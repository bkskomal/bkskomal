# TB-OutlookPro -- Self-Contained Installer (2026-06-29)

This folder is everything you need to install TB-OutlookPro on a fresh
Windows machine with Thunderbird 140+ already installed.

## Quick install

`powershell
# 1. Unzip this folder anywhere (e.g. C:\Tools\TB-OutlookPro)
# 2. Open PowerShell, cd into it
# 3. Run the installer (auto-detects your default TB profile):
.\install.ps1
`

That's it -- the script reads `profiles.ini` to find the profile Thunderbird
opens by default and installs everything into it.

To target a different profile explicitly:

`powershell
.\install.ps1 -ProfileName default-release
.\install.ps1 -ProfileName "C:\path\to\custom-profile"
`

To list your profiles: `ls C:\Users\bkkom\AppData\Roaming\Thunderbird\Profiles`.

## What gets installed

| Layer | Source folder | Count |
|---|---|---|
| In-house plugins | `plugins\` | 7 (.xpi) |
| 3rd-party add-ons | `vendor\` | up to 9 (.xpi); composeur-en-onglet is REQUIRED |
| Visual theme | `userChrome.css` | 1 file -> `<profile>\chrome\` |
| Prefs | `user.js` | 1 file -> `<profile>\` |
| Required prefs | added to `user.js` if missing | 3 |

Plus:
- `pst_import\` -- Python CLI (run separately if you want to import PSTs)

## Installer flags

| Flag | What it does |
|---|---|
| `-ProfileName <name>` | Target TB profile (omit -> auto-detect default profile from `profiles.ini`). Accepts a profile name (substring match) or a full path. |
| `-NoLaunch` | Don't auto-launch TB after install |
| `-NoVendor` | Skip `vendor\` 3rd-party add-ons (only install in-house ones) |
| `-VendorOnly <names,...>` | Install only specific 3rd-party add-ons by filename match (e.g. `-VendorOnly "composeur","cardbook"`) |
| `-ThunderbirdExe <path>` | Override default `C:\Program Files\Mozilla Thunderbird\thunderbird.exe` |
| `-MinTbVersion <int>` | Override minimum TB major version (default `140`) |

## Verifying it worked

After TB launches, check Tools -> Add-ons and Themes -- you should see:
- All 7 `outlookpro-*` add-ons (active, no errors)
- `Tab Composer` (composeur-en-onglet) -- REQUIRED for +New Message -> tab
- Any other vendor add-ons you opted in to

For the PST import CLI:

`powershell
pip install libpff-python-windows pywin32 msal
python pst_import\pst_import.py --help
`

## Architecture / what each plugin does

See the full README in this folder.

## Build version

This dist was built from source on 2026-06-29 12:45 UTC.
Source: TB-OutlookPro project (see `README.md` for full plugin docs).

## License

MIT -- see `LICENSE`.