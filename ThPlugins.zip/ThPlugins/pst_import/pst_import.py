"""Import an Outlook .pst file into Thunderbird.

Phase 1: --mode local writes to TB's Local Folders directly.
Phase 2 (planned): --mode imap APPENDs to an IMAP server with OAuth2.

Usage:
  python pst_import.py archive.pst --mode local
  python pst_import.py archive.pst --mode local --target "My Old Mail"
  python pst_import.py archive.pst --mode local --tb-profile "C:\\path\\to\\profile"
  python pst_import.py archive.pst --dry-run    # count messages, no write

The PST hierarchy is mirrored under the target folder name. Existing
messages (by Message-ID) are deduped. Thunderbird must be CLOSED before
running this — TB locks its Mail directory while it has a profile open.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path


def _default_tb_profile() -> Path:
    """Pick the jitsitest profile if present; else first default-release."""
    base = Path.home() / "AppData" / "Roaming" / "Thunderbird" / "Profiles"
    if not base.exists():
        raise SystemExit(
            f"TB profile dir not found: {base}\n"
            "Pass --tb-profile <path> explicitly."
        )
    cands = list(base.iterdir())
    for p in cands:
        if "jitsitest" in p.name.lower():
            return p
    for p in cands:
        if "default-release" in p.name.lower():
            return p
    if cands:
        return cands[0]
    raise SystemExit("No TB profiles found.")


def _run_imap(args, pst_path: Path) -> int:
    """Phase 2: PST → IMAP server via OAuth2 device-code + SASL XOAUTH2."""
    from pst_reader import iter_messages
    from imap_writer import ImapWriter, acquire_oauth_token_device_code

    if not args.imap_user:
        print("ERROR: --imap-user required for IMAP mode", file=sys.stderr)
        return 2

    state_file = Path(args.state_file) if args.state_file \
                  else pst_path.with_suffix(pst_path.suffix + ".state.json")

    print(f"PST:         {pst_path}")
    print(f"Mode:        imap")
    print(f"Server:      {args.imap_host}:{args.imap_port}")
    print(f"User:        {args.imap_user}")
    print(f"Auth:        {args.imap_auth}")
    print(f"Root folder: {args.target}")
    print(f"State file:  {state_file}")
    print()

    if args.dry_run:
        # Dry-run uses the same code path as local mode
        return _walk_count(pst_path, args)

    # Acquire token
    access_token = None
    password = args.imap_password
    if args.imap_auth == "oauth2":
        print("Acquiring OAuth2 token via device-code flow...")
        access_token = acquire_oauth_token_device_code()
    elif args.imap_auth == "basic" and not password:
        import getpass
        password = getpass.getpass(f"Password for {args.imap_user}: ")

    n_written = n_dedup = 0
    start = time.time()
    with ImapWriter(
        host=args.imap_host, port=args.imap_port,
        user=args.imap_user, access_token=access_token, password=password,
        root_folder=args.target, state_file=state_file,
    ) as w:
        for folder, eml in iter_messages(pst_path, include_system=args.include_system):
            try:
                if w.write(folder, eml):
                    n_written += 1
                else:
                    n_dedup += 1
            except Exception as e:
                print(f"  ! folder={folder!r} failed: {e}", file=sys.stderr)
            if (n_written + n_dedup) % 25 == 0 and (n_written + n_dedup) > 0:
                rate = (n_written + n_dedup) / max(time.time() - start, 0.1)
                print(f"  ...{n_written + n_dedup} processed "
                      f"({n_written} uploaded, {n_dedup} dedup'd) "
                      f"[{rate:.1f} msg/s]", flush=True)
    dt = time.time() - start
    print()
    print(f"Done. {n_written} uploaded, {n_dedup} dedup'd in {dt:.1f}s")
    print(f"State persisted to {state_file} — re-run to resume.")
    return 0


def _walk_count(pst_path: Path, args) -> int:
    """Shared dry-run path: walk PST, print counts per folder."""
    from pst_reader import iter_messages
    print("DRY RUN - walking PST, no writes")
    count = 0
    per_folder: dict[str, int] = {}
    start = time.time()
    for folder, _ in iter_messages(pst_path, include_system=args.include_system):
        count += 1
        per_folder[folder] = per_folder.get(folder, 0) + 1
        if count % 100 == 0:
            print(f"  ...{count} walked", flush=True)
    dt = time.time() - start
    print()
    print(f"Total messages: {count}  ({dt:.1f}s)")
    print(f"Folders ({len(per_folder)}):")
    for f, n in sorted(per_folder.items()):
        print(f"  {n:>6}  {f}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Import .pst into Thunderbird.")
    ap.add_argument("pst", help="Path to .pst file")
    ap.add_argument("--mode", choices=["local", "imap"], default="local")
    ap.add_argument("--target", default="Imported PST",
                    help="Root folder name (default: 'Imported PST')")
    ap.add_argument("--tb-profile", default=None,
                    help="local mode: TB profile dir (default: auto-detect jitsitest)")
    ap.add_argument("--dry-run", action="store_true",
                    help="Walk the PST and count messages; do not write.")
    ap.add_argument("--include-system", action="store_true",
                    help="Include system folders (Search Root, Recoverable Items).")
    # IMAP mode options
    ap.add_argument("--imap-host", default="outlook.office365.com",
                    help="IMAP server host (default: outlook.office365.com)")
    ap.add_argument("--imap-port", type=int, default=993)
    ap.add_argument("--imap-user", default=None,
                    help="IMAP username (email address)")
    ap.add_argument("--imap-password", default=None,
                    help="IMAP password (if using --imap-auth basic; not recommended)")
    ap.add_argument("--imap-auth", choices=["oauth2", "basic"], default="oauth2")
    ap.add_argument("--state-file", default=None,
                    help="JSON file to persist seen-Message-IDs for resume (default: <pst>.state.json)")
    args = ap.parse_args()

    pst_path = Path(args.pst).resolve()
    if not pst_path.exists():
        print(f"ERROR: PST not found: {pst_path}", file=sys.stderr)
        return 2

    # Import lazily so --help / --dry-run-with-bad-args don't need pypff loaded
    from pst_reader import iter_messages

    if args.mode == "imap":
        return _run_imap(args, pst_path)

    profile = Path(args.tb_profile) if args.tb_profile else _default_tb_profile()
    print(f"PST:         {pst_path}")
    print(f"Mode:        local")
    print(f"TB profile:  {profile}")
    print(f"Root folder: Local Folders/{args.target}")
    print()

    if args.dry_run:
        print("DRY RUN — walking PST, no files will be written")
        count = 0
        per_folder: dict[str, int] = {}
        start = time.time()
        for folder, _eml in iter_messages(pst_path, include_system=args.include_system):
            count += 1
            per_folder[folder] = per_folder.get(folder, 0) + 1
            if count % 100 == 0:
                print(f"  ...{count} messages walked", flush=True)
        dt = time.time() - start
        print()
        print(f"Total messages: {count}  ({dt:.1f}s)")
        print(f"Folders ({len(per_folder)}):")
        for f, n in sorted(per_folder.items()):
            print(f"  {n:>6}  {f}")
        return 0

    # Live run — write to mbox files
    from local_writer import LocalFoldersWriter

    # Best-effort check: warn if TB is running
    try:
        import subprocess
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq thunderbird.exe"],
                             capture_output=True, text=True, timeout=5)
        if "thunderbird.exe" in out.stdout.lower():
            print("WARNING: Thunderbird is running. Close it first to avoid")
            print("         file lock conflicts. Continuing anyway...", file=sys.stderr)
    except Exception:
        pass

    n_written = n_dedup = 0
    start = time.time()
    with LocalFoldersWriter(profile, root_folder=args.target) as w:
        for folder, eml in iter_messages(pst_path, include_system=args.include_system):
            written = w.write(folder, eml)
            if written:
                n_written += 1
            else:
                n_dedup += 1
            if (n_written + n_dedup) % 50 == 0:
                print(f"  ...{n_written + n_dedup} processed "
                      f"({n_written} new, {n_dedup} dedup)", flush=True)

    dt = time.time() - start
    print()
    print(f"Done. {n_written} messages written, {n_dedup} dedup'd in {dt:.1f}s")
    print()
    print("Next step: launch Thunderbird with this profile. The new folders")
    print(f"will appear under 'Local Folders' -> '{args.target}'.")
    print("(TB regenerates the .msf summary files on first open.)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
