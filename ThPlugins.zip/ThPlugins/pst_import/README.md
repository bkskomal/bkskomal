# PST Import for Thunderbird

Import Outlook `.pst` files into Thunderbird — into **Local Folders**
(offline) or directly to a **remote IMAP server** via OAuth2 device-code
(M365, on-prem Exchange, any RFC-3501 IMAP backend).

## What's in this folder

| File | Purpose |
|------|---------|
| `pst_reader.py` | Walks a PST via `libpff-python-windows`, converts each message to RFC-822 EML bytes (handles plain + HTML alternative + attachments + record_set body fallback). |
| `local_writer.py` | Streams EML bytes into Thunderbird's Mozilla mbox files under `<profile>/Mail/Local Folders/`, creates `.sbd` subfolder dirs for nested PST folders, dedupes by Message-ID. |
| `imap_writer.py` | **Phase 2**: SASL XOAUTH2 + IMAP APPEND. MSAL device-code flow to acquire access token using the Thunderbird-trusted Microsoft client_id (no Azure app registration needed). Preserves folder hierarchy under a configurable root. Resumable via state file. |
| `pst_import.py` | CLI entry point. `--mode local` or `--mode imap`. `--dry-run` walks the PST without writing. |
| `make_sample_pst.py` | Builds a synthetic PST via Outlook COM automation (requires Outlook installed). Produces a small PST with 4 top-level folders, 2 nested, 15 messages of varied content. |

## Prerequisites

- **Python 3.13** with `libpff-python-windows` 20231205 + `pywin32` + **`msal`** (for IMAP mode)
- **Thunderbird** target profile (default: `jitsitest`) — only needed for **local** mode
- **Outlook installed** ONLY for `make_sample_pst.py` — not required for importing

```powershell
pip install libpff-python-windows pywin32 msal
```

## Usage

### Generate a test PST (only if you don't have one)

```powershell
python make_sample_pst.py --out C:\Temp\sample.pst
```

### Dry-run an import (count messages, no writes)

```powershell
python pst_import.py C:\Temp\sample.pst --dry-run
```

### Mode 1 — Local: PST → TB Local Folders

```powershell
# 1. Close Thunderbird (it locks the Mail directory)
Get-Process thunderbird -ErrorAction SilentlyContinue | Stop-Process -Force

# 2. Run import
python pst_import.py C:\Temp\sample.pst --target "Imported PST"

# 3. Restart TB — new folders appear under Local Folders > Imported PST
```

### Mode 2 — IMAP: PST → remote mailbox via OAuth2

```powershell
python pst_import.py C:\Temp\sample.pst `
    --mode imap `
    --imap-user bk.komal@hotmail.com `
    --target "Imported PST"
```

What happens:

1. CLI prints a Microsoft device-code URL + 8-char code
2. You open the URL in any browser, paste the code, sign in to Microsoft, consent
3. CLI acquires the access token (cached to `~/.outlookpro_msal_cache.bin` for next runs)
4. Connects to `outlook.office365.com:993` via TLS, authenticates with SASL XOAUTH2
5. For each PST folder, creates the corresponding IMAP folder under "Imported PST/…"
6. APPENDs each message with the `\Seen` flag
7. Skips messages whose Message-ID is already in the state file (resume across runs)

Other IMAP options:

```powershell
# Different server (any IMAP-XOAUTH2 backend)
python pst_import.py archive.pst --mode imap \
    --imap-host imap.gmail.com --imap-port 993 \
    --imap-user me@gmail.com --target "Imported"

# Legacy Basic auth (Microsoft consumers no longer support this)
python pst_import.py archive.pst --mode imap \
    --imap-user me@example.com --imap-auth basic --imap-password "..."

# Resume from existing state file
python pst_import.py archive.pst --mode imap \
    --imap-user me@example.com \
    --state-file C:\Temp\archive.pst.state.json
```

### Resumability

Both modes persist a JSON state file of seen Message-IDs. Re-running
the same command skips already-uploaded messages, so an interrupted
upload is safe to resume.

## Design choices

- **Dedup by Message-ID** — re-running on the same PST is idempotent.
- **Folder hierarchy mirrored** under one root (default `Imported PST`).
- **System folders skipped** by default (Search Root, Recoverable Items).
  Use `--include-system` to include them.
- **TB lock detection** — warns if TB is running before write.
- **No `.msf` files written** — TB regenerates them on next open.

## Phase 2 (planned)

`--mode imap` with OAuth2 device-code flow:
- Acquires Microsoft token via MSAL device-code (no client secret needed)
- Connects via `imaplib.IMAP4_SSL("outlook.office365.com", 993)`
- Authenticates with `SASL XOAUTH2`
- `APPEND`s each EML into the target folder (creates folder if missing)
- Preserves PST hierarchy under the target folder

## Notes

- libpff is **read-only**. PST writing requires Outlook COM (used only for the test-PST generator).
- libpff project status: alpha-20231205, last release Dec 2023, but stable for read paths.
- IMAP+OAuth2 to outlook.office365.com still works as of mid-2026
  (Microsoft only deprecated Basic Auth; OAuth IMAP still supported).
- TLS 1.0/1.1 will be blocked for POP/IMAP in July 2026 — Python's
  `imaplib.IMAP4_SSL` defaults to TLS 1.2+, so we're fine.
