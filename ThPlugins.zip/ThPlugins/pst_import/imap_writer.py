"""Upload PST messages to a remote IMAP server.

Pairs with pst_reader.py to give --mode imap behavior for pst_import.py.

Auth: OAuth2 device-code flow via MSAL (recommended for Outlook 365),
or username/password (legacy, off by default).

Folder hierarchy from the PST is mirrored under a configurable root.
Dedup by Message-ID across re-runs (state file).

Tested target: outlook.office365.com:993 with the Thunderbird-trusted
Microsoft client_id (so we don't need our own Azure app registration).
Any IMAP server that supports XOAUTH2 should work the same way.
"""
from __future__ import annotations

import email
import email.parser
import email.policy
import imaplib
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Iterable, Iterator, Optional

# ---- IMAP folder name encoding (RFC 3501 modified UTF-7) ----------
def _utf7_encode_imap(s: str) -> str:
    """Encode IMAP mailbox name using modified UTF-7 (RFC 3501 5.1.3).
    Required because some IMAP servers reject non-ASCII raw."""
    out = []
    buf = []
    def flush():
        if not buf: return
        encoded = "".join(buf).encode("utf-16-be")
        import base64
        b = base64.b64encode(encoded).decode("ascii").rstrip("=")
        b = b.replace("/", ",")
        out.append("&" + b + "-")
        buf.clear()
    for ch in s:
        cp = ord(ch)
        if 0x20 <= cp <= 0x7E and ch != "&":
            flush()
            out.append(ch)
        elif ch == "&":
            flush()
            out.append("&-")
        else:
            buf.append(ch)
    flush()
    return "".join(out)


def _quote_mailbox(name: str) -> str:
    """Quote a mailbox name for IMAP commands."""
    enc = _utf7_encode_imap(name)
    return '"' + enc.replace("\\", "\\\\").replace('"', '\\"') + '"'


# ---- OAuth2 token acquisition (device-code flow via MSAL) ---------

TB_MS_CLIENT_ID = "9e5f94bc-e8a4-4e73-b8be-63364c29d753"   # Thunderbird's registered client id
TB_MS_TENANT    = "common"
TB_MS_SCOPES    = ["https://outlook.office.com/IMAP.AccessAsUser.All"]


def _default_cache_path() -> Path:
    """Default MSAL cache location — TB profile dir if available, else
    home dir. Per-profile isolation prevents tokens from leaking across
    different mailboxes."""
    # Try TB jitsitest profile first
    candidates = [
        Path.home() / "AppData/Roaming/Thunderbird/Profiles",
    ]
    for base in candidates:
        if not base.exists():
            continue
        for p in base.iterdir():
            if "jitsitest" in p.name.lower():
                return p / "outlookpro_msal_cache.bin"
        # No jitsitest — use first profile
        first = next(iter(base.iterdir()), None)
        if first:
            return first / "outlookpro_msal_cache.bin"
    # Fallback: home dir (legacy)
    return Path.home() / ".outlookpro_msal_cache.bin"


def acquire_oauth_token_device_code(
    client_id: str = TB_MS_CLIENT_ID,
    tenant: str = TB_MS_TENANT,
    scopes: Iterable[str] = TB_MS_SCOPES,
    cache_path: Optional[Path] = None,
) -> str:
    """Device-code OAuth flow → access token. Caches refresh token to disk.

    Cache lives in the TB profile by default (per-profile isolation).
    Pass `cache_path=` to override.

    Returns the access token (string) on success. Raises on failure.
    """
    try:
        import msal
    except ImportError:
        raise SystemExit(
            "msal not installed. Run:  pip install msal"
        )

    cache = msal.SerializableTokenCache()
    cache_path = cache_path or _default_cache_path()
    # Legacy path migration: if user has an old cache in home dir, move it
    legacy = Path.home() / ".outlookpro_msal_cache.bin"
    if legacy.exists() and not cache_path.exists():
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(legacy.read_text())
            legacy.unlink()
            print(f"  (migrated legacy MSAL cache → {cache_path})")
        except Exception:
            cache_path = legacy   # keep using old path if migration fails
    if cache_path.exists():
        cache.deserialize(cache_path.read_text())

    app = msal.PublicClientApplication(
        client_id,
        authority=f"https://login.microsoftonline.com/{tenant}",
        token_cache=cache,
    )

    # Try silent (cached refresh token) first
    accounts = app.get_accounts()
    if accounts:
        result = app.acquire_token_silent(list(scopes), account=accounts[0])
        if result and "access_token" in result:
            if cache.has_state_changed:
                cache_path.write_text(cache.serialize())
            return result["access_token"]

    # Fall back to device-code flow
    flow = app.initiate_device_flow(scopes=list(scopes))
    if "user_code" not in flow:
        raise RuntimeError(
            f"Device flow init failed: {flow.get('error_description', flow)}"
        )
    print()
    print("=" * 64)
    print(f"  Open this URL in any browser:   {flow['verification_uri']}")
    print(f"  Enter this code:                {flow['user_code']}")
    print(f"  (expires in {flow['expires_in']}s)")
    print("=" * 64)
    print()

    result = app.acquire_token_by_device_flow(flow)
    if "access_token" not in result:
        raise RuntimeError(
            f"Token acquisition failed: {result.get('error_description', result)}"
        )
    if cache.has_state_changed:
        cache_path.write_text(cache.serialize())
    return result["access_token"]


# ---- XOAUTH2 helper (RFC 7628) ------------------------------------
def build_xoauth2_blob(user: str, access_token: str) -> str:
    """Build the SASL XOAUTH2 base64 blob: user=...^Aauth=Bearer ...^A^A"""
    raw = f"user={user}\x01auth=Bearer {access_token}\x01\x01"
    import base64
    return base64.b64encode(raw.encode("utf-8")).decode("ascii")


# ---- The writer ---------------------------------------------------

class ImapWriter:
    """Stream-uploads EMLs to IMAP, dedups by Message-ID."""

    def __init__(self, *, host: str, port: int = 993,
                 user: str, access_token: Optional[str] = None,
                 password: Optional[str] = None,
                 root_folder: str = "Imported PST",
                 state_file: Optional[Path] = None,
                 hierarchy_sep: str = "/"):
        self.host = host
        self.port = port
        self.user = user
        self.access_token = access_token
        self.password = password
        self.root_folder = root_folder
        self.hierarchy_sep = hierarchy_sep   # how the SERVER nests folders
        self.state_file = state_file
        self.seen_message_ids: set[str] = set()
        if state_file and state_file.exists():
            try:
                self.seen_message_ids = set(json.loads(state_file.read_text()))
            except Exception:
                pass
        self._imap: Optional[imaplib.IMAP4_SSL] = None
        self._created_folders: set[str] = set()

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *_):
        self.close()

    def connect(self):
        print(f"Connecting {self.host}:{self.port} ...", end=" ", flush=True)
        self._imap = imaplib.IMAP4_SSL(self.host, self.port)
        print("ok")
        if self.access_token:
            print(f"Authenticating XOAUTH2 user={self.user} ...", end=" ", flush=True)
            blob = build_xoauth2_blob(self.user, self.access_token)
            typ, resp = self._imap.authenticate("XOAUTH2", lambda _: blob)
            if typ != "OK":
                raise RuntimeError(f"XOAUTH2 failed: {resp}")
            print("ok")
        else:
            print(f"Authenticating LOGIN user={self.user} ...", end=" ", flush=True)
            typ, resp = self._imap.login(self.user, self.password or "")
            if typ != "OK":
                raise RuntimeError(f"LOGIN failed: {resp}")
            print("ok")
        # Discover the server's hierarchy separator from LIST ""
        typ, resp = self._imap.list("", "")
        if typ == "OK" and resp:
            # Reply line looks like: ('(\\HasNoChildren) "/" "INBOX"',)
            for line in resp:
                m = re.match(rb'\([^)]*\) "([^"]+)" ', line)
                if m:
                    self.hierarchy_sep = m.group(1).decode("ascii")
                    print(f"server hierarchy sep: {self.hierarchy_sep!r}")
                    break

    def close(self):
        if self._imap:
            try: self._imap.logout()
            except Exception: pass
            self._imap = None
        if self.state_file:
            self.state_file.write_text(json.dumps(sorted(self.seen_message_ids)))

    def _server_folder(self, pst_path: str) -> str:
        """Convert a PST-style 'Inbox/Personal/2024' path to the
        server's mailbox name under our root."""
        full = self.root_folder
        if pst_path:
            # PST paths use '/'; map to server's separator
            parts = [p for p in pst_path.split("/") if p]
            for p in parts:
                full = full + self.hierarchy_sep + p
        return full

    def ensure_folder(self, server_path: str) -> None:
        """CREATE the folder if we haven't already this session."""
        if server_path in self._created_folders:
            return
        quoted = _quote_mailbox(server_path)
        typ, resp = self._imap.create(quoted)
        # OK = created, NO with "already exists" message = fine
        if typ == "OK":
            print(f"  + created folder: {server_path}")
        else:
            msg = b"".join(resp or [b""]).decode("ascii", errors="replace").lower()
            if "exist" not in msg and "alreadyexists" not in msg:
                # Try parent path first then retry
                parts = server_path.split(self.hierarchy_sep)
                if len(parts) > 1:
                    self.ensure_folder(self.hierarchy_sep.join(parts[:-1]))
                    self._imap.create(quoted)
        self._created_folders.add(server_path)

    def write(self, pst_folder_path: str, eml_bytes: bytes) -> bool:
        """APPEND one message. Returns True if uploaded, False if dedup."""
        mid = _extract_message_id(eml_bytes)
        if mid and mid in self.seen_message_ids:
            return False

        server_folder = self._server_folder(pst_folder_path)
        self.ensure_folder(server_folder)

        # Build the IMAP APPEND. Flags: \Seen since these are historical.
        quoted = _quote_mailbox(server_folder)
        date = imaplib.Time2Internaldate(time.time())
        typ, resp = self._imap.append(quoted, "(\\Seen)", date, eml_bytes)
        if typ != "OK":
            raise RuntimeError(
                f"APPEND failed for {server_folder}: {resp}"
            )
        if mid:
            self.seen_message_ids.add(mid)
        return True


def _extract_message_id(eml_bytes: bytes) -> Optional[str]:
    head_end = eml_bytes.find(b"\n\n")
    head = eml_bytes[: head_end if head_end != -1 else len(eml_bytes)]
    for line in head.splitlines():
        if line.lower().startswith(b"message-id:"):
            return line.split(b":", 1)[1].strip().decode("ascii", errors="replace")
    return None
