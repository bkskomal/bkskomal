"""Write a stream of (folder_path, eml_bytes) into Thunderbird's
Local Folders as Mozilla mbox files.

Mozilla / Berkeley mbox layout in a TB profile:

  <profile>/Mail/Local Folders/
      Inbox             # mbox file (text, no extension)
      Inbox.msf         # TB-generated summary; we don't write — TB rebuilds
      Sent              # mbox file
      Sent.msf
      MyFolder.sbd/     # subfolder *directory* — same pattern recurses
          Child         # mbox file inside .sbd
          Child.msf

Each mbox file is a concatenation of:
    From - <Day Mon DD HH:MM:SS YYYY>\n
    <RFC-822 message bytes>
    \n

Lines inside the message body that start with "From " must be quoted to
">From " on write (and unquoted on read). TB reads these.

We don't write .msf files; TB regenerates them at startup. On next launch
of TB the new folders appear and are indexed.
"""
from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Dict, Iterable, Tuple

# Lines that start with "From " (zero-or-more ">", then "From ") must be
# escaped to ">From " etc. in mbox format.
_FROM_LINE = re.compile(rb"^(>*From )", re.MULTILINE)


class LocalFoldersWriter:
    """Append messages to mbox files under TB's Local Folders directory.

    Maintains per-folder file handles + a Message-ID set for dedup.
    """

    def __init__(self, profile_dir: Path, root_folder: str = "Imported PST"):
        self.local_root = Path(profile_dir) / "Mail" / "Local Folders"
        if not self.local_root.exists():
            raise FileNotFoundError(
                f"TB Local Folders dir not found: {self.local_root}\n"
                "Has Thunderbird run with this profile at least once?"
            )
        self.root_folder = root_folder
        self._handles: Dict[str, "io.BufferedWriter"] = {}
        self._seen_ids: Dict[str, set[bytes]] = {}

    def write(self, folder_path: str, eml: bytes) -> bool:
        """Append eml to the mbox for folder_path. Returns True if written,
        False if deduped (Message-ID already seen)."""
        full = f"{self.root_folder}/{folder_path}" if folder_path else self.root_folder
        f = self._open(full)

        mid = _extract_message_id(eml)
        seen = self._seen_ids.setdefault(full, set())
        if mid and mid in seen:
            return False
        if mid:
            seen.add(mid)

        # Separator
        ts = time.strftime("%a %b %d %H:%M:%S %Y", time.gmtime())
        f.write(f"From - {ts}\n".encode())
        # Body with "From " escape
        escaped = _FROM_LINE.sub(rb">\1", eml)
        f.write(escaped)
        if not escaped.endswith(b"\n"):
            f.write(b"\n")
        f.write(b"\n")  # blank line between messages
        return True

    def _open(self, full_path: str):
        """Open (or reuse) an mbox file for the given logical folder path.
        full_path uses '/' as separator and maps to <root>/<subA>.sbd/<subB>.sbd/<leaf>.
        """
        if full_path in self._handles:
            return self._handles[full_path]

        parts = [p.strip() for p in full_path.split("/") if p.strip()]
        # All intermediate parts become .sbd dirs; final part is the mbox file.
        cur = self.local_root
        for p in parts[:-1]:
            cur = cur / f"{_safe(p)}.sbd"
            cur.mkdir(exist_ok=True)
            # Also create an EMPTY mbox file at the parent level so TB shows
            # the folder; otherwise the .sbd alone is invisible until a
            # message gets added.
            parent_mbox = cur.parent / _safe(p)
            if not parent_mbox.exists():
                parent_mbox.touch()
        leaf_file = cur / _safe(parts[-1])
        leaf_file.touch(exist_ok=True)
        # Open in append-binary so we can stream
        fh = open(leaf_file, "ab", buffering=64 * 1024)
        self._handles[full_path] = fh
        return fh

    def close(self) -> None:
        for fh in self._handles.values():
            fh.close()
        self._handles.clear()

    def __enter__(self): return self
    def __exit__(self, *a): self.close()


def _safe(name: str) -> str:
    """Filesystem-safe folder name. Replace chars Windows refuses."""
    out = name
    for bad in '\\/:*?"<>|':
        out = out.replace(bad, "_")
    return out.strip() or "Unnamed"


def _extract_message_id(eml: bytes) -> bytes | None:
    """Pull Message-ID from header block. Used for dedup."""
    # Split headers from body
    head_end = eml.find(b"\n\n")
    headers = eml[: head_end if head_end != -1 else len(eml)]
    for line in headers.splitlines():
        if line.lower().startswith(b"message-id:"):
            return line.split(b":", 1)[1].strip()
    return None
