"""Generate a sample test PST.

We use Outlook COM (AddStoreEx + folder.Items.Add) to build a small
test PST with a few folders and messages. This requires Outlook
installed and that the COM subsystem is willing to create stores
without UI prompts.

In our experience some Outlook installs (where the user has both
Classic and New Outlook side-by-side, or has a corrupted MAPI
profile) refuse to honor a path passed to AddStoreEx and instead
pop a "Create/Open Outlook Data File" picker. The dismisser thread
below auto-fills that picker if it appears.

If you don't have a PST handy and this script fails, see
`make_sample_emls.py` — it bypasses Outlook entirely and writes
synthetic EML files for testing the LocalFoldersWriter path.

Usage:
  python make_sample_pst.py --out C:\\Temp\\sample.pst
"""
from __future__ import annotations

import argparse
import sys
import threading
import time
from pathlib import Path

import pythoncom
import win32com.client
import win32con
import win32gui

olStoreUnicode = 3

SAMPLES = [
    ("Inbox", "Welcome to TB-OutlookPro test", "qa@example.com", "html",
     "<p>First synthetic test message. If you see this in Thunderbird "
     "Local Folders, the PST import pipeline works.</p>"),
    ("Inbox", "Server maintenance window 2026-07-15",
     "ops@example.com", "plain",
     "Heads up — outlook.office365.com IMAP will be unavailable for "
     "30 minutes starting 02:00 UTC on July 15, 2026."),
    ("Inbox", "Lunch tomorrow?", "bob@example.com", "plain",
     "1pm at the usual place? Let me know."),
    ("Sent Items", "Re: server maintenance window",
     "me@example.com", "plain",
     "Acknowledged — I will pause the nightly batch on July 15."),
    ("Archive", "Old contract 2024-03-15", "legal@example.com", "plain",
     "Original NDA filed in 2024. Keeping for reference."),
    ("Personal/2024", "Birthday wishes", "mom@example.com", "plain",
     "Happy birthday beta! Lots of love."),
    ("Personal/2025", "Anniversary plan", "wife@example.com", "html",
     "<p>Booked the dinner for <b>Saturday 8pm</b>. Can you arrange "
     "the cake?</p>"),
]


_stop = threading.Event()

def _handle_dialogs(target_path: Path):
    """Auto-fill or close any Outlook picker/error dialog."""
    while not _stop.is_set():
        try:
            def cb(h, _):
                if not win32gui.IsWindowVisible(h):
                    return
                t = win32gui.GetWindowText(h) or ""
                if t == "Create/Open Outlook Data File":
                    _fill_picker(h, target_path)
                elif t == "Outlook Data File" or t == "Microsoft Outlook":
                    win32gui.PostMessage(h, win32con.WM_CLOSE, 0, 0)
            win32gui.EnumWindows(cb, None)
        except Exception:
            pass
        time.sleep(0.3)


def _fill_picker(hwnd: int, target_path: Path):
    """Type target_path into the picker's filename field + click Open."""
    try:
        import uiautomation as auto
        w = auto.ControlFromHandle(hwnd)
        # find File name edit
        def find(c, pred, d=0):
            if d > 8: return None
            try:
                if pred(c): return c
                for cc in c.GetChildren():
                    r = find(cc, pred, d+1)
                    if r: return r
            except: pass
        edit = find(w, lambda c: c.ControlTypeName == "EditControl"
                                  and (c.AutomationId or "").startswith("1148"))
        open_btn = find(w, lambda c: c.ControlTypeName == "ButtonControl"
                                       and c.AutomationId == "1")
        if edit and open_btn:
            edit.SendKeys("{Ctrl}a{Delete}")
            edit.SendKeys(str(target_path).replace(" ", "{Space}"))
            time.sleep(0.2)
            open_btn.GetInvokePattern().Invoke()
            print(f"  auto-filled picker -> {target_path}", flush=True)
    except Exception as e:
        print(f"  picker auto-fill failed: {e}", flush=True)


def main() -> int:
    sys.stdout.reconfigure(line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    out = Path(args.out) if args.out else Path.home() / "Documents" / "sample.pst"
    out = out.resolve()
    if out.exists():
        out.unlink()
    print(f"Target: {out}")

    pythoncom.CoInitialize()
    t = threading.Thread(target=_handle_dialogs, args=(out,), daemon=True)
    t.start()
    print("Dialog handler started")
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        ns = outlook.GetNamespace("MAPI")
        print("Calling AddStoreEx...")
        ns.AddStoreEx(str(out), olStoreUnicode)
        # Locate the store via indexed access
        store = None
        for i in range(1, ns.Stores.Count + 1):
            try:
                s = ns.Stores.Item(i)
                if Path(s.FilePath).resolve() == out:
                    store = s; break
            except Exception:
                continue
        if not store:
            print("ERROR: store not in ns.Stores", file=sys.stderr)
            return 1
        root = store.GetRootFolder()
        print(f"Root: {root.Name}")

        # Ensure folder hierarchy
        folders = {}
        def ensure(path):
            if path in folders: return folders[path]
            parent = root; cur = ""
            for p in path.split("/"):
                cur = f"{cur}/{p}" if cur else p
                if cur in folders:
                    parent = folders[cur]; continue
                found = None
                for i in range(1, parent.Folders.Count + 1):
                    try:
                        f = parent.Folders.Item(i)
                        if f.Name == p: found = f; break
                    except Exception:
                        continue
                if not found: found = parent.Folders.Add(p)
                folders[cur] = found; parent = found
            return folders[path]

        for path, *_ in SAMPLES:
            ensure(path)
        print(f"Folders: {len(folders)}")

        # IPM.Post items are designed to live in a folder (not be sent
        # via SMTP) so they persist correctly in a profile-less PST.
        # Notes (IPM.Note) silently fail to persist when no MAPI
        # profile is attached.
        for i, (path, subj, sender, kind, body) in enumerate(SAMPLES, 1):
            folder = folders[path]
            post = folder.Items.Add("IPM.Post")
            post.Subject = subj
            if kind == "html":
                post.BodyFormat = 2; post.HTMLBody = body
            else:
                post.BodyFormat = 1; post.Body = body
            # IPM.Post has SenderName not SentOnBehalfOfName
            try:
                post.SenderName = sender
            except Exception:
                pass
            post.Save()
            print(f"  + {path}: {subj}")

        # Force Outlook to flush all pending writes to disk before
        # detaching the store.
        try:
            outlook.GetNamespace("MAPI").Logoff()
        except Exception:
            pass
        time.sleep(2)
        ns.RemoveStore(root)
        time.sleep(2)
        sz = out.stat().st_size / 1024
        print(f"Done: {out}  ({sz:.1f} KB)")
        return 0
    finally:
        _stop.set()
        pythoncom.CoUninitialize()


if __name__ == "__main__":
    sys.exit(main())
