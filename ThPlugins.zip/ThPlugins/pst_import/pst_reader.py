"""Walk a PST file, yield (folder_path, EML bytes) tuples.

PST internals (via libpff/pypff):
  pst.root_folder
    -> sub_folders[]    (Top of Personal Folders, Search Root, etc.)
        -> sub_folders[]
        -> sub_messages[]

Each message exposes:
  - transport_headers   raw RFC-822 headers as the PST recorded them
                        (may be missing for items composed offline)
  - plain_text_body
  - html_body
  - rtf_body            (compressed; we ignore)
  - attachments[]       each has .name, .read_buffer(size)
  - subject, sender_name, delivery_time, ...

Strategy for EML output:
  1. If transport_headers exist AND look complete, use them as the seed.
  2. Otherwise synthesise minimal headers (Subject, From, Date, To,
     Message-ID) from the PST's own metadata.
  3. Assemble multipart/mixed with body alternative + attachments.
"""
from __future__ import annotations

import email
import email.message
import email.policy
import email.utils
import hashlib
import mimetypes
from pathlib import Path
from typing import Iterator, Tuple

import pypff

# PST "Top of Personal Folders" is the only branch users typically care about.
# Search folders, deleted items, and the system root are skipped by default
# unless --include-system is passed.
TOP_NAMES = {"top of personal folders", "top of outlook data file",
             "ipm_subtree", "ipm.subtree"}


def open_pst(path: Path) -> pypff.file:
    if not pypff.check_file_signature(str(path)):
        raise ValueError(f"{path} is not a valid PST file")
    pst = pypff.file()
    pst.open(str(path))
    return pst


def iter_messages(pst_path: Path, include_system: bool = False
                  ) -> Iterator[Tuple[str, bytes]]:
    """Yield (folder_path, eml_bytes) for every message in the PST."""
    pst = open_pst(pst_path)
    try:
        for child in pst.root_folder.sub_folders:
            name = (child.name or "").strip().lower()
            if not include_system and name not in TOP_NAMES and name != "":
                # Many PSTs put real folders directly under root; only skip
                # truly system branches by name.
                if name in {"search root", "deleted items recovery"}:
                    continue
            yield from _walk(child, parent_path="")
    finally:
        pst.close()


def _walk(folder, parent_path: str) -> Iterator[Tuple[str, bytes]]:
    """Recursively yield (folder_path, eml_bytes) for a folder subtree."""
    name = (folder.name or "Unnamed").strip()
    # Top-of-folders branches are skipped from path so user doesn't see
    # "Top of Personal Folders/Inbox" — just "Inbox"
    if name.lower() in TOP_NAMES:
        path = parent_path
    else:
        path = f"{parent_path}/{name}" if parent_path else name

    try:
        n_msgs = folder.number_of_sub_messages
    except Exception:
        n_msgs = 0

    for i in range(n_msgs):
        try:
            msg = folder.get_sub_message(i)
            eml = message_to_eml(msg)
            yield path, eml
        except Exception as e:
            # One bad message shouldn't kill the whole import
            print(f"  ! skip message {i} in {path}: {e}")

    try:
        n_sub = folder.number_of_sub_folders
    except Exception:
        n_sub = 0
    for i in range(n_sub):
        try:
            sub = folder.get_sub_folder(i)
            yield from _walk(sub, path)
        except Exception as e:
            print(f"  ! skip subfolder {i} in {path}: {e}")


def message_to_eml(msg) -> bytes:
    """Convert a pypff.message into RFC-822 EML bytes."""
    headers = _get_str(msg, "transport_headers")

    if headers and "From:" in headers and "Subject:" in headers:
        # Path 1: PST has full headers — parse, append body+attachments.
        parsed = email.message_from_string(headers, policy=email.policy.default)
        eml = email.message.EmailMessage(policy=email.policy.default)
        for k, v in parsed.items():
            eml[k] = v
        _attach_body_and_files(eml, msg)
        return eml.as_bytes(policy=email.policy.default)

    # Path 2: synthesize from metadata
    eml = email.message.EmailMessage(policy=email.policy.default)
    subject = _get_str(msg, "subject") or "(no subject)"
    sender = _get_str(msg, "sender_name") or "unknown"
    sender_email = _get_str(msg, "sender_email_address") or "unknown@local"
    eml["Subject"] = subject
    eml["From"] = f'"{sender}" <{sender_email}>'
    try:
        delivery = msg.get_delivery_time()
        if delivery:
            eml["Date"] = email.utils.format_datetime(delivery)
    except Exception:
        pass
    eml["Message-ID"] = (
        f"<{hashlib.sha1((subject + sender + sender_email).encode()).hexdigest()}@pst.import>"
    )
    _attach_body_and_files(eml, msg)
    return eml.as_bytes(policy=email.policy.default)


def _attach_body_and_files(eml: email.message.EmailMessage, msg) -> None:
    """Populate body (plain/html alternative) + attachments on `eml`."""
    plain = _get_str(msg, "plain_text_body")
    html = _get_str(msg, "html_body")
    # Fallback: for items where pypff doesn't surface the body (e.g.
    # IPM.Post in some Outlook versions), scan raw MAPI record sets
    # for any string entry that looks like the body text.
    if not plain and not html:
        plain = _body_from_record_sets(msg)

    if html and plain:
        eml.set_content(plain)
        eml.add_alternative(html, subtype="html")
    elif html:
        eml.set_content(html, subtype="html")
    elif plain:
        eml.set_content(plain)
    else:
        eml.set_content("(no body)")

    try:
        n_att = msg.number_of_attachments
    except Exception:
        n_att = 0
    for i in range(n_att):
        try:
            att = msg.get_attachment(i)
            name = (att.name or f"attachment_{i}").strip() or f"attachment_{i}"
            size = att.size
            if size <= 0:
                continue
            data = att.read_buffer(size)
            ctype, _ = mimetypes.guess_type(name)
            if ctype:
                maintype, subtype = ctype.split("/", 1)
            else:
                maintype, subtype = "application", "octet-stream"
            eml.add_attachment(data, maintype=maintype, subtype=subtype,
                               filename=name)
        except Exception as e:
            print(f"  ! attachment {i} skipped: {e}")


def _body_from_record_sets(msg) -> str:
    """Fallback body extraction by scanning all string entries in the
    message's raw MAPI record sets. We prefer the longest text-looking
    entry that isn't the subject/conversation-topic/sender-name.
    """
    try:
        subject = _get_str(msg, "subject")
        sender = _get_str(msg, "sender_name")
        skip = {subject.strip(), sender.strip()}

        candidates: list[str] = []
        for rs in msg.record_sets:
            for re in rs.entries:
                try:
                    data = re.data
                    if not data or len(data) < 16:
                        continue
                    # Heuristic: must decode cleanly as UTF-8 and look
                    # like printable text (mostly ASCII letters/spaces)
                    try:
                        s = data.rstrip(b"\x00").decode("utf-8")
                    except UnicodeDecodeError:
                        continue
                    s = s.strip()
                    if not s or s in skip:
                        continue
                    # Body fields typically have at least one space or
                    # punctuation, distinguishing them from EX: addresses
                    # and GUIDs
                    if not any(c in s for c in " .,-:;?!\n"):
                        continue
                    # Skip obvious EX: / GUID / DN paths
                    if s.startswith(("EX:", "/o=", "/O=")):
                        continue
                    printable = sum(1 for c in s if c.isprintable() or c.isspace())
                    if printable / len(s) < 0.85:
                        continue
                    candidates.append(s)
                except Exception:
                    continue

        if not candidates:
            return ""
        # Pick the longest — the body is usually longer than ancillary
        # text fields like "16.0" or display names.
        return max(candidates, key=len)
    except Exception:
        return ""


def _get_str(obj, attr: str) -> str:
    """Pull a string attribute from a pypff object; return '' if missing/None."""
    try:
        v = getattr(obj, attr)
        if v is None:
            return ""
        if isinstance(v, bytes):
            return v.decode("utf-8", errors="replace")
        return str(v)
    except Exception:
        return ""
