# `userChrome.css` — Outlook visual theme reference

The 700-line file at `userChrome.css` retheme Thunderbird 152 to
visually match Microsoft Outlook (Office 365 / 2021 / Windows 11
Fluent variant). It pairs with `user.js` which sets ~150 prefs that
back the layout choices below.

Drop it at `<profile>/chrome/userChrome.css`. Requires:

```
toolkit.legacyUserProfileCustomizations.stylesheets = true
```

(set in `user.js`; `install_all.ps1` ensures it.)

## What's in it

### 1. Outlook palette + theme tokens (top)
- `--outlook-blue: #0078D4` (the main brand color)
- `--outlook-blue-dark: #106EBE`, `--outlook-blue-darker: #005A9E`
- Neutrals matching Outlook's grays
- Semantic green/amber/red
- Overrides for Mozilla theme tokens (`--toolbar-bgcolor`, `--tab-selected-bgcolor`, `--lwt-accent-color`, etc.)
- Re-themes Lightning calendar tokens (`--color-primary`, `--button-primary-background-color`)

### 2. Spaces toolbar (left rail)
- 60px wide navy gradient (`#005A9E → #106EBE`)
- White icons via `filter: brightness(0) invert(1)` (works on any TB-default icon)
- Custom hover + selected states with Outlook-blue tint
- Mail / Address Book / Calendar / Tasks / Chat / CardBook all themed

### 3. Folder pane
- "+ New Message" pill button: full-width, Outlook-blue, white text
- Folder icons: keep TB's yellow folders but slightly enlarged
- Selected folder: light Outlook-blue tint (`--outlook-blue-light`)
- Account-root rows: bold weight, larger font

### 4. Thread pane (message list)
- Cards View styling: 2-line cards with sender bold above, subject in
  outlook-blue-darker below
- 12px subject font (was 16px default); 11px preview
- 56px row height
- Unread cards: subject bumps to font-weight 700, sender remains bold
- Column header: subtle gray, no borders
- Quick Filter bar styled to match Outlook's "All / Unread" tabs

### 5. Reading pane
- Message header: sender avatar, name in bold, address in muted gray
- Reply / Reply All / Forward / Archive / Delete / More buttons styled as
  Outlook's pill button strip
- "MORE" expand button mimics Outlook's expander
- Remote-content warning banner: amber tint matching Outlook

### 6. Toolbar buttons
- All toolbar `image` icons get the white-icon filter on dark backgrounds
- `CardBook`, `quickFilters`, `ImportExport`, `Compose in tab` (composeur)
  toolbar buttons get the Outlook-pill treatment

### 7. Tab strip
- TB native tab strip: rounded tabs, Outlook-blue active indicator
- "Inbox - bk.komal@hotmail..." style with mail icon

### 8. Calendar (Lightning)
- "Calendars" header: outlook-blue
- Today highlight: light blue (`--outlook-blue-light`)
- "+ New Event" button: Outlook pill
- Mini-month calendar styled to match
- Time grid: subtle hour separators

### 9. Address Book
- Card view styled like Outlook contacts
- Group headers in outlook-blue-darker

### 10. Compose-in-tab page (composeur-en-onglet)
- Form fields styled to match Outlook's compose
- Send button: outlook-blue pill
- Toolbar pure white background

## Things to know

**`#folderPaneWriteMessage` cannot be intercepted via CSS hover handlers**
to redirect to compose-in-tab — that's a JS / experiment_api job done in
`outlookpro-compose-in-tab`. CSS only theme.

**The `#spacesToolbar` styling is sensitive to TB minor versions** — if
icons go missing after a TB update, check that `#spacesToolbar
toolbarbutton.spaces-toolbar-button image` still matches TB's current
class names.

**Cards View vs Table View font/spacing rules are scoped under**
`.thread-card-row` (cards) and `.thread-listrow` (table). Both are
themed so the visual feel stays consistent regardless of which the user
picks per-folder. `outlookpro-cards-default` makes Cards the default.

## Customizing further

Edit `userChrome.css` directly. After saving:

```powershell
# Force TB to re-read the stylesheet (it caches on startup)
Get-Process thunderbird | Stop-Process -Force
Start-Process "C:\Program Files\Mozilla Thunderbird\thunderbird.exe" -ArgumentList "-P","jitsitest","-no-remote"
```

The palette tokens at the top of the file are the most useful starting
point — change `--outlook-blue` once and the whole theme follows.
