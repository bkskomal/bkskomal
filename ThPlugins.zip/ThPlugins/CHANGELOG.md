# Changelog

All notable changes to TB-OutlookPro. Per-plugin versions are tracked
in each plugin's `manifest.json`.

## [2026-06-25 v2] +New Message regression fix (compose-in-tab v2.2)

### Fixed
- `outlookpro-compose-in-tab` **2.1.0 → 2.2.0**: +New Message button regressed (popup opened instead of tab). Root cause: TB 152's `#folderPaneWriteMessage` button lives in `about:3pane` and has its click handler wired via `addEventListener` (no declarative `oncommand`). Fix: **clone the button** (clones don't carry event listeners), replaceChild it in the DOM, then attach our handler to the clean clone. Plus expose `outlookProComposeInTab` on both the outer chrome window AND the inner `about:3pane` window.
- Also: added 3-tier delayed re-scan (3s/8s/20s) to catch about:3pane content that loads async after our startup hook.
- Per-iframe document traversal: hook now scans every `<browser>` and `<iframe>` recursively (TB 152 packs the folder pane / thread pane / message pane into separate browsers).

### Added
- File logger at `<profile>/outlookpro-cit.log` — captures every step of the compose-in-tab dispatch path. Crucial for debugging without browser console access.
- DOM-dump diagnostic that lists all candidate buttons + their `oncommand`/`onclick` attributes across all sub-documents (useful when TB changes button selectors in future versions).

## [2026-06-25] Polish pass + Phase 3 v0.2

### Added
- **Master `README.md`** at repo root explaining the full suite + install order
- **`build_all.ps1`** — packages all 7 in-house add-ons into `.xpi` files in one shot
- **`install_all.ps1`** — idempotent installer that drops XPIs into a TB profile, copies userChrome.css + user.js, sets required prefs, restarts TB
- **`LICENSE`** (MIT) at repo root
- **`CHANGELOG.md`** (this file)
- **userChrome.css README** documenting the visual customization
- **`outlookpro-mapi-http/lib/README.md`** explaining why those files are kept as reference

### Changed
- `outlookpro-mapi-http` **0.1.0 → 0.2.0**: op-aware ROP reply decoder for `RopLogon` (extracts 13 well-known folder IDs, mailbox GUID, replica IDs, store state); bundled `OpenFolder + GetHierarchyTable + SetColumns + QueryRows` pipeline; PropertyRow value decoder for PT_I2/LONG/I8/UNICODE/STRING8/BOOLEAN/BINARY/SYSTIME
- `outlookpro-compose-in-tab` **2.0.0 → 2.1.0**: +New Message button finally opens in tab (not popup). Hooks `MsgNewMessage` global, sets XUL `oncommand` via `setAttribute()`, dispatches `command` event on composeur-en-onglet's browserAction button (the only path that actually triggers `browser.tabs.create()`).
- `outlookpro-cards-default` **1.0.0 → 1.1.0**: discovered correct property name (`viewType`, not `preferredView`/`listview`) by grepping MSF files. Uses `folder.preferredLayout` setter + direct `dbFolderInfo.setCharProperty` writes. Two startup passes (+5s, +60s) catch lazy-mounted IMAP folders.
- `outlookpro-ews-calendar` **1.0.0 → 1.0.1**: real OAuth2 token bridge via `OAuth2Module.initFromHostname`. Added Options UI with form + test + sync-now + calendar list.
- `outlookpro-ews-contacts` **1.0.0 → 1.0.1**: same token bridge. Options UI with GAL live-search box.
- `pst_import.py`: `--mode imap` no longer a stub — full implementation with MSAL device-code OAuth2, SASL XOAUTH2, folder mirror, dedup by Message-ID, resumable state file.
- Deck (`TB-OutlookPro-Decision.pptx`): added slide 12 "The OutlookPro Add-on Stack" showing all 7 plugins + pst_import in a 3×3 color-coded grid. Total now 14 slides.

### Documented (READMEs added/updated)
- `outlookpro-quick-rule/README.md` (created)
- `outlookpro-compose-in-tab/README.md` (rewrote for v2.1)
- `outlookpro-cards-default/README.md` (created)
- `outlookpro-mapi-http/README.md` (updated for v0.2)
- `pst_import/README.md` (added `--mode imap` section)

### Memory persisted
- `project_outlookpro.md` updated with full add-on table + verification state
- `feedback_xul_oncommand_capture.md` (created) — the lesson from 5 failed approaches to overriding `MsgNewMessage`

---

## [2026-06-22] Initial suite ship (Phase 0 + 1 + 2 + Phase 3 v0.1)

### Added
- `outlookpro-quick-rule` 1.0.0 — right-click → Create Rule for [sender]
- `outlookpro-compose-in-tab` 1.0.0 — listen for compose popup, convert to tab (leaked popups; superseded by v2.x)
- `outlookpro-adfs-oauth` 1.0.0 — Phase 0: custom OAuth2 IdP for any TB account via `OAuth2Providers.sys.mjs` monkey-patch
- `outlookpro-ews-calendar` 1.0.0 — Phase 1: EWS SOAP client → Lightning `storage://` calendar (read-only, 5-min sync)
- `outlookpro-ews-contacts` 1.0.0 — Phase 2: EWS → TB `jsaddrbook://` (Personal + GAL)
- `outlookpro-mapi-http` 0.1.0 — Phase 3 vertical slice: HTTP transport + auth + Bind + RopLogon (no reply decoder yet)
- `pst_import/` Python CLI — PST → TB Local Folders via libpff-python-windows
- `pst_import/make_sample_pst.py` — synthetic PST builder via Outlook COM
- 13-slide stakeholder deck `TB-OutlookPro-Decision.pptx`

### Verified
- OAuth2 to outlook.office365.com (bk.komal@hotmail.com — 8,440 mails synced)
- PST → Local Folders import: 7 messages across 5 folders visible in TB UI
- All add-ons load `active: true` in TB jitsitest profile

### Documented constraints
- User runs **on-prem Exchange + ADFS** — EWS retirement (Oct 2026) does NOT affect them
- OSS license is hard requirement
- "Better than Owl for Exchange" target (Owl is the only proprietary equivalent)

---

## Earlier (May 2026 — pre-OutlookPro)

- `userChrome.css` + `user.js` developed for Outlook visual parity
- Hotmail account added via TB's native OAuth flow
- TB customization: navy spaces rail, white icons, Cards View, vertical layout
- Initial 7 third-party add-ons installed (CardBook, ImportExportTools NG, etc.)
- Profile: `jitsitest`
