# TB-OutlookPro

**MIT-licensed Thunderbird 152 customization that turns it into a
drop-in Outlook replacement for on-prem Exchange + ADFS environments.**

Built clean-room from scratch. No proprietary components. Everything
in this repo can be audited, forked, and redistributed.

## What you get

| Piece | What it does |
|---|---|
| **`userChrome.css`** + **`user.js`** | Outlook visual theme (navy spaces rail, white icons, Cards View, 12px subjects, vertical 3-pane layout) + 150 prefs tuned for Outlook parity |
| **7 in-house WebExtensions** (see below) | The functional Outlook parity layer |
| **PST import CLI** (`pst_import/`) | Bring decades of Outlook archives into TB Local Folders **OR** re-upload them to an IMAP server via OAuth2 |
| **Phase-3 native MAPI/HTTP client** (`outlookpro-mapi-http/`) | Spec-grounded implementation of Outlook's wire protocol — the only OSS attempt that exists |

## The 7 in-house add-ons

| Add-on | Ver | Status | What it does |
|---|---|---|---|
| [`outlookpro-quick-rule`](outlookpro-quick-rule/) | 1.0.1 | 🟢 shipped | Right-click message → "Create Rule for [sender]" — opens TB's native filter editor with sender pre-filled |
| [`outlookpro-compose-in-tab`](outlookpro-compose-in-tab/) | 2.1.0 | 🟢 shipped | +New Message opens in a tab (not popup). Hooks `MsgNewMessage` → dispatches command on composeur-en-onglet's browserAction button |
| [`outlookpro-cards-default`](outlookpro-cards-default/) | 1.1.0 | 🟢 shipped | All folders default to Cards View on startup. Writes `viewType` property to each folder's `dbFolderInfo`. |
| [`outlookpro-adfs-oauth`](outlookpro-adfs-oauth/) | 1.0.0 | 🟢 shipped | Custom OAuth2 IdP (ADFS, custom Azure AD app, Okta, Keycloak, anything OIDC) for ANY TB account — IMAP/SMTP/EWS/MAPI |
| [`outlookpro-ews-calendar`](outlookpro-ews-calendar/) | 1.0.1 | 🟢 read-only | Exchange calendars → Lightning `storage://`. 5-min polled sync. Token via ADFS plugin. |
| [`outlookpro-ews-contacts`](outlookpro-ews-contacts/) | 1.0.1 | 🟢 read-only | Personal Contacts + Global Address List → TB `jsaddrbook://`. Cached 30 min for Personal; live `ResolveNames` for GAL. |
| [`outlookpro-mapi-http`](outlookpro-mapi-http/) | 0.2.0 | 🟦 vertical slice | Native MAPI/HTTP — transport + Bind + Logon + op-aware reply decoder + folder list pipeline. Untested against live Exchange. |

## Third-party add-ons we depend on / bundle alongside

| Add-on | Why we ship with it |
|---|---|
| **composeur-en-onglet** (Tab Composer) | Provides the in-tab compose UI that our compose-in-tab plugin routes to |
| **CardBook** | Optional, gives a more Outlook-like contacts UX than TB's native AB |
| **ImportExportTools NG** | Optional, for EML/MBOX/HTML/PDF/CSV import/export |
| **Thunderbird Conversations** | Optional, Gmail-style threading |
| **quickFilters** | Optional, advanced filter management |
| **Sieve** | Optional, server-side filter editor for Dovecot/Cyrus IMAP |
| **TbSync** + **EAS-4-TbSync** | Optional, for Exchange ActiveSync sync (alternative to our EWS plugins) |

## Install

```powershell
# 1. Make sure TB 140+ is installed and the target profile exists.

# 2. Build all XPIs:
.\build_all.ps1

# 3. Install everything (XPIs + userChrome.css + user.js prefs):
.\install_all.ps1 -Profile jitsitest

# 4. Launch TB:
& "C:\Program Files\Mozilla Thunderbird\thunderbird.exe" -P jitsitest -no-remote
```

`install_all.ps1` handles enabling experiment APIs + disabling unsigned-add-on
enforcement (required because we use experiment APIs that aren't yet in TB's
public WebExtensions API surface).

For per-plugin install, see each add-on's individual README.

## Architecture cheat-sheet

```
                  ┌──────────────────────────────────────────────────┐
                  │      Thunderbird 152 (jitsitest profile)         │
                  │                                                  │
                  │   userChrome.css ──► Outlook visual theme        │
                  │   user.js        ──► 150 Outlook-style prefs    │
                  │                                                  │
                  │   ┌──────────────────────────────────────────┐  │
                  │   │ TB native EWS (mail) — built-in TB 145+   │  │
                  │   └─────────────┬────────────────────────────┘  │
                  │                 │ uses OAuth2 lookup            │
                  │   ┌─────────────▼────────────────────────────┐  │
                  │   │ OAuth2Providers.sys.mjs (TB internal)    │◄┼── outlookpro-adfs-oauth
                  │   │   kHostnames map mutated at startup      │  │   (your ADFS, your IdP)
                  │   └──────────────────────────────────────────┘  │
                  │                                                  │
                  │   Lightning calendar         TB Address Book     │
                  │   storage:// cals            jsaddrbook://       │
                  │        ▲                          ▲              │
                  │        │                          │              │
                  │   outlookpro-ews-calendar   outlookpro-ews-contacts
                  │        │                          │              │
                  │        ▼                          ▼              │
                  │   ╔════════════════════════════════════════════╗ │
                  │   ║       Token bridge (shared pattern)        ║ │
                  │   ║  OAuth2Module.initFromHostname(host)       ║ │
                  │   ║  50-min cache, refresh on miss             ║ │
                  │   ╚════════════════════════════════════════════╝ │
                  │                          │                       │
                  └──────────────────────────┼───────────────────────┘
                                             ▼
                            https://mail.corp.example.com/EWS/Exchange.asmx
                            https://mail.corp.example.com/mapi/emsmdb
                                       (on-prem Exchange)

  outlookpro-mapi-http (v0.2 — vertical slice):
    POST /mapi/emsmdb  Bind → Logon → OpenFolder + GetHierarchyTable
                                         + SetColumns + QueryRows

  outlookpro-quick-rule, outlookpro-compose-in-tab, outlookpro-cards-default:
    UI/UX layer — pure local TB customization, no server calls.
```

## Repository layout

```
TB-OutlookPro/
├── README.md                            # this file
├── LICENSE                              # MIT
├── CHANGELOG.md                         # what shipped per session
├── userChrome.css                       # Outlook visual theme — see README inside
├── user.js                              # 150 Outlook-style prefs
├── build_all.ps1                        # packages every plugin into .xpi
├── install_all.ps1                      # drops XPIs + CSS + prefs into a TB profile
│
├── outlookpro-quick-rule/               # 7 in-house add-ons, each self-contained
├── outlookpro-compose-in-tab/
├── outlookpro-cards-default/
├── outlookpro-adfs-oauth/
├── outlookpro-ews-calendar/
├── outlookpro-ews-contacts/
├── outlookpro-mapi-http/
│
├── pst_import/                          # Python CLI: PST → Local Folders or IMAP
│   ├── pst_import.py
│   ├── pst_reader.py
│   ├── local_writer.py
│   ├── imap_writer.py
│   └── make_sample_pst.py
│
├── build_deck.py                        # produces TB-OutlookPro-Decision.pptx
├── TB-OutlookPro-Decision.pptx          # 14-slide stakeholder deck
└── deck_preview/                        # PNG renders of each slide
```

## What's verified and what isn't

✅ **Verified end-to-end:**
- All 7 add-ons load `active: true` in TB jitsitest profile
- OAuth2 to outlook.office365.com (bk.komal@hotmail.com — 8,440 mails synced)
- PST import (local mode) — synthetic 7-message test PST, all messages visible in TB Local Folders
- Cards View default — confirmed on BK CHANDIGARH folder which was never previously toggled
- +New Message → tab — screenshot confirms no popup leaks

❌ **NOT verified:**
- ews-calendar, ews-contacts, mapi-http against a **real Exchange server** (only spec-conformance + plugin-loads checks)
- PST → IMAP upload (live) — CLI runs but the actual append flow needs a real IMAP target
- ADFS OAuth flow against an actual ADFS instance — the auto-discovery path is tested with the standard OIDC well-known doc shape

## Roadmap

- **Phase 1.1**: write-back for ews-calendar + ews-contacts (gated on real-Exchange E2E)
- **MAPI/HTTP v0.3**: `RopOpenMessage` + `RopGetPropertiesSpecific` → read a single message body
- **MAPI/HTTP v0.4**: `RopCreateMessage` + `RopSaveChangesMessage` → send mail
- **MAPI/HTTP v0.5**: `/mapi/nspi` address-book channel
- **MAPI/HTTP v1.0**: bridge into `nsIMsgFolder` so MAPI folders show in TB folder pane (replaces EWS plugins entirely)
- **Aggregated settings hub**: one Options page that surfaces all 7 plugins' status

## License

MIT © 2026 OutlookPro contributors. See `LICENSE`.
