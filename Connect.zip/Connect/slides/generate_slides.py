"""
Generates a clean light-theme .pptx deck covering the new OATIConnect
meeting-join functionality:

  * Direct join from link (web + Windows Electron) — no login
  * Encrypted vs plain share URLs
  * Password-protected meetings
  * Recurring meetings

Content sits in the middle of each slide — the top (~0.7") and bottom
(~0.5") are intentionally left blank so the presenter can drop their
own header / footer in PowerPoint without overlapping slide content.

Run:
    python generate_slides.py
Produces OATIConnect_New_Features.pptx in the same folder.
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor

# ---- Theme tokens --------------------------------------------------
# Light deck — white background, dark slate text, muted-navy accent
# (matches the dashboard's primary blue / the Electron launcher's
# button color so the slides feel on-brand without us shipping logos.)
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)
INK        = RGBColor(0x1F, 0x29, 0x37)
INK_MUTED  = RGBColor(0x6B, 0x72, 0x80)
ACCENT     = RGBColor(0x2C, 0x5D, 0xC0)
ACCENT_BG  = RGBColor(0xE7, 0xEE, 0xFA)   # very-light tint for callouts
RULE       = RGBColor(0xE5, 0xE7, 0xEB)

# ---- Slide geometry -----------------------------------------------
# 16:9 widescreen. Header band 0.7", footer band 0.5". Content area =
# middle ~6" of vertical space.
prs = Presentation()
prs.slide_width  = Inches(13.33)
prs.slide_height = Inches(7.5)

SLIDE_W = prs.slide_width
SLIDE_H = prs.slide_height
HEADER_H = Inches(0.7)    # reserved for user header
FOOTER_H = Inches(0.5)    # reserved for user footer
CONTENT_TOP    = HEADER_H
CONTENT_HEIGHT = SLIDE_H - HEADER_H - FOOTER_H
SIDE_MARGIN    = Inches(0.6)
CONTENT_W      = SLIDE_W - 2 * SIDE_MARGIN
BLANK_LAYOUT   = prs.slide_layouts[6]   # built-in "Blank"


def _set_solid_fill(shape, rgb):
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb
    shape.line.fill.background()


def add_slide():
    slide = prs.slides.add_slide(BLANK_LAYOUT)
    # White background for the whole canvas — explicit so PowerPoint
    # themes don't override.
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, SLIDE_H)
    _set_solid_fill(bg, WHITE)
    # Faint divider lines top + bottom mark the header/footer boundary
    # so the presenter sees exactly where their content can sit. Hidden
    # at print but visible in editing — comment out if you'd rather not
    # see them.
    top_rule = slide.shapes.add_connector(1, SIDE_MARGIN, HEADER_H, SLIDE_W - SIDE_MARGIN, HEADER_H)
    top_rule.line.color.rgb = RULE
    top_rule.line.width = Pt(0.75)
    bot_rule = slide.shapes.add_connector(1, SIDE_MARGIN, SLIDE_H - FOOTER_H, SLIDE_W - SIDE_MARGIN, SLIDE_H - FOOTER_H)
    bot_rule.line.color.rgb = RULE
    bot_rule.line.width = Pt(0.75)
    return slide


def add_title(slide, text, y_offset=Inches(0.1)):
    """Big slide title — sits just under the header band."""
    box = slide.shapes.add_textbox(
        SIDE_MARGIN, CONTENT_TOP + y_offset,
        CONTENT_W, Inches(0.9),
    )
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = ACCENT
    return box


def add_subtitle(slide, text, y_offset=Inches(1.0)):
    box = slide.shapes.add_textbox(
        SIDE_MARGIN, CONTENT_TOP + y_offset,
        CONTENT_W, Inches(0.5),
    )
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(18)
    p.font.color.rgb = INK_MUTED
    return box


def add_bullets(slide, items, top=Inches(1.6), height=Inches(5.0), font_size=18):
    """
    items: list of either a string (single-level bullet) or a tuple
    (string, list_of_subitems) for one level of nesting.
    """
    box = slide.shapes.add_textbox(SIDE_MARGIN, CONTENT_TOP + top, CONTENT_W, height)
    tf = box.text_frame
    tf.word_wrap = True
    first = True
    for item in items:
        if isinstance(item, tuple):
            head, subs = item
        else:
            head, subs = item, []
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.level = 0
        p.text = u"• " + head
        p.font.size = Pt(font_size)
        p.font.color.rgb = INK
        p.space_after = Pt(6)
        for sub in subs:
            sp = tf.add_paragraph()
            sp.level = 1
            sp.text = u"– " + sub
            sp.font.size = Pt(font_size - 3)
            sp.font.color.rgb = INK_MUTED
            sp.space_after = Pt(4)
    return box


def add_callout(slide, left, top, width, height, title, body, accent=True):
    """Rounded card with title + body. Used for side-by-side comparisons."""
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    card.fill.solid()
    card.fill.fore_color.rgb = ACCENT_BG if accent else WHITE
    card.line.color.rgb = ACCENT if accent else RULE
    card.line.width = Pt(1)
    # Title
    title_top = top + Inches(0.15)
    title_box = slide.shapes.add_textbox(left + Inches(0.25), title_top, width - Inches(0.5), Inches(0.4))
    tf = title_box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = ACCENT if accent else INK
    # Body
    body_box = slide.shapes.add_textbox(
        left + Inches(0.25), title_top + Inches(0.55),
        width - Inches(0.5), height - Inches(0.8),
    )
    tf = body_box.text_frame
    tf.word_wrap = True
    for i, line in enumerate(body):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.font.size = Pt(13)
        p.font.color.rgb = INK
        p.space_after = Pt(4)


def add_code_block(slide, text, top, height=Inches(1.2), font_size=12):
    """Monospaced inline-block for URLs, JSON snippets, etc."""
    box = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        SIDE_MARGIN, CONTENT_TOP + top,
        CONTENT_W, height,
    )
    box.fill.solid()
    box.fill.fore_color.rgb = RGBColor(0xF3, 0xF4, 0xF6)
    box.line.fill.background()
    tb = slide.shapes.add_textbox(
        SIDE_MARGIN + Inches(0.25), CONTENT_TOP + top + Inches(0.15),
        CONTENT_W - Inches(0.5), height - Inches(0.3),
    )
    tf = tb.text_frame
    tf.word_wrap = True
    for i, line in enumerate(text.splitlines()):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.font.name = "Consolas"
        p.font.size = Pt(font_size)
        p.font.color.rgb = INK


# =====================================================================
# Slides
# =====================================================================

# ----- Slide 1 — Title -----------------------------------------------
s = add_slide()
title = s.shapes.add_textbox(SIDE_MARGIN, CONTENT_TOP + Inches(1.4), CONTENT_W, Inches(1.4))
tf = title.text_frame
tf.word_wrap = True
p = tf.paragraphs[0]
p.text = "OATIConnect"
p.font.size = Pt(54)
p.font.bold = True
p.font.color.rgb = ACCENT
p2 = tf.add_paragraph()
p2.text = "New Meeting-Join Features"
p2.font.size = Pt(28)
p2.font.color.rgb = INK
sub = s.shapes.add_textbox(SIDE_MARGIN, CONTENT_TOP + Inches(3.2), CONTENT_W, Inches(0.6))
tf = sub.text_frame
tf.word_wrap = True
p = tf.paragraphs[0]
p.text = "Zoom-style join — without a webVision login"
p.font.size = Pt(20)
p.font.color.rgb = INK_MUTED


# ----- Slide 2 — What's new -----------------------------------------
s = add_slide()
add_title(s, "What's new")
add_subtitle(s, "Four additions that make sharing a meeting one click away.")
add_bullets(s, [
    ("Direct join from a meeting link — no host login required",
        ["Recipient gets a URL, opens it, types their name, joins the meeting."]),
    ("Encrypted vs plain share URLs",
        ["Admin toggles which format the dashboard / .ics / email body emit."]),
    ("Per-meeting password protection",
        ["Optional — guarded by an admin-level feature flag."]),
    ("Recurring meetings (Daily / Weekly / Monthly)",
        ["Single series, native RRULE in .ics, per-occurrence cancel."]),
    ("Windows desktop client — minimal Zoom-style launcher",
        ["Local UI, calls /api/v1/meetings/join-by-code, embeds the meeting."]),
])


# ----- Slide 3 — Direct Join (no login) ------------------------------
s = add_slide()
add_title(s, "Direct join — no login required")
add_subtitle(s, "Recipients click the link → type a name → land in the meeting.")
add_bullets(s, [
    ("Web flow",
        ["Open the URL in any browser → prejoin form with mic/camera preview → Join."]),
    ("Windows desktop flow",
        ["Launch the OATIConnect Join app → type the Meeting ID + name → Join."]),
    ("Server-side guardrails",
        ["Password check, host-start gate, moderator-role assignment — all enforced by the API.",
         "No anonymous shortcut to the Jitsi room; every join routes through /api/v1/meetings/join-by-code."]),
], top=Inches(1.6), height=Inches(4.5), font_size=16)


# ----- Slide 4 — Encrypted vs Plain share URLs ----------------------
s = add_slide()
add_title(s, "Encrypted vs plain share URLs")
add_subtitle(s, "Admin preference — Settings → Meeting Preferences → \"Enable encrypted meeting URL\".")

card_top    = CONTENT_TOP + Inches(1.6)
card_height = Inches(3.4)
card_width  = (CONTENT_W - Inches(0.4)) / 2
add_callout(s,
    SIDE_MARGIN, card_top, card_width, card_height,
    "Encrypted (default)",
    [
        "/oaticonnect/j/{opaque-token}",
        "",
        "Token is a data-protected ciphertext of the meeting GUID.",
        "Revocable by rotating the key.",
        "Safer to post in public channels — URL doesn't reveal the meeting code.",
    ],
    accent=True,
)
add_callout(s,
    SIDE_MARGIN + card_width + Inches(0.4), card_top, card_width, card_height,
    "Plain (off)",
    [
        "/{meeting-code}",
        "",
        "Bare 9–10 digit meeting code in the URL.",
        "Recipient can read or type the code from the URL itself.",
        "Useful when sharing in chat or printing on agendas.",
    ],
    accent=False,
)


# ----- Slide 5 — Web client share-link flow --------------------------
s = add_slide()
add_title(s, "Web client — share link join")
add_subtitle(s, "Same URL works on desktop, mobile, any modern browser.")

add_bullets(s, [
    ("Recipient lands on /oaticonnect/j/{token}   (or  /{code} for plain)"),
    ("Prejoin page",
        ["Camera / microphone preview with device pickers.",
         "Name input (saved to localStorage — prefilled on next visit).",
         "Password field appears only when the meeting has one."]),
    ("Click Join",
        ["Server issues a Jitsi JWT and embeds the meeting iframe in-page.",
         "When the meeting ends, the prejoin form returns automatically."]),
    ("Host-start gate",
        ["If the host requires it, recipients see a polite \"Waiting for host\" page that auto-resumes the moment the host starts."]),
], top=Inches(1.6), height=Inches(4.5), font_size=16)


# ----- Slide 6 — Windows Electron desktop client --------------------
s = add_slide()
add_title(s, "Windows desktop client (Electron)")
add_subtitle(s, "Local-first launcher — installs once, points at any OATIConnect server.")

card_top    = CONTENT_TOP + Inches(1.6)
card_height = Inches(3.4)
card_width  = (CONTENT_W - Inches(0.4)) / 2

add_callout(s,
    SIDE_MARGIN, card_top, card_width, card_height,
    "Minimal client (Zoom-style)",
    [
        "Renders home + settings from local HTML — paints instantly.",
        "Single-step form: Meeting ID + Password + Name + camera/mic preview.",
        "Left rail nav: Home / Settings. Light/dark theme toggle.",
        "Remembers last name + last 5 meeting IDs.",
        "Window maximises during meeting, restores on leave.",
    ],
    accent=True,
)
add_callout(s,
    SIDE_MARGIN + card_width + Inches(0.4), card_top, card_width, card_height,
    "Full client (dashboard)",
    [
        "Same as the web dashboard, wrapped in an Electron window.",
        "Schedule meetings, manage prefs, participate as host.",
        "Uses the same OATIConnect API.",
    ],
    accent=False,
)


# ----- Slide 7 — Password-protected meetings ------------------------
s = add_slide()
add_title(s, "Password-protected meetings")
add_subtitle(s, "Optional — gated by an admin-level preference.")
add_bullets(s, [
    ("Two-step opt-in",
        ["Admin enables \"Enable meeting password\" in Meeting Preferences.",
         "Host sets a per-meeting password while creating the meeting."]),
    ("End-to-end protection",
        ["Stored encrypted at rest via IDataProtector.",
         "Decrypted server-side only to validate joins and lock the Jitsi room.",
         "Plaintext leaves the server only in the invitation email body."]),
    ("Recipient experience",
        ["Prejoin form asks for the password before issuing the JWT.",
         "Wrong password = inline error, name preserved, no retype."]),
    ("Sharing",
        ["Email body and .ics description both include the password.",
         "Generated link itself stays opaque — no password in the URL."]),
], top=Inches(1.6), height=Inches(4.7), font_size=15)


# ----- Slide 8 — Recurring meetings ---------------------------------
s = add_slide()
add_title(s, "Recurring meetings")
add_subtitle(s, "Daily / Weekly / Monthly — single series, native calendar handling.")
add_bullets(s, [
    ("Schedule page recurrence panel",
        ["None / Daily / Weekly (with weekday picker) / Monthly.",
         "Every-N-units interval. End condition: never / after N / on date.",
         "Live human-readable summary (\"Weekly · Mon, Wed, Fri\")."]),
    ("Per-occurrence cancel",
        ["Delete on a recurring row prompts: cancel this occurrence vs delete entire series.",
         "Cancelled instances stored in OATIConnectMeetingOccurrenceExceptions; next-occurrence math skips them."]),
    ("Native calendar integration",
        [".ics carries an RFC 5545 RRULE — Outlook / Google / Apple Calendar expand the series themselves.",
         "Email body shows the recurrence label (\"Daily, ends after 10\")."]),
    ("Timeline UX",
        ["List shows the next live occurrence, not the original start.",
         "Next-occurrence cursor advances automatically as time passes."]),
], top=Inches(1.6), height=Inches(4.7), font_size=15)


# ----- Slide 9 — Summary / where to configure -----------------------
s = add_slide()
add_title(s, "Summary")
add_subtitle(s, "Everything new lives behind admin-controlled preferences — opt in per deployment.")
add_bullets(s, [
    ("Settings → Meeting Preferences",
        ["Enable meeting password.",
         "Require host to start meeting (Zoom-style waiting page).",
         "Enable encrypted meeting URL (on = opaque token; off = plain code)."]),
    ("Settings → App Settings",
        ["OATIConnect_Configs holds App:Name, Jitsi:ServerBaseUrl, App:WebAppUrl, etc."]),
    ("Sidecar oaticonnect_config.json",
        ["OATIConnect.App.WebAppUrl pins the host URL for outbound emails + .ics."]),
    ("Two Windows installers",
        ["dist/electron-clients/full/OATIConnect-Setup-1.0.0.exe — dashboard.",
         "dist/electron-clients/minimal/OATIConnect-Setup-1.0.0.exe — Zoom-style join client."]),
], top=Inches(1.6), height=Inches(4.7), font_size=15)


# ----- Output --------------------------------------------------------
import os
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "OATIConnect_New_Features.pptx")
prs.save(out)
print("Wrote " + out)
