# OATIConnect — Project Backup & Setup Guide

> **Backup created:** 2026-06-09 · Source: `I:\Jitsi\9\OATIConnect`
> **Version line:** 2.2.6.0 (see `dist/RELEASE-2.2.6.0.md`)
> This is a **clean, portable backup**. Regenerable/machine-specific folders were
> intentionally excluded (`node_modules`, `bin`, `obj`, `dist-electron`, `publish`,
> `.vs`, `.vscode`). They are recreated by the setup steps below.

---

## 1. What OATIConnect is

OATIConnect is a **Jitsi-based meetings product** (Zoom/Teams-style) built to run two ways:

1. **Standalone web app** — a self-contained ASP.NET Core host (`OATIConnect.Client`)
   that serves a React UI and its own API, backed by SQL Server / PostgreSQL / MySQL.
2. **Embedded integration** — the same engine shipped as a **single class-library DLL**
   (`OATIConnect.API.dll`) plus a **web-component bundle** (`oaticonnect.mjs`), dropped
   into a host app (e.g. **OATI Hub / WebVision**). The host owns identity + the database;
   OATIConnect plugs in via two small adapters. This drop lives in `dist/`.

### Core functionality
- **Schedule meetings** — title, date/time, duration, password, host-start gating, recurrence
  (daily/weekly/monthly with end conditions).
- **Join flows** — numeric Meeting ID + password, one-click share links (plain or encrypted
  token), and a generic "web client" join page.
- **Jitsi embedding** — loads `external_api.js` from the Jitsi server using a **JWT** the
  server signs with the Jitsi private key. Host-start presence gating prevents the first
  guest from becoming moderator.
- **Invitations** — three sharing surfaces that all render identical content:
  server-sent email, downloadable **`.ics`** calendar file, and a client-side
  **share-via-email** (mailto). All render times in the **logged-in user's timezone**.
- **Admin settings** — app config, meeting preferences, Exchange/directory lookup,
  password/host-start feature toggles (role-gated: Admin vs Standard).
- **Desktop clients** — Electron launcher apps (full + minimal "join-only"), see
  `electron-clients/` and `server/OATIConnect.Client/Client/electron/`.

---

## 2. Technology stack

| Layer | Tech |
|---|---|
| Server | **.NET 8** (ASP.NET Core). `OATIConnect.API` is a persistence-agnostic class library. |
| Client | **React 19 + TypeScript 5.9 + Vite 7**, package manager **pnpm**. |
| Web component | Same React app compiled to a Shadow-DOM custom element `<oaticonnect-meet>` (`oaticonnect.mjs`). |
| Database | EF Core — **SQL Server** (default), **PostgreSQL**, or **MySQL**. (Host owns the DB in integration mode.) |
| Meetings | **Jitsi** (`external_api.js` + JWT auth). Default server `qa.meet.oati.com`, AppId `oaticonnect`. |
| Desktop | **Electron** (electron-builder) — full and minimal installers. |

---

## 3. Folder structure (this backup)

```
Connect/
├── README.md                      ← this file
├── OATIConnect.sln                ← Visual Studio solution
├── build.ps1                      ← STANDALONE build → ./publish (SPA + web component + .NET publish)
├── build-oaticonnect.ps1          ← INTEGRATION build → ./dist (DLL + oaticonnect.mjs + adapters + guide)
├── client.ps1 / server.ps1        ← granular client / server build helpers
├── DEPLOYMENT.md                  ← standalone deployment guide (DB providers, IIS sub-paths)
│
├── server/
│   ├── OATIConnect.API/           ← ★ core engine: meetings, calendar/.ics, Jitsi JWT, settings.
│   │                                 NO EF dependency — talks to DB via IOATIConnectRepository.
│   │   └── Meetings/              ← MeetingService, MeetingCalendarService (.ics), InvitationHtmlBuilder
│   ├── OATIConnect.Client/        ← ★ ASP.NET host (standalone). Program.cs, wwwroot, dev login.
│   │   └── Client/                ← ★ React/Vite SPA + web component source (pnpm project)
│   │       ├── src/               ← UI: pages/, components/, contexts/, api/, utils/
│   │       └── electron/          ← Electron launcher (main/preload/dev-launcher)
│   ├── OATIConnect.EntityFramework/  ← EF Core DbContext + migrations (standalone DB)
│   └── OATIConnect.Server/        ← repository implementation wiring the API to EF (standalone)
│
├── dist/                          ← ★ INTEGRATION DROP (the "CD") — ready to hand to a host app
│   ├── server/OATIConnect.API.dll ← the engine as one DLL
│   ├── client/oaticonnect.mjs     ← web component bundle (CSS embedded in Shadow DOM)
│   ├── templates/                 ← host adapter samples (identity + data provider) + APIFiles
│   ├── extjs/                     ← ExtJS/Sencha glue for OATI Hub (OATIConnectView.js)
│   ├── migrations/                ← SQL for the host DB (SqlServer + Postgres)
│   ├── config/                    ← oaticonnect_config.sample.json, jitsi key sample
│   └── INTEGRATE.md               ← ★ step-by-step host integration guide (READ THIS for OATI Hub)
│
├── dist-templates/                ← SOURCES the build-oaticonnect.ps1 copies into dist/
│                                     (edit adapters / APIFiles / extjs here, not in dist/)
├── electron-clients/              ← packaged desktop client assets
├── samples/SampleHostApp/         ← minimal example host that embeds the DLL + web component
├── DeployAI/, hashtool/, slides/  ← auxiliary tooling / docs
```

★ = the parts you'll touch most.

---

## 4. Prerequisites (target machine)

- **.NET 8 SDK** — https://dotnet.microsoft.com/download/dotnet/8.0
- **Node.js 18+** and **pnpm** (`npm i -g pnpm`)
- **PowerShell 7+** (for the build scripts)
- A database for standalone mode: **SQL Server** (default), or PostgreSQL / MySQL
- (Optional) A **Jitsi** server + its **private key** for real meetings
- (Optional, desktop) nothing extra — electron-builder pulls what it needs

---

## 5. First-time setup on a new machine

```powershell
# 0. Copy this backup folder to the new machine, e.g. C:\Apps\OATIConnect

# 1. Restore frontend dependencies (recreates node_modules)
cd <root>\server\OATIConnect.Client\Client
pnpm install

# 2. Restore .NET dependencies
cd <root>
dotnet restore OATIConnect.sln
```

### Run the standalone app (dev)
```powershell
cd <root>\server\OATIConnect.Client
dotnet run --urls "http://localhost:5205"
# Browse http://localhost:5205/login  → enter any positive numeric userId to sign in (dev auth).
```
The dev login lets you set a timezone (e.g. `Central Standard Time`, `IST`) so invite
times render in that zone.

### Build the standalone deployment artifact
```powershell
cd <root>
.\build.ps1                              # → .\publish  (root deployment, SQL Server)
.\build.ps1 -BasePath "/oaticonnect"     # IIS sub-app
.\build.ps1 -DbProvider "Postgres"       # or MySql
```
`build.ps1` builds the SPA **and** the meeting web-component, copies the bundle into
`wwwroot/meet/`, publishes the .NET host, and injects `App:BasePath` / `Database:Provider`
into the published `appsettings.json`. Deploy the contents of `.\publish`.
Full DB-provider + IIS details: **`DEPLOYMENT.md`**.

### Build the integration drop (for OATI Hub / any host app)
```powershell
cd <root>
.\build-oaticonnect.ps1                  # → .\dist
```
Then follow **`dist/INTEGRATE.md`**. In short: the host references
`dist/server/OATIConnect.API.dll`, serves `dist/client/oaticonnect.mjs` as a static asset,
implements two adapters (identity + data provider — samples in `dist/templates/`), and
calls `services.AddOATIConnect()` + `app.MapOATIConnect()`.

---

## 6. Configuration

**Standalone:** `server/OATIConnect.Client/appsettings.json`
- `App:BasePath` — "" for root, `/oaticonnect` for an IIS sub-app
- `Database:Provider` — `SqlServer` | `Postgres` | `MySql`, plus the matching connection string
- Jitsi server URL, AppId, and private-key path

**Integration (sidecar):** rename `dist/config/oaticonnect_config.sample.json` to
`oaticonnect_config.json` and drop it next to the host executable. It carries Jitsi + email
settings. The **database lives in the host** (via the data-provider adapter), not here.

**Jitsi key:** put your real `jitsi-private-key.pem` next to the host executable and point
`Jitsi.PrivateKeyFile` at it. (Only the `.sample` placeholder is in this backup.)

---

## 7. ⚠️ Integration gotcha — invite times & timezone

OATIConnect renders the `.ics` and email invitation **server-side** (no browser), so the
**only** source of the user's timezone is what the host's identity adapter puts on
`ExternalUserInfo`. **If the adapter leaves `TimeZoneWindows`/`TimeZoneIana` blank, every
invitation falls back to UTC.**

The host's `OATIMeetSessionAdapter` must populate them from the host user's zone. For OATI
Hub/WebVision that value is the same `CallingUser.Timezone` the other controllers use; the
DLL ships `TimeZoneMapper.ToIana()` / `ToWindows()` to convert it:

```csharp
var shortTz = UserManagerRepository.RetrieveUser()?.Timezone;   // e.g. "IST", "CST"
new ExternalUserInfo(
    Id, Name, Email, Role, IsActive: true,
    TimeZoneWindows: TimeZoneMapper.ToWindows(shortTz),
    TimeZoneIana:    TimeZoneMapper.ToIana(shortTz));
```
See `dist/INTEGRATE.md` ("Timezone is mandatory") and
`dist/templates/OATIMeetSessionAdapter.cs.sample`.

---

## 8. Recent fixes included in this backup (2026-06)

- **Duplicate-meeting / .ics fix** — scheduling the same title + start time now **updates**
  the existing meeting instead of creating a duplicate (stable `.ics` UID → calendars
  override, not duplicate). Added a monotonic `SEQUENCE` so updates are honored.
- **Timezone in invitations** — `.ics` + server email + client share-via-email now show the
  **logged-in user's timezone by name** (e.g. "India Standard Time"), not a bare `GMT-5`
  offset; the `.ics` event (`DTSTART;TZID` + `VTIMEZONE`) is tagged with that zone. Create,
  edit, and download paths all carry the zone.
- **`build.ps1` web-component step** — the master build now (re)builds and copies the meeting
  bundle into `wwwroot/meet/`, so a fresh build never ships without the in-meeting view.
- **Integration timezone** — the host adapter sample + `INTEGRATE.md` now show how to supply
  the user's timezone (the root cause of the "integrated app shows UTC" issue).

---

## 9. Notes

- **Not under version control.** This project is **not** a git repository and has no GitHub
  remote — this backup folder is the source of truth. Consider `git init` on the new machine.
- **Excluded from backup (regenerate on setup):** `node_modules` (`pnpm install`),
  `bin`/`obj` (`dotnet build`), `dist-electron` & `publish` (build scripts), `.vs`/`.vscode`.
- **Two build outputs, don't confuse them:** `build.ps1` → `publish/` (standalone web app);
  `build-oaticonnect.ps1` → `dist/` (integration DLL + web component drop).
- **Default dev port:** `http://localhost:5205` (HTTP), `https://localhost:5206` (HTTPS).
