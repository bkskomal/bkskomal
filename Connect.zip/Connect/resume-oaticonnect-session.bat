@echo off
cd /d I:\Jitsi\OATIMeet\server\Meet.API\Client
claude --resume 515846b4-ddca-4054-a87c-d66fa5d36bec
