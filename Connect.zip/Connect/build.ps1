﻿# ============================================
# Master Build Script - OATIMeetAI
# Builds frontend, runs tests, publishes backend
#
# Usage:
#   .\build.ps1                                          # root deployment, SqlServer (default)
#   .\build.ps1 -BasePath "/oaticonnect"                 # IIS sub-app at /oaticonnect
#   .\build.ps1 -DbProvider "Postgres"                   # use PostgreSQL
#   .\build.ps1 -DbProvider "MySql"                      # use MySQL
#   .\build.ps1 -BasePath "/oaticonnect" -DbProvider "Postgres"
#   .\build.ps1 -SkipTests                               # skip the test step
# ============================================

param(
    [string]$BasePath = "",
    [ValidateSet("SqlServer", "Postgres", "MySql", "")]
    [string]$DbProvider = "",
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"

$PublishDir = "./publish"
$ClientDir        = "./server/OATIConnect.Client/Client"
$TestDir          = ""  # no test project in this repo
$ApiProject       = "./server/OATIConnect.Client/OATIConnect.Client.csproj"
$WwwrootDir       = "./server/OATIConnect.Client/wwwroot"
$AppSettingsPath  = "./server/OATIConnect.Client/appsettings.json"
$PublishedAppSettings = Join-Path $PublishDir "appsettings.json"

function Write-Step($step, $message) {
    Write-Host "`n=====================================" -ForegroundColor Cyan
    Write-Host " Step $step : $message" -ForegroundColor Cyan
    Write-Host "=====================================" -ForegroundColor Cyan
}

function Get-DirectorySize($path) {
    if (Test-Path $path) {
        $size = (Get-ChildItem $path -Recurse -File | Measure-Object -Property Length -Sum).Sum
        if ($size -gt 1MB) { return "{0:N2} MB" -f ($size / 1MB) }
        if ($size -gt 1KB) { return "{0:N2} KB" -f ($size / 1KB) }
        return "$size bytes"
    }
    return "N/A"
}

try {
    $startTime = Get-Date
    Write-Host "`nStarting Full Build..." -ForegroundColor Cyan
    Write-Host "Time: $startTime"

    # Normalise base path
    $effectiveBase = $BasePath
    if ([string]::IsNullOrWhiteSpace($effectiveBase)) {
        $vitePathForBuild = "/"
        $aspNetBasePath = ""
    }
    else {
        # Strip trailing slash for ASP.NET, ensure trailing slash for Vite
        $aspNetBasePath = $effectiveBase.TrimEnd('/')
        if (-not $aspNetBasePath.StartsWith('/')) { $aspNetBasePath = "/$aspNetBasePath" }
        $vitePathForBuild = "$aspNetBasePath/"
    }

    Write-Host "Deployment base path : '$aspNetBasePath' (Vite base: '$vitePathForBuild')" -ForegroundColor Cyan

    # ------------------------------------------
    # Clean previous publish
    # ------------------------------------------
    if (Test-Path $PublishDir) {
        Write-Host "`nCleaning previous publish directory..." -ForegroundColor Yellow
        Remove-Item $PublishDir -Recurse -Force
    }

    # ------------------------------------------
    # Step 1: Build Frontend
    # ------------------------------------------
    Write-Step 1 "Build Frontend (pnpm + Vite)"

    Push-Location $ClientDir
    try {
        Write-Host "Installing dependencies..." -ForegroundColor Yellow
        pnpm install
        if ($LASTEXITCODE -ne 0) { throw "pnpm install failed with exit code $LASTEXITCODE" }

        Write-Host "Building React app with VITE_BASE_PATH=$vitePathForBuild ..." -ForegroundColor Yellow
        $env:VITE_BASE_PATH = $vitePathForBuild
        try {
            pnpm build
            if ($LASTEXITCODE -ne 0) { throw "pnpm build failed with exit code $LASTEXITCODE" }

            # Meeting web component. The SPA build above runs with Vite
            # emptyOutDir=true and WIPES wwwroot/ — so the meeting bundle
            # must be (re)built and copied in AFTER it, or the published
            # app serves the launcher but 404s on the in-meeting view.
            # The wc Vite config emits dist-wc/oaticonnect.mjs; the runtime
            # loads it from /meet/oaticonnect-meet.mjs (note the rename).
            Write-Host "Building meeting web component (pnpm build:wc)..." -ForegroundColor Yellow
            pnpm build:wc
            if ($LASTEXITCODE -ne 0) { throw "pnpm build:wc failed with exit code $LASTEXITCODE" }

            $meetDir = "..\wwwroot\meet"
            if (-not (Test-Path $meetDir)) { New-Item -ItemType Directory -Path $meetDir -Force | Out-Null }
            Copy-Item "dist-wc\oaticonnect.mjs" "$meetDir\oaticonnect-meet.mjs" -Force
            Write-Host "Meeting web component -> wwwroot/meet/oaticonnect-meet.mjs" -ForegroundColor Green
        }
        finally {
            Remove-Item Env:VITE_BASE_PATH -ErrorAction SilentlyContinue
        }
    }
    finally {
        Pop-Location
    }

    if (-not (Test-Path $WwwrootDir)) {
        throw "Frontend build output not found at $WwwrootDir"
    }

    $frontendFiles = (Get-ChildItem $WwwrootDir -Recurse -File).Count
    Write-Host "Frontend build complete: $frontendFiles files in wwwroot" -ForegroundColor Green

    # ------------------------------------------
    # Step 2: Run Tests
    # ------------------------------------------
    Write-Step 2 "Run Tests"

    if ($SkipTests) {
        Write-Host "Skipped (-SkipTests flag set)." -ForegroundColor Yellow
    }
    elseif ($TestDir -and (Test-Path $TestDir)) {
        dotnet test $TestDir --verbosity minimal
        if ($LASTEXITCODE -ne 0) { throw "Tests failed with exit code $LASTEXITCODE" }
        Write-Host "All tests passed." -ForegroundColor Green
    }
    else {
        Write-Host "No test project found at $TestDir - skipping." -ForegroundColor Yellow
    }

    # ------------------------------------------
    # Step 3: Publish Backend
    # ------------------------------------------
    Write-Step 3 "Publish Backend (.NET)"

    dotnet publish $ApiProject -c Release -o $PublishDir
    if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed with exit code $LASTEXITCODE" }

    Write-Host "Backend publish complete." -ForegroundColor Green

    # ------------------------------------------
    # Step 4: Inject App:BasePath and Database:Provider into published appsettings.json
    # ------------------------------------------
    Write-Step 4 "Configure published appsettings (App:BasePath='$aspNetBasePath', Database:Provider='$DbProvider')"

    if (Test-Path $PublishedAppSettings) {
        # Use surgical regex edits instead of ConvertFrom-Json/ConvertTo-Json round-trip,
        # because the round-trip double-escapes embedded backslashes (e.g. the Jitsi
        # PrivateKey has \\n sequences that would become \\\\n on disk after re-serialization,
        # corrupting the PEM at runtime).
        $jsonText = Get-Content $PublishedAppSettings -Raw

        # --- Patch App:BasePath ---
        $escapedBasePath = $aspNetBasePath -replace '\\', '\\'
        if ($jsonText -match '"BasePath"\s*:\s*"[^"]*"') {
            $jsonText = [regex]::Replace($jsonText, '"BasePath"\s*:\s*"[^"]*"', '"BasePath": "' + $escapedBasePath + '"')
        }
        elseif ($jsonText -match '"App"\s*:\s*\{') {
            # Insert BasePath into the App object
            $jsonText = [regex]::Replace($jsonText, '("App"\s*:\s*\{)', '$1' + "`n    `"BasePath`": `"$escapedBasePath`",")
        }

        # --- Patch Database:Provider (only if -DbProvider was passed) ---
        if (-not [string]::IsNullOrWhiteSpace($DbProvider)) {
            if ($jsonText -match '"Database"\s*:\s*\{[^}]*"Provider"\s*:\s*"[^"]*"') {
                $jsonText = [regex]::Replace($jsonText, '("Database"\s*:\s*\{[^}]*"Provider"\s*:\s*)"[^"]*"', '$1"' + $DbProvider + '"')
                Write-Host "Database:Provider set to '$DbProvider'" -ForegroundColor Green
            }
        }

        Set-Content $PublishedAppSettings -Value $jsonText -Encoding UTF8 -NoNewline
        Write-Host "App:BasePath set to '$aspNetBasePath' in $PublishedAppSettings" -ForegroundColor Green
    }
    else {
        Write-Host "Warning: $PublishedAppSettings not found - skipping config injection" -ForegroundColor Yellow
    }

    # ------------------------------------------
    # Summary
    # ------------------------------------------
    $endTime = Get-Date
    $duration = $endTime - $startTime

    Write-Host "`n=====================================" -ForegroundColor Green
    Write-Host " BUILD SUCCEEDED" -ForegroundColor Green
    Write-Host "=====================================" -ForegroundColor Green
    Write-Host "  Duration       : $($duration.ToString('mm\:ss'))"
    Write-Host "  Base path      : '$aspNetBasePath'  (use '' for root deployment)"
    Write-Host "  Frontend files : $frontendFiles ($(Get-DirectorySize $WwwrootDir))"
    Write-Host "  Publish dir    : $PublishDir ($(Get-DirectorySize $PublishDir))"
    Write-Host "  Artifacts      : $(Resolve-Path $PublishDir)"
    Write-Host ""
    if ($aspNetBasePath) {
        Write-Host "IIS deployment notes:" -ForegroundColor Cyan
        Write-Host "  1. In IIS Manager, add an Application under your site"
        Write-Host "     - Alias        : $($aspNetBasePath.TrimStart('/'))"
        Write-Host "     - Physical path: $(Resolve-Path $PublishDir)"
        Write-Host "     - App pool     : .NET 8 (or No Managed Code if self-contained)"
        Write-Host "  2. Browse to https://localhost$aspNetBasePath/"
        Write-Host ""
    }
}
catch {
    Write-Host "`n=====================================" -ForegroundColor Red
    Write-Host " BUILD FAILED" -ForegroundColor Red
    Write-Host "=====================================" -ForegroundColor Red
    Write-Host "Error: $_" -ForegroundColor Red
    Write-Host "At: $($_.InvocationInfo.ScriptLineNumber)" -ForegroundColor Red
    exit 1
}


