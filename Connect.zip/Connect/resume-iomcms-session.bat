@echo off
cd /d I:\Jitsi\OATIMeetAI
claude --resume 6ef00e5e-1d73-4851-8413-2b2668a8fb63
pause
