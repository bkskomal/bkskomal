# OATIMeetAI — Deployment Guide

This app supports **SQL Server**, **PostgreSQL**, and **MySQL** out of the box,
and can be deployed at the root of a domain or under any IIS / nginx sub-path.

---

## 1. Quick reference

```powershell
# Local dev (root, SQL Server)
.\build.ps1

# IIS sub-app at /oaticonnect, SQL Server
.\build.ps1 -BasePath "/oaticonnect"

# IIS sub-app, PostgreSQL backend
.\build.ps1 -BasePath "/oaticonnect" -DbProvider "Postgres"

# IIS sub-app, MySQL backend
.\build.ps1 -BasePath "/oaticonnect" -DbProvider "MySql"

# Skip tests
.\build.ps1 -BasePath "/oaticonnect" -SkipTests
```

After build → contents of `./publish` are ready to deploy.

---

## 2. Database providers

| Provider    | Database.Provider value | Connection string example |
|-------------|------------------------|---------------------------|
| SQL Server  | `SqlServer` (default)  | `Data Source=SERVER;Initial Catalog=oaticonnect;Integrated Security=True;Encrypt=False;TrustServerCertificate=True` |
| PostgreSQL  | `Postgres`             | `Host=localhost;Port=5432;Database=oaticonnect;Username=postgres;Password=postgres` |
| MySQL       | `MySql`                | `Server=localhost;Port=3306;Database=oaticonnect;User=root;Password=root` |

### Migrations & multi-provider

EF Core stores ONE `ModelSnapshot` per migrations assembly, so switching providers
requires regenerating migrations against the target provider. The repo ships with
migrations for **SQL Server** under `server/OATIConnect.Infrastructure/Migrations/SqlServer/`.

**To deploy against PostgreSQL or MySQL:**

```powershell
# 1. Delete existing SqlServer migrations
Remove-Item -Recurse -Force server/OATIConnect.Infrastructure/Migrations/SqlServer

# 2. Generate fresh migrations for the target provider
$env:EF_PROVIDER="Postgres"   # or "MySql"
dotnet ef migrations add InitialCreate `
    -o Migrations/Postgres `
    --project server/OATIConnect.Infrastructure `
    --startup-project server/OATIConnect.API
Remove-Item Env:EF_PROVIDER

# 3. Build & deploy
.\build.ps1 -DbProvider "Postgres"
```

The seed data (`General` group + `admin@admin.com` user) is defined in
`AppDbContext.OnModelCreating` via `HasData()`, so it's portable across providers
and gets baked into whichever migration you generate.

---

## 3. Sub-path hosting (IIS / nginx)

The Vite frontend bakes the deployment base path into `index.html` at build time.
The ASP.NET backend uses `App:BasePath` from `appsettings.json` (set automatically
by `build.ps1 -BasePath`) to call `app.UsePathBase()`.

**These two MUST match.** The build script enforces this by writing both from the
same `-BasePath` value.

### IIS setup

1. **Stop the app pool first** (so you can copy files over a previous deployment).
   ```powershell
   Stop-WebAppPool -Name "DefaultAppPool"
   ```

2. **Build & publish:**
   ```powershell
   .\build.ps1 -BasePath "/oaticonnect"
   ```

3. **Copy `./publish` contents** to your IIS site folder (e.g.
   `C:\inetpub\sites\meet\oaticonnect\`).

4. **In IIS Manager:**
   - Add an **Application** under your site
   - **Alias**: `oaticonnect` (no leading slash)
   - **Application pool**: any pool with **.NET CLR version = No Managed Code**
   - **Physical path**: the folder you copied to

5. **Grant the app pool identity SQL access** (one-time, for SQL Server):
   ```sql
   USE master;
   CREATE LOGIN [IIS APPPOOL\DefaultAppPool] FROM WINDOWS;
   USE oaticonnect;
   CREATE USER [IIS APPPOOL\DefaultAppPool] FOR LOGIN [IIS APPPOOL\DefaultAppPool];
   ALTER ROLE db_owner ADD MEMBER [IIS APPPOOL\DefaultAppPool];
   ```

6. **Start the app pool & browse:**
   ```powershell
   Start-WebAppPool -Name "DefaultAppPool"
   # → https://your-host/oaticonnect/
   ```

### nginx example

```nginx
location /oaticonnect/ {
    proxy_pass         http://localhost:5000/;   # trailing slash strips the prefix
    proxy_http_version 1.1;
    proxy_set_header   Host $host;
    proxy_set_header   Upgrade $http_upgrade;
    proxy_set_header   Connection "upgrade";
    proxy_set_header   X-Forwarded-Proto $scheme;
    proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
}
```

For nginx you do NOT need `App:BasePath` set (nginx strips the prefix before
forwarding), but you DO need to build the client with `-BasePath "/oaticonnect"`
so the asset URLs include the prefix.

---

## 4. Production checklist

- [ ] **Strong JWT key**: replace `Jwt:Key` with a 32+ char random secret
- [ ] **Strong admin password**: log in as `admin@admin.com` / `Oati@1234` then change it immediately
- [ ] **Production Jitsi private key**: replace `Jitsi:PrivateKey` with your real key
- [ ] **Database credentials**: use a SQL login (not Windows auth) with least-privilege
- [ ] **HTTPS only**: configure IIS bindings / nginx for TLS, redirect HTTP → HTTPS
- [ ] **CORS**: set `AllowedOrigins` in `appsettings.Production.json` to your real frontend URL
- [ ] **Logging**: keep at `Warning` level in production (already configured)
- [ ] **SMTP**: configure email settings via Settings → App Settings tab so password reset works
- [ ] **Firewall**: open only the IIS/nginx port; SQL/Postgres/MySQL should be on a private network

---

## 5. Default seeded data

On first run against an empty database, the migration seeds:

- **Group**: `General` (id `00000000-0000-0000-0000-000000000001`)
- **Admin user**: `admin@admin.com` / `Oati@1234`

The admin user is in the General group and has the `Admin` role.

**Change the admin password immediately after first login.**
