﻿using OATIConnect.API.Settings;
using OATIConnect.API.Domain.Entities;
using System.Globalization;

namespace OATIConnect.API.Settings;

public class AppSettingsService : IAppSettingsService
{
    private const string PrefPrefix = "Pref:";

    private static readonly string[] ToolbarButtons =
    {
        "Microphone", "Camera", "Screenshare", "Chat", "RaiseHand",
        "Participants", "TileView", "ToggleCamera", "Hangup", "Profile",
        "Invite", "Settings", "Fullscreen", "Security", "ClosedCaptions",
        "Recording", "LiveStreaming", "ShareVideo", "ShareAudio",
        "NoiseSuppression", "Whiteboard", "Etherpad", "SelectBackground",
        "Help", "Filmstrip"
    };

    private readonly IOATIConnectExternalAPI _data;

    public AppSettingsService(IOATIConnectExternalAPI api)
    {
        _data = api;
    }

    public async Task<IReadOnlyList<AppConfigDto>> GetAllAsync()
    {
        var rows = await _data.GetAllAppConfigsAsync();
        return rows
            .OrderBy(x => x.Category).ThenBy(x => x.Key)
            .Select(x => new AppConfigDto(x.Key, x.Value, x.Description, x.Category))
            .ToList();
    }

    public async Task<AppConfigDto?> GetByKeyAsync(string key)
    {
        var row = await _data.GetAppConfigByKeyAsync(key);
        return row is null ? null : new AppConfigDto(row.Key, row.Value, row.Description, row.Category);
    }

    public async Task<AppConfigDto> UpsertAsync(UpsertAppConfigCommand command)
    {
        var saved = await _data.UpsertAppConfigAsync(new AppConfig
        {
            Key         = command.Key,
            Value       = command.Value,
            Description = command.Description,
            Category    = command.Category,
        });
        return new AppConfigDto(saved.Key, saved.Value, saved.Description, saved.Category);
    }

    public async Task<MeetingPreferencesDto> GetMeetingPreferencesAsync()
    {
        var all = await _data.GetAllAppConfigsAsync();
        var rows = all
            .Where(x => x.Key.StartsWith(PrefPrefix, StringComparison.Ordinal))
            .ToDictionary(x => x.Key, x => x.Value);

        var dto = new MeetingPreferencesDto
        {
            DefaultCameraOn        = ParseBool(rows, "Pref:Camera:Default",            true),
            DefaultMicOn           = ParseBool(rows, "Pref:Microphone:Default",        true),
            DefaultDurationMinutes = ParseInt (rows, "Pref:Meeting:DefaultDuration",   60),
            MeetingNameMode        = rows.GetValueOrDefault("Pref:Meeting:NameMode")  ?? "auto",
            EnableMeetingPassword  = ParseBool(rows, "Pref:Meeting:EnablePassword",    true),
            RequireHostStart       = ParseBool(rows, "Pref:Meeting:RequireHostStart",  true),
            EncryptedShareLink     = ParseBool(rows, "Pref:Meeting:EncryptedShareLink", true),
            EmbedPasswordInLink    = ParseBool(rows, "Pref:Meeting:EmbedPasswordInLink", true),
            RecurringMaxDurationDays = ParseInt (rows, "Pref:Recurring:MaxDurationDays",  90),
            WebClientUrl           = rows.GetValueOrDefault("Pref:Meeting:WebClientUrl") ?? "",

            DisablePreJoinPage     = ParseBool(rows, "Pref:Jitsi:DisablePreJoinPage",     false),
            AudioOnly              = ParseBool(rows, "Pref:Jitsi:AudioOnly",              false),
            StartWithAudioMuted    = ParseBool(rows, "Pref:Jitsi:StartWithAudioMuted",    false),
            StartWithCameraOff     = ParseBool(rows, "Pref:Jitsi:StartWithCameraOff",     false),
            DisableFaceCentering   = ParseBool(rows, "Pref:Jitsi:DisableFaceCentering",   false),
            DisableTileEnlargement = ParseBool(rows, "Pref:Jitsi:DisableTileEnlargement", false),
            SkipMediaPermissions   = ParseBool(rows, "Pref:Jitsi:SkipMediaPermissions",   false),
            DisableNotifications   = ParseBool(rows, "Pref:Jitsi:DisableNotifications",   false),
        };
        foreach (var name in ToolbarButtons)
            dto.ToolbarButtons[name] = ParseBool(rows, $"Pref:Toolbar:{name}", true);
        return dto;
    }

    public async Task SaveMeetingPreferencesAsync(MeetingPreferencesDto p)
    {
        async Task UpsertKey(string key, string value, string desc, string cat)
        {
            await _data.UpsertAppConfigAsync(new AppConfig
            {
                Key         = key,
                Value       = value,
                Description = desc,
                Category    = cat,
            });
        }

        await UpsertKey("Pref:Camera:Default",            B(p.DefaultCameraOn),       "Camera on by default in new meetings",     "Preferences");
        await UpsertKey("Pref:Microphone:Default",        B(p.DefaultMicOn),          "Microphone on by default in new meetings", "Preferences");
        await UpsertKey("Pref:Meeting:DefaultDuration",   p.DefaultDurationMinutes.ToString(CultureInfo.InvariantCulture),
                                                          "Default meeting duration (minutes)",                 "Preferences");
        await UpsertKey("Pref:Meeting:NameMode",          p.MeetingNameMode ?? "auto",
                                                          "Meeting name mode: 'auto' or 'manual'",              "Preferences");
        await UpsertKey("Pref:Meeting:EnablePassword",    B(p.EnableMeetingPassword),
                                                          "Allow hosts to set a join password on each meeting", "Preferences");
        await UpsertKey("Pref:Meeting:RequireHostStart",  B(p.RequireHostStart),
                                                          "Block share-link joiners until the host starts the meeting", "Preferences");
        await UpsertKey("Pref:Meeting:EncryptedShareLink", B(p.EncryptedShareLink),
                                                          "Use opaque encrypted token in share URL. When off, share URL exposes the plain meeting code so recipients can read/type it.", "Preferences");
        await UpsertKey("Pref:Meeting:EmbedPasswordInLink", B(p.EmbedPasswordInLink),
                                                          "Embed the meeting password into the encrypted share token so recipients skip the password prompt. Encrypted-link mode only — has no effect on plain /{code} URLs.", "Preferences");
        await UpsertKey("Pref:Recurring:MaxDurationDays",  p.RecurringMaxDurationDays.ToString(CultureInfo.InvariantCulture),
                                                          "Maximum number of days a recurring meeting series may extend from its start. 0 = no cap (Never end-condition stays available). Default 90.", "Preferences");
        await UpsertKey("Pref:Meeting:WebClientUrl",      p.WebClientUrl ?? "",
                                                          "Optional branded URL for the web join page printed in email + .ics invitations. Empty = use the host's own /oaticonnect/join.", "Preferences");

        await UpsertKey("Pref:Jitsi:DisablePreJoinPage",     B(p.DisablePreJoinPage),     "Skip Jitsi prejoin page",                  "Jitsi");
        await UpsertKey("Pref:Jitsi:AudioOnly",              B(p.AudioOnly),              "Audio-only mode",                          "Jitsi");
        await UpsertKey("Pref:Jitsi:StartWithAudioMuted",    B(p.StartWithAudioMuted),    "Start with audio muted",                   "Jitsi");
        await UpsertKey("Pref:Jitsi:StartWithCameraOff",     B(p.StartWithCameraOff),     "Start with camera off",                    "Jitsi");
        await UpsertKey("Pref:Jitsi:DisableFaceCentering",   B(p.DisableFaceCentering),   "Disable face centering",                   "Jitsi");
        await UpsertKey("Pref:Jitsi:DisableTileEnlargement", B(p.DisableTileEnlargement), "Disable tile enlargement",                 "Jitsi");
        await UpsertKey("Pref:Jitsi:SkipMediaPermissions",   B(p.SkipMediaPermissions),   "Skip media permissions on join",           "Jitsi");
        await UpsertKey("Pref:Jitsi:DisableNotifications",   B(p.DisableNotifications),   "Disable Jitsi notifications",              "Jitsi");

        foreach (var name in ToolbarButtons)
        {
            var visible = p.ToolbarButtons.TryGetValue(name, out var v) ? v : true;
            await UpsertKey($"Pref:Toolbar:{name}", B(visible), $"Show '{name}' button in the meeting toolbar", "Toolbar");
        }
    }

    private static string B(bool v) => v ? "true" : "false";

    private static bool ParseBool(IReadOnlyDictionary<string, string> rows, string key, bool dflt)
        => rows.TryGetValue(key, out var v) && bool.TryParse(v, out var b) ? b : dflt;

    private static int ParseInt(IReadOnlyDictionary<string, string> rows, string key, int dflt)
        => rows.TryGetValue(key, out var v) && int.TryParse(v, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) ? n : dflt;
}

