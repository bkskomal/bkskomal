namespace OATIConnect.API.Settings;

public interface IAppSettingsService
{
    Task<IReadOnlyList<AppConfigDto>> GetAllAsync();
    Task<AppConfigDto?> GetByKeyAsync(string key);
    Task<AppConfigDto>  UpsertAsync(UpsertAppConfigCommand command);

    Task<MeetingPreferencesDto> GetMeetingPreferencesAsync();
    Task SaveMeetingPreferencesAsync(MeetingPreferencesDto prefs);
}

public record AppConfigDto(string Key, string Value, string? Description, string Category);
public record UpsertAppConfigCommand(string Key, string Value, string? Description, string Category);

public class MeetingPreferencesDto
{
    public bool DefaultCameraOn        { get; set; } = true;
    public bool DefaultMicOn           { get; set; } = true;
    public int  DefaultDurationMinutes { get; set; } = 60;
    public string MeetingNameMode      { get; set; } = "auto"; // "auto" | "manual"

    // Defaults reflect the production-deployed posture: passwords on,
    // host-start gating on, encrypted share links on. Fresh installs
    // pick these up; existing deployments keep whatever value is
    // already persisted in oaticonnect_AppConfigs.
    public bool EnableMeetingPassword  { get; set; } = true;

    public bool RequireHostStart       { get; set; } = true;

    public bool EncryptedShareLink     { get; set; } = true;

    /// <summary>
    /// When true AND the meeting has a password AND the share URL is in
    /// encrypted form, the token also carries the password — recipients
    /// click the link and land directly in the meeting (Jitsi password
    /// auto-applied server-side) without the prejoin password prompt.
    /// Off by default: encrypted link is opaque but recipients must
    /// still type the password they got separately. Has no effect on
    /// the plain /{code} share format (which never embeds secrets).
    /// </summary>
    public bool EmbedPasswordInLink    { get; set; } = true;

    /// <summary>
    /// Hard ceiling on how far out a recurring series may extend
    /// (in days from the series start). The Schedule Meeting form
    /// hides the "Never" end-condition once the admin sets a cap
    /// here, and clamps the "On date" picker / "After N" counter to
    /// fit. 0 disables the cap (legacy behaviour — Never option
    /// remains visible). Default 90 days = ~3 months, which covers
    /// typical project standups without letting series accumulate
    /// forever.
    /// </summary>
    public int  RecurringMaxDurationDays { get; set; } = 90;

    /// <summary>
    /// Optional override for the "join from the web" URL printed in
    /// invitations alongside the one-click share link. Recipients
    /// without the share URL (e.g. forwarded by SMS) can paste this
    /// generic page URL and type the Meeting ID + name + password to
    /// join — same flow as the Windows desktop client.
    ///
    /// Empty / null = use the host's own <c>{webAppUrl}/oaticonnect/join</c>.
    /// Set to a branded short URL (e.g. <c>https://meet.example.com/join</c>)
    /// when you front the OATIConnect deployment behind a custom domain.
    /// </summary>
    public string WebClientUrl { get; set; } = "";

    public bool DisablePreJoinPage     { get; set; }
    public bool AudioOnly              { get; set; }
    public bool StartWithAudioMuted    { get; set; }
    public bool StartWithCameraOff     { get; set; }
    public bool DisableFaceCentering   { get; set; }
    public bool DisableTileEnlargement { get; set; }
    public bool SkipMediaPermissions   { get; set; }
    public bool DisableNotifications   { get; set; }

    public Dictionary<string, bool> ToolbarButtons { get; set; } = new();
}
