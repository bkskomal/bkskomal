﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using OATIConnect.API.DependencyInjection;
using OATIConnect.Server;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace OATIConnect.API.Jitsi;

public class JitsiTokenService : IJitsiTokenService
{
	private readonly IConfiguration _config;
	private readonly OATIConnectOptions _options;
	private readonly OATIConnectSettings? _settings;

	public JitsiTokenService(IConfiguration config, OATIConnectOptions options, IServiceProvider sp)
	{
		_config = config;
		_options = options;
		
		_settings = sp.GetService<OATIConnectSettings>() ?? SidecarConfigLoader.TryLoad();
	}

	
	private string? GetJitsiSetting(string key, string? fromOptions, Func<OATIConnectJitsiSettings, string>? fromSettings = null)
	{
		if (!string.IsNullOrWhiteSpace(fromOptions)) return fromOptions;
		if (_settings != null && fromSettings != null)
		{
			var v = fromSettings(_settings.Jitsi);
			if (!string.IsNullOrWhiteSpace(v)) return v;
		}
		return _config["Jitsi:" + key] ?? _config["OATIConnect:Jitsi:" + key];
	}

	
	private string LoadPrivateKeyPem()
	{
		var keyFile = GetJitsiSetting("PrivateKeyFile", _options.JitsiPrivateKeyFile, s => s.PrivateKeyFile);
		if (!string.IsNullOrWhiteSpace(keyFile))
		{
			if (!Path.IsPathRooted(keyFile))
				keyFile = Path.Combine(AppContext.BaseDirectory, keyFile);

			if (File.Exists(keyFile))
				return File.ReadAllText(keyFile);
		}

		var pem = _config["Jitsi:PrivateKey"] ?? _config["OATIConnect:Jitsi:PrivateKey"];
		if (string.IsNullOrWhiteSpace(pem))
			throw new InvalidOperationException(
				"Jitsi private key is missing. Set OATIConnect.Jitsi.PrivateKeyFile in oaticonnect_config.json (next to your host exe), " +
				"or pass options.JitsiPrivateKeyFile to AddOATIConnect, " +
				"or set Jitsi:PrivateKeyFile / Jitsi:PrivateKey in appsettings.json.");
		return pem;
	}

	private static RSA CreateRsaFromPem(string pem)
	{
		if (string.IsNullOrWhiteSpace(pem))
			throw new ArgumentNullException(nameof(pem), "Jitsi private key is missing");

		
		while (pem.Contains("\\n"))
		{
			pem = pem.Replace("\\n", "\n");
		}
		pem = Regex.Replace(pem, @"\\+\n", "\n");
		pem = pem.Replace("\r\n", "\n").Trim();

		var rsa = RSA.Create();
		rsa.ImportFromPem(pem.ToCharArray());
		return rsa;
	}

	public string Generate(
		string room,
		string userId,
		string displayName,
		bool isModerator)
	{
		
		var appId = GetJitsiSetting("AppId", _options.JitsiAppId, s => s.AppId);
		if (string.IsNullOrWhiteSpace(appId))
		{
			appId = "oaticonnect";
			Console.Error.WriteLine("[OATIConnect/JitsiTokenService] Jitsi.AppId not configured anywhere — falling back to 'oaticonnect'. Set OATIConnect.Jitsi.AppId in oaticonnect_config.json to silence this warning.");
		}
		var privateKeyPem = LoadPrivateKeyPem();

		var rsa = CreateRsaFromPem(privateKeyPem);

		var rsaKey = new RsaSecurityKey(rsa)
		{
			CryptoProviderFactory = new CryptoProviderFactory { CacheSignatureProviders = false }
		};

		var credentials = new SigningCredentials(
			rsaKey,
			SecurityAlgorithms.RsaSha256
		);

		var claims = new List<Claim>
		{
			new("context", $$"""
            {
              "user": {
                "id": "{{userId}}",
                "name": "{{displayName}}",
                "moderator": {{isModerator.ToString().ToLower()}}
              }
            }
            """),
			new("room", room)
		};

		var token = new JwtSecurityToken(
			issuer: appId,
			audience: "jitsi",
			claims: claims,
			expires: DateTime.UtcNow.AddMinutes(3),
			signingCredentials: credentials
		);

		try
		{
			return new JwtSecurityTokenHandler().WriteToken(token);
		}
		finally
		{
			rsa.Dispose();
		}
	}
}
