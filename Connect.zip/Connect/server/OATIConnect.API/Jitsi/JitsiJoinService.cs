using OATIConnect.API.Common;
using OATIConnect.API.Meetings;
using OATIConnect.API.Meetings.DTOs;
using OATIConnect.API.DependencyInjection;
using OATIConnect.API.Jitsi;
using Microsoft.Extensions.Configuration;

namespace OATIConnect.API.Jitsi;

public class JitsiJoinService : IJitsiJoinService
{
	private readonly IJitsiTokenService _jitsi;

	private readonly IOATIConnectExternalAPI _data;
	private readonly IOATIConnectExternalAPI _userProvider;
	private readonly OATIConnectOptions _options;
	private readonly IConfiguration _config;
	private readonly IMeetingPasswordProtector _passwordProtector;
	private readonly IHostPresenceTracker _hostPresence;

	public JitsiJoinService(
		IJitsiTokenService jitsi,
		IOATIConnectExternalAPI api,
		OATIConnectOptions options,
		IConfiguration config,
		IMeetingPasswordProtector passwordProtector,
		IHostPresenceTracker hostPresence)
	{
		_jitsi              = jitsi;
		_data               = api;
		_userProvider       = api;
		_options            = options;
		_config             = config;
		_passwordProtector  = passwordProtector;
		_hostPresence       = hostPresence;
	}

	public async Task<Result<JitsiJoinDto>> JoinAsync(string roomName)
	{
		var meeting = await _data.GetActiveMeetingByRoomNameAsync(roomName);
		if (meeting == null)
			return Result<JitsiJoinDto>.Failure("NOT_FOUND", "Meeting not found or not active");

		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null)
			return Result<JitsiJoinDto>.Failure("UNAUTHORIZED", "User not authenticated");

		var isHost = meeting.HostUserId == currentUser.Id;

		// Host-start gate (in-app path). When the meeting carries the
		// per-meeting RequireHostStart flag, only the host can enter
		// when the host is NOT currently present in the room. Source of
		// truth is the in-memory presence tracker (set on host's
		// videoConferenceJoined, cleared on videoConferenceLeft) — using
		// Status alone leaks: a meeting can be Active but empty after
		// the host leaves without explicitly ending, and we don't want
		// late joiners walking into an empty room.
		// Defensive: a presence-read failure mustn't 500 the join flow.
		// Falling through to "not arrived" leaves the gate closed,
		// which is the conservative choice — guest sees the waiting
		// page until the next poll succeeds.
		bool hostPresent = false;
		try { hostPresent = await _hostPresence.HasArrivedAsync(meeting.Id); }
		catch (Exception ex) { Console.Error.WriteLine($"[OATIConnect/JitsiJoinService] HasArrivedAsync threw: {ex.GetType().Name}: {ex.Message}"); }
		if (meeting.RequireHostStart && !isHost && !hostPresent)
		{
			return Result<JitsiJoinDto>.Failure(
				"HOST_NOT_STARTED",
				"The host hasn't started this meeting yet. Please wait for the host to start it.");
		}

		// Zoom-style auto-start: when the host enters a Scheduled meeting,
		// flip Status=Active and stamp ActualStartUtc so the gate releases
		// for everyone else. Without this the host could be inside Jitsi
		// while invitees + share-link guests still see the waiting page,
		// because no separate "Start" API call was ever made.
		if (isHost && meeting.Status == Domain.Entities.MeetingStatus.Scheduled)
		{
			meeting.Status         = Domain.Entities.MeetingStatus.Active;
			meeting.ActualStartUtc = DateTime.UtcNow;
			await _data.UpdateMeetingAsync(meeting);
		}

		await _data.AddParticipantAsync(new Domain.Entities.MeetingParticipant
		{
			Id          = Guid.NewGuid(),
			MeetingId   = meeting.Id,
			UserId      = currentUser.Id,
			Name        = currentUser.Name,
			Email       = currentUser.Email,
			JoinedAtUtc = DateTime.UtcNow,
		});

		var serverUrl = ResolveJitsiServerUrl();

		// JWT is optional. Public Jitsi (meet.jit.si, jitsi.riot.im, …)
		// rejects tokens signed by an unknown key; private deployments
		// require them. If our token issuer isn't fully configured (key
		// file missing in dev, AppId blank), let the popup join without
		// auth rather than failing the whole flow.
		string jwt;
		try
		{
			jwt = _jitsi.Generate(
				meeting.RoomName,
				currentUser.Id.ToString(),
				currentUser.Name,
				isModerator: isHost);
		}
		catch (Exception ex)
		{
			Console.Error.WriteLine($"[OATIConnect/JitsiJoinService] JWT generation skipped: {ex.Message}");
			jwt = "";
		}

		return Result<JitsiJoinDto>.Success(new JitsiJoinDto
		{
			MeetingId       = meeting.Id,
			ServerUrl       = serverUrl,
			RoomName        = meeting.RoomName,
			Jwt             = jwt,
			DisplayName     = currentUser.Name,
			IsModerator     = isHost,
			DurationMinutes = meeting.DurationMinutes,
			ActualStartUtc  = meeting.ActualStartUtc,
			Status          = meeting.Status.ToString(),
			// Plaintext password for in-app host/invitee. Logged-in
			// users skip the prejoin password gate, so the embed JS
			// auto-fills via executeCommand('password', …) instead.
			Password        = _passwordProtector.Unprotect(meeting.Password) ?? "",
		});
	}

	public async Task<Result<JitsiJoinDto>> JoinAsGuestAsync(Guid meetingId, string displayName)
	{
		var meeting = await _data.GetMeetingByIdAsync(meetingId);
		if (meeting == null)
			return Result<JitsiJoinDto>.Failure("NOT_FOUND", "Meeting not found");

		// Only allow guest join when the meeting is alive — Cancelled or
		// Ended meetings shouldn't accept new joiners. Scheduled and Active
		// are both fine; the host UI surfaces a "waiting room" state for
		// pre-Active meetings via the meeting status badge.
		if (meeting.Status == Domain.Entities.MeetingStatus.Cancelled ||
		    meeting.Status == Domain.Entities.MeetingStatus.Ended)
		{
			return Result<JitsiJoinDto>.Failure("MEETING_OVER", "This meeting is no longer available.");
		}

		var safeName = string.IsNullOrWhiteSpace(displayName)
			? "Guest"
			: displayName.Trim();
		// Truncate to a sensible length — Jitsi shows the display name in
		// every tile and accepts ~50 chars before clipping.
		if (safeName.Length > 50) safeName = safeName.Substring(0, 50);

		// Synthetic guest user id — negative so it can never collide with a
		// real host UserId (those are positive ints from the framework).
		// Stable per session via a quick hash, so two browser tabs from
		// the same guest don't appear as multiple participants.
		var guestUserId = -Math.Abs(safeName.GetHashCode());

		await _data.AddParticipantAsync(new Domain.Entities.MeetingParticipant
		{
			Id          = Guid.NewGuid(),
			MeetingId   = meeting.Id,
			UserId      = guestUserId,
			Name        = safeName,
			Email       = "",
			JoinedAtUtc = DateTime.UtcNow,
		});

		var serverUrl = ResolveJitsiServerUrl();

		string jwt;
		try
		{
			jwt = _jitsi.Generate(meeting.RoomName, guestUserId.ToString(), safeName, isModerator: false);
		}
		catch (Exception ex)
		{
			Console.Error.WriteLine($"[OATIConnect/JitsiJoinService] guest JWT generation skipped: {ex.Message}");
			jwt = "";
		}

		return Result<JitsiJoinDto>.Success(new JitsiJoinDto
		{
			MeetingId       = meeting.Id,
			ServerUrl       = serverUrl,
			RoomName        = meeting.RoomName,
			Jwt             = jwt,
			DisplayName     = safeName,
			IsModerator     = false,
			DurationMinutes = meeting.DurationMinutes,
			ActualStartUtc  = meeting.ActualStartUtc,
			Status          = meeting.Status.ToString(),
			// Server has already validated the password against user input
			// in the prejoin form before we got here — pass it back so the
			// embed JS can satisfy Jitsi's room-lock prompt without a
			// second user keystroke.
			Password        = _passwordProtector.Unprotect(meeting.Password) ?? "",
		});
	}

	private string ResolveJitsiServerUrl()
	{
		// Priority: explicit option → sidecar oaticonnect_config.json →
		// host's IConfiguration ("Jitsi:..." or "OATIConnect:Jitsi:...").
		// All three are config-driven — Jitsi server URL is environment
		// configuration, never inferred from the current request.
		var sidecar = SidecarConfigLoader.TryLoad();
		var jitsiBase = _options.JitsiServerBaseUrl;
		if (string.IsNullOrWhiteSpace(jitsiBase) && sidecar != null)
			jitsiBase = sidecar.Jitsi.ServerBaseUrl;
		if (string.IsNullOrWhiteSpace(jitsiBase))
			jitsiBase = _config["Jitsi:ServerBaseUrl"] ?? _config["OATIConnect:Jitsi:ServerBaseUrl"];

		if (!string.IsNullOrWhiteSpace(jitsiBase))
		{
			return jitsiBase.StartsWith("http", StringComparison.OrdinalIgnoreCase)
				? jitsiBase
				: $"https://{jitsiBase}";
		}

		// No Jitsi server configured anywhere. Fall back to the public
		// Jitsi server so the embed still works in a misconfigured dev
		// environment — the host will see clearly that they need to set
		// Jitsi:ServerBaseUrl when JWT auth fails.
		return "https://meet.jit.si";
	}
}
