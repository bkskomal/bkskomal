﻿namespace OATIConnect.API.Jitsi;

public interface IJitsiTokenService
{
	string Generate(
		string room,
		string userId,
		string displayName,
		bool isModerator
	);
}
