using OATIConnect.API.Exchange;

namespace OATIConnect.API.Exchange;

public class DisabledExchangeDirectoryService : IExchangeDirectoryService
{
    private readonly IOATIConnectExternalAPI _data;

    public DisabledExchangeDirectoryService(IOATIConnectExternalAPI api) { _data = api; }

    public async Task<bool> IsEnabledAsync()
    {
        var row = await _data.GetAppConfigByKeyAsync("Exchange:Enabled");
        return string.Equals(row?.Value, "true", StringComparison.OrdinalIgnoreCase);
    }

    public Task<IReadOnlyList<ExchangeDirectoryItem>> SearchAsync(string query, CancellationToken ct = default)
        => Task.FromResult<IReadOnlyList<ExchangeDirectoryItem>>(Array.Empty<ExchangeDirectoryItem>());

    public Task<IReadOnlyList<string>> ResolveEmailsAsync(IEnumerable<string> ids, CancellationToken ct = default)
        => Task.FromResult<IReadOnlyList<string>>(Array.Empty<string>());

    public async Task<ExchangeTestResult> TestConnectionAsync(CancellationToken ct = default)
    {
        if (!await IsEnabledAsync())
            return new ExchangeTestResult(false, "Exchange integration is disabled. Toggle it on in Settings to test the connection.");

        return new ExchangeTestResult(false, "Exchange integration is enabled but the Graph client isn't wired up yet (Phase 1 stub).");
    }

    public Task<bool> SendInviteEmailAsync(
        string senderEmail, IEnumerable<string> recipientEmails,
        string subject, string htmlBody,
        byte[]? icsAttachment, string? icsFileName,
        CancellationToken ct = default) => Task.FromResult(false);
}
