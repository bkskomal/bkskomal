using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using OATIConnect.API.Exchange;

namespace OATIConnect.API.Exchange;

public class GraphExchangeDirectoryService : IExchangeDirectoryService
{
    private const string GraphRoot = "https://graph.microsoft.com/v1.0";

    private readonly IOATIConnectExternalAPI _data;
    private readonly HttpClient _http;
    private readonly IMemoryCache _cache;
    private readonly ILogger<GraphExchangeDirectoryService> _log;

    public GraphExchangeDirectoryService(
        IOATIConnectExternalAPI api,
        IHttpClientFactory httpFactory,
        IMemoryCache cache,
        ILogger<GraphExchangeDirectoryService> log)
    {
        _data  = api;
        _http  = httpFactory.CreateClient("OATIConnect-Graph");
        _cache = cache;
        _log   = log;
    }

    public async Task<bool> IsEnabledAsync()
    {
        var enabled = await ReadConfigValueAsync("Exchange:Enabled");
        return string.Equals(enabled, "true", StringComparison.OrdinalIgnoreCase);
    }

    public async Task<IReadOnlyList<ExchangeDirectoryItem>> SearchAsync(string query, CancellationToken ct = default)
    {
        if (!await IsEnabledAsync())                  return Array.Empty<ExchangeDirectoryItem>();
        if (string.IsNullOrWhiteSpace(query) || query.Trim().Length < 2)
            return Array.Empty<ExchangeDirectoryItem>();

        var trimmed = query.Trim();
        var cacheKey = $"xchg:search:{trimmed.ToLowerInvariant()}";
        if (_cache.TryGetValue<IReadOnlyList<ExchangeDirectoryItem>>(cacheKey, out var cached))
            return cached!;

        try
        {
            await EnsureAuthHeaderAsync(ct);

            var groupsTask = QueryGraphAsync(
                $"{GraphRoot}/groups?$top=20&$select=id,displayName,mail&$filter=" +
                $"startswith(displayName,'{Escape(trimmed)}') or startswith(mail,'{Escape(trimmed)}')",
                ct);

            var usersTask = QueryGraphAsync(
                $"{GraphRoot}/users?$top=20&$select=id,displayName,mail&$filter=" +
                $"startswith(displayName,'{Escape(trimmed)}') or startswith(mail,'{Escape(trimmed)}')",
                ct);

            await Task.WhenAll(groupsTask, usersTask);

            var items = new List<ExchangeDirectoryItem>();
            AppendItems(items, groupsTask.Result, kind: "group");
            AppendItems(items, usersTask.Result,  kind: "user");

            var result = (IReadOnlyList<ExchangeDirectoryItem>)items;
            _cache.Set(cacheKey, result, TimeSpan.FromMinutes(1));
            return result;
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Exchange search failed for query '{Query}'", trimmed);
            return Array.Empty<ExchangeDirectoryItem>();
        }
    }

    public async Task<IReadOnlyList<string>> ResolveEmailsAsync(IEnumerable<string> ids, CancellationToken ct = default)
    {
        if (!await IsEnabledAsync()) return Array.Empty<string>();
        var distinctIds = ids?.Where(id => !string.IsNullOrWhiteSpace(id)).Distinct().ToList()
                          ?? new List<string>();
        if (distinctIds.Count == 0) return Array.Empty<string>();

        await EnsureAuthHeaderAsync(ct);

        var emails = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var id in distinctIds)
        {
            try
            {
                var members = await QueryGraphAsync(
                    $"{GraphRoot}/groups/{Uri.EscapeDataString(id)}/members?$top=999&$select=mail,userPrincipalName",
                    ct);
                if (members.TryGetProperty("value", out var arr) && arr.ValueKind == JsonValueKind.Array)
                {
                    foreach (var m in arr.EnumerateArray())
                    {
                        var email = ReadEmail(m);
                        if (!string.IsNullOrWhiteSpace(email)) emails.Add(email);
                    }
                    continue; // It was a group — done.
                }
            }
            catch
            {
            }

            try
            {
                var user = await QueryGraphAsync(
                    $"{GraphRoot}/users/{Uri.EscapeDataString(id)}?$select=mail,userPrincipalName",
                    ct);
                var email = ReadEmail(user);
                if (!string.IsNullOrWhiteSpace(email)) emails.Add(email);
            }
            catch (Exception ex)
            {
                _log.LogWarning(ex, "Could not resolve directory id {Id}", id);
            }
        }

        return emails.ToList();
    }

    public async Task<bool> SendInviteEmailAsync(
        string senderEmail,
        IEnumerable<string> recipientEmails,
        string subject,
        string htmlBody,
        byte[]? icsAttachment,
        string? icsFileName,
        CancellationToken ct = default)
    {
        if (!await IsEnabledAsync()) return false;
        if (string.IsNullOrWhiteSpace(senderEmail)) return false;

        var to = recipientEmails?
            .Where(e => !string.IsNullOrWhiteSpace(e))
            .Select(e => e.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList() ?? new List<string>();
        if (to.Count == 0) return false;

        try
        {
            await EnsureAuthHeaderAsync(ct);

            
            var toArray = new JsonArray();
            foreach (var addr in to)
            {
                toArray.Add(new JsonObject
                {
                    ["emailAddress"] = new JsonObject { ["address"] = addr },
                });
            }

            var attachmentsArray = new JsonArray();
            if (icsAttachment != null && icsAttachment.Length > 0)
            {
                attachmentsArray.Add(new JsonObject
                {
                    ["@odata.type"] = "#microsoft.graph.fileAttachment",
                    ["name"]         = icsFileName ?? "invite.ics",
                    ["contentType"]  = "text/calendar",
                    ["contentBytes"] = Convert.ToBase64String(icsAttachment),
                });
            }

            var payload = new JsonObject
            {
                ["message"] = new JsonObject
                {
                    ["subject"]      = subject,
                    ["body"]         = new JsonObject { ["contentType"] = "HTML", ["content"] = htmlBody },
                    ["toRecipients"] = toArray,
                    ["attachments"]  = attachmentsArray,
                },
                ["saveToSentItems"] = false,
            };

            using var content = new StringContent(payload.ToJsonString(), System.Text.Encoding.UTF8, "application/json");
            using var resp    = await _http.PostAsync(
                $"{GraphRoot}/users/{Uri.EscapeDataString(senderEmail)}/sendMail",
                content, ct);

            if (!resp.IsSuccessStatusCode)
            {
                var detail = await resp.Content.ReadAsStringAsync(ct);
                _log.LogWarning("Graph sendMail failed ({Status}): {Detail}", (int)resp.StatusCode, detail);
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Exchange sendMail failed");
            return false;
        }
    }

    public async Task<ExchangeTestResult> TestConnectionAsync(CancellationToken ct = default)
    {
        if (!await IsEnabledAsync())
            return new ExchangeTestResult(false, "Exchange integration is disabled. Toggle it on in Settings before testing.");

        try
        {
            await EnsureAuthHeaderAsync(ct, force: true);

            var org = await QueryGraphAsync($"{GraphRoot}/organization?$select=displayName", ct);
            var name = org.TryGetProperty("value", out var arr) && arr.ValueKind == JsonValueKind.Array && arr.GetArrayLength() > 0
                ? arr[0].GetProperty("displayName").GetString()
                : null;

            return new ExchangeTestResult(true, $"Connected to {name ?? "tenant"}.");
        }
        catch (HttpRequestException ex) when (ex.Message.Contains("401") || ex.Message.Contains("403"))
        {
            return new ExchangeTestResult(false, $"Auth failed: {ex.Message}. Check tenant id, client id, and secret.");
        }
        catch (Exception ex)
        {
            return new ExchangeTestResult(false, $"Connection failed: {ex.Message}");
        }
    }


    private async Task EnsureAuthHeaderAsync(CancellationToken ct, bool force = false)
    {
        const string tokenCacheKey = "xchg:token";
        if (!force && _cache.TryGetValue<string>(tokenCacheKey, out var cachedToken))
        {
            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", cachedToken);
            return;
        }

        var tenantId     = await ReadConfigValueAsync("Exchange:TenantId");
        var clientId     = await ReadConfigValueAsync("Exchange:ClientId");
        var clientSecret = await ReadConfigValueAsync("Exchange:ClientSecret");
        if (string.IsNullOrWhiteSpace(tenantId) || string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
            throw new InvalidOperationException("Tenant id, client id, and client secret are all required.");

        var tokenUrl = $"https://login.microsoftonline.com/{Uri.EscapeDataString(tenantId)}/oauth2/v2.0/token";
        var body = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_id"]     = clientId,
            ["client_secret"] = clientSecret,
            ["scope"]         = "https://graph.microsoft.com/.default",
            ["grant_type"]    = "client_credentials",
        });

        using var resp = await _http.PostAsync(tokenUrl, body, ct);
        var json = await resp.Content.ReadAsStringAsync(ct);
        if (!resp.IsSuccessStatusCode)
            throw new HttpRequestException($"Token endpoint returned {(int)resp.StatusCode}: {json}");

        using var doc = JsonDocument.Parse(json);
        var token = doc.RootElement.GetProperty("access_token").GetString()
                    ?? throw new InvalidOperationException("Token response missing access_token");
        var ttl = doc.RootElement.TryGetProperty("expires_in", out var ttlEl) ? ttlEl.GetInt32() : 3600;

        _cache.Set(tokenCacheKey, token, TimeSpan.FromSeconds(Math.Max(60, ttl - 600)));
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    private async Task<JsonElement> QueryGraphAsync(string url, CancellationToken ct)
    {
        using var resp = await _http.GetAsync(url, ct);
        var json = await resp.Content.ReadAsStringAsync(ct);
        if (!resp.IsSuccessStatusCode)
            throw new HttpRequestException($"Graph {(int)resp.StatusCode}: {json}");
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.Clone();
    }

    private static void AppendItems(List<ExchangeDirectoryItem> sink, JsonElement root, string kind)
    {
        if (!root.TryGetProperty("value", out var arr) || arr.ValueKind != JsonValueKind.Array) return;
        foreach (var x in arr.EnumerateArray())
        {
            var id    = x.TryGetProperty("id",          out var idEl)   ? idEl.GetString()   : null;
            var name  = x.TryGetProperty("displayName", out var nameEl) ? nameEl.GetString() : null;
            var email = ReadEmail(x);
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(name)) continue;
            sink.Add(new ExchangeDirectoryItem(id!, kind, name!, email));
        }
    }

    private static string? ReadEmail(JsonElement el)
    {
        if (el.TryGetProperty("mail", out var mailEl) && mailEl.ValueKind == JsonValueKind.String)
        {
            var m = mailEl.GetString();
            if (!string.IsNullOrWhiteSpace(m)) return m;
        }
        if (el.TryGetProperty("userPrincipalName", out var upn) && upn.ValueKind == JsonValueKind.String)
        {
            var u = upn.GetString();
            if (!string.IsNullOrWhiteSpace(u)) return u;
        }
        return null;
    }

    private async Task<string?> ReadConfigValueAsync(string key)
    {
        var row = await _data.GetAppConfigByKeyAsync(key);
        return row?.Value;
    }

    private static string Escape(string s) => s.Replace("'", "''");
}
