namespace OATIConnect.API.Exchange;

public interface IExchangeDirectoryService
{
    
    Task<bool> IsEnabledAsync();

    Task<IReadOnlyList<ExchangeDirectoryItem>> SearchAsync(string query, CancellationToken ct = default);

    
    Task<IReadOnlyList<string>> ResolveEmailsAsync(IEnumerable<string> ids, CancellationToken ct = default);

    
    Task<ExchangeTestResult> TestConnectionAsync(CancellationToken ct = default);

    
    Task<bool> SendInviteEmailAsync(
        string senderEmail,
        IEnumerable<string> recipientEmails,
        string subject,
        string htmlBody,
        byte[]? icsAttachment,
        string? icsFileName,
        CancellationToken ct = default);
}

public record ExchangeDirectoryItem(
    string Id,
    string Kind,    // "group" | "contact" | "user"
    string Name,
    string? Email);

public record ExchangeTestResult(bool Success, string Message);
