namespace OATIConnect.API;

public interface IOATIConnectRequestUrlProvider
{
    string? GetWebAppBaseUrl();
}

internal class NullRequestUrlProvider : IOATIConnectRequestUrlProvider
{
    public string? GetWebAppBaseUrl() => null;
}
