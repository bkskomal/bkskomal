﻿using System.Globalization;

namespace OATIConnect.API.Common;

public static class TimeZoneMapper
{
    private static readonly Dictionary<string, string> AbbrToIana = new(StringComparer.OrdinalIgnoreCase)
    {
        // ----- North America -----
        ["EST"]  = "America/New_York",   ["EDT"]  = "America/New_York",
        ["CST"]  = "America/Chicago",    ["CDT"]  = "America/Chicago",
        ["MST"]  = "America/Denver",     ["MDT"]  = "America/Denver",
        ["PST"]  = "America/Los_Angeles",["PDT"]  = "America/Los_Angeles",
        ["AKST"] = "America/Anchorage",  ["AKDT"] = "America/Anchorage",
        ["HST"]  = "Pacific/Honolulu",   ["HAST"] = "Pacific/Honolulu",
        ["AST"]  = "America/Halifax",    ["ADT"]  = "America/Halifax",
        ["NST"]  = "America/St_Johns",   ["NDT"]  = "America/St_Johns",

        // ----- Europe -----
        ["GMT"]  = "Etc/GMT",
        ["BST"]  = "Europe/London",      ["WET"]  = "Europe/London",
        ["CET"]  = "Europe/Paris",       ["CEST"] = "Europe/Paris",
        ["EET"]  = "Europe/Bucharest",   ["EEST"] = "Europe/Bucharest",

        // ----- Asia / Pacific -----
        ["IST"]  = "Asia/Kolkata",       // India Standard Time (NOT Israel/Ireland — those use Asia/Jerusalem / Europe/Dublin)
        ["JST"]  = "Asia/Tokyo",
        ["KST"]  = "Asia/Seoul",
        ["AEST"] = "Australia/Sydney",   ["AEDT"] = "Australia/Sydney",
        ["NZST"] = "Pacific/Auckland",   ["NZDT"] = "Pacific/Auckland",
    };

    public static string ToIana(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "";
        var input = raw.Trim();

        if (AbbrToIana.TryGetValue(input, out var ianaFromAbbr))
            return ianaFromAbbr;

        try
        {
            var tz = TimeZoneInfo.FindSystemTimeZoneById(input);
            if (tz.HasIanaId) return tz.Id;

            if (TimeZoneInfo.TryConvertWindowsIdToIanaId(tz.Id, out var iana))
                return iana;
        }
        catch {  }
        return "";
    }

 
    public static string ToWindows(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "";
        var input = raw.Trim();

        if (AbbrToIana.TryGetValue(input, out var iana))
        {
            if (TimeZoneInfo.TryConvertIanaIdToWindowsId(iana, out var winFromAbbr))
                return winFromAbbr;
        }

        try
        {
            var tz = TimeZoneInfo.FindSystemTimeZoneById(input);
            if (!tz.HasIanaId) return tz.Id;

            if (TimeZoneInfo.TryConvertIanaIdToWindowsId(tz.Id, out var win))
                return win;
        }
        catch { /* ignore */ }
        return "";
    }
}
