using OATIConnect.API.Domain.Entities;

namespace OATIConnect.API;


public interface IOATIConnectExternalAPI : IOATIConnectRepository
{
    Task<ExternalUserInfo?> GetCurrentUserAsync();
}

public record ExternalUserInfo(
    int Id,
    string Name,
    string Email,
    string Role,
    bool IsActive = true,
    string TimeZoneWindows = "",
    string TimeZoneIana = "");
