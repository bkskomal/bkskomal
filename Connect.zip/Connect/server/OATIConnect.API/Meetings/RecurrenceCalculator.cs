using OATIConnect.API.Domain.Entities;
using System.Globalization;
using System.Text;

namespace OATIConnect.API.Meetings;

public static class RecurrenceCalculator
{
    public static string? BuildRRule(Meeting meeting)
    {
        if (meeting.RecurrenceType == RecurrenceType.None) return null;

        var sb = new StringBuilder("RRULE:FREQ=");
        switch (meeting.RecurrenceType)
        {
            case RecurrenceType.Daily:   sb.Append("DAILY");   break;
            case RecurrenceType.Weekly:  sb.Append("WEEKLY");  break;
            case RecurrenceType.Monthly: sb.Append("MONTHLY"); break;
        }

        var interval = meeting.RecurrenceInterval > 0 ? meeting.RecurrenceInterval : 1;
        if (interval != 1) sb.Append(";INTERVAL=").Append(interval);

        if (meeting.RecurrenceType == RecurrenceType.Weekly && meeting.RecurrenceDaysOfWeekMask > 0)
        {
            sb.Append(";BYDAY=").Append(DaysOfWeekMaskToBYDAY(meeting.RecurrenceDaysOfWeekMask));
        }

        switch (meeting.RecurrenceEndType)
        {
            case RecurrenceEndType.After when meeting.RecurrenceEndCount is > 0:
                sb.Append(";COUNT=").Append(meeting.RecurrenceEndCount);
                break;
            case RecurrenceEndType.OnDate when meeting.RecurrenceEndDateUtc.HasValue:
               
                var until = DateTime.SpecifyKind(meeting.RecurrenceEndDateUtc.Value, DateTimeKind.Utc);
                if (until.TimeOfDay == TimeSpan.Zero)
                    until = until.AddDays(1).AddSeconds(-1);
                sb.Append(";UNTIL=").Append(until.ToString("yyyyMMddTHHmmssZ", CultureInfo.InvariantCulture));
                break;
        }

        return sb.ToString();
    }

    public static DateTime? NextOccurrenceUtc(
        Meeting meeting,
        DateTime afterUtc,
        IReadOnlyCollection<DateTime>? cancelledOriginalUtc = null)
    {
        var first = DateTime.SpecifyKind(meeting.ScheduledTimeUtc, DateTimeKind.Utc);

        if (meeting.RecurrenceType == RecurrenceType.None)
        {
            if (first < afterUtc) return null;
            if (cancelledOriginalUtc != null && IsCancelled(first, cancelledOriginalUtc)) return null;
            return first;
        }

        var interval = meeting.RecurrenceInterval > 0 ? meeting.RecurrenceInterval : 1;
        DateTime? endDate = meeting.RecurrenceEndDateUtc.HasValue
            ? DateTime.SpecifyKind(meeting.RecurrenceEndDateUtc.Value, DateTimeKind.Utc)
            : (DateTime?)null;
        var maxCount = meeting.RecurrenceEndType == RecurrenceEndType.After
            ? meeting.RecurrenceEndCount ?? int.MaxValue
            : int.MaxValue;

        DateTime candidate = first;
        int count = 1;
        int safety = 5000;
        while (safety-- > 0)
        {
            if (count > maxCount) return null;
            if (endDate.HasValue && candidate > endDate.Value) return null;

            var matchesWeekday =
                meeting.RecurrenceType != RecurrenceType.Weekly
                || meeting.RecurrenceDaysOfWeekMask == 0
                || (meeting.RecurrenceDaysOfWeekMask & (1 << (int)candidate.DayOfWeek)) != 0;

            var notCancelled = cancelledOriginalUtc == null || !IsCancelled(candidate, cancelledOriginalUtc);

            if (matchesWeekday && notCancelled && candidate >= afterUtc) return candidate;

            candidate = StepNext(candidate, meeting.RecurrenceType, interval, first);
            count++;
        }
        return null; 
    }

    private static bool IsCancelled(DateTime candidate, IReadOnlyCollection<DateTime> cancelled)
    {
       
        var stamp = DateTime.SpecifyKind(candidate, DateTimeKind.Utc).Ticks;
        foreach (var c in cancelled)
        {
            if (DateTime.SpecifyKind(c, DateTimeKind.Utc).Ticks == stamp) return true;
        }
        return false;
    }

    public static string Describe(Meeting meeting)
    {
        if (meeting.RecurrenceType == RecurrenceType.None) return "";
        var interval = meeting.RecurrenceInterval > 0 ? meeting.RecurrenceInterval : 1;
        var sb = new StringBuilder("Recurs ");
        switch (meeting.RecurrenceType)
        {
            case RecurrenceType.Daily:
                sb.Append(interval == 1 ? "daily" : $"every {interval} days");
                break;
            case RecurrenceType.Weekly:
                sb.Append(interval == 1 ? "weekly" : $"every {interval} weeks");
                if (meeting.RecurrenceDaysOfWeekMask > 0)
                    sb.Append(" on ").Append(DaysOfWeekMaskToHuman(meeting.RecurrenceDaysOfWeekMask));
                break;
            case RecurrenceType.Monthly:
                sb.Append(interval == 1 ? "monthly" : $"every {interval} months");
                break;
        }
        switch (meeting.RecurrenceEndType)
        {
            case RecurrenceEndType.After when meeting.RecurrenceEndCount is > 0:
                sb.Append(", ").Append(meeting.RecurrenceEndCount).Append(" occurrences");
                break;
            case RecurrenceEndType.OnDate when meeting.RecurrenceEndDateUtc.HasValue:
                sb.Append(" until ").Append(meeting.RecurrenceEndDateUtc.Value.ToString("MMM d, yyyy", CultureInfo.InvariantCulture));
                break;
        }
        return sb.ToString();
    }

    private static DateTime StepNext(DateTime current, RecurrenceType type, int interval, DateTime seriesAnchor)
    {
        switch (type)
        {
            case RecurrenceType.Daily:   return current.AddDays(interval);
            case RecurrenceType.Weekly:
              
                return current.AddDays(1);
            case RecurrenceType.Monthly: return current.AddMonths(interval);
            default:                     return current.AddDays(1);
        }
    }

    private static readonly string[] BYDAY = { "SU", "MO", "TU", "WE", "TH", "FR", "SA" };
    private static readonly string[] SHORT = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

    private static string DaysOfWeekMaskToBYDAY(int mask)
    {
        var parts = new List<string>();
        for (int i = 0; i < 7; i++)
            if ((mask & (1 << i)) != 0)
                parts.Add(BYDAY[i]);
        return string.Join(",", parts);
    }

    private static string DaysOfWeekMaskToHuman(int mask)
    {
        var parts = new List<string>();
        for (int i = 0; i < 7; i++)
            if ((mask & (1 << i)) != 0)
                parts.Add(SHORT[i]);
        return string.Join(", ", parts);
    }
}
