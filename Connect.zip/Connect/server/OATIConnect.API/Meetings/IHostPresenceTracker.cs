using System.Collections.Concurrent;
using System.Globalization;
using OATIConnect.API.Domain.Entities;

namespace OATIConnect.API.Meetings;

// Async + persistent presence tracking.
//
// Previously this was a singleton in-memory dictionary. That broke
// under IIS when:
//   * the app pool has >1 worker process (web garden) — the host's
//     "I'm here" ping hits one worker, the guest's "is the host here?"
//     poll hits another, and the second worker has no record;
//   * the app pool recycles between the host ping and the guest poll;
//   * the host process restarts after the meeting started.
//
// Backing the tracker with the same AppConfig table the rest of the
// settings live in keeps the "is the host present?" answer consistent
// across workers and survives restarts, with no schema change.
//
// Staleness: presence rows hold the host's last-seen UTC timestamp.
// HasArrivedAsync treats a row older than StaleAfter as "host gone"
// even if the row hasn't been explicitly cleared — so a host that
// crashes / loses network / closes the tab without firing the
// host-left ping still ends up correctly marked absent within ~1 min.
// The host's popup heartbeats every ~20s, well inside this window.
public interface IHostPresenceTracker
{
    Task RecordHostArrivedAsync(Guid meetingId);

    Task<bool> HasArrivedAsync(Guid meetingId);

    Task ForgetAsync(Guid meetingId);
}

public class HostPresenceTracker : IHostPresenceTracker
{
    // Heartbeats arrive every ~20s (see popup JS). 60s leaves a 3-miss
    // safety margin before we declare the host gone, which is enough
    // to absorb a single network blip without dropping the gate.
    public static readonly TimeSpan StaleAfter = TimeSpan.FromSeconds(60);

    private const string KeyPrefix = "Presence:Host:";
    private const string Category  = "Presence";

    private readonly IOATIConnectExternalAPI _data;

    // Tiny in-process cache to avoid hammering AppConfig on every status
    // poll — the source of truth is still the DB row. 5s TTL keeps the
    // staleness window tight enough that a host-left ping is reflected
    // promptly across workers.
    private static readonly ConcurrentDictionary<Guid, (DateTime At, DateTime? LastSeen)> _cache = new();
    private static readonly TimeSpan CacheTtl = TimeSpan.FromSeconds(5);

    public HostPresenceTracker(IOATIConnectExternalAPI data) { _data = data; }

    public async Task RecordHostArrivedAsync(Guid meetingId)
    {
        var now = DateTime.UtcNow;
        // Optimistically update local cache first so even if the DB
        // upsert fails (constraint violation, race, schema mismatch in
        // the integrator's repo) this worker still treats the host as
        // present until the cache TTL elapses. Cross-worker propagation
        // is best-effort.
        _cache[meetingId] = (now, now);
        try
        {
            await _data.UpsertAppConfigAsync(new AppConfig
            {
                Key         = KeyPrefix + meetingId.ToString(),
                Value       = now.ToString("O", CultureInfo.InvariantCulture),
                Description = "Host last-seen heartbeat. Stale after " + StaleAfter.TotalSeconds + "s.",
                Category    = Category,
            });
        }
        catch (Exception ex)
        {
            // Don't let a repo failure 500 the host-arrived ping. Worst
            // case: cross-worker presence is degraded but local worker
            // still grants the gate while the cache entry is fresh.
            Console.Error.WriteLine($"[OATIConnect/HostPresence] RecordHostArrivedAsync write failed: {ex.GetType().Name}: {ex.Message}");
        }
    }

    public async Task<bool> HasArrivedAsync(Guid meetingId)
    {
        var now = DateTime.UtcNow;
        if (_cache.TryGetValue(meetingId, out var entry) && (now - entry.At) < CacheTtl)
        {
            return entry.LastSeen.HasValue && (now - entry.LastSeen.Value) <= StaleAfter;
        }

        OATIConnect.API.Domain.Entities.AppConfig? row = null;
        try
        {
            row = await _data.GetAppConfigByKeyAsync(KeyPrefix + meetingId.ToString());
        }
        catch (Exception ex)
        {
            // Some repo impls throw on missing row instead of returning
            // null. Treat any read failure as "no presence record" so
            // the gate stays closed but the status endpoint doesn't 500.
            Console.Error.WriteLine($"[OATIConnect/HostPresence] HasArrivedAsync read failed: {ex.GetType().Name}: {ex.Message}");
        }

        // RoundtripKind alone — the ISO "O" format we write encodes the
        // UTC offset (trailing Z), so the parser preserves Kind=Utc
        // without help. RoundtripKind cannot be combined with
        // AssumeUniversal or AssumeLocal; passing the combination
        // throws ArgumentException BEFORE the try-parse runs, slipping
        // past any try/catch on the parse call itself.
        DateTime? lastSeen = null;
        if (row?.Value != null
            && DateTime.TryParse(row.Value, CultureInfo.InvariantCulture,
                                 DateTimeStyles.RoundtripKind,
                                 out var ts))
        {
            lastSeen = DateTime.SpecifyKind(ts, DateTimeKind.Utc);
        }
        _cache[meetingId] = (now, lastSeen);
        return lastSeen.HasValue && (now - lastSeen.Value) <= StaleAfter;
    }

    public async Task ForgetAsync(Guid meetingId)
    {
        // Repo has no delete; back-date the timestamp to MinValue so
        // HasArrivedAsync sees it as stale across every worker, then
        // clear the local cache so this worker also re-reads.
        _cache[meetingId] = (DateTime.UtcNow, null);
        try
        {
            await _data.UpsertAppConfigAsync(new AppConfig
            {
                Key         = KeyPrefix + meetingId.ToString(),
                Value       = DateTime.MinValue.ToString("O", CultureInfo.InvariantCulture),
                Description = "Host left — back-dated stale stamp.",
                Category    = Category,
            });
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[OATIConnect/HostPresence] ForgetAsync write failed: {ex.GetType().Name}: {ex.Message}");
        }
    }
}
