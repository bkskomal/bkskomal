﻿using OATIConnect.API.Common;
using OATIConnect.API.Meetings.DTOs;

namespace OATIConnect.API.Meetings;

public interface IJitsiJoinService
{
	Task<Result<JitsiJoinDto>> JoinAsync(string meetingId);

	Task<Result<JitsiJoinDto>> JoinAsGuestAsync(Guid meetingId, string displayName);
}
