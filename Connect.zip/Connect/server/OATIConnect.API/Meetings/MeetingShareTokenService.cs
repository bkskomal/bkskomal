using System.Text;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.WebUtilities;

namespace OATIConnect.API.Meetings;


public class MeetingShareTokenService : IMeetingShareTokenService
{
    private const string Purpose = "OATIConnect.MeetingShare.v1";

    private readonly IDataProtector _protector;

    public MeetingShareTokenService(IDataProtectionProvider provider)
    {
        _protector = provider.CreateProtector(Purpose);
    }

    // Token payload formats — both wrapped in IDataProtector so any
    // tamper / key roll invalidates them.
    //
    //   Legacy  (guid-only):    [16 bytes meeting GUID]
    //   v2      (with password): [16 bytes meeting GUID][1 byte N][N bytes UTF-8 password]
    //
    // TryValidate accepts either; the password overload returns null
    // for legacy payloads so callers don't have to know which one they
    // got. N is capped at 255 to fit a single length byte — meeting
    // passwords longer than that aren't a realistic case but the
    // Create overload throws to keep failures local.

    public string Create(Guid meetingId) => Create(meetingId, null);

    public string Create(Guid meetingId, string? embeddedPassword)
    {
        var guidBytes = meetingId.ToByteArray();
        byte[] payload;
        if (string.IsNullOrEmpty(embeddedPassword))
        {
            payload = guidBytes;
        }
        else
        {
            var pwBytes = Encoding.UTF8.GetBytes(embeddedPassword);
            if (pwBytes.Length > 255)
                throw new ArgumentException("Embedded password too long (UTF-8 byte count must fit in one byte).", nameof(embeddedPassword));
            payload = new byte[16 + 1 + pwBytes.Length];
            Buffer.BlockCopy(guidBytes, 0, payload, 0, 16);
            payload[16] = (byte)pwBytes.Length;
            Buffer.BlockCopy(pwBytes, 0, payload, 17, pwBytes.Length);
        }
        var protectedBytes = _protector.Protect(payload);
        return WebEncoders.Base64UrlEncode(protectedBytes);
    }

    public bool TryValidate(string token, out Guid meetingId)
        => TryValidate(token, out meetingId, out _);

    public bool TryValidate(string token, out Guid meetingId, out string? embeddedPassword)
    {
        meetingId = Guid.Empty;
        embeddedPassword = null;
        if (string.IsNullOrWhiteSpace(token)) return false;

        try
        {
            var bytes       = WebEncoders.Base64UrlDecode(token);
            var unprotected = _protector.Unprotect(bytes);
            if (unprotected.Length < 16) return false;

            // GUID first.
            var guidBuf = new byte[16];
            Buffer.BlockCopy(unprotected, 0, guidBuf, 0, 16);
            meetingId = new Guid(guidBuf);

            // Optional length-prefixed password tail. Defensive bounds
            // check — a malformed v2 payload silently degrades to a
            // legacy validate (caller still gets the GUID).
            if (unprotected.Length > 16)
            {
                int pwLen = unprotected[16];
                if (pwLen > 0 && unprotected.Length >= 17 + pwLen)
                {
                    embeddedPassword = Encoding.UTF8.GetString(unprotected, 17, pwLen);
                }
            }
            return true;
        }
        catch
        {
            return false;
        }
    }
}
