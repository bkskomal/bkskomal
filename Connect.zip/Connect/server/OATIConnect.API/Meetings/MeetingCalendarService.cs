using OATIConnect.API.Meetings;
using OATIConnect.API.Meetings.DTOs;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Text;

namespace OATIConnect.API.Meetings;

public class MeetingCalendarService : IMeetingCalendarService
{
    // Single IOATIConnectExternalAPI instance behind two fields so the
    // existing call sites (_data.GetXxx / _userProvider.GetCurrentUser)
    // stay readable.
    private readonly IOATIConnectExternalAPI _data;
    private readonly IConfiguration _config;
    private readonly IOATIConnectExternalAPI _userProvider;
    private readonly IMeetingShareTokenService _tokens;
    private readonly IMeetingPasswordProtector _passwordProtector;
    private readonly IOATIConnectRequestUrlProvider _urlProvider;

    public MeetingCalendarService(
        IOATIConnectExternalAPI api,
        IConfiguration config,
        IMeetingShareTokenService tokens,
        IMeetingPasswordProtector passwordProtector,
        IOATIConnectRequestUrlProvider urlProvider)
    {
        _data = api;
        _config = config;
        _userProvider = api;
        _tokens = tokens;
        _passwordProtector = passwordProtector;
        _urlProvider = urlProvider;
    }

    public async Task<CalendarFileResult?> GenerateCalendarAsync(
        string roomName,
        int reminderMinutes = 10,
        string? overrideWebAppBaseUrl = null,
        string? overrideWebClientUrl = null,
        string? clientFallbackTimeZone = null)
    {
        var appName   = await ResolveConfigAsync("App:Name", _config["App:Name"] ?? "OATIConnect");
        // Caller's override wins — used by MeetingService.CreateAsync to
        // pin the same host string the email body uses, so the email
        // body URL and the attached .ics URL can never drift apart even
        // if the host's URL provider returns different values across
        // back-to-back calls in the same request.
        var webAppUrl = !string.IsNullOrWhiteSpace(overrideWebAppBaseUrl)
            ? overrideWebAppBaseUrl!.TrimEnd('/')
            : ResolveWebAppUrl();

        // Web-client URL — the generic /oaticonnect/join page recipients
        // visit if the one-click link isn't available (forwarded by SMS,
        // copy-pasted into chat, etc.). Admin can override via
        // Pref:Meeting:WebClientUrl; default is the host's own page.
        var webClientUrl = !string.IsNullOrWhiteSpace(overrideWebClientUrl)
            ? overrideWebClientUrl!.TrimEnd('/')
            : await ResolveWebClientUrlAsync(webAppUrl);

        var meeting = await _data.GetActiveMeetingByRoomNameAsync(roomName);
        if (meeting == null) return null;

        // Owner-only: only the host of the meeting can download its .ics.
        var currentUser = await _userProvider.GetCurrentUserAsync();
        if (currentUser == null || meeting.HostUserId != currentUser.Id)
            return null;

        var startUtc = DateTime.SpecifyKind(meeting.ScheduledTimeUtc, DateTimeKind.Utc);
        var endUtc   = startUtc.AddMinutes(meeting.DurationMinutes > 0 ? meeting.DurationMinutes : 60);

        // Resolve the organizer's zone for DTSTART;TZID + VTIMEZONE
        // rendering. Priority MUST match the DESCRIPTION label
        // (ResolveTimeZone): host profile IANA → host profile Windows →
        // client-sent browser zone → UTC. The client fallback is the
        // load-bearing case for HOSTED integrations (e.g. OATIHub) where
        // the host's IExternalUserProvider adapter doesn't populate a
        // timezone — without it the event time fell back to UTC-Z even
        // though the browser told us the zone via ?tz=. UTC fallback (null)
        // still produces a valid .ics; it just renders DTSTART verbatim.
        var hostTz = ResolveTimeZone(currentUser, clientFallbackTimeZone);

        // Subject is the meeting title verbatim — Zoom-style, no
        // "OATIConnect:" prefix, no embedded Meeting ID. Both surfaces
        // (mailbox preview + calendar row) read clean.
        var subject = meeting.Title;

        // Plain-text DESCRIPTION for Outlook's reading pane and other clients
        // that don't render the HTML body. \\n is the ICS line-break literal
        // (single backslash + n inside the .ics file), which Outlook unfolds.
        //
        // Share URL format mirrors what MeetingService + MeetingsController
        // emit (driven by Pref:Meeting:EncryptedShareLink). Off → short
        // /oaticonnect/{meetingCode}; on → opaque /oaticonnect/j/{token}.
        // Calendar apps surface URL as a clickable link, and DESCRIPTION
        // inlines it so plain-text views still expose it.
        // Plain form sits at the literal root — webAppUrl already
        // includes the host's basePath, so we append just /{code} for
        // a clean single-prefix URL like https://host/oaticonnect/{code}
        // instead of the double-prefix /oaticonnect/oaticonnect/{code}.
        // Decrypt the meeting password (if any) FIRST. Needed both for
        // the inline DESCRIPTION display below AND to seal into the
        // encrypted share token when the admin has opted in.
        var plaintextPassword = _passwordProtector.Unprotect(meeting.Password);

        var encryptedShareLink = await IsEncryptedShareLinkEnabledAsync();
        // Mirror MeetingService.SendInviteEmailsAsync — when both the
        // EmbedPasswordInLink pref AND the meeting has a password, seal
        // the password into the encrypted share token so recipients
        // click the link and skip the prejoin password prompt. Without
        // this the email body's link auto-fills but the .ics link
        // doesn't — confusingly inconsistent.
        var embedPassword = encryptedShareLink
            && await IsEmbedPasswordInLinkEnabledAsync()
            && !string.IsNullOrEmpty(plaintextPassword);
        var shareUrl = encryptedShareLink
            ? $"{webAppUrl}/oaticonnect/j/{_tokens.Create(meeting.Id, embedPassword ? plaintextPassword : null)}"
            : $"{webAppUrl}/{meeting.MeetingCode}";

        // Date + time labels in the host's IANA zone:
        //   "Friday, 22 May 2026"
        //   "20:48 – 21:48 GMT-5"
        var durationMin = meeting.DurationMinutes > 0 ? meeting.DurationMinutes : 60;
        var (dateLabel, timeLabel) = FormatHostDateTimeLabels(startUtc, endUtc, currentUser, clientFallbackTimeZone);

        // ----- Plain-text DESCRIPTION -----
        // Zoom-style invitation body. Single source of truth across all
        // three sharing surfaces (server email, .ics, dashboard mailto).
        // Four separator widths, all hard-coded to the host's signed-off
        // draft (do NOT derive from heading lengths):
        //   OUTER_TOP    (75)   ribbon above + below the greeting,
        //   INNER        (39)   underlines Meeting Details + Join-link,
        //   INNER_WEB    (61)   underlines the web-client heading,
        //   OUTER_BOTTOM (102)  closing ribbon at the foot of the card.
        // No blank lines between sections — dashes do all the visual work.
        var hostName    = string.IsNullOrWhiteSpace(currentUser.Name) ? "The host" : currentUser.Name;
        var outerTop    = new string('-', 75);
        var outerBottom = new string('-', 102);
        var innerShort  = new string('-', 39);
        var innerLong   = new string('-', 61);
        var webHeading  = $"Join meeting using {appName} Web Client";
        var meetingIdDisplay = MeetingService.FormatMeetingCodeForDisplay(meeting.MeetingCode);

        var lines = new List<string>
        {
            outerTop,
            $"{hostName} is inviting you to {appName} meeting.",
            outerTop,
            "Meeting Details:",
            innerShort,
            $" Topic: {meeting.Title}",
            $" Date: {dateLabel}",
            $" Time: {timeLabel}",
            innerShort,
            $" Meeting Id : {meetingIdDisplay}",
        };
        if (!string.IsNullOrEmpty(plaintextPassword))
            lines.Add($" Password   : {plaintextPassword}");
        lines.Add(innerShort);
        lines.Add("");
        lines.Add("Join meeting with link");
        lines.Add(innerShort);
        lines.Add($"  {shareUrl}");
        lines.Add("");
        // Web-client heading is sandwiched between two innerLong ribbons
        // so it stands apart from the link-share section above. The
        // closing bottom outer ribbon follows the instructions line.
        lines.Add(innerLong);
        lines.Add(webHeading);
        lines.Add(innerLong);
        lines.Add($"  {webClientUrl}");
        lines.Add("  Enter the Meeting ID and password on that page to join from any browser.");
        lines.Add(outerBottom);
        var description = string.Join("\\n", lines);

        // ----- HTML alt-desc (Outlook editable-meeting view) -----
        // Wraps the SAME plain-text lines in <pre> so the dashed
        // separators and aligned label columns stay column-perfect in
        // Outlook's editable-meeting view — without the formatting
        // collapse you'd get from HTML's default whitespace handling.
        // URLs are upgraded to clickable <a> tags but everything else
        // stays a 1:1 visual copy of the DESCRIPTION above.
        var shareUrlHtml  = System.Net.WebUtility.HtmlEncode(shareUrl);
        var webClientHtml = System.Net.WebUtility.HtmlEncode(webClientUrl);
        var htmlLines = lines.Select(l =>
            l.TrimStart() == shareUrl     ? l.Replace(shareUrl,     $"<a href=\"{shareUrlHtml}\">{shareUrlHtml}</a>")
            : l.TrimStart() == webClientUrl ? l.Replace(webClientUrl, $"<a href=\"{webClientHtml}\">{webClientHtml}</a>")
            : System.Net.WebUtility.HtmlEncode(l));
        var htmlBody =
            "<html><body><pre style=\"font-family:'Segoe UI',Tahoma,sans-serif;font-size:13px;line-height:1.55;margin:0;white-space:pre-wrap;\">"
            + string.Join("\n", htmlLines)
            + "</pre></body></html>";
        // RFC 5545: ',' and ';' inside a property VALUE must be escaped;
        // CRLF newlines collapse into the \n escape; backslash doubles.
        var htmlForIcs = htmlBody
            .Replace("\\", "\\\\")
            .Replace(",", "\\,")
            .Replace(";", "\\;")
            .Replace("\r", "")
            .Replace("\n", "\\n");

        // METHOD:PUBLISH + ORGANIZER (no ATTENDEEs) — Outlook opens this as
        // an editable meeting draft owned by the user, with the To field
        // enabled, so the host can forward to attendees.
        var icsLines = new List<string>
        {
            "BEGIN:VCALENDAR",
            "VERSION:2.0",
            $"PRODID:-//{appName}//Calendar//EN",
            "CALSCALE:GREGORIAN",
            "METHOD:PUBLISH",
        };

        // VTIMEZONE block + DTSTART;TZID lets Outlook / Google / Apple
        // Calendar display the time in the organizer's wall-clock with
        // the correct DST abbreviation. This was the format working
        // before the X-ALT-DESC and BOM detours — restored verbatim.
        if (hostTz != null)
        {
            icsLines.AddRange(BuildVTimezone(hostTz, hostTz.Id, startUtc));
        }

        var startToken = hostTz != null
            ? $"DTSTART;TZID={hostTz.Id}:{TimeZoneInfo.ConvertTimeFromUtc(startUtc, hostTz):yyyyMMddTHHmmss}"
            : $"DTSTART:{startUtc:yyyyMMddTHHmmssZ}";
        var endToken = hostTz != null
            ? $"DTEND;TZID={hostTz.Id}:{TimeZoneInfo.ConvertTimeFromUtc(endUtc, hostTz):yyyyMMddTHHmmss}"
            : $"DTEND:{endUtc:yyyyMMddTHHmmssZ}";

        icsLines.AddRange(new[]
        {
            "BEGIN:VEVENT",
            $"UID:{meeting.Id}",
            $"DTSTAMP:{DateTime.UtcNow:yyyyMMddTHHmmssZ}",
            startToken,
            endToken,
            $"SUMMARY:{subject}",
            $"ORGANIZER;CN={currentUser.Name}:mailto:{currentUser.Email}",
            $"DESCRIPTION:{description}",
            $"X-ALT-DESC;FMTTYPE=text/html:{htmlForIcs}",
            $"URL:{shareUrl}",
            $"LOCATION:{appName}",
            "STATUS:CONFIRMED",
            // Monotonic revision number. The UID is stable per meeting
            // (UID:{meeting.Id}), so a re-shared .ics already matches the
            // existing calendar entry by UID — but Outlook/Google only
            // APPLY the update when SEQUENCE is greater than the copy they
            // hold. With no persisted revision counter on the Meeting, we
            // derive one from whole minutes since creation: it never
            // decreases, and every re-share after an edit lands a higher
            // value, so the override actually takes effect instead of being
            // silently dropped as "stale".
            $"SEQUENCE:{Math.Max(0, (long)(DateTime.UtcNow - meeting.CreatedAtUtc).TotalMinutes)}",
        });

        // Recurrence: emit the RFC-5545 RRULE so Outlook / Google /
        // Apple Calendar expand the series natively. We don't ship one
        // VEVENT per occurrence — the rule does the work, and editing
        // the series later just rewrites the rule.
        var rrule = RecurrenceCalculator.BuildRRule(meeting);
        if (rrule != null) icsLines.Add(rrule);

        if (reminderMinutes > 0)
        {
            icsLines.Add("BEGIN:VALARM");
            icsLines.Add($"TRIGGER:-PT{reminderMinutes}M");
            icsLines.Add("ACTION:DISPLAY");
            icsLines.Add("DESCRIPTION:Reminder");
            icsLines.Add("END:VALARM");
        }

        icsLines.Add("END:VEVENT");
        icsLines.Add("END:VCALENDAR");

        // Folding intentionally NOT applied. Outlook 2013 has a
        // long-standing bug where its unfold-then-escape pipeline
        // mis-handles the embedded \n escapes when a fold boundary
        // lands inside the DESCRIPTION value — adjacent text on the
        // continuation line gets collapsed and the file fails to load.
        // Now that the X-ALT-DESC HTML payload is gone, no single line
        // exceeds ~800 chars, well inside Outlook's per-line buffer
        // (~8 KB) and Apple/Google Calendar tolerate long content lines
        // just fine. RFC 5545 says SHOULD fold at 75 octets — not MUST.
        var ics = string.Join("\r\n", icsLines) + "\r\n";

        // No UTF-8 BOM. Outlook 2013 reads .ics as Windows-1252 by
        // default and sees the BOM bytes (EF BB BF) as garbage before
        // BEGIN:VCALENDAR, then refuses to load the file. Our content
        // is ASCII-clean so plain UTF-8 (= ASCII) is unambiguous to
        // every parser without a BOM.
        var bytes = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false).GetBytes(ics);

        return new CalendarFileResult
        {
            Content  = bytes,
            FileName = $"meet-{meeting.MeetingCode}.ics",
        };
    }

    /// <summary>
    /// RFC 5545 §3.1 line folding. Splits a content line into chunks of
    /// at most 75 octets, joined by CRLF + a leading space on every
    /// continuation. The receiver's unfold step removes the CRLF + space
    /// to reassemble the original line.
    ///
    /// Carefully avoids ending a chunk on a lone backslash so escape
    /// sequences (\n, \,, \;, \\) stay intact across the fold — Outlook
    /// has historically mis-rendered \n when its unfolder splits the
    /// escape into two adjacent lines.
    /// </summary>
    private static IEnumerable<string> FoldIcsLine(string line)
    {
        if (string.IsNullOrEmpty(line)) { yield return line; yield break; }
        // Operate on UTF-8 octet count rather than .NET char count so a
        // line ending mid-codepoint can't slip through.
        var bytes = Encoding.UTF8.GetBytes(line);
        if (bytes.Length <= 75) { yield return line; yield break; }

        int pos = 0;
        bool first = true;
        while (pos < bytes.Length)
        {
            // First chunk gets the full 75 octets; subsequent chunks lose
            // 1 octet to the leading-space continuation marker.
            int budget = first ? 75 : 74;
            int end    = Math.Min(pos + budget, bytes.Length);

            // Don't end a chunk mid-UTF-8 codepoint. Walk back until the
            // next byte is a UTF-8 start byte (top two bits != 10).
            while (end < bytes.Length && (bytes[end] & 0xC0) == 0x80) end--;

            // Don't end with a lone backslash — that's almost always the
            // start of an iCal escape (\n, \,, \;, \\). Push the backslash
            // to the next chunk so the pair stays together.
            if (end < bytes.Length && bytes[end - 1] == (byte)'\\') end--;

            var chunk = Encoding.UTF8.GetString(bytes, pos, end - pos);
            yield return first ? chunk : " " + chunk;
            pos   = end;
            first = false;
        }
    }

    /// <summary>
    /// Emits a minimal VTIMEZONE block for the supplied zone, describing
    /// only the rule active around the meeting instant. RFC 5545 requires
    /// TZOFFSETFROM / TZOFFSETTO on every STANDARD/DAYLIGHT sub-component;
    /// .NET's <see cref="TimeZoneInfo.GetAdjustmentRules"/> gives us the
    /// transition for the relevant year so calendar apps render the right
    /// abbreviation across the DST boundary. Always emits both STANDARD
    /// and (when applicable) DAYLIGHT so a meeting straddling a transition
    /// still localizes correctly. Falls back to a single STANDARD block
    /// when the zone never observes DST (e.g. UTC, India, Arizona).
    /// </summary>
    private static IEnumerable<string> BuildVTimezone(TimeZoneInfo tz, string tzId, DateTime utc)
    {
        var lines = new List<string>
        {
            "BEGIN:VTIMEZONE",
            $"TZID:{tzId}",
        };

        var year      = utc.Year;
        var rule      = FindAdjustmentRule(tz, utc);
        var stdOffset = tz.BaseUtcOffset;
        var dstOffset = stdOffset + (rule?.DaylightDelta ?? TimeSpan.Zero);

        if (rule == null || rule.DaylightDelta == TimeSpan.Zero)
        {
            // Non-DST zone — single STANDARD block with the canonical offset.
            lines.Add("BEGIN:STANDARD");
            lines.Add("DTSTART:19700101T000000");
            lines.Add($"TZOFFSETFROM:{FormatOffset(stdOffset)}");
            lines.Add($"TZOFFSETTO:{FormatOffset(stdOffset)}");
            lines.Add($"TZNAME:{tz.StandardName}");
            lines.Add("END:STANDARD");
        }
        else
        {
            // DST zone — emit both transitions for the meeting's year.
            var dstStart = TransitionDate(rule.DaylightTransitionStart, year);
            var dstEnd   = TransitionDate(rule.DaylightTransitionEnd,   year);

            lines.Add("BEGIN:DAYLIGHT");
            lines.Add($"DTSTART:{dstStart:yyyyMMddTHHmmss}");
            lines.Add($"TZOFFSETFROM:{FormatOffset(stdOffset)}");
            lines.Add($"TZOFFSETTO:{FormatOffset(dstOffset)}");
            lines.Add($"TZNAME:{tz.DaylightName}");
            lines.Add("END:DAYLIGHT");

            lines.Add("BEGIN:STANDARD");
            lines.Add($"DTSTART:{dstEnd:yyyyMMddTHHmmss}");
            lines.Add($"TZOFFSETFROM:{FormatOffset(dstOffset)}");
            lines.Add($"TZOFFSETTO:{FormatOffset(stdOffset)}");
            lines.Add($"TZNAME:{tz.StandardName}");
            lines.Add("END:STANDARD");
        }

        lines.Add("END:VTIMEZONE");
        return lines;
    }

    private static TimeZoneInfo.AdjustmentRule? FindAdjustmentRule(TimeZoneInfo tz, DateTime utc)
    {
        var local = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utc, DateTimeKind.Utc), tz);
        foreach (var r in tz.GetAdjustmentRules())
            if (local >= r.DateStart && local <= r.DateEnd)
                return r;
        return null;
    }

    private static DateTime TransitionDate(TimeZoneInfo.TransitionTime t, int year)
    {
        if (t.IsFixedDateRule)
            return new DateTime(year, t.Month, t.Day, t.TimeOfDay.Hour, t.TimeOfDay.Minute, t.TimeOfDay.Second);

        // Floating rule: e.g. "second Sunday in March". Walk to that week.
        var first = new DateTime(year, t.Month, 1);
        var firstWanted = ((int)t.DayOfWeek - (int)first.DayOfWeek + 7) % 7;
        var day = 1 + firstWanted + (t.Week - 1) * 7;
        var lastDay = DateTime.DaysInMonth(year, t.Month);
        if (day > lastDay) day -= 7; // "last X" — Week==5 sometimes overshoots
        return new DateTime(year, t.Month, day, t.TimeOfDay.Hour, t.TimeOfDay.Minute, t.TimeOfDay.Second);
    }

    private static string FormatOffset(TimeSpan offset)
    {
        var sign = offset.Ticks >= 0 ? "+" : "-";
        var abs  = offset.Duration();
        return $"{sign}{abs.Hours:D2}{abs.Minutes:D2}";
    }

    /// <summary>
    /// Reads a key from <c>OATIConnect_Configs</c>, falling back to the
    /// supplied default when the row is missing or empty. Centralises the
    /// "prefer DB over config file" pattern for App:* settings.
    /// </summary>
    private async Task<string> ResolveConfigAsync(string key, string fallback)
    {
        var row = await _data.GetAppConfigByKeyAsync(key);
        return string.IsNullOrWhiteSpace(row?.Value) ? fallback : row!.Value;
    }

    /// <summary>
    /// Mirrors MeetingService.IsEncryptedShareLinkEnabledAsync — defaults
    /// to true when the row is missing so all three share-URL emitters
    /// (this .ics, the email body, and the share-link controller) agree
    /// on format. Without this, the host's "copy link" returned a short
    /// URL but the calendar invitation kept the opaque one.
    /// </summary>
    private async Task<bool> IsEncryptedShareLinkEnabledAsync()
    {
        var row = await _data.GetAppConfigByKeyAsync("Pref:Meeting:EncryptedShareLink");
        if (row?.Value == null) return true;
        return !bool.TryParse(row.Value, out var b) || b;
    }

    /// <summary>
    /// Mirrors MeetingService.IsEmbedPasswordInLinkEnabledAsync exactly
    /// — same key, same default (false when missing). Keeping the two
    /// reads identical guarantees the email body's encrypted link and
    /// the .ics encrypted link always agree on whether the password
    /// is sealed in. Drift here would silently produce one-click join
    /// in the email but a prejoin password prompt from the .ics.
    /// </summary>
    private async Task<bool> IsEmbedPasswordInLinkEnabledAsync()
    {
        var row = await _data.GetAppConfigByKeyAsync("Pref:Meeting:EmbedPasswordInLink");
        return bool.TryParse(row?.Value, out var b) && b;
    }

    /// <summary>
    /// Mirrors MeetingService.ResolveWebClientUrlAsync — preferred
    /// override from <c>Pref:Meeting:WebClientUrl</c>, else default to
    /// the host's own <c>{webAppUrl}/oaticonnect/join</c>.
    /// </summary>
    private async Task<string> ResolveWebClientUrlAsync(string webAppUrl)
    {
        var row = await _data.GetAppConfigByKeyAsync("Pref:Meeting:WebClientUrl");
        var configured = row?.Value;
        if (!string.IsNullOrWhiteSpace(configured)) return configured.TrimEnd('/');
        return $"{webAppUrl.TrimEnd('/')}/oaticonnect/join";
    }

    private string ResolveWebAppUrl()
    {
        var dynamicUrl = _urlProvider.GetWebAppBaseUrl();
        if (!string.IsNullOrWhiteSpace(dynamicUrl)) return dynamicUrl.TrimEnd('/');
        var sidecar = OATIConnect.API.DependencyInjection.SidecarConfigLoader.TryLoad();
        if (!string.IsNullOrWhiteSpace(sidecar?.App?.WebAppUrl)) return sidecar!.App.WebAppUrl.TrimEnd('/');
        var adminConfigured = _config["App:WebAppUrl"];
        if (!string.IsNullOrWhiteSpace(adminConfigured)) return adminConfigured.TrimEnd('/');
        var legacy = _config["webAppUrl"];
        if (!string.IsNullOrWhiteSpace(legacy)) return legacy.TrimEnd('/');
        return "http://localhost:5000";
    }

    /// <summary>
    /// Renders the meeting start in the host's wall-clock as two
    /// separate labels suited to the Zoom-style invitation template:
    ///   Date  → "Friday, 22 May 2026"      (day-month-year)
    ///   Time  → "20:48 – 21:48 GMT-5"      (24-hour, no parens)
    /// Falls back to UTC formatting when the host's zone isn't known.
    /// </summary>
    private static (string Date, string Time) FormatHostDateTimeLabels(
        DateTime startUtc, DateTime endUtc, ExternalUserInfo host,
        string? clientFallbackTimeZone = null)
    {
        var culture = System.Globalization.CultureInfo.InvariantCulture;
        const string dateFmt = "dddd, d MMMM yyyy";
        const string timeFmt = "HH:mm";

        var tz = ResolveTimeZone(host, clientFallbackTimeZone);
        if (tz == null)
        {
            var dStr = DateTime.SpecifyKind(startUtc, DateTimeKind.Utc).ToString(dateFmt, culture);
            var tStr = $"{DateTime.SpecifyKind(startUtc, DateTimeKind.Utc).ToString(timeFmt, culture)} – {DateTime.SpecifyKind(endUtc, DateTimeKind.Utc).ToString(timeFmt, culture)} UTC";
            return (dStr, tStr);
        }
        var startLoc = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(startUtc, DateTimeKind.Utc), tz);
        var endLoc   = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(endUtc,   DateTimeKind.Utc), tz);
        // Label the time with the host's actual timezone NAME (e.g.
        // "Central Daylight Time") rather than a bare "GMT-5" offset —
        // recipients asked to see the logged-in user's timezone, not GMT.
        var zoneLabel = FormatZoneLabel(tz, startLoc);
        var dateStr  = startLoc.ToString(dateFmt, culture);
        var timeStr  = $"{startLoc.ToString(timeFmt, culture)} – {endLoc.ToString(timeFmt, culture)} {zoneLabel}";
        return (dateStr, timeStr);
    }

    /// <summary>
    /// Friendly timezone label for a given local instant: the zone's
    /// Daylight or Standard display name depending on whether DST is in
    /// effect (e.g. "Central Daylight Time" vs "Central Standard Time").
    /// Falls back to the zone id when the platform supplies no display
    /// name. Used to render the host's wall-clock zone in the invitation
    /// instead of a generic GMT offset.
    /// </summary>
    internal static string FormatZoneLabel(TimeZoneInfo tz, DateTime localInstant)
    {
        var name = tz.IsDaylightSavingTime(localInstant) ? tz.DaylightName : tz.StandardName;
        return string.IsNullOrWhiteSpace(name) ? tz.Id : name;
    }

    /// <summary>
    /// Resolves the timezone the invitation body should be rendered in.
    /// Priority: host's profile IANA → host's profile Windows → client-
    /// sent browser timezone (fallback supplied via clientFallbackTimeZone
    /// argument). Returns null when nothing resolves, so callers fall
    /// back to UTC formatting.
    /// </summary>
    internal static TimeZoneInfo? ResolveTimeZone(ExternalUserInfo host, string? clientFallback)
    {
        foreach (var candidate in new[] {
            host.TimeZoneIana,
            host.TimeZoneWindows,
            clientFallback,
        })
        {
            if (string.IsNullOrWhiteSpace(candidate)) continue;
            try { return TimeZoneInfo.FindSystemTimeZoneById(candidate); }
            catch { /* try the next one */ }
        }
        return null;
    }

    private static string FormatHostLocalTimeIcs(DateTime utc, ExternalUserInfo host)
    {
        var zoneId = !string.IsNullOrWhiteSpace(host.TimeZoneIana)    ? host.TimeZoneIana
                   : !string.IsNullOrWhiteSpace(host.TimeZoneWindows) ? host.TimeZoneWindows
                   : "";
        if (string.IsNullOrWhiteSpace(zoneId))
            return DateTime.SpecifyKind(utc, DateTimeKind.Utc).ToString("dddd, d MMMM yyyy 'at' HH:mm 'UTC'");

        try
        {
            var tz     = TimeZoneInfo.FindSystemTimeZoneById(zoneId);
            var local  = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utc, DateTimeKind.Utc), tz);
            var off    = tz.GetUtcOffset(local);
            var sign   = off.Ticks >= 0 ? "+" : "-";
            var abs    = off.Duration();
            var offStr = abs.Minutes == 0 ? $"GMT{sign}{abs.Hours}" : $"GMT{sign}{abs.Hours}:{abs.Minutes:D2}";
            return local.ToString("dddd, d MMMM yyyy 'at' HH:mm") + " " + offStr;
        }
        catch
        {
            return DateTime.SpecifyKind(utc, DateTimeKind.Utc).ToString("dddd, d MMMM yyyy 'at' HH:mm 'UTC'");
        }
    }
}
