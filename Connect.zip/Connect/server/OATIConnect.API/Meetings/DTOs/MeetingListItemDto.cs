namespace OATIConnect.API.Meetings.DTOs;

public class MeetingListItemDto
{
	public Guid MeetingId { get; set; }
	public string Title       { get; set; } = default!;
	public string? Description { get; set; }
	public DateTime ScheduledTimeUtc { get; set; }
	public string Status      { get; set; } = default!;
	public bool IsHost        { get; set; }
	public string MeetingCode { get; set; } = default!;
	public int DurationMinutes { get; set; }

	
	public List<string> InviteeEmails { get; set; } = new();

	
	public bool PasswordRequired { get; set; }

	
	public string? Password { get; set; }

	
	public bool RequireHostStart { get; set; }

	
	public int RecurrenceType { get; set; }
	public int RecurrenceInterval { get; set; } = 1;
	public int RecurrenceDaysOfWeekMask { get; set; }
	public int RecurrenceEndType { get; set; }
	public int? RecurrenceEndCount { get; set; }
	public DateTime? RecurrenceEndDateUtc { get; set; }

	
	public DateTime? NextOccurrenceUtc { get; set; }
}
