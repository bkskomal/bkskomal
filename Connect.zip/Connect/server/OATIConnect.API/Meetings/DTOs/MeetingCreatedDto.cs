﻿namespace OATIConnect.API.Meetings.DTOs;

public class MeetingCreatedDto
{
	public Guid MeetingId { get; set; }
	public string MeetingCode { get; set; } = default!;
	public string RoomName { get; set; } = default!;
	public DateTime ScheduledTimeUtc { get; set; }
}
