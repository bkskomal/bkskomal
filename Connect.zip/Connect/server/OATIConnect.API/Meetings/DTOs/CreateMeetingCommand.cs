namespace OATIConnect.API.Meetings.DTOs;

public class CreateMeetingCommand
{
	public string Title { get; set; } = default!;
	/// <summary>
	/// Optional client-supplied 10-digit Meeting ID, used so the
	/// Schedule modal can show the code up-front Zoom-style. When
	/// missing or malformed, the server generates a fresh one.
	/// Stored verbatim in <see cref="Domain.Entities.Meeting.MeetingCode"/>.
	/// </summary>
	public string? MeetingCode { get; set; }
	/// <summary>
	/// Optional client browser timezone (Intl.DateTimeFormat
	/// resolvedOptions().timeZone — e.g. "America/Chicago"). Used as
	/// a fallback when the host's stored profile timezone is empty
	/// or unrecognised by the runtime — so the email body + .ics
	/// still display times in the host's actual wall-clock instead
	/// of falling back to UTC.
	/// </summary>
	public string? ClientTimeZone { get; set; }
	public string? Description { get; set; }
	public DateTime ScheduledTimeUtc { get; set; }
	public int DurationMinutes { get; set; }

	public List<string> InviteeIds { get; set; } = new();

	public List<string> InviteeEmails { get; set; } = new();

	
	public string? Password { get; set; }

	public bool RequireHostStart { get; set; }


	/// <summary>0=None, 1=Daily, 2=Weekly, 3=Monthly. None ⇒ single occurrence.</summary>
	public int RecurrenceType { get; set; } = 0;
	/// <summary>"Every N" multiplier. 1 = every day/week/month, 2 = every other, etc. Min 1.</summary>
	public int RecurrenceInterval { get; set; } = 1;
	/// <summary>Weekday bitmask for weekly pattern: Sun=1, Mon=2, Tue=4, Wed=8, Thu=16, Fri=32, Sat=64.</summary>
	public int RecurrenceDaysOfWeekMask { get; set; }
	/// <summary>0=Never, 1=After N occurrences, 2=On a date.</summary>
	public int RecurrenceEndType { get; set; } = 0;
	/// <summary>Occurrence count when EndType=After. Null otherwise.</summary>
	public int? RecurrenceEndCount { get; set; }
	/// <summary>Last allowed date (UTC) when EndType=OnDate. Null otherwise.</summary>
	public DateTime? RecurrenceEndDateUtc { get; set; }
}
