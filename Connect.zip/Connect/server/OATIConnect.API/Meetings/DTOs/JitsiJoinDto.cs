﻿namespace OATIConnect.API.Meetings.DTOs;

public class JitsiJoinDto
{
	public Guid MeetingId { get; set; }
	public string ServerUrl { get; set; } = default!;
	public string RoomName { get; set; } = default!;
	public string Jwt { get; set; } = default!;
	public string DisplayName { get; set; } = default!;
	public bool IsModerator { get; set; }
	public int DurationMinutes { get; set; }
	public DateTime? ActualStartUtc { get; set; }
	public string Status { get; set; } = default!;

	
	public string Password { get; set; } = "";
}
