namespace OATIConnect.API.Meetings.DTOs;

public class ParticipantDto
{
    public Guid Id { get; set; }
    public int  UserId { get; set; }
    public string Name  { get; set; } = default!;
    public string Email { get; set; } = default!;
    public DateTime JoinedAtUtc { get; set; }
}
