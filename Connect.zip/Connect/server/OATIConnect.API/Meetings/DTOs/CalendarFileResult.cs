﻿namespace OATIConnect.API.Meetings.DTOs;

public class CalendarFileResult
{
	public byte[] Content { get; set; } = default!;
	// Content-Type must include both method= and charset= parameters
	// for Outlook 2013 to invoke its iCal handler — bare "text/calendar"
	// makes some Outlook builds fall back to text/plain rendering and
	// the user sees raw VCALENDAR text in a notepad-style window
	// instead of the meeting opening up in the calendar.
	public string ContentType { get; set; } = "text/calendar; method=PUBLISH; charset=utf-8";
	public string FileName { get; set; } = default!;
}
