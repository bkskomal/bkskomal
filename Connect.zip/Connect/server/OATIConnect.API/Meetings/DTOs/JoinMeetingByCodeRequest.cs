﻿public class JoinMeetingByCodeRequest
{
	public string MeetingCode { get; set; } = string.Empty;
	public Guid? ParticipantId { get; set; }  // For guest Flow
	public string? DisplayName { get; set; }  // Guest Name
}
