namespace OATIConnect.API.Meetings.DTOs;

public class UpdateMeetingCommand
{
	public string Title { get; set; } = default!;
	public string? Description { get; set; }
	public DateTime ScheduledTimeUtc { get; set; }
	public int DurationMinutes { get; set; } = 60;

	/// <summary>
	/// Optional client browser timezone (e.g. "Asia/Kolkata"). Fallback
	/// for the update-invite email + .ics formatting when the host's
	/// stored profile timezone is empty/unrecognised — mirrors
	/// <see cref="CreateMeetingCommand.ClientTimeZone"/> so edited
	/// meetings render in the user's wall-clock instead of UTC.
	/// </summary>
	public string? ClientTimeZone { get; set; }

	public List<string>? InviteeIds    { get; set; }
	public List<string>? InviteeEmails { get; set; }

	
	public string? Password { get; set; }

	
	public bool? RequireHostStart { get; set; }

	public int? RecurrenceType { get; set; }
	public int? RecurrenceInterval { get; set; }
	public int? RecurrenceDaysOfWeekMask { get; set; }
	public int? RecurrenceEndType { get; set; }
	public int? RecurrenceEndCount { get; set; }
	public DateTime? RecurrenceEndDateUtc { get; set; }
}
