﻿using Microsoft.Extensions.Configuration;
using OATIConnect.API.Common;
using OATIConnect.API.Exchange;
using OATIConnect.API.Meetings;
using OATIConnect.API.Meetings.DTOs;
using OATIConnect.API.Settings;
using OATIConnect.API.Domain.Entities;

namespace OATIConnect.API.Meetings;

public class MeetingService : IMeetingService
{
	
	private readonly IOATIConnectExternalAPI _data;
	private readonly IOATIConnectExternalAPI _userProvider;
	private readonly IExchangeDirectoryService _exchange;
	private readonly IMeetingCalendarService _calendar;
	private readonly IAppSettingsService _settings;
	private readonly IConfiguration _config;
	private readonly IMeetingShareTokenService _tokens;
	private readonly IMeetingPasswordProtector _passwordProtector;
	private readonly IHostPresenceTracker _hostPresence;
	private readonly IOATIConnectRequestUrlProvider _urlProvider;

	public MeetingService(
		IOATIConnectExternalAPI api,
		IExchangeDirectoryService exchange,
		IMeetingCalendarService calendar,
		IAppSettingsService settings,
		IConfiguration config,
		IMeetingShareTokenService tokens,
		IMeetingPasswordProtector passwordProtector,
		IHostPresenceTracker hostPresence,
		IOATIConnectRequestUrlProvider urlProvider)
	{
		_data              = api;
		_userProvider      = api;
		_exchange          = exchange;
		_calendar          = calendar;
		_settings          = settings;
		_config            = config;
		_tokens            = tokens;
		_passwordProtector = passwordProtector;
		_hostPresence      = hostPresence;
		_urlProvider       = urlProvider;
	}

	private async Task<string> ResolveAppConfigAsync(string key, string fallback)
	{
		var row = await _settings.GetByKeyAsync(key);
		return string.IsNullOrWhiteSpace(row?.Value) ? fallback : row!.Value;
	}

	
	private async Task<bool> IsPasswordFeatureEnabledAsync()
	{
		var row = await _settings.GetByKeyAsync("Pref:Meeting:EnablePassword");
		return bool.TryParse(row?.Value, out var b) && b;
	}

	
	private async Task<bool> IsHostStartFeatureEnabledAsync()
	{
		var row = await _settings.GetByKeyAsync("Pref:Meeting:RequireHostStart");
		return bool.TryParse(row?.Value, out var b) && b;
	}

	
	private async Task<bool> IsEncryptedShareLinkEnabledAsync()
	{
		var row = await _settings.GetByKeyAsync("Pref:Meeting:EncryptedShareLink");
		if (row?.Value == null) return true;
		return !bool.TryParse(row.Value, out var b) || b;
	}

	/// <summary>
	/// Reads <c>Pref:Meeting:EmbedPasswordInLink</c>. Defaults to FALSE
	/// when missing — opt-in feature. Only consulted when the share URL
	/// is encrypted; the plain /{code} form never embeds secrets.
	/// </summary>
	private async Task<bool> IsEmbedPasswordInLinkEnabledAsync()
	{
		var row = await _settings.GetByKeyAsync("Pref:Meeting:EmbedPasswordInLink");
		return bool.TryParse(row?.Value, out var b) && b;
	}

	/// <summary>
	/// Resolves the generic "join from the web" URL printed in
	/// invitations alongside the one-click share link. Falls back to
	/// the host's own <c>{portalUrl}/oaticonnect/join</c> when the
	/// admin hasn't set a branded override.
	/// </summary>
	private async Task<string> ResolveWebClientUrlAsync(string portalUrl)
	{
		var row = await _settings.GetByKeyAsync("Pref:Meeting:WebClientUrl");
		var configured = row?.Value;
		if (!string.IsNullOrWhiteSpace(configured)) return configured.TrimEnd('/');
		return $"{portalUrl.TrimEnd('/')}/oaticonnect/join";
	}

	public async Task<Result<MeetingCreatedDto>> CreateAsync(CreateMeetingCommand cmd)
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null)
			return Result<MeetingCreatedDto>.Failure("UNAUTHORIZED", "User not authenticated");

		var passwordEnabled = await IsPasswordFeatureEnabledAsync();
		var plaintextPassword = passwordEnabled
			? (string.IsNullOrWhiteSpace(cmd.Password) ? null : cmd.Password.Trim())
			: null;
		
		var storedPassword = _passwordProtector.Protect(plaintextPassword);

		
		var requireHostStart = await IsHostStartFeatureEnabledAsync() && cmd.RequireHostStart;

		var title = string.IsNullOrWhiteSpace(cmd.Title) ? "Meeting" : cmd.Title.Trim();

		// Dedup-on-create: a meeting the host already scheduled with the
		// SAME title and SAME start time is treated as an EDIT of that
		// meeting, not a brand-new one. Reusing the existing row keeps its
		// Id — and therefore the .ics UID — stable, so the re-shared invite
		// OVERRIDES the recipient's existing calendar entry instead of
		// dropping in a duplicate (every CreateAsync used to mint a fresh
		// Guid → fresh UID → calendars saw two distinct events). Only live
		// meetings (Scheduled/Active) are candidates; Ended/Cancelled rows
		// are left untouched so re-using a past name+time still makes a new
		// meeting.
		var existing = (await _data.GetVisibleMeetingsAsync(currentUser.Id, currentUser.Email))
			.FirstOrDefault(m =>
				m.HostUserId == currentUser.Id
				&& (m.Status == MeetingStatus.Scheduled || m.Status == MeetingStatus.Active)
				&& string.Equals(m.Title?.Trim(), title, StringComparison.OrdinalIgnoreCase)
				&& m.ScheduledTimeUtc == cmd.ScheduledTimeUtc);

		Meeting meeting;
		if (existing != null)
		{
			// Override in place — keep Id / MeetingCode / RoomName /
			// HostUserId / Status / CreatedAtUtc; refresh everything the
			// command can change so the new .ics carries the latest details.
			meeting = existing;
			meeting.Description      = cmd.Description;
			meeting.DurationMinutes  = cmd.DurationMinutes > 0 ? cmd.DurationMinutes : 60;
			meeting.Password         = storedPassword;
			meeting.RequireHostStart = requireHostStart;
			meeting.RecurrenceType            = (RecurrenceType)cmd.RecurrenceType;
			meeting.RecurrenceInterval        = cmd.RecurrenceInterval > 0 ? cmd.RecurrenceInterval : 1;
			meeting.RecurrenceDaysOfWeekMask  = cmd.RecurrenceDaysOfWeekMask;
			meeting.RecurrenceEndType         = (RecurrenceEndType)cmd.RecurrenceEndType;
			meeting.RecurrenceEndCount        = cmd.RecurrenceEndCount;
			meeting.RecurrenceEndDateUtc      = cmd.RecurrenceEndDateUtc;
			await _data.UpdateMeetingAsync(meeting);
		}
		else
		{
			// New model (2026-05): Title is the free-form human name the
			// host enters ("Weekly Standup"). MeetingCode is the numeric ID
			// used for join URLs and the "Meeting Id" field shown to
			// attendees. Accept a client-supplied code when it parses as
			// 9–12 digits (so the Schedule modal can show the code up-front
			// Zoom-style and the saved meeting matches what the host saw).
			// Falls back to a fresh server-generated code otherwise.
			// RoomName binds to MeetingCode so URL routing matches /{code}
			// (digits-only regex) and Jitsi gets a stable room id.
			var meetingCode = NormalizeMeetingCode(cmd.MeetingCode) ?? GenerateMeetingCode();
			meeting = new Meeting
			{
				Id               = Guid.NewGuid(),
				Title            = title,
				Description      = cmd.Description,
				ScheduledTimeUtc = cmd.ScheduledTimeUtc,
				DurationMinutes  = cmd.DurationMinutes > 0 ? cmd.DurationMinutes : 60,
				RoomName         = meetingCode,
				MeetingCode      = meetingCode,
				HostUserId       = currentUser.Id,
				Status           = MeetingStatus.Scheduled,
				Password         = storedPassword,
				RequireHostStart = requireHostStart,
				RecurrenceType            = (RecurrenceType)cmd.RecurrenceType,
				RecurrenceInterval        = cmd.RecurrenceInterval > 0 ? cmd.RecurrenceInterval : 1,
				RecurrenceDaysOfWeekMask  = cmd.RecurrenceDaysOfWeekMask,
				RecurrenceEndType         = (RecurrenceEndType)cmd.RecurrenceEndType,
				RecurrenceEndCount        = cmd.RecurrenceEndCount,
				RecurrenceEndDateUtc      = cmd.RecurrenceEndDateUtc,
			};

			await _data.AddMeetingAsync(meeting);
		}

		
		var invitees = await BuildInviteesAsync(cmd.InviteeIds, cmd.InviteeEmails);
		await _data.ReplaceInviteesAsync(meeting.Id, invitees);

		
		await SendInviteEmailsAsync(meeting, currentUser, invitees.Select(i => i.Email),
			clientFallbackTimeZone: cmd.ClientTimeZone);

		return Result<MeetingCreatedDto>.Success(new MeetingCreatedDto
		{
			MeetingId        = meeting.Id,
			MeetingCode      = meeting.MeetingCode,
			RoomName         = meeting.RoomName,
			ScheduledTimeUtc = meeting.ScheduledTimeUtc
		});
	}

	private async Task<IReadOnlyList<MeetingInvitee>> BuildInviteesAsync(
		IReadOnlyList<string>? graphIds, IReadOnlyList<string>? rawEmails)
	{
		var rows = new List<MeetingInvitee>();
		var resolved = (graphIds is { Count: > 0 })
			? await _exchange.ResolveEmailsAsync(graphIds)
			: Array.Empty<string>();

		foreach (var email in resolved)
			rows.Add(new MeetingInvitee { Email = email, SourceKind = "directory" });

		if (rawEmails != null)
			foreach (var email in rawEmails)
				if (!string.IsNullOrWhiteSpace(email))
					rows.Add(new MeetingInvitee { Email = email, SourceKind = "manual" });

		return rows;
	}

	public async Task<Result<IReadOnlyList<MeetingListItemDto>>> GetMyMeetingsAsync()
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null)
			return Result<IReadOnlyList<MeetingListItemDto>>.Success(new List<MeetingListItemDto>());

		var meetings = await _data.GetVisibleMeetingsAsync(currentUser.Id, currentUser.Email);

		var now = DateTime.UtcNow;
		var result = new List<MeetingListItemDto>(meetings.Count);
		foreach (var x in meetings)
		{
			var isHost = x.HostUserId == currentUser.Id;
			
			var invitees = isHost
				? (await _data.GetInviteesAsync(x.Id)).Select(i => i.Email).ToList()
				: new List<string>();

			DateTime? nextOccurrence = null;
			if (x.RecurrenceType != RecurrenceType.None)
			{
				var exceptions = await _data.GetOccurrenceExceptionsAsync(x.Id);
				var cancelled = exceptions
					.Where(e => e.Type == OccurrenceExceptionType.Cancelled)
					.Select(e => e.OriginalStartUtc)
					.ToList();
				nextOccurrence = RecurrenceCalculator.NextOccurrenceUtc(x, now, cancelled);
			}
			else
			{
				nextOccurrence = RecurrenceCalculator.NextOccurrenceUtc(x, now);
			}

			result.Add(new MeetingListItemDto
			{
				MeetingId        = x.Id,
				Title            = x.Title,
				Description      = x.Description,
				ScheduledTimeUtc = x.ScheduledTimeUtc,
				Status           = x.Status.ToString(),
				IsHost           = isHost,
				MeetingCode      = x.MeetingCode,
				DurationMinutes  = x.DurationMinutes,
				InviteeEmails    = invitees,
				PasswordRequired = !string.IsNullOrEmpty(x.Password),
				Password         = isHost ? _passwordProtector.Unprotect(x.Password) : null,
				RequireHostStart = x.RequireHostStart,
				RecurrenceType           = (int)x.RecurrenceType,
				RecurrenceInterval       = x.RecurrenceInterval,
				RecurrenceDaysOfWeekMask = x.RecurrenceDaysOfWeekMask,
				RecurrenceEndType        = (int)x.RecurrenceEndType,
				RecurrenceEndCount       = x.RecurrenceEndCount,
				RecurrenceEndDateUtc     = x.RecurrenceEndDateUtc,
				NextOccurrenceUtc        = nextOccurrence,
			});
		}

		return Result<IReadOnlyList<MeetingListItemDto>>.Success(result);
	}

	public async Task<Result<MeetingDetailsDto>> GetByIdAsync(Guid meetingId)
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		var currentUserId = currentUser?.Id ?? 0;

		var meeting = await _data.GetMeetingByIdAsync(meetingId);
		if (meeting == null)
			return Result<MeetingDetailsDto>.Failure("NOT_FOUND", "Meeting not found");
		if (meeting.HostUserId != currentUserId)
			return Result<MeetingDetailsDto>.Failure("FORBIDDEN", "Not your meeting");

		return Result<MeetingDetailsDto>.Success(new MeetingDetailsDto
		{
			MeetingId        = meeting.Id,
			Title            = meeting.Title,
			MeetingCode      = meeting.MeetingCode,
			ScheduledTimeUtc = meeting.ScheduledTimeUtc,
			Status           = meeting.Status.ToString(),
			IsLocked         = meeting.IsLocked,
			IsHost           = true,
		});
	}

	public async Task<Result> UpdateAsync(Guid meetingId, UpdateMeetingCommand cmd)
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null) return Result.Failure("UNAUTHORIZED", "User not authenticated");

		var meeting = await _data.GetMeetingByIdAsync(meetingId);
		if (meeting == null)
			return Result.Failure("NOT_FOUND", "Meeting not found");
		if (meeting.HostUserId != currentUser.Id)
			return Result.Failure("FORBIDDEN", "Only host can update meeting");

		meeting.Title            = cmd.Title;
		meeting.Description      = cmd.Description;
		meeting.ScheduledTimeUtc = cmd.ScheduledTimeUtc;
		if (cmd.DurationMinutes > 0)
			meeting.DurationMinutes = cmd.DurationMinutes;

		
		if (!await IsPasswordFeatureEnabledAsync())
		{
			meeting.Password = null;
		}
		else if (cmd.Password != null)
		{
			var trimmed = string.IsNullOrWhiteSpace(cmd.Password) ? null : cmd.Password.Trim();
			meeting.Password = _passwordProtector.Protect(trimmed);
		}

		
		if (!await IsHostStartFeatureEnabledAsync())
		{
			meeting.RequireHostStart = false;
		}
		else if (cmd.RequireHostStart.HasValue)
		{
			meeting.RequireHostStart = cmd.RequireHostStart.Value;
		}

		
		if (cmd.RecurrenceType.HasValue)           meeting.RecurrenceType           = (RecurrenceType)cmd.RecurrenceType.Value;
		if (cmd.RecurrenceInterval.HasValue)       meeting.RecurrenceInterval       = cmd.RecurrenceInterval.Value > 0 ? cmd.RecurrenceInterval.Value : 1;
		if (cmd.RecurrenceDaysOfWeekMask.HasValue) meeting.RecurrenceDaysOfWeekMask = cmd.RecurrenceDaysOfWeekMask.Value;
		if (cmd.RecurrenceEndType.HasValue)        meeting.RecurrenceEndType        = (RecurrenceEndType)cmd.RecurrenceEndType.Value;
		if (cmd.RecurrenceEndCount.HasValue)       meeting.RecurrenceEndCount       = cmd.RecurrenceEndCount.Value;
		if (cmd.RecurrenceEndDateUtc.HasValue)     meeting.RecurrenceEndDateUtc     = cmd.RecurrenceEndDateUtc.Value;
		
		if (meeting.RecurrenceType == RecurrenceType.None)
		{
			meeting.RecurrenceInterval       = 1;
			meeting.RecurrenceDaysOfWeekMask = 0;
			meeting.RecurrenceEndType        = RecurrenceEndType.Never;
			meeting.RecurrenceEndCount       = null;
			meeting.RecurrenceEndDateUtc     = null;
		}

		await _data.UpdateMeetingAsync(meeting);

		
		IReadOnlyList<string> newlyAddedEmails = Array.Empty<string>();
		if (cmd.InviteeIds != null || cmd.InviteeEmails != null)
		{
			var existing = (await _data.GetInviteesAsync(meetingId))
				.Select(i => i.Email).ToHashSet(StringComparer.OrdinalIgnoreCase);

			var invitees = await BuildInviteesAsync(cmd.InviteeIds, cmd.InviteeEmails);
			await _data.ReplaceInviteesAsync(meetingId, invitees);

			newlyAddedEmails = invitees
				.Select(i => i.Email)
				.Where(e => !string.IsNullOrWhiteSpace(e) && !existing.Contains(e))
				.ToList();
		}


		
		if (newlyAddedEmails.Count > 0)
			await SendInviteEmailsAsync(meeting, currentUser, newlyAddedEmails,
				clientFallbackTimeZone: cmd.ClientTimeZone);

		return Result.Success();
	}

	
	private async Task SendInviteEmailsAsync(Meeting meeting, ExternalUserInfo host, IEnumerable<string> recipientEmails, string? clientFallbackTimeZone = null)
	{
		var recipients = recipientEmails
			.Where(e => !string.IsNullOrWhiteSpace(e))
			.Distinct(StringComparer.OrdinalIgnoreCase)
			.ToList();
		if (recipients.Count == 0) return;

		
		if (string.IsNullOrWhiteSpace(host.Email) || host.Email.EndsWith("@local", StringComparison.OrdinalIgnoreCase))
			return;

		try
		{
			
			var appName   = await ResolveAppConfigAsync("App:Name", _config["App:Name"] ?? "OATIConnect");
			var portalUrl = ResolvePortalUrl();
			var when      = FormatHostLocalTimeForInvite(meeting.ScheduledTimeUtc, host);

			// Pre-resolve the web-client URL so it gets stamped into both
			// the email body and the attached .ics consistently — same
			// pin we do for portalUrl. Helper read once, both consumers
			// get the identical value.
			var webClientUrlForInvite = await ResolveWebClientUrlAsync(portalUrl);
			var ics = await _calendar.GenerateCalendarAsync(
				meeting.RoomName,
				overrideWebAppBaseUrl: portalUrl,
				overrideWebClientUrl:  webClientUrlForInvite,
				clientFallbackTimeZone: clientFallbackTimeZone);

			// In encrypted mode, optionally embed the meeting password
			// into the token so recipients skip the prejoin password
			// prompt. Gated by Pref:Meeting:EmbedPasswordInLink; plain
			// /{code} URLs never embed secrets.
			var plaintextPassword = _passwordProtector.Unprotect(meeting.Password);

			string shareUrl;
			if (await IsEncryptedShareLinkEnabledAsync())
			{
				var embedded = (await IsEmbedPasswordInLinkEnabledAsync() && !string.IsNullOrEmpty(plaintextPassword))
					? plaintextPassword
					: null;
				shareUrl = $"{portalUrl}/oaticonnect/j/{_tokens.Create(meeting.Id, embedded)}";
			}
			else
			{
				shareUrl = $"{portalUrl}/{meeting.MeetingCode}";
			}

			// Zoom-style subject: the meeting title verbatim. No
			// "OATIConnect:" prefix, no embedded Meeting ID — keeps
			// mailbox preview clean. The numeric MeetingCode is in
			// the body's "Meeting Id" row.
			var subject = meeting.Title;
			var html    = BuildInviteEmailHtml(appName, host, meeting, shareUrl, plaintextPassword, webClientUrlForInvite, clientFallbackTimeZone);

			await _exchange.SendInviteEmailAsync(
				senderEmail:     host.Email,
				recipientEmails: recipients,
				subject:         subject,
				htmlBody:        html,
				icsAttachment:   ics?.Content,
				icsFileName:     ics?.FileName ?? "invite.ics");
		}
		catch
		{
		
		}
	}

	
	private static string BuildInviteEmailHtml(string appName, ExternalUserInfo host, Meeting meeting, string shareUrl, string? plaintextPassword, string webClientUrl, string? clientFallbackTimeZone = null)
	{
		// Delegates to the shared InvitationHtmlBuilder which now renders
		// the Zoom-style invitation (host greeting, Meeting Details
		// block with Topic/Date/Time, separate "Join {App} Meeting"
		// and "Join From {App} Web Client" sections). The same shape
		// drives the .ics DESCRIPTION so all sharing surfaces read
		// identically.
		var displayCode = FormatMeetingCodeForDisplay(meeting.MeetingCode);
		var startUtc    = DateTime.SpecifyKind(meeting.ScheduledTimeUtc, DateTimeKind.Utc);
		var endUtc      = startUtc.AddMinutes(meeting.DurationMinutes > 0 ? meeting.DurationMinutes : 60);
		return InvitationHtmlBuilder.Build(
			appName,
			host.Name ?? "The host",
			meeting.Title,
			displayCode,
			startUtc, endUtc, host,
			plaintextPassword, shareUrl, webClientUrl,
			clientFallbackTimeZone);
	}

	// Formats a 9 or 10-digit MeetingCode as "XXX XXX XXX" / "XXX XXX
	// XXXX" for human-friendly display. URLs and lookups continue to
	// use the unspaced raw digits — only the display surfaces (email
	// body, .ics description, dashboard row) get the spaced form.
	internal static string FormatMeetingCodeForDisplay(string? code)
	{
		var digits = (code ?? "").Where(char.IsDigit).ToArray();
		if (digits.Length == 10)
			return $"{new string(digits, 0, 3)} {new string(digits, 3, 3)} {new string(digits, 6, 4)}";
		if (digits.Length == 9)
			return $"{new string(digits, 0, 3)} {new string(digits, 3, 3)} {new string(digits, 6, 3)}";
		return code ?? "";
	}

	// Legacy inline builder retained below for reference only — every
	// caller now goes through the shared builder. Marking unreachable
	// to keep the inline copy out of the compile while still showing
	// the original markup if anyone needs to diff.
	#if FALSE
	private static string BuildInviteEmailHtml_LEGACY(string appName, Meeting meeting, string when, string shareUrl, string? plaintextPassword, string webClientUrl)
	{
		// Table-based layout, all-inline styles, no flexbox / no
		// emojis — keeps the rendering consistent across Outlook 2016+,
		// Gmail web, Apple Mail, mobile clients. The brand colour mirrors
		// the dashboard's primary blue (#2c5dc0) and the Electron
		// launcher button so all surfaces feel like one product.
		string Enc(string s) => System.Net.WebUtility.HtmlEncode(s);
		var safeApp     = Enc(appName);
		var safeJoin    = Enc(shareUrl);
		var safeWebUrl  = Enc(webClientUrl);
		var safeId      = Enc(meeting.Title);
		var safeWhen    = Enc(when);
		var duration    = meeting.DurationMinutes > 0 ? meeting.DurationMinutes : 60;
		var safePwd     = string.IsNullOrEmpty(plaintextPassword) ? "" : Enc(plaintextPassword);

		var pwdRow = string.IsNullOrEmpty(safePwd) ? "" : $@"
                <tr>
                  <td style=""padding:8px 0;border-top:1px solid #e5e7eb;color:#6b7280;font-size:12px;letter-spacing:.04em;text-transform:uppercase;width:35%;"">Password</td>
                  <td style=""padding:8px 0;border-top:1px solid #e5e7eb;color:#1f2937;font-family:Consolas,Menlo,monospace;font-size:14px;font-weight:600;letter-spacing:.04em;"">{safePwd}</td>
                </tr>";

		return $@"<!DOCTYPE html>
<html lang=""en""><head><meta charset=""utf-8""><title>{safeApp} meeting invitation</title></head>
<body style=""margin:0;padding:0;background:#f5f7fb;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1f2937;"">
  <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"" style=""background:#f5f7fb;padding:32px 16px;"">
    <tr><td align=""center"">
      <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""600"" style=""max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 14px rgba(15,23,42,.08);"">

        <!-- Header band -->
        <tr><td style=""background:#2c5dc0;background-image:linear-gradient(135deg,#2c5dc0,#1d4ed8);padding:28px 32px;color:#ffffff;"">
          <div style=""font-size:13px;letter-spacing:.08em;text-transform:uppercase;opacity:.85;"">{safeApp}</div>
          <div style=""margin-top:4px;font-size:22px;font-weight:600;line-height:1.3;"">You're invited to a meeting</div>
        </td></tr>

        <!-- Meeting title + meta -->
        <tr><td style=""padding:24px 32px 8px;"">
          <h2 style=""margin:0;font-size:18px;font-weight:600;color:#1f2937;"">{safeId}</h2>
          <p style=""margin:6px 0 0;font-size:14px;color:#6b7280;line-height:1.5;"">{safeWhen} &middot; {duration} min</p>
        </td></tr>

        <!-- Primary CTA -->
        <tr><td style=""padding:20px 32px 8px;"">
          <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0""><tr><td style=""background:#2c5dc0;border-radius:8px;"">
            <a href=""{safeJoin}"" style=""display:inline-block;padding:13px 28px;background:#2c5dc0;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;border-radius:8px;letter-spacing:.02em;"">Join meeting</a>
          </td></tr></table>
          <p style=""margin:12px 0 0;font-size:12px;color:#6b7280;word-break:break-all;"">
            Or paste this link in any browser:<br>
            <a href=""{safeJoin}"" style=""color:#2c5dc0;text-decoration:none;"">{safeJoin}</a>
          </p>
        </td></tr>

        <!-- Web client info (always shown — parallel to the one-click link) -->
        <tr><td style=""padding:4px 32px 16px;"">
          <div style=""padding:14px 16px;background:#eef3fb;border-left:3px solid #2c5dc0;border-radius:6px;"">
            <div style=""font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#2c5dc0;font-weight:700;"">Join from the web client</div>
            <p style=""margin:6px 0 0;font-size:13px;color:#374151;line-height:1.5;"">
              Open
              <a href=""{safeWebUrl}"" style=""color:#2c5dc0;text-decoration:none;font-weight:600;"">{safeWebUrl}</a>
              and enter the Meeting ID and password to join from any browser.
            </p>
          </div>
        </td></tr>

        <!-- Meeting details table -->
        <tr><td style=""padding:0 32px 24px;"">
          <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"" style=""background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:4px 16px;"">
            <tr>
              <td style=""padding:8px 0;color:#6b7280;font-size:12px;letter-spacing:.04em;text-transform:uppercase;width:35%;"">Meeting ID</td>
              <td style=""padding:8px 0;color:#1f2937;font-family:Consolas,Menlo,monospace;font-size:14px;font-weight:600;letter-spacing:.04em;"">{safeId}</td>
            </tr>{pwdRow}
            <tr>
              <td style=""padding:8px 0;border-top:1px solid #e5e7eb;color:#6b7280;font-size:12px;letter-spacing:.04em;text-transform:uppercase;width:35%;"">When</td>
              <td style=""padding:8px 0;border-top:1px solid #e5e7eb;color:#1f2937;font-size:14px;"">{safeWhen}</td>
            </tr>
            <tr>
              <td style=""padding:8px 0;border-top:1px solid #e5e7eb;color:#6b7280;font-size:12px;letter-spacing:.04em;text-transform:uppercase;width:35%;"">Duration</td>
              <td style=""padding:8px 0;border-top:1px solid #e5e7eb;color:#1f2937;font-size:14px;"">{duration} minutes</td>
            </tr>
          </table>
        </td></tr>

        <!-- Footer -->
        <tr><td style=""background:#f9fafb;padding:16px 32px;text-align:center;color:#9ca3af;font-size:12px;border-top:1px solid #e5e7eb;"">
          Sent by {safeApp}
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>";
	}
	#endif

	private static string FormatHostLocalTimeForInvite(DateTime utc, ExternalUserInfo host)
	{
		var zoneId = !string.IsNullOrWhiteSpace(host.TimeZoneIana)    ? host.TimeZoneIana
		           : !string.IsNullOrWhiteSpace(host.TimeZoneWindows) ? host.TimeZoneWindows
		           : "";
		if (string.IsNullOrWhiteSpace(zoneId))
			return DateTime.SpecifyKind(utc, DateTimeKind.Utc).ToString("dddd, d MMMM yyyy 'at' HH:mm 'UTC'");

		try
		{
			var tz     = TimeZoneInfo.FindSystemTimeZoneById(zoneId);
			var local  = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utc, DateTimeKind.Utc), tz);
			var off    = tz.GetUtcOffset(local);
			var sign   = off.Ticks >= 0 ? "+" : "-";
			var abs    = off.Duration();
			var offStr = abs.Minutes == 0 ? $"GMT{sign}{abs.Hours}" : $"GMT{sign}{abs.Hours}:{abs.Minutes:D2}";
			return local.ToString("dddd, d MMMM yyyy 'at' HH:mm") + " " + offStr;
		}
		catch
		{
			return DateTime.SpecifyKind(utc, DateTimeKind.Utc).ToString("dddd, d MMMM yyyy 'at' HH:mm 'UTC'");
		}
	}

	private string ResolveWebAppRoot()
	{
		var dynamicUrl = _urlProvider.GetWebAppBaseUrl();
		if (!string.IsNullOrWhiteSpace(dynamicUrl)) return dynamicUrl.TrimEnd('/');
		
		var sidecar = OATIConnect.API.DependencyInjection.SidecarConfigLoader.TryLoad();
		if (!string.IsNullOrWhiteSpace(sidecar?.App?.WebAppUrl)) return sidecar!.App.WebAppUrl.TrimEnd('/');
		var adminConfigured = _config["App:WebAppUrl"];
		if (!string.IsNullOrWhiteSpace(adminConfigured)) return adminConfigured.TrimEnd('/');
		var legacy = _config["webAppUrl"];
		if (!string.IsNullOrWhiteSpace(legacy)) return legacy.TrimEnd('/');
		return "http://localhost:5000";
	}

	private string ResolvePortalUrl() => ResolveWebAppRoot();

	private string ResolveJoinUrl(string roomName)
		=> $"{ResolveWebAppRoot()}/oaticonnect/room/{Uri.EscapeDataString(roomName)}";

	public async Task<Result> StartAsync(Guid meetingId)
		=> await TransitionAsync(meetingId, m =>
		{
			m.Status = MeetingStatus.Active;
			m.ActualStartUtc = DateTime.UtcNow;
		}, "start");

	public async Task<Result> CancelOccurrenceAsync(Guid meetingId, DateTime occurrenceStartUtc)
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null) return Result.Failure("UNAUTHORIZED", "User not authenticated");

		var meeting = await _data.GetMeetingByIdAsync(meetingId);
		if (meeting == null) return Result.Failure("NOT_FOUND", "Meeting not found");
		if (meeting.HostUserId != currentUser.Id)
			return Result.Failure("FORBIDDEN", "Only host can cancel a meeting occurrence");
		if (meeting.RecurrenceType == RecurrenceType.None)
			return Result.Failure("INVALID", "This meeting isn't recurring — delete it instead");

		
		var existing = await _data.GetOccurrenceExceptionsAsync(meetingId);
		var stamp = DateTime.SpecifyKind(occurrenceStartUtc, DateTimeKind.Utc);
		if (existing.Any(e => e.Type == OccurrenceExceptionType.Cancelled
		                   && DateTime.SpecifyKind(e.OriginalStartUtc, DateTimeKind.Utc) == stamp))
		{
			return Result.Success();
		}

		await _data.AddOccurrenceExceptionAsync(new MeetingOccurrenceException
		{
			Id               = Guid.NewGuid(),
			MeetingId        = meetingId,
			OriginalStartUtc = stamp,
			Type             = OccurrenceExceptionType.Cancelled,
			CreatedAtUtc     = DateTime.UtcNow,
		});
		return Result.Success();
	}

	public async Task<Result> EndAsync(Guid meetingId)
		=> await TransitionAsync(meetingId, m =>
		{
			m.Status = MeetingStatus.Ended;
			m.ActualEndUtc = DateTime.UtcNow;
		}, "end");

	public async Task<Result> DeleteAsync(Guid meetingId)
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null) return Result.Failure("UNAUTHORIZED", "User not authenticated");

		var meeting = await _data.GetMeetingByIdAsync(meetingId);
		if (meeting == null)
			return Result.Failure("NOT_FOUND", "Meeting not found");
		if (meeting.HostUserId != currentUser.Id)
			return Result.Failure("FORBIDDEN", "Only host can delete meeting");

		await _data.DeleteMeetingAsync(meeting.Id);
		return Result.Success();
	}

	public async Task<Result<IReadOnlyList<ParticipantDto>>> GetParticipantsAsync(Guid meetingId)
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null)
			return Result<IReadOnlyList<ParticipantDto>>.Failure("UNAUTHORIZED", "User not authenticated");

		var meeting = await _data.GetMeetingByIdAsync(meetingId);
		if (meeting == null)
			return Result<IReadOnlyList<ParticipantDto>>.Failure("NOT_FOUND", "Meeting not found");
		if (meeting.HostUserId != currentUser.Id)
			return Result<IReadOnlyList<ParticipantDto>>.Failure("FORBIDDEN", "Only host can view participants");

		var rows = await _data.GetParticipantsAsync(meetingId);
		var dto  = rows.Select(p => new ParticipantDto
		{
			Id          = p.Id,
			UserId      = p.UserId,
			Name        = p.Name,
			Email       = p.Email,
			JoinedAtUtc = p.JoinedAtUtc,
		}).ToList();
		return Result<IReadOnlyList<ParticipantDto>>.Success(dto);
	}

	public async Task<MeetingStatusDto> GetMeetingStatusByRoomNameAsync(string roomName)
	{
		// Defensive against repo throws — the join-by-code waiting page
		// polls this endpoint every 2s from an anonymous guest browser,
		// and a 500 here would leave the page silently stuck (the JS
		// catches errors but the user sees no progress). A safe NotFound
		// stub is the worst case.
		Domain.Entities.Meeting? meeting = null;
		try
		{
			meeting = await _data.GetActiveMeetingByRoomNameAsync(roomName);
		}
		catch (Exception ex)
		{
			Console.Error.WriteLine($"[OATIConnect/MeetingService] GetActiveMeetingByRoomNameAsync threw: {ex.GetType().Name}: {ex.Message}");
		}
		if (meeting == null)
		{
			return new MeetingStatusDto { Exists = false, IsActive = false, JoinReady = false, Status = "NotFound" };
		}

		// joinReady is the polled signal the "waiting for host" pages
		// flip to "host has started — joining now". Source of truth is
		// the persistent presence tracker (set on host's
		// videoConferenceJoined, refreshed by heartbeat, cleared on
		// videoConferenceLeft). Status alone leaks because a meeting
		// can stay Active after the host leaves without explicitly
		// ending it.
		var isActive   = meeting.Status == MeetingStatus.Active;
		bool hostArrived = false;
		try { hostArrived = await _hostPresence.HasArrivedAsync(meeting.Id); }
		catch (Exception ex) { Console.Error.WriteLine($"[OATIConnect/MeetingService] HasArrivedAsync threw: {ex.GetType().Name}: {ex.Message}"); }

		var joinReady = isActive
		    && (!meeting.RequireHostStart || hostArrived);
		return new MeetingStatusDto
		{
			Exists   = true,
			IsActive  = isActive,
			JoinReady = joinReady,
			RoomName = meeting.RoomName,
			Status   = meeting.Status.ToString()
		};
	}

	// ----------------------------------------------------------------

	private async Task<Result> TransitionAsync(Guid meetingId, Action<Meeting> mutate, string verb)
	{
		var currentUser = await _userProvider.GetCurrentUserAsync();
		if (currentUser == null) return Result.Failure("UNAUTHORIZED", "User not authenticated");

		var meeting = await _data.GetMeetingByIdAsync(meetingId);
		if (meeting == null) return Result.Failure("NOT_FOUND", "Meeting not found");
		if (meeting.HostUserId != currentUser.Id)
			return Result.Failure("FORBIDDEN", $"Only host can {verb} meeting");

		mutate(meeting);
		await _data.UpdateMeetingAsync(meeting);
		return Result.Success();
	}

	// 10-digit numeric meeting code, Zoom-style. Always generated fresh
	// — never derived from Title (which is now the host's free-form
	// human name). The display layer formats it as "XXX XXX XXXX" via
	// FormatMeetingCodeForDisplay; URLs and lookups use the raw digits.
	private static string GenerateMeetingCode()
		=> Random.Shared.NextInt64(1_000_000_000L, 9_999_999_999L).ToString();

	// Strips whitespace/dashes from a client-supplied code and accepts
	// it iff it parses as 9–12 ASCII digits (matches the URL routing
	// regex). Returns null when the input is missing or malformed so
	// the caller can fall back to a server-generated code.
	private static string? NormalizeMeetingCode(string? raw)
	{
		if (string.IsNullOrWhiteSpace(raw)) return null;
		var digits = new string(raw.Where(char.IsDigit).ToArray());
		if (digits.Length < 9 || digits.Length > 12) return null;
		return digits;
	}
}

