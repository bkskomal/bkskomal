using Microsoft.AspNetCore.DataProtection;

namespace OATIConnect.API.Meetings;

public class MeetingPasswordProtector : IMeetingPasswordProtector
{
    private const string Purpose = "OATIConnect.MeetingPassword.v1";

    private readonly IDataProtector _protector;

    public MeetingPasswordProtector(IDataProtectionProvider provider)
    {
        _protector = provider.CreateProtector(Purpose);
    }

    public string? Protect(string? plaintext)
    {
        if (string.IsNullOrEmpty(plaintext)) return plaintext;
        return _protector.Protect(plaintext);
    }

    public string? Unprotect(string? ciphertext)
    {
        if (string.IsNullOrEmpty(ciphertext)) return ciphertext;
        try
        {
            return _protector.Unprotect(ciphertext);
        }
        catch
        {
            return null;
        }
    }
}
