using OATIConnect.API.Meetings.DTOs;

namespace OATIConnect.API.Meetings;

public interface IMeetingCalendarService
{
	Task<CalendarFileResult?> GenerateCalendarAsync(
		string roomName,
		int reminderMinutes = 10,
		string? overrideWebAppBaseUrl = null,
		string? overrideWebClientUrl = null,
		string? clientFallbackTimeZone = null);
}
