using System.Net;
using System.Text;
using System.Globalization;

namespace OATIConnect.API.Meetings;

/// <summary>
/// Renders the Zoom-style invitation HTML body used by the server-sent
/// email. Mirrors the plain-text DESCRIPTION emitted in
/// MeetingCalendarService.GenerateCalendarAsync so the email body and
/// the .ics carry the same content/format, just wrapped in HTML for
/// the email path.
///
/// Layout (column-counted dashes give the section ribbons in plain
/// text — preserved verbatim in HTML via &lt;pre&gt; so monospace
/// alignment survives every mail client):
///
///   ---------------------------------------------------------------------------
///   {Host} is inviting you to {App} meeting.
///   ---------------------------------------------------------------------------
///   Meeting Details:
///   ----------------------------
///    Topic: ...
///    Date:  ...
///    Time:  ...
///   ----------------------------
///    Meeting Id : ...
///    Password   : ...
///   ----------------------------
///
///   Join meeting with link
///   ----------------------------
///     {shareUrl}
///
///   Join meeting using {App} Web Client
///   ------------------------------------------
///     {webClientUrl}
///     Enter the Meeting ID and password on that page to join...
///   ---------------------------------------------------------------------------
/// </summary>
internal static class InvitationHtmlBuilder
{
    public static string Build(
        string appName,
        string hostName,
        string meetingTitle,
        string meetingIdDisplay,
        DateTime startUtc,
        DateTime endUtc,
        ExternalUserInfo host,
        string? plaintextPassword,
        string shareUrl,
        string webClientUrl,
        string? clientFallbackTimeZone = null)
    {
        string Enc(string s) => WebUtility.HtmlEncode(s ?? "");

        var (dateLabel, timeLabel) = FormatDateTime(startUtc, endUtc, host, clientFallbackTimeZone);

        var safeApp        = Enc(appName);
        var safeHost       = Enc(hostName);
        var safeTitle      = Enc(meetingTitle);
        var safeMeetingId  = Enc(meetingIdDisplay);
        var safeDate       = Enc(dateLabel);
        var safeTime       = Enc(timeLabel);
        var safeShare      = Enc(shareUrl);
        var safeWebClient  = Enc(webClientUrl);
        var safePassword   = string.IsNullOrEmpty(plaintextPassword) ? "" : Enc(plaintextPassword);

        var outerTop    = new string('-', 75);
        var outerBottom = new string('-', 102);
        var innerShort  = new string('-', 39);
        var innerLong   = new string('-', 61);
        var webHeading  = $"Join meeting using {appName} Web Client";
        var safeWebHeading = Enc(webHeading);

        // Build the body line by line so the password row drops cleanly
        // when missing, and so the diff against the .ics description
        // stays trivial to audit. No blank lines — separator ribbons
        // do all the visual work, matching the signed-off plain-text
        // draft byte-for-byte.
        var sb = new StringBuilder();
        sb.AppendLine(outerTop);
        sb.AppendLine($"{safeHost} is inviting you to {safeApp} meeting.");
        sb.AppendLine(outerTop);
        sb.AppendLine("Meeting Details:");
        sb.AppendLine(innerShort);
        sb.AppendLine($" Topic: {safeTitle}");
        sb.AppendLine($" Date: {safeDate}");
        sb.AppendLine($" Time: {safeTime}");
        sb.AppendLine(innerShort);
        sb.AppendLine($" Meeting Id : {safeMeetingId}");
        if (!string.IsNullOrEmpty(safePassword))
            sb.AppendLine($" Password   : {safePassword}");
        sb.AppendLine(innerShort);
        sb.AppendLine();
        sb.AppendLine("Join meeting with link");
        sb.AppendLine(innerShort);
        sb.AppendLine($"  <a href=\"{safeShare}\" style=\"color:#2563eb;text-decoration:none;\">{safeShare}</a>");
        sb.AppendLine();
        // Web-client heading sandwiched between two innerLong ribbons
        // so the section reads as a distinct call-out box.
        sb.AppendLine(innerLong);
        sb.AppendLine(safeWebHeading);
        sb.AppendLine(innerLong);
        sb.AppendLine($"  <a href=\"{safeWebClient}\" style=\"color:#2563eb;text-decoration:none;\">{safeWebClient}</a>");
        sb.AppendLine("  Enter the Meeting ID and password on that page to join from any browser.");
        sb.Append(outerBottom);

        // <pre>-wrapped so column alignment is preserved across Outlook,
        // Gmail web, and Apple Mail. Inline body styling kept minimal —
        // the structure is in the dashes, not in CSS.
        return $@"<!DOCTYPE html>
<html lang=""en""><head>
<meta charset=""UTF-8"">
<meta name=""viewport"" content=""width=device-width,initial-scale=1.0"">
<title>{safeApp} meeting invitation</title>
</head>
<body style=""margin:0;padding:24px;background:#f5f7fb;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;color:#1f2937;"">
  <div style=""max-width:760px;margin:0 auto;background:#ffffff;border:1px solid #e5e7eb;border-radius:8px;padding:28px 32px;box-shadow:0 1px 3px rgba(0,0,0,0.04);"">
    <pre style=""font-family:'Segoe UI',Tahoma,sans-serif;font-size:13px;line-height:1.55;margin:0;white-space:pre-wrap;color:#1f2937;"">{sb}</pre>
  </div>
</body>
</html>";
    }

    /// <summary>
    /// Mirrors MeetingCalendarService.FormatHostDateTimeLabels — kept
    /// in sync by hand for now; the two surfaces (email body + .ics
    /// DESCRIPTION) must produce the same Date/Time strings or
    /// recipients see drift between the two invitations.
    /// </summary>
    private static (string Date, string Time) FormatDateTime(
        DateTime startUtc, DateTime endUtc, ExternalUserInfo host,
        string? clientFallbackTimeZone = null)
    {
        var culture = CultureInfo.InvariantCulture;
        const string dateFmt = "dddd, d MMMM yyyy";
        const string timeFmt = "HH:mm";

        // Same priority as MeetingCalendarService.ResolveTimeZone — host
        // profile IANA → Windows → client-sent browser zone → UTC. Kept
        // inline to keep this class dependency-free; both surfaces must
        // produce the same Date/Time strings or recipients see drift.
        TimeZoneInfo? tz = null;
        foreach (var candidate in new[] { host.TimeZoneIana, host.TimeZoneWindows, clientFallbackTimeZone })
        {
            if (string.IsNullOrWhiteSpace(candidate)) continue;
            try { tz = TimeZoneInfo.FindSystemTimeZoneById(candidate); break; }
            catch { /* try the next one */ }
        }
        if (tz == null)
            return (DateTime.SpecifyKind(startUtc, DateTimeKind.Utc).ToString(dateFmt, culture),
                    $"{DateTime.SpecifyKind(startUtc, DateTimeKind.Utc).ToString(timeFmt, culture)} – {DateTime.SpecifyKind(endUtc, DateTimeKind.Utc).ToString(timeFmt, culture)} UTC");
        var startLoc = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(startUtc, DateTimeKind.Utc), tz);
        var endLoc   = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(endUtc,   DateTimeKind.Utc), tz);
        // Label with the host's timezone NAME (e.g. "Central Daylight
        // Time") not a bare "GMT-5" offset — must match the .ics
        // DESCRIPTION produced by MeetingCalendarService.FormatZoneLabel.
        var zoneLabel = tz.IsDaylightSavingTime(startLoc) ? tz.DaylightName : tz.StandardName;
        if (string.IsNullOrWhiteSpace(zoneLabel)) zoneLabel = tz.Id;
        return (startLoc.ToString(dateFmt, culture),
                $"{startLoc.ToString(timeFmt, culture)} – {endLoc.ToString(timeFmt, culture)} {zoneLabel}");
    }
}
