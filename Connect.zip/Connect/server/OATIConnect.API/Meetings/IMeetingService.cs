﻿using OATIConnect.API.Common;
using OATIConnect.API.Meetings.DTOs;
using OATIConnect.API.Domain.Entities;

namespace OATIConnect.API.Meetings;

public interface IMeetingService
{
	Task<Result<MeetingCreatedDto>> CreateAsync(CreateMeetingCommand command);
	Task<Result<IReadOnlyList<MeetingListItemDto>>> GetMyMeetingsAsync();
	Task<Result<MeetingDetailsDto>> GetByIdAsync(Guid meetingId);
	Task<Result> UpdateAsync(Guid meetingId, UpdateMeetingCommand command);
	Task<Result> StartAsync(Guid meetingId);
	Task<Result> EndAsync(Guid meetingId);
	Task<Result> DeleteAsync(Guid meetingId);
	Task<MeetingStatusDto> GetMeetingStatusByRoomNameAsync(string roomName);

	Task<Result<IReadOnlyList<ParticipantDto>>> GetParticipantsAsync(Guid meetingId);

	Task<Result> CancelOccurrenceAsync(Guid meetingId, DateTime occurrenceStartUtc);
}

