namespace OATIConnect.API.Meetings;

public interface IMeetingShareTokenService
{
    /// <summary>
    /// Build a Data-Protected token that resolves back to <paramref name="meetingId"/>.
    /// </summary>
    string Create(Guid meetingId);

    /// <summary>
    /// Build a token that also carries a password the join controller
    /// auto-applies. Used when <c>Pref:Meeting:EmbedPasswordInLink</c> is on
    /// — recipients click the link and bypass the password prompt. Password
    /// is length-prefixed inside the protected payload, so existing
    /// guid-only tokens still validate cleanly via the same key.
    /// </summary>
    string Create(Guid meetingId, string? embeddedPassword);

    bool TryValidate(string token, out Guid meetingId);

    /// <summary>
    /// Like <see cref="TryValidate(string, out Guid)"/> but also returns
    /// any password embedded into the token at create time. Returns null
    /// when the token is a legacy guid-only payload.
    /// </summary>
    bool TryValidate(string token, out Guid meetingId, out string? embeddedPassword);
}
