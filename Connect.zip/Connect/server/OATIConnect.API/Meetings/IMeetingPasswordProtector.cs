namespace OATIConnect.API.Meetings;

public interface IMeetingPasswordProtector
{
    string? Protect(string? plaintext);

    string? Unprotect(string? ciphertext);
}
