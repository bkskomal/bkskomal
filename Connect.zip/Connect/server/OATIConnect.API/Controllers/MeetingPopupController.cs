using OATIConnect.API.Meetings;
using OATIConnect.API.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Web;

namespace OATIConnect.API.Controllers;

[ApiController]
[AllowAnonymous]
[Route("oaticonnect")]
public class MeetingPopupController : ControllerBase
{
    private readonly IJitsiJoinService _jitsiJoinService;
    private readonly IMeetingCalendarService _calendarService;
    private readonly IAppSettingsService _settings;
    private readonly IHostPresenceTracker _hostPresence;

    private static readonly JsonSerializerOptions CamelJson = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    public MeetingPopupController(
        IJitsiJoinService jitsiJoinService,
        IMeetingCalendarService calendarService,
        IAppSettingsService settings,
        IHostPresenceTracker hostPresence)
    {
        _jitsiJoinService = jitsiJoinService;
        _calendarService  = calendarService;
        _settings         = settings;
        _hostPresence     = hostPresence;
    }

    
    // Host's popup pings this on videoConferenceJoined AND every ~20s
    // afterwards (heartbeat). Each ping refreshes the persisted
    // last-seen timestamp so the presence row stays "fresh" — without
    // the heartbeat, a host that joins and stays put would still drift
    // stale after 60s and the gate would mis-fire as "host gone".
    //
    // IgnoreAntiforgeryToken because host apps that wire global
    // antiforgery validation otherwise 400 this AllowAnonymous POST.
    [HttpPost("host-arrived/{meetingId:guid}")]
    [Microsoft.AspNetCore.Mvc.IgnoreAntiforgeryToken]
    public async Task<IActionResult> HostArrived(Guid meetingId)
    {
        await _hostPresence.RecordHostArrivedAsync(meetingId);
        return Ok(new { ok = true });
    }

    // Paired with host-arrived. Fired from the host's popup JS when the
    // host leaves the Jitsi room (readyToClose / videoConferenceLeft).
    // Clearing the presence flag re-arms the RequireHostStart gate so
    // late joiners can't sneak into an empty room after the host has
    // walked away without explicitly ending the meeting.
    //
    // Called via navigator.sendBeacon on host close, so the request is
    // always one-shot best-effort — never await, never return a body.
    [HttpPost("host-left/{meetingId:guid}")]
    [Microsoft.AspNetCore.Mvc.IgnoreAntiforgeryToken]
    public async Task<IActionResult> HostLeft(Guid meetingId)
    {
        await _hostPresence.ForgetAsync(meetingId);
        return Ok(new { ok = true });
    }

    
    [HttpGet("calendar/{*roomName}")]
    public async Task<IActionResult> Calendar(string roomName, [FromQuery] string? tz = null)
    {
        var decoded = System.Net.WebUtility.UrlDecode(roomName ?? string.Empty);

        // Pin the web-app + web-client URLs to the host the user is
        // currently viewing this download from. Without this, the .ics
        // path falls back to MeetingCalendarService.ResolveWebAppUrl()
        // which reads IOATIConnectRequestUrlProvider — behind nginx the
        // provider often sees the upstream's localhost:5000 instead of
        // the public host, and the .ics ends up shipping localhost links
        // even though the share-via-email path (which runs in the
        // user's create-meeting request) gets the right URL.
        //
        // Computing from Request.Scheme + Host + PathBase guarantees the
        // URL matches what the user just typed in their browser bar.
        var requestUrl = $"{Request.Scheme}://{Request.Host}{Request.PathBase}".TrimEnd('/');

        // tz query param: client passes their browser timezone
        // (Intl.DateTimeFormat().resolvedOptions().timeZone) as a
        // fallback for the email/.ics time formatting in case the
        // host's stored profile timezone is empty or unrecognised
        // by the runtime — keeps .ics times in the user's wall-clock
        // instead of falling through to UTC.
        var file = await _calendarService.GenerateCalendarAsync(
            decoded,
            overrideWebAppBaseUrl: requestUrl,
            clientFallbackTimeZone: tz);
        if (file == null) return NotFound();
        return File(file.Content, file.ContentType, file.FileName);
    }

    [HttpGet("room/{*roomName}")]
    public async Task<ContentResult> Room(string roomName)
    {
        
        Response.Headers["Permissions-Policy"] =
            "camera=(self \"https://*\"), " +
            "microphone=(self \"https://*\"), " +
            "display-capture=(self \"https://*\"), " +
            "fullscreen=(self \"https://*\"), " +
            "clipboard-read=(self \"https://*\"), " +
            "clipboard-write=(self \"https://*\"), " +
            "autoplay=(self \"https://*\")";

        var safeRoom   = HttpUtility.HtmlEncode(roomName ?? string.Empty);
        var safeRoomJs = JsonSerializer.Serialize(roomName ?? string.Empty);

       
        string joinJson  = "null";
        string errorJson = "null";
        try
        {
            var decoded = System.Net.WebUtility.UrlDecode(roomName ?? string.Empty);
            var result = await _jitsiJoinService.JoinAsync(decoded);
            if (result.IsSuccess && result.Data != null)
            {
                joinJson = JsonSerializer.Serialize(result.Data, CamelJson);
            }
            else if (result.ErrorCode == "HOST_NOT_STARTED")
            {
                return Content(InAppWaitingPage(decoded, Request.PathBase.Value ?? ""), "text/html");
            }
            else
            {
                errorJson = JsonSerializer.Serialize(new
                {
                    message = result.ErrorMessage ?? "Meeting not found or not active",
                    code    = result.ErrorCode
                }, CamelJson);
            }
        }
        catch (Exception ex)
        {
            var logger = HttpContext.RequestServices.GetRequiredService<ILogger<MeetingPopupController>>();
            logger.LogError(ex, "Server-side join failed for room {RoomName}", roomName);
            errorJson = JsonSerializer.Serialize(new
            {
                message = ex.Message,
                details = ex.InnerException?.Message,
                type    = ex.GetType().Name
            }, CamelJson);
        }

        string prefsJson;
        try
        {
            var prefs = await _settings.GetMeetingPreferencesAsync();
            prefsJson = JsonSerializer.Serialize(prefs, CamelJson);
        }
        catch
        {
            prefsJson = "null";
        }

        var html = @"<!DOCTYPE html>
<html lang=""en"">
<head>
  <meta charset=""utf-8"" />
  <title>OATIConnect</title>
  <style>
    html, body { margin: 0; padding: 0; height: 100%; width: 100%; background: #1a1a1a; font-family: 'Segoe UI', sans-serif; color: #e5e7eb; }
    #jitsi { height: 100%; width: 100%; position: relative; z-index: 1; }
    /* Joining overlay stays above the Jitsi iframe (z-index 1000) until
       videoConferenceJoined fires. Without this, Jitsi's native
       password-required dialog flashes for 2-3s before our
       executeCommand(password) auto-fill round-trip completes. The
       overlay covers the iframe so the user never sees that flash. */
    #status { position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 12px; font-size: 14px; background: #1a1a1a; z-index: 1000; }
    #status.error { color: #f87171; }
    .spinner { width: 32px; height: 32px; border: 3px solid #374151; border-top-color: #60a5fa; border-radius: 50%; animation: sp 1s linear infinite; }
    @keyframes sp { to { transform: rotate(360deg); } }
  </style>
</head>
<body>
  <div id=""status""><div class=""spinner""></div><div>Joining meeting…</div></div>
  <div id=""jitsi""></div>
  <script>
    // Server-rendered. No fetch. Immune to /api/* and /oaticonnect POST
    // auth filters because the join already happened on the server during
    // this page's GET request — these are just the resulting values.
    var SERVER_JOIN  = " + joinJson + @";
    var SERVER_ERROR = " + errorJson + @";
    var SERVER_PREFS = " + prefsJson + @";
    // Host basePath (e.g. ""/oaticonnect"" under IIS virtual-app deploy,
    // empty when running at the domain root). Prepended to any
    // server-relative URL the popup builds (host-arrived ping,
    // /api/v1/* calls) so IIS deployments don't 404.
    var BASE_PATH    = " + JsonSerializer.Serialize(Request.PathBase.Value ?? "") + @";

    (function () {
      var status = document.getElementById('status');
      var roomName = " + safeRoomJs + @";
      function err(msg) {
        status.classList.add('error');
        status.innerHTML = '<div style=""font-size:48px"">⚠️</div><div>' + msg + '</div>';
      }

      if (SERVER_ERROR) {
        var m = SERVER_ERROR.message || 'Could not join meeting.';
        if (SERVER_ERROR.details) m += ' (' + SERVER_ERROR.details + ')';
        err(m);
        return;
      }
      if (!SERVER_JOIN || !SERVER_JOIN.serverUrl || !SERVER_JOIN.roomName) {
        err('Server did not return a valid Jitsi token.');
        return;
      }

      var data = SERVER_JOIN;
      var serverUrl = String(data.serverUrl).replace(/^https?:\/\//, '');
      var roomNameOut = data.roomName;
      var jwt = data.jwt;
      var displayName = data.displayName || '';
      var meetingPassword = data.password || '';

      // Map our PascalCase toolbar names → Jitsi's lowercase identifiers.
      // Anything missing from this map is dropped from the toolbar (Jitsi
      // ignores unknown ids). New Jitsi versions add buttons over time;
      // extend the map when adopting them.
      var TOOLBAR_MAP = {
        Microphone: 'microphone', Camera: 'camera', Screenshare: 'desktop',
        Chat: 'chat', RaiseHand: 'raisehand', Participants: 'participants-pane',
        TileView: 'tileview', Hangup: 'hangup', Profile: 'profile',
        Invite: 'invite', Settings: 'settings', Fullscreen: 'fullscreen',
        Security: 'security', ClosedCaptions: 'closedcaptions',
        Recording: 'recording', LiveStreaming: 'livestreaming',
        ShareVideo: 'sharedvideo', Whiteboard: 'whiteboard',
        Etherpad: 'etherpad', SelectBackground: 'select-background',
        Help: 'help', Filmstrip: 'filmstrip',
        // Jitsi has no separate toolbar entries for these — leaving them
        // unmapped means the pref toggle is a no-op in this version.
        ToggleCamera: null, ShareAudio: null, NoiseSuppression: null
      };
      var p = SERVER_PREFS || {};
      var toolbarPrefs = p.toolbarButtons || {};
      var toolbarButtons = Object.keys(toolbarPrefs)
        .filter(function (k) { return toolbarPrefs[k] && TOOLBAR_MAP[k]; })
        .map(function (k) { return TOOLBAR_MAP[k]; });

      var s = document.createElement('script');
      s.src = 'https://' + serverUrl + '/external_api.js';
      s.onerror = function () { err('Could not load Jitsi from ' + serverUrl); };
      s.onload = function () {
        // KEEP the joining overlay visible — it covers the iframe so the
        // password-required dialog Jitsi briefly shows while we auto-fill
        // is never seen. Drop it only after videoConferenceJoined fires.
        status.querySelector('div + div').textContent = 'Connecting to meeting…';
        // Only pass `jwt` when we actually have one. Public Jitsi servers
        // (meet.jit.si, …) reject tokens signed by unknown keys; passing
        // an empty string would still fail the validation step.
        var apiOptions = {
          roomName: roomNameOut,
          parentNode: document.getElementById('jitsi'),
          width: '100%',
          height: '100%',
          userInfo: { displayName: displayName },
          configOverwrite: {
            // ALWAYS skip Jitsi's prejoin page — the React-side
            // NewMeetingPreviewModal already handles device picking, so
            // showing Jitsi's prejoin afterwards is a redundant second step.
            // Both keys are set because `prejoinConfig` is the newer Jitsi
            // key and `prejoinPageEnabled` is the legacy boolean.
            prejoinPageEnabled:  false,
            prejoinConfig:       { enabled: false },
            startWithAudioMuted: !!p.startWithAudioMuted,
            // Camera default OR the explicit start-camera-off pref both
            // mute video on join.
            startWithVideoMuted: !!p.startWithCameraOff || (p.defaultCameraOn === false),
            startAudioOnly:       !!p.audioOnly,
            disableSelfView:      !!p.disableFaceCentering,
            disableNotifications: !!p.disableNotifications
          },
          interfaceConfigOverwrite: toolbarButtons.length > 0
            ? { TOOLBAR_BUTTONS: toolbarButtons }
            : {}
        };
        if (jwt) apiOptions.jwt = jwt;
        var api = new JitsiMeetExternalAPI(serverUrl, apiOptions);

        // Two videoConferenceJoined responsibilities:
        //   1. (host only) Ping host-arrived so visitors stuck on the
        //      waiting page can be released. This is the deterministic
        //      replacement for the old 5-second timer — visitors wait
        //      for the host to ACTUALLY be in the Jitsi room, not for a
        //      stopwatch to elapse. Closes the race where a fast visitor
        //      lands first and gets promoted to moderator.
        //   2. (host only, when password is set) executeCommand('password')
        //      to lock the room. We piggyback on the same handler.
        // passwordRequired (any joiner) auto-submits the same password.
        // Heartbeat the host's presence to the server. Each ping
        // refreshes the persisted last-seen timestamp; without this,
        // the row goes stale after 60s and the gate would mis-fire as
        // ""host gone"". Started in videoConferenceJoined (below) and
        // cleared in closeWindow / pagehide.
        var hostHeartbeatTimer = null;
        function startHostHeartbeat() {
          if (!data.isModerator || hostHeartbeatTimer) return;
          var pingUrl = BASE_PATH + '/oaticonnect/host-arrived/' + data.meetingId;
          var ping = function () {
            try { fetch(pingUrl, { method: 'POST', credentials: 'include', keepalive: true }).catch(function(){}); }
            catch (e) {}
          };
          // Cadence: 20s gives a 3x safety margin against the server's
          // 60s stale window so a single missed beat doesn't flip the
          // gate. Background tabs may throttle setInterval, but Jitsi
          // keeps the tab active.
          hostHeartbeatTimer = setInterval(ping, 20000);
        }
        function stopHostHeartbeat() {
          if (hostHeartbeatTimer) { clearInterval(hostHeartbeatTimer); hostHeartbeatTimer = null; }
        }
        api.addEventListener('videoConferenceJoined', function () {
          // We're in the room — drop the overlay so the meeting becomes
          // visible. Any password dialog Jitsi flashed inside the iframe
          // has already been auto-dismissed by our passwordRequired handler.
          status.style.display = 'none';
          if (data.isModerator) startHostHeartbeat();
          if (data.isModerator) {
            // Ping host-arrived. fetch is best-effort; even if it fails
            // the 30s backstop on the server still releases visitors.
            try {
              fetch(BASE_PATH + '/oaticonnect/host-arrived/' + data.meetingId, {
                method: 'POST',
                credentials: 'include',
                keepalive: true,
              }).catch(function () {});
            } catch (e) {}
            if (meetingPassword) {
              try { api.executeCommand('password', meetingPassword); } catch (e) {}
            }
          }
        });
        if (meetingPassword) {
          api.addEventListener('passwordRequired', function () {
            try { api.executeCommand('password', meetingPassword); } catch (e) {}
          });
        }

        // Grant the embedded Jitsi iframe the permissions its overflow
        // (3-dots) menu items need: fullscreen, screen sharing, clipboard,
        // device selection. Without these the menu options silently no-op
        // because the host-page's default Permissions-Policy doesn't
        // delegate them. Apply on every layout cycle in case the iframe
        // gets recreated (Jitsi sometimes does this on reconnect).
        function grantIframePermissions() {
          try {
            var iframe = api.getIFrame && api.getIFrame();
            if (iframe) {
              iframe.allow = 'camera; microphone; display-capture; fullscreen; clipboard-read; clipboard-write; autoplay; speaker-selection; web-share';
              iframe.setAttribute('allowfullscreen', 'true');
              // Sandbox would block too much — leave unset so all
              // Jitsi UI features (popups, downloads, etc.) work.
            }
          } catch (e) {}
        }
        grantIframePermissions();
        // Re-apply after a moment in case the API object isn't ready.
        setTimeout(grantIframePermissions, 250);
        setTimeout(grantIframePermissions, 1000);

        // Close the popup when the meeting ends. readyToClose fires after
        // the user hangs up AND any thank-you / feedback step finishes,
        // which is the moment Jitsi itself is done. videoConferenceLeft
        // is a fallback in case the host disables the thank-you screen.
        //
        // Host-only: ping host-left so the RequireHostStart gate re-arms
        // for late joiners. Use sendBeacon — fetch() with keepalive can
        // be dropped by browsers when the page is unloading, sendBeacon
        // is the API specifically designed to survive the close.
        function pingHostLeft() {
          if (!data.isModerator) return;
          var url = BASE_PATH + '/oaticonnect/host-left/' + data.meetingId;
          try {
            if (navigator.sendBeacon) { navigator.sendBeacon(url); return; }
            fetch(url, { method: 'POST', credentials: 'include', keepalive: true }).catch(function(){});
          } catch (e) {}
        }
        function closeWindow() {
          stopHostHeartbeat();
          pingHostLeft();
          try { api.dispose(); } catch (e) {}
          try { window.close(); } catch (e) {}
        }
        api.addEventListener('readyToClose', closeWindow);
        api.addEventListener('videoConferenceLeft', closeWindow);
        // Belt-and-braces: if the host closes the tab via the OS / X
        // button before Jitsi fires its own events, pagehide still
        // gives us a last chance to ping host-left.
        window.addEventListener('pagehide', function () { stopHostHeartbeat(); pingHostLeft(); });
      };
      document.head.appendChild(s);

      // Title intentionally locked to brand only — keeps popup chrome clean
      // and uniform across multiple meetings. Room name is visible inside
      // Jitsi's own header, so no need to duplicate it in the window title.
      document.title = 'OATIConnect';
    })();
  </script>
</body>
</html>";
        return Content(html, "text/html");
    }

    /// <summary>
    /// Zoom-style "waiting for host" page rendered for in-app non-host
    /// joiners hitting a gated Scheduled meeting. Polls the room's status
    /// every 4s via /api/v1/meetings/status/{roomName} and reloads when
    /// the meeting flips to Active. Authenticated path — uses the host's
    /// existing cookie session so the polled endpoint authorizes.
    /// </summary>
    private static string InAppWaitingPage(string roomName, string basePath)
    {
        var safeRoom    = HttpUtility.HtmlEncode(roomName);
        var safeRoomJs  = JsonSerializer.Serialize(roomName);
        var safeBaseJs  = JsonSerializer.Serialize(basePath ?? "");
        return @"<!DOCTYPE html>
<html lang=""en""><head><meta charset=""utf-8""><title>Waiting for host — " + safeRoom + @"</title>
<style>
  html, body { margin: 0; padding: 0; min-height: 100vh; background: #f5f7fb; font-family: 'Segoe UI', Roboto, sans-serif; color: #1f2937; }
  .card { max-width: 480px; margin: 80px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 36px; text-align: center; box-shadow: 0 8px 28px -16px rgba(0,0,0,0.15); }
  h1 { margin: 0 0 8px; font-size: 18px; color: #1f2937; }
  .sub { color: #6b7280; font-size: 14px; line-height: 1.5; margin: 0 0 18px; }
  .meeting { font-size: 13px; color: #374151; background: #f3f4f6; border-radius: 6px; padding: 8px 12px; margin: 0 0 18px; }
  .spinner { width: 36px; height: 36px; margin: 0 auto 14px; border: 3px solid #e5e7eb; border-top-color: #2563eb; border-radius: 50%; animation: sp 1s linear infinite; }
  @keyframes sp { to { transform: rotate(360deg); } }
  .hint { font-size: 12px; color: #9ca3af; margin-top: 8px; }
</style></head><body>
  <div class=""card"">
    <div class=""spinner""></div>
    <h1>Waiting for host to start the meeting…</h1>
    <p class=""sub"">Please wait. This window will refresh automatically when the host begins.</p>
    <div class=""meeting"">" + safeRoom + @"</div>
    <div class=""hint"" id=""hint"">Checking every few seconds…</div>
  </div>
  <script>
    var ROOM      = " + safeRoomJs + @";
    var BASE_PATH = " + safeBaseJs + @";
    var stopped   = false;
    async function poll() {
      if (stopped) return;
      try {
        var res = await fetch(BASE_PATH + '/api/v1/meetings/status/' + encodeURIComponent(ROOM), { cache: 'no-store', credentials: 'include' });
        if (res.ok) {
          var data = await res.json();
          // joinReady is true only AFTER the host-start grace has
          // expired — gives the host's own Jitsi session time to claim
          // moderator before this user lands in the room. Until then
          // keep polling. We may also show a brief 'host has started'
          // hint as soon as the meeting flips Active but stays in grace.
          var d = data && (data.data || data); // tolerate Result-envelope shape
          if (d && d.joinReady === true) {
            stopped = true;
            document.getElementById('hint').textContent = 'Host has started — joining now…';
            window.location.reload();
            return;
          }
          if (d && d.isActive === true) {
            document.getElementById('hint').textContent = 'Host has started — joining you in a moment…';
          }
        }
      } catch (e) { /* transient — keep polling */ }
      setTimeout(poll, 2000); // poll faster once we're close to ready
    }
    poll();
  </script>
</body></html>";
    }
}
