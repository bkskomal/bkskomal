using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OATIConnect.API.Common;
using OATIConnect.API.Domain.Entities;
using OATIConnect.API.Meetings;
using System.Text.Json;
using System.Web;

namespace OATIConnect.API.Controllers;


[ApiController]
[AllowAnonymous]
public class MeetingJoinByCodeController : ControllerBase
{
    private readonly IOATIConnectExternalAPI _data;
    private readonly IMeetingPasswordProtector _passwordProtector;
    private readonly IJitsiJoinService _jitsiJoinService;
    private readonly IHostPresenceTracker _hostPresence;

    private static readonly JsonSerializerOptions CamelJson = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    public MeetingJoinByCodeController(
        IOATIConnectExternalAPI api,
        IMeetingPasswordProtector passwordProtector,
        IJitsiJoinService jitsiJoinService,
        IHostPresenceTracker hostPresence)
    {
        _data              = api;
        _passwordProtector = passwordProtector;
        _jitsiJoinService  = jitsiJoinService;
        _hostPresence      = hostPresence;
    }

    
    public record JoinByCodeRequest(string MeetingCode, string DisplayName, string? Password);

    // IgnoreAntiforgeryToken: hosts that wire global antiforgery
    // validation (AutoValidateAntiforgeryTokenAttribute) otherwise 400
    // this AllowAnonymous POST before model binding runs — the join-by-
    // code form has no way to obtain the host's CSRF token.
    [HttpPost("/api/v1/meetings/join-by-code")]
    [Microsoft.AspNetCore.Mvc.IgnoreAntiforgeryToken]
    public async Task<IActionResult> JoinByCode([FromBody] JoinByCodeRequest req, CancellationToken ct = default)
    {
        var code = new string((req.MeetingCode ?? "").Where(c => !char.IsWhiteSpace(c)).ToArray());
        if (string.IsNullOrEmpty(code))
            return Ok(new { ok = false, code = "NOT_FOUND", error = "Please enter a meeting id." });

        var meeting = await _data.GetMeetingByMeetingCodeAsync(code, ct);
        if (meeting == null)
            return Ok(new { ok = false, code = "NOT_FOUND", error = "Meeting not found. Check the id and try again." });

        var expected = _passwordProtector.Unprotect(meeting.Password);
        if (!string.IsNullOrEmpty(expected))
        {
            if (string.IsNullOrEmpty(req.Password))
                return Ok(new { ok = false, code = "PASSWORD_REQUIRED", error = "This meeting requires a password." });
            if (!string.Equals(req.Password, expected, StringComparison.Ordinal))
                return Ok(new { ok = false, code = "INVALID_PASSWORD", error = "Incorrect password. Please try again." });
        }

        
        // Host-presence gate. Status alone isn't enough: a meeting can
        // be left in Active state after the host leaves without
        // explicitly ending it, and we don't want late joiners walking
        // into an empty room. The presence tracker is the source of
        // truth — set on host's videoConferenceJoined, cleared on
        // videoConferenceLeft (see host-left endpoint).
        // Defensive: if the presence read fails for any reason, treat
        // as "host not arrived" rather than 500-ing the whole join.
        // The waiting page will keep polling and the user gets a
        // recoverable state instead of a hard failure.
        bool hostPresent = false;
        try { hostPresent = await _hostPresence.HasArrivedAsync(meeting.Id); }
        catch (Exception ex) { Console.Error.WriteLine($"[OATIConnect/JoinByCode] HasArrivedAsync threw: {ex.GetType().Name}: {ex.Message}"); }
        if (meeting.RequireHostStart && !hostPresent)
        {
            // Return roomName so the join-by-code page can swap to the
            // "Waiting for host" panel and poll /meetings/status/{roomName}.
            // The polling endpoint takes the room name (not the meeting code).
            return Ok(new {
                ok       = false,
                code     = "HOST_NOT_STARTED",
                error    = "The host hasn't started this meeting yet. Please wait a moment and try again.",
                roomName = meeting.RoomName,
            });
        }

        var result = await _jitsiJoinService.JoinAsGuestAsync(meeting.Id, req.DisplayName ?? "Guest");
        if (!result.IsSuccess || result.Data == null)
            return Ok(new { ok = false, code = result.ErrorCode ?? "JOIN_FAILED", error = result.ErrorMessage ?? "Could not join meeting." });

        return Ok(new { ok = true, join = result.Data });
    }

    
    [HttpGet("/oaticonnect/join")]
    public ContentResult JoinPage()
    {
        Response.Headers["Permissions-Policy"] =
            "camera=(self \"https://*\"), " +
            "microphone=(self \"https://*\"), " +
            "display-capture=(self \"https://*\"), " +
            "fullscreen=(self \"https://*\"), " +
            "clipboard-read=(self \"https://*\"), " +
            "clipboard-write=(self \"https://*\"), " +
            "autoplay=(self \"https://*\")";

        // Pass the host's PathBase into the page so the inline JS can
        // prepend it to /api/v1/* fetches. Without this, integrators
        // mounting OATIConnect under a virtual app (e.g. /oaticonnect/)
        // get 404s — the POST to /api/v1/meetings/join-by-code lands at
        // the bare host instead of the mounted prefix, and the status
        // poll silently 404s too which makes the waiting page hang.
        var basePath = Request.PathBase.Value ?? "";
        return Content(JoinByCodeHtml(basePath), "text/html");
    }


    private static string JoinByCodeHtml(string basePath) => @"<!DOCTYPE html>
<html lang=""en""><head><meta charset=""utf-8""><title>Join Meeting</title>
<style>
  *, *::before, *::after { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; height: 100%; background: #f5f7fb; font-family: 'Segoe UI', Roboto, sans-serif; color: #1f2937; overflow: hidden; }
  .modal { max-width: 680px; margin: 12px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 10px; padding: 16px 22px 14px; box-shadow: 0 8px 28px -16px rgba(0,0,0,0.15); position: relative; }
  h1 { margin: 0 0 10px; text-align: center; font-size: 18px; font-weight: 600; }
  .field { margin: 0 0 10px; }
  .field label { display: block; text-align: left; font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 4px; }
  .field input { width: 100%; padding: 8px 11px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; background: #f9fafb; font-family: inherit; }
  .field input:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.18); background: #fff; }
  .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .pw-wrap { position: relative; }
  .pw-wrap input { padding-right: 36px; }
  .pw-eye { position: absolute; top: 50%; right: 6px; transform: translateY(-50%); background: transparent; border: 0; padding: 4px; cursor: pointer; color: #6b7280; display: flex; align-items: center; }
  .pw-eye:hover { color: #374151; }
  .toggles { display: flex; gap: 24px; justify-content: center; margin: 4px 0 8px; }
  .toggles label { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; color: #374151; cursor: pointer; }
  .toggles input[type=checkbox] { width: 14px; height: 14px; accent-color: #2563eb; cursor: pointer; }
  .video-wrap { position: relative; width: 100%; height: 180px; background: #93c5fd; border-radius: 8px; overflow: hidden; margin: 0 0 10px; }
  .video-wrap video { width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1); }
  .video-off { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 13px; font-weight: 500; background: #93c5fd; }
  .controls { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 0 0 10px; }
  .controls label { display: block; font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 4px; text-align: left; }
  .controls select { width: 100%; padding: 7px 9px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 12px; background: #f9fafb; }
  .actions { display: flex; gap: 8px; justify-content: flex-end; }
  .actions button { padding: 8px 20px; border-radius: 6px; font-size: 13px; font-weight: 600; cursor: pointer; }
  .actions .cancel { background: #fff; color: #374151; border: 1px solid #d1d5db; }
  .actions .cancel:hover { background: #f3f4f6; }
  .actions .join { background: #2563eb; color: #fff; border: 0; }
  .actions .join:hover { background: #1d4ed8; }
  .actions .join:disabled { background: #93c5fd; cursor: not-allowed; }
  .err  { display: none; background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; padding: 6px 10px; border-radius: 6px; font-size: 12px; margin: 0 0 8px; }
  .warn { display: none; background: #fffbeb; border: 1px solid #fde68a; color: #92400e; padding: 6px 10px; border-radius: 6px; font-size: 12px; margin: 0 0 8px; }
  /* Waiting-for-host card. Mirrors MeetingPopupController.InAppWaitingPage
     so the join-by-code flow and the direct meeting-link flow show the
     same Zoom-style host-hasnt-started UI instead of just an inline
     red error banner. */
  .wait-wrap { display: none; max-width: 480px; margin: 80px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 36px; text-align: center; box-shadow: 0 8px 28px -16px rgba(0,0,0,0.15); }
  .wait-wrap h2 { margin: 0 0 8px; font-size: 18px; color: #1f2937; }
  .wait-wrap .sub { color: #6b7280; font-size: 14px; line-height: 1.5; margin: 0 0 18px; }
  .wait-wrap .room { font-size: 13px; color: #374151; background: #f3f4f6; border-radius: 6px; padding: 8px 12px; margin: 0 0 18px; }
  .wait-spinner { width: 36px; height: 36px; margin: 0 auto 14px; border: 3px solid #e5e7eb; border-top-color: #2563eb; border-radius: 50%; animation: sp 1s linear infinite; }
  .wait-hint { font-size: 12px; color: #9ca3af; margin-top: 8px; }
  #jitsi { display: none; height: 100vh; width: 100vw; position: fixed; inset: 0; background: #1a1a1a; z-index: 100; }
  /* Joining overlay sits ABOVE the Jitsi iframe (z-index 200 vs 100) so the
     brief password-required dialog that pops inside Jitsi while we auto-fill
     the room password via executeCommand('password', …) is never visible to
     the user — the overlay stays up until the videoConferenceJoined event
     confirms we're actually in the room. */
  .joining { display: none; position: fixed; inset: 0; background: #1a1a1a; color: #e5e7eb; align-items: center; justify-content: center; flex-direction: column; gap: 12px; font-size: 14px; z-index: 200; }
  .spinner { width: 32px; height: 32px; border: 3px solid #374151; border-top-color: #60a5fa; border-radius: 50%; animation: sp 1s linear infinite; }
  @keyframes sp { to { transform: rotate(360deg); } }
</style></head><body>
  <div class=""modal"" id=""form"">
    <h1>Join Meeting</h1>
    <div class=""err""  id=""err""></div>
    <div class=""warn"" id=""warn""></div>
    <div class=""field"">
      <label for=""code"">Meeting ID</label>
      <input id=""code"" type=""text"" inputmode=""numeric"" autocomplete=""off"" autocorrect=""off"" autocapitalize=""off"" spellcheck=""false"" placeholder=""e.g. 377 401 626"" autofocus />
    </div>
    <div class=""row2"">
      <div class=""field"">
        <label for=""pw"">Password <span style=""font-weight:400;color:#dc2626;font-size:11px;"">*</span></label>
        <div class=""pw-wrap"">
          <input id=""pw"" type=""password"" maxlength=""100"" required autocomplete=""new-password"" autocorrect=""off"" autocapitalize=""off"" spellcheck=""false"" data-1p-ignore=""true"" data-lpignore=""true"" placeholder=""Enter meeting password"" />
          <button type=""button"" id=""pwToggle"" class=""pw-eye"" aria-label=""Show password"" title=""Show password"">
            <svg id=""pwEyeOn""  width=""16"" height=""16"" viewBox=""0 0 24 24"" fill=""none"" stroke=""currentColor"" stroke-width=""2"" stroke-linecap=""round"" stroke-linejoin=""round"">
              <path d=""M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"" /><circle cx=""12"" cy=""12"" r=""3"" />
            </svg>
            <svg id=""pwEyeOff"" width=""16"" height=""16"" viewBox=""0 0 24 24"" fill=""none"" stroke=""currentColor"" stroke-width=""2"" stroke-linecap=""round"" stroke-linejoin=""round"" style=""display:none;"">
              <path d=""M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"" />
              <path d=""M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"" />
              <path d=""M14.12 14.12A3 3 0 1 1 9.88 9.88"" /><line x1=""1"" y1=""1"" x2=""23"" y2=""23"" />
            </svg>
          </button>
        </div>
      </div>
      <div class=""field"">
        <label for=""n"">Your name</label>
        <input id=""n"" type=""text"" maxlength=""50"" autocomplete=""off"" autocorrect=""off"" autocapitalize=""off"" spellcheck=""false"" placeholder=""Enter your name"" />
      </div>
    </div>
    <div class=""toggles"">
      <label><input id=""cam"" type=""checkbox"" checked /> Camera</label>
      <label><input id=""mic"" type=""checkbox"" checked /> Microphone</label>
    </div>
    <div class=""video-wrap"">
      <video id=""v"" autoplay playsinline muted></video>
      <div id=""vOff"" class=""video-off"" style=""display:none;"">Camera Off</div>
    </div>
    <div class=""controls"">
      <div><label for=""camDev"">Camera</label><select id=""camDev""><option>Loading…</option></select></div>
      <div><label for=""micDev"">Microphone</label><select id=""micDev""><option>Loading…</option></select></div>
    </div>
    <div class=""actions"">
      <button class=""cancel"" type=""button"" onclick=""window.close && window.close()"">Cancel</button>
      <button class=""join""   type=""button"" id=""joinBtn"" onclick=""onJoin()"">Join</button>
    </div>
  </div>

  <div class=""wait-wrap"" id=""waiting"">
    <div class=""wait-spinner""></div>
    <h2>Waiting for host to start the meeting…</h2>
    <p class=""sub"">Please wait. This page will refresh automatically when the host begins.</p>
    <div class=""room"" id=""waitingRoom""></div>
    <div class=""wait-hint"" id=""waitingHint"">Checking every few seconds…</div>
  </div>

  <div class=""joining"" id=""joining""><div class=""spinner""></div><div id=""joiningText"">Joining…</div></div>
  <div id=""jitsi""></div>

  <script>
    var INSECURE_CTX = !window.isSecureContext;
    var stream = null;
    // Host basePath (e.g. ""/oaticonnect"" under IIS virtual-app deploy,
    // empty when running at the domain root). Prepended to every
    // server-relative URL the page builds (join-by-code POST, status
    // poll) so integrators under a basepath don't 404.
    var BASE_PATH = """ + basePath + @""";

    function showErr(msg)  { var e=document.getElementById('err');  e.textContent=msg||''; e.style.display=msg?'block':'none'; if(msg)document.getElementById('warn').style.display='none'; }
    function showWarn(msg) { var e=document.getElementById('warn'); e.textContent=msg||''; e.style.display=msg?'block':'none'; }

    async function listDevices() {
      if (INSECURE_CTX) {
        showWarn('Camera/microphone preview is unavailable on insecure (HTTP) connections. You can still join.');
        document.getElementById('camDev').innerHTML = '<option>(unavailable on HTTP)</option>';
        document.getElementById('micDev').innerHTML = '<option>(unavailable on HTTP)</option>';
        return;
      }
      try {
        await ensurePreview();
        var list = await navigator.mediaDevices.enumerateDevices();
        var camSel = document.getElementById('camDev'); var micSel = document.getElementById('micDev');
        camSel.innerHTML=''; micSel.innerHTML='';
        list.filter(function(d){return d.kind==='videoinput';}).forEach(function(d){var o=document.createElement('option');o.value=d.deviceId;o.textContent=d.label||'Camera';camSel.appendChild(o);});
        list.filter(function(d){return d.kind==='audioinput';}).forEach(function(d){var o=document.createElement('option');o.value=d.deviceId;o.textContent=d.label||'Microphone';micSel.appendChild(o);});
        // Clear any stale warn — at least one preview/enumerate path succeeded.
        showWarn('');
      } catch (e) {
        // Only surface the warn when both cam AND mic are toggled ON.
        // If the user already toggled them off, an empty preview is the
        // expected outcome — don't pop a misleading banner.
        if (document.getElementById('cam').checked || document.getElementById('mic').checked) {
          showWarn('Camera/microphone preview unavailable. You can still join — Jitsi will request permissions inside the meeting.');
        }
      }
    }

    async function ensurePreview() {
      if (INSECURE_CTX) return;
      try {
        if (stream) { stream.getTracks().forEach(function(t){t.stop();}); stream = null; }
        var camOn = document.getElementById('cam').checked;
        var micOn = document.getElementById('mic').checked;
        var camId = (document.getElementById('camDev').value||'').trim();
        var micId = (document.getElementById('micDev').value||'').trim();
        var v = document.getElementById('v'); var vOff = document.getElementById('vOff');
        if (!camOn && !micOn) { v.srcObject=null; vOff.style.display='flex'; showWarn(''); return; }
        stream = await navigator.mediaDevices.getUserMedia({
          video: camOn ? (camId ? { deviceId: { exact: camId } } : true) : false,
          audio: micOn ? (micId ? { deviceId: { exact: micId } } : true) : false,
        });
        v.srcObject = stream;
        vOff.style.display = camOn ? 'none' : 'flex';
        // Latest preview succeeded — clear any prior warn.
        showWarn('');
      } catch (e) {
        if (document.getElementById('cam').checked || document.getElementById('mic').checked) {
          showWarn('Camera/microphone preview unavailable. You can still join.');
        }
      }
    }

    // Format a meeting code with spaces (3-3-4 for 10-digit codes) for
    // the waiting card so it mirrors how Jitsi/Zoom display dial-in IDs.
    function formatMeetingCode(code) {
      var digits = String(code || '').replace(/\D/g, '');
      if (digits.length < 7) return digits || (code || '');
      // 10-digit canonical layout: 3-3-4. Otherwise group from the end in 3s.
      if (digits.length === 10) return digits.slice(0,3) + ' ' + digits.slice(3,6) + ' ' + digits.slice(6);
      return digits.replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    }

    // Remember the user's join attempt so the waiting-for-host poller can
    // silently retry the same POST once the host arrives — no need to keep
    // the form visible or ask them to re-enter the password.
    var pendingJoin = null;
    var waitPollTimer = null;

    // Normalise a join-by-code response so the rest of the JS doesn't
    // care whether the host serialised in camelCase (our dev host) or
    // PascalCase (the typical integrated main app). Returns null for
    // network/parse failures so callers can show a generic error.
    function pick(obj, camel, pascal) {
      if (!obj || typeof obj !== 'object') return undefined;
      return obj[camel] !== undefined ? obj[camel] : obj[pascal];
    }
    function normalizeJitsiJoin(rawJoin) {
      if (!rawJoin || typeof rawJoin !== 'object') return null;
      return {
        meetingId:       pick(rawJoin, 'meetingId',       'MeetingId'),
        serverUrl:       pick(rawJoin, 'serverUrl',       'ServerUrl'),
        roomName:        pick(rawJoin, 'roomName',        'RoomName'),
        jwt:             pick(rawJoin, 'jwt',             'Jwt'),
        displayName:     pick(rawJoin, 'displayName',     'DisplayName'),
        isModerator:     pick(rawJoin, 'isModerator',     'IsModerator'),
        durationMinutes: pick(rawJoin, 'durationMinutes', 'DurationMinutes'),
        actualStartUtc:  pick(rawJoin, 'actualStartUtc',  'ActualStartUtc'),
        status:          pick(rawJoin, 'status',          'Status'),
        password:        pick(rawJoin, 'password',        'Password'),
      };
    }
    function normalizeJoinResponse(raw) {
      if (!raw || typeof raw !== 'object') return null;
      var ok = (raw.ok === true) || (raw.Ok === true);
      return {
        ok:        ok,
        code:      raw.code      || raw.Code      || null,
        error:     raw.error     || raw.Error     || null,
        roomName:  raw.roomName  || raw.RoomName  || null,
        join:      normalizeJitsiJoin(raw.join || raw.Join),
      };
    }

    async function submitJoin(code, name, pw) {
      var res = await fetch(BASE_PATH + '/api/v1/meetings/join-by-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ meetingCode: code, displayName: name, password: pw || null }),
      });
      return normalizeJoinResponse(await res.json());
    }

    function showWaitingForHost(roomName, code, name, pw) {
      pendingJoin = { roomName: roomName, code: code, name: name, pw: pw };
      document.getElementById('form').style.display = 'none';
      document.getElementById('joining').style.display = 'none';
      var w = document.getElementById('waiting');
      w.style.display = 'block';
      document.getElementById('waitingRoom').textContent = formatMeetingCode(code);
      document.getElementById('waitingHint').textContent = 'Checking every few seconds…';
      pollWaitingForHost();
    }

    async function pollWaitingForHost() {
      if (!pendingJoin) return;
      try {
        var res = await fetch(BASE_PATH + '/api/v1/meetings/status/' + encodeURIComponent(pendingJoin.roomName), { cache: 'no-store', credentials: 'include' });
        if (res.ok) {
          var data = await res.json();
          // Tolerate Result-envelope shape ({ data: { ... } }) and the raw DTO.
          var d = data && (data.data || data);
          // Integrators with default Newtonsoft / System.Text.Json config
          // serialize PascalCase, while our standalone dev host emits
          // camelCase. Accept both shapes so the same JS works in either
          // deployment without depending on the host's JSON convention.
          var isActiveFlag  = d && (d.isActive  === true || d.IsActive  === true);
          var joinReadyFlag = d && (d.joinReady === true || d.JoinReady === true);
          if (isActiveFlag) {
            document.getElementById('waitingHint').textContent = 'Host has started — joining you in a moment…';
          }
          if (joinReadyFlag) {
            // Retry the original join silently. No need to reload the page —
            // we still have the password + name from the user's first attempt.
            var retry = await submitJoin(pendingJoin.code, pendingJoin.name, pendingJoin.pw);
            if (retry && retry.ok) {
              var name = pendingJoin.name;
              pendingJoin = null;
              if (stream) { stream.getTracks().forEach(function(t){t.stop();}); stream = null; }
              document.getElementById('waiting').style.display = 'none';
              document.getElementById('joining').style.display = 'flex';
              document.getElementById('joiningText').textContent = 'Joining as ' + name + '…';
              bootJitsi(retry.join);
              return;
            }
            // Still gated (host left between polls, etc.) — keep waiting.
          }
        }
      } catch (e) { /* transient — keep polling */ }
      waitPollTimer = setTimeout(pollWaitingForHost, 2000);
    }

    async function onJoin() {
      var code = document.getElementById('code').value.trim();
      var name = document.getElementById('n').value.trim();
      var pw   = document.getElementById('pw').value;
      if (!code) { showErr('Please enter the meeting ID.'); document.getElementById('code').focus(); return; }
      if (!name) { showErr('Please enter your name.'); document.getElementById('n').focus(); return; }
      if (!pw)   { showErr('Please enter the meeting password.'); document.getElementById('pw').focus(); return; }
      showErr('');
      // Remember the display name across sessions — saves the user from
      // re-typing it for every meeting. Stored only in this browser; the
      // password and meeting id are NOT persisted.
      try { localStorage.setItem('oaticonnect.joinName', name); } catch (e) { /* private mode */ }
      var btn = document.getElementById('joinBtn'); btn.disabled = true; btn.textContent = 'Joining…';
      try {
        var data = await submitJoin(code, name, pw);
        if (!data || !data.ok) {
          // Host hasn't started yet → swap to the Zoom-style waiting card
          // and silently retry once the room flips Active. Mirrors the
          // direct-link flow in MeetingPopupController.InAppWaitingPage.
          if (data && data.code === 'HOST_NOT_STARTED' && data.roomName) {
            btn.disabled = false; btn.textContent = 'Join';
            showWaitingForHost(data.roomName, code, name, pw);
            return;
          }
          showErr((data && data.error) || 'Could not join meeting.');
          btn.disabled = false; btn.textContent = 'Join';
          return;
        }
        // Tear down preview before Jitsi spins up its own getUserMedia.
        if (stream) { stream.getTracks().forEach(function(t){t.stop();}); stream = null; }
        document.getElementById('form').style.display = 'none';
        document.getElementById('joining').style.display = 'flex';
        document.getElementById('joiningText').textContent = 'Joining as ' + name + '…';
        bootJitsi(data.join);
      } catch (e) {
        showErr('Network error. Please try again.');
        btn.disabled = false; btn.textContent = 'Join';
      }
    }

    function bootJitsi(join) {
      var serverUrl = String(join.serverUrl).replace(/^https?:\/\//, '');
      var meetingPassword = join.password || '';
      var s = document.createElement('script');
      s.src = 'https://' + serverUrl + '/external_api.js';
      s.onerror = function () {
        document.getElementById('joiningText').textContent = 'Could not load Jitsi from ' + serverUrl;
      };
      s.onload = function () {
        // Mount the iframe but KEEP the joining overlay visible — it covers
        // the iframe (z-index 200) so the password-required dialog Jitsi
        // briefly shows while we auto-fill the room password is never seen.
        // The overlay is dismissed only after videoConferenceJoined fires.
        document.getElementById('jitsi').style.display = 'block';
        document.getElementById('joiningText').textContent = 'Connecting to meeting…';
        var apiOptions = {
          roomName: join.roomName,
          parentNode: document.getElementById('jitsi'),
          width: '100%', height: '100%',
          userInfo: { displayName: join.displayName || 'Guest' },
          configOverwrite: { prejoinPageEnabled: false, prejoinConfig: { enabled: false } },
        };
        if (join.jwt) apiOptions.jwt = join.jwt;
        var api = new JitsiMeetExternalAPI(serverUrl, apiOptions);
        // Register the password listener FIRST — we want it queued before
        // the iframe internals attempt their first join, so the auto-fill
        // round-trip starts the instant Jitsi raises passwordRequired.
        if (meetingPassword) {
          api.addEventListener('passwordRequired', function () {
            try { api.executeCommand('password', meetingPassword); } catch(e){}
          });
        }
        api.addEventListener('videoConferenceJoined', function () {
          // We're in the room — drop the overlay so the meeting becomes
          // visible. By this point any password prompt Jitsi flashed
          // internally has already been auto-dismissed.
          document.getElementById('joining').style.display = 'none';
          if (meetingPassword && join.isModerator) {
            try { api.executeCommand('password', meetingPassword); } catch(e){}
          }
        });
        function grant() {
          try {
            var iframe = api.getIFrame && api.getIFrame();
            if (iframe) {
              iframe.allow = 'camera; microphone; display-capture; fullscreen; clipboard-read; clipboard-write; autoplay; speaker-selection; web-share';
              iframe.setAttribute('allowfullscreen', 'true');
            }
          } catch(e) {}
        }
        grant(); setTimeout(grant, 250); setTimeout(grant, 1000);
        function closeWindow() {
          try { api.dispose(); } catch(e) {}
          try { window.close(); } catch(e) {}
          // If we can't close (web context), drop back to the form.
          document.getElementById('joining').style.display = 'none';
          document.getElementById('jitsi').style.display = 'none';
          document.getElementById('jitsi').innerHTML = '';
          document.getElementById('form').style.display = 'block';
          var btn = document.getElementById('joinBtn'); btn.disabled = false; btn.textContent = 'Join';
        }
        api.addEventListener('readyToClose', closeWindow);
        api.addEventListener('videoConferenceLeft', closeWindow);
      };
      document.head.appendChild(s);
    }

    // Wire device + visibility events.
    document.getElementById('cam').addEventListener('change', ensurePreview);
    document.getElementById('mic').addEventListener('change', ensurePreview);
    document.getElementById('camDev').addEventListener('change', ensurePreview);
    document.getElementById('micDev').addEventListener('change', ensurePreview);
    ['code', 'n', 'pw'].forEach(function (id) {
      document.getElementById(id).addEventListener('keydown', function (e) { if (e.key === 'Enter') onJoin(); });
    });
    var pwEl = document.getElementById('pw');
    var pwToggle = document.getElementById('pwToggle');
    pwToggle.addEventListener('click', function () {
      var on = document.getElementById('pwEyeOn'); var off = document.getElementById('pwEyeOff');
      if (pwEl.type === 'password') { pwEl.type = 'text';     on.style.display='none';   off.style.display='inline'; pwToggle.setAttribute('aria-label','Hide password'); }
      else                          { pwEl.type = 'password'; on.style.display='inline'; off.style.display='none';   pwToggle.setAttribute('aria-label','Show password'); }
    });

    // Pre-fill the display name from localStorage (set on the last
    // successful submit). If a name is present, jump focus to the
    // password field so returning users land on the first empty input.
    try {
      var savedName = localStorage.getItem('oaticonnect.joinName');
      if (savedName) {
        document.getElementById('n').value = savedName;
        // Don't steal focus from #code if the user hasn't entered it yet —
        // most landings here are without the meeting id pre-filled.
        var codeEl = document.getElementById('code');
        if (codeEl.value.trim()) document.getElementById('pw').focus();
      }
    } catch (e) { /* localStorage unavailable — fall through */ }

    listDevices();
  </script>
</body></html>";
}
