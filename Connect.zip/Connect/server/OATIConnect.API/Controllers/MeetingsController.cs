using OATIConnect.API.Meetings;
using OATIConnect.API.Meetings.DTOs;
using OATIConnect.API.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace OATIConnect.API.Controllers;

[ApiController]
[Route("api/v1/meetings")]
public class MeetingsController : ControllerBase
{
	private readonly IMeetingService _service;
	private readonly IOATIConnectExternalAPI _api;
	private readonly IMeetingShareTokenService _tokens;
	private readonly IAppSettingsService _settings;
	private readonly IMeetingPasswordProtector _passwords;

	public MeetingsController(
		IMeetingService service,
		IOATIConnectExternalAPI api,
		IMeetingShareTokenService tokens,
		IAppSettingsService settings,
		IMeetingPasswordProtector passwords)
	{
		_service      = service;
		_api          = api;
		_tokens       = tokens;
		_settings     = settings;
		_passwords    = passwords;
	}

	[HttpGet]
	public async Task<IActionResult> MyMeetings()
	{
		
		var who = await _api.GetCurrentUserAsync();
		Response.Headers["X-OATIConnect-User"] = who?.Id.ToString() ?? "(none)";
		return Ok(await _service.GetMyMeetingsAsync());
	}

	[HttpPost]
	public async Task<IActionResult> Create(CreateMeetingCommand cmd)
		=> Ok(await _service.CreateAsync(cmd));

	[HttpGet("{id:guid}")]
	public async Task<IActionResult> Get(Guid id)
		=> Ok(await _service.GetByIdAsync(id));

	[HttpPut("{id:guid}")]
	public async Task<IActionResult> Update(Guid id, UpdateMeetingCommand cmd)
		=> Ok(await _service.UpdateAsync(id, cmd));

	[HttpDelete("{id:guid}")]
	public async Task<IActionResult> Delete(Guid id)
		=> Ok(await _service.DeleteAsync(id));

	[HttpPost("{id:guid}/start")]
	public async Task<IActionResult> Start(Guid id)
		=> Ok(await _service.StartAsync(id));

	[HttpPost("{id:guid}/end")]
	public async Task<IActionResult> End(Guid id)
		=> Ok(await _service.EndAsync(id));

	// AllowAnonymous: the join-by-code waiting page polls this endpoint
	// from an unauthenticated guest browser. Without this, integrators
	// with a global authorization policy 401/500 the request before the
	// action runs, leaving the waiting page stuck.
	[AllowAnonymous]
	[HttpGet("status/{roomName}")]
	public async Task<IActionResult> GetStatus(string roomName)
		=> Ok(await _service.GetMeetingStatusByRoomNameAsync(roomName));

	
	public record CancelOccurrenceBody(DateTime OccurrenceStartUtc);
	[HttpPost("{id:guid}/occurrences/cancel")]
	public async Task<IActionResult> CancelOccurrence(Guid id, [FromBody] CancelOccurrenceBody body)
		=> Ok(await _service.CancelOccurrenceAsync(id, body.OccurrenceStartUtc));

	
	[HttpGet("{id:guid}/participants")]
	public async Task<IActionResult> Participants(Guid id)
		=> Ok(await _service.GetParticipantsAsync(id));

	
	[HttpGet("{id:guid}/share-link")]
	public async Task<IActionResult> ShareLink(Guid id, CancellationToken ct)
	{
		var user = await _api.GetCurrentUserAsync();
		if (user == null) return Unauthorized();

		var meeting = await _api.GetMeetingByIdAsync(id, ct);
		if (meeting == null) return NotFound();
		if (meeting.HostUserId != user.Id) return Forbid();

		var prefs = await _settings.GetMeetingPreferencesAsync();
		var req   = HttpContext.Request;
		string url, slug;
		if (prefs.EncryptedShareLink)
		{
			// Optional one-click join — embed the decrypted password in
			// the token so the join controller auto-applies it on
			// arrival, skipping the prejoin password prompt. Only when
			// the admin explicitly opts in (EmbedPasswordInLink); the
			// password still lives inside Data-Protected ciphertext so
			// the URL doesn't leak it. Plain /{code} URLs never embed.
			var plaintext = (prefs.EmbedPasswordInLink && !string.IsNullOrEmpty(meeting.Password))
				? _passwords.Unprotect(meeting.Password)
				: null;
			slug = _tokens.Create(meeting.Id, plaintext);
			url  = $"{req.Scheme}://{req.Host}{req.PathBase}/oaticonnect/j/{slug}";
		}
		else
		{
			slug = meeting.MeetingCode;
			url  = $"{req.Scheme}://{req.Host}{req.PathBase}/{slug}";
		}

		return Ok(new { url, token = slug });
	}
}
