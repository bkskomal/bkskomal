﻿using OATIConnect.API.Common;
using OATIConnect.API.Meetings;
using OATIConnect.API.Settings;
using Microsoft.AspNetCore.Mvc;

namespace OATIConnect.API.Controllers;

[ApiController]
[Route("oaticonnect")]
[Route("api/v1/oaticonnect")]
public class OATIConnectAliasController : ControllerBase
{
    private readonly IAppSettingsService   _settings;
    private readonly IMeetingService       _meetings;
    private readonly IOATIConnectExternalAPI _api;

    public OATIConnectAliasController(
        IAppSettingsService settings,
        IMeetingService meetings,
        IOATIConnectExternalAPI api)
    {
        _settings = settings;
        _meetings = meetings;
        _api      = api;
    }

    private async Task<IActionResult?> RequireAdmin()
    {
        var user = await _api.GetCurrentUserAsync();
        if (user == null)
            return Ok(Result.Failure("UNAUTHORIZED", "Not authenticated"));
        if (!string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
            return Ok(Result.Failure("FORBIDDEN", "Admin only"));
        return null;
    }

    [HttpGet("appconfig")]
    public async Task<IActionResult> GetAllAppConfigs()
    {
        var deny = await RequireAdmin();
        return deny ?? Ok(await _settings.GetAllAsync());
    }

    [HttpGet("appconfig/{key}")]
    public async Task<IActionResult> GetAppConfigByKey(string key)
    {
        var deny = await RequireAdmin();
        if (deny != null) return deny;
        var row = await _settings.GetByKeyAsync(key);
        return row is null ? NotFound() : Ok(row);
    }

    [HttpPost("appconfig")]
    public async Task<IActionResult> UpsertAppConfig([FromBody] UpsertAppConfigCommand command)
    {
        var deny = await RequireAdmin();
        return deny ?? Ok(await _settings.UpsertAsync(command));
    }

    // ---------------- Meeting preferences ----------------
    [HttpGet("settings")]
    public async Task<IActionResult> GetMeetingPreferences()
    {
        var user = await _api.GetCurrentUserAsync();
        if (user == null) return Ok(Result.Failure("UNAUTHORIZED", "Not authenticated"));
        return Ok(await _settings.GetMeetingPreferencesAsync());
    }

    [HttpPost("settings")]
    public async Task<IActionResult> SaveMeetingPreferences([FromBody] MeetingPreferencesDto prefs)
    {
        var deny = await RequireAdmin();
        if (deny != null) return deny;
        await _settings.SaveMeetingPreferencesAsync(prefs);
        return Ok(Result.Success());
    }

    // ---------------- Participants (host-only) ----------------
    [HttpGet("meetings/{id:guid}/participants")]
    public async Task<IActionResult> Participants(Guid id)
        => Ok(await _meetings.GetParticipantsAsync(id));

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var user = await _api.GetCurrentUserAsync();
        if (user == null)
            return Ok(new { id = 0, name = "", email = "", role = "Standard", isAdmin = false, isAuthenticated = false, timeZone = "", timeZoneIana = "" });

        return Ok(new
        {
            id              = user.Id,
            name            = user.Name,
            email           = user.Email,
            role            = user.Role,
            isAdmin         = string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase),
            isAuthenticated = true,
            timeZone        = user.TimeZoneWindows,
            timeZoneIana    = user.TimeZoneIana,
        });
    }
}

