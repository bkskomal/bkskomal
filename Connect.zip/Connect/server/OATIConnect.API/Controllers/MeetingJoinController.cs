using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OATIConnect.API.Domain.Entities;
using OATIConnect.API.Meetings;
using OATIConnect.API.Settings;
using System.Net;
using System.Text.Json;
using System.Web;

namespace OATIConnect.API.Controllers;


[ApiController]
[AllowAnonymous]
public class MeetingJoinController : ControllerBase
{
    private readonly IMeetingShareTokenService _tokens;
    private readonly IJitsiJoinService         _jitsiJoinService;
    private readonly IOATIConnectExternalAPI   _data;
    private readonly IMeetingPasswordProtector _passwordProtector;
    private readonly IAppSettingsService       _settings;
    private readonly IHostPresenceTracker      _hostPresence;

    private static readonly JsonSerializerOptions CamelJson = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    public MeetingJoinController(
        IMeetingShareTokenService tokens,
        IJitsiJoinService jitsiJoinService,
        IOATIConnectExternalAPI api,
        IMeetingPasswordProtector passwordProtector,
        IAppSettingsService settings,
        IHostPresenceTracker hostPresence)
    {
        _tokens             = tokens;
        _jitsiJoinService   = jitsiJoinService;
        _data               = api;
        _passwordProtector  = passwordProtector;
        _settings           = settings;
        _hostPresence       = hostPresence;
    }

    [HttpGet(@"/{token:regex(^\d{{9,12}}$)}")]
    [HttpGet("/oaticonnect/j/{token}")]
    public async Task<ContentResult> Join(
        string token,
        [FromQuery] string? name = null,
        [FromQuery] string? password = null,
        CancellationToken ct = default)
    {
        Response.Headers["Permissions-Policy"] =
            "camera=(self \"https://*\"), " +
            "microphone=(self \"https://*\"), " +
            "display-capture=(self \"https://*\"), " +
            "fullscreen=(self \"https://*\"), " +
            "clipboard-read=(self \"https://*\"), " +
            "clipboard-write=(self \"https://*\"), " +
            "autoplay=(self \"https://*\")";

        // Resolve meetingId. Plain-code path queries by code; encrypted
        // path additionally yields any password the host embedded into
        // the token (Pref:Meeting:EmbedPasswordInLink).
        Guid meetingId;
        string? embeddedPassword = null;
        if (IsPlainMeetingCode(token))
        {
            var byCode = await _data.GetMeetingByMeetingCodeAsync(token, ct);
            if (byCode == null) return Content(InvalidLinkPage(), "text/html");
            meetingId = byCode.Id;
        }
        else if (!_tokens.TryValidate(token, out meetingId, out embeddedPassword))
        {
            return Content(InvalidLinkPage(), "text/html");
        }

        var meeting = await _data.GetMeetingByIdAsync(meetingId, ct);
        var title   = meeting?.Title ?? "(meeting)";
        var expectedPassword = _passwordProtector.Unprotect(meeting?.Password);
        var requiresPassword = !string.IsNullOrEmpty(expectedPassword);

        // Token-embedded password (when present) acts as if the user
        // already typed the right password — no prejoin password
        // prompt, no inline error, name field still has to be filled
        // in. Equivalent to ?password={pw} in the URL but without
        // exposing the password in the query string.
        var embeddedPasswordMatches =
            requiresPassword
            && !string.IsNullOrEmpty(embeddedPassword)
            && string.Equals(embeddedPassword, expectedPassword, StringComparison.Ordinal);
        if (embeddedPasswordMatches)
        {
            password = embeddedPassword;
        }

        if (string.IsNullOrWhiteSpace(name))
        {
            // Hide the password field when the token already carries
            // a valid one — recipient only needs to type their name.
            var showPasswordField = requiresPassword && !embeddedPasswordMatches;
            return Content(PrejoinPage(token, title, showPasswordField, errorMessage: null), "text/html");
        }

        if (requiresPassword && !string.Equals(password, expectedPassword, StringComparison.Ordinal))
        {
            var msg = string.IsNullOrEmpty(password)
                ? "This meeting is password protected. Enter the password to continue."
                : "Incorrect password. Please try again.";
            return Content(PrejoinPage(token, title, requiresPassword: true, errorMessage: msg), "text/html");
        }

        
        if (meeting != null && meeting.RequireHostStart && !await IsHostInRoomAsync(meeting))
        {
            return Content(WaitingForHostPage(token, name, password ?? "", meeting.Title), "text/html");
        }

       
        string joinJson  = "null";
        string errorJson = "null";
        try
        {
            var result = await _jitsiJoinService.JoinAsGuestAsync(meetingId, name);
            if (result.IsSuccess && result.Data != null)
                joinJson = JsonSerializer.Serialize(result.Data, CamelJson);
            else
                errorJson = JsonSerializer.Serialize(new { message = result.ErrorMessage ?? "Could not join meeting", code = result.ErrorCode }, CamelJson);
        }
        catch (Exception ex)
        {
            errorJson = JsonSerializer.Serialize(new { message = ex.Message, type = ex.GetType().Name }, CamelJson);
        }

        return Content(JoinPage(name, joinJson, errorJson), "text/html");
    }

    
    [HttpGet(@"/{token:regex(^\d{{9,12}}$)}/status")]
    [HttpGet("/oaticonnect/j/{token}/status")]
    public async Task<IActionResult> Status(string token, CancellationToken ct = default)
    {
        
        Guid meetingId;
        if (IsPlainMeetingCode(token))
        {
            var byCode = await _data.GetMeetingByMeetingCodeAsync(token, ct);
            if (byCode == null) return Ok(new { active = false });
            meetingId = byCode.Id;
        }
        else if (!_tokens.TryValidate(token, out meetingId))
        {
            return Ok(new { active = false });
        }
        var meeting = await _data.GetMeetingByIdAsync(meetingId, ct);

        return Ok(new { active = await IsHostInRoomAsync(meeting) });
    }

    // Host-presence is now the single source of truth for "is the host
    // currently in the meeting?". Set on the host's videoConferenceJoined,
    // refreshed by the host's popup heartbeat every ~20s, cleared on
    // host's videoConferenceLeft (via /oaticonnect/host-left) and also
    // expires automatically after 60s without a heartbeat — so a host
    // who closes the tab abruptly still ends up correctly marked absent.
    // Cancelled/Ended meetings are always closed regardless.
    internal async Task<bool> IsHostInRoomAsync(Domain.Entities.Meeting? meeting)
    {
        if (meeting == null) return false;
        if (meeting.Status == MeetingStatus.Cancelled || meeting.Status == MeetingStatus.Ended) return false;
        try { return await _hostPresence.HasArrivedAsync(meeting.Id); }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[OATIConnect/MeetingJoin] HasArrivedAsync threw: {ex.GetType().Name}: {ex.Message}");
            return false;
        }
    }

    
    private static bool IsPlainMeetingCode(string? value)
    {
        if (string.IsNullOrEmpty(value)) return false;
        if (value.Length < 9 || value.Length > 12) return false;
        foreach (var c in value) if (!char.IsDigit(c)) return false;
        return true;
    }

   
    private static string InvalidLinkPage() => $@"<!DOCTYPE html>
<html lang=""en""><head><meta charset=""utf-8""><title>Invitation link expired</title>
<style>
  html, body {{ margin: 0; padding: 0; height: 100%; background: #f5f7fb; font-family: 'Segoe UI', Roboto, sans-serif; color: #1f2937; }}
  .card {{ max-width: 480px; margin: 80px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 36px; text-align: center; box-shadow: 0 8px 28px -16px rgba(0,0,0,0.15); }}
  h1 {{ margin: 0 0 8px; color: #b91c1c; }}
  p {{ color: #6b7280; line-height: 1.5; }}
</style></head><body>
  <div class=""card"">
    <div style=""font-size:48px;margin-bottom:12px"">🔒</div>
    <h1>Invitation link expired</h1>
    <p>The link you used has expired or is no longer valid. Please contact the meeting organizer for a fresh invitation.</p>
  </div>
</body></html>";

   
    private static string PrejoinPage(string token, string meetingTitle, bool requiresPassword, string? errorMessage)
    {
        var safeTitle = HttpUtility.HtmlEncode(meetingTitle);
        var safeError = string.IsNullOrEmpty(errorMessage) ? "" : HttpUtility.HtmlEncode(errorMessage);
        var errStyle  = string.IsNullOrEmpty(errorMessage) ? "display:none;" : "display:block;";
        var pwField   = requiresPassword
            ? @"
    <div class=""field"">
      <label for=""pw"">Meeting password</label>
      <div class=""pw-wrap"">
        <input id=""pw"" type=""password"" maxlength=""100"" placeholder=""Enter the meeting password""
               autocomplete=""new-password"" autocorrect=""off"" autocapitalize=""off"" spellcheck=""false""
               data-1p-ignore=""true"" data-lpignore=""true"" data-form-type=""other"" />
        <button type=""button"" id=""pwToggle"" class=""pw-eye"" aria-label=""Show password"" title=""Show password"">
          <svg id=""pwEyeOn""  width=""18"" height=""18"" viewBox=""0 0 24 24"" fill=""none"" stroke=""currentColor"" stroke-width=""2"" stroke-linecap=""round"" stroke-linejoin=""round"">
            <path d=""M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"" />
            <circle cx=""12"" cy=""12"" r=""3"" />
          </svg>
          <svg id=""pwEyeOff"" width=""18"" height=""18"" viewBox=""0 0 24 24"" fill=""none"" stroke=""currentColor"" stroke-width=""2"" stroke-linecap=""round"" stroke-linejoin=""round"" style=""display:none;"">
            <path d=""M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"" />
            <path d=""M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"" />
            <path d=""M14.12 14.12A3 3 0 1 1 9.88 9.88"" />
            <line x1=""1"" y1=""1"" x2=""23"" y2=""23"" />
          </svg>
        </button>
      </div>
    </div>"
            : "";
        var requiresPasswordJs = requiresPassword ? "true" : "false";
        return $@"<!DOCTYPE html>
<html lang=""en""><head><meta charset=""utf-8""><title>Join {safeTitle}</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; }}
  html, body {{ margin: 0; padding: 0; min-height: 100vh; background: #f5f7fb; font-family: 'Segoe UI', Roboto, sans-serif; color: #1f2937; }}
  .modal {{ max-width: 680px; margin: 40px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 28px 32px 24px; box-shadow: 0 8px 28px -16px rgba(0,0,0,0.15); position: relative; }}
  .close {{ position: absolute; top: 14px; right: 14px; background: transparent; border: 0; color: #9ca3af; font-size: 20px; cursor: pointer; padding: 4px 8px; line-height: 1; }}
  .close:hover {{ color: #374151; }}
  h1 {{ margin: 0 0 4px; text-align: center; font-size: 20px; font-weight: 600; }}
  .subtitle {{ margin: 0 0 18px; text-align: center; font-size: 13px; color: #6b7280; }}
  .field {{ margin: 0 0 14px; }}
  .field label {{ display: block; text-align: center; font-size: 13px; font-weight: 600; color: #374151; margin: 0 0 6px; }}
  .field input[type=text], .field input[type=password] {{ width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; background: #f9fafb; }}
  .field input[type=text]:focus, .field input[type=password]:focus {{ outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.18); background: #fff; }}
  .pw-wrap {{ position: relative; }}
  .pw-wrap input {{ padding-right: 38px; }}
  .pw-eye {{ position: absolute; top: 50%; right: 8px; transform: translateY(-50%); background: transparent; border: 0; padding: 4px; cursor: pointer; color: #6b7280; display: flex; align-items: center; }}
  .pw-eye:hover {{ color: #374151; }}
  .toggles {{ display: flex; gap: 32px; justify-content: center; margin: 6px 0 12px; }}
  .toggles label {{ display: inline-flex; align-items: center; gap: 8px; font-size: 14px; color: #374151; cursor: pointer; }}
  .toggles input[type=checkbox] {{ width: 16px; height: 16px; accent-color: #2563eb; cursor: pointer; }}
  .video-wrap {{ position: relative; width: 100%; aspect-ratio: 16 / 9; background: #93c5fd; border-radius: 8px; overflow: hidden; margin: 0 0 14px; }}
  .video-wrap video {{ width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1); }}
  .video-off {{ position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; font-weight: 500; background: #93c5fd; }}
  .controls {{ display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 0 0 16px; }}
  .controls label {{ display: block; font-size: 13px; font-weight: 600; color: #374151; margin: 0 0 6px; text-align: center; }}
  .controls select {{ width: 100%; padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; background: #f9fafb; }}
  .actions {{ display: flex; gap: 10px; justify-content: flex-end; margin-top: 8px; }}
  .actions button {{ padding: 9px 22px; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; }}
  .actions .cancel {{ background: #fff; color: #374151; border: 1px solid #d1d5db; }}
  .actions .cancel:hover {{ background: #f3f4f6; }}
  .actions .join {{ background: #2563eb; color: #fff; border: 0; }}
  .actions .join:hover {{ background: #1d4ed8; }}
  .actions .join:disabled {{ background: #93c5fd; cursor: not-allowed; }}
  .err   {{ display: none; background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; padding: 8px 12px; border-radius: 6px; font-size: 13px; margin: 0 0 12px; }}
  .warn  {{ display: none; background: #fffbeb; border: 1px solid #fde68a; color: #92400e; padding: 8px 12px; border-radius: 6px; font-size: 13px; margin: 0 0 12px; }}
</style></head><body>
  <div class=""modal"">
    <button class=""close"" onclick=""onCancel()"" aria-label=""Cancel"">×</button>
    <h1>Join Meeting</h1>
    <div class=""subtitle"">{safeTitle}</div>

    <div class=""err""  id=""err""  style=""{errStyle}"">{safeError}</div>
    <div class=""warn"" id=""warn""></div>

    <div class=""field"">
      <label for=""n"">Your name</label>
      <input id=""n"" type=""text"" maxlength=""50"" required autofocus placeholder=""Enter your name""
             autocomplete=""off"" autocorrect=""off"" autocapitalize=""off"" spellcheck=""false"" />
    </div>{pwField}

    <div class=""toggles"">
      <label><input id=""cam"" type=""checkbox"" checked /> Camera</label>
      <label><input id=""mic"" type=""checkbox"" checked /> Microphone</label>
    </div>

    <div class=""video-wrap"">
      <video id=""v"" autoplay playsinline muted></video>
      <div id=""vOff"" class=""video-off"" style=""display:none;"">Camera Off</div>
    </div>

    <div class=""controls"">
      <div>
        <label for=""camDev"">Camera</label>
        <select id=""camDev""><option>Loading…</option></select>
      </div>
      <div>
        <label for=""micDev"">Microphone</label>
        <select id=""micDev""><option>Loading…</option></select>
      </div>
    </div>

    <div class=""actions"">
      <button class=""cancel"" type=""button"" onclick=""onCancel()"">Cancel</button>
      <button class=""join""   type=""button"" id=""joinBtn"" onclick=""onJoin()"">Join</button>
    </div>
  </div>

  <script>
    var TOKEN = '{token}';
    var REQUIRES_PASSWORD = {requiresPasswordJs};
    var stream = null;
    var devs   = [];

    function showErr(msg)  {{ var e = document.getElementById('err');  e.textContent = msg; e.style.display = msg ? 'block' : 'none'; }}
    function showWarn(msg) {{ var e = document.getElementById('warn'); e.textContent = msg; e.style.display = msg ? 'block' : 'none'; }}

    // Browsers only expose getUserMedia/enumerateDevices on secure contexts
    // (HTTPS or localhost). Plain HTTP on a non-localhost hostname returns
    // a NotAllowedError without ever surfacing a permission prompt.
    var INSECURE_CTX = !window.isSecureContext;

    async function listDevices() {{
      if (INSECURE_CTX) {{
        // No prompt is possible here — surface the reason as a non-blocking
        // warning. The user can still click Join; Jitsi handles permissions
        // in its own iframe, which the host page may load over HTTPS even
        // when this prejoin landed on HTTP.
        showWarn('Camera/microphone preview is unavailable on insecure (HTTP) connections. You can still join — Jitsi will request permissions inside the meeting.');
        var camSel = document.getElementById('camDev');
        var micSel = document.getElementById('micDev');
        camSel.innerHTML = '<option>(unavailable on HTTP)</option>';
        micSel.innerHTML = '<option>(unavailable on HTTP)</option>';
        return;
      }}
      try {{
        // Permission must already be granted (or about to be) for labels to
        // show up. We trigger getUserMedia first so the label list is
        // populated, then enumerate.
        await ensurePreview();
        var list = await navigator.mediaDevices.enumerateDevices();
        devs = list;
        var camSel = document.getElementById('camDev');
        var micSel = document.getElementById('micDev');
        camSel.innerHTML = ''; micSel.innerHTML = '';
        list.filter(function (d) {{ return d.kind === 'videoinput'; }}).forEach(function (d) {{
          var o = document.createElement('option'); o.value = d.deviceId; o.textContent = d.label || 'Camera'; camSel.appendChild(o);
        }});
        list.filter(function (d) {{ return d.kind === 'audioinput'; }}).forEach(function (d) {{
          var o = document.createElement('option'); o.value = d.deviceId; o.textContent = d.label || 'Microphone'; micSel.appendChild(o);
        }});
      }} catch (e) {{
        // Silent — blue preview area is enough indication; Jitsi will
        // re-prompt permissions inside the meeting iframe anyway.
      }}
    }}

    async function ensurePreview() {{
      if (INSECURE_CTX) return;
      try {{
        if (stream) {{ stream.getTracks().forEach(function (t) {{ t.stop(); }}); stream = null; }}
        var camOn = document.getElementById('cam').checked;
        var micOn = document.getElementById('mic').checked;
        var camId = (document.getElementById('camDev').value || '').trim();
        var micId = (document.getElementById('micDev').value || '').trim();

        var v = document.getElementById('v');
        var vOff = document.getElementById('vOff');
        if (!camOn && !micOn) {{
          v.srcObject = null;
          vOff.style.display = 'flex';
          return;
        }}

        var constraints = {{
          video: camOn ? (camId ? {{ deviceId: {{ exact: camId }} }} : true) : false,
          audio: micOn ? (micId ? {{ deviceId: {{ exact: micId }} }} : true) : false,
        }};
        stream = await navigator.mediaDevices.getUserMedia(constraints);
        v.srcObject = stream;
        vOff.style.display = camOn ? 'none' : 'flex';
      }} catch (e) {{
        // Silent — same reasoning as listDevices's catch.
      }}
    }}

    function onCancel() {{
      if (stream) {{ stream.getTracks().forEach(function (t) {{ t.stop(); }}); stream = null; }}
      // If opened as a popup, closing it returns the user to the host's
      // window. If opened as a normal tab, history.back() falls back to
      // wherever they came from (email client, calendar app).
      try {{ window.close(); }} catch (e) {{}}
      try {{ if (!window.closed) history.back(); }} catch (e) {{}}
    }}

    function onJoin() {{
      var n = document.getElementById('n').value.trim();
      if (!n) {{ showErr('Please enter your name to join.'); document.getElementById('n').focus(); return; }}
      // Persist the name so the next visit (from any meeting link in
      // this browser) pre-fills it. Same key as the blur handler.
      try {{ if (window.localStorage) window.localStorage.setItem('oaticonnect:lastName', n); }} catch (e) {{}}
      var pw = '';
      if (REQUIRES_PASSWORD) {{
        var pwEl = document.getElementById('pw');
        pw = pwEl ? pwEl.value : '';
        if (!pw) {{ showErr('Please enter the meeting password to join.'); if (pwEl) pwEl.focus(); return; }}
      }}
      // Stop the preview before navigating — the join page boots its own
      // Jitsi iframe with its own getUserMedia, so we'd otherwise leak
      // a duplicate microphone capture for ~1 frame.
      if (stream) {{ stream.getTracks().forEach(function (t) {{ t.stop(); }}); stream = null; }}
      var btn = document.getElementById('joinBtn');
      btn.disabled = true; btn.textContent = 'Joining…';
      // Reuse the current pathname (whether /oaticonnect/j/TOKEN or
      // the short /oaticonnect/CODE form) so the join action hits
      // the same controller that rendered this page — and so any host
      // basePath the app is mounted under (e.g. IIS virtual app at
      // /oaticonnect) is preserved automatically. Hard-coding the
      // route here drops the basePath and 404s on IIS deployments.
      var url = window.location.pathname + '?name=' + encodeURIComponent(n);
      if (REQUIRES_PASSWORD) url += '&password=' + encodeURIComponent(pw);
      window.location = url;
    }}

    document.getElementById('cam').addEventListener('change', ensurePreview);
    document.getElementById('mic').addEventListener('change', ensurePreview);
    document.getElementById('camDev').addEventListener('change', ensurePreview);
    document.getElementById('micDev').addEventListener('change', ensurePreview);
    document.getElementById('n').addEventListener('keydown', function (e) {{ if (e.key === 'Enter') onJoin(); }});
    var pwEl = document.getElementById('pw');
    if (pwEl) pwEl.addEventListener('keydown', function (e) {{ if (e.key === 'Enter') onJoin(); }});
    var pwToggle = document.getElementById('pwToggle');
    if (pwToggle && pwEl) {{
      pwToggle.addEventListener('click', function () {{
        var on  = document.getElementById('pwEyeOn');
        var off = document.getElementById('pwEyeOff');
        if (pwEl.type === 'password') {{
          pwEl.type = 'text';
          on.style.display  = 'none';
          off.style.display = 'inline';
          pwToggle.setAttribute('aria-label', 'Hide password');
          pwToggle.setAttribute('title', 'Hide password');
        }} else {{
          pwEl.type = 'password';
          on.style.display  = 'inline';
          off.style.display = 'none';
          pwToggle.setAttribute('aria-label', 'Show password');
          pwToggle.setAttribute('title', 'Show password');
        }}
      }});
    }}

    // Remember the recipient's name across visits in this browser.
    // Saved on each successful name entry; pre-filled on next load
    // so the recipient doesn't have to retype every time they rejoin
    // a meeting from the same machine. Per-origin via localStorage —
    // a different OATIConnect deployment gets its own slot.
    var NAME_KEY = 'oaticonnect:lastName';
    var nameInput = document.getElementById('n');
    if (nameInput) {{
      try {{
        var saved = window.localStorage && window.localStorage.getItem(NAME_KEY);
        if (saved && !nameInput.value) nameInput.value = saved;
      }} catch (e) {{ /* private mode / disabled storage — ignore */ }}
      nameInput.addEventListener('blur', function () {{
        var v = nameInput.value.trim();
        try {{ if (v) window.localStorage.setItem(NAME_KEY, v); }} catch (e) {{}}
      }});
    }}

    listDevices();
  </script>
</body></html>";
    }

    /// <summary>
    /// Zoom-style "waiting for host to start" page. Rendered when the
    /// admin enabled <c>Pref:Meeting:RequireHostStart</c> and the meeting
    /// hasn't been started yet. Polls the JSON status endpoint every 4
    /// seconds and reloads the current URL the moment the meeting flips
    /// to Active — at that point the controller's normal Join branch
    /// runs because the gate condition is no longer true.
    ///
    /// Name + password are baked back into the page so the resume reload
    /// carries them along; the user never re-enters anything.
    /// </summary>
    private static string WaitingForHostPage(string token, string name, string password, string meetingTitle)
    {
        var safeTitle = HttpUtility.HtmlEncode(meetingTitle);
        // JSON-encode for safe inline into JS string literals (handles quotes,
        // backslashes, unicode). Avoids hand-rolled escaping bugs.
        var jsToken    = JsonSerializer.Serialize(token);
        var jsName     = JsonSerializer.Serialize(name);
        var jsPassword = JsonSerializer.Serialize(password);

        return $@"<!DOCTYPE html>
<html lang=""en""><head><meta charset=""utf-8""><title>Waiting for host — {safeTitle}</title>
<style>
  html, body {{ margin: 0; padding: 0; min-height: 100vh; background: #f5f7fb; font-family: 'Segoe UI', Roboto, sans-serif; color: #1f2937; }}
  .card {{ max-width: 480px; margin: 80px auto; background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 36px; text-align: center; box-shadow: 0 8px 28px -16px rgba(0,0,0,0.15); }}
  h1 {{ margin: 0 0 8px; font-size: 18px; color: #1f2937; }}
  .sub {{ color: #6b7280; font-size: 14px; line-height: 1.5; margin: 0 0 18px; }}
  .meeting {{ font-size: 13px; color: #374151; background: #f3f4f6; border-radius: 6px; padding: 8px 12px; margin: 0 0 18px; }}
  .spinner {{ width: 36px; height: 36px; margin: 0 auto 14px; border: 3px solid #e5e7eb; border-top-color: #2563eb; border-radius: 50%; animation: sp 1s linear infinite; }}
  @keyframes sp {{ to {{ transform: rotate(360deg); }} }}
  .hint {{ font-size: 12px; color: #9ca3af; margin-top: 8px; }}
</style></head><body>
  <div class=""card"">
    <div class=""spinner""></div>
    <h1>Waiting for host to start the meeting…</h1>
    <p class=""sub"">Please wait. This page will refresh automatically when the host begins.</p>
    <div class=""meeting"">{safeTitle}</div>
    <div class=""hint"" id=""hint"">Checking every few seconds…</div>
  </div>
  <script>
    var TOKEN    = {jsToken};
    var USERNAME = {jsName};
    var PASSWORD = {jsPassword};

    // Both the join target AND the status poll URL are derived from
    // window.location.pathname so they preserve whatever host basePath
    // the app is mounted under (e.g. IIS virtual app at /oaticonnect).
    // Hard-coding /oaticonnect/j/... drops the basePath and 404s.
    function buildJoinUrl() {{
      var u = window.location.pathname + '?name=' + encodeURIComponent(USERNAME);
      if (PASSWORD) u += '&password=' + encodeURIComponent(PASSWORD);
      return u;
    }}

    var stopped = false;
    async function poll() {{
      if (stopped) return;
      try {{
        var res = await fetch(window.location.pathname + '/status', {{ cache: 'no-store' }});
        if (res.ok) {{
          var data = await res.json();
          // The server holds 'active' false for ~5s after the host
          // auto-starts so the host's own iframe acquires moderator
          // role before any visitor lands in the room. We don't know
          // server-side when grace started, so just keep polling — a
          // tighter cadence (2s) once we get close keeps the redirect
          // snappy without burying the host under requests.
          if (data && data.active) {{
            stopped = true;
            document.getElementById('hint').textContent = 'Host has started — joining now…';
            // Replace so the back button doesn't bring the user back to
            // the waiting page after they land in Jitsi.
            window.location.replace(buildJoinUrl());
            return;
          }}
        }}
      }} catch (e) {{
        // Network blip — keep polling silently. Surfacing a transient
        // error here would just panic the user; the next tick recovers.
      }}
      setTimeout(poll, 2000);
    }}
    poll();
  </script>
</body></html>";
    }

    /// <summary>
    /// Step B: name was supplied, server ran <c>JoinAsGuestAsync</c>, the
    /// resulting JWT + room + server URL are inlined into the page.
    /// Identical Jitsi bootstrap as <see cref="MeetingPopupController.Room"/>.
    /// </summary>
    private static string JoinPage(string name, string joinJson, string errorJson) => @"<!DOCTYPE html>
<html lang=""en"">
<head>
  <meta charset=""utf-8"" />
  <title>OATIConnect</title>
  <style>
    html, body { margin: 0; padding: 0; height: 100%; width: 100%; background: #1a1a1a; font-family: 'Segoe UI', sans-serif; color: #e5e7eb; }
    #jitsi { height: 100%; width: 100%; position: relative; z-index: 1; }
    /* Joining overlay stays above the Jitsi iframe until videoConferenceJoined
       fires. Without this, Jitsi's native password-required dialog flashes
       inside the iframe for 2-3s while our executeCommand(password) auto-fill
       round-trip completes. The overlay covers the iframe so the flash is
       invisible to the user. */
    #status { position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 12px; font-size: 14px; background: #1a1a1a; z-index: 1000; }
    #status.error { color: #f87171; }
    .spinner { width: 32px; height: 32px; border: 3px solid #374151; border-top-color: #60a5fa; border-radius: 50%; animation: sp 1s linear infinite; }
    @keyframes sp { to { transform: rotate(360deg); } }
  </style>
</head>
<body>
  <div id=""status""><div class=""spinner""></div><div>Joining as " + HttpUtility.HtmlEncode(name) + @"…</div></div>
  <div id=""jitsi""></div>
  <script>
    var SERVER_JOIN  = " + joinJson + @";
    var SERVER_ERROR = " + errorJson + @";

    (function () {
      var status = document.getElementById('status');
      function err(msg) {
        status.classList.add('error');
        status.innerHTML = '<div style=""font-size:48px"">⚠️</div><div>' + msg + '</div>';
      }

      if (SERVER_ERROR) {
        var m = SERVER_ERROR.message || 'Could not join meeting.';
        err(m);
        return;
      }
      if (!SERVER_JOIN || !SERVER_JOIN.serverUrl || !SERVER_JOIN.roomName) {
        err('Server did not return a valid Jitsi token.');
        return;
      }

      var data = SERVER_JOIN;
      var serverUrl = String(data.serverUrl).replace(/^https?:\/\//, '');
      var meetingPassword = data.password || '';

      var s = document.createElement('script');
      s.src = 'https://' + serverUrl + '/external_api.js';
      s.onerror = function () { err('Could not load Jitsi from ' + serverUrl); };
      s.onload = function () {
        // KEEP the joining overlay visible — it covers the iframe so the
        // password-required dialog Jitsi briefly shows while we auto-fill
        // is never seen. Drop it only after videoConferenceJoined fires.
        var statusText = status.querySelector('div + div');
        if (statusText) statusText.textContent = 'Connecting to meeting…';
        var apiOptions = {
          roomName: data.roomName,
          parentNode: document.getElementById('jitsi'),
          width: '100%',
          height: '100%',
          userInfo: { displayName: data.displayName || 'Guest' },
          configOverwrite: {
            prejoinPageEnabled: false,
            prejoinConfig: { enabled: false }
          }
        };
        if (data.jwt) apiOptions.jwt = data.jwt;
        var api = new JitsiMeetExternalAPI(serverUrl, apiOptions);

        // Register passwordRequired FIRST — we want it queued before
        // the iframe internals attempt their first join, so the auto-
        // fill round-trip starts the instant Jitsi raises the event.
        if (meetingPassword) {
          api.addEventListener('passwordRequired', function () {
            try { api.executeCommand('password', meetingPassword); } catch (e) {}
          });
        }
        api.addEventListener('videoConferenceJoined', function () {
          // In the room — drop the overlay so the meeting becomes
          // visible. Any password dialog Jitsi flashed inside the
          // iframe has already been auto-dismissed.
          status.style.display = 'none';
          if (meetingPassword && data.isModerator) {
            try { api.executeCommand('password', meetingPassword); } catch (e) {}
          }
        });

        function grantIframePermissions() {
          try {
            var iframe = api.getIFrame && api.getIFrame();
            if (iframe) {
              iframe.allow = 'camera; microphone; display-capture; fullscreen; clipboard-read; clipboard-write; autoplay; speaker-selection; web-share';
              iframe.setAttribute('allowfullscreen', 'true');
            }
          } catch (e) {}
        }
        grantIframePermissions();
        setTimeout(grantIframePermissions, 250);
        setTimeout(grantIframePermissions, 1000);

        // When the user hangs up Jitsi fires readyToClose /
        // videoConferenceLeft. Two cases:
        //
        //   (a) Page was opened by window.open() (e.g. host's start-
        //       meeting popup from the dashboard): window.close() is
        //       allowed and shuts the tab cleanly.
        //   (b) Recipient clicked a share link in their mail client:
        //       this is a normal navigation tab — browsers silently
        //       block window.close() — so we drop the ?name= query
        //       and reload the same join URL, returning to the
        //       prejoin form for that meeting. Without this branch
        //       the iframe vanishes and the user stares at black.
        //
        // window.opener is non-null only in case (a) — use it to
        // decide. Try close first either way (safe), then navigate
        // for case (b).
        function onLeave() {
          try { api.dispose(); } catch (e) {}
          var openedByJs = !!window.opener;
          if (openedByJs) {
            try { window.close(); } catch (e) {}
            return; // close took effect — nothing more to do
          }
          // Drop the query string. Re-hits the join URL without
          // ?name=, which renders the prejoin form for this meeting.
          window.location.href = window.location.pathname;
        }
        api.addEventListener('readyToClose', onLeave);
        api.addEventListener('videoConferenceLeft', onLeave);
      };
      document.head.appendChild(s);

      document.title = 'OATIConnect';
    })();
  </script>
</body>
</html>";
}
