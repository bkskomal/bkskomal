using OATIConnect.API.Common;
using OATIConnect.API.Exchange;
using Microsoft.AspNetCore.Mvc;

namespace OATIConnect.API.Controllers;


[ApiController]
[Route("api/v1/exchange")]
public class ExchangeController : ControllerBase
{
    private readonly IExchangeDirectoryService _exchange;
    private readonly IOATIConnectExternalAPI _api;

    public ExchangeController(IExchangeDirectoryService exchange, IOATIConnectExternalAPI api)
    {
        _exchange = exchange;
        _api      = api;
    }

   
    [HttpGet("status")]
    public async Task<IActionResult> Status()
        => Ok(new { enabled = await _exchange.IsEnabledAsync() });

    
    [HttpGet("search")]
    public async Task<IActionResult> Search([FromQuery] string q, CancellationToken ct)
    {
        var user = await _api.GetCurrentUserAsync();
        if (user == null) return Ok(Result.Failure("UNAUTHORIZED", "Not authenticated"));
        return Ok(await _exchange.SearchAsync(q ?? string.Empty, ct));
    }

    
    [HttpPost("test")]
    public async Task<IActionResult> Test(CancellationToken ct)
    {
        var user = await _api.GetCurrentUserAsync();
        if (user == null) return Ok(Result.Failure("UNAUTHORIZED", "Not authenticated"));
        if (!string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
            return Ok(Result.Failure("FORBIDDEN", "Admin only"));

        var result = await _exchange.TestConnectionAsync(ct);
        return Ok(result);
    }
}
