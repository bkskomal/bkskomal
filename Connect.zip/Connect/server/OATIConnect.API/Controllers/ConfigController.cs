using OATIConnect.API.DependencyInjection;
using OATIConnect.API.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace OATIConnect.API.Controllers;

[ApiController]
[Route("api/v1/config")]
public class ConfigController : ControllerBase
{
    private readonly IConfiguration _config;
    private readonly IAppSettingsService _settings;
    private readonly OATIConnect.Server.OATIConnectSettings _sidecar;

    public ConfigController(IConfiguration config, IAppSettingsService settings,
        OATIConnect.Server.OATIConnectSettings? sidecar = null)
    {
        _config   = config;
        _settings = settings;
       
        _sidecar = sidecar
                ?? SidecarConfigLoader.TryLoad()
                ?? new OATIConnect.Server.OATIConnectSettings();   // last resort: defaults (Enabled=true)
    }

    [HttpGet("/oaticonnect/feature")]
    [HttpGet("/api/v1/oaticonnect/feature")]
    [AllowAnonymous]
    public IActionResult Feature()
        => Ok(new { enabled = _sidecar.Enabled });

    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> Get()
    {
      
        async Task<Settings.AppConfigDto?> Read(string key)
        {
            try { return await _settings.GetByKeyAsync(key); }
            catch { return null; }
        }

        var jitsiCfg        = await Read("Jitsi:ServerBaseUrl");
        var appNameCfg      = await Read("App:Name");
        var hostNameCfg     = await Read("App:HostName");
        var showClockCfg    = await Read("App:ShowClock");
        var showThemeCfg    = await Read("App:ShowThemeToggle");
        var defaultThemeCfg = await Read("App:DefaultTheme");

        bool ParseBool(string? raw, bool fallback)
            => bool.TryParse(raw, out var v) ? v : fallback;

        
        string Pick(string? a, string? b, string fallback)
            => !string.IsNullOrWhiteSpace(a) ? a!
             : !string.IsNullOrWhiteSpace(b) ? b!
             : fallback;

        return Ok(new
        {
            jitsiServerBaseUrl = Pick(jitsiCfg?.Value,    _config["Jitsi:ServerBaseUrl"], _sidecar?.Jitsi?.ServerBaseUrl ?? "qa.meet.oati.com"),
            appName            = Pick(appNameCfg?.Value,  _config["App:Name"],            _sidecar?.App?.Name           ?? "OATIConnect"),
            hostName           = Pick(hostNameCfg?.Value, _config["App:HostName"],        "OATIHub"),
            showClock          = ParseBool(showClockCfg?.Value, true),
            showThemeToggle    = ParseBool(showThemeCfg?.Value, true),
            defaultTheme       = string.IsNullOrWhiteSpace(defaultThemeCfg?.Value)
                                    ? "system"
                                    : defaultThemeCfg!.Value!.ToLowerInvariant(),
        });
    }
}
