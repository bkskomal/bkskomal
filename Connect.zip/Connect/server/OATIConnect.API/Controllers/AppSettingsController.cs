using OATIConnect.API.Common;
using OATIConnect.API.Settings;
using Microsoft.AspNetCore.Mvc;

namespace OATIConnect.API.Controllers;

[ApiController]
[Route("api/v1")]
public class AppSettingsController : ControllerBase
{
    private readonly IAppSettingsService _settings;
    private readonly IOATIConnectExternalAPI _api;

    public AppSettingsController(IAppSettingsService settings, IOATIConnectExternalAPI api)
    {
        _settings = settings;
        _api      = api;
    }

    private async Task<IActionResult?> RequireAdmin()
    {
        var user = await _api.GetCurrentUserAsync();
        if (user == null)
            return Ok(Result.Failure("UNAUTHORIZED", "Not authenticated"));
        if (!string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
            return Ok(Result.Failure("FORBIDDEN", "Admin only"));
        return null;
    }

    [HttpGet("appconfig")]
    public async Task<IActionResult> GetAll()
    {
        var deny = await RequireAdmin();
        return deny ?? Ok(await _settings.GetAllAsync());
    }

    [HttpGet("appconfig/{key}")]
    public async Task<IActionResult> GetByKey(string key)
    {
        var deny = await RequireAdmin();
        if (deny != null) return deny;
        var row = await _settings.GetByKeyAsync(key);
        return row is null ? NotFound() : Ok(row);
    }

    [HttpPost("appconfig")]
    public async Task<IActionResult> Upsert(UpsertAppConfigCommand command)
    {
        var deny = await RequireAdmin();
        return deny ?? Ok(await _settings.UpsertAsync(command));
    }

   
    [HttpGet("settings")]
    public async Task<IActionResult> GetMeetingPreferences()
    {
        var user = await _api.GetCurrentUserAsync();
        if (user == null) return Ok(Result.Failure("UNAUTHORIZED", "Not authenticated"));
        return Ok(await _settings.GetMeetingPreferencesAsync());
    }

    [HttpPost("settings")]
    public async Task<IActionResult> SaveMeetingPreferences([FromBody] MeetingPreferencesDto prefs)
    {
        var deny = await RequireAdmin();
        if (deny != null) return deny;
        await _settings.SaveMeetingPreferencesAsync(prefs);
        return Ok(Result.Success());
    }
}
