﻿namespace OATIConnect.API.Domain.Entities;


public enum MeetingStatus
{
    /// <summary>Created but not yet started by the host.</summary>
    Scheduled = 0,

    /// <summary>Host hit "Start"; room is live and accepting joins.</summary>
    Active = 1,

    /// <summary>Host hit "End" (or the room timed out).</summary>
    Ended = 2,

    /// <summary>Host deleted / cancelled before it went active.</summary>
    Cancelled = 3,
}

