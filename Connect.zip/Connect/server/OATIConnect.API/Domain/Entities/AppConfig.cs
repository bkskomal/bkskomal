﻿namespace OATIConnect.API.Domain.Entities;

/// <summary>
/// Universal key-value row for all app settings and meeting preferences.
/// </summary>
public class AppConfig
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";
    public string? Description { get; set; }
    public string Category { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAtUtc { get; set; }
}

