namespace OATIConnect.API.Domain.Entities;


public class MeetingOccurrenceException
{
    public Guid Id { get; set; } = Guid.NewGuid();

    public Guid MeetingId { get; set; }

    public DateTime OriginalStartUtc { get; set; }

    public OccurrenceExceptionType Type { get; set; } = OccurrenceExceptionType.Cancelled;

    public DateTime? OverrideScheduledTimeUtc { get; set; }

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}

public enum OccurrenceExceptionType
{
    Cancelled   = 0, // this occurrence is skipped — RecurrenceCalculator filters it out
    Rescheduled = 1, // future-phase: this occurrence runs at OverrideScheduledTimeUtc instead
}
