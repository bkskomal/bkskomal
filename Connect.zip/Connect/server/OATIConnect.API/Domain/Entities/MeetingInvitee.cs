﻿namespace OATIConnect.API.Domain.Entities;

/// <summary>
/// One row per invited recipient of a <see cref="Meeting"/>.
/// </summary>
public class MeetingInvitee
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MeetingId { get; set; }
    public string Email { get; set; } = "";
    public string SourceKind { get; set; } = "manual";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}

