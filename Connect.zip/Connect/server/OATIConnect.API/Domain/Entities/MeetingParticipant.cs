﻿namespace OATIConnect.API.Domain.Entities;

/// <summary>
/// One row per join of a <see cref="Meeting"/>.
/// </summary>
public class MeetingParticipant
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid MeetingId { get; set; }
    public int UserId { get; set; }
    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public DateTime JoinedAtUtc { get; set; } = DateTime.UtcNow;
}

