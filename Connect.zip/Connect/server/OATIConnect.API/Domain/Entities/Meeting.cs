﻿namespace OATIConnect.API.Domain.Entities;

/// <summary>
/// Meeting aggregate root. Owned by <see cref="HostUserId"/> (the int id
/// surfaced by the host app through <c>IOATIConnectExternalAPI</c>).
/// Persisted in the host database through the same interface
/// — OATIConnect itself ships no EF / schema code.
/// </summary>
public class Meeting
{
    public Guid Id { get; set; }

    /// <summary>Free-form title shown in the UI and used as the Jitsi room id.</summary>
    public string Title { get; set; } = "";

    public string? Description { get; set; }

    /// <summary>Scheduled start (UTC). Always store UTC.</summary>
    public DateTime ScheduledTimeUtc { get; set; }

    /// <summary>Planned meeting length in minutes; defaults to 60 at creation.</summary>
    public int DurationMinutes { get; set; } = 60;

    /// <summary>Jitsi room name. Usually equals <see cref="Title"/>.</summary>
    public string RoomName { get; set; } = "";

    /// <summary>Short numeric join code shown to invitees.</summary>
    public string MeetingCode { get; set; } = "";

    /// <summary>Host''s user id (from <c>IOATIConnectExternalAPI.GetCurrentUserAsync</c>).</summary>
    public int HostUserId { get; set; }

    public MeetingStatus Status { get; set; } = MeetingStatus.Scheduled;

    /// <summary>Set when the host hits "Start" (UTC).</summary>
    public DateTime? ActualStartUtc { get; set; }

    /// <summary>Set when the host hits "End" (UTC).</summary>
    public DateTime? ActualEndUtc { get; set; }

    /// <summary>Prevents new joins once the host locks the room.</summary>
    public bool IsLocked { get; set; }

    /// <summary>
    /// Optional join password. Null/empty means no password required. When
    /// set, the public share-link prejoin gates entry on password match
    /// before issuing a Jitsi token, and the value is shown in the host's
    /// invite email/.ics so recipients have something to type.
    /// </summary>
    public string? Password { get; set; }

    /// <summary>
    /// When true, joiners (share-link guests AND in-app invitees) are
    /// blocked from entering this meeting until the host hits Start
    /// (i.e. <see cref="MeetingStatus.Active"/>). Share-link guests see
    /// a Zoom-style waiting page that auto-resumes; in-app invitees
    /// receive a "host hasn't started yet" error from the join service.
    /// Per-meeting flag — only the host can opt in, and only when the
    /// admin has the global feature pref turned on.
    /// </summary>
    public bool RequireHostStart { get; set; }

    // ===== Recurrence (Zoom-style series, one row per series) =====

    /// <summary>
    /// Recurrence pattern. None = single occurrence (default). All other
    /// values turn the row into a recurring series sharing one room
    /// name, meeting code, share link, and password across every
    /// occurrence.
    /// </summary>
    public RecurrenceType RecurrenceType { get; set; } = RecurrenceType.None;

    /// <summary>
    /// "Every N" multiplier. 1 = every day/week/month, 2 = every other,
    /// etc. Honored for all non-None patterns. Min 1.
    /// </summary>
    public int RecurrenceInterval { get; set; } = 1;

    /// <summary>
    /// Bitmask of weekdays for <see cref="RecurrenceType.Weekly"/>:
    /// Sunday=1, Monday=2, Tuesday=4, Wednesday=8, Thursday=16,
    /// Friday=32, Saturday=64. Ignored for non-weekly patterns.
    /// 0 (= no days picked) implies "the same weekday as the first
    /// occurrence".
    /// </summary>
    public int RecurrenceDaysOfWeekMask { get; set; }

    /// <summary>
    /// How the series ends. Never = unbounded, After = stop after
    /// <see cref="RecurrenceEndCount"/> occurrences, OnDate = stop on
    /// or before <see cref="RecurrenceEndDateUtc"/>.
    /// </summary>
    public RecurrenceEndType RecurrenceEndType { get; set; } = RecurrenceEndType.Never;

    /// <summary>Total occurrences when EndType=After. Null otherwise.</summary>
    public int? RecurrenceEndCount { get; set; }

    /// <summary>Inclusive end date (UTC) when EndType=OnDate. Null otherwise.</summary>
    public DateTime? RecurrenceEndDateUtc { get; set; }

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}

/// <summary>Pattern for recurring meetings. <see cref="None"/> = single occurrence.</summary>
public enum RecurrenceType
{
    None    = 0,
    Daily   = 1,
    Weekly  = 2,
    Monthly = 3,
}

/// <summary>How a recurring series terminates.</summary>
public enum RecurrenceEndType
{
    Never  = 0,
    After  = 1, // stops after RecurrenceEndCount occurrences
    OnDate = 2, // stops on or before RecurrenceEndDateUtc
}

