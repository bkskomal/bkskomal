using OATIConnect.API.Domain.Entities;

namespace OATIConnect.API;


public interface IOATIConnectRepository
{
    // ---------- Meetings ----------

    Task<Meeting?> GetMeetingByIdAsync(Guid meetingId, CancellationToken ct = default);
    Task<Meeting?> GetActiveMeetingByRoomNameAsync(string roomName, CancellationToken ct = default);

    
    Task<Meeting?> GetMeetingByMeetingCodeAsync(string meetingCode, CancellationToken ct = default);

    Task<IReadOnlyList<Meeting>> GetVisibleMeetingsAsync(int userId, string? email, CancellationToken ct = default);
    Task AddMeetingAsync(Meeting meeting, CancellationToken ct = default);
    Task UpdateMeetingAsync(Meeting meeting, CancellationToken ct = default);
    Task DeleteMeetingAsync(Guid meetingId, CancellationToken ct = default);

    // ---------- Invitees ----------

    Task<IReadOnlyList<MeetingInvitee>> GetInviteesAsync(Guid meetingId, CancellationToken ct = default);
    Task ReplaceInviteesAsync(Guid meetingId, IEnumerable<MeetingInvitee> invitees, CancellationToken ct = default);

    // ---------- Participants ----------

    Task<IReadOnlyList<MeetingParticipant>> GetParticipantsAsync(Guid meetingId, CancellationToken ct = default);
    Task AddParticipantAsync(MeetingParticipant participant, CancellationToken ct = default);

    // ---------- App configs ----------

    Task<IReadOnlyList<AppConfig>> GetAllAppConfigsAsync(CancellationToken ct = default);
    Task<AppConfig?> GetAppConfigByKeyAsync(string key, CancellationToken ct = default);
    Task<AppConfig> UpsertAppConfigAsync(AppConfig config, CancellationToken ct = default);

    // ---------- Recurrence occurrence exceptions ----------

    Task<IReadOnlyList<MeetingOccurrenceException>> GetOccurrenceExceptionsAsync(Guid meetingId, CancellationToken ct = default);

    Task AddOccurrenceExceptionAsync(MeetingOccurrenceException exception, CancellationToken ct = default);

    Task DeleteOccurrenceExceptionsAsync(Guid meetingId, CancellationToken ct = default);
}
