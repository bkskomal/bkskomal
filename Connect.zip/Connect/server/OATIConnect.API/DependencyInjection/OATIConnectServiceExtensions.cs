namespace Microsoft.Extensions.DependencyInjection;

using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.Extensions.DependencyInjection.Extensions;
using OATIConnect.API;
using OATIConnect.API.DependencyInjection;
using OATIConnect.API.Exchange;
using OATIConnect.API.Jitsi;
using OATIConnect.API.Meetings;
using OATIConnect.API.Settings;

public static class OATIConnectServiceExtensions
{
    public static IServiceCollection AddOATIConnect(
        this IServiceCollection services,
        Action<OATIConnectOptions>? configure = null)
    {
        var options = new OATIConnectOptions();
        configure?.Invoke(options);
        services.AddSingleton(options);

        services.AddHttpClient("OATIConnect-Graph");
        services.AddMemoryCache();

        services.AddDataProtection();


        services.AddScoped<IMeetingService,           MeetingService>();
        services.AddScoped<IJitsiTokenService,        JitsiTokenService>();
        services.AddScoped<IJitsiJoinService,         JitsiJoinService>();
        services.AddScoped<IMeetingCalendarService,   MeetingCalendarService>();
        services.AddScoped<IAppSettingsService,       AppSettingsService>();
        services.AddScoped<IExchangeDirectoryService, GraphExchangeDirectoryService>();
        services.AddSingleton<IMeetingShareTokenService, MeetingShareTokenService>();
        services.AddSingleton<IMeetingPasswordProtector, MeetingPasswordProtector>();
        // Scoped now (was Singleton) because HostPresenceTracker depends
        // on the scoped IOATIConnectExternalAPI repository to persist
        // host last-seen timestamps in AppConfig — surviving IIS
        // multi-worker deployments and app-pool recycles.
        services.AddScoped<IHostPresenceTracker, HostPresenceTracker>();

       
        services.TryAddScoped<IOATIConnectRequestUrlProvider, NullRequestUrlProvider>();

       
        var asm = typeof(OATIConnectServiceExtensions).Assembly;

        services.AddControllers().AddApplicationPart(asm);

        var apmAddedDirect = false;
        foreach (var d in services.Where(x => x.ServiceType == typeof(ApplicationPartManager)).ToList())
        {
            if (d.ImplementationInstance is ApplicationPartManager apm
                && !apm.ApplicationParts.OfType<AssemblyPart>().Any(p => p.Assembly == asm))
            {
                apm.ApplicationParts.Add(new AssemblyPart(asm));
                apmAddedDirect = true;
            }
        }

       
        services.AddSingleton<Microsoft.Extensions.Options.IConfigureOptions<Microsoft.AspNetCore.Mvc.MvcOptions>>(
            sp => new OATIConnectApplicationPartFixup(sp.GetRequiredService<ApplicationPartManager>(), asm));

       
        try
        {
            Console.Error.WriteLine(
                $"[OATIConnect] AddOATIConnect ENTERED. asm={asm.GetName().Name} v={asm.GetName().Version} location='{asm.Location}'");
            Console.Error.WriteLine(
                $"[OATIConnect]   path1 (IMvcBuilder.AddApplicationPart) = called");
            Console.Error.WriteLine(
                $"[OATIConnect]   path2 (direct APM instance mutation)   = {(apmAddedDirect ? "added" : "skipped (no APM instance descriptor yet — path3 will handle it)")}");
            Console.Error.WriteLine(
                $"[OATIConnect]   path3 (IConfigureOptions<MvcOptions>) = registered (will run when MVC configures)");

            var controllerTypes = asm.GetTypes()
                .Where(t => !t.IsAbstract && typeof(Microsoft.AspNetCore.Mvc.ControllerBase).IsAssignableFrom(t))
                .ToList();
            Console.Error.WriteLine(
                $"[OATIConnect]   controllers in DLL = {controllerTypes.Count}: {string.Join(", ", controllerTypes.Select(t => t.Name))}");
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[OATIConnect] startup diagnostic failed: {ex.Message}");
        }

        return services;
    }

    
    private sealed class OATIConnectApplicationPartFixup
        : Microsoft.Extensions.Options.IConfigureOptions<Microsoft.AspNetCore.Mvc.MvcOptions>
    {
        private readonly ApplicationPartManager _apm;
        private readonly System.Reflection.Assembly _asm;

        public OATIConnectApplicationPartFixup(ApplicationPartManager apm, System.Reflection.Assembly asm)
        {
            _apm = apm; _asm = asm;
        }

        public void Configure(Microsoft.AspNetCore.Mvc.MvcOptions options)
        {
            try
            {
                var already = _apm.ApplicationParts.OfType<AssemblyPart>().Any(p => p.Assembly == _asm);
                if (!already)
                {
                    _apm.ApplicationParts.Add(new AssemblyPart(_asm));
                    Console.Error.WriteLine($"[OATIConnect] path3 added AssemblyPart for {_asm.GetName().Name} via IConfigureOptions<MvcOptions>");
                }
                else
                {
                    Console.Error.WriteLine($"[OATIConnect] path3: AssemblyPart for {_asm.GetName().Name} already present (paths 1/2 worked) — skipping");
                }

                var oatiCount = _apm.ApplicationParts
                    .OfType<AssemblyPart>()
                    .Count(p => p.Assembly == _asm);
                Console.Error.WriteLine($"[OATIConnect] APM final state: total parts={_apm.ApplicationParts.Count}, OATIConnect.API parts={oatiCount}");
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"[OATIConnect] path3 fixup failed: {ex.Message}");
            }
        }
    }
}
