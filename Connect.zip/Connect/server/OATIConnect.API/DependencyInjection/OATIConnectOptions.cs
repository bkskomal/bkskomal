namespace OATIConnect.API.DependencyInjection;

public enum DatabaseProviderKind
{
    SqlServer,
    Postgres,
    MySql
}

public class OATIConnectOptions
{
    public string JitsiAppId { get; set; } = "";
    public string JitsiServerBaseUrl { get; set; } = "";
    public string JitsiPrivateKeyFile { get; set; } = "";
    public string ApiPrefix { get; set; } = "api/v1";
}
