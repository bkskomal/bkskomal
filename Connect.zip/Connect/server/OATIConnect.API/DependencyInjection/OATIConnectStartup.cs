﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OATIConnect.API;
using OATIConnect.API.DependencyInjection;
using OATIConnect.API.Domain.Entities;
using System.Reflection;

namespace OATIConnect.Server;


public static class OATIConnectStartup
{
    public static IServiceCollection UseOATIConnect(this IServiceCollection services)
    {
  
        var candidatePaths = new List<string>
        {
            AppContext.BaseDirectory,
            Directory.GetCurrentDirectory(),
            Path.GetDirectoryName(typeof(OATIConnectStartup).Assembly.Location) ?? "",
        };
        candidatePaths = candidatePaths
            .Where(p => !string.IsNullOrWhiteSpace(p))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var resolvedConfigDir = candidatePaths.FirstOrDefault(p =>
            File.Exists(Path.Combine(p, "oaticonnect_config.json")));

        var configuration = new ConfigurationBuilder()
            .SetBasePath(resolvedConfigDir ?? AppContext.BaseDirectory)
            .AddJsonFile("oaticonnect_config.json", optional: true, reloadOnChange: true)
            .Build();

        var settings = new OATIConnectSettings();
        configuration.GetSection("OATIConnect").Bind(settings);
        services.AddSingleton(settings);

        if (resolvedConfigDir != null)
        {
            Console.Error.WriteLine(
                $"[OATIConnect] loaded {resolvedConfigDir}\\oaticonnect_config.json " +
                $"(Enabled={settings.Enabled}, Jitsi.AppId='{settings.Jitsi.AppId}', Jitsi.ServerBaseUrl='{settings.Jitsi.ServerBaseUrl}')");
        }
        else
        {
            Console.Error.WriteLine(
                "[OATIConnect] oaticonnect_config.json NOT FOUND. Searched: " +
                string.Join(", ", candidatePaths));
        }

        if (!settings.Enabled)
        {
            Console.Error.WriteLine("[OATIConnect] Enabled=false â€” skipping service registration. The host will not expose OATIConnect endpoints, controllers, or DB schema.");
            services.AddControllers().ConfigureApplicationPartManager(apm =>
            {
                var defaults = apm.FeatureProviders
                    .OfType<ControllerFeatureProvider>()
                    .Where(p => p.GetType() != typeof(ExcludeOATIConnectControllers))
                    .ToList();
                foreach (var d in defaults) apm.FeatureProviders.Remove(d);
                apm.FeatureProviders.Add(new ExcludeOATIConnectControllers());
            });
            return services;
        }

        services.AddOATIConnect(options =>
        {
            options.JitsiServerBaseUrl  = settings.Jitsi.ServerBaseUrl;
            options.JitsiAppId          = settings.Jitsi.AppId;
            options.JitsiPrivateKeyFile = settings.Jitsi.PrivateKeyFile;
        });

        return services;
    }

    public static bool IsOATIConnectEnabled(this IServiceProvider services)
    {
        var settings = services.GetService<OATIConnectSettings>();
        return settings?.Enabled ?? false;
    }

   
    public static IApplicationBuilder ConfigureOATIConnect(this IApplicationBuilder app)
    {
        var settings = app.ApplicationServices.GetService<OATIConnectSettings>();
        if (settings != null && !settings.Enabled)
        {
            Console.Error.WriteLine("[OATIConnect] Enabled=false â€” skipping migrations and AppConfigs seeding.");
            return app;
        }

        var config  = app.ApplicationServices.GetRequiredService<IConfiguration>();

        try
        {
            using var seedScope = app.ApplicationServices.CreateScope();
            var data = seedScope.ServiceProvider.GetRequiredService<IOATIConnectExternalAPI>();

            SeedIfMissing(data, "Jitsi:ServerBaseUrl",
                settings?.Jitsi.ServerBaseUrl ?? config["Jitsi:ServerBaseUrl"] ?? "qa.meet.oati.com",
                "Jitsi server base URL", "Jitsi").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:Name",
                settings?.App.Name ?? config["App:Name"] ?? "OATIConnect",
                "Display name of the application", "Branding").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:HostName",
                config["App:HostName"] ?? "OATIHub",
                "Display name of the surrounding host portal (e.g. OATIHub) â€” appears in invite emails", "Branding").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:ShowClock",       "true",
                "Show the live clock in the top header (true/false)", "Header").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:ShowThemeToggle", "true",
                "Show the dark/light theme toggle button in the top header (true/false)", "Header").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:DefaultTheme",    "system",
                "Initial theme when no per-user override exists: light, dark, or system (follows OS)", "Header").GetAwaiter().GetResult();
        }
        catch
        {
        }

        return app;
    }

    private static async Task SeedIfMissing(IOATIConnectExternalAPI data, string key, string value, string desc, string cat)
    {
        var existing = await data.GetAppConfigByKeyAsync(key);
        if (existing != null) return;
        await data.UpsertAppConfigAsync(new AppConfig
        {
            Id           = Guid.NewGuid(),
            Key          = key,
            Value        = value,
            Description  = desc,
            Category     = cat,
            CreatedAtUtc = DateTime.UtcNow,
        });
    }

    private sealed class ExcludeOATIConnectControllers : ControllerFeatureProvider
    {
        protected override bool IsController(TypeInfo typeInfo)
        {
            if (!base.IsController(typeInfo)) return false;
            var ns = typeInfo.Namespace ?? "";
            if (ns.StartsWith("OATIConnect.API.", StringComparison.OrdinalIgnoreCase) ||
                ns.Equals  ("OATIConnect.API",   StringComparison.OrdinalIgnoreCase))
                return false;
            return true;
        }
    }
}


