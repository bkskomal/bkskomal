namespace OATIConnect.Server;


public class OATIConnectSettings
{
    public bool Enabled { get; set; } = true;

    public OATIConnectJitsiSettings Jitsi { get; set; } = new();
    public OATIConnectAppSettings   App   { get; set; } = new();
}

public class OATIConnectJitsiSettings
{
    public string ServerBaseUrl  { get; set; } = "";
    public string ServerUrl      { get; set; } = "";
    public string AppId          { get; set; } = "";
    public string PrivateKeyFile { get; set; } = "jitsi-private-key.pem";
}

public class OATIConnectAppSettings
{
    public string Name { get; set; } = "OATIConnect";

   
    public string WebAppUrl { get; set; } = "";
}
