using Microsoft.Extensions.Configuration;
using OATIConnect.Server;

namespace OATIConnect.API.DependencyInjection;

internal static class SidecarConfigLoader
{
    private static readonly object _lock = new();
    private static OATIConnectSettings? _cached;
    private static string? _cachedPath;
    private static bool _attempted;

    public static OATIConnectSettings? TryLoad()
    {
        if (_attempted) return _cached;
        lock (_lock)
        {
            if (_attempted) return _cached;
            _attempted = true;
            try
            {
                var paths = ProbePaths();
                var hit = paths.FirstOrDefault(p => File.Exists(Path.Combine(p, "oaticonnect_config.json")));
                if (hit == null)
                {
                    Console.Error.WriteLine("[OATIConnect/SidecarConfigLoader] oaticonnect_config.json NOT FOUND. Searched: " + string.Join(", ", paths));
                    return null;
                }
                var configuration = new ConfigurationBuilder()
                    .SetBasePath(hit)
                    .AddJsonFile("oaticonnect_config.json", optional: false, reloadOnChange: true)
                    .Build();
                var settings = new OATIConnectSettings();
                configuration.GetSection("OATIConnect").Bind(settings);
                _cached = settings;
                _cachedPath = hit;
                Console.Error.WriteLine($"[OATIConnect/SidecarConfigLoader] loaded {hit}\\oaticonnect_config.json (Jitsi.AppId='{settings.Jitsi.AppId}', Jitsi.ServerBaseUrl='{settings.Jitsi.ServerBaseUrl}')");
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("[OATIConnect/SidecarConfigLoader] failed to load oaticonnect_config.json: " + ex.Message);
            }
        }
        return _cached;
    }

    public static string? CachedPath => _cachedPath;

    private static List<string> ProbePaths()
    {
        var paths = new List<string>
        {
            AppContext.BaseDirectory,
            Directory.GetCurrentDirectory(),
            Path.GetDirectoryName(typeof(SidecarConfigLoader).Assembly.Location) ?? "",
        };
        var seed = paths.ToList();
        foreach (var p in seed)
        {
            if (string.IsNullOrWhiteSpace(p)) continue;
            try
            {
                var parent = Directory.GetParent(p)?.FullName;
                if (!string.IsNullOrWhiteSpace(parent)) paths.Add(parent);
                var grand = parent != null ? Directory.GetParent(parent)?.FullName : null;
                if (!string.IsNullOrWhiteSpace(grand)) paths.Add(grand);
            }
            catch { /* path math is best-effort */ }
        }
        return paths
            .Where(p => !string.IsNullOrWhiteSpace(p))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }
}
