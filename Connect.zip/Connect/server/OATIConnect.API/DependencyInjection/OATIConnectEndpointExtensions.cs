﻿namespace Microsoft.AspNetCore.Builder;

using OATIConnect.API;
using OATIConnect.API.DependencyInjection;
using OATIConnect.API.Domain.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

public static class OATIConnectEndpointExtensions
{
    public static WebApplication MapOATIConnect(this WebApplication app)
    {
        var config = app.Services.GetRequiredService<IConfiguration>();

        try
        {
            using var seedScope = app.Services.CreateScope();
            var data = seedScope.ServiceProvider.GetRequiredService<IOATIConnectExternalAPI>();

            SeedIfMissing(data, "Jitsi:ServerBaseUrl",
                config["Jitsi:ServerBaseUrl"] ?? "qa.meet.oati.com",
                "Jitsi server base URL", "Jitsi").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:Name",
                config["App:Name"] ?? "OATIConnect",
                "Display name of the application", "Branding").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:HostName",
                config["App:HostName"] ?? "OATIHub",
                "Display name of the surrounding host portal (e.g. OATIHub) â€” appears in invite emails", "Branding").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:ShowClock",       "true",
                "Show the live clock in the top header (true/false)", "Header").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:ShowThemeToggle", "true",
                "Show the dark/light theme toggle button in the top header (true/false)", "Header").GetAwaiter().GetResult();

            SeedIfMissing(data, "App:DefaultTheme",    "system",
                "Initial theme when no per-user override exists: light, dark, or system (follows OS)", "Header").GetAwaiter().GetResult();
        }
        catch { /* host owns persistence; skip seeding if it isn't ready */ }

        return app;
    }

    private static async Task SeedIfMissing(IOATIConnectExternalAPI data, string key, string value, string desc, string cat)
    {
        var existing = await data.GetAppConfigByKeyAsync(key);
        if (existing != null) return;
        await data.UpsertAppConfigAsync(new AppConfig
        {
            Id           = Guid.NewGuid(),
            Key          = key,
            Value        = value,
            Description  = desc,
            Category     = cat,
            CreatedAtUtc = DateTime.UtcNow,
        });
    }
}


