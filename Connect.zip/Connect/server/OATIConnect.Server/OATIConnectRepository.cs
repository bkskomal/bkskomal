using Microsoft.EntityFrameworkCore;
using OATIConnect.API;
using OATIConnect.API.Domain.Entities;
using OATIConnect.EntityFramework;
using OATIConnect.EntityFramework.Models;

// Lives in a dedicated OATIConnect.Server class library — mirrors the
// production OATIHub.Server project layout 1:1. The facade
// (OATIConnect.Client.OATIConnectExternalAPI) lives in the
// OATIConnect.Client project and imports this namespace to delegate
// persistence. Same pattern as the production host's OATIHub project
// importing `OATIHub.Server`.
namespace OATIConnect.Server;

/// <summary>
/// EF-backed repository the demo's <see cref="OATIConnectExternalAPI"/>
/// delegates to for every persistence operation. Mirrors the layering
/// the production host should adopt: a thin facade exposed via
/// <see cref="OATIConnect.API.IOATIConnectExternalAPI"/>, sitting in
/// front of a repository that owns the DbContext and entity mapping.
///
/// <para>
/// Repository methods return / accept <c>OATIConnect.API.Domain.Entities</c>
/// types (the domain language the OATIConnect.API DLL speaks). EF rows
/// live in <c>OATIConnect.EntityFramework.Models</c>; mapping between
/// the two happens here, in one place, so the DLL never touches an EF
/// type.
/// </para>
///
/// <para>
/// Re-stamps <see cref="DateTime"/> Kind=Utc on every read. EF normally
/// returns columns as Kind=Unspecified — System.Text.Json then drops
/// the trailing "Z" on serialize, the React UI parses values as local
/// time, and timezone math goes wrong. The DbContext value converter
/// already does this, but the explicit Utc() guard here is belt-and-
/// suspenders for hosts that wire EF differently.
/// </para>
/// </summary>
public class OATIConnectRepository : IOATIConnectRepository
{
    private readonly OATIConnectDbContext _db;

    public OATIConnectRepository(OATIConnectDbContext db) => _db = db;

    // ===== Meetings =====

    public async Task<Meeting?> GetMeetingByIdAsync(Guid meetingId, CancellationToken ct = default)
    {
        var row = await _db.OATIConnectMeetings.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == meetingId, ct);
        return row == null ? null : ToEntity(row);
    }

    public async Task<Meeting?> GetActiveMeetingByRoomNameAsync(string roomName, CancellationToken ct = default)
    {
        var row = await _db.OATIConnectMeetings.AsNoTracking()
            .Where(x => x.RoomName == roomName && x.Status != 3)
            .OrderByDescending(x => x.CreatedAtUtc)
            .FirstOrDefaultAsync(ct);
        return row == null ? null : ToEntity(row);
    }

    public async Task<Meeting?> GetMeetingByMeetingCodeAsync(string meetingCode, CancellationToken ct = default)
    {
        // Primary: lookup by stored MeetingCode. For meetings created with
        // meetingNameMode = "auto", MeetingService.DeriveMeetingCode now
        // stores the Title's digits here so the user-facing handle == the
        // join code; for "manual" titles MeetingCode is an independent
        // 9-digit random.
        var row = await _db.OATIConnectMeetings.AsNoTracking()
            .FirstOrDefaultAsync(x => x.MeetingCode == meetingCode, ct);
        if (row != null) return ToEntity(row);

        // Defensive fallback for legacy meetings created BEFORE DeriveMeetingCode
        // landed — Title may carry the Zoom-style 10-digit ID the host gave
        // out while MeetingCode holds an unrelated random 9-digit code.
        // Match the inbound code against the Title's digits ("770 961 5728"
        // → "7709615728"). Excludes Deleted (Status=3).
        row = await _db.OATIConnectMeetings.AsNoTracking()
            .Where(x => x.Status != 3 && x.Title.Replace(" ", "").Replace("-", "") == meetingCode)
            .OrderByDescending(x => x.CreatedAtUtc)
            .FirstOrDefaultAsync(ct);
        return row == null ? null : ToEntity(row);
    }

    public async Task<IReadOnlyList<Meeting>> GetVisibleMeetingsAsync(int userId, string? email, CancellationToken ct = default)
    {
        var rows = await
            (from m in _db.OATIConnectMeetings.AsNoTracking()
             where m.HostUserId == userId
                || _db.OATIConnectMeetingInvitees.Any(i => i.MeetingId == m.Id && i.Email == email)
             orderby m.ScheduledTimeUtc descending
             select m).ToListAsync(ct);
        return rows.Select(ToEntity).ToList();
    }

    public async Task AddMeetingAsync(Meeting meeting, CancellationToken ct = default)
    {
        _db.OATIConnectMeetings.Add(FromEntity(meeting));
        await _db.SaveChangesAsync(ct);
    }

    public async Task UpdateMeetingAsync(Meeting meeting, CancellationToken ct = default)
    {
        var existing = await _db.OATIConnectMeetings.FirstOrDefaultAsync(x => x.Id == meeting.Id, ct);
        if (existing == null) return;

        existing.Title            = meeting.Title;
        existing.Description      = meeting.Description;
        existing.ScheduledTimeUtc = meeting.ScheduledTimeUtc;
        existing.DurationMinutes  = meeting.DurationMinutes;
        existing.RoomName         = meeting.RoomName;
        existing.MeetingCode      = meeting.MeetingCode;
        existing.HostUserId       = meeting.HostUserId;
        existing.Status           = (int)meeting.Status;
        existing.ActualStartUtc   = meeting.ActualStartUtc;
        existing.ActualEndUtc     = meeting.ActualEndUtc;
        existing.IsLocked         = meeting.IsLocked;
        existing.Password         = meeting.Password;
        existing.RequireHostStart = meeting.RequireHostStart;
        existing.RecurrenceType              = (int)meeting.RecurrenceType;
        existing.RecurrenceInterval          = meeting.RecurrenceInterval;
        existing.RecurrenceDaysOfWeekMask    = meeting.RecurrenceDaysOfWeekMask;
        existing.RecurrenceEndType           = (int)meeting.RecurrenceEndType;
        existing.RecurrenceEndCount          = meeting.RecurrenceEndCount;
        existing.RecurrenceEndDateUtc        = meeting.RecurrenceEndDateUtc;
        await _db.SaveChangesAsync(ct);
    }

    public async Task DeleteMeetingAsync(Guid meetingId, CancellationToken ct = default)
    {
        var m = await _db.OATIConnectMeetings.FirstOrDefaultAsync(x => x.Id == meetingId, ct);
        if (m == null) return;
        _db.OATIConnectMeetings.Remove(m);
        _db.OATIConnectMeetingInvitees.RemoveRange(_db.OATIConnectMeetingInvitees.Where(i => i.MeetingId == meetingId));
        _db.OATIConnectMeetingParticipants.RemoveRange(_db.OATIConnectMeetingParticipants.Where(p => p.MeetingId == meetingId));
        _db.OATIConnectMeetingOccurrenceExceptions.RemoveRange(_db.OATIConnectMeetingOccurrenceExceptions.Where(e => e.MeetingId == meetingId));
        await _db.SaveChangesAsync(ct);
    }

    // ===== Invitees =====

    public async Task<IReadOnlyList<MeetingInvitee>> GetInviteesAsync(Guid meetingId, CancellationToken ct = default)
    {
        var rows = await _db.OATIConnectMeetingInvitees.AsNoTracking()
            .Where(x => x.MeetingId == meetingId).ToListAsync(ct);
        return rows.Select(ToEntity).ToList();
    }

    public async Task ReplaceInviteesAsync(Guid meetingId, IEnumerable<MeetingInvitee> invitees, CancellationToken ct = default)
    {
        _db.OATIConnectMeetingInvitees.RemoveRange(_db.OATIConnectMeetingInvitees.Where(x => x.MeetingId == meetingId));

        foreach (var i in invitees ?? Enumerable.Empty<MeetingInvitee>())
        {
            var row = FromEntity(i);
            row.MeetingId = meetingId;
            if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
            _db.OATIConnectMeetingInvitees.Add(row);
        }
        await _db.SaveChangesAsync(ct);
    }

    // ===== Participants =====

    public async Task<IReadOnlyList<MeetingParticipant>> GetParticipantsAsync(Guid meetingId, CancellationToken ct = default)
    {
        var rows = await _db.OATIConnectMeetingParticipants.AsNoTracking()
            .Where(x => x.MeetingId == meetingId)
            .OrderBy(x => x.JoinedAtUtc)
            .ToListAsync(ct);
        return rows.Select(ToEntity).ToList();
    }

    public async Task AddParticipantAsync(MeetingParticipant participant, CancellationToken ct = default)
    {
        var row = FromEntity(participant);
        if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
        _db.OATIConnectMeetingParticipants.Add(row);
        await _db.SaveChangesAsync(ct);
    }

    // ===== Recurrence occurrence exceptions =====

    public async Task<IReadOnlyList<MeetingOccurrenceException>> GetOccurrenceExceptionsAsync(Guid meetingId, CancellationToken ct = default)
    {
        var rows = await _db.OATIConnectMeetingOccurrenceExceptions.AsNoTracking()
            .Where(x => x.MeetingId == meetingId)
            .ToListAsync(ct);
        return rows.Select(ToEntity).ToList();
    }

    public async Task AddOccurrenceExceptionAsync(MeetingOccurrenceException exception, CancellationToken ct = default)
    {
        var row = FromEntity(exception);
        if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
        if (row.CreatedAtUtc == default) row.CreatedAtUtc = DateTime.UtcNow;
        _db.OATIConnectMeetingOccurrenceExceptions.Add(row);
        await _db.SaveChangesAsync(ct);
    }

    public async Task DeleteOccurrenceExceptionsAsync(Guid meetingId, CancellationToken ct = default)
    {
        _db.OATIConnectMeetingOccurrenceExceptions.RemoveRange(
            _db.OATIConnectMeetingOccurrenceExceptions.Where(x => x.MeetingId == meetingId));
        await _db.SaveChangesAsync(ct);
    }

    // ===== AppConfigs =====

    public async Task<IReadOnlyList<AppConfig>> GetAllAppConfigsAsync(CancellationToken ct = default)
    {
        var rows = await _db.OATIConnectAppConfigs.AsNoTracking().ToListAsync(ct);
        return rows.Select(ToEntity).ToList();
    }

    public async Task<AppConfig?> GetAppConfigByKeyAsync(string key, CancellationToken ct = default)
    {
        var row = await _db.OATIConnectAppConfigs.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Key == key, ct);
        return row == null ? null : ToEntity(row);
    }

    public async Task<AppConfig> UpsertAppConfigAsync(AppConfig config, CancellationToken ct = default)
    {
        var existing = await _db.OATIConnectAppConfigs.FirstOrDefaultAsync(x => x.Key == config.Key, ct);
        if (existing == null)
        {
            var row = FromEntity(config);
            if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
            if (row.CreatedAtUtc == default) row.CreatedAtUtc = DateTime.UtcNow;
            _db.OATIConnectAppConfigs.Add(row);
            await _db.SaveChangesAsync(ct);
            return ToEntity(row);
        }

        existing.Value        = config.Value;
        existing.Description  = config.Description ?? existing.Description;
        existing.Category     = string.IsNullOrWhiteSpace(config.Category) ? existing.Category : config.Category;
        existing.UpdatedAtUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        return ToEntity(existing);
    }

    // =========================================================================
    // EF row <-> domain entity mapping
    // =========================================================================

    private static DateTime  Utc(DateTime  v) => DateTime.SpecifyKind(v, DateTimeKind.Utc);
    private static DateTime? Utc(DateTime? v) => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : null;

    private static Meeting ToEntity(OATIConnectMeeting m) => new()
    {
        Id               = m.Id,
        Title            = m.Title,
        Description      = m.Description,
        ScheduledTimeUtc = Utc(m.ScheduledTimeUtc),
        DurationMinutes  = m.DurationMinutes,
        RoomName         = m.RoomName,
        MeetingCode      = m.MeetingCode,
        HostUserId       = m.HostUserId,
        Status           = (MeetingStatus)m.Status,
        ActualStartUtc   = Utc(m.ActualStartUtc),
        ActualEndUtc     = Utc(m.ActualEndUtc),
        IsLocked         = m.IsLocked,
        Password         = m.Password,
        RequireHostStart = m.RequireHostStart,
        RecurrenceType            = (RecurrenceType)m.RecurrenceType,
        RecurrenceInterval        = m.RecurrenceInterval > 0 ? m.RecurrenceInterval : 1,
        RecurrenceDaysOfWeekMask  = m.RecurrenceDaysOfWeekMask,
        RecurrenceEndType         = (RecurrenceEndType)m.RecurrenceEndType,
        RecurrenceEndCount        = m.RecurrenceEndCount,
        RecurrenceEndDateUtc      = Utc(m.RecurrenceEndDateUtc),
        CreatedAtUtc     = Utc(m.CreatedAtUtc),
    };

    private static OATIConnectMeeting FromEntity(Meeting m) => new()
    {
        Id               = m.Id == Guid.Empty ? Guid.NewGuid() : m.Id,
        Title            = m.Title,
        Description      = m.Description,
        ScheduledTimeUtc = m.ScheduledTimeUtc,
        DurationMinutes  = m.DurationMinutes,
        RoomName         = m.RoomName,
        MeetingCode      = m.MeetingCode,
        HostUserId       = m.HostUserId,
        Status           = (int)m.Status,
        ActualStartUtc   = m.ActualStartUtc,
        ActualEndUtc     = m.ActualEndUtc,
        IsLocked         = m.IsLocked,
        Password         = m.Password,
        RequireHostStart = m.RequireHostStart,
        RecurrenceType            = (int)m.RecurrenceType,
        RecurrenceInterval        = m.RecurrenceInterval > 0 ? m.RecurrenceInterval : 1,
        RecurrenceDaysOfWeekMask  = m.RecurrenceDaysOfWeekMask,
        RecurrenceEndType         = (int)m.RecurrenceEndType,
        RecurrenceEndCount        = m.RecurrenceEndCount,
        RecurrenceEndDateUtc      = m.RecurrenceEndDateUtc,
        CreatedAtUtc     = m.CreatedAtUtc == default ? DateTime.UtcNow : m.CreatedAtUtc,
    };

    private static MeetingInvitee ToEntity(OATIConnectMeetingInvitee x) => new()
    {
        Id           = x.Id,
        MeetingId    = x.MeetingId,
        Email        = x.Email,
        SourceKind   = x.SourceKind,
        CreatedAtUtc = Utc(x.CreatedAtUtc),
    };

    private static OATIConnectMeetingInvitee FromEntity(MeetingInvitee x) => new()
    {
        Id           = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
        MeetingId    = x.MeetingId,
        Email        = x.Email,
        SourceKind   = string.IsNullOrWhiteSpace(x.SourceKind) ? "manual" : x.SourceKind,
        CreatedAtUtc = x.CreatedAtUtc == default ? DateTime.UtcNow : x.CreatedAtUtc,
    };

    private static MeetingParticipant ToEntity(OATIConnectMeetingParticipant x) => new()
    {
        Id          = x.Id,
        MeetingId   = x.MeetingId,
        UserId      = x.UserId,
        Name        = x.Name ?? "",
        Email       = x.Email ?? "",
        JoinedAtUtc = Utc(x.JoinedAtUtc),
    };

    private static OATIConnectMeetingParticipant FromEntity(MeetingParticipant x) => new()
    {
        Id          = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
        MeetingId   = x.MeetingId,
        UserId      = x.UserId,
        Name        = x.Name,
        Email       = x.Email,
        JoinedAtUtc = x.JoinedAtUtc == default ? DateTime.UtcNow : x.JoinedAtUtc,
    };

    private static AppConfig ToEntity(OATIConnectAppConfig x) => new()
    {
        Id           = x.Id,
        Key          = x.Key,
        Value        = x.Value ?? "",
        Description  = x.Description,
        Category     = x.Category ?? "",
        CreatedAtUtc = Utc(x.CreatedAtUtc),
        UpdatedAtUtc = Utc(x.UpdatedAtUtc),
    };

    private static OATIConnectAppConfig FromEntity(AppConfig x) => new()
    {
        Id           = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
        Key          = x.Key,
        Value        = x.Value,
        Description  = x.Description,
        Category     = string.IsNullOrWhiteSpace(x.Category) ? "General" : x.Category,
        CreatedAtUtc = x.CreatedAtUtc == default ? DateTime.UtcNow : x.CreatedAtUtc,
        UpdatedAtUtc = x.UpdatedAtUtc,
    };

    private static MeetingOccurrenceException ToEntity(OATIConnectMeetingOccurrenceException x) => new()
    {
        Id                       = x.Id,
        MeetingId                = x.MeetingId,
        OriginalStartUtc         = Utc(x.OriginalStartUtc),
        Type                     = (OccurrenceExceptionType)x.Type,
        OverrideScheduledTimeUtc = Utc(x.OverrideScheduledTimeUtc),
        CreatedAtUtc             = Utc(x.CreatedAtUtc),
    };

    private static OATIConnectMeetingOccurrenceException FromEntity(MeetingOccurrenceException x) => new()
    {
        Id                       = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
        MeetingId                = x.MeetingId,
        OriginalStartUtc         = x.OriginalStartUtc,
        Type                     = (int)x.Type,
        OverrideScheduledTimeUtc = x.OverrideScheduledTimeUtc,
        CreatedAtUtc             = x.CreatedAtUtc == default ? DateTime.UtcNow : x.CreatedAtUtc,
    };
}
