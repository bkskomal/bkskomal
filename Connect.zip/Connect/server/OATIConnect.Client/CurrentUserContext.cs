using OATIConnect.API;
using System.Security.Claims;

namespace OATIConnect.Client;

/// <summary>
/// Per-request holder for everything the demo's
/// <see cref="OATIConnectExternalAPI"/> facade needs to read from the
/// inbound HTTP request without injecting <c>IHttpContextAccessor</c>:
///
/// <list type="bullet">
///   <item><description><see cref="User"/> — the
///     <see cref="ClaimsPrincipal"/> for the cookie-authenticated user,
///     used by <c>GetCurrentUserAsync</c>.</description></item>
///   <item><description><see cref="BaseUrl"/> — the public-facing base
///     URL the admin is currently on (e.g. <c>https://localhost:5206</c>),
///     consumed by <see cref="DemoRequestUrlProvider"/> so outbound
///     invitations (email + .ics) carry HTTPS URLs when the admin is
///     on HTTPS.</description></item>
/// </list>
///
/// Populated by <see cref="CurrentUserMiddleware"/> once per request.
/// </summary>
public class CurrentUserContext
{
    public ClaimsPrincipal? User { get; set; }
    public string? BaseUrl { get; set; }
}

/// <summary>
/// Runs once per request, copies <c>HttpContext.User</c> and the
/// request's scheme+host (post-PathBase) into the scoped
/// <see cref="CurrentUserContext"/>. Register AFTER
/// <c>UseAuthentication</c> + <c>UsePathBase</c> so both values are
/// fully resolved.
/// </summary>
public class CurrentUserMiddleware
{
    private readonly RequestDelegate _next;

    public CurrentUserMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext ctx, CurrentUserContext holder)
    {
        holder.User    = ctx.User;
        // Capture scheme + host + path-base so URLs we bake into
        // invitations match whatever the admin is browsing. Trims the
        // trailing slash so callers can concatenate safely.
        var req = ctx.Request;
        var pathBase = req.PathBase.HasValue ? req.PathBase.Value : "";
        holder.BaseUrl = $"{req.Scheme}://{req.Host}{pathBase}".TrimEnd('/');
        await _next(ctx);
    }
}

/// <summary>
/// Demo implementation of <see cref="IOATIConnectRequestUrlProvider"/>.
/// Reads the per-request base URL out of <see cref="CurrentUserContext"/>
/// so outbound invitations (email body + .ics) track whatever scheme
/// + host the admin is currently using. Production hosts typically
/// implement this differently — e.g. webVision's UrlContext static, a
/// configured public URL, or null to defer to config.
/// </summary>
public class DemoRequestUrlProvider : IOATIConnectRequestUrlProvider
{
    private readonly CurrentUserContext _context;
    public DemoRequestUrlProvider(CurrentUserContext context) => _context = context;
    public string? GetWebAppBaseUrl() => _context.BaseUrl;
}
