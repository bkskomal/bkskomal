using OATIConnect.API;
using OATIConnect.API.Common;
using OATIConnect.API.Domain.Entities;
using System.Security.Claims;

namespace OATIConnect.Client;

public class OATIConnectExternalAPI : IOATIConnectExternalAPI
{
    private readonly CurrentUserContext _currentUser;
    
    private readonly IOATIConnectRepository _repo;

    public OATIConnectExternalAPI(CurrentUserContext currentUser, IOATIConnectRepository repo)
    {
        _currentUser = currentUser;
        _repo        = repo;
    }


    public Task<ExternalUserInfo?> GetCurrentUserAsync()
    {
        var user = _currentUser.User;
        if (user == null || !(user.Identity?.IsAuthenticated ?? false))
            return Task.FromResult<ExternalUserInfo?>(null);

        var idClaim = user.FindFirst("user-id")?.Value;
        if (!int.TryParse(idClaim, out var userId) || userId <= 0)
            return Task.FromResult<ExternalUserInfo?>(null);

        var name  = user.FindFirst("user-name")?.Value
                  ?? user.Identity?.Name
                  ?? $"User {userId}";
        var email = user.FindFirst(ClaimTypes.Email)?.Value
                  ?? $"user{userId}@local";
        var role  = user.FindFirst(ClaimTypes.Role)?.Value ?? "Standard";

        // Default test zone: Central Standard Time. Switchable per session
        // via the user-tz claim from the login form, so you can validate
        // CDT / CST / IST / GMT renderings end-to-end without rebuilding.
        var rawTz = user.FindFirst("user-tz")?.Value ?? "Central Standard Time";
        var iana  = TimeZoneMapper.ToIana(rawTz);

        return Task.FromResult<ExternalUserInfo?>(new ExternalUserInfo(
            Id:             userId,
            Name:           name,
            Email:          email,
            Role:           role,
            IsActive:       true,
            TimeZoneWindows: rawTz,
            TimeZoneIana:    iana));
    }

    // ===================================================================
    //  Persistence — pure delegation to the repository. Keeping this layer
    //  forwarding-only mirrors the production pattern: the host's
    //  controllers / services should never go through the facade for data
    //  access either; everything flows through the repository.
    // ===================================================================

    public Task<Meeting?> GetMeetingByIdAsync(Guid meetingId, CancellationToken ct = default)
        => _repo.GetMeetingByIdAsync(meetingId, ct);

    public Task<Meeting?> GetActiveMeetingByRoomNameAsync(string roomName, CancellationToken ct = default)
        => _repo.GetActiveMeetingByRoomNameAsync(roomName, ct);

    public Task<Meeting?> GetMeetingByMeetingCodeAsync(string meetingCode, CancellationToken ct = default)
        => _repo.GetMeetingByMeetingCodeAsync(meetingCode, ct);

    public Task<IReadOnlyList<Meeting>> GetVisibleMeetingsAsync(int userId, string? email, CancellationToken ct = default)
        => _repo.GetVisibleMeetingsAsync(userId, email, ct);

    public Task AddMeetingAsync(Meeting meeting, CancellationToken ct = default)
        => _repo.AddMeetingAsync(meeting, ct);

    public Task UpdateMeetingAsync(Meeting meeting, CancellationToken ct = default)
        => _repo.UpdateMeetingAsync(meeting, ct);

    public Task DeleteMeetingAsync(Guid meetingId, CancellationToken ct = default)
        => _repo.DeleteMeetingAsync(meetingId, ct);

    public Task<IReadOnlyList<MeetingInvitee>> GetInviteesAsync(Guid meetingId, CancellationToken ct = default)
        => _repo.GetInviteesAsync(meetingId, ct);

    public Task ReplaceInviteesAsync(Guid meetingId, IEnumerable<MeetingInvitee> invitees, CancellationToken ct = default)
        => _repo.ReplaceInviteesAsync(meetingId, invitees, ct);

    public Task<IReadOnlyList<MeetingParticipant>> GetParticipantsAsync(Guid meetingId, CancellationToken ct = default)
        => _repo.GetParticipantsAsync(meetingId, ct);

    public Task AddParticipantAsync(MeetingParticipant participant, CancellationToken ct = default)
        => _repo.AddParticipantAsync(participant, ct);

    public Task<IReadOnlyList<AppConfig>> GetAllAppConfigsAsync(CancellationToken ct = default)
        => _repo.GetAllAppConfigsAsync(ct);

    public Task<AppConfig?> GetAppConfigByKeyAsync(string key, CancellationToken ct = default)
        => _repo.GetAppConfigByKeyAsync(key, ct);

    public Task<AppConfig> UpsertAppConfigAsync(AppConfig config, CancellationToken ct = default)
        => _repo.UpsertAppConfigAsync(config, ct);

    public Task<IReadOnlyList<MeetingOccurrenceException>> GetOccurrenceExceptionsAsync(Guid meetingId, CancellationToken ct = default)
        => _repo.GetOccurrenceExceptionsAsync(meetingId, ct);

    public Task AddOccurrenceExceptionAsync(MeetingOccurrenceException exception, CancellationToken ct = default)
        => _repo.AddOccurrenceExceptionAsync(exception, ct);

    public Task DeleteOccurrenceExceptionsAsync(Guid meetingId, CancellationToken ct = default)
        => _repo.DeleteOccurrenceExceptionsAsync(meetingId, ct);
}
