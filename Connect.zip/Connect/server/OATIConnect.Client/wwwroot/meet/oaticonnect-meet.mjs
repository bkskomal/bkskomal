function Qx(o, i) {
  for (var n = 0; n < i.length; n++) {
    const a = i[n];
    if (typeof a != "string" && !Array.isArray(a)) {
      for (const l in a)
        if (l !== "default" && !(l in o)) {
          const c = Object.getOwnPropertyDescriptor(a, l);
          c && Object.defineProperty(o, l, c.get ? c : {
            enumerable: !0,
            get: () => a[l]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(o, Symbol.toStringTag, { value: "Module" }));
}
function pf(o) {
  return o && o.__esModule && Object.prototype.hasOwnProperty.call(o, "default") ? o.default : o;
}
var Ed = { exports: {} }, Oo = {};
var Og;
function Px() {
  if (Og) return Oo;
  Og = 1;
  var o = /* @__PURE__ */ Symbol.for("react.transitional.element"), i = /* @__PURE__ */ Symbol.for("react.fragment");
  function n(a, l, c) {
    var d = null;
    if (c !== void 0 && (d = "" + c), l.key !== void 0 && (d = "" + l.key), "key" in l) {
      c = {};
      for (var p in l)
        p !== "key" && (c[p] = l[p]);
    } else c = l;
    return l = c.ref, {
      $$typeof: o,
      type: a,
      key: d,
      ref: l !== void 0 ? l : null,
      props: c
    };
  }
  return Oo.Fragment = i, Oo.jsx = n, Oo.jsxs = n, Oo;
}
var jg;
function Fx() {
  return jg || (jg = 1, Ed.exports = Px()), Ed.exports;
}
var h = Fx(), Md = { exports: {} }, _e = {};
var Ag;
function Vx() {
  if (Ag) return _e;
  Ag = 1;
  var o = /* @__PURE__ */ Symbol.for("react.transitional.element"), i = /* @__PURE__ */ Symbol.for("react.portal"), n = /* @__PURE__ */ Symbol.for("react.fragment"), a = /* @__PURE__ */ Symbol.for("react.strict_mode"), l = /* @__PURE__ */ Symbol.for("react.profiler"), c = /* @__PURE__ */ Symbol.for("react.consumer"), d = /* @__PURE__ */ Symbol.for("react.context"), p = /* @__PURE__ */ Symbol.for("react.forward_ref"), m = /* @__PURE__ */ Symbol.for("react.suspense"), g = /* @__PURE__ */ Symbol.for("react.memo"), y = /* @__PURE__ */ Symbol.for("react.lazy"), b = /* @__PURE__ */ Symbol.for("react.activity"), _ = Symbol.iterator;
  function k(M) {
    return M === null || typeof M != "object" ? null : (M = _ && M[_] || M["@@iterator"], typeof M == "function" ? M : null);
  }
  var w = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, D = Object.assign, S = {};
  function O(M, T, K) {
    this.props = M, this.context = T, this.refs = S, this.updater = K || w;
  }
  O.prototype.isReactComponent = {}, O.prototype.setState = function(M, T) {
    if (typeof M != "object" && typeof M != "function" && M != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, M, T, "setState");
  }, O.prototype.forceUpdate = function(M) {
    this.updater.enqueueForceUpdate(this, M, "forceUpdate");
  };
  function q() {
  }
  q.prototype = O.prototype;
  function L(M, T, K) {
    this.props = M, this.context = T, this.refs = S, this.updater = K || w;
  }
  var P = L.prototype = new q();
  P.constructor = L, D(P, O.prototype), P.isPureReactComponent = !0;
  var F = Array.isArray;
  function J() {
  }
  var Z = { H: null, A: null, T: null, S: null }, ie = Object.prototype.hasOwnProperty;
  function ue(M, T, K) {
    var I = K.ref;
    return {
      $$typeof: o,
      type: M,
      key: T,
      ref: I !== void 0 ? I : null,
      props: K
    };
  }
  function de(M, T) {
    return ue(M.type, T, M.props);
  }
  function ne(M) {
    return typeof M == "object" && M !== null && M.$$typeof === o;
  }
  function $(M) {
    var T = { "=": "=0", ":": "=2" };
    return "$" + M.replace(/[=:]/g, function(K) {
      return T[K];
    });
  }
  var ae = /\/+/g;
  function le(M, T) {
    return typeof M == "object" && M !== null && M.key != null ? $("" + M.key) : T.toString(36);
  }
  function fe(M) {
    switch (M.status) {
      case "fulfilled":
        return M.value;
      case "rejected":
        throw M.reason;
      default:
        switch (typeof M.status == "string" ? M.then(J, J) : (M.status = "pending", M.then(
          function(T) {
            M.status === "pending" && (M.status = "fulfilled", M.value = T);
          },
          function(T) {
            M.status === "pending" && (M.status = "rejected", M.reason = T);
          }
        )), M.status) {
          case "fulfilled":
            return M.value;
          case "rejected":
            throw M.reason;
        }
    }
    throw M;
  }
  function j(M, T, K, I, oe) {
    var pe = typeof M;
    (pe === "undefined" || pe === "boolean") && (M = null);
    var ke = !1;
    if (M === null) ke = !0;
    else
      switch (pe) {
        case "bigint":
        case "string":
        case "number":
          ke = !0;
          break;
        case "object":
          switch (M.$$typeof) {
            case o:
            case i:
              ke = !0;
              break;
            case y:
              return ke = M._init, j(
                ke(M._payload),
                T,
                K,
                I,
                oe
              );
          }
      }
    if (ke)
      return oe = oe(M), ke = I === "" ? "." + le(M, 0) : I, F(oe) ? (K = "", ke != null && (K = ke.replace(ae, "$&/") + "/"), j(oe, T, K, "", function(ee) {
        return ee;
      })) : oe != null && (ne(oe) && (oe = de(
        oe,
        K + (oe.key == null || M && M.key === oe.key ? "" : ("" + oe.key).replace(
          ae,
          "$&/"
        ) + "/") + ke
      )), T.push(oe)), 1;
    ke = 0;
    var Ke = I === "" ? "." : I + ":";
    if (F(M))
      for (var ze = 0; ze < M.length; ze++)
        I = M[ze], pe = Ke + le(I, ze), ke += j(
          I,
          T,
          K,
          pe,
          oe
        );
    else if (ze = k(M), typeof ze == "function")
      for (M = ze.call(M), ze = 0; !(I = M.next()).done; )
        I = I.value, pe = Ke + le(I, ze++), ke += j(
          I,
          T,
          K,
          pe,
          oe
        );
    else if (pe === "object") {
      if (typeof M.then == "function")
        return j(
          fe(M),
          T,
          K,
          I,
          oe
        );
      throw T = String(M), Error(
        "Objects are not valid as a React child (found: " + (T === "[object Object]" ? "object with keys {" + Object.keys(M).join(", ") + "}" : T) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return ke;
  }
  function Q(M, T, K) {
    if (M == null) return M;
    var I = [], oe = 0;
    return j(M, I, "", "", function(pe) {
      return T.call(K, pe, oe++);
    }), I;
  }
  function W(M) {
    if (M._status === -1) {
      var T = M._result;
      T = T(), T.then(
        function(K) {
          (M._status === 0 || M._status === -1) && (M._status = 1, M._result = K);
        },
        function(K) {
          (M._status === 0 || M._status === -1) && (M._status = 2, M._result = K);
        }
      ), M._status === -1 && (M._status = 0, M._result = T);
    }
    if (M._status === 1) return M._result.default;
    throw M._result;
  }
  var se = typeof reportError == "function" ? reportError : function(M) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var T = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof M == "object" && M !== null && typeof M.message == "string" ? String(M.message) : String(M),
        error: M
      });
      if (!window.dispatchEvent(T)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", M);
      return;
    }
    console.error(M);
  }, we = {
    map: Q,
    forEach: function(M, T, K) {
      Q(
        M,
        function() {
          T.apply(this, arguments);
        },
        K
      );
    },
    count: function(M) {
      var T = 0;
      return Q(M, function() {
        T++;
      }), T;
    },
    toArray: function(M) {
      return Q(M, function(T) {
        return T;
      }) || [];
    },
    only: function(M) {
      if (!ne(M))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return M;
    }
  };
  return _e.Activity = b, _e.Children = we, _e.Component = O, _e.Fragment = n, _e.Profiler = l, _e.PureComponent = L, _e.StrictMode = a, _e.Suspense = m, _e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = Z, _e.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(M) {
      return Z.H.useMemoCache(M);
    }
  }, _e.cache = function(M) {
    return function() {
      return M.apply(null, arguments);
    };
  }, _e.cacheSignal = function() {
    return null;
  }, _e.cloneElement = function(M, T, K) {
    if (M == null)
      throw Error(
        "The argument must be a React element, but you passed " + M + "."
      );
    var I = D({}, M.props), oe = M.key;
    if (T != null)
      for (pe in T.key !== void 0 && (oe = "" + T.key), T)
        !ie.call(T, pe) || pe === "key" || pe === "__self" || pe === "__source" || pe === "ref" && T.ref === void 0 || (I[pe] = T[pe]);
    var pe = arguments.length - 2;
    if (pe === 1) I.children = K;
    else if (1 < pe) {
      for (var ke = Array(pe), Ke = 0; Ke < pe; Ke++)
        ke[Ke] = arguments[Ke + 2];
      I.children = ke;
    }
    return ue(M.type, oe, I);
  }, _e.createContext = function(M) {
    return M = {
      $$typeof: d,
      _currentValue: M,
      _currentValue2: M,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, M.Provider = M, M.Consumer = {
      $$typeof: c,
      _context: M
    }, M;
  }, _e.createElement = function(M, T, K) {
    var I, oe = {}, pe = null;
    if (T != null)
      for (I in T.key !== void 0 && (pe = "" + T.key), T)
        ie.call(T, I) && I !== "key" && I !== "__self" && I !== "__source" && (oe[I] = T[I]);
    var ke = arguments.length - 2;
    if (ke === 1) oe.children = K;
    else if (1 < ke) {
      for (var Ke = Array(ke), ze = 0; ze < ke; ze++)
        Ke[ze] = arguments[ze + 2];
      oe.children = Ke;
    }
    if (M && M.defaultProps)
      for (I in ke = M.defaultProps, ke)
        oe[I] === void 0 && (oe[I] = ke[I]);
    return ue(M, pe, oe);
  }, _e.createRef = function() {
    return { current: null };
  }, _e.forwardRef = function(M) {
    return { $$typeof: p, render: M };
  }, _e.isValidElement = ne, _e.lazy = function(M) {
    return {
      $$typeof: y,
      _payload: { _status: -1, _result: M },
      _init: W
    };
  }, _e.memo = function(M, T) {
    return {
      $$typeof: g,
      type: M,
      compare: T === void 0 ? null : T
    };
  }, _e.startTransition = function(M) {
    var T = Z.T, K = {};
    Z.T = K;
    try {
      var I = M(), oe = Z.S;
      oe !== null && oe(K, I), typeof I == "object" && I !== null && typeof I.then == "function" && I.then(J, se);
    } catch (pe) {
      se(pe);
    } finally {
      T !== null && K.types !== null && (T.types = K.types), Z.T = T;
    }
  }, _e.unstable_useCacheRefresh = function() {
    return Z.H.useCacheRefresh();
  }, _e.use = function(M) {
    return Z.H.use(M);
  }, _e.useActionState = function(M, T, K) {
    return Z.H.useActionState(M, T, K);
  }, _e.useCallback = function(M, T) {
    return Z.H.useCallback(M, T);
  }, _e.useContext = function(M) {
    return Z.H.useContext(M);
  }, _e.useDebugValue = function() {
  }, _e.useDeferredValue = function(M, T) {
    return Z.H.useDeferredValue(M, T);
  }, _e.useEffect = function(M, T) {
    return Z.H.useEffect(M, T);
  }, _e.useEffectEvent = function(M) {
    return Z.H.useEffectEvent(M);
  }, _e.useId = function() {
    return Z.H.useId();
  }, _e.useImperativeHandle = function(M, T, K) {
    return Z.H.useImperativeHandle(M, T, K);
  }, _e.useInsertionEffect = function(M, T) {
    return Z.H.useInsertionEffect(M, T);
  }, _e.useLayoutEffect = function(M, T) {
    return Z.H.useLayoutEffect(M, T);
  }, _e.useMemo = function(M, T) {
    return Z.H.useMemo(M, T);
  }, _e.useOptimistic = function(M, T) {
    return Z.H.useOptimistic(M, T);
  }, _e.useReducer = function(M, T, K) {
    return Z.H.useReducer(M, T, K);
  }, _e.useRef = function(M) {
    return Z.H.useRef(M);
  }, _e.useState = function(M) {
    return Z.H.useState(M);
  }, _e.useSyncExternalStore = function(M, T, K) {
    return Z.H.useSyncExternalStore(
      M,
      T,
      K
    );
  }, _e.useTransition = function() {
    return Z.H.useTransition();
  }, _e.version = "19.2.4", _e;
}
var Rg;
function hf() {
  return Rg || (Rg = 1, Md.exports = Vx()), Md.exports;
}
var N = hf();
const B = /* @__PURE__ */ pf(N), ob = /* @__PURE__ */ Qx({
  __proto__: null,
  default: B
}, [N]);
var Td = { exports: {} }, jo = {}, Cd = { exports: {} }, Nd = {};
var zg;
function Gx() {
  return zg || (zg = 1, (function(o) {
    function i(j, Q) {
      var W = j.length;
      j.push(Q);
      e: for (; 0 < W; ) {
        var se = W - 1 >>> 1, we = j[se];
        if (0 < l(we, Q))
          j[se] = Q, j[W] = we, W = se;
        else break e;
      }
    }
    function n(j) {
      return j.length === 0 ? null : j[0];
    }
    function a(j) {
      if (j.length === 0) return null;
      var Q = j[0], W = j.pop();
      if (W !== Q) {
        j[0] = W;
        e: for (var se = 0, we = j.length, M = we >>> 1; se < M; ) {
          var T = 2 * (se + 1) - 1, K = j[T], I = T + 1, oe = j[I];
          if (0 > l(K, W))
            I < we && 0 > l(oe, K) ? (j[se] = oe, j[I] = W, se = I) : (j[se] = K, j[T] = W, se = T);
          else if (I < we && 0 > l(oe, W))
            j[se] = oe, j[I] = W, se = I;
          else break e;
        }
      }
      return Q;
    }
    function l(j, Q) {
      var W = j.sortIndex - Q.sortIndex;
      return W !== 0 ? W : j.id - Q.id;
    }
    if (o.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
      var c = performance;
      o.unstable_now = function() {
        return c.now();
      };
    } else {
      var d = Date, p = d.now();
      o.unstable_now = function() {
        return d.now() - p;
      };
    }
    var m = [], g = [], y = 1, b = null, _ = 3, k = !1, w = !1, D = !1, S = !1, O = typeof setTimeout == "function" ? setTimeout : null, q = typeof clearTimeout == "function" ? clearTimeout : null, L = typeof setImmediate < "u" ? setImmediate : null;
    function P(j) {
      for (var Q = n(g); Q !== null; ) {
        if (Q.callback === null) a(g);
        else if (Q.startTime <= j)
          a(g), Q.sortIndex = Q.expirationTime, i(m, Q);
        else break;
        Q = n(g);
      }
    }
    function F(j) {
      if (D = !1, P(j), !w)
        if (n(m) !== null)
          w = !0, J || (J = !0, $());
        else {
          var Q = n(g);
          Q !== null && fe(F, Q.startTime - j);
        }
    }
    var J = !1, Z = -1, ie = 5, ue = -1;
    function de() {
      return S ? !0 : !(o.unstable_now() - ue < ie);
    }
    function ne() {
      if (S = !1, J) {
        var j = o.unstable_now();
        ue = j;
        var Q = !0;
        try {
          e: {
            w = !1, D && (D = !1, q(Z), Z = -1), k = !0;
            var W = _;
            try {
              t: {
                for (P(j), b = n(m); b !== null && !(b.expirationTime > j && de()); ) {
                  var se = b.callback;
                  if (typeof se == "function") {
                    b.callback = null, _ = b.priorityLevel;
                    var we = se(
                      b.expirationTime <= j
                    );
                    if (j = o.unstable_now(), typeof we == "function") {
                      b.callback = we, P(j), Q = !0;
                      break t;
                    }
                    b === n(m) && a(m), P(j);
                  } else a(m);
                  b = n(m);
                }
                if (b !== null) Q = !0;
                else {
                  var M = n(g);
                  M !== null && fe(
                    F,
                    M.startTime - j
                  ), Q = !1;
                }
              }
              break e;
            } finally {
              b = null, _ = W, k = !1;
            }
            Q = void 0;
          }
        } finally {
          Q ? $() : J = !1;
        }
      }
    }
    var $;
    if (typeof L == "function")
      $ = function() {
        L(ne);
      };
    else if (typeof MessageChannel < "u") {
      var ae = new MessageChannel(), le = ae.port2;
      ae.port1.onmessage = ne, $ = function() {
        le.postMessage(null);
      };
    } else
      $ = function() {
        O(ne, 0);
      };
    function fe(j, Q) {
      Z = O(function() {
        j(o.unstable_now());
      }, Q);
    }
    o.unstable_IdlePriority = 5, o.unstable_ImmediatePriority = 1, o.unstable_LowPriority = 4, o.unstable_NormalPriority = 3, o.unstable_Profiling = null, o.unstable_UserBlockingPriority = 2, o.unstable_cancelCallback = function(j) {
      j.callback = null;
    }, o.unstable_forceFrameRate = function(j) {
      0 > j || 125 < j ? console.error(
        "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
      ) : ie = 0 < j ? Math.floor(1e3 / j) : 5;
    }, o.unstable_getCurrentPriorityLevel = function() {
      return _;
    }, o.unstable_next = function(j) {
      switch (_) {
        case 1:
        case 2:
        case 3:
          var Q = 3;
          break;
        default:
          Q = _;
      }
      var W = _;
      _ = Q;
      try {
        return j();
      } finally {
        _ = W;
      }
    }, o.unstable_requestPaint = function() {
      S = !0;
    }, o.unstable_runWithPriority = function(j, Q) {
      switch (j) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          j = 3;
      }
      var W = _;
      _ = j;
      try {
        return Q();
      } finally {
        _ = W;
      }
    }, o.unstable_scheduleCallback = function(j, Q, W) {
      var se = o.unstable_now();
      switch (typeof W == "object" && W !== null ? (W = W.delay, W = typeof W == "number" && 0 < W ? se + W : se) : W = se, j) {
        case 1:
          var we = -1;
          break;
        case 2:
          we = 250;
          break;
        case 5:
          we = 1073741823;
          break;
        case 4:
          we = 1e4;
          break;
        default:
          we = 5e3;
      }
      return we = W + we, j = {
        id: y++,
        callback: Q,
        priorityLevel: j,
        startTime: W,
        expirationTime: we,
        sortIndex: -1
      }, W > se ? (j.sortIndex = W, i(g, j), n(m) === null && j === n(g) && (D ? (q(Z), Z = -1) : D = !0, fe(F, W - se))) : (j.sortIndex = we, i(m, j), w || k || (w = !0, J || (J = !0, $()))), j;
    }, o.unstable_shouldYield = de, o.unstable_wrapCallback = function(j) {
      var Q = _;
      return function() {
        var W = _;
        _ = Q;
        try {
          return j.apply(this, arguments);
        } finally {
          _ = W;
        }
      };
    };
  })(Nd)), Nd;
}
var Lg;
function Xx() {
  return Lg || (Lg = 1, Cd.exports = Gx()), Cd.exports;
}
var Od = { exports: {} }, Mt = {};
var Yg;
function Zx() {
  if (Yg) return Mt;
  Yg = 1;
  var o = hf();
  function i(m) {
    var g = "https://react.dev/errors/" + m;
    if (1 < arguments.length) {
      g += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var y = 2; y < arguments.length; y++)
        g += "&args[]=" + encodeURIComponent(arguments[y]);
    }
    return "Minified React error #" + m + "; visit " + g + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function n() {
  }
  var a = {
    d: {
      f: n,
      r: function() {
        throw Error(i(522));
      },
      D: n,
      C: n,
      L: n,
      m: n,
      X: n,
      S: n,
      M: n
    },
    p: 0,
    findDOMNode: null
  }, l = /* @__PURE__ */ Symbol.for("react.portal");
  function c(m, g, y) {
    var b = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: l,
      key: b == null ? null : "" + b,
      children: m,
      containerInfo: g,
      implementation: y
    };
  }
  var d = o.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function p(m, g) {
    if (m === "font") return "";
    if (typeof g == "string")
      return g === "use-credentials" ? g : "";
  }
  return Mt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = a, Mt.createPortal = function(m, g) {
    var y = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!g || g.nodeType !== 1 && g.nodeType !== 9 && g.nodeType !== 11)
      throw Error(i(299));
    return c(m, g, null, y);
  }, Mt.flushSync = function(m) {
    var g = d.T, y = a.p;
    try {
      if (d.T = null, a.p = 2, m) return m();
    } finally {
      d.T = g, a.p = y, a.d.f();
    }
  }, Mt.preconnect = function(m, g) {
    typeof m == "string" && (g ? (g = g.crossOrigin, g = typeof g == "string" ? g === "use-credentials" ? g : "" : void 0) : g = null, a.d.C(m, g));
  }, Mt.prefetchDNS = function(m) {
    typeof m == "string" && a.d.D(m);
  }, Mt.preinit = function(m, g) {
    if (typeof m == "string" && g && typeof g.as == "string") {
      var y = g.as, b = p(y, g.crossOrigin), _ = typeof g.integrity == "string" ? g.integrity : void 0, k = typeof g.fetchPriority == "string" ? g.fetchPriority : void 0;
      y === "style" ? a.d.S(
        m,
        typeof g.precedence == "string" ? g.precedence : void 0,
        {
          crossOrigin: b,
          integrity: _,
          fetchPriority: k
        }
      ) : y === "script" && a.d.X(m, {
        crossOrigin: b,
        integrity: _,
        fetchPriority: k,
        nonce: typeof g.nonce == "string" ? g.nonce : void 0
      });
    }
  }, Mt.preinitModule = function(m, g) {
    if (typeof m == "string")
      if (typeof g == "object" && g !== null) {
        if (g.as == null || g.as === "script") {
          var y = p(
            g.as,
            g.crossOrigin
          );
          a.d.M(m, {
            crossOrigin: y,
            integrity: typeof g.integrity == "string" ? g.integrity : void 0,
            nonce: typeof g.nonce == "string" ? g.nonce : void 0
          });
        }
      } else g == null && a.d.M(m);
  }, Mt.preload = function(m, g) {
    if (typeof m == "string" && typeof g == "object" && g !== null && typeof g.as == "string") {
      var y = g.as, b = p(y, g.crossOrigin);
      a.d.L(m, y, {
        crossOrigin: b,
        integrity: typeof g.integrity == "string" ? g.integrity : void 0,
        nonce: typeof g.nonce == "string" ? g.nonce : void 0,
        type: typeof g.type == "string" ? g.type : void 0,
        fetchPriority: typeof g.fetchPriority == "string" ? g.fetchPriority : void 0,
        referrerPolicy: typeof g.referrerPolicy == "string" ? g.referrerPolicy : void 0,
        imageSrcSet: typeof g.imageSrcSet == "string" ? g.imageSrcSet : void 0,
        imageSizes: typeof g.imageSizes == "string" ? g.imageSizes : void 0,
        media: typeof g.media == "string" ? g.media : void 0
      });
    }
  }, Mt.preloadModule = function(m, g) {
    if (typeof m == "string")
      if (g) {
        var y = p(g.as, g.crossOrigin);
        a.d.m(m, {
          as: typeof g.as == "string" && g.as !== "script" ? g.as : void 0,
          crossOrigin: y,
          integrity: typeof g.integrity == "string" ? g.integrity : void 0
        });
      } else a.d.m(m);
  }, Mt.requestFormReset = function(m) {
    a.d.r(m);
  }, Mt.unstable_batchedUpdates = function(m, g) {
    return m(g);
  }, Mt.useFormState = function(m, g, y) {
    return d.H.useFormState(m, g, y);
  }, Mt.useFormStatus = function() {
    return d.H.useHostTransitionStatus();
  }, Mt.version = "19.2.4", Mt;
}
var Hg;
function lb() {
  if (Hg) return Od.exports;
  Hg = 1;
  function o() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o);
      } catch (i) {
        console.error(i);
      }
  }
  return o(), Od.exports = Zx(), Od.exports;
}
var Ug;
function Kx() {
  if (Ug) return jo;
  Ug = 1;
  var o = Xx(), i = hf(), n = lb();
  function a(e) {
    var t = "https://react.dev/errors/" + e;
    if (1 < arguments.length) {
      t += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var r = 2; r < arguments.length; r++)
        t += "&args[]=" + encodeURIComponent(arguments[r]);
    }
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function l(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
  }
  function c(e) {
    var t = e, r = e;
    if (e.alternate) for (; t.return; ) t = t.return;
    else {
      e = t;
      do
        t = e, (t.flags & 4098) !== 0 && (r = t.return), e = t.return;
      while (e);
    }
    return t.tag === 3 ? r : null;
  }
  function d(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function p(e) {
    if (e.tag === 31) {
      var t = e.memoizedState;
      if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function m(e) {
    if (c(e) !== e)
      throw Error(a(188));
  }
  function g(e) {
    var t = e.alternate;
    if (!t) {
      if (t = c(e), t === null) throw Error(a(188));
      return t !== e ? null : e;
    }
    for (var r = e, s = t; ; ) {
      var u = r.return;
      if (u === null) break;
      var f = u.alternate;
      if (f === null) {
        if (s = u.return, s !== null) {
          r = s;
          continue;
        }
        break;
      }
      if (u.child === f.child) {
        for (f = u.child; f; ) {
          if (f === r) return m(u), e;
          if (f === s) return m(u), t;
          f = f.sibling;
        }
        throw Error(a(188));
      }
      if (r.return !== s.return) r = u, s = f;
      else {
        for (var v = !1, x = u.child; x; ) {
          if (x === r) {
            v = !0, r = u, s = f;
            break;
          }
          if (x === s) {
            v = !0, s = u, r = f;
            break;
          }
          x = x.sibling;
        }
        if (!v) {
          for (x = f.child; x; ) {
            if (x === r) {
              v = !0, r = f, s = u;
              break;
            }
            if (x === s) {
              v = !0, s = f, r = u;
              break;
            }
            x = x.sibling;
          }
          if (!v) throw Error(a(189));
        }
      }
      if (r.alternate !== s) throw Error(a(190));
    }
    if (r.tag !== 3) throw Error(a(188));
    return r.stateNode.current === r ? e : t;
  }
  function y(e) {
    var t = e.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return e;
    for (e = e.child; e !== null; ) {
      if (t = y(e), t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var b = Object.assign, _ = /* @__PURE__ */ Symbol.for("react.element"), k = /* @__PURE__ */ Symbol.for("react.transitional.element"), w = /* @__PURE__ */ Symbol.for("react.portal"), D = /* @__PURE__ */ Symbol.for("react.fragment"), S = /* @__PURE__ */ Symbol.for("react.strict_mode"), O = /* @__PURE__ */ Symbol.for("react.profiler"), q = /* @__PURE__ */ Symbol.for("react.consumer"), L = /* @__PURE__ */ Symbol.for("react.context"), P = /* @__PURE__ */ Symbol.for("react.forward_ref"), F = /* @__PURE__ */ Symbol.for("react.suspense"), J = /* @__PURE__ */ Symbol.for("react.suspense_list"), Z = /* @__PURE__ */ Symbol.for("react.memo"), ie = /* @__PURE__ */ Symbol.for("react.lazy"), ue = /* @__PURE__ */ Symbol.for("react.activity"), de = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), ne = Symbol.iterator;
  function $(e) {
    return e === null || typeof e != "object" ? null : (e = ne && e[ne] || e["@@iterator"], typeof e == "function" ? e : null);
  }
  var ae = /* @__PURE__ */ Symbol.for("react.client.reference");
  function le(e) {
    if (e == null) return null;
    if (typeof e == "function")
      return e.$$typeof === ae ? null : e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case D:
        return "Fragment";
      case O:
        return "Profiler";
      case S:
        return "StrictMode";
      case F:
        return "Suspense";
      case J:
        return "SuspenseList";
      case ue:
        return "Activity";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case w:
          return "Portal";
        case L:
          return e.displayName || "Context";
        case q:
          return (e._context.displayName || "Context") + ".Consumer";
        case P:
          var t = e.render;
          return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case Z:
          return t = e.displayName || null, t !== null ? t : le(e.type) || "Memo";
        case ie:
          t = e._payload, e = e._init;
          try {
            return le(e(t));
          } catch {
          }
      }
    return null;
  }
  var fe = Array.isArray, j = i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, Q = n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, W = {
    pending: !1,
    data: null,
    method: null,
    action: null
  }, se = [], we = -1;
  function M(e) {
    return { current: e };
  }
  function T(e) {
    0 > we || (e.current = se[we], se[we] = null, we--);
  }
  function K(e, t) {
    we++, se[we] = e.current, e.current = t;
  }
  var I = M(null), oe = M(null), pe = M(null), ke = M(null);
  function Ke(e, t) {
    switch (K(pe, t), K(oe, e), K(I, null), t.nodeType) {
      case 9:
      case 11:
        e = (e = t.documentElement) && (e = e.namespaceURI) ? eg(e) : 0;
        break;
      default:
        if (e = t.tagName, t = t.namespaceURI)
          t = eg(t), e = tg(t, e);
        else
          switch (e) {
            case "svg":
              e = 1;
              break;
            case "math":
              e = 2;
              break;
            default:
              e = 0;
          }
    }
    T(I), K(I, e);
  }
  function ze() {
    T(I), T(oe), T(pe);
  }
  function ee(e) {
    e.memoizedState !== null && K(ke, e);
    var t = I.current, r = tg(t, e.type);
    t !== r && (K(oe, e), K(I, r));
  }
  function ve(e) {
    oe.current === e && (T(I), T(oe)), ke.current === e && (T(ke), Mo._currentValue = W);
  }
  var Et, be;
  function qe(e) {
    if (Et === void 0)
      try {
        throw Error();
      } catch (r) {
        var t = r.stack.trim().match(/\n( *(at )?)/);
        Et = t && t[1] || "", be = -1 < r.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < r.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
    return `
` + Et + e + be;
  }
  var Ot = !1;
  function lt(e, t) {
    if (!e || Ot) return "";
    Ot = !0;
    var r = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var s = {
        DetermineComponentFrameRoot: function() {
          try {
            if (t) {
              var X = function() {
                throw Error();
              };
              if (Object.defineProperty(X.prototype, "props", {
                set: function() {
                  throw Error();
                }
              }), typeof Reflect == "object" && Reflect.construct) {
                try {
                  Reflect.construct(X, []);
                } catch (U) {
                  var Y = U;
                }
                Reflect.construct(e, [], X);
              } else {
                try {
                  X.call();
                } catch (U) {
                  Y = U;
                }
                e.call(X.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (U) {
                Y = U;
              }
              (X = e()) && typeof X.catch == "function" && X.catch(function() {
              });
            }
          } catch (U) {
            if (U && Y && typeof U.stack == "string")
              return [U.stack, Y.stack];
          }
          return [null, null];
        }
      };
      s.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var u = Object.getOwnPropertyDescriptor(
        s.DetermineComponentFrameRoot,
        "name"
      );
      u && u.configurable && Object.defineProperty(
        s.DetermineComponentFrameRoot,
        "name",
        { value: "DetermineComponentFrameRoot" }
      );
      var f = s.DetermineComponentFrameRoot(), v = f[0], x = f[1];
      if (v && x) {
        var E = v.split(`
`), z = x.split(`
`);
        for (u = s = 0; s < E.length && !E[s].includes("DetermineComponentFrameRoot"); )
          s++;
        for (; u < z.length && !z[u].includes(
          "DetermineComponentFrameRoot"
        ); )
          u++;
        if (s === E.length || u === z.length)
          for (s = E.length - 1, u = z.length - 1; 1 <= s && 0 <= u && E[s] !== z[u]; )
            u--;
        for (; 1 <= s && 0 <= u; s--, u--)
          if (E[s] !== z[u]) {
            if (s !== 1 || u !== 1)
              do
                if (s--, u--, 0 > u || E[s] !== z[u]) {
                  var V = `
` + E[s].replace(" at new ", " at ");
                  return e.displayName && V.includes("<anonymous>") && (V = V.replace("<anonymous>", e.displayName)), V;
                }
              while (1 <= s && 0 <= u);
            break;
          }
      }
    } finally {
      Ot = !1, Error.prepareStackTrace = r;
    }
    return (r = e ? e.displayName || e.name : "") ? qe(r) : "";
  }
  function Xt(e, t) {
    switch (e.tag) {
      case 26:
      case 27:
      case 5:
        return qe(e.type);
      case 16:
        return qe("Lazy");
      case 13:
        return e.child !== t && t !== null ? qe("Suspense Fallback") : qe("Suspense");
      case 19:
        return qe("SuspenseList");
      case 0:
      case 15:
        return lt(e.type, !1);
      case 11:
        return lt(e.type.render, !1);
      case 1:
        return lt(e.type, !0);
      case 31:
        return qe("Activity");
      default:
        return "";
    }
  }
  function Ta(e) {
    try {
      var t = "", r = null;
      do
        t += Xt(e, r), r = e, e = e.return;
      while (e);
      return t;
    } catch (s) {
      return `
Error generating stack: ` + s.message + `
` + s.stack;
    }
  }
  var Ca = Object.prototype.hasOwnProperty, Jn = o.unstable_scheduleCallback, Rr = o.unstable_cancelCallback, Li = o.unstable_shouldYield, zr = o.unstable_requestPaint, et = o.unstable_now, Na = o.unstable_getCurrentPriorityLevel, re = o.unstable_ImmediatePriority, De = o.unstable_UserBlockingPriority, ya = o.unstable_NormalPriority, fc = o.unstable_LowPriority, Yi = o.unstable_IdlePriority, Hi = o.log, pc = o.unstable_setDisableYieldValue, $n = null, Zt = null;
  function yn(e) {
    if (typeof Hi == "function" && pc(e), Zt && typeof Zt.setStrictMode == "function")
      try {
        Zt.setStrictMode($n, e);
      } catch {
      }
  }
  var Kt = Math.clz32 ? Math.clz32 : Ty, Ey = Math.log, My = Math.LN2;
  function Ty(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (Ey(e) / My | 0) | 0;
  }
  var el = 256, tl = 262144, al = 4194304;
  function er(e) {
    var t = e & 42;
    if (t !== 0) return t;
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return e & 261888;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return e & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return e;
    }
  }
  function nl(e, t, r) {
    var s = e.pendingLanes;
    if (s === 0) return 0;
    var u = 0, f = e.suspendedLanes, v = e.pingedLanes;
    e = e.warmLanes;
    var x = s & 134217727;
    return x !== 0 ? (s = x & ~f, s !== 0 ? u = er(s) : (v &= x, v !== 0 ? u = er(v) : r || (r = x & ~e, r !== 0 && (u = er(r))))) : (x = s & ~f, x !== 0 ? u = er(x) : v !== 0 ? u = er(v) : r || (r = s & ~e, r !== 0 && (u = er(r)))), u === 0 ? 0 : t !== 0 && t !== u && (t & f) === 0 && (f = u & -u, r = t & -t, f >= r || f === 32 && (r & 4194048) !== 0) ? t : u;
  }
  function Ui(e, t) {
    return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
  }
  function Cy(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function zf() {
    var e = al;
    return al <<= 1, (al & 62914560) === 0 && (al = 4194304), e;
  }
  function hc(e) {
    for (var t = [], r = 0; 31 > r; r++) t.push(e);
    return t;
  }
  function Bi(e, t) {
    e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0);
  }
  function Ny(e, t, r, s, u, f) {
    var v = e.pendingLanes;
    e.pendingLanes = r, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= r, e.entangledLanes &= r, e.errorRecoveryDisabledLanes &= r, e.shellSuspendCounter = 0;
    var x = e.entanglements, E = e.expirationTimes, z = e.hiddenUpdates;
    for (r = v & ~r; 0 < r; ) {
      var V = 31 - Kt(r), X = 1 << V;
      x[V] = 0, E[V] = -1;
      var Y = z[V];
      if (Y !== null)
        for (z[V] = null, V = 0; V < Y.length; V++) {
          var U = Y[V];
          U !== null && (U.lane &= -536870913);
        }
      r &= ~X;
    }
    s !== 0 && Lf(e, s, 0), f !== 0 && u === 0 && e.tag !== 0 && (e.suspendedLanes |= f & ~(v & ~t));
  }
  function Lf(e, t, r) {
    e.pendingLanes |= t, e.suspendedLanes &= ~t;
    var s = 31 - Kt(t);
    e.entangledLanes |= t, e.entanglements[s] = e.entanglements[s] | 1073741824 | r & 261930;
  }
  function Yf(e, t) {
    var r = e.entangledLanes |= t;
    for (e = e.entanglements; r; ) {
      var s = 31 - Kt(r), u = 1 << s;
      u & t | e[s] & t && (e[s] |= t), r &= ~u;
    }
  }
  function Hf(e, t) {
    var r = t & -t;
    return r = (r & 42) !== 0 ? 1 : mc(r), (r & (e.suspendedLanes | t)) !== 0 ? 0 : r;
  }
  function mc(e) {
    switch (e) {
      case 2:
        e = 1;
        break;
      case 8:
        e = 4;
        break;
      case 32:
        e = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        e = 128;
        break;
      case 268435456:
        e = 134217728;
        break;
      default:
        e = 0;
    }
    return e;
  }
  function gc(e) {
    return e &= -e, 2 < e ? 8 < e ? (e & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
  }
  function Uf() {
    var e = Q.p;
    return e !== 0 ? e : (e = window.event, e === void 0 ? 32 : Sg(e.type));
  }
  function Bf(e, t) {
    var r = Q.p;
    try {
      return Q.p = e, t();
    } finally {
      Q.p = r;
    }
  }
  var xn = Math.random().toString(36).slice(2), xt = "__reactFiber$" + xn, zt = "__reactProps$" + xn, Lr = "__reactContainer$" + xn, vc = "__reactEvents$" + xn, Oy = "__reactListeners$" + xn, jy = "__reactHandles$" + xn, qf = "__reactResources$" + xn, qi = "__reactMarker$" + xn;
  function bc(e) {
    delete e[xt], delete e[zt], delete e[vc], delete e[Oy], delete e[jy];
  }
  function Yr(e) {
    var t = e[xt];
    if (t) return t;
    for (var r = e.parentNode; r; ) {
      if (t = r[Lr] || r[xt]) {
        if (r = t.alternate, t.child !== null || r !== null && r.child !== null)
          for (e = sg(e); e !== null; ) {
            if (r = e[xt]) return r;
            e = sg(e);
          }
        return t;
      }
      e = r, r = e.parentNode;
    }
    return null;
  }
  function Hr(e) {
    if (e = e[xt] || e[Lr]) {
      var t = e.tag;
      if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3)
        return e;
    }
    return null;
  }
  function Qi(e) {
    var t = e.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
    throw Error(a(33));
  }
  function Ur(e) {
    var t = e[qf];
    return t || (t = e[qf] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), t;
  }
  function bt(e) {
    e[qi] = !0;
  }
  var Qf = /* @__PURE__ */ new Set(), Pf = {};
  function tr(e, t) {
    Br(e, t), Br(e + "Capture", t);
  }
  function Br(e, t) {
    for (Pf[e] = t, e = 0; e < t.length; e++)
      Qf.add(t[e]);
  }
  var Ay = RegExp(
    "^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"
  ), Ff = {}, Vf = {};
  function Ry(e) {
    return Ca.call(Vf, e) ? !0 : Ca.call(Ff, e) ? !1 : Ay.test(e) ? Vf[e] = !0 : (Ff[e] = !0, !1);
  }
  function rl(e, t, r) {
    if (Ry(t))
      if (r === null) e.removeAttribute(t);
      else {
        switch (typeof r) {
          case "undefined":
          case "function":
          case "symbol":
            e.removeAttribute(t);
            return;
          case "boolean":
            var s = t.toLowerCase().slice(0, 5);
            if (s !== "data-" && s !== "aria-") {
              e.removeAttribute(t);
              return;
            }
        }
        e.setAttribute(t, "" + r);
      }
  }
  function il(e, t, r) {
    if (r === null) e.removeAttribute(t);
    else {
      switch (typeof r) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          e.removeAttribute(t);
          return;
      }
      e.setAttribute(t, "" + r);
    }
  }
  function Va(e, t, r, s) {
    if (s === null) e.removeAttribute(r);
    else {
      switch (typeof s) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          e.removeAttribute(r);
          return;
      }
      e.setAttributeNS(t, r, "" + s);
    }
  }
  function ia(e) {
    switch (typeof e) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function Gf(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
  }
  function zy(e, t, r) {
    var s = Object.getOwnPropertyDescriptor(
      e.constructor.prototype,
      t
    );
    if (!e.hasOwnProperty(t) && typeof s < "u" && typeof s.get == "function" && typeof s.set == "function") {
      var u = s.get, f = s.set;
      return Object.defineProperty(e, t, {
        configurable: !0,
        get: function() {
          return u.call(this);
        },
        set: function(v) {
          r = "" + v, f.call(this, v);
        }
      }), Object.defineProperty(e, t, {
        enumerable: s.enumerable
      }), {
        getValue: function() {
          return r;
        },
        setValue: function(v) {
          r = "" + v;
        },
        stopTracking: function() {
          e._valueTracker = null, delete e[t];
        }
      };
    }
  }
  function yc(e) {
    if (!e._valueTracker) {
      var t = Gf(e) ? "checked" : "value";
      e._valueTracker = zy(
        e,
        t,
        "" + e[t]
      );
    }
  }
  function Xf(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var r = t.getValue(), s = "";
    return e && (s = Gf(e) ? e.checked ? "true" : "false" : e.value), e = s, e !== r ? (t.setValue(e), !0) : !1;
  }
  function ol(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  var Ly = /[\n"\\]/g;
  function oa(e) {
    return e.replace(
      Ly,
      function(t) {
        return "\\" + t.charCodeAt(0).toString(16) + " ";
      }
    );
  }
  function xc(e, t, r, s, u, f, v, x) {
    e.name = "", v != null && typeof v != "function" && typeof v != "symbol" && typeof v != "boolean" ? e.type = v : e.removeAttribute("type"), t != null ? v === "number" ? (t === 0 && e.value === "" || e.value != t) && (e.value = "" + ia(t)) : e.value !== "" + ia(t) && (e.value = "" + ia(t)) : v !== "submit" && v !== "reset" || e.removeAttribute("value"), t != null ? wc(e, v, ia(t)) : r != null ? wc(e, v, ia(r)) : s != null && e.removeAttribute("value"), u == null && f != null && (e.defaultChecked = !!f), u != null && (e.checked = u && typeof u != "function" && typeof u != "symbol"), x != null && typeof x != "function" && typeof x != "symbol" && typeof x != "boolean" ? e.name = "" + ia(x) : e.removeAttribute("name");
  }
  function Zf(e, t, r, s, u, f, v, x) {
    if (f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" && (e.type = f), t != null || r != null) {
      if (!(f !== "submit" && f !== "reset" || t != null)) {
        yc(e);
        return;
      }
      r = r != null ? "" + ia(r) : "", t = t != null ? "" + ia(t) : r, x || t === e.value || (e.value = t), e.defaultValue = t;
    }
    s = s ?? u, s = typeof s != "function" && typeof s != "symbol" && !!s, e.checked = x ? e.checked : !!s, e.defaultChecked = !!s, v != null && typeof v != "function" && typeof v != "symbol" && typeof v != "boolean" && (e.name = v), yc(e);
  }
  function wc(e, t, r) {
    t === "number" && ol(e.ownerDocument) === e || e.defaultValue === "" + r || (e.defaultValue = "" + r);
  }
  function qr(e, t, r, s) {
    if (e = e.options, t) {
      t = {};
      for (var u = 0; u < r.length; u++)
        t["$" + r[u]] = !0;
      for (r = 0; r < e.length; r++)
        u = t.hasOwnProperty("$" + e[r].value), e[r].selected !== u && (e[r].selected = u), u && s && (e[r].defaultSelected = !0);
    } else {
      for (r = "" + ia(r), t = null, u = 0; u < e.length; u++) {
        if (e[u].value === r) {
          e[u].selected = !0, s && (e[u].defaultSelected = !0);
          return;
        }
        t !== null || e[u].disabled || (t = e[u]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function Kf(e, t, r) {
    if (t != null && (t = "" + ia(t), t !== e.value && (e.value = t), r == null)) {
      e.defaultValue !== t && (e.defaultValue = t);
      return;
    }
    e.defaultValue = r != null ? "" + ia(r) : "";
  }
  function Wf(e, t, r, s) {
    if (t == null) {
      if (s != null) {
        if (r != null) throw Error(a(92));
        if (fe(s)) {
          if (1 < s.length) throw Error(a(93));
          s = s[0];
        }
        r = s;
      }
      r == null && (r = ""), t = r;
    }
    r = ia(t), e.defaultValue = r, s = e.textContent, s === r && s !== "" && s !== null && (e.value = s), yc(e);
  }
  function Qr(e, t) {
    if (t) {
      var r = e.firstChild;
      if (r && r === e.lastChild && r.nodeType === 3) {
        r.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var Yy = new Set(
    "animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(
      " "
    )
  );
  function If(e, t, r) {
    var s = t.indexOf("--") === 0;
    r == null || typeof r == "boolean" || r === "" ? s ? e.setProperty(t, "") : t === "float" ? e.cssFloat = "" : e[t] = "" : s ? e.setProperty(t, r) : typeof r != "number" || r === 0 || Yy.has(t) ? t === "float" ? e.cssFloat = r : e[t] = ("" + r).trim() : e[t] = r + "px";
  }
  function Jf(e, t, r) {
    if (t != null && typeof t != "object")
      throw Error(a(62));
    if (e = e.style, r != null) {
      for (var s in r)
        !r.hasOwnProperty(s) || t != null && t.hasOwnProperty(s) || (s.indexOf("--") === 0 ? e.setProperty(s, "") : s === "float" ? e.cssFloat = "" : e[s] = "");
      for (var u in t)
        s = t[u], t.hasOwnProperty(u) && r[u] !== s && If(e, u, s);
    } else
      for (var f in t)
        t.hasOwnProperty(f) && If(e, f, t[f]);
  }
  function _c(e) {
    if (e.indexOf("-") === -1) return !1;
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var Hy = /* @__PURE__ */ new Map([
    ["acceptCharset", "accept-charset"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"],
    ["crossOrigin", "crossorigin"],
    ["accentHeight", "accent-height"],
    ["alignmentBaseline", "alignment-baseline"],
    ["arabicForm", "arabic-form"],
    ["baselineShift", "baseline-shift"],
    ["capHeight", "cap-height"],
    ["clipPath", "clip-path"],
    ["clipRule", "clip-rule"],
    ["colorInterpolation", "color-interpolation"],
    ["colorInterpolationFilters", "color-interpolation-filters"],
    ["colorProfile", "color-profile"],
    ["colorRendering", "color-rendering"],
    ["dominantBaseline", "dominant-baseline"],
    ["enableBackground", "enable-background"],
    ["fillOpacity", "fill-opacity"],
    ["fillRule", "fill-rule"],
    ["floodColor", "flood-color"],
    ["floodOpacity", "flood-opacity"],
    ["fontFamily", "font-family"],
    ["fontSize", "font-size"],
    ["fontSizeAdjust", "font-size-adjust"],
    ["fontStretch", "font-stretch"],
    ["fontStyle", "font-style"],
    ["fontVariant", "font-variant"],
    ["fontWeight", "font-weight"],
    ["glyphName", "glyph-name"],
    ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
    ["glyphOrientationVertical", "glyph-orientation-vertical"],
    ["horizAdvX", "horiz-adv-x"],
    ["horizOriginX", "horiz-origin-x"],
    ["imageRendering", "image-rendering"],
    ["letterSpacing", "letter-spacing"],
    ["lightingColor", "lighting-color"],
    ["markerEnd", "marker-end"],
    ["markerMid", "marker-mid"],
    ["markerStart", "marker-start"],
    ["overlinePosition", "overline-position"],
    ["overlineThickness", "overline-thickness"],
    ["paintOrder", "paint-order"],
    ["panose-1", "panose-1"],
    ["pointerEvents", "pointer-events"],
    ["renderingIntent", "rendering-intent"],
    ["shapeRendering", "shape-rendering"],
    ["stopColor", "stop-color"],
    ["stopOpacity", "stop-opacity"],
    ["strikethroughPosition", "strikethrough-position"],
    ["strikethroughThickness", "strikethrough-thickness"],
    ["strokeDasharray", "stroke-dasharray"],
    ["strokeDashoffset", "stroke-dashoffset"],
    ["strokeLinecap", "stroke-linecap"],
    ["strokeLinejoin", "stroke-linejoin"],
    ["strokeMiterlimit", "stroke-miterlimit"],
    ["strokeOpacity", "stroke-opacity"],
    ["strokeWidth", "stroke-width"],
    ["textAnchor", "text-anchor"],
    ["textDecoration", "text-decoration"],
    ["textRendering", "text-rendering"],
    ["transformOrigin", "transform-origin"],
    ["underlinePosition", "underline-position"],
    ["underlineThickness", "underline-thickness"],
    ["unicodeBidi", "unicode-bidi"],
    ["unicodeRange", "unicode-range"],
    ["unitsPerEm", "units-per-em"],
    ["vAlphabetic", "v-alphabetic"],
    ["vHanging", "v-hanging"],
    ["vIdeographic", "v-ideographic"],
    ["vMathematical", "v-mathematical"],
    ["vectorEffect", "vector-effect"],
    ["vertAdvY", "vert-adv-y"],
    ["vertOriginX", "vert-origin-x"],
    ["vertOriginY", "vert-origin-y"],
    ["wordSpacing", "word-spacing"],
    ["writingMode", "writing-mode"],
    ["xmlnsXlink", "xmlns:xlink"],
    ["xHeight", "x-height"]
  ]), Uy = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function ll(e) {
    return Uy.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e;
  }
  function Ga() {
  }
  var kc = null;
  function Sc(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
  }
  var Pr = null, Fr = null;
  function $f(e) {
    var t = Hr(e);
    if (t && (e = t.stateNode)) {
      var r = e[zt] || null;
      e: switch (e = t.stateNode, t.type) {
        case "input":
          if (xc(
            e,
            r.value,
            r.defaultValue,
            r.defaultValue,
            r.checked,
            r.defaultChecked,
            r.type,
            r.name
          ), t = r.name, r.type === "radio" && t != null) {
            for (r = e; r.parentNode; ) r = r.parentNode;
            for (r = r.querySelectorAll(
              'input[name="' + oa(
                "" + t
              ) + '"][type="radio"]'
            ), t = 0; t < r.length; t++) {
              var s = r[t];
              if (s !== e && s.form === e.form) {
                var u = s[zt] || null;
                if (!u) throw Error(a(90));
                xc(
                  s,
                  u.value,
                  u.defaultValue,
                  u.defaultValue,
                  u.checked,
                  u.defaultChecked,
                  u.type,
                  u.name
                );
              }
            }
            for (t = 0; t < r.length; t++)
              s = r[t], s.form === e.form && Xf(s);
          }
          break e;
        case "textarea":
          Kf(e, r.value, r.defaultValue);
          break e;
        case "select":
          t = r.value, t != null && qr(e, !!r.multiple, t, !1);
      }
    }
  }
  var Dc = !1;
  function ep(e, t, r) {
    if (Dc) return e(t, r);
    Dc = !0;
    try {
      var s = e(t);
      return s;
    } finally {
      if (Dc = !1, (Pr !== null || Fr !== null) && (Zl(), Pr && (t = Pr, e = Fr, Fr = Pr = null, $f(t), e)))
        for (t = 0; t < e.length; t++) $f(e[t]);
    }
  }
  function Pi(e, t) {
    var r = e.stateNode;
    if (r === null) return null;
    var s = r[zt] || null;
    if (s === null) return null;
    r = s[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (s = !s.disabled) || (e = e.type, s = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !s;
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (r && typeof r != "function")
      throw Error(
        a(231, t, typeof r)
      );
    return r;
  }
  var Xa = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Ec = !1;
  if (Xa)
    try {
      var Fi = {};
      Object.defineProperty(Fi, "passive", {
        get: function() {
          Ec = !0;
        }
      }), window.addEventListener("test", Fi, Fi), window.removeEventListener("test", Fi, Fi);
    } catch {
      Ec = !1;
    }
  var wn = null, Mc = null, sl = null;
  function tp() {
    if (sl) return sl;
    var e, t = Mc, r = t.length, s, u = "value" in wn ? wn.value : wn.textContent, f = u.length;
    for (e = 0; e < r && t[e] === u[e]; e++) ;
    var v = r - e;
    for (s = 1; s <= v && t[r - s] === u[f - s]; s++) ;
    return sl = u.slice(e, 1 < s ? 1 - s : void 0);
  }
  function cl(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
  }
  function ul() {
    return !0;
  }
  function ap() {
    return !1;
  }
  function Lt(e) {
    function t(r, s, u, f, v) {
      this._reactName = r, this._targetInst = u, this.type = s, this.nativeEvent = f, this.target = v, this.currentTarget = null;
      for (var x in e)
        e.hasOwnProperty(x) && (r = e[x], this[x] = r ? r(f) : f[x]);
      return this.isDefaultPrevented = (f.defaultPrevented != null ? f.defaultPrevented : f.returnValue === !1) ? ul : ap, this.isPropagationStopped = ap, this;
    }
    return b(t.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var r = this.nativeEvent;
        r && (r.preventDefault ? r.preventDefault() : typeof r.returnValue != "unknown" && (r.returnValue = !1), this.isDefaultPrevented = ul);
      },
      stopPropagation: function() {
        var r = this.nativeEvent;
        r && (r.stopPropagation ? r.stopPropagation() : typeof r.cancelBubble != "unknown" && (r.cancelBubble = !0), this.isPropagationStopped = ul);
      },
      persist: function() {
      },
      isPersistent: ul
    }), t;
  }
  var ar = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(e) {
      return e.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, dl = Lt(ar), Vi = b({}, ar, { view: 0, detail: 0 }), By = Lt(Vi), Tc, Cc, Gi, fl = b({}, Vi, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: Oc,
    button: 0,
    buttons: 0,
    relatedTarget: function(e) {
      return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
    },
    movementX: function(e) {
      return "movementX" in e ? e.movementX : (e !== Gi && (Gi && e.type === "mousemove" ? (Tc = e.screenX - Gi.screenX, Cc = e.screenY - Gi.screenY) : Cc = Tc = 0, Gi = e), Tc);
    },
    movementY: function(e) {
      return "movementY" in e ? e.movementY : Cc;
    }
  }), np = Lt(fl), qy = b({}, fl, { dataTransfer: 0 }), Qy = Lt(qy), Py = b({}, Vi, { relatedTarget: 0 }), Nc = Lt(Py), Fy = b({}, ar, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), Vy = Lt(Fy), Gy = b({}, ar, {
    clipboardData: function(e) {
      return "clipboardData" in e ? e.clipboardData : window.clipboardData;
    }
  }), Xy = Lt(Gy), Zy = b({}, ar, { data: 0 }), rp = Lt(Zy), Ky = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, Wy = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, Iy = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function Jy(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = Iy[e]) ? !!t[e] : !1;
  }
  function Oc() {
    return Jy;
  }
  var $y = b({}, Vi, {
    key: function(e) {
      if (e.key) {
        var t = Ky[e.key] || e.key;
        if (t !== "Unidentified") return t;
      }
      return e.type === "keypress" ? (e = cl(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? Wy[e.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: Oc,
    charCode: function(e) {
      return e.type === "keypress" ? cl(e) : 0;
    },
    keyCode: function(e) {
      return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    },
    which: function(e) {
      return e.type === "keypress" ? cl(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    }
  }), e0 = Lt($y), t0 = b({}, fl, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), ip = Lt(t0), a0 = b({}, Vi, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: Oc
  }), n0 = Lt(a0), r0 = b({}, ar, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), i0 = Lt(r0), o0 = b({}, fl, {
    deltaX: function(e) {
      return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
    },
    deltaY: function(e) {
      return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), l0 = Lt(o0), s0 = b({}, ar, {
    newState: 0,
    oldState: 0
  }), c0 = Lt(s0), u0 = [9, 13, 27, 32], jc = Xa && "CompositionEvent" in window, Xi = null;
  Xa && "documentMode" in document && (Xi = document.documentMode);
  var d0 = Xa && "TextEvent" in window && !Xi, op = Xa && (!jc || Xi && 8 < Xi && 11 >= Xi), lp = " ", sp = !1;
  function cp(e, t) {
    switch (e) {
      case "keyup":
        return u0.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function up(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
  }
  var Vr = !1;
  function f0(e, t) {
    switch (e) {
      case "compositionend":
        return up(t);
      case "keypress":
        return t.which !== 32 ? null : (sp = !0, lp);
      case "textInput":
        return e = t.data, e === lp && sp ? null : e;
      default:
        return null;
    }
  }
  function p0(e, t) {
    if (Vr)
      return e === "compositionend" || !jc && cp(e, t) ? (e = tp(), sl = Mc = wn = null, Vr = !1, e) : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
          if (t.char && 1 < t.char.length)
            return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return op && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var h0 = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function dp(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!h0[e.type] : t === "textarea";
  }
  function fp(e, t, r, s) {
    Pr ? Fr ? Fr.push(s) : Fr = [s] : Pr = s, t = ts(t, "onChange"), 0 < t.length && (r = new dl(
      "onChange",
      "change",
      null,
      r,
      s
    ), e.push({ event: r, listeners: t }));
  }
  var Zi = null, Ki = null;
  function m0(e) {
    Zm(e, 0);
  }
  function pl(e) {
    var t = Qi(e);
    if (Xf(t)) return e;
  }
  function pp(e, t) {
    if (e === "change") return t;
  }
  var hp = !1;
  if (Xa) {
    var Ac;
    if (Xa) {
      var Rc = "oninput" in document;
      if (!Rc) {
        var mp = document.createElement("div");
        mp.setAttribute("oninput", "return;"), Rc = typeof mp.oninput == "function";
      }
      Ac = Rc;
    } else Ac = !1;
    hp = Ac && (!document.documentMode || 9 < document.documentMode);
  }
  function gp() {
    Zi && (Zi.detachEvent("onpropertychange", vp), Ki = Zi = null);
  }
  function vp(e) {
    if (e.propertyName === "value" && pl(Ki)) {
      var t = [];
      fp(
        t,
        Ki,
        e,
        Sc(e)
      ), ep(m0, t);
    }
  }
  function g0(e, t, r) {
    e === "focusin" ? (gp(), Zi = t, Ki = r, Zi.attachEvent("onpropertychange", vp)) : e === "focusout" && gp();
  }
  function v0(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return pl(Ki);
  }
  function b0(e, t) {
    if (e === "click") return pl(t);
  }
  function y0(e, t) {
    if (e === "input" || e === "change")
      return pl(t);
  }
  function x0(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
  }
  var Wt = typeof Object.is == "function" ? Object.is : x0;
  function Wi(e, t) {
    if (Wt(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null)
      return !1;
    var r = Object.keys(e), s = Object.keys(t);
    if (r.length !== s.length) return !1;
    for (s = 0; s < r.length; s++) {
      var u = r[s];
      if (!Ca.call(t, u) || !Wt(e[u], t[u]))
        return !1;
    }
    return !0;
  }
  function bp(e) {
    for (; e && e.firstChild; ) e = e.firstChild;
    return e;
  }
  function yp(e, t) {
    var r = bp(e);
    e = 0;
    for (var s; r; ) {
      if (r.nodeType === 3) {
        if (s = e + r.textContent.length, e <= t && s >= t)
          return { node: r, offset: t - e };
        e = s;
      }
      e: {
        for (; r; ) {
          if (r.nextSibling) {
            r = r.nextSibling;
            break e;
          }
          r = r.parentNode;
        }
        r = void 0;
      }
      r = bp(r);
    }
  }
  function xp(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? xp(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1;
  }
  function wp(e) {
    e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
    for (var t = ol(e.document); t instanceof e.HTMLIFrameElement; ) {
      try {
        var r = typeof t.contentWindow.location.href == "string";
      } catch {
        r = !1;
      }
      if (r) e = t.contentWindow;
      else break;
      t = ol(e.document);
    }
    return t;
  }
  function zc(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
  }
  var w0 = Xa && "documentMode" in document && 11 >= document.documentMode, Gr = null, Lc = null, Ii = null, Yc = !1;
  function _p(e, t, r) {
    var s = r.window === r ? r.document : r.nodeType === 9 ? r : r.ownerDocument;
    Yc || Gr == null || Gr !== ol(s) || (s = Gr, "selectionStart" in s && zc(s) ? s = { start: s.selectionStart, end: s.selectionEnd } : (s = (s.ownerDocument && s.ownerDocument.defaultView || window).getSelection(), s = {
      anchorNode: s.anchorNode,
      anchorOffset: s.anchorOffset,
      focusNode: s.focusNode,
      focusOffset: s.focusOffset
    }), Ii && Wi(Ii, s) || (Ii = s, s = ts(Lc, "onSelect"), 0 < s.length && (t = new dl(
      "onSelect",
      "select",
      null,
      t,
      r
    ), e.push({ event: t, listeners: s }), t.target = Gr)));
  }
  function nr(e, t) {
    var r = {};
    return r[e.toLowerCase()] = t.toLowerCase(), r["Webkit" + e] = "webkit" + t, r["Moz" + e] = "moz" + t, r;
  }
  var Xr = {
    animationend: nr("Animation", "AnimationEnd"),
    animationiteration: nr("Animation", "AnimationIteration"),
    animationstart: nr("Animation", "AnimationStart"),
    transitionrun: nr("Transition", "TransitionRun"),
    transitionstart: nr("Transition", "TransitionStart"),
    transitioncancel: nr("Transition", "TransitionCancel"),
    transitionend: nr("Transition", "TransitionEnd")
  }, Hc = {}, kp = {};
  Xa && (kp = document.createElement("div").style, "AnimationEvent" in window || (delete Xr.animationend.animation, delete Xr.animationiteration.animation, delete Xr.animationstart.animation), "TransitionEvent" in window || delete Xr.transitionend.transition);
  function rr(e) {
    if (Hc[e]) return Hc[e];
    if (!Xr[e]) return e;
    var t = Xr[e], r;
    for (r in t)
      if (t.hasOwnProperty(r) && r in kp)
        return Hc[e] = t[r];
    return e;
  }
  var Sp = rr("animationend"), Dp = rr("animationiteration"), Ep = rr("animationstart"), _0 = rr("transitionrun"), k0 = rr("transitionstart"), S0 = rr("transitioncancel"), Mp = rr("transitionend"), Tp = /* @__PURE__ */ new Map(), Uc = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
    " "
  );
  Uc.push("scrollEnd");
  function xa(e, t) {
    Tp.set(e, t), tr(t, [e]);
  }
  var hl = typeof reportError == "function" ? reportError : function(e) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var t = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
        error: e
      });
      if (!window.dispatchEvent(t)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", e);
      return;
    }
    console.error(e);
  }, la = [], Zr = 0, Bc = 0;
  function ml() {
    for (var e = Zr, t = Bc = Zr = 0; t < e; ) {
      var r = la[t];
      la[t++] = null;
      var s = la[t];
      la[t++] = null;
      var u = la[t];
      la[t++] = null;
      var f = la[t];
      if (la[t++] = null, s !== null && u !== null) {
        var v = s.pending;
        v === null ? u.next = u : (u.next = v.next, v.next = u), s.pending = u;
      }
      f !== 0 && Cp(r, u, f);
    }
  }
  function gl(e, t, r, s) {
    la[Zr++] = e, la[Zr++] = t, la[Zr++] = r, la[Zr++] = s, Bc |= s, e.lanes |= s, e = e.alternate, e !== null && (e.lanes |= s);
  }
  function qc(e, t, r, s) {
    return gl(e, t, r, s), vl(e);
  }
  function ir(e, t) {
    return gl(e, null, null, t), vl(e);
  }
  function Cp(e, t, r) {
    e.lanes |= r;
    var s = e.alternate;
    s !== null && (s.lanes |= r);
    for (var u = !1, f = e.return; f !== null; )
      f.childLanes |= r, s = f.alternate, s !== null && (s.childLanes |= r), f.tag === 22 && (e = f.stateNode, e === null || e._visibility & 1 || (u = !0)), e = f, f = f.return;
    return e.tag === 3 ? (f = e.stateNode, u && t !== null && (u = 31 - Kt(r), e = f.hiddenUpdates, s = e[u], s === null ? e[u] = [t] : s.push(t), t.lane = r | 536870912), f) : null;
  }
  function vl(e) {
    if (50 < xo)
      throw xo = 0, Wu = null, Error(a(185));
    for (var t = e.return; t !== null; )
      e = t, t = e.return;
    return e.tag === 3 ? e.stateNode : null;
  }
  var Kr = {};
  function D0(e, t, r, s) {
    this.tag = e, this.key = r, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = s, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function It(e, t, r, s) {
    return new D0(e, t, r, s);
  }
  function Qc(e) {
    return e = e.prototype, !(!e || !e.isReactComponent);
  }
  function Za(e, t) {
    var r = e.alternate;
    return r === null ? (r = It(
      e.tag,
      t,
      e.key,
      e.mode
    ), r.elementType = e.elementType, r.type = e.type, r.stateNode = e.stateNode, r.alternate = e, e.alternate = r) : (r.pendingProps = t, r.type = e.type, r.flags = 0, r.subtreeFlags = 0, r.deletions = null), r.flags = e.flags & 65011712, r.childLanes = e.childLanes, r.lanes = e.lanes, r.child = e.child, r.memoizedProps = e.memoizedProps, r.memoizedState = e.memoizedState, r.updateQueue = e.updateQueue, t = e.dependencies, r.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, r.sibling = e.sibling, r.index = e.index, r.ref = e.ref, r.refCleanup = e.refCleanup, r;
  }
  function Np(e, t) {
    e.flags &= 65011714;
    var r = e.alternate;
    return r === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = r.childLanes, e.lanes = r.lanes, e.child = r.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = r.memoizedProps, e.memoizedState = r.memoizedState, e.updateQueue = r.updateQueue, e.type = r.type, t = r.dependencies, e.dependencies = t === null ? null : {
      lanes: t.lanes,
      firstContext: t.firstContext
    }), e;
  }
  function bl(e, t, r, s, u, f) {
    var v = 0;
    if (s = e, typeof e == "function") Qc(e) && (v = 1);
    else if (typeof e == "string")
      v = Nx(
        e,
        r,
        I.current
      ) ? 26 : e === "html" || e === "head" || e === "body" ? 27 : 5;
    else
      e: switch (e) {
        case ue:
          return e = It(31, r, t, u), e.elementType = ue, e.lanes = f, e;
        case D:
          return or(r.children, u, f, t);
        case S:
          v = 8, u |= 24;
          break;
        case O:
          return e = It(12, r, t, u | 2), e.elementType = O, e.lanes = f, e;
        case F:
          return e = It(13, r, t, u), e.elementType = F, e.lanes = f, e;
        case J:
          return e = It(19, r, t, u), e.elementType = J, e.lanes = f, e;
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case L:
                v = 10;
                break e;
              case q:
                v = 9;
                break e;
              case P:
                v = 11;
                break e;
              case Z:
                v = 14;
                break e;
              case ie:
                v = 16, s = null;
                break e;
            }
          v = 29, r = Error(
            a(130, e === null ? "null" : typeof e, "")
          ), s = null;
      }
    return t = It(v, r, t, u), t.elementType = e, t.type = s, t.lanes = f, t;
  }
  function or(e, t, r, s) {
    return e = It(7, e, s, t), e.lanes = r, e;
  }
  function Pc(e, t, r) {
    return e = It(6, e, null, t), e.lanes = r, e;
  }
  function Op(e) {
    var t = It(18, null, null, 0);
    return t.stateNode = e, t;
  }
  function Fc(e, t, r) {
    return t = It(
      4,
      e.children !== null ? e.children : [],
      e.key,
      t
    ), t.lanes = r, t.stateNode = {
      containerInfo: e.containerInfo,
      pendingChildren: null,
      implementation: e.implementation
    }, t;
  }
  var jp = /* @__PURE__ */ new WeakMap();
  function sa(e, t) {
    if (typeof e == "object" && e !== null) {
      var r = jp.get(e);
      return r !== void 0 ? r : (t = {
        value: e,
        source: t,
        stack: Ta(t)
      }, jp.set(e, t), t);
    }
    return {
      value: e,
      source: t,
      stack: Ta(t)
    };
  }
  var Wr = [], Ir = 0, yl = null, Ji = 0, ca = [], ua = 0, _n = null, Oa = 1, ja = "";
  function Ka(e, t) {
    Wr[Ir++] = Ji, Wr[Ir++] = yl, yl = e, Ji = t;
  }
  function Ap(e, t, r) {
    ca[ua++] = Oa, ca[ua++] = ja, ca[ua++] = _n, _n = e;
    var s = Oa;
    e = ja;
    var u = 32 - Kt(s) - 1;
    s &= ~(1 << u), r += 1;
    var f = 32 - Kt(t) + u;
    if (30 < f) {
      var v = u - u % 5;
      f = (s & (1 << v) - 1).toString(32), s >>= v, u -= v, Oa = 1 << 32 - Kt(t) + u | r << u | s, ja = f + e;
    } else
      Oa = 1 << f | r << u | s, ja = e;
  }
  function Vc(e) {
    e.return !== null && (Ka(e, 1), Ap(e, 1, 0));
  }
  function Gc(e) {
    for (; e === yl; )
      yl = Wr[--Ir], Wr[Ir] = null, Ji = Wr[--Ir], Wr[Ir] = null;
    for (; e === _n; )
      _n = ca[--ua], ca[ua] = null, ja = ca[--ua], ca[ua] = null, Oa = ca[--ua], ca[ua] = null;
  }
  function Rp(e, t) {
    ca[ua++] = Oa, ca[ua++] = ja, ca[ua++] = _n, Oa = t.id, ja = t.overflow, _n = e;
  }
  var wt = null, Ie = null, Re = !1, kn = null, da = !1, Xc = Error(a(519));
  function Sn(e) {
    var t = Error(
      a(
        418,
        1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML",
        ""
      )
    );
    throw $i(sa(t, e)), Xc;
  }
  function zp(e) {
    var t = e.stateNode, r = e.type, s = e.memoizedProps;
    switch (t[xt] = e, t[zt] = s, r) {
      case "dialog":
        Ce("cancel", t), Ce("close", t);
        break;
      case "iframe":
      case "object":
      case "embed":
        Ce("load", t);
        break;
      case "video":
      case "audio":
        for (r = 0; r < _o.length; r++)
          Ce(_o[r], t);
        break;
      case "source":
        Ce("error", t);
        break;
      case "img":
      case "image":
      case "link":
        Ce("error", t), Ce("load", t);
        break;
      case "details":
        Ce("toggle", t);
        break;
      case "input":
        Ce("invalid", t), Zf(
          t,
          s.value,
          s.defaultValue,
          s.checked,
          s.defaultChecked,
          s.type,
          s.name,
          !0
        );
        break;
      case "select":
        Ce("invalid", t);
        break;
      case "textarea":
        Ce("invalid", t), Wf(t, s.value, s.defaultValue, s.children);
    }
    r = s.children, typeof r != "string" && typeof r != "number" && typeof r != "bigint" || t.textContent === "" + r || s.suppressHydrationWarning === !0 || Jm(t.textContent, r) ? (s.popover != null && (Ce("beforetoggle", t), Ce("toggle", t)), s.onScroll != null && Ce("scroll", t), s.onScrollEnd != null && Ce("scrollend", t), s.onClick != null && (t.onclick = Ga), t = !0) : t = !1, t || Sn(e, !0);
  }
  function Lp(e) {
    for (wt = e.return; wt; )
      switch (wt.tag) {
        case 5:
        case 31:
        case 13:
          da = !1;
          return;
        case 27:
        case 3:
          da = !0;
          return;
        default:
          wt = wt.return;
      }
  }
  function Jr(e) {
    if (e !== wt) return !1;
    if (!Re) return Lp(e), Re = !0, !1;
    var t = e.tag, r;
    if ((r = t !== 3 && t !== 27) && ((r = t === 5) && (r = e.type, r = !(r !== "form" && r !== "button") || dd(e.type, e.memoizedProps)), r = !r), r && Ie && Sn(e), Lp(e), t === 13) {
      if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(a(317));
      Ie = lg(e);
    } else if (t === 31) {
      if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(a(317));
      Ie = lg(e);
    } else
      t === 27 ? (t = Ie, Hn(e.type) ? (e = gd, gd = null, Ie = e) : Ie = t) : Ie = wt ? pa(e.stateNode.nextSibling) : null;
    return !0;
  }
  function lr() {
    Ie = wt = null, Re = !1;
  }
  function Zc() {
    var e = kn;
    return e !== null && (Bt === null ? Bt = e : Bt.push.apply(
      Bt,
      e
    ), kn = null), e;
  }
  function $i(e) {
    kn === null ? kn = [e] : kn.push(e);
  }
  var Kc = M(null), sr = null, Wa = null;
  function Dn(e, t, r) {
    K(Kc, t._currentValue), t._currentValue = r;
  }
  function Ia(e) {
    e._currentValue = Kc.current, T(Kc);
  }
  function Wc(e, t, r) {
    for (; e !== null; ) {
      var s = e.alternate;
      if ((e.childLanes & t) !== t ? (e.childLanes |= t, s !== null && (s.childLanes |= t)) : s !== null && (s.childLanes & t) !== t && (s.childLanes |= t), e === r) break;
      e = e.return;
    }
  }
  function Ic(e, t, r, s) {
    var u = e.child;
    for (u !== null && (u.return = e); u !== null; ) {
      var f = u.dependencies;
      if (f !== null) {
        var v = u.child;
        f = f.firstContext;
        e: for (; f !== null; ) {
          var x = f;
          f = u;
          for (var E = 0; E < t.length; E++)
            if (x.context === t[E]) {
              f.lanes |= r, x = f.alternate, x !== null && (x.lanes |= r), Wc(
                f.return,
                r,
                e
              ), s || (v = null);
              break e;
            }
          f = x.next;
        }
      } else if (u.tag === 18) {
        if (v = u.return, v === null) throw Error(a(341));
        v.lanes |= r, f = v.alternate, f !== null && (f.lanes |= r), Wc(v, r, e), v = null;
      } else v = u.child;
      if (v !== null) v.return = u;
      else
        for (v = u; v !== null; ) {
          if (v === e) {
            v = null;
            break;
          }
          if (u = v.sibling, u !== null) {
            u.return = v.return, v = u;
            break;
          }
          v = v.return;
        }
      u = v;
    }
  }
  function $r(e, t, r, s) {
    e = null;
    for (var u = t, f = !1; u !== null; ) {
      if (!f) {
        if ((u.flags & 524288) !== 0) f = !0;
        else if ((u.flags & 262144) !== 0) break;
      }
      if (u.tag === 10) {
        var v = u.alternate;
        if (v === null) throw Error(a(387));
        if (v = v.memoizedProps, v !== null) {
          var x = u.type;
          Wt(u.pendingProps.value, v.value) || (e !== null ? e.push(x) : e = [x]);
        }
      } else if (u === ke.current) {
        if (v = u.alternate, v === null) throw Error(a(387));
        v.memoizedState.memoizedState !== u.memoizedState.memoizedState && (e !== null ? e.push(Mo) : e = [Mo]);
      }
      u = u.return;
    }
    e !== null && Ic(
      t,
      e,
      r,
      s
    ), t.flags |= 262144;
  }
  function xl(e) {
    for (e = e.firstContext; e !== null; ) {
      if (!Wt(
        e.context._currentValue,
        e.memoizedValue
      ))
        return !0;
      e = e.next;
    }
    return !1;
  }
  function cr(e) {
    sr = e, Wa = null, e = e.dependencies, e !== null && (e.firstContext = null);
  }
  function _t(e) {
    return Yp(sr, e);
  }
  function wl(e, t) {
    return sr === null && cr(e), Yp(e, t);
  }
  function Yp(e, t) {
    var r = t._currentValue;
    if (t = { context: t, memoizedValue: r, next: null }, Wa === null) {
      if (e === null) throw Error(a(308));
      Wa = t, e.dependencies = { lanes: 0, firstContext: t }, e.flags |= 524288;
    } else Wa = Wa.next = t;
    return r;
  }
  var E0 = typeof AbortController < "u" ? AbortController : function() {
    var e = [], t = this.signal = {
      aborted: !1,
      addEventListener: function(r, s) {
        e.push(s);
      }
    };
    this.abort = function() {
      t.aborted = !0, e.forEach(function(r) {
        return r();
      });
    };
  }, M0 = o.unstable_scheduleCallback, T0 = o.unstable_NormalPriority, ft = {
    $$typeof: L,
    Consumer: null,
    Provider: null,
    _currentValue: null,
    _currentValue2: null,
    _threadCount: 0
  };
  function Jc() {
    return {
      controller: new E0(),
      data: /* @__PURE__ */ new Map(),
      refCount: 0
    };
  }
  function eo(e) {
    e.refCount--, e.refCount === 0 && M0(T0, function() {
      e.controller.abort();
    });
  }
  var to = null, $c = 0, ei = 0, ti = null;
  function C0(e, t) {
    if (to === null) {
      var r = to = [];
      $c = 0, ei = ad(), ti = {
        status: "pending",
        value: void 0,
        then: function(s) {
          r.push(s);
        }
      };
    }
    return $c++, t.then(Hp, Hp), t;
  }
  function Hp() {
    if (--$c === 0 && to !== null) {
      ti !== null && (ti.status = "fulfilled");
      var e = to;
      to = null, ei = 0, ti = null;
      for (var t = 0; t < e.length; t++) (0, e[t])();
    }
  }
  function N0(e, t) {
    var r = [], s = {
      status: "pending",
      value: null,
      reason: null,
      then: function(u) {
        r.push(u);
      }
    };
    return e.then(
      function() {
        s.status = "fulfilled", s.value = t;
        for (var u = 0; u < r.length; u++) (0, r[u])(t);
      },
      function(u) {
        for (s.status = "rejected", s.reason = u, u = 0; u < r.length; u++)
          (0, r[u])(void 0);
      }
    ), s;
  }
  var Up = j.S;
  j.S = function(e, t) {
    _m = et(), typeof t == "object" && t !== null && typeof t.then == "function" && C0(e, t), Up !== null && Up(e, t);
  };
  var ur = M(null);
  function eu() {
    var e = ur.current;
    return e !== null ? e : We.pooledCache;
  }
  function _l(e, t) {
    t === null ? K(ur, ur.current) : K(ur, t.pool);
  }
  function Bp() {
    var e = eu();
    return e === null ? null : { parent: ft._currentValue, pool: e };
  }
  var ai = Error(a(460)), tu = Error(a(474)), kl = Error(a(542)), Sl = { then: function() {
  } };
  function qp(e) {
    return e = e.status, e === "fulfilled" || e === "rejected";
  }
  function Qp(e, t, r) {
    switch (r = e[r], r === void 0 ? e.push(t) : r !== t && (t.then(Ga, Ga), t = r), t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw e = t.reason, Fp(e), e;
      default:
        if (typeof t.status == "string") t.then(Ga, Ga);
        else {
          if (e = We, e !== null && 100 < e.shellSuspendCounter)
            throw Error(a(482));
          e = t, e.status = "pending", e.then(
            function(s) {
              if (t.status === "pending") {
                var u = t;
                u.status = "fulfilled", u.value = s;
              }
            },
            function(s) {
              if (t.status === "pending") {
                var u = t;
                u.status = "rejected", u.reason = s;
              }
            }
          );
        }
        switch (t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw e = t.reason, Fp(e), e;
        }
        throw fr = t, ai;
    }
  }
  function dr(e) {
    try {
      var t = e._init;
      return t(e._payload);
    } catch (r) {
      throw r !== null && typeof r == "object" && typeof r.then == "function" ? (fr = r, ai) : r;
    }
  }
  var fr = null;
  function Pp() {
    if (fr === null) throw Error(a(459));
    var e = fr;
    return fr = null, e;
  }
  function Fp(e) {
    if (e === ai || e === kl)
      throw Error(a(483));
  }
  var ni = null, ao = 0;
  function Dl(e) {
    var t = ao;
    return ao += 1, ni === null && (ni = []), Qp(ni, e, t);
  }
  function no(e, t) {
    t = t.props.ref, e.ref = t !== void 0 ? t : null;
  }
  function El(e, t) {
    throw t.$$typeof === _ ? Error(a(525)) : (e = Object.prototype.toString.call(t), Error(
      a(
        31,
        e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e
      )
    ));
  }
  function Vp(e) {
    function t(A, C) {
      if (e) {
        var R = A.deletions;
        R === null ? (A.deletions = [C], A.flags |= 16) : R.push(C);
      }
    }
    function r(A, C) {
      if (!e) return null;
      for (; C !== null; )
        t(A, C), C = C.sibling;
      return null;
    }
    function s(A) {
      for (var C = /* @__PURE__ */ new Map(); A !== null; )
        A.key !== null ? C.set(A.key, A) : C.set(A.index, A), A = A.sibling;
      return C;
    }
    function u(A, C) {
      return A = Za(A, C), A.index = 0, A.sibling = null, A;
    }
    function f(A, C, R) {
      return A.index = R, e ? (R = A.alternate, R !== null ? (R = R.index, R < C ? (A.flags |= 67108866, C) : R) : (A.flags |= 67108866, C)) : (A.flags |= 1048576, C);
    }
    function v(A) {
      return e && A.alternate === null && (A.flags |= 67108866), A;
    }
    function x(A, C, R, G) {
      return C === null || C.tag !== 6 ? (C = Pc(R, A.mode, G), C.return = A, C) : (C = u(C, R), C.return = A, C);
    }
    function E(A, C, R, G) {
      var ge = R.type;
      return ge === D ? V(
        A,
        C,
        R.props.children,
        G,
        R.key
      ) : C !== null && (C.elementType === ge || typeof ge == "object" && ge !== null && ge.$$typeof === ie && dr(ge) === C.type) ? (C = u(C, R.props), no(C, R), C.return = A, C) : (C = bl(
        R.type,
        R.key,
        R.props,
        null,
        A.mode,
        G
      ), no(C, R), C.return = A, C);
    }
    function z(A, C, R, G) {
      return C === null || C.tag !== 4 || C.stateNode.containerInfo !== R.containerInfo || C.stateNode.implementation !== R.implementation ? (C = Fc(R, A.mode, G), C.return = A, C) : (C = u(C, R.children || []), C.return = A, C);
    }
    function V(A, C, R, G, ge) {
      return C === null || C.tag !== 7 ? (C = or(
        R,
        A.mode,
        G,
        ge
      ), C.return = A, C) : (C = u(C, R), C.return = A, C);
    }
    function X(A, C, R) {
      if (typeof C == "string" && C !== "" || typeof C == "number" || typeof C == "bigint")
        return C = Pc(
          "" + C,
          A.mode,
          R
        ), C.return = A, C;
      if (typeof C == "object" && C !== null) {
        switch (C.$$typeof) {
          case k:
            return R = bl(
              C.type,
              C.key,
              C.props,
              null,
              A.mode,
              R
            ), no(R, C), R.return = A, R;
          case w:
            return C = Fc(
              C,
              A.mode,
              R
            ), C.return = A, C;
          case ie:
            return C = dr(C), X(A, C, R);
        }
        if (fe(C) || $(C))
          return C = or(
            C,
            A.mode,
            R,
            null
          ), C.return = A, C;
        if (typeof C.then == "function")
          return X(A, Dl(C), R);
        if (C.$$typeof === L)
          return X(
            A,
            wl(A, C),
            R
          );
        El(A, C);
      }
      return null;
    }
    function Y(A, C, R, G) {
      var ge = C !== null ? C.key : null;
      if (typeof R == "string" && R !== "" || typeof R == "number" || typeof R == "bigint")
        return ge !== null ? null : x(A, C, "" + R, G);
      if (typeof R == "object" && R !== null) {
        switch (R.$$typeof) {
          case k:
            return R.key === ge ? E(A, C, R, G) : null;
          case w:
            return R.key === ge ? z(A, C, R, G) : null;
          case ie:
            return R = dr(R), Y(A, C, R, G);
        }
        if (fe(R) || $(R))
          return ge !== null ? null : V(A, C, R, G, null);
        if (typeof R.then == "function")
          return Y(
            A,
            C,
            Dl(R),
            G
          );
        if (R.$$typeof === L)
          return Y(
            A,
            C,
            wl(A, R),
            G
          );
        El(A, R);
      }
      return null;
    }
    function U(A, C, R, G, ge) {
      if (typeof G == "string" && G !== "" || typeof G == "number" || typeof G == "bigint")
        return A = A.get(R) || null, x(C, A, "" + G, ge);
      if (typeof G == "object" && G !== null) {
        switch (G.$$typeof) {
          case k:
            return A = A.get(
              G.key === null ? R : G.key
            ) || null, E(C, A, G, ge);
          case w:
            return A = A.get(
              G.key === null ? R : G.key
            ) || null, z(C, A, G, ge);
          case ie:
            return G = dr(G), U(
              A,
              C,
              R,
              G,
              ge
            );
        }
        if (fe(G) || $(G))
          return A = A.get(R) || null, V(C, A, G, ge, null);
        if (typeof G.then == "function")
          return U(
            A,
            C,
            R,
            Dl(G),
            ge
          );
        if (G.$$typeof === L)
          return U(
            A,
            C,
            R,
            wl(C, G),
            ge
          );
        El(C, G);
      }
      return null;
    }
    function ce(A, C, R, G) {
      for (var ge = null, Ye = null, he = C, Ee = C = 0, je = null; he !== null && Ee < R.length; Ee++) {
        he.index > Ee ? (je = he, he = null) : je = he.sibling;
        var He = Y(
          A,
          he,
          R[Ee],
          G
        );
        if (He === null) {
          he === null && (he = je);
          break;
        }
        e && he && He.alternate === null && t(A, he), C = f(He, C, Ee), Ye === null ? ge = He : Ye.sibling = He, Ye = He, he = je;
      }
      if (Ee === R.length)
        return r(A, he), Re && Ka(A, Ee), ge;
      if (he === null) {
        for (; Ee < R.length; Ee++)
          he = X(A, R[Ee], G), he !== null && (C = f(
            he,
            C,
            Ee
          ), Ye === null ? ge = he : Ye.sibling = he, Ye = he);
        return Re && Ka(A, Ee), ge;
      }
      for (he = s(he); Ee < R.length; Ee++)
        je = U(
          he,
          A,
          Ee,
          R[Ee],
          G
        ), je !== null && (e && je.alternate !== null && he.delete(
          je.key === null ? Ee : je.key
        ), C = f(
          je,
          C,
          Ee
        ), Ye === null ? ge = je : Ye.sibling = je, Ye = je);
      return e && he.forEach(function(Pn) {
        return t(A, Pn);
      }), Re && Ka(A, Ee), ge;
    }
    function ye(A, C, R, G) {
      if (R == null) throw Error(a(151));
      for (var ge = null, Ye = null, he = C, Ee = C = 0, je = null, He = R.next(); he !== null && !He.done; Ee++, He = R.next()) {
        he.index > Ee ? (je = he, he = null) : je = he.sibling;
        var Pn = Y(A, he, He.value, G);
        if (Pn === null) {
          he === null && (he = je);
          break;
        }
        e && he && Pn.alternate === null && t(A, he), C = f(Pn, C, Ee), Ye === null ? ge = Pn : Ye.sibling = Pn, Ye = Pn, he = je;
      }
      if (He.done)
        return r(A, he), Re && Ka(A, Ee), ge;
      if (he === null) {
        for (; !He.done; Ee++, He = R.next())
          He = X(A, He.value, G), He !== null && (C = f(He, C, Ee), Ye === null ? ge = He : Ye.sibling = He, Ye = He);
        return Re && Ka(A, Ee), ge;
      }
      for (he = s(he); !He.done; Ee++, He = R.next())
        He = U(he, A, Ee, He.value, G), He !== null && (e && He.alternate !== null && he.delete(He.key === null ? Ee : He.key), C = f(He, C, Ee), Ye === null ? ge = He : Ye.sibling = He, Ye = He);
      return e && he.forEach(function(qx) {
        return t(A, qx);
      }), Re && Ka(A, Ee), ge;
    }
    function Ze(A, C, R, G) {
      if (typeof R == "object" && R !== null && R.type === D && R.key === null && (R = R.props.children), typeof R == "object" && R !== null) {
        switch (R.$$typeof) {
          case k:
            e: {
              for (var ge = R.key; C !== null; ) {
                if (C.key === ge) {
                  if (ge = R.type, ge === D) {
                    if (C.tag === 7) {
                      r(
                        A,
                        C.sibling
                      ), G = u(
                        C,
                        R.props.children
                      ), G.return = A, A = G;
                      break e;
                    }
                  } else if (C.elementType === ge || typeof ge == "object" && ge !== null && ge.$$typeof === ie && dr(ge) === C.type) {
                    r(
                      A,
                      C.sibling
                    ), G = u(C, R.props), no(G, R), G.return = A, A = G;
                    break e;
                  }
                  r(A, C);
                  break;
                } else t(A, C);
                C = C.sibling;
              }
              R.type === D ? (G = or(
                R.props.children,
                A.mode,
                G,
                R.key
              ), G.return = A, A = G) : (G = bl(
                R.type,
                R.key,
                R.props,
                null,
                A.mode,
                G
              ), no(G, R), G.return = A, A = G);
            }
            return v(A);
          case w:
            e: {
              for (ge = R.key; C !== null; ) {
                if (C.key === ge)
                  if (C.tag === 4 && C.stateNode.containerInfo === R.containerInfo && C.stateNode.implementation === R.implementation) {
                    r(
                      A,
                      C.sibling
                    ), G = u(C, R.children || []), G.return = A, A = G;
                    break e;
                  } else {
                    r(A, C);
                    break;
                  }
                else t(A, C);
                C = C.sibling;
              }
              G = Fc(R, A.mode, G), G.return = A, A = G;
            }
            return v(A);
          case ie:
            return R = dr(R), Ze(
              A,
              C,
              R,
              G
            );
        }
        if (fe(R))
          return ce(
            A,
            C,
            R,
            G
          );
        if ($(R)) {
          if (ge = $(R), typeof ge != "function") throw Error(a(150));
          return R = ge.call(R), ye(
            A,
            C,
            R,
            G
          );
        }
        if (typeof R.then == "function")
          return Ze(
            A,
            C,
            Dl(R),
            G
          );
        if (R.$$typeof === L)
          return Ze(
            A,
            C,
            wl(A, R),
            G
          );
        El(A, R);
      }
      return typeof R == "string" && R !== "" || typeof R == "number" || typeof R == "bigint" ? (R = "" + R, C !== null && C.tag === 6 ? (r(A, C.sibling), G = u(C, R), G.return = A, A = G) : (r(A, C), G = Pc(R, A.mode, G), G.return = A, A = G), v(A)) : r(A, C);
    }
    return function(A, C, R, G) {
      try {
        ao = 0;
        var ge = Ze(
          A,
          C,
          R,
          G
        );
        return ni = null, ge;
      } catch (he) {
        if (he === ai || he === kl) throw he;
        var Ye = It(29, he, null, A.mode);
        return Ye.lanes = G, Ye.return = A, Ye;
      }
    };
  }
  var pr = Vp(!0), Gp = Vp(!1), En = !1;
  function au(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null
    };
  }
  function nu(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
      baseState: e.baseState,
      firstBaseUpdate: e.firstBaseUpdate,
      lastBaseUpdate: e.lastBaseUpdate,
      shared: e.shared,
      callbacks: null
    });
  }
  function Mn(e) {
    return { lane: e, tag: 0, payload: null, callback: null, next: null };
  }
  function Tn(e, t, r) {
    var s = e.updateQueue;
    if (s === null) return null;
    if (s = s.shared, (Ue & 2) !== 0) {
      var u = s.pending;
      return u === null ? t.next = t : (t.next = u.next, u.next = t), s.pending = t, t = vl(e), Cp(e, null, r), t;
    }
    return gl(e, s, t, r), vl(e);
  }
  function ro(e, t, r) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (r & 4194048) !== 0)) {
      var s = t.lanes;
      s &= e.pendingLanes, r |= s, t.lanes = r, Yf(e, r);
    }
  }
  function ru(e, t) {
    var r = e.updateQueue, s = e.alternate;
    if (s !== null && (s = s.updateQueue, r === s)) {
      var u = null, f = null;
      if (r = r.firstBaseUpdate, r !== null) {
        do {
          var v = {
            lane: r.lane,
            tag: r.tag,
            payload: r.payload,
            callback: null,
            next: null
          };
          f === null ? u = f = v : f = f.next = v, r = r.next;
        } while (r !== null);
        f === null ? u = f = t : f = f.next = t;
      } else u = f = t;
      r = {
        baseState: s.baseState,
        firstBaseUpdate: u,
        lastBaseUpdate: f,
        shared: s.shared,
        callbacks: s.callbacks
      }, e.updateQueue = r;
      return;
    }
    e = r.lastBaseUpdate, e === null ? r.firstBaseUpdate = t : e.next = t, r.lastBaseUpdate = t;
  }
  var iu = !1;
  function io() {
    if (iu) {
      var e = ti;
      if (e !== null) throw e;
    }
  }
  function oo(e, t, r, s) {
    iu = !1;
    var u = e.updateQueue;
    En = !1;
    var f = u.firstBaseUpdate, v = u.lastBaseUpdate, x = u.shared.pending;
    if (x !== null) {
      u.shared.pending = null;
      var E = x, z = E.next;
      E.next = null, v === null ? f = z : v.next = z, v = E;
      var V = e.alternate;
      V !== null && (V = V.updateQueue, x = V.lastBaseUpdate, x !== v && (x === null ? V.firstBaseUpdate = z : x.next = z, V.lastBaseUpdate = E));
    }
    if (f !== null) {
      var X = u.baseState;
      v = 0, V = z = E = null, x = f;
      do {
        var Y = x.lane & -536870913, U = Y !== x.lane;
        if (U ? (Oe & Y) === Y : (s & Y) === Y) {
          Y !== 0 && Y === ei && (iu = !0), V !== null && (V = V.next = {
            lane: 0,
            tag: x.tag,
            payload: x.payload,
            callback: null,
            next: null
          });
          e: {
            var ce = e, ye = x;
            Y = t;
            var Ze = r;
            switch (ye.tag) {
              case 1:
                if (ce = ye.payload, typeof ce == "function") {
                  X = ce.call(Ze, X, Y);
                  break e;
                }
                X = ce;
                break e;
              case 3:
                ce.flags = ce.flags & -65537 | 128;
              case 0:
                if (ce = ye.payload, Y = typeof ce == "function" ? ce.call(Ze, X, Y) : ce, Y == null) break e;
                X = b({}, X, Y);
                break e;
              case 2:
                En = !0;
            }
          }
          Y = x.callback, Y !== null && (e.flags |= 64, U && (e.flags |= 8192), U = u.callbacks, U === null ? u.callbacks = [Y] : U.push(Y));
        } else
          U = {
            lane: Y,
            tag: x.tag,
            payload: x.payload,
            callback: x.callback,
            next: null
          }, V === null ? (z = V = U, E = X) : V = V.next = U, v |= Y;
        if (x = x.next, x === null) {
          if (x = u.shared.pending, x === null)
            break;
          U = x, x = U.next, U.next = null, u.lastBaseUpdate = U, u.shared.pending = null;
        }
      } while (!0);
      V === null && (E = X), u.baseState = E, u.firstBaseUpdate = z, u.lastBaseUpdate = V, f === null && (u.shared.lanes = 0), An |= v, e.lanes = v, e.memoizedState = X;
    }
  }
  function Xp(e, t) {
    if (typeof e != "function")
      throw Error(a(191, e));
    e.call(t);
  }
  function Zp(e, t) {
    var r = e.callbacks;
    if (r !== null)
      for (e.callbacks = null, e = 0; e < r.length; e++)
        Xp(r[e], t);
  }
  var ri = M(null), Ml = M(0);
  function Kp(e, t) {
    e = ln, K(Ml, e), K(ri, t), ln = e | t.baseLanes;
  }
  function ou() {
    K(Ml, ln), K(ri, ri.current);
  }
  function lu() {
    ln = Ml.current, T(ri), T(Ml);
  }
  var Jt = M(null), fa = null;
  function Cn(e) {
    var t = e.alternate;
    K(st, st.current & 1), K(Jt, e), fa === null && (t === null || ri.current !== null || t.memoizedState !== null) && (fa = e);
  }
  function su(e) {
    K(st, st.current), K(Jt, e), fa === null && (fa = e);
  }
  function Wp(e) {
    e.tag === 22 ? (K(st, st.current), K(Jt, e), fa === null && (fa = e)) : Nn();
  }
  function Nn() {
    K(st, st.current), K(Jt, Jt.current);
  }
  function $t(e) {
    T(Jt), fa === e && (fa = null), T(st);
  }
  var st = M(0);
  function Tl(e) {
    for (var t = e; t !== null; ) {
      if (t.tag === 13) {
        var r = t.memoizedState;
        if (r !== null && (r = r.dehydrated, r === null || hd(r) || md(r)))
          return t;
      } else if (t.tag === 19 && (t.memoizedProps.revealOrder === "forwards" || t.memoizedProps.revealOrder === "backwards" || t.memoizedProps.revealOrder === "unstable_legacy-backwards" || t.memoizedProps.revealOrder === "together")) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return null;
  }
  var Ja = 0, Se = null, Ge = null, pt = null, Cl = !1, ii = !1, hr = !1, Nl = 0, lo = 0, oi = null, O0 = 0;
  function nt() {
    throw Error(a(321));
  }
  function cu(e, t) {
    if (t === null) return !1;
    for (var r = 0; r < t.length && r < e.length; r++)
      if (!Wt(e[r], t[r])) return !1;
    return !0;
  }
  function uu(e, t, r, s, u, f) {
    return Ja = f, Se = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, j.H = e === null || e.memoizedState === null ? Ah : Du, hr = !1, f = r(s, u), hr = !1, ii && (f = Jp(
      t,
      r,
      s,
      u
    )), Ip(e), f;
  }
  function Ip(e) {
    j.H = uo;
    var t = Ge !== null && Ge.next !== null;
    if (Ja = 0, pt = Ge = Se = null, Cl = !1, lo = 0, oi = null, t) throw Error(a(300));
    e === null || ht || (e = e.dependencies, e !== null && xl(e) && (ht = !0));
  }
  function Jp(e, t, r, s) {
    Se = e;
    var u = 0;
    do {
      if (ii && (oi = null), lo = 0, ii = !1, 25 <= u) throw Error(a(301));
      if (u += 1, pt = Ge = null, e.updateQueue != null) {
        var f = e.updateQueue;
        f.lastEffect = null, f.events = null, f.stores = null, f.memoCache != null && (f.memoCache.index = 0);
      }
      j.H = Rh, f = t(r, s);
    } while (ii);
    return f;
  }
  function j0() {
    var e = j.H, t = e.useState()[0];
    return t = typeof t.then == "function" ? so(t) : t, e = e.useState()[0], (Ge !== null ? Ge.memoizedState : null) !== e && (Se.flags |= 1024), t;
  }
  function du() {
    var e = Nl !== 0;
    return Nl = 0, e;
  }
  function fu(e, t, r) {
    t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~r;
  }
  function pu(e) {
    if (Cl) {
      for (e = e.memoizedState; e !== null; ) {
        var t = e.queue;
        t !== null && (t.pending = null), e = e.next;
      }
      Cl = !1;
    }
    Ja = 0, pt = Ge = Se = null, ii = !1, lo = Nl = 0, oi = null;
  }
  function jt() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return pt === null ? Se.memoizedState = pt = e : pt = pt.next = e, pt;
  }
  function ct() {
    if (Ge === null) {
      var e = Se.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = Ge.next;
    var t = pt === null ? Se.memoizedState : pt.next;
    if (t !== null)
      pt = t, Ge = e;
    else {
      if (e === null)
        throw Se.alternate === null ? Error(a(467)) : Error(a(310));
      Ge = e, e = {
        memoizedState: Ge.memoizedState,
        baseState: Ge.baseState,
        baseQueue: Ge.baseQueue,
        queue: Ge.queue,
        next: null
      }, pt === null ? Se.memoizedState = pt = e : pt = pt.next = e;
    }
    return pt;
  }
  function Ol() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function so(e) {
    var t = lo;
    return lo += 1, oi === null && (oi = []), e = Qp(oi, e, t), t = Se, (pt === null ? t.memoizedState : pt.next) === null && (t = t.alternate, j.H = t === null || t.memoizedState === null ? Ah : Du), e;
  }
  function jl(e) {
    if (e !== null && typeof e == "object") {
      if (typeof e.then == "function") return so(e);
      if (e.$$typeof === L) return _t(e);
    }
    throw Error(a(438, String(e)));
  }
  function hu(e) {
    var t = null, r = Se.updateQueue;
    if (r !== null && (t = r.memoCache), t == null) {
      var s = Se.alternate;
      s !== null && (s = s.updateQueue, s !== null && (s = s.memoCache, s != null && (t = {
        data: s.data.map(function(u) {
          return u.slice();
        }),
        index: 0
      })));
    }
    if (t == null && (t = { data: [], index: 0 }), r === null && (r = Ol(), Se.updateQueue = r), r.memoCache = t, r = t.data[t.index], r === void 0)
      for (r = t.data[t.index] = Array(e), s = 0; s < e; s++)
        r[s] = de;
    return t.index++, r;
  }
  function $a(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Al(e) {
    var t = ct();
    return mu(t, Ge, e);
  }
  function mu(e, t, r) {
    var s = e.queue;
    if (s === null) throw Error(a(311));
    s.lastRenderedReducer = r;
    var u = e.baseQueue, f = s.pending;
    if (f !== null) {
      if (u !== null) {
        var v = u.next;
        u.next = f.next, f.next = v;
      }
      t.baseQueue = u = f, s.pending = null;
    }
    if (f = e.baseState, u === null) e.memoizedState = f;
    else {
      t = u.next;
      var x = v = null, E = null, z = t, V = !1;
      do {
        var X = z.lane & -536870913;
        if (X !== z.lane ? (Oe & X) === X : (Ja & X) === X) {
          var Y = z.revertLane;
          if (Y === 0)
            E !== null && (E = E.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: z.action,
              hasEagerState: z.hasEagerState,
              eagerState: z.eagerState,
              next: null
            }), X === ei && (V = !0);
          else if ((Ja & Y) === Y) {
            z = z.next, Y === ei && (V = !0);
            continue;
          } else
            X = {
              lane: 0,
              revertLane: z.revertLane,
              gesture: null,
              action: z.action,
              hasEagerState: z.hasEagerState,
              eagerState: z.eagerState,
              next: null
            }, E === null ? (x = E = X, v = f) : E = E.next = X, Se.lanes |= Y, An |= Y;
          X = z.action, hr && r(f, X), f = z.hasEagerState ? z.eagerState : r(f, X);
        } else
          Y = {
            lane: X,
            revertLane: z.revertLane,
            gesture: z.gesture,
            action: z.action,
            hasEagerState: z.hasEagerState,
            eagerState: z.eagerState,
            next: null
          }, E === null ? (x = E = Y, v = f) : E = E.next = Y, Se.lanes |= X, An |= X;
        z = z.next;
      } while (z !== null && z !== t);
      if (E === null ? v = f : E.next = x, !Wt(f, e.memoizedState) && (ht = !0, V && (r = ti, r !== null)))
        throw r;
      e.memoizedState = f, e.baseState = v, e.baseQueue = E, s.lastRenderedState = f;
    }
    return u === null && (s.lanes = 0), [e.memoizedState, s.dispatch];
  }
  function gu(e) {
    var t = ct(), r = t.queue;
    if (r === null) throw Error(a(311));
    r.lastRenderedReducer = e;
    var s = r.dispatch, u = r.pending, f = t.memoizedState;
    if (u !== null) {
      r.pending = null;
      var v = u = u.next;
      do
        f = e(f, v.action), v = v.next;
      while (v !== u);
      Wt(f, t.memoizedState) || (ht = !0), t.memoizedState = f, t.baseQueue === null && (t.baseState = f), r.lastRenderedState = f;
    }
    return [f, s];
  }
  function $p(e, t, r) {
    var s = Se, u = ct(), f = Re;
    if (f) {
      if (r === void 0) throw Error(a(407));
      r = r();
    } else r = t();
    var v = !Wt(
      (Ge || u).memoizedState,
      r
    );
    if (v && (u.memoizedState = r, ht = !0), u = u.queue, yu(ah.bind(null, s, u, e), [
      e
    ]), u.getSnapshot !== t || v || pt !== null && pt.memoizedState.tag & 1) {
      if (s.flags |= 2048, li(
        9,
        { destroy: void 0 },
        th.bind(
          null,
          s,
          u,
          r,
          t
        ),
        null
      ), We === null) throw Error(a(349));
      f || (Ja & 127) !== 0 || eh(s, t, r);
    }
    return r;
  }
  function eh(e, t, r) {
    e.flags |= 16384, e = { getSnapshot: t, value: r }, t = Se.updateQueue, t === null ? (t = Ol(), Se.updateQueue = t, t.stores = [e]) : (r = t.stores, r === null ? t.stores = [e] : r.push(e));
  }
  function th(e, t, r, s) {
    t.value = r, t.getSnapshot = s, nh(t) && rh(e);
  }
  function ah(e, t, r) {
    return r(function() {
      nh(t) && rh(e);
    });
  }
  function nh(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var r = t();
      return !Wt(e, r);
    } catch {
      return !0;
    }
  }
  function rh(e) {
    var t = ir(e, 2);
    t !== null && qt(t, e, 2);
  }
  function vu(e) {
    var t = jt();
    if (typeof e == "function") {
      var r = e;
      if (e = r(), hr) {
        yn(!0);
        try {
          r();
        } finally {
          yn(!1);
        }
      }
    }
    return t.memoizedState = t.baseState = e, t.queue = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: $a,
      lastRenderedState: e
    }, t;
  }
  function ih(e, t, r, s) {
    return e.baseState = r, mu(
      e,
      Ge,
      typeof s == "function" ? s : $a
    );
  }
  function A0(e, t, r, s, u) {
    if (Ll(e)) throw Error(a(485));
    if (e = t.action, e !== null) {
      var f = {
        payload: u,
        action: e,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function(v) {
          f.listeners.push(v);
        }
      };
      j.T !== null ? r(!0) : f.isTransition = !1, s(f), r = t.pending, r === null ? (f.next = t.pending = f, oh(t, f)) : (f.next = r.next, t.pending = r.next = f);
    }
  }
  function oh(e, t) {
    var r = t.action, s = t.payload, u = e.state;
    if (t.isTransition) {
      var f = j.T, v = {};
      j.T = v;
      try {
        var x = r(u, s), E = j.S;
        E !== null && E(v, x), lh(e, t, x);
      } catch (z) {
        bu(e, t, z);
      } finally {
        f !== null && v.types !== null && (f.types = v.types), j.T = f;
      }
    } else
      try {
        f = r(u, s), lh(e, t, f);
      } catch (z) {
        bu(e, t, z);
      }
  }
  function lh(e, t, r) {
    r !== null && typeof r == "object" && typeof r.then == "function" ? r.then(
      function(s) {
        sh(e, t, s);
      },
      function(s) {
        return bu(e, t, s);
      }
    ) : sh(e, t, r);
  }
  function sh(e, t, r) {
    t.status = "fulfilled", t.value = r, ch(t), e.state = r, t = e.pending, t !== null && (r = t.next, r === t ? e.pending = null : (r = r.next, t.next = r, oh(e, r)));
  }
  function bu(e, t, r) {
    var s = e.pending;
    if (e.pending = null, s !== null) {
      s = s.next;
      do
        t.status = "rejected", t.reason = r, ch(t), t = t.next;
      while (t !== s);
    }
    e.action = null;
  }
  function ch(e) {
    e = e.listeners;
    for (var t = 0; t < e.length; t++) (0, e[t])();
  }
  function uh(e, t) {
    return t;
  }
  function dh(e, t) {
    if (Re) {
      var r = We.formState;
      if (r !== null) {
        e: {
          var s = Se;
          if (Re) {
            if (Ie) {
              t: {
                for (var u = Ie, f = da; u.nodeType !== 8; ) {
                  if (!f) {
                    u = null;
                    break t;
                  }
                  if (u = pa(
                    u.nextSibling
                  ), u === null) {
                    u = null;
                    break t;
                  }
                }
                f = u.data, u = f === "F!" || f === "F" ? u : null;
              }
              if (u) {
                Ie = pa(
                  u.nextSibling
                ), s = u.data === "F!";
                break e;
              }
            }
            Sn(s);
          }
          s = !1;
        }
        s && (t = r[0]);
      }
    }
    return r = jt(), r.memoizedState = r.baseState = t, s = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: uh,
      lastRenderedState: t
    }, r.queue = s, r = Nh.bind(
      null,
      Se,
      s
    ), s.dispatch = r, s = vu(!1), f = Su.bind(
      null,
      Se,
      !1,
      s.queue
    ), s = jt(), u = {
      state: t,
      dispatch: null,
      action: e,
      pending: null
    }, s.queue = u, r = A0.bind(
      null,
      Se,
      u,
      f,
      r
    ), u.dispatch = r, s.memoizedState = e, [t, r, !1];
  }
  function fh(e) {
    var t = ct();
    return ph(t, Ge, e);
  }
  function ph(e, t, r) {
    if (t = mu(
      e,
      t,
      uh
    )[0], e = Al($a)[0], typeof t == "object" && t !== null && typeof t.then == "function")
      try {
        var s = so(t);
      } catch (v) {
        throw v === ai ? kl : v;
      }
    else s = t;
    t = ct();
    var u = t.queue, f = u.dispatch;
    return r !== t.memoizedState && (Se.flags |= 2048, li(
      9,
      { destroy: void 0 },
      R0.bind(null, u, r),
      null
    )), [s, f, e];
  }
  function R0(e, t) {
    e.action = t;
  }
  function hh(e) {
    var t = ct(), r = Ge;
    if (r !== null)
      return ph(t, r, e);
    ct(), t = t.memoizedState, r = ct();
    var s = r.queue.dispatch;
    return r.memoizedState = e, [t, s, !1];
  }
  function li(e, t, r, s) {
    return e = { tag: e, create: r, deps: s, inst: t, next: null }, t = Se.updateQueue, t === null && (t = Ol(), Se.updateQueue = t), r = t.lastEffect, r === null ? t.lastEffect = e.next = e : (s = r.next, r.next = e, e.next = s, t.lastEffect = e), e;
  }
  function mh() {
    return ct().memoizedState;
  }
  function Rl(e, t, r, s) {
    var u = jt();
    Se.flags |= e, u.memoizedState = li(
      1 | t,
      { destroy: void 0 },
      r,
      s === void 0 ? null : s
    );
  }
  function zl(e, t, r, s) {
    var u = ct();
    s = s === void 0 ? null : s;
    var f = u.memoizedState.inst;
    Ge !== null && s !== null && cu(s, Ge.memoizedState.deps) ? u.memoizedState = li(t, f, r, s) : (Se.flags |= e, u.memoizedState = li(
      1 | t,
      f,
      r,
      s
    ));
  }
  function gh(e, t) {
    Rl(8390656, 8, e, t);
  }
  function yu(e, t) {
    zl(2048, 8, e, t);
  }
  function z0(e) {
    Se.flags |= 4;
    var t = Se.updateQueue;
    if (t === null)
      t = Ol(), Se.updateQueue = t, t.events = [e];
    else {
      var r = t.events;
      r === null ? t.events = [e] : r.push(e);
    }
  }
  function vh(e) {
    var t = ct().memoizedState;
    return z0({ ref: t, nextImpl: e }), function() {
      if ((Ue & 2) !== 0) throw Error(a(440));
      return t.impl.apply(void 0, arguments);
    };
  }
  function bh(e, t) {
    return zl(4, 2, e, t);
  }
  function yh(e, t) {
    return zl(4, 4, e, t);
  }
  function xh(e, t) {
    if (typeof t == "function") {
      e = e();
      var r = t(e);
      return function() {
        typeof r == "function" ? r() : t(null);
      };
    }
    if (t != null)
      return e = e(), t.current = e, function() {
        t.current = null;
      };
  }
  function wh(e, t, r) {
    r = r != null ? r.concat([e]) : null, zl(4, 4, xh.bind(null, t, e), r);
  }
  function xu() {
  }
  function _h(e, t) {
    var r = ct();
    t = t === void 0 ? null : t;
    var s = r.memoizedState;
    return t !== null && cu(t, s[1]) ? s[0] : (r.memoizedState = [e, t], e);
  }
  function kh(e, t) {
    var r = ct();
    t = t === void 0 ? null : t;
    var s = r.memoizedState;
    if (t !== null && cu(t, s[1]))
      return s[0];
    if (s = e(), hr) {
      yn(!0);
      try {
        e();
      } finally {
        yn(!1);
      }
    }
    return r.memoizedState = [s, t], s;
  }
  function wu(e, t, r) {
    return r === void 0 || (Ja & 1073741824) !== 0 && (Oe & 261930) === 0 ? e.memoizedState = t : (e.memoizedState = r, e = Sm(), Se.lanes |= e, An |= e, r);
  }
  function Sh(e, t, r, s) {
    return Wt(r, t) ? r : ri.current !== null ? (e = wu(e, r, s), Wt(e, t) || (ht = !0), e) : (Ja & 42) === 0 || (Ja & 1073741824) !== 0 && (Oe & 261930) === 0 ? (ht = !0, e.memoizedState = r) : (e = Sm(), Se.lanes |= e, An |= e, t);
  }
  function Dh(e, t, r, s, u) {
    var f = Q.p;
    Q.p = f !== 0 && 8 > f ? f : 8;
    var v = j.T, x = {};
    j.T = x, Su(e, !1, t, r);
    try {
      var E = u(), z = j.S;
      if (z !== null && z(x, E), E !== null && typeof E == "object" && typeof E.then == "function") {
        var V = N0(
          E,
          s
        );
        co(
          e,
          t,
          V,
          aa(e)
        );
      } else
        co(
          e,
          t,
          s,
          aa(e)
        );
    } catch (X) {
      co(
        e,
        t,
        { then: function() {
        }, status: "rejected", reason: X },
        aa()
      );
    } finally {
      Q.p = f, v !== null && x.types !== null && (v.types = x.types), j.T = v;
    }
  }
  function L0() {
  }
  function _u(e, t, r, s) {
    if (e.tag !== 5) throw Error(a(476));
    var u = Eh(e).queue;
    Dh(
      e,
      u,
      t,
      W,
      r === null ? L0 : function() {
        return Mh(e), r(s);
      }
    );
  }
  function Eh(e) {
    var t = e.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: W,
      baseState: W,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: $a,
        lastRenderedState: W
      },
      next: null
    };
    var r = {};
    return t.next = {
      memoizedState: r,
      baseState: r,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: $a,
        lastRenderedState: r
      },
      next: null
    }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t;
  }
  function Mh(e) {
    var t = Eh(e);
    t.next === null && (t = e.alternate.memoizedState), co(
      e,
      t.next.queue,
      {},
      aa()
    );
  }
  function ku() {
    return _t(Mo);
  }
  function Th() {
    return ct().memoizedState;
  }
  function Ch() {
    return ct().memoizedState;
  }
  function Y0(e) {
    for (var t = e.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var r = aa();
          e = Mn(r);
          var s = Tn(t, e, r);
          s !== null && (qt(s, t, r), ro(s, t, r)), t = { cache: Jc() }, e.payload = t;
          return;
      }
      t = t.return;
    }
  }
  function H0(e, t, r) {
    var s = aa();
    r = {
      lane: s,
      revertLane: 0,
      gesture: null,
      action: r,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, Ll(e) ? Oh(t, r) : (r = qc(e, t, r, s), r !== null && (qt(r, e, s), jh(r, t, s)));
  }
  function Nh(e, t, r) {
    var s = aa();
    co(e, t, r, s);
  }
  function co(e, t, r, s) {
    var u = {
      lane: s,
      revertLane: 0,
      gesture: null,
      action: r,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if (Ll(e)) Oh(t, u);
    else {
      var f = e.alternate;
      if (e.lanes === 0 && (f === null || f.lanes === 0) && (f = t.lastRenderedReducer, f !== null))
        try {
          var v = t.lastRenderedState, x = f(v, r);
          if (u.hasEagerState = !0, u.eagerState = x, Wt(x, v))
            return gl(e, t, u, 0), We === null && ml(), !1;
        } catch {
        }
      if (r = qc(e, t, u, s), r !== null)
        return qt(r, e, s), jh(r, t, s), !0;
    }
    return !1;
  }
  function Su(e, t, r, s) {
    if (s = {
      lane: 2,
      revertLane: ad(),
      gesture: null,
      action: s,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, Ll(e)) {
      if (t) throw Error(a(479));
    } else
      t = qc(
        e,
        r,
        s,
        2
      ), t !== null && qt(t, e, 2);
  }
  function Ll(e) {
    var t = e.alternate;
    return e === Se || t !== null && t === Se;
  }
  function Oh(e, t) {
    ii = Cl = !0;
    var r = e.pending;
    r === null ? t.next = t : (t.next = r.next, r.next = t), e.pending = t;
  }
  function jh(e, t, r) {
    if ((r & 4194048) !== 0) {
      var s = t.lanes;
      s &= e.pendingLanes, r |= s, t.lanes = r, Yf(e, r);
    }
  }
  var uo = {
    readContext: _t,
    use: jl,
    useCallback: nt,
    useContext: nt,
    useEffect: nt,
    useImperativeHandle: nt,
    useLayoutEffect: nt,
    useInsertionEffect: nt,
    useMemo: nt,
    useReducer: nt,
    useRef: nt,
    useState: nt,
    useDebugValue: nt,
    useDeferredValue: nt,
    useTransition: nt,
    useSyncExternalStore: nt,
    useId: nt,
    useHostTransitionStatus: nt,
    useFormState: nt,
    useActionState: nt,
    useOptimistic: nt,
    useMemoCache: nt,
    useCacheRefresh: nt
  };
  uo.useEffectEvent = nt;
  var Ah = {
    readContext: _t,
    use: jl,
    useCallback: function(e, t) {
      return jt().memoizedState = [
        e,
        t === void 0 ? null : t
      ], e;
    },
    useContext: _t,
    useEffect: gh,
    useImperativeHandle: function(e, t, r) {
      r = r != null ? r.concat([e]) : null, Rl(
        4194308,
        4,
        xh.bind(null, t, e),
        r
      );
    },
    useLayoutEffect: function(e, t) {
      return Rl(4194308, 4, e, t);
    },
    useInsertionEffect: function(e, t) {
      Rl(4, 2, e, t);
    },
    useMemo: function(e, t) {
      var r = jt();
      t = t === void 0 ? null : t;
      var s = e();
      if (hr) {
        yn(!0);
        try {
          e();
        } finally {
          yn(!1);
        }
      }
      return r.memoizedState = [s, t], s;
    },
    useReducer: function(e, t, r) {
      var s = jt();
      if (r !== void 0) {
        var u = r(t);
        if (hr) {
          yn(!0);
          try {
            r(t);
          } finally {
            yn(!1);
          }
        }
      } else u = t;
      return s.memoizedState = s.baseState = u, e = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: e,
        lastRenderedState: u
      }, s.queue = e, e = e.dispatch = H0.bind(
        null,
        Se,
        e
      ), [s.memoizedState, e];
    },
    useRef: function(e) {
      var t = jt();
      return e = { current: e }, t.memoizedState = e;
    },
    useState: function(e) {
      e = vu(e);
      var t = e.queue, r = Nh.bind(null, Se, t);
      return t.dispatch = r, [e.memoizedState, r];
    },
    useDebugValue: xu,
    useDeferredValue: function(e, t) {
      var r = jt();
      return wu(r, e, t);
    },
    useTransition: function() {
      var e = vu(!1);
      return e = Dh.bind(
        null,
        Se,
        e.queue,
        !0,
        !1
      ), jt().memoizedState = e, [!1, e];
    },
    useSyncExternalStore: function(e, t, r) {
      var s = Se, u = jt();
      if (Re) {
        if (r === void 0)
          throw Error(a(407));
        r = r();
      } else {
        if (r = t(), We === null)
          throw Error(a(349));
        (Oe & 127) !== 0 || eh(s, t, r);
      }
      u.memoizedState = r;
      var f = { value: r, getSnapshot: t };
      return u.queue = f, gh(ah.bind(null, s, f, e), [
        e
      ]), s.flags |= 2048, li(
        9,
        { destroy: void 0 },
        th.bind(
          null,
          s,
          f,
          r,
          t
        ),
        null
      ), r;
    },
    useId: function() {
      var e = jt(), t = We.identifierPrefix;
      if (Re) {
        var r = ja, s = Oa;
        r = (s & ~(1 << 32 - Kt(s) - 1)).toString(32) + r, t = "_" + t + "R_" + r, r = Nl++, 0 < r && (t += "H" + r.toString(32)), t += "_";
      } else
        r = O0++, t = "_" + t + "r_" + r.toString(32) + "_";
      return e.memoizedState = t;
    },
    useHostTransitionStatus: ku,
    useFormState: dh,
    useActionState: dh,
    useOptimistic: function(e) {
      var t = jt();
      t.memoizedState = t.baseState = e;
      var r = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return t.queue = r, t = Su.bind(
        null,
        Se,
        !0,
        r
      ), r.dispatch = t, [e, t];
    },
    useMemoCache: hu,
    useCacheRefresh: function() {
      return jt().memoizedState = Y0.bind(
        null,
        Se
      );
    },
    useEffectEvent: function(e) {
      var t = jt(), r = { impl: e };
      return t.memoizedState = r, function() {
        if ((Ue & 2) !== 0)
          throw Error(a(440));
        return r.impl.apply(void 0, arguments);
      };
    }
  }, Du = {
    readContext: _t,
    use: jl,
    useCallback: _h,
    useContext: _t,
    useEffect: yu,
    useImperativeHandle: wh,
    useInsertionEffect: bh,
    useLayoutEffect: yh,
    useMemo: kh,
    useReducer: Al,
    useRef: mh,
    useState: function() {
      return Al($a);
    },
    useDebugValue: xu,
    useDeferredValue: function(e, t) {
      var r = ct();
      return Sh(
        r,
        Ge.memoizedState,
        e,
        t
      );
    },
    useTransition: function() {
      var e = Al($a)[0], t = ct().memoizedState;
      return [
        typeof e == "boolean" ? e : so(e),
        t
      ];
    },
    useSyncExternalStore: $p,
    useId: Th,
    useHostTransitionStatus: ku,
    useFormState: fh,
    useActionState: fh,
    useOptimistic: function(e, t) {
      var r = ct();
      return ih(r, Ge, e, t);
    },
    useMemoCache: hu,
    useCacheRefresh: Ch
  };
  Du.useEffectEvent = vh;
  var Rh = {
    readContext: _t,
    use: jl,
    useCallback: _h,
    useContext: _t,
    useEffect: yu,
    useImperativeHandle: wh,
    useInsertionEffect: bh,
    useLayoutEffect: yh,
    useMemo: kh,
    useReducer: gu,
    useRef: mh,
    useState: function() {
      return gu($a);
    },
    useDebugValue: xu,
    useDeferredValue: function(e, t) {
      var r = ct();
      return Ge === null ? wu(r, e, t) : Sh(
        r,
        Ge.memoizedState,
        e,
        t
      );
    },
    useTransition: function() {
      var e = gu($a)[0], t = ct().memoizedState;
      return [
        typeof e == "boolean" ? e : so(e),
        t
      ];
    },
    useSyncExternalStore: $p,
    useId: Th,
    useHostTransitionStatus: ku,
    useFormState: hh,
    useActionState: hh,
    useOptimistic: function(e, t) {
      var r = ct();
      return Ge !== null ? ih(r, Ge, e, t) : (r.baseState = e, [e, r.queue.dispatch]);
    },
    useMemoCache: hu,
    useCacheRefresh: Ch
  };
  Rh.useEffectEvent = vh;
  function Eu(e, t, r, s) {
    t = e.memoizedState, r = r(s, t), r = r == null ? t : b({}, t, r), e.memoizedState = r, e.lanes === 0 && (e.updateQueue.baseState = r);
  }
  var Mu = {
    enqueueSetState: function(e, t, r) {
      e = e._reactInternals;
      var s = aa(), u = Mn(s);
      u.payload = t, r != null && (u.callback = r), t = Tn(e, u, s), t !== null && (qt(t, e, s), ro(t, e, s));
    },
    enqueueReplaceState: function(e, t, r) {
      e = e._reactInternals;
      var s = aa(), u = Mn(s);
      u.tag = 1, u.payload = t, r != null && (u.callback = r), t = Tn(e, u, s), t !== null && (qt(t, e, s), ro(t, e, s));
    },
    enqueueForceUpdate: function(e, t) {
      e = e._reactInternals;
      var r = aa(), s = Mn(r);
      s.tag = 2, t != null && (s.callback = t), t = Tn(e, s, r), t !== null && (qt(t, e, r), ro(t, e, r));
    }
  };
  function zh(e, t, r, s, u, f, v) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(s, f, v) : t.prototype && t.prototype.isPureReactComponent ? !Wi(r, s) || !Wi(u, f) : !0;
  }
  function Lh(e, t, r, s) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(r, s), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(r, s), t.state !== e && Mu.enqueueReplaceState(t, t.state, null);
  }
  function mr(e, t) {
    var r = t;
    if ("ref" in t) {
      r = {};
      for (var s in t)
        s !== "ref" && (r[s] = t[s]);
    }
    if (e = e.defaultProps) {
      r === t && (r = b({}, r));
      for (var u in e)
        r[u] === void 0 && (r[u] = e[u]);
    }
    return r;
  }
  function Yh(e) {
    hl(e);
  }
  function Hh(e) {
    console.error(e);
  }
  function Uh(e) {
    hl(e);
  }
  function Yl(e, t) {
    try {
      var r = e.onUncaughtError;
      r(t.value, { componentStack: t.stack });
    } catch (s) {
      setTimeout(function() {
        throw s;
      });
    }
  }
  function Bh(e, t, r) {
    try {
      var s = e.onCaughtError;
      s(r.value, {
        componentStack: r.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null
      });
    } catch (u) {
      setTimeout(function() {
        throw u;
      });
    }
  }
  function Tu(e, t, r) {
    return r = Mn(r), r.tag = 3, r.payload = { element: null }, r.callback = function() {
      Yl(e, t);
    }, r;
  }
  function qh(e) {
    return e = Mn(e), e.tag = 3, e;
  }
  function Qh(e, t, r, s) {
    var u = r.type.getDerivedStateFromError;
    if (typeof u == "function") {
      var f = s.value;
      e.payload = function() {
        return u(f);
      }, e.callback = function() {
        Bh(t, r, s);
      };
    }
    var v = r.stateNode;
    v !== null && typeof v.componentDidCatch == "function" && (e.callback = function() {
      Bh(t, r, s), typeof u != "function" && (Rn === null ? Rn = /* @__PURE__ */ new Set([this]) : Rn.add(this));
      var x = s.stack;
      this.componentDidCatch(s.value, {
        componentStack: x !== null ? x : ""
      });
    });
  }
  function U0(e, t, r, s, u) {
    if (r.flags |= 32768, s !== null && typeof s == "object" && typeof s.then == "function") {
      if (t = r.alternate, t !== null && $r(
        t,
        r,
        u,
        !0
      ), r = Jt.current, r !== null) {
        switch (r.tag) {
          case 31:
          case 13:
            return fa === null ? Kl() : r.alternate === null && rt === 0 && (rt = 3), r.flags &= -257, r.flags |= 65536, r.lanes = u, s === Sl ? r.flags |= 16384 : (t = r.updateQueue, t === null ? r.updateQueue = /* @__PURE__ */ new Set([s]) : t.add(s), $u(e, s, u)), !1;
          case 22:
            return r.flags |= 65536, s === Sl ? r.flags |= 16384 : (t = r.updateQueue, t === null ? (t = {
              transitions: null,
              markerInstances: null,
              retryQueue: /* @__PURE__ */ new Set([s])
            }, r.updateQueue = t) : (r = t.retryQueue, r === null ? t.retryQueue = /* @__PURE__ */ new Set([s]) : r.add(s)), $u(e, s, u)), !1;
        }
        throw Error(a(435, r.tag));
      }
      return $u(e, s, u), Kl(), !1;
    }
    if (Re)
      return t = Jt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = u, s !== Xc && (e = Error(a(422), { cause: s }), $i(sa(e, r)))) : (s !== Xc && (t = Error(a(423), {
        cause: s
      }), $i(
        sa(t, r)
      )), e = e.current.alternate, e.flags |= 65536, u &= -u, e.lanes |= u, s = sa(s, r), u = Tu(
        e.stateNode,
        s,
        u
      ), ru(e, u), rt !== 4 && (rt = 2)), !1;
    var f = Error(a(520), { cause: s });
    if (f = sa(f, r), yo === null ? yo = [f] : yo.push(f), rt !== 4 && (rt = 2), t === null) return !0;
    s = sa(s, r), r = t;
    do {
      switch (r.tag) {
        case 3:
          return r.flags |= 65536, e = u & -u, r.lanes |= e, e = Tu(r.stateNode, s, e), ru(r, e), !1;
        case 1:
          if (t = r.type, f = r.stateNode, (r.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || f !== null && typeof f.componentDidCatch == "function" && (Rn === null || !Rn.has(f))))
            return r.flags |= 65536, u &= -u, r.lanes |= u, u = qh(u), Qh(
              u,
              e,
              r,
              s
            ), ru(r, u), !1;
      }
      r = r.return;
    } while (r !== null);
    return !1;
  }
  var Cu = Error(a(461)), ht = !1;
  function kt(e, t, r, s) {
    t.child = e === null ? Gp(t, null, r, s) : pr(
      t,
      e.child,
      r,
      s
    );
  }
  function Ph(e, t, r, s, u) {
    r = r.render;
    var f = t.ref;
    if ("ref" in s) {
      var v = {};
      for (var x in s)
        x !== "ref" && (v[x] = s[x]);
    } else v = s;
    return cr(t), s = uu(
      e,
      t,
      r,
      v,
      f,
      u
    ), x = du(), e !== null && !ht ? (fu(e, t, u), en(e, t, u)) : (Re && x && Vc(t), t.flags |= 1, kt(e, t, s, u), t.child);
  }
  function Fh(e, t, r, s, u) {
    if (e === null) {
      var f = r.type;
      return typeof f == "function" && !Qc(f) && f.defaultProps === void 0 && r.compare === null ? (t.tag = 15, t.type = f, Vh(
        e,
        t,
        f,
        s,
        u
      )) : (e = bl(
        r.type,
        null,
        s,
        t,
        t.mode,
        u
      ), e.ref = t.ref, e.return = t, t.child = e);
    }
    if (f = e.child, !Yu(e, u)) {
      var v = f.memoizedProps;
      if (r = r.compare, r = r !== null ? r : Wi, r(v, s) && e.ref === t.ref)
        return en(e, t, u);
    }
    return t.flags |= 1, e = Za(f, s), e.ref = t.ref, e.return = t, t.child = e;
  }
  function Vh(e, t, r, s, u) {
    if (e !== null) {
      var f = e.memoizedProps;
      if (Wi(f, s) && e.ref === t.ref)
        if (ht = !1, t.pendingProps = s = f, Yu(e, u))
          (e.flags & 131072) !== 0 && (ht = !0);
        else
          return t.lanes = e.lanes, en(e, t, u);
    }
    return Nu(
      e,
      t,
      r,
      s,
      u
    );
  }
  function Gh(e, t, r, s) {
    var u = s.children, f = e !== null ? e.memoizedState : null;
    if (e === null && t.stateNode === null && (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), s.mode === "hidden") {
      if ((t.flags & 128) !== 0) {
        if (f = f !== null ? f.baseLanes | r : r, e !== null) {
          for (s = t.child = e.child, u = 0; s !== null; )
            u = u | s.lanes | s.childLanes, s = s.sibling;
          s = u & ~f;
        } else s = 0, t.child = null;
        return Xh(
          e,
          t,
          f,
          r,
          s
        );
      }
      if ((r & 536870912) !== 0)
        t.memoizedState = { baseLanes: 0, cachePool: null }, e !== null && _l(
          t,
          f !== null ? f.cachePool : null
        ), f !== null ? Kp(t, f) : ou(), Wp(t);
      else
        return s = t.lanes = 536870912, Xh(
          e,
          t,
          f !== null ? f.baseLanes | r : r,
          r,
          s
        );
    } else
      f !== null ? (_l(t, f.cachePool), Kp(t, f), Nn(), t.memoizedState = null) : (e !== null && _l(t, null), ou(), Nn());
    return kt(e, t, u, r), t.child;
  }
  function fo(e, t) {
    return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), t.sibling;
  }
  function Xh(e, t, r, s, u) {
    var f = eu();
    return f = f === null ? null : { parent: ft._currentValue, pool: f }, t.memoizedState = {
      baseLanes: r,
      cachePool: f
    }, e !== null && _l(t, null), ou(), Wp(t), e !== null && $r(e, t, s, !0), t.childLanes = u, null;
  }
  function Hl(e, t) {
    return t = Bl(
      { mode: t.mode, children: t.children },
      e.mode
    ), t.ref = e.ref, e.child = t, t.return = e, t;
  }
  function Zh(e, t, r) {
    return pr(t, e.child, null, r), e = Hl(t, t.pendingProps), e.flags |= 2, $t(t), t.memoizedState = null, e;
  }
  function B0(e, t, r) {
    var s = t.pendingProps, u = (t.flags & 128) !== 0;
    if (t.flags &= -129, e === null) {
      if (Re) {
        if (s.mode === "hidden")
          return e = Hl(t, s), t.lanes = 536870912, fo(null, e);
        if (su(t), (e = Ie) ? (e = og(
          e,
          da
        ), e = e !== null && e.data === "&" ? e : null, e !== null && (t.memoizedState = {
          dehydrated: e,
          treeContext: _n !== null ? { id: Oa, overflow: ja } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, r = Op(e), r.return = t, t.child = r, wt = t, Ie = null)) : e = null, e === null) throw Sn(t);
        return t.lanes = 536870912, null;
      }
      return Hl(t, s);
    }
    var f = e.memoizedState;
    if (f !== null) {
      var v = f.dehydrated;
      if (su(t), u)
        if (t.flags & 256)
          t.flags &= -257, t = Zh(
            e,
            t,
            r
          );
        else if (t.memoizedState !== null)
          t.child = e.child, t.flags |= 128, t = null;
        else throw Error(a(558));
      else if (ht || $r(e, t, r, !1), u = (r & e.childLanes) !== 0, ht || u) {
        if (s = We, s !== null && (v = Hf(s, r), v !== 0 && v !== f.retryLane))
          throw f.retryLane = v, ir(e, v), qt(s, e, v), Cu;
        Kl(), t = Zh(
          e,
          t,
          r
        );
      } else
        e = f.treeContext, Ie = pa(v.nextSibling), wt = t, Re = !0, kn = null, da = !1, e !== null && Rp(t, e), t = Hl(t, s), t.flags |= 4096;
      return t;
    }
    return e = Za(e.child, {
      mode: s.mode,
      children: s.children
    }), e.ref = t.ref, t.child = e, e.return = t, e;
  }
  function Ul(e, t) {
    var r = t.ref;
    if (r === null)
      e !== null && e.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof r != "function" && typeof r != "object")
        throw Error(a(284));
      (e === null || e.ref !== r) && (t.flags |= 4194816);
    }
  }
  function Nu(e, t, r, s, u) {
    return cr(t), r = uu(
      e,
      t,
      r,
      s,
      void 0,
      u
    ), s = du(), e !== null && !ht ? (fu(e, t, u), en(e, t, u)) : (Re && s && Vc(t), t.flags |= 1, kt(e, t, r, u), t.child);
  }
  function Kh(e, t, r, s, u, f) {
    return cr(t), t.updateQueue = null, r = Jp(
      t,
      s,
      r,
      u
    ), Ip(e), s = du(), e !== null && !ht ? (fu(e, t, f), en(e, t, f)) : (Re && s && Vc(t), t.flags |= 1, kt(e, t, r, f), t.child);
  }
  function Wh(e, t, r, s, u) {
    if (cr(t), t.stateNode === null) {
      var f = Kr, v = r.contextType;
      typeof v == "object" && v !== null && (f = _t(v)), f = new r(s, f), t.memoizedState = f.state !== null && f.state !== void 0 ? f.state : null, f.updater = Mu, t.stateNode = f, f._reactInternals = t, f = t.stateNode, f.props = s, f.state = t.memoizedState, f.refs = {}, au(t), v = r.contextType, f.context = typeof v == "object" && v !== null ? _t(v) : Kr, f.state = t.memoizedState, v = r.getDerivedStateFromProps, typeof v == "function" && (Eu(
        t,
        r,
        v,
        s
      ), f.state = t.memoizedState), typeof r.getDerivedStateFromProps == "function" || typeof f.getSnapshotBeforeUpdate == "function" || typeof f.UNSAFE_componentWillMount != "function" && typeof f.componentWillMount != "function" || (v = f.state, typeof f.componentWillMount == "function" && f.componentWillMount(), typeof f.UNSAFE_componentWillMount == "function" && f.UNSAFE_componentWillMount(), v !== f.state && Mu.enqueueReplaceState(f, f.state, null), oo(t, s, f, u), io(), f.state = t.memoizedState), typeof f.componentDidMount == "function" && (t.flags |= 4194308), s = !0;
    } else if (e === null) {
      f = t.stateNode;
      var x = t.memoizedProps, E = mr(r, x);
      f.props = E;
      var z = f.context, V = r.contextType;
      v = Kr, typeof V == "object" && V !== null && (v = _t(V));
      var X = r.getDerivedStateFromProps;
      V = typeof X == "function" || typeof f.getSnapshotBeforeUpdate == "function", x = t.pendingProps !== x, V || typeof f.UNSAFE_componentWillReceiveProps != "function" && typeof f.componentWillReceiveProps != "function" || (x || z !== v) && Lh(
        t,
        f,
        s,
        v
      ), En = !1;
      var Y = t.memoizedState;
      f.state = Y, oo(t, s, f, u), io(), z = t.memoizedState, x || Y !== z || En ? (typeof X == "function" && (Eu(
        t,
        r,
        X,
        s
      ), z = t.memoizedState), (E = En || zh(
        t,
        r,
        E,
        s,
        Y,
        z,
        v
      )) ? (V || typeof f.UNSAFE_componentWillMount != "function" && typeof f.componentWillMount != "function" || (typeof f.componentWillMount == "function" && f.componentWillMount(), typeof f.UNSAFE_componentWillMount == "function" && f.UNSAFE_componentWillMount()), typeof f.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof f.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = s, t.memoizedState = z), f.props = s, f.state = z, f.context = v, s = E) : (typeof f.componentDidMount == "function" && (t.flags |= 4194308), s = !1);
    } else {
      f = t.stateNode, nu(e, t), v = t.memoizedProps, V = mr(r, v), f.props = V, X = t.pendingProps, Y = f.context, z = r.contextType, E = Kr, typeof z == "object" && z !== null && (E = _t(z)), x = r.getDerivedStateFromProps, (z = typeof x == "function" || typeof f.getSnapshotBeforeUpdate == "function") || typeof f.UNSAFE_componentWillReceiveProps != "function" && typeof f.componentWillReceiveProps != "function" || (v !== X || Y !== E) && Lh(
        t,
        f,
        s,
        E
      ), En = !1, Y = t.memoizedState, f.state = Y, oo(t, s, f, u), io();
      var U = t.memoizedState;
      v !== X || Y !== U || En || e !== null && e.dependencies !== null && xl(e.dependencies) ? (typeof x == "function" && (Eu(
        t,
        r,
        x,
        s
      ), U = t.memoizedState), (V = En || zh(
        t,
        r,
        V,
        s,
        Y,
        U,
        E
      ) || e !== null && e.dependencies !== null && xl(e.dependencies)) ? (z || typeof f.UNSAFE_componentWillUpdate != "function" && typeof f.componentWillUpdate != "function" || (typeof f.componentWillUpdate == "function" && f.componentWillUpdate(s, U, E), typeof f.UNSAFE_componentWillUpdate == "function" && f.UNSAFE_componentWillUpdate(
        s,
        U,
        E
      )), typeof f.componentDidUpdate == "function" && (t.flags |= 4), typeof f.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof f.componentDidUpdate != "function" || v === e.memoizedProps && Y === e.memoizedState || (t.flags |= 4), typeof f.getSnapshotBeforeUpdate != "function" || v === e.memoizedProps && Y === e.memoizedState || (t.flags |= 1024), t.memoizedProps = s, t.memoizedState = U), f.props = s, f.state = U, f.context = E, s = V) : (typeof f.componentDidUpdate != "function" || v === e.memoizedProps && Y === e.memoizedState || (t.flags |= 4), typeof f.getSnapshotBeforeUpdate != "function" || v === e.memoizedProps && Y === e.memoizedState || (t.flags |= 1024), s = !1);
    }
    return f = s, Ul(e, t), s = (t.flags & 128) !== 0, f || s ? (f = t.stateNode, r = s && typeof r.getDerivedStateFromError != "function" ? null : f.render(), t.flags |= 1, e !== null && s ? (t.child = pr(
      t,
      e.child,
      null,
      u
    ), t.child = pr(
      t,
      null,
      r,
      u
    )) : kt(e, t, r, u), t.memoizedState = f.state, e = t.child) : e = en(
      e,
      t,
      u
    ), e;
  }
  function Ih(e, t, r, s) {
    return lr(), t.flags |= 256, kt(e, t, r, s), t.child;
  }
  var Ou = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null
  };
  function ju(e) {
    return { baseLanes: e, cachePool: Bp() };
  }
  function Au(e, t, r) {
    return e = e !== null ? e.childLanes & ~r : 0, t && (e |= ta), e;
  }
  function Jh(e, t, r) {
    var s = t.pendingProps, u = !1, f = (t.flags & 128) !== 0, v;
    if ((v = f) || (v = e !== null && e.memoizedState === null ? !1 : (st.current & 2) !== 0), v && (u = !0, t.flags &= -129), v = (t.flags & 32) !== 0, t.flags &= -33, e === null) {
      if (Re) {
        if (u ? Cn(t) : Nn(), (e = Ie) ? (e = og(
          e,
          da
        ), e = e !== null && e.data !== "&" ? e : null, e !== null && (t.memoizedState = {
          dehydrated: e,
          treeContext: _n !== null ? { id: Oa, overflow: ja } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, r = Op(e), r.return = t, t.child = r, wt = t, Ie = null)) : e = null, e === null) throw Sn(t);
        return md(e) ? t.lanes = 32 : t.lanes = 536870912, null;
      }
      var x = s.children;
      return s = s.fallback, u ? (Nn(), u = t.mode, x = Bl(
        { mode: "hidden", children: x },
        u
      ), s = or(
        s,
        u,
        r,
        null
      ), x.return = t, s.return = t, x.sibling = s, t.child = x, s = t.child, s.memoizedState = ju(r), s.childLanes = Au(
        e,
        v,
        r
      ), t.memoizedState = Ou, fo(null, s)) : (Cn(t), Ru(t, x));
    }
    var E = e.memoizedState;
    if (E !== null && (x = E.dehydrated, x !== null)) {
      if (f)
        t.flags & 256 ? (Cn(t), t.flags &= -257, t = zu(
          e,
          t,
          r
        )) : t.memoizedState !== null ? (Nn(), t.child = e.child, t.flags |= 128, t = null) : (Nn(), x = s.fallback, u = t.mode, s = Bl(
          { mode: "visible", children: s.children },
          u
        ), x = or(
          x,
          u,
          r,
          null
        ), x.flags |= 2, s.return = t, x.return = t, s.sibling = x, t.child = s, pr(
          t,
          e.child,
          null,
          r
        ), s = t.child, s.memoizedState = ju(r), s.childLanes = Au(
          e,
          v,
          r
        ), t.memoizedState = Ou, t = fo(null, s));
      else if (Cn(t), md(x)) {
        if (v = x.nextSibling && x.nextSibling.dataset, v) var z = v.dgst;
        v = z, s = Error(a(419)), s.stack = "", s.digest = v, $i({ value: s, source: null, stack: null }), t = zu(
          e,
          t,
          r
        );
      } else if (ht || $r(e, t, r, !1), v = (r & e.childLanes) !== 0, ht || v) {
        if (v = We, v !== null && (s = Hf(v, r), s !== 0 && s !== E.retryLane))
          throw E.retryLane = s, ir(e, s), qt(v, e, s), Cu;
        hd(x) || Kl(), t = zu(
          e,
          t,
          r
        );
      } else
        hd(x) ? (t.flags |= 192, t.child = e.child, t = null) : (e = E.treeContext, Ie = pa(
          x.nextSibling
        ), wt = t, Re = !0, kn = null, da = !1, e !== null && Rp(t, e), t = Ru(
          t,
          s.children
        ), t.flags |= 4096);
      return t;
    }
    return u ? (Nn(), x = s.fallback, u = t.mode, E = e.child, z = E.sibling, s = Za(E, {
      mode: "hidden",
      children: s.children
    }), s.subtreeFlags = E.subtreeFlags & 65011712, z !== null ? x = Za(
      z,
      x
    ) : (x = or(
      x,
      u,
      r,
      null
    ), x.flags |= 2), x.return = t, s.return = t, s.sibling = x, t.child = s, fo(null, s), s = t.child, x = e.child.memoizedState, x === null ? x = ju(r) : (u = x.cachePool, u !== null ? (E = ft._currentValue, u = u.parent !== E ? { parent: E, pool: E } : u) : u = Bp(), x = {
      baseLanes: x.baseLanes | r,
      cachePool: u
    }), s.memoizedState = x, s.childLanes = Au(
      e,
      v,
      r
    ), t.memoizedState = Ou, fo(e.child, s)) : (Cn(t), r = e.child, e = r.sibling, r = Za(r, {
      mode: "visible",
      children: s.children
    }), r.return = t, r.sibling = null, e !== null && (v = t.deletions, v === null ? (t.deletions = [e], t.flags |= 16) : v.push(e)), t.child = r, t.memoizedState = null, r);
  }
  function Ru(e, t) {
    return t = Bl(
      { mode: "visible", children: t },
      e.mode
    ), t.return = e, e.child = t;
  }
  function Bl(e, t) {
    return e = It(22, e, null, t), e.lanes = 0, e;
  }
  function zu(e, t, r) {
    return pr(t, e.child, null, r), e = Ru(
      t,
      t.pendingProps.children
    ), e.flags |= 2, t.memoizedState = null, e;
  }
  function $h(e, t, r) {
    e.lanes |= t;
    var s = e.alternate;
    s !== null && (s.lanes |= t), Wc(e.return, t, r);
  }
  function Lu(e, t, r, s, u, f) {
    var v = e.memoizedState;
    v === null ? e.memoizedState = {
      isBackwards: t,
      rendering: null,
      renderingStartTime: 0,
      last: s,
      tail: r,
      tailMode: u,
      treeForkCount: f
    } : (v.isBackwards = t, v.rendering = null, v.renderingStartTime = 0, v.last = s, v.tail = r, v.tailMode = u, v.treeForkCount = f);
  }
  function em(e, t, r) {
    var s = t.pendingProps, u = s.revealOrder, f = s.tail;
    s = s.children;
    var v = st.current, x = (v & 2) !== 0;
    if (x ? (v = v & 1 | 2, t.flags |= 128) : v &= 1, K(st, v), kt(e, t, s, r), s = Re ? Ji : 0, !x && e !== null && (e.flags & 128) !== 0)
      e: for (e = t.child; e !== null; ) {
        if (e.tag === 13)
          e.memoizedState !== null && $h(e, r, t);
        else if (e.tag === 19)
          $h(e, r, t);
        else if (e.child !== null) {
          e.child.return = e, e = e.child;
          continue;
        }
        if (e === t) break e;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t)
            break e;
          e = e.return;
        }
        e.sibling.return = e.return, e = e.sibling;
      }
    switch (u) {
      case "forwards":
        for (r = t.child, u = null; r !== null; )
          e = r.alternate, e !== null && Tl(e) === null && (u = r), r = r.sibling;
        r = u, r === null ? (u = t.child, t.child = null) : (u = r.sibling, r.sibling = null), Lu(
          t,
          !1,
          u,
          r,
          f,
          s
        );
        break;
      case "backwards":
      case "unstable_legacy-backwards":
        for (r = null, u = t.child, t.child = null; u !== null; ) {
          if (e = u.alternate, e !== null && Tl(e) === null) {
            t.child = u;
            break;
          }
          e = u.sibling, u.sibling = r, r = u, u = e;
        }
        Lu(
          t,
          !0,
          r,
          null,
          f,
          s
        );
        break;
      case "together":
        Lu(
          t,
          !1,
          null,
          null,
          void 0,
          s
        );
        break;
      default:
        t.memoizedState = null;
    }
    return t.child;
  }
  function en(e, t, r) {
    if (e !== null && (t.dependencies = e.dependencies), An |= t.lanes, (r & t.childLanes) === 0)
      if (e !== null) {
        if ($r(
          e,
          t,
          r,
          !1
        ), (r & t.childLanes) === 0)
          return null;
      } else return null;
    if (e !== null && t.child !== e.child)
      throw Error(a(153));
    if (t.child !== null) {
      for (e = t.child, r = Za(e, e.pendingProps), t.child = r, r.return = t; e.sibling !== null; )
        e = e.sibling, r = r.sibling = Za(e, e.pendingProps), r.return = t;
      r.sibling = null;
    }
    return t.child;
  }
  function Yu(e, t) {
    return (e.lanes & t) !== 0 ? !0 : (e = e.dependencies, !!(e !== null && xl(e)));
  }
  function q0(e, t, r) {
    switch (t.tag) {
      case 3:
        Ke(t, t.stateNode.containerInfo), Dn(t, ft, e.memoizedState.cache), lr();
        break;
      case 27:
      case 5:
        ee(t);
        break;
      case 4:
        Ke(t, t.stateNode.containerInfo);
        break;
      case 10:
        Dn(
          t,
          t.type,
          t.memoizedProps.value
        );
        break;
      case 31:
        if (t.memoizedState !== null)
          return t.flags |= 128, su(t), null;
        break;
      case 13:
        var s = t.memoizedState;
        if (s !== null)
          return s.dehydrated !== null ? (Cn(t), t.flags |= 128, null) : (r & t.child.childLanes) !== 0 ? Jh(e, t, r) : (Cn(t), e = en(
            e,
            t,
            r
          ), e !== null ? e.sibling : null);
        Cn(t);
        break;
      case 19:
        var u = (e.flags & 128) !== 0;
        if (s = (r & t.childLanes) !== 0, s || ($r(
          e,
          t,
          r,
          !1
        ), s = (r & t.childLanes) !== 0), u) {
          if (s)
            return em(
              e,
              t,
              r
            );
          t.flags |= 128;
        }
        if (u = t.memoizedState, u !== null && (u.rendering = null, u.tail = null, u.lastEffect = null), K(st, st.current), s) break;
        return null;
      case 22:
        return t.lanes = 0, Gh(
          e,
          t,
          r,
          t.pendingProps
        );
      case 24:
        Dn(t, ft, e.memoizedState.cache);
    }
    return en(e, t, r);
  }
  function tm(e, t, r) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps)
        ht = !0;
      else {
        if (!Yu(e, r) && (t.flags & 128) === 0)
          return ht = !1, q0(
            e,
            t,
            r
          );
        ht = (e.flags & 131072) !== 0;
      }
    else
      ht = !1, Re && (t.flags & 1048576) !== 0 && Ap(t, Ji, t.index);
    switch (t.lanes = 0, t.tag) {
      case 16:
        e: {
          var s = t.pendingProps;
          if (e = dr(t.elementType), t.type = e, typeof e == "function")
            Qc(e) ? (s = mr(e, s), t.tag = 1, t = Wh(
              null,
              t,
              e,
              s,
              r
            )) : (t.tag = 0, t = Nu(
              null,
              t,
              e,
              s,
              r
            ));
          else {
            if (e != null) {
              var u = e.$$typeof;
              if (u === P) {
                t.tag = 11, t = Ph(
                  null,
                  t,
                  e,
                  s,
                  r
                );
                break e;
              } else if (u === Z) {
                t.tag = 14, t = Fh(
                  null,
                  t,
                  e,
                  s,
                  r
                );
                break e;
              }
            }
            throw t = le(e) || e, Error(a(306, t, ""));
          }
        }
        return t;
      case 0:
        return Nu(
          e,
          t,
          t.type,
          t.pendingProps,
          r
        );
      case 1:
        return s = t.type, u = mr(
          s,
          t.pendingProps
        ), Wh(
          e,
          t,
          s,
          u,
          r
        );
      case 3:
        e: {
          if (Ke(
            t,
            t.stateNode.containerInfo
          ), e === null) throw Error(a(387));
          s = t.pendingProps;
          var f = t.memoizedState;
          u = f.element, nu(e, t), oo(t, s, null, r);
          var v = t.memoizedState;
          if (s = v.cache, Dn(t, ft, s), s !== f.cache && Ic(
            t,
            [ft],
            r,
            !0
          ), io(), s = v.element, f.isDehydrated)
            if (f = {
              element: s,
              isDehydrated: !1,
              cache: v.cache
            }, t.updateQueue.baseState = f, t.memoizedState = f, t.flags & 256) {
              t = Ih(
                e,
                t,
                s,
                r
              );
              break e;
            } else if (s !== u) {
              u = sa(
                Error(a(424)),
                t
              ), $i(u), t = Ih(
                e,
                t,
                s,
                r
              );
              break e;
            } else
              for (e = t.stateNode.containerInfo, e.nodeType === 9 ? e = e.body : e = e.nodeName === "HTML" ? e.ownerDocument.body : e, Ie = pa(e.firstChild), wt = t, Re = !0, kn = null, da = !0, r = Gp(
                t,
                null,
                s,
                r
              ), t.child = r; r; )
                r.flags = r.flags & -3 | 4096, r = r.sibling;
          else {
            if (lr(), s === u) {
              t = en(
                e,
                t,
                r
              );
              break e;
            }
            kt(e, t, s, r);
          }
          t = t.child;
        }
        return t;
      case 26:
        return Ul(e, t), e === null ? (r = fg(
          t.type,
          null,
          t.pendingProps,
          null
        )) ? t.memoizedState = r : Re || (r = t.type, e = t.pendingProps, s = as(
          pe.current
        ).createElement(r), s[xt] = t, s[zt] = e, St(s, r, e), bt(s), t.stateNode = s) : t.memoizedState = fg(
          t.type,
          e.memoizedProps,
          t.pendingProps,
          e.memoizedState
        ), null;
      case 27:
        return ee(t), e === null && Re && (s = t.stateNode = cg(
          t.type,
          t.pendingProps,
          pe.current
        ), wt = t, da = !0, u = Ie, Hn(t.type) ? (gd = u, Ie = pa(s.firstChild)) : Ie = u), kt(
          e,
          t,
          t.pendingProps.children,
          r
        ), Ul(e, t), e === null && (t.flags |= 4194304), t.child;
      case 5:
        return e === null && Re && ((u = s = Ie) && (s = vx(
          s,
          t.type,
          t.pendingProps,
          da
        ), s !== null ? (t.stateNode = s, wt = t, Ie = pa(s.firstChild), da = !1, u = !0) : u = !1), u || Sn(t)), ee(t), u = t.type, f = t.pendingProps, v = e !== null ? e.memoizedProps : null, s = f.children, dd(u, f) ? s = null : v !== null && dd(u, v) && (t.flags |= 32), t.memoizedState !== null && (u = uu(
          e,
          t,
          j0,
          null,
          null,
          r
        ), Mo._currentValue = u), Ul(e, t), kt(e, t, s, r), t.child;
      case 6:
        return e === null && Re && ((e = r = Ie) && (r = bx(
          r,
          t.pendingProps,
          da
        ), r !== null ? (t.stateNode = r, wt = t, Ie = null, e = !0) : e = !1), e || Sn(t)), null;
      case 13:
        return Jh(e, t, r);
      case 4:
        return Ke(
          t,
          t.stateNode.containerInfo
        ), s = t.pendingProps, e === null ? t.child = pr(
          t,
          null,
          s,
          r
        ) : kt(e, t, s, r), t.child;
      case 11:
        return Ph(
          e,
          t,
          t.type,
          t.pendingProps,
          r
        );
      case 7:
        return kt(
          e,
          t,
          t.pendingProps,
          r
        ), t.child;
      case 8:
        return kt(
          e,
          t,
          t.pendingProps.children,
          r
        ), t.child;
      case 12:
        return kt(
          e,
          t,
          t.pendingProps.children,
          r
        ), t.child;
      case 10:
        return s = t.pendingProps, Dn(t, t.type, s.value), kt(e, t, s.children, r), t.child;
      case 9:
        return u = t.type._context, s = t.pendingProps.children, cr(t), u = _t(u), s = s(u), t.flags |= 1, kt(e, t, s, r), t.child;
      case 14:
        return Fh(
          e,
          t,
          t.type,
          t.pendingProps,
          r
        );
      case 15:
        return Vh(
          e,
          t,
          t.type,
          t.pendingProps,
          r
        );
      case 19:
        return em(e, t, r);
      case 31:
        return B0(e, t, r);
      case 22:
        return Gh(
          e,
          t,
          r,
          t.pendingProps
        );
      case 24:
        return cr(t), s = _t(ft), e === null ? (u = eu(), u === null && (u = We, f = Jc(), u.pooledCache = f, f.refCount++, f !== null && (u.pooledCacheLanes |= r), u = f), t.memoizedState = { parent: s, cache: u }, au(t), Dn(t, ft, u)) : ((e.lanes & r) !== 0 && (nu(e, t), oo(t, null, null, r), io()), u = e.memoizedState, f = t.memoizedState, u.parent !== s ? (u = { parent: s, cache: s }, t.memoizedState = u, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = u), Dn(t, ft, s)) : (s = f.cache, Dn(t, ft, s), s !== u.cache && Ic(
          t,
          [ft],
          r,
          !0
        ))), kt(
          e,
          t,
          t.pendingProps.children,
          r
        ), t.child;
      case 29:
        throw t.pendingProps;
    }
    throw Error(a(156, t.tag));
  }
  function tn(e) {
    e.flags |= 4;
  }
  function Hu(e, t, r, s, u) {
    if ((t = (e.mode & 32) !== 0) && (t = !1), t) {
      if (e.flags |= 16777216, (u & 335544128) === u)
        if (e.stateNode.complete) e.flags |= 8192;
        else if (Tm()) e.flags |= 8192;
        else
          throw fr = Sl, tu;
    } else e.flags &= -16777217;
  }
  function am(e, t) {
    if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0)
      e.flags &= -16777217;
    else if (e.flags |= 16777216, !vg(t))
      if (Tm()) e.flags |= 8192;
      else
        throw fr = Sl, tu;
  }
  function ql(e, t) {
    t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag !== 22 ? zf() : 536870912, e.lanes |= t, di |= t);
  }
  function po(e, t) {
    if (!Re)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var r = null; t !== null; )
            t.alternate !== null && (r = t), t = t.sibling;
          r === null ? e.tail = null : r.sibling = null;
          break;
        case "collapsed":
          r = e.tail;
          for (var s = null; r !== null; )
            r.alternate !== null && (s = r), r = r.sibling;
          s === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : s.sibling = null;
      }
  }
  function Je(e) {
    var t = e.alternate !== null && e.alternate.child === e.child, r = 0, s = 0;
    if (t)
      for (var u = e.child; u !== null; )
        r |= u.lanes | u.childLanes, s |= u.subtreeFlags & 65011712, s |= u.flags & 65011712, u.return = e, u = u.sibling;
    else
      for (u = e.child; u !== null; )
        r |= u.lanes | u.childLanes, s |= u.subtreeFlags, s |= u.flags, u.return = e, u = u.sibling;
    return e.subtreeFlags |= s, e.childLanes = r, t;
  }
  function Q0(e, t, r) {
    var s = t.pendingProps;
    switch (Gc(t), t.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return Je(t), null;
      case 1:
        return Je(t), null;
      case 3:
        return r = t.stateNode, s = null, e !== null && (s = e.memoizedState.cache), t.memoizedState.cache !== s && (t.flags |= 2048), Ia(ft), ze(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (Jr(t) ? tn(t) : e === null || e.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, Zc())), Je(t), null;
      case 26:
        var u = t.type, f = t.memoizedState;
        return e === null ? (tn(t), f !== null ? (Je(t), am(t, f)) : (Je(t), Hu(
          t,
          u,
          null,
          s,
          r
        ))) : f ? f !== e.memoizedState ? (tn(t), Je(t), am(t, f)) : (Je(t), t.flags &= -16777217) : (e = e.memoizedProps, e !== s && tn(t), Je(t), Hu(
          t,
          u,
          e,
          s,
          r
        )), null;
      case 27:
        if (ve(t), r = pe.current, u = t.type, e !== null && t.stateNode != null)
          e.memoizedProps !== s && tn(t);
        else {
          if (!s) {
            if (t.stateNode === null)
              throw Error(a(166));
            return Je(t), null;
          }
          e = I.current, Jr(t) ? zp(t) : (e = cg(u, s, r), t.stateNode = e, tn(t));
        }
        return Je(t), null;
      case 5:
        if (ve(t), u = t.type, e !== null && t.stateNode != null)
          e.memoizedProps !== s && tn(t);
        else {
          if (!s) {
            if (t.stateNode === null)
              throw Error(a(166));
            return Je(t), null;
          }
          if (f = I.current, Jr(t))
            zp(t);
          else {
            var v = as(
              pe.current
            );
            switch (f) {
              case 1:
                f = v.createElementNS(
                  "http://www.w3.org/2000/svg",
                  u
                );
                break;
              case 2:
                f = v.createElementNS(
                  "http://www.w3.org/1998/Math/MathML",
                  u
                );
                break;
              default:
                switch (u) {
                  case "svg":
                    f = v.createElementNS(
                      "http://www.w3.org/2000/svg",
                      u
                    );
                    break;
                  case "math":
                    f = v.createElementNS(
                      "http://www.w3.org/1998/Math/MathML",
                      u
                    );
                    break;
                  case "script":
                    f = v.createElement("div"), f.innerHTML = "<script><\/script>", f = f.removeChild(
                      f.firstChild
                    );
                    break;
                  case "select":
                    f = typeof s.is == "string" ? v.createElement("select", {
                      is: s.is
                    }) : v.createElement("select"), s.multiple ? f.multiple = !0 : s.size && (f.size = s.size);
                    break;
                  default:
                    f = typeof s.is == "string" ? v.createElement(u, { is: s.is }) : v.createElement(u);
                }
            }
            f[xt] = t, f[zt] = s;
            e: for (v = t.child; v !== null; ) {
              if (v.tag === 5 || v.tag === 6)
                f.appendChild(v.stateNode);
              else if (v.tag !== 4 && v.tag !== 27 && v.child !== null) {
                v.child.return = v, v = v.child;
                continue;
              }
              if (v === t) break e;
              for (; v.sibling === null; ) {
                if (v.return === null || v.return === t)
                  break e;
                v = v.return;
              }
              v.sibling.return = v.return, v = v.sibling;
            }
            t.stateNode = f;
            e: switch (St(f, u, s), u) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                s = !!s.autoFocus;
                break e;
              case "img":
                s = !0;
                break e;
              default:
                s = !1;
            }
            s && tn(t);
          }
        }
        return Je(t), Hu(
          t,
          t.type,
          e === null ? null : e.memoizedProps,
          t.pendingProps,
          r
        ), null;
      case 6:
        if (e && t.stateNode != null)
          e.memoizedProps !== s && tn(t);
        else {
          if (typeof s != "string" && t.stateNode === null)
            throw Error(a(166));
          if (e = pe.current, Jr(t)) {
            if (e = t.stateNode, r = t.memoizedProps, s = null, u = wt, u !== null)
              switch (u.tag) {
                case 27:
                case 5:
                  s = u.memoizedProps;
              }
            e[xt] = t, e = !!(e.nodeValue === r || s !== null && s.suppressHydrationWarning === !0 || Jm(e.nodeValue, r)), e || Sn(t, !0);
          } else
            e = as(e).createTextNode(
              s
            ), e[xt] = t, t.stateNode = e;
        }
        return Je(t), null;
      case 31:
        if (r = t.memoizedState, e === null || e.memoizedState !== null) {
          if (s = Jr(t), r !== null) {
            if (e === null) {
              if (!s) throw Error(a(318));
              if (e = t.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(a(557));
              e[xt] = t;
            } else
              lr(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            Je(t), e = !1;
          } else
            r = Zc(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = r), e = !0;
          if (!e)
            return t.flags & 256 ? ($t(t), t) : ($t(t), null);
          if ((t.flags & 128) !== 0)
            throw Error(a(558));
        }
        return Je(t), null;
      case 13:
        if (s = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
          if (u = Jr(t), s !== null && s.dehydrated !== null) {
            if (e === null) {
              if (!u) throw Error(a(318));
              if (u = t.memoizedState, u = u !== null ? u.dehydrated : null, !u) throw Error(a(317));
              u[xt] = t;
            } else
              lr(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            Je(t), u = !1;
          } else
            u = Zc(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = u), u = !0;
          if (!u)
            return t.flags & 256 ? ($t(t), t) : ($t(t), null);
        }
        return $t(t), (t.flags & 128) !== 0 ? (t.lanes = r, t) : (r = s !== null, e = e !== null && e.memoizedState !== null, r && (s = t.child, u = null, s.alternate !== null && s.alternate.memoizedState !== null && s.alternate.memoizedState.cachePool !== null && (u = s.alternate.memoizedState.cachePool.pool), f = null, s.memoizedState !== null && s.memoizedState.cachePool !== null && (f = s.memoizedState.cachePool.pool), f !== u && (s.flags |= 2048)), r !== e && r && (t.child.flags |= 8192), ql(t, t.updateQueue), Je(t), null);
      case 4:
        return ze(), e === null && od(t.stateNode.containerInfo), Je(t), null;
      case 10:
        return Ia(t.type), Je(t), null;
      case 19:
        if (T(st), s = t.memoizedState, s === null) return Je(t), null;
        if (u = (t.flags & 128) !== 0, f = s.rendering, f === null)
          if (u) po(s, !1);
          else {
            if (rt !== 0 || e !== null && (e.flags & 128) !== 0)
              for (e = t.child; e !== null; ) {
                if (f = Tl(e), f !== null) {
                  for (t.flags |= 128, po(s, !1), e = f.updateQueue, t.updateQueue = e, ql(t, e), t.subtreeFlags = 0, e = r, r = t.child; r !== null; )
                    Np(r, e), r = r.sibling;
                  return K(
                    st,
                    st.current & 1 | 2
                  ), Re && Ka(t, s.treeForkCount), t.child;
                }
                e = e.sibling;
              }
            s.tail !== null && et() > Gl && (t.flags |= 128, u = !0, po(s, !1), t.lanes = 4194304);
          }
        else {
          if (!u)
            if (e = Tl(f), e !== null) {
              if (t.flags |= 128, u = !0, e = e.updateQueue, t.updateQueue = e, ql(t, e), po(s, !0), s.tail === null && s.tailMode === "hidden" && !f.alternate && !Re)
                return Je(t), null;
            } else
              2 * et() - s.renderingStartTime > Gl && r !== 536870912 && (t.flags |= 128, u = !0, po(s, !1), t.lanes = 4194304);
          s.isBackwards ? (f.sibling = t.child, t.child = f) : (e = s.last, e !== null ? e.sibling = f : t.child = f, s.last = f);
        }
        return s.tail !== null ? (e = s.tail, s.rendering = e, s.tail = e.sibling, s.renderingStartTime = et(), e.sibling = null, r = st.current, K(
          st,
          u ? r & 1 | 2 : r & 1
        ), Re && Ka(t, s.treeForkCount), e) : (Je(t), null);
      case 22:
      case 23:
        return $t(t), lu(), s = t.memoizedState !== null, e !== null ? e.memoizedState !== null !== s && (t.flags |= 8192) : s && (t.flags |= 8192), s ? (r & 536870912) !== 0 && (t.flags & 128) === 0 && (Je(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Je(t), r = t.updateQueue, r !== null && ql(t, r.retryQueue), r = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (r = e.memoizedState.cachePool.pool), s = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (s = t.memoizedState.cachePool.pool), s !== r && (t.flags |= 2048), e !== null && T(ur), null;
      case 24:
        return r = null, e !== null && (r = e.memoizedState.cache), t.memoizedState.cache !== r && (t.flags |= 2048), Ia(ft), Je(t), null;
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(a(156, t.tag));
  }
  function P0(e, t) {
    switch (Gc(t), t.tag) {
      case 1:
        return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 3:
        return Ia(ft), ze(), e = t.flags, (e & 65536) !== 0 && (e & 128) === 0 ? (t.flags = e & -65537 | 128, t) : null;
      case 26:
      case 27:
      case 5:
        return ve(t), null;
      case 31:
        if (t.memoizedState !== null) {
          if ($t(t), t.alternate === null)
            throw Error(a(340));
          lr();
        }
        return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 13:
        if ($t(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
          if (t.alternate === null)
            throw Error(a(340));
          lr();
        }
        return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 19:
        return T(st), null;
      case 4:
        return ze(), null;
      case 10:
        return Ia(t.type), null;
      case 22:
      case 23:
        return $t(t), lu(), e !== null && T(ur), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 24:
        return Ia(ft), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function nm(e, t) {
    switch (Gc(t), t.tag) {
      case 3:
        Ia(ft), ze();
        break;
      case 26:
      case 27:
      case 5:
        ve(t);
        break;
      case 4:
        ze();
        break;
      case 31:
        t.memoizedState !== null && $t(t);
        break;
      case 13:
        $t(t);
        break;
      case 19:
        T(st);
        break;
      case 10:
        Ia(t.type);
        break;
      case 22:
      case 23:
        $t(t), lu(), e !== null && T(ur);
        break;
      case 24:
        Ia(ft);
    }
  }
  function ho(e, t) {
    try {
      var r = t.updateQueue, s = r !== null ? r.lastEffect : null;
      if (s !== null) {
        var u = s.next;
        r = u;
        do {
          if ((r.tag & e) === e) {
            s = void 0;
            var f = r.create, v = r.inst;
            s = f(), v.destroy = s;
          }
          r = r.next;
        } while (r !== u);
      }
    } catch (x) {
      Pe(t, t.return, x);
    }
  }
  function On(e, t, r) {
    try {
      var s = t.updateQueue, u = s !== null ? s.lastEffect : null;
      if (u !== null) {
        var f = u.next;
        s = f;
        do {
          if ((s.tag & e) === e) {
            var v = s.inst, x = v.destroy;
            if (x !== void 0) {
              v.destroy = void 0, u = t;
              var E = r, z = x;
              try {
                z();
              } catch (V) {
                Pe(
                  u,
                  E,
                  V
                );
              }
            }
          }
          s = s.next;
        } while (s !== f);
      }
    } catch (V) {
      Pe(t, t.return, V);
    }
  }
  function rm(e) {
    var t = e.updateQueue;
    if (t !== null) {
      var r = e.stateNode;
      try {
        Zp(t, r);
      } catch (s) {
        Pe(e, e.return, s);
      }
    }
  }
  function im(e, t, r) {
    r.props = mr(
      e.type,
      e.memoizedProps
    ), r.state = e.memoizedState;
    try {
      r.componentWillUnmount();
    } catch (s) {
      Pe(e, t, s);
    }
  }
  function mo(e, t) {
    try {
      var r = e.ref;
      if (r !== null) {
        switch (e.tag) {
          case 26:
          case 27:
          case 5:
            var s = e.stateNode;
            break;
          case 30:
            s = e.stateNode;
            break;
          default:
            s = e.stateNode;
        }
        typeof r == "function" ? e.refCleanup = r(s) : r.current = s;
      }
    } catch (u) {
      Pe(e, t, u);
    }
  }
  function Aa(e, t) {
    var r = e.ref, s = e.refCleanup;
    if (r !== null)
      if (typeof s == "function")
        try {
          s();
        } catch (u) {
          Pe(e, t, u);
        } finally {
          e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null);
        }
      else if (typeof r == "function")
        try {
          r(null);
        } catch (u) {
          Pe(e, t, u);
        }
      else r.current = null;
  }
  function om(e) {
    var t = e.type, r = e.memoizedProps, s = e.stateNode;
    try {
      e: switch (t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          r.autoFocus && s.focus();
          break e;
        case "img":
          r.src ? s.src = r.src : r.srcSet && (s.srcset = r.srcSet);
      }
    } catch (u) {
      Pe(e, e.return, u);
    }
  }
  function Uu(e, t, r) {
    try {
      var s = e.stateNode;
      dx(s, e.type, r, t), s[zt] = t;
    } catch (u) {
      Pe(e, e.return, u);
    }
  }
  function lm(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && Hn(e.type) || e.tag === 4;
  }
  function Bu(e) {
    e: for (; ; ) {
      for (; e.sibling === null; ) {
        if (e.return === null || lm(e.return)) return null;
        e = e.return;
      }
      for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
        if (e.tag === 27 && Hn(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue e;
        e.child.return = e, e = e.child;
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function qu(e, t, r) {
    var s = e.tag;
    if (s === 5 || s === 6)
      e = e.stateNode, t ? (r.nodeType === 9 ? r.body : r.nodeName === "HTML" ? r.ownerDocument.body : r).insertBefore(e, t) : (t = r.nodeType === 9 ? r.body : r.nodeName === "HTML" ? r.ownerDocument.body : r, t.appendChild(e), r = r._reactRootContainer, r != null || t.onclick !== null || (t.onclick = Ga));
    else if (s !== 4 && (s === 27 && Hn(e.type) && (r = e.stateNode, t = null), e = e.child, e !== null))
      for (qu(e, t, r), e = e.sibling; e !== null; )
        qu(e, t, r), e = e.sibling;
  }
  function Ql(e, t, r) {
    var s = e.tag;
    if (s === 5 || s === 6)
      e = e.stateNode, t ? r.insertBefore(e, t) : r.appendChild(e);
    else if (s !== 4 && (s === 27 && Hn(e.type) && (r = e.stateNode), e = e.child, e !== null))
      for (Ql(e, t, r), e = e.sibling; e !== null; )
        Ql(e, t, r), e = e.sibling;
  }
  function sm(e) {
    var t = e.stateNode, r = e.memoizedProps;
    try {
      for (var s = e.type, u = t.attributes; u.length; )
        t.removeAttributeNode(u[0]);
      St(t, s, r), t[xt] = e, t[zt] = r;
    } catch (f) {
      Pe(e, e.return, f);
    }
  }
  var an = !1, mt = !1, Qu = !1, cm = typeof WeakSet == "function" ? WeakSet : Set, yt = null;
  function F0(e, t) {
    if (e = e.containerInfo, cd = cs, e = wp(e), zc(e)) {
      if ("selectionStart" in e)
        var r = {
          start: e.selectionStart,
          end: e.selectionEnd
        };
      else
        e: {
          r = (r = e.ownerDocument) && r.defaultView || window;
          var s = r.getSelection && r.getSelection();
          if (s && s.rangeCount !== 0) {
            r = s.anchorNode;
            var u = s.anchorOffset, f = s.focusNode;
            s = s.focusOffset;
            try {
              r.nodeType, f.nodeType;
            } catch {
              r = null;
              break e;
            }
            var v = 0, x = -1, E = -1, z = 0, V = 0, X = e, Y = null;
            t: for (; ; ) {
              for (var U; X !== r || u !== 0 && X.nodeType !== 3 || (x = v + u), X !== f || s !== 0 && X.nodeType !== 3 || (E = v + s), X.nodeType === 3 && (v += X.nodeValue.length), (U = X.firstChild) !== null; )
                Y = X, X = U;
              for (; ; ) {
                if (X === e) break t;
                if (Y === r && ++z === u && (x = v), Y === f && ++V === s && (E = v), (U = X.nextSibling) !== null) break;
                X = Y, Y = X.parentNode;
              }
              X = U;
            }
            r = x === -1 || E === -1 ? null : { start: x, end: E };
          } else r = null;
        }
      r = r || { start: 0, end: 0 };
    } else r = null;
    for (ud = { focusedElem: e, selectionRange: r }, cs = !1, yt = t; yt !== null; )
      if (t = yt, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null)
        e.return = t, yt = e;
      else
        for (; yt !== null; ) {
          switch (t = yt, f = t.alternate, e = t.flags, t.tag) {
            case 0:
              if ((e & 4) !== 0 && (e = t.updateQueue, e = e !== null ? e.events : null, e !== null))
                for (r = 0; r < e.length; r++)
                  u = e[r], u.ref.impl = u.nextImpl;
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((e & 1024) !== 0 && f !== null) {
                e = void 0, r = t, u = f.memoizedProps, f = f.memoizedState, s = r.stateNode;
                try {
                  var ce = mr(
                    r.type,
                    u
                  );
                  e = s.getSnapshotBeforeUpdate(
                    ce,
                    f
                  ), s.__reactInternalSnapshotBeforeUpdate = e;
                } catch (ye) {
                  Pe(
                    r,
                    r.return,
                    ye
                  );
                }
              }
              break;
            case 3:
              if ((e & 1024) !== 0) {
                if (e = t.stateNode.containerInfo, r = e.nodeType, r === 9)
                  pd(e);
                else if (r === 1)
                  switch (e.nodeName) {
                    case "HEAD":
                    case "HTML":
                    case "BODY":
                      pd(e);
                      break;
                    default:
                      e.textContent = "";
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((e & 1024) !== 0) throw Error(a(163));
          }
          if (e = t.sibling, e !== null) {
            e.return = t.return, yt = e;
            break;
          }
          yt = t.return;
        }
  }
  function um(e, t, r) {
    var s = r.flags;
    switch (r.tag) {
      case 0:
      case 11:
      case 15:
        rn(e, r), s & 4 && ho(5, r);
        break;
      case 1:
        if (rn(e, r), s & 4)
          if (e = r.stateNode, t === null)
            try {
              e.componentDidMount();
            } catch (v) {
              Pe(r, r.return, v);
            }
          else {
            var u = mr(
              r.type,
              t.memoizedProps
            );
            t = t.memoizedState;
            try {
              e.componentDidUpdate(
                u,
                t,
                e.__reactInternalSnapshotBeforeUpdate
              );
            } catch (v) {
              Pe(
                r,
                r.return,
                v
              );
            }
          }
        s & 64 && rm(r), s & 512 && mo(r, r.return);
        break;
      case 3:
        if (rn(e, r), s & 64 && (e = r.updateQueue, e !== null)) {
          if (t = null, r.child !== null)
            switch (r.child.tag) {
              case 27:
              case 5:
                t = r.child.stateNode;
                break;
              case 1:
                t = r.child.stateNode;
            }
          try {
            Zp(e, t);
          } catch (v) {
            Pe(r, r.return, v);
          }
        }
        break;
      case 27:
        t === null && s & 4 && sm(r);
      case 26:
      case 5:
        rn(e, r), t === null && s & 4 && om(r), s & 512 && mo(r, r.return);
        break;
      case 12:
        rn(e, r);
        break;
      case 31:
        rn(e, r), s & 4 && pm(e, r);
        break;
      case 13:
        rn(e, r), s & 4 && hm(e, r), s & 64 && (e = r.memoizedState, e !== null && (e = e.dehydrated, e !== null && (r = $0.bind(
          null,
          r
        ), yx(e, r))));
        break;
      case 22:
        if (s = r.memoizedState !== null || an, !s) {
          t = t !== null && t.memoizedState !== null || mt, u = an;
          var f = mt;
          an = s, (mt = t) && !f ? on(
            e,
            r,
            (r.subtreeFlags & 8772) !== 0
          ) : rn(e, r), an = u, mt = f;
        }
        break;
      case 30:
        break;
      default:
        rn(e, r);
    }
  }
  function dm(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, dm(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && bc(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
  }
  var tt = null, Yt = !1;
  function nn(e, t, r) {
    for (r = r.child; r !== null; )
      fm(e, t, r), r = r.sibling;
  }
  function fm(e, t, r) {
    if (Zt && typeof Zt.onCommitFiberUnmount == "function")
      try {
        Zt.onCommitFiberUnmount($n, r);
      } catch {
      }
    switch (r.tag) {
      case 26:
        mt || Aa(r, t), nn(
          e,
          t,
          r
        ), r.memoizedState ? r.memoizedState.count-- : r.stateNode && (r = r.stateNode, r.parentNode.removeChild(r));
        break;
      case 27:
        mt || Aa(r, t);
        var s = tt, u = Yt;
        Hn(r.type) && (tt = r.stateNode, Yt = !1), nn(
          e,
          t,
          r
        ), So(r.stateNode), tt = s, Yt = u;
        break;
      case 5:
        mt || Aa(r, t);
      case 6:
        if (s = tt, u = Yt, tt = null, nn(
          e,
          t,
          r
        ), tt = s, Yt = u, tt !== null)
          if (Yt)
            try {
              (tt.nodeType === 9 ? tt.body : tt.nodeName === "HTML" ? tt.ownerDocument.body : tt).removeChild(r.stateNode);
            } catch (f) {
              Pe(
                r,
                t,
                f
              );
            }
          else
            try {
              tt.removeChild(r.stateNode);
            } catch (f) {
              Pe(
                r,
                t,
                f
              );
            }
        break;
      case 18:
        tt !== null && (Yt ? (e = tt, rg(
          e.nodeType === 9 ? e.body : e.nodeName === "HTML" ? e.ownerDocument.body : e,
          r.stateNode
        ), yi(e)) : rg(tt, r.stateNode));
        break;
      case 4:
        s = tt, u = Yt, tt = r.stateNode.containerInfo, Yt = !0, nn(
          e,
          t,
          r
        ), tt = s, Yt = u;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        On(2, r, t), mt || On(4, r, t), nn(
          e,
          t,
          r
        );
        break;
      case 1:
        mt || (Aa(r, t), s = r.stateNode, typeof s.componentWillUnmount == "function" && im(
          r,
          t,
          s
        )), nn(
          e,
          t,
          r
        );
        break;
      case 21:
        nn(
          e,
          t,
          r
        );
        break;
      case 22:
        mt = (s = mt) || r.memoizedState !== null, nn(
          e,
          t,
          r
        ), mt = s;
        break;
      default:
        nn(
          e,
          t,
          r
        );
    }
  }
  function pm(e, t) {
    if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
      e = e.dehydrated;
      try {
        yi(e);
      } catch (r) {
        Pe(t, t.return, r);
      }
    }
  }
  function hm(e, t) {
    if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null))))
      try {
        yi(e);
      } catch (r) {
        Pe(t, t.return, r);
      }
  }
  function V0(e) {
    switch (e.tag) {
      case 31:
      case 13:
      case 19:
        var t = e.stateNode;
        return t === null && (t = e.stateNode = new cm()), t;
      case 22:
        return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new cm()), t;
      default:
        throw Error(a(435, e.tag));
    }
  }
  function Pl(e, t) {
    var r = V0(e);
    t.forEach(function(s) {
      if (!r.has(s)) {
        r.add(s);
        var u = ex.bind(null, e, s);
        s.then(u, u);
      }
    });
  }
  function Ht(e, t) {
    var r = t.deletions;
    if (r !== null)
      for (var s = 0; s < r.length; s++) {
        var u = r[s], f = e, v = t, x = v;
        e: for (; x !== null; ) {
          switch (x.tag) {
            case 27:
              if (Hn(x.type)) {
                tt = x.stateNode, Yt = !1;
                break e;
              }
              break;
            case 5:
              tt = x.stateNode, Yt = !1;
              break e;
            case 3:
            case 4:
              tt = x.stateNode.containerInfo, Yt = !0;
              break e;
          }
          x = x.return;
        }
        if (tt === null) throw Error(a(160));
        fm(f, v, u), tt = null, Yt = !1, f = u.alternate, f !== null && (f.return = null), u.return = null;
      }
    if (t.subtreeFlags & 13886)
      for (t = t.child; t !== null; )
        mm(t, e), t = t.sibling;
  }
  var wa = null;
  function mm(e, t) {
    var r = e.alternate, s = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        Ht(t, e), Ut(e), s & 4 && (On(3, e, e.return), ho(3, e), On(5, e, e.return));
        break;
      case 1:
        Ht(t, e), Ut(e), s & 512 && (mt || r === null || Aa(r, r.return)), s & 64 && an && (e = e.updateQueue, e !== null && (s = e.callbacks, s !== null && (r = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = r === null ? s : r.concat(s))));
        break;
      case 26:
        var u = wa;
        if (Ht(t, e), Ut(e), s & 512 && (mt || r === null || Aa(r, r.return)), s & 4) {
          var f = r !== null ? r.memoizedState : null;
          if (s = e.memoizedState, r === null)
            if (s === null)
              if (e.stateNode === null) {
                e: {
                  s = e.type, r = e.memoizedProps, u = u.ownerDocument || u;
                  t: switch (s) {
                    case "title":
                      f = u.getElementsByTagName("title")[0], (!f || f[qi] || f[xt] || f.namespaceURI === "http://www.w3.org/2000/svg" || f.hasAttribute("itemprop")) && (f = u.createElement(s), u.head.insertBefore(
                        f,
                        u.querySelector("head > title")
                      )), St(f, s, r), f[xt] = e, bt(f), s = f;
                      break e;
                    case "link":
                      var v = mg(
                        "link",
                        "href",
                        u
                      ).get(s + (r.href || ""));
                      if (v) {
                        for (var x = 0; x < v.length; x++)
                          if (f = v[x], f.getAttribute("href") === (r.href == null || r.href === "" ? null : r.href) && f.getAttribute("rel") === (r.rel == null ? null : r.rel) && f.getAttribute("title") === (r.title == null ? null : r.title) && f.getAttribute("crossorigin") === (r.crossOrigin == null ? null : r.crossOrigin)) {
                            v.splice(x, 1);
                            break t;
                          }
                      }
                      f = u.createElement(s), St(f, s, r), u.head.appendChild(f);
                      break;
                    case "meta":
                      if (v = mg(
                        "meta",
                        "content",
                        u
                      ).get(s + (r.content || ""))) {
                        for (x = 0; x < v.length; x++)
                          if (f = v[x], f.getAttribute("content") === (r.content == null ? null : "" + r.content) && f.getAttribute("name") === (r.name == null ? null : r.name) && f.getAttribute("property") === (r.property == null ? null : r.property) && f.getAttribute("http-equiv") === (r.httpEquiv == null ? null : r.httpEquiv) && f.getAttribute("charset") === (r.charSet == null ? null : r.charSet)) {
                            v.splice(x, 1);
                            break t;
                          }
                      }
                      f = u.createElement(s), St(f, s, r), u.head.appendChild(f);
                      break;
                    default:
                      throw Error(a(468, s));
                  }
                  f[xt] = e, bt(f), s = f;
                }
                e.stateNode = s;
              } else
                gg(
                  u,
                  e.type,
                  e.stateNode
                );
            else
              e.stateNode = hg(
                u,
                s,
                e.memoizedProps
              );
          else
            f !== s ? (f === null ? r.stateNode !== null && (r = r.stateNode, r.parentNode.removeChild(r)) : f.count--, s === null ? gg(
              u,
              e.type,
              e.stateNode
            ) : hg(
              u,
              s,
              e.memoizedProps
            )) : s === null && e.stateNode !== null && Uu(
              e,
              e.memoizedProps,
              r.memoizedProps
            );
        }
        break;
      case 27:
        Ht(t, e), Ut(e), s & 512 && (mt || r === null || Aa(r, r.return)), r !== null && s & 4 && Uu(
          e,
          e.memoizedProps,
          r.memoizedProps
        );
        break;
      case 5:
        if (Ht(t, e), Ut(e), s & 512 && (mt || r === null || Aa(r, r.return)), e.flags & 32) {
          u = e.stateNode;
          try {
            Qr(u, "");
          } catch (ce) {
            Pe(e, e.return, ce);
          }
        }
        s & 4 && e.stateNode != null && (u = e.memoizedProps, Uu(
          e,
          u,
          r !== null ? r.memoizedProps : u
        )), s & 1024 && (Qu = !0);
        break;
      case 6:
        if (Ht(t, e), Ut(e), s & 4) {
          if (e.stateNode === null)
            throw Error(a(162));
          s = e.memoizedProps, r = e.stateNode;
          try {
            r.nodeValue = s;
          } catch (ce) {
            Pe(e, e.return, ce);
          }
        }
        break;
      case 3:
        if (is = null, u = wa, wa = ns(t.containerInfo), Ht(t, e), wa = u, Ut(e), s & 4 && r !== null && r.memoizedState.isDehydrated)
          try {
            yi(t.containerInfo);
          } catch (ce) {
            Pe(e, e.return, ce);
          }
        Qu && (Qu = !1, gm(e));
        break;
      case 4:
        s = wa, wa = ns(
          e.stateNode.containerInfo
        ), Ht(t, e), Ut(e), wa = s;
        break;
      case 12:
        Ht(t, e), Ut(e);
        break;
      case 31:
        Ht(t, e), Ut(e), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, Pl(e, s)));
        break;
      case 13:
        Ht(t, e), Ut(e), e.child.flags & 8192 && e.memoizedState !== null != (r !== null && r.memoizedState !== null) && (Vl = et()), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, Pl(e, s)));
        break;
      case 22:
        u = e.memoizedState !== null;
        var E = r !== null && r.memoizedState !== null, z = an, V = mt;
        if (an = z || u, mt = V || E, Ht(t, e), mt = V, an = z, Ut(e), s & 8192)
          e: for (t = e.stateNode, t._visibility = u ? t._visibility & -2 : t._visibility | 1, u && (r === null || E || an || mt || gr(e)), r = null, t = e; ; ) {
            if (t.tag === 5 || t.tag === 26) {
              if (r === null) {
                E = r = t;
                try {
                  if (f = E.stateNode, u)
                    v = f.style, typeof v.setProperty == "function" ? v.setProperty("display", "none", "important") : v.display = "none";
                  else {
                    x = E.stateNode;
                    var X = E.memoizedProps.style, Y = X != null && X.hasOwnProperty("display") ? X.display : null;
                    x.style.display = Y == null || typeof Y == "boolean" ? "" : ("" + Y).trim();
                  }
                } catch (ce) {
                  Pe(E, E.return, ce);
                }
              }
            } else if (t.tag === 6) {
              if (r === null) {
                E = t;
                try {
                  E.stateNode.nodeValue = u ? "" : E.memoizedProps;
                } catch (ce) {
                  Pe(E, E.return, ce);
                }
              }
            } else if (t.tag === 18) {
              if (r === null) {
                E = t;
                try {
                  var U = E.stateNode;
                  u ? ig(U, !0) : ig(E.stateNode, !1);
                } catch (ce) {
                  Pe(E, E.return, ce);
                }
              }
            } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === e) && t.child !== null) {
              t.child.return = t, t = t.child;
              continue;
            }
            if (t === e) break e;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === e) break e;
              r === t && (r = null), t = t.return;
            }
            r === t && (r = null), t.sibling.return = t.return, t = t.sibling;
          }
        s & 4 && (s = e.updateQueue, s !== null && (r = s.retryQueue, r !== null && (s.retryQueue = null, Pl(e, r))));
        break;
      case 19:
        Ht(t, e), Ut(e), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, Pl(e, s)));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        Ht(t, e), Ut(e);
    }
  }
  function Ut(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        for (var r, s = e.return; s !== null; ) {
          if (lm(s)) {
            r = s;
            break;
          }
          s = s.return;
        }
        if (r == null) throw Error(a(160));
        switch (r.tag) {
          case 27:
            var u = r.stateNode, f = Bu(e);
            Ql(e, f, u);
            break;
          case 5:
            var v = r.stateNode;
            r.flags & 32 && (Qr(v, ""), r.flags &= -33);
            var x = Bu(e);
            Ql(e, x, v);
            break;
          case 3:
          case 4:
            var E = r.stateNode.containerInfo, z = Bu(e);
            qu(
              e,
              z,
              E
            );
            break;
          default:
            throw Error(a(161));
        }
      } catch (V) {
        Pe(e, e.return, V);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function gm(e) {
    if (e.subtreeFlags & 1024)
      for (e = e.child; e !== null; ) {
        var t = e;
        gm(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), e = e.sibling;
      }
  }
  function rn(e, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; )
        um(e, t.alternate, t), t = t.sibling;
  }
  function gr(e) {
    for (e = e.child; e !== null; ) {
      var t = e;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          On(4, t, t.return), gr(t);
          break;
        case 1:
          Aa(t, t.return);
          var r = t.stateNode;
          typeof r.componentWillUnmount == "function" && im(
            t,
            t.return,
            r
          ), gr(t);
          break;
        case 27:
          So(t.stateNode);
        case 26:
        case 5:
          Aa(t, t.return), gr(t);
          break;
        case 22:
          t.memoizedState === null && gr(t);
          break;
        case 30:
          gr(t);
          break;
        default:
          gr(t);
      }
      e = e.sibling;
    }
  }
  function on(e, t, r) {
    for (r = r && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
      var s = t.alternate, u = e, f = t, v = f.flags;
      switch (f.tag) {
        case 0:
        case 11:
        case 15:
          on(
            u,
            f,
            r
          ), ho(4, f);
          break;
        case 1:
          if (on(
            u,
            f,
            r
          ), s = f, u = s.stateNode, typeof u.componentDidMount == "function")
            try {
              u.componentDidMount();
            } catch (z) {
              Pe(s, s.return, z);
            }
          if (s = f, u = s.updateQueue, u !== null) {
            var x = s.stateNode;
            try {
              var E = u.shared.hiddenCallbacks;
              if (E !== null)
                for (u.shared.hiddenCallbacks = null, u = 0; u < E.length; u++)
                  Xp(E[u], x);
            } catch (z) {
              Pe(s, s.return, z);
            }
          }
          r && v & 64 && rm(f), mo(f, f.return);
          break;
        case 27:
          sm(f);
        case 26:
        case 5:
          on(
            u,
            f,
            r
          ), r && s === null && v & 4 && om(f), mo(f, f.return);
          break;
        case 12:
          on(
            u,
            f,
            r
          );
          break;
        case 31:
          on(
            u,
            f,
            r
          ), r && v & 4 && pm(u, f);
          break;
        case 13:
          on(
            u,
            f,
            r
          ), r && v & 4 && hm(u, f);
          break;
        case 22:
          f.memoizedState === null && on(
            u,
            f,
            r
          ), mo(f, f.return);
          break;
        case 30:
          break;
        default:
          on(
            u,
            f,
            r
          );
      }
      t = t.sibling;
    }
  }
  function Pu(e, t) {
    var r = null;
    e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (r = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== r && (e != null && e.refCount++, r != null && eo(r));
  }
  function Fu(e, t) {
    e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && eo(e));
  }
  function _a(e, t, r, s) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; )
        vm(
          e,
          t,
          r,
          s
        ), t = t.sibling;
  }
  function vm(e, t, r, s) {
    var u = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        _a(
          e,
          t,
          r,
          s
        ), u & 2048 && ho(9, t);
        break;
      case 1:
        _a(
          e,
          t,
          r,
          s
        );
        break;
      case 3:
        _a(
          e,
          t,
          r,
          s
        ), u & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && eo(e)));
        break;
      case 12:
        if (u & 2048) {
          _a(
            e,
            t,
            r,
            s
          ), e = t.stateNode;
          try {
            var f = t.memoizedProps, v = f.id, x = f.onPostCommit;
            typeof x == "function" && x(
              v,
              t.alternate === null ? "mount" : "update",
              e.passiveEffectDuration,
              -0
            );
          } catch (E) {
            Pe(t, t.return, E);
          }
        } else
          _a(
            e,
            t,
            r,
            s
          );
        break;
      case 31:
        _a(
          e,
          t,
          r,
          s
        );
        break;
      case 13:
        _a(
          e,
          t,
          r,
          s
        );
        break;
      case 23:
        break;
      case 22:
        f = t.stateNode, v = t.alternate, t.memoizedState !== null ? f._visibility & 2 ? _a(
          e,
          t,
          r,
          s
        ) : go(e, t) : f._visibility & 2 ? _a(
          e,
          t,
          r,
          s
        ) : (f._visibility |= 2, si(
          e,
          t,
          r,
          s,
          (t.subtreeFlags & 10256) !== 0 || !1
        )), u & 2048 && Pu(v, t);
        break;
      case 24:
        _a(
          e,
          t,
          r,
          s
        ), u & 2048 && Fu(t.alternate, t);
        break;
      default:
        _a(
          e,
          t,
          r,
          s
        );
    }
  }
  function si(e, t, r, s, u) {
    for (u = u && ((t.subtreeFlags & 10256) !== 0 || !1), t = t.child; t !== null; ) {
      var f = e, v = t, x = r, E = s, z = v.flags;
      switch (v.tag) {
        case 0:
        case 11:
        case 15:
          si(
            f,
            v,
            x,
            E,
            u
          ), ho(8, v);
          break;
        case 23:
          break;
        case 22:
          var V = v.stateNode;
          v.memoizedState !== null ? V._visibility & 2 ? si(
            f,
            v,
            x,
            E,
            u
          ) : go(
            f,
            v
          ) : (V._visibility |= 2, si(
            f,
            v,
            x,
            E,
            u
          )), u && z & 2048 && Pu(
            v.alternate,
            v
          );
          break;
        case 24:
          si(
            f,
            v,
            x,
            E,
            u
          ), u && z & 2048 && Fu(v.alternate, v);
          break;
        default:
          si(
            f,
            v,
            x,
            E,
            u
          );
      }
      t = t.sibling;
    }
  }
  function go(e, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var r = e, s = t, u = s.flags;
        switch (s.tag) {
          case 22:
            go(r, s), u & 2048 && Pu(
              s.alternate,
              s
            );
            break;
          case 24:
            go(r, s), u & 2048 && Fu(s.alternate, s);
            break;
          default:
            go(r, s);
        }
        t = t.sibling;
      }
  }
  var vo = 8192;
  function ci(e, t, r) {
    if (e.subtreeFlags & vo)
      for (e = e.child; e !== null; )
        bm(
          e,
          t,
          r
        ), e = e.sibling;
  }
  function bm(e, t, r) {
    switch (e.tag) {
      case 26:
        ci(
          e,
          t,
          r
        ), e.flags & vo && e.memoizedState !== null && Ox(
          r,
          wa,
          e.memoizedState,
          e.memoizedProps
        );
        break;
      case 5:
        ci(
          e,
          t,
          r
        );
        break;
      case 3:
      case 4:
        var s = wa;
        wa = ns(e.stateNode.containerInfo), ci(
          e,
          t,
          r
        ), wa = s;
        break;
      case 22:
        e.memoizedState === null && (s = e.alternate, s !== null && s.memoizedState !== null ? (s = vo, vo = 16777216, ci(
          e,
          t,
          r
        ), vo = s) : ci(
          e,
          t,
          r
        ));
        break;
      default:
        ci(
          e,
          t,
          r
        );
    }
  }
  function ym(e) {
    var t = e.alternate;
    if (t !== null && (e = t.child, e !== null)) {
      t.child = null;
      do
        t = e.sibling, e.sibling = null, e = t;
      while (e !== null);
    }
  }
  function bo(e) {
    var t = e.deletions;
    if ((e.flags & 16) !== 0) {
      if (t !== null)
        for (var r = 0; r < t.length; r++) {
          var s = t[r];
          yt = s, wm(
            s,
            e
          );
        }
      ym(e);
    }
    if (e.subtreeFlags & 10256)
      for (e = e.child; e !== null; )
        xm(e), e = e.sibling;
  }
  function xm(e) {
    switch (e.tag) {
      case 0:
      case 11:
      case 15:
        bo(e), e.flags & 2048 && On(9, e, e.return);
        break;
      case 3:
        bo(e);
        break;
      case 12:
        bo(e);
        break;
      case 22:
        var t = e.stateNode;
        e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, Fl(e)) : bo(e);
        break;
      default:
        bo(e);
    }
  }
  function Fl(e) {
    var t = e.deletions;
    if ((e.flags & 16) !== 0) {
      if (t !== null)
        for (var r = 0; r < t.length; r++) {
          var s = t[r];
          yt = s, wm(
            s,
            e
          );
        }
      ym(e);
    }
    for (e = e.child; e !== null; ) {
      switch (t = e, t.tag) {
        case 0:
        case 11:
        case 15:
          On(8, t, t.return), Fl(t);
          break;
        case 22:
          r = t.stateNode, r._visibility & 2 && (r._visibility &= -3, Fl(t));
          break;
        default:
          Fl(t);
      }
      e = e.sibling;
    }
  }
  function wm(e, t) {
    for (; yt !== null; ) {
      var r = yt;
      switch (r.tag) {
        case 0:
        case 11:
        case 15:
          On(8, r, t);
          break;
        case 23:
        case 22:
          if (r.memoizedState !== null && r.memoizedState.cachePool !== null) {
            var s = r.memoizedState.cachePool.pool;
            s != null && s.refCount++;
          }
          break;
        case 24:
          eo(r.memoizedState.cache);
      }
      if (s = r.child, s !== null) s.return = r, yt = s;
      else
        e: for (r = e; yt !== null; ) {
          s = yt;
          var u = s.sibling, f = s.return;
          if (dm(s), s === r) {
            yt = null;
            break e;
          }
          if (u !== null) {
            u.return = f, yt = u;
            break e;
          }
          yt = f;
        }
    }
  }
  var G0 = {
    getCacheForType: function(e) {
      var t = _t(ft), r = t.data.get(e);
      return r === void 0 && (r = e(), t.data.set(e, r)), r;
    },
    cacheSignal: function() {
      return _t(ft).controller.signal;
    }
  }, X0 = typeof WeakMap == "function" ? WeakMap : Map, Ue = 0, We = null, Te = null, Oe = 0, Qe = 0, ea = null, jn = !1, ui = !1, Vu = !1, ln = 0, rt = 0, An = 0, vr = 0, Gu = 0, ta = 0, di = 0, yo = null, Bt = null, Xu = !1, Vl = 0, _m = 0, Gl = 1 / 0, Xl = null, Rn = null, gt = 0, zn = null, fi = null, sn = 0, Zu = 0, Ku = null, km = null, xo = 0, Wu = null;
  function aa() {
    return (Ue & 2) !== 0 && Oe !== 0 ? Oe & -Oe : j.T !== null ? ad() : Uf();
  }
  function Sm() {
    if (ta === 0)
      if ((Oe & 536870912) === 0 || Re) {
        var e = tl;
        tl <<= 1, (tl & 3932160) === 0 && (tl = 262144), ta = e;
      } else ta = 536870912;
    return e = Jt.current, e !== null && (e.flags |= 32), ta;
  }
  function qt(e, t, r) {
    (e === We && (Qe === 2 || Qe === 9) || e.cancelPendingCommit !== null) && (pi(e, 0), Ln(
      e,
      Oe,
      ta,
      !1
    )), Bi(e, r), ((Ue & 2) === 0 || e !== We) && (e === We && ((Ue & 2) === 0 && (vr |= r), rt === 4 && Ln(
      e,
      Oe,
      ta,
      !1
    )), Ra(e));
  }
  function Dm(e, t, r) {
    if ((Ue & 6) !== 0) throw Error(a(327));
    var s = !r && (t & 127) === 0 && (t & e.expiredLanes) === 0 || Ui(e, t), u = s ? W0(e, t) : Ju(e, t, !0), f = s;
    do {
      if (u === 0) {
        ui && !s && Ln(e, t, 0, !1);
        break;
      } else {
        if (r = e.current.alternate, f && !Z0(r)) {
          u = Ju(e, t, !1), f = !1;
          continue;
        }
        if (u === 2) {
          if (f = t, e.errorRecoveryDisabledLanes & f)
            var v = 0;
          else
            v = e.pendingLanes & -536870913, v = v !== 0 ? v : v & 536870912 ? 536870912 : 0;
          if (v !== 0) {
            t = v;
            e: {
              var x = e;
              u = yo;
              var E = x.current.memoizedState.isDehydrated;
              if (E && (pi(x, v).flags |= 256), v = Ju(
                x,
                v,
                !1
              ), v !== 2) {
                if (Vu && !E) {
                  x.errorRecoveryDisabledLanes |= f, vr |= f, u = 4;
                  break e;
                }
                f = Bt, Bt = u, f !== null && (Bt === null ? Bt = f : Bt.push.apply(
                  Bt,
                  f
                ));
              }
              u = v;
            }
            if (f = !1, u !== 2) continue;
          }
        }
        if (u === 1) {
          pi(e, 0), Ln(e, t, 0, !0);
          break;
        }
        e: {
          switch (s = e, f = u, f) {
            case 0:
            case 1:
              throw Error(a(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              Ln(
                s,
                t,
                ta,
                !jn
              );
              break e;
            case 2:
              Bt = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(a(329));
          }
          if ((t & 62914560) === t && (u = Vl + 300 - et(), 10 < u)) {
            if (Ln(
              s,
              t,
              ta,
              !jn
            ), nl(s, 0, !0) !== 0) break e;
            sn = t, s.timeoutHandle = ag(
              Em.bind(
                null,
                s,
                r,
                Bt,
                Xl,
                Xu,
                t,
                ta,
                vr,
                di,
                jn,
                f,
                "Throttled",
                -0,
                0
              ),
              u
            );
            break e;
          }
          Em(
            s,
            r,
            Bt,
            Xl,
            Xu,
            t,
            ta,
            vr,
            di,
            jn,
            f,
            null,
            -0,
            0
          );
        }
      }
      break;
    } while (!0);
    Ra(e);
  }
  function Em(e, t, r, s, u, f, v, x, E, z, V, X, Y, U) {
    if (e.timeoutHandle = -1, X = t.subtreeFlags, X & 8192 || (X & 16785408) === 16785408) {
      X = {
        stylesheets: null,
        count: 0,
        imgCount: 0,
        imgBytes: 0,
        suspenseyImages: [],
        waitingForImages: !0,
        waitingForViewTransition: !1,
        unsuspend: Ga
      }, bm(
        t,
        f,
        X
      );
      var ce = (f & 62914560) === f ? Vl - et() : (f & 4194048) === f ? _m - et() : 0;
      if (ce = jx(
        X,
        ce
      ), ce !== null) {
        sn = f, e.cancelPendingCommit = ce(
          Rm.bind(
            null,
            e,
            t,
            f,
            r,
            s,
            u,
            v,
            x,
            E,
            V,
            X,
            null,
            Y,
            U
          )
        ), Ln(e, f, v, !z);
        return;
      }
    }
    Rm(
      e,
      t,
      f,
      r,
      s,
      u,
      v,
      x,
      E
    );
  }
  function Z0(e) {
    for (var t = e; ; ) {
      var r = t.tag;
      if ((r === 0 || r === 11 || r === 15) && t.flags & 16384 && (r = t.updateQueue, r !== null && (r = r.stores, r !== null)))
        for (var s = 0; s < r.length; s++) {
          var u = r[s], f = u.getSnapshot;
          u = u.value;
          try {
            if (!Wt(f(), u)) return !1;
          } catch {
            return !1;
          }
        }
      if (r = t.child, t.subtreeFlags & 16384 && r !== null)
        r.return = t, t = r;
      else {
        if (t === e) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
    }
    return !0;
  }
  function Ln(e, t, r, s) {
    t &= ~Gu, t &= ~vr, e.suspendedLanes |= t, e.pingedLanes &= ~t, s && (e.warmLanes |= t), s = e.expirationTimes;
    for (var u = t; 0 < u; ) {
      var f = 31 - Kt(u), v = 1 << f;
      s[f] = -1, u &= ~v;
    }
    r !== 0 && Lf(e, r, t);
  }
  function Zl() {
    return (Ue & 6) === 0 ? (wo(0), !1) : !0;
  }
  function Iu() {
    if (Te !== null) {
      if (Qe === 0)
        var e = Te.return;
      else
        e = Te, Wa = sr = null, pu(e), ni = null, ao = 0, e = Te;
      for (; e !== null; )
        nm(e.alternate, e), e = e.return;
      Te = null;
    }
  }
  function pi(e, t) {
    var r = e.timeoutHandle;
    r !== -1 && (e.timeoutHandle = -1, hx(r)), r = e.cancelPendingCommit, r !== null && (e.cancelPendingCommit = null, r()), sn = 0, Iu(), We = e, Te = r = Za(e.current, null), Oe = t, Qe = 0, ea = null, jn = !1, ui = Ui(e, t), Vu = !1, di = ta = Gu = vr = An = rt = 0, Bt = yo = null, Xu = !1, (t & 8) !== 0 && (t |= t & 32);
    var s = e.entangledLanes;
    if (s !== 0)
      for (e = e.entanglements, s &= t; 0 < s; ) {
        var u = 31 - Kt(s), f = 1 << u;
        t |= e[u], s &= ~f;
      }
    return ln = t, ml(), r;
  }
  function Mm(e, t) {
    Se = null, j.H = uo, t === ai || t === kl ? (t = Pp(), Qe = 3) : t === tu ? (t = Pp(), Qe = 4) : Qe = t === Cu ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, ea = t, Te === null && (rt = 1, Yl(
      e,
      sa(t, e.current)
    ));
  }
  function Tm() {
    var e = Jt.current;
    return e === null ? !0 : (Oe & 4194048) === Oe ? fa === null : (Oe & 62914560) === Oe || (Oe & 536870912) !== 0 ? e === fa : !1;
  }
  function Cm() {
    var e = j.H;
    return j.H = uo, e === null ? uo : e;
  }
  function Nm() {
    var e = j.A;
    return j.A = G0, e;
  }
  function Kl() {
    rt = 4, jn || (Oe & 4194048) !== Oe && Jt.current !== null || (ui = !0), (An & 134217727) === 0 && (vr & 134217727) === 0 || We === null || Ln(
      We,
      Oe,
      ta,
      !1
    );
  }
  function Ju(e, t, r) {
    var s = Ue;
    Ue |= 2;
    var u = Cm(), f = Nm();
    (We !== e || Oe !== t) && (Xl = null, pi(e, t)), t = !1;
    var v = rt;
    e: do
      try {
        if (Qe !== 0 && Te !== null) {
          var x = Te, E = ea;
          switch (Qe) {
            case 8:
              Iu(), v = 6;
              break e;
            case 3:
            case 2:
            case 9:
            case 6:
              Jt.current === null && (t = !0);
              var z = Qe;
              if (Qe = 0, ea = null, hi(e, x, E, z), r && ui) {
                v = 0;
                break e;
              }
              break;
            default:
              z = Qe, Qe = 0, ea = null, hi(e, x, E, z);
          }
        }
        K0(), v = rt;
        break;
      } catch (V) {
        Mm(e, V);
      }
    while (!0);
    return t && e.shellSuspendCounter++, Wa = sr = null, Ue = s, j.H = u, j.A = f, Te === null && (We = null, Oe = 0, ml()), v;
  }
  function K0() {
    for (; Te !== null; ) Om(Te);
  }
  function W0(e, t) {
    var r = Ue;
    Ue |= 2;
    var s = Cm(), u = Nm();
    We !== e || Oe !== t ? (Xl = null, Gl = et() + 500, pi(e, t)) : ui = Ui(
      e,
      t
    );
    e: do
      try {
        if (Qe !== 0 && Te !== null) {
          t = Te;
          var f = ea;
          t: switch (Qe) {
            case 1:
              Qe = 0, ea = null, hi(e, t, f, 1);
              break;
            case 2:
            case 9:
              if (qp(f)) {
                Qe = 0, ea = null, jm(t);
                break;
              }
              t = function() {
                Qe !== 2 && Qe !== 9 || We !== e || (Qe = 7), Ra(e);
              }, f.then(t, t);
              break e;
            case 3:
              Qe = 7;
              break e;
            case 4:
              Qe = 5;
              break e;
            case 7:
              qp(f) ? (Qe = 0, ea = null, jm(t)) : (Qe = 0, ea = null, hi(e, t, f, 7));
              break;
            case 5:
              var v = null;
              switch (Te.tag) {
                case 26:
                  v = Te.memoizedState;
                case 5:
                case 27:
                  var x = Te;
                  if (v ? vg(v) : x.stateNode.complete) {
                    Qe = 0, ea = null;
                    var E = x.sibling;
                    if (E !== null) Te = E;
                    else {
                      var z = x.return;
                      z !== null ? (Te = z, Wl(z)) : Te = null;
                    }
                    break t;
                  }
              }
              Qe = 0, ea = null, hi(e, t, f, 5);
              break;
            case 6:
              Qe = 0, ea = null, hi(e, t, f, 6);
              break;
            case 8:
              Iu(), rt = 6;
              break e;
            default:
              throw Error(a(462));
          }
        }
        I0();
        break;
      } catch (V) {
        Mm(e, V);
      }
    while (!0);
    return Wa = sr = null, j.H = s, j.A = u, Ue = r, Te !== null ? 0 : (We = null, Oe = 0, ml(), rt);
  }
  function I0() {
    for (; Te !== null && !Li(); )
      Om(Te);
  }
  function Om(e) {
    var t = tm(e.alternate, e, ln);
    e.memoizedProps = e.pendingProps, t === null ? Wl(e) : Te = t;
  }
  function jm(e) {
    var t = e, r = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = Kh(
          r,
          t,
          t.pendingProps,
          t.type,
          void 0,
          Oe
        );
        break;
      case 11:
        t = Kh(
          r,
          t,
          t.pendingProps,
          t.type.render,
          t.ref,
          Oe
        );
        break;
      case 5:
        pu(t);
      default:
        nm(r, t), t = Te = Np(t, ln), t = tm(r, t, ln);
    }
    e.memoizedProps = e.pendingProps, t === null ? Wl(e) : Te = t;
  }
  function hi(e, t, r, s) {
    Wa = sr = null, pu(t), ni = null, ao = 0;
    var u = t.return;
    try {
      if (U0(
        e,
        u,
        t,
        r,
        Oe
      )) {
        rt = 1, Yl(
          e,
          sa(r, e.current)
        ), Te = null;
        return;
      }
    } catch (f) {
      if (u !== null) throw Te = u, f;
      rt = 1, Yl(
        e,
        sa(r, e.current)
      ), Te = null;
      return;
    }
    t.flags & 32768 ? (Re || s === 1 ? e = !0 : ui || (Oe & 536870912) !== 0 ? e = !1 : (jn = e = !0, (s === 2 || s === 9 || s === 3 || s === 6) && (s = Jt.current, s !== null && s.tag === 13 && (s.flags |= 16384))), Am(t, e)) : Wl(t);
  }
  function Wl(e) {
    var t = e;
    do {
      if ((t.flags & 32768) !== 0) {
        Am(
          t,
          jn
        );
        return;
      }
      e = t.return;
      var r = Q0(
        t.alternate,
        t,
        ln
      );
      if (r !== null) {
        Te = r;
        return;
      }
      if (t = t.sibling, t !== null) {
        Te = t;
        return;
      }
      Te = t = e;
    } while (t !== null);
    rt === 0 && (rt = 5);
  }
  function Am(e, t) {
    do {
      var r = P0(e.alternate, e);
      if (r !== null) {
        r.flags &= 32767, Te = r;
        return;
      }
      if (r = e.return, r !== null && (r.flags |= 32768, r.subtreeFlags = 0, r.deletions = null), !t && (e = e.sibling, e !== null)) {
        Te = e;
        return;
      }
      Te = e = r;
    } while (e !== null);
    rt = 6, Te = null;
  }
  function Rm(e, t, r, s, u, f, v, x, E) {
    e.cancelPendingCommit = null;
    do
      Il();
    while (gt !== 0);
    if ((Ue & 6) !== 0) throw Error(a(327));
    if (t !== null) {
      if (t === e.current) throw Error(a(177));
      if (f = t.lanes | t.childLanes, f |= Bc, Ny(
        e,
        r,
        f,
        v,
        x,
        E
      ), e === We && (Te = We = null, Oe = 0), fi = t, zn = e, sn = r, Zu = f, Ku = u, km = s, (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? (e.callbackNode = null, e.callbackPriority = 0, tx(ya, function() {
        return Um(), null;
      })) : (e.callbackNode = null, e.callbackPriority = 0), s = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || s) {
        s = j.T, j.T = null, u = Q.p, Q.p = 2, v = Ue, Ue |= 4;
        try {
          F0(e, t, r);
        } finally {
          Ue = v, Q.p = u, j.T = s;
        }
      }
      gt = 1, zm(), Lm(), Ym();
    }
  }
  function zm() {
    if (gt === 1) {
      gt = 0;
      var e = zn, t = fi, r = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || r) {
        r = j.T, j.T = null;
        var s = Q.p;
        Q.p = 2;
        var u = Ue;
        Ue |= 4;
        try {
          mm(t, e);
          var f = ud, v = wp(e.containerInfo), x = f.focusedElem, E = f.selectionRange;
          if (v !== x && x && x.ownerDocument && xp(
            x.ownerDocument.documentElement,
            x
          )) {
            if (E !== null && zc(x)) {
              var z = E.start, V = E.end;
              if (V === void 0 && (V = z), "selectionStart" in x)
                x.selectionStart = z, x.selectionEnd = Math.min(
                  V,
                  x.value.length
                );
              else {
                var X = x.ownerDocument || document, Y = X && X.defaultView || window;
                if (Y.getSelection) {
                  var U = Y.getSelection(), ce = x.textContent.length, ye = Math.min(E.start, ce), Ze = E.end === void 0 ? ye : Math.min(E.end, ce);
                  !U.extend && ye > Ze && (v = Ze, Ze = ye, ye = v);
                  var A = yp(
                    x,
                    ye
                  ), C = yp(
                    x,
                    Ze
                  );
                  if (A && C && (U.rangeCount !== 1 || U.anchorNode !== A.node || U.anchorOffset !== A.offset || U.focusNode !== C.node || U.focusOffset !== C.offset)) {
                    var R = X.createRange();
                    R.setStart(A.node, A.offset), U.removeAllRanges(), ye > Ze ? (U.addRange(R), U.extend(C.node, C.offset)) : (R.setEnd(C.node, C.offset), U.addRange(R));
                  }
                }
              }
            }
            for (X = [], U = x; U = U.parentNode; )
              U.nodeType === 1 && X.push({
                element: U,
                left: U.scrollLeft,
                top: U.scrollTop
              });
            for (typeof x.focus == "function" && x.focus(), x = 0; x < X.length; x++) {
              var G = X[x];
              G.element.scrollLeft = G.left, G.element.scrollTop = G.top;
            }
          }
          cs = !!cd, ud = cd = null;
        } finally {
          Ue = u, Q.p = s, j.T = r;
        }
      }
      e.current = t, gt = 2;
    }
  }
  function Lm() {
    if (gt === 2) {
      gt = 0;
      var e = zn, t = fi, r = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || r) {
        r = j.T, j.T = null;
        var s = Q.p;
        Q.p = 2;
        var u = Ue;
        Ue |= 4;
        try {
          um(e, t.alternate, t);
        } finally {
          Ue = u, Q.p = s, j.T = r;
        }
      }
      gt = 3;
    }
  }
  function Ym() {
    if (gt === 4 || gt === 3) {
      gt = 0, zr();
      var e = zn, t = fi, r = sn, s = km;
      (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? gt = 5 : (gt = 0, fi = zn = null, Hm(e, e.pendingLanes));
      var u = e.pendingLanes;
      if (u === 0 && (Rn = null), gc(r), t = t.stateNode, Zt && typeof Zt.onCommitFiberRoot == "function")
        try {
          Zt.onCommitFiberRoot(
            $n,
            t,
            void 0,
            (t.current.flags & 128) === 128
          );
        } catch {
        }
      if (s !== null) {
        t = j.T, u = Q.p, Q.p = 2, j.T = null;
        try {
          for (var f = e.onRecoverableError, v = 0; v < s.length; v++) {
            var x = s[v];
            f(x.value, {
              componentStack: x.stack
            });
          }
        } finally {
          j.T = t, Q.p = u;
        }
      }
      (sn & 3) !== 0 && Il(), Ra(e), u = e.pendingLanes, (r & 261930) !== 0 && (u & 42) !== 0 ? e === Wu ? xo++ : (xo = 0, Wu = e) : xo = 0, wo(0);
    }
  }
  function Hm(e, t) {
    (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, eo(t)));
  }
  function Il() {
    return zm(), Lm(), Ym(), Um();
  }
  function Um() {
    if (gt !== 5) return !1;
    var e = zn, t = Zu;
    Zu = 0;
    var r = gc(sn), s = j.T, u = Q.p;
    try {
      Q.p = 32 > r ? 32 : r, j.T = null, r = Ku, Ku = null;
      var f = zn, v = sn;
      if (gt = 0, fi = zn = null, sn = 0, (Ue & 6) !== 0) throw Error(a(331));
      var x = Ue;
      if (Ue |= 4, xm(f.current), vm(
        f,
        f.current,
        v,
        r
      ), Ue = x, wo(0, !1), Zt && typeof Zt.onPostCommitFiberRoot == "function")
        try {
          Zt.onPostCommitFiberRoot($n, f);
        } catch {
        }
      return !0;
    } finally {
      Q.p = u, j.T = s, Hm(e, t);
    }
  }
  function Bm(e, t, r) {
    t = sa(r, t), t = Tu(e.stateNode, t, 2), e = Tn(e, t, 2), e !== null && (Bi(e, 2), Ra(e));
  }
  function Pe(e, t, r) {
    if (e.tag === 3)
      Bm(e, e, r);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          Bm(
            t,
            e,
            r
          );
          break;
        } else if (t.tag === 1) {
          var s = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof s.componentDidCatch == "function" && (Rn === null || !Rn.has(s))) {
            e = sa(r, e), r = qh(2), s = Tn(t, r, 2), s !== null && (Qh(
              r,
              s,
              t,
              e
            ), Bi(s, 2), Ra(s));
            break;
          }
        }
        t = t.return;
      }
  }
  function $u(e, t, r) {
    var s = e.pingCache;
    if (s === null) {
      s = e.pingCache = new X0();
      var u = /* @__PURE__ */ new Set();
      s.set(t, u);
    } else
      u = s.get(t), u === void 0 && (u = /* @__PURE__ */ new Set(), s.set(t, u));
    u.has(r) || (Vu = !0, u.add(r), e = J0.bind(null, e, t, r), t.then(e, e));
  }
  function J0(e, t, r) {
    var s = e.pingCache;
    s !== null && s.delete(t), e.pingedLanes |= e.suspendedLanes & r, e.warmLanes &= ~r, We === e && (Oe & r) === r && (rt === 4 || rt === 3 && (Oe & 62914560) === Oe && 300 > et() - Vl ? (Ue & 2) === 0 && pi(e, 0) : Gu |= r, di === Oe && (di = 0)), Ra(e);
  }
  function qm(e, t) {
    t === 0 && (t = zf()), e = ir(e, t), e !== null && (Bi(e, t), Ra(e));
  }
  function $0(e) {
    var t = e.memoizedState, r = 0;
    t !== null && (r = t.retryLane), qm(e, r);
  }
  function ex(e, t) {
    var r = 0;
    switch (e.tag) {
      case 31:
      case 13:
        var s = e.stateNode, u = e.memoizedState;
        u !== null && (r = u.retryLane);
        break;
      case 19:
        s = e.stateNode;
        break;
      case 22:
        s = e.stateNode._retryCache;
        break;
      default:
        throw Error(a(314));
    }
    s !== null && s.delete(t), qm(e, r);
  }
  function tx(e, t) {
    return Jn(e, t);
  }
  var Jl = null, mi = null, ed = !1, $l = !1, td = !1, Yn = 0;
  function Ra(e) {
    e !== mi && e.next === null && (mi === null ? Jl = mi = e : mi = mi.next = e), $l = !0, ed || (ed = !0, nx());
  }
  function wo(e, t) {
    if (!td && $l) {
      td = !0;
      do
        for (var r = !1, s = Jl; s !== null; ) {
          if (e !== 0) {
            var u = s.pendingLanes;
            if (u === 0) var f = 0;
            else {
              var v = s.suspendedLanes, x = s.pingedLanes;
              f = (1 << 31 - Kt(42 | e) + 1) - 1, f &= u & ~(v & ~x), f = f & 201326741 ? f & 201326741 | 1 : f ? f | 2 : 0;
            }
            f !== 0 && (r = !0, Vm(s, f));
          } else
            f = Oe, f = nl(
              s,
              s === We ? f : 0,
              s.cancelPendingCommit !== null || s.timeoutHandle !== -1
            ), (f & 3) === 0 || Ui(s, f) || (r = !0, Vm(s, f));
          s = s.next;
        }
      while (r);
      td = !1;
    }
  }
  function ax() {
    Qm();
  }
  function Qm() {
    $l = ed = !1;
    var e = 0;
    Yn !== 0 && px() && (e = Yn);
    for (var t = et(), r = null, s = Jl; s !== null; ) {
      var u = s.next, f = Pm(s, t);
      f === 0 ? (s.next = null, r === null ? Jl = u : r.next = u, u === null && (mi = r)) : (r = s, (e !== 0 || (f & 3) !== 0) && ($l = !0)), s = u;
    }
    gt !== 0 && gt !== 5 || wo(e), Yn !== 0 && (Yn = 0);
  }
  function Pm(e, t) {
    for (var r = e.suspendedLanes, s = e.pingedLanes, u = e.expirationTimes, f = e.pendingLanes & -62914561; 0 < f; ) {
      var v = 31 - Kt(f), x = 1 << v, E = u[v];
      E === -1 ? ((x & r) === 0 || (x & s) !== 0) && (u[v] = Cy(x, t)) : E <= t && (e.expiredLanes |= x), f &= ~x;
    }
    if (t = We, r = Oe, r = nl(
      e,
      e === t ? r : 0,
      e.cancelPendingCommit !== null || e.timeoutHandle !== -1
    ), s = e.callbackNode, r === 0 || e === t && (Qe === 2 || Qe === 9) || e.cancelPendingCommit !== null)
      return s !== null && s !== null && Rr(s), e.callbackNode = null, e.callbackPriority = 0;
    if ((r & 3) === 0 || Ui(e, r)) {
      if (t = r & -r, t === e.callbackPriority) return t;
      switch (s !== null && Rr(s), gc(r)) {
        case 2:
        case 8:
          r = De;
          break;
        case 32:
          r = ya;
          break;
        case 268435456:
          r = Yi;
          break;
        default:
          r = ya;
      }
      return s = Fm.bind(null, e), r = Jn(r, s), e.callbackPriority = t, e.callbackNode = r, t;
    }
    return s !== null && s !== null && Rr(s), e.callbackPriority = 2, e.callbackNode = null, 2;
  }
  function Fm(e, t) {
    if (gt !== 0 && gt !== 5)
      return e.callbackNode = null, e.callbackPriority = 0, null;
    var r = e.callbackNode;
    if (Il() && e.callbackNode !== r)
      return null;
    var s = Oe;
    return s = nl(
      e,
      e === We ? s : 0,
      e.cancelPendingCommit !== null || e.timeoutHandle !== -1
    ), s === 0 ? null : (Dm(e, s, t), Pm(e, et()), e.callbackNode != null && e.callbackNode === r ? Fm.bind(null, e) : null);
  }
  function Vm(e, t) {
    if (Il()) return null;
    Dm(e, t, !0);
  }
  function nx() {
    mx(function() {
      (Ue & 6) !== 0 ? Jn(
        re,
        ax
      ) : Qm();
    });
  }
  function ad() {
    if (Yn === 0) {
      var e = ei;
      e === 0 && (e = el, el <<= 1, (el & 261888) === 0 && (el = 256)), Yn = e;
    }
    return Yn;
  }
  function Gm(e) {
    return e == null || typeof e == "symbol" || typeof e == "boolean" ? null : typeof e == "function" ? e : ll("" + e);
  }
  function Xm(e, t) {
    var r = t.ownerDocument.createElement("input");
    return r.name = t.name, r.value = t.value, e.id && r.setAttribute("form", e.id), t.parentNode.insertBefore(r, t), e = new FormData(e), r.parentNode.removeChild(r), e;
  }
  function rx(e, t, r, s, u) {
    if (t === "submit" && r && r.stateNode === u) {
      var f = Gm(
        (u[zt] || null).action
      ), v = s.submitter;
      v && (t = (t = v[zt] || null) ? Gm(t.formAction) : v.getAttribute("formAction"), t !== null && (f = t, v = null));
      var x = new dl(
        "action",
        "action",
        null,
        s,
        u
      );
      e.push({
        event: x,
        listeners: [
          {
            instance: null,
            listener: function() {
              if (s.defaultPrevented) {
                if (Yn !== 0) {
                  var E = v ? Xm(u, v) : new FormData(u);
                  _u(
                    r,
                    {
                      pending: !0,
                      data: E,
                      method: u.method,
                      action: f
                    },
                    null,
                    E
                  );
                }
              } else
                typeof f == "function" && (x.preventDefault(), E = v ? Xm(u, v) : new FormData(u), _u(
                  r,
                  {
                    pending: !0,
                    data: E,
                    method: u.method,
                    action: f
                  },
                  f,
                  E
                ));
            },
            currentTarget: u
          }
        ]
      });
    }
  }
  for (var nd = 0; nd < Uc.length; nd++) {
    var rd = Uc[nd], ix = rd.toLowerCase(), ox = rd[0].toUpperCase() + rd.slice(1);
    xa(
      ix,
      "on" + ox
    );
  }
  xa(Sp, "onAnimationEnd"), xa(Dp, "onAnimationIteration"), xa(Ep, "onAnimationStart"), xa("dblclick", "onDoubleClick"), xa("focusin", "onFocus"), xa("focusout", "onBlur"), xa(_0, "onTransitionRun"), xa(k0, "onTransitionStart"), xa(S0, "onTransitionCancel"), xa(Mp, "onTransitionEnd"), Br("onMouseEnter", ["mouseout", "mouseover"]), Br("onMouseLeave", ["mouseout", "mouseover"]), Br("onPointerEnter", ["pointerout", "pointerover"]), Br("onPointerLeave", ["pointerout", "pointerover"]), tr(
    "onChange",
    "change click focusin focusout input keydown keyup selectionchange".split(" ")
  ), tr(
    "onSelect",
    "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
      " "
    )
  ), tr("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]), tr(
    "onCompositionEnd",
    "compositionend focusout keydown keypress keyup mousedown".split(" ")
  ), tr(
    "onCompositionStart",
    "compositionstart focusout keydown keypress keyup mousedown".split(" ")
  ), tr(
    "onCompositionUpdate",
    "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
  );
  var _o = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
    " "
  ), lx = new Set(
    "beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(_o)
  );
  function Zm(e, t) {
    t = (t & 4) !== 0;
    for (var r = 0; r < e.length; r++) {
      var s = e[r], u = s.event;
      s = s.listeners;
      e: {
        var f = void 0;
        if (t)
          for (var v = s.length - 1; 0 <= v; v--) {
            var x = s[v], E = x.instance, z = x.currentTarget;
            if (x = x.listener, E !== f && u.isPropagationStopped())
              break e;
            f = x, u.currentTarget = z;
            try {
              f(u);
            } catch (V) {
              hl(V);
            }
            u.currentTarget = null, f = E;
          }
        else
          for (v = 0; v < s.length; v++) {
            if (x = s[v], E = x.instance, z = x.currentTarget, x = x.listener, E !== f && u.isPropagationStopped())
              break e;
            f = x, u.currentTarget = z;
            try {
              f(u);
            } catch (V) {
              hl(V);
            }
            u.currentTarget = null, f = E;
          }
      }
    }
  }
  function Ce(e, t) {
    var r = t[vc];
    r === void 0 && (r = t[vc] = /* @__PURE__ */ new Set());
    var s = e + "__bubble";
    r.has(s) || (Km(t, e, 2, !1), r.add(s));
  }
  function id(e, t, r) {
    var s = 0;
    t && (s |= 4), Km(
      r,
      e,
      s,
      t
    );
  }
  var es = "_reactListening" + Math.random().toString(36).slice(2);
  function od(e) {
    if (!e[es]) {
      e[es] = !0, Qf.forEach(function(r) {
        r !== "selectionchange" && (lx.has(r) || id(r, !1, e), id(r, !0, e));
      });
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[es] || (t[es] = !0, id("selectionchange", !1, t));
    }
  }
  function Km(e, t, r, s) {
    switch (Sg(t)) {
      case 2:
        var u = zx;
        break;
      case 8:
        u = Lx;
        break;
      default:
        u = wd;
    }
    r = u.bind(
      null,
      t,
      r,
      e
    ), u = void 0, !Ec || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (u = !0), s ? u !== void 0 ? e.addEventListener(t, r, {
      capture: !0,
      passive: u
    }) : e.addEventListener(t, r, !0) : u !== void 0 ? e.addEventListener(t, r, {
      passive: u
    }) : e.addEventListener(t, r, !1);
  }
  function ld(e, t, r, s, u) {
    var f = s;
    if ((t & 1) === 0 && (t & 2) === 0 && s !== null)
      e: for (; ; ) {
        if (s === null) return;
        var v = s.tag;
        if (v === 3 || v === 4) {
          var x = s.stateNode.containerInfo;
          if (x === u) break;
          if (v === 4)
            for (v = s.return; v !== null; ) {
              var E = v.tag;
              if ((E === 3 || E === 4) && v.stateNode.containerInfo === u)
                return;
              v = v.return;
            }
          for (; x !== null; ) {
            if (v = Yr(x), v === null) return;
            if (E = v.tag, E === 5 || E === 6 || E === 26 || E === 27) {
              s = f = v;
              continue e;
            }
            x = x.parentNode;
          }
        }
        s = s.return;
      }
    ep(function() {
      var z = f, V = Sc(r), X = [];
      e: {
        var Y = Tp.get(e);
        if (Y !== void 0) {
          var U = dl, ce = e;
          switch (e) {
            case "keypress":
              if (cl(r) === 0) break e;
            case "keydown":
            case "keyup":
              U = e0;
              break;
            case "focusin":
              ce = "focus", U = Nc;
              break;
            case "focusout":
              ce = "blur", U = Nc;
              break;
            case "beforeblur":
            case "afterblur":
              U = Nc;
              break;
            case "click":
              if (r.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              U = np;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              U = Qy;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              U = n0;
              break;
            case Sp:
            case Dp:
            case Ep:
              U = Vy;
              break;
            case Mp:
              U = i0;
              break;
            case "scroll":
            case "scrollend":
              U = By;
              break;
            case "wheel":
              U = l0;
              break;
            case "copy":
            case "cut":
            case "paste":
              U = Xy;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              U = ip;
              break;
            case "toggle":
            case "beforetoggle":
              U = c0;
          }
          var ye = (t & 4) !== 0, Ze = !ye && (e === "scroll" || e === "scrollend"), A = ye ? Y !== null ? Y + "Capture" : null : Y;
          ye = [];
          for (var C = z, R; C !== null; ) {
            var G = C;
            if (R = G.stateNode, G = G.tag, G !== 5 && G !== 26 && G !== 27 || R === null || A === null || (G = Pi(C, A), G != null && ye.push(
              ko(C, G, R)
            )), Ze) break;
            C = C.return;
          }
          0 < ye.length && (Y = new U(
            Y,
            ce,
            null,
            r,
            V
          ), X.push({ event: Y, listeners: ye }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (Y = e === "mouseover" || e === "pointerover", U = e === "mouseout" || e === "pointerout", Y && r !== kc && (ce = r.relatedTarget || r.fromElement) && (Yr(ce) || ce[Lr]))
            break e;
          if ((U || Y) && (Y = V.window === V ? V : (Y = V.ownerDocument) ? Y.defaultView || Y.parentWindow : window, U ? (ce = r.relatedTarget || r.toElement, U = z, ce = ce ? Yr(ce) : null, ce !== null && (Ze = c(ce), ye = ce.tag, ce !== Ze || ye !== 5 && ye !== 27 && ye !== 6) && (ce = null)) : (U = null, ce = z), U !== ce)) {
            if (ye = np, G = "onMouseLeave", A = "onMouseEnter", C = "mouse", (e === "pointerout" || e === "pointerover") && (ye = ip, G = "onPointerLeave", A = "onPointerEnter", C = "pointer"), Ze = U == null ? Y : Qi(U), R = ce == null ? Y : Qi(ce), Y = new ye(
              G,
              C + "leave",
              U,
              r,
              V
            ), Y.target = Ze, Y.relatedTarget = R, G = null, Yr(V) === z && (ye = new ye(
              A,
              C + "enter",
              ce,
              r,
              V
            ), ye.target = R, ye.relatedTarget = Ze, G = ye), Ze = G, U && ce)
              t: {
                for (ye = sx, A = U, C = ce, R = 0, G = A; G; G = ye(G))
                  R++;
                G = 0;
                for (var ge = C; ge; ge = ye(ge))
                  G++;
                for (; 0 < R - G; )
                  A = ye(A), R--;
                for (; 0 < G - R; )
                  C = ye(C), G--;
                for (; R--; ) {
                  if (A === C || C !== null && A === C.alternate) {
                    ye = A;
                    break t;
                  }
                  A = ye(A), C = ye(C);
                }
                ye = null;
              }
            else ye = null;
            U !== null && Wm(
              X,
              Y,
              U,
              ye,
              !1
            ), ce !== null && Ze !== null && Wm(
              X,
              Ze,
              ce,
              ye,
              !0
            );
          }
        }
        e: {
          if (Y = z ? Qi(z) : window, U = Y.nodeName && Y.nodeName.toLowerCase(), U === "select" || U === "input" && Y.type === "file")
            var Ye = pp;
          else if (dp(Y))
            if (hp)
              Ye = y0;
            else {
              Ye = v0;
              var he = g0;
            }
          else
            U = Y.nodeName, !U || U.toLowerCase() !== "input" || Y.type !== "checkbox" && Y.type !== "radio" ? z && _c(z.elementType) && (Ye = pp) : Ye = b0;
          if (Ye && (Ye = Ye(e, z))) {
            fp(
              X,
              Ye,
              r,
              V
            );
            break e;
          }
          he && he(e, Y, z), e === "focusout" && z && Y.type === "number" && z.memoizedProps.value != null && wc(Y, "number", Y.value);
        }
        switch (he = z ? Qi(z) : window, e) {
          case "focusin":
            (dp(he) || he.contentEditable === "true") && (Gr = he, Lc = z, Ii = null);
            break;
          case "focusout":
            Ii = Lc = Gr = null;
            break;
          case "mousedown":
            Yc = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Yc = !1, _p(X, r, V);
            break;
          case "selectionchange":
            if (w0) break;
          case "keydown":
          case "keyup":
            _p(X, r, V);
        }
        var Ee;
        if (jc)
          e: {
            switch (e) {
              case "compositionstart":
                var je = "onCompositionStart";
                break e;
              case "compositionend":
                je = "onCompositionEnd";
                break e;
              case "compositionupdate":
                je = "onCompositionUpdate";
                break e;
            }
            je = void 0;
          }
        else
          Vr ? cp(e, r) && (je = "onCompositionEnd") : e === "keydown" && r.keyCode === 229 && (je = "onCompositionStart");
        je && (op && r.locale !== "ko" && (Vr || je !== "onCompositionStart" ? je === "onCompositionEnd" && Vr && (Ee = tp()) : (wn = V, Mc = "value" in wn ? wn.value : wn.textContent, Vr = !0)), he = ts(z, je), 0 < he.length && (je = new rp(
          je,
          e,
          null,
          r,
          V
        ), X.push({ event: je, listeners: he }), Ee ? je.data = Ee : (Ee = up(r), Ee !== null && (je.data = Ee)))), (Ee = d0 ? f0(e, r) : p0(e, r)) && (je = ts(z, "onBeforeInput"), 0 < je.length && (he = new rp(
          "onBeforeInput",
          "beforeinput",
          null,
          r,
          V
        ), X.push({
          event: he,
          listeners: je
        }), he.data = Ee)), rx(
          X,
          e,
          z,
          r,
          V
        );
      }
      Zm(X, t);
    });
  }
  function ko(e, t, r) {
    return {
      instance: e,
      listener: t,
      currentTarget: r
    };
  }
  function ts(e, t) {
    for (var r = t + "Capture", s = []; e !== null; ) {
      var u = e, f = u.stateNode;
      if (u = u.tag, u !== 5 && u !== 26 && u !== 27 || f === null || (u = Pi(e, r), u != null && s.unshift(
        ko(e, u, f)
      ), u = Pi(e, t), u != null && s.push(
        ko(e, u, f)
      )), e.tag === 3) return s;
      e = e.return;
    }
    return [];
  }
  function sx(e) {
    if (e === null) return null;
    do
      e = e.return;
    while (e && e.tag !== 5 && e.tag !== 27);
    return e || null;
  }
  function Wm(e, t, r, s, u) {
    for (var f = t._reactName, v = []; r !== null && r !== s; ) {
      var x = r, E = x.alternate, z = x.stateNode;
      if (x = x.tag, E !== null && E === s) break;
      x !== 5 && x !== 26 && x !== 27 || z === null || (E = z, u ? (z = Pi(r, f), z != null && v.unshift(
        ko(r, z, E)
      )) : u || (z = Pi(r, f), z != null && v.push(
        ko(r, z, E)
      ))), r = r.return;
    }
    v.length !== 0 && e.push({ event: t, listeners: v });
  }
  var cx = /\r\n?/g, ux = /\u0000|\uFFFD/g;
  function Im(e) {
    return (typeof e == "string" ? e : "" + e).replace(cx, `
`).replace(ux, "");
  }
  function Jm(e, t) {
    return t = Im(t), Im(e) === t;
  }
  function Xe(e, t, r, s, u, f) {
    switch (r) {
      case "children":
        typeof s == "string" ? t === "body" || t === "textarea" && s === "" || Qr(e, s) : (typeof s == "number" || typeof s == "bigint") && t !== "body" && Qr(e, "" + s);
        break;
      case "className":
        il(e, "class", s);
        break;
      case "tabIndex":
        il(e, "tabindex", s);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        il(e, r, s);
        break;
      case "style":
        Jf(e, s, f);
        break;
      case "data":
        if (t !== "object") {
          il(e, "data", s);
          break;
        }
      case "src":
      case "href":
        if (s === "" && (t !== "a" || r !== "href")) {
          e.removeAttribute(r);
          break;
        }
        if (s == null || typeof s == "function" || typeof s == "symbol" || typeof s == "boolean") {
          e.removeAttribute(r);
          break;
        }
        s = ll("" + s), e.setAttribute(r, s);
        break;
      case "action":
      case "formAction":
        if (typeof s == "function") {
          e.setAttribute(
            r,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')"
          );
          break;
        } else
          typeof f == "function" && (r === "formAction" ? (t !== "input" && Xe(e, t, "name", u.name, u, null), Xe(
            e,
            t,
            "formEncType",
            u.formEncType,
            u,
            null
          ), Xe(
            e,
            t,
            "formMethod",
            u.formMethod,
            u,
            null
          ), Xe(
            e,
            t,
            "formTarget",
            u.formTarget,
            u,
            null
          )) : (Xe(e, t, "encType", u.encType, u, null), Xe(e, t, "method", u.method, u, null), Xe(e, t, "target", u.target, u, null)));
        if (s == null || typeof s == "symbol" || typeof s == "boolean") {
          e.removeAttribute(r);
          break;
        }
        s = ll("" + s), e.setAttribute(r, s);
        break;
      case "onClick":
        s != null && (e.onclick = Ga);
        break;
      case "onScroll":
        s != null && Ce("scroll", e);
        break;
      case "onScrollEnd":
        s != null && Ce("scrollend", e);
        break;
      case "dangerouslySetInnerHTML":
        if (s != null) {
          if (typeof s != "object" || !("__html" in s))
            throw Error(a(61));
          if (r = s.__html, r != null) {
            if (u.children != null) throw Error(a(60));
            e.innerHTML = r;
          }
        }
        break;
      case "multiple":
        e.multiple = s && typeof s != "function" && typeof s != "symbol";
        break;
      case "muted":
        e.muted = s && typeof s != "function" && typeof s != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (s == null || typeof s == "function" || typeof s == "boolean" || typeof s == "symbol") {
          e.removeAttribute("xlink:href");
          break;
        }
        r = ll("" + s), e.setAttributeNS(
          "http://www.w3.org/1999/xlink",
          "xlink:href",
          r
        );
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        s != null && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(r, "" + s) : e.removeAttribute(r);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        s && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(r, "") : e.removeAttribute(r);
        break;
      case "capture":
      case "download":
        s === !0 ? e.setAttribute(r, "") : s !== !1 && s != null && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(r, s) : e.removeAttribute(r);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        s != null && typeof s != "function" && typeof s != "symbol" && !isNaN(s) && 1 <= s ? e.setAttribute(r, s) : e.removeAttribute(r);
        break;
      case "rowSpan":
      case "start":
        s == null || typeof s == "function" || typeof s == "symbol" || isNaN(s) ? e.removeAttribute(r) : e.setAttribute(r, s);
        break;
      case "popover":
        Ce("beforetoggle", e), Ce("toggle", e), rl(e, "popover", s);
        break;
      case "xlinkActuate":
        Va(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:actuate",
          s
        );
        break;
      case "xlinkArcrole":
        Va(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:arcrole",
          s
        );
        break;
      case "xlinkRole":
        Va(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:role",
          s
        );
        break;
      case "xlinkShow":
        Va(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:show",
          s
        );
        break;
      case "xlinkTitle":
        Va(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:title",
          s
        );
        break;
      case "xlinkType":
        Va(
          e,
          "http://www.w3.org/1999/xlink",
          "xlink:type",
          s
        );
        break;
      case "xmlBase":
        Va(
          e,
          "http://www.w3.org/XML/1998/namespace",
          "xml:base",
          s
        );
        break;
      case "xmlLang":
        Va(
          e,
          "http://www.w3.org/XML/1998/namespace",
          "xml:lang",
          s
        );
        break;
      case "xmlSpace":
        Va(
          e,
          "http://www.w3.org/XML/1998/namespace",
          "xml:space",
          s
        );
        break;
      case "is":
        rl(e, "is", s);
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        (!(2 < r.length) || r[0] !== "o" && r[0] !== "O" || r[1] !== "n" && r[1] !== "N") && (r = Hy.get(r) || r, rl(e, r, s));
    }
  }
  function sd(e, t, r, s, u, f) {
    switch (r) {
      case "style":
        Jf(e, s, f);
        break;
      case "dangerouslySetInnerHTML":
        if (s != null) {
          if (typeof s != "object" || !("__html" in s))
            throw Error(a(61));
          if (r = s.__html, r != null) {
            if (u.children != null) throw Error(a(60));
            e.innerHTML = r;
          }
        }
        break;
      case "children":
        typeof s == "string" ? Qr(e, s) : (typeof s == "number" || typeof s == "bigint") && Qr(e, "" + s);
        break;
      case "onScroll":
        s != null && Ce("scroll", e);
        break;
      case "onScrollEnd":
        s != null && Ce("scrollend", e);
        break;
      case "onClick":
        s != null && (e.onclick = Ga);
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        if (!Pf.hasOwnProperty(r))
          e: {
            if (r[0] === "o" && r[1] === "n" && (u = r.endsWith("Capture"), t = r.slice(2, u ? r.length - 7 : void 0), f = e[zt] || null, f = f != null ? f[r] : null, typeof f == "function" && e.removeEventListener(t, f, u), typeof s == "function")) {
              typeof f != "function" && f !== null && (r in e ? e[r] = null : e.hasAttribute(r) && e.removeAttribute(r)), e.addEventListener(t, s, u);
              break e;
            }
            r in e ? e[r] = s : s === !0 ? e.setAttribute(r, "") : rl(e, r, s);
          }
    }
  }
  function St(e, t, r) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        Ce("error", e), Ce("load", e);
        var s = !1, u = !1, f;
        for (f in r)
          if (r.hasOwnProperty(f)) {
            var v = r[f];
            if (v != null)
              switch (f) {
                case "src":
                  s = !0;
                  break;
                case "srcSet":
                  u = !0;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  throw Error(a(137, t));
                default:
                  Xe(e, t, f, v, r, null);
              }
          }
        u && Xe(e, t, "srcSet", r.srcSet, r, null), s && Xe(e, t, "src", r.src, r, null);
        return;
      case "input":
        Ce("invalid", e);
        var x = f = v = u = null, E = null, z = null;
        for (s in r)
          if (r.hasOwnProperty(s)) {
            var V = r[s];
            if (V != null)
              switch (s) {
                case "name":
                  u = V;
                  break;
                case "type":
                  v = V;
                  break;
                case "checked":
                  E = V;
                  break;
                case "defaultChecked":
                  z = V;
                  break;
                case "value":
                  f = V;
                  break;
                case "defaultValue":
                  x = V;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  if (V != null)
                    throw Error(a(137, t));
                  break;
                default:
                  Xe(e, t, s, V, r, null);
              }
          }
        Zf(
          e,
          f,
          x,
          E,
          z,
          v,
          u,
          !1
        );
        return;
      case "select":
        Ce("invalid", e), s = v = f = null;
        for (u in r)
          if (r.hasOwnProperty(u) && (x = r[u], x != null))
            switch (u) {
              case "value":
                f = x;
                break;
              case "defaultValue":
                v = x;
                break;
              case "multiple":
                s = x;
              default:
                Xe(e, t, u, x, r, null);
            }
        t = f, r = v, e.multiple = !!s, t != null ? qr(e, !!s, t, !1) : r != null && qr(e, !!s, r, !0);
        return;
      case "textarea":
        Ce("invalid", e), f = u = s = null;
        for (v in r)
          if (r.hasOwnProperty(v) && (x = r[v], x != null))
            switch (v) {
              case "value":
                s = x;
                break;
              case "defaultValue":
                u = x;
                break;
              case "children":
                f = x;
                break;
              case "dangerouslySetInnerHTML":
                if (x != null) throw Error(a(91));
                break;
              default:
                Xe(e, t, v, x, r, null);
            }
        Wf(e, s, u, f);
        return;
      case "option":
        for (E in r)
          r.hasOwnProperty(E) && (s = r[E], s != null) && (E === "selected" ? e.selected = s && typeof s != "function" && typeof s != "symbol" : Xe(e, t, E, s, r, null));
        return;
      case "dialog":
        Ce("beforetoggle", e), Ce("toggle", e), Ce("cancel", e), Ce("close", e);
        break;
      case "iframe":
      case "object":
        Ce("load", e);
        break;
      case "video":
      case "audio":
        for (s = 0; s < _o.length; s++)
          Ce(_o[s], e);
        break;
      case "image":
        Ce("error", e), Ce("load", e);
        break;
      case "details":
        Ce("toggle", e);
        break;
      case "embed":
      case "source":
      case "link":
        Ce("error", e), Ce("load", e);
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (z in r)
          if (r.hasOwnProperty(z) && (s = r[z], s != null))
            switch (z) {
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(a(137, t));
              default:
                Xe(e, t, z, s, r, null);
            }
        return;
      default:
        if (_c(t)) {
          for (V in r)
            r.hasOwnProperty(V) && (s = r[V], s !== void 0 && sd(
              e,
              t,
              V,
              s,
              r,
              void 0
            ));
          return;
        }
    }
    for (x in r)
      r.hasOwnProperty(x) && (s = r[x], s != null && Xe(e, t, x, s, r, null));
  }
  function dx(e, t, r, s) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var u = null, f = null, v = null, x = null, E = null, z = null, V = null;
        for (U in r) {
          var X = r[U];
          if (r.hasOwnProperty(U) && X != null)
            switch (U) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                E = X;
              default:
                s.hasOwnProperty(U) || Xe(e, t, U, null, s, X);
            }
        }
        for (var Y in s) {
          var U = s[Y];
          if (X = r[Y], s.hasOwnProperty(Y) && (U != null || X != null))
            switch (Y) {
              case "type":
                f = U;
                break;
              case "name":
                u = U;
                break;
              case "checked":
                z = U;
                break;
              case "defaultChecked":
                V = U;
                break;
              case "value":
                v = U;
                break;
              case "defaultValue":
                x = U;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (U != null)
                  throw Error(a(137, t));
                break;
              default:
                U !== X && Xe(
                  e,
                  t,
                  Y,
                  U,
                  s,
                  X
                );
            }
        }
        xc(
          e,
          v,
          x,
          E,
          z,
          V,
          f,
          u
        );
        return;
      case "select":
        U = v = x = Y = null;
        for (f in r)
          if (E = r[f], r.hasOwnProperty(f) && E != null)
            switch (f) {
              case "value":
                break;
              case "multiple":
                U = E;
              default:
                s.hasOwnProperty(f) || Xe(
                  e,
                  t,
                  f,
                  null,
                  s,
                  E
                );
            }
        for (u in s)
          if (f = s[u], E = r[u], s.hasOwnProperty(u) && (f != null || E != null))
            switch (u) {
              case "value":
                Y = f;
                break;
              case "defaultValue":
                x = f;
                break;
              case "multiple":
                v = f;
              default:
                f !== E && Xe(
                  e,
                  t,
                  u,
                  f,
                  s,
                  E
                );
            }
        t = x, r = v, s = U, Y != null ? qr(e, !!r, Y, !1) : !!s != !!r && (t != null ? qr(e, !!r, t, !0) : qr(e, !!r, r ? [] : "", !1));
        return;
      case "textarea":
        U = Y = null;
        for (x in r)
          if (u = r[x], r.hasOwnProperty(x) && u != null && !s.hasOwnProperty(x))
            switch (x) {
              case "value":
                break;
              case "children":
                break;
              default:
                Xe(e, t, x, null, s, u);
            }
        for (v in s)
          if (u = s[v], f = r[v], s.hasOwnProperty(v) && (u != null || f != null))
            switch (v) {
              case "value":
                Y = u;
                break;
              case "defaultValue":
                U = u;
                break;
              case "children":
                break;
              case "dangerouslySetInnerHTML":
                if (u != null) throw Error(a(91));
                break;
              default:
                u !== f && Xe(e, t, v, u, s, f);
            }
        Kf(e, Y, U);
        return;
      case "option":
        for (var ce in r)
          Y = r[ce], r.hasOwnProperty(ce) && Y != null && !s.hasOwnProperty(ce) && (ce === "selected" ? e.selected = !1 : Xe(
            e,
            t,
            ce,
            null,
            s,
            Y
          ));
        for (E in s)
          Y = s[E], U = r[E], s.hasOwnProperty(E) && Y !== U && (Y != null || U != null) && (E === "selected" ? e.selected = Y && typeof Y != "function" && typeof Y != "symbol" : Xe(
            e,
            t,
            E,
            Y,
            s,
            U
          ));
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var ye in r)
          Y = r[ye], r.hasOwnProperty(ye) && Y != null && !s.hasOwnProperty(ye) && Xe(e, t, ye, null, s, Y);
        for (z in s)
          if (Y = s[z], U = r[z], s.hasOwnProperty(z) && Y !== U && (Y != null || U != null))
            switch (z) {
              case "children":
              case "dangerouslySetInnerHTML":
                if (Y != null)
                  throw Error(a(137, t));
                break;
              default:
                Xe(
                  e,
                  t,
                  z,
                  Y,
                  s,
                  U
                );
            }
        return;
      default:
        if (_c(t)) {
          for (var Ze in r)
            Y = r[Ze], r.hasOwnProperty(Ze) && Y !== void 0 && !s.hasOwnProperty(Ze) && sd(
              e,
              t,
              Ze,
              void 0,
              s,
              Y
            );
          for (V in s)
            Y = s[V], U = r[V], !s.hasOwnProperty(V) || Y === U || Y === void 0 && U === void 0 || sd(
              e,
              t,
              V,
              Y,
              s,
              U
            );
          return;
        }
    }
    for (var A in r)
      Y = r[A], r.hasOwnProperty(A) && Y != null && !s.hasOwnProperty(A) && Xe(e, t, A, null, s, Y);
    for (X in s)
      Y = s[X], U = r[X], !s.hasOwnProperty(X) || Y === U || Y == null && U == null || Xe(e, t, X, Y, s, U);
  }
  function $m(e) {
    switch (e) {
      case "css":
      case "script":
      case "font":
      case "img":
      case "image":
      case "input":
      case "link":
        return !0;
      default:
        return !1;
    }
  }
  function fx() {
    if (typeof performance.getEntriesByType == "function") {
      for (var e = 0, t = 0, r = performance.getEntriesByType("resource"), s = 0; s < r.length; s++) {
        var u = r[s], f = u.transferSize, v = u.initiatorType, x = u.duration;
        if (f && x && $m(v)) {
          for (v = 0, x = u.responseEnd, s += 1; s < r.length; s++) {
            var E = r[s], z = E.startTime;
            if (z > x) break;
            var V = E.transferSize, X = E.initiatorType;
            V && $m(X) && (E = E.responseEnd, v += V * (E < x ? 1 : (x - z) / (E - z)));
          }
          if (--s, t += 8 * (f + v) / (u.duration / 1e3), e++, 10 < e) break;
        }
      }
      if (0 < e) return t / e / 1e6;
    }
    return navigator.connection && (e = navigator.connection.downlink, typeof e == "number") ? e : 5;
  }
  var cd = null, ud = null;
  function as(e) {
    return e.nodeType === 9 ? e : e.ownerDocument;
  }
  function eg(e) {
    switch (e) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function tg(e, t) {
    if (e === 0)
      switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
    return e === 1 && t === "foreignObject" ? 0 : e;
  }
  function dd(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
  }
  var fd = null;
  function px() {
    var e = window.event;
    return e && e.type === "popstate" ? e === fd ? !1 : (fd = e, !0) : (fd = null, !1);
  }
  var ag = typeof setTimeout == "function" ? setTimeout : void 0, hx = typeof clearTimeout == "function" ? clearTimeout : void 0, ng = typeof Promise == "function" ? Promise : void 0, mx = typeof queueMicrotask == "function" ? queueMicrotask : typeof ng < "u" ? function(e) {
    return ng.resolve(null).then(e).catch(gx);
  } : ag;
  function gx(e) {
    setTimeout(function() {
      throw e;
    });
  }
  function Hn(e) {
    return e === "head";
  }
  function rg(e, t) {
    var r = t, s = 0;
    do {
      var u = r.nextSibling;
      if (e.removeChild(r), u && u.nodeType === 8)
        if (r = u.data, r === "/$" || r === "/&") {
          if (s === 0) {
            e.removeChild(u), yi(t);
            return;
          }
          s--;
        } else if (r === "$" || r === "$?" || r === "$~" || r === "$!" || r === "&")
          s++;
        else if (r === "html")
          So(e.ownerDocument.documentElement);
        else if (r === "head") {
          r = e.ownerDocument.head, So(r);
          for (var f = r.firstChild; f; ) {
            var v = f.nextSibling, x = f.nodeName;
            f[qi] || x === "SCRIPT" || x === "STYLE" || x === "LINK" && f.rel.toLowerCase() === "stylesheet" || r.removeChild(f), f = v;
          }
        } else
          r === "body" && So(e.ownerDocument.body);
      r = u;
    } while (r);
    yi(t);
  }
  function ig(e, t) {
    var r = e;
    e = 0;
    do {
      var s = r.nextSibling;
      if (r.nodeType === 1 ? t ? (r._stashedDisplay = r.style.display, r.style.display = "none") : (r.style.display = r._stashedDisplay || "", r.getAttribute("style") === "" && r.removeAttribute("style")) : r.nodeType === 3 && (t ? (r._stashedText = r.nodeValue, r.nodeValue = "") : r.nodeValue = r._stashedText || ""), s && s.nodeType === 8)
        if (r = s.data, r === "/$") {
          if (e === 0) break;
          e--;
        } else
          r !== "$" && r !== "$?" && r !== "$~" && r !== "$!" || e++;
      r = s;
    } while (r);
  }
  function pd(e) {
    var t = e.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var r = t;
      switch (t = t.nextSibling, r.nodeName) {
        case "HTML":
        case "HEAD":
        case "BODY":
          pd(r), bc(r);
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (r.rel.toLowerCase() === "stylesheet") continue;
      }
      e.removeChild(r);
    }
  }
  function vx(e, t, r, s) {
    for (; e.nodeType === 1; ) {
      var u = r;
      if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!s && (e.nodeName !== "INPUT" || e.type !== "hidden"))
          break;
      } else if (s) {
        if (!e[qi])
          switch (t) {
            case "meta":
              if (!e.hasAttribute("itemprop")) break;
              return e;
            case "link":
              if (f = e.getAttribute("rel"), f === "stylesheet" && e.hasAttribute("data-precedence"))
                break;
              if (f !== u.rel || e.getAttribute("href") !== (u.href == null || u.href === "" ? null : u.href) || e.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin) || e.getAttribute("title") !== (u.title == null ? null : u.title))
                break;
              return e;
            case "style":
              if (e.hasAttribute("data-precedence")) break;
              return e;
            case "script":
              if (f = e.getAttribute("src"), (f !== (u.src == null ? null : u.src) || e.getAttribute("type") !== (u.type == null ? null : u.type) || e.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin)) && f && e.hasAttribute("async") && !e.hasAttribute("itemprop"))
                break;
              return e;
            default:
              return e;
          }
      } else if (t === "input" && e.type === "hidden") {
        var f = u.name == null ? null : "" + u.name;
        if (u.type === "hidden" && e.getAttribute("name") === f)
          return e;
      } else return e;
      if (e = pa(e.nextSibling), e === null) break;
    }
    return null;
  }
  function bx(e, t, r) {
    if (t === "") return null;
    for (; e.nodeType !== 3; )
      if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !r || (e = pa(e.nextSibling), e === null)) return null;
    return e;
  }
  function og(e, t) {
    for (; e.nodeType !== 8; )
      if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !t || (e = pa(e.nextSibling), e === null)) return null;
    return e;
  }
  function hd(e) {
    return e.data === "$?" || e.data === "$~";
  }
  function md(e) {
    return e.data === "$!" || e.data === "$?" && e.ownerDocument.readyState !== "loading";
  }
  function yx(e, t) {
    var r = e.ownerDocument;
    if (e.data === "$~") e._reactRetry = t;
    else if (e.data !== "$?" || r.readyState !== "loading")
      t();
    else {
      var s = function() {
        t(), r.removeEventListener("DOMContentLoaded", s);
      };
      r.addEventListener("DOMContentLoaded", s), e._reactRetry = s;
    }
  }
  function pa(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (t = e.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F")
          break;
        if (t === "/$" || t === "/&") return null;
      }
    }
    return e;
  }
  var gd = null;
  function lg(e) {
    e = e.nextSibling;
    for (var t = 0; e; ) {
      if (e.nodeType === 8) {
        var r = e.data;
        if (r === "/$" || r === "/&") {
          if (t === 0)
            return pa(e.nextSibling);
          t--;
        } else
          r !== "$" && r !== "$!" && r !== "$?" && r !== "$~" && r !== "&" || t++;
      }
      e = e.nextSibling;
    }
    return null;
  }
  function sg(e) {
    e = e.previousSibling;
    for (var t = 0; e; ) {
      if (e.nodeType === 8) {
        var r = e.data;
        if (r === "$" || r === "$!" || r === "$?" || r === "$~" || r === "&") {
          if (t === 0) return e;
          t--;
        } else r !== "/$" && r !== "/&" || t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  function cg(e, t, r) {
    switch (t = as(r), e) {
      case "html":
        if (e = t.documentElement, !e) throw Error(a(452));
        return e;
      case "head":
        if (e = t.head, !e) throw Error(a(453));
        return e;
      case "body":
        if (e = t.body, !e) throw Error(a(454));
        return e;
      default:
        throw Error(a(451));
    }
  }
  function So(e) {
    for (var t = e.attributes; t.length; )
      e.removeAttributeNode(t[0]);
    bc(e);
  }
  var ha = /* @__PURE__ */ new Map(), ug = /* @__PURE__ */ new Set();
  function ns(e) {
    return typeof e.getRootNode == "function" ? e.getRootNode() : e.nodeType === 9 ? e : e.ownerDocument;
  }
  var cn = Q.d;
  Q.d = {
    f: xx,
    r: wx,
    D: _x,
    C: kx,
    L: Sx,
    m: Dx,
    X: Mx,
    S: Ex,
    M: Tx
  };
  function xx() {
    var e = cn.f(), t = Zl();
    return e || t;
  }
  function wx(e) {
    var t = Hr(e);
    t !== null && t.tag === 5 && t.type === "form" ? Mh(t) : cn.r(e);
  }
  var gi = typeof document > "u" ? null : document;
  function dg(e, t, r) {
    var s = gi;
    if (s && typeof t == "string" && t) {
      var u = oa(t);
      u = 'link[rel="' + e + '"][href="' + u + '"]', typeof r == "string" && (u += '[crossorigin="' + r + '"]'), ug.has(u) || (ug.add(u), e = { rel: e, crossOrigin: r, href: t }, s.querySelector(u) === null && (t = s.createElement("link"), St(t, "link", e), bt(t), s.head.appendChild(t)));
    }
  }
  function _x(e) {
    cn.D(e), dg("dns-prefetch", e, null);
  }
  function kx(e, t) {
    cn.C(e, t), dg("preconnect", e, t);
  }
  function Sx(e, t, r) {
    cn.L(e, t, r);
    var s = gi;
    if (s && e && t) {
      var u = 'link[rel="preload"][as="' + oa(t) + '"]';
      t === "image" && r && r.imageSrcSet ? (u += '[imagesrcset="' + oa(
        r.imageSrcSet
      ) + '"]', typeof r.imageSizes == "string" && (u += '[imagesizes="' + oa(
        r.imageSizes
      ) + '"]')) : u += '[href="' + oa(e) + '"]';
      var f = u;
      switch (t) {
        case "style":
          f = vi(e);
          break;
        case "script":
          f = bi(e);
      }
      ha.has(f) || (e = b(
        {
          rel: "preload",
          href: t === "image" && r && r.imageSrcSet ? void 0 : e,
          as: t
        },
        r
      ), ha.set(f, e), s.querySelector(u) !== null || t === "style" && s.querySelector(Do(f)) || t === "script" && s.querySelector(Eo(f)) || (t = s.createElement("link"), St(t, "link", e), bt(t), s.head.appendChild(t)));
    }
  }
  function Dx(e, t) {
    cn.m(e, t);
    var r = gi;
    if (r && e) {
      var s = t && typeof t.as == "string" ? t.as : "script", u = 'link[rel="modulepreload"][as="' + oa(s) + '"][href="' + oa(e) + '"]', f = u;
      switch (s) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          f = bi(e);
      }
      if (!ha.has(f) && (e = b({ rel: "modulepreload", href: e }, t), ha.set(f, e), r.querySelector(u) === null)) {
        switch (s) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (r.querySelector(Eo(f)))
              return;
        }
        s = r.createElement("link"), St(s, "link", e), bt(s), r.head.appendChild(s);
      }
    }
  }
  function Ex(e, t, r) {
    cn.S(e, t, r);
    var s = gi;
    if (s && e) {
      var u = Ur(s).hoistableStyles, f = vi(e);
      t = t || "default";
      var v = u.get(f);
      if (!v) {
        var x = { loading: 0, preload: null };
        if (v = s.querySelector(
          Do(f)
        ))
          x.loading = 5;
        else {
          e = b(
            { rel: "stylesheet", href: e, "data-precedence": t },
            r
          ), (r = ha.get(f)) && vd(e, r);
          var E = v = s.createElement("link");
          bt(E), St(E, "link", e), E._p = new Promise(function(z, V) {
            E.onload = z, E.onerror = V;
          }), E.addEventListener("load", function() {
            x.loading |= 1;
          }), E.addEventListener("error", function() {
            x.loading |= 2;
          }), x.loading |= 4, rs(v, t, s);
        }
        v = {
          type: "stylesheet",
          instance: v,
          count: 1,
          state: x
        }, u.set(f, v);
      }
    }
  }
  function Mx(e, t) {
    cn.X(e, t);
    var r = gi;
    if (r && e) {
      var s = Ur(r).hoistableScripts, u = bi(e), f = s.get(u);
      f || (f = r.querySelector(Eo(u)), f || (e = b({ src: e, async: !0 }, t), (t = ha.get(u)) && bd(e, t), f = r.createElement("script"), bt(f), St(f, "link", e), r.head.appendChild(f)), f = {
        type: "script",
        instance: f,
        count: 1,
        state: null
      }, s.set(u, f));
    }
  }
  function Tx(e, t) {
    cn.M(e, t);
    var r = gi;
    if (r && e) {
      var s = Ur(r).hoistableScripts, u = bi(e), f = s.get(u);
      f || (f = r.querySelector(Eo(u)), f || (e = b({ src: e, async: !0, type: "module" }, t), (t = ha.get(u)) && bd(e, t), f = r.createElement("script"), bt(f), St(f, "link", e), r.head.appendChild(f)), f = {
        type: "script",
        instance: f,
        count: 1,
        state: null
      }, s.set(u, f));
    }
  }
  function fg(e, t, r, s) {
    var u = (u = pe.current) ? ns(u) : null;
    if (!u) throw Error(a(446));
    switch (e) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof r.precedence == "string" && typeof r.href == "string" ? (t = vi(r.href), r = Ur(
          u
        ).hoistableStyles, s = r.get(t), s || (s = {
          type: "style",
          instance: null,
          count: 0,
          state: null
        }, r.set(t, s)), s) : { type: "void", instance: null, count: 0, state: null };
      case "link":
        if (r.rel === "stylesheet" && typeof r.href == "string" && typeof r.precedence == "string") {
          e = vi(r.href);
          var f = Ur(
            u
          ).hoistableStyles, v = f.get(e);
          if (v || (u = u.ownerDocument || u, v = {
            type: "stylesheet",
            instance: null,
            count: 0,
            state: { loading: 0, preload: null }
          }, f.set(e, v), (f = u.querySelector(
            Do(e)
          )) && !f._p && (v.instance = f, v.state.loading = 5), ha.has(e) || (r = {
            rel: "preload",
            as: "style",
            href: r.href,
            crossOrigin: r.crossOrigin,
            integrity: r.integrity,
            media: r.media,
            hrefLang: r.hrefLang,
            referrerPolicy: r.referrerPolicy
          }, ha.set(e, r), f || Cx(
            u,
            e,
            r,
            v.state
          ))), t && s === null)
            throw Error(a(528, ""));
          return v;
        }
        if (t && s !== null)
          throw Error(a(529, ""));
        return null;
      case "script":
        return t = r.async, r = r.src, typeof r == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = bi(r), r = Ur(
          u
        ).hoistableScripts, s = r.get(t), s || (s = {
          type: "script",
          instance: null,
          count: 0,
          state: null
        }, r.set(t, s)), s) : { type: "void", instance: null, count: 0, state: null };
      default:
        throw Error(a(444, e));
    }
  }
  function vi(e) {
    return 'href="' + oa(e) + '"';
  }
  function Do(e) {
    return 'link[rel="stylesheet"][' + e + "]";
  }
  function pg(e) {
    return b({}, e, {
      "data-precedence": e.precedence,
      precedence: null
    });
  }
  function Cx(e, t, r, s) {
    e.querySelector('link[rel="preload"][as="style"][' + t + "]") ? s.loading = 1 : (t = e.createElement("link"), s.preload = t, t.addEventListener("load", function() {
      return s.loading |= 1;
    }), t.addEventListener("error", function() {
      return s.loading |= 2;
    }), St(t, "link", r), bt(t), e.head.appendChild(t));
  }
  function bi(e) {
    return '[src="' + oa(e) + '"]';
  }
  function Eo(e) {
    return "script[async]" + e;
  }
  function hg(e, t, r) {
    if (t.count++, t.instance === null)
      switch (t.type) {
        case "style":
          var s = e.querySelector(
            'style[data-href~="' + oa(r.href) + '"]'
          );
          if (s)
            return t.instance = s, bt(s), s;
          var u = b({}, r, {
            "data-href": r.href,
            "data-precedence": r.precedence,
            href: null,
            precedence: null
          });
          return s = (e.ownerDocument || e).createElement(
            "style"
          ), bt(s), St(s, "style", u), rs(s, r.precedence, e), t.instance = s;
        case "stylesheet":
          u = vi(r.href);
          var f = e.querySelector(
            Do(u)
          );
          if (f)
            return t.state.loading |= 4, t.instance = f, bt(f), f;
          s = pg(r), (u = ha.get(u)) && vd(s, u), f = (e.ownerDocument || e).createElement("link"), bt(f);
          var v = f;
          return v._p = new Promise(function(x, E) {
            v.onload = x, v.onerror = E;
          }), St(f, "link", s), t.state.loading |= 4, rs(f, r.precedence, e), t.instance = f;
        case "script":
          return f = bi(r.src), (u = e.querySelector(
            Eo(f)
          )) ? (t.instance = u, bt(u), u) : (s = r, (u = ha.get(f)) && (s = b({}, r), bd(s, u)), e = e.ownerDocument || e, u = e.createElement("script"), bt(u), St(u, "link", s), e.head.appendChild(u), t.instance = u);
        case "void":
          return null;
        default:
          throw Error(a(443, t.type));
      }
    else
      t.type === "stylesheet" && (t.state.loading & 4) === 0 && (s = t.instance, t.state.loading |= 4, rs(s, r.precedence, e));
    return t.instance;
  }
  function rs(e, t, r) {
    for (var s = r.querySelectorAll(
      'link[rel="stylesheet"][data-precedence],style[data-precedence]'
    ), u = s.length ? s[s.length - 1] : null, f = u, v = 0; v < s.length; v++) {
      var x = s[v];
      if (x.dataset.precedence === t) f = x;
      else if (f !== u) break;
    }
    f ? f.parentNode.insertBefore(e, f.nextSibling) : (t = r.nodeType === 9 ? r.head : r, t.insertBefore(e, t.firstChild));
  }
  function vd(e, t) {
    e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.title == null && (e.title = t.title);
  }
  function bd(e, t) {
    e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.integrity == null && (e.integrity = t.integrity);
  }
  var is = null;
  function mg(e, t, r) {
    if (is === null) {
      var s = /* @__PURE__ */ new Map(), u = is = /* @__PURE__ */ new Map();
      u.set(r, s);
    } else
      u = is, s = u.get(r), s || (s = /* @__PURE__ */ new Map(), u.set(r, s));
    if (s.has(e)) return s;
    for (s.set(e, null), r = r.getElementsByTagName(e), u = 0; u < r.length; u++) {
      var f = r[u];
      if (!(f[qi] || f[xt] || e === "link" && f.getAttribute("rel") === "stylesheet") && f.namespaceURI !== "http://www.w3.org/2000/svg") {
        var v = f.getAttribute(t) || "";
        v = e + v;
        var x = s.get(v);
        x ? x.push(f) : s.set(v, [f]);
      }
    }
    return s;
  }
  function gg(e, t, r) {
    e = e.ownerDocument || e, e.head.insertBefore(
      r,
      t === "title" ? e.querySelector("head > title") : null
    );
  }
  function Nx(e, t, r) {
    if (r === 1 || t.itemProp != null) return !1;
    switch (e) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "")
          break;
        return !0;
      case "link":
        if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError)
          break;
        return t.rel === "stylesheet" ? (e = t.disabled, typeof t.precedence == "string" && e == null) : !0;
      case "script":
        if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string")
          return !0;
    }
    return !1;
  }
  function vg(e) {
    return !(e.type === "stylesheet" && (e.state.loading & 3) === 0);
  }
  function Ox(e, t, r, s) {
    if (r.type === "stylesheet" && (typeof s.media != "string" || matchMedia(s.media).matches !== !1) && (r.state.loading & 4) === 0) {
      if (r.instance === null) {
        var u = vi(s.href), f = t.querySelector(
          Do(u)
        );
        if (f) {
          t = f._p, t !== null && typeof t == "object" && typeof t.then == "function" && (e.count++, e = os.bind(e), t.then(e, e)), r.state.loading |= 4, r.instance = f, bt(f);
          return;
        }
        f = t.ownerDocument || t, s = pg(s), (u = ha.get(u)) && vd(s, u), f = f.createElement("link"), bt(f);
        var v = f;
        v._p = new Promise(function(x, E) {
          v.onload = x, v.onerror = E;
        }), St(f, "link", s), r.instance = f;
      }
      e.stylesheets === null && (e.stylesheets = /* @__PURE__ */ new Map()), e.stylesheets.set(r, t), (t = r.state.preload) && (r.state.loading & 3) === 0 && (e.count++, r = os.bind(e), t.addEventListener("load", r), t.addEventListener("error", r));
    }
  }
  var yd = 0;
  function jx(e, t) {
    return e.stylesheets && e.count === 0 && ss(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(r) {
      var s = setTimeout(function() {
        if (e.stylesheets && ss(e, e.stylesheets), e.unsuspend) {
          var f = e.unsuspend;
          e.unsuspend = null, f();
        }
      }, 6e4 + t);
      0 < e.imgBytes && yd === 0 && (yd = 62500 * fx());
      var u = setTimeout(
        function() {
          if (e.waitingForImages = !1, e.count === 0 && (e.stylesheets && ss(e, e.stylesheets), e.unsuspend)) {
            var f = e.unsuspend;
            e.unsuspend = null, f();
          }
        },
        (e.imgBytes > yd ? 50 : 800) + t
      );
      return e.unsuspend = r, function() {
        e.unsuspend = null, clearTimeout(s), clearTimeout(u);
      };
    } : null;
  }
  function os() {
    if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
      if (this.stylesheets) ss(this, this.stylesheets);
      else if (this.unsuspend) {
        var e = this.unsuspend;
        this.unsuspend = null, e();
      }
    }
  }
  var ls = null;
  function ss(e, t) {
    e.stylesheets = null, e.unsuspend !== null && (e.count++, ls = /* @__PURE__ */ new Map(), t.forEach(Ax, e), ls = null, os.call(e));
  }
  function Ax(e, t) {
    if (!(t.state.loading & 4)) {
      var r = ls.get(e);
      if (r) var s = r.get(null);
      else {
        r = /* @__PURE__ */ new Map(), ls.set(e, r);
        for (var u = e.querySelectorAll(
          "link[data-precedence],style[data-precedence]"
        ), f = 0; f < u.length; f++) {
          var v = u[f];
          (v.nodeName === "LINK" || v.getAttribute("media") !== "not all") && (r.set(v.dataset.precedence, v), s = v);
        }
        s && r.set(null, s);
      }
      u = t.instance, v = u.getAttribute("data-precedence"), f = r.get(v) || s, f === s && r.set(null, u), r.set(v, u), this.count++, s = os.bind(this), u.addEventListener("load", s), u.addEventListener("error", s), f ? f.parentNode.insertBefore(u, f.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(u, e.firstChild)), t.state.loading |= 4;
    }
  }
  var Mo = {
    $$typeof: L,
    Provider: null,
    Consumer: null,
    _currentValue: W,
    _currentValue2: W,
    _threadCount: 0
  };
  function Rx(e, t, r, s, u, f, v, x, E) {
    this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = hc(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = hc(0), this.hiddenUpdates = hc(null), this.identifierPrefix = s, this.onUncaughtError = u, this.onCaughtError = f, this.onRecoverableError = v, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = E, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function bg(e, t, r, s, u, f, v, x, E, z, V, X) {
    return e = new Rx(
      e,
      t,
      r,
      v,
      E,
      z,
      V,
      X,
      x
    ), t = 1, f === !0 && (t |= 24), f = It(3, null, null, t), e.current = f, f.stateNode = e, t = Jc(), t.refCount++, e.pooledCache = t, t.refCount++, f.memoizedState = {
      element: s,
      isDehydrated: r,
      cache: t
    }, au(f), e;
  }
  function yg(e) {
    return e ? (e = Kr, e) : Kr;
  }
  function xg(e, t, r, s, u, f) {
    u = yg(u), s.context === null ? s.context = u : s.pendingContext = u, s = Mn(t), s.payload = { element: r }, f = f === void 0 ? null : f, f !== null && (s.callback = f), r = Tn(e, s, t), r !== null && (qt(r, e, t), ro(r, e, t));
  }
  function wg(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
      var r = e.retryLane;
      e.retryLane = r !== 0 && r < t ? r : t;
    }
  }
  function xd(e, t) {
    wg(e, t), (e = e.alternate) && wg(e, t);
  }
  function _g(e) {
    if (e.tag === 13 || e.tag === 31) {
      var t = ir(e, 67108864);
      t !== null && qt(t, e, 67108864), xd(e, 67108864);
    }
  }
  function kg(e) {
    if (e.tag === 13 || e.tag === 31) {
      var t = aa();
      t = mc(t);
      var r = ir(e, t);
      r !== null && qt(r, e, t), xd(e, t);
    }
  }
  var cs = !0;
  function zx(e, t, r, s) {
    var u = j.T;
    j.T = null;
    var f = Q.p;
    try {
      Q.p = 2, wd(e, t, r, s);
    } finally {
      Q.p = f, j.T = u;
    }
  }
  function Lx(e, t, r, s) {
    var u = j.T;
    j.T = null;
    var f = Q.p;
    try {
      Q.p = 8, wd(e, t, r, s);
    } finally {
      Q.p = f, j.T = u;
    }
  }
  function wd(e, t, r, s) {
    if (cs) {
      var u = _d(s);
      if (u === null)
        ld(
          e,
          t,
          s,
          us,
          r
        ), Dg(e, s);
      else if (Hx(
        u,
        e,
        t,
        r,
        s
      ))
        s.stopPropagation();
      else if (Dg(e, s), t & 4 && -1 < Yx.indexOf(e)) {
        for (; u !== null; ) {
          var f = Hr(u);
          if (f !== null)
            switch (f.tag) {
              case 3:
                if (f = f.stateNode, f.current.memoizedState.isDehydrated) {
                  var v = er(f.pendingLanes);
                  if (v !== 0) {
                    var x = f;
                    for (x.pendingLanes |= 2, x.entangledLanes |= 2; v; ) {
                      var E = 1 << 31 - Kt(v);
                      x.entanglements[1] |= E, v &= ~E;
                    }
                    Ra(f), (Ue & 6) === 0 && (Gl = et() + 500, wo(0));
                  }
                }
                break;
              case 31:
              case 13:
                x = ir(f, 2), x !== null && qt(x, f, 2), Zl(), xd(f, 2);
            }
          if (f = _d(s), f === null && ld(
            e,
            t,
            s,
            us,
            r
          ), f === u) break;
          u = f;
        }
        u !== null && s.stopPropagation();
      } else
        ld(
          e,
          t,
          s,
          null,
          r
        );
    }
  }
  function _d(e) {
    return e = Sc(e), kd(e);
  }
  var us = null;
  function kd(e) {
    if (us = null, e = Yr(e), e !== null) {
      var t = c(e);
      if (t === null) e = null;
      else {
        var r = t.tag;
        if (r === 13) {
          if (e = d(t), e !== null) return e;
          e = null;
        } else if (r === 31) {
          if (e = p(t), e !== null) return e;
          e = null;
        } else if (r === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          e = null;
        } else t !== e && (e = null);
      }
    }
    return us = e, null;
  }
  function Sg(e) {
    switch (e) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (Na()) {
          case re:
            return 2;
          case De:
            return 8;
          case ya:
          case fc:
            return 32;
          case Yi:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var Sd = !1, Un = null, Bn = null, qn = null, To = /* @__PURE__ */ new Map(), Co = /* @__PURE__ */ new Map(), Qn = [], Yx = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(
    " "
  );
  function Dg(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Un = null;
        break;
      case "dragenter":
      case "dragleave":
        Bn = null;
        break;
      case "mouseover":
      case "mouseout":
        qn = null;
        break;
      case "pointerover":
      case "pointerout":
        To.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Co.delete(t.pointerId);
    }
  }
  function No(e, t, r, s, u, f) {
    return e === null || e.nativeEvent !== f ? (e = {
      blockedOn: t,
      domEventName: r,
      eventSystemFlags: s,
      nativeEvent: f,
      targetContainers: [u]
    }, t !== null && (t = Hr(t), t !== null && _g(t)), e) : (e.eventSystemFlags |= s, t = e.targetContainers, u !== null && t.indexOf(u) === -1 && t.push(u), e);
  }
  function Hx(e, t, r, s, u) {
    switch (t) {
      case "focusin":
        return Un = No(
          Un,
          e,
          t,
          r,
          s,
          u
        ), !0;
      case "dragenter":
        return Bn = No(
          Bn,
          e,
          t,
          r,
          s,
          u
        ), !0;
      case "mouseover":
        return qn = No(
          qn,
          e,
          t,
          r,
          s,
          u
        ), !0;
      case "pointerover":
        var f = u.pointerId;
        return To.set(
          f,
          No(
            To.get(f) || null,
            e,
            t,
            r,
            s,
            u
          )
        ), !0;
      case "gotpointercapture":
        return f = u.pointerId, Co.set(
          f,
          No(
            Co.get(f) || null,
            e,
            t,
            r,
            s,
            u
          )
        ), !0;
    }
    return !1;
  }
  function Eg(e) {
    var t = Yr(e.target);
    if (t !== null) {
      var r = c(t);
      if (r !== null) {
        if (t = r.tag, t === 13) {
          if (t = d(r), t !== null) {
            e.blockedOn = t, Bf(e.priority, function() {
              kg(r);
            });
            return;
          }
        } else if (t === 31) {
          if (t = p(r), t !== null) {
            e.blockedOn = t, Bf(e.priority, function() {
              kg(r);
            });
            return;
          }
        } else if (t === 3 && r.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = r.tag === 3 ? r.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function ds(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length; ) {
      var r = _d(e.nativeEvent);
      if (r === null) {
        r = e.nativeEvent;
        var s = new r.constructor(
          r.type,
          r
        );
        kc = s, r.target.dispatchEvent(s), kc = null;
      } else
        return t = Hr(r), t !== null && _g(t), e.blockedOn = r, !1;
      t.shift();
    }
    return !0;
  }
  function Mg(e, t, r) {
    ds(e) && r.delete(t);
  }
  function Ux() {
    Sd = !1, Un !== null && ds(Un) && (Un = null), Bn !== null && ds(Bn) && (Bn = null), qn !== null && ds(qn) && (qn = null), To.forEach(Mg), Co.forEach(Mg);
  }
  function fs(e, t) {
    e.blockedOn === t && (e.blockedOn = null, Sd || (Sd = !0, o.unstable_scheduleCallback(
      o.unstable_NormalPriority,
      Ux
    )));
  }
  var ps = null;
  function Tg(e) {
    ps !== e && (ps = e, o.unstable_scheduleCallback(
      o.unstable_NormalPriority,
      function() {
        ps === e && (ps = null);
        for (var t = 0; t < e.length; t += 3) {
          var r = e[t], s = e[t + 1], u = e[t + 2];
          if (typeof s != "function") {
            if (kd(s || r) === null)
              continue;
            break;
          }
          var f = Hr(r);
          f !== null && (e.splice(t, 3), t -= 3, _u(
            f,
            {
              pending: !0,
              data: u,
              method: r.method,
              action: s
            },
            s,
            u
          ));
        }
      }
    ));
  }
  function yi(e) {
    function t(E) {
      return fs(E, e);
    }
    Un !== null && fs(Un, e), Bn !== null && fs(Bn, e), qn !== null && fs(qn, e), To.forEach(t), Co.forEach(t);
    for (var r = 0; r < Qn.length; r++) {
      var s = Qn[r];
      s.blockedOn === e && (s.blockedOn = null);
    }
    for (; 0 < Qn.length && (r = Qn[0], r.blockedOn === null); )
      Eg(r), r.blockedOn === null && Qn.shift();
    if (r = (e.ownerDocument || e).$$reactFormReplay, r != null)
      for (s = 0; s < r.length; s += 3) {
        var u = r[s], f = r[s + 1], v = u[zt] || null;
        if (typeof f == "function")
          v || Tg(r);
        else if (v) {
          var x = null;
          if (f && f.hasAttribute("formAction")) {
            if (u = f, v = f[zt] || null)
              x = v.formAction;
            else if (kd(u) !== null) continue;
          } else x = v.action;
          typeof x == "function" ? r[s + 1] = x : (r.splice(s, 3), s -= 3), Tg(r);
        }
      }
  }
  function Cg() {
    function e(f) {
      f.canIntercept && f.info === "react-transition" && f.intercept({
        handler: function() {
          return new Promise(function(v) {
            return u = v;
          });
        },
        focusReset: "manual",
        scroll: "manual"
      });
    }
    function t() {
      u !== null && (u(), u = null), s || setTimeout(r, 20);
    }
    function r() {
      if (!s && !navigation.transition) {
        var f = navigation.currentEntry;
        f && f.url != null && navigation.navigate(f.url, {
          state: f.getState(),
          info: "react-transition",
          history: "replace"
        });
      }
    }
    if (typeof navigation == "object") {
      var s = !1, u = null;
      return navigation.addEventListener("navigate", e), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(r, 100), function() {
        s = !0, navigation.removeEventListener("navigate", e), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), u !== null && (u(), u = null);
      };
    }
  }
  function Dd(e) {
    this._internalRoot = e;
  }
  hs.prototype.render = Dd.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(a(409));
    var r = t.current, s = aa();
    xg(r, s, e, t, null, null);
  }, hs.prototype.unmount = Dd.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
      this._internalRoot = null;
      var t = e.containerInfo;
      xg(e.current, 2, null, e, null, null), Zl(), t[Lr] = null;
    }
  };
  function hs(e) {
    this._internalRoot = e;
  }
  hs.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
      var t = Uf();
      e = { blockedOn: null, target: e, priority: t };
      for (var r = 0; r < Qn.length && t !== 0 && t < Qn[r].priority; r++) ;
      Qn.splice(r, 0, e), r === 0 && Eg(e);
    }
  };
  var Ng = i.version;
  if (Ng !== "19.2.4")
    throw Error(
      a(
        527,
        Ng,
        "19.2.4"
      )
    );
  Q.findDOMNode = function(e) {
    var t = e._reactInternals;
    if (t === void 0)
      throw typeof e.render == "function" ? Error(a(188)) : (e = Object.keys(e).join(","), Error(a(268, e)));
    return e = g(t), e = e !== null ? y(e) : null, e = e === null ? null : e.stateNode, e;
  };
  var Bx = {
    bundleType: 0,
    version: "19.2.4",
    rendererPackageName: "react-dom",
    currentDispatcherRef: j,
    reconcilerVersion: "19.2.4"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var ms = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!ms.isDisabled && ms.supportsFiber)
      try {
        $n = ms.inject(
          Bx
        ), Zt = ms;
      } catch {
      }
  }
  return jo.createRoot = function(e, t) {
    if (!l(e)) throw Error(a(299));
    var r = !1, s = "", u = Yh, f = Hh, v = Uh;
    return t != null && (t.unstable_strictMode === !0 && (r = !0), t.identifierPrefix !== void 0 && (s = t.identifierPrefix), t.onUncaughtError !== void 0 && (u = t.onUncaughtError), t.onCaughtError !== void 0 && (f = t.onCaughtError), t.onRecoverableError !== void 0 && (v = t.onRecoverableError)), t = bg(
      e,
      1,
      !1,
      null,
      null,
      r,
      s,
      null,
      u,
      f,
      v,
      Cg
    ), e[Lr] = t.current, od(e), new Dd(t);
  }, jo.hydrateRoot = function(e, t, r) {
    if (!l(e)) throw Error(a(299));
    var s = !1, u = "", f = Yh, v = Hh, x = Uh, E = null;
    return r != null && (r.unstable_strictMode === !0 && (s = !0), r.identifierPrefix !== void 0 && (u = r.identifierPrefix), r.onUncaughtError !== void 0 && (f = r.onUncaughtError), r.onCaughtError !== void 0 && (v = r.onCaughtError), r.onRecoverableError !== void 0 && (x = r.onRecoverableError), r.formState !== void 0 && (E = r.formState)), t = bg(
      e,
      1,
      !0,
      t,
      r ?? null,
      s,
      u,
      E,
      f,
      v,
      x,
      Cg
    ), t.context = yg(null), r = t.current, s = aa(), s = mc(s), u = Mn(s), u.callback = null, Tn(r, u, s), r = s, t.current.lanes = r, Bi(t, r), Ra(t), e[Lr] = t.current, od(e), new hs(t);
  }, jo.version = "19.2.4", jo;
}
var Bg;
function Wx() {
  if (Bg) return Td.exports;
  Bg = 1;
  function o() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o);
      } catch (i) {
        console.error(i);
      }
  }
  return o(), Td.exports = Kx(), Td.exports;
}
var Ix = Wx();
const Jx = /* @__PURE__ */ pf(Ix), mf = N.createContext(null);
function $x({ config: o, children: i }) {
  return /* @__PURE__ */ h.jsx(mf.Provider, { value: o, children: i });
}
function e1() {
  const o = N.useContext(mf);
  if (!o) throw new Error("useMeetConfig must be used within MeetConfigProvider");
  return o;
}
function sb() {
  return N.useContext(mf) ?? null;
}
function cb(o, i) {
  return function() {
    return o.apply(i, arguments);
  };
}
const { toString: t1 } = Object.prototype, { getPrototypeOf: gf } = Object, { iterator: Ws, toStringTag: ub } = Symbol, Is = /* @__PURE__ */ ((o) => (i) => {
  const n = t1.call(i);
  return o[n] || (o[n] = n.slice(8, -1).toLowerCase());
})(/* @__PURE__ */ Object.create(null)), Ma = (o) => (o = o.toLowerCase(), (i) => Is(i) === o), Js = (o) => (i) => typeof i === o, { isArray: Ri } = Array, Ei = Js("undefined");
function Po(o) {
  return o !== null && !Ei(o) && o.constructor !== null && !Ei(o.constructor) && Vt(o.constructor.isBuffer) && o.constructor.isBuffer(o);
}
const db = Ma("ArrayBuffer");
function a1(o) {
  let i;
  return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? i = ArrayBuffer.isView(o) : i = o && o.buffer && db(o.buffer), i;
}
const n1 = Js("string"), Vt = Js("function"), fb = Js("number"), Fo = (o) => o !== null && typeof o == "object", r1 = (o) => o === !0 || o === !1, Ts = (o) => {
  if (Is(o) !== "object")
    return !1;
  const i = gf(o);
  return (i === null || i === Object.prototype || Object.getPrototypeOf(i) === null) && !(ub in o) && !(Ws in o);
}, i1 = (o) => {
  if (!Fo(o) || Po(o))
    return !1;
  try {
    return Object.keys(o).length === 0 && Object.getPrototypeOf(o) === Object.prototype;
  } catch {
    return !1;
  }
}, o1 = Ma("Date"), l1 = Ma("File"), s1 = Ma("Blob"), c1 = Ma("FileList"), u1 = (o) => Fo(o) && Vt(o.pipe), d1 = (o) => {
  let i;
  return o && (typeof FormData == "function" && o instanceof FormData || Vt(o.append) && ((i = Is(o)) === "formdata" || // detect form-data instance
  i === "object" && Vt(o.toString) && o.toString() === "[object FormData]"));
}, f1 = Ma("URLSearchParams"), [p1, h1, m1, g1] = [
  "ReadableStream",
  "Request",
  "Response",
  "Headers"
].map(Ma), v1 = (o) => o.trim ? o.trim() : o.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
function Vo(o, i, { allOwnKeys: n = !1 } = {}) {
  if (o === null || typeof o > "u")
    return;
  let a, l;
  if (typeof o != "object" && (o = [o]), Ri(o))
    for (a = 0, l = o.length; a < l; a++)
      i.call(null, o[a], a, o);
  else {
    if (Po(o))
      return;
    const c = n ? Object.getOwnPropertyNames(o) : Object.keys(o), d = c.length;
    let p;
    for (a = 0; a < d; a++)
      p = c[a], i.call(null, o[p], p, o);
  }
}
function pb(o, i) {
  if (Po(o))
    return null;
  i = i.toLowerCase();
  const n = Object.keys(o);
  let a = n.length, l;
  for (; a-- > 0; )
    if (l = n[a], i === l.toLowerCase())
      return l;
  return null;
}
const kr = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, hb = (o) => !Ei(o) && o !== kr;
function Jd() {
  const { caseless: o, skipUndefined: i } = hb(this) && this || {}, n = {}, a = (l, c) => {
    if (c === "__proto__" || c === "constructor" || c === "prototype")
      return;
    const d = o && pb(n, c) || c;
    Ts(n[d]) && Ts(l) ? n[d] = Jd(n[d], l) : Ts(l) ? n[d] = Jd({}, l) : Ri(l) ? n[d] = l.slice() : (!i || !Ei(l)) && (n[d] = l);
  };
  for (let l = 0, c = arguments.length; l < c; l++)
    arguments[l] && Vo(arguments[l], a);
  return n;
}
const b1 = (o, i, n, { allOwnKeys: a } = {}) => (Vo(
  i,
  (l, c) => {
    n && Vt(l) ? Object.defineProperty(o, c, {
      value: cb(l, n),
      writable: !0,
      enumerable: !0,
      configurable: !0
    }) : Object.defineProperty(o, c, {
      value: l,
      writable: !0,
      enumerable: !0,
      configurable: !0
    });
  },
  { allOwnKeys: a }
), o), y1 = (o) => (o.charCodeAt(0) === 65279 && (o = o.slice(1)), o), x1 = (o, i, n, a) => {
  o.prototype = Object.create(
    i.prototype,
    a
  ), Object.defineProperty(o.prototype, "constructor", {
    value: o,
    writable: !0,
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(o, "super", {
    value: i.prototype
  }), n && Object.assign(o.prototype, n);
}, w1 = (o, i, n, a) => {
  let l, c, d;
  const p = {};
  if (i = i || {}, o == null) return i;
  do {
    for (l = Object.getOwnPropertyNames(o), c = l.length; c-- > 0; )
      d = l[c], (!a || a(d, o, i)) && !p[d] && (i[d] = o[d], p[d] = !0);
    o = n !== !1 && gf(o);
  } while (o && (!n || n(o, i)) && o !== Object.prototype);
  return i;
}, _1 = (o, i, n) => {
  o = String(o), (n === void 0 || n > o.length) && (n = o.length), n -= i.length;
  const a = o.indexOf(i, n);
  return a !== -1 && a === n;
}, k1 = (o) => {
  if (!o) return null;
  if (Ri(o)) return o;
  let i = o.length;
  if (!fb(i)) return null;
  const n = new Array(i);
  for (; i-- > 0; )
    n[i] = o[i];
  return n;
}, S1 = /* @__PURE__ */ ((o) => (i) => o && i instanceof o)(typeof Uint8Array < "u" && gf(Uint8Array)), D1 = (o, i) => {
  const a = (o && o[Ws]).call(o);
  let l;
  for (; (l = a.next()) && !l.done; ) {
    const c = l.value;
    i.call(o, c[0], c[1]);
  }
}, E1 = (o, i) => {
  let n;
  const a = [];
  for (; (n = o.exec(i)) !== null; )
    a.push(n);
  return a;
}, M1 = Ma("HTMLFormElement"), T1 = (o) => o.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(n, a, l) {
  return a.toUpperCase() + l;
}), qg = (({ hasOwnProperty: o }) => (i, n) => o.call(i, n))(Object.prototype), C1 = Ma("RegExp"), mb = (o, i) => {
  const n = Object.getOwnPropertyDescriptors(o), a = {};
  Vo(n, (l, c) => {
    let d;
    (d = i(l, c, o)) !== !1 && (a[c] = d || l);
  }), Object.defineProperties(o, a);
}, N1 = (o) => {
  mb(o, (i, n) => {
    if (Vt(o) && ["arguments", "caller", "callee"].indexOf(n) !== -1)
      return !1;
    const a = o[n];
    if (Vt(a)) {
      if (i.enumerable = !1, "writable" in i) {
        i.writable = !1;
        return;
      }
      i.set || (i.set = () => {
        throw Error("Can not rewrite read-only method '" + n + "'");
      });
    }
  });
}, O1 = (o, i) => {
  const n = {}, a = (l) => {
    l.forEach((c) => {
      n[c] = !0;
    });
  };
  return Ri(o) ? a(o) : a(String(o).split(i)), n;
}, j1 = () => {
}, A1 = (o, i) => o != null && Number.isFinite(o = +o) ? o : i;
function R1(o) {
  return !!(o && Vt(o.append) && o[ub] === "FormData" && o[Ws]);
}
const z1 = (o) => {
  const i = new Array(10), n = (a, l) => {
    if (Fo(a)) {
      if (i.indexOf(a) >= 0)
        return;
      if (Po(a))
        return a;
      if (!("toJSON" in a)) {
        i[l] = a;
        const c = Ri(a) ? [] : {};
        return Vo(a, (d, p) => {
          const m = n(d, l + 1);
          !Ei(m) && (c[p] = m);
        }), i[l] = void 0, c;
      }
    }
    return a;
  };
  return n(o, 0);
}, L1 = Ma("AsyncFunction"), Y1 = (o) => o && (Fo(o) || Vt(o)) && Vt(o.then) && Vt(o.catch), gb = ((o, i) => o ? setImmediate : i ? ((n, a) => (kr.addEventListener(
  "message",
  ({ source: l, data: c }) => {
    l === kr && c === n && a.length && a.shift()();
  },
  !1
), (l) => {
  a.push(l), kr.postMessage(n, "*");
}))(`axios@${Math.random()}`, []) : (n) => setTimeout(n))(typeof setImmediate == "function", Vt(kr.postMessage)), H1 = typeof queueMicrotask < "u" ? queueMicrotask.bind(kr) : typeof process < "u" && process.nextTick || gb, U1 = (o) => o != null && Vt(o[Ws]), H = {
  isArray: Ri,
  isArrayBuffer: db,
  isBuffer: Po,
  isFormData: d1,
  isArrayBufferView: a1,
  isString: n1,
  isNumber: fb,
  isBoolean: r1,
  isObject: Fo,
  isPlainObject: Ts,
  isEmptyObject: i1,
  isReadableStream: p1,
  isRequest: h1,
  isResponse: m1,
  isHeaders: g1,
  isUndefined: Ei,
  isDate: o1,
  isFile: l1,
  isBlob: s1,
  isRegExp: C1,
  isFunction: Vt,
  isStream: u1,
  isURLSearchParams: f1,
  isTypedArray: S1,
  isFileList: c1,
  forEach: Vo,
  merge: Jd,
  extend: b1,
  trim: v1,
  stripBOM: y1,
  inherits: x1,
  toFlatObject: w1,
  kindOf: Is,
  kindOfTest: Ma,
  endsWith: _1,
  toArray: k1,
  forEachEntry: D1,
  matchAll: E1,
  isHTMLForm: M1,
  hasOwnProperty: qg,
  hasOwnProp: qg,
  // an alias to avoid ESLint no-prototype-builtins detection
  reduceDescriptors: mb,
  freezeMethods: N1,
  toObjectSet: O1,
  toCamelCase: T1,
  noop: j1,
  toFiniteNumber: A1,
  findKey: pb,
  global: kr,
  isContextDefined: hb,
  isSpecCompliantForm: R1,
  toJSONObject: z1,
  isAsyncFn: L1,
  isThenable: Y1,
  setImmediate: gb,
  asap: H1,
  isIterable: U1
};
let xe = class vb extends Error {
  static from(i, n, a, l, c, d) {
    const p = new vb(i.message, n || i.code, a, l, c);
    return p.cause = i, p.name = i.name, d && Object.assign(p, d), p;
  }
  /**
   * Create an Error with the specified message, config, error code, request and response.
   *
   * @param {string} message The error message.
   * @param {string} [code] The error code (for example, 'ECONNABORTED').
   * @param {Object} [config] The config.
   * @param {Object} [request] The request.
   * @param {Object} [response] The response.
   *
   * @returns {Error} The created error.
   */
  constructor(i, n, a, l, c) {
    super(i), this.name = "AxiosError", this.isAxiosError = !0, n && (this.code = n), a && (this.config = a), l && (this.request = l), c && (this.response = c, this.status = c.status);
  }
  toJSON() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: H.toJSONObject(this.config),
      code: this.code,
      status: this.status
    };
  }
};
xe.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
xe.ERR_BAD_OPTION = "ERR_BAD_OPTION";
xe.ECONNABORTED = "ECONNABORTED";
xe.ETIMEDOUT = "ETIMEDOUT";
xe.ERR_NETWORK = "ERR_NETWORK";
xe.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
xe.ERR_DEPRECATED = "ERR_DEPRECATED";
xe.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
xe.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
xe.ERR_CANCELED = "ERR_CANCELED";
xe.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
xe.ERR_INVALID_URL = "ERR_INVALID_URL";
const B1 = null;
function $d(o) {
  return H.isPlainObject(o) || H.isArray(o);
}
function bb(o) {
  return H.endsWith(o, "[]") ? o.slice(0, -2) : o;
}
function Qg(o, i, n) {
  return o ? o.concat(i).map(function(l, c) {
    return l = bb(l), !n && c ? "[" + l + "]" : l;
  }).join(n ? "." : "") : i;
}
function q1(o) {
  return H.isArray(o) && !o.some($d);
}
const Q1 = H.toFlatObject(H, {}, null, function(i) {
  return /^is[A-Z]/.test(i);
});
function $s(o, i, n) {
  if (!H.isObject(o))
    throw new TypeError("target must be an object");
  i = i || new FormData(), n = H.toFlatObject(n, {
    metaTokens: !0,
    dots: !1,
    indexes: !1
  }, !1, function(D, S) {
    return !H.isUndefined(S[D]);
  });
  const a = n.metaTokens, l = n.visitor || y, c = n.dots, d = n.indexes, m = (n.Blob || typeof Blob < "u" && Blob) && H.isSpecCompliantForm(i);
  if (!H.isFunction(l))
    throw new TypeError("visitor must be a function");
  function g(w) {
    if (w === null) return "";
    if (H.isDate(w))
      return w.toISOString();
    if (H.isBoolean(w))
      return w.toString();
    if (!m && H.isBlob(w))
      throw new xe("Blob is not supported. Use a Buffer instead.");
    return H.isArrayBuffer(w) || H.isTypedArray(w) ? m && typeof Blob == "function" ? new Blob([w]) : Buffer.from(w) : w;
  }
  function y(w, D, S) {
    let O = w;
    if (w && !S && typeof w == "object") {
      if (H.endsWith(D, "{}"))
        D = a ? D : D.slice(0, -2), w = JSON.stringify(w);
      else if (H.isArray(w) && q1(w) || (H.isFileList(w) || H.endsWith(D, "[]")) && (O = H.toArray(w)))
        return D = bb(D), O.forEach(function(L, P) {
          !(H.isUndefined(L) || L === null) && i.append(
            // eslint-disable-next-line no-nested-ternary
            d === !0 ? Qg([D], P, c) : d === null ? D : D + "[]",
            g(L)
          );
        }), !1;
    }
    return $d(w) ? !0 : (i.append(Qg(S, D, c), g(w)), !1);
  }
  const b = [], _ = Object.assign(Q1, {
    defaultVisitor: y,
    convertValue: g,
    isVisitable: $d
  });
  function k(w, D) {
    if (!H.isUndefined(w)) {
      if (b.indexOf(w) !== -1)
        throw Error("Circular reference detected in " + D.join("."));
      b.push(w), H.forEach(w, function(O, q) {
        (!(H.isUndefined(O) || O === null) && l.call(
          i,
          O,
          H.isString(q) ? q.trim() : q,
          D,
          _
        )) === !0 && k(O, D ? D.concat(q) : [q]);
      }), b.pop();
    }
  }
  if (!H.isObject(o))
    throw new TypeError("data must be an object");
  return k(o), i;
}
function Pg(o) {
  const i = {
    "!": "%21",
    "'": "%27",
    "(": "%28",
    ")": "%29",
    "~": "%7E",
    "%20": "+",
    "%00": "\0"
  };
  return encodeURIComponent(o).replace(/[!'()~]|%20|%00/g, function(a) {
    return i[a];
  });
}
function vf(o, i) {
  this._pairs = [], o && $s(o, this, i);
}
const yb = vf.prototype;
yb.append = function(i, n) {
  this._pairs.push([i, n]);
};
yb.toString = function(i) {
  const n = i ? function(a) {
    return i.call(this, a, Pg);
  } : Pg;
  return this._pairs.map(function(l) {
    return n(l[0]) + "=" + n(l[1]);
  }, "").join("&");
};
function P1(o) {
  return encodeURIComponent(o).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
}
function xb(o, i, n) {
  if (!i)
    return o;
  const a = n && n.encode || P1, l = H.isFunction(n) ? {
    serialize: n
  } : n, c = l && l.serialize;
  let d;
  if (c ? d = c(i, l) : d = H.isURLSearchParams(i) ? i.toString() : new vf(i, l).toString(a), d) {
    const p = o.indexOf("#");
    p !== -1 && (o = o.slice(0, p)), o += (o.indexOf("?") === -1 ? "?" : "&") + d;
  }
  return o;
}
class Fg {
  constructor() {
    this.handlers = [];
  }
  /**
   * Add a new interceptor to the stack
   *
   * @param {Function} fulfilled The function to handle `then` for a `Promise`
   * @param {Function} rejected The function to handle `reject` for a `Promise`
   * @param {Object} options The options for the interceptor, synchronous and runWhen
   *
   * @return {Number} An ID used to remove interceptor later
   */
  use(i, n, a) {
    return this.handlers.push({
      fulfilled: i,
      rejected: n,
      synchronous: a ? a.synchronous : !1,
      runWhen: a ? a.runWhen : null
    }), this.handlers.length - 1;
  }
  /**
   * Remove an interceptor from the stack
   *
   * @param {Number} id The ID that was returned by `use`
   *
   * @returns {void}
   */
  eject(i) {
    this.handlers[i] && (this.handlers[i] = null);
  }
  /**
   * Clear all interceptors from the stack
   *
   * @returns {void}
   */
  clear() {
    this.handlers && (this.handlers = []);
  }
  /**
   * Iterate over all the registered interceptors
   *
   * This method is particularly useful for skipping over any
   * interceptors that may have become `null` calling `eject`.
   *
   * @param {Function} fn The function to call for each interceptor
   *
   * @returns {void}
   */
  forEach(i) {
    H.forEach(this.handlers, function(a) {
      a !== null && i(a);
    });
  }
}
const bf = {
  silentJSONParsing: !0,
  forcedJSONParsing: !0,
  clarifyTimeoutError: !1,
  legacyInterceptorReqResOrdering: !0
}, F1 = typeof URLSearchParams < "u" ? URLSearchParams : vf, V1 = typeof FormData < "u" ? FormData : null, G1 = typeof Blob < "u" ? Blob : null, X1 = {
  isBrowser: !0,
  classes: {
    URLSearchParams: F1,
    FormData: V1,
    Blob: G1
  },
  protocols: ["http", "https", "file", "blob", "url", "data"]
}, yf = typeof window < "u" && typeof document < "u", ef = typeof navigator == "object" && navigator || void 0, Z1 = yf && (!ef || ["ReactNative", "NativeScript", "NS"].indexOf(ef.product) < 0), K1 = typeof WorkerGlobalScope < "u" && // eslint-disable-next-line no-undef
self instanceof WorkerGlobalScope && typeof self.importScripts == "function", W1 = yf && window.location.href || "http://localhost", I1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  hasBrowserEnv: yf,
  hasStandardBrowserEnv: Z1,
  hasStandardBrowserWebWorkerEnv: K1,
  navigator: ef,
  origin: W1
}, Symbol.toStringTag, { value: "Module" })), Nt = {
  ...I1,
  ...X1
};
function J1(o, i) {
  return $s(o, new Nt.classes.URLSearchParams(), {
    visitor: function(n, a, l, c) {
      return Nt.isNode && H.isBuffer(n) ? (this.append(a, n.toString("base64")), !1) : c.defaultVisitor.apply(this, arguments);
    },
    ...i
  });
}
function $1(o) {
  return H.matchAll(/\w+|\[(\w*)]/g, o).map((i) => i[0] === "[]" ? "" : i[1] || i[0]);
}
function ew(o) {
  const i = {}, n = Object.keys(o);
  let a;
  const l = n.length;
  let c;
  for (a = 0; a < l; a++)
    c = n[a], i[c] = o[c];
  return i;
}
function wb(o) {
  function i(n, a, l, c) {
    let d = n[c++];
    if (d === "__proto__") return !0;
    const p = Number.isFinite(+d), m = c >= n.length;
    return d = !d && H.isArray(l) ? l.length : d, m ? (H.hasOwnProp(l, d) ? l[d] = [l[d], a] : l[d] = a, !p) : ((!l[d] || !H.isObject(l[d])) && (l[d] = []), i(n, a, l[d], c) && H.isArray(l[d]) && (l[d] = ew(l[d])), !p);
  }
  if (H.isFormData(o) && H.isFunction(o.entries)) {
    const n = {};
    return H.forEachEntry(o, (a, l) => {
      i($1(a), l, n, 0);
    }), n;
  }
  return null;
}
function tw(o, i, n) {
  if (H.isString(o))
    try {
      return (i || JSON.parse)(o), H.trim(o);
    } catch (a) {
      if (a.name !== "SyntaxError")
        throw a;
    }
  return (n || JSON.stringify)(o);
}
const Go = {
  transitional: bf,
  adapter: ["xhr", "http", "fetch"],
  transformRequest: [function(i, n) {
    const a = n.getContentType() || "", l = a.indexOf("application/json") > -1, c = H.isObject(i);
    if (c && H.isHTMLForm(i) && (i = new FormData(i)), H.isFormData(i))
      return l ? JSON.stringify(wb(i)) : i;
    if (H.isArrayBuffer(i) || H.isBuffer(i) || H.isStream(i) || H.isFile(i) || H.isBlob(i) || H.isReadableStream(i))
      return i;
    if (H.isArrayBufferView(i))
      return i.buffer;
    if (H.isURLSearchParams(i))
      return n.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), i.toString();
    let p;
    if (c) {
      if (a.indexOf("application/x-www-form-urlencoded") > -1)
        return J1(i, this.formSerializer).toString();
      if ((p = H.isFileList(i)) || a.indexOf("multipart/form-data") > -1) {
        const m = this.env && this.env.FormData;
        return $s(
          p ? { "files[]": i } : i,
          m && new m(),
          this.formSerializer
        );
      }
    }
    return c || l ? (n.setContentType("application/json", !1), tw(i)) : i;
  }],
  transformResponse: [function(i) {
    const n = this.transitional || Go.transitional, a = n && n.forcedJSONParsing, l = this.responseType === "json";
    if (H.isResponse(i) || H.isReadableStream(i))
      return i;
    if (i && H.isString(i) && (a && !this.responseType || l)) {
      const d = !(n && n.silentJSONParsing) && l;
      try {
        return JSON.parse(i, this.parseReviver);
      } catch (p) {
        if (d)
          throw p.name === "SyntaxError" ? xe.from(p, xe.ERR_BAD_RESPONSE, this, null, this.response) : p;
      }
    }
    return i;
  }],
  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,
  xsrfCookieName: "XSRF-TOKEN",
  xsrfHeaderName: "X-XSRF-TOKEN",
  maxContentLength: -1,
  maxBodyLength: -1,
  env: {
    FormData: Nt.classes.FormData,
    Blob: Nt.classes.Blob
  },
  validateStatus: function(i) {
    return i >= 200 && i < 300;
  },
  headers: {
    common: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": void 0
    }
  }
};
H.forEach(["delete", "get", "head", "post", "put", "patch"], (o) => {
  Go.headers[o] = {};
});
const aw = H.toObjectSet([
  "age",
  "authorization",
  "content-length",
  "content-type",
  "etag",
  "expires",
  "from",
  "host",
  "if-modified-since",
  "if-unmodified-since",
  "last-modified",
  "location",
  "max-forwards",
  "proxy-authorization",
  "referer",
  "retry-after",
  "user-agent"
]), nw = (o) => {
  const i = {};
  let n, a, l;
  return o && o.split(`
`).forEach(function(d) {
    l = d.indexOf(":"), n = d.substring(0, l).trim().toLowerCase(), a = d.substring(l + 1).trim(), !(!n || i[n] && aw[n]) && (n === "set-cookie" ? i[n] ? i[n].push(a) : i[n] = [a] : i[n] = i[n] ? i[n] + ", " + a : a);
  }), i;
}, Vg = /* @__PURE__ */ Symbol("internals");
function Ao(o) {
  return o && String(o).trim().toLowerCase();
}
function Cs(o) {
  return o === !1 || o == null ? o : H.isArray(o) ? o.map(Cs) : String(o);
}
function rw(o) {
  const i = /* @__PURE__ */ Object.create(null), n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
  let a;
  for (; a = n.exec(o); )
    i[a[1]] = a[2];
  return i;
}
const iw = (o) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(o.trim());
function jd(o, i, n, a, l) {
  if (H.isFunction(a))
    return a.call(this, i, n);
  if (l && (i = n), !!H.isString(i)) {
    if (H.isString(a))
      return i.indexOf(a) !== -1;
    if (H.isRegExp(a))
      return a.test(i);
  }
}
function ow(o) {
  return o.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (i, n, a) => n.toUpperCase() + a);
}
function lw(o, i) {
  const n = H.toCamelCase(" " + i);
  ["get", "set", "has"].forEach((a) => {
    Object.defineProperty(o, a + n, {
      value: function(l, c, d) {
        return this[a].call(this, i, l, c, d);
      },
      configurable: !0
    });
  });
}
let Gt = class {
  constructor(i) {
    i && this.set(i);
  }
  set(i, n, a) {
    const l = this;
    function c(p, m, g) {
      const y = Ao(m);
      if (!y)
        throw new Error("header name must be a non-empty string");
      const b = H.findKey(l, y);
      (!b || l[b] === void 0 || g === !0 || g === void 0 && l[b] !== !1) && (l[b || m] = Cs(p));
    }
    const d = (p, m) => H.forEach(p, (g, y) => c(g, y, m));
    if (H.isPlainObject(i) || i instanceof this.constructor)
      d(i, n);
    else if (H.isString(i) && (i = i.trim()) && !iw(i))
      d(nw(i), n);
    else if (H.isObject(i) && H.isIterable(i)) {
      let p = {}, m, g;
      for (const y of i) {
        if (!H.isArray(y))
          throw TypeError("Object iterator must return a key-value pair");
        p[g = y[0]] = (m = p[g]) ? H.isArray(m) ? [...m, y[1]] : [m, y[1]] : y[1];
      }
      d(p, n);
    } else
      i != null && c(n, i, a);
    return this;
  }
  get(i, n) {
    if (i = Ao(i), i) {
      const a = H.findKey(this, i);
      if (a) {
        const l = this[a];
        if (!n)
          return l;
        if (n === !0)
          return rw(l);
        if (H.isFunction(n))
          return n.call(this, l, a);
        if (H.isRegExp(n))
          return n.exec(l);
        throw new TypeError("parser must be boolean|regexp|function");
      }
    }
  }
  has(i, n) {
    if (i = Ao(i), i) {
      const a = H.findKey(this, i);
      return !!(a && this[a] !== void 0 && (!n || jd(this, this[a], a, n)));
    }
    return !1;
  }
  delete(i, n) {
    const a = this;
    let l = !1;
    function c(d) {
      if (d = Ao(d), d) {
        const p = H.findKey(a, d);
        p && (!n || jd(a, a[p], p, n)) && (delete a[p], l = !0);
      }
    }
    return H.isArray(i) ? i.forEach(c) : c(i), l;
  }
  clear(i) {
    const n = Object.keys(this);
    let a = n.length, l = !1;
    for (; a--; ) {
      const c = n[a];
      (!i || jd(this, this[c], c, i, !0)) && (delete this[c], l = !0);
    }
    return l;
  }
  normalize(i) {
    const n = this, a = {};
    return H.forEach(this, (l, c) => {
      const d = H.findKey(a, c);
      if (d) {
        n[d] = Cs(l), delete n[c];
        return;
      }
      const p = i ? ow(c) : String(c).trim();
      p !== c && delete n[c], n[p] = Cs(l), a[p] = !0;
    }), this;
  }
  concat(...i) {
    return this.constructor.concat(this, ...i);
  }
  toJSON(i) {
    const n = /* @__PURE__ */ Object.create(null);
    return H.forEach(this, (a, l) => {
      a != null && a !== !1 && (n[l] = i && H.isArray(a) ? a.join(", ") : a);
    }), n;
  }
  [Symbol.iterator]() {
    return Object.entries(this.toJSON())[Symbol.iterator]();
  }
  toString() {
    return Object.entries(this.toJSON()).map(([i, n]) => i + ": " + n).join(`
`);
  }
  getSetCookie() {
    return this.get("set-cookie") || [];
  }
  get [Symbol.toStringTag]() {
    return "AxiosHeaders";
  }
  static from(i) {
    return i instanceof this ? i : new this(i);
  }
  static concat(i, ...n) {
    const a = new this(i);
    return n.forEach((l) => a.set(l)), a;
  }
  static accessor(i) {
    const a = (this[Vg] = this[Vg] = {
      accessors: {}
    }).accessors, l = this.prototype;
    function c(d) {
      const p = Ao(d);
      a[p] || (lw(l, d), a[p] = !0);
    }
    return H.isArray(i) ? i.forEach(c) : c(i), this;
  }
};
Gt.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
H.reduceDescriptors(Gt.prototype, ({ value: o }, i) => {
  let n = i[0].toUpperCase() + i.slice(1);
  return {
    get: () => o,
    set(a) {
      this[n] = a;
    }
  };
});
H.freezeMethods(Gt);
function Ad(o, i) {
  const n = this || Go, a = i || n, l = Gt.from(a.headers);
  let c = a.data;
  return H.forEach(o, function(p) {
    c = p.call(n, c, l.normalize(), i ? i.status : void 0);
  }), l.normalize(), c;
}
function _b(o) {
  return !!(o && o.__CANCEL__);
}
let Xo = class extends xe {
  /**
   * A `CanceledError` is an object that is thrown when an operation is canceled.
   *
   * @param {string=} message The message.
   * @param {Object=} config The config.
   * @param {Object=} request The request.
   *
   * @returns {CanceledError} The created error.
   */
  constructor(i, n, a) {
    super(i ?? "canceled", xe.ERR_CANCELED, n, a), this.name = "CanceledError", this.__CANCEL__ = !0;
  }
};
function kb(o, i, n) {
  const a = n.config.validateStatus;
  !n.status || !a || a(n.status) ? o(n) : i(new xe(
    "Request failed with status code " + n.status,
    [xe.ERR_BAD_REQUEST, xe.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4],
    n.config,
    n.request,
    n
  ));
}
function sw(o) {
  const i = /^([-+\w]{1,25})(:?\/\/|:)/.exec(o);
  return i && i[1] || "";
}
function cw(o, i) {
  o = o || 10;
  const n = new Array(o), a = new Array(o);
  let l = 0, c = 0, d;
  return i = i !== void 0 ? i : 1e3, function(m) {
    const g = Date.now(), y = a[c];
    d || (d = g), n[l] = m, a[l] = g;
    let b = c, _ = 0;
    for (; b !== l; )
      _ += n[b++], b = b % o;
    if (l = (l + 1) % o, l === c && (c = (c + 1) % o), g - d < i)
      return;
    const k = y && g - y;
    return k ? Math.round(_ * 1e3 / k) : void 0;
  };
}
function uw(o, i) {
  let n = 0, a = 1e3 / i, l, c;
  const d = (g, y = Date.now()) => {
    n = y, l = null, c && (clearTimeout(c), c = null), o(...g);
  };
  return [(...g) => {
    const y = Date.now(), b = y - n;
    b >= a ? d(g, y) : (l = g, c || (c = setTimeout(() => {
      c = null, d(l);
    }, a - b)));
  }, () => l && d(l)];
}
const Ys = (o, i, n = 3) => {
  let a = 0;
  const l = cw(50, 250);
  return uw((c) => {
    const d = c.loaded, p = c.lengthComputable ? c.total : void 0, m = d - a, g = l(m), y = d <= p;
    a = d;
    const b = {
      loaded: d,
      total: p,
      progress: p ? d / p : void 0,
      bytes: m,
      rate: g || void 0,
      estimated: g && p && y ? (p - d) / g : void 0,
      event: c,
      lengthComputable: p != null,
      [i ? "download" : "upload"]: !0
    };
    o(b);
  }, n);
}, Gg = (o, i) => {
  const n = o != null;
  return [(a) => i[0]({
    lengthComputable: n,
    total: o,
    loaded: a
  }), i[1]];
}, Xg = (o) => (...i) => H.asap(() => o(...i)), dw = Nt.hasStandardBrowserEnv ? /* @__PURE__ */ ((o, i) => (n) => (n = new URL(n, Nt.origin), o.protocol === n.protocol && o.host === n.host && (i || o.port === n.port)))(
  new URL(Nt.origin),
  Nt.navigator && /(msie|trident)/i.test(Nt.navigator.userAgent)
) : () => !0, fw = Nt.hasStandardBrowserEnv ? (
  // Standard browser envs support document.cookie
  {
    write(o, i, n, a, l, c, d) {
      if (typeof document > "u") return;
      const p = [`${o}=${encodeURIComponent(i)}`];
      H.isNumber(n) && p.push(`expires=${new Date(n).toUTCString()}`), H.isString(a) && p.push(`path=${a}`), H.isString(l) && p.push(`domain=${l}`), c === !0 && p.push("secure"), H.isString(d) && p.push(`SameSite=${d}`), document.cookie = p.join("; ");
    },
    read(o) {
      if (typeof document > "u") return null;
      const i = document.cookie.match(new RegExp("(?:^|; )" + o + "=([^;]*)"));
      return i ? decodeURIComponent(i[1]) : null;
    },
    remove(o) {
      this.write(o, "", Date.now() - 864e5, "/");
    }
  }
) : (
  // Non-standard browser env (web workers, react-native) lack needed support.
  {
    write() {
    },
    read() {
      return null;
    },
    remove() {
    }
  }
);
function pw(o) {
  return typeof o != "string" ? !1 : /^([a-z][a-z\d+\-.]*:)?\/\//i.test(o);
}
function hw(o, i) {
  return i ? o.replace(/\/?\/$/, "") + "/" + i.replace(/^\/+/, "") : o;
}
function Sb(o, i, n) {
  let a = !pw(i);
  return o && (a || n == !1) ? hw(o, i) : i;
}
const Zg = (o) => o instanceof Gt ? { ...o } : o;
function Nr(o, i) {
  i = i || {};
  const n = {};
  function a(g, y, b, _) {
    return H.isPlainObject(g) && H.isPlainObject(y) ? H.merge.call({ caseless: _ }, g, y) : H.isPlainObject(y) ? H.merge({}, y) : H.isArray(y) ? y.slice() : y;
  }
  function l(g, y, b, _) {
    if (H.isUndefined(y)) {
      if (!H.isUndefined(g))
        return a(void 0, g, b, _);
    } else return a(g, y, b, _);
  }
  function c(g, y) {
    if (!H.isUndefined(y))
      return a(void 0, y);
  }
  function d(g, y) {
    if (H.isUndefined(y)) {
      if (!H.isUndefined(g))
        return a(void 0, g);
    } else return a(void 0, y);
  }
  function p(g, y, b) {
    if (b in i)
      return a(g, y);
    if (b in o)
      return a(void 0, g);
  }
  const m = {
    url: c,
    method: c,
    data: c,
    baseURL: d,
    transformRequest: d,
    transformResponse: d,
    paramsSerializer: d,
    timeout: d,
    timeoutMessage: d,
    withCredentials: d,
    withXSRFToken: d,
    adapter: d,
    responseType: d,
    xsrfCookieName: d,
    xsrfHeaderName: d,
    onUploadProgress: d,
    onDownloadProgress: d,
    decompress: d,
    maxContentLength: d,
    maxBodyLength: d,
    beforeRedirect: d,
    transport: d,
    httpAgent: d,
    httpsAgent: d,
    cancelToken: d,
    socketPath: d,
    responseEncoding: d,
    validateStatus: p,
    headers: (g, y, b) => l(Zg(g), Zg(y), b, !0)
  };
  return H.forEach(
    Object.keys({ ...o, ...i }),
    function(y) {
      if (y === "__proto__" || y === "constructor" || y === "prototype")
        return;
      const b = H.hasOwnProp(m, y) ? m[y] : l, _ = b(o[y], i[y], y);
      H.isUndefined(_) && b !== p || (n[y] = _);
    }
  ), n;
}
const Db = (o) => {
  const i = Nr({}, o);
  let { data: n, withXSRFToken: a, xsrfHeaderName: l, xsrfCookieName: c, headers: d, auth: p } = i;
  if (i.headers = d = Gt.from(d), i.url = xb(Sb(i.baseURL, i.url, i.allowAbsoluteUrls), o.params, o.paramsSerializer), p && d.set(
    "Authorization",
    "Basic " + btoa((p.username || "") + ":" + (p.password ? unescape(encodeURIComponent(p.password)) : ""))
  ), H.isFormData(n)) {
    if (Nt.hasStandardBrowserEnv || Nt.hasStandardBrowserWebWorkerEnv)
      d.setContentType(void 0);
    else if (H.isFunction(n.getHeaders)) {
      const m = n.getHeaders(), g = ["content-type", "content-length"];
      Object.entries(m).forEach(([y, b]) => {
        g.includes(y.toLowerCase()) && d.set(y, b);
      });
    }
  }
  if (Nt.hasStandardBrowserEnv && (a && H.isFunction(a) && (a = a(i)), a || a !== !1 && dw(i.url))) {
    const m = l && c && fw.read(c);
    m && d.set(l, m);
  }
  return i;
}, mw = typeof XMLHttpRequest < "u", gw = mw && function(o) {
  return new Promise(function(n, a) {
    const l = Db(o);
    let c = l.data;
    const d = Gt.from(l.headers).normalize();
    let { responseType: p, onUploadProgress: m, onDownloadProgress: g } = l, y, b, _, k, w;
    function D() {
      k && k(), w && w(), l.cancelToken && l.cancelToken.unsubscribe(y), l.signal && l.signal.removeEventListener("abort", y);
    }
    let S = new XMLHttpRequest();
    S.open(l.method.toUpperCase(), l.url, !0), S.timeout = l.timeout;
    function O() {
      if (!S)
        return;
      const L = Gt.from(
        "getAllResponseHeaders" in S && S.getAllResponseHeaders()
      ), F = {
        data: !p || p === "text" || p === "json" ? S.responseText : S.response,
        status: S.status,
        statusText: S.statusText,
        headers: L,
        config: o,
        request: S
      };
      kb(function(Z) {
        n(Z), D();
      }, function(Z) {
        a(Z), D();
      }, F), S = null;
    }
    "onloadend" in S ? S.onloadend = O : S.onreadystatechange = function() {
      !S || S.readyState !== 4 || S.status === 0 && !(S.responseURL && S.responseURL.indexOf("file:") === 0) || setTimeout(O);
    }, S.onabort = function() {
      S && (a(new xe("Request aborted", xe.ECONNABORTED, o, S)), S = null);
    }, S.onerror = function(P) {
      const F = P && P.message ? P.message : "Network Error", J = new xe(F, xe.ERR_NETWORK, o, S);
      J.event = P || null, a(J), S = null;
    }, S.ontimeout = function() {
      let P = l.timeout ? "timeout of " + l.timeout + "ms exceeded" : "timeout exceeded";
      const F = l.transitional || bf;
      l.timeoutErrorMessage && (P = l.timeoutErrorMessage), a(new xe(
        P,
        F.clarifyTimeoutError ? xe.ETIMEDOUT : xe.ECONNABORTED,
        o,
        S
      )), S = null;
    }, c === void 0 && d.setContentType(null), "setRequestHeader" in S && H.forEach(d.toJSON(), function(P, F) {
      S.setRequestHeader(F, P);
    }), H.isUndefined(l.withCredentials) || (S.withCredentials = !!l.withCredentials), p && p !== "json" && (S.responseType = l.responseType), g && ([_, w] = Ys(g, !0), S.addEventListener("progress", _)), m && S.upload && ([b, k] = Ys(m), S.upload.addEventListener("progress", b), S.upload.addEventListener("loadend", k)), (l.cancelToken || l.signal) && (y = (L) => {
      S && (a(!L || L.type ? new Xo(null, o, S) : L), S.abort(), S = null);
    }, l.cancelToken && l.cancelToken.subscribe(y), l.signal && (l.signal.aborted ? y() : l.signal.addEventListener("abort", y)));
    const q = sw(l.url);
    if (q && Nt.protocols.indexOf(q) === -1) {
      a(new xe("Unsupported protocol " + q + ":", xe.ERR_BAD_REQUEST, o));
      return;
    }
    S.send(c || null);
  });
}, vw = (o, i) => {
  const { length: n } = o = o ? o.filter(Boolean) : [];
  if (i || n) {
    let a = new AbortController(), l;
    const c = function(g) {
      if (!l) {
        l = !0, p();
        const y = g instanceof Error ? g : this.reason;
        a.abort(y instanceof xe ? y : new Xo(y instanceof Error ? y.message : y));
      }
    };
    let d = i && setTimeout(() => {
      d = null, c(new xe(`timeout of ${i}ms exceeded`, xe.ETIMEDOUT));
    }, i);
    const p = () => {
      o && (d && clearTimeout(d), d = null, o.forEach((g) => {
        g.unsubscribe ? g.unsubscribe(c) : g.removeEventListener("abort", c);
      }), o = null);
    };
    o.forEach((g) => g.addEventListener("abort", c));
    const { signal: m } = a;
    return m.unsubscribe = () => H.asap(p), m;
  }
}, bw = function* (o, i) {
  let n = o.byteLength;
  if (n < i) {
    yield o;
    return;
  }
  let a = 0, l;
  for (; a < n; )
    l = a + i, yield o.slice(a, l), a = l;
}, yw = async function* (o, i) {
  for await (const n of xw(o))
    yield* bw(n, i);
}, xw = async function* (o) {
  if (o[Symbol.asyncIterator]) {
    yield* o;
    return;
  }
  const i = o.getReader();
  try {
    for (; ; ) {
      const { done: n, value: a } = await i.read();
      if (n)
        break;
      yield a;
    }
  } finally {
    await i.cancel();
  }
}, Kg = (o, i, n, a) => {
  const l = yw(o, i);
  let c = 0, d, p = (m) => {
    d || (d = !0, a && a(m));
  };
  return new ReadableStream({
    async pull(m) {
      try {
        const { done: g, value: y } = await l.next();
        if (g) {
          p(), m.close();
          return;
        }
        let b = y.byteLength;
        if (n) {
          let _ = c += b;
          n(_);
        }
        m.enqueue(new Uint8Array(y));
      } catch (g) {
        throw p(g), g;
      }
    },
    cancel(m) {
      return p(m), l.return();
    }
  }, {
    highWaterMark: 2
  });
}, Wg = 64 * 1024, { isFunction: gs } = H, ww = (({ Request: o, Response: i }) => ({
  Request: o,
  Response: i
}))(H.global), {
  ReadableStream: Ig,
  TextEncoder: Jg
} = H.global, $g = (o, ...i) => {
  try {
    return !!o(...i);
  } catch {
    return !1;
  }
}, _w = (o) => {
  o = H.merge.call({
    skipUndefined: !0
  }, ww, o);
  const { fetch: i, Request: n, Response: a } = o, l = i ? gs(i) : typeof fetch == "function", c = gs(n), d = gs(a);
  if (!l)
    return !1;
  const p = l && gs(Ig), m = l && (typeof Jg == "function" ? /* @__PURE__ */ ((w) => (D) => w.encode(D))(new Jg()) : async (w) => new Uint8Array(await new n(w).arrayBuffer())), g = c && p && $g(() => {
    let w = !1;
    const D = new n(Nt.origin, {
      body: new Ig(),
      method: "POST",
      get duplex() {
        return w = !0, "half";
      }
    }).headers.has("Content-Type");
    return w && !D;
  }), y = d && p && $g(() => H.isReadableStream(new a("").body)), b = {
    stream: y && ((w) => w.body)
  };
  l && ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((w) => {
    !b[w] && (b[w] = (D, S) => {
      let O = D && D[w];
      if (O)
        return O.call(D);
      throw new xe(`Response type '${w}' is not supported`, xe.ERR_NOT_SUPPORT, S);
    });
  });
  const _ = async (w) => {
    if (w == null)
      return 0;
    if (H.isBlob(w))
      return w.size;
    if (H.isSpecCompliantForm(w))
      return (await new n(Nt.origin, {
        method: "POST",
        body: w
      }).arrayBuffer()).byteLength;
    if (H.isArrayBufferView(w) || H.isArrayBuffer(w))
      return w.byteLength;
    if (H.isURLSearchParams(w) && (w = w + ""), H.isString(w))
      return (await m(w)).byteLength;
  }, k = async (w, D) => {
    const S = H.toFiniteNumber(w.getContentLength());
    return S ?? _(D);
  };
  return async (w) => {
    let {
      url: D,
      method: S,
      data: O,
      signal: q,
      cancelToken: L,
      timeout: P,
      onDownloadProgress: F,
      onUploadProgress: J,
      responseType: Z,
      headers: ie,
      withCredentials: ue = "same-origin",
      fetchOptions: de
    } = Db(w), ne = i || fetch;
    Z = Z ? (Z + "").toLowerCase() : "text";
    let $ = vw([q, L && L.toAbortSignal()], P), ae = null;
    const le = $ && $.unsubscribe && (() => {
      $.unsubscribe();
    });
    let fe;
    try {
      if (J && g && S !== "get" && S !== "head" && (fe = await k(ie, O)) !== 0) {
        let M = new n(D, {
          method: "POST",
          body: O,
          duplex: "half"
        }), T;
        if (H.isFormData(O) && (T = M.headers.get("content-type")) && ie.setContentType(T), M.body) {
          const [K, I] = Gg(
            fe,
            Ys(Xg(J))
          );
          O = Kg(M.body, Wg, K, I);
        }
      }
      H.isString(ue) || (ue = ue ? "include" : "omit");
      const j = c && "credentials" in n.prototype, Q = {
        ...de,
        signal: $,
        method: S.toUpperCase(),
        headers: ie.normalize().toJSON(),
        body: O,
        duplex: "half",
        credentials: j ? ue : void 0
      };
      ae = c && new n(D, Q);
      let W = await (c ? ne(ae, de) : ne(D, Q));
      const se = y && (Z === "stream" || Z === "response");
      if (y && (F || se && le)) {
        const M = {};
        ["status", "statusText", "headers"].forEach((oe) => {
          M[oe] = W[oe];
        });
        const T = H.toFiniteNumber(W.headers.get("content-length")), [K, I] = F && Gg(
          T,
          Ys(Xg(F), !0)
        ) || [];
        W = new a(
          Kg(W.body, Wg, K, () => {
            I && I(), le && le();
          }),
          M
        );
      }
      Z = Z || "text";
      let we = await b[H.findKey(b, Z) || "text"](W, w);
      return !se && le && le(), await new Promise((M, T) => {
        kb(M, T, {
          data: we,
          headers: Gt.from(W.headers),
          status: W.status,
          statusText: W.statusText,
          config: w,
          request: ae
        });
      });
    } catch (j) {
      throw le && le(), j && j.name === "TypeError" && /Load failed|fetch/i.test(j.message) ? Object.assign(
        new xe("Network Error", xe.ERR_NETWORK, w, ae, j && j.response),
        {
          cause: j.cause || j
        }
      ) : xe.from(j, j && j.code, w, ae, j && j.response);
    }
  };
}, kw = /* @__PURE__ */ new Map(), Eb = (o) => {
  let i = o && o.env || {};
  const { fetch: n, Request: a, Response: l } = i, c = [
    a,
    l,
    n
  ];
  let d = c.length, p = d, m, g, y = kw;
  for (; p--; )
    m = c[p], g = y.get(m), g === void 0 && y.set(m, g = p ? /* @__PURE__ */ new Map() : _w(i)), y = g;
  return g;
};
Eb();
const xf = {
  http: B1,
  xhr: gw,
  fetch: {
    get: Eb
  }
};
H.forEach(xf, (o, i) => {
  if (o) {
    try {
      Object.defineProperty(o, "name", { value: i });
    } catch {
    }
    Object.defineProperty(o, "adapterName", { value: i });
  }
});
const ev = (o) => `- ${o}`, Sw = (o) => H.isFunction(o) || o === null || o === !1;
function Dw(o, i) {
  o = H.isArray(o) ? o : [o];
  const { length: n } = o;
  let a, l;
  const c = {};
  for (let d = 0; d < n; d++) {
    a = o[d];
    let p;
    if (l = a, !Sw(a) && (l = xf[(p = String(a)).toLowerCase()], l === void 0))
      throw new xe(`Unknown adapter '${p}'`);
    if (l && (H.isFunction(l) || (l = l.get(i))))
      break;
    c[p || "#" + d] = l;
  }
  if (!l) {
    const d = Object.entries(c).map(
      ([m, g]) => `adapter ${m} ` + (g === !1 ? "is not supported by the environment" : "is not available in the build")
    );
    let p = n ? d.length > 1 ? `since :
` + d.map(ev).join(`
`) : " " + ev(d[0]) : "as no adapter specified";
    throw new xe(
      "There is no suitable adapter to dispatch the request " + p,
      "ERR_NOT_SUPPORT"
    );
  }
  return l;
}
const Mb = {
  /**
   * Resolve an adapter from a list of adapter names or functions.
   * @type {Function}
   */
  getAdapter: Dw,
  /**
   * Exposes all known adapters
   * @type {Object<string, Function|Object>}
   */
  adapters: xf
};
function Rd(o) {
  if (o.cancelToken && o.cancelToken.throwIfRequested(), o.signal && o.signal.aborted)
    throw new Xo(null, o);
}
function tv(o) {
  return Rd(o), o.headers = Gt.from(o.headers), o.data = Ad.call(
    o,
    o.transformRequest
  ), ["post", "put", "patch"].indexOf(o.method) !== -1 && o.headers.setContentType("application/x-www-form-urlencoded", !1), Mb.getAdapter(o.adapter || Go.adapter, o)(o).then(function(a) {
    return Rd(o), a.data = Ad.call(
      o,
      o.transformResponse,
      a
    ), a.headers = Gt.from(a.headers), a;
  }, function(a) {
    return _b(a) || (Rd(o), a && a.response && (a.response.data = Ad.call(
      o,
      o.transformResponse,
      a.response
    ), a.response.headers = Gt.from(a.response.headers))), Promise.reject(a);
  });
}
const Tb = "1.13.5", ec = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((o, i) => {
  ec[o] = function(a) {
    return typeof a === o || "a" + (i < 1 ? "n " : " ") + o;
  };
});
const av = {};
ec.transitional = function(i, n, a) {
  function l(c, d) {
    return "[Axios v" + Tb + "] Transitional option '" + c + "'" + d + (a ? ". " + a : "");
  }
  return (c, d, p) => {
    if (i === !1)
      throw new xe(
        l(d, " has been removed" + (n ? " in " + n : "")),
        xe.ERR_DEPRECATED
      );
    return n && !av[d] && (av[d] = !0, console.warn(
      l(
        d,
        " has been deprecated since v" + n + " and will be removed in the near future"
      )
    )), i ? i(c, d, p) : !0;
  };
};
ec.spelling = function(i) {
  return (n, a) => (console.warn(`${a} is likely a misspelling of ${i}`), !0);
};
function Ew(o, i, n) {
  if (typeof o != "object")
    throw new xe("options must be an object", xe.ERR_BAD_OPTION_VALUE);
  const a = Object.keys(o);
  let l = a.length;
  for (; l-- > 0; ) {
    const c = a[l], d = i[c];
    if (d) {
      const p = o[c], m = p === void 0 || d(p, c, o);
      if (m !== !0)
        throw new xe("option " + c + " must be " + m, xe.ERR_BAD_OPTION_VALUE);
      continue;
    }
    if (n !== !0)
      throw new xe("Unknown option " + c, xe.ERR_BAD_OPTION);
  }
}
const Ns = {
  assertOptions: Ew,
  validators: ec
}, ma = Ns.validators;
let Mr = class {
  constructor(i) {
    this.defaults = i || {}, this.interceptors = {
      request: new Fg(),
      response: new Fg()
    };
  }
  /**
   * Dispatch a request
   *
   * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
   * @param {?Object} config
   *
   * @returns {Promise} The Promise to be fulfilled
   */
  async request(i, n) {
    try {
      return await this._request(i, n);
    } catch (a) {
      if (a instanceof Error) {
        let l = {};
        Error.captureStackTrace ? Error.captureStackTrace(l) : l = new Error();
        const c = l.stack ? l.stack.replace(/^.+\n/, "") : "";
        try {
          a.stack ? c && !String(a.stack).endsWith(c.replace(/^.+\n.+\n/, "")) && (a.stack += `
` + c) : a.stack = c;
        } catch {
        }
      }
      throw a;
    }
  }
  _request(i, n) {
    typeof i == "string" ? (n = n || {}, n.url = i) : n = i || {}, n = Nr(this.defaults, n);
    const { transitional: a, paramsSerializer: l, headers: c } = n;
    a !== void 0 && Ns.assertOptions(a, {
      silentJSONParsing: ma.transitional(ma.boolean),
      forcedJSONParsing: ma.transitional(ma.boolean),
      clarifyTimeoutError: ma.transitional(ma.boolean),
      legacyInterceptorReqResOrdering: ma.transitional(ma.boolean)
    }, !1), l != null && (H.isFunction(l) ? n.paramsSerializer = {
      serialize: l
    } : Ns.assertOptions(l, {
      encode: ma.function,
      serialize: ma.function
    }, !0)), n.allowAbsoluteUrls !== void 0 || (this.defaults.allowAbsoluteUrls !== void 0 ? n.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls : n.allowAbsoluteUrls = !0), Ns.assertOptions(n, {
      baseUrl: ma.spelling("baseURL"),
      withXsrfToken: ma.spelling("withXSRFToken")
    }, !0), n.method = (n.method || this.defaults.method || "get").toLowerCase();
    let d = c && H.merge(
      c.common,
      c[n.method]
    );
    c && H.forEach(
      ["delete", "get", "head", "post", "put", "patch", "common"],
      (w) => {
        delete c[w];
      }
    ), n.headers = Gt.concat(d, c);
    const p = [];
    let m = !0;
    this.interceptors.request.forEach(function(D) {
      if (typeof D.runWhen == "function" && D.runWhen(n) === !1)
        return;
      m = m && D.synchronous;
      const S = n.transitional || bf;
      S && S.legacyInterceptorReqResOrdering ? p.unshift(D.fulfilled, D.rejected) : p.push(D.fulfilled, D.rejected);
    });
    const g = [];
    this.interceptors.response.forEach(function(D) {
      g.push(D.fulfilled, D.rejected);
    });
    let y, b = 0, _;
    if (!m) {
      const w = [tv.bind(this), void 0];
      for (w.unshift(...p), w.push(...g), _ = w.length, y = Promise.resolve(n); b < _; )
        y = y.then(w[b++], w[b++]);
      return y;
    }
    _ = p.length;
    let k = n;
    for (; b < _; ) {
      const w = p[b++], D = p[b++];
      try {
        k = w(k);
      } catch (S) {
        D.call(this, S);
        break;
      }
    }
    try {
      y = tv.call(this, k);
    } catch (w) {
      return Promise.reject(w);
    }
    for (b = 0, _ = g.length; b < _; )
      y = y.then(g[b++], g[b++]);
    return y;
  }
  getUri(i) {
    i = Nr(this.defaults, i);
    const n = Sb(i.baseURL, i.url, i.allowAbsoluteUrls);
    return xb(n, i.params, i.paramsSerializer);
  }
};
H.forEach(["delete", "get", "head", "options"], function(i) {
  Mr.prototype[i] = function(n, a) {
    return this.request(Nr(a || {}, {
      method: i,
      url: n,
      data: (a || {}).data
    }));
  };
});
H.forEach(["post", "put", "patch"], function(i) {
  function n(a) {
    return function(c, d, p) {
      return this.request(Nr(p || {}, {
        method: i,
        headers: a ? {
          "Content-Type": "multipart/form-data"
        } : {},
        url: c,
        data: d
      }));
    };
  }
  Mr.prototype[i] = n(), Mr.prototype[i + "Form"] = n(!0);
});
let Mw = class Cb {
  constructor(i) {
    if (typeof i != "function")
      throw new TypeError("executor must be a function.");
    let n;
    this.promise = new Promise(function(c) {
      n = c;
    });
    const a = this;
    this.promise.then((l) => {
      if (!a._listeners) return;
      let c = a._listeners.length;
      for (; c-- > 0; )
        a._listeners[c](l);
      a._listeners = null;
    }), this.promise.then = (l) => {
      let c;
      const d = new Promise((p) => {
        a.subscribe(p), c = p;
      }).then(l);
      return d.cancel = function() {
        a.unsubscribe(c);
      }, d;
    }, i(function(c, d, p) {
      a.reason || (a.reason = new Xo(c, d, p), n(a.reason));
    });
  }
  /**
   * Throws a `CanceledError` if cancellation has been requested.
   */
  throwIfRequested() {
    if (this.reason)
      throw this.reason;
  }
  /**
   * Subscribe to the cancel signal
   */
  subscribe(i) {
    if (this.reason) {
      i(this.reason);
      return;
    }
    this._listeners ? this._listeners.push(i) : this._listeners = [i];
  }
  /**
   * Unsubscribe from the cancel signal
   */
  unsubscribe(i) {
    if (!this._listeners)
      return;
    const n = this._listeners.indexOf(i);
    n !== -1 && this._listeners.splice(n, 1);
  }
  toAbortSignal() {
    const i = new AbortController(), n = (a) => {
      i.abort(a);
    };
    return this.subscribe(n), i.signal.unsubscribe = () => this.unsubscribe(n), i.signal;
  }
  /**
   * Returns an object that contains a new `CancelToken` and a function that, when called,
   * cancels the `CancelToken`.
   */
  static source() {
    let i;
    return {
      token: new Cb(function(l) {
        i = l;
      }),
      cancel: i
    };
  }
};
function Tw(o) {
  return function(n) {
    return o.apply(null, n);
  };
}
function Cw(o) {
  return H.isObject(o) && o.isAxiosError === !0;
}
const tf = {
  Continue: 100,
  SwitchingProtocols: 101,
  Processing: 102,
  EarlyHints: 103,
  Ok: 200,
  Created: 201,
  Accepted: 202,
  NonAuthoritativeInformation: 203,
  NoContent: 204,
  ResetContent: 205,
  PartialContent: 206,
  MultiStatus: 207,
  AlreadyReported: 208,
  ImUsed: 226,
  MultipleChoices: 300,
  MovedPermanently: 301,
  Found: 302,
  SeeOther: 303,
  NotModified: 304,
  UseProxy: 305,
  Unused: 306,
  TemporaryRedirect: 307,
  PermanentRedirect: 308,
  BadRequest: 400,
  Unauthorized: 401,
  PaymentRequired: 402,
  Forbidden: 403,
  NotFound: 404,
  MethodNotAllowed: 405,
  NotAcceptable: 406,
  ProxyAuthenticationRequired: 407,
  RequestTimeout: 408,
  Conflict: 409,
  Gone: 410,
  LengthRequired: 411,
  PreconditionFailed: 412,
  PayloadTooLarge: 413,
  UriTooLong: 414,
  UnsupportedMediaType: 415,
  RangeNotSatisfiable: 416,
  ExpectationFailed: 417,
  ImATeapot: 418,
  MisdirectedRequest: 421,
  UnprocessableEntity: 422,
  Locked: 423,
  FailedDependency: 424,
  TooEarly: 425,
  UpgradeRequired: 426,
  PreconditionRequired: 428,
  TooManyRequests: 429,
  RequestHeaderFieldsTooLarge: 431,
  UnavailableForLegalReasons: 451,
  InternalServerError: 500,
  NotImplemented: 501,
  BadGateway: 502,
  ServiceUnavailable: 503,
  GatewayTimeout: 504,
  HttpVersionNotSupported: 505,
  VariantAlsoNegotiates: 506,
  InsufficientStorage: 507,
  LoopDetected: 508,
  NotExtended: 510,
  NetworkAuthenticationRequired: 511,
  WebServerIsDown: 521,
  ConnectionTimedOut: 522,
  OriginIsUnreachable: 523,
  TimeoutOccurred: 524,
  SslHandshakeFailed: 525,
  InvalidSslCertificate: 526
};
Object.entries(tf).forEach(([o, i]) => {
  tf[i] = o;
});
function Nb(o) {
  const i = new Mr(o), n = cb(Mr.prototype.request, i);
  return H.extend(n, Mr.prototype, i, { allOwnKeys: !0 }), H.extend(n, i, null, { allOwnKeys: !0 }), n.create = function(l) {
    return Nb(Nr(o, l));
  }, n;
}
const it = Nb(Go);
it.Axios = Mr;
it.CanceledError = Xo;
it.CancelToken = Mw;
it.isCancel = _b;
it.VERSION = Tb;
it.toFormData = $s;
it.AxiosError = xe;
it.Cancel = it.CanceledError;
it.all = function(i) {
  return Promise.all(i);
};
it.spread = Tw;
it.isAxiosError = Cw;
it.mergeConfig = Nr;
it.AxiosHeaders = Gt;
it.formToJSON = (o) => wb(H.isHTMLForm(o) ? new FormData(o) : o);
it.getAdapter = Mb.getAdapter;
it.HttpStatusCode = tf;
it.default = it;
const {
  Axios: pE,
  AxiosError: hE,
  CanceledError: mE,
  isCancel: gE,
  CancelToken: vE,
  VERSION: bE,
  all: yE,
  Cancel: xE,
  isAxiosError: wE,
  spread: _E,
  toFormData: kE,
  AxiosHeaders: SE,
  HttpStatusCode: DE,
  formToJSON: EE,
  getAdapter: ME,
  mergeConfig: TE
} = it;
function mn() {
  try {
    if (typeof window < "u") {
      const i = window.__oaticonnectBasePath;
      if (typeof i == "string")
        return i === "/" ? "" : i.replace(/\/$/, "");
    }
  } catch {
  }
  const o = "/";
  return o === "/" ? "" : o.replace(/\/$/, "");
}
function Nw() {
  return `${mn()}/api/v1`;
}
function Ow() {
  return mn();
}
const ba = it.create({
  baseURL: Nw(),
  headers: { "Content-Type": "application/json" },
  withCredentials: !0
}), In = it.create({
  baseURL: Ow(),
  headers: { "Content-Type": "application/json" },
  withCredentials: !0
});
function ki(o) {
  if (Array.isArray(o)) return o.map(ki);
  if (o && typeof o == "object" && Object.getPrototypeOf(o) === Object.prototype) {
    const i = {};
    for (const n of Object.keys(o)) {
      const a = n.charAt(0).toLowerCase() + n.slice(1);
      i[a] = ki(o[n]);
    }
    return i;
  }
  return o;
}
function jw(o) {
  if (!o || typeof o != "object" || Array.isArray(o)) return !1;
  const i = "Message" in o || "message" in o, n = "UserName" in o || "userName" in o, a = "IsAuthenticate" in o || "isAuthenticate" in o;
  if (!(i && n && a)) return !1;
  const l = String(o.Message || o.message || "").toLowerCase();
  return l.includes("authorization") && l.includes("denied");
}
function Ob(o) {
  o.interceptors.response.use(
    (i) => {
      try {
        const n = i.data;
        if (jw(n)) {
          const a = new Error("Host session expired — please refresh the page and sign in again.");
          return a.isHostAuthDenied = !0, a.response = i, Promise.reject(a);
        }
        n && typeof n == "object" && !Array.isArray(n) ? "Data" in n && "IsSuccess" in n ? i.data = ki(n.Data) : "data" in n && "isSuccess" in n ? i.data = ki(n.data) : i.data = ki(n) : i.data = ki(n);
      } catch {
      }
      return i;
    },
    (i) => Promise.reject(i)
  );
}
Ob(ba);
Ob(In);
function Aw() {
  return {
    defaultCameraOn: !0,
    defaultMicOn: !0,
    defaultDurationMinutes: 60,
    meetingNameMode: "auto",
    enableMeetingPassword: !0,
    requireHostStart: !0,
    encryptedShareLink: !0,
    embedPasswordInLink: !0,
    recurringMaxDurationDays: 90,
    webClientUrl: "",
    disablePreJoinPage: !1,
    audioOnly: !1,
    startWithAudioMuted: !1,
    startWithCameraOff: !1,
    disableFaceCentering: !1,
    disableTileEnlargement: !1,
    skipMediaPermissions: !1,
    disableNotifications: !1,
    toolbarButtons: {}
  };
}
async function jb() {
  const i = (await In.get("/oaticonnect/settings")).data;
  if (!i || typeof i != "object" || !("toolbarButtons" in i))
    return { ...Aw(), ...i && typeof i == "object" ? {} : {} };
  const n = i;
  return (!n.toolbarButtons || typeof n.toolbarButtons != "object") && (n.toolbarButtons = {}), n;
}
async function Rw(o) {
  await In.post("/oaticonnect/settings", o);
}
async function zw() {
  try {
    const i = (await In.get("/oaticonnect/me")).data;
    return !i || typeof i != "object" || !("isAuthenticated" in i) ? null : i;
  } catch {
    return null;
  }
}
const wf = N.createContext(void 0);
function Lw({ children: o }) {
  const n = sb()?.user ?? null, [a, l] = N.useState(n ? {
    id: n.id,
    name: n.name,
    email: n.email,
    role: n.role || "Standard",
    timeZone: ""
  } : null), [c, d] = N.useState(null), [p, m] = N.useState(!0), g = N.useCallback(async () => {
    try {
      d(await jb());
    } catch (y) {
      console.warn("[UserContext] /settings load failed:", y), d(null);
    }
  }, []);
  return N.useEffect(() => {
    if (!n) {
      l(null), m(!1);
      return;
    }
    let y = !1;
    return (async () => {
      const b = await zw();
      if (y) return;
      const _ = b?.isAuthenticated && b.role ? b.role : n.role || "Standard", k = (b?.isAuthenticated ? b.timeZoneIana || b.timeZone : "") || "";
      let w = "";
      if (k)
        try {
          new Intl.DateTimeFormat("en-CA", { timeZone: k }), w = k;
        } catch {
          console.warn(`[UserContext] dropping unrecognised time zone "${k}" — falling back to browser-local rendering.`);
        }
      l({
        id: b?.isAuthenticated ? b.id : n.id,
        name: b?.isAuthenticated ? b.name : n.name,
        email: b?.isAuthenticated ? b.email : n.email,
        role: _,
        timeZone: w
      }), await g(), m(!1);
    })(), () => {
      y = !0;
    };
  }, [n?.id, g]), /* @__PURE__ */ h.jsx(wf.Provider, { value: { user: a, preferences: c, loading: p, refreshPreferences: g }, children: o });
}
const Yw = {
  user: null,
  preferences: null,
  loading: !0,
  refreshPreferences: async () => {
  }
};
function Ab() {
  const o = N.useContext(wf);
  return o || Yw;
}
function tc() {
  return N.useContext(wf) ?? null;
}
let ka = null;
async function Hw() {
  try {
    const o = localStorage.getItem("app_config_v2");
    o && (ka = JSON.parse(o));
  } catch {
  }
  try {
    const o = mn();
    ka = await (await fetch(`${o}/api/v1/config`, { cache: "no-store" })).json();
    try {
      localStorage.setItem("app_config_v2", JSON.stringify(ka));
    } catch {
    }
  } catch (o) {
    if (!ka)
      throw console.error("Failed to load app config", o), o;
  }
}
async function Uw() {
  try {
    localStorage.removeItem("app_config_v2");
  } catch {
  }
  ka = null;
  const o = mn();
  ka = await (await fetch(`${o}/api/v1/config`, { cache: "no-store" })).json();
  try {
    localStorage.setItem("app_config_v2", JSON.stringify(ka));
  } catch {
  }
}
function Zo() {
  if (!ka) {
    const o = localStorage.getItem("app_config_v2");
    if (o)
      try {
        ka = JSON.parse(o);
      } catch {
      }
  }
  if (!ka)
    throw new Error("Config not loaded. Call loadConfig() first.");
  return ka;
}
function ac() {
  try {
    return Zo().appName || "OATIConnect";
  } catch {
    return "OATIConnect";
  }
}
function nv() {
  try {
    return Zo().showClock !== !1;
  } catch {
    return !0;
  }
}
function rv() {
  try {
    return Zo().showThemeToggle !== !1;
  } catch {
    return !0;
  }
}
function iv() {
  try {
    const o = Zo().defaultTheme;
    return o === "light" || o === "dark" || o === "system" ? o : "system";
  } catch {
    return "system";
  }
}
mn();
const Rb = N.createContext(null);
function Bw({ children: o }) {
  const [i, n] = N.useState([]), a = N.useCallback((c, d) => {
    const p = Date.now() + Math.floor(Math.random() * 1e3);
    n((m) => [...m, { id: p, kind: c, message: d }]), window.setTimeout(() => {
      n((m) => m.filter((g) => g.id !== p));
    }, 3200);
  }, []), l = {
    success: (c) => a("success", c),
    error: (c) => a("error", c),
    info: (c) => a("info", c)
  };
  return /* @__PURE__ */ h.jsxs(Rb.Provider, { value: l, children: [
    o,
    /* @__PURE__ */ h.jsx("div", { className: "toast-stack", role: "status", "aria-live": "polite", children: i.map((c) => /* @__PURE__ */ h.jsxs("div", { className: `toast toast-${c.kind}`, children: [
      /* @__PURE__ */ h.jsxs("span", { className: "toast-icon", "aria-hidden": !0, children: [
        c.kind === "success" && /* @__PURE__ */ h.jsx("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ h.jsx("polyline", { points: "20 6 9 17 4 12" }) }),
        c.kind === "error" && /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", children: [
          /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "12", r: "10" }),
          /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "8", x2: "12", y2: "12" }),
          /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" })
        ] }),
        c.kind === "info" && /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", children: [
          /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "12", r: "10" }),
          /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "16", x2: "12", y2: "12" }),
          /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "8", x2: "12.01", y2: "8" })
        ] })
      ] }),
      /* @__PURE__ */ h.jsx("span", { className: "toast-text", children: c.message })
    ] }, c.id)) })
  ] });
}
function zb() {
  const o = N.useContext(Rb);
  return o || {
    success: (i) => console.warn("[Toast] (no provider) success:", i),
    error: (i) => console.warn("[Toast] (no provider) error:", i),
    info: (i) => console.warn("[Toast] (no provider) info:", i)
  };
}
function Lb(o) {
  var i, n, a = "";
  if (typeof o == "string" || typeof o == "number") a += o;
  else if (typeof o == "object") if (Array.isArray(o)) {
    var l = o.length;
    for (i = 0; i < l; i++) o[i] && (n = Lb(o[i])) && (a && (a += " "), a += n);
  } else for (n in o) o[n] && (a && (a += " "), a += n);
  return a;
}
function vt() {
  for (var o, i, n = 0, a = "", l = arguments.length; n < l; n++) (o = arguments[n]) && (i = Lb(o)) && (a && (a += " "), a += i);
  return a;
}
const Yb = 6048e5, qw = 864e5, nc = 6e4, rc = 36e5, Qw = 1e3, ov = /* @__PURE__ */ Symbol.for("constructDateFrom");
function Ve(o, i) {
  return typeof o == "function" ? o(i) : o && typeof o == "object" && ov in o ? o[ov](i) : o instanceof Date ? new o.constructor(i) : new Date(i);
}
function me(o, i) {
  return Ve(i || o, o);
}
function Sa(o, i, n) {
  const a = me(o, n?.in);
  return isNaN(i) ? Ve(n?.in || o, NaN) : (i && a.setDate(a.getDate() + i), a);
}
function Ea(o, i, n) {
  const a = me(o, n?.in);
  if (isNaN(i)) return Ve(o, NaN);
  if (!i)
    return a;
  const l = a.getDate(), c = Ve(o, a.getTime());
  c.setMonth(a.getMonth() + i + 1, 0);
  const d = c.getDate();
  return l >= d ? c : (a.setFullYear(
    c.getFullYear(),
    c.getMonth(),
    l
  ), a);
}
function Hb(o, i, n) {
  return Ve(o, +me(o) + i);
}
function Pw(o, i, n) {
  return Hb(o, i * rc);
}
let Fw = {};
function Ar() {
  return Fw;
}
function gn(o, i) {
  const n = Ar(), a = i?.weekStartsOn ?? i?.locale?.options?.weekStartsOn ?? n.weekStartsOn ?? n.locale?.options?.weekStartsOn ?? 0, l = me(o, i?.in), c = l.getDay(), d = (c < a ? 7 : 0) + c - a;
  return l.setDate(l.getDate() - d), l.setHours(0, 0, 0, 0), l;
}
function Mi(o, i) {
  return gn(o, { ...i, weekStartsOn: 1 });
}
function Ub(o, i) {
  const n = me(o, i?.in), a = n.getFullYear(), l = Ve(n, 0);
  l.setFullYear(a + 1, 0, 4), l.setHours(0, 0, 0, 0);
  const c = Mi(l), d = Ve(n, 0);
  d.setFullYear(a, 0, 4), d.setHours(0, 0, 0, 0);
  const p = Mi(d);
  return n.getTime() >= c.getTime() ? a + 1 : n.getTime() >= p.getTime() ? a : a - 1;
}
function Hs(o) {
  const i = me(o), n = new Date(
    Date.UTC(
      i.getFullYear(),
      i.getMonth(),
      i.getDate(),
      i.getHours(),
      i.getMinutes(),
      i.getSeconds(),
      i.getMilliseconds()
    )
  );
  return n.setUTCFullYear(i.getFullYear()), +o - +n;
}
function vn(o, ...i) {
  const n = Ve.bind(
    null,
    i.find((a) => typeof a == "object")
  );
  return i.map(n);
}
function Or(o, i) {
  const n = me(o, i?.in);
  return n.setHours(0, 0, 0, 0), n;
}
function Ti(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  ), c = Or(a), d = Or(l), p = +c - Hs(c), m = +d - Hs(d);
  return Math.round((p - m) / qw);
}
function Vw(o, i) {
  const n = Ub(o, i), a = Ve(o, 0);
  return a.setFullYear(n, 0, 4), a.setHours(0, 0, 0, 0), Mi(a);
}
function Bo(o, i, n) {
  const a = me(o, n?.in);
  return a.setTime(a.getTime() + i * nc), a;
}
function _f(o, i, n) {
  return Ea(o, i * 3, n);
}
function Gw(o, i, n) {
  return Hb(o, i * 1e3);
}
function Us(o, i, n) {
  return Sa(o, i * 7, n);
}
function Da(o, i, n) {
  return Ea(o, i * 12, n);
}
function lv(o, i) {
  let n, a = i?.in;
  return o.forEach((l) => {
    !a && typeof l == "object" && (a = Ve.bind(null, l));
    const c = me(l, a);
    (!n || n < c || isNaN(+c)) && (n = c);
  }), Ve(a, n || NaN);
}
function sv(o, i) {
  let n, a = i?.in;
  return o.forEach((l) => {
    !a && typeof l == "object" && (a = Ve.bind(null, l));
    const c = me(l, a);
    (!n || n > c || isNaN(+c)) && (n = c);
  }), Ve(a, n || NaN);
}
function Xw(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  );
  return +Or(a) == +Or(l);
}
function Qa(o) {
  return o instanceof Date || typeof o == "object" && Object.prototype.toString.call(o) === "[object Date]";
}
function Ci(o) {
  return !(!Qa(o) && typeof o != "number" || isNaN(+me(o)));
}
function Bs(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  ), c = a.getFullYear() - l.getFullYear(), d = a.getMonth() - l.getMonth();
  return c * 12 + d;
}
function Gn(o, i) {
  const n = me(o, i?.in);
  return Math.trunc(n.getMonth() / 3) + 1;
}
function qs(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  ), c = a.getFullYear() - l.getFullYear(), d = Gn(a) - Gn(l);
  return c * 4 + d;
}
function Qs(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  );
  return a.getFullYear() - l.getFullYear();
}
function Zw(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  ), c = cv(a, l), d = Math.abs(
    Ti(a, l)
  );
  a.setDate(a.getDate() - c * d);
  const p = +(cv(a, l) === -c), m = c * (d - p);
  return m === 0 ? 0 : m;
}
function cv(o, i) {
  const n = o.getFullYear() - i.getFullYear() || o.getMonth() - i.getMonth() || o.getDate() - i.getDate() || o.getHours() - i.getHours() || o.getMinutes() - i.getMinutes() || o.getSeconds() - i.getSeconds() || o.getMilliseconds() - i.getMilliseconds();
  return n < 0 ? -1 : n > 0 ? 1 : n;
}
function Bb(o, i) {
  const n = me(o, i?.in);
  return n.setHours(23, 59, 59, 999), n;
}
function qb(o, i) {
  const n = me(o, i?.in), a = n.getMonth();
  return n.setFullYear(n.getFullYear(), a + 1, 0), n.setHours(23, 59, 59, 999), n;
}
function af(o, i) {
  const n = me(o, i?.in), a = n.getMonth(), l = a - a % 3;
  return n.setMonth(l, 1), n.setHours(0, 0, 0, 0), n;
}
function Qb(o, i) {
  const n = me(o, i?.in);
  return n.setDate(1), n.setHours(0, 0, 0, 0), n;
}
function Pb(o, i) {
  const n = me(o, i?.in), a = n.getFullYear();
  return n.setFullYear(a + 1, 0, 0), n.setHours(23, 59, 59, 999), n;
}
function ic(o, i) {
  const n = me(o, i?.in);
  return n.setFullYear(n.getFullYear(), 0, 1), n.setHours(0, 0, 0, 0), n;
}
function Kw(o, i) {
  const n = Ar(), a = n.weekStartsOn ?? n.locale?.options?.weekStartsOn ?? 0, l = me(o, i?.in), c = l.getDay(), d = (c < a ? -7 : 0) + 6 - (c - a);
  return l.setDate(l.getDate() + d), l.setHours(23, 59, 59, 999), l;
}
const Ww = {
  lessThanXSeconds: {
    one: "less than a second",
    other: "less than {{count}} seconds"
  },
  xSeconds: {
    one: "1 second",
    other: "{{count}} seconds"
  },
  halfAMinute: "half a minute",
  lessThanXMinutes: {
    one: "less than a minute",
    other: "less than {{count}} minutes"
  },
  xMinutes: {
    one: "1 minute",
    other: "{{count}} minutes"
  },
  aboutXHours: {
    one: "about 1 hour",
    other: "about {{count}} hours"
  },
  xHours: {
    one: "1 hour",
    other: "{{count}} hours"
  },
  xDays: {
    one: "1 day",
    other: "{{count}} days"
  },
  aboutXWeeks: {
    one: "about 1 week",
    other: "about {{count}} weeks"
  },
  xWeeks: {
    one: "1 week",
    other: "{{count}} weeks"
  },
  aboutXMonths: {
    one: "about 1 month",
    other: "about {{count}} months"
  },
  xMonths: {
    one: "1 month",
    other: "{{count}} months"
  },
  aboutXYears: {
    one: "about 1 year",
    other: "about {{count}} years"
  },
  xYears: {
    one: "1 year",
    other: "{{count}} years"
  },
  overXYears: {
    one: "over 1 year",
    other: "over {{count}} years"
  },
  almostXYears: {
    one: "almost 1 year",
    other: "almost {{count}} years"
  }
}, Iw = (o, i, n) => {
  let a;
  const l = Ww[o];
  return typeof l == "string" ? a = l : i === 1 ? a = l.one : a = l.other.replace("{{count}}", i.toString()), n?.addSuffix ? n.comparison && n.comparison > 0 ? "in " + a : a + " ago" : a;
};
function zd(o) {
  return (i = {}) => {
    const n = i.width ? String(i.width) : o.defaultWidth;
    return o.formats[n] || o.formats[o.defaultWidth];
  };
}
const Jw = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, $w = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, e_ = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, t_ = {
  date: zd({
    formats: Jw,
    defaultWidth: "full"
  }),
  time: zd({
    formats: $w,
    defaultWidth: "full"
  }),
  dateTime: zd({
    formats: e_,
    defaultWidth: "full"
  })
}, a_ = {
  lastWeek: "'last' eeee 'at' p",
  yesterday: "'yesterday at' p",
  today: "'today at' p",
  tomorrow: "'tomorrow at' p",
  nextWeek: "eeee 'at' p",
  other: "P"
}, n_ = (o, i, n, a) => a_[o];
function Ro(o) {
  return (i, n) => {
    const a = n?.context ? String(n.context) : "standalone";
    let l;
    if (a === "formatting" && o.formattingValues) {
      const d = o.defaultFormattingWidth || o.defaultWidth, p = n?.width ? String(n.width) : d;
      l = o.formattingValues[p] || o.formattingValues[d];
    } else {
      const d = o.defaultWidth, p = n?.width ? String(n.width) : o.defaultWidth;
      l = o.values[p] || o.values[d];
    }
    const c = o.argumentCallback ? o.argumentCallback(i) : i;
    return l[c];
  };
}
const r_ = {
  narrow: ["B", "A"],
  abbreviated: ["BC", "AD"],
  wide: ["Before Christ", "Anno Domini"]
}, i_ = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
}, o_ = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  wide: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ]
}, l_ = {
  narrow: ["S", "M", "T", "W", "T", "F", "S"],
  short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  wide: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ]
}, s_ = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  }
}, c_ = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  }
}, u_ = (o, i) => {
  const n = Number(o), a = n % 100;
  if (a > 20 || a < 10)
    switch (a % 10) {
      case 1:
        return n + "st";
      case 2:
        return n + "nd";
      case 3:
        return n + "rd";
    }
  return n + "th";
}, d_ = {
  ordinalNumber: u_,
  era: Ro({
    values: r_,
    defaultWidth: "wide"
  }),
  quarter: Ro({
    values: i_,
    defaultWidth: "wide",
    argumentCallback: (o) => o - 1
  }),
  month: Ro({
    values: o_,
    defaultWidth: "wide"
  }),
  day: Ro({
    values: l_,
    defaultWidth: "wide"
  }),
  dayPeriod: Ro({
    values: s_,
    defaultWidth: "wide",
    formattingValues: c_,
    defaultFormattingWidth: "wide"
  })
};
function zo(o) {
  return (i, n = {}) => {
    const a = n.width, l = a && o.matchPatterns[a] || o.matchPatterns[o.defaultMatchWidth], c = i.match(l);
    if (!c)
      return null;
    const d = c[0], p = a && o.parsePatterns[a] || o.parsePatterns[o.defaultParseWidth], m = Array.isArray(p) ? p_(p, (b) => b.test(d)) : (
      // [TODO] -- I challenge you to fix the type
      f_(p, (b) => b.test(d))
    );
    let g;
    g = o.valueCallback ? o.valueCallback(m) : m, g = n.valueCallback ? (
      // [TODO] -- I challenge you to fix the type
      n.valueCallback(g)
    ) : g;
    const y = i.slice(d.length);
    return { value: g, rest: y };
  };
}
function f_(o, i) {
  for (const n in o)
    if (Object.prototype.hasOwnProperty.call(o, n) && i(o[n]))
      return n;
}
function p_(o, i) {
  for (let n = 0; n < o.length; n++)
    if (i(o[n]))
      return n;
}
function h_(o) {
  return (i, n = {}) => {
    const a = i.match(o.matchPattern);
    if (!a) return null;
    const l = a[0], c = i.match(o.parsePattern);
    if (!c) return null;
    let d = o.valueCallback ? o.valueCallback(c[0]) : c[0];
    d = n.valueCallback ? n.valueCallback(d) : d;
    const p = i.slice(l.length);
    return { value: d, rest: p };
  };
}
const m_ = /^(\d+)(th|st|nd|rd)?/i, g_ = /\d+/i, v_ = {
  narrow: /^(b|a)/i,
  abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
  wide: /^(before christ|before common era|anno domini|common era)/i
}, b_ = {
  any: [/^b/i, /^(a|c)/i]
}, y_ = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](th|st|nd|rd)? quarter/i
}, x_ = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, w_ = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
  wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
}, __ = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^may/i,
    /^jun/i,
    /^jul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, k_ = {
  narrow: /^[smtwf]/i,
  short: /^(su|mo|tu|we|th|fr|sa)/i,
  abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
  wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
}, S_ = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
}, D_ = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
}, E_ = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
}, M_ = {
  ordinalNumber: h_({
    matchPattern: m_,
    parsePattern: g_,
    valueCallback: (o) => parseInt(o, 10)
  }),
  era: zo({
    matchPatterns: v_,
    defaultMatchWidth: "wide",
    parsePatterns: b_,
    defaultParseWidth: "any"
  }),
  quarter: zo({
    matchPatterns: y_,
    defaultMatchWidth: "wide",
    parsePatterns: x_,
    defaultParseWidth: "any",
    valueCallback: (o) => o + 1
  }),
  month: zo({
    matchPatterns: w_,
    defaultMatchWidth: "wide",
    parsePatterns: __,
    defaultParseWidth: "any"
  }),
  day: zo({
    matchPatterns: k_,
    defaultMatchWidth: "wide",
    parsePatterns: S_,
    defaultParseWidth: "any"
  }),
  dayPeriod: zo({
    matchPatterns: D_,
    defaultMatchWidth: "any",
    parsePatterns: E_,
    defaultParseWidth: "any"
  })
}, Fb = {
  code: "en-US",
  formatDistance: Iw,
  formatLong: t_,
  formatRelative: n_,
  localize: d_,
  match: M_,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
};
function T_(o, i) {
  const n = me(o, i?.in);
  return Ti(n, ic(n)) + 1;
}
function kf(o, i) {
  const n = me(o, i?.in), a = +Mi(n) - +Vw(n);
  return Math.round(a / Yb) + 1;
}
function Sf(o, i) {
  const n = me(o, i?.in), a = n.getFullYear(), l = Ar(), c = i?.firstWeekContainsDate ?? i?.locale?.options?.firstWeekContainsDate ?? l.firstWeekContainsDate ?? l.locale?.options?.firstWeekContainsDate ?? 1, d = Ve(i?.in || o, 0);
  d.setFullYear(a + 1, 0, c), d.setHours(0, 0, 0, 0);
  const p = gn(d, i), m = Ve(i?.in || o, 0);
  m.setFullYear(a, 0, c), m.setHours(0, 0, 0, 0);
  const g = gn(m, i);
  return +n >= +p ? a + 1 : +n >= +g ? a : a - 1;
}
function C_(o, i) {
  const n = Ar(), a = i?.firstWeekContainsDate ?? i?.locale?.options?.firstWeekContainsDate ?? n.firstWeekContainsDate ?? n.locale?.options?.firstWeekContainsDate ?? 1, l = Sf(o, i), c = Ve(i?.in || o, 0);
  return c.setFullYear(l, 0, a), c.setHours(0, 0, 0, 0), gn(c, i);
}
function Vb(o, i) {
  const n = me(o, i?.in), a = +gn(n, i) - +C_(n, i);
  return Math.round(a / Yb) + 1;
}
function Fe(o, i) {
  const n = o < 0 ? "-" : "", a = Math.abs(o).toString().padStart(i, "0");
  return n + a;
}
const Fn = {
  // Year
  y(o, i) {
    const n = o.getFullYear(), a = n > 0 ? n : 1 - n;
    return Fe(i === "yy" ? a % 100 : a, i.length);
  },
  // Month
  M(o, i) {
    const n = o.getMonth();
    return i === "M" ? String(n + 1) : Fe(n + 1, 2);
  },
  // Day of the month
  d(o, i) {
    return Fe(o.getDate(), i.length);
  },
  // AM or PM
  a(o, i) {
    const n = o.getHours() / 12 >= 1 ? "pm" : "am";
    switch (i) {
      case "a":
      case "aa":
        return n.toUpperCase();
      case "aaa":
        return n;
      case "aaaaa":
        return n[0];
      default:
        return n === "am" ? "a.m." : "p.m.";
    }
  },
  // Hour [1-12]
  h(o, i) {
    return Fe(o.getHours() % 12 || 12, i.length);
  },
  // Hour [0-23]
  H(o, i) {
    return Fe(o.getHours(), i.length);
  },
  // Minute
  m(o, i) {
    return Fe(o.getMinutes(), i.length);
  },
  // Second
  s(o, i) {
    return Fe(o.getSeconds(), i.length);
  },
  // Fraction of second
  S(o, i) {
    const n = i.length, a = o.getMilliseconds(), l = Math.trunc(
      a * Math.pow(10, n - 3)
    );
    return Fe(l, i.length);
  }
}, xi = {
  midnight: "midnight",
  noon: "noon",
  morning: "morning",
  afternoon: "afternoon",
  evening: "evening",
  night: "night"
}, uv = {
  // Era
  G: function(o, i, n) {
    const a = o.getFullYear() > 0 ? 1 : 0;
    switch (i) {
      // AD, BC
      case "G":
      case "GG":
      case "GGG":
        return n.era(a, { width: "abbreviated" });
      // A, B
      case "GGGGG":
        return n.era(a, { width: "narrow" });
      default:
        return n.era(a, { width: "wide" });
    }
  },
  // Year
  y: function(o, i, n) {
    if (i === "yo") {
      const a = o.getFullYear(), l = a > 0 ? a : 1 - a;
      return n.ordinalNumber(l, { unit: "year" });
    }
    return Fn.y(o, i);
  },
  // Local week-numbering year
  Y: function(o, i, n, a) {
    const l = Sf(o, a), c = l > 0 ? l : 1 - l;
    if (i === "YY") {
      const d = c % 100;
      return Fe(d, 2);
    }
    return i === "Yo" ? n.ordinalNumber(c, { unit: "year" }) : Fe(c, i.length);
  },
  // ISO week-numbering year
  R: function(o, i) {
    const n = Ub(o);
    return Fe(n, i.length);
  },
  // Extended year. This is a single number designating the year of this calendar system.
  // The main difference between `y` and `u` localizers are B.C. years:
  // | Year | `y` | `u` |
  // |------|-----|-----|
  // | AC 1 |   1 |   1 |
  // | BC 1 |   1 |   0 |
  // | BC 2 |   2 |  -1 |
  // Also `yy` always returns the last two digits of a year,
  // while `uu` pads single digit years to 2 characters and returns other years unchanged.
  u: function(o, i) {
    const n = o.getFullYear();
    return Fe(n, i.length);
  },
  // Quarter
  Q: function(o, i, n) {
    const a = Math.ceil((o.getMonth() + 1) / 3);
    switch (i) {
      // 1, 2, 3, 4
      case "Q":
        return String(a);
      // 01, 02, 03, 04
      case "QQ":
        return Fe(a, 2);
      // 1st, 2nd, 3rd, 4th
      case "Qo":
        return n.ordinalNumber(a, { unit: "quarter" });
      // Q1, Q2, Q3, Q4
      case "QQQ":
        return n.quarter(a, {
          width: "abbreviated",
          context: "formatting"
        });
      // 1, 2, 3, 4 (narrow quarter; could be not numerical)
      case "QQQQQ":
        return n.quarter(a, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return n.quarter(a, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Stand-alone quarter
  q: function(o, i, n) {
    const a = Math.ceil((o.getMonth() + 1) / 3);
    switch (i) {
      // 1, 2, 3, 4
      case "q":
        return String(a);
      // 01, 02, 03, 04
      case "qq":
        return Fe(a, 2);
      // 1st, 2nd, 3rd, 4th
      case "qo":
        return n.ordinalNumber(a, { unit: "quarter" });
      // Q1, Q2, Q3, Q4
      case "qqq":
        return n.quarter(a, {
          width: "abbreviated",
          context: "standalone"
        });
      // 1, 2, 3, 4 (narrow quarter; could be not numerical)
      case "qqqqq":
        return n.quarter(a, {
          width: "narrow",
          context: "standalone"
        });
      default:
        return n.quarter(a, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  // Month
  M: function(o, i, n) {
    const a = o.getMonth();
    switch (i) {
      case "M":
      case "MM":
        return Fn.M(o, i);
      // 1st, 2nd, ..., 12th
      case "Mo":
        return n.ordinalNumber(a + 1, { unit: "month" });
      // Jan, Feb, ..., Dec
      case "MMM":
        return n.month(a, {
          width: "abbreviated",
          context: "formatting"
        });
      // J, F, ..., D
      case "MMMMM":
        return n.month(a, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return n.month(a, { width: "wide", context: "formatting" });
    }
  },
  // Stand-alone month
  L: function(o, i, n) {
    const a = o.getMonth();
    switch (i) {
      // 1, 2, ..., 12
      case "L":
        return String(a + 1);
      // 01, 02, ..., 12
      case "LL":
        return Fe(a + 1, 2);
      // 1st, 2nd, ..., 12th
      case "Lo":
        return n.ordinalNumber(a + 1, { unit: "month" });
      // Jan, Feb, ..., Dec
      case "LLL":
        return n.month(a, {
          width: "abbreviated",
          context: "standalone"
        });
      // J, F, ..., D
      case "LLLLL":
        return n.month(a, {
          width: "narrow",
          context: "standalone"
        });
      default:
        return n.month(a, { width: "wide", context: "standalone" });
    }
  },
  // Local week of year
  w: function(o, i, n, a) {
    const l = Vb(o, a);
    return i === "wo" ? n.ordinalNumber(l, { unit: "week" }) : Fe(l, i.length);
  },
  // ISO week of year
  I: function(o, i, n) {
    const a = kf(o);
    return i === "Io" ? n.ordinalNumber(a, { unit: "week" }) : Fe(a, i.length);
  },
  // Day of the month
  d: function(o, i, n) {
    return i === "do" ? n.ordinalNumber(o.getDate(), { unit: "date" }) : Fn.d(o, i);
  },
  // Day of year
  D: function(o, i, n) {
    const a = T_(o);
    return i === "Do" ? n.ordinalNumber(a, { unit: "dayOfYear" }) : Fe(a, i.length);
  },
  // Day of week
  E: function(o, i, n) {
    const a = o.getDay();
    switch (i) {
      // Tue
      case "E":
      case "EE":
      case "EEE":
        return n.day(a, {
          width: "abbreviated",
          context: "formatting"
        });
      // T
      case "EEEEE":
        return n.day(a, {
          width: "narrow",
          context: "formatting"
        });
      // Tu
      case "EEEEEE":
        return n.day(a, {
          width: "short",
          context: "formatting"
        });
      default:
        return n.day(a, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Local day of week
  e: function(o, i, n, a) {
    const l = o.getDay(), c = (l - a.weekStartsOn + 8) % 7 || 7;
    switch (i) {
      // Numerical value (Nth day of week with current locale or weekStartsOn)
      case "e":
        return String(c);
      // Padded numerical value
      case "ee":
        return Fe(c, 2);
      // 1st, 2nd, ..., 7th
      case "eo":
        return n.ordinalNumber(c, { unit: "day" });
      case "eee":
        return n.day(l, {
          width: "abbreviated",
          context: "formatting"
        });
      // T
      case "eeeee":
        return n.day(l, {
          width: "narrow",
          context: "formatting"
        });
      // Tu
      case "eeeeee":
        return n.day(l, {
          width: "short",
          context: "formatting"
        });
      default:
        return n.day(l, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Stand-alone local day of week
  c: function(o, i, n, a) {
    const l = o.getDay(), c = (l - a.weekStartsOn + 8) % 7 || 7;
    switch (i) {
      // Numerical value (same as in `e`)
      case "c":
        return String(c);
      // Padded numerical value
      case "cc":
        return Fe(c, i.length);
      // 1st, 2nd, ..., 7th
      case "co":
        return n.ordinalNumber(c, { unit: "day" });
      case "ccc":
        return n.day(l, {
          width: "abbreviated",
          context: "standalone"
        });
      // T
      case "ccccc":
        return n.day(l, {
          width: "narrow",
          context: "standalone"
        });
      // Tu
      case "cccccc":
        return n.day(l, {
          width: "short",
          context: "standalone"
        });
      default:
        return n.day(l, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  // ISO day of week
  i: function(o, i, n) {
    const a = o.getDay(), l = a === 0 ? 7 : a;
    switch (i) {
      // 2
      case "i":
        return String(l);
      // 02
      case "ii":
        return Fe(l, i.length);
      // 2nd
      case "io":
        return n.ordinalNumber(l, { unit: "day" });
      // Tue
      case "iii":
        return n.day(a, {
          width: "abbreviated",
          context: "formatting"
        });
      // T
      case "iiiii":
        return n.day(a, {
          width: "narrow",
          context: "formatting"
        });
      // Tu
      case "iiiiii":
        return n.day(a, {
          width: "short",
          context: "formatting"
        });
      default:
        return n.day(a, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // AM or PM
  a: function(o, i, n) {
    const l = o.getHours() / 12 >= 1 ? "pm" : "am";
    switch (i) {
      case "a":
      case "aa":
        return n.dayPeriod(l, {
          width: "abbreviated",
          context: "formatting"
        });
      case "aaa":
        return n.dayPeriod(l, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "aaaaa":
        return n.dayPeriod(l, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return n.dayPeriod(l, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // AM, PM, midnight, noon
  b: function(o, i, n) {
    const a = o.getHours();
    let l;
    switch (a === 12 ? l = xi.noon : a === 0 ? l = xi.midnight : l = a / 12 >= 1 ? "pm" : "am", i) {
      case "b":
      case "bb":
        return n.dayPeriod(l, {
          width: "abbreviated",
          context: "formatting"
        });
      case "bbb":
        return n.dayPeriod(l, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "bbbbb":
        return n.dayPeriod(l, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return n.dayPeriod(l, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // in the morning, in the afternoon, in the evening, at night
  B: function(o, i, n) {
    const a = o.getHours();
    let l;
    switch (a >= 17 ? l = xi.evening : a >= 12 ? l = xi.afternoon : a >= 4 ? l = xi.morning : l = xi.night, i) {
      case "B":
      case "BB":
      case "BBB":
        return n.dayPeriod(l, {
          width: "abbreviated",
          context: "formatting"
        });
      case "BBBBB":
        return n.dayPeriod(l, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return n.dayPeriod(l, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Hour [1-12]
  h: function(o, i, n) {
    if (i === "ho") {
      let a = o.getHours() % 12;
      return a === 0 && (a = 12), n.ordinalNumber(a, { unit: "hour" });
    }
    return Fn.h(o, i);
  },
  // Hour [0-23]
  H: function(o, i, n) {
    return i === "Ho" ? n.ordinalNumber(o.getHours(), { unit: "hour" }) : Fn.H(o, i);
  },
  // Hour [0-11]
  K: function(o, i, n) {
    const a = o.getHours() % 12;
    return i === "Ko" ? n.ordinalNumber(a, { unit: "hour" }) : Fe(a, i.length);
  },
  // Hour [1-24]
  k: function(o, i, n) {
    let a = o.getHours();
    return a === 0 && (a = 24), i === "ko" ? n.ordinalNumber(a, { unit: "hour" }) : Fe(a, i.length);
  },
  // Minute
  m: function(o, i, n) {
    return i === "mo" ? n.ordinalNumber(o.getMinutes(), { unit: "minute" }) : Fn.m(o, i);
  },
  // Second
  s: function(o, i, n) {
    return i === "so" ? n.ordinalNumber(o.getSeconds(), { unit: "second" }) : Fn.s(o, i);
  },
  // Fraction of second
  S: function(o, i) {
    return Fn.S(o, i);
  },
  // Timezone (ISO-8601. If offset is 0, output is always `'Z'`)
  X: function(o, i, n) {
    const a = o.getTimezoneOffset();
    if (a === 0)
      return "Z";
    switch (i) {
      // Hours and optional minutes
      case "X":
        return fv(a);
      // Hours, minutes and optional seconds without `:` delimiter
      // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
      // so this token always has the same output as `XX`
      case "XXXX":
      case "XX":
        return wr(a);
      // Hours and minutes with `:` delimiter
      default:
        return wr(a, ":");
    }
  },
  // Timezone (ISO-8601. If offset is 0, output is `'+00:00'` or equivalent)
  x: function(o, i, n) {
    const a = o.getTimezoneOffset();
    switch (i) {
      // Hours and optional minutes
      case "x":
        return fv(a);
      // Hours, minutes and optional seconds without `:` delimiter
      // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
      // so this token always has the same output as `xx`
      case "xxxx":
      case "xx":
        return wr(a);
      // Hours and minutes with `:` delimiter
      default:
        return wr(a, ":");
    }
  },
  // Timezone (GMT)
  O: function(o, i, n) {
    const a = o.getTimezoneOffset();
    switch (i) {
      // Short
      case "O":
      case "OO":
      case "OOO":
        return "GMT" + dv(a, ":");
      default:
        return "GMT" + wr(a, ":");
    }
  },
  // Timezone (specific non-location)
  z: function(o, i, n) {
    const a = o.getTimezoneOffset();
    switch (i) {
      // Short
      case "z":
      case "zz":
      case "zzz":
        return "GMT" + dv(a, ":");
      default:
        return "GMT" + wr(a, ":");
    }
  },
  // Seconds timestamp
  t: function(o, i, n) {
    const a = Math.trunc(+o / 1e3);
    return Fe(a, i.length);
  },
  // Milliseconds timestamp
  T: function(o, i, n) {
    return Fe(+o, i.length);
  }
};
function dv(o, i = "") {
  const n = o > 0 ? "-" : "+", a = Math.abs(o), l = Math.trunc(a / 60), c = a % 60;
  return c === 0 ? n + String(l) : n + String(l) + i + Fe(c, 2);
}
function fv(o, i) {
  return o % 60 === 0 ? (o > 0 ? "-" : "+") + Fe(Math.abs(o) / 60, 2) : wr(o, i);
}
function wr(o, i = "") {
  const n = o > 0 ? "-" : "+", a = Math.abs(o), l = Fe(Math.trunc(a / 60), 2), c = Fe(a % 60, 2);
  return n + l + i + c;
}
const pv = (o, i) => {
  switch (o) {
    case "P":
      return i.date({ width: "short" });
    case "PP":
      return i.date({ width: "medium" });
    case "PPP":
      return i.date({ width: "long" });
    default:
      return i.date({ width: "full" });
  }
}, Gb = (o, i) => {
  switch (o) {
    case "p":
      return i.time({ width: "short" });
    case "pp":
      return i.time({ width: "medium" });
    case "ppp":
      return i.time({ width: "long" });
    default:
      return i.time({ width: "full" });
  }
}, N_ = (o, i) => {
  const n = o.match(/(P+)(p+)?/) || [], a = n[1], l = n[2];
  if (!l)
    return pv(o, i);
  let c;
  switch (a) {
    case "P":
      c = i.dateTime({ width: "short" });
      break;
    case "PP":
      c = i.dateTime({ width: "medium" });
      break;
    case "PPP":
      c = i.dateTime({ width: "long" });
      break;
    default:
      c = i.dateTime({ width: "full" });
      break;
  }
  return c.replace("{{date}}", pv(a, i)).replace("{{time}}", Gb(l, i));
}, nf = {
  p: Gb,
  P: N_
}, O_ = /^D+$/, j_ = /^Y+$/, A_ = ["D", "DD", "YY", "YYYY"];
function R_(o) {
  return O_.test(o);
}
function z_(o) {
  return j_.test(o);
}
function L_(o, i, n) {
  const a = Y_(o, i, n);
  if (console.warn(a), A_.includes(o)) throw new RangeError(a);
}
function Y_(o, i, n) {
  const a = o[0] === "Y" ? "years" : "days of the month";
  return `Use \`${o.toLowerCase()}\` instead of \`${o}\` (in \`${i}\`) for formatting ${a} to the input \`${n}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`;
}
const H_ = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g, U_ = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g, B_ = /^'([^]*?)'?$/, q_ = /''/g, Q_ = /[a-zA-Z]/;
function hv(o, i, n) {
  const a = Ar(), l = n?.locale ?? a.locale ?? Fb, c = n?.firstWeekContainsDate ?? n?.locale?.options?.firstWeekContainsDate ?? a.firstWeekContainsDate ?? a.locale?.options?.firstWeekContainsDate ?? 1, d = n?.weekStartsOn ?? n?.locale?.options?.weekStartsOn ?? a.weekStartsOn ?? a.locale?.options?.weekStartsOn ?? 0, p = me(o, n?.in);
  if (!Ci(p))
    throw new RangeError("Invalid time value");
  let m = i.match(U_).map((y) => {
    const b = y[0];
    if (b === "p" || b === "P") {
      const _ = nf[b];
      return _(y, l.formatLong);
    }
    return y;
  }).join("").match(H_).map((y) => {
    if (y === "''")
      return { isToken: !1, value: "'" };
    const b = y[0];
    if (b === "'")
      return { isToken: !1, value: P_(y) };
    if (uv[b])
      return { isToken: !0, value: y };
    if (b.match(Q_))
      throw new RangeError(
        "Format string contains an unescaped latin alphabet character `" + b + "`"
      );
    return { isToken: !1, value: y };
  });
  l.localize.preprocessor && (m = l.localize.preprocessor(p, m));
  const g = {
    firstWeekContainsDate: c,
    weekStartsOn: d,
    locale: l
  };
  return m.map((y) => {
    if (!y.isToken) return y.value;
    const b = y.value;
    (!n?.useAdditionalWeekYearTokens && z_(b) || !n?.useAdditionalDayOfYearTokens && R_(b)) && L_(b, i, String(o));
    const _ = uv[b[0]];
    return _(p, b, l.localize, g);
  }).join("");
}
function P_(o) {
  const i = o.match(B_);
  return i ? i[1].replace(q_, "'") : o;
}
function mv(o, i) {
  return me(o, i?.in).getDate();
}
function F_(o, i) {
  return me(o, i?.in).getDay();
}
function V_(o, i) {
  const n = me(o, i?.in), a = n.getFullYear(), l = n.getMonth(), c = Ve(n, 0);
  return c.setFullYear(a, l + 1, 0), c.setHours(0, 0, 0, 0), c.getDate();
}
function G_() {
  return Object.assign({}, Ar());
}
function Tt(o, i) {
  return me(o, i?.in).getHours();
}
function X_(o, i) {
  const n = me(o, i?.in).getDay();
  return n === 0 ? 7 : n;
}
function Ct(o, i) {
  return me(o, i?.in).getMinutes();
}
function Ft(o, i) {
  return me(o, i?.in).getMonth();
}
function Xn(o) {
  return me(o).getSeconds();
}
function rf(o) {
  return +me(o);
}
function Ne(o, i) {
  return me(o, i?.in).getFullYear();
}
function pn(o, i) {
  return +me(o) > +me(i);
}
function Ba(o, i) {
  return +me(o) < +me(i);
}
function Z_(o, i) {
  return +me(o) == +me(i);
}
function K_(o, i) {
  const n = W_(i) ? new i(0) : Ve(i, 0);
  return n.setFullYear(o.getFullYear(), o.getMonth(), o.getDate()), n.setHours(
    o.getHours(),
    o.getMinutes(),
    o.getSeconds(),
    o.getMilliseconds()
  ), n;
}
function W_(o) {
  return typeof o == "function" && o.prototype?.constructor === o;
}
const I_ = 10;
class Xb {
  subPriority = 0;
  validate(i, n) {
    return !0;
  }
}
class J_ extends Xb {
  constructor(i, n, a, l, c) {
    super(), this.value = i, this.validateValue = n, this.setValue = a, this.priority = l, c && (this.subPriority = c);
  }
  validate(i, n) {
    return this.validateValue(i, this.value, n);
  }
  set(i, n, a) {
    return this.setValue(i, n, this.value, a);
  }
}
class $_ extends Xb {
  priority = I_;
  subPriority = -1;
  constructor(i, n) {
    super(), this.context = i || ((a) => Ve(n, a));
  }
  set(i, n) {
    return n.timestampIsSet ? i : Ve(i, K_(i, this.context));
  }
}
class Be {
  run(i, n, a, l) {
    const c = this.parse(i, n, a, l);
    return c ? {
      setter: new J_(
        c.value,
        this.validate,
        this.set,
        this.priority,
        this.subPriority
      ),
      rest: c.rest
    } : null;
  }
  validate(i, n, a) {
    return !0;
  }
}
class ek extends Be {
  priority = 140;
  parse(i, n, a) {
    switch (n) {
      // AD, BC
      case "G":
      case "GG":
      case "GGG":
        return a.era(i, { width: "abbreviated" }) || a.era(i, { width: "narrow" });
      // A, B
      case "GGGGG":
        return a.era(i, { width: "narrow" });
      default:
        return a.era(i, { width: "wide" }) || a.era(i, { width: "abbreviated" }) || a.era(i, { width: "narrow" });
    }
  }
  set(i, n, a) {
    return n.era = a, i.setFullYear(a, 0, 1), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = ["R", "u", "t", "T"];
}
const ut = {
  month: /^(1[0-2]|0?\d)/,
  // 0 to 12
  date: /^(3[0-1]|[0-2]?\d)/,
  // 0 to 31
  dayOfYear: /^(36[0-6]|3[0-5]\d|[0-2]?\d?\d)/,
  // 0 to 366
  week: /^(5[0-3]|[0-4]?\d)/,
  // 0 to 53
  hour23h: /^(2[0-3]|[0-1]?\d)/,
  // 0 to 23
  hour24h: /^(2[0-4]|[0-1]?\d)/,
  // 0 to 24
  hour11h: /^(1[0-1]|0?\d)/,
  // 0 to 11
  hour12h: /^(1[0-2]|0?\d)/,
  // 0 to 12
  minute: /^[0-5]?\d/,
  // 0 to 59
  second: /^[0-5]?\d/,
  // 0 to 59
  singleDigit: /^\d/,
  // 0 to 9
  twoDigits: /^\d{1,2}/,
  // 0 to 99
  threeDigits: /^\d{1,3}/,
  // 0 to 999
  fourDigits: /^\d{1,4}/,
  // 0 to 9999
  anyDigitsSigned: /^-?\d+/,
  singleDigitSigned: /^-?\d/,
  // 0 to 9, -0 to -9
  twoDigitsSigned: /^-?\d{1,2}/,
  // 0 to 99, -0 to -99
  threeDigitsSigned: /^-?\d{1,3}/,
  // 0 to 999, -0 to -999
  fourDigitsSigned: /^-?\d{1,4}/
  // 0 to 9999, -0 to -9999
}, Ha = {
  basicOptionalMinutes: /^([+-])(\d{2})(\d{2})?|Z/,
  basic: /^([+-])(\d{2})(\d{2})|Z/,
  basicOptionalSeconds: /^([+-])(\d{2})(\d{2})((\d{2}))?|Z/,
  extended: /^([+-])(\d{2}):(\d{2})|Z/,
  extendedOptionalSeconds: /^([+-])(\d{2}):(\d{2})(:(\d{2}))?|Z/
};
function dt(o, i) {
  return o && {
    value: i(o.value),
    rest: o.rest
  };
}
function at(o, i) {
  const n = i.match(o);
  return n ? {
    value: parseInt(n[0], 10),
    rest: i.slice(n[0].length)
  } : null;
}
function Ua(o, i) {
  const n = i.match(o);
  if (!n)
    return null;
  if (n[0] === "Z")
    return {
      value: 0,
      rest: i.slice(1)
    };
  const a = n[1] === "+" ? 1 : -1, l = n[2] ? parseInt(n[2], 10) : 0, c = n[3] ? parseInt(n[3], 10) : 0, d = n[5] ? parseInt(n[5], 10) : 0;
  return {
    value: a * (l * rc + c * nc + d * Qw),
    rest: i.slice(n[0].length)
  };
}
function Zb(o) {
  return at(ut.anyDigitsSigned, o);
}
function ot(o, i) {
  switch (o) {
    case 1:
      return at(ut.singleDigit, i);
    case 2:
      return at(ut.twoDigits, i);
    case 3:
      return at(ut.threeDigits, i);
    case 4:
      return at(ut.fourDigits, i);
    default:
      return at(new RegExp("^\\d{1," + o + "}"), i);
  }
}
function Ps(o, i) {
  switch (o) {
    case 1:
      return at(ut.singleDigitSigned, i);
    case 2:
      return at(ut.twoDigitsSigned, i);
    case 3:
      return at(ut.threeDigitsSigned, i);
    case 4:
      return at(ut.fourDigitsSigned, i);
    default:
      return at(new RegExp("^-?\\d{1," + o + "}"), i);
  }
}
function Df(o) {
  switch (o) {
    case "morning":
      return 4;
    case "evening":
      return 17;
    case "pm":
    case "noon":
    case "afternoon":
      return 12;
    default:
      return 0;
  }
}
function Kb(o, i) {
  const n = i > 0, a = n ? i : 1 - i;
  let l;
  if (a <= 50)
    l = o || 100;
  else {
    const c = a + 50, d = Math.trunc(c / 100) * 100, p = o >= c % 100;
    l = o + d - (p ? 100 : 0);
  }
  return n ? l : 1 - l;
}
function Wb(o) {
  return o % 400 === 0 || o % 4 === 0 && o % 100 !== 0;
}
class tk extends Be {
  priority = 130;
  incompatibleTokens = ["Y", "R", "u", "w", "I", "i", "e", "c", "t", "T"];
  parse(i, n, a) {
    const l = (c) => ({
      year: c,
      isTwoDigitYear: n === "yy"
    });
    switch (n) {
      case "y":
        return dt(ot(4, i), l);
      case "yo":
        return dt(
          a.ordinalNumber(i, {
            unit: "year"
          }),
          l
        );
      default:
        return dt(ot(n.length, i), l);
    }
  }
  validate(i, n) {
    return n.isTwoDigitYear || n.year > 0;
  }
  set(i, n, a) {
    const l = i.getFullYear();
    if (a.isTwoDigitYear) {
      const d = Kb(
        a.year,
        l
      );
      return i.setFullYear(d, 0, 1), i.setHours(0, 0, 0, 0), i;
    }
    const c = !("era" in n) || n.era === 1 ? a.year : 1 - a.year;
    return i.setFullYear(c, 0, 1), i.setHours(0, 0, 0, 0), i;
  }
}
class ak extends Be {
  priority = 130;
  parse(i, n, a) {
    const l = (c) => ({
      year: c,
      isTwoDigitYear: n === "YY"
    });
    switch (n) {
      case "Y":
        return dt(ot(4, i), l);
      case "Yo":
        return dt(
          a.ordinalNumber(i, {
            unit: "year"
          }),
          l
        );
      default:
        return dt(ot(n.length, i), l);
    }
  }
  validate(i, n) {
    return n.isTwoDigitYear || n.year > 0;
  }
  set(i, n, a, l) {
    const c = Sf(i, l);
    if (a.isTwoDigitYear) {
      const p = Kb(
        a.year,
        c
      );
      return i.setFullYear(
        p,
        0,
        l.firstWeekContainsDate
      ), i.setHours(0, 0, 0, 0), gn(i, l);
    }
    const d = !("era" in n) || n.era === 1 ? a.year : 1 - a.year;
    return i.setFullYear(d, 0, l.firstWeekContainsDate), i.setHours(0, 0, 0, 0), gn(i, l);
  }
  incompatibleTokens = [
    "y",
    "R",
    "u",
    "Q",
    "q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "i",
    "t",
    "T"
  ];
}
class nk extends Be {
  priority = 130;
  parse(i, n) {
    return Ps(n === "R" ? 4 : n.length, i);
  }
  set(i, n, a) {
    const l = Ve(i, 0);
    return l.setFullYear(a, 0, 4), l.setHours(0, 0, 0, 0), Mi(l);
  }
  incompatibleTokens = [
    "G",
    "y",
    "Y",
    "u",
    "Q",
    "q",
    "M",
    "L",
    "w",
    "d",
    "D",
    "e",
    "c",
    "t",
    "T"
  ];
}
class rk extends Be {
  priority = 130;
  parse(i, n) {
    return Ps(n === "u" ? 4 : n.length, i);
  }
  set(i, n, a) {
    return i.setFullYear(a, 0, 1), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = ["G", "y", "Y", "R", "w", "I", "i", "e", "c", "t", "T"];
}
class ik extends Be {
  priority = 120;
  parse(i, n, a) {
    switch (n) {
      // 1, 2, 3, 4
      case "Q":
      case "QQ":
        return ot(n.length, i);
      // 1st, 2nd, 3rd, 4th
      case "Qo":
        return a.ordinalNumber(i, { unit: "quarter" });
      // Q1, Q2, Q3, Q4
      case "QQQ":
        return a.quarter(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.quarter(i, {
          width: "narrow",
          context: "formatting"
        });
      // 1, 2, 3, 4 (narrow quarter; could be not numerical)
      case "QQQQQ":
        return a.quarter(i, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return a.quarter(i, {
          width: "wide",
          context: "formatting"
        }) || a.quarter(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.quarter(i, {
          width: "narrow",
          context: "formatting"
        });
    }
  }
  validate(i, n) {
    return n >= 1 && n <= 4;
  }
  set(i, n, a) {
    return i.setMonth((a - 1) * 3, 1), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "Y",
    "R",
    "q",
    "M",
    "L",
    "w",
    "I",
    "d",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"
  ];
}
class ok extends Be {
  priority = 120;
  parse(i, n, a) {
    switch (n) {
      // 1, 2, 3, 4
      case "q":
      case "qq":
        return ot(n.length, i);
      // 1st, 2nd, 3rd, 4th
      case "qo":
        return a.ordinalNumber(i, { unit: "quarter" });
      // Q1, Q2, Q3, Q4
      case "qqq":
        return a.quarter(i, {
          width: "abbreviated",
          context: "standalone"
        }) || a.quarter(i, {
          width: "narrow",
          context: "standalone"
        });
      // 1, 2, 3, 4 (narrow quarter; could be not numerical)
      case "qqqqq":
        return a.quarter(i, {
          width: "narrow",
          context: "standalone"
        });
      default:
        return a.quarter(i, {
          width: "wide",
          context: "standalone"
        }) || a.quarter(i, {
          width: "abbreviated",
          context: "standalone"
        }) || a.quarter(i, {
          width: "narrow",
          context: "standalone"
        });
    }
  }
  validate(i, n) {
    return n >= 1 && n <= 4;
  }
  set(i, n, a) {
    return i.setMonth((a - 1) * 3, 1), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "Y",
    "R",
    "Q",
    "M",
    "L",
    "w",
    "I",
    "d",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"
  ];
}
class lk extends Be {
  incompatibleTokens = [
    "Y",
    "R",
    "q",
    "Q",
    "L",
    "w",
    "I",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"
  ];
  priority = 110;
  parse(i, n, a) {
    const l = (c) => c - 1;
    switch (n) {
      // 1, 2, ..., 12
      case "M":
        return dt(
          at(ut.month, i),
          l
        );
      // 01, 02, ..., 12
      case "MM":
        return dt(ot(2, i), l);
      // 1st, 2nd, ..., 12th
      case "Mo":
        return dt(
          a.ordinalNumber(i, {
            unit: "month"
          }),
          l
        );
      // Jan, Feb, ..., Dec
      case "MMM":
        return a.month(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.month(i, { width: "narrow", context: "formatting" });
      // J, F, ..., D
      case "MMMMM":
        return a.month(i, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return a.month(i, { width: "wide", context: "formatting" }) || a.month(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.month(i, { width: "narrow", context: "formatting" });
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 11;
  }
  set(i, n, a) {
    return i.setMonth(a, 1), i.setHours(0, 0, 0, 0), i;
  }
}
class sk extends Be {
  priority = 110;
  parse(i, n, a) {
    const l = (c) => c - 1;
    switch (n) {
      // 1, 2, ..., 12
      case "L":
        return dt(
          at(ut.month, i),
          l
        );
      // 01, 02, ..., 12
      case "LL":
        return dt(ot(2, i), l);
      // 1st, 2nd, ..., 12th
      case "Lo":
        return dt(
          a.ordinalNumber(i, {
            unit: "month"
          }),
          l
        );
      // Jan, Feb, ..., Dec
      case "LLL":
        return a.month(i, {
          width: "abbreviated",
          context: "standalone"
        }) || a.month(i, { width: "narrow", context: "standalone" });
      // J, F, ..., D
      case "LLLLL":
        return a.month(i, {
          width: "narrow",
          context: "standalone"
        });
      default:
        return a.month(i, { width: "wide", context: "standalone" }) || a.month(i, {
          width: "abbreviated",
          context: "standalone"
        }) || a.month(i, { width: "narrow", context: "standalone" });
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 11;
  }
  set(i, n, a) {
    return i.setMonth(a, 1), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "Y",
    "R",
    "q",
    "Q",
    "M",
    "w",
    "I",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"
  ];
}
function ck(o, i, n) {
  const a = me(o, n?.in), l = Vb(a, n) - i;
  return a.setDate(a.getDate() - l * 7), me(a, n?.in);
}
class uk extends Be {
  priority = 100;
  parse(i, n, a) {
    switch (n) {
      case "w":
        return at(ut.week, i);
      case "wo":
        return a.ordinalNumber(i, { unit: "week" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 1 && n <= 53;
  }
  set(i, n, a, l) {
    return gn(ck(i, a, l), l);
  }
  incompatibleTokens = [
    "y",
    "R",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "i",
    "t",
    "T"
  ];
}
function dk(o, i, n) {
  const a = me(o, n?.in), l = kf(a, n) - i;
  return a.setDate(a.getDate() - l * 7), a;
}
class fk extends Be {
  priority = 100;
  parse(i, n, a) {
    switch (n) {
      case "I":
        return at(ut.week, i);
      case "Io":
        return a.ordinalNumber(i, { unit: "week" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 1 && n <= 53;
  }
  set(i, n, a) {
    return Mi(dk(i, a));
  }
  incompatibleTokens = [
    "y",
    "Y",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "w",
    "d",
    "D",
    "e",
    "c",
    "t",
    "T"
  ];
}
const pk = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], hk = [
  31,
  29,
  31,
  30,
  31,
  30,
  31,
  31,
  30,
  31,
  30,
  31
];
class mk extends Be {
  priority = 90;
  subPriority = 1;
  parse(i, n, a) {
    switch (n) {
      case "d":
        return at(ut.date, i);
      case "do":
        return a.ordinalNumber(i, { unit: "date" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    const a = i.getFullYear(), l = Wb(a), c = i.getMonth();
    return l ? n >= 1 && n <= hk[c] : n >= 1 && n <= pk[c];
  }
  set(i, n, a) {
    return i.setDate(a), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "Y",
    "R",
    "q",
    "Q",
    "w",
    "I",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"
  ];
}
class gk extends Be {
  priority = 90;
  subpriority = 1;
  parse(i, n, a) {
    switch (n) {
      case "D":
      case "DD":
        return at(ut.dayOfYear, i);
      case "Do":
        return a.ordinalNumber(i, { unit: "date" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    const a = i.getFullYear();
    return Wb(a) ? n >= 1 && n <= 366 : n >= 1 && n <= 365;
  }
  set(i, n, a) {
    return i.setMonth(0, a), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "Y",
    "R",
    "q",
    "Q",
    "M",
    "L",
    "w",
    "I",
    "d",
    "E",
    "i",
    "e",
    "c",
    "t",
    "T"
  ];
}
function Ef(o, i, n) {
  const a = Ar(), l = n?.weekStartsOn ?? n?.locale?.options?.weekStartsOn ?? a.weekStartsOn ?? a.locale?.options?.weekStartsOn ?? 0, c = me(o, n?.in), d = c.getDay(), m = (i % 7 + 7) % 7, g = 7 - l, y = i < 0 || i > 6 ? i - (d + g) % 7 : (m + g) % 7 - (d + g) % 7;
  return Sa(c, y, n);
}
class vk extends Be {
  priority = 90;
  parse(i, n, a) {
    switch (n) {
      // Tue
      case "E":
      case "EE":
      case "EEE":
        return a.day(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.day(i, { width: "short", context: "formatting" }) || a.day(i, { width: "narrow", context: "formatting" });
      // T
      case "EEEEE":
        return a.day(i, {
          width: "narrow",
          context: "formatting"
        });
      // Tu
      case "EEEEEE":
        return a.day(i, { width: "short", context: "formatting" }) || a.day(i, { width: "narrow", context: "formatting" });
      default:
        return a.day(i, { width: "wide", context: "formatting" }) || a.day(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.day(i, { width: "short", context: "formatting" }) || a.day(i, { width: "narrow", context: "formatting" });
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 6;
  }
  set(i, n, a, l) {
    return i = Ef(i, a, l), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = ["D", "i", "e", "c", "t", "T"];
}
class bk extends Be {
  priority = 90;
  parse(i, n, a, l) {
    const c = (d) => {
      const p = Math.floor((d - 1) / 7) * 7;
      return (d + l.weekStartsOn + 6) % 7 + p;
    };
    switch (n) {
      // 3
      case "e":
      case "ee":
        return dt(ot(n.length, i), c);
      // 3rd
      case "eo":
        return dt(
          a.ordinalNumber(i, {
            unit: "day"
          }),
          c
        );
      // Tue
      case "eee":
        return a.day(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.day(i, { width: "short", context: "formatting" }) || a.day(i, { width: "narrow", context: "formatting" });
      // T
      case "eeeee":
        return a.day(i, {
          width: "narrow",
          context: "formatting"
        });
      // Tu
      case "eeeeee":
        return a.day(i, { width: "short", context: "formatting" }) || a.day(i, { width: "narrow", context: "formatting" });
      default:
        return a.day(i, { width: "wide", context: "formatting" }) || a.day(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.day(i, { width: "short", context: "formatting" }) || a.day(i, { width: "narrow", context: "formatting" });
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 6;
  }
  set(i, n, a, l) {
    return i = Ef(i, a, l), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "y",
    "R",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "E",
    "i",
    "c",
    "t",
    "T"
  ];
}
class yk extends Be {
  priority = 90;
  parse(i, n, a, l) {
    const c = (d) => {
      const p = Math.floor((d - 1) / 7) * 7;
      return (d + l.weekStartsOn + 6) % 7 + p;
    };
    switch (n) {
      // 3
      case "c":
      case "cc":
        return dt(ot(n.length, i), c);
      // 3rd
      case "co":
        return dt(
          a.ordinalNumber(i, {
            unit: "day"
          }),
          c
        );
      // Tue
      case "ccc":
        return a.day(i, {
          width: "abbreviated",
          context: "standalone"
        }) || a.day(i, { width: "short", context: "standalone" }) || a.day(i, { width: "narrow", context: "standalone" });
      // T
      case "ccccc":
        return a.day(i, {
          width: "narrow",
          context: "standalone"
        });
      // Tu
      case "cccccc":
        return a.day(i, { width: "short", context: "standalone" }) || a.day(i, { width: "narrow", context: "standalone" });
      default:
        return a.day(i, { width: "wide", context: "standalone" }) || a.day(i, {
          width: "abbreviated",
          context: "standalone"
        }) || a.day(i, { width: "short", context: "standalone" }) || a.day(i, { width: "narrow", context: "standalone" });
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 6;
  }
  set(i, n, a, l) {
    return i = Ef(i, a, l), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "y",
    "R",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "E",
    "i",
    "e",
    "t",
    "T"
  ];
}
function xk(o, i, n) {
  const a = me(o, n?.in), l = X_(a, n), c = i - l;
  return Sa(a, c, n);
}
class wk extends Be {
  priority = 90;
  parse(i, n, a) {
    const l = (c) => c === 0 ? 7 : c;
    switch (n) {
      // 2
      case "i":
      case "ii":
        return ot(n.length, i);
      // 2nd
      case "io":
        return a.ordinalNumber(i, { unit: "day" });
      // Tue
      case "iii":
        return dt(
          a.day(i, {
            width: "abbreviated",
            context: "formatting"
          }) || a.day(i, {
            width: "short",
            context: "formatting"
          }) || a.day(i, {
            width: "narrow",
            context: "formatting"
          }),
          l
        );
      // T
      case "iiiii":
        return dt(
          a.day(i, {
            width: "narrow",
            context: "formatting"
          }),
          l
        );
      // Tu
      case "iiiiii":
        return dt(
          a.day(i, {
            width: "short",
            context: "formatting"
          }) || a.day(i, {
            width: "narrow",
            context: "formatting"
          }),
          l
        );
      default:
        return dt(
          a.day(i, {
            width: "wide",
            context: "formatting"
          }) || a.day(i, {
            width: "abbreviated",
            context: "formatting"
          }) || a.day(i, {
            width: "short",
            context: "formatting"
          }) || a.day(i, {
            width: "narrow",
            context: "formatting"
          }),
          l
        );
    }
  }
  validate(i, n) {
    return n >= 1 && n <= 7;
  }
  set(i, n, a) {
    return i = xk(i, a), i.setHours(0, 0, 0, 0), i;
  }
  incompatibleTokens = [
    "y",
    "Y",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "w",
    "d",
    "D",
    "E",
    "e",
    "c",
    "t",
    "T"
  ];
}
class _k extends Be {
  priority = 80;
  parse(i, n, a) {
    switch (n) {
      case "a":
      case "aa":
      case "aaa":
        return a.dayPeriod(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
      case "aaaaa":
        return a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return a.dayPeriod(i, {
          width: "wide",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
    }
  }
  set(i, n, a) {
    return i.setHours(Df(a), 0, 0, 0), i;
  }
  incompatibleTokens = ["b", "B", "H", "k", "t", "T"];
}
class kk extends Be {
  priority = 80;
  parse(i, n, a) {
    switch (n) {
      case "b":
      case "bb":
      case "bbb":
        return a.dayPeriod(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
      case "bbbbb":
        return a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return a.dayPeriod(i, {
          width: "wide",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
    }
  }
  set(i, n, a) {
    return i.setHours(Df(a), 0, 0, 0), i;
  }
  incompatibleTokens = ["a", "B", "H", "k", "t", "T"];
}
class Sk extends Be {
  priority = 80;
  parse(i, n, a) {
    switch (n) {
      case "B":
      case "BB":
      case "BBB":
        return a.dayPeriod(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
      case "BBBBB":
        return a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
      default:
        return a.dayPeriod(i, {
          width: "wide",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "abbreviated",
          context: "formatting"
        }) || a.dayPeriod(i, {
          width: "narrow",
          context: "formatting"
        });
    }
  }
  set(i, n, a) {
    return i.setHours(Df(a), 0, 0, 0), i;
  }
  incompatibleTokens = ["a", "b", "t", "T"];
}
class Dk extends Be {
  priority = 70;
  parse(i, n, a) {
    switch (n) {
      case "h":
        return at(ut.hour12h, i);
      case "ho":
        return a.ordinalNumber(i, { unit: "hour" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 1 && n <= 12;
  }
  set(i, n, a) {
    const l = i.getHours() >= 12;
    return l && a < 12 ? i.setHours(a + 12, 0, 0, 0) : !l && a === 12 ? i.setHours(0, 0, 0, 0) : i.setHours(a, 0, 0, 0), i;
  }
  incompatibleTokens = ["H", "K", "k", "t", "T"];
}
class Ek extends Be {
  priority = 70;
  parse(i, n, a) {
    switch (n) {
      case "H":
        return at(ut.hour23h, i);
      case "Ho":
        return a.ordinalNumber(i, { unit: "hour" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 23;
  }
  set(i, n, a) {
    return i.setHours(a, 0, 0, 0), i;
  }
  incompatibleTokens = ["a", "b", "h", "K", "k", "t", "T"];
}
class Mk extends Be {
  priority = 70;
  parse(i, n, a) {
    switch (n) {
      case "K":
        return at(ut.hour11h, i);
      case "Ko":
        return a.ordinalNumber(i, { unit: "hour" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 11;
  }
  set(i, n, a) {
    return i.getHours() >= 12 && a < 12 ? i.setHours(a + 12, 0, 0, 0) : i.setHours(a, 0, 0, 0), i;
  }
  incompatibleTokens = ["h", "H", "k", "t", "T"];
}
class Tk extends Be {
  priority = 70;
  parse(i, n, a) {
    switch (n) {
      case "k":
        return at(ut.hour24h, i);
      case "ko":
        return a.ordinalNumber(i, { unit: "hour" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 1 && n <= 24;
  }
  set(i, n, a) {
    const l = a <= 24 ? a % 24 : a;
    return i.setHours(l, 0, 0, 0), i;
  }
  incompatibleTokens = ["a", "b", "h", "H", "K", "t", "T"];
}
class Ck extends Be {
  priority = 60;
  parse(i, n, a) {
    switch (n) {
      case "m":
        return at(ut.minute, i);
      case "mo":
        return a.ordinalNumber(i, { unit: "minute" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 59;
  }
  set(i, n, a) {
    return i.setMinutes(a, 0, 0), i;
  }
  incompatibleTokens = ["t", "T"];
}
class Nk extends Be {
  priority = 50;
  parse(i, n, a) {
    switch (n) {
      case "s":
        return at(ut.second, i);
      case "so":
        return a.ordinalNumber(i, { unit: "second" });
      default:
        return ot(n.length, i);
    }
  }
  validate(i, n) {
    return n >= 0 && n <= 59;
  }
  set(i, n, a) {
    return i.setSeconds(a, 0), i;
  }
  incompatibleTokens = ["t", "T"];
}
class Ok extends Be {
  priority = 30;
  parse(i, n) {
    const a = (l) => Math.trunc(l * Math.pow(10, -n.length + 3));
    return dt(ot(n.length, i), a);
  }
  set(i, n, a) {
    return i.setMilliseconds(a), i;
  }
  incompatibleTokens = ["t", "T"];
}
class jk extends Be {
  priority = 10;
  parse(i, n) {
    switch (n) {
      case "X":
        return Ua(
          Ha.basicOptionalMinutes,
          i
        );
      case "XX":
        return Ua(Ha.basic, i);
      case "XXXX":
        return Ua(
          Ha.basicOptionalSeconds,
          i
        );
      case "XXXXX":
        return Ua(
          Ha.extendedOptionalSeconds,
          i
        );
      default:
        return Ua(Ha.extended, i);
    }
  }
  set(i, n, a) {
    return n.timestampIsSet ? i : Ve(
      i,
      i.getTime() - Hs(i) - a
    );
  }
  incompatibleTokens = ["t", "T", "x"];
}
class Ak extends Be {
  priority = 10;
  parse(i, n) {
    switch (n) {
      case "x":
        return Ua(
          Ha.basicOptionalMinutes,
          i
        );
      case "xx":
        return Ua(Ha.basic, i);
      case "xxxx":
        return Ua(
          Ha.basicOptionalSeconds,
          i
        );
      case "xxxxx":
        return Ua(
          Ha.extendedOptionalSeconds,
          i
        );
      default:
        return Ua(Ha.extended, i);
    }
  }
  set(i, n, a) {
    return n.timestampIsSet ? i : Ve(
      i,
      i.getTime() - Hs(i) - a
    );
  }
  incompatibleTokens = ["t", "T", "X"];
}
class Rk extends Be {
  priority = 40;
  parse(i) {
    return Zb(i);
  }
  set(i, n, a) {
    return [Ve(i, a * 1e3), { timestampIsSet: !0 }];
  }
  incompatibleTokens = "*";
}
class zk extends Be {
  priority = 20;
  parse(i) {
    return Zb(i);
  }
  set(i, n, a) {
    return [Ve(i, a), { timestampIsSet: !0 }];
  }
  incompatibleTokens = "*";
}
const Lk = {
  G: new ek(),
  y: new tk(),
  Y: new ak(),
  R: new nk(),
  u: new rk(),
  Q: new ik(),
  q: new ok(),
  M: new lk(),
  L: new sk(),
  w: new uk(),
  I: new fk(),
  d: new mk(),
  D: new gk(),
  E: new vk(),
  e: new bk(),
  c: new yk(),
  i: new wk(),
  a: new _k(),
  b: new kk(),
  B: new Sk(),
  h: new Dk(),
  H: new Ek(),
  K: new Mk(),
  k: new Tk(),
  m: new Ck(),
  s: new Nk(),
  S: new Ok(),
  X: new jk(),
  x: new Ak(),
  t: new Rk(),
  T: new zk()
}, Yk = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g, Hk = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g, Uk = /^'([^]*?)'?$/, Bk = /''/g, qk = /\S/, Qk = /[a-zA-Z]/;
function Pk(o, i, n, a) {
  const l = () => Ve(a?.in || n, NaN), c = G_(), d = a?.locale ?? c.locale ?? Fb, p = a?.firstWeekContainsDate ?? a?.locale?.options?.firstWeekContainsDate ?? c.firstWeekContainsDate ?? c.locale?.options?.firstWeekContainsDate ?? 1, m = a?.weekStartsOn ?? a?.locale?.options?.weekStartsOn ?? c.weekStartsOn ?? c.locale?.options?.weekStartsOn ?? 0;
  if (!i)
    return o ? l() : me(n, a?.in);
  const g = {
    firstWeekContainsDate: p,
    weekStartsOn: m,
    locale: d
  }, y = [new $_(a?.in, n)], b = i.match(Hk).map((S) => {
    const O = S[0];
    if (O in nf) {
      const q = nf[O];
      return q(S, d.formatLong);
    }
    return S;
  }).join("").match(Yk), _ = [];
  for (let S of b) {
    const O = S[0], q = Lk[O];
    if (q) {
      const { incompatibleTokens: L } = q;
      if (Array.isArray(L)) {
        const F = _.find(
          (J) => L.includes(J.token) || J.token === O
        );
        if (F)
          throw new RangeError(
            `The format string mustn't contain \`${F.fullToken}\` and \`${S}\` at the same time`
          );
      } else if (q.incompatibleTokens === "*" && _.length > 0)
        throw new RangeError(
          `The format string mustn't contain \`${S}\` and any other token at the same time`
        );
      _.push({ token: O, fullToken: S });
      const P = q.run(
        o,
        S,
        d.match,
        g
      );
      if (!P)
        return l();
      y.push(P.setter), o = P.rest;
    } else {
      if (O.match(Qk))
        throw new RangeError(
          "Format string contains an unescaped latin alphabet character `" + O + "`"
        );
      if (S === "''" ? S = "'" : O === "'" && (S = Fk(S)), o.indexOf(S) === 0)
        o = o.slice(S.length);
      else
        return l();
    }
  }
  if (o.length > 0 && qk.test(o))
    return l();
  const k = y.map((S) => S.priority).sort((S, O) => O - S).filter((S, O, q) => q.indexOf(S) === O).map(
    (S) => y.filter((O) => O.priority === S).sort((O, q) => q.subPriority - O.subPriority)
  ).map((S) => S[0]);
  let w = me(n, a?.in);
  if (isNaN(+w)) return l();
  const D = {};
  for (const S of k) {
    if (!S.validate(w, g))
      return l();
    const O = S.set(w, D, g);
    Array.isArray(O) ? (w = O[0], Object.assign(D, O[1])) : w = O;
  }
  return w;
}
function Fk(o) {
  return o.match(Uk)[1].replace(Bk, "'");
}
function Vk(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  );
  return a.getFullYear() === l.getFullYear() && a.getMonth() === l.getMonth();
}
function Gk(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  );
  return +af(a) == +af(l);
}
function Xk(o, i, n) {
  const [a, l] = vn(
    n?.in,
    o,
    i
  );
  return a.getFullYear() === l.getFullYear();
}
function qo(o, i, n) {
  const a = +me(o, n?.in), [l, c] = [
    +me(i.start, n?.in),
    +me(i.end, n?.in)
  ].sort((d, p) => d - p);
  return a >= l && a <= c;
}
function Zk(o, i, n) {
  return Sa(o, -1, n);
}
function Kk(o, i) {
  const n = () => Ve(i?.in, NaN), l = $k(o);
  let c;
  if (l.date) {
    const g = e2(l.date, 2);
    c = t2(g.restDateString, g.year);
  }
  if (!c || isNaN(+c)) return n();
  const d = +c;
  let p = 0, m;
  if (l.time && (p = a2(l.time), isNaN(p)))
    return n();
  if (l.timezone) {
    if (m = n2(l.timezone), isNaN(m)) return n();
  } else {
    const g = new Date(d + p), y = me(0, i?.in);
    return y.setFullYear(
      g.getUTCFullYear(),
      g.getUTCMonth(),
      g.getUTCDate()
    ), y.setHours(
      g.getUTCHours(),
      g.getUTCMinutes(),
      g.getUTCSeconds(),
      g.getUTCMilliseconds()
    ), y;
  }
  return me(d + p + m, i?.in);
}
const vs = {
  dateTimeDelimiter: /[T ]/,
  timeZoneDelimiter: /[Z ]/i,
  timezone: /([Z+-].*)$/
}, Wk = /^-?(?:(\d{3})|(\d{2})(?:-?(\d{2}))?|W(\d{2})(?:-?(\d{1}))?|)$/, Ik = /^(\d{2}(?:[.,]\d*)?)(?::?(\d{2}(?:[.,]\d*)?))?(?::?(\d{2}(?:[.,]\d*)?))?$/, Jk = /^([+-])(\d{2})(?::?(\d{2}))?$/;
function $k(o) {
  const i = {}, n = o.split(vs.dateTimeDelimiter);
  let a;
  if (n.length > 2)
    return i;
  if (/:/.test(n[0]) ? a = n[0] : (i.date = n[0], a = n[1], vs.timeZoneDelimiter.test(i.date) && (i.date = o.split(vs.timeZoneDelimiter)[0], a = o.substr(
    i.date.length,
    o.length
  ))), a) {
    const l = vs.timezone.exec(a);
    l ? (i.time = a.replace(l[1], ""), i.timezone = l[1]) : i.time = a;
  }
  return i;
}
function e2(o, i) {
  const n = new RegExp(
    "^(?:(\\d{4}|[+-]\\d{" + (4 + i) + "})|(\\d{2}|[+-]\\d{" + (2 + i) + "})$)"
  ), a = o.match(n);
  if (!a) return { year: NaN, restDateString: "" };
  const l = a[1] ? parseInt(a[1]) : null, c = a[2] ? parseInt(a[2]) : null;
  return {
    year: c === null ? l : c * 100,
    restDateString: o.slice((a[1] || a[2]).length)
  };
}
function t2(o, i) {
  if (i === null) return /* @__PURE__ */ new Date(NaN);
  const n = o.match(Wk);
  if (!n) return /* @__PURE__ */ new Date(NaN);
  const a = !!n[4], l = Lo(n[1]), c = Lo(n[2]) - 1, d = Lo(n[3]), p = Lo(n[4]), m = Lo(n[5]) - 1;
  if (a)
    return s2(i, p, m) ? r2(i, p, m) : /* @__PURE__ */ new Date(NaN);
  {
    const g = /* @__PURE__ */ new Date(0);
    return !o2(i, c, d) || !l2(i, l) ? /* @__PURE__ */ new Date(NaN) : (g.setUTCFullYear(i, c, Math.max(l, d)), g);
  }
}
function Lo(o) {
  return o ? parseInt(o) : 1;
}
function a2(o) {
  const i = o.match(Ik);
  if (!i) return NaN;
  const n = Ld(i[1]), a = Ld(i[2]), l = Ld(i[3]);
  return c2(n, a, l) ? n * rc + a * nc + l * 1e3 : NaN;
}
function Ld(o) {
  return o && parseFloat(o.replace(",", ".")) || 0;
}
function n2(o) {
  if (o === "Z") return 0;
  const i = o.match(Jk);
  if (!i) return 0;
  const n = i[1] === "+" ? -1 : 1, a = parseInt(i[2]), l = i[3] && parseInt(i[3]) || 0;
  return u2(a, l) ? n * (a * rc + l * nc) : NaN;
}
function r2(o, i, n) {
  const a = /* @__PURE__ */ new Date(0);
  a.setUTCFullYear(o, 0, 4);
  const l = a.getUTCDay() || 7, c = (i - 1) * 7 + n + 1 - l;
  return a.setUTCDate(a.getUTCDate() + c), a;
}
const i2 = [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
function Ib(o) {
  return o % 400 === 0 || o % 4 === 0 && o % 100 !== 0;
}
function o2(o, i, n) {
  return i >= 0 && i <= 11 && n >= 1 && n <= (i2[i] || (Ib(o) ? 29 : 28));
}
function l2(o, i) {
  return i >= 1 && i <= (Ib(o) ? 366 : 365);
}
function s2(o, i, n) {
  return i >= 1 && i <= 53 && n >= 0 && n <= 6;
}
function c2(o, i, n) {
  return o === 24 ? i === 0 && n === 0 : n >= 0 && n < 60 && i >= 0 && i < 60 && o >= 0 && o < 25;
}
function u2(o, i) {
  return i >= 0 && i <= 59;
}
function na(o, i, n) {
  const a = me(o, n?.in), l = a.getFullYear(), c = a.getDate(), d = Ve(o, 0);
  d.setFullYear(l, i, 15), d.setHours(0, 0, 0, 0);
  const p = V_(d);
  return a.setMonth(i, Math.min(c, p)), a;
}
function Os(o, i, n) {
  const a = me(o, n?.in);
  return a.setHours(i), a;
}
function js(o, i, n) {
  const a = me(o, n?.in);
  return a.setMinutes(i), a;
}
function _i(o, i, n) {
  const a = me(o, n?.in), l = Math.trunc(a.getMonth() / 3) + 1, c = i - l;
  return na(a, a.getMonth() + c * 3);
}
function As(o, i, n) {
  const a = me(o, n?.in);
  return a.setSeconds(i), a;
}
function La(o, i, n) {
  const a = me(o, n?.in);
  return isNaN(+a) ? Ve(o, NaN) : (a.setFullYear(i), a);
}
function Tr(o, i, n) {
  return Ea(o, -i, n);
}
function Jb(o, i, n) {
  return _f(o, -1, n);
}
function gv(o, i, n) {
  return Us(o, -1, n);
}
function Kn(o, i, n) {
  return Da(o, -i, n);
}
function oc() {
  return typeof window < "u";
}
function zi(o) {
  return $b(o) ? (o.nodeName || "").toLowerCase() : "#document";
}
function ra(o) {
  var i;
  return (o == null || (i = o.ownerDocument) == null ? void 0 : i.defaultView) || window;
}
function Fa(o) {
  var i;
  return (i = ($b(o) ? o.ownerDocument : o.document) || window.document) == null ? void 0 : i.documentElement;
}
function $b(o) {
  return oc() ? o instanceof Node || o instanceof ra(o).Node : !1;
}
function Rt(o) {
  return oc() ? o instanceof Element || o instanceof ra(o).Element : !1;
}
function bn(o) {
  return oc() ? o instanceof HTMLElement || o instanceof ra(o).HTMLElement : !1;
}
function vv(o) {
  return !oc() || typeof ShadowRoot > "u" ? !1 : o instanceof ShadowRoot || o instanceof ra(o).ShadowRoot;
}
function Ko(o) {
  const {
    overflow: i,
    overflowX: n,
    overflowY: a,
    display: l
  } = va(o);
  return /auto|scroll|overlay|hidden|clip/.test(i + a + n) && l !== "inline" && l !== "contents";
}
function d2(o) {
  return /^(table|td|th)$/.test(zi(o));
}
function lc(o) {
  try {
    if (o.matches(":popover-open"))
      return !0;
  } catch {
  }
  try {
    return o.matches(":modal");
  } catch {
    return !1;
  }
}
const f2 = /transform|translate|scale|rotate|perspective|filter/, p2 = /paint|layout|strict|content/, br = (o) => !!o && o !== "none";
let Yd;
function Mf(o) {
  const i = Rt(o) ? va(o) : o;
  return br(i.transform) || br(i.translate) || br(i.scale) || br(i.rotate) || br(i.perspective) || !Tf() && (br(i.backdropFilter) || br(i.filter)) || f2.test(i.willChange || "") || p2.test(i.contain || "");
}
function h2(o) {
  let i = Wn(o);
  for (; bn(i) && !Ni(i); ) {
    if (Mf(i))
      return i;
    if (lc(i))
      return null;
    i = Wn(i);
  }
  return null;
}
function Tf() {
  return Yd == null && (Yd = typeof CSS < "u" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none")), Yd;
}
function Ni(o) {
  return /^(html|body|#document)$/.test(zi(o));
}
function va(o) {
  return ra(o).getComputedStyle(o);
}
function sc(o) {
  return Rt(o) ? {
    scrollLeft: o.scrollLeft,
    scrollTop: o.scrollTop
  } : {
    scrollLeft: o.scrollX,
    scrollTop: o.scrollY
  };
}
function Wn(o) {
  if (zi(o) === "html")
    return o;
  const i = (
    // Step into the shadow DOM of the parent of a slotted node.
    o.assignedSlot || // DOM Element detected.
    o.parentNode || // ShadowRoot detected.
    vv(o) && o.host || // Fallback.
    Fa(o)
  );
  return vv(i) ? i.host : i;
}
function ey(o) {
  const i = Wn(o);
  return Ni(i) ? o.ownerDocument ? o.ownerDocument.body : o.body : bn(i) && Ko(i) ? i : ey(i);
}
function Qo(o, i, n) {
  var a;
  i === void 0 && (i = []), n === void 0 && (n = !0);
  const l = ey(o), c = l === ((a = o.ownerDocument) == null ? void 0 : a.body), d = ra(l);
  if (c) {
    const p = of(d);
    return i.concat(d, d.visualViewport || [], Ko(l) ? l : [], p && n ? Qo(p) : []);
  } else
    return i.concat(l, Qo(l, [], n));
}
function of(o) {
  return o.parent && Object.getPrototypeOf(o.parent) ? o.frameElement : null;
}
const Oi = Math.min, Cr = Math.max, Fs = Math.round, bs = Math.floor, Pa = (o) => ({
  x: o,
  y: o
}), m2 = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function g2(o, i, n) {
  return Cr(o, Oi(i, n));
}
function cc(o, i) {
  return typeof o == "function" ? o(i) : o;
}
function ji(o) {
  return o.split("-")[0];
}
function Wo(o) {
  return o.split("-")[1];
}
function v2(o) {
  return o === "x" ? "y" : "x";
}
function Cf(o) {
  return o === "y" ? "height" : "width";
}
function Sr(o) {
  const i = o[0];
  return i === "t" || i === "b" ? "y" : "x";
}
function Nf(o) {
  return v2(Sr(o));
}
function b2(o, i, n) {
  n === void 0 && (n = !1);
  const a = Wo(o), l = Nf(o), c = Cf(l);
  let d = l === "x" ? a === (n ? "end" : "start") ? "right" : "left" : a === "start" ? "bottom" : "top";
  return i.reference[c] > i.floating[c] && (d = Vs(d)), [d, Vs(d)];
}
function y2(o) {
  const i = Vs(o);
  return [lf(o), i, lf(i)];
}
function lf(o) {
  return o.includes("start") ? o.replace("start", "end") : o.replace("end", "start");
}
const bv = ["left", "right"], yv = ["right", "left"], x2 = ["top", "bottom"], w2 = ["bottom", "top"];
function _2(o, i, n) {
  switch (o) {
    case "top":
    case "bottom":
      return n ? i ? yv : bv : i ? bv : yv;
    case "left":
    case "right":
      return i ? x2 : w2;
    default:
      return [];
  }
}
function k2(o, i, n, a) {
  const l = Wo(o);
  let c = _2(ji(o), n === "start", a);
  return l && (c = c.map((d) => d + "-" + l), i && (c = c.concat(c.map(lf)))), c;
}
function Vs(o) {
  const i = ji(o);
  return m2[i] + o.slice(i.length);
}
function S2(o) {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...o
  };
}
function ty(o) {
  return typeof o != "number" ? S2(o) : {
    top: o,
    right: o,
    bottom: o,
    left: o
  };
}
function Gs(o) {
  const {
    x: i,
    y: n,
    width: a,
    height: l
  } = o;
  return {
    width: a,
    height: l,
    top: n,
    left: i,
    right: i + a,
    bottom: n + l,
    x: i,
    y: n
  };
}
var D2 = typeof document < "u", E2 = function() {
}, Xs = D2 ? N.useLayoutEffect : E2;
const M2 = {
  ...ob
}, T2 = M2.useInsertionEffect, C2 = T2 || ((o) => o());
function N2(o) {
  const i = N.useRef(() => {
  });
  return C2(() => {
    i.current = o;
  }), N.useCallback(function() {
    for (var n = arguments.length, a = new Array(n), l = 0; l < n; l++)
      a[l] = arguments[l];
    return i.current == null ? void 0 : i.current(...a);
  }, []);
}
var ay = lb();
const O2 = /* @__PURE__ */ pf(ay);
function xv(o, i, n) {
  let {
    reference: a,
    floating: l
  } = o;
  const c = Sr(i), d = Nf(i), p = Cf(d), m = ji(i), g = c === "y", y = a.x + a.width / 2 - l.width / 2, b = a.y + a.height / 2 - l.height / 2, _ = a[p] / 2 - l[p] / 2;
  let k;
  switch (m) {
    case "top":
      k = {
        x: y,
        y: a.y - l.height
      };
      break;
    case "bottom":
      k = {
        x: y,
        y: a.y + a.height
      };
      break;
    case "right":
      k = {
        x: a.x + a.width,
        y: b
      };
      break;
    case "left":
      k = {
        x: a.x - l.width,
        y: b
      };
      break;
    default:
      k = {
        x: a.x,
        y: a.y
      };
  }
  switch (Wo(i)) {
    case "start":
      k[d] -= _ * (n && g ? -1 : 1);
      break;
    case "end":
      k[d] += _ * (n && g ? -1 : 1);
      break;
  }
  return k;
}
async function j2(o, i) {
  var n;
  i === void 0 && (i = {});
  const {
    x: a,
    y: l,
    platform: c,
    rects: d,
    elements: p,
    strategy: m
  } = o, {
    boundary: g = "clippingAncestors",
    rootBoundary: y = "viewport",
    elementContext: b = "floating",
    altBoundary: _ = !1,
    padding: k = 0
  } = cc(i, o), w = ty(k), S = p[_ ? b === "floating" ? "reference" : "floating" : b], O = Gs(await c.getClippingRect({
    element: (n = await (c.isElement == null ? void 0 : c.isElement(S))) == null || n ? S : S.contextElement || await (c.getDocumentElement == null ? void 0 : c.getDocumentElement(p.floating)),
    boundary: g,
    rootBoundary: y,
    strategy: m
  })), q = b === "floating" ? {
    x: a,
    y: l,
    width: d.floating.width,
    height: d.floating.height
  } : d.reference, L = await (c.getOffsetParent == null ? void 0 : c.getOffsetParent(p.floating)), P = await (c.isElement == null ? void 0 : c.isElement(L)) ? await (c.getScale == null ? void 0 : c.getScale(L)) || {
    x: 1,
    y: 1
  } : {
    x: 1,
    y: 1
  }, F = Gs(c.convertOffsetParentRelativeRectToViewportRelativeRect ? await c.convertOffsetParentRelativeRectToViewportRelativeRect({
    elements: p,
    rect: q,
    offsetParent: L,
    strategy: m
  }) : q);
  return {
    top: (O.top - F.top + w.top) / P.y,
    bottom: (F.bottom - O.bottom + w.bottom) / P.y,
    left: (O.left - F.left + w.left) / P.x,
    right: (F.right - O.right + w.right) / P.x
  };
}
const A2 = 50, R2 = async (o, i, n) => {
  const {
    placement: a = "bottom",
    strategy: l = "absolute",
    middleware: c = [],
    platform: d
  } = n, p = d.detectOverflow ? d : {
    ...d,
    detectOverflow: j2
  }, m = await (d.isRTL == null ? void 0 : d.isRTL(i));
  let g = await d.getElementRects({
    reference: o,
    floating: i,
    strategy: l
  }), {
    x: y,
    y: b
  } = xv(g, a, m), _ = a, k = 0;
  const w = {};
  for (let D = 0; D < c.length; D++) {
    const S = c[D];
    if (!S)
      continue;
    const {
      name: O,
      fn: q
    } = S, {
      x: L,
      y: P,
      data: F,
      reset: J
    } = await q({
      x: y,
      y: b,
      initialPlacement: a,
      placement: _,
      strategy: l,
      middlewareData: w,
      rects: g,
      platform: p,
      elements: {
        reference: o,
        floating: i
      }
    });
    y = L ?? y, b = P ?? b, w[O] = {
      ...w[O],
      ...F
    }, J && k < A2 && (k++, typeof J == "object" && (J.placement && (_ = J.placement), J.rects && (g = J.rects === !0 ? await d.getElementRects({
      reference: o,
      floating: i,
      strategy: l
    }) : J.rects), {
      x: y,
      y: b
    } = xv(g, _, m)), D = -1);
  }
  return {
    x: y,
    y: b,
    placement: _,
    strategy: l,
    middlewareData: w
  };
}, z2 = (o) => ({
  name: "arrow",
  options: o,
  async fn(i) {
    const {
      x: n,
      y: a,
      placement: l,
      rects: c,
      platform: d,
      elements: p,
      middlewareData: m
    } = i, {
      element: g,
      padding: y = 0
    } = cc(o, i) || {};
    if (g == null)
      return {};
    const b = ty(y), _ = {
      x: n,
      y: a
    }, k = Nf(l), w = Cf(k), D = await d.getDimensions(g), S = k === "y", O = S ? "top" : "left", q = S ? "bottom" : "right", L = S ? "clientHeight" : "clientWidth", P = c.reference[w] + c.reference[k] - _[k] - c.floating[w], F = _[k] - c.reference[k], J = await (d.getOffsetParent == null ? void 0 : d.getOffsetParent(g));
    let Z = J ? J[L] : 0;
    (!Z || !await (d.isElement == null ? void 0 : d.isElement(J))) && (Z = p.floating[L] || c.floating[w]);
    const ie = P / 2 - F / 2, ue = Z / 2 - D[w] / 2 - 1, de = Oi(b[O], ue), ne = Oi(b[q], ue), $ = de, ae = Z - D[w] - ne, le = Z / 2 - D[w] / 2 + ie, fe = g2($, le, ae), j = !m.arrow && Wo(l) != null && le !== fe && c.reference[w] / 2 - (le < $ ? de : ne) - D[w] / 2 < 0, Q = j ? le < $ ? le - $ : le - ae : 0;
    return {
      [k]: _[k] + Q,
      data: {
        [k]: fe,
        centerOffset: le - fe - Q,
        ...j && {
          alignmentOffset: Q
        }
      },
      reset: j
    };
  }
}), L2 = function(o) {
  return o === void 0 && (o = {}), {
    name: "flip",
    options: o,
    async fn(i) {
      var n, a;
      const {
        placement: l,
        middlewareData: c,
        rects: d,
        initialPlacement: p,
        platform: m,
        elements: g
      } = i, {
        mainAxis: y = !0,
        crossAxis: b = !0,
        fallbackPlacements: _,
        fallbackStrategy: k = "bestFit",
        fallbackAxisSideDirection: w = "none",
        flipAlignment: D = !0,
        ...S
      } = cc(o, i);
      if ((n = c.arrow) != null && n.alignmentOffset)
        return {};
      const O = ji(l), q = Sr(p), L = ji(p) === p, P = await (m.isRTL == null ? void 0 : m.isRTL(g.floating)), F = _ || (L || !D ? [Vs(p)] : y2(p)), J = w !== "none";
      !_ && J && F.push(...k2(p, D, w, P));
      const Z = [p, ...F], ie = await m.detectOverflow(i, S), ue = [];
      let de = ((a = c.flip) == null ? void 0 : a.overflows) || [];
      if (y && ue.push(ie[O]), b) {
        const le = b2(l, d, P);
        ue.push(ie[le[0]], ie[le[1]]);
      }
      if (de = [...de, {
        placement: l,
        overflows: ue
      }], !ue.every((le) => le <= 0)) {
        var ne, $;
        const le = (((ne = c.flip) == null ? void 0 : ne.index) || 0) + 1, fe = Z[le];
        if (fe && (!(b === "alignment" ? q !== Sr(fe) : !1) || // We leave the current main axis only if every placement on that axis
        // overflows the main axis.
        de.every((W) => Sr(W.placement) === q ? W.overflows[0] > 0 : !0)))
          return {
            data: {
              index: le,
              overflows: de
            },
            reset: {
              placement: fe
            }
          };
        let j = ($ = de.filter((Q) => Q.overflows[0] <= 0).sort((Q, W) => Q.overflows[1] - W.overflows[1])[0]) == null ? void 0 : $.placement;
        if (!j)
          switch (k) {
            case "bestFit": {
              var ae;
              const Q = (ae = de.filter((W) => {
                if (J) {
                  const se = Sr(W.placement);
                  return se === q || // Create a bias to the `y` side axis due to horizontal
                  // reading directions favoring greater width.
                  se === "y";
                }
                return !0;
              }).map((W) => [W.placement, W.overflows.filter((se) => se > 0).reduce((se, we) => se + we, 0)]).sort((W, se) => W[1] - se[1])[0]) == null ? void 0 : ae[0];
              Q && (j = Q);
              break;
            }
            case "initialPlacement":
              j = p;
              break;
          }
        if (l !== j)
          return {
            reset: {
              placement: j
            }
          };
      }
      return {};
    }
  };
}, Y2 = /* @__PURE__ */ new Set(["left", "top"]);
async function H2(o, i) {
  const {
    placement: n,
    platform: a,
    elements: l
  } = o, c = await (a.isRTL == null ? void 0 : a.isRTL(l.floating)), d = ji(n), p = Wo(n), m = Sr(n) === "y", g = Y2.has(d) ? -1 : 1, y = c && m ? -1 : 1, b = cc(i, o);
  let {
    mainAxis: _,
    crossAxis: k,
    alignmentAxis: w
  } = typeof b == "number" ? {
    mainAxis: b,
    crossAxis: 0,
    alignmentAxis: null
  } : {
    mainAxis: b.mainAxis || 0,
    crossAxis: b.crossAxis || 0,
    alignmentAxis: b.alignmentAxis
  };
  return p && typeof w == "number" && (k = p === "end" ? w * -1 : w), m ? {
    x: k * y,
    y: _ * g
  } : {
    x: _ * g,
    y: k * y
  };
}
const U2 = function(o) {
  return o === void 0 && (o = 0), {
    name: "offset",
    options: o,
    async fn(i) {
      var n, a;
      const {
        x: l,
        y: c,
        placement: d,
        middlewareData: p
      } = i, m = await H2(i, o);
      return d === ((n = p.offset) == null ? void 0 : n.placement) && (a = p.arrow) != null && a.alignmentOffset ? {} : {
        x: l + m.x,
        y: c + m.y,
        data: {
          ...m,
          placement: d
        }
      };
    }
  };
};
function ny(o) {
  const i = va(o);
  let n = parseFloat(i.width) || 0, a = parseFloat(i.height) || 0;
  const l = bn(o), c = l ? o.offsetWidth : n, d = l ? o.offsetHeight : a, p = Fs(n) !== c || Fs(a) !== d;
  return p && (n = c, a = d), {
    width: n,
    height: a,
    $: p
  };
}
function Of(o) {
  return Rt(o) ? o : o.contextElement;
}
function Si(o) {
  const i = Of(o);
  if (!bn(i))
    return Pa(1);
  const n = i.getBoundingClientRect(), {
    width: a,
    height: l,
    $: c
  } = ny(i);
  let d = (c ? Fs(n.width) : n.width) / a, p = (c ? Fs(n.height) : n.height) / l;
  return (!d || !Number.isFinite(d)) && (d = 1), (!p || !Number.isFinite(p)) && (p = 1), {
    x: d,
    y: p
  };
}
const B2 = /* @__PURE__ */ Pa(0);
function ry(o) {
  const i = ra(o);
  return !Tf() || !i.visualViewport ? B2 : {
    x: i.visualViewport.offsetLeft,
    y: i.visualViewport.offsetTop
  };
}
function q2(o, i, n) {
  return i === void 0 && (i = !1), !n || i && n !== ra(o) ? !1 : i;
}
function jr(o, i, n, a) {
  i === void 0 && (i = !1), n === void 0 && (n = !1);
  const l = o.getBoundingClientRect(), c = Of(o);
  let d = Pa(1);
  i && (a ? Rt(a) && (d = Si(a)) : d = Si(o));
  const p = q2(c, n, a) ? ry(c) : Pa(0);
  let m = (l.left + p.x) / d.x, g = (l.top + p.y) / d.y, y = l.width / d.x, b = l.height / d.y;
  if (c) {
    const _ = ra(c), k = a && Rt(a) ? ra(a) : a;
    let w = _, D = of(w);
    for (; D && a && k !== w; ) {
      const S = Si(D), O = D.getBoundingClientRect(), q = va(D), L = O.left + (D.clientLeft + parseFloat(q.paddingLeft)) * S.x, P = O.top + (D.clientTop + parseFloat(q.paddingTop)) * S.y;
      m *= S.x, g *= S.y, y *= S.x, b *= S.y, m += L, g += P, w = ra(D), D = of(w);
    }
  }
  return Gs({
    width: y,
    height: b,
    x: m,
    y: g
  });
}
function uc(o, i) {
  const n = sc(o).scrollLeft;
  return i ? i.left + n : jr(Fa(o)).left + n;
}
function iy(o, i) {
  const n = o.getBoundingClientRect(), a = n.left + i.scrollLeft - uc(o, n), l = n.top + i.scrollTop;
  return {
    x: a,
    y: l
  };
}
function Q2(o) {
  let {
    elements: i,
    rect: n,
    offsetParent: a,
    strategy: l
  } = o;
  const c = l === "fixed", d = Fa(a), p = i ? lc(i.floating) : !1;
  if (a === d || p && c)
    return n;
  let m = {
    scrollLeft: 0,
    scrollTop: 0
  }, g = Pa(1);
  const y = Pa(0), b = bn(a);
  if ((b || !b && !c) && ((zi(a) !== "body" || Ko(d)) && (m = sc(a)), b)) {
    const k = jr(a);
    g = Si(a), y.x = k.x + a.clientLeft, y.y = k.y + a.clientTop;
  }
  const _ = d && !b && !c ? iy(d, m) : Pa(0);
  return {
    width: n.width * g.x,
    height: n.height * g.y,
    x: n.x * g.x - m.scrollLeft * g.x + y.x + _.x,
    y: n.y * g.y - m.scrollTop * g.y + y.y + _.y
  };
}
function P2(o) {
  return Array.from(o.getClientRects());
}
function F2(o) {
  const i = Fa(o), n = sc(o), a = o.ownerDocument.body, l = Cr(i.scrollWidth, i.clientWidth, a.scrollWidth, a.clientWidth), c = Cr(i.scrollHeight, i.clientHeight, a.scrollHeight, a.clientHeight);
  let d = -n.scrollLeft + uc(o);
  const p = -n.scrollTop;
  return va(a).direction === "rtl" && (d += Cr(i.clientWidth, a.clientWidth) - l), {
    width: l,
    height: c,
    x: d,
    y: p
  };
}
const wv = 25;
function V2(o, i) {
  const n = ra(o), a = Fa(o), l = n.visualViewport;
  let c = a.clientWidth, d = a.clientHeight, p = 0, m = 0;
  if (l) {
    c = l.width, d = l.height;
    const y = Tf();
    (!y || y && i === "fixed") && (p = l.offsetLeft, m = l.offsetTop);
  }
  const g = uc(a);
  if (g <= 0) {
    const y = a.ownerDocument, b = y.body, _ = getComputedStyle(b), k = y.compatMode === "CSS1Compat" && parseFloat(_.marginLeft) + parseFloat(_.marginRight) || 0, w = Math.abs(a.clientWidth - b.clientWidth - k);
    w <= wv && (c -= w);
  } else g <= wv && (c += g);
  return {
    width: c,
    height: d,
    x: p,
    y: m
  };
}
function G2(o, i) {
  const n = jr(o, !0, i === "fixed"), a = n.top + o.clientTop, l = n.left + o.clientLeft, c = bn(o) ? Si(o) : Pa(1), d = o.clientWidth * c.x, p = o.clientHeight * c.y, m = l * c.x, g = a * c.y;
  return {
    width: d,
    height: p,
    x: m,
    y: g
  };
}
function _v(o, i, n) {
  let a;
  if (i === "viewport")
    a = V2(o, n);
  else if (i === "document")
    a = F2(Fa(o));
  else if (Rt(i))
    a = G2(i, n);
  else {
    const l = ry(o);
    a = {
      x: i.x - l.x,
      y: i.y - l.y,
      width: i.width,
      height: i.height
    };
  }
  return Gs(a);
}
function oy(o, i) {
  const n = Wn(o);
  return n === i || !Rt(n) || Ni(n) ? !1 : va(n).position === "fixed" || oy(n, i);
}
function X2(o, i) {
  const n = i.get(o);
  if (n)
    return n;
  let a = Qo(o, [], !1).filter((p) => Rt(p) && zi(p) !== "body"), l = null;
  const c = va(o).position === "fixed";
  let d = c ? Wn(o) : o;
  for (; Rt(d) && !Ni(d); ) {
    const p = va(d), m = Mf(d);
    !m && p.position === "fixed" && (l = null), (c ? !m && !l : !m && p.position === "static" && !!l && (l.position === "absolute" || l.position === "fixed") || Ko(d) && !m && oy(o, d)) ? a = a.filter((y) => y !== d) : l = p, d = Wn(d);
  }
  return i.set(o, a), a;
}
function Z2(o) {
  let {
    element: i,
    boundary: n,
    rootBoundary: a,
    strategy: l
  } = o;
  const d = [...n === "clippingAncestors" ? lc(i) ? [] : X2(i, this._c) : [].concat(n), a], p = _v(i, d[0], l);
  let m = p.top, g = p.right, y = p.bottom, b = p.left;
  for (let _ = 1; _ < d.length; _++) {
    const k = _v(i, d[_], l);
    m = Cr(k.top, m), g = Oi(k.right, g), y = Oi(k.bottom, y), b = Cr(k.left, b);
  }
  return {
    width: g - b,
    height: y - m,
    x: b,
    y: m
  };
}
function K2(o) {
  const {
    width: i,
    height: n
  } = ny(o);
  return {
    width: i,
    height: n
  };
}
function W2(o, i, n) {
  const a = bn(i), l = Fa(i), c = n === "fixed", d = jr(o, !0, c, i);
  let p = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const m = Pa(0);
  function g() {
    m.x = uc(l);
  }
  if (a || !a && !c)
    if ((zi(i) !== "body" || Ko(l)) && (p = sc(i)), a) {
      const k = jr(i, !0, c, i);
      m.x = k.x + i.clientLeft, m.y = k.y + i.clientTop;
    } else l && g();
  c && !a && l && g();
  const y = l && !a && !c ? iy(l, p) : Pa(0), b = d.left + p.scrollLeft - m.x - y.x, _ = d.top + p.scrollTop - m.y - y.y;
  return {
    x: b,
    y: _,
    width: d.width,
    height: d.height
  };
}
function Hd(o) {
  return va(o).position === "static";
}
function kv(o, i) {
  if (!bn(o) || va(o).position === "fixed")
    return null;
  if (i)
    return i(o);
  let n = o.offsetParent;
  return Fa(o) === n && (n = n.ownerDocument.body), n;
}
function ly(o, i) {
  const n = ra(o);
  if (lc(o))
    return n;
  if (!bn(o)) {
    let l = Wn(o);
    for (; l && !Ni(l); ) {
      if (Rt(l) && !Hd(l))
        return l;
      l = Wn(l);
    }
    return n;
  }
  let a = kv(o, i);
  for (; a && d2(a) && Hd(a); )
    a = kv(a, i);
  return a && Ni(a) && Hd(a) && !Mf(a) ? n : a || h2(o) || n;
}
const I2 = async function(o) {
  const i = this.getOffsetParent || ly, n = this.getDimensions, a = await n(o.floating);
  return {
    reference: W2(o.reference, await i(o.floating), o.strategy),
    floating: {
      x: 0,
      y: 0,
      width: a.width,
      height: a.height
    }
  };
};
function J2(o) {
  return va(o).direction === "rtl";
}
const $2 = {
  convertOffsetParentRelativeRectToViewportRelativeRect: Q2,
  getDocumentElement: Fa,
  getClippingRect: Z2,
  getOffsetParent: ly,
  getElementRects: I2,
  getClientRects: P2,
  getDimensions: K2,
  getScale: Si,
  isElement: Rt,
  isRTL: J2
};
function sy(o, i) {
  return o.x === i.x && o.y === i.y && o.width === i.width && o.height === i.height;
}
function eS(o, i) {
  let n = null, a;
  const l = Fa(o);
  function c() {
    var p;
    clearTimeout(a), (p = n) == null || p.disconnect(), n = null;
  }
  function d(p, m) {
    p === void 0 && (p = !1), m === void 0 && (m = 1), c();
    const g = o.getBoundingClientRect(), {
      left: y,
      top: b,
      width: _,
      height: k
    } = g;
    if (p || i(), !_ || !k)
      return;
    const w = bs(b), D = bs(l.clientWidth - (y + _)), S = bs(l.clientHeight - (b + k)), O = bs(y), L = {
      rootMargin: -w + "px " + -D + "px " + -S + "px " + -O + "px",
      threshold: Cr(0, Oi(1, m)) || 1
    };
    let P = !0;
    function F(J) {
      const Z = J[0].intersectionRatio;
      if (Z !== m) {
        if (!P)
          return d();
        Z ? d(!1, Z) : a = setTimeout(() => {
          d(!1, 1e-7);
        }, 1e3);
      }
      Z === 1 && !sy(g, o.getBoundingClientRect()) && d(), P = !1;
    }
    try {
      n = new IntersectionObserver(F, {
        ...L,
        // Handle <iframe>s
        root: l.ownerDocument
      });
    } catch {
      n = new IntersectionObserver(F, L);
    }
    n.observe(o);
  }
  return d(!0), c;
}
function tS(o, i, n, a) {
  a === void 0 && (a = {});
  const {
    ancestorScroll: l = !0,
    ancestorResize: c = !0,
    elementResize: d = typeof ResizeObserver == "function",
    layoutShift: p = typeof IntersectionObserver == "function",
    animationFrame: m = !1
  } = a, g = Of(o), y = l || c ? [...g ? Qo(g) : [], ...i ? Qo(i) : []] : [];
  y.forEach((O) => {
    l && O.addEventListener("scroll", n, {
      passive: !0
    }), c && O.addEventListener("resize", n);
  });
  const b = g && p ? eS(g, n) : null;
  let _ = -1, k = null;
  d && (k = new ResizeObserver((O) => {
    let [q] = O;
    q && q.target === g && k && i && (k.unobserve(i), cancelAnimationFrame(_), _ = requestAnimationFrame(() => {
      var L;
      (L = k) == null || L.observe(i);
    })), n();
  }), g && !m && k.observe(g), i && k.observe(i));
  let w, D = m ? jr(o) : null;
  m && S();
  function S() {
    const O = jr(o);
    D && !sy(D, O) && n(), D = O, w = requestAnimationFrame(S);
  }
  return n(), () => {
    var O;
    y.forEach((q) => {
      l && q.removeEventListener("scroll", n), c && q.removeEventListener("resize", n);
    }), b?.(), (O = k) == null || O.disconnect(), k = null, m && cancelAnimationFrame(w);
  };
}
const aS = U2, nS = L2, Sv = z2, rS = (o, i, n) => {
  const a = /* @__PURE__ */ new Map(), l = {
    platform: $2,
    ...n
  }, c = {
    ...l.platform,
    _c: a
  };
  return R2(o, i, {
    ...l,
    platform: c
  });
};
var iS = typeof document < "u", oS = function() {
}, Rs = iS ? N.useLayoutEffect : oS;
function Zs(o, i) {
  if (o === i)
    return !0;
  if (typeof o != typeof i)
    return !1;
  if (typeof o == "function" && o.toString() === i.toString())
    return !0;
  let n, a, l;
  if (o && i && typeof o == "object") {
    if (Array.isArray(o)) {
      if (n = o.length, n !== i.length) return !1;
      for (a = n; a-- !== 0; )
        if (!Zs(o[a], i[a]))
          return !1;
      return !0;
    }
    if (l = Object.keys(o), n = l.length, n !== Object.keys(i).length)
      return !1;
    for (a = n; a-- !== 0; )
      if (!{}.hasOwnProperty.call(i, l[a]))
        return !1;
    for (a = n; a-- !== 0; ) {
      const c = l[a];
      if (!(c === "_owner" && o.$$typeof) && !Zs(o[c], i[c]))
        return !1;
    }
    return !0;
  }
  return o !== o && i !== i;
}
function cy(o) {
  return typeof window > "u" ? 1 : (o.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function Dv(o, i) {
  const n = cy(o);
  return Math.round(i * n) / n;
}
function Ud(o) {
  const i = N.useRef(o);
  return Rs(() => {
    i.current = o;
  }), i;
}
function lS(o) {
  o === void 0 && (o = {});
  const {
    placement: i = "bottom",
    strategy: n = "absolute",
    middleware: a = [],
    platform: l,
    elements: {
      reference: c,
      floating: d
    } = {},
    transform: p = !0,
    whileElementsMounted: m,
    open: g
  } = o, [y, b] = N.useState({
    x: 0,
    y: 0,
    strategy: n,
    placement: i,
    middlewareData: {},
    isPositioned: !1
  }), [_, k] = N.useState(a);
  Zs(_, a) || k(a);
  const [w, D] = N.useState(null), [S, O] = N.useState(null), q = N.useCallback((W) => {
    W !== J.current && (J.current = W, D(W));
  }, []), L = N.useCallback((W) => {
    W !== Z.current && (Z.current = W, O(W));
  }, []), P = c || w, F = d || S, J = N.useRef(null), Z = N.useRef(null), ie = N.useRef(y), ue = m != null, de = Ud(m), ne = Ud(l), $ = Ud(g), ae = N.useCallback(() => {
    if (!J.current || !Z.current)
      return;
    const W = {
      placement: i,
      strategy: n,
      middleware: _
    };
    ne.current && (W.platform = ne.current), rS(J.current, Z.current, W).then((se) => {
      const we = {
        ...se,
        // The floating element's position may be recomputed while it's closed
        // but still mounted (such as when transitioning out). To ensure
        // `isPositioned` will be `false` initially on the next open, avoid
        // setting it to `true` when `open === false` (must be specified).
        isPositioned: $.current !== !1
      };
      le.current && !Zs(ie.current, we) && (ie.current = we, ay.flushSync(() => {
        b(we);
      }));
    });
  }, [_, i, n, ne, $]);
  Rs(() => {
    g === !1 && ie.current.isPositioned && (ie.current.isPositioned = !1, b((W) => ({
      ...W,
      isPositioned: !1
    })));
  }, [g]);
  const le = N.useRef(!1);
  Rs(() => (le.current = !0, () => {
    le.current = !1;
  }), []), Rs(() => {
    if (P && (J.current = P), F && (Z.current = F), P && F) {
      if (de.current)
        return de.current(P, F, ae);
      ae();
    }
  }, [P, F, ae, de, ue]);
  const fe = N.useMemo(() => ({
    reference: J,
    floating: Z,
    setReference: q,
    setFloating: L
  }), [q, L]), j = N.useMemo(() => ({
    reference: P,
    floating: F
  }), [P, F]), Q = N.useMemo(() => {
    const W = {
      position: n,
      left: 0,
      top: 0
    };
    if (!j.floating)
      return W;
    const se = Dv(j.floating, y.x), we = Dv(j.floating, y.y);
    return p ? {
      ...W,
      transform: "translate(" + se + "px, " + we + "px)",
      ...cy(j.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: n,
      left: se,
      top: we
    };
  }, [n, p, j.floating, y.x, y.y]);
  return N.useMemo(() => ({
    ...y,
    update: ae,
    refs: fe,
    elements: j,
    floatingStyles: Q
  }), [y, ae, fe, j, Q]);
}
const sS = (o) => {
  function i(n) {
    return {}.hasOwnProperty.call(n, "current");
  }
  return {
    name: "arrow",
    options: o,
    fn(n) {
      const {
        element: a,
        padding: l
      } = typeof o == "function" ? o(n) : o;
      return a && i(a) ? a.current != null ? Sv({
        element: a.current,
        padding: l
      }).fn(n) : {} : a ? Sv({
        element: a,
        padding: l
      }).fn(n) : {};
    }
  };
}, cS = (o, i) => {
  const n = aS(o);
  return {
    name: n.name,
    fn: n.fn,
    options: [o, i]
  };
}, uS = (o, i) => {
  const n = nS(o);
  return {
    name: n.name,
    fn: n.fn,
    options: [o, i]
  };
}, dS = (o, i) => {
  const n = sS(o);
  return {
    name: n.name,
    fn: n.fn,
    options: [o, i]
  };
}, fS = {
  ...ob
};
let Ev = !1, pS = 0;
const Mv = () => (
  // Ensure the id is unique with multiple independent versions of Floating UI
  // on <React 18
  "floating-ui-" + Math.random().toString(36).slice(2, 6) + pS++
);
function hS() {
  const [o, i] = N.useState(() => Ev ? Mv() : void 0);
  return Xs(() => {
    o == null && i(Mv());
  }, []), N.useEffect(() => {
    Ev = !0;
  }, []), o;
}
const mS = fS.useId, uy = mS || hS, gS = /* @__PURE__ */ N.forwardRef(function(i, n) {
  const {
    context: {
      placement: a,
      elements: {
        floating: l
      },
      middlewareData: {
        arrow: c,
        shift: d
      }
    },
    width: p = 14,
    height: m = 7,
    tipRadius: g = 0,
    strokeWidth: y = 0,
    staticOffset: b,
    stroke: _,
    d: k,
    style: {
      transform: w,
      ...D
    } = {},
    ...S
  } = i, O = uy(), [q, L] = N.useState(!1);
  if (Xs(() => {
    if (!l) return;
    va(l).direction === "rtl" && L(!0);
  }, [l]), !l)
    return null;
  const [P, F] = a.split("-"), J = P === "top" || P === "bottom";
  let Z = b;
  (J && d != null && d.x || !J && d != null && d.y) && (Z = null);
  const ie = y * 2, ue = ie / 2, de = p / 2 * (g / -8 + 1), ne = m / 2 * g / 4, $ = !!k, ae = Z && F === "end" ? "bottom" : "top";
  let le = Z && F === "end" ? "right" : "left";
  Z && q && (le = F === "end" ? "left" : "right");
  const fe = c?.x != null ? Z || c.x : "", j = c?.y != null ? Z || c.y : "", Q = k || "M0,0" + (" H" + p) + (" L" + (p - de) + "," + (m - ne)) + (" Q" + p / 2 + "," + m + " " + de + "," + (m - ne)) + " Z", W = {
    top: $ ? "rotate(180deg)" : "",
    left: $ ? "rotate(90deg)" : "rotate(-90deg)",
    bottom: $ ? "" : "rotate(180deg)",
    right: $ ? "rotate(-90deg)" : "rotate(90deg)"
  }[P];
  return /* @__PURE__ */ h.jsxs("svg", {
    ...S,
    "aria-hidden": !0,
    ref: n,
    width: $ ? p : p + ie,
    height: p,
    viewBox: "0 0 " + p + " " + (m > p ? m : p),
    style: {
      position: "absolute",
      pointerEvents: "none",
      [le]: fe,
      [ae]: j,
      [P]: J || $ ? "100%" : "calc(100% - " + ie / 2 + "px)",
      transform: [W, w].filter((se) => !!se).join(" "),
      ...D
    },
    children: [ie > 0 && /* @__PURE__ */ h.jsx("path", {
      clipPath: "url(#" + O + ")",
      fill: "none",
      stroke: _,
      strokeWidth: ie + (k ? 0 : 1),
      d: Q
    }), /* @__PURE__ */ h.jsx("path", {
      stroke: ie && !k ? S.fill : "none",
      d: Q
    }), /* @__PURE__ */ h.jsx("clipPath", {
      id: O,
      children: /* @__PURE__ */ h.jsx("rect", {
        x: -ue,
        y: ue * ($ ? -1 : 1),
        width: p + ie,
        height: p
      })
    })]
  });
});
function vS() {
  const o = /* @__PURE__ */ new Map();
  return {
    emit(i, n) {
      var a;
      (a = o.get(i)) == null || a.forEach((l) => l(n));
    },
    on(i, n) {
      o.has(i) || o.set(i, /* @__PURE__ */ new Set()), o.get(i).add(n);
    },
    off(i, n) {
      var a;
      (a = o.get(i)) == null || a.delete(n);
    }
  };
}
const bS = /* @__PURE__ */ N.createContext(null), yS = /* @__PURE__ */ N.createContext(null), xS = () => {
  var o;
  return ((o = N.useContext(bS)) == null ? void 0 : o.id) || null;
}, wS = () => N.useContext(yS);
function _S(o) {
  const {
    open: i = !1,
    onOpenChange: n,
    elements: a
  } = o, l = uy(), c = N.useRef({}), [d] = N.useState(() => vS()), p = xS() != null, [m, g] = N.useState(a.reference), y = N2((k, w, D) => {
    c.current.openEvent = k ? w : void 0, d.emit("openchange", {
      open: k,
      event: w,
      reason: D,
      nested: p
    }), n?.(k, w, D);
  }), b = N.useMemo(() => ({
    setPositionReference: g
  }), []), _ = N.useMemo(() => ({
    reference: m || a.reference || null,
    floating: a.floating || null,
    domReference: a.reference
  }), [m, a.reference, a.floating]);
  return N.useMemo(() => ({
    dataRef: c,
    open: i,
    onOpenChange: y,
    elements: _,
    events: d,
    floatingId: l,
    refs: b
  }), [i, y, _, d, l, b]);
}
function kS(o) {
  o === void 0 && (o = {});
  const {
    nodeId: i
  } = o, n = _S({
    ...o,
    elements: {
      reference: null,
      floating: null,
      ...o.elements
    }
  }), a = o.rootContext || n, l = a.elements, [c, d] = N.useState(null), [p, m] = N.useState(null), y = l?.domReference || c, b = N.useRef(null), _ = wS();
  Xs(() => {
    y && (b.current = y);
  }, [y]);
  const k = lS({
    ...o,
    elements: {
      ...l,
      ...p && {
        reference: p
      }
    }
  }), w = N.useCallback((L) => {
    const P = Rt(L) ? {
      getBoundingClientRect: () => L.getBoundingClientRect(),
      getClientRects: () => L.getClientRects(),
      contextElement: L
    } : L;
    m(P), k.refs.setReference(P);
  }, [k.refs]), D = N.useCallback((L) => {
    (Rt(L) || L === null) && (b.current = L, d(L)), (Rt(k.refs.reference.current) || k.refs.reference.current === null || // Don't allow setting virtual elements using the old technique back to
    // `null` to support `positionReference` + an unstable `reference`
    // callback ref.
    L !== null && !Rt(L)) && k.refs.setReference(L);
  }, [k.refs]), S = N.useMemo(() => ({
    ...k.refs,
    setReference: D,
    setPositionReference: w,
    domReference: b
  }), [k.refs, D, w]), O = N.useMemo(() => ({
    ...k.elements,
    domReference: y
  }), [k.elements, y]), q = N.useMemo(() => ({
    ...k,
    ...a,
    refs: S,
    elements: O,
    nodeId: i
  }), [k, S, O, i, a]);
  return Xs(() => {
    a.dataRef.current.floatingContext = q;
    const L = _?.nodesRef.current.find((P) => P.id === i);
    L && (L.context = q);
  }), N.useMemo(() => ({
    ...k,
    context: q,
    refs: S,
    elements: O
  }), [k, S, O, q]);
}
var sf = function(i, n) {
  return sf = Object.setPrototypeOf || {
    __proto__: []
  } instanceof Array && function(a, l) {
    a.__proto__ = l;
  } || function(a, l) {
    for (var c in l) Object.prototype.hasOwnProperty.call(l, c) && (a[c] = l[c]);
  }, sf(i, n);
};
function Dt(o, i) {
  if (typeof i != "function" && i !== null) throw new TypeError("Class extends value " + String(i) + " is not a constructor or null");
  sf(o, i);
  function n() {
    this.constructor = o;
  }
  o.prototype = i === null ? Object.create(i) : (n.prototype = i.prototype, new n());
}
var Me = function() {
  return Me = Object.assign || function(n) {
    for (var a, l = 1, c = arguments.length; l < c; l++) {
      a = arguments[l];
      for (var d in a) Object.prototype.hasOwnProperty.call(a, d) && (n[d] = a[d]);
    }
    return n;
  }, Me.apply(this, arguments);
};
function qa(o, i, n) {
  if (n || arguments.length === 2) for (var a = 0, l = i.length, c; a < l; a++)
    (c || !(a in i)) && (c || (c = Array.prototype.slice.call(i, 0, a)), c[a] = i[a]);
  return o.concat(c || Array.prototype.slice.call(i));
}
var SS = function(o) {
  var i = o.showTimeSelectOnly, n = i === void 0 ? !1 : i, a = o.showTime, l = a === void 0 ? !1 : a, c = o.className, d = o.children, p = o.inline, m = n ? "Choose Time" : "Choose Date".concat(l ? " and Time" : "");
  return B.createElement("div", { className: c, "aria-label": m, role: p ? void 0 : "dialog", "aria-modal": p ? void 0 : "true", translate: "no" }, d);
}, DS = function(o, i) {
  var n = N.useRef(null), a = N.useRef(o);
  N.useEffect(function() {
    a.current = o;
  }, [o]);
  var l = N.useCallback(function(c) {
    var d, p = c.composed && c.composedPath && c.composedPath().find(function(m) {
      return m instanceof Node;
    }) || c.target;
    n.current && !n.current.contains(p) && (i && p instanceof HTMLElement && p.classList.contains(i) || (d = a.current) === null || d === void 0 || d.call(a, c));
  }, [i]);
  return N.useEffect(function() {
    return document.addEventListener("mousedown", l), function() {
      document.removeEventListener("mousedown", l);
    };
  }, [l]), n;
}, dc = function(o) {
  var i = o.children, n = o.onClickOutside, a = o.className, l = o.containerRef, c = o.style, d = o.ignoreClass, p = DS(n, d);
  return B.createElement("div", { className: a, style: c, ref: function(m) {
    p.current = m, l && (l.current = m);
  } }, i);
}, ys = null, Tv = !1;
function dy() {
  if (Tv)
    return ys;
  Tv = !0;
  try {
    var o = "date-fns-tz";
    ys = require(o);
  } catch {
    ys = null;
  }
  return ys;
}
function Cv(o, i) {
  if (!i)
    return o;
  var n = dy();
  return n ? n.toZonedTime(o, i) : o;
}
function un(o, i) {
  if (!i)
    return o;
  var n = dy();
  return n ? n.fromZonedTime(o, i) : o;
}
var te;
(function(o) {
  o.ArrowUp = "ArrowUp", o.ArrowDown = "ArrowDown", o.ArrowLeft = "ArrowLeft", o.ArrowRight = "ArrowRight", o.PageUp = "PageUp", o.PageDown = "PageDown", o.Home = "Home", o.End = "End", o.Enter = "Enter", o.Space = " ", o.Tab = "Tab", o.Escape = "Escape", o.Backspace = "Backspace", o.X = "x";
})(te || (te = {}));
function fy() {
  var o = typeof window < "u" ? window : globalThis;
  return o;
}
var Io = 12;
function Le(o) {
  if (o == null)
    return /* @__PURE__ */ new Date();
  var i = typeof o == "string" ? Kk(o) : me(o);
  return Pt(i) ? i : /* @__PURE__ */ new Date();
}
function yr(o, i, n, a, l) {
  l === void 0 && (l = Le());
  for (var c = Ai(n) || Ai(jf()), d = Array.isArray(i) ? i : [i], p = 0, m = d; p < m.length; p++) {
    var g = m[p], y = Pk(o, g, l, {
      locale: c
    });
    if (Pt(y) && (!a || o === $e(y, g, n)))
      return y;
  }
  if (!a && o && o.length >= 8) {
    var b = new Date(o);
    if (Ci(b))
      return b;
  }
  return null;
}
function ES(o, i) {
  if (i === void 0 && (i = Le()), !o)
    return null;
  var n = o.match(/\b(1\d{3}|2\d{3})\b/);
  if (!n || !n[1])
    return null;
  var a = parseInt(n[1], 10), l = o.match(/(?:^|[/\-\s])?(0?[1-9]|1[0-2])(?:[/\-\s]|$)/), c = l && l[1] ? parseInt(l[1], 10) - 1 : i.getMonth();
  return new Date(a, c, 1);
}
function Pt(o) {
  return Ci(o);
}
function Dr(o) {
  return o == null ? null : Qa(o) && Ci(o) ? o : null;
}
function $e(o, i, n) {
  if (n === "en")
    return hv(o, i, {
      useAdditionalWeekYearTokens: !0,
      useAdditionalDayOfYearTokens: !0
    });
  var a = n ? Ai(n) : void 0;
  return n && !a && console.warn('A locale object was not found for the provided string ["'.concat(n, '"].')), a = a || Ai(jf()), hv(o, i, {
    locale: a,
    useAdditionalWeekYearTokens: !0,
    useAdditionalDayOfYearTokens: !0
  });
}
function Qt(o, i) {
  var n = i.dateFormat, a = i.locale, l = Array.isArray(n) && n.length > 0 ? n[0] : n;
  return o && $e(o, l, a) || "";
}
var py = " - ";
function MS(o, i, n) {
  if (!o && !i)
    return "";
  var a = o ? Qt(o, n) : "", l = i ? Qt(i, n) : "", c = n.rangeSeparator || py;
  return "".concat(a).concat(c).concat(l);
}
function TS(o, i) {
  if (!o?.length)
    return "";
  var n = o[0] ? Qt(o[0], i) : "";
  if (o.length === 1)
    return n;
  if (o.length === 2 && o[1]) {
    var a = Qt(o[1], i);
    return "".concat(n, ", ").concat(a);
  }
  var l = o.length - 1;
  return "".concat(n, " (+").concat(l, ")");
}
function dn(o, i) {
  var n = i.hour, a = n === void 0 ? 0 : n, l = i.minute, c = l === void 0 ? 0 : l, d = i.second, p = d === void 0 ? 0 : d;
  return Os(js(As(o, p), c), a);
}
function CS(o) {
  return kf(o);
}
function NS(o, i) {
  return $e(o, "ddd", i);
}
function Ho(o) {
  return Or(o);
}
function Zn(o, i, n) {
  var a = Ai(i || jf());
  return gn(o, {
    locale: a,
    weekStartsOn: n
  });
}
function hn(o) {
  return Qb(o);
}
function Uo(o) {
  return ic(o);
}
function Nv(o) {
  return af(o);
}
function Ov() {
  return Or(Le());
}
function jv(o) {
  return Bb(o);
}
function OS(o) {
  return Kw(o);
}
function jS(o) {
  return qb(o);
}
function Ya(o, i) {
  return o && i ? Xk(o, i) : !o && !i;
}
function At(o, i) {
  return o && i ? Vk(o, i) : !o && !i;
}
function Ks(o, i) {
  return o && i ? Gk(o, i) : !o && !i;
}
function Ae(o, i) {
  return o && i ? Xw(o, i) : !o && !i;
}
function Er(o, i) {
  return o && i ? Z_(o, i) : !o && !i;
}
function _r(o, i, n) {
  var a, l = Or(i), c = Bb(n);
  try {
    a = qo(o, { start: l, end: c });
  } catch {
    a = !1;
  }
  return a;
}
function jf() {
  var o = fy();
  return o.__localeId__;
}
function Ai(o) {
  if (typeof o == "string") {
    var i = fy();
    return i.__localeData__ ? i.__localeData__[o] : void 0;
  } else
    return o;
}
function AS(o, i, n) {
  return i($e(o, "EEEE", n));
}
function RS(o, i) {
  return $e(o, "EEEEEE", i);
}
function zS(o, i) {
  return $e(o, "EEE", i);
}
function Af(o, i) {
  return $e(na(Le(), o), "LLLL", i);
}
function hy(o, i) {
  return $e(na(Le(), o), "LLL", i);
}
function LS(o, i) {
  return $e(_i(Le(), o), "QQQ", i);
}
function ga(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.maxDate, c = n.excludeDates, d = n.excludeDateIntervals, p = n.includeDates, m = n.includeDateIntervals, g = n.filterDate, y = n.disabled;
  return y ? !0 : Jo(o, { minDate: a, maxDate: l }) || c && c.some(function(b) {
    return b instanceof Date ? Ae(o, b) : Ae(o, b.date);
  }) || d && d.some(function(b) {
    var _ = b.start, k = b.end;
    return qo(o, { start: _, end: k });
  }) || p && !p.some(function(b) {
    return Ae(o, b);
  }) || m && !m.some(function(b) {
    var _ = b.start, k = b.end;
    return qo(o, { start: _, end: k });
  }) || g && !g(Le(o)) || !1;
}
function Rf(o, i) {
  var n = i === void 0 ? {} : i, a = n.excludeDates, l = n.excludeDateIntervals;
  return l && l.length > 0 ? l.some(function(c) {
    var d = c.start, p = c.end;
    return qo(o, { start: d, end: p });
  }) : a && a.some(function(c) {
    var d;
    return c instanceof Date ? Ae(o, c) : Ae(o, (d = c.date) !== null && d !== void 0 ? d : /* @__PURE__ */ new Date());
  }) || !1;
}
function my(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.maxDate, c = n.excludeDates, d = n.includeDates, p = n.filterDate;
  return Jo(o, {
    minDate: a ? Qb(a) : void 0,
    maxDate: l ? qb(l) : void 0
  }) || c?.some(function(m) {
    return At(o, m instanceof Date ? m : m.date);
  }) || d && !d.some(function(m) {
    return At(o, m);
  }) || p && !p(Le(o)) || !1;
}
function xs(o, i, n, a) {
  var l = Ne(o), c = Ft(o), d = Ne(i), p = Ft(i), m = Ne(a);
  return l === d && l === m ? c <= n && n <= p : l < d ? m === l && c <= n || m === d && p >= n || m < d && m > l : !1;
}
function YS(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.maxDate, c = n.excludeDates, d = n.includeDates;
  return Jo(o, { minDate: a, maxDate: l }) || c && c.some(function(p) {
    return At(p instanceof Date ? p : p.date, o);
  }) || d && !d.some(function(p) {
    return At(p, o);
  }) || !1;
}
function ws(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.maxDate, c = n.excludeDates, d = n.includeDates, p = n.filterDate, m = n.disabled;
  return m ? !0 : Jo(o, { minDate: a, maxDate: l }) || c?.some(function(g) {
    return Ks(o, g instanceof Date ? g : g.date);
  }) || d && !d.some(function(g) {
    return Ks(o, g);
  }) || p && !p(Le(o)) || !1;
}
function _s(o, i, n) {
  if (!i || !n || !Ci(i) || !Ci(n))
    return !1;
  var a = Ne(i), l = Ne(n);
  return a <= o && l >= o;
}
function zs(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.maxDate, c = n.excludeDates, d = n.includeDates, p = n.filterDate, m = n.disabled;
  if (m)
    return !0;
  var g = new Date(o, 0, 1);
  return Jo(g, {
    minDate: a ? ic(a) : void 0,
    maxDate: l ? Pb(l) : void 0
  }) || c?.some(function(y) {
    return Ya(g, y instanceof Date ? y : y.date);
  }) || d && !d.some(function(y) {
    return Ya(g, y);
  }) || p && !p(Le(g)) || !1;
}
function ks(o, i, n, a) {
  var l = Ne(o), c = Gn(o), d = Ne(i), p = Gn(i), m = Ne(a);
  return l === d && l === m ? c <= n && n <= p : l < d ? m === l && c <= n || m === d && p >= n || m < d && m > l : !1;
}
function Jo(o, i) {
  var n, a = i === void 0 ? {} : i, l = a.minDate, c = a.maxDate;
  return (n = l && Ti(o, l) < 0 || c && Ti(o, c) > 0) !== null && n !== void 0 ? n : !1;
}
function Av(o, i) {
  return i.some(function(n) {
    return Tt(n) === Tt(o) && Ct(n) === Ct(o) && Xn(n) === Xn(o);
  });
}
function Rv(o, i) {
  var n = i === void 0 ? {} : i, a = n.excludeTimes, l = n.includeTimes, c = n.filterTime;
  return a && Av(o, a) || l && !Av(o, l) || c && !c(o) || !1;
}
function zv(o, i) {
  var n = i.minTime, a = i.maxTime;
  if (!n || !a)
    throw new Error("Both minTime and maxTime props required");
  var l = Le();
  l = Os(l, Tt(o)), l = js(l, Ct(o)), l = As(l, Xn(o));
  var c = Le();
  c = Os(c, Tt(n)), c = js(c, Ct(n)), c = As(c, Xn(n));
  var d = Le();
  d = Os(d, Tt(a)), d = js(d, Ct(a)), d = As(d, Xn(a));
  var p;
  try {
    p = !qo(l, { start: c, end: d });
  } catch {
    p = !1;
  }
  return p;
}
function Lv(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.includeDates, c = Tr(o, 1);
  return a && Bs(a, c) > 0 || l && l.every(function(d) {
    return Bs(d, c) > 0;
  }) || !1;
}
function Yv(o, i) {
  var n = i === void 0 ? {} : i, a = n.maxDate, l = n.includeDates, c = Ea(o, 1);
  return a && Bs(c, a) > 0 || l && l.every(function(d) {
    return Bs(c, d) > 0;
  }) || !1;
}
function HS(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.includeDates, c = ic(o), d = Jb(c);
  return a && qs(a, d) > 0 || l && l.every(function(p) {
    return qs(p, d) > 0;
  }) || !1;
}
function US(o, i) {
  var n = i === void 0 ? {} : i, a = n.maxDate, l = n.includeDates, c = Pb(o), d = _f(c, 1);
  return a && qs(d, a) > 0 || l && l.every(function(p) {
    return qs(d, p) > 0;
  }) || !1;
}
function Hv(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.includeDates, c = Kn(o, 1);
  return a && Qs(a, c) > 0 || l && l.every(function(d) {
    return Qs(d, c) > 0;
  }) || !1;
}
function BS(o, i) {
  var n = i === void 0 ? {} : i, a = n.minDate, l = n.yearItemNumber, c = l === void 0 ? Io : l, d = Uo(Kn(o, c)), p = fn(d, c).endPeriod, m = a && Ne(a);
  return m && m > p || !1;
}
function Uv(o, i) {
  var n = i === void 0 ? {} : i, a = n.maxDate, l = n.includeDates, c = Da(o, 1);
  return a && Qs(c, a) > 0 || l && l.every(function(d) {
    return Qs(c, d) > 0;
  }) || !1;
}
function qS(o, i) {
  var n = i === void 0 ? {} : i, a = n.maxDate, l = n.yearItemNumber, c = l === void 0 ? Io : l, d = Da(o, c), p = fn(d, c).startPeriod, m = a && Ne(a);
  return m && m < p || !1;
}
function gy(o) {
  var i = o.minDate, n = o.includeDates;
  if (n && i) {
    var a = n.filter(function(l) {
      return Ti(l, i) >= 0;
    });
    return sv(a);
  } else return n ? sv(n) : i;
}
function vy(o) {
  var i = o.maxDate, n = o.includeDates;
  if (n && i) {
    var a = n.filter(function(l) {
      return Ti(l, i) <= 0;
    });
    return lv(a);
  } else return n ? lv(n) : i;
}
function Bv(o, i) {
  var n;
  o === void 0 && (o = []), i === void 0 && (i = "react-datepicker__day--highlighted");
  for (var a = /* @__PURE__ */ new Map(), l = 0, c = o.length; l < c; l++) {
    var d = o[l];
    if (Qa(d)) {
      var p = $e(d, "MM.dd.yyyy"), m = a.get(p) || [];
      m.includes(i) || (m.push(i), a.set(p, m));
    } else if (typeof d == "object") {
      var g = Object.keys(d), y = (n = g[0]) !== null && n !== void 0 ? n : "", b = d[y];
      if (typeof y == "string" && Array.isArray(b))
        for (var _ = 0, k = b.length; _ < k; _++) {
          var w = b[_];
          if (w) {
            var p = $e(w, "MM.dd.yyyy"), m = a.get(p) || [];
            m.includes(y) || (m.push(y), a.set(p, m));
          }
        }
    }
  }
  return a;
}
function QS(o, i) {
  return o.length !== i.length ? !1 : o.every(function(n, a) {
    return n === i[a];
  });
}
function PS(o, i) {
  o === void 0 && (o = []), i === void 0 && (i = "react-datepicker__day--holidays");
  var n = /* @__PURE__ */ new Map();
  return o.forEach(function(a) {
    var l = a.date, c = a.holidayName;
    if (Qa(l)) {
      var d = $e(l, "MM.dd.yyyy"), p = n.get(d) || {
        className: "",
        holidayNames: []
      };
      if (!("className" in p && p.className === i && QS(p.holidayNames, [c]))) {
        p.className = i;
        var m = p.holidayNames;
        p.holidayNames = m ? qa(qa([], m, !0), [c], !1) : [c], n.set(d, p);
      }
    }
  }), n;
}
function FS(o, i, n, a, l) {
  for (var c = l.length, d = [], p = 0; p < c; p++) {
    var m = o, g = l[p];
    g && (m = Pw(m, Tt(g)), m = Bo(m, Ct(g)), m = Gw(m, Xn(g)));
    var y = Bo(o, (n + 1) * a);
    pn(m, i) && Ba(m, y) && g != null && d.push(g);
  }
  return d;
}
function wi(o) {
  return o < 10 ? "0".concat(o) : "".concat(o);
}
function fn(o, i) {
  i === void 0 && (i = Io);
  var n = Math.ceil(Ne(o) / i) * i, a = n - (i - 1);
  return { startPeriod: a, endPeriod: n };
}
function VS(o) {
  var i = new Date(o.getFullYear(), o.getMonth(), o.getDate()), n = new Date(o.getFullYear(), o.getMonth(), o.getDate(), 24);
  return Math.round((+n - +i) / 36e5);
}
function qv(o) {
  var i = o.getSeconds(), n = o.getMilliseconds();
  return me(o.getTime() - i * 1e3 - n);
}
function by(o, i) {
  return qv(o).getTime() === qv(i).getTime();
}
function Qv(o) {
  if (!Qa(o))
    throw new Error("Invalid date");
  var i = new Date(o);
  return i.setHours(0, 0, 0, 0), i;
}
function Bd(o, i) {
  if (!Qa(o) || !Qa(i))
    throw new Error("Invalid date received");
  var n = Qv(o), a = Qv(i);
  return Ba(n, a);
}
function yy(o) {
  return o.key === te.Space;
}
var qd = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      return a.inputRef = B.createRef(), a.onTimeChange = function(l) {
        var c, d;
        a.setState({ time: l });
        var p = a.props.date, m = p instanceof Date && !isNaN(+p), g = m ? p : /* @__PURE__ */ new Date();
        if (l?.includes(":")) {
          var y = l.split(":"), b = y[0], _ = y[1];
          g.setHours(Number(b)), g.setMinutes(Number(_));
        }
        (d = (c = a.props).onChange) === null || d === void 0 || d.call(c, g);
      }, a.renderTimeInput = function() {
        var l = a.state.time, c = a.props, d = c.date, p = c.timeString, m = c.customTimeInput;
        return m ? N.cloneElement(m, {
          date: d,
          value: l,
          onChange: a.onTimeChange
        }) : B.createElement("input", { type: "time", className: "react-datepicker-time__input", placeholder: "Time", name: "time-input", ref: a.inputRef, onClick: function() {
          var g;
          (g = a.inputRef.current) === null || g === void 0 || g.focus();
        }, required: !0, value: l, onChange: function(g) {
          a.onTimeChange(g.target.value || p);
        } });
      }, a.state = {
        time: a.props.timeString
      }, a;
    }
    return i.getDerivedStateFromProps = function(n, a) {
      return n.timeString !== a.time ? {
        time: n.timeString
      } : null;
    }, i.prototype.render = function() {
      return B.createElement(
        "div",
        { className: "react-datepicker__input-time-container" },
        B.createElement("div", { className: "react-datepicker-time__caption" }, this.props.timeInputLabel),
        B.createElement(
          "div",
          { className: "react-datepicker-time__input-container" },
          B.createElement("div", { className: "react-datepicker-time__input" }, this.renderTimeInput())
        )
      );
    }, i;
  })(N.Component)
), GS = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.dayEl = N.createRef(), n.handleClick = function(a) {
        !n.isDisabled() && n.props.onClick && n.props.onClick(a);
      }, n.handleMouseEnter = function(a) {
        !n.isDisabled() && n.props.onMouseEnter && n.props.onMouseEnter(a);
      }, n.handleOnKeyDown = function(a) {
        var l, c, d = a.key;
        d === te.Space && (a.preventDefault(), a.key = te.Enter), (c = (l = n.props).handleOnKeyDown) === null || c === void 0 || c.call(l, a);
      }, n.isSameDay = function(a) {
        return Ae(n.props.day, a);
      }, n.isKeyboardSelected = function() {
        var a;
        if (n.props.disabledKeyboardNavigation)
          return !1;
        var l = n.props.selectsMultiple ? (a = n.props.selectedDates) === null || a === void 0 ? void 0 : a.some(function(d) {
          return n.isSameDayOrWeek(d);
        }) : n.isSameDayOrWeek(n.props.selected), c = n.props.preSelection && n.isDisabled(n.props.preSelection);
        return !l && n.isSameDayOrWeek(n.props.preSelection) && !c;
      }, n.isDisabled = function(a) {
        return a === void 0 && (a = n.props.day), ga(a, {
          minDate: n.props.minDate,
          maxDate: n.props.maxDate,
          excludeDates: n.props.excludeDates,
          excludeDateIntervals: n.props.excludeDateIntervals,
          includeDateIntervals: n.props.includeDateIntervals,
          includeDates: n.props.includeDates,
          filterDate: n.props.filterDate,
          disabled: n.props.disabled
        });
      }, n.isExcluded = function() {
        return Rf(n.props.day, {
          excludeDates: n.props.excludeDates,
          excludeDateIntervals: n.props.excludeDateIntervals
        });
      }, n.isStartOfWeek = function() {
        return Ae(n.props.day, Zn(n.props.day, n.props.locale, n.props.calendarStartDay));
      }, n.isSameWeek = function(a) {
        return n.props.showWeekPicker && Ae(a, Zn(n.props.day, n.props.locale, n.props.calendarStartDay));
      }, n.isSameDayOrWeek = function(a) {
        return n.isSameDay(a) || n.isSameWeek(a);
      }, n.getHighLightedClass = function() {
        var a = n.props, l = a.day, c = a.highlightDates;
        if (!c)
          return !1;
        var d = $e(l, "MM.dd.yyyy");
        return c.get(d);
      }, n.getHolidaysClass = function() {
        var a, l = n.props, c = l.day, d = l.holidays;
        if (!d)
          return [void 0];
        var p = $e(c, "MM.dd.yyyy");
        return d.has(p) ? [(a = d.get(p)) === null || a === void 0 ? void 0 : a.className] : [void 0];
      }, n.isInRange = function() {
        var a = n.props, l = a.day, c = a.startDate, d = a.endDate;
        return !c || !d ? !1 : _r(l, c, d);
      }, n.isInSelectingRange = function() {
        var a, l = n.props, c = l.day, d = l.selectsStart, p = l.selectsEnd, m = l.selectsRange, g = l.selectsDisabledDaysInRange, y = l.startDate, b = l.swapRange, _ = l.endDate, k = (a = n.props.selectingDate) !== null && a !== void 0 ? a : n.props.preSelection;
        if (n.isAfterMonth() || n.isBeforeMonth() || !(d || p || m) || !k || !g && n.isDisabled())
          return !1;
        if (d && _ && (Ba(k, _) || Er(k, _)))
          return _r(c, k, _);
        if (p && y && (pn(k, y) || Er(k, y)))
          return _r(c, y, k);
        if (m && y && !_) {
          if (Er(k, y) || pn(k, y))
            return _r(c, y, k);
          if (b && Ba(k, y))
            return _r(c, k, y);
        }
        return !1;
      }, n.isSelectingRangeStart = function() {
        var a;
        if (!n.isInSelectingRange())
          return !1;
        var l = n.props, c = l.day, d = l.startDate, p = l.selectsStart, m = l.swapRange, g = l.selectsRange, y = (a = n.props.selectingDate) !== null && a !== void 0 ? a : n.props.preSelection;
        return p ? Ae(c, y) : g && m && d && y ? Ae(c, Ba(y, d) ? y : d) : Ae(c, d);
      }, n.isSelectingRangeEnd = function() {
        var a;
        if (!n.isInSelectingRange())
          return !1;
        var l = n.props, c = l.day, d = l.endDate, p = l.selectsEnd, m = l.selectsRange, g = l.swapRange, y = l.startDate, b = (a = n.props.selectingDate) !== null && a !== void 0 ? a : n.props.preSelection;
        return p ? Ae(c, b) : m && g && y && b ? Ae(c, Ba(b, y) ? y : b) : m ? Ae(c, b) : Ae(c, d);
      }, n.isRangeStart = function() {
        var a = n.props, l = a.day, c = a.startDate, d = a.endDate;
        return !c || !d ? !1 : Ae(c, l);
      }, n.isRangeEnd = function() {
        var a = n.props, l = a.day, c = a.startDate, d = a.endDate;
        return !c || !d ? !1 : Ae(d, l);
      }, n.isWeekend = function() {
        var a = F_(n.props.day);
        return a === 0 || a === 6;
      }, n.isAfterMonth = function() {
        return n.props.month !== void 0 && (n.props.month + 1) % 12 === Ft(n.props.day);
      }, n.isBeforeMonth = function() {
        return n.props.month !== void 0 && (Ft(n.props.day) + 1) % 12 === n.props.month;
      }, n.isCurrentDay = function() {
        return n.isSameDay(Le());
      }, n.isSelected = function() {
        var a;
        return n.props.selectsMultiple ? (a = n.props.selectedDates) === null || a === void 0 ? void 0 : a.some(function(l) {
          return n.isSameDayOrWeek(l);
        }) : n.isSameDayOrWeek(n.props.selected);
      }, n.getClassNames = function(a) {
        var l = n.props.dayClassName ? n.props.dayClassName(a) : void 0;
        return vt("react-datepicker__day", l, "react-datepicker__day--" + NS(n.props.day), {
          "react-datepicker__day--disabled": n.isDisabled(),
          "react-datepicker__day--excluded": n.isExcluded(),
          "react-datepicker__day--selected": n.isSelected(),
          "react-datepicker__day--keyboard-selected": n.isKeyboardSelected(),
          "react-datepicker__day--range-start": n.isRangeStart(),
          "react-datepicker__day--range-end": n.isRangeEnd(),
          "react-datepicker__day--in-range": n.isInRange(),
          "react-datepicker__day--in-selecting-range": n.isInSelectingRange(),
          "react-datepicker__day--selecting-range-start": n.isSelectingRangeStart(),
          "react-datepicker__day--selecting-range-end": n.isSelectingRangeEnd(),
          "react-datepicker__day--today": n.isCurrentDay(),
          "react-datepicker__day--weekend": n.isWeekend(),
          "react-datepicker__day--outside-month": n.isAfterMonth() || n.isBeforeMonth()
        }, n.getHighLightedClass(), n.getHolidaysClass());
      }, n.getAriaLabel = function() {
        var a = n.props, l = a.day, c = a.ariaLabelPrefixWhenEnabled, d = c === void 0 ? "Choose" : c, p = a.ariaLabelPrefixWhenDisabled, m = p === void 0 ? "Not available" : p, g = n.isDisabled() || n.isExcluded() ? m : d;
        return "".concat(g, " ").concat($e(l, "PPPP", n.props.locale));
      }, n.getTitle = function() {
        var a = n.props, l = a.day, c = a.holidays, d = c === void 0 ? /* @__PURE__ */ new Map() : c, p = a.excludeDates, m = $e(l, "MM.dd.yyyy"), g = [];
        return d.has(m) && g.push.apply(g, d.get(m).holidayNames), n.isExcluded() && g.push(p?.filter(function(y) {
          return y instanceof Date ? Ae(y, l) : Ae(y?.date, l);
        }).map(function(y) {
          if (!(y instanceof Date))
            return y?.message;
        })), g.join(", ");
      }, n.getTabIndex = function() {
        var a = n.props.selected, l = n.props.preSelection, c = !(n.props.showWeekPicker && (n.props.showWeekNumber || !n.isStartOfWeek())) && (n.isKeyboardSelected() || n.isSameDay(a) && Ae(l, a)) ? 0 : -1;
        return c;
      }, n.handleFocusDay = function() {
        var a;
        n.shouldFocusDay() && ((a = n.dayEl.current) === null || a === void 0 || a.focus({ preventScroll: !0 }));
      }, n.renderDayContents = function() {
        return n.props.monthShowsDuplicateDaysEnd && n.isAfterMonth() || n.props.monthShowsDuplicateDaysStart && n.isBeforeMonth() ? null : n.props.renderDayContents ? n.props.renderDayContents(mv(n.props.day), n.props.day) : mv(n.props.day);
      }, n.render = function() {
        return (
          // TODO: Use <option> instead of the "option" role to ensure accessibility across all devices.
          B.createElement(
            "div",
            { ref: n.dayEl, className: n.getClassNames(n.props.day), onKeyDown: n.handleOnKeyDown, onClick: n.handleClick, onMouseEnter: n.props.usePointerEvent ? void 0 : n.handleMouseEnter, onPointerEnter: n.props.usePointerEvent ? n.handleMouseEnter : void 0, tabIndex: n.getTabIndex(), "aria-label": n.getAriaLabel(), role: "gridcell", title: n.getTitle(), "aria-disabled": n.isDisabled(), "aria-current": n.isCurrentDay() ? "date" : void 0, "aria-selected": n.isSelected() || n.isInRange() },
            n.renderDayContents(),
            n.getTitle() !== "" && B.createElement("span", { className: "overlay" }, n.getTitle())
          )
        );
      }, n;
    }
    return i.prototype.componentDidMount = function() {
      this.handleFocusDay();
    }, i.prototype.componentDidUpdate = function() {
      this.handleFocusDay();
    }, i.prototype.shouldFocusDay = function() {
      var n = !1;
      return this.getTabIndex() === 0 && this.isSameDay(this.props.preSelection) && ((!document.activeElement || document.activeElement === document.body) && (n = !0), this.props.inline && !this.props.shouldFocusDayInline && (n = !1), this.isDayActiveElement() && (n = !0), this.isDuplicateDay() && (n = !1)), n;
    }, i.prototype.isDayActiveElement = function() {
      var n, a, l;
      return ((a = (n = this.props.containerRef) === null || n === void 0 ? void 0 : n.current) === null || a === void 0 ? void 0 : a.contains(document.activeElement)) && ((l = document.activeElement) === null || l === void 0 ? void 0 : l.classList.contains("react-datepicker__day"));
    }, i.prototype.isDuplicateDay = function() {
      return (
        //day is one of the non rendered duplicate days
        this.props.monthShowsDuplicateDaysEnd && this.isAfterMonth() || this.props.monthShowsDuplicateDaysStart && this.isBeforeMonth()
      );
    }, i;
  })(N.Component)
), XS = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.weekNumberEl = N.createRef(), n.handleClick = function(a) {
        n.props.onClick && n.props.onClick(a);
      }, n.handleOnKeyDown = function(a) {
        var l, c, d = a.key;
        d === te.Space && (a.preventDefault(), a.key = te.Enter), (c = (l = n.props).handleOnKeyDown) === null || c === void 0 || c.call(l, a);
      }, n.isKeyboardSelected = function() {
        return !n.props.disabledKeyboardNavigation && !Ae(n.props.date, n.props.selected) && Ae(n.props.date, n.props.preSelection);
      }, n.getTabIndex = function() {
        return n.props.showWeekPicker && n.props.showWeekNumber && (n.isKeyboardSelected() || Ae(n.props.date, n.props.selected) && Ae(n.props.preSelection, n.props.selected)) ? 0 : -1;
      }, n.handleFocusWeekNumber = function(a) {
        var l = !1;
        n.getTabIndex() === 0 && !a?.isInputFocused && Ae(n.props.date, n.props.preSelection) && ((!document.activeElement || document.activeElement === document.body) && (l = !0), n.props.inline && !n.props.shouldFocusDayInline && (l = !1), n.props.containerRef && n.props.containerRef.current && n.props.containerRef.current.contains(document.activeElement) && document.activeElement && document.activeElement.classList.contains("react-datepicker__week-number") && (l = !0)), l && n.weekNumberEl.current && n.weekNumberEl.current.focus({ preventScroll: !0 });
      }, n;
    }
    return Object.defineProperty(i, "defaultProps", {
      get: function() {
        return {
          ariaLabelPrefix: "week "
        };
      },
      enumerable: !1,
      configurable: !0
    }), i.prototype.componentDidMount = function() {
      this.handleFocusWeekNumber();
    }, i.prototype.componentDidUpdate = function(n) {
      this.handleFocusWeekNumber(n);
    }, i.prototype.render = function() {
      var n = this.props, a = n.weekNumber, l = n.isWeekDisabled, c = n.ariaLabelPrefix, d = c === void 0 ? i.defaultProps.ariaLabelPrefix : c, p = n.onClick, m = {
        "react-datepicker__week-number": !0,
        "react-datepicker__week-number--clickable": !!p && !l,
        "react-datepicker__week-number--selected": !!p && Ae(this.props.date, this.props.selected)
      };
      return B.createElement("div", { ref: this.weekNumberEl, className: vt(m), "aria-label": "".concat(d, " ").concat(this.props.weekNumber), onClick: this.handleClick, onKeyDown: this.handleOnKeyDown, tabIndex: this.getTabIndex(), role: "gridcell" }, a);
    }, i;
  })(N.Component)
), ZS = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.isDisabled = function(a) {
        return ga(a, {
          minDate: n.props.minDate,
          maxDate: n.props.maxDate,
          excludeDates: n.props.excludeDates,
          excludeDateIntervals: n.props.excludeDateIntervals,
          includeDateIntervals: n.props.includeDateIntervals,
          includeDates: n.props.includeDates,
          filterDate: n.props.filterDate
        });
      }, n.handleDayClick = function(a, l) {
        n.props.onDayClick && n.props.onDayClick(a, l);
      }, n.handleDayMouseEnter = function(a) {
        n.props.onDayMouseEnter && n.props.onDayMouseEnter(a);
      }, n.handleWeekClick = function(a, l, c) {
        for (var d, p, m, g = new Date(a), y = 0; y < 7; y++) {
          var b = new Date(a);
          b.setDate(b.getDate() + y);
          var _ = !n.isDisabled(b);
          if (_) {
            g = b;
            break;
          }
        }
        typeof n.props.onWeekSelect == "function" && n.props.onWeekSelect(g, l, c), n.props.showWeekPicker && n.handleDayClick(g, c), ((d = n.props.shouldCloseOnSelect) !== null && d !== void 0 ? d : i.defaultProps.shouldCloseOnSelect) && ((m = (p = n.props).setOpen) === null || m === void 0 || m.call(p, !1));
      }, n.formatWeekNumber = function(a) {
        return n.props.formatWeekNumber ? n.props.formatWeekNumber(a) : CS(a);
      }, n.isWeekDisabled = function() {
        for (var a = n.startOfWeek(), l = Sa(a, 6), c = new Date(a); c <= l; ) {
          if (!n.isDisabled(c))
            return !1;
          c = Sa(c, 1);
        }
        return !0;
      }, n.renderDays = function() {
        var a = n.startOfWeek(), l = [], c = n.formatWeekNumber(a);
        if (n.props.showWeekNumber) {
          var d = n.props.onWeekSelect || n.props.showWeekPicker ? n.handleWeekClick.bind(n, a, c) : void 0;
          l.push(B.createElement(XS, Me({ key: "W" }, i.defaultProps, n.props, { weekNumber: c, isWeekDisabled: n.isWeekDisabled(), date: a, onClick: d })));
        }
        return l.concat([0, 1, 2, 3, 4, 5, 6].map(function(p) {
          var m = Sa(a, p);
          return B.createElement(GS, Me({}, i.defaultProps, n.props, { ariaLabelPrefixWhenEnabled: n.props.chooseDayAriaLabelPrefix, ariaLabelPrefixWhenDisabled: n.props.disabledDayAriaLabelPrefix, key: m.valueOf(), day: m, onClick: n.handleDayClick.bind(n, m), onMouseEnter: n.handleDayMouseEnter.bind(n, m) }));
        }));
      }, n.startOfWeek = function() {
        return Zn(n.props.day, n.props.locale, n.props.calendarStartDay);
      }, n.isKeyboardSelected = function() {
        return !n.props.disabledKeyboardNavigation && !Ae(n.startOfWeek(), n.props.selected) && Ae(n.startOfWeek(), n.props.preSelection);
      }, n;
    }
    return Object.defineProperty(i, "defaultProps", {
      get: function() {
        return {
          shouldCloseOnSelect: !0
        };
      },
      enumerable: !1,
      configurable: !0
    }), i.prototype.render = function() {
      var n = {
        "react-datepicker__week": !0,
        "react-datepicker__week--selected": Ae(this.startOfWeek(), this.props.selected),
        "react-datepicker__week--keyboard-selected": this.isKeyboardSelected()
      }, a = this.props.weekClassName ? this.props.weekClassName(this.startOfWeek()) : void 0;
      return B.createElement("div", { className: vt(n, a), role: "row" }, this.renderDays());
    }, i;
  })(N.Component)
), Yo, KS = 6, Di = {
  TWO_COLUMNS: "two_columns",
  THREE_COLUMNS: "three_columns",
  FOUR_COLUMNS: "four_columns"
}, Qd = (Yo = {}, Yo[Di.TWO_COLUMNS] = {
  grid: [
    [0, 1],
    [2, 3],
    [4, 5],
    [6, 7],
    [8, 9],
    [10, 11]
  ],
  verticalNavigationOffset: 2
}, Yo[Di.THREE_COLUMNS] = {
  grid: [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [9, 10, 11]
  ],
  verticalNavigationOffset: 3
}, Yo[Di.FOUR_COLUMNS] = {
  grid: [
    [0, 1, 2, 3],
    [4, 5, 6, 7],
    [8, 9, 10, 11]
  ],
  verticalNavigationOffset: 4
}, Yo), Ss = 1;
function Pv(o, i) {
  return o ? Di.FOUR_COLUMNS : i ? Di.TWO_COLUMNS : Di.THREE_COLUMNS;
}
var WS = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.MONTH_REFS = qa([], Array(12), !0).map(function() {
        return N.createRef();
      }), n.QUARTER_REFS = qa([], Array(4), !0).map(function() {
        return N.createRef();
      }), n.isDisabled = function(a) {
        return ga(a, {
          minDate: n.props.minDate,
          maxDate: n.props.maxDate,
          excludeDates: n.props.excludeDates,
          excludeDateIntervals: n.props.excludeDateIntervals,
          includeDateIntervals: n.props.includeDateIntervals,
          includeDates: n.props.includeDates,
          filterDate: n.props.filterDate,
          disabled: n.props.disabled
        });
      }, n.isExcluded = function(a) {
        return Rf(a, {
          excludeDates: n.props.excludeDates,
          excludeDateIntervals: n.props.excludeDateIntervals
        });
      }, n.handleDayClick = function(a, l) {
        var c, d;
        (d = (c = n.props).onDayClick) === null || d === void 0 || d.call(c, a, l, n.props.orderInDisplay);
      }, n.handleDayMouseEnter = function(a) {
        var l, c;
        (c = (l = n.props).onDayMouseEnter) === null || c === void 0 || c.call(l, a);
      }, n.handleMouseLeave = function() {
        var a, l;
        (l = (a = n.props).onMouseLeave) === null || l === void 0 || l.call(a);
      }, n.isRangeStartMonth = function(a) {
        var l = n.props, c = l.day, d = l.startDate, p = l.endDate;
        return !d || !p ? !1 : At(na(c, a), d);
      }, n.isRangeStartQuarter = function(a) {
        var l = n.props, c = l.day, d = l.startDate, p = l.endDate;
        return !d || !p ? !1 : Ks(_i(c, a), d);
      }, n.isRangeEndMonth = function(a) {
        var l = n.props, c = l.day, d = l.startDate, p = l.endDate;
        return !d || !p ? !1 : At(na(c, a), p);
      }, n.isRangeEndQuarter = function(a) {
        var l = n.props, c = l.day, d = l.startDate, p = l.endDate;
        return !d || !p ? !1 : Ks(_i(c, a), p);
      }, n.isInSelectingRangeMonth = function(a) {
        var l, c = n.props, d = c.day, p = c.selectsStart, m = c.selectsEnd, g = c.selectsRange, y = c.startDate, b = c.endDate, _ = (l = n.props.selectingDate) !== null && l !== void 0 ? l : n.props.preSelection;
        return !(p || m || g) || !_ ? !1 : p && b ? xs(_, b, a, d) : m && y || g && y && !b ? xs(y, _, a, d) : !1;
      }, n.isSelectingMonthRangeStart = function(a) {
        var l;
        if (!n.isInSelectingRangeMonth(a))
          return !1;
        var c = n.props, d = c.day, p = c.startDate, m = c.selectsStart, g = na(d, a), y = (l = n.props.selectingDate) !== null && l !== void 0 ? l : n.props.preSelection;
        return m ? At(g, y) : At(g, p);
      }, n.isSelectingMonthRangeEnd = function(a) {
        var l;
        if (!n.isInSelectingRangeMonth(a))
          return !1;
        var c = n.props, d = c.day, p = c.endDate, m = c.selectsEnd, g = c.selectsRange, y = na(d, a), b = (l = n.props.selectingDate) !== null && l !== void 0 ? l : n.props.preSelection;
        return m || g ? At(y, b) : At(y, p);
      }, n.isInSelectingRangeQuarter = function(a) {
        var l, c = n.props, d = c.day, p = c.selectsStart, m = c.selectsEnd, g = c.selectsRange, y = c.startDate, b = c.endDate, _ = (l = n.props.selectingDate) !== null && l !== void 0 ? l : n.props.preSelection;
        return !(p || m || g) || !_ ? !1 : p && b ? ks(_, b, a, d) : m && y || g && y && !b ? ks(y, _, a, d) : !1;
      }, n.isWeekInMonth = function(a) {
        var l = n.props.day, c = Sa(a, 6);
        return At(a, l) || At(c, l);
      }, n.isCurrentMonth = function(a, l) {
        return Ne(a) === Ne(Le()) && l === Ft(Le());
      }, n.isCurrentQuarter = function(a, l) {
        return Ne(a) === Ne(Le()) && l === Gn(Le());
      }, n.isSelectedMonth = function(a, l, c) {
        return Ft(c) === l && Ne(a) === Ne(c);
      }, n.isSelectMonthInList = function(a, l, c) {
        return c.some(function(d) {
          return n.isSelectedMonth(a, l, d);
        });
      }, n.isSelectedQuarter = function(a, l, c) {
        return Gn(c) === l && Ne(a) === Ne(c);
      }, n.isSelectQuarterInList = function(a, l, c) {
        return c.some(function(d) {
          return n.isSelectedQuarter(a, l, d);
        });
      }, n.isMonthSelected = function() {
        var a = n.props, l = a.day, c = a.selected, d = a.selectedDates, p = a.selectsMultiple, m = Ft(l);
        return p ? d?.some(function(g) {
          return n.isSelectedMonth(l, m, g);
        }) : !!c && n.isSelectedMonth(l, m, c);
      }, n.isQuarterSelected = function() {
        var a = n.props, l = a.day, c = a.selected, d = a.selectedDates, p = a.selectsMultiple, m = Gn(l);
        return p ? d?.some(function(g) {
          return n.isSelectedQuarter(l, m, g);
        }) : !!c && n.isSelectedQuarter(l, m, c);
      }, n.renderWeeks = function() {
        if (!Pt(n.props.day))
          return [];
        for (var a = [], l = n.props.fixedHeight, c = 0, d = !1, p = Zn(hn(n.props.day), n.props.locale, n.props.calendarStartDay), m = function(w) {
          return n.props.showWeekPicker ? Zn(w, n.props.locale, n.props.calendarStartDay) : n.props.preSelection;
        }, g = function(w) {
          return n.props.showWeekPicker ? Zn(w, n.props.locale, n.props.calendarStartDay) : n.props.selected;
        }, y = n.props.selected ? g(n.props.selected) : void 0, b = n.props.preSelection ? m(n.props.preSelection) : void 0; a.push(B.createElement(ZS, Me({}, n.props, { ariaLabelPrefix: n.props.weekAriaLabelPrefix, key: c, day: p, month: Ft(n.props.day), onDayClick: n.handleDayClick, onDayMouseEnter: n.handleDayMouseEnter, selected: y, preSelection: b, showWeekNumber: n.props.showWeekNumbers }))), !d; ) {
          c++, p = Us(p, 1);
          var _ = l && c >= KS, k = !l && !n.isWeekInMonth(p);
          if (_ || k)
            if (n.props.peekNextMonth)
              d = !0;
            else
              break;
        }
        return a;
      }, n.onMonthClick = function(a, l) {
        var c = n.isMonthDisabledForLabelDate(l), d = c.isDisabled, p = c.labelDate;
        d || n.handleDayClick(hn(p), a);
      }, n.onMonthMouseEnter = function(a) {
        var l = n.isMonthDisabledForLabelDate(a), c = l.isDisabled, d = l.labelDate;
        c || n.handleDayMouseEnter(hn(d));
      }, n.handleMonthNavigation = function(a, l) {
        var c, d, p, m;
        (d = (c = n.props).setPreSelection) === null || d === void 0 || d.call(c, l), (m = (p = n.MONTH_REFS[a]) === null || p === void 0 ? void 0 : p.current) === null || m === void 0 || m.focus();
      }, n.handleKeyboardNavigation = function(a, l, c) {
        var d, p = n.props, m = p.selected, g = p.preSelection, y = p.setPreSelection, b = p.minDate, _ = p.maxDate, k = p.showFourColumnMonthYearPicker, w = p.showTwoColumnMonthYearPicker;
        if (g) {
          var D = Pv(k, w), S = n.getVerticalOffset(D), O = (d = Qd[D]) === null || d === void 0 ? void 0 : d.grid, q = function(Z, ie, ue) {
            var de, ne, $ = ie, ae = ue;
            switch (Z) {
              case te.ArrowRight:
                $ = Ea(ie, Ss), ae = ue === 11 ? 0 : ue + Ss;
                break;
              case te.ArrowLeft:
                $ = Tr(ie, Ss), ae = ue === 0 ? 11 : ue - Ss;
                break;
              case te.ArrowUp:
                $ = Tr(ie, S), ae = !((de = O?.[0]) === null || de === void 0) && de.includes(ue) ? ue + 12 - S : ue - S;
                break;
              case te.ArrowDown:
                $ = Ea(ie, S), ae = !((ne = O?.[O.length - 1]) === null || ne === void 0) && ne.includes(ue) ? ue - 12 + S : ue + S;
                break;
            }
            return { newCalculatedDate: $, newCalculatedMonth: ae };
          }, L = function(Z, ie, ue) {
            for (var de = 40, ne = Z, $ = !1, ae = 0, le = q(ne, ie, ue), fe = le.newCalculatedDate, j = le.newCalculatedMonth; !$; ) {
              if (ae >= de) {
                fe = ie, j = ue;
                break;
              }
              if (b && fe < b) {
                ne = te.ArrowRight;
                var Q = q(ne, fe, j);
                fe = Q.newCalculatedDate, j = Q.newCalculatedMonth;
              }
              if (_ && fe > _) {
                ne = te.ArrowLeft;
                var Q = q(ne, fe, j);
                fe = Q.newCalculatedDate, j = Q.newCalculatedMonth;
              }
              if (YS(fe, n.props)) {
                var Q = q(ne, fe, j);
                fe = Q.newCalculatedDate, j = Q.newCalculatedMonth;
              } else
                $ = !0;
              ae++;
            }
            return { newCalculatedDate: fe, newCalculatedMonth: j };
          };
          if (l === te.Enter) {
            n.isMonthDisabled(c) || (n.onMonthClick(a, c), y?.(m));
            return;
          }
          var P = L(l, g, c), F = P.newCalculatedDate, J = P.newCalculatedMonth;
          switch (l) {
            case te.ArrowRight:
            case te.ArrowLeft:
            case te.ArrowUp:
            case te.ArrowDown:
              n.handleMonthNavigation(J, F);
              break;
          }
        }
      }, n.getVerticalOffset = function(a) {
        var l, c;
        return (c = (l = Qd[a]) === null || l === void 0 ? void 0 : l.verticalNavigationOffset) !== null && c !== void 0 ? c : 0;
      }, n.onMonthKeyDown = function(a, l) {
        var c = n.props, d = c.disabledKeyboardNavigation, p = c.handleOnMonthKeyDown, m = a.key;
        m !== te.Tab && a.preventDefault(), d || n.handleKeyboardNavigation(a, m, l), p && p(a);
      }, n.onQuarterClick = function(a, l) {
        var c = _i(n.props.day, l);
        ws(c, n.props) || n.handleDayClick(Nv(c), a);
      }, n.onQuarterMouseEnter = function(a) {
        var l = _i(n.props.day, a);
        ws(l, n.props) || n.handleDayMouseEnter(Nv(l));
      }, n.handleQuarterNavigation = function(a, l) {
        var c, d, p, m;
        n.isDisabled(l) || n.isExcluded(l) || ((d = (c = n.props).setPreSelection) === null || d === void 0 || d.call(c, l), (m = (p = n.QUARTER_REFS[a - 1]) === null || p === void 0 ? void 0 : p.current) === null || m === void 0 || m.focus());
      }, n.onQuarterKeyDown = function(a, l) {
        var c, d, p = a.key;
        if (!n.props.disabledKeyboardNavigation)
          switch (p) {
            case te.Enter:
              n.onQuarterClick(a, l), (d = (c = n.props).setPreSelection) === null || d === void 0 || d.call(c, n.props.selected);
              break;
            case te.ArrowRight:
              if (!n.props.preSelection)
                break;
              n.handleQuarterNavigation(l === 4 ? 1 : l + 1, _f(n.props.preSelection, 1));
              break;
            case te.ArrowLeft:
              if (!n.props.preSelection)
                break;
              n.handleQuarterNavigation(l === 1 ? 4 : l - 1, Jb(n.props.preSelection));
              break;
          }
      }, n.isMonthDisabledForLabelDate = function(a) {
        var l, c = n.props, d = c.day, p = c.disabled, m = c.minDate, g = c.maxDate, y = c.excludeDates, b = c.includeDates, _ = na(d, a);
        return p ? {
          isDisabled: !0,
          labelDate: na(d, a)
        } : {
          isDisabled: (l = (m || g || y || b) && my(_, n.props)) !== null && l !== void 0 ? l : !1,
          labelDate: _
        };
      }, n.isMonthDisabled = function(a) {
        var l = n.isMonthDisabledForLabelDate(a).isDisabled;
        return l;
      }, n.getMonthClassNames = function(a) {
        var l = n.props, c = l.day, d = l.startDate, p = l.endDate, m = l.preSelection, g = l.monthClassName, y = g ? g(na(c, a)) : void 0, b = n.getSelection();
        return vt("react-datepicker__month-text", "react-datepicker__month-".concat(a), y, {
          "react-datepicker__month-text--disabled": n.isMonthDisabled(a),
          "react-datepicker__month-text--selected": b ? n.isSelectMonthInList(c, a, b) : void 0,
          "react-datepicker__month-text--keyboard-selected": !n.props.disabledKeyboardNavigation && m && n.isSelectedMonth(c, a, m) && !n.isMonthSelected() && !n.isMonthDisabled(a),
          "react-datepicker__month-text--in-selecting-range": n.isInSelectingRangeMonth(a),
          "react-datepicker__month-text--in-range": d && p ? xs(d, p, a, c) : void 0,
          "react-datepicker__month-text--range-start": n.isRangeStartMonth(a),
          "react-datepicker__month-text--range-end": n.isRangeEndMonth(a),
          "react-datepicker__month-text--selecting-range-start": n.isSelectingMonthRangeStart(a),
          "react-datepicker__month-text--selecting-range-end": n.isSelectingMonthRangeEnd(a),
          "react-datepicker__month-text--today": n.isCurrentMonth(c, a)
        });
      }, n.getTabIndex = function(a) {
        if (n.props.preSelection == null)
          return "-1";
        var l = Ft(n.props.preSelection), c = n.isMonthDisabledForLabelDate(l).isDisabled, d = a === l && !(c || n.props.disabledKeyboardNavigation) ? "0" : "-1";
        return d;
      }, n.getQuarterTabIndex = function(a) {
        if (n.props.preSelection == null)
          return "-1";
        var l = Gn(n.props.preSelection), c = ws(n.props.day, n.props), d = a === l && !(c || n.props.disabledKeyboardNavigation) ? "0" : "-1";
        return d;
      }, n.getAriaLabel = function(a) {
        var l = n.props, c = l.chooseDayAriaLabelPrefix, d = c === void 0 ? "Choose" : c, p = l.disabledDayAriaLabelPrefix, m = p === void 0 ? "Not available" : p, g = l.day, y = l.locale, b = na(g, a), _ = n.isDisabled(b) || n.isExcluded(b) ? m : d;
        return "".concat(_, " ").concat($e(b, "MMMM yyyy", y));
      }, n.getQuarterClassNames = function(a) {
        var l = n.props, c = l.day, d = l.startDate, p = l.endDate, m = l.minDate, g = l.maxDate, y = l.excludeDates, b = l.includeDates, _ = l.filterDate, k = l.preSelection, w = l.disabledKeyboardNavigation, D = l.disabled, S = (m || g || y || b || _ || D) && ws(_i(c, a), n.props), O = n.getSelection();
        return vt("react-datepicker__quarter-text", "react-datepicker__quarter-".concat(a), {
          "react-datepicker__quarter-text--disabled": S,
          "react-datepicker__quarter-text--selected": O ? n.isSelectQuarterInList(c, a, O) : void 0,
          "react-datepicker__quarter-text--keyboard-selected": !w && k && n.isSelectedQuarter(c, a, k) && !n.isQuarterSelected() && !S,
          "react-datepicker__quarter-text--in-selecting-range": n.isInSelectingRangeQuarter(a),
          "react-datepicker__quarter-text--in-range": d && p ? ks(d, p, a, c) : void 0,
          "react-datepicker__quarter-text--range-start": n.isRangeStartQuarter(a),
          "react-datepicker__quarter-text--range-end": n.isRangeEndQuarter(a),
          "react-datepicker__quarter-text--today": n.isCurrentQuarter(c, a)
        });
      }, n.getMonthContent = function(a) {
        var l = n.props, c = l.showFullMonthYearPicker, d = l.renderMonthContent, p = l.locale, m = l.day, g = hy(a, p), y = Af(a, p);
        return d ? d(a, g, y, m) : c ? y : g;
      }, n.getQuarterContent = function(a) {
        var l, c = n.props, d = c.renderQuarterContent, p = c.locale, m = LS(a, p);
        return (l = d?.(a, m)) !== null && l !== void 0 ? l : m;
      }, n.renderMonths = function() {
        var a, l = n.props, c = l.showTwoColumnMonthYearPicker, d = l.showFourColumnMonthYearPicker, p = l.day, m = l.selected, g = (a = Qd[Pv(d, c)]) === null || a === void 0 ? void 0 : a.grid;
        return g?.map(function(y, b) {
          return B.createElement("div", { className: "react-datepicker__month-wrapper", key: b }, y.map(function(_, k) {
            return B.createElement("div", { ref: n.MONTH_REFS[_], key: k, onClick: function(w) {
              n.onMonthClick(w, _);
            }, onKeyDown: function(w) {
              yy(w) && (w.preventDefault(), w.key = te.Enter), n.onMonthKeyDown(w, _);
            }, onMouseEnter: n.props.usePointerEvent ? void 0 : function() {
              return n.onMonthMouseEnter(_);
            }, onPointerEnter: n.props.usePointerEvent ? function() {
              return n.onMonthMouseEnter(_);
            } : void 0, tabIndex: Number(n.getTabIndex(_)), className: n.getMonthClassNames(_), "aria-disabled": n.isMonthDisabled(_), role: "option", "aria-label": n.getAriaLabel(_), "aria-current": n.isCurrentMonth(p, _) ? "date" : void 0, "aria-selected": m ? n.isSelectedMonth(p, _, m) : void 0 }, n.getMonthContent(_));
          }));
        });
      }, n.renderQuarters = function() {
        var a = n.props, l = a.day, c = a.selected, d = [1, 2, 3, 4];
        return B.createElement("div", { className: "react-datepicker__quarter-wrapper" }, d.map(function(p, m) {
          return B.createElement("div", { key: m, ref: n.QUARTER_REFS[m], role: "option", onClick: function(g) {
            n.onQuarterClick(g, p);
          }, onKeyDown: function(g) {
            n.onQuarterKeyDown(g, p);
          }, onMouseEnter: n.props.usePointerEvent ? void 0 : function() {
            return n.onQuarterMouseEnter(p);
          }, onPointerEnter: n.props.usePointerEvent ? function() {
            return n.onQuarterMouseEnter(p);
          } : void 0, className: n.getQuarterClassNames(p), "aria-selected": c ? n.isSelectedQuarter(l, p, c) : void 0, tabIndex: Number(n.getQuarterTabIndex(p)), "aria-current": n.isCurrentQuarter(l, p) ? "date" : void 0 }, n.getQuarterContent(p));
        }));
      }, n.getClassNames = function() {
        var a = n.props, l = a.selectingDate, c = a.selectsStart, d = a.selectsEnd, p = a.showMonthYearPicker, m = a.showQuarterYearPicker, g = a.showWeekPicker;
        return vt("react-datepicker__month", {
          "react-datepicker__month--selecting-range": l && (c || d)
        }, { "react-datepicker__monthPicker": p }, { "react-datepicker__quarterPicker": m }, { "react-datepicker__weekPicker": g });
      }, n;
    }
    return i.prototype.getSelection = function() {
      var n = this.props, a = n.selected, l = n.selectedDates, c = n.selectsMultiple;
      if (c)
        return l;
      if (a)
        return [a];
    }, i.prototype.render = function() {
      var n = this.props, a = n.showMonthYearPicker, l = n.showQuarterYearPicker, c = n.day, d = n.ariaLabelPrefix, p = d === void 0 ? "Month " : d, m = p ? p.trim() + " " : "", g = Pt(c) ? "".concat(m).concat($e(c, "MMMM, yyyy", this.props.locale)) : "", y = a || l;
      return y ? B.createElement("div", { className: this.getClassNames(), onMouseLeave: this.props.usePointerEvent ? void 0 : this.handleMouseLeave, onPointerLeave: this.props.usePointerEvent ? this.handleMouseLeave : void 0, "aria-label": g, role: "listbox" }, a ? this.renderMonths() : this.renderQuarters()) : B.createElement(
        "div",
        { role: "table" },
        this.props.dayNamesHeader && B.createElement("div", { role: "rowgroup" }, this.props.dayNamesHeader),
        this.props.monthHeader && B.createElement("div", { role: "rowgroup" }, this.props.monthHeader),
        B.createElement("div", { className: this.getClassNames(), onMouseLeave: this.props.usePointerEvent ? void 0 : this.handleMouseLeave, onPointerLeave: this.props.usePointerEvent ? this.handleMouseLeave : void 0, "aria-label": g, role: "rowgroup" }, this.renderWeeks()),
        this.props.monthFooter && B.createElement("div", { role: "rowgroup" }, this.props.monthFooter)
      );
    }, i;
  })(N.Component)
), IS = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.monthOptionButtonsRef = {}, n.isSelectedMonth = function(a) {
        return n.props.month === a;
      }, n.handleOptionKeyDown = function(a, l) {
        var c;
        switch (l.key) {
          case "Enter":
            l.preventDefault(), n.onChange(a);
            break;
          case "Escape":
            l.preventDefault(), n.props.onCancel();
            break;
          case "ArrowUp":
          case "ArrowDown": {
            l.preventDefault();
            var d = (a + (l.key === "ArrowUp" ? -1 : 1) + n.props.monthNames.length) % n.props.monthNames.length;
            (c = n.monthOptionButtonsRef[d]) === null || c === void 0 || c.focus();
            break;
          }
        }
      }, n.renderOptions = function() {
        return n.monthOptionButtonsRef = {}, n.props.monthNames.map(function(a, l) {
          return B.createElement(
            "div",
            { ref: function(c) {
              n.monthOptionButtonsRef[l] = c, n.isSelectedMonth(l) && c?.focus();
            }, role: "button", tabIndex: 0, className: n.isSelectedMonth(l) ? "react-datepicker__month-option react-datepicker__month-option--selected_month" : "react-datepicker__month-option", key: a, onClick: n.onChange.bind(n, l), onKeyDown: n.handleOptionKeyDown.bind(n, l), "aria-selected": n.isSelectedMonth(l) ? "true" : void 0 },
            n.isSelectedMonth(l) ? B.createElement("span", { className: "react-datepicker__month-option--selected" }, "✓") : "",
            a
          );
        });
      }, n.onChange = function(a) {
        return n.props.onChange(a);
      }, n.handleClickOutside = function() {
        return n.props.onCancel();
      }, n;
    }
    return i.prototype.render = function() {
      return B.createElement(dc, { className: "react-datepicker__month-dropdown", onClickOutside: this.handleClickOutside }, this.renderOptions());
    }, i;
  })(N.Component)
), JS = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.state = {
        dropdownVisible: !1
      }, n.renderSelectOptions = function(a) {
        return a.map(function(l, c) {
          return B.createElement("option", { key: l, value: c }, l);
        });
      }, n.renderSelectMode = function(a) {
        return B.createElement("select", { value: n.props.month, className: "react-datepicker__month-select", onChange: function(l) {
          return n.onChange(parseInt(l.target.value));
        } }, n.renderSelectOptions(a));
      }, n.renderReadView = function(a, l) {
        return B.createElement(
          "button",
          { key: "read", type: "button", style: { visibility: a ? "visible" : "hidden" }, className: "react-datepicker__month-read-view", onClick: n.toggleDropdown },
          B.createElement("span", { className: "react-datepicker__month-read-view--down-arrow" }),
          B.createElement("span", { className: "react-datepicker__month-read-view--selected-month" }, l[n.props.month])
        );
      }, n.renderDropdown = function(a) {
        return B.createElement(IS, Me({ key: "dropdown" }, n.props, { monthNames: a, onChange: n.onChange, onCancel: n.toggleDropdown }));
      }, n.renderScrollMode = function(a) {
        var l = n.state.dropdownVisible, c = [n.renderReadView(!l, a)];
        return l && c.unshift(n.renderDropdown(a)), c;
      }, n.onChange = function(a) {
        n.toggleDropdown(), a !== n.props.month && n.props.onChange(a);
      }, n.toggleDropdown = function() {
        return n.setState({
          dropdownVisible: !n.state.dropdownVisible
        });
      }, n;
    }
    return i.prototype.render = function() {
      var n = this, a = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(this.props.useShortMonthInDropdown ? function(c) {
        return hy(c, n.props.locale);
      } : function(c) {
        return Af(c, n.props.locale);
      }), l;
      switch (this.props.dropdownMode) {
        case "scroll":
          l = this.renderScrollMode(a);
          break;
        case "select":
          l = this.renderSelectMode(a);
          break;
      }
      return B.createElement("div", { className: "react-datepicker__month-dropdown-container react-datepicker__month-dropdown-container--".concat(this.props.dropdownMode) }, l);
    }, i;
  })(N.Component)
), Fv = 5;
function $S(o, i, n) {
  for (var a = [], l = o ?? Kn(n, Fv), c = i ?? Da(n, Fv), d = hn(l), p = hn(c); !pn(d, p); )
    a.push(Le(d)), d = Ea(d, 1);
  return a;
}
var eD = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      return a.renderOptions = function() {
        return a.state.monthYearsList.map(function(l) {
          var c = rf(l), d = Ya(a.props.date, l) && At(a.props.date, l);
          return B.createElement(
            "div",
            { className: d ? "react-datepicker__month-year-option--selected_month-year" : "react-datepicker__month-year-option", key: c, onClick: a.onChange.bind(a, c), "aria-selected": d ? "true" : void 0 },
            d ? B.createElement("span", { className: "react-datepicker__month-year-option--selected" }, "✓") : "",
            $e(l, a.props.dateFormat, a.props.locale)
          );
        });
      }, a.onChange = function(l) {
        return a.props.onChange(l);
      }, a.handleClickOutside = function() {
        a.props.onCancel();
      }, a.state = {
        monthYearsList: $S(a.props.minDate, a.props.maxDate, a.props.date)
      }, a;
    }
    return i.prototype.render = function() {
      var n = vt({
        "react-datepicker__month-year-dropdown": !0,
        "react-datepicker__month-year-dropdown--scrollable": this.props.scrollableMonthYearDropdown
      });
      return B.createElement(dc, { className: n, onClickOutside: this.handleClickOutside }, this.renderOptions());
    }, i;
  })(N.Component)
), Vv = 5, tD = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.state = {
        dropdownVisible: !1
      }, n.renderSelectOptions = function() {
        for (var a, l, c = (a = n.props.minDate) !== null && a !== void 0 ? a : Kn(n.props.date, Vv), d = (l = n.props.maxDate) !== null && l !== void 0 ? l : Da(n.props.date, Vv), p = hn(c), m = hn(d), g = []; !pn(p, m); ) {
          var y = rf(p);
          g.push(B.createElement("option", { key: y, value: y }, $e(p, n.props.dateFormat, n.props.locale))), p = Ea(p, 1);
        }
        return g;
      }, n.onSelectChange = function(a) {
        n.onChange(parseInt(a.target.value));
      }, n.renderSelectMode = function() {
        return B.createElement("select", { value: rf(hn(n.props.date)), className: "react-datepicker__month-year-select", onChange: n.onSelectChange }, n.renderSelectOptions());
      }, n.renderReadView = function(a) {
        var l = $e(n.props.date, n.props.dateFormat, n.props.locale);
        return B.createElement(
          "div",
          { key: "read", style: { visibility: a ? "visible" : "hidden" }, className: "react-datepicker__month-year-read-view", onClick: n.toggleDropdown },
          B.createElement("span", { className: "react-datepicker__month-year-read-view--down-arrow" }),
          B.createElement("span", { className: "react-datepicker__month-year-read-view--selected-month-year" }, l)
        );
      }, n.renderDropdown = function() {
        return B.createElement(eD, Me({ key: "dropdown" }, n.props, { onChange: n.onChange, onCancel: n.toggleDropdown }));
      }, n.renderScrollMode = function() {
        var a = n.state.dropdownVisible, l = [n.renderReadView(!a)];
        return a && l.unshift(n.renderDropdown()), l;
      }, n.onChange = function(a) {
        n.toggleDropdown();
        var l = Le(a);
        Ya(n.props.date, l) && At(n.props.date, l) || n.props.onChange(l);
      }, n.toggleDropdown = function() {
        return n.setState({
          dropdownVisible: !n.state.dropdownVisible
        });
      }, n;
    }
    return i.prototype.render = function() {
      var n;
      switch (this.props.dropdownMode) {
        case "scroll":
          n = this.renderScrollMode();
          break;
        case "select":
          n = this.renderSelectMode();
          break;
      }
      return B.createElement("div", { className: "react-datepicker__month-year-dropdown-container react-datepicker__month-year-dropdown-container--".concat(this.props.dropdownMode) }, n);
    }, i;
  })(N.Component)
), aD = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.state = {
        height: null
      }, n.scrollToTheSelectedTime = function() {
        requestAnimationFrame(function() {
          var a, l, c;
          n.list && (n.list.scrollTop = (c = n.centerLi && i.calcCenterPosition(n.props.monthRef ? n.props.monthRef.clientHeight - ((l = (a = n.header) === null || a === void 0 ? void 0 : a.clientHeight) !== null && l !== void 0 ? l : 0) : n.list.clientHeight, n.centerLi)) !== null && c !== void 0 ? c : 0);
        });
      }, n.handleClick = function(a) {
        var l, c;
        (n.props.minTime || n.props.maxTime) && zv(a, n.props) || (n.props.excludeTimes || n.props.includeTimes || n.props.filterTime) && Rv(a, n.props) || (c = (l = n.props).onChange) === null || c === void 0 || c.call(l, a);
      }, n.isSelectedTime = function(a) {
        var l = Dr(n.props.selected);
        return l && by(l, a);
      }, n.isDisabledTime = function(a) {
        return (n.props.minTime || n.props.maxTime) && zv(a, n.props) || (n.props.excludeTimes || n.props.includeTimes || n.props.filterTime) && Rv(a, n.props);
      }, n.liClasses = function(a) {
        var l, c = [
          "react-datepicker__time-list-item",
          n.props.timeClassName ? n.props.timeClassName(a) : void 0
        ];
        return n.isSelectedTime(a) && c.push("react-datepicker__time-list-item--selected"), n.isDisabledTime(a) && c.push("react-datepicker__time-list-item--disabled"), n.props.injectTimes && (Tt(a) * 3600 + Ct(a) * 60 + Xn(a)) % (((l = n.props.intervals) !== null && l !== void 0 ? l : i.defaultProps.intervals) * 60) !== 0 && c.push("react-datepicker__time-list-item--injected"), c.join(" ");
      }, n.handleOnKeyDown = function(a, l) {
        var c, d;
        a.key === te.Space && (a.preventDefault(), a.key = te.Enter), (a.key === te.ArrowUp || a.key === te.ArrowLeft) && a.target instanceof HTMLElement && a.target.previousSibling && (a.preventDefault(), a.target.previousSibling instanceof HTMLElement && a.target.previousSibling.focus()), (a.key === te.ArrowDown || a.key === te.ArrowRight) && a.target instanceof HTMLElement && a.target.nextSibling && (a.preventDefault(), a.target.nextSibling instanceof HTMLElement && a.target.nextSibling.focus()), a.key === te.Enter && n.handleClick(l), (d = (c = n.props).handleOnKeyDown) === null || d === void 0 || d.call(c, a);
      }, n.renderTimes = function() {
        for (var a, l = [], c = typeof n.props.format == "string" ? n.props.format : "p", d = (a = n.props.intervals) !== null && a !== void 0 ? a : i.defaultProps.intervals, p = Dr(n.props.selected) || Dr(n.props.openToDate) || Le(), m = Ho(p), g = n.props.injectTimes && n.props.injectTimes.sort(function(S, O) {
          return S.getTime() - O.getTime();
        }), y = 60 * VS(p), b = y / d, _ = 0; _ < b; _++) {
          var k = Bo(m, _ * d);
          if (l.push(k), g) {
            var w = FS(m, k, _, d, g);
            l = l.concat(w);
          }
        }
        var D = l.reduce(function(S, O) {
          return O.getTime() <= p.getTime() ? O : S;
        }, l[0]);
        return l.map(function(S) {
          return B.createElement("li", { key: S.valueOf(), onClick: n.handleClick.bind(n, S), className: n.liClasses(S), ref: function(O) {
            S === D && (n.centerLi = O);
          }, onKeyDown: function(O) {
            n.handleOnKeyDown(O, S);
          }, tabIndex: S === D ? 0 : -1, role: "option", "aria-selected": n.isSelectedTime(S) ? "true" : void 0, "aria-disabled": n.isDisabledTime(S) ? "true" : void 0 }, $e(S, c, n.props.locale));
        });
      }, n.renderTimeCaption = function() {
        return n.props.showTimeCaption === !1 ? B.createElement(B.Fragment, null) : B.createElement(
          "div",
          { className: "react-datepicker__header react-datepicker__header--time ".concat(n.props.showTimeSelectOnly ? "react-datepicker__header--time--only" : ""), ref: function(a) {
            n.header = a;
          } },
          B.createElement("div", { className: "react-datepicker-time__header" }, n.props.timeCaption)
        );
      }, n;
    }
    return Object.defineProperty(i, "defaultProps", {
      get: function() {
        return {
          intervals: 30,
          todayButton: null,
          timeCaption: "Time",
          showTimeCaption: !0
        };
      },
      enumerable: !1,
      configurable: !0
    }), i.prototype.componentDidMount = function() {
      this.scrollToTheSelectedTime(), this.observeDatePickerHeightChanges();
    }, i.prototype.componentWillUnmount = function() {
      var n;
      (n = this.resizeObserver) === null || n === void 0 || n.disconnect();
    }, i.prototype.observeDatePickerHeightChanges = function() {
      var n = this, a = this.props.monthRef;
      this.updateContainerHeight(), a && (this.resizeObserver = new ResizeObserver(function() {
        n.updateContainerHeight();
      }), this.resizeObserver.observe(a));
    }, i.prototype.updateContainerHeight = function() {
      if (this.props.monthRef && this.header) {
        var n = this.props.monthRef.clientHeight - this.header.clientHeight;
        this.state.height !== n && this.setState({
          height: n
        });
      }
    }, i.prototype.render = function() {
      var n = this, a, l = this.state.height;
      return B.createElement(
        "div",
        { className: "react-datepicker__time-container ".concat(((a = this.props.todayButton) !== null && a !== void 0 ? a : i.defaultProps.todayButton) ? "react-datepicker__time-container--with-today-button" : "") },
        this.renderTimeCaption(),
        B.createElement(
          "div",
          { className: "react-datepicker__time" },
          B.createElement(
            "div",
            { className: "react-datepicker__time-box" },
            B.createElement("ul", { className: "react-datepicker__time-list", ref: function(c) {
              n.list = c;
            }, style: l ? { height: l } : {}, role: "listbox", "aria-label": this.props.timeCaption }, this.renderTimes())
          )
        )
      );
    }, i.calcCenterPosition = function(n, a) {
      return a.offsetTop - (n / 2 - a.clientHeight / 2);
    }, i;
  })(N.Component)
), Gv = 3, nD = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      return a.YEAR_REFS = qa([], Array(a.props.yearItemNumber), !0).map(function() {
        return N.createRef();
      }), a.isDisabled = function(l) {
        return ga(l, {
          minDate: a.props.minDate,
          maxDate: a.props.maxDate,
          excludeDates: a.props.excludeDates,
          includeDates: a.props.includeDates,
          filterDate: a.props.filterDate
        });
      }, a.isExcluded = function(l) {
        return Rf(l, {
          excludeDates: a.props.excludeDates
        });
      }, a.selectingDate = function() {
        var l;
        return (l = a.props.selectingDate) !== null && l !== void 0 ? l : a.props.preSelection;
      }, a.updateFocusOnPaginate = function(l) {
        var c = function() {
          var d, p;
          (p = (d = a.YEAR_REFS[l]) === null || d === void 0 ? void 0 : d.current) === null || p === void 0 || p.focus();
        };
        window.requestAnimationFrame(c);
      }, a.handleYearClick = function(l, c) {
        a.props.onDayClick && a.props.onDayClick(l, c);
      }, a.handleYearNavigation = function(l, c) {
        var d, p, m, g, y = a.props, b = y.date, _ = y.yearItemNumber;
        if (!(b === void 0 || _ === void 0)) {
          var k = fn(b, _).startPeriod;
          a.isDisabled(c) || a.isExcluded(c) || ((p = (d = a.props).setPreSelection) === null || p === void 0 || p.call(d, c), l - k < 0 ? a.updateFocusOnPaginate(_ - (k - l)) : l - k >= _ ? a.updateFocusOnPaginate(Math.abs(_ - (l - k))) : (g = (m = a.YEAR_REFS[l - k]) === null || m === void 0 ? void 0 : m.current) === null || g === void 0 || g.focus());
        }
      }, a.isSameDay = function(l, c) {
        return Ae(l, c);
      }, a.isCurrentYear = function(l) {
        return l === Ne(Le());
      }, a.isRangeStart = function(l) {
        return a.props.startDate && a.props.endDate && Ya(La(Le(), l), a.props.startDate);
      }, a.isRangeEnd = function(l) {
        return a.props.startDate && a.props.endDate && Ya(La(Le(), l), a.props.endDate);
      }, a.isInRange = function(l) {
        return _s(l, a.props.startDate, a.props.endDate);
      }, a.isInSelectingRange = function(l) {
        var c = a.props, d = c.selectsStart, p = c.selectsEnd, m = c.selectsRange, g = c.startDate, y = c.endDate;
        return !(d || p || m) || !a.selectingDate() ? !1 : d && y ? _s(l, a.selectingDate(), y) : p && g || m && g && !y ? _s(l, g, a.selectingDate()) : !1;
      }, a.isSelectingRangeStart = function(l) {
        var c;
        if (!a.isInSelectingRange(l))
          return !1;
        var d = a.props, p = d.startDate, m = d.selectsStart, g = La(Le(), l);
        return m ? Ya(g, (c = a.selectingDate()) !== null && c !== void 0 ? c : null) : Ya(g, p ?? null);
      }, a.isSelectingRangeEnd = function(l) {
        var c;
        if (!a.isInSelectingRange(l))
          return !1;
        var d = a.props, p = d.endDate, m = d.selectsEnd, g = d.selectsRange, y = La(Le(), l);
        return m || g ? Ya(y, (c = a.selectingDate()) !== null && c !== void 0 ? c : null) : Ya(y, p ?? null);
      }, a.isKeyboardSelected = function(l) {
        if (!(a.props.disabledKeyboardNavigation || a.props.date === void 0 || a.props.preSelection == null)) {
          var c = a.props, d = c.minDate, p = c.maxDate, m = c.excludeDates, g = c.includeDates, y = c.filterDate, b = c.selected, _ = Uo(La(a.props.date, l)), k = (d || p || m || g || y) && zs(l, a.props), w = !!b && Ae(_, Uo(b)), D = Ae(_, Uo(a.props.preSelection));
          return !a.props.inline && !w && D && !k;
        }
      }, a.isSelectedYear = function(l) {
        var c = a.props, d = c.selectsMultiple, p = c.selected, m = c.selectedDates;
        return d ? m?.some(function(g) {
          return l === Ne(g);
        }) : !!p && l === Ne(p);
      }, a.onYearClick = function(l, c) {
        var d = a.props.date;
        d !== void 0 && a.handleYearClick(Uo(La(d, c)), l);
      }, a.onYearKeyDown = function(l, c) {
        var d, p, m = l.key, g = a.props, y = g.date, b = g.yearItemNumber, _ = g.handleOnKeyDown;
        if (m !== te.Tab && l.preventDefault(), !a.props.disabledKeyboardNavigation)
          switch (m) {
            case te.Enter:
              if (a.props.selected == null)
                break;
              a.onYearClick(l, c), (p = (d = a.props).setPreSelection) === null || p === void 0 || p.call(d, a.props.selected);
              break;
            case te.ArrowRight:
              if (a.props.preSelection == null)
                break;
              a.handleYearNavigation(c + 1, Da(a.props.preSelection, 1));
              break;
            case te.ArrowLeft:
              if (a.props.preSelection == null)
                break;
              a.handleYearNavigation(c - 1, Kn(a.props.preSelection, 1));
              break;
            case te.ArrowUp: {
              if (y === void 0 || b === void 0 || a.props.preSelection == null)
                break;
              var k = fn(y, b).startPeriod, w = Gv, D = c - w;
              if (D < k) {
                var S = b % w;
                c >= k && c < k + S ? w = S : w += S, D = c - w;
              }
              a.handleYearNavigation(D, Kn(a.props.preSelection, w));
              break;
            }
            case te.ArrowDown: {
              if (y === void 0 || b === void 0 || a.props.preSelection == null)
                break;
              var O = fn(y, b).endPeriod, w = Gv, D = c + w;
              if (D > O) {
                var S = b % w;
                c <= O && c > O - S ? w = S : w += S, D = c + w;
              }
              a.handleYearNavigation(D, Da(a.props.preSelection, w));
              break;
            }
          }
        _ && _(l);
      }, a.getYearClassNames = function(l) {
        var c = a.props, d = c.date, p = c.disabled, m = c.minDate, g = c.maxDate, y = c.excludeDates, b = c.includeDates, _ = c.filterDate, k = c.yearClassName;
        return vt("react-datepicker__year-text", "react-datepicker__year-".concat(l), d ? k?.(La(d, l)) : void 0, {
          "react-datepicker__year-text--selected": a.isSelectedYear(l),
          "react-datepicker__year-text--disabled": (m || g || y || b || _ || p) && zs(l, a.props),
          "react-datepicker__year-text--keyboard-selected": a.isKeyboardSelected(l),
          "react-datepicker__year-text--range-start": a.isRangeStart(l),
          "react-datepicker__year-text--range-end": a.isRangeEnd(l),
          "react-datepicker__year-text--in-range": a.isInRange(l),
          "react-datepicker__year-text--in-selecting-range": a.isInSelectingRange(l),
          "react-datepicker__year-text--selecting-range-start": a.isSelectingRangeStart(l),
          "react-datepicker__year-text--selecting-range-end": a.isSelectingRangeEnd(l),
          "react-datepicker__year-text--today": a.isCurrentYear(l)
        });
      }, a.getYearTabIndex = function(l) {
        if (a.props.disabledKeyboardNavigation || a.props.preSelection == null)
          return "-1";
        var c = Ne(a.props.preSelection), d = zs(l, a.props);
        return l === c && !d ? "0" : "-1";
      }, a.getYearContent = function(l) {
        return a.props.renderYearContent ? a.props.renderYearContent(l) : l;
      }, a;
    }
    return i.prototype.render = function() {
      var n = this, a = [], l = this.props, c = l.date, d = l.yearItemNumber, p = l.onYearMouseEnter, m = l.onYearMouseLeave;
      if (c === void 0)
        return null;
      for (var g = fn(c, d), y = g.startPeriod, b = g.endPeriod, _ = function(D) {
        a.push(B.createElement("div", { ref: k.YEAR_REFS[D - y], onClick: function(S) {
          n.onYearClick(S, D);
        }, onKeyDown: function(S) {
          yy(S) && (S.preventDefault(), S.key = te.Enter), n.onYearKeyDown(S, D);
        }, tabIndex: Number(k.getYearTabIndex(D)), className: k.getYearClassNames(D), onMouseEnter: k.props.usePointerEvent ? void 0 : function(S) {
          return p(S, D);
        }, onPointerEnter: k.props.usePointerEvent ? function(S) {
          return p(S, D);
        } : void 0, onMouseLeave: k.props.usePointerEvent ? void 0 : function(S) {
          return m(S, D);
        }, onPointerLeave: k.props.usePointerEvent ? function(S) {
          return m(S, D);
        } : void 0, key: D, "aria-current": k.isCurrentYear(D) ? "date" : void 0 }, k.getYearContent(D)));
      }, k = this, w = y; w <= b; w++)
        _(w);
      return B.createElement(
        "div",
        { className: "react-datepicker__year" },
        B.createElement("div", { className: "react-datepicker__year-wrapper", onMouseLeave: this.props.usePointerEvent ? void 0 : this.props.clearSelectingDate, onPointerLeave: this.props.usePointerEvent ? this.props.clearSelectingDate : void 0 }, a)
      );
    }, i;
  })(N.Component)
);
function rD(o, i, n, a) {
  for (var l = [], c = 0; c < 2 * i + 1; c++) {
    var d = o + i - c, p = !0;
    n && (p = Ne(n) <= d), a && p && (p = Ne(a) >= d), p && l.push(d);
  }
  return l;
}
var iD = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      a.yearOptionButtonsRef = {}, a.handleOptionKeyDown = function(p, m) {
        var g;
        switch (m.key) {
          case "Enter":
            m.preventDefault(), a.onChange(p);
            break;
          case "Escape":
            m.preventDefault(), a.props.onCancel();
            break;
          case "ArrowUp":
          case "ArrowDown": {
            m.preventDefault();
            var y = p + (m.key === "ArrowUp" ? 1 : -1);
            a.yearOptionButtonsRef[y] && ((g = a.yearOptionButtonsRef[y]) === null || g === void 0 || g.focus());
            break;
          }
        }
      }, a.renderOptions = function() {
        a.yearOptionButtonsRef = {};
        var p = a.props.year, m = a.state.yearsList.map(function(b) {
          return B.createElement(
            "div",
            { ref: function(_) {
              a.yearOptionButtonsRef[b] = _, b === p && _?.focus();
            }, role: "button", tabIndex: 0, className: p === b ? "react-datepicker__year-option react-datepicker__year-option--selected_year" : "react-datepicker__year-option", key: b, onClick: a.onChange.bind(a, b), onKeyDown: a.handleOptionKeyDown.bind(a, b), "aria-selected": p === b ? "true" : void 0 },
            p === b ? B.createElement("span", { className: "react-datepicker__year-option--selected" }, "✓") : "",
            b
          );
        }), g = a.props.minDate ? Ne(a.props.minDate) : null, y = a.props.maxDate ? Ne(a.props.maxDate) : null;
        return (!y || !a.state.yearsList.find(function(b) {
          return b === y;
        })) && m.unshift(B.createElement(
          "div",
          { className: "react-datepicker__year-option", key: "upcoming", onClick: a.incrementYears },
          B.createElement("a", { className: "react-datepicker__navigation react-datepicker__navigation--years react-datepicker__navigation--years-upcoming" })
        )), (!g || !a.state.yearsList.find(function(b) {
          return b === g;
        })) && m.push(B.createElement(
          "div",
          { className: "react-datepicker__year-option", key: "previous", onClick: a.decrementYears },
          B.createElement("a", { className: "react-datepicker__navigation react-datepicker__navigation--years react-datepicker__navigation--years-previous" })
        )), m;
      }, a.onChange = function(p) {
        a.props.onChange(p);
      }, a.handleClickOutside = function() {
        a.props.onCancel();
      }, a.shiftYears = function(p) {
        var m = a.state.yearsList.map(function(g) {
          return g + p;
        });
        a.setState({
          yearsList: m
        });
      }, a.incrementYears = function() {
        return a.shiftYears(1);
      }, a.decrementYears = function() {
        return a.shiftYears(-1);
      };
      var l = n.yearDropdownItemNumber, c = n.scrollableYearDropdown, d = l || (c ? 10 : 5);
      return a.state = {
        yearsList: rD(a.props.year, d, a.props.minDate, a.props.maxDate)
      }, a.dropdownRef = N.createRef(), a;
    }
    return i.prototype.componentDidMount = function() {
      var n = this.dropdownRef.current;
      if (n) {
        var a = n.children ? Array.from(n.children) : null, l = a ? a.find(function(c) {
          return c.ariaSelected;
        }) : null;
        n.scrollTop = l && l instanceof HTMLElement ? l.offsetTop + (l.clientHeight - n.clientHeight) / 2 : (n.scrollHeight - n.clientHeight) / 2;
      }
    }, i.prototype.render = function() {
      var n = vt({
        "react-datepicker__year-dropdown": !0,
        "react-datepicker__year-dropdown--scrollable": this.props.scrollableYearDropdown
      });
      return B.createElement(dc, { className: n, containerRef: this.dropdownRef, onClickOutside: this.handleClickOutside }, this.renderOptions());
    }, i;
  })(N.Component)
), oD = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.state = {
        dropdownVisible: !1
      }, n.renderSelectOptions = function() {
        for (var a = n.props.minDate ? Ne(n.props.minDate) : 1900, l = n.props.maxDate ? Ne(n.props.maxDate) : 2100, c = [], d = a; d <= l; d++)
          c.push(B.createElement("option", { key: d, value: d }, d));
        return c;
      }, n.onSelectChange = function(a) {
        n.onChange(parseInt(a.target.value));
      }, n.renderSelectMode = function() {
        return B.createElement("select", { value: n.props.year, className: "react-datepicker__year-select", onChange: n.onSelectChange }, n.renderSelectOptions());
      }, n.renderReadView = function(a) {
        return B.createElement(
          "button",
          { key: "read", type: "button", style: { visibility: a ? "visible" : "hidden" }, className: "react-datepicker__year-read-view", onClick: n.toggleDropdown },
          B.createElement("span", { className: "react-datepicker__year-read-view--down-arrow" }),
          B.createElement("span", { className: "react-datepicker__year-read-view--selected-year" }, n.props.year)
        );
      }, n.renderDropdown = function() {
        return B.createElement(iD, Me({ key: "dropdown" }, n.props, { onChange: n.onChange, onCancel: n.toggleDropdown }));
      }, n.renderScrollMode = function() {
        var a = n.state.dropdownVisible, l = [n.renderReadView(!a)];
        return a && l.unshift(n.renderDropdown()), l;
      }, n.onChange = function(a) {
        n.toggleDropdown(), a !== n.props.year && n.props.onChange(a);
      }, n.toggleDropdown = function(a) {
        n.setState({
          dropdownVisible: !n.state.dropdownVisible
        }, function() {
          n.props.adjustDateOnChange && n.handleYearChange(n.props.date, a);
        });
      }, n.handleYearChange = function(a, l) {
        var c;
        (c = n.onSelect) === null || c === void 0 || c.call(n, a, l), n.setOpen();
      }, n.onSelect = function(a, l) {
        var c, d;
        (d = (c = n.props).onSelect) === null || d === void 0 || d.call(c, a, l);
      }, n.setOpen = function() {
        var a, l;
        (l = (a = n.props).setOpen) === null || l === void 0 || l.call(a, !0);
      }, n;
    }
    return i.prototype.render = function() {
      var n;
      switch (this.props.dropdownMode) {
        case "scroll":
          n = this.renderScrollMode();
          break;
        case "select":
          n = this.renderSelectMode();
          break;
      }
      return B.createElement("div", { className: "react-datepicker__year-dropdown-container react-datepicker__year-dropdown-container--".concat(this.props.dropdownMode) }, n);
    }, i;
  })(N.Component)
), lD = [
  "react-datepicker__year-select",
  "react-datepicker__month-select",
  "react-datepicker__month-year-select"
], xy = "react-datepicker-ignore-onclickoutside", sD = function(o) {
  var i = (o.className || "").split(/\s+/);
  return lD.some(function(n) {
    return i.indexOf(n) >= 0;
  });
}, cD = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      return a.monthContainer = void 0, a.handleClickOutside = function(l) {
        a.props.onClickOutside(l);
      }, a.setClickOutsideRef = function() {
        return a.containerRef.current;
      }, a.handleDropdownFocus = function(l) {
        var c, d;
        sD(l.target) && ((d = (c = a.props).onDropdownFocus) === null || d === void 0 || d.call(c, l));
      }, a.getDateInView = function() {
        var l = a.props, c = l.preSelection, d = l.selected, p = l.openToDate, m = gy(a.props), g = vy(a.props), y = Le(), b = p || d || c;
        return b || (m && Ba(y, m) ? m : g && pn(y, g) ? g : y);
      }, a.increaseMonth = function() {
        a.setState(function(l) {
          var c = l.date;
          return {
            date: Ea(c, 1)
          };
        }, function() {
          return a.handleMonthChange(a.state.date);
        });
      }, a.decreaseMonth = function() {
        a.setState(function(l) {
          var c = l.date;
          return {
            date: Tr(c, 1)
          };
        }, function() {
          return a.handleMonthChange(a.state.date);
        });
      }, a.handleDayClick = function(l, c, d) {
        a.props.onSelect(l, c, d), a.props.setPreSelection && a.props.setPreSelection(l);
      }, a.handleDayMouseEnter = function(l) {
        a.setState({ selectingDate: l }), a.props.onDayMouseEnter && a.props.onDayMouseEnter(l);
      }, a.handleMonthMouseLeave = function() {
        a.setState({ selectingDate: void 0 }), a.props.onMonthMouseLeave && a.props.onMonthMouseLeave();
      }, a.handleYearMouseEnter = function(l, c) {
        a.setState({ selectingDate: La(Le(), c) }), a.props.onYearMouseEnter && a.props.onYearMouseEnter(l, c);
      }, a.handleYearMouseLeave = function(l, c) {
        a.props.onYearMouseLeave && a.props.onYearMouseLeave(l, c);
      }, a.handleYearChange = function(l) {
        var c, d, p, m;
        (d = (c = a.props).onYearChange) === null || d === void 0 || d.call(c, l), a.setState({ isRenderAriaLiveMessage: !0 }), a.props.adjustDateOnChange && (a.props.onSelect(l), (m = (p = a.props).setOpen) === null || m === void 0 || m.call(p, !0)), a.props.setPreSelection && a.props.setPreSelection(l);
      }, a.getEnabledPreSelectionDateForMonth = function(l) {
        if (!ga(l, a.props))
          return l;
        for (var c = hn(l), d = jS(l), p = Zw(d, c), m = null, g = 0; g <= p; g++) {
          var y = Sa(c, g);
          if (!ga(y, a.props)) {
            m = y;
            break;
          }
        }
        return m;
      }, a.handleMonthChange = function(l) {
        var c, d, p, m = (c = a.getEnabledPreSelectionDateForMonth(l)) !== null && c !== void 0 ? c : l;
        a.handleCustomMonthChange(m), a.props.adjustDateOnChange && (a.props.onSelect(m), (p = (d = a.props).setOpen) === null || p === void 0 || p.call(d, !0)), a.props.setPreSelection && a.props.setPreSelection(m);
      }, a.handleCustomMonthChange = function(l) {
        var c, d;
        (d = (c = a.props).onMonthChange) === null || d === void 0 || d.call(c, l), a.setState({ isRenderAriaLiveMessage: !0 });
      }, a.handleMonthYearChange = function(l) {
        a.handleYearChange(l), a.handleMonthChange(l);
      }, a.changeYear = function(l) {
        a.setState(function(c) {
          var d = c.date;
          return {
            date: La(d, Number(l))
          };
        }, function() {
          return a.handleYearChange(a.state.date);
        });
      }, a.changeMonth = function(l) {
        a.setState(function(c) {
          var d = c.date;
          return {
            date: na(d, Number(l))
          };
        }, function() {
          var c, d;
          a.handleMonthChange(a.state.date), (d = (c = a.props).onMonthSelectedInChange) === null || d === void 0 || d.call(c, 0);
        });
      }, a.changeMonthYear = function(l) {
        a.setState(function(c) {
          var d = c.date;
          return {
            date: La(na(d, Ft(l)), Ne(l))
          };
        }, function() {
          return a.handleMonthYearChange(a.state.date);
        });
      }, a.header = function(l, c) {
        if (l === void 0 && (l = a.state.date), c === void 0 && (c = 0), !Pt(l))
          return [];
        var d = a.props.disabled, p = Zn(l, a.props.locale, a.props.calendarStartDay), m = [];
        return a.props.showWeekNumbers && m.push(B.createElement(
          "div",
          { key: "W", className: "react-datepicker__day-name ".concat(d ? "react-datepicker__day-name--disabled" : ""), role: "columnheader" },
          B.createElement("span", { className: "react-datepicker__sr-only" }, "Week number"),
          B.createElement("span", { "aria-hidden": "true" }, a.props.weekLabel || "#")
        )), m.concat([0, 1, 2, 3, 4, 5, 6].map(function(g) {
          var y = Sa(p, g), b = a.formatWeekday(y, a.props.locale), _ = $e(y, "EEEE", a.props.locale), k = a.props.weekDayClassName ? a.props.weekDayClassName(y) : void 0;
          if (a.props.renderCustomDayName) {
            var w = a.props.renderCustomDayName({
              day: y,
              shortName: b,
              fullName: _,
              locale: a.props.locale,
              customDayNameCount: c
            });
            return B.createElement("div", { key: g, role: "columnheader", className: vt("react-datepicker__day-name", k, d ? "react-datepicker__day-name--disabled" : "") }, w);
          }
          return B.createElement(
            "div",
            { key: g, role: "columnheader", className: vt("react-datepicker__day-name", k, d ? "react-datepicker__day-name--disabled" : "") },
            B.createElement("span", { className: "react-datepicker__sr-only" }, _),
            B.createElement("span", { "aria-hidden": "true" }, b)
          );
        }));
      }, a.formatWeekday = function(l, c) {
        return a.props.formatWeekDay ? AS(l, a.props.formatWeekDay, c) : a.props.useWeekdaysShort ? zS(l, c) : RS(l, c);
      }, a.decreaseYear = function() {
        a.setState(function(l) {
          var c, d = l.date;
          return {
            date: Kn(d, a.props.showYearPicker ? (c = a.props.yearItemNumber) !== null && c !== void 0 ? c : i.defaultProps.yearItemNumber : 1)
          };
        }, function() {
          return a.handleYearChange(a.state.date);
        });
      }, a.clearSelectingDate = function() {
        a.setState({ selectingDate: void 0 });
      }, a.renderPreviousButton = function() {
        var l, c, d;
        if (!a.props.renderCustomHeader) {
          var p = (l = a.props.monthsShown) !== null && l !== void 0 ? l : i.defaultProps.monthsShown, m = a.props.showPreviousMonths ? p - 1 : 0, g = (c = a.props.monthSelectedIn) !== null && c !== void 0 ? c : m, y = Tr(a.state.date, g), b;
          switch (!0) {
            case a.props.disabled:
              b = !0;
              break;
            case a.props.showMonthYearPicker:
              b = Hv(a.state.date, a.props);
              break;
            case a.props.showYearPicker:
              b = BS(a.state.date, a.props);
              break;
            case a.props.showQuarterYearPicker:
              b = HS(a.state.date, a.props);
              break;
            default:
              b = Lv(y, a.props);
              break;
          }
          if (!(!((d = a.props.forceShowMonthNavigation) !== null && d !== void 0 ? d : i.defaultProps.forceShowMonthNavigation) && !a.props.showDisabledMonthNavigation && b || a.props.showTimeSelectOnly)) {
            var _ = [
              "react-datepicker__navigation-icon",
              "react-datepicker__navigation-icon--previous"
            ], k = [
              "react-datepicker__navigation",
              "react-datepicker__navigation--previous"
            ], w = a.decreaseMonth;
            (a.props.showMonthYearPicker || a.props.showQuarterYearPicker || a.props.showYearPicker) && (w = a.decreaseYear), b && a.props.showDisabledMonthNavigation && (k.push("react-datepicker__navigation--previous--disabled"), w = void 0);
            var D = a.props.showMonthYearPicker || a.props.showQuarterYearPicker || a.props.showYearPicker, S = a.props, O = S.previousMonthButtonLabel, q = O === void 0 ? i.defaultProps.previousMonthButtonLabel : O, L = S.previousYearButtonLabel, P = L === void 0 ? i.defaultProps.previousYearButtonLabel : L, F = a.props, J = F.previousMonthAriaLabel, Z = J === void 0 ? typeof q == "string" ? q : "Previous Month" : J, ie = F.previousYearAriaLabel, ue = ie === void 0 ? typeof P == "string" ? P : "Previous Year" : ie;
            return B.createElement(
              "button",
              { type: "button", className: k.join(" "), onClick: w, onKeyDown: a.props.handleOnKeyDown, "aria-label": D ? ue : Z },
              B.createElement("span", { className: _.join(" ") }, D ? P : q)
            );
          }
        }
      }, a.increaseYear = function() {
        a.setState(function(l) {
          var c, d = l.date;
          return {
            date: Da(d, a.props.showYearPicker ? (c = a.props.yearItemNumber) !== null && c !== void 0 ? c : i.defaultProps.yearItemNumber : 1)
          };
        }, function() {
          return a.handleYearChange(a.state.date);
        });
      }, a.renderNextButton = function() {
        var l;
        if (!a.props.renderCustomHeader) {
          var c;
          switch (!0) {
            case a.props.disabled:
              c = !0;
              break;
            case a.props.showMonthYearPicker:
              c = Uv(a.state.date, a.props);
              break;
            case a.props.showYearPicker:
              c = qS(a.state.date, a.props);
              break;
            case a.props.showQuarterYearPicker:
              c = US(a.state.date, a.props);
              break;
            default:
              c = Yv(a.state.date, a.props);
              break;
          }
          if (!(!((l = a.props.forceShowMonthNavigation) !== null && l !== void 0 ? l : i.defaultProps.forceShowMonthNavigation) && !a.props.showDisabledMonthNavigation && c || a.props.showTimeSelectOnly)) {
            var d = [
              "react-datepicker__navigation",
              "react-datepicker__navigation--next"
            ], p = [
              "react-datepicker__navigation-icon",
              "react-datepicker__navigation-icon--next"
            ];
            a.props.showTimeSelect && d.push("react-datepicker__navigation--next--with-time"), a.props.todayButton && d.push("react-datepicker__navigation--next--with-today-button");
            var m = a.increaseMonth;
            (a.props.showMonthYearPicker || a.props.showQuarterYearPicker || a.props.showYearPicker) && (m = a.increaseYear), c && a.props.showDisabledMonthNavigation && (d.push("react-datepicker__navigation--next--disabled"), m = void 0);
            var g = a.props.showMonthYearPicker || a.props.showQuarterYearPicker || a.props.showYearPicker, y = a.props, b = y.nextMonthButtonLabel, _ = b === void 0 ? i.defaultProps.nextMonthButtonLabel : b, k = y.nextYearButtonLabel, w = k === void 0 ? i.defaultProps.nextYearButtonLabel : k, D = a.props, S = D.nextMonthAriaLabel, O = S === void 0 ? typeof _ == "string" ? _ : "Next Month" : S, q = D.nextYearAriaLabel, L = q === void 0 ? typeof w == "string" ? w : "Next Year" : q;
            return B.createElement(
              "button",
              { type: "button", className: d.join(" "), onClick: m, onKeyDown: a.props.handleOnKeyDown, "aria-label": g ? L : O },
              B.createElement("span", { className: p.join(" ") }, g ? w : _)
            );
          }
        }
      }, a.renderCurrentMonth = function(l) {
        l === void 0 && (l = a.state.date);
        var c = ["react-datepicker__current-month"];
        return a.props.showYearDropdown && c.push("react-datepicker__current-month--hasYearDropdown"), a.props.showMonthDropdown && c.push("react-datepicker__current-month--hasMonthDropdown"), a.props.showMonthYearDropdown && c.push("react-datepicker__current-month--hasMonthYearDropdown"), B.createElement("h2", { className: c.join(" ") }, Pt(l) ? $e(l, a.props.dateFormat, a.props.locale) : "");
      }, a.renderYearDropdown = function(l) {
        if (l === void 0 && (l = !1), !(!a.props.showYearDropdown || l))
          return B.createElement(oD, Me({}, i.defaultProps, a.props, { date: a.state.date, onChange: a.changeYear, year: Ne(a.state.date) }));
      }, a.renderMonthDropdown = function(l) {
        if (l === void 0 && (l = !1), !(!a.props.showMonthDropdown || l))
          return B.createElement(JS, Me({}, i.defaultProps, a.props, { month: Ft(a.state.date), onChange: a.changeMonth }));
      }, a.renderMonthYearDropdown = function(l) {
        if (l === void 0 && (l = !1), !(!a.props.showMonthYearDropdown || l))
          return B.createElement(tD, Me({}, i.defaultProps, a.props, { date: a.state.date, onChange: a.changeMonthYear }));
      }, a.handleTodayButtonClick = function(l) {
        a.props.onSelect(Ov(), l), a.props.setPreSelection && a.props.setPreSelection(Ov());
      }, a.renderTodayButton = function() {
        if (!(!a.props.todayButton || a.props.showTimeSelectOnly))
          return B.createElement("div", { className: "react-datepicker__today-button", onClick: a.handleTodayButtonClick }, a.props.todayButton);
      }, a.renderDayNamesHeader = function(l, c) {
        return c === void 0 && (c = 0), B.createElement("div", { className: "react-datepicker__day-names", role: "row" }, a.header(l, c));
      }, a.renderDefaultHeader = function(l) {
        var c = l.monthDate, d = l.i, p = B.createElement(
          "div",
          { className: vt("react-datepicker__header", {
            "react-datepicker__header--has-time-select": a.props.showTimeSelect,
            "react-datepicker__header--middle": a.props.monthHeaderPosition === "middle",
            "react-datepicker__header--bottom": a.props.monthHeaderPosition === "bottom"
          }) },
          a.renderCurrentMonth(c),
          B.createElement(
            "div",
            { className: "react-datepicker__header__dropdown react-datepicker__header__dropdown--".concat(a.props.dropdownMode), onFocus: a.handleDropdownFocus },
            a.renderMonthDropdown(d !== 0),
            a.renderMonthYearDropdown(d !== 0),
            a.renderYearDropdown(d !== 0)
          )
        );
        return a.props.monthHeaderPosition === "top" ? p : B.createElement(
          "div",
          { className: "react-datepicker__header-wrapper" },
          a.renderPreviousButton() || null,
          a.renderNextButton() || null,
          p
        );
      }, a.renderCustomHeader = function(l) {
        var c, d, p = l.monthDate, m = l.i;
        if (a.props.showTimeSelect && !a.state.monthContainer || a.props.showTimeSelectOnly)
          return null;
        var g = a.props, y = g.showYearPicker, b = g.yearItemNumber, _;
        if (y) {
          var k = fn(p, b), w = k.startPeriod, D = k.endPeriod;
          _ = {
            startYear: w,
            endYear: D
          };
        }
        var S = Lv(a.state.date, a.props), O = Yv(a.state.date, a.props), q = Hv(a.state.date, a.props), L = Uv(a.state.date, a.props);
        return B.createElement("div", { className: "react-datepicker__header react-datepicker__header--custom", onFocus: a.props.onDropdownFocus }, (d = (c = a.props).renderCustomHeader) === null || d === void 0 ? void 0 : d.call(c, Me(Me(Me({}, a.state), y && { visibleYearsRange: _ }), { customHeaderCount: m, monthDate: p, changeMonth: a.changeMonth, changeYear: a.changeYear, decreaseMonth: a.decreaseMonth, increaseMonth: a.increaseMonth, decreaseYear: a.decreaseYear, increaseYear: a.increaseYear, prevMonthButtonDisabled: S, nextMonthButtonDisabled: O, prevYearButtonDisabled: q, nextYearButtonDisabled: L })));
      }, a.renderYearHeader = function(l) {
        var c = l.monthDate, d = a.props, p = d.showYearPicker, m = d.yearItemNumber, g = m === void 0 ? i.defaultProps.yearItemNumber : m, y = fn(c, g), b = y.startPeriod, _ = y.endPeriod;
        return B.createElement("div", { className: "react-datepicker__header react-datepicker-year-header" }, p ? "".concat(b, " - ").concat(_) : Ne(c));
      }, a.renderHeader = function(l) {
        var c = l.monthDate, d = l.i, p = d === void 0 ? 0 : d, m = { monthDate: c, i: p };
        switch (!0) {
          case a.props.renderCustomHeader !== void 0:
            return a.renderCustomHeader(m);
          case (a.props.showMonthYearPicker || a.props.showQuarterYearPicker || a.props.showYearPicker):
            return a.renderYearHeader(m);
          default:
            return a.renderDefaultHeader(m);
        }
      }, a.renderMonths = function() {
        var l, c;
        if (!(a.props.showTimeSelectOnly || a.props.showYearPicker)) {
          for (var d = [], p = (l = a.props.monthsShown) !== null && l !== void 0 ? l : i.defaultProps.monthsShown, m = a.props.showPreviousMonths ? p - 1 : 0, g = a.props.showMonthYearPicker || a.props.showQuarterYearPicker ? Da(a.state.date, m) : Tr(a.state.date, m), y = (c = a.props.monthSelectedIn) !== null && c !== void 0 ? c : m, b = 0; b < p; ++b) {
            var _ = b - y + m, k = a.props.showMonthYearPicker || a.props.showQuarterYearPicker ? Da(g, _) : Ea(g, _), w = "month-".concat(b), D = b < p - 1, S = b > 0;
            d.push(B.createElement(
              "div",
              { key: w, ref: function(O) {
                a.monthContainer = O ?? void 0;
              }, className: "react-datepicker__month-container" },
              a.props.monthHeaderPosition === "top" && a.renderHeader({ monthDate: k, i: b }),
              B.createElement(WS, Me({}, i.defaultProps, a.props, { containerRef: a.containerRef, ariaLabelPrefix: a.props.monthAriaLabelPrefix, day: k, onDayClick: a.handleDayClick, handleOnKeyDown: a.props.handleOnDayKeyDown, handleOnMonthKeyDown: a.props.handleOnKeyDown, onDayMouseEnter: a.handleDayMouseEnter, onMouseLeave: a.handleMonthMouseLeave, orderInDisplay: b, selectingDate: a.state.selectingDate, monthShowsDuplicateDaysEnd: D, monthShowsDuplicateDaysStart: S, dayNamesHeader: a.renderDayNamesHeader(k, b), monthHeader: a.props.monthHeaderPosition === "middle" ? a.renderHeader({ monthDate: k, i: b }) : void 0, monthFooter: a.props.monthHeaderPosition === "bottom" ? a.renderHeader({ monthDate: k, i: b }) : void 0 }))
            ));
          }
          return d;
        }
      }, a.renderYears = function() {
        if (!a.props.showTimeSelectOnly && a.props.showYearPicker)
          return B.createElement(
            "div",
            { className: "react-datepicker__year--container" },
            a.renderHeader({ monthDate: a.state.date }),
            B.createElement(nD, Me({}, i.defaultProps, a.props, { selectingDate: a.state.selectingDate, date: a.state.date, onDayClick: a.handleDayClick, clearSelectingDate: a.clearSelectingDate, onYearMouseEnter: a.handleYearMouseEnter, onYearMouseLeave: a.handleYearMouseLeave }))
          );
      }, a.renderTimeSection = function() {
        if (a.props.showTimeSelect && (a.state.monthContainer || a.props.showTimeSelectOnly))
          return B.createElement(aD, Me({}, i.defaultProps, a.props, { onChange: a.props.onTimeChange, format: a.props.timeFormat, intervals: a.props.timeIntervals, monthRef: a.state.monthContainer }));
      }, a.renderInputTimeSection = function() {
        var l, c;
        if (a.props.showTimeInput) {
          if (a.props.selectsRange) {
            var d = a.props, p = d.startDate, m = d.endDate, g = p ? new Date(p) : void 0, y = g && Pt(g) && !!p, b = y ? "".concat(wi(g.getHours()), ":").concat(wi(g.getMinutes())) : "", _ = m ? new Date(m) : void 0, k = _ && Pt(_) && !!m, w = k ? "".concat(wi(_.getHours()), ":").concat(wi(_.getMinutes())) : "";
            return B.createElement(
              B.Fragment,
              null,
              B.createElement(qd, Me({}, i.defaultProps, a.props, { date: g, timeString: b, onChange: function(q) {
                var L, P;
                (P = (L = a.props).onTimeChange) === null || P === void 0 || P.call(L, q, "start");
              }, timeInputLabel: ((l = a.props.timeInputLabel) !== null && l !== void 0 ? l : "Time") + " (Start)" })),
              B.createElement(qd, Me({}, i.defaultProps, a.props, { date: _, timeString: w, onChange: function(q) {
                var L, P;
                (P = (L = a.props).onTimeChange) === null || P === void 0 || P.call(L, q, "end");
              }, timeInputLabel: ((c = a.props.timeInputLabel) !== null && c !== void 0 ? c : "Time") + " (End)" }))
            );
          }
          var D = a.props.selected ? new Date(a.props.selected) : void 0, S = D && Pt(D) && !!a.props.selected, O = S ? "".concat(wi(D.getHours()), ":").concat(wi(D.getMinutes())) : "";
          return B.createElement(qd, Me({}, i.defaultProps, a.props, { date: D, timeString: O, onChange: function(q) {
            var L, P;
            (P = (L = a.props).onTimeChange) === null || P === void 0 || P.call(L, q);
          } }));
        }
      }, a.renderAriaLiveRegion = function() {
        var l;
        if (!Pt(a.state.date))
          return B.createElement("span", { role: "alert", "aria-live": "polite", className: "react-datepicker__aria-live" });
        var c = fn(a.state.date, (l = a.props.yearItemNumber) !== null && l !== void 0 ? l : i.defaultProps.yearItemNumber), d = c.startPeriod, p = c.endPeriod, m;
        return a.props.showYearPicker ? m = "".concat(d, " - ").concat(p) : a.props.showMonthYearPicker || a.props.showQuarterYearPicker ? m = Ne(a.state.date) : m = "".concat(Af(Ft(a.state.date), a.props.locale), " ").concat(Ne(a.state.date)), B.createElement("span", { role: "alert", "aria-live": "polite", className: "react-datepicker__aria-live" }, a.state.isRenderAriaLiveMessage && m);
      }, a.renderChildren = function() {
        if (a.props.children)
          return B.createElement("div", { className: "react-datepicker__children-container" }, a.props.children);
      }, a.containerRef = N.createRef(), a.state = {
        date: a.getDateInView(),
        selectingDate: void 0,
        monthContainer: void 0,
        isRenderAriaLiveMessage: !1
      }, a;
    }
    return Object.defineProperty(i, "defaultProps", {
      get: function() {
        return {
          monthsShown: 1,
          forceShowMonthNavigation: !1,
          outsideClickIgnoreClass: xy,
          timeCaption: "Time",
          previousYearButtonLabel: "Previous Year",
          nextYearButtonLabel: "Next Year",
          previousMonthButtonLabel: "Previous Month",
          nextMonthButtonLabel: "Next Month",
          yearItemNumber: Io,
          monthHeaderPosition: "top"
        };
      },
      enumerable: !1,
      configurable: !0
    }), i.prototype.componentDidMount = function() {
      var n = this;
      this.props.showTimeSelect && (this.assignMonthContainer = (function() {
        n.setState({ monthContainer: n.monthContainer });
      })());
    }, i.prototype.componentDidUpdate = function(n) {
      var a = this;
      if (this.props.preSelection && Pt(this.props.preSelection) && (!Ae(this.props.preSelection, n.preSelection) || this.props.monthSelectedIn !== n.monthSelectedIn)) {
        var l = !At(this.state.date, this.props.preSelection);
        this.setState({
          date: this.props.preSelection
        }, function() {
          return l && a.handleCustomMonthChange(a.state.date);
        });
      } else this.props.openToDate && !Ae(this.props.openToDate, n.openToDate) && this.setState({
        date: this.props.openToDate
      });
    }, i.prototype.render = function() {
      var n = this.props.container || SS;
      return B.createElement(
        dc,
        { onClickOutside: this.handleClickOutside, style: { display: "contents" }, ignoreClass: this.props.outsideClickIgnoreClass },
        B.createElement(
          "div",
          { style: { display: "contents" }, ref: this.containerRef },
          B.createElement(
            n,
            { className: vt("react-datepicker", this.props.className, {
              "react-datepicker--time-only": this.props.showTimeSelectOnly
            }), showTime: this.props.showTimeSelect || this.props.showTimeInput, showTimeSelectOnly: this.props.showTimeSelectOnly, inline: this.props.inline },
            this.renderAriaLiveRegion(),
            this.props.monthHeaderPosition === "top" && this.renderPreviousButton(),
            this.props.monthHeaderPosition === "top" && this.renderNextButton(),
            this.renderMonths(),
            this.renderYears(),
            this.renderTodayButton(),
            this.renderTimeSection(),
            this.renderInputTimeSection(),
            this.renderChildren()
          )
        )
      );
    }, i;
  })(N.Component)
), uD = function(o) {
  var i = o.icon, n = o.className, a = n === void 0 ? "" : n, l = o.onClick, c = "react-datepicker__calendar-icon";
  if (typeof i == "string")
    return B.createElement("i", { className: "".concat(c, " ").concat(i, " ").concat(a), "aria-hidden": "true", onClick: l });
  if (B.isValidElement(i)) {
    var d = i;
    return B.cloneElement(d, {
      className: "".concat(d.props.className || "", " ").concat(c, " ").concat(a),
      onClick: function(p) {
        typeof d.props.onClick == "function" && d.props.onClick(p), typeof l == "function" && l(p);
      }
    });
  }
  return B.createElement(
    "svg",
    { className: "".concat(c, " ").concat(a), xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512", onClick: l },
    B.createElement("path", { d: "M96 32V64H48C21.5 64 0 85.5 0 112v48H448V112c0-26.5-21.5-48-48-48H352V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V64H160V32c0-17.7-14.3-32-32-32S96 14.3 96 32zM448 192H0V464c0 26.5 21.5 48 48 48H400c26.5 0 48-21.5 48-48V192z" })
  );
}, wy = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      return a.portalRoot = null, a.el = document.createElement("div"), a;
    }
    return i.prototype.componentDidMount = function() {
      this.portalRoot = (this.props.portalHost || document).getElementById(this.props.portalId), this.portalRoot || (this.portalRoot = document.createElement("div"), this.portalRoot.setAttribute("id", this.props.portalId), (this.props.portalHost || document.body).appendChild(this.portalRoot)), this.portalRoot.appendChild(this.el);
    }, i.prototype.componentWillUnmount = function() {
      this.portalRoot && this.portalRoot.removeChild(this.el);
    }, i.prototype.render = function() {
      return O2.createPortal(this.props.children, this.el);
    }, i;
  })(N.Component)
), dD = "[tabindex], a, button, input, select, textarea", fD = function(o) {
  return (o instanceof HTMLAnchorElement || !o.disabled) && o.tabIndex !== -1;
}, _y = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      return a.getTabChildren = function() {
        var l;
        return Array.prototype.slice.call((l = a.tabLoopRef.current) === null || l === void 0 ? void 0 : l.querySelectorAll(dD), 1, -1).filter(fD);
      }, a.handleFocusStart = function() {
        var l = a.getTabChildren();
        l && l.length > 1 && l[l.length - 1].focus();
      }, a.handleFocusEnd = function() {
        var l = a.getTabChildren();
        l && l.length > 1 && l[0].focus();
      }, a.tabLoopRef = N.createRef(), a;
    }
    return i.prototype.render = function() {
      var n;
      return ((n = this.props.enableTabLoop) !== null && n !== void 0 ? n : i.defaultProps.enableTabLoop) ? B.createElement(
        "div",
        { className: "react-datepicker__tab-loop", ref: this.tabLoopRef },
        B.createElement("div", { className: "react-datepicker__tab-loop__start", tabIndex: 0, onFocus: this.handleFocusStart }),
        this.props.children,
        B.createElement("div", { className: "react-datepicker__tab-loop__end", tabIndex: 0, onFocus: this.handleFocusEnd })
      ) : this.props.children;
    }, i.defaultProps = {
      enableTabLoop: !0
    }, i;
  })(N.Component)
);
function pD(o) {
  function i(n) {
    var a, l = typeof n.hidePopper == "boolean" ? n.hidePopper : !0, c = N.useRef(null), d = kS(Me({ open: !l, whileElementsMounted: tS, placement: n.popperPlacement, middleware: qa([
      uS({ padding: 15 }),
      cS(10),
      // eslint-disable-next-line react-hooks/refs -- Floating UI requires refs to be passed during render
      dS({ element: c })
    ], (a = n.popperModifiers) !== null && a !== void 0 ? a : [], !0) }, n.popperProps)), p = Me(Me({}, n), { hidePopper: l, popperProps: Me(Me({}, d), { arrowRef: c }) });
    return B.createElement(o, Me({}, p));
  }
  return i.displayName = "withFloating(".concat(o.displayName || o.name || "Component", ")"), i;
}
var hD = function(o) {
  var i = o.className, n = o.wrapperClassName, a = o.hidePopper, l = a === void 0 ? !0 : a, c = o.popperComponent, d = o.targetComponent, p = o.enableTabLoop, m = o.popperOnKeyDown, g = o.portalId, y = o.portalHost, b = o.popperProps, _ = o.showArrow, k = o.popperTargetRef, w = o.monthHeaderPosition;
  N.useEffect(function() {
    k?.current && b.refs.setPositionReference(k.current);
  }, [k, b.refs]);
  var D = void 0;
  if (!l) {
    var S = vt("react-datepicker-popper", !_ && "react-datepicker-popper-offset", w === "middle" && "react-datepicker-popper--header-middle", w === "bottom" && "react-datepicker-popper--header-bottom", i);
    D = B.createElement(
      _y,
      { enableTabLoop: p },
      B.createElement(
        "div",
        { ref: b.refs.setFloating, style: b.floatingStyles, className: S, "data-placement": b.placement, onKeyDown: m },
        c,
        _ && B.createElement(gS, { ref: b.arrowRef, context: b.context, fill: "currentColor", strokeWidth: 1, height: 8, width: 16, style: { transform: "translateY(-1px)" }, className: "react-datepicker__triangle" })
      )
    );
  }
  o.popperContainer && (D = N.createElement(o.popperContainer, {}, D)), g && !l && (D = B.createElement(wy, { portalId: g, portalHost: y }, D));
  var O = vt("react-datepicker-wrapper", n);
  return B.createElement(
    B.Fragment,
    null,
    B.createElement("div", { ref: b.refs.setReference, className: O }, d),
    D
  );
}, mD = pD(hD);
function Xv(o, i) {
  return o && i ? Ft(o) !== Ft(i) || Ne(o) !== Ne(i) : o !== i;
}
var Pd = "Date input not valid.", cf = (
  /** @class */
  (function(o) {
    Dt(i, o);
    function i(n) {
      var a = o.call(this, n) || this;
      return a.calendar = null, a.input = null, a.getPreSelection = function() {
        var l = a.props.timeZone, c = a.props.openToDate ? a.props.openToDate : a.props.selectsEnd && a.props.startDate ? a.props.startDate : a.props.selectsStart && a.props.endDate ? a.props.endDate : Le();
        return l ? Cv(c, l) : c;
      }, a.modifyHolidays = function() {
        var l;
        return (l = a.props.holidays) === null || l === void 0 ? void 0 : l.reduce(function(c, d) {
          var p = yr(d.date, "yyyy-MM-dd", void 0, !1);
          return p ? qa(qa([], c, !0), [Me(Me({}, d), { date: p })], !1) : c;
        }, []);
      }, a.calcInitialState = function() {
        var l = a.props.timeZone, c = a.getPreSelection(), d = gy(a.props), p = vy(a.props), m = d && Ba(c, Ho(d)) ? d : p && pn(c, jv(p)) ? p : c, g = a.props.selectsRange ? a.props.startDate : a.props.selected;
        return g && l && (g = Cv(g, l)), {
          open: a.props.startOpen || !1,
          preventFocus: !1,
          inputValue: null,
          preSelection: g ?? m,
          // transforming highlighted days (perhaps nested array)
          // to flat Map for faster access in day.jsx
          highlightDates: Bv(a.props.highlightDates),
          focused: !1,
          // used to focus day in inline version after month has changed, but not on
          // initial render
          shouldFocusDayInline: !1,
          isRenderAriaLiveMessage: !1,
          wasHidden: !1
        };
      }, a.getInputValue = function() {
        var l, c = a.props, d = c.locale, p = c.startDate, m = c.endDate, g = c.rangeSeparator, y = c.selected, b = c.selectedDates, _ = c.selectsMultiple, k = c.selectsRange, w = c.formatMultipleDates, D = c.value, S = (l = a.props.dateFormat) !== null && l !== void 0 ? l : i.defaultProps.dateFormat, O = a.state.inputValue;
        if (typeof D == "string")
          return D;
        if (typeof O == "string")
          return O;
        if (k)
          return MS(p, m, {
            dateFormat: S,
            locale: d,
            rangeSeparator: g
          });
        if (_) {
          if (w) {
            var q = function(L) {
              return Qt(L, { dateFormat: S, locale: d });
            };
            return w(b ?? [], q);
          }
          return TS(b ?? [], {
            dateFormat: S,
            locale: d
          });
        }
        return Qt(y, {
          dateFormat: S,
          locale: d
        });
      }, a.resetHiddenStatus = function() {
        a.setState(Me(Me({}, a.state), { wasHidden: !1 }));
      }, a.setHiddenStatus = function() {
        a.setState(Me(Me({}, a.state), { wasHidden: !0 }));
      }, a.setHiddenStateOnVisibilityHidden = function() {
        document.visibilityState === "hidden" && a.setHiddenStatus();
      }, a.clearPreventFocusTimeout = function() {
        a.preventFocusTimeout && clearTimeout(a.preventFocusTimeout);
      }, a.setFocus = function() {
        var l, c;
        (c = (l = a.input) === null || l === void 0 ? void 0 : l.focus) === null || c === void 0 || c.call(l, { preventScroll: !0 });
      }, a.setBlur = function() {
        var l, c;
        (c = (l = a.input) === null || l === void 0 ? void 0 : l.blur) === null || c === void 0 || c.call(l), a.cancelFocusInput();
      }, a.deferBlur = function() {
        requestAnimationFrame(function() {
          a.setBlur();
        });
      }, a.setOpen = function(l, c) {
        c === void 0 && (c = !1), a.setState({
          open: l,
          preSelection: l && a.state.open ? a.state.preSelection : a.calcInitialState().preSelection,
          lastPreSelectChange: Fd
        }, function() {
          l || a.setState(function(d) {
            return {
              focused: c ? d.focused : !1
            };
          }, function() {
            !c && a.deferBlur(), a.setState({ inputValue: null });
          });
        });
      }, a.inputOk = function() {
        return Qa(a.state.preSelection);
      }, a.isCalendarOpen = function() {
        return a.props.open === void 0 ? a.state.open && !a.props.disabled && !a.props.readOnly : a.props.open;
      }, a.handleFocus = function(l) {
        var c, d, p = a.state.wasHidden, m = p ? a.state.open : !0;
        p && a.resetHiddenStatus(), a.state.preventFocus || ((d = (c = a.props).onFocus) === null || d === void 0 || d.call(c, l), m && !a.props.preventOpenOnFocus && !a.props.readOnly && a.setOpen(!0)), a.setState({ focused: !0 });
      }, a.sendFocusBackToInput = function() {
        a.preventFocusTimeout && a.clearPreventFocusTimeout(), a.setState({ preventFocus: !0 }, function() {
          a.preventFocusTimeout = setTimeout(function() {
            a.setFocus(), a.setState({ preventFocus: !1 });
          });
        });
      }, a.cancelFocusInput = function() {
        clearTimeout(a.inputFocusTimeout), a.inputFocusTimeout = void 0;
      }, a.deferFocusInput = function() {
        a.cancelFocusInput(), a.inputFocusTimeout = setTimeout(function() {
          return a.setFocus();
        }, 1);
      }, a.handleDropdownFocus = function() {
        a.cancelFocusInput();
      }, a.resetInputValue = function() {
        a.setState(Me(Me({}, a.state), { inputValue: null }));
      }, a.handleBlur = function(l) {
        var c, d;
        (!a.state.open || a.props.withPortal || a.props.showTimeInput) && ((d = (c = a.props).onBlur) === null || d === void 0 || d.call(c, l));
        var p = a.state.inputValue;
        if (typeof p == "string" && p.length > 0) {
          var m = /[a-zA-Z0-9]/.test(p);
          !m && a.props.selected && a.setSelected(null, void 0, !0);
        }
        a.resetInputValue(), a.state.open && a.props.open === !1 && a.setOpen(!1), a.setState({ focused: !1 });
      }, a.handleCalendarClickOutside = function(l) {
        var c, d;
        (d = (c = a.props).onClickOutside) === null || d === void 0 || d.call(c, l), !a.props.inline && !l.defaultPrevented && a.setOpen(!1), a.props.withPortal && l.preventDefault();
      }, a.handleChange = function() {
        for (var l, c, d, p, m, g, y, b, _ = [], k = 0; k < arguments.length; k++)
          _[k] = arguments[k];
        var w = _[0];
        if (!(a.props.onChangeRaw && (a.props.onChangeRaw.apply(a, _), !w || typeof w.isDefaultPrevented != "function" || w.isDefaultPrevented()))) {
          a.setState({
            inputValue: w?.target instanceof HTMLInputElement ? w.target.value : null,
            lastPreSelectChange: gD
          });
          var D = a.props, S = D.selectsRange, O = D.startDate, q = D.endDate, L = (l = a.props.dateFormat) !== null && l !== void 0 ? l : i.defaultProps.dateFormat, P = (c = a.props.strictParsing) !== null && c !== void 0 ? c : i.defaultProps.strictParsing, F = w?.target instanceof HTMLInputElement ? w.target.value : "";
          if (S) {
            var J = a.props.rangeSeparator, Z = J.trim(), ie = F.split(L.includes(Z) ? J : Z, 2).map(function(Q) {
              return Q.trim();
            }), ue = ie[0], de = ie[1], ne = yr(ue ?? "", L, a.props.locale, P), $ = ne ? yr(de ?? "", L, a.props.locale, P) : null, ae = ((d = Dr(O)) === null || d === void 0 ? void 0 : d.getTime()) !== ne?.getTime(), le = ((p = Dr(q)) === null || p === void 0 ? void 0 : p.getTime()) !== $?.getTime();
            if (!ae && !le || ne && ga(ne, a.props) || $ && ga($, a.props))
              return;
            ne && a.setState({ preSelection: ne }), (g = (m = a.props).onChange) === null || g === void 0 || g.call(m, [ne, $], w);
          } else {
            var fe = yr(F, L, a.props.locale, P, (y = a.props.selected) !== null && y !== void 0 ? y : void 0);
            if (fe || !F)
              a.setSelected(fe, w, !0);
            else if (!a.props.inline) {
              var j = ES(F, (b = a.state.preSelection) !== null && b !== void 0 ? b : void 0);
              j && (!a.props.minDate || !Ba(j, a.props.minDate)) && (!a.props.maxDate || !pn(j, a.props.maxDate)) && a.setState({ preSelection: j });
            }
          }
        }
      }, a.handleSelect = function(l, c, d) {
        var p;
        if (!a.props.readOnly) {
          var m = a.props, g = m.selectsRange, y = m.startDate, b = m.endDate, _ = m.locale, k = m.swapRange, w = (p = a.props.dateFormat) !== null && p !== void 0 ? p : i.defaultProps.dateFormat, D = !g || y && !b && (k || !Bd(l, y));
          if (a.props.shouldCloseOnSelect && !a.props.showTimeSelect && D && a.sendFocusBackToInput(), a.props.onChangeRaw) {
            var S = Qt(l, {
              dateFormat: w,
              locale: _
            });
            a.props.onChangeRaw(c, { date: l, formattedDate: S });
          }
          a.setSelected(l, c, !1, d), a.props.showDateSelect && a.setState({ isRenderAriaLiveMessage: !0 }), !a.props.shouldCloseOnSelect || a.props.showTimeSelect ? a.setPreSelection(l) : D && a.setOpen(!1);
        }
      }, a.setSelected = function(l, c, d, p) {
        var m, g, y = a.props.timeZone, b = l;
        if (b && y && (b = un(b, y)), a.props.showYearPicker) {
          if (b !== null && zs(Ne(b), a.props))
            return;
        } else if (a.props.showMonthYearPicker) {
          if (b !== null && my(b, a.props))
            return;
        } else if (b !== null && ga(b, a.props))
          return;
        var _ = a.props, k = _.onChange, w = _.selectsRange, D = _.startDate, S = _.endDate, O = _.selectsMultiple, q = _.selectedDates, L = _.minTime, P = _.swapRange;
        if (!Er(a.props.selected, b) || a.props.allowSameDay || w || O)
          if (b !== null && (a.props.selected && (!d || !a.props.showTimeSelect && !a.props.showTimeSelectOnly && !a.props.showTimeInput) && (b = dn(b, {
            hour: Tt(a.props.selected),
            minute: Ct(a.props.selected),
            second: Xn(a.props.selected)
          })), !d && (a.props.showTimeSelect || a.props.showTimeSelectOnly) && L && (b = dn(b, {
            hour: L.getHours(),
            minute: L.getMinutes(),
            second: L.getSeconds()
          })), a.props.inline || a.setState({
            preSelection: b
          }), a.props.focusSelectedMonth || a.setState({ monthSelectedIn: p })), w) {
            var F = k, J = !D && !S, Z = D && !S, ie = !D && !!S, ue = D && S;
            J ? F?.([b, null], c) : Z ? b === null ? F?.([null, null], c) : Bd(b, D) ? F?.(P ? [b, D] : [b, null], c) : F?.([D, b], c) : ie && (b && Bd(b, S) ? F?.([b, S], c) : F?.([b, null], c)), ue && F?.([b, null], c);
          } else if (O) {
            var de = k;
            if (b !== null)
              if (!q?.length)
                de?.([b], c);
              else {
                var ne = q.some(function(ae) {
                  return Ae(ae, b);
                });
                if (ne) {
                  var $ = q.filter(function(ae) {
                    return !Ae(ae, b);
                  });
                  de?.($, c);
                } else
                  de?.(qa(qa([], q, !0), [b], !1), c);
              }
          } else
            k?.(b, c);
        d || ((g = (m = a.props).onSelect) === null || g === void 0 || g.call(m, b, c), a.setState({ inputValue: null }));
      }, a.setPreSelection = function(l) {
        if (!a.props.readOnly) {
          var c = Qa(a.props.minDate), d = Qa(a.props.maxDate), p = !0;
          if (l) {
            var m = Ho(l);
            if (c && d)
              p = _r(l, a.props.minDate, a.props.maxDate);
            else if (c) {
              var g = Ho(a.props.minDate);
              p = pn(l, g) || Er(m, g);
            } else if (d) {
              var y = jv(a.props.maxDate);
              p = Ba(l, y) || Er(m, y);
            }
          }
          p && a.setState({
            preSelection: l
          });
        }
      }, a.toggleCalendar = function() {
        a.setOpen(!a.state.open);
      }, a.handleTimeChange = function(l, c) {
        var d, p;
        if (!a.props.selectsMultiple) {
          var m = a.props, g = m.selectsRange, y = m.startDate, b = m.endDate, _ = m.onChange, k = m.timeZone;
          if (g) {
            var w = _;
            if (c === "start") {
              if (y) {
                var D = dn(y, {
                  hour: Tt(l),
                  minute: Ct(l)
                });
                a.setState({
                  preSelection: D
                }), k && (D = un(D, k)), w?.([
                  D,
                  b ? k ? un(b, k) : b : null
                ], void 0);
              }
            } else if (c === "end") {
              if (b) {
                var S = dn(b, {
                  hour: Tt(l),
                  minute: Ct(l)
                });
                a.setState({
                  preSelection: S
                }), k && (S = un(S, k)), w?.([
                  y ? k ? un(y, k) : y : null,
                  S
                ], void 0);
              }
            } else {
              var O = y && !b;
              if (O) {
                var D = dn(y, {
                  hour: Tt(l),
                  minute: Ct(l)
                });
                a.setState({
                  preSelection: D
                }), k && (D = un(D, k)), w?.([D, null], void 0);
              } else if (y && b) {
                var S = dn(b, {
                  hour: Tt(l),
                  minute: Ct(l)
                });
                a.setState({
                  preSelection: S
                }), k && (S = un(S, k)), w?.([
                  k ? un(y, k) : y,
                  S
                ], void 0);
              } else {
                var q = dn(a.getPreSelection(), {
                  hour: Tt(l),
                  minute: Ct(l)
                });
                a.setState({
                  preSelection: q
                });
              }
            }
          } else {
            var L = a.props.selected ? a.props.selected : a.getPreSelection(), q = a.props.selected ? l : dn(L, {
              hour: Tt(l),
              minute: Ct(l)
            });
            a.setState({
              preSelection: q
            }), q && k && (q = un(q, k)), (p = (d = a.props).onChange) === null || p === void 0 || p.call(d, q);
          }
          a.props.shouldCloseOnSelect && !a.props.showTimeInput && (a.sendFocusBackToInput(), a.setOpen(!1)), a.props.showTimeInput && a.setOpen(!0), (a.props.showTimeSelectOnly || a.props.showTimeSelect) && a.setState({ isRenderAriaLiveMessage: !0 }), a.setState({ inputValue: null });
        }
      }, a.onInputClick = function() {
        var l, c;
        !a.props.disabled && !a.props.readOnly && a.setOpen(!0), (c = (l = a.props).onInputClick) === null || c === void 0 || c.call(l);
      }, a.handleTimeOnlyArrowKey = function(l) {
        var c, d, p, m, g = Dr(a.props.selected) || a.state.preSelection || Le(), y = (c = a.props.timeIntervals) !== null && c !== void 0 ? c : 30, b = (d = a.props.dateFormat) !== null && d !== void 0 ? d : i.defaultProps.dateFormat, _ = Array.isArray(b) ? b[0] : b, k = Ho(g), w = Tt(g) * 60 + Ct(g), D = 1440 - y, S;
        if (l === te.ArrowUp) {
          var O = Math.max(0, w - y);
          S = Bo(k, O);
        } else {
          var O = Math.min(D, w + y);
          S = Bo(k, O);
        }
        var q = $e(S, _ || i.defaultProps.dateFormat, a.props.locale);
        if (a.setState({
          preSelection: S,
          inputValue: q
        }), !(a.props.selectsRange || a.props.selectsMultiple)) {
          var L = a.props.selected ? a.props.selected : a.getPreSelection(), P = a.props.selected ? S : dn(L, {
            hour: Tt(S),
            minute: Ct(S)
          });
          (m = (p = a.props).onChange) === null || m === void 0 || m.call(p, P), (a.props.showTimeSelectOnly || a.props.showTimeSelect) && a.setState({ isRenderAriaLiveMessage: !0 }), requestAnimationFrame(function() {
            a.scrollToTimeOption(S);
          });
        }
      }, a.handleTimeOnlyEnterKey = function(l) {
        var c, d, p, m, g = l.target, y = g.value, b = (c = a.props.dateFormat) !== null && c !== void 0 ? c : i.defaultProps.dateFormat, _ = a.props.timeFormat || "p", k = a.state.preSelection || Dr(a.props.selected) || Le(), w = yr(y, b, a.props.locale, (d = a.props.strictParsing) !== null && d !== void 0 ? d : !1, k), D = k;
        if (w && Pt(w))
          D = w;
        else {
          var S = ((p = a.calendar) === null || p === void 0 ? void 0 : p.containerRef.current) instanceof Element && a.calendar.containerRef.current.querySelector(".react-datepicker__time-list-item[tabindex='0']");
          if (S instanceof HTMLElement) {
            var O = (m = S.textContent) === null || m === void 0 ? void 0 : m.trim();
            if (O) {
              var q = yr(O, _, a.props.locale, !1, k);
              q && Pt(q) && (D = q);
            }
          }
        }
        a.handleTimeChange(D), a.setOpen(!1), a.sendFocusBackToInput();
      }, a.scrollToTimeOption = function(l) {
        var c, d;
        if (!((c = a.calendar) === null || c === void 0) && c.containerRef.current) {
          for (var p = a.calendar.containerRef.current, m = Array.from(p.querySelectorAll(".react-datepicker__time-list-item")), g = null, y = 1 / 0, b = a.props.timeFormat || "p", _ = 0, k = m; _ < k.length; _++) {
            var w = k[_], D = (d = w.textContent) === null || d === void 0 ? void 0 : d.trim();
            if (D) {
              var S = yr(D, b, a.props.locale, !1, l);
              if (S && Pt(S)) {
                if (by(S, l)) {
                  g = w;
                  break;
                }
                var O = Math.abs(S.getTime() - l.getTime());
                O < y && (y = O, g = w);
              }
            }
          }
          g && (m.forEach(function(q) {
            q.setAttribute("tabindex", "-1");
          }), g.setAttribute("tabindex", "0"), g.scrollIntoView({
            behavior: "smooth",
            block: "center"
          }));
        }
      }, a.onInputKeyDown = function(l) {
        var c, d, p, m, g, y;
        (d = (c = a.props).onKeyDown) === null || d === void 0 || d.call(c, l);
        var b = l.key;
        if (!a.state.open && !a.props.inline && !a.props.preventOpenOnFocus) {
          (b === te.ArrowDown || b === te.ArrowUp || b === te.Enter) && ((p = a.onInputClick) === null || p === void 0 || p.call(a));
          return;
        }
        if (a.state.open && a.props.showTimeSelectOnly) {
          if (b === te.ArrowDown || b === te.ArrowUp) {
            l.preventDefault(), a.handleTimeOnlyArrowKey(b);
            return;
          }
          if (b === te.Enter) {
            l.preventDefault(), a.handleTimeOnlyEnterKey(l);
            return;
          }
        }
        if (a.state.open) {
          if (b === te.ArrowDown || b === te.ArrowUp) {
            l.preventDefault();
            var _ = a.props.showTimeSelectOnly ? ".react-datepicker__time-list-item[tabindex='0']" : a.props.showWeekPicker && a.props.showWeekNumbers ? '.react-datepicker__week-number[tabindex="0"]' : a.props.showFullMonthYearPicker || a.props.showMonthYearPicker ? '.react-datepicker__month-text[tabindex="0"]' : '.react-datepicker__day[tabindex="0"]', k = ((m = a.calendar) === null || m === void 0 ? void 0 : m.containerRef.current) instanceof Element && a.calendar.containerRef.current.querySelector(_);
            k instanceof HTMLElement && k.focus({ preventScroll: !0 });
            return;
          }
          var w = Le(a.state.preSelection);
          b === te.Enter ? (l.preventDefault(), l.target.blur(), a.inputOk() && a.state.lastPreSelectChange === Fd ? (a.handleSelect(w, l), !a.props.shouldCloseOnSelect && a.setPreSelection(w)) : a.setOpen(!1)) : b === te.Escape ? (l.preventDefault(), l.target.blur(), a.sendFocusBackToInput(), a.setOpen(!1)) : b === te.Tab && a.setOpen(!1), a.inputOk() || (y = (g = a.props).onInputError) === null || y === void 0 || y.call(g, { code: 1, msg: Pd });
        }
      }, a.onPortalKeyDown = function(l) {
        var c = l.key;
        c === te.Escape && (l.preventDefault(), a.setState({
          preventFocus: !0
        }, function() {
          a.setOpen(!1), setTimeout(function() {
            a.setFocus(), a.setState({ preventFocus: !1 });
          });
        }));
      }, a.onDayKeyDown = function(l) {
        var c, d, p, m, g, y, b = a.props, _ = b.minDate, k = b.maxDate, w = b.disabledKeyboardNavigation, D = b.showWeekPicker, S = b.shouldCloseOnSelect, O = b.locale, q = b.calendarStartDay, L = b.adjustDateOnChange, P = b.inline;
        if ((d = (c = a.props).onKeyDown) === null || d === void 0 || d.call(c, l), !w) {
          var F = l.key, J = l.shiftKey, Z = Le(a.state.preSelection), ie = function(ne, $) {
            var ae = $;
            switch (ne) {
              case te.ArrowRight:
                ae = D ? Us($, 1) : Sa($, 1);
                break;
              case te.ArrowLeft:
                ae = D ? gv($) : Zk($);
                break;
              case te.ArrowUp:
                ae = gv($);
                break;
              case te.ArrowDown:
                ae = Us($, 1);
                break;
              case te.PageUp:
                ae = J ? Kn($, 1) : Tr($, 1);
                break;
              case te.PageDown:
                ae = J ? Da($, 1) : Ea($, 1);
                break;
              case te.Home:
                ae = Zn($, O, q);
                break;
              case te.End:
                ae = OS($);
                break;
            }
            return ae;
          }, ue = function(ne, $) {
            for (var ae = 40, le = ne, fe = !1, j = 0, Q = ie(ne, $); !fe; ) {
              if (j >= ae) {
                Q = $;
                break;
              }
              _ && Q < _ && (le = te.ArrowRight, Q = ga(_, a.props) ? ie(le, Q) : _), k && Q > k && (le = te.ArrowLeft, Q = ga(k, a.props) ? ie(le, Q) : k), ga(Q, a.props) ? ((le === te.PageUp || le === te.Home) && (le = te.ArrowRight), (le === te.PageDown || le === te.End) && (le = te.ArrowLeft), Q = ie(le, Q)) : fe = !0, j++;
            }
            return Q;
          };
          if (F === te.Enter) {
            l.preventDefault(), a.handleSelect(Z, l), !S && a.setPreSelection(Z);
            return;
          } else if (F === te.Escape) {
            l.preventDefault(), a.setOpen(!1), a.inputOk() || (m = (p = a.props).onInputError) === null || m === void 0 || m.call(p, { code: 1, msg: Pd });
            return;
          }
          var de = null;
          switch (F) {
            case te.ArrowLeft:
            case te.ArrowRight:
            case te.ArrowUp:
            case te.ArrowDown:
            case te.PageUp:
            case te.PageDown:
            case te.Home:
            case te.End:
              de = ue(F, Z);
              break;
          }
          if (!de) {
            (y = (g = a.props).onInputError) === null || y === void 0 || y.call(g, { code: 1, msg: Pd });
            return;
          }
          l.preventDefault(), a.setState({ lastPreSelectChange: Fd }), L && a.setSelected(de), a.setPreSelection(de), P && a.setState({ shouldFocusDayInline: !0 });
        }
      }, a.onPopperKeyDown = function(l) {
        var c = l.key;
        c === te.Escape && (l.preventDefault(), a.sendFocusBackToInput(), a.setOpen(!1));
      }, a.onClearClick = function(l) {
        l && l.preventDefault && l.preventDefault(), a.sendFocusBackToInput();
        var c = a.props, d = c.selectsRange, p = c.onChange;
        p?.(d ? [null, null] : null, l), a.setState({ inputValue: null });
      }, a.clear = function() {
        a.onClearClick();
      }, a.onScroll = function(l) {
        typeof a.props.closeOnScroll == "boolean" && a.props.closeOnScroll ? (l.target === document || l.target === document.documentElement || l.target === document.body) && a.setOpen(!1) : typeof a.props.closeOnScroll == "function" && a.props.closeOnScroll(l) && a.setOpen(!1);
      }, a.handleMonthSelectedInChange = function(l) {
        a.setState({ monthSelectedIn: l });
      }, a.renderCalendar = function() {
        var l, c;
        return !a.props.inline && !a.isCalendarOpen() ? null : B.createElement(cD, Me({ showMonthYearDropdown: void 0, ref: function(d) {
          a.calendar = d;
        } }, a.props, a.state, { setOpen: a.setOpen, dateFormat: (l = a.props.dateFormatCalendar) !== null && l !== void 0 ? l : i.defaultProps.dateFormatCalendar, onSelect: a.handleSelect, onClickOutside: a.handleCalendarClickOutside, holidays: PS(a.modifyHolidays()), outsideClickIgnoreClass: a.props.outsideClickIgnoreClass, onDropdownFocus: a.handleDropdownFocus, onTimeChange: a.handleTimeChange, className: a.props.calendarClassName, container: a.props.calendarContainer, handleOnKeyDown: a.props.onKeyDown, handleOnDayKeyDown: a.onDayKeyDown, setPreSelection: a.setPreSelection, dropdownMode: (c = a.props.dropdownMode) !== null && c !== void 0 ? c : i.defaultProps.dropdownMode, onMonthSelectedInChange: a.handleMonthSelectedInChange }), a.props.children);
      }, a.renderAriaLiveRegion = function() {
        var l, c = a.props.locale, d = (l = a.props.dateFormat) !== null && l !== void 0 ? l : i.defaultProps.dateFormat, p = a.props.showTimeInput || a.props.showTimeSelect, m = p ? "PPPPp" : "PPPP", g;
        return a.props.selectsRange ? g = "Selected start date: ".concat(Qt(a.props.startDate, {
          dateFormat: m,
          locale: c
        }), ". ").concat(a.props.endDate ? "End date: " + Qt(a.props.endDate, {
          dateFormat: m,
          locale: c
        }) : "") : a.props.showTimeSelectOnly ? g = "Selected time: ".concat(Qt(a.props.selected, { dateFormat: d, locale: c })) : a.props.showYearPicker ? g = "Selected year: ".concat(Qt(a.props.selected, { dateFormat: "yyyy", locale: c })) : a.props.showMonthYearPicker ? g = "Selected month: ".concat(Qt(a.props.selected, { dateFormat: "MMMM yyyy", locale: c })) : a.props.showQuarterYearPicker ? g = "Selected quarter: ".concat(Qt(a.props.selected, {
          dateFormat: "yyyy, QQQ",
          locale: c
        })) : g = "Selected date: ".concat(Qt(a.props.selected, {
          dateFormat: m,
          locale: c
        })), B.createElement("span", { role: "alert", "aria-live": "polite", className: "react-datepicker__aria-live" }, g);
      }, a.renderDateInput = function() {
        var l, c, d, p, m, g, y, b = vt(a.props.className, (l = {}, l[a.props.outsideClickIgnoreClass || i.defaultProps.outsideClickIgnoreClass] = a.state.open, l)), _ = a.props.customInput || B.createElement("input", { type: "text" }), k = a.props.customInputRef || "ref", w = {}, D = (d = a.props["aria-describedby"]) !== null && d !== void 0 ? d : a.props.ariaDescribedBy, S = (p = a.props["aria-invalid"]) !== null && p !== void 0 ? p : a.props.ariaInvalid, O = (m = a.props["aria-label"]) !== null && m !== void 0 ? m : a.props.ariaLabel, q = (g = a.props["aria-labelledby"]) !== null && g !== void 0 ? g : a.props.ariaLabelledBy, L = (y = a.props["aria-required"]) !== null && y !== void 0 ? y : a.props.ariaRequired;
        return D != null && (w["aria-describedby"] = D), S != null && (w["aria-invalid"] = S), O != null && (w["aria-label"] = O), q != null && (w["aria-labelledby"] = q), L != null && (w["aria-required"] = L), N.cloneElement(_, Me((c = {}, c[k] = function(P) {
          a.input = P;
        }, c.value = a.getInputValue(), c.onBlur = a.handleBlur, c.onChange = a.handleChange, c.onClick = a.onInputClick, c.onFocus = a.handleFocus, c.onKeyDown = a.onInputKeyDown, c.id = a.props.id, c.name = a.props.name, c.form = a.props.form, c.autoFocus = a.props.autoFocus, c.placeholder = a.props.placeholderText, c.disabled = a.props.disabled, c.autoComplete = a.props.autoComplete, c.className = vt(_.props.className, b), c.title = a.props.title, c.readOnly = a.props.readOnly, c.required = a.props.required, c.tabIndex = a.props.tabIndex, c), w));
      }, a.renderClearButton = function() {
        var l = a.props, c = l.isClearable, d = l.disabled, p = l.selected, m = l.startDate, g = l.endDate, y = l.clearButtonTitle, b = l.clearButtonClassName, _ = b === void 0 ? "" : b, k = l.ariaLabelClose, w = k === void 0 ? "Close" : k, D = l.selectedDates, S = l.readOnly;
        return c && !S && (p != null || m != null || g != null || D?.length) ? B.createElement("button", { type: "button", className: vt("react-datepicker__close-icon", _, { "react-datepicker__close-icon--disabled": d }), disabled: d, "aria-label": w, onClick: a.onClearClick, title: y, tabIndex: -1 }) : null;
      }, a.state = a.calcInitialState(), a.preventFocusTimeout = void 0, a;
    }
    return Object.defineProperty(i, "defaultProps", {
      get: function() {
        return {
          allowSameDay: !1,
          dateFormat: "MM/dd/yyyy",
          dateFormatCalendar: "LLLL yyyy",
          disabled: !1,
          disabledKeyboardNavigation: !1,
          dropdownMode: "scroll",
          preventOpenOnFocus: !1,
          monthsShown: 1,
          outsideClickIgnoreClass: xy,
          readOnly: !1,
          rangeSeparator: py,
          withPortal: !1,
          selectsDisabledDaysInRange: !1,
          shouldCloseOnSelect: !0,
          showTimeSelect: !1,
          showTimeInput: !1,
          showPreviousMonths: !1,
          showMonthYearPicker: !1,
          showFullMonthYearPicker: !1,
          showTwoColumnMonthYearPicker: !1,
          showFourColumnMonthYearPicker: !1,
          showYearPicker: !1,
          showQuarterYearPicker: !1,
          showWeekPicker: !1,
          strictParsing: !1,
          swapRange: !1,
          timeIntervals: 30,
          timeCaption: "Time",
          previousMonthAriaLabel: "Previous Month",
          previousMonthButtonLabel: "Previous Month",
          nextMonthAriaLabel: "Next Month",
          nextMonthButtonLabel: "Next Month",
          previousYearAriaLabel: "Previous Year",
          previousYearButtonLabel: "Previous Year",
          nextYearAriaLabel: "Next Year",
          nextYearButtonLabel: "Next Year",
          timeInputLabel: "Time",
          enableTabLoop: !0,
          yearItemNumber: Io,
          focusSelectedMonth: !1,
          showPopperArrow: !0,
          excludeScrollbar: !0,
          customTimeInput: null,
          calendarStartDay: void 0,
          toggleCalendarOnIconClick: !1,
          usePointerEvent: !1
        };
      },
      enumerable: !1,
      configurable: !0
    }), i.prototype.componentDidMount = function() {
      window.addEventListener("scroll", this.onScroll, !0), document.addEventListener("visibilitychange", this.setHiddenStateOnVisibilityHidden);
    }, i.prototype.componentDidUpdate = function(n, a) {
      var l, c, d, p;
      this.props.selectsRange && Xv(n.startDate, this.props.startDate) ? this.setPreSelection(this.props.startDate) : Xv(n.selected, this.props.selected) && this.setPreSelection(this.props.selected), this.state.monthSelectedIn !== void 0 && n.monthsShown !== this.props.monthsShown && this.setState({ monthSelectedIn: 0 }), this.props.selectsRange && a.open === !1 && this.state.open === !0 && this.state.monthSelectedIn !== 0 && this.setState({ monthSelectedIn: 0 }), n.highlightDates !== this.props.highlightDates && this.setState({
        highlightDates: Bv(this.props.highlightDates)
      }), !a.focused && !Er(n.selected, this.props.selected) && this.setState({ inputValue: null }), a.open !== this.state.open && (a.open === !1 && this.state.open === !0 && ((c = (l = this.props).onCalendarOpen) === null || c === void 0 || c.call(l)), a.open === !0 && this.state.open === !1 && ((p = (d = this.props).onCalendarClose) === null || p === void 0 || p.call(d)));
    }, i.prototype.componentWillUnmount = function() {
      this.clearPreventFocusTimeout(), window.removeEventListener("scroll", this.onScroll, !0), document.removeEventListener("visibilitychange", this.setHiddenStateOnVisibilityHidden);
    }, i.prototype.renderInputContainer = function() {
      var n = this.props, a = n.showIcon, l = n.icon, c = n.calendarIconClassname, d = n.calendarIconClassName, p = n.toggleCalendarOnIconClick, m = this.state.open;
      return c && console.warn("calendarIconClassname props is deprecated. should use calendarIconClassName props."), B.createElement(
        "div",
        { className: "react-datepicker__input-container".concat(a ? " react-datepicker__view-calendar-icon" : "") },
        a && B.createElement(uD, Me({ icon: l, className: vt(d, !d && c, m && "react-datepicker-ignore-onclickoutside") }, p ? {
          onClick: this.toggleCalendar
        } : null)),
        this.state.isRenderAriaLiveMessage && this.renderAriaLiveRegion(),
        this.renderDateInput(),
        this.renderClearButton()
      );
    }, i.prototype.render = function() {
      var n = this.renderCalendar();
      if (this.props.inline)
        return n;
      if (this.props.withPortal) {
        var a = this.state.open ? B.createElement(
          _y,
          { enableTabLoop: this.props.enableTabLoop },
          B.createElement("div", { className: "react-datepicker__portal", tabIndex: -1, onKeyDown: this.onPortalKeyDown }, n)
        ) : null;
        return this.state.open && this.props.portalId && (a = B.createElement(wy, Me({ portalId: this.props.portalId }, this.props), a)), B.createElement(
          B.Fragment,
          null,
          this.renderInputContainer(),
          a
        );
      }
      return B.createElement(mD, Me({}, this.props, { className: this.props.popperClassName, hidePopper: !this.isCalendarOpen(), targetComponent: this.renderInputContainer(), popperComponent: n, popperOnKeyDown: this.onPopperKeyDown, showArrow: this.props.showPopperArrow, monthHeaderPosition: this.props.monthHeaderPosition }));
    }, i;
  })(N.Component)
), gD = "input", Fd = "navigate";
const vD = {
  video: /* @__PURE__ */ h.jsxs("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
    /* @__PURE__ */ h.jsx("polygon", { points: "23 7 16 12 23 17 23 7" }),
    /* @__PURE__ */ h.jsx("rect", { x: "1", y: "5", width: "15", height: "14", rx: "2", ry: "2" })
  ] }),
  plus: /* @__PURE__ */ h.jsxs("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
    /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "5", x2: "12", y2: "19" }),
    /* @__PURE__ */ h.jsx("line", { x1: "5", y1: "12", x2: "19", y2: "12" })
  ] }),
  calendar: /* @__PURE__ */ h.jsxs("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
    /* @__PURE__ */ h.jsx("rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", ry: "2" }),
    /* @__PURE__ */ h.jsx("line", { x1: "16", y1: "2", x2: "16", y2: "6" }),
    /* @__PURE__ */ h.jsx("line", { x1: "8", y1: "2", x2: "8", y2: "6" }),
    /* @__PURE__ */ h.jsx("line", { x1: "3", y1: "10", x2: "21", y2: "10" })
  ] }),
  share: /* @__PURE__ */ h.jsxs("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
    /* @__PURE__ */ h.jsx("rect", { x: "2", y: "3", width: "20", height: "14", rx: "2", ry: "2" }),
    /* @__PURE__ */ h.jsx("line", { x1: "8", y1: "21", x2: "16", y2: "21" }),
    /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "17", x2: "12", y2: "21" })
  ] })
};
function Vd({
  label: o,
  icon: i,
  color: n = "blue",
  disabled: a,
  onClick: l
}) {
  return /* @__PURE__ */ h.jsxs(
    "button",
    {
      className: `action-btn ${n}`,
      disabled: a,
      onClick: l,
      children: [
        i && vD[i],
        /* @__PURE__ */ h.jsx("span", { children: o })
      ]
    }
  );
}
async function bD() {
  const o = await ba.get("/meetings");
  return Array.isArray(o.data) ? o.data : [];
}
async function ky(o) {
  return (await ba.post("/meetings", o)).data;
}
async function yD(o, i) {
  await ba.put(`/meetings/${o}`, i);
}
async function xD(o) {
  await ba.delete(`/meetings/${o}`);
}
async function wD(o, i) {
  await ba.post(`/meetings/${o}/occurrences/cancel`, { occurrenceStartUtc: i });
}
async function _D(o) {
  await ba.post(`/meetings/${o}/start`);
}
async function kD(o) {
  return (await ba.get(`/meetings/status/${encodeURIComponent(o)}`)).data;
}
async function SD(o, i, n) {
  const l = (await In.post("/api/v1/meetings/join-by-code", {
    meetingCode: o,
    displayName: i,
    password: n
  })).data || {};
  return {
    ok: l.ok === !0 || l.Ok === !0,
    code: l.code ?? l.Code ?? null,
    error: l.error ?? l.Error ?? null,
    roomName: l.roomName ?? l.RoomName ?? null
  };
}
async function DD(o) {
  const i = await In.get(`/oaticonnect/meetings/${o}/participants`);
  return Array.isArray(i.data) ? i.data : [];
}
async function Zv(o) {
  return (await ba.get(`/meetings/${o}/share-link`)).data;
}
async function ED() {
  return { enabled: !!(await ba.get("/exchange/status")).data?.enabled };
}
async function MD() {
  return (await ba.post("/exchange/test")).data;
}
async function TD(o) {
  const i = (o ?? "").trim();
  if (i.length < 2) return [];
  const n = await ba.get(`/exchange/search?q=${encodeURIComponent(i)}`);
  return Array.isArray(n.data) ? n.data : [];
}
const Gd = {};
function CD(o) {
  if (!o) return !1;
  const i = Gd[o];
  if (i !== void 0) return i;
  try {
    return new Intl.DateTimeFormat("en-CA", { timeZone: o }), Gd[o] = !0, !0;
  } catch {
    return Gd[o] = !1, !1;
  }
}
function $o(o) {
  if (o)
    return CD(o) ? o : void 0;
}
function Sy(o, i) {
  const n = {
    hour12: !1,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }, a = $o(i);
  a && (n.timeZone = a);
  const l = new Intl.DateTimeFormat("en-CA", n), c = {};
  for (const p of l.formatToParts(o)) c[p.type] = p.value;
  const d = +c.hour == 24 ? 0 : +c.hour;
  return {
    year: +c.year,
    month: +c.month,
    day: +c.day,
    hour: d,
    minute: +c.minute,
    second: +c.second
  };
}
function ND(o, i) {
  if (!o) return null;
  const n = o instanceof Date ? o : new Date(o);
  if (isNaN(n.getTime())) return null;
  const a = $o(i);
  if (!a) return n;
  const l = Sy(n, a);
  return new Date(l.year, l.month - 1, l.day, l.hour, l.minute, l.second);
}
function OD(o, i) {
  if (!o) return null;
  const n = $o(i);
  if (!n) return new Date(o.getTime());
  const a = Date.UTC(
    o.getFullYear(),
    o.getMonth(),
    o.getDate(),
    o.getHours(),
    o.getMinutes(),
    o.getSeconds()
  ), l = Sy(new Date(a), n), c = Date.UTC(l.year, l.month - 1, l.day, l.hour, l.minute, l.second), d = a - c;
  return new Date(a + d);
}
function jD(o, i, n) {
  const a = $o(i);
  try {
    return new Intl.DateTimeFormat(void 0, { ...o, timeZone: a }).format(n);
  } catch {
    return new Intl.DateTimeFormat(void 0, o).format(n);
  }
}
function uf(o, i, n) {
  if (!o) return "";
  const a = o instanceof Date ? o : new Date(o);
  return isNaN(a.getTime()) ? "" : jD(n, i, a);
}
function Dy() {
  const o = tc(), i = $o((o?.user?.timeZone || "").trim() || void 0), n = (a, l) => uf(a, i, l);
  return {
    timeZone: i,
    formatDateTimeShort: (a) => n(a, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }),
    formatDateTimeLong: (a) => n(a, { weekday: "long", year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short" }),
    formatDate: (a) => n(a, { year: "numeric", month: "short", day: "numeric" }),
    /** Long human-readable date — "Friday, 22 May 2026" (day-month-
     *  year). Locale forced to en-GB so dashboard mailto matches the
     *  server's InvariantCulture output regardless of browser locale. */
    formatDateLong: (a) => {
      if (!a) return "";
      const l = a instanceof Date ? a : new Date(a);
      if (isNaN(l.getTime())) return "";
      try {
        return new Intl.DateTimeFormat("en-GB", {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
          timeZone: i || void 0
        }).format(l);
      } catch {
        return new Intl.DateTimeFormat("en-GB", {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric"
        }).format(l);
      }
    },
    formatTime: (a) => n(a, { hour: "numeric", minute: "2-digit" }),
    /** Time in 24h with the host zone's full NAME suffix — e.g.
     *  "20:48 Central Daylight Time". Matches the server .ics/email,
     *  which label with TimeZoneInfo.DaylightName/StandardName rather
     *  than a bare GMT offset (recipients want the logged-in user's
     *  timezone shown, not GMT). DST-aware: the name auto-flips between
     *  standard and daylight as Intl resolves it for the instant. */
    formatTimeWithZone: (a) => {
      if (!a) return "";
      const l = a instanceof Date ? a : new Date(a);
      if (isNaN(l.getTime())) return "";
      try {
        const c = new Intl.DateTimeFormat("en-GB", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: !1,
          timeZone: i || void 0
        }).format(l), d = new Intl.DateTimeFormat("en-US", {
          hour: "2-digit",
          timeZoneName: "long",
          timeZone: i || void 0
        }).formatToParts(l).find((p) => p.type === "timeZoneName")?.value || "";
        return d ? `${c} ${d}` : c;
      } catch {
        return new Intl.DateTimeFormat("en-GB", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: !1
        }).format(l);
      }
    },
    format: n
  };
}
const Kv = (o) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(o.trim());
function AD({ value: o, onChange: i }) {
  const [n, a] = N.useState(""), [l, c] = N.useState([]), [d, p] = N.useState(!1), [m, g] = N.useState(!1), y = N.useRef(null), b = N.useRef(null);
  N.useEffect(() => {
    if (y.current && clearTimeout(y.current), n.trim().length < 2) {
      c([]), g(!1);
      return;
    }
    return g(!0), y.current = setTimeout(async () => {
      try {
        c(await TD(n));
      } catch {
        c([]);
      } finally {
        g(!1);
      }
    }, 250), () => {
      y.current && clearTimeout(y.current);
    };
  }, [n]), N.useEffect(() => {
    if (!d) return;
    const D = (S) => {
      const O = S.composedPath && S.composedPath() || [];
      b.current && !O.includes(b.current) && p(!1);
    };
    return document.addEventListener("mousedown", D), () => document.removeEventListener("mousedown", D);
  }, [d]);
  function _(D) {
    const S = new Set(o.map((q) => (q.id || q.email || "").toLowerCase())), O = (D.id || D.email || "").toLowerCase();
    S.has(O) || (i([...o, D]), a(""), c([]));
  }
  function k(D) {
    i(o.filter((S, O) => O !== D));
  }
  function w() {
    const D = n.trim();
    D && Kv(D) && _({ email: D, name: D, kind: "manual" });
  }
  return /* @__PURE__ */ h.jsxs("div", { className: "invite-picker", ref: b, children: [
    /* @__PURE__ */ h.jsxs("div", { className: "invite-picker-chips", onClick: () => p(!0), children: [
      o.map((D, S) => /* @__PURE__ */ h.jsxs("span", { className: `invite-chip invite-chip-${D.kind}`, children: [
        /* @__PURE__ */ h.jsx(Wv, { kind: D.kind }),
        /* @__PURE__ */ h.jsx("span", { className: "invite-chip-name", children: D.name }),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            className: "invite-chip-x",
            onClick: (O) => {
              O.stopPropagation(), k(S);
            },
            "aria-label": `Remove ${D.name}`,
            children: "×"
          }
        )
      ] }, (D.id || D.email || D.name) + S)),
      /* @__PURE__ */ h.jsx(
        "input",
        {
          className: "invite-picker-input",
          placeholder: o.length === 0 ? "Search people, groups, or type an email…" : "",
          value: n,
          onChange: (D) => {
            a(D.target.value), p(!0);
          },
          onFocus: () => p(!0),
          onKeyDown: (D) => {
            D.key === "Enter" && (D.preventDefault(), w()), D.key === "Backspace" && !n && o.length > 0 && k(o.length - 1);
          }
        }
      )
    ] }),
    d && (n.trim().length >= 2 || l.length > 0) && /* @__PURE__ */ h.jsxs("div", { className: "invite-picker-dropdown", children: [
      m && /* @__PURE__ */ h.jsx("div", { className: "invite-picker-row muted", children: "Searching…" }),
      !m && l.length === 0 && /* @__PURE__ */ h.jsx("div", { className: "invite-picker-row muted", children: Kv(n) ? /* @__PURE__ */ h.jsxs("span", { children: [
        "Press Enter to add ",
        /* @__PURE__ */ h.jsx("b", { children: n.trim() }),
        " as an email invite."
      ] }) : /* @__PURE__ */ h.jsx("span", { children: "No matches. Type a full email and press Enter to add it directly." }) }),
      l.map((D) => /* @__PURE__ */ h.jsxs(
        "button",
        {
          type: "button",
          className: "invite-picker-row",
          onClick: () => _({ id: D.id, name: D.name, email: D.email ?? void 0, kind: D.kind === "contact" ? "user" : D.kind }),
          children: [
            /* @__PURE__ */ h.jsx(Wv, { kind: D.kind === "contact" ? "user" : D.kind }),
            /* @__PURE__ */ h.jsx("span", { className: "invite-picker-row-name", children: D.name }),
            D.email && /* @__PURE__ */ h.jsx("span", { className: "invite-picker-row-email", children: D.email })
          ]
        },
        D.id
      ))
    ] })
  ] });
}
function Wv({ kind: o }) {
  return o === "group" ? /* @__PURE__ */ h.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
    /* @__PURE__ */ h.jsx("path", { d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" }),
    /* @__PURE__ */ h.jsx("circle", { cx: "9", cy: "7", r: "4" }),
    /* @__PURE__ */ h.jsx("path", { d: "M23 21v-2a4 4 0 0 0-3-3.87" }),
    /* @__PURE__ */ h.jsx("path", { d: "M16 3.13a4 4 0 0 1 0 7.75" })
  ] }) : /* @__PURE__ */ h.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
    /* @__PURE__ */ h.jsx("path", { d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" }),
    /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "7", r: "4" })
  ] });
}
function Iv() {
  return (Math.floor(Math.random() * 9e9) + 1e9).toString();
}
function RD() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || void 0;
  } catch {
    return;
  }
}
function zD(o) {
  const i = (o || "").replace(/\D/g, "");
  return i.length === 10 ? `${i.slice(0, 3)} ${i.slice(3, 6)} ${i.slice(6)}` : i.length === 9 ? `${i.slice(0, 3)} ${i.slice(3, 6)} ${i.slice(6)}` : o || "";
}
function Jv() {
  const o = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  let i = "";
  for (let n = 0; n < 6; n++) i += o[Math.floor(Math.random() * o.length)];
  return i;
}
function $v(o) {
  return `${mn()}/oaticonnect/calendar/${encodeURIComponent(o)}`;
}
const xr = 0, eb = 1, Ds = 2, LD = 3, Xd = 0, Es = 1, Zd = 2, YD = [
  { label: "Sun", mask: 1 },
  { label: "Mon", mask: 2 },
  { label: "Tue", mask: 4 },
  { label: "Wed", mask: 8 },
  { label: "Thu", mask: 16 },
  { label: "Fri", mask: 32 },
  { label: "Sat", mask: 64 }
];
function HD({ onClose: o, editMeeting: i }) {
  const n = !!i, a = zb(), l = tc(), c = l?.user?.role === "Admin", d = (l?.user?.timeZone || "").trim() || void 0, p = l?.preferences?.defaultDurationMinutes || 60, m = !!l?.preferences?.enableMeetingPassword, g = !!l?.preferences?.requireHostStart, y = (l?.user?.name?.trim() || "Untitled") + "'s " + (ac() || "OATIConnect") + " Meeting", [b, _] = N.useState(i?.title || y), [k, w] = N.useState(
    i?.meetingCode || Iv()
  ), [D, S] = N.useState(i?.description || ""), [O, q] = N.useState(
    () => i?.scheduledTimeUtc ? ND(i.scheduledTimeUtc, d) : null
  ), [L, P] = N.useState(i?.durationMinutes || p), [F, J] = N.useState(i?.password ?? ""), [Z, ie] = N.useState(!1), [ue, de] = N.useState(!!i?.requireHostStart), ne = l?.preferences?.recurringMaxDurationDays ?? 90, $ = ne > 0 ? Es : Xd, [ae, le] = N.useState(i?.recurrenceType ?? xr), [fe, j] = N.useState(i?.recurrenceInterval ?? 1), [Q, W] = N.useState(i?.recurrenceDaysOfWeekMask ?? 0), [se, we] = N.useState(i?.recurrenceEndType ?? $), [M, T] = N.useState(i?.recurrenceEndCount ?? 10), [K, I] = N.useState(
    () => i?.recurrenceEndDateUtc ? new Date(i.recurrenceEndDateUtc) : null
  ), oe = N.useMemo(() => {
    if (ne <= 0) return null;
    const be = O ?? /* @__PURE__ */ new Date(), qe = new Date(be);
    return qe.setDate(qe.getDate() + ne), qe;
  }, [ne, O]), [pe, ke] = N.useState(!1), [Ke, ze] = N.useState(!1), [ee, ve] = N.useState(
    (i?.inviteeEmails ?? []).map((be) => ({
      email: be,
      name: be,
      kind: "manual"
    }))
  );
  N.useEffect(() => {
    ED().then((be) => ze(be.enabled)).catch(() => ze(!1));
  }, []), N.useEffect(() => {
    !n && m && !F && J(Jv());
  }, [m, n]);
  async function Et() {
    if (!b.trim() && !O) {
      a.error("Please enter a title and select a date & time");
      return;
    }
    if (!b.trim()) {
      a.error("Please enter a meeting title");
      return;
    }
    if (!O) {
      a.error("Please select a date & time");
      return;
    }
    if (m && !F.trim()) {
      a.error("Please enter a meeting password");
      return;
    }
    const be = ee.filter((lt) => lt.id).map((lt) => lt.id), qe = ee.filter((lt) => !lt.id && lt.email).map((lt) => lt.email), Ot = (OD(O, d) ?? O).toISOString();
    ke(!0);
    try {
      const lt = m ? F ?? "" : void 0, Xt = g ? ue : void 0, Ta = {
        recurrenceType: ae,
        recurrenceInterval: ae === xr ? 1 : Math.max(1, fe | 0),
        recurrenceDaysOfWeekMask: ae === Ds ? Q : 0,
        recurrenceEndType: ae === xr ? Xd : se,
        recurrenceEndCount: se === Es && ae !== xr ? M : null,
        recurrenceEndDateUtc: se === Zd && ae !== xr && K ? K.toISOString() : null
      };
      if (n && i) {
        await yD(i.meetingId, {
          title: b,
          description: D || null,
          scheduledTimeUtc: Ot,
          durationMinutes: L,
          inviteeIds: be,
          inviteeEmails: qe,
          password: lt,
          requireHostStart: Xt,
          ...Ta
        }), o();
        return;
      }
      const Ca = await ky({
        title: b,
        meetingCode: k,
        // Browser timezone as a fallback for email/.ics formatting so
        // the invitation reads in the user's wall-clock even when the
        // host's stored profile zone is missing or unrecognised.
        clientTimeZone: RD(),
        description: D || null,
        scheduledTimeUtc: Ot,
        durationMinutes: L,
        inviteeIds: be,
        inviteeEmails: qe,
        password: lt,
        requireHostStart: Xt,
        ...Ta
      });
      if (window.electronAPI)
        try {
          await window.electronAPI.openOutlookEvent($v(Ca.roomName));
        } catch {
        }
      else
        window.open($v(Ca.roomName));
      o();
    } finally {
      ke(!1);
    }
  }
  return /* @__PURE__ */ h.jsx("div", { className: "modal-backdrop", children: /* @__PURE__ */ h.jsxs("div", { className: "modal scheduler-modal", children: [
    /* @__PURE__ */ h.jsx("button", { className: "modal-close-btn", onClick: o, "aria-label": "Close", type: "button", children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
      /* @__PURE__ */ h.jsx("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
      /* @__PURE__ */ h.jsx("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
    ] }) }),
    /* @__PURE__ */ h.jsx("h2", { children: n ? "Edit Meeting" : "Schedule Meeting" }),
    /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Meeting ID" }),
      /* @__PURE__ */ h.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "8px" }, children: [
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: "text",
            value: zD(k),
            readOnly: !0,
            style: {
              fontFamily: "Consolas, Menlo, monospace",
              letterSpacing: "0.04em",
              fontSize: "15px",
              fontWeight: 600,
              flex: 1,
              background: "var(--color-surface-muted, #f3f4f6)",
              cursor: "default"
            }
          }
        ),
        !n && /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: () => w(Iv()),
            title: "Generate a new Meeting ID",
            style: {
              padding: "6px 10px",
              borderRadius: "6px",
              border: "1px solid var(--color-border, #d1d5db)",
              background: "var(--color-surface, #fff)",
              cursor: "pointer",
              fontSize: "12px",
              color: "var(--color-text-muted, #6b7280)"
            },
            children: "Regenerate"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Meeting Title" }),
      /* @__PURE__ */ h.jsx(
        "input",
        {
          placeholder: "What's this meeting about?",
          value: b,
          onChange: (be) => _(be.target.value)
        }
      )
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Description (optional)" }),
      /* @__PURE__ */ h.jsx(
        "textarea",
        {
          placeholder: "Brief description / agenda for the meeting",
          value: D,
          onChange: (be) => S(be.target.value),
          rows: 2
        }
      )
    ] }),
    Ke && /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Invite (optional)" }),
      /* @__PURE__ */ h.jsx(AD, { value: ee, onChange: ve }),
      /* @__PURE__ */ h.jsx("div", { style: { marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }, children: "Invitees see this meeting on their dashboard and can join. Groups expand to all members at save time." })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Date & Time" }),
      /* @__PURE__ */ h.jsx(
        cf,
        {
          selected: O,
          onChange: (be) => q(be),
          showTimeSelect: !0,
          timeFormat: "HH:mm",
          timeIntervals: 15,
          timeCaption: "Time",
          dateFormat: "MMM d, yyyy h:mm aa",
          placeholderText: "Select date and time",
          minDate: n ? void 0 : /* @__PURE__ */ new Date(),
          className: "datepicker-input",
          wrapperClassName: "datepicker-wrapper",
          popperClassName: "datepicker-popper",
          popperPlacement: "bottom-start"
        }
      )
    ] }),
    m && /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsxs("label", { children: [
        "Password ",
        /* @__PURE__ */ h.jsx("span", { style: { color: "#dc2626", fontSize: 11 }, children: "*" }),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: () => J(Jv()),
            style: {
              marginLeft: 10,
              padding: "2px 8px",
              fontSize: 11,
              background: "transparent",
              border: "1px solid var(--color-border, #d1d5db)",
              borderRadius: 4,
              cursor: "pointer",
              color: "var(--color-text-secondary, #6b7280)"
            },
            title: "Generate a new random password",
            children: "Regenerate"
          }
        )
      ] }),
      /* @__PURE__ */ h.jsxs("div", { style: { position: "relative" }, children: [
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: Z ? "text" : "password",
            maxLength: 100,
            placeholder: "Required when password protection is enabled",
            required: !0,
            value: F,
            onChange: (be) => J(be.target.value),
            autoComplete: "new-password",
            autoCorrect: "off",
            autoCapitalize: "off",
            spellCheck: !1,
            "data-1p-ignore": "true",
            "data-lpignore": "true",
            "data-form-type": "other",
            style: { paddingRight: 38, width: "100%" }
          }
        ),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: () => ie((be) => !be),
            "aria-label": Z ? "Hide password" : "Show password",
            title: Z ? "Hide password" : "Show password",
            style: {
              position: "absolute",
              top: "50%",
              right: 8,
              transform: "translateY(-50%)",
              background: "transparent",
              border: 0,
              padding: 4,
              cursor: "pointer",
              color: "var(--color-text-secondary, #6b7280)",
              display: "flex",
              alignItems: "center"
            },
            children: Z ? (
              // eye-off
              /* @__PURE__ */ h.jsxs(
                "svg",
                {
                  width: "18",
                  height: "18",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: "2",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  children: [
                    /* @__PURE__ */ h.jsx("path", { d: "M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" }),
                    /* @__PURE__ */ h.jsx("path", { d: "M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" }),
                    /* @__PURE__ */ h.jsx("path", { d: "M14.12 14.12A3 3 0 1 1 9.88 9.88" }),
                    /* @__PURE__ */ h.jsx("line", { x1: "1", y1: "1", x2: "23", y2: "23" })
                  ]
                }
              )
            ) : (
              // eye
              /* @__PURE__ */ h.jsxs(
                "svg",
                {
                  width: "18",
                  height: "18",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: "2",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  children: [
                    /* @__PURE__ */ h.jsx("path", { d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }),
                    /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "12", r: "3" })
                  ]
                }
              )
            )
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Repeat" }),
      /* @__PURE__ */ h.jsxs("select", { value: ae, onChange: (be) => le(Number(be.target.value)), children: [
        /* @__PURE__ */ h.jsx("option", { value: xr, children: "Does not repeat" }),
        /* @__PURE__ */ h.jsx("option", { value: eb, children: "Daily" }),
        /* @__PURE__ */ h.jsx("option", { value: Ds, children: "Weekly" }),
        /* @__PURE__ */ h.jsx("option", { value: LD, children: "Monthly" })
      ] })
    ] }),
    ae !== xr && /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
      /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
        /* @__PURE__ */ h.jsx("label", { children: ae === eb ? "Every (days)" : ae === Ds ? "Every (weeks)" : "Every (months)" }),
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: "number",
            min: 1,
            max: 99,
            value: fe,
            onChange: (be) => j(Math.max(1, parseInt(be.target.value || "1", 10)))
          }
        )
      ] }),
      ae === Ds && /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
        /* @__PURE__ */ h.jsx("label", { children: "Repeat on" }),
        /* @__PURE__ */ h.jsx("div", { style: { display: "flex", gap: 6, flexWrap: "wrap" }, children: YD.map((be) => {
          const qe = (Q & be.mask) !== 0;
          return /* @__PURE__ */ h.jsx(
            "button",
            {
              type: "button",
              onClick: () => W((Ot) => qe ? Ot & ~be.mask : Ot | be.mask),
              style: {
                padding: "6px 10px",
                borderRadius: 6,
                border: "1px solid var(--color-border)",
                background: qe ? "var(--color-primary)" : "var(--color-bg)",
                color: qe ? "#fff" : "var(--color-text)",
                fontSize: 12,
                fontWeight: 600,
                cursor: "pointer",
                minWidth: 44
              },
              children: be.label
            },
            be.mask
          );
        }) }),
        /* @__PURE__ */ h.jsx("div", { style: { marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }, children: "Leave blank to repeat on the same weekday as the first occurrence." })
      ] }),
      /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
        /* @__PURE__ */ h.jsx("label", { children: "Ends" }),
        /* @__PURE__ */ h.jsxs("select", { value: se, onChange: (be) => we(Number(be.target.value)), children: [
          ne === 0 && /* @__PURE__ */ h.jsx("option", { value: Xd, children: "Never" }),
          /* @__PURE__ */ h.jsx("option", { value: Es, children: "After N occurrences" }),
          /* @__PURE__ */ h.jsx("option", { value: Zd, children: "On a date" })
        ] }),
        ne > 0 && /* @__PURE__ */ h.jsxs("div", { style: { marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }, children: [
          "Recurring series may extend up to ",
          ne,
          " days from the start."
        ] })
      ] }),
      se === Es && /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
        /* @__PURE__ */ h.jsx("label", { children: "Occurrences" }),
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: "number",
            min: 1,
            max: 999,
            value: M,
            onChange: (be) => T(Math.max(1, parseInt(be.target.value || "1", 10)))
          }
        )
      ] }),
      se === Zd && /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
        /* @__PURE__ */ h.jsx("label", { children: "End date" }),
        /* @__PURE__ */ h.jsx(
          cf,
          {
            selected: K,
            onChange: (be) => I(be),
            dateFormat: "MMM d, yyyy",
            placeholderText: "Select end date",
            minDate: O ?? /* @__PURE__ */ new Date(),
            maxDate: oe ?? void 0,
            className: "datepicker-input",
            wrapperClassName: "datepicker-wrapper",
            popperClassName: "datepicker-popper",
            popperPlacement: "bottom-start"
          }
        ),
        oe && /* @__PURE__ */ h.jsxs("div", { style: { marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }, children: [
          "Cannot extend past ",
          oe.toLocaleDateString(),
          "."
        ] })
      ] })
    ] }),
    g && /* @__PURE__ */ h.jsx("div", { className: "form-group", children: /* @__PURE__ */ h.jsxs("div", { className: "checkbox-row", children: [
      /* @__PURE__ */ h.jsx(
        "input",
        {
          id: "require-host-start",
          type: "checkbox",
          checked: ue,
          onChange: (be) => de(be.target.checked)
        }
      ),
      /* @__PURE__ */ h.jsxs("div", { className: "checkbox-text", children: [
        /* @__PURE__ */ h.jsx("label", { htmlFor: "require-host-start", children: "Require host to start the meeting" }),
        /* @__PURE__ */ h.jsx("div", { className: "checkbox-helper", children: "Joiners see a waiting page until you hit Start." })
      ] })
    ] }) }),
    c && /* @__PURE__ */ h.jsxs("div", { className: "form-group", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Duration" }),
      /* @__PURE__ */ h.jsxs("select", { value: L, onChange: (be) => P(Number(be.target.value)), children: [
        /* @__PURE__ */ h.jsx("option", { value: 15, children: "15 minutes" }),
        /* @__PURE__ */ h.jsx("option", { value: 30, children: "30 minutes" }),
        /* @__PURE__ */ h.jsx("option", { value: 45, children: "45 minutes" }),
        /* @__PURE__ */ h.jsx("option", { value: 60, children: "1 hour" }),
        /* @__PURE__ */ h.jsx("option", { value: 90, children: "1.5 hours" }),
        /* @__PURE__ */ h.jsx("option", { value: 120, children: "2 hours" }),
        /* @__PURE__ */ h.jsx("option", { value: 180, children: "3 hours" })
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "modal-actions", children: [
      /* @__PURE__ */ h.jsx("button", { type: "button", className: "modal-btn modal-btn-secondary", onClick: o, children: "Cancel" }),
      /* @__PURE__ */ h.jsx(
        "button",
        {
          type: "button",
          className: "modal-btn modal-btn-primary primary",
          onClick: Et,
          disabled: pe,
          children: pe ? "Saving..." : "Save"
        }
      )
    ] })
  ] }) });
}
let Ms = null;
function df() {
  if (window.JitsiMeetExternalAPI)
    return Promise.resolve();
  if (Ms)
    return Ms;
  const { jitsiServerBaseUrl: o } = Zo();
  return Ms = new Promise((i, n) => {
    const a = document.createElement("script");
    a.id = "jitsi-script", a.src = `https://${o}/external_api.js`, a.async = !0, a.onload = () => i(), a.onerror = () => n(new Error("Failed to load Jitsi script")), document.body.appendChild(a);
  }), Ms;
}
async function ff(o) {
  const i = mn();
  try {
    await df();
  } catch (a) {
    console.error("Failed to preload Jitsi", a);
  }
  const n = `${window.location.origin}${i}/oaticonnect/room/${encodeURIComponent(o)}`;
  window.open(
    n,
    "meetingWindow",
    "width=1400,height=900,resizable=yes"
  );
}
function tb() {
  const o = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  let i = "";
  for (let n = 0; n < 6; n++) i += o[Math.floor(Math.random() * o.length)];
  return i;
}
function UD({ onClose: o, isJoinMode: i = !1, meetingTitle: n }) {
  const a = N.useRef(null), l = N.useRef(null), [c, d] = N.useState([]), [p, m] = N.useState(""), [g, y] = N.useState(""), [b, _] = N.useState(!0), [k, w] = N.useState(!0), D = tc(), S = D?.preferences ?? null, O = D?.user?.role === "Admin", q = S?.defaultDurationMinutes || 60, L = !!S?.enableMeetingPassword, P = !!S?.requireHostStart, [F, J] = N.useState(""), [Z, ie] = N.useState(
    () => (Math.floor(Math.random() * 9e9) + 1e9).toString()
  );
  function ue(ee) {
    const ve = (ee || "").replace(/\D/g, "");
    return ve.length === 10 ? `${ve.slice(0, 3)} ${ve.slice(3, 6)} ${ve.slice(6)}` : ve.length === 9 ? `${ve.slice(0, 3)} ${ve.slice(3, 6)} ${ve.slice(6)}` : ee || "";
  }
  function de() {
    ie((Math.floor(Math.random() * 9e9) + 1e9).toString());
  }
  const [ne, $] = N.useState(""), [ae, le] = N.useState(q), [fe, j] = N.useState(""), [Q, W] = N.useState(!1), [se, we] = N.useState(!1), [M, T] = N.useState(!1), [K, I] = N.useState("");
  N.useEffect(() => {
    le(S?.defaultDurationMinutes || 60);
  }, [S?.defaultDurationMinutes]), N.useEffect(() => {
    if (!i && !F) {
      const ee = D?.user?.name?.trim() || "Untitled", ve = ac() || "OATIConnect";
      J(`${ee}'s ${ve} Meeting`);
    }
  }, [i, D?.user?.name]), N.useEffect(() => {
    !i && L && !fe && j(tb());
  }, [L, i]), N.useEffect(() => {
    async function ee() {
      const ve = await navigator.mediaDevices.enumerateDevices();
      d(ve);
      const Et = ve.find((qe) => qe.kind === "videoinput"), be = ve.find((qe) => qe.kind === "audioinput");
      Et && m(Et.deviceId), be && y(be.deviceId);
    }
    ee();
  }, []), N.useEffect(() => {
    async function ee() {
      try {
        oe();
        const ve = await navigator.mediaDevices.getUserMedia({
          video: b ? { deviceId: p ? { exact: p } : void 0 } : !1,
          audio: k ? { deviceId: g ? { exact: g } : void 0 } : !1
        });
        l.current = ve, a.current && (a.current.srcObject = ve);
      } catch (ve) {
        console.error("Preview failed", ve);
      }
    }
    return ee(), () => oe();
  }, [p, g, b, k]);
  function oe() {
    l.current?.getTracks().forEach((ee) => ee.stop()), l.current = null;
  }
  async function pe() {
    const ee = F.replace(/\s+/g, "");
    if (!ee) {
      I("Please enter meeting name or ID");
      return;
    }
    T(!0);
    try {
      const ve = await kD(ee);
      if (!ve.exists) {
        I("Meeting not found. Please check the meeting name/ID.");
        return;
      }
      if (ve.status === "Scheduled") {
        I("This meeting hasn't started yet. Please wait for the host to start it.");
        return;
      }
      if (ve.status === "Ended") {
        I("This meeting has ended.");
        return;
      }
      const Et = D?.user?.name?.trim() || "Guest", be = await SD(ee, Et, fe || null);
      if (!be.ok) {
        be.code === "PASSWORD_REQUIRED" ? I("This meeting requires a password.") : be.code === "INVALID_PASSWORD" ? I("Incorrect password. Please try again.") : I(be.error || "Could not join meeting.");
        return;
      }
      oe(), await ff(ee), o();
    } catch {
      I("Unable to verify meeting. Please try again.");
    } finally {
      T(!1);
    }
  }
  async function ke() {
    if (!F.trim()) {
      I("Please enter meeting name");
      return;
    }
    if (L && !fe.trim()) {
      I("Please enter a meeting password");
      return;
    }
    T(!0);
    try {
      oe();
      let ee;
      try {
        ee = Intl.DateTimeFormat().resolvedOptions().timeZone || void 0;
      } catch {
        ee = void 0;
      }
      const ve = await ky({
        title: F.trim(),
        meetingCode: Z,
        clientTimeZone: ee,
        description: ne.trim() || null,
        scheduledTimeUtc: (/* @__PURE__ */ new Date()).toISOString(),
        durationMinutes: ae,
        password: L ? fe || "" : void 0,
        requireHostStart: P ? se : void 0
      });
      if (!ve?.roomName) throw new Error("Meeting creation failed");
      await _D(ve.meetingId).catch(() => {
      }), await ff(ve.roomName), o();
    } catch (ee) {
      console.error("Start meeting failed", ee), I(ee?.isHostAuthDenied ? "Host session expired. Please refresh the page and sign in again." : "Unable to start meeting");
    } finally {
      T(!1);
    }
  }
  const Ke = c.filter((ee) => ee.kind === "videoinput"), ze = c.filter((ee) => ee.kind === "audioinput");
  return /* @__PURE__ */ h.jsx("div", { className: "modal-backdrop", children: /* @__PURE__ */ h.jsxs("div", { className: "preview-modal", children: [
    /* @__PURE__ */ h.jsx("button", { className: "modal-close-btn", onClick: o, "aria-label": "Close", type: "button", children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
      /* @__PURE__ */ h.jsx("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
      /* @__PURE__ */ h.jsx("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
    ] }) }),
    /* @__PURE__ */ h.jsx("h2", { children: n ?? (i ? "Join Meeting" : "Create Meeting") }),
    K && /* @__PURE__ */ h.jsxs("div", { className: "error-popup", children: [
      /* @__PURE__ */ h.jsx("p", { children: K }),
      /* @__PURE__ */ h.jsx("button", { onClick: () => I(""), children: "OK" })
    ] }),
    !i && /* @__PURE__ */ h.jsxs("div", { className: "meeting-name-field", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Meeting ID" }),
      /* @__PURE__ */ h.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "8px" }, children: [
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: "text",
            value: ue(Z),
            readOnly: !0,
            style: {
              fontFamily: "Consolas, Menlo, monospace",
              letterSpacing: "0.04em",
              fontSize: "15px",
              fontWeight: 600,
              flex: 1,
              background: "var(--color-surface-muted, #f3f4f6)",
              cursor: "default"
            }
          }
        ),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: de,
            title: "Generate a new Meeting ID",
            style: {
              padding: "6px 10px",
              borderRadius: "6px",
              border: "1px solid var(--color-border, #d1d5db)",
              background: "var(--color-surface, #fff)",
              cursor: "pointer",
              fontSize: "12px",
              color: "var(--color-text-muted, #6b7280)"
            },
            children: "Regenerate"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "meeting-name-field", children: [
      /* @__PURE__ */ h.jsx("label", { children: i ? "Meeting ID" : "Meeting Title" }),
      /* @__PURE__ */ h.jsx(
        "input",
        {
          type: "text",
          placeholder: i ? "Enter the meeting ID" : "What's this meeting about?",
          value: F,
          onChange: (ee) => J(ee.target.value)
        }
      )
    ] }),
    i && /* @__PURE__ */ h.jsxs("div", { className: "meeting-name-field", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Password" }),
      /* @__PURE__ */ h.jsxs("div", { style: { position: "relative" }, children: [
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: Q ? "text" : "password",
            maxLength: 100,
            placeholder: "Enter meeting password (if required)",
            value: fe,
            onChange: (ee) => j(ee.target.value),
            autoComplete: "new-password",
            autoCorrect: "off",
            autoCapitalize: "off",
            spellCheck: !1,
            "data-1p-ignore": "true",
            "data-lpignore": "true",
            "data-form-type": "other",
            style: { paddingRight: 38, width: "100%" }
          }
        ),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: () => W((ee) => !ee),
            "aria-label": Q ? "Hide password" : "Show password",
            title: Q ? "Hide password" : "Show password",
            style: {
              position: "absolute",
              top: "50%",
              right: 8,
              transform: "translateY(-50%)",
              background: "transparent",
              border: 0,
              padding: 4,
              cursor: "pointer",
              color: "var(--color-text-secondary, #6b7280)",
              display: "flex",
              alignItems: "center"
            },
            children: Q ? /* @__PURE__ */ h.jsxs(
              "svg",
              {
                width: "18",
                height: "18",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                children: [
                  /* @__PURE__ */ h.jsx("path", { d: "M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" }),
                  /* @__PURE__ */ h.jsx("path", { d: "M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" }),
                  /* @__PURE__ */ h.jsx("path", { d: "M14.12 14.12A3 3 0 1 1 9.88 9.88" }),
                  /* @__PURE__ */ h.jsx("line", { x1: "1", y1: "1", x2: "23", y2: "23" })
                ]
              }
            ) : /* @__PURE__ */ h.jsxs(
              "svg",
              {
                width: "18",
                height: "18",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                children: [
                  /* @__PURE__ */ h.jsx("path", { d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }),
                  /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "12", r: "3" })
                ]
              }
            )
          }
        )
      ] })
    ] }),
    !i && /* @__PURE__ */ h.jsxs("div", { className: "meeting-name-field", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Description (optional)" }),
      /* @__PURE__ */ h.jsx(
        "textarea",
        {
          placeholder: "Brief description / agenda",
          value: ne,
          onChange: (ee) => $(ee.target.value),
          rows: 2
        }
      )
    ] }),
    !i && L && /* @__PURE__ */ h.jsxs("div", { className: "meeting-name-field", children: [
      /* @__PURE__ */ h.jsxs("label", { children: [
        "Password ",
        /* @__PURE__ */ h.jsx("span", { style: { color: "#dc2626", fontSize: 11 }, children: "*" }),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: () => j(tb()),
            style: {
              marginLeft: 10,
              padding: "2px 8px",
              fontSize: 11,
              background: "transparent",
              border: "1px solid var(--color-border, #d1d5db)",
              borderRadius: 4,
              cursor: "pointer",
              color: "var(--color-text-secondary, #6b7280)"
            },
            title: "Generate a new random password",
            children: "Regenerate"
          }
        )
      ] }),
      /* @__PURE__ */ h.jsxs("div", { style: { position: "relative" }, children: [
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: Q ? "text" : "password",
            maxLength: 100,
            placeholder: "Required when password protection is enabled",
            required: !0,
            value: fe,
            onChange: (ee) => j(ee.target.value),
            autoComplete: "new-password",
            autoCorrect: "off",
            autoCapitalize: "off",
            spellCheck: !1,
            "data-1p-ignore": "true",
            "data-lpignore": "true",
            "data-form-type": "other",
            style: { paddingRight: 38, width: "100%" }
          }
        ),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: () => W((ee) => !ee),
            "aria-label": Q ? "Hide password" : "Show password",
            title: Q ? "Hide password" : "Show password",
            style: {
              position: "absolute",
              top: "50%",
              right: 8,
              transform: "translateY(-50%)",
              background: "transparent",
              border: 0,
              padding: 4,
              cursor: "pointer",
              color: "var(--color-text-secondary, #6b7280)",
              display: "flex",
              alignItems: "center"
            },
            children: Q ? /* @__PURE__ */ h.jsxs(
              "svg",
              {
                width: "18",
                height: "18",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                children: [
                  /* @__PURE__ */ h.jsx("path", { d: "M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" }),
                  /* @__PURE__ */ h.jsx("path", { d: "M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" }),
                  /* @__PURE__ */ h.jsx("path", { d: "M14.12 14.12A3 3 0 1 1 9.88 9.88" }),
                  /* @__PURE__ */ h.jsx("line", { x1: "1", y1: "1", x2: "23", y2: "23" })
                ]
              }
            ) : /* @__PURE__ */ h.jsxs(
              "svg",
              {
                width: "18",
                height: "18",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                children: [
                  /* @__PURE__ */ h.jsx("path", { d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }),
                  /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "12", r: "3" })
                ]
              }
            )
          }
        )
      ] })
    ] }),
    !i && P && /* @__PURE__ */ h.jsx("div", { className: "meeting-name-field", children: /* @__PURE__ */ h.jsxs("div", { className: "checkbox-row", children: [
      /* @__PURE__ */ h.jsx(
        "input",
        {
          id: "qc-require-host-start",
          type: "checkbox",
          checked: se,
          onChange: (ee) => we(ee.target.checked)
        }
      ),
      /* @__PURE__ */ h.jsx("label", { htmlFor: "qc-require-host-start", children: "Require host to start the meeting" })
    ] }) }),
    !i && O && /* @__PURE__ */ h.jsxs("div", { className: "meeting-name-field", children: [
      /* @__PURE__ */ h.jsx("label", { children: "Duration" }),
      /* @__PURE__ */ h.jsxs("select", { value: ae, onChange: (ee) => le(Number(ee.target.value)), children: [
        /* @__PURE__ */ h.jsx("option", { value: 15, children: "15 minutes" }),
        /* @__PURE__ */ h.jsx("option", { value: 30, children: "30 minutes" }),
        /* @__PURE__ */ h.jsx("option", { value: 45, children: "45 minutes" }),
        /* @__PURE__ */ h.jsx("option", { value: 60, children: "1 hour" }),
        /* @__PURE__ */ h.jsx("option", { value: 90, children: "1.5 hours" }),
        /* @__PURE__ */ h.jsx("option", { value: 120, children: "2 hours" }),
        /* @__PURE__ */ h.jsx("option", { value: 180, children: "3 hours" })
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "preview-toggles", children: [
      /* @__PURE__ */ h.jsxs("label", { children: [
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: "checkbox",
            checked: b,
            onChange: (ee) => _(ee.target.checked)
          }
        ),
        " Camera"
      ] }),
      /* @__PURE__ */ h.jsxs("label", { children: [
        /* @__PURE__ */ h.jsx(
          "input",
          {
            type: "checkbox",
            checked: k,
            onChange: (ee) => w(ee.target.checked)
          }
        ),
        " Microphone"
      ] })
    ] }),
    /* @__PURE__ */ h.jsx("div", { className: "preview-video-container", children: b ? /* @__PURE__ */ h.jsx("video", { ref: a, autoPlay: !0, playsInline: !0, muted: !0, className: "preview-video" }) : /* @__PURE__ */ h.jsx("div", { className: "camera-off", children: "Camera Off" }) }),
    /* @__PURE__ */ h.jsxs("div", { className: "preview-controls", children: [
      /* @__PURE__ */ h.jsxs("div", { className: "control-group", children: [
        /* @__PURE__ */ h.jsx("label", { children: "Camera" }),
        /* @__PURE__ */ h.jsx("select", { value: p, onChange: (ee) => m(ee.target.value), disabled: !b, children: Ke.map((ee) => /* @__PURE__ */ h.jsx("option", { value: ee.deviceId, children: ee.label || "Camera" }, ee.deviceId)) })
      ] }),
      /* @__PURE__ */ h.jsxs("div", { className: "control-group", children: [
        /* @__PURE__ */ h.jsx("label", { children: "Microphone" }),
        /* @__PURE__ */ h.jsx("select", { value: g, onChange: (ee) => y(ee.target.value), disabled: !k, children: ze.map((ee) => /* @__PURE__ */ h.jsx("option", { value: ee.deviceId, children: ee.label || "Microphone" }, ee.deviceId)) })
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "modal-actions", children: [
      /* @__PURE__ */ h.jsx("button", { type: "button", className: "modal-btn modal-btn-secondary", onClick: o, children: "Cancel" }),
      /* @__PURE__ */ h.jsx(
        "button",
        {
          type: "button",
          className: "modal-btn modal-btn-primary primary",
          disabled: M,
          onClick: () => i ? pe() : ke(),
          children: M ? "Starting..." : i ? "Join" : "Start"
        }
      )
    ] })
  ] }) });
}
const Kd = 10;
function BD(o, i) {
  const n = Date.now(), a = new Date(o).getTime(), l = a + (i > 0 ? i : 60) * 6e4;
  return n >= a && n <= l ? "ongoing" : a > n ? "upcoming" : "past";
}
function ab(o) {
  const i = o.recurrenceType ?? 0;
  if (!i) return null;
  const n = o.recurrenceInterval && o.recurrenceInterval > 1 ? o.recurrenceInterval : 1;
  if (i === 1) return n === 1 ? "Daily" : `Every ${n} days`;
  if (i === 2) {
    const a = o.recurrenceDaysOfWeekMask ?? 0;
    if (a > 0) {
      const l = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].filter((c, d) => (a & 1 << d) !== 0).join(",");
      return n === 1 ? `Weekly · ${l}` : `Every ${n}w · ${l}`;
    }
    return n === 1 ? "Weekly" : `Every ${n} weeks`;
  }
  return i === 3 ? n === 1 ? "Monthly" : `Every ${n} months` : null;
}
function Wd(o) {
  const i = (o ?? "").replace(/\D/g, "");
  return i.length === 10 ? `${i.slice(0, 3)} ${i.slice(3, 6)} ${i.slice(6)}` : i.length === 9 ? `${i.slice(0, 3)} ${i.slice(3, 6)} ${i.slice(6)}` : o ?? "";
}
function qD({ onViewParticipants: o }) {
  const i = Dy(), n = zb(), a = sb() != null, l = tc(), [c, d] = N.useState([]), [p, m] = N.useState(!0), [g, y] = N.useState(1), [b, _] = N.useState(/* @__PURE__ */ new Date()), [k, w] = N.useState(!1), [D, S] = N.useState(!1), [O, q] = N.useState(!1), [L, P] = N.useState(null), [F, J] = N.useState(null), [Z, ie] = N.useState(!1), [ue, de] = N.useState("");
  N.useEffect(() => {
    "requestIdleCallback" in window ? requestIdleCallback(() => df().catch(() => {
    })) : setTimeout(() => df().catch(() => {
    }), 2e3);
  }, []);
  async function ne() {
    m(!0);
    try {
      const T = await bD();
      d(T.filter((K) => K.isHost !== !1));
    } catch (T) {
      console.error("Failed to load meetings", T), d([]);
    } finally {
      m(!1);
    }
  }
  N.useEffect(() => {
    ne();
  }, []), N.useEffect(() => {
    y(1);
  }, [b]);
  const $ = c.filter((T) => uf(T.scheduledTimeUtc, i.timeZone, { year: "numeric", month: "2-digit", day: "2-digit" }) === uf(b, i.timeZone, { year: "numeric", month: "2-digit", day: "2-digit" })).sort((T, K) => new Date(T.scheduledTimeUtc).getTime() - new Date(K.scheduledTimeUtc).getTime()), ae = (g - 1) * Kd, le = $.slice(ae, ae + Kd), fe = Math.ceil($.length / Kd), j = b.toDateString() === (/* @__PURE__ */ new Date()).toDateString(), Q = b.toLocaleDateString(void 0, {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric"
  });
  function W(T) {
    navigator.clipboard.writeText(Wd(T)), n.success("Meeting ID copied to clipboard");
  }
  function se(T) {
    let K;
    try {
      K = Intl.DateTimeFormat().resolvedOptions().timeZone || void 0;
    } catch {
      K = void 0;
    }
    const I = K ? `?tz=${encodeURIComponent(K)}` : "", oe = `${mn()}/oaticonnect/calendar/${encodeURIComponent(T)}${I}`, pe = document.createElement("a");
    pe.href = oe, pe.download = `meet-${T}.ics`, document.body.appendChild(pe), pe.click(), document.body.removeChild(pe);
  }
  async function we(T) {
    const K = ac(), I = l?.user?.name?.trim() || "The host", pe = new Date(T.scheduledTimeUtc).getTime() + (T.durationMinutes || 60) * 6e4, ke = i.formatDateLong(T.scheduledTimeUtc);
    i.formatTime(T.scheduledTimeUtc);
    const Ke = i.formatTimeWithZone(new Date(pe));
    let ze;
    try {
      ze = new Intl.DateTimeFormat("en-GB", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: !1,
        timeZone: i.timeZone || void 0
      }).format(new Date(T.scheduledTimeUtc));
    } catch {
      ze = new Intl.DateTimeFormat("en-GB", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: !1
      }).format(new Date(T.scheduledTimeUtc));
    }
    const ee = `${ze} – ${Ke}`;
    let ve = "";
    try {
      ve = (await Zv(T.meetingId)).url;
    } catch (Na) {
      console.warn("[Home] could not fetch share link", Na);
    }
    const Et = l?.preferences?.webClientUrl?.trim(), be = Et && Et.length > 0 ? Et.replace(/\/+$/, "") : `${window.location.origin}${mn()}/oaticonnect/join`.replace(/\/+$/, ""), qe = T.title, Ot = "-".repeat(75), lt = "-".repeat(102), Xt = "-".repeat(39), Ta = "-".repeat(61), Ca = `Join meeting using ${K} Web Client`, Jn = Wd(T.meetingCode || T.title), Li = [
      Ot,
      `${I} is inviting you to ${K} meeting.`,
      Ot,
      "Meeting Details:",
      Xt,
      ` Topic: ${T.title}`,
      ` Date: ${ke}`,
      ` Time: ${ee}`,
      Xt,
      ` Meeting Id : ${Jn}`,
      T.password ? ` Password   : ${T.password}` : null,
      Xt,
      "",
      "Join meeting with link",
      Xt,
      `  ${ve || "(share link unavailable — please contact the meeting host)"}`,
      "",
      // Web-client heading is sandwiched between two innerLong ribbons,
      // making it visually distinct from the link-share section above.
      Ta,
      Ca,
      Ta,
      `  ${be}`,
      "  Enter the Meeting ID and password on that page to join from any browser.",
      lt,
      T.description ? "" : null,
      T.description ? T.description : null
    ].filter((Na) => Na !== null).join(`
`), zr = `mailto:?subject=${encodeURIComponent(qe)}&body=${encodeURIComponent(Li)}`, et = document.createElement("a");
    et.href = zr, et.target = "_blank", et.rel = "noopener", document.body.appendChild(et), et.click(), document.body.removeChild(et);
  }
  async function M(T) {
    try {
      const K = await Zv(T.meetingId);
      await navigator.clipboard.writeText(K.url), n.success("Join link copied to clipboard");
    } catch (K) {
      console.warn("[Home] could not copy share link", K), n.error("Couldn't copy the join link. Please try again.");
    }
  }
  return /* @__PURE__ */ h.jsxs("div", { className: `home${a ? " home-embedded" : ""}`, children: [
    /* @__PURE__ */ h.jsxs("div", { className: "home-actions", children: [
      /* @__PURE__ */ h.jsx(
        Vd,
        {
          label: "New Meeting",
          color: "orange",
          icon: "video",
          onClick: () => {
            q(!1), w(!0);
          }
        }
      ),
      /* @__PURE__ */ h.jsx(
        Vd,
        {
          label: "Join",
          color: "indigo",
          icon: "plus",
          onClick: () => {
            q(!0), w(!0);
          }
        }
      ),
      /* @__PURE__ */ h.jsx(
        Vd,
        {
          label: "Schedule",
          color: "indigo",
          icon: "calendar",
          onClick: () => S(!0)
        }
      )
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "home-card", children: [
      /* @__PURE__ */ h.jsxs("div", { className: "card-header-row", children: [
        /* @__PURE__ */ h.jsxs("div", { className: "timeline-date-heading", children: [
          j ? "Today" : "",
          " ",
          Q
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "zoom-toolbar", children: [
          /* @__PURE__ */ h.jsx(
            cf,
            {
              selected: b,
              onChange: (T) => T && _(T),
              dateFormat: "MMM d, yyyy",
              className: "datepicker-input home-date-input",
              wrapperClassName: "datepicker-wrapper home-date-wrapper",
              popperClassName: "datepicker-popper",
              popperPlacement: "bottom-end"
            }
          ),
          /* @__PURE__ */ h.jsx("button", { className: "icon-btn", onClick: () => {
            const T = new Date(b);
            T.setDate(T.getDate() - 1), _(T);
          }, children: "‹" }),
          /* @__PURE__ */ h.jsx("button", { className: "icon-btn", onClick: () => {
            const T = new Date(b);
            T.setDate(T.getDate() + 1), _(T);
          }, children: "›" }),
          /* @__PURE__ */ h.jsx("button", { className: "today-btn", onClick: () => _(/* @__PURE__ */ new Date()), children: "Today" })
        ] })
      ] }),
      /* @__PURE__ */ h.jsx("div", { className: "timeline-divider" }),
      p ? /* @__PURE__ */ h.jsx("p", { className: "muted", children: "Loading meetings..." }) : $.length === 0 ? /* @__PURE__ */ h.jsxs("div", { className: "empty-state-container", children: [
        /* @__PURE__ */ h.jsx("div", { className: "empty-state-icon", children: /* @__PURE__ */ h.jsxs("svg", { width: "48", height: "48", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", children: [
          /* @__PURE__ */ h.jsx("rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", ry: "2" }),
          /* @__PURE__ */ h.jsx("line", { x1: "16", y1: "2", x2: "16", y2: "6" }),
          /* @__PURE__ */ h.jsx("line", { x1: "8", y1: "2", x2: "8", y2: "6" }),
          /* @__PURE__ */ h.jsx("line", { x1: "3", y1: "10", x2: "21", y2: "10" })
        ] }) }),
        /* @__PURE__ */ h.jsx("p", { className: "empty-state-text", children: "No meetings scheduled" }),
        /* @__PURE__ */ h.jsx("button", { className: "btn btn-primary btn-sm", onClick: () => S(!0), children: "Schedule Meeting" })
      ] }) : /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
        /* @__PURE__ */ h.jsx("div", { className: "timeline-list", children: le.map((T) => {
          const K = (T.recurrenceType ?? 0) !== 0, I = K && T.nextOccurrenceUtc ? T.nextOccurrenceUtc : T.scheduledTimeUtc, oe = BD(I, T.durationMinutes), pe = i.formatTime(I), ke = K && T.nextOccurrenceUtc ? `Next: ${i.formatDateTimeLong(T.nextOccurrenceUtc)}` : null;
          return /* @__PURE__ */ h.jsxs("div", { className: `timeline-row ${oe}`, children: [
            /* @__PURE__ */ h.jsx("div", { className: "timeline-time", children: /* @__PURE__ */ h.jsx("span", { className: "timeline-time-text", children: pe }) }),
            /* @__PURE__ */ h.jsxs("div", { className: "timeline-connector", children: [
              /* @__PURE__ */ h.jsx("div", { className: `timeline-dot timeline-dot-${oe}` }),
              /* @__PURE__ */ h.jsx("div", { className: "timeline-line" })
            ] }),
            /* @__PURE__ */ h.jsxs("div", { className: "timeline-content", children: [
              /* @__PURE__ */ h.jsxs("div", { className: "timeline-content-main", children: [
                /* @__PURE__ */ h.jsxs("div", { className: "timeline-title-row", children: [
                  /* @__PURE__ */ h.jsx("span", { className: "timeline-title", children: T.title }),
                  /* @__PURE__ */ h.jsx("span", { className: "timeline-meeting-code", children: Wd(T.meetingCode) }),
                  /* @__PURE__ */ h.jsx(
                    "button",
                    {
                      type: "button",
                      className: "timeline-copy-btn",
                      title: "Copy meeting ID",
                      onClick: (Ke) => {
                        Ke.stopPropagation(), W(T.meetingCode);
                      },
                      children: /* @__PURE__ */ h.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                        /* @__PURE__ */ h.jsx("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2", ry: "2" }),
                        /* @__PURE__ */ h.jsx("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })
                      ] })
                    }
                  ),
                  /* @__PURE__ */ h.jsx("span", { className: `timeline-status-badge timeline-status-${oe}`, children: oe === "ongoing" ? "Live" : oe === "upcoming" ? "Scheduled" : "Ended" })
                ] }),
                /* @__PURE__ */ h.jsxs("div", { className: "timeline-meta", children: [
                  /* @__PURE__ */ h.jsxs("span", { className: "timeline-duration", children: [
                    T.durationMinutes || 60,
                    " min"
                  ] }),
                  ab(T) && /* @__PURE__ */ h.jsxs("span", { className: "timeline-recurrence-badge", title: "Recurring meeting", children: [
                    /* @__PURE__ */ h.jsxs(
                      "svg",
                      {
                        width: "11",
                        height: "11",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "2.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        children: [
                          /* @__PURE__ */ h.jsx("polyline", { points: "23 4 23 10 17 10" }),
                          /* @__PURE__ */ h.jsx("polyline", { points: "1 20 1 14 7 14" }),
                          /* @__PURE__ */ h.jsx("path", { d: "M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" })
                        ]
                      }
                    ),
                    ab(T)
                  ] }),
                  T.isHost === !1 && /* @__PURE__ */ h.jsx("span", { className: "timeline-invited-badge", title: "You were invited to this meeting", children: "Invited" })
                ] })
              ] }),
              ke && /* @__PURE__ */ h.jsx("div", { className: "timeline-next-occurrence", children: ke }),
              T.description && /* @__PURE__ */ h.jsx("div", { className: "timeline-description-col", children: T.description }),
              /* @__PURE__ */ h.jsx("div", { className: "timeline-actions", children: /* @__PURE__ */ h.jsxs("div", { className: "timeline-icon-actions", children: [
                /* @__PURE__ */ h.jsx(
                  "button",
                  {
                    type: "button",
                    className: "row-icon-btn row-icon-btn-primary",
                    title: "Start/Join meeting",
                    onClick: () => ff(T.meetingCode),
                    children: /* @__PURE__ */ h.jsx("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "currentColor", stroke: "none", children: /* @__PURE__ */ h.jsx("polygon", { points: "6 4 20 12 6 20 6 4" }) })
                  }
                ),
                /* @__PURE__ */ h.jsx(
                  "button",
                  {
                    type: "button",
                    className: "row-icon-btn",
                    title: "Download .ics calendar invite",
                    onClick: () => se(T.meetingCode),
                    children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                      /* @__PURE__ */ h.jsx("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }),
                      /* @__PURE__ */ h.jsx("polyline", { points: "7 10 12 15 17 10" }),
                      /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "15", x2: "12", y2: "3" })
                    ] })
                  }
                ),
                /* @__PURE__ */ h.jsx(
                  "button",
                  {
                    type: "button",
                    className: "row-icon-btn",
                    title: "Share via email (includes click-to-join link)",
                    onClick: () => we(T),
                    children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                      /* @__PURE__ */ h.jsx("path", { d: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" }),
                      /* @__PURE__ */ h.jsx("polyline", { points: "22,6 12,13 2,6" })
                    ] })
                  }
                ),
                T.isHost !== !1 && /* @__PURE__ */ h.jsx(
                  "button",
                  {
                    type: "button",
                    className: "row-icon-btn",
                    title: "Copy click-to-join link (host only)",
                    onClick: () => M(T),
                    children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                      /* @__PURE__ */ h.jsx("path", { d: "M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 0 0-7.07-7.07l-1.5 1.5" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M14 11a5 5 0 0 0-7.07 0l-3 3a5 5 0 0 0 7.07 7.07l1.5-1.5" })
                    ] })
                  }
                ),
                T.isHost !== !1 && o && /* @__PURE__ */ h.jsx(
                  "button",
                  {
                    type: "button",
                    className: "row-icon-btn",
                    title: "View participants",
                    onClick: () => o(T),
                    children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                      /* @__PURE__ */ h.jsx("path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" }),
                      /* @__PURE__ */ h.jsx("circle", { cx: "9", cy: "7", r: "4" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M22 21v-2a4 4 0 0 0-3-3.87" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M16 3.13a4 4 0 0 1 0 7.75" })
                    ] })
                  }
                ),
                T.isHost !== !1 && /* @__PURE__ */ h.jsx(
                  "button",
                  {
                    type: "button",
                    className: "row-icon-btn",
                    title: "Edit meeting",
                    onClick: () => {
                      P(T), S(!0);
                    },
                    children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                      /* @__PURE__ */ h.jsx("path", { d: "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" })
                    ] })
                  }
                ),
                T.isHost !== !1 && /* @__PURE__ */ h.jsx(
                  "button",
                  {
                    type: "button",
                    className: "row-icon-btn row-icon-btn-danger",
                    title: "Delete meeting",
                    onClick: () => {
                      de(""), J(T);
                    },
                    children: /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                      /* @__PURE__ */ h.jsx("polyline", { points: "3 6 5 6 21 6" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M10 11v6" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M14 11v6" }),
                      /* @__PURE__ */ h.jsx("path", { d: "M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2" })
                    ] })
                  }
                )
              ] }) })
            ] })
          ] }, T.meetingId);
        }) }),
        /* @__PURE__ */ h.jsxs("div", { className: "timeline-end-note", children: [
          "No more meetings ",
          j ? "today" : "on this day"
        ] }),
        fe > 1 && /* @__PURE__ */ h.jsxs("div", { className: "paging", children: [
          /* @__PURE__ */ h.jsx("button", { disabled: g === 1, onClick: () => y((T) => T - 1), children: "â† Prev" }),
          /* @__PURE__ */ h.jsxs("span", { children: [
            "Page ",
            g,
            " / ",
            fe
          ] }),
          /* @__PURE__ */ h.jsx("button", { disabled: g === fe, onClick: () => y((T) => T + 1), children: "Next â†’" })
        ] })
      ] })
    ] }),
    k && /* @__PURE__ */ h.jsx(
      UD,
      {
        isJoinMode: O,
        onClose: () => {
          w(!1), ne();
        }
      }
    ),
    D && /* @__PURE__ */ h.jsx(
      HD,
      {
        editMeeting: L ? {
          meetingId: L.meetingId,
          meetingCode: L.meetingCode,
          title: L.title,
          description: L.description ?? void 0,
          scheduledTimeUtc: L.scheduledTimeUtc,
          durationMinutes: L.durationMinutes,
          inviteeEmails: L.inviteeEmails,
          password: L.password,
          requireHostStart: L.requireHostStart,
          recurrenceType: L.recurrenceType,
          recurrenceInterval: L.recurrenceInterval,
          recurrenceDaysOfWeekMask: L.recurrenceDaysOfWeekMask,
          recurrenceEndType: L.recurrenceEndType,
          recurrenceEndCount: L.recurrenceEndCount,
          recurrenceEndDateUtc: L.recurrenceEndDateUtc
        } : void 0,
        onClose: () => {
          S(!1), P(null), ne();
        }
      }
    ),
    F && (() => {
      const T = (F.recurrenceType ?? 0) !== 0, K = F.nextOccurrenceUtc ? new Date(F.nextOccurrenceUtc) : null, I = T && F.isHost !== !1 && !!K, oe = K ? K.toLocaleString(void 0, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "";
      return /* @__PURE__ */ h.jsx("div", { className: "modal-backdrop", onClick: () => {
        Z || J(null);
      }, children: /* @__PURE__ */ h.jsxs("div", { className: "modal", onClick: (pe) => pe.stopPropagation(), style: { maxWidth: 480 }, children: [
        /* @__PURE__ */ h.jsx("h3", { style: { margin: "0 0 12px" }, children: I ? "Delete recurring meeting" : "Delete Meeting" }),
        /* @__PURE__ */ h.jsx("p", { style: { margin: "0 0 16px", color: "var(--color-text-secondary)" }, children: I ? /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
          /* @__PURE__ */ h.jsx("strong", { style: { color: "var(--color-text)" }, children: F.title }),
          " ",
          "is a recurring meeting. Cancel just the next occurrence on",
          " ",
          /* @__PURE__ */ h.jsx("strong", { style: { color: "var(--color-text)" }, children: oe }),
          ", or delete the whole series?"
        ] }) : /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
          "Are you sure you want to delete",
          " ",
          /* @__PURE__ */ h.jsx("strong", { style: { color: "var(--color-text)" }, children: F.title }),
          "? This cannot be undone."
        ] }) }),
        ue && /* @__PURE__ */ h.jsx("div", { style: { color: "var(--color-danger)", marginBottom: 12, fontSize: 13 }, children: ue }),
        /* @__PURE__ */ h.jsxs("div", { className: "modal-actions", style: { gap: 8, flexWrap: "wrap" }, children: [
          /* @__PURE__ */ h.jsx(
            "button",
            {
              className: "btn btn-secondary",
              disabled: Z,
              onClick: () => J(null),
              children: "Cancel"
            }
          ),
          I && /* @__PURE__ */ h.jsx(
            "button",
            {
              className: "btn btn-secondary",
              disabled: Z,
              onClick: async () => {
                ie(!0), de("");
                try {
                  await wD(F.meetingId, K.toISOString()), J(null), await ne(), n.success(`Cancelled the ${oe} occurrence`);
                } catch (pe) {
                  console.error("Cancel occurrence failed", pe), de("Failed to cancel this occurrence.");
                } finally {
                  ie(!1);
                }
              },
              children: Z ? "Working..." : "Cancel this occurrence"
            }
          ),
          /* @__PURE__ */ h.jsx(
            "button",
            {
              className: "btn btn-danger",
              disabled: Z,
              onClick: async () => {
                ie(!0), de("");
                try {
                  await xD(F.meetingId), J(null), await ne();
                } catch (pe) {
                  console.error("Delete failed", pe), de("Failed to delete meeting.");
                } finally {
                  ie(!1);
                }
              },
              children: Z ? "Deleting..." : I ? "Delete entire series" : "Delete"
            }
          )
        ] })
      ] }) });
    })()
  ] });
}
async function QD() {
  const o = await In.get("/oaticonnect/appconfig");
  return Array.isArray(o.data) ? o.data : [];
}
async function za(o) {
  return (await In.post("/oaticonnect/appconfig", o)).data;
}
const PD = [
  { key: "disablePreJoinPage", label: "Disable PreJoin page", desc: "Skip the prejoin step where users adjust mic/camera before joining." },
  { key: "audioOnly", label: "Audio only", desc: "No video sent or received — frees bandwidth for the audio call." },
  { key: "startWithAudioMuted", label: "Start with audio muted" },
  { key: "startWithCameraOff", label: "Start with camera off" },
  { key: "disableFaceCentering", label: "Disable face centering" },
  { key: "disableTileEnlargement", label: "Disable tile enlargement", desc: "Skip cropping/enlarging tile videos." },
  { key: "skipMediaPermissions", label: "Skip media permissions", desc: "Don't request mic/camera permissions on join." },
  { key: "disableNotifications", label: "Disable all notifications" }
], Ls = [
  "Microphone",
  "Camera",
  "Screenshare",
  "Chat",
  "RaiseHand",
  "Participants",
  "TileView",
  "ToggleCamera",
  "Hangup",
  "Profile",
  "Invite",
  "Settings",
  "Fullscreen",
  "Security",
  "ClosedCaptions",
  "Recording",
  "LiveStreaming",
  "ShareVideo",
  "ShareAudio",
  "NoiseSuppression",
  "Whiteboard",
  "Etherpad",
  "SelectBackground",
  "Help",
  "Filmstrip"
];
function nb() {
  const o = {};
  return Ls.forEach((i) => {
    o[i] = !0;
  }), {
    defaultCameraOn: !0,
    defaultMicOn: !0,
    defaultDurationMinutes: 60,
    meetingNameMode: "auto",
    enableMeetingPassword: !1,
    requireHostStart: !1,
    encryptedShareLink: !0,
    embedPasswordInLink: !1,
    recurringMaxDurationDays: 90,
    webClientUrl: "",
    disablePreJoinPage: !1,
    audioOnly: !1,
    startWithAudioMuted: !1,
    startWithCameraOff: !1,
    disableFaceCentering: !1,
    disableTileEnlargement: !1,
    skipMediaPermissions: !1,
    disableNotifications: !1,
    toolbarButtons: o
  };
}
function FD() {
  const { user: o, loading: i, refreshPreferences: n } = Ab(), a = o?.role === "Admin", [l, c] = N.useState("app-settings"), [d, p] = N.useState("general"), [m, g] = N.useState(""), [y, b] = N.useState(""), [_, k] = N.useState(!1), [w, D] = N.useState(!1), [S, O] = N.useState(null), [q, L] = N.useState(null), [P, F] = N.useState(!1), [J, Z] = N.useState(""), [ie, ue] = N.useState(""), [de, ne] = N.useState(""), [$, ae] = N.useState("App"), [le, fe] = N.useState(!1), [j, Q] = N.useState(!1), [W, se] = N.useState(null), [we, M] = N.useState(!1), [T, K] = N.useState(!0), [I, oe] = N.useState("system"), [pe, ke] = N.useState(!1), [Ke, ze] = N.useState(null), [ee, ve] = N.useState(nb), [Et, be] = N.useState(!0), [qe, Ot] = N.useState(!1), [lt, Xt] = N.useState(null);
  N.useEffect(() => {
    QD().then((re) => {
      const De = (pc) => re.find(($n) => $n.key === pc)?.value ?? "";
      g(De("App:Name") || "OATIConnect"), b(De("Jitsi:ServerBaseUrl")), F(De("Exchange:Enabled").toLowerCase() === "true"), Z(De("Exchange:TenantId")), ue(De("Exchange:ClientId")), ne(De("Exchange:ClientSecret"));
      const ya = De("Exchange:Mode");
      ae(ya === "Delegated" ? "Delegated" : "App");
      const fc = De("App:ShowClock").toLowerCase();
      M(fc === "true");
      const Yi = De("App:ShowThemeToggle").toLowerCase();
      K(Yi === "" ? !0 : Yi === "true");
      const Hi = De("App:DefaultTheme").toLowerCase();
      oe(Hi === "light" || Hi === "dark" ? Hi : "system");
    }).catch(() => {
    }), jb().then(ve).catch(() => ve(nb())).finally(() => be(!1));
  }, []);
  async function Ta() {
    ze(null), ke(!0);
    try {
      await za({
        key: "App:ShowClock",
        value: we ? "true" : "false",
        description: "Show the live clock in the top header (true/false)",
        category: "Header"
      }), await za({
        key: "App:ShowThemeToggle",
        value: T ? "true" : "false",
        description: "Show the dark/light theme toggle button in the top header (true/false)",
        category: "Header"
      }), await za({
        key: "App:DefaultTheme",
        value: I,
        description: "Initial theme: light, dark, or system (follows OS)",
        category: "Header"
      }), await Uw(), window.dispatchEvent(new CustomEvent("oaticonnect-config-updated")), ze({ kind: "ok", text: "Header settings saved." });
    } catch {
      ze({ kind: "err", text: "Failed to save header settings." });
    } finally {
      ke(!1);
    }
  }
  async function Ca() {
    se(null), fe(!0);
    try {
      await za({
        key: "Exchange:Enabled",
        value: P ? "true" : "false",
        description: "Whether Outlook/Exchange integration is enabled",
        category: "Exchange"
      }), await za({
        key: "Exchange:TenantId",
        value: J,
        description: "Azure AD tenant id (GUID)",
        category: "Exchange"
      }), await za({
        key: "Exchange:ClientId",
        value: ie,
        description: "Azure AD app client id",
        category: "Exchange"
      }), await za({
        key: "Exchange:ClientSecret",
        value: de,
        description: "Azure AD app client secret",
        category: "Exchange"
      }), await za({
        key: "Exchange:Mode",
        value: $,
        description: "Auth mode: App (server creds) or Delegated (per-user)",
        category: "Exchange"
      }), se({ kind: "ok", text: "Exchange settings saved." });
    } catch {
      se({ kind: "err", text: "Failed to save Exchange settings." });
    } finally {
      fe(!1);
    }
  }
  async function Jn() {
    se(null), Q(!0);
    try {
      const re = await MD();
      se({ kind: re.success ? "ok" : "err", text: re.message });
    } catch {
      se({ kind: "err", text: "Test connection failed." });
    } finally {
      Q(!1);
    }
  }
  async function Rr() {
    O(null), k(!0);
    try {
      await za({
        key: "App:Name",
        value: m,
        description: "Display name of the application",
        category: "Branding"
      }), O({ kind: "ok", text: "Saved. Refresh the page to see the new name everywhere." });
    } catch {
      O({ kind: "err", text: "Failed to save app name." });
    } finally {
      k(!1);
    }
  }
  async function Li() {
    L(null), D(!0);
    try {
      await za({
        key: "Jitsi:ServerBaseUrl",
        value: y,
        description: "Base URL for the Jitsi server",
        category: "Jitsi"
      }), L({ kind: "ok", text: "Saved." });
    } catch {
      L({ kind: "err", text: "Failed to save Jitsi server URL." });
    } finally {
      D(!1);
    }
  }
  async function zr() {
    Xt(null), Ot(!0);
    try {
      await Rw(ee), await n(), Xt({ kind: "ok", text: "Preferences saved." });
    } catch {
      Xt({ kind: "err", text: "Failed to save preferences." });
    } finally {
      Ot(!1);
    }
  }
  if (i)
    return /* @__PURE__ */ h.jsx("div", { className: "settings-loading", children: /* @__PURE__ */ h.jsx("div", { className: "spinner" }) });
  const et = a ? [{ key: "app-settings", label: "App Settings" }, { key: "preferences", label: "Meeting Preferences" }] : [{ key: "preferences", label: "Meeting Preferences" }], Na = et.some((re) => re.key === l) ? l : et[0].key;
  return /* @__PURE__ */ h.jsxs("div", { className: "settings-page", children: [
    /* @__PURE__ */ h.jsx("h1", { children: "Settings" }),
    /* @__PURE__ */ h.jsx("div", { className: "settings-tabs", children: et.map((re) => /* @__PURE__ */ h.jsx(
      "button",
      {
        className: `settings-tab ${Na === re.key ? "settings-tab-active" : ""}`,
        onClick: () => c(re.key),
        children: re.label
      },
      re.key
    )) }),
    Na === "app-settings" && /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
      /* @__PURE__ */ h.jsxs("div", { className: "settings-section", children: [
        /* @__PURE__ */ h.jsx("h2", { className: "settings-section-title", children: "App Settings" }),
        S && /* @__PURE__ */ h.jsx("div", { className: S.kind === "ok" ? "settings-success" : "settings-error", children: S.text }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "App Name" }),
          /* @__PURE__ */ h.jsx(
            "input",
            {
              className: "input",
              placeholder: "e.g. OATIConnect",
              value: m,
              onChange: (re) => g(re.target.value)
            }
          ),
          /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", style: { marginTop: 6 }, children: "Display name shown in nav, login pages, and the desktop app window title." })
        ] }),
        /* @__PURE__ */ h.jsx("div", { className: "settings-actions", children: /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            className: "settings-btn settings-btn-primary",
            disabled: _ || !m.trim(),
            onClick: Rr,
            children: _ ? "Saving..." : "Save App Name"
          }
        ) }),
        /* @__PURE__ */ h.jsx("div", { style: { height: 1, background: "var(--color-border)", margin: "var(--space-4) 0" } }),
        q && /* @__PURE__ */ h.jsx("div", { className: q.kind === "ok" ? "settings-success" : "settings-error", children: q.text }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Jitsi Server URL" }),
          /* @__PURE__ */ h.jsx(
            "input",
            {
              className: "input",
              placeholder: "e.g. meet.example.com",
              value: y,
              onChange: (re) => b(re.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ h.jsx("div", { className: "settings-actions", children: /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            className: "settings-btn settings-btn-primary",
            disabled: w,
            onClick: Li,
            children: w ? "Saving..." : "Save"
          }
        ) })
      ] }),
      /* @__PURE__ */ h.jsxs("div", { className: "settings-section", children: [
        /* @__PURE__ */ h.jsx("h2", { className: "settings-section-title", children: "Header Display" }),
        /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", style: { marginBottom: "var(--space-3)" }, children: "Control what shows up in the top bar (clock, theme toggle) and the initial light/dark theme." }),
        Ke && /* @__PURE__ */ h.jsx("div", { className: Ke.kind === "ok" ? "settings-success" : "settings-error", children: Ke.text }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-row", children: [
          /* @__PURE__ */ h.jsxs("div", { children: [
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-label", children: "Show clock" }),
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", children: "Display the live ticking clock + date in the top header." })
          ] }),
          /* @__PURE__ */ h.jsxs("label", { className: "toggle-switch", children: [
            /* @__PURE__ */ h.jsx(
              "input",
              {
                type: "checkbox",
                checked: we,
                onChange: (re) => M(re.target.checked)
              }
            ),
            /* @__PURE__ */ h.jsx("span", { className: "toggle-slider" })
          ] })
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-row", children: [
          /* @__PURE__ */ h.jsxs("div", { children: [
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-label", children: "Show theme toggle" }),
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", children: "Show the sun/moon button so users can flip light/dark on demand." })
          ] }),
          /* @__PURE__ */ h.jsxs("label", { className: "toggle-switch", children: [
            /* @__PURE__ */ h.jsx(
              "input",
              {
                type: "checkbox",
                checked: T,
                onChange: (re) => K(re.target.checked)
              }
            ),
            /* @__PURE__ */ h.jsx("span", { className: "toggle-slider" })
          ] })
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Default theme" }),
          /* @__PURE__ */ h.jsxs(
            "select",
            {
              className: "input",
              value: I,
              onChange: (re) => oe(re.target.value),
              children: [
                /* @__PURE__ */ h.jsx("option", { value: "system", children: "System (follow OS preference)" }),
                /* @__PURE__ */ h.jsx("option", { value: "light", children: "Light" }),
                /* @__PURE__ */ h.jsx("option", { value: "dark", children: "Dark" })
              ]
            }
          ),
          /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", style: { marginTop: 6 }, children: "Initial theme on first load. A user's manual toggle persists in their browser and overrides this." })
        ] }),
        /* @__PURE__ */ h.jsx("div", { className: "settings-actions", children: /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            className: "settings-btn settings-btn-primary",
            disabled: pe,
            onClick: Ta,
            children: pe ? "Saving..." : "Save Header settings"
          }
        ) })
      ] }),
      /* @__PURE__ */ h.jsxs("div", { className: "settings-section", children: [
        /* @__PURE__ */ h.jsx("h2", { className: "settings-section-title", children: "Outlook / Exchange Integration" }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-desc", style: { marginBottom: "var(--space-3)" }, children: [
          "Read distribution lists, contacts, and users from Microsoft 365 / Exchange so meeting hosts can invite groups. The invite picker on the Schedule meeting form only appears when this is enabled. ",
          /* @__PURE__ */ h.jsx("em", { children: "Phase 1: form only — Microsoft Graph wiring lands in a follow-up." })
        ] }),
        W && /* @__PURE__ */ h.jsx("div", { className: W.kind === "ok" ? "settings-success" : "settings-error", children: W.text }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-row", children: [
          /* @__PURE__ */ h.jsxs("div", { children: [
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-label", children: "Enable Exchange integration" }),
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", children: "When off, OATIConnect ignores all Exchange settings below." })
          ] }),
          /* @__PURE__ */ h.jsxs("label", { className: "toggle-switch", children: [
            /* @__PURE__ */ h.jsx(
              "input",
              {
                type: "checkbox",
                checked: P,
                onChange: (re) => F(re.target.checked)
              }
            ),
            /* @__PURE__ */ h.jsx("span", { className: "toggle-slider" })
          ] })
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Tenant ID" }),
          /* @__PURE__ */ h.jsx(
            "input",
            {
              className: "input",
              placeholder: "00000000-0000-0000-0000-000000000000",
              value: J,
              onChange: (re) => Z(re.target.value),
              disabled: !P
            }
          )
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Client ID" }),
          /* @__PURE__ */ h.jsx(
            "input",
            {
              className: "input",
              placeholder: "00000000-0000-0000-0000-000000000000",
              value: ie,
              onChange: (re) => ue(re.target.value),
              disabled: !P
            }
          )
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Client Secret" }),
          /* @__PURE__ */ h.jsx(
            "input",
            {
              className: "input",
              type: "password",
              placeholder: "••••••••",
              value: de,
              onChange: (re) => ne(re.target.value),
              disabled: !P
            }
          ),
          /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-desc", style: { marginTop: 6 }, children: [
            "Stored in ",
            /* @__PURE__ */ h.jsx("code", { children: "OATIConnect_Configs" }),
            ". Treat the database row as a secret."
          ] })
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Auth Mode" }),
          /* @__PURE__ */ h.jsxs(
            "select",
            {
              className: "input",
              value: $,
              onChange: (re) => ae(re.target.value),
              disabled: !P,
              children: [
                /* @__PURE__ */ h.jsx("option", { value: "App", children: "App (server credentials — sees all org groups)" }),
                /* @__PURE__ */ h.jsx("option", { value: "Delegated", children: "Delegated (per-user — only that user's groups)" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-actions", children: [
          /* @__PURE__ */ h.jsx(
            "button",
            {
              type: "button",
              className: "settings-btn settings-btn-secondary",
              disabled: j || !P,
              onClick: Jn,
              children: j ? "Testing..." : "Test connection"
            }
          ),
          /* @__PURE__ */ h.jsx(
            "button",
            {
              type: "button",
              className: "settings-btn settings-btn-primary",
              disabled: le,
              onClick: Ca,
              children: le ? "Saving..." : "Save Exchange settings"
            }
          )
        ] })
      ] })
    ] }),
    Na === "preferences" && /* @__PURE__ */ h.jsx("div", { className: "settings-section", children: Et ? /* @__PURE__ */ h.jsx("div", { className: "settings-loading", children: /* @__PURE__ */ h.jsx("div", { className: "spinner" }) }) : /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
      /* @__PURE__ */ h.jsxs("div", { className: "prefs-sticky-header", children: [
        /* @__PURE__ */ h.jsxs("div", { className: "prefs-sticky-title-row", children: [
          /* @__PURE__ */ h.jsx("h2", { className: "settings-section-title prefs-sticky-title", children: "Meeting Preferences" }),
          /* @__PURE__ */ h.jsx(
            "button",
            {
              type: "button",
              className: "settings-btn settings-btn-primary",
              disabled: qe,
              onClick: zr,
              children: qe ? "Saving..." : "Save Preferences"
            }
          )
        ] }),
        /* @__PURE__ */ h.jsx("div", { className: "prefs-subtabs", children: [
          { key: "general", label: "General" },
          { key: "jitsi", label: "Jitsi Features" },
          { key: "toolbar", label: "Toolbar Buttons" }
        ].map((re) => /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            className: `prefs-subtab ${d === re.key ? "prefs-subtab-active" : ""}`,
            onClick: () => p(re.key),
            children: re.label
          },
          re.key
        )) })
      ] }),
      lt && /* @__PURE__ */ h.jsx("div", { className: lt.kind === "ok" ? "settings-success" : "settings-error", children: lt.text }),
      d === "general" && /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Meeting Name Mode" }),
          /* @__PURE__ */ h.jsxs(
            "select",
            {
              className: "input",
              value: ee.meetingNameMode,
              onChange: (re) => ve((De) => ({ ...De, meetingNameMode: re.target.value })),
              children: [
                /* @__PURE__ */ h.jsx("option", { value: "auto", children: "Auto-generate (Zoom-style meeting ID)" }),
                /* @__PURE__ */ h.jsx("option", { value: "manual", children: "Manual (enter meeting name)" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-form-group", children: [
          /* @__PURE__ */ h.jsx("label", { className: "label", children: "Default Meeting Duration" }),
          /* @__PURE__ */ h.jsxs(
            "select",
            {
              className: "input",
              value: ee.defaultDurationMinutes,
              onChange: (re) => ve((De) => ({ ...De, defaultDurationMinutes: Number(re.target.value) })),
              children: [
                /* @__PURE__ */ h.jsx("option", { value: 15, children: "15 minutes" }),
                /* @__PURE__ */ h.jsx("option", { value: 30, children: "30 minutes" }),
                /* @__PURE__ */ h.jsx("option", { value: 45, children: "45 minutes" }),
                /* @__PURE__ */ h.jsx("option", { value: 60, children: "1 hour" }),
                /* @__PURE__ */ h.jsx("option", { value: 90, children: "1.5 hours" }),
                /* @__PURE__ */ h.jsx("option", { value: 120, children: "2 hours" }),
                /* @__PURE__ */ h.jsx("option", { value: 180, children: "3 hours" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ h.jsx(
          Vn,
          {
            label: "Camera",
            desc: "Turn camera on by default when joining meetings",
            checked: ee.defaultCameraOn,
            onChange: (re) => ve((De) => ({ ...De, defaultCameraOn: re }))
          }
        ),
        /* @__PURE__ */ h.jsx(
          Vn,
          {
            label: "Microphone",
            desc: "Turn microphone on by default when joining meetings",
            checked: ee.defaultMicOn,
            onChange: (re) => ve((De) => ({ ...De, defaultMicOn: re }))
          }
        ),
        /* @__PURE__ */ h.jsx(
          Vn,
          {
            label: "Enable meeting password",
            desc: "Let hosts set a join password on each meeting. Recipients are asked for the password on the share-link prejoin page and Jitsi locks the room with it.",
            checked: ee.enableMeetingPassword,
            onChange: (re) => ve((De) => ({ ...De, enableMeetingPassword: re }))
          }
        ),
        /* @__PURE__ */ h.jsx(
          Vn,
          {
            label: "Require host to start meeting",
            desc: "Block share-link joiners until the host hits Start. They see a Zoom-style waiting page that auto-resumes the moment the meeting goes live.",
            checked: ee.requireHostStart,
            onChange: (re) => ve((De) => ({ ...De, requireHostStart: re }))
          }
        ),
        /* @__PURE__ */ h.jsx(
          Vn,
          {
            label: "Enable encrypted meeting URL",
            desc: "When on, share links use an opaque encrypted token (safer to share publicly, revocable by rotating the key). Turn off to share simple URLs like /oaticonnect/j/377401626 so recipients can read or type the meeting code directly.",
            checked: ee.encryptedShareLink,
            onChange: (re) => ve((De) => ({ ...De, encryptedShareLink: re }))
          }
        ),
        /* @__PURE__ */ h.jsx(
          Vn,
          {
            label: "Embed password in encrypted meeting link",
            desc: "Seal the meeting password into the encrypted token so recipients click the link and skip the password prompt. Only used with encrypted URLs; plain code URLs never carry secrets. Recommended when the password is shared out-of-band as a backup.",
            checked: ee.embedPasswordInLink,
            onChange: (re) => ve((De) => ({ ...De, embedPasswordInLink: re }))
          }
        ),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-row", children: [
          /* @__PURE__ */ h.jsxs("div", { children: [
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-label", children: "Recurring meeting max duration (days)" }),
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", children: 'Hard ceiling on how far a recurring series may extend from its start date. Hides the "Never" end-condition in the Schedule form. Set to 0 to disable the cap (legacy behaviour).' })
          ] }),
          /* @__PURE__ */ h.jsx(
            "input",
            {
              type: "number",
              min: 0,
              max: 3650,
              value: ee.recurringMaxDurationDays,
              onChange: (re) => ve((De) => ({ ...De, recurringMaxDurationDays: Math.max(0, parseInt(re.target.value || "0", 10)) })),
              className: "input",
              style: { width: 100 }
            }
          )
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-row", children: [
          /* @__PURE__ */ h.jsxs("div", { children: [
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-label", children: "Web client URL" }),
            /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", children: "Branded URL for the web join page printed in invitation emails + .ics files (recipients without the one-click link can paste this and type the meeting ID). Leave blank to use the host's own /oaticonnect/join." })
          ] }),
          /* @__PURE__ */ h.jsx(
            "input",
            {
              type: "text",
              placeholder: "https://meet.example.com/join",
              value: ee.webClientUrl,
              onChange: (re) => ve((De) => ({ ...De, webClientUrl: re.target.value })),
              className: "input",
              style: { width: 280 }
            }
          )
        ] })
      ] }),
      d === "jitsi" && /* @__PURE__ */ h.jsx(h.Fragment, { children: PD.map((re) => /* @__PURE__ */ h.jsx(
        Vn,
        {
          label: re.label,
          desc: re.desc,
          checked: !!ee[re.key],
          onChange: (De) => ve((ya) => ({ ...ya, [re.key]: De }))
        },
        re.key
      )) }),
      d === "toolbar" && /* @__PURE__ */ h.jsxs(h.Fragment, { children: [
        /* @__PURE__ */ h.jsxs("div", { className: "prefs-bulk-actions", children: [
          /* @__PURE__ */ h.jsx(
            "button",
            {
              type: "button",
              className: "settings-btn settings-btn-secondary",
              onClick: () => ve((re) => ({ ...re, toolbarButtons: Object.fromEntries(Ls.map((De) => [De, !0])) })),
              children: "Enable All"
            }
          ),
          /* @__PURE__ */ h.jsx(
            "button",
            {
              type: "button",
              className: "settings-btn settings-btn-secondary",
              onClick: () => ve((re) => ({ ...re, toolbarButtons: Object.fromEntries(Ls.map((De) => [De, !1])) })),
              children: "Disable All"
            }
          )
        ] }),
        /* @__PURE__ */ h.jsx("div", { className: "toolbar-buttons-grid", children: Ls.map((re) => /* @__PURE__ */ h.jsx(
          Vn,
          {
            label: re,
            checked: ee.toolbarButtons?.[re] ?? !0,
            onChange: (De) => ve((ya) => ({ ...ya, toolbarButtons: { ...ya.toolbarButtons ?? {}, [re]: De } }))
          },
          re
        )) })
      ] }),
      /* @__PURE__ */ h.jsx("div", { className: "settings-actions", children: /* @__PURE__ */ h.jsx(
        "button",
        {
          type: "button",
          className: "settings-btn settings-btn-primary",
          disabled: qe,
          onClick: zr,
          children: qe ? "Saving..." : "Save Preferences"
        }
      ) })
    ] }) })
  ] });
}
function Vn({
  label: o,
  desc: i,
  checked: n,
  onChange: a
}) {
  return /* @__PURE__ */ h.jsxs("div", { className: "settings-toggle-row", children: [
    /* @__PURE__ */ h.jsxs("div", { children: [
      /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-label", children: o }),
      i && /* @__PURE__ */ h.jsx("div", { className: "settings-toggle-desc", children: i })
    ] }),
    /* @__PURE__ */ h.jsxs("label", { className: "toggle-switch", children: [
      /* @__PURE__ */ h.jsx("input", { type: "checkbox", checked: n, onChange: (l) => a(l.target.checked) }),
      /* @__PURE__ */ h.jsx("span", { className: "toggle-slider" })
    ] })
  ] });
}
function VD(o) {
  const i = (o || "").trim().split(/\s+/).filter(Boolean);
  return i.length === 0 ? "?" : i.length === 1 ? i[0].slice(0, 2).toUpperCase() : (i[0][0] + i[i.length - 1][0]).toUpperCase();
}
function rb(o) {
  let i = 0;
  for (let n = 0; n < o.length; n++) i = i * 31 + o.charCodeAt(n) >>> 0;
  return i % 360;
}
function ib(o) {
  const i = new Date(o).getTime();
  if (Number.isNaN(i)) return "";
  const n = Math.max(0, Math.floor((Date.now() - i) / 1e3));
  return n < 45 ? "just now" : n < 90 ? "1 min ago" : n < 3600 ? `${Math.round(n / 60)} min ago` : n < 5400 ? "1 hr ago" : n < 86400 ? `${Math.round(n / 3600)} hr ago` : n < 86400 * 2 ? "yesterday" : n < 86400 * 30 ? `${Math.round(n / 86400)} d ago` : new Date(o).toLocaleDateString();
}
function GD({ meeting: o, onClose: i }) {
  const n = Dy(), [a, l] = N.useState([]), [c, d] = N.useState(!0), [p, m] = N.useState(null);
  N.useEffect(() => {
    let b = !1;
    return d(!0), m(null), DD(o.meetingId).then((_) => {
      b || l(_);
    }).catch(() => {
      b || m("Could not load participants.");
    }).finally(() => {
      b || d(!1);
    }), () => {
      b = !0;
    };
  }, [o.meetingId]);
  const g = Array.from(new Map(a.map((b) => [b.userId, b])).values()), y = a.length > 0 ? a.reduce((b, _) => new Date(b.joinedAtUtc) > new Date(_.joinedAtUtc) ? b : _) : null;
  return /* @__PURE__ */ h.jsxs("div", { className: "participants-page", children: [
    /* @__PURE__ */ h.jsxs(
      "button",
      {
        className: "participants-back",
        onClick: i,
        type: "button",
        children: [
          /* @__PURE__ */ h.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ h.jsx("path", { d: "M19 12H5" }),
            /* @__PURE__ */ h.jsx("path", { d: "m12 19-7-7 7-7" })
          ] }),
          /* @__PURE__ */ h.jsx("span", { children: "Back to meetings" })
        ]
      }
    ),
    /* @__PURE__ */ h.jsxs("div", { className: "participants-hero", children: [
      /* @__PURE__ */ h.jsxs("div", { className: "participants-hero-main", children: [
        /* @__PURE__ */ h.jsx("div", { className: "participants-hero-eyebrow", children: "Participants" }),
        /* @__PURE__ */ h.jsx("h1", { className: "participants-hero-title", children: o.title }),
        /* @__PURE__ */ h.jsxs("div", { className: "participants-hero-meta", children: [
          /* @__PURE__ */ h.jsx("span", { children: n.formatDateTimeLong(o.scheduledTimeUtc) }),
          /* @__PURE__ */ h.jsx("span", { className: "participants-hero-dot", children: "Â·" }),
          /* @__PURE__ */ h.jsxs("span", { children: [
            o.durationMinutes || 60,
            " min"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ h.jsxs("div", { className: "participants-stats", children: [
        /* @__PURE__ */ h.jsxs("div", { className: "participants-stat", children: [
          /* @__PURE__ */ h.jsx("div", { className: "participants-stat-value", children: a.length }),
          /* @__PURE__ */ h.jsx("div", { className: "participants-stat-label", children: "Total joins" })
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "participants-stat", children: [
          /* @__PURE__ */ h.jsx("div", { className: "participants-stat-value", children: g.length }),
          /* @__PURE__ */ h.jsx("div", { className: "participants-stat-label", children: "Unique users" })
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "participants-stat", children: [
          /* @__PURE__ */ h.jsx("div", { className: "participants-stat-value", children: y ? ib(y.joinedAtUtc) : "—" }),
          /* @__PURE__ */ h.jsx("div", { className: "participants-stat-label", children: "Last join" })
        ] })
      ] })
    ] }),
    c ? /* @__PURE__ */ h.jsxs("div", { className: "participants-state participants-state-loading", children: [
      /* @__PURE__ */ h.jsx("div", { className: "spinner" }),
      /* @__PURE__ */ h.jsx("p", { children: "Loading participants…" })
    ] }) : p ? /* @__PURE__ */ h.jsxs("div", { className: "participants-state participants-state-error", children: [
      /* @__PURE__ */ h.jsx("div", { className: "participants-state-icon", "aria-hidden": "true", children: /* @__PURE__ */ h.jsxs("svg", { width: "32", height: "32", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
        /* @__PURE__ */ h.jsx("path", { d: "M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" }),
        /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "9", x2: "12", y2: "13" }),
        /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "17", x2: "12.01", y2: "17" })
      ] }) }),
      /* @__PURE__ */ h.jsx("p", { children: p })
    ] }) : a.length === 0 ? /* @__PURE__ */ h.jsxs("div", { className: "participants-state", children: [
      /* @__PURE__ */ h.jsx("div", { className: "participants-state-icon", children: /* @__PURE__ */ h.jsxs("svg", { width: "48", height: "48", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", children: [
        /* @__PURE__ */ h.jsx("path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" }),
        /* @__PURE__ */ h.jsx("circle", { cx: "9", cy: "7", r: "4" }),
        /* @__PURE__ */ h.jsx("path", { d: "M22 21v-2a4 4 0 0 0-3-3.87" }),
        /* @__PURE__ */ h.jsx("path", { d: "M16 3.13a4 4 0 0 1 0 7.75" })
      ] }) }),
      /* @__PURE__ */ h.jsx("p", { className: "participants-state-title", children: "No one has joined yet" }),
      /* @__PURE__ */ h.jsx("p", { className: "participants-state-desc", children: "Join events appear here as soon as anyone enters the meeting." })
    ] }) : /* @__PURE__ */ h.jsx("div", { className: "participants-list", children: a.slice().sort((b, _) => new Date(_.joinedAtUtc).getTime() - new Date(b.joinedAtUtc).getTime()).map((b) => {
      const _ = b.email || b.name || String(b.userId);
      return /* @__PURE__ */ h.jsxs("div", { className: "participant-row", children: [
        /* @__PURE__ */ h.jsx(
          "div",
          {
            className: "participant-avatar",
            style: {
              background: `linear-gradient(135deg, hsl(${rb(_)}, 60%, 45%), hsl(${(rb(_) + 30) % 360}, 65%, 35%))`
            },
            children: VD(b.name || b.email)
          }
        ),
        /* @__PURE__ */ h.jsxs("div", { className: "participant-id", children: [
          /* @__PURE__ */ h.jsx("div", { className: "participant-name", children: b.name || "(no name)" }),
          b.email && /* @__PURE__ */ h.jsx("div", { className: "participant-email", children: b.email })
        ] }),
        /* @__PURE__ */ h.jsxs("div", { className: "participant-time", children: [
          /* @__PURE__ */ h.jsx("div", { className: "participant-time-rel", children: ib(b.joinedAtUtc) }),
          /* @__PURE__ */ h.jsx("div", { className: "participant-time-abs", children: n.formatDateTimeLong(b.joinedAtUtc) })
        ] })
      ] }, b.id);
    }) })
  ] });
}
function XD({ theme: o, onToggle: i }) {
  return /* @__PURE__ */ h.jsx(
    "button",
    {
      className: "nav-tab-btn",
      onClick: i,
      title: o === "dark" ? "Switch to Light mode" : "Switch to Dark mode",
      style: { display: "flex", alignItems: "center", gap: 6 },
      children: o === "dark" ? /* @__PURE__ */ h.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
        /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "12", r: "5" }),
        /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "1", x2: "12", y2: "3" }),
        /* @__PURE__ */ h.jsx("line", { x1: "12", y1: "21", x2: "12", y2: "23" }),
        /* @__PURE__ */ h.jsx("line", { x1: "4.22", y1: "4.22", x2: "5.64", y2: "5.64" }),
        /* @__PURE__ */ h.jsx("line", { x1: "18.36", y1: "18.36", x2: "19.78", y2: "19.78" }),
        /* @__PURE__ */ h.jsx("line", { x1: "1", y1: "12", x2: "3", y2: "12" }),
        /* @__PURE__ */ h.jsx("line", { x1: "21", y1: "12", x2: "23", y2: "12" }),
        /* @__PURE__ */ h.jsx("line", { x1: "4.22", y1: "19.78", x2: "5.64", y2: "18.36" }),
        /* @__PURE__ */ h.jsx("line", { x1: "18.36", y1: "5.64", x2: "19.78", y2: "4.22" })
      ] }) : /* @__PURE__ */ h.jsx("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ h.jsx("path", { d: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" }) })
    }
  );
}
function ZD({ timeZone: o }) {
  const i = o && o.trim() ? o.trim() : void 0, [n, a] = N.useState(/* @__PURE__ */ new Date());
  N.useEffect(() => {
    const F = 1e3 - Date.now() % 1e3;
    let J = null;
    const Z = setTimeout(() => {
      a(/* @__PURE__ */ new Date()), J = setInterval(() => a(/* @__PURE__ */ new Date()), 1e3);
    }, F);
    return () => {
      clearTimeout(Z), J && clearInterval(J);
    };
  }, []);
  const l = (F) => {
    try {
      return new Intl.DateTimeFormat(void 0, { ...F, timeZone: i }).format(n);
    } catch {
      return new Intl.DateTimeFormat(void 0, F).format(n);
    }
  }, c = (F) => {
    try {
      return new Intl.DateTimeFormat(void 0, { ...F, timeZone: i, hour12: !0 }).formatToParts(n);
    } catch {
      return new Intl.DateTimeFormat(void 0, { ...F, hour12: !0 }).formatToParts(n);
    }
  }, d = c({ hour: "2-digit", minute: "2-digit", second: "2-digit" }), p = (F) => d.find((J) => J.type === F)?.value ?? "", m = p("hour").padStart(2, "0"), g = p("minute").padStart(2, "0"), y = p("second").padStart(2, "0"), b = p("dayPeriod").toUpperCase() || "AM", _ = Number(y) || 0, k = l({ weekday: "short" }), w = l({ month: "short", day: "numeric" }), S = c({ hour: "2-digit", timeZoneName: "short" }).find((F) => F.type === "timeZoneName")?.value ?? "", O = _ % 2 === 0, q = 12, L = 2 * Math.PI * q, P = L * (1 - _ / 60);
  return /* @__PURE__ */ h.jsxs("div", { className: "header-clock", title: n.toLocaleString(), children: [
    /* @__PURE__ */ h.jsxs("div", { className: "hc-date", children: [
      /* @__PURE__ */ h.jsx("span", { className: "hc-date-day", children: k }),
      /* @__PURE__ */ h.jsx("span", { className: "hc-date-sub", children: w })
    ] }),
    /* @__PURE__ */ h.jsx("div", { className: "hc-divider", "aria-hidden": !0 }),
    /* @__PURE__ */ h.jsxs("span", { className: "header-clock-time", children: [
      /* @__PURE__ */ h.jsx("span", { className: "hc-digits", children: m }, `h-${m}`),
      /* @__PURE__ */ h.jsx("span", { className: `hc-colon ${O ? "hc-colon-lit" : ""}`, children: ":" }),
      /* @__PURE__ */ h.jsx("span", { className: "hc-digits", children: g }, `m-${g}`),
      /* @__PURE__ */ h.jsxs("span", { className: "hc-meridiem", children: [
        /* @__PURE__ */ h.jsx("span", { className: "hc-ampm", children: b }),
        S && /* @__PURE__ */ h.jsx("span", { className: "hc-tz", title: i || "browser default", children: S })
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "hc-second-ring", "aria-hidden": !0, children: [
      /* @__PURE__ */ h.jsxs("svg", { className: "hc-ring", viewBox: "0 0 30 30", width: "30", height: "30", children: [
        /* @__PURE__ */ h.jsx("defs", { children: /* @__PURE__ */ h.jsxs("linearGradient", { id: "hc-arc-grad", x1: "0%", y1: "0%", x2: "100%", y2: "100%", children: [
          /* @__PURE__ */ h.jsx("stop", { offset: "0%", stopColor: "#2563eb" }),
          /* @__PURE__ */ h.jsx("stop", { offset: "100%", stopColor: "#7c3aed" })
        ] }) }),
        /* @__PURE__ */ h.jsx("circle", { className: "hc-ring-track", cx: "15", cy: "15", r: q }),
        /* @__PURE__ */ h.jsx(
          "circle",
          {
            className: "hc-ring-progress",
            cx: "15",
            cy: "15",
            r: q,
            strokeDasharray: L.toFixed(2),
            strokeDashoffset: P.toFixed(2)
          }
        )
      ] }),
      /* @__PURE__ */ h.jsx("span", { className: "hc-second-text", children: y }, `s-${y}`)
    ] })
  ] });
}
function KD() {
  const { user: o, loading: i } = Ab(), n = e1(), [a, l] = N.useState(() => {
    try {
      return nv();
    } catch {
      return !1;
    }
  }), [c, d] = N.useState(() => {
    try {
      return rv();
    } catch {
      return !0;
    }
  }), [p, m] = N.useState(
    () => {
      try {
        return iv();
      } catch {
        return "system";
      }
    }
  );
  N.useEffect(() => {
    const P = () => {
      try {
        l(nv());
      } catch {
      }
      try {
        d(rv());
      } catch {
      }
      try {
        m(iv());
      } catch {
      }
    };
    return window.addEventListener("oaticonnect-config-updated", P), () => window.removeEventListener("oaticonnect-config-updated", P);
  }, []);
  function g() {
    const P = typeof localStorage < "u" ? localStorage.getItem("oaticonnect-theme") : null;
    return P === "dark" || P === "light" ? P : p === "light" || p === "dark" ? p : typeof window < "u" && typeof window.matchMedia == "function" ? window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light" : n.theme || "light";
  }
  const [y, b] = N.useState("home"), [_, k] = N.useState(g), [w, D] = N.useState(null), S = o?.role || "Standard", O = !i && S === "Admin";
  let q = "OATIConnect";
  try {
    q = ac();
  } catch {
  }
  N.useEffect(() => {
    const P = document.querySelector("oaticonnect-meet")?.shadowRoot?.getElementById("oaticonnect-root");
    P && P.setAttribute("data-theme", _), localStorage.setItem("oaticonnect-theme", _);
  }, [_]), N.useEffect(() => {
    if (p !== "system" || typeof window > "u" || typeof window.matchMedia != "function") return;
    const P = localStorage.getItem("oaticonnect-theme");
    if (P === "dark" || P === "light") return;
    const F = window.matchMedia("(prefers-color-scheme: dark)"), J = (Z) => k(Z.matches ? "dark" : "light");
    return F.addEventListener?.("change", J), () => F.removeEventListener?.("change", J);
  }, [p]);
  const L = () => k((P) => P === "dark" ? "light" : "dark");
  return /* @__PURE__ */ h.jsxs("div", { className: "app-shell", "data-theme": _, children: [
    /* @__PURE__ */ h.jsx("div", { className: "header-wrapper", children: /* @__PURE__ */ h.jsxs("header", { className: "app-header header-centered", children: [
      /* @__PURE__ */ h.jsx("div", { className: "header-left", children: /* @__PURE__ */ h.jsx("span", { className: "logo", children: q }) }),
      /* @__PURE__ */ h.jsxs("nav", { className: "header-nav header-nav-icons", children: [
        /* @__PURE__ */ h.jsx(
          "button",
          {
            className: `nav-icon-btn ${y === "home" && !w ? "active" : ""}`,
            onClick: () => {
              b("home"), D(null);
            },
            title: "Home",
            "aria-label": "Home",
            children: /* @__PURE__ */ h.jsxs("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
              /* @__PURE__ */ h.jsx("path", { d: "M3 12 12 3l9 9" }),
              /* @__PURE__ */ h.jsx("path", { d: "M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10" })
            ] })
          }
        ),
        w && y === "home" && /* @__PURE__ */ h.jsx(
          "button",
          {
            className: "nav-icon-btn active",
            onClick: () => {
            },
            title: `Participants â€” ${w.title}`,
            "aria-label": "Participants",
            children: /* @__PURE__ */ h.jsxs("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
              /* @__PURE__ */ h.jsx("path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" }),
              /* @__PURE__ */ h.jsx("circle", { cx: "9", cy: "7", r: "4" }),
              /* @__PURE__ */ h.jsx("path", { d: "M22 21v-2a4 4 0 0 0-3-3.87" }),
              /* @__PURE__ */ h.jsx("path", { d: "M16 3.13a4 4 0 0 1 0 7.75" })
            ] })
          }
        ),
        O && /* @__PURE__ */ h.jsx(
          "button",
          {
            className: `nav-icon-btn ${y === "settings" ? "active" : ""}`,
            onClick: () => {
              b("settings"), D(null);
            },
            title: "Settings",
            "aria-label": "Settings",
            children: /* @__PURE__ */ h.jsxs("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
              /* @__PURE__ */ h.jsx("circle", { cx: "12", cy: "12", r: "3" }),
              /* @__PURE__ */ h.jsx("path", { d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.01a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.01a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" })
            ] })
          }
        )
      ] }),
      /* @__PURE__ */ h.jsxs("div", { className: "header-right", style: { display: "flex", alignItems: "center", gap: 12 }, children: [
        a && /* @__PURE__ */ h.jsx(ZD, { timeZone: o?.timeZone }),
        c && /* @__PURE__ */ h.jsx(XD, { theme: _, onToggle: L })
      ] })
    ] }) }),
    /* @__PURE__ */ h.jsxs("main", { className: "app-content", children: [
      y === "home" && (w ? /* @__PURE__ */ h.jsx(
        GD,
        {
          meeting: w,
          onClose: () => D(null)
        }
      ) : /* @__PURE__ */ h.jsx(qD, { onViewParticipants: D })),
      y === "settings" && O && /* @__PURE__ */ h.jsx(FD, {})
    ] })
  ] });
}
function WD({ config: o }) {
  return /* @__PURE__ */ h.jsx($x, { config: o, children: /* @__PURE__ */ h.jsx(Lw, { children: /* @__PURE__ */ h.jsx(Bw, { children: /* @__PURE__ */ h.jsx(KD, {}) }) }) });
}
const ID = ':root{--color-primary: #2563eb;--color-primary-hover: #1d4ed8;--color-primary-light: #eff6ff;--color-primary-muted: #1e3a8a;--color-danger: #dc2626;--color-danger-hover: #b91c1c;--color-success: #059669;--color-success-hover: #047857;--color-warning: #f59e0b;--color-warning-hover: #d97706;--color-bg: #0f172a;--color-surface: #1e293b;--color-surface-hover: #334155;--color-surface-elevated: #283548;--color-text: #f1f5f9;--color-text-secondary: #94a3b8;--color-text-muted: #64748b;--color-text-inverse: #0f172a;--color-border: #334155;--color-border-light: #1e293b;--color-border-focus: #2563eb;--font-family: "Segoe UI", Tahoma, Verdana, Arial, -apple-system, BlinkMacSystemFont, sans-serif;--font-size-xs: .75rem;--font-size-sm: .8125rem;--font-size-base: .875rem;--font-size-md: 1rem;--font-size-lg: 1.125rem;--font-size-xl: 1.25rem;--font-size-2xl: 1.5rem;--font-size-3xl: 2rem;--font-size-4xl: 2.5rem;--font-weight-normal: 400;--font-weight-medium: 500;--font-weight-semibold: 600;--font-weight-bold: 700;--space-1: 4px;--space-2: 8px;--space-3: 12px;--space-4: 16px;--space-5: 20px;--space-6: 24px;--space-8: 32px;--space-10: 40px;--space-12: 48px;--space-16: 64px;--radius-sm: 3px;--radius-md: 5px;--radius-lg: 8px;--radius-xl: 12px;--radius-full: 9999px;--shadow-sm: 0 1px 2px rgba(0, 0, 0, .3);--shadow-md: 0 4px 12px rgba(0, 0, 0, .4);--shadow-lg: 0 8px 24px rgba(0, 0, 0, .5);--shadow-xl: 0 16px 48px rgba(0, 0, 0, .6);--shadow-glow: 0 0 20px rgba(37, 99, 235, .15);--transition-fast: .15s ease;--transition-normal: .25s ease;--transition-slow: .35s ease}[data-theme=light]{--color-primary: #1e5b9a;--color-primary-hover: #174775;--color-primary-light: #e3eef9;--color-primary-muted: #4d80b5;--color-danger: #d9534f;--color-danger-hover: #b73c38;--color-success: #28a745;--color-success-hover: #1f8537;--color-warning: #f0ad4e;--color-warning-hover: #d18b30;--color-bg: #f0f3f7;--color-surface: #ffffff;--color-surface-hover: #f5f7fa;--color-surface-elevated: #ffffff;--color-text: #1f2933;--color-text-secondary: #52606d;--color-text-muted: #9aa5b1;--color-text-inverse: #ffffff;--color-border: #d4dce4;--color-border-light: #e8edf2;--color-border-focus: #1e5b9a;--shadow-sm: 0 1px 1px rgba(15, 30, 50, .05);--shadow-md: 0 2px 4px rgba(15, 30, 50, .08);--shadow-lg: 0 4px 12px rgba(15, 30, 50, .12);--shadow-xl: 0 8px 24px rgba(15, 30, 50, .16);--shadow-glow: 0 0 0 2px rgba(30, 91, 154, .18)}*,*:before,*:after{box-sizing:border-box;margin:0;padding:0}html,body,#root{height:100%}body{font-family:var(--font-family);font-size:var(--font-size-base);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--color-text);background:var(--color-bg);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}a{color:var(--color-primary);text-decoration:none;transition:color var(--transition-fast)}a:hover{color:var(--color-primary-hover)}button{font-family:var(--font-family);font-size:var(--font-size-base);cursor:pointer;border:none;background:none;color:inherit;line-height:1}input,textarea,select{font-family:var(--font-family);font-size:var(--font-size-base);color:var(--color-text);background:var(--color-surface);border:1px solid var(--color-border);outline:none;transition:border-color var(--transition-fast),box-shadow var(--transition-fast)}input:focus,textarea:focus,select:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}img,svg{display:block;max-width:100%}ul,ol{list-style:none}h1,h2,h3,h4,h5,h6{font-weight:var(--font-weight-semibold);line-height:1.25;color:var(--color-text)}.container{width:100%;max-width:1200px;margin:0 auto;padding:0 var(--space-6)}.flex{display:flex}.flex-col{display:flex;flex-direction:column}.flex-center{display:flex;align-items:center;justify-content:center}.flex-between{display:flex;align-items:center;justify-content:space-between}.flex-1{flex:1}.items-center{align-items:center}.justify-center{justify-content:center}.gap-1{gap:var(--space-1)}.gap-2{gap:var(--space-2)}.gap-3{gap:var(--space-3)}.gap-4{gap:var(--space-4)}.gap-6{gap:var(--space-6)}.gap-8{gap:var(--space-8)}.grid{display:grid}.text-center{text-align:center}.text-right{text-align:right}.w-full{width:100%}.h-full{height:100%}.min-h-screen{min-height:100vh}.overflow-hidden{overflow:hidden}.relative{position:relative}.btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);height:40px;padding:0 var(--space-4);font-size:var(--font-size-base);font-weight:var(--font-weight-medium);border-radius:var(--radius-sm);border:none;cursor:pointer;transition:background var(--transition-fast),color var(--transition-fast),box-shadow var(--transition-fast),transform var(--transition-fast);white-space:nowrap;-webkit-user-select:none;user-select:none}.btn:active{transform:scale(.97)}.btn:disabled{opacity:.45;cursor:not-allowed;transform:none}.btn-primary{background:var(--color-primary);color:#fff}.btn-primary:hover:not(:disabled){background:var(--color-primary-hover);box-shadow:var(--shadow-glow)}.btn-secondary{background:var(--color-surface);color:var(--color-text);border:1px solid var(--color-border)}.btn-secondary:hover:not(:disabled){background:var(--color-surface-hover);border-color:var(--color-text-muted)}.btn-danger{background:var(--color-danger);color:#fff}.btn-danger:hover:not(:disabled){background:var(--color-danger-hover)}.btn-success{background:var(--color-success);color:#fff}.btn-success:hover:not(:disabled){background:var(--color-success-hover)}.btn-ghost{background:transparent;color:var(--color-text-secondary)}.btn-ghost:hover:not(:disabled){background:var(--color-surface);color:var(--color-text)}.btn-link{background:none;color:var(--color-primary);padding:0;height:auto}.btn-link:hover:not(:disabled){color:var(--color-primary-hover);text-decoration:underline}.btn-sm{height:32px;padding:0 var(--space-3);font-size:var(--font-size-sm);border-radius:var(--radius-sm)}.btn-lg{height:48px;padding:0 var(--space-6);font-size:var(--font-size-md)}.btn-icon{width:40px;padding:0;border-radius:var(--radius-sm)}.btn-icon.btn-sm{width:32px}.btn-icon.btn-lg{width:48px}.input{width:100%;height:44px;padding:0 var(--space-3);font-size:var(--font-size-base);color:var(--color-text);background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-sm);transition:border-color var(--transition-fast),box-shadow var(--transition-fast)}.input:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}.input::placeholder{color:var(--color-text-muted)}.input-error{border-color:var(--color-danger)}.input-error:focus{box-shadow:0 0 0 2px #dc262640}.label{display:block;font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);color:var(--color-text-secondary);margin-bottom:var(--space-1)}.form-group{margin-bottom:var(--space-4)}.error-text{font-size:var(--font-size-xs);color:var(--color-danger);margin-top:var(--space-1)}.checkbox-row{display:flex;align-items:center;gap:var(--space-2);font-size:var(--font-size-base);cursor:pointer}.checkbox-row input[type=checkbox]{width:18px;height:18px;accent-color:var(--color-primary);cursor:pointer}.card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-6);box-shadow:var(--shadow-sm)}.card-hover:hover{background:var(--color-surface-hover);border-color:var(--color-text-muted);box-shadow:var(--shadow-md);transition:all var(--transition-normal)}.badge{display:inline-flex;align-items:center;height:24px;padding:0 var(--space-2);font-size:var(--font-size-xs);font-weight:var(--font-weight-medium);border-radius:var(--radius-full);background:var(--color-surface-hover);color:var(--color-text-secondary)}.badge-primary{background:#2563eb26;color:#60a5fa}.badge-success{background:#05966926;color:#34d399}.badge-danger{background:#dc262626;color:#f87171}.badge-warning{background:#f59e0b26;color:#fbbf24}.avatar{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:var(--radius-full);background:var(--color-primary-muted);color:#fff;font-size:var(--font-size-sm);font-weight:var(--font-weight-semibold);flex-shrink:0}.avatar-sm{width:28px;height:28px;font-size:var(--font-size-xs)}.avatar-lg{width:48px;height:48px;font-size:var(--font-size-lg)}.top-nav{height:56px;background:var(--color-surface);border-bottom:1px solid var(--color-border);display:flex;align-items:center;padding:0 var(--space-6)}.brand{font-weight:var(--font-weight-bold);font-size:var(--font-size-lg);color:var(--color-text);margin-right:var(--space-8)}.nav-links{display:flex;gap:var(--space-6);flex:1}.nav-links a{text-decoration:none;color:var(--color-text-secondary);font-weight:var(--font-weight-medium);font-size:var(--font-size-base);padding:var(--space-2) 0;border-bottom:2px solid transparent;transition:color var(--transition-fast),border-color var(--transition-fast)}.nav-links a:hover{color:var(--color-text)}.nav-links a.active{color:var(--color-primary);border-bottom-color:var(--color-primary);font-weight:var(--font-weight-semibold)}.logout{background:none;border:none;color:var(--color-danger);cursor:pointer;font-weight:var(--font-weight-medium);font-size:var(--font-size-base);transition:color var(--transition-fast)}.logout:hover{color:var(--color-danger-hover)}.public-home{height:100vh;background:var(--color-bg);display:flex;align-items:center;justify-content:center}.public-center{text-align:center}.public-center .brand{font-size:var(--font-size-4xl);font-weight:var(--font-weight-bold);margin-bottom:var(--space-2);margin-right:0}.tagline{color:var(--color-text-secondary);font-size:var(--font-size-md);margin-bottom:var(--space-8)}.public-actions{display:flex;gap:var(--space-4);justify-content:center}.primary{background:var(--color-primary);color:#fff;border:none;padding:var(--space-3) var(--space-6);border-radius:var(--radius-sm);cursor:pointer;font-weight:var(--font-weight-medium);transition:background var(--transition-fast)}.primary:hover{background:var(--color-primary-hover)}.secondary{background:var(--color-surface);color:var(--color-text);border:1px solid var(--color-border);padding:var(--space-3) var(--space-6);border-radius:var(--radius-sm);cursor:pointer;font-weight:var(--font-weight-medium);transition:background var(--transition-fast)}.secondary:hover{background:var(--color-surface-hover)}.center-container{min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--color-bg)}.home-page{padding:var(--space-12);background:var(--color-bg);height:100%}.time-block{text-align:center;margin-bottom:var(--space-8)}.time{font-size:var(--font-size-4xl);font-weight:var(--font-weight-bold);color:var(--color-text);letter-spacing:-1px}.date{color:var(--color-text-secondary);font-size:var(--font-size-base);margin-top:var(--space-1)}.quick-actions{display:flex;justify-content:center;gap:var(--space-6);margin-bottom:var(--space-8)}.action-btn{width:96px;height:96px;border-radius:var(--radius-lg);border:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:var(--space-1);font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);cursor:pointer;color:#fff;transition:transform var(--transition-fast),box-shadow var(--transition-fast)}.action-btn:hover:not(:disabled){transform:translateY(-2px);box-shadow:var(--shadow-lg)}.action-btn.blue{background:var(--color-primary)}.action-btn.blue:hover:not(:disabled){background:var(--color-primary-hover)}.action-btn.orange{background:#f97316}.action-btn.orange:hover:not(:disabled){background:#ea580c}.action-btn.teal{background:#0d9488}.action-btn.teal:hover:not(:disabled){background:#0f766e}.action-btn.indigo{background:#1e5b9a}.action-btn.indigo:hover:not(:disabled){background:#174a7e}.action-btn:disabled{opacity:.35;cursor:not-allowed;transform:none}.action-btn svg{width:26px;height:26px;flex-shrink:0}.meetings-card{max-width:600px;margin:0 auto;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-6);box-shadow:var(--shadow-md)}.meeting-list{margin-top:var(--space-6);display:grid;gap:var(--space-4)}.meeting-card{background:var(--color-surface);padding:var(--space-4);border-radius:var(--radius-md);border:1px solid var(--color-border);box-shadow:var(--shadow-sm);transition:background var(--transition-fast),border-color var(--transition-fast)}.meeting-card:hover{background:var(--color-surface-hover);border-color:var(--color-text-muted)}.page{padding:var(--space-8)}.empty-state{margin-top:var(--space-10);text-align:center;color:var(--color-text-muted);font-size:var(--font-size-base)}.link{background:none;border:none;color:var(--color-primary);cursor:pointer;font-weight:var(--font-weight-medium);transition:color var(--transition-fast)}.link:hover{color:var(--color-primary-hover)}.modal-backdrop{position:fixed;inset:0;background:#0009;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;z-index:1000;padding:24px 16px;overflow-y:auto}.modal{background:var(--color-surface);width:420px;padding:var(--space-6);border-radius:var(--radius-md);border:1px solid var(--color-border);box-shadow:var(--shadow-xl);position:relative}.modal,.preview-modal,.scheduler-modal{position:relative;max-height:calc(100vh - 48px);overflow-y:auto}.modal::-webkit-scrollbar,.preview-modal::-webkit-scrollbar,.scheduler-modal::-webkit-scrollbar{width:10px}.modal::-webkit-scrollbar-thumb,.preview-modal::-webkit-scrollbar-thumb,.scheduler-modal::-webkit-scrollbar-thumb{background:var(--color-border);border-radius:5px;border:2px solid var(--color-surface)}.modal::-webkit-scrollbar-thumb:hover,.preview-modal::-webkit-scrollbar-thumb:hover,.scheduler-modal::-webkit-scrollbar-thumb:hover{background:var(--color-text-muted)}.modal-close-btn{position:sticky;position:-webkit-sticky;top:0;float:right;margin:calc(var(--space-3) * -1 + 2px) calc(var(--space-3) * -1 + 2px) 0 auto;width:32px;height:32px;background:var(--color-surface);border:none;color:var(--color-text-muted);cursor:pointer;border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;padding:0;transition:background var(--transition-fast),color var(--transition-fast);z-index:2}.modal-close-btn:hover{background:var(--color-surface-hover);color:var(--color-text)}.modal-close-btn:focus-visible{outline:2px solid var(--color-primary);outline-offset:1px}.modal input{width:100%;height:44px;padding:0 var(--space-3);margin-bottom:var(--space-3);background:var(--color-bg);border:1px solid var(--color-border);border-radius:var(--radius-sm);color:var(--color-text)}.modal input:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}.modal-actions{display:flex;justify-content:flex-end;gap:var(--space-3);margin-top:var(--space-4)}.modal-btn{height:38px;padding:0 var(--space-5);border-radius:var(--radius-sm);font-size:var(--font-size-base);font-weight:var(--font-weight-medium);cursor:pointer;transition:background var(--transition-fast),border-color var(--transition-fast),box-shadow var(--transition-fast);border:1px solid transparent;min-width:96px}.modal-btn-secondary{background:transparent;color:var(--color-text);border-color:var(--color-border)}.modal-btn-secondary:hover:not(:disabled){background:var(--color-surface-hover);border-color:var(--color-border-focus, var(--color-border))}.modal-btn-primary{background:var(--color-primary);color:#fff}.modal-btn-primary:hover:not(:disabled){background:var(--color-primary-hover);box-shadow:var(--shadow-glow)}.modal-btn:disabled{opacity:.5;cursor:not-allowed}.join-overlay{position:fixed;inset:0;background:#0009;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center}.join-modal{background:var(--color-surface);padding:var(--space-6);border-radius:var(--radius-md);width:340px;border:1px solid var(--color-border);box-shadow:var(--shadow-xl)}.join-modal input{width:100%;height:44px;padding:0 var(--space-3);margin-top:var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--color-border);background:var(--color-bg);color:var(--color-text)}.join-modal input:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}.join-actions{margin-top:var(--space-4);display:flex;justify-content:flex-end;gap:var(--space-3)}.meeting-layout{display:flex;height:100vh;overflow:hidden}.video-area{flex:1;background:#000}.lobby-area{width:320px;background:var(--color-surface);border-left:1px solid var(--color-border);padding:var(--space-3);overflow-y:auto}.waiting-page{height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:var(--color-bg)}.spinner{margin-top:var(--space-5);width:40px;height:40px;border:3px solid var(--color-border);border-top:3px solid var(--color-primary);border-radius:50%;animation:spin .8s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}::-webkit-scrollbar{width:8px;height:8px}::-webkit-scrollbar-track{background:var(--color-bg)}::-webkit-scrollbar-thumb{background:var(--color-surface-hover);border-radius:var(--radius-full)}::-webkit-scrollbar-thumb:hover{background:var(--color-text-muted)}::selection{background:#2563eb4d;color:var(--color-text)}.transition{transition:all var(--transition-normal)}.transition-fast{transition:all var(--transition-fast)}.datepicker-wrapper{width:100%}.datepicker-input{width:100%;height:42px;padding:0 var(--space-3);background:var(--color-bg);border:1px solid var(--color-border);border-radius:var(--radius-sm);color:var(--color-text);font-size:var(--font-size-base);font-family:var(--font-family)}.datepicker-input:focus{outline:none;border-color:var(--color-primary);box-shadow:0 0 0 2px #2563eb33}.home-date-wrapper{width:auto}.home-date-input{width:160px;height:34px;font-size:var(--font-size-sm)}.datepicker-popper{z-index:1100!important}.react-datepicker{background:var(--color-surface-elevated)!important;border:1px solid var(--color-border)!important;border-radius:var(--radius-md)!important;box-shadow:var(--shadow-lg)!important;font-family:var(--font-family)!important;color:var(--color-text)!important}.react-datepicker__header{background:var(--color-surface)!important;border-bottom:1px solid var(--color-border)!important;padding-top:12px!important}.react-datepicker__current-month,.react-datepicker-time__header,.react-datepicker__day-name,.react-datepicker__day,.react-datepicker__time-list-item{color:var(--color-text)!important}.react-datepicker__day:hover,.react-datepicker__time-list-item:hover{background:var(--color-surface-hover)!important;border-radius:var(--radius-sm)!important}.react-datepicker__day--selected,.react-datepicker__day--keyboard-selected,.react-datepicker__time-list-item--selected{background:var(--color-primary)!important;color:#fff!important;border-radius:var(--radius-sm)!important}.react-datepicker__day--selected:hover,.react-datepicker__time-list-item--selected:hover{background:var(--color-primary-hover)!important}.react-datepicker__day--disabled,.react-datepicker__day--outside-month{color:var(--color-text-muted)!important}.react-datepicker__day--today{font-weight:var(--font-weight-bold)!important;color:var(--color-primary)!important}.react-datepicker__day--today.react-datepicker__day--selected,.react-datepicker__day--today.react-datepicker__day--keyboard-selected{color:#fff!important}.react-datepicker__triangle{display:none!important}.react-datepicker__navigation{top:14px!important}.react-datepicker__navigation-icon:before{border-color:var(--color-text-secondary)!important}.react-datepicker__time-container{border-left:1px solid var(--color-border)!important}.react-datepicker__time,.react-datepicker__time-list{background:var(--color-surface-elevated)!important}.react-datepicker__input-container input{width:100%}', JD = '.app-shell{height:100vh;display:flex;flex-direction:column;background:var(--color-bg)}.app-header{height:56px;display:grid;grid-template-columns:auto 1fr auto;align-items:center;padding:0 var(--space-6);border-bottom:1px solid var(--color-border);background:var(--color-surface);flex-shrink:0}.app-header.header-centered{max-width:960px;width:100%;margin:0 auto;border-bottom:none}.app-shell .header-wrapper{border-bottom:1px solid var(--color-border);background:var(--color-surface)}.header-left .logo{font-size:var(--font-size-xl);font-weight:var(--font-weight-bold);color:var(--color-text);letter-spacing:-.5px}.header-left .logo-accent{color:var(--color-primary)}.header-nav{display:flex;justify-content:center;gap:var(--space-6)}.header-nav a{color:var(--color-text-secondary);text-decoration:none;font-weight:var(--font-weight-medium);font-size:var(--font-size-base);padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border-bottom:2px solid transparent;transition:color var(--transition-fast),background var(--transition-fast),border-color var(--transition-fast)}.header-nav a:hover{color:var(--color-text);background:var(--color-surface-hover)}.header-nav a.active{color:var(--color-primary);border-bottom-color:var(--color-primary);font-weight:var(--font-weight-semibold)}.nav-tab-btn{color:var(--color-text-secondary);background:transparent;border:none;font-weight:var(--font-weight-medium);font-size:var(--font-size-base);padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border-bottom:2px solid transparent;cursor:pointer;transition:color var(--transition-fast),background var(--transition-fast),border-color var(--transition-fast)}.nav-tab-btn:hover{color:var(--color-text);background:var(--color-surface-hover)}.nav-tab-btn.active{color:var(--color-primary);border-bottom-color:var(--color-primary);font-weight:var(--font-weight-semibold)}.header-nav-icons{gap:var(--space-2, 8px);align-items:center}.nav-icon-btn{position:relative;width:36px;height:36px;display:inline-flex;align-items:center;justify-content:center;background:transparent;border:none;border-radius:4px;color:var(--color-text-secondary);cursor:pointer;padding:0;transition:color .16s ease,background .16s ease,transform .12s ease}.nav-icon-btn svg{display:block}.nav-icon-btn:hover{color:var(--color-text);background:var(--color-surface-hover, rgba(0, 0, 0, .04))}.nav-icon-btn:focus-visible{outline:none;box-shadow:0 0 0 2px var(--color-primary-muted, rgba(30, 91, 154, .4))}.nav-icon-btn:active{transform:scale(.96)}.nav-icon-btn.active{color:var(--color-primary);background:transparent}.nav-icon-btn.active:after{content:"";position:absolute;left:6px;right:6px;bottom:-2px;height:2px;border-radius:2px;background:var(--color-primary)}[data-theme=dark] .nav-icon-btn:hover{background:#ffffff0f}.header-right{position:relative;display:flex;align-items:center}.user-menu{display:flex;align-items:center;gap:var(--space-2);cursor:pointer;padding:var(--space-1) var(--space-2);border-radius:var(--radius-sm);transition:background var(--transition-fast)}.user-menu:hover{background:var(--color-surface-hover)}.user-menu .avatar{width:32px;height:32px;border-radius:var(--radius-full);background:var(--color-primary-muted);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:var(--font-weight-semibold);font-size:var(--font-size-sm);flex-shrink:0}.user-menu .user-name{font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);color:var(--color-text);max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.caret{font-size:var(--font-size-xs);color:var(--color-text-muted)}.user-dropdown{position:absolute;top:46px;right:0;background:var(--color-surface-elevated);border-radius:var(--radius-md);border:1px solid var(--color-border);box-shadow:var(--shadow-lg);min-width:180px;overflow:hidden;z-index:1000;animation:dropdown-in .15s ease-out}@keyframes dropdown-in{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.user-dropdown button{width:100%;padding:var(--space-3) var(--space-4);border:none;background:transparent;color:var(--color-text);text-align:left;font-size:var(--font-size-base);cursor:pointer;transition:background var(--transition-fast);display:flex;align-items:center;gap:var(--space-2)}.dropdown-icon{display:flex;align-items:center;color:var(--color-text-secondary)}.user-dropdown button:hover{background:var(--color-surface-hover)}.dropdown-divider{height:1px;background:var(--color-border);margin:var(--space-1) 0}.theme-toggle-btn{display:flex;align-items:center;gap:var(--space-2)}.theme-toggle-icon{display:flex;align-items:center;color:var(--color-text-secondary)}.user-dropdown .danger{color:var(--color-danger);font-weight:var(--font-weight-medium)}.user-dropdown .danger:hover{background:#dc26261a}.app-content{flex:1;overflow-y:auto;background:var(--color-bg)}.header-clock{display:inline-flex;align-items:center;gap:8px;padding:3px 12px 3px 8px;border-radius:12px;background:linear-gradient(135deg,#2563eb1f,#7c3aed1a 60%,#ec48990f),var(--color-surface-hover, rgba(0, 0, 0, .04));border:1px solid rgba(37,99,235,.18);color:var(--color-text);box-shadow:inset 0 1px #ffffff1a,0 4px 14px -8px #2563eb73;transition:background var(--transition-fast),border-color var(--transition-fast),box-shadow var(--transition-fast),transform var(--transition-fast)}.header-clock:hover{border-color:#2563eb59;box-shadow:inset 0 1px #ffffff1a,0 6px 20px -8px #2563eb8c;transform:translateY(-1px)}.hc-second-ring{position:relative;display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;flex-shrink:0}.hc-ring{width:26px;height:26px}.hc-ring{display:block;transform:rotate(-90deg);filter:drop-shadow(0 0 4px rgba(37,99,235,.3))}.hc-ring-track{fill:none;stroke:#2563eb26;stroke-width:2}.hc-ring-progress{fill:none;stroke:url(#hc-arc-grad);stroke-width:2;stroke-linecap:round;transition:stroke-dashoffset .9s cubic-bezier(.22,1,.36,1)}.hc-second-text{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-family:ui-monospace,SFMono-Regular,JetBrains Mono,Menlo,Consolas,monospace;font-variant-numeric:tabular-nums;font-size:11px;font-weight:700;letter-spacing:.3px;color:var(--color-text);animation:hc-second-pop .35s ease-out}@keyframes hc-second-pop{0%{transform:scale(.85);opacity:0}60%{transform:scale(1.04);opacity:1}to{transform:scale(1);opacity:1}}.header-clock-time{display:inline-flex;align-items:baseline;gap:2px;color:var(--color-text);font-weight:700;font-size:19px;line-height:1;font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;letter-spacing:.4px}.hc-digits{font-family:ui-monospace,SFMono-Regular,JetBrains Mono,Menlo,Consolas,monospace;display:inline-block;min-width:2ch;text-align:center;background:linear-gradient(135deg,var(--color-text),var(--color-text) 50%,var(--color-primary));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;animation:hc-digit-flip .35s ease-out}@keyframes hc-digit-flip{0%{transform:translateY(-25%);opacity:0}60%{transform:translateY(0);opacity:1}to{transform:translateY(0);opacity:1}}.hc-colon{display:inline-block;width:.4ch;text-align:center;color:var(--color-primary);opacity:.35;transition:opacity .2s ease-out;font-weight:700;position:relative;top:-2px}.hc-colon-lit{opacity:1}.hc-meridiem{display:inline-flex;flex-direction:column;align-items:center;gap:2px;margin-left:6px;position:relative;top:-4px}.hc-ampm{padding:1px 5px;font-family:Inter,sans-serif;font-size:9px;font-weight:800;letter-spacing:.8px;color:#fff;background:linear-gradient(135deg,var(--color-primary),#7c3aed);border-radius:4px;box-shadow:0 1px 3px #7c3aed59}.hc-tz{padding:1px 5px;font-family:Inter,sans-serif;font-size:8px;font-weight:700;letter-spacing:.6px;color:var(--color-text-secondary);background:#2563eb14;border:1px solid rgba(37,99,235,.18);border-radius:4px;white-space:nowrap}.hc-divider{width:1px;height:22px;background:linear-gradient(to bottom,transparent,rgba(37,99,235,.25),transparent);flex-shrink:0}.hc-date{display:inline-flex;flex-direction:column;align-items:flex-start;line-height:1.1;color:var(--color-text-secondary)}.hc-date-day{font-size:11px;font-weight:700;color:var(--color-text);letter-spacing:.3px}.hc-date-sub{font-size:10px;font-weight:500;color:var(--color-text-secondary);letter-spacing:.2px;margin-top:1px}@media(max-width:640px){.hc-divider,.hc-date,.hc-second-ring,.hc-meridiem{display:none}.header-clock-time{font-size:16px}}', $D = ".timeline-invited-badge{display:inline-flex;align-items:center;font-size:11px;padding:2px 8px;border-radius:999px;background:#7c3aed1a;color:#7c3aed;border:1px solid rgba(124,58,237,.25);font-weight:600}.participants-page{max-width:960px;margin:0 auto;padding:var(--space-6) var(--space-6) var(--space-12)}.participants-back{display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 var(--space-3);background:transparent;color:var(--color-text-secondary);border:1px solid var(--color-border);border-radius:var(--radius-full);font-size:13px;font-weight:var(--font-weight-medium);cursor:pointer;transition:color var(--transition-fast),background var(--transition-fast),border-color var(--transition-fast);margin-bottom:var(--space-4)}.participants-back:hover{color:var(--color-text);background:var(--color-surface-hover);border-color:var(--color-border-focus, var(--color-border))}.participants-hero{display:flex;flex-wrap:wrap;align-items:stretch;justify-content:space-between;gap:var(--space-5);padding:var(--space-5) var(--space-6);margin-bottom:var(--space-5);background:radial-gradient(1200px 400px at 0% 0%,rgba(37,99,235,.1),transparent 60%),var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg, 12px);box-shadow:var(--shadow-sm, 0 1px 2px rgba(0, 0, 0, .18))}.participants-hero-main{flex:1 1 320px;min-width:0}.participants-hero-eyebrow{font-size:11px;font-weight:var(--font-weight-semibold);letter-spacing:1.4px;text-transform:uppercase;color:var(--color-primary);margin-bottom:6px}.participants-hero-title{margin:0 0 6px;font-size:var(--font-size-2xl);font-weight:var(--font-weight-bold);color:var(--color-text);line-height:1.2;word-break:break-word}.participants-hero-meta{display:inline-flex;align-items:center;gap:var(--space-2);color:var(--color-text-secondary);font-size:13px}.participants-hero-dot{opacity:.5}.participants-stats{display:flex;gap:var(--space-3);align-self:center;flex-wrap:wrap}.participants-stat{min-width:96px;padding:var(--space-3) var(--space-4);background:#ffffff06;border:1px solid var(--color-border);border-radius:var(--radius-md, 8px);text-align:center}.participants-stat-value{font-size:22px;font-weight:var(--font-weight-bold);color:var(--color-text);line-height:1.1;margin-bottom:2px}.participants-stat-label{font-size:11px;letter-spacing:.6px;text-transform:uppercase;color:var(--color-text-secondary)}.participants-list{display:flex;flex-direction:column;gap:1px;background:var(--color-border);border:1px solid var(--color-border);border-radius:var(--radius-lg, 12px);overflow:hidden}.participant-row{display:grid;grid-template-columns:44px 1fr auto;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);background:var(--color-surface);transition:background var(--transition-fast)}.participant-row:hover{background:var(--color-surface-hover)}.participant-avatar{width:44px;height:44px;border-radius:var(--radius-full);display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:var(--font-weight-bold);letter-spacing:.5px;color:#fff;flex-shrink:0;box-shadow:0 1px 2px #00000040,inset 0 0 0 1px #ffffff0f}.participant-id{min-width:0}.participant-name{font-size:var(--font-size-base);font-weight:var(--font-weight-semibold);color:var(--color-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.participant-email{font-size:12px;color:var(--color-text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}.participant-time{text-align:right;white-space:nowrap}.participant-time-rel{font-size:13px;font-weight:var(--font-weight-medium);color:var(--color-text)}.participant-time-abs{font-size:11px;color:var(--color-text-secondary);margin-top:2px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace}.participants-state{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:var(--space-2);padding:var(--space-12) var(--space-6);text-align:center;background:var(--color-surface);border:1px dashed var(--color-border);border-radius:var(--radius-lg, 12px);color:var(--color-text-secondary)}.participants-state-icon{color:var(--color-text-muted);margin-bottom:var(--space-2);font-size:36px;line-height:1}.participants-state-title{margin:0;font-size:var(--font-size-base);font-weight:var(--font-weight-semibold);color:var(--color-text)}.participants-state-desc{margin:0;font-size:13px}.participants-state-loading .spinner{width:28px;height:28px}.participants-state-error{border-style:solid;border-color:#dc262659;color:#f87171;background:#dc26260f}@media(max-width:600px){.participants-hero{flex-direction:column}.participants-stats{width:100%;justify-content:space-between}.participants-stat{flex:1;min-width:0}.participant-row{grid-template-columns:40px 1fr}.participant-time{grid-column:2;text-align:left}}.home{max-width:960px;margin:0 auto;padding:var(--space-8) var(--space-6) var(--space-12);text-align:center}.home-embedded{padding-top:var(--space-3)}.home-embedded .home-actions{margin-top:var(--space-2);margin-bottom:var(--space-5)}.home-welcome{margin-bottom:var(--space-6)}.home-welcome h2{font-size:var(--font-size-xl);font-weight:var(--font-weight-semibold);color:var(--color-text);margin-bottom:var(--space-1)}.home-welcome p{color:var(--color-text-secondary);font-size:var(--font-size-sm)}.home-time h1{font-size:var(--font-size-4xl);margin-bottom:var(--space-1);font-weight:var(--font-weight-bold);color:var(--color-text)}.home-time p{color:var(--color-text-secondary);font-size:var(--font-size-base);margin-bottom:var(--space-3)}.home-actions{display:flex;gap:var(--space-5);justify-content:center;margin:var(--space-8) 0;flex-wrap:wrap}.card-header-row{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);margin-bottom:var(--space-4);flex-wrap:wrap}.zoom-toolbar{display:flex;align-items:center;gap:var(--space-2);flex-wrap:nowrap;flex-shrink:0}.icon-btn{width:34px;height:34px;border-radius:var(--radius-sm);border:none;background:var(--color-primary);color:#fff;font-size:var(--font-size-md);cursor:pointer;transition:background var(--transition-fast),transform var(--transition-fast)}.icon-btn:hover{background:var(--color-primary-hover);transform:translateY(-1px)}.date-input{height:34px;padding:0 var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--color-border);background:var(--color-bg);color:var(--color-text);font-size:var(--font-size-sm)}.date-input:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}.today-btn{height:34px;padding:0 var(--space-4);border-radius:var(--radius-sm);border:none;background:var(--color-primary);color:#fff;font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);cursor:pointer;transition:background var(--transition-fast)}.today-btn:hover{background:var(--color-primary-hover)}.org-filter-wrapper{min-width:160px;max-width:240px;flex-shrink:0}.org-filter-select{height:34px;padding:0 var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--color-border);background:var(--color-bg);color:var(--color-text);font-size:var(--font-size-sm);min-width:160px;cursor:pointer}.org-filter-select:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}.home-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-6);box-shadow:var(--shadow-md);margin-bottom:var(--space-5);text-align:left}.timeline-date-heading{font-size:var(--font-size-sm);font-weight:var(--font-weight-semibold);color:var(--color-text-secondary);text-transform:uppercase;letter-spacing:.5px;white-space:nowrap}.timeline-divider{height:1px;background:var(--color-border);margin-bottom:var(--space-5)}.timeline-list{display:flex;flex-direction:column;gap:0}.timeline-row{display:flex;align-items:stretch;gap:var(--space-4);min-height:72px;transition:background var(--transition-fast);padding:var(--space-3) var(--space-3);border-radius:var(--radius-sm);margin:0 calc(var(--space-3) * -1)}.timeline-row:hover{background:var(--color-surface-hover)}.timeline-row.past .timeline-title,.timeline-row.past .timeline-time-text,.timeline-row.past .timeline-meta{color:var(--color-text-muted)}.timeline-row.past .timeline-title{text-decoration:line-through;text-decoration-color:var(--color-text-muted);text-decoration-thickness:1px}.timeline-row.past .timeline-org-badge{opacity:.7}.timeline-time{width:80px;flex-shrink:0;display:flex;align-items:flex-start;padding-top:var(--space-2)}.timeline-time-text{font-size:var(--font-size-sm);font-weight:var(--font-weight-semibold);color:var(--color-text);white-space:nowrap}.timeline-connector{display:flex;flex-direction:column;align-items:center;width:20px;flex-shrink:0;padding-top:var(--space-2)}.timeline-dot{width:10px;height:10px;border-radius:var(--radius-full);flex-shrink:0;margin-top:4px}.timeline-dot-ongoing{background:var(--color-success);box-shadow:0 0 8px #05966980}.timeline-dot-upcoming{background:var(--color-primary)}.timeline-dot-past{background:var(--color-text-muted)}.timeline-line{width:2px;flex:1;background:var(--color-border);margin-top:var(--space-2);min-height:20px}.timeline-content{flex:1;display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-4);padding:var(--space-1) 0 var(--space-3) 0;border-bottom:1px solid var(--color-border-light);min-width:0}.timeline-row:last-child .timeline-content{border-bottom:none}.timeline-row:last-child .timeline-line{display:none}.timeline-content-main{flex:1;min-width:0}.timeline-title-row{display:flex;align-items:center;gap:var(--space-2);flex-wrap:wrap;margin-bottom:var(--space-1)}.timeline-title{font-size:var(--font-size-base);font-weight:var(--font-weight-semibold);color:var(--color-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.timeline-meeting-code{font-size:12px;font-family:Consolas,Menlo,monospace;color:var(--color-text-muted, #6b7280);letter-spacing:.02em;white-space:nowrap}.timeline-copy-btn{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;padding:0;background:transparent;border:1px solid var(--color-border);border-radius:var(--radius-sm);color:var(--color-text-secondary);cursor:pointer;transition:all var(--transition-fast);flex-shrink:0}.timeline-copy-btn:hover{background:var(--color-surface-hover);color:var(--color-primary);border-color:var(--color-primary)}.timeline-copy-btn:active{transform:scale(.92)}.timeline-description-col{flex:0 0 220px;align-self:center;font-size:var(--font-size-sm);color:var(--color-text-secondary);line-height:1.4;padding:0 var(--space-3);border-left:1px solid var(--color-border);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}@media(max-width:900px){.timeline-description-col{display:none}}.timeline-org-badge{display:inline-flex;align-items:center;height:20px;padding:0 var(--space-2);font-size:var(--font-size-xs);font-weight:var(--font-weight-medium);background:#2563eb1f;color:#60a5fa;border-radius:var(--radius-full)}.timeline-status-badge{display:inline-flex;align-items:center;height:20px;padding:0 var(--space-2);font-size:var(--font-size-xs);font-weight:var(--font-weight-medium);border-radius:var(--radius-full)}.timeline-status-ongoing{background:#05966926;color:#34d399}.timeline-status-upcoming{background:#2563eb1f;color:#60a5fa}.timeline-status-past{background:var(--color-surface-hover);color:var(--color-text-muted)}.timeline-meta{display:flex;align-items:center;gap:var(--space-3);font-size:var(--font-size-xs);color:var(--color-text-muted)}.timeline-duration{font-weight:var(--font-weight-medium)}.timeline-code{display:inline-flex;align-items:center;gap:6px;font-family:monospace;font-size:var(--font-size-xs);font-weight:var(--font-weight-medium);color:var(--color-text-secondary);background:var(--color-bg-elevated, rgba(0, 0, 0, .04));padding:2px 8px;border-radius:6px}.timeline-code-label{font-family:inherit;font-size:10px;font-weight:var(--font-weight-bold);color:var(--color-text-muted);letter-spacing:.05em}.timeline-recurrence-badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;margin-left:6px;border-radius:999px;background:var(--color-surface-elevated, #eef2ff);color:var(--color-primary, #4338ca);font-size:var(--font-size-xs);font-weight:var(--font-weight-semibold, 600);line-height:1.4;white-space:nowrap}.timeline-recurrence-badge svg{flex-shrink:0}.timeline-next-occurrence{font-size:var(--font-size-xs);color:var(--color-text-secondary);margin-top:2px}[data-theme=dark] .timeline-recurrence-badge{background:#6366f126;color:#a5b4fc}.timeline-actions{display:flex;align-items:center;gap:var(--space-2);flex-shrink:0;padding-top:2px}.timeline-more-wrapper{position:relative}.timeline-icon-actions{display:inline-flex;align-items:center;gap:2px;padding:2px;background:var(--color-surface-hover);border:1px solid var(--color-border);border-radius:var(--radius-md, 8px)}.row-icon-btn{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;background:transparent;border:none;border-radius:var(--radius-sm, 6px);color:var(--color-text-secondary);cursor:pointer;transition:background var(--transition-fast),color var(--transition-fast)}.row-icon-btn:hover{background:var(--color-surface);color:var(--color-text)}.row-icon-btn:focus-visible{outline:2px solid var(--color-primary);outline-offset:1px}.row-icon-btn-danger:hover{background:#dc26261a;color:#ef4444}.row-icon-btn-primary{background:var(--color-primary);color:#fff}.row-icon-btn-primary:hover{background:var(--color-primary-hover);color:#fff;box-shadow:var(--shadow-glow)}.timeline-end-note{text-align:center;padding:var(--space-4) 0 var(--space-2);font-size:var(--font-size-sm);color:var(--color-text-muted);border-top:1px solid var(--color-border-light);margin-top:var(--space-3)}.empty-state-container{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:var(--space-12) 0;gap:var(--space-4)}.empty-state-icon{color:var(--color-text-muted);opacity:.5}.empty-state-text{font-size:var(--font-size-md);color:var(--color-text-muted);font-weight:var(--font-weight-medium)}.empty{color:var(--color-text-muted);padding:var(--space-10) 0}.empty p{margin-bottom:var(--space-2)}.muted{font-size:var(--font-size-sm);color:var(--color-text-muted)}.meeting-menu{position:absolute;top:34px;right:0;min-width:170px;padding:var(--space-1);background:var(--color-surface-elevated);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:var(--radius-md);border:1px solid var(--color-border);box-shadow:var(--shadow-lg);display:flex;flex-direction:column;gap:2px;z-index:999;animation:zoomMenuIn .12s ease-out}@keyframes zoomMenuIn{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.meeting-menu button{border:none;background:var(--color-primary);color:#fff;width:100%;height:34px;border-radius:var(--radius-sm);cursor:pointer;font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);line-height:1;transition:background var(--transition-fast)}.meeting-menu button:hover{background:var(--color-primary-hover)}.paging{display:flex;justify-content:center;align-items:center;gap:var(--space-4);margin-top:var(--space-5)}.paging button{border:none;background:var(--color-primary);color:#fff;padding:var(--space-2) var(--space-4);border-radius:var(--radius-sm);cursor:pointer;font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);transition:background var(--transition-fast)}.paging button:hover:not(:disabled){background:var(--color-primary-hover)}.paging button:disabled{background:var(--color-surface-hover);color:var(--color-text-muted);cursor:not-allowed}.paging span{font-size:var(--font-size-sm);color:var(--color-text-secondary)}.return-button{background:#f97316;color:#fff;border:none;padding:var(--space-2) var(--space-4);border-radius:var(--radius-sm);cursor:pointer;font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);margin-bottom:var(--space-3);transition:background var(--transition-fast)}.return-button:hover{background:#ea580c}.status{font-size:var(--font-size-xs);color:var(--color-primary);text-transform:capitalize;font-weight:var(--font-weight-medium)}.live-dot{color:var(--color-danger);font-weight:var(--font-weight-semibold);font-size:var(--font-size-xs)}.copy-toast{position:fixed;bottom:30px;left:50%;transform:translate(-50%);background:var(--color-surface-elevated);color:var(--color-text);padding:var(--space-3) var(--space-5);border-radius:var(--radius-sm);border:1px solid var(--color-border);font-size:var(--font-size-base);box-shadow:var(--shadow-lg);z-index:2000;animation:fadeInOut 2s ease}@keyframes fadeInOut{0%{opacity:0;transform:translate(-50%,10px)}20%{opacity:1;transform:translate(-50%)}80%{opacity:1}to{opacity:0}}.toggle{display:flex;background:var(--color-surface);border-radius:var(--radius-sm);border:1px solid var(--color-border)}.toggle button{height:34px;padding:0 var(--space-4);border:none;background:transparent;font-size:var(--font-size-sm);cursor:pointer;color:var(--color-text-secondary);transition:all var(--transition-fast)}.toggle button.active{background:var(--color-surface-hover);font-weight:var(--font-weight-semibold);color:var(--color-text)}", eE = '.settings-page{max-width:720px;margin:0 auto;padding:var(--space-8) var(--space-6)}.settings-page h1{font-size:var(--font-size-2xl);margin-bottom:var(--space-5)}.settings-tabs{display:flex;gap:var(--space-1);margin-bottom:var(--space-6);border-bottom:1px solid var(--color-border);padding-bottom:0}.settings-tab{padding:var(--space-3) var(--space-4);font-size:var(--font-size-base);font-weight:var(--font-weight-medium);color:var(--color-text-secondary);background:none;border:none;border-bottom:2px solid transparent;cursor:pointer;transition:color var(--transition-fast),border-color var(--transition-fast);margin-bottom:-1px}.settings-tab:hover{color:var(--color-text)}.settings-tab-active{color:var(--color-primary);border-bottom-color:var(--color-primary);font-weight:var(--font-weight-semibold)}.settings-coming-soon{margin-top:var(--space-6);padding:var(--space-4);text-align:center;font-size:var(--font-size-sm);color:var(--color-text-muted);border-top:1px solid var(--color-border-light)}.settings-field-loading{height:44px;display:flex;align-items:center;font-size:var(--font-size-sm);color:var(--color-text-muted)}.settings-section{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-6);margin-bottom:var(--space-6)}.settings-section-title{font-size:var(--font-size-lg);font-weight:var(--font-weight-semibold);margin-bottom:var(--space-5);padding-bottom:var(--space-3);border-bottom:1px solid var(--color-border)}.settings-profile{display:flex;align-items:center;gap:var(--space-5)}.settings-avatar{width:64px;height:64px;border-radius:var(--radius-full);background:var(--color-primary-muted);color:#fff;display:flex;align-items:center;justify-content:center;font-size:var(--font-size-2xl);font-weight:var(--font-weight-bold);flex-shrink:0}.settings-profile-info{flex:1}.settings-profile-name{font-size:var(--font-size-lg);font-weight:var(--font-weight-semibold);margin-bottom:var(--space-1)}.settings-profile-email{display:inline-flex;align-items:center;gap:var(--space-2);color:var(--color-text-secondary);font-size:var(--font-size-sm)}.settings-email-badge{display:inline-flex;align-items:center;height:20px;padding:0 var(--space-2);font-size:var(--font-size-xs);background:#2563eb26;color:#60a5fa;border-radius:var(--radius-full);font-weight:var(--font-weight-medium)}.settings-form-group{margin-bottom:var(--space-4)}.settings-form-group .label{display:block;font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);color:var(--color-text-secondary);margin-bottom:var(--space-1)}.settings-form-group .input{width:100%;height:44px;padding:0 var(--space-3);background:var(--color-bg);border:1px solid var(--color-border);border-radius:var(--radius-sm);color:var(--color-text)}.settings-form-group .input:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}.settings-password-wrapper{position:relative}.settings-password-wrapper .input{padding-right:44px}.settings-password-toggle{position:absolute;right:0;top:0;width:44px;height:44px;display:flex;align-items:center;justify-content:center;background:none;border:none;color:var(--color-text-muted);cursor:pointer;transition:color var(--transition-fast)}.settings-password-toggle:hover{color:var(--color-text)}.settings-toggle-row{display:flex;align-items:center;justify-content:space-between;padding:var(--space-3) 0;border-bottom:1px solid var(--color-border-light)}.settings-toggle-row:last-child{border-bottom:none}.settings-toggle-label{font-size:var(--font-size-base);color:var(--color-text)}.settings-toggle-desc{font-size:var(--font-size-xs);color:var(--color-text-muted);margin-top:2px}.toggle-switch{position:relative;width:44px;height:24px;flex-shrink:0}.toggle-switch input{opacity:0;width:0;height:0}.toggle-slider{position:absolute;cursor:pointer;inset:0;background:var(--color-surface-hover);border-radius:var(--radius-full);transition:background var(--transition-fast)}.toggle-slider:before{content:"";position:absolute;height:18px;width:18px;left:3px;bottom:3px;background:#fff;border-radius:var(--radius-full);transition:transform var(--transition-fast)}.toggle-switch input:checked+.toggle-slider{background:var(--color-primary)}.toggle-switch input:checked+.toggle-slider:before{transform:translate(20px)}.settings-actions{display:flex;justify-content:flex-end;gap:var(--space-3);margin-top:var(--space-5)}.settings-btn{height:40px;padding:0 var(--space-5);border-radius:var(--radius-sm);font-size:var(--font-size-base);font-weight:var(--font-weight-medium);cursor:pointer;transition:background var(--transition-fast),box-shadow var(--transition-fast);border:none}.settings-btn-primary{background:var(--color-primary);color:#fff}.settings-btn-primary:hover:not(:disabled){background:var(--color-primary-hover);box-shadow:var(--shadow-glow)}.settings-btn-primary:disabled{opacity:.5;cursor:not-allowed}.settings-success{display:flex;align-items:center;gap:var(--space-2);padding:var(--space-3) var(--space-4);background:#0596691a;border:1px solid rgba(5,150,105,.2);border-radius:var(--radius-sm);margin-bottom:var(--space-4);font-size:var(--font-size-sm);color:#34d399}.settings-error{display:flex;align-items:center;gap:var(--space-2);padding:var(--space-3) var(--space-4);background:#dc26261a;border:1px solid rgba(220,38,38,.2);border-radius:var(--radius-sm);margin-bottom:var(--space-4);font-size:var(--font-size-sm);color:#f87171}.settings-loading{display:flex;align-items:center;justify-content:center;padding:var(--space-16) 0;color:var(--color-text-secondary)}.settings-form-group-spaced{margin-top:var(--space-4)}.toolbar-buttons-grid{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-3);margin-top:var(--space-3)}.settings-btn-secondary{background:var(--color-surface-hover);color:var(--color-text);border:1px solid var(--color-border)}.settings-btn-secondary:hover:not(:disabled){background:var(--color-border)}.prefs-sticky-header{position:sticky;top:0;z-index:5;background:var(--color-surface);margin:calc(var(--space-6) * -1) calc(var(--space-6) * -1) var(--space-4);padding:var(--space-5) var(--space-6) 0;border-bottom:1px solid var(--color-border)}.prefs-sticky-title-row{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);margin-bottom:var(--space-3)}.prefs-sticky-title{margin:0;padding-bottom:0;border-bottom:none}.prefs-subtabs{display:flex;gap:var(--space-1);margin-bottom:-1px}.prefs-subtab{padding:var(--space-2) var(--space-4);font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);color:var(--color-text-secondary);background:none;border:none;border-bottom:2px solid transparent;cursor:pointer;transition:color var(--transition-fast),border-color var(--transition-fast)}.prefs-subtab:hover{color:var(--color-text)}.prefs-subtab-active{color:var(--color-primary);border-bottom-color:var(--color-primary);font-weight:var(--font-weight-semibold)}.prefs-bulk-actions{display:flex;gap:var(--space-2);margin-bottom:var(--space-3)}', tE = ".preview-modal{width:680px;max-width:90vw;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-6);box-shadow:var(--shadow-xl)}.preview-modal h2{font-size:var(--font-size-xl);color:var(--color-text);margin-bottom:var(--space-4)}.preview-video-container{width:100%;height:260px;background:#000;border-radius:var(--radius-md);overflow:hidden;display:flex;align-items:center;justify-content:center;margin:var(--space-4) 0}.preview-video{width:100%;height:100%;object-fit:cover}.camera-off{color:var(--color-text-muted);font-size:var(--font-size-lg)}.preview-controls{display:flex;gap:var(--space-3);margin:var(--space-3) 0}.control-group{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--space-1);overflow:hidden}.control-group label{font-size:var(--font-size-sm);color:var(--color-text-secondary);font-weight:var(--font-weight-medium)}.control-group select{width:100%;padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--color-border);background:var(--color-bg);color:var(--color-text);font-size:var(--font-size-sm);text-overflow:ellipsis;overflow:hidden}.control-group select:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40}.control-group select:disabled{opacity:.5;cursor:not-allowed}.preview-toggles{display:flex;justify-content:center;gap:var(--space-6);margin:var(--space-3) 0}.preview-toggles label{display:flex;align-items:center;gap:var(--space-2);font-size:var(--font-size-base);color:var(--color-text);cursor:pointer}.preview-toggles input[type=checkbox]{width:18px;height:18px;accent-color:var(--color-primary);cursor:pointer}.meeting-name-field{margin-bottom:var(--space-4);display:flex;flex-direction:column}.meeting-name-field label{font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);color:var(--color-text-secondary);margin-bottom:var(--space-1)}.meeting-name-field input,.meeting-name-field textarea,.meeting-name-field select{padding:var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--color-border);background:var(--color-bg);color:var(--color-text);font-size:var(--font-size-base);font-family:var(--font-family);resize:vertical}.meeting-name-field input[type=checkbox]{width:18px;height:18px;padding:0;flex:none;accent-color:var(--color-primary);cursor:pointer}.meeting-name-field .checkbox-row{display:flex;align-items:center;gap:10px}.meeting-name-field .checkbox-row label{margin:0;cursor:pointer;font-size:var(--font-size-base);font-weight:var(--font-weight-regular, 400);color:var(--color-text);line-height:18px}.meeting-name-field input:focus,.meeting-name-field textarea:focus,.meeting-name-field select:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40;outline:none}.error-popup{background:#dc26261a;border:1px solid rgba(220,38,38,.2);padding:var(--space-3) var(--space-4);margin-bottom:var(--space-3);border-radius:var(--radius-sm);text-align:center;color:#f87171;font-size:var(--font-size-sm)}.error-popup button{margin-top:var(--space-2);background:transparent;border:1px solid rgba(220,38,38,.3);color:#f87171;padding:var(--space-1) var(--space-3);border-radius:var(--radius-sm);cursor:pointer;font-size:var(--font-size-sm)}.error-popup button:hover{background:#dc26261a}", aE = ".scheduler-modal{width:460px;padding:var(--space-6)}.scheduler-modal h2{text-align:center;margin-bottom:var(--space-6);font-size:var(--font-size-xl);color:var(--color-text)}.scheduler-modal .form-group{display:flex;flex-direction:column;margin-bottom:var(--space-4)}.scheduler-modal .form-group label{font-size:var(--font-size-sm);font-weight:var(--font-weight-medium);color:var(--color-text-secondary);margin-bottom:var(--space-1)}.scheduler-modal .form-group input,.scheduler-modal .form-group select,.scheduler-modal .form-group textarea{padding:var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--color-border);background:var(--color-bg);color:var(--color-text);font-size:var(--font-size-base);font-family:var(--font-family);resize:vertical}.scheduler-modal .form-group input[type=checkbox]{width:18px;height:18px;padding:0;flex:none;accent-color:var(--color-primary);cursor:pointer}.scheduler-modal .form-group .checkbox-row{display:flex;align-items:flex-start;gap:10px}.scheduler-modal .form-group .checkbox-row>input[type=checkbox]{margin-top:2px}.scheduler-modal .form-group .checkbox-text{display:flex;flex-direction:column;gap:2px}.scheduler-modal .form-group .checkbox-text label{margin:0;cursor:pointer;font-size:var(--font-size-base);font-weight:var(--font-weight-regular, 400);color:var(--color-text);line-height:18px;text-align:left}.scheduler-modal .form-group .checkbox-text .checkbox-helper{font-size:12px;color:var(--color-text-secondary);line-height:1.4;text-align:left}.scheduler-modal .form-group input:focus,.scheduler-modal .form-group select:focus,.scheduler-modal .form-group textarea:focus{border-color:var(--color-border-focus);box-shadow:0 0 0 2px #2563eb40;outline:none}.form-row{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4)}.form-row label{display:flex;align-items:center;gap:var(--space-2);font-size:var(--font-size-base);color:var(--color-text);cursor:pointer}.form-row input[type=checkbox]{width:18px;height:18px;accent-color:var(--color-primary);cursor:pointer}", nE = ".toast-stack{position:fixed;left:50%;bottom:32px;transform:translate(-50%);display:flex;flex-direction:column-reverse;gap:10px;z-index:4000;pointer-events:none}.toast{pointer-events:auto;display:inline-flex;align-items:center;gap:10px;min-width:220px;max-width:480px;padding:12px 16px;border-radius:10px;font-size:14px;line-height:1.4;border:1px solid transparent;background:var(--color-surface-elevated, #ffffff);color:var(--color-text, #1f2937);box-shadow:0 8px 28px -10px #00000040;animation:toast-fade 3.2s ease forwards}.toast-icon{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;flex-shrink:0}.toast-success{border-color:#bbf7d0;background:#f0fdf4;color:#166534}.toast-success .toast-icon{background:#16a34a;color:#fff}.toast-error{border-color:#fecaca;background:#fef2f2;color:#b91c1c}.toast-error .toast-icon{background:#dc2626;color:#fff}.toast-info{border-color:#bfdbfe;background:#eff6ff;color:#1e40af}.toast-info .toast-icon{background:#2563eb;color:#fff}[data-theme=dark] .toast-success{background:#052e1a;color:#4ade80;border-color:#166534}[data-theme=dark] .toast-error{background:#2a0a0a;color:#f87171;border-color:#7f1d1d}[data-theme=dark] .toast-info{background:#0b1f3a;color:#93c5fd;border-color:#1e3a8a}@keyframes toast-fade{0%{opacity:0;transform:translateY(10px)}10%{opacity:1;transform:translateY(0)}90%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-6px)}}", rE = '@charset "UTF-8";.react-datepicker__navigation-icon:before,.react-datepicker__year-read-view--down-arrow,.react-datepicker__month-read-view--down-arrow,.react-datepicker__month-year-read-view--down-arrow{border-color:#ccc;border-style:solid;border-width:3px 3px 0 0;content:"";display:block;height:9px;position:absolute;top:6px;width:9px}.react-datepicker__sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap;border:0}.react-datepicker-wrapper{display:inline-block;padding:0;border:0}.react-datepicker{font-family:Helvetica Neue,helvetica,arial,sans-serif;font-size:.8rem;background-color:#fff;color:#000;border:1px solid #aeaeae;border-radius:.3rem;display:inline-block;position:relative;line-height:initial}.react-datepicker--time-only .react-datepicker__time-container{border-left:0}.react-datepicker--time-only .react-datepicker__time,.react-datepicker--time-only .react-datepicker__time-box{border-bottom-left-radius:.375em;border-bottom-right-radius:.375em}.react-datepicker-popper{z-index:1;line-height:0}.react-datepicker-popper .react-datepicker__triangle{stroke:#aeaeae}.react-datepicker-popper[data-placement^=bottom] .react-datepicker__triangle{fill:#f0f0f0;color:#f0f0f0}.react-datepicker-popper[data-placement^=top] .react-datepicker__triangle,.react-datepicker-popper--header-middle[data-placement^=bottom] .react-datepicker__triangle,.react-datepicker-popper--header-bottom[data-placement^=bottom] .react-datepicker__triangle{fill:#fff;color:#fff}.react-datepicker-popper--header-bottom[data-placement^=top] .react-datepicker__triangle{fill:#f0f0f0;color:#f0f0f0}.react-datepicker__header{text-align:center;background-color:#f0f0f0;border-bottom:1px solid #aeaeae;border-top-left-radius:.3rem;padding:8px 0;position:relative}.react-datepicker__header--time{padding-bottom:8px;padding-left:5px;padding-right:5px}.react-datepicker__header--time:not(.react-datepicker__header--time--only){border-top-left-radius:0}.react-datepicker__header:not(.react-datepicker__header--has-time-select,.react-datepicker__header--middle,.react-datepicker__header--bottom){border-top-right-radius:.3rem}.react-datepicker__header--middle{border-top:1px solid #aeaeae;border-radius:0;margin-top:4px}.react-datepicker__header--bottom{border-bottom:none;border-top:1px solid #aeaeae;border-radius:0 0 .3rem .3rem}.react-datepicker__header-wrapper{position:relative}.react-datepicker__header-wrapper .react-datepicker__navigation--next--with-time:not(.react-datepicker__navigation--next--with-today-button){right:2px}.react-datepicker__year-dropdown-container--select,.react-datepicker__month-dropdown-container--select,.react-datepicker__month-year-dropdown-container--select,.react-datepicker__year-dropdown-container--scroll,.react-datepicker__month-dropdown-container--scroll,.react-datepicker__month-year-dropdown-container--scroll{display:inline-block;margin:0 15px}.react-datepicker__month-select,.react-datepicker__year-select,.react-datepicker__month-year-select{background-color:transparent;border:1px solid #aeaeae;border-radius:.3rem;color:inherit;cursor:pointer;font-family:inherit;font-size:inherit;margin-top:5px;padding:2px 5px}.react-datepicker__month-select:focus-visible,.react-datepicker__year-select:focus-visible,.react-datepicker__month-year-select:focus-visible{outline:auto 1px}.react-datepicker__current-month,.react-datepicker-time__header,.react-datepicker-year-header{margin-top:0;color:#000;font-weight:700;font-size:.944rem}h2.react-datepicker__current-month{padding:0;margin:0}.react-datepicker-time__header{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.react-datepicker__navigation{align-items:center;background:none;display:flex;justify-content:center;text-align:center;cursor:pointer;position:absolute;top:2px;padding:0;border:none;z-index:1;height:32px;width:32px;text-indent:-999em;overflow:hidden}.react-datepicker__navigation--previous{left:2px}.react-datepicker__navigation--next{right:2px}.react-datepicker__navigation--next--with-time:not(.react-datepicker__navigation--next--with-today-button){right:85px}.react-datepicker__navigation--years{position:relative;top:0;display:block;margin-left:auto;margin-right:auto}.react-datepicker__navigation--years-previous{top:4px}.react-datepicker__navigation--years-upcoming{top:-4px}.react-datepicker__navigation:hover *:before{border-color:#a6a6a6}.react-datepicker__navigation-icon{position:relative;top:-1px;font-size:20px;width:0}.react-datepicker__navigation-icon--next{left:-2px}.react-datepicker__navigation-icon--next:before{transform:rotate(45deg);left:-7px}.react-datepicker__navigation-icon--previous{right:-2px}.react-datepicker__navigation-icon--previous:before{transform:rotate(225deg);right:-7px}.react-datepicker__month-container{float:left}.react-datepicker__year{margin:.5em;text-align:center}.react-datepicker__year-wrapper{display:flex;flex-wrap:wrap;max-width:180px}.react-datepicker__year .react-datepicker__year-text{display:inline-block;width:5em;margin:2px}.react-datepicker__month{margin:.5em;text-align:center}.react-datepicker__month .react-datepicker__month-text,.react-datepicker__month .react-datepicker__quarter-text{display:inline-block;width:5em;margin:2px}.react-datepicker__input-time-container{clear:both;width:100%;float:left;margin:5px 0 10px 15px;text-align:left}.react-datepicker__input-time-container .react-datepicker-time__caption,.react-datepicker__input-time-container .react-datepicker-time__input-container{display:inline-block}.react-datepicker__input-time-container .react-datepicker-time__input-container .react-datepicker-time__input{display:inline-block;margin-left:10px}.react-datepicker__input-time-container .react-datepicker-time__input-container .react-datepicker-time__input input{width:auto}.react-datepicker__input-time-container .react-datepicker-time__input-container .react-datepicker-time__input input[type=time]::-webkit-inner-spin-button,.react-datepicker__input-time-container .react-datepicker-time__input-container .react-datepicker-time__input input[type=time]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.react-datepicker__input-time-container .react-datepicker-time__input-container .react-datepicker-time__input input[type=time]{-moz-appearance:textfield}.react-datepicker__input-time-container .react-datepicker-time__input-container .react-datepicker-time__delimiter{margin-left:5px;display:inline-block}.react-datepicker__time-container{float:right;border-left:1px solid #aeaeae;width:85px}.react-datepicker__time-container--with-today-button{display:inline;border:1px solid #aeaeae;border-radius:.375em;position:absolute;right:-87px;top:0}.react-datepicker__time-container .react-datepicker__time{position:relative;background:#fff;border-bottom-right-radius:.375em}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box{width:85px;overflow-x:hidden;margin:0 auto;text-align:center;border-bottom-right-radius:.375em}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box ul.react-datepicker__time-list{list-style:none;margin:0;height:calc(195px + 1.0625em);overflow-y:scroll;padding-right:0;padding-left:0;width:100%;box-sizing:content-box}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box ul.react-datepicker__time-list li.react-datepicker__time-list-item{height:30px;padding:5px 10px;white-space:nowrap}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box ul.react-datepicker__time-list li.react-datepicker__time-list-item:hover{cursor:pointer;background-color:#f0f0f0}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box ul.react-datepicker__time-list li.react-datepicker__time-list-item--selected{background-color:#216ba5;color:#fff;font-weight:700}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box ul.react-datepicker__time-list li.react-datepicker__time-list-item--selected:hover{background-color:#216ba5}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box ul.react-datepicker__time-list li.react-datepicker__time-list-item--disabled{color:#ccc}.react-datepicker__time-container .react-datepicker__time .react-datepicker__time-box ul.react-datepicker__time-list li.react-datepicker__time-list-item--disabled:hover{cursor:default;background-color:transparent}.react-datepicker__week-number{color:#ccc;display:inline-block;width:2.125em;line-height:2.125em;text-align:center;margin:.208em}.react-datepicker__week-number.react-datepicker__week-number--clickable{cursor:pointer}.react-datepicker__week-number.react-datepicker__week-number--clickable:not(.react-datepicker__week-number--selected):hover{border-radius:.3rem;background-color:#f0f0f0}.react-datepicker__week-number--selected{border-radius:.3rem;background-color:#216ba5;color:#fff}.react-datepicker__week-number--selected:hover{background-color:#1d5d90}.react-datepicker__day-names{text-align:center;white-space:nowrap;margin-bottom:-8px}.react-datepicker__week{white-space:nowrap}.react-datepicker__day-name,.react-datepicker__day,.react-datepicker__time-name{color:#000;display:inline-block;width:2.125em;line-height:2.125em;text-align:center;margin:.208em}.react-datepicker__day-name--disabled,.react-datepicker__day--disabled,.react-datepicker__time-name--disabled{cursor:default;color:#ccc}.react-datepicker__day,.react-datepicker__month-text,.react-datepicker__quarter-text,.react-datepicker__year-text{cursor:pointer}.react-datepicker__day:not([aria-disabled=true]):hover,.react-datepicker__month-text:not([aria-disabled=true]):hover,.react-datepicker__quarter-text:not([aria-disabled=true]):hover,.react-datepicker__year-text:not([aria-disabled=true]):hover{border-radius:.3rem;background-color:#f0f0f0}.react-datepicker__day--today,.react-datepicker__month-text--today,.react-datepicker__quarter-text--today,.react-datepicker__year-text--today{font-weight:700}.react-datepicker__day--highlighted,.react-datepicker__month-text--highlighted,.react-datepicker__quarter-text--highlighted,.react-datepicker__year-text--highlighted{border-radius:.3rem;background-color:#3dcc4a;color:#fff}.react-datepicker__day--highlighted:not([aria-disabled=true]):hover,.react-datepicker__month-text--highlighted:not([aria-disabled=true]):hover,.react-datepicker__quarter-text--highlighted:not([aria-disabled=true]):hover,.react-datepicker__year-text--highlighted:not([aria-disabled=true]):hover{background-color:#32be3f}.react-datepicker__day--highlighted-custom-1,.react-datepicker__month-text--highlighted-custom-1,.react-datepicker__quarter-text--highlighted-custom-1,.react-datepicker__year-text--highlighted-custom-1{color:#f0f}.react-datepicker__day--highlighted-custom-2,.react-datepicker__month-text--highlighted-custom-2,.react-datepicker__quarter-text--highlighted-custom-2,.react-datepicker__year-text--highlighted-custom-2{color:green}.react-datepicker__day--holidays,.react-datepicker__month-text--holidays,.react-datepicker__quarter-text--holidays,.react-datepicker__year-text--holidays{position:relative;border-radius:.3rem;background-color:#ff6803;color:#fff}.react-datepicker__day--holidays .overlay,.react-datepicker__month-text--holidays .overlay,.react-datepicker__quarter-text--holidays .overlay,.react-datepicker__year-text--holidays .overlay{position:absolute;bottom:100%;left:50%;transform:translate(-50%);background-color:#333;color:#fff;padding:4px;border-radius:4px;white-space:nowrap;visibility:hidden;opacity:0;transition:visibility 0s,opacity .3s ease-in-out}.react-datepicker__day--holidays:not([aria-disabled=true]):hover,.react-datepicker__month-text--holidays:not([aria-disabled=true]):hover,.react-datepicker__quarter-text--holidays:not([aria-disabled=true]):hover,.react-datepicker__year-text--holidays:not([aria-disabled=true]):hover{background-color:#cf5300}.react-datepicker__day--holidays:hover .overlay,.react-datepicker__month-text--holidays:hover .overlay,.react-datepicker__quarter-text--holidays:hover .overlay,.react-datepicker__year-text--holidays:hover .overlay{visibility:visible;opacity:1}.react-datepicker__day--selected,.react-datepicker__day--in-selecting-range,.react-datepicker__day--in-range,.react-datepicker__month-text--selected,.react-datepicker__month-text--in-selecting-range,.react-datepicker__month-text--in-range,.react-datepicker__quarter-text--selected,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__quarter-text--in-range,.react-datepicker__year-text--selected,.react-datepicker__year-text--in-selecting-range,.react-datepicker__year-text--in-range{border-radius:.3rem;background-color:#216ba5;color:#fff}.react-datepicker__day--selected:not([aria-disabled=true]):hover,.react-datepicker__day--in-selecting-range:not([aria-disabled=true]):hover,.react-datepicker__day--in-range:not([aria-disabled=true]):hover,.react-datepicker__month-text--selected:not([aria-disabled=true]):hover,.react-datepicker__month-text--in-selecting-range:not([aria-disabled=true]):hover,.react-datepicker__month-text--in-range:not([aria-disabled=true]):hover,.react-datepicker__quarter-text--selected:not([aria-disabled=true]):hover,.react-datepicker__quarter-text--in-selecting-range:not([aria-disabled=true]):hover,.react-datepicker__quarter-text--in-range:not([aria-disabled=true]):hover,.react-datepicker__year-text--selected:not([aria-disabled=true]):hover,.react-datepicker__year-text--in-selecting-range:not([aria-disabled=true]):hover,.react-datepicker__year-text--in-range:not([aria-disabled=true]):hover{background-color:#1d5d90}.react-datepicker__day--keyboard-selected,.react-datepicker__month-text--keyboard-selected,.react-datepicker__quarter-text--keyboard-selected,.react-datepicker__year-text--keyboard-selected{border-radius:.3rem;background-color:#bad9f1;color:#000}.react-datepicker__day--keyboard-selected:not([aria-disabled=true]):hover,.react-datepicker__month-text--keyboard-selected:not([aria-disabled=true]):hover,.react-datepicker__quarter-text--keyboard-selected:not([aria-disabled=true]):hover,.react-datepicker__year-text--keyboard-selected:not([aria-disabled=true]):hover{background-color:#1d5d90;color:#fff}.react-datepicker__day--in-selecting-range:not(.react-datepicker__day--in-range,.react-datepicker__month-text--in-range,.react-datepicker__quarter-text--in-range,.react-datepicker__year-text--in-range),.react-datepicker__month-text--in-selecting-range:not(.react-datepicker__day--in-range,.react-datepicker__month-text--in-range,.react-datepicker__quarter-text--in-range,.react-datepicker__year-text--in-range),.react-datepicker__quarter-text--in-selecting-range:not(.react-datepicker__day--in-range,.react-datepicker__month-text--in-range,.react-datepicker__quarter-text--in-range,.react-datepicker__year-text--in-range),.react-datepicker__year-text--in-selecting-range:not(.react-datepicker__day--in-range,.react-datepicker__month-text--in-range,.react-datepicker__quarter-text--in-range,.react-datepicker__year-text--in-range){background-color:#216ba580}.react-datepicker__month--selecting-range .react-datepicker__day--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range),.react-datepicker__year--selecting-range .react-datepicker__day--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range),.react-datepicker__month--selecting-range .react-datepicker__month-text--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range),.react-datepicker__year--selecting-range .react-datepicker__month-text--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range),.react-datepicker__month--selecting-range .react-datepicker__quarter-text--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range),.react-datepicker__year--selecting-range .react-datepicker__quarter-text--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range),.react-datepicker__month--selecting-range .react-datepicker__year-text--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range),.react-datepicker__year--selecting-range .react-datepicker__year-text--in-range:not(.react-datepicker__day--in-selecting-range,.react-datepicker__month-text--in-selecting-range,.react-datepicker__quarter-text--in-selecting-range,.react-datepicker__year-text--in-selecting-range){background-color:#f0f0f0;color:#000}.react-datepicker__day--disabled,.react-datepicker__month-text--disabled,.react-datepicker__quarter-text--disabled,.react-datepicker__year-text--disabled{cursor:default;color:#ccc}.react-datepicker__day--disabled .overlay,.react-datepicker__month-text--disabled .overlay,.react-datepicker__quarter-text--disabled .overlay,.react-datepicker__year-text--disabled .overlay{position:absolute;bottom:70%;left:50%;transform:translate(-50%);background-color:#333;color:#fff;padding:4px;border-radius:4px;white-space:nowrap;visibility:hidden;opacity:0;transition:visibility 0s,opacity .3s ease-in-out}.react-datepicker__input-container{position:relative;display:inline-block;width:100%}.react-datepicker__input-container .react-datepicker__calendar-icon{position:absolute;padding:.625em;box-sizing:content-box}.react-datepicker__view-calendar-icon input{padding:6px 10px 5px 25px}.react-datepicker__year-read-view,.react-datepicker__month-read-view,.react-datepicker__month-year-read-view{border:1px solid transparent;border-radius:.3rem;position:relative}.react-datepicker__year-read-view:hover,.react-datepicker__month-read-view:hover,.react-datepicker__month-year-read-view:hover{cursor:pointer}.react-datepicker__year-read-view:hover .react-datepicker__year-read-view--down-arrow,.react-datepicker__year-read-view:hover .react-datepicker__month-read-view--down-arrow,.react-datepicker__month-read-view:hover .react-datepicker__year-read-view--down-arrow,.react-datepicker__month-read-view:hover .react-datepicker__month-read-view--down-arrow,.react-datepicker__month-year-read-view:hover .react-datepicker__year-read-view--down-arrow,.react-datepicker__month-year-read-view:hover .react-datepicker__month-read-view--down-arrow{border-top-color:#b3b3b3}.react-datepicker__year-read-view--down-arrow,.react-datepicker__month-read-view--down-arrow,.react-datepicker__month-year-read-view--down-arrow{transform:rotate(135deg);right:-16px;top:0}.react-datepicker__year-dropdown,.react-datepicker__month-dropdown,.react-datepicker__month-year-dropdown{background-color:#f0f0f0;position:absolute;width:50%;left:25%;top:30px;z-index:1;text-align:center;border-radius:.3rem;border:1px solid #aeaeae}.react-datepicker__year-dropdown:hover,.react-datepicker__month-dropdown:hover,.react-datepicker__month-year-dropdown:hover{cursor:pointer}.react-datepicker__year-dropdown--scrollable,.react-datepicker__month-dropdown--scrollable,.react-datepicker__month-year-dropdown--scrollable{height:150px;overflow-y:scroll}.react-datepicker__year-option,.react-datepicker__month-option,.react-datepicker__month-year-option{line-height:20px;width:100%;display:block;margin-left:auto;margin-right:auto}.react-datepicker__year-option:first-of-type,.react-datepicker__month-option:first-of-type,.react-datepicker__month-year-option:first-of-type{border-top-left-radius:.3rem;border-top-right-radius:.3rem}.react-datepicker__year-option:last-of-type,.react-datepicker__month-option:last-of-type,.react-datepicker__month-year-option:last-of-type{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-bottom-left-radius:.3rem;border-bottom-right-radius:.3rem}.react-datepicker__year-option:hover,.react-datepicker__month-option:hover,.react-datepicker__month-year-option:hover{background-color:#ccc}.react-datepicker__year-option:hover .react-datepicker__navigation--years-upcoming,.react-datepicker__month-option:hover .react-datepicker__navigation--years-upcoming,.react-datepicker__month-year-option:hover .react-datepicker__navigation--years-upcoming{border-bottom-color:#b3b3b3}.react-datepicker__year-option:hover .react-datepicker__navigation--years-previous,.react-datepicker__month-option:hover .react-datepicker__navigation--years-previous,.react-datepicker__month-year-option:hover .react-datepicker__navigation--years-previous{border-top-color:#b3b3b3}.react-datepicker__year-option--selected,.react-datepicker__month-option--selected,.react-datepicker__month-year-option--selected{position:absolute;left:15px}.react-datepicker__close-icon{cursor:pointer;background-color:transparent;border:0;outline:0;padding:0 6px 0 0;position:absolute;top:0;right:0;height:100%;display:table-cell;vertical-align:middle}.react-datepicker__close-icon:after{cursor:pointer;background-color:#216ba5;color:#fff;border-radius:50%;height:16px;width:16px;padding:2px;font-size:12px;line-height:1;text-align:center;display:table-cell;vertical-align:middle;content:"×"}.react-datepicker__close-icon--disabled{cursor:default}.react-datepicker__close-icon--disabled:after{cursor:default;background-color:#ccc}.react-datepicker__today-button{background:#f0f0f0;border-top:1px solid #aeaeae;cursor:pointer;text-align:center;font-weight:700;padding:5px 0;clear:left}.react-datepicker__portal{position:fixed;width:100vw;height:100vh;background-color:#000c;left:0;top:0;justify-content:center;align-items:center;display:flex;z-index:2147483647}.react-datepicker__children-container{width:17.25em;margin:.5em;padding-right:.25em;padding-left:.25em;height:auto}.react-datepicker__aria-live{position:absolute;clip-path:circle(0);border:0;height:1px;margin:-1px;overflow:hidden;padding:0;width:1px;white-space:nowrap}.react-datepicker__calendar-icon{width:1em;height:1em;vertical-align:-.125em}.react-datepicker-popper-offset{margin-top:-.7em}', iE = [
  ID,
  JD,
  $D,
  eE,
  tE,
  aE,
  nE,
  rE
].join(`
`), oE = "__OATICONNECT_BUILD__";
function lE(o) {
  return o.replace(/[&<>"']/g, (i) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[i]);
}
try {
  console.log("[oaticonnect-meet] bundle build=" + oE);
} catch {
}
let Id = null;
function sE() {
  return Id || (Id = Hw()), Id;
}
class cE extends HTMLElement {
  root = null;
  shadow = null;
  mountEl = null;
  /** True once the config fetch has resolved and React has mounted at
   *  least once. Until then, attribute changes only update local state —
   *  rendering the React tree is gated on configReady to guarantee
   *  getConfig() never throws. */
  configLoaded = !1;
  static get observedAttributes() {
    return ["api-base", "user-id", "user-name", "user-email", "user-role", "theme"];
  }
  connectedCallback() {
    this.shadow = this.attachShadow({ mode: "open" });
    const i = iE.replace(/:root\s*\{/g, ":host, #oaticonnect-root {").replace(/\bhtml\s*,\s*body\s*,\s*#root\b/g, "#oaticonnect-root").replace(/\bbody\s*\{/g, "#oaticonnect-root {"), n = document.createElement("style");
    if (n.textContent = i, this.shadow.appendChild(n), !document.querySelector('link[href*="fonts.googleapis.com/css2?family=Inter"]')) {
      const l = document.createElement("link");
      l.rel = "stylesheet", l.href = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap", document.head.appendChild(l);
    }
    const a = document.createElement("div");
    a.id = "oaticonnect-root", a.style.fontFamily = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", a.style.minHeight = "100%", this.shadow.appendChild(a), this.mountEl = a, a.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;min-height:200px;color:#6b7280;font-size:14px;">Loading OATIConnect…</div>', this.root = Jx.createRoot(a), sE().then(() => {
      this.configLoaded = !0, this.mountEl && (this.mountEl.innerHTML = ""), this.render();
    }).catch((l) => {
      if (console.error("[oaticonnect-meet] /api/v1/config load failed", l), this.mountEl) {
        const c = l && l.message || String(l);
        this.mountEl.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;min-height:200px;padding:24px;color:#b91c1c;font-size:14px;text-align:center;"><div style="font-size:32px;margin-bottom:8px;">⚠️</div><div><strong>Could not load OATIConnect.</strong></div><div style="margin-top:8px;color:#6b7280;font-size:12px;">/api/v1/config failed: ' + lE(c) + "</div></div>";
      }
    });
  }
  attributeChangedCallback() {
    this.configLoaded && this.render();
  }
  disconnectedCallback() {
    this.root?.unmount();
  }
  getConfig() {
    const i = this.getAttribute("user-id"), n = i ? Number.parseInt(i, 10) : NaN;
    return {
      apiBase: this.getAttribute("api-base") || "/api/v1",
      user: Number.isFinite(n) && n > 0 ? {
        id: n,
        name: this.getAttribute("user-name") || "",
        email: this.getAttribute("user-email") || "",
        role: this.getAttribute("user-role") || "Standard"
      } : null,
      theme: this.getAttribute("theme") || "light"
    };
  }
  render() {
    if (!this.root) return;
    const i = this.getConfig(), n = this.shadow?.getElementById("oaticonnect-root");
    n && n.setAttribute("data-theme", i.theme), this.root.render(
      /* @__PURE__ */ h.jsx(B.StrictMode, { children: /* @__PURE__ */ h.jsx(WD, { config: i }) })
    );
  }
}
customElements.define("oaticonnect-meet", cE);
