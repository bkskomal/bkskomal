using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace OATIConnect.Client.Controllers;

/// <summary>
/// Demo cookie-auth flow for OATIConnect.Client. Production hosts replace
/// this with their own login pipeline — webVision uses Forms / OIDC.
/// Here we just bake user-id, role, and timezone into a signed cookie so
/// <see cref="OATIConnectExternalAPI"/> can read them back on every API
/// call without depending on webVision's UserContext.
/// </summary>
[ApiController]
[AllowAnonymous]
[Route("")]
public class HostAuthController : ControllerBase
{
    public record LoginRequest(int UserId, string? Role, string? TimeZone, string? Name);

    [HttpGet("login")]
    public ContentResult LoginPage()
    {
        var html = @"<!DOCTYPE html>
<html lang=""en""><head><meta charset=""utf-8""><title>Sign in — OATIConnect demo</title>
<style>
  body{font-family:'Segoe UI',Roboto,sans-serif;max-width:520px;margin:80px auto;padding:0 24px;color:#111827;background:#f9fafb}
  h1{color:#2563eb;margin-bottom:4px}
  .sub{color:#6b7280;margin-bottom:32px}
  fieldset{border:1px solid #e5e7eb;border-radius:8px;padding:16px 20px;margin-bottom:16px;background:#fff}
  legend{font-weight:600;color:#374151;padding:0 6px}
  label{display:block;margin:8px 0 4px;font-size:13px;color:#374151;font-weight:500}
  select,input{width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;box-sizing:border-box}
  button{margin-top:8px;width:100%;padding:11px 16px;background:#2563eb;color:#fff;border:0;border-radius:6px;font-weight:600;font-size:14px;cursor:pointer}
  button:hover{background:#1d4ed8}
  .row{display:flex;gap:12px}
  .row > div{flex:1}
  small{color:#6b7280;font-size:12px}
</style></head><body>
  <h1>OATIConnect demo</h1>
  <p class=""sub"">Sign in to mount the embedded React UI. The form mimics what a production host (e.g. OATIHub) populates from its own user store — user id, role, and timezone are written into a cookie that <code>OATIConnectExternalAPI</code> reads back on every API call.</p>
  <fieldset>
    <legend>User</legend>
    <label>User id</label><input id=""uid"" type=""number"" value=""1"" min=""1"" />
    <label>Display name</label><input id=""name"" value=""Demo User"" />
    <div class=""row"">
      <div>
        <label>Role</label>
        <select id=""role""><option>Admin</option><option>Moderator</option><option>Standard</option></select>
      </div>
      <div>
        <label>Timezone (Windows id, IANA, or 3-letter abbr)</label>
        <select id=""tz"">
          <option value=""Central Standard Time"">Central Standard Time (CDT/CST — Chicago)</option>
          <option value=""Eastern Standard Time"">Eastern Standard Time (EDT/EST — New York)</option>
          <option value=""Pacific Standard Time"">Pacific Standard Time (PDT/PST — Los Angeles)</option>
          <option value=""GMT Standard Time"">GMT Standard Time (BST/GMT — London)</option>
          <option value=""India Standard Time"">India Standard Time (IST — Kolkata)</option>
          <option value=""Tokyo Standard Time"">Tokyo Standard Time (JST)</option>
          <option value=""UTC"">UTC</option>
        </select>
      </div>
    </div>
    <small>The DLL maps both Windows ids and bare 3-letter abbreviations to IANA via <code>TimeZoneMapper.ToIana</code>. DST is honored automatically.</small>
    <button onclick=""signin()"">Sign in</button>
  </fieldset>
  <script>
    function signin() {
      const body = {
        userId: parseInt(document.getElementById('uid').value, 10),
        role:   document.getElementById('role').value,
        timeZone: document.getElementById('tz').value,
        name:   document.getElementById('name').value,
      };
      fetch('/api/host/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), credentials: 'include' })
        .then(r => { if (!r.ok) throw new Error('login failed'); window.location = '/'; })
        .catch(e => alert(e.message));
    }
  </script>
</body></html>";
        return new ContentResult { Content = html, ContentType = "text/html", StatusCode = 200 };
    }

    [HttpPost("api/host/login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        if (req == null || req.UserId <= 0) return BadRequest("userId required");
        var role = string.IsNullOrWhiteSpace(req.Role) ? "Standard" : req.Role!;
        var tz   = string.IsNullOrWhiteSpace(req.TimeZone) ? "Central Standard Time" : req.TimeZone!;
        var name = string.IsNullOrWhiteSpace(req.Name) ? $"User {req.UserId}" : req.Name!;

        var identity = new ClaimsIdentity(new[]
        {
            new Claim("user-id",       req.UserId.ToString()),
            new Claim("user-name",     name),
            new Claim(ClaimTypes.Role, role),
            new Claim("user-tz",       tz),
            new Claim(ClaimTypes.Email, $"user{req.UserId}@local"),
        }, CookieAuthenticationDefaults.AuthenticationScheme);

        await HttpContext.SignInAsync(new ClaimsPrincipal(identity));
        return Ok();
    }

    [HttpGet("api/host/logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync();
        return Redirect("/login");
    }
}
