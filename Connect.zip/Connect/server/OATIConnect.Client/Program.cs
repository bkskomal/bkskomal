using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using OATIConnect.API;
using OATIConnect.Client;
using OATIConnect.EntityFramework;
using OATIConnect.EntityFramework.Models;
// OATIConnect.Server namespace contributes types from two assemblies:
//   * OATIConnect.API.dll  — OATIConnectSettings, UseOATIConnect extension
//   * OATIConnect.Server.dll — OATIConnectRepository (the host's EF layer)
// Both are pulled in by one `using` because C# namespaces span assemblies.
using OATIConnect.Server;

// =============================================================================
// OATIConnect.Client — demo host application. Mirrors the production
// OATIHub integration shape after the 2.2.5.0 architecture change:
//
//   * OATIConnect.API         = shippable DLL (business logic + controllers
//                               + services). Depends on the single host
//                               seam IOATIConnectExternalAPI.
//   * OATIConnect.EntityFramework
//                             = host-owned EF context + entities. The DLL
//                               never sees these — they're an implementation
//                               detail of the host's repository.
//   * OATIConnect.Client      = this executable. Owns auth, the DbContext,
//                               OATIConnectExternalAPI (the single seam
//                               implementation) and OATIConnectRepository
//                               (its EF-backed delegate).
//
// The old OATIConnect.Server project (controller-as-data-provider) is gone:
// there's no more loopback HTTP path, no more IIS POST 502 risk. React
// requests hit OATIConnect.API's controllers, which call services, which
// call IOATIConnectExternalAPI → the host's repository → EF → DB.
// =============================================================================

var builder = WebApplication.CreateBuilder(args);

// 1. Cookie auth (host-owned).
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath  = "/login";
        options.Cookie.Name = "OATIConnect.Demo.Auth";
    });
builder.Services.AddAuthorization();

// 2. Host-owned EF Core layer (SQLite — file appears next to the exe).
//    Production points OATIConnect at the framework DB via its own context.
builder.Services.AddDbContext<OATIConnectDbContext>(opt =>
    opt.UseSqlite("Data Source=oaticonnect-demo.db"));

// 3. The single host seam. OATIConnectExternalAPI is a thin facade that
//    delegates persistence to OATIConnectRepository — the layering the
//    production host should adopt verbatim. CurrentUserContext is the
//    per-request user holder (populated by CurrentUserMiddleware below)
//    — replaces IHttpContextAccessor in the user-identity path so the
//    facade has zero direct request-API dependency.
builder.Services.AddScoped<CurrentUserContext>();
// Bind the new repository seam to the demo's EF Core implementation.
// Hosts that want to substitute their own data layer (test fake,
// in-memory store, alternate ORM, extra-instrumented variant) register
// a different IOATIConnectRepository binding before UseOATIConnect.
builder.Services.AddScoped<IOATIConnectRepository, OATIConnectRepository>();
builder.Services.AddScoped<IOATIConnectExternalAPI, OATIConnectExternalAPI>();
// Demo URL provider — reads scheme+host out of the per-request
// CurrentUserContext (populated by CurrentUserMiddleware) so the URLs
// we bake into outbound invitations match whatever the admin is
// browsing. Registered BEFORE UseOATIConnect so the DLL's TryAdd
// fallback (NullRequestUrlProvider) is pre-empted.
builder.Services.AddScoped<IOATIConnectRequestUrlProvider, DemoRequestUrlProvider>();

// 4. MVC + OATIConnect's own controllers (registered as part of MapControllers
//    via the DLL's ApplicationPart hook in AddOATIConnect).
builder.Services.AddControllers().AddControllersAsServices();

// 5. OATIConnect core services + sidecar binding. UseOATIConnect() reads
//    oaticonnect_config.json from the host content root, registers
//    OATIConnectSettings as a singleton, and registers the DLL's services
//    (meeting service, Jitsi token issuer, settings service, controllers).
//    Must come AFTER step 3 so IOATIConnectExternalAPI is already in the
//    container when the DLL's services resolve.
builder.Services.UseOATIConnect();

// CORS — keep dev origins open so the React Vite server can hit us.
var allowedOrigins = builder.Configuration.GetSection("AllowedOrigins").Get<string[]>()
    ?? new[] { "http://localhost:5173", "http://localhost:5174" };
builder.Services.AddCors(options =>
{
    options.AddPolicy("ui", policy =>
        policy.WithOrigins(allowedOrigins).AllowAnyHeader().AllowAnyMethod().AllowCredentials());
});

builder.Services.AddHealthChecks();

var app = builder.Build();

// 6. Bring up the SQLite DB + seed the AppConfigs the React shell expects on
//    bootstrap. The DLL's MapOATIConnect() seeder also runs but it goes
//    through IOATIConnectExternalAPI — which is now ready. Doing it here
//    first keeps startup robust regardless of registration order.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<OATIConnectDbContext>();
    db.Database.EnsureCreated();

    void Seed(string key, string value, string desc, string cat)
    {
        if (db.OATIConnectAppConfigs.Any(c => c.Key == key)) return;
        db.OATIConnectAppConfigs.Add(new OATIConnectAppConfig
        {
            Id           = Guid.NewGuid(),
            Key          = key,
            Value        = value,
            Description  = desc,
            Category     = cat,
            CreatedAtUtc = DateTime.UtcNow,
        });
    }
    Seed("Jitsi:ServerBaseUrl", "qa.meet.oati.com", "Jitsi server base URL", "Jitsi");
    Seed("App:Name",            "OATIConnect",      "Display name of the application", "Branding");
    Seed("App:HostName",        "OATIHub",          "Display name of the surrounding host portal", "Branding");
    Seed("App:ShowClock",       "true",             "Show the live clock in the top header", "Header");
    Seed("App:ShowThemeToggle", "true",             "Show the dark/light theme toggle", "Header");
    Seed("App:DefaultTheme",    "system",           "Initial theme: light, dark, or system", "Header");
    db.SaveChanges();
}

// 7. PathBase for IIS virtual-app deployment (e.g. https://host/oaticonnect/).
var appBasePath = builder.Configuration["App:BasePath"];
if (!string.IsNullOrWhiteSpace(appBasePath))
    app.UsePathBase(appBasePath);

app.UseRouting();
app.UseCors("ui");
app.UseAuthentication();
app.UseAuthorization();
// Copy ClaimsPrincipal into the scoped CurrentUserContext before any
// downstream handler runs. Must sit AFTER UseAuthentication so the
// principal is fully hydrated, and BEFORE MapControllers so MVC's
// resolved controllers see the populated holder.
app.UseMiddleware<CurrentUserMiddleware>();
app.UseDefaultFiles();
// .mjs (ES module) isn't in Kestrel's default MIME map — without
// this, /meet/oaticonnect-meet.mjs returns 404 and the embedded
// dashboard renders as a blank screen (the dark top bar shows but
// the web component never mounts). Inject the extension into the
// provider (which is pre-seeded with the standard MIME map) before
// handing it to UseStaticFiles.
var mimeProvider = new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider();
mimeProvider.Mappings[".mjs"] = "text/javascript";
app.UseStaticFiles(new Microsoft.AspNetCore.Builder.StaticFileOptions
{
    ContentTypeProvider = mimeProvider,
});
app.MapControllers();
app.MapOATIConnect();   // /oaticonnect/* aliases + AppConfigs seed
app.MapHealthChecks("/health");

// Landing page — gate on auth, otherwise redirect to /login. When the
// sidecar has Enabled=false the embed is suppressed and a notice replaces it.
app.MapGet("/", async (HttpContext ctx, IOATIConnectExternalAPI api, OATIConnect.Server.OATIConnectSettings sidecar) =>
{
    if (!(ctx.User.Identity?.IsAuthenticated ?? false))
        return Results.Redirect("/login");
    var user = await api.GetCurrentUserAsync();
    if (user == null) return Results.Redirect("/login");

    var topBar = $@"<div style=""background:#1e293b;color:#fff;padding:12px 24px;display:flex;justify-content:space-between;align-items:center"">
    <h1 style=""font-size:18px;margin:0"">OATIConnect.Client demo</h1>
    <div>Signed in as <strong>{user.Name}</strong> ({user.Role}, {user.TimeZoneIana})
      <a href=""/api/host/logout"" style=""color:#93c5fd;margin-left:16px"">Sign out</a></div>
  </div>";

    if (!sidecar.Enabled)
    {
        return Results.Content($@"<!DOCTYPE html>
<html><head><meta charset=""utf-8""><title>OATIConnect demo</title></head>
<body style=""font-family:Segoe UI,sans-serif;margin:0;background:#f9fafb"">
  {topBar}
  <div style=""max-width:600px;margin:64px auto;padding:32px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;text-align:center"">
    <div style=""font-size:48px;margin-bottom:12px"">⏸</div>
    <h2 style=""color:#374151;margin:0 0 8px"">OATIConnect is disabled</h2>
    <p style=""color:#6b7280;font-size:14px;line-height:1.5"">
      <code>oaticonnect_config.json</code> has <code>OATIConnect.Enabled = false</code>.
      All OATIConnect controllers are excluded from MVC and the React embed is suppressed.
      Set <code>Enabled = true</code> and restart the app to bring it back online.
    </p>
  </div>
</body></html>", "text/html");
    }

    return Results.Content($@"<!DOCTYPE html>
<html><head><meta charset=""utf-8""><title>OATIConnect demo</title></head>
<body style=""font-family:Segoe UI,sans-serif;margin:0"">
  {topBar}
  <oaticonnect-meet
    api-base=""/api/v1""
    user-id=""{user.Id}""
    user-name=""{user.Name}""
    user-email=""{user.Email}""
    user-role=""{user.Role}""
    theme=""light""
    auth-enabled=""false"">
  </oaticonnect-meet>
  <script type=""module"" src=""/meet/oaticonnect-meet.mjs""></script>
</body></html>", "text/html");
});

app.Run();

public partial class Program { }
