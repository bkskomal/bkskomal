#!/usr/bin/env node
/*
 * Spawns electron from node_modules/.bin with ELECTRON_RUN_AS_NODE
 * removed from the environment. Some setups (VSCode, certain dev
 * tools) export ELECTRON_RUN_AS_NODE=1 globally — when present,
 * Electron skips its main-process bootstrap and runs as pure Node,
 * which makes require("electron") return the binary path string
 * instead of the API namespace. Our main.ts then crashes on the
 * first ipcMain.handle call ("Cannot read properties of undefined").
 *
 * Args after the script path are forwarded as electron's argv.
 * Mode/debug env vars (OATICONNECT_MODE, OATICONNECT_DEBUG) are
 * passed through whatever the caller (npm script) set them to.
 */
const { spawn } = require("child_process");
const path      = require("path");

const env = { ...process.env };
delete env.ELECTRON_RUN_AS_NODE;

const electronCmd = path.join(
    __dirname, "..", "node_modules", ".bin",
    process.platform === "win32" ? "electron.cmd" : "electron"
);

const args = process.argv.slice(2);
const child = spawn(electronCmd, args.length ? args : ["."], {
    stdio: "inherit",
    env,
    shell: process.platform === "win32", // .cmd needs cmd.exe to invoke
});

child.on("close", (code) => process.exit(code ?? 0));
