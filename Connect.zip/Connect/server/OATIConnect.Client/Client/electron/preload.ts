import { contextBridge, ipcRenderer } from "electron";

// Outlook IPC — used by the dashboard (full) build to open .ics files /
// the Outlook protocol from the renderer.
contextBridge.exposeInMainWorld("electronAPI", {
    openOutlookEvent: (payload: any) => {
        console.log("PRELOAD → sending IPC", payload);
        return ipcRenderer.invoke("open-outlook-event", payload);
    },
    openOutlook: () => ipcRenderer.invoke("open-outlook-app"),
});

/**
 * Launcher chrome bridge — exposed to home.html and settings.html. All
 * server access is proxied through main so the renderer can stay on
 * file:// without hitting CORS (Electron's net.request ignores it).
 */
contextBridge.exposeInMainWorld("oaticonnect", {
    // Server URL config (persisted in userData/oaticonnect-client.json)
    saveServerUrl: (url: string) => ipcRenderer.invoke("oaticonnect:save-server-url", url),
    getServerUrl:  ()             => ipcRenderer.invoke("oaticonnect:get-server-url"),

    // Reachability probe — main calls GET ${url}/health and returns { ok }.
    probeHealth:   (url: string)  => ipcRenderer.invoke("oaticonnect:probe-health", url),

    // Join-by-code — main POSTs to ${serverUrl}/api/v1/meetings/join-by-code
    // with the renderer-supplied body. Returns the JSON the server sent.
    joinByCode:    (body: { meetingCode: string; displayName: string; password: string | null }) =>
        ipcRenderer.invoke("oaticonnect:join-by-code", body),

    // Lightweight prefs (last name + recent meeting ids) stored next to
    // the server URL. savePrefs accepts a partial; only the keys it
    // contains are updated. addRecentMeetingId pushes onto a capped list.
    getPrefs:      ()                                                                => ipcRenderer.invoke("oaticonnect:get-prefs"),
    savePrefs:     (patch: { lastName?: string; addRecentMeetingId?: string })       => ipcRenderer.invoke("oaticonnect:save-prefs", patch),

    // Rail navigation — renderer asks main to load the other local page.
    navigateHome:     () => ipcRenderer.invoke("oaticonnect:navigate", "home"),
    navigateSettings: () => ipcRenderer.invoke("oaticonnect:navigate", "settings"),

    // Window state — maximize while a meeting is active, restore on leave.
    meetingStarted: () => ipcRenderer.invoke("oaticonnect:meeting-started"),
    meetingEnded:   () => ipcRenderer.invoke("oaticonnect:meeting-ended"),

    // Renderer asks main to size the window's content area to match its
    // current scrollHeight. Called by home.html / settings.html after
    // load so the launcher chrome has no empty space below the form.
    fitWindowToContent: (height: number) =>
        ipcRenderer.invoke("oaticonnect:fit-window", height),
});
