import { app, BrowserWindow, ipcMain, shell, net, Menu, session } from "electron";
import path from "path";
import fs from "fs";
import os from "os";

let mainWindow: BrowserWindow | null = null;

// =============================================================================
// User-data persistence (server URL + lightweight prefs)
// =============================================================================

interface UserConfig {
    serverUrl?: string;
    lastName?: string;
    recentMeetingIds?: string[];
    /** Launcher chrome theme — "light" (default) or "dark". Persists
     *  across launches. Toggled by the sun/moon button in the top-right
     *  corner of home.html / settings.html. */
    theme?: "light" | "dark";
}

const RECENT_LIMIT = 5;

function userConfigPath(): string {
    return path.join(app.getPath("userData"), "oaticonnect-client.json");
}

function readUserConfig(): UserConfig {
    try {
        const p = userConfigPath();
        if (!fs.existsSync(p)) return {};
        const j = JSON.parse(fs.readFileSync(p, "utf-8"));
        return (j && typeof j === "object") ? j as UserConfig : {};
    } catch { return {}; }
}

function writeUserConfig(cfg: UserConfig): void {
    const dir = app.getPath("userData");
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(userConfigPath(), JSON.stringify(cfg, null, 2), "utf-8");
}

function readSavedServerUrl(): string | null {
    const cfg = readUserConfig();
    const v = (cfg.serverUrl || "").trim();
    return v || null;
}

function writeSavedServerUrl(url: string): void {
    const cfg = readUserConfig();
    cfg.serverUrl = url;
    writeUserConfig(cfg);
}

// =============================================================================
// Build-mode + server URL resolution
// =============================================================================
//
//  full     — wraps the entire OATIConnect dashboard; loads server root.
//  minimal  — Zoom-style join client; loads a LOCAL home.html with a
//             compact form + camera preview. Only the meeting itself
//             (Jitsi external_api embed) talks to the remote server.

type AppMode = "full" | "minimal";

function resolveMode(): AppMode {
    if (process.env.OATICONNECT_MODE === "minimal") return "minimal";
    if (process.env.OATICONNECT_MODE === "full")    return "full";
    try {
        const pkgPath = path.join(__dirname, "..", "package.json");
        if (fs.existsSync(pkgPath)) {
            const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
            if (pkg.oaticonnectMode === "minimal") return "minimal";
        }
    } catch { /* fall through */ }
    return "full";
}
const APP_MODE: AppMode = resolveMode();

function getServerUrl(): string | null {
    if (process.env.OATICONNECT_SERVER_URL) return process.env.OATICONNECT_SERVER_URL.replace(/\/+$/, "");

    const saved = readSavedServerUrl();
    if (saved) return saved.replace(/\/+$/, "");

    try {
        const sideCfg = path.join(path.dirname(app.getPath("exe")), "oaticonnect-client.json");
        if (fs.existsSync(sideCfg)) {
            const j = JSON.parse(fs.readFileSync(sideCfg, "utf-8"));
            if (j.serverUrl) return String(j.serverUrl).replace(/\/+$/, "");
        }
    } catch { /* fall through */ }

    try {
        const devCfg = path.join(__dirname, "../../server/OATIConnect.API/appsettings.json");
        if (fs.existsSync(devCfg)) {
            const config = JSON.parse(fs.readFileSync(devCfg, "utf-8"));
            if (config.webAppUrl) return String(config.webAppUrl).replace(/\/+$/, "");
        }
    } catch { /* fall through */ }

    // Minimal client ships pointing at qa so first-launch users land on
    // the join form directly. They can repoint via the Settings page.
    if (APP_MODE === "minimal") return "https://qa.meet.oati.com";

    return null;
}

// =============================================================================
// Local file URLs for the launcher chrome (minimal client only)
// =============================================================================

function localFileUrl(name: string): string {
    const candidates = [
        path.join(__dirname, name),
        path.join(__dirname, "..", "electron", name),
    ];
    for (const c of candidates) {
        if (fs.existsSync(c)) return "file://" + c.replace(/\\/g, "/");
    }
    return "file://" + candidates[0].replace(/\\/g, "/");
}

function homePageFileUrl():     string { return localFileUrl("home.html"); }
function settingsPageFileUrl(): string { return localFileUrl("settings.html"); }

// =============================================================================
// Server fetches (proxied from renderer via IPC to skip file:// CORS)
// =============================================================================

function httpJson(url: string, options: { method?: string; body?: any } = {}): Promise<any> {
    return new Promise((resolve, reject) => {
        try {
            const req = net.request({ method: options.method || "GET", url });
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Accept", "application/json");
            let body = "";
            req.on("response", (response: any) => {
                console.log(`[http] ${options.method || "GET"} ${url} → ${response.statusCode}`);
                response.on("data", (chunk: Buffer) => { body += chunk.toString(); });
                response.on("end", () => {
                    try { resolve(body ? JSON.parse(body) : null); }
                    catch (e) {
                        console.error(`[http] non-JSON response (status=${response.statusCode}):`, body.slice(0, 500));
                        resolve({ ok: false, error: `Server returned ${response.statusCode}. ${body.slice(0, 200)}` });
                    }
                });
                response.on("error", (err: any) => reject(err));
            });
            req.on("error", (err: any) => reject(err));
            if (options.body) req.write(JSON.stringify(options.body));
            req.end();
        } catch (e) { reject(e); }
    });
}

function fetchAppName(webAppUrl: string): Promise<string> {
    return httpJson(new URL("/api/v1/config", webAppUrl).toString())
        .then(cfg => (cfg && cfg.appName) || "OATIConnect")
        .catch(() => "OATIConnect");
}

// =============================================================================
// Window lifecycle
// =============================================================================

async function createWindow() {
    const serverUrl = getServerUrl();
    const baseName  = serverUrl ? await fetchAppName(serverUrl) : "OATIConnect";
    app.setName(baseName);

    const dim = APP_MODE === "minimal"
        ? { width: 720, height: 760 }
        : { width: 1400, height: 900 };

    mainWindow = new BrowserWindow({
        width:  dim.width,
        height: dim.height,
        title:  baseName,
        webPreferences: {
            preload: path.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false,
        }
    });

    mainWindow.on("page-title-updated", (e) => e.preventDefault());

    // Auto-grant camera/mic for the launcher pages so the local home
    // preview works without showing the Chromium permission dialog.
    session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => {
        if (permission === "media" || permission === "mediaKeySystem") return cb(true);
        cb(true);
    });

    if (APP_MODE === "minimal") {
        // Always start at the local launcher. home.html / settings.html
        // decide what to show based on whether a server URL is saved.
        if (serverUrl) {
            mainWindow.loadURL(homePageFileUrl());
        } else {
            mainWindow.loadURL(settingsPageFileUrl());
        }
    } else {
        // Full client behaviour is unchanged: load the server root or
        // the first-launch setup screen.
        if (!serverUrl) {
            mainWindow.loadURL(settingsPageFileUrl());
        } else {
            mainWindow.loadURL(serverUrl);
        }
    }

    // DevTools — open automatically when OATICONNECT_DEBUG=1 or when the
    // server URL is localhost. Otherwise Ctrl+Shift+I (viewMenu role)
    // still toggles them on demand. "detach" so the small launcher
    // window isn't squished by the DevTools panel.
    const debugMode = process.env.OATICONNECT_DEBUG === "1"
        || (serverUrl ? serverUrl.includes("localhost") : false);
    if (debugMode) {
        mainWindow.webContents.openDevTools({ mode: "detach" });
    }
    console.log(`[${APP_MODE}] serverUrl =`, serverUrl, "| debug =", debugMode);

    buildAppMenu();
}

function buildAppMenu() {
    const template: Electron.MenuItemConstructorOptions[] = [
        {
            label: "File",
            submenu: [
                {
                    label: "Change server URL…",
                    click: () => {
                        // Don't wipe the saved URL — just open Settings.
                        // User edits the value and clicks Save.
                        if (mainWindow) mainWindow.loadURL(settingsPageFileUrl());
                    },
                },
                { type: "separator" },
                { role: "quit" },
            ],
        },
        { role: "editMenu" },
        { role: "viewMenu" },
        { role: "windowMenu" },
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// =============================================================================
// IPC — server URL + prefs + server proxies + nav
// =============================================================================

ipcMain.handle("oaticonnect:save-server-url", async (_evt, url: string) => {
    if (typeof url !== "string" || !url.trim()) return { ok: false, error: "Empty URL" };
    const cleaned = url.trim().replace(/\/+$/, "");
    try { writeSavedServerUrl(cleaned); }
    catch (err: any) { return { ok: false, error: err.message ?? "Failed to save" }; }
    return { ok: true };
});

ipcMain.handle("oaticonnect:get-server-url", () => readSavedServerUrl());

// Health probe — used by Settings to validate the URL before saving.
ipcMain.handle("oaticonnect:probe-health", async (_evt, url: string) => {
    try {
        const cleaned = String(url || "").trim().replace(/\/+$/, "");
        if (!cleaned) return { ok: false };
        await httpJson(cleaned + "/health");
        return { ok: true };
    } catch { return { ok: false }; }
});

// Join-by-code — POSTs to the configured server, returns the JSON.
ipcMain.handle("oaticonnect:join-by-code", async (_evt, body: any) => {
    const serverUrl = getServerUrl();
    if (!serverUrl) return { ok: false, error: "No server URL configured. Open Settings and add one." };
    const url = serverUrl + "/api/v1/meetings/join-by-code";
    console.log("[join-by-code] POST", url, "body=", JSON.stringify(body));
    try {
        const res = await httpJson(url, { method: "POST", body });
        console.log("[join-by-code] response=", JSON.stringify(res));
        return res;
    } catch (e: any) {
        console.error("[join-by-code] error=", e);
        return { ok: false, error: e?.message || "Could not reach server." };
    }
});

ipcMain.handle("oaticonnect:get-prefs", () => {
    const cfg = readUserConfig();
    return {
        lastName: cfg.lastName || "",
        recentMeetingIds: Array.isArray(cfg.recentMeetingIds) ? cfg.recentMeetingIds : [],
        theme: cfg.theme === "dark" ? "dark" : "light",
    };
});

ipcMain.handle("oaticonnect:save-prefs", (_evt, patch: { lastName?: string; theme?: "light" | "dark"; addRecentMeetingId?: string }) => {
    const cfg = readUserConfig();
    if (patch && typeof patch.lastName === "string") cfg.lastName = patch.lastName;
    if (patch && (patch.theme === "light" || patch.theme === "dark")) cfg.theme = patch.theme;
    if (patch && typeof patch.addRecentMeetingId === "string" && patch.addRecentMeetingId.trim()) {
        const id = patch.addRecentMeetingId.trim();
        const list = (cfg.recentMeetingIds || []).filter(x => x !== id);
        list.unshift(id);
        cfg.recentMeetingIds = list.slice(0, RECENT_LIMIT);
    }
    try { writeUserConfig(cfg); return { ok: true }; }
    catch (err: any) { return { ok: false, error: err?.message }; }
});

ipcMain.handle("oaticonnect:navigate", (_evt, target: "home" | "settings") => {
    if (!mainWindow) return { ok: false };
    if (target === "settings") mainWindow.loadURL(settingsPageFileUrl());
    else                       mainWindow.loadURL(homePageFileUrl());
    return { ok: true };
});

// Window sizing — give the meeting iframe maximum real estate while
// it's active, then drop back to launcher size when the user leaves.
ipcMain.handle("oaticonnect:meeting-started", () => {
    if (!mainWindow) return { ok: false };
    mainWindow.maximize();
    return { ok: true };
});

ipcMain.handle("oaticonnect:meeting-ended", () => {
    if (!mainWindow) return { ok: false };
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    // Snap back to launcher dimensions explicitly — unmaximize alone
    // restores the pre-maximize bounds, which is usually launcher-size
    // already, but be defensive in case the user dragged the window
    // larger before joining.
    mainWindow.setSize(720, 760);
    mainWindow.center();
    return { ok: true };
});

// Renderer-driven window sizing. home.html and settings.html measure
// their content's scrollHeight on load and call here so the launcher
// has no empty space below the form. Width is fixed; only height is
// resized. Clamped to a sensible range so a missing/bad measurement
// can't shrink the window to nothing or balloon off-screen.
ipcMain.handle("oaticonnect:fit-window", (_evt, height: number) => {
    if (!mainWindow) return { ok: false };
    if (mainWindow.isMaximized()) return { ok: false }; // don't fight maximize while in a meeting
    const h = Math.max(360, Math.min(Math.round(height) || 0, 1100));
    mainWindow.setContentSize(720, h);
    return { ok: true };
});

app.whenReady().then(createWindow);

// =============================================================================
// Outlook IPC — used by the full client renderer.
// =============================================================================

ipcMain.handle("open-outlook-event", async (_, meeting) => {
    try {
        const base64 = meeting.file.content;
        const icsContent = Buffer.from(base64, "base64").toString("utf-8");
        const filePath = path.join(os.tmpdir(), meeting.file.fileName || `meet-${Date.now()}.ics`);
        fs.writeFileSync(filePath, icsContent, "utf-8");
        const result = await shell.openPath(filePath);
        console.log("shell.openPath result:", result);
        return { success: true };
    } catch (err: any) {
        console.error("Outlook open failed:", err);
        return { success: false, error: err.message };
    }
});

ipcMain.handle("open-outlook-app", () => {
    shell.openExternal("outlook:");
});
