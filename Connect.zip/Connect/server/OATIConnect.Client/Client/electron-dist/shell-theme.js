/*
 * Launcher theme bootstrap — shared by home.html and settings.html.
 *
 * On load: reads the persisted theme from prefs (userData JSON via
 * the preload bridge) and applies it to <html data-theme="...">.
 * Light is the default when nothing's saved.
 *
 * Wires a click handler on .theme-toggle (must exist in the page DOM)
 * that flips the attribute AND persists the new value, so opening
 * any other page sees the same setting.
 */
(function () {
    function applyTheme(t) {
        if (t === "dark") document.documentElement.setAttribute("data-theme", "dark");
        else              document.documentElement.removeAttribute("data-theme");
    }

    async function init() {
        // Pull the current preference. Best-effort — if the bridge
        // isn't available (e.g. someone opens the .html directly in a
        // browser), default to light.
        var saved = "light";
        try {
            var prefs = await window.oaticonnect.getPrefs();
            if (prefs && prefs.theme === "dark") saved = "dark";
        } catch (e) { /* leave light */ }
        applyTheme(saved);

        var btn = document.querySelector(".theme-toggle");
        if (!btn) return;
        btn.addEventListener("click", function () {
            var next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
            applyTheme(next);
            try { window.oaticonnect.savePrefs({ theme: next }); } catch (e) {}
        });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else                                    init();
})();
