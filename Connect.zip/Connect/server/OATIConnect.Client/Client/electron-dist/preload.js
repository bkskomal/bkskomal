"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
// Outlook IPC — used by the dashboard (full) build to open .ics files /
// the Outlook protocol from the renderer.
electron_1.contextBridge.exposeInMainWorld("electronAPI", {
    openOutlookEvent: (payload) => {
        console.log("PRELOAD → sending IPC", payload);
        return electron_1.ipcRenderer.invoke("open-outlook-event", payload);
    },
    openOutlook: () => electron_1.ipcRenderer.invoke("open-outlook-app"),
});
/**
 * Launcher chrome bridge — exposed to home.html and settings.html. All
 * server access is proxied through main so the renderer can stay on
 * file:// without hitting CORS (Electron's net.request ignores it).
 */
electron_1.contextBridge.exposeInMainWorld("oaticonnect", {
    // Server URL config (persisted in userData/oaticonnect-client.json)
    saveServerUrl: (url) => electron_1.ipcRenderer.invoke("oaticonnect:save-server-url", url),
    getServerUrl: () => electron_1.ipcRenderer.invoke("oaticonnect:get-server-url"),
    // Reachability probe — main calls GET ${url}/health and returns { ok }.
    probeHealth: (url) => electron_1.ipcRenderer.invoke("oaticonnect:probe-health", url),
    // Join-by-code — main POSTs to ${serverUrl}/api/v1/meetings/join-by-code
    // with the renderer-supplied body. Returns the JSON the server sent.
    joinByCode: (body) => electron_1.ipcRenderer.invoke("oaticonnect:join-by-code", body),
    // Lightweight prefs (last name + recent meeting ids) stored next to
    // the server URL. savePrefs accepts a partial; only the keys it
    // contains are updated. addRecentMeetingId pushes onto a capped list.
    getPrefs: () => electron_1.ipcRenderer.invoke("oaticonnect:get-prefs"),
    savePrefs: (patch) => electron_1.ipcRenderer.invoke("oaticonnect:save-prefs", patch),
    // Rail navigation — renderer asks main to load the other local page.
    navigateHome: () => electron_1.ipcRenderer.invoke("oaticonnect:navigate", "home"),
    navigateSettings: () => electron_1.ipcRenderer.invoke("oaticonnect:navigate", "settings"),
    // Window state — maximize while a meeting is active, restore on leave.
    meetingStarted: () => electron_1.ipcRenderer.invoke("oaticonnect:meeting-started"),
    meetingEnded: () => electron_1.ipcRenderer.invoke("oaticonnect:meeting-ended"),
    // Renderer asks main to size the window's content area to match its
    // current scrollHeight. Called by home.html / settings.html after
    // load so the launcher chrome has no empty space below the form.
    fitWindowToContent: (height) => electron_1.ipcRenderer.invoke("oaticonnect:fit-window", height),
});
