"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const os_1 = __importDefault(require("os"));
let mainWindow = null;
const RECENT_LIMIT = 5;
function userConfigPath() {
    return path_1.default.join(electron_1.app.getPath("userData"), "oaticonnect-client.json");
}
function readUserConfig() {
    try {
        const p = userConfigPath();
        if (!fs_1.default.existsSync(p))
            return {};
        const j = JSON.parse(fs_1.default.readFileSync(p, "utf-8"));
        return (j && typeof j === "object") ? j : {};
    }
    catch {
        return {};
    }
}
function writeUserConfig(cfg) {
    const dir = electron_1.app.getPath("userData");
    fs_1.default.mkdirSync(dir, { recursive: true });
    fs_1.default.writeFileSync(userConfigPath(), JSON.stringify(cfg, null, 2), "utf-8");
}
function readSavedServerUrl() {
    const cfg = readUserConfig();
    const v = (cfg.serverUrl || "").trim();
    return v || null;
}
function writeSavedServerUrl(url) {
    const cfg = readUserConfig();
    cfg.serverUrl = url;
    writeUserConfig(cfg);
}
function resolveMode() {
    if (process.env.OATICONNECT_MODE === "minimal")
        return "minimal";
    if (process.env.OATICONNECT_MODE === "full")
        return "full";
    try {
        const pkgPath = path_1.default.join(__dirname, "..", "package.json");
        if (fs_1.default.existsSync(pkgPath)) {
            const pkg = JSON.parse(fs_1.default.readFileSync(pkgPath, "utf-8"));
            if (pkg.oaticonnectMode === "minimal")
                return "minimal";
        }
    }
    catch { /* fall through */ }
    return "full";
}
const APP_MODE = resolveMode();
function getServerUrl() {
    if (process.env.OATICONNECT_SERVER_URL)
        return process.env.OATICONNECT_SERVER_URL.replace(/\/+$/, "");
    const saved = readSavedServerUrl();
    if (saved)
        return saved.replace(/\/+$/, "");
    try {
        const sideCfg = path_1.default.join(path_1.default.dirname(electron_1.app.getPath("exe")), "oaticonnect-client.json");
        if (fs_1.default.existsSync(sideCfg)) {
            const j = JSON.parse(fs_1.default.readFileSync(sideCfg, "utf-8"));
            if (j.serverUrl)
                return String(j.serverUrl).replace(/\/+$/, "");
        }
    }
    catch { /* fall through */ }
    try {
        const devCfg = path_1.default.join(__dirname, "../../server/OATIConnect.API/appsettings.json");
        if (fs_1.default.existsSync(devCfg)) {
            const config = JSON.parse(fs_1.default.readFileSync(devCfg, "utf-8"));
            if (config.webAppUrl)
                return String(config.webAppUrl).replace(/\/+$/, "");
        }
    }
    catch { /* fall through */ }
    // Minimal client ships pointing at qa so first-launch users land on
    // the join form directly. They can repoint via the Settings page.
    if (APP_MODE === "minimal")
        return "https://qa.meet.oati.com";
    return null;
}
// =============================================================================
// Local file URLs for the launcher chrome (minimal client only)
// =============================================================================
function localFileUrl(name) {
    const candidates = [
        path_1.default.join(__dirname, name),
        path_1.default.join(__dirname, "..", "electron", name),
    ];
    for (const c of candidates) {
        if (fs_1.default.existsSync(c))
            return "file://" + c.replace(/\\/g, "/");
    }
    return "file://" + candidates[0].replace(/\\/g, "/");
}
function homePageFileUrl() { return localFileUrl("home.html"); }
function settingsPageFileUrl() { return localFileUrl("settings.html"); }
// =============================================================================
// Server fetches (proxied from renderer via IPC to skip file:// CORS)
// =============================================================================
function httpJson(url, options = {}) {
    return new Promise((resolve, reject) => {
        try {
            const req = electron_1.net.request({ method: options.method || "GET", url });
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Accept", "application/json");
            let body = "";
            req.on("response", (response) => {
                console.log(`[http] ${options.method || "GET"} ${url} → ${response.statusCode}`);
                response.on("data", (chunk) => { body += chunk.toString(); });
                response.on("end", () => {
                    try {
                        resolve(body ? JSON.parse(body) : null);
                    }
                    catch (e) {
                        console.error(`[http] non-JSON response (status=${response.statusCode}):`, body.slice(0, 500));
                        resolve({ ok: false, error: `Server returned ${response.statusCode}. ${body.slice(0, 200)}` });
                    }
                });
                response.on("error", (err) => reject(err));
            });
            req.on("error", (err) => reject(err));
            if (options.body)
                req.write(JSON.stringify(options.body));
            req.end();
        }
        catch (e) {
            reject(e);
        }
    });
}
function fetchAppName(webAppUrl) {
    return httpJson(new URL("/api/v1/config", webAppUrl).toString())
        .then(cfg => (cfg && cfg.appName) || "OATIConnect")
        .catch(() => "OATIConnect");
}
// =============================================================================
// Window lifecycle
// =============================================================================
async function createWindow() {
    const serverUrl = getServerUrl();
    const baseName = serverUrl ? await fetchAppName(serverUrl) : "OATIConnect";
    electron_1.app.setName(baseName);
    const dim = APP_MODE === "minimal"
        ? { width: 720, height: 760 }
        : { width: 1400, height: 900 };
    mainWindow = new electron_1.BrowserWindow({
        width: dim.width,
        height: dim.height,
        title: baseName,
        webPreferences: {
            preload: path_1.default.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false,
        }
    });
    mainWindow.on("page-title-updated", (e) => e.preventDefault());
    // Auto-grant camera/mic for the launcher pages so the local home
    // preview works without showing the Chromium permission dialog.
    electron_1.session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => {
        if (permission === "media" || permission === "mediaKeySystem")
            return cb(true);
        cb(true);
    });
    if (APP_MODE === "minimal") {
        // Always start at the local launcher. home.html / settings.html
        // decide what to show based on whether a server URL is saved.
        if (serverUrl) {
            mainWindow.loadURL(homePageFileUrl());
        }
        else {
            mainWindow.loadURL(settingsPageFileUrl());
        }
    }
    else {
        // Full client behaviour is unchanged: load the server root or
        // the first-launch setup screen.
        if (!serverUrl) {
            mainWindow.loadURL(settingsPageFileUrl());
        }
        else {
            mainWindow.loadURL(serverUrl);
        }
    }
    // DevTools — open automatically when OATICONNECT_DEBUG=1 or when the
    // server URL is localhost. Otherwise Ctrl+Shift+I (viewMenu role)
    // still toggles them on demand. "detach" so the small launcher
    // window isn't squished by the DevTools panel.
    const debugMode = process.env.OATICONNECT_DEBUG === "1"
        || (serverUrl ? serverUrl.includes("localhost") : false);
    if (debugMode) {
        mainWindow.webContents.openDevTools({ mode: "detach" });
    }
    console.log(`[${APP_MODE}] serverUrl =`, serverUrl, "| debug =", debugMode);
    buildAppMenu();
}
function buildAppMenu() {
    const template = [
        {
            label: "File",
            submenu: [
                {
                    label: "Change server URL…",
                    click: () => {
                        // Don't wipe the saved URL — just open Settings.
                        // User edits the value and clicks Save.
                        if (mainWindow)
                            mainWindow.loadURL(settingsPageFileUrl());
                    },
                },
                { type: "separator" },
                { role: "quit" },
            ],
        },
        { role: "editMenu" },
        { role: "viewMenu" },
        { role: "windowMenu" },
    ];
    electron_1.Menu.setApplicationMenu(electron_1.Menu.buildFromTemplate(template));
}
// =============================================================================
// IPC — server URL + prefs + server proxies + nav
// =============================================================================
electron_1.ipcMain.handle("oaticonnect:save-server-url", async (_evt, url) => {
    if (typeof url !== "string" || !url.trim())
        return { ok: false, error: "Empty URL" };
    const cleaned = url.trim().replace(/\/+$/, "");
    try {
        writeSavedServerUrl(cleaned);
    }
    catch (err) {
        return { ok: false, error: err.message ?? "Failed to save" };
    }
    return { ok: true };
});
electron_1.ipcMain.handle("oaticonnect:get-server-url", () => readSavedServerUrl());
// Health probe — used by Settings to validate the URL before saving.
electron_1.ipcMain.handle("oaticonnect:probe-health", async (_evt, url) => {
    try {
        const cleaned = String(url || "").trim().replace(/\/+$/, "");
        if (!cleaned)
            return { ok: false };
        await httpJson(cleaned + "/health");
        return { ok: true };
    }
    catch {
        return { ok: false };
    }
});
// Join-by-code — POSTs to the configured server, returns the JSON.
electron_1.ipcMain.handle("oaticonnect:join-by-code", async (_evt, body) => {
    const serverUrl = getServerUrl();
    if (!serverUrl)
        return { ok: false, error: "No server URL configured. Open Settings and add one." };
    const url = serverUrl + "/api/v1/meetings/join-by-code";
    console.log("[join-by-code] POST", url, "body=", JSON.stringify(body));
    try {
        const res = await httpJson(url, { method: "POST", body });
        console.log("[join-by-code] response=", JSON.stringify(res));
        return res;
    }
    catch (e) {
        console.error("[join-by-code] error=", e);
        return { ok: false, error: e?.message || "Could not reach server." };
    }
});
electron_1.ipcMain.handle("oaticonnect:get-prefs", () => {
    const cfg = readUserConfig();
    return {
        lastName: cfg.lastName || "",
        recentMeetingIds: Array.isArray(cfg.recentMeetingIds) ? cfg.recentMeetingIds : [],
        theme: cfg.theme === "dark" ? "dark" : "light",
    };
});
electron_1.ipcMain.handle("oaticonnect:save-prefs", (_evt, patch) => {
    const cfg = readUserConfig();
    if (patch && typeof patch.lastName === "string")
        cfg.lastName = patch.lastName;
    if (patch && (patch.theme === "light" || patch.theme === "dark"))
        cfg.theme = patch.theme;
    if (patch && typeof patch.addRecentMeetingId === "string" && patch.addRecentMeetingId.trim()) {
        const id = patch.addRecentMeetingId.trim();
        const list = (cfg.recentMeetingIds || []).filter(x => x !== id);
        list.unshift(id);
        cfg.recentMeetingIds = list.slice(0, RECENT_LIMIT);
    }
    try {
        writeUserConfig(cfg);
        return { ok: true };
    }
    catch (err) {
        return { ok: false, error: err?.message };
    }
});
electron_1.ipcMain.handle("oaticonnect:navigate", (_evt, target) => {
    if (!mainWindow)
        return { ok: false };
    if (target === "settings")
        mainWindow.loadURL(settingsPageFileUrl());
    else
        mainWindow.loadURL(homePageFileUrl());
    return { ok: true };
});
// Window sizing — give the meeting iframe maximum real estate while
// it's active, then drop back to launcher size when the user leaves.
electron_1.ipcMain.handle("oaticonnect:meeting-started", () => {
    if (!mainWindow)
        return { ok: false };
    mainWindow.maximize();
    return { ok: true };
});
electron_1.ipcMain.handle("oaticonnect:meeting-ended", () => {
    if (!mainWindow)
        return { ok: false };
    if (mainWindow.isMaximized())
        mainWindow.unmaximize();
    // Snap back to launcher dimensions explicitly — unmaximize alone
    // restores the pre-maximize bounds, which is usually launcher-size
    // already, but be defensive in case the user dragged the window
    // larger before joining.
    mainWindow.setSize(720, 760);
    mainWindow.center();
    return { ok: true };
});
// Renderer-driven window sizing. home.html and settings.html measure
// their content's scrollHeight on load and call here so the launcher
// has no empty space below the form. Width is fixed; only height is
// resized. Clamped to a sensible range so a missing/bad measurement
// can't shrink the window to nothing or balloon off-screen.
electron_1.ipcMain.handle("oaticonnect:fit-window", (_evt, height) => {
    if (!mainWindow)
        return { ok: false };
    if (mainWindow.isMaximized())
        return { ok: false }; // don't fight maximize while in a meeting
    const h = Math.max(360, Math.min(Math.round(height) || 0, 1100));
    mainWindow.setContentSize(720, h);
    return { ok: true };
});
electron_1.app.whenReady().then(createWindow);
// =============================================================================
// Outlook IPC — used by the full client renderer.
// =============================================================================
electron_1.ipcMain.handle("open-outlook-event", async (_, meeting) => {
    try {
        const base64 = meeting.file.content;
        const icsContent = Buffer.from(base64, "base64").toString("utf-8");
        const filePath = path_1.default.join(os_1.default.tmpdir(), meeting.file.fileName || `meet-${Date.now()}.ics`);
        fs_1.default.writeFileSync(filePath, icsContent, "utf-8");
        const result = await electron_1.shell.openPath(filePath);
        console.log("shell.openPath result:", result);
        return { success: true };
    }
    catch (err) {
        console.error("Outlook open failed:", err);
        return { success: false, error: err.message };
    }
});
electron_1.ipcMain.handle("open-outlook-app", () => {
    electron_1.shell.openExternal("outlook:");
});
