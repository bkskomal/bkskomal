﻿import { useEffect, useState } from "react";
import { listParticipants, type Meeting, type Participant } from "../api/meetings.api";
import { useTzFormat } from "../utils/tzFormat";

type Props = {
  meeting: Meeting;
  onClose: () => void;
};

function initials(name: string): string {
  const parts = (name || "").trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

// Stable HSL hue per name so each user gets a consistent avatar color.
function avatarHue(seed: string): number {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return h % 360;
}

function timeAgo(iso: string): string {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return "";
  const sec = Math.max(0, Math.floor((Date.now() - t) / 1000));
  if (sec < 45)         return "just now";
  if (sec < 90)         return "1 min ago";
  if (sec < 3600)       return `${Math.round(sec / 60)} min ago`;
  if (sec < 5400)       return "1 hr ago";
  if (sec < 86400)      return `${Math.round(sec / 3600)} hr ago`;
  if (sec < 86400 * 2)  return "yesterday";
  if (sec < 86400 * 30) return `${Math.round(sec / 86400)} d ago`;
  return new Date(iso).toLocaleDateString();
}

/**
 * Host-only participant audit for a single meeting. Each join produces one
 * row; re-joins create new rows so the total reflects join *events*, not
 * unique users. The summary header counts both.
 */
export default function MeetingParticipants({ meeting, onClose }: Props) {
  const tz = useTzFormat();
  const [rows, setRows]       = useState<Participant[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    listParticipants(meeting.meetingId)
      .then(list => { if (!cancelled) setRows(list); })
      .catch(()   => { if (!cancelled) setError("Could not load participants."); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [meeting.meetingId]);

  // De-duplicate by userId for "who joined at all" + most-recent join.
  const uniqueUsers = Array.from(new Map(rows.map(r => [r.userId, r])).values());
  const lastJoin    = rows.length > 0
    ? rows.reduce((a, b) => new Date(a.joinedAtUtc) > new Date(b.joinedAtUtc) ? a : b)
    : null;

  return (
    <div className="participants-page">
      <button
        className="participants-back"
        onClick={onClose}
        type="button"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M19 12H5" />
          <path d="m12 19-7-7 7-7" />
        </svg>
        <span>Back to meetings</span>
      </button>

      <div className="participants-hero">
        <div className="participants-hero-main">
          <div className="participants-hero-eyebrow">Participants</div>
          <h1 className="participants-hero-title">{meeting.title}</h1>
          <div className="participants-hero-meta">
            <span>{tz.formatDateTimeLong(meeting.scheduledTimeUtc)}</span>
            <span className="participants-hero-dot">Â·</span>
            <span>{meeting.durationMinutes || 60} min</span>
          </div>
        </div>
        <div className="participants-stats">
          <div className="participants-stat">
            <div className="participants-stat-value">{rows.length}</div>
            <div className="participants-stat-label">Total joins</div>
          </div>
          <div className="participants-stat">
            <div className="participants-stat-value">{uniqueUsers.length}</div>
            <div className="participants-stat-label">Unique users</div>
          </div>
          <div className="participants-stat">
            <div className="participants-stat-value">{lastJoin ? timeAgo(lastJoin.joinedAtUtc) : "—"}</div>
            <div className="participants-stat-label">Last join</div>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="participants-state participants-state-loading">
          <div className="spinner" />
          <p>Loading participants…</p>
        </div>
      ) : error ? (
        <div className="participants-state participants-state-error">
          <div className="participants-state-icon" aria-hidden="true">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
              <line x1="12" y1="9" x2="12" y2="13" />
              <line x1="12" y1="17" x2="12.01" y2="17" />
            </svg>
          </div>
          <p>{error}</p>
        </div>
      ) : rows.length === 0 ? (
        <div className="participants-state">
          <div className="participants-state-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
          <p className="participants-state-title">No one has joined yet</p>
          <p className="participants-state-desc">Join events appear here as soon as anyone enters the meeting.</p>
        </div>
      ) : (
        <div className="participants-list">
          {rows
            .slice()
            .sort((a, b) => new Date(b.joinedAtUtc).getTime() - new Date(a.joinedAtUtc).getTime())
            .map(r => {
              const seed = r.email || r.name || String(r.userId);
              return (
                <div key={r.id} className="participant-row">
                  <div
                    className="participant-avatar"
                    style={{
                      background: `linear-gradient(135deg, hsl(${avatarHue(seed)}, 60%, 45%), hsl(${(avatarHue(seed) + 30) % 360}, 65%, 35%))`,
                    }}
                  >
                    {initials(r.name || r.email)}
                  </div>
                  <div className="participant-id">
                    <div className="participant-name">{r.name || "(no name)"}</div>
                    {/* Share-link guests have no email — drop the row entirely
                        instead of showing a placeholder; an empty line under the
                        name looked like a rendering bug. */}
                    {r.email && <div className="participant-email">{r.email}</div>}
                  </div>
                  <div className="participant-time">
                    <div className="participant-time-rel">{timeAgo(r.joinedAtUtc)}</div>
                    <div className="participant-time-abs">{tz.formatDateTimeLong(r.joinedAtUtc)}</div>
                  </div>
                </div>
              );
            })}
        </div>
      )}
    </div>
  );
}

