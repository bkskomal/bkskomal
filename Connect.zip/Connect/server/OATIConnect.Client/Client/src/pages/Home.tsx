﻿import { useEffect, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ActionButton from "../components/ActionButton";
import ScheduleMeetingModal from "../components/ScheduleMeetingModal";
import NewMeetingPreviewModal from "../components/NewMeetingPreviewModal";
import { listMeetings, deleteMeeting, getMeetingShareLink, cancelOccurrence, type Meeting } from "../api/meetings.api";
import { openMeetingWindow } from "../utils/meetingWindow";
import { loadJitsiScript } from "../utils/loadJitsi";
import { useOptionalMeetConfig } from "../contexts/MeetConfigContext";
import { useOptionalUser } from "../contexts/UserContext";
import { useToast } from "../components/Toast";
import { getBasePath } from "../config/basePath";
import { getAppName } from "../config/env";
import { useTzFormat, formatInTz } from "../utils/tzFormat";

import "./Home.css";

type Props = {
  /** Called when the user picks "View Participants" from a row's menu.
   *  The dashboard swaps Home for the participants page. */
  onViewParticipants?: (meeting: Meeting) => void;
};

const PAGE_SIZE = 10;

type RowState = "ongoing" | "upcoming" | "past";
function getRowState(timeUtc: string, durationMinutes: number): RowState {
  const nowMs = Date.now();
  const start = new Date(timeUtc).getTime();
  const end   = start + (durationMinutes > 0 ? durationMinutes : 60) * 60_000;
  if (nowMs >= start && nowMs <= end) return "ongoing";
  return start > nowMs ? "upcoming" : "past";
}

/** Short, human-readable recurrence summary for the row badge.
 *  Mirrors the server's RecurrenceCalculator.Describe — kept compact
 *  to fit on a single line alongside duration + meeting code. */
function recurrenceLabel(m: Meeting): string | null {
  const t = m.recurrenceType ?? 0;
  if (!t) return null;
  const interval = m.recurrenceInterval && m.recurrenceInterval > 1 ? m.recurrenceInterval : 1;
  if (t === 1) return interval === 1 ? "Daily" : `Every ${interval} days`;
  if (t === 2) {
    const mask = m.recurrenceDaysOfWeekMask ?? 0;
    if (mask > 0) {
      const days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]
        .filter((_, i) => (mask & (1 << i)) !== 0).join(",");
      return interval === 1 ? `Weekly · ${days}` : `Every ${interval}w · ${days}`;
    }
    return interval === 1 ? "Weekly" : `Every ${interval} weeks`;
  }
  if (t === 3) return interval === 1 ? "Monthly" : `Every ${interval} months`;
  return null;
}

/**
 * Formats a 9 or 10-digit MeetingCode as "XXX XXX XXX" / "XXX XXX XXXX"
 * for human-friendly display. URLs continue to use the unspaced digits;
 * only display surfaces (mailto body, list secondary text) get the
 * spaced form. Mirrors MeetingService.FormatMeetingCodeForDisplay.
 */
function formatMeetingIdForDisplay(code: string | undefined | null): string {
  const digits = (code ?? "").replace(/\D/g, "");
  if (digits.length === 10) return `${digits.slice(0,3)} ${digits.slice(3,6)} ${digits.slice(6)}`;
  if (digits.length === 9)  return `${digits.slice(0,3)} ${digits.slice(3,6)} ${digits.slice(6)}`;
  return code ?? "";
}

export default function Home({ onViewParticipants }: Props) {
  const tz = useTzFormat();
  const toast = useToast();
  const isEmbedded = useOptionalMeetConfig() != null;
  const userCtx = useOptionalUser();

  const [meetings, setMeetings]       = useState<Meeting[]>([]);
  const [loading, setLoading]         = useState(true);
  const [page, setPage]               = useState(1);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  const [showPreview, setShowPreview]     = useState(false);
  const [showSchedule, setShowSchedule]   = useState(false);
  const [isJoinMode, setIsJoinMode]       = useState(false);
  const [editMeeting, setEditMeeting]     = useState<Meeting | null>(null);


  const [deleteTarget, setDeleteTarget]   = useState<Meeting | null>(null);
  const [deleting, setDeleting]           = useState(false);
  const [deleteError, setDeleteError]     = useState("");

  // Pre-warm Jitsi external_api.js so the popup opens faster on first click.
  useEffect(() => {
    if ("requestIdleCallback" in window) {
      requestIdleCallback(() => loadJitsiScript().catch(() => {}));
    } else {
      setTimeout(() => loadJitsiScript().catch(() => {}), 2000);
    }
  }, []);

  async function loadMeetings() {
    setLoading(true);
    try {
      const list = await listMeetings();
      // Defense-in-depth: server already filters by host, but if the host
      // adapter ever returns the wrong identity, the explicit isHost check
      // here keeps user A from seeing user B's rows in the UI.
      setMeetings(list.filter(m => m.isHost !== false));
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error("Failed to load meetings", err);
      setMeetings([]);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { loadMeetings(); }, []);
  useEffect(() => { setPage(1); }, [selectedDate]);

  const filteredMeetings = meetings
    .filter(m => formatInTz(m.scheduledTimeUtc, tz.timeZone, { year: "numeric", month: "2-digit", day: "2-digit" }) === formatInTz(selectedDate, tz.timeZone, { year: "numeric", month: "2-digit", day: "2-digit" }))
    .sort((a, b) => new Date(a.scheduledTimeUtc).getTime() - new Date(b.scheduledTimeUtc).getTime());

  const startIndex     = (page - 1) * PAGE_SIZE;
  const pagedMeetings  = filteredMeetings.slice(startIndex, startIndex + PAGE_SIZE);
  const totalPages     = Math.ceil(filteredMeetings.length / PAGE_SIZE);

  const isToday   = selectedDate.toDateString() === new Date().toDateString();
  const dateLabel = selectedDate.toLocaleDateString(undefined, {
    weekday: "long", month: "long", day: "numeric", year: "numeric",
  });

  function copyMeetingId(meetingCode: string) {
    // Copy the human-formatted code ("XXX XXX XXXX") since that's
    // what hosts paste into chat / calendar tools. URL routes accept
    // either form — the regex matches digits and our lookup strips
    // whitespace.
    navigator.clipboard.writeText(formatMeetingIdForDisplay(meetingCode));
    toast.success("Meeting ID copied to clipboard");
  }

  function downloadIcs(meetingCode: string) {
    // /oaticonnect/calendar/{room} bypasses the host's /api/* auth filter.
    // RoomName == MeetingCode in the new model.
    //
    // ?tz=… sends the current browser timezone as a fallback so the
    // .ics times render in the user's wall-clock even when the host's
    // stored profile timezone is empty or unrecognised by the server's
    // runtime. Without it, the server falls back to UTC formatting.
    let browserTz: string | undefined;
    try { browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone || undefined; }
    catch { browserTz = undefined; }
    const tzParam = browserTz ? `?tz=${encodeURIComponent(browserTz)}` : "";
    const url = `${getBasePath()}/oaticonnect/calendar/${encodeURIComponent(meetingCode)}${tzParam}`;
    const a = document.createElement("a");
    a.href = url;
    a.download = `meet-${meetingCode}.ics`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  async function shareViaEmail(m: Meeting) {
    // mailto: opens the user's local email client with a pre-filled
    // body — this path stays plain text (mailto strips HTML), so we
    // mirror the exact same structured template the server's .ics
    // DESCRIPTION and server-sent email use. All three sharing paths
    // therefore read identically: a header + key/value details +
    // separate "JOIN WITH ONE CLICK" and "JOIN FROM THE WEB CLIENT"
    // sections.
    const appName  = getAppName();
    const hostName = userCtx?.user?.name?.trim() || "The host";

    // Date + time labels in the host's IANA zone, en-GB style:
    //   "Friday, 22 May 2026"
    //   "20:48 – 21:48 GMT-5"
    const startMs   = new Date(m.scheduledTimeUtc).getTime();
    const endMs     = startMs + (m.durationMinutes || 60) * 60_000;
    const dateLabel = tz.formatDateLong(m.scheduledTimeUtc);
    const startTime = tz.formatTime(m.scheduledTimeUtc);
    const endZoned  = tz.formatTimeWithZone(new Date(endMs));
    // 24-hour start in the host's zone. tz.timeZone is sanitised by
    // useTzFormat (invalid zones already downgraded to undefined),
    // but we still wrap in try/catch as defense-in-depth — Linux
    // deployments throw RangeError on legacy zone abbreviations like
    // "CPT" that Windows JS engines accept silently.
    let start24: string;
    try {
      start24 = new Intl.DateTimeFormat("en-GB", {
        hour: "2-digit", minute: "2-digit", hour12: false,
        timeZone: tz.timeZone || undefined,
      }).format(new Date(m.scheduledTimeUtc));
    } catch {
      start24 = new Intl.DateTimeFormat("en-GB", {
        hour: "2-digit", minute: "2-digit", hour12: false,
      }).format(new Date(m.scheduledTimeUtc));
    }
    void startTime; // legacy var, kept for diff readability
    const timeLabel = `${start24} – ${endZoned}`;

    let shareUrl = "";
    try {
      const link = await getMeetingShareLink(m.meetingId);
      shareUrl = link.url;
    } catch (e) {
      console.warn("[Home] could not fetch share link", e);
    }

    const configuredWebClient = userCtx?.preferences?.webClientUrl?.trim();
    const webClientUrl = configuredWebClient && configuredWebClient.length > 0
      ? configuredWebClient.replace(/\/+$/, "")
      : `${window.location.origin}${getBasePath()}/oaticonnect/join`.replace(/\/+$/, "");

    // Subject = the meeting title verbatim. Zoom-style.
    const subject = m.title;

    // Four separator widths — hard-coded to the host's signed-off draft.
    // No blank lines between sections; ribbons do all the visual work.
    const outerTop    = "-".repeat(75);
    const outerBottom = "-".repeat(102);
    const innerShort  = "-".repeat(39);
    const innerLong   = "-".repeat(61);
    const webHeading  = `Join meeting using ${appName} Web Client`;
    const meetingId   = formatMeetingIdForDisplay(m.meetingCode || m.title);

    const lines: (string | null)[] = [
      outerTop,
      `${hostName} is inviting you to ${appName} meeting.`,
      outerTop,
      `Meeting Details:`,
      innerShort,
      ` Topic: ${m.title}`,
      ` Date: ${dateLabel}`,
      ` Time: ${timeLabel}`,
      innerShort,
      ` Meeting Id : ${meetingId}`,
      m.password ? ` Password   : ${m.password}` : null,
      innerShort,
      ``,
      `Join meeting with link`,
      innerShort,
      `  ${shareUrl || "(share link unavailable — please contact the meeting host)"}`,
      ``,
      // Web-client heading is sandwiched between two innerLong ribbons,
      // making it visually distinct from the link-share section above.
      innerLong,
      webHeading,
      innerLong,
      `  ${webClientUrl}`,
      `  Enter the Meeting ID and password on that page to join from any browser.`,
      outerBottom,
      m.description ? `` : null,
      m.description ? m.description : null,
    ];
    const body = lines.filter((l): l is string => l !== null).join("\n");
    const href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    const a = document.createElement("a");
    a.href = href;
    a.target = "_blank";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  /**
   * Copies the click-to-join link to the clipboard. Same URL the server
   * bakes into invite emails / .ics — the host can paste it into any
   * chat / email / DM and recipients click straight into the meeting.
   */
  async function copyShareLink(m: Meeting) {
    try {
      const link = await getMeetingShareLink(m.meetingId);
      await navigator.clipboard.writeText(link.url);
      toast.success("Join link copied to clipboard");
    } catch (e) {
      console.warn("[Home] could not copy share link", e);
      toast.error("Couldn't copy the join link. Please try again.");
    }
  }

  /**
   * Opens the click-to-join link in a popup window — identical
   * dimensions to <c>openMeetingWindow</c>. Useful for the host who wants
   * to test the recipient experience, or to open a guest seat next to
   * the moderator window.
   *
   * Currently unreferenced — the grid's external-link preview icon
   * was hidden in favour of just copying the URL (host can paste it
   * anywhere). Kept here so re-enabling the icon is a one-line change.
   */
  // @ts-ignore — intentionally unreferenced while the preview icon is hidden.
  async function openShareLinkPopup(m: Meeting) {
    try {
      const link = await getMeetingShareLink(m.meetingId);
      window.open(link.url, "meetingShareWindow", "width=1400,height=900,resizable=yes");
    } catch (e) {
      console.warn("[Home] could not open share link", e);
    }
  }

  return (
    <div className={`home${isEmbedded ? " home-embedded" : ""}`}>

      {/* ACTIONS */}
      <div className="home-actions">
        <ActionButton label="New Meeting" color="orange" icon="video"
          onClick={() => { setIsJoinMode(false); setShowPreview(true); }} />
        <ActionButton label="Join" color="indigo" icon="plus"
          onClick={() => { setIsJoinMode(true); setShowPreview(true); }} />
        <ActionButton label="Schedule" color="indigo" icon="calendar"
          onClick={() => setShowSchedule(true)} />
      </div>

      {/* MEETINGS TIMELINE */}
      <div className="home-card">
        <div className="card-header-row">
          <div className="timeline-date-heading">
            {isToday ? "Today" : ""} {dateLabel}
          </div>
          <div className="zoom-toolbar">
            <DatePicker
              selected={selectedDate}
              onChange={(d: Date | null) => d && setSelectedDate(d)}
              dateFormat="MMM d, yyyy"
              className="datepicker-input home-date-input"
              wrapperClassName="datepicker-wrapper home-date-wrapper"
              popperClassName="datepicker-popper"
              popperPlacement="bottom-end"
            />
            <button className="icon-btn" onClick={() => {
              const d = new Date(selectedDate); d.setDate(d.getDate() - 1); setSelectedDate(d);
            }}>&#8249;</button>
            <button className="icon-btn" onClick={() => {
              const d = new Date(selectedDate); d.setDate(d.getDate() + 1); setSelectedDate(d);
            }}>&#8250;</button>
            <button className="today-btn" onClick={() => setSelectedDate(new Date())}>Today</button>
          </div>
        </div>
        <div className="timeline-divider"></div>

        {loading ? (
          <p className="muted">Loading meetings...</p>
        ) : filteredMeetings.length === 0 ? (
          <div className="empty-state-container">
            <div className="empty-state-icon">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                <line x1="16" y1="2" x2="16" y2="6" />
                <line x1="8"  y1="2" x2="8"  y2="6" />
                <line x1="3"  y1="10" x2="21" y2="10" />
              </svg>
            </div>
            <p className="empty-state-text">No meetings scheduled</p>
            <button className="btn btn-primary btn-sm" onClick={() => setShowSchedule(true)}>
              Schedule Meeting
            </button>
          </div>
        ) : (
          <>
            <div className="timeline-list">
              {pagedMeetings.map(m => {
                // For recurring meetings with a future next-occurrence,
                // anchor the timeline state + time off that next slot
                // rather than the immutable first occurrence — otherwise
                // a daily series whose first occurrence already passed
                // would permanently read as "past".
                const isSeries = (m.recurrenceType ?? 0) !== 0;
                const effectiveStartUtc = isSeries && m.nextOccurrenceUtc
                  ? m.nextOccurrenceUtc
                  : m.scheduledTimeUtc;
                const state = getRowState(effectiveStartUtc, m.durationMinutes);
                const time  = tz.formatTime(effectiveStartUtc);
                const nextLabel = isSeries && m.nextOccurrenceUtc
                  ? `Next: ${tz.formatDateTimeLong(m.nextOccurrenceUtc)}`
                  : null;
                return (
                  <div key={m.meetingId} className={`timeline-row ${state}`}>
                    <div className="timeline-time"><span className="timeline-time-text">{time}</span></div>
                    <div className="timeline-connector">
                      <div className={`timeline-dot timeline-dot-${state}`}></div>
                      <div className="timeline-line"></div>
                    </div>
                    <div className="timeline-content">
                      <div className="timeline-content-main">
                        <div className="timeline-title-row">
                          <span className="timeline-title">{m.title}</span>
                          <span className="timeline-meeting-code">{formatMeetingIdForDisplay(m.meetingCode)}</span>
                          <button type="button" className="timeline-copy-btn"
                            title="Copy meeting ID"
                            onClick={(e) => { e.stopPropagation(); copyMeetingId(m.meetingCode); }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                            </svg>
                          </button>
                          <span className={`timeline-status-badge timeline-status-${state}`}>
                            {state === "ongoing" ? "Live" : state === "upcoming" ? "Scheduled" : "Ended"}
                          </span>
                        </div>
                        <div className="timeline-meta">
                          <span className="timeline-duration">{m.durationMinutes || 60} min</span>
                          {/* MeetingCode badge intentionally hidden — in auto-mode the meeting
                              Title IS the user-facing join ID, so a second number was redundant
                              and confusing. Re-enable here if a future manual-mode flow needs
                              to expose the random 9-digit MeetingCode. */}
                          {recurrenceLabel(m) && (
                            <span className="timeline-recurrence-badge" title="Recurring meeting">
                              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                <polyline points="23 4 23 10 17 10" />
                                <polyline points="1 20 1 14 7 14" />
                                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                              </svg>
                              {recurrenceLabel(m)}
                            </span>
                          )}
                          {m.isHost === false && (
                            <span className="timeline-invited-badge" title="You were invited to this meeting">Invited</span>
                          )}
                        </div>
                      </div>
                      {nextLabel && (
                        <div className="timeline-next-occurrence">{nextLabel}</div>
                      )}
                      {m.description && (
                        <div className="timeline-description-col">{m.description}</div>
                      )}
                      <div className="timeline-actions">
                        {/* Inline icon action bar â€” replaces the old labelled
                            Start/Join button + 3-dot kebab. Every per-row
                            action is one click away. Start/Join is the
                            primary (filled) icon to keep visual hierarchy;
                            the rest are ghost icons. Host-only actions
                            (View Participants / Edit / Delete) only render
                            when the user owns the meeting; the server
                            enforces the same gate via FORBIDDEN. */}
                        <div className="timeline-icon-actions">
                          <button type="button" className="row-icon-btn row-icon-btn-primary"
                            title="Start/Join meeting"
                            onClick={() => openMeetingWindow(m.meetingCode)}>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                              <polygon points="6 4 20 12 6 20 6 4" />
                            </svg>
                          </button>
                          {/* Copy intentionally lives next to the meeting
                              title â€” no need to duplicate it here. */}
                          <button type="button" className="row-icon-btn"
                            title="Download .ics calendar invite"
                            onClick={() => downloadIcs(m.meetingCode)}>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                              <polyline points="7 10 12 15 17 10" />
                              <line x1="12" y1="15" x2="12" y2="3" />
                            </svg>
                          </button>
                          {/* Order: download .ics → email → copy link → participants.
                              Email comes BEFORE the copy-link icon so the most-common
                              "send invite" flow is the first sharing action a host hits. */}
                          <button type="button" className="row-icon-btn"
                            title="Share via email (includes click-to-join link)"
                            onClick={() => shareViaEmail(m)}>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                              <polyline points="22,6 12,13 2,6" />
                            </svg>
                          </button>
                          {m.isHost !== false && (
                            <button type="button" className="row-icon-btn"
                              title="Copy click-to-join link (host only)"
                              onClick={() => copyShareLink(m)}>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 0 0-7.07-7.07l-1.5 1.5" />
                                <path d="M14 11a5 5 0 0 0-7.07 0l-3 3a5 5 0 0 0 7.07 7.07l1.5-1.5" />
                              </svg>
                            </button>
                          )}
                          {/* "Open click-to-join link in popup" preview-as-guest icon
                              (external-link / arrow-out-of-box SVG) hidden — host can
                              paste the copied URL into a new tab if they want to preview
                              the join experience. Re-enable here if a one-click preview
                              flow becomes useful again. */}
                          {m.isHost !== false && onViewParticipants && (
                            <button type="button" className="row-icon-btn"
                              title="View participants"
                              onClick={() => onViewParticipants(m)}>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                                <circle cx="9" cy="7" r="4" />
                                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                              </svg>
                            </button>
                          )}
                          {m.isHost !== false && (
                            <button type="button" className="row-icon-btn"
                              title="Edit meeting"
                              onClick={() => { setEditMeeting(m); setShowSchedule(true); }}>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                              </svg>
                            </button>
                          )}
                          {m.isHost !== false && (
                            <button type="button" className="row-icon-btn row-icon-btn-danger"
                              title="Delete meeting"
                              onClick={() => { setDeleteError(""); setDeleteTarget(m); }}>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <polyline points="3 6 5 6 21 6" />
                                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                                <path d="M10 11v6" />
                                <path d="M14 11v6" />
                                <path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2" />
                              </svg>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="timeline-end-note">No more meetings {isToday ? "today" : "on this day"}</div>

            {totalPages > 1 && (
              <div className="paging">
                <button disabled={page === 1} onClick={() => setPage(p => p - 1)}>â† Prev</button>
                <span>Page {page} / {totalPages}</span>
                <button disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>Next â†’</button>
              </div>
            )}
          </>
        )}
      </div>

      {/* MODALS */}
      {showPreview && (
        <NewMeetingPreviewModal
          isJoinMode={isJoinMode}
          onClose={() => { setShowPreview(false); loadMeetings(); }}
        />
      )}

      {showSchedule && (
        <ScheduleMeetingModal
          editMeeting={editMeeting ? {
            meetingId:        editMeeting.meetingId,
            meetingCode:      editMeeting.meetingCode,
            title:            editMeeting.title,
            description:      editMeeting.description ?? undefined,
            scheduledTimeUtc: editMeeting.scheduledTimeUtc,
            durationMinutes:  editMeeting.durationMinutes,
            inviteeEmails:    editMeeting.inviteeEmails,
            password:         editMeeting.password,
            requireHostStart: editMeeting.requireHostStart,
            recurrenceType:           editMeeting.recurrenceType,
            recurrenceInterval:       editMeeting.recurrenceInterval,
            recurrenceDaysOfWeekMask: editMeeting.recurrenceDaysOfWeekMask,
            recurrenceEndType:        editMeeting.recurrenceEndType,
            recurrenceEndCount:       editMeeting.recurrenceEndCount,
            recurrenceEndDateUtc:     editMeeting.recurrenceEndDateUtc,
          } : undefined}
          onClose={() => { setShowSchedule(false); setEditMeeting(null); loadMeetings(); }}
        />
      )}


      {deleteTarget && (() => {
        // Recurring-series detection — when the meeting recurs AND the
        // next slot is known, offer the host a choice between cancelling
        // the next occurrence only vs deleting the whole series. Non-
        // recurring meetings + series with no future occurrences left
        // fall back to the original single Delete prompt.
        const isSeries = (deleteTarget.recurrenceType ?? 0) !== 0;
        const next = deleteTarget.nextOccurrenceUtc ? new Date(deleteTarget.nextOccurrenceUtc) : null;
        const showOccurrenceOption = isSeries && deleteTarget.isHost !== false && !!next;
        const nextDateLabel = next
          ? next.toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })
          : "";
        return (
        <div className="modal-backdrop" onClick={() => { if (!deleting) setDeleteTarget(null); }}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 480 }}>
            <h3 style={{ margin: "0 0 12px" }}>
              {showOccurrenceOption ? "Delete recurring meeting" : "Delete Meeting"}
            </h3>
            <p style={{ margin: "0 0 16px", color: "var(--color-text-secondary)" }}>
              {showOccurrenceOption ? (
                <>
                  <strong style={{ color: "var(--color-text)" }}>{deleteTarget.title}</strong>{" "}
                  is a recurring meeting. Cancel just the next occurrence on
                  {" "}<strong style={{ color: "var(--color-text)" }}>{nextDateLabel}</strong>,
                  or delete the whole series?
                </>
              ) : (
                <>
                  Are you sure you want to delete{" "}
                  <strong style={{ color: "var(--color-text)" }}>{deleteTarget.title}</strong>? This cannot be undone.
                </>
              )}
            </p>
            {deleteError && (
              <div style={{ color: "var(--color-danger)", marginBottom: 12, fontSize: 13 }}>{deleteError}</div>
            )}
            <div className="modal-actions" style={{ gap: 8, flexWrap: "wrap" }}>
              <button className="btn btn-secondary" disabled={deleting}
                onClick={() => setDeleteTarget(null)}>Cancel</button>
              {showOccurrenceOption && (
                <button className="btn btn-secondary" disabled={deleting}
                  onClick={async () => {
                    setDeleting(true);
                    setDeleteError("");
                    try {
                      await cancelOccurrence(deleteTarget.meetingId, next!.toISOString());
                      setDeleteTarget(null);
                      await loadMeetings();
                      toast.success(`Cancelled the ${nextDateLabel} occurrence`);
                    } catch (err) {
                      console.error("Cancel occurrence failed", err);
                      setDeleteError("Failed to cancel this occurrence.");
                    } finally {
                      setDeleting(false);
                    }
                  }}>
                  {deleting ? "Working..." : "Cancel this occurrence"}
                </button>
              )}
              <button className="btn btn-danger" disabled={deleting}
                onClick={async () => {
                  setDeleting(true);
                  setDeleteError("");
                  try {
                    await deleteMeeting(deleteTarget.meetingId);
                    setDeleteTarget(null);
                    await loadMeetings();
                  } catch (err) {
                    // eslint-disable-next-line no-console
                    console.error("Delete failed", err);
                    setDeleteError("Failed to delete meeting.");
                  } finally {
                    setDeleting(false);
                  }
                }}>
                {deleting ? "Deleting..." : showOccurrenceOption ? "Delete entire series" : "Delete"}
              </button>
            </div>
          </div>
        </div>
        );
      })()}
    </div>
  );
}

