import { useEffect, useState } from "react";
import { useUser } from "../contexts/UserContext";
import {
  getMeetingPreferences,
  saveMeetingPreferences,
  type MeetingPreferences,
} from "../api/settings.api";
import {
  getAppConfigs,
  upsertAppConfig,
} from "../api/appconfig.api";
import { testExchangeConnection } from "../api/exchange.api";
import { refreshAppConfig } from "../config/env";

import "./Settings.css";

type Tab = "app-settings" | "preferences";
type PrefSubTab = "general" | "jitsi" | "toolbar";

const JITSI_FLAGS: { key: keyof MeetingPreferences; label: string; desc?: string }[] = [
  { key: "disablePreJoinPage",     label: "Disable PreJoin page",   desc: "Skip the prejoin step where users adjust mic/camera before joining." },
  { key: "audioOnly",              label: "Audio only",             desc: "No video sent or received — frees bandwidth for the audio call." },
  { key: "startWithAudioMuted",    label: "Start with audio muted" },
  { key: "startWithCameraOff",     label: "Start with camera off" },
  { key: "disableFaceCentering",   label: "Disable face centering" },
  { key: "disableTileEnlargement", label: "Disable tile enlargement", desc: "Skip cropping/enlarging tile videos." },
  { key: "skipMediaPermissions",   label: "Skip media permissions",   desc: "Don't request mic/camera permissions on join." },
  { key: "disableNotifications",   label: "Disable all notifications" },
];

const TOOLBAR_BUTTONS = [
  "Microphone", "Camera", "Screenshare", "Chat", "RaiseHand",
  "Participants", "TileView", "ToggleCamera", "Hangup", "Profile",
  "Invite", "Settings", "Fullscreen", "Security", "ClosedCaptions",
  "Recording", "LiveStreaming", "ShareVideo", "ShareAudio",
  "NoiseSuppression", "Whiteboard", "Etherpad", "SelectBackground",
  "Help", "Filmstrip",
];

function defaultPrefs(): MeetingPreferences {
  const tb: Record<string, boolean> = {};
  TOOLBAR_BUTTONS.forEach(n => { tb[n] = true; });
  return {
    defaultCameraOn: true,
    defaultMicOn: true,
    defaultDurationMinutes: 60,
    meetingNameMode: "auto",
    enableMeetingPassword: false,
    requireHostStart: false,
    encryptedShareLink: true,
    embedPasswordInLink: false,
    recurringMaxDurationDays: 90,
    webClientUrl: "",
    disablePreJoinPage: false,
    audioOnly: false,
    startWithAudioMuted: false,
    startWithCameraOff: false,
    disableFaceCentering: false,
    disableTileEnlargement: false,
    skipMediaPermissions: false,
    disableNotifications: false,
    toolbarButtons: tb,
  };
}

export default function Settings() {
  const { user, loading: userLoading, refreshPreferences } = useUser();
  const isAdmin = user?.role === "Admin";

  const [activeTab, setActiveTab]       = useState<Tab>("app-settings");
  const [prefSubTab, setPrefSubTab]     = useState<PrefSubTab>("general");

  // App-level config rows (App:Name, Jitsi:ServerBaseUrl)
  const [appName, setAppName]               = useState("");
  const [jitsiUrl, setJitsiUrl]             = useState("");
  const [appNameSaving, setAppNameSaving]   = useState(false);
  const [jitsiUrlSaving, setJitsiUrlSaving] = useState(false);
  const [appNameMsg, setAppNameMsg]         = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const [jitsiUrlMsg, setJitsiUrlMsg]       = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  // Exchange / Outlook integration (Phase 1: form only, real Graph wiring
  // lands in Phase 2). All fields persist as individual rows in
  // OATIConnect_Configs so they show up alongside App:Name / Jitsi:* in
  // the same admin grid.
  const [xchgEnabled, setXchgEnabled]     = useState(false);
  const [xchgTenant, setXchgTenant]       = useState("");
  const [xchgClient, setXchgClient]       = useState("");
  const [xchgSecret, setXchgSecret]       = useState("");
  const [xchgMode, setXchgMode]           = useState<"App" | "Delegated">("App");
  const [xchgSaving, setXchgSaving]       = useState(false);
  const [xchgTesting, setXchgTesting]     = useState(false);
  const [xchgMsg, setXchgMsg]             = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  // Header display preferences (App:ShowClock, App:ShowThemeToggle,
  // App:DefaultTheme). Saved as three kvp rows.
  const [showClock, setShowClock]               = useState(false);
  const [showThemeToggle, setShowThemeToggle]   = useState(true);
  const [defaultTheme, setDefaultTheme]         = useState<"light" | "dark" | "system">("system");
  const [headerSaving, setHeaderSaving]         = useState(false);
  const [headerMsg, setHeaderMsg]               = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  // Typed preferences
  const [prefs, setPrefs]         = useState<MeetingPreferences>(defaultPrefs);
  const [prefsLoading, setPrefsLoading] = useState(true);
  const [prefsSaving, setPrefsSaving]   = useState(false);
  const [prefsMsg, setPrefsMsg]   = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  useEffect(() => {
    getAppConfigs()
      .then(rows => {
        const byKey = (k: string) => rows.find(r => r.key === k)?.value ?? "";
        setAppName(byKey("App:Name") || "OATIConnect");
        setJitsiUrl(byKey("Jitsi:ServerBaseUrl"));
        setXchgEnabled(byKey("Exchange:Enabled").toLowerCase() === "true");
        setXchgTenant(byKey("Exchange:TenantId"));
        setXchgClient(byKey("Exchange:ClientId"));
        setXchgSecret(byKey("Exchange:ClientSecret"));
        const mode = byKey("Exchange:Mode");
        setXchgMode(mode === "Delegated" ? "Delegated" : "App");

        // Header display
        const sc = byKey("App:ShowClock").toLowerCase();
        setShowClock(sc === "true");      // default off when missing
        const stt = byKey("App:ShowThemeToggle").toLowerCase();
        setShowThemeToggle(stt === "" ? true : stt === "true");
        const dt = byKey("App:DefaultTheme").toLowerCase();
        setDefaultTheme(dt === "light" || dt === "dark" ? dt : "system");
      })
      .catch(() => {});
    getMeetingPreferences()
      .then(setPrefs)
      .catch(() => setPrefs(defaultPrefs()))
      .finally(() => setPrefsLoading(false));
  }, []);

  async function saveHeader() {
    setHeaderMsg(null); setHeaderSaving(true);
    try {
      // Three kvp upserts.
      await upsertAppConfig({ key: "App:ShowClock", value: showClock ? "true" : "false",
        description: "Show the live clock in the top header (true/false)", category: "Header" });
      await upsertAppConfig({ key: "App:ShowThemeToggle", value: showThemeToggle ? "true" : "false",
        description: "Show the dark/light theme toggle button in the top header (true/false)", category: "Header" });
      await upsertAppConfig({ key: "App:DefaultTheme", value: defaultTheme,
        description: "Initial theme: light, dark, or system (follows OS)", category: "Header" });
      // Re-fetch /api/v1/config so the in-memory cache picks up new values,
      // then broadcast a window event the dashboard listens for. End result:
      // toggles in the header (clock, theme button) flip live without a
      // full page refresh.
      await refreshAppConfig();
      window.dispatchEvent(new CustomEvent("oaticonnect-config-updated"));
      setHeaderMsg({ kind: "ok", text: "Header settings saved." });
    } catch {
      setHeaderMsg({ kind: "err", text: "Failed to save header settings." });
    } finally { setHeaderSaving(false); }
  }

  async function saveExchange() {
    setXchgMsg(null); setXchgSaving(true);
    try {
      // Five separate kvp upserts. The keys appear together in the
      // /appconfig list so admins can also edit them as raw kvp if needed.
      await upsertAppConfig({ key: "Exchange:Enabled",      value: xchgEnabled ? "true" : "false",
                              description: "Whether Outlook/Exchange integration is enabled", category: "Exchange" });
      await upsertAppConfig({ key: "Exchange:TenantId",     value: xchgTenant,
                              description: "Azure AD tenant id (GUID)",   category: "Exchange" });
      await upsertAppConfig({ key: "Exchange:ClientId",     value: xchgClient,
                              description: "Azure AD app client id",       category: "Exchange" });
      await upsertAppConfig({ key: "Exchange:ClientSecret", value: xchgSecret,
                              description: "Azure AD app client secret",   category: "Exchange" });
      await upsertAppConfig({ key: "Exchange:Mode",         value: xchgMode,
                              description: "Auth mode: App (server creds) or Delegated (per-user)", category: "Exchange" });
      setXchgMsg({ kind: "ok", text: "Exchange settings saved." });
    } catch {
      setXchgMsg({ kind: "err", text: "Failed to save Exchange settings." });
    } finally { setXchgSaving(false); }
  }

  async function testExchange() {
    setXchgMsg(null); setXchgTesting(true);
    try {
      const r = await testExchangeConnection();
      setXchgMsg({ kind: r.success ? "ok" : "err", text: r.message });
    } catch {
      setXchgMsg({ kind: "err", text: "Test connection failed." });
    } finally { setXchgTesting(false); }
  }

  async function saveAppName() {
    setAppNameMsg(null); setAppNameSaving(true);
    try {
      await upsertAppConfig({
        key: "App:Name", value: appName,
        description: "Display name of the application", category: "Branding",
      });
      setAppNameMsg({ kind: "ok", text: "Saved. Refresh the page to see the new name everywhere." });
    } catch {
      setAppNameMsg({ kind: "err", text: "Failed to save app name." });
    } finally { setAppNameSaving(false); }
  }

  async function saveJitsiUrl() {
    setJitsiUrlMsg(null); setJitsiUrlSaving(true);
    try {
      await upsertAppConfig({
        key: "Jitsi:ServerBaseUrl", value: jitsiUrl,
        description: "Base URL for the Jitsi server", category: "Jitsi",
      });
      setJitsiUrlMsg({ kind: "ok", text: "Saved." });
    } catch {
      setJitsiUrlMsg({ kind: "err", text: "Failed to save Jitsi server URL." });
    } finally { setJitsiUrlSaving(false); }
  }

  async function savePrefs() {
    setPrefsMsg(null); setPrefsSaving(true);
    try {
      await saveMeetingPreferences(prefs);
      // Re-pull into UserContext so Home / NewMeeting / Schedule see the
      // new defaults immediately — without this, in-app pages would keep
      // using the cached prefs until the user refreshed the host page.
      await refreshPreferences();
      setPrefsMsg({ kind: "ok", text: "Preferences saved." });
    } catch {
      setPrefsMsg({ kind: "err", text: "Failed to save preferences." });
    } finally { setPrefsSaving(false); }
  }

  if (userLoading) {
    return <div className="settings-loading"><div className="spinner" /></div>;
  }

  // Tabs visible in the UI. App settings are admin-only — non-admins still
  // reach the page but only see meeting preferences (camera defaults etc.).
  const tabs: { key: Tab; label: string }[] = isAdmin
    ? [{ key: "app-settings", label: "App Settings" }, { key: "preferences", label: "Meeting Preferences" }]
    : [{ key: "preferences", label: "Meeting Preferences" }];
  const currentTab: Tab = tabs.some(t => t.key === activeTab) ? activeTab : tabs[0].key;

  return (
    <div className="settings-page">
      <h1>Settings</h1>

      <div className="settings-tabs">
        {tabs.map(t => (
          <button key={t.key}
            className={`settings-tab ${currentTab === t.key ? "settings-tab-active" : ""}`}
            onClick={() => setActiveTab(t.key)}>
            {t.label}
          </button>
        ))}
      </div>

      {currentTab === "app-settings" && (
        <>
          <div className="settings-section">
            <h2 className="settings-section-title">App Settings</h2>

            {appNameMsg && (
              <div className={appNameMsg.kind === "ok" ? "settings-success" : "settings-error"}>
                {appNameMsg.text}
              </div>
            )}
            <div className="settings-form-group">
              <label className="label">App Name</label>
              <input className="input" placeholder="e.g. OATIConnect"
                value={appName} onChange={e => setAppName(e.target.value)} />
              <div className="settings-toggle-desc" style={{ marginTop: 6 }}>
                Display name shown in nav, login pages, and the desktop app window title.
              </div>
            </div>
            <div className="settings-actions">
              <button type="button" className="settings-btn settings-btn-primary"
                disabled={appNameSaving || !appName.trim()} onClick={saveAppName}>
                {appNameSaving ? "Saving..." : "Save App Name"}
              </button>
            </div>

            <div style={{ height: 1, background: "var(--color-border)", margin: "var(--space-4) 0" }} />

            {jitsiUrlMsg && (
              <div className={jitsiUrlMsg.kind === "ok" ? "settings-success" : "settings-error"}>
                {jitsiUrlMsg.text}
              </div>
            )}
            <div className="settings-form-group">
              <label className="label">Jitsi Server URL</label>
              <input className="input" placeholder="e.g. meet.example.com"
                value={jitsiUrl} onChange={e => setJitsiUrl(e.target.value)} />
            </div>
            <div className="settings-actions">
              <button type="button" className="settings-btn settings-btn-primary"
                disabled={jitsiUrlSaving} onClick={saveJitsiUrl}>
                {jitsiUrlSaving ? "Saving..." : "Save"}
              </button>
            </div>
          </div>

          {/* ---------- Header Display ---------- */}
          <div className="settings-section">
            <h2 className="settings-section-title">Header Display</h2>
            <div className="settings-toggle-desc" style={{ marginBottom: "var(--space-3)" }}>
              Control what shows up in the top bar (clock, theme toggle) and the initial light/dark theme.
            </div>

            {headerMsg && (
              <div className={headerMsg.kind === "ok" ? "settings-success" : "settings-error"}>
                {headerMsg.text}
              </div>
            )}

            <div className="settings-toggle-row">
              <div>
                <div className="settings-toggle-label">Show clock</div>
                <div className="settings-toggle-desc">Display the live ticking clock + date in the top header.</div>
              </div>
              <label className="toggle-switch">
                <input type="checkbox" checked={showClock}
                  onChange={e => setShowClock(e.target.checked)} />
                <span className="toggle-slider" />
              </label>
            </div>

            <div className="settings-toggle-row">
              <div>
                <div className="settings-toggle-label">Show theme toggle</div>
                <div className="settings-toggle-desc">Show the sun/moon button so users can flip light/dark on demand.</div>
              </div>
              <label className="toggle-switch">
                <input type="checkbox" checked={showThemeToggle}
                  onChange={e => setShowThemeToggle(e.target.checked)} />
                <span className="toggle-slider" />
              </label>
            </div>

            <div className="settings-form-group">
              <label className="label">Default theme</label>
              <select className="input" value={defaultTheme}
                onChange={e => setDefaultTheme(e.target.value as "light" | "dark" | "system")}>
                <option value="system">System (follow OS preference)</option>
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
              <div className="settings-toggle-desc" style={{ marginTop: 6 }}>
                Initial theme on first load. A user's manual toggle persists in their browser and overrides this.
              </div>
            </div>

            <div className="settings-actions">
              <button type="button" className="settings-btn settings-btn-primary"
                disabled={headerSaving} onClick={saveHeader}>
                {headerSaving ? "Saving..." : "Save Header settings"}
              </button>
            </div>
          </div>

          {/* ---------- Exchange / Outlook integration ---------- */}
          <div className="settings-section">
            <h2 className="settings-section-title">Outlook / Exchange Integration</h2>
            <div className="settings-toggle-desc" style={{ marginBottom: "var(--space-3)" }}>
              Read distribution lists, contacts, and users from Microsoft 365 / Exchange so meeting hosts can invite groups.
              The invite picker on the Schedule meeting form only appears when this is enabled. <em>Phase 1: form only — Microsoft Graph wiring lands in a follow-up.</em>
            </div>

            {xchgMsg && (
              <div className={xchgMsg.kind === "ok" ? "settings-success" : "settings-error"}>
                {xchgMsg.text}
              </div>
            )}

            <div className="settings-toggle-row">
              <div>
                <div className="settings-toggle-label">Enable Exchange integration</div>
                <div className="settings-toggle-desc">When off, OATIConnect ignores all Exchange settings below.</div>
              </div>
              <label className="toggle-switch">
                <input type="checkbox" checked={xchgEnabled}
                  onChange={e => setXchgEnabled(e.target.checked)} />
                <span className="toggle-slider" />
              </label>
            </div>

            <div className="settings-form-group">
              <label className="label">Tenant ID</label>
              <input className="input" placeholder="00000000-0000-0000-0000-000000000000"
                value={xchgTenant} onChange={e => setXchgTenant(e.target.value)}
                disabled={!xchgEnabled} />
            </div>

            <div className="settings-form-group">
              <label className="label">Client ID</label>
              <input className="input" placeholder="00000000-0000-0000-0000-000000000000"
                value={xchgClient} onChange={e => setXchgClient(e.target.value)}
                disabled={!xchgEnabled} />
            </div>

            <div className="settings-form-group">
              <label className="label">Client Secret</label>
              <input className="input" type="password" placeholder="••••••••"
                value={xchgSecret} onChange={e => setXchgSecret(e.target.value)}
                disabled={!xchgEnabled} />
              <div className="settings-toggle-desc" style={{ marginTop: 6 }}>
                Stored in <code>OATIConnect_Configs</code>. Treat the database row as a secret.
              </div>
            </div>

            <div className="settings-form-group">
              <label className="label">Auth Mode</label>
              <select className="input" value={xchgMode}
                onChange={e => setXchgMode(e.target.value as "App" | "Delegated")}
                disabled={!xchgEnabled}>
                <option value="App">App (server credentials — sees all org groups)</option>
                <option value="Delegated">Delegated (per-user — only that user's groups)</option>
              </select>
            </div>

            <div className="settings-actions">
              <button type="button" className="settings-btn settings-btn-secondary"
                disabled={xchgTesting || !xchgEnabled} onClick={testExchange}>
                {xchgTesting ? "Testing..." : "Test connection"}
              </button>
              <button type="button" className="settings-btn settings-btn-primary"
                disabled={xchgSaving} onClick={saveExchange}>
                {xchgSaving ? "Saving..." : "Save Exchange settings"}
              </button>
            </div>
          </div>
        </>
      )}

      {currentTab === "preferences" && (
        <div className="settings-section">
          {prefsLoading ? (
            <div className="settings-loading"><div className="spinner" /></div>
          ) : (
            <>
              {/* Sticky header: section title + sub-tab nav + always-visible
                  Save button. Stays put while the long preference list scrolls
                  underneath, so you don't have to scroll to the bottom to save. */}
              <div className="prefs-sticky-header">
                <div className="prefs-sticky-title-row">
                  <h2 className="settings-section-title prefs-sticky-title">Meeting Preferences</h2>
                  <button type="button" className="settings-btn settings-btn-primary"
                    disabled={prefsSaving} onClick={savePrefs}>
                    {prefsSaving ? "Saving..." : "Save Preferences"}
                  </button>
                </div>

                <div className="prefs-subtabs">
                  {([
                    { key: "general", label: "General" },
                    { key: "jitsi",   label: "Jitsi Features" },
                    { key: "toolbar", label: "Toolbar Buttons" },
                  ] as { key: PrefSubTab; label: string }[]).map(t => (
                    <button key={t.key}
                      type="button"
                      className={`prefs-subtab ${prefSubTab === t.key ? "prefs-subtab-active" : ""}`}
                      onClick={() => setPrefSubTab(t.key)}>
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {prefsMsg && (
                <div className={prefsMsg.kind === "ok" ? "settings-success" : "settings-error"}>
                  {prefsMsg.text}
                </div>
              )}

              {prefSubTab === "general" && (
                <>
                  <div className="settings-form-group">
                    <label className="label">Meeting Name Mode</label>
                    <select className="input" value={prefs.meetingNameMode}
                      onChange={e => setPrefs(p => ({ ...p, meetingNameMode: e.target.value as "auto" | "manual" }))}>
                      <option value="auto">Auto-generate (Zoom-style meeting ID)</option>
                      <option value="manual">Manual (enter meeting name)</option>
                    </select>
                  </div>

                  <div className="settings-form-group">
                    <label className="label">Default Meeting Duration</label>
                    <select className="input" value={prefs.defaultDurationMinutes}
                      onChange={e => setPrefs(p => ({ ...p, defaultDurationMinutes: Number(e.target.value) }))}>
                      <option value={15}>15 minutes</option>
                      <option value={30}>30 minutes</option>
                      <option value={45}>45 minutes</option>
                      <option value={60}>1 hour</option>
                      <option value={90}>1.5 hours</option>
                      <option value={120}>2 hours</option>
                      <option value={180}>3 hours</option>
                    </select>
                  </div>

                  <ToggleRow label="Camera"     desc="Turn camera on by default when joining meetings"
                    checked={prefs.defaultCameraOn}
                    onChange={v => setPrefs(p => ({ ...p, defaultCameraOn: v }))} />
                  <ToggleRow label="Microphone" desc="Turn microphone on by default when joining meetings"
                    checked={prefs.defaultMicOn}
                    onChange={v => setPrefs(p => ({ ...p, defaultMicOn: v }))} />
                  <ToggleRow label="Enable meeting password"
                    desc="Let hosts set a join password on each meeting. Recipients are asked for the password on the share-link prejoin page and Jitsi locks the room with it."
                    checked={prefs.enableMeetingPassword}
                    onChange={v => setPrefs(p => ({ ...p, enableMeetingPassword: v }))} />
                  <ToggleRow label="Require host to start meeting"
                    desc="Block share-link joiners until the host hits Start. They see a Zoom-style waiting page that auto-resumes the moment the meeting goes live."
                    checked={prefs.requireHostStart}
                    onChange={v => setPrefs(p => ({ ...p, requireHostStart: v }))} />
                  <ToggleRow label="Enable encrypted meeting URL"
                    desc="When on, share links use an opaque encrypted token (safer to share publicly, revocable by rotating the key). Turn off to share simple URLs like /oaticonnect/j/377401626 so recipients can read or type the meeting code directly."
                    checked={prefs.encryptedShareLink}
                    onChange={v => setPrefs(p => ({ ...p, encryptedShareLink: v }))} />
                  <ToggleRow label="Embed password in encrypted meeting link"
                    desc="Seal the meeting password into the encrypted token so recipients click the link and skip the password prompt. Only used with encrypted URLs; plain code URLs never carry secrets. Recommended when the password is shared out-of-band as a backup."
                    checked={prefs.embedPasswordInLink}
                    onChange={v => setPrefs(p => ({ ...p, embedPasswordInLink: v }))} />
                  {/* Numeric input — reuses ToggleRow's label/desc styling
                      so this row matches the rest of the panel; the
                      right-hand control is a number input instead of a
                      toggle slider. */}
                  <div className="settings-toggle-row">
                    <div>
                      <div className="settings-toggle-label">Recurring meeting max duration (days)</div>
                      <div className="settings-toggle-desc">
                        Hard ceiling on how far a recurring series may extend from its start date. Hides the "Never" end-condition in the Schedule form. Set to 0 to disable the cap (legacy behaviour).
                      </div>
                    </div>
                    <input
                      type="number"
                      min={0}
                      max={3650}
                      value={prefs.recurringMaxDurationDays}
                      onChange={e => setPrefs(p => ({ ...p, recurringMaxDurationDays: Math.max(0, parseInt(e.target.value || "0", 10)) }))}
                      className="input"
                      style={{ width: 100 }}
                    />
                  </div>
                  <div className="settings-toggle-row">
                    <div>
                      <div className="settings-toggle-label">Web client URL</div>
                      <div className="settings-toggle-desc">
                        Branded URL for the web join page printed in invitation emails + .ics files (recipients without the one-click link can paste this and type the meeting ID). Leave blank to use the host's own /oaticonnect/join.
                      </div>
                    </div>
                    <input
                      type="text"
                      placeholder="https://meet.example.com/join"
                      value={prefs.webClientUrl}
                      onChange={e => setPrefs(p => ({ ...p, webClientUrl: e.target.value }))}
                      className="input"
                      style={{ width: 280 }}
                    />
                  </div>
                </>
              )}

              {prefSubTab === "jitsi" && (
                <>
                  {JITSI_FLAGS.map(f => (
                    <ToggleRow key={f.key} label={f.label} desc={f.desc}
                      checked={Boolean(prefs[f.key])}
                      onChange={v => setPrefs(p => ({ ...p, [f.key]: v }) as MeetingPreferences)} />
                  ))}
                </>
              )}

              {prefSubTab === "toolbar" && (
                <>
                  <div className="prefs-bulk-actions">
                    <button type="button" className="settings-btn settings-btn-secondary"
                      onClick={() => setPrefs(p => ({ ...p, toolbarButtons: Object.fromEntries(TOOLBAR_BUTTONS.map(n => [n, true])) }))}>
                      Enable All
                    </button>
                    <button type="button" className="settings-btn settings-btn-secondary"
                      onClick={() => setPrefs(p => ({ ...p, toolbarButtons: Object.fromEntries(TOOLBAR_BUTTONS.map(n => [n, false])) }))}>
                      Disable All
                    </button>
                  </div>
                  <div className="toolbar-buttons-grid">
                    {TOOLBAR_BUTTONS.map(name => (
                      <ToggleRow key={name} label={name}
                        checked={prefs.toolbarButtons?.[name] ?? true}
                        onChange={v => setPrefs(p => ({ ...p, toolbarButtons: { ...(p.toolbarButtons ?? {}), [name]: v } }))} />
                    ))}
                  </div>
                </>
              )}

              <div className="settings-actions">
                <button type="button" className="settings-btn settings-btn-primary"
                  disabled={prefsSaving} onClick={savePrefs}>
                  {prefsSaving ? "Saving..." : "Save Preferences"}
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function ToggleRow({
  label, desc, checked, onChange,
}: {
  label: string;
  desc?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="settings-toggle-row">
      <div>
        <div className="settings-toggle-label">{label}</div>
        {desc && <div className="settings-toggle-desc">{desc}</div>}
      </div>
      <label className="toggle-switch">
        <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} />
        <span className="toggle-slider" />
      </label>
    </div>
  );
}
