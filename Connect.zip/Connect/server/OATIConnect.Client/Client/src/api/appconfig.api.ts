import { apiHost } from "./axios";

/**
 * Raw key-value rows from the universal `oaticonnect_AppConfigs` table.
 * Used by the admin "App Settings" tab to manage things like `App:Name`
 * and `Jitsi:ServerBaseUrl`. The typed meeting-preferences view lives in
 * `settings.api.ts`.
 */
export interface AppConfig {
  key: string;
  value: string;
  description: string | null;
  category: string;
}

export interface UpsertAppConfig {
  key: string;
  value: string;
  description: string | null;
  category: string;
}

// Use the /oaticonnect/* alias for parity with the meeting-prefs endpoint —
// webVision shadows generic /api/v1/* paths, so all our admin reads/writes
// go through the namespaced alias via apiHost (host-root baseURL). The
// legacy /api/v1/appconfig path still exists server-side for older clients.
export async function getAppConfigs(): Promise<AppConfig[]> {
  const res = await apiHost.get("/oaticonnect/appconfig");
  return Array.isArray(res.data) ? res.data : [];
}

export async function upsertAppConfig(data: UpsertAppConfig): Promise<AppConfig> {
  const res = await apiHost.post("/oaticonnect/appconfig", data);
  return res.data;
}
