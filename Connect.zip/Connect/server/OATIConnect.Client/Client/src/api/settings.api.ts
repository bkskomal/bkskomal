import { apiHost } from "./axios";

/**
 * Universal meeting preferences — stored as `Pref:*` rows in
 * `oaticonnect_AppConfigs`. Single global object (no per-user). The
 * server packs/unpacks these into a typed shape via `IAppSettingsService`.
 */
export interface MeetingPreferences {
  defaultCameraOn: boolean;
  defaultMicOn: boolean;
  defaultDurationMinutes: number;
  meetingNameMode: "auto" | "manual";

  /** When true, hosts can set a per-meeting join password and the
   *  share-link prejoin requires it. UI hides the password field when
   *  this is off. */
  enableMeetingPassword: boolean;
  /** When true, share-link joiners see a "waiting for host to start"
   *  page until the host hits Start. Auto-resumes once started. */
  requireHostStart: boolean;
  /** When true (default), share URLs carry an opaque encrypted token
   *  (/oaticonnect/j/{token}). When false, the URL embeds the plain
   *  meeting code (/oaticonnect/j/377401626) so recipients can read
   *  or type the code without copying the full URL. */
  encryptedShareLink: boolean;
  /** Only meaningful when encryptedShareLink is on. When true, the
   *  meeting password is sealed into the token so recipients click
   *  the link and skip the password prompt — one-click join. */
  embedPasswordInLink: boolean;
  /** Hard ceiling (days from series start) on how far a recurring
   *  meeting may extend. 0 = no cap (Schedule form keeps "Never"
   *  end-condition). Default 90. */
  recurringMaxDurationDays: number;
  /** Optional branded URL for the "join from the web" page printed
   *  in invitations. Empty = use the host's own /oaticonnect/join.
   *  Set when fronting OATIConnect behind a custom domain. */
  webClientUrl: string;

  // Jitsi configOverwrite flags
  disablePreJoinPage: boolean;
  audioOnly: boolean;
  startWithAudioMuted: boolean;
  startWithCameraOff: boolean;
  disableFaceCentering: boolean;
  disableTileEnlargement: boolean;
  skipMediaPermissions: boolean;
  disableNotifications: boolean;

  // Toolbar visibility — flat name -> visible map. Keys mirror the
  // Jitsi external-API toolbar identifiers (capitalized).
  toolbarButtons: Record<string, boolean>;
}

export function defaultMeetingPreferences(): MeetingPreferences {
  return {
    defaultCameraOn: true,
    defaultMicOn: true,
    defaultDurationMinutes: 60,
    meetingNameMode: "auto",
    enableMeetingPassword: true,
    requireHostStart: true,
    encryptedShareLink: true,
    embedPasswordInLink: true,
    recurringMaxDurationDays: 90,
    webClientUrl: "",
    disablePreJoinPage: false,
    audioOnly: false,
    startWithAudioMuted: false,
    startWithCameraOff: false,
    disableFaceCentering: false,
    disableTileEnlargement: false,
    skipMediaPermissions: false,
    disableNotifications: false,
    toolbarButtons: {},
  };
}

export async function getMeetingPreferences(): Promise<MeetingPreferences> {
  // /oaticonnect/settings is the host-safe alias — webVision exposes its own
  // /api/v1/settings GET-only endpoint that swallows ours, so we use the
  // namespaced path (no /api/v1 prefix) via the apiHost instance.
  const res = await apiHost.get("/oaticonnect/settings");
  const data = res.data;
  // The endpoint returns either a MeetingPreferencesDto or a Result envelope
  // (`{ isSuccess: false, errorCode: "UNAUTHORIZED" }`) when the auth filter
  // rejects the call. Detect the envelope shape and fall back to defaults so
  // the Settings page can still render.
  if (!data || typeof data !== "object" || !("toolbarButtons" in data)) {
    return { ...defaultMeetingPreferences(), ...(data && typeof data === "object" ? {} : {}) };
  }
  const prefs = data as MeetingPreferences;
  if (!prefs.toolbarButtons || typeof prefs.toolbarButtons !== "object") {
    prefs.toolbarButtons = {};
  }
  return prefs;
}

export async function saveMeetingPreferences(prefs: MeetingPreferences): Promise<void> {
  await apiHost.post("/oaticonnect/settings", prefs);
}
