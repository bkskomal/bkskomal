import api from "./axios";

/**
 * Phase-1 Exchange/Outlook integration API. Only `getStatus` and
 * `testConnection` exist for now; `search()` and resolve flows land
 * with Phase 2 once the Microsoft Graph client is wired up.
 *
 * `getStatus().enabled` is the toggle that gates UI elements like the
 * meeting invite multi-select — call it once on mount, hide the field
 * if false.
 */

export interface ExchangeStatus {
  enabled: boolean;
}

export interface ExchangeTestResult {
  success: boolean;
  message: string;
}

export interface ExchangeDirectoryItem {
  id: string;
  kind: "group" | "user" | "contact";
  name: string;
  email: string | null;
}

export async function getExchangeStatus(): Promise<ExchangeStatus> {
  const res = await api.get("/exchange/status");
  return { enabled: !!res.data?.enabled };
}

export async function testExchangeConnection(): Promise<ExchangeTestResult> {
  const res = await api.post("/exchange/test");
  // Server returns either { success, message } directly, or a
  // Result.Failure envelope (FORBIDDEN/UNAUTHORIZED). The axios
  // interceptor strips the envelope so res.data is the inner object.
  return res.data as ExchangeTestResult;
}

/** Typeahead search — returns groups + users matching the query. */
export async function searchExchange(query: string): Promise<ExchangeDirectoryItem[]> {
  const q = (query ?? "").trim();
  if (q.length < 2) return [];
  const res = await api.get(`/exchange/search?q=${encodeURIComponent(q)}`);
  return Array.isArray(res.data) ? res.data : [];
}
