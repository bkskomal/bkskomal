﻿import { apiHost } from "./axios";

/**
 * Server-resolved current user â€” same payload the host adapter built
 * via `OATIMeetSessionAdapter.GetCurrentUserAsync()`. The `role` field
 * comes from the adapter's `MapRole()` (which probes
 * `UserManagerRepository.RetrieveUserPermissions().IsAdmin`), so the
 * client always sees exactly what server-side gates see â€” no separate
 * JS-level admin check that could drift if MapRole tightens.
 */
export interface MeResponse {
  id: number;
  name: string;
  email: string;
  role: string;
  isAdmin: boolean;
  isAuthenticated: boolean;
  /** Windows time zone id as stored by the host framework (e.g. "Central Standard Time"). */
  timeZone: string;
  /** IANA form of the same zone (e.g. "America/Chicago") — preferred by `Intl.DateTimeFormat`. */
  timeZoneIana: string;
}

/** Goes through the `/oaticonnect/*` alias prefix (apiHost) so it
 *  bypasses the host's `/api/v1` route filter. */
export async function getMe(): Promise<MeResponse | null> {
  try {
    const res = await apiHost.get("/oaticonnect/me");
    const data = res.data as MeResponse | undefined;
    if (!data || typeof data !== "object" || !("isAuthenticated" in data)) return null;
    return data;
  } catch {
    return null;
  }
}

