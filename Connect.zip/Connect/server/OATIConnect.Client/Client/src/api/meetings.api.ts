import api, { apiHost } from "./axios";

/**
 * Server's MeetingListItemDto. Field names follow the C# DTO 1:1 — the
 * global axios interceptor strips the Result envelope and camelizes keys
 * so the React side always sees this shape regardless of host serializer.
 */
export interface Meeting {
  meetingId: string;
  meetingCode: string;
  title: string;
  description?: string | null;
  scheduledTimeUtc: string;
  status: "Scheduled" | "Ready" | "Active" | "Ended" | "Archived" | "Expired";
  isHost: boolean;
  durationMinutes: number;
  /** Invitee emails — populated only for the host's view of the meeting. */
  inviteeEmails?: string[];
  /** True when this meeting requires a password to join. Sent to all
   *  callers (host + invitees) so the dashboard can show a 🔒 hint
   *  without leaking the password itself. */
  passwordRequired?: boolean;
  /** Plaintext join password — host's view only. Lets the edit modal
   *  pre-fill the existing value and the share-via-email helper drop
   *  it into the message. Always undefined for non-host callers. */
  password?: string | null;
  /** Per-meeting "host must start first" flag. When true, joiners are
   *  blocked until the host hits Start. Visible to everyone so the
   *  dashboard can show a wait state on Scheduled meetings. */
  requireHostStart?: boolean;

  /** Recurrence — surfaced to everyone so the row can show a badge. */
  recurrenceType?: number;            // 0=None, 1=Daily, 2=Weekly, 3=Monthly
  recurrenceInterval?: number;        // 1 = every period, 2 = every other, etc.
  recurrenceDaysOfWeekMask?: number;  // weekly: Sun=1 Mon=2 Tue=4 Wed=8 Thu=16 Fri=32 Sat=64
  recurrenceEndType?: number;         // 0=Never, 1=After N, 2=OnDate
  recurrenceEndCount?: number | null;
  recurrenceEndDateUtc?: string | null;
  /** Next upcoming occurrence (UTC) — computed server-side, skipping any
   *  cancelled occurrences for the series. Null when series has ended. */
  nextOccurrenceUtc?: string | null;
}

export interface CreateMeeting {
  title: string;
  /** Optional client-supplied 10-digit Meeting ID for Zoom-style
   *  pre-display in the schedule modal. Server uses it directly when
   *  supplied; otherwise generates a fresh one. */
  meetingCode?: string;
  /** Client browser timezone (Intl.DateTimeFormat
   *  resolvedOptions().timeZone). Used as a fallback for time
   *  formatting in the email body + .ics when the host's stored
   *  profile zone is empty or unrecognised. */
  clientTimeZone?: string;
  description?: string | null;
  scheduledTimeUtc: string;
  durationMinutes: number;
  /** Microsoft Graph object ids (groups + users) chosen from the invite picker. */
  inviteeIds?: string[];
  /** Free-typed email addresses (no Graph lookup). */
  inviteeEmails?: string[];
  /** Optional join password. Server ignores when the global
   *  enable-password preference is off. */
  password?: string | null;
  /** Per-meeting host-start gate. Server forces false when the global
   *  RequireHostStart preference is off. */
  requireHostStart?: boolean;

  /** Recurrence pattern + end condition. Send all fields (server treats
   *  null fields as "leave alone" for updates; for create the server
   *  defaults missing values to None / 1 / 0 / Never). */
  recurrenceType?: number;
  recurrenceInterval?: number;
  recurrenceDaysOfWeekMask?: number;
  recurrenceEndType?: number;
  recurrenceEndCount?: number | null;
  recurrenceEndDateUtc?: string | null;
}

export interface UpdateMeeting extends CreateMeeting {}

export interface MeetingCreated {
  meetingId: string;
  meetingCode: string;
  roomName: string;
  scheduledTimeUtc: string;
}

export interface MeetingStatus {
  exists: boolean;
  isActive: boolean;
  /** True only after the host-start grace window has expired (host has
   *  had ~5s to acquire Jitsi moderator before any visitor lands).
   *  Waiting pages should resume on this flag, not bare `isActive`. */
  joinReady?: boolean;
  roomName?: string;
  status: string;
}

export async function listMeetings(): Promise<Meeting[]> {
  const res = await api.get("/meetings");
  return Array.isArray(res.data) ? res.data : [];
}

export async function createMeeting(data: CreateMeeting): Promise<MeetingCreated> {
  const res = await api.post("/meetings", data);
  return res.data;
}

export async function updateMeeting(id: string, data: UpdateMeeting): Promise<void> {
  await api.put(`/meetings/${id}`, data);
}

export async function deleteMeeting(id: string): Promise<void> {
  await api.delete(`/meetings/${id}`);
}

/** Cancels a single occurrence of a recurring meeting series. Pass the
 *  occurrence's original (computed) start time — the server adds a
 *  Cancelled exception row that filters that one slot out of future
 *  enumeration. The series itself, including the room name, share
 *  link, and password, is unaffected. Host-only. */
export async function cancelOccurrence(meetingId: string, occurrenceStartUtc: string): Promise<void> {
  await api.post(`/meetings/${meetingId}/occurrences/cancel`, { occurrenceStartUtc });
}

export async function startMeeting(id: string): Promise<void> {
  await api.post(`/meetings/${id}/start`);
}

export async function getMeetingStatus(roomName: string): Promise<MeetingStatus> {
  const res = await api.get(`/meetings/status/${encodeURIComponent(roomName)}`);
  return res.data;
}

/** Response shape from POST /api/v1/meetings/join-by-code. The endpoint
 *  serves both the anonymous public join page and the authenticated
 *  in-app Join Meeting modal — it validates the password (when one is
 *  set), checks the host-start gate, and returns either an error code
 *  or the Jitsi join data. The in-app modal only uses this to validate
 *  the password up-front; the popup that actually boots Jitsi runs
 *  under the user's host session, not this guest join. */
export interface JoinByCodeResult {
  ok: boolean;
  code?: string | null;
  error?: string | null;
  roomName?: string | null;
}

export async function validateJoinByCode(
  meetingCode: string,
  displayName: string,
  password: string | null,
): Promise<JoinByCodeResult> {
  // Use apiHost so the request lands at /api/v1/... under the host's
  // basepath (matches the join-by-code page's BASE_PATH pattern).
  const res = await apiHost.post("/api/v1/meetings/join-by-code", {
    meetingCode,
    displayName,
    password,
  });
  // The host may serialise either camelCase (our standalone dev host)
  // or PascalCase (typical integrated main app). Normalise both.
  const raw = res.data || {};
  return {
    ok:       (raw.ok === true) || (raw.Ok === true),
    code:     raw.code     ?? raw.Code     ?? null,
    error:    raw.error    ?? raw.Error    ?? null,
    roomName: raw.roomName ?? raw.RoomName ?? null,
  };
}

export interface Participant {
  id: string;
  userId: number;
  name: string;
  email: string;
  joinedAtUtc: string;
}

/** Lists everyone who joined the meeting (one row per join). Host-only —
 *  the server enforces this at the service layer; non-host callers get
 *  an empty list and a `FORBIDDEN` errorCode in the envelope. Uses the
 *  `/oaticonnect/...` alias via apiHost because some host pipelines
 *  (webVision) shadow nested routes under `/api/v1/meetings/{id}/{action}`
 *  and return 404. */
export async function listParticipants(meetingId: string): Promise<Participant[]> {
  const res = await apiHost.get(`/oaticonnect/meetings/${meetingId}/participants`);
  return Array.isArray(res.data) ? res.data : [];
}

/**
 * Returns the encrypted, click-to-join URL for the meeting — same link
 * the server bakes into invite emails / .ics files. Host-only; the
 * server returns 403 to anyone except the meeting's owner. The UI uses
 * the URL to copy-to-clipboard or open the meeting in a popup window
 * for guests (e.g. an external attendee on the host's machine).
 */
export interface ShareLink { url: string; token: string; }
export async function getMeetingShareLink(meetingId: string): Promise<ShareLink> {
  const res = await api.get(`/meetings/${meetingId}/share-link`);
  return res.data;
}
