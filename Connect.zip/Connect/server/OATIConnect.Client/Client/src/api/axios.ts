import axios, { type AxiosInstance } from "axios";
import { getBasePath } from "../config/basePath";

/**
 * Shared axios instance used by every API helper.
 *
 * <p>Two pieces of cross-cutting behaviour live here:</p>
 *   <ul>
 *     <li>Cookie credentials always flow with the request — auth is owned
 *       by the host (webVision), so the browser-managed session cookie is
 *       what proves identity to the server.</li>
 *     <li>A response interceptor strips the .NET <c>Result&lt;T&gt;</c>
 *       envelope and camelizes keys, so every caller sees a consistent
 *       camelCase payload regardless of how the host's JSON serializer is
 *       configured (webVision emits PascalCase by default).</li>
 *   </ul>
 */

function getApiBaseUrl(): string {
	return `${getBasePath()}/api/v1`;
}

/** Host-root base — used by helpers that talk to <c>/oaticonnect/*</c>
 *  endpoints which deliberately bypass the <c>/api/v1</c> prefix that
 *  webVision intercepts. Pairs with <c>OATIConnectAliasController</c>. */
function getHostBaseUrl(): string {
	return getBasePath();
}

const api = axios.create({
	baseURL: getApiBaseUrl(),
	headers: { "Content-Type": "application/json" },
	withCredentials: true,
});

export const apiHost: AxiosInstance = axios.create({
	baseURL: getHostBaseUrl(),
	headers: { "Content-Type": "application/json" },
	withCredentials: true,
});

/** Recursively lower-case the first letter of every plain-object key.
 *  Idempotent — already-camelCase keys are unchanged. Leaves arrays of
 *  primitives, Blob/FormData, and class instances alone. */
function camelizeKeys(value: any): any {
	if (Array.isArray(value)) return value.map(camelizeKeys);
	if (value && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
		const out: Record<string, any> = {};
		for (const k of Object.keys(value)) {
			const ck = k.charAt(0).toLowerCase() + k.slice(1);
			out[ck] = camelizeKeys(value[k]);
		}
		return out;
	}
	return value;
}

/** webVision returns HTTP 200 with body `{Message, UserName, IsAuthenticate, Code}`
 *  when its session has timed out — without recognizing this shape the
 *  response looks like a success and callers crash with "X is undefined"
 *  deep in the UI. Detect it and convert to a rejected promise so the UI
 *  can show a clean "session expired" message. */
function isHostAuthDeniedBody(body: any): boolean {
	if (!body || typeof body !== "object" || Array.isArray(body)) return false;
	const hasMessage  = "Message"        in body || "message"        in body;
	const hasUserName = "UserName"       in body || "userName"       in body;
	const hasIsAuth   = "IsAuthenticate" in body || "isAuthenticate" in body;
	if (!(hasMessage && hasUserName && hasIsAuth)) return false;
	const msg = String(body.Message || body.message || "").toLowerCase();
	return msg.includes("authorization") && msg.includes("denied");
}

function installResponseInterceptor(instance: AxiosInstance) {
	instance.interceptors.response.use(
		response => {
			try {
				const body = response.data;
				if (isHostAuthDeniedBody(body)) {
					const e: any = new Error("Host session expired — please refresh the page and sign in again.");
					e.isHostAuthDenied = true;
					e.response = response;
					return Promise.reject(e);
				}
				if (body && typeof body === "object" && !Array.isArray(body)) {
					if ("Data" in body && "IsSuccess" in body)        response.data = camelizeKeys((body as any).Data);
					else if ("data" in body && "isSuccess" in body)   response.data = camelizeKeys((body as any).data);
					else                                              response.data = camelizeKeys(body);
				} else {
					response.data = camelizeKeys(body);
				}
			} catch {
				// Anything goes wrong: leave the response untouched. Better to
				// render with PascalCase than to drop the response entirely.
			}
			return response;
		},
		error => Promise.reject(error)
	);
}

installResponseInterceptor(api);
installResponseInterceptor(apiHost);

export default api;
