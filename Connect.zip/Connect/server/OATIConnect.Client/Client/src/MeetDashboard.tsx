﻿import { useState, useEffect } from "react";
import { MeetConfigProvider, type MeetConfig, useMeetConfig } from "./contexts/MeetConfigContext";
import { UserProvider, useUser } from "./contexts/UserContext";
import { getAppName, getShowClock, getShowThemeToggle, getDefaultTheme } from "./config/env";
import { ToastProvider } from "./components/Toast";
import Home from "./pages/Home";
import Settings from "./pages/Settings";
import MeetingParticipants from "./pages/MeetingParticipants";
import type { Meeting } from "./api/meetings.api";
import "./layouts/AppLayout.css";

interface Props {
  config: MeetConfig;
}

type EmbeddedTab = "home" | "settings";

function ThemeToggle({ theme, onToggle }: { theme: "dark" | "light"; onToggle: () => void }) {
  return (
    <button
      className="nav-tab-btn"
      onClick={onToggle}
      title={theme === "dark" ? "Switch to Light mode" : "Switch to Dark mode"}
      style={{ display: "flex", alignItems: "center", gap: 6 }}
    >
      {theme === "dark" ? (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="5" /><line x1="12" y1="1" x2="12" y2="3" /><line x1="12" y1="21" x2="12" y2="23" /><line x1="4.22" y1="4.22" x2="5.64" y2="5.64" /><line x1="18.36" y1="18.36" x2="19.78" y2="19.78" /><line x1="1" y1="12" x2="3" y2="12" /><line x1="21" y1="12" x2="23" y2="12" /><line x1="4.22" y1="19.78" x2="5.64" y2="18.36" /><line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
        </svg>
      ) : (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
        </svg>
      )}
    </button>
  );
}

/** Live ticking clock for the embedded header. Big-display 12-hour format
 *  with AM/PM, a blinking colon, animated tabular digits, a circular
 *  seconds progress ring, and a subtle gradient pill. Ticks every second,
 *  aligned to wall-clock boundaries so the digits change exactly on the
 *  second mark. */
function HeaderClock({ timeZone }: { timeZone?: string }) {
  // Resolve once per render. When timeZone is empty/invalid, fall back to
  // the browser''s zone (behaviour identical to before this prop existed).
  const tz = (timeZone && timeZone.trim()) ? timeZone.trim() : undefined;
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    // Align the first tick to the next second boundary so updates land at
    // wall-clock :01.000, :02.000 ... rather than drifting by however long
    // the component took to mount. Then tick every second.
    const msToNext = 1000 - (Date.now() % 1000);
    let interval: ReturnType<typeof setInterval> | null = null;
    const initial = setTimeout(() => {
      setNow(new Date());
      interval = setInterval(() => setNow(new Date()), 1000);
    }, msToNext);
    return () => { clearTimeout(initial); if (interval) clearInterval(interval); };
  }, []);

  
  // All derivations go through Intl.DateTimeFormat with the user''s TZ so
  // the clock reflects wall-clock time in their zone (Central, Pacific,
  // India, …) rather than the browser''s zone. Falls back to the browser
  // zone when tz is undefined or unknown.
  const safeFormat = (opts: Intl.DateTimeFormatOptions) => {
    try { return new Intl.DateTimeFormat(undefined, { ...opts, timeZone: tz }).format(now); }
    catch { return new Intl.DateTimeFormat(undefined, opts).format(now); }
  };
  const safeParts = (opts: Intl.DateTimeFormatOptions) => {
    try { return new Intl.DateTimeFormat(undefined, { ...opts, timeZone: tz, hour12: true }).formatToParts(now); }
    catch { return new Intl.DateTimeFormat(undefined, { ...opts, hour12: true }).formatToParts(now); }
  };
  const timeParts = safeParts({ hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const pick = (type: string) => timeParts.find(p => p.type === type)?.value ?? "";
  const hh     = pick("hour").padStart(2, "0");
  const mm     = pick("minute").padStart(2, "0");
  const ssText = pick("second").padStart(2, "0");
  const ampm   = pick("dayPeriod").toUpperCase() || "AM";
  const ss     = Number(ssText) || 0;
  const day    = safeFormat({ weekday: "short" });
  const date   = safeFormat({ month: "short", day: "numeric" });
  // Short timezone name (e.g. "CDT", "CST", "GMT+5:30") — Intl handles the
  // DST-aware abbreviation. Empty when the runtime can't resolve a short
  // name for the zone (rare); the UI hides the chip in that case.
  const tzParts = safeParts({ hour: "2-digit", timeZoneName: "short" });
  const tzAbbr  = tzParts.find(p => p.type === "timeZoneName")?.value ?? "";
  const colonLit = ss % 2 === 0;

  // Seconds progress arc â€” circumference = 2Ï€r with r=12 inside a 30px box.
  // dashOffset shrinks from full circumference (start of minute) toward 0
  // (end of minute) so the arc sweeps clockwise like a second hand.
  const SR    = 12;
  const CIRC  = 2 * Math.PI * SR;
  const arcOffset = CIRC * (1 - ss / 60);

  return (
    <div className="header-clock" title={now.toLocaleString()}>
      {/* Day + date column lives at the start; the time + seconds ring
          follow on the right so the eye sweeps Day â†’ Time naturally. */}
      <div className="hc-date">
        <span className="hc-date-day">{day}</span>
        <span className="hc-date-sub">{date}</span>
      </div>

      <div className="hc-divider" aria-hidden />

      <span className="header-clock-time">
        <span className="hc-digits" key={`h-${hh}`}>{hh}</span>
        <span className={`hc-colon ${colonLit ? "hc-colon-lit" : ""}`}>:</span>
        <span className="hc-digits" key={`m-${mm}`}>{mm}</span>
        {/* AM/PM badge with the short timezone name stacked underneath
            (e.g. "PM" / "CDT") so the user always knows which zone the
            displayed time belongs to. The tz line auto-flips between
            standard and daylight (CST <-> CDT) as DST transitions. */}
        <span className="hc-meridiem">
          <span className="hc-ampm">{ampm}</span>
          {tzAbbr && <span className="hc-tz" title={tz || "browser default"}>{tzAbbr}</span>}
        </span>
      </span>

      {/* Seconds-as-ring: the digits live INSIDE the circle and the
          gradient arc around them sweeps once per minute. */}
      <div className="hc-second-ring" aria-hidden>
        <svg className="hc-ring" viewBox="0 0 30 30" width="30" height="30">
          <defs>
            <linearGradient id="hc-arc-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%"  stopColor="#2563eb" />
              <stop offset="100%" stopColor="#7c3aed" />
            </linearGradient>
          </defs>
          <circle className="hc-ring-track" cx="15" cy="15" r={SR} />
          <circle className="hc-ring-progress" cx="15" cy="15" r={SR}
            strokeDasharray={CIRC.toFixed(2)}
            strokeDashoffset={arcOffset.toFixed(2)} />
        </svg>
        <span className="hc-second-text" key={`s-${ssText}`}>{ssText}</span>
      </div>
    </div>
  );
}

function EmbeddedLayout() {
  const { user, loading: userLoading } = useUser();
  const config = useMeetConfig();

  // Header display prefs from /api/v1/config. Held in state so the
  // dashboard re-renders the moment an admin saves new values from the
  // Settings page â€” a `oaticonnect-config-updated` window event is the
  // signal (dispatched by Settings.saveHeader after refreshAppConfig).
  const [showClock, setShowClock]               = useState<boolean>(() => { try { return getShowClock(); }       catch { return false; } });
  const [showThemeToggle, setShowThemeToggle]   = useState<boolean>(() => { try { return getShowThemeToggle(); } catch { return true;  } });
  const [defaultTheme, setDefaultTheme]         = useState<"light" | "dark" | "system">(
    () => { try { return getDefaultTheme(); } catch { return "system"; } }
  );

  useEffect(() => {
    const handler = () => {
      try { setShowClock(getShowClock()); } catch {}
      try { setShowThemeToggle(getShowThemeToggle()); } catch {}
      try { setDefaultTheme(getDefaultTheme()); } catch {}
    };
    window.addEventListener("oaticonnect-config-updated", handler);
    return () => window.removeEventListener("oaticonnect-config-updated", handler);
  }, []);

  /**
   * Resolve the initial theme:
   *   1. Per-user override from localStorage wins (so toggling persists).
   *   2. Otherwise honor the admin-configured default.
   *   3. "system" follows the OS / web-component-host preference.
   * The web-component prop `config.theme` from the host page is treated as
   * a fallback, not an override â€” admin App Settings + user toggle take
   * priority because they're more recent / user-specific signals.
   */
  function resolveInitialTheme(): "dark" | "light" {
    const stored = (typeof localStorage !== "undefined") ? localStorage.getItem("oaticonnect-theme") : null;
    if (stored === "dark" || stored === "light") return stored;
    if (defaultTheme === "light" || defaultTheme === "dark") return defaultTheme;
    if (typeof window !== "undefined" && typeof window.matchMedia === "function") {
      return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    return config.theme || "light";
  }

  const [activeTab, setActiveTab] = useState<EmbeddedTab>("home");
  const [theme, setTheme] = useState<"dark" | "light">(resolveInitialTheme);

  // When set, the dashboard swaps Home for the per-meeting participants
  // page. Acts like a sub-route under the Home tab â€” switching tabs (e.g.
  // clicking the Settings icon) clears it.
  const [participantsFor, setParticipantsFor] = useState<Meeting | null>(null);

  const role    = user?.role || "Standard";
  const isAdmin = !userLoading && role === "Admin";

  let appName = "OATIConnect";
  try { appName = getAppName(); } catch {}

  // Apply theme to the shadow root container
  useEffect(() => {
    // Find the shadow root's mount point and set data-theme
    const el = document.querySelector("oaticonnect-meet")?.shadowRoot?.getElementById("oaticonnect-root");
    if (el) el.setAttribute("data-theme", theme);
    // Also try setting on parent .app-shell
    localStorage.setItem("oaticonnect-theme", theme);
  }, [theme]);

  // When defaultTheme is "system" and no user override is stored, follow
  // OS-level changes live (toggle the OS dark mode and the app reacts).
  useEffect(() => {
    if (defaultTheme !== "system") return;
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
    const stored = localStorage.getItem("oaticonnect-theme");
    if (stored === "dark" || stored === "light") return; // user override wins
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e: MediaQueryListEvent) => setTheme(e.matches ? "dark" : "light");
    mq.addEventListener?.("change", handler);
    return () => mq.removeEventListener?.("change", handler);
  }, [defaultTheme]);

  const toggleTheme = () => setTheme(prev => prev === "dark" ? "light" : "dark");

  return (
    <div className="app-shell" data-theme={theme}>
      <div className="header-wrapper">
        <header className="app-header header-centered">
          <div className="header-left">
            <span className="logo">{appName}</span>
          </div>

          <nav className="header-nav header-nav-icons">
            <button
              className={`nav-icon-btn ${activeTab === "home" && !participantsFor ? "active" : ""}`}
              onClick={() => { setActiveTab("home"); setParticipantsFor(null); }}
              title="Home"
              aria-label="Home"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 12 12 3l9 9" />
                <path d="M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10" />
              </svg>
            </button>
            {/* Participants tab â€” only rendered while the dashboard is showing
                the per-meeting participants page. Returning to Home (clicking
                the Home icon, or the Back button on the participants page)
                clears `participantsFor` and this button disappears again. */}
            {participantsFor && activeTab === "home" && (
              <button
                className="nav-icon-btn active"
                onClick={() => { /* already on participants page */ }}
                title={`Participants â€” ${participantsFor.title}`}
                aria-label="Participants"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </button>
            )}
            {isAdmin && (
              <button
                className={`nav-icon-btn ${activeTab === "settings" ? "active" : ""}`}
                onClick={() => { setActiveTab("settings"); setParticipantsFor(null); }}
                title="Settings"
                aria-label="Settings"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3" />
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.01a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.01a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
              </button>
            )}
          </nav>

        <div className="header-right" style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {showClock       && <HeaderClock timeZone={user?.timeZone} />}
          {showThemeToggle && <ThemeToggle theme={theme} onToggle={toggleTheme} />}
        </div>
        </header>
      </div>

      <main className="app-content">
        {activeTab === "home" && (
          participantsFor
            ? <MeetingParticipants
                meeting={participantsFor}
                onClose={() => setParticipantsFor(null)} />
            : <Home onViewParticipants={setParticipantsFor} />
        )}
        {activeTab === "settings" && isAdmin && <Settings />}
      </main>
    </div>
  );
}

export default function MeetDashboard({ config }: Props) {
  return (
    <MeetConfigProvider config={config}>
      <UserProvider>
        <ToastProvider>
          <EmbeddedLayout />
        </ToastProvider>
      </UserProvider>
    </MeetConfigProvider>
  );
}





