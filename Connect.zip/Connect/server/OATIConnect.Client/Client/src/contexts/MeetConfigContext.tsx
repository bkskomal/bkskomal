import { createContext, useContext, type ReactNode } from "react";

/**
 * Runtime configuration for the embedded meet bundle. Hydrated by
 * `web-component.tsx` from the host's `<oaticonnect-meet>` element
 * attributes (or used directly in standalone dev mode).
 */
export interface MeetConfig {
  apiBase: string;
  user: {
    /** Host's native int identity (e.g. webVision UserId). */
    id: number;
    name: string;
    email: string;
    role: string;
  } | null;
  theme: "dark" | "light";
}

const MeetConfigContext = createContext<MeetConfig | null>(null);

export function MeetConfigProvider({ config, children }: { config: MeetConfig; children: ReactNode }) {
  return <MeetConfigContext.Provider value={config}>{children}</MeetConfigContext.Provider>;
}

export function useMeetConfig(): MeetConfig {
  const ctx = useContext(MeetConfigContext);
  if (!ctx) throw new Error("useMeetConfig must be used within MeetConfigProvider");
  return ctx;
}

// Safe variant — returns null when not inside MeetConfigProvider (standalone dev).
export function useOptionalMeetConfig(): MeetConfig | null {
  return useContext(MeetConfigContext) ?? null;
}
