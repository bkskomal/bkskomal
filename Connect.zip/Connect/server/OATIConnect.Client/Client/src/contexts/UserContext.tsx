﻿import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";
import { useOptionalMeetConfig } from "./MeetConfigContext";
import {
  getMeetingPreferences,
  type MeetingPreferences,
} from "../api/settings.api";
import { getMe } from "../api/me.api";

/**
 * Effective user info for the embedded bundle. The identity itself comes
 * from the host (web component attributes), but the **role is always read
 * from the server** via <c>/oaticonnect/me</c>, which runs the same
 * <c>OATIMeetSessionAdapter.MapRole()</c> the server-side gates use.
 *
 * Result: any tightening of MapRole on the server (extra privilege checks,
 * IsAdmin shape changes, â€¦) automatically narrows the client UI too â€” the
 * React side never makes its own admin decision in JS.
 */
interface UserInfo {
  id: number;
  name: string;
  email: string;
  role: string;
  /** IANA id preferred ("America/Chicago"); empty string → fall back to browser zone. */
  timeZone: string;
}

interface UserContextValue {
  user: UserInfo | null;
  preferences: MeetingPreferences | null;
  loading: boolean;
  refreshPreferences: () => Promise<void>;
}

const UserContext = createContext<UserContextValue | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const meetConfig = useOptionalMeetConfig();
  const injected   = meetConfig?.user ?? null;

  // First-paint placeholder. We render the injected attributes immediately
  // so the dashboard isn't blank during the /oaticonnect/me round-trip,
  // but the role here is just whatever the host page passed â€” the fetch
  // below overwrites it with the authoritative server value, and any role-
  // gated UI that misrenders for a fraction of a second self-corrects.
  const [user, setUser] = useState<UserInfo | null>(injected ? {
    id:    injected.id,
    name:  injected.name,
    email: injected.email,
    role:  injected.role || "Standard",
    timeZone: "",
  } : null);

  const [preferences, setPreferences] = useState<MeetingPreferences | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshPreferences = useCallback(async () => {
    try {
      setPreferences(await getMeetingPreferences());
    } catch (e) {
      // eslint-disable-next-line no-console
      console.warn("[UserContext] /settings load failed:", e);
      setPreferences(null);
    }
  }, []);

  // Re-resolve identity when the injected user changes (host re-mounts,
  // login swap, etc.). We unconditionally fetch /oaticonnect/me so the
  // client mirrors whatever role MapRole() decided server-side; the
  // injected attribute is only the first-paint hint.
  useEffect(() => {
    if (!injected) {
      setUser(null);
      setLoading(false);
      return;
    }

    let cancelled = false;
    (async () => {
      const me = await getMe();
      if (cancelled) return;

      // /oaticonnect/me may return a synthetic anonymous payload when the
      // host has no logged-in user; in that case keep the injected hint
      // rather than blanking the role.
      const role = (me?.isAuthenticated && me.role) ? me.role : (injected.role || "Standard");
      const rawTimeZone = (me?.isAuthenticated ? (me.timeZoneIana || me.timeZone) : "") || "";
      // Sanitise at the boundary — host apps sometimes return legacy
      // abbreviations like "CPT" in user.timeZone which Linux Node /
      // Chromium reject with RangeError when fed to Intl.DateTimeFormat.
      // Validating once here means every downstream consumer can trust
      // user.timeZone is either a known IANA zone or empty string.
      let timeZone = "";
      if (rawTimeZone) {
        try {
          new Intl.DateTimeFormat("en-CA", { timeZone: rawTimeZone });
          timeZone = rawTimeZone;
        } catch {
          console.warn(`[UserContext] dropping unrecognised time zone "${rawTimeZone}" — falling back to browser-local rendering.`);
        }
      }

      setUser({
        id:       me?.isAuthenticated ? me.id    : injected.id,
        name:     me?.isAuthenticated ? me.name  : injected.name,
        email:    me?.isAuthenticated ? me.email : injected.email,
        role,
        timeZone,
      });

      await refreshPreferences();
      setLoading(false);
    })();

    return () => { cancelled = true; };
  }, [injected?.id, refreshPreferences]);

  return (
    <UserContext.Provider value={{ user, preferences, loading, refreshPreferences }}>
      {children}
    </UserContext.Provider>
  );
}

const EMPTY_USER_CTX: UserContextValue = {
  user: null,
  preferences: null,
  loading: true,
  refreshPreferences: async () => {},
};

export function useUser(): UserContextValue {
  const ctx = useContext(UserContext);
  if (!ctx) {
    if (import.meta.env.DEV) {
      // eslint-disable-next-line no-console
      console.warn("useUser() called outside UserProvider â€” returning empty defaults.");
    }
    return EMPTY_USER_CTX;
  }
  return ctx;
}

export function useOptionalUser(): UserContextValue | null {
  return useContext(UserContext) ?? null;
}

