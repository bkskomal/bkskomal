import { loadJitsiScript } from "./loadJitsi";
import { getBasePath } from "../config/basePath";

/**
 * Opens the Jitsi meeting popup. The popup is served by MeetingPopupController
 * at /oaticonnect/room/{name}; that controller now performs the Jitsi join
 * server-side during the GET render and embeds the JWT/serverUrl/roomName
 * inline in the HTML. The popup itself makes ZERO authenticated API calls,
 * so it isn't blocked by host-level auth filters (e.g. webVision's global
 * /api/* and /oaticonnect POST handler).
 */
export async function openMeetingWindow(roomName: string) {
  const basePath = getBasePath();

  try {
    await loadJitsiScript();
  } catch (e) {
    console.error("Failed to preload Jitsi", e);
  }

  const url = `${window.location.origin}${basePath}/oaticonnect/room/${encodeURIComponent(roomName)}`;

  window.open(
    url,
    "meetingWindow",
    "width=1400,height=900,resizable=yes"
  );
}
