﻿import { useOptionalUser } from "../contexts/UserContext";

// Thin wrapper around Intl.DateTimeFormat that honours the current user time
// zone served by /oaticonnect/me. When no user zone is available the helpers
// quietly fall back to the browser zone, matching the original behaviour.

// Cache of "is this IANA zone recognised by the host's runtime" lookups.
// Linux runtimes use tzdata which rejects legacy/Windows abbreviations like
// "CPT", while Windows JS engines silently accept those — host apps can
// therefore feed us strings that work in dev but throw on prod. Validating
// once per zone keeps the format helpers crash-free under either platform.
const _tzValidCache: Record<string, boolean> = {};

function isValidIanaZone(iana: string): boolean {
  if (!iana) return false;
  const cached = _tzValidCache[iana];
  if (cached !== undefined) return cached;
  try {
    // Constructor throws synchronously on an unrecognised time zone.
    new Intl.DateTimeFormat("en-CA", { timeZone: iana });
    _tzValidCache[iana] = true;
    return true;
  } catch {
    _tzValidCache[iana] = false;
    return false;
  }
}

/**
 * Returns the input IANA zone if the host runtime recognises it, otherwise
 * returns undefined so callers fall back to browser-local rendering.
 *
 * Why: on Linux Node/Chromium, Intl.DateTimeFormat throws RangeError
 * ("Invalid time zone specified: CPT") when given a zone tzdata doesn't
 * know — this used to crash the schedule modal and the share-via-email
 * helper on Linux deployments where the host stores custom abbreviations
 * in the user's timeZone field.
 */
export function safeTimeZone(iana: string | undefined | null): string | undefined {
  if (!iana) return undefined;
  return isValidIanaZone(iana) ? iana : undefined;
}

// Pulls year/month/day/hour/minute/second from a Date as it would render in
// the supplied IANA zone. Used by the picker helpers below to bridge between
// JS Date (which is permanently glued to the browser's local zone) and the
// user's chosen app zone. Invalid/unknown zones fall through to browser-
// local so the picker still works instead of throwing.
function partsInZone(d: Date, iana: string) {
  const opts: Intl.DateTimeFormatOptions = {
    hour12: false,
    year:  "numeric", month:  "2-digit", day:    "2-digit",
    hour:  "2-digit", minute: "2-digit", second: "2-digit",
  };
  const safeZone = safeTimeZone(iana);
  if (safeZone) opts.timeZone = safeZone;
  const fmt = new Intl.DateTimeFormat("en-CA", opts);
  const o: Record<string, string> = {};
  for (const p of fmt.formatToParts(d)) o[p.type] = p.value;
  // Intl returns "24" for midnight in some locales — normalise.
  const h = +o.hour === 24 ? 0 : +o.hour;
  return {
    year:   +o.year,   month:  +o.month,
    day:    +o.day,    hour:   h,
    minute: +o.minute, second: +o.second,
  };
}

/**
 * Returns a Date whose **browser-local** wall-clock equals the wall-clock
 * the supplied UTC instant has when projected into `iana`. Pass that Date
 * to react-datepicker (or any browser-local UI) and it will display
 * "the user's IANA wall-clock" even though the picker itself is unaware
 * of zones. Round-trips losslessly with `wallClockInZoneToUtc` below.
 *
 * Without IANA the value is returned as-is (browser-local rendering).
 */
export function utcToWallClockInZone(utc: Date | string | null | undefined, iana?: string): Date | null {
  if (!utc) return null;
  const d = utc instanceof Date ? utc : new Date(utc);
  if (isNaN(d.getTime())) return null;
  const safeZone = safeTimeZone(iana);
  if (!safeZone) return d;
  const p = partsInZone(d, safeZone);
  return new Date(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
}

/**
 * Inverse of `utcToWallClockInZone`: takes a Date whose browser-local
 * wall-clock equals "what the user picked in their IANA zone" and
 * returns the corresponding UTC instant. Honors DST automatically — the
 * offset is read from `Intl.DateTimeFormat` for the relevant moment.
 *
 * Without IANA the value is treated as browser-local and converted to
 * UTC the standard way (matches the previous behaviour).
 */
export function wallClockInZoneToUtc(d: Date | null | undefined, iana?: string): Date | null {
  if (!d) return null;
  const safeZone = safeTimeZone(iana);
  if (!safeZone) return new Date(d.getTime());
  // Take the browser-local wall-clock components and pretend they're UTC.
  const guessUtcMs = Date.UTC(
    d.getFullYear(), d.getMonth(), d.getDate(),
    d.getHours(),    d.getMinutes(), d.getSeconds(),
  );
  // What does that pretend-UTC moment look like *in the target zone*?
  const p = partsInZone(new Date(guessUtcMs), safeZone);
  const wallInTargetMs = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  // The offset between guessUtcMs and wallInTargetMs is the target zone's
  // offset at that moment (with DST applied). Add it back to get the real
  // UTC instant whose target-zone projection matches the picked wall-clock.
  const offsetMs = guessUtcMs - wallInTargetMs;
  return new Date(guessUtcMs + offsetMs);
}

function safe(opts: Intl.DateTimeFormatOptions, tz: string | undefined, d: Date): string {
  const safeZone = safeTimeZone(tz);
  try {
    return new Intl.DateTimeFormat(undefined, { ...opts, timeZone: safeZone }).format(d);
  } catch {
    return new Intl.DateTimeFormat(undefined, opts).format(d);
  }
}

export function formatInTz(value: Date | string | null | undefined, tz: string | undefined, opts: Intl.DateTimeFormatOptions): string {
  if (!value) return "";
  const d = value instanceof Date ? value : new Date(value);
  if (isNaN(d.getTime())) return "";
  return safe(opts, tz, d);
}

export function useTzFormat() {
  const ctx = useOptionalUser();
  // Sanitise the host-supplied user timezone once. Linux deployments
  // crash with RangeError when given legacy/abbreviation zones
  // ("CPT") that Windows JS engines accept silently; downgrading to
  // browser-local for unknown zones keeps the dashboard usable.
  const tz  = safeTimeZone((ctx?.user?.timeZone || "").trim() || undefined);

  const format = (value: Date | string | null | undefined, opts: Intl.DateTimeFormatOptions) =>
    formatInTz(value, tz, opts);

  return {
    timeZone: tz,
    formatDateTimeShort: (v: Date | string | null | undefined) =>
      format(v, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }),
    formatDateTimeLong: (v: Date | string | null | undefined) =>
      format(v, { weekday: "long", year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short" }),
    formatDate: (v: Date | string | null | undefined) =>
      format(v, { year: "numeric", month: "short", day: "numeric" }),
    /** Long human-readable date — "Friday, 22 May 2026" (day-month-
     *  year). Locale forced to en-GB so dashboard mailto matches the
     *  server's InvariantCulture output regardless of browser locale. */
    formatDateLong: (v: Date | string | null | undefined) => {
      if (!v) return "";
      const d = v instanceof Date ? v : new Date(v);
      if (isNaN(d.getTime())) return "";
      try {
        return new Intl.DateTimeFormat("en-GB", {
          weekday: "long", day: "numeric", month: "long", year: "numeric",
          timeZone: tz || undefined,
        }).format(d);
      } catch {
        return new Intl.DateTimeFormat("en-GB", {
          weekday: "long", day: "numeric", month: "long", year: "numeric",
        }).format(d);
      }
    },
    formatTime: (v: Date | string | null | undefined) =>
      format(v, { hour: "numeric", minute: "2-digit" }),
    /** Time in 24h with the host zone's full NAME suffix — e.g.
     *  "20:48 Central Daylight Time". Matches the server .ics/email,
     *  which label with TimeZoneInfo.DaylightName/StandardName rather
     *  than a bare GMT offset (recipients want the logged-in user's
     *  timezone shown, not GMT). DST-aware: the name auto-flips between
     *  standard and daylight as Intl resolves it for the instant. */
    formatTimeWithZone: (v: Date | string | null | undefined) => {
      if (!v) return "";
      const d = v instanceof Date ? v : new Date(v);
      if (isNaN(d.getTime())) return "";
      try {
        const hm = new Intl.DateTimeFormat("en-GB", {
          hour: "2-digit", minute: "2-digit", hour12: false,
          timeZone: tz || undefined,
        }).format(d);
        // Full zone display name ("Central Daylight Time"), forced to
        // en-US so it matches the Windows TimeZoneInfo display name the
        // server emits regardless of the browser's locale.
        const zoneName = new Intl.DateTimeFormat("en-US", {
          hour: "2-digit", timeZoneName: "long", timeZone: tz || undefined,
        }).formatToParts(d).find(p => p.type === "timeZoneName")?.value || "";
        return zoneName ? `${hm} ${zoneName}` : hm;
      } catch {
        return new Intl.DateTimeFormat("en-GB", {
          hour: "2-digit", minute: "2-digit", hour12: false,
        }).format(d);
      }
    },
    format,
  };
}
