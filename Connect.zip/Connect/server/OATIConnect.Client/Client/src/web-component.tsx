import React from "react";
import ReactDOM from "react-dom/client";
import MeetDashboard from "./MeetDashboard";
import type { MeetConfig } from "./contexts/MeetConfigContext";
import { loadConfig } from "./config/env";

// All CSS imported as strings for Shadow-DOM injection. Shadow DOM scopes
// styles to this element's subtree — only what we explicitly inject applies.
import indexCss             from "./index.css?inline";
import appLayoutCss         from "./layouts/AppLayout.css?inline";
import homeCss              from "./pages/Home.css?inline";
import settingsCss          from "./pages/Settings.css?inline";
import newMeetingPreviewCss from "./components/NewMeetingPreviewModal.css?inline";
import scheduleMeetingCss   from "./components/ScheduleMeetingModal.css?inline";
import toastCss             from "./components/Toast.css?inline";
import reactDatepickerCss   from "react-datepicker/dist/react-datepicker.css?inline";

const allCss = [
  indexCss,
  appLayoutCss,
  homeCss,
  settingsCss,
  newMeetingPreviewCss,
  scheduleMeetingCss,
  toastCss,
  reactDatepickerCss,
].join("\n");

// Build stamp — substituted at packaging time by build-oaticonnect.ps1.
// Seeing the literal placeholder in DevTools means a dev build (no stamp).
const OATICONNECT_BUILD = "__OATICONNECT_BUILD__";

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;",
  } as Record<string, string>)[ch]);
}
try {
  // eslint-disable-next-line no-console
  console.log("[oaticonnect-meet] bundle build=" + OATICONNECT_BUILD);
} catch { /* ignore — non-browser */ }

// Module-level promise — shared across every <oaticonnect-meet> instance on
// the page. The standalone `main.tsx` calls loadConfig() itself; the
// web-component path used by host integrations didn't, which made
// getConfig() throw "Config not loaded. Call loadConfig() first." the
// moment the React tree touched any non-guarded helper (getJitsiBaseUrl,
// useMeetConfig fan-out, etc.). Kicking off the fetch lazily on first
// element mount fixes that — multiple elements share one in-flight call.
let configReady: Promise<void> | null = null;
function ensureConfigLoaded(): Promise<void> {
  if (!configReady) configReady = loadConfig();
  return configReady;
}

class OATIConnectMeet extends HTMLElement {
  private root: ReactDOM.Root | null = null;
  private shadow: ShadowRoot | null = null;
  private mountEl: HTMLElement | null = null;
  /** True once the config fetch has resolved and React has mounted at
   *  least once. Until then, attribute changes only update local state —
   *  rendering the React tree is gated on configReady to guarantee
   *  getConfig() never throws. */
  private configLoaded = false;

  static get observedAttributes() {
    return ["api-base", "user-id", "user-name", "user-email", "user-role", "theme"];
  }

  connectedCallback() {
    this.shadow = this.attachShadow({ mode: "open" });

    // `:root` targets <html> which is outside the shadow tree, so we re-
    // scope CSS variables to :host and #oaticonnect-root. Body/html rules
    // get scoped to the mount point too — same trick.
    const scopedCss = allCss
      .replace(/:root\s*\{/g, ":host, #oaticonnect-root {")
      .replace(/\bhtml\s*,\s*body\s*,\s*#root\b/g, "#oaticonnect-root")
      .replace(/\bbody\s*\{/g, "#oaticonnect-root {");

    const style = document.createElement("style");
    style.textContent = scopedCss;
    this.shadow.appendChild(style);

    // Google Fonts via @import doesn't work inside Shadow DOM, so inject
    // the stylesheet link into the light DOM (idempotent).
    if (!document.querySelector('link[href*="fonts.googleapis.com/css2?family=Inter"]')) {
      const fontLink = document.createElement("link");
      fontLink.rel  = "stylesheet";
      fontLink.href = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap";
      document.head.appendChild(fontLink);
    }

    const mount = document.createElement("div");
    mount.id = "oaticonnect-root";
    mount.style.fontFamily = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    mount.style.minHeight  = "100%";
    this.shadow.appendChild(mount);
    this.mountEl = mount;

    // Lightweight loading placeholder so the host sees something while
    // /api/v1/config is in flight. React mounts after the fetch resolves.
    mount.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:center;'
      + 'height:100%;min-height:200px;color:#6b7280;font-size:14px;">'
      + 'Loading OATIConnect…</div>';

    this.root = ReactDOM.createRoot(mount);

    ensureConfigLoaded()
      .then(() => {
        this.configLoaded = true;
        // Clear placeholder; React owns the mount node from here on.
        if (this.mountEl) this.mountEl.innerHTML = "";
        this.render();
      })
      .catch(err => {
        // Show a clear error in-place so a host with a broken /config
        // route doesn't get a silent blank panel + console-only error.
        // eslint-disable-next-line no-console
        console.error("[oaticonnect-meet] /api/v1/config load failed", err);
        if (this.mountEl) {
          const msg = (err && (err as Error).message) || String(err);
          this.mountEl.innerHTML =
            '<div style="display:flex;flex-direction:column;align-items:center;'
            + 'justify-content:center;height:100%;min-height:200px;padding:24px;'
            + 'color:#b91c1c;font-size:14px;text-align:center;">'
            + '<div style="font-size:32px;margin-bottom:8px;">⚠️</div>'
            + '<div><strong>Could not load OATIConnect.</strong></div>'
            + '<div style="margin-top:8px;color:#6b7280;font-size:12px;">'
            + '/api/v1/config failed: ' + escapeHtml(msg)
            + '</div></div>';
        }
      });
  }

  attributeChangedCallback() {
    // Re-render only after the initial config fetch has resolved —
    // otherwise getConfig() throws inside the React tree.
    if (this.configLoaded) this.render();
  }

  disconnectedCallback() { this.root?.unmount(); }

  private getConfig(): MeetConfig {
    const userIdRaw = this.getAttribute("user-id");
    // Host's native int identity. Earlier builds used Guid via IntToGuid
    // packing on both sides — that translation layer is gone, the host
    // sends the raw int and we parse it here.
    const userId = userIdRaw ? Number.parseInt(userIdRaw, 10) : NaN;
    return {
      apiBase: this.getAttribute("api-base") || "/api/v1",
      user: Number.isFinite(userId) && userId > 0
        ? {
            id:    userId,
            name:  this.getAttribute("user-name")  || "",
            email: this.getAttribute("user-email") || "",
            role:  this.getAttribute("user-role")  || "Standard",
          }
        : null,
      theme: (this.getAttribute("theme") as "dark" | "light") || "light",
    };
  }

  private render() {
    if (!this.root) return;
    const config = this.getConfig();
    const rootDiv = this.shadow?.getElementById("oaticonnect-root");
    if (rootDiv) rootDiv.setAttribute("data-theme", config.theme);

    this.root.render(
      <React.StrictMode>
        <MeetDashboard config={config} />
      </React.StrictMode>
    );
  }
}

customElements.define("oaticonnect-meet", OATIConnectMeet);
