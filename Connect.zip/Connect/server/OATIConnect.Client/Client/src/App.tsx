import MeetDashboard from "./MeetDashboard";
import type { MeetConfig } from "./contexts/MeetConfigContext";

/**
 * Standalone-mode dev shell. The production deployment is the web
 * component bundle (`oaticonnect.mjs`) embedded in the host app —
 * standalone routing pages are gone. This still exists so
 * `npm run dev` (Vite SPA) can render the dashboard against a local
 * dev API for fast iteration.
 *
 * Set `?user=12&name=Dev&email=dev@local&role=Admin` on the URL to
 * exercise different identities; defaults work for one-off testing.
 */
export default function App() {
  const params = new URLSearchParams(window.location.search);
  const userId = Number.parseInt(params.get("user") || "1", 10);
  const config: MeetConfig = {
    apiBase: "/api/v1",
    user: {
      id:    Number.isFinite(userId) && userId > 0 ? userId : 1,
      name:  params.get("name")  || "Dev User",
      email: params.get("email") || "dev@local",
      role:  params.get("role")  || "Admin",
    },
    theme: (params.get("theme") as "dark" | "light") || "light",
  };

  return <MeetDashboard config={config} />;
}
