import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { loadConfig, getAppName } from "./config/env";

/**
 * Vite SPA dev entry. Production embedding goes through `web-component.tsx`
 * — main.tsx is only loaded by `index.html` for `npm run dev` and the
 * non-wc Vite build, neither of which webVision deployment uses.
 */
async function bootstrap() {
  try {
    await loadConfig();
  } catch { /* Dev iteration without backend — proceed. */ }

  try {
    document.title = getAppName();
  } catch { /* config not ready — keep default title */ }

  createRoot(document.getElementById("root")!).render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}
bootstrap();
