// basePath.ts
//
// Returns the deployment base path WITHOUT a trailing slash.
//
// Resolution order (first match wins):
//   1. window.__oaticonnectBasePath  — runtime override set by the host
//      (Sencha OATIConnectView publishes this once it has detected the
//      virtual app prefix). Wins over the build-time value because the
//      bundle is published once and reused under hosts at different
//      virtual paths.
//   2. import.meta.env.BASE_URL      — Vite build-time value, baked in by
//      the `base` option (controlled by VITE_BASE_PATH env var). Useful
//      when the bundle is built per-host with a known prefix.
//   3. ""                             — root.
//
// Examples:
//   host sets window.__oaticonnectBasePath = "/oaticonnect"  → returns "/oaticonnect"
//   build with base="/oaticonnect/"                          → returns "/oaticonnect"
//   build with base="/" + no override                        → returns ""
//   dev (Vite serves at root)                                → returns ""
export function getBasePath(): string {
  try {
    if (typeof window !== "undefined") {
      const override = (window as any).__oaticonnectBasePath;
      if (typeof override === "string") {
        return override === "/" ? "" : override.replace(/\/$/, "");
      }
    }
  } catch { /* SSR / non-browser — fall through */ }

  const base = import.meta.env.BASE_URL || "/";
  return base === "/" ? "" : base.replace(/\/$/, "");
}