﻿import { getBasePath } from "./basePath";

type AppConfig = {
jitsiServerBaseUrl: string;
appName: string;
hostName: string;
showClock: boolean;
showThemeToggle: boolean;
defaultTheme: "light" | "dark" | "system";
};

let config: AppConfig | null = null;

// 🔥 Load config BEFORE app starts
//
// Always fetches fresh from /api/v1/config on every page load — the cache
// in localStorage is only a fallback used when the network request fails
// (offline, server restart, etc.). Caching the response permanently was a
// bad bet: admins flip header settings (clock visibility, default theme)
// from the UI and expect a refresh to reflect those changes, but the old
// cache-then-skip-fetch path kept stale values forever.
export async function loadConfig() {
  // Cheap synchronous hydrate from cache so the very first render has
  // *something* sensible while the fetch is in flight. The fetch result
  // overwrites this immediately afterwards.
  try {
    const cached = localStorage.getItem("app_config_v2");
    if (cached) config = JSON.parse(cached);
  } catch {}

  try {
    const basePath = getBasePath();
    const res = await fetch(`${basePath}/api/v1/config`, { cache: "no-store" });
    config = await res.json();
    try { localStorage.setItem("app_config_v2", JSON.stringify(config)); } catch {}
  } catch (err) {
    if (!config) {
      console.error("Failed to load app config", err);
      throw err;
    }
    // Server unreachable but we have cached config — keep going.
  }
}

/**
 * Force-refresh the cached app config from the server. Used by the Settings
 * page after admins save Header Display changes so the dashboard's clock /
 * theme-toggle visibility flips live without a full page reload.
 */
export async function refreshAppConfig(): Promise<void> {
  try { localStorage.removeItem("app_config_v2"); } catch {}
  config = null;
  const basePath = getBasePath();
  const res = await fetch(`${basePath}/api/v1/config`, { cache: "no-store" });
  config = await res.json();
  try { localStorage.setItem("app_config_v2", JSON.stringify(config)); } catch {}
}

// 🔥 Access config anywhere (in-memory, no re-parsing per call)
export function getConfig(): AppConfig {
  if (!config) {
    // Lazy-hydrate from localStorage once if loadConfig() hasn't run yet
    const cached = localStorage.getItem("app_config_v2");
    if (cached) {
      try {
        config = JSON.parse(cached);
      } catch {}
    }
  }

  if (!config) {
    throw new Error("Config not loaded. Call loadConfig() first.");
  }
  return config;
}

// 🔥 Optional helpers (after config load)
export function getJitsiBaseUrl() {
return getConfig().jitsiServerBaseUrl;
}

export function getAppName() {
try {
  return getConfig().appName || "OATIConnect";
} catch {
  return "OATIConnect";
}
}

/** Display name of the surrounding host portal — used by share-via-email
 *  to render the "Open <hostName> at <url>" instruction. Defaults to
 *  "OATIHub" when the server didn't supply one. */
export function getHostName() {
try {
  return getConfig().hostName || "OATIHub";
} catch {
  return "OATIHub";
}
}

/** Header display prefs — read by MeetDashboard to decide whether to
 *  render the clock / theme toggle and which theme to start with.
 *  All three default to "show / system" when config hasn't loaded. */
export function getShowClock(): boolean {
  try { return getConfig().showClock !== false; } catch { return true; }
}
export function getShowThemeToggle(): boolean {
  try { return getConfig().showThemeToggle !== false; } catch { return true; }
}
export function getDefaultTheme(): "light" | "dark" | "system" {
  try {
    const t = getConfig().defaultTheme;
    return t === "light" || t === "dark" || t === "system" ? t : "system";
  } catch { return "system"; }
}

// ================================
// CONSTANTS (Dynamic Safe)
// ================================

// 👉 Base path (e.g. /abcconnect)
export const BASE_PATH = getBasePath();

// 👉 API base (always correct)
export const API_BASE = `${BASE_PATH}/api/v1`;

// 👉 App base URL (full domain + base path)
export const APP_BASE_URL = `${window.location.origin}${BASE_PATH}`;

// 👉 Jitsi placeholders (can override from config)
export const JITSI_BASE_URL = "";
export const JITSI_DOMAIN = "";
export const JITSI_BASE_PATH = "";