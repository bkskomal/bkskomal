import { useEffect, useRef, useState } from "react";
import { searchExchange, type ExchangeDirectoryItem } from "../api/exchange.api";
import "./InvitePicker.css";

/**
 * Multi-select that talks to Microsoft Graph (via /api/v1/exchange/search)
 * for groups + users, with a free-text fallback for plain email addresses.
 *
 * <p>Used only on the Schedule meeting form, gated behind the
 * <c>Exchange:Enabled</c> toggle in Settings — when off, the parent doesn't
 * render this component at all.</p>
 *
 * <p>Picked items are kept in two parallel buckets so the parent can pass
 * <c>InviteeIds</c> (Graph-resolvable) and <c>InviteeEmails</c> (manual)
 * separately to the server. Group ids expand to multiple emails server-side
 * via <c>IExchangeDirectoryService.ResolveEmailsAsync</c>.</p>
 */

export interface PickedInvitee {
  id?: string;       // Graph object id when picked from the typeahead
  email?: string;    // Set for manual email entries; null/undefined for group picks
  name: string;
  kind: "group" | "user" | "manual";
}

type Props = {
  value: PickedInvitee[];
  onChange: (next: PickedInvitee[]) => void;
};

const isLikelyEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.trim());

export default function InvitePicker({ value, onChange }: Props) {
  const [query, setQuery]       = useState("");
  const [results, setResults]   = useState<ExchangeDirectoryItem[]>([]);
  const [open, setOpen]         = useState(false);
  const [loading, setLoading]   = useState(false);
  const debounceRef             = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef            = useRef<HTMLDivElement | null>(null);

  // Debounced search. <2 chars returns nothing per the server contract.
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (query.trim().length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        setResults(await searchExchange(query));
      } catch {
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 250);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [query]);

  // Close dropdown when click lands outside the component. composedPath is
  // required because we live inside a Shadow DOM — see the same pattern in
  // Home.tsx menu close handler.
  useEffect(() => {
    if (!open) return;
    const handle = (e: MouseEvent) => {
      const path = (e.composedPath && e.composedPath()) || [];
      if (containerRef.current && !path.includes(containerRef.current)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handle);
    return () => document.removeEventListener("mousedown", handle);
  }, [open]);

  function addPick(p: PickedInvitee) {
    // Skip exact duplicates by id-or-email.
    const seen = new Set(value.map(v => (v.id || v.email || "").toLowerCase()));
    const key  = (p.id || p.email || "").toLowerCase();
    if (seen.has(key)) return;
    onChange([...value, p]);
    setQuery("");
    setResults([]);
  }

  function removePick(idx: number) {
    onChange(value.filter((_, i) => i !== idx));
  }

  function commitFreeText() {
    const trimmed = query.trim();
    if (!trimmed) return;
    if (!isLikelyEmail(trimmed)) return; // ignore bad input silently — typeahead is the path
    addPick({ email: trimmed, name: trimmed, kind: "manual" });
  }

  return (
    <div className="invite-picker" ref={containerRef}>
      <div className="invite-picker-chips" onClick={() => setOpen(true)}>
        {value.map((p, i) => (
          <span key={(p.id || p.email || p.name) + i} className={`invite-chip invite-chip-${p.kind}`}>
            <ChipIcon kind={p.kind} />
            <span className="invite-chip-name">{p.name}</span>
            <button type="button" className="invite-chip-x" onClick={(e) => { e.stopPropagation(); removePick(i); }}
                    aria-label={`Remove ${p.name}`}>×</button>
          </span>
        ))}
        <input
          className="invite-picker-input"
          placeholder={value.length === 0 ? "Search people, groups, or type an email…" : ""}
          value={query}
          onChange={e => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onKeyDown={e => {
            if (e.key === "Enter") {
              e.preventDefault();
              commitFreeText();
            }
            if (e.key === "Backspace" && !query && value.length > 0) {
              removePick(value.length - 1);
            }
          }}
        />
      </div>

      {open && (query.trim().length >= 2 || results.length > 0) && (
        <div className="invite-picker-dropdown">
          {loading && <div className="invite-picker-row muted">Searching…</div>}
          {!loading && results.length === 0 && (
            <div className="invite-picker-row muted">
              {isLikelyEmail(query)
                ? <span>Press Enter to add <b>{query.trim()}</b> as an email invite.</span>
                : <span>No matches. Type a full email and press Enter to add it directly.</span>}
            </div>
          )}
          {results.map(r => (
            <button
              type="button"
              key={r.id}
              className="invite-picker-row"
              onClick={() => addPick({ id: r.id, name: r.name, email: r.email ?? undefined, kind: r.kind === "contact" ? "user" : r.kind })}
            >
              <ChipIcon kind={r.kind === "contact" ? "user" : r.kind} />
              <span className="invite-picker-row-name">{r.name}</span>
              {r.email && <span className="invite-picker-row-email">{r.email}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ChipIcon({ kind }: { kind: PickedInvitee["kind"] | "group" | "user" | "contact" }) {
  if (kind === "group") {
    return (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    );
  }
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}
