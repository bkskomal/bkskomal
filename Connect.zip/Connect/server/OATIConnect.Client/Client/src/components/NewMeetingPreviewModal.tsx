import { useEffect, useRef, useState } from "react";
import { createMeeting, getMeetingStatus, startMeeting, validateJoinByCode } from "../api/meetings.api";
import { openMeetingWindow } from "../utils/meetingWindow";
import { useOptionalUser } from "../contexts/UserContext";
import { getAppName } from "../config/env";
import "./NewMeetingPreviewModal.css";

/** Six alphanumeric chars, no 0/O/1/l confusables — pre-fills the
 *  password field when admin policy requires one so hosts aren't
 *  blocked by an empty required input. Mirrors ScheduleMeetingModal. */
function generateMeetingPassword(): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += alphabet[Math.floor(Math.random() * alphabet.length)];
  return s;
}

type Props = {
  onClose: () => void;
  isJoinMode?: boolean;
  meetingTitle?: string;
};

export default function NewMeetingPreviewModal({ onClose, isJoinMode = false, meetingTitle }: Props) {
  const videoRef  = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [devices, setDevices]   = useState<MediaDeviceInfo[]>([]);
  const [cameraId, setCameraId] = useState("");
  const [micId, setMicId]       = useState("");
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [micEnabled, setMicEnabled]       = useState(true);

  const userCtx          = useOptionalUser();
  const prefs            = userCtx?.preferences ?? null;
  const isAdmin          = userCtx?.user?.role === "Admin";
  // meetingNameMode preference is no longer consulted — Title is
  // always a free-form host-entered field; the numeric MeetingCode
  // is generated server-side. The setting still exists in DTO for
  // back-compat but its value is ignored by the modals.
  const defaultDuration  = prefs?.defaultDurationMinutes || 60;
  // Same gate as ScheduleMeetingModal — password input only renders
  // when the admin enabled the global preference.
  const passwordEnabled  = !!prefs?.enableMeetingPassword;
  const hostStartFeatureEnabled = !!prefs?.requireHostStart;

  const [meetingName, setMeetingName] = useState("");
  // Pre-generated 10-digit Meeting ID shown Zoom-style up-front; sent
  // to the server in createMeeting so the saved meeting matches what
  // the host saw on this screen. Only used in start-now mode (the
  // join flow uses meetingName as the lookup key).
  const [meetingCode, setMeetingCode] = useState<string>(() =>
    (Math.floor(Math.random() * 9_000_000_000) + 1_000_000_000).toString()
  );
  function formatMeetingId(code: string): string {
    const d = (code || "").replace(/\D/g, "");
    if (d.length === 10) return `${d.slice(0,3)} ${d.slice(3,6)} ${d.slice(6)}`;
    if (d.length === 9)  return `${d.slice(0,3)} ${d.slice(3,6)} ${d.slice(6)}`;
    return code || "";
  }
  function regenMeetingCode() {
    setMeetingCode((Math.floor(Math.random() * 9_000_000_000) + 1_000_000_000).toString());
  }
  const [description, setDescription] = useState("");
  const [duration, setDuration]       = useState(defaultDuration);
  const [password, setPassword]       = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [requireHostStart, setRequireHostStart] = useState(false);
  const [loading, setLoading]         = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    setDuration(prefs?.defaultDurationMinutes || 60);
  }, [prefs?.defaultDurationMinutes]);

  // Default the title to "{HostName}'s {AppName} Meeting" Zoom-style
  // the moment the modal opens in create mode. Host can keep, edit,
  // or wipe it — we just seed something sensible.
  useEffect(() => {
    if (!isJoinMode && !meetingName) {
      const hostName = userCtx?.user?.name?.trim() || "Untitled";
      const appName  = getAppName() || "OATIConnect";
      setMeetingName(`${hostName}'s ${appName} Meeting`);
    }
  }, [isJoinMode, userCtx?.user?.name]);

  // Auto-fill the required password for new meetings when the admin
  // has password protection turned on. Host can hit Regenerate or
  // type their own — but the field is never left empty by default.
  useEffect(() => {
    if (!isJoinMode && passwordEnabled && !password) {
      setPassword(generateMeetingPassword());
    }
  }, [passwordEnabled, isJoinMode]);

  useEffect(() => {
    async function loadDevices() {
      const mediaDevices = await navigator.mediaDevices.enumerateDevices();
      setDevices(mediaDevices);
      const cam = mediaDevices.find(d => d.kind === "videoinput");
      const mic = mediaDevices.find(d => d.kind === "audioinput");
      if (cam) setCameraId(cam.deviceId);
      if (mic) setMicId(mic.deviceId);
    }
    loadDevices();
  }, []);

  // Live preview stream for the camera/mic the user is about to join with.
  // Re-runs on every device-or-toggle change; cleanup stops the previous tracks.
  useEffect(() => {
    async function startPreview() {
      try {
        stopStream();
        const stream = await navigator.mediaDevices.getUserMedia({
          video: cameraEnabled ? { deviceId: cameraId ? { exact: cameraId } : undefined } : false,
          audio: micEnabled    ? { deviceId: micId    ? { exact: micId    } : undefined } : false,
        });
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (err) {
        // eslint-disable-next-line no-console
        console.error("Preview failed", err);
      }
    }
    startPreview();
    return () => stopStream();
  }, [cameraId, micId, cameraEnabled, micEnabled]);

  function stopStream() {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
  }

  async function handleJoin() {
    // Strip whitespace from the typed code so users who paste "324 728
    // 1886" still resolve to the room name (which is stored as raw
    // digits "3247281886" since the new-model refactor).
    const room = meetingName.replace(/\s+/g, "");
    if (!room) { setErrorMessage("Please enter meeting name or ID"); return; }
    setLoading(true);
    try {
      const status = await getMeetingStatus(room);
      if (!status.exists) {
        setErrorMessage("Meeting not found. Please check the meeting name/ID.");
        return;
      }
      if (status.status === "Scheduled") {
        setErrorMessage("This meeting hasn't started yet. Please wait for the host to start it.");
        return;
      }
      if (status.status === "Ended") {
        setErrorMessage("This meeting has ended.");
        return;
      }

      // Validate the password up-front via the public join-by-code
      // endpoint so the user sees an inline error here instead of
      // Jitsi's native "Password required" dialog after the popup
      // opens. The displayName falls back to the authenticated user
      // when the modal didn't ask for one.
      const displayName = (userCtx?.user?.name?.trim() || "Guest");
      const result = await validateJoinByCode(room, displayName, password || null);
      if (!result.ok) {
        if (result.code === "PASSWORD_REQUIRED") {
          setErrorMessage("This meeting requires a password.");
        } else if (result.code === "INVALID_PASSWORD") {
          setErrorMessage("Incorrect password. Please try again.");
        } else {
          setErrorMessage(result.error || "Could not join meeting.");
        }
        return;
      }

      stopStream();
      await openMeetingWindow(room);
      onClose();
    } catch {
      setErrorMessage("Unable to verify meeting. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function handleStart() {
    if (!meetingName.trim()) { setErrorMessage("Please enter meeting name"); return; }
    // Admin policy: when password protection is enabled, every new
    // meeting must carry a non-empty password. The field is
    // pre-filled with a random value, but if the host cleared it we
    // refuse to create.
    if (passwordEnabled && !password.trim()) {
      setErrorMessage("Please enter a meeting password");
      return;
    }
    setLoading(true);
    try {
      stopStream();
      // Browser zone as fallback for email/.ics formatting — see
      // ScheduleMeetingModal for the rationale.
      let browserTz: string | undefined;
      try { browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone || undefined; }
      catch { browserTz = undefined; }
      const created = await createMeeting({
        title:            meetingName.trim(),
        meetingCode:      meetingCode,
        clientTimeZone:   browserTz,
        description:      description.trim() || null,
        scheduledTimeUtc: new Date().toISOString(),
        durationMinutes:  duration,
        password:         passwordEnabled ? (password || "") : undefined,
        requireHostStart: hostStartFeatureEnabled ? requireHostStart : undefined,
      });
      if (!created?.roomName) throw new Error("Meeting creation failed");
      // Best-effort start — even if it fails, the popup will show the meeting
      // as Scheduled and the user can start it from inside Jitsi if needed.
      await startMeeting(created.meetingId).catch(() => {});
      await openMeetingWindow(created.roomName);
      onClose();
    } catch (err: any) {
      // eslint-disable-next-line no-console
      console.error("Start meeting failed", err);
      setErrorMessage(err?.isHostAuthDenied
        ? "Host session expired. Please refresh the page and sign in again."
        : "Unable to start meeting");
    } finally {
      setLoading(false);
    }
  }

  const cameras = devices.filter(d => d.kind === "videoinput");
  const mics    = devices.filter(d => d.kind === "audioinput");

  return (
    <div className="modal-backdrop">
      <div className="preview-modal">
        <button className="modal-close-btn" onClick={onClose} aria-label="Close" type="button">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6"  x2="6"  y2="18" />
            <line x1="6"  y1="6"  x2="18" y2="18" />
          </svg>
        </button>

        <h2>{meetingTitle ?? (isJoinMode ? "Join Meeting" : "Create Meeting")}</h2>

        {errorMessage && (
          <div className="error-popup">
            <p>{errorMessage}</p>
            <button onClick={() => setErrorMessage("")}>OK</button>
          </div>
        )}

        {!isJoinMode && (
          <div className="meeting-name-field">
            <label>Meeting ID</label>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <input
                type="text"
                value={formatMeetingId(meetingCode)}
                readOnly
                style={{
                  fontFamily: "Consolas, Menlo, monospace",
                  letterSpacing: "0.04em",
                  fontSize: "15px",
                  fontWeight: 600,
                  flex: 1,
                  background: "var(--color-surface-muted, #f3f4f6)",
                  cursor: "default",
                }}
              />
              <button
                type="button"
                onClick={regenMeetingCode}
                title="Generate a new Meeting ID"
                style={{
                  padding: "6px 10px",
                  borderRadius: "6px",
                  border: "1px solid var(--color-border, #d1d5db)",
                  background: "var(--color-surface, #fff)",
                  cursor: "pointer",
                  fontSize: "12px",
                  color: "var(--color-text-muted, #6b7280)",
                }}>
                Regenerate
              </button>
            </div>
          </div>
        )}

        <div className="meeting-name-field">
          <label>{isJoinMode ? "Meeting ID" : "Meeting Title"}</label>
          <input
            type="text"
            placeholder={isJoinMode ? "Enter the meeting ID" : "What's this meeting about?"}
            value={meetingName}
            onChange={e => setMeetingName(e.target.value)}
          />
        </div>

        {/* Password — join mode. The user enters the password the
            host gave them; we validate it up-front via the
            join-by-code endpoint so the user sees an inline error
            here instead of Jitsi's native prompt after the popup
            opens. Field is optional in markup — left blank when the
            meeting has no password set. Eye toggle reuses the same
            showPassword state as the create-mode field. */}
        {isJoinMode && (
          <div className="meeting-name-field">
            <label>Password</label>
            <div style={{ position: "relative" }}>
              <input
                type={showPassword ? "text" : "password"}
                maxLength={100}
                placeholder="Enter meeting password (if required)"
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="new-password"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                data-1p-ignore="true"
                data-lpignore="true"
                data-form-type="other"
                style={{ paddingRight: 38, width: "100%" }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                title={showPassword ? "Hide password" : "Show password"}
                style={{
                  position: "absolute", top: "50%", right: 8, transform: "translateY(-50%)",
                  background: "transparent", border: 0, padding: 4, cursor: "pointer",
                  color: "var(--color-text-secondary, #6b7280)", display: "flex", alignItems: "center",
                }}
              >
                {showPassword ? (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                    <path d="M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                    <path d="M14.12 14.12A3 3 0 1 1 9.88 9.88" />
                    <line x1="1" y1="1" x2="23" y2="23" />
                  </svg>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        )}

        {!isJoinMode && (
          <div className="meeting-name-field">
            <label>Description (optional)</label>
            <textarea
              placeholder="Brief description / agenda"
              value={description}
              onChange={e => setDescription(e.target.value)}
              rows={2}
            />
          </div>
        )}

        {/* Password — host opt-in. Only visible on the create path
            (isJoinMode=false) and when the admin enabled the feature.
            Masked by default; eye toggle on the right reveals/hides. */}
        {!isJoinMode && passwordEnabled && (
          <div className="meeting-name-field">
            <label>
              Password <span style={{ color: "#dc2626", fontSize: 11 }}>*</span>
              <button type="button" onClick={() => setPassword(generateMeetingPassword())}
                style={{
                  marginLeft: 10, padding: "2px 8px", fontSize: 11,
                  background: "transparent", border: "1px solid var(--color-border, #d1d5db)",
                  borderRadius: 4, cursor: "pointer", color: "var(--color-text-secondary, #6b7280)",
                }}
                title="Generate a new random password">
                Regenerate
              </button>
            </label>
            <div style={{ position: "relative" }}>
              <input
                type={showPassword ? "text" : "password"}
                maxLength={100}
                placeholder="Required when password protection is enabled"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="new-password"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                data-1p-ignore="true"
                data-lpignore="true"
                data-form-type="other"
                style={{ paddingRight: 38, width: "100%" }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                title={showPassword ? "Hide password" : "Show password"}
                style={{
                  position: "absolute", top: "50%", right: 8, transform: "translateY(-50%)",
                  background: "transparent", border: 0, padding: 4, cursor: "pointer",
                  color: "var(--color-text-secondary, #6b7280)", display: "flex", alignItems: "center",
                }}
              >
                {showPassword ? (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                    <path d="M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                    <path d="M14.12 14.12A3 3 0 1 1 9.88 9.88" />
                    <line x1="1" y1="1" x2="23" y2="23" />
                  </svg>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Host-start gate — only visible when the admin enabled the
            feature globally. Default off, host opts in per meeting. */}
        {!isJoinMode && hostStartFeatureEnabled && (
          <div className="meeting-name-field">
            <div className="checkbox-row">
              <input
                id="qc-require-host-start"
                type="checkbox"
                checked={requireHostStart}
                onChange={e => setRequireHostStart(e.target.checked)}
              />
              <label htmlFor="qc-require-host-start">Require host to start the meeting</label>
            </div>
          </div>
        )}

        {!isJoinMode && isAdmin && (
          <div className="meeting-name-field">
            <label>Duration</label>
            <select value={duration} onChange={e => setDuration(Number(e.target.value))}>
              <option value={15}>15 minutes</option>
              <option value={30}>30 minutes</option>
              <option value={45}>45 minutes</option>
              <option value={60}>1 hour</option>
              <option value={90}>1.5 hours</option>
              <option value={120}>2 hours</option>
              <option value={180}>3 hours</option>
            </select>
          </div>
        )}

        <div className="preview-toggles">
          <label>
            <input type="checkbox" checked={cameraEnabled}
              onChange={e => setCameraEnabled(e.target.checked)} /> Camera
          </label>
          <label>
            <input type="checkbox" checked={micEnabled}
              onChange={e => setMicEnabled(e.target.checked)} /> Microphone
          </label>
        </div>

        <div className="preview-video-container">
          {cameraEnabled
            ? <video ref={videoRef} autoPlay playsInline muted className="preview-video" />
            : <div className="camera-off">Camera Off</div>}
        </div>

        <div className="preview-controls">
          <div className="control-group">
            <label>Camera</label>
            <select value={cameraId} onChange={e => setCameraId(e.target.value)} disabled={!cameraEnabled}>
              {cameras.map(c => <option key={c.deviceId} value={c.deviceId}>{c.label || "Camera"}</option>)}
            </select>
          </div>
          <div className="control-group">
            <label>Microphone</label>
            <select value={micId} onChange={e => setMicId(e.target.value)} disabled={!micEnabled}>
              {mics.map(m => <option key={m.deviceId} value={m.deviceId}>{m.label || "Microphone"}</option>)}
            </select>
          </div>
        </div>

        <div className="modal-actions">
          <button type="button" className="modal-btn modal-btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="button" className="modal-btn modal-btn-primary primary" disabled={loading}
            onClick={() => isJoinMode ? handleJoin() : handleStart()}>
            {loading ? "Starting..." : isJoinMode ? "Join" : "Start"}
          </button>
        </div>
      </div>
    </div>
  );
}
