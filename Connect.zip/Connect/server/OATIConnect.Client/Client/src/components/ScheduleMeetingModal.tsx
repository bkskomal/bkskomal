import { useState, useEffect, useMemo } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { createMeeting, updateMeeting } from "../api/meetings.api";
import { getExchangeStatus } from "../api/exchange.api";
import { getBasePath } from "../config/basePath";
import { getAppName } from "../config/env";
import { useOptionalUser } from "../contexts/UserContext";
import { utcToWallClockInZone, wallClockInZoneToUtc } from "../utils/tzFormat";
import InvitePicker, { type PickedInvitee } from "./InvitePicker";
import { useToast } from "./Toast";
import "./ScheduleMeetingModal.css";

/** Zoom-style 10-digit meeting ID formatted as XXX XXX XXXX. */
/**
 * Random 10-digit Meeting ID stored raw (no spaces) so URL routes
 * and lookups match the digits-only regex. Display layer formats
 * it as "XXX XXX XXXX" via formatMeetingId.
 */
function generateMeetingCode(): string {
  const n = Math.floor(Math.random() * 9_000_000_000) + 1_000_000_000;
  return n.toString();
}

/** Returns the browser's IANA zone (e.g. "America/Chicago") or
 *  undefined when the runtime doesn't expose it. Sent to the server
 *  as a last-resort fallback for invitation time formatting. */
function tryGetBrowserTimeZone(): string | undefined {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone || undefined; }
  catch { return undefined; }
}

/**
 * Renders the 10-digit code as "XXX XXX XXXX" for human display.
 * Mirrors MeetingService.FormatMeetingCodeForDisplay on the server.
 */
function formatMeetingId(code: string): string {
  const d = (code || "").replace(/\D/g, "");
  if (d.length === 10) return `${d.slice(0,3)} ${d.slice(3,6)} ${d.slice(6)}`;
  if (d.length === 9)  return `${d.slice(0,3)} ${d.slice(3,6)} ${d.slice(6)}`;
  return code || "";
}

/**
 * Zoom-style random meeting password — six alphanumeric chars, no
 * confusables (no 0/O/1/l). Pre-filled when the admin has password
 * protection turned on so hosts don't get blocked by an empty
 * required field; they can hit "Regenerate" or type their own.
 */
function generateMeetingPassword(): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += alphabet[Math.floor(Math.random() * alphabet.length)];
  return s;
}

/** Calendar download URL — anonymous /oaticonnect/* route, bypasses host auth filter. */
function getDownloadCalendarUrl(roomName: string): string {
  return `${getBasePath()}/oaticonnect/calendar/${encodeURIComponent(roomName)}`;
}

type EditMeeting = {
  meetingId: string;
  /** Numeric Meeting ID — populated in edit mode so the modal shows
   *  the same code attendees were already given. */
  meetingCode?: string;
  title: string;
  description?: string;
  scheduledTimeUtc: string;
  durationMinutes?: number;
  /** Existing invitee emails to seed the picker on edit. */
  inviteeEmails?: string[];
  /** Existing join password to pre-fill on edit (host's view only). */
  password?: string | null;
  /** Existing per-meeting host-start flag — pre-fills the toggle. */
  requireHostStart?: boolean;
  /** Existing recurrence pattern — pre-fills the Repeat selector. */
  recurrenceType?: number;
  recurrenceInterval?: number;
  recurrenceDaysOfWeekMask?: number;
  recurrenceEndType?: number;
  recurrenceEndCount?: number | null;
  recurrenceEndDateUtc?: string | null;
};

const REC_NONE    = 0;
const REC_DAILY   = 1;
const REC_WEEKLY  = 2;
const REC_MONTHLY = 3;

const END_NEVER  = 0;
const END_AFTER  = 1;
const END_ONDATE = 2;

// Bitmask: Sun=1, Mon=2, ..., Sat=64. Matches the server's enum.
const WEEKDAYS: { label: string; mask: number }[] = [
  { label: "Sun", mask: 1 },
  { label: "Mon", mask: 2 },
  { label: "Tue", mask: 4 },
  { label: "Wed", mask: 8 },
  { label: "Thu", mask: 16 },
  { label: "Fri", mask: 32 },
  { label: "Sat", mask: 64 },
];

type Props = {
  onClose: () => void;
  editMeeting?: EditMeeting;
};

export default function ScheduleMeetingModal({ onClose, editMeeting }: Props) {
  const isEditMode = !!editMeeting;

  const toast            = useToast();
  const userCtx          = useOptionalUser();
  const isAdmin          = userCtx?.user?.role === "Admin";
  const userTz           = (userCtx?.user?.timeZone || "").trim() || undefined;
  const defaultDuration  = userCtx?.preferences?.defaultDurationMinutes || 60;
  // meetingNameMode preference is no longer consulted — Title is
  // always a free-form host-entered field; the numeric MeetingCode
  // is generated server-side and surfaced separately. The setting
  // still exists in the DTO for back-compat but its value is ignored.
  // Global feature gate — when off, the password input is hidden and the
  // server ignores any password the client posts.
  const passwordEnabled  = !!userCtx?.preferences?.enableMeetingPassword;
  // Same for the host-start gate. When the global pref is off the
  // toggle is hidden; server-side the per-meeting flag is forced false.
  const hostStartFeatureEnabled = !!userCtx?.preferences?.requireHostStart;

  // Default title is "{HostName}'s {AppName} Meeting" Zoom-style.
  // Host can keep it, edit it, or wipe it — we just seed something
  // sensible so the field isn't empty on open.
  const _defaultTitle = (userCtx?.user?.name?.trim() || "Untitled")
    + "'s " + (getAppName() || "OATIConnect") + " Meeting";
  const [title, setTitle]             = useState(editMeeting?.title || _defaultTitle);
  // Meeting ID: edit mode reuses the existing code (so attendees who
  // already have the link/.ics keep working); new meetings pre-fill a
  // fresh 10-digit code shown read-only above Title, Zoom-style.
  const [meetingCode, setMeetingCode] = useState<string>(
    editMeeting?.meetingCode || generateMeetingCode()
  );
  const [description, setDescription] = useState(editMeeting?.description || "");
  // Picker is browser-local under the hood; reframe its wall-clock so it
  // matches the user's IANA zone (the same zone the meeting list and email
  // body use). Without this, picking "3:30 PM" in a browser whose local
  // zone differs from the user's app zone round-trips at the wrong time.
  const [dateTime, setDateTime]       = useState<Date | null>(() =>
    editMeeting?.scheduledTimeUtc
      ? utcToWallClockInZone(editMeeting.scheduledTimeUtc, userTz)
      : null
  );
  const [duration, setDuration]       = useState(editMeeting?.durationMinutes || defaultDuration);
  const [password, setPassword]       = useState<string>(editMeeting?.password ?? "");
  const [showPassword, setShowPassword] = useState(false);
  const [requireHostStart, setRequireHostStart] = useState<boolean>(!!editMeeting?.requireHostStart);

  // Admin-configured ceiling on recurring-series length. 0 = no cap
  // (legacy behaviour — keeps the "Never" end option). Default 90
  // days; the form maxDate clamps the picker and the validator
  // rejects "After N" choices that overshoot.
  const recurringMaxDurationDays = userCtx?.preferences?.recurringMaxDurationDays ?? 90;

  // Default end-condition: when a cap is in place, "After N" is the
  // sensible new-meeting default (10 occurrences). When there's no
  // cap (admin set it to 0), keep "Never" so existing UX is preserved.
  const defaultRecEnd = recurringMaxDurationDays > 0 ? END_AFTER : END_NEVER;

  // Recurrence state — defaults to single occurrence. When the host
  // picks Daily/Weekly/Monthly the extended controls (interval, weekday
  // pills, end-condition) appear underneath.
  const [recType, setRecType]         = useState<number>(editMeeting?.recurrenceType    ?? REC_NONE);
  const [recInterval, setRecInterval] = useState<number>(editMeeting?.recurrenceInterval ?? 1);
  const [recWeekMask, setRecWeekMask] = useState<number>(editMeeting?.recurrenceDaysOfWeekMask ?? 0);
  const [recEndType, setRecEndType]   = useState<number>(editMeeting?.recurrenceEndType  ?? defaultRecEnd);
  const [recEndCount, setRecEndCount] = useState<number>(editMeeting?.recurrenceEndCount ?? 10);
  const [recEndDate, setRecEndDate]   = useState<Date | null>(() =>
    editMeeting?.recurrenceEndDateUtc ? new Date(editMeeting.recurrenceEndDateUtc) : null
  );

  // Latest legal end date for the "On date" option, derived from the
  // admin cap + the picked start. Recomputed when either changes.
  const recurringMaxEndDate = useMemo<Date | null>(() => {
    if (recurringMaxDurationDays <= 0) return null;
    const anchor = dateTime ?? new Date();
    const max = new Date(anchor);
    max.setDate(max.getDate() + recurringMaxDurationDays);
    return max;
  }, [recurringMaxDurationDays, dateTime]);

  const [loading, setLoading]         = useState(false);

  // Invite picker — only renders when admin has flipped Exchange:Enabled on.
  // Seeded from editMeeting.inviteeEmails on edit; the manual pre-existing
  // emails come back as kind="manual" since the server doesn't round-trip
  // Graph object ids on the list response.
  const [exchangeEnabled, setExchangeEnabled] = useState(false);
  const [invitees, setInvitees] = useState<PickedInvitee[]>(
    (editMeeting?.inviteeEmails ?? []).map(email => ({
      email, name: email, kind: "manual" as const,
    }))
  );

  useEffect(() => {
    getExchangeStatus()
      .then(s => setExchangeEnabled(s.enabled))
      .catch(() => setExchangeEnabled(false));
  }, []);

  // Title is now the host's free-form name for the meeting ("Weekly
  // Standup"). The numeric Meeting Id is generated server-side and
  // stored in MeetingCode — no longer derived from Title. The
  // historical isAutoMode auto-fill is gone; the field is always a
  // plain text input. The generateMeetingId import is kept only
  // because the create flow still references it (will be removed in a
  // follow-up cleanup once the legacy Settings dropdown is dropped).

  // Auto-fill a Zoom-style random password for new meetings when the
  // admin has password protection enabled. Editing an existing
  // meeting preserves whatever password was already set (host can
  // still hit "Regenerate" to roll a fresh one).
  useEffect(() => {
    if (!isEditMode && passwordEnabled && !password) {
      setPassword(generateMeetingPassword());
    }
  }, [passwordEnabled, isEditMode]);

  async function saveMeeting() {
    if (!title.trim() && !dateTime) {
      toast.error("Please enter a title and select a date & time");
      return;
    }
    if (!title.trim()) {
      toast.error("Please enter a meeting title");
      return;
    }
    if (!dateTime) {
      toast.error("Please select a date & time");
      return;
    }
    // Password is required when admin has the feature enabled — the
    // create form auto-fills one so the user never sees an empty
    // required field unless they cleared it on purpose.
    if (passwordEnabled && !password.trim()) {
      toast.error("Please enter a meeting password");
      return;
    }
    // Split picks into Graph ids (server expands groups → emails) and
    // manual emails (saved as-is). Either may be empty.
    const inviteeIds    = invitees.filter(i => i.id).map(i => i.id!) as string[];
    const inviteeEmails = invitees.filter(i => !i.id && i.email).map(i => i.email!) as string[];

    // The picker's `dateTime` carries the wall-clock the user picked, but
    // its absolute UTC moment is wrong when browser-local ≠ user IANA.
    // Re-anchor the wall-clock against the user's IANA so the stored UTC
    // matches the same wall-clock the meeting list will render.
    const utcIso = (wallClockInZoneToUtc(dateTime, userTz) ?? dateTime).toISOString();

    setLoading(true);
    try {
      // Only send `password` when the feature is on. Sending an empty
      // string explicitly clears the password on update; sending undefined
      // leaves the existing value alone (matches the server's null
      // semantics in UpdateMeetingCommand).
      const passwordPayload = passwordEnabled ? (password ?? "") : undefined;
      // Same pattern for the host-start flag — only sent when the
      // feature is enabled globally; server-side the value is forced
      // false otherwise.
      const requireHostStartPayload = hostStartFeatureEnabled ? requireHostStart : undefined;

      // Build the recurrence payload. When recType=None we still send
      // zeros — that's how the server clears stale fields on an edit
      // that turns a recurring meeting back into a single one.
      const recurrencePayload = {
        recurrenceType:           recType,
        recurrenceInterval:       recType === REC_NONE ? 1 : Math.max(1, recInterval | 0),
        recurrenceDaysOfWeekMask: recType === REC_WEEKLY ? recWeekMask : 0,
        recurrenceEndType:        recType === REC_NONE ? END_NEVER : recEndType,
        recurrenceEndCount:       recEndType === END_AFTER && recType !== REC_NONE ? recEndCount : null,
        recurrenceEndDateUtc:     recEndType === END_ONDATE && recType !== REC_NONE && recEndDate
                                    ? recEndDate.toISOString() : null,
      };

      if (isEditMode && editMeeting) {
        await updateMeeting(editMeeting.meetingId, {
          title,
          // Browser timezone — same fallback we send on create, so the
          // update-invite email + .ics render in the user's wall-clock
          // even when the host's stored profile zone is missing (e.g.
          // hosted integrations where the host adapter omits timezone).
          clientTimeZone:   tryGetBrowserTimeZone(),
          description:      description || null,
          scheduledTimeUtc: utcIso,
          durationMinutes:  duration,
          inviteeIds,
          inviteeEmails,
          password:         passwordPayload,
          requireHostStart: requireHostStartPayload,
          ...recurrencePayload,
        });
        onClose();
        return;
      }

      const created = await createMeeting({
        title,
        meetingCode,
        // Browser timezone as a fallback for email/.ics formatting so
        // the invitation reads in the user's wall-clock even when the
        // host's stored profile zone is missing or unrecognised.
        clientTimeZone: tryGetBrowserTimeZone(),
        description:      description || null,
        scheduledTimeUtc: utcIso,
        durationMinutes:  duration,
        inviteeIds,
        inviteeEmails,
        password:         passwordPayload,
        requireHostStart: requireHostStartPayload,
        ...recurrencePayload,
      });

      // Offer the calendar invite immediately. Electron host gets the file
      // bytes; everyone else opens the .ics download in a new tab.
      if (window.electronAPI) {
        try {
          // Electron path: hand the .ics URL to the desktop shell so it
          // opens directly in Outlook / default calendar app.
          await window.electronAPI.openOutlookEvent(getDownloadCalendarUrl(created.roomName));
        } catch { /* fall through to web download */ }
      } else {
        window.open(getDownloadCalendarUrl(created.roomName));
      }

      onClose();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal-backdrop">
      <div className="modal scheduler-modal">
        <button className="modal-close-btn" onClick={onClose} aria-label="Close" type="button">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6"  x2="6"  y2="18" />
            <line x1="6"  y1="6"  x2="18" y2="18" />
          </svg>
        </button>

        <h2>{isEditMode ? "Edit Meeting" : "Schedule Meeting"}</h2>

        <div className="form-group">
          <label>Meeting ID</label>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <input
              type="text"
              value={formatMeetingId(meetingCode)}
              readOnly
              style={{
                fontFamily: "Consolas, Menlo, monospace",
                letterSpacing: "0.04em",
                fontSize: "15px",
                fontWeight: 600,
                flex: 1,
                background: "var(--color-surface-muted, #f3f4f6)",
                cursor: "default",
              }}
            />
            {!isEditMode && (
              <button
                type="button"
                onClick={() => setMeetingCode(generateMeetingCode())}
                title="Generate a new Meeting ID"
                style={{
                  padding: "6px 10px",
                  borderRadius: "6px",
                  border: "1px solid var(--color-border, #d1d5db)",
                  background: "var(--color-surface, #fff)",
                  cursor: "pointer",
                  fontSize: "12px",
                  color: "var(--color-text-muted, #6b7280)",
                }}>
                Regenerate
              </button>
            )}
          </div>
        </div>

        <div className="form-group">
          <label>Meeting Title</label>
          <input
            placeholder="What's this meeting about?"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Description (optional)</label>
          <textarea
            placeholder="Brief description / agenda for the meeting"
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={2}
          />
        </div>

        {/* Invite picker — only renders when admin has flipped Exchange:Enabled
            on. Hidden entirely (no empty section) when off, so users without
            Exchange configured see the same form they always have. */}
        {exchangeEnabled && (
          <div className="form-group">
            <label>Invite (optional)</label>
            <InvitePicker value={invitees} onChange={setInvitees} />
            <div style={{ marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }}>
              Invitees see this meeting on their dashboard and can join. Groups expand to all members at save time.
            </div>
          </div>
        )}

        <div className="form-group">
          <label>Date &amp; Time</label>
          <DatePicker
            selected={dateTime}
            onChange={(d: Date | null) => setDateTime(d)}
            showTimeSelect
            timeFormat="HH:mm"
            timeIntervals={15}
            timeCaption="Time"
            dateFormat="MMM d, yyyy h:mm aa"
            placeholderText="Select date and time"
            // In edit mode keep the original timestamp editable even when it's
            // already in the past — the user might only be tweaking the title.
            // New meetings always require a future date.
            minDate={isEditMode ? undefined : new Date()}
            className="datepicker-input"
            wrapperClassName="datepicker-wrapper"
            popperClassName="datepicker-popper"
            popperPlacement="bottom-start"
          />
        </div>

        {/* Password input — visible only when the admin enabled
            EnableMeetingPassword. Recipients of the share link must
            type this value on the prejoin page; the email/.ics body
            also includes it so they can read it ahead of time.
            Masked by default with an eye toggle to reveal. */}
        {passwordEnabled && (
          <div className="form-group">
            <label>
              Password <span style={{ color: "#dc2626", fontSize: 11 }}>*</span>
              <button type="button" onClick={() => setPassword(generateMeetingPassword())}
                style={{
                  marginLeft: 10, padding: "2px 8px", fontSize: 11,
                  background: "transparent", border: "1px solid var(--color-border, #d1d5db)",
                  borderRadius: 4, cursor: "pointer", color: "var(--color-text-secondary, #6b7280)",
                }}
                title="Generate a new random password">
                Regenerate
              </button>
            </label>
            <div style={{ position: "relative" }}>
              <input
                type={showPassword ? "text" : "password"}
                maxLength={100}
                placeholder="Required when password protection is enabled"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="new-password"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                data-1p-ignore="true"
                data-lpignore="true"
                data-form-type="other"
                style={{ paddingRight: 38, width: "100%" }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                title={showPassword ? "Hide password" : "Show password"}
                style={{
                  position: "absolute", top: "50%", right: 8, transform: "translateY(-50%)",
                  background: "transparent", border: 0, padding: 4, cursor: "pointer",
                  color: "var(--color-text-secondary, #6b7280)", display: "flex", alignItems: "center",
                }}
              >
                {showPassword ? (
                  // eye-off
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                    <path d="M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                    <path d="M14.12 14.12A3 3 0 1 1 9.88 9.88" />
                    <line x1="1" y1="1" x2="23" y2="23" />
                  </svg>
                ) : (
                  // eye
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Recurrence — Repeat dropdown. Expands to show interval +
            (for Weekly) weekday pills + end-condition selector. */}
        <div className="form-group">
          <label>Repeat</label>
          <select value={recType} onChange={e => setRecType(Number(e.target.value))}>
            <option value={REC_NONE}>Does not repeat</option>
            <option value={REC_DAILY}>Daily</option>
            <option value={REC_WEEKLY}>Weekly</option>
            <option value={REC_MONTHLY}>Monthly</option>
          </select>
        </div>

        {recType !== REC_NONE && (
          <>
            <div className="form-group">
              <label>{recType === REC_DAILY ? "Every (days)" : recType === REC_WEEKLY ? "Every (weeks)" : "Every (months)"}</label>
              <input
                type="number"
                min={1}
                max={99}
                value={recInterval}
                onChange={e => setRecInterval(Math.max(1, parseInt(e.target.value || "1", 10)))}
              />
            </div>

            {recType === REC_WEEKLY && (
              <div className="form-group">
                <label>Repeat on</label>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {WEEKDAYS.map(d => {
                    const selected = (recWeekMask & d.mask) !== 0;
                    return (
                      <button
                        key={d.mask}
                        type="button"
                        onClick={() => setRecWeekMask(m => selected ? (m & ~d.mask) : (m | d.mask))}
                        style={{
                          padding: "6px 10px",
                          borderRadius: 6,
                          border: "1px solid var(--color-border)",
                          background: selected ? "var(--color-primary)" : "var(--color-bg)",
                          color: selected ? "#fff" : "var(--color-text)",
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: "pointer",
                          minWidth: 44,
                        }}
                      >{d.label}</button>
                    );
                  })}
                </div>
                <div style={{ marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }}>
                  Leave blank to repeat on the same weekday as the first occurrence.
                </div>
              </div>
            )}

            <div className="form-group">
              <label>Ends</label>
              <select value={recEndType} onChange={e => setRecEndType(Number(e.target.value))}>
                {/* "Never" is hidden when the admin's RecurringMaxDurationDays
                    cap is > 0 (the default). Recurring series should stay
                    bounded — picks one of After N / On date. Setting the
                    pref to 0 restores the Never option for legacy
                    use cases. */}
                {recurringMaxDurationDays === 0 && (
                  <option value={END_NEVER}>Never</option>
                )}
                <option value={END_AFTER}>After N occurrences</option>
                <option value={END_ONDATE}>On a date</option>
              </select>
              {recurringMaxDurationDays > 0 && (
                <div style={{ marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }}>
                  Recurring series may extend up to {recurringMaxDurationDays} days from the start.
                </div>
              )}
            </div>

            {recEndType === END_AFTER && (
              <div className="form-group">
                <label>Occurrences</label>
                <input
                  type="number"
                  min={1}
                  max={999}
                  value={recEndCount}
                  onChange={e => setRecEndCount(Math.max(1, parseInt(e.target.value || "1", 10)))}
                />
              </div>
            )}

            {recEndType === END_ONDATE && (
              <div className="form-group">
                <label>End date</label>
                <DatePicker
                  selected={recEndDate}
                  onChange={(d: Date | null) => setRecEndDate(d)}
                  dateFormat="MMM d, yyyy"
                  placeholderText="Select end date"
                  minDate={dateTime ?? new Date()}
                  maxDate={recurringMaxEndDate ?? undefined}
                  className="datepicker-input"
                  wrapperClassName="datepicker-wrapper"
                  popperClassName="datepicker-popper"
                  popperPlacement="bottom-start"
                />
                {recurringMaxEndDate && (
                  <div style={{ marginTop: 6, fontSize: 12, color: "var(--color-text-secondary)" }}>
                    Cannot extend past {recurringMaxEndDate.toLocaleDateString()}.
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* Host-start gate — only visible when the global feature is
            enabled. Default off; the host opts in per meeting. */}
        {hostStartFeatureEnabled && (
          <div className="form-group">
            <div className="checkbox-row">
              <input
                id="require-host-start"
                type="checkbox"
                checked={requireHostStart}
                onChange={e => setRequireHostStart(e.target.checked)}
              />
              <div className="checkbox-text">
                <label htmlFor="require-host-start">Require host to start the meeting</label>
                <div className="checkbox-helper">
                  Joiners see a waiting page until you hit Start.
                </div>
              </div>
            </div>
          </div>
        )}

        {isAdmin && (
          <div className="form-group">
            <label>Duration</label>
            <select value={duration} onChange={e => setDuration(Number(e.target.value))}>
              <option value={15}>15 minutes</option>
              <option value={30}>30 minutes</option>
              <option value={45}>45 minutes</option>
              <option value={60}>1 hour</option>
              <option value={90}>1.5 hours</option>
              <option value={120}>2 hours</option>
              <option value={180}>3 hours</option>
            </select>
          </div>
        )}

        <div className="modal-actions">
          <button type="button" className="modal-btn modal-btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="button" className="modal-btn modal-btn-primary primary"
            onClick={saveMeeting} disabled={loading}>
            {loading ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}
