import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
// CSS for this component is bundled via web-component.tsx's ?inline import
// chain (vite-wc drops the auto-emitted oaticonnect.css), so no direct
// import here.

type ToastKind = "success" | "error" | "info";

interface ToastItem {
  id: number;
  kind: ToastKind;
  message: string;
}

interface ToastApi {
  success: (message: string) => void;
  error:   (message: string) => void;
  info:    (message: string) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

/** Shared in-app notice surface — replaces native window.alert calls
 *  with branded, theme-aware toasts that auto-dismiss. Wrap once near
 *  the top of the dashboard; any descendant calls useToast(). */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const push = useCallback((kind: ToastKind, message: string) => {
    // Random-ish id; collisions don't matter because removal is by exact match.
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setItems(list => [...list, { id, kind, message }]);
    // 3.2s matches the fade animation length below — the toast finishes
    // its fade-out roughly when we drop it from state.
    window.setTimeout(() => {
      setItems(list => list.filter(t => t.id !== id));
    }, 3200);
  }, []);

  const api: ToastApi = {
    success: (m) => push("success", m),
    error:   (m) => push("error",   m),
    info:    (m) => push("info",    m),
  };

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="toast-stack" role="status" aria-live="polite">
        {items.map(t => (
          <div key={t.id} className={`toast toast-${t.kind}`}>
            <span className="toast-icon" aria-hidden>
              {t.kind === "success" && (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              )}
              {t.kind === "error" && (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8"  x2="12" y2="12" />
                  <line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
              )}
              {t.kind === "info" && (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="16" x2="12" y2="12" />
                  <line x1="12" y1="8"  x2="12.01" y2="8" />
                </svg>
              )}
            </span>
            <span className="toast-text">{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    // Dev-only safety net — outside the provider, log instead of crashing.
    return {
      success: (m) => console.warn("[Toast] (no provider) success:", m),
      error:   (m) => console.warn("[Toast] (no provider) error:",   m),
      info:    (m) => console.warn("[Toast] (no provider) info:",    m),
    };
  }
  return ctx;
}
