﻿import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import path from "path"

// Production base path is configurable via env var VITE_BASE_PATH
// Examples:
//   VITE_BASE_PATH=/               → app served at the root (default)
//   VITE_BASE_PATH=/oaticonnect/   → app served under /oaticonnect/
//   VITE_BASE_PATH=/abcconnect/    → app served under /abcconnect/
//
// Defaults to "/" so localhost / root deployments work out of the box.
// Set VITE_BASE_PATH only when deploying under a sub-path.
export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), 'VITE_');
    const prodBase = env.VITE_BASE_PATH || '/';
    // Always end with a slash
    const normalizedProdBase = prodBase.endsWith('/') ? prodBase : prodBase + '/';

    return {
        plugins: [react()],
        build: {
            outDir: path.resolve(__dirname, "../wwwroot"),
            emptyOutDir: true
        },
        base: mode === 'development' ? '/' : normalizedProdBase,
        server: {
            port: 5173,
            proxy: {
                '/api': {
                    target: 'http://localhost:56347',
                    changeOrigin: true,
                },
                // The popup window's HTML and the .ics download both live
                // under /oaticonnect/* on the API. Without this proxy entry
                // Vite serves index.html (SPA fallback) for those paths and
                // the popup just shows the dashboard again.
                '/oaticonnect': {
                    target: 'http://localhost:56347',
                    changeOrigin: true,
                },
            }
        }
    };
})
