import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import fs from "fs";

// All CSS is already embedded in the mjs (via `?inline` imports in
// web-component.tsx, injected into Shadow DOM at runtime). The standalone
// oaticonnect.css Vite emits in library mode is unused — this plugin
// deletes it after write so the drop is a single self-contained .mjs.
const dropCssAsset = {
  name: "drop-css-asset",
  closeBundle() {
    const css = path.resolve(__dirname, "dist-wc", "oaticonnect.css");
    if (fs.existsSync(css)) fs.unlinkSync(css);
  },
};

export default defineConfig({
  plugins: [react(), dropCssAsset],
  build: {
    lib: {
      entry: path.resolve(__dirname, "src/web-component.tsx"),
      name: "OATIConnectMeet",
      fileName: "oaticonnect",
      // ES only — every embed uses <script type="module"> so the UMD build
      // was dead weight.
      formats: ["es"],
    },
    cssCodeSplit: false,
    outDir: "dist-wc",
    rollupOptions: {
      external: [],
    },
  },
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
  },
});
