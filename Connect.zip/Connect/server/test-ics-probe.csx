// Reflectively builds an .ics through the running server's logic so we
// can dump the exact bytes Outlook 2013 would receive. No HTTP, no auth
// — we directly call MeetingCalendarService.GenerateCalendarAsync via
// a hand-rolled DI container backed by an in-memory repository.

#r "I:/Jitsi/9/OATIConnect/server/OATIConnect.Client/bin/Debug/net8.0/OATIConnect.API.dll"

using System;
using System.Linq;
using System.Reflection;
using System.Text;
using System.IO;

// We can't easily run the whole DI graph from a script, so we'll call
// FoldIcsLine + the inner formatting helpers directly to render a
// representative .ics body and dump the byte sequence.
var asm = typeof(OATIConnect.API.Meetings.InvitationHtmlBuilder).Assembly;
var calType = asm.GetType("OATIConnect.API.Meetings.MeetingCalendarService");
var foldM = calType.GetMethod("FoldIcsLine",
    BindingFlags.NonPublic | BindingFlags.Static);
Console.WriteLine("FoldIcsLine found: " + (foldM != null));

// Manually build a representative .ics matching what GenerateCalendarAsync would emit.
var meetingId = Guid.NewGuid();
var startUtc  = new DateTime(2026, 5, 22, 14, 0, 0, DateTimeKind.Utc);
var endUtc    = startUtc.AddMinutes(60);
var sep       = new string('-', 42);

var descLines = new[]
{
    "OATICONNECT MEETING INVITATION",
    sep,
    "You have been invited to join the OATIConnect meeting:",
    "",
    "  Meeting Id : 549 816 9408",
    "  Password   : 000000",
    "",
    "JOIN WITH ONE CLICK",
    "  http://localhost:5205/oaticonnect/j/CfDJ8Aak41zzQwFCoQ6qF7AqIiijvlwcIT94Cr2k7T5edH66FUBwXazdCS4FyMUzs1vgthC-52HKaR3n782LKMzdcMnxzLNuux_IYA-ryufRZMErA9qzeOKXq-vxYW5_o3ns933e2Yc6t_1mKWGQ5zFCLcI",
    "",
    "JOIN FROM THE WEB CLIENT",
    "  http://localhost:5205/oaticonnect/join",
    "  Enter the Meeting ID and password on that page to join from any browser.",
    "",
    sep,
};
var description = string.Join("\\n", descLines);

var icsLines = new System.Collections.Generic.List<string>
{
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//OATIConnect//Calendar//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    $"UID:{meetingId}",
    $"DTSTAMP:{DateTime.UtcNow:yyyyMMddTHHmmssZ}",
    $"DTSTART:{startUtc:yyyyMMddTHHmmssZ}",
    $"DTEND:{endUtc:yyyyMMddTHHmmssZ}",
    "SUMMARY:OATIConnect meeting (549 816 9408) invitation",
    "ORGANIZER;CN=Host Name:mailto:host@example.com",
    $"DESCRIPTION:{description}",
    "URL:http://localhost:5205/oaticonnect/j/CfDJ8Aak...",
    "LOCATION:OATIConnect",
    "STATUS:CONFIRMED",
    "SEQUENCE:0",
    "BEGIN:VALARM",
    "TRIGGER:-PT10M",
    "ACTION:DISPLAY",
    "DESCRIPTION:Reminder",
    "END:VALARM",
    "END:VEVENT",
    "END:VCALENDAR",
};

var ics   = string.Join("\r\n", icsLines) + "\r\n";
var bytes = new UTF8Encoding(false).GetBytes(ics);

Console.WriteLine($"Total bytes: {bytes.Length}");
Console.WriteLine($"First 3 bytes (hex): {bytes[0]:X2} {bytes[1]:X2} {bytes[2]:X2}  (BOM would be EF BB BF)");
Console.WriteLine($"Has CR before each LF: {!bytes.Where((b,i) => b==0x0A && i>0 && bytes[i-1]!=0x0D).Any()}");
Console.WriteLine();
Console.WriteLine("--- File contents (raw) ---");
Console.WriteLine(ics);
Console.WriteLine("--- End ---");
File.WriteAllBytes("I:/Jitsi/9/OATIConnect/server/sample.ics", bytes);
Console.WriteLine("Wrote I:/Jitsi/9/OATIConnect/server/sample.ics — open this in Outlook 2013 to test.");
