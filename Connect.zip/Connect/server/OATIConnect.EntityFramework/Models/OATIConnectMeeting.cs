using System.ComponentModel.DataAnnotations;

namespace OATIConnect.EntityFramework.Models;

// Shape mirrors OATIHub.EntityFramework.Models.OATIConnectMeeting and the
// columns created by the production migration
// (20260506144328_Release_2_2_3_0_OATIConnect). The OATIConnect.API DLL
// reads/writes these via the host's IOATIConnectDataProvider — wire JSON
// only, no DLL dependency on this entity class.
public class OATIConnectMeeting
{
    [Key]
    public Guid Id { get; set; }

    [Required, StringLength(200)]
    public string Title { get; set; } = "";

    [StringLength(2000)]
    public string? Description { get; set; }

    public DateTime ScheduledTimeUtc { get; set; }

    public int DurationMinutes { get; set; }

    [Required, StringLength(200)]
    public string RoomName { get; set; } = "";

    [Required, StringLength(20)]
    public string MeetingCode { get; set; } = "";

    public int HostUserId { get; set; }

    public int Status { get; set; }

    public DateTime? ActualStartUtc { get; set; }

    public DateTime? ActualEndUtc { get; set; }

    public bool IsLocked { get; set; }

    [StringLength(100)]
    public string? Password { get; set; }

    public bool RequireHostStart { get; set; }

    // ===== Recurrence =====
    public int RecurrenceType { get; set; }            // enum stored as int
    public int RecurrenceInterval { get; set; } = 1;
    public int RecurrenceDaysOfWeekMask { get; set; }
    public int RecurrenceEndType { get; set; }
    public int? RecurrenceEndCount { get; set; }
    public DateTime? RecurrenceEndDateUtc { get; set; }

    public DateTime CreatedAtUtc { get; set; }
}
