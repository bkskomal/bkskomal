using System.ComponentModel.DataAnnotations;

namespace OATIConnect.EntityFramework.Models;

/// <summary>
/// EF row for the OATIConnectMeetingOccurrenceExceptions table —
/// per-occurrence overrides on a recurring meeting series.
/// Currently used only for "Cancelled" exceptions (skip one instance
/// without ending the series); the OverrideScheduledTimeUtc column
/// is reserved for a future "Reschedule this occurrence" phase.
/// </summary>
public class OATIConnectMeetingOccurrenceException
{
    [Key]
    public Guid Id { get; set; }

    public Guid MeetingId { get; set; }

    public DateTime OriginalStartUtc { get; set; }

    /// <summary>0=Cancelled, 1=Rescheduled (future use).</summary>
    public int Type { get; set; }

    public DateTime? OverrideScheduledTimeUtc { get; set; }

    public DateTime CreatedAtUtc { get; set; }
}
