using System.ComponentModel.DataAnnotations;

namespace OATIConnect.EntityFramework.Models;

public class OATIConnectAppConfig
{
    [Key]
    public Guid Id { get; set; }

    [Required, StringLength(200)]
    public string Key { get; set; } = "";

    [StringLength(4000)]
    public string? Value { get; set; }

    [StringLength(1000)]
    public string? Description { get; set; }

    [StringLength(100)]
    public string Category { get; set; } = "General";

    public DateTime CreatedAtUtc { get; set; }

    public DateTime? UpdatedAtUtc { get; set; }
}
