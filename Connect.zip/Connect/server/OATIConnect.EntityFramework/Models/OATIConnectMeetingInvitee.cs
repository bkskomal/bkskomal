using System.ComponentModel.DataAnnotations;

namespace OATIConnect.EntityFramework.Models;

public class OATIConnectMeetingInvitee
{
    [Key]
    public Guid Id { get; set; }

    public Guid MeetingId { get; set; }

    [Required, StringLength(320)]
    public string Email { get; set; } = "";

    [Required, StringLength(50)]
    public string SourceKind { get; set; } = "manual";

    public DateTime CreatedAtUtc { get; set; }
}
