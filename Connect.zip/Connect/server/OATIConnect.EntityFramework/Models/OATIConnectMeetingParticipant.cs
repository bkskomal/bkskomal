using System.ComponentModel.DataAnnotations;

namespace OATIConnect.EntityFramework.Models;

public class OATIConnectMeetingParticipant
{
    [Key]
    public Guid Id { get; set; }

    public Guid MeetingId { get; set; }

    public int UserId { get; set; }

    [StringLength(200)]
    public string? Name { get; set; }

    [StringLength(320)]
    public string? Email { get; set; }

    public DateTime JoinedAtUtc { get; set; }
}
