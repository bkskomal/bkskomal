using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using OATIConnect.EntityFramework.Models;

namespace OATIConnect.EntityFramework;

/// <summary>
/// EF Core context for the four OATIConnect tables. Mirrors the schema in
/// OATIHub.EntityFramework's Application_FrameworkEntities (same table /
/// column / index shape) so migrations applied here line up with what the
/// production OATIHub host carries.
///
/// The shipped <c>OATIConnect.API.dll</c> has NO EF dependency — when a
/// host integrates the DLL, this context (or the host's own equivalent) is
/// plugged in behind <see cref="OATIConnect.API.OATIConnectData.IOATIConnectDataProvider"/>.
/// </summary>
public class OATIConnectDbContext : DbContext
{
    public OATIConnectDbContext(DbContextOptions<OATIConnectDbContext> options) : base(options) { }

    public DbSet<OATIConnectMeeting>                     OATIConnectMeetings                     => Set<OATIConnectMeeting>();
    public DbSet<OATIConnectMeetingInvitee>              OATIConnectMeetingInvitees              => Set<OATIConnectMeetingInvitee>();
    public DbSet<OATIConnectMeetingParticipant>          OATIConnectMeetingParticipants          => Set<OATIConnectMeetingParticipant>();
    public DbSet<OATIConnectAppConfig>                   OATIConnectAppConfigs                   => Set<OATIConnectAppConfig>();
    public DbSet<OATIConnectMeetingOccurrenceException>  OATIConnectMeetingOccurrenceExceptions  => Set<OATIConnectMeetingOccurrenceException>();

    // SQLite drops DateTimeKind on read — every DateTime comes back as
    // Kind=Unspecified. Without these converters, System.Text.Json then
    // emits values without the trailing "Z" and the React UI parses them
    // as local time. Restamping Kind=Utc on read keeps the wire JSON
    // unambiguous (matches the OATIHub.Server controller's explicit
    // DateTime.SpecifyKind(...) pattern, which solves the same problem on
    // EF6).
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<OATIConnectMeeting>(e =>
        {
            e.HasIndex(x => x.RoomName);
            e.HasIndex(x => x.HostUserId);
        });
        modelBuilder.Entity<OATIConnectMeetingInvitee>(e =>
        {
            e.HasIndex(x => x.MeetingId);
            e.HasIndex(x => x.Email);
        });
        modelBuilder.Entity<OATIConnectMeetingParticipant>(e =>
        {
            e.HasIndex(x => x.MeetingId);
        });
        modelBuilder.Entity<OATIConnectAppConfig>(e =>
        {
            e.HasIndex(x => x.Key).IsUnique();
        });
        modelBuilder.Entity<OATIConnectMeetingOccurrenceException>(e =>
        {
            e.HasIndex(x => x.MeetingId);
            // (MeetingId, OriginalStartUtc) is the natural key — same
            // series can have many exceptions but never two for the same
            // occurrence. Index speeds up the per-series fetch we run
            // every time the meeting list is generated.
            e.HasIndex(x => new { x.MeetingId, x.OriginalStartUtc }).IsUnique();
        });

        var utc      = new ValueConverter<DateTime,  DateTime >(v => v, v => DateTime.SpecifyKind(v, DateTimeKind.Utc));
        var nullable = new ValueConverter<DateTime?, DateTime?>(v => v, v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : v);

        foreach (var et in modelBuilder.Model.GetEntityTypes())
        foreach (var p in et.GetProperties())
        {
            if (p.ClrType == typeof(DateTime))   p.SetValueConverter(utc);
            if (p.ClrType == typeof(DateTime?))  p.SetValueConverter(nullable);
        }
    }
}
