// dotnet-script probe — loads the running server's DLL and reflectively
// invokes InvitationHtmlBuilder.Build / MeetingCalendarService description
// lookup so we can see exactly what the running code produces.

#r "I:/Jitsi/9/OATIConnect/server/OATIConnect.Client/bin/Debug/net8.0/OATIConnect.API.dll"

using System;
using System.Reflection;
using System.Linq;

var asm = typeof(OATIConnect.API.Meetings.InvitationHtmlBuilder).Assembly;
Console.WriteLine($"Assembly: {asm.GetName().Name} v{asm.GetName().Version}");
Console.WriteLine($"Location: {asm.Location}");
Console.WriteLine($"Has InvitationHtmlBuilder: yes");

var t = typeof(OATIConnect.API.Meetings.InvitationHtmlBuilder);
var m = t.GetMethod("Build", BindingFlags.Public | BindingFlags.Static | BindingFlags.NonPublic);
Console.WriteLine($"Build method found: {m != null}");

var html = (string)m.Invoke(null, new object[] {
    "OATIConnect", "634 777 0513",
    "Thursday, 21 May 2026 at 19:52 GMT-5", 60,
    "xbSHA7", "http://localhost:5205/6347770513",
    "http://localhost:5205/oaticonnect/join"
});
Console.WriteLine("---HTML LENGTH: " + html.Length);
Console.WriteLine("---FIRST 1200 CHARS:");
Console.WriteLine(html.Substring(0, Math.Min(1200, html.Length)));
