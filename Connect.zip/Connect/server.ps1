# ============================================
# Server Build Script - OATIMeetAI Backend
# ============================================

$ErrorActionPreference = "Stop"

$ProjectPath = "./server/OATIConnect.API/OATIConnect.API.csproj"
$Configuration = "Release"
$OutputDir = "./publish"

try {
    Write-Host "Building Backend..." -ForegroundColor Cyan
    Write-Host "  Configuration: $Configuration"
    Write-Host "  Output: $OutputDir"

    # Clean previous build
    if (Test-Path $OutputDir) {
        Write-Host "Cleaning previous build..." -ForegroundColor Yellow
        Remove-Item $OutputDir -Recurse -Force
    }

    # Restore dependencies
    Write-Host "Restoring dependencies..." -ForegroundColor Yellow
    dotnet restore $ProjectPath
    if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed with exit code $LASTEXITCODE" }

    # Publish
    Write-Host "Publishing..." -ForegroundColor Yellow
    dotnet publish $ProjectPath -c $Configuration -o $OutputDir --no-restore
    if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed with exit code $LASTEXITCODE" }

    # Summary
    $size = (Get-ChildItem $OutputDir -Recurse -File | Measure-Object -Property Length -Sum).Sum
    $sizeMB = "{0:N2} MB" -f ($size / 1MB)
    $fullPath = Resolve-Path $OutputDir

    Write-Host "`nServer build succeeded." -ForegroundColor Green
    Write-Host "  Output: $fullPath"
    Write-Host "  Size:   $sizeMB"
}
catch {
    Write-Host "`nServer build FAILED: $_" -ForegroundColor Red
    exit 1
}
