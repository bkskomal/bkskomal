﻿using Microsoft.AspNetCore.Http;
using OATIConnect.API.Domain.Entities;
using OATIConnect.API.OATIConnectData;
using System.Net.Http;
using System.Net.Http.Json;

namespace OATIHub
{
    /// <summary>
    /// OATIHub''s implementation of <see cref="IOATIConnectDataProvider"/>.
    /// Calls the CRUD endpoints hosted by OATIConnectDataController in
    /// OATIHub.Server, which in turn talk to Application_FrameworkEntities
    /// in OATIHub.EntityFramework. This is the ONLY piece of OATIConnect
    /// glue the main app ships - everything else (controllers, services,
    /// DTOs, business logic) comes from OATIConnect.API.dll.
    ///
    /// <para>
    /// The HttpClient is intentionally NOT configured with a fixed
    /// BaseAddress. Instead every request resolves the current host at
    /// call time via <see cref="IHttpContextAccessor"/>, so the provider
    /// works unchanged in dev/QA/prod, under IIS sub-path or a reverse
    /// proxy, and against whichever scheme + host the end-user is already
    /// on. The inbound request''s Cookie header is forwarded so the
    /// target controller sees the same authenticated session.
    /// </para>
    /// </summary>
    public class OATIConnectDataProvider : IOATIConnectDataProvider
    {
        private readonly HttpClient _http;
        private readonly IHttpContextAccessor _http_ctx;

        public OATIConnectDataProvider(HttpClient http, IHttpContextAccessor httpContextAccessor)
        {
            _http      = http;
            _http_ctx  = httpContextAccessor;
        }

        /// <summary>
        /// Builds an absolute URL against the CURRENT request''s scheme + host
        /// so this adapter self-configures on whatever host the app happens
        /// to be running under (no appsettings needed).
        /// </summary>
        private string AbsoluteUrl(string relativePath)
        {
            var req = _http_ctx.HttpContext?.Request
                ?? throw new InvalidOperationException(
                    "OATIConnectDataProvider needs an active HttpContext (register IHttpContextAccessor).");

            var path = relativePath.StartsWith("/") ? relativePath : "/" + relativePath;
            return $"{req.Scheme}://{req.Host}{req.PathBase}{path}";
        }

        /// <summary>
        /// Forwards the inbound request''s Cookie header so controllers
        /// protected by the host''s cookie-auth middleware authenticate the
        /// call as the same user. Safe to call before every request —
        /// <see cref="HttpRequestMessage.Headers"/> is per-message, so there
        /// is no cross-request leakage.
        /// </summary>
        private HttpRequestMessage NewRequest(HttpMethod method, string relativePath)
        {
            var req = new HttpRequestMessage(method, AbsoluteUrl(relativePath));
            var cookie = _http_ctx.HttpContext?.Request.Headers["Cookie"].ToString();
            if (!string.IsNullOrEmpty(cookie))
                req.Headers.TryAddWithoutValidation("Cookie", cookie);
            return req;
        }

        // ===== Meetings =====

        public async Task<Meeting?> GetMeetingByIdAsync(Guid meetingId, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Get, $"api/oaticonnect-data/meetings/{meetingId}");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            return await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<Meeting>(res.Content, ct);
        }

        public async Task<Meeting?> GetActiveMeetingByRoomNameAsync(string roomName, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Get, $"api/oaticonnect-data/meetings/active-by-room?roomName={Uri.EscapeDataString(roomName)}");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            return await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<Meeting>(res.Content, ct);
        }

        public async Task<IReadOnlyList<Meeting>> GetVisibleMeetingsAsync(int userId, string? email, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Get, $"api/oaticonnect-data/meetings/visible?userId={userId}&email={Uri.EscapeDataString(email ?? "")}");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            var list = await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<List<Meeting>>(res.Content, ct);
            return list ?? new List<Meeting>();
        }

        public async Task AddMeetingAsync(Meeting meeting, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Post, "api/oaticonnect-data/meetings");
            req.Content = JsonContent.Create(meeting);
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
        }

        public async Task UpdateMeetingAsync(Meeting meeting, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Put, "api/oaticonnect-data/meetings");
            req.Content = JsonContent.Create(meeting);
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
        }

        public async Task DeleteMeetingAsync(Guid meetingId, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Delete, $"api/oaticonnect-data/meetings/{meetingId}");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
        }

        // ===== Invitees =====

        public async Task<IReadOnlyList<MeetingInvitee>> GetInviteesAsync(Guid meetingId, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Get, $"api/oaticonnect-data/meetings/{meetingId}/invitees");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            var list = await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<List<MeetingInvitee>>(res.Content, ct);
            return list ?? new List<MeetingInvitee>();
        }

        public async Task ReplaceInviteesAsync(Guid meetingId, IEnumerable<MeetingInvitee> invitees, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Put, $"api/oaticonnect-data/meetings/{meetingId}/invitees");
            req.Content = JsonContent.Create(invitees.ToList());
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
        }

        // ===== Participants =====

        public async Task<IReadOnlyList<MeetingParticipant>> GetParticipantsAsync(Guid meetingId, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Get, $"api/oaticonnect-data/meetings/{meetingId}/participants");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            var list = await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<List<MeetingParticipant>>(res.Content, ct);
            return list ?? new List<MeetingParticipant>();
        }

        public async Task AddParticipantAsync(MeetingParticipant participant, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Post, "api/oaticonnect-data/participants");
            req.Content = JsonContent.Create(participant);
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
        }

        // ===== AppConfigs =====

        public async Task<IReadOnlyList<AppConfig>> GetAllAppConfigsAsync(CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Get, "api/oaticonnect-data/appconfigs");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            var list = await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<List<AppConfig>>(res.Content, ct);
            return list ?? new List<AppConfig>();
        }

        public async Task<AppConfig?> GetAppConfigByKeyAsync(string key, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Get, $"api/oaticonnect-data/appconfigs/by-key?key={Uri.EscapeDataString(key)}");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            return await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<AppConfig>(res.Content, ct);
        }

        public async Task<AppConfig> UpsertAppConfigAsync(AppConfig config, CancellationToken ct = default)
        {
            using var req = NewRequest(HttpMethod.Post, "api/oaticonnect-data/appconfigs/upsert");
            req.Content = JsonContent.Create(config);
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            return (await System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync<AppConfig>(res.Content, ct))!;
        }
    }
}
