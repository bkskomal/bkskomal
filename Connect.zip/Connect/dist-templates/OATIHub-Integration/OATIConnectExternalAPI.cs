﻿using OATI.webVision.Server.Core.User;
using OATI.webVision.Server.Core.User.SystemUser;
using OATI.webVision.Server.Core.UserContext;
using OATIConnect.API.Common;
using OATIConnect.API.ExternalUser;

namespace OATIHub
{
    /// <summary>
    /// OATIHub''s implementation of <see cref="IExternalUserProvider"/>.
    /// Mirrors <c>OATIGenieExternalAPI.GetUser()</c> — same
    /// <c>UserContextHelper.GetOATIUser()</c> path, same
    /// <c>SystemUserContextHelper</c> fallback, same fields pulled off
    /// <c>CallingUser</c> — so OATIConnect and Genie see identical user
    /// identities + time zones across the app.
    ///
    /// <para>
    /// TimeZone is read from the framework user''s <c>Timezone</c>
    /// property (a Windows zone id like "Central Standard Time") and
    /// mapped to an IANA id ("America/Chicago") for the React client
    /// via <see cref="TimeZoneMapper.ToIana(string)"/>. Both forms go
    /// across the wire so the browser can use IANA and legacy JS code
    /// keeps working with Windows ids.
    /// </para>
    /// </summary>
    public class OATIConnectExternalAPI : IExternalUserProvider
    {
        public Task<ExternalUserInfo?> GetCurrentUserAsync()
        {
            var callingUser = UserContextHelper.GetOATIUser();

            if (callingUser == null || callingUser.UserId == 0)
            {
                // Fallback: same SystemUser path OATIGenieExternalAPI uses for
                // server-originated / background requests without a session.
                var sys = SystemUserContextHelper.GetSystemUser();
                if (sys == null)
                    return Task.FromResult<ExternalUserInfo?>(null);

                return Task.FromResult<ExternalUserInfo?>(new ExternalUserInfo(
                    Id:              sys.UserId,
                    Name:            $"{sys.FirstName} {sys.LastName}".Trim(),
                    Email:           $"{sys.UserName}@local",
                    Role:            "Standard",   // system user — never admin-gated
                    IsActive:        true,
                    TimeZoneWindows: sys.Timezone ?? "",
                    TimeZoneIana:    TimeZoneMapper.ToIana(sys.Timezone)));
            }

            return Task.FromResult<ExternalUserInfo?>(new ExternalUserInfo(
                Id:              callingUser.UserId,
                Name:            $"{callingUser.FirstName} {callingUser.LastName}".Trim(),
                Email:           $"{callingUser.UserName}@local",
                Role:            MapRole(callingUser),
                IsActive:        true,
                TimeZoneWindows: callingUser.Timezone ?? "",
                TimeZoneIana:    TimeZoneMapper.ToIana(callingUser.Timezone)));
        }

        /// <summary>
        /// Single source of truth for admin status — same probe the React
        /// side uses in the browser via
        /// <c>Wv.OATIUser.getUserPermissions().IsAdmin</c>, so server and
        /// client never disagree about who''s an admin.
        /// </summary>
        private static string MapRole(IOATIApplicationUser user)
        {
            // TODO (host): plug in your real admin probe here. Typically:
            //   var perms = UserManagerRepository.RetrieveUserPermissions();
            //   return perms != null && perms.IsAdmin ? "Admin" : "Standard";
            // Fallback below keeps the integration compilable before the
            // probe is wired in.
            return "Standard";
        }
    }
}
