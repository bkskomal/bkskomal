Ext.define('Webvision.view.welcomepage.OATIWelcomePage', {
	xtype: 'welcomepage',
	reference: 'welcomepage',
	extend: 'Webvision.views.oatidashboard.OatiDashboardPanel',
	requires: ['Webvision.view.admindashboard.OATIWebSupportIssueStore',
		'Webvision.view.admindashboard.OATIHelpDeskTicketsStore',
		'Webvision.view.welcomepage.OATIWelcomePageController',
		'Webvision.view.welcomepage.OATIApplicationLayoutManager',
		'Webvision.view.welcomepage.OATIApplicationLayoutView',
		'Webvision.utils.DisplayToolbar',
		'Webvision.view.welcomepage.OATIWelcomePageCalendar',
		'Webvision.view.welcomepage.OATIWelcomePageSidePanelCalendar',
		'Webvision.view.welcomepage.OATIRecentTicketsView',
		'Webvision.view.welcomepage.OATIRecentTicketsSidePanelView',
		'Webvision.view.welcomepage.OATIHelpVideosView',
		'Webvision.view.welcomepage.OATIFeedbackSummaryFilterConfig',
		// OATICONNECT (1/4): require the embedded view
		'Webvision.view.oaticonnect.OATIConnectView',
		'Webvision.utils.CommonUtils'
	],
	mixins: ['Webvision.mixins.OATICommonMixin'],
	cls: 'admin-dashboard x-dashboard',
	userCls: "hubwelcomepagecls",
	offsetBottomBar: 10,
	width: '5px',
	layout: {
		type: 'dashboard',
		getSplitterConfig: function () {
			return {
				xtype: 'columnsplitter',
				width: 10
			};
		}
	},
	configurations: {
		mapPeriodicRefresh: new Ext.util.HashMap()
	},

	controller: 'welcomepagecontroller',
	title: GlobalStrings.Message_WelcomeText,
	dockedItems: [{
		xtype: 'panel',
		reference: 'dockedItemBar',
		//styel: "margin: 10px 10px;",
		collapseWidth: 41,
		expandWidth: 290,
		collapsed: false,
		dock: 'left',
		collapseDirection: 'left',
		collapsible: false,
		animCollapse: true,
		header: false,
		items: [{
			xtype: 'dataview',
			height: '100%',
			style: 'width:41px;overflow: hidden;',
			reference: 'dockedItemBarDataView',
			tpl: [
				`<div class="sidebar"><ul>
					<tpl for=".">
						<tpl if="Id==0">
							<li class="sidebarmenu x-item-selected"><div class="sidebarmenu_internaldv">
						<tpl else>
							<li class="sidebarmenu"><div class="sidebarmenu_internaldv">
						</tpl>
						<tpl if="iconcls">
							<div class="sidebarmenus_dvimg" data-qtip="{Name}">{iconcls}</div>
						<tpl else>
							<div class="sidebarmenus_dvimg" data-qtip="{Name}"><img src="{Image}"  width="25" height="25" /></div>
						</tpl>
						<div class="sidebarmenus_text">{Name}</div>
						</div></li>
					</tpl>
				</ul></div>`,
			],
			itemSelector: 'li.sidebarmenu',
			store: {
				data: [{
					"Name": "Dashboard",
					"iconcls": '<i class="fas fa-home dashboard_homeicon"></i>',
					"Id": 0
				}, {
					"Name": "Single sign-on & Application Access",
					"Image": "../HubResources/images/leftpanel/Single_Signon_Product_Overview.svg",
					"Id": 1
				}, {
					"Name": "Support and Help Desk Center",
					"Image": "../HubResources/images/leftpanel/Support_Help_Desk_Center.svg",
					"Id": 2
				}, {
					"Name": "News, Events & Highlights",
					"Image": "../HubResources/images/leftpanel/News_Events_Highlights.svg",
					"Id": 3
				}, {
					"Name": "Training and Onboarding",
					"Image": "../HubResources/images/leftpanel/Training_Onboarding.svg",
					"Id": 4
				}, {
					"Name": "Feedback & Suggestions",
					"Image": "../HubResources/images/leftpanel/Feedback _Suggestions.svg",
					"Id": 5
				},
				// OATICONNECT (2/4): new sidebar entry — use the same icon class
				// as Dashboard ("dashboard_homeicon") so color/size match.
				{
					"Name": "OATIConnect Meet",
					"iconcls": '<i class="fas fa-video dashboard_homeicon"></i>',
					"Id": 6
				}]
			},
			listeners: {
				"itemclick": 'sidePanelItemClick',
				afterrender: function (dataview) {
					// Detect the webVision virtual app prefix so /oaticonnect/feature
					// resolves to the right ASP.NET Core app. When webVision is
					// hosted at https://host/<prefix>/... a bare '/oaticonnect/feature'
					// hits the IIS site root instead of the virtual app and 404s as
					// a static-file lookup. Prefix with the first segment of the
					// page URL (escape hatch: hard-code via
					//   Webvision.view.oaticonnect.OATIConnectView.basePath = '/myapp')
					function oaticonnectBasePath() {
						try {
							var Cls = Webvision.view.oaticonnect && Webvision.view.oaticonnect.OATIConnectView;
							if (Cls && typeof Cls.basePath === 'string') return Cls.basePath;
							var segs = (window.location.pathname || '').split('/').filter(function (s) { return s.length > 0; });
							if (segs.length > 0 && segs[0].indexOf('.') === -1) return '/' + segs[0];
						} catch (e) {}
						return '';
					}
					function removeOATIConnectTile() {
						try {
							var store = dataview.getStore();
							if (!store) return;
							var idx = store.findBy(function (rec) { return rec.get('Id') === 6; });
							if (idx >= 0) store.removeAt(idx);
						} catch (e) { /* swallow */ }
					}
					// Visibility policy: hide the tile ONLY when the server
					// EXPLICITLY says Enabled=false. A failed / timed-out /
					// malformed /oaticonnect/feature response leaves the tile
					// visible — matching the server-side default
					// (Enabled=true when no sidecar is found). Logs the
					// failure to console so a misconfigured route or auth
					// filter can be spotted without chasing a missing icon.
					try {
						Ext.Ajax.request({
							url: oaticonnectBasePath() + '/oaticonnect/feature',
							method: 'GET',
							timeout: 3000,
							success: function (response) {
								try {
									var data = Ext.decode(response.responseText) || {};
									if (data.enabled === false || data.Enabled === false) {
										removeOATIConnectTile();
									}
								} catch (e) {
									if (console && console.warn) {
										console.warn('[OATIConnect] /oaticonnect/feature returned malformed JSON, leaving tile visible:', e);
									}
								}
							},
							failure: function (resp) {
								if (console && console.warn) {
									console.warn('[OATIConnect] /oaticonnect/feature failed (status=' +
										(resp && resp.status) + '), leaving tile visible.');
								}
							}
						});
					} catch (e) {
						if (console && console.warn) {
							console.warn('[OATIConnect] could not issue /oaticonnect/feature request, leaving tile visible:', e);
						}
					}

					// OATICONNECT: post-handler that fires AFTER the controller's
					// sidePanelItemClick. The controller only knows IDs 1–5; for
					// Id 6 (OATIConnect) we manually show the embedded panel so
					// it always opens — even if the OATIConnectView itself errors,
					// the empty container will still be visible.
					dataview.on('itemclick', function (dv, record) {
						try {
							var id = record && record.data ? record.data.Id : null;
							var welcomepage = dv.up('welcomepage');
							if (!welcomepage) return;
							var rightBar = welcomepage.lookupReference('dockedItemRightBar');
							var oaticonnectPanel = welcomepage.lookupReference('sidepanel_oaticonnectpanel');
							if (!oaticonnectPanel) return;

							if (id === 6) {
								// Centralized show routine. Sizes the right bar
								// BEFORE the view mounts (it starts at width:0,
								// and on the very first OATIConnect click no
								// other tab has triggered the controller's
								// size pass yet — without this the view used
								// to render into a 0-width container, making
								// it look like the icon "did not work" until
								// the user clicked another tab and back).
								function applyShow() {
									try {
										var setDockWidth  = 0, setDockHeight = 0;
										try {
											var dockedItemBar = welcomepage.lookupReference('dockedItemBar');
											setDockWidth  = welcomepage.up().body.getWidth()  - dockedItemBar.getWidth() - 16;
											setDockHeight = welcomepage.up().body.getHeight() - 90;
											if (rightBar) {
												if (setDockWidth  > 0) rightBar.setWidth(setDockWidth);
												if (setDockHeight > 0) rightBar.setHeight(setDockHeight);
											}
										} catch (e) { /* sizing best-effort */ }

										if (rightBar && rightBar.show) rightBar.show();

										Ext.Array.each([
											'sidepanel_productaccesspanel',
											'sidepanel_ticketmessagepanel',
											'sidepanel_calendarhighlightpanel',
											'sidepanel_helpvideospanel',
											'sidepanel_feedbackandSummarypanel'
										], function (ref) {
											var p = welcomepage.lookupReference(ref);
											if (p && p.hide) { try { p.hide(); } catch (e) {} }
										});

										if (oaticonnectPanel.show) oaticonnectPanel.show();

										// Force-add the view if the show listener
										// did not (or already cleared on a prior
										// hide) — guarantees the panel is never
										// shown empty.
										if (!oaticonnectPanel.down('oaticonnectview')) {
											try {
												oaticonnectPanel.removeAll(true);
												oaticonnectPanel.add({
													xtype: 'oaticonnectview',
													customLoadData: function () {}
												});
											} catch (e) {}
										}

										if (welcomepage.body && welcomepage.body.el && welcomepage.body.el.dom) {
											welcomepage.body.el.dom.style.display = 'none';
										}

										try {
											var connectView = oaticonnectPanel.down('oaticonnectview');
											if (connectView) {
												if (setDockWidth  > 0) connectView.setWidth(setDockWidth);
												if (setDockHeight > 0) connectView.setHeight(setDockHeight);
											}
										} catch (e) {}

										if (dv.el && dv.el.dom) {
											var lis = dv.el.dom.getElementsByClassName('sidebarmenu');
											for (var i = 0; i < lis.length; i++) {
												lis[i].classList.remove('x-item-selected');
											}
											if (lis[6]) lis[6].classList.add('x-item-selected');
										}

										welcomepage.updateLayout(true);
									} catch (e) { /* swallow */ }
								}

								applyShow();
								// Re-apply after a tick to absorb the layout race
								// that made the very first click appear to do nothing.
								Ext.defer(applyShow, 80);

								// Intentionally NOT persisting Id=6 to selectedLeftSidebarItem.
								// We want initial focus on Dashboard (Id=0) every time the
								// welcome page opens — OATIConnect is a click-to-enter
								// experience, not a default landing tab.
							} else {
								// Other tabs: hide the OATIConnect panel so the
								// controller's own logic for ids 0–5 isn't disturbed.
								if (oaticonnectPanel.hide) {
									try { oaticonnectPanel.hide(); } catch (e) {}
								}
							}
						} catch (e) {
							// Last-resort: still try to surface the panel for Id 6
							// so the user gets at least the empty container.
							try {
								if (record && record.data && record.data.Id === 6) {
									var wp = dv.up('welcomepage');
									var rb = wp && wp.lookupReference('dockedItemRightBar');
									var p  = wp && wp.lookupReference('sidepanel_oaticonnectpanel');
									if (rb && rb.show) rb.show();
									if (p  && p.show)  p.show();
								}
							} catch (ee) { /* swallow */ }
						}
					});
				}
			}
		}],
		dockedItems: [{
			xtype: 'toolbar',
			dock: 'bottom',
			style: 'margin-left: 0px;border-top: 1px solid #e9e9e9 !important;',
			items: [
				{
					xtype: 'button',
					html: '<i data-qtip="Expand Panel" class="fas summaryIcon fa-angle-double-right glow" aria-hidden="true" style="font-size:20px;" ></i>',
					style: 'box-shadow: none;background:none;left:0px !important;margin: 0 0 0 2px !important;',
					cls: 'trans-back-btn',
					reference: 'expandBtn',
					handler: function (expandBtn) {
						var welcomepage = this.up('welcomepage');
						var dockedItemBar = welcomepage.lookupReference('dockedItemBar');
						var dataview = welcomepage.lookupReference('dockedItemBarDataView');
						var collapseBtn = welcomepage.lookupReference('collapseBtn');
						var rightDockedItemBar = welcomepage.lookupReference('dockedItemRightBar');
						Wv.CommonUtils.runWithLayoutsSuspended(function () {
							dockedItemBar.collapse(true);
							welcomepage.updateLayout(true)
						}, this);
						dataview.setWidth(dockedItemBar.expandWidth);
						if (rightDockedItemBar && !rightDockedItemBar.hidden) {
							rightDockedItemBar.setWidth(welcomepage.getWidth() - dockedItemBar.expandWidth - 16);
						}
						expandBtn.hide();
						collapseBtn.show();
						Wv.CommonUtils.runWithLayoutsSuspended(function () {
							dockedItemBar.expand(true);
							welcomepage.updateLayout(true)
						}, welcomepage);
					}
				},
				'->',
				{
					xtype: 'button',
					html: '<i data-qtip="Collpase Panel" class="fas summaryIcon fa-angle-double-left glow" aria-hidden="true" style="font-size:20px;" ></i>',
					style: 'box-shadow: none;background:none;left:0px !important;margin: 0 0 0 2px !important;',
					cls: 'trans-back-btn',
					reference: 'collapseBtn',
					hidden: true,
					handler: function (collapseBtn) {
						var welcomepage = this.up('welcomepage');
						var dockedItemBar = welcomepage.lookupReference('dockedItemBar');
						var dataview = welcomepage.lookupReference('dockedItemBarDataView');
						var expandBtn = welcomepage.lookupReference('expandBtn');
						var rightDockedItemBar = welcomepage.lookupReference('dockedItemRightBar');
						Wv.CommonUtils.runWithLayoutsSuspended(function () {
							dockedItemBar.collapse(true);
							welcomepage.updateLayout(true)
						}, this);
						dataview.setWidth(dockedItemBar.collapseWidth);
						if (rightDockedItemBar && !rightDockedItemBar.hidden) {
							rightDockedItemBar.setWidth(welcomepage.getWidth() - dockedItemBar.collapseWidth - 16);
						}
						collapseBtn.hide();
						expandBtn.show();
						Wv.CommonUtils.runWithLayoutsSuspended(function () {
							dockedItemBar.expand(true);
							welcomepage.updateLayout(true)
						}, welcomepage);
					}
				}
			]
		}]
	}, {
		xtype: 'panel',
		reference: 'dockedItemRightBar',
		collapsed: false,
		dock: 'right',
		collapseDirection: 'left',
		collapsible: false,
		animCollapse: false,
		cls: "dockedItemRightBar",
		width: 0,
		header: false,
		layout: 'anchor',
		width: '100%',
		height: '100%',
		listeners: {
			//boxready: function (me) {
			//	me.hide();
			//}
		},
		items: [{
			xtype: 'container',
			layout: {
				type: 'fit',
			},
			reference: 'dockedItemRightBarMainPanel',
			items: [{
				layout: {
					type: 'vbox',
					align: 'stretch'
				},

				reference: 'sidepanel_productaccesspanel',
				cls: 'ProductAccess-panel',
				title: GlobalStrings.Title_ProductAccess,
				header: true,
				titleAlign: 'left',
				scrollable: false,
				FilterData: '{"productaccesspanelfilter":"All"}',
				tools: [{
					xtype: 'splitbutton',
					//itemId: 'layoutButtonFrmk',
					reference: 'ShowApplicationLayoutSidePanelIcon',
					iconCls: 'far apptopicon fa-table prodPanel glow-only',
					tooltip: GlobalStrings.Tooltip_CreateNewLayout,
					style: 'background:none; padding: 0px 0px 0px 0px !important;',
					cls: 'appTopPanelCls refreshPlugin layoutikon',
					menu: {
						xtype: 'menu',
						items: [
							{
								text: GlobalStrings.Tooltip_CreateNewLayout,
								hideOnClick: false,
								handler: 'onApplicationLayoutBtnClicked'
							}]
					},
					listeners: {
						click: 'onApplicationLayoutBtnClicked',
						menushow: function (btn, menu) {
							this.up('welcomepage').getController().onApplicationLayoutMenuShow(btn, menu);
						}
					}
				}, {
					xtype: 'button',
					iconMask: true,
					iconCls: 'sidepanelrefresh',
					handler: function () {
						if (Wv.CommonUtils.getIfAvailable(this, 'up("[reference=sidepanel_productaccesspanel]").down("productaccesssidepanelview")')) {
							var panel = this.up('[reference=sidepanel_productaccesspanel]').down('productaccesssidepanelview');
							panel.customLoadData(panel);
						}

					}
				}],
				items: [{
					xtype: 'productaccesssidepanelview',
					customLoadData: function (productAccess, extraParams) {
						if (Wv.CommonUtils.getIfAvailable(productAccess, '.down("[reference=productaccesspanel]").xtype') == "dataview") {
							Ext.Ajax.request({
								url: UrlManager.buildURL(UrlManager.apiURL(), "OATIWelcomePage/GetProductAccessData"),
								params: {},
								scope: this,
								async: true,
								method: 'POST',
								success: function (data) {
									if (data && data.status == 200) {
										var result = JSON.parse(data.responseText);
										productAccess.up("welcomepage").controller.setApplicationLayoutManager(productAccess, result);
									}
								}.bind(this)
							})
						}
					}
				}],

			}, {
				xtype: 'container',
				layout: 'vbox',
				reference: 'sidepanel_ticketmessagepanel',
				items: [{
					style: 'overflow: hidden;',
					reference: 'sidepanel_ticketpanel',
					layout: 'vbox',
					title: GlobalStrings.Title_RecentTickets,
					userCls: "welcomepage_ticketsummary",
					scrollable: true,
					tools: [{
						xtype: 'button',
						iconMask: true,
						iconCls: 'sidepanelrefresh',

						handler: function () {
							if (Wv.CommonUtils.getIfAvailable(this, 'up("[reference=sidepanel_ticketpanel]").down("recentticketssidepanelview")')) {
								var panel = this.up('[reference=sidepanel_ticketpanel]').down('recentticketssidepanelview');
								panel.customLoadData(panel);
							}
						}
					}],
					items: [{
						xtype: 'recentticketssidepanelview',
						customLoadData: function (panel) {
							if (panel) {
								if (Wv.CommonUtils.getIfAvailable(panel, '.xtype') == "recentticketssidepanelview") {
									panel.getController().updateButtons();
								} else if (Wv.CommonUtils.getIfAvailable(panel, '.down("recentticketssidepanelview").xtype') == "recentticketssidepanelview") {
									panel.down("recentticketssidepanelview").getController().updateButtons();
								}
							}
						}
					}],
				}, {
					style: 'overflow:hidden;',
					userCls: "communicationpanel",
					reference: 'sidepanel_communicationpanel',
					title: GlobalStrings.Title_Communications,
					tools: [{
						xtype: 'button',
						iconMask: true,
						iconCls: 'sidepanelrefresh',

						handler: function () {
							if (Wv.CommonUtils.getIfAvailable(this, 'up("[reference=sidepanel_communicationpanel]").down("messagingpanel")')) {
								var panel = this.up('[reference=sidepanel_communicationpanel]').down('messagingpanel');
								panel.customLoadData(panel);
							}
						}
					}],
					items: [{
						xtype: 'messagingpanel',
						customLoadData: function (messagingPanel) {
							Ext.Ajax.request({
								url: UrlManager.buildURL(UrlManager.apiURL(), "OATIWelcomePage/GetMessagingData"),
								scope: this,
								async: true,
								method: 'POST',
								success: function (data) {
									if (data && data.status == 200) {
										var messageData = JSON.parse(data.responseText);
										messagingPanel.up("welcomepage").controller.setMessageData(messagingPanel, messageData);
									}
								}.bind(this)
							});
						}
					}],
				}]
			}, {
				xtype: 'container',
				layout: 'column',
				reference: 'sidepanel_calendarhighlightpanel',
				items: [{
					columnWidth: .5,
					layout: {
						type: 'vbox',
						align: 'stretch'
					},
					title: GlobalStrings.Title_Calendar,
					reference: 'sidepanel_calendarpanel',
					scrollable: false,
					tools: [{
						xtype: 'button',
						iconMask: true,
						iconCls: 'sidepanelrefresh',
						handler: function () {
							if (Wv.CommonUtils.getIfAvailable(this, 'up("[reference=sidepanel_calendarpanel]").down("welcomepagesidepanelcalendar")')) {
								var panel = this.up('[reference=sidepanel_calendarpanel]').down('welcomepagesidepanelcalendar');
								panel.customLoadData(panel);
							}
						}
					}],
					items: [{
						xtype: 'welcomepagesidepanelcalendar',
						/**
						* @method customLoadData
						* @private
						* calls custom Load data.
						**/
						customLoadData: function (calendarpanel, globalRefresh) {
							if (Wv.CommonUtils.getIfAvailable($('#welcomePageSidePanelCalendarPanel'), ".fullCalendar('getView').calendar")) {
								if (Wv.CommonUtils.getIfAvailable(calendarpanel, ".xtype")) {
									var filterStartDate = new Date(Webvision.view.admindashboard.OATIAdminDashboardManager.welcomePageSelectedDate);
									var startDateView = $("#welcomePageSidePanelCalendarPanel").fullCalendar('getView').currentRange.start._d;
									var endDateView = $("#welcomePageSidePanelCalendarPanel").fullCalendar('getView').currentRange.end._d;
									Webvision.view.admindashboard.OATIAdminDashboardManager.getCalendarData(startDateView, endDateView, filterStartDate, endDateView, 'welcomePageSidePanelCalendarPanel', 'welcomePageSidePanelEventPanel', endDateView.getFullYear());
								}
							} else {
								if (Wv.CommonUtils.getIfAvailable(calendarpanel, '.xtype') == "welcomepagesidepanelcalendar") {
									calendarpanel.getController().addCalendar('welcomePageSidePanelCalendarPanel', 'welcomePageSidePanelEventPanel');

									if (Wv.CommonUtils.getIfAvailable($('#welcomePageSidePanelCalendarPanel'), ".fullCalendar('getView').calendar")) {
										if (Wv.CommonUtils.getIfAvailable(calendarpanel, ".xtype")) {
											var filterStartDate = new Date(Webvision.view.admindashboard.OATIAdminDashboardManager.welcomePageSelectedDate);
											var startDateView = $("#welcomePageSidePanelCalendarPanel").fullCalendar('getView').currentRange.start._d;
											var endDateView = $("#welcomePageSidePanelCalendarPanel").fullCalendar('getView').currentRange.end._d;
											Webvision.view.admindashboard.OATIAdminDashboardManager.getCalendarData(startDateView, endDateView, filterStartDate, endDateView, 'welcomePageSidePanelCalendarPanel', 'welcomePageSidePanelEventPanel', endDateView.getFullYear());
										}
									}

								} else if (Wv.CommonUtils.getIfAvailable(calendarpanel, '.down("welcomepagesidepanelcalendar").xtype') == "welcomepagesidepanelcalendar") {
									var filterStartDate = new Date(Webvision.view.admindashboard.OATIAdminDashboardManager.welcomePageSelectedDate);
									if (!Wv.CommonUtils.getIfAvailable($('#welcomePageSidePanelCalendarPanel'), ".fullCalendar('getView').calendar")) {
										if (Wv.CommonUtils.getIfAvailable(calendarpanel, ".up('dashboard').query('welcomepagecalendar')[0]")) {
											calendarpanel.up('dashboard').query('welcomepagesidepanelcalendar')[0].getController().addCalendar('welcomePageSidePanelCalendarPanel', 'welcomePageSidePanelEventPanel');
										}
									}

									var startDateView = $("#welcomePageSidePanelCalendarPanel").fullCalendar('getView').currentRange.start._d;
									var endDateView = $("#welcomePageSidePanelCalendarPanel").fullCalendar('getView').currentRange.end._d;
									Webvision.view.admindashboard.OATIAdminDashboardManager.getCalendarData(startDateView, endDateView, filterStartDate, endDateView, 'welcomePageSidePanelCalendarPanel', 'welcomePagSidePaneleEventPanel', endDateView.getFullYear());
								}
							}
						}

					}]
				}, {
					columnWidth: .5,
					layout: {
						type: 'vbox',
						align: 'stretch'
					},
					reference: 'sidepanel_highlightpanel',
					cls: 'welcomepage_sidepanelhighlightspanel',
					scrollable: true,
					userCls: "latestnewshighlighpanel",
					title: GlobalStrings.Title_OATIHighlights,
					tools: [{
						xtype: 'button',
						iconMask: true,
						iconCls: 'sidepanelrefresh',

						handler: function () {
							if (Wv.CommonUtils.getIfAvailable(this, 'up("[reference=sidepanel_highlightpanel]").down("highlightssidepanelview")')) {
								var panel = this.up('[reference=sidepanel_highlightpanel]').down('highlightssidepanelview');
								panel.customLoadData(panel);
							}
						}
					}],
					items: [{
						xtype: 'highlightssidepanelview',
						/**
					* @method customLoadData
					* @private
					* calls custom Load data.
					**/
						customLoadData: function (calendarpanel, globalRefresh) {
							if (Wv.CommonUtils.getIfAvailable(calendarpanel, '.xtype') == "highlightssidepanelview") {
								calendarpanel.getController().addHighlights();
							} else if (Wv.CommonUtils.getIfAvailable(calendarpanel, '.down("highlightssidepanelview").xtype') == "highlightssidepanelview") {
								calendarpanel.down("highlightssidepanelview").getController().addHighlights();
							}
						}

					}]
				}]
			}, {
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				scrollable: true,
				title: "Help Videos",
				reference: "sidepanel_helpvideospanel",
				cls: 'welcomepage_sidepanelhelpvideopanel',
				tools: [{
					xtype: 'button',
					iconMask: true,
					iconCls: 'sidepanelrefresh',
					handler: function () {
						if (Wv.CommonUtils.getIfAvailable(this, 'up("[reference=sidepanel_helpvideospanel]").down("helpvideossidepanelview")')) {
							var panel = this.up('[reference=sidepanel_helpvideospanel]').down('helpvideossidepanelview');
							panel.customLoadData(panel);
						}
					}
				}],
				items: [{
					xtype: 'helpvideossidepanelview',
					/**
				* @method customLoadData
				* @private
				* calls custom Load data.
				**/
					customLoadData: function (helpvideopanel, globalRefresh) {
						Ext.Ajax.request({
							url: UrlManager.buildURL(UrlManager.apiURL(), "OATIWelcomePage/GetHelpVideosdata"),
							scope: this,
							async: false,
							method: 'POST',
							success: function (data) {
								if (data && data.status == 200) {
									helpvideodata = JSON.parse(data.responseText);
									//me.welcomePageData.HelpVideosdata = helpvideodata;
									helpvideopanel.down("#helpvideossidepanel").update(helpvideodata)
								}
							}.bind(this)
						});
					}
				}]
			}, {
				xtype: 'container',
				layout: 'column',
				reference: 'sidepanel_feedbackandSummarypanel',
				cls: 'welcomepage_sidepanelfeedbackpanel',
				items: [{
					columnWidth: .45,
					title: "Feedback & Suggestions",
					itemId: 'feedbackpanel',
					resizable: false,
					scrollable: true,
					reference: 'sidepanel_feedbackpanel',
					cls: 'x-dashboard-panel',
					config: {
						draggable: false,
						closable: false,
						maximizable: false,
						resizable: false
					},
					items: [{
						xtype: 'container',
						itemId: 'feedbackFormInside',
						autoScroll: true,
						scrollable: true,
						hidden: true,
						listeners: {
							afterRender: function (panel) {
								if (!Ext.getCmp("feedback")) {
									Webvision.view.feedbackForm.OATIFeedbackForm.feedbackForm();
								}
							}
						}
					}]
				}, {
					columnWidth: .55,
					layout: {
						type: 'vbox',
						align: 'stretch'
					},
					scrollable: true,
					resizable: false,
					config: {
						draggable: false,
						closable: false,
						maximizable: false,
						resizable: false
					},
					title: "Feedback Summary",
					reference: 'sidepanel_feedbacksummarypanel',
					tools: [{
						xtype: 'button',
						iconMask: true,
						iconCls: 'sidepanelrefresh',
						handler: function () {
							if (Wv.CommonUtils.getIfAvailable(this, 'up("[reference=sidepanel_feedbacksummarypanel]").down("feedbacksummaryview")')) {
								var panel = this.up('[reference=sidepanel_feedbacksummarypanel]').down('feedbacksummaryview');
								panel.customLoadData(panel);
							}
						}
					}],
					items: [{
						xtype: 'feedbacksummaryview',
						/*
					* @method customLoadData
					* @private
					* calls custom Load data.
					*/
						customLoadData: function (feedbacksummarypanel, globalRefresh) {
							Ext.Ajax.request({
								url: UrlManager.buildURL(UrlManager.apiURL(), "OATIFeedbackLog/GetFeedbackDataByUser"),
								scope: this,
								async: true,
								method: 'POST',
								success: function (data) {
									if (data && data.status == 200) {
										var feedbacksummary = JSON.parse(data.responseText);
										var feedbacksummarydata = feedbacksummary.Data;
										var feedbacksummarypanelview = feedbacksummarypanel.down('#feedbacksummarypanelview');
										if (feedbacksummarydata.length != 0) {
											feedbacksummarypanelview.update(feedbacksummarydata);
										}
										else {
											if (feedbacksummarypanelview && !feedbacksummarypanelview.down('[reference=feedbacksummarypanelemptyfield]')) {
												feedbacksummarypanelview.add({
													xtype: 'displayfield',
													reference: 'feedbacksummarypanelemptyfield',
													value: 'No records found.',
													cls: 'feedbacksummarypanelempty'
												});
											}
											else {
												feedbacksummarypanelview.show();
											}
										}


									}
								}.bind(this)
							});
						}

					}]
				}]
			},
			// OATICONNECT (3/4): right-side container that mounts/unmounts the
			// OATIConnectView in lockstep with show/hide. This frees React +
			// SignalR + axios state when the user navigates away, and gives
			// a fresh single instance when they come back. Memory bounded.
			{
				layout: 'fit',
				header: false,
				reference: 'sidepanel_oaticonnectpanel',
				cls: 'welcomepage_sidepaneloaticonnectpanel',
				scrollable: false,
				// items intentionally empty — populated on `show`, cleared on `hide`.
				items: [],
				listeners: {
					show: function (panel) {
						try {
							panel.removeAll(true); // clear any stale child first
							panel.add({
								xtype: 'oaticonnectview',
								customLoadData: function () { /* no-op — bundle refreshes itself */ }
							});
							panel.updateLayout(true);
						} catch (e) { /* view's own error path will surface failures */ }
					},
					hide: function (panel) {
						try {
							// removeAll(true) destroys child components. The view's
							// beforedestroy listener removes the <oaticonnect-meet>
							// element, triggering the bundle's disconnectedCallback
							// (unmount React + tear down SignalR + cancel axios).
							panel.removeAll(true);
						} catch (e) { /* swallow */ }
					}
				}
			}]
		}]
	}],
	maxColumns: 3,
	isLoaded: false,
	widthOld: 0,
	columnWidths: [0.25, 0.43, 0.32],

	offsetMarginTop: 7,
	isDashboardResponsive: false,
	minHeight: {},
	originalDashboardHeight: null,
	originalVisualViewport: null,
	setDashboardMinimumHeight: true,
	plugins: [{
		ptype: 'refreshPlugin',
		periodicRefresh: true,
		hidePeriodicRefreshDropdown: true
	}],
	listeners: {
		afterrender: function (panel) {
			panel.addTool({
				xtype: 'button',
				itemId: 'highlightVoiceConfiguration',
				cls: 'trans-back-btn refreshicon pluginSummaryButton',
				reference: 'highlightVoiceConfiguration',
				iconCls: 'fas fa-volume-up glow highlightVolumeIcon ',
				userCls: "volmicon",
				style: 'background:none; width:44px;',
				menu: {
					xtype: 'menu',
					itemId: 'highlightVoiceConfigurationMenu',
					cls: 'VolumnToggleUI',
					hideOnSelect: false, //initialize flag to hide the menu
					listeners: {
						beforehide: function (menu) {
							if (menu.hideOnSelect) {
								menu.hideOnSelect = false;
								return true;
							}

							var activeElement = Ext.Element.getActiveElement();
							if (menu && menu.el && menu.el.contains(activeElement)) {
								return false;
							}
							return true;
						}
					},
					items: [
						// Menu Option: Configure Voice Settings.
						{
							iconCls: 'fas apptopicon fa-tools fa-fw glow',
							text: GlobalStrings.Title_VoiceSettings,
							listeners: {
								click: function (a, b, c, d) {
									var menu = this.up('menu');
									if (menu) {
										menu.hideOnSelect = true;
										menu.hide();
									}
									Wv.DisplayManager.openLink({ xtype: 'HubVoiceSynthesisSettingsView', title: GlobalStrings.Title_VoiceRecognitionSettings }, null, true);
								}
							}
						},
						{
							xtype: 'container',
							layout: {
								type: 'hbox',
								align: 'left'
							},

							items: [{
								xtype: 'oatitogglebutton',
								reference: 'Toggle1',
								padding: '0 10 0 0',
								cls: 'toggle-hubUi',
								listeners: {
									beforerender: function (field, e) {
										field.setToggle(Webvision.utils.HubSettings.getHubSettings().WelcomePageVoiceModes.CommunicationPanel == "Unmute" ? true : false);
									},
									change: function (field, value) {
										var me = this;
										var controller = Wv.CommonUtils.getIfAvailable(me, ".up('dashboard').getController()");
										controller.SaveWelcomePageVoiceModes('communicationpanel', value);
									}
								}
							}, {
								xtype: 'label',
								html: GlobalStrings.Title_NewMessage
							}]
						}, {
							xtype: 'container',
							layout: {
								type: 'hbox'
							},

							items: [{
								xtype: 'oatitogglebutton',
								reference: 'Toggle1',
								padding: '0 10 5 0',
								cls: 'toggle-hubUi',
								listeners: {
									beforerender: function (field, e) {
										field.setToggle(Webvision.utils.HubSettings.getHubSettings().WelcomePageVoiceModes.HighlightPanel == "Unmute" ? true : false);
									},
									change: function (field, value) {
										var me = this;
										var controller = Wv.CommonUtils.getIfAvailable(me, ".up('dashboard').getController()");
										controller.SaveWelcomePageVoiceModes('highlightpanel', value);
									}
								}
							}, {
								xtype: 'label',
								html: GlobalStrings.Label_NewNewsHighlights
							}]
						}, {
							xtype: 'container',
							layout: {
								type: 'hbox'
							},
							hidden: Webvision.app.GlobalVariables.getApplicationConfig().EnvironmentIndicatorText == 'QA' ? false : true,
							items: [{
								xtype: 'oatitogglebutton',
								reference: 'Toggle2',
								padding: '0 10 5 0',
								cls: 'toggle-hubUi',
								listeners: {
									beforerender: function (field, e) {
										field.setToggle(Webvision.utils.HubSettings.getHubSettings().WelcomePageVoiceModes.SystemDownAlerts == "Unmute" ? true : false);
									},
									change: function (field, value) {
										var me = this;
										var controller = Wv.CommonUtils.getIfAvailable(me, ".up('dashboard').getController()");
										controller.SaveWelcomePageVoiceModes('systemdownalerts', value);
									}
								}
							}, {
								xtype: 'label',
								html: GlobalStrings.Label_WelcomePageSystemDownAlertsVoiceMode
							}]
						}

					]
				}
			});

			this.getController().getWelcomePageData();
		},
		beforedestroy: function (cmp, e) {
			var feedbackform = Wv.CommonUtils.getIfAvailable(cmp, 'lookupReference("dockedItemRightBar").down("feedbacksummaryview").body.getById("feedbackWindow").component');

			if (feedbackform && feedbackform.hidden == false) {
				feedbackform.close();
			}

			if (Wv.DisplayManager.welcomePageView.appLayoutWind) {
				Wv.DisplayManager.welcomePageView.appLayoutWind.destroy();
			}
		},
		boxready: function () {
			var me = this;
			me.lookupReference('dockedItemRightBar').hide();
			me.originalDashboardHeight = me.body.getHeight() - me.offsetMargin - me.offsetBottomBar;
			me.originalVisualViewport = { height: visualViewport.height, width: visualViewport.width };

			var refreshTime = Webvision.utils.timeZone.OATIDateTimeHelper.getFormattedDateTime(new Date(), Wv.OATIUser.timezone, Wv.GlobalVar.getApplicationConfig().DefaultMomentDateTimeFormat, false);
			var time = refreshTime.substring(refreshTime.indexOf(" ") + 1, refreshTime.length);
			this.addTool({
				xtype: 'label',
				cls: 'refreshTimeCls',
				html: '<i> Refreshed at ' + time + ' ' + Wv.OATIUser.timezone + '</i>',
				itemId: 'refreshTime',
				reference: 'refreshTime'
			});

			var panel = this.query('dashboard-panel[hidden=false][id = "welcomepage_messagingpanel"]')[0];
			var headerSummary;
			if (panel && typeof panel.getHeader == 'function') {
				headerSummary = panel.getHeader();
				if (headerSummary && headerSummary != undefined) {
					headerSummary.el.addCls('dashboard_Cursor');
					var headerTitle = Wv.CommonUtils.getIfAvailable(headerSummary, '.title.el.dom.children[0]');
					if (headerTitle) {
						me.openAsNewTab(panel, headerTitle);
					}
					else {
						var headerTitle = Wv.CommonUtils.getIfAvailable(headerSummary, '.title.el.dom');
						me.openAsNewTab(panel, headerTitle)
					}
				}
			}
			me.setDockedItemBar = true;

		},
		resize: function (column, width, height, oldWidth, oldHeight) {
			var me = this;
			if (oldHeight >= 0 && column.isOatiDashboard) {
				Webvision.view.admindashboard.OATIAdminDashboardManager.setCalendarHeightForWelcomePage();
				$('[name=welcomePageCalendarPanel_eventTile]').css('max-width', $('#welcomepage_calendarpanel').width() * .65 + 'px');

				var dockedItemRightBar = me.lookupReference('dockedItemRightBar')
				if (!dockedItemRightBar.hidden) {
					var setDockWidth = me.up().body.getWidth() - me.lookupReference('dockedItemBar').getWidth() - 16;
					var setDockHeight = me.up().body.getHeight() - 90;
					dockedItemRightBar.setWidth(setDockWidth);
					Webvision.view.admindashboard.OATIAdminDashboardManager.setSidePanelCalendarHeightForWelcomePage();

					var selectedLeftSidebar = me.restoreStateLocally[me.stateId].selectedLeftSidebarItem
					if (selectedLeftSidebar == 2) {
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("recentticketssidepanelview")')) {
							dockedItemRightBar.down("recentticketssidepanelview").setWidth(setDockWidth);
						}
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("messagingpanel")')) {
							dockedItemRightBar.down("messagingpanel").setWidth(setDockWidth);
						}
					} else if (selectedLeftSidebar == 3) {
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("welcomepagesidepanelcalendar")')) {
							dockedItemRightBar.down("welcomepagesidepanelcalendar").setHeight(setDockHeight);
						}
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("highlightssidepanelview")')) {
							dockedItemRightBar.down("highlightssidepanelview").setHeight(setDockHeight);
						}
					} else if (selectedLeftSidebar == 4) {
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("helpvideossidepanelview")')) {
							dockedItemRightBar.down("helpvideossidepanelview").setHeight(setDockHeight);
						}
					}
					else if (selectedLeftSidebar == 5) {
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("#feedbackpanel")')) {
							dockedItemRightBar.down("#feedbackpanel").setHeight(setDockHeight);
						}
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("feedbacksummaryview")')) {
							dockedItemRightBar.down("feedbacksummaryview").setHeight(setDockHeight);

						}
						var feedbackform = Wv.CommonUtils.getIfAvailable(me, '.body.getById("feedbackWindow").component');
						if (feedbackform) {
							var feedbackFormHeight = 540;
							if (setDockHeight < 500) {
								feedbackFormHeight = 400;
							}
							feedbackform.setHeight(feedbackFormHeight);
						}
					}
					// OATICONNECT (4/4): size the embedded view to fill the right panel
					else if (selectedLeftSidebar == 6) {
						if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("oaticonnectview")')) {
							dockedItemRightBar.down("oaticonnectview").setHeight(setDockHeight);
							dockedItemRightBar.down("oaticonnectview").setWidth(setDockWidth);
						}
					}
				}
			}
		},
		onStateResetClick: function () {
			var dataview = this.lookupReference('dockedItemBarDataView');
			if (dataview.getSelection() && (dataview.getSelection().length == 0 || (dataview.getSelection().length > 0 && dataview.getSelection()[0].data.Id == 0 && Wv.CommonUtils.getIfAvailable(dataview, ".el.dom.getElementsByClassName('sidebarmenu')[0].className")))) {
				dataview.el.dom.getElementsByClassName('sidebarmenu')[0].className = "sidebarmenu x-item-selected";
			}
			this.getController().getWelcomePageData(null, true);
			this.setDashboardColumnWidth([0.25, 0.43, 0.32]);
		}
	},

	//Dashboard Parts
	//#region OatiDashboardPanel Methods
	parts: {
		welcometext: {
			viewTemplate: {
				layout: 'center',
				itemId: 'welcomepage_text',
				//userCls: 'welcomeLogoPanel',
				header: false,
				config: {
					draggable: false,
					expandcollapse: false,
					resizable: false
				},
				items: {
					xtype: 'container',
					margin: 0,
					padding: 0,
					cls: 'welcome-OATIText',
					layout: 'center',
					items: [{
						xtype: 'container',
						layout: {
							type: 'hbox',
							align: 'stretch'
						},
						items: [{
							xtype: 'image',
							src: '../HubResources/images/OATIHubLogo.png'
						},
						{
							xtype: 'panel',
							itemId: 'logoseparator',
							html: '<div id="logoseperator"></div>',
							cls: 'logoseparator',
							hidden: true
						},
						{
							xtype: 'image',
							itemId: 'logoimage',
							listeners: {
								beforeRender: function (img) {
								},
								afterRender: function (img) {
									var src = '../OATILogos/GetLogo?code=' + Wv.OATIUser.selectedOrganization.OrganizationWebCaresCodes;
									$.get(src, function (res) {
										var logoContainer = img.up('[itemId=welcomepage_text]');
										if (res && res.length > 0 && logoContainer) {
											logoContainer.query("[itemId=logoseparator]")[0].setHidden(false);
											img.setSrc(src);
											logoContainer.updateLayout();
										}
									})
								}
							}
						}]
					}]
				}
			}
		},
		calendarpanel: {
			viewTemplate: {
				config: {
					draggable: true,
					closable: false
				},
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				title: GlobalStrings.Title_Calendar,
				scrollable: false,
				plugins: [
					{
						ptype: 'refreshPlugin',
						periodicRefresh: false,
						hidePeriodicRefreshDropdown: true
					}
				],
				/**
				* @method customLoadData
				* @private
				* calls custom Load data.
				**/
				customLoadData: function (calendarpanel, globalRefresh) {
					if (Wv.CommonUtils.getIfAvailable($('#welcomePageCalendarPanel'), ".fullCalendar('getView').calendar")) {
						if (Wv.CommonUtils.getIfAvailable(calendarpanel, ".xtype")) {
							var filterStartDate = new Date(Webvision.view.admindashboard.OATIAdminDashboardManager.welcomePageSelectedDate);
							var startDateView = $("#welcomePageCalendarPanel").fullCalendar('getView').currentRange.start._d;
							var endDateView = $("#welcomePageCalendarPanel").fullCalendar('getView').currentRange.end._d;
							Webvision.view.admindashboard.OATIAdminDashboardManager.getCalendarData(startDateView, endDateView, filterStartDate, endDateView, 'welcomePageCalendarPanel', 'welcomePageEventPanel', endDateView.getFullYear());
						}
					} else {
						if (Wv.CommonUtils.getIfAvailable(calendarpanel, '.xtype') == "welcomepagecalendar") {
							calendarpanel.getController().addCalendar('welcomePageCalendarPanel', 'welcomePageEventPanel');
						} else if (Wv.CommonUtils.getIfAvailable(calendarpanel, '.down("welcomepagecalendar").xtype') == "welcomepagecalendar") {
							var filterStartDate = new Date(Webvision.view.admindashboard.OATIAdminDashboardManager.welcomePageSelectedDate);
							var startDateView = $("#welcomePageCalendarPanel").fullCalendar('getView').currentRange.start._d;
							var endDateView = $("#welcomePageCalendarPanel").fullCalendar('getView').currentRange.end._d;
							Webvision.view.admindashboard.OATIAdminDashboardManager.getCalendarData(startDateView, endDateView, filterStartDate, endDateView, 'welcomePageCalendarPanel', 'welcomePageEventPanel', endDateView.getFullYear());
						}
					}
					if (!globalRefresh) {
						if (typeof calendarpanel.up == "function") {
							var mainPanel = calendarpanel.up("welcomepage");
							if (mainPanel) {
								mainPanel.getController().updateRefreshTime(mainPanel);
							}
						}
					}
				},
				items: {
					xtype: 'welcomepagecalendar'
				}
			},
			maximizePortlet: function (panel) {
				Webvision.view.admindashboard.OATIAdminDashboardManager.setCalendarHeightForWelcomePage();
			},
			restorePortlet: function (panel) {
				Webvision.view.admindashboard.OATIAdminDashboardManager.setCalendarHeightForWelcomePage();
			}
		},
		productaccesspanel: {
			viewTemplate: {
				config: {
					draggable: true,
					resizable: true,
					closable: false
				},
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				cls: 'ProductAccess-panel',
				title: GlobalStrings.Title_ProductAccess,
				header: true,
				titleAlign: 'left',
				scrollable: false,
				FilterData: '{"productaccesspanelfilter":"All"}',
				tools: [{
					xtype: 'button',
					hidden: true,
					html: Webvision.utils.HubSettings.getHubSettings().SSOApplicationOpenMode == 'Tab' ? '<span class="hubnew_ssoicon"><img src="../HubResources/images/newTabImg.svg" class="hubtabiconsvg" /></span>' : '<span class="hubnew_ssoicon"><img src="../HubResources/images/popupImg.svg" class="hubpopupiconsvg" /></span>',
					tooltip: Webvision.utils.HubSettings.getHubSettings().SSOApplicationOpenMode == 'Tab' ? GlobalStrings.Label_OpenAsTab : GlobalStrings.Label_OpenAsPopup,
					cls: 'trans-back-btn pluginSummaryButton ssoproductbtn',
					listeners: {
						click: function (a, b, c, d) {
							// Default mode is tab
							var me = this;
							var html = "";
							if (me.text.indexOf("newTabImg.svg") > 1) {
								html = '<span class="hubnew_ssoicon"><img src="../HubResources/images/popupImg.svg" class="hubpopupiconsvg" /></span>';
								me.setTooltip(GlobalStrings.Label_OpenAsPopup);
								Webvision.view.welcomepage.OATIApplicationLayoutManager.saveSsoApplicationOpenMode('Popup');
							} else {
								html = '<span class="hubnew_ssoicon"><img src="../HubResources/images/newTabImg.svg" class="hubtabiconsvg" /></span>';
								me.setTooltip(GlobalStrings.Label_OpenAsTab);
								Webvision.view.welcomepage.OATIApplicationLayoutManager.saveSsoApplicationOpenMode('Tab');
							}
							me.setHtml(html);
							me.setText(html);
						}
					}
				}, {
					xtype: 'splitbutton',
					//itemId: 'layoutButtonFrmk',
					reference: 'ShowApplicationLayoutIcon',
					iconCls: 'far apptopicon fa-table prodPanel glow-only',
					tooltip: GlobalStrings.Tooltip_CreateNewLayout,
					style: 'background:none; padding: 0px 0px 0px 0px !important;',
					cls: 'appTopPanelCls refreshPlugin layoutikon',
					menu: {
						xtype: 'menu',
						items: [
							{
								text: GlobalStrings.Tooltip_CreateNewLayout,
								hideOnClick: false,
								handler: 'onApplicationLayoutBtnClicked'
							}]
					},
					listeners: {
						click: 'onApplicationLayoutBtnClicked',
						menushow: function (btn, menu) {
							this.up('welcomepage').getController().onApplicationLayoutMenuShow(btn, menu);
						}
					}
				}],
				items: {
					xtype: 'productaccessview'
				},
				plugins: [{
					ptype: 'refreshPlugin',
					periodicRefresh: false,
					hidePeriodicRefreshDropdown: true
				}],
				/**
				* @method customLoadData
				* @private
				* calls custom Load data.
				**/
				customLoadData: function (productAccess, extraParams) {
					if (Wv.CommonUtils.getIfAvailable(productAccess, '.down("[reference=productaccesspanel]").xtype') == "dataview") {
						Ext.Ajax.request({
							url: UrlManager.buildURL(UrlManager.apiURL(), "OATIWelcomePage/GetProductAccessData"),
							params: {},
							scope: this,
							async: true,
							method: 'POST',
							success: function (data) {
								if (data && data.status == 200) {
									var result = JSON.parse(data.responseText);
									productAccess.up("welcomepage").controller.setApplicationLayoutManager(productAccess, result);
								}
							}.bind(this)
						})
					}
				}
			}
		},
		messagingpanel: {
			viewTemplate: {
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				title: GlobalStrings.Title_Communications,
				scrollable: true,
				padding: "3 0 0 0",
				userCls: "communicationpanel",
				items: {
					xtype: 'messagingpanel'
				},
				config: {
					draggable: true,
					resizable: true,
					closable: false
				},
				plugins: [{
					ptype: 'refreshPlugin',
					periodicRefresh: true,
					hidePeriodicRefreshDropdown: true
				}],
				/**
				* @method customLoadData
				* @private
				* calls custom Load data.
				**/
				customLoadData: function (messagingPanel, globalRefresh) {
					Ext.Ajax.request({
						url: UrlManager.buildURL(UrlManager.apiURL(), "OATIWelcomePage/GetMessagingData"),
						scope: this,
						async: true,
						method: 'POST',
						success: function (data) {
							if (data && data.status == 200) {
								var messageData = JSON.parse(data.responseText);
								messagingPanel.up("welcomepage").controller.setMessageData(messagingPanel, messageData);
							}
						}.bind(this)
					})

					if (!globalRefresh) {
						if (typeof messagingPanel.up == "function") {
							var mainPanel = messagingPanel.up("welcomepage");
							if (mainPanel) {
								mainPanel.getController().updateRefreshTime(mainPanel);
							}
						}
					}
				}
			}
		},
		ticketspanel: {
			viewTemplate: {
				config: {
					draggable: true,
					resizable: true,
					closable: false
				},
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				title: GlobalStrings.Title_RecentTickets,
				userCls: "welcomepage_ticketsummary",
				items: {
					xtype: 'recentticketsview'
				},
				plugins: [{
					ptype: 'refreshPlugin',
					periodicRefresh: false,
					hidePeriodicRefreshDropdown: true
				}],
				customLoadData: function (panel, globalRefresh) {
					if (panel) {
						if (panel.mask) panel.mask(GlobalStrings.Label_Loading);
						if (Wv.CommonUtils.getIfAvailable(panel, '.xtype') == "recentticketsview") {
							panel.getController().updateButtons();
						} else if (Wv.CommonUtils.getIfAvailable(panel, '.down("recentticketsview").xtype') == "recentticketsview") {
							panel.down("recentticketsview").getController().updateButtons();
						}

						if (!globalRefresh) {
							if (typeof panel.up == "function") {
								var mainPanel = panel.up("welcomepage");
								if (mainPanel) {
									mainPanel.getController().updateRefreshTime(mainPanel);
								}
							}
						}
						if (panel.mask) {
							setTimeout(function () {
								panel.unmask();
							}, 10);
						}
					}
				}
			}
		},
		highlightspanel: {
			viewTemplate: {
				config: {
					draggable: true,
					resizable: true,
					closable: false
				},
				cls: 'welcomepage_highlightspanel',
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				flex: 1,
				scrollable: true,
				padding: "3 0 0 0",
				userCls: "latestnewshighlighpanel",
				title: GlobalStrings.Title_OATIHighlights,
				items: {
					xtype: 'highlightsview'
				},
				plugins: [{
					ptype: 'refreshPlugin',
					periodicRefresh: true,
					hidePeriodicRefreshDropdown: true
				}],
				customLoadData: function (panel, globalRefresh) {
					if (panel) {
						var mainPanel = panel.up("welcomepage");
						if (Wv.CommonUtils.getIfAvailable(panel, '.xtype') == "highlightsview") {
							panel.getController().addHighlights();
						} else if (Wv.CommonUtils.getIfAvailable(panel, '.down("highlightsview").xtype') == "highlightsview") {
							panel.down("highlightsview").getController().addHighlights();
						}
						if (!globalRefresh) {
							if (typeof panel.up == "function") {
								if (mainPanel) {
									mainPanel.getController().updateRefreshTime(mainPanel);
								}
							}
						}
					}
				}
			}
		},
		helpvideospanel: {
			viewTemplate: {
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				config: {
					draggable: true,
					resizable: true,
					closable: false,
					maximizable: false
				},
				title: "Help Videos",
				items: {
					xtype: 'helpvideossview'
				},
				header: true,
				titleAlign: 'left',
				plugins: [{
					ptype: 'refreshPlugin',
					periodicRefresh: false,
					hidePeriodicRefreshDropdown: true
				}],
				customLoadData: function (panel, globalRefresh) {

					Ext.Ajax.request({
						url: UrlManager.buildURL(UrlManager.apiURL(), "OATIWelcomePage/GetHelpVideosdata"),
						scope: this,
						async: true,
						method: 'POST',
						success: function (data) {
							if (data && data.status == 200) {
								var videoData = JSON.parse(data.responseText);
								panel.up("welcomepage").controller.setHelpVideossData(panel, videoData);

							}
						}.bind(this)
					});



					if (!globalRefresh) {
						if (typeof panel.up == "function") {
							var mainPanel = panel.up("welcomepage");
							if (mainPanel) {
								mainPanel.getController().updateRefreshTime(mainPanel);
							}
						}
					}

				}

			}
		},
		oaticonnectpanel: {
			viewTemplate: {
				layout: {
					type: 'vbox',
					align: 'stretch'
				},
				config: {
					draggable: true,
					resizable: true,
					closable: false,
					maximizable: false
				},
				title: "Help Videos",
				items: {
					xtype: 'helpvideossview'
				},
				header: true,
				titleAlign: 'left',
				plugins: [{
					ptype: 'refreshPlugin',
					periodicRefresh: false,
					hidePeriodicRefreshDropdown: true
				}],
				customLoadData: function (panel, globalRefresh) {

					Ext.Ajax.request({
						url: UrlManager.buildURL(UrlManager.apiURL(), "OATIWelcomePage/GetHelpVideosdata"),
						scope: this,
						async: true,
						method: 'POST',
						success: function (data) {
							if (data && data.status == 200) {
								var videoData = JSON.parse(data.responseText);
								panel.up("welcomepage").controller.setHelpVideossData(panel, videoData);

							}
						}.bind(this)
					});



					if (!globalRefresh) {
						if (typeof panel.up == "function") {
							var mainPanel = panel.up("welcomepage");
							if (mainPanel) {
								mainPanel.getController().updateRefreshTime(mainPanel);
							}
						}
					}

				}

			}
		}
	},
	//#endregion

	defaultContent: [{
		type: 'welcometext',
		id: 'welcomepage_text',
		columnIndex: 0
	}, {
		type: 'calendarpanel',
		id: 'welcomepage_calendarpanel',
		columnIndex: 0
	}, {
		type: 'ticketspanel',
		id: 'welcomepage_ticketspanel',
		columnIndex: 1
	},
	{
		type: 'productaccesspanel',
		id: 'welcomepage_productaccesspanel',
		columnIndex: 1
	}, {
		type: 'helpvideospanel',
		id: 'welcomepage_helpvideospanel',
		columnIndex: 1
	}, {
		type: 'oaticonnectpanel',
		id: 'welcomepage_oaticonnectpanel',
		columnIndex: 1
	}, {
		type: 'messagingpanel',
		id: 'welcomepage_messagingpanel',
		columnIndex: 2
	}, {
		type: 'highlightspanel',
		id: 'welcomepage_highlightspanel',
		columnIndex: 2
	}
	],
	initComponent: function () {
		var me = this;



		/* ----- begin Periodic Refresh Configurations ----- */
		var panels = new Ext.util.HashMap();
		panels.add('applicationAccess', me.parts.getByKey('productaccesspanel').config.viewTemplate);
		panels.add('calendar', me.parts.getByKey('calendarpanel').config.viewTemplate);
		panels.add('communications', me.parts.getByKey('messagingpanel').config.viewTemplate);
		panels.add('helpVideos', me.parts.getByKey('helpvideospanel').config.viewTemplate);
		panels.add('highlights', me.parts.getByKey('highlightspanel').config.viewTemplate);
		panels.add('ticketSummary', me.parts.getByKey('ticketspanel').config.viewTemplate);

		// Initially set all periodic refresh settings to false.
		if (me.DisplayInformation.State == null) {
			me.DisplayInformation.State = {
				"DataSummaryState": {
					"RefreshMetaData": "Disabled"
				}
			}
		}
		else if (me.DisplayInformation.State.DataSummaryState == null) {
			me.DisplayInformation.State.DataSummaryState = {
				"RefreshMetaData": "Disabled"
			}
		}
		else {
			me.DisplayInformation.State.DataSummaryState.RefreshMetaData = "Disabled";
		}

		var periodicRefreshConfigurations = Webvision.utils.HubSettings.getHubSettings(true).WelcomePagePeriodicRefresh;

		me.configurations.mapPeriodicRefresh.add('globalControl', periodicRefreshConfigurations.GlobalControl);
		me.configurations.mapPeriodicRefresh.add('applicationAccess', periodicRefreshConfigurations.ApplicationAccess);
		me.configurations.mapPeriodicRefresh.add('calendar', periodicRefreshConfigurations.Calendar);
		me.configurations.mapPeriodicRefresh.add('communications', periodicRefreshConfigurations.Communications);
		me.configurations.mapPeriodicRefresh.add('helpVideos', periodicRefreshConfigurations.HelpVideos);
		me.configurations.mapPeriodicRefresh.add('highlights', periodicRefreshConfigurations.Highlights);
		me.configurations.mapPeriodicRefresh.add('ticketSummary', periodicRefreshConfigurations.TicketSummary);

		// if any panels (or global control) have periodic refresh configured to be true, apply periodic refresh to top level welcome page
		me.applyPeriodicRefreshConfigurations(me, me.configurations.mapPeriodicRefresh.getValues().includes(true));

		for (let key of panels.getKeys()) {
			me.applyPeriodicRefreshConfigurations(panels.map[key], me.configurations.mapPeriodicRefresh.map[key]);
		}

		//var multDispINfo = Wv.DisplayManager.getMultipleDisplayInformation(["messagingpanel|true|0", "calendarpanel|true|0", "ticketspanel|true|0", "productaccesspanel|true|0", "helpvideospanel|true|0", "feedbackpanel|true|0", "feedbacksummarypanel|true|0", "highlightsview|true|0"]);

		// displayinformation clone
		var highlightsDisplayInformation = Wv.DisplayToolbar.deepCopy(me.DisplayInformation);
		highlightsDisplayInformation.ClassName = "highlightsview";
		highlightsDisplayInformation.DisplayName = "highlightsview";
		highlightsDisplayInformation.State = null;
		me.parts.map["highlightspanel"].config.viewTemplate.DisplayInformation = highlightsDisplayInformation;

		var messagingDisplayInformation = Wv.DisplayToolbar.deepCopy(me.DisplayInformation);
		messagingDisplayInformation.ClassName = "messagingpanel";
		messagingDisplayInformation.DisplayName = "messagingpanel";
		messagingDisplayInformation.State = null;
		me.parts.map["messagingpanel"].config.viewTemplate.DisplayInformation = messagingDisplayInformation;

		var calendarDisplayInformation = Wv.DisplayToolbar.deepCopy(me.DisplayInformation);
		calendarDisplayInformation.ClassName = "calendarpanel";
		calendarDisplayInformation.DisplayName = "calendarpanel";
		calendarDisplayInformation.State = null;
		me.parts.map["calendarpanel"].config.viewTemplate.DisplayInformation = calendarDisplayInformation;

		var ticketspanelDisplayInformation = Wv.DisplayToolbar.deepCopy(me.DisplayInformation);
		ticketspanelDisplayInformation.ClassName = "ticketspanel";
		ticketspanelDisplayInformation.DisplayName = "ticketspanel";
		ticketspanelDisplayInformation.State = null;
		me.parts.map["ticketspanel"].config.viewTemplate.DisplayInformation = ticketspanelDisplayInformation;

		var productAccessPanelDisplayInformtion = Wv.DisplayToolbar.deepCopy(me.DisplayInformation);
		productAccessPanelDisplayInformtion.ClassName = "productaccesspanel";
		productAccessPanelDisplayInformtion.DisplayName = "productaccesspanel";

		// The below code retained the Filter data settings used by product panel
		productAccessPanelDisplayInformtion.State = Wv.DisplayManager.getDisplayInformation('productaccesspanel', true, false, 0).State;
		if (productAccessPanelDisplayInformtion.State && productAccessPanelDisplayInformtion.State.DataSummaryState && productAccessPanelDisplayInformtion.State.DataSummaryState.FiltersMetaData) {
			me.parts.map["productaccesspanel"].config.viewTemplate.FilterData = productAccessPanelDisplayInformtion.State.DataSummaryState.FiltersMetaData;
			if (Wv.CommonUtils.getIfAvailable(me, ".dockedItems[1].items[0].items[0]")) {
				me.dockedItems[1].items[0].items[0].FilterData = productAccessPanelDisplayInformtion.State.DataSummaryState.FiltersMetaData;
			}

		}

		productAccessPanelDisplayInformtion.State = null;
		me.parts.map["productaccesspanel"].config.viewTemplate.DisplayInformation = productAccessPanelDisplayInformtion;




		var helpVideosPanelDisplayInformation = Wv.DisplayToolbar.deepCopy(me.DisplayInformation);
		helpVideosPanelDisplayInformation.ClassName = "helpvideospanel";
		helpVideosPanelDisplayInformation.DisplayName = "helpvideospanel";
		helpVideosPanelDisplayInformation.State = null;
		me.parts.map["helpvideospanel"].config.viewTemplate.DisplayInformation = helpVideosPanelDisplayInformation;
		/* ----- end Periodic Refresh Configurations ----- */


		// set auto-references..
		me.id = me.xtype;
		Ext.Array.forEach(me.parts.items, function (item) {
			item.config.viewTemplate.reference = item.config.id;
		});
		Ext.Array.forEach(me.defaultContent, function (item) {
			var dash = me;
			item.stateId = item.id;
			item.itemId = item.id;
			var partsItem = me.getPart(item.type);
			var itemTemplate = partsItem.config.viewTemplate;
			itemTemplate.stateId = item.id;
		}, me);

		me.callParent();

	},

	disableRefreshMetaData: function (displayInformation) {
		if (displayInformation.State == null) {
			displayInformation.State = {
				"DataSummaryState": {
					"RefreshMetaData": "Disabled"
				}
			}
		}
		else if (displayInformation.State.DataSummaryState == null) {
			displayInformation.State.DataSummaryState = {
				"RefreshMetaData": "Disabled"
			}
		}
		else {
			displayInformation.State.DataSummaryState.RefreshMetaData = "Disabled";
		}
	},

	applyPeriodicRefreshConfigurations: function (panel, enablePeriodicRefresh) {
		me = panel;
		if (me.DisplayInformation && me.DisplayInformation.DisplayName == 'welcomepage') {
			/* if called for global welcome page, set status of RefreshMetaData to 'Enabled'.  Will not be done for individual panels
			 * 	as we wish for only the top level customLoadData function be called, not the customLoadData calls of individual panels.
			 */
			if (me.DisplayInformation.State == null) {
				me.DisplayInformation.State = {
					"DataSummaryState": {
						"RefreshMetaData": enablePeriodicRefresh ? "Enabled" : "Disabled"
					}
				}
			}
			else if (me.DisplayInformation.State.DataSummaryState == null) {
				me.DisplayInformation.State.DataSummaryState = {
					"RefreshMetaData": enablePeriodicRefresh ? "Enabled" : "Disabled"
				}
			}
			else {
				me.DisplayInformation.State.DataSummaryState.RefreshMetaData = enablePeriodicRefresh ? "Enabled" : "Disabled";
			}
		}

		var plugins = panel.plugins;
		if (plugins != null) {
			var refreshPlugin = plugins.find((x) => x.ptype == "refreshPlugin");

			if (refreshPlugin != null) {
				refreshPlugin.periodicRefresh = enablePeriodicRefresh;
			}
			else {
				refreshPlugin = {
					ptype: 'refreshPlugin',
					periodicRefresh: enablePeriodicRefresh
				};
				plugins.push(refreshPlugin);
			}
		}
		else {
			panel.plugins = [{
				ptype: 'refreshPlugin',
				periodicRefresh: enablePeriodicRefresh
			}];
		}
	},

	resetColumnWidth: function (grid) {
		grid.columnConfigReset = true;
		Wv.DisplayToolbar.resetColumns(grid, true);
		grid.columnConfigReset = false;
	},
	customLoadData: function (grid, params) {
		var isPeriodicRefresh = (params != null && params.isIgnoreInactivityMonitor == true);
		var refreshConfigs = null;
		// if done through auto refresh, pass specific panels to refresh for.
		if (isPeriodicRefresh) {
			refreshConfigs = this.configurations.mapPeriodicRefresh;
		}
		this.getController().getWelcomePageData(refreshConfigs);
	},
	/**
	* @method openAsNewTab : This will set cursor style for title and will attach click event to title.
	* @param {Object} param current object.
	* @param {Object} headerTitle the headerTitle object.
	**/
	openAsNewTab: function (param, headerTitle) {
		if (!param)
			return;
		if (headerTitle) {
			var title = headerTitle.innerText;
			var spn = document.createElement("span");
			headerTitle.innerText = "";
			headerTitle.appendChild(spn);
			headerTitle.children[0].innerText = title;
			headerTitle.children[0].addEventListener('click', function () {
				//To remove New Message Badge
				var messageCountPanel = param.down('messagingpanel').down('#messageCountPanel');
				param.down('messagingpanel').removeNewMessageBadge(messageCountPanel);
				Webvision.utils.DisplayManager.openLink({ xtype: 'OATIMessageMainPanels' }, null, null);
			});
		}
	},

	//OatiDashboardPanel Methods
	//#region OatiDashboardPanel Methods

	/**
	 * @method getDashboardState
	 * get dashboard state with height and collapsed.
	 */
	getDashboardState: function () {
		var me = this;
		var state = me.getState();
		var dashHeight = me.body.getHeight() - me.offsetMargin - me.offsetBottomBar;
		if (dashHeight <= 530) {
			dashHeight = 530;
		}
		for (var i = 0; i < state.items.length; i++) {
			var item = state.items[i];
			var itemC = me.down('[itemId=' + item.itemId + ']');
			if (itemC && itemC.xtype == "dashboard-panel") {
				if (itemC.defHeight) {
					item.height = itemC.defHeight;
				}
				else if (itemC.getHeight() == 90) {
					item.height = me.restoreStateLocally[me.stateId].items[item.itemId].height;
				}
				else {
					item.height = (100 * (itemC.getHeight()) / (dashHeight));
				}
				if (me.isMaximizePanel) {
					item.height = itemC.restoreMaximizeHeight;
				}

				if (itemC.prevColumnIndex) {
					item.columnIndex = itemC.prevColumnIndex;
				}
				item.collapsed = itemC.collapsed;
				item.closed = false;
				if (itemC.collapsed != false) {
					item.collapseDirection = itemC.collapseDirection;
					var collapsedState = $.extend(true, {}, itemC.getState()).collapsed;
					collapsedState["height"] = (100 * (collapsedState["height"]) / (dashHeight));
					collapsedState["last.height"] = (100 * (collapsedState["last.height"]) / (dashHeight));
					item.collapsedState = collapsedState;
					item.collapseHeight = me.restoreStateLocally[me.stateId].items[item.itemId].collapseHeight;
				}
			}
		}
		state.prevColumnWidths = me.restoreStateLocally[me.stateId].prevColumnWidths;
		if (me.isMaximizePanel) {
			state.columnWidths = me.restoreMaximizeColumnWidth;
		}
		if (me.ClosedPanel[me.stateId].length > 0) {
			state.items = state.items.concat(me.ClosedPanel[me.stateId]);
		}
		return state;
	},
	/**
	 * @method setDashboardState
	 * apply dashboard state with height and collapsed.
	 */
	setDashboardState: function (state) {
		var me = this, columnWidths;
		var dashHeight = me.body.getHeight() - me.offsetMargin - me.offsetBottomBar;
		if (dashHeight <= 530) {
			dashHeight = 530;
		}
		var dataview = me.lookupReference('dockedItemBarDataView');
		var currentVisualViewport = { height: visualViewport.height, width: visualViewport.width };
		Wv.CommonUtils.runWithLayoutsSuspended(function () {
			if (state) {
				for (var i = 0; i < state.items.length; i++) {
					var item = state.items[i];
					var itemC = me.down('[itemId=' + item.itemId + ']');
					if (itemC && itemC.xtype == "dashboard-panel") {
						var height = 'auto';
						if (itemC.defHeight) {
							height = itemC.defHeight;
						}
						else {
							height = dashHeight * (item.height / 100);
						}
						var collapsed = false;
						if (item.collapsed) {
							itemC.collapseDirection = item.collapseDirection;
							collapsed = {};
							collapsed["height"] = dashHeight * (item.collapsedState["height"] / 100);;
							collapsed["last.height"] = dashHeight * (item.collapsedState["last.height"] / 100);
							if (me.restoreStateLocally[me.stateId].items[itemC.itemId] && item.height) {
								me.restoreStateLocally[me.stateId].items[itemC.itemId].height = item.height;
							}
							if (me.restoreStateLocally[me.stateId].items[itemC.itemId] && item.collapseHeight) {
								me.restoreStateLocally[me.stateId].items[itemC.itemId].collapseHeight = item.collapseHeight;
							}

							if (Wv.CommonUtils.getIfAvailable(itemC, ".query('[itemId=expandcollapse]')[0]")) {
								itemC.query('[itemId=expandcollapse]')[0].hide();
							}
							if (item.collapseDirection == "top") {
								if (Wv.CommonUtils.getIfAvailable(itemC, ".query('[type=collapse-bottom]')[0]")) {
									itemC.query('[type=collapse-bottom]')[0].show();
								}
								if (Wv.CommonUtils.getIfAvailable(itemC, ".tools['maximize']")) {
									itemC.tools['maximize'].show();
									itemC.tools['maximize'].setDisabled(true);
								}
							}
						}
						else {
							if (me.restoreStateLocally[me.stateId].items[itemC.itemId] && item.height) {
								if (me.isMaximizePanel && itemC.restoreMaximizeHeight) {
									me.restoreStateLocally[me.stateId].items[itemC.itemId].height = itemC.restoreMaximizeHeight;
								} else {
									me.restoreStateLocally[me.stateId].items[itemC.itemId].height = item.height;
								}
							}
							if (me.restoreStateLocally[me.stateId].items[itemC.itemId] && item.collapseHeight) {
								if (me.isMaximizePanel && itemC.restoreMaximizeHeight) {
									me.restoreStateLocally[me.stateId].items[itemC.itemId].collapseHeight = itemC.restoreMaximizeHeight;
								} else {
									me.restoreStateLocally[me.stateId].items[itemC.itemId].collapseHeight = item.collapseHeight;
								}

							}
						}
						itemC.applyState({ height: height, collapsed: collapsed });
					}
				}
				columnWidths = state.columnWidths;
			}
			else {
				var activeTab = me.getDisplayManager().getActiveTab();
				var index = me.getDisplayManager().mainAppTabPanel.items.findIndex('DisplayId', me.DisplayInformation.DisplayId);
				if (index >= 0) {
					activeTab = me.getDisplayManager().mainAppTabPanel.items.getAt(index);
				}
				var defstate = activeTab.defaultState[me.stateId];
				defstate = $.extend(true, {}, defstate);
				columnWidths = defstate.columnWidths;
				me.makeDashboardResponsive();
			}
		}, me);
		var dataview = me.lookupReference('dockedItemBarDataView');
		if (dataview.getSelection() && (dataview.getSelection().length == 0 || (dataview.getSelection().length > 0 && dataview.getSelection()[0].data.Id == 0))) {
			if (me.isMaximizePanel) {
				me.setDashboardColumnWidth(1);
				var itemC = me.query('dashboard-panel[hidden=false]')[0];
				itemC.setHeight(dashHeight);
			}
			else {
				me.setDashboardColumnWidth(columnWidths);
			}
			if (!me.isDashboardPanelResizeEventAttach) {
				setTimeout(function () {
					Wv.CommonUtils.runWithLayoutsSuspended(function () {
						var dashColumns = me.items;
						for (var i = 0; i < dashColumns.length; i++) {
							var dashColumnsItem = dashColumns.items[i];
							if (!dashColumnsItem.isSplitter) {
								for (var j = 0; j < dashColumnsItem.items.items.length; j++) {
									var itemC = dashColumnsItem.items.items[j];
									me.attachEvents(itemC);
									if (itemC && itemC.getHeight() < 90 && itemC.isVisible()) {
										var collapseHeight = me.restoreStateLocally[me.stateId].items[itemC.itemId].collapseHeight;
										me.restoreStateLocally[me.stateId].items[itemC.itemId].collapseHeight = collapseHeight;
									}
								}
							}
						}
						me.updateLayout(true);
					}, me);
					Wv.DisplayPerformanceBenchmark.SafeStop(me, "DisplayInformation.bench", "Full Load");
				}, 500);
				me.isDashboardPanelResizeEventAttach = true;
			}
		}
		else {
			me.controller.setHeightResponsive();
		}
		if (me.setDockedItemBar) {
			if (me.lookupReference('dockedItemBarDataView')) {
				var leftSidebar = me.lookupReference('dockedItemBarDataView');
				var dashboardDisplayState = me.getDisplayInformationState();
				if (dashboardDisplayState) {
					var selectedRecordId = dashboardDisplayState.selectedLeftSidebarItem;
					// OATICONNECT: never restore to OATIConnect (Id 6) as the
					// initial selection — Dashboard is the always-default landing
					// tab. Stale state from earlier builds may still hold 6.
					if (selectedRecordId === 6 || selectedRecordId === '6') {
						selectedRecordId = 0;
						if (me.restoreStateLocally && me.restoreStateLocally[me.stateId]) {
							me.restoreStateLocally[me.stateId].selectedLeftSidebarItem = 0;
						}
					}
					if (selectedRecordId) {
						var selectedRecord = leftSidebar.store.data.items.find((el) => el.data.Id == selectedRecordId);
						if (selectedRecord) {
							me.getController().setStateLocally();
							me.getController().sidePanelItemClick(leftSidebar, selectedRecord);
						}
					}
				}
			}
			delete me.setDockedItemBar;
		}

		me.originalDashboardHeight = dashHeight;
		me.originalVisualViewport = currentVisualViewport;
	},
	/**
	* @method onCollapsePanel
	* collapse dashboard panel.
	* @param {object} column .
	* @param {boolean} isNextPanel .
	* @private
	*/
	onCollapsePanel: function (column, isNextPanel) {
		var me = this;
		if (column.expandcollapse) {
			me.isDashboardReset = false;
			Wv.CommonUtils.runWithLayoutsSuspended(function () {
				if (!me.isDashboardPanelResetClick) {
					if (column.collapseDirection == "left" || column.collapseDirection == "right") {
						var isColColllapse = true, colWidth = 0.03, checkCollapse = ['left', 'right'], nextCol = [];
						var col = column.up('dashboard-column');
						var colPanel = col.query('dashboard-panel[hidden=false]');
						Ext.Array.each(colPanel, function (item) {
							var isColl = false;
							if (item.collapseDirection == "left" || item.collapseDirection == "right") {
								var coll = item.collapsed;
								if (coll == true || checkCollapse.indexOf(coll) >= 0) {
									coll = true;
								}
								if (column != item && coll == false) {
									isColl = true;
								}
							}
							else {
								isColl = true;
							}
							if (isColl) {
								isColColllapse = false;
								return false;
							}
						});
						if (isColColllapse) {
							var dashColumns = [], nextColIndex;
							var dashColumns = me.query('dashboard-column');
							var dashRowColumns = me.query('dashboard-column[rowIndex=' + col.rowIndex + ']');
							var colIndex = column.columnIndex;
							nextColIndex = me.getDashboardNextColumnHorizontal(colIndex, col, [], 'collapse');
							nextCol = Ext.Array.filter((dashRowColumns), function (c) {
								return c == dashColumns[nextColIndex]
							});
							if (nextColIndex != -1 && nextCol.length > 0) {
								var state = me.getDashboardState();
								var stateColumnWidths = state.columnWidths;
								var columnWidths = [];
								Ext.Array.each(dashRowColumns, function (item) { columnWidths.push(item.columnWidth) })
								nextCol = dashColumns[nextColIndex];
								var nextColWidth = (stateColumnWidths[colIndex] + stateColumnWidths[nextColIndex]) - colWidth;
								var dashWidth = eval(columnWidths.join("+"));
								if (dashWidth != 1) {
									nextColWidth += (1 - dashWidth);
								}
								if (isColColllapse) {
									col.columnWidth = colWidth;
								}
								else if (columnWidths.length > 2) {
									colWidth = columnWidths[colIndex];
								}
								else {
									nextColWidth = 1 - colWidth;
								}
								col.columnWidth = colWidth;
								nextCol.columnWidth = nextColWidth;
								nextCol.updateLayout();
							}
							else {
								if (dashRowColumns.indexOf(col) != (dashRowColumns.length - 1) && col.columnWidth != 0.03) {
									col.columnWidth = colWidth;
									var lastCol = dashRowColumns[dashRowColumns.length - 1];
									var lastColWidth = 1 - (dashRowColumns.length - 1) * 0.03;
									if (lastCol.columnWidth != lastColWidth) {
										lastCol.columnWidth = lastColWidth;
										lastCol.updateLayout();
									}

								}
							}
						}
					}
				}
			}, me);
			me.updateLayout(true);
		}
	},
	/**
	* @method onExpandPanel
	* expand dashboard panel.
	* @param {object} column .
	* @private
	*/
	onExpandPanel: function (column) {
		var me = this;
		if (column.expandcollapse) {
			if (me.isDashboardReset) {
				me.isDashboardReset = false;
			}
			Wv.CommonUtils.runWithLayoutsSuspended(function () {
				if (!me.isDashboardPanelResetClick) {
					if (column.collapseDirection == "left" || column.collapseDirection == "right") {
						var dashColumns = me.query('dashboard-column'), nextColIndex, isColExpand = false, checkCollapse = ['left', 'right'], nextCol = [];
						var col = column.up('dashboard-column');
						var dashRowColumns = me.query('dashboard-column[rowIndex=' + col.rowIndex + ']');
						var colPanel = col.query('dashboard-panel');
						Ext.Array.each(colPanel, function (item) {
							if (column != item && item.collapsed == false) {
								isColExpand = true;
								return false;
							}
						});
						if (!isColExpand) {
							var state = me.getDashboardState();
							var colIndex = column.columnIndex;
							nextColIndex = me.getDashboardNextColumnHorizontal(colIndex, col, [], "expand");
							nextCol = Ext.Array.filter((dashRowColumns), function (c) {
								return c == dashColumns[nextColIndex]
							});
							if (nextColIndex != -1 && nextCol.length > 0) {
								nextCol = dashColumns[nextColIndex];
								var columnWidths = me.restoreStateLocally[me.stateId].prevColumnWidths;
								var isNextColExapnd = false;
								var nextColPanel = nextCol.query('dashboard-panel');
								Ext.Array.each(nextColPanel, function (item) {
									var isColl = false;
									if (item.collapseDirection == "left" || item.collapseDirection == "right") {
										var coll = item.collapsed;
										if (coll == true || checkCollapse.indexOf(coll) >= 0) {
											coll = true;
										}
										if (coll == false) {
											isColl = true;
										}
									}
									else {
										isColl = true;
									}
									if (isColl) {
										isNextColExapnd = true;
										return false;
									}
								});
								var colWidth, nextColWidth;
								if (!isNextColExapnd) {
									nextColWidth = 0.03;
								}
								else {
									colWidth = columnWidths[colIndex];
								}

								var obj = [];
								for (var i = 0; i < dashRowColumns.length; i++) {
									var ind = dashColumns.indexOf(dashRowColumns[i]);
									obj.push(state.columnWidths[ind]);
								}
								var index = obj.indexOf(col.columnWidth);
								if (index > -1) {
									obj.splice(index, 1);
								}
								index = obj.indexOf(nextCol.columnWidth);
								if (index > -1) {
									obj.splice(index, 1);
								}
								var objCount = 0;
								for (var i = 0; i < obj.length; i++) {
									objCount += obj[i];
								}
								if (!isNextColExapnd) {
									colWidth = 1 - (objCount + nextColWidth);
									col.columnWidth = colWidth;
									nextCol.columnWidth = nextColWidth;
								}
								else {
									nextColWidth = 1 - (objCount + colWidth);
									col.columnWidth = colWidth;
									nextCol.columnWidth = nextColWidth;
								}
								col.updateLayout();
								nextCol.updateLayout();
							}
							else {
								if (col.columnWidth == 0.03) {
									var obj = [];
									for (var i = 0; i < dashRowColumns.length; i++) {
										var ind = dashColumns.indexOf(dashRowColumns[i]);
										obj.push(state.columnWidths[ind]);
									}
									var index = obj.indexOf(col.columnWidth);
									if (index > -1) {
										obj.splice(index, 1);
									}
									var objCount = 0;
									for (var i = 0; i < obj.length; i++) {
										objCount += obj[i];
									}
									colWidth = 1 - objCount;
									col.columnWidth = colWidth;
									col.updateLayout();
								}
							}
						}
						if (Wv.CommonUtils.getIfAvailable(column, ".header.query('[type=collapse-left]')[0]")) {
							column.header.query('[type=collapse-left]')[0].hide();
						}
						if (Wv.CommonUtils.getIfAvailable(column, ".header.query('[type=collapse-right]')[0]")) {
							column.header.query('[type=collapse-right]')[0].hide();
						}
						if (Wv.CommonUtils.getIfAvailable(column, ".header.query('[itemId=expandcollapse]')[0]")) {
							column.header.query('[itemId=expandcollapse]')[0].show();
						}
					}
				}
			}, me);
			me.updateLayout(true);
		}
	},
	/**
	* reset state
	* @private
	*/
	resetstate: function () {
		var me = this;
		if (me.lookupReference('dockedItemBarDataView')) {
			me.lookupReference('dockedItemBarDataView').getSelectionModel().deselectAll();
			me.restoreStateLocally[me.stateId].selectedLeftSidebarItem = 0;
			var dockedItemRightBar = me.lookupReference('dockedItemRightBar');
			if (dockedItemRightBar && !dockedItemRightBar.hidden) {
				if (Wv.CommonUtils.getIfAvailable(me.body, ".el.dom.style.display")) {
					me.body.el.dom.style.display = '';
				}
				dockedItemRightBar.hide();
			}
			if (me.homeState) {
				delete me.homeState;
			}
		}
		me.isMaximizePanel = false;
		me.isDashboardPanelResetClick = true;
		me.ClosedPanel[me.stateId] = [];
		var val = [];
		var key = me.config.xtype;
		if (key == "OATIUserDashboard") {
			key = me.stateId;
		}
		me.mask(GlobalStrings.Label_Loading);
		Ext.Ajax.request({
			url: UrlManager.buildURL(UrlManager.apiURL(), UrlRegistry.OATIDataSummary_SaveColumnsContext),
			method: 'POST',
			params: {
				key: key,
				value: val,
				submitType: 'clear',
				instanceId: me.config.DisplayInformation.instanceId
			},
			success: function (response) {
				var defstate = me.getDisplayManager().getActiveTab().defaultState[me.stateId];
				defstate = $.extend(true, {}, defstate);
				Ext.state.Manager.provider.state[me.stateId] = defstate;
				Ext.state.Manager.provider.state[me.stateId].prevColumnWidths = defstate.columnWidths;
				for (var i = 0; i < (defstate && defstate.items && defstate.items.length); i++) {
					var item = defstate.items[i];
					var itemC = me.down('[itemId=' + item.itemId + ']');
					if (itemC) {
						Ext.state.Manager.provider.clear(itemC.stateId);
						var height = 90;
						if (item.height) {
							height = item.height;
						}
						if (item.collapsed) {
							if (!itemC.collapsed) {
								itemC.collapse()
							}
						}
						else {
							if (itemC.collapsed) {
								itemC.expand();
							}
						}
						if (Wv.CommonUtils.getIfAvailable(itemC, ".tools['maximize']")) {
							itemC.tools['maximize'].show();
							itemC.tools['maximize'].setDisabled(false);
						}
						if (me.isDashboardResponsive) {
							itemC.applyState({ height: height });
						}
						else {
							itemC.applyState({ height: "auto" });
						}
						me.addView(itemC, item.columnIndex);
						if (itemC.el.hasCls('x-animating-size')) {
							itemC.el.removeCls('x-animating-size');
						}
						delete itemC.restoreMaximizeHeight;

						if (Wv.CommonUtils.getIfAvailable(itemC, ".tools['restore']")) {
							itemC.tools['restore'].hide();
						}
						if (Wv.CommonUtils.getIfAvailable(itemC, ".query('[type=collapse-bottom]')[0]")) {
							itemC.query('[type=collapse-bottom]')[0].hide();
						}
						if (Wv.CommonUtils.getIfAvailable(itemC, ".query('[itemId=expandcollapse]')[0]")) {
							itemC.query('[itemId=expandcollapse]')[0].show();
						}
						itemC.show();
						me.showhideTools(itemC, true);
						me.applyPlugin(itemC);
						if (itemC && itemC.isVisible() && itemC.resizable) {
							itemC.resizer.resizeTracker.enable();
						}
						if (itemC && itemC.isVisible() && itemC.draggable) {
							itemC.dd.unlock();
						}
						itemC.updateLayout();
					}
					else {
						me.addNew(item.type, item.columnIndex);
						itemC = me.down('[itemId=' + item.itemId + ']');
						if (!itemC.stateId) {
							itemC.stateId = item.itemId;
						}
						Ext.resumeLayouts(true);
						me.attachEvents(itemC);
						me.restoreStateLocally[me.stateId].items[itemC.itemId] = {};
					}
				}

				var columns = me.query('dashboard-column');
				Ext.Array.each(columns, function (item) {
					if (Wv.CommonUtils.getIfAvailable(item, ".el.dom.style.display")) {
						item.el.dom.style.display = "";
					}
				});

				me.setDashboardColumnWidth(defstate.columnWidths);
				me.restoreStateLocally[me.stateId].prevColumnWidths = defstate.columnWidths;
				me.updateLayout(true);
				me.makeDashboardResponsive();
				me.setHeightLocally();
				me.setDisplayInformationState(null);
				me.fireEvent('onStateResetClick', me);
				me.prevColumnWidths = null;
				me.isDashboardReset = false;
				me.isDashboardPanelResetClick = false;
				delete me.restoreMaximizeColumnWidth;
				me.isMaximizePanel = false;
				setTimeout(function () {
					me.unmask();
				}, 500);
			}
		});
	},
	/**
	* Garbage Collection of the entity data and the accompanying  components.
	* @param {object} grid The grid summary object.
	* @private
	*/
	cleanup: function () {
		var me = this;
		if (me.itemsPresenter) {
			me.itemsPresenter.destroy();
			me.itemsPresenter = null;
		}
		if (me.filterWindow) {
			me.filterWindow.destroy();
		}
		var dashboardReset = me.isDashboardReset != undefined ? !me.isDashboardReset : true;
		if (dashboardReset) {
			var selectedLeftSidebarItem = me.restoreStateLocally[me.stateId].selectedLeftSidebarItem;
			var state = {};
			if (me.homeState && selectedLeftSidebarItem != 0) {
				state = me.homeState;
			}
			else {
				state = me.getDashboardState();
			}
			state.selectedLeftSidebarItem = selectedLeftSidebarItem;
			me.setDisplayInformationState(state);
			var val = JSON.stringify(state);
			var key = me.config.xtype;
			if (key == "OATIUserDashboard") {
				key = me.stateId;
			}
			Ext.Ajax.request({
				url: UrlManager.buildURL(UrlManager.apiURL(), UrlRegistry.OATIDataSummary_SaveColumnsContext),
				method: 'POST',
				params: {
					key: key,
					value: val,
					instanceId: me.config.DisplayInformation.instanceId
				}
			});
		}
	},
	//#endregion
});
