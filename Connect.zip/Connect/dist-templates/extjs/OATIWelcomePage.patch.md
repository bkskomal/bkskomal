# OATIWelcomePage.js — patch instructions

Apply these four small edits to your existing
`Webvision/view/welcomepage/OATIWelcomePage.js` to wire the new OATIConnect
sidebar entry + panel. None of the existing welcome-page features change.

---

## 1. Add `Webvision.view.oaticonnect.OATIConnectView` to `requires`

Find the `requires:` block at the top of the class definition and add the new view. Place it next to the other welcome-page view requires.

```diff
   requires: [
     'Webvision.view.admindashboard.OATIWebSupportIssueStore',
     'Webvision.view.admindashboard.OATIHelpDeskTicketsStore',
     'Webvision.view.welcomepage.OATIWelcomePageController',
     'Webvision.view.welcomepage.OATIApplicationLayoutManager',
     'Webvision.view.welcomepage.OATIApplicationLayoutView',
     'Webvision.utils.DisplayToolbar',
     'Webvision.view.welcomepage.OATIWelcomePageCalendar',
     'Webvision.view.welcomepage.OATIWelcomePageSidePanelCalendar',
     'Webvision.view.welcomepage.OATIRecentTicketsView',
     'Webvision.view.welcomepage.OATIRecentTicketsSidePanelView',
     'Webvision.view.welcomepage.OATIHelpVideosView',
     'Webvision.view.welcomepage.OATIFeedbackSummaryFilterConfig',
+    'Webvision.view.oaticonnect.OATIConnectView',
     'Webvision.utils.CommonUtils'
   ],
```

---

## 2. Add the sidebar menu item

Inside `dockedItems[0].items[0]` (the dataview with the sidebar list), append a new entry to the `store.data` array. **Id must be 6** so the controller's `sidePanelItemClick` and the resize-listener branches line up cleanly:

```diff
   store: {
     data: [{
       "Name": "Dashboard",
       "iconcls": '<i class="fas fa-home dashboard_homeicon"></i>',
       "Id": 0
     }, {
       "Name": "Single sign-on & Application Access",
       "Image": "../HubResources/images/leftpanel/Single_Signon_Product_Overview.svg",
       "Id": 1
     }, {
       "Name": "Support and Help Desk Center",
       "Image": "../HubResources/images/leftpanel/Support_Help_Desk_Center.svg",
       "Id": 2
     }, {
       "Name": "News, Events & Highlights",
       "Image": "../HubResources/images/leftpanel/News_Events_Highlights.svg",
       "Id": 3
     }, {
       "Name": "Training and Onboarding",
       "Image": "../HubResources/images/leftpanel/Training_Onboarding.svg",
       "Id": 4
     }, {
       "Name": "Feedback & Suggestions",
       "Image": "../HubResources/images/leftpanel/Feedback _Suggestions.svg",
       "Id": 5
+    }, {
+      "Name": "OATIConnect Meet",
+      "iconcls": '<i class="fas fa-video oaticonnect_sidebaricon" style="font-size:25px;color:#2563eb;"></i>',
+      "Id": 6
     }]
   },
```

If you prefer an SVG icon to match the others, drop a `Single_OATIConnect.svg`
(or similar) into `wwwroot/HubResources/images/leftpanel/` and use:

```js
{
    "Name": "OATIConnect Meet",
    "Image": "../HubResources/images/leftpanel/OATIConnect.svg",
    "Id": 6
}
```

---

## 3. Add the right-side container

Inside `dockedItems[1].items[0].items` (right side panel — the
`dockedItemRightBarMainPanel` container), append a new entry that hosts the
OATIConnect view. Place it after `sidepanel_feedbackandSummarypanel`:

```diff
       }]
     }]
+  }, {
+    layout: 'fit',
+    title: 'OATIConnect Meet',
+    reference: 'sidepanel_oaticonnectpanel',
+    cls: 'welcomepage_sidepaneloaticonnectpanel',
+    scrollable: false,
+    items: [{
+        xtype: 'oaticonnectview',
+        // The view manages its own loading + cleanup; no customLoadData needed
+        // because the web component doesn't poll — SignalR pushes updates.
+        customLoadData: function (panel, globalRefresh) { /* no-op */ }
+    }]
   }]
 }]
```

The `customLoadData` no-op stub is required because
`OATIWelcomePageController.sidePanelItemClick` calls it on every sidebar
selection. The web component handles its own data refresh through SignalR
and React Query, so we don't need to do anything here.

---

## 4. Update the `resize` listener

In the top-level `listeners.resize` handler, find the `else if` chain that
sizes panels per `selectedLeftSidebar` value. Add a branch for `== 6`:

```diff
   } else if (selectedLeftSidebar == 5) {
     if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("#feedbackpanel")')) {
       dockedItemRightBar.down("#feedbackpanel").setHeight(setDockHeight);
     }
     if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("feedbacksummaryview")')) {
       dockedItemRightBar.down("feedbacksummaryview").setHeight(setDockHeight);
     }
     var feedbackform = Wv.CommonUtils.getIfAvailable(me, '.body.getById("feedbackWindow").component');
     if (feedbackform) {
       var feedbackFormHeight = 540;
       if (setDockHeight < 500) {
         feedbackFormHeight = 400;
       }
       feedbackform.setHeight(feedbackFormHeight);
     }
   }
+  else if (selectedLeftSidebar == 6) {
+    if (Wv.CommonUtils.getIfAvailable(dockedItemRightBar, '.down("oaticonnectview")')) {
+      dockedItemRightBar.down("oaticonnectview").setHeight(setDockHeight);
+      dockedItemRightBar.down("oaticonnectview").setWidth(setDockWidth);
+    }
+  }
```

---

## 5. (Optional) Replace the broken `oaticonnectpanel` part definition

Your file currently has an `oaticonnectpanel` part inside `parts:` that's a
copy-paste of `helpvideospanel` (title "Help Videos", `xtype:
helpvideossview`). It's also referenced in `defaultContent`. If you want
OATIConnect to also appear as a regular dashboard tile (in addition to the
sidebar entry above), replace that part with:

```js
oaticonnectpanel: {
    viewTemplate: {
        layout: 'fit',
        config: {
            draggable: true,
            resizable: true,
            closable: false,
            maximizable: true
        },
        title: 'OATIConnect Meet',
        items: { xtype: 'oaticonnectview' },
        header: true,
        titleAlign: 'left',
        plugins: [{
            ptype: 'refreshPlugin',
            periodicRefresh: false,
            hidePeriodicRefreshDropdown: true
        }],
        customLoadData: function (panel, globalRefresh) { /* no-op */ }
    }
}
```

If you don't want a dashboard tile (only the sidebar entry), **remove** both
the `oaticonnectpanel` entry from `parts:` and the matching
`{ type: 'oaticonnectpanel', id: 'welcomepage_oaticonnectpanel', columnIndex: 1 }`
entry from `defaultContent`.

---

## Controller hookup

Your `OATIWelcomePageController.sidePanelItemClick` already shows/hides the
right-side panels by `selectedLeftSidebarItem`. As long as the new
`sidepanel_oaticonnectpanel` is at the same level as the other
sidepanel_* containers, the existing show/hide logic should pick it up.
If the controller has an explicit switch on Id, add a branch for Id 6 that
makes `sidepanel_oaticonnectpanel` visible and hides the rest.

---

## Deployment

1. Drop **`OATIConnectView.js`** AND **`oaticonnect.mjs`** into the **same
   folder** (e.g. `Webvision/view/oaticonnect/`). Sencha picks the view up
   via the namespace `Webvision.view.oaticonnect.OATIConnectView`. Module-
   loading logic is built into the single file — no separate loader needed.

   The default `modulePath` is the bare filename `'oaticonnect.mjs'`, which
   resolves **relative to OATIConnectView.js's own URL** (NOT the page
   URL). This matters because:
     - In dev mode (`sencha app watch`), the page URL sits a few directories
       deep so a *page-relative* path happens to land on the right file.
     - In production after `sencha app build`, all JS is bundled into
       `app.js` served from a different depth — page-relative paths break,
       but script-relative paths still work because the view and the
       bundle stay co-located.

   If you must split them, override at app startup with an **absolute**
   URL:
     ```js
     Webvision.view.oaticonnect.OATIConnectView.modulePath = '/oatigenie/js/oaticonnect.mjs';
     ```
   Anything starting with `/`, `http://`, or `https://` is used as-is;
   everything else is resolved against the OATIConnectView.js script URL.

2. Make sure your IIS / web server returns `.mjs` with
   `Content-Type: text/javascript`. In `web.config`:
   ```xml
   <staticContent>
       <mimeMap fileExtension=".mjs" mimeType="text/javascript" />
   </staticContent>
   ```
4. Make sure `services.AddOATIConnect(...)`, `app.ConfigureOATIConnect()`,
   and `app.MapHub<LobbyHub>("/hubs/lobby")` are all wired in your
   WebVision server `Startup.cs` per the integration guide.

After these four edits + deployment, clicking the new "OATIConnect Meet"
left-sidebar icon mounts the embedded meeting dashboard inside the
right-side panel.
