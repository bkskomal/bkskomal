/***********************************************************************/
/*  OATIConnectView                                                    */
/*                                                                     */
/*  Hosts the OATIConnect Meet web component inside an ExtJS Container.*/
/*  Reads the current user from Wv.OATIUser, pulls runtime config from */
/*  /api/v1/config, and mounts <oaticonnect-meet>.                     */
/*                                                                     */
/*  Module loading is handled internally — the bundled .mjs is fetched */
/*  exactly once per page even if multiple OATIConnectView instances   */
/*  are created.                                                       */
/*                                                                     */
/*  Hardened so any failure (module fetch, missing user, mount error)  */
/*  still leaves the wrapping container visible with a clear message.  */
/***********************************************************************/

// Captured at file-load time so we can resolve the bundle URL relative to
// THIS script's location instead of the host page's URL. In dev mode the
// page URL happens to make a relative `../../../oatigenie/js/...` path
// resolve correctly; after `sencha app build` the page sits at a different
// depth and the same relative path collapses to the wrong absolute URL.
// Anchoring against the script's own URL is stable across both layouts.
var __oaticonnectScriptSrc = '';
try {
    if (document && document.currentScript && document.currentScript.src) {
        __oaticonnectScriptSrc = document.currentScript.src;
    }
} catch (e) { /* document.currentScript not available — fall back later */ }

Ext.define('Webvision.view.oaticonnect.OATIConnectView', {
    extend: 'Ext.container.Container',
    xtype: 'oaticonnectview',
    alias: 'widget.oaticonnectview',

    layout: 'fit',
    cls: 'oaticonnect-host',
    width: '100%',
    height: '100%',
    autoScroll: false,

    config: {
        // apiBase / configEndpoint default to "/api/v1" but get rewritten on
        // mount with the detected webVision virtual app prefix (see
        // resolveBasePath() below). With webVision at https://host/oaticonnect
        // the values become "/oaticonnect/api/v1" and "/oaticonnect/api/v1/config"
        // so requests reach the right ASP.NET Core app instead of the IIS
        // default site.
        apiBase:        '/api/v1',
        theme:          'light',
        configEndpoint: '/api/v1/config'
    },

    statics: {
        // Override to hard-code the webVision virtual app prefix. When unset
        // (the default), the prefix is detected from window.location.pathname
        // — the first non-file segment is treated as the virtual app path.
        // For webVision at https://host/oaticonnect/... this resolves to
        // "/oaticonnect"; for a root-mounted app set it to '' explicitly:
        //   Webvision.view.oaticonnect.OATIConnectView.basePath = '';
        // Set to '/foo' to override the autodetect.
        basePath: null,

        /**
         * Returns the virtual-app prefix (no trailing slash). All API URLs
         * passed to the React bundle are anchored to this — without it,
         * absolute paths like "/api/v1/config" hit the IIS site root and
         * 404 as static-file lookups when webVision is mounted under a
         * sub-path.
         */
        resolveBasePath: function () {
            if (typeof this.basePath === 'string') return this.basePath;
            try {
                var path = window.location.pathname || '';
                var segs = path.split('/').filter(function (s) { return s.length > 0; });
                if (segs.length > 0 && segs[0].indexOf('.') === -1) return '/' + segs[0];
            } catch (e) {}
            return '';
        },

        // Path to the bundled module. Default is root-relative
        // ("/oatigenie/js/oaticonnect.mjs") so it resolves the same in
        // both `sencha app watch` (dev) and `sencha app build` (prod) —
        // production bundles the JS into a single app.js served from a
        // different depth, which breaks any path that relies on the page
        // URL or the calling script URL. Root-relative dodges both.
        //
        // To deploy elsewhere, override before the first instance renders:
        //   Webvision.view.oaticonnect.OATIConnectView.modulePath = '/myapp/oaticonnect.mjs';
        //   Webvision.view.oaticonnect.OATIConnectView.modulePath = 'oaticonnect.mjs';   // co-located with this file
        //   Webvision.view.oaticonnect.OATIConnectView.modulePath = 'https://cdn.example.com/oaticonnect.mjs';
        //
        // Resolution rules:
        //   * absolute (scheme:// or //host) — used verbatim
        //   * starts with "/" — root-relative on the host origin
        //   * otherwise — resolved against THIS script's URL (not the page),
        //     so co-locating the bundle with OATIConnectView.js works even
        //     after `sencha app build`. In bundled builds where the view is
        //     inlined into app.js, this falls back to app.js's URL — set an
        //     absolute path above if your deploy needs it.
        modulePath: '/oatigenie/js/oaticonnect.mjs',

        // Cache-busting version stamp, appended to modulePath as ?v=...
        // Auto-rewritten by build-oaticonnect.ps1 on every build, so a
        // fresh deploy guarantees clients refetch the bundle. Manually
        // bump if you replace the bundle without re-running the script.
        version: '20260504225132',

        /** @private — singleton load promise shared across all instances */
        _modulePromise: null,

        /**
         * Resolves modulePath against the captured OATIConnectView.js script
         * URL. Absolute URLs (root-relative or scheme-prefixed) pass through
         * unchanged — only bare or `./`/`../` paths are anchored to the
         * script directory.
         */
        resolveModuleUrl: function () {
            var path = this.modulePath || '';
            if (!path) return path;
            // Absolute (scheme or protocol-relative) — leave alone.
            if (/^([a-z][a-z0-9+.-]*:)?\/\//i.test(path)) return path;
            // Root-relative — leave alone.
            if (path.charAt(0) === '/') return path;
            // Otherwise resolve against this script's own URL. Falls back to
            // page-relative resolution when document.currentScript isn't
            // available (e.g. inlined into Sencha's app.js bundle, in which
            // case the host should override modulePath with an absolute URL).
            if (__oaticonnectScriptSrc) {
                try { return new URL(path, __oaticonnectScriptSrc).href; }
                catch (e) { /* malformed URL — fall through to raw path */ }
            }
            return path;
        },

        /**
         * Returns a Promise that resolves once the bundle is loaded and the
         * <oaticonnect-meet> custom element is registered. Idempotent:
         * subsequent calls return the same promise — module is loaded once.
         */
        loadModule: function () {
            var me = this;
            if (me._modulePromise) return me._modulePromise;

            me._modulePromise = new Promise(function (resolve, reject) {
                if (typeof customElements !== 'undefined' &&
                    customElements.get && customElements.get('oaticonnect-meet')) {
                    resolve();
                    return;
                }
                try {
                    var src = me.resolveModuleUrl();
                    if (me.version && me.version.indexOf('__') !== 0) {
                        src += (src.indexOf('?') >= 0 ? '&' : '?') + 'v=' + encodeURIComponent(me.version);
                    }
                    var script = document.createElement('script');
                    script.type = 'module';
                    script.src  = src;
                    script.onload  = function () { resolve(); };
                    script.onerror = function () {
                        me._modulePromise = null;
                        reject(new Error('Failed to load OATIConnect bundle: ' + src));
                    };
                    document.head.appendChild(script);
                } catch (e) {
                    me._modulePromise = null;
                    reject(e);
                }
            });
            return me._modulePromise;
        }
    },

    /** @private — the live <oaticonnect-meet> DOM element after mount */
    _meetEl: null,

    listeners: {
        afterrender:   function () { this.onAfterRender(); },
        beforedestroy: function () { this.onBeforeDestroy(); }
    },

    onAfterRender: function () {
        var me = this;
        var Cls = Webvision.view.oaticonnect.OATIConnectView;

        // Detect the webVision virtual app prefix and rewrite our config
        // (apiBase, configEndpoint) so absolute URLs resolve into the
        // ASP.NET Core app, not the IIS site root. Also stash on window
        // so the React bundle's getBasePath() picks it up — without this,
        // the bundle's API calls (loadConfig, getJoinUrl, ics download)
        // hit the wrong host root and 404.
        var basePath = '';
        try { basePath = Cls.resolveBasePath(); } catch (e) {}
        try { window.__oaticonnectBasePath = basePath; } catch (e) {}
        if (basePath) {
            // Only rewrite when default ('/api/v1' / '/api/v1/config') so
            // explicit overrides set on the instance config still win.
            if (me.getApiBase() === '/api/v1') me.setApiBase(basePath + '/api/v1');
            if (me.getConfigEndpoint() === '/api/v1/config') me.setConfigEndpoint(basePath + '/api/v1/config');
        }

        // Print the version to the console so DevTools can confirm which
        // OATIConnectView is actually running. Helps when deployments
        // appear "not to take effect" (Sencha bundle / browser cache
        // serving the old file).
        try {
            // eslint-disable-next-line no-console
            console.log('[OATIConnectView] version=' + Cls.version +
                ', basePath=' + (basePath || '(root)') +
                ', apiBase=' + me.getApiBase() +
                ', configEndpoint=' + me.getConfigEndpoint() +
                ', modulePath=' + Cls.modulePath +
                ', resolvedBundleUrl=' + Cls.resolveModuleUrl() +
                ', scriptSrc=' + (__oaticonnectScriptSrc || '(unavailable)'));
        } catch (e) {}

        me.showPlaceholder('Loading OATIConnect...');

        try {
            me.mask(GlobalStrings && GlobalStrings.Label_Loading
                ? GlobalStrings.Label_Loading : 'Loading...');
        } catch (e) { /* mask is best-effort */ }

        var loaderPromise;
        try {
            loaderPromise = Webvision.view.oaticonnect.OATIConnectView.loadModule();
        } catch (e) {
            loaderPromise = Promise.reject(e);
        }

        Promise.all([loaderPromise, me.fetchRuntimeConfig()])
            .then(function (results) {
                try { me.unmask(); } catch (e) {}
                try {
                    me.mountWebComponent(results[1] || {});
                } catch (mountErr) {
                    me.showLoadError(mountErr);
                }
            })
            .catch(function (err) {
                try { me.unmask(); } catch (e) {}
                me.showLoadError(err);
            });
    },

    onBeforeDestroy: function () {
        var me = this;
        // Removing the element triggers the web component's
        // disconnectedCallback (unmounts React + tears down in-flight
        // axios calls).
        if (me._meetEl && me._meetEl.parentNode) {
            try { me._meetEl.parentNode.removeChild(me._meetEl); } catch (e) {}
        }
        me._meetEl = null;
    },

    /**
     * Pulls /api/v1/config. Failure is non-fatal — the embedded bundle
     * calls the same endpoint itself; we only pre-load to surface the
     * Jitsi URL on the element as an attribute. We DO log the failure
     * to the console with status + body so a host can diagnose 401/403/500
     * without needing to break out devtools.
     */
    fetchRuntimeConfig: function () {
        var me = this;
        return new Promise(function (resolve) {
            try {
                Ext.Ajax.request({
                    url: me.getConfigEndpoint(),
                    method: 'GET',
                    withCredentials: true,
                    timeout: 8000,
                    success: function (resp) {
                        try { resolve(Ext.decode(resp.responseText)); }
                        catch (e) { resolve({}); }
                    },
                    failure: function (resp) {
                        try {
                            // eslint-disable-next-line no-console
                            console.warn('[OATIConnectView] /api/v1/config failed: status=' +
                                (resp && resp.status) + ' statusText=' +
                                (resp && resp.statusText) + ' body=' +
                                ((resp && resp.responseText) || '').slice(0, 500));
                        } catch (e) {}
                        resolve({});
                    }
                });
            } catch (e) { resolve({}); }
        });
    },

    mountWebComponent: function (runtimeCfg) {
        var me = this;
        var user = me.resolveCurrentUser();
        if (!user) {
            me.showLoadError(new Error(
                'No authenticated user. Please ensure you are logged in to webVision before opening OATIConnect.'
            ));
            return;
        }

        if (typeof customElements === 'undefined' ||
            !customElements.get || !customElements.get('oaticonnect-meet')) {
            me.showLoadError(new Error(
                'OATIConnect bundle loaded but <oaticonnect-meet> is not registered. ' +
                'Check that oaticonnect.mjs is being served as application/javascript.'
            ));
            return;
        }

        me.clearPlaceholder();

        var tag = document.createElement('oaticonnect-meet');
        tag.setAttribute('api-base',  me.getApiBase());
        tag.setAttribute('user-id',   String(user.id));
        tag.setAttribute('user-name', String(user.name || ''));
        tag.setAttribute('user-email',String(user.email || ''));
        tag.setAttribute('user-role', String(user.role));
        tag.setAttribute('theme',     me.resolveTheme());

        // /api/v1/config is camelCase; webVision serializer is PascalCase.
        // Try both shapes so the host's serializer choice doesn't matter.
        var jitsiBase = (runtimeCfg && (runtimeCfg.jitsiServerBaseUrl ||
                                        runtimeCfg.JitsiServerBaseUrl)) || '';
        if (jitsiBase) tag.setAttribute('jitsi-base-url', jitsiBase);

        tag.style.display = 'block';
        tag.style.width   = '100%';
        tag.style.height  = '100%';

        me.el.dom.appendChild(tag);
        me._meetEl = tag;
    },

    /**
     * Maps Wv.OATIUser → { id:int, name, email, role }. Returns null only
     * when no user info is available at all. The host's native int UserId
     * flows straight through — no Guid translation, the server stores the
     * int directly.
     */
    resolveCurrentUser: function () {
        try {
            if (typeof Wv === 'undefined' || !Wv.OATIUser) return null;
            var u = Wv.OATIUser;

            var id = (u.userId || u.UserId || 0) | 0;
            if (id <= 0) return null;

            var firstName = u.firstName || u.FirstName || '';
            var lastName  = u.lastName  || u.LastName  || '';
            var username  = u.userName  || u.UserName  || '';
            var displayName = (firstName + ' ' + lastName).trim() || username || 'User';

            return {
                id:    id,
                name:  displayName,
                email: u.emailAddress || u.EmailAddress || (username + '@local'),
                role:  this.resolveRole()
            };
        } catch (e) {
            return null;
        }
    },

    /**
     * Authoritative admin probe via Wv.OATIUser.getUserPermissions().IsAdmin
     * — same gate the rest of webVision uses for admin UI. IsAdmin can be
     * a boolean property OR a 0-arg method depending on host build, so
     * accept both shapes.
     */
    resolveRole: function () {
        try {
            if (typeof Wv !== 'undefined' && Wv.OATIUser &&
                typeof Wv.OATIUser.getUserPermissions === 'function') {
                var perms = Wv.OATIUser.getUserPermissions();
                if (perms) {
                    var raw = perms.IsAdmin;
                    var value = (typeof raw === 'function') ? raw.call(perms) : raw;
                    if (value === true) return 'Admin';
                }
            }
        } catch (e) {}
        return 'Standard';
    },

    resolveTheme: function () {
        var configured = this.getTheme();
        if (configured) return configured;
        try {
            var docTheme = (document.documentElement.getAttribute('data-theme') || '').toLowerCase();
            if (docTheme === 'dark' || docTheme === 'light') return docTheme;
        } catch (e) {}
        return 'light';
    },

    /**
     * Inserts a plain DOM status message. Used both for the initial
     * "Loading..." state and for error messages. Always works — no Ext
     * layout dependencies — so even mid-mount it appears.
     */
    showPlaceholder: function (text) {
        var me = this;
        if (!me.el || !me.el.dom) return;
        try {
            me.clearPlaceholder();
            var div = document.createElement('div');
            div.className = 'oaticonnect-placeholder';
            div.style.cssText = 'display:flex;align-items:center;justify-content:center;' +
                                'height:100%;color:#6b7280;font-family:Segoe UI, sans-serif;' +
                                'font-size:14px;padding:24px;text-align:center;';
            div.textContent = text || '';
            div.setAttribute('data-oaticonnect-placeholder', '1');
            me.el.dom.appendChild(div);
        } catch (e) { /* DOM ops best-effort */ }
    },

    clearPlaceholder: function () {
        var me = this;
        if (!me.el || !me.el.dom) return;
        try {
            var existing = me.el.dom.querySelectorAll('[data-oaticonnect-placeholder]');
            for (var i = 0; i < existing.length; i++) {
                existing[i].parentNode.removeChild(existing[i]);
            }
        } catch (e) {}
    },

    showLoadError: function (err) {
        var msg = (err && err.message)
            ? err.message
            : (typeof err === 'string' ? err : 'Unknown error');
        this.showPlaceholder('Could not load OATIConnect: ' + msg);
    }
});
