﻿/***********************************************************************/
/*                            TRADE SECRET                             */
/*                                                                     */
/*     This computer program contains confidential and proprietary     */
/*      information of Open Access Technology International, Inc.      */
/*   This information is not to be used, disseminated, distributed,    */
/*  or otherwise transferred without the expressed written permission  */
/*            of Open Access Technology International, Inc.            */
/*                                                                     */
/*          (c)2025 Open Access Technology International, Inc.         */
/*                        All rights reserved.                         */
/***********************************************************************/
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;
using OATI.webVision.EntityFramework.Migrations;
using OATIHub.EntityFramework.Models;
using System;

namespace OATIHub.EntityFramework.Migrations
{
	/// <summary>
	/// Adds the four tables that back the OATIConnect integration:
	///   - OATIConnectMeetings
	///   - OATIConnectMeetingInvitees
	///   - OATIConnectMeetingParticipants
	///   - OATIConnectAppConfigs
	///
	/// All four live in the main framework database so OATIConnect reuses
	/// the host's existing connection / auth / transaction scope. Schema
	/// mirrors the entities in OATIConnect.API.dll (see
	/// OATIConnect.API.Domain.Entities.*).
	/// </summary>
	[DbContext(typeof(Application_FrameworkEntities))]
	[Migration("20260506144328_Release_2_2_3_0_OATIConnect")]
	public partial class Release_2_2_3_0_OATIConnect : OATIPreMigrationBase
	{
		public override void Up(IOATIPreUpMigrationBuilder migrationBuilder)
		{
			migrationBuilder.CreateTable(
				name: "OATIConnectMeetings",
				columns: table => new
				{
					Id = table.Column<Guid>(nullable: false),
					Title = table.Column<string>(maxLength: 200, nullable: false),
					Description = table.Column<string>(maxLength: 2000, nullable: true),
					ScheduledTimeUtc = table.Column<DateTime>(nullable: false),
					DurationMinutes = table.Column<int>(nullable: false),
					RoomName = table.Column<string>(maxLength: 200, nullable: false),
					MeetingCode = table.Column<string>(maxLength: 20, nullable: false),
					HostUserId = table.Column<int>(nullable: false),
					Status = table.Column<int>(nullable: false),
					ActualStartUtc = table.Column<DateTime>(nullable: true),
					ActualEndUtc = table.Column<DateTime>(nullable: true),
					IsLocked = table.Column<bool>(nullable: false),
					CreatedAtUtc = table.Column<DateTime>(nullable: false)
				},
				constraints: table =>
				{
					table.PrimaryKey("PK_OATIConnectMeetings", x => x.Id);
				});

			migrationBuilder.CreateIndex(
				name: "IX_OATIConnectMeetings_RoomName",
				table: "OATIConnectMeetings",
				column: "RoomName");

			migrationBuilder.CreateIndex(
				name: "IX_OATIConnectMeetings_HostUserId",
				table: "OATIConnectMeetings",
				column: "HostUserId");

			migrationBuilder.CreateTable(
				name: "OATIConnectMeetingInvitees",
				columns: table => new
				{
					Id = table.Column<Guid>(nullable: false),
					MeetingId = table.Column<Guid>(nullable: false),
					Email = table.Column<string>(maxLength: 320, nullable: false),
					SourceKind = table.Column<string>(maxLength: 20, nullable: false),
					CreatedAtUtc = table.Column<DateTime>(nullable: false)
				},
				constraints: table =>
				{
					table.PrimaryKey("PK_OATIConnectMeetingInvitees", x => x.Id);
				});

			migrationBuilder.CreateIndex(
				name: "IX_OATIConnectMeetingInvitees_MeetingId",
				table: "OATIConnectMeetingInvitees",
				column: "MeetingId");

			migrationBuilder.CreateIndex(
				name: "IX_OATIConnectMeetingInvitees_Email",
				table: "OATIConnectMeetingInvitees",
				column: "Email");

			migrationBuilder.CreateTable(
				name: "OATIConnectMeetingParticipants",
				columns: table => new
				{
					Id = table.Column<Guid>(nullable: false),
					MeetingId = table.Column<Guid>(nullable: false),
					UserId = table.Column<int>(nullable: false),
					Name = table.Column<string>(maxLength: 200, nullable: false),
					Email = table.Column<string>(maxLength: 320, nullable: false),
					JoinedAtUtc = table.Column<DateTime>(nullable: false)
				},
				constraints: table =>
				{
					table.PrimaryKey("PK_OATIConnectMeetingParticipants", x => x.Id);
				});

			migrationBuilder.CreateIndex(
				name: "IX_OATIConnectMeetingParticipants_MeetingId",
				table: "OATIConnectMeetingParticipants",
				column: "MeetingId");

			migrationBuilder.CreateTable(
				name: "OATIConnectAppConfigs",
				columns: table => new
				{
					Id = table.Column<Guid>(nullable: false),
					Key = table.Column<string>(maxLength: 200, nullable: false),
					Value = table.Column<string>(maxLength: 4000, nullable: false),
					Description = table.Column<string>(maxLength: 1000, nullable: true),
					Category = table.Column<string>(maxLength: 100, nullable: false),
					CreatedAtUtc = table.Column<DateTime>(nullable: false),
					UpdatedAtUtc = table.Column<DateTime>(nullable: true)
				},
				constraints: table =>
				{
					table.PrimaryKey("PK_OATIConnectAppConfigs", x => x.Id);
				});

			migrationBuilder.CreateIndex(
				name: "IX_OATIConnectAppConfigs_Key",
				table: "OATIConnectAppConfigs",
				column: "Key",
				unique: true);
		}

		public override void Down(IOATIPreDownMigrationBuilder migrationBuilder)
		{
			migrationBuilder.DropTable(name: "OATIConnectAppConfigs");
			migrationBuilder.DropTable(name: "OATIConnectMeetingParticipants");
			migrationBuilder.DropTable(name: "OATIConnectMeetingInvitees");
			migrationBuilder.DropTable(name: "OATIConnectMeetings");
		}
	}
}
