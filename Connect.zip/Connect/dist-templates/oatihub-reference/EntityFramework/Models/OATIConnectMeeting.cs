﻿/***********************************************************************/
/*                            TRADE SECRET                             */
/*                                                                     */
/*     This computer program contains confidential and proprietary     */
/*      information of Open Access Technology International, Inc.      */
/*   This information is not to be used, disseminated, distributed,    */
/*  or otherwise transferred without the expressed written permission  */
/*            of Open Access Technology International, Inc.            */
/*                                                                     */
/*          (c)2025 Open Access Technology International, Inc.         */
/*                        All rights reserved.                         */
/***********************************************************************/
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OATIHub.EntityFramework.Models
{
	/// <summary>
	/// Meeting aggregate backing the OATIConnect integration. Owned by
	/// <see cref="HostUserId"/> (the framework user id surfaced by the
	/// host through IExternalUserProvider). Mirrors the entity shape
	/// defined in OATIConnect.API.dll so the JSON round-trip through the
	/// server's OATIConnectDataProvider stays lossless.
	/// </summary>
	public partial class OATIConnectMeeting
	{
		[Key]
		public Guid Id { get; set; }

		[Required]
		[StringLength(200)]
		public string Title { get; set; }

		[StringLength(2000)]
		public string Description { get; set; }

		public DateTime ScheduledTimeUtc { get; set; }

		public int DurationMinutes { get; set; }

		[Required]
		[StringLength(200)]
		public string RoomName { get; set; }

		[Required]
		[StringLength(20)]
		public string MeetingCode { get; set; }

		public int HostUserId { get; set; }

		/// <summary>Stored as int to match the OATIConnectMeetingStatus enum.</summary>
		public int Status { get; set; }

		public DateTime? ActualStartUtc { get; set; }

		public DateTime? ActualEndUtc { get; set; }

		public bool IsLocked { get; set; }

		public DateTime CreatedAtUtc { get; set; }
	}
}
