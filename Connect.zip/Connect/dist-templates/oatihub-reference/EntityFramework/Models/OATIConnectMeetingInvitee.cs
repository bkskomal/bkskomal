﻿/***********************************************************************/
/*                            TRADE SECRET                             */
/*                                                                     */
/*     This computer program contains confidential and proprietary     */
/*      information of Open Access Technology International, Inc.      */
/*   This information is not to be used, disseminated, distributed,    */
/*  or otherwise transferred without the expressed written permission  */
/*            of Open Access Technology International, Inc.            */
/*                                                                     */
/*          (c)2025 Open Access Technology International, Inc.         */
/*                        All rights reserved.                         */
/***********************************************************************/
using System;
using System.ComponentModel.DataAnnotations;

namespace OATIHub.EntityFramework.Models
{
	/// <summary>
	/// One row per invited recipient of an <see cref="OATIConnectMeeting"/>.
	/// </summary>
	public partial class OATIConnectMeetingInvitee
	{
		[Key]
		public Guid Id { get; set; }

		public Guid MeetingId { get; set; }

		[Required]
		[StringLength(320)]
		public string Email { get; set; }

		[Required]
		[StringLength(20)]
		public string SourceKind { get; set; }

		public DateTime CreatedAtUtc { get; set; }
	}
}
