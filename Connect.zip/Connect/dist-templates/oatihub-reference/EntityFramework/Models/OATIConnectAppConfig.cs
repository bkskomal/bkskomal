﻿/***********************************************************************/
/*                            TRADE SECRET                             */
/*                                                                     */
/*     This computer program contains confidential and proprietary     */
/*      information of Open Access Technology International, Inc.      */
/*   This information is not to be used, disseminated, distributed,    */
/*  or otherwise transferred without the expressed written permission  */
/*            of Open Access Technology International, Inc.            */
/*                                                                     */
/*          (c)2025 Open Access Technology International, Inc.         */
/*                        All rights reserved.                         */
/***********************************************************************/
using System;
using System.ComponentModel.DataAnnotations;

namespace OATIHub.EntityFramework.Models
{
	/// <summary>
	/// Universal key-value row for OATIConnect settings and meeting
	/// preferences (Branding, Jitsi, Pref:*, Toolbar:*).
	/// </summary>
	public partial class OATIConnectAppConfig
	{
		[Key]
		public Guid Id { get; set; }

		[Required]
		[StringLength(200)]
		public string Key { get; set; }

		[Required]
		[StringLength(4000)]
		public string Value { get; set; }

		[StringLength(1000)]
		public string Description { get; set; }

		[Required]
		[StringLength(100)]
		public string Category { get; set; }

		public DateTime CreatedAtUtc { get; set; }

		public DateTime? UpdatedAtUtc { get; set; }
	}
}
