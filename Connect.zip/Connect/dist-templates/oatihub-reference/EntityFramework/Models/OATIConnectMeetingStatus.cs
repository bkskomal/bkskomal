﻿/***********************************************************************/
/*                            TRADE SECRET                             */
/*                                                                     */
/*     This computer program contains confidential and proprietary     */
/*      information of Open Access Technology International, Inc.      */
/*   This information is not to be used, disseminated, distributed,    */
/*  or otherwise transferred without the expressed written permission  */
/*            of Open Access Technology International, Inc.            */
/*                                                                     */
/*          (c)2025 Open Access Technology International, Inc.         */
/*                        All rights reserved.                         */
/***********************************************************************/
namespace OATIHub.EntityFramework.Models
{
	/// <summary>
	/// Stored as int on <see cref="OATIConnectMeeting.Status"/>. Values
	/// MUST stay in sync with OATIConnect.API.Domain.Entities.MeetingStatus.
	/// </summary>
	public enum OATIConnectMeetingStatus
	{
		Scheduled = 0,
		Active    = 1,
		Ended     = 2,
		Cancelled = 3
	}
}
