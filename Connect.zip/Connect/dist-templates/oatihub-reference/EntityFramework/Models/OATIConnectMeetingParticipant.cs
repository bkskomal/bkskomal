﻿/***********************************************************************/
/*                            TRADE SECRET                             */
/*                                                                     */
/*     This computer program contains confidential and proprietary     */
/*      information of Open Access Technology International, Inc.      */
/*   This information is not to be used, disseminated, distributed,    */
/*  or otherwise transferred without the expressed written permission  */
/*            of Open Access Technology International, Inc.            */
/*                                                                     */
/*          (c)2025 Open Access Technology International, Inc.         */
/*                        All rights reserved.                         */
/***********************************************************************/
using System;
using System.ComponentModel.DataAnnotations;

namespace OATIHub.EntityFramework.Models
{
	/// <summary>
	/// One row per join of an <see cref="OATIConnectMeeting"/>. Re-joins
	/// produce additional rows so the host can see the full timeline.
	/// </summary>
	public partial class OATIConnectMeetingParticipant
	{
		[Key]
		public Guid Id { get; set; }

		public Guid MeetingId { get; set; }

		public int UserId { get; set; }

		[Required]
		[StringLength(200)]
		public string Name { get; set; }

		[Required]
		[StringLength(320)]
		public string Email { get; set; }

		public DateTime JoinedAtUtc { get; set; }
	}
}
