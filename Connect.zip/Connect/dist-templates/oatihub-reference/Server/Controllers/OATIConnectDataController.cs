﻿/***********************************************************************/
/*                            TRADE SECRET                             */
/*                                                                     */
/*     This computer program contains confidential and proprietary     */
/*      information of Open Access Technology International, Inc.      */
/*   This information is not to be used, disseminated, distributed,    */
/*  or otherwise transferred without the expressed written permission  */
/*            of Open Access Technology International, Inc.            */
/*                                                                     */
/*          (c)2025 Open Access Technology International, Inc.         */
/*                        All rights reserved.                         */
/***********************************************************************/
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OATIHub.EntityFramework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OATIHub.Server.Controllers
{
	// =========================================================================
	// Local DTOs — DELIBERATELY defined inside OATIHub.Server so this project
	// has ZERO reference to OATIConnect.API.dll. Only the main OATIHub app
	// references the DLL. The wire format (JSON property names / types) is
	// kept 1:1 with OATIConnect.API.Domain.Entities.* so the provider and
	// controller agree on the serialized shape without sharing types.
	//
	// If the DLL entity ever grows a new property, add it here too — the
	// compiler won''t flag the drift (different types on purpose) so this
	// contract is maintained by discipline, same as any cross-service JSON
	// API.
	// =========================================================================

	public class OATIConnectMeetingDto
	{
		public Guid      Id { get; set; }
		public string    Title { get; set; }
		public string    Description { get; set; }
		public DateTime  ScheduledTimeUtc { get; set; }
		public int       DurationMinutes { get; set; }
		public string    RoomName { get; set; }
		public string    MeetingCode { get; set; }
		public int       HostUserId { get; set; }

		/// <summary>
		/// Accepts BOTH numeric (0/1/2/3) AND string ("Scheduled"/"Active"/…)
		/// because the DLL entity is a <c>MeetingStatus</c> enum whose JSON
		/// default differs by host configuration. The custom converter below
		/// removes the guesswork so no global JsonSerializerOptions tweak is
		/// needed on the host.
		/// </summary>
		[JsonConverter(typeof(MeetingStatusTolerantConverter))]
		public int Status { get; set; }

		public DateTime? ActualStartUtc { get; set; }
		public DateTime? ActualEndUtc { get; set; }
		public bool      IsLocked { get; set; }
		public DateTime  CreatedAtUtc { get; set; }
	}

	public class OATIConnectMeetingInviteeDto
	{
		public Guid     Id { get; set; }
		public Guid     MeetingId { get; set; }
		public string   Email { get; set; }
		public string   SourceKind { get; set; }
		public DateTime CreatedAtUtc { get; set; }
	}

	public class OATIConnectMeetingParticipantDto
	{
		public Guid     Id { get; set; }
		public Guid     MeetingId { get; set; }
		public int      UserId { get; set; }
		public string   Name { get; set; }
		public string   Email { get; set; }
		public DateTime JoinedAtUtc { get; set; }
	}

	public class OATIConnectAppConfigDto
	{
		public Guid      Id { get; set; }
		public string    Key { get; set; }
		public string    Value { get; set; }
		public string    Description { get; set; }
		public string    Category { get; set; }
		public DateTime  CreatedAtUtc { get; set; }
		public DateTime? UpdatedAtUtc { get; set; }
	}

	/// <summary>
	/// Reads a <c>Status</c> property as either JSON number (0/1/2/3) or
	/// JSON string ("Scheduled"/"Active"/"Ended"/"Cancelled"), so the
	/// controller binds cleanly no matter how the DLL side was configured.
	/// Writes back as a number — compact and unambiguous.
	/// </summary>
	public class MeetingStatusTolerantConverter : JsonConverter<int>
	{
		public override int Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
		{
			if (reader.TokenType == JsonTokenType.Number)
				return reader.GetInt32();

			if (reader.TokenType == JsonTokenType.String)
			{
				var s = reader.GetString();
				if (int.TryParse(s, out var n)) return n;
				switch ((s ?? "").Trim().ToLowerInvariant())
				{
					case "scheduled": return 0;
					case "active":    return 1;
					case "ended":     return 2;
					case "cancelled": return 3;
				}
			}
			return 0; // default — Scheduled
		}

		public override void Write(Utf8JsonWriter writer, int value, JsonSerializerOptions options)
			=> writer.WriteNumberValue(value);
	}

	/// <summary>
	/// Data-access endpoints consumed by the OATIConnectDataProvider living
	/// in the main OATIHub app. This controller intentionally has ZERO
	/// reference to OATIConnect.API.dll — it speaks only local DTOs whose
	/// JSON shape matches the DLL entities. The main app is the only place
	/// that references OATIConnect.API.
	/// </summary>
	[ApiController]
	[IgnoreAntiforgeryToken]
	[Route("api/oaticonnect-data")]
	public class OATIConnectDataController : ControllerBase
	{
		/// <summary>
		/// Diagnostic no-op. If GET /api/oaticonnect-data/ping returns 200
		/// but other endpoints return 400, the failure is in model binding
		/// or request body handling — not in the routing / auth pipeline.
		/// If this also returns 400, the problem is in OATI''s middleware
		/// (anti-forgery, route filters, OATIBaseController requirements).
		/// </summary>
		[HttpGet("ping")]
		public IActionResult Ping() => Ok(new { ok = true, time = DateTime.UtcNow });

		/// <summary>
		/// Emits the literal JSON token <c>null</c> (4 bytes, content-type
		/// <c>application/json</c>) as the response body. We can't use
		/// <c>Ok((object)null)</c> because webVision's Newtonsoft.Json
		/// serializer is configured to skip null values — that produces an
		/// empty 200 body, which then trips a "no JSON tokens" exception
		/// inside the OATIConnect.API HTTP adapter on the consuming side.
		/// Forcing a literal "null" string keeps the wire shape valid JSON
		/// regardless of host serializer config.
		/// </summary>
		private ContentResult JsonNull() => Content("null", "application/json");

		// ===== Meetings =====

		[HttpGet("meetings/{meetingId:guid}")]
		public IActionResult GetMeetingById(Guid meetingId)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var m = db.OATIConnectMeetings.AsNoTracking().FirstOrDefault(x => x.Id == meetingId);
				return m == null ? (IActionResult)JsonNull() : Ok(ToDto(m));
			}
		}

		[HttpGet("meetings/active-by-room")]
		public IActionResult GetActiveMeetingByRoomName([FromQuery] string roomName)
		{
			using (var db = new Application_FrameworkEntities())
			{
				// Status != 3 (Cancelled)
				var m = db.OATIConnectMeetings.AsNoTracking()
					.Where(x => x.RoomName == roomName && x.Status != 3)
					.OrderByDescending(x => x.CreatedAtUtc)
					.FirstOrDefault();
				return m == null ? (IActionResult)JsonNull() : Ok(ToDto(m));
			}
		}

		[HttpGet("meetings/visible")]
		public IActionResult GetVisibleMeetings([FromQuery] int userId, [FromQuery] string email)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows =
					(from m in db.OATIConnectMeetings.AsNoTracking()
					 where m.HostUserId == userId
					    || db.OATIConnectMeetingInvitees.Any(i => i.MeetingId == m.Id && i.Email == email)
					 orderby m.ScheduledTimeUtc descending
					 select m).ToList();

				return Ok(rows.Select(ToDto).ToList());
			}
		}

		[HttpPost("meetings")]
		public IActionResult AddMeeting([FromBody] OATIConnectMeetingDto meeting)
		{
			if (meeting == null) return BadRequest("meeting is required");
			using (var db = new Application_FrameworkEntities())
			{
				var row = FromDto(meeting);
				db.OATIConnectMeetings.Add(row);
				db.SaveChanges();
				return Ok(ToDto(row));
			}
		}

		[HttpPut("meetings")]
		public IActionResult UpdateMeeting([FromBody] OATIConnectMeetingDto meeting)
		{
			if (meeting == null) return BadRequest("meeting is required");
			using (var db = new Application_FrameworkEntities())
			{
				var existing = db.OATIConnectMeetings.FirstOrDefault(x => x.Id == meeting.Id);
				if (existing == null) return NotFound();

				existing.Title            = meeting.Title;
				existing.Description      = meeting.Description;
				existing.ScheduledTimeUtc = meeting.ScheduledTimeUtc;
				existing.DurationMinutes  = meeting.DurationMinutes;
				existing.RoomName         = meeting.RoomName;
				existing.MeetingCode      = meeting.MeetingCode;
				existing.HostUserId       = meeting.HostUserId;
				existing.Status           = meeting.Status;
				existing.ActualStartUtc   = meeting.ActualStartUtc;
				existing.ActualEndUtc     = meeting.ActualEndUtc;
				existing.IsLocked         = meeting.IsLocked;
				db.SaveChanges();
				return Ok();
			}
		}

		[HttpDelete("meetings/{meetingId:guid}")]
		public IActionResult DeleteMeeting(Guid meetingId)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var m = db.OATIConnectMeetings.FirstOrDefault(x => x.Id == meetingId);
				if (m != null)
				{
					db.OATIConnectMeetings.Remove(m);

					var inv = db.OATIConnectMeetingInvitees.Where(i => i.MeetingId == meetingId);
					db.OATIConnectMeetingInvitees.RemoveRange(inv);

					var par = db.OATIConnectMeetingParticipants.Where(p => p.MeetingId == meetingId);
					db.OATIConnectMeetingParticipants.RemoveRange(par);

					db.SaveChanges();
				}
				return Ok();
			}
		}

		// ===== Invitees =====

		[HttpGet("meetings/{meetingId:guid}/invitees")]
		public IActionResult GetInvitees(Guid meetingId)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows = db.OATIConnectMeetingInvitees.AsNoTracking()
					.Where(x => x.MeetingId == meetingId).ToList();
				return Ok(rows.Select(ToDto).ToList());
			}
		}

		[HttpPut("meetings/{meetingId:guid}/invitees")]
		public IActionResult ReplaceInvitees(Guid meetingId, [FromBody] List<OATIConnectMeetingInviteeDto> invitees)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var existing = db.OATIConnectMeetingInvitees.Where(x => x.MeetingId == meetingId);
				db.OATIConnectMeetingInvitees.RemoveRange(existing);

				if (invitees != null)
				{
					foreach (var i in invitees)
					{
						var row = FromDto(i);
						row.MeetingId = meetingId;
						if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
						db.OATIConnectMeetingInvitees.Add(row);
					}
				}
				db.SaveChanges();
				return Ok();
			}
		}

		// ===== Participants =====

		[HttpGet("meetings/{meetingId:guid}/participants")]
		public IActionResult GetParticipants(Guid meetingId)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows = db.OATIConnectMeetingParticipants.AsNoTracking()
					.Where(x => x.MeetingId == meetingId)
					.OrderBy(x => x.JoinedAtUtc)
					.ToList();
				return Ok(rows.Select(ToDto).ToList());
			}
		}

		[HttpPost("participants")]
		public IActionResult AddParticipant([FromBody] OATIConnectMeetingParticipantDto participant)
		{
			if (participant == null) return BadRequest("participant is required");
			using (var db = new Application_FrameworkEntities())
			{
				var row = FromDto(participant);
				if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
				db.OATIConnectMeetingParticipants.Add(row);
				db.SaveChanges();
				return Ok();
			}
		}

		// ===== AppConfigs =====

		[HttpGet("appconfigs")]
		public IActionResult GetAllAppConfigs()
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows = db.OATIConnectAppConfigs.AsNoTracking().ToList();
				return Ok(rows.Select(ToDto).ToList());
			}
		}

		[HttpGet("appconfigs/by-key")]
		public IActionResult GetAppConfigByKey([FromQuery] string key)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var row = db.OATIConnectAppConfigs.AsNoTracking().FirstOrDefault(x => x.Key == key);
				return row == null ? (IActionResult)JsonNull() : Ok(ToDto(row));
			}
		}

		[HttpPost("appconfigs/upsert")]
		public IActionResult UpsertAppConfig([FromBody] OATIConnectAppConfigDto config)
		{
			if (config == null) return BadRequest("config is required");
			using (var db = new Application_FrameworkEntities())
			{
				var existing = db.OATIConnectAppConfigs.FirstOrDefault(x => x.Key == config.Key);
				if (existing == null)
				{
					var row = FromDto(config);
					if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
					if (row.CreatedAtUtc == default(DateTime)) row.CreatedAtUtc = DateTime.UtcNow;
					db.OATIConnectAppConfigs.Add(row);
					db.SaveChanges();
					return Ok(ToDto(row));
				}

				existing.Value        = config.Value;
				existing.Description  = config.Description ?? existing.Description;
				existing.Category     = string.IsNullOrWhiteSpace(config.Category) ? existing.Category : config.Category;
				existing.UpdatedAtUtc = DateTime.UtcNow;
				db.SaveChanges();
				return Ok(ToDto(existing));
			}
		}

		// =====================================================================
		// DTO <-> EF mappers
		//
		// EF6 reads DateTime columns back with Kind=Unspecified — System.Text.Json
		// then drops the trailing "Z" on serialize, and the React UI parses the
		// resulting "2026-07-15T21:00:00" as LOCAL time. Result: meetings appear
		// shifted by the user's UTC offset and the "Ended/Active/Scheduled"
		// status math goes wrong. Re-stamp Kind=Utc on every DateTime we hand to
		// the wire so the JSON always carries "Z" and downstream consumers
		// (React, the OATIConnect.API DLL) treat the value as UTC.
		// =====================================================================

		private static DateTime  Utc(DateTime  v) => DateTime.SpecifyKind(v, DateTimeKind.Utc);
		private static DateTime? Utc(DateTime? v) => v.HasValue ? (DateTime?)DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : null;

		private static OATIConnectMeetingDto ToDto(OATIConnectMeeting m) => new OATIConnectMeetingDto
		{
			Id               = m.Id,
			Title            = m.Title,
			Description      = m.Description,
			ScheduledTimeUtc = Utc(m.ScheduledTimeUtc),
			DurationMinutes  = m.DurationMinutes,
			RoomName         = m.RoomName,
			MeetingCode      = m.MeetingCode,
			HostUserId       = m.HostUserId,
			Status           = m.Status,
			ActualStartUtc   = Utc(m.ActualStartUtc),
			ActualEndUtc     = Utc(m.ActualEndUtc),
			IsLocked         = m.IsLocked,
			CreatedAtUtc     = Utc(m.CreatedAtUtc),
		};

		private static OATIConnectMeeting FromDto(OATIConnectMeetingDto m) => new OATIConnectMeeting
		{
			Id               = m.Id == Guid.Empty ? Guid.NewGuid() : m.Id,
			Title            = m.Title,
			Description      = m.Description,
			ScheduledTimeUtc = m.ScheduledTimeUtc,
			DurationMinutes  = m.DurationMinutes,
			RoomName         = m.RoomName,
			MeetingCode      = m.MeetingCode,
			HostUserId       = m.HostUserId,
			Status           = m.Status,
			ActualStartUtc   = m.ActualStartUtc,
			ActualEndUtc     = m.ActualEndUtc,
			IsLocked         = m.IsLocked,
			CreatedAtUtc     = m.CreatedAtUtc == default(DateTime) ? DateTime.UtcNow : m.CreatedAtUtc,
		};

		private static OATIConnectMeetingInviteeDto ToDto(OATIConnectMeetingInvitee x) => new OATIConnectMeetingInviteeDto
		{
			Id           = x.Id,
			MeetingId    = x.MeetingId,
			Email        = x.Email,
			SourceKind   = x.SourceKind,
			CreatedAtUtc = Utc(x.CreatedAtUtc),
		};

		private static OATIConnectMeetingInvitee FromDto(OATIConnectMeetingInviteeDto x) => new OATIConnectMeetingInvitee
		{
			Id           = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
			MeetingId    = x.MeetingId,
			Email        = x.Email,
			SourceKind   = string.IsNullOrWhiteSpace(x.SourceKind) ? "manual" : x.SourceKind,
			CreatedAtUtc = x.CreatedAtUtc == default(DateTime) ? DateTime.UtcNow : x.CreatedAtUtc,
		};

		private static OATIConnectMeetingParticipantDto ToDto(OATIConnectMeetingParticipant x) => new OATIConnectMeetingParticipantDto
		{
			Id          = x.Id,
			MeetingId   = x.MeetingId,
			UserId      = x.UserId,
			Name        = x.Name,
			Email       = x.Email,
			JoinedAtUtc = Utc(x.JoinedAtUtc),
		};

		private static OATIConnectMeetingParticipant FromDto(OATIConnectMeetingParticipantDto x) => new OATIConnectMeetingParticipant
		{
			Id          = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
			MeetingId   = x.MeetingId,
			UserId      = x.UserId,
			Name        = x.Name,
			Email       = x.Email,
			JoinedAtUtc = x.JoinedAtUtc == default(DateTime) ? DateTime.UtcNow : x.JoinedAtUtc,
		};

		private static OATIConnectAppConfigDto ToDto(OATIConnectAppConfig x) => new OATIConnectAppConfigDto
		{
			Id           = x.Id,
			Key          = x.Key,
			Value        = x.Value,
			Description  = x.Description,
			Category     = x.Category,
			CreatedAtUtc = Utc(x.CreatedAtUtc),
			UpdatedAtUtc = Utc(x.UpdatedAtUtc),
		};

		private static OATIConnectAppConfig FromDto(OATIConnectAppConfigDto x) => new OATIConnectAppConfig
		{
			Id           = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
			Key          = x.Key,
			Value        = x.Value,
			Description  = x.Description,
			Category     = string.IsNullOrWhiteSpace(x.Category) ? "General" : x.Category,
			CreatedAtUtc = x.CreatedAtUtc == default(DateTime) ? DateTime.UtcNow : x.CreatedAtUtc,
			UpdatedAtUtc = x.UpdatedAtUtc,
		};
	}
}



