using Microsoft.AspNetCore.Http;
using OATIConnect.API.Domain.Entities;
using OATIConnect.API.OATIConnectData;
using OATIHub.EntityFramework.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

// =============================================================================
//  OATIConnectDataProvider — DIRECT DB implementation, DI-compatible ctor
//
//  Earlier versions of this file made HTTP calls back to the host's own
//  /api/oaticonnect-data/* endpoints. That produced 502 Bad Gateway errors
//  under IIS during POST flows — classic sync-over-async-over-HTTP-loopback
//  deadlock. Symptom: meeting creation returned
//      {"StatusCode":500,"ExceptionDetail":"Response status code does not
//       indicate success: 502 (Bad Gateway)"}
//
//  Since OATIConnect.API.dll and Application_FrameworkEntities live in the
//  SAME process, we now bypass HTTP entirely and call EF directly.
//
//  The ctor still accepts (HttpClient, IHttpContextAccessor) for backwards
//  compatibility with existing DI registrations — typically:
//      services.AddHttpClient<OATIConnectDataProvider>();
//      services.AddScoped<IOATIConnectDataProvider, OATIConnectDataProvider>();
//  No startup change is required to deploy this file. The injected services
//  are simply unused; if you want to clean up later, drop the AddHttpClient
//  line and the parameters can be removed.
// =============================================================================

namespace OATIHub
{
	public class OATIConnectDataProvider : IOATIConnectDataProvider
	{
		// Held purely to satisfy existing DI registrations like
		// services.AddHttpClient<OATIConnectDataProvider>(). The fields are
		// never read — every method opens its own EF context and returns.
		// Keeping the parameters means dropping in this file is zero-config:
		// no Startup.cs / Program.cs change required.
		private readonly HttpClient? _http;
		private readonly IHttpContextAccessor? _http_ctx;

		// Parameterless ctor for hosts that registered with AddScoped only.
		public OATIConnectDataProvider() { }

		// Legacy ctor — keeps services.AddHttpClient<OATIConnectDataProvider>()
		// working without a startup change. The args are ignored at runtime.
		public OATIConnectDataProvider(HttpClient http, IHttpContextAccessor httpContextAccessor)
		{
			_http     = http;
			_http_ctx = httpContextAccessor;
		}

		// ---------- Meetings ----------

		public Task<Meeting?> GetMeetingByIdAsync(Guid meetingId, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var row = db.OATIConnectMeetings.AsNoTracking().FirstOrDefault(x => x.Id == meetingId);
				return Task.FromResult<Meeting?>(row == null ? null : ToEntity(row));
			}
		}

		public Task<Meeting?> GetActiveMeetingByRoomNameAsync(string roomName, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var row = db.OATIConnectMeetings.AsNoTracking()
					.Where(x => x.RoomName == roomName && x.Status != 3)   // Status 3 = Cancelled
					.OrderByDescending(x => x.CreatedAtUtc)
					.FirstOrDefault();
				return Task.FromResult<Meeting?>(row == null ? null : ToEntity(row));
			}
		}

		public Task<IReadOnlyList<Meeting>> GetVisibleMeetingsAsync(int userId, string? email, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows =
					(from m in db.OATIConnectMeetings.AsNoTracking()
					 where m.HostUserId == userId
					    || db.OATIConnectMeetingInvitees.Any(i => i.MeetingId == m.Id && i.Email == email)
					 orderby m.ScheduledTimeUtc descending
					 select m).ToList();
				return Task.FromResult<IReadOnlyList<Meeting>>(rows.Select(ToEntity).ToList());
			}
		}

		public Task AddMeetingAsync(Meeting meeting, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				db.OATIConnectMeetings.Add(FromEntity(meeting));
				db.SaveChanges();
				return Task.CompletedTask;
			}
		}

		public Task UpdateMeetingAsync(Meeting meeting, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var existing = db.OATIConnectMeetings.FirstOrDefault(x => x.Id == meeting.Id);
				if (existing == null) return Task.CompletedTask;

				existing.Title            = meeting.Title;
				existing.Description      = meeting.Description;
				existing.ScheduledTimeUtc = meeting.ScheduledTimeUtc;
				existing.DurationMinutes  = meeting.DurationMinutes;
				existing.RoomName         = meeting.RoomName;
				existing.MeetingCode      = meeting.MeetingCode;
				existing.HostUserId       = meeting.HostUserId;
				existing.Status           = (int)meeting.Status;
				existing.ActualStartUtc   = meeting.ActualStartUtc;
				existing.ActualEndUtc     = meeting.ActualEndUtc;
				existing.IsLocked         = meeting.IsLocked;
				db.SaveChanges();
				return Task.CompletedTask;
			}
		}

		public Task DeleteMeetingAsync(Guid meetingId, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var m = db.OATIConnectMeetings.FirstOrDefault(x => x.Id == meetingId);
				if (m != null)
				{
					db.OATIConnectMeetings.Remove(m);

					var inv = db.OATIConnectMeetingInvitees.Where(i => i.MeetingId == meetingId);
					db.OATIConnectMeetingInvitees.RemoveRange(inv);

					var par = db.OATIConnectMeetingParticipants.Where(p => p.MeetingId == meetingId);
					db.OATIConnectMeetingParticipants.RemoveRange(par);

					db.SaveChanges();
				}
				return Task.CompletedTask;
			}
		}

		// ---------- Invitees ----------

		public Task<IReadOnlyList<MeetingInvitee>> GetInviteesAsync(Guid meetingId, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows = db.OATIConnectMeetingInvitees.AsNoTracking()
					.Where(x => x.MeetingId == meetingId).ToList();
				return Task.FromResult<IReadOnlyList<MeetingInvitee>>(rows.Select(ToEntity).ToList());
			}
		}

		public Task ReplaceInviteesAsync(Guid meetingId, IEnumerable<MeetingInvitee> invitees, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var existing = db.OATIConnectMeetingInvitees.Where(x => x.MeetingId == meetingId);
				db.OATIConnectMeetingInvitees.RemoveRange(existing);

				foreach (var i in invitees ?? Enumerable.Empty<MeetingInvitee>())
				{
					var row = FromEntity(i);
					row.MeetingId = meetingId;
					if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
					db.OATIConnectMeetingInvitees.Add(row);
				}
				db.SaveChanges();
				return Task.CompletedTask;
			}
		}

		// ---------- Participants ----------

		public Task<IReadOnlyList<MeetingParticipant>> GetParticipantsAsync(Guid meetingId, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows = db.OATIConnectMeetingParticipants.AsNoTracking()
					.Where(x => x.MeetingId == meetingId)
					.OrderBy(x => x.JoinedAtUtc)
					.ToList();
				return Task.FromResult<IReadOnlyList<MeetingParticipant>>(rows.Select(ToEntity).ToList());
			}
		}

		public Task AddParticipantAsync(MeetingParticipant participant, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var row = FromEntity(participant);
				if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
				db.OATIConnectMeetingParticipants.Add(row);
				db.SaveChanges();
				return Task.CompletedTask;
			}
		}

		// ---------- App Configs ----------

		public Task<IReadOnlyList<AppConfig>> GetAllAppConfigsAsync(CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var rows = db.OATIConnectAppConfigs.AsNoTracking().ToList();
				return Task.FromResult<IReadOnlyList<AppConfig>>(rows.Select(ToEntity).ToList());
			}
		}

		public Task<AppConfig?> GetAppConfigByKeyAsync(string key, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var row = db.OATIConnectAppConfigs.AsNoTracking().FirstOrDefault(x => x.Key == key);
				return Task.FromResult<AppConfig?>(row == null ? null : ToEntity(row));
			}
		}

		public Task<AppConfig> UpsertAppConfigAsync(AppConfig config, CancellationToken ct = default)
		{
			using (var db = new Application_FrameworkEntities())
			{
				var existing = db.OATIConnectAppConfigs.FirstOrDefault(x => x.Key == config.Key);
				if (existing == null)
				{
					var row = FromEntity(config);
					if (row.Id == Guid.Empty) row.Id = Guid.NewGuid();
					if (row.CreatedAtUtc == default(DateTime)) row.CreatedAtUtc = DateTime.UtcNow;
					db.OATIConnectAppConfigs.Add(row);
					db.SaveChanges();
					return Task.FromResult(ToEntity(row));
				}

				existing.Value        = config.Value;
				existing.Description  = config.Description ?? existing.Description;
				existing.Category     = string.IsNullOrWhiteSpace(config.Category) ? existing.Category : config.Category;
				existing.UpdatedAtUtc = DateTime.UtcNow;
				db.SaveChanges();
				return Task.FromResult(ToEntity(existing));
			}
		}

		// =====================================================================
		//  EF row <-> Domain entity mapping
		//
		//  Re-stamp Kind=Utc on every DateTime we hand back to OATIConnect.API.
		//  EF reads DateTime columns as Kind=Unspecified — System.Text.Json
		//  then drops the trailing "Z" on serialize, the React UI parses the
		//  value as local time, and timezone math goes wrong (meetings render
		//  at the wrong hour, the Scheduled/Active/Ended badge calculation
		//  flips). Doing it here keeps the wire JSON correct regardless of
		//  what serializer the host is configured with.
		// =====================================================================

		private static DateTime  Utc(DateTime  v) => DateTime.SpecifyKind(v, DateTimeKind.Utc);
		private static DateTime? Utc(DateTime? v) => v.HasValue ? (DateTime?)DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : null;

		private static Meeting ToEntity(OATIConnectMeeting m) => new Meeting
		{
			Id               = m.Id,
			Title            = m.Title,
			Description      = m.Description,
			ScheduledTimeUtc = Utc(m.ScheduledTimeUtc),
			DurationMinutes  = m.DurationMinutes,
			RoomName         = m.RoomName,
			MeetingCode      = m.MeetingCode,
			HostUserId       = m.HostUserId,
			Status           = (MeetingStatus)m.Status,
			ActualStartUtc   = Utc(m.ActualStartUtc),
			ActualEndUtc     = Utc(m.ActualEndUtc),
			IsLocked         = m.IsLocked,
			CreatedAtUtc     = Utc(m.CreatedAtUtc),
		};

		private static OATIConnectMeeting FromEntity(Meeting m) => new OATIConnectMeeting
		{
			Id               = m.Id == Guid.Empty ? Guid.NewGuid() : m.Id,
			Title            = m.Title,
			Description      = m.Description,
			ScheduledTimeUtc = m.ScheduledTimeUtc,
			DurationMinutes  = m.DurationMinutes,
			RoomName         = m.RoomName,
			MeetingCode      = m.MeetingCode,
			HostUserId       = m.HostUserId,
			Status           = (int)m.Status,
			ActualStartUtc   = m.ActualStartUtc,
			ActualEndUtc     = m.ActualEndUtc,
			IsLocked         = m.IsLocked,
			CreatedAtUtc     = m.CreatedAtUtc == default(DateTime) ? DateTime.UtcNow : m.CreatedAtUtc,
		};

		private static MeetingInvitee ToEntity(OATIConnectMeetingInvitee x) => new MeetingInvitee
		{
			Id           = x.Id,
			MeetingId    = x.MeetingId,
			Email        = x.Email,
			SourceKind   = x.SourceKind,
			CreatedAtUtc = Utc(x.CreatedAtUtc),
		};

		private static OATIConnectMeetingInvitee FromEntity(MeetingInvitee x) => new OATIConnectMeetingInvitee
		{
			Id           = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
			MeetingId    = x.MeetingId,
			Email        = x.Email,
			SourceKind   = string.IsNullOrWhiteSpace(x.SourceKind) ? "manual" : x.SourceKind,
			CreatedAtUtc = x.CreatedAtUtc == default(DateTime) ? DateTime.UtcNow : x.CreatedAtUtc,
		};

		private static MeetingParticipant ToEntity(OATIConnectMeetingParticipant x) => new MeetingParticipant
		{
			Id          = x.Id,
			MeetingId   = x.MeetingId,
			UserId      = x.UserId,
			Name        = x.Name ?? "",
			Email       = x.Email ?? "",
			JoinedAtUtc = Utc(x.JoinedAtUtc),
		};

		private static OATIConnectMeetingParticipant FromEntity(MeetingParticipant x) => new OATIConnectMeetingParticipant
		{
			Id          = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
			MeetingId   = x.MeetingId,
			UserId      = x.UserId,
			Name        = x.Name,
			Email       = x.Email,
			JoinedAtUtc = x.JoinedAtUtc == default(DateTime) ? DateTime.UtcNow : x.JoinedAtUtc,
		};

		private static AppConfig ToEntity(OATIConnectAppConfig x) => new AppConfig
		{
			Id           = x.Id,
			Key          = x.Key,
			Value        = x.Value ?? "",
			Description  = x.Description,
			Category     = x.Category ?? "",
			CreatedAtUtc = Utc(x.CreatedAtUtc),
			UpdatedAtUtc = Utc(x.UpdatedAtUtc),
		};

		private static OATIConnectAppConfig FromEntity(AppConfig x) => new OATIConnectAppConfig
		{
			Id           = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
			Key          = x.Key,
			Value        = x.Value,
			Description  = x.Description,
			Category     = string.IsNullOrWhiteSpace(x.Category) ? "General" : x.Category,
			CreatedAtUtc = x.CreatedAtUtc == default(DateTime) ? DateTime.UtcNow : x.CreatedAtUtc,
			UpdatedAtUtc = x.UpdatedAtUtc,
		};
	}
}
