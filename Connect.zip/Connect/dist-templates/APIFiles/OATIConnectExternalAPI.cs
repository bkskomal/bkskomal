﻿using OATI.webVision.SecurityAdministration;
using OATI.webVision.Server.Core.Model;
using OATI.webVision.Server.Core.User;
using OATI.webVision.Server.Core.User.SystemUser;
using OATI.webVision.Server.Core.UserContext;
using OATI.webVisionServer.Interfaces;
using OATIConnect.API.Common;
using OATIConnect.API.ExternalUser;
using System.Threading.Tasks;

namespace OATIHub
{

	public class OATIConnectExternalAPI : IExternalUserProvider
	{
		private IOATIUserManagerRepository _userManagerRepository;
		private IOATIUserManagerRepository UserManagerRepository
		{
			get
			{
				if (_userManagerRepository == null)
				{
					_userManagerRepository = OATIWebVisionServerFactory.GetFactory().GetInstance<IOATIUserManagerRepository>();
				}

				return _userManagerRepository;
			}
		}

		public Task<ExternalUserInfo?> GetCurrentUserAsync()
		{
			var callingUser = UserContextHelper.GetOATIUser();

			if (callingUser == null || callingUser.UserId == 0)
			{
				var sys = SystemUserContextHelper.GetSystemUser();
				if (sys == null)
					return Task.FromResult<ExternalUserInfo?>(null);

				return Task.FromResult<ExternalUserInfo?>(new ExternalUserInfo(
					Id: sys.UserId,
					Name: $"{sys.FirstName} {sys.LastName}".Trim(),
					Email: $"{sys.UserName}@local",
					Role: "Standard",   
					IsActive: true,
					TimeZoneWindows: sys.Timezone ?? "",
					TimeZoneIana: TimeZoneMapper.ToIana(sys.Timezone)));
			}

			return Task.FromResult<ExternalUserInfo?>(new ExternalUserInfo(
				Id: callingUser.UserId,
				Name: $"{callingUser.FirstName} {callingUser.LastName}".Trim(),
				Email: $"{callingUser.UserName}@local",
				Role: MapRole(),
				IsActive: true,
				TimeZoneWindows: callingUser.Timezone ?? "",
				TimeZoneIana: TimeZoneMapper.ToIana(callingUser.Timezone)));
		}

		private string MapRole()
		{
			OATIUserPermissions permissions = UserManagerRepository.RetrieveUserPermissions();
			return permissions.IsAdmin ? "Admin" : "Standard";
		}

	}
}
