# ============================================================
#  build-oaticonnect.ps1
#
#  Produces a clean distribution drop for integrating OATIConnect
#  into an existing host ASP.NET Core app.
#
#  Output:  .\dist\
#    server\OATIConnect.API.dll            server-side class library (all business logic)
#    server\OATIConnect.API.pdb            debug symbols (optional)
#    client\oaticonnect.mjs           web component bundle (self-contained — CSS embedded in Shadow DOM)
#    config\jitsi-private-key.pem.sample     rename + drop real key next to your host exe
#    config\oaticonnect_config.sample.json   sidecar config file (rename, drop next to host exe)
#    templates\OATIMeetSessionAdapter.cs.sample  drop-in adapter: IOATIExternalAPI -> IExternalUserProvider
#    INTEGRATE.md                          step-by-step integration guide
#
#  Usage:
#    pwsh .\build-oaticonnect.ps1                # build both sides, copy to dist\
#    pwsh .\build-oaticonnect.ps1 -ServerOnly    # skip client build
#    pwsh .\build-oaticonnect.ps1 -ClientOnly    # skip server build
#    pwsh .\build-oaticonnect.ps1 -Clean         # delete dist\ before building
# ============================================================

[CmdletBinding()]
param(
    [switch]$ServerOnly,
    [switch]$ClientOnly,
    [switch]$Clean
)

$ErrorActionPreference = "Stop"

# Paths are resolved relative to this script so it works from any working dir.
$Root       = $PSScriptRoot
$ServerProj = Join-Path $Root "server\OATIConnect.API"
$ClientDir  = Join-Path $Root "server\OATIConnect.Client\Client"
$ServerDll  = Join-Path $Root "server\OATIConnect.API\bin\Release\net8.0\OATIConnect.API.dll"
$ServerPdb  = Join-Path $Root "server\OATIConnect.API\bin\Release\net8.0\OATIConnect.API.pdb"
$ClientOut  = Join-Path $Root "server\OATIConnect.Client\Client\dist-wc"
$Dist       = Join-Path $Root "dist"

function Section($msg) {
    Write-Host ""
    Write-Host "=== $msg ===" -ForegroundColor Cyan
}

if ($Clean -and (Test-Path $Dist)) {
    Section "Cleaning dist\"
    Remove-Item $Dist -Recurse -Force
}

New-Item -ItemType Directory -Force -Path "$Dist\server"    | Out-Null
New-Item -ItemType Directory -Force -Path "$Dist\client"    | Out-Null
New-Item -ItemType Directory -Force -Path "$Dist\config"    | Out-Null
New-Item -ItemType Directory -Force -Path "$Dist\templates" | Out-Null
New-Item -ItemType Directory -Force -Path "$Dist\extjs"     | Out-Null

# ---------- Server: OATIConnect.API class library (single DLL) ----------
if (-not $ClientOnly) {
    Section "Building server DLL"
    Push-Location $ServerProj
    try {
        & dotnet build -c Release
        if ($LASTEXITCODE -ne 0) { throw "dotnet build failed with exit code $LASTEXITCODE" }
    } finally { Pop-Location }

    if (-not (Test-Path $ServerDll)) {
        throw "Expected DLL not found at: $ServerDll"
    }

    Copy-Item $ServerDll -Destination "$Dist\server\" -Force
    if (Test-Path $ServerPdb) { Copy-Item $ServerPdb -Destination "$Dist\server\" -Force }

    $size = "{0:N0} KB" -f ((Get-Item "$Dist\server\OATIConnect.API.dll").Length / 1KB)
    Write-Host "  -> dist\server\OATIConnect.API.dll  ($size)" -ForegroundColor Green
}

# ---------- Client: web component bundle ----------
if (-not $ServerOnly) {
    Section "Building web component bundle"
    Push-Location $ClientDir
    try {
        if (-not (Test-Path "node_modules")) {
            Write-Host "  node_modules missing — running npm ci" -ForegroundColor Yellow
            & npm ci
            if ($LASTEXITCODE -ne 0) { throw "npm ci failed" }
        }
        & npm run build:wc
        if ($LASTEXITCODE -ne 0) { throw "npm run build:wc failed" }
    } finally { Pop-Location }

    Copy-Item "$ClientOut\oaticonnect.mjs" -Destination "$Dist\client\" -Force

    # Stamp the bundle with the build timestamp so it logs to console on load.
    # The same timestamp goes into OATIConnectView's `version` for the cache-busting
    # query string, so both prints should match — easy way to verify a deploy is clean.
    $bundleBuild = Get-Date -Format "yyyyMMddHHmmss"
    $bundlePath = Join-Path $Dist "client\oaticonnect.mjs"
    $bundleContent = Get-Content $bundlePath -Raw
    $bundleStamped = $bundleContent.Replace("__OATICONNECT_BUILD__", $bundleBuild)
    if ($bundleStamped -ne $bundleContent) {
        Set-Content -Path $bundlePath -Value $bundleStamped -NoNewline
        Write-Host "  -> stamped bundle build=$bundleBuild" -ForegroundColor Green
    }

    $mjsSize = "{0:N0} KB" -f ((Get-Item $bundlePath).Length / 1KB)
    Write-Host "  -> dist\client\oaticonnect.mjs  ($mjsSize, CSS embedded for Shadow DOM)" -ForegroundColor Green
}

# ---------- Config samples ----------
Section "Writing config samples"

$PemSrc = Join-Path $Root "server\OATIConnect.Client\jitsi-private-key.pem"
if (Test-Path $PemSrc) {
    # Sample only — we write a placeholder so real keys don't leak through the drop.
    @"
-----BEGIN RSA PRIVATE KEY-----
<<< REPLACE WITH YOUR REAL JITSI PRIVATE KEY >>>
-----END RSA PRIVATE KEY-----
"@ | Set-Content "$Dist\config\jitsi-private-key.pem.sample"
}

@'
{
  "// note":   "Rename to 'oaticonnect_config.json' and drop it next to your host app's executable (same folder as appsettings.json).",
  "// loader": "services.AddOATIConnect() reads this file automatically — same pattern as services.UseGenie() reading genie_config.json.",
  "// db":     "Connection string / DB provider live in YOUR host (the IOATIConnectDataProvider adapter). The DLL is persistence-agnostic and reads only the keys below.",

  "OATIConnect": {
    "Enabled": true,

    "Jitsi": {
      "ServerBaseUrl":  "qa.meet.oati.com",
      "AppId":          "oaticonnect",
      "PrivateKeyFile": "jitsi-private-key.pem"
    },

    "App": {
      "Name": "OATIConnect"
    }
  }
}
'@ | Set-Content "$Dist\config\oaticonnect_config.sample.json"

# Copy the adapter templates into dist/templates/. Host apps need:
#   - OATIMeetSessionAdapter         -> implements IExternalUserProvider
#                                       (bridges IOATIExternalAPI for OATI framework hosts)
#   - OATIConnectDataProviderAdapter -> implements IOATIConnectDataProvider
#                                       (CRUD against the host's own DbContext)
foreach ($tpl in @(
    'OATIMeetSessionAdapter.cs.sample',
    'OATIConnectDataProviderAdapter.cs.sample',
    'OATIConnectHttpDataProviderAdapter.cs.sample')) {
    $src = Join-Path $Root "dist-templates\$tpl"
    if (Test-Path $src) {
        Copy-Item $src -Destination "$Dist\templates\" -Force
    }
}

# ---------- APIFiles (host's IExternalUserProvider + IOATIConnectDataProvider) ----------
# These two .cs files are the actual implementations the OATIHub host ships
# in its main project — copied here so a deploy hand-off only needs to grab
# templates\APIFiles\* and drop into the host project tree (typically next
# to the host's other repository / DI wiring code).
#
# Source: dist-templates\APIFiles\ — survives `-Clean`, edited in place
# whenever the API contract or implementation changes. The build copies the
# whole folder verbatim into dist\templates\APIFiles\ so the user can ship
# the latest from CD without touching dist-templates manually.
Section "Copying APIFiles (host adapters)"
$ApiFilesSrcDir = Join-Path $Root "dist-templates\APIFiles"
$ApiFilesDstDir = Join-Path $Dist "templates\APIFiles"
if (Test-Path $ApiFilesSrcDir) {
    New-Item -ItemType Directory -Force -Path $ApiFilesDstDir | Out-Null
    Copy-Item (Join-Path $ApiFilesSrcDir "*") -Destination $ApiFilesDstDir -Recurse -Force
    Get-ChildItem $ApiFilesDstDir -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($Dist.Length + 1)
        Write-Host "  -> $rel" -ForegroundColor Green
    }
} else {
    Write-Host "  -> WARNING: $ApiFilesSrcDir missing — skipping" -ForegroundColor Yellow
}

# ---------- OATIHub reference files ----------
# Mirrors the exact controller / EF entities / EF migration that ship in the
# OATIHub.Server + OATIHub.EntityFramework production projects, so the
# integration drop carries authoritative side-by-side references that hosts
# can compare against.
#
# Sources (in order of preference):
#   1. The live production projects (..\OATIHub.Server, ..\OATIHub.EntityFramework
#      next to this OATIConnect tree) — picked first so the dist always reflects
#      the latest committed code.
#   2. The cached copy under dist-templates\oatihub-reference\ — used when the
#      production projects aren't on this machine (e.g. on a CI builder that
#      only has the OATIConnect repo).
#
# The cached copy is refreshed automatically from the live paths whenever
# they're available, so checking dist-templates\ into git keeps history.
Section "Copying OATIHub reference files"
$HubCacheDir = Join-Path $Root "dist-templates\oatihub-reference"
$HubLiveServer = Join-Path $Root "..\OATIHub.Server"
$HubLiveEf     = Join-Path $Root "..\OATIHub.EntityFramework"

$liveFiles = @(
    @{ live = (Join-Path $HubLiveServer "Controllers\OATIConnectDataController.cs");
       cache = (Join-Path $HubCacheDir "Server\Controllers\OATIConnectDataController.cs") },
    @{ live = (Join-Path $HubLiveEf "Models\OATIConnectMeeting.cs");
       cache = (Join-Path $HubCacheDir "EntityFramework\Models\OATIConnectMeeting.cs") },
    @{ live = (Join-Path $HubLiveEf "Models\OATIConnectMeetingInvitee.cs");
       cache = (Join-Path $HubCacheDir "EntityFramework\Models\OATIConnectMeetingInvitee.cs") },
    @{ live = (Join-Path $HubLiveEf "Models\OATIConnectMeetingParticipant.cs");
       cache = (Join-Path $HubCacheDir "EntityFramework\Models\OATIConnectMeetingParticipant.cs") },
    @{ live = (Join-Path $HubLiveEf "Models\OATIConnectAppConfig.cs");
       cache = (Join-Path $HubCacheDir "EntityFramework\Models\OATIConnectAppConfig.cs") },
    @{ live = (Join-Path $HubLiveEf "Models\OATIConnectMeetingStatus.cs");
       cache = (Join-Path $HubCacheDir "EntityFramework\Models\OATIConnectMeetingStatus.cs") },
    @{ live = (Join-Path $HubLiveEf "Migrations\20260506144328_Release_2_2_3_0_OATIConnect.cs");
       cache = (Join-Path $HubCacheDir "EntityFramework\Migrations\20260506144328_Release_2_2_3_0_OATIConnect.cs") }
)

foreach ($f in $liveFiles) {
    if (Test-Path $f.live) {
        New-Item -ItemType Directory -Force -Path (Split-Path $f.cache -Parent) | Out-Null
        Copy-Item $f.live -Destination $f.cache -Force
        Write-Host "  refreshed cache <- $((Resolve-Path $f.live).Path)" -ForegroundColor DarkGray
    }
}

if (Test-Path $HubCacheDir) {
    Copy-Item $HubCacheDir -Destination "$Dist\templates\" -Recurse -Force
    $HubDstDir = Join-Path $Dist "templates\oatihub-reference"
    Get-ChildItem $HubDstDir -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($Dist.Length + 1)
        Write-Host "  -> $rel" -ForegroundColor Green
    }
} else {
    Write-Host "  -> WARNING: no oatihub-reference source found, skipping" -ForegroundColor Yellow
}

# ---------- ExtJS / Sencha integration files ----------
# Authored in dist-templates/extjs/ so they survive `-Clean`. Copied into
# dist/extjs/ on every build for a Sencha host app to drop into
# Webvision/view/oaticonnect/ and call <oaticonnectview> directly.
Section "Copying ExtJS integration files"
$ExtJsSrcDir = Join-Path $Root "dist-templates\extjs"
$ExtJsDstDir = Join-Path $Dist "extjs"
foreach ($f in @('OATIConnectView.js','OATIWelcomePage.js','OATIWelcomePage.patch.md')) {
    $src = Join-Path $ExtJsSrcDir $f
    if (Test-Path $src) {
        Copy-Item $src -Destination "$ExtJsDstDir\" -Force
        Write-Host "  -> dist\extjs\$f" -ForegroundColor Green
    } else {
        Write-Host "  -> WARNING: dist-templates\extjs\$f missing" -ForegroundColor Yellow
    }
}

# ---------- Stamp the OATIConnectView with a fresh version ----------
# Browsers cache the .mjs bundle aggressively. The Loader in OATIConnectView
# appends ?v=<version> to the bundle URL. Rewrite a placeholder on every build
# so a new deployment always invalidates client caches. Stamp the COPY in
# dist/extjs/ (not the source in dist-templates/extjs/) so the source stays
# stable across builds.
$ViewFile = Join-Path $ExtJsDstDir "OATIConnectView.js"
if (Test-Path $ViewFile) {
    $version = Get-Date -Format "yyyyMMddHHmmss"
    $content = Get-Content $ViewFile -Raw
    # Replace either the placeholder (first build) or any previously stamped version.
    $stamped = [regex]::Replace($content,
        "version:\s*'(__OATICONNECT_VERSION__|\d{14})'",
        "version: '$version'")
    if ($stamped -ne $content) {
        Set-Content -Path $ViewFile -Value $stamped -NoNewline
        Write-Host "  -> stamped OATIConnectView.js with version=$version" -ForegroundColor Green
    }
}

# ---------- Integration guide ----------
$IntegrateMd = @'
# Integrating OATIConnect into your host app

This drop contains **one server class library DLL** (`server/OATIConnect.API.dll`)
and **one client bundle** (`client/oaticonnect.mjs`). Integration is five
steps: reference, identity adapter, data adapter, register, embed.

The DLL has **zero EF Core dependencies** — it talks to persistence through
`IOATIConnectDataProvider`, which the host implements against its own
DbContext.

---

## 1. Server: reference the class library DLL

In your host `.csproj`:

```xml
<ItemGroup>
  <Reference Include="OATIConnect.API">
    <HintPath>..\path\to\OATIConnect.API.dll</HintPath>
    <Private>true</Private>
  </Reference>
</ItemGroup>

<!-- Runtime dependencies the API DLL needs at the host's edge. -->
<ItemGroup>
  <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.23" />
  <PackageReference Include="Microsoft.IdentityModel.Tokens" Version="7.1.2" />
  <PackageReference Include="System.IdentityModel.Tokens.Jwt" Version="7.1.2" />
  <PackageReference Include="Microsoft.Extensions.Identity.Core" Version="8.0.23" />
</ItemGroup>

<!-- EF Core lives in YOUR host project, not in the API DLL. Pull in whichever
     providers your DbContext actually uses. -->
<ItemGroup>
  <PackageReference Include="Microsoft.EntityFrameworkCore" Version="8.0.4" />
  <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.4" />
  <PackageReference Include="Npgsql.EntityFrameworkCore.PostgreSQL" Version="8.0.4" />   <!-- optional -->
  <PackageReference Include="Pomelo.EntityFrameworkCore.MySql" Version="8.0.2" />        <!-- optional -->
</ItemGroup>
```

## 2. Host: drop in the session adapter (identity)

OATIConnect reads the current user through `IExternalUserProvider`. For hosts
already on the OATI framework, the easiest path is the ready-made adapter that
delegates to your existing `IOATIExternalAPI` — same interface you already
bind for Genie. Copy `templates/OATIMeetSessionAdapter.cs.sample` into your
project (e.g. `OATI.webVision.Demo.Repository`), rename the namespace, and
you're done. Its guts:

```csharp
using OATI.Genie.Server.Repository;               // your existing Genie contract
using OATIConnect.API.ExternalUser;

public class OATIMeetSessionAdapter : IExternalUserProvider
{
    private readonly IOATIExternalAPI _framework;
    public OATIMeetSessionAdapter(IOATIExternalAPI framework) => _framework = framework;

    public Task<ExternalUserInfo?> GetCurrentUserAsync()
    {
        var u = _framework.GetUser();
        if (u == null || u.UserId == 0) return Task.FromResult<ExternalUserInfo?>(null);

        // REQUIRED for correct invite times. The server generates the .ics +
        // email with no browser involved, so the ONLY source of the user's
        // zone is what you set here — omit it and every invitation is UTC.
        // Feed the short/Windows token webVision already carries (the same
        // CallingUser.Timezone you pass to OATITimeZone.ParseShort, e.g.
        // "CST"/"EST"/"IST"); TimeZoneMapper (shipped in the DLL) -> IANA.
        var shortTz = UserManagerRepository.RetrieveUser()?.Timezone;   // your existing accessor
        return Task.FromResult<ExternalUserInfo?>(new ExternalUserInfo(
            Id:    u.UserId,
            Name:  $"{u.FirstName} {u.LastName}".Trim(),
            Email: $"{u.Username}@local",
            Role:  MapRole(),
            IsActive: true,
            TimeZoneWindows: OATIConnect.API.Common.TimeZoneMapper.ToWindows(shortTz),
            TimeZoneIana:    OATIConnect.API.Common.TimeZoneMapper.ToIana(shortTz)));
    }

    // Single source of truth for admin status — same probe the React side
    // uses in the browser (Wv.OATIUser.getUserPermissions().IsAdmin), so
    // server and client never disagree about who's an admin.
    private static string MapRole()
    {
        OATIUserPermissions permissions = UserManagerRepository.RetrieveUserPermissions();
        return permissions != null && permissions.IsAdmin ? "Admin" : "Standard";
    }
}
```

The adapter maps framework 32-bit IDs to stable Guids (same int → same Guid
every run), so OATIConnect's EF Core FKs stay consistent.

> **Timezone is mandatory.** OATIConnect renders the `.ics` and email invite in
> the host user''s wall-clock. Those are generated **server-side** (no browser),
> so the only source of the user''s zone is the `TimeZoneWindows` / `TimeZoneIana`
> you set on `ExternalUserInfo`. Leave them blank and every invitation falls back
> to **UTC** — this is the #1 integration gotcha. `TimeZoneMapper` (in the DLL)
> accepts the short/Windows tokens webVision already uses, so it''s one line.

**Not on the OATI framework?** Skip the adapter, implement
`IExternalUserProvider` directly against your own auth/user store — same
interface, same registration.

Role values OATIConnect recognizes: `"Admin"`, `"Moderator"`, `"Standard"`.

## 3. Host: drop in the data provider (persistence)

OATIConnect.API has **no EF Core reference** — it reaches the database only
through `IOATIConnectDataProvider`, which the host implements. The drop
includes two ready-to-paste samples; pick the one that matches your host
architecture.

### 3a. Direct EF (single-project host)

If the project that references OATIConnect.API.dll **also owns the
DbContext**, paste `templates/OATIConnectDataProviderAdapter.cs.sample` and
wire it to your DbContext:

```csharp
using OATIConnect.API.Domain.Entities;
using OATIConnect.API.OATIConnectData;

public class OATIConnectDataProviderAdapter : IOATIConnectDataProvider
{
    private readonly YourHostDbContext _db;
    public OATIConnectDataProviderAdapter(YourHostDbContext db) => _db = db;

    public Task<Meeting?> GetMeetingByIdAsync(Guid id, CancellationToken ct = default)
        => _db.Set<Meeting>().FirstOrDefaultAsync(x => x.Id == id, ct);
    // ... (CRUD against the four DbSets — see the sample for the rest)
}
```

Add these `DbSet`s to your host's `DbContext` (entity types come from the
API DLL — reference them directly):

```csharp
public DbSet<Meeting>             Meetings             => Set<Meeting>();
public DbSet<MeetingInvitee>      MeetingInvitees      => Set<MeetingInvitee>();
public DbSet<MeetingParticipant>  MeetingParticipants  => Set<MeetingParticipant>();
public DbSet<AppConfig>           AppConfigs           => Set<AppConfig>();
```

Then run `Add-Migration AddOATIConnect` in your host project — the host
owns the schema and migration history.

### 3b. HTTP relay (decoupled host, e.g. OATIHub)

If your data layer lives in a **sibling service** that should NOT reference
OATIConnect.API.dll (e.g. OATIHub.Server's `OATIConnectDataController`),
paste `templates/OATIConnectHttpDataProviderAdapter.cs.sample` instead.
The sibling exposes endpoints under `/api/oaticonnect-data/*` using its own
local DTOs — only the main host that runs the API DLL references the DLL.

```csharp
services.AddHttpClient<OATIConnectHttpDataProviderAdapter>(c =>
    c.BaseAddress = new Uri(config["OATIHub:BaseUrl"]!));
services.AddScoped<IOATIConnectDataProvider, OATIConnectHttpDataProviderAdapter>();
```

The sibling defines its own EF entities (e.g. `OATIConnectMeeting` in
`OATIHub.EntityFramework.Models`) and maps to/from a wire DTO that mirrors
the DLL's entity shape 1:1.

## 4. Host: two-line registration (mirrors `UseGenie`)

Inside your `Startup.ApplicationConfigureServices` (or a minimal-hosting
`Program.cs`), alongside your existing Genie registration:

```csharp
using OATI.Genie.Server.Repository;                      // IOATIExternalAPI
using OATIConnect.API.ExternalUser;                      // IExternalUserProvider
using OATIConnect.API.OATIConnectData;                   // IOATIConnectDataProvider
using OATIConnect.API.DependencyInjection;               // AddOATIConnect / MapOATIConnect

// --- existing Genie registrations you already have ---
services.UseGenie();
services.AddTransient<IOATIExternalAPI, OATIGenieExternalAPI>();

// --- OATIConnect: identical shape to UseGenie ---
services.AddHttpContextAccessor();
services.AddScoped<IExternalUserProvider,    OATIMeetSessionAdapter>();        // step 2
services.AddScoped<IOATIConnectDataProvider, OATIConnectDataProviderAdapter>(); // step 3
services.AddOATIConnect();                                                     // reads oaticonnect_config.json
```

And in your `ApplicationConfigure` pipeline (also mirroring `ConfigureGenie`):

```csharp
app.ConfigureGenie();
app.MapOATIConnect();      // /api/v1/* + /oaticonnect/* routes + AppConfigs seed
```

That's it. `AddOATIConnect()` reads `oaticonnect_config.json` from the host's
content root — exactly the way `UseGenie()` reads `genie_config.json`.

### Sidecar file layout

Rename `config/oaticonnect_config.sample.json` (from this drop) to
`oaticonnect_config.json` and place it **next to your host's
`appsettings.json`** (same folder as the executable). Structure:

```jsonc
{
  "OATIConnect": {
    "Jitsi": {
      "ServerBaseUrl":  "qa.meet.oati.com",
      "AppId":          "meet-app",
      "PrivateKeyFile": "jitsi-private-key.pem"
    },

    "Email": {
      "EnableEmail": false,
      "SmtpHost": "",  "SmtpPort": 587,
      "SmtpUser": "",  "SmtpPassword": "",
      "FromEmail": "", "FromName": "YourAppName"
    },

    "EnableStandaloneAuth": false
  }
}
```

The DLL no longer carries connection-string / DB-provider settings — that
lives entirely in your host's `IOATIConnectDataProvider` adapter (step 3).
The sidecar covers only Jitsi + email + standalone-auth, which the DLL still
owns.

## Database — owned by the host

OATIConnect.API is **persistence-agnostic**. The host owns the DbContext (or
HTTP relay) and is responsible for creating the four tables backing the four
entity types in `OATIConnect.API.Domain.Entities`:

- `Meeting`              -> any table name (recommend `OATIConnectMeetings`)
- `MeetingInvitee`       -> e.g. `OATIConnectMeetingInvitees`
- `MeetingParticipant`   -> e.g. `OATIConnectMeetingParticipants`
- `AppConfig`            -> e.g. `OATIConnectAppConfigs`  *(stores Jitsi URL,
                              SMTP defaults — seeded on first boot from
                              `oaticonnect_config.json`)*

For step 3a (direct EF), run `Add-Migration AddOATIConnect` in your host
project. For step 3b (HTTP relay), the sibling service owns the schema (see
`OATIHub.EntityFramework` for the canonical layout).

### Copy the Jitsi private key
Put your real `jitsi-private-key.pem` next to your host app's executable (same
directory as `appsettings.json`) and keep the same filename referenced in
`Jitsi.PrivateKeyFile` above.

## 5. Client: embed the web component

Copy `client/oaticonnect.mjs` (and `.css` if you want to inspect; the mjs
ships inline styles) to somewhere your host serves as a static asset, e.g.
`wwwroot/meet/oaticonnect.mjs`. Then in any host page:

```html
<oaticonnect-meet
    api-base="/api/v1"
    user-id="{{ current user id }}"
    user-name="{{ current user name }}"
    user-email="{{ current user email }}"
    user-role="{{ Admin | Moderator | Standard }}"
    org-id="{{ current user org id }}"
    org-name="{{ current user org name }}"
    theme="light"
    auth-enabled="false"
></oaticonnect-meet>

<script type="module" src="/meet/oaticonnect.mjs"></script>
```

Shadow DOM isolates all styles — no CSS collisions with your host.

---

## Config + file placement (next to your host executable)

```
<host-publish-folder>/
  MyHostApp.exe
  appsettings.json                   (your existing file — untouched)
  genie_config.json                  (your existing Genie sidecar — untouched)
  oaticonnect_config.json            (rename from config/oaticonnect_config.sample.json)
  jitsi-private-key.pem              (rename from config/jitsi-private-key.pem.sample — paste real key)
  OATI.Genie.Server.dll              (your existing reference — untouched)
  OATIConnect.API.dll                (copy from server/)
  wwwroot/meet/oaticonnect.mjs  (copy from client/)
  wwwroot/meet/oaticonnect.css
```

### Authoritative reference: `templates/oatihub-reference/`

The drop also carries the **exact** files shipping in the OATIHub
production projects, so you have a side-by-side reference instead of
having to derive them:

```
templates/oatihub-reference/
  Server/Controllers/OATIConnectDataController.cs       (the HTTP relay endpoint)
  EntityFramework/Models/OATIConnectMeeting.cs          (4 entity classes)
  EntityFramework/Models/OATIConnectMeetingInvitee.cs
  EntityFramework/Models/OATIConnectMeetingParticipant.cs
  EntityFramework/Models/OATIConnectAppConfig.cs
  EntityFramework/Models/OATIConnectMeetingStatus.cs    (status enum)
  EntityFramework/Migrations/<datestamp>_Release_..._OATIConnect.cs
                                                        (creates the four
                                                         tables + indexes)
```

These are not templates with placeholders — they are the production
source. If you're integrating into a fresh host, drop them in verbatim,
adjust namespaces if needed, and run the migration.

Plus two source files added to your project (not publish folder):

```
<your-project>/.../Repository/OATIMeetSessionAdapter.cs
                              (copy from templates/OATIMeetSessionAdapter.cs.sample)

<your-project>/.../Repository/OATIConnectDataProviderAdapter.cs
                              (copy from templates/OATIConnectDataProviderAdapter.cs.sample
                               OR templates/OATIConnectHttpDataProviderAdapter.cs.sample)
```

## Admin vs Standard role assignment

OATIConnect's UI shows different tabs based on role, and the same role
gates write endpoints on the server (App Settings, Meeting Preferences,
Exchange config). To keep server and client perfectly in sync, the
adapter probes webVision's authoritative permissions record — the same
source the React UI uses in the browser:

```csharp
private static string MapRole()
{
    OATIUserPermissions permissions = UserManagerRepository.RetrieveUserPermissions();
    return permissions != null && permissions.IsAdmin ? "Admin" : "Standard";
}
```

The browser side calls the JavaScript twin of the same record:

```js
Wv.OATIUser.getUserPermissions().IsAdmin
```

Both sides resolve to the same boolean, so the React UI and the server
controllers can never disagree about who's an admin. There's no separate
privilege key to wire up, no security-UI configuration step, and no role
drift between the two halves of the app — `IsAdmin` is the single source
of truth.

Session initialization happens automatically on the first request after login:
`OATIMeetSessionAdapter` calls `IOATIExternalAPI.GetUser()` → reads
`UserManagerRepository.RetrieveUserPermissions().IsAdmin` → role is
decided → OATIConnect renders the right UI.

---

## Troubleshooting

- **`Could not load Microsoft.Extensions.Configuration.Abstractions v10.0.0.0`**:
  your host targets .NET 8 but a transitive package resolved to v10. Rebuild
  with `build-oaticonnect.ps1`; this distribution pins them to v8.
- **`IExternalUserProvider` not resolved**: register `OATIMeetSessionAdapter`
  *before* calling `services.AddOATIConnect()` — `AddOATIConnect` uses
  `TryAddScoped` for the default, so your adapter wins.
- **`IOATIConnectDataProvider` not resolved**: same pattern — register your
  adapter (EF or HTTP variant) *before* `services.AddOATIConnect()`. There
  is no built-in default; the DLL throws at first DB-touching call without
  this registration.
- **`{"IsSuccess":false,"ErrorCode":"FORBIDDEN","ErrorMessage":"Admin only"}`
  when saving App Settings / Meeting Preferences / Exchange config**: your
  `OATIMeetSessionAdapter.MapRole()` is returning `"Standard"`, but the
  React UI thinks the user is admin (because
  `Wv.OATIUser.getUserPermissions().IsAdmin === true` in the browser).
  Make the adapter use the server-side twin of the same probe:
  ```csharp
  private static string MapRole()
  {
      OATIUserPermissions permissions = UserManagerRepository.RetrieveUserPermissions();
      return permissions != null && permissions.IsAdmin ? "Admin" : "Standard";
  }
  ```
  Either copy `templates/OATIMeetSessionAdapter.cs.sample` from this drop
  over your existing adapter, or paste this snippet into the existing
  `MapRole()`. Then rebuild the host app DLL and redeploy. After that
  server and client both read `IsAdmin` from the same `OATIUserPermissions`
  record, so they can't disagree about role.
- **401 on `/api/v1/*` endpoints**: your host's authentication middleware
  isn't running before `app.UseAuthorization()`, or the OATI framework auth
  pipeline isn't active. OATIConnect's controllers carry `[Authorize]` —
  they rely on the same authentication scheme your host already uses.
'@
$IntegrateMd | Set-Content "$Dist\INTEGRATE.md"

Section "Done"
Write-Host "Drop folder: $Dist" -ForegroundColor Green
Write-Host ""
Write-Host "Contents:" -ForegroundColor Gray
Get-ChildItem $Dist -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($Dist.Length + 1)
    $sz  = if ($_.Length -ge 1KB) { "{0:N0} KB" -f ($_.Length / 1KB) } else { "$($_.Length) B" }
    Write-Host ("  {0,-50} {1,10}" -f $rel, $sz) -ForegroundColor Gray
}
