@echo off
cd /d I:\Jitsi\OATIMeetAI
claude --resume 29ebcfe5-be4f-4691-822f-953e11690730
pause
