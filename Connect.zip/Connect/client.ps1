# ============================================
# Client Build Script - OATIMeetAI Frontend
# Builds the Vite app and copies the output to ./publish/wwwroot
# so the client can be published independently of the backend.
# ============================================

$ErrorActionPreference = "Stop"

$ClientPath  = "./server/OATIConnect.API/Client"
$WwwrootPath = "./server/OATIConnect.API/wwwroot"
$PublishDir  = "./publish"
$PublishWwwroot = Join-Path $PublishDir "wwwroot"

try {
    Write-Host "Building Frontend..." -ForegroundColor Cyan

    if (-not (Test-Path $ClientPath)) {
        throw "Client directory not found at $ClientPath"
    }

    Push-Location $ClientPath
    try {
        # Install dependencies
        Write-Host "Installing dependencies..." -ForegroundColor Yellow
        pnpm install
        if ($LASTEXITCODE -ne 0) { throw "pnpm install failed with exit code $LASTEXITCODE" }

        # Build
        Write-Host "Building React (Vite) app..." -ForegroundColor Yellow
        pnpm build
        if ($LASTEXITCODE -ne 0) { throw "pnpm build failed with exit code $LASTEXITCODE" }
    }
    finally {
        Pop-Location
    }

    # Verify Vite output
    if (-not (Test-Path $WwwrootPath)) {
        throw "Build output not found at $WwwrootPath. Vite build may have failed silently."
    }

    $fileCount = (Get-ChildItem $WwwrootPath -Recurse -File).Count
    Write-Host "`nVite build succeeded: $fileCount files in $WwwrootPath" -ForegroundColor Green

    # ------------------------------------------
    # Copy build output -> ./publish/wwwroot
    # ------------------------------------------
    Write-Host "`nCopying client build to $PublishWwwroot..." -ForegroundColor Yellow

    if (-not (Test-Path $PublishDir)) {
        New-Item -ItemType Directory -Path $PublishDir | Out-Null
    }

    if (Test-Path $PublishWwwroot) {
        Remove-Item $PublishWwwroot -Recurse -Force
    }

    Copy-Item -Path $WwwrootPath -Destination $PublishWwwroot -Recurse -Force

    $publishedCount = (Get-ChildItem $PublishWwwroot -Recurse -File).Count
    Write-Host "Copied $publishedCount files to $PublishWwwroot" -ForegroundColor Green

    Write-Host "`nClient publish complete." -ForegroundColor Green
    Write-Host "  Source : $WwwrootPath"
    Write-Host "  Target : $(Resolve-Path $PublishWwwroot)"
}
catch {
    Write-Host "`nClient build FAILED: $_" -ForegroundColor Red
    exit 1
}
