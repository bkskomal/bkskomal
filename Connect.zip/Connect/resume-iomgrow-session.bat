@echo off
cd /d I:\Apps\iOmGrow\iOmGrow
claude --resume 59aaf6e2-5221-44eb-a90f-dd0ecb426878
pause
