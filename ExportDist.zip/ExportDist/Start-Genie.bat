@echo off
rem ---------------------------------------------------------------------------
rem  Start-Genie.bat - opens index.html, the multi-product Genie hub
rem  (8 dashboards in one shell), on http://localhost:8890/index.html
rem
rem  Serving over http (rather than opening the file directly) matters:
rem    * Chrome REMEMBERS the microphone Allow on localhost - a file:// page
rem      re-asks on every load, so Genie listening never sticks.
rem    * serve_genie.py sends no-cache headers, so a rebuilt dashboard is the
rem      one you see instead of a stale copy from the browser cache.
rem
rem  If the server is already running (started by this or Start-GenieShell.bat)
rem  this only opens the tab. ASCII only - PowerShell/cmd read .bat as cp1252.
rem ---------------------------------------------------------------------------
cd /d "%~dp0"
set "URL=http://localhost:8890/index.html"
set "PY=C:\Users\bkkom\.venv\Scripts\python.exe"

netstat -ano | findstr /R /C:":8890 .*LISTENING" >nul 2>&1
if %errorlevel%==0 (
  echo Genie server already running on 8890 - opening %URL%
  start "" "%URL%"
  exit /b 0
)

echo Starting the Genie server on 8890 ...
start "" "%URL%"
if exist "%PY%" (
  "%PY%" serve_genie.py 8890
) else (
  rem no venv on this machine: fall back to whatever Python is on PATH
  py serve_genie.py 8890 || python serve_genie.py 8890
)
