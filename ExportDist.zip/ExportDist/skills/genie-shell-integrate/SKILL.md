---
name: genie-shell-integrate
description: Convert a raw single-file dashboard/application into a Genie webVision Shell product — inject the shell layer from GenieApplicationShell.html, strip the product's own chrome, register its views through the WV API, and verify end-to-end. Use when asked to "apply the Genie shell", "integrate a dashboard with the shell", or convert any standalone HTML dashboard under the webVision framework.
---

# Genie Shell — Integrate a Dashboard

Converts a raw single-file HTML dashboard into a **shell-integrated product**: one file,
shell chrome (header, nav, palette, tabs, alarms, Genie, theming, i18n, workspaces)
owned by the framework, product content untouched in behavior.

## Canonical sources (read these first, in this order)

1. `E:\AI\Self\Genie\WV-INTEGRATION-SPEC.md` — THE contract: namespacing (§2), the WV
   product API (§3), the seven conversion rules (§4), embed protocol (§5), **sentinel &
   versioning contract (§7)**.
2. `E:\AI\Self\Genie\WV-PRODUCT-REGISTRY.md` — binding product ids/names/accents and
   view-id conventions; the singleton-mount rule.
3. `E:\AI\Self\Genie\GenieApplicationShell.html` — the living framework. Its nine
   `WV-SHELL:BEGIN/END` chunks are the shell layer; its `WV-PRODUCT:BEGIN registration`
   block is the living example a product registration replaces.
4. Worked examples: `E:\AI\Self\WVShellV1\dashboards\*_v1.html` (five prior conversions,
   older shell — structure reference only, do NOT copy their shell bytes).

## Procedure

### 1 · Analyze the raw dashboard (read it thoroughly)

Produce a short conversion map before writing anything:
- **Chrome to remove**: topbar/header, nav/tabs/mode bar, theme toggle, clock, its own
  settings modals, toast containers. Keep product-semantic toolbars (site/filter bars).
  A product's own AI-read/insights strip is chrome too: hide it, stop its rotation
  timer, and bridge its reads into the SHELL band's pager via
  `WV.genieRead.set({product, reads:[…]})` — one Genie's Read surface per product,
  never two (decode HTML entities; the band honors `<b>` only). Reads that belong to ONE
  display go through the same call with a **`view` key** (framework ≥ 1.9.0):
  `WV.genieRead.set({product, view:"<id>.<slug>", reads:[…]})` — the band's Global / Local (label; value `view`)
  toggle shows them for the focused tab and inside that view's popout (`.loading(product, view)`
  / `.clear(product, view)` likewise). Product-level reads without `view` behave as before.
  **The first two GLOBAL reads feed the sign-in briefing (framework ≥ 1.9.4)** — the genie reads
  their `headline`s aloud right after the greeting (HTML stripped, source language kept, Announce
  caps ~140 chars): keep headlines speakable plain sentences (no code, no bare numbers/units
  without a noun, the point first), and put the read that should be heard first at index 0.
  `WV.embedURLFor(viewId, inst)` is the framework's popout-URL rule — a hub layer that
  overrides `embedURL` delegates `v.shell===true` / `wv:settings` views to it.
- **Views**: each top-level page/mode/tab of the product = one catalog view
  (`<productId>.<slug>`). Note each view's mount recipe (the internal call that shows it).
- **Theme mechanism**: what the product toggles (body class? data attr?) and its
  rebuild entry point — that becomes the `onTheme` bridge.
- **Hazards**: document-level hotkeys, long-running timers, generic localStorage keys,
  embedded user-guide pages, `body`/`html` state classes, z-indexes ≥ 100000.
- **Registry entry**: reuse the product's binding id if it exists; else draft
  id/name/suffix/accent (read the accent from the product's own CSS tokens) + systems.

### 2 · Assemble the converted file — BY SCRIPT, never by retyping

Write a Python assembly script (in the scratchpad) that builds the output from parts:

```
product <title> + meta            (product-owned head)
wv-shell-version meta             (copied from framework — never invent a version)
wv-app-id meta                    (<meta name="wv-app-id" content="<productId>"> — the
                                   file's storage namespace; REQUIRED since 1.4.1)
WV-SHELL chunks 1–9               (extracted verbatim by sentinel from the framework,
                                   sentinel lines included)
product CSS                       (its <style> blocks, adjusted per §4)
parked product root               (<div id="wv-park" hidden><div id="<id>-root">…)
product JS                        (its scripts, adjusted per §4)
WV-PRODUCT registration block     (new — replaces the framework's sample block,
                                   keeps the WV-PRODUCT sentinels)
```

Extraction regex per chunk: everything from `<!-- WV-SHELL:BEGIN <name> -->` through
`<!-- WV-SHELL:END <name> -->` inclusive. Assemble in framework order. The framework's
sample-product block is NOT copied.

Apply the spec-§4 conversion rules as targeted edits to the product parts:
1. Remove listed chrome markup + its CSS + its JS wiring.
2. Re-root `body`/`html` state classes to the product root element.
3. Theme bridge: product stops toggling theme itself; `onTheme(theme)` calls its rebuild
   path; product light/dark selectors re-keyed to the root's `data-theme`.
4. Scope document-level hotkeys: run only when the target is inside the product root and
   `WV.uiBusy()` is false; never capture Ctrl+K / Ctrl+B / Ctrl+, / Esc / Alt+digits.
5. Gate long timers via `onVisibility`/`unmount` where cheap; else document.
6. Prefix generic localStorage keys with the product id.
7. **Change no product behavior beyond the above.**

Sizing trap: product layout heights keyed to `100vh` or to its own (now removed) topbar
— sticky side rails, per-mode `calc(100vh - …)` chart heights — silently clip inside the
shell, because the product now lives in a panel scroller under shell chrome. Re-derive
them from the panel scroll container (measure the nearest `overflow-y:auto` ancestor's
clientHeight in the product's chrome-sync path), and zero any `--topbar-h`-style fallback
whose element no longer exists.

**The no-scroll contract** (for fill-the-viewport console designs — most Genie
dashboards): the product must fit its panel with ZERO page scroll, in normal view and
Full View, exactly as it fits the window standalone; scroll appears only past the
design's readability floors. The product usually already has the fit engine
(shrink-to-fit loops, bottom-alignment, `calc(100vh…)` fallbacks) — re-aim it at the
panel instead of the window:
- One helper returns the fit frontier: the panel scroller's CONTENT bottom edge
  (`rect.bottom` minus the panel's own `padding-bottom`; window bottom standalone).
  Every JS overflow/avail measurement uses it.
- Set a `--<id>-vh` token from it (zoom-corrected) in the product's chrome-sync path
  and swap `100vh` → `var(--<id>-vh,100vh)` in the per-mode LAYOUT fallback calcs only
  (overlays/popovers keep true 100vh).
- Sticky column budgets subtract the column's own starting offset inside the panel and
  the panel padding — else the column overshoots the panel bottom by that offset.
- The shell's chrome rows legitimately cost a fixed-content rail ~50–150px vs
  standalone. Before falling back to scroll, add GRADUATED DENSIFY tiers keyed to the
  deficit measured at the native rhythm (state cleared before measuring, each layout
  sync, so it cannot oscillate): tier 1 trims paddings/gaps a notch (~half the range);
  tier 2 trims one more notch AND compresses any large decorative block (gauge/dial)
  proportionally via `zoom` — crisp, layout-real, fonts never touched. Only past the
  last tier does the scroll floor appear.
- `overflow:hidden` fixed-fit lists get inner scroll (thin themed scrollbar) as the
  LAST-RESORT floor, not the primary behavior — after the densify tier is exhausted.
- When a product's top toolbar governs only the main column, scope it INTO that
  column (move it inside the main grid cell) — a side rail then starts at the panel
  top and gains the toolbar's height for free.
- FILL BEFORE COMPRESSING: give the rail a definite column height (the measured
  budget) and flex-fill card → list inside it, so the card always ends one gap above
  the panel bottom. Watch for a shrink-lock: product bottom-ALIGNMENT logic that
  chases an element's natural height will follow a densified card downward and strand
  the recovered space — a definite flex height breaks the loop, and the main column's
  aligned chart then lands on the same bottom line (raw parity).
Verify: panel `scrollHeight − clientHeight === 0` in every primary mode at a desktop
viewport, normal + Full View; floors engage gracefully at short windows.

### 3 · Write the registration block

**Required: the shell-prefs bridge.** Shell Display + Regional settings must reflect in
product content, not just chrome. In the registration block, listen for the `wv:prefs`
document event (and apply once at first mount) with an `applyShellPrefs(p)` that:
- **UI scale / font size**: sets `zoom` on the product root to `p.scale * p.fontScale`
  (product content is px-locked, so the two combine there — document this), then runs
  the product's resize/chrome-sync path so charts and sticky rails re-measure.
- **Density**: sets `data-wv-density` on the product root; a small CSS block maps
  `comfortable` onto the product's own spacing vars (e.g. bump `--gap`, card padding);
  `compact` = the product's native look.
- **Reduce motion**: sets `data-wv-motion` on the product root; CSS under
  `[data-wv-motion="reduced"]` disables product animations/transitions.
- **Regional formats**: route the product's central date/time stamp helpers through
  `WV.fmt.date/time/tz` (timezone, date pattern, 12/24-hour all follow), route a central
  number formatter through `WV.fmt.number` if the product has one (domain-styled figures
  with fixed units stay as designed — document what follows and what doesn't), and
  trigger the product's cheap re-render so visible stamps update live.
- **Appearance (Background + pinned Accent)**: read the shell's computed `--wv-bg0`
  and set it on the product's ground token (`--background` or equivalent — at the
  product root if its theme layer is root-scoped, at `documentElement` if it was
  re-keyed to `html[data-theme]`); when `html[data-accent]` is present (operator
  PINNED an accent) copy computed `--wv-acc` onto the product's accent token
  (usually `--ring` per the genie-ui standard), removing it in auto mode so the
  product keeps its native hue. Guard with a change-signature and re-run the
  product's theme rebuild only when the look actually changed (charts re-read tokens).
Verify each: change the setting, assert the product content changed, zero errors.

**Required: the single-info-mode merge.** One ⓘ for the whole page — the shell's:
- Add `data-wv-product-root` to the product root element (the shell's info click-capture
  passes clicks inside it through to the product's own info system).
- Hide the product's own info toggle (`display:none!important`), wiring intact.
- Listen for the `wv:info` document event (`detail.on`) and drive the product's own
  info-mode setter with it; read `body[data-infomode]` once at mount for initial state.

**Required: the single-alarm-surface merge.** The shell drawer is THE alarm surface
(severity-count filter chips, Latest/Severity sort, multi-select Acknowledge, Ack all —
adopted from product alarm UIs at merge time). Bridge the product's alarm engine into
it: raise each derived/detected alarm once via `WV.raiseAlarm(sev, msg, source, viewId)`
with a product-keyed dedup set (product severity vocab maps onto the shell's —
`warn→maj`); a re-derive that changes an alarm's identity key is new state and raises
again. Hide the product's own bell/popover (`display:none!important`), keep its
derivation ticking. Never leave a second alarm surface alive.

**Required: the single-health-surface merge.** The shell health chip + "System health"
popover (chip SYSTEM when nominal, N/M-nominal chip, ✓ OK rows, DEGRADED/STALE pills)
is THE health surface. Register the product's REAL service list as `systems` in
`WV.registerProduct`, drive states from the product's own health truth via
`WV.setSystemState` (typical map: ok→live, degraded→degraded, down→stale) hooked into
its health render path, and hide the product's own health button/popover.

**Required: the single-shortcuts + single-help merge.** The shell's shortcuts sheet
(header kbd icon, hideable via Header icons) and help menu are THE surfaces. Contribute
the product's keys via `WV.registerShortcuts(groups, productId)` — dropping rows whose
surfaces moved to the shell (its own alarm/theme/sheet keys) — and register the
product's User Guide view id as `guide` in `WV.registerProduct` so the help menu's
"User guide" entry opens it. Hide the product's own shortcuts/help buttons and sheet.

**Product-local mode/view switchers**: normally retired (shell nav supersedes), but
they MAY stay by user preference — if kept, reroute them THROUGH the shell (capture-
phase intercept → `openView(<catalog view>)`, letting the mount recipe drive the
product's internal switch) so tab/view/workspace state never drifts; custom entries
and `#wv-embed` boots fall through natively. If a kept surface owns a MODAL, add a
capture-phase Esc bridge that closes it first and stops the event — hotkey scoping
reserves Esc for the shell, which otherwise strands the modal with no Esc path.

**The commons principle** (governs all the Required steps): capabilities every product
needs — alarms, info mode, Genie's Read, notifications, theming, prefs, i18n, health —
live ONCE in the shell; the product supplies only its domain data/logic through the WV
seams and retires its own duplicate chrome. When a product's duplicate surface has a
feature the shell lacks, the feature moves INTO the shell (framework release + update
round), never the other way.

**Required: product i18n.** The shell's translation engine walks the whole document,
so product UI strings translate once registered: build a `<ID>_I18N` map of the
product's UI labels (titles, headings, buttons, table headers, tooltips, empty states)
with fr-CA/es-MX/ar/ja values and call `WV.i18n.register(map)` in the registration
block. NEVER register numbers/units, site/zone/resource names, domain acronyms
(DA/RT/SOC/LMP/…), or dynamic data values — unregistered text is naturally untouched.
Mark genuine collisions (data readouts whose text equals a key) `data-wv-i18n-off`.
Canvas-drawn chart internals are out of scope — document it. Test Arabic: if the dense
layout breaks under the RTL cascade, pin `direction:ltr` on the product root and
document the choice. Verify: translated labels, untouched data, re-render survival
(the observer re-applies), lossless return to en-US.

Follow the framework's sample block as the template: `WV.registerProduct` (id, name,
suffix, accent, systems) → `WV.registerViews` (catalog per the registry conventions) →
`WV.registerRenderer` per view or `"*"` (singleton pattern: mount moves the parked root
into the panel and drives the product's internal nav; implement `unmount`, `onTheme`,
`onResize`, `onVisibility` honestly) → optional `WV.genieRead.set` product feed,
`WV.registerActions`, `WV.genie.desk` / `WV.genie.alert` feeds → `WV.start({product})`.
Honor the embed protocol (§5) — `#wv-embed=` boots chromeless into one view.

Contract details that bite (current framework):
- **Catalog names are plain English STRINGS** (workspaces, palette and voice resolve by exact
  name via `viewByName`) and must be speakable — the generic voice command "open ‹view›" (all
  five languages) resolves against them, and the Genie Chat's product group lists them.
  Translations come from `WV.i18n.register({"Name":[fr-CA, es-MX, ar, ja]})` in the
  registration block — an ARRAY as `name` breaks the startup workspace. Avoid code-only names.
- **Genie chat is the OATI Genie chat component (shell ≥ 1.8.0)** — `WV.genie.register(fn)`
  is a documented NO-OP (returns false; the chat brain is the OATI Genie service configured in
  `chat/genie-config.js`). Products feed **Genie's Desk** and **alerts** instead:
  `WV.genie.desk.add({id, title, channelLabel?, tone?: severe|warning|attention|info,
  timestamp?, summary?, container?: "activeRisks"|"monitoring", actions?:[{label, run}]})` /
  `remove(id)` / `clear()` / `set(items)` / `push()`; `WV.genie.alert({id, headline,
  description, severity: elevated|high|severe (shell/Desk tones are mapped), channelLabel?,
  canAcknowledge?, actions?:[{label, run}]})` / `dismissAlert(id)`; `WV.genie.open("desk")`.
  The shell already turns every unacknowledged alarm into an Active risk and every
  degraded/stale dependent system into a Monitoring item — do not duplicate those.
- **The converted file must sit where `chat/` is reachable** — the shell loads
  `chat/genie-config.js` → `chat/genie-rag-shim.js` → `chat/oati-genie-chat-widget.js`
  relative to the HOST file (http and file://). A file under `dashboards\` therefore needs
  `dashboards\chat\` (copy or junction of `E:\AI\Self\Genie\chat`) or a
  `WV_GENIE_CONFIG.bundle` / `WV_GENIE_LOADER` path override. If the component is missing the
  lamp shows a toast and nothing else breaks — that is a verification FAILURE for a delivered
  integration, not an acceptable state.
- **Self-contained**: vendor every chart/map library inline — the framework itself carries NO
  chart library; copy ECharts 5.5.0 from an already-converted file (ftm/ev) and Leaflet 1.9.4 from btm or bafc (NOT dlr-genie-map — that product is a static SVG snapshot with no Leaflet).
  btm/dlr rather than downloading again; drop Google Fonts (the shell embeds IBM Plex Sans + a
  mono face). A converted file makes zero external library/font requests (runtime basemap tiles
  are product behaviour — document them).
- **Framework boots EMPTY** — the product's own `startupWs` (below) is what lands the
  operator on a view; never rely on the framework's sample workspace.
- **Info mode content (`WV.info`, shell ≥ 1.7.6)**: the shell ⓘ has two presentations —
  floating card (click) and docked panel (hover fills, click pins; the page makes room via
  `body[data-wv-infodock]`). Give product regions rich sections with
  `WV.info.describe(key, {title, kind?, plain, what, why, how, read, healthy, concerning,
  health?, wrong, terms:[[term,def],…]|html, related})` / `describeMany({...})` /
  `resolve((key, el) => entry|null)` for live values — `key` is a CSS selector (matched up the
  ancestor chain; beats the element's own `data-info`) or a token carried in `data-info-key`
  (a product's raw `data-info="kpi:soc"` value also resolves). Values are trusted HTML. Plain
  `data-info="Title|What|How to use|Calc|Healthy vs abnormal|Depends on"` still works in both
  presentations (dock mapping 1→IN PLAIN TERMS, 2→HOW TO READ IT, 3→HOW IT IS CALCULATED,
  4→HEALTHY VS CONCERNING on the "Healthy: … Abnormal: …" convention, 5→RELATED). A product
  with its own explainer registry bridges it in the registration block and hides its own
  floating pop under `body[data-wv-infodock]` so one explainer answers at a time.

**Required: the login-default workspace.** A fresh login lands on the product's
default/primary view, never the empty launchpad: pass an inline startup workspace to
`WV.start({product, startupWs:{id,name,product,layout:"tabs",views:[<primary>]}})`.
Verify with a fresh browser profile (no stored session): after login, `S.open`
contains the default view, mounted and active. The resume-session pref correctly
overrides on later logins — verify the fresh case.

### 4 · Verify — the acceptance bar is functionality preservation

Playwright (`channel="chrome"`, venv `C:/Users/bkkom/.venv/Scripts/python.exe`,
`PYTHONIOENCODING=utf-8`), serving over `http://localhost` (mic/permissions parity):
- Boot → login (Enter on prefilled) → app shell present, **zero page errors and zero
  console errors** (strict: collect `pageerror` + `console.error` for the whole run;
  only Chrome's own `/favicon.ico` probe is tolerated, by exact text).
- Every registered view opens and renders its real content (assert a content marker per
  view, not just no-crash). Views behave as they did standalone.
- Theme round-trip (dark→light→dark) — product canvases/charts rebuilt.
- One popout/embed check: `#wv-embed=<view>` boots chromeless and posts `wv:ready`.
- Screenshots per view for the record.
Fix at the root cause and re-run until fully green. Report the suite tally.

### 5 · Register the product in the hub

`E:\AI\Self\Genie\index.html (the hub; renamed from GenieAllDashboards.html 2026-08-31)` is the multi-product hub (one shell
instance whose catalog spans every converted dashboard, each view an iframe of the
product file via `#wv-embed=`). Its hub layer (`<style id="wv-hub-css">` +
`<script id="wv-hub-js">`, outside the sentinel chunks) holds the product → file → view
map. Add the new product there (identity values copied from the product's own
`WV.registerProduct`, full view catalog with the same ids/i18n names, relative
`dashboards/<file>` path) and verify in the hub: switch to the product, open its views,
`{wv:"ready"}` received, theme/time pushed, its alarms bubble with the product-prefixed
source. Then add the file to the propagation set (`tools\splice_shell.py` target list
and the table in `genie-shell-update`).

**Hub-level views (`shell:true`, framework ≥ 1.8.10).** A view the HUB renders itself — no product
file, no iframe, no runtime component (the "Genie UI" folder: Nightly Reports (id `hub.report`) + the framework's
Settings) — is a catalog entry with `shell:true`: `isFrameworkView` accepts the flag, so
`visibleCatalog()` lists it under EVERY product (palette, launchpad, favorites, voice "open ‹name›").
Recipe, all in the hub layer (never inside a WV-SHELL chunk):
- `WV.registerViews([{id:"hub.<slug>", name, product:PRODUCTS[0].id, path:["Genie UI"], type, openMode:"inline", …}])`
  then `view(id).shell=true` — `registerViews` copies only the spec'd fields, so the hub stamps
  the flag on the catalog entry itself. Register a SPECIFIC renderer (`WV.registerRenderer(id, {mount,
  unmount, onResize, onTheme, onVisibility})`) that builds DOM into the panel body — the hub's `"*"`
  iframe renderer loses to an exact id (`rendererFor`).
- Keep the hub's frame machinery away from it: `isHubView` must return false for `v.shell===true`
  (so `hubExclusive` never tears it down on a product switch and the time bus does not subscribe it)
  and `frameURL` must never build an embed URL for it.
- Move the framework's Settings view into the same folder AFTER `WV.start` (it is registered inside
  start): `view("wv:settings").path=["Genie UI"]; .shell=true`; add the folder to `S.treeOpen`.
- Commons principle still governs: the view's own AI-read strip → the shell band via the hub's
  `feedHubRead` (one read surface), its critical findings → `WV.raiseAlarm` with a stable dedup key
  (`report:<id>`) and a folder-prefixed source (`"Genie UI · Nightly Reports"` — the hub's
  "‹Product› · ‹source›" convention) so drawer + Genie's Desk get them once, Info mode via
  `WV.info.describeMany` + `data-info` facets, labels via `WV.i18n.register` (data never), tokens
  only, density from the shell pref, sign-in hooks by wrapping `enterApp` BEFORE `WV.start` (a
  resumed session calls it from inside start).
- Framework gap to know (1.8.10–1.8.12): the sidebar Browse tree, the horizontal menu bar and its
  mega menus are built from `productCatalog()`, not `visibleCatalog()` — a shell-level view lists
  only under its registering product. The hub wraps `renderSidebar` / `renderHnav` / `openMega` to
  append the folder under the other products until the framework switches those three (then drop
  the wrappers). Verify the folder under at least two products and that the view SURVIVES a switch.
- Popouts: the shell's `popOut()` calls `embedURL()`; the hub's override must return the HUB's own file for a
  `shell:true` view (no product file knows it) — delegate to `WV.embedURLFor(viewId,inst)` when present (else the
  framework's `embedURL` captured before the override) and only swap the file before the `#` for product views, so
  the framework's query (`&band=1` from 1.9.0 …) survives. Skip such popouts in the hub's child→parent relay (no
  frame record, no product-accent re-brief). The view's own AI read inside a row detail reuses the shell band's
  `#wv-gread` markup/classes (`.wv-gr-*`) so it reads as the same component — never a second read line in the header.

**Not integrating yet?** A raw dashboard can still be merged into the hub as a RAW product: add
its file to `FILES`, its id to `ORDER` and `RAW`, a `registerProduct` (single `<id>-page` system)
and ONE view (`<id>.<slug>`) in the hub layer. The hub loads the page as-is (no `#wv-embed`),
lifts the veil on the frame's load event and skips theme/time/info/alarm relay. When the file is
later converted, remove the id from `RAW` and register its real catalog — nothing else changes.

### 6 · Record

- Stamp = framework's version (came with the chunks; verify it survived).
- Append/refresh the product's section in `WV-PRODUCT-REGISTRY.md` (id table row if new,
  the actual view catalog derived in step 1).
- Note the integration (file, version, suite tally) in `WV-PRODUCT-UPDATES.md`.

## Rules that override convenience

- Shell bytes come ONLY from the current framework file, extracted by sentinel —
  never from a previously converted product, never retyped.
- Sentinel lines are byte-exact; never edit, translate, or re-indent them.
- Product functionality is sacred: when a conversion rule and product behavior conflict,
  stop and surface the conflict instead of silently degrading the product.
- Write patch/assembly scripts to files before running (heredoc backslash collapse
  corrupts `\b`-class escapes invisibly).
- The skills themselves are versioned with the project: after changing any `genie-*`
  skill, mirror it to `E:\AI\Self\Genie\skills\` (see README there).

## Global-collision sweep (MANDATORY, learned on bafc 2026-08-31)

Before wiring the product layer, grep the raw file for top-level declarations that shadow shell globals —
at minimum: `toast`, `renderAll`, `renderAlarms`, `renderGenieRead`, `view`, `herald`, `spark`, `S`, `EMB`, `WV`.
A raw `function toast(...)` silently replaces the shell's and every shell toast breaks. Rename collisions with the
product prefix (`bafcToast` …) throughout the product layer. Known latent debt: btm (`toast`) and pf (`toast`,
`renderAlarms`) were converted before this rule and still shadow — fix on their next touch.

## Genie's Read must fill BOTH scopes (MANDATORY, CEO ruling 2026-08-31)

The band has two scopes: **Global** (the product's reads) and **Local** (the reads filed for the
display currently open). A product that files only Global reads leaves Local showing the honest
empty state on every one of its views — which reads as unfinished. So:

- File the product-level reads with `WV.genieRead.set({product, reads:[…]})` **and**
- file **exactly 2 view-scoped reads for EVERY registered view** with
  `WV.genieRead.set({product, view:"<view id>", silent:true, reads:[…2…]})`.

Rules for the two Local reads, learned across the 2026-08-31 round (40 views, 8 products):

1. **Computed from the state that view renders** — its series, its selection, its filters, its hour —
   never hardcoded prose. If the view's numbers move, the reads refile on the same events the Global
   read already refiles on (`wv:time`, selector/filter change, a new solve/run). Add the refile call
   next to the Global one so the pair stays visible to the next maintainer.
2. **Two different jobs**: one "state of this view right now", one "the thing worth acting on here".
3. **Every read carries a real action** — a `cta` or an `insights[].act` whose `run()` does something
   in that view (scroll+ring the panel, scrub the hour, open the drill-down, select the row). Dead
   links are a defect; execute every handler in your verification pass.
4. **Honest when quiet**: "no constraint binds in this window" beats invented drama. For a snapshot
   product with no live telemetry, derive from what the snapshot does contain and say so; for a
   documentation view, describe what the document is generated from.
5. Tone (`info`/`watch`/`crit`) comes from the real value against the product's own threshold, not
   from a wish to look eventful.
6. **A `kind` chip where it helps** (framework 1.10.15): a short category label (≤ 18 chars) shown before
   the headline — CHARGE, MARKET, AT LIMIT, WATCH, ACCURACY, REPORTING, RUN HEALTH, FORECAST, SPAN WIND.
   It is product wording and is never translated. It must name what the read IS at file time: if the
   dispatch maths says discharge, the chip says DISCHARGE — stamping the template's CHARGE on it is a lie
   the chart will contradict.

Each view block gets its own `try/catch` so one bad view cannot starve the rest.

Verification (add to the product's deep suite): open every view in the hub, assert
`(GREAD.views['<id>'].reads||[]).length === 2`, headlines non-empty and distinct, and that
`setGreadScope('view')` renders that view's read instead of `.wv-gr-empty`.

## Supplied read tables are TEMPLATES, NOT COPY (MANDATORY, CEO ruling 2026-09-01)

The CEO supplies Genie's Read content as tables: a **kind chip**, a **one-line read**, and **figures**
("Charge 1.60 MW through HE 15:00 — high PV surplus is the binding driver. | Confidence: 92% · SOC: 14.3 MWh").
Adopt the SENTENCE PATTERN, the CHIP and the FIGURE LIST verbatim. Every VALUE in them is a **formula**
against the product's live state, evaluated at file time and refiled on the events that product already
refiles on. Never paste a sample number.

Why this is not negotiable: a hardcoded "1.60 MW" sits in the band while the chart underneath says
something else, and the first hour-scrub in a demo destroys trust in every read the system has ever
filed. One fake number is worse than an empty band.

Consequences to plan for:

- **Code both branches of every sentence.** The sample is one state of the world. "3 lines are critical"
  needs its true-zero branch; "wind is nearly PARALLEL" needs its crossing-wind branch; a tracking claim
  needs its honest negative ("2 of 7 intervals landed outside P10–P90"). A snapshot product will often
  render the quiet branch — that is correct, and demo staff should be told which branch they are seeing
  and what live data would make it read like the table.
- **Reuse the product's own maths.** If the product already computes the score, ranking or threshold the
  table describes, expose its seam (e.g. `window.<prod>Shell.attention`) and read it. Re-deriving the
  number beside the product's own is how the band and the panel end up disagreeing.
- **Where the state genuinely cannot produce a figure**, use the nearest honest equivalent and SAY SO in
  the read's own summary (not only in the report) — e.g. per-line critical hours absent, so the thinnest
  SLR margin stands in as the second urgency axis.
- **Distribute by subject, not by count.** A table's reads go to the view whose content each one describes;
  a multi-view product spreads them, a single-view product carries its whole list worst-first (crit >
  watch > info). The "exactly 2" Local rule then reads as a FLOOR of 2 and a ceiling of about 5 per view:
  never empty, never a wall of paging. Keep an existing read only where it still earns its place.
- **Prove liveness, not just presence.** The verification pass must change the driving state (scrub the
  hour, switch the site/resource/feeder/line) and quote at least two reads' figures before and after.
  A read that never moves is indistinguishable from hardcoded prose.
- **Do not invent content in this format for products the CEO has not supplied a table for.** They keep
  their current reads until he does.

The framework does the same for its own views: `shellFeedViewReads()` (1.10.8) files two computed
reads for Settings (which preferences differ from `PREF_DEFAULTS`; the genie's voice/briefing state).

## A product's main-thread cost is the HOST'S cost (MANDATORY — learned on derms, 2026-09-01)

A same-origin embed runs on the HOST'S main thread. Whatever a converted dashboard spends, the hub
spends: its timers, its speech, its animations, and every Playwright locator in your own suite.

Three things this cost us, all measured:

- **A hung suite is not always a bad selector.** derms' smoke run hung on `pg.hover("#wv-clock")` with
  the element visible and stable. The cause was a main thread ~90% busy: `computeActions()`, a PURE
  derivation, was recomputed 8+ times per repaint at ~200 ms each, so one `commit()` cost **1764 ms**
  against a 2000 ms tick, and Playwright's rAF-polled actionability starved. `page.evaluate` and raw
  `mouse.move` still worked — that asymmetry is the tell. Memoising per state generation took it to
  392 ms. **If a locator hangs while evaluate works, measure the thread before you touch the test.**
- **Nothing may repaint while nobody is looking at it.** Every opened derms view kept a console
  repainting every 2 s, and hub view-swap latency degraded **4.8 s → 151 s** as views accumulated. Gate
  every tick on visibility (the root having a client box is enough) — a hidden view costs zero.
- **The user HEARS this.** Framework 1.10.16 traced a stuttering genie to exactly this: the landing
  dashboard's boot lands a ~2.0 s long task on the host thread, delaying both the shell's step timer
  and `speechSynthesis`' own start. No scheduling trick in the shell can create audio time while a
  product owns the thread.

So, during conversion: memoise pure derivations behind the product's own state counter; gate repaint
loops on visibility; keep any single boot task under ~50 ms (chunk it if it is not); and profile with
a `longtask` PerformanceObserver in the HOST, not the frame, because that is where the damage lands.
Check this on the UNTOUCHED RAW too — derms' 1764 ms commit was pre-existing product behaviour, and
reporting it as such is the difference between a fix and a blame.

## The collision sweep runs in BOTH directions (MANDATORY — learned 2026-09-02)

The sweep was written for a product global shadowing a shell one. It applies to the FRAMEWORK's own
new globals just as hard. A mode registry introduced as `const MODES` collided with four converted
products that each already declare a top-level `const MODES` — and two `const` of one name in a
document is a **SyntaxError that takes the whole product layer down**, reported as "Identifier 'MODES'
has already been declared" plus every downstream product function missing. Before naming any new
framework global, grep the converted dashboards for it. Prefer a distinctive name (`MODEGRP`).

## A recurring bug lives in the SHARED HELPER, not the call sites (2026-09-02)

derms emitted intermittent `<path d="M0.00 NaN …">` console errors. Two rounds fixed two individual
CALLERS and both concluded the remainder was machine load. Measured in isolation it was **0, 28 and 308
errors across three runs** — failing two in three. The cause was `svgPath()`, the shared path builder
every chart went through: it guarded the empty case but not `maxY` arriving 0 or undefined (`0/0` ->
NaN) nor a non-finite coordinate. Guarded once in the helper: five consecutive clean runs.

Two rules from that: **when a defect is called transient twice, measure it in isolation before believing
it**; and **when a symptom returns after call-site fixes, the bug is upstream in the shared helper**.
A helper that formats output for many callers must never be able to emit an invalid value — a series
with no data should draw a flat baseline, not a broken path.

## A product's registered name must NOT carry the brand (2026-09-02)

The chrome adds "OATI" — the lockup and the tab title both do. Register the name without it
(`GridLine FTM Optimizer`, `BA Forecast & Capacity Console`, `Genie Dynamic Line Ratings`), as every
other product does. One integration registered "OATI Genie Dynamic Line Ratings" and the roster read
"OATI OATI Genie Dynamic Line Ratings". `prodBranded()` exists as a backstop, but fix the NAME: a
second de-duplication guard hides the inconsistency instead of removing it.

## A product's own segmented controls follow the house selection spec (2026-09-02)

If a converted product keeps a segmented control of its own (mode switchers, scope toggles, unit
pickers), restyle its ACTIVE state to the genie-ui segmented spec — a ring that covers the track
border, a specular top in dark, and dividers suppressed around the active button. Two controls a
few pixels apart that mark selection differently is the fastest way to make a converted product
look bolted on. The shell's own mode group and the Genie's Read Global/Local scope are the
reference implementations.

## Two writers on one attribute (MANDATORY — learned on dlr, 2026-09-02)

The shell owns `data-theme` on `documentElement`. If the RAW writes it too — many app shells do,
via their own ThemeProvider calling `setAttribute`/**`removeAttribute`** — then the shell and the
product are two writers on one attribute, and the product will strip the shell's own light layer
the moment its internal state disagrees. The symptom is precise and misleading: switching theme
leaves the product on the old theme, and a RELOAD looks correct (because the seed re-syncs at boot).

Before trusting "the product re-themes for free from `:root[data-theme=...]`", grep the raw for
`data-theme` writes. If it writes the attribute, the product's OWN theme state must be driven to
match on every change — and drive whatever it treats as authority. On dlr that was its settings
store: a `useEffect` forced the provider back to `draft.theme` on every render, so `setTheme`,
`toggleTheme` and the raw's own keyboard shortcut were all overridden.

## Never identify a product control by visible text or aria-label (2026-09-02)

If the product has i18n, every label you match on is a time bomb. On dlr the settings cog was found
by its English `aria-label`: after ONE switch to French the bridge could never find it again, so
every later preference write — theme included — silently no-opped. Match by CSS-module class, ARIA
shape (`button[aria-haspopup="dialog"]` plus a distinguishing child), or a `<select>`'s option-VALUE
signature (`dark|light`) — values are stable, labels are not. Beware count-dependent labels too:
a save button reading `"Apply 3 changes"` when dirty and a bare `"Apply"` only when DISABLED will
match your `/^apply$/` regex exactly when there is nothing to commit.

## A staged panel must be COMMITTED, and closing usually discards (2026-09-02)

If the product's settings surface stages edits behind Apply/Save, setting a control is not a write.
Click the commit control and confirm it settled (e.g. poll until it returns to disabled) BEFORE
closing — and check what close actually does: on dlr the header X, Escape and an outside click all
routed through `discard(); onClose()`. Expect a commit to re-create the routed page, so snapshot and
restore the operator's scroll position.

## Register the product's READ SENTENCES (MANDATORY — CEO ruling 2026-09-03)

The language must reach the chrome, the dashboard AND Genie's Read. A read is generated prose with
live values in it, so the band cannot look it up as a label — an untranslated read sits in English
inside an otherwise Arabic screen, which is exactly how this was reported.

Give the product one `WV.i18n.registerPatterns({…})` call covering every read sentence:

- **Key** = the English source as an **anchored regex** (`^…$` — unanchored keys are refused).
- **Value** = `[fr-CA, es-MX, ar, ja]`.
- **Capture groups are the live values.** `$n` copies the capture VERBATIM — that is how
  `Span P-3222`, `Mojave Desert 500kV`, `HE 18`, `FDR-10045`, figures and units survive translation.
  `~$n` resolves the capture as a label first, for the enumerated words a product drops into its own
  sentences ("reserve requirement", "Discharge"); pair that with `WV.i18n.register`.
- **Templates may place `$1…$9` anywhere.** Arabic and Japanese do not keep English word order, and a
  substitution that can only fill in place will produce broken sentences in both.
- **Never pattern the `kind` chip.** It is product wording by ruling and carries `data-wv-i18n-off`.

Two shapes are free and worth knowing: a read written `<b>KIND</b> — sentence` needs only the
sentence registered, and a figure row `<b>Label</b> — value` needs only `register({"Label": […]})`.

**Harvest the real strings, do not guess from the source.** Open the product and read
`GREAD.data[pid].reads` (and each view's `GREAD.views[id].reads`), because reads branch: one dispatch
read can have three verb branches times seven driver words, and a pattern that only covers the branch
you happened to see leaves the others English.

**A read crossing the frame boundary is a plain string.** In the hub a product's read arrives over
`postMessage` with no product code in that document, so only a pattern applied at RENDER time can
translate it — per-locale builders inside the product cannot reach the hub at all. `registerPatterns`
relays itself up as `{wv:"i18n-rx"}` for exactly this reason.

**The hub's own roster reads are the same job**, in the hub layer, and are easy to forget because they
are not any product's code — they were left English for a full round after the products were done.

Verify: `verify_shell.py --url <product> --only "gread-i18n|i18n"`, then switch to `ar` and read the
band — prose Arabic, identifiers and figures untouched, kind chip still product wording, and a round
trip back to `en-US` byte-identical with no reload.

## A collision RENAME needs its own verification (MANDATORY - learned on otp, 2026-09-04)

The sweep is only half the job. otp shadowed **eleven** shell globals, four of them fatal by
redeclaration (`$`, `S`, `VOICE`, `esc` - two `const` of one name is a SyntaxError that takes the
whole product layer down). Renaming them is mechanical, and that is exactly why it goes wrong
quietly.

**The spread trap.** A rename pattern that refuses to touch a property access (`obj.S`) will also
refuse `...S`, because both are preceded by a dot:

```js
Math.max(...S.paths.map(p => p.mw))   // still the SHELL's S after the rename
[...$("apSort").children]             // still the SHELL's $
```

Nothing fails at load. It surfaces later, on a code path an operator reaches -
`Cannot read properties of undefined (reading 'map')` on a re-price - which is the worst kind of
defect to hand to a demo. Mask `...` before applying a dot-aware rename, and treat `?.` and optional
chaining the same way.

**Then prove the rename, do not trust it.** After renaming, sweep AGAIN and fail the build if any
shell global is still reachable from raw product code. A build-time assertion is worth more than a
careful regex, because the regex is what you got wrong.

**And check whether a "collision" is real before renaming it.** On pf, `S` looked like a collision
and was not - the raw's `S` declarations are block-scoped inside functions, so renaming them would
have been churn against a non-problem. Measure the SCOPE, not the token count.

## Prove the helper is CALLED before you guard it (MANDATORY - learned on derms, 2026-09-03)

Three rounds went into one `<path> attribute d: Expected number, "M0.00 NaN ..."` storm. Round one
patched call sites. Round two moved the guard into the shared helper `svgPath()` - the right instinct,
and the note even said "guard once, here, for every caller". Round three (mine) added a further guard
there for the geometry.

Then a stack trace showed **`svgPath()` has no callers at all.** It sits behind
`const $legacy_unused = null;`, and the chart that actually draws is `buildChart`'s `line()`/`area()`.
Every previous fix had landed in dead code. The bug never "came back" - it had never been touched.

- **`grep -c "helperName("` before you edit.** A count of 1 means the definition and nothing else.
- A converted product is a *captured build*: it carries dead paths the original app no longer uses.
  Plausibility is not evidence that a function runs.
- **Get a stack, do not infer one.** Hook the write and read `new Error().stack`. Two of my own
  hypotheses here (maxY, then the height multiplier) were arithmetically plausible and both wrong;
  the stack was decisive in one run.
- Hook the right seam. `setAttribute` caught nothing because this product builds **HTML strings** -
  the path arrived through `innerHTML`. If your hook never fires, that is data: the value is getting
  there another way.

**And reproduce load-dependent bugs on purpose.** 308 errors in a full gate, 0 in three back-to-back
isolated runs, 42 under a deliberate 6x CPU throttle (`Emulation.setCPUThrottlingRate` via CDP). A
defect that only appears on a loaded machine is a race, not flake, and throttling turns it into a
repeatable test. It is also the honest demo risk: the CEO's laptop is not the gate's idle machine.

**What the guard must cover.** `Math.abs(undefined)` is NaN and `Math.max(anything, NaN)` is NaN, so
ONE unresolved point poisoned the scale and therefore every coordinate AND every axis label. Guard
the scale, the point formatter, and the label formatter - a shared renderer should be incapable of
emitting NaN whatever it is handed, because the alternative is an operator reading "NaN" and
concluding the product is broken.

## A popover must not PAINT before it is anchored (MANDATORY - learned on dlr, 2026-09-03)

Reported as "this alarm window just flashes and disappears" on every refresh. Measured with a flash
detector armed before the first frame: the product's alarm popover was visible for ~1.3 s at
`[8, 8, 400, 596]` - the frame's top-left corner - then gone.

The trap, and it is a general one:

> **`getBoundingClientRect()` never returns `null`.** While an element is unlaid it returns a ZERO
> rect. So `if(!anchorRect||!ownRect)return` looks like a guard and guards nothing.

The zero rect then flows into the placement clamp, and the clamp is what produces the corner:
`left = anchor.right - width` is hugely negative, so it falls back to `anchor.left` (0) and clamps
up to the viewport padding; `top = anchor.bottom + gap` clamps the same way. The result is exactly
`(padding, padding)` - a popover pinned to the corner, every time, which is why this class of bug
always looks identical.

Rules:

- **Test the rect, not its existence**: `if((!r.width&&!r.height)||!own.width)` - then retry on the
  next frame rather than committing a position.
- **Bound the retry.** In a CONVERTED product the anchor may never lay out - see below - and an
  unbounded `requestAnimationFrame` loop is an unexplained CPU burn months later. ~90 frames is
  plenty; past that the anchor is not coming and staying invisible is correct.
- **Cancel it in the effect cleanup**, alongside the resize/scroll listeners.
- Prefer components that already render unpositioned popovers off-screen at `opacity:0` - many do,
  including this one. The fix is usually to let that existing guard do its job, not to add a new one.

**A converted product's own chrome is PARKED, so its chrome-anchored popovers can be permanently
anchorless.** Here the alarm trigger measured `w:0,h:0` forever, because the shell's alarm drawer is
the alarm surface and the product's topbar is parked. The popover could only ever appear in the
window between the integration opening alarms and docking them - which is precisely the flash. When
you park a product's chrome, sweep for anything that positions itself AGAINST that chrome.

**Verify both halves.** Nothing paints in the corner during a refresh (a flash detector sampling
every frame from before the first script, not a screenshot), AND a popover that does have an anchor
still opens under it. A fix that only stops something happening is half proven.

## Parked-block balance (MANDATORY, learned on bafc 2026-08-31)

After assembly, assert the parked product block is HTML-balanced. bafc shipped one `</div>` short:
`#wv-park` (which is `hidden`) never closed, so `#<pid>-overlays` — declared after it in the source —
parsed INSIDE the park. Every fixed overlay hosted there (panel kebab menus, info card/menu, toasts)
then rendered at zero size in BOTH the hub and standalone, with no console error to point at it.

Two cheap checks that would have caught it:
1. Static: walk `<div>`/`</div>` across the parked region; the stack must be empty at `#<pid>-overlays`.
2. Runtime: `document.getElementById('<pid>-overlays').parentElement === document.body`, and after
   opening one panel menu, `getBoundingClientRect().width > 0`.

Add the runtime pair to the product's deep suite — an overlay that opens with zero size looks exactly
like a dead click handler, and that is where the debugging time goes.

## Overlays must PAINT, not merely open (MANDATORY — two regressions, 2026-08-31)

Two shipped conversions had dead-looking controls whose handlers were running perfectly:

1. **bafc** — the parked block was one `</div>` short, so `#bafc-overlays` parsed inside `#wv-park[hidden]`.
   Every overlay it hosts (panel kebab menus, info card, toasts) rendered `0x0`.
2. **conv** — `#conv-overlays{position:relative; z-index:0}` created a **stacking context**, so the dialogs'
   own `z-index:1500` was trapped inside it and `#wv-embedRoot` (later in the DOM, `position:fixed`) painted
   over them. The gear / layouts / export dialogs opened at full size, full of content, and were invisible.
   A third, related trap in the same file: `inset:auto` written AFTER `top/left/right/bottom` longhands
   cancelled them, collapsing a `position:fixed` backdrop to shrink-to-fit in a corner.

None of these produce a console error, and all three pass a "does the handler run / does the element exist /
is it display:flex" check. **Only hit-testing catches them.** So, for every converted product:

```js
// with the overlay open:
const box = dialog.getBoundingClientRect();
const hit = document.elementFromPoint(box.x + box.width/2, box.y + 24);
// PASS only if dialog.contains(hit) || hit === dialog
```

Rules that follow:
- The product's overlay host (`#<pid>-overlays`) must be a child of `<body>` at runtime and must NOT create a
  stacking context — no `z-index` other than `auto`, no `transform`/`filter`/`opacity<1`/`contain:paint` on it.
- Assert the parked block is balanced (walk `<div>`/`</div>`; the stack must be empty where the overlay host opens).
- Put shorthands BEFORE longhands (`inset` before `top/left/right/bottom`), never after.
- **Test in EMBED mode.** All of this is invisible standalone: `#wv-embedRoot` is the sibling that paints over a
  trapped overlay, and it only exists in embed mode — which is how the hub renders every product. Load
  `<file>#wv-embed=<viewId>&inst=9&theme=dark&density=compact` and hit-test there. Note a hash-only change is a
  same-document navigation: `reload()` afterwards or the app never re-boots in embed mode.

The regression suite now runs this automatically for every dashboard (`smoke()`, "product overlays paint on top
and are clickable in embed mode"): it sweeps the product's own buttons whose tip/id mentions
config/export/option/layout/menu/download/kebab/settings, clicks each, and hit-tests whatever opens. It was
validated against a deliberately re-broken copy — it FAILS with `cfgBtn -> BURIED:filterBar` and passes clean.
A guard that has never been seen to fail is not evidence; break the thing on purpose and watch it catch it.

## A read's action acts ON THE OPEN DASHBOARD (MANDATORY — 2026-09-01)

Genie's Read in **Local** scope is, by definition, about the display currently on screen. So every `cta.run()`
and `insights[].act.run()` on a view-scoped read must **change something in that dashboard, in place** —
scrub to the hour, select the row, focus and ring the panel, flip the sub-view. It must never navigate away,
re-mount, or blank what the operator is looking at.

The failure that produced this rule: product helpers wrote

```js
function ftmJump(viewId,h){ openView(viewId); /* …then setHour(h) */ }
```

Inside an embed (which is how the hub renders every product) `openView()` mounted a view into the child's own
hidden panel area and pushed the product root back to the park — **the dashboard vanished** on a Genie's Read
click. Framework **1.10.12** closes this at the root: in an embed, `openView()` no longer mounts locally. If the
requested view is the one already on screen it is a no-op; otherwise the child posts `{wv:"open-view",viewId}`
and the host opens/activates it. The hub activates an already-open instance rather than re-mounting it.

What this means when you write a product's reads:

- **Target the view the read belongs to.** A read filed for `pf.map` acts on `pf.map`. Calling `openView` for
  that same view is now harmless, but pointless — just do the thing.
- **Crossing views is legitimate but rare** (e.g. "open the drill-down"): call `openView('<other view>')` and let
  the framework relay it. Do not reach into the host yourself, and do not reload or rewrite `location`.
- **Never** call `location.reload()`, rewrite `location.hash`, replace the product root, or re-run the product's
  bootstrap from a read action.
- Every action must be **idempotent and safe to click twice** — the operator will.

Verification (add to the product's deep suite, and the shell suite does it for the sampled products):
open each view in the hub, switch the band to Local, and click **every** cta and insight action on **every** read.
After each click assert the frame still exists, the product root still has size, and the body still has text.
Clicking is the only way to catch this: the handler runs, no error is thrown, and the dashboard is simply gone.
