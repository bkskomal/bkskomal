# Genie Console — component specifications

Exact specs for every UI pattern in the system. All values are literal; they are the
result of hand-tuning at 13px base density. Colors go through tokens or `--c`.

---

## 1. Top bar (40px)

`display:flex;align-items:center;gap:12px;padding:0 6px`

- Logo 22×34 grid-centered, gradient SVG, `filter:drop-shadow(0 0 7px …)`.
- Product name `16px/800`, `-.01em`; the second word is `--ink-2`/600 (two-tone wordmark).
- `.sp{flex:1}` spacer pushes the right cluster.
- Clock: mono `13px/500`, `.02em`, value in `<b>` at `--ink`, zone label `--ink-2`.
- **Icon button `.ib`:** 30×30, radius 8, `display:grid;place-items:center`,
  color `--ink-3`; hover → `--ink` + `rgba(255,255,255,.06)`; active `.on` → `--cyan`
  + `rgba(34,211,238,.1)`. SVG 16px.
- Alarm/notification control: idle = bare 25px bordered chip with a bell.
  Active `.act` = solid `#8f1122`, white text, inline label + white count badge
  (`font:800 9px Inter`), `animation:notifblink 1.4s infinite`. Never a bare red dot —
  it carries a word ("Violations") and a number.

## 2. Primary nav tabs (`.viewnav`) — the amber-underline pattern

```css
.viewnav button{position:relative;display:inline-flex;align-items:center;gap:8px;
  padding:9px 15px 11px;border:none;background:none;font-size:12px;font-weight:600;
  letter-spacing:.012em;color:var(--ink-3);border-radius:10px 10px 0 0;cursor:pointer;
  transition:color .16s,background .16s}
.viewnav button svg{width:15px;height:15px;opacity:.85;transition:opacity .16s,transform .16s}
.viewnav button:hover{color:var(--ink-2);background:rgba(255,255,255,.035)}
.viewnav button:hover svg{opacity:1;transform:translateY(-1px)}
.viewnav button.on{color:#fff;background:linear-gradient(180deg,rgba(245,179,66,.13),rgba(245,179,66,.03))}
.viewnav button.on::after{content:'';position:absolute;left:9px;right:9px;bottom:0;height:3px;
  border-radius:3px 3px 0 0;background:linear-gradient(90deg,#f5b342,#fb923c);
  box-shadow:0 -1px 12px rgba(245,179,66,.65)}
/* per-destination icon color = wayfinding */
.viewnav button[data-view="realtime"] svg{color:#34d399}
.viewnav button[data-view="planning"] svg{color:#a78bfa}
```
Sub-tabs (`.rtnav`) are the same pattern one notch smaller: `11.5px`, padding
`8px 12px 10px`, icons 13px @ `.72` opacity, underline 2.5px.

## 3. Vertical sidebar (240px, collapsible to 66px)

```css
.sidebar{position:fixed;inset:0 auto 0 0;width:240px;z-index:2000;
  background:linear-gradient(180deg,#0a0c12,#070709);border-right:1px solid var(--line);
  transform:translateX(-100%);transition:transform .26s ease,width .26s ease;
  display:flex;flex-direction:column;overflow:hidden}
body.nav-vertical .sidebar{transform:none}
body.nav-vertical .app{padding-left:240px;transition:padding .26s ease}
body.nav-collapsed .sidebar{width:66px}
```
- Head: logo 24–26px + name `15px/700`, collapse chevron 26×26 bordered.
- Group header `.sb-top`: `13px/600`, 18px icon, padding `11px 12px`, radius 10;
  expanded → `--ink` on `linear-gradient(160deg,rgba(34,211,238,.12),transparent)`.
- Items `.sb-i`: `11.5px/600`, padding `5px 8px 5px 11px`, margin `0 5px`, radius 8,
  color `--ink-3`; hover `rgba(255,255,255,.04)`.
- **Active item:** white text, faint fill + 1px border, plus a 3px amber rail via
  `::before{background:linear-gradient(180deg,#f5b342,#fb923c);box-shadow:0 0 10px rgba(245,179,66,.55)}`.
- Sub-list is indented with a `border-left:1px solid var(--line-2)` spine.
- Collapsed: labels/carets/footer `display:none`, items centered.

## 4. Filter bar (42px)

`display:flex;align-items:center;gap:10px;padding:0 14px`

- Leading label `.fl-ic`: 14px icon + `10px/700` uppercase `.09em` in `--ink-3`.
- **Dropdown `.dd`:** `background:rgba(255,255,255,.04);border:1px solid var(--line);
  border-radius:9px;padding:6px 11px`. Two stacked lines: key `9px/700 .09em --ink-3`,
  value `12px/700 --ink` + 12px chevron. Hover → `border-color:rgba(34,211,238,.4)`.
- Menu `.dd-menu`: absolute `top:calc(100% + 6px)`, min-width 250, radius 11, padding 6,
  `background:rgba(11,11,15,.98)`, shadow `0 24px 50px -18px #000`.
  Options `12px/600` padding `9px 11px` radius 8, hover `rgba(34,211,238,.1)`;
  each option may carry a `.sm` sub-line at `9.5px/500 --ink-3`.
- Right side: run-status line (`11.5px`, `--ink-3`, values in `<b>`, `success` in green)
  then ghost + primary buttons.

## 5. Buttons

```css
.btn-primary{display:inline-flex;align-items:center;gap:8px;padding:9px 18px;
  border-radius:10px;border:none;font-size:12.5px;font-weight:700;letter-spacing:.01em;
  color:#fff;background:linear-gradient(135deg,#3b82f6,#6366f1);
  box-shadow:0 8px 20px -10px rgba(99,102,241,.75);transition:.15s;cursor:pointer}
.btn-primary:hover{filter:brightness(1.08);transform:translateY(-1px)}

.btn-ghost{display:inline-flex;align-items:center;gap:7px;padding:9px 16px;
  border-radius:10px;font-size:12.5px;font-weight:600;color:var(--ink);
  background:rgba(255,255,255,.05);border:1px solid var(--line);cursor:pointer;transition:.15s}
.btn-ghost:hover{background:rgba(255,255,255,.09);border-color:rgba(56,189,248,.45);color:#fff}

/* confirm/apply action — dark text on a bright teal→cyan gradient */
.btn-apply{padding:11px;border-radius:10px;border:none;font-size:12.5px;font-weight:700;
  color:#04121a;background:linear-gradient(135deg,var(--teal),var(--cyan))}
```
Button SVG is always 14–15px. Only `.btn-primary` lifts on hover.
Destructive/secondary "reset": `rgba(255,255,255,.04)` + `--line`, `12px/600 --ink-2`.

## 6. Segmented control (`.seg`) — the workhorse toggle

```css
.seg{display:flex;background:rgba(255,255,255,.04);border:1px solid var(--line);
     border-radius:9px;padding:3px;gap:3px}
.seg button{flex:1;font-size:11px;font-weight:600;color:var(--ink-3);background:none;
  border:none;padding:7px 4px;border-radius:6px;cursor:pointer;transition:.12s;white-space:nowrap}
.seg button:hover{color:var(--ink-2)}
.seg button.on{color:#eaf7ff;background:linear-gradient(160deg,rgba(56,189,248,.34),rgba(34,211,238,.12));
               box-shadow:inset 0 0 0 1px rgba(56,189,248,.4)}
```
**Rule: outer radius − inner radius = the padding (9−6=3).** Applies to every
track/thumb pair in the system. Variants only change the active gradient hue
(green track for "quantity" pickers, etc.).

## 7. KPI card (`.kc`) — the signature component

```css
.kpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(158px,1fr));gap:9px}
.kc{position:relative;--c:122,150,220;
  background:linear-gradient(155deg,rgba(var(--c),.10),var(--card));
  border:1px solid rgba(var(--c),.30);border-radius:11px;padding:10px 13px 9px;
  overflow:hidden;display:flex;flex-direction:column;
  box-shadow:0 1px 0 rgba(var(--c),.06) inset}
.kc.alert{box-shadow:0 0 22px -9px rgba(var(--c),.6),0 1px 0 rgba(var(--c),.1) inset}
.kc-badge{position:absolute;top:10px;right:10px;width:30px;height:30px;border-radius:8px;
  display:grid;place-items:center;background:rgba(var(--c),.16);color:rgb(var(--c));
  box-shadow:0 0 0 1px rgba(var(--c),.2) inset}          /* svg 17px */
.kc-lbl{font-size:9px;font-weight:700;letter-spacing:.13em;text-transform:uppercase;
        color:var(--ink-3);padding-right:30px}            /* clears the badge */
.kc-val{font-size:23px;font-weight:700;margin-top:6px;line-height:1;letter-spacing:-.02em;
        font-variant-numeric:tabular-nums;color:var(--ink)}
.kc-val .u{font-size:11px;color:var(--ink-3);font-weight:600;margin-left:3px}
.kc.warnval .kc-val{color:rgb(var(--c))}                  /* value turns semantic on alert */
.kc-desc{font-size:10px;color:var(--ink-2);margin-top:6px}
.kc-desc b{color:var(--ink);font-weight:700}
.kc-spark{margin-top:auto;padding-top:7px;height:30px}    /* pushed to the bottom */
.kc-foot{font-size:9px;font-weight:800;letter-spacing:.09em;color:rgba(var(--c),.9);
         text-transform:uppercase;margin-top:9px}
```
Anatomy top→bottom: **label · value+unit · one-line context · sparkline · status foot**,
with a color badge floating top-right. Light theme adds a 3px colored top-rail
(`::before`) per `.c-*` class.

**Bigger sibling `.ops-card`** (rail hero): radius 15, padding `19px 16px`,
`border-left:3px solid rgb(var(--c))`, value 31px/700, absolutely-positioned 92×30
sparkline bottom-right; `.alarm` swaps the left border red + red glow.

## 8. Section header (`.ph`) — on every panel

```css
.ph{display:flex;align-items:center;gap:9px;padding:11px 14px 10px;
    border-bottom:1px solid var(--line-2);flex:none}
.ph .dot{width:6px;height:6px;border-radius:50%;background:var(--cyan);box-shadow:0 0 8px var(--glow)}
.ph h3{font-size:10.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-2)}
.ph .sp{flex:1}
.ph .cnt{font-size:9.5px;color:var(--ink-3);font-family:var(--mono)}
```
Pattern: **glowing dot · tracked uppercase title · spacer · mono count/pill**.

## 9. Status vocabulary (learn these three, reuse everywhere)

```css
/* health dot */
.hb{width:8px;height:8px;border-radius:50%;flex:none}
.hb.ok{background:var(--green);box-shadow:0 0 7px rgba(52,211,153,.6)}
.hb.warn{background:var(--amber);box-shadow:0 0 7px rgba(245,179,66,.6)}
.hb.crit{background:var(--red);box-shadow:0 0 7px rgba(245,85,109,.6);animation:blink 1.6s infinite}

/* value badge (mono) */
.vbadge{font-size:9.5px;font-weight:700;font-family:var(--mono);padding:2px 6px;border-radius:5px}
.vbadge.crit{color:#ff8298;background:rgba(245,85,109,.13)}
.vbadge.warn{color:var(--amber);background:rgba(245,179,66,.13)}
.vbadge.ok{color:var(--green);background:rgba(52,211,153,.1)}

/* severity chip (sans, uppercase) */
.sev{font-size:9px;font-weight:700;padding:2px 7px;border-radius:5px;
     text-transform:uppercase;letter-spacing:.03em}
.sev.critical{color:var(--red);background:rgba(245,85,109,.14)}
.sev.high{color:var(--amber);background:rgba(245,179,66,.14)}
.sev.medium{color:var(--blue);background:rgba(56,189,248,.14)}
```
Critical red text lightens to `#ff8298` on dark for legibility — pure `--red` fails at
small sizes. Chip fill is always `.10–.16` alpha of the same hue.

## 10. Tree / list rows

```css
.sub-row{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:9px;
         cursor:pointer;transition:.12s}
.sub-row:hover{background:rgba(255,255,255,.04)}
.sub-item.on>.sub-row{background:linear-gradient(90deg,rgba(34,211,238,.13),transparent);
                      box-shadow:inset 3px 0 0 var(--cyan)}
.caret{width:11px;color:var(--ink-3);transition:.15s}
.sub-item.open .caret{transform:rotate(90deg)}
```
**`box-shadow:inset 3px 0 0 var(--cyan)` is THE selection marker** — reuse it on
selected table rows (`tr.sel td:first-child`), riser rows and trace rows so selection
reads identically everywhere.

Row content: 8px health dot · name `12px/600` truncating · mono sub-line `9.5px --ink-3`
· right-aligned mono value. Children indent `28px` with 11px rows.

## 11. Tables

```css
.tbl-scroll{overflow:auto;flex:1;min-height:0}
.tbl-scroll table{width:100%;border-collapse:separate;border-spacing:0}
.tbl-scroll thead th{position:sticky;top:0;z-index:2;background:rgba(10,13,19,.96);
  backdrop-filter:blur(6px);font-size:9px;letter-spacing:.11em;text-transform:uppercase;
  color:var(--ink-3);font-weight:700;padding:8px 10px;border-bottom:1px solid var(--line);
  text-align:left;white-space:nowrap}
.tbl-scroll tbody td{padding:7px 10px;font-size:11.5px;
  border-bottom:1px solid rgba(255,255,255,.045);white-space:nowrap}
.tbl-scroll tbody tr:nth-child(even) td{background:rgba(255,255,255,.014)}
.tbl-scroll tbody tr:hover td{background:rgba(56,189,248,.075)}
tbody tr{cursor:pointer;transition:.1s}
td.mono{font-family:var(--mono)}
```
Fixed-width variants use `table-layout:fixed` + explicit `th:nth-child(n){width:%}` and
ellipsis cells. Inline mini-bar in a cell:
`.mbar{width:56px;height:5px;border-radius:3px;background:rgba(255,255,255,.1)}` with an
`<i>` fill.

## 12. Toggles, sliders, checkboxes

```css
.switch{width:38px;height:21px;border-radius:20px;background:rgba(255,255,255,.14);
        position:relative;cursor:pointer;transition:.18s;flex:none}
.switch::after{content:"";position:absolute;top:2px;left:2px;width:15px;height:15px;
        border-radius:50%;background:#c9c9d2;transition:.18s}
.switch.on{background:linear-gradient(90deg,var(--teal),var(--cyan))}
.switch.on::after{left:19px;background:#fff}
/* compact variant .mini-sw: 34×19, knob 13, travel to 17 */

input[type=range]{-webkit-appearance:none;width:100%;height:5px;border-radius:5px;outline:none;
  background:linear-gradient(90deg,var(--cyan) 0,var(--cyan) var(--p,50%),
                             rgba(255,255,255,.12) var(--p,50%))}   /* set --p from JS */
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:15px;height:15px;
  border-radius:50%;background:#eafcff;border:3px solid var(--cyan);
  box-shadow:0 0 10px var(--glow);cursor:pointer}

input[type=checkbox]{width:14px;height:14px;accent-color:#38bdf8;cursor:pointer}
```
Toggle row `.tog`: 26px icon chip · title `12px/500` + description `9.5px --ink-3` ·
switch right, `border-bottom:1px solid var(--line-2)` between rows, none on the last.

## 13. Inputs & selects

```css
.inp{width:100%;background:rgba(255,255,255,.04);border:1px solid var(--line);
     border-radius:9px;color:var(--ink);padding:9px 11px;font-family:inherit;
     font-size:12.5px;resize:vertical}
.inp:focus{outline:none;border-color:rgba(34,211,238,.5)}
```
Select uses `appearance:none` plus a **data-URI chevron** (`stroke:%2363636e`) at
`background-position:right 11px center`. Dense config forms drop the box entirely:
transparent input, right-aligned mono text, `border-bottom:1px dashed rgba(255,255,255,.16)`
that turns cyan on focus — reads as a spreadsheet, not a form.

## 14. Drawer, modal, context menu

**Drawer** — two modes from one element:
```css
.drawer{position:fixed;z-index:1000;display:flex;flex-direction:column;
  background:linear-gradient(165deg,#0e0f13,#0a0a0d);
  transition:transform .3s cubic-bezier(.22,.61,.36,1),opacity .2s}
.drawer.docked{top:0;right:0;bottom:0;width:456px;transform:translateX(106%);
  border-left:1px solid var(--line);box-shadow:-30px 0 60px -20px rgba(0,0,0,.7)}
.drawer.docked.open{transform:translateX(0)}
.drawer.floating{top:98px;right:24px;width:456px;height:min(720px,calc(100vh - 150px));
  border:1px solid var(--line);border-radius:14px;box-shadow:0 40px 90px -25px #000;
  opacity:0;pointer-events:none;transform:translateY(10px)}
.drawer.floating.open{opacity:1;pointer-events:auto;transform:translateY(0)}
.drawer.floating .dr-head{cursor:grab}
```
Head = 34px cyan icon tile + title `13.5px/700` + sub `10px --ink-3` + 31px action
buttons. Tabs are top-radius-only (`9px 9px 0 0`) with no bottom border. Footer is a
fixed row: ghost reset + `flex:1` apply.

**Modal**
```css
.modal-scrim{position:fixed;inset:0;background:rgba(4,6,13,.62);backdrop-filter:blur(3px);
  z-index:1100;opacity:0;pointer-events:none;transition:.2s}
.modal-scrim.open{opacity:1;pointer-events:auto}
.modal{position:fixed;top:50%;left:50%;transform:translate(-50%,-46%);width:540px;max-width:92vw;
  z-index:1101;background:linear-gradient(165deg,#0f1013,#0b0b0e);border:1px solid var(--line);
  border-radius:16px;box-shadow:0 50px 100px -30px #000;opacity:0;pointer-events:none;
  transition:.22s;overflow:hidden}
.modal.open{opacity:1;pointer-events:auto;transform:translate(-50%,-50%)}
```
Entry animates `-46% → -50%` (a 4% rise) — subtle, not a zoom. Body is a 2-col grid,
`gap:14px`, with `.span2` for full-width fields. Full-screen variant: `inset:0` flex
centering, card `92vw × 86vh`, `max-width:1560px`, radius 18.

**Context menu**: fixed, min-width 206, radius 12, `rgba(10,12,18,.98)` + blur,
cyan-tinted border, mono header line, items `12px` padding `8px 10px` radius 8.

## 15. Map overlays (Leaflet)

- Container background `#060608` (light: `#dfe5ef`); `font-family:var(--sans)`.
- Restyle Leaflet chrome: attribution `rgba(0,0,0,.55)` @ 9px; `.leaflet-bar` no border
  /shadow, links `rgba(12,12,16,.92)` + blur, hover cyan.
- Overlay wrapper: `.ov{position:absolute;z-index:500;pointer-events:none}` with
  `.ov>*{pointer-events:auto}` so only the controls capture the mouse.
- **Every floating map element:** `rgba(6,6,9,.8)` + `backdrop-filter:blur(10px)` +
  `1px solid var(--line)`, radius 10–13.
- Map icon button `.mp-ic`: 34×34, radius 10, 16px SVG.
- Toolbar: centered pill, `rgba(9,11,17,.72)`, blur 18, radius 13, padding 5, inner
  buttons `11.5px/600` radius 8; primary action is the blue→indigo gradient.
- **Legend:** tiny tracked uppercase title, a 150–184×8 gradient bar, mono scale ends,
  then wrapped `10px` key rows with 9–10px color swatches. `max-width:60%`.
- **Node marker:** 22×22 rounded-7 gradient core with a 1.5px light border, a colored
  status ring at `inset:-3px`, an expanding `subpulse` ring, and a `-7px/-7px` red count
  badge. Labels are mono `8.5–9px` chips at `translate(11px,-19px)`.
- **Tooltip `.pf-tip`:** `rgba(8,11,17,.97)`, 1px `rgba(56,189,248,.42)`, radius 11,
  padding `10px 12px`, min-width 214, blur 10, arrow hidden. Title `12.5px/700 #eaf7ff`
  with a bottom hairline; rows are `flex; justify-content:space-between` with a sans
  label and a mono tabular value.
- Flow direction is animated dashes: `stroke-dasharray:2 9;animation:dash 1s linear infinite`.

## 16. Charts (ECharts contract)

Charts must look like they were drawn by the same hand as the CSS:
```js
animation:false                                  // never animate on load
grid:{left:38-48,right:12-18,top:14-22,bottom:22-24}
axisLabel:{color:AXIS_INK, fontSize:9, fontFamily:'JetBrains Mono'}
nameTextStyle:{color:AXIS_INK, fontSize:9-10}
axisLine:{lineStyle:{color:SPLIT}}   axisTick:{show:false}
splitLine:{lineStyle:{color:SPLIT}}  // or {show:false} on the x axis
tooltip:{trigger:'axis', backgroundColor:tipBg(), borderColor:'rgba(34,211,238,.35)',
         textStyle:{color:tipFg(), fontSize:11}}
legend:{top:0,right:6,textStyle:{color:AXIS_INK,fontSize:9-10},itemWidth:14-16,itemHeight:3,icon:'roundRect'}
series:{type:'line', smooth:.3, lineStyle:{width:2.4}, areaStyle:{color:'rgba(<hue>,.14)'}}
```
- Series colors come from the semantic palette: P/load green `#34d399`, Q/reactive blue
  `#38bdf8`, PF/limit amber `#f5b342`, violation red `#f5556d`, AI violet `#a78bfa`.
- Legend swatch is a 3px-tall rounded bar (matches `.lg i` legends in CSS).
- Tooltip HTML reuses the map tooltip classes (`.tn` / `.tr` / `.tr b`) so map and chart
  tooltips are pixel-identical.
- Chart wrapper: `.chartfill{width:100%;height:100%;min-height:0}` inside a
  `flex:1;min-height:0` card body. Re-run `resize()` on layout change.

## 17. Small patterns worth reusing verbatim

| Pattern | Spec |
|---|---|
| **Sparkline** | inline SVG, `width:100%;height:27-30px;display:block`, pushed down with `margin-top:auto` |
| **Progress bar** | track `height:4-8px;border-radius:3-5px;background:rgba(255,255,255,.07-.10);overflow:hidden`; fill is a child `<i>{display:block;height:100%}` |
| **Limit marker** | `position:absolute;top:-2px;bottom:-2px;left:85%;width:1.5px;background:var(--red)` on a bar |
| **Stepper (horizontal)** | 44×44 rounded-12 dots joined by a `::after` 2px line at `top:22px`; done=green fill, active=cyan fill + `0 0 18px -4px var(--glow)` |
| **Stepper (vertical)** | 28px rounded-9 mono number + absolute 2px rail at `left:13px;top:30px;bottom:2px`; rail turns green when done |
| **Gauge ring** | square box `92px`/`122px`, SVG same size, value absolutely centered: mono 25–30px `<b>` + 8px tracked uppercase `<i>` |
| **Chip / tag** | `9-10px/700`, `.03-.08em`, padding `2-4px 7-10px`, radius 5-7, fill `rgba(hue,.14)` |
| **Timeline heat strip** | flex row, `gap:2px`, `height:22-40px`, cells `flex:1;border-radius:3-4px`; hover `outline:1px solid rgba(255,255,255,.35)`, selected `outline:2px solid var(--cyan);outline-offset:1px`, "now" `box-shadow:inset 0 -3px 0 var(--green)`, future `opacity:.38` |
| **Time cursor** | 2px cyan line with a 10px dot `::before`, `box-shadow:0 0 10px var(--glow)` |
| **Bottom dock** | 46px bar (radius `13 13 0 0` open, `13` closed) + 336px body, `animation:dockup .3s cubic-bezier(.22,.61,.36,1)`, chevron rotates 180° |
| **AI recommendation card** | violet: `rgba(167,139,250,.07)` fill, `.22` border, `padding-left:44px` with a 24px absolute icon tile at `12px/12px` |
| **Left-accent stat tile** | `border-left:2-3px solid var(--cyan)` + faint fill; label `8.5px .11em uppercase`, value mono 12.5–15px/700 |
| **Marquee alarm** | 130px overflow-hidden window, inner `animation:almq 9s linear infinite` translating -50% (content duplicated) |

## 18. Info mode (the self-documenting UI)

A first-class UX feature worth copying into any complex console:

- Toggle in the top bar with a second caret button for placement options
  (floating card that follows hover, or docked right panel).
- `body.info-mode [data-info]{outline:1px dashed rgba(56,189,248,.35);outline-offset:-1px;
  cursor:help;border-radius:8px}` → hover thickens to `1.5px` @ `.85` + a `.05` wash.
- Interactive layers are neutralized while explaining:
  `body.info-mode .leaflet-container,canvas,.chartfill{pointer-events:none!important}`
  and native tooltips are hidden.
- Info card: 436px, `rgba(9,12,19,.985)` + blur 14, cyan border, radius 16.
  Header = title `15px/730` + a tracked uppercase kind-chip. Body rows are
  `8.5px .13em` cyan labels over `12.5px/1.65 --ink-2` prose, plus optional
  `.ic-f` mono formula block and a two-up **good/bad** pair (`.ic-ok` green wash /
  `.ic-no` red wash, each with a 3.5px left color bar).
- Docked mode sets `body.info-docked{padding-right:var(--infoW)}` (392px, 344px under
  1400px) so the app **reflows** rather than being covered. Under 1100px it becomes a
  46vh bottom sheet.
