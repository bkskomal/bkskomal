---
name: genie-ui
description: UI/UX design standards for dense, dark-first operational console apps (energy/grid ops, SCADA, monitoring, analytics dashboards) — typography scale, color tokens, spacing, component specs, icon rules, motion, chart/map styling, responsive rules. Use when building or restyling a dashboard, control room UI, admin console, or any data-dense web app, and when asked to "match the Genie Powerflow look" or apply the house UI standard. Extracted from E:\AI\Self\WVShellSample\genie_powerflow.html.
---

# Genie Console UI Standard

A design system for **information-dense operational consoles**: one screen, no page
scroll, many live panels, numbers everywhere. Dark-first with a full light theme.

This skill covers **UI/UX only** — type, color, spacing, components, icons, motion.
It says nothing about app logic.

## 1. Design philosophy (apply these before any pixel)

1. **Viewport-locked shell.** `html,body{height:100%;overflow:hidden}`. The app is a
   CSS grid that fills `100vh`. Scrolling happens *inside* panels, never on the page.
   Only below 1100px does the page become a normal scrolling column.
2. **Small type, high density.** Base is `13px`; most UI text lives at **9–12.5px**.
   Density is the point — an operator sees the whole grid at once.
3. **Numbers are the hero.** Values are large, bold, tight-tracked, tabular-figure.
   Labels are tiny, uppercase, wide-tracked, muted. That contrast *is* the visual style.
4. **Surfaces are barely-there.** Cards are ~2–3% white over near-black, defined by a
   1px hairline, not by fill. Depth comes from hairlines + colored glow, not shadows.
5. **Color = meaning, never decoration.** Cyan is "selected/active/system", green ok,
   amber warn, red critical, violet AI. If it's colored, it means something.
6. **One accent per state.** Selection is a cyan inset 3px bar. Active nav is an amber
   underline. Never both on the same element.
7. **Every panel explains itself.** An "Info mode" toggle outlines each `[data-info]`
   region and shows a plain-language card: what it is, how to read it, what to do.

## 2. Typography

**Families** (Google Fonts, preconnected):
```
--sans:'Inter',system-ui,sans-serif        /* everything */
--mono:'JetBrains Mono',ui-monospace,monospace  /* all numerals, IDs, timestamps, codes */
```
Load `Inter:wght@300;400;500;600;700;800` + `JetBrains+Mono:wght@400;500;600`.
`body{font-size:13px;line-height:1.4;-webkit-font-smoothing:antialiased}`

**The scale** (these exact values — the whole system is built on half-pixel steps):

| Role | Size | Weight | Tracking | Family |
|---|---|---|---|---|
| Hero metric (ops card, sc-big) | 28–34px | 700–800 | `-.02em` | sans, tabular |
| KPI value | 21–23px | 700–800 | `-.02em` | sans, tabular |
| Panel/section title | 15–16px | 700 | `-.01em` | sans |
| Card title / row name | 12.5–13.5px | 600–700 | — | sans |
| Body / list row | 11.5–12px | 500–600 | — | sans |
| Secondary text | 10.5–11px | 400–600 | — | sans |
| **Micro-label (uppercase)** | **8.5–10px** | **700–800** | **.08–.13em** | sans |
| Table header | 8.5–9px | 700 | `.11em` | sans, UPPERCASE |
| Table cell | 10.5–11.5px | 400 | — | sans (`.mono` for numbers) |
| Numeric inline | 9.5–12.5px | 600–700 | — | **mono**, tabular |
| Unit suffix | 55–60% of its value | 600 | — | inherits, `--ink-3` |

**Non-negotiable rules**
- Any digit that can change or be compared gets `font-variant-numeric:tabular-nums`.
  There is a global rule for this; add new numeric classes to it.
- Uppercase micro-labels **always** carry letter-spacing ≥ `.08em`. Uppercase without
  tracking looks broken at 9px.
- Large numbers **always** get negative tracking (`-.02em`) and `line-height:1`.
- Units are a `<span class="u">` inside the value, never a separate line.
- Identifiers, timestamps, coordinates, percentages in tables → mono.
  Prose and labels → sans. Never mix within one string.
- Minimum size is 8.5px and only for tracked uppercase labels. Never put prose below 10px.

## 3. Color

All color is CSS custom properties on `:root`, themed by a `body.light` class.
**Never hard-code a hex in a component** except decorative gradients.

```css
:root{
  --bg:#050506; --bg-2:#08080a;
  --card:rgba(255,255,255,.022); --card-2:rgba(255,255,255,.035);
  --line:rgba(255,255,255,.09); --line-2:rgba(255,255,255,.055);
  --ink:#f3f3f6; --ink-2:#9b9ba6; --ink-3:#63636e; --ink-4:#45454e;
  --cyan:#22d3ee; --teal:#2dd4bf; --green:#34d399; --violet:#a78bfa;
  --amber:#f5b342; --orange:#fb923c; --red:#f5556d; --blue:#38bdf8; --pink:#f472b6;
  --glow:rgba(34,211,238,.3);
}
```

**Ink ladder** — four levels, used strictly:
`--ink` value/primary · `--ink-2` body/secondary · `--ink-3` labels/muted · `--ink-4` ticks/disabled.

**Semantics**

| Token | Means |
|---|---|
| cyan | selected, active, system/live, primary interactive accent |
| blue | secondary data series, info severity |
| green | healthy / done / converged / positive delta |
| amber | warning, degraded, **active-nav underline** |
| red | critical, violation, alarm |
| violet | AI / ML / recommendations |
| orange | DER / distributed assets |
| pink | forecast / secondary AI |

**The `--c` triplet pattern** (the most reusable idea in this system). Any card can be
recolored by setting one variable, because it is authored as an RGB triplet:
```css
.c-cy{--c:34,211,238} .c-bl{--c:56,130,246} .c-gn{--c:52,211,153}
.c-am{--c:245,179,66} .c-rd{--c:245,85,109} .c-tl{--c:45,212,191}
.c-vt{--c:167,139,250} .c-or{--c:251,146,60} .c-pk{--c:244,114,182}

.kc{background:linear-gradient(155deg,rgba(var(--c),.10),var(--card));
    border:1px solid rgba(var(--c),.30)}
.kc-badge{background:rgba(var(--c),.16);color:rgb(var(--c))}
```
**Standard alpha ladder for a semantic color:**
`.02–.03` card wash · `.06–.09` hover/soft fill · `.10–.16` active fill / icon chip ·
`.22–.35` border · `.9–1` text & glyph.

**Light theme.** Same variable names, re-declared on `body.light`. Accents are
*darkened for contrast on white*, not reused:
```css
body.light{--bg:#e8ecf3; --bg-2:#f4f6fa; --card:#fbfcfe; --card-2:#eef1f7;
  --line:rgba(23,32,53,.16); --line-2:rgba(23,32,53,.09);
  --ink:#131a2b; --ink-2:#3f4a63; --ink-3:#6b7590; --ink-4:#9aa3b8;
  --cyan:#0a91ad; --teal:#0d9488; --green:#0f8a5f; --violet:#6d47d9;
  --amber:#b45309; --red:#c62742; --blue:#0369a1;}
```
In light mode, cards become **solid white with a real shadow** (`0 1px 2px` + a soft
`0 10px 26px -22px` lift) instead of translucent, and KPI cards gain a 3px colored
top-rail via `::before`. Layout wrappers stay `transparent` so cards read as cards.

**Body ambience** — two large low-alpha radial gradients keep the near-black from
looking flat:
```css
background-image:
  radial-gradient(900px 500px at 8% -6%,rgba(34,211,238,.045),transparent 60%),
  radial-gradient(900px 600px at 100% 0%,rgba(59,130,246,.05),transparent 60%);
```

## 4. Space, shape, elevation

- **Spacing scale (px):** `2 3 5 6 7 8 9 10 11 12 13 14 15 16 18 22`.
  Panel gutter `10–12`, card padding `9–16`, tight rows `5–9`. Odd numbers are
  intentional — at this density even-only steps read as too loose.
- **Radius by size of thing:** chip/badge `5–7` · button/input/icon-button `8–10` ·
  card/panel `11–14` · modal/hero `14–18` · pill/track `20px`+ · dot `50%`.
  *Rule: radius grows with the element; never a uniform radius everywhere.*
- **Borders:** `1px solid var(--line)` is the default edge. `--line-2` for internal
  dividers (row separators, section rules). Accent borders use `rgba(var(--c),.30)`.
- **Elevation** (only for things that float):
  - dropdown/menu: `0 24px 50px -18px #000`
  - drawer: `-30px 0 60px -20px rgba(0,0,0,.7)`
  - modal: `0 50px 100px -30px #000`
  - map hero: `0 24px 70px -34px #000, 0 0 0 1px var(--line)`
  - Flat panels get **no** shadow in dark mode — the hairline is the edge.
- **Glass:** every element floating over a map or the page gets
  `background:rgba(6,6,9,.8); backdrop-filter:blur(10px); border:1px solid var(--line)`.
  Light mode swaps to `rgba(255,255,255,.92)`.
- **Glow** replaces shadow as the emphasis tool: status dots `box-shadow:0 0 7px <color>`,
  active tab `0 0 20px -10px var(--glow)`, alarm `0 0 26px -14px rgba(245,85,109,.7)`.

## 5. Layout

**Shell**
```css
:root{--topH:40px; --titleH:56px; --filterH:42px; --bandH:126px}
.app{display:grid;height:100vh;padding:12px;gap:10px;
     grid-template-rows:var(--topH) 1fr;max-width:2560px;margin:0 auto}
.stage{position:relative;min-height:0}
.view{position:absolute;inset:0;display:none;gap:10px}
.view.on{display:grid}
```
Chrome heights are **variables**, so a row can be retuned in one place.

**Named grid areas** for each view — layout is declarative and readable:
```css
.view.planning{
  grid-template-rows:auto auto calc(var(--filterH) - 5px) 1fr var(--bandH);
  grid-template-columns:224px minmax(360px,1fr) 548px;
  grid-template-areas:"pnav pnav pnav" "kpi kpi kpi" "filter filter filter"
                      "tree map ctx" "band band band"}
```
**Canonical console shape:** left tree/rail `200–250px` · fluid center map/chart
`minmax(320px,1fr)` · right context panel `320–548px` · full-width KPI row on top ·
full-width time band at the bottom.

**Survival rules for nested flex/grid** (this is what makes a no-scroll app work):
- Every scroll container ancestor gets `min-height:0` (and `min-width:0` for h-scroll).
- Scrollable regions are `flex:1;overflow:auto`; their headers/footers are `flex:none`.
- Panels are `display:flex;flex-direction:column;overflow:hidden`.
- Absolute-positioned view swapping (`position:absolute;inset:0` + `.on`) instead of
  mounting/unmounting, so charts keep their size.

**Breakpoints:** `1650` (tighten columns) · `1500` / `1450` · `1240` (drop to 2 cols) ·
**`1100` — the big one**: page unlocks to vertical scroll, all grids become
`flex-direction:column`, map gets a fixed `68vh`, nav rows wrap ·
`1000` · `640` (KPI grids to 1 column, `.app` padding → 8px) · `560`.

**KPI rows are always** `grid-template-columns:repeat(auto-fit,minmax(158px,1fr))` —
auto-fit means no breakpoint is needed for card counts.

## 6. Icons

- **Inline SVG only.** No icon font, no sprite, no external library. ~233 inline icons.
- Grid: `viewBox="0 0 24 24"` (small chevrons/carets use `0 0 12 12`).
- Always `fill="none" stroke="currentColor"` so icons inherit text color and theme.
- **Stroke width: `1.8` default, `1.9` for nav/top-bar, `2–2.4` for tiny or emphatic
  glyphs (+, play, chevron).** Never below 1.5 or above 2.4 for UI icons.
- Sizes are set in CSS by context, never on the SVG:
  `10–12px` inline/caret · `13–14px` tabs, list rows, small buttons ·
  `15–17px` toolbar, card badges · `18–20px` sidebar, section heads ·
  `23–25px` hero/engine badges.
- Icons in a colored chip: chip is `rgba(var(--c),.14–.18)`, glyph is `rgb(var(--c))`,
  chip radius 7–10px, chip 20–34px square.
- Nav icons are **individually colored per destination** (green=network, cyan=profile,
  blue=powerflow, violet=validation, orange=DER, pink=forecast, amber=studies,
  grey=config) at `opacity:.72–.85`, going to `1` when active. This is a wayfinding
  device — keep the mapping stable across the app.
- Draw simple, geometric, 1-2 path glyphs. Feather/Lucide grammar.

## 7. Motion

- **Transitions:** `.12s` micro (tab/button hover), `.14–.16s` standard (cards, chips),
  `.18s` toggles, `.2–.22s` modal, `.26–.3s` drawer/sidebar.
  Easing: default for micro; `cubic-bezier(.22,.61,.36,1)` for panels.
- Hover = color + border change. Only the primary button lifts (`translateY(-1px)`).
- **Named animations, used sparingly and only to encode state:**
  `blink` 1.6s (critical status dot) · `subpulse` 2.6s expanding ring (live node) ·
  `dash` / `ifflow` marching dashes (power/data flow direction) ·
  `vpulse`/`violPulse` (violation ring) · `bellwob` (unread alarms) ·
  `abpulse`/`notifblink` (alarm banner) · `dockup` (panel reveal) · `almq` (marquee).
- **Nothing animates on load.** Charts use `animation:false`. Motion means *live data*,
  not decoration — if it moves, an operator should look at it.

## 8. Accessibility & polish rules

- Focus ring, globally: `button:focus-visible,input:focus-visible,textarea:focus-visible
  {outline:2px solid rgba(56,189,248,.6);outline-offset:2px}`.
- Status is **never color-only** — every state pairs color with a shape, glyph, badge
  text, or position (severity chip text, `hb.ok/warn/crit` dot + label, `sev` label).
- Custom scrollbars: `9px`, thumb `rgba(255,255,255,.13)` with
  `border:2px solid transparent;background-clip:content-box`, hover → accent.
- Tables: sticky `thead` with a solid/blurred background, zebra at
  `rgba(255,255,255,.014)`, hover `rgba(56,189,248,.075)`, `white-space:nowrap` cells.
- Truncate with `white-space:nowrap;overflow:hidden;text-overflow:ellipsis` plus
  `min-width:0` on the flex parent — do it on every name/label in a flex row.
- `title=""` on every icon-only control.

**Known weak spots in the source — fix these when you apply the system:**
- 8–9px prose (`.aic-cap`, `.fa-sc .l`, some map labels) is below comfortable reading
  size. Reserve <10px for tracked uppercase labels only.
- `--ink-3` on `--card` is around 4:1 — fine for labels, **not** for prose. Use
  `--ink-2` for anything a user must read.
- The source accumulated duplicate/override rules and `!important` (light theme,
  repeated `.rtnav`/`.viewnav` blocks). Author once, in token order; don't replicate that.
- Add `@media (prefers-reduced-motion:reduce)` to disable blink/pulse/marquee.

## 9. Applying this

1. Copy `references/tokens.css` into the project first — variables, reset, base type,
   scrollbars, focus ring, `.c-*` color classes, light theme.
2. Build the shell: grid `.app`, named `grid-template-areas` per view, `min-height:0`
   everywhere.
3. Compose from `references/components.md` — it has exact specs for KPI cards, section
   heads, segmented controls, nav tabs, buttons, chips, tables, toggles, sliders,
   dropdowns, drawers, modals, tooltips, map overlays, sidebar, dock, steppers,
   gauges, sparklines, and the ECharts/Leaflet style contract.
4. Ship both themes at once. Never write a color that only exists in one theme.

**Review checklist before calling a screen done**
- [ ] Zero page scroll ≥1100px; every overflow is inside a panel
- [ ] All numerals mono + tabular; all units are `.u` spans
- [ ] Every uppercase micro-label has ≥.08em tracking and is `--ink-3`
- [ ] No raw hex in components; every accent goes through `--c` or a token
- [ ] Light theme verified on every new surface (card, header, overlay, chart, tooltip)
- [ ] Icons: 24-grid, `currentColor`, stroke 1.8–1.9, size set in CSS
- [ ] Hover, active, selected, focus-visible, and disabled all defined
- [ ] Status conveyed by more than color
- [ ] Checked at 1650 / 1240 / 1100 / 640

## ONE focus ring per control (Genie shell ruling, 2026-09-03)

A bare `input` inside a framed field - a filter pill, a search box, a chip that holds an input -
**delegates its focus ring to the FRAME**. The wrapper is what the eye reads as the control; the
input is an implementation detail inside it.

The failure this came from: `.wv-dd-filter` drew `inset 0 0 0 1px accent` on `:focus-within`, and
the input ALSO picked up the global `:focus-visible` ring (`0 0 0 2px bg0, 0 0 0 4px accent`) at its
own 4px radius. An 18px-tall input wearing a 4px ring inside a 28px 8px-radius pill overflows to
within 1px of the frame on both edges, so it reads as a second, differently-rounded rectangle,
clipped top and bottom. Two rings, two radii, one control - and it looked broken rather than focused.

The house form:

```css
.frame:focus-within{background:var(--wv-bg1);
  box-shadow:inset 0 0 0 1px var(--wv-acc),0 0 0 3px var(--wv-acc-dim)}
.frame:focus-within .icon{stroke:var(--wv-acc)}     /* the frame's glyph joins the state */
.wv-root .frame input:focus-visible{box-shadow:none;border-radius:inherit}
```

An accent hairline plus a soft accent halo - the `.wv-field` language. Never `border-radius` on the
inner input that differs from the frame's; if a ring must survive there, it inherits.

**Check it when you add any framed input.** `getComputedStyle(input).boxShadow` must be `none` and
the frame must carry exactly one ring, in BOTH themes. Killing `outline` is not enough - the global
`:focus-visible` rule paints a `box-shadow`, not an outline, so `outline:none` leaves it standing.

## Auto-advance stops when someone is reading (Genie shell ruling, 2026-09-03)

Any surface that rotates on a timer - a read band, a carousel, a ticker - **halts while it is
expanded**. Expanding is a deliberate act that means "I am reading this"; swapping the content out
from under that is the one thing rotation must never do.

Three parts, all required:

- The rotation guard consults the expanded flag, not only the explicit pause toggle.
- Collapsing **restarts the countdown from zero**, so the first thing that happens after you close
  the detail is not an immediate advance.
- The pause control tells the truth. While held it is not actionable, so render it `disabled` and
  let it read as STATE (stopped) with a title saying why - never leave a control offering an action
  it cannot perform, and never let it claim rotation is running when it is not.

Manual paging (prev / next / dots) stays live while expanded: that is the reader steering, which is
the opposite of content moving on its own.

## Icon-rail selection (Genie shell ruling, 2026-09-01)

For a minimised icon rail (~52px), the selected state is an **edge bar + soft chip**, never a solid accent
fill: a FULL-BLEED row rectangle — the whole row edge to edge, SQUARE corners (10% accent wash, 1px inset hairline), with the 3px accent bar running the row's full height on its left edge (part of the rectangle, not a separate mark; detached at the rail edge it reads as two marks with a gutter), and a
1px inset hairline behind the icon, glyph at full accent. A solid fill is the loudest mark in the system
and reads as "pressed", not "you are here". For nav tabs with counts: active = soft wash (8%) + 2px
underline (gradient tail, glow) + the count as a mono tabular pill — accent-on-16% when active, muted
otherwise. Both marks derive from the accent token; neither state may be colour-only.

## Side panels in RTL (Genie shell ruling, 2026-09-01)

In an RTL layout the inline-end edge is the LEFT one. Every side-anchored surface — quick settings,
alarm and notification drawers, docked info/help panels — mirrors as a UNIT:

- it anchors to the left, not the right;
- its hairline moves to the edge that now faces the content (`border-left` → `border-right`);
- it slides in FROM the left (mirror the keyframe — a repositioned panel still entering from +26px
  reads as flying in from across the screen);
- anything it pushes (a dock that insets the main area) pushes the other way, and any edge affordance
  (a resize grip) moves to its new inner edge.

Half a mirror is worse than none: a panel on the correct side whose border and animation still point
the old way looks broken rather than un-localised. Verify by MEASUREMENT in both directions — assert
the box against the viewport edge and the border widths, in RTL *and* LTR, so the fix cannot silently
regress the majority language.

## Two zones on one bar, and how a selection is marked (Genie shell ruling, 2026-09-02)

When a second control group shares a row with tabs (a product's sub-view/mode switcher beside the
document tabs), one divider is NOT enough to stop it reading as more tabs. Use three cues together:

- **different ground** — the group sits in its own inset track (a faint fill, a 1px hairline, a small
  radius) where tabs sit directly on the bar;
- **different shape** — chips in a track versus top-attached squared tabs;
- **a real gap plus a rule** — a 1px separator at ~60% row height with ~12px either side.

**Give the two zones DIFFERENT selection marks.** If the active tab and the active chip highlight the
same way, the zones collapse back into one bar in the reader's mind however you style the ground: keep
the tab's underline, and mark the mode with a filled chip. Assert the difference in tests — it is the
kind of thing a later round quietly unifies.

**A selection OWNS its cell.** No padding, no gap, square chips, and let the track clip them so the end
chips inherit its corners — a fill floating inside a 2px margin reads as unfinished (the same ruling
as the icon rail's full-bleed row rectangle).

**To make a selection read as LIT, go inset.** A clipping track kills an outer glow, and a full 1px
border doubles the track's own edge top and bottom. Use accent edges on the left and right (which also
mark where the segment starts and ends once chips abut), a 1px specular line along the top, and a
slightly stronger fill. In a light theme a white specular is invisible on a pale fill — let the edges
carry it alone.

**Cost it in vertical space.** A second bar spends ~40px on every screen forever, including the products
that have no modes; the right end of the tab row is usually empty and costs nothing. Prefer the row you
already have, and degrade (labels -> icons -> a menu) with a hard floor so the tabs are never crushed.

### The segmented control's selection (house spec, 2026-09-02)

Applies to every segmented control in the shell — the product mode group, the Genie's Read
Global/Local scope, and any a converted product keeps. Consistency here is what makes two unrelated
controls read as one system.

```
track   border 1px hairline · radius ~9-13px · faint fill · NO padding · NO gap · no clip
buttons abut; first/last carry the track's inner radius explicitly
active  margin:-1px 0            <- grows OVER the track border along its own span
        inset 0 0 0 1px accent   <- a full ring: the group's outline turns accent here
        inset 0 1px 0 #fff ~14%  <- specular top (dark theme only)
        0 0 10px -4px glow       <- a whisper of lift
        fill: accent ~18-20%
```

The reasoning behind each line, because the obvious alternatives all fail:

- **Why the active button covers the border rather than sitting inside it.** A button that fills the
  track's inner height cannot take a 1px top/bottom line without stacking it directly against the
  track's own border — two hairlines with no gap read as a thick muddy edge, not a highlight.
- **Why the clip comes off.** `overflow:hidden` clips at the PADDING box, so the overlap would be
  clipped away; the end buttons then need their corners set explicitly instead.
- **Why vertical overlap only.** A horizontal one shifts every following button by a pixel each time
  the selection moves — a 1px jitter on every click is worse than a 1px inlay at the two extreme ends.
- **Why not an outer glow alone.** A clipping track eats it, and once the clip is gone a glow without a
  ring reads as blur rather than selection.
- **Light theme.** A white specular is invisible on a pale fill — drop it and let the ring carry the
  selection.
- **Dividers.** Where the control draws 1px separators between buttons, make the divider transparent on
  the active button AND the one after it, or it stacks against the ring.

A selection also OWNS its cell: no padding, no gap, square middles. A fill floating inside a 2px
margin reads as unfinished — the same ruling as the icon rail's full-bleed row rectangle.
