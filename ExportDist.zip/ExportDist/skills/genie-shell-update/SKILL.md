---
name: genie-shell-update
description: Propagate the current GenieApplicationShell.html framework into dashboards/products that already embed the shell — splice the updated shell chunks by sentinel, apply contract deltas, bump the version stamp, and re-verify each product. Use when the shell has changed and integrated dashboards need the update, or when asked to "update the shell in the dashboards" / "propagate shell changes".
---

# Genie Shell — Update Integrated Dashboards

Brings already-converted products up to the current framework. The shell layer is
replaced wholesale by sentinel splice; **product bytes are never touched by the splice**.

## Canonical sources

1. `E:\AI\Self\Genie\GenieApplicationShell.html` — the framework (source of truth).
   Head meta `wv-shell-version` is the release stamp.
2. `E:\AI\Self\Genie\WV-INTEGRATION-SPEC.md` §7 — the sentinel & versioning contract
   (nine chunk names, byte-exact sentinel lines, product block markers).
3. `E:\AI\Self\Genie\WV-PRODUCT-UPDATES.md` — pending contract deltas that need
   product-side edits beyond the splice, and where each round is recorded.
4. `E:\AI\Self\Genie\tools\splice_shell.py` — the canonical propagation script
   (target list = the five dashboards + the hub; splices the nine chunks, bumps stamps,
   asserts sentinel integrity). Copy it to the scratchpad to iterate; copy back when it
   changes. Never retype it.

## The propagation set (keep this list current)

| app-id | file | notes |
|---|---|---|
| ftm | `dashboards\ftm_optimization_dashboard_wv1.1.html` | |
| btm | `dashboards\btm_soc_forecast_dashboard_wv1.1.html` | |
| ev | `dashboards\ev_dashboard_wv1.4.html` | |
| dlrmap | `dashboards\dlr-genie-map_wv1.4.html` | |
| dlrline | `dashboards\dlr-genie-line-details_wv1.4.html` | |
| conv | `dashboards\conversationAndFeedback_wv1.2.html` | re-integrated 2026-08-31 from a NEW raw; supersedes wv1.0 (retired) |
| pf | `dashboards\genie_powerflow_genie_standard_wv1.0.html` | integrated 2026-08-29 |
| bafc | `dashboards\BA_Margin_Capacity_Dashboard_wv0.8.html` | integrated 2026-08-31 (BA Forecast & Capacity Console) |
| hub | `index.html (the hub; renamed from GenieAllDashboards.html 2026-08-31)` | multi-product hub; its hub layer (`#wv-hub-css` + `#wv-hub-js`) lives OUTSIDE the sentinel chunks and must survive the splice byte-for-byte |

**Hold lifted (1.8.9, 2026-08-29):** the 1.8.0 hold (dashboards kept at 1.7.6 while the chat widget
rollout awaited approval) is over — all EIGHT dashboards + the hub are on the current framework and stay in
lock-step from now on. The chat loader is path-resilient since 1.8.9: it probes `chat/` beside the
host file and falls back to `../chat/` (the config load is the probe), so `dashboards\*.html` share
the ONE `E:\AI\Self\Genie\chat\` folder — no copy/junction, no `WV_GENIE_CONFIG.bundle` override.
The designed probe leaves one `404 chat/genie-config.js` console line on a subfolder file; the
suite tolerates exactly that line and asserts `GWID.base === "../"` afterwards.

RAW products merged into the hub without integration (`RAW` set in the hub layer, e.g. conv, pf)
are NOT propagation targets — they carry no sentinels; the hub layer itself is outside the
sentinels and survives every splice.

Every file carries `<meta name="wv-app-id" content="<id>">` (storage namespace since
1.4.1) — a file without it is a pre-1.4.1 conversion: add the meta as a contract delta.

## Procedure

### 1 · Inventory

For each candidate file (default: `E:\AI\Self\Genie\dashboards\*.html`, or the files the
user names): read its `wv-shell-version` meta and compare to the framework's.
- Same version → skip (report "current").
- Older version → queue for update.
- **No sentinels / no version meta** → this is a pre-1.1.0 conversion or a raw file;
  it cannot be spliced. Say so and hand it to `genie-shell-integrate`
  (re-integration: extract its product layer, reassemble on current chunks).

### 2 · Splice — BY SCRIPT, never by retyping

Python script (in the scratchpad; write the script to a file first):
- Extract each of the nine `WV-SHELL:BEGIN/END` chunks from the framework
  (sentinels inclusive): `fonts` `css` `symbols` `login` `app` `overlays`
  `js-core` `js-render` `js-app`.
- In the product file, replace each same-named sentinel range with the framework's
  chunk. Assert every chunk name matched exactly once in both files BEFORE writing;
  abort whole-file on any mismatch (never write a half-spliced file).
- Update the file's `wv-shell-version` meta to the framework's.
- The `WV-PRODUCT:BEGIN/END registration` block and all other product bytes stay
  untouched by this step.

### 3 · Contract deltas

Read `WV-PRODUCT-UPDATES.md` "Pending propagation" and the deltas section: some releases
need small product-side edits (new registration options, renamed hooks, new storage-key
collisions). Apply them as targeted edits per product, listed explicitly in the report.
If a delta is ambiguous for a product, surface it instead of guessing.

### 4 · Verify every touched file

**Durable suite (since 1.8.9): `E:\AI\Self\Genie\tools\verify_shell.py`** — one file, runnable against
any shell-integrated URL, per-feature tally, strict error policy (zero `pageerror` in the page AND every
frame/popup; `console.error` tolerated only for the favicon probe, the RAG host, and the loader's
designed `chat/genie-config.js` probe). `python tools\verify_shell.py` runs the default set (framework
deep · hub deep · five dashboards smoke · hub file://); `--url <url>` for one file (`--smoke` for a boot
smoke), `--only <regex>` for a feature subset, `--json <report>` for the tally. Extend it when the
framework grows a feature; a round is not done until it is green on every touched file.

Manual/ad-hoc checks (what the suite encodes), Playwright (`channel="chrome"`, venv
`C:/Users/bkkom/.venv/Scripts/python.exe`, `PYTHONIOENCODING=utf-8`), over `http://localhost`:
- Boot → login → shell present; **strict zero `pageerror` AND zero `console.error`**
  for the whole run (the only tolerated console line is Chrome's own `/favicon.ico`
  probe against the local server, matched by exact text).
- Every registered view still opens and renders its content marker.
- Theme round-trip; one embed (`#wv-embed=`) check.
- Shell surfaces that products feed: the OATI Genie chat component mounts after sign-in
  (`document.querySelector('oati-genie-chat-widget')`, `window.__GENIE_WIDGET__`), opens on
  Ctrl+G, and `WV.genie.desk.content().items` lists the unacked alarms (shell ≥ 1.8.0; a
  1.7.x file still has the built-in drawer); the herald/voice path is intact (`typeof earCommand === "function"`,
  `GENIE_CMDS.length` ≥ 20); the Voice-commands overlay opens.
- For the hub: also attach `pageerror`/`console` listeners to every child iframe and
  assert each product's default view reaches `{wv:"ready"}`.
- If the product has its own E2E suite from integration, run it fully green.
- Screenshots per product for the record.
A failure means the round is not done — fix at root cause (usually a contract delta
missed in step 3) and re-verify.

### 5 · Record the round

In `WV-PRODUCT-UPDATES.md`: move shipped items out of "Pending propagation" into a dated
round entry listing per-file from→to versions and suite tallies.

## A `//` comment NEVER goes on a line that continues (MANDATORY - learned 2026-09-03)

Three regressions in a single round, all from one habit, all caught by the gate rather than by
reading the diff:

```js
const top = S.alarms.filter(a => !a.acked && genieCovers(alarmProduct(a))).slice() // only in-scope
  .sort(...).slice(0, 2);          // <-- SILENTLY DELETED
```

The shell is dense single-file JavaScript where **most lines continue** - a chained `.sort()`, a
second statement after a `;`, the rest of a template literal. A trailing `//` swallows all of it, and
the result reads as correct code with a helpful comment, so review does not catch it. What these
three cost: Genie briefing UNSORTED and UNLIMITED alarms (Minor announced before Critical), the same
for notifications, and Reset preferences silently no longer clearing the saved session.

- **Put the comment on its own line above the statement.** Always, even when the line looks like it
  ends.
- After any patch that adds comments, sweep for the pattern - a regex for `//` followed on the SAME
  line by `.sort(` / `.slice(` / `.map(` / `store.set(` / `persist(` costs one command and finds it
  instantly.
- The same trap exists inside template literals, where a `//` is not a comment at all and becomes
  literal output.

**And a placement rule that came with it:** the Quick Settings rows have asserted ADJACENCIES (the
1.9.8 ruling that Login briefing sits directly under Login greeting). Inserting a new row "somewhere
sensible" broke that pair. Add a row NEXT TO its own family, and if a suite check names two rows as
neighbours, they are neighbours by ruling - not by accident.

## Rules that override convenience

- Never splice into a file without both sentinels of every chunk verified present.
- Never "fix" product code during a splice round except as a named contract delta or a
  root-cause fix for a verification failure — and say which.
- Backups: before the first write to each file, copy it to
  `<name>.pre-<newversion>.html` beside it; delete the backup only after its
  verification passes.
- Write patch scripts to files before running (heredoc backslash collapse).
- Never edit inside a product file's sentinel chunks by hand — a hand edit is erased by
  the next splice. Framework fixes go to `GenieApplicationShell.html`, then propagate.
- After every round, refresh this skill's propagation-set table if files were added or
  renamed, and mirror the skill to `E:\AI\Self\Genie\skills\` (see README there).

## Release history the splice must know about (contract deltas already shipped)

- 1.4.1 — `wv-app-id` meta (per-file storage namespace); vendored ECharts (self-contained
  rule: no CDN); framework boots EMPTY (`startupWs:null`), products pass their own.
- 1.5.0 — native login greeting + voice gender + sign-in quiet window.
- 1.6.x — 17+ localized voice commands; generic "open ‹view›" resolves catalog names in
  all five languages (catalog names must be i18n arrays); Voice-commands overlay.
- 1.7.0 — Genie Chat redesign (rail / Genie's Desk / chat tabs / settings popover, popup
  parity). Provider reply contract widened: `WV.genie.register(fn)` may return
  `string | {text, details?, actions?}` — old string providers keep working.
- 1.7.1 — `window.EMB` exposed (products' embed guard works: mode bars switch in place inside
  hub frames/popouts). Hub boots on an inline `hub-home` workspace; workspace `views` are NAMES.
- 1.7.2 — `visibleCatalog()` follows the active product when >1 product is registered (hub palette/nav
  scoped); voice + Genie groups + "Open <product> home" actions keep hub-wide reach.
- 1.8.9/1.8.10 — Info mode into product frames (info/info-item/info-clear/info-exit); `shell:true`
  catalog views (hub-level folders); embed posts a health snapshot after ready; `../chat/` loader
  fallback; propagation set = 5 dashboards + conv + pf + hub.
- 1.9.0/1.9.1 — Genie's Read scope Global/View (`WV.genieRead.set({product, view?, reads})`, session-only), read
  band in popouts (`&band=1`), notifications drawer `#wv-ndrawer`, `WV.embedURLFor` (shell-view popouts);
  the lamp always opens the chat — the event badge delivers a carried herald event.
- 1.9.4 — sign-in briefing + stop gestures: pref `loginBrief` (read | alarms | notifs | none; QS "Login briefing"
  under Login greeting, greyed when the greeting is Off), `briefRun/briefItems` chain after the greeting, ONE
  `stopSpeaking(reason)` (lamp click while speaking, voice "stop" barge-in via `earGate`/`STOP_RX`, Esc first,
  island ■, Voice Off, `interrupt:true`), `#wv-podGenie[data-speaking]`. No product-side delta.
- 1.9.5 — greeting style pref `greetStyle` ("simple" default: Hello / Bonjour / ¡Hola / مرحباً / こんにちは + name;
  "timeofday": the 1.5.0 Good-morning greetings). QS row "Greeting" above Login briefing, palette
  `act:greet-*`, `GREET_SIMPLE`. No product-side delta.
- 1.9.6 — digital-rain dot texture: the Read band's four `.wv-gr-tex i` tile layers and the Halo lamp's
  `.wv-gb-aura` fall top-to-bottom (`wv-gr-rain` / `wv-gb-halorain` mask-position-Y keyframes, per-layer
  phase + a slower trail layer; `--wv-rain-speed`, `--gb-rain` busy = faster; reduced motion → static
  grid). CSS chunk only — no product-side delta.
- 1.9.7 — the Dot shimmer slider is the rain speed for BOTH the band and the Halo lamp:
  `--wv-rain-speed = 100 / max(shimmer%, 25)` on the shell root (200 % = 2× faster, 50 % = half, Off =
  static grid + aura frozen). `--gb-rain` derives from it (busy = 0.45×). No product-side delta.
- 1.9.8 — "Login briefing" QS row is the title alone (sub-line + its i18n key removed); Dot shimmer DEFAULT = 25 %
  (`store.get("greadTwinkle",25)`, `PREF_DEFAULTS`, slider fallbacks; stored values win). No product-side delta.
- 1.9.9 — Genie's Read scope LABEL View → **Local** (= the display currently open); API value stays `"view"`
  (`S.greadScope`, `setGreadScope`, `WV.genieRead.set({view})`). Labels/tooltips/palette/info/i18n only — no product delta.
- 1.9.10 — alarm-burst debounce (`summNoteAlarm` → 2.5 s timer) re-checks `S.alarmSumm` before filing the summary
  read. Suite lesson: hub frames raise a startup alarm storm — blocks that pin a read must clear `SUMM.timer`. No product delta.
- 1.9.11 — Summarize alarms (burst → summary read) defaults OFF (`alarmSumm:false`); explicit voice/palette summary still works. No product delta.
- 1.10.0 — reliable voice commands: barge-in (a matched command spoken over the genie cancels the speech and runs; only
  echoes are dropped), speaking watchdog (a stuck flag can never mute commands), heard bubble + replies always at the genie
  (even while the lamp carries an event; “phrase” ✓ Reply.), interim transcript, `maxAlternatives=3`, session self-heal
  (`earKick`, visibilitychange), `WV.voice.diag()/log()/say()/match()`. No product delta.
- 1.10.1/1.10.2 — Voice diagnostics strip in the Voice commands sheet (+Copy); the ear PAUSES while the genie speaks
  (`earPause` abort on utterance start / `earResume` on end) — keeping it running let the mic transcribe the speakers, which
  made commands slow/missed. Rule: never let SpeechRecognition run while speechSynthesis plays. No product delta.
- 1.10.3 — microphone self-check on Listening On (`earCheckMic`: inputs → open default → level; dead default → names a
  working input; `EAR.mic`, diag cell). Chrome's SpeechRecognition always uses the DEFAULT input. No product delta.
- 1.10.4 — voice rows lead the Genie assistant card; healthy mic NOT announced (problems still explain); the hub file
  is `index.html` (renamed from GenieAllDashboards.html 2026-08-31; served as the default page at `/`). No product delta.
- 1.10.5/1.10.6 — “Hello” voice command (native greeting back + product welcome); UI scale × Font size = `--wv-vz`
  zooms every `.wv-view-body:not(:has(> iframe))` (px product content follows; shell font tokens re-based inside; embeds
  adopt scale/fontScale/motion over the relay and zoom themselves — never both sides). No product delta.
- 1.10.7 — product shortcuts in the hub: registerShortcuts relays `{wv:"shortcuts"}` up from embeds (at registration,
  not ready); `fwdKeyToFrame` forwards unclaimed product-shaped keys to the active frame (panel `[data-uid]`, not the tab);
  '?' in an embed posts `{wv:"key-help"}` BEFORE the sign-in gate. Hub handles both messages. No product delta.
- 1.10.8 — the SHELL files Local (view-scoped) reads for its own views (`shellFeedViewReads`: Settings gets
  two computed reads — preferences that differ from `PREF_DEFAULTS`, and the genie's voice/briefing state;
  refiled on `prefChanged` and at sign-in). Products must do the same for every view — see the integrate
  skill's "Genie's Read must fill BOTH scopes" rule. No product-side framework delta.
- 1.10.9/1.10.10 — reads CROSS THE FRAME BOUNDARY: an embedded child relays its reads up ({wv:"gread-up"},
  both scopes; `relayed:true` stops the host<->child echo), the host files them and routes their actions back
  down as {wv:"gread-run"}. Before this, a product's reads NEVER reached the hub band — Local was empty and
  Global showed only hub-owned reads. Hub layer composes Global as a FLEET ROSTER: exactly one read per
  product (its own relayed read once live this session, else an honest hub-derived line from relayed alarms +
  health + catalog), worst-first in coarse buckets; the hub's own two reads moved to Nightly Reports' Local pair.
- 1.10.11 — the sign-in greeting plays ONCE per user x device x language (`GREET_SEEN`, persisted `greetSeen`
  map); a language switch re-arms it once for that language (`genieGreetForLanguage` from `prefChanged`).
  Pref `greetFreq` = Once (default) | Every sign-in | Off, migrating the old `loginGreet` boolean, which stays
  as the derived master switch. Reset preferences clears the memory. The BRIEFING is unchanged — operational,
  not ceremonial, so it still runs at every sign-in. Suite `fresh_login()` clears the memory unless a check
  passes `keep_seen=True` / `freq=`. No product delta.
- 1.10.12 — `openView()` inside an EMBED no longer mounts locally: same view = no-op, other view = 
  `postUp({wv:"open-view",viewId})` for the host to open (the hub ACTIVATES an already-open instance rather
  than re-mounting). Product code that called `openView` in a frame (e.g. Genie's Read action helpers) used to
  push the product root back to the park and blank the dashboard. No product delta — but see the integrate
  skill's rule "A read's action acts ON THE OPEN DASHBOARD".
- 1.10.13/1.10.14 — rail selection = FULL-BLEED row rectangle sized against the SIDEBAR (square, 3px bar as its
  left edge; genie-ui skill carries the ruling); tabs = wash + 2px underline + mono count pill. Genie quick menu:
  right-click / long-press the lamp = Voice / Listening / Voice commands / Voice settings (no fourth idle icon).
- 1.10.15 — a read may carry `kind` (≤ 18 chars): the KIND CHIP, rendered between the tone dot and the
  headline as a mono-caps chip tinted by tone (accent / `--wv-maj` / `--wv-crit`), marked `data-wv-i18n-off`
  because a kind is PRODUCT WORDING (an operator's category label: CHARGE, AT LIMIT, WATCH, RUN HEALTH),
  never translated. Added to `norm()` and `grSerial()`, so it survives the frame relay both ways. Figures
  keep using the existing `meta` chips. Product delta: OPTIONAL — add `kind` where a short category label
  helps the reader scan the band; existing reads without it render exactly as before.
- 1.10.16 — the genie SPEAKS NATURALLY. `voiceWarm()` loads the SAPI voice during the sign-in animation
  (measured cold start: Arabic 3832 ms, English 685 ms, paid as silence at the top of the ceremony); the
  ceremonial greeting is ONE utterance, not two (a split put a 2.0 s engine gap inside the greeting); the
  inter-step gap is 90 ms (was 260, on top of ~215 ms of engine latency); `VOICE_RATE` sets rate/pitch PER
  LANGUAGE (the flat 1.02/1.05 sped up and raised every vendor voice); the 25 s briefing cap is an IDLE
  watchdog re-armed per step (a flat budget silently truncated Arabic/Japanese briefings, whose utterances
  run 6-9 s each); `whenQuiet()` waits for an unblocked main thread before each line; and the never-started
  watchdog RE-ARMS while `JANK` says the thread was blocked instead of cancelling a healthy utterance.
  No product delta — but see the integrate skill's rule "A product's main-thread cost is the HOST'S cost".
- 1.10.17 — RTL side panels. `#wv-qs`, `#wv-adrawer`, `#wv-ndrawer`, `#wv-infoDock` mirror to the LEFT under
  `html[dir="rtl"]`, carry their hairline on the right edge, slide in from the left (`wv-slidein-rtl`), and
  the Info dock's page push and resize grip flip with them. No product delta.
- 1.10.18 — login backdrop: scene 3 is "Switchyard" (substation bay elevation rising from the bottom edge),
  scene 2 became a JOURNEY (source → packet → destination arrival beat, with occasional reversal), and the
  scene ROTATES per visit (`loginBgSeq` in localStorage, never an immediate repeat; a dev-bar pick writes
  `loginBgPin` to sessionStorage and beats the rotation). Login chunk only. No product delta.
- 1.11.0 — MODE GROUP. `WV.registerModes({product,modes:[{viewId,label,icon}],label})` renders an ordered
  set of a product's views as a segmented control at the FAR RIGHT of the tab row, past the arrangement
  control, in its own inset track (zero new vertical height). Switching is IN PLACE via
  `modeGo`/`switchInstView` — never `openView`, so never a second instance; embeds relay `{wv:"mode"}` down
  and `{wv:"mode-changed"}` up. Alt+Shift+1-9 through the existing `PROD_KEYS`. Degrades labels -> icons ->
  a "Views" menu with a hard floor so tabs are never crushed; mirrors in RTL. `prodBranded()` stops the
  chrome doubling a product name that already starts with the brand. **Product delta: OPTIONAL** — declare a
  group or change nothing.
- 1.11.1 — ONE CHANNEL PER EVENT. The hub's relayed-alarm toast now honours `heraldWill(kind)` as the
  framework's own alarm/notify paths already did, so `genieHerald` (all|alarms|off) decides island-vs-toast
  and the two never both fire. A frame's BOOT SYNC (it relays its entire existing alarm list) no longer
  toasts at all — that is state, not news. `toast()` is bounded: MAX_TOASTS=3 plus one "+N more" counter
  that opens the drawer. Confirmations still toast in every mode; they have no other home.
- 1.11.2 — the mode group belongs to the TAB: it renders only while the FOCUSED view belongs to that
  product (the focused PANE in split/grid), and a chip is current only when the focused view IS that mode.
- 1.11.3/1.11.4 — mode selection owns its cell (track `padding:0;gap:0;overflow:hidden`, square chips, so
  end chips inherit the track corners) and is LIT: inset accent edges left/right plus a specular top.
  Inset only — the track clips, so an outer glow vanishes, and a full border doubles the track edge.
- 1.11.5 — FAVICON. The tab icon is generated at boot by serialising the live `#wv-mark` group and its
  gradient into a `data:image/svg+xml` URI (`wvFavicon()`), so it can never drift from the lamp on screen,
  needs no shipped asset, and works over file://. The mark's `var(--wv-mark-fill, …)` is rebound to the
  gradient explicitly — a favicon document has no CSS variables. Ends Chrome's automatic /favicon.ico 404.
  No product delta.
- 1.11.6/1.11.7 — the SEGMENTED SELECTION is ringed on all four sides, and Global/Local now matches the
  mode group. The active button covers the track's border (`margin:-1px 0`, clip removed, end buttons
  given explicit corners) and carries a full inset ring plus a specular top, so the group's outline turns
  accent exactly where the selection is. Where a control draws dividers between buttons, the divider is
  made transparent on the active button and the one after it — the ring is the edge there. No product
  delta, but see the genie-ui spec if a converted product keeps a segmented control of its own.
- 1.7.3–1.7.5 — header status/Info pods right of the genie; browser tab title = selected product
  (`renderChrome`); sign-in session `AUTH` (remember → localStorage 7d sliding, else sessionStorage
  12h; refresh resumes silently, sign-out clears). Storage keys live under `wvfw.<ns>.*`.
- 1.7.6 — Info mode: Docked panel. ⓘ split control (caret / right-click → Floating card | Docked
  panel; pref `infoDock`, QS Behavior row, palette actions); `#wv-infoDock` in the overlays chunk
  (`body[data-wv-infodock]` + `--wv-idock-w` → `#wv-main` margin, stacks inside a docked chat).
  Content contract `WV.info.describe(key, {title, plain, what, why, how, read, healthy, concerning,
  wrong, terms, related}) / describeMany / resolve` — key = selector or `data-info-key`; plain
  `data-info` facets still render (1→IN PLAIN TERMS, 2→HOW TO READ IT, 3→HOW IT IS CALCULATED,
  4→HEALTHY VS CONCERNING, 5→RELATED). Products with their own explainer registry bridge it in
  their registration block (BTM: `window.btmShell.infoFor/infoKeys` → `describeMany`, own pop
  hidden under `body[data-wv-infodock]`).
- 1.8.0 — the OATI Genie chat component replaces the built-in chat. Loader in js-app:
  `chat/genie-config.js` → `chat/genie-rag-shim.js` → `chat/oati-genie-chat-widget.js`, paths
  relative to the host file (so a spliced dashboard needs `chat/` beside it or a
  `WV_GENIE_CONFIG.bundle` override); mounts AFTER sign-in, unmounts at sign-out, never in
  embeds. `#wv-genie` drawer, `GENIE`/`GCHAT`/`GPOP`, dock/max, the `genie-*` dispatcher and
  the chat-local prefs are gone; `WV.genie.register` is a documented no-op; new
  `WV.genie.desk.*` / `WV.genie.alert` / `WV.genie.open|close|isOpen|element`. Product-side
  delta: only a product that re-bound old chat internals (the hub re-bound `genieRailHTML`)
  needs its override removed. (Dashboards were held at 1.7.6 for 1.8.0–1.8.8; the hold was lifted
  by 1.8.9 — see the table note.)
- 1.9.0 — Genie's Read scope (Global / View): `S.greadScope` session-only (never persisted; `enterApp` →
  "global", a band popout boots on "view"); `WV.genieRead.set({view})` / `.loading(product, view)` /
  `.clear(product, view)` file per-view reads in `GREAD.views[viewId]`; segmented toggle at the band's right
  edge (`.wv-gr-scope`, act `gread-scope`), view chip (`.wv-gr-ctx`), honest empty line (`.wv-gr-empty`,
  "No read for ‹View› in this run" + Show global), palette actions `act:gread-global/view`, `grCur()` feeds
  rotation / voice top-5. Popouts carry the band: `popOut()` appends `&band=1` (the hub's `embedURL`
  override must keep the framework's query intact); `bootEmbed` moves `#wv-gread` (adds `wv-root`) above
  `#wv-embedRoot` under `body.wv-embed[data-wv-band]`; parent→child `{wv:"gread", product, view, title,
  reads, viewReads}` on ready + every set/clear, child→parent `{wv:"gread-run"}`. Shell-level views pop the
  CURRENT page (`WV.embedURLFor`; hub override delegates `v.shell===true`); `popOut` refuses views without
  a renderer (toast). Notifications: `#wv-ndrawer` (overlays chunk) replaces the `notif-menu` dropdown —
  `openNotif/closeNotif/toggleNotif/renderNotif`, acts `notif-menu` (toggle) / `notif-close` /
  `notif-readall`, Esc order QS → genie → notifications → alarms, `uiBusy()` includes it, `menuNotif()`
  is a guarded alias. No product-side delta (hub: delegate shell views in its `embedURL` override).
- 1.9.4 — sign-in briefing + stop gestures. `S.loginBrief` ("read" default | "alarms" | "notifs" | "none",
  persisted, `PREF_DEFAULTS`); QS/Settings row `gbrief-set` (`.wv-qs-off` when `loginGreet===false` — the
  master switch); palette `act:brief-*`; `BRIEF_STR` intros (5 languages); `briefItems(src)` → read = first two
  GLOBAL reads of the active product (HTML stripped), alarms = top two unacked by severity then newest
  ("Critical: …"), notifs = latest two unread that pass `briefNotifMeaningful` (warn always; else not a shell
  confirmation per `BRIEF_CONFIRM_RX`); `briefRun(steps)` chains greeting → welcome → intro → item 1 → item 2
  on `genieSpeak(..., {onend})`, each item an island card (`briefCard`, click → source), `VOICE.holdUntil`
  follows the chain (cap 25 s) then `briefRelease` settles queued herald events; Voice Off plays the cards
  silently. `stopSpeaking(reason)` is the one stop; `voiceBusy()` / `voiceSyncUI()` drive
  `#wv-podGenie[data-speaking]` + the "Speaking — click to stop" tooltip + the island's `.wv-say-stop`;
  barge-in: the ear keeps listening while speaking (`EAR.pausedForSpeech` never set), `earGate(t)` admits only
  `STOP_RX` meanwhile and drops echoes (`earIsEcho`) for 1.8 s after an utterance. `voiceDetail`, `loginGreet`,
  `voiceGender` are now persisted. No product-side delta (reads' headlines feed the briefing — keep them
  speakable).
- 1.9.5 — greeting style. `S.greetStyle` ("simple" default | "timeofday", persisted, `PREF_DEFAULTS`); QS/Settings
  row `gstyle-set` (greyed with the greeting Off, like `gbrief-set`); palette `act:greet-simple|timeofday`;
  `GREET_SIMPLE[lang](name)` = the native hello word with the name the way each language attaches it
  ("Hello, Ana!", "Bonjour, Ana !", "¡Hola, Ana!", "مرحباً يا Ana!", "こんにちは、Anaさん！"); `genieLoginGreet`
  picks by style, the welcome line + briefing are unchanged. i18n keys Greeting / Simple hello / Time of day.
- 1.9.7 — shimmer → rain speed. `prefChanged` sets `--wv-rain-speed` on the root from `S.greadTwinkle`
  (`100/max(v,25)`; `data-twinkle="off"` also freezes `.wv-gb-aura` under Halo); the band's `wv-gr-rain`
  and the lamp's `wv-gb-halorain` durations multiply by it. Pure CSS/prefs — no i18n, no product delta.
- 1.8.12 — tab labels show the dashboard name: pref `tabLabel` ("product-view" | "product" | "view";
  stored null = computed default → product-view when >1 product registered, view otherwise; QS/Settings
  Behavior row + palette actions). One helper `tabLabelParts/tabLabelFor/tabLabelText` names every open
  instance (tab strip + tooltip, overflow menu, sidebar Open list + rail tips, palette Open tab, panel
  headers, Popouts menu, context-menu titles, popout notice, voice "Opening …"). No product-side delta.
- 1.8.1–1.8.8 — widget portals lifted (z 100095); identity-card "Genie voice commands" link;
  Settings fills the page (balanced columns, `settingsPack`), motion default off, ring default violet,
  identity card plain; Halo aura ≥ .88; Voice-commands panel 1240px. No product-side delta.
- 1.8.9 — Info mode reaches embedded product frames. Embed protocol: parent → child `{wv:"info", on,
  mode, pin?}` (sent on ready + every toggle / presentation change; the hub layer wraps
  `broadcastInfo()` to reach its frames — `briefFrame` sends `infoMsg()`), child → parent
  `{wv:"info-item", title, kind, sections, pinned}` / `{wv:"info-clear"}` / `{wv:"info-exit"}` (Esc inside a frame). `body.wv-embed` hides
  `#wv-infoDock` + `#wv-infoBanner`; `applyInfoDock` never opens the panel in a child but still sets
  `body[data-wv-infodock]` so products hide their own explainer under the shell dock. Chat loader
  probes `chat/` then `../chat/` (`GWID.base`). Fixes: `?` renders the shortcuts sheet before opening;
  under-filled arrangements collapse to the visible panel count (`#wv-panels[data-n]`); `settingsPack`
  keeps the template sequence across re-packs (`data-wv-seq`); voice grammar accepts the documented
  fr/es "Ouvre les alarmes" / "Abre las alarmas" and es "notificaciones". **Product-side deltas
  applied:** ftm + ev Info bridges (`WV.info.resolve` over the product's `infoEntry(el)`; own
  `.info-card` hidden under `body[data-wv-infodock]`); a product with its own explainer registry
  should bridge the same way so the hub's panel can render it.
