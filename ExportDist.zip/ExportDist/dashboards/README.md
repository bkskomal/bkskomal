This folder is intentionally empty.

Put a RAW single-file dashboard here, then ask Claude to integrate it (see ../context/START-HERE.md).
Converted outputs are written here as *_wv<ver>.html and are discovered automatically by tools/splice_shell.py and tools/verify_shell.py.
