# webVision Framework — Product Integration Spec (v1)

The contract between the Genie/webVision shell framework and product applications.
Applies to: `GenieApplicationShell.html` (the deliverable for product teams), the five
converted products, and the multi-product hub. 2026-08-19.

## 1. Architecture

- **Converted product** = the product's own single HTML file with the **namespaced shell
  layer injected** and the product's own chrome removed. The product's content code
  (views, engines, data, CSS) stays essentially unchanged and owns the view containers;
  the shell owns everything else (header, nav, palette, tabs, panels, alarms, drawers,
  theming, popouts, workspaces, Info mode).
- **View granularity is coarse**: one shell catalog view = one existing product page /
  mode / top-level tab. Per-panel registration is a later enhancement.
- **Hub** = one shell instance whose catalog spans all products; product views render in
  sandbox-free iframes of the converted product files using the embed protocol (§5).

## 2. Namespacing rules (framework build only — the demo `webvision-shell.html` keeps its names)

- Every shell CSS class gets the `wv-` prefix (`.panel` → `.wv-panel`); every shell
  element id gets a `wv-` prefix (`#hdr` → `#wv-hdr`); every shell CSS custom property
  gets `--wv-` (`--acc` → `--wv-acc`). Mechanical, script-driven, applied uniformly
  across CSS, HTML, and JS template literals/selectors.
- Shell CSS contains **no bare element selectors** that can reach product content.
  Shell element-level styling is scoped under shell chrome roots
  (`#wv-shell`, `.wv-drop`, `.wv-modal`, …). The one exception: `html`/`body` rules
  guarded as `html[data-wv-root]` — converted products hand the page root to the shell.
- Shell chrome controls are **defensively self-styled**: every property a hostile
  product reset could touch (background, border, font, color, cursor on
  buttons/inputs/tables) is set explicitly by shell rules, so product globals like
  `button{background:none}` cannot deface shell chrome.
- The shell's overlay z-band in converted files is **100000+**. Product overlays keep
  their existing z-indexes (all observed products stay under 10000).

## 3. Product Integration API (global `WV` in the framework)

```js
WV.registerProduct({ id, name, suffix, accent,            // accent: CSS color for the product token
                     systems: [{id, name}] })              // dependent systems for the health chip
WV.registerViews([{ id, name, product, path: ["Group","Sub"], // catalog entry
                    type,                                   // Dashboard|Data Grid|Map|Chart|Console|Wizard|Report|Form|Admin
                    openMode,                               // "inline" | "popout"
                    keywords }])                            // extra palette search terms
WV.registerRenderer(viewIdOrStar, {
  mount(el, ctx),        // REQUIRED. Render the view into el. Must be re-entrant.
  unmount(el, ctx),      // release timers/observers/maps owned by this mount
  onTheme(theme, ctx),   // shell theme changed — rebuild canvas/chart colors here
  onResize(ctx),         // panel geometry changed (arrangement, maximize, sidebar)
  onTime(hour, ctx),     // shared time-context tick (only if the view subscribes)
  onVisibility(v, ctx)   // panel hidden/shown without unmount (tab switches)
})
// ctx: { uid, viewId, inst, product, el, theme(), density(), hour() }
WV.registerActions([{ id, name, keywords,  // command-palette actions — the Ctrl+K "Actions" band
                      icon,                // a wv-i-* / wv-t-* symbol name (default "bolt")
                      hint,                // () => string — current state, right-aligned in the row
                      run,                 // REQUIRED. Executes on Enter/click; the palette closes first
                      product }])          // optional; defaults to the registering product (rows carry its chip)
WV.genieRead.set({ headline, summary,      // Genie's Read — the per-product AI-insights band
                   tone,                   //   optional severity of the read: "info" (violet, default)
                                           //   | "watch" (amber) | "crit" (red). Colors the collapsed
                                           //   row's severity dot, particle texture and cta link, and
                                           //   the expanded briefing accents; band family stays violet
                   cta: { label, run },    //   optional inline accent action link on the collapsed row
                                           //   (" · confirm in 3h" style) — runs without toggling the row
                   insights: [{ text,      //   between the tab strip and the panels; only <b>
                                tone,      //   optional per-insight tone — tints that card's icon chip
                                act: { label, run } }],  //   emphasis is honored in supplied text;
                   meta,                   //   meta: string | string[] — muted mono as-of chips
                   product,                //   optional; defaults to the active/registering product
                   view })                 //   optional (1.9.0): file the reads for ONE view id — the band's
                                           //   Global / Local toggle shows them for the focused tab (and in
                                           //   that view's popout); without it the reads stay product-level
WV.genieRead.loading(product?, view?)      // reading state (label + twinkling field), product- or view-level
WV.genieRead.clear(product?, view?)        // remove the product's read (or one view's) — the band hides entirely
WV.embedURLFor(viewId, inst?)              // 1.9.0: the framework's popout-URL rule (this page's file + #wv-embed…);
                                           //   a hub that overrides embedURL delegates shell-level views to it
WV.genie.register(provider)                // Genie assistant brains (chat: GENIE AI chip / Ctrl+G / palette).
                                           //   provider = async (message, ctx) => string
                                           //     | { text, actions: [{label, run}] }   // buttons under the bubble
                                           //     | null                                // DEFER to the built-in
                                           //   framework demo responder (grounded in live shell state).
                                           //   ctx: { viewId, viewName, product, hour, attachments }
                                           //   ctx.attachments: [{name, size, type}] — metadata of the files
                                           //   attached in the composer for THIS message (contents are never
                                           //   read); [] when nothing was attached
WV.toast(msg, kind)                        // shell notification (toast only)
WV.notify(msg, kind)                       // kind: info|ok|warn — LOW-KEY framework event: toast + the
                                           // header notification center (persistent, ≠ alarms)
WV.raiseAlarm(sev, msg, source, viewId)    // sev: crit|maj|minr|info
WV.setSystemState(systemId, state)         // state: live|degraded|stale — drives health chip
WV.time.subscribe(viewId)                  // opt the view into the shared time bus
WV.start({ product, startupWs })           // boot the shell after registration
```

Lifecycle guarantees the shell makes to renderers:
- `mount` is called with a sized, visible container (products with Leaflet/ECharts need
  this); after arrangement/maximize/scale changes the shell calls `onResize`.
- `onTheme` fires after the token swap is applied, so `getComputedStyle` reads new values.
- The shell never innerHTML-rebuilds a mounted view container on focus changes.

## 4. Conversion rules (per product)

1. **Remove**: product topbar/header, nav (tabs/sidebar/mode bar), theme toggle, clock,
   its own Info-mode toggles, settings/config modals that the shell replaces, toast
   containers. **Keep** product-semantic toolbars (site/ticket/filter bars) inside views.
2. **Re-root state classes**: everything the product toggled on `<body>`/`<html>`
   (theme, mode, solo, info) moves to the product's content root element. The shell owns
   the page root. Product `body{overflow:hidden;…}` rules move to the content root.
3. **Theme bridge**: product theme code no longer toggles anything itself; it implements
   `onTheme` by calling its existing rebuild path (`rebuildAll` / `_themeRefresh` /
   `render`). Product light/dark selectors are rewritten to key off the root element's
   `data-theme` (one mechanical substitution).
4. **Hotkey scoping**: product `document`-level keydown handlers run only when the event
   target is inside the product root AND the shell reports no overlay open
   (`WV.uiBusy()`), and never capture Ctrl+K / Ctrl+B / Ctrl+, / Esc / Alt+digits.
5. **Timers**: long-running product intervals (simulation ticks, playback) are gated by
   `onVisibility`/`unmount` where cheap to do; otherwise left running (documented).
6. **Storage**: product localStorage keys get a product prefix if they are generic
   (`ftmMode` → kept, already unique; generic keys like `workspace` must be prefixed).
7. **Functionality-preservation is the acceptance bar**: every product view must behave
   as it did standalone. Each conversion ships with its own E2E additions + screenshots.

## 5. Embed protocol (hub + popouts)

- URL hash `#wv-embed=<viewId>` (optionally `&inst=<n>&theme=<t>&density=<d>`):
  the converted product boots **chromeless** — no shell chrome, no product chrome —
  mounts only that view full-bleed, and posts `{wv:"ready", viewId}` to `window.parent`
  (and `window.opener`).
- Parent → child messages (postMessage, targetOrigin `"*"` — file:// origins are opaque):
  `{wv:"theme", theme, density, scale, accent}` · `{wv:"time", hour}` · `{wv:"prefs", …snapshot}` ·
  `{wv:"info", on, mode:"float"|"dock", pin?}` (1.8.9 — the parent's Info mode: the child turns its
  own Info mode on/off; `float` → the child shows its own card; `dock` → the child never opens a
  dock and feeds the parent's panel instead; `pin:false` releases the child's pinned component).
  The parent sends theme, prefs and info on `{wv:"ready"}` and re-broadcasts each on change.
- Child → parent: `{wv:"ready", viewId}` · `{wv:"alarm", sev, msg, source}` ·
  `{wv:"system", id, state}` · `{wv:"info-item", title, kind, sections:{plain, what, why, how, read,
  healthy, concerning, health, wrong, terms, related}, pinned}` (hover = unpinned, click = pinned;
  rendered in the parent's docked panel exactly like a local entry) · `{wv:"info-clear"}` (the
  pointer left the frame with nothing pinned) · `{wv:"info-exit"}` (Esc pressed inside the frame — the
  parent leaves Info mode everywhere).
- The hub's popouts `window.open` the same embed URL — real multi-monitor windows for free.
- **1.9.0 — read band in popouts**: `popOut()` appends `&band=1` to the embed URL. With `band=1` the child
  boots with the SAME `#wv-gread` band above the view (`body.wv-embed[data-wv-band]`, `EMB.band`),
  scope "view" for the popped view (toggle available). Hub product FRAMES never carry `band` and stay
  chromeless. Parent → child `{wv:"gread", product, view, title, reads, viewReads}` on ready and on every
  `WV.genieRead.set/clear` (cta / insight actions travel as `{label, remote:true}`); child → parent
  `{wv:"gread-run", scope, product, view, ix, ins}` runs the action where its function lives.
  A `shell:true` view (or `wv:settings`) always pops the CURRENT page (`WV.embedURLFor`), never a product
  file; `popOut` refuses (toast) a view with no renderer instead of opening an "Unknown view" window.

## 6. Deliverables recap

1. `GenieApplicationShell.html` — namespaced shell + `WV` API + one sample product
   (a handful of starter views incl. the three content states) + a built-in
   **Framework Guide** view documenting this spec from inside the shell.
2. Five converted products (in place, per §4), each single-file, each also honoring §5.
3. `webVisionHub.html` — the multi-product shell over the five converted files (§1, §5).

---

## 7. Sentinel & versioning contract (v1.1 — canonical home E:\AI\Self\Genie, 2026-08-27)

This directory is now the canonical home of the framework. `GenieApplicationShell.html`
here is the living release; `E:\AI\Self\WVShellV1\` is history (stage-2 conversions with
the 1.0.x shell and their verification records).

### Sentinels

Every shell-owned chunk in `GenieApplicationShell.html` — and in every converted
product — is wrapped in exact HTML-comment sentinels:

```
<!-- WV-SHELL:BEGIN <name> --> … <!-- WV-SHELL:END <name> -->
```

The nine chunk names, in document order:
`fonts` `css` `symbols` `login` `app` `overlays` `js-core` `js-render` `js-app`

The framework's sample-product script is wrapped as
`<!-- WV-PRODUCT:BEGIN registration … --> … <!-- WV-PRODUCT:END registration -->`;
a converted product REPLACES that block's contents with its own registration and keeps
the same product sentinels. All product CSS/markup/JS lives outside the shell sentinels.

Rules:
- Sentinel lines are byte-exact and never edited, translated, or re-indented.
- Integration copies the sentinels into the converted file; updates extract each chunk
  from the framework by sentinel and splice it over the converted file's same-named
  range. Product bytes are never touched by an update splice.
- A converted file's `<head>` keeps its own `<title>` and meta before the `fonts` chunk.

### Version stamp

`<head>` carries `<meta name="wv-shell-version" content="<semver> <date>">` — the single
source of truth for what shell a file embeds. The update skill compares this stamp
between the framework and each converted file and reports from→to per file.

### Skills

- `genie-shell-integrate` — converts a raw dashboard into a shell-integrated product
  per §2–§5 of this spec, the registry, and the sentinel contract.
- `genie-shell-update` — propagates the current framework chunks into already-converted
  products, applies any contract deltas listed in `WV-PRODUCT-UPDATES.md`, re-verifies.

### 1.1.1 product-contract additions (2026-08-28)

- **Single info mode**: the shell header ⓘ is the only info toggle. `toggleInfo` emits a
  document `CustomEvent "wv:info"` (`detail.on`); products drive their own info system
  from it and hide their own toggle. Product roots carry `data-wv-product-root` — the
  shell's info-mode click-capture passes clicks inside such roots through, so the
  product's own explainer answers for its content while shell cards answer for chrome.
- **Appearance follow**: products mirror the shell ground by copying computed `--wv-bg0`
  onto their ground token on every `wv:prefs`, and mirror a PINNED accent (present when
  `html[data-accent]` is set) by copying computed `--wv-acc` onto their accent token
  (auto mode = product native hue). Rebuild charts only when the look signature changes.
- **Product i18n**: `WV.i18n.register({"English label":[fr,es,ar,ja]})` merges product
  UI strings into the shell's translation engine (exact-key matching keeps numbers,
  units, names and unregistered domain text untouched); `[data-wv-i18n-off]` exempts a
  subtree. The engine's MutationObserver re-applies after product re-renders.
