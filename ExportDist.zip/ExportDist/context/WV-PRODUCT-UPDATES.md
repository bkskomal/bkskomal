# Product update backlog (framework → products) — Genie era

Canonical home: `E:\AI\Self\Genie\`. Changes land in `GenieApplicationShell.html` first;
converted products in `dashboards\` receive them in consolidated rounds via the
`genie-shell-update` skill. Verification bar per round: per-product Playwright suite
green + strict zero-console-error gate + screenshots.

History: rounds delivered against the 1.0.x shell (five products + hub) are recorded in
`E:\AI\Self\WVShellV1\WV-PRODUCT-UPDATES.md` (Round 1 complete 2026-08-20; the Round-2
queue there is SUPERSEDED — everything in it is already inside the 1.1.0 framework).

## Framework 1.1.0 (2026-08-27) — the baseline for all new integrations

Everything since the 1.0.6 snapshot, now in the shell every integration inherits:
premium header capsules · Living Lamp (Halo/Lamp/Comet, flame colours, size, ring)
· Genie's Read (per-dot twinkle, pager, rotation, dot colour) · the Herald (island
delivery, severity keys, queue re-carry, toast suppression) · full i18n
(en-US/fr-CA/es-MX/ar RTL/ja, pattern engine, language-rescue row with English anchor,
English-aware settings filter) · Voice Mode (announce/full detail, localized announce
phrases, critical-alarm exception, greeting) · Genie Listening (mic on ring, commands,
polite no-match retry, island replies, "no alarms — all clear") · alarm-burst
summarizer + `WV.genie.registerSummarizer` seam · login variation D (DER Registry,
OATI logo, prefilled GenieUser) · resizable sidebar + Solid Accent Key rail ·
sentinel + version-stamp contract (spec §7).

## Contract deltas an updater must know (1.0.x → 1.1.0)

- Sentinels are new: a 1.0.x-converted file has none. First update to such a file is a
  RE-INTEGRATION (extract its product layer, reassemble on the 1.1.0 chunks), not a splice.
- `WV.genie.registerSummarizer(fn)` and `WV.genie.registerCommand` exist as product seams.
- Storage keys added by the shell: voiceDetail, genieChatIcon, genieRing, greadDots,
  greadTwinkle, alarmSumm (products must not collide).
- The startup demo alarm and the sign-in notification are gone by design.

## Integrations delivered on 1.1.0

### ftm — GridLine FTM Optimizer (2026-08-27)

- File: `dashboards\ftm_optimization_dashboard_wv1.1.html` (raw source
  `dashboards\ftm_optimization_dashboard_v0.1.html` untouched); embedded shell stamp
  `1.1.0 2026-08-27` (verified in-page post-assembly).
- Views registered: `ftm.monitor` · `ftm.forecast` · `ftm.analyze` · `ftm.all`
  (singleton mount of `#ftm-root`, `applyMode(<Mode>)` recipes) + `ftm.guide`
  (the v0.1 generated User Guide as a Report view in a panel-scoped iframe; the
  product's own help button still opens it in its own tab).
- Verification: Playwright (channel=chrome) suite **18/18 green, 0 pageerror /
  0 console-error (strict whole-run gate)** — login→shell, all 5 views with real
  content markers, playback interaction, palette open path, singleton replace,
  relocated utility cluster + product alarm list, theme round-trip dark→light→dark
  through the onTheme bridge, `#wv-embed=ftm.forecast` chromeless boot posting
  `{wv:"ready"}` from a same-origin iframe parent. Screenshots: monitor/forecast/
  analyze/all/guide dark + monitor light + embed (session scratchpad).
- Conversion notes an updater must know:
  - Product global functions renamed to avoid shadowing shell globals (both are
    top-level classic scripts): `toast→ftmToast` (routes to WV.toast),
    `renderGenieRead→ftmRenderGenieRead`, `renderAlarms→ftmRenderAlarms`,
    `swapPanels→ftmSwapPanels`, `lineChart→ftmLineChart`, `popOut→ftmPopOutMode`.
  - Product-functional topbar controls (alarms bell+list, system-health pop,
    keyboard-shortcuts sheet, help/guide button, Info-mode group) were RELOCATED
    into a `.ftm-utils` cluster in the filter bar (product-semantic toolbar), not
    removed; brand/clock/user/theme/logout/mode-seg/config+workspace cogs removed
    or hidden (`.flt-mode{display:none}` — superseded by shell nav/workspaces).
  - Per-panel popout now rides the embed protocol:
    `#wv-embed=<view>&ftm-panel=<cardId>` (renderer applies the product's
    panel-solo state); the old `#panel=`/`#mode=` hash boots are removed.
  - Left running (documented per §4.5): Genie-Read rotation (10s), market-timeline
    tick (1s), alarm-bell + health pulses (sub-second class toggles) — all cheap
    DOM writes, safe while parked. Playback timer IS gated (pause() on unmount).
  - localStorage keys were already product-prefixed (ftmMode/ftmWorkspaces/
    ftmDispatchLog) — no changes.
  - 2026-08-27 follow-up (user request): the product's IN-PAGE Genie's Read strip
    (`#genieRead`) is now hidden (`#ftm-root .genie-read{display:none!important}`),
    its 10s rotation timer no longer starts, and its six rotating optimizer reads
    feed the SHELL band's pager instead — `ftmFeedRead` sends
    `WV.genieRead.set({product,reads:[primary, …buildReads() mapped]})` with tones
    `--bad→crit / --warn→watch / else info` and HTML entities decoded (the band
    honors `<b>` only). ONE Genie's Read surface per product is the standing rule
    for integrations; BTM already complied.
  - 2026-08-27 follow-up (user report — Live Operational Status card clipped):
    `syncChrome()` now sets `--topbar-h:0px` when no product topbar exists (the old
    62px fallback pushed the sticky rail down) and computes `--sb-maxh` from the
    PANEL scroller's clientHeight (the `.sidebar` max-height was keyed to `100vh`,
    which ignores shell header/tab strip/read band/status bar). Verified stuck-state:
    8px top gap, whole card visible with 25px bottom room. General rule: product
    layout heights keyed to `100vh` or its own topbar must be re-derived from the
    panel scroll container.
  - 2026-08-27 shell-prefs bridge (skill step 3, required): registration block now
    has `applyShellPrefs(p)` wired to the `wv:prefs` document event + applied once
    at first mount from `WV.prefs()`. What follows each setting:
    - **UI scale × Font size** → CSS `zoom` on `#ftm-root` = `p.scale*p.fontScale`
      (NaN-guarded → 1; product content is px-locked so the two prefs combine
      there), then the full resize path re-runs. `syncChrome()` divides its
      `--sb-maxh` panel-scroller measurement by the root's computed zoom (scroller
      px are outer, sidebar px are zoomed) — verified stuck-state at 125%×110%
      (=1.375): sidebar height 713.6px inside a 726px frame, no clip; charts
      re-measure to their containers.
    - **Density** → `data-wv-density` on the root; a bridge `<style>` block inside
      the WV-PRODUCT sentinels maps `comfortable` onto the product's own tokens
      (`--gap` 14→20px, `--pad` 16→20px, `.card-b` padding 8/12→12/16, `.kpi`
      padding/min-height bumped); `compact` = native look. `syncChrome()`/
      `syncMonitorHeight()` now read the LIVE `--gap` instead of hardcoded 14 so
      the height arithmetic stays honest under comfortable.
    - **Reduce motion** → `data-wv-motion` on the root; bridge CSS disables all
      `#ftm-root` animations/transitions (mirrors the product's own
      prefers-reduced-motion blanket) AND the product's JS pulse loops
      (`startBellPulse`, `startHealthPulse`) hold steady while it is set — the
      product's living "pulses" are those class-toggle loops + transitions (the
      `.dot{animation:pulse}` rule is dead CSS from the removed topbar chip).
    - **Regional** → the central stamp helpers render via WV.fmt: `stampNow()`
      (tooltip "Computed at" stamps), `stampAt()` (hour-ending export stamps) and
      the market-timeline clock (`#mkNow`) use `WV.fmt.date/time/tz` with a
      `ftmTzShort()` short-label derivation, standalone fallback preserved —
      Time zone, Date format and 12/24-hour prefs all show in product content;
      `applyShellPrefs` re-runs `renderMarket()` so the visible clock updates live.
    - Deliberately NOT bridged: **Number format** — the product has no central
      number-grouping formatter (its figures are domain-styled: `$` +
      `toLocaleString` currency, fixed-decimal MW/MWh with sign conventions) and
      stays as designed per the skill. Market-event schedule MATH (gate times,
      countdowns) stays on the browser wall clock by design — it drives urgency
      states, not display formatting; only the stamp RENDERING follows prefs.
    - Verified: Playwright prefs suite **18/18 green, 0 pageerror (strict
      whole-run gate)** — zoom 1.375 + sidebar no-clip + chart re-measure + back
      to 1; comfortable/compact round-trip on computed `--gap`/padding; reduced
      motion stops bell+health pulses and zeroes transitions, auto restores;
      24↔12-hour, EPT↔PPT and `YYYY-MM-DD` all change `stampNow`/`stampAt`/clock
      output, defaults restore; theme round-trip still green. Screenshots
      (125%×110% zoom, comfortable density) in the session scratchpad.

### btm — DER Availability · BTM SOC (2026-08-27)

- File: `dashboards\btm_soc_forecast_dashboard_wv1.1.html` (raw source
  `dashboards\btm_soc_forecast_dashboard_v0.1.html` untouched); embedded shell stamp
  `1.1.0 2026-08-27` (copied with the chunks, asserted post-assembly).
- Views registered: `btm.monitor` · `btm.fleet` · `btm.energy` · `btm.accuracy` ·
  `btm.all` (singleton mount of `#btm-root`, `applyMode(<Mode>)` recipes) +
  `btm.guide` (the v0.1 generated User Guide as a Report view in a panel-scoped
  blob-URL iframe; "Open User Guide in a new tab" palette action keeps the original
  own-window behavior). Accent `#6ba6e8` (its `--fc`/dark `--chart-6`).
- Verification: Playwright (channel=chrome) suite **29/29 green, 0 pageerror /
  0 console-error (strict whole-run gate)** — login→shell, all 6 views with real
  content markers (KPIs, SOC canvas, Leaflet fleet map + attention rows, energy/
  accuracy canvases + driver matrix, 13 cards in All, guide document), singleton
  replace toast, theme round-trip dark→light→dark through the onTheme bridge
  (basemap follows the theme), `#wv-embed=btm.fleet` chromeless boot posting
  `{wv:"ready"}` to a same-origin iframe parent, alarm/system/genie-read bridges
  live. Screenshots: monitor/fleet/energy/accuracy/all/guide dark + monitor light +
  embed (session scratchpad).
- Conversion notes an updater must know:
  - Entire product JS (62 script blocks incl. the base64 guide figures) is
    concatenated into ONE IIFE — no product globals leak; `window.btmShell` +
    `window.btmApplyTheme` + `window.btmViewIdOfMode` are the only seams the
    registration block uses. Head keeps the vendored ECharts/Leaflet + CONFIG/SAMPLE
    scripts as classic globals (no shell collisions).
  - Removed & bridged (the build's own `syncChrome()` classifies all three as
    chrome): topbar (brand/clock/user/theme/logout/alarm bell/health) — alarms →
    `WV.raiseAlarm`, health → `WV.setSystemState` (6 services from
    `healthServices()`); the in-page Genie's-Read strip → `WV.genieRead.set({reads})`
    pager fed from its six computed reads, re-fed (silent, 400ms-throttled) on every
    product re-render. Keys/Help/Info-mode buttons RELOCATED into the filter row.
  - Mode switcher + Modes config modal + product workspace menu hidden
    (`.flt-mode{display:none}`), wiring intact — shell nav/workspaces supersede.
  - Popouts ride the embed protocol: `#wv-embed=btm.<slug>` (mode menu) and
    `#wv-embed=btm.all&panel=<cardId>` (per-panel; mount re-runs `applyPanelHash`).
  - Product hotkeys scoped per §4.4 (btmOutside/btmReservedKey/WV.uiBusy); a keydown
    targeting `<body>` counts as in-scope while the singleton is visible, else the
    unfocused-page keys would never fire. Shift+A (alarm panel) and Shift+T (theme)
    now no-op — those surfaces are the shell's.
  - RAW-FILE FIX carried in assembly: the v0.1 filter bar has two stray `</div>`s
    (parser-dropped at body level; inside the park wrapper they closed `#btm-root`).
    Any re-integration from the raw file must repeat this fix.
  - Theme selectors keyed to `html[data-theme]` (shell-owned) instead of the product
    root — the build re-homes overlays to `<body>` (fullscreen lift, infopop, chart
    popovers, drag ghosts), so root-scoped tokens would strand them.
  - Left running (documented per §4.5): syncOptionTicks (700ms), clampCCPop (250ms),
    detitleMap (1.5s) — cheap DOM maintenance, safe while parked; the topbar clock
    interval is gone with the clock. Vendor note: the tree-shaken ECharts tooltip
    carries z-index 9999999 (vendor bytes, untouched) — hover-transient only.
  - localStorage keys already product-prefixed (btmMode/btmWorkspaces/btmGuideTheme)
    — no changes.
- **Shell-prefs bridge added (2026-08-27)** — Display + Regional settings now reflect
  in product CONTENT per skill step 3 (`applyShellPrefs(p)` in the registration block,
  listening on `wv:prefs` + attributes-only apply at first mount):
  - **UI scale × Font size** → ONE `zoom` on `#btm-root` (`p.scale * p.fontScale`,
    NaN-guarded, ×1000-rounded; product content is px-locked so the two combine
    there). After apply: `paintContext()` + `renderAll()`, then a 60ms-deferred
    re-measure — every ECharts `resize()`, `MAP.inst.invalidateSize()` (the Leaflet
    fleet map re-reads its zoomed container or the tile grid breaks),
    `relayoutMode()` + `syncFilterBar()` + `syncChrome()`. Note Leaflet reports
    LAYOUT px while `getBoundingClientRect` returns visual px (× zoom) — divide by
    the effective zoom when comparing.
  - **Density** → `data-wv-density` on `#btm-root`; comfortable bumps the product's
    own tokens: `--gap` 14→20px (grid12/#modeGrid), card padding 14/16→18/20px, and
    the page band rhythm 10→14px gap / bumped padding — the product tightens `.page`
    with `!important` (its "#3 band rhythm" fix), so the comfortable override carries
    the same weight and preserves `--page-pad-r` (docked alarm/info rails). compact
    = native look, zero delta.
  - **Reduce motion** → `data-wv-motion`; `[data-wv-motion="reduced"]` parks every
    product animation/transition incl. `::before/::after` (marker pulses, bell
    shakes, running badges, card hover fades).
  - **Regional formats** → the product's central stamp helpers now route through the
    shell's ONE formatting service: `ct()`/`ctd()` via `WV.fmt.time`/`WV.fmt.date`
    (seconds trimmed — product stamps are minute-grained; `fCT`/`fCTd` remain the
    standalone fallback), plus new seams `tzL()` (pref tz label via
    `WV.prefs().tzLabel`) and `tzZone()` (via `WV.fmt.tz`). All 25 hardcoded
    `" CT"` label sites swept to `tzL()` (tooltips, run stamps, reads, export
    meta/PDF headers, pagehead); `tzL`+`paintContext` added to the `window.btmShell`
    seam. Time zone, Date format and 12/24-hour prefs all show live in
    product-rendered stamps (e.g. `latest run 21:00 EPT` ↔ `09:00 PM EPT` ↔
    `01:00 AM UTC`).
  - **Deliberately NOT routed**: numbers. The product has no central grouping
    formatter — every figure is domain-styled with fixed decimals and units
    (`n1/n2/pct/pp`: SOC %, MWh/kW, pts, durations) — so `WV.fmt.number` is not
    wired and those figures stay as designed. The guide iframe (`btm.guide`) is an
    independent document and does not inherit zoom/density/motion.
  - Verification: Playwright suite **20/20 green, STRICT zero pageerror whole-run**
    — zoom 1.375 (125×110) asserted on the root + fleet map non-degenerate with
    `invalidateSize` confirmed (map size == container layout size, tiles loaded),
    comfortable/compact computed-style round-trip, reduced-motion parks the card
    transition and restores, 24↔12-hour + EPT↔UTC stamp changes, theme round-trip
    intact. Screenshots: zoom125 monitor + fleet, comfortable monitor (session
    scratchpad).

## Pending propagation

- Nothing pending. **The 1.8.0 hold is lifted (1.8.9, 2026-08-29):** the five dashboards were held at
  1.7.6 for rounds 1.8.0–1.8.8 (built-in chat, md5-identical); 1.8.9 needed them on the current
  framework (Info mode in product frames), so the chat loader was first made path-resilient — it
  probes `chat/` beside the host file, then `../chat/` (the config load is the probe; the graceful
  "Genie chat component not found" toast stays when neither exists) — and `tools\splice_shell.py`
  ran for all six targets (1.7.6 → 1.8.9 / 1.8.8 → 1.8.9). No copy/junction of `chat\` and no
  `WV_GENIE_CONFIG.bundle` override is needed: `dashboards\x.html` resolves `../chat/`. Product-side
  deltas of the round: ftm + ev Info bridges (see the 1.8.9 record).

## Round 1.1.1 delivered (2026-08-28) — first genie-shell-update splice round

Framework `1.1.1 2026-08-28`: `wv:info` event + `[data-wv-product-root]` info
pass-through; `WV.i18n.register` product-translation seam (spec §"1.1.1 additions").
Both converted dashboards spliced (9 chunks each, backups `*.pre-1.1.1.html`, dry-run
sentinel assertion before write) and given the round's product-side deltas:
- **Single info mode**: product roots marked `data-wv-product-root`; product `#infoGrp`
  hidden; `wv:info` drives ftm `setInfoMode(on)` / btm `#infoToggle` (aria-pressed
  compared before click). Verified both: shell ⓘ on → product info mode on, off → off,
  own buttons hidden, zero errors.
- **Appearance bridge** (extends the shell-prefs bridge): computed `--wv-bg0` → product
  `--background` (ftm at `#ftm-root`; btm at `documentElement` — its Layer-1 tokens are
  keyed to `html[data-theme]`); PINNED accent → product `--ring` (auto = native hue);
  look-signature-guarded product theme rebuild. Verified both: Background "midnight"
  reaches product grounds (#000000), pinned cyan → product `--ring` #00ccff, auto
  restores native, zero errors.
- **Product i18n dictionaries**: per-product entries appended below by their agents.

### btm — product-content translation (2026-08-27)

- **BTM_I18N: 370 exact-match keys** registered through the 1.1.1 seam
  (`WV.i18n.register(BTM_I18N)`, guarded by `typeof WV.i18n==="object"`, inside the
  registration IIFE just before the Genie's Read bridge), grouped by surface with
  comments: views/nav/palette actions + registered system names · filter bar &
  relocated utility tips (config cog, layouts caret, keys, help, info, export) ·
  section headings + descriptions · all card titles in BOTH cases (markup sentence
  case + `PANELS` Title Case — `applyLabels` paints the registry form) · six KPI
  tiles incl. note lines and the `typically within`/`of actual` split-fragment
  sub-lines · forecast-card controls (History/Horizon/CI band/Quantiles/run-strip
  label/Last 6/Clear/Reset zoom) · fleet map (basemaps, layer chips, zoom tips,
  vector-fallback note, Leaflet site-popup row labels) · attention rail (All/
  Attention only, WATCH/INVESTIGATE badges, thresholds empty state) · energy-flow
  legends + unit-suffix readouts ("kW net", "% self-supplied", "pp average miss",
  "% cloud" — unit symbol kept) · chart-hover row labels (lowercase `actual`/
  `forecast`/`charge`/`tariff`… so ECharts DOM tooltips translate consistently) ·
  driver matrix headers/groups/driver names · Risk & Opportunity row titles + the
  four static descriptions · run-health tiles · every loading/empty state ·
  export dialog (+ per-format hints) · keyboard-shortcut sheet · panel kebab menu +
  Maximise/Restore titles · configuration modal, workspaces menus, save-as dialog ·
  info-mode chrome (menu, pin controls, popover section skeleton) · Genie's Read
  kinds (ACTION…HEADROOM) + insight meta labels + `forecast model · live/paused`.
- **Excluded, never registered**: numbers & units (%, kW, kWh, MWh, pp, W/m², h),
  resource/zone IDs (`ZONE-NE-3_SELF_CONSUMPTION`…), city/site names, domain
  keywords & acronyms (SOC, p10–p90 band names & quantile chips, TOU, DER, CT,
  MAE, MAPE, KPI, XLSX/CSV/PDF/JSON as format chips), product/brand names
  ("DER Availability — BTM SOC", Genie BTM), and every dynamic value.
- **Skipped (dynamic number-embedding — exact-match keys only, never mistranslate)**:
  `runstat` composite (only the static `latest run` fragment is keyed), "N / M
  selected" resource summary, `N of M` attention badge, attention-row flag lines &
  score data-tips, map legend SOC thresholds (config-derived numbers), the two
  config-derived risk descriptions + "one-in-ten…" line, alarm-rule sentences (also
  bridged into the shell drawer as composed name+detail strings), Genie's Read
  sentence texts (labels around them ARE translated), guide FAQ/scenario prose,
  multiline `data-tip`s (subject-scope hint, save-as paragraph), and the fleet
  scope chip's counted tip. Long-form info-mode prose (INFO/DRIVER_INFO paragraphs)
  stays English by design — the popover's section skeleton (What it is / Why it
  matters / Healthy vs concerning …) is translated.
- **Out of scope, documented**: canvas-drawn ECharts internals (axis names, NOW /
  target markline labels, tick text) are painted pixels, not DOM — untouched by the
  engine; the `btm.guide` view is an independent iframe document and does not
  inherit the shell engine.
- **Arabic decision**: `ar` flips the page RTL (`dir` on `<html>` cascades). Shell
  chrome mirrors cleanly and stays RTL, but the product plate's mono data
  composites bidi-scrambled into misreadings ("1 of 6" → "of 6 1", the count in
  "9 of 10 devices reporting" detached to line end) even though the flex layout
  held (no overflow, map intact). **Pinned `#btm-root{direction:ltr}`** in the
  registration style block as the documented choice: numeric readouts keep their
  authored order, Arabic label runs still render correctly inside the LTR plate.
  No real text-node collisions were found (no mono data readout's exact text equals
  a registered key), so no `data-wv-i18n-off` markers were needed.
- Verification: Playwright (channel=chrome) **43/43 green, STRICT zero pageerror
  whole-run** — ja: 19+ distinct exact-string label assertions across cards, KPIs,
  matrix headers, dialogs, menus, risk rows, run-health, data-tips; numbers, run
  stamp, `p10–p90` CI summary, resource IDs and dynamic EN composites asserted
  byte-unchanged; fleet map renders under ja (749×678, 6 markers) and survives a
  full `paintContext()+renderAll()` repaint with translations intact; fr-CA + ar
  spot checks (ar: `html dir=rtl`, root computed `direction:ltr`, no overflow);
  en-US restore asserted exact against captured baselines; theme round-trip clean.
  Screenshots: `btm_ja_monitor.png`, `btm_ar_fleet.png` (session scratchpad).

### ftm — product i18n dictionary (2026-08-28)

- **Registered**: `FTM_I18N` (287 keys) + `WV.i18n.register(FTM_I18N)` (guarded by
  `typeof WV.i18n==="object"`) appended as section 8 of the ftm registration IIFE
  (between the WV-PRODUCT sentinels). Grouped by surface: views/modes + palette
  actions; filter bar (labels, select options, tooltips); the relocated `.ftm-utils`
  cluster (Alarms/System/health/keys/help/export/market-timeline tips); alarm list
  (sort, ack, empty states, all 8 derived alarm names); playback (Hour Ending,
  On plan / At risk / Re-optimizing); all 10 KPI tiles + their vs-strings
  ("on plan", "on spec", "pre/post-divergence") and data-tips; all 14 config panel
  titles + markup originals + `TITLE_SHORT` compact titles; card descs/segments
  (Columns/River/Heatmap/Intraday/Day-Ahead/Flow, Compare, header-overflow labels);
  RT cell titles; AI-insights headings + the 5 fully-static insight sentences;
  decision-timeline legend (7 REASONS); constraint monitor (10 names + At
  Limit/Nominal); SOC card + sidebar (gauge, sr-cells, all 18 live tiles);
  price notes (Charge/Discharge window); market timeline (5 events + subtitles +
  footer); export dialog (+ 4 format hints); panel kebab menu (incl. the
  Restore size / Expand panel toggles); User Configuration modal + workspace
  menus (incl. 2 placeholders — the engine's attribute pass covers placeholder);
  keyboard-shortcut sheet (4 groups + all rows); HTML chart legends (~38 series
  names — safe to translate: legend handlers key off `data-n`, not textContent);
  Genie's Read meta "optimizer · live".
- **Excluded by design (never registered)**: numbers/units (MW, MWh, %, $, cyc,
  "· to hr"), site names (Saguaro BESS-01 …), bare acronyms/domain keywords
  (DA, RT, LMP, SOC, PV, HE, POI and the DA/Δ segment buttons), brand names
  (GridLine FTM Optimizer, Genie Forecast Model, service names in the health
  popover), and every dynamic composed string (alarm descriptions, Genie's Read
  sentences, "N of M selected", "Nm ago", "mean of N h", priceNotes/revDesc
  sentences, `N degraded`, chip counts) — exact-match keys only, so they pass
  through untouched. Canvas-drawn ECharts internals (axis labels, canvas
  tooltips, PEAK/CHEAP markers, sankey node text) are OUT of scope — the DOM
  HTML legends carry the translations instead. The User Guide (`ftm.guide`
  iframe srcdoc / help tab) and the long-form INFO-mode entries are separate
  reference documents and stay English, like btm's guide.
- **Keys deliberately left to the shell dictionaries** (already covered, not
  overwritten): Alarms, Today, Watch, Peak, Operations, Genie's Read, Settings.
- **ar decision**: tested live under `ar` — the dense grid itself survives the
  RTL flip (no overflow), but bidi reordering scrambles the signed/currency mono
  readouts ("−$219" → "219$−", "+9H" → "9H+", value/unit order inverts), a real
  misreading risk in a financial console. `#ftm-root{direction:ltr}` is pinned in
  the bridge CSS as the documented choice (data consoles stay LTR): Arabic labels
  still translate in place, shell chrome (nav/tabs/header) remains RTL.
- **data-wv-i18n-off audit**: no real collision found — no mono/data readout's
  exact trimmed text equals a registered key (IDs, HE/+NH stamps, site names,
  seg values are all unregistered) — so no markers were added.
- Verification: Playwright (channel=chrome) **38/38 green, STRICT zero pageerror
  whole-run** — ja: 19/19 exact-string product labels (modes, filters, 8 KPIs,
  schedule title, playback, sidebar) + data-tip attribute pass asserted; site
  name, MW units, DA segment, hour stamp, DA LMP tile asserted byte-unchanged;
  translations survive `setHour()` re-render + live playback ticks (observer
  re-applies); fr-CA + ar spot checks (ar: `html dir=rtl`, `#ftm-root` computed
  `direction:ltr`, zero overflow probes); en-US restore asserted exact against
  captured baselines (engine reversibility); light-theme round-trip + Forecast
  view clean. Screenshots: `ftm_ja_monitor.png`, `ftm_ar_monitor.png` (session
  scratchpad).

## Round 1.2.0 delivered (2026-08-28) — single alarm surface

Framework `1.2.0 2026-08-28`: the alarm drawer absorbed the product alarm surfaces'
features — severity-count FILTER CHIPS (crit/maj/minr/info, click to filter, x to
clear), LATEST/SEVERITY sort (stable, newest-first inside a band), MULTI-SELECT
(per-card checkboxes + select-all honoring the active filter) with a footer
"N selected / Acknowledge" bar; Ack-all clears selection; all new labels localized
(exact keys Latest/Severity/Acknowledge/None selected + count patterns in 5 languages).
Verified in-framework: chips/filter/sort/select/ack matrix + ja localization, zero
errors. The popover "pin/dock" affordance was deliberately NOT adopted — the drawer
already persists until closed.

Both dashboards spliced to 1.2.0 (backups `*.pre-1.1.1.html` superseded in place).
Product-side deltas:
- **ftm**: `#alarmBar` bell + `#alarmPop` popover hidden; NEW `ftmBridgeAlarms()` in the
  registration block feeds the drawer — `buildAlarms()` output raised once per product
  `alarmKey` (name|worst-hour; ack-set respected), `crit→crit`, `warn→maj`, source
  "FTM Optimizer", srcView ftm.monitor; hooked after `ftmRenderAlarms` (the derivation
  tick keeps running) + once at mount. Verified: 7 derived alarms (3 crit · 4 maj) in
  the drawer, chips/sort/select working, bell gone, zero errors.
- **btm**: already compliant (its rule-scanner bridged via WV.raiseAlarm at conversion;
  bell removed then). Inherits the new drawer features with the splice. Verified.

Standing rule added to the integrate skill: COMMONS LIVE IN THE SHELL — a product
feature the shell lacks moves into the framework, never survives as a duplicate surface.

### ftm follow-up 2026-08-28 — Live Operational Status bottom tiles unreachable
Root cause: the RAW page is a no-scroll full-viewport design, so `#liveBody`
(`overflow:hidden`) always fit standalone; under the shell the column is ~150px
shorter and the hidden overflow silently clipped the bottom tiles (777px content in
a 565px box at 768-high windows) with no way to reach them. Fix: under the shell
`#ftm-root #liveBody{overflow-y:auto}` with a thin themed scrollbar — the tile list
scrolls INSIDE the card when space is short; taller windows still fit with no
scrollbar. Verified at 1366x768 (212px scroll, last tile reachable) and 1680x1000
(no overflow), zero errors. GENERAL RULE for integrations: a no-page-scroll product
design means every `overflow:hidden` fixed-fit region must gain inner scroll (or
re-derived height) under the shell's shorter viewport.

### ftm follow-up 2026-08-28 — the NO-SCROLL CONTRACT restored under the shell
The raw dashboard is a fill-the-viewport, no-scroll console and its own fit engine
(fitGrid shrink-to-fit with readability floors, syncMonitorHeight bottom-alignment,
per-mode `calc(100vh…)` fallbacks) already implements "scroll only when utmost
necessary" — it just measured the WINDOW instead of the PANEL under the shell. Rewired:
- `ftmFitBottom()` = the panel scroller's CONTENT bottom edge (rect.bottom minus the
  panel's own padding-bottom; window bottom standalone) — `layoutOverflow`,
  `syncMonitorHeight` and the forecast row budget all measure against it.
- `--ftm-vh` token (set in syncChrome, zoom-corrected) replaces `100vh` in the five
  per-mode CSS fallback calcs (mon-h, fc-row, analyze, panel-solo ×2). Overlay/guide
  `100vh` uses untouched.
- `--sb-maxh` budget now subtracts the sidebar's own starting offset + panel padding
  (the column previously overshot the panel bottom by exactly that offset).
Verified at 1912x940: panelScroll **0** in Monitor (normal AND Full View), Forecast,
Analyze; All Panels scrolls by design (a stacked collection); at 720-high windows the
readability floors engage and only then does minimal scroll appear (liveBody inner
scroll as the last-resort floor). Zero errors throughout.

## Round 1.2.1 delivered (2026-08-28) — single health surface

Framework `1.2.1 2026-08-28`: the health chip + popover adopted the product health
panels' presentation — chip label **SYSTEM** when nominal (DEGRADED/STALE still break
through), popover retitled "System health" with an **N/M nominal** chip and calm
green ✓ **OK** rows (DEGRADED/STALE keep their pills), heartbeat ages kept; new i18n
entries (SYSTEM, System health, N/M nominal pattern). Both dashboards spliced.
Product-side deltas:
- **ftm**: registration `systems` replaced with the product's REAL six services
  (UI · Interfaces · Database · Kafka · MILP Optimizer · Genie Model); its
  `SERVICES` truth drives the chip via `ftmBridgeHealth()` (ok→live,
  degraded→degraded, down→stale; hooked after `renderHealth`, once at mount);
  `#healthBtn`/`#healthPop` hidden. Verified: chip SYSTEM, popover 6/6 nominal with
  six ✓ OK rows, own button gone, zero errors.
- **btm**: already bridged at conversion — inherits the presentation; verified live
  showing 5/6 nominal + chip DEGRADED (real freshness miss), zero errors.

## Round 1.3.0 delivered (2026-08-28) — single shortcuts + help/guide surfaces

Framework `1.3.0 2026-08-28`:
- **Header keyboard-shortcuts icon** (`#wv-keysBtn`, kbd glyph, beside Help) opening
  the shell sheet; HIDEABLE via the Header icons card (id `keys`; the resources pod
  collapses only when help+ticket+keys are all off).
- **`WV.registerShortcuts(groups, product?)`** — products contribute their own keys
  ([[groupLabel,[[keys,desc],…]],…]); the sheet renders an accent-titled product
  section (groups + rows) for the ACTIVE product on every open.
- **`WV.registerProduct({guide})`** — optional guide view id; the help menu's first
  entry becomes "User guide — <view> · <product>" opening that view (external-docs
  note remains the fallback when absent).
- i18n: User guide, Keyboard shortcuts entries added.
Both dashboards spliced. Product-side deltas (both): own `#keysBtn`/`#helpBtn`/
`#keysBack` sheet hidden; `guide:"<id>.guide"` registered; SHORTCUTS contributed with
retired rows dropped (Alarm list / This sheet / Close overlays; btm also Light-dark
theme — those surfaces are the shell's now). btm's IIFE exposes its table as
`window.btmShellKeys`. Verified both: header icon shown+hideable, sheet carries the
product section (ftm 4 groups/18 rows · btm 3 groups/15 rows), help menu opens the
registered guide view, zero errors; framework standalone clean.

### Framework 1.3.1 (2026-08-28) — shortcuts sheet redesigned in the product style
The shell sheet adopted the product sheets' presentation: two-column grouped grid,
per-group accent (violet/green/cyan/amber cycle) on a left rail + dot + uppercase
title, colored mono key combos ("Ctrl + K"), header X close, wider box (780px,
inner-scroll past 88vh). Shell keys are now the first group ("Application shell");
product groups from `WV.registerShortcuts` follow. Old flat-row markup and interim
product-section styles removed; subtitle + group label localized. Both dashboards
spliced to 1.3.1; verified FTM (5 groups/26 rows) + BTM (4 groups), zero errors.

### ftm follow-up 2026-08-28 — filter bar scoped to the main column (user layout decision)
The filter bar governs main-column content only, so it was moved INSIDE `.main`
(runtime `insertBefore` in the stage-2 prologue; `#ftm-root .main>#filterBar{margin:0}`)
— the Live Operational Status column now starts at the panel top and gets the FULL
panel height. Verified at 1912x940: filter bar right edge 1556 < sidebar left 1570,
both top-aligned, panel scroll 0, liveBody inner scroll 136→76px (fits entirely at
≥1000px-high windows). The sidebar height budget adapts automatically (its measured
starting offset shrank). General option for integrations: when a product's top
toolbar governs only the main column, scoping it INTO that column buys a side rail
the full panel height.

### ftm follow-up 2026-08-28 — adaptive rail densify (raw-parity space management)
Measured raw vs integrated at identical viewports: product spacing was PIXEL-IDENTICAL
(fonts/tiles/gaps/paddings all equal); the only delta was the rail's available height
(774 raw vs 701 shell — the shell's legitimate chrome rows). Fix: a small deficit
(0–96px, measured at the native rhythm inside syncChrome) sets `data-sb-fit="tight"`
on #ftm-root — tile padding 8→5px, #liveRows gap 8→5px, side header/body trims —
recovering ~74px invisibly; full-height windows keep the native rhythm (attribute
absent); short windows past the threshold fall back to the scroll floor. Verified:
940px normal view = whole card visible incl. THROUGHPUT/WARRANTY, no scrollbar;
1080px = native; zero errors.

### ftm follow-up 2026-08-28 — densify graduated into tiers (final space management)
The binary tight state became GRADUATED, keyed to the native-rhythm deficit measured
in syncChrome: d<=0 native · d<=78 "tight" (pad/gap 8→5, header trims, ~74px) ·
d>78 "tighter" (pad/gap →4, plus the dial block compressed proportionally via
`.gauge-wrap{zoom:.82}` — crisp, fonts untouched, ~135px) · anything beyond scrolls
as the floor. Verified at the user's window (1836x878): REGULAR view (nav + tabs +
read band all visible) fits the whole rail with zero scrollbars; Full View fits on
the milder tier with the dial full-size; 1080 returns native. Zero errors.

### ftm follow-up 2026-08-28 — rail FILLS its column (final geometry; breaks the shrink-lock)
User-identified root cause of the residual gap: the side card's height came from the
product's bottom-ALIGNMENT logic (syncMonitorHeight stretches card/chart to each
other's natural bottoms) — densify shrank the card's natural height, alignment chased
it down, and both locked ~63px short of the panel bottom while tiles sat compressed.
Fix: in shell context the sidebar takes a DEFINITE height (`height:var(--sb-maxh)`),
`.side-card` flex-fills it, `#liveBody` flex-fills the card — the rail always ends
one --gap above the panel bottom, the chart aligns to the same line (raw-parity), and
densify only covers a true shortfall. Verified 878–1080px: gapBelowCard=chartGap=14px
constant, zero hidden tiles, zero scrollbars; Full View at 939 needs NO densify
(native). Also: local server now serves NO-CACHE (serve_genie.py + updated
Start-GenieShell.bat) — stale-tab confusion during review rounds is gone.

### ftm follow-up 2026-08-28 — MODE seg restored in-dashboard (routed through the shell)
User decision: the filter bar's MODE segmented control (Monitor/Forecast/Analyze/All)
stays IN the dashboard. Un-hidden (`.flt-mode` visible again; only `.cfg-group` —
config + workspace cogs — remains retired), and a capture-phase reroute on `#modeSel`
maps each standard mode to its catalog view (`openView('ftm.<mode>')`) so the shell
tab/view state stays honest; the mount recipe drives `applyMode`, the seg's active
state tracks as before. Custom modes and `#wv-embed` boots fall through natively.
Verified: Forecast click → activeView ftm.forecast + mode-forecast + seg active;
round-trip to Monitor; cogs hidden; zero errors. RULE for future integrations: a
product-local view/mode switcher MAY stay by user preference, but must route through
`openView` — never drive product navigation behind the shell's back.

### ftm follow-up 2026-08-28 — mode CONFIG + LAYOUTS cogs restored too
Supersedes the "cfg-group retired" line above: the `.cfg-group` (config cog `#cfgBtn`
+ layouts caret `#wsBtn`) is visible again beside MODE. Verified: cog opens the User
Configuration modal; caret opens the workspace menu (load/undo/reset), closes on
outside click. FIX shipped with it: hotkey scoping reserves Esc for the shell, so the
product modal's Esc path never fired — a capture-phase keydown in the registration
block closes `#cfgBack` first (via `closeConfig()`) and stops the event. Custom modes
defined via the cog apply natively inside the singleton (the shell tab keeps the last
catalog view's name — documented trade-off). RULE: when a kept product surface owns a
MODAL, give it a capture-phase Esc bridge — reserved-key scoping otherwise strands it.

### Framework 1.3.2 (2026-08-28) — utility pods moved right of the genie · new defaults
`#wv-podNotify` (bell + inbox) and `#wv-podRes` (help + shortcuts + ticket) now sit
RIGHT of the genie pod (also frees more left space for the herald island). Default
visibility changed: bell/inbox/ticket ship HIDDEN, help + keyboard shortcuts shown —
the Header icons card turns any back on. Storage key versioned `hiddenIcons2` so the
new default applies over previously-persisted empty sets; Reset preferences restores
the new default. Verified both dashboards: pod order, default visibility, QS rows
(alarm/notif/ticket Off · help/keys On), zero errors.

### Framework 1.3.3 (2026-08-28) — shortcuts sheet sizes to its content
`renderProdKeys` stamps the group count (`data-kn`, capped 3) on the overlay: one
group = 480px single column (framework standalone), two = 720px pair, three+ = the
full 780px two-column grid. Verified: framework kn=1/480px/1col; ftm kn=3/780px.
Both dashboards spliced to 1.3.3, zero errors.

## Round 1.4.0 delivered (2026-08-28) — "share top 5" voice commands · btm mode parity

Framework `1.4.0 2026-08-28`: two new Genie voice commands (all products inherit):
- **"share top 5 alarms"** (`top5a`) — opens the alarm drawer AND, with Voice on,
  speaks the enumerated top five (severity + text); empty list answers "There are no
  alarms." Island reply either way.
- **"share top 5 notifications"** (`top5n`) — opens the notification menu (genie-anchor
  fallback when the tray icon is hidden) and speaks the top five; empty-store answer.
Multilingual triggers (en/fr/es/ar/ja number+noun patterns), localized replies
(t5a/t5n/none_a/none_n in CMD_STR). Both dashboards spliced.

btm parity round (matching the ftm user decisions):
- MODE seg (Monitor/Fleet/Energy/Accuracy/All) + config cog + workspace caret restored
  (`.flt-mode` unhidden); standard modes route through the shell via the existing
  `btmViewIdOfMode` seam (capture intercept → openView; custom modes/embeds native).
- Esc bridge for the Modes-config modal (`#cfgBack` closed via `#cfgClose.click()`).
Not applicable to btm (documented): filter-bar-into-main, rail flex-fill/densify —
its band layout has no persistent side rail. Verified: seg visible + Fleet routes to
btm.fleet with the map alive, cog modal opens + Esc closes, top-5 commands spoken with
open surfaces (seeded store), empty cases answered, zero errors.


## Integrations delivered on 1.4.0

### dlrline — DLR Genie · Line Details (2026-08-28)

- File: `dashboards\dlr-genie-line-details_wv1.4.html` (raw source
  `dashboards\dlr-genie-line-details_v0.2.html` untouched); embedded shell stamp
  `1.4.0 2026-08-28` (copied with the chunks, asserted post-assembly). NEW product
  `dlrline` — row + catalog added to WV-PRODUCT-REGISTRY.md.
- **The raw build is a STATIC DOM SNAPSHOT** (live app route `/lines/6`, captured
  2026-08-27 per its `genie-dlr-snapshot` meta): zero product JavaScript — captured
  DOM + token CSS + inline token-driven SVG charts. Everything below follows from
  that; an updater must not expect product engines/globals in this file.
- Views registered: `dlrline.details` (Line Details — the file's ONE page; singleton
  mount of `#dlrline-root`). Accent `#5B9BF0` (`--genie-action-primary`). No guide
  (none embedded), no product shortcuts (no hotkeys exist), no chat provider.
- **STARTUP WORKSPACE (new requirement, first use):** `WV.start` passes the inline
  workspace `startupWs:{id:"ws-dlrline-details",name:"Line Details",product,layout:
  "tabs",views:["Line Details"]}` — a FRESH login lands directly on the mounted
  Line Details view, never the launchpad (`loadWs` matches `views` by NAME within
  the workspace's product; verified with two fresh profiles at 1680x1000 and
  1366x768). Resume-session may supersede it on later logins — by design.
- Conversion notes an updater must know:
  - Product CSS is byte-pure except SIX exact-anchor re-scopes: the bare globals
    (`*` box-sizing, `img,svg`, `button`, `table` — the classic hostile resets)
    scoped under `#dlrline-root`; the `html,body` reset dropped (shell owns the
    page root); the snapshot-capture overrides re-scoped — the `.genie-shell`
    capture-height pin (2120px) becomes `height:auto` and `__content` stops being
    a second scroller (`overflow-y:visible`) so the PANEL scroller owns the one
    scroll; the snapshot's blanket `*{transition/animation:none}` freeze is KEPT,
    scoped to the product root (shell motion untouched).
  - Theme needs no bridge: product light CSS keys off `:root[data-theme='light']`
    (dark = absence) — exactly the shell's `html[data-theme]` mechanism. `onTheme`/
    `onResize`/`onVisibility` are honest documented no-ops (pure CSS + viewBox
    SVGs; no engine to call).
  - Chrome removed via the registration style block: `header.genie-topbar`
    (brand, DEAD route nav Fleet/Map/Events/Analytics, clock, unit/axis toggles,
    alarm chip, user chip, health chip, theme toggle, sign-out) and the product
    `.genie-reads-bar`. Root re-rooted: `class="genie-body"` moved from `<body>`
    onto `#dlrline-root` (+ `min-height:0` under the shell).
  - Single alarm surface: 24 captured Thermal Derating Events rows raised once
    each (critical→crit ×2, warning→maj ×22, message composed from the row cells)
    + the Current Hour panel's Warning state (DLR −12.0% vs AAR) = **25 alarms**
    (2 crit / 23 maj), matching the removed topbar chip's "25 active"; the chip's
    3rd critical is fleet-level state not present in the captured page data —
    documented delta. Dedup set keyed by message; raised at first mount (the
    burst rides the shell's alarm-burst summarizer, which files an Alarm-summary
    read — observed live).
  - Single health surface: 4 systems registered static `live` (= the captured
    "System health — 4/4 nominal"); service names not in the snapshot (popover
    never captured) — named from the page's data planes (Rating Engine, Weather
    Feed, Span Telemetry, Forecast Service).
  - Genie's Read: the strip's ONE captured read (React renders only the current
    read; the pager's other 9 dots have no DOM content) parsed from the page and
    fed to the shell band — kind Divergence, tone info, figures → insights, line
    name + "model · live" meta.
  - Shell-prefs bridge: UI scale × Font size → one `zoom` on `#dlrline-root`
    (nothing to re-measure — no JS; charts are viewBox SVGs); Density →
    `data-wv-density`, comfortable bumps `--genie-space-1/2` 12/20→14/24px +
    `--genie-panel-pad-y/x` 15/16→18/20px; Reduce motion → `data-wv-motion`
    (contract completeness — snapshot motion is already frozen); Appearance →
    computed `--wv-bg0` → `--genie-surface-base` on the root, PINNED accent →
    `--genie-action-primary`(+emphasis), auto restores native blue,
    change-signature guarded. Regional/number formats NOT bridgeable, documented:
    zero JS — every visible stamp/figure is captured data baked into markup (the
    live clock left with the topbar).
  - Info mode: root carries `data-wv-product-root` per the 1.1.1 contract, but
    the live app's info system was not captured — no `wv:info` listener (nothing
    to drive), documented.
  - Palette actions: `dlrline:open` + three panel-jump actions (Rating Timeline /
    Derating Events / Heat Balance via scrollIntoView) — shell-side navigation
    aids for a long page; no product behavior changed.
  - i18n: `DLRLINE_I18N` (57 keys) through `WV.i18n.register` — panel titles
    (static ones only), filter bar, timeline controls + legends, heat-strip
    legend, weather tabs + HTML legend, events-table headers + Warning/Critical
    badges, limiting-span metric labels, actions/systems/meta. NEVER registered:
    numbers/units, line/owner names, acronyms + composites (DLR/AAR/SLR/GHI,
    "vs AAR", duration chips), count-embedding panel titles ("Thermal Derating
    Events (24)", "Limiting Span — #465 …", "Span Ranking Heat Strip — 690 …"),
    unit-composite table headers, and SVG-internal chart text (axis labels,
    compass letters — positioned per capture geometry, chart internals).
    **ar decision:** `#dlrline-root{direction:ltr}` pinned (btm/ftm precedent) —
    shell chrome mirrors RTL, the dense mono data plate stays LTR; verified no
    overflow, labels translate in place. No `data-wv-i18n-off` needed (no data
    readout's exact text equals a registered key).
  - No-scroll contract: the raw page is a LONG SCROLLING details page by design
    (~2120px content at capture width; standalone `.genie-shell__content` is the
    scroller) — under the shell the PANEL scroller is the one scroll surface
    (raw parity), zero horizontal overflow, `__content` verified NOT a second
    scroller, events table keeps its own capped inner scroll
    (`--panel-scroll-max`). Densify tiers N/A (no fill-the-viewport fit engine);
    verified normal + Full View at 1680x1000 and 1366x768.
- Verification: Playwright (channel=chrome) suite **39/39 green, 0 pageerror /
  0 console-error (strict whole-run gate)** — fresh-profile login lands on the
  mounted view (startup-workspace proof, ×2 viewports), 8-panel content markers
  (24 event rows, 190-cell heat strip, IEEE table, gauge 1,816.4 A), topbar/reads
  strip retired, shell band carries the captured read, 25 alarms (2 crit/23 maj)
  in the drawer, health popover 4/4 nominal with real service names, scroll
  contract (one scroller, no h-overflow, normal + Full View), theme round-trip
  dark→light→dark exact, zoom 1.375 apply/restore, comfortable/compact token
  round-trip, reduce-motion attr, Appearance ground+pinned-accent+auto restore,
  ja labels + untouched data, ar RTL-shell/LTR-plate, en-US exact restore,
  `#wv-embed=dlrline.details` chromeless boot posting `{wv:"ready"}` to a
  same-origin iframe parent. Screenshots: details dark/light, ja, ar, Full View,
  fresh-768, embed (session scratchpad).

### dlrmap — DLR Genie · Map (2026-08-28)

- File: `dashboards\dlr-genie-map_wv1.4.html` (raw source
  `dashboards\dlr-genie-map_v0.2.html` untouched); embedded shell stamp
  `1.4.0 2026-08-28` (copied with the chunks, asserted in-page). NEW product
  `dlrmap` — row + catalog added to WV-PRODUCT-REGISTRY.md.
- **The raw build is a STATIC DOM SNAPSHOT** of the React app's `/map` route
  (`genie-dlr-snapshot` meta, captured 2026-08-27): zero product JavaScript —
  one giant token-CSS block + the captured DOM whose map is inline SVG
  (`viewBox 0 0 1000 365`, `width/height 100%`, no Leaflet/tiles). All product
  buttons are inert by nature of the snapshot; theme/appearance/i18n ride the
  snapshot's own CSS custom properties.
- One view: `dlrmap.map` (Network Map, type Map, group Operations) — singleton
  mount of `#dlrmap-root`. **Startup workspace** `ws-dlrmap-map` passed inline to
  `WV.start` so a fresh login opens the map directly (verified twice on fresh
  profiles; no launchpad).
- **SNAPSHOT-TOOL OVERRIDES ARE THE RE-INTEGRATION TRAP** (any future rebuild from
  the raw file must repeat this): the raw tail carries appended
  "offline snapshot overrides" — `html,body{height:auto!important;overflow:visible
  !important}` (breaks the shell's viewport chain: header/body stretched to
  content), `.genie-shell{height:1196px!important}` (capture-height freeze) and a
  GLOBAL `*{transition/animation:none!important}` (kills SHELL animations).
  Assembly deletes the html/body override, re-scopes the rest under `#dlrmap-root`
  (shell frame becomes `height:auto`).
- Conversion map: `header.genie-topbar` REMOVED (brand/nav → shell nav; clock,
  refresh, offline-copy, SI-units select, y-axis + nav-orientation toggles died
  with the snapshot; alarms bell → drawer; user chip/help/sign-out → shell; Info
  Mode group → shell ⓘ; theme toggle → shell; health pop → shell chip). In-page
  Genie's Read strip hidden and bridged (below). Bare-element resets
  (`img/svg`, `button`, `table`) scoped under `#dlrmap-root` so they cannot reach
  shell chrome; `html.genie-info-mode-active` selectors re-rooted to
  `#dlrmap-root.genie-info-mode-active`.
- Bridges: **wv:info** → toggles the re-rooted info CSS class (the live app's JS
  explainer popovers are not in the snapshot — CSS hover affordance is the whole
  product info surface, documented). **Alarms** → the topbar bell was a CLOSED
  popover at capture ("24 active · 3 crit · 21 warn" — items not in the DOM), so
  the drawer is fed from the page's concrete truth: the Lines on Map table's 13
  Warning lines → `maj` (Critical→`crit` mapping ready), deduped per line.
  **Health** → 4 drafted systems static `live` (names aligned with dlrline; the
  4/4-nominal count is the snapshot's own). **Genie's Read** → the ONE read the
  capture rendered (Constraint · Taft–Castaic 230kV, tone watch) feeds the shell
  band with fleet-figure insights; the strip's other 9 rotation dots have no
  content in the DOM (documented).
- Shell-prefs bridge: zoom = scale×fontScale on `#dlrmap-root`; density
  comfortable bumps page gap 14→18 + panel pads 15/16→19/20 (compact native);
  reduce-motion parks product animation/transition (the snapshot override already
  parks them product-wide); Appearance copies `--wv-bg0` → `--genie-t-background`
  and PINNED `--wv-acc` → `--genie-t-ring` at documentElement (auto restores
  native violet). Regional/number formats NOT wired — every stamp/figure is
  captured data, no live clocks or formatters exist (documented).
- **No-scroll contract:** the raw page is a content-sized scrolling console
  (map `aspect-ratio 1000/520, max-height 570px`, table inner-scroll cap 271px;
  at 1912x940 the raw page window-scrolls 256px). Under the shell, graduated
  densify tiers keyed to the native-rhythm deficit (measured in `syncFit()` with
  state cleared): tier "tight" (d≤95) trims content padding/page gap + map
  →505px + layers/legend stack `zoom:.84`; tier "tighter" trims further, map
  →440px, table cap →190px, Selected-Line side panel body `zoom:.88` (its natural
  height binds the map row — fill-before-compressing), layers stack `zoom:.71`
  (clears the bottom zoom-control cluster, asserted). Result: **1912x1080 normal
  view = ZERO panel scroll**; 1912x940 = 135px (normal) / 53px (Full View) panel
  scroll vs the raw page's own 256px — better-than-raw parity at the floor.
- Product i18n: `DLRMAP_I18N` (58 exact-match keys — filter bar, playback, map
  controls/layers/legend, Selected Line, table headers + status pills, catalog
  name) via `WV.i18n.register`; excluded: numbers/units, line names, span/H3 ids,
  owner name, bare acronyms (DLR, SLR, AAR, GHI, kV, SI), the "SLR – AAR"
  all-acronym legend row, and "Status" (already in the shell dictionary). ar
  pinned `#dlrmap-root{direction:ltr}` (btm/ftm precedent; mono composites
  "20/20", "1,493 A", "+102.0%"). No shortcut groups contributed — the snapshot
  has no live keys (registering them would advertise dead keys); no embedded
  User Guide exists (topbar /help was an external route).
- Verification: Playwright (channel=chrome) suite **54/54 green, 0 pageerror /
  0 console-error (strict whole-run gate)** — fresh-login startup-workspace proof
  (x2 fresh profiles), map container non-degenerate + SVG content assertions,
  alarm/health/read bridges, theme round-trip with the CSS basemap wash following,
  wv:info round-trip, zoom/density/motion/appearance prefs asserts, ja (6 label
  asserts + data/acronym untouched + lossless en-US restore), ar RTL-shell/LTR-
  plate + no overflow, singleton forceNew replace, `#wv-embed=dlrmap.map`
  chromeless + `wv:ready`, layers-stack/controls clearance, 1080p zero-scroll.
  Screenshots: dark/light/Full View/zoom125/ja/ar/embed/1080-noscroll (session
  scratchpad).

### ev — Genie EV Charge Load Management (2026-08-28, new product)

- File: `dashboards\ev_dashboard_wv1.4.html` (raw source `dashboards\ev_dashboard_v0.3.html`
  untouched); embedded shell stamp `1.4.0 2026-08-28` (copied with the chunks, asserted
  post-assembly). New product id `ev` — row + view catalog added to WV-PRODUCT-REGISTRY.md.
- Views: `ev.monitor` · `ev.forecast` · `ev.dispatch` · `ev.fleet` · `ev.analyze` ·
  `ev.all` (singleton mount of `#ev-root`, `applyMode(<Mode>)` recipes) + `ev.guide`
  (the LIVE-generated User Guide — `buildHelp(sink)` captures chart shots, then renders
  `evBuildGuideDoc()` into a panel-scoped srcdoc iframe). Accent `#bb93ff` (its `--ring`).
- **Startup workspace (per the new 1.4.0-era requirement):** `WV.start({product:"ev",
  startupWs:{id:"ev-default",name:"EV Default",layout:"tabs",views:["Monitor"]}})` — a
  FRESH profile logs in straight onto a mounted Monitor (verified: `S.open==["ev.monitor"]`,
  mounted, no launchpad); the resume-session pref rightly overrides on later logins.
- Verification: Playwright (channel=chrome) suite **58/58 green, 0 pageerror /
  0 console-error (strict whole-run gate)** — fresh-login startup workspace; all 7 views
  with real content markers (envelope canvas + feeder rail + KPIs, tariff/connected/
  confidence canvases, dispatch console form + waterfall + delivery monitor, sessions
  grid + SoC/mix/segments + transport tiles, value canvas + DER list + history, 16-card
  All, guide document with captured figures); no-scroll contract `scrollHeight−clientHeight
  === 0` in every primary mode at 1912×940 normal AND Full View (and still 0 under
  125 %×110 % zoom); singleton replace; theme round-trip dark→light→dark (canvas-hash
  proof of chart rebuild); prefs bridge (zoom/density/motion/regional/appearance);
  `#wv-embed=ev.forecast` chromeless + `{wv:"ready"}` postMessage; ja/ar/en i18n
  round-trip. Screenshots: monitor/forecast/dispatch/fleet/analyze/all/guide dark +
  monitor light + zoom137 + fullview + ja + ar + embed (session scratchpad).
- Conversion notes an updater must know:
  - **Entire product JS wrapped in ONE IIFE** (no globals leak; the shell's lexical
    globals such as `renderGenieRead`/`openView` can no longer collide). Seams:
    `window.evShell` (applyMode/soloPanel/resizeAll/buildAlarms/alarmKey/isAcked/
    services/buildReads/shortcuts/i18n/setInfoMode/close*/openExport/buildHelpTo/
    guideDoc/subName/stateMode/modeOrder), `window.evApplyTheme` (readTokens + axis
    colors + rebuildAll + read re-feed), `window.__evInitDone` + `ev:ready` event,
    `window.__evFeedRead` / `__evBridgeAlarms` / `__evBridgeHealth` hooks appended to
    renderGenieRead / renderAlarms / renderHealth inside the product layer.
  - **RAW-FILE FIXES carried in assembly** (repeat on any re-integration): (1) the raw
    markup never closes `.layout`/`.main` (auto-closed at `</body>` standalone) — two
    explicit closers appended so the `#wv-park`/`#ev-root` wrapper closes; (2) FTM
    copy-paste leftovers: guide `<title>` said "Genie FTM Optimizer", guide subtitle
    said "Front-of-meter battery dispatch · ${D.name}" and the PDF export title used
    `D.name` — `D.name` is UNDEFINED in the EV model; all three now use EV branding +
    `CONFIG.display.substation_name`; (3) the guide doc skeleton now carries
    `data-theme` and its own body ground/font rule (the page `body` rules moved to
    `#ev-root`, and the copied CSS keys dark tokens to `html[data-theme="dark"]`).
  - **Theme keyed to `html[data-theme]`** (shell-owned) because the product re-homes
    overlays to `<body>` at runtime (info card/menu, legend popover); light selectors
    `html:not(.dark)` → `html:not([data-theme="dark"])`. `onTheme` → `evApplyTheme()`.
  - **No-scroll contract:** `evFitBottom()` (panel scroller content bottom; window
    standalone) feeds `layoutOverflow`/`syncMonitorHeight`/forecast-analyze budgets;
    `--ev-vh` (zoom-corrected) replaces `100vh` in the 9 per-mode layout calcs +
    sidebar/no-access; `--grid-top`/`--layout-top` now rect-based (÷ zoom);
    `--ev-below/--ev-left/--ev-right` keep the MAXIMIZE overlay + fs backdrop inside
    the panel edges. GRADUATED DENSIFY: tier 1 = the product's own authored compact
    rhythm (`html[data-density="compact"]` rules re-keyed to `#ev-root[data-ev-fit]` —
    the shell's default density attribute would otherwise have silently tightened the
    native 14px look), tier 2 trims one more notch; measured at the pref rhythm with
    state cleared each syncChrome, skipped in mode-all/panel-solo (scroll by design).
  - **Guide staging:** when the singleton is hidden (parked or background tab) the
    capture stages `#ev-root` in an offscreen sized wrapper and returns it EXACTLY
    where it lived (never blind re-park — a mounted root must go back to its panel);
    `onTheme` of the guide re-renders from the EXISTING shots (a theme swap must never
    re-run the choreography — it would flip the live singleton through All mode).
  - Relocated (product-functional): `userChip` (impersonation demo) + `roleCog`
    (role-matrix editor) into a `.ev-utils` cluster in the filter bar. The role system
    itself is untouched product logic (role-filtered modes/panels; `no-access` state).
    The product User Settings panel ships parked in the raw (`US_ENABLED=false`, the
    panel self-removes) — shell Settings supersede; its `usApply` was re-pointed at
    `#ev-root` and its theme/language writes neutralized under the shell.
  - Hotkeys scoped per §4.4 (uiBusy + inside-root + singleton-visible; body counts
    in-scope). ⇧A (alarm list), ⇧T (theme), ⇧G (read advance) and `?` (sheet) now
    no-op — those surfaces are the shell's; the product Esc branch is deleted and a
    capture-phase Esc bridge in the registration closes cfg/role-matrix/name/export
    modals, maximize, msel pops and menus first. Shortcuts contributed minus retired
    rows; the raw sheet's dead "Schedule panel" keys (⇧1/2/3/Q — FTM leftovers with no
    handler) were dropped and its working ⇧Z folded into Workspace.
  - Popouts ride the embed protocol: mode menu → `#wv-embed=ev.<slug>` (custom modes
    fall back to `ev.all`); per-panel → `#wv-embed=ev.all&ev-panel=<cardId>` (the
    mount re-applies the product's panel-solo state; the old `#mode=`/`#panel=` hashes
    remain as the standalone fallback).
  - Regional: `stampNow()`/`stampAt()` render via `WV.fmt.date/time` + `evTzShort()`
    (pref tz label; `TZ_ABBR` standalone fallback). NOT bridged by design: numbers
    (no central grouping formatter — domain-styled fixed-decimal kW/kWh), `WALL()`/HE
    hour-ending schedule labels (domain convention), the playback wall-clock.
  - i18n: EV_I18N built at runtime from the product's OWN parked-panel dictionary
    (fr/es/ja/ar tables → shell [fr,es,ar,ja] order; ~60 keys: modes, all 17 panel
    titles, filters, msel strings) minus shell-owned keys, plus ~60 curated extras
    (kebab, export, config modal, workspaces, playback, dispatch form, session grid).
    `#ev-root{direction:ltr}` pinned under ar (mono data composites; ftm/btm
    precedent). Canvas ECharts internals + the generated guide stay English.
  - Left running while parked (documented per §4.5): KPI refresh (10 s), clock tick
    into the hidden topbar (1 s), bell/health pulse class-loops (parked under reduced
    motion) — cheap DOM writes. Playback and the Genie's-Read rotation are gated
    (pause on unmount; rotation never starts under the shell). Voice/wake-word
    surfaces retired with the strip (unreachable, wiring intact).
  - Product ECharts stays the raw build's CDN script tag (cdnjs 5.5.0) — same as the
    ftm conversion; not vendored.
  - localStorage keys already product-prefixed (`evclmMode`, `evClmWorkspaces`,
    `evClmUserSettings`, `evClmVoice`, `evClmRoleMatrix`, `evClmRoleModes`,
    `evClmActiveUser`) — no changes.

## Round 1.4.1 delivered (2026-08-28) — portability + defaults (user field-test findings)

User copied the converted files to ANOTHER system and one booted EMPTY with the
placeholder brand. Root causes found + fixed:
1. **CDN dependency (the actual field failure)**: ftm + ev loaded ECharts 5.5.0 from
   cdnjs — unreachable there → product script threw → registration never ran → hollow
   shell. **ECharts is now VENDORED inline** in both (self-contained rule enforced);
   verified with ALL external requests blocked: every product boots fully, charts render.
   RULE: converted files must be verifiably self-contained — verification now includes a
   blocked-network boot.
2. **Same-origin storage collisions**: all files served from localhost:8890 shared one
   `wvfw.*` localStorage — sessions/workspaces/product state bled between files. The
   store is now namespaced per file via `<meta name="wv-app-id">` (framework key
   `wvfw.<ns>.<key>`, default ns "shell"); each converted product carries its meta
   (ftm/btm/ev/dlrmap/dlrline). Verified in ONE shared browser context: five products
   in sequence each boot their own default view with isolated namespaces.
3. **Sidebar minimized by default** everywhere: `<body … data-side="min">` in the
   framework and all five products (dlrmap's bare `<body>` patched explicitly).
4. **Framework boots EMPTY**: `WV.start({startupWs:null})` is now an explicit opt-out
   (no auto-pick fallback); the sample product uses it — fresh shell login lands on the
   empty launchpad. All five PRODUCTS keep their login-default views (re-verified).
All six files at `1.4.1 2026-08-28`; splice roster now covers all five products.

## Round 1.5.0 delivered (2026-08-28) — native login greeting · voice gender · quiet sign-in

Framework `1.5.0 2026-08-28` (CEO asks), spliced to all five products:
- **Native login greeting**: ~1.4s after sign-in the island blooms at the genie with a
  NATIVE, time-of-day-aware greeting + welcome sentence (en Good morning/afternoon/
  evening · fr Bonjour/Bonsoir(18h) · es ¡Buenos días/tardes/noches! · ar صباح الخير/
  مساء الخير · ja おはようございます/こんにちは/こんばんは +さん) with the operator's
  name; spoken when Voice is on (`{greet:true}` bypasses the quiet window; sets
  VOICE.greeted so the old first-speech hello stands down). Config: **Login greeting**
  On/Off in the Genie assistant card (`loginGreet`, default On).
- **Voice gender**: **Auto/Female/Male** seg (`voiceGender`); `pickVoice` filters the
  candidate pool by a Windows-voice-name gender heuristic (Zira/Hazel/Hoda/Ayumi… vs
  David/Mark/Ravi…, plus literal male/female tokens) and never blocks speech when no
  match exists. Verified David↔Zira flip.
- **Quiet sign-in**: `VOICE.holdUntil` starts at **Infinity on page load** — nothing
  ever speaks at the login screen (products boot + bridge alarms behind it) — and
  re-arms at sign-in (+6.5s with greeting, +0.9s without). During the window, herald
  events queue with badges only (no island takeover, no speech); a settle timer hands
  the island to the carried event right after the greeting bubble yields. Verified
  full sequence: pre-login silence → greeting only (island + sole utterance) →
  +8.8s herald carries the critical, badge 7, no retro-speech. QS labels localized.

## Round 1.6.0 delivered (2026-08-28) — ten new Genie voice commands

Framework `1.6.0 2026-08-28`, spliced to all five products. New commands (all with
localized spoken+island replies in 5 languages; multilingual trigger regexes):
1. **"share top 5 Genie's Read"** — expands the band, speaks the top headlines
2. **"log out"** — says a native goodbye, signs out 1.8s later
3. **"How are you"** — an honest status reply (unacked alarms + systems nominal)
4. **"open ‹anything›"** — the WHOLE catalog is voice-navigable: filler words stripped
   ("Open Operations DASHBOARD"→group Operations→Monitor), matches view names in the
   current language too, falls back to GROUP names, "I couldn't find that view" otherwise
5. **"change language to Spanish/…"** — switches live; confirms IN the new language
   ("Ahora hablo español."); language names recognized in all five languages
6. **"acknowledge all alarms"** — acks + confirms
7. **"full view" / "regular view"** — toggles with the right confirmation
8. **"what time is it"** — market-format time + zone label via WV.fmt
9. **"what can I say"** — a spoken capability menu (discovery)
10. **"stop"** — cancels speech instantly, island shows "Okay — staying quiet."
Mechanics: `cmdSay()` reply helper; `run(t)` now receives the transcript; generic
open-view registered LAST so specific commands always win. Verified end-to-end by fake
recognition: all ten + Spanish→English round-trip + logout-to-login, zero errors.

### Framework 1.6.0 follow-up (2026-08-28) — commands fully NATIVE per selected language
- The recognition ear RE-TUNES live: `EAR.lang` recorded at start; `prefChanged`
  restarts recognition when the language changes (incl. mid-conversation via the
  "change language to …" command — you keep talking in the new language).
- Trigger audit for natural word order: Japanese verb-last forms (言語を英語に変えて,
  すべてのアラームを確認して widened, 主要な…を教えて, …で話して), Arabic تأكيد/شارك أهم
  forms, extra ja discovery phrasings.
- The open-view matcher folds typographic apostrophes (’→') and French elisions
  (l'analyse, guide de l'utilisateur) and drops de/du/des fillers — spoken names match
  the i18n dict's typography.
Verified native matrix 21/21 across ja (7) / ar (4) / es (4) / fr (4+2): every command
answered in-language, ear tuned to ja-JP/ar-SA/es-MX/fr-CA respectively, view names
matched in the spoken language (モニターを開いて → モニターを開きます; ouvre la
surveillance → Ouverture de Surveillance), zero errors.

### Framework 1.6.1 (2026-08-28) — "Voice commands" reference overlay
New overlay `#wv-vcmds` in the shortcuts-sheet design language (grouped grid, colored
group rails, mono phrase column): four groups — Views & navigation · Alarms ·
Notifications & reads · Genie & system — 15 entries, with the example phrases rendered
IN THE SELECTED LANGUAGE (VC_STR table, pre-localized, walker told hands-off) so users
learn the native things to say. Opened by voice ("share the list of voice commands" /
「音声コマンド一覧」/ etc, with a localized spoken confirm), from the help menu
("Voice commands — everything the genie understands"), Esc/backdrop close wired.
Spliced to all five products; verified en + ja + help-menu path, zero errors.

### Framework 1.6.1 addendum (2026-08-28) — "close all displays" voice command
`closeall`: closes every open view via `closeInst` and confirms ("All displays
closed." / "Toutes les vues sont fermées." / "Todas las vistas cerradas." /
"أُغلقت جميع العروض." / "すべてのビューを閉じました。"). Multilingual triggers incl.
Japanese verb-last (すべてのビューを閉じて / 全部閉じて) and Arabic أغلق جميع العروض.
Spliced to all five products; verified en (2→0 views) + ja, zero errors. The Voice
commands overlay's Views group should gain this row at the next content touch.

## Framework 1.7.0 (2026-08-28) — Genie Chat redesign (CEO mockups: two-pane assistant app)

The chat surface is now a two-pane app, identical in every mode — floating drawer (680px),
docked panel, maximized, and the popup window (ONE markup builder `genieAppHTML` +
`genieMount(doc)`; the popup mounts the same app and shows a single "return to the shell"
control). The engine underneath (GENIE / genieSend / streaming / genieSpeak / attachments /
mic / dock+resize / max / herald / voice commands / Quick-Settings Genie card) is unchanged.

- **Left rail (~200px)**: Genie flame + wordmark, collapse toggle (icons-only; also folds
  automatically below 600px via a container query — the docked 420px default), WORKSPACE →
  Genie's Desk (active = filled row), OATI ▾ group listing the active product's catalog views
  (click → `openView`), + New chat, Search chats (in-place history filter), day-grouped
  history (TODAY / YESTERDAY / date — open tabs + archived sessions), pinned Settings.
- **Tab strip**: Genie's Desk · one tab per open chat (title = first user message ≤24 chars,
  ×) · + · right: dock / popout / minimize / maximize (popup: dock-back only).
- **Genie's Desk**: ACTIVE RISKS N (collapsible) — "✓ All clear…" at 0, else one row per
  unacknowledged alarm (severity chip, message, source, time; click → alarm drawer), re-rendered
  from `renderAlarms`; Genie's Read headline + cta; the grounding chip ("Context · …", click
  reveals the 4 facts inline) moved here from the composer.
- **Chat**: user = right-aligned dark bubble; Genie = plain text + action row (copy, 👍, 👎,
  regenerate — re-asks the previous user message through the provider); provider `actions`
  still render; new collapsible `details` block ("Show/Hide details").
- **Composer**: rounded input + round ↑ send, attach + mic kept; Desk placeholder "Type a
  question — it will open in a new chat tab" (sending from the Desk creates + activates a tab).
  Type-ahead chips (≤4, curated list + suggestion cards) above the composer while typing.
- **Settings popover** (above the rail's Settings item): Theme Dark/Light (chat-LOCAL:
  `data-chat-theme` on the chat root re-declares the token ramp only when it disagrees with
  the shell; shell untouched), Voice synthesis (speaks every reply via `genieSpeak(…,{greet,
  interrupt,force})` — never muted, independent of the herald Voice pref), Auto-expand details,
  Type ahead suggestions. Defaults dark / off / off / on.
- **Esc order**: settings popover → (rail search) → drawer (maximized restores first; docked
  chat is furniture, unchanged). Ctrl+G toggles as before. Reduced-motion: no transitions.

### Contract deltas (1.6.1 → 1.7.0)
- `WV.genie.register(provider)` reply contract is now `string | {text, details?, actions?}`:
  `details` = optional HTML rendered as a collapsible block under the reply, auto-opened when
  the chat's Auto-expand pref is on. The built-in demo responder returns `details` for alarm
  roll-ups.
- Storage keys added (namespaced): `genieTabs`, `genieActiveTab`, `genieRail`, `chatTheme`,
  `chatVoice`, `chatAutoExpand`, `chatTypeahead`. `genieChat` (legacy single conversation)
  is migrated into the first tab on first load and kept mirrored for the active tab.
- `genieSpeak(text, opts)` accepts `opts.force` (bypasses the `S.genieVoice` gate).
- Removed from the drawer: the header history / context drop menus (`menuGenieHist`,
  `menuGenieCtx`) — history lives in the rail, context facts in the Desk.
- New i18n keys (fr-CA / es-MX / ar / ja) for every rail / strip / Desk / settings / composer /
  action-row label and tooltip (Genie's Desk, Workspace, New chat, Search chats, Yesterday,
  Active risks, All clear…, the four setting titles + subs, footnote, both placeholders,
  Show/Hide details, Copy, Regenerate, Good/Poor reply, …).

### Verification (Playwright, channel=chrome, strict gate)
73-check suite (`verify_170.py`) run on the framework and ALL FIVE spliced products (ftm,
btm, ev, dlrmap, dlrline): 73/73 each. Covers: Ctrl+G → rail + Desk; All clear at 0 alarms;
`WV.demo.alarmStorm(5)` → 5 rows = unacked count, live re-render on ack, row → alarm drawer,
section collapse; OATI group → catalog views → openView; Desk send → new tab + reply with the
4-button action row + demo details; details toggle; thumbs; regenerate; New chat; Search
chats filter + Esc; tab close → archive → history restore + row activation; settings
popover (defaults), chat-local light theme (chat root tokens only, shell unchanged) + label,
voice synthesis via a speechSynthesis spy with the herald Voice OFF, auto-expand from a test
provider `{text, details, actions}`, type-ahead chips on/off + chip send; Esc order
(popover → drawer); docked (body flag, main margin, rail folded, toggle expands/collapses);
maximized (full workspace, 900px content column, Esc restores); minimize; popout renders
the same app (rail/tabs/Desk/composer, shared state, send from popup, settings, Esc) and
dock-back returns inline; shell theme round-trip; ja spot check (ジーニーのデスク /
ワークスペース / 設定 / アクティブなリスク / placeholder); Quick-Settings Genie card,
genieTop5, herald island, uiBusy intact; tabs + prefs persist across reload. Zero pageerror,
zero page-owned 4xx/5xx, zero console.error (Chrome's own /favicon.ico probe on the local
server is the only console line and is excluded by name). Screenshots: g170_<tag>_{desk_clear,
desk_risks,chat,settings,chat_light,autoexpand,docked,maximized,popup,ja,drawer}.png.

Spliced to all five products via the 9-chunk sentinel splice (stamps 1.6.1 → 1.7.0; the
1.6.1 state of each product is kept as `*.pre-1.7.0.html`; framework backup
`GenieApplicationShell.pre-1.7.0.html`).

## GenieAllDashboards (hub) 1.7.0 (2026-08-28) — the multi-product hub over the five converted dashboards

`E:\AI\Self\Genie\GenieAllDashboards.html` — ONE shell instance (framework 1.7.0, stamp
`1.7.0 2026-08-28`, `<meta name="wv-app-id" content="hub">` = own storage namespace
`wvfw.hub.*`) whose catalog spans all five converted Genie dashboards. Every product view
renders as a chromeless iframe of the converted file in `dashboards/` via the embed protocol
(spec §5). The dashboards themselves were NOT modified (md5 before == after, asserted).

### Structure
- Byte-exact copy of `GenieApplicationShell.html` 1.7.0: the nine `WV-SHELL` chunks are
  byte-identical to the framework's (asserted at build time); `<title>Genie — All
  Dashboards</title>` + the `wv-app-id` meta are the only `<head>` deltas.
- The framework's sample product + starter views are gone; the hub layer REPLACES the
  contents of the `WV-PRODUCT:BEGIN/END registration` block — `<style id="wv-hub-css">` +
  `<script id="wv-hub-js">` — i.e. OUTSIDE every WV-SHELL chunk, so `splice_111.py` can
  propagate future framework rounds (it is now in the script's target list; a dry splice on
  the fresh hub is a byte-identical no-op — md5 checked).
- The hub overrides framework behaviour only by re-binding global function declarations on
  `window` (`prefChanged`, `renderChrome`, `embedURL`, `openView`, `menuProduct`,
  `genieRailHTML`) — zero edits inside shell bytes.
- Framework Guide view: DROPPED (framework 1.7.0 itself retired its catalog entry on
  2026-08-20; the help menu's Documentation entry covers it). The framework's own Settings
  view stays (auto-registered under `Framework`, product `ftm` = PRODUCTS[0]).

### Product → file → views (identity values read at runtime from each product's own registerProduct)
| id | file | name · suffix · accent | views (embed ids) |
|---|---|---|---|
| ftm | dashboards/ftm_optimization_dashboard_wv1.1.html | GridLine FTM Optimizer · Genie FTM · #bb93ff | ftm.monitor ftm.forecast ftm.analyze ftm.all ftm.guide |
| btm | dashboards/btm_soc_forecast_dashboard_wv1.1.html | DER Availability — BTM SOC · Genie BTM · #6ba6e8 | btm.monitor btm.fleet btm.energy btm.accuracy btm.all btm.guide |
| ev | dashboards/ev_dashboard_wv1.4.html | Genie EV Charge Load Management · Genie EV · #bb93ff | ev.monitor ev.forecast ev.dispatch ev.fleet ev.analyze ev.all ev.guide |
| dlrmap | dashboards/dlr-genie-map_wv1.4.html | DLR Genie — Map · Genie DLR · Map · #bb93ff | dlrmap.map |
| dlrline | dashboards/dlr-genie-line-details_wv1.4.html | DLR Genie — Line Details · Genie DLR · #5B9BF0 | dlrline.details |

20 product views, groups/names/types/keywords verbatim from each product's `WV.registerViews`;
systems verbatim (6/6/7/4/4 rows). View + group labels registered through `WV.i18n.register`
in fr-CA/es-MX/ar/ja from the products' own dictionaries (shell keys on the English label, so a
label shared by several products — Monitor, Forecast, Fleet, Analyze, User Guide — carries ONE
translation hub-wide: first product in catalog order ftm → btm → ev → dlrmap → dlrline).

### Hub layer behaviour
- **Renderer `"*"`**: `iframe.wv-hubframe` on `dashboards/<file>#wv-embed=<viewId>&inst=<n>&theme=<t>&density=<d>`
  (relative — works from localhost:8890 AND file://, both verified) behind a veil (spinner +
  "Loading ‹product› · ‹view›") that lifts on `{wv:"ready"}`; 12 s fallback lifts the veil and
  leaves a muted corner "Still loading …" note until ready — never a dead panel. Each frame is
  a fresh product instance (second instances = `&inst=2`).
- **Parent → child**: on ready (deferred 400 ms past the child's script-parse-time ready) and
  on every shell theme/density/scale/accent/language change (`prefChanged` wrap):
  `{wv:"theme", theme, density, scale, accent}` with the PRODUCT's accent while the accent
  follows the product (a pinned accent is shared, like the shell), plus `{wv:"prefs"}`;
  `{wv:"time", hour}` on ready and on every shared-hour tick (every product view is
  time-subscribed).
- **Child → parent**: the shell's own embed listener files the raw message first (as for a
  popout); the hub listener runs right after and makes the record hub-true — alarm `source`
  rewritten in place to `‹Product name› · ‹source›` (product name alone when the child sent
  none), `srcView` = the frame's view, crit/maj toast; system state confirmed on the
  SENDER's rows and every other product sharing the id restored to its own last relayed
  state (dlrmap/dlrline share `dlr-*` ids). Alarm ack/clear stays hub-side. Counters:
  `WV_HUB_STATS` {frames, ready, timeouts, themeCasts, prefsCasts, timeCasts, alarmsRelayed,
  systemsRelayed, switches}; `WV_HUB_LIVE` = uid → frame record.
- **Product switching**: the top-left lockup dropdown (`#wv-prodBtn` → overridden
  `menuProduct`) lists the five products with accent swatch, dependent-system dots (live
  state) and live-frame count; a NEW compact chip `#wv-hubProdChip` (accent dot + product
  suffix + caret) is inserted as the first control of the header's session pod (before
  sign-out and the user menu) and opens the SAME dropdown (`data-wv-act="prod-menu"`). The old
  webVisionHub had no right-side control — the chip is the hub's addition. Switching runs the
  framework's own `prod-set` path (accent re-brand, catalog scope, menu sync, notification).
  Opening a product view of a non-active product (voice "open ‹view›", palette, Genie rail,
  favorites, recents, alarm rows) switches product first, then opens; the framework Settings
  view never switches.
- **Genie Chat** OATI ▾ lists the hub-wide catalog grouped by product (swatch + name heading,
  active product highlighted, live views dotted). Desk "Active risks" = the hub's unacked
  alarms (relayed ones included). No hub chat provider (framework responder answers).
- **Popouts**: `embedURL` override → the shell's `popOut` opens the CONVERTED FILE's embed URL
  in a real window; the popout is re-briefed with its product accent after the shell's brief.
- **Genie's Read** at hub level: one fleet read stamped (silently) under every product id —
  counts, dependent-system worst state, frames on screen, "open the fleet grid" cta.
- **Palette actions**: `hub:open-<pid>` "Open ‹product› home" ×5.
- **Startup**: `WV.start({product:"ftm", startupWs:null})` — EMPTY launchpad, ftm in the
  lockup; login greeting unchanged; workspaces save per product; session resume works in the
  hub namespace (frames remount on reload).
- Zero external requests from the hub (tokens only). Note: the BTM Fleet basemap tiles are the
  product's own Leaflet/Carto behaviour inside its frame — unchanged product content.

### Verification (Playwright, channel=chrome, strict gate) — `verify_hub.py`, 108/108
boot → launchpad · 5 products with identities · 20-view catalog · systems rows · hour-bus
subscriptions · ja labels · lockup dropdown (5 rows, 5 swatches, 27 system dots, ftm current)
· right chip first in the session pod + opens the same dropdown · per product ×5: switch
(S.product, html[data-product], chip label, catalog scope) → home view → exact embed src →
veil → `{wv:"ready"}` (0.5–2.4 s) → veil lifted → child chromeless (`body.wv-embed`, `EMB.on`)
→ theme+prefs brief on ready with the product accent → second view (ftm.forecast,
btm.fleet, ev.dispatch) or second INSTANCE (`&inst=2` for the single-view dlrmap/dlrline) →
health popover rows · mixed-product split (ftm.monitor + btm.fleet): btm's own
device-telemetry=degraded relayed into btm rows only · theme light / density comfortable /
scale 110 / accent teal → children's `html[data-theme|data-density]`, `S.scale`, `--wv-acc`,
message accents (per-product vs pinned), 8 themeCasts · back to defaults · shared hour →
children `WVTime.hour` · child `WV.raiseAlarm` → hub drawer with "GridLine FTM Optimizer ·
Test Source", relayed exactly once, empty source → product name, srcView = frame view,
drawer + Genie Desk Active risks, ack hub-side (child store untouched) · OATI ▾ 5 groups / 20
views / live + active markers, rail click on a foreign view switches + opens · Settings view
never switches · voice `earCommand("open the line details")` (ev active) → dlrline switched +
opened, `"open network map"` → dlrmap · 5 frames live across 4 products · child
`setSystemState('dlr-weather','stale')` from dlrmap → dlrmap row only, chip STALE · palette
actions ×5 · hub read under every product · popout → `dashboards/ftm_…#wv-embed=ftm.forecast`
real window, ready-tracked, chromeless, product accent · workspace saved under the active
product in `wvfw.hub.userWs` · 43 `wvfw.hub.*` keys · reload keeps product + resumes the 5
views, all frames ready · 12 s timeout fallback (about:blank frame): veil lifted + "Still
loading" note · ZERO pageerror, ZERO console.error, ZERO in-frame onerror/unhandled
rejection, ZERO page-owned 4xx/5xx across hub + every child frame + popup (Chrome's own
/favicon.ico probe is the only console error line and is excluded by name) · dashboards md5
before == after. Plus `verify_hub_file.py`: file:// boot + child ready, zero errors.
Screenshots (scratchpad): hub_01_launchpad, hub_02_lockup_dropdown, hub_03_right_chip_dropdown,
hub_04_{ftm,btm,ev,dlrmap,dlrline}_home, hub_05_{…}_two_views, hub_06_light_split,
hub_07_alarm_drawer_relay, hub_08_genie_oati_grouped, hub_09_fleet_grid,
hub_10_health_dlrmap_stale, hub_11_popout_ftm_forecast, hub_12_after_reload,
hub_13_timeout_note, hub_14_file_protocol.

### Propagation
`splice_111.py` targets now include `GenieAllDashboards.html` (paths relative to the Genie
home; `--dry [paths…]` reports CHANGED / no-op with md5s and writes nothing; live runs skip
byte-identical files and name backups `.pre-<oldver>.html`). Dry run on the fresh hub and on
all five dashboards: no-op (byte-identical). Build script: `build_hub.py` (+ `hub_identity.json`
read at runtime from the five products) in the session scratchpad.

## Framework 1.7.1 — embed-mode guard fix + hub landing (2026-08-28)

- **Root cause (framework, since 1.0.x):** the shell's embed-mode state was `const EMB` — never on
  `window` — so every product's native-nav guard `if(window.EMB&&EMB.on)return` was dead inside
  embeds. A mode-bar click inside a hub frame or a popout window fell through to the shell's
  `openView`, which mounted a second panel and moved the product root out of `#wv-embedRoot`:
  blank display. Fix: `window.EMB=EMB` right after the declaration (js-core chunk).
  Effect: inside embeds the product's mode bar now switches the display IN PLACE (native
  `applyMode`); standalone, the bar still routes to shell tabs (unchanged).
- **Hub landing:** `GenieAllDashboards.html` now boots with an inline startup workspace
  `hub-home` (ftm · Monitor) — a fresh login lands on the first product's default view;
  session resume (pref ON) still wins. Note: workspace `views` are catalog NAMES
  (`loadWs → viewByName`), not ids.
- Propagated by `tools\splice_shell.py` to ftm/btm/ev/dlrmap/dlrline + hub (1.7.0 → 1.7.1);
  `.pre-1.7.0.html` backups kept beside each file. Verified: hub fresh login → `ftm.monitor`
  frame ready; Forecast/Analyze/All/Monitor clicks inside the frame keep the root mounted and
  re-filter cards; popout window mode click likewise; all five dashboards standalone boot on
  1.7.1 with zero errors and their mode bars still open shell tabs.

## Hub — exclusive product display + memory hygiene (2026-08-28, hub layer only)

- **Product switch = exclusive display.** Selecting a product (lockup dropdown, right-side chip,
  or any foreign-view open via voice / palette / Genie rail) closes every open view of the other
  products first — their frames are torn down (`src="about:blank"` then removed, LIVE record
  dropped) — and the selected product's HOME view opens (dropdown/chip path); an openView-driven
  switch opens only the requested view (`HUB.pendingOpen`). Re-selecting the active product is a
  no-op. `WV_HUB_STATS.closedOnSwitch` counts closures.
- **Every view close releases its document** (same teardown) — the frame tree returns to
  baseline immediately, not at GC time.
- **Relayed-alarm dedupe.** Each switch boots a fresh product instance that re-raises its startup
  alarms; the hub now keeps ONE unacked record per (product·source, severity, message) — the
  newest — `WV_HUB_STATS.alarmsDeduped`. Before: 39 duplicate cards after 10 switches (alarm
  drawer DOM +352 nodes); after: alarm count flat at 16 across 3 full rotations.
- Measured over 3 rotations through all five products (15 switches): iframes 1, frame tree 2,
  hub DOM nodes flat (1366), JS heap flat (~55 MB), zero errors. Standalone products are
  unaffected (their singleton roots park by design; nothing to release).

## Framework 1.7.2 — catalog follows the active product (2026-08-29)

- `visibleCatalog()` now scopes to the selected product when more than one product is registered
  (hub): the command palette, sidebar nav, launchpad counts and favorites list only the active
  product's views plus framework views (`isFrameworkView`: Settings / path "Framework").
  Single-product files are unaffected (ev standalone: 8 views before and after).
- Cross-product reach stays on the purpose-built paths: product switcher (lockup / chip), the
  palette's "Open <product> home" actions, the Genie Chat product groups, and voice
  (`genieOpenByName` resolves hub-wide over `S.catalog.filter(allowed)` — verified: "open the
  line details" from ev switches to dlrline and opens it).
- Propagated to all six files (1.7.1 → 1.7.2). Verified hub: ftm → 6 views, switch to ev → 8
  views, zero errors.

- Hub 2026-08-29: right-side product chip retired (duplicate of the top-left lockup switcher); `hubMakeChip` no longer called, `hubSyncChip` is a safe no-op without the element.

## Framework 1.7.3 — header: status + Info pods right of the genie (2026-08-29)

- `#wv-podStatus` (system-health chip + market clock) and `#wv-podInfo` moved from the left
  cluster (after search) to immediately RIGHT of `#wv-podGenie`, ahead of the utility pods
  (bell/inbox hidden by default → help/keys → session). Markup-only move in the app chunk;
  CSS untouched. Propagated to all six files; verified geometry genie < status < info < session
  on hub + ftm, zero errors.

## Framework 1.7.4 — browser tab title = selected product (2026-08-29)

- `renderChrome()` sets `document.title = "OATI " + product.name` once signed in (not in embed
  mode — popouts keep "<view> — <product>"; the login page keeps the file's own title).
  Hub: login → "OATI GridLine FTM Optimizer", switch → "OATI DER Availability — BTM SOC",
  voice cross-product → "OATI DLR Genie — Line Details". Standalone files follow the same
  format after login. Propagated to all six files, zero errors.

## Framework 1.7.5 — sign-in session (2026-08-29)

- `AUTH` (js-core, next to `store`): signing in saves `{name, initials, at, exp, remember, start}`
  under `wvfw.<ns>.auth` — "Remember me" → localStorage, 7-day SLIDING expiry (survives closing
  the browser, shared by new tabs); unchecked → sessionStorage, 12-hour expiry (survives refresh,
  ends with the tab). `bootShell` resumes a live session straight into the app (silent resume:
  no spoken welcome again, quiet window shortened); `doLogout` clears it; expiry falls back to
  the login page. The QS "signed-in since" stamp persists in the record.
- Verified (hub + btm standalone): refresh keeps the app + open views + title; new tab → login
  for a tab session, signed in for a remembered one; sign-out → login; backdated expiry → login;
  zero errors. Propagated to all six files. Sessions are per file namespace (hub vs each
  standalone dashboard), like every other preference.

## Framework 1.7.6 — Info mode: Docked panel (2026-08-29)

- **Chooser**: the header ⓘ is a split control. Click toggles Info mode (as before); the slim caret
  beside it (`#wv-infoCaret`, `data-wv-act="info-menu"`) or a right-click on ⓘ opens the "Info panel"
  dropdown — *Floating card — Appears next to whatever you click* · *Docked panel — Pinned to the
  right, page makes room* (icon, title, sub-label, check on the active row). Pref `S.infoDock`
  (`"float"` | `"dock"`, stored `wvfw.<ns>.infoDock`, default float, in `PREF_DEFAULTS`/reset), also
  a *Info panel* row in Quick Settings › Behavior, palette actions "Info: floating card" /
  "Info: docked panel", and `WV.info.present("float"|"dock")`. Choosing a presentation turns Info
  mode on if it was off.
- **Docked panel** `#wv-infoDock` (overlays chunk; `role="region"`, aria-label "Info panel", focus
  never trapped): right side, 430px default, drag grip 340–720 (dblclick resets; stored
  `infoDockW`). Header = INFO pill + component title + kind chip + pin toggle + close ×. Open exactly
  while Info mode is on AND the presentation is dock (never while presenting). Hover fills it
  (unpinned); click PINS (solid outline `[data-wv-info-pinned]`, hover ignored) — click the pinned
  component again or the pin button to release. Close × / Esc leave Info mode (Esc keeps its
  existing first-in-order slot). The floating card is never shown in dock mode.
- **Layout**: same mechanism as the docked chat — `body[data-wv-infodock]` + `--wv-idock-w` drive
  `#wv-main{margin-right}` (hub iframes shrink with their panels; no horizontal scroll). With the
  chat ALSO docked, the chat keeps the window edge and the info panel docks immediately inside it;
  both widths add on the main margin.
- **Content contract** (`WV.info`): `describe(key, entry)`, `describeMany({key: entry})`,
  `resolve(fn(key, el) → entry|null)` for live-computed keys, `get(key)`, `present(v)`,
  `presentation()`. `key` = a CSS selector (matched against the hovered element and its
  ancestors — a selector entry WINS over the element's own `data-info` facets) or a token matched
  against `data-info-key` (or a product's raw `data-info` value). `entry = {title, kind?, plain,
  what, why, how, read, healthy, concerning, health?, wrong, terms, related}` — values are trusted
  HTML strings; `terms` = `[[term, definition], …]` or an HTML string; `health` = one card when
  healthy/concerning are not split. Sections render in the fixed order IN PLAIN TERMS · WHAT IT IS ·
  WHY IT MATTERS · HOW IT IS CALCULATED · HOW TO READ IT · HEALTHY VS CONCERNING (green/red twin
  cards) · IF IT LOOKS WRONG · TERMS USED HERE (bold term — definition) · RELATED, absent ones
  skipped; labels are i18n (fr/es/ar/ja). The floating card shows title + IN PLAIN TERMS for
  described entries.
- **Facet fallback** (`data-info="Title|What it is|How to use|How it is calculated|Healthy vs
  abnormal|Depends on"` keeps working, floating card unchanged): in the dock facet 1 → IN PLAIN
  TERMS, 2 → HOW TO READ IT, 3 → HOW IT IS CALCULATED, 4 → HEALTHY VS CONCERNING (split into the
  two cards on the "Healthy: … Abnormal: …" convention, else one card), 5 → RELATED.
- **Framework chrome described** (js-app tail, `WV.info.describeMany`): search, product lockup,
  workspaces, alarms bell, genie lamp, market clock, realtime link, the Info pod itself — every
  section demonstrated on every file that embeds the shell.
- **BTM bridge (product-side delta, applied)**: the product closure exports `infoFor` +
  `infoKeys()` on `window.btmShell` (one line in the product JS) and the registration block maps
  the product's INFO registry (`t/p/w/y/c/r/ok/no/h/a/g/d`) through `WV.info.describeMany` + a
  `resolve` for live `driver:*` rows; the product's own `#infopop` is hidden while
  `body[data-wv-infodock]` (CSS in the registration block). KPI cards / panels / filters show the
  real sections in the dock.
- Verified (Playwright, strict zero errors): framework 60/60 checks — chooser + persistence across
  reload, float unchanged, dock hover/pin/unpin/close, width + no h-scroll, chat dock + info dock,
  Esc order, all 9 labels + facet fallback, ja labels, reduced motion, grip, present mode, reset;
  hub: iframes shrink to the dock edge, rich sections + pin over a product frame; BTM: `kpi:soc`
  renders all 9 real sections, terms parsed into pairs, click pins. ftm / ev / dlr-map / dlr-line
  smoke: dock opens, 9 sections, Esc leaves, zero errors. Propagated to all six files.

## Framework 1.8.0 — OATI Genie chat component replaces the built-in chat (2026-08-29)

Scope this round: `GenieApplicationShell.html` (1.7.6 → 1.8.0) and the hub
`GenieAllDashboards.html` (spliced, product block adjusted). The five dashboards are held at
1.7.6 (see Pending propagation). Backups: `GenieApplicationShell.pre-1.8.0.html`,
`GenieAllDashboards.pre-1.8.0.html`.

### File layout (CEO directive: config + shim are SEPARATE files, one copy each)
- `chat/oati-genie-chat-widget.js` — the pre-built bundle (untouched; light-DOM React, custom
  element `<oati-genie-chat-widget>`, host API `window.__GENIE_WIDGET__`).
- `chat/genie-config.js` — `window.WV_GENIE_CONFIG` = `{enabled, mode:"connected"|"offline",
  bundle (override, null = loader default), ragBaseUrl 'http://aniketsa-d.dev.oati.local',
  ragServerPath '/network_api', userId, organizationId, settings (the former
  DEFAULT_GENIE_SETTINGS), channels (STATIC_CHANNELS), persistenceKey (null → shell derives
  `wvfw.<app-id>.genie`), title 'Genie', description, position {right:16,bottom:36} (clears the
  status bar), dimensions (null = 884×800)}` — THE single edit point.
- `chat/genie-rag-shim.js` — `window.WV_GENIE_SHIM.install()` — the fetch shim carried over
  verbatim from `chat/index.html` (GetGenieSettings, channel/list|selected, OATIClientVar/*,
  Genie/UserPrompt → /api/v1/chat + /Conversations/Get, UserChatHistoryList, GetUserChatHistory,
  UpdateChatHistory, GroupsList, UserFeedback), now reading `WV_GENIE_CONFIG`; intercepts ONLY
  those paths — the shell's own fetches are untouched. Installed only in connected mode.
- `chat/index.html` — the standalone demo now loads the two files above (no inline copies);
  its Desk injector keeps working (verified).
- The shell-side bridge stays INSIDE the framework's `js-app` chunk (it needs shell internals:
  `S.alarms`, `S.sysHealth`, `renderAlarms`, `prefChanged`, the lamp) — no `genie-shell-bridge.js`.

### Shell loader + lifecycle (js-app chunk)
- `WV_GENIE_LOADER = {config:"chat/genie-config.js", shim:"chat/genie-rag-shim.js",
  bundle:"chat/oati-genie-chat-widget.js"}` — paths relative to the host file (http and file://
  both verified); `WV_GENIE_CONFIG.bundle` overrides the bundle path. `genieBundleLoad()` loads
  config → shim → bundle sequentially, once, warmed at `bootShell` while the login page shows.
- `genieMountWidget()` runs from `enterApp` (AFTER sign-in, never in embeds — `EMB.on` returns):
  `<oati-genie-chat-widget enable-launcher="false" enable-fullscreen enable-resize
  enable-persistence persistence-key="wvfw.<ns>.genie" default-theme=S.theme
  default-motion=reduced|full title="Genie" position/default-dimensions api-endpoint=(connected
  only) data-wv-i18n-off>`; the Desk is pre-set before the first render. Sign-out
  (`doLogout`) → `genieUnmountWidget()` = close + `resetState()` + element removed until the next
  sign-in. Missing bundle (404/offline) → toast "Genie chat component not found (‹path›)" at the
  lamp click, nothing else breaks (verified with a routed 404).
- Entry points → the widget: lamp click, Ctrl+G, palette "Open Genie assistant", voice
  "open the chat" (`GENIE_CMDS` id `chat`), `openGenie(tab?)` / `closeGenie()` /
  `toggleGenie()` / `genieVisible()` are the shell-side wrappers over
  `__GENIE_WIDGET__.open/close/getState().isOpen`. Esc closes the widget in its old slot (after
  QS, before the alarm drawer); inside the panel the widget's own Esc runs first. Opening the alarm
  drawer / Quick Settings closes the widget (one right-edge surface), as before.
- Theme/motion: `prefChanged` → `setTheme(light|dark)` + `setMotion(reduced|full)`
  (`data-genie-theme` / `data-genie-motion` on `<html>` follow the shell). Presentation mode
  closes the widget. `WV.uiBusy()` counts an open widget.
- **Z-order**: the bundle portals its panel into `<body>` under `.genie-widget-scope` with an
  inline `z-index: 9999` (below the shell's 100000+ band, so the header would poke through in
  fullscreen). The css chunk lifts it: `.genie-widget-scope [style*="z-index: 9999"]
  {z-index:100090!important}` → above the app chrome (header 100060), below the login screen
  (100100), the Info dock / Quick Settings / palette / modals (100280+) and toasts. The herald
  island is unchanged.
- **i18n hands-off**: `applyI18n` (text walker + attribute pass) skips `.genie-widget-scope` and
  `[data-wv-i18n-off]` — the walker's text-node stash fought React's in-place text reuse (blank
  Desk rows / wrong tab labels). Verified: fr-CA translates the chrome, the widget stays English.

### Desk + alert bridge (`WV.genie`)
- Automatic Desk feed (debounced 150 ms; from `renderAlarms` — i.e. addAlarm / ack / ack-all /
  clear —, `WV.setSystemState`, `prefChanged`): every UNACKED alarm → Active-risks item
  `{id:"alarm:<id>", title = first sentence ≤ 90 chars, channelLabel = alarm.src (hub sources are
  already "‹Product› · ‹source›"), status tone crit→severe / maj→warning / minr→attention /
  info→info, timestamp = alarm market-time stamp "hh:mm:ss EPT", detail.summary = message +
  source + view + severity + stamp, detail.actions = ["Open alarms" → closes the widget, opens
  the drawer]}`; every degraded/stale dependent system (all products) → Monitoring item
  `{id:"sys:<pid>:<sysId>", title "‹System› ‹state›", channelLabel = product name, tone
  stale→warning / degraded→attention, action "System health"}`; the Monitoring section renders
  only while `monitoringCount` is present. Acknowledging in the shell removes the item.
- `WV.genie.desk.add(item) / remove(id) / clear() / set(items) / push() / items() / content()` —
  host items `{id, title, channelLabel?, tone?: severe|warning|attention|info, statusLabel?,
  timestamp?, summary?, container?: "activeRisks"|"monitoring", actions?:[{id?, label, run}]}`
  live in their own list merged IN FRONT of the shell items.
- `WV.genie.alert(alert) / dismissAlert(id)` — in-widget alerts (Desk › alerts list + the Desk
  tab badge): `{id, headline (title/message accepted), description, severity, channelLabel?,
  timestamp?, canAcknowledge, learnMoreHref, showAskGenie (default false), secondaryAction,
  actions:[{label, run}]}`. **Bundle facts learned**: the alert vocabulary is `elevated | high |
  severe` (NOT the Desk tones — an unknown severity crashes its peek canvas: `t.deep` pageerror),
  and the label fields are `headline`/`description` (not title/message) — the shell maps shell
  severities (crit/maj/minr/info) and Desk tones onto it. Crit/maj alarm ARRIVALS are mirrored as
  in-widget alerts ONLY while the widget is open (acknowledge there acks the shell alarm); the
  herald island stays the shell's transient surface.
- `WV.genie.open(tab?) / close() / isOpen() / element()`; `WV.genie.register(provider)` is a
  documented NO-OP (returns false, one console.info) — the chat brain is the OATI Genie service.
  `registerSummarizer` / `registerCommand` unchanged.

### Retired
`#wv-genie` drawer markup + its CSS block (≈370 lines), `genieAppHTML` / `genieMount` /
`renderGenieDesk` / `genieDeskHTML` / rail / tabs / settings popover, `GENIE` / `GCHAT` /
`GSESS` state, the demo responder + streaming, the `GPOP` popup window, dock (`data-wv-dock`,
`--wv-dock-w`) + maximize + grip, the `genie-*` dispatcher router, the chat-local prefs
(`chatTheme`, `chatVoice`, `chatAutoExpand`, `chatTypeahead`, `genieDock`, `genieMax`,
`genieRail`, `genieTabs`, `genieSessions` — stale keys are ignored), `GREAD_AI_INFO`. Kept:
the lamp (ring/aura/mic/herald), `genieSpeak`, `genieLoginGreet`, `cmdSay`, `genieTop5`,
`GENIE_CMDS`, `earCommand`, Genie's Read + alarms; the QS Genie card (lamp settings incl.
"Chat icon in header") is unchanged. What's-new (1.8.0 row), Framework Guide (Genie layer
section, API table, services row, `SNIP.genie`), the lamp's Info-mode entry and the sample
product (a "Sample: file a Desk item" palette action instead of a provider) were rewritten.

### Verification (Playwright channel=chrome, strict gate) — `verify_180.py`, 72/72
Error policy applied: zero `pageerror`; `console.error` tolerated only for Chrome's
`/favicon.ico` probe (the one line seen) and network failures to `aniketsa-d.dev.oati.local`
(none occurred — the RAG host answered, so the widget's history list is real). Framework: stamp,
`#wv-genie` null, config/shim/bundle requested from `chat/` before sign-in with NO mount, mount
after sign-in with the expected attributes, lamp / Ctrl+G toggle / Esc-before-drawer / voice
"open the chat" / palette action + hint, theme + reduced-motion follow, `alarmStorm(5)` → 5
items with correct tones/labels/channels/summaries/actions, ack → 4, degraded → Monitoring
(attention, product channel) → stale (warning) → live (section gone), `desk.add` first (+
monitoring container, items/remove), detail view + host action, "Open alarms" → drawer,
fr-CA leaves the widget alone, `WV.genie.alert` → row → select → description + Acknowledge +
action runs, `dismissAlert`, crit mirrored only while open, `register` no-op, presentation
closes, `popOut` (own "Genie Chat" window) / `popIn`, sign-out unmounts / re-sign-in
re-mounts with the Desk intact, herald/voice/Read functions intact, Guide text, embed mode
never mounts. Hub: stamp, `wvfw.hub.genie`, no rail override, alarms from two products with
product-prefixed channels, product switch keeps items until ack, widget over a product frame
in the 100090 band, ack-all empties, `ftm-kafka` degraded → Monitoring "GridLine FTM
Optimizer" while `btm` is active. file:// smoke (bundle loads relative, opens). Missing-bundle
degradation (routed 404 → toast, shell alive). `chat/index.html` demo smoke (shared config +
shim, injector, zero errors). Dashboards md5-identical before/after.
Screenshots (session scratchpad `shots\`): `fw_widget_open.png`, `fw_desk_risks.png`,
`fw_desk_detail.png`, `fw_alert.png`, `fw_alert_selected.png`, `fw_widget_light.png`,
`hub_widget_over_frame.png`, `fw_missing_bundle.png`, `chat_index_demo.png`.

### Bundle behaviour worth knowing
- Offline mode (no `api-endpoint`) = the bundle's demo component: replies are `Echo: ‹text›`
  after a "Reading your message / Thinking it through" beat; Desk + alerts work the same.
- The Desk renders `timestamp` verbatim (no parsing) — the shell passes its market-time stamp.
- Host-pushed alerts render in a Desk section whose header shows only the count (the bundle
  gives that section no label); the Desk tab carries a severity badge for the newest alert.
- `resetState()` also resets the persisted position/size; `popOut` opens a same-origin
  window titled "Genie Chat" that mirrors the panel.

## Framework 1.8.1 — widget portals lifted above the chat panel (2026-08-29)

- The OATI chat component portals its sidebar Settings popover, channel picker, menus and tooltips
  straight into `<body>` at its own z scale (~10000). 1.8.0 lifts the chat panel to 100090 (so the
  header cannot show through in fullscreen) — which buried those portals: "Settings does nothing",
  "channel dropdown does not open". Fix: `geniePortalWatch` (MutationObserver on body while the
  widget is mounted) lifts every non-shell fixed/absolute body child the component adds to 100095
  (above the panel, below the login screen at 100100 and the shell's modals). Class-name agnostic
  (the bundle's class names are build-hashed). Framework + hub only (dashboards still held at 1.7.6).

## Framework 1.8.2 — "Genie voice commands" link in the identity card (2026-08-29)

- Quick Settings identity card: a link row (mic icon + "Genie voice commands" · "everything you can
  say to Genie") directly below Language; click → the Voice commands overlay (`vcmds`). i18n in
  fr/es/ar/ja. Framework + hub (dashboards still held at 1.7.6).

## Framework 1.8.3 — Settings fills the page · motion + ring defaults (2026-08-29)

- Settings view: masonry columns follow the viewport (`columns:480px 4`, no max-width) — 2 / 3 / 4
  columns as width allows, no empty right band in Full View.
- Reduce motion defaults to OFF (no longer seeded from the OS `prefers-reduced-motion` hint; the
  operator opts in). `genieMotion()` follows the shell pref only.
- Genie ring colour default = the solid accent ring ("violet"), was the animated brand gradient.
- Framework + hub (dashboards still held at 1.7.6).

## Framework 1.8.4 — Settings view mirrors Quick Settings (2026-08-29)

- The full Settings view now renders the SAME cards in the SAME order as Quick Settings:
  identity → Appearance → Genie assistant (was missing) → Display → Regional & formats → Data →
  Header icons → Behavior → About → Session (last, with Reset preferences).
- Genie sliders (lamp size, read twinkle) are id-free (`data-wv-range` / `data-wv-rangeval`) so the
  card renders in both surfaces at once without duplicate ids; handlers update the label beside the
  slider that moved. Framework + hub (dashboards still held at 1.7.6).

## Framework 1.8.5 — identity card: plain background (2026-08-29)

- The accent dot-texture overlay on the Quick Settings / Settings identity card is retired; the card uses the same plain ground as every other card. Framework + hub.

## Framework 1.8.6 — balanced Settings columns (2026-08-29)

- The Settings view packs its cards into explicit columns (`.wv-set-col`, count from the viewport:
  ~460px min per column, max 4) with a "next card → shortest column" pass (`settingsPack`), keeping
  the Quick Settings sequence. Column bottoms stay even; the tall Genie assistant card lands at the
  top of a column. Re-packs on resize (ResizeObserver, width band ≥ 24px) and when the filter hides
  rows. Framework + hub (dashboards still held at 1.7.6).

## Framework 1.8.7 — Halo lamp dots crisp (2026-08-29)

- The Halo lamp style's LED dot backdrop breathed between 50% and 85% opacity and read as faded; now 88%–100% (unread: 95%–100%). Framework + hub.

## Framework 1.8.8 — wider Voice commands panel (2026-08-29)

- `#wv-vcmds` box widened to min(1240px, 94vw) with two equal columns, phrase column 262px and the description column flexible (min 220px) so descriptions read on one or two lines; single column under 1100px. Framework + hub.

## Framework 1.8.9 — Info mode in product frames + E2E regression (2026-08-29)

Scope: `GenieApplicationShell.html` 1.8.8 → 1.8.9, propagated by `tools\splice_shell.py` to ALL six targets
(hub 1.8.8 → 1.8.9; the five dashboards 1.7.6 → 1.8.9 — **the 1.8.0 hold is lifted**, see Pending propagation).
Backups: `GenieApplicationShell.pre-1.8.8.html`, `GenieAllDashboards.pre-1.8.8.html`, `dashboards\*.pre-1.7.6.html`
(+ `.pre-1.8.9.html` intermediates from the re-splices of this round).

### Info mode reaches the product frames (framework + hub layer)
- **Protocol (spec §5 updated).** Parent → child `{wv:"info", on, mode:"float"|"dock", pin?}` — sent with the
  theme/prefs brief on `{wv:"ready"}` (a frame adopted while the hub is off gets `on:false`) and on every
  Info toggle / presentation change (`toggleInfo`, `infoDockSet` → `broadcastInfo()`; the framework reaches
  its popouts, the hub layer wraps `broadcastInfo` and `briefFrame` to reach every live iframe —
  `WV_HUB_STATS.infoCasts`). Child → parent `{wv:"info-item", title, kind, sections:{plain, what, why, how,
  read, healthy, concerning, health, wrong, terms, related}, pinned}` on hover (unpinned) / click (pinned) and
  `{wv:"info-clear"}` when the pointer leaves the frame with nothing pinned, `{wv:"info-exit"}` on Esc inside the
  frame (the parent leaves Info mode everywhere).
- **Child (embed mode).** `{wv:"info"}` drives the SAME Info machinery inside the frame — `body[data-infomode]`
  outlines, facets, rich entries, the product's own explainer through `wv:info`. `float` → the frame shows its
  own card (the product's, or the shell facet card). `dock` → the frame never opens `#wv-infoDock` (hidden by
  `body.wv-embed`, together with `#wv-infoBanner`); `renderInfoDock` posts the entry upward instead and
  `body[data-wv-infodock]` is still set so products hide their own pop under the shell dock. `pin:false`
  releases the child's pinned component; Info off clears every outline and pin in the child.
- **Parent.** `infoRemoteItem` renders a frame's entry in the docked panel exactly like a local one
  (`renderInfoDockEnt` — title, kind chip, all sections, pin state); a pinned panel ignores hover from any
  surface; the pin button toggles the frame's pin over the protocol; a local hub chrome hover/click replaces a
  frame's entry (last message wins — the frame is told `pin:false`); Esc / close × turn Info off everywhere.
  Popouts follow the same protocol (Info on + float → their own card; dock → they feed the opener's panel).
- **Chat loader path-resilient.** `WV_GENIE_LOADER.bases = ["", "../"]`: the config load probes `chat/` beside
  the host file, then `../chat/` (`GWID.base`); shim + bundle follow the resolved base; the "Genie chat
  component not found" toast stays when neither exists. The five dashboards share the one `chat\` folder —
  no copy/junction, no `WV_GENIE_CONFIG.bundle` override.
- **Product-side deltas (outside the sentinels):** ftm — `WV.info.resolve` over the product's `infoEntry(el)`
  (kind/title/basics/what/why/calc+formula/read/ok/no/wrong/terms/rel → the shell entry shape; terms parsed
  into pairs) + `body[data-wv-infodock] #ftm-root .info-card{display:none}`; ev — `evShell.infoEntry` export +
  the same bridge and CSS. btm already bridged (1.7.6); dlrmap/dlrline expose facets only.
- Docs: What's-new row, Framework Guide embed table (+3 rows), hub product-block prose, spec §5, the
  update skill (hold lifted, loader fallback, durable suite, 1.8.x release history), skills synced.

### Root-cause fixes found by the regression (framework, propagated)
1. **Voice grammar (1.6.x):** the documented fr "Ouvre les alarmes" / es "Abre las alarmas" fell through to the
   generic opener (no view named "alarmes" → "no view" reply); es "Comparte las 5 notificaciones principales"
   never matched (`notificación` vs the unaccented plural). `alarms`/`notifs`/`chat` accept
   ouvre/affiche/montre/abre/muestra/اعرض; `notificaci[oó]n`. The suite now audits every documented phrase in
   all five languages against its English twin (84 phrases).
2. **Under-filled arrangements (1.0.x):** one view in a `split` / `mainside` / `cols3` / `grid` / `grid6`
   workspace rendered in ONE slot (half or a third of the display — the Settings view "filled the page" only in
   `tabs`). `#wv-panels[data-n]` = visible panel count (renderPanels/focusPanels) + CSS collapses the grid to
   the visible count; an arrangement is a cap, not a mandate.
3. **`?` hotkey (1.0.x):** toggled `#wv-keys` without `renderProdKeys()` — on a fresh page the sheet opened
   EMPTY until the help menu / keys button had rendered it once. Renders before toggling.
4. **Settings re-pack (1.8.6):** `settingsPack` re-read the cards in column-major DOM order on every
   ResizeObserver / filter re-pack, scrambling the Quick Settings sequence after one resize (the tall Genie card
   fell mid-column). Cards remember their template sequence (`data-wv-seq`) and are sorted before packing.
5. **Esc inside a frame (1.8.9 protocol gap, hub):** with keyboard focus inside an embedded frame (the operator
   clicked in it), Esc left the CHILD's Info mode but the hub stayed in Info mode with its panel open. The
   child now posts `{wv:"info-exit"}`; the parent leaves Info mode and re-broadcasts off everywhere.
6. **Resolver precedence (1.7.6 contract):** `WV.info.resolve` resolvers were consulted for EVERY annotated
   element, so a product resolver with an honest "This component" fallback (ftm/ev bridges) answered for
   shell chrome (`#wv-clock`) ahead of the framework's own rich entry. Resolvers now run only inside
   `[data-wv-product-root]`; the ftm/ev bridges are additionally gated on their roots.
Screenshots (session scratchpad `shots\`): `fix_split_single_view_before/after.png`,
`fix_settings_repack_before/after.png`, `fix_question_key_sheet_before/after.png`.

### Durable suite — `tools\verify_shell.py` (new)
One file, any shell-integrated URL, per-feature tally, `--only`, `--smoke`, `--json`. Default set = framework
(deep) · hub (deep) · five dashboards (boot smoke) · hub `file://`. **Error policy (strict, whole run, page +
every frame + every popup):** zero `pageerror`; `console.error` tolerated ONLY for Chrome's `/favicon.ico`
probe, network errors to `aniketsa-d.dev.oati.local`, and the loader's designed `chat/genie-config.js` probe
404 on a subfolder file (asserted to resolve `GWID.base === "../"`). Deep coverage: login variants A–D +
remember me + greeting, launchpad/favorites/recents, palette (search, actions, tabs, Enter, Shift+Enter popout),
sidebar both orientations + mega menus + Ctrl+B, views open/close/cycle/pin/maximize + content states + all six
arrangements (+ under-fill collapse), workspaces (save/load/rename/duplicate/trim/delete/startup/self-heal) +
session resume, popouts (open, theme broadcast, pull-in, sign-out prompt + cleanup), alarms (drawer, filters,
sort, select/ack, ack all, badge, burst → summary read), Genie's Read (pager, detail, cta, insight action,
pause, rotation pref, loading), herald island + lamp states (carry, materialize, whisper, deliver, herald
modes, unread/busy, halo ≥ .88, vanish timer, chat icon), 16 English + 9 French voice commands + generic open
in both + language switching + 84-phrase audit + no-match + real voice sign-out, voice prefs, every Quick
Settings control (90 checks), Settings view parity + columns (3 @1913 · 2 @1500 · 4 @2560, sequence kept
across re-packs, Genie at a column top, id-free sliders, no duplicate ids besides `wv-i-info`), i18n through
the five languages (lang/dir, catalog names, RTL header), presentation mode, Info mode float + dock
(chooser, hover/pin/unpin/close, 9 sections, ja labels, chat dock coexistence, grip reset, persistence,
`WV.info.present`, facet fallback), shortcuts sheet + Esc order + help menu + What's new + report-an-issue +
notification center, system health chip + popover + degraded/stale, market clock + time zone, shared-hour
scrub bus (subscribers, play, close), product switch + accents + title, embed protocol (ready/theme/time/
prefs/alarm/system + the new info messages), chat widget (mount, lamp/Ctrl+G, z 100090, Settings popover
portal z 100095, Desk tones/channels/ack, Monitoring, desk.add, alert, theme follow, register no-op,
popOut/popIn), reset preferences, sign-out cleanup, sessions (tab vs remembered, expiry). Hub deep adds:
landing on `ftm.monitor`, 1.7.1 embed guard (Forecast/Analyze/All/Monitor in the frame + popout), exclusive
switch, openView-driven switch, close releases the frame, 3 rotations (iframes 1, DOM flat, alarms deduped),
catalog scope, voice cross-product, **Info in frames** (hover an FTM KPI → hub dock entry with title/kind/
sections, click pins both sides, pin button releases, local hover wins, Esc clears the frame, float → the
frame's own card, popout Info), Desk product channels + survive switch until ack.

### Verification tally (this round, after the fixes)
| file | mode | pass / total | pageerror | console.error (non-tolerated) | tolerated lines |
|---|---|---|---|---|---|
| framework | deep | **399 / 399** | 0 | 0 | 2 |
| hub | deep | **438 / 438** | 0 | 0 | 2 |
| ftm | smoke | **13 / 13** | 0 | 0 | 2 |
| btm | smoke | **13 / 13** | 0 | 0 | 2 |
| ev | smoke | **13 / 13** | 0 | 0 | 2 |
| dlrmap | smoke | **13 / 13** | 0 | 0 | 2 |
| dlrline | smoke | **13 / 13** | 0 | 0 | 2 |
| hub-file | file | **6 / 6** | 0 | 0 | 0 |

Framework features: boot+login 19/19 · launchpad+favorites+recents 9/9 · command palette 13/13 · sidebar nav + mega menus 9/9 · views: open/close/cycle/pin/maximize + layouts 28/28 · workspaces + session resume 15/15 · popout windows 9/9 · alarms drawer + badge + summary read 11/11 · Genie's Read band 11/11 · herald island + lamp states 13/13 · voice commands (en + fr) 35/35 · voice prefs 12/12 · Quick Settings: every control 90/90 · Settings view parity + columns 15/15 · i18n (5 languages, RTL) 16/16 · presentation mode 5/5 · Info mode float + dock 20/20 · keyboard shortcuts + Esc order + help menu + ticket 11/11 · system health + market clock + time bus 11/11 · product switch + accents 2/2 · embed protocol (#wv-embed) 16/16 · chat widget integration 17/17 · reset preferences + sign-out cleanup + sessions 10/10 · error gate 2/2
Hub-only features: hub: landing + frames + embed guard (1.7.1) 6/6 · hub: exclusive product switch + memory hygiene 11/11 · hub: Info mode in product frames (1.8.9) 15/15 · hub: widget channels 3/3
Screenshots of the new behaviour (scratchpad `shots\`): `hub_info_dock_ftm_kpi.png` (hub dock showing the FTM
Battery State of Charge entry from inside the frame), `hub_info_float_in_frame.png` (the frame's own card in
float mode), `p189_hub_dock_ftm_kpi.png` / `p189_hub_float_in_frame.png` (first probe).

## Hub — raw products: Conversation & Feedback + Genie Powerflow (2026-08-29)

- Two NEW standalone dashboards merged into `GenieAllDashboards.html` WITHOUT shell integration:
  `dashboards\conversationAndFeedback.html` → product **conv** "Genie Conversation & Feedback"
  (view `conv.history` "Conversation History", group Genie) and
  `dashboards\genie_powerflow_genie_standard.html` → product **pf** "Genie Powerflow"
  (view `pf.dashboard` "Powerflow", group Operations). One view each (raw pages have no
  addressable sub-views).
- Hub layer: `RAW={conv,pf}` — `frameURL` loads the page as-is (no `#wv-embed`), readiness = the
  frame's `load` event (veil off, system row `<pid>-page` live; `error` → stale), `briefFrame` skips
  raw frames (no theme/time/info/alarm relay — their own chrome and theme stay). Product switcher,
  palette scope, voice ("open the conversation history" / "open the powerflow"), tab title, fleet
  read count (now `ORDER.length`) and i18n view names all work. Dropdown footnote counts products.
- Not spliced (raw files carry no sentinels); the propagation set is unchanged. Converting them
  later with genie-shell-integrate = remove them from `RAW` (embed protocol takes over).

## 2026-08-29 — conv integrated: dashboards/conversationAndFeedback_wv1.0.html (framework 1.8.9)

- New converted product `conv` (Genie Conversation & Feedback) from the RAW hub page; one view
  `conv.history`; accent `#8134FF`; system `conv-api`. Raw file untouched.
- Merges per genie-shell-integrate: chrome retired; range/role/charts controls kept as a product
  toolbar; drawer/scrim/menu/tour re-homed to `#conv-overlays`; prefs bridge; single Info mode
  (30 rich entries); single health; NO alarms (Desk feed instead); Genie's Read ← 3 KPI reads;
  shortcuts + palette actions; product i18n (~180 labels); startupWs → conv.history; embed
  protocol; zero external requests.
- Raw defects fixed and surfaced: `waterfall()` ("Run trace") was undefined → ReferenceError;
  `.listwrap{min-height:240px}` floor was overridden to 0 (rows collapsed under short windows);
  programmatic focus/scrollIntoView scrolled the page root mid-transition (scoped).
- Hub: conv switched from RAW to converted (embed protocol, `conv-api` relay); propagation set +1.
- Verified: 109/109 + verify_shell --smoke 13/13, zero pageerror / console.error.

## 2026-08-29 — pf integrated: dashboards/genie_powerflow_genie_standard_wv1.0.html (framework 1.8.9)

- Raw Genie Powerflow → converted product `pf` (10 views: 7 Real-Time module tabs + Planning/HCA/
  DOE), singleton `#pf-root`, MODE seg + RT tab row rerouted through openView. Self-contained:
  ECharts 5.5.0 + Leaflet 1.9.4 vendored (the framework carries NO ECharts — ftm/ev do), echarts-gl
  2.0.9 vendored inert, Google Fonts dropped. Basemap tiles remain runtime network requests
  (product behaviour; CARTO watermark).
- Merges: alarms (5 derived, dedup) · health (3 systems) · Genie's Read (6 reads → band; kind/fact
  chips = framework gap) · Info (resolver over the product INFO registry) · shortcuts · prefs bridge
  · i18n (~230 keys, root pinned LTR) · no-scroll contract (--pf-vh + 2 densify tiers).
- Hub: pf switched from RAW to converted (embed protocol; HOME → pf.results); propagation set +1.
- Skill corrections from this run: catalog `name` is a STRING (translations via WV.i18n.register;
  array names broke the startup workspace); the framework does NOT vendor ECharts.
- Verified: verify_pf.py 82/82 · verify_shell --smoke 13/13 · zero pageerror / console.error.

## Framework 1.8.10 — shell-scoped views · embed health snapshot · CR fix (2026-08-29)

- **Shell-scoped views**: a catalog entry with `shell:true` belongs to the shell, not a product —
  `isFrameworkView` accepts it, so it is visible under every product (nav, palette, launchpad,
  favorites) like the Settings view. Enables hub-level folders (the "Genie UI" folder + Report
  Review view in GenieAllDashboards).
- **Embed health snapshot**: right after `{wv:"ready"}` an embedded product posts `{wv:"system"}`
  for every non-live system (states set at registration time — before `EMB.on` — were stored
  locally and never reached the hub; Powerflow's degraded DER telemetry showed live in the hub).
- Two stray `


` runs in the framework normalized (from a CRLF-unaware insert); converted files
  copied them verbatim, so the splice dry-run reported them CHANGED.
- Propagated to all eight targets (5 dashboards + conv + pf + hub).

## Framework 1.8.11 — presentation mode across product frames (2026-08-29)

- Found by the hub regression (a real gap, not a flake): once the presentation control chip had
  faded, moving the mouse over a PRODUCT FRAME never brought it back (frames swallow pointer
  events), and Esc with focus inside a frame could not end the presentation.
- Protocol: parent → child `{wv:"present", on}` on enter/exit (popouts + every `iframe[data-wv-product]`,
  and to a frame adopted mid-presentation on its ready); child → parent `{wv:"pointer"}` (throttled
  400 ms mousemove while presenting) → `presentPoke()`, and `{wv:"present-exit"}` (Esc inside the
  frame) → `presentExit()`. Framework-only (no hub-layer change); propagated to all eight targets.

## Framework 1.8.12 — tab labels show the dashboard name (2026-08-29)

- CEO ask: an open view's tab read only the mode/view name ("Monitor", "Forecast"); the tab now names
  the DASHBOARD the way the browser title / lockup does, since the product's own mode bar already
  highlights the view. Tabs read “‹Product› · ‹View›” — product in the tab's text colour, view muted
  (`--wv-t-lo`), hairline separator; the product part truncates first (`.wv-tab-prod` min-width 0 /
  flex 1 / ellipsis), the view part keeps its width; composite tabs may grow to 300px (`.wv-tab.wv-tl2`);
  the full label is the tab tooltip. Product name = the registered product `name` (an "OATI " prefix is
  stripped). Framework views (Settings, `shell:true`) show just their name.
- Preference `tabLabel` = `"product-view" | "product" | "view"`; stored value `null` = computed default:
  **product-view when more than one product is registered (the hub), view for a single-product file** —
  resolved at render time (`tabLabelMode()`), so a product registered after boot still counts. Reset
  preferences restores the computed default. "product" alone still appends the view (muted) when another
  open view belongs to the same product, so tabs stay distinguishable.
- Surfaces on ONE helper (`tabLabelParts / tabLabelFor / tabLabelText`): the tab strip (inline + popout
  tabs, tooltip), the tab overflow "▾ N" menu (sub-line drops the product when the label already has it),
  the sidebar Open list + the collapsed rail's quick-launch tooltips, the palette Open tab (query
  highlighting kept inside the view part), panel headers (the tab surrogate in split/grid arrangements),
  the status-bar Popouts menu, tab context-menu titles, the "opened in its own window" notice and the
  voice "Opening …" confirmation. Unchanged by design: the header context strip (a catalog-path
  breadcrumb), workspace definitions (`views` are NAMES per contract) and the workspace composer
  (grouped per workspace/product), the presentation chip (has no view label).
- UI: Quick Settings › Behavior and the full Settings view share the new segmented row "Tab labels —
  Product · View / Product / View" (+ sub-label); palette actions "Tab labels: product · view / product /
  view"; i18n fr/es/ar/ja; What's-new row; Framework Guide row. No product-side delta.
- Propagated to the seven dashboards (ftm, btm, ev, dlrmap, dlrline, conv, pf); the hub is spliced by the
  lead separately (it was being edited in parallel).
## Hub — Genie UI folder + Report Review view (2026-08-29, hub spliced 1.8.9 → 1.8.10 → 1.8.12)

- **What**: a native **Report Review** view inside `GenieAllDashboards.html` under a new root folder
  **"Genie UI"** in the left nav, visible whatever product is active, with the framework's **Settings**
  view moved into the same folder. Built as DOM by the hub layer (section 7b of the hub script +
  `<style id="wv-hub-report-css">`, both inside the WV-PRODUCT block, outside every WV-SHELL chunk) —
  no iframe, and `reports/dist-widget/oati-report-widget.js` is NOT loaded at runtime.
- **Data (`REPORT_DATA`, verbatim from `reports/report-widget-demo.html`)**: header (runLabel, statusLabel) ·
  genieRead (outageId, message, deadlineLabel, severityTone) · rowDetails for 17133060 (3 idTags, confidence
  level+label, summary, recommendedAction, 2 evidence pairs, 1 inconsistency finding, 1 note with
  highlightTerm) · 8 attribute rows + the 1 row the host page appends 5 s after load (`lateRows`) = **9 outages,
  10 inconsistency chips, 7,065 MW**. `REPORT_DATA.component` carries what the compiled component defines and
  the host does not: tab ids/labels, filter-chip names, search placeholder, grid aria label, empty/loading/error
  texts, footer words, confidence bars (low 1 / medium 2 / high 3), density hints, the locked column.
  Semantics kept: Critical Outages = `statusTone==="critical"` (5), Inconsistencies badge + footer "flagged" =
  total chips (10), tag tones critical/attention/neutral, flagged voltage / planned-start in red mono, id cell
  severity diamond + related pill, `+N` overflow, sort click asc→desc toggle, evidence section collapsed by
  default, the other two open.
- **UI**: header (title · run picker · status stamp · refresh with spinner · Export · kebab), slim context
  line (no second read strip), tabs with live counts, filter chips as multi-select popovers with counts
  (Suggested presets from the rows' own flags, Participant, Type, Status, Voltage kV class + flagged-only,
  Impact, Inconsistency incl. None), Group (participant/type/status headers), Sort popover + sortable
  sticky headers with `aria-sort`, search across id/equipment/description (focus preserved), density toggle
  (follows the shell pref; override cleared by a shell change), split toggle (detail in a side pane, stacks
  under 980px), Columns popover (hide/reset, Outage ID locked), row expand inline with the full detail
  (confidence meter, summary, recommended action, evidence grid, findings, notes with highlighted term,
  add-a-note, Ask Genie → Desk item + opens the Desk, Open source row, Export row), roving-tabindex keyboard
  nav (↑ ↓ Home End · Enter expands · Space selects · Esc collapses/closes popovers — container-scoped
  scrolling, never `scrollIntoView`), selection + bulk bar (export selected / copy IDs / Ask Genie / clear),
  Export CSV (data: download, `WV_HUB_REPORT.lastCSV`), Share view (copies `#view=hub.report&tab=…&q=…&
  outage=…&split=…&sort=…&group=…`; the hub reopens it after sign-in), loading skeleton / empty / error
  (role=alert + Retry) states, kebab "Preview state". Tokens only (`--wv-*`), light + dark, reduced motion via
  the shell's `--wv-dur`, `[hidden]` honoured, fixed column budget (`REP_COLS.px`, Short Description flexes,
  grid scrolls sideways under 1440px inside its own container).
- **Commons merges**: the component's GENIE'S READ strip → the SHELL band: `feedHubRead` now stamps
  `[report read, fleet read]` under every product id (crit tone, cta "open the report review" → opens the
  view at 17133060, insights → Critical tab, deadline meta). Critical outages with inconsistencies →
  `WV.raiseAlarm` (crit when any critical-tone chip, maj otherwise; 4 crit + 1 maj), source
  `"Genie UI · Report Review"` (the hub's "‹Product› · ‹source›" convention), srcView `hub.report`, dedup
  `report:<outageId>` — raised once after sign-in (enterApp wrapper, installed BEFORE `WV.start` because a
  resumed session calls enterApp from inside start), never on re-render; they reach the drawer + Genie's
  Desk automatically. Info mode: 43 `WV.info.describeMany` rich entries (`rep:*` via `data-info-key`) +
  `data-info` facets on every control. i18n: 74 labels fr-CA/es-MX/ar/ja incl. "Genie UI" / "Report Review";
  data (ids, equipment, participants, descriptions, chip labels, OUT/SCHED, TRANS/GEN) untouched.
  Voice "open the report review" + palette work through the normal catalog.
- **Shell-level registration (1.8.10 `shell:true`)**: `WV.registerViews([{id:"hub.report", path:["Genie UI"],
  type:"Report", important:true, …}])` then `view("hub.report").shell=true` (registerViews copies only the
  spec'd fields); `WV.registerRenderer("hub.report", …)` beats the hub's `"*"` iframe renderer; `isHubView`
  returns false for `v.shell===true` (so `hubExclusive` never closes it on a product switch, no time-bus
  subscription) and `frameURL` returns `about:blank` for it; after `WV.start`: `view("wv:settings").path=
  ["Genie UI"]; .shell=true`, `S.treeOpen.add("Genie UI")`.
- **Framework gap found (1.8.10–1.8.12)**: `visibleCatalog()` admits shell views under every product, but the
  sidebar Browse tree, the horizontal menu bar and `openMega` build from `productCatalog()` — the folder
  listed only under ftm. Hub-layer wrappers (`renderSidebar` → append the folder + filter hits, `renderHnav`
  → a "Genie UI" item, `openMega` → a plain view list for it) cover it; framework fix = switch those three to
  `visibleCatalog()` (then drop the wrappers). Also: `registerViews` drops unknown fields (`shell`).
- **Verified** (Playwright chrome, strict zero pageerror / console.error; tolerated: favicon probe + chat
  service noise): `verify_report.py` **150/150** — folder under ftm/btm/pf (+ h-nav item + menu), open via
  nav/palette/voice, survives product switches, 9 rows + verbatim cells, tab counts 9/5/10, footer 9 · 10 ·
  7,065, every chip (counts asserted), search, sort asc/desc on Voltage/Planned Start/Equipment/Market
  Impact, keyboard, expand detail (evidence/findings/notes/highlight/add note), selection + bulk + export
  selected, density follow/override, split, columns, Export CSV (10 lines), Share link + clipboard, refresh
  spinner, loading/empty/error, dark→light→dark, reduced motion, ja labels + lossless return, Info dock
  rich sections on a column header/tab/footer, band read + cta, 5 alarms once (drawer + Desk, re-raise no
  dup), Settings in the folder, deep link in a second page, 1240 no page h-scroll.
  `tools\verify_shell.py --only "hub|nav|palette|product|info"` **103/103** (stamp check now compares to
  the framework's own version). Screenshots: scratchpad `shots_report\` (dark, light, expanded, split,
  filters open, error state, alarms drawer, band read, nav folder under ftm + btm).
- Skill: `genie-shell-integrate` step 5 gained "Hub-level views (`shell:true`)"; mirrored via `sync_skills.py`.
  Backup: `GenieAllDashboards.pre-report.html` (pre-round), `.pre-1.8.10.html` (pre-1.8.12 splice).

## Framework 1.8.13 — shell-level views in nav / menu bar / mega menu (2026-08-29)

- Found while building the hub's Genie UI folder: `visibleCatalog()` admitted `shell:true` views under every product, but the sidebar Browse tree, the horizontal menu bar and `openMega` built from `productCatalog()` (active product only). New `navCatalog()` = product views + shell views, used by all three. `registerViews` now keeps the `shell` field (it dropped unknown fields; the hub stamped it after the fact). The hub's guarded nav wrappers remain harmless. Propagated to all eight targets.

## Hub — Nightly Reports (rename, single read surface, band-styled row read, popout) (2026-08-29)

- **Rename (CEO)**: the hub's shell-level view `hub.report` is now **"Nightly Reports"** everywhere the user sees it —
  catalog name (nav row, shell tab, palette, launchpad; voice "open the nightly reports" resolves through
  `genieOpenByName`), the view's header title (`REPORT_DATA.component.title`), `aria-label`, i18n
  ("Rapports nocturnes" / "Informes nocturnos" / "التقارير الليلية" / "夜間レポート"), Info entries (`rep:header`),
  palette keywords (the old "report review" stays as a keyword alias), Genie's Desk action ("Open in Nightly Reports"),
  the band read's summary lead + cta ("open the nightly reports"), CSV file names (`nightly-reports*.csv`), alarm
  source **"Genie UI · Nightly Reports"**. The id `hub.report` (deep links `#view=hub.report…`, prefs key
  `hub.report.prefs`) and the alarm dedup keys `report:<outageId>` are unchanged — existing alarms are not re-raised.
- **One read surface**: the slim "GENIE'S READ · Genie's Read is in the shell band above · 17133060 · ~2h to act"
  context line under the view header is gone (`.wv-rep-ctx` markup + CSS, `rep:context` Info entry, `focus-read`
  action, its i18n). The shell band carries the read; the header keeps run picker / status / refresh / export / kebab
  and the tabs follow it directly.
- **Row read = the shell band's component**: an expanded outage's Genie's Read is rendered with `#wv-gread`'s own
  markup and classes (`renderGenieRead` shape: `.wv-gr-row` › `.wv-gr-mark` ✦ + `.wv-gr-cap` "GENIE'S READ:" +
  `.wv-gr-sdot` tone dot + `.wv-gr-head` bold lead + `.wv-gr-ctasep`/`.wv-gr-cta` + `.wv-gr-tex` 4-layer dot texture +
  `.wv-gr-side` meta chips (confidence with a 3-bar meter, run label) + `.wv-gr-tg` Show/Hide detail; `.wv-gr-x` ›
  `.wv-gr-sum` quote + `.wv-gr-sumcap`, `.wv-gr-ins` insight rows `.wv-gr-i` (recommended action → Ask Genie, evidence
  pairs, each inconsistency with its tone) + `.wv-gr-acts` tone buttons Ask Genie / Open source row). Only the container
  rules the framework keys on the `#wv-gread` id (tone ladder `--wv-tn`, dotted hairline, violet wash, open state) are
  restated on `.wv-rep-gread` (hub CSS) — the hub's `.wv-rep button{font:inherit}` reset now excludes
  `.wv-gr-cta/.wv-gr-i/.wv-btn` so the computed typography is byte-equal to the band (asserted). Tone: red = critical
  status, amber = attention chips only, violet = clean. Open state per outage (`st.sec[id].gr`, default open). Outages
  without a recorded read keep the honest "No Genie read recorded for this outage in this run." line in the same band
  (info tone, no toggle) followed by the facts grid inside the band. New Info entry `rep:read`.
- **Popout fixed**: popping the view out used to open the FTM product file with `#wv-embed=hub.report` → "Unknown
  view". The hub's `embedURL(viewId,inst)` override now lets the FRAMEWORK build the URL and only swaps the file:
  `fw = WV.embedURLFor(viewId,inst)` when the framework exposes it (re-entrancy guarded; 1.9.0 adds `&band=1`) else the
  framework's own `embedURL` captured before the override (`_hubEmbedURL`) — i.e. `location.href.split("#")[0] +
  "#wv-embed=<id>&inst=N&theme=…&density=…[&…]"`; **shell:true view (or unknown / no product file) → return `fw`
  as built (the HUB's own file)**; product view → `FILES[v.product] + fw.slice(fw.indexOf("#"))` (converted file, the
  framework's query untouched). Rule string on `WV_HUB_STATS.embedURLRule`. The hub's child→parent relay ignores a
  popout whose view is `shell:true` (the framework adopts + briefs it; no product-accent re-brief, no frame record —
  `WV_HUB_STATS.frames/themeCasts` and `WV_HUB_LIVE` unchanged, asserted). The hub file's embed boot mounts
  `hub.report` through the registered renderer: chromeless, title "Nightly Reports — GridLine FTM Optimizer", full view
  (rows, tabs, expand with the band-styled read).
- **Verified** (Playwright chrome, strict zero pageerror / console.error; tolerated favicon + chat-service noise):
  `verify_report.py` **183/183** (rename in nav/tab/palette/title/voice/ja, old context line absent, band class set +
  computed-style parity with `#wv-gread`, Hide/Show detail, no-read band + facts grid, popout of the hub file with
  bookkeeping unchanged, product popout URL unchanged, deep link, alarms as Nightly Reports, everything from the
  previous round); `tools\verify_shell.py --only "hub|nav|palette|embed|popouts"` **104/104**. Screenshots:
  scratchpad `shots_report\nightly_header.png`, `nightly_row_read_vs_band.png`, `nightly_row_no_read.png`,
  `nightly_popout.png`. Shell chunks byte-identical (hub layer only; framework untouched, no splice).
  Backup: `GenieAllDashboards.pre-nightly.html`.
- Skill `genie-shell-integrate` (hub-level views recipe) renamed accordingly; mirrored via `sync_skills.py`.

## Framework 1.9.0 — Genie's Read scope (Global/View), read band in popouts, notifications drawer, shell-view popouts (2026-08-29)

- **Genie's Read scope**: `WV.genieRead.set({product, view?, reads})` — with `view` the reads are stored per view
  (`GREAD.views[viewId]`), without it product-level as before; `.loading(product?, view?)` / `.clear(product?, view?)`
  likewise. `S.greadScope` = "global" | "view", session-only (never persisted; `enterApp` resets to "global",
  a band popout boots on "view"). Band right edge (before Show detail): segmented **Global / View** toggle
  (globe / view icons, `data-info` facets + rich `WV.info.describe("gread-scope")`, fr/es/ar/ja). View scope
  follows the active tab (`renderTabs` re-renders it); the context chip reads "‹View› · N reads"; a view with
  nothing filed shows the honest line "No read for ‹View› in this run · Show global" (never blank); Global with
  no product read but a focused view that has reads shows the mirror line. Rotation / pager / detail / cta / voice
  "share top 5 reads" all run on `grCur()` (the scope showing). Palette: "Genie's Read: Global" / "Genie's Read: View".
  The framework's sample product files view reads for `sample:dash` (2) and `sample:trend` (1) in five languages.
- **Popouts carry the band**: `popOut()` appends `&band=1`; `bootEmbed` with `band` moves the SAME `#wv-gread`
  (adds `wv-root` for border-box) above `#wv-embedRoot` under `body.wv-embed[data-wv-band]` (slim full-width band,
  scope "view", toggle available; ≤1240px drops the as-of chips, keeps the view chip). Parent → child
  `{wv:"gread", product, view, title, reads, viewReads}` on ready and on every `WV.genieRead.set/clear`
  (functions travel as `{label, remote:true}`); child → parent `{wv:"gread-run", scope, product, view, ix, ins}`
  runs the cta / insight action in the parent. Hub product FRAMES (no `band`) stay chromeless. Title unchanged.
- **Shell-view popouts**: `WV.embedURLFor(viewId, inst)` = the framework rule (current page's file + `#wv-embed…`);
  `popOut` uses it FIRST for `v.shell===true` / `wv:settings` (whatever a hub override does to product views), and
  refuses with a toast when the view has no renderer (no more "Unknown view" windows). `bootEmbed` mounts a shell
  view through its registered renderer like any catalog view (verified: Settings pops out of the framework page).
- **Notifications drawer** `#wv-ndrawer` (overlays chunk) replaces the `notif-menu` dropdown: alarm-drawer geometry /
  animation / z / Esc order (QS → genie → notifications → alarms) / `uiBusy`; header "Notifications" + unread chip +
  Mark all read (disabled when nothing unread) + close; body grouped by day (Today / Yesterday / date, newest first)
  with the existing row content (kind dot, `<b>` text, relative time); opening marks visible items read after 1.5 s;
  events arriving while open land live; focus moves in (Tab cycles inside) and returns to the bell on close; one
  right-edge surface at a time (alarms ↔ notifications ↔ QS ↔ chat). `menuNotif()` stays as a guarded alias.
- **Hub wiring for the lead (GenieAllDashboards.html not touched here — still 1.8.13)**: in the hub's `window.embedURL`
  override, return `WV.embedURLFor(viewId,instN)` when `view(viewId).shell===true || viewId==="wv:settings"`; keep
  swapping only the file before `#` for product views so the framework's `&band=1` survives; splice the hub with
  `tools\splice_shell.py GenieAllDashboards.html` after that. Product popouts from the hub receive the band relay
  automatically (the framework's ready handler posts `greadMsg` from the hub's `GREAD.data`, i.e. `feedHubRead`).
- **Verified** (`tools\verify_shell.py`, Playwright chrome, strict zero pageerror / zero non-tolerated console.error):
  framework deep **433/433** (gread 23 incl. scope toggle / empty line / view chip / i18n / palette; popouts 18 incl.
  band=1, relay, gread-run, Settings shell-view popout, WV.embedURLFor, no-renderer refusal; keys/Esc/notifications 24
  incl. 9-step Esc order and the drawer's open / group / read timer / live event / Mark all read / Tab trap / Esc /
  ja); smoke ftm + conv green. Screenshots: scratchpad `shots190\` (band_global, band_view, band_view_expanded,
  band_view_empty, band_view_empty_ja, popout_band_view, popout_band_global, popout_settings_shellview,
  notifications_drawer, notifications_drawer_read).
- Propagated (explicit args, NOT the hub): ftm, btm, ev, dlrmap, dlrline, conv, pf → 1.9.0 (`.pre-1.8.13.html`
  backups). Framework backup `GenieApplicationShell.pre-1.9.0.html`. Skills: `genie-shell-integrate` (the `view` key +
  `WV.embedURLFor` contract notes), `genie-shell-update` (1.9.0 release line); mirrored via `sync_skills.py`.

- Hub 2026-08-29 (1.9.0 follow-up): `feedHubRead` merges — the hub owns only its two reads (Nightly Reports + fleet); any other read filed for a product is kept AHEAD of them instead of being clobbered on every hour tick. The Nightly Reports read is also filed as that view's VIEW-scoped read (band View scope shows it). Suite: gread scope checks park a live alarm-summary read first; herald settles hub connect notices.

## Framework 1.9.1 — the lamp always opens the chat (2026-08-29)

- While the genie carried a herald event (alarm / notification / read badge), clicking the lamp DELIVERED the event instead of opening the chat, so the chat could not be opened from the lamp until the event was cleared. Now the lamp always toggles the chat; only the small event badge at the lamp's bottom-right delivers the carried event (it is a real pointer target with a tooltip). Whisper island and voice delivery unchanged. Propagated to all eight targets.

- Hub 2026-08-30 — Nightly Reports i18n audit (skill rule: UI labels translate, data never): attribute labels (search placeholder, aria-labels, titles) and the header's run/status phrases ("Latest · <run>", "Studying · N updates pending" → UI words translated, data kept) were untranslated; 26 keys added (fr/es/ar/ja), dynamic "Select row N" built through the dictionary, the hub's fleet read + cta labels localized and re-fed on language change (read CONTENT from products stays in its source language), the view header re-renders on a language switch. Lossless return to en-US verified.

## Framework 1.9.2 — Voice gender in the identity card (2026-08-30)

- The "Voice gender" row (Auto / Female / Male) moved from the Genie assistant card to the identity card, directly above the "Genie voice commands" link — quick reach in Quick Settings and the Settings view (both render `qsIdentityHTML`). Propagated to all eight targets.

## Framework 1.9.3 — male/female voices for every language (2026-08-30)

- Voice-gender name lists extended for Windows' fr-CA (Claude/Caroline), es-MX (Raul/Sabina), ar (Naayf/Hamed · Salma/Hoda from the Egypt pack — Saudi ships male voices only) and ja-JP (Ichiro · Ayumi/Haruka/Sayaka). `pickVoice` already falls back to a same-language voice of the wanted gender from another locale (ar female → Egypt). Voice packs installed on this machine: ar-SA, ja-JP, fr-CA, es-MX, ar-EG. Propagated to all eight targets.

## Framework 1.9.4 — sign-in briefing + stop gestures (2026-08-30)

- **Sign-in briefing.** After the native greeting + welcome line the genie briefs TWO items, spoken AND shown as
  island cards (each item its own utterance and its own card; a card click opens the source — alarm drawer /
  notifications drawer / the read's detail + its `cta`). Pref `S.loginBrief` = `read` (default) | `alarms` |
  `notifs` | `none`, persisted, in `PREF_DEFAULTS`; Quick Settings › Genie assistant › **Login briefing**
  (Genie's Read / Alarms / Notifications / None, sub-label "two items after the greeting") directly under
  Login greeting — greyed (`.wv-qs-off`) when Login greeting is Off, the master switch; palette actions
  `act:brief-read|alarms|notifs|none`; i18n fr/es/ar/ja. Intro lines per source (`BRIEF_STR`, 5 languages):
  read → "Two things from Genie's Read:" (or "Nothing new in Genie's Read."), alarms → "Two alarms need
  attention:" / "No active alarms.", notifications → "Your latest notifications:" / "No new notifications."
  Sources: read = first two reads of the GLOBAL scope of the active product (`grReads(GREAD.data[product])`,
  HTML stripped, content spoken in its source language); alarms = top two UNACKNOWLEDGED by severity
  (crit > maj > minr > info) then newest, spoken "Critical: ‹message›"; notifications = the two latest UNREAD
  that are news — rule: a `warn` always briefs, otherwise anything whose text is not one of the shell's own
  confirmation phrasings (`BRIEF_CONFIRM_RX`: product switched / menu synced / role changed / workspace loaded /
  "will open at launch" / popout opened, moved inline or closed / preferences reset). Voice detail: Announce
  caps an item at ~140 characters, Full reads it whole. Timing: `VOICE.holdUntil` follows the chain (each
  utterance's `onend`, safety cap 25 s) instead of the fixed 6.5 s; herald events queue behind it and settle
  right after (`briefRelease`). Silent resumes (`S._silentResume`) and embeds/popouts never brief; Voice Off
  plays the same cards silently (~3.5 s each).
- **One stop — `stopSpeaking(reason)`.** Cancels the current utterance, drops the whole queue (briefing
  included), clears the extended hold, resumes the ear, calms the lamp (`#wv-podGenie[data-speaking]` off) and
  the island. Wired to: the lamp click while speaking (stops, does NOT open the chat; visible speaking state =
  sound-wave ring `::after` + tooltip "Speaking — click to stop", reduced motion → static ring), the voice
  "stop" vocabulary (`STOP_RX`, five languages + "Genie stop") as a **barge-in** — recognition now keeps
  running while the genie speaks (`EAR.pausedForSpeech` is no longer set); `earGate` admits ONLY the stop
  vocabulary while `voiceBusy()` and, for 1.8 s after an utterance ends, drops a transcript that echoes it
  (`earIsEcho`: normalized-lowercase containment either way, or ≥ 60 % of the heard tokens present in
  `VOICE.cur`; the stop test runs first so it can never swallow a real stop) — Esc (speech stops before any
  overlay closes; nothing speaking → Esc as before), the island's ■ (`.wv-say-stop`, in every card, shown
  while speaking), Voice → Off, and every `interrupt:true` utterance. `genieSpeak` now returns true when an
  utterance was queued and calls `opts.onend(why)` exactly once (end / error / gave-up).
- Persisted for the first time (they were read at boot but never written): `voiceDetail`, `loginGreet`,
  `voiceGender`.
- Suite: `voice-briefing` step (feature "voice: sign-in briefing + stop gestures (1.9.4)") with a
  speechSynthesis spy — fresh login utterance order for read / alarms / notifications / none / greeting Off /
  silent resume / Voice Off, card click → source, hold extension until the last item, all five stop gestures,
  barge-in + echo filter; "voice prefs" covers the QS row, master-switch greying, i18n, palette; "reset"
  restores `loginBrief=read`. Propagated to all eight targets.

## Framework 1.9.5 — Greeting style preference (2026-08-30)

- New pref `S.greetStyle` = "simple" (DEFAULT: Hello, ‹name›! / Bonjour, ‹name› ! / ¡Hola, ‹name›! / مرحباً يا ‹name›! / こんにちは、‹name›さん！) | "timeofday" (the 1.5.0 native time-of-day greetings). Row "Greeting — Simple hello / Time of day" sits between Login greeting and Login briefing (greyed when greeting Off); palette actions; i18n. Propagated to all eight targets.

## Framework 1.9.6 — digital-rain dot texture (band + Halo lamp) (2026-08-30)

- CSS-chunk-only change (no product-side delta, no markup/JS change). The square-dot texture on Genie's Read
  band (`.wv-gr-tex i`, four tile layers) and on the Halo lamp (`html[data-genie-anim="halo"] .wv-gb-aura`)
  now animates as a top-to-bottom flow — "digital rain": the tile mask's Y position drifts DOWN one tile per
  cycle, X never moves (`mask-position` keyframes only; GPU-friendly, no layout).
- Band: `@keyframes wv-gr-rain` (from `--gr-x --gr-y` to `--gr-x calc(--gr-y + --wv-dot-tile)`); each of the
  four layers keeps its own X/Y offset as `--gr-x/--gr-y` (0/0, 14.79/29.58, 34.51/9.86, 44.37/19.72 px) and
  falls on its own clock + phase — 1.6 s / 2.7 s / 2.1 s / 3.6 s per tile, delays −.4 / −1.3 / −.9 / −2.2 s —
  so columns land out of step (falling data, not a scrolling wall). `--wv-rain-speed` (default 1) scales all
  four fall clocks together. The per-dot shimmer (`wv-gr-blink`, hold-snap-hold, incommensurate periods,
  peak .55) is unchanged and is still the only thing `--wv-tw-speed` (Quick Settings › Dot shimmer) drives;
  Dot shimmer Off keeps its meaning (static dot field, no animation). Layer opacities (.34/.3/.3/.26, blink
  peak .55), the right-edge fade mask, Dot colour, tone tints (crit/watch) and RTL are untouched; the texture
  never overlaps the headline / cta (it is the flex sibling to their right) — headline contrast measured
  identical before/after (15.1 dark, 16.5 light).
- Halo lamp: `@keyframes wv-gb-halorain` replaces the horizontal `wv-gb-halodrift` (removed). One element,
  a three-layer mask stack `[lead dots] ADD ([trail dots] INTERSECT [42 % flat])`: the bright lead layer falls
  two tiles per 4.8 s cycle (2.4 s per tile), the 42 % trail layer one tile per cycle (4.8 s per tile) at a
  3×6-pitch offset, both looping seamlessly on integer tiles. `--gb-rain` (1) scales the cycle: busy sets
  `.45` (2.16 s cycle = faster rain) and keeps the 1.5 s breath; unread keeps `--gb-o1:.95/--gb-o2:1`
  (brighter); rematerialize keeps the rain running under `wv-gb-lightsout`; breath stays .88–1 (peak
  opacity ≤ 1). Dot colour → lamp backdrop mapping unchanged.
- Reduced motion (`html[data-wv-root][data-motion="reduced"]`): band layers and the halo aura get
  `animation:none` — a static grid at its resting offsets, no drift, no shimmer, no breath.
- Popouts (`body.wv-embed[data-wv-band]`) inherit the effect (same band CSS). Both themes verified.
- Verified: `verify_shell.py --only "gread|herald|qs"` 147/147 on the framework; computed `animation-name`
  = `wv-gr-rain, wv-gr-blink` on the four band layers and `wv-gb-halorain, wv-gb-breathe` on the aura;
  600 ms `mask-position` samples show Y rising / X constant on every layer; peak opacities band .55 ×4,
  aura .99998, unchanged. Propagated to the SEVEN dashboards (hub spliced separately by the lead).

## Framework 1.9.7 — Dot shimmer = rain speed (2026-08-30)

- The Quick Settings "Dot shimmer" slider now controls the digital-rain SPEED of both the Genie's Read band and the Halo lamp (`--wv-rain-speed` = 100/pct: 100% design speed, 200% twice as fast, 0 = still on both); busy stays proportionally faster; shimmer twinkle still follows the slider. Propagated to the seven dashboards; hub after the polish round.

## Hub — Nightly Reports premium polish (2026-08-30)

- Hub-layer UI round on the native `hub.report` view (renderer + `<style id="wv-hub-report-css">` + hub script 7b in the WV-PRODUCT block; no WV-SHELL chunk touched, hub NOT re-spliced — still stamped 1.9.5 while the framework moved to 1.9.7 under the framework owner). Every behaviour, label, id, data value and i18n key is unchanged; judged against the `genie-ui` standard on the shell's own chrome language, tokens only (`--wv-*`), motion on `--wv-dur` (0 under reduced motion).
- **Header** = one composed toolbar on the shell's chrome budget (`min-height:var(--wv-hdr-h)`): accent section tick before the title (the Quick Settings `.wv-qs-sec` tick) · hairline after the title · run picker on the `.wv-btn` surface (bg3→bg2 gradient, tabular mono stamp, `.wv-open` accent ring — `repSync` now toggles `wv-open` on `.wv-rep-run[data-pop]` like every other popover anchor) · status stamp in tabular mono with a pulsing busy dot (the only header motion) and a hairline before the action set · icon buttons 28 px (`max(28px, ctl-h + 2)`) with hover / press (`scale(.94)`) / focus-visible (`--wv-focus`) / `.wv-on` / `.wv-open` states · Export = `.wv-btn.wv-primary` verbatim (accent-ink on accent, glow, the only button that lifts).
- **Tabs**: the shell's underline language — a 2 px accent rail with glow (`::after`, scaleX in on `--wv-dur-slow`), hover `bg2`, mono count chips (accent when active, crit tint on Critical), height `--wv-hnav-h`.
- **Filter row**: the band's pill family — dimension chips are 999-radius hairline pills on `bg2`, hover = accent hairline + 1 px lift, active = accent-dim fill + accent text + solid count badge, open = accent ring; **Suggested** reads as a PRESET (AI-tinted gradient + `--rep-ai` spark, solid accent when a preset is on); Group/Sort separated by the taller hairline; search = pill field with accent focus ring, the glyph turns accent on focus-within; view toggles = icon segmented pill (track `bg2`, round inner buttons, accent-dim active). Wrap keeps a 6 px row gap.
- **Table**: mono-caps header with the sort arrow shown only on hover / when sorted (the AI spark stays), a real shadow on the sticky header once the grid has scrolled (`.wv-rep-tw[data-scrolled]`, set by a passive scroll listener installed in `repSync`); zebra removed, hairlines on `--wv-line`, hover = 6 % accent wash, selected/expanded rows carry the shell's `inset 3px 0 0 var(--wv-acc)` rail on the sticky checkbox cell; Outage ID bold mono tight; tags on the `.wv-pill` metrics (18 px, radius 9, 10 px/700, `.04em`) with a tone hairline (`inset 0 0 0 1px currentColor 16 %`), ERC pill mono, OUT/SCHED status pills; voltage pairs + dates tabular mono with the ▲ flag aligned (no letter-spacing so the 138 px voltage budget still holds).
- **Expanded row**: an inset card (`::before` on the sticky `.wv-rep-det`: bg2→bg1 gradient, hairline, radius 9, `--wv-shadow-sm`, accent left rail); the band component inside is untouched; facts grid label sans `t-md` / value mono tabular `fs-sm`; section heads gain hover + focus; note input gets the accent focus ring. Split pane keeps the flat layout.
- **Bulk bar** = a floating dock centred over the grid (absolute above the footer, accent hairline, blur, `--wv-shadow` + accent glow, `wv-repdock` rise): mono count · hairline · **Export selected** as `.wv-primary` · Copy IDs / Ask Genie secondary · Clear quiet; `.wv-rep:has(.wv-rep-bulk:not([hidden])) .wv-rep-tw{padding-bottom:64px}` so it never covers the last rows.
- **Footer**: three mono stat chips (outages · ✦ flagged with the AI tint · MW total impact) + right-aligned Share view / Export icon shortcuts (`data-act="share|export"`, titles reuse the registered keys). Markup: `<div class="wv-rep-stat">` wrappers — `.wv-rep-ft b` order and the first `span` ("outages") are unchanged for the suite.
- **States**: loading skeleton = six table rows with masked cell blocks on the column budget (shimmer, hairlines); empty / error = the shell's state-block tone with a ringed 56 px glyph (crit-dim ring + glow on error), title `fs-md/600`, mono sub-line, one action.
- **Specificity fix**: the view's generic button reset is now `.wv-rep :where(button:not(.wv-gr-cta):not(.wv-gr-i):not(.wv-btn))` (zero specificity) — the old `(0,3,1)` rule silently overrode `color`/`font-weight` on `.wv-rep-btn.wv-primary`, `.wv-rep-ib.wv-on`, `.wv-rep-chip.wv-on`, `.wv-rep-tab` (primary buttons rendered with inherited grey text). Band parts inset in the row still keep the framework's typography (their class rules now win as intended).
- **Light theme**: header gradient bg3→bg2, chips / seg / search / stat chips on `bg3`, expanded card solid `bg3` + shadow, dock `bg3`, popover `bg3`; accent + severity tones re-derive from the light tokens. **Density**: rows 30/38, gutters 14/18, looser filter row and detail gap under comfortable; cell padding stays (fixed px column budget).
- Verified: `verify_report.py` 183/183 (two STALE assertions aligned with framework 1.9.x — the version-stamp check parsed a `1.8.1x` prefix, and the band pager check assumed the report read at index 0 whereas the 1.9.0 follow-up keeps other reads AHEAD of the hub's pair; baseline run on the pre-polish hub failed identically, so neither was a regression) · `verify_shell.py --only "hub|nav|i18n"` 80/81 — the single failure is the version stamp (hub 1.9.5 vs framework 1.9.7, splice owned by the framework round) · ja i18n audit: zero untranslated UI labels (the Latin regex only flags ID / Genie / MW inside translated strings) · no page horizontal scroll at 1913×939 and 1440×900 · zero pageerror, zero console.error beyond the favicon probe + chat-service noise · light theme checked on every surface · sticky shadow + hover states probed.

## conv — UI aligned to the Genie dashboard family (2026-08-30)

- `dashboards/conversationAndFeedback_wv1.0.html` (product `conv`, view `conv.history`) restyled onto the genie-ui house
  standard with Powerflow `pf.results` / FTM as the reference. Product layer only (a third `<style data-conv-css>` sheet
  appended after the conversion-layer sheet, the filter-bar markup, `renderKpis` / `renderViews`, the registration block,
  `CONV_I18N`); the nine WV-SHELL chunks are byte-identical (`splice_shell.py --dry` no-op on 1.9.7).
- Zones: filter bar (surface strip, mono-caps DATE RANGE / ADMIN VIEW / CHARTS keys, shell-style segmented controls
  with the accent thumb, hairline separators, charts toggle as a 30px icon button; the org badge stays) · KPI cards as the
  `.kc` family (tone wash + border, icon chip top-right — accent for the three neutral cards, attention for Needs review /
  User not told, ok when a queue is clear — mono-caps label, 23px tabular value + 11px unit, sub-line with the delta chips,
  sparkline pushed to the bottom, mono footer PAST 30D → NOW / COVERAGE / OF RATED / OPEN QUEUE / LOOP NOT CLOSED; the
  active-filter card = inset 3px tone rail + tone outline; light theme = white card + 3px tone top-rail) · panels with the
  family `.ph` head (glow dot · mono-caps title · secondary word · legend chips / mono count), hairline, padded body ·
  queues / lenses as the module-tab row (label + mono count chip, accent underline, inline mono-caps QUEUES / LENSES
  captions, one hairline between the groups) · list toolbar (family search field, ghost tools, Export CSV as the primary
  gradient button, the queue explainer as a note row with a tone rail: attention for queues, accent for lenses) · rows
  (mono-caps 9px head, 8px row rhythm, hover wash, accent selection rail, 12.5px/700 title, uppercase reason chips, quote,
  avatar identity, tabular mono WAITING, family pills) · footer as the mono stats line · overlays on the family drawer /
  menu / modal tokens (radius 11-16, hairline, elevation shadows, accent rails) · both themes · shell Density (comfortable
  = genie-ui spacing) · reduced motion unchanged.
- Every behaviour, id, data value, i18n key and bridge kept (WV.info entries, Desk feed, reads, shortcuts, prefs bridge,
  no-scroll contract). New UI strings registered in `CONV_I18N` (fr/es/ar/ja): Charts, Past 7d/30d/90d → now, Coverage,
  Of rated, Open queue, Loop not closed; the bar keys reuse the existing Date range / Admin view keys ("View" alone would
  collide with the shell's own string). Chart data colours stay on the product's --up / --down / --info tokens (the shell
  exposes no --wv-chart-* colour tokens to map onto).
- Densify re-aimed: the tier measure now uses layout geometry (offsetTop/offsetHeight) instead of scrollHeight — the
  section entrance transforms counted toward scrollable overflow for ~700 ms and mis-tiered the first measure — plus settle
  re-measures at 0.9 s / 1.8 s and a ResizeObserver on the panel scroller; tier rules use padding longhands so the
  split-with-list dock's padding-right reservation survives. At 1913×939 the view rests on tier 1 (panels 212px, list
  272px, viewport over 0); comfortable also tier 1; 1913×1200 native; 1400×700 tier 2, panel never scrolls.
- Verified: `conv_verify.py` 109/109 (stamp check now tracks the framework stamp), `verify_shell.py --smoke` 13/13, hub
  switch → conv frame renders the new look with zero errors, ja spot-check of the new strings + lossless return, no page
  h-scroll, before/after screenshots dark + light + drawer + comfortable and a side-by-side with `pf.results`.

## Framework 1.9.8 — Login briefing row title only; Dot shimmer default 25 % (2026-08-30)

- QS/Settings row "Login briefing" is the title alone (the "two items after the greeting" sub-line and its i18n key are gone).
- Dot shimmer (= rain speed for the band and the Halo lamp, 1.9.7) now DEFAULTS to 25 % (`store.get("greadTwinkle",25)`, `PREF_DEFAULTS.greadTwinkle=25`, slider/label fallbacks); users who already moved the slider keep their stored value.
- Suite: presentation-mode banner check asserts newest-critical semantics (hub frames relay their own startup criticals) and pauses the cycle first; reset-preferences check waits for the reset to settle and asserts the 25 % default. No product-side delta; propagated to the 7 dashboards + hub.

## Framework 1.9.9 — Genie's Read scope label: View → Local (2026-08-30)

- The band's scope toggle reads **Global / Local**: Local = the reads filed for the display currently open (formerly labelled View). Button, tooltip, empty-line link ("Show local"), context-chip title, palette action ("Genie's Read: Local"), Info-mode description and the five-language dictionary follow. **API unchanged**: `S.greadScope` still holds `"global"|"view"`, `setGreadScope("view")`, `WV.genieRead.set({view})`, `&band=1` popouts — products change nothing.
- Hub 2026-08-30 (product layer): Nightly Reports row-level Genie's Read is a plain header (no dot texture, no mark/tone-dot motion — the top band alone carries the rain); family CORNER rule settled with the CEO (Powerflow = reference): ONLY the top KPI tiles are rounded (11 px); every panel below sits on the normal 4 px corner. Powerflow unchanged (its kit's `--radius-md:4px` cards); Conversation & Feedback's filter strip, chart panels, queues/list and footer moved 12 px → 4 px, KPI tiles keep 11 px. Width: conv is back on its ORIGINAL 1560 px centered canvas (`#conv-root .viewport{max-width:1560px}`; the split dock still lifts the cap) — the full-width fill from the alignment round read as over-stretched (5 KPIs / 2-column charts vs Powerflow's denser grid); the shell chrome and the Genie's Read band stay full-bleed. KPI tiles = Powerflow's tile language (CEO): one family tone per tile (`--kc` rgb triplets = Powerflow's `.c-cy/.c-vt/.c-gn/.c-or/.c-rd`; warn tile at zero → green), 30 px badge, plain description line (trend as coloured emphasis, no pills), a mini chart in EVERY tile from a new `kpiSeries()` (per-bucket total / coverage % / satisfaction % / needs-review / not-told counts), mono tone-coloured footer, selection = inset rail + firmer border (no glow). conv_verify 109/109, smoke 13/13.
- Suite: briefing-row check no longer expects the sub-label (1.9.8); scope checks read the Local label.

## Framework 1.9.10 — alarm-burst debounce honours the Summarize-alarms pref (2026-08-30)

- `summNoteAlarm` arms a 2.5 s debounce during a burst; the callback now re-checks `S.alarmSumm` so turning Summarize alarms Off mid-burst files nothing (found by the hub suite: product frames raise a startup storm, and a summary read landed on the band 2.5 s after the pref was switched off). No product-side delta.

## Framework 1.9.11 — Summarize alarms OFF by default (2026-08-30)

- `S.alarmSumm` defaults to false (`store.get("alarmSumm",false)===true`, `PREF_DEFAULTS`); the QS/Settings row "Summarize alarms" and the voice command "Summarize the alarms" (explicit ask, always works) are unchanged. Stored On stays On. No product-side delta.

## Framework 1.10.0 — reliable voice commands (2026-08-30)

Reported: only "How are you" worked, and what was spoken never showed. Root causes found in the pipeline, each fixed:
- **Commands were dropped silently while the genie spoke** (`earGate` blocked everything but "stop" during `voiceBusy()`), and the heard bubble was only drawn AFTER the gate — so a command spoken over a reply vanished without a trace. Now a matched command spoken over the genie **barges in**: the speech is cancelled, the command runs, its own reply follows. Only echoes of the genie's own voice are dropped (containment / ≥60 % token overlap, while speaking or within 1.8 s of the end).
- **A stuck `VOICE.speaking` flag muted every command for good** when Chrome never fired `onend` (long utterance, stalled voice, backgrounded tab). A 1 s watchdog clears it when the engine has been idle two ticks or past a length-based cap (`max(8 s, 95 ms/char)`).
- **Nothing showed while the lamp carried an event** (`earShow`/`earReply` bailed on `HERALD.carrying` — nearly always true in the hub). The heard bubble and command replies now always surface at the genie; the carried event returns to the island afterwards (`earSayRestore`).
- Feedback: interim transcript live on the island (grey italic, trailing …) → final “phrase” with ✓ understood / ✗ not a command; a command reply keeps the phrase in front: “open the alarms” ✓ Opening alarms.
- Recognition: `maxAlternatives=3` — the other guesses are tried when the first is not a command ("opin the nutifications" → "open the notifications"); patterns are also tried on the normalized phrase (case/punctuation); the stop vocabulary is matched first.
- Session resilience: `onend` always restarts (250 ms) while listening; `earKick()` re-arms a dead session (also on `visibilitychange`); errors are logged (`no-speech`/`aborted` just restart; `network` warns once; `not-allowed` turns listening off).
- Diagnostics: `WV.voice.diag()` (supported, listening, sessionAlive, restarts, lastError, lastResultAgoMs, lastHeard, lastMatch, lang, voiceOn, speaking, engineSpeaking/Pending, briefing, holdMs, commands), `WV.voice.log()` (last 40 ear events), `WV.voice.say(text, alts)` (inject a transcript), `WV.voice.match(text)` → command id.
- Suite: barge-in semantics; new blocks "voice: reliability" (13) and "voice: recognizer lifecycle (fake engine)" (10 — start/interim/final+alternatives/silence-restart/no-speech/visibility kick/language re-tune/diag/off) — everything but the microphone hardware is exercised end to end. No product-side delta; propagated to the 7 dashboards + hub.

## Framework 1.10.1 — Voice diagnostics strip (2026-08-30)

- The Voice commands sheet ends with a live **Voice diagnostics** strip (1 s refresh while open): recognizer availability, Listening, Session (live / restarting…), Language, Last heard, Last match, Heard (ago), Last error, Restarts, Genie voice, Speaking, Commands + the last six ear events; **Copy** puts `WV.voice.diag()` + recent events on the clipboard (prompt fallback). Support/demo tool — the first thing to open when a phrase "does nothing". No product-side delta; propagated.

## Framework 1.10.2 — the ear pauses while the genie speaks (2026-08-30)

- CEO report after 1.10.0: commands work but are slow and sometimes missed — "earlier it was instant". Cause: since 1.9.4 the recognizer kept running through the genie's replies (for voice barge-in); the microphone hears the speakers, so Chrome folds the operator's next phrase into the same segment as the reply — finalized only when everything goes quiet (slow) — and the merged transcript reads as an echo (dropped). Before 1.9.4 the ear was paused during speech, which is why it felt instant.
- Now: `earPause()` on utterance start (session **aborted** → buffered echo discarded), `earResume()` 120 ms after the utterance ends (also from stopSpeaking, the guard loop, the speaking watchdog); `earKick`/`onend` never restart while paused. Diagnostics show *Session: paused — genie speaking*. Voice "stop" over the genie's own speech is no longer a path (it never worked reliably with speaker echo); lamp click / Esc / island ■ stop it. Everything else from 1.10.0–1.10.1 stays (watchdog, feedback, alternatives, diag).
- Suite: fake-engine block adds pause → stray end ignored → resume → normal utterance round-trip. Propagated to the 7 dashboards + hub.

## Framework 1.10.3 — microphone self-check on Listening On (2026-08-30)

- CEO: "when we turn on listening mode, we should check for available devices and confirm it's working". `earCheckMic()` runs 250 ms after the recognizer starts (never blocks it): (1) `enumerateDevices` → any audio input? (2) `getUserMedia` (4 s bound) → can the DEFAULT input be opened? (3) ~1.2 s level probe (AnalyserNode RMS peak). Verdict at the genie (spoken when voice is on), in five languages: “Listening — microphone: ‹name›.” / “…is silent — check the input device.” / “No microphone available — the browser lists no audio input…” / “Microphone access denied…” / “The default microphone ‹name› cannot be opened — ‹other› works: set it as the default input in Windows Sound → Input.”
- The dead-default case is real on the CEO's box: Chrome's default input was *Headset (AirPods) (Bluetooth)* whose hands-free profile was idle → `NotReadableError: Could not start audio source` → Chrome's page-info bubble says "No microphone available" while five inputs exist. Chrome's SpeechRecognition always uses the DEFAULT input (no device choice), so the check probes the other inputs and names one that opens (Microphone Array (Realtek)). Fix on the machine: Windows Sound → Input → choose the Realtek array (or make the AirPods active).
- `EAR.mic` {inputs,label,level,ok,err,alt}; run token — a superseded check (Listening toggled) abandons its result; `WV.voice.diag().mic`; diagnostics strip cell *Microphone*. Guard-loop restarts now go through `earKick` (counted). Suite: "voice: microphone self-check" (5) with a fake `navigator.mediaDevices` — none / dead default + working alternative / healthy with level / silent / strip. Propagated.

## Framework 1.10.4 — voice rows lead the Genie card; quiet healthy-mic verdict; hub → index.html (2026-08-31)

- Quick Settings / Settings, Genie assistant card: the voice group (Listening · Voice · Voice detail · Login greeting · Greeting · Login briefing) now LEADS the card (Chat icon / Herald / Summarize alarms and the lamp visuals follow). Same rows, same acts — order only.
- Microphone self-check: a HEALTHY microphone is no longer announced (no device name on the island — "Listening." already confirmed; the `ok` strings are gone). Problems still explain themselves (none/denied/dead-with-alternative/silent), and the diagnostics strip keeps the full detail as the support surface.
- Voice and Listening both default Off (confirmed: `genieVoice:false`, `genieListen:false`, PREF_DEFAULTS, reset).
- **The hub file is renamed `GenieAllDashboards.html` → `index.html`** — it is now the DEFAULT page at `http://localhost:8890/`. Updated: `tools/splice_shell.py` target list, `tools/verify_shell.py` presets, `serve_genie.py` note, both Start-*.bat (the hub bat opens `/`), skills (integrate/update/README), WV-PRODUCT-REGISTRY. The suite detects the hub by `wv-app-id`, not by filename. Old backups keep their names.

## Framework 1.10.5 — “Hello” voice command (2026-08-31)

- A native greeting spoken to Genie (hello/hi/hey/good morning · bonjour/salut · hola/buenos días · مرحبا/السلام عليكم/صباح الخير · こんにちは/おはよう — whole-phrase only, optional “genie” suffix) answers with the native hello (`GREET_SIMPLE` + name) **plus a welcome to the open product**: “Hello, Komal! Welcome to GridLine FTM Optimizer.” (`CMD_STR.welcomep`, five languages). Documented as the first row of “Genie & system” in the Voice commands sheet. Suite: 5-language match set, greeting-only guard, en/es replies carry the product name.

## Framework 1.10.6 — UI scale + Font size reach the ENTIRE view (2026-08-31)

- CEO: settings applied “to shell only” — product content ignored Font size. Product CSS is px-based, so tokens alone cannot reach it: the view body now zooms by `--wv-vz = scale × fontScale` (`applyPrefs`). A body hosting an embed IFRAME is exempt (`:not(:has(> iframe))`) — the child adopts `scale`/`fontScale`/`motion` over the theme+prefs relay (both now carry `fontScale`) and zooms itself, so it is never scaled twice; popouts ride the same relay. The shell font tokens are re-based to 1× inside the zoomed body (compact + comfortable variants) so token-driven text (hub Nightly Reports) scales once. QS sub-labels updated (“entire interface — views included” / “text and views — chrome geometry keeps its size”, localized). Verified live: hub frame adopts fs 115 → child view-body zoom 1.15; inline Nightly Reports zoom 1.15; frame-hosting body stays 1.

## Framework 1.10.7 — product shortcuts work in the hub (2026-08-31)

- CEO: the product groups (Panel · Workspace · Timeline) were missing from index.html's '?' sheet and their keys did nothing on framed dashboards. Three legs:
  1. **Groups relay up** — `WV.registerShortcuts` in an embed child posts `{wv:"shortcuts",product,groups}` (at registration — products register AFTER embInit, so the ready-time send alone was too early); the hub handler feeds them into `WV.registerShortcuts` locally, so `renderProdKeys` shows shell + the active product's groups.
  2. **Keys forward down** — `fwdKeyToFrame(e)` at the end of the shell keydown: a key the shell did not claim, of a product shape (⇧+letter · plain ←/→ · Home/End/Space), posts `{wv:"key"}` to the ACTIVE view's frame (`#wv-panels [data-uid] iframe` — the panel, not the tab button that shares the uid); the child replays it as a KeyboardEvent on its document. Pointer-over-panel keys work because :hover is a pointer fact, independent of focus. Space/arrows preventDefault so the hub page never scrolls.
  3. **'?' inside a frame** posts `{wv:"key-help"}` and the HUB's sheet opens — the relay sits BEFORE the `dataset.in` sign-in gate (an embed has no sign-in; this also explains why '?' in a focused frame did nothing before).
- Verified live: hub sheet = Application shell + ftm's 4 groups; Shift+M / Home replayed in the frame; '?' from the frame opens the hub sheet. Suite: 4 checks in the hub block. dist refreshed to 1.10.7 (byte-identical index.html + 7 dashboards).

## 2026-08-31 — bafc integrated: dashboards/BA_Margin_Capacity_Dashboard_wv0.8.html (framework 1.10.7)

- **New product `bafc` — BA Forecast & Capacity Console** (raw `dashboards/BA_Margin_Capacity_Dashboard_v0.8.html`,
  1.35 MB, untouched). Converted per genie-shell-integrate on the 1.10.7 chunks (byte-exact sentinel
  extraction; `splice_shell.py --dry` confirms the file is a no-op at 1.10.7). Output ~2.43 MB, CRLF,
  `wv-app-id=bafc`. Full catalog + bridges in WV-PRODUCT-REGISTRY.md (bafc section).
- **Views (9):** `bafc.realtime` Real-Time · `bafc.planning` Planning · `bafc.analysis` Analysis ·
  `bafc.management` Management · `bafc.all` All Panels (Capacity Desks, singleton `applyMode`) ·
  `bafc.verify` Margin Verification · `bafc.explore` Data Explorer · `bafc.factors` Assumptions
  (Drill-Downs, singleton `activateTab` in the current mode — the raw v5 drill-down semantics) ·
  `bafc.guide` User Guide (blob-iframe renderer, All-mode capture like the raw `buildHelp`).
- **Bridges implemented:** genieRead.set (7 worst-first pinned-hour reads, KIND lead + meta→insights;
  first two feed the sign-in briefing) · raiseAlarm (8-condition `buildAlarms`, alarmKey dedup, ack set
  respected, crit/maj map) · setSystemState (6 FEED_SOURCES systems, age-vs-cadence → live/degraded/stale,
  re-derived on wv:time; ships 3 degraded — honest) · Genie's Desk (outstanding follow-up shift notes →
  attention items) · info (`wv:info` → its `setInfoMode`; INFO registry → `WV.info.resolve`; root +
  overlays carry `data-wv-product-root`) · shortcuts (3 groups; Shift+A/G/T, `?`, Esc rows dropped) ·
  5 palette actions · ~150-key i18n (fr-CA/es-MX/ar/ja) · shell-prefs bridge (density/motion attrs,
  ground + pinned-accent mirroring with change-signature re-render, fmtClock + shift-note stamps via
  WV.fmt.time; NO self-zoom — UI scale × Font size is the shell's --wv-vz since 1.10.6) · embed §5
  honored incl. `&band=1` and per-panel solo popouts re-routed to `#wv-embed=bafc.all&panel=…`.
- **Structurally n/a, documented (not faked):** no central number formatter (domain-styled MW/normalized
  figures keep their fixed formats); `fmtDay` stays ISO (doubles as a data key in export filenames);
  canvas/SVG chart internals + generated guide prose outside i18n; basemap tiles (CARTO/Esri) are
  runtime product behaviour (the only network the file touches); user-config cog + workspace caret
  hidden (shell workspaces supersede; mode data model + storage intact); `writeHash` suppressed under
  the shell (deep-link params still honored INBOUND via readHash in embeds/popouts).
- **Global-collision hygiene:** the raw console's top-level `toast` / `renderAll` / `renderAlarms` /
  `renderGenieRead` shadow the SHELL's identically-named globals (later classic script wins) — renamed
  `bafcToast`/`bafcRenderAll`/`bafcRenderAlarms`/`bafcRenderGenieRead` (ftm did the same in its round).
  ⚠ FLAG for a future cleanup round: **btm still declares `toast`, and pf declares `toast` +
  `renderAlarms`** at top level over the shell's — latent override of the shell's toast/alarm-drawer
  render in those two files (not addressed in this round; product-side delta candidates).
- **Vendoring note:** Leaflet 1.9.4 copied from `btm_soc_forecast_dashboard_wv1.1.html` — the work
  order named dlr-genie-map as the source, but that file is a static SVG snapshot and carries no
  Leaflet; btm/pf hold the canonical vendored block. Zero external library/font requests.
- **Hub (`index.html`):** FILES/HOME/ORDER + `WV.registerProduct` (guide:`bafc.guide`) + 9-view catalog
  + i18n additions (Capacity Desks/Drill-Downs/Real-Time/Planning/Analysis/Management/Margin
  Verification/Data Explorer/Assumptions). Everything else (frame relay, exclusive switch, alarm
  dedupe + product-prefixed sources, feedHubRead merge, 1.10.7 shortcuts up/keys down, theme/prefs/info
  relay) is the generic hub machinery — verified live: frame ready, "BA Forecast & Capacity Console ·
  Forecast adequacy" alarms in the drawer, 6 systems relayed, theme light/dark round-trip in-frame.
- **Tooling:** file added to `tools/splice_shell.py` TARGETS and `tools/verify_shell.py` DEFAULT_SET
  (smoke). dist refreshed: `dist/index.html` + `dist/dashboards/BA_Margin_Capacity_Dashboard_wv0.8.html`
  byte-identical; dist README count 7→8, stamp 1.10.6→1.10.7 (was stale).
- **Verification (all green, zero pageerror + zero non-tolerated console.error):**
  - product deep suite (session scratchpad `bafc_verify.py`): **62/62** — boot/startupWs, all 9 views
    with real content markers, singleton move + toast, guide-outside-singleton, read/alarm/health/desk
    bridges, nav reroute (mode seg, drill-down buttons, back buttons, writeHash silence), info
    float+dock via resolve, theme round-trip (basemap follows), prefs (density/motion/ground/pinned
    accent/auto restore), no-scroll (4 primary views + Full View, deficit 0), hotkey scoping (works
    mounted, stands down under uiBusy, capture-Esc closes product modals first), i18n fr-CA/ar +
    lossless return, embed chromeless + band + panel-solo + shell popOut window.
  - `verify_shell.py --smoke` standalone (8890): **13/13**.
  - FULL hub gate `verify_shell.py --url http://localhost:8890/index.html`: **576/576**.
  - `splice_shell.py --dry`: all 9 targets no-op byte-identical at 1.10.7 (new file included).
  - dist smoke (8899, server killed after): **13/13** + dist-hub bafc frame ready, zero errors.

## 2026-08-31 — conv RE-INTEGRATED from a newer raw: dashboards/conversationAndFeedback_wv1.1.html (framework 1.10.8)

- **A newer raw arrived** — `dashboards/conversationAndFeedback_latest.html` (412 KB / 6055 lines vs the
  old `conversationAndFeedback.html` at 250 KB / 3406 lines). wv1.0 was discarded and the product was
  converted from scratch on the current chunks; `wv-app-id` stays `conv`, so stored prefs, sessions and
  workspaces carry over. Both raws remain untouched. Output **1,442,161 bytes**, CRLF.
- **What the new raw brought** (same review model, rebuilt on the *Genie standard chrome*):
  - a full top bar — clock · alarm bar + severity/sort/multi-ack popover · user chip · shortcuts ·
    help · Info split control (glyph + Floating/Docked caret menu) · theme · health chip + popover ·
    sign-out · measured overflow into a hamburger;
  - a **filter row** (Range 7/30/90 · Mode segment · configuration gear · workspace caret · export)
    with its own measured fold;
  - an in-page **Genie's-Read strip**: six domain kinds (action · opportunity · constraint ·
    divergence · waste · headroom), rotating every 10 s;
  - a real **alarm engine** — 6 conditions derived from the review model (stale queue · unclosed loop ·
    thumbs-down rate · context-window cluster · a diverging agent · thin coverage). wv1.0's registry
    note "**No alarm concept**" no longer holds;
  - a **health** derivation (4 checks) replacing wv1.0's single data-load system;
  - **three panel MODES** (Monitor · Triage · Analysis) + a configuration modal that drags panels
    between them, Save-as workspaces and a 20-deep undo;
  - per-panel **kebab actions** (CSV · pop out · maximize · collapse · PNG · copy · pin · hide), an
    **export dialog** (XLSX/CSV/PDF/JSON, hand-rolled), a **shortcuts sheet**, an **INFO registry**
    (11 entries) and a **user guide** page;
  - row density moved into the list header; the Admin-view (Full/Limited) control and the charts
    show/hide toggle were withdrawn by the raw (`applyRole` intact but unbound, `setChartsHidden`
    kept as the API).
- **View catalog 1 → 4** (a mode is a real display, so each is a view over the ONE page):
  `conv.monitor` Review Monitor · **`conv.history` Conversation History (HOME, id+name kept)** ·
  `conv.analysis` Quality Analysis · `conv.guide` User Guide (own renderer, registered as the
  product's `guide`). Group `Conversation Review`; the guide under `Reference`. Order and home
  semantics in the hub unchanged. Full detail in WV-PRODUCT-REGISTRY.md (conv section).
- **Genie's Read now fills BOTH scopes.** GLOBAL = the raw's six kinds, worst-first (reads[0..1] feed
  the sign-in briefing, kept speakable). LOCAL = **exactly 2 reads on every one of the four views**,
  each computed from that view's own data with a cta that acts on that view, refiled on every product
  re-render — the Local scope never renders the empty state on a conv tab. Headlines:
  - `conv.monitor` — "Satisfaction reads 78% (+16.2 pts) but rests on 34% coverage — 80 of 233
    conversations were rated at all." (cta: widen the window to 90d) · "Deals Validation carries 6 of
    the 22 thumbs-down in the ring — 27.3% of its own rated answers against a fleet rate of 27.5%."
    (cta: filter both charts to Deals Validation)
  - `conv.history` — "12 conversations need review — the oldest has waited 28d." (cta: open the Needs
    review queue) · "5 complaints were concluded and never sent back — the oldest conclusion has sat
    26d; 50% of conclusions have been answered." (cta: open the Awaiting reply queue)
  - `conv.analysis` — "Thumbs-down is running at 27.5% of rated answers over 30 days — 22 down against
    80 rated." (cta: group the list by context signal) · "8 of 22 thumbs-down (36%) match the
    context-window signature, not an agent fault." (cta: open the Context-limited queue)
  - `conv.guide` — "The guided tour walks 11 steps of the live console, and it opens on the queue: 12
    conversations are waiting on a reviewer right now." (cta: start the guided tour) · "11 regions of
    this console carry their own explainer, and 10 product shortcuts in 3 groups act on the panel
    under the pointer." (cta: open the shortcuts sheet)
- **House rules held** (CEO 2026-08-30, carried from wv1.0 and re-aimed at the new markup): only the
  KPI tiles rounded (11px), filter strip / chart panels / queues+list / footer on 4px; the **1560px
  centred canvas**, not full-bleed (the split dock still lifts the cap); tiles in Powerflow's tile
  language — one family tone per tile, 30px badge, plain description line with the trend as coloured
  emphasis (not a pill), mono tone footer, and a **mini sparkline in EVERY tile** (the raw ships one
  on a single tile, so `kpiSeries()` computes the other four); no dot texture outside the shell band;
  scope labels Global / Local.
- **Global-collision sweep:** the raw's first script declares `toast`, `renderAll` and `spark` at top
  level — the same names the shell's own script declares. Both product scripts are wrapped in their
  own closures, so nothing reaches `window` and the shell's four stay intact (verified: the shell's
  toast renders the singleton notice while the product's `toast` routes to `WV.toast`). The raw's
  second script was already an IIFE; because the first one now is too, the chrome layer takes the
  review model through the `window.convShell` seam instead of shared globals (`syncModel()` re-reads
  `conversations`, which `applyRole` re-points).
- **Raw gaps fixed at root cause** (named, not silently): `waterfall()` was called by the run bar but
  never defined; `setView()` was called by the alarm rows and the read strip behind a `typeof` guard
  but never defined; the guided tour's chart step clicked a `#chartsBtn` the Genie-standard rebuild had
  retired — a TypeError in Triage, the default mode, where the chart row is off.
- **Conversion-caused layout fix:** Monitor's chart row now fills the panel (the raw's fixed 212px left
  the lower half of a first-class view empty), with the donut capped at the size it has in the raw so
  the per-agent list keeps its width and no agent name truncates. Triage and Analysis keep the raw's
  rhythm. A defensive clamp in the prefs bridge rejects an out-of-band scale x fontScale rather than
  collapsing the page to an unreadable zoom.
- **Structurally n/a, documented (not faked):** no chart or map library to vendor — every chart is
  hand-written SVG, so `onTheme` needs no rebuild (the tokens recolor it) and the file makes **zero**
  external requests of any kind, at load or at runtime; a product's reads do not bubble into the HUB's
  band (the embed protocol relays reads parent to child only — framework-level, identical for every
  product); the product's own pop-out windows are separate untranslated documents that copy
  `style[data-conv-css]` only.
- **Retired:** `dashboards/conversationAndFeedback_wv1.0.html` and its 24 `*.pre-*.html` backups
  deleted (no other product's backups touched); `dist/dashboards/conversationAndFeedback_wv1.0.html`
  removed. Target lists updated: `tools/splice_shell.py` TARGETS to the new filename;
  `tools/verify_shell.py` DEFAULT_SET — **conv added** (it was absent — the propagation set lists it,
  so the durable suite now covers it at the new filename).
- **Hub (`index.html`):** FILES to `dashboards/conversationAndFeedback_wv1.1.html`; `WV.registerProduct`
  gains `guide:"conv.guide"` and the 4 real systems; the 1-view catalog replaced by the 4 views; i18n
  additions (Conversation Review / Review Monitor / Quality Analysis). `HOME.conv` stays `conv.history`
  and `ORDER` is unchanged. dist refreshed: `dist/index.html` + the new conv file byte-identical (md5
  checked both ways).
- **Framework stamp — deviation to note.** The brief pinned 1.10.7, but `GenieApplicationShell.html`
  was being rewritten to **1.10.8** while this round ran (its length changed between two reads). The
  chunks were therefore taken from the framework only after a two-read stability check, and 1.10.8's
  delta was diffed first: it is purely additive in `js-render` + `js-app` (the shell files two LOCAL
  reads for its OWN views — Settings and the Framework Guide — the same CEO requirement this round
  applies to products) with **no product-side delta**, so conv ships at 1.10.8. The other eight files
  are still at 1.10.7 pending the parallel propagation round; `splice_shell.py --dry` reports conv as
  **no-op (byte-identical)** and every other target as CHANGED for exactly that reason.
- **Verification (all green, zero pageerror + zero non-tolerated console.error):**
  - product deep suite (session scratchpad `verify_conv.py`): **112/112** — registration + startupWs,
    all 4 views with real content markers, mode-to-view mapping, the singleton move + its notice,
    BOTH read scopes (Local asserted at exactly 2 reads / working ctas / real figures / insight rows /
    never-empty on every view, and refiled on a filter change), the 6 alarms into the shell drawer
    with dedup, the 4 systems, Info dock over 8 product regions + the `conv:kpi:` and `conv:view:`
    resolvers, shortcut rows with the shell's own rows dropped, 6 palette actions, Genie's Desk,
    i18n fr-CA/ar + lossless return + direction:ltr, theme round-trip both ways, density, scale x font
    zoom, the 1560px cap + the corner rule + the tile language, no-scroll in all 3 panel views,
    embed chromeless + `&band=1` popout on the Local scope, drawer open/Esc-bridge, lens switch,
    panel menu in the overlay host, the guide view.
  - `verify_shell.py --smoke` standalone (8890): **13/13**.
  - FULL hub gate `verify_shell.py --url http://localhost:8890/index.html`: **575 pass / 1 fail** —
    the single fail is the HUB's own stamp (1.10.7 vs the framework's in-flight 1.10.8), which the
    parallel propagation round owns; zero pageerror and zero console.error across the hub, every child
    frame and the popouts.
  - hub-conv targeted check (`hub_conv.py`): **18/18** — all 4 views frame the wv1.1 file via the embed
    protocol and render, alarms bubble with the product-prefixed source, 4 systems relayed, theme
    reaches the child, both themes screenshotted.
  - `splice_shell.py --dry`: conv **no-op (byte-identical) at 1.10.8**.
  - dist smoke (8899, server killed after; 8890 never touched): **13/13** + dist-hub conv **18/18**.
- **Open, for the coordinator:** the `genie-shell-update` skill's propagation-set table still names
  `dashboards\conversationAndFeedback_wv1.0.html` — skills are the coordinator's to edit. `dist/README.md`
  still reads "framework 1.10.7"; it will be right again once the 1.10.8 propagation lands.

## 2026-08-31 (evening round) — bafc overlay fix · framework 1.10.8 · Local reads everywhere · conv re-integrated

**1 · bafc panel menus were dead (structural).** The converted file's parked block was ONE `</div>` short, so `#wv-park` (which is `hidden`) never closed and `#bafc-overlays` parsed INSIDE it. Every overlay it hosts — the panel kebab menu, the info card, the info menu, toasts — rendered at zero size (`display:flex`, rect 0x0) in the hub AND standalone. The close was restored; the menu measures 166x215 again and is the top element at its own coordinates. LESSON for the integrate skill: after assembly, assert the parked block is balanced and that `#<pid>-overlays` is a child of `<body>` at runtime, not of `#wv-park`.

**2 · Framework 1.10.8 — the shell files Local reads for its OWN views.** `shellFeedViewReads()` (+ `shellPrefDiffs()`) files two computed reads on the Settings view: which preferences differ from `PREF_DEFAULTS` (named, counted, with a reset CTA) and the genie's voice/briefing/listening state (with a CTA into those rows). Refiled from `prefChanged` and 600 ms after sign-in, so Local is populated from the first screen. The Framework-Guide branch is a graceful no-op when no guide view is registered (the framework's own catalog has none).

**3 · Local Genie's Read on EVERY product view (CEO ruling).** An audit of all 40 product views found ZERO view-scoped reads — products filed Global only, so the Local scope showed the honest empty state everywhere. Every product now files exactly 2 view-scoped reads per view, computed from that view's own live state, each with a runnable CTA, refiled on the same events as the Global read:
- ftm (5) + btm (6): `ftmFeedViewReads` / `feedViewReads`; btm additionally hooks the energy lookback slider, which bypassed the shared render sweep.
- ev (7) + dlrmap (1) + dlrline (1): `evFeedViewReads` via the throttled `__evFeedRead`; the two DLR snapshots re-derive from what the snapshot contains rather than inventing telemetry (a filter-chip vs table census inconsistency in dlrmap was found and kept out of the read text).
- pf (10) + bafc (9): `pfFeedViewReads` / `bafcFeedViewReads` with debounced refeeds wrapped around ~28 product entry points. Three accuracy defects were caught in self-review (a thermal limit described as an import limit; `helpSections()` returning a string not an array; nameplate vs derated capacity for `Other`/`Battery`).
- conv (4): filed as part of its re-integration.
Rule promoted into `genie-shell-integrate` ("Genie's Read must fill BOTH scopes") and enforced by the suite: the shell's Settings view must carry 2 Local reads, and sampled product home views must too.

**4 · Conversation & Feedback re-integrated as `conversationAndFeedback_wv1.1.html`** from a new raw (250 KB/3.4k lines -> 412 KB/6.1k lines): the new build carries the Genie standard chrome, a real 6-condition alarm engine, health derivation, three panel MODES + configuration/workspaces, per-panel kebabs, export dialog, shortcuts sheet, an 11-entry INFO registry and a user guide. Catalog grew 1 -> 4 views (`conv.monitor`, `conv.history` (home, id kept so prefs/links carry), `conv.analysis`, `conv.guide`). Two raw defects fixed at root cause (`waterfall()`/`setView()` called but never defined; the tour clicking a retired `#chartsBtn` — a TypeError in the default mode). wv1.0 and its 24 backups retired.

**5 · Tooling gap closed:** `pf` was missing from the suite's `DEFAULT_SET` (it was in the splice set) — added, so the standard run now covers framework + hub + 8 dashboards + file:// hub.


## 2026-08-31 (late) — conv re-integrated from the v11 raw as `dashboards/conversationAndFeedback_wv1.2.html` (framework 1.10.10)

**Headline finding first: the "newer raw" is not newer.** `dashboards/conversationAndFeedback_v11.html`
and `dashboards/conversationAndFeedback_latest.html` (the raw wv1.1 was built from a few hours
earlier) are **byte-identical** — md5 `bfa7789efb1110eb9268b99678b49827`, 412 627 bytes both. A
line-by-line diff is empty. v11 is the same CEO build under a version-stamped filename, so there is
no UI or content delta to carry across: everything the brief describes as the v11 design (full-bleed
layout, the MODE segment Monitor/Triage/Analysis, RANGE 7d/30d/90d, the in-page GENIE'S READ strip,
the queues/lenses row, the conversation list) was already converted faithfully in wv1.1. wv1.2 is
therefore wv1.1's product layer, unchanged in behaviour, with the round's two real deltas applied.

**Delta 1 — FULL WIDTH (CEO).** wv1.1 pinned `#conv-root .viewport{max-width:1560px;margin:0 auto}`
(a rule inherited from wv1.0, where the older, narrower raw looked over-stretched full-bleed). The
v11 UI is designed full-bleed, so the cap is retired: `max-width:none;margin:0`, padding/gap kept.
A static guard in the build script asserts no numeric `max-width` survives on `#conv-root`, `.page`,
`.viewport`, `#kpis`, `#panels`, `.cmd` or `#panel-list`, and that the only remaining `margin:0 auto`
in the product CSS is `#conv-guide-host{max-width:900px}` — the User Guide's prose measure, which
deliberately matches the framework's own `.wv-guide-wrap{max-width:920px;margin:0 auto}` (it is a
document, not the v11 layout). Measured proof, standalone and inside the hub frame:

| viewport | canvas available | canvas rendered | tile row | list |
|---|---|---|---|---|
| 1913 px | 1841 px | **1841 px** | 1813 px | 1813 px |
| 1400 px | 1328 px | **1328 px** | 1300 px | 1300 px |

Δviewport 513 px = Δcanvas 513 px — the layout tracks the frame 1:1 with no cap and no centring.

**Delta 2 — the framework moved mid-round.** The brief named 1.10.9; `GenieApplicationShell.html`
went to **1.10.10** while the file was being assembled (the gread relay fix: a relayed read is no
longer echoed back up, and an embedded child now relays BOTH scopes — view-scoped for the host's
Local band and product-scoped with `view:null` for a host roster). wv1.2 was spliced to 1.10.10 with
the canonical `tools\splice_shell.py`; no product-side contract delta was required.

**Genie's Read — both scopes, and Local now reaches the HUB band.** The registry's wv1.1 note that
"a product's reads do not bubble into the HUB's band" no longer holds: since 1.10.9 the child posts
`{wv:"gread-up"}` for every view-scoped set and the hub re-files it with wired-back CTAs. Verified
in the PARENT window (not inside the frame) — `GREAD.views['<id>'].reads.length === 2` for all four
views, and `setGreadScope('view')` renders the child's read instead of `.wv-gr-empty`. The 8 Local
headlines as they arrive in the hub band:

| view | read 1 | read 2 |
|---|---|---|
| `conv.monitor` | Satisfaction reads 78 % (+16.2 pts) but rests on 34 % coverage — 80 of 233 conversations were rated at all. | Deals Validation carries 6 of the 22 thumbs-down in the ring — 50.0 % of its own rated answers against a fleet rate of 27.5 %. |
| `conv.history` | 12 conversations need review — the oldest has waited 28d. | 5 complaints were concluded and never sent back — the oldest conclusion has sat 26d; 50 % of conclusions have been answered. |
| `conv.analysis` | Thumbs-down is running at 27.5 % of rated answers over 30 days — 22 down against 80 rated. | 8 of 22 thumbs-down (36 %) match the context-window signature, not an agent fault. |
| `conv.guide` | The guided tour walks 11 steps of the live console, and it opens on the queue: 12 conversations are waiting on a reviewer right now. | 11 regions of this console carry their own explainer, and 10 product shortcuts in 3 groups act on the panel under the pointer. |

Every one carries a CTA that acts on its own view (open Needs review / open Awaiting reply / group
by context signal / open Context-limited / widen the window / filter both charts to the agent /
start the tour / open the shortcuts sheet), all executed in the suite. Global scope is unchanged:
the raw's six domain kinds worst-first, so reads[0..1] still feed the sign-in briefing.

**View catalog — unchanged (4).** The v11 raw's `DEFAULT_MODES` are still Monitor · Triage ·
Analysis, so the three mode views plus the User Guide stand as registered:
`conv.monitor` Review Monitor (Dashboard) · `conv.history` Conversation History (Console, HOME) ·
`conv.analysis` Quality Analysis (Chart) · `conv.guide` User Guide (Report). App-id `conv` and every
view id kept, so stored prefs, sessions, workspaces and deep links carry over untouched.

**Mandatory sweeps (integrate skill).**
- *Global-collision sweep*: clean. The whole product layer is inside one IIFE closure, so the raw's
  `toast` / `renderAll` / `renderAlarms` / `spark` / `esc` / `num` never reach the shell's globals;
  the product's `toast` delegates to `WV.toast`. No rename was needed.
- *Parked-block balance*: static walk of `<div>`/`</div>` across the parked region — depth 0 exactly
  where `#conv-overlays` opens and 0 at the end, with nothing but comments between the park's close
  and the overlay host. Runtime pair added to the deep suite:
  `#conv-overlays.parentElement === document.body`, it is NOT inside `#wv-park`, and an opened panel
  kebab menu measures **205 × 208** (non-zero) — the bafc failure mode cannot recur silently here.

**Retired.** `dashboards/conversationAndFeedback_wv1.1.html` and its `*.pre-*` backup deleted; no
other product's backups touched. `conv` repointed to the new filename in `index.html`'s WV-PRODUCT
block (`FILES`), `tools/splice_shell.py` and `tools/verify_shell.py` (`DEFAULT_SET`).

**Suite totals (all green).**
- `splice_shell.py --dry`: conv **no-op (byte-identical)** at 1.10.10 (whole set no-op).
- `verify_shell.py --url .../conversationAndFeedback_wv1.2.html --smoke`: **13/13**, 0 pageerror,
  0 non-tolerated console.error.
- product deep-verify (`verify_conv12.py`, 1680×1000): **120 pass / 0 fail** — every view renders
  its content marker, both read scopes populated, alarms/health/info/i18n/prefs/embed/popout/band,
  both themes, density and scale, the no-scroll contract in all three modes, the full-width proof
  at 1913 px and 1400 px, and the runtime overlay pair.
- hub check (`hub_conv12.py`): **44 pass / 0 fail** — all four views frame the wv1.2 file over the
  embed protocol and render, 2 relayed Local reads per view measured in the top frame, full width
  inside the frame at both viewports, alarms bubble with the product-prefixed source, 4 systems
  relayed, theme round-trip, dark + light screenshots.
- Output: **1 443 784 bytes** (wv1.1 was 1 412 557 at 1.10.9; the growth is the 1.10.10 shell).

**Deviations / notes for the coordinator.**
1. The premise "a NEWER raw supersedes" is false — the two raws are byte-identical (proof above).
   Nothing was invented to manufacture a delta; wv1.2 is wv1.1 + full width + 1.10.10.
2. The in-page GENIE'S READ strip of the v11 design stays retired in favour of the shell band (the
   commons principle and the integrate skill's rule 1). The CEO's own framing lists the band as
   shell-owned chrome, so this is not a UI change to the v11 design — it is where the band lives.
3. `#conv-guide-host` keeps its 900 px prose measure (framework parity). Everything that is layout
   is uncapped.
4. The full hub gate, `dist\`, the skills and memory were NOT run or touched — the coordinator owns
   them. The `genie-shell-update` propagation-set table still names `conversationAndFeedback_wv1.1.html`
   and needs the wv1.2 rename; `WV-PRODUCT-UPDATES.md` history entries above this one still cite
   wv1.1 by name (left as written history).
5. The port-8890 server was never restarted or killed.

## 2026-08-31 — framework 1.10.10 · the HUB's Genie's Read Global scope is the FLEET ROSTER (8 dashboards = 8 reads)

**The ask (CEO).** "Global Genie Read should show 8 genie reads and local per dashboard/view should
show just 2 reads — currently global is also showing just two reads." Global carried only the hub's
own pair (fleet summary + Nightly Reports), so the pager read 2.

**Framework 1.10.10 (one change, both halves of one relay).** `WV.genieRead.set` now relays BOTH
scopes up from an embedded child, not just the view-scoped ones: `{wv:"gread-up", product, view,
title, reads}` with `view:null` for the product-scoped (Global) reads. The payload is
`grSerial(grReads(bag[key]))` so the index the host sends back in `gread-run` lines up with the
child's own bag. A `relayed:true` marker on the reads the child files FROM the host's `{wv:"gread"}`
brief stops the host↔child echo that both scopes would otherwise sustain (a real 1.10.9 ping-pong
in band popouts — measured 0 extra messages over 8 idle seconds after the fix). Spliced into all
eight dashboards and the hub with `tools/splice_shell.py`; `--dry` is no-op for all nine files.

**Hub layer (index.html, WV-PRODUCT block, section 8b — nothing outside the read-composition area).**
- `HUBGR` (`window.WV_HUB_GREAD`) caches each product's OWN Global reads for the session. Exclusive
  display tears a frame down on every product switch, so the roster keeps the last read the product
  itself filed rather than re-deriving or inventing one after it is gone.
- `fleetReads()` composes exactly **one read per registered product, eight of them**, each headlined
  with the product name.
  - Product HAS been live this session → its own relayed read, verbatim, name-prefixed. Its CTA and
    insight actions route back INTO the live frame (`{wv:"gread-run", scope:"global"}`) exactly as
    the Local reads do; when the product is not on screen the CTA switches to it and opens its home
    view instead, and the insight actions (whose functions live in the torn-down frame) are dropped
    rather than faked.
  - Product has NOT run → an honest hub-derived line built ONLY from what crossed the frame
    boundary: relayed unacknowledged alarms by severity, relayed dependent-system health (`HUBSYS`,
    never the registration defaults), its catalog view count, its home view, and whether it ever
    connected. It says so in the read ("This is the hub's own summary … the product has not been
    running in this session"). No product-internal metric is ever invented.
- **Ordering — worst-first, in coarse buckets:** 0 an unacknowledged critical alarm · 1 a major alarm
  or a stale dependent system · 2 a degraded system or lesser alarms · 3 clean; ties keep `ORDER`.
  Buckets change rarely, so the pager does not reshuffle under the operator's eyes.
- **The hub's own two reads moved to LOCAL scope** — they are the two view-scoped reads of the hub's
  own shell-level view **Nightly Reports** (`hub.report`): [0] the report read, [1] the fleet summary
  with its "open the fleet grid" CTA. That keeps Global exactly the eight dashboards (the standing
  "2 Local reads per view" rule now covers a hub view that had only one).
- Local scope is untouched: the frame's two view-scoped reads, exactly as 1.10.9 filed them.

**Verified (own Playwright suites, localhost:8890, 1913×939).**
- Fresh sign-in: Global = **8 reads, 8 pager dots**, one per product, every headline non-empty, every
  CTA present; paged through all eight and ran every CTA — 0 pageerror.
- Local: exactly **2** reads on the landing view and **2** after switching view, and they change with
  the view.
- Upgrade: `btm` / `ev` / `bafc` each went from "… not opened yet this session · N views · meta: hub
  summary" to their own relayed read ("ACTION — ZONE-NE-3_SELF_CONSUMPTION …" etc., meta "its own
  read"). After the CTA sweep all eight products were cached.
- A relayed critical alarm on `bafc` moved it to index 0, tone `crit`, meta "1 alarm open, 1 critical".
- Nightly Reports (Local) carries the hub's 2 reads and the fleet CTA runs.
- `splice_shell.py --dry`: **no-op (byte-identical) for all nine files**.
- 0 pageerror throughout; the only console.error is the pre-existing `/favicon.ico` 404 (identical on
  the pre-change baseline).

**Deviations / not fabricated.**
1. An alarm burst (framework's `summaryRead`, ≥10 alarms in 30 s) still prepends the framework's own
   alarm summary, which would page as a transient 9th read. That is framework behaviour, deliberately
   left alone; it does not fire on a fresh sign-in (measured 8 dots with 12 alarms already relayed).
2. Nothing product-internal is stated for a product that has not run — no fabricated KPI, no health
   claim from the registration defaults. Dependent systems that never reported are described as
   "N dependent systems registered, none reporting yet".
3. The full hub gate, `dist\`, the skills and memory were NOT run or touched; the port-8890 server was
   never restarted. No `conv` file was edited (the concurrent round owns those).

## 2026-08-31 (late) — reads cross the frame boundary (1.10.9/1.10.10) · Global = fleet roster · conv wv1.2 full-width

**The bug under all of it:** `WV.genieRead.set` had NO child->parent relay — only parent->popout. Products filed their reads correctly inside their own frame, but in the hub the band could only ever show hub-owned reads. Local was empty on all 40 product views and Global showed 2. Fixed in **1.10.9** (child relays view-scoped reads up as `{wv:"gread-up"}`; the host files them and routes their actions back down as `{wv:"gread-run"}`) and **1.10.10** (Global reads relay too; a `relayed:true` marker stops the host<->child echo that 1.10.9 introduced — measured 0 extra messages over 8 idle seconds).

**GLOBAL = the fleet roster (hub layer, section 8b).** Exactly one read per product, name-headlined, worst-first in coarse buckets (critical / major-or-stale / degraded / clean; ties keep ORDER) so the pager does not reshuffle while it is read. A product live this session shows ITS OWN relayed read (actions routed into the frame when on screen, otherwise the CTA switches product and opens its home); a product never opened shows an honest hub-derived line built only from relayed alarms, relayed health, catalog size and connection state — nothing product-internal is invented. `HUBGR` (`window.WV_HUB_GREAD`) caches a product's own reads for the session so exclusive display (frame teardown) does not lose them. The hub's own two reads moved to Nightly Reports' LOCAL pair, so Global reads exactly as the eight dashboards. Park seam: `WV_HUB_GREAD.paused=true` holds the roster still (the roster owns the product-scoped bag, so anything else filing Global reads for the active product would be overwritten on the next tick).

**conv wv1.2.** `conversationAndFeedback_v11.html` proved BYTE-IDENTICAL to `conversationAndFeedback_latest.html` (md5 bfa7789efb1110eb9268b99678b49827) — same CEO build under a version-stamped name, so no UI delta was manufactured. Real deltas: the viewport cap is removed (`max-width:none;margin:0` — measured 1:1 tracking, 1913->1841 px and 1400->1328 px canvas) because the v11 layout is designed full-bleed, reversing wv1.1's 1560 px cap; the User Guide keeps a 900 px prose measure to match the framework's own guide. 4 views, app-id and view ids kept; wv1.1 retired.

**Suite.** Local-read checks (shell Settings pair, sampled product homes) + the roster assertion (one read per product, a pager dot each, actions present). Three gate lessons recorded: `f_hub` runs SECOND, so anything it opens strands later features — it now restores the landing product; the roster must be parked around blocks that file their own Global reads; the zoom checks need a shell-level view open in the hub because every product view is an iframe (exempt from the view-body zoom).

## 2026-08-31 (late 2) — conv overlays + raw-design parity · EV chip · pf lands on Network Map

**conv dead controls — two CSS faults, not handlers.** The gear (User configuration), caret (Layouts) and download (Export) opened at full size with content and were invisible: (a) `#conv-overlays{z-index:0}` made the overlay host a STACKING CONTEXT, trapping each dialog's own `z-index:1500` inside it while `#wv-embedRoot` (later in the DOM, position:fixed) painted over them; (b) the backdrop rule ended with `inset:auto` AFTER its four longhands, cancelling them so a fixed backdrop collapsed to shrink-to-fit. Both fixed in the product layer.

**New permanent guard (suite, every dashboard).** "product overlays paint on top and are clickable in embed mode": sweeps the product's own config/export/option/layout/menu/download/kebab buttons, clicks each, and HIT-TESTS what opens (`elementFromPoint` at the dialog centre must land inside it). It runs in EMBED mode because that is the only place the trap exists (`#wv-embedRoot` is the sibling that covers it) — and a hash-only navigation is same-document, so it reloads. **Validated by deliberately re-breaking a copy**: it fails with `cfgBtn -> BURIED:filterBar` and passes clean. Swept all 8 products: only conv was affected (25 trigger controls exercised).

**conv raw-design parity.** The CEO ruled the v11 raw is the design of record, so the earlier "Powerflow tile language" restyling was retired for the three named regions: KPI tiles (plain surface, 14px corner, 32px value, trend pill, sparkline only on the volume tile, raw's violet-ring + brand-gradient selected state), the Export control (inverse-surface pill, not the violet gradient) and the conversations grid (38px head, 12/16 rows with the 3px rail, capitalised neutral chips, circular avatar, sans footer). 43/43 computed properties now match the raw; 31/31 controls verified by clicking standalone AND in the hub. Chart-panel heads, the filter strip and shell-owned overlays stay (documented).

**ev** — the leftover product user chip no longer shows a hardcoded name ("PankajG"); icon + caret only, since the shell header owns identity. A pre-existing rule hid it only below 1180 px. (`bafc` still carries the same chip hardcoded to "Operator" — left as-is, not requested.)

**pf lands on Network Map.** `HOME.pf` → `pf.map` (hub) plus the product's own `startupWs` (`ws-pf-map`), recipe fallback, internal RT default tab (`net`), MODE routing and pop-out fallback — so the shell view and the product's tab strip agree on fresh sign-in, product switch, palette action and every one of the 10 views. Also fixed en route: `window.pfCurrentView` was **never defined**, so the panel kebab's "pop out" always popped a hardcoded view; it is now derived from the embed view or the last mount (verified pf.map / pf.results / pf.hca).

## Framework 1.10.11 — the sign-in greeting plays ONCE per context (2026-08-31)

- CEO: the welcome is ceremony, and ceremony on every sign-in is annoying. It should play once, and once more when the language changes.
- A CONTEXT is **this user x this device x this language**. `GREET_SEEN` (persisted `greetSeen` map, keyed `user|lang`) remembers it; `greetSteps()` is the ceremonial pair (native hello + welcome) shared by both paths; `genieGreetForLanguage()` fires from `prefChanged` when `S.lang` changes while signed in and that context has not been greeted (420 ms after the switch, so the UI has re-rendered first).
- Preference `greetFreq` replaces the Login-greeting on/off with **Once (default) · Every sign-in · Off** (row sub-label "spoken the first time — and after a language change"; localized). The old boolean migrates (`loginGreet===false` → `off`), and `S.loginGreet` stays as the derived master switch so every dependent row (Greeting style, Login briefing) keeps working unchanged. Reset preferences clears `greetSeen`, so a demo machine can be re-armed deliberately.
- The BRIEFING is operational, not ceremonial: it still runs on every sign-in per its own setting, including on a silent one. `VOICE.greeted` is set either way, so a later utterance never prepends its own hello.
- Suite: 7 new checks driven through the real sign-in path with the speech spy (first speaks · second silent · language switch speaks in the new language · switching back silent · that language silent from its second time · Every-sign-in still greets · Off silent) plus "a silent sign-in still delivers the briefing". `fresh_login()` now clears the greeting memory by default (each simulated sign-in is a first-time context, which is what the pre-1.10.11 checks assume) and takes `keep_seen` / `freq` for the block that tests the rule itself.

## Framework 1.10.12 — a read's action must not lose the dashboard (2026-09-01)

- CEO: clicking **Go to HE 20** / **Show Real-Time** in the Local band made the dashboard disappear. Reproduced: after the click the product root measured 0x0 and the frame's text went to zero, with no console error.
- Cause: the product's read-action helpers (`ftmJump`, `ftmFocus`, `ftmSetSchedule` — and the same shape in other products) call `openView(viewId)`. Inside an EMBED that mounted a view into the child's OWN hidden panel area and pushed `[data-wv-product-root]` back into `#wv-park`.
- Fixed in the framework, so it holds for every product: `openView()` in an embed no longer mounts locally. Same view (the normal case for a Local read — it is about the view on screen) = **no-op, nothing moves**; a different view = `postUp({wv:"open-view",viewId})` and the HOST opens it. The hub handler ACTIVATES an already-open instance rather than re-mounting (re-mounting was the other way to blank a frame).
- Suite: "every Local read action leaves the dashboard mounted" in the hub feature — clicks every cta/insight action on the landing view's reads and asserts the frame, the product root's height and its text survive.
- **Probe lesson (recorded so the next sweep is not misled):** `conv` and `bafc` mark BOTH their root and their overlay host with `data-wv-product-root`, and the overlay host is legitimately 0-height; a sweep that measured `querySelector('[data-wv-product-root]')` produced 5 false alarms, and a 6th came from measuring the wrong frame after an action legitimately opened a second view. Select `[data-wv-product-root]` excluding `*-overlays` / `*-guide-host`, and pick the tallest. Re-checked with the correct probe: conv and bafc were healthy (root 1841x661 with content) and the actions did their job.

## Framework 1.10.13 — selection states: edge rail + soft chip · underline + count pill (2026-09-01)

- CEO design review of the minimised sidebar and the Favorites tab. The old marks: a SOLID accent puck in the rail (the loudest mark in the system on the quietest information — read as "pressed", not "you are here") and a faint gradient wash on the active tab (ambiguous at 12px).
- Chosen from a 4x3 rendered study (options built in the shell's own tokens, judged as pixels): **D + T3**.
- **Rail (min)**: the sliding `.wv-railpuck` becomes a 10% accent chip with a hairline inset, plus a 3px accent **bar hugging the chip's left edge** (`::before`, radius 3, glow; CEO follow-up — flush with the RAIL edge it read as two marks with a gutter, against the chip they read as one object) that slides with it; the active glyph goes to full accent (was ink-on-fill — two legacy `--wv-acc-ink` rules updated). Motion is unchanged — the puck still slides, so selection still animates between items.
- **Tabs (expanded)**: active tab = 8% accent wash + a 2px gradient **underline** (house rule: active nav is an underline) + the count as a **mono pill** (accent-on-16% when active, muted otherwise; radius 999, tabular). The pill replaces the bare number so counts line up optically.
- Both marks derive from `--wv-acc`, so they follow the active product's accent and both themes automatically; neither state is colour-only (glyph brightens, count changes shape). Light theme verified.
- Two CEO follow-ups, both rendered before deciding: the bar moved from the rail edge to HUG THE CHIP'S LEFT EDGE (detached it read as two marks with a gutter; together they are one object), and the chip grew from a 36px square to, finally, a **FULL-BLEED rectangle** — the whole row edge to edge, SQUARE corners, the 3px bar running the row's full height on its left edge (CEO's final call after seeing the inset variant live; sized in `positionRailPucks` against the SIDEBAR's inner box, not the puck's host — the OPEN group's host (.wv-rail) is inset ~6px and left a gap on both sides until the CEO caught it; radius zeroed in min mode). The slide animation re-sizes with it.
- Suite: 4 checks in the launchpad block (underline geometry, pill typography, no-solid-fill + bar on the puck, accent glyph).

## Framework 1.10.14 — the genie quick menu (2026-09-01)

- CEO asked whether a speaker icon on the lamp would be useful or overcrowding; the ruling: no fourth permanent icon (permanent chrome must be earned by frequency; a mode toggle is not that). Instead: **right-click or long-press (~550 ms, touch) the lamp** opens a quick menu — Voice On/Off (turning Off also stops any current speech) · Listening On/Off · Voice commands sheet · Voice settings (opens Settings scrolled to the voice rows). Zero idle chrome; the lamp's silhouette is unchanged.
- Same `openDrop` dropdown pattern as the Info button's presentation menu; state shown per row (checkmark + On/Off sub-line); a long-press swallows the click that follows so the chat does not also open; a new `wv-i-spk` speaker symbol joins the icon set.
- Note for testers: on a fresh sign-in the FIRST lamp click yields the active briefing (1.9.4 design) — the second opens the chat; the quick-menu probe initially misread this as a regression.
- Suite: four checks in the briefing block (menu opens with all four entries; right-click does not open the chat; Voice toggles and closes; toggles back).

## Framework 1.10.15 — the read KIND chip (2026-09-01)

- The CEO supplied dashboard-wise Genie's Read content as tables of three parts: a **kind chip** (CHARGE · MARKET · AT LIMIT · WATCH · ACCURACY …), a one-line read, and **figures**. The band had no chip slot, so the contract grew one before the content could land.
- `WV.genieRead.set` reads now accept `kind` (a string, clamped to 18 chars). It renders between the tone dot and the headline as a mono-caps chip tinted by the read's tone (accent for info, `--wv-maj` for watch, `--wv-crit` for crit), and carries `data-wv-i18n-off` — a kind is **product wording** (an operator's category label), never translated.
- Added to `norm()` (the read normaliser) and to `grSerial()`, so the chip survives the frame relay in both directions: a product files it in an embed, the hub's band shows it.
- Figures map onto the existing `meta` chips, which already rendered — no change needed there.

## 2026-09-01 — the CEO's dashboard-wise Genie's Read content lands as LOCAL reads (ftm · btm · ev · dlrmap · dlrline)

The CEO's four tables (FTM 5 · BTM 5 · EV 5 · DLR 12) are **view-scoped Local** content, not Global — his correction: "These reads are all specific to dashboards, that means local". Global (the hub's 8-product fleet roster) is unchanged; each product's roster line keeps deriving from its own Global read.

**The principle held throughout, and it is the rule for every future table:** the tables are **TEMPLATES, NOT COPY**. "Charge 1.60 MW through HE 15:00 — Confidence 92%" is a *formula* against the product's live state, evaluated at file time and refiled on the product's existing events (hour scrub, site/resource/feeder switch, playback, filter, new run). Hardcoding the CEO's sample numbers would put 1.60 MW in the band while the chart says something else, and the demo dies on the first scrub. Where live state cannot honestly produce a figure, the nearest honest equivalent is used and the deviation is stated in the read's own summary.

- **ftm** (`ftm_optimization_dashboard_wv1.1.html`) — CHARGE/DISCHARGE/HOLD · MARKET · AT LIMIT · CURTAILMENT · OPPORTUNITY, distributed monitor/forecast/analyze/all with the kept reads chipped and every view sorted worst-first. #1's kind is the **live act**: the dispatch maths said Discharge at file time, and stamping "CHARGE" on a discharge would be fake. AT LIMIT has an honest-quiet variant ("No limit binds today — the closest is X at N%"); CURTAILMENT has zero-spill and battery-full variants; the export cap comes from the site's real POI limit, not the constraint table's fixed number.
- **btm** (`btm_soc_forecast_dashboard_wv1.1.html`) — WATCH · ACCURACY · UNCERTAINTY · REPORTING · RUN HEALTH, computed by **the product's own attention model** (the `attention`/`ranked` seam was exposed on `window.btmShell` so the configured 40/25/25/10 weights and comparators are reused, never re-derived). RUN HEALTH is fleet-wide by construction (it reads the run row), and says so rather than pretending to be per-resource.
- **ev** (`ev_dashboard_wv1.4.html`) — DISPATCH · AT LIMIT · FORECAST · ON-PEAK · UNCALLED across monitor/dispatch/forecast/analyze/fleet/all. The FORECAST read fires its **honest negative** when the band is not tracking ("2 of 7 elapsed intervals landed outside P10–P90"), and ON-PEAK declines to announce a zero as lost value when the window is already shaved to the must-serve floor. Clearing the feeder scope files a NO SCOPE/RESTORE pair instead of stale figures.
- **dlrmap** (`dlr-genie-map_wv1.4.html`) — the CEO's items 1–10, worst-first: TRIAGE · DERATE WINDOW · BOTTLENECK · EVENTS · WIND ANGLE · NEAR CLEAR · CRITICAL · HEADROOM · AT RISK · SPREAD. CTAs scroll-and-highlight the named table row / panel / playback marker **in place**.
- **dlrline** (`dlr-genie-line-details_wv1.4.html`) — items 11 and 12 (FORECAST · SPAN WIND) plus the line-scoped renderings of 5 and 6 (WIND HISTORY · NEAR CLEAR), all following the selected span at the shared hour.
- **Fixed while in there:** neither DLR page was subscribed to the shell's hour bus, so the status-bar scrubber never reached them and their reads could not move. Both now call `WV.time.subscribe(...)`; scrubbing Line Details walks the forecast read from `Aug 27 12:00 / 1,038.5 A / -1.1%` to `13:00 / 937.9 A / -10.7%` and the span-wind read to a different span.
- **conv · pf · bafc keep their current Local reads** — the CEO has not supplied tables for them, and content in this format is not to be invented.
- **Branch honesty is a feature, and demo staff should know it:** the DLR pages are static data captures whose fleet has no critical line and nothing below SLR, so items 7 and 9 render their true-zero branch ("0 lines are critical"). Every CEO sentence pattern is coded with both branches; live data with a real critical renders the table's wording exactly.
- Verification per product: kind chips present and relayed into the hub band · at least two reads' figures proven to change on a real state change (quoted before/after) · **every** cta and insight act clicked with the frame, the product root and its text surviving (ftm 34 · btm 45 · ev 30 · dlr 14 actions) · `verify_shell.py --smoke` 14/14 on each of the five files · `splice_shell.py --dry` byte-identical at 1.10.15 (product layer only).

## 2026-09-01 — the chat widget is repointed at the app.int RAG deployment

CEO-supplied: `RAG_API_BASE_URL = 'https://app.int.oatihub.oati.com'`, `RAG_API_SERVER_PATH = '/genie/rag'`.

- Landed in `chat/genie-config.js` — the documented SINGLE EDIT POINT — as `ragBaseUrl` +
  `ragServerPath` (was `http://aniketsa-d.dev.oati.local` + `/network_api`). Every real call is
  `${ragBaseUrl}${ragServerPath}${path}` in `chat/genie-rag-shim.js`.
- **Sweep confirmed there is nothing else to change in the products.** The framework, the hub and
  all nine dashboards carry the identical config-driven line
  `if(c.mode==="connected"&&c.ragBaseUrl)set("api-endpoint",c.ragBaseUrl);` — no hardcoded
  fallback anywhere. `chat/index.html` reads the config too. The only other real copy was
  `dist/chat/genie-config.js`, synced from source (md5-identical).
- **Verified live, not asserted.** The new host is reachable from this box: DNS
  `174.141.247.242`, TLS 1.3 with a valid `CN=app.int.oatihub.oati.com` cert. Preflight
  `OPTIONS /genie/rag/Conversations/List` with `Origin: http://localhost:8890` → 200 with
  `access-control-allow-origin: *`, methods incl. POST, `access-control-allow-headers: content-type`.
  In the signed-in shell (Ctrl+G) the widget mounts with `api-endpoint="https://app.int.oatihub.oati.com"`
  and its HISTORY list populates with real conversations from the deployment — end-to-end proof.
  Read paths only were exercised; no chat prompt was sent, to avoid writing a conversation record
  into a shared server.
- **http → https is not blocked** (browsers block active https→http, not the reverse): an in-page
  `fetch` from `http://localhost:8890` returned 200 `type:"cors"` with zero mixed-content warnings.
- **Degradation was force-tested** (route abort → `ERR_NAME_NOT_RESOLVED`), because an internal host
  will not resolve from every machine: history/groups fall back to `[]` so the chat opens with an
  empty list (no spinner, no dialog), and a prompt resolves to an in-conversation error message with
  the composer still usable. Zero pageerror, zero unhandled rejections; the shim logs its own
  failures at `console.debug` so they never pollute the error channel.
- **Follow-ups recorded, not silently done:** `tools/verify_shell.py:27` holds
  `RAG = "aniketsa-d.dev.oati.local"`, the tolerated-console-error allowlist — it now whitelists a
  host that is never contacted and should become `app.int.oatihub.oati.com` (deferred while the
  DERMS agent owns `tools/`). And `chat/openapi.json` is the OLD deployment's spec (`Rag 0.1.3`,
  `servers:[{url:'/network_api'}]`); the live `/genie/rag/openapi.json` is `Rag 0.2.1` and declares
  no `servers` key at all (the prefix is a proxy mount). All six paths the shim calls exist in
  0.2.1, so nothing is broken — but the bundled reference spec is stale, and the new comment in
  `genie-config.js` says so explicitly so no maintainer trusts it.
- Earlier entries in this file that name `aniketsa-d.dev.oati.local` (the 1.8.0 integration notes and
  the verification error policies) are HISTORY — accurate when written, superseded by this entry.

## Framework 1.10.16 — the genie speaks naturally (2026-09-01)

CEO: "Genie is speaking but with some pause… it should sound natural for all languages, and it
should work perfectly fine in index.html no matter which dashboard is open." Measured before
guessing. Baseline on the hub in Arabic (Microsoft Naayf), sign-in chain:

| | before | after |
|---|---|---|
| engine latency, first utterance | **3832 ms** (cold SAPI voice) | **~200 ms** |
| silence between spoken lines | 2003 / 471 / 516 / 483 ms — avg **868 ms** | **~290 ms** typical |
| utterances the engine never started | intermittent (see watchdog below) | **0** |

Five separate causes, each fixed at the root:

1. **The voice was loaded on the first spoken word.** Windows loads a SAPI voice on its first
   utterance — 3832 ms for Arabic, 685 ms for English on this box — and that load was paid as
   silence at the top of the ceremony. `voiceWarm()` speaks a zero-volume `​` on the SAME
   voice during the sign-in animation, and the greeting waits for it (bounded at 4.2 s, so a dead
   engine can never hold the ceremony). A language change warms the new voice too.
   *Honest measurement note:* once Windows has loaded a voice it stays cached across runs, so the
   control test with warm-up disabled measured 524 ms rather than 3832 ms. The warm-up's full
   value shows on a cold machine — the first sign-in after a boot, or the first use of a language,
   which is exactly the demo case.
2. **The greeting was two utterances.** "Hello, Komal!" and "Welcome back…" were spoken
   separately, so the engine's own start latency landed *inside the greeting* — measured 2003 ms
   in Arabic, a pause no human puts there. Now ONE utterance; the "!" supplies the natural breath,
   and the island card is unchanged because it always showed the pair together.
3. **The inter-step gap was 260 ms on top of ~215 ms of engine latency** — 485 ms between every
   line, which reads as a stall. Now 90 ms, so the audible boundary is the engine's own ~215 ms.
4. **Speaking speed was forced to `rate 1.02 / pitch 1.05` in every language.** A vendor voice at
   unity is what natural sounds like, and the pitch raise was most of what made the genie sound
   synthetic. Now `VOICE_RATE`, per language, tuned by ear in ONE table: Latin languages at
   1.00/1.00, Arabic and Japanese at 0.96 (their SAPI voices read faster at the same rate).
5. **The 25 s briefing cap was a total budget, not a watchdog.** Arabic and Japanese utterances run
   6–9 s each, so the last briefing item was silently dropped — in the baseline it survived by
   100 ms, which is luck, not design. The cap is now re-armed per step (an IDLE watchdog), and the
   login quiet window follows the chain the same way.

**Why it depended on which dashboard was open.** A same-origin embed runs on the HOST'S main
thread. Long-task attribution on the hub named the culprit exactly: `ftm_optimization_dashboard`
booting inside its iframe — one **2022 ms** task, plus a train of 240–544 ms ones, 19 tasks and
~5.8 s of blocking in the first 20 s. Both our step timer and `speechSynthesis`' own start queue
behind those, so identical builds produced 290 ms silences on one run and a 3065 ms stall on the
next. Two fixes:

- **`whenQuiet()`** — a `longtask` PerformanceObserver (`JANK.last`) plus a bounded wait: each line
  waits for a short quiet window before speaking (160 ms quiet, 800 ms cap), and the ceremony
  itself begins in the first quiet window after the sign-in burst (600 ms / 8 s cap). A capped wait
  settles 120 ms before speaking, because the tick that notices the cap is the first one after a
  long task ended — firing there speaks on the very edge of the next block.
- **The never-started watchdog is now jank-aware.** It cancelled the queue and retried voiceless
  whenever `onstart` was later than a flat 2200 ms — but a blocked thread is not a dead engine,
  and that false cancel was measured as an **8.6–9.4 s hole** in the briefing on two of four hub
  runs. It now re-arms (bounded, 3×) while `JANK` says the thread was blocked inside the window,
  and still condemns a genuinely dead engine.

**Acceptance run** (hub, sign-in chain, 2 languages × 2 runs): never-started 0/4, silences ~290 ms,
one run at 748 ms. **Known remainder, stated plainly:** if a briefing overlaps a product *mount*
(the deliberately brutal test: switch product, greet 150 ms later), the first gap is still
2.9–3.5 s, because no scheduling trick in the shell can create audio time while a 2 s synchronous
task owns the thread. The durable fix is to chunk the dashboards' boot so no single task exceeds
~50 ms — worth doing on its own merits, since the same tasks are what make the hub feel heavy.

## Framework 1.10.17 - RTL: the side panels open on the reading side (2026-09-01)

CEO, testing Arabic on the hub: Quick Settings, the Alarms drawer and the Notifications drawer
still slid in from the RIGHT while the shell around them was mirrored. In an RTL layout the
inline-end edge is the LEFT one - the drawer must arrive on the same side as the control that
opened it, from the direction the eye is already travelling.

- Four surfaces share this geometry and all four are fixed together: `#wv-qs`, `#wv-adrawer`,
  `#wv-ndrawer`, `#wv-infoDock`. Under `html[dir="rtl"]` each anchors `left:0`, carries its
  hairline on the RIGHT edge (`border-left` -> `border-right`), and slides in from the left via a
  mirrored `wv-slidein-rtl` keyframe.
- The Info dock also pushes the page away from ITS side, so its `#wv-main` margin flips
  (`margin-right` -> `margin-left`), and its resize grip moves to the dock's inner edge, now the
  right one. The two drawers' asymmetric header padding (`0 8px 0 15px`) mirrors too, so the close
  button keeps its margin.
- Authored as explicit `[dir="rtl"]` overrides rather than logical properties: the base rules are
  physical and shared with the popout/embed CSS, so one grammar changed in one place beats a
  partial migration.
- Verified by measurement in both directions, not by eye alone: in Arabic all four panels report
  x=0 with the border on the right; in English all four still report right=viewport with the
  border on the left; zero pageerrors. Quick Settings opened through its real control renders 52
  rows and 3051 characters on the left edge.

## 2026-09-01 — derms integrated: dashboards/DERMS-Dispatch-Genie_wv1.0.html (9th product)

Raw `dashboards\DERMS-Dispatch-Genie.html` ("Grid DERMS · Dispatch Scheduling", ~1 MB) converted
with the `genie-shell-integrate` skill applied in full; raw untouched. The propagation set is now
**10 targets** (9 dashboards + the hub) and the hub's Global roster is **9 reads**.

- **Views (8, not 9 — there is no `derms.dispatch`)**: `derms.watch` · `derms.respond` ·
  `derms.notify` · `derms.compose` (Operate) · `derms.plan` · `derms.calendar` · `derms.review`
  (Plan & Review) · `derms.configure` (Configure) — one per raw `DEFAULT_MODES` entry.
- **Both read scopes filled.** Global: 6 computed reads (ACTION / OPPORTUNITY / AT RISK / ON PLAN /
  WASTE / HEADROOM). Local: 2 per view, all computed, with 1.10.15 kind chips (QUEUE, RECOMMEND,
  DELIVERY, COMMS, PEAK, CONSTRAINT, BOOKINGS, BUDGET, SENDS, OPT-OUTS, REALIZED, ROOT CAUSE,
  DRAFT, GATES, TRIGGERS, FLEET RULES). Liveness proven: *"2 critical exceptions are open right
  now…"* → dismiss 4 alerts (41→37) → *"Nothing is at critical severity — 37 items waiting on a
  deadline and 2 live dispatches."*
- Functionality inventory: **59/59 standalone, 19/19 embedded**, every overlay hit-tested at its
  centre in EMBED mode. Two apparent failures proved by-design (Watch panels are card layouts, so
  CSV correctly declines; the info card is `pointer-events:none`, so paint order was proved
  instead). All 56 read CTAs clicked with the dashboard surviving each.

### The performance defects this integration exposed (they matter beyond derms)

- **The smoke suite HUNG, and it was not the test's fault.** Playwright's rAF-polled actionability
  starved because the main thread was ~90 % busy: `computeActions()` — a pure derivation — was
  recomputed **8+ times per repaint** at ~200 ms each, so one `commit()` cost **1764 ms** against a
  2000 ms tick. It reproduced identically in the UNTOUCHED RAW, so it was pre-existing product
  behaviour, not an artefact of integration. Memoised per state generation (the counter bumps in
  `commit()`/`tick()`, exactly where state changes are announced): **1764 ms → 392 ms**. The
  product's own hidden Genie's-Read strip also stopped painting (its reads are bridged to the shell
  band) — another ~330 ms per repaint.
- **Hub view-swap latency degraded 4.8 s → 151 s** as views accumulated, because every opened view
  kept a live console repainting every 2 s. The tick now skips when the root has no visible box:
  flat **11–16 s**.
- Both are the same class of problem as the 1.10.16 speech work: a same-origin embed's main-thread
  cost is the HOST'S cost. A product that repaints while nobody is looking at it steals time from
  the shell, and the genie's speech is where a user hears it.
- Also fixed at root: NaN SVG paths from `v.presentKw`/`v.limitKw` (fields no violation has ever
  carried) and from `0/0` on a dispatch with no included plan rows; a genie drawer painting behind
  the shell header (`inset:0 0 0 auto` full-viewport rail, now keyed to `--layout-top`); a stale
  shell tab after an in-frame mode switch (now reroutes through the 1.10.12 `{wv:"open-view"}`
  relay); a bare `{wv:"theme"}` leaving the product ground stale; `C&amp;I` double-escaped by the
  band's `bmark()`; and an ACTION read chipped `info` for a CRITICAL alert (tone now from the
  alert's real severity).
- **Honest caveat carried forward:** residual NaN-path console errors appeared in 2 early runs made
  while other browser suites were saturating this machine. Both concrete causes are fixed and it
  has not reproduced across 4 consecutive clean runs plus the smoke, embed and hub sweeps — but a
  third cause was not proven impossible. Watch for it.

## Framework 1.10.18 — the login backdrop: a switchyard, a journey, and a rotation (2026-09-01)

CEO: the background animations are good and the first ones are praised, but **scene 3 was a copy of
scene 2** (same lattice towers and dashed catenary, pushed lower), the set never showed
**transmission from one place to another**, and the same scene greeted every sign-in.

- **Scene 3 is now "Switchyard"** — a substation bay elevation seen FROM BELOW, rising off the
  bottom edge. Chosen over a load-profile stack and a DER field because its composition is
  *inherently vertical*, which is the thing that separates it from two horizon-and-catenary scenes:
  twelve bays on pedestals, single-line switchgear (breaker block → CT → open disconnect blade),
  risers climbing to gantries with insulator strings, two transformer bays, two control houses, two
  bus levels with bus-B ties. Riser heights form a valley in the centre so the sign-in card sits in
  the quiet zone; a per-depth scale ladder (1.0 → 0.68) and a five-step opacity ladder (.56 → .14)
  carry depth. The ONLY accent is the current pulses climbing 7 energised risers — the one thing
  that moves is the one thing that is live. Vocabulary is single-line diagram, not steel-and-wire.
- **Scene 2 becomes the JOURNEY.** Its spans used to run off both edges, so power came from nowhere
  and went nowhere, and its travelling dashes were ambient rather than meaningful. Now: a wind pair
  on a collector bus at the left (tying back to scene 1), the substation at the right, and one
  accent packet crossing between them on a `pathLength="1000"` conductor — 6.93 s of travel, then a
  14 s pause, on a 21 s cycle. **The destination flashes on arrival** (~0.4 s after the packet
  lands): that beat is what makes the eye read *transfer* instead of decoration. A second packet
  runs the other way on a 53 s cycle — coprime with 21, so reversal falls roughly once per three
  forward trips and never repeats mechanically, reading as import/export on an interconnect.
  Accent exclusivity enforced and measured: in both themes exactly **6 elements resolve to the
  accent** (4 packet paths + 2 arrival overlays), **0 offenders** — the old conductors were demoted
  from `var(--wv-acc)` to neutral so the dashes survive only as texture.
- **The scene changes on every visit.** A `MutationObserver` on the login element catches every
  hidden → visible transition (boot and sign-out alike; a session-resume boot never fires because
  `data-in="1"` is already set). Order is a fixed cycle persisted in `wvfw.<ns>.loginBgSeq`
  (localStorage), so it advances across reloads and sign-outs and **can never repeat immediately** —
  only the first-ever visit picks at random. Rotation observed over 6 visits on both the framework
  and the hub: all three scenes appear, no immediate repeat.
- **An explicit Scene 1/2/3 pick still pins**, for demos: the dev-bar click writes
  `wvfw.<ns>.loginBgPin` to **sessionStorage**, which beats the rotation, survives reloads and
  sign-out/sign-in within the tab, and resets in a new tab so rotation can never be killed
  permanently.
- **Performance, held to the 1.10.16 bar:** pure CSS/SVG, no canvas — **0 long tasks and 0 rAF calls
  across 15 s idle on each scene**; each scene's own render-tree attach/detach measures 0.2–0.5 ms
  (25 reps, median). After sign-in `#wv-login` is `display:none` and `document.getAnimations()`
  over the login subtree returns **0**, verified again after two sign-out/sign-in cycles — nothing
  keeps painting behind the app. `prefers-reduced-motion: reduce` drops the scene's animation count
  from 33 to 0.
  *(An earlier A/B suggested scene 3 added ~55 ms to the sign-in long task; direct measurement and
  an interleaved re-run showed that was machine drift — the distributions overlap, and the single
  140–200 ms task at sign-in is app mount, which happens once the scene is already unrendered.)*
- Scope-checked against the 1.10.17 backup: only the `css` and `login` chunks plus the version
  stamp differ; the other seven chunks and everything outside the sentinels are byte-identical.

**The set now tells one story across visits:** scene 1 generation (the source) · scene 2
transmission (the journey) · scene 3 the switchyard where it lands.

## Framework 1.10.19 - scene 2 restored, transmission moved into the switchyard, and the genie stops when the session does (2026-09-01)

Four CEO items, one round.

### 1. Scene 2 reverted - it was already right
The 1.10.18 "journey" (wind-pair source, substation destination, accent packet, arrival flash,
reversal) came back OUT of scene 2. CEO: "this one was already good clean, lets revert changes from
this one." Proof, not assertion: the `#wv-bgC` subtree is **byte-identical** to the 1.10.17 snapshot
(943 B), and backdrop-only screenshots at 1920x1080 hash **identically** in dark and light.

The trap in this revert, and why it was called out in the brief: 1.10.18 had demoted the SHARED
`#wv-corr` catenary symbol off the accent to keep the accent exclusive to its packet, and that
symbol is used by scenes 1 and 3 as well. Verified un-collateral: `#wv-bgP`, `#wv-corr`, `#wv-hglow`,
`#wv-pylon`, `#wv-substation`, `#wv-tblades` all byte-identical to the snapshot; of the 17 CSS
selectors that differ from 1.10.17, **zero** match anything in scene 1 or scene 2 - all 94 matches
are inside `#wv-bgH`.

### 2. Transmission now runs THROUGH the switchyard
CEO pointed at scene 3, not scene 2, as the one missing "transmission from one place to another".
A switchyard is exactly where that happens: a line arrives, is switched across the bus, and departs.
One `pathLength="1000"` path carries a packet in from off-frame left onto the left gantry, down the
riser through its switchgear, **across the bus**, up the far riser and out past the right gantry.
The bus crossing is 41% of the distance but gets **49% of the time** (4.14 s of 8.5 s) - it dwells,
because that traverse is the beat that reads as transfer. Forward 23 s, reverse 59 s (coprime
primes: the pair realigns only every ~22.6 min, so the pattern never looks mechanical), and on
reversal the beat moves to the other gantry, because that is then the departure. Permanent incoming
and departing double circuits give the frame an upstream and a downstream.

Accent exclusivity measured rather than assumed: over all 54 elements in the scene plus every
reachable gradient stop, exactly **8 elements resolve to the accent in both themes** - the packet
and its beat, nothing else. The ambient riser pulses were demoted off the accent so the journey
outranks them, and the two transit bays lost their ambient pulses entirely (they are carried by the
journey itself).

### 3. The genie goes silent when the session ends
CEO: "I have logged out but genie is still speaking; it should immediately stop on logout, refresh
also." Two distinct causes:

- **`doLogout()` never touched speech.** It closed popouts, cleared AUTH, unmounted the chat and
  cleared toasts - so a sign-in briefing simply carried on over the login screen. It now goes silent
  FIRST: `VOICE.epoch++` -> `stopSpeaking("signout")` -> `cancel()`. The new **epoch** is the real
  fix: every deferred sign-in callback (the warm-up, its 1400 ms greeting timer, the `whenQuiet`
  briefing start, `genieLoginGreet` itself) is generation-guarded, so nothing scheduled by the old
  session can speak into the new login screen. `genieSpeak` also hard-gates on being signed in
  (embeds and popouts exempt).
- **Refresh leaked because the utterance queue outlives the document.** `beforeunload` alone is not
  enough (bfcache, and the queue is profile-level). Added `pagehide`, plus a `cancel()` at js-app
  parse time - the NEW document dropping the queue is the only guaranteed moment.

Verified by test, not by inspection: sign-out mid-briefing -> `speaking:false, BRIEF.active:false`
immediately and **zero further utterances over the next 9 s** (spanning both the 1400 ms greet timer
and the 8 s quiet-gate cap); sign-out 350 ms after sign-in, inside the warm-up -> zero real
utterances ever; reload mid-briefing -> silent on load and still silent 4 s later.

### 4. A language switch stops the voice and never greets
CEO: "when we switch language, if genie is speaking it should also stop, because it's a new
language; and currently on switching language it starts greeting - that should not happen. Greeting
works after login based on the configurations." This **supersedes the 1.10.11 rule** that re-greeted
once per language.

`prefChanged()` now cuts the voice the moment `S.lang` actually changes, before the re-render.
`genieGreetForLanguage()`, `_greetLang` and the 420 ms scheduling are removed outright - no stubs.
A new `_prefLang` is **seeded at boot from `S.lang`**, without which the first switch of a page
session slipped past the stop (caught in test, not in review). `GREET_SEEN`, the sign-in ceremony
and `greetFreq` are untouched. The Settings sub-label "spoken the first time - and after a language
change" became **"spoken the first time you sign in"** in all five languages: a UI that promises
behaviour we just removed is its own defect.

Suite: the three 1.10.11 language checks asserted the retired rule. Replaced at equal strength -
silence across six consecutive switches (en/fr/es/ar/ja), and a live utterance proven CUT by a
switch. Briefing block 58 -> 64 checks.

### Also on rotation
The dev-bar Scene pin (sessionStorage) is gone. A pick now holds only for the current login visit
and moves the rotation cursor onto that scene, so the next arrival advances PAST it - CEO: "on
logout, or when we come to the login screen, we should see a different background animation every
time." Proven across 5 logout->login round trips including a pin used mid-way, which did not leak
into the next visit.

### Performance and flake notes
Idle 15 s on scene 3, measured twice against two controls (no scene; `about:blank`): **rAF 0, long
tasks 0**. Two earlier readings of 1 and 4 long tasks were contention from concurrently running
harnesses and vanish when measured alone - recorded here because the same trap cost this project a
false conclusion once already. `prefers-reduced-motion` -> 0 running animations in any scene; after
sign-in, 0 animations in the login subtree. Known load-sensitive check for the flake list: **"lamp
rematerializes (spark)"** waits 1500 ms for a class that lives 2200 ms - it fails only on a
saturated machine, passes in isolation, and is not a regression.

## Framework 1.10.20 / 1.10.21 - scene 3: a taller yard, and a journey that never stops (2026-09-01)

### 1.10.20 - the towers stand taller, WITHOUT flattening the valley
CEO asked whether raising the towers 50% would look clean. Measured before answering, and the
honest answer was no - a uniform +50% would have cost the two best details and gained nothing:
- the outermost pair (x 58/1548) already exits the frame at y -40, so more height is invisible;
- the second pair (x 168/1424) would go from visible crossarm terminations at y 122/104 to roughly
  y -136/-190, clipped off-frame - losing the gantries that make these read as switchyard
  structures rather than bare vertical lines;
- the centre pair (x 700/862) would climb from y 646/634 to ~606/589, behind the sign-in card
  (box x 631-969, y 247-652) - harmless on login variant A, but B-D use different card sizes and
  the SVG scales with the viewport's aspect ratio.

So the raise is GRADUATED, and only into empty frame: the taller a bay already is, the smaller its
factor, so the descending silhouette - the valley the card sits in - is preserved rather than
flattened into a plateau.

| bay | height | factor | top was -> now |
|---|---|---|---|
| 296 / 1292 | 430.3 / 392.6 | 1.22 | 270 -> 175.3 · 258 -> 171.6 |
| 428 / 1150 | 284.6 / 272.6 | 1.30 | 424 -> 338.6 · 436 -> 354.2 |
| 556 / 1006 | 169.0 / 151.0 | 1.38 | 548 -> 483.8 · 566 -> 508.6 |

Untouched by design: x 58/1548 (already clipped), x 168/1424 (their crossarms are the payoff and
they carry the transit journey), x 700/862 (they sit under the card). Each bay's RISER, its GANTRY
and its ambient PULSE path all carry the same top, so all three move together - a riser raised on
its own would leave its gantry floating and its pulse short. Verified silhouette, outside-in:
104 · 171.6 · 354.2 · 508.6 · 634 | 646 · 483.8 · 338.6 · 175.3 · 122 - strictly descending.

### 1.10.21 - the journey is continuous
CEO: "decrease the speed of the bar flowing but keep it flowing continuously - presently it
disappears and again comes after 3-4 seconds."

Before: the forward packet travelled 8.5 s inside a 23 s cycle then parked off-path for ~14.5 s,
and the reverse packet ran an unrelated 59 s cycle - so most of the time nothing was in transit.

After: ONE shared 45 s cycle carrying three 15 s passes back to back - forward, forward, reverse.
Slower per pass, continuous, and direction still changes on a 2:1 pattern rather than a simple
alternation. The bus traverse keeps its dwell (~41% of the distance, ~49% of each pass's time),
because that horizontal crossing is the beat that reads as transfer.

**Verified by sampling, not by eye.** Seeking both packet animations across the full cycle every
0.1 s and computing each dash's real position with `getPointAtLength`, then testing it against the
viewBox - because the path deliberately starts at x -40 and ends at x 1640, so "in transit" and
"visible" are not the same thing:
- first cut: longest stretch with nothing visible **1.10 s**, at the forward -> reverse handover -
  both use the same right-hand edge, so their off-frame tails sat end to end instead of overlapping;
- fixed by starting the reverse pass 1.27% of the cycle (~0.57 s) earlier, so its off-frame lead-in
  runs underneath the outgoing packet's off-frame lead-out;
- final: longest blank **0.50 s**, blank samples 20 -> 14 of 450, and **0 samples with two packets
  visible at once** in either build.

The remaining 0.5 s breaths are at the two handovers where the SAME element has to finish one pass
before starting the next (a element cannot overlap itself); removing them would need a second
forward packet element, which was judged not worth the extra markup for a half-second at 15 s
intervals. Recorded here so the next person does not rediscover it.

## Framework 1.10.22 - scene 3 sits LOW, like scene 1 (2026-09-01)

CEO ruling, after a clarification round: **lower the Switchyard to match the Panorama.** Scene 1
keeps every structure in the bottom quarter and leaves the upper frame empty, and that emptiness is
what reads as clean; scene 3 was doing the opposite, with risers climbing most of the frame and two
running off the top edge. This SUPERSEDES 1.10.20, which had raised them - the wrong direction.

Two readings of the instruction were possible and opposite (raise scene 1 to match scene 3, or
lower scene 3 to match scene 1), each a substantial re-proportioning, so the question was put to
the CEO before any edit rather than guessed at. Answer: lower scene 3.

- Every bay now terminates between y 544 and y 686, so the yard occupies the bottom ~38% of the
  900-unit frame. The silhouette still descends toward the centre, so the card keeps its valley:
  544 · 556 · 588 · 624 · 656 · 686 | 682 · 660 · 628 · 582 · 550 · 544.
- Everything hanging off a riser top moved with it: gantries, the ambient pulse paths, the incoming
  and departing lines, the transit path, its arrival-beat gantry and span, and the light on the tall
  right gantry. x 58 and x 1548 used to leave the frame and so had no termination; inside the frame
  they now get gantries of their own, because a bare line stopping in mid-air reads as unfinished.
- **The packet keyframes had to be recomputed, not just translated.** With short risers the bus is
  now ~57% of the journey instead of ~41%, so the old dash-offset stops (-267 / -675, chosen to land
  on the old segment boundaries) would have fallen mid-segment and mistimed the dwell. New stops
  -188 / -755, with the bus taking 60% of the time for 57% of the distance - a slight dwell rather
  than the old pronounced one, because at these proportions a heavy dwell reads as the packet
  stalling.
- Re-measured after the change: over a full 45 s cycle, longest stretch with nothing visible
  **0.60 s**, and **0 samples with two packets visible**. The continuous-flow guarantee from 1.10.21
  survives the re-proportioning.

## Framework 1.10.23 - the product is named GenieUI (2026-09-02)

CEO: "GenieUI is the new word replacement for old webVision Framework."

Renamed wherever a user can SEE or HEAR the name - four places existed in the shell, plus the two
file-header comments:
- the Product-switcher Info card ("Selects which **GenieUI** product fills the navigation");
- the spoken welcome's fallback when no product is registered (Genie says the name aloud);
- the browser tab title's fallback product name;
- the placeholder product the shell registers when it boots with nothing mounted.

Spliced to all 10 targets, so every dashboard carries the new name too. `dist/README.md` renamed in
step: title **OATI Genie UI**, and "on the GenieUI framework 1.10.23".

**Deliberately NOT renamed - plumbing, not naming, and invisible to users:**
- the `wv-` CSS prefix and every class built on it (thousands of rules, and every converted
  dashboard's product layer is written against them);
- the `WV-SHELL:BEGIN/END` sentinels - the splice contract itself; renaming them would orphan all
  nine dashboards at once and break `splice_shell.py`;
- the `WV.*` public API, the `wv-shell-version` meta, and the `wvfw.<ns>.*` storage namespace -
  renaming the last would silently discard every user's saved preferences and sessions;
- file names (`GenieApplicationShell.html`, `tools/*`) and the `WV-*.md` spec documents.

A rename that reaches identifiers buys nothing a user can see and risks the whole propagation
contract, so this one stops at the words. Remaining `webVision` occurrences in the tree are code
COMMENTS in two dashboards' product layers and `chat/genie-config.js`, plus the `.pre-*` history
snapshots - none render.

## Framework 1.11.0 — the MODE GROUP, and one DLR product replaces two (2026-09-02)

### The mode group (framework)
A product may declare an ordered set of its registered views as a **mode group** —
`WV.registerModes({product, modes:[{viewId,label,icon?}], label})` — and the shell renders it as a
segmented control at the **far right of the tab row, past the arrangement control**. Built as a
framework feature, not a DLR strip: bafc and derms have mode-like desks that will want it next, and
a one-off bar is debt in a shell eight products share.

**The CEO's two-zone ruling, implemented with three cues** — one divider is too weak to change how a
control reads: different GROUND (inset track, 6% low-ink fill, 1px hairline, 9px radius, 7px chips,
where tabs sit on the bare bar), different SHAPE, and a real GAP plus a 1px rule at 60% row height
with 12px either side. A width-gated `VIEWS` micro-label appears at >=1440. The track is 24px inside
the 36px row — **zero new vertical height**, which is why this placement beat a second bar.

**Deliberately different selection language:** the active tab keeps its 1.10.14 underline; the active
mode is an accent wash + accent ink chip, asserted to differ. If both zones highlighted identically
they would collapse back into one bar in the reader's mind, which is the whole thing being avoided.

**Degradation, measured at eight widths:** tabs get `min(wanted, 720px)` before the group steps down,
a hard 380px floor the group may never push them under, and a 40% max share of the row. Ladder:
full+label (1920/1440) -> full (1280) -> icons (1100/900/760) -> a single "Views · <current>" menu
(620/520). Asserted monotonic, with a never-crushed guard on the tabs at every width.

**RTL:** `.wv-tb-side` moved from physical `margin-left:auto` to logical `margin-inline-start:auto` —
the physical margin collapsed the group back against the tabs under `dir=rtl`. Verified by
measurement in both directions.

**Switching is in place, never a new instance:** `modeGo()` -> `switchInstView()`; if one renderer
serves the group and implements `onModeChange`, nothing unmounts at all (same uid, same panel, same
DOM). In an embed `openView` is bypassed and the child switches locally, posting `{wv:"mode-changed"}`
up; the hub posts `{wv:"mode"}` down and never rebuilds the iframe. Keyboard Alt+Shift+1-9, matched
on `e.code` so a shifted digit glyph cannot break it, published through the same `PROD_KEYS` store
products use so it reaches the `?` sheet and relays into the hub.

Also fixed here: the lockup and the tab title both prefix "OATI", so a product registered as "OATI
Genie Dynamic Line Ratings" rendered **"OATI OATI Genie…"**. `prodBranded()` plus a hideable
`#wv-prodBrand` span — the registered name stays exact and the chrome never doubles the word.

Suite: new `f_modes` feature, 26 checks on framework + hub.

### NEW HARD RULE — a framework global must be as namespaced as a product one
The registry was first called `MODES`. Four converted products (ftm, ev, btm, bafc) already declare a
top-level `const MODES`, and two `const` of one name is a **SyntaxError that takes the entire product
layer down** — the suite reported "Identifier 'MODES' has already been declared" plus every
downstream product function missing. Renamed `MODEGRP`. The global-collision sweep in the integrate
skill was written for product globals shadowing shell ones; it applies in **both** directions.

### One DLR product replaces two
`dlrmap` + `dlrline` removed from the registry, catalog, `splice_shell.py` TARGETS,
`verify_shell.py` DEFAULT_SET and `dist/`; their converted files moved to `dashboards/retired/`.
The roster is now **8 products**, and nine suite/prose assertions that hard-coded nine (or five) were
updated.

`dashboards/dlr-genie.html` (10.9 MB, untouched) -> `dashboards/dlr-genie_wv1.0.html`, id `dlr`,
name **"OATI Genie Dynamic Line Ratings"**, accent `#bb93ff`. Five views — Fleet Overview, Geographic
Map, Thermal Event Log, Historical Analytics, Line Details — registered AND declared as its mode
group. Routing is a MEMORY router (offline copy: no URL, no hash), so each recipe clicks the
product's own nav link, kept in the DOM under the hidden topbar; a debounced, layout-free
MutationObserver relays the product's own internal navigations back to the shell.

**Singleton mount — the constraint that drove the design.** Five views must never mean five iframes
of an 11 MB app on the host thread (this project has already paid for that twice: FTM's 2022 ms boot
task stuttering the genie's speech, derms degrading hub view-swap 4.8 s -> 151 s). Proven: sweeping
all five modes leaves `open=1 · panels=1 · #dlr-root=1` standalone, and in the hub `frames=1` with
the frame `src` unchanged and `ready` never incrementing. **Mode-switch long tasks max 192 ms** in
the hub, 201 ms standalone.

**Two conversion techniques new here, worth reusing:**
- **Deferred module boot.** The 2.5 MB app module is parked in `<script type="wv/dlr-module">` and
  injected as a real inline module on first mount — so an 11 MB app never shares the thread with the
  sign-in ceremony, and React's first render measures a real panel box instead of a zero one.
- **Narrowing an offline capture's network override.** The raw's bootstrap replaces `window.fetch`
  AND `XMLHttpRequest` with tape resolvers that answer *everything*, which would have handed the chat
  widget a 503 "Offline copy" body. A prologue captures the real `fetch` first and narrows the
  override to the product's own `/api/v1/…` surface.
- Plus a boot-blocking conformance check inside the bundle: it throws unless `body`'s computed
  `font-family` leads with its own token. The shell types under `.wv-root` and sets no body font, so
  React never rendered until that one property was supplied from the product's own token.

### Genie's Read — the CEO's DLR content carried across, not lost
Global = the product's own read strip lifted verbatim (one read surface, never two). Local counts
asserted in the hub too: fleet 2, map 10, events 2, analytics 2, line details 4.

All ten curated Map chips survive — TRIAGE, DERATE WINDOW, BOTTLENECK, EVENTS, WIND ANGLE, NEAR
CLEAR, CRITICAL, HEADROOM, AT RISK, SPREAD — re-authored against the new dashboard's own data (the
Lines-on-Map table, the Selected Line panel, the forecast slider), and the four Line Details chips
likewise. **The quiet branches are firing on today's data and saying so honestly:** "0 mapped lines
are critical — Midway-Vincent 500kV is tightest at 129% of SLR", "0 A across 0 lines below SLR —
that is a genuine zero rather than a missing one". Two figures the retired pair had to caveat are now
real product figures: WIND ANGLE's phi comes from the Selected Line panel, and the fleet-scale
parallel-wind count (17,084 hours, 9.8%) lives on Historical Analytics.

One rule enforcement: `dlrLineAct` first clicked the map row, which on THIS dashboard *navigates* to
that line's page — changed to scroll+ring, because a Local read must act on the display you are
looking at.

### Gates
`splice --dry` 9/9 byte-identical at 1.11.0; full suite **1373 pass / 0 fail**, zero pageerror and
zero non-tolerated console.error across framework (602), hub (653), eight dashboards and the file://
hub; dist 10 files byte-identical and smoked.

## derms — the THIRD NaN cause, found by refusing to accept "transient" (2026-09-02)

Two separate agents reported intermittent `<path> attribute d: Expected number, "M0.00 NaN L1.67 NaN
L3…"` console errors on derms, both concluding it was contention from a loaded machine. It was not.
Three consecutive smoke runs on an otherwise idle box gave **0, 28 and 308 errors** — an intermittent
data condition, roughly two runs in three.

Root cause: `svgPath()`, the SHARED path builder every chart in the product goes through, guards the
empty case and nothing else — `(1 - p.y / maxY) * h`. `maxY` arrives 0 or undefined from a series
with no data yet (`0/0` -> NaN, `undefined` -> NaN), and a point can carry a non-finite y. Earlier
rounds had fixed two individual CALLERS; the helper itself kept emitting NaN for every other caller,
which is exactly why the errors kept coming back and looked random.

Fixed once, in the helper: a non-positive or non-finite `maxY` falls back to 1, and non-finite
coordinates fall back to 0 — so a series with no data draws a flat baseline (visibly "no data")
instead of a broken path. **Five consecutive smoke runs clean**, where the same command failed two in
three before.

**Lesson worth keeping:** when a defect is called transient twice, measure it in isolation before
believing it. And when a symptom recurs after call-site fixes, the bug is in the shared helper.

## dlr — the product name stops doubling the brand (2026-09-02)

The roster read showed **"OATI OATI Genie Dynamic Line Ratings"**. `dlr` was registered as "OATI
Genie Dynamic Line Ratings", while every other product registers its name WITHOUT the brand and lets
the chrome add it (GridLine FTM Optimizer, BA Forecast & Capacity Console, Grid DERMS — Dispatch).
Fixed by correcting the NAME in both registrations (the hub's and the dashboard's own product layer)
to **"Genie Dynamic Line Ratings"**, rather than adding a second de-duplication guard on top of
`prodBranded()` — a guard would have hidden the inconsistency instead of removing it. `prodBranded()`
stays as a backstop. Verified: no "OATI OATI" anywhere in the signed-in app; the lockup and tab title
render the brand exactly once.

## Framework 1.11.1 — one channel per event, and a bounded toast stack (2026-09-02)

CEO: alarms and notifications are already delivered by the genie, so they should not ALSO stack up
from the bottom; and if the genie is not carrying them, the toasts should work as the fallback.

Investigation changed the fix. The framework **already** had the rule — `heraldWill(kind)` gates both
`WV.raiseAlarm`'s toast and `notify()`'s. Two gaps and one missing bound:

1. **The hub's relay handler never asked.** It toasted every relayed crit/major alarm
   unconditionally, so in the hub you got the island AND the bell AND a toast for one event. It now
   honours `heraldWill("alarm")`, so the existing `genieHerald` setting (all | alarms | off) decides
   the channel — no new preference, and no state where both fire.
2. **A boot sync was being rendered as news.** When a product frame boots it relays its ENTIRE
   existing alarm list; the hub treated dozens of historical items as things that had just happened,
   which is what buried a third of the viewport. Alarms arriving within 3 s of a frame reporting
   ready now go to the bell, the drawer and Genie's Read only.
3. **`toast()` appended without limit.** Now `MAX_TOASTS=3` stand at once; beyond that the oldest is
   retired early and one live "+N more · open the list" counter carries the rest and opens the
   drawer.

Confirmations ("Preferences saved", "Workspace loaded") keep toasting in every mode — they have no
other home, and silencing them would remove the only feedback for an action you took. The cap applies
to them too: that bound is about volume, not class.

Measured: after sign-in + frame boot **0 toasts**; genie ON + new critical alarm **0**; genie OFF
**1** (fallback intact); a burst of 12 → **3 live + "+10 more"**.

## Framework 1.11.2 — the mode group belongs to the TAB, not the product (2026-09-02)

CEO opened Nightly Reports and the DLR sub-views were still on screen. `renderModeGroup()` showed the
group whenever the SELECTED PRODUCT declared one, and `modeActiveViewId()` fell back to "any OPEN
view in the group" — so Line Details stayed lit while Nightly Reports filled the screen, a chip
pointing at something nobody was looking at.

Now the group renders only while the FOCUSED view belongs to that product, and a chip is current only
when the focused view IS that mode. In split/grid the focused PANE decides. A product view outside
the group (a guide) still shows the group with nothing marked — otherwise there would be no way back
to the modes from that view.

Verified all four states: DLR view → shown with Fleet marked · Nightly Reports → hidden · back to the
DLR view → shown again · another product → hidden.

**Own-goal worth recording:** the first cut keyed the lookup off `view(id)`, whose record has no
`viewId` field — the INSTANCE carries it — so `modeGroupOf(fv.viewId)` was always null and no chip
was ever marked. The probe caught it before it shipped; a screenshot would not have.

## Framework 1.11.3 / 1.11.4 — the mode selection owns its cell, and is lit (2026-09-02)

**1.11.3** CEO: "select the full area around the Fleet button and don't leave a small empty space" —
the same ruling he made on the icon rail in 1.10.13: a selection OWNS its cell, it does not float
inside a margin. The track had `padding:2px` + `gap:2px` with 7px chips. Now `padding:0`, `gap:0`,
square chips and `overflow:hidden` on the track, so the end chips inherit the track's corners and
every chip meets its neighbour exactly. Measured: track 24px, chip **22px**, 1px offset — which is
the track's own border, so no empty space remains. The active chip's inset accent ring came out with
it: against a full-bleed fill it doubled the track border top and bottom.

**1.11.4** CEO: "add its border a bright highlight… much more premium." Two constraints from
decisions already taken: the track clips, so an OUTER glow is cut off; and a full 1px border doubles
the track edge top and bottom. So the highlight is inset and on the SIDES — bright accent edges left
and right (which also mark where the selected segment starts and ends now that chips abut), a 1px
specular line along the top, and an 18% fill so it reads as illuminated rather than tinted. Light
theme takes its own rule: a white specular is invisible on a pale lavender fill, so there the edges
carry it alone at 20%.

**Suite note:** the check asserting "active MODE = accent chip, deliberately NOT the tab's underline"
asserted `boxShadow!=='none'` — the ring 1.11.3 removed. It was RE-ARMED on the current mark (accent
fill AND accent ink AND different from the tab in both shadow and background), not relaxed: its
purpose is to keep the two zones from collapsing into one bar, and that purpose still holds.
