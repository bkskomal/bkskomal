# START HERE — hand this folder to Claude on the new machine

This is a portable, self-contained copy of the **OATI Genie UI** shell (framework `GenieUI`), its
integration tooling, its rules, and the accumulated judgement of the sessions that built it. Its
purpose: **drop a raw dashboard into `dashboards/`, ask Claude to integrate it, and get the same
result as on the original machine.**

Read this file first, in full, before touching anything.

---

## 0 · What is in here

| Path | What it is |
|---|---|
| `GenieApplicationShell.html` | The framework — the living release. Its `<meta name="wv-shell-version">` is the single version source. |
| `index.html` | The hub (app-id `hub`): one shell hosting every converted dashboard as a chromeless iframe. |
| `dashboards/` | **Empty by design.** Raw dashboards go here; converted outputs are written here as `*_wv<ver>.html`. |
| `reference/` | The **eight finished conversions** this shell shipped with. The hub loads its products from here, so the export works out of the box, and they are eight worked product layers to read. They ARE spliced and gated — that is what makes them a trustworthy reference. |
| `chat/` | The Genie chat widget bundle, its config and its RAG shim. |
| `tools/splice_shell.py` | Propagates the framework's nine shell chunks into every converted dashboard + the hub. |
| `tools/verify_shell.py` | The regression gate. **This is the thing that makes the work good — do not skip it.** |
| `skills/` | The three skills that encode the procedure: `genie-shell-integrate`, `genie-shell-update`, `genie-ui`. |
| `context/` | This file, `SESSION-CONTEXT.md` (standing rulings), and the three `WV-*.md` documents. |
| `serve.py`, `Start-Genie.bat` | The no-cache local server. |

**The export build differs from the original repo in four deliberate ways** — each one is what makes
it portable, and each was found by running the export standalone rather than assuming:

1. **The tools discover their targets** (`dashboards/*_wv*.html` and `reference/*_wv*.html`) instead of
   carrying a hard-coded list of eight files. Drop a converted dashboard in and it is spliced and
   gated automatically; an empty `dashboards/` is a valid state, not an error.
2. **The tools find their own tree.** The originals hard-code `HOME = E:\AI\Self\Genie`; here HOME is
   derived from the script's own location, so the folder works wherever it is unzipped.
3. **The base URL is overridable** with the `WV_BASE` environment variable, so the export can be
   served on any port: `WV_BASE=http://localhost:8891/ python tools/verify_shell.py`.
4. **The hub loads its products from `reference/`.** A hub is a fleet view of products that EXIST —
   shipping it pre-registered with eight absent dashboards produced eight 404s and a hub that could
   open nothing. `dashboards/` is your workspace; `reference/` is the shipped set.

---

## 1 · Set the machine up

Requires **Python 3.10+** and **Google Chrome**.

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows;  source .venv/bin/activate elsewhere
pip install playwright
python -m playwright install chromium
```

The suite drives Chrome through Playwright with `channel="chrome"`. If real Chrome is not present,
either install it or change `channel="chrome"` to `channel="chromium"` in `tools/verify_shell.py`.

## 2 · Start the server, and leave it running

```bash
python serve.py 8890          # or double-click Start-Genie.bat
```

Then open <http://localhost:8890/>.

**Always work over `http://localhost`, never `file://`.** Microphone permission for Genie listening
persists on localhost and is re-asked every time on `file://`, and browsers cache `file://` pages so
you end up testing a stale copy. `serve.py` sends no-cache headers.

## 3 · PROVE THE EXPORT WORKS BEFORE INTEGRATING ANYTHING

Do this first, every time, on a new machine. If this does not pass, nothing built on top of it can
be trusted.

```bash
python tools/verify_shell.py           # the whole default set: framework, hub, every
                                       # discovered dashboard, and the file:// hub
```

Expect **0 fail, 0 pageerror, 0 non-tolerated console.error**. On the machine this export was built
on it is ~1379 checks: framework ~605, hub ~656, eight reference products at 14 each, and the
file:// hub. It takes roughly 20 minutes. If it fails HERE, the problem is the environment
(Chrome/Playwright), not the shell - fix that before integrating anything, because every later
claim rests on this gate.

## 4 · Integrate a dashboard

1. Put the raw single-file dashboard in `dashboards/`.
2. Give Claude this prompt:

> Read `context/START-HERE.md`, then `context/SESSION-CONTEXT.md`, then the
> `genie-shell-integrate` skill in `skills/`, and follow it as law. Integrate
> `dashboards/<file>.html` into the Genie UI shell as a new product. The framework is
> `GenieApplicationShell.html`; the hub is `index.html`. Verify with `tools/verify_shell.py`
> and propagate with `tools/splice_shell.py`. Do not restart the server on 8890.

3. Claude should finish with: `splice_shell.py --dry` reporting every target **no-op
   (byte-identical)** at the current version, and the full `verify_shell.py` default set green.

**If the skills are not auto-loaded on the new machine**, copy `skills/*` into that machine's Claude
skills directory, or simply tell Claude to read `skills/genie-shell-integrate/SKILL.md` directly —
the skills are plain Markdown and work either way.

## 5 · Upgrade dashboards after a framework change

Edit `GenieApplicationShell.html`, then follow the `genie-shell-update` skill: splice, bump, re-verify.
`python tools/splice_shell.py` propagates; `--dry` reports without writing.

---

## The five rules that matter most

These are the ones whose violation has actually cost this project time. `SESSION-CONTEXT.md` has the
full set with the stories behind them.

1. **The gate is the deliverable, not the paperwork.** Every round ends with `splice --dry` at
   byte-parity and the full suite green. A gate that overlapped a splice is **void** — re-run it clean.
2. **Never restart the running server**, and never verify over `file://`.
3. **Write patch scripts to files; never inline a heredoc containing backslashes or non-ASCII.**
   They corrupt silently — a `\b` becomes a backspace byte and the regex breaks invisibly.
4. **A same-origin embed spends the HOST's main thread.** Never mount five iframes of a big app;
   use one instance and switch in place. Gate every repaint loop on visibility.
5. **Measure, do not assert.** Click every action, sample the state, quote before/after. Two separate
   agents called a real bug "machine load"; measured in isolation it failed two runs in three.
