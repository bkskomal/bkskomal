# webVision Product Registry (v1)

Canonical product/view definitions for stage-2 conversions and the hub. Consumed together
with WV-INTEGRATION-SPEC.md. Naming here is binding — stage-2 agents and the hub must use
these ids/names verbatim so the hub catalog, embeds, and popouts stay consistent. 2026-08-19.

## The singleton-mount rule (applies to all five products)

Every product renders into ONE shared DOM (`.grid`, `.stage`, `#canvas`, `#center`, sections).
Therefore, per product, exactly one view is live in the page at a time:

- The product content root is a **singleton**. Opening a product view mounts the singleton
  into that panel and drives the product's internal navigation to the requested view.
- Opening a second view of the same product **moves** the singleton to the new panel; the
  previous panel is closed by the shell automatically (with a toast: "<View> replaced —
  <Product> renders one inline view at a time; use a window for side-by-side").
- **Side-by-side of two views of the same product** = window popouts / hub iframes: the
  shell opens `<own file>#wv-embed=<viewId>` via window.open (a fresh full product instance
  per window). Stage 2 wires the shell's popout path for product views to this instead of
  the shell's document.write popout.
- Simultaneous INLINE views of one product (iframe panels inside the shell) are a stage-3
  option, not required for stage 2.

## Products

| id | Product name | Suffix (lockup) | Accent (from its own palette) | Dependent systems |
|----|--------------|-----------------|-------------------------------|-------------------|
| `ftm` | GridLine FTM Optimizer | Genie FTM | `#22d3ee` (its cyan) | Market Feed, Optimizer Engine, Site Telemetry |
| `btm` | DER Availability — BTM SOC | Genie BTM | `#4da8ff` (its forecast blue) | Forecast Pipeline, Device Head-End, Weather Feed |
| `derms` | Grid DERMS — Dispatch | Genie DERMS | its `--accent` token value | SCADA, ADMS, Head End, Power Flow |
| `pf` | Genie Powerflow | Genie PF | its cyan accent token | GIS, ADMS/SCADA, DER Registry, Forecast Engine |
| `tsr` | Genie OASIS — TSR | Genie TSR | its `--accent` token value | OASIS Feed, Provider Links, Rates Service |
| `dlr` | Genie Dynamic Line Ratings | Genie DLR | `#bb93ff` (its `--genie-t-ring`) | Database, Background Scheduler, DLR Calculation, Weather Ingestion |
| ~~`dlrline`~~ | RETIRED 2026-09-02 — superseded by `dlr`; file moved to `dashboards/retired/`. Id never to be reused. |  |  |  |
| ~~`dlrmap`~~ | RETIRED 2026-09-02 — superseded by `dlr`; file moved to `dashboards/retired/`. Id never to be reused. |  |  |  |
| `ev` | Genie EV Charge Load Management | Genie EV | `#bb93ff` (its `--ring` Genie-kit violet; `#6d28d9` light) | EVSE Telemetry, Session Manager, Forecast Service, Must-Serve Model, Feeder SCADA, Dispatch Bus, Weather Feed |
| `bafc` | BA Forecast & Capacity Console | Genie BA | `#bb93ff` (its `--ring` Genie-kit violet; `#6d28d9` light) | Forecast execution, EIA-930 actuals, EIA-930 interchange, Weather inputs, Capacity factors, BA reference data |

(Agents: read the actual token value from the product's CSS and use that exact color;
the table's literals are fallbacks. `systems` map onto the shell health chip via
`WV.setSystemState`, driven from each product's existing health/status logic where present —
DERMS already has SCADA/ADMS/Head-end/Engine chips; BTM has pipeline run health; others
may register systems as static `live`.)

## View catalogs (coarse — one view = one existing product page/mode)

View id convention: `<product>.<slug>`. Type from the shell's fixed enumeration.

### ftm — group "Operations"
| view id | name | type | mount recipe |
|---|---|---|---|
| `ftm.monitor` | Monitor | Dashboard | `applyMode('Monitor')` |
| `ftm.forecast` | Forecast | Chart/Trend | `applyMode('Forecast')` |
| `ftm.analyze` | Analyze | Dashboard | `applyMode('Analyze')` |
| `ftm.all` | All Panels | Dashboard | `applyMode('All')` |
Keep inside views: site/view/duration selects (as a view toolbar), playback bar, per-card chrome.
Custom user modes (its composer) are superseded by shell workspaces — drop the config modal in stage 2.

### btm — group "Forecast Ops"
| view id | name | type | mount recipe |
|---|---|---|---|
| `btm.monitor` | Monitor | Dashboard | `applyMode('Monitor')` |
| `btm.fleet` | Fleet | Map | `applyMode('Fleet')` (Leaflet: invalidateSize on mount/onResize) |
| `btm.energy` | Energy Flows | Chart/Trend | `applyMode('Energy')` |
| `btm.accuracy` | Accuracy & Drivers | Report | `applyMode('Accuracy')` |
| `btm.all` | All Panels | Dashboard | `applyMode('All')` |
Keep inside views: resources/subject filter bar, lookback slider, per-card exports/fullscreen.
Its Info registry (INFO) feeds shell Info mode via data-info facets where cheap; its generated
User Guide stays (opens its own window). Its Modes config modal is superseded — drop.

### derms — groups "Operate" / "Plan & Review" / "Configure"
| view id | name | type | group | mount recipe (`goMode`) |
|---|---|---|---|---|
| `derms.watch` | Watch | Console | Operate | `goMode('watch')` |
| `derms.respond` | Respond | Dashboard | Operate | `goMode('respond')` |
| `derms.plan` | Plan | Chart/Trend | Plan & Review | `goMode('plan')` |
| `derms.calendar` | Calendar | Data Grid | Plan & Review | `goMode('calendar')` |
| `derms.notify` | Notify | Dashboard | Operate | `goMode('notify')` |
| `derms.review` | Review | Report | Plan & Review | `goMode('review')` |
| `derms.compose` | Compose Event | Wizard | Operate | `goMode('compose')` |
| `derms.configure` | Configure | Form/Configuration | Configure | `goMode('configure')` |
Keep inside views: the situation strip + systems-health rail render INSIDE the mounted root
(top of the view) in stage 2 — they are product content by function; additionally bridge the
four system chips to `WV.setSystemState`. Its own toasts route to `WV.toast`. Its tour stays.
Its workspace/mode-config drag-drop is superseded by the shell composer — keep data model,
drop the modal entry. The 2s tick pauses via `WV_EMBEDDED_PAUSED` when the singleton is unmounted.

### pf — groups mirror its modules
| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `pf.realtime` | Real-Time Operations | Dashboard | Real-Time | `switchView('realtime')` |
| `pf.planning` | Operational Planning | Dashboard | Planning | `switchView('planning')` |
| `pf.hca` | Hosting Capacity | Map | Studies | `switchView('hca')` |
| `pf.doe` | Dynamic Operating Envelopes | Chart/Trend | Studies | `switchView('doe')` |
Sub-tabs (Network Map, FPA, Solver Validation…) stay as in-view tab rows. Both product nav
modes (viewnav + sidebar) are removed in stage 2 — the shell owns navigation. Leaflet maps:
invalidateSize choreography runs on mount/onResize/onVisibility. Its alarm pill/modal maps to
`WV.raiseAlarm` (violations → shell alarms with ack) — keep the per-map violation rendering.

### tsr — group "Trading"
| view id | name | type | mount recipe (`setView`) |
|---|---|---|---|
| `tsr.desk` | Desk | Dashboard | `setView('desk')` |
| `tsr.evaluate` | Evaluate Paths | Dashboard | `setView('evaluate')` |
| `tsr.procure` | Procure | Console | `setView('procure')` |
| `tsr.monitor` | Monitor Blotter | Data Grid | `setView('monitor')` |
| `tsr.atc` | Availability (ATC) | Chart/Trend | `setView('atc')` |
| `tsr.activity` | Activity | Console | `setView('activity')` |
Keep inside views: ticket strips + ticket bar + KPI answer row (they are the product's
workspace semantics), Rates drawer, Genie panel, tour, help. Its own live popouts stay for its
internal panels; SHELL-level popout of a tsr.* view uses the embed protocol. Boot note: TSR
returns to Desk ~850ms after load — mount recipes must defer `setView` until after boot settles
(hook its boot completion or a ~1s defer, verified).

## Stage-2 chrome removal map (per spec §4 rule 1)

- ftm: topbar (brand, filters move into a view toolbar, clock, theme/info/gear buttons), mode
  segmented control + its context menu, config modal.
- btm: topbar (logo, clock, refresh→optional view toolbar, info/help/theme), pagehead mode
  switcher + cog, its `#mode=` hash solo handling (replaced by `#wv-embed`).
- derms: topbar (brand, duration select → view toolbar, clock, tour buttons stay as an in-view
  affordance or move to help, info + theme buttons), mode bar (mode buttons + gear; the
  "Schedule an event" primary action moves into the Watch/Compose views).
- pf: header.top (logo, navtoggle, viewnav, alarm pill → WV.raiseAlarm bridge, clock, refresh,
  info group, theme toggle), aside.sidebar (both nav modes).
- tsr: topbar (brand, env pills → systems bridge, clock, theme toggle; Tour/Rates/Info/Help
  buttons relocate into the product's own surface — e.g. a slim product utility row atop the
  view), `#navBar` (the 5-view tab row — shell nav replaces it; per-view badges become catalog
  state dots where cheap, else dropped).

## Verification bar for every stage-2 conversion

1. Its own E2E file (`.e2e_<prod>.js` + runner copy) asserting: login→shell, every view opens
   via the shell catalog, singleton move behavior, theme swap propagates through the bridge
   (visual token check), embed mode renders chromeless, popout opens the embed URL, alarms/
   systems bridges fire, zero console errors.
2. Screenshot set: every view in dark, one in light, one embed, compared against the product's
   stage-1 shots for content parity.
3. The product's own interactions still work inside panels (spot-check the analysis reports'
   flagship interactions: FTM playback, BTM vintage overlays + map popups, DERMS approve flow +
   dialogs, PF solve + map modes + replay, TSR evaluate→procure flow + rates approval).

---

## Genie-era addendum (2026-08-27)

Canonical home is now `E:\AI\Self\Genie\`. New RAW product builds arrive in
`E:\AI\Self\Genie\dashboards\` (currently `btm_soc_forecast_dashboard_v0.1.html`,
`ftm_optimization_dashboard_v0.1.html`). Product ids/names/accents above remain BINDING —
a new build of an existing product reuses its id (`btm`, `ftm`, …) and its view-id
convention; genuinely new products append a row to the Products table and a view catalog
section here as part of integration. The v0.1 raw builds are fresh product content —
their internal pages/modes may differ from the v1 catalogs above; the integration pass
re-derives the view catalog from the actual file and records it here.

### ftm — actual view catalog (v0.1 build → `ftm_optimization_dashboard_wv1.1.html`, integrated 2026-08-27)

Derived from the v0.1 file itself (its DEFAULT_MODES + generated User Guide). Group
"Operations" retained; the guide sits under "Reference".

| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `ftm.monitor` | Monitor | Dashboard | Operations | singleton `applyMode('Monitor')` |
| `ftm.forecast` | Forecast | Chart/Trend | Operations | singleton `applyMode('Forecast')` |
| `ftm.analyze` | Analyze | Dashboard | Operations | singleton `applyMode('Analyze')` |
| `ftm.all` | All Panels | Dashboard | Operations | singleton `applyMode('All')` |
| `ftm.guide` | User Guide | Report | Reference | own renderer — `ftmGuideDoc()` in a panel-scoped iframe (srcdoc); NOT part of the singleton |

- **Accent (read from the v0.1 tokens, per the "read the actual token" rule):**
  `--brand → --ring` = **`#bb93ff`** (dark) / `#6d28d9` (light) — the v0.1 build moved
  from the old cyan to the Genie kit ring violet; `#bb93ff` is registered and the shell's
  fitAccent derives the light-ground variant. The Products-table `#22d3ee` literal is
  the OLD build's palette and stays a historical fallback only.
- Systems: the three registry systems (Market Feed / Optimizer Engine / Site Telemetry)
  registered static `live`; the v0.1 build's own six-service health popover (UI,
  Interfaces, Database, Kafka, MILP Optimizer, Genie Model) stays in-product in the
  relocated utility cluster.
- Kept inside views: site/view/duration filter bar (+ market timeline, bulk export,
  relocated alarms/health/keys/help/info utility cluster), playback bar, product
  Genie's-Read bar with dispatch accept/override, per-card chrome, split view,
  drag-to-zoom, panel DnD, Info mode (product-scoped). Custom user modes / config
  modal / workspace menu are hidden — superseded by shell workspaces (mode data model
  intact). Per-panel popout = `#wv-embed=<view>&ftm-panel=<cardId>`.
- Genie integration: `WV.genieRead.set` fed from the live plan (D/STATE) on the
  `wv:time` bus + site switches; palette actions `ftm:analyze` / `ftm:rt` / `ftm:site`
  / `ftm:guide`; no chat provider (framework responder answers).
- Verified 2026-08-27: 18/18 Playwright checks, zero pageerror/console-error, theme
  round-trip + embed + singleton + playback (details in WV-PRODUCT-UPDATES.md).

### btm — actual view catalog (v0.1 build → `btm_soc_forecast_dashboard_wv1.1.html`, integrated 2026-08-27)

Derived from the v0.1 file itself (its DEFAULT_MODES + generated User Guide). Group
renamed to "Forecast Ops" per the v1 convention; the guide sits under "Reference".
Raw source `dashboards/btm_soc_forecast_dashboard_v0.1.html` untouched.

| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `btm.monitor` | Monitor | Dashboard | Forecast Ops | singleton `applyMode('Monitor')` |
| `btm.fleet` | Fleet | Map | Forecast Ops | singleton `applyMode('Fleet')` (Leaflet: invalidateSize on mount/onResize/onVisibility) |
| `btm.energy` | Energy Flows | Chart | Forecast Ops | singleton `applyMode('Energy')` |
| `btm.accuracy` | Accuracy & Drivers | Report | Forecast Ops | singleton `applyMode('Accuracy')` |
| `btm.all` | All Panels | Dashboard | Forecast Ops | singleton `applyMode('All')` |
| `btm.guide` | User Guide | Report | Reference | own renderer — `guideHTML()` in a panel-scoped iframe (blob URL, revoked on unmount); NOT part of the singleton |

- **Accent (read from the v0.1 tokens):** **`#6ba6e8`** — the dark-plate `--chart-6`,
  which is the build's `--fc` forecast-blue token. The Products-table `#4da8ff`
  literal stays a historical fallback only.
- **Systems (from the build's own `healthServices()`, driven live):**
  `forecast-pipeline`, `device-telemetry`, `forecast-publisher` (freshness miss →
  `stale`), `message-bus`, `weather-feed`, `tariff-schedule` — richer than the v1
  trio; states bridged ok→`live`, miss→`degraded` on every product re-render + 60s tick.
- **Bridged rather than kept in-product** (its own `syncChrome()` counts all three as
  chrome): topbar alarm bell + popover → `WV.raiseAlarm` (crit→crit, warn→maj, deduped
  per rule+resource); health popover → `WV.setSystemState`; the in-page rotating
  Genie's-Read strip (six filter-following computed reads) → `WV.genieRead.set({reads})`
  pager, tone map brand/good→info, warn→watch, bad→crit.
- Kept inside views: resources/subject filter bar + lookback slider (+ relocated
  Keys/Help/Info-mode utility cluster + bulk-export button), per-card kebab menu,
  exports, fullscreen, collapse, drag-to-zoom + zoom band, panel DnD, Info mode
  (float/dock), keyboard-shortcuts sheet, layout undo. Mode switcher / Modes config
  modal / product workspace menu hidden — superseded by shell nav + workspaces (mode
  data model and `btmMode`/`btmWorkspaces` storage intact).
- Popouts ride the embed protocol: mode context menu → `#wv-embed=btm.<slug>`;
  per-panel popout = `#wv-embed=btm.all&panel=<cardId>` (the mount re-applies the
  product's panel-solo hash path).
- Theme: product selectors keyed to the shell's `html[data-theme]` (not the product
  root) because the build re-homes overlays (fullscreen lift, info popup, chart
  popovers, drag ghosts) to `<body>`; `onTheme` → `btmApplyTheme()` syncs the basemap
  and rebuilds every chart. Product light/dark toggling of its own is gone.
- Raw-markup fix required by the wrapper: the filter bar carried two stray `</div>`s
  (silently dropped by the parser at body level; inside `#wv-park`/`#btm-root` they
  closed the product root) — removed during assembly.
- Verified 2026-08-27: 29/29 Playwright checks, zero pageerror + zero console-error,
  all six views with content assertions, singleton move toast, theme round-trip
  (basemap follows), embed chromeless + `wv:ready`, alarm/system/read bridges live
  (details in WV-PRODUCT-UPDATES.md).


### dlrline — actual view catalog (v0.2 Line Details build → `dlr-genie-line-details_wv1.4.html`, integrated 2026-08-28)

Derived from the v0.2 file itself. THE RAW BUILD IS A STATIC DOM SNAPSHOT of the live
DLR Genie app's Line Details route (`/lines/6 @ 2026-08-27`, see its `genie-dlr-snapshot`
meta): zero product JavaScript — captured DOM + token CSS + inline token-driven SVG
charts. One page, therefore ONE catalog view. The topbar's Fleet/Map/Events/Analytics
links are routes of the full app NOT present in the file and are NOT registered.
Raw source `dashboards/dlr-genie-line-details_v0.2.html` untouched.

| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `dlrline.details` | Line Details | Dashboard | Line Operations | singleton mount of `#dlrline-root` (static page; no internal nav to drive) |

- **Accent (read from the v0.2 tokens):** **`#5B9BF0`** — `--genie-action-primary`
  → `--genie-blue-500`, the build's interactive accent (the shell's fitAccent derives
  the light-ground variant).
- **Systems:** the captured topbar declares "System health — 4/4 nominal" but the
  popover markup (service names) was not captured; four services named from the page's
  real data planes — `dlr-ratings` Rating Engine · `dlr-weather` Weather Feed ·
  `dlr-telemetry` Span Telemetry · `dlr-forecast` Forecast Service — registered static
  `live` (= the captured 4/4-nominal truth).
- **Theme:** the product's light theme is pure CSS keyed to `:root[data-theme='light']`
  (dark = absence) — the shell's `html[data-theme]` drives it natively; `onTheme` is an
  honest no-op (all SVG strokes/fills resolve through `var(--genie-*)` tokens).
- **Bridged rather than kept:** topbar alarm chip ("25 active") → the 24 captured
  Thermal Derating Events rows (critical→crit, warning→maj) + the Current Hour
  Warning state raised once each via `WV.raiseAlarm` (= 25 in the drawer; the chip's
  3rd critical is fleet-level state not present in the page data — documented delta);
  the in-page Genie's Read strip → `WV.genieRead.set` (only the read visible at capture
  time exists in the React-rendered DOM — the pager's other 9 dots have no content).
- **Kept inside the view:** the filter bar (Owner/Line/tags/Refresh/Live — static) and
  the full 8-panel grid (Rating Timeline, Current Hour gauge, Limiting Span, Thermal
  Derating Events, Span Ranking Heat Strip, Elevation Profile, Weather Inputs, IEEE
  738-2023 Heat Balance).
- **Not applicable, documented:** product hotkeys/shortcuts (none — no JS), embedded
  User Guide (none), product info system (the live app's Info Mode was not captured;
  root still carries `data-wv-product-root` per the 1.1.1 contract), regional/number
  format bridging (every visible stamp/figure is captured data baked into the markup),
  timers/localStorage (none). Scroll: the details page is a long scrolling page BY
  DESIGN (~2120px at capture width) — the shell panel scroller owns the one scroll
  (raw parity), snapshot's `.genie-shell` capture-height pin re-scoped to auto.
- Verified 2026-08-28: 39/39 Playwright checks, zero pageerror + zero console-error
  (details in WV-PRODUCT-UPDATES.md).

### dlrmap — actual view catalog (v0.2 MAP snapshot → `dlr-genie-map_wv1.4.html`, integrated 2026-08-28)

Derived from `dashboards/dlr-genie-map_v0.2.html` — a STATIC DOM SNAPSHOT of the
DLR Genie app's Geographic Map route (`/map @ 2026-08-27`, per its
`genie-dlr-snapshot` meta): ZERO product JavaScript — one token-CSS block + the
captured DOM (inline SVG map). One route = ONE coarse view; the raw topbar's other
nav targets (/, /events, /analytics, /line-details, /help) are separate routes whose
content is not in this file (`/line-details` = the `dlrline` product).
Raw source `dashboards/dlr-genie-map_v0.2.html` untouched.

| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `dlrmap.map` | Network Map | Map | Operations | singleton mount of `#dlrmap-root` (static page; no internal nav to drive) |

- **Accent (read from its own tokens):** `--genie-t-ring` = **`#bb93ff`** dark /
  `#7c3aed` light — the Genie kit ring violet (same family as ftm's v0.1 tokens).
- **Systems:** the snapshot's health truth is the aggregate topbar chip
  "System health — 4/4 nominal" (popover items not rendered at capture), so four
  systems are DRAFTED to that 4/4 truth and registered static `live` — names
  aligned with the sibling `dlrline` registry for DLR-family coherence
  (`dlr-ratings` Rating Engine · `dlr-weather` Weather Feed · `dlr-telemetry`
  Span Telemetry · `dlr-forecast` Forecast Service).
- **Startup workspace (new 1.4.0-era requirement):** `WV.start` passes inline
  `startupWs:{id:"ws-dlrmap-map",name:"Network Map",layout:"tabs",views:["Network Map"]}`
  — a FRESH login lands directly on the mounted map, never the launchpad
  (resume-session may override on later logins, by design).
- Kept inside the view: filter bar (Owner/Lines/Status/Voltage chips + export),
  forecast playback bar, the SVG map with zoom/hide controls + Map Layers +
  legend overlays, Selected Line panel, Lines on Map table (all static).
- Verified 2026-08-28: 54/54 Playwright checks, zero pageerror + zero
  console-error (details in WV-PRODUCT-UPDATES.md).

### ev — actual view catalog (v0.3 build → `ev_dashboard_wv1.4.html`, integrated 2026-08-28)

Derived from the v0.3 file itself (its `DEFAULT_MODES` + generated User Guide). One
catalog view per product mode; group "Operations", the guide under "Reference".
Raw source `dashboards/ev_dashboard_v0.3.html` untouched.

| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `ev.monitor` | Monitor | Dashboard | Operations | singleton `applyMode('Monitor')` |
| `ev.forecast` | Forecast | Chart/Trend | Operations | singleton `applyMode('Forecast')` |
| `ev.dispatch` | Dispatch | Console | Operations | singleton `applyMode('Dispatch')` |
| `ev.fleet` | Fleet | Dashboard | Operations | singleton `applyMode('Fleet')` |
| `ev.analyze` | Analyze | Dashboard | Operations | singleton `applyMode('Analyze')` |
| `ev.all` | All Panels | Dashboard | Operations | singleton `applyMode('All')` (scrolls by design) |
| `ev.guide` | User Guide | Report | Reference | own renderer — `evBuildGuideDoc()` (live chart-shot capture via `buildHelp(sink)`) in a panel-scoped srcdoc iframe; NOT part of the singleton |

- **Accent (read from the v0.3 tokens):** `--brand → --ring` = **`#bb93ff`** dark /
  `#6d28d9` light — the Genie-kit ring violet (same family as ftm).
- **Systems (the build's own `SERVICES` truth, driven live via `renderHealth` hook):**
  `ev-telemetry` (EVSE Telemetry — ships **degraded**, a real comms truth), `ev-sessions`,
  `ev-forecast`, `ev-mustserve`, `ev-scada`, `ev-dispatchbus`, `ev-weather`
  (ok→live, degraded→degraded, down→stale).
- **Bridged rather than kept in-product:** topbar alarm bell + popover → `WV.raiseAlarm`
  (crit→crit, warn→maj, dedup on the product's `alarmKey`, ack-set respected); health
  button/popover → `WV.setSystemState`; the in-page Genie's-Read strip (six computed
  reads: ACTION/OPPORTUNITY/CONSTRAINT/DIVERGENCE/WASTE/HEADROOM) → the shell band's
  pager (`WV.genieRead.set({reads})`, silent + 400 ms-throttled, re-fed on every product
  re-render + `wv:time`); keys sheet + help → `WV.registerShortcuts` + `guide:"ev.guide"`;
  its own info toggle → `wv:info`; theme → `onTheme` (shell owns `html[data-theme]`).
  The strip's voice cluster (speaker / "Hello Genie" wake-word mic) retired with it —
  Voice Mode + Genie Listening are the shell commons.
- **Kept inside views:** feeder/state/segment/horizon filter bar (+ MODE seg + config
  cog + layouts caret, all routed through `openView` per the 1.4.0 parity rule), the
  relocated `.ev-utils` cluster (userChip impersonation + roleCog role-matrix — the
  product's RBAC demo is product-functional), playback scrubber, bulk export, per-card
  kebab/fullscreen/collapse, drag-to-zoom, panel DnD, workspaces, dispatch console
  interactions, role matrix. The product's own User Settings panel ships PARKED
  (`US_ENABLED=false` in the raw) — the shell Settings surface supersedes it outright.
- Startup workspace: `startupWs:{id:"ev-default",name:"EV Default",layout:"tabs",views:["Monitor"]}`
  — fresh login lands on Monitor, never the launchpad.
- Popouts ride the embed protocol: mode menu → `#wv-embed=ev.<slug>`; per-panel →
  `#wv-embed=ev.all&ev-panel=<cardId>` (custom user modes fall back to `ev.all`).
- Verified 2026-08-28: 58/58 Playwright checks, zero pageerror + zero console-error
  (details in WV-PRODUCT-UPDATES.md).

---

## Hub — `index.html (the hub; renamed from GenieAllDashboards.html 2026-08-31)` (framework 1.7.0, built 2026-08-28)

File `E:\AI\Self\Genie\index.html (the hub; renamed from GenieAllDashboards.html 2026-08-31)` · app-id `hub` (storage `wvfw.hub.*`) · stamp
`1.7.0 2026-08-28`. ONE shell instance whose catalog spans the five converted dashboards below;
each product view is a chromeless iframe of the converted file (embed protocol, spec §5). The
hub layer (`<style id="wv-hub-css">` + `<script id="wv-hub-js">`) sits inside the
`WV-PRODUCT registration` block — outside the nine WV-SHELL chunks — so `splice_111.py`
(target list includes the hub) propagates framework rounds into it untouched. Serve from
`localhost:8890` (Start-GenieShell.bat) or open via file:// — the `dashboards/` paths are relative.

### Product → file → view map (identities VERBATIM from each product's own `WV.registerProduct`)

| id | file (`dashboards/`) | name · lockup suffix · accent | home view | catalog views (embed `#wv-embed=` ids) | systems |
|---|---|---|---|---|---|
| `ftm` | `ftm_optimization_dashboard_wv1.1.html` | GridLine FTM Optimizer · Genie FTM · `#bb93ff` | `ftm.monitor` | `ftm.monitor` `ftm.forecast` `ftm.analyze` `ftm.all` (Operations) · `ftm.guide` (Reference) | ftm-ui, ftm-interfaces, ftm-database, ftm-kafka, ftm-milp, ftm-genie-model |
| `btm` | `btm_soc_forecast_dashboard_wv1.1.html` | DER Availability — BTM SOC · Genie BTM · `#6ba6e8` | `btm.monitor` | `btm.monitor` `btm.fleet` `btm.energy` `btm.accuracy` `btm.all` (Forecast Ops) · `btm.guide` (Reference) | forecast-pipeline, device-telemetry, forecast-publisher, message-bus, weather-feed, tariff-schedule |
| `ev` | `ev_dashboard_wv1.4.html` | Genie EV Charge Load Management · Genie EV · `#bb93ff` | `ev.monitor` | `ev.monitor` `ev.forecast` `ev.dispatch` `ev.fleet` `ev.analyze` `ev.all` (Operations) · `ev.guide` (Reference) | ev-telemetry, ev-sessions, ev-forecast, ev-mustserve, ev-scada, ev-dispatchbus, ev-weather |
| `dlr` | `dlr-genie_wv1.0.html` | Genie Dynamic Line Ratings · Genie DLR · `#bb93ff` | `dlr.fleet` | `dlr.fleet` `dlr.map` `dlr.events` `dlr.analytics` `dlr.linedetails` (Line Ratings) — all five ALSO declared as its MODE GROUP | dlr-database, dlr-scheduler, dlr-calc, dlr-weather |
|  |  | *(integrated 2026-09-02, 10.9 MB raw: singleton mount, deferred module boot, memory router driven by clicking the product's own nav; supersedes the retired `dlrmap` + `dlrline`)* |  |  |  |

20 product views + the framework's own `wv:settings` (Framework group, under `ftm`). Guide
ids are passed as each product's `guide` so the help menu's User Guide entry opens the
product's guide view as a frame.

### Embed notes (how the hub drives the children)
- Frame URL: `dashboards/<file>#wv-embed=<viewId>&inst=<n>&theme=<dark|light>&density=<compact|comfortable>`
  — the child boots chromeless (`body.wv-embed`, `EMB.on`) and posts `{wv:"ready", viewId}`.
  Every frame is a fresh product instance (the products' singleton-mount rule does not apply
  across frames); a second instance of the same view is `&inst=2`.
- Veil: "Loading ‹product› · ‹view›" until ready; 12 s fallback lifts the veil and keeps a
  muted "Still loading …" corner note until ready.
- Parent → child, on ready (+400 ms — ready is posted before the product's DOMContentLoaded
  init) and on every shell pref change: `{wv:"theme", theme, density, scale, accent}` (accent
  = the product's own token in auto mode, the pinned hue otherwise), `{wv:"prefs", …}`,
  `{wv:"time", hour}` (also on every shared-hour tick — all product views are time-subscribed).
- Child → parent: `{wv:"alarm", sev, msg, source}` → hub alarm with source
  `‹Product name› · ‹source›` and `srcView` = the frame's view (ack/clear hub-side);
  `{wv:"system", id, state}` → that product's health rows only (shared ids across dlrmap /
  dlrline stay independent). The shell's own embed listener still files the raw record first;
  the hub rewrites it in place (no duplicates).
- Popouts: the shell's popout of a hub view opens `dashboards/<file>#wv-embed=…` in a real
  window (multi-monitor); the hub re-briefs it with the product accent.
- Product switch: top-left lockup dropdown (accent swatch · system dots · live-frame count)
  and the right-side `#wv-hubProdChip` in the session pod open the same menu; opening a view
  of another product (voice "open ‹view›", palette, Genie rail, favorites/recents) switches
  product first. Genie Chat's OATI ▾ group lists all products' views grouped by product.
- i18n: view/group labels registered from the products' own dictionaries; a label shared by
  several products carries one hub-wide translation (first product in catalog order wins).
- Verified 2026-08-28: 108/108 Playwright checks (`verify_hub.py`), zero pageerror + zero
  console.error across the hub, every child frame and the popout; dashboards byte-identical
  (details in WV-PRODUCT-UPDATES.md).

### Hub — raw (not yet integrated) products, 2026-08-29

| id | file | view | notes |
|---|---|---|---|
| conv | `dashboards\conversationAndFeedback.html` | `conv.history` "Conversation History" | RAW: loaded as-is, ready on frame load, no embed protocol; own theme (dark) |
| pf | `dashboards\genie_powerflow_genie_standard.html` | `pf.dashboard` "Powerflow" | RAW: same; pulls ECharts/Leaflet/fonts from CDNs (needs internet) — vendor when integrating |

Converting either: run genie-shell-integrate on the file, then in the hub layer drop the id from `RAW`
and register its real view catalog (the embed protocol takes over automatically).

### conv — actual view catalog (Genie-standard raw → `conversationAndFeedback_wv1.2.html`, re-integrated 2026-08-31)

Supersedes `conversationAndFeedback_wv1.1.html` (same day, earlier round) which superseded
`conversationAndFeedback_wv1.0.html` (2026-08-29, built from the older raw
`dashboards/conversationAndFeedback.html`). wv1.1, wv1.0 and all their `*.pre-*` backups are
deleted. The named source of truth is now the raw `dashboards/conversationAndFeedback_v11.html`
(untouched). **`_v11.html` and the `_latest.html` wv1.1 was built from are BYTE-IDENTICAL**
(md5 `bfa7789efb1110eb9268b99678b49827`, 412 627 bytes) — v11 is the same CEO build under a
version-stamped name, so wv1.2 carries no UI or content delta from wv1.1. The wv1.2 delta is the
**full-width canvas** (CEO, this round) plus the 1.10.10 framework. The app-id stays `conv`, so
stored prefs, sessions, deep links and workspaces carry over.

| id | name | suffix | accent | systems |
|---|---|---|---|---|
| `conv` | Genie Conversation & Feedback | Genie Conv | `#8134FF` (its `--brand-violet`) | the four checks the raw's own health popover ran: `conv-ingest` Feedback ingest · `conv-coverage` Rating coverage · `conv-queue` Review queue · `conv-loop` Reply loop — states DRIVEN from the same truth (ok→live, warn→degraded, hard fail→stale); ships with the queue and the loop honestly degraded |

The new raw is the same review console rebuilt on the **Genie standard chrome**, which brought a top
bar (clock · alarms · user · shortcuts · help · Info split control · theme · health · sign-out), a
filter row, an in-page Genie's-Read strip, an INFO registry, a shortcuts sheet, a user guide, panel
kebabs, an export dialog — and **three panel MODES**. A mode is a named list of panels, so each one
is a real display with its own question: those are the three catalog views over the ONE page. The
queues/lenses strip (Needs review · Awaiting reply · Context-limited · Thumbs-down · Thumbs-up ·
Unrated · Ticketed · Everything) stays inside the views as the product-semantic toolbar it is, and
so does the filter row (moved into the main column).

| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `conv.monitor` | Review Monitor | Dashboard | Conversation Review | singleton mount of `#conv-root` + `applyMode(0)` — five tiles + Ratings over time + Thumbs-down by agent |
| `conv.history` | Conversation History | Console | Conversation Review | singleton + `applyMode(1)` (Triage) — tiles + queues/lenses + the conversation list. **HOME / PRIMARY**, id and name kept from wv1.0 |
| `conv.analysis` | Quality Analysis | Chart | Conversation Review | singleton + `applyMode(2)` — both charts + queues/lenses + the list |
| `conv.guide` | User Guide | Report | Reference | own renderer — the raw's help-modal copy rendered inline into `#conv-guide-host`; NOT part of the singleton, and registered as the product's `guide` so the shell help menu opens it |

- **Singleton-mount rule honored**: opening a second inline conv view MOVES the one page and closes
  the panel it left, with the standard "renders one inline view at a time" notice (ftm's pattern); a
  tab switch that shows a panel without re-mounting re-parents the page in `onVisibility`.
- The Mode segment stays in the filter row and **reroutes through `openView`**, so tab / view /
  workspace state never drifts. A mode the operator ADDS in the configuration modal has no catalog
  entry and falls through to the product's own switch (documented, by design).
- **Chrome removed** (commons principle — the shell owns one of each): top bar and every control in
  it, the alarm bar + popover, the health chip + popover, the in-page Genie's-Read strip and its
  10 s rotation timer, the ⓘ glyph + Floating/Docked caret menu + info card, the shortcuts button,
  the help button, the top-bar overflow pass, the clock, sign-out, the skip link. Their
  DERIVATIONS all stay — they are the product's domain logic.
- **Kept inside the views**: the filter row (Range 7/30/90 · Mode · configuration gear · workspace
  caret · export), the queues/lenses strip, search / group-by / row density / Export CSV, the panel
  kebabs (CSV · pop out · maximize · collapse · PNG · copy · pin · hide), the configuration modal +
  workspaces + undo, the export dialog (XLSX/CSV/PDF/JSON, hand-rolled), the detail drawer with its
  dock/split/maximize/pop-out, the guided tour, the themed tooltip layer.
- Overlays (drawer, scrim, group menu, panel menus, modals, the maximized panel + its veil, the
  tour, the tooltip) re-homed to a body-level `#conv-overlays` (also `data-wv-product-root`) with
  panel-aimed `--conv-*` geometry (now incl. `--conv-botgap` for the maximized panel).
- **Bridged**: alarms → `WV.raiseAlarm` (the raw's 6-condition engine, crit→crit / warn→maj /
  info→info, product-keyed dedup, the product's ack set respected, `srcView` per condition — the
  wv1.0 note "no alarm concept" no longer holds, the new raw has one); health → `WV.setSystemState`
  over the four checks; Genie's Read → BOTH scopes (below); Genie's Desk ← 5 oldest Needs-review
  conversations (attention; warning past a week; "Review" opens the drawer) + one Awaiting-reply
  summary; Info mode ← the raw's own INFO registry (11 entries) via `WV.info.resolve` + 16 rich
  `describeMany` entries + the `conv:view:` / `conv:kpi:` resolvers; shortcuts → 2 groups / 17 rows
  (Shift+T, Shift+A, `?` and Esc dropped — those surfaces are the shell's); 6 palette actions.
- **Genie's Read — both scopes.** GLOBAL: the raw's own six domain kinds (action · constraint ·
  divergence · waste · headroom · opportunity), worst-first, so reads[0..1] feed the sign-in
  briefing as speakable sentences. LOCAL: exactly **2 reads per view, on that view's own numbers,
  each with a cta that acts on that view**, refiled on every product re-render (range, lens or
  filter change) — so the Local scope never falls to the empty state on any conv tab:
  · `conv.monitor` — satisfaction-vs-coverage (cta: widen the window) · the diverging agent's share
  of ring volume vs its own rate (cta: filter both charts to that agent)
  · `conv.history` — the review queue and its oldest wait (cta: open Needs review) · conclusions
  never sent back + % answered (cta: open Awaiting reply)
  · `conv.analysis` — thumbs-down rate over the window + bucket shape (cta: group the list by
  context signal) · the context-compaction share of complaints (cta: open Context-limited)
  · `conv.guide` — tour steps + the live queue behind them (cta: start the tour) · Info entries and
  product shortcut rows (cta: open the shortcuts sheet)
- **House rules**: only the KPI tiles are rounded (11px), everything below on 4px; the canvas is
  **FULL WIDTH** (CEO, 2026-08-31 — `#conv-root .viewport{max-width:none;margin:0}`), which
  REVERSES wv1.1's 1560px centred cap: that cap was tuned for the older raw's narrower rhythm and
  the v11 design is full-bleed, so the canvas now tracks the viewport at every width (measured
  1841 px of 1841 available at a 1913 px viewport and 1328 of 1328 at 1400 px, standalone and in
  the hub frame; Δviewport 513 px = Δcanvas 513 px). No max-width, no centring margin and no
  fixed-width wrapper survives anywhere in the layout chain — the ONE remaining `margin:0 auto`
  is `#conv-guide-host{max-width:900px}`, the User Guide's prose measure, which matches the
  framework's own `.wv-guide-wrap{max-width:920px;margin:0 auto}` and is a document, not the
  v11 layout; KPI tiles in Powerflow's tile language (one
  family tone per tile from the `--kc` rgb triplet, 30px badge, plain description line with the
  trend as coloured emphasis rather than a pill, mono tone footer, and a mini sparkline in EVERY
  tile — the raw ships a sparkline on one tile only, so `kpiSeries()` computes the other four);
  no dot texture outside the shell band; read scope labels Global / Local.
- Monitor's chart row FILLS the panel (the raw's fixed 212px left the lower half of a first-class
  view empty); the donut is capped at the size it has in the raw so the per-agent list keeps its
  width. Triage and Analysis keep the raw's rhythm.
- Raw gaps fixed at root cause (documented, not silently): `waterfall()` was called by the run bar
  but never defined; `setView()` was called by the alarm rows and the read strip behind a `typeof`
  guard but never defined; the tour's chart step clicked a `#chartsBtn` the Genie-standard rebuild
  had retired (a TypeError in Triage, where the chart row is off).
- Startup workspace `ws-conv-history`; embed protocol honored (`#wv-embed=<view>`, `&band=1`
  popouts carry the band on the Local scope); zero external requests (Google Fonts dropped);
  product root pinned `direction:ltr`; the product's own pop-out windows copy `style[data-conv-css]`
  only and are separate untranslated documents.
- **Local reads reach the HUB band** (new in wv1.2, framework 1.10.9/1.10.10 — this reverses the
  wv1.1 note that reads relay parent→child only): an embedded child now posts `{wv:"gread-up"}`
  for every view-scoped set, the hub re-files it with wired-back CTAs, and the hub's Local scope
  renders the child's read. Verified in the PARENT window: `GREAD.views['<id>'].reads.length === 2`
  for all four views, headlines non-empty and distinct, both reads carrying an action, and
  `setGreadScope('view')` rendering the read instead of `.wv-gr-empty`.
- **n/a for this product**: no chart/map library to vendor (every chart is hand-written SVG, so
  `onTheme` needs no rebuild — the tokens do it); no runtime basemap tiles; no view catalog change
  in wv1.2 (the v11 raw's `DEFAULT_MODES` are still Monitor · Triage · Analysis, so the four views
  are unchanged); no i18n / info / alarm / health / shortcuts delta (the raw did not change).
- Verified 2026-08-31 (wv1.2): **120/120** product deep-verify (incl. the full-width proof at
  1913 px and 1400 px and the runtime parked-block pair) + `verify_shell --smoke` **13/13** +
  **44/44** hub-conv checks (2 relayed Local reads per view measured in the top frame, full-width
  in the frame, both themes), `splice_shell --dry` no-op at 1.10.10, zero pageerror and zero
  non-tolerated console.error throughout (details in WV-PRODUCT-UPDATES.md).

### pf — actual view catalog (Genie-standard build → `genie_powerflow_genie_standard_wv1.0.html`, integrated 2026-08-29)

| id | name | suffix | accent | systems |
|---|---|---|---|---|
| `pf` | Genie Powerflow | Genie PF | `#bb93ff` (its `--ring`; `#6d28d9` light) | `pf-solver` Power flow solver · `pf-model` Network model · `pf-der-telemetry` DER telemetry (degraded) |

A four-MODE console (Real-Time / Planning / HCA / DOE); the seven Real-Time module tabs are
first-class views, the three study modes are coarse mode-views whose own tab rows stay in-view.
MODE segment + Real-Time tab row kept (product-semantic) and rerouted through `openView`.

| view id | name | type | group |
|---|---|---|---|
| `pf.map` | Network Map | Map | Real-Time Operations |
| `pf.fpa` | Feeder Profile Analyzer | Chart | Real-Time Operations |
| `pf.results` | Power Flow Results | Dashboard | Real-Time Operations (PRIMARY) |
| `pf.validation` | Solver Validation | Chart | Real-Time Operations |
| `pf.der` | DER Controls | Console | Real-Time Operations |
| `pf.config` | Configuration | Form | Real-Time Operations |
| `pf.forecast` | Forecast | Chart | Real-Time Operations |
| `pf.planning` | Operational Planning | Dashboard | Studies |
| `pf.hca` | Hosting Capacity | Map | Studies |
| `pf.doe` | Dynamic Operating Envelopes | Chart | Studies |

- Bridged: alarm bell → `WV.raiseAlarm` (5 derived alarms, crit/maj map, product-keyed dedup,
  srcView per family); health popover → `WV.setSystemState` (static truth); Genie's Read strip
  (6 computed reads with KIND chip + fact chips) → shell band (kind folded into the headline lead,
  facts → insight rows — **framework gap**: a typed kind chip + fact chips in the band); Info →
  `WV.info.resolve` over the product INFO registry; help modal/keys → shell; theme → `pfApplyTheme`.
- Self-contained: ECharts 5.5.0 + Leaflet 1.9.4 vendored (from ftm/btm files), echarts-gl 2.0.9
  vendored inert (3D FPA style), Google Fonts dropped. Basemap tiles (CARTO/Esri) still fetched at
  runtime — product behaviour; CARTO shows an "API KEY REQUIRED" watermark.
- Raw gaps surfaced: `#panelMenu` ships without CSS (hidden); 3-second `#tall-info` dev diagnostics
  removed; one disposed-ECharts resize tick guarded. No User Guide (5-line help modal was chrome).
- Startup workspace `ws-pf-map` (Network Map — the landing view since 2026-08-31; was Power Flow Results); embed protocol honored; no-scroll contract in all 10 views.
- Verified 2026-08-29: 82/82 product checks + verify_shell --smoke 13/13, zero errors.

### bafc — actual view catalog (v0.8 build → `BA_Margin_Capacity_Dashboard_wv0.8.html`, integrated 2026-08-31)

| id | name | suffix | accent | systems |
|---|---|---|---|---|
| `bafc` | BA Forecast & Capacity Console | Genie BA | `#bb93ff` (its `--ring`; `#6d28d9` light) | six real upstream feeds (`FEED_SOURCES`): `bafc-run` Forecast execution · `bafc-actuals` EIA-930 actuals · `bafc-interchange` EIA-930 interchange · `bafc-weather` Weather inputs · `bafc-factors` Capacity factors · `bafc-refdata` BA reference data — states DRIVEN from each feed's age vs its own cadence (>1x -> degraded, >2x -> stale); ships with three honestly degraded |

A five-DESK console (its Mode segment: Real-Time / Planning / Analysis / Management + the implicit
All) whose old tab bar was retired in raw v5 — Margin Verification, Data Explorer and Assumptions
are panel-triggered drill-downs. One catalog view per desk + one per drill-down + the generated
guide. Raw source `dashboards/BA_Margin_Capacity_Dashboard_v0.8.html` untouched.

| view id | name | type | group | mount recipe |
|---|---|---|---|---|
| `bafc.realtime` | Real-Time | Console | Capacity Desks | singleton `applyMode('Real-Time')` (Leaflet map: invalidateSize on mount/onResize/onVisibility) |
| `bafc.planning` | Planning | Dashboard | Capacity Desks | singleton `applyMode('Planning')` |
| `bafc.analysis` | Analysis | Dashboard | Capacity Desks | singleton `applyMode('Analysis')` |
| `bafc.management` | Management | Report | Capacity Desks | singleton `applyMode('Management')` |
| `bafc.all` | All Panels | Dashboard | Capacity Desks | singleton `applyMode('All')` |
| `bafc.verify` | Margin Verification | Report | Drill-Downs | singleton `activateTab('verify')` — opens in the CURRENT mode, exactly the raw drill-down semantics (write gates follow the mode's permissions) |
| `bafc.explore` | Data Explorer | Chart | Drill-Downs | singleton `activateTab('explore')` |
| `bafc.factors` | Assumptions | Form | Drill-Downs | singleton `activateTab('factors')` |
| `bafc.guide` | User Guide | Report | Reference | own renderer — `bafcBuildGuideDoc()` (the split `openHelp` builder; All-mode capture + restore, like the raw `buildHelp`) in a panel-scoped blob iframe; NOT part of the singleton |

- **Accent (read from the v0.8 tokens):** `--brand → --ring` = **`#bb93ff`** dark / `#6d28d9`
  light — the Genie-kit ring violet.
- **Global-scope hygiene (new for this conversion):** the raw console declares `toast`,
  `renderAll`, `renderAlarms`, `renderGenieRead` at top level — the SAME names the shell's own
  script declares, and a later top-level declaration overrides the shell's. Renamed in the
  product layer (`bafcToast` / `bafcRenderAll` / `bafcRenderAlarms` / `bafcRenderGenieRead`);
  the shell's four stay untouched. (Prior conversions carry this collision class latently —
  flagged in WV-PRODUCT-UPDATES.md.)
- **Bridged rather than kept in-product (commons principle):** topbar alarm chip + popover →
  `WV.raiseAlarm` (8-condition engine `buildAlarms`, crit→crit / warn→maj, deduped on the
  product's `alarmKey`, its ack set respected); health button + popover → `WV.setSystemState`
  (re-derived on `wv:time`); the in-page Genie's-Read strip + its Explore-rail twin →
  `WV.genieRead.set` (7 worst-first reads at the pinned hour, KIND folded into the headline
  lead, `meta` pairs → insight rows; reads[0..1] = CONSTRAINT → ACTION feed the sign-in
  briefing); keys sheet → `WV.registerShortcuts` (Shift+A/G/T + `?` + Esc rows dropped — those
  surfaces are the shell's); own ⓘ toggle/caret/menu → `wv:info` → its `setInfoMode` (float);
  its INFO registry (kind/title/basics/what/why/calc/formula/read/ok/no/wrong/terms/rel) →
  `WV.info.resolve` for the shell docked panel; theme → shell `html[data-theme]` (`.dark`
  selectors re-keyed; `onTheme` steers the dark/gray basemaps + re-renders); clock / user chip /
  sign-out → shell chrome. Outstanding follow-up shift notes → **Genie's Desk** attention items
  (dedup by note id; cleared on ack/clear). 5 palette actions (Now / Simulate / Export / Shift
  notes / Guided tour).
- **Kept inside views (relocated where the topbar died):** forecast-run provenance chip +
  Refresh, Shift notes (localStorage handover + BroadcastChannel), the guided tour — moved into
  the filter bar (`.bafc-utils`); Window/Hour/Simulate(+pace)/Horizon/Focus filter bar; the 24h
  time ribbon; per-panel kebab (CSV / pop out / maximize / collapse / PNG / copy / pin / hide);
  hero + float-dock mechanic; panel DnD; export dialog (XLSX/CSV/PDF/JSON, hand-rolled); BA
  Review shared-axis stack; Margin Verification what-if + scenarios; Data Explorer grid;
  Assumptions editors + reserve thresholds. Its Mode segment is KEPT (product vocabulary) and
  rerouted through `openView` (capture intercept); every other internal tab move (drill-down
  buttons, scenario hand-off, the tour) rides an `activateTab` wrapper → `openView`, so shell
  tab state never drifts; custom user-defined modes fall through natively. The
  User-Configuration cog + workspace caret are hidden — shell workspaces supersede (mode data
  model + `bafc-*` storage intact, custom modes still render in the segment).
- **Popouts ride the embed protocol:** every self-URL builder (`popOutPanel`, `rvPopOut`, the
  mode right-click menu) routes through `bafcPopURL` → `#wv-embed=bafc.<view>&…` (panel solos +
  custom modes → `bafc.all`); the mount re-applies `applySoloPanelFromHash()` so a solo panel
  window reproduces the raw contract (params `panel/ba/hour/date/layers/…` unchanged).
- **Structure:** body-state classes (mode-*, panel-solo*, focus-view, info-mode/docked,
  no-edit-*, has-panel-fs, alarm-docked) re-rooted to `[data-bafc-scope]` carried by BOTH
  `#bafc-root` and a body-level `#bafc-overlays` (the runtime home its `overlayHost()` now
  returns for toast / tooltips / info card, so re-parented overlays keep every state selector);
  the `.shell` 100vh frame re-keyed to the panel via `--bafc-vh` + two graduated densify tiers;
  UI scale × Font size is the SHELL's `--wv-vz` zoom (1.10.6) — the product deliberately does
  NOT self-zoom; `writeHash` suppressed under the shell (workspaces own state); `fmtClock` +
  shift-note stamps route via `WV.fmt.time` (`fmtDay` stays ISO by design — it doubles as a
  data key in export filenames); vendored Leaflet 1.9.4 (copied from btm — the dlrmap file is a
  static SVG snapshot and carries no Leaflet); zero external library/font requests (CARTO/Esri
  basemap tiles at runtime are product behaviour).
- **House rules applied:** ONLY the KPI tiles ride the 11px corner (panels/strips 4px); KPI
  tiles restyled to the Powerflow tile language (tone tint, 30px badge, mono footer lifted from
  the tile's own sub-line, sparkline kept; compact variant in the Real-Time fleet column);
  designed as a full-viewport console — no width cap needed; product root pinned
  `direction:ltr` (dense mono readouts) with labels still translating in place.
- **i18n:** ~150 UI labels (views, groups, panel titles, filter/segment/button/layer labels)
  registered fr-CA/es-MX/ar/ja; data (BA codes, model names, MW/normalized figures), dynamic
  composed sentences (reads, alarm descriptions, live tooltips), the generated guide prose and
  SVG-drawn chart internals are out of scope by design.
- Startup workspace `ws-bafc-realtime` — a fresh login lands on Real-Time, never the launchpad.
- Verified 2026-08-31: 62/62 product deep checks + `verify_shell.py --smoke` 13/13, zero
  pageerror + zero non-tolerated console.error; hub full gate + dist smoke recorded in
  WV-PRODUCT-UPDATES.md.
