# SESSION CONTEXT — the standing rulings and working practice

Read after `START-HERE.md`. This is the judgement that does not fit in a procedure: the CEO's
rulings, the conventions they imply, and the mistakes already paid for. The `WV-*.md` documents
beside this file carry the contract (`WV-INTEGRATION-SPEC.md`), the binding ids
(`WV-PRODUCT-REGISTRY.md`) and the dated history with root causes (`WV-PRODUCT-UPDATES.md`).

*Written 2026-09-02, framework 1.11.7. Product name: **OATI Genie UI**; the framework is **GenieUI**
(it was called "webVision" until 2026-09-02 — old comments still say so).*

---

## 1 · What "integrated" means here

A conversion is not done when the dashboard renders inside the shell. It is done when:

- all nine `WV-SHELL` sentinel chunks are spliced in and `splice_shell.py --dry` reports the file
  **no-op (byte-identical)** at the current version;
- every interactive surface of the raw dashboard still works — menus, dialogs, exports, filters,
  playback — **standalone AND embedded**, with overlays hit-tested at their centre in EMBED mode
  (an overlay that toggles a class but paints under the frame has broken twice);
- **both Genie's Read scopes are filled**: a product-level Global set, and per-view Local reads —
  computed from live state, never hardcoded, each with an action that acts on the open dashboard;
- the product's globals do not collide with the shell's (and vice versa — see §3);
- the smoke suite passes with zero pageerror and zero non-tolerated console.error.

## 2 · The CEO's standing rulings

**Supplied read tables are TEMPLATES, NOT COPY.** When content arrives as a table (a kind chip, a
one-line read, figures), adopt the sentence pattern, the chip and the figure list verbatim — but
every VALUE is a formula against live state, refiled on the product's own events. Code *both
branches* of every sentence: the quiet one fires more often than you expect, and "0 lines are
critical" is a correct answer. One hardcoded number contradicts the chart beneath it and destroys
trust in every read the system has ever filed.

**A read's action acts on the dashboard you are looking at.** Never blank it, never navigate away
when a scroll-and-highlight will do.

**One channel per event.** Alarms and notifications are delivered by the genie (island + bell) when
`genieHerald` is on; toasts are the FALLBACK when it is off. Never both. A frame's boot relay of its
existing alarms is *state, not news* — it must never toast. Confirmations ("Preferences saved") still
toast in every mode: they have no other home.

**A selection owns its cell, and is lit.** No floating fill inside a margin. The segmented spec is in
the `genie-ui` skill; the mode group and the Genie's Read Global/Local scope are the reference
implementations, and any segmented control a product keeps must match them.

**Two controls sharing a bar need three separation cues AND different selection marks.** If the
active tab and the active chip highlight identically, the zones collapse into one bar however you
style the ground.

**Names do not carry the brand.** The chrome adds "OATI". Register `Genie Dynamic Line Ratings`, not
`OATI Genie Dynamic Line Ratings`.

**The greeting is ceremony.** It plays once per user × device × language at sign-in (Once / Every /
Off), never on a language switch — a language switch *stops* whatever is speaking, because it is now
the wrong voice.

## 3 · Rules learned the hard way

**The global-collision sweep runs in BOTH directions.** A product's `toast`/`renderAlarms` can shadow
the shell's; and a new FRAMEWORK global can collide with a product's. A framework `const MODES` met
four products that each already declared `const MODES` — two `const` of one name in a document is a
**SyntaxError that takes the entire product layer down**. Grep the converted dashboards before naming
anything new.

**When a symptom returns after call-site fixes, the bug is in the shared helper.** `svgPath()` emitted
`d="M0.00 NaN …"` because it guarded the empty case but not `maxY` arriving 0 or undefined. Two rounds
had patched individual callers. Guarded once in the helper: fixed.

**When a defect is called transient twice, measure it in isolation.** That same bug was twice
attributed to machine load. On an idle box: 0, 28 and 308 errors across three runs.

**A hung Playwright locator can mean a busy main thread, not a bad selector.** `hover()` timed out
while `evaluate()` still worked, because a pure derivation was recomputed 8+ times per repaint
(1764 ms per commit). That asymmetry is the tell — measure the thread before touching the test.

**Nothing may repaint while nobody is looking at it.** Every open view repainting every 2 s degraded
hub view-swap from 4.8 s to 151 s. Gate repaint loops on visibility.

**The user HEARS main-thread jank.** A dashboard's 2 s boot task delayed both the shell's timers and
`speechSynthesis`' own start, which is heard as the genie stuttering. Keep any single boot task under
~50 ms; defer a heavy module so it never shares the thread with the sign-in ceremony.

**Gates overlapping a splice are void.** Including your own. If the stamp in the output does not match
the file, the run tested a moving target — re-run it clean.

**Patch scripts go in files.** Inline heredocs with backslashes or non-ASCII corrupt silently.

## 4 · Working practice that produced the good results

- **Verify by measurement, not by screenshot.** Click every CTA; assert the frame, the product root
  (the tallest `[data-wv-product-root]`, excluding `*-overlays`/`*-guide-host`) and its text survive.
  Sample animation state across a full cycle rather than eyeballing it.
- **Prove a fix by re-breaking it.** The overlay hit-test guard was validated against a deliberately
  re-broken copy; without that, a guard that passes proves nothing.
- **Render design options and judge them as pixels.** Selection states, scene variants and bar
  placements were all decided from real screenshots, never from prose.
- **When a suite check contradicts an intended change, re-arm it on the new intent — never relax it.**
  Every such check exists because something broke once.
- **Say what is not done.** Honest quiet branches, stated deviations, and "this is a snapshot so the
  live branch will differ" are worth more than a clean-looking claim.

## 5 · Architecture in one page

- **Framework** = `GenieApplicationShell.html`, nine byte-exact `<!-- WV-SHELL:BEGIN … / END … -->`
  chunks (`fonts css symbols login app overlays js-core js-render js-app`) plus a version stamp.
  `splice_shell.py` copies those chunks into every converted file; a product's own code lives
  OUTSIDE the sentinels and survives every splice.
- **Hub** = `index.html`, app-id `hub`. Products are chromeless iframes at
  `dashboards/<file>#wv-embed=<viewId>&inst=…`. Messages: `ready · theme · prefs · time · info · gread ·
  gread-run · gread-up · open-view · mode · mode-changed · shortcuts · key · pointer · present`.
- **Views** are the unit of navigation: registered per product, opened as tabs, searchable in the
  palette, saveable in workspaces, poppable into real windows.
- **Mode group** (`WV.registerModes`) renders a product's sub-views as a segmented control at the far
  right of the tab row; switching is IN PLACE (never `openView`, never a second instance), and the
  group is scoped to the focused view's product.
- **Genie's Read** is the band: Global (the product's own reads; in the hub, a fleet roster line per
  product) and Local (the reads for the display in front of you). Reads relay child→host
  (`gread-up`) and their actions route back (`gread-run`).
- **Storage** is namespaced `wvfw.<app-id>.*` — never rename it casually; renaming discards every
  user's saved preferences and sessions.
