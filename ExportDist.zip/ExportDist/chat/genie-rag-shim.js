// ============================================================================
// OATI Genie chat — RAG SHIM. Carried over from chat/index.html (2026-08-29): translates the
// widget bundle's fixed old-API calls (GetGenieSettings, channel/list|selected, OATIClientVar/*,
// Genie/UserPrompt, Genie/UserChatHistoryList, Genie/GetUserChatHistory, Genie/UpdateChatHistory,
// Genie/GroupsList, Genie/UserFeedback) to the real Rag API (openapi.json) — or mocks the ones
// that have no backend yet. Reads every value from window.WV_GENIE_CONFIG (genie-config.js must
// load first). Publishes window.WV_GENIE_SHIM = { install, installed }.
//
// The shim wraps window.fetch ONLY for the listed paths; every other request (the host page's
// own fetches included) goes straight to the original fetch untouched.
// ============================================================================
(function () {
  function cfg() { return window.WV_GENIE_CONFIG || {}; }

  let installed = false;

  function installGenieRagShim() {
    if (installed) return false;
    installed = true;
    const originalFetch = window.fetch.bind(window);
    const LOCAL_STORAGE_PREFIX = 'genie-demo-clientvar:';

    function ragUrl(path) {
      return String(cfg().ragBaseUrl || '').replace(/\/+$/, '') + String(cfg().ragServerPath || '') + path;
    }

    function jsonResponse(body, status) {
      const text = body === undefined ? '' : JSON.stringify(body);
      return new Response(text, { status: status || 200, headers: { 'Content-Type': 'application/json' } });
    }

    function emptyResponse(status) {
      return new Response(null, { status: status || 204 });
    }

    function parseJsonBody(init) {
      if (!init || init.body === undefined || init.body === null) return undefined;
      try {
        return JSON.parse(init.body);
      } catch (e) {
        return undefined;
      }
    }

    function demoUserMetadata() {
      return { user_id: cfg().userId, organization_id: cfg().organizationId };
    }

    function staticChannels() { return Array.isArray(cfg().channels) ? cfg().channels : []; }

    // Every real Rag call goes through here — always the real, un-shimmed fetch, POST + JSON.
    async function callRag(path, body) {
      const res = await originalFetch(ragUrl(path), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(body),
      });
      const text = await res.text();
      const data = text ? JSON.parse(text) : undefined;
      if (!res.ok) {
        const err = new Error('Rag API ' + path + ' failed with status ' + res.status);
        err.status = res.status;
        err.body = data;
        throw err;
      }
      return data;
    }

    // ---- GetGenieSettings — fully mocked, no real backend yet ----
    function handleGetGenieSettings() {
      const settings = cfg().settings || {};
      console.debug('[genie-shim] GetGenieSettings -> mocked defaults', settings);
      return jsonResponse(settings);
    }

    // ---- channel/list, channel/selected — fully mocked from the static channels, no real backend yet ----
    function handleChannelList() {
      console.debug('[genie-shim] channel/list -> static channels');
      return jsonResponse(staticChannels());
    }

    function getPersistedChannel() {
      const channels = staticChannels();
      try {
        const raw = localStorage.getItem(LOCAL_STORAGE_PREFIX + 'oati-genie-last-channel');
        if (raw) {
          const parsed = JSON.parse(raw);
          const match = channels.find((c) => c.id === parsed.id);
          if (match) return match;
        }
      } catch (e) {
        // ignore malformed/unavailable localStorage
      }
      return channels.find((c) => c.isDefault) || channels[0] || null;
    }

    function handleChannelSelected() {
      const channel = getPersistedChannel();
      console.debug('[genie-shim] channel/selected ->', channel);
      return jsonResponse(channel);
    }

    // ---- OATIClientVar/Save|GetClientVariable — fully mocked via localStorage, no real backend ----
    // `Value` on save already arrives JSON-stringified by the bundle. The real GetClientVariable
    // response has been observed to be *double* JSON-encoded (the HTTP body is a JSON string whose
    // decoded value is itself the stored JSON text) — jsonResponse(stored) below reproduces exactly
    // that by JSON-encoding the already-stringified value one more time.
    function handleClientVarSave(init) {
      const body = parseJsonBody(init);
      if (body && body.Key) {
        try {
          localStorage.setItem(LOCAL_STORAGE_PREFIX + body.Key, body.Value);
        } catch (e) {
          // ignore quota/unavailable localStorage
        }
      }
      console.debug('[genie-shim] SaveClientVariable', body);
      return emptyResponse(204);
    }

    function handleClientVarGet(url) {
      let key = null;
      try { key = new URL(url, window.location.href).searchParams.get('key'); } catch (e) { key = null; }
      let stored = null;
      try {
        stored = localStorage.getItem(LOCAL_STORAGE_PREFIX + key);
      } catch (e) {
        // ignore unavailable localStorage
      }
      console.debug('[genie-shim] GetClientVariable', key, '->', stored);
      if (stored === null) return jsonResponse(null);
      return jsonResponse(stored);
    }

    // ---- Genie/UserPrompt — real: POST /api/v1/chat, then read the reply back via /Conversations/Get ----
    // (openapi.json leaves /api/v1/chat's response schema undefined, so its own response is ignored;
    // /Conversations/Get is fully typed and used as the source of truth for the reply text/references.)
    async function handleUserPrompt(init) {
      const oldBody = parseJsonBody(init) || {};
      const oldMetadata = oldBody.metadata || {};
      const chatRequest = {
        metadata: {
          user_id: cfg().userId,
          organization_id: cfg().organizationId,
          channel: oldMetadata.channel,
          data_source: oldMetadata.data_source,
        },
        prompt: oldBody.prompt,
        conversation_id: oldBody.conversation_id,
        stream: false,
        files: [],
      };

      console.debug('[genie-shim] POST /api/v1/chat', chatRequest);
      try {
        await callRag('/api/v1/chat', chatRequest);
      } catch (err) {
        console.debug('[genie-shim] /api/v1/chat failed', err);
        return jsonResponse({ prompt_id: null, status: 'error', response: null, references: [], error: 'Failed to reach Genie: ' + err.message });
      }

      const getReq = { user_metadata: demoUserMetadata(), conversation_id: oldBody.conversation_id };
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const detail = await callRag('/Conversations/Get', getReq);
          const prompts = (detail && detail.prompts) || [];
          const last = prompts[prompts.length - 1];
          if (last && last.response) {
            console.debug('[genie-shim] resolved chat response via /Conversations/Get', last);
            return jsonResponse({
              prompt_id: last.id,
              status: 'complete',
              response: last.response,
              data_generation_timestamp: last.response_dt,
              references: last.references || [],
              error: null,
            });
          }
        } catch (err) {
          console.debug('[genie-shim] /Conversations/Get attempt ' + attempt + ' failed', err);
        }
        if (attempt === 0) await new Promise((resolve) => setTimeout(resolve, 500));
      }
      return jsonResponse({
        prompt_id: null,
        status: 'error',
        response: null,
        references: [],
        error: 'Genie responded, but the reply could not be read back yet — try reopening this conversation in a moment.',
      });
    }

    // ---- Genie/UserChatHistoryList — real: POST /Conversations/List ----
    async function handleChatHistoryList() {
      console.debug('[genie-shim] Genie/UserChatHistoryList -> Conversations/List');
      try {
        const list = await callRag('/Conversations/List', { user_metadata: demoUserMetadata() });
        const mapped = (list || []).map((c) => ({
          conversation_id: c.conversation_id,
          title: c.title,
          tags: c.tags || [],
          group: c.group,
          favorite: c.favorite,
          channel: c.channel,
          status: c.status,
        }));
        return jsonResponse(mapped);
      } catch (err) {
        console.debug('[genie-shim] Conversations/List failed', err);
        return jsonResponse([]);
      }
    }

    // ---- Genie/GetUserChatHistory — real: POST /Conversations/Get ----
    async function handleChatHistoryDetail(init) {
      const oldBody = parseJsonBody(init) || {};
      console.debug('[genie-shim] Genie/GetUserChatHistory -> Conversations/Get', oldBody);
      try {
        const detail = await callRag('/Conversations/Get', {
          user_metadata: demoUserMetadata(),
          conversation_id: oldBody.conversation_id,
        });
        return jsonResponse({
          conversation_id: detail.conversation_id,
          title: detail.title,
          tags: detail.tags || [],
          group: detail.group,
          favorite: detail.favorite,
          channel: detail.channel,
          status: detail.status,
          prompts: (detail.prompts || []).map((p) => ({
            id: p.id,
            prompt: p.prompt,
            response: p.response,
            received_dt: p.received_dt,
            response_dt: p.response_dt,
            references: p.references || [],
            feedback_positive: p.feedback_positive,
            // Old shape stores a single reason-code string; the new API stores an array — take the first.
            feedback_reason_code: p.feedback_reason_code && p.feedback_reason_code.length ? p.feedback_reason_code[0] : undefined,
            feedback_description: p.feedback_description,
          })),
        });
      } catch (err) {
        console.debug('[genie-shim] Conversations/Get failed', err);
        return jsonResponse({ prompts: [] });
      }
    }

    // ---- Genie/UpdateChatHistory — real: POST /Conversations/Update ----
    async function handleUpdateChatHistory(init) {
      const oldBody = parseJsonBody(init) || {};
      const req = {
        user_metadata: demoUserMetadata(),
        conversation_id: oldBody.conversation_id,
        title: oldBody.title,
        group: oldBody.group,
        favorite: oldBody.favorite,
        status: oldBody.status,
        tags: oldBody.tags,
        updated_at: new Date().toISOString(),
      };
      console.debug('[genie-shim] Genie/UpdateChatHistory -> Conversations/Update', req);
      try {
        await callRag('/Conversations/Update', req);
      } catch (err) {
        console.debug('[genie-shim] Conversations/Update failed', err);
      }
      return emptyResponse(204);
    }

    // ---- Genie/GroupsList — real: POST /Conversations/Groups/List ----
    async function handleGroupsList() {
      console.debug('[genie-shim] Genie/GroupsList -> Conversations/Groups/List');
      try {
        const groups = await callRag('/Conversations/Groups/List', { user_metadata: demoUserMetadata() });
        return jsonResponse(groups || []);
      } catch (err) {
        console.debug('[genie-shim] Conversations/Groups/List failed', err);
        return jsonResponse([]);
      }
    }

    // ---- Genie/UserFeedback — real: POST /UserFeedback ----
    async function handleUserFeedback(init) {
      const oldBody = parseJsonBody(init) || {};
      const req = {
        user_metadata: demoUserMetadata(),
        conversation_id: oldBody.conversation_id,
        prompt_id: oldBody.prompt_id,
        positive: oldBody.positive,
        reason_code: oldBody.reason_code || [],
        description: oldBody.description || '',
      };
      console.debug('[genie-shim] Genie/UserFeedback -> UserFeedback', req);
      try {
        await callRag('/UserFeedback', req);
        return emptyResponse(204);
      } catch (err) {
        console.debug('[genie-shim] UserFeedback failed', err);
        return emptyResponse(err.status || 500);
      }
    }

    window.fetch = function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      let pathname = url;
      try {
        pathname = new URL(url, window.location.href).pathname;
      } catch (e) {
        // fall back to the raw url string if it's not a valid absolute/relative URL
      }

      if (pathname.endsWith('/GetGenieSettings')) return Promise.resolve(handleGetGenieSettings());
      if (pathname.endsWith('/channel/list')) return Promise.resolve(handleChannelList());
      if (pathname.endsWith('/channel/selected')) return Promise.resolve(handleChannelSelected());
      if (pathname.endsWith('/OATIClientVar/SaveClientVariable')) return Promise.resolve(handleClientVarSave(init));
      if (pathname.endsWith('/OATIClientVar/GetClientVariable')) return Promise.resolve(handleClientVarGet(url));
      if (pathname.endsWith('/Genie/UserPrompt')) return handleUserPrompt(init);
      if (pathname.endsWith('/Genie/UserChatHistoryList')) return handleChatHistoryList();
      if (pathname.endsWith('/Genie/GetUserChatHistory')) return handleChatHistoryDetail(init);
      if (pathname.endsWith('/Genie/UpdateChatHistory')) return handleUpdateChatHistory(init);
      if (pathname.endsWith('/Genie/GroupsList')) return handleGroupsList();
      if (pathname.endsWith('/Genie/UserFeedback')) return handleUserFeedback(init);
      // Not called — AutoSuggestion.IsEnabled is false in the config settings.
      if (pathname.endsWith('/Genie/GetOutageFilteringData')) return Promise.resolve(jsonResponse({}));

      return originalFetch(input, init);
    };
    return true;
  }

  window.WV_GENIE_SHIM = { install: installGenieRagShim, get installed() { return installed; } };
})();
