// ============================================================================
// OATI Genie chat — CONFIG (the single edit point). Loaded by the webVision shell
// (GenieApplicationShell.html / GenieAllDashboards.html) and by chat/index.html (the
// standalone demo) BEFORE genie-rag-shim.js and the widget bundle. Plain script, no
// module syntax — it only publishes window.WV_GENIE_CONFIG.
// ============================================================================
window.WV_GENIE_CONFIG = {
  // Master switch for the shell integration (the lamp / Ctrl+G still exist; false = nothing mounts).
  enabled: true,

  // "connected" → the element gets api-endpoint = ragBaseUrl and the bundle runs its Connected
  //               Mode (chat / history / feedback through the RAG API via genie-rag-shim.js).
  // "offline"   → no api-endpoint: the bundle's built-in demo component (replies echo the
  //               question after a short "thinking" beat; Desk + alerts still work).
  mode: 'connected',

  // Optional override of the bundle location, relative to the HOST FILE (framework, hub or a
  // converted dashboard). Leave null to use the shell loader's default "chat/oati-genie-chat-widget.js".
  bundle: null,

  // Base origin of the real Rag API server — the app.int deployment (supplied 2026-09-01). This
  // SUPERSEDES the old dev host `http://aniketsa-d.dev.oati.local`, which is no longer used.
  // Cross-origin for fetch/CORS purposes, and now cross-SCHEME as well (the shell is served over
  // http from localhost, this is https — allowed as a sub-resource, the reverse is what browsers
  // block), so the Rag server must send Access-Control-Allow-Origin covering the host page's
  // origin AND answer the preflight OPTIONS that the shim's JSON POSTs trigger. No path here —
  // ragServerPath supplies the prefix.
  ragBaseUrl: 'https://app.int.oatihub.oati.com',

  // Path prefix this deployment mounts the Rag API under — every real Rag call is made at
  // `${ragBaseUrl}${ragServerPath}${path}` (see genie-rag-shim.js `ragUrl`). NOTE: the bundled
  // chat/openapi.json still declares the OLD dev deployment's `servers: [{ url: '/network_api' }]`;
  // app.int mounts the same API at '/genie/rag', so THIS key — not openapi.json — is the truth.
  // Adjust if your deployment differs.
  ragServerPath: '/genie/rag',

  // No auth/login yet. Every Conversations/Feedback call requires a UserMetadata
  // {user_id, organization_id} — placeholders until real values exist.
  userId: 1,
  organizationId: 1,

  // There is no GetGenieSettings API yet — the widget's feature-toggle defaults until one exists.
  // This is the ONLY place they are defined; swap handleGetGenieSettings() in genie-rag-shim.js
  // for a real fetch once a settings endpoint exists.
  settings: {
    EnableChannels: true,
    // Desk tab visible — the shell pushes unacknowledged alarms / degraded systems into it
    // (WV.genie.desk); Genie's Desk still has no backend of its own.
    HideGenieDesk: false,
    EnableFeedbackIcons: true, // POST /UserFeedback is real
    FeedbackOptions: [
      { Label: 'Inaccurate', Value: 'Inaccurate' },
      { Label: 'Not helpful', Value: 'NotHelpful' },
    ],
    InitialMessages: 'Ask me about outages, reports, and capacity margins.',
    SearchAgentLabel: 'Genie',
    EnableSearchOptions: false,
    EnableSpeechRecognition: false,
    // The Rag API DOES support file attachments (UserPromptRequest.files) — flip this on later
    // if you want the composer's attachment button; the shim already sends `files: []`.
    PromptAttachment: { EnableAttachment: false },
    // No outage-filtering-equivalent endpoint in the new API — keep type-ahead suggestions off.
    AutoSuggestion: { IsEnabled: false },
  },

  // No channel API today — static list, verbatim from the org's known channels.
  channels: [
    { id: 'OATI', name: 'OATI', dataSource: ['oati'], environment: null, envColor: null, type: 'General', isDefault: true },
    { id: 'Energy_Atlas', name: 'Energy Atlas', dataSource: ['energy_public'], environment: null, envColor: null, type: 'General', isDefault: false },
    { id: '60b8fba6fc3ae24d4b177b36', name: 'webSmartTag', dataSource: ['websmarttag_20'], environment: null, envColor: null, type: 'Application', isDefault: false },
    { id: '60b8fc6bfc3ae24d4b177d98', name: 'webSmartOASIS', dataSource: ['websmartoasis_10'], environment: null, envColor: null, type: 'Application', isDefault: false },
    { id: '6487494f6e0940d89ec59a3d', name: 'INTHUB_Test', dataSource: [''], environment: null, envColor: null, type: 'Application', isDefault: false },
    { id: '64d402c822055533b89b481e', name: 'webTrader', dataSource: ['webtrader_90'], environment: null, envColor: null, type: 'Application', isDefault: false },
    { id: '68e5952a792757d2d7c306e1', name: 'webSettlement', dataSource: ['websettlement_550'], environment: null, envColor: null, type: 'Application', isDefault: false },
    { id: '69c586f08d056fbca05c28af', name: 'Latest10_SSDT_Visiondev', dataSource: [''], environment: null, envColor: null, type: 'Application', isDefault: false },
    { id: '6a8d5ebaed1f5e3951b4851d', name: 'webSEEM', dataSource: [''], environment: null, envColor: null, type: 'Application', isDefault: false },
  ],

  // Widget persistence namespace (theme / motion / preferences / chatState live under
  // `${persistenceKey}:*` in localStorage). null → the shell derives "wvfw.<app-id>.genie" so
  // every converted file keeps its own widget state, like every other shell preference.
  persistenceKey: null,

  // Branding + geometry defaults handed to the element. position = {right, bottom} px offsets of
  // the floating panel; dimensions = {width, height} px. null → the bundle's own defaults
  // (16/16 and 884×800). The shell default lifts the panel clear of its 26 px status bar.
  title: 'Genie',
  description: null,
  position: { right: 16, bottom: 36 },
  dimensions: null,
};
