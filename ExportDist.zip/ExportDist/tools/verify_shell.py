# -*- coding: utf-8 -*-
"""verify_shell.py — end-to-end regression of EVERY Genie webVision Shell feature on any shell-integrated URL.

Usage (venv: C:/Users/bkkom/.venv/Scripts/python.exe, PYTHONIOENCODING=utf-8, server: serve_genie.py on :8890):
  python tools\\verify_shell.py                      # default set: framework (deep) + hub (deep) + every dashboards/*_wv*.html (smoke) + hub file://
  python tools\\verify_shell.py --url http://localhost:8890/GenieApplicationShell.html   # one URL, deep
  python tools\\verify_shell.py --url <dashboard url> --smoke                             # boot smoke only
  python tools\\verify_shell.py --only "voice|alarms"  # feature filter (regex on the feature name)
  python tools\\verify_shell.py --shots <dir> --headed --json <report.json>

Error policy (STRICT, whole run, page + every frame + every popup window):
  * zero `pageerror`
  * `console.error` tolerated ONLY for (a) Chrome's /favicon.ico probe, (b) network errors to any RAG host
    named in chat/genie-config.js (RAG_HOSTS, parsed at import), (c) the chat loader's DESIGNED probe: one 404 on `chat/genie-config.js`
    when the file then resolves chat/ one level up (GWID.base === "../"; asserted per page).
Every other console.error fails the run's gate for that file.

Hub-specific checks run when window.WV_HUB_STATS exists; framework-only checks (sample product renderers)
run when the sample product is registered. Product frames inside the hub are exercised through the embed
protocol (theme / time / prefs / info messages) and the 1.7.1 embed guard.
"""
import argparse, json, os, pathlib, re, sys, time, traceback
from playwright.sync_api import sync_playwright, Error as PWError

# serve_genie.py on :8890; WV_BASE overrides for a different port.
import os as _os_env
BASE = _os_env.environ.get("WV_BASE", "http://localhost:8890/")
if not BASE.endswith("/"): BASE += "/"
# the tree is wherever THIS FILE lives, not a machine-specific path.
HOME = pathlib.Path(__file__).resolve().parents[1]
# The chat widget calls a RAG deployment normally unreachable from a dev box; its network errors
# are tolerated. PARSED from the config rather than hardcoded - that host has already moved once
# (dev box -> app.int.oatihub), and a stale literal would quietly stop tolerating the host that is
# actually called while tolerating one nothing calls. The legacy name stays as a fallback.
_cfg = HOME / "chat" / "genie-config.js"
RAG_HOSTS = sorted({m.group(1) for m in re.finditer(r"https?://([A-Za-z0-9.\-]+)",
                    _cfg.read_text(encoding="utf-8") if _cfg.exists() else "")}
                   | {"aniketsa-d.dev.oati.local"})
# the living release's stamp — every file under test must embed exactly this shell (framework, hub, dashboards)
FW_VER = re.search(r'<meta name="wv-shell-version" content="([^"]+)">', (HOME / "GenieApplicationShell.html").read_text(encoding="utf-8")).group(1)
# 2026-09-05 — the dashboard rows are DISCOVERED from dashboards/*_wv*.html (minus *pre-*
# backups); the label is the file stem, so a new dashboard is gated the moment it is added.
import glob as _glob, os as _os
_files = sorted(str(q) for d in ("dashboards", "reference")
                for q in (HOME / d).glob("*_wv*.html"))
_files = [f for f in _files if "pre-" not in _os.path.basename(f)]
DEFAULT_SET = ([
    ("framework", BASE + "GenieApplicationShell.html", "deep"),
    ("hub", BASE + "index.html", "deep"),
] + [(_os.path.basename(f).split("_wv")[0][:14], BASE + _os.path.basename(_os.path.dirname(f)) + "/" + _os.path.basename(f), "smoke")
     for f in _files]
  + [("hub-file", (HOME / "index.html").as_uri(), "file")])

# ------------------------------------------------------------------ harness
class Run:
    def __init__(self, label, url, mode, shots, headed, only):
        self.label, self.url, self.mode, self.shots, self.headed = label, url, mode, shots, headed
        self.only = re.compile(only, re.I) if only else None
        self.tally = {}          # feature -> [pass, fail]
        self.fails = []          # (feature, check, note)
        self.errs = []           # pageerror strings (any page/frame)
        self.cons = []           # {text,url,page,ok}
        self.feature = "boot"
        self.pages = []
        self.probe404 = []       # pages that logged the designed loader probe 404

    def chk(self, ok, name, note=""):
        t = self.tally.setdefault(self.feature, [0, 0])
        ok = bool(ok)
        t[0 if ok else 1] += 1
        line = ("  PASS " if ok else "  FAIL ") + name + ((" — " + str(note)[:300]) if note else "")
        print(line, flush=True)
        if not ok:
            self.fails.append((self.feature, name, str(note)[:400]))
        return ok

    def tolerated(self, m, page_url):
        loc = m.location or {}
        url, text = loc.get("url", ""), m.text
        if "favicon.ico" in url or "favicon.ico" in text: return True
        if any(h and (h in url or h in text) for h in RAG_HOSTS): return True
        if "Failed to load resource" in text and url.endswith("chat/genie-config.js") and "404" in text:
            self.probe404.append(page_url); return True   # designed probe — validated later against GWID.base
        return False

    def attach(self, pg):
        self.pages.append(pg)
        pg.on("pageerror", lambda e: self.errs.append("[%s] %s" % (pg.url[-60:], str(e)[:300])))
        def on_console(m):
            if m.type == "error":
                self.cons.append({"text": m.text[:300], "url": (m.location or {}).get("url", ""), "page": pg.url[-60:],
                                  "ok": self.tolerated(m, pg.url)})
        pg.on("console", on_console)

    def want(self, name):
        return self.only is None or self.only.search(name)

# ------------------------------------------------------------------ small helpers
def login(pg, remember=None, variant=None):
    # 60 s, not 30: in the HUB a fresh load re-mounts product frames, and this runs late in a long
    # session with several contexts alive. The assertion is unchanged - only the patience is.
    pg.wait_for_selector("#wv-la-u", state="attached", timeout=60000)
    if variant:
        pg.evaluate("v=>{const b=document.querySelector('#wv-lvSwitch [data-wv-act=lv][data-v='+v+']');b&&b.click()}", variant)
    if remember is not None:
        pg.evaluate("r=>{const f=document.querySelector('form[data-wv-login]');const c=f&&f.querySelector('input[type=checkbox]');if(c)c.checked=!!r}", remember)
    pg.focus("#wv-la-u"); pg.keyboard.press("Enter")
    pg.wait_for_function("document.body.dataset.in==='1'", timeout=30000)

def J(pg, js, *args):  # evaluate helper (a failing expression is named in the log)
    try: return pg.evaluate(js, *args) if args else pg.evaluate(js)
    except Exception as e:
        print("  J-FAIL " + " ".join(js[:220].split()) + " -> " + str(e)[:160]); raise

def wait(pg, js, timeout=15000):
    try:
        pg.wait_for_function(js, timeout=timeout); return True
    except PWError:
        return False

def widget_ready(pg, timeout=30000):
    return wait(pg, "!!window.__GENIE_WIDGET__ && !!document.querySelector('oati-genie-chat-widget')", timeout)

def is_open(pg):
    return J(pg, "!!(window.__GENIE_WIDGET__&&window.__GENIE_WIDGET__.getState().isOpen)")

def hub_frame(pg, pid=None):
    for f in pg.frames:
        if "wv-embed" in f.url and (pid is None or f.url.split("#")[0].endswith(J(pg, "p=>WV_HUB_FILES[p]", pid))):
            return f
    return None

def wait_hub_ready(pg, n=1, timeout=45000):
    return wait(pg, "WV_HUB_STATS.ready>=%d && [...WV_HUB_LIVE.values()].every(r=>r.ready)" % n, timeout)

def frame_info_target(pg, f):
    """The smallest BOUNDED stamped region in a frame, or None if it only has containers.

    A click lands on an element's centre. For a full-view container that centre is whatever
    sits in the middle - in a frame-of-frames product (der: hub -> product -> about:srcdoc
    per sub-dashboard) that is the INNER document, so the click never reaches the product and
    no pin can take. Only a bounded region answers the gesture the check is about."""
    loc = f.locator("[data-wv-product-root] [data-info]:visible")
    best, idx = None, None
    for i in range(min(loc.count(), 40)):
        box = loc.nth(i).bounding_box()
        if not box: continue
        area = box["width"] * box["height"]
        if 400 < area < 300000 and (best is None or area < best):
            best, idx = area, i
    return (loc, idx, best)

def hub_switch(pg, pid):  # the lockup-dropdown path (product home opens); WV_HUB_SWITCH is the openView-driven variant
    J(pg, "p=>{if(S.product!==p){S.product=p;S.lastMenuSync=mktNow();prefChanged()}}", pid)

def views_of_product(pg, n=6):
    return J(pg, "n=>visibleCatalog().filter(v=>!isFrameworkView(v)&&v.openMode==='inline').slice(0,n).map(v=>v.id)", n)

def close_all(pg):
    J(pg, "for(const i of S.open.slice())closeInst(i.uid); S.popouts.forEach(p=>{try{p.win.close()}catch(e){}}); S.popouts=[]; renderAll()")

# ================================================================== FEATURES (deep)
def f_boot(R, pg, ctx):
    R.feature = "boot+login"
    pg.goto(R.url); pg.wait_for_selector("#wv-la-u", state="attached", timeout=30000)
    stamp = J(pg, "(document.querySelector('meta[name=wv-shell-version]')||{}).content")
    R.chk(stamp == FW_VER, "shell version stamp = framework (%s)" % FW_VER, stamp)
    R.chk(J(pg, "getComputedStyle(document.querySelector('#wv-login')).display!=='none' && document.body.dataset.in!=='1'"), "login page shows first")
    fav = J(pg, "((document.querySelector('link[rel=icon]'))||{}).href||''")
    R.chk(fav.startswith("data:image/svg+xml,"), "the tab icon is the genie mark, inlined as a data URI (1.11.5 — no asset to ship, works over file://)", fav[:48])
    R.chk("wv-genie-grad" in fav and "stop-color" in fav, "…carrying the mark's own gradient, so the icon cannot drift from the lamp")
    R.chk("--wv-mark-fill" not in fav, "…with no CSS variable left in it (a favicon document has none)")
    # variants A–D + background art switch
    for v in ["b", "c", "d", "a"]:
        J(pg, "v=>document.querySelector('#wv-lvSwitch [data-wv-act=lv][data-v='+v+']').click()", v)
        R.chk(J(pg, "document.querySelector('#wv-login').dataset.variant") == v, "login variant %s selected" % v.upper())
    J(pg, "document.querySelector('#wv-lvSwitch [data-wv-act=lvbg][data-v=c]').click()")
    R.chk(J(pg, "document.querySelector('#wv-login').dataset.bgart==='c' && store.get('loginBg')==='c'"), "login background art switch persists")
    J(pg, "document.querySelector('#wv-lvSwitch [data-wv-act=lvbg][data-v=p]').click()")
    R.chk(J(pg, "document.querySelector('oati-genie-chat-widget')===null"), "chat widget NOT mounted before sign-in")
    # variant D role pick + eye toggle
    J(pg, "document.querySelector('#wv-lvSwitch [data-wv-act=lv][data-v=d]').click()")
    J(pg, "(document.querySelectorAll('[data-wv-act=ld-role]')[1]||{}).click&&document.querySelectorAll('[data-wv-act=ld-role]')[1].click()")
    R.chk(J(pg, "[...document.querySelectorAll('[data-wv-act=ld-role]')].filter(r=>r.classList.contains('wv-on')).length===1"), "variant D role radio: exactly one selected")
    J(pg, "document.querySelector('[data-wv-act=ld-eye]').click()")
    R.chk(J(pg, "document.querySelector('#wv-ld-p').type==='text'"), "variant D password eye reveals")
    J(pg, "document.querySelector('#wv-lvSwitch [data-wv-act=lv][data-v=a]').click()")
    # sign in (remember me OFF → tab session)
    login(pg, remember=False)
    R.chk(J(pg, "document.body.dataset.in==='1' && getComputedStyle(document.querySelector('#wv-app')).display!=='none'"), "Enter on #wv-la-u signs in → app visible")
    # A KNOWN read scope for everything that follows. A host file may ship either default (the hub
    # demo build ships Local), and since 1.12.6 opening a display RE-APPLIES that default - so a
    # per-check setGreadScope() would be undone by the next openView. Pin the PREFERENCE, and record
    # what the file actually ships so the choice stays visible rather than silently normalised away.
    shipped_scope = J(pg, "PREF_DEFAULTS.greadDefault")
    R.chk(shipped_scope in ("global", "view"),
          "this file ships read scope default: %s (%s)" % (shipped_scope, "Local" if shipped_scope == "view" else "Global"))
    J(pg, "S.greadDefault='global';setGreadScope('global')")  # the checks below test GLOBAL-scope behaviour deliberately
    R.chk(J(pg, "!!sessionStorage.getItem(AUTH.KEY) && !localStorage.getItem(AUTH.KEY)"), "tab session stored in sessionStorage (remember off)")
    R.chk(J(pg, "S.user.name==='GenieUser' && S.user.initials==='GU' && $('#wv-uName').textContent==='GenieUser'"), "typed username becomes the identity (GenieUser → GU)")
    ok = wait(pg, "$('#wv-gbSay').classList.contains('wv-show') && /GenieUser/.test($('#wv-gbSay').textContent)", 6000)
    R.chk(ok, "native login greeting blooms on the island with the user's name", J(pg, "$('#wv-gbSay').textContent.trim().slice(0,80)"))
    R.chk(J(pg, "VOICE.greeted===true"), "greeting marks VOICE.greeted")
    title = J(pg, "document.title")
    R.chk(title.startswith("OATI "), "tab title = 'OATI <product>' after sign-in (1.7.4)", title)
    R.chk(J(pg, "(()=>{const r=id=>document.getElementById(id).getBoundingClientRect().left;return r('wv-podGenie')<r('wv-podStatus')&&r('wv-podStatus')<r('wv-podInfo')&&r('wv-podInfo')<r('wv-podSession')})()"),
          "header geometry genie < status < info < session (1.7.3)")
    R.chk(widget_ready(pg), "OATI Genie chat component mounts after sign-in (1.8.0)")
    R.chk(J(pg, "(()=>{const e=document.querySelector('oati-genie-chat-widget');return e&&e.getAttribute('enable-launcher')==='false'&&e.getAttribute('persistence-key')==='wvfw.'+WVNS+'.genie'&&e.hasAttribute('data-wv-i18n-off')})()"),
          "widget attributes (launcher off, persistence-key wvfw.<ns>.genie, i18n-off)")

def f_launchpad(R, pg):
    R.feature = "launchpad+favorites+recents"
    close_all(pg)
    R.chk(J(pg, "!!document.querySelector('#wv-panels .wv-lp') && /GenieUser/.test($('#wv-panels .wv-wl-title').textContent)"), "empty workspace renders the launchpad with a greeting")
    vids = views_of_product(pg, 3)
    if not vids: R.chk(False, "catalog has inline views"); return
    J(pg, "id=>{S.favorites.add(id);persist();renderAll()}", vids[0])
    R.chk(J(pg, "id=>!!document.querySelector('#wv-panels .wv-lp-card.wv-c-am [data-id=\"'+id+'\"], #wv-panels .wv-lp-card.wv-c-am .wv-vrow')", vids[0]), "favorite lands in the launchpad Favorites card")
    J(pg, "id=>openView(id)", vids[1]); pg.wait_for_timeout(300); close_all(pg)
    R.chk(J(pg, "id=>S.recents[0]===id && !!document.querySelector('#wv-panels .wv-lp-card.wv-c-cy .wv-vrow')", vids[1]), "opened view queues in Recents card")
    J(pg, "document.querySelector('#wv-panels .wv-lp-search').click()")
    R.chk(J(pg, "$('#wv-palette').classList.contains('wv-open')"), "launchpad search button opens the palette")
    J(pg, "closePalette()")
    # sidebar favorites/recents tabs
    for t in ["fav", "recent", "openv", "browse"]:
        J(pg, "t=>{S.sbTab=t;document.body.dataset.side='max';renderSidebar()}", t)
        R.chk(J(pg, "t=>[...document.querySelectorAll('#wv-sidebar .wv-sb-tab')].find(b=>b.dataset.t===t).classList.contains('wv-on') && $('#wv-sbBody').innerHTML.length>20", t), "sidebar tab '%s' renders" % t)
    R.chk(J(pg, "!!document.querySelector('#wv-sbBody .wv-vrow')||/No favorites/.test($('#wv-sbBody').textContent)"), "sidebar browse tree renders rows")
    # 1.10.13 — selection states: edge-bar + soft-chip rail (min), underline + count-pill tabs (expanded)
    J(pg, "S.sbTab='fav';document.body.dataset.side='max';renderSidebar()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "(()=>{const t=document.querySelector('#wv-sidebar .wv-sb-tab.wv-on');const u=getComputedStyle(t,'::after');return u.height==='2px'&&parseFloat(u.width)>20})()"), "active tab carries the 2px underline (1.10.13)")
    R.chk(J(pg, "(()=>{const c=document.querySelector('#wv-sidebar .wv-sb-tab.wv-on .wv-sb-ct')||document.querySelector('#wv-sidebar .wv-sb-ct');if(!c||!c.textContent)return true;const s=getComputedStyle(c);return s.borderRadius.includes('999')&&s.fontFamily.toLowerCase().includes('mono')})()"), "count renders as a mono pill")
    J(pg, "document.body.dataset.side='min';renderSidebar();positionRailPucks()"); pg.wait_for_timeout(500)
    R.chk(J(pg, "(()=>{const p=document.querySelector('#wv-sidebar .wv-sb-tabs .wv-railpuck');if(!p)return false;const s=getComputedStyle(p),b=getComputedStyle(p,'::before');return s.backgroundImage==='none'&&b.width==='3px'&&parseFloat(b.height)>=16})()"), "min rail: soft chip + 3px edge bar, no solid fill (1.10.13)")
    R.chk(J(pg, "(()=>{const acc=getComputedStyle(document.documentElement).getPropertyValue('--wv-acc').trim();const el=document.querySelector('#wv-sidebar .wv-sb-tab.wv-on');const c=getComputedStyle(el).color;const h=acc.length===7?'rgb('+parseInt(acc.slice(1,3),16)+', '+parseInt(acc.slice(3,5),16)+', '+parseInt(acc.slice(5,7),16)+')':acc;return c===h})()"), "min rail: active glyph is the accent, not ink-on-fill")
    J(pg, "document.body.dataset.side='max';S.sbTab='browse';renderSidebar()")
    J(pg, "id=>{S.favorites.delete(id);persist();renderAll()}", vids[0])

def f_palette(R, pg, ctx):
    R.feature = "command palette"
    close_all(pg)
    pg.keyboard.press("Control+k"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-palette').classList.contains('wv-open') && document.activeElement.id==='wv-palInput'"), "Ctrl+K opens the palette with focus in the input")
    n_all = J(pg, "visibleCatalog().length")
    R.chk(J(pg, "+$('#wv-cntAll').textContent") == n_all, "All-views count = visibleCatalog()", n_all)
    if J(pg, "PRODUCTS.length>1"):
        R.chk(J(pg, "visibleCatalog().every(v=>v.product===S.product||isFrameworkView(v))"), "catalog scoped to the active product + framework views (1.7.2)")
    vname = J(pg, "visibleCatalog().find(v=>!isFrameworkView(v)).name")
    pg.fill("#wv-palInput", vname[:5]); pg.wait_for_timeout(150)
    R.chk(J(pg, "n=>[...document.querySelectorAll('#wv-palResults .wv-pr-row:not(.wv-pr-act) .wv-pr-name')].some(e=>e.textContent.toLowerCase().includes(n.toLowerCase()))", vname[:5]), "typing filters views (name match highlighted)")
    pg.fill("#wv-palInput", "theme"); pg.wait_for_timeout(150)
    R.chk(J(pg, "!!document.querySelector('#wv-palResults .wv-pr-act[data-aid=\"act:theme\"]')"), "actions band lists 'Toggle theme' for query 'theme'")
    th0 = J(pg, "S.theme")
    J(pg, "document.querySelector('#wv-palResults .wv-pr-act[data-aid=\"act:theme\"]').click()"); pg.wait_for_timeout(150)
    R.chk(J(pg, "S.theme") != th0 and not J(pg, "$('#wv-palette').classList.contains('wv-open')"), "running an action applies it and closes the palette")
    J(pg, "S.theme='dark';prefChanged()")
    pg.keyboard.press("Control+k"); pg.fill("#wv-palInput", ""); pg.wait_for_timeout(120)
    R.chk(J(pg, "!!document.querySelector('#wv-palResults .wv-pr-sec') && /Recent/.test($('#wv-palResults').textContent)"), "empty query shows the Recent commands band")
    for t in ["fav", "recent", "openv", "all"]:
        J(pg, "t=>document.querySelector('#wv-palTabs [data-t='+t+']').click()", t)
        R.chk(J(pg, "t=>pal.openTab===t && document.querySelector('#wv-palTabs [data-t='+t+']').classList.contains('wv-on')", t), "palette tab '%s'" % t)
    pg.fill("#wv-palInput", vname); pg.wait_for_timeout(150)
    J(pg, "pal.sel=Math.max(0,pal.items.findIndex(it=>it.kind==='view'));renderPalette()")  # the actions band may rank above the view for this query
    pg.keyboard.press("Enter"); pg.wait_for_timeout(400)
    R.chk(J(pg, "n=>S.open.length===1 && view(S.open[0].viewId).name===n && !$('#wv-palette').classList.contains('wv-open')", vname), "Enter opens the selected view inline")
    # Shift+Enter → popout window
    pg.keyboard.press("Control+k"); pg.fill("#wv-palInput", vname); pg.wait_for_timeout(150)
    J(pg, "pal.sel=Math.max(0,pal.items.findIndex(it=>it.kind==='view'));renderPalette()")
    with ctx.expect_page(timeout=15000) as pi:
        pg.keyboard.press("Shift+Enter")
    pop = pi.value; R.attach(pop)
    R.chk(J(pg, "S.popouts.length===1"), "Shift+Enter opens the view in a popout window")
    pop.wait_for_load_state(); wait(pg, "S.popouts[0]&&S.popouts[0].ready", 20000)
    R.chk(J(pg, "S.popouts[0].ready===true"), "popout reports {wv:'ready'}")
    J(pg, "popClose(S.popouts[0].uid)"); pg.wait_for_timeout(300)
    pg.keyboard.press("Escape"); close_all(pg)

def f_nav(R, pg):
    R.feature = "sidebar nav + mega menus"
    J(pg, "S.navMode='v';prefChanged();document.body.dataset.side='max';S.sbTab='browse';renderSidebar()")
    R.chk(J(pg, "document.body.dataset.navmode==='v' && !!document.querySelector('#wv-treeRoot')"), "vertical sidebar renders the catalog tree")
    grp = J(pg, "(()=>{const g=document.querySelector('#wv-treeRoot [data-wv-act=g-toggle]');return g?g.dataset.path:null})()")
    if grp:
        before = J(pg, "p=>S.treeOpen.has(p)", grp)
        J(pg, "p=>document.querySelector('#wv-treeRoot [data-wv-act=g-toggle][data-path=\"'+p+'\"]').click()", grp)
        R.chk(J(pg, "p=>S.treeOpen.has(p)", grp) != before, "group toggle collapses/expands a tree group")
        J(pg, "p=>document.querySelector('#wv-treeRoot [data-wv-act=g-toggle][data-path=\"'+p+'\"]').click()", grp)
    pg.fill("#wv-sbFilter", "zzzz-nomatch"); pg.wait_for_timeout(100)
    R.chk(J(pg, "/No matches/.test($('#wv-treeRoot').textContent)"), "sidebar filter: no-match note")
    pg.fill("#wv-sbFilter", ""); pg.wait_for_timeout(100)
    pg.keyboard.press("Control+b"); pg.wait_for_timeout(150)
    R.chk(J(pg, "document.body.dataset.side==='min' && !!document.querySelector('#wv-sbBody .wv-rail')"), "Ctrl+B collapses the sidebar to the quick-launch rail")
    pg.keyboard.press("Control+b"); pg.wait_for_timeout(150)
    R.chk(J(pg, "document.body.dataset.side==='max'"), "Ctrl+B expands it back")
    J(pg, "document.querySelector('#wv-navModeBtn').click()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "S.navMode==='h' && document.body.dataset.navmode==='h' && document.querySelectorAll('#wv-hnav .wv-hn-item').length>0"), "orientation toggle → horizontal menu bar with groups")
    J(pg, "document.querySelector('#wv-hnav .wv-hn-item').click()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-mega').classList.contains('wv-open') && document.querySelectorAll('#wv-mega .wv-vrow').length>0"), "mega menu opens with view rows")
    if J(pg, "!!document.querySelector('#wv-mega [data-wv-act=mega-openall]')"):
        J(pg, "document.querySelector('#wv-mega [data-wv-act=mega-openall]').click()"); pg.wait_for_timeout(500)
        R.chk(J(pg, "S.open.length>=1 && !$('#wv-mega').classList.contains('wv-open')"), "'Open all' opens the column's views and closes the mega menu", J(pg, "S.open.length"))
        close_all(pg)
    else:
        J(pg, "closeMega()")
    J(pg, "document.querySelector('#wv-hnav .wv-hn-item').click()"); pg.keyboard.press("Escape")
    R.chk(J(pg, "!$('#wv-mega').classList.contains('wv-open')"), "Esc closes the mega menu")
    J(pg, "S.navMode='v';prefChanged()")

def f_views(R, pg):
    R.feature = "views: open/close/cycle/pin/maximize + layouts"
    close_all(pg)
    vids = views_of_product(pg, 6)
    cap = J(pg, "LAYOUT_CAP")
    if len(vids) < 2: R.chk(False, "need ≥2 inline views", vids); return
    for v in vids[:3]: J(pg, "id=>openView(id)", v)
    pg.wait_for_timeout(400)
    R.chk(J(pg, "S.open.length===3 && document.querySelectorAll('#wv-panels .wv-panel[data-uid]').length===3 && document.querySelectorAll('#wv-tabstrip .wv-tab').length===3"), "3 views open → 3 panels + 3 tabs")
    R.chk(J(pg, "id=>{openView(id);return S.open.length===3}", vids[0]), "re-opening an open view activates it (no duplicate)")
    R.chk(J(pg, "id=>{openView(id,{forceNew:true});return S.open.length===4&&S.open[3].inst===2}", vids[0]), "forceNew opens a second instance (#2)")
    J(pg, "closeInst(S.open[3].uid)")
    a0 = J(pg, "S.activeUid")
    pg.keyboard.press("Alt+ArrowRight"); pg.wait_for_timeout(100)
    R.chk(J(pg, "S.activeUid") != a0, "Alt+→ cycles the active view")
    pg.keyboard.press("Alt+ArrowLeft"); pg.wait_for_timeout(100)
    R.chk(J(pg, "S.activeUid") == a0, "Alt+← cycles back")
    pg.keyboard.press("Alt+3"); pg.wait_for_timeout(100)
    R.chk(J(pg, "S.activeUid===S.open[2].uid"), "Alt+3 activates the third view")
    J(pg, "document.querySelector('#wv-panels .wv-panel [data-wv-act=v-pin]').click()")
    R.chk(J(pg, "S.open.some(i=>i.pinned)"), "panel pin toggles pinned")
    J(pg, "document.querySelector('#wv-panels .wv-panel [data-wv-act=panel-max]').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "!!S.maximizedUid && $('#wv-panels').classList.contains('wv-maxed')"), "maximize overlays one panel")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(100)
    R.chk(J(pg, "!S.maximizedUid && !$('#wv-panels').classList.contains('wv-maxed')"), "Esc restores the arrangement")
    for v in vids[3:]: J(pg, "id=>openView(id)", v)
    n = J(pg, "S.open.length")
    for lay in ["tabs", "split", "mainside", "cols3", "grid", "grid6"]:
        J(pg, "l=>{S.layout=l;S.maximizedUid=null;renderTabs();renderPanels()}", lay)
        vis = J(pg, "visibleUids().length")
        R.chk(J(pg, "$('#wv-panels').dataset.layout") == lay and vis == min(n, cap.get(lay, 1)), "layout '%s' shows %d visible panel(s)" % (lay, min(n, cap.get(lay, 1))), vis)
    J(pg, "document.querySelector('#wv-layBtn').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-drop').classList.contains('wv-open') && document.querySelectorAll('#wv-drop [data-wv-act=layout]').length>=6"), "arrangement picker lists the 6 layouts")
    J(pg, "document.querySelector('#wv-drop [data-wv-act=layout][data-l=split]').click()")
    R.chk(J(pg, "S.layout==='split'"), "picking an arrangement applies it")
    # under-filled arrangements collapse to the visible count (1.8.9 fix: one view in 'split' filled half the display)
    keep = J(pg, "S.open[0].uid"); J(pg, "u=>{for(const i of S.open.slice())if(i.uid!==u)closeInst(i.uid)}", keep)
    for lay in ["split", "mainside", "cols3", "grid", "grid6"]:
        J(pg, "l=>{S.layout=l;renderTabs();renderPanels()}", lay)
        R.chk(J(pg, "(()=>{const p=document.querySelector('#wv-panels .wv-panel[data-uid]'),g=$('#wv-panels');return g.dataset.n==='1'&&Math.abs(p.getBoundingClientRect().width-g.clientWidth)<24})()"), "one view in '%s' fills the whole display" % lay, J(pg, "[$('#wv-panels').dataset.n,document.querySelector('#wv-panels .wv-panel[data-uid]').getBoundingClientRect().width,$('#wv-panels').clientWidth]"))
    for v in vids[1:]: J(pg, "id=>openView(id)", v)
    J(pg, "S.layout='split';renderTabs();renderPanels()")
    # tab context menu + close others/right/all
    uid = J(pg, "S.open[0].uid")
    J(pg, "u=>menuTabCtx(200,200,u)", uid)
    R.chk(J(pg, "!!document.querySelector('#wv-drop [data-wv-act=ctx-close-others]')"), "tab context menu offers Close others / right / all")
    J(pg, "document.querySelector('#wv-drop [data-wv-act=ctx-close-all]').click()"); pg.wait_for_timeout(150)
    R.chk(J(pg, "S.open.length===S.open.filter(i=>i.pinned).length"), "Close all keeps pinned views", J(pg, "S.open.length"))
    # content states (fw-state) on a sample renderer
    if J(pg, "S.open.length"):
        J(pg, "S.open.forEach(i=>i.pinned=false)")
        u = J(pg, "S.open[0].uid")
        for st in ["loading", "empty", "error", "ready"]:
            J(pg, "([u,s])=>{const i=inst(u);i.state=s;renderPanels()}", [u, st])
            R.chk(J(pg, "u=>inst(u).state", u) == st and J(pg, "!!document.querySelector('#wv-panels .wv-panel[data-uid=\"%s\"] [data-vb]')" % u), "content state '%s' renders" % st)
        J(pg, "u=>{const i=inst(u);i.state='ready';renderPanels()}", u)
    close_all(pg)

def f_workspaces(R, pg):
    R.feature = "workspaces + session resume"
    close_all(pg)
    vids = views_of_product(pg, 2)
    for v in vids: J(pg, "id=>openView(id)", v)
    J(pg, "S.layout='split';renderTabs();renderPanels()")
    J(pg, "saveWsModal()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-modal').classList.contains('wv-open') && !!document.querySelector('#wv-wsName')"), "Save workspace modal opens")
    pg.fill("#wv-wsName", "E2E Verify WS"); J(pg, "document.querySelector('[data-wv-act=ws-save-do]').click()")
    ws = J(pg, "S.workspaces.find(w=>w.name==='E2E Verify WS')")
    R.chk(ws and ws["views"] and ws["layout"] == "split" and ws.get("user") == 1, "saved workspace captures views + arrangement (user ws)", ws)
    R.chk(J(pg, "store.get('userWs',[]).some(w=>w.name==='E2E Verify WS')"), "user workspace persisted")
    close_all(pg)
    J(pg, "id=>loadWs(id)", ws["id"]); pg.wait_for_timeout(300)
    R.chk(J(pg, "n=>S.open.length===n && S.layout==='split'", len(ws["views"])), "loadWs reopens its views + layout")
    J(pg, "document.querySelector('#wv-wsBtn').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "document.querySelectorAll('#wv-drop [data-wv-act=ws-load]').length===S.workspaces.length && !!document.querySelector('#wv-drop [data-wv-act=ws-manage]')"), "workspaces menu lists every workspace + manage")
    J(pg, "id=>document.querySelector('#wv-drop [data-wv-act=ws-startup][data-id=\"'+id+'\"]').click()", ws["id"])
    R.chk(J(pg, "S.startupWs") == ws["id"] and J(pg, "store.get('startupWs')") == ws["id"], "startup pointer set + persisted")
    J(pg, "renderWsComposer()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-modal').classList.contains('wv-open') && !!document.querySelector('.wv-wsc-name')"), "composer opens with editable user workspace")
    J(pg, "id=>{const i=document.querySelector('.wv-wsc-name[data-wsid=\"'+id+'\"]');i.value='E2E Renamed';i.dispatchEvent(new Event('change',{bubbles:true}))}", ws["id"])
    R.chk(J(pg, "id=>S.workspaces.find(w=>w.id===id).name", ws["id"]) == "E2E Renamed", "rename via composer")
    J(pg, "id=>document.querySelector('[data-wv-act=wsc-dup][data-id=\"'+id+'\"]').click()", ws["id"])
    R.chk(J(pg, "S.workspaces.some(w=>w.name==='E2E Renamed (copy)')"), "duplicate creates '(copy)'")
    J(pg, "id=>document.querySelector('[data-wv-act=wsc-rmview][data-id=\"'+id+'\"]').click()", ws["id"])
    R.chk(J(pg, "([id,n])=>S.workspaces.find(w=>w.id===id).views.length===n-1", [ws["id"], len(ws["views"])]), "trim a view from a user workspace")
    dup = J(pg, "S.workspaces.find(w=>w.name==='E2E Renamed (copy)').id")
    for wid in [dup, ws["id"]]:
        J(pg, "id=>document.querySelector('[data-wv-act=wsc-del][data-id=\"'+id+'\"]').click()", wid)
    R.chk(J(pg, "!S.workspaces.some(w=>/E2E/.test(w.name))"), "delete removes both user workspaces")
    R.chk(J(pg, "id=>S.startupWs!==id && !!S.startupWs", ws["id"]), "startup pointer self-heals after deleting its target", J(pg, "S.startupWs"))
    J(pg, "closeModal()")
    # resume session: reopen views, reload → restored silently
    close_all(pg)
    for v in vids: J(pg, "id=>openView(id)", v)
    J(pg, "S.layout='split';S.resumeSession=true;prefChanged();scheduleSessionSave()"); pg.wait_for_timeout(800)
    R.chk(J(pg, "(store.get('session')||{}).views.length===S.open.length"), "session shape persisted (debounced)")
    pg.reload(); pg.wait_for_function("document.body.dataset.in==='1'", timeout=30000); pg.wait_for_timeout(1200)
    R.chk(J(pg, "n=>S.open.length===n && S.layout==='split'", len(vids)), "refresh resumes the session (views + layout) without re-login (1.7.5)")
    pg.wait_for_timeout(1500)
    R.chk(J(pg, "!VOICE.greeted && !(/GenieUser/.test($('#wv-gbSay').textContent)&&$('#wv-gbSay').classList.contains('wv-show'))"), "resume is silent (no re-greet)")
    widget_ready(pg)
    close_all(pg)

def f_popouts(R, pg, ctx):
    R.feature = "popout windows"
    close_all(pg)
    vid = views_of_product(pg, 1)[0]
    with ctx.expect_page(timeout=15000) as pi:
        J(pg, "id=>popOut(id)", vid)
    pop = pi.value; R.attach(pop); pop.wait_for_load_state()
    ok = wait(pg, "S.popouts.length===1&&S.popouts[0].ready", 20000)
    R.chk(ok, "popout adopted (ready)")
    R.chk(J(pg, "+$('#wv-popCount').textContent===1"), "status bar Popouts count = 1")
    wait(pop, "document.body.classList.contains('wv-embed') && !!document.querySelector('#wv-embedRoot')", 15000)
    R.chk(J(pop, "document.body.classList.contains('wv-embed') && !!document.querySelector('#wv-embedRoot') && EMB.on"), "popout boots chromeless in embed mode")
    R.chk(re.search(r" — ", J(pop, "document.title")) is not None, "popout title '<view> — <product>' (1.7.4)", J(pop, "document.title"))
    # 1.9.0 — the popout carries Genie's Read (band=1), View scope, toggle; Global = the parent's relayed reads
    wait(pop, "document.body.dataset.wvBand==='1' && $('#wv-gread').classList.contains('wv-show')", 15000)
    R.chk(J(pop, "EMB.band===true && document.body.dataset.wvBand==='1' && $('#wv-gread').parentElement===document.body && $('#wv-gread').classList.contains('wv-show') && $('#wv-gread').getBoundingClientRect().bottom<=$('#wv-embedRoot').getBoundingClientRect().top+1"), "band=1 popout renders Genie's Read above the view (1.9.0)")
    R.chk(J(pop, "S.greadScope==='view' && $('#wv-gread').dataset.scope==='view' && !!document.querySelector('#wv-gread .wv-gr-scope') && document.querySelector('#wv-gread .wv-gr-sc[data-d=view]').classList.contains('wv-on')"), "popout scope defaults to View, toggle present")
    # NOTE: the popout runs its own copy of the sample product, and its feedGenieRead keeps
    # rewriting GREAD.data[P] from inside. It cannot be frozen from outside - the pending
    # setTimeout and the wv:time listener both captured the original function reference, so
    # rebinding the name changes nothing for them. The insight step below re-plants instead.
    J(pg, """WV.genieRead.set({product:S.product,reads:[{headline:"<b>Relayed</b> global read",cta:{label:"relay cta",run(){window.__relayCta=1}},insights:[{text:"relayed insight",act:{label:"relay act",run(){window.__relayAct=1}}}]}]})"""); pg.wait_for_timeout(400)
    J(pop, "document.querySelector('#wv-gread .wv-gr-sc[data-d=global]').click()")
    # Global in the popout is the FLEET - one read per dashboard - so the relayed read is not
    # necessarily the first row. Find it, then drive THAT row.
    J(pop, """(()=>{const rows=[...document.querySelectorAll('#wv-gread .wv-gr-row')];
        const i=rows.findIndex(r=>/Relayed/.test(r.textContent||''));
        if(i>0&&typeof GREAD==='object'){GREAD.ix=i;if(typeof renderGenieRead==='function')renderGenieRead()}})()""")
    pg.wait_for_timeout(400)
    R.chk(J(pop, """S.greadScope==='global' && [...document.querySelectorAll('#wv-gread .wv-gr-row,#wv-gread .wv-gr-head')]
        .some(e=>/Relayed/.test(e.textContent||''))"""),
          "Global in the popout = the parent's relayed reads, live on WV.genieRead.set ({wv:'gread'})",
          J(pop, "(document.querySelector('#wv-gread .wv-gr-head')||{}).textContent"))
    J(pop, """(()=>{const rows=[...document.querySelectorAll('#wv-gread .wv-gr-row')];
        const r=rows.find(x=>/Relayed/.test(x.textContent||''));
        const c=(r&&r.querySelector('[data-wv-act=gread-cta]'))||document.querySelector('#wv-gread [data-wv-act=gread-cta]');
        if(c)c.click()})()"""); pg.wait_for_timeout(300)
    R.chk(J(pg, "window.__relayCta===1"), "relayed cta runs in the parent ({wv:'gread-run'})")
    # The expansion lives in a SIBLING `.wv-gr-x`, rebuilt only when the row is (re-)expanded,
    # so it can still hold the PREVIOUS read's insights. Clicking blind clicked the sample
    # product's "Cedar Creek 138 at 97% loading" and called the relay proven. Drive the pane
    # until it belongs to the RELAYED read, then click that read's action.
    _ins = None
    for _try in range(4):
        # re-plant each time: the popout's own demo publisher may have replaced the fixture
        # between attempts, and it cannot be stopped from here.
        J(pg, """WV.genieRead.set({product:S.product,reads:[{headline:"<b>Relayed</b> global read",
            cta:{label:"relay cta",run(){window.__relayCta=1}},
            insights:[{text:"relayed insight",act:{label:"relay act",run(){window.__relayAct=1}}}]}]})""")
        pg.wait_for_timeout(300)
        _ins = J(pop, """(()=>{const x=document.querySelector('#wv-gread .wv-gr-x');
            if(x&&/relayed insight/i.test(x.textContent||'')){
              const a=x.querySelector('[data-wv-act=gread-run]');
              if(a){a.click();return (a.textContent||'').trim().slice(0,30)}}
            return null})()""")
        if _ins: break
        J(pop, "(()=>{const r=document.querySelector('#wv-gread .wv-gr-row');if(r)r.click()})()")
        pg.wait_for_timeout(450)
    pg.wait_for_timeout(300)
    R.chk(J(pg, "window.__relayAct===1"), "relayed insight action runs in the parent",
          _ins or J(pop, "((document.querySelector('#wv-gread .wv-gr-x')||{}).textContent||'no expanded pane').trim().slice(0,60)"))
    # (nothing to restore - see the note above: the publisher was never actually frozen)
    J(pop, "document.querySelector('#wv-gread .wv-gr-sc[data-d=view]').click()")
    J(pg, "S.theme='light';prefChanged()"); pg.wait_for_timeout(500)
    R.chk(J(pop, "document.documentElement.dataset.theme") == "light", "theme broadcast reaches the popout")
    J(pg, "S.theme='dark';prefChanged()"); pg.wait_for_timeout(500)
    R.chk(J(pop, "document.documentElement.dataset.theme") == "dark", "…and back to dark")
    J(pg, "document.querySelector('#wv-stPop').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "!!document.querySelector('#wv-drop [data-wv-act=pop-in]')"), "popouts menu offers Inline / Close")
    J(pg, "document.querySelector('#wv-drop [data-wv-act=pop-in]').click()"); pg.wait_for_timeout(500)
    R.chk(J(pg, "id=>S.popouts.length===0 && S.open.some(i=>i.viewId===id)", vid) and pop.is_closed(), "pull-in closes the window and opens the view inline")
    close_all(pg)
    # 1.9.0 — a shell-level view (Settings) pops THIS page and mounts through its renderer; WV.embedURLFor = the rule
    with ctx.expect_page(timeout=15000) as pi3:
        J(pg, "popOut('wv:settings')")
    pop3 = pi3.value; R.attach(pop3); pop3.wait_for_load_state()
    wait(pop3, "!!document.querySelector('#wv-embedRoot') && EMB.inst && EMB.inst.mounted", 15000)
    R.chk(pop3.url.split("#")[0] == pg.url.split("#")[0] and J(pop3, "EMB.inst.mounted===true && !/Unknown view/.test($('#wv-embedRoot').textContent) && !!document.querySelector('#wv-embedRoot .wv-vc-toolbar')"), "shell view (Settings) pops the current page and mounts via its renderer — no 'Unknown view'", pop3.url[-70:])
    R.chk(J(pg, "typeof WV.embedURLFor==='function' && WV.embedURLFor('wv:settings',3).split('#')[0]===location.href.split('#')[0] && /#wv-embed=wv%3Asettings&inst=3/.test(WV.embedURLFor('wv:settings',3))"), "WV.embedURLFor(viewId, inst) = the framework rule (current page)")
    R.chk(J(pg, "/band=1/.test(S.popouts[0]&&S.popouts[0].win.location.hash)"), "popOut URL carries &band=1")
    close_all(pg); pg.wait_for_timeout(200)
    J(pg, "WV.registerViews([{id:'e2e:norender',name:'E2E No Renderer',product:S.product,path:['E2E'],type:'Dashboard'}])")
    if J(pg, "!!rendererFor('e2e:norender')"):
        R.chk(True, "popOut of a view without a renderer is refused with a toast — n/a here: a catch-all renderer serves every view (hub)")
        J(pg, "S.popouts.forEach(p=>{try{p.win.close()}catch(e){}});S.popouts=[]")
    else:
        n0 = J(pg, "S.popouts.length"); J(pg, "popOut('e2e:norender')"); pg.wait_for_timeout(200)
        R.chk(J(pg, "S.popouts.length") == n0 and J(pg, "/no renderer/.test($('#wv-toasts').textContent)"), "popOut of a view without a renderer is refused with a toast")
    J(pg, "S.catalog=S.catalog.filter(v=>v.id!=='e2e:norender');$('#wv-toasts').innerHTML=''")
    with ctx.expect_page(timeout=15000) as pi2:
        J(pg, "id=>popOut(id)", vid)
    pop2 = pi2.value; R.attach(pop2); wait(pg, "S.popouts[0]&&S.popouts[0].ready", 20000)
    J(pg, "document.querySelector('#wv-logoutBtn').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-modal').classList.contains('wv-open') && /popout/.test($('#wv-moBox').textContent)"), "sign-out with popouts asks to close them")
    J(pg, "closeModal()")
    R.popout_for_logout = True

def f_alarms(R, pg):
    R.feature = "alarms drawer + badge + summary read"
    J(pg, "S.alarms=[];renderAlarms();AD.sev=null;AD.sort='latest';AD.sel.clear()")
    J(pg, "WV.raiseAlarm('crit','E2E critical feeder fault','E2E Source');WV.raiseAlarm('maj','E2E major sag','E2E Source');WV.raiseAlarm('info','E2E info note','Other')")
    R.chk(J(pg, "+$('#wv-alarmCount').textContent===3 && $('#wv-alarmBtn').dataset.sev==='crit' && $('#wv-alarmBtn').classList.contains('wv-has-crit')"), "badge counts 3 unacked, tracks CRIT")
    pg.keyboard.press("Alt+a"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-adrawer').classList.contains('wv-open') && document.querySelectorAll('#wv-adBody .wv-al-card').length===3"), "Alt+A opens the drawer with 3 cards")
    J(pg, "document.querySelector('#wv-adTools [data-wv-act=ad-sev][data-d=maj]').click()")
    R.chk(J(pg, "AD.sev==='maj' && document.querySelectorAll('#wv-adBody .wv-al-card').length===1"), "severity chip filters the list")
    J(pg, "document.querySelector('#wv-adTools [data-wv-act=ad-sev][data-d=maj]').click()")
    J(pg, "document.querySelector('#wv-adTools [data-wv-act=ad-sort][data-d=sev]').click()")
    R.chk(J(pg, "AD.sort==='sev' && document.querySelector('#wv-adBody .wv-al-card').classList.contains('wv-s-crit')"), "sort by severity puts CRIT first")
    J(pg, "document.querySelector('#wv-adBody [data-wv-act=al-ack]').click()")
    R.chk(J(pg, "S.alarms.filter(a=>!a.acked&&/E2E|Other/.test(a.src)).length===2 && +$('#wv-alarmCount').textContent>=2"), "Ack one → 2 unacked")  # relayed hub alarms may arrive mid-feature: count the E2E ones
    J(pg, "document.querySelector('#wv-adTools [data-wv-act=ad-sel-all]').click()")
    R.chk(J(pg, "AD.sel.size>=2 && !document.querySelector('#wv-adFoot [data-wv-act=al-ack-sel]').disabled"), "select all → Acknowledge enabled")
    J(pg, "document.querySelector('#wv-adFoot [data-wv-act=al-ack-sel]').click()")
    R.chk(J(pg, "S.alarms.filter(a=>/E2E|Other/.test(a.src)).every(a=>a.acked) && (S.alarms.every(a=>a.acked) ? $('#wv-alarmBtn').classList.contains('wv-all-ack') : true)"), "acknowledge selected → all acked, bell calm")
    J(pg, "WV.raiseAlarm('minr','E2E minor','X');document.querySelector('#wv-adrawer [data-wv-act=ack-all]').click()")
    R.chk(J(pg, "S.alarms.every(a=>a.acked)"), "Ack all")
    R.chk(J(pg, "!!document.querySelector('#wv-adBody .wv-al-src a')"), "alarm card shows its source link")
    J(pg, "$('#wv-adrawer').classList.remove('wv-open')")
    # summary read: a burst of ≥10 alarms within 30s files a summary read into Genie's Read
    J(pg, "S.alarmSumm=true;SUMM.burst=[];WV.demo.alarmStorm(12)")
    ok = wait(pg, "!!(GREAD.data[S.product]&&GREAD.data[S.product].summaryRead)", 12000)
    R.chk(ok, "alarm burst (12) files a summary read into Genie's Read", J(pg, "(GREAD.data[S.product]||{}).summaryRead&&GREAD.data[S.product].summaryRead.headline.slice(0,80)"))
    R.chk(J(pg, "$('#wv-gread').classList.contains('wv-show')"), "Genie's Read band shows the summary")
    J(pg, "S.alarms.forEach(a=>a.acked=true);renderAlarms()")

def f_gread(R, pg):
    R.feature = "Genie's Read band"
    J(pg, "if(window.WV_HUB_GREAD)WV_HUB_GREAD.paused=true")  # hub: hold the fleet roster still — it owns the product bag
    # the alarm-summary read has its own block; here the burst detector is OFF so the hub's relayed product alarms (they arrive
    # in storms right after frames boot) cannot file a summary read mid-block and displace the E2E read under the cursor
    J(pg, "window.__summPref=S.alarmSumm;S.alarmSumm=false;if(typeof SUMM!=='undefined'){SUMM.burst=[];clearTimeout(SUMM.timer)}")
    J(pg, """WV.genieRead.set({product:S.product,title:"E2E Read",reads:[
      {headline:"<b>First</b> read",summary:"Summary one",tone:"info",cta:{label:"run cta",run(){window.__ctaRan=(window.__ctaRan||0)+1}},insights:[{text:"insight A",act:{label:"do A",run(){window.__insRan=1}}}],meta:["m1"]},
      {headline:"<b>Second</b> read",summary:"Summary two",tone:"watch"},
      {headline:"<b>Third</b> read",summary:"Summary three",tone:"crit"}]})""")
    # a live alarm-summary read (hub: relayed product alarms) legitimately leads the band — park it so the E2E reads are what shows
    J(pg, "(()=>{const d=GREAD.data[S.product];if(d&&d.summaryRead){window.__sumRead=d.summaryRead;d.summaryRead=null;d.ix=0}if(typeof renderGenieRead==='function')renderGenieRead()})()")
    d = J(pg, "GREAD.data[S.product]")
    R.chk(J(pg, "$('#wv-gread').classList.contains('wv-show') && /First/.test($('#wv-gread .wv-gr-head').textContent)"), "band shows the first read")
    R.chk(J(pg, "document.querySelectorAll('#wv-gread .wv-gr-pd').length") == J(pg, "grReads(GREAD.data[S.product]).length"), "pager dots = number of reads")
    J(pg, "document.querySelector('#wv-gread [data-wv-act=gread-next]').click()")
    R.chk(J(pg, "/Second/.test($('#wv-gread .wv-gr-head').textContent) && $('#wv-gread').dataset.tone==='watch'"), "next → second read, tone watch")
    J(pg, "document.querySelector('#wv-gread [data-wv-act=gread-prev]').click()")
    R.chk(J(pg, "/First/.test($('#wv-gread .wv-gr-head').textContent)"), "prev → first read")
    J(pg, "document.querySelector('#wv-gread .wv-gr-row').click()")
    R.chk(J(pg, "$('#wv-gread').dataset.open==='1' && /Summary one/.test($('#wv-gread .wv-gr-sum').textContent) && /insight A/.test($('#wv-gread .wv-gr-ins').textContent)"), "row click expands detail (summary + insights)")
    J(pg, "document.querySelector('#wv-gread [data-wv-act=gread-cta]').click()")
    R.chk(J(pg, "window.__ctaRan===1"), "cta runs")
    J(pg, "document.querySelector('#wv-gread .wv-gr-ins [data-wv-act=gread-run]').click()")
    R.chk(J(pg, "window.__insRan===1"), "insight action runs")
    J(pg, "document.querySelector('#wv-gread [data-wv-act=gread-pause]').click()")
    R.chk(J(pg, "GREAD.data[S.product].paused===true"), "pause halts rotation per product")
    J(pg, "document.querySelector('#wv-gread [data-wv-act=gread-pause]').click()")
    J(pg, "S.greadCycle=0;prefChanged()"); R.chk(J(pg, "_grCycleT===null"), "rotation pref Off clears the cycle timer")
    J(pg, "S.greadCycle=10;prefChanged()"); R.chk(J(pg, "_grCycleT!==null"), "rotation pref 10s arms the cycle timer")
    R.chk(J(pg, "(()=>{WV.genieRead.loading(S.product);return !!document.querySelector('#wv-gread .wv-gr-loading')})()"), "loading state renders the reading row")
    J(pg, "WV.genieRead.set({product:S.product,reads:[{headline:'restored'}]});GREAD.exp[S.product]=false;renderGenieRead()")
    # 1.9.0 — scope: Global / View
    J(pg, """WV.genieRead.set({product:S.product,title:"E2E Read",reads:[{headline:"<b>First</b> read",summary:"Summary one",tone:"info"}]})""")
    close_all(pg); vids = views_of_product(pg, 2)
    for v in vids: J(pg, "id=>openView(id)", v)
    J(pg, "id=>activate(S.open.find(i=>i.viewId===id).uid)", vids[0])
    J(pg, """id=>{WV.genieRead.clear(S.product,id);WV.genieRead.set({product:S.product,view:id,reads:[{headline:"<b>ViewRead</b> alpha",summary:"view summary",tone:"info"},{headline:"<b>ViewRead</b> beta"}]})}""", vids[0])
    J(pg, "id=>WV.genieRead.clear(S.product,id)", vids[1])
    # a live alarm-summary read (hub: relayed product alarms) legitimately leads the band — park it so the E2E reads are what shows
    J(pg, "(()=>{const d=GREAD.data[S.product];if(d&&d.summaryRead){window.__sumRead=d.summaryRead;d.summaryRead=null;d.ix=0}if(typeof renderGenieRead==='function')renderGenieRead()})()")
    R.chk(J(pg, "S.greadScope==='global' && $('#wv-gread').dataset.scope==='global' && !!document.querySelector('#wv-gread .wv-gr-scope') && document.querySelector('#wv-gread .wv-gr-sc[data-d=global]').classList.contains('wv-on') && /First/.test($('#wv-gread .wv-gr-head').textContent)"), "scope toggle rendered before Show detail; Global current; product read showing")
    R.chk(J(pg, "(()=>{const s=document.querySelector('#wv-gread .wv-gr-scope'),t=document.querySelector('#wv-gread .wv-gr-tg');return !!s&&!!t&&(s.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_FOLLOWING)>0})()"), "toggle sits before the detail pill")
    J(pg, "document.querySelector('#wv-gread .wv-gr-sc[data-d=view]').click()")
    R.chk(J(pg, "S.greadScope==='view' && $('#wv-gread').dataset.scope==='view' && /ViewRead/.test($('#wv-gread .wv-gr-head').textContent) && !/First/.test($('#wv-gread .wv-gr-head').textContent)"), "View → the focused view's read")
    R.chk(J(pg, "id=>{const c=document.querySelector('#wv-gread .wv-gr-ctx');return !!c && c.textContent.includes(view(id).name) && /2 reads/.test(c.textContent)}", vids[0]), "context chip names the view · N reads")
    R.chk(J(pg, "document.querySelectorAll('#wv-gread .wv-gr-pd').length===2"), "pager follows the view's reads")
    J(pg, "document.querySelector('#wv-gread [data-wv-act=gread-next]').click()")
    R.chk(J(pg, "/beta/.test($('#wv-gread .wv-gr-head').textContent) && GREAD.views[grActiveViewId()].ix===1"), "pager next works per scope")
    J(pg, "id=>activate(S.open.find(i=>i.viewId===id).uid)", vids[1])
    R.chk(J(pg, "id=>$('#wv-gread').classList.contains('wv-show') && $('#wv-gread').classList.contains('wv-gr-empty') && $('#wv-gread .wv-gr-emptytx').textContent.includes(view(id).name) && /No read for/.test($('#wv-gread .wv-gr-emptytx').textContent) && !!document.querySelector('#wv-gread .wv-gr-none [data-wv-act=gread-scope][data-d=global]')", vids[1]), "tab switch → a view without reads shows the honest empty line + Show global (never blank)")
    J(pg, "document.querySelector('#wv-gread .wv-gr-none [data-wv-act=gread-scope][data-d=global]').click()")
    R.chk(J(pg, "S.greadScope==='global' && /First/.test($('#wv-gread .wv-gr-head').textContent) && !$('#wv-gread').classList.contains('wv-gr-empty')"), "Show global → product reads again")
    J(pg, "S.lang='fr-CA';prefChanged();setGreadScope('view')"); pg.wait_for_timeout(100)
    R.chk(J(pg, "/Aucune lecture pour/.test($('#wv-gread .wv-gr-emptytx').textContent) && /Local/.test(document.querySelector('#wv-gread .wv-gr-sc[data-d=view]').textContent) && i18nResolve('Local — reads of the display currently open')!==null"), "i18n: empty line + toggle labels translate (fr; Local, 1.9.9)")
    J(pg, "S.lang='en-US';prefChanged()")
    R.chk(J(pg, "!!actionById('act:gread-view') && !!actionById('act:gread-global') && actionById('act:gread-view').hint()==='current'"), "palette actions Genie's Read: Global / Local (hint = current)")
    # 1.10.8 — the shell files Local reads for its OWN views: Settings is never the empty state
    J(pg, "openView(SETTINGS_ID)"); pg.wait_for_timeout(700)
    R.chk(J(pg, "((GREAD.views[SETTINGS_ID]||{}).reads||[]).length===2"), "the shell's Settings view carries 2 Local reads (1.10.8)", J(pg, "((GREAD.views[SETTINGS_ID]||{}).reads||[]).length"))
    J(pg, "setGreadScope('view')"); pg.wait_for_timeout(300)
    R.chk(J(pg, "!$('#wv-gread').classList.contains('wv-gr-empty') && /preference|genie/i.test($('#wv-gread .wv-gr-head').textContent)"), "…and Local scope renders them instead of the empty state", J(pg, "$('#wv-gread .wv-gr-head').textContent.slice(0,90)"))
    R.chk(J(pg, "(()=>{const r=(GREAD.views[SETTINGS_ID]||{}).reads||[];return r.length===2&&r.every(x=>x.headline&&x.summary&&(x.cta||(x.insights||[]).some(i=>i.act)))})()"), "both Settings reads carry a headline, a summary and a runnable action")

    # 1.12.6 - DEFAULT read scope. Session-only scope, but where it STARTS is now a preference, and
    # the requirement was explicit: opening any display must respect it.
    # the FRAMEWORK ships Global; a host file may override its own default (the hub demo build sets
    # Local), so assert the surface and that the resolver AGREES with whatever the default says -
    # a default the resolver ignored would be the actual bug here.
    R.chk(J(pg, "typeof grDefaultScope==='function' && typeof grApplyDefaultScope==='function' && "
                "['global','view'].includes(PREF_DEFAULTS.greadDefault)"),
          "1.12.6 surface: grDefaultScope / grApplyDefaultScope, with a valid shipped default")
    R.chk(J(pg, "(()=>{const keep=S.greadDefault;S.greadDefault=PREF_DEFAULTS.greadDefault;const ok=grDefaultScope()===PREF_DEFAULTS.greadDefault;S.greadDefault=keep;return ok})()"),
          "…and the resolver agrees with the shipped default", J(pg, "PREF_DEFAULTS.greadDefault"))
    J(pg, "toggleQS()"); pg.wait_for_timeout(250)
    R.chk(J(pg, "document.querySelectorAll('#wv-qs [data-wv-act=grdef-set]').length===2"), "Quick Settings carries a Global / Local default control")
    J(pg, "closeQS()")
    dvids = views_of_product(pg, 2)
    # default LOCAL: push the scope the wrong way, then open a display
    J(pg, "S.greadDefault='view';persist();setGreadScope('global')")
    J(pg, "id=>openView(id)", dvids[0]); pg.wait_for_timeout(400)
    R.chk(J(pg, "S.greadScope==='view'"), "default Local: opening a display starts the band on Local", J(pg, "S.greadScope"))
    J(pg, "setGreadScope('global')")
    J(pg, "id=>openView(id)", dvids[0]); pg.wait_for_timeout(300)   # the ALREADY-OPEN branch of openView
    R.chk(J(pg, "S.greadScope==='view'"), "…and re-opening an already-open display honours it too (the activate branch)")
    # default GLOBAL: the same, the other way, so this is a default and not a one-way switch
    J(pg, "S.greadDefault='global';persist();setGreadScope('view')")
    J(pg, "id=>openView(id)", dvids[1]); pg.wait_for_timeout(400)
    R.chk(J(pg, "S.greadScope==='global'"), "default Global: opening a display returns the band to Global", J(pg, "S.greadScope"))
    # and the sign-in start is the preference, not the old hardcoded Global
    J(pg, "S.greadDefault='view';persist();S.greadScope='global';enterApp()"); pg.wait_for_timeout(400)
    R.chk(J(pg, "S.greadScope==='view'"), "sign-in starts on the configured default, not a hardcoded Global")
    J(pg, "S.greadDefault='global';persist();setGreadScope('global')")   # leave nothing behind for later features
    J(pg, "setGreadScope('global');for(const i of S.open.slice())closeInst(i.uid)")
    R.chk(J(pg, "document.querySelector('#wv-gread .wv-gr-sc[data-d=view] span').textContent==='Local' && /Local$/.test(actionById('act:gread-view').label||actionById('act:gread-view').name||'')"), "scope toggle + palette read Local (1.9.9; value stays view)")
    J(pg, "actionById('act:gread-global').run()"); R.chk(J(pg, "S.greadScope==='global' && $('#wv-gread').dataset.scope==='global'"), "palette action switches the scope")
    R.chk(J(pg, "typeof grCur==='function' && (S.greadScope='view', grReads(grCur()).length===0) && (S.greadScope='global', grReads(grCur()).length>0 && grReads(grCur()).length===grReads(GREAD.data[S.product]).length)"), "voice/top-5 source (grCur) follows the scope showing")
    J(pg, "id=>WV.genieRead.clear(S.product,id)", vids[0]); J(pg, "setGreadScope('global')"); close_all(pg)
    J(pg, "WV.genieRead.set({product:S.product,reads:[{headline:'restored'}]});GREAD.exp[S.product]=false;renderGenieRead()")
    J(pg, "S.alarmSumm=window.__summPref!==false")  # restore the burst detector for the blocks that follow
    J(pg, "if(window.WV_HUB_GREAD){WV_HUB_GREAD.paused=false;if(typeof feedHubRead==='function')feedHubRead()}")

def f_gread_kind(R, pg):
    """1.10.15 — a read may carry `kind`: a mono-caps chip before the headline, tinted by tone,
       product wording that is never translated, and carried across the frame relay."""
    R.feature = "Genie's Read: the kind chip (1.10.15)"
    J(pg, """WV.genieRead.set({product:S.product,reads:[
        {kind:"AT LIMIT",tone:"watch",headline:"Battery charge rate is binding in HE 15",summary:"s",meta:["Headroom: 3.70 MWh"]},
        {kind:"OPPORTUNITY",tone:"info",headline:"Stored-energy headroom is never used today",summary:"s"},
        {headline:"A read with no kind at all",summary:"s"}]})""")
    pg.wait_for_timeout(300)
    R.chk(J(pg, "grReads(GREAD.data[S.product])[0].kind==='AT LIMIT'"), "the contract keeps `kind` through norm()")
    R.chk(J(pg, "(()=>{const k=document.querySelector('#wv-gread .wv-gr-kind');return !!k&&k.textContent==='AT LIMIT'&&k.dataset.tone==='watch'})()"), "the chip renders before the headline, carrying the read's tone")
    R.chk(J(pg, "(()=>{const k=document.querySelector('#wv-gread .wv-gr-kind');return !!k&&k.hasAttribute('data-wv-i18n-off')})()"), "the chip is i18n-off — a kind is product wording, never translated")
    R.chk(J(pg, "(()=>{const k=document.querySelector('#wv-gread .wv-gr-kind'),cs=getComputedStyle(k);\n        return cs.textTransform==='uppercase'&&parseFloat(cs.fontSize)<=10&&cs.color!==getComputedStyle(document.querySelector('#wv-gread .wv-gr-head')).color})()"), "the chip is mono-caps and tone-tinted, distinct from the headline ink")
    R.chk(J(pg, "(()=>{const s=grSerial(grReads(GREAD.data[S.product]));return s[0].kind==='AT LIMIT'&&s[2].kind===null})()"), "grSerial carries `kind` across the frame relay, and null when a read has none")
    J(pg, "(()=>{const d=GREAD.data[S.product];if(d)d.ix=0})()")

def f_gread_i18n(R, pg):
    """1.12.4 - Genie's Read speaks the shell's language.

       A product's read is generated prose, so there is no exact key to hold: the product
       registers the SENTENCE through the new WV.i18n.registerPatterns (a regex whose capture
       groups are the live values, one replacement template per language), and the band resolves
       each read string WHOLE - before bmark() splits it into <b> fragments - which is what lets
       Arabic and Japanese reposition $1/$2 while every captured figure, unit and line / site /
       feeder identifier is copied through untranslated."""
    R.feature = "Genie's Read: i18n (1.12.4)"
    close_all(pg)
    J(pg, "S.lang='en-US';prefChanged()")
    J(pg, "if(window.WV_HUB_GREAD)WV_HUB_GREAD.paused=true")
    J(pg, "window.__summPref=S.alarmSumm;S.alarmSumm=false;if(typeof SUMM!=='undefined'){SUMM.burst=[];clearTimeout(SUMM.timer)}")

    # ---- 1 - the seam: public, beside register(), with its own list
    R.chk(J(pg, "typeof WV.i18n.register==='function' && typeof WV.i18n.registerPatterns==='function' && Array.isArray(I18N_RXP) && typeof grTx==='function'"),
          "WV.i18n.registerPatterns is public, beside WV.i18n.register (and the band has grTx)")
    bad = J(pg, """WV.i18n.registerPatterns({
      "not anchored at all":["a","b","c","d"],
      "^unbalanced ( $":["a","b","c","d"],
      "^only one (group)$":["$1","$2 is one group too far","c","d"],
      "^too short (x)$":["only","two"]})""")
    R.chk(bad == 0, "validated like register(), and then some: unanchored / uncompilable / over-referencing / short entries are all refused", bad)

    # ---- 2 - a product registers its sentences; capture groups may be REPOSITIONED per language
    n = J(pg, r"""WV.i18n.registerPatterns({
      "^<b>(.+)</b> is running <b>(.+)</b> vs SLR at (.+), limited by span (.+)\\.$":[
        "<b>$1</b> tourne \u00e0 <b>$2</b> vs SLR \u00e0 $3, limit\u00e9e par la port\u00e9e $4.",
        "<b>$1</b> va a <b>$2</b> vs SLR a las $3, limitada por el vano $4.",
        "\u0627\u0644\u0645\u0642\u0637\u0639 $4 \u0639\u0646\u062f $3 \u0647\u0648 \u0627\u0644\u0645\u062d\u062f\u0651\u062f \u2014 \u064a\u0639\u0645\u0644 <b>$1</b> \u0639\u0646\u062f <b>$2</b> \u0645\u0642\u0627\u0628\u0644 SLR.",
        "$3 \u6642\u70b9\u3001\u30b9\u30d1\u30f3 $4 \u306e\u5236\u7d04 \u2014 <b>$1</b> \u306f SLR \u6bd4 <b>$2</b> \u3067\u7a3c\u50cd\u4e2d\u3002"],
      "^Computed on feeder (.+) at (.+) from the same model the panels read\\.$":[
        "Calcul\u00e9 sur le d\u00e9part $1 \u00e0 $2 \u00e0 partir du m\u00eame mod\u00e8le que lisent les panneaux.",
        "Calculado en el alimentador $1 a las $2 con el mismo modelo que leen los paneles.",
        "\u0645\u062d\u0633\u0648\u0628 \u0639\u0644\u0649 \u0627\u0644\u0645\u063a\u0630\u0651\u064a $1 \u0639\u0646\u062f $2 \u0645\u0646 \u0627\u0644\u0646\u0645\u0648\u0630\u062c \u0630\u0627\u062a\u0647 \u0627\u0644\u0630\u064a \u062a\u0642\u0631\u0623\u0647 \u0627\u0644\u0644\u0648\u062d\u0627\u062a.",
        "\u30d1\u30cd\u30eb\u3068\u540c\u3058\u30e2\u30c7\u30eb\u304b\u3089\u3001$2 \u6642\u70b9\u3067\u30d5\u30a3\u30fc\u30c0 $1 \u306b\u3064\u3044\u3066\u7b97\u51fa\u3002"],
      "^Span (.+) \u00b7 feeder (.+)$":[
        "Port\u00e9e $1 \u00b7 d\u00e9part $2","Vano $1 \u00b7 alimentador $2",
        "\u0627\u0644\u0645\u0642\u0637\u0639 $1 \u00b7 \u0627\u0644\u0645\u063a\u0630\u0651\u064a $2","\u30b9\u30d1\u30f3 $1 \u00b7 \u30d5\u30a3\u30fc\u30c0 $2"],
      "^open the span detail$":[
        "ouvrir le d\u00e9tail de la port\u00e9e","abrir el detalle del vano",
        "\u0627\u0641\u062a\u062d \u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0642\u0637\u0639","\u30b9\u30d1\u30f3\u8a73\u7d30\u3092\u958b\u304f"],
      "^Rating held by the (.+) at HE 18\\.$":[
        "Limite tenue par ~$1 \u00e0 HE 18.","L\u00edmite impuesto por ~$1 en HE 18.",
        "\u0627\u0644\u062a\u0635\u0646\u064a\u0641 \u0645\u062d\u0643\u0648\u0645 \u0628\u0640~$1 \u0639\u0646\u062f HE 18.","HE 18 \u3067\u306f~$1 \u304c\u5b9a\u683c\u3092\u62d8\u675f\u3002"],
      "^(\\d+) unread$":["PRODUCT WINS","PRODUCT WINS","PRODUCT WINS","PRODUCT WINS"]})""")
    R.chk(n == 6, "six sentence patterns accepted", n)
    R.chk(J(pg, """WV.i18n.register({"conductor limit":["limite du conducteur","l\u00edmite del conductor","\u062d\u062f \u0627\u0644\u0645\u0648\u0635\u0644","\u5c0e\u4f53\u5236\u9650"]})""") == 1,
          "the enumerated words a sentence drops in stay WV.i18n.register()'s job")
    R.chk(J(pg, "WV.i18n.registerPatterns({'^open the span detail$':['a','b','c','d']})") == 0,
          "registering the same sentence twice is a no-op (idempotent)")

    # ---- 3 - a product pattern can never shadow shell chrome
    J(pg, "S.lang='fr-CA';prefChanged()")
    R.chk(J(pg, "i18nResolve('3 unread')==='3 non lues'"), "the shell's own I18N_RX is searched FIRST - a product cannot shadow chrome",
          J(pg, "i18nResolve('3 unread')"))
    J(pg, "S.lang='en-US';prefChanged()")

    # ---- 4 - file a read written the way the eight products write one.
    #        Every product on the shell re-files its reads on prefChanged (that is the contract),
    #        so a language switch legitimately replaces whatever the suite parked in the bag: the
    #        E2E read is re-filed after each switch, exactly as a live product would re-file its own.
    READ = r"""[{
        kind:"AT LIMIT",tone:"watch",
        headline:"<b>Mojave Desert 500kV</b> is running <b>\u22127.6%</b> vs SLR at HE 18, limited by span P-3222.",
        summary:"Computed on feeder FDR-10045 at HE 18 from the same model the panels read.",
        meta:["Span P-3222 \u00b7 feeder FDR-10045"],
        insights:[{text:"Rating held by the conductor limit at HE 18."}],
        cta:{label:"open the span detail",run(){window.__i18nCta=1}}}]"""
    STAMPED = r"""[{
        headline:"<b>Genie Dynamic Line Ratings</b> \u2014 <b>Mojave Desert 500kV</b> is running <b>\u22127.6%</b> vs SLR at HE 18, limited by span P-3222.",
        summary:"Computed on feeder FDR-10045 at HE 18 from the same model the panels read."}]"""
    RELAYED = r"""[{headline:"Relayed from a frame at HE 18.",summary:"s"}]"""
    BAND = """(()=>{const el=document.querySelector('#wv-gread');const t=s=>{const n=el.querySelector(s);return n?n.textContent.trim():''};
      return {head:t('.wv-gr-head'),sum:t('.wv-gr-sum'),cta:t('.wv-gr-cta'),kind:t('.wv-gr-kind'),
              ins:t('.wv-gr-itx'),meta:[...el.querySelectorAll('.wv-gr-meta')].map(x=>x.textContent.trim()).join('|')}})()"""

    def file_read(js):
        J(pg, "(()=>{WV.genieRead.set({product:S.product,title:'E2E Read',silent:true,reads:" + js + "});"
              "const d=GREAD.data[S.product];if(d){d.summaryRead=null;d.ix=0}"
              "GREAD.exp[S.product]=true;store.set('greadExp',GREAD.exp);renderGenieRead()})()")
        pg.wait_for_timeout(150)

    def switch(lang, js):
        J(pg, "l=>{S.lang=l;prefChanged()}", lang)   # no reload, ever
        pg.wait_for_timeout(300)
        file_read(js)

    file_read(READ)
    en = J(pg, BAND)
    R.chk("Mojave Desert 500kV is running" in en["head"] and en["cta"] == "open the span detail",
          "the read renders in English first", en["head"][:90])

    # ---- 5 - Arabic: translated prose, untouched identifiers, untouched kind chip, RTL
    switch("ar", READ)
    ar = J(pg, BAND)
    R.chk(J(pg, "document.documentElement.dir") == "rtl", "ar: the shell is RTL")
    R.chk(ar["head"].startswith("\u0627\u0644\u0645\u0642\u0637\u0639 P-3222"),
          "ar: the headline is Arabic AND reordered - the span the template moved to the front leads the sentence", ar["head"][:90])
    R.chk("is running" not in ar["head"] and "limited by span" not in ar["head"],
          "ar: no English clause survives in the headline", ar["head"][:90])
    for ident in ["Mojave Desert 500kV", "P-3222", "HE 18", "\u22127.6%"]:
        R.chk(ident in ar["head"], "ar: the identifier / figure '%s' is copied through untranslated" % ident, ar["head"][:120])
    R.chk("FDR-10045" in ar["sum"] and "HE 18" in ar["sum"] and "the same model" not in ar["sum"],
          "ar: the summary translates, its feeder id does not", ar["sum"][:120])
    R.chk("FDR-10045" in ar["meta"] and "P-3222" in ar["meta"] and "Span" not in ar["meta"] and "feeder" not in ar["meta"],
          "ar: the meta chip translates around its identifiers", ar["meta"])
    R.chk(ar["cta"] == "\u0627\u0641\u062a\u062d \u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0642\u0637\u0639", "ar: the CTA label translates", ar["cta"])
    R.chk(ar["kind"] == "AT LIMIT" and J(pg, "document.querySelector('#wv-gread .wv-gr-kind').hasAttribute('data-wv-i18n-off')"),
          "ar: the kind chip stays product wording (never translated)", ar["kind"])
    R.chk("\u062d\u062f \u0627\u0644\u0645\u0648\u0635\u0644" in ar["ins"] and "HE 18" in ar["ins"],
          "ar: ~$n resolves an enumerated word INSIDE the sentence while the hour stays a figure", ar["ins"][:100])

    # ---- 6 - the store stays English: a language switch re-renders it, and en-US comes back whole
    R.chk(J(pg, "grReads(GREAD.data[S.product])[0].headline.indexOf('Mojave Desert 500kV</b> is running')>0"),
          "the STORE is untouched canonical English - only the render is translated",
          J(pg, "grReads(GREAD.data[S.product])[0].headline")[:90])
    for lang in ["fr-CA", "es-MX", "ja"]:
        switch(lang, READ)
        b2 = J(pg, BAND)
        R.chk(b2["head"] != en["head"] and "Mojave Desert 500kV" in b2["head"] and "P-3222" in b2["head"] and "HE 18" in b2["head"],
              "%s: the read is translated and its identifiers are not" % lang, b2["head"][:100])
    switch("en-US", READ)
    R.chk(J(pg, BAND) == en, "round trip ar / fr-CA / es-MX / ja and back to en-US is lossless - no residue", J(pg, BAND))

    # ---- 7 - the bold stamp a host adds when it re-files a read relayed up from a frame
    switch("ar", STAMPED)
    st = J(pg, BAND)
    R.chk(st["head"].startswith("Genie Dynamic Line Ratings \u2014 \u0627\u0644\u0645\u0642\u0637\u0639 P-3222"),
          "a read stamped <b>Product</b> - sentence keeps the stamp verbatim and translates the sentence behind it", st["head"][:110])
    J(pg, "S.lang='en-US';prefChanged()")

    # ---- 8 - an embedded product's sentences follow its reads UP to the host
    J(pg, r"""window.postMessage({wv:"i18n-rx",product:"child",patterns:[
        ["^Relayed from a frame at (.+)\\.$",
         ["Relay\u00e9 d\u2019un cadre \u00e0 $1.","Retransmitido desde un marco a las $1.",
          "\u0645\u064f\u0631\u064e\u062d\u0651\u064e\u0644 \u0645\u0646 \u0625\u0637\u0627\u0631 \u0639\u0646\u062f $1.","\u30d5\u30ec\u30fc\u30e0\u304b\u3089 $1 \u306b\u4e2d\u7d99\u3002"]]]},"*")""")
    pg.wait_for_timeout(300)
    R.chk(J(pg, "I18N_RXP.some(x=>x.src.indexOf('Relayed from a frame')>=0)"),
          "a host adopts the sentence patterns a frame relays up")
    switch("ar", RELAYED)
    rl = J(pg, BAND)
    R.chk(rl["head"].endswith("HE 18.") and "Relayed from" not in rl["head"],
          "...and a read relayed from a frame renders translated in the host band", rl["head"])
    J(pg, "S.lang='en-US';prefChanged()")
    if J(pg, "!!window.WV_HUB_STATS"):
        R.chk(J(pg, "I18N_RXP.filter(x=>['Relayed from a frame','vs SLR at','span detail','feeder','unread','HE 18'].every(s=>x.src.indexOf(s)<0)).length>0"),
              "hub: real product frames relayed their own read sentences up to the hub", J(pg, "I18N_RXP.length"))

    J(pg, "WV.genieRead.set({product:S.product,reads:[{headline:'restored'}]});GREAD.exp[S.product]=false;renderGenieRead()")
    J(pg, "S.alarmSumm=window.__summPref!==false")
    J(pg, "if(window.WV_HUB_GREAD){WV_HUB_GREAD.paused=false;if(typeof feedHubRead==='function')feedHubRead()}")


def f_herald(R, pg):
    R.feature = "herald island + lamp states"
    # the hub's frames announce themselves ("<product> connected") for a few seconds after a load — let that
    # settle so the E2E event is the only thing the herald carries (isolated --only runs start right after login)
    try: pg.wait_for_function("!document.querySelector('.wv-hubveil:not(.wv-off)')", timeout=15000)
    except Exception: pass
    pg.wait_for_timeout(1500)
    J(pg, "if(typeof stopSpeaking==='function')stopSpeaking('test');VOICE.holdUntil=0;HERALD.cooldownUntil=0;heraldClear();S.genieHerald='all';S.motionPref='auto';prefChanged()")
    J(pg, "herald({kind:'notif',text:'<b>E2E</b> herald event',open(){window.__heraldOpened=1}})"); pg.wait_for_timeout(200)
    R.chk(J(pg, "HERALD.carrying&&HERALD.carrying.kind==='notif' && $('#wv-podGenie').dataset.herald==='notif'"), "herald queues the event and the pod carries it")
    try: pg.wait_for_function("$('#wv-genieBtn').classList.contains('wv-materialize')", timeout=4000); spark = True  # the class lives 2200 ms; 1500 lost the race under load
    except Exception: spark = J(pg, "$('#wv-genieBtn').classList.contains('wv-materialize')")
    R.chk(spark, "lamp rematerializes (spark)")
    ok = wait(pg, "$('#wv-gbSay').classList.contains('wv-show') && /E2E/.test($('#wv-gbSay').textContent)", 4000)
    R.chk(ok, "whisper island shows the event text")
    J(pg, "document.querySelector('#wv-gbHb').click()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "window.__heraldOpened===1 && !HERALD.carrying"), "event badge click DELIVERS the carried event, queue cleared (1.9.1: the lamp itself opens the chat)")
    J(pg, "S.genieHerald='alarms';herald({kind:'notif',text:'x',open(){}})")
    R.chk(J(pg, "!HERALD.carrying"), "Herald 'Alarms only' ignores notif events")
    J(pg, "S.genieHerald='off';herald({kind:'alarm',sev:'crit',text:'x',open(){}})")
    R.chk(J(pg, "!HERALD.carrying"), "Herald Off ignores everything")
    J(pg, "S.genieHerald='all';prefChanged()")
    J(pg, "$('#wv-genieBtn').classList.add('wv-unread')")
    R.chk(J(pg, "getComputedStyle(document.querySelector('#wv-genieBtn .wv-gb-ring')).animationName!=='none'"), "unread state: sonar ring animates")
    J(pg, "$('#wv-genieBtn').classList.remove('wv-unread');$('#wv-genieBtn').classList.add('wv-busy')")
    R.chk(J(pg, "getComputedStyle(document.querySelector('#wv-genieBtn .wv-gb-aura')).getPropertyValue('--gb-o2').trim()!==''"), "busy state changes the aura tokens")
    J(pg, "$('#wv-genieBtn').classList.remove('wv-busy')")
    J(pg, "S.genieAnim='halo';prefChanged()")
    R.chk(float(J(pg, "getComputedStyle(document.querySelector('#wv-genieBtn .wv-gb-aura')).getPropertyValue('--gb-o1')") or 0) >= .88, "halo aura opacity floor ≥ .88 (1.8.7)")
    J(pg, "S.genieVanish=5;prefChanged()"); R.chk(J(pg, "_gvTimer!==null"), "re-appear 5s arms the vanish timer")
    J(pg, "S.genieVanish=0;prefChanged()"); R.chk(J(pg, "_gvTimer===null"), "re-appear Off clears it")
    J(pg, "S.genieVanish=60;S.motionPref='reduced';prefChanged()"); R.chk(J(pg, "_gvTimer===null"), "reduced motion suppresses the vanish timer")
    J(pg, "S.motionPref='auto';prefChanged()")
    J(pg, "S.genieChat=false;prefChanged()")
    R.chk(J(pg, "document.documentElement.dataset.genieChat==='off'"), "'Chat icon in header' Off → html[data-genie-chat=off]")
    J(pg, "S.genieChat=true;prefChanged()")

def f_voice(R, pg):
    R.feature = "voice commands (en + fr)"
    J(pg, "if(typeof stopSpeaking==='function')stopSpeaking('test');S.alarms=[];renderAlarms();S.lang='en-US';prefChanged();VOICE.holdUntil=0;heraldClear();closeQS();$('#wv-adrawer').classList.remove('wv-open');closeDrop()")
    R.chk(J(pg, "GENIE_CMDS.length>=20 && typeof earCommand==='function'"), "GENIE_CMDS ≥ 20 + earCommand", J(pg, "GENIE_CMDS.length"))
    J(pg, "WV.raiseAlarm('maj','E2E voice alarm','V')")
    cases = [
        ("top5a", "Genie, share the top 5 alarms", "$('#wv-adrawer').classList.contains('wv-open')"),
        ("how", "genie how are you", "$('#wv-gbSay').classList.contains('wv-show')"),
        ("timecmd", "what time is it", "/\\d\\d:\\d\\d/.test($('#wv-gbSay').textContent)"),
        ("ackall", "acknowledge all alarms", "S.alarms.every(a=>a.acked)"),
        ("fullv", "full view", "S.fullView===true&&document.body.hasAttribute('data-wv-fullview')"),
        ("fullv", "regular view", "S.fullView===false"),
        ("vclist", "list the voice commands", "$('#wv-vcmds').classList.contains('wv-open')"),
        ("cansay", "what can I say", "$('#wv-gbSay').classList.contains('wv-show')"),
        ("shh", "stop", "true"),
        ("alarms", "open the alarms", "$('#wv-adrawer').classList.contains('wv-open')"),
        ("light", "light theme", "S.theme==='light'"),
        ("dark", "dark theme", "S.theme==='dark'"),
        ("chat", "open the chat", "genieVisible()"),
        ("summ", "summarize the alarms", "true"),
        ("top5r", "share top 5 reads", "GREAD.exp[S.product]===true"),
        ("top5n", "share the top 5 notifications", "$('#wv-ndrawer').classList.contains('wv-open')"),
    ]
    for cid, phrase, expect in cases:
        J(pg, "$('#wv-adrawer').classList.remove('wv-open');closeNotif();closeDrop();$('#wv-vcmds').classList.remove('wv-open');heraldClear()")
        hit = J(pg, "t=>{const c=GENIE_CMDS.find(c=>c.re.test(t.replace(/^(hey\\s+)?genie[,]?\\s*/i,'')));return c?c.id:null}", phrase)
        J(pg, "t=>earCommand(t)", phrase); pg.wait_for_timeout(350 if cid != "chat" else 900)
        R.chk(hit == cid and J(pg, expect), "en '%s' → %s" % (phrase, cid), "matched=%s" % hit)
    J(pg, "closeGenie();$('#wv-adrawer').classList.remove('wv-open');closeDrop()")
    vname = J(pg, "visibleCatalog().find(v=>!isFrameworkView(v)).name")
    J(pg, "n=>earCommand('open the '+n)", vname); pg.wait_for_timeout(500)
    R.chk(J(pg, "n=>S.open.some(i=>view(i.viewId).name===n)", vname), "en 'open the <view>' resolves the catalog name", vname)
    close_all(pg)
    J(pg, "earCommand('close all views')"); R.chk(J(pg, "S.open.length===0"), "en 'close all views'")
    J(pg, "earCommand('switch language to spanish')"); pg.wait_for_timeout(200)
    R.chk(J(pg, "S.lang==='es-MX' && document.documentElement.lang==='es-MX'"), "en 'switch language to spanish' → es-MX")
    J(pg, "earCommand('cambia el idioma a francés')"); pg.wait_for_timeout(200)
    R.chk(J(pg, "S.lang==='fr-CA'"), "es 'cambia el idioma a francés' → fr-CA")
    # French round
    J(pg, "WV.raiseAlarm('maj','E2E alarme','V')")
    fr = [
        ("ackall", "acquitte toutes les alarmes", "S.alarms.every(a=>a.acked)"),
        ("fullv", "plein écran", "S.fullView===true"), ("fullv", "vue normale", "S.fullView===false"),
        ("how", "genie, comment ça va", "$('#wv-gbSay').classList.contains('wv-show')"),
        ("timecmd", "quelle heure est-il", "/\\d\\d:\\d\\d/.test($('#wv-gbSay').textContent)"),
        ("light", "thème clair", "S.theme==='light'"), ("dark", "thème sombre", "S.theme==='dark'"),
        ("alarms", "ouvre les alarmes", "$('#wv-adrawer').classList.contains('wv-open')"),
        ("vclist", "liste des commandes vocales", "$('#wv-vcmds').classList.contains('wv-open')"),
    ]
    for cid, phrase, expect in fr:
        J(pg, "$('#wv-adrawer').classList.remove('wv-open');closeNotif();closeDrop();$('#wv-vcmds').classList.remove('wv-open');heraldClear()")
        hit = J(pg, "t=>{const c=GENIE_CMDS.find(c=>c.re.test(t.replace(/^(hey\\s+)?genie[,]?\\s*/i,'')));return c?c.id:null}", phrase)
        J(pg, "t=>earCommand(t)", phrase); pg.wait_for_timeout(300)
        R.chk(hit == cid and J(pg, expect), "fr '%s' → %s" % (phrase, cid), "matched=%s" % hit)
    loc = J(pg, "n=>i18nResolve(n)||n", vname)
    J(pg, "n=>earCommand('ouvre '+n)", loc); pg.wait_for_timeout(500)
    R.chk(J(pg, "n=>S.open.some(i=>view(i.viewId).name===n)", vname), "fr 'ouvre <nom localisé>' opens the view", loc)
    J(pg, "$('#wv-vcmds').classList.remove('wv-open');$('#wv-adrawer').classList.remove('wv-open')")
    J(pg, "earCommand('change la langue en anglais')"); pg.wait_for_timeout(600)
    R.chk(J(pg, "S.lang==='en-US'"), "fr 'change la langue en anglais' → en-US")
    close_all(pg)
    # every documented phrase (Voice-commands overlay, 5 languages) must match the same command as its English twin
    audit = J(pg, """(()=>{const clean=s=>s.replace(/[“”«»「」]/g,"").replace(/\\s*·\\s*/g,"|").trim();
      const idOf=t=>{const c=GENIE_CMDS.find(c=>c.re.test(t.replace(/^(hey\\s+)?(genie|ジーニー|جيني)[,、，]?\\s*/i,"")));return c?c.id:null};
      const bad=[],en=VC_STR["en-US"].g;let n=0;
      for(const lang of Object.keys(VC_STR))VC_STR[lang].g.forEach((grp,gi)=>grp[1].forEach((row,ri)=>{
        const enP=clean(en[gi][1][ri][0]).split("|"),ps=clean(row[0]).split("|");
        ps.forEach((p,k)=>{n++;const e=enP[Math.min(k,enP.length-1)];const got=idOf(p.replace(/‹[^›]*›/,"Operations Dashboard")),exp=idOf(e.replace(/‹[^›]*›/,"Operations Dashboard"));
          if(!got||got!==exp)bad.push(lang+" '"+p+"' → "+got+" (en "+exp+")")})}));
      return {n,bad}})()""")
    R.chk(not audit["bad"], "every documented voice phrase in 5 languages matches its English twin's command (%d phrases)" % audit["n"], audit["bad"])
    J(pg, "heraldClear();earCommand('genie flibbertigibbet zork')"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-gbSay').classList.contains('wv-show') && $('#wv-gbSay .wv-say-t').textContent===cmdStrs().nomatch"), "addressed nonsense → polite no-match reply on the island")
    # bye: says goodbye, then really signs out after 1.8s
    J(pg, "earCommand('genie sign out')"); pg.wait_for_timeout(2400)
    R.chk(J(pg, "document.body.dataset.in!=='1' && getComputedStyle($('#wv-login')).display!=='none'"), "'sign out' voice command signs out (login page)")
    login(pg, remember=False); widget_ready(pg); pg.wait_for_timeout(1500)
    # voice prefs
    R.feature = "voice prefs"
    J(pg, "toggleQS()"); pg.wait_for_timeout(150)
    for act, d, expect in [("gvoice-set", "on", "S.genieVoice===true"), ("gvoice-set", "off", "S.genieVoice===false"),
                           ("gvdet-set", "full", "S.voiceDetail==='full'"), ("gvdet-set", "announce", "S.voiceDetail==='announce'"),
                           ("gvgen-set", "female", "S.voiceGender==='female'"), ("gvgen-set", "male", "S.voiceGender==='male'"), ("gvgen-set", "auto", "S.voiceGender==='auto'"),
                           ("greet-set", "off", "S.greetFreq==='off'&&S.loginGreet===false"), ("greet-set", "every", "S.greetFreq==='every'"), ("greet-set", "once", "S.greetFreq==='once'&&S.loginGreet===true"),
                           ("gbrief-set", "alarms", "S.loginBrief==='alarms'"), ("gbrief-set", "notifs", "S.loginBrief==='notifs'"),
                           ("gbrief-set", "none", "S.loginBrief==='none'"), ("gbrief-set", "read", "S.loginBrief==='read'"),
                           ("gstyle-set", "timeofday", "S.greetStyle==='timeofday'"), ("gstyle-set", "simple", "S.greetStyle==='simple'")]:
        J(pg, "([a,d])=>document.querySelector('#wv-qs [data-wv-act=\"'+a+'\"][data-d=\"'+d+'\"]').click()", [act, d])
        R.chk(J(pg, expect), "QS %s=%s" % (act, d))
    R.chk(J(pg, "(()=>{const r=document.querySelector('#wv-qs [data-wv-act=gbrief-set]').closest('.wv-qs-row'),g=document.querySelector('#wv-qs [data-wv-act=greet-set]').closest('.wv-qs-row');return !!r&&!!g&&g.nextElementSibling===document.querySelector('#wv-qs [data-wv-act=gstyle-set]').closest('.wv-qs-row')&&document.querySelector('#wv-qs [data-wv-act=gstyle-set]').closest('.wv-qs-row').nextElementSibling===r&&/Login briefing/.test(r.textContent)&&!/two items after the greeting/.test(r.textContent)&&r.querySelectorAll('[data-wv-act=gbrief-set]').length===4})()"), "Login briefing row sits directly under Login greeting (4 options, title only — 1.9.8)")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=greet-set][data-d=off]').click()")
    R.chk(J(pg, "document.querySelector('#wv-qs [data-wv-act=gbrief-set]').closest('.wv-qs-row').classList.contains('wv-qs-off') && PREF_DEFAULTS.loginBrief==='read' && store.get('loginBrief')==='read'"), "Login greeting Off greys the briefing row (master switch); loginBrief persisted, default read")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=greet-set][data-d=once]').click()")
    R.chk(J(pg, "!document.querySelector('#wv-qs [data-wv-act=gbrief-set]').closest('.wv-qs-row').classList.contains('wv-qs-off')"), "Login greeting On re-enables the row")
    R.chk(J(pg, "PREF_DEFAULTS.greetStyle==='simple' && !!actionById('act:greet-simple') && !!actionById('act:greet-timeofday')"), "Greeting style: default Simple hello + palette actions (1.9.5)")
    J(pg, "actionById('act:greet-timeofday').run()"); R.chk(J(pg, "S.greetStyle==='timeofday' && actionById('act:greet-timeofday').hint()==='current'"), "palette: Greeting → Time of day")
    R.chk(J(pg, "(()=>{S.greetStyle='simple';const G=GREET_SIMPLE;return /^Hello, GenieUser!$/.test(G['en-US']('GenieUser')) && G.ja('GenieUser')==='こんにちは、GenieUserさん！' && G.ar('GenieUser').startsWith('مرحباً يا GenieUser')})()"), "simple greetings carry the name the native way")
    J(pg, "S.greetStyle='simple';prefChanged()")
    J(pg, "S.lang='fr-CA';prefChanged()"); pg.wait_for_timeout(150)
    R.chk(J(pg, "/Briefing à la connexion/.test(document.querySelector('#wv-qs [data-wv-act=gbrief-set]').closest('.wv-qs-row').textContent) && /Aucun/.test(document.querySelector('#wv-qs [data-wv-act=gbrief-set][data-d=none]').textContent) && /^Deux/.test(briefStrs().read)"), "i18n: row, options and intro line translate (fr)")
    J(pg, "S.lang='en-US';prefChanged()")
    R.chk(J(pg, "!!actionById('act:brief-read') && !!actionById('act:brief-alarms') && !!actionById('act:brief-notifs') && !!actionById('act:brief-none') && actionById('act:brief-read').hint()==='current'"), "palette actions Login briefing: Genie's Read / Alarms / Notifications / None (hint = current)")
    J(pg, "actionById('act:brief-alarms').run()"); R.chk(J(pg, "S.loginBrief==='alarms' && actionById('act:brief-alarms').hint()==='current'"), "palette action switches the source"); J(pg, "S.loginBrief='read';prefChanged()")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=glisten-set][data-d=on]').click()"); pg.wait_for_timeout(600)
    R.chk(J(pg, "EAR.on===true || S.genieListen===false"), "Listening toggle: ear starts, or degrades gracefully (mic denied / unsupported)", J(pg, "[EAR.on,earSupported()]"))
    J(pg, "earSet(false)")
    R.chk(J(pg, "EAR.on===false && !EAR.rec"), "Listening off stops the recognizer")
    R.chk(J(pg, "(()=>{const b=document.querySelector('#wv-qs [data-wv-act=gvoice-test]');b.click();return true})()"), "Voice test button (voice off → warns)")
    J(pg, "closeQS()")

def f_briefing(R, pg, ctx):
    J(pg, "if(window.WV_HUB_GREAD)WV_HUB_GREAD.paused=true")  # hub: hold the fleet roster still — it owns the product bag
    R.feature = "voice: sign-in briefing + stop gestures (1.9.4)"
    # speechSynthesis SPY on the live object: logs every utterance text, starts it after 10 ms and ends it after 120 ms —
    # unless __ss.hold (all) or __ss.holdAt === its index in the run keeps it playing until cancel() / __ss.end()
    J(pg, """(()=>{const ss=speechSynthesis;const st=window.__ss={log:[],cancels:0,cur:null,hold:false,holdAt:-1,n:0};
      const endCur=()=>{const c=st.cur;if(!c)return;st.cur=null;setTimeout(()=>{c.onend&&c.onend({})},0)};
      st.end=endCur;st.reset=()=>{st.log=[];st.cancels=0;st.n=0;st.hold=false;st.holdAt=-1;st.cur=null;window.__cards=[]};
      Object.defineProperty(ss,'speaking',{get:()=>!!st.cur,configurable:true});
      Object.defineProperty(ss,'pending',{get:()=>false,configurable:true});
      ss.speak=u=>{if(u.volume===0){setTimeout(()=>{u.onend&&u.onend({})},0);return} // 1.10.16 voiceWarm: silent, answered at once, never transcript
        const k=st.n++;st.log.push(u.text);st.cur=u;setTimeout(()=>{if(st.cur!==u)return;u.onstart&&u.onstart({});
        if(!(st.hold||st.holdAt===k))setTimeout(()=>{if(st.cur===u)endCur()},120)},10)};
      ss.cancel=()=>{st.cancels++;const c=st.cur;if(c){st.cur=null;setTimeout(()=>{c.onerror&&c.onerror({error:'interrupted'})},0)}};
      ss.resume=()=>{};ss.pause=()=>{};ss.getVoices=()=>[];
      window.__cards=[];
      new MutationObserver(()=>{const s=$('#wv-gbSay');if(s&&s.classList.contains('wv-show')){const t=((s.querySelector('.wv-say-t')||{}).textContent||'').trim();
        if(t&&window.__cards[window.__cards.length-1]!==t)window.__cards.push(t)}}).observe($('#wv-gbSay'),{childList:true,subtree:true,attributes:true,characterData:true});
      return true})()""")
    R.chk(J(pg, "typeof stopSpeaking==='function' && typeof briefItems==='function' && typeof earGate==='function' && STOP_RX instanceof RegExp && 'loginBrief' in PREF_DEFAULTS"), "1.9.4 surface: stopSpeaking / briefItems / earGate / STOP_RX / PREF_DEFAULTS.loginBrief")
    J(pg, "window.__n0=S.notifs;window.__a0=S.alarms;(()=>{const d=GREAD.data[S.product];if(d&&d.summaryRead){window.__sumRead2=d.summaryRead;d.summaryRead=null;d.ix=0}})()")
    J(pg, "WV.genieRead.set({product:S.product,reads:[{headline:'<b>Alpha</b> feeder load is climbing on the north bus',summary:'x'},{headline:'Beta reserve margin holds at nine percent',summary:'y'},{headline:'Gamma third read'}]})")
    def fresh_login(src, voice=True, greet=True, hold_at=-1, keep_seen=False, freq=None):
        # 1.10.11: the ceremony is once per user+language, so a simulated sign-in clears that memory unless
        # the caller is deliberately testing the "second time is silent" rule.
        if not keep_seen: J(pg, "if(typeof GREET_SEEN!=='undefined')GREET_SEEN.clear()")
        J(pg, "([s,v,g,h,f])=>{S.loginBrief=s;S.genieVoice=v;S.loginGreet=g;S.greetFreq=f||(g?'once':'off');S.lang='en-US';prefChanged();if(typeof stopSpeaking==='function')stopSpeaking('test');heraldClear();__ss.reset();__ss.holdAt=h}", [src, voice, greet, hold_at, freq])
        J(pg, "doLogout()"); pg.wait_for_timeout(250)
        login(pg, remember=False); widget_ready(pg)
    def expect_head():  # greeting + welcome as the shell computes them now
        return J(pg, "(()=>{const G=GREET[S.lang]||GREET['en-US'];const g=(S.greetStyle==='timeofday')?G.g(new Date().getHours(),S.user.name):(GREET_SIMPLE[S.lang]||GREET_SIMPLE['en-US'])(S.user.name);return [g+' '+G.w]})()")  # 1.9.5: follows the Greeting style pref · 1.10.16: ONE utterance, not two
    # ---- read source (default): utterances + cards in order
    fresh_login("read"); pg.wait_for_timeout(1700); wait(pg, "!BRIEF.active", 12000)
    exp = expect_head() + J(pg, "(()=>{const strip=h=>{const d=document.createElement('div');d.innerHTML=h;return d.textContent.replace(/\\s+/g,' ').trim()};return [briefStrs().read].concat(grReads(GREAD.data[S.product]).slice(0,2).map(r=>strip(r.headline)))})()")
    log = J(pg, "__ss.log")
    R.chk(log == exp, "fresh login, loginBrief=read → utterances: greeting+welcome (one utterance, 1.10.16), intro, 2 GLOBAL read headlines (HTML stripped) in order", log)
    cards = J(pg, "__cards")
    R.chk(any(exp[0] in c for c in cards) and all(any(x == c for c in cards) for x in exp[1:]), "island cards: the greeting card (greeting+welcome, one utterance since 1.10.16), then one card per intro / item (exactly what is said)", cards)
    R.chk(J(pg, "VOICE.holdUntil<=Date.now()+800 && !BRIEF.active"), "hold released once the last item ended")
    # ---- read item card: speaking state, island ■, hold extension, click → the read's detail
    fresh_login("read", hold_at=2); wait(pg, "VOICE.speaking && __ss.n===3", 9000)  # 1.10.16: greeting is one utterance
    R.chk(J(pg, "$('#wv-gbSay').classList.contains('wv-show') && $('#wv-gbSay .wv-say-t').textContent===__ss.log[2] && $('#wv-gbSay').dataset.k==='read'"), "item 1 card shows exactly what is being said")
    R.chk(J(pg, "(()=>{const s=document.querySelector('#wv-gbSay .wv-say-stop');return !!s&&getComputedStyle(s).display!=='none'&&s.getAttribute('aria-label')==='Stop speaking'})()"), "the island's ■ stop control is visible while speaking (aria-label Stop speaking)")
    R.chk(J(pg, "VOICE.holdUntil-Date.now()>5000 && BRIEF.active"), "quiet window extended dynamically while the briefing plays (cap 25 s)")
    R.chk(J(pg, "$('#wv-podGenie').dataset.speaking==='1' && $('#wv-genieBtn').getAttribute('data-tip')==='Speaking — click to stop' && $('#wv-podGenie').classList.contains('wv-speaking')"), "lamp speaking state: #wv-podGenie[data-speaking] + tooltip 'Speaking — click to stop'")
    ring = J(pg, "getComputedStyle($('#wv-podGenie'),'::after').animationName")
    R.chk(ring == "wv-spk-ring", "sound-wave ring animates on the pod", ring)
    J(pg, "S.motionPref='reduced';prefChanged()"); R.chk(J(pg, "getComputedStyle($('#wv-podGenie'),'::after').animationName==='none' && getComputedStyle($('#wv-podGenie'),'::after').borderTopStyle==='solid'"), "reduced motion → static ring"); J(pg, "S.motionPref='auto';prefChanged()")
    if R.shots:
        try: pg.screenshot(path=str(R.shots / ("%s_194_lamp_speaking_island_card.png" % R.label)), clip={"x": 700, "y": 0, "width": 900, "height": 70})
        except Exception: pass
    J(pg, "GREAD.exp[S.product]=false;GREAD.data[S.product].ix=2;$('#wv-gbSay .wv-say-t').click()"); pg.wait_for_timeout(250)
    R.chk(J(pg, "GREAD.exp[S.product]===true && GREAD.data[S.product].ix===0 && !VOICE.speaking && !BRIEF.active && !$('#wv-gbSay').classList.contains('wv-show')"), "read card click → band expanded on that read (detail), briefing stopped, island calm")
    # ---- hold follows the LAST item
    fresh_login("read", hold_at=3); wait(pg, "VOICE.speaking && __ss.n===4", 9000)
    R.chk(J(pg, "VOICE.holdUntil-Date.now()>5000 && BRIEF.active && $('#wv-gbSay .wv-say-t').textContent===__ss.log[3]"), "still held on item 2 (the last utterance)")
    J(pg, "__ss.end()"); wait(pg, "!BRIEF.active", 3000)
    R.chk(J(pg, "!BRIEF.active && VOICE.holdUntil<=Date.now()+800 && !VOICE.speaking && !$('#wv-podGenie').dataset.speaking"), "last item ends → hold released, speaking state off")
    # ---- alarms source: top two UNACKED by severity, then newest; card click → alarm drawer
    J(pg, "S.alarms=[{id:'b1',sev:'minr',msg:'Minor thing',at:3,acked:false,ts:''},{id:'b2',sev:'crit',msg:'Transformer <b>T2</b> overload',at:2,acked:false,ts:''},{id:'b3',sev:'maj',msg:'Line 4 sag',at:1,acked:false,ts:''},{id:'b4',sev:'crit',msg:'acked crit',at:9,acked:true,ts:''},{id:'b5',sev:'maj',msg:'Older major',at:0,acked:false,ts:''}];renderAlarms()")
    fresh_login("alarms", hold_at=3); wait(pg, "VOICE.speaking && __ss.n===4", 9000)
    log = J(pg, "__ss.log")
    R.chk(log[1:] == ["Two alarms need attention:", "Critical: Transformer T2 overload", "Major: Line 4 sag"], "alarms source: intro + top two unacknowledged by severity (crit > maj), newest first within a severity", log)
    R.chk(J(pg, "$('#wv-gbSay').dataset.k==='maj' && $('#wv-gbSay .wv-say-t').textContent==='Major: Line 4 sag'"), "alarm card carries the severity hue + text")
    J(pg, "$('#wv-gbSay .wv-say-t').click()"); pg.wait_for_timeout(250)
    R.chk(J(pg, "$('#wv-adrawer').classList.contains('wv-open') && !BRIEF.active"), "alarm card click → alarm drawer"); J(pg, "$('#wv-adrawer').classList.remove('wv-open')")
    J(pg, "S.alarms=[];renderAlarms()"); fresh_login("alarms"); pg.wait_for_timeout(1700); wait(pg, "!BRIEF.active", 8000)
    R.chk(J(pg, "__ss.log").__len__() == 2 and J(pg, "__ss.log[1]") == "No active alarms.", "no unacked alarms → 'No active alarms.' and no items", J(pg, "__ss.log"))
    # ---- notifications source: latest two UNREAD that are news — shell confirmations excluded
    J(pg, """(()=>{const t=Date.now();S.notifs=[
      {ts:t-1000,msg:'Product switched to <b>FTM</b> — menu synced.',kind:'info',read:false},
      {ts:t-2000,msg:'Feed <b>degraded</b> on node 7',kind:'warn',read:false},
      {ts:t-2500,msg:'Workspace “Ops” loaded — 3 views (pinned views kept)',kind:'info',read:false},
      {ts:t-3000,msg:'Sync finished',kind:'ok',read:false},
      {ts:t-3500,msg:'“Ops” will open at launch.',kind:'info',read:false},
      {ts:t-4000,msg:'Tariff file imported',kind:'ok',read:false},
      {ts:t-5000,msg:'Older unread-but-read news',kind:'ok',read:true}];store.set('notifs',S.notifs);updateNotifBadge()})()""")
    fresh_login("notifs", hold_at=3); wait(pg, "VOICE.speaking && __ss.n===4", 9000)
    log = J(pg, "__ss.log")
    R.chk(log[1:] == ["Your latest notifications:", "Feed degraded on node 7", "Sync finished"], "notifications source: intro + latest two unread NEWS (product-switched / workspace-loaded / startup confirmations excluded; read ones excluded)", log)
    R.chk(J(pg, "briefNotifMeaningful({kind:'warn',msg:'Product switched to X — menu synced.'})===true && briefNotifMeaningful({kind:'ok',msg:'UI preferences reset to defaults — saved session cleared.'})===false && briefNotifMeaningful({kind:'info',msg:'Popout “Map” closed.'})===false && briefNotifMeaningful({kind:'info',msg:'Batch run finished with 2 warnings'})===true"), "notification rule: warn always briefs; otherwise anything but the shell's own confirmation phrasings")
    J(pg, "$('#wv-gbSay .wv-say-t').click()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "$('#wv-ndrawer').classList.contains('wv-open') && !BRIEF.active"), "notification card click → notifications drawer"); J(pg, "closeNotif()")
    J(pg, "S.notifs=[];store.set('notifs',S.notifs);updateNotifBadge()"); fresh_login("notifs"); pg.wait_for_timeout(1700); wait(pg, "!BRIEF.active", 8000)
    R.chk(J(pg, "__ss.log.length===2 && __ss.log[1]==='No new notifications.'"), "no unread news → 'No new notifications.' and no items", J(pg, "__ss.log"))
    J(pg, "S.notifs=window.__n0||[];store.set('notifs',S.notifs);updateNotifBadge()")
    # ---- none / greeting Off / silent resume / Voice Off
    fresh_login("none"); pg.wait_for_timeout(1700); wait(pg, "!BRIEF.active", 8000)
    R.chk(J(pg, "__ss.log") == expect_head(), "loginBrief=none → the greeting utterance only (greeting+welcome merged, 1.10.16)", J(pg, "__ss.log"))
    fresh_login("read", greet=False); pg.wait_for_timeout(2600)
    R.chk(J(pg, "__ss.log.length===0 && !BRIEF.active && !__cards.some(c=>c.includes(briefStrs().read)||c.includes(GREET['en-US'].w))"), "Login greeting Off → nothing at all (master switch)", J(pg, "[__ss.log,__cards]"))
    J(pg, "S.loginGreet=true;prefChanged();__ss.reset();S._silentResume=true;try{enterApp()}finally{S._silentResume=false}"); pg.wait_for_timeout(2600)
    R.chk(J(pg, "__ss.log.length===0 && !BRIEF.active"), "silent resume (refresh) never briefs", J(pg, "__ss.log"))
    fresh_login("read", voice=False); pg.wait_for_timeout(1700)
    R.chk(wait(pg, "__cards.length>=4", 17000) and J(pg, "__ss.log.length===0 && BRIEF.active && !VOICE.speaking && !$('#wv-podGenie').dataset.speaking"), "Voice Off → the same cards play silently (no utterance, no speaking state)", J(pg, "__cards"))
    R.chk(J(pg, "__cards").__len__() >= 4 and J(pg, "__cards[1]===briefStrs().read"), "silent cards: intro then items", J(pg, "__cards"))
    J(pg, "stopSpeaking('test')"); R.chk(J(pg, "!BRIEF.active && !$('#wv-gbSay').classList.contains('wv-show')"), "stopSpeaking ends a silent briefing too")
    # ---- Voice detail: Announce caps an item at ~140 chars, Full reads it whole
    J(pg, "WV.genieRead.set({product:S.product,reads:[{headline:'Long '+'word '.repeat(60)+'end'}]})")
    R.chk(J(pg, "(S.voiceDetail='announce', briefItems('read').items[0].text.length<=141) && (S.voiceDetail='full', briefItems('read').items[0].text.length>200)"), "Voice detail: announce caps item text (~140 chars), full reads it whole"); J(pg, "S.voiceDetail='announce'")
    J(pg, "WV.genieRead.set({product:S.product,reads:[{headline:'<b>Alpha</b> feeder load is climbing on the north bus'},{headline:'Beta reserve margin holds at nine percent'}]})")
    # ---- stop gestures (a held utterance; voice on)
    J(pg, "S.genieVoice=true;S.loginBrief='none';prefChanged();stopSpeaking('test');__ss.reset();__ss.hold=true")
    def speak(text="Feeder load is climbing on the north bus"):
        J(pg, "t=>{heraldClear();__ss.reset();__ss.hold=true;genieSpeak(t,{interrupt:true,greet:true})}", text); wait(pg, "VOICE.speaking", 3000)
    R.chk(J(pg, "stopSpeaking('idle')===false && !VOICE.speaking"), "stopSpeaking is idempotent when nothing is speaking (returns false)")
    speak(); J(pg, "closeGenie();$('#wv-genieBtn').click()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "!VOICE.speaking && !genieVisible() && __ss.cancels>0 && !$('#wv-podGenie').dataset.speaking && $('#wv-genieBtn').getAttribute('data-tip')==='Genie assistant (Ctrl+G)'"), "lamp click while speaking → stops, does NOT open the chat, tooltip restored")
    J(pg, "$('#wv-genieBtn').click()"); pg.wait_for_timeout(700)
    R.chk(J(pg, "genieVisible()"), "next lamp click opens the chat"); J(pg, "closeGenie()"); pg.wait_for_timeout(200)
    # 1.10.14 — the genie quick menu: right-click the lamp = Voice / Listening / Voice commands / Voice settings
    pg.click("#wv-genieBtn", button="right"); pg.wait_for_timeout(400)
    R.chk(J(pg, "$('#wv-drop').classList.contains('wv-open') && document.querySelectorAll('#wv-drop [data-wv-act=gmenu-voice],#wv-drop [data-wv-act=gmenu-listen],#wv-drop [data-wv-act=vcmds],#wv-drop [data-wv-act=gmenu-settings]').length===4"), "right-click on the lamp opens the quick menu with all four entries (1.10.14)")
    R.chk(J(pg, "!genieVisible()"), "…and the right-click did NOT open the chat")
    v0 = J(pg, "S.genieVoice===true")
    J(pg, "document.querySelector('#wv-drop [data-wv-act=gmenu-voice]').click()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "S.genieVoice===true") != v0 and J(pg, "!$('#wv-drop').classList.contains('wv-open')"), "menu Voice entry toggles the voice and closes the menu")
    pg.click("#wv-genieBtn", button="right"); pg.wait_for_timeout(300)
    J(pg, "document.querySelector('#wv-drop [data-wv-act=gmenu-voice]').click()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "S.genieVoice===true") == v0, "…and toggles back")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(200)
    J(pg, "toggleQS()"); speak(); pg.keyboard.press("Escape"); pg.wait_for_timeout(150)
    R.chk(J(pg, "!VOICE.speaking && $('#wv-qs').classList.contains('wv-open')"), "Esc stops speech FIRST — Quick Settings stays open")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(150); R.chk(J(pg, "!$('#wv-qs').classList.contains('wv-open')"), "Esc with nothing speaking behaves as today (closes QS)")
    J(pg, "__ss.reset();__ss.hold=true;heraldClear();cmdSay('Island stop test')"); wait(pg, "VOICE.speaking", 3000); pg.wait_for_timeout(120)
    R.chk(J(pg, "$('#wv-gbSay').classList.contains('wv-show') && $('#wv-gbSay').classList.contains('wv-spk') && getComputedStyle(document.querySelector('#wv-gbSay .wv-say-stop')).display!=='none'"), "a command reply card shows the ■ while it is spoken")
    J(pg, "document.querySelector('#wv-gbSay .wv-say-stop').click()"); pg.wait_for_timeout(150)
    R.chk(J(pg, "!VOICE.speaking && !$('#wv-gbSay').classList.contains('wv-show')"), "island ■ click → stops, island calm")
    speak(); J(pg, "toggleQS();document.querySelector('#wv-qs [data-wv-act=gvoice-set][data-d=off]').click()"); pg.wait_for_timeout(150)
    R.chk(J(pg, "!VOICE.speaking && S.genieVoice===false && __ss.cancels>0"), "Voice → Off cancels current speech immediately"); J(pg, "closeQS();S.genieVoice=true;prefChanged()")
    speak("A"); J(pg, "genieSpeak('B',{interrupt:true,greet:true})"); pg.wait_for_timeout(250)
    R.chk(J(pg, "__ss.cancels>0 && __ss.log.join('|')==='A|B'"), "interrupt:true goes through the same stop (cancel, then the new utterance)")
    # ---- barge-in (1.10.0): a REAL command spoken over the genie stops the speech and runs; echoes are dropped; a stop is never swallowed
    speak(); J(pg, "$('#wv-adrawer').classList.remove('wv-open');earCommand('open the alarms')"); pg.wait_for_timeout(150)
    R.chk(J(pg, "__ss.cancels>0 && !/Feeder load/.test(VOICE.cur||'') && $('#wv-adrawer').classList.contains('wv-open') && $('#wv-gbSay').dataset.res==='ok' && /open the alarms/.test($('#wv-gbSay').textContent)"), "barge-in: a real command while speaking cancels the speech, runs (its own reply follows), and is marked understood (1.10.0)")
    J(pg, "$('#wv-adrawer').classList.remove('wv-open')")
    speak(); J(pg, "earCommand('feeder load is climbing on the north')"); pg.wait_for_timeout(100)
    R.chk(J(pg, "VOICE.speaking && earIsEcho('feeder load is climbing on the north') && earIsEcho('load climbing north bus feeder') && !earIsEcho('open the alarms please now')"), "echo of the current utterance is ignored (containment / ≥60% token overlap)")
    R.chk(J(pg, "earGate('stop') && earGate('Stop.') && earGate('ストップ') && earGate('توقف') && earGate('silencio') && earGate('arrête') && WV.voice.match('stop')==='shh' && WV.voice.match('Stop.')==='shh' && WV.voice.match('stop the presses')!=='shh'"), "the stop vocabulary always passes the gate (5 languages), even mid-speech; 'stop the presses' is not a stop")
    J(pg, "earCommand('genie stop')"); pg.wait_for_timeout(150)
    R.chk(J(pg, "!VOICE.speaking && __ss.cancels>0 && $('#wv-gbSay .wv-say-t').textContent===cmdStrs().shhtxt"), "voice 'Genie stop' while speaking → barge-in cancels, reply 'Okay — staying quiet.'")
    J(pg, "__ss.reset();genieSpeak('Reserve margin holds at nine percent',{interrupt:true,greet:true})"); wait(pg, "VOICE.speaking", 3000); wait(pg, "!VOICE.speaking", 3000); pg.wait_for_timeout(120)
    # The premise is a 1.8 s tail after speech ends (earEchoWindow). Doing the clear, the read
    # and the command as separate round-trips can spend that whole budget under load, so the
    # echo lands AFTER the tail - where being heard is correct. Establish the premise in one
    # evaluate, and re-speak if latency stole it.
    _win = None
    for _try in range(3):
        _win = J(pg, """(()=>{heraldClear();$('#wv-gbSay').classList.remove('wv-show');
            const open=earEchoWindow(), since=Date.now()-(VOICE.lastEnd||0);
            earCommand('reserve margin holds');
            return {open, since}})()""")
        if _win and _win.get("open"): break
        J(pg, "__ss.reset();genieSpeak('Reserve margin holds at nine percent',{interrupt:true,greet:true})")
        wait(pg, "VOICE.speaking", 3000); wait(pg, "!VOICE.speaking", 3000)
    pg.wait_for_timeout(100)
    if _win and _win.get("open"):
        R.chk(J(pg, "!/reserve margin/.test($('#wv-gbSay').textContent) || !$('#wv-gbSay').classList.contains('wv-show')"),
              "late echo (within 1.8 s of the end) is dropped — not even shown as heard", _win)
    else:
        R.chk(False, "late echo: could not land inside the 1.8 s tail — harness latency, not a drop-logic failure", _win)
    # ---- 1.15.0: pressing a speaker speaks THAT surface, and does so with Voice OFF.
    # The toggle governs unsolicited speech; an explicit press is a request, so a speaker that
    # stayed silent would be a broken control. Guarded because folding force back into
    # S.genieVoice is exactly the "simplification" that would quietly kill it.
    def _spoke(src, opener=None):
        if opener: J(pg, opener); pg.wait_for_timeout(500)
        J(pg, "__ss.reset();if(typeof briefEnd==='function'&&BRIEF.active)briefEnd('stop')")
        pg.wait_for_timeout(200)
        J(pg, "s=>document.querySelector('[data-wv-act=gspeak][data-src='+s+']').click()", src)
        wait(pg, "__ss.log.length>0", 6000); pg.wait_for_timeout(700)
        return J(pg, "__ss.log.slice(0,3)")
    J(pg, "S.genieVoice=false;prefChanged()"); pg.wait_for_timeout(150)
    _r = _spoke("read")
    R.chk(bool(_r), "the read band's speaker speaks Genie's Read with Voice OFF (1.15.0)", _r)
    _a = _spoke("alarms", "(()=>{closeQS();closeNotif();$('#wv-adrawer').classList.add('wv-open');renderAlarms()})()")
    R.chk(bool(_a), "the alarm drawer's speaker speaks the alarms", _a)
    _n = _spoke("notifs", "(()=>{$('#wv-adrawer').classList.remove('wv-open');openNotif()})()")
    R.chk(bool(_n), "the notifications drawer's speaker speaks the notifications", _n)
    R.chk(_r and _a and _n and _r[0] != _a[0] and _a[0] != _n[0],
          "each speaker opens with its OWN source's line, not a shared one", [_r[:1], _a[:1], _n[:1]])
    J(pg, "closeNotif();if(typeof briefEnd==='function')briefEnd('stop')"); pg.wait_for_timeout(300)
    R.chk(J(pg, "S.genieVoice===false && BRIEF.force===false"),
          "a forced run leaves the Voice preference and the force flag as it found them",
          J(pg, "[S.genieVoice,BRIEF.force]"))
    # ---- 1.15.0: a press while OTHER speech is running must TAKE OVER, not merely cancel.
    # This is the case the first pass missed: with the sign-in briefing still speaking, the
    # press hit the stop-guard and the button looked dead. Hold the utterance open so the run
    # stays observable instead of racing the spy's 120 ms end.
    J(pg, "__ss.reset();__ss.hold=true")
    J(pg, "(()=>{closeQS();closeNotif();$('#wv-adrawer').classList.add('wv-open');renderAlarms()})()")
    pg.wait_for_timeout(400)
    J(pg, "document.querySelector('#wv-gread [data-wv-act=gspeak]').click()")
    wait(pg, "BRIEF.active===true", 6000); pg.wait_for_timeout(250)
    _mid = J(pg, "[BRIEF.active,BRIEF.src]")
    J(pg, "document.querySelector('#wv-adrawer [data-wv-act=gspeak]').click()")
    pg.wait_for_timeout(700)
    _after = J(pg, "[BRIEF.active,BRIEF.src]")
    R.chk(_mid[1] == "read" and _after[0] is True and _after[1] == "alarms",
          "a speaker pressed while another source is speaking TAKES OVER (1.15.0)",
          [_mid, _after])
    R.chk(J(pg, """(()=>{const b=document.querySelector('#wv-adrawer [data-wv-act=gspeak]');
        return !!b&&b.dataset.speaking==="1"
               &&!document.querySelector('#wv-gread [data-wv-act=gspeak]').dataset.speaking})()"""),
          "…and only the speaking source is lit")
    # the toggle survives: pressing the source that IS speaking stops it
    J(pg, "document.querySelector('#wv-adrawer [data-wv-act=gspeak]').click()")
    pg.wait_for_timeout(600)
    R.chk(J(pg, "BRIEF.active===false && BRIEF.src===null"),
          "…and pressing the source already speaking stops it (the toggle is kept)",
          J(pg, "[BRIEF.active,BRIEF.src]"))
    J(pg, "__ss.hold=false;__ss.reset();$('#wv-adrawer').classList.remove('wv-open')")
    J(pg, "earCommand('open the alarms')"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-adrawer').classList.contains('wv-open')"), "a real command right after speech ends is handled normally"); J(pg, "$('#wv-adrawer').classList.remove('wv-open')")
    R.chk(J(pg, "typeof earPause==='function' && typeof earResume==='function' && EAR.pausedForSpeech===false"), "pause/resume helpers present; the ear is not paused when nothing speaks (1.10.2)")
    # ---- 1.10.11: the ceremony plays ONCE per user x device x language; a language switch re-arms it once.
    # Driven through the real sign-in path (fresh_login) with the speech-synthesis spy, so "spoken" means spoken.
    J(pg, "S.greetFreq='once';S.loginGreet=true;S.loginBrief='none';S.genieVoice=true;S.lang='en-US';prefChanged();GREET_SEEN.clear()")
    fresh_login("none", keep_seen=True); pg.wait_for_timeout(1800); wait(pg, "!BRIEF.active", 8000)
    first = J(pg, "__ss.log")
    R.chk(len(first) >= 1 and "Hello" in " ".join(first), "first sign-in for this user+language speaks the greeting", first)
    R.chk(J(pg, "GREET_SEEN.has()===true"), "…and the context is remembered")
    fresh_login("none", keep_seen=True); pg.wait_for_timeout(1800); wait(pg, "!BRIEF.active", 8000)
    R.chk(J(pg, "__ss.log").__len__() == 0, "second sign-in in the same context is SILENT (no greeting, no welcome)", J(pg, "__ss.log"))
    R.chk(J(pg, "VOICE.greeted===true"), "…and a later utterance still does not prepend its own hello")
    # 1.10.19 (CEO ruling) — a language switch NEVER greets: the greeting belongs to sign-in and its
    # Once / Every / Off setting. This REPLACES the 1.10.11 rule that re-greeted once per language.
    J(pg, "__ss.reset();S.lang='fr-CA';prefChanged()"); pg.wait_for_timeout(2600)
    R.chk(J(pg, "__ss.log").__len__() == 0, "a language switch NEVER greets (1.10.19)", J(pg, "__ss.log"))
    for _lg in ("es-MX", "ar", "ja", "en-US", "fr-CA"):
        J(pg, "l=>{__ss.reset();S.lang=l;prefChanged()}", _lg); pg.wait_for_timeout(700)
        R.chk(J(pg, "__ss.log").__len__() == 0, "…and switching to %s is silent too" % _lg, J(pg, "__ss.log"))
    # …and it CUTS whatever is speaking — finishing a sentence in the language the user just
    # abandoned is the defect the ruling names.
    J(pg, "S.lang='en-US';prefChanged();__ss.reset();__ss.hold=true;VOICE.holdUntil=0")
    J(pg, "genieSpeak('A long sentence that the language switch has to cut off mid-word',{force:true})")
    wait(pg, "VOICE.speaking===true", 5000)
    R.chk(J(pg, "VOICE.speaking===true"), "(setup) an utterance is live before the switch")
    J(pg, "S.lang='fr-CA';prefChanged()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "VOICE.speaking!==true && BRIEF.active!==true && !speechSynthesis.speaking"), "a language switch CUTS the live utterance (it is the wrong voice now)")
    J(pg, "__ss.hold=false;__ss.reset();S.lang='en-US';prefChanged()"); pg.wait_for_timeout(600)
    R.chk(J(pg, "__ss.log").__len__() == 0, "…and cutting it does not trigger a greeting on the way back")
    J(pg, "S.lang='en-US';prefChanged();S.greetFreq='every';prefChanged()")
    fresh_login("none", keep_seen=True, freq="every"); pg.wait_for_timeout(1800); wait(pg, "!BRIEF.active", 8000)
    R.chk(len(J(pg, "__ss.log")) >= 1, "'Every sign-in' still greets every time (demo mode)", J(pg, "__ss.log"))
    J(pg, "S.greetFreq='off';prefChanged()")
    fresh_login("none", greet=False, keep_seen=True); pg.wait_for_timeout(1800)
    R.chk(J(pg, "__ss.log").__len__() == 0 and J(pg, "S.loginGreet===false"), "'Off' silences it and still greys the dependent rows")
    J(pg, "S.greetFreq='once';S.loginGreet=true;prefChanged();GREET_SEEN.clear()")
    # the briefing is operational, not ceremonial: it still runs on a silent sign-in
    fresh_login("read", keep_seen=True); pg.wait_for_timeout(1800); wait(pg, "!BRIEF.active", 9000)   # first: ceremony + briefing
    J(pg, "__ss.reset()")
    fresh_login("read", keep_seen=True); pg.wait_for_timeout(1800); wait(pg, "!BRIEF.active", 9000)   # second: briefing only
    later = J(pg, "__ss.log")
    R.chk(len(later) >= 1 and not any("Hello" in x for x in later), "a silent sign-in still delivers the briefing (operational, not ceremonial)", later)
    J(pg, "GREET_SEEN.clear();S.greetFreq='once';S.loginBrief='read';S.genieVoice=false;prefChanged()")
    # ---- 1.10.0 reliability: heard bubble always visible, result marks, alternatives, interim, watchdog, diagnostics
    R.feature = "voice: reliability (1.10.0)"
    J(pg, "stopSpeaking('test');heraldClear();S.genieHerald='all';herald({kind:'notif',text:'<b>E2E</b> carried event',open(){}})"); pg.wait_for_timeout(1800)
    R.chk(J(pg, "!!HERALD.carrying"), "a herald event is being carried on the lamp")
    J(pg, "$('#wv-ndrawer').classList.remove('wv-open');earCommand('open the notifications')"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-gbSay').classList.contains('wv-show') && /open the notifications/.test($('#wv-gbSay').textContent) && $('#wv-gbSay').dataset.res==='ok' && !!document.querySelector('#wv-gbSay .wv-say-ok') && /Opening notifications/.test($('#wv-gbSay .wv-say-t').textContent)"), "what was heard shows at the genie EVEN while the lamp carries an event — “phrase” ✓ + the reply")
    R.chk(J(pg, "$('#wv-ndrawer').classList.contains('wv-open')"), "…and the command ran"); J(pg, "closeNotif()")
    R.chk(wait(pg, "/E2E/.test($('#wv-gbSay .wv-say-t').textContent) && $('#wv-gbSay').classList.contains('wv-show')", 7000), "afterwards the carried event returns to the island")
    J(pg, "earCommand('genie flibbertigibbet zork')"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-gbSay').dataset.res==='miss' && !!document.querySelector('#wv-gbSay .wv-say-miss') || /catch that/.test($('#wv-gbSay .wv-say-t').textContent)"), "addressed but not a command → ✗ mark (then the polite retry reply)")
    J(pg, "heraldClear();$('#wv-ndrawer').classList.remove('wv-open');WV.voice.say('opin the nutifications',['open the notifications','open the modifications'])"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-ndrawer').classList.contains('wv-open') && EAR.lastMatch==='notifs' && /open the notifications/.test($('#wv-gbSay').textContent)"), "the recognizer's alternatives are tried when the first guess is not a command"); J(pg, "closeNotif()")
    J(pg, "earInterim('open the al')"); pg.wait_for_timeout(50)
    R.chk(J(pg, "$('#wv-gbSay').classList.contains('wv-say-interim') && /open the al…/.test($('#wv-gbSay .wv-say-t').textContent)"), "interim transcript shows live (grey, italic, trailing …)")
    J(pg, "earCommand('what time is it')"); pg.wait_for_timeout(120)
    R.chk(J(pg, "!$('#wv-gbSay').classList.contains('wv-say-interim') && $('#wv-gbSay').dataset.res!=='interim'"), "the final replaces the interim")
    J(pg, "stopSpeaking('test')"); pg.wait_for_timeout(400)
    J(pg, "VOICE.speaking=true;VOICE.spkAt=Date.now()-120000;VOICE.spkIdle=0;VOICE.cur='stuck flag';voiceSyncUI()")
    R.chk(wait(pg, "!VOICE.speaking && !$('#wv-podGenie').dataset.speaking && EAR.log.some(e=>e.ev==='speak-watchdog')", 4000), "a stuck speaking flag clears itself (watchdog: idle engine / length cap) — commands can never be muted for good", J(pg, "JSON.stringify({sp:VOICE.speaking,log:EAR.log.slice(-3)})"))
    J(pg, "heraldClear();$('#wv-adrawer').classList.remove('wv-open');earCommand('open the alarms')"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-adrawer').classList.contains('wv-open')"), "…and a command right after is handled"); J(pg, "$('#wv-adrawer').classList.remove('wv-open')")
    d = J(pg, "WV.voice.diag()")
    R.chk(isinstance(d, dict) and all(k in d for k in ("supported","listening","sessionAlive","restarts","lastError","lastHeard","lastMatch","lang","voiceOn","speaking","commands")) and d["commands"] >= 17 and d["lastMatch"] == "alarms", "WV.voice.diag() reports the whole pipeline", str(d)[:200])
    R.chk(J(pg, "WV.voice.match('how are you')==='how' && WV.voice.match('Open the alarms.')==='alarms' && WV.voice.match('share top 5 alarms')==='top5a' && WV.voice.match('summarize the alarms')==='summ' && WV.voice.match('switch to dark theme')==='dark' && WV.voice.match('what can I say')==='cansay' && WV.voice.match('close all displays')==='closeall' && WV.voice.match('log out')==='bye' && WV.voice.match('acknowledge all alarms')==='ackall' && WV.voice.match('full view')==='fullv' && WV.voice.match('change language to Spanish')==='langsw' && WV.voice.match('What time is it?')==='timecmd' && WV.voice.match('share top 5 notifications')==='top5n' && WV.voice.match('share top 5 genie reads')==='top5r' && WV.voice.match('open the notifications')==='notifs' && WV.voice.match('open the alarms')==='alarms' && WV.voice.match('hello there')==='hello' && WV.voice.match('tell me about the weather')===null"), "every documented phrase resolves to its command (punctuation/case tolerant); free speech resolves to none")
    R.chk(J(pg, "typeof earKick==='function' && Array.isArray(WV.voice.log()) && WV.voice.log().length>0"), "earKick + event log present")
    # ---- 1.10.5 'Hello' — a native greeting gets the native hello back + a welcome to the open product
    R.chk(J(pg, "['hello','hi','hey','good morning','bonjour','salut','hola','buenos días','مرحبا','السلام عليكم','こんにちは','おはよう','hello genie','Hello!'].every(t=>WV.voice.match(t)==='hello') && ['hello everyone how are things','say hello to the team','open the alarms'].every(t=>WV.voice.match(t)!=='hello')"), "greeting words in 5 languages match 'hello' — greeting-only phrases, never sentences")
    J(pg, "heraldClear();earCommand('hello')"); pg.wait_for_timeout(200)
    R.chk(J(pg, "new RegExp(prodObj().name).test($('#wv-gbSay').textContent) && /Hello/.test($('#wv-gbSay').textContent) && /Welcome to/.test($('#wv-gbSay').textContent)"), "'hello' → native hello + 'Welcome to <product>' at the genie", J(pg, "$('#wv-gbSay').textContent.slice(0,120)"))
    J(pg, "S.lang='es-MX';prefChanged();heraldClear();earCommand('hola')"); pg.wait_for_timeout(200)
    R.chk(J(pg, "/Hola/.test($('#wv-gbSay').textContent) && /Bienvenido a/.test($('#wv-gbSay').textContent) && new RegExp(prodObj().name).test($('#wv-gbSay').textContent)"), "es: 'hola' → ¡Hola…! Bienvenido a <product>", J(pg, "$('#wv-gbSay').textContent.slice(0,120)"))
    J(pg, "S.lang='en-US';prefChanged()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "renderVoiceCmds(),$('#wv-vcGrid').textContent.includes('Hello') && $('#wv-vcGrid').textContent.includes('greets back with a product welcome')"), "the Voice commands sheet documents it")
    # ---- recognizer lifecycle with a FAKE engine (everything but the microphone): start, interim, final + alternatives, silence-end restart, visibility kick
    R.feature = "voice: recognizer lifecycle (fake engine, 1.10.0)"
    J(pg, """(()=>{window.__fr={inst:[],starts:0};class FR{constructor(){this.continuous=false;this.interimResults=false;this.maxAlternatives=1;this.lang='';__fr.inst.push(this)}
      start(){if(this.live)throw new DOMException('already started','InvalidStateError');this.live=true;__fr.starts++;setTimeout(()=>this.onstart&&this.onstart(),0)}
      stop(){this.live=false;setTimeout(()=>this.onend&&this.onend(),0)}abort(){this.stop()}
      emit(list,final,idx){const res=list.map(alts=>{const r=alts.map(t=>({transcript:t,confidence:.9}));r.isFinal=final;r.length=alts.length;return r});
        this.onresult&&this.onresult({resultIndex:idx||0,results:res})}
      silence(){this.live=false;this.onend&&this.onend()}}
      window.__RealSR=window.webkitSpeechRecognition;window.webkitSpeechRecognition=FR;window.SpeechRecognition=FR;})()""")
    J(pg, "stopSpeaking('test');heraldClear();S.genieVoice=false;prefChanged();earSet(true)"); pg.wait_for_timeout(300)
    R.chk(J(pg, "EAR.on && __fr.inst.length===1 && __fr.inst[0].continuous===true && __fr.inst[0].interimResults===true && __fr.inst[0].maxAlternatives===3 && __fr.inst[0].lang==='en-US' && EAR.alive===true"), "Listening On starts one continuous, interim, 3-alternative session in the shell language")
    J(pg, "EAR.rec.emit([['open the al']],false,0)")
    wait(pg, "$('#wv-gbSay').classList.contains('wv-say-interim')", 4000)  # poll, not a 60 ms guess: this failed only on a saturated machine
    R.chk(J(pg, "$('#wv-gbSay').classList.contains('wv-say-interim') && /open the al…/.test($('#wv-gbSay .wv-say-t').textContent) && $('#wv-podGenie').classList.contains('wv-heard')"), "an interim result shows live on the island and the ear pulses")
    J(pg, "$('#wv-adrawer').classList.remove('wv-open');EAR.rec.emit([['open the alarms','open the alarm','opened the alarms']],true,0)"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-adrawer').classList.contains('wv-open') && EAR.lastMatch==='alarms' && $('#wv-gbSay').dataset.res==='ok'"), "a final result runs the command and is marked ✓"); J(pg, "$('#wv-adrawer').classList.remove('wv-open')")
    J(pg, "$('#wv-ndrawer').classList.remove('wv-open');EAR.rec.emit([['opened a notification','open the notifications']],true,0)"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-ndrawer').classList.contains('wv-open') && EAR.lastMatch==='notifs'"), "…the 2nd alternative rescues a mis-heard first guess"); J(pg, "closeNotif()")
    n0 = J(pg, "__fr.starts"); J(pg, "EAR.rec.silence()"); pg.wait_for_timeout(600)
    R.chk(J(pg, "n=>EAR.on && EAR.alive===true && __fr.starts>=n+1 && EAR.restarts>=1 && EAR.log.some(e=>e.ev==='end')", n0), "Chrome's silence end → the session restarts by itself (restart counted, logged)")
    J(pg, "EAR.rec.onerror&&EAR.rec.onerror({error:'no-speech'});EAR.rec.silence()"); pg.wait_for_timeout(600)
    R.chk(J(pg, "EAR.alive===true && EAR.lastErr==='no-speech' && WV.voice.diag().lastError==='no-speech'"), "a 'no-speech' error is logged and the session comes back")
    J(pg, "EAR.rec.live=false;EAR.alive=false;document.dispatchEvent(new Event('visibilitychange'))"); pg.wait_for_timeout(500)
    R.chk(J(pg, "EAR.alive===true"), "visibility change re-arms a dead session (earKick)")
    # 1.12.1: while the genie speaks the ear KEEPS LISTENING. 1.10.2 aborted the session so the speakers could not be
    # transcribed; that cost every barge-in and clipped the first words of the next phrase (both reported by the CEO).
    # `pausedForSpeech` now means "the echo guard is up", and the guard is software (earStripEcho / earIsEcho / earGate).
    J(pg, "S.genieVoice=true;prefChanged();__ss.reset();__ss.hold=true;genieSpeak('Hold this utterance open',{interrupt:true,greet:true})"); wait(pg, "VOICE.speaking", 3000); pg.wait_for_timeout(150)
    R.chk(J(pg, "EAR.on && EAR.pausedForSpeech===true && __fr.inst.some(i=>i.live) && WV.voice.diag().pausedForSpeech===true && EAR.log.some(e=>e.ev==='pause')"), "the ear KEEPS LISTENING while the genie speaks — echo guard up, engine still live (1.12.1)")
    J(pg, "EAR.rec.silence()"); pg.wait_for_timeout(500)
    R.chk(wait(pg, "EAR.pausedForSpeech===true && __fr.inst.some(i=>i.live)", 3000), "…and a stray engine end mid-speech is restarted at once (1.12.1: the ear is never off while Listening is on)")
    J(pg, "stopSpeaking('test')"); pg.wait_for_timeout(400)
    R.chk(J(pg, "!VOICE.speaking && EAR.pausedForSpeech===false && EAR.alive===true && __fr.inst.some(i=>i.live) && EAR.log.some(e=>e.ev==='resume')"), "speech ends → the ear resumes at once (live session again)")
    J(pg, "__ss.reset();__ss.hold=false;genieSpeak('Short reply',{interrupt:true,greet:true})"); wait(pg, "!VOICE.speaking && EAR.pausedForSpeech===false && EAR.alive===true", 5000)
    R.chk(J(pg, "!VOICE.speaking && EAR.pausedForSpeech===false && EAR.alive===true"), "a normal utterance: echo guard for its duration, guard down and listening right after its end")
    J(pg, "S.genieVoice=false;prefChanged()")
    J(pg, "S.lang='fr-CA';prefChanged()"); pg.wait_for_timeout(400)
    R.chk(J(pg, "EAR.on && EAR.rec.lang==='fr-CA'"), "a language switch re-tunes the ear (new session in fr-CA)"); J(pg, "S.lang='en-US';prefChanged()"); pg.wait_for_timeout(400)
    d = J(pg, "WV.voice.diag()")
    R.chk(d.get("listening") is True and d.get("sessionAlive") is True and d.get("restarts", 0) >= 1 and d.get("lang") == "en-US", "diag() reflects the live session", str(d)[:160])
    J(pg, "earSet(false)"); pg.wait_for_timeout(200)
    R.chk(J(pg, "!EAR.on && EAR.rec===null && !__fr.inst.some(i=>i.live)"), "Listening Off stops the session (no live engine left)")
    # ---- 1.10.3 microphone self-check (fake navigator.mediaDevices): no input / dead default with a working alternative / healthy input
    R.feature = "voice: microphone self-check (1.10.3)"
    J(pg, """(()=>{window.__md={mode:'none'};const devs=()=>__md.mode==='none'?[]:[{kind:'audioinput',deviceId:'default',label:'Default - Headset (AirPods) (Bluetooth)'},{kind:'audioinput',deviceId:'communications',label:'Communications - Headset (AirPods) (Bluetooth)'},{kind:'audioinput',deviceId:'realtek1',label:'Microphone Array (Realtek(R) Audio)'},{kind:'audioinput',deviceId:'bt1',label:'Headset (AirPods) (Bluetooth)'}];
      const track=l=>({label:l,readyState:'live',stop(){},getSettings(){return{deviceId:'x'}}});const stream=l=>({getAudioTracks(){return[track(l)]},getTracks(){return[track(l)]}});
      const fake={enumerateDevices:async()=>devs(),getUserMedia:async c=>{const id=c&&c.audio&&c.audio.deviceId&&c.audio.deviceId.exact;
        if(__md.mode==='dead'){if(!id||id==='default'||id==='bt1'){const e=new Error('Could not start audio source');e.name='NotReadableError';throw e}return stream('Microphone Array (Realtek(R) Audio)')}
        return stream(id==='realtek1'?'Microphone Array (Realtek(R) Audio)':'Default - Headset (AirPods) (Bluetooth)')}};
      Object.defineProperty(navigator,'mediaDevices',{value:fake,configurable:true});
      window.__AC=window.AudioContext;window.AudioContext=function(){return{createMediaStreamSource(){return{connect(){}}},createAnalyser(){return{fftSize:2048,getFloatTimeDomainData(b){for(let i=0;i<b.length;i++)b[i]=__md.level||0}}},close(){}}};})()""")
    J(pg, "EAR.mic=null;heraldClear();earSet(true)"); wait(pg, "EAR.mic && EAR.mic.err==='none'", 5000)
    R.chk(J(pg, "EAR.mic && EAR.mic.err==='none' && /No microphone available/.test($('#wv-gbSay').textContent) && WV.voice.diag().mic.err==='none'"), "no audio input listed → island says so; diag mic.err='none'")
    J(pg, "earSet(false);__md.mode='dead';EAR.mic=null;heraldClear();earSet(true)"); wait(pg, "EAR.mic && EAR.mic.err==='dead'", 12000)
    R.chk(J(pg, "EAR.mic && EAR.mic.err==='dead' && EAR.mic.alt==='Microphone Array (Realtek(R) Audio)' && /default microphone/.test($('#wv-gbSay').textContent) && /Microphone Array/.test($('#wv-gbSay').textContent)"), "dead default input (NotReadableError) → the working input is found and named (“… Microphone Array … set it as the default”)", J(pg, "JSON.stringify(EAR.mic)"))
    J(pg, "earSet(false);__md.mode='ok';__md.level=0.05;EAR.mic=null;heraldClear();earSet(true)"); wait(pg, "EAR.mic && EAR.mic.ok===true", 8000)
    R.chk(J(pg, "EAR.mic && EAR.mic.ok===true && EAR.mic.level>0.01 && !/microphone|Microphone|Brio|AirPods|Realtek/.test($('#wv-gbSay .wv-say-t').textContent)"), "healthy input → level recorded, NO device announcement (1.10.4 — 'Listening.' already confirmed)", J(pg, "JSON.stringify(EAR.mic)+' | '+$('#wv-gbSay').textContent.slice(0,80)"))
    J(pg, "earSet(false);__md.mode='ok';__md.level=0;EAR.mic=null;heraldClear();earSet(true)"); wait(pg, "EAR.mic && EAR.mic.ok===true", 8000)
    R.chk(J(pg, "EAR.mic && EAR.mic.ok===true && EAR.mic.level===0 && /silent/.test($('#wv-gbSay').textContent)"), "input opens but delivers silence → warned as silent")
    J(pg, "renderVoiceCmds();$('#wv-vcmds').classList.add('wv-open');renderVcDiag()")
    R.chk(J(pg, "[...document.querySelectorAll('#wv-vcDiagGrid .wv-vcd-k')].some(e=>e.textContent==='Microphone') && /AirPods|Microphone Array/.test($('#wv-vcDiagGrid').textContent)"), "diagnostics strip shows the microphone verdict"); J(pg, "$('#wv-vcmds').classList.remove('wv-open')")
    J(pg, "earSet(false);delete navigator.mediaDevices;window.AudioContext=window.__AC;0")  # never return a DOM constructor to Playwright; pg.wait_for_timeout(200)
    R.feature = "voice: recognizer lifecycle (fake engine, 1.10.0)"
    J(pg, "window.webkitSpeechRecognition=window.__RealSR;window.SpeechRecognition=undefined")
    R.feature = "voice: sign-in briefing + stop gestures (1.9.4)"
    R.feature = "voice: sign-in briefing + stop gestures (1.9.4)"
    if R.shots:
        try:
            J(pg, "toggleQS();document.querySelector('#wv-qs [data-wv-act=gbrief-set]').scrollIntoView({block:'center'})"); pg.wait_for_timeout(250)
            pg.screenshot(path=str(R.shots / ("%s_194_qs_login_briefing_row.png" % R.label)))
            J(pg, "closeQS()")
        except Exception: pass
    # ---- restore
    J(pg, "stopSpeaking('test');S.alarms=window.__a0||[];renderAlarms();S.loginBrief='read';S.genieVoice=false;S.loginGreet=true;prefChanged();(()=>{const d=GREAD.data[S.product];if(d&&window.__sumRead2){d.summaryRead=window.__sumRead2;window.__sumRead2=null}})();WV.genieRead.set({product:S.product,reads:[{headline:'restored'}]});GREAD.exp[S.product]=false;renderGenieRead()")

# ------------------------------------------------------------------ 1.12.1 listening robustness
"""The two devices the shell talks to, modelled so that "was it heard?" is a measurable fact.

MOUTH   the operator speaks word by word into the air. A word reaches the machine ONLY while a
        recognition session is live and has actually started (Chrome opens the microphone
        asynchronously). Everything else is LOST, which is precisely the user-visible defect:
        commands missed, and transcripts truncated to half a word.
FakeRec  models Chrome: start() -> onstart after startMs; abort() DISCARDS the buffer with no final
        result; stop() finalises; silence() is Chrome's own end-on-silence.
SS      speechSynthesis with realistic latency, so `earPause`/`earResume` are exercised on the same
        timeline the operator lives on.
Chrome ignores --use-file-for-fake-audio-capture for SpeechRecognition (only getUserMedia honours
it), so a real microphone cannot be driven from Playwright. This model is the substitute: it covers
everything between the audio device and the command, and nothing below it. What it CANNOT prove is
listed at the end of this block."""
EAR_BENCH_JS = r"""(()=>{
  const W=window;
  W.__air={said:[],lost:[]};
  W.__fr={inst:[],starts:0,startMs:220,cur:null};
  class FakeRec{
    constructor(){this.continuous=false;this.interimResults=false;this.maxAlternatives=1;this.lang="";
      this.live=false;this.started=false;this.buf=[];W.__fr.inst.push(this)}
    start(){if(this.live)throw new DOMException("already started","InvalidStateError");
      this.live=true;this.dead=false;W.__fr.starts++;W.__fr.cur=this;   // a real restart gives a working session
      setTimeout(()=>{if(!this.live)return;this.started=true;this.onstart&&this.onstart({})},W.__fr.startMs)}
    stop(){if(!this.live)return;const b=this.buf.join(" ");this.live=false;this.started=false;this.buf=[];
      if(b)this._final(b);setTimeout(()=>this.onend&&this.onend({}),0)}
    abort(){if(!this.live)return;this.live=false;this.started=false;this.buf=[];
      setTimeout(()=>this.onend&&this.onend({}),0)}
    silence(){if(!this.live)return;this.live=false;this.started=false;this.buf=[];this.onend&&this.onend({})}
    err(e){this.onerror&&this.onerror({error:e})}
    /* 1.12.2 THE DEVICE THAT MATTERS. Reported from a real microphone: Chrome stops delivering and
       fires NOTHING - no onend, no onerror - so `live`/`started` and the shell's EAR.alive all keep
       claiming health while the operator talks to a corpse. No amount of flag-checking can see this;
       only the ABSENCE OF ENGINE ACTIVITY can. zombie() is that device, exactly. */
    /* vanish(): the browser DROPS the session and says nothing - no onend, no onerror. Its internal
       state is no longer "started", so start() succeeds: the free probe revives it. This is the
       reported mechanism (the pre-1.12.1 blind start() healed exactly this, by accident). */
    vanish(){this.dead=true;this.live=false;this.started=false}
    /* zombie(): the harder one - it INSISTS it is running (start() still throws) while delivering
       nothing at all. No probe can revive this; only a full rebuild can. */
    zombie(){this.dead=true}
    /* a real room is never silent: Chrome fires sound/audio events continuously on a healthy session.
       sound() is that heartbeat, so "left alone while healthy" can be told from "recovered when dead". */
    sound(){if(this.dead)return;this.onsoundstart&&this.onsoundstart({});this.onsoundend&&this.onsoundend({})}
    hear(w){if(this.dead||!(this.live&&this.started))return false;this.buf.push(w);this._emit(this.buf.join(" "),false);return true}
    _emit(t,f){if(this.dead)return;const r=[{transcript:t,confidence:.9}];r.isFinal=f;r.length=1;
      this.onresult&&this.onresult({resultIndex:0,results:[r]})}
    _final(t){this._emit(t,true)}
  }
  W.__RealSR=W.__RealSR||W.webkitSpeechRecognition;
  W.SpeechRecognition=FakeRec;W.webkitSpeechRecognition=FakeRec;
  W.__mouth={
    say(text,perWord,tail){perWord=perWord==null?140:perWord;tail=tail==null?320:tail;
      const ws=String(text).trim().split(/\s+/),rec={text,at:Date.now(),got:null,lost:[],timers:[]};
      W.__air.said.push(rec);
      ws.forEach((w,i)=>rec.timers.push(setTimeout(()=>{const r=EAR.rec;
        if(!(r&&r.live&&r.started&&r.hear(w))){rec.lost.push(w);W.__air.lost.push(w)}},i*perWord)));
      rec.timers.push(setTimeout(()=>{const r=EAR.rec;
        if(r&&r.live&&r.started&&r.buf.length){const t=r.buf.join(" ");r.buf=[];rec.got=t;r._final(t)}
        else rec.got=rec.got||""},ws.length*perWord+tail));
      return ws.length*perWord+tail},
    whole(t){const r=W.__air.said.filter(s=>s.text===t).pop();return !!r&&r.got===t},
    last(){return W.__air.said[W.__air.said.length-1]||null},
    /* a long tail left pending from an earlier scenario would drain the NEXT phrase's buffer -
       reset() cancels every timer it owns, so scenarios cannot bleed into each other */
    reset(){(W.__air.said||[]).forEach(s=>(s.timers||[]).forEach(clearTimeout));W.__air={said:[],lost:[]}}};
  /* speechSynthesis: same API surface as the briefing spy, plus real latency knobs */
  const ss=speechSynthesis,st=W.__ss=W.__ss||{};
  st.log=[];st.cancels=0;st.q=[];st.cur=null;st.n=0;st.hold=false;st.holdAt=-1;
  st.startMs=st.startMs||10;st.durMs=st.durMs||120;st.lenBased=false;st.warmMs=st.warmMs||0;
  st.reset=()=>{st.log=[];st.cancels=0;st.q=[];st.cur=null;st.n=0;st.hold=false;st.holdAt=-1;window.__cards=[]};
  const pump=()=>{if(st.cur||!st.q.length)return;const e=st.q.shift(),u=e.u;st.cur=u;
    setTimeout(()=>{if(st.cur!==u)return;u.onstart&&u.onstart({});
      if(st.hold||st.holdAt===e.k)return;
      const d=st.lenBased?Math.max(300,String(u.text||"").length*st.durMs):st.durMs;
      setTimeout(()=>{if(st.cur!==u)return;st.cur=null;u.onend&&u.onend({});pump()},d)},st.startMs)};
  st.end=()=>{const c=st.cur;if(!c)return;st.cur=null;setTimeout(()=>{c.onend&&c.onend({});pump()},0)};
  try{Object.defineProperty(ss,"speaking",{get:()=>!!st.cur,configurable:true})}catch(e){}
  try{Object.defineProperty(ss,"pending",{get:()=>st.q.length>0,configurable:true})}catch(e){}
  ss.speak=u=>{if(u.volume===0){setTimeout(()=>{u.onend&&u.onend({})},st.warmMs);return}
    const k=st.n++;st.log.push(u.text);st.q.push({u,k});pump()};
  ss.cancel=()=>{st.cancels++;const c=st.cur,q=st.q.slice();st.cur=null;st.q=[];
    if(c)setTimeout(()=>{c.onerror&&c.onerror({error:"interrupted"})},0);
    q.forEach(e=>setTimeout(()=>{e.u.onerror&&e.u.onerror({error:"canceled"})},0))};
  ss.resume=()=>{};ss.pause=()=>{};ss.getVoices=()=>[];
  return true})()"""


def f_listening(R, pg):
    """1.12.1 — every utterance while Listening is ON is heard, transcribed WHOLE, and either
    matched to a command or shown as heard. Asserted on what the operator experiences, not on
    internal flags: the phrase that reached the machine, and whether the command ran."""
    R.feature = "voice: listening robustness (1.12.2)"
    J(pg, EAR_BENCH_JS)
    J(pg, """(()=>{S.genieVoice=true;S.lang='en-US';S.greetFreq='off';S.loginGreet=false;S.loginBrief='none';
       S.genieHerald='off';S.voiceDetail='announce';prefChanged();stopSpeaking('e2e');heraldClear();
       VOICE.holdUntil=0;VOICE.greeted=true;__ss.startMs=180;__ss.durMs=45;__ss.lenBased=true;__ss.warmMs=250})()""")
    J(pg, "earSet(true)"); pg.wait_for_timeout(2600)
    quiet = "closeNotif&&closeNotif();$('#wv-adrawer').classList.remove('wv-open');$('#wv-ndrawer').classList.remove('wv-open');heraldClear()"
    R.chk(J(pg, "EAR.on===true && EAR.alive===true && __fr.inst.some(i=>i.live)"), "Listening On: one live session", J(pg, "WV.voice.diag()"))

    # ---- the quiet case (the floor: this has always worked)
    J(pg, quiet + ";__mouth.reset();__ss.reset();__mouth.say('open the alarms')"); pg.wait_for_timeout(1500)
    R.chk(J(pg, "__mouth.whole('open the alarms') && $('#wv-adrawer').classList.contains('wv-open')"),
          "a phrase spoken into a quiet room is heard WHOLE and runs", J(pg, "(__mouth.last()||{}).got"))

    # ---- BARGE-IN: the operator talks over the genie (was 100 % lost before 1.12.1)
    J(pg, quiet + ";__mouth.reset();__ss.reset();stopSpeaking('e2e')")
    J(pg, "genieSpeak('Feeder load is climbing on the north bus and the reserve margin holds at nine percent',{interrupt:true,greet:true})")
    wait(pg, "VOICE.speaking===true", 6000); pg.wait_for_timeout(300)
    J(pg, "__mouth.say('open the alarms')"); pg.wait_for_timeout(2200)
    R.chk(J(pg, "__mouth.whole('open the alarms')"), "a phrase spoken WHILE the genie is speaking is heard WHOLE (1.12.1: the microphone is never closed)", J(pg, "JSON.stringify(__mouth.last())"))
    R.chk(J(pg, "$('#wv-adrawer').classList.contains('wv-open') && !VOICE.speaking"), "— and it runs, and the genie yields (barge-in)")

    # ---- THE SEAM: the operator answers the instant the reply ends (was truncated to "notifications")
    J(pg, quiet + ";__mouth.reset();__ss.reset();stopSpeaking('e2e')")
    J(pg, "genieSpeak('Opening the alarms.',{interrupt:true,greet:true})")
    wait(pg, "VOICE.speaking===true", 6000); wait(pg, "VOICE.speaking!==true", 8000)
    J(pg, "__mouth.say('open the notifications')"); pg.wait_for_timeout(1800)
    R.chk(J(pg, "__mouth.whole('open the notifications') && $('#wv-ndrawer').classList.contains('wv-open')"),
          "the FIRST WORDS of a phrase begun the instant a reply ends are not clipped", J(pg, "JSON.stringify(__mouth.last())"))

    # ---- a real conversation: three commands, each answered aloud
    J(pg, quiet + ";__mouth.reset();__ss.reset();stopSpeaking('e2e')")
    for phrase in ("open the alarms", "open the notifications", "what time is it"):
        J(pg, "t=>__mouth.say(t)", phrase); pg.wait_for_timeout(1500)
    pg.wait_for_timeout(900)
    R.chk(J(pg, "__air.said.every(s=>s.got===s.text) && __air.lost.length===0"),
          "three commands in a row, each answered aloud: all three heard WHOLE, not one word lost",
          J(pg, "JSON.stringify(__air.said.map(s=>[s.text,s.got]))"))

    # ---- the microphone is never closed while Listening is on
    J(pg, quiet + ";__ss.reset();stopSpeaking('e2e');__ss.hold=true;genieSpeak('A long held utterance',{interrupt:true,greet:true})")
    wait(pg, "VOICE.speaking===true", 5000); pg.wait_for_timeout(200)
    R.chk(J(pg, "EAR.pausedForSpeech===true && EAR.alive===true && __fr.inst.some(i=>i.live)"),
          "mid-utterance the echo guard is UP and the engine is still LIVE")
    J(pg, "__fr.inst.filter(i=>i.live).forEach(i=>i.silence())"); pg.wait_for_timeout(900)
    R.chk(J(pg, "EAR.alive===true"), "— and an engine that dies mid-utterance is back within a second")
    J(pg, "__ss.hold=false;stopSpeaking('e2e')"); pg.wait_for_timeout(400)

    # ---- NO FEEDBACK LOOP: the genie's own voice never becomes a command
    J(pg, quiet + ";__mouth.reset();__ss.reset();stopSpeaking('e2e')")
    J(pg, "__ss.hold=true;genieSpeak('Opening alarms.',{interrupt:true,greet:true})"); wait(pg, "VOICE.speaking===true", 5000)
    d0 = J(pg, "WV.voice.diag().echoDrops")
    J(pg, "__mouth.say('opening alarms')"); pg.wait_for_timeout(1400)
    R.chk(J(pg, "n=>WV.voice.diag().echoDrops>n", d0) and not J(pg, "$('#wv-adrawer').classList.contains('wv-open')"),
          "the genie hearing ITSELF is dropped as an echo and counted (no feedback loop) — its own reply parses as a command, so this is the loop that made 1.10.2 close the microphone")
    J(pg, "__ss.hold=false;stopSpeaking('e2e')"); pg.wait_for_timeout(300)

    # ---- a MERGED segment is unmerged, not dropped
    J(pg, quiet + ";__ss.reset();stopSpeaking('e2e');__ss.hold=true;genieSpeak('Opening alarms.',{interrupt:true,greet:true})")
    wait(pg, "VOICE.speaking===true", 5000); J(pg, quiet)
    J(pg, "WV.voice.say('opening alarms open the notifications')"); pg.wait_for_timeout(500)
    R.chk(J(pg, "$('#wv-ndrawer').classList.contains('wv-open') && EAR.log.some(e=>e.ev==='unmerge')"),
          "one segment carrying the genie's words AND the operator's is UNMERGED, and the operator's command runs")
    J(pg, "__ss.hold=false;stopSpeaking('e2e')"); pg.wait_for_timeout(300)

    # ---- the island never captions the genie
    J(pg, quiet + ";__ss.reset();stopSpeaking('e2e');__ss.hold=true;genieSpeak('Reserve margin holds at nine percent',{interrupt:true,greet:true})")
    wait(pg, "VOICE.speaking===true", 5000)
    J(pg, "$('#wv-gbSay').classList.remove('wv-show');earInterim&&0;__fr.inst.filter(i=>i.live).forEach(i=>{i.buf=[];['reserve','margin','holds'].forEach(w=>i.hear(w))})")
    pg.wait_for_timeout(300)
    R.chk(not J(pg, "$('#wv-gbSay').classList.contains('wv-say-interim') && /reserve margin/i.test($('#wv-gbSay').textContent)"),
          "the island never captions the genie's own voice as a live transcript")
    J(pg, "__ss.hold=false;stopSpeaking('e2e')"); pg.wait_for_timeout(300)

    # ---- SALVAGE: the engine cuts the operator off mid-phrase
    J(pg, quiet + ";__mouth.reset();__ss.reset();EAR.log.length=0;__mouth.say('open the alarms',120,4000)")
    pg.wait_for_timeout(520)
    R.chk(J(pg, "EAR.pendInterim && EAR.pendInterim.t==='open the alarms'"), "(setup) the whole command has arrived as an interim, no final yet")
    J(pg, "EAR.rec&&EAR.rec.silence()"); pg.wait_for_timeout(1200)
    R.chk(J(pg, "EAR.log.some(e=>e.ev==='salvage') && $('#wv-adrawer').classList.contains('wv-open')"),
          "an engine cut mid-phrase does NOT lose the command: the last interim is honoured (1.12.1)", J(pg, "EAR.log.map(e=>e.ev)"))
    J(pg, quiet + ";__mouth.reset();EAR.log.length=0;__mouth.say('open the operations dashboard',120,4000)")
    pg.wait_for_timeout(280); J(pg, "EAR.rec&&EAR.rec.silence()"); pg.wait_for_timeout(1000)
    R.chk(not J(pg, "EAR.log.some(e=>e.ev==='salvage')"), "— but a FRAGMENT is never guessed at (the open-a-view catch-all is fuzzy)", J(pg, "EAR.log.map(e=>e.ev)"))

    # ---- every engine error recovers with no user action
    for err in ("no-speech", "aborted", "network", "audio-capture"):
        J(pg, "e=>{EAR.rec&&EAR.rec.err(e);EAR.rec&&EAR.rec.silence()}", err); pg.wait_for_timeout(800)
        J(pg, quiet + ";__mouth.reset();__mouth.say('open the alarms')"); pg.wait_for_timeout(1500)
        R.chk(J(pg, "__mouth.whole('open the alarms') && $('#wv-adrawer').classList.contains('wv-open')"),
              "after a '%s' engine error the ear recovers by itself and the next phrase is heard WHOLE" % err,
              J(pg, "JSON.stringify([WV.voice.diag().lastError,(__mouth.last()||{}).got])"))

    # ---- 1.12.2 THE REPORTED FAILURE: a session that dies without firing onend or onerror.
    # Real-microphone evidence at 1.12.1: 48 s of deafness with listening:true, sessionAlive:true,
    # pausedForSpeech:false, lastError:null and restarts:0 - the guard never fired once, because it
    # trusted EAR.alive and EAR.alive was a lie. Liveness has to be an ACTIVITY fact.
    # Device 1 - vanish(): the browser drops the session silently. start() succeeds, so the free probe
    # revives it. This is the mechanism the evidence supports.
    J(pg, quiet + ";__mouth.reset();EAR.log.length=0;EAR.restarts=0;EAR.recycles=0;EAR.rec&&EAR.rec.vanish()")
    R.chk(J(pg, "EAR.on===true && EAR.alive===true && WV.voice.diag().sessionAlive===true"),
          "(setup) the engine has stopped delivering while every flag still claims a healthy session")
    J(pg, "__mouth.say('open the alarms')"); pg.wait_for_timeout(1500)
    R.chk(J(pg, "!$('#wv-adrawer').classList.contains('wv-open') && (__mouth.last()||{}).got===''"),
          "(setup) … and the operator's command is lost, exactly as reported")
    R.chk(wait(pg, "EAR.log.some(e=>e.ev==='probe') && EAR.rec && EAR.rec.started===true", 12000),
          "a SILENTLY DROPPED session is revived by the liveness probe within the bounded window (1.12.2)",
          J(pg, "[EAR.restarts, EAR.log.map(e=>e.ev)]"))
    R.chk(J(pg, "EAR.restarts>=1"), "… and diag().restarts counts it, so the failure is no longer invisible (the CEO's capture read restarts:0)", J(pg, "WV.voice.diag().restarts"))
    J(pg, quiet + ";__mouth.reset();__mouth.say('open the alarms')"); pg.wait_for_timeout(1700)
    R.chk(J(pg, "__mouth.whole('open the alarms') && $('#wv-adrawer').classList.contains('wv-open')"),
          "… and the very next phrase is heard WHOLE and acted on, with no action from the user",
          J(pg, "JSON.stringify(__mouth.last())"))

    # Device 2 - zombie(): it INSISTS it is running while delivering nothing. The probe cannot revive
    # it, so the guard must escalate to a full rebuild.
    J(pg, quiet + ";__mouth.reset();EAR.log.length=0;EAR.recycles=0;EAR.rec&&EAR.rec.zombie()")
    R.chk(wait(pg, "EAR.log.some(e=>e.ev==='recycle')", 20000),
          "a session that CLAIMS to be running while saying nothing is rebuilt outright (probe refuted, guard escalates)",
          J(pg, "[WV.voice.diag().recycles, EAR.log.map(e=>e.ev)]"))
    R.chk(J(pg, "WV.voice.diag().recycles>=1"), "… and diag() reports the rebuild", J(pg, "WV.voice.diag().recycles"))
    wait(pg, "EAR.rec && EAR.rec.started===true", 6000)
    J(pg, quiet + ";__mouth.reset();__mouth.say('open the alarms')"); pg.wait_for_timeout(1700)
    R.chk(J(pg, "__mouth.whole('open the alarms') && $('#wv-adrawer').classList.contains('wv-open')"),
          "… and the ear works again afterwards", J(pg, "JSON.stringify(__mouth.last())"))

    # ---- 1.12.2 THE LAMP CLICK: "that click is just to stop speaking, it must keep taking commands"
    J(pg, quiet + ";__mouth.reset();__ss.reset();stopSpeaking('e2e');__ss.hold=true")
    J(pg, "genieSpeak('A long reply the operator is about to cut short',{interrupt:true,greet:true})")
    wait(pg, "VOICE.speaking===true", 5000); pg.wait_for_timeout(150)
    J(pg, "$('#wv-genieBtn').click()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "!VOICE.speaking && EAR.on===true && EAR.pausedForSpeech===false"),
          "the lamp click stops the speech and lowers the echo guard")
    J(pg, "__mouth.say('open the alarms')"); pg.wait_for_timeout(1700)
    R.chk(J(pg, "__mouth.whole('open the alarms') && $('#wv-adrawer').classList.contains('wv-open')"),
          "… and a command spoken straight after the click is HEARD and ACTED ON", J(pg, "JSON.stringify(__mouth.last())"))

    # … and the reported case exactly: the session is already silently dead when he clicks.
    J(pg, quiet + ";__mouth.reset();__ss.reset();stopSpeaking('e2e');EAR.log.length=0;EAR.restarts=0;__ss.hold=true")
    J(pg, "genieSpeak('A long reply the operator is about to cut short',{interrupt:true,greet:true})")
    wait(pg, "VOICE.speaking===true", 5000); pg.wait_for_timeout(150)
    J(pg, "EAR.rec&&EAR.rec.vanish()")     # the browser drops it, with no event, while the genie talks
    J(pg, "$('#wv-genieBtn').click()")     # he clicks the lamp only to stop the reply
    R.chk(wait(pg, "EAR.log.some(e=>e.ev==='probe')", 4000),
          "REPORTED CASE: dropped session + lamp click — the resume is VERIFIED, not hoped for, and revived (1.12.2)",
          J(pg, "EAR.log.map(e=>e.ev)"))
    wait(pg, "EAR.rec && EAR.rec.started===true", 6000)
    J(pg, quiet + ";__mouth.reset();__mouth.say('open the alarms')"); pg.wait_for_timeout(1700)
    R.chk(J(pg, "__mouth.whole('open the alarms') && $('#wv-adrawer').classList.contains('wv-open')"),
          "… and it keeps taking commands: the next phrase is heard WHOLE and acted on", J(pg, "JSON.stringify(__mouth.last())"))

    # ---- the recovery must NOT become the hammering it replaced (that is what produced `network`)
    J(pg, quiet + ";window.__hb=setInterval(()=>{try{EAR.rec&&EAR.rec.sound()}catch(e){}},1200)")
    pg.wait_for_timeout(2600)                       # let the heartbeat establish: measure from a KNOWN state,
    J(pg, "EAR.recycles=0;EAR.restarts=0")          # not across a stale-idle window inherited from the last step
    pg.wait_for_timeout(9000)
    R.chk(J(pg, "WV.voice.diag().recycles===0 && EAR.restarts===0 && EAR.alive===true"),
          "a session that keeps emitting engine events is LEFT ALONE for 9 s: no probes, no recycles, no restarts",
          J(pg, "[WV.voice.diag().recycles,EAR.restarts,WV.voice.diag().lastEngineEvent]"))
    J(pg, "clearInterval(window.__hb);EAR.recycles=0;EAR.restarts=0"); pg.wait_for_timeout(9000)
    _r, _s = J(pg, "WV.voice.diag().recycles") or 0, J(pg, "EAR.restarts") or 0
    R.chk(_r <= 2 and _s == 0,
          "a wholly silent HEALTHY session is probed but never hammered or rebuilt needlessly (%s rebuilds, %s revivals in 9 s)" % (_r, _s),
          [_r, _s])

    # ---- the echo filter no longer eats good commands
    R.chk(J(pg, """(()=>{VOICE.cur='Beta reserve margin holds at nine percent on the north bus and the feeder is open';
      VOICE.speaking=true;const r=[earGate('open the alarms'),earGate('open the notifications'),earGate('what time is it')];
      VOICE.speaking=false;VOICE.cur='';return r.every(Boolean)})()"""),
      "a DIFFERENT command spoken over a long utterance passes the gate (1.12.1: content words, not stop-words — the 60 % token rule dropped all three)")
    R.chk(J(pg, """(()=>{VOICE.cur='Alpha feeder load is climbing on the north bus';VOICE.speaking=true;
      const r=earIsEcho('feeder load is climbing on the north')&&earIsEcho('load climbing north bus feeder')&&!earIsEcho('open the alarms please now');
      VOICE.speaking=false;VOICE.cur='';return r})()"""), "— while a real echo (verbatim or reordered) is still caught")

    # ---- a bare word is not a command
    R.chk(J(pg, """['it is a bit dark in here today','the room is dark','open the','highlight the feeder'].every(t=>{
      const id=WV.voice.match(t);return id!=='dark'&&id!=='light'&&id!=='openv'})"""),
      "ambient speech containing a command WORD does not act (1.12.1: 'dark' needed a theme word, 'open the' needed a name)",
      J(pg, "['it is a bit dark in here today','the room is dark','open the'].map(t=>[t,WV.voice.match(t)])"))
    R.chk(J(pg, """WV.voice.match('switch to dark theme')==='dark' && WV.voice.match('dark theme')==='dark' && WV.voice.match('dark')==='dark'
      && WV.voice.match('Th\u00e8me sombre')==='dark' && WV.voice.match('Tema oscuro')==='dark' && WV.voice.match('\u0633\u0645\u0629 \u062f\u0627\u0643\u0646\u0629')==='dark'
      && WV.voice.match('\u30c0\u30fc\u30af\u30c6\u30fc\u30de')==='dark' && WV.voice.match('open the alarms')==='alarms'"""),
      "— and every documented theme phrase in all five languages still resolves")

    # ---- diag tells the truth about the whole pipeline
    d = J(pg, "WV.voice.diag()")
    R.chk(all(k in d for k in ("echoDrops", "lastDrop", "sessionStarting", "pausedForSpeech", "sessionAlive", "recycles", "lastEngineEvent", "lastEngineEventAgoMs")) and d["listening"] is True and d["sessionAlive"] is True,
          "WV.voice.diag() reports echo drops, recycles AND the last engine event — a silent drop and a silently dead session are the two failures a suite cannot otherwise see", str(d)[:240])

    # ---- Listening Off still closes everything
    J(pg, "earSet(false)"); pg.wait_for_timeout(300)
    R.chk(J(pg, "!EAR.on && EAR.rec===null && EAR.pausedForSpeech===false && !__fr.inst.some(i=>i.live)"),
          "Listening Off closes the session and lowers the guard (a language switch can never leave the new session born deaf)")
    J(pg, "window.webkitSpeechRecognition=window.__RealSR;window.SpeechRecognition=undefined")
    J(pg, "__ss.startMs=10;__ss.durMs=120;__ss.lenBased=false;__ss.warmMs=0;__ss.reset()")
    # NOT COVERED HERE (real microphone only, for the CEO to confirm):
    #   * whether Chrome's acoustic echo cancellation keeps the speakers out of the transcript in the
    #     demo room — the software filter is the backstop, and echoDrops counts what it caught;
    #   * recognition ACCURACY on the CEO's voice, accent and microphone;
    #   * Chrome's cloud speech latency and its per-origin rate limiting under a long live session.


def f_qs(R, pg):
    R.feature = "Quick Settings: every control"
    # ---- 1.10.6: UI scale x Font size = the view-body zoom (product content follows; a body hosting an embed iframe is exempt)
    # the hub renders every PRODUCT view in an iframe, so open a shell-level view first — otherwise there is no
    # non-frame body to measure and the check would report a framework regression that is really a missing subject.
    J(pg, "openView(SETTINGS_ID)"); pg.wait_for_timeout(500)
    J(pg, "S.scale=100;S.fontScale=115;prefChanged()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "(()=>{const b=[...document.querySelectorAll('.wv-view-body')].find(x=>!x.querySelector('iframe'));return !!b&&Math.abs(parseFloat(getComputedStyle(b).zoom)-1.15)<0.001})()"), "Font size 115% → inline view body zoom 1.15 (the whole view scales)")
    J(pg, "S.scale=110;prefChanged()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "(()=>{const b=[...document.querySelectorAll('.wv-view-body')].find(x=>!x.querySelector('iframe'));return !!b&&Math.abs(parseFloat(getComputedStyle(b).zoom)-1.265)<0.002})()"), "UI scale 110% multiplies in (zoom 1.265)")
    R.chk(J(pg, "(()=>{const b=[...document.querySelectorAll('.wv-view-body')].find(x=>!x.querySelector('iframe'));if(!b)return false;const d=document.createElement('div');d.style.fontSize='var(--wv-fs-sm)';b.appendChild(d);const inside=parseFloat(getComputedStyle(d).fontSize);d.remove();document.body.appendChild(d);d.style.fontSize='var(--wv-fs-sm)';const outside=parseFloat(getComputedStyle(d).fontSize);d.remove();return inside<outside})()"), "shell font tokens are re-based inside the view body (token text scales ONCE via zoom, not twice)")
    fr = [f for f in pg.frames if 'wv-embed' in f.url]
    if fr:
        pg.wait_for_timeout(400)
        R.chk(J(pg, "(()=>{const b=[...document.querySelectorAll('.wv-view-body')].filter(x=>x.querySelector('iframe'));return b.every(x=>{const z=getComputedStyle(x).zoom;return z==='1'||z==='normal'})})()") and fr[0].evaluate("S.fontScale") == 115, "a frame-hosting body stays at zoom 1 — the CHILD adopts fontScale over the relay and zooms itself", str(fr[0].evaluate("({fs:S.fontScale,sc:S.scale})")))
    else:
        R.chk(True, "embed-side adoption covered in the embed feature (no frame open here)")
    J(pg, "S.scale=100;S.fontScale=100;prefChanged()"); pg.wait_for_timeout(100)
    J(pg, "for(const i of S.open.slice())if(view(i.viewId)&&view(i.viewId).id===SETTINGS_ID)closeInst(i.uid)")
    pg.keyboard.press("Control+,"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-qs').classList.contains('wv-open') && document.querySelectorAll('#wv-qs .wv-qs-card').length>=9"), "Ctrl+, opens Quick Settings with all cards")
    # 1.14.5 - a menu-trigger button wearing .wv-qsel must stay on ONE line inside its box.
    # "All products" wrapped to two lines and spilled out, because .wv-qsel was written for
    # <select> and a button full of spans does not inherit a select's single-line behaviour.
    _wrap = J(pg, """(()=>[...document.querySelectorAll('#wv-qs button.wv-qsel')].map(b=>({
        act:b.dataset.wvAct, h:Math.round(b.getBoundingClientRect().height),
        over:Math.round(b.scrollWidth-b.clientWidth),
        txt:(b.textContent||'').trim().slice(0,20)})))()""")
    R.chk(bool(_wrap) and all(b["h"] <= 32 for b in _wrap),
          "menu-trigger buttons stay on one line in their box (no wrap)", _wrap)
    J(pg, "closeQS()"); pg.wait_for_timeout(200)
    # ---- 1.15.0: the read band's badge head (CEO) - no product/live caption, no old label
    R.chk(J(pg, """(()=>{const b=document.querySelector('#wv-gread .wv-gr-badge');
        if(!b)return null;const t=b.querySelector('.wv-gr-btx');
        return !!t&&getComputedStyle(t).textTransform=="uppercase"
               &&!document.querySelector('#wv-gread .wv-gr-cap')})()"""),
          "Genie's Read head is the badge (uppercase label, the old caption gone)",
          J(pg, "((document.querySelector('#wv-gread .wv-gr-btx')||{}).textContent||'')"))
    # ---- 1.15.0: a speaker on each of the three surfaces
    _spk = J(pg, """(()=>{const q=s=>!!document.querySelector('[data-wv-act=gspeak][data-src='+s+']');
        return {read:q('read'), alarms:q('alarms'), notifs:q('notifs')}})()""")
    R.chk(all(_spk.values()), "a speaker sits on Genie's Read, the alarm drawer and the notifications drawer", _spk)

    order = J(pg, "[...document.querySelectorAll('#wv-qs .wv-qs-card')].map(c=>c.classList.contains('wv-qs-idcard')?'identity':(c.querySelector('.wv-qs-sec')||{}).textContent)")
    R.chk(order == ["identity", "Appearance", "Genie assistant", "Display", "Regional & formats", "Data", "Header icons", "Behavior", "Session"], "card order identity→Appearance→Genie→Display→Regional→Data→Header icons→Behavior→Session", order)
    # 1.14.5 - the identity card's voice-commands link is GONE (it duplicated Help &
    # resources). Assert the absence, so two doors to one overlay cannot return unnoticed.
    R.chk(J(pg, "!document.querySelector('#wv-qs .wv-qs-vclink') && getComputedStyle(document.querySelector('#wv-qs .wv-qs-idcard'),'::before').content==='none'"), "identity card: no duplicate voice-commands link, no ::before texture (1.8.5/1.14.5)")
    # the overlay is now reached from Help & resources - the surface that owns it
    J(pg, "closeQS();document.querySelector('#wv-helpBtn').click()"); pg.wait_for_timeout(250)
    R.chk(J(pg, "!!document.querySelector('#wv-drop [data-wv-act=vcmds]')"), "Help & resources carries the voice-commands entry")
    J(pg, "document.querySelector('#wv-drop [data-wv-act=vcmds]').click()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-vcmds').classList.contains('wv-open') && document.querySelectorAll('#wv-vcGrid .wv-krow').length>=16"), "Help & resources opens the voice-commands overlay (16 rows / 4 groups)", J(pg, "document.querySelectorAll('#wv-vcGrid .wv-krow').length"))
    R.chk(J(pg, "Math.round(document.querySelector('#wv-vcmds .wv-keys-box').getBoundingClientRect().width)") in range(1200, 1245), "voice panel 1240px wide (1.8.8)", J(pg, "document.querySelector('#wv-vcmds .wv-keys-box').getBoundingClientRect().width"))
    R.chk(J(pg, "[...document.querySelectorAll('#wv-vcGrid .wv-kdesc')].every(e=>e.getBoundingClientRect().height<32)"), "every voice description fits on 1 line (1.8.8)")
    J(pg, "S.lang='ja';prefChanged()"); pg.wait_for_timeout(250)
    # the same label, localized, on the surface that now carries it
    J(pg, "$('#wv-vcmds').classList.remove('wv-open');document.querySelector('#wv-helpBtn').click()"); pg.wait_for_timeout(250)
    R.chk(J(pg, "/音声/.test((document.querySelector('#wv-drop [data-wv-act=vcmds]')||{}).textContent||'')"), "help-menu voice-commands label localized (ja)",
          J(pg, "((document.querySelector('#wv-drop [data-wv-act=vcmds]')||{}).textContent||'').trim().slice(0,30)"))
    J(pg, "closeDrop();S.lang='en-US';prefChanged();$('#wv-vcmds').classList.remove('wv-open')"); pg.wait_for_timeout(200)
    pg.keyboard.press("Control+,"); pg.wait_for_timeout(250)   # the block below reads Quick Settings again
    def seg(act, d, expect, label):
        J(pg, "([a,d])=>{const b=document.querySelector('#wv-qs [data-wv-act=\"'+a+'\"][data-d=\"'+d+'\"]');if(!b)throw new Error('no control '+a+'/'+d);b.click()}", [act, d])
        R.chk(J(pg, expect), label)
    seg("theme-set", "light", "S.theme==='light'&&document.documentElement.dataset.theme==='light'", "Theme → light (html[data-theme])")
    seg("theme-set", "dark", "S.theme==='dark'&&document.documentElement.dataset.theme==='dark'", "Theme → dark")
    for bg in ["deepblue", "slate", "midnight", "graphite"]:
        seg("bg-set", bg, "S.bg==='%s'&&document.documentElement.dataset.bg==='%s'" % (bg, bg), "Background → %s" % bg)
    acc0 = J(pg, "getComputedStyle(document.documentElement).getPropertyValue('--wv-acc').trim()")
    seg("accent-set", "cyan", "S.accentMode==='cyan'&&document.documentElement.dataset.accent==='cyan'", "Accent → cyan (html[data-accent])")
    R.chk(J(pg, "getComputedStyle(document.documentElement).getPropertyValue('--wv-acc').trim()") != acc0, "accent token changed")
    seg("accent-set", "auto", "S.accentMode==='auto'&&!document.documentElement.dataset.accent", "Accent → follow product")
    seg("density-set", "comfortable", "S.density==='comfortable'&&document.documentElement.dataset.density==='comfortable'", "Density → comfortable")
    seg("density-set", "compact", "S.density==='compact'", "Density → compact")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=scale-step][data-d=\"5\"]').click()")
    R.chk(J(pg, "S.scale===105&&getComputedStyle(document.documentElement).getPropertyValue('--wv-scale').trim()==='1.05'"), "UI scale +5 → --wv-scale 1.05")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=scale-set]').click()"); R.chk(J(pg, "S.scale===100"), "UI scale reset")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=fscale-step][data-d=\"5\"]').click()")
    R.chk(J(pg, "S.fontScale===105&&getComputedStyle(document.documentElement).getPropertyValue('--wv-fscale').trim()==='1.05'"), "Font size +5 → --wv-fscale")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=fscale-set]').click()"); R.chk(J(pg, "S.fontScale===100"), "Font size reset")
    seg("ambient-set", "off", "S.ambient===false&&document.documentElement.dataset.ambient==='off'", "Ambient light off"); seg("ambient-set", "on", "S.ambient===true", "Ambient on")
    seg("motion-set", "reduced", "S.motionPref==='reduced'&&document.documentElement.dataset.motion==='reduced'", "Reduce motion on")
    seg("motion-set", "auto", "S.motionPref==='auto'", "Reduce motion off (default)")
    R.chk(J(pg, "PREF_DEFAULTS.motionPref==='auto' && PREF_DEFAULTS.genieRing==='violet' && PREF_DEFAULTS.infoDock==='float'"), "defaults: motion off, ring violet, info float (1.8.3)")
    # regional
    J(pg, "const s=document.querySelector('#wv-qs select[data-pref=tzPref]');s.value='UTC';s.dispatchEvent(new Event('change',{bubbles:true}))")
    R.chk(J(pg, "S.tzPref==='UTC'&&$('#wv-clockZ').textContent.trim()==='UTC'&&WV.prefs().tzLabel==='UTC'"), "Time zone → UTC (clock zone label + WV.prefs)")
    J(pg, "const s=document.querySelector('#wv-qs select[data-pref=tzPref]');s.value='EPT';s.dispatchEvent(new Event('change',{bubbles:true}))")
    J(pg, "const s=document.querySelector('#wv-qs select[data-pref=dateFormat]');s.value='DD/MM/YYYY';s.dispatchEvent(new Event('change',{bubbles:true}))")
    R.chk(J(pg, "S.dateFormat==='DD/MM/YYYY'&&/^\\d\\d\\/\\d\\d\\/\\d{4}$/.test(WV.fmt.date(new Date()))"), "Date format → DD/MM/YYYY (WV.fmt.date)")
    J(pg, "const s=document.querySelector('#wv-qs select[data-pref=dateFormat]');s.value='MM/DD/YYYY';s.dispatchEvent(new Event('change',{bubbles:true}))")
    seg("timefmt-set", "12", "S.timeFormat==='12'&&/[AP]M/i.test(WV.fmt.time(new Date()))", "Time format → 12-hour")
    seg("timefmt-set", "24", "S.timeFormat==='24'", "Time format → 24-hour")
    J(pg, "const s=document.querySelector('#wv-qs select[data-pref=numberFormat]');s.value='1.234,5';s.dispatchEvent(new Event('change',{bubbles:true}))")
    R.chk(J(pg, "S.numberFormat==='1.234,5'&&WV.fmt.number(1234.5)==='1.234,5'"), "Number format → 1.234,5 (WV.fmt.number)")
    J(pg, "const s=document.querySelector('#wv-qs select[data-pref=numberFormat]');s.value='1,234.5';s.dispatchEvent(new Event('change',{bubbles:true}))")
    seg("dec-set", "2", "S.decimals===2&&WV.fmt.number(1.5)==='1.50'", "Decimal places → 2"); seg("dec-set", "auto", "S.decimals==='auto'", "Decimal places → auto")
    seg("ar-set", "30", "S.autoRefresh===30&&WV.prefs().autoRefreshMs===30000", "Auto refresh → 30s (WV.prefs)"); seg("ar-set", "10", "S.autoRefresh===10", "Auto refresh → 10s")
    seg("gps-set", "100", "S.gridPageSize===100", "Grid page size → 100"); seg("gps-set", "50", "S.gridPageSize===50", "Grid page size → 50")
    seg("exp-set", "JSON", "S.exportFormat==='JSON'", "Export format → JSON"); seg("exp-set", "CSV", "S.exportFormat==='CSV'", "Export format → CSV")
    # header icons
    for hid in ["help", "keys", "info", "lay", "navmode", "fullview"]:
        seg("hicon:" + hid, "off", "S.hiddenIcons.has('%s')&&document.body.dataset.wvHide.split(' ').includes('%s')" % (hid, hid), "Header icon %s → Off (body[data-wv-hide])" % hid)
        seg("hicon:" + hid, "on", "!S.hiddenIcons.has('%s')" % hid, "Header icon %s → On" % hid)
    R.chk(J(pg, "document.querySelector('#wv-podInfo').getBoundingClientRect().width>0"), "Info pod visible again after toggling")
    # behavior
    seg("nav-set", "h", "S.navMode==='h'&&document.body.dataset.navmode==='h'", "Navigation → horizontal"); seg("nav-set", "v", "S.navMode==='v'", "Navigation → vertical")
    ws2 = J(pg, "(S.workspaces[1]||S.workspaces[0]||{}).id")
    if ws2:
        J(pg, "id=>{const s=document.querySelector('#wv-qsWs');s.value=id;s.dispatchEvent(new Event('change',{bubbles:true}))}", ws2)
        R.chk(J(pg, "S.startupWs") == ws2, "Startup workspace select → S.startupWs")
    seg("resume-set", "off", "S.resumeSession===false", "Resume last session → Off"); seg("resume-set", "on", "S.resumeSession===true", "Resume → On")
    seg("opendef-set", "inline", "S.openDefault==='inline'", "New views open → always inline"); seg("opendef-set", "config", "S.openDefault==='config'", "New views open → as configured")
    seg("infodock-set", "dock", "S.infoDock==='dock'&&S.infoMode===true", "Info panel → Docked (turns Info on)")
    J(pg, "toggleInfo(false)"); seg("infodock-set", "float", "S.infoDock==='float'", "Info panel → Floating"); J(pg, "toggleInfo(false)")
    # genie assistant rows
    seg("gchat-set", "off", "S.genieChat===false", "Chat icon in header → Off"); seg("gchat-set", "on", "S.genieChat===true", "Chat icon → On")
    seg("gherald-set", "alarms", "S.genieHerald==='alarms'", "Herald → Alarms only"); seg("gherald-set", "all", "S.genieHerald==='all'", "Herald → All")
    seg("gsumm-set", "off", "S.alarmSumm===false", "Summarize alarms → Off"); seg("gsumm-set", "on", "S.alarmSumm===true", "Summarize → On")
    for fl in ["golden", "brand", "red", "white"]:
        seg("gflame-set", fl, "S.genieFlame==='%s'&&document.documentElement.dataset.genieFlame==='%s'" % (fl, fl), "Flame colour → %s" % fl)
    J(pg, "const r=document.querySelector('#wv-qs input[data-wv-range=gsize]');r.value='120';r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))")
    R.chk(J(pg, "S.genieSize===120&&getComputedStyle(document.documentElement).getPropertyValue('--wv-gb-scale').trim()==='1.2'&&document.querySelector('#wv-qs [data-wv-rangeval=gsize]').textContent==='120%'"), "Lamp size slider → 120% (token + label; id-free)")
    J(pg, "const r=document.querySelector('#wv-qs input[data-wv-range=gsize]');r.value='100';r.dispatchEvent(new Event('change',{bubbles:true}))")
    for an in ["lamp", "comet", "halo"]:
        seg("ganim-set", an, "S.genieAnim==='%s'&&document.documentElement.dataset.genieAnim==='%s'" % (an, an), "Lamp style → %s" % an)
    seg("gvan-set", "30", "S.genieVanish===30", "Re-appears → 30s"); seg("gvan-set", "60", "S.genieVanish===60", "Re-appears → 1m")
    seg("gcycle-set", "5", "S.greadCycle===5", "Read rotation → 5s"); seg("gcycle-set", "10", "S.greadCycle===10", "Read rotation → 10s")
    J(pg, "const r=document.querySelector('#wv-qs input[data-wv-range=gtw]');r.value='0';r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))")
    R.chk(J(pg, "S.greadTwinkle===0&&document.documentElement.dataset.twinkle==='off'&&document.querySelector('#wv-qs [data-wv-rangeval=gtw]').textContent==='Off'"), "Dot shimmer slider → Off")
    J(pg, "const r=document.querySelector('#wv-qs input[data-wv-range=gtw]');r.value='100';r.dispatchEvent(new Event('change',{bubbles:true}))")
    for dc in ["tone", "gold", "violet"]:
        seg("grdot-set", dc, "S.greadDots==='%s'&&document.documentElement.dataset.grDots==='%s'" % (dc, dc), "Dot colour → %s" % dc)
    for rc in ["brand", "off", "violet"]:
        seg("gring-set", rc, "S.genieRing==='%s'&&document.documentElement.dataset.genieRing==='%s'" % (rc, rc), "Ring colour → %s" % rc)
    # role select + filter
    J(pg, "const s=document.querySelector('#wv-qsRole');const v=[...s.options][1].value;s.value=v;s.dispatchEvent(new Event('change',{bubbles:true}))")
    R.chk(J(pg, "S.role===[...document.querySelector('#wv-qsRole').options][1].value"), "Active role select switches role")
    J(pg, "const s=document.querySelector('#wv-qsRole');s.value=ROLES[0].id;s.dispatchEvent(new Event('change',{bubbles:true}))")
    J(pg, "const f=document.querySelector('#wv-qs .wv-qs-fin');f.value='theme';f.dispatchEvent(new Event('input',{bubbles:true}))"); pg.wait_for_timeout(120)
    R.chk(J(pg, "[...document.querySelectorAll('#wv-qs .wv-qs-row')].filter(r=>getComputedStyle(r).display!=='none').length<8"), "QS filter narrows rows to matches")
    J(pg, "const f=document.querySelector('#wv-qs .wv-qs-fin');f.value='';f.dispatchEvent(new Event('input',{bubbles:true}))")
    # language menu
    J(pg, "document.querySelector('#wv-qs [data-wv-act=lang-menu]').click()")
    R.chk(J(pg, "document.querySelectorAll('#wv-drop [data-wv-act=lang-set]').length===5"), "Language menu lists 5 languages")
    J(pg, "closeDrop();closeQS()")
    R.chk(J(pg, "!$('#wv-qs').classList.contains('wv-open')"), "close QS")

def f_settings_view(R, pg):
    R.feature = "Settings view parity + columns"
    close_all(pg); J(pg, "openView('wv:settings')"); pg.wait_for_timeout(400)
    R.chk(J(pg, "!!document.querySelector('#wv-panels .wv-set-grid')"), "Settings view mounts")
    # the sequence the packer receives = settingsHTML() template order (the DOM after packing is column-major)
    order = J(pg, "(()=>{const d=document.createElement('div');d.innerHTML=settingsHTML();return [...d.querySelectorAll('.wv-qs-card')].map(c=>c.classList.contains('wv-qs-idcard')?'identity':(c.querySelector('.wv-qs-sec')||{}).textContent)})()")
    R.chk(order == ["identity", "Appearance", "Genie assistant", "Display", "Regional & formats", "Data", "Header icons", "Behavior", "About", "Session"], "Settings sequence identity→Appearance→Genie→Display→Regional→Data→Header icons→Behavior→About→Session (1.8.4)", order)
    R.chk(J(pg, "[...document.querySelectorAll('#wv-panels .wv-set-grid .wv-qs-card')].map(c=>(c.querySelector('.wv-qs-sec')||{}).textContent)").count("Session") == 1 and J(pg, "!!document.querySelector('#wv-panels .wv-set-grid [data-wv-act=qs-reset]')"), "Session card rendered once with Reset preferences")
    R.chk(J(pg, "(()=>{const cols=[...document.querySelectorAll('#wv-panels .wv-set-col')];const seq=['identity','Appearance','Genie assistant','Display','Regional & formats','Data','Header icons','Behavior','About','Session'];return cols.every(c=>{const names=[...c.querySelectorAll('.wv-qs-card')].map(x=>x.classList.contains('wv-qs-idcard')?'identity':x.querySelector('.wv-qs-sec').textContent);const ix=names.map(n=>seq.indexOf(n));return ix.every((v,i)=>i===0||v>ix[i-1])})})()"), "each column keeps the Quick Settings sequence")
    for w, n in [(1913, 3), (1500, 2), (2560, 4)]:
        pg.set_viewport_size({"width": w, "height": 900}); pg.wait_for_timeout(350)
        cols = J(pg, "document.querySelectorAll('#wv-panels .wv-set-grid .wv-set-col').length")
        R.chk(cols == n, "@%dpx → %d balanced columns (1.8.6)" % (w, n), J(pg, "[document.querySelectorAll('#wv-panels .wv-set-grid .wv-set-col').length,document.querySelector('#wv-panels .wv-set-grid').clientWidth,document.body.dataset.side,S.layout]"))
        R.chk(J(pg, "(()=>{const cols=[...document.querySelectorAll('#wv-panels .wv-set-col')].map(c=>c.getBoundingClientRect().height);const tallest=Math.max(...[...document.querySelectorAll('#wv-panels .wv-qs-card')].map(c=>c.offsetHeight));return Math.max(...cols)-Math.min(...cols)<=tallest})()"), "@%dpx column bottoms balanced (spread ≤ tallest card)" % w, J(pg, "[...document.querySelectorAll('#wv-panels .wv-set-col')].map(c=>Math.round(c.getBoundingClientRect().height))"))
    pg.set_viewport_size({"width": 1913, "height": 900}); pg.wait_for_timeout(350)
    tops = J(pg, "[...document.querySelectorAll('#wv-panels .wv-set-col')].map(c=>{const x=c.querySelector(':scope>.wv-qs-card');return !x?'':x.classList.contains('wv-qs-idcard')?'identity':x.querySelector('.wv-qs-sec').textContent})")
    R.chk("Genie assistant" in tops, "@1913 the tall Genie assistant card sits at the top of a column", tops)
    pg.set_viewport_size({"width": 1600, "height": 900}); pg.wait_for_timeout(300)
    pg.keyboard.press("Control+,"); pg.wait_for_timeout(200)
    dups = J(pg, "(()=>{const seen={},d=[];for(const e of document.querySelectorAll('[id]')){if(seen[e.id])d.push(e.id);seen[e.id]=1}return [...new Set(d)]})()")
    R.chk(all(x == "wv-i-info" for x in dups), "QS + Settings open together → no duplicate ids (besides the pre-existing wv-i-info symbol)", dups)
    J(pg, "const r=document.querySelector('#wv-panels input[data-wv-range=gsize]');r.value='110';r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))")
    R.chk(J(pg, "S.genieSize===110 && document.querySelector('#wv-panels [data-wv-rangeval=gsize]').textContent==='110%' && document.querySelector('#wv-qs [data-wv-rangeval=gsize]').textContent==='110%'"), "view slider updates its own label AND the QS copy re-renders (id-free)")
    J(pg, "S.genieSize=100;prefChanged();closeQS()")
    J(pg, "const f=document.querySelector('#wv-panels .wv-qs-fin');f.value='accent';f.dispatchEvent(new Event('input',{bubbles:true}))"); pg.wait_for_timeout(150)
    R.chk(J(pg, "[...document.querySelectorAll('#wv-panels .wv-set-grid .wv-qs-row')].filter(r=>getComputedStyle(r).display!=='none').length<6"), "Settings filter hides non-matching rows")
    J(pg, "const f=document.querySelector('#wv-panels .wv-qs-fin');f.value='';f.dispatchEvent(new Event('input',{bubbles:true}))")
    R.chk(J(pg, "document.querySelector('#wv-panels [data-wv-act=theme-set][data-d=light]').click(),S.theme==='light'"), "a control in the Settings view changes the pref")
    J(pg, "S.theme='dark';prefChanged()")
    close_all(pg)

def f_i18n(R, pg):
    R.feature = "i18n (5 languages, RTL)"
    close_all(pg)
    for lang, dir_, probe in [("fr-CA", "ltr", "Réglages"), ("es-MX", "ltr", "Ajustes"), ("ar", "rtl", "الإعدادات"), ("ja", "ltr", "設定"), ("en-US", "ltr", "Settings")]:
        J(pg, "l=>{S.lang=l;prefChanged()}", lang); pg.wait_for_timeout(250)
        R.chk(J(pg, "document.documentElement.lang") == lang and J(pg, "document.documentElement.dir") == dir_, "%s → html lang/dir=%s" % (lang, dir_))
        pg.keyboard.press("Control+k"); pg.fill("#wv-palInput", "wv:settings" if False else ""); pg.wait_for_timeout(150)
        R.chk(J(pg, "p=>[...document.querySelectorAll('#wv-palResults .wv-pr-name')].some(e=>e.textContent.includes(p))", probe), "%s: catalog name '%s' in the palette" % (lang, probe))
        pg.keyboard.press("Escape")
        R.chk(J(pg, "l=>i18nResolve('Quick settings')!==(l==='en-US'?null:'Quick settings')", lang), "%s: chrome label translation resolves" % lang)
    J(pg, "S.lang='ar';prefChanged()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "document.querySelector('#wv-podSession').getBoundingClientRect().left < document.querySelector('#wv-prodBtn').getBoundingClientRect().left"), "ar: header mirrored (session pod left of the lockup)")
    # 1.10.17 — every side-anchored surface opens on the reading side. In RTL the inline-end
    # edge is the LEFT one, so a drawer must arrive on the same side as the control that opened it.
    PANELS = ["#wv-qs", "#wv-adrawer", "#wv-ndrawer", "#wv-infoDock"]
    def panel_side(sel):
        return J(pg, """(s=>{const e=document.querySelector(s);if(!e)return null;
            const o=e.classList.contains("wv-open");e.classList.add("wv-open");
            const r=e.getBoundingClientRect(),cs=getComputedStyle(e);
            const side=r.left<=2?"left":(r.right>=innerWidth-2?"right":"mid");
            if(!o)e.classList.remove("wv-open");
            return {side:side,bl:parseFloat(cs.borderLeftWidth)||0,br:parseFloat(cs.borderRightWidth)||0}})""", sel)
    for sel in PANELS:
        g = panel_side(sel)
        R.chk(bool(g) and g["side"] == "left" and g["br"] > 0 and g["bl"] == 0,
              "ar: %s opens on the LEFT with its hairline on the right edge" % sel, g)
    R.chk(J(pg, "getComputedStyle(document.querySelector('#wv-infoDock .wv-id-grip')).right==='-3px'"), "ar: the info dock's resize grip moves to its inner (right) edge")
    J(pg, "S.lang='en-US';prefChanged()"); pg.wait_for_timeout(200)
    for sel in PANELS:
        g = panel_side(sel)
        R.chk(bool(g) and g["side"] == "right" and g["bl"] > 0 and g["br"] == 0,
              "en: %s stays on the RIGHT (LTR untouched)" % sel, g)

def f_presentation(R, pg):
    R.feature = "presentation mode"
    close_all(pg)
    for v in views_of_product(pg, 2): J(pg, "id=>openView(id)", v)
    J(pg, "presentEnter({interval:1000})"); pg.wait_for_timeout(200)
    R.chk(J(pg, "PRES.on && document.body.hasAttribute('data-wv-present') && getComputedStyle($('#wv-hdr')).display==='none' && getComputedStyle($('#wv-sidebar')).display==='none'"), "enter → chrome hidden (header + sidebar)")
    a0 = J(pg, "S.activeUid")
    # wait for the FIRST tick rather than a fixed delay: with two views an even number of ticks lands back on a0
    try: pg.wait_for_function("a0=>PRES.playing && S.activeUid!==a0", arg=a0, timeout=3000); moved = True
    except Exception: moved = False
    R.chk(moved, "auto-cycle advances the active view")
    # the next two checks test the break-through banner and the pointer relay — not the race against a frame that is
    # still loading under the cursor (hub: every tick swaps in an iframe). Pause the cycle and let the active frame settle first.
    J(pg, "presentPlay(false)")
    try: pg.wait_for_function("()=>{const f=document.querySelector('.wv-view.wv-active iframe, [data-uid] iframe');return !f||!!(window.EMB_FRAMES&&EMB_FRAMES[f.dataset.uid]&&EMB_FRAMES[f.dataset.uid].ready)||f.contentWindow&&f.contentDocument&&f.contentDocument.readyState==='complete'}", timeout=4000)
    except Exception: pass
    pg.wait_for_timeout(300)
    J(pg, "WV.raiseAlarm('crit','E2E present crit','P')")
    def _wait(expr, ms=4000):
        try: pg.wait_for_function(expr, timeout=ms); return True
        except Exception: return False
    # the banner carries the NEWEST critical: in the hub, product frames relay their own startup criticals moments after
    # loading, so accept either our alarm on the banner or a newer critical that has (correctly) replaced it
    ok = _wait("$('#wv-presAlarm').classList.contains('wv-show') && (/present crit/.test($('#wv-presAlarmMsg').textContent) || (S.alarms.some(a=>/present crit/.test(a.msg)) && S.alarms.find(a=>a.sev==='crit') && $('#wv-presAlarmMsg').textContent===S.alarms.find(a=>a.sev==='crit').msg))")
    R.chk(ok, "critical alarm breaks through as the slim banner", "" if ok else J(pg, "JSON.stringify({on:PRES.on,playing:PRES.playing,show:$('#wv-presAlarm').classList.contains('wv-show'),msg:$('#wv-presAlarmMsg').textContent,first:(S.alarms[0]||{}).msg,n:S.alarms.length,present:document.body.hasAttribute('data-wv-present')})"))
    # over PARENT CHROME: a point inside a product iframe receives no synthesised move at all
    # (measured: child 0, parent 0, with presentation mode on AND off - a harness limit).
    J(pg, "(()=>{const c=$('#wv-presentChip');if(c)c.classList.remove('wv-show')})()")
    pg.mouse.move(850, 6); pg.wait_for_timeout(80); pg.mouse.move(866, 11)
    R.chk(_wait("$('#wv-presentChip').classList.contains('wv-show')"), "mouse move shows the control chip")
    # and the presenter case: pointer activity INSIDE the dashboard raises the controls too,
    # which is where a presenter actually moves. Exercises the child -> parent relay.
    J(pg, "(()=>{const c=$('#wv-presentChip');if(c)c.classList.remove('wv-show')})()")
    _pf = next((x for x in pg.frames if "dashboards/" in x.url), None)
    if _pf is not None:
        _pf.evaluate("document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:120,clientY:120}))")
        R.chk(_wait("$('#wv-presentChip').classList.contains('wv-show')"),
              "…and pointer activity INSIDE a dashboard frame raises them too (relayed)")
    else:
        R.chk(True, "no product frame on this file — the in-frame relay does not apply")
    # Esc stops SPEECH before it touches any overlay or mode (1.9.4), so silence is part of a
    # known start state here exactly as it is for the drawer check below.
    J(pg, "if(typeof stopSpeaking==='function')stopSpeaking('e2e-clean')")
    R.chk(J(pg, "!(typeof voiceBusy==='function'&&voiceBusy())"), "…voice quiet before the Esc (Esc stops SPEECH first, by design)")
    pg.keyboard.press("Escape")
    escOk = _wait("!PRES.on && !document.body.hasAttribute('data-wv-present') && getComputedStyle($('#wv-hdr')).display!=='none'")
    # This failed in the FULL run and passed in isolation even after polling, so it is a STATE
    # difference, not a timing one - most likely an overlay left open by an earlier feature, which
    # Esc correctly closes FIRST. Say what was open instead of leaving the next reader guessing.
    R.chk(escOk, "Esc exits → chrome restored", "" if escOk else J(pg, """JSON.stringify({
        pres:PRES.on, present:document.body.hasAttribute('data-wv-present'), voiceBusy:(typeof voiceBusy==='function')?voiceBusy():null,
        hdr:getComputedStyle($('#wv-hdr')).display, uiBusy:(typeof WV!=="undefined"&&WV.uiBusy)?WV.uiBusy():null,
        openOverlays:['#wv-drop','#wv-qs','#wv-adrawer','#wv-ndrawer','#wv-keys','#wv-modal','#wv-pal','#wv-infoDock']
          .filter(id=>{const e=$(id);return e&&(e.classList.contains('wv-open')||e.classList.contains('wv-show'))}),
        info:document.body.dataset.wvInfo||null, genie:!!document.querySelector('.wv-genie-open')})"""))
    J(pg, "S.alarms.forEach(a=>a.acked=true);renderAlarms()")
    close_all(pg)

def f_info(R, pg):
    R.feature = "Info mode float + dock"
    close_all(pg); J(pg, "infoDockSet('float');toggleInfo(false)")
    J(pg, "document.querySelector('#wv-infoBtn').click()")
    R.chk(J(pg, "S.infoMode===true && document.body.hasAttribute('data-infomode') && $('#wv-infoBanner').classList.contains('wv-show') && $('#wv-infoBtn').classList.contains('wv-on')"), "ⓘ turns Info on (banner + active state + outlines)")
    pg.click("#wv-clock"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-drop').classList.contains('wv-open') && !!document.querySelector('#wv-drop .wv-info-card') && /Market clock/.test($('#wv-drop .wv-ic-t').textContent)"), "float: click a chrome element → floating card")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(250)   # press() returns on DISPATCH, not
    # after the handlers run - asserting immediately raced the shell and failed under load
    R.chk(J(pg, "!S.infoMode && !$('#wv-drop').classList.contains('wv-open')"), "Esc leaves Info mode and closes the card")
    J(pg, "document.querySelector('#wv-infoCaret').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "document.querySelectorAll('#wv-drop [data-wv-act=infodock-set]').length===2"), "caret opens the Floating/Docked chooser")
    J(pg, "document.querySelector('#wv-drop [data-wv-act=infodock-set][data-d=dock]').click()"); pg.wait_for_timeout(150)
    R.chk(J(pg, "S.infoDock==='dock' && S.infoMode && $('#wv-infoDock').classList.contains('wv-open') && document.body.hasAttribute('data-wv-infodock') && store.get('infoDock')==='dock'"), "choose Docked → panel opens, pref persisted, Info on")
    R.chk(J(pg, "parseInt(getComputedStyle($('#wv-main')).marginRight)>=340 && document.documentElement.scrollWidth<=innerWidth"), "page makes room (margin-right ≥ 340, no h-scroll)")
    pg.hover("#wv-genieBtn"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-infoDockT').textContent==='Genie assistant' && $('#wv-infoDockK').textContent==='header'"), "dock: hover fills title + kind chip")
    caps = J(pg, "[...document.querySelectorAll('#wv-infoDockBody .wv-id-cap')].map(e=>e.textContent)")
    R.chk(caps == ["In plain terms", "What it is", "Why it matters", "How it is calculated", "How to read it", "Healthy vs concerning", "If it looks wrong", "Terms used here", "Related"], "all 9 rich sections in fixed order", caps)
    R.chk(J(pg, "document.querySelectorAll('#wv-infoDockBody .wv-id-term').length>=2 && !!document.querySelector('#wv-infoDockBody .wv-id-hc.wv-ok')"), "terms rendered as pairs; healthy/concerning twin cards")
    pg.click("#wv-genieBtn"); pg.wait_for_timeout(300)
    R.chk(J(pg, "INFO_DOCK.pinned && $('#wv-infoDockPin').classList.contains('wv-on') && $('#wv-genieBtn').hasAttribute('data-wv-info-pinned') && !genieVisible()"), "dock: click PINS (solid outline), click intercepted (widget stays closed)")
    pg.hover("#wv-clock"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-infoDockT').textContent==='Genie assistant'"), "pinned panel ignores hover")
    J(pg, "document.querySelector('#wv-infoDockPin').click()")
    R.chk(J(pg, "!INFO_DOCK.pinned && !document.querySelector('[data-wv-info-pinned]')"), "pin button releases")
    pg.hover("#wv-connChip"); pg.wait_for_timeout(150)
    R.chk(J(pg, "$('#wv-infoDockT').textContent==='Realtime link'"), "hover follows again after release")
    J(pg, "S.lang='ja';prefChanged()"); pg.hover("#wv-connChip"); pg.wait_for_timeout(200)
    R.chk(J(pg, "[...document.querySelectorAll('#wv-infoDockBody .wv-id-cap')].some(e=>/[一-龥ぁ-ん]/.test(e.textContent))"), "section labels localized (ja)")
    J(pg, "S.lang='en-US';prefChanged()")
    J(pg, "openGenie()"); pg.wait_for_timeout(600)
    R.chk(J(pg, "genieVisible() && $('#wv-infoDock').classList.contains('wv-open')"), "chat widget + info dock coexist")
    J(pg, "closeGenie()")
    J(pg, "document.querySelector('#wv-infoDock [data-wv-act=info-close]').click()")
    R.chk(J(pg, "!S.infoMode && !$('#wv-infoDock').classList.contains('wv-open') && !document.body.hasAttribute('data-wv-infodock')"), "dock close × leaves Info mode")
    J(pg, "document.querySelector('#wv-infoDockGrip').dispatchEvent(new MouseEvent('dblclick'))")
    R.chk(J(pg, "INFO_DOCK.w===430"), "grip dblclick resets width to 430")
    pg.reload(); pg.wait_for_function("document.body.dataset.in==='1'", timeout=30000); widget_ready(pg)
    R.chk(J(pg, "S.infoDock==='dock'"), "presentation choice persists across reload")
    J(pg, "WV.info.present('float')"); R.chk(J(pg, "S.infoDock==='float' && WV.info.presentation()==='float'"), "WV.info.present('float') API")
    J(pg, "toggleInfo(false)")
    # facet fallback
    J(pg, "const d=document.createElement('div');d.id='e2eFacet';d.dataset.info='E2E Facet|plain text|read text|calc text|Healthy: good. Abnormal: bad.|related text';document.body.appendChild(d)")
    ent = J(pg, "infoEntryFor(document.getElementById('e2eFacet'))")
    R.chk(ent and ent["plain"] == "plain text" and ent["read"] == "read text" and ent["how"] == "calc text" and ent["healthy"].startswith("good") and ent["related"] == "related text", "data-info facets map to the dock sections (1→plain, 2→read, 3→how, 4→healthy/concerning, 5→related)", ent)
    J(pg, "document.getElementById('e2eFacet').remove()")

def f_keys_help(R, pg):
    R.feature = "keyboard shortcuts + Esc order + help menu + ticket"
    close_all(pg)
    J(pg, "closeQS();closePalette();closeModal();closeDrop();closeGenie();$('#wv-keys').classList.remove('wv-open');$('#wv-vcmds').classList.remove('wv-open');if(document.activeElement)document.activeElement.blur()")
    pg.keyboard.press("?"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-keys').classList.contains('wv-open') && document.querySelectorAll('#wv-keysGrid .wv-krow').length>=8"), "'?' opens the shortcuts sheet with the shell group")
    pg.keyboard.press("Escape"); R.chk(J(pg, "!$('#wv-keys').classList.contains('wv-open')"), "Esc closes it")
    J(pg, "WV.registerShortcuts([['E2E group',[[['Shift','Z'],'E2E action']]]])")
    J(pg, "document.querySelector('#wv-keysBtn').click()")
    R.chk(J(pg, "/E2E action/.test($('#wv-keysGrid').textContent)"), "WV.registerShortcuts contributes a product group to the sheet")
    J(pg, "$('#wv-keys').classList.remove('wv-open');delete PROD_KEYS[S.product]")
    # Esc order: open surfaces then Esc peels topmost first
    for v in views_of_product(pg, 2): J(pg, "id=>openView(id)", v)
    J(pg, "S.maximizedUid=S.open[0].uid;renderPanels();$('#wv-adrawer').classList.add('wv-open');$('#wv-ndrawer').classList.add('wv-open');renderQS();$('#wv-qs').classList.add('wv-open');$('#wv-keys').classList.add('wv-open');$('#wv-vcmds').classList.add('wv-open');openModal('<div>m</div>');openPalette();openDrop($('#wv-clock'),'<div>d</div>')")
    # Esc stops SPEECH before it touches any overlay (1.9.4), and in the hub a relayed alarm can
    # herald mid-sequence - which eats exactly one press and shifts the whole ladder by a step.
    # This asserts the ORDER, not the voice, so keep the voice out of it.
    J(pg, "if(typeof stopSpeaking==='function')stopSpeaking('e2e-clean')")
    R.chk(J(pg, "!(typeof voiceBusy==='function'&&voiceBusy())"), "…Esc-order run starts silent (Esc stops speech first, by design)")
    seq = []
    for step in range(9):
        J(pg, "if(typeof stopSpeaking==='function')stopSpeaking('e2e-clean')")  # no-op unless something started talking
        pg.keyboard.press("Escape"); pg.wait_for_timeout(60)
        seq.append(J(pg, "[$('#wv-drop').classList.contains('wv-open'),$('#wv-palette').classList.contains('wv-open'),$('#wv-modal').classList.contains('wv-open'),$('#wv-vcmds').classList.contains('wv-open'),$('#wv-keys').classList.contains('wv-open'),$('#wv-qs').classList.contains('wv-open'),$('#wv-ndrawer').classList.contains('wv-open'),$('#wv-adrawer').classList.contains('wv-open'),!!S.maximizedUid].map(x=>x?1:0).join('')"))
    R.chk(seq == ["011111111", "001111111", "000111111", "000011111", "000001111", "000000111", "000000011", "000000001", "000000000"], "Esc order drop→palette→modal→vcmds→keys→QS→notifications→alarms→maximize", seq)
    close_all(pg)
    pg.keyboard.press("Control+g"); pg.wait_for_timeout(600); R.chk(is_open(pg), "Ctrl+G opens the Genie widget")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(300); R.chk(not is_open(pg), "Esc closes the widget")
    J(pg, "document.querySelector('#wv-helpBtn').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "['whats-new','toast-new','info-mode','present-start','keys','vcmds'].every(a=>!!document.querySelector('#wv-drop [data-wv-act='+a+']'))"), "help menu lists what's new / about / info / presentation / keys / voice")
    J(pg, "document.querySelector('#wv-drop [data-wv-act=whats-new]').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-modal').classList.contains('wv-open') && /1\\.8\\.9/.test($('#wv-moBox').textContent)"), "What's new modal opens and lists 1.8.9")
    J(pg, "closeModal()")
    J(pg, "document.querySelector('#wv-ticketBtn')?document.querySelector('#wv-ticketBtn').click():ticketModal()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-modal').classList.contains('wv-open') && !!document.querySelector('#wv-tkSum')"), "Report an issue modal opens")
    pg.fill("#wv-tkSum", "E2E ticket"); J(pg, "document.querySelector('#wv-tkSev [data-v=high]').click();document.querySelector('[data-wv-act=ticket-send]').click()")
    R.chk(J(pg, "!$('#wv-modal').classList.contains('wv-open') && /TCK-\\d{4}/.test((S.notifs[0]||{}).msg||'')"), "ticket sends → notification with TCK id")
    # 1.9.0 — notifications drawer (right edge, alarm-drawer geometry)
    J(pg, "closeDrop();S.notifs.unshift({ts:Date.now()-86400000,msg:'E2E <b>yesterday</b> event',kind:'info',read:true});store.set('notifs',S.notifs);document.querySelector('#wv-notifBtn').click()"); pg.wait_for_timeout(120)
    R.chk(J(pg, "$('#wv-ndrawer').classList.contains('wv-open') && !$('#wv-drop').classList.contains('wv-open') && document.querySelectorAll('#wv-ndrawer .wv-nt-row').length>1"), "bell opens the notifications drawer (no dropdown)")
    R.chk(J(pg, "[...document.querySelectorAll('#wv-ndrawer .wv-nd-day .wv-dd-title')].map(e=>e.textContent.trim()).slice(0,2).join('|')==='Today|Yesterday'"), "rows grouped by day: Today, Yesterday")
    R.chk(J(pg, "!!document.querySelector('#wv-ndrawer .wv-nt-row[data-k] .wv-nt-dot') && /TCK-/.test(document.querySelector('#wv-ndrawer .wv-nt-row .wv-nt-msg').textContent) && /ago|now/i.test(document.querySelector('#wv-ndrawer .wv-nt-row .wv-nt-time').textContent)"), "row = kind dot + message with <b> + relative time")
    R.chk(J(pg, "$('#wv-ndrawer').contains(document.activeElement) && WV.uiBusy()"), "focus moves into the drawer; uiBusy true")
    R.chk(J(pg, "+$('#wv-notifBtn').dataset.n>0 && /unread/.test($('#wv-ndSummary').textContent)"), "unread badge + header count before the read timer")
    pg.wait_for_timeout(1800)
    R.chk(J(pg, "+$('#wv-notifBtn').dataset.n===0 && !document.querySelector('#wv-ndrawer .wv-nt-row.wv-unread') && document.querySelector('#wv-ndrawer [data-wv-act=notif-readall]').disabled"), "open 1.5 s → visible items marked read, badge cleared, Mark all read idle")
    J(pg, "notify('E2E <b>while open</b>','ok')"); pg.wait_for_timeout(120)
    R.chk(J(pg, "+$('#wv-notifBtn').dataset.n===1 && !!document.querySelector('#wv-ndrawer .wv-nt-row.wv-unread[data-k=ok]') && !document.querySelector('#wv-ndrawer [data-wv-act=notif-readall]').disabled"), "event while open → unread row + badge; Mark all read enabled")
    J(pg, "document.querySelector('#wv-ndrawer [data-wv-act=notif-readall]').click()")
    R.chk(J(pg, "+$('#wv-notifBtn').dataset.n===0 && !document.querySelector('#wv-ndrawer .wv-nt-row.wv-unread') && document.querySelector('#wv-ndrawer [data-wv-act=notif-readall]').disabled"), "Mark all read clears the badge")
    pg.keyboard.press("Tab"); pg.keyboard.press("Tab"); pg.keyboard.press("Tab")
    R.chk(J(pg, "$('#wv-ndrawer').contains(document.activeElement)"), "Tab keeps focus inside the drawer")
    J(pg, "$('#wv-adrawer').classList.add('wv-open');renderAlarms()"); J(pg, "closeNotif();openNotif()")
    R.chk(J(pg, "!$('#wv-adrawer').classList.contains('wv-open') && $('#wv-ndrawer').classList.contains('wv-open')"), "one right-edge surface: opening notifications closes the alarm drawer")
    J(pg, "document.querySelector('#wv-alarmBtn').click()")
    R.chk(J(pg, "$('#wv-adrawer').classList.contains('wv-open') && !$('#wv-ndrawer').classList.contains('wv-open')"), "…and the bell closes notifications")
    # uiBusy() is true while ANY overlay is open, and Esc closes only the TOP-MOST surface - so a
    # surface left open by an earlier feature fails this even when Esc did its job. Start clean and
    # assert that we are clean, so a failure here means the DRAWER, which is what this checks.
    J(pg, "closeQS();closeNotif();closeDrop&&closeDrop();$('#wv-adrawer').classList.remove('wv-open');if(typeof stopSpeaking==='function')stopSpeaking('e2e-clean');if(typeof closeGenie==='function')closeGenie();if(typeof closeModal==='function')closeModal();['#wv-keys','#wv-pal','#wv-infoDock'].forEach(id=>{const e=$(id);if(e){e.classList.remove('wv-open');e.classList.remove('wv-show')}});")
    R.chk(J(pg, "!WV.uiBusy() && !(typeof voiceBusy==='function'&&voiceBusy())"),
          "…start state for the Esc check is clean (no overlay open, voice quiet — Esc stops SPEECH first by design)")
    J(pg, "openNotif()"); pg.keyboard.press("Escape")
    escOk = wait(pg, "!$('#wv-ndrawer').classList.contains('wv-open') && !WV.uiBusy()", 4000)
    R.chk(escOk, "Esc closes the drawer; uiBusy false", "" if escOk else J(pg, """JSON.stringify({
        ndrawer:$('#wv-ndrawer').classList.contains('wv-open'), uiBusy:WV.uiBusy(),
        stillOpen:['#wv-drop','#wv-qs','#wv-adrawer','#wv-ndrawer','#wv-keys','#wv-modal','#wv-pal','#wv-infoDock']
          .filter(id=>{const e=$(id);return e&&(e.classList.contains('wv-open')||e.classList.contains('wv-show'))})})"""))
    R.chk(J(pg, "S.lang='ja';prefChanged();openNotif();const ok=/通知/.test($('#wv-ndrawer h3').textContent)&&/今日/.test(document.querySelector('#wv-ndrawer .wv-dd-title').textContent);S.lang='en-US';prefChanged();closeNotif();ok"), "i18n: drawer header + day groups translate (ja)")
    R.chk(J(pg, "typeof menuNotif==='function' && !document.querySelector('#wv-drop .wv-nt-row')"), "old dropdown path gone (guarded alias only)")
    J(pg, "S.notifs=S.notifs.filter(n=>!/E2E <b>yesterday/.test(n.msg));store.set('notifs',S.notifs);updateNotifBadge()")

def f_health_clock_time(R, pg):
    R.feature = "system health + market clock + time bus"
    sysid = J(pg, "(sysForProduct()[0]||{}).id")
    if sysid:
        J(pg, "id=>WV.setSystemState(id,'degraded')", sysid)
        R.chk(J(pg, "$('#wv-connLabel').textContent==='DEGRADED' && $('#wv-connChip').classList.contains('wv-degraded')"), "degraded system → chip DEGRADED")
        J(pg, "id=>WV.setSystemState(id,'stale')", sysid)
        R.chk(J(pg, "$('#wv-connLabel').textContent==='STALE' && $('#wv-connChip').classList.contains('wv-stale')"), "stale → chip STALE")
        J(pg, "document.querySelector('#wv-connChip').click()"); pg.wait_for_timeout(100)
        R.chk(J(pg, "document.querySelectorAll('#wv-drop .wv-sys-row').length===sysForProduct().length && /STALE/.test($('#wv-drop').textContent)"), "health popover lists every dependent system with state")
        J(pg, "closeDrop()")
        J(pg, "id=>WV.setSystemState(id,'live')", sysid)
        R.chk(J(pg, "(sysForProduct().every(s=>s.state==='live')) ? $('#wv-connLabel').textContent==='SYSTEM' : $('#wv-connLabel').textContent!=='STALE'"), "back to live → SYSTEM")
    t0 = J(pg, "$('#wv-clockT').textContent")
    try: pg.wait_for_function("t0=>$('#wv-clockT').textContent!==t0", arg=t0, timeout=4000); adv = True
    except Exception: adv = False
    R.chk(adv, "market clock advances")
    J(pg, "S.tzPref='PPT';prefChanged()")
    R.chk(J(pg, "$('#wv-clockZ').textContent.trim()==='PPT' && /PPT/.test($('#wv-stStamp').textContent)"), "time zone pref → clock zone + status stamp")
    J(pg, "S.tzPref='EPT';prefChanged()")
    # time bus
    close_all(pg)
    sub = J(pg, "visibleCatalog().find(v=>TIMESUBS.has(v.id)&&v.openMode==='inline')")
    if sub:
        J(pg, "window.__wvTime=[];document.addEventListener('wv:time',e=>window.__wvTime.push(e.detail.hour))")
        J(pg, "id=>openView(id)", sub["id"]); pg.wait_for_timeout(400)
        R.chk(J(pg, "WVTime.active && document.body.hasAttribute('data-timescrub')"), "a subscribed view shows the shared-hour scrubber")
        h0 = J(pg, "WVTime.hour")
        J(pg, "document.querySelector('#wv-stTime [data-wv-act=time-step][data-d=\"1\"]').click()")
        R.chk(J(pg, "WVTime.hour") == (h0 + 1) % 24 and J(pg, "$('#wv-stTimeHour').textContent") == "HE %02d" % ((h0 + 1) % 24), "step +1 → HE label")
        R.chk(J(pg, "window.__wvTime.length>=1 && window.__wvTime[window.__wvTime.length-1]===WVTime.hour"), "wv:time subscribers receive the hour")
        J(pg, "wvTimePlay(true)"); pg.wait_for_timeout(1700); J(pg, "wvTimePlay(false)")
        R.chk(J(pg, "WVTime.hour") != (h0 + 1) % 24, "play advances the hour")
        J(pg, "document.querySelector('#wv-stTime [data-wv-act=time-off]').click()")
        R.chk(J(pg, "!WVTime.active && WVTime.userOff"), "scrubber close hides it (userOff)")
        close_all(pg)
    else:
        R.chk(True, "no time-bus subscriber view in this catalog (skipped)")

def f_product_switch(R, pg):
    R.feature = "product switch + accents"
    n = J(pg, "PRODUCTS.length")
    # restored at the end: this step switches product to prove the re-brand, and everything
    # after it inherited whatever it left (the embed step was embedding dlr, not the landing
    # product). Third and final site of the hand-back defect.
    S_ENTER = J(pg, "S.product")
    J(pg, "document.querySelector('#wv-prodBtn').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "document.querySelectorAll('#wv-drop [data-wv-act=prod-set]').length") == n, "lockup dropdown lists %d product(s)" % n)
    if n > 1:
        # a product whose accent genuinely DIFFERS, else the re-brand cannot show. Most of the
        # fleet shares #bb93ff; picking "the next product" compares violet with violet.
        other = J(pg, """(()=>{const me=prodObj();
            const d=PRODUCTS.find(p=>p.id!==S.product&&p.accent&&me&&p.accent!==me.accent);
            return (d||PRODUCTS.find(p=>p.id!==S.product)).id})()""")
        ACC_DIFFERS = J(pg, "p=>{const me=prodObj(),o=PRODUCTS.find(x=>x.id===p);return !!(me&&o&&o.accent&&me.accent&&o.accent!==me.accent)}", other)
        acc0 = J(pg, "getComputedStyle(document.documentElement).getPropertyValue('--wv-acc').trim()")
        J(pg, "id=>document.querySelector('#wv-drop [data-wv-act=prod-set][data-id=\"'+id+'\"]').click()", other); pg.wait_for_timeout(600)
        R.chk(J(pg, "S.product") == other and J(pg, "document.documentElement.dataset.product") == other, "switch product via dropdown")
        R.chk(J(pg, "document.title") == "OATI " + J(pg, "prodObj().name"), "tab title follows the product")
        acc1 = J(pg, "getComputedStyle(document.documentElement).getPropertyValue('--wv-acc').trim()")
        R.chk((acc1 != acc0) if ACC_DIFFERS else (acc1 == acc0),
              "accent re-brands with the product (auto)" if ACC_DIFFERS
              else "every product shares one accent — it correctly stays put across a switch",
              [acc0, acc1, other])
    else:
        J(pg, "closeDrop()")
        R.chk(J(pg, "document.documentElement.dataset.product===S.product"), "single product: html[data-product] set")
    # hand the run back on the product it was entered on
    J(pg, """p=>{if(S.product!==p){S.product=p;prefChanged()}
        const v=S.catalog.find(x=>x.product===p&&!x.shell&&x.openMode!=='popout');
        for(const i of S.open.slice())closeInst(i.uid);
        if(v)openView(v.id);renderAll()}""", S_ENTER)
    wait(pg, "S.product===%r" % S_ENTER, 30000); pg.wait_for_timeout(1200)
    R.chk(J(pg, "p=>S.product===p", S_ENTER),
          "the product-switch feature hands the run back on the product it was entered on", S_ENTER)

def f_embed_protocol(R, pg):
    R.feature = "embed protocol (#wv-embed)"
    vid = views_of_product(pg, 1)[0]
    J(pg, """id=>{window.__emsg=[];window.addEventListener('message',e=>{if(e.data&&e.data.wv)window.__emsg.push(e.data)});
      const f=document.createElement('iframe');f.id='e2eEmbed';f.style.cssText='position:fixed;left:0;top:0;width:600px;height:400px;z-index:0';
      f.src=embedURL(id,7);document.body.appendChild(f)}""", vid)
    ok = wait(pg, "window.__emsg.some(m=>m.wv==='ready')", 30000)
    R.chk(ok, "child posts {wv:'ready', viewId}", J(pg, "window.__emsg.find(m=>m.wv==='ready')"))
    fr = next((f for f in pg.frames if "inst=7" in f.url), None)
    R.chk(fr is not None and fr.evaluate("document.body.classList.contains('wv-embed') && EMB.on && EMB.inst.inst===7 && !!document.querySelector('#wv-embedRoot')"), "child boots chromeless with inst=7")
    R.chk(fr.evaluate("window.EMB===EMB"), "window.EMB exposed for product guards (1.7.1)")
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'theme',theme:'light',density:'comfortable',scale:1.1,accent:'#00aa88'},'*')"); pg.wait_for_timeout(300)
    R.chk(fr.evaluate("document.documentElement.dataset.theme==='light'&&S.density==='comfortable'&&S.scale===110"), "{wv:'theme'} adopts theme/density/scale")
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'time',hour:5},'*')"); pg.wait_for_timeout(200)
    R.chk(fr.evaluate("WVTime.hour===5&&WVTime.active"), "{wv:'time'} sets the child hour")
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'prefs',locale:'fr-CA',tzLabel:'UTC',timeFormat:'12'},'*')"); pg.wait_for_timeout(200)
    R.chk(fr.evaluate("S.lang==='fr-CA'&&S.tzPref==='UTC'&&S.timeFormat==='12'"), "{wv:'prefs'} adopts preferences")
    n0 = J(pg, "S.alarms.length")
    fr.evaluate("WV.raiseAlarm('maj','E2E embed alarm','EmbedSrc');WV.setSystemState((sysForProduct()[0]||{}).id||'x','degraded')"); pg.wait_for_timeout(300)
    R.chk(J(pg, "window.__emsg.some(m=>m.wv==='alarm'&&m.msg==='E2E embed alarm')"), "child forwards WV.raiseAlarm as {wv:'alarm'}")
    R.chk(J(pg, "window.__emsg.some(m=>m.wv==='system')"), "child forwards WV.setSystemState as {wv:'system'}")
    # info protocol (1.8.9)
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'info',on:true,mode:'dock'},'*')"); pg.wait_for_timeout(300)
    R.chk(fr.evaluate("S.infoMode===true&&S.infoDock==='dock'&&document.body.hasAttribute('data-infomode')&&!$('#wv-infoDock').classList.contains('wv-open')&&getComputedStyle($('#wv-infoBanner')).display==='none'"), "{wv:'info' dock} → child Info on, NO own dock/banner")
    fr.evaluate("(()=>{const d=document.createElement('div');d.id='e2eF';d.dataset.info='Embed Facet|plain|read|calc|Healthy: a. Abnormal: b.|rel';document.querySelector('#wv-embedRoot').appendChild(d);d.dispatchEvent(new MouseEvent('mouseover',{bubbles:true}))})()"); pg.wait_for_timeout(200)
    # NOT the injected title: a product that registers a CSS-selector entry resolves the whole
    # ancestor chain to its OWN region, and a registered selector beats an element's own
    # data-info by contract (measured: dlr answers every hover with "Dynamic Line Ratings").
    # The property here is the PROTOCOL; the pipe-facet parsing is asserted in f_info and in
    # the framework deep run, where no product resolver competes.
    R.chk(J(pg, """(()=>{const m=window.__emsg.filter(x=>x.wv==='info-item').pop();
        return !!m&&typeof m.title==='string'&&m.title.length>1&&!!m.sections
               &&Object.values(m.sections).some(v=>typeof v==='string'&&v.trim().length>0)
               &&m.pinned===false})()"""),
          "child hover posts {wv:'info-item'} with sections (unpinned)",
          J(pg, "(window.__emsg.filter(x=>x.wv==='info-item').pop()||{}).title"))
    fr.evaluate("document.getElementById('e2eF').click()"); pg.wait_for_timeout(200)
    # the pin lands on whichever element the child RESOLVED, which need not be the injected one
    R.chk(J(pg, "(window.__emsg.filter(m=>m.wv==='info-item').pop()||{}).pinned===true")
          and fr.evaluate("!!document.querySelector('[data-wv-info-pinned]')"),
          "child click posts pinned:true + solid outline")
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'info',on:true,mode:'dock',pin:false},'*')"); pg.wait_for_timeout(200)
    R.chk(fr.evaluate("!INFO_DOCK.pinned&&!document.querySelector('[data-wv-info-pinned]')"), "{wv:'info', pin:false} releases the child's pin")
    fr.evaluate("document.documentElement.dispatchEvent(new MouseEvent('mouseleave'))"); pg.wait_for_timeout(150)
    R.chk(J(pg, "window.__emsg.some(m=>m.wv==='info-clear')"), "pointer leaving the frame posts {wv:'info-clear'}")
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'info',on:true,mode:'float'},'*')"); pg.wait_for_timeout(200)
    R.chk(fr.evaluate("S.infoDock==='float'&&!document.body.hasAttribute('data-wv-infodock')"), "{wv:'info' float} → child presents its own card (no dock marker)")
    J(pg, "toggleInfo(true)"); pg.wait_for_timeout(200)
    fr.evaluate("document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}))"); pg.wait_for_timeout(300)
    R.chk(J(pg, "window.__emsg.some(m=>m.wv==='info-exit') && !S.infoMode") and fr.evaluate("!S.infoMode"), "Esc inside the child posts {wv:'info-exit'} → parent leaves Info mode (both off)")
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'info',on:true,mode:'float'},'*')"); pg.wait_for_timeout(200)
    J(pg, "document.getElementById('e2eEmbed').contentWindow.postMessage({wv:'info',on:false,mode:'float'},'*')"); pg.wait_for_timeout(200)
    R.chk(fr.evaluate("S.infoMode===false&&!document.body.hasAttribute('data-infomode')&&!document.querySelector('[data-wv-info-pinned]')"), "{wv:'info' off} → no outlines left in the child")
    J(pg, "document.getElementById('e2eEmbed').remove();S.alarms.forEach(a=>a.acked=true);renderAlarms()")
    J(pg, "for(const pid in S.sysHealth)S.sysHealth[pid].forEach(s=>s.state='live');updateConnChip()")

def f_widget(R, pg, ctx):
    R.feature = "chat widget integration"
    close_all(pg); widget_ready(pg)
    J(pg, "closeModal();closeQS();closeDrop();closePalette();closeGenie();heraldClear();S.alarms=[];renderAlarms()")
    pg.click("#wv-genieBtn"); pg.wait_for_timeout(700)
    R.chk(is_open(pg), "lamp opens the widget (no carried event)")
    R.chk(J(pg, "[...document.querySelectorAll('.genie-widget-scope [style*=\"z-index\"]')].some(e=>getComputedStyle(e).zIndex==='100090')"), "panel lifted to z 100090")
    # settings popover / channel menu portals lifted above the panel (1.8.1)
    lifted = J(pg, """(()=>{const find=re=>[...document.querySelectorAll('.genie-widget-scope button')].find(x=>re.test(x.getAttribute('aria-label')||x.title||x.textContent));
      const show=find(/show sidebar/i);if(show)show.click();
      const b=find(/sidebar settings|settings/i);if(!b)return 'no-settings-button';b.click();return 'clicked'})()""")
    pg.wait_for_timeout(500)
    z = J(pg, "[...document.body.children].filter(e=>!genieIsShellNode(e)&&e.tagName!=='OATI-GENIE-CHAT-WIDGET'&&/fixed|absolute/.test(getComputedStyle(e).position)).map(e=>getComputedStyle(e).zIndex)")
    R.chk(lifted == "clicked" and ("100095" in z), "Settings popover portal lifted to z 100095 (interactive)", [lifted, z])
    pg.keyboard.press("Escape"); pg.wait_for_timeout(200)
    if not is_open(pg): J(pg, "openGenie()"); pg.wait_for_timeout(400)
    J(pg, "WV.demo.alarmStorm(5)"); pg.wait_for_timeout(500)
    d = J(pg, "JSON.parse(JSON.stringify(document.querySelector('oati-genie-chat-widget').deskContent,(k,v)=>typeof v==='function'?'[fn]':v))")
    items = d.get("items", [])
    R.chk(len(items) == 5, "alarmStorm(5) → 5 Desk Active-risk items", len(items))
    exp = {"crit": "severe", "maj": "warning", "minr": "attention", "info": "info"}
    sevs = J(pg, "S.alarms.filter(a=>!a.acked).map(a=>[a.id,a.sev,a.src])")
    R.chk(all(next((i for i in items if i["id"] == "alarm:" + a[0]), {}).get("status", {}).get("tone") == exp[a[1]] for a in sevs), "tones crit→severe / maj→warning / minr→attention / info→info")
    R.chk(all(next((i for i in items if i["id"] == "alarm:" + a[0]), {}).get("channelLabel") == a[2] for a in sevs), "channelLabel = alarm source")
    J(pg, "id=>{const a=S.alarms.find(x=>x.id===id);a.acked=true;renderAlarms()}", sevs[0][0]); pg.wait_for_timeout(400)
    R.chk(J(pg, "document.querySelector('oati-genie-chat-widget').deskContent.items.length===4"), "ack in the shell removes the Desk item")
    sysid = J(pg, "(sysForProduct()[0]||{}).id")
    if sysid:
        J(pg, "id=>WV.setSystemState(id,'degraded')", sysid); pg.wait_for_timeout(400)
        R.chk(J(pg, "(document.querySelector('oati-genie-chat-widget').deskContent.monitoringItems||[]).some(i=>i.status.tone==='attention')"), "degraded system → Monitoring item (attention)")
        J(pg, "id=>WV.setSystemState(id,'live')", sysid); pg.wait_for_timeout(400)
        R.chk(J(pg, "!('monitoringCount' in document.querySelector('oati-genie-chat-widget').deskContent)"), "live again → Monitoring section gone")
    J(pg, "WV.genie.desk.add({id:'e2e-host',title:'E2E host item',tone:'severe'})"); pg.wait_for_timeout(400)
    R.chk(J(pg, "document.querySelector('oati-genie-chat-widget').deskContent.items[0].id==='e2e-host'"), "WV.genie.desk.add → host item first")
    J(pg, "WV.genie.desk.remove('e2e-host')")
    R.chk(J(pg, "(()=>{WV.genie.alert({id:'e2e-al',headline:'E2E alert',description:'d',severity:'high'});return true})()"), "WV.genie.alert accepted")
    pg.wait_for_timeout(400)
    R.chk(J(pg, "/E2E alert/.test([...document.querySelectorAll('.genie-widget-scope')].map(e=>e.innerText).join(' '))"), "alert visible in the widget")
    J(pg, "WV.genie.dismissAlert('e2e-al')")
    J(pg, "S.theme='light';prefChanged()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "document.documentElement.getAttribute('data-genie-theme')==='light'"), "theme follows the shell (light)")
    J(pg, "S.theme='dark';prefChanged()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "document.documentElement.getAttribute('data-genie-theme')==='dark'"), "…and dark")
    R.chk(J(pg, "WV.genie.register(()=>'x')===false"), "WV.genie.register is a documented no-op")
    with ctx.expect_page(timeout=15000) as pi:
        J(pg, "window.__GENIE_WIDGET__.popOut()")
    pop = pi.value; R.attach(pop); pg.wait_for_timeout(600)
    R.chk(pop is not None and "Genie" in (pop.title() or "Genie"), "widget popOut opens its own window")
    J(pg, "window.__GENIE_WIDGET__.popIn()"); pg.wait_for_timeout(500)
    R.chk(J(pg, "!!document.querySelector('oati-genie-chat-widget')"), "popIn returns")
    J(pg, "closeGenie();S.alarms.forEach(a=>a.acked=true);renderAlarms()")

def f_reset_logout(R, pg, ctx):
    R.feature = "reset preferences + sign-out cleanup + sessions"
    J(pg, "S.theme='light';S.density='comfortable';S.scale=110;S.bg='slate';S.loginBrief='none';prefChanged()")
    J(pg, "toggleQS();document.querySelector('#wv-qs [data-wv-act=qs-reset]').click()"); pg.wait_for_timeout(100)
    R.chk(J(pg, "$('#wv-modal').classList.contains('wv-open') && !!document.querySelector('[data-wv-act=qs-reset-do]')"), "Reset asks for confirmation")
    J(pg, "document.querySelector('[data-wv-act=qs-reset-do]').click()")
    # wait for the reset to settle instead of a fixed pause: in the hub, prefChanged re-themes every live frame first
    try: pg.wait_for_function("S.theme==='dark'&&S.density==='compact'&&S.scale===100&&S.bg==='graphite'&&S.motionPref==='auto'&&S.genieRing==='violet'&&S.infoDock==='float'&&S.loginBrief==='read'&&S.greadTwinkle===25&&S.alarmSumm===false&&store.get('session')===null", timeout=3000); ok = True
    except Exception: ok = False
    R.chk(ok, "defaults restored (incl. loginBrief=read, 1.9.4; Dot shimmer 25%, 1.9.8; Summarize alarms Off, 1.9.11) + saved session cleared", "" if ok else J(pg, "JSON.stringify({theme:S.theme,density:S.density,scale:S.scale,bg:S.bg,brief:S.loginBrief,tw:S.greadTwinkle,session:store.get('session')})"))
    J(pg, "closeQS()")
    # sign-out
    vids = views_of_product(pg, 1)
    with ctx.expect_page(timeout=15000) as pi:
        J(pg, "id=>popOut(id)", vids[0])
    pop = pi.value; R.attach(pop); wait(pg, "S.popouts[0]&&S.popouts[0].ready", 20000)
    J(pg, "WV.raiseAlarm('maj','pre-logout','x');$('#wv-adrawer').classList.add('wv-open');toast('lingering')")
    J(pg, "doLogout()"); pg.wait_for_timeout(500)
    R.chk(J(pg, "document.body.dataset.in==='' && getComputedStyle($('#wv-login')).display!=='none'"), "sign-out → login page")
    R.chk(J(pg, "S.popouts.length===0") and pop.is_closed(), "popouts closed on sign-out")
    R.chk(J(pg, "document.querySelector('oati-genie-chat-widget')===null"), "chat widget unmounted on sign-out")
    R.chk(J(pg, "!$('#wv-adrawer').classList.contains('wv-open') && $('#wv-toasts').children.length===0 && !sessionStorage.getItem(AUTH.KEY) && !localStorage.getItem(AUTH.KEY)"), "drawer closed, toasts cleared, session record cleared")
    # sessions (1.7.5)
    login(pg, remember=False); widget_ready(pg)
    p2 = ctx.new_page(); R.attach(p2); p2.goto(R.url); p2.wait_for_timeout(1500)
    R.chk(p2.evaluate("document.body.dataset.in!=='1'"), "new tab with a TAB session → login page")
    p2.close()
    J(pg, "doLogout()"); login(pg, remember=True); widget_ready(pg)
    R.chk(J(pg, "!!localStorage.getItem(AUTH.KEY)"), "remember me → localStorage record")
    p3 = ctx.new_page(); R.attach(p3); p3.goto(R.url); wait(p3, "document.body.dataset.in==='1'", 20000)
    R.chk(p3.evaluate("document.body.dataset.in==='1'"), "new tab with a REMEMBERED session → signed in")
    p3.close()
    J(pg, "(()=>{const r=JSON.parse(localStorage.getItem(AUTH.KEY));r.exp=Date.now()-1000;localStorage.setItem(AUTH.KEY,JSON.stringify(r))})()")
    pg.reload(); pg.wait_for_selector("#wv-la-u", state="attached", timeout=60000); pg.wait_for_timeout(800)  # a hub reload re-mounts frames
    R.chk(J(pg, "document.body.dataset.in!=='1' && !localStorage.getItem(AUTH.KEY)"), "expired record → login page, record dropped")
    login(pg, remember=False); widget_ready(pg)

# ================================================================== Genie's scope (1.13.0)
def f_genie_scope(R, pg):
    """Which dashboards Genie is allowed to SPEAK about - the sign-in briefing, the herald island and
    its voice, and the alarm toast. Plus 1.13.0's other half: the briefing reads from the scope that
    is showing (Global or Local), which it did not before."""
    R.feature = "Genie's scope + briefing scope (1.13.0)"
    R.chk(J(pg, "typeof genieCovers==='function' && typeof genieScopeAll==='function' && typeof alarmProduct==='function' && typeof menuGenieScope==='function' && Array.isArray(PREF_DEFAULTS.genieScope)"),
          "1.13.0 surface: genieCovers / genieScopeAll / alarmProduct / menuGenieScope, genieScope in the defaults")
    R.chk(J(pg, "genieScopeAll() && genieCovers('anything')"), "empty scope = every dashboard (the shipped default)")
    R.chk(J(pg, "genieCovers(null) && genieCovers('')"), "items with no dashboard of their own are always in scope")
    # the control
    J(pg, "toggleQS()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "!!document.querySelector('#wv-qs [data-wv-act=gscope-menu]')"), "Quick Settings carries the 'Genie speaks about' control")
    J(pg, "document.querySelector('#wv-qs [data-wv-act=gscope-menu]').click()"); pg.wait_for_timeout(300)
    nprod = J(pg, "PRODUCTS.length")
    R.chk(J(pg, "document.querySelectorAll('#wv-drop [data-wv-act=gscope-toggle]').length") == nprod
          and J(pg, "!!document.querySelector('#wv-drop [data-wv-act=gscope-all]')"),
          "the dropdown is a multi-select: one row per dashboard (%d) + All dashboards" % nprod)
    if nprod > 1:
        pid = J(pg, "PRODUCTS[0].id")
        J(pg, "id=>document.querySelector('#wv-drop [data-wv-act=gscope-toggle][data-id='+JSON.stringify(id)+']').click()", pid)
        pg.wait_for_timeout(250)
        R.chk(J(pg, "$('#wv-drop').classList.contains('wv-open')"),
              "picking does NOT close it - a multi-select that closed on each tick would be reopened once per dashboard")
        pid2 = J(pg, "PRODUCTS[1].id")
        J(pg, "id=>document.querySelector('#wv-drop [data-wv-act=gscope-toggle][data-id='+JSON.stringify(id)+']').click()", pid2)
        pg.wait_for_timeout(250)
        R.chk(J(pg, "S.genieScope.length===2"), "picks accumulate", J(pg, "JSON.stringify(S.genieScope)"))
        J(pg, "document.querySelector('#wv-drop [data-wv-act=gscope-all]').click()"); pg.wait_for_timeout(250)
        R.chk(J(pg, "genieScopeAll()"), "All dashboards clears the scope")
    else:
        R.chk(True, "single-product file: scoping is a no-op by construction, control still present")
    J(pg, "closeDrop();closeQS()")
    # filtering, where there is more than one product to filter
    if nprod > 1:
        pid = J(pg, "PRODUCTS[0].id"); other = J(pg, "PRODUCTS[1].id")
        n_before = J(pg, "S.alarms.length")
        J(pg, "p=>{S.genieScope=[p];persist();document.dispatchEvent(new CustomEvent('wv:genie-scope',{detail:{scope:[p]}}))}", pid)
        pg.wait_for_timeout(900)
        R.chk(J(pg, "a=>genieCovers(a[0])&&!genieCovers(a[1])", [pid, other]),
              "the scoped dashboard is covered and the others are not")
        R.chk(J(pg, """a=>{HERALD.queue.length=0;
                 herald({kind:'alarm',sev:'crit',product:a[1],text:'out'});const n0=HERALD.queue.length;
                 herald({kind:'alarm',sev:'crit',product:a[0],text:'in'});const n1=HERALD.queue.length;
                 HERALD.queue.length=0;return n0===0&&n1===1}""", [pid, other]),
              "an out-of-scope alarm never reaches the herald; an in-scope one passes through")
        R.chk(J(pg, "S.alarms.length") == n_before,
              "the alarm DRAWER is not filtered - an operations console must never hide an alarm from the record", n_before)
        R.chk(J(pg, "S.alarms.filter(a=>!a.acked&&genieCovers(alarmProduct(a))).length <= S.alarms.filter(a=>!a.acked).length"),
              "what Genie would announce is a SUBSET of the drawer, never more than it")
        J(pg, "S.genieScope=[];persist();document.dispatchEvent(new CustomEvent('wv:genie-scope',{detail:{scope:[]}}))")
        pg.wait_for_timeout(600)
    # the briefing reads from the SHOWING scope (the CEO's second report)
    vid = J(pg, "(S.open[0]||{}).viewId||(S.catalog.find(v=>v.product===S.product&&!v.shell)||{}).id")
    if vid:
        J(pg, "id=>{if(!S.open.some(i=>i.viewId===id))openView(id);}", vid); pg.wait_for_timeout(600)
        # the hub roster OWNS the product bag and would overwrite these on its next tick - park it
        J(pg, "if(window.WV_HUB_GREAD)window.WV_HUB_GREAD.paused=true")
        J(pg, """id=>{WV.genieRead.set({product:S.product,reads:[{headline:'GLOBALMARK one',summary:'g'}]});
                     WV.genieRead.set({product:S.product,view:id,reads:[{headline:'LOCALMARK one',summary:'l'}]})}""", vid)
        pg.wait_for_timeout(500)
        J(pg, "setGreadScope('global')"); pg.wait_for_timeout(250)
        R.chk(J(pg, "briefItems('read').items.some(i=>/GLOBALMARK/.test(i.text))&&!briefItems('read').items.some(i=>/LOCALMARK/.test(i.text))"),
              "Global scope: the briefing speaks the GLOBAL reads")
        J(pg, "setGreadScope('view')"); pg.wait_for_timeout(250)
        R.chk(J(pg, "briefItems('read').items.some(i=>/LOCALMARK/.test(i.text))&&!briefItems('read').items.some(i=>/GLOBALMARK/.test(i.text))"),
              "Local scope: the briefing speaks the LOCAL reads (1.13.0 - it always read Global before)")
        J(pg, "briefItems('read').items[0].open()"); pg.wait_for_timeout(400)
        R.chk(J(pg, "S.greadScope==='view'"), "opening a briefed Local card leaves the band on Local")
        J(pg, "id=>WV.genieRead.clear(S.product,id)", vid); pg.wait_for_timeout(300)
        R.chk(J(pg, "briefItems('read').items.length===0"),
              "an empty Local scope says nothing new rather than borrowing Global's reads")
        J(pg, "setGreadScope('global')")

# ================================================================== mode group (1.11.0)
def f_modes(R, pg, ctx):
    """The generic MODE GROUP control at the far right of the tab row: it appears ONLY for a
    product that declared one, marks the active mode, switches IN PLACE (no new tab, no second
    instance), degrades label->icon->menu as the row tightens without ever crushing the tabs,
    and mirrors to the left under RTL."""
    R.feature = "mode group (1.11.0)"
    # the product the run was HANDED to us on. Restored at the end - PRODUCTS[0] is
    # registration order (dlr on the hub) and is NOT the landing product (der).
    P_ENTER = J(pg, "S.product")
    R.chk(J(pg, "typeof WV.registerModes==='function' && typeof modeGo==='function' && typeof fitModeGroup==='function' && typeof MODEGRP==='object'"),
          "1.11.0 surface: WV.registerModes / modeGo / fitModeGroup / MODEGRP")
    decl = J(pg, "Object.keys(MODEGRP)")
    if not decl:
        R.chk(True, "no product on this file declares a mode group — control stays hidden")
        R.chk(J(pg, "document.querySelector('#wv-modes').dataset.on!=='1'"), "…and #wv-modes is not shown")
        return
    pid = decl[0]
    # --- only declared products show it: prove the OTHER products' rows are unchanged
    others = J(pg, "d=>PRODUCTS.map(p=>p.id).filter(x=>d.indexOf(x)<0)", decl)
    if others:
        prev = J(pg, "S.product")
        J(pg, "p=>{S.product=p;prefChanged();renderAll()}", others[0])
        pg.wait_for_timeout(500)
        R.chk(J(pg, "document.querySelector('#wv-modes').dataset.on!=='1' && document.querySelector('#wv-modes').innerHTML===''"),
              "a product that declares NO modes shows nothing there (%s)" % others[0])
        J(pg, "p=>{S.product=p;prefChanged();renderAll()}", prev); pg.wait_for_timeout(400)
    else:
        R.chk(True, "every registered product declares modes on this file")
    J(pg, "p=>{if(S.product!==p){S.product=p;prefChanged();renderAll()}}", pid)
    modes = J(pg, "p=>MODEGRP[p].modes.map(m=>m.viewId)", pid)
    J(pg, "v=>{for(const i of S.open.slice())closeInst(i.uid);openView(v)}", modes[0])
    wait(pg, "S.open.length===1", 20000); pg.wait_for_timeout(1200)
    R.chk(J(pg, "document.querySelector('#wv-modes').dataset.on==='1' && document.querySelectorAll('#wv-modes .wv-mg-chip').length===%d" % len(modes)),
          "the control appears for the declaring product with one chip per mode (%d)" % len(modes))
    # --- two-zone geometry: right of the arrangement control, inside the row, 24px track in a 36px row
    g = J(pg, """(()=>{const r=e=>{const b=document.querySelector(e).getBoundingClientRect();return {l:Math.round(b.left),r:Math.round(b.right),h:Math.round(b.height)}};
        const bar=document.querySelector('#wv-tabbar'),cs=getComputedStyle(bar);
        return {mg:r('#wv-modes'),lay:r('#wv-layBtn'),strip:r('#wv-tabstrip'),
          inner:[Math.round(bar.getBoundingClientRect().left+parseFloat(cs.paddingLeft)),Math.round(bar.getBoundingClientRect().right-parseFloat(cs.paddingRight))],
          track:r('#wv-modes .wv-mg-track'),sep:r('#wv-modes .wv-mg-sep'),barH:Math.round(bar.getBoundingClientRect().height)}})()""")
    R.chk(g["mg"]["l"] >= g["lay"]["r"], "the group sits to the RIGHT of the arrangement control", g)
    R.chk(g["mg"]["r"] <= g["inner"][1] + 1 and g["strip"]["r"] <= g["mg"]["l"], "it stays inside the row and never overlaps the tab strip", g)
    # 1.14.1 - the CEO reversed the two-zone ruling: the mode entries now wear the TAB shape so the
    # row reads as one uniform strip. Assert THAT, and then assert the thing the uniform look makes
    # risky - that they are still not real tabs underneath.
    geo = J(pg, """(()=>{const c=document.querySelector('#wv-modes .wv-mg-chip');
        const t=document.querySelector('#wv-tabstrip .wv-tab'); if(!c||!t)return null;
        const rc=c.getBoundingClientRect(),rt=t.getBoundingClientRect();
        return {chipH:Math.round(rc.height),tabH:Math.round(rt.height),
                chipTop:Math.round(rc.top),tabTop:Math.round(rt.top),
                chipRad:getComputedStyle(c).borderRadius,tabRad:getComputedStyle(t).borderRadius,
                sep:getComputedStyle(document.querySelector('#wv-modes .wv-mg-sep')||c).display}})()""")
    R.chk(bool(geo) and abs(geo["chipH"] - geo["tabH"]) <= 2 and abs(geo["chipTop"] - geo["tabTop"]) <= 2,
          "mode entries share the TAB geometry - same height, same line (1.14.1)", geo)
    R.chk(bool(geo) and geo["chipRad"] == geo["tabRad"] and geo["sep"] == "none",
          "…same corner shape, and no divider - the row is one uniform strip", geo)
    R.chk(J(pg, """(()=>{const tab=document.querySelector('#wv-tabstrip .wv-tab');
        return tab?getComputedStyle(tab).backgroundColor!==getComputedStyle(document.querySelector('#wv-modes .wv-mg-track')).backgroundColor:true})()"""),
          "tabs sit on the bare bar — a different ground from the track")
    # --- the ROW COSTS NOTHING new: the tab bar is the same height as with no group
    R.chk(g["barH"] <= 40, "zero new vertical height — the group lives in the 36px tab row (%dpx)" % g["barH"])
    # --- active marking, in the house grammar and DIFFERENT from the tab's
    R.chk(J(pg, "v=>{const c=document.querySelector('#wv-modes .wv-mg-chip[data-vid=\"'+v+'\"]');return c&&c.classList.contains('wv-on')&&c.getAttribute('aria-selected')==='true'}", modes[0]),
          "the open mode's chip is marked active")
    R.chk(J(pg, """(()=>{const c=document.querySelector('#wv-modes .wv-mg-chip.wv-on'),s=getComputedStyle(c);
        const acc=getComputedStyle(document.documentElement).getPropertyValue('--wv-acc').trim();
        const tab=document.querySelector('#wv-tabstrip .wv-tab.wv-on');
        const ts=tab?getComputedStyle(tab):null;
        const filled=s.backgroundColor!=='rgba(0, 0, 0, 0)'&&s.backgroundColor!=='transparent';
        const inked=s.color!==getComputedStyle(document.querySelector('#wv-modes .wv-mg-chip:not(.wv-on)')||c).color;
        /* 1.14.1: the mark is now DELIBERATELY the tab's own - uniform row by CEO ruling - so the
           old "must not look like a tab" clause is gone. What still matters is that the active
           entry is unmistakably marked against its inactive siblings. */
        return filled&&inked&&s.boxShadow!=="none"})()"""),
          "the active mode is marked, and distinctly from the inactive ones")
    # THE guard the uniform look makes necessary: they look like tabs, so nothing must ever turn
    # them into tabs. Real tabs become real PANELS in split/grid - four panels of a multi-MB
    # product on the host thread is exactly what the singleton rule forbids.
    before = J(pg, "({open:S.open.length, frames:document.querySelectorAll('iframe').length})")
    J(pg, "(()=>{const c=[...document.querySelectorAll('#wv-modes .wv-mg-chip:not(.wv-on)')];if(c[0])c[0].click()})()")
    pg.wait_for_timeout(2500)
    after = J(pg, "({open:S.open.length, frames:document.querySelectorAll('iframe').length})")
    R.chk(after["open"] == before["open"] and after["frames"] == before["frames"],
          "switching a mode adds NO instance and NO second frame - they look like tabs, they are not tabs",
          "%s -> %s" % (before, after))
    R.chk(J(pg, "!document.querySelector('#wv-modes .wv-mg-chip [data-wv-act=close],#wv-modes .wv-mg-chip .wv-tclose')"),
          "…and a mode entry carries no close affordance")
    # --- IN-PLACE SWITCHING: never a new tab, never a second instance
    uid0 = J(pg, "S.activeUid")
    bad = []
    for vid in modes[1:] + [modes[0]]:
        J(pg, "v=>{const c=document.querySelector('#wv-modes .wv-mg-chip[data-vid=\"'+v+'\"]');if(c)c.click()}", vid)
        pg.wait_for_timeout(900)
        st = J(pg, """(()=>({n:S.open.length,ids:S.open.map(i=>i.viewId),uid:S.activeUid,
            panels:document.querySelectorAll('#wv-panels .wv-panel[data-uid]').length,
            on:[...document.querySelectorAll('#wv-modes .wv-mg-chip.wv-on')].map(c=>c.dataset.vid)}))()""")
        if st["n"] != 1 or st["panels"] != 1 or st["ids"] != [vid] or st["on"] != [vid]:
            bad.append("%s -> %s" % (vid, st))
    R.chk(not bad, "clicking a mode switches IN PLACE: one instance, one panel, one tab (%d modes swept)" % len(modes), bad)
    R.chk(J(pg, "S.activeUid") == uid0, "…and it is the SAME instance throughout (uid never changes)", [uid0, J(pg, "S.activeUid")])
    # --- keyboard, through the shortcuts sheet
    pg.keyboard.press("Alt+Shift+Digit2"); pg.wait_for_timeout(700)
    R.chk(J(pg, "S.open.length===1&&S.open[0].viewId") == modes[1], "Alt+Shift+2 selects the second mode, still one instance", J(pg, "S.open.map(i=>i.viewId)"))
    J(pg, "renderProdKeys();$('#wv-keys').classList.add('wv-open')"); pg.wait_for_timeout(300)
    # the group heading is the product's REGISTERED mode-group label ("Views" is only the
    # fallback the framework sample happens to use); der registers "Dashboards".
    R.chk(J(pg, """(()=>{const lab=((typeof MODEGRP!=="undefined"&&MODEGRP[S.product])||{}).label||"Views";
        const g=[...document.querySelectorAll('#wv-keysGrid .wv-kgrp')].find(x=>{
          const t=x.querySelector('.wv-kg-t');return t&&t.textContent.trim()===lab});
        return !!g&&g.querySelectorAll('.wv-krow').length>=2&&/Alt/.test(g.textContent)})()"""),
          "the mode accelerators list in the '?' sheet (same PROD_KEYS store the products use)",
          J(pg, "((typeof MODEGRP!=='undefined'&&MODEGRP[S.product])||{}).label"))
    J(pg, "$('#wv-keys').classList.remove('wv-open')")
    # --- the Views dropdown (the collapsed tier's surface)
    J(pg, "menuModes(document.querySelector('#wv-modes .wv-mg-more'))"); pg.wait_for_timeout(400)
    R.chk(J(pg, "document.querySelectorAll('#wv-drop .wv-dd-item[data-wv-act=mode-go]').length") == len(modes),
          "the Views dropdown lists every mode")
    J(pg, "closeDrop()")
    # --- DEGRADATION: as the row tightens the group steps down; the tabs are never crushed
    J(pg, "v=>{for(const i of S.open.slice())closeInst(i.uid);openView(v)}", modes[0])
    for x in J(pg, "visibleCatalog().filter(v=>!isFrameworkView(v)&&v.openMode==='inline').map(v=>v.id).slice(0,7)"):
        J(pg, "v=>openView(v)", x); pg.wait_for_timeout(150)
    pg.wait_for_timeout(600)
    ladder, crushed = [], []
    for w in (1920, 1440, 1280, 1100, 900, 760, 620, 520):
        pg.set_viewport_size({"width": w, "height": 900}); pg.wait_for_timeout(450)
        J(pg, "updateTabScroll()"); pg.wait_for_timeout(250)
        d = J(pg, """(()=>{const g=document.querySelector('#wv-modes'),s=document.querySelector('#wv-tabstrip'),
            bar=document.querySelector('#wv-tabbar'),cs=getComputedStyle(bar);
            const gb=g.getBoundingClientRect(),sb=s.getBoundingClientRect();
            return {tier:g.dataset.tier,lab:g.dataset.lab||'',mgW:Math.round(gb.width),tabW:Math.round(sb.width),
              overlap:Math.round(sb.right-gb.left),
              inner:Math.round(bar.getBoundingClientRect().right-parseFloat(cs.paddingRight)-gb.right),
              labels:getComputedStyle(document.querySelector('#wv-modes .wv-mg-t')).display,
              track:getComputedStyle(document.querySelector('#wv-modes .wv-mg-track')).display,
              more:getComputedStyle(document.querySelector('#wv-modes .wv-mg-more')).display}})()""")
        ladder.append((w, d))
        if d["overlap"] > 0 or d["inner"] < -1: crushed.append((w, d))
        if w >= 1280 and d["tabW"] < 380: crushed.append((w, d))
    pg.set_viewport_size({"width": 1600, "height": 900}); pg.wait_for_timeout(400); J(pg, "updateTabScroll()")
    R.chk(not crushed, "tabs are never crushed or overlapped by the group at 1920/1440/1280 (and below)", crushed)
    tiers = [d["tier"] for _, d in ladder]
    rank = {"full": 0, "icons": 1, "menu": 2}
    R.chk(all(rank[tiers[i]] <= rank[tiers[i + 1]] for i in range(len(tiers) - 1)),
          "the tier ladder only ever steps DOWN as the row tightens: %s" % list(zip([w for w, _ in ladder], tiers)))
    R.chk("icons" in tiers and "menu" in tiers, "degradation walks the whole ladder — labels -> icons -> Views menu: %s" % list(zip([w for w, _ in ladder], tiers)))
    for w, d in ladder:
        if d["tier"] == "icons":
            R.chk(d["labels"] == "none" and d["track"] != "none", "at %dpx the icons tier hides the labels and keeps the track" % w); break
    for w, d in ladder:
        if d["tier"] == "menu":
            R.chk(d["track"] == "none" and d["more"] != "none", "at %dpx the menu tier collapses to a single Views dropdown" % w); break
    R.chk(J(pg, """(()=>{const c=document.querySelector('#wv-modes .wv-mg-chip');return !!(c.getAttribute('title')&&c.getAttribute('aria-label'))})()"""),
          "icon-only chips keep their name in title + aria-label")
    R.chk(all(d["lab"] == "" for w, d in ladder if w < 1440), "the VIEWS micro-label is width-gated (dropped below 1440)")
    # 1.14.3 - the ATTRIBUTE above is not the same thing as the heading being PAINTED. The
    # tabs rule was overridden by [data-lab="1"] at equal specificity and the caption came
    # back over the tab row; assert what the operator actually sees, in both presentations.
    R.chk(J(pg, """(()=>{const g=document.querySelector('#wv-modes'),l=g&&g.querySelector('.wv-mg-lab');
        return !!g&&g.dataset.mgstyle!=='segment'&&g.dataset.lab==='1'&&!!l
               &&getComputedStyle(l).display==='none'})()"""),
          "as TABS the group paints no heading, even at the width that sets data-lab")
    J(pg, "S.modeStyle='segment';prefChanged();renderAll()"); pg.wait_for_timeout(600)
    _seg = J(pg, """(()=>{const g=document.querySelector('#wv-modes'),l=g&&g.querySelector('.wv-mg-lab');
        return {style:g.dataset.mgstyle,tier:g.dataset.tier,lab:g.dataset.lab,
                disp:l?getComputedStyle(l).display:null}})()""")
    # the caption belongs to the FULL tier: a group that steps down to icons drops its
    # caption with it (der measures 652px against the segmented 620 cap and does exactly
    # that, while dlr reaches full and still shows "Views"). Follow the tier.
    if _seg["tier"] == "full" and _seg["lab"] == "1":
        R.chk(_seg["disp"] not in (None, "none"),
              "…and the segmented look still captions its inset control", _seg)
    else:
        R.chk(_seg["disp"] == "none",
              "…segmented but stepped down a tier — the caption drops with it", _seg)
    J(pg, "S.modeStyle='tabs';prefChanged();renderAll()"); pg.wait_for_timeout(500)
    # --- RTL: the group mirrors to the LEFT, by measurement, in both directions
    lt = J(pg, """(()=>{const g=document.querySelector('#wv-modes').getBoundingClientRect(),s=document.querySelector('#wv-tabstrip').getBoundingClientRect();
        return {mg:Math.round(g.left),strip:Math.round(s.left),mgr:Math.round(g.right),stripr:Math.round(s.right)}})()""")
    lang0 = J(pg, "S.lang")
    J(pg, "S.lang='ar';prefChanged();renderAll()"); pg.wait_for_timeout(1200); J(pg, "updateTabScroll()"); pg.wait_for_timeout(400)
    rt = J(pg, """(()=>{const g=document.querySelector('#wv-modes').getBoundingClientRect(),s=document.querySelector('#wv-tabstrip').getBoundingClientRect(),
        bar=document.querySelector('#wv-tabbar').getBoundingClientRect();
        return {dir:document.documentElement.dir,mg:Math.round(g.left),strip:Math.round(s.left),mgr:Math.round(g.right),
          fromBarLeft:Math.round(g.left-bar.left)}})()""")
    R.chk(rt["dir"] == "rtl" and rt["mgr"] <= rt["strip"] and rt["fromBarLeft"] < 30,
          "RTL: the group mirrors to the LEFT of the tabs, at the row's far edge (measured)", [lt, rt])
    R.chk(lt["mg"] > lt["strip"], "…and it is on the RIGHT in LTR (measured, both directions)", lt)
    J(pg, "l=>{S.lang=l;prefChanged();renderAll()}", lang0); pg.wait_for_timeout(900)
    close_all(pg); pg.wait_for_timeout(300)
    # hand the run back exactly as it was found: the landing product, its home view open and
    # the read band's expand state untouched (f_hub carries the same rule for the same reason)
    J(pg, """p0=>{
        if(S.product!==p0){S.product=p0;prefChanged()}
        const v=S.catalog.find(x=>x.product===p0&&!x.shell&&x.openMode!=='popout');
        for(const i of S.open.slice())closeInst(i.uid);
        if(v)openView(v.id);
        renderAll();}""", P_ENTER)
    wait(pg, "S.product===%r && S.open.length>0" % P_ENTER, 40000); pg.wait_for_timeout(1500)
    R.chk(J(pg, "p=>S.product===p", P_ENTER),
          "the mode-group feature hands the run back on the product it was entered on", P_ENTER)

# ================================================================== HUB-specific
def f_hub(R, pg, ctx):
    if not J(pg, "!!window.WV_HUB_STATS"): return
    R.feature = "hub: landing + frames + embed guard (1.7.1)"
    # what this step was HANDED. Restored at the end - PRODUCTS[0] is registration order
    # (dlr on the hub), NOT the landing product (der), and handing back to the wrong one
    # moved every later feature onto a product the run never started on.
    H_ENTER = J(pg, "S.product")
    # ---- 1.10.7: product shortcuts work in the hub — groups relayed up, keys forwarded down, '?' answered by the hub sheet
    # 1.11.0: a hub-declared MODE GROUP publishes its accelerators into PROD_KEYS at
    # registration time, so "PROD_KEYS is non-empty" is true before any frame has relayed —
    # the wait has to key on the ACTIVE product's own groups arriving.
    wait(pg, "(PROD_KEYS[S.product]||[]).length>0", 20000)
    R.chk(J(pg, "Object.keys(PROD_KEYS).length>0 && (PROD_KEYS[S.product]||[]).length>0"), "the active frame's registered shortcut groups reached the hub (WV.registerShortcuts relay)", J(pg, "JSON.stringify(Object.keys(PROD_KEYS))"))
    J(pg, "renderProdKeys();$('#wv-keys').classList.add('wv-open')")
    R.chk(J(pg, "document.querySelectorAll('#wv-keysGrid .wv-kgrp').length>=2"), "the hub's '?' sheet shows shell + product groups", J(pg, "[...document.querySelectorAll('#wv-keysGrid .wv-kg-t')].map(e=>e.textContent.trim()).join(' | ')"))
    J(pg, "$('#wv-keys').classList.remove('wv-open')")
    kfr = [f for f in pg.frames if 'wv-embed' in f.url]
    if kfr:
        kfr[0].evaluate("window.__keys=[];document.addEventListener('keydown',e=>__keys.push((e.shiftKey?'S+':'')+e.key))")
        pg.keyboard.press("Shift+M"); pg.keyboard.press("Home"); pg.wait_for_timeout(300)
        R.chk(kfr[0].evaluate("__keys") == ["S+M", "Home"], "Shift+M / Home pressed on the hub chrome are replayed inside the active frame", str(kfr[0].evaluate("__keys")))
        kfr[0].evaluate("document.dispatchEvent(new KeyboardEvent('keydown',{key:'?',bubbles:true,cancelable:true}))"); pg.wait_for_timeout(300)
        R.chk(J(pg, "$('#wv-keys').classList.contains('wv-open')"), "'?' inside a frame opens the HUB's sheet (embed relay precedes the sign-in gate)")
        J(pg, "$('#wv-keys').classList.remove('wv-open')")
    else:
        R.chk(True, "no embed frame here — forwarding covered on the hub run")
    # 2026-09-05 - derived from the LIVE fleet, not named products: ftm/btm/ev were retired into der,
    # and hardcoding the new ids would only move the breakage to the next retirement.
    FLEET = J(pg, "PRODUCTS.map(p=>p.id)")
    HOMES = J(pg, "window.WV_HUB_HOME||{}")
    # the LANDING product, not PRODUCTS[0]: registration order and landing order differ (the hub
    # starts on WV.start({product}), which need not be the first registered).
    P1 = J(pg, "S.product")
    _rest = [x for x in FLEET if x != P1]
    P2 = _rest[0] if _rest else P1; P3 = _rest[1] if len(_rest) > 1 else P2
    H1 = HOMES.get(P1); H2 = HOMES.get(P2); H3 = HOMES.get(P3)
    R.chk(wait_hub_ready(pg, 1, 60000) and J(pg, "h=>S.open.length===1&&S.open[0].viewId===h", H1),
          "fresh login lands on %s with a ready frame" % H1, J(pg, "S.open.map(i=>i.viewId)"))
    f = hub_frame(pg, P1)
    R.chk(f is not None and f.evaluate("EMB.on&&window.EMB===EMB&&!!document.querySelector('[data-wv-product-root]')"),
          "frame runs in embed mode with the product root mounted")
    # in-frame navigation must never unmount the root. Stated through the shell's mode group, which any
    # product with sub-dashboards satisfies - the old form clicked ftm's own mode-bar labels.
    mids = J(pg, "p=>((typeof MODEGRP==='object'&&MODEGRP[p])?MODEGRP[p].modes.map(m=>m.viewId):[])", P1)
    if mids:
        for vid in mids[:4]:
            J(pg, "v=>{if(typeof modeGo==='function')modeGo(v)}", vid); pg.wait_for_timeout(900)
            fr = hub_frame(pg, P1)
            R.chk(bool(fr) and fr.evaluate("!!document.querySelector('#wv-embedRoot [data-wv-product-root]')") and J(pg, "S.open.length===1"),
                  "mode '%s' switches IN PLACE - root still mounted, still one instance" % vid)
    else:
        R.chk(True, "%s declares no mode group - in-place switching covered by the mode-group feature" % P1)
    R.feature = "hub: exclusive product switch + memory hygiene"
    base_frames = J(pg, "document.querySelectorAll('iframe').length")
    J(pg, "p=>{document.querySelector('#wv-prodBtn').click();const b=document.querySelector('#wv-drop [data-wv-act=prod-set][data-id='+JSON.stringify(p)+']');b&&b.click()}", P2)
    wait_hub_ready(pg, 2, 60000); pg.wait_for_timeout(500)
    R.chk(J(pg, "a=>S.product===a[0]&&S.open.length===1&&S.open[0].viewId===a[1]&&[...WV_HUB_LIVE.values()].every(r=>r.product===a[0])&&document.querySelectorAll('iframe').length===1", [P2, H2]),
          "lockup switch → other product's frames torn down, home opens", J(pg, "[S.product,S.open.map(i=>i.viewId),document.querySelectorAll('iframe').length]"))
    R.chk(J(pg, "document.title===prodBranded(prodObj().name)"), "tab title follows the switch")
    V3 = J(pg, "p=>S.catalog.filter(v=>v.product===p&&!v.shell&&v.openMode!=='popout').map(v=>v.id)", P3)
    VA, VB = V3[0], (V3[1] if len(V3) > 1 else V3[0])
    J(pg, "v=>openView(v)", VA); wait_hub_ready(pg, 3, 60000); pg.wait_for_timeout(300)
    R.chk(J(pg, "a=>S.product===a[0]&&S.open.length===1&&S.open[0].viewId===a[1]", [P3, VA]),
          "openView-driven switch opens ONLY the requested view", J(pg, "S.open.map(i=>i.viewId)"))
    J(pg, "v=>openView(v)", VB); wait_hub_ready(pg, 4, 60000)
    J(pg, "v=>{const i=S.open.find(x=>x.viewId===v);if(i)closeInst(i.uid)}", VA); pg.wait_for_timeout(300)
    R.chk(J(pg, "document.querySelectorAll('iframe').length===1&&WV_HUB_LIVE.size===1"), "closing a view releases its frame immediately")
    R.chk(J(pg, "p=>visibleCatalog().every(v=>v.product===p||isFrameworkView(v))&&visibleCatalog().length>=3", P3),
          "palette/catalog scoped to the active product (1.7.2)", J(pg, "visibleCatalog().length"))
    J(pg, "earCommand('open the line details')"); wait_hub_ready(pg, 5, 60000); pg.wait_for_timeout(300)
    R.chk(J(pg, "S.product==='dlr'&&S.open.some(i=>i.viewId==='dlr.linedetails')"), "voice 'open the line details' switches product hub-wide")
    R.chk(J(pg, "document.title") == "OATI Genie Dynamic Line Ratings", "title after voice switch (the product's own name already carries the brand — never doubled)", J(pg, "document.title"))
    nodes0 = J(pg, "document.querySelectorAll('*').length"); al0 = J(pg, "S.alarms.length")
    ready0 = J(pg, "WV_HUB_STATS.ready")
    nodes_lap1 = None
    for rot in range(3):
        for pid in FLEET[:5]:
            hub_switch(pg, pid)
            ready0 += 1; wait_hub_ready(pg, ready0, 60000)
        if rot == 0:
            pg.wait_for_timeout(800)
            nodes_lap1 = J(pg, "document.querySelectorAll('*').length")
    pg.wait_for_timeout(800)
    R.chk(J(pg, "document.querySelectorAll('iframe').length===1&&WV_HUB_LIVE.size===1"), "3 rotations through all products → iframes 1")
    nodes1 = J(pg, "document.querySelectorAll('*').length")
    # measured: 1161 cold -> 1678 after lap 1 -> 1678 / 1678 / 1678. The first lap BUILDS each
    # product's chrome once; growth after that is what a leak looks like, so compare lap1 vs lap3.
    R.chk(abs(nodes1 - (nodes_lap1 or nodes0)) < 150,
          "DOM flat across rotations (once the first lap has built the baseline)",
          "cold %d → lap1 %s → lap3 %d" % (nodes0, nodes_lap1, nodes1))
    # the store is capped at 60 by design (addAlarm slices); the property is that rotations do not
    # grow it past the cap and that the dedup is actually firing.
    R.chk(J(pg, "S.alarms.length<=60 && (WV_HUB_STATS.alarmsDeduped>0 || S.alarms.length<=al0+40)".replace("al0", str(al0))),
          "relayed alarms stay bounded and deduped across rotations", J(pg, "[S.alarms.length,WV_HUB_STATS.alarmsDeduped]"))
    R.chk(J(pg, "S.alarms.some(a=>/ · /.test(a.src))"), "relayed alarm sources are product-prefixed")
    # Info in frames (1.8.9)
    R.feature = "hub: Info mode in product frames (1.8.9)"
    # position is not capability (the PRODUCTS[0] lesson): use the first product whose frame
    # actually exposes a bounded stamped region, and say which one answered.
    PINFO, f, FTGT = None, None, None
    for _pid in ([P1] + [q for q in J(pg, "S.products?S.products.map(p=>p.id):Object.keys(WV_HUB_FILES)") if q != P1]):
        hub_switch(pg, _pid); ready0 += 1; wait_hub_ready(pg, ready0, 60000); pg.wait_for_timeout(1200)
        _f = hub_frame(pg, _pid)
        if _f is None: continue
        _loc, _i, _a = frame_info_target(pg, _f)
        if PINFO is None and _i is not None:
            PINFO, f, FTGT = _pid, _f, (_loc, _i, _a); break
        if PINFO is None: CONTAINER_ONLY = _pid
    R.chk(PINFO is not None, "a product frame exposes a bounded info region to click",
          "using %s (region area %s)" % (PINFO, FTGT[2] if FTGT else None))
    P1 = PINFO or P1
    R.chk(f.evaluate("S.infoMode!==true&&!document.body.hasAttribute('data-infomode')"), "frame adopted while hub Info is off → child off (on:false brief)")
    J(pg, "infoDockSet('dock');toggleInfo(true)"); pg.wait_for_timeout(500)
    R.chk(f.evaluate("S.infoMode===true&&S.infoDock==='dock'&&document.body.hasAttribute('data-infomode')&&!$('#wv-infoDock').classList.contains('wv-open')&&document.querySelectorAll('[data-info]').length>0"), "hub Info ON (dock) → frame outlines on, no child dock", f.evaluate("document.querySelectorAll('[data-info]').length"))
    # any region the frame STAMPED - `.kpi` was ftm's class, and ftm is retired.
    kpi = FTGT[0].nth(FTGT[1]); kpi.hover(); pg.wait_for_timeout(500)
    title = J(pg, "$('#wv-infoDockT').textContent"); caps = J(pg, "[...document.querySelectorAll('#wv-infoDockBody .wv-id-cap')].map(e=>e.textContent)")
    R.chk(bool(title) and len(title) > 2 and len(caps) >= 4 and J(pg, "!!INFO_DOCK.remote"),
          "hover a region inside the frame → hub dock shows ITS entry (title + sections)", [title, caps])
    R.chk(f.evaluate("""(()=>{const r=document.querySelector('[data-wv-product-root]');
        const c=r&&r.querySelector('.info-card,[class*=info-card]');
        return !c||getComputedStyle(c).display==='none'})()"""),
          "frame's own floating card hidden while the hub docks")
    pg.screenshot(path=str(R.shots / "hub_info_dock_ftm_kpi.png"))
    kpi.click(); pg.wait_for_timeout(400)
    R.chk(J(pg, "INFO_DOCK.pinned&&$('#wv-infoDockPin').classList.contains('wv-on')") and f.evaluate("INFO_DOCK.pinned&&!!document.querySelector('[data-wv-info-pinned]')"), "click in the frame pins (hub + child agree)")
    pg.hover("#wv-clock"); pg.wait_for_timeout(200)
    R.chk(J(pg, "t=>$('#wv-infoDockT').textContent===t", title), "pinned frame entry ignores hub hover", J(pg, "$('#wv-infoDockT').textContent"))
    J(pg, "document.querySelector('#wv-infoDockPin').click()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "!INFO_DOCK.pinned") and f.evaluate("!INFO_DOCK.pinned&&!document.querySelector('[data-wv-info-pinned]')"), "hub pin button releases the child's pin")
    pg.mouse.move(5, 500); pg.wait_for_timeout(120)  # the pointer must actually MOVE - a repeat hover on the same spot fires no event
    pg.hover("#wv-connChip"); pg.wait_for_timeout(200)
    R.chk(J(pg, "$('#wv-infoDockT').textContent==='Realtime link'&&!INFO_DOCK.remote"), "local hub chrome hover still fills the dock (last message wins)")
    # a DIFFERENT bounded region than the one above - the property is that a frame hover
    # replaces the local chrome entry, not that any particular region is called anything.
    _o = FTGT[0].nth(FTGT[1] + 1 if FTGT[1] + 1 < FTGT[0].count() else max(FTGT[1] - 1, 0))
    _o.hover(); pg.wait_for_timeout(400)
    _t2 = J(pg, "$('#wv-infoDockT').textContent")
    R.chk(bool(_t2) and _t2 != "Realtime link" and J(pg, "!!INFO_DOCK.remote"),
          "frame hover replaces the local entry", _t2)
    # Esc while the FRAME has keyboard focus (the operator clicked inside it): the child asks the parent to leave Info mode
    f.evaluate("window.focus()"); pg.keyboard.press("Escape"); pg.wait_for_timeout(500)
    R.chk(J(pg, "!S.infoMode&&!$('#wv-infoDock').classList.contains('wv-open')") and f.evaluate("!S.infoMode&&!document.body.hasAttribute('data-infomode')&&!(document.querySelector('[data-wv-product-root]')||{classList:{contains:()=>false}}).classList.contains('info-mode')"), "Esc with focus INSIDE the frame → Info off in hub AND frame ({wv:'info-exit'})", [J(pg, "S.infoMode"), f.evaluate("S.infoMode")])
    J(pg, "infoDockSet('dock');toggleInfo(true)"); pg.wait_for_timeout(400); J(pg, "window.focus()")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(400)
    R.chk(J(pg, "!S.infoMode&&!$('#wv-infoDock').classList.contains('wv-open')") and f.evaluate("!S.infoMode&&!document.body.hasAttribute('data-infomode')&&!(document.querySelector('[data-wv-product-root]')||{classList:{contains:()=>false}}).classList.contains('info-mode')"), "Esc in the hub → Info off in hub AND frame (no outlines left)")
    J(pg, "infoDockSet('float');toggleInfo(true)"); pg.wait_for_timeout(400)
    # CLICK, not hover: the shell's floating card opens on click (hover only fills the dock),
    # and it is the SHELL's card in #wv-drop - `.info-card` inside the product root was a
    # retired product's own widget.
    FTGT[0].nth(FTGT[1]).hover(); pg.wait_for_timeout(300)
    FTGT[0].nth(FTGT[1]).click(); pg.wait_for_timeout(700)
    R.chk(f.evaluate("""(()=>{const c=document.querySelector('#wv-drop .wv-info-card');
        const t=document.querySelector('#wv-drop .wv-ic-t');
        return S.infoDock==='float'&&!!c&&getComputedStyle(c).display!=='none'
               &&(c.textContent||'').trim().length>10&&!!t&&(t.textContent||'').trim().length>1})()""")
          and not J(pg, "!!INFO_DOCK.remote&&$('#wv-infoDock').classList.contains('wv-open')"),
          "float mode → the frame answers in its OWN card, the hub does not dock it",
          f.evaluate("(document.querySelector('#wv-drop .wv-ic-t')||{}).textContent"))
    pg.screenshot(path=str(R.shots / "hub_info_float_in_frame.png"))
    J(pg, "toggleInfo(false);infoDockSet('float')")
    # popout Info
    POPV = J(pg, "p=>{const v=S.catalog.find(x=>x.product===p&&!x.shell&&x.openMode!=='popout');return v?v.id:null}", P1)
    with ctx.expect_page(timeout=20000) as pi:
        J(pg, "v=>popOut(v)", POPV)
    pop = pi.value; R.attach(pop); wait(pg, "S.popouts[0]&&S.popouts[0].ready", 30000); pop.wait_for_timeout(1500)
    J(pg, "toggleInfo(true)"); pg.wait_for_timeout(500)
    R.chk(pop.evaluate("S.infoMode===true&&document.body.hasAttribute('data-infomode')&&S.infoDock==='float'"), "popout follows Info on (float → own card)")
    J(pg, "infoDockSet('dock')"); pg.wait_for_timeout(400)
    pop.locator("[data-wv-product-root] [data-info]:visible").first.hover(); pg.wait_for_timeout(500)
    R.chk(J(pg, "!!INFO_DOCK.remote&&$('#wv-infoDockT').textContent.length>0"), "popout in dock mode feeds the hub's panel", J(pg, "$('#wv-infoDockT').textContent"))
    pop.evaluate("(()=>{const r=document.querySelector('[data-wv-product-root]');const b=r&&r.querySelector('button');if(b)b.click()})()"); pop.wait_for_timeout(300)
    R.chk(pop.evaluate("!!document.querySelector('#wv-embedRoot [data-wv-product-root]')"), "popout in-frame click keeps the root mounted (1.7.1)")
    J(pg, "toggleInfo(false);infoDockSet('float');popClose(S.popouts[0].uid)")
    R.feature = "hub: widget channels"
    widget_ready(pg)
    J(pg, "openGenie()"); pg.wait_for_timeout(600)
    R.chk(J(pg, "(document.querySelector('oati-genie-chat-widget').deskContent.items||[]).every(i=>/ · /.test(i.channelLabel)||!i.id.startsWith('alarm:'))"), "Desk items carry product-prefixed channels")
    n_items = J(pg, "document.querySelector('oati-genie-chat-widget').deskContent.items.length")
    J(pg, "closeGenie()"); hub_switch(pg, P2); ready0 += 1; wait_hub_ready(pg, ready0, 60000); pg.wait_for_timeout(500)  # a LIVE product, not a retired literal
    R.chk(J(pg, "document.querySelector('oati-genie-chat-widget').deskContent.items.length") >= n_items, "items survive a product switch until acked")
    # the product switch above leaves a frame booting, and a frame relays its whole startup alarm
    # list on ready - so a one-shot ack races alarms that have not arrived yet. Re-ack while polling:
    # that is the claim ("everything acked -> Desk empty") and it still fails if acking does not work.
    # Re-ack ONLY while something is unacked. renderAlarms() ends in genieDeskSync(), a 150 ms
    # debounce that clearTimeout()s on every call - so an unconditional re-ack in a fast poll resets
    # it forever and the Desk push never runs (measured: unacked 0, five items still on the Desk).
    # This way a late alarm from a booting frame is still caught, and once all are acked the poll
    # stops touching renderAlarms so the debounce can fire.
    ackOk = wait(pg, "(S.alarms.some(a=>!a.acked)?(S.alarms.forEach(a=>a.acked=true),renderAlarms(),false):document.querySelector('oati-genie-chat-widget').deskContent.items.length===0)", 8000)
    R.chk(ackOk, "ack-all empties the Desk", "" if ackOk else J(pg, """JSON.stringify({
        deskItems:(document.querySelector('oati-genie-chat-widget').deskContent.items||[]).map(i=>i.id).slice(0,5),
        alarms:S.alarms.length, unacked:S.alarms.filter(a=>!a.acked).length})"""))
    # 1.10.10 — GLOBAL is the fleet roster: exactly one read per product, Local stays the view's own 2
    R.feature = "hub: Global fleet roster (1.10.10)"
    J(pg, "if(window.WV_HUB_GREAD){WV_HUB_GREAD.paused=false};if(typeof feedHubRead==='function')feedHubRead();setGreadScope('global')"); pg.wait_for_timeout(500)
    n_prod = J(pg, "PRODUCTS.length")
    R.chk(J(pg, "(()=>{const d=GREAD.data[S.product];const r=(d&&grReads(d))||[];return r.filter(x=>x!==(d||{}).summaryRead).length})()") == n_prod,
          "Global shows one read per dashboard (%d products)" % n_prod, J(pg, "(()=>{const d=GREAD.data[S.product];return ((d&&grReads(d))||[]).map(r=>r.headline.replace(/<[^>]+>/g,'').slice(0,34))})()"))
    R.chk(J(pg, "document.querySelectorAll('#wv-gread .wv-gr-pd').length") == n_prod, "…and the pager offers a dot per dashboard")
    R.chk(J(pg, "(()=>{const d=GREAD.data[S.product];const r=((d&&grReads(d))||[]).filter(x=>x!==(d||{}).summaryRead);return r.every(x=>x.headline&&x.headline.trim().length>8)&&r.some(x=>x.cta)})()"), "every roster line has a headline, and the lines carry actions")
    # 1.10.9 — Local reads: a frame relays its VIEW-scoped reads up ({wv:"gread-up"}), so the hub band
    # shows the read of the display on screen. Sampled on product home views; runs LAST because it
    # changes which view is open. (Full 43-view sweep: scratchpad/audit_localreads2.py.)
    R.feature = "hub: Local reads relayed from frames (1.10.9)"
    homes = J(pg, "PRODUCTS.map(p=>{const v=S.catalog.find(v=>v.product===p.id&&!v.shell&&v.openMode!=='popout');return v?v.id:null}).filter(Boolean)")
    missing = []
    for vid in homes[:4]:
        J(pg, "id=>{for(const i of S.open.slice())closeInst(i.uid);openView(id)}", vid)
        if not wait(pg, "((GREAD.views[" + repr(vid) + "]||{}).reads||[]).length>=2", 30000):
            missing.append(vid)
    R.chk(not missing, "each sampled product home view relays 2 Local reads to the hub (1.10.9)", "missing: %s" % missing)
    if not missing:
        J(pg, "setGreadScope('view')"); pg.wait_for_timeout(400)
        R.chk(J(pg, "!$('#wv-gread').classList.contains('wv-gr-empty') && $('#wv-gread .wv-gr-head').textContent.trim().length>10"), "…and the band renders that view's read in Local scope", J(pg, "$('#wv-gread .wv-gr-head').textContent.slice(0,80)"))
        R.chk(J(pg, "(()=>{const d=GREAD.views[grActiveViewId()];const r=(d&&d.reads)||[];return r.length>=2&&r.every(x=>x.headline&&(x.cta||(x.insights||[]).some(i=>i.act)))})()"), "relayed reads keep their runnable actions (routed back into the frame; >=2 since the curated sets landed)", J(pg, "((GREAD.views[grActiveViewId()]||{}).reads||[]).length"))
        J(pg, "if(window.WV_HUB_GREAD)window.WV_HUB_GREAD.paused=false")  # release the roster
        J(pg, "setGreadScope('global')")

# ================================================================== SMOKE (dashboards)
    # 1.10.12 — a Local read's action must act on the OPEN dashboard, never blank it. The failure this guards:
    # a product helper called openView() inside the frame, which mounted a view into the child's own hidden
    # panel area and pushed the product root back to the park — handler "succeeded", dashboard vanished.
    # NOTE the selector: conv/bafc mark BOTH their root and their overlay host with data-wv-product-root, and
    # the overlay host is legitimately 0-height — measuring it produces false alarms.
    R.feature = "hub: Local read actions act in place (1.10.12)"
    ROOT = ("(()=>{const c=[...document.querySelectorAll('[data-wv-product-root]')]"
            ".filter(e=>!/-overlays$|-guide-host$/.test(e.id||''));"
            "const r=c.sort((a,b)=>b.getBoundingClientRect().height-a.getBoundingClientRect().height)[0];"
            "if(!r)return null;const b=r.getBoundingClientRect();"
            "return {id:r.id,h:Math.round(b.height),txt:(r.innerText||'').trim().length}})()")
    J(pg, "setGreadScope('view')"); pg.wait_for_timeout(500)
    dead = []
    nreads = J(pg, "((GREAD.views[grActiveViewId()]||{}).reads||[]).length")
    for ix in range(min(nreads, 2)):
        J(pg, "i=>{const d=GREAD.views[grActiveViewId()];if(d){d.ix=i;renderGenieRead()}}", ix)
        pg.wait_for_timeout(350)
        J(pg, "(()=>{const g=document.querySelector('#wv-gread');if(g&&g.dataset.open!=='1'){const t=g.querySelector('.wv-gr-tg');if(t)t.click()}})()")
        pg.wait_for_timeout(400)
        # query AND click in one tick: the band re-renders on every relayed read, so a handle taken
        # a moment earlier can already be detached (this sweep now walks 11 products, not 8).
        RSEL = "#wv-gread [data-wv-act=gread-run],#wv-gread [data-wv-act=gread-cta]"
        n = J(pg, "s=>document.querySelectorAll(s).length", RSEL)
        for k in range(n):
            label = J(pg, "a=>{const e=[...document.querySelectorAll(a[0])][a[1]];"
                            "if(!e)return null;const t=(e.textContent||'?').trim().slice(0,24);e.click();return t}",
                      [RSEL, k])
            if label is None: break
            pg.wait_for_timeout(1400)
            # the VISIBLE panel's frame, not fr[0]: a read action may legitimately open a
            # second view, and in tabs layout that turns the previous panel into a
            # wv-hiddenpanel - measuring it would report a healthy dashboard as torn down.
            vis = J(pg, "(()=>{const f=[...document.querySelectorAll('iframe')]"
                        ".find(x=>x.getBoundingClientRect().height>40&&/dashboards\\//.test(x.src||''));"
                        "return f?f.getAttribute('src'):null})()")
            fr = [f for f in pg.frames if vis and f.url.endswith(vis)]
            root = fr[0].evaluate(ROOT) if fr else None
            if (not fr) or (not root) or root["h"] < 40 or root["txt"] < 40:
                dead.append("%s -> %s" % (label, root or "no visible product frame"))
    R.chk(not dead, "every Local read action leaves the dashboard mounted (%d reads swept)" % min(nreads, 2), dead)
    J(pg, "setGreadScope('global')")
    # f_hub runs SECOND — every later feature inherits whatever product this block left active. The sampling above
    # walks four products, so restore the landing state before handing the run on.
    J(pg, """p0=>{if(S.product!==p0){S.product=p0;prefChanged()}
        const v=S.catalog.find(x=>x.product===p0&&!x.shell&&x.openMode!=='popout');
        for(const i of S.open.slice())closeInst(i.uid);if(v)openView(v.id);renderAll()}""", H_ENTER)
    wait(pg, "S.product===%r && S.open.length>0" % H_ENTER, 30000); pg.wait_for_timeout(1500)
    R.chk(J(pg, "p=>S.product===p", H_ENTER)
          and J(pg, "visibleCatalog().filter(v=>!isFrameworkView(v)&&v.openMode==='inline').length>=2"),
          "hub feature hands the run back on the product it was entered on", H_ENTER)

def smoke(R, pg):
    R.feature = "boot smoke"
    pg.goto(R.url); pg.wait_for_selector("#wv-la-u", state="attached", timeout=60000)
    stamp = J(pg, "(document.querySelector('meta[name=wv-shell-version]')||{}).content")
    R.chk(stamp == FW_VER, "stamp = framework (%s)" % FW_VER, stamp)
    login(pg, remember=False); pg.wait_for_timeout(2500)
    R.chk(J(pg, "S.open.length>=1&&!!document.querySelector('#wv-panels .wv-panel[data-uid] [data-wv-product-root], #wv-panels .wv-panel[data-uid] [data-vb] *')"), "default view mounted after login", J(pg, "S.open.map(i=>i.viewId)"))
    R.chk(widget_ready(pg, 45000), "chat component loads (via ../chat/ when beside a subfolder)")
    R.chk(J(pg, "GWID.base") in ("", "../"), "loader base resolved", J(pg, "GWID.base"))
    if R.url.startswith("http") and "/dashboards/" in R.url:
        R.chk(J(pg, "GWID.base==='../'"), "dashboard under dashboards/ resolves chat/ one level up")
    J(pg, "document.querySelector('#wv-infoBtn').click()"); pg.wait_for_timeout(200)
    R.chk(J(pg, "S.infoMode===true&&document.body.hasAttribute('data-infomode')"), "Info toggles on")
    J(pg, "infoDockSet('dock')"); pg.hover("#wv-clock"); pg.wait_for_timeout(300)
    R.chk(J(pg, "$('#wv-infoDock').classList.contains('wv-open')&&document.querySelectorAll('#wv-infoDockBody .wv-id-cap').length>=8"), "dock shows rich sections standalone")
    prod_entry = J(pg, "(()=>{const els=[...document.querySelectorAll('[data-wv-product-root] [data-info]')];for(const e of els){const x=infoEntryFor(e);if(x&&x.rich)return x.title}return null})()")
    # 1.12.1 — this used to be R.chk(True, …): it could not fail, and it reported "none" for a
    # product whose Info mode was entirely broken while the smoke stayed green. Assert both halves.
    outlined = J(pg, """(()=>{let n=0;
        document.querySelectorAll('[data-wv-product-root] [data-info]').forEach(e=>{
          if(getComputedStyle(e).outlineStyle==="dashed")n++});return n})()""")
    in_doc = J(pg, "!!document.querySelector('[data-wv-product-root]')") and "/index.html" not in R.url
    if in_doc:   # a converted dashboard mounts its product IN the document…
        R.chk(bool(prod_entry), "product content bridged to the dock: %s" % (prod_entry or "NONE — the product answers nothing of its own"))
        R.chk(outlined >= 1, "…and the product's own regions are OUTLINED (the shell outlines [data-info] only — a product with its own data-info-KEY registry must stamp data-info itself)", outlined)
    else:        # …the HUB hosts it in an iframe: regions live in the frame and arrive by the
        # {wv:"info-item"} relay, so there is nothing in the top document to outline.
        R.chk(True, "hub: product info arrives by relay, not from the top document (nothing to outline here)")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(200)
    R.chk(J(pg, "!S.infoMode"), "Esc leaves Info mode")
    J(pg, "infoDockSet('float');doLogout()"); pg.wait_for_timeout(300)
    R.chk(J(pg, "document.body.dataset.in===''&&document.querySelector('oati-genie-chat-widget')===null"), "sign out → login, widget unmounted")
    # ---- functional overlay guard (2026-08-31), run LAST and in EMBED mode.
    # A product dialog must not merely open: it must PAINT ON TOP and be clickable. Two real regressions hid
    # behind "the handler ran" — an overlay host trapped in a hidden parked block (0x0), and an overlay
    # container with z-index:0 that became a stacking context, so full-size dialogs painted UNDER the product.
    # Both only manifest in embed mode (#wv-embedRoot is the sibling that paints over them), which is exactly
    # how the hub renders every product — so the guard loads the embed URL and hit-tests there.
    try:
        vid = J(pg, "(S.catalog.find(v=>!isFrameworkView(v)&&v.openMode==='inline')||{}).id")
        if vid:
            # a hash-only change is a SAME-DOCUMENT navigation — the app would never re-boot in embed mode,
            # so reload() after it and wait for the embed to actually mount rather than sleeping blind.
            pg.goto(R.url.split("#")[0] + "#wv-embed=" + vid + "&inst=9&theme=dark&density=compact")
            pg.reload()
            wait(pg, "typeof EMB!=='undefined' && EMB.on && !!document.querySelector('[data-wv-product-root]')", 30000)
            pg.wait_for_timeout(2500)
            triggers = J(pg, """(()=>{const seen=new Set(),out=[];
              for(const b of document.querySelectorAll('button,[role=button]')){
                const t=((b.getAttribute('data-tip')||b.getAttribute('title')||b.getAttribute('aria-label')||'')+' '+(b.id||'')).toLowerCase();
                if(!/config|export|option|layout|menu|download|kebab|settings/.test(t))continue;
                if(b.closest('#wv-hdr,#wv-sidebar,#wv-status,#wv-qs,#wv-drop,#wv-modal,#wv-keys,#wv-vcmds,#wv-adrawer,#wv-ndrawer,#wv-infoDock,#wv-palette'))continue; // shell chrome only — NOT .wv-root, which wraps the product in embed mode
                const r=b.getBoundingClientRect(); if(r.width<8||r.height<8)continue;
                const key=b.id||t.slice(0,20); if(seen.has(key))continue; seen.add(key);
                out.push({id:b.id||'',key:key.slice(0,26)});}
              return out.slice(0,6)})()""")
            buried = []
            for t in triggers:
                if not t["id"]: continue
                J(pg, "id=>{const b=document.getElementById(id);if(b)b.click()}", t["id"]); pg.wait_for_timeout(700)
                verdict = J(pg, """(()=>{const cand=[...document.querySelectorAll('body *')].filter(e=>{
                     const s=getComputedStyle(e),r=e.getBoundingClientRect();
                     return r.width>140&&r.height>60&&s.display!=='none'&&s.visibility!=='hidden'&&+s.opacity>0.5&&
                       (s.position==='fixed'||s.position==='absolute')&&/menu|modal|dlg|dialog|back|pop|sheet/i.test(e.id+' '+e.className)&&
                       !/wv-/.test(e.id);});
                   if(!cand.length)return 'none';
                   const el=cand.sort((a,b)=>b.getBoundingClientRect().width*b.getBoundingClientRect().height-a.getBoundingClientRect().width*a.getBoundingClientRect().height)[0];
                   const box=el.getBoundingClientRect();
                   const hit=document.elementFromPoint(box.x+box.width/2,box.y+Math.min(24,box.height/2));
                   return (hit&&(el.contains(hit)||hit===el))?'ok':'BURIED:'+((hit&&(hit.id||hit.className))||'?').toString().slice(0,22)})()""")
                if str(verdict).startswith("BURIED"): buried.append("%s -> %s" % (t["key"], verdict))
                J(pg, "document.querySelectorAll('.gm-back.on,.popmenu.on,.on').forEach(e=>{if(/back|menu|modal|dlg/i.test(e.className))e.classList.remove('on')})"); pg.wait_for_timeout(200)
            R.chk(not buried, "product overlays paint on top and are clickable in embed mode (%d triggers)" % len(triggers), buried)
        else:
            R.chk(True, "no inline view to embed — overlay guard n/a")
    except Exception as ex:
        R.chk(False, "overlay guard ran", str(ex)[:140])

def file_smoke(R, pg):
    R.feature = "file:// hub smoke"
    pg.goto(R.url); pg.wait_for_selector("#wv-la-u", state="attached", timeout=60000)
    login(pg, remember=False)
    R.chk(wait_hub_ready(pg, 1, 60000), "file:// hub: child frame reaches ready")
    R.chk(widget_ready(pg, 45000), "file:// hub: chat bundle loads relative")
    f = hub_frame(pg)
    R.chk(f is not None and f.evaluate("EMB.on&&!!document.querySelector('[data-wv-product-root]')"), "file:// child frame mounted its product root")
    J(pg, "infoDockSet('dock');toggleInfo(true)"); pg.wait_for_timeout(500)
    R.chk(f.evaluate("S.infoMode===true"), "file:// info brief reaches the frame (opaque origin, targetOrigin *)")
    J(pg, "toggleInfo(false);infoDockSet('float');doLogout()")

# ================================================================== driver
def run_one(p, label, url, mode, shots, headed, only):
    R = Run(label, url, mode, shots, headed, only)
    print("\n=== %s (%s) — %s ===" % (label, mode, url), flush=True)
    b = p.chromium.launch(channel="chrome", headless=not headed)
    ctx = b.new_context(viewport={"width": 1600, "height": 900})
    ctx.on("page", lambda pg: R.attach(pg) if pg not in R.pages else None)
    pg = ctx.new_page(); R.attach(pg)
    try:
        if mode == "smoke":
            smoke(R, pg)
        elif mode == "file":
            file_smoke(R, pg)
        else:
            steps = [("boot+login", lambda: f_boot(R, pg, ctx)), ("hub", lambda: f_hub(R, pg, ctx)),
                     ("modes", lambda: f_modes(R, pg, ctx)),
                     ("launchpad", lambda: f_launchpad(R, pg)), ("palette", lambda: f_palette(R, pg, ctx)),
                     ("nav", lambda: f_nav(R, pg)), ("views", lambda: f_views(R, pg)), ("workspaces", lambda: f_workspaces(R, pg)),
                     ("popouts", lambda: f_popouts(R, pg, ctx)), ("alarms", lambda: f_alarms(R, pg)), ("gread", lambda: f_gread(R, pg)), ("gread-kind", lambda: f_gread_kind(R, pg)),
                     ("gread-i18n", lambda: f_gread_i18n(R, pg)),
                     ("genie-scope", lambda: f_genie_scope(R, pg)),
                     ("herald", lambda: f_herald(R, pg)), ("voice", lambda: f_voice(R, pg)), ("voice-briefing", lambda: f_briefing(R, pg, ctx)), ("voice-listening", lambda: f_listening(R, pg)), ("qs", lambda: f_qs(R, pg)),
                     ("settings", lambda: f_settings_view(R, pg)), ("i18n", lambda: f_i18n(R, pg)), ("presentation", lambda: f_presentation(R, pg)),
                     ("info", lambda: f_info(R, pg)), ("keys", lambda: f_keys_help(R, pg)), ("health", lambda: f_health_clock_time(R, pg)),
                     ("product", lambda: f_product_switch(R, pg)), ("embed", lambda: f_embed_protocol(R, pg)), ("widget", lambda: f_widget(R, pg, ctx)),
                     ("reset", lambda: f_reset_logout(R, pg, ctx))]
            for name, fn in steps:
                if name != "boot+login" and not R.want(name): continue
                try:
                    fn()
                except Exception as e:
                    R.feature = name; R.chk(False, "feature crashed: " + name, "%s: %s" % (type(e).__name__, str(e)[:300]))
                    traceback.print_exc()
                    try: J(pg, "try{if(S.infoMode)toggleInfo(false);infoDockSet('float');closeModal();closeQS();closePalette();closeDrop();closeGenie();if(PRES.on)presentExit();$('#wv-adrawer').classList.remove('wv-open');closeNotif();$('#wv-keys').classList.remove('wv-open');$('#wv-vcmds').classList.remove('wv-open')}catch(e){}")  # never let one crash poison the next feature
                    except Exception: pass
                    try: pg.screenshot(path=str(shots / ("%s_%s_crash.png" % (label, name))))
                    except Exception: pass
    finally:
        try: pg.screenshot(path=str(shots / ("%s_final.png" % label)))
        except Exception: pass
        b.close()
    # error gate
    R.feature = "error gate"
    bad_cons = [c for c in R.cons if not c["ok"]]
    R.chk(not R.errs, "zero pageerror (page + frames + popups)", R.errs[:3])
    R.chk(not bad_cons, "zero non-tolerated console.error", bad_cons[:3])
    if R.probe404:
        R.chk(True, "designed loader probe 404 seen on %d page(s) — chat/ resolved via ../chat/" % len(set(R.probe404)))
    return R

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", action="append")
    ap.add_argument("--smoke", action="store_true"); ap.add_argument("--file", action="store_true")
    ap.add_argument("--only"); ap.add_argument("--headed", action="store_true")
    ap.add_argument("--shots", default=os.path.join(os.environ.get("TEMP", "."), "wv-verify-shots"))
    ap.add_argument("--json"); ap.add_argument("--set", help="comma list of default-set labels to run")
    a = ap.parse_args()
    shots = pathlib.Path(a.shots); shots.mkdir(parents=True, exist_ok=True)
    targets = []
    if a.url:
        for u in a.url: targets.append((re.sub(r"\W+", "_", u.split("/")[-1].split(".html")[0])[:24], u, "smoke" if a.smoke else ("file" if a.file else "deep")))
    else:
        sel = set(a.set.split(",")) if a.set else None
        targets = [t for t in DEFAULT_SET if not sel or t[0] in sel]
    results = []
    with sync_playwright() as p:
        for label, url, mode in targets:
            results.append(run_one(p, label, url, mode, shots, a.headed, a.only))
    print("\n" + "=" * 78 + "\nTALLY")
    total_p = total_f = 0; report = {}
    for R in results:
        P = sum(v[0] for v in R.tally.values()); F = sum(v[1] for v in R.tally.values()); total_p += P; total_f += F
        print("%-10s %4d pass %3d fail | pageerror=%d console.error(non-tolerated)=%d" % (R.label, P, F, len(R.errs), len([c for c in R.cons if not c["ok"]])))
        for k, v in R.tally.items(): print("    %-58s %3d/%-3d" % (k, v[0], v[0] + v[1]))
        for f in R.fails: print("    FAIL [%s] %s — %s" % f)
        report[R.label] = {"url": R.url, "mode": R.mode, "pass": P, "fail": F, "tally": R.tally, "fails": R.fails, "pageerrors": R.errs,
                           "console_errors": [c for c in R.cons if not c["ok"]], "tolerated_console": [c for c in R.cons if c["ok"]]}
    print("TOTAL %d pass / %d fail" % (total_p, total_f))
    if a.json: pathlib.Path(a.json).write_text(json.dumps(report, indent=1, ensure_ascii=False), encoding="utf-8")
    sys.exit(1 if total_f else 0)

if __name__ == "__main__":
    main()
