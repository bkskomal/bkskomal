# -*- coding: utf-8 -*-
"""genie-shell-update splice: framework chunks -> converted dashboards + the hub.
Per the skill: assert every chunk matches exactly once in both files BEFORE
writing; backups beside each file; bump the wv-shell-version meta.

Targets (paths relative to E:\\AI\\Self\\Genie): the eight converted dashboards in
dashboards/ and index.html (app-id "hub", 2026-08-28) — the hub's own
layer lives inside its WV-PRODUCT registration block, outside the nine WV-SHELL
chunks, so the splice never touches it.

Usage:
  python splice_111.py                 # live splice of every target (backups kept)
  python splice_111.py --dry [paths…]  # compute the splice, report changed/no-op, write NOTHING
  python splice_111.py path [path…]    # live splice of the named targets only
"""
import pathlib, re, shutil, sys, hashlib

# EXPORT BUILD - the tree is wherever THIS FILE lives, not a machine-specific path.
HOME = pathlib.Path(__file__).resolve().parents[1]
FW = (HOME / "GenieApplicationShell.html").read_text(encoding="utf-8")
CHUNKS = ["fonts","css","symbols","login","app","overlays","js-core","js-render","js-app"]
NEWVER = re.search(r'<meta name="wv-shell-version" content="([^"]+)">', FW).group(1)
# 2026-09-05 — targets are DISCOVERED, not listed: every dashboards/*_wv*.html (minus
# *pre-* backups) plus the hub. Drop a converted dashboard in and it is spliced automatically.
import glob as _glob, os as _os
_dash = sorted(p.replace("\\", "/")
               for d in ("dashboards", "reference")
               for p in _glob.glob(d + "/*_wv*.html")
               if "pre-" not in _os.path.basename(p))
TARGETS = _dash + ["index.html"]  # the hub (app-id "hub") — stamp handled like the others
args = [a for a in sys.argv[1:]]
DRY = "--dry" in args
args = [a for a in args if a != "--dry"]
targets = args or TARGETS

def rng(src, name):
    b = f"<!-- WV-SHELL:BEGIN {name} -->"
    e = f"<!-- WV-SHELL:END {name} -->"
    ib, ie = src.count(b), src.count(e)
    if ib != 1 or ie != 1: return None
    i = src.index(b); j = src.index(e) + len(e)
    if j <= i: return None
    return (i, j)

fw_chunks = {}
for n in CHUNKS:
    r = rng(FW, n)
    assert r, f"framework chunk broken: {n}"
    fw_chunks[n] = FW[r[0]:r[1]]

for fname in targets:
    fp = (HOME / fname) if not pathlib.Path(fname).is_absolute() else pathlib.Path(fname)
    raw = fp.read_bytes()
    src = raw.decode("utf-8")
    src = src.replace("\r\n", "\n")  # same normalization read_text() applied to the framework
    oldver = re.search(r'<meta name="wv-shell-version" content="([^"]+)">', src)
    assert oldver, f"{fname}: no version meta"
    # dry-run: every chunk must match exactly once BEFORE any write
    ranges = {}
    for n in CHUNKS:
        r = rng(src, n)
        assert r, f"{fname}: chunk sentinel mismatch: {n} — ABORTING file untouched"
        ranges[n] = r
    # splice back-to-front so earlier offsets stay valid
    for n in sorted(CHUNKS, key=lambda x: ranges[x][0], reverse=True):
        i, j = ranges[n]
        src = src[:i] + fw_chunks[n] + src[j:]
    src = re.sub(r'<meta name="wv-shell-version" content="[^"]+">',
                 f'<meta name="wv-shell-version" content="{NEWVER}">', src, count=1)
    out = src.replace("\n", "\r\n").encode("utf-8")  # write_text's newline translation on Windows
    changed = out != raw
    if DRY:
        print(f"[dry] {fname}: {oldver.group(1)} -> {NEWVER} · {'CHANGED' if changed else 'no-op (byte-identical)'} · "
              f"md5 {hashlib.md5(raw).hexdigest()} -> {hashlib.md5(out).hexdigest()}")
        continue
    if not changed:
        print(f"{fname}: already at {NEWVER} — byte-identical, skipped (no backup written)")
        continue
    shutil.copy(fp, fp.with_name(fp.stem + f".pre-{oldver.group(1).split()[0]}.html"))
    fp.write_bytes(out)
    print(f"{fname}: {oldver.group(1)} -> {NEWVER} (9 chunks spliced, backup kept)")
print("round splice complete" if not DRY else "dry run complete — nothing written")
