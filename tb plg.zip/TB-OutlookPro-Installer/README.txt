TB-OutlookPro Installer
=======================

This package installs the OutlookPro suite for Thunderbird: 10 bundles
that make Thunderbird feel like Outlook (Exchange auth, calendar +
contacts over EWS, MAPI/HTTP, compose UX, rules, layout, triage,
composer-plus, people, and search).

Requirements
------------
  * Windows 10 / 11
  * Thunderbird 115 or newer (140+ recommended for EWS)
  * PowerShell 5.1 or newer (bundled with Windows 10/11)

Quick install (fresh machine)
-----------------------------
  1. Unzip this folder anywhere (e.g. C:\Tools\TB-OutlookPro).
  2. Open PowerShell as your normal user in this folder.
     If your PowerShell blocks unsigned scripts, run first:
        Set-ExecutionPolicy -Scope Process Bypass
  3. Run:
        .\install.ps1

  The installer:
     - Detects Thunderbird from the standard install paths
     - Detects your default Thunderbird profile from profiles.ini
     - Copies all 10 .xpi files into <profile>\extensions\
     - Sets required prefs in user.js (experiments enabled, unsigned OK)
     - Clears the addon startup cache
     - Launches Thunderbird

Upgrade from older fine-grained OutlookPro plugins
--------------------------------------------------
If you previously installed the older 13-plugin build (with plugins
named outlookpro-cards-default, outlookpro-folder-size, ...), remove
those first:
    .\uninstall_old.ps1
    .\install.ps1

Both scripts are idempotent -- safe to re-run.

Common options
--------------
  .\install.ps1 -ProfileName default-release
        Target a specific profile by substring match.

  .\install.ps1 -ProfileName "C:\path\to\my-profile"
        Target a specific profile by absolute path.

  .\install.ps1 -NoLaunch
        Don't auto-launch Thunderbird after install.

  .\install.ps1 -ThunderbirdExe "D:\Portable\thunderbird.exe"
        Point at a portable / non-standard TB install.

What gets installed (10 bundles)
--------------------------------
  outlookpro-adfs-oauth     ADFS federated OAuth 2.0 for IMAP + SMTP
  outlookpro-mapi-http      Native MAPI over HTTP transport
  outlookpro-ews            Exchange EWS Calendar + Contacts
  outlookpro-composer       Compose-in-tab + Reply-All CC fix + Recall
  outlookpro-rules          Auto Archive + OOF + Quick Rule + Server rules
  outlookpro-view           Cards-view default + Folder Size + View ribbon
  outlookpro-triage         Snooze + Sweep + Follow Up + Ignore thread
  outlookpro-composer-plus  Undo Send + Attachment Reminder + Signatures + @Mentions
  outlookpro-people         Sender Info + DL expansion + Check Names (Ctrl+Shift+K)
  outlookpro-search         Instant filters + Saved Searches

Total size: ~193 KB installed.

Verifying after install
-----------------------
Open Thunderbird -> Tools -> Add-ons and Themes -> Extensions.
You should see 10 rows starting with "OutlookPro:" all enabled with no
red error badges. If any show a red badge, that add-on failed to load;
click Details for the error message.

Troubleshooting
---------------
  * "Thunderbird not found" -- pass -ThunderbirdExe with the full path
    to your thunderbird.exe.

  * "Could not resolve TB profile" -- pass -ProfileName with the
    profile folder name (found under %APPDATA%\Thunderbird\Profiles\).

  * TB launches but add-ons show red badges -- the required prefs may
    not have taken effect. Reopen a fresh Thunderbird instance, or set
    them manually via Tools -> Config Editor.

  * Add-ons install but don't appear in the UI -- the addon startup
    cache is stale. Delete <profile>\addonStartup.json.lz4 and relaunch.

Uninstalling (full removal)
---------------------------
To remove all 10 bundles (without touching the older 11):
    Get-ChildItem "$env:APPDATA\Thunderbird\Profiles\*\extensions\outlookpro-*@oss.local.xpi" |
      Remove-Item -Force

Then relaunch Thunderbird.

License
-------
MIT.

Prepared by OATI Technology, 2026.
