#requires -Version 5.1
<#
.SYNOPSIS
  Installs the OutlookPro suite (10 bundles) into a Thunderbird profile.

.DESCRIPTION
  Idempotent. Steps:
   1. Verifies Thunderbird is installed and version >= 115.
   2. Stops Thunderbird if running.
   3. Resolves the target profile (auto-detect from profiles.ini, or -ProfileName).
   4. Copies the 10 .xpi files from plugins\ into <profile>\extensions\.
   5. Appends required prefs to <profile>\user.js (creates if missing):
        - extensions.experiments.enabled           = true
        - extensions.autoDisableScopes             = 0
        - extensions.enabledScopes                 = 15
        - xpinstall.signatures.required            = false
        - extensions.legacy.enabled                = true
   6. Clears addonStartup.json.lz4 so TB rescans add-ons on next launch.
   7. Optionally launches Thunderbird.

.PARAMETER ProfileName
  Profile name substring OR full profile-dir path.
  Omit to auto-detect the default profile from profiles.ini.

.PARAMETER NoLaunch
  Skip auto-launching Thunderbird after install.

.PARAMETER ThunderbirdExe
  Path to thunderbird.exe (default: standard install path, x64 or x86).

.PARAMETER MinTbVersion
  Minimum TB major version accepted (default: 115).

.EXAMPLE
  .\install.ps1
  .\install.ps1 -ProfileName default-release
  .\install.ps1 -ProfileName "C:\path\to\profile"
  .\install.ps1 -NoLaunch
#>
param(
  [string]$ProfileName = "",
  [switch]$NoLaunch,
  [string]$ThunderbirdExe = "",
  [int]$MinTbVersion = 115
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# The 10 bundles this installer ships, mapped to their gecko-id filenames.
$AddonMap = @{
  "outlookpro-adfs-oauth.xpi"      = "outlookpro-adfs-oauth@oss.local.xpi"
  "outlookpro-mapi-http.xpi"       = "outlookpro-mapi-http@oss.local.xpi"
  "outlookpro-ews.xpi"             = "outlookpro-ews@oss.local.xpi"
  "outlookpro-composer.xpi"        = "outlookpro-composer@oss.local.xpi"
  "outlookpro-rules.xpi"           = "outlookpro-rules@oss.local.xpi"
  "outlookpro-view.xpi"            = "outlookpro-view@oss.local.xpi"
  "outlookpro-triage.xpi"          = "outlookpro-triage@oss.local.xpi"
  "outlookpro-composer-plus.xpi"   = "outlookpro-composer-plus@oss.local.xpi"
  "outlookpro-people.xpi"          = "outlookpro-people@oss.local.xpi"
  "outlookpro-search.xpi"          = "outlookpro-search@oss.local.xpi"
}

$RequiredPrefs = @(
  @{ key = "extensions.experiments.enabled";   line = 'user_pref("extensions.experiments.enabled", true);' },
  @{ key = "extensions.autoDisableScopes";     line = 'user_pref("extensions.autoDisableScopes", 0);' },
  @{ key = "extensions.enabledScopes";         line = 'user_pref("extensions.enabledScopes", 15);' },
  @{ key = "xpinstall.signatures.required";    line = 'user_pref("xpinstall.signatures.required", false);' },
  @{ key = "extensions.legacy.enabled";        line = 'user_pref("extensions.legacy.enabled", true);' }
)

# ---------- 0. Verify Thunderbird ----------
Write-Host "Step 0/7   Verifying Thunderbird installation..." -ForegroundColor Cyan
if (-not $ThunderbirdExe) {
  $candidates = @(
    "C:\Program Files\Mozilla Thunderbird\thunderbird.exe",
    "C:\Program Files (x86)\Mozilla Thunderbird\thunderbird.exe"
  )
  foreach ($c in $candidates) {
    if (Test-Path $c) { $ThunderbirdExe = $c; break }
  }
}
if (-not $ThunderbirdExe -or -not (Test-Path $ThunderbirdExe)) {
  throw "Thunderbird not found. Install TB $MinTbVersion+ or pass -ThunderbirdExe <path>."
}
$tbInfo = (Get-Item $ThunderbirdExe).VersionInfo
$tbVer  = $tbInfo.ProductVersion
$tbMajor = [int]($tbVer.Split('.')[0])
if ($tbMajor -lt $MinTbVersion) {
  throw "Thunderbird $tbVer found, but $MinTbVersion+ required."
}
Write-Host "  Thunderbird $tbVer at $ThunderbirdExe" -ForegroundColor Green

# ---------- 1. Stop TB ----------
Write-Host "Step 1/7   Stopping Thunderbird (if running)..." -ForegroundColor Cyan
Get-Process thunderbird -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 3

# ---------- 2. Resolve profile ----------
Write-Host "Step 2/7   Resolving Thunderbird profile..." -ForegroundColor Cyan
$profilesRoot = Join-Path $env:APPDATA "Thunderbird\Profiles"
$profileDir = $null

if ($ProfileName -and (Test-Path $ProfileName)) {
  $profileDir = (Resolve-Path $ProfileName).Path
} elseif ($ProfileName) {
  $match = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
           Where-Object { $_.Name -like "*$ProfileName*" } |
           Select-Object -First 1
  if ($match) { $profileDir = $match.FullName }
} else {
  # Read the default profile from profiles.ini
  $pi = Join-Path $env:APPDATA "Thunderbird\profiles.ini"
  if (Test-Path $pi) {
    $lines = Get-Content $pi
    $inInstall = $false
    foreach ($ln in $lines) {
      if ($ln -match "^\[Install") { $inInstall = $true; continue }
      if ($ln -match "^\[")        { $inInstall = $false; continue }
      if ($inInstall -and $ln -match "^Default\s*=\s*(.+)$") {
        $relPath = $Matches[1].Trim()
        $candidate = Join-Path (Split-Path $pi -Parent) $relPath
        if (Test-Path $candidate) { $profileDir = $candidate; break }
      }
    }
    # Fallback: pick the newest *.default-release
    if (-not $profileDir) {
      $fallback = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -like "*.default-release" } |
                  Sort-Object LastWriteTime -Descending |
                  Select-Object -First 1
      if ($fallback) { $profileDir = $fallback.FullName }
    }
  }
}
if (-not $profileDir -or -not (Test-Path $profileDir)) {
  throw "Could not resolve TB profile. Pass -ProfileName <name-or-path>."
}
Write-Host "  Profile: $profileDir" -ForegroundColor Green

$extDir = Join-Path $profileDir "extensions"
if (-not (Test-Path $extDir)) { New-Item -ItemType Directory -Path $extDir | Out-Null }

# ---------- 3. Install XPIs ----------
Write-Host "Step 3/7   Installing 10 OutlookPro bundles..." -ForegroundColor Cyan
$pluginsDir = Join-Path $here "plugins"
if (-not (Test-Path $pluginsDir)) {
  throw "plugins\ folder not found next to this script. Extract the installer zip fully before running."
}

$installed = 0
foreach ($srcName in $AddonMap.Keys) {
  $src = Join-Path $pluginsDir $srcName
  if (-not (Test-Path $src)) {
    Write-Host ("  [MISS] {0}" -f $srcName) -ForegroundColor Yellow
    continue
  }
  $dst = Join-Path $extDir $AddonMap[$srcName]
  Copy-Item $src $dst -Force
  $sz = (Get-Item $src).Length
  Write-Host ("  [OK]   {0,-46} {1,8:N0} bytes" -f $AddonMap[$srcName], $sz) -ForegroundColor Green
  $installed++
}

# ---------- 4. Ensure required prefs ----------
Write-Host "Step 4/7   Ensuring required prefs in user.js..." -ForegroundColor Cyan
$userJs = Join-Path $profileDir "user.js"
$existing = ""
if (Test-Path $userJs) { $existing = Get-Content $userJs -Raw }

$appendLines = @()
foreach ($p in $RequiredPrefs) {
  if ($existing -notmatch [regex]::Escape($p.key)) {
    $appendLines += $p.line
    Write-Host ("  [ADD] {0}" -f $p.key) -ForegroundColor Green
  } else {
    Write-Host ("  [OK]  {0} already set" -f $p.key) -ForegroundColor DarkGray
  }
}
if ($appendLines.Count -gt 0) {
  $block = "`r`n# OutlookPro required prefs`r`n" + ($appendLines -join "`r`n") + "`r`n"
  Add-Content -Path $userJs -Value $block -Encoding ASCII
}

# ---------- 5. Clear addonStartup cache ----------
Write-Host "Step 5/7   Clearing addonStartup cache..." -ForegroundColor Cyan
$cache = Join-Path $profileDir "addonStartup.json.lz4"
if (Test-Path $cache) {
  Remove-Item $cache -Force
  Write-Host "  [OK]  addonStartup.json.lz4 cleared" -ForegroundColor Green
} else {
  Write-Host "  [--]  no cache to clear" -ForegroundColor DarkGray
}

# ---------- 6. Summary ----------
Write-Host ""
Write-Host ("Step 6/7   SUMMARY: installed {0} of {1} bundles" -f $installed, $AddonMap.Count) -ForegroundColor Cyan
Write-Host ""

# ---------- 7. Launch TB ----------
Write-Host "Step 7/7   Launching Thunderbird..." -ForegroundColor Cyan
if (-not $NoLaunch) {
  Start-Process $ThunderbirdExe
  Write-Host "  [OK]  Thunderbird starting" -ForegroundColor Green
} else {
  Write-Host "  [--]  -NoLaunch set, skip" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "DONE. Open Tools -> Add-ons and Themes to verify all 10 OutlookPro bundles are enabled." -ForegroundColor Cyan
Write-Host "If you had older fine-grained OutlookPro bundles installed, run uninstall_old.ps1 first." -ForegroundColor Yellow
