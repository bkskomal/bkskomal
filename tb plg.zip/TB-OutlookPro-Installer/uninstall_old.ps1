#requires -Version 5.1
<#
.SYNOPSIS
  Removes the 11 old fine-grained OutlookPro add-ons from a Thunderbird
  profile, before installing the 10 new consolidated bundles.

.DESCRIPTION
  Idempotent -- safe to run twice; no-op for any bundles already gone.
  Steps:
   1. Stops Thunderbird if running.
   2. Resolves the target profile (auto-detect from profiles.ini, or -ProfileName).
   3. Removes the 11 old @oss.local.xpi files from <profile>\extensions\.
   4. Clears addonStartup.json.lz4 so TB rescans on next launch.

  Does NOT remove:
   - The 10 new bundles (outlookpro-adfs-oauth, ..., outlookpro-search)
   - Any non-OutlookPro extensions
   - Any user prefs or data (storage.local per-extension is scoped by ID
     and will be inaccessible from the new bundles anyway; user reconfigures)

.PARAMETER ProfileName
  Profile name substring OR full profile-dir path.
  Omit to auto-detect the default profile from profiles.ini.

.EXAMPLE
  .\uninstall_old.ps1
  .\uninstall_old.ps1 -ProfileName default-release
#>
param(
  [string]$ProfileName = ""
)

$ErrorActionPreference = "Stop"

# The 11 old fine-grained bundles that were consolidated into 4 merged ones.
$OldBundles = @(
  "outlookpro-cards-default@oss.local.xpi",
  "outlookpro-folder-size@oss.local.xpi",
  "outlookpro-compose-in-tab@oss.local.xpi",
  "outlookpro-reply-all-fix@oss.local.xpi",
  "outlookpro-recall@oss.local.xpi",
  "outlookpro-ews-calendar@oss.local.xpi",
  "outlookpro-ews-contacts@oss.local.xpi",
  "outlookpro-auto-archive@oss.local.xpi",
  "outlookpro-auto-reply@oss.local.xpi",
  "outlookpro-quick-rule@oss.local.xpi",
  "outlookpro-server-rules@oss.local.xpi"
)

# ---------- 1. Stop TB ----------
Write-Host "Step 1/4   Stopping Thunderbird (if running)..." -ForegroundColor Cyan
Get-Process thunderbird -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 3

# ---------- 2. Resolve profile ----------
Write-Host "Step 2/4   Resolving Thunderbird profile..." -ForegroundColor Cyan
$profilesRoot = Join-Path $env:APPDATA "Thunderbird\Profiles"
$profileDir = $null

if ($ProfileName -and (Test-Path $ProfileName)) {
  $profileDir = (Resolve-Path $ProfileName).Path
} elseif ($ProfileName) {
  $match = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
           Where-Object { $_.Name -like "*$ProfileName*" } |
           Select-Object -First 1
  if ($match) { $profileDir = $match.FullName }
} else {
  $pi = Join-Path $env:APPDATA "Thunderbird\profiles.ini"
  if (Test-Path $pi) {
    $lines = Get-Content $pi
    $inInstall = $false
    foreach ($ln in $lines) {
      if ($ln -match "^\[Install") { $inInstall = $true; continue }
      if ($ln -match "^\[")        { $inInstall = $false; continue }
      if ($inInstall -and $ln -match "^Default\s*=\s*(.+)$") {
        $relPath = $Matches[1].Trim()
        $candidate = Join-Path (Split-Path $pi -Parent) $relPath
        if (Test-Path $candidate) { $profileDir = $candidate; break }
      }
    }
    if (-not $profileDir) {
      $fallback = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -like "*.default-release" } |
                  Sort-Object LastWriteTime -Descending |
                  Select-Object -First 1
      if ($fallback) { $profileDir = $fallback.FullName }
    }
  }
}
if (-not $profileDir -or -not (Test-Path $profileDir)) {
  throw "Could not resolve TB profile. Pass -ProfileName <name-or-path>."
}
Write-Host "  Profile: $profileDir" -ForegroundColor Green

$extDir = Join-Path $profileDir "extensions"
if (-not (Test-Path $extDir)) {
  Write-Host "  No extensions/ folder present -- nothing to remove." -ForegroundColor Yellow
  return
}

# ---------- 3. Remove old bundles ----------
Write-Host "Step 3/4   Removing old fine-grained OutlookPro bundles..." -ForegroundColor Cyan
$removed = 0
$missing = 0
foreach ($n in $OldBundles) {
  $p = Join-Path $extDir $n
  if (Test-Path $p) {
    Remove-Item $p -Force
    Write-Host ("  [DEL]  {0}" -f $n) -ForegroundColor DarkYellow
    $removed++
  } else {
    Write-Host ("  [--]   {0} (not present)" -f $n) -ForegroundColor DarkGray
    $missing++
  }
}
Write-Host ("  Removed {0}, {1} already gone" -f $removed, $missing) -ForegroundColor Green

# ---------- 4. Clear cache ----------
Write-Host "Step 4/4   Clearing addonStartup cache..." -ForegroundColor Cyan
$cache = Join-Path $profileDir "addonStartup.json.lz4"
if (Test-Path $cache) {
  Remove-Item $cache -Force
  Write-Host "  [OK]  addonStartup.json.lz4 cleared" -ForegroundColor Green
} else {
  Write-Host "  [--]  no cache to clear" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "DONE. Now run .\install.ps1 to install the 10 new consolidated bundles." -ForegroundColor Cyan
