============================================================
 OutlookPro for Thunderbird -- Installer Bundle
============================================================

Turns Thunderbird 128+ into a drop-in Outlook replacement:
Outlook-style ribbon, ADFS OAuth, EWS calendar/contacts,
MAPI/HTTP, cards-view-by-default, composer polish, people
picker (Check Names equivalent), and more.

============================================================
 QUICK START -- ONE COMMAND
============================================================

Double-click Install-OutlookPro.cmd, or run:

  Install-OutlookPro.cmd

The batch file launches PowerShell with a per-invocation
ExecutionPolicy bypass (no system change), uninstalls any
old fine-grained bundles, installs the current 12 bundles
+ user.js template + userChrome.css + xulstore whitelist,
and launches Thunderbird.

If you prefer PowerShell directly:

  powershell -ExecutionPolicy Bypass -File .\Install-OutlookPro.ps1

Administrator rights are NOT required.

============================================================
 OPTIONS
============================================================

  Install-OutlookPro.cmd -ProfileName default-release
      Target a specific profile (substring match) instead of
      the auto-detected default.

  Install-OutlookPro.cmd -NoLaunch
      Install everything but do NOT auto-start Thunderbird.

  Install-OutlookPro.cmd -SkipUninstall
      Skip the "remove old bundles" phase (only run install).

  Install-OutlookPro.cmd -ThunderbirdExe "C:\Custom\Path\thunderbird.exe"
      Point at a non-standard TB install location.

Options combine freely:
  Install-OutlookPro.cmd -ProfileName bt572ve7 -NoLaunch

============================================================
 WHAT GETS INSTALLED
============================================================

12 add-ons (drop into <profile>\extensions\):
  outlookpro-adfs-oauth       ADFS OAuth2 credentials
  outlookpro-mapi-http        MAPI/HTTP transport layer
  outlookpro-ews              EWS calendar + contacts
  outlookpro-composer         New-message composer polish
  outlookpro-composer-plus    Extended composer features
  outlookpro-rules            Outlook-style client-side rules
  outlookpro-view             View controls + folder size
  outlookpro-triage           Rapid inbox triage
  outlookpro-people           Check Names (Ctrl+K equivalent)
  outlookpro-search           Advanced search bar
  outlookpro-cards-default    Cards view as default (owns
                              mail.threadpane.listview pref)
  outlookpro-ribbon           Outlook-style ribbon bar with
                              Home/Send-Receive/Folder/View/
                              Add-ons/Help tabs

Files copied into <profile>:
  user.js                     ~150-line Outlook-parity pref
                              template (idempotent: guarded by
                              a marker comment; safe to re-run)
  chrome\userChrome.css       Menu bar always visible + tab
                              polish + folder pane styling

xulstore.json patched:
  Whitelists outlookpro-view, outlookpro-ribbon,
  outlookpro-search in the unified toolbar's allowedExtSpaces
  so their browser_action buttons appear.

============================================================
 WHAT GETS UNINSTALLED (from any older release)
============================================================

10 legacy fine-grained bundles that were consolidated:
  outlookpro-folder-size          -> merged into outlookpro-view
  outlookpro-compose-in-tab       -> reverted; native TB compose
  outlookpro-reply-all-fix        -> merged into outlookpro-ribbon
  outlookpro-recall               -> merged into outlookpro-ribbon
  outlookpro-ews-calendar         -> merged into outlookpro-ews
  outlookpro-ews-contacts         -> merged into outlookpro-ews
  outlookpro-auto-archive         -> merged into outlookpro-rules
  outlookpro-auto-reply           -> merged into outlookpro-rules
  outlookpro-quick-rule           -> merged into outlookpro-rules
  outlookpro-server-rules         -> merged into outlookpro-rules

NOT removed:
  - Any non-OutlookPro add-on
  - Any current OutlookPro bundle
  - Any user data, prefs, mail, calendars, or contacts

============================================================
 REQUIREMENTS
============================================================

  - Windows 10 / 11
  - PowerShell 5.1 or newer (built into Windows)
  - Thunderbird 115 or newer, installed to a default path or
    passed with -ThunderbirdExe

The installer is idempotent -- re-running is safe. It replaces
existing XPIs, merges the user.js template only once (marker-
guarded), and appends missing prefs without touching existing
ones.

============================================================
 TROUBLESHOOTING
============================================================

Ribbon buttons don't appear after install:
  1. Fully quit Thunderbird
  2. Delete <profile>\addonStartup.json.lz4
  3. Re-launch Thunderbird

Profile not auto-detected:
  Pass -ProfileName <substring or full path>.
  Profiles live in %APPDATA%\Thunderbird\Profiles\.

Cards view is not the default:
  The outlookpro-cards-default add-on owns the
  mail.threadpane.listview pref. If a folder still opens in
  Table, wait 60 seconds (delayed pass catches IMAP folders)
  or click View -> Layout -> Cards once.
