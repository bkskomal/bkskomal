@echo off
REM Zero-friction launcher for Install-OutlookPro.ps1.
REM Bypasses execution policy for this one invocation only -- does not modify
REM system settings.
REM
REM Usage:
REM   Install-OutlookPro.cmd                       (auto profile, launches TB)
REM   Install-OutlookPro.cmd -ProfileName mine     (specific profile)
REM   Install-OutlookPro.cmd -NoLaunch             (skip TB launch)

setlocal
set SCRIPT_DIR=%~dp0
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%Install-OutlookPro.ps1" %*
set RC=%ERRORLEVEL%
echo.
if %RC% NEQ 0 (
  echo Install failed with exit code %RC%.
  pause
) else (
  echo Install complete.
  pause
)
exit /b %RC%
