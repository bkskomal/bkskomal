#requires -Version 5.1
<#
.SYNOPSIS
  Single-command OutlookPro installer -- uninstalls old bundles, then installs
  the current 12-bundle release.

.DESCRIPTION
  Runs uninstall_old.ps1 followed by install.ps1 in the same session. Both
  scripts are idempotent, so re-running this is safe.

  Steps:
   1. Kill Thunderbird if running (handled inside each child script).
   2. Uninstall old fine-grained bundles that were consolidated away.
   3. Install the current 12 bundles + user.js template + userChrome.css +
      xulstore whitelist for browser_action buttons.
   4. Launch Thunderbird (unless -NoLaunch).

  Everything is scoped to the ACTIVE Thunderbird profile. Non-OutlookPro
  extensions and user data are never touched.

.PARAMETER ProfileName
  Substring of the profile folder name, OR a full path to the profile.
  Omit to auto-detect the default profile from profiles.ini.

.PARAMETER NoLaunch
  Skip auto-launching Thunderbird at the end of the install step.

.PARAMETER ThunderbirdExe
  Path to thunderbird.exe. Omit for auto-detect
  (Program Files / Program Files (x86)).

.PARAMETER MinTbVersion
  Minimum TB major version accepted (default 115).

.PARAMETER SkipUninstall
  Skip the uninstall_old step (only run install). Useful when you know the
  target profile is clean.

.EXAMPLE
  # Zero-friction: uninstall old, install new, launch TB.
  .\Install-OutlookPro.ps1

.EXAMPLE
  # Point at a specific profile without launching TB.
  .\Install-OutlookPro.ps1 -ProfileName default-release -NoLaunch
#>
param(
  [string]$ProfileName    = "",
  [switch]$NoLaunch,
  [string]$ThunderbirdExe = "",
  [int]   $MinTbVersion   = 115,
  [switch]$SkipUninstall
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " OutlookPro for Thunderbird -- single-command installer"     -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Forward the same profile / TB args to both children.
$commonArgs = @{}
if ($ProfileName)    { $commonArgs['ProfileName']    = $ProfileName }

if (-not $SkipUninstall) {
  Write-Host ">>> Phase 1/2: uninstalling old fine-grained bundles"    -ForegroundColor Yellow
  & (Join-Path $here 'uninstall_old.ps1') @commonArgs
  Write-Host ""
} else {
  Write-Host ">>> Phase 1/2: skipped (SkipUninstall)"                   -ForegroundColor DarkGray
  Write-Host ""
}

$installArgs = $commonArgs.Clone()
if ($NoLaunch)       { $installArgs['NoLaunch']       = $true }
if ($ThunderbirdExe) { $installArgs['ThunderbirdExe'] = $ThunderbirdExe }
if ($MinTbVersion)   { $installArgs['MinTbVersion']   = $MinTbVersion }

Write-Host ">>> Phase 2/2: installing current OutlookPro bundles"      -ForegroundColor Yellow
& (Join-Path $here 'install.ps1') @installArgs
Write-Host ""

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " OutlookPro installation complete."                          -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
