@echo off
REM Deliberately NO EnableDelayedExpansion -- causes '!' in paths to be
REM interpreted and produces the "was unexpected at this time" batch
REM parse error on some paths.
setlocal EnableExtensions
title OutlookPro for Thunderbird -- Setup

REM %~dp0 ends with a backslash. Strip it so we never emit paths
REM ending in \" (which CMD parses as an escaped quote, breaking
REM every "if exist ..." check that follows).
set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

echo.
echo ============================================================
echo  OutlookPro for Thunderbird -- Final Package
echo  Setup ^| unblock -^> uninstall ALL -^> install current 15
echo ============================================================
echo.

REM ---- Step 0: normalise layout ----
REM The .exe self-extractor drops every file flat into a temp dir; the .zip
REM distribution keeps XPIs inside plugins\. install.ps1 expects plugins\.
REM If we see loose outlookpro-*.xpi files and no plugins\ dir, move them.
if not exist "%SCRIPT_DIR%\plugins" (
  if exist "%SCRIPT_DIR%\outlookpro-adfs-oauth.xpi" (
    echo [0/3] Normalising layout ^(flat .exe extract -^> plugins\ dir^)...
    mkdir "%SCRIPT_DIR%\plugins" >nul 2>&1
    move /Y "%SCRIPT_DIR%\outlookpro-*.xpi" "%SCRIPT_DIR%\plugins" >nul
    echo        moved XPIs into plugins\
    echo.
  )
)


REM ---- Step 1: unblock all .ps1 files (removes Mark of the Web) ----
REM Downloaded PowerShell scripts carry a Zone.Identifier that blocks execution
REM even under -ExecutionPolicy Bypass. Unblock-File strips that marker for
REM this session only -- no system setting is changed.
echo [1/3] Unblocking PowerShell scripts...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$files = Get-ChildItem -Path '%SCRIPT_DIR%' -Filter '*.ps1' -File -Recurse -ErrorAction SilentlyContinue; if ($files) { $files | Unblock-File -ErrorAction SilentlyContinue; Write-Host ('       ' + $files.Count + ' .ps1 file(s) unblocked') -ForegroundColor Green } else { Write-Host '       no .ps1 files found' -ForegroundColor Yellow }"
if errorlevel 1 (
  echo.
  echo [!!] Unblock step failed. If you saved the zip with "Extract to..."
  echo      from Windows Explorer, some AV products or Group Policy may block
  echo      Unblock-File. Try running this .cmd from an elevated Command
  echo      Prompt ^(right-click -^> Run as administrator^).
  echo.
  pause
  exit /b 1
)
echo.

REM ---- Step 2: uninstall ALL OutlookPro bundles (current 15 + legacy 10) ----
REM Uses the full uninstall.ps1 which removes 25 possible extension IDs.
REM Idempotent -- safe when nothing is installed. -KeepPrefs keeps user.js
REM alone; the install step below re-adds anything missing.
echo [2/3] Uninstalling ALL existing OutlookPro bundles ^(current + legacy^)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%\uninstall.ps1" -KeepPrefs -KeepUserChromeCss %*
if errorlevel 1 (
  echo.
  echo [!!] Uninstall step returned exit code %ERRORLEVEL%.
  echo      Continuing to install anyway -- uninstall is idempotent and
  echo      failure usually just means nothing was there to remove.
  echo.
)
echo.

REM ---- Step 3: install the current 15 bundles + prefs + userChrome.css ----
echo [3/3] Installing current 15 OutlookPro bundles...
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%\install.ps1" %*
set "RC=%ERRORLEVEL%"
echo.

echo ============================================================
if not "%RC%"=="0" (
  echo Install failed with exit code %RC%.
  echo Scroll up for details.
  echo ============================================================
  pause
  exit /b %RC%
)
echo Install complete. Thunderbird was launched with OutlookPro.
echo ============================================================
echo.
echo Press any key to close this window.
pause >nul
exit /b 0
