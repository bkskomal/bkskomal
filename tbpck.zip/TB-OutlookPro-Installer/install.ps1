#requires -Version 5.1
<#
.SYNOPSIS
  Installs the OutlookPro suite (10 bundles) into a Thunderbird profile.

.DESCRIPTION
  Idempotent. Steps:
   1. Verifies Thunderbird is installed and version >= 115.
   2. Stops Thunderbird if running.
   3. Resolves the target profile (auto-detect from profiles.ini, or -ProfileName).
   4. Copies the 10 .xpi files from plugins\ into <profile>\extensions\.
   5. Appends required prefs to <profile>\user.js (creates if missing):
        - extensions.experiments.enabled           = true
        - extensions.autoDisableScopes             = 0
        - extensions.enabledScopes                 = 15
        - xpinstall.signatures.required            = false
        - extensions.legacy.enabled                = true
   6. Clears addonStartup.json.lz4 so TB rescans add-ons on next launch.
   7. Optionally launches Thunderbird.

.PARAMETER ProfileName
  Profile name substring OR full profile-dir path.
  Omit to auto-detect the default profile from profiles.ini.

.PARAMETER NoLaunch
  Skip auto-launching Thunderbird after install.

.PARAMETER ThunderbirdExe
  Path to thunderbird.exe (default: standard install path, x64 or x86).

.PARAMETER MinTbVersion
  Minimum TB major version accepted (default: 115).

.EXAMPLE
  .\install.ps1
  .\install.ps1 -ProfileName default-release
  .\install.ps1 -ProfileName "C:\path\to\profile"
  .\install.ps1 -NoLaunch
#>
param(
  [string]$ProfileName = "",
  [switch]$NoLaunch,
  [string]$ThunderbirdExe = "",
  [int]$MinTbVersion = 115
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# The 12 bundles this installer ships, mapped to their gecko-id filenames.
# outlookpro-cards-default is separate from outlookpro-view now (it owns
# the mail.threadpane.listview pref; view's cards code no longer touches it).
# outlookpro-ribbon is the Outlook-style tabbed ribbon that replaces the
# unified toolbar.
$AddonMap = @{
  "outlookpro-adfs-oauth.xpi"      = "outlookpro-adfs-oauth@oss.local.xpi"
  "outlookpro-mapi-http.xpi"       = "outlookpro-mapi-http@oss.local.xpi"
  "outlookpro-ews.xpi"             = "outlookpro-ews@oss.local.xpi"
  "outlookpro-composer.xpi"        = "outlookpro-composer@oss.local.xpi"
  "outlookpro-rules.xpi"           = "outlookpro-rules@oss.local.xpi"
  "outlookpro-view.xpi"            = "outlookpro-view@oss.local.xpi"
  "outlookpro-triage.xpi"          = "outlookpro-triage@oss.local.xpi"
  "outlookpro-composer-plus.xpi"   = "outlookpro-composer-plus@oss.local.xpi"
  "outlookpro-people.xpi"          = "outlookpro-people@oss.local.xpi"
  "outlookpro-search.xpi"          = "outlookpro-search@oss.local.xpi"
  "outlookpro-cards-default.xpi"   = "outlookpro-cards-default@oss.local.xpi"
  "outlookpro-ribbon.xpi"          = "outlookpro-ribbon@oss.local.xpi"
  "outlookpro-archive.xpi"         = "outlookpro-archive@oss.local.xpi"
  "outlookpro-archive-dialog.xpi"  = "outlookpro-archive-dialog@oss.local.xpi"
  "outlookpro-header.xpi"          = "outlookpro-header@oss.local.xpi"
}

$RequiredPrefs = @(
  @{ key = "extensions.experiments.enabled";                    line = 'user_pref("extensions.experiments.enabled", true);' },
  @{ key = "extensions.autoDisableScopes";                      line = 'user_pref("extensions.autoDisableScopes", 0);' },
  @{ key = "extensions.enabledScopes";                          line = 'user_pref("extensions.enabledScopes", 15);' },
  @{ key = "xpinstall.signatures.required";                     line = 'user_pref("xpinstall.signatures.required", false);' },
  @{ key = "extensions.legacy.enabled";                         line = 'user_pref("extensions.legacy.enabled", true);' },
  # userChrome.css support (needed for Outlook-style tweaks)
  @{ key = "toolkit.legacyUserProfileCustomizations.stylesheets"; line = 'user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);' },
  # Ribbon acts as the titlebar (no separate title strip). userChrome.css
  # applies -moz-window-dragging to the ribbon area so the whole top bar
  # is a drag handle for the window.
  @{ key = "browser.tabs.inTitlebar";                            line = 'user_pref("browser.tabs.inTitlebar", 1);' },
  @{ key = "mailnews.default_sort_order";                       line = 'user_pref("mailnews.default_sort_order", 2);' },
  @{ key = "mail.thread.conversation.enabled";                 line = 'user_pref("mail.thread.conversation.enabled", false);' },
  @{ key = "mail.gloda.enabled";                                line = 'user_pref("mail.gloda.enabled", false);' },
  @{ key = "mailnews.default_sort_type";                        line = 'user_pref("mailnews.default_sort_type", 18);' },
  @{ key = "mail.threadpane.newestReplyFirst";                  line = 'user_pref("mail.threadpane.newestReplyFirst", true);' },
  @{ key = "mail.biff.show_alert";                             line = 'user_pref("mail.biff.show_alert", false);' },
  @{ key = "mail.biff.show_tray_icon";                         line = 'user_pref("mail.biff.show_tray_icon", false);' },
  @{ key = "mail.tabs.drawInTitlebar";                           line = 'user_pref("mail.tabs.drawInTitlebar", true);' }
)

# ---------- 0. Verify Thunderbird ----------
Write-Host "Step 0/7   Verifying Thunderbird installation..." -ForegroundColor Cyan
if (-not $ThunderbirdExe) {
  $candidates = @(
    "C:\Program Files\Mozilla Thunderbird\thunderbird.exe",
    "C:\Program Files (x86)\Mozilla Thunderbird\thunderbird.exe"
  )
  foreach ($c in $candidates) {
    if (Test-Path $c) { $ThunderbirdExe = $c; break }
  }
}
if (-not $ThunderbirdExe -or -not (Test-Path $ThunderbirdExe)) {
  throw "Thunderbird not found. Install TB $MinTbVersion+ or pass -ThunderbirdExe <path>."
}
$tbInfo = (Get-Item $ThunderbirdExe).VersionInfo
$tbVer  = $tbInfo.ProductVersion
$tbMajor = [int]($tbVer.Split('.')[0])
if ($tbMajor -lt $MinTbVersion) {
  throw "Thunderbird $tbVer found, but $MinTbVersion+ required."
}
Write-Host "  Thunderbird $tbVer at $ThunderbirdExe" -ForegroundColor Green

# ---------- 1. Stop TB ----------
Write-Host "Step 1/7   Stopping Thunderbird (if running)..." -ForegroundColor Cyan
Get-Process thunderbird -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 3

# ---------- 2. Resolve profile ----------
Write-Host "Step 2/7   Resolving Thunderbird profile..." -ForegroundColor Cyan
$profilesRoot = Join-Path $env:APPDATA "Thunderbird\Profiles"
$profileDir = $null

if ($ProfileName -and (Test-Path $ProfileName)) {
  $profileDir = (Resolve-Path $ProfileName).Path
} elseif ($ProfileName) {
  $match = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
           Where-Object { $_.Name -like "*$ProfileName*" } |
           Select-Object -First 1
  if ($match) { $profileDir = $match.FullName }
} else {
  # Read the default profile from profiles.ini
  $pi = Join-Path $env:APPDATA "Thunderbird\profiles.ini"
  if (Test-Path $pi) {
    $lines = Get-Content $pi
    $inInstall = $false
    foreach ($ln in $lines) {
      if ($ln -match "^\[Install") { $inInstall = $true; continue }
      if ($ln -match "^\[")        { $inInstall = $false; continue }
      if ($inInstall -and $ln -match "^Default\s*=\s*(.+)$") {
        $relPath = $Matches[1].Trim()
        $candidate = Join-Path (Split-Path $pi -Parent) $relPath
        if (Test-Path $candidate) { $profileDir = $candidate; break }
      }
    }
    # Fallback: pick the newest *.default-release
    if (-not $profileDir) {
      $fallback = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -like "*.default-release" } |
                  Sort-Object LastWriteTime -Descending |
                  Select-Object -First 1
      if ($fallback) { $profileDir = $fallback.FullName }
    }
  }
}
if (-not $profileDir -or -not (Test-Path $profileDir)) {
  throw "Could not resolve TB profile. Pass -ProfileName <name-or-path>."
}
Write-Host "  Profile: $profileDir" -ForegroundColor Green

$extDir = Join-Path $profileDir "extensions"
if (-not (Test-Path $extDir)) { New-Item -ItemType Directory -Path $extDir | Out-Null }

# ---------- 3. Install XPIs ----------
Write-Host "Step 3/7   Installing 10 OutlookPro bundles..." -ForegroundColor Cyan
$pluginsDir = Join-Path $here "plugins"
if (-not (Test-Path $pluginsDir)) {
  throw "plugins\ folder not found next to this script. Extract the installer zip fully before running."
}

$installed = 0
foreach ($srcName in $AddonMap.Keys) {
  $src = Join-Path $pluginsDir $srcName
  if (-not (Test-Path $src)) {
    Write-Host ("  [MISS] {0}" -f $srcName) -ForegroundColor Yellow
    continue
  }
  $dst = Join-Path $extDir $AddonMap[$srcName]
  Copy-Item $src $dst -Force
  $sz = (Get-Item $src).Length
  Write-Host ("  [OK]   {0,-46} {1,8:N0} bytes" -f $AddonMap[$srcName], $sz) -ForegroundColor Green
  $installed++
}

# ---------- 3b. Install vendor (third-party) XPIs ----------
# These are the 9 third-party add-ons Komal's reference machine relies on
# for the full Outlook-parity experience: CardBook (contacts panel),
# composeur-en-onglet (compose-in-tab renderer), ImportExportToolsNG,
# EAS4TbSync + TbSync (Exchange ActiveSync), gconversation, MailMerge,
# QuickFilters, Sieve. Bundled so a fresh target box gets the same UX
# without hunting each add-on down individually.
Write-Host "Step 3b/7  Installing vendor (third-party) add-ons..." -ForegroundColor Cyan
$vendorDir = Join-Path $here "vendor"
$vendorInstalled = 0; $vendorSkipped = 0
if (Test-Path $vendorDir) {
  Get-ChildItem $vendorDir -Filter "*.xpi" -File | ForEach-Object {
    $dst = Join-Path $extDir $_.Name
    if (Test-Path $dst) {
      # Compare sizes. Only overwrite if bundled version is different --
      # avoids downgrading a newer copy the user may have installed.
      $srcSize = $_.Length
      $dstSize = (Get-Item $dst).Length
      if ($srcSize -eq $dstSize) {
        Write-Host ("  [--]   {0,-52} unchanged ({1:N0} bytes)" -f $_.Name, $dstSize) -ForegroundColor DarkGray
        $vendorSkipped++
        return
      }
    }
    Copy-Item $_.FullName $dst -Force
    Write-Host ("  [OK]   {0,-52} {1:N0} bytes" -f $_.Name, $_.Length) -ForegroundColor Green
    $vendorInstalled++
  }
  Write-Host ("  Installed {0}, {1} unchanged" -f $vendorInstalled, $vendorSkipped) -ForegroundColor Green
} else {
  Write-Host "  [--]   no vendor/ folder in this installer -- skip" -ForegroundColor DarkGray
}

# ---------- 4. Ensure required prefs ----------
Write-Host "Step 4/7   Ensuring required prefs in user.js..." -ForegroundColor Cyan
$userJs = Join-Path $profileDir "user.js"
$existing = ""
if (Test-Path $userJs) { $existing = Get-Content $userJs -Raw }

$appendLines = @()
foreach ($p in $RequiredPrefs) {
  if ($existing -notmatch [regex]::Escape($p.key)) {
    $appendLines += $p.line
    Write-Host ("  [ADD] {0}" -f $p.key) -ForegroundColor Green
  } else {
    Write-Host ("  [OK]  {0} already set" -f $p.key) -ForegroundColor DarkGray
  }
}
if ($appendLines.Count -gt 0) {
  $block = "`r`n# OutlookPro required prefs`r`n" + ($appendLines -join "`r`n") + "`r`n"
  Add-Content -Path $userJs -Value $block -Encoding ASCII
}

# ---------- 4c. Merge OutlookPro user.js template ----------
# Ships the ~150-pref template (Outlook-parity defaults: quick filter, folder
# pane mode, thread-pane cards default, sort by date desc, HTML off by default,
# etc.). Marker-guarded: idempotent, safe to run twice.
Write-Host "Step 4c/7  Merging OutlookPro user.js template..." -ForegroundColor Cyan
$templateJs = Join-Path $here "user.js"
if (Test-Path $templateJs) {
  $tpl = Get-Content $templateJs -Raw
  $marker = "# --- OutlookPro user.js template (managed block) ---"
  # Re-read the current profile user.js since Step 4 may have appended to it
  $existing2 = if (Test-Path $userJs) { Get-Content $userJs -Raw } else { "" }
  if ($existing2 -notmatch [regex]::Escape($marker)) {
    $block = "`r`n$marker`r`n$tpl`r`n# --- end OutlookPro template ---`r`n"
    Add-Content -Path $userJs -Value $block -Encoding ASCII
    Write-Host ("  [OK]   template merged ({0:N0} bytes appended)" -f $tpl.Length) -ForegroundColor Green
  } else {
    Write-Host "  [--]   template already merged (marker found)" -ForegroundColor DarkGray
  }
} else {
  Write-Host "  [--]   user.js template not shipped in this installer; skip" -ForegroundColor DarkGray
}

# ---------- 4b. Copy userChrome.css to profile\chrome\ ----------
Write-Host "Step 4b/7  Installing userChrome.css (menu bar always visible + Outlook styling)..." -ForegroundColor Cyan
$userChromeSrc = Join-Path $here "userChrome.css"
if (Test-Path $userChromeSrc) {
  $chromeDir = Join-Path $profileDir "chrome"
  if (-not (Test-Path $chromeDir)) { New-Item -ItemType Directory -Path $chromeDir | Out-Null }
  $userChromeDst = Join-Path $chromeDir "userChrome.css"
  Copy-Item $userChromeSrc $userChromeDst -Force
  Write-Host ("  [OK]   userChrome.css copied ({0:N0} bytes)" -f (Get-Item $userChromeDst).Length) -ForegroundColor Green
} else {
  Write-Host "  [--]   userChrome.css not shipped in this installer; skip" -ForegroundColor DarkGray
}

# ---------- 4d. Allow OutlookPro extensions in the unified toolbar ----------
# TB's unified toolbar has an explicit allow-list (allowedExtSpaces) that
# hides browser_action buttons from any extension not on the list. We add
# our extensions with browser_action -- view, ribbon, search -- to the
# "mail" space so their toolbar buttons actually appear.
Write-Host "Step 4d/7  Whitelisting OutlookPro browser_action extensions in unified toolbar..." -ForegroundColor Cyan
$xulStore = Join-Path $profileDir "xulstore.json"
$msgUrl   = "chrome://messenger/content/messenger.xhtml"
$obpExtIds = @(
  "outlookpro-view@oss.local",
  "outlookpro-ribbon@oss.local",
  "outlookpro-search@oss.local"
)
try {
  if (Test-Path $xulStore) {
    $raw = Get-Content $xulStore -Raw
  } else {
    $raw = "{}"
  }
  $json = $raw | ConvertFrom-Json

  # Ensure the nested path exists: json.<msgUrl>.unifiedToolbar.allowedExtSpaces
  if (-not $json.$msgUrl) {
    $json | Add-Member -MemberType NoteProperty -Name $msgUrl -Value ([pscustomobject]@{})
  }
  if (-not $json.$msgUrl.unifiedToolbar) {
    $json.$msgUrl | Add-Member -MemberType NoteProperty -Name 'unifiedToolbar' -Value ([pscustomobject]@{})
  }

  # allowedExtSpaces is stored as a JSON STRING (double-encoded). Decode -> merge -> re-encode.
  $mapRaw = $json.$msgUrl.unifiedToolbar.allowedExtSpaces
  if ($mapRaw) {
    $map = $mapRaw | ConvertFrom-Json
  } else {
    $map = [pscustomobject]@{}
  }
  foreach ($id in $obpExtIds) {
    if (-not $map.$id) {
      $map | Add-Member -MemberType NoteProperty -Name $id -Value @("mail")
      Write-Host ("  [ADD] {0}" -f $id) -ForegroundColor Green
    } else {
      $cur = @($map.$id)
      if ($cur -notcontains "mail") {
        $map.$id = @($cur + "mail")
        Write-Host ("  [MERGE] {0}" -f $id) -ForegroundColor Green
      } else {
        Write-Host ("  [OK]  {0} already allowed" -f $id) -ForegroundColor DarkGray
      }
    }
  }
  $newMapRaw = $map | ConvertTo-Json -Depth 10 -Compress
  if (-not $json.$msgUrl.unifiedToolbar.allowedExtSpaces) {
    $json.$msgUrl.unifiedToolbar | Add-Member -MemberType NoteProperty -Name 'allowedExtSpaces' -Value $newMapRaw
  } else {
    $json.$msgUrl.unifiedToolbar.allowedExtSpaces = $newMapRaw
  }
  ($json | ConvertTo-Json -Depth 20 -Compress) | Set-Content $xulStore -Encoding ASCII
  Write-Host "  [OK]  xulstore.json unifiedToolbar.allowedExtSpaces updated" -ForegroundColor Green
} catch {
  Write-Host ("  [WARN] allowedExtSpaces patch failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
  Write-Host "         User can add buttons manually via toolbar right-click -> Customize." -ForegroundColor DarkGray
}

# ---------- 4c. Patch xulstore.json to persist menu bar visible ----------
Write-Host "Step 4c/7  Patching xulstore.json (menu bar autohide=false)..." -ForegroundColor Cyan
$xulStore = Join-Path $profileDir "xulstore.json"
$msgUrl   = "chrome://messenger/content/messenger.xhtml"
try {
  if (Test-Path $xulStore) {
    $json = Get-Content $xulStore -Raw | ConvertFrom-Json
    if (-not $json.$msgUrl) {
      $json | Add-Member -MemberType NoteProperty -Name $msgUrl -Value ([pscustomobject]@{})
    }
    if (-not $json.$msgUrl.'toolbar-menubar') {
      $json.$msgUrl | Add-Member -MemberType NoteProperty -Name 'toolbar-menubar' -Value ([pscustomobject]@{})
    }
    if (-not $json.$msgUrl.'toolbar-menubar'.autohide) {
      $json.$msgUrl.'toolbar-menubar' | Add-Member -MemberType NoteProperty -Name 'autohide' -Value 'false'
    } else {
      $json.$msgUrl.'toolbar-menubar'.autohide = 'false'
    }
    $json | ConvertTo-Json -Depth 20 -Compress | Set-Content $xulStore -Encoding ASCII
    Write-Host "  [OK]   xulstore.json patched: toolbar-menubar.autohide = false" -ForegroundColor Green
  } else {
    # Seed a minimal xulstore.json (TB will merge on next launch)
    $seed = '{"' + $msgUrl + '":{"toolbar-menubar":{"autohide":"false"}}}'
    Set-Content -Path $xulStore -Value $seed -Encoding ASCII
    Write-Host "  [OK]   xulstore.json created with menu bar visibility seed" -ForegroundColor Green
  }
} catch {
  Write-Host ("  [WARN] xulstore.json patch failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
  Write-Host "         Menu bar will still show via userChrome.css CSS override." -ForegroundColor DarkGray
}

# ---------- 5. Clear addonStartup cache ----------
Write-Host "Step 5/7   Clearing addonStartup cache..." -ForegroundColor Cyan
$cache = Join-Path $profileDir "addonStartup.json.lz4"
if (Test-Path $cache) {
  Remove-Item $cache -Force
  Write-Host "  [OK]  addonStartup.json.lz4 cleared" -ForegroundColor Green
} else {
  Write-Host "  [--]  no cache to clear" -ForegroundColor DarkGray
}

# ---------- 6. Summary ----------
Write-Host ""
Write-Host ("Step 6/7   SUMMARY: installed {0} of {1} bundles" -f $installed, $AddonMap.Count) -ForegroundColor Cyan
Write-Host ""

# ---------- 7. Launch TB ----------
Write-Host "Step 7/7   Launching Thunderbird..." -ForegroundColor Cyan
if (-not $NoLaunch) {
  Start-Process $ThunderbirdExe
  Write-Host "  [OK]  Thunderbird starting" -ForegroundColor Green
} else {
  Write-Host "  [--]  -NoLaunch set, skip" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "DONE. Open Tools -> Add-ons and Themes to verify all 10 OutlookPro bundles are enabled." -ForegroundColor Cyan
Write-Host "If you had older fine-grained OutlookPro bundles installed, run uninstall_old.ps1 first." -ForegroundColor Yellow
