OutlookPro contacts-import/
============================

This folder contains a snapshot of Komal's address books captured from
the reference machine at package build time.

- abook.sqlite       Thunderbird's default Personal Address Book
- abook-1.sqlite     Thunderbird's Collected Addresses (auto-collected
                     recipients TB harvests as you send mail)

WHY: on a fresh Thunderbird install the address books are empty, so the
"To:" autocomplete dropdown has nothing to suggest even after OutlookPro
loads. Copying these files bootstraps the target machine with the same
contact set, so the compose window shows completion popups from day one.
(The OATI GAL still syncs live via outlookpro-ews as usual, into a
separate address book named "Exchange GAL (dev.oati.local\<user>)".)

HOW TO RESTORE (only on a fresh profile, or if you want to reset your
address books to the reference snapshot):

  1. Close Thunderbird completely (File -> Quit).
  2. Open the profile folder:  %APPDATA%\Thunderbird\Profiles\<your profile>\
  3. Rename any EXISTING abook*.sqlite files to *.bak (do NOT delete
     unless you're sure -- these hold your Personal + Collected contacts).
  4. Copy abook.sqlite + abook-1.sqlite from THIS folder into the profile.
  5. Also delete the matching *.sqlite-shm and *.sqlite-wal files if they
     exist alongside the old .sqlite files (WAL journals).
  6. Start Thunderbird.

SAFETY: install.ps1 does NOT auto-copy these files. It leaves your
existing address books alone. The manual restore above is deliberate --
we don't want the installer to overwrite contacts you've collected on
your own machine.
