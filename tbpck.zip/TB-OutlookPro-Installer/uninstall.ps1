#requires -Version 5.1
<#
.SYNOPSIS
  Complete removal of the OutlookPro suite from a Thunderbird profile.

.DESCRIPTION
  Removes every OutlookPro bundle -- both current (13 shipped) and legacy
  (10 fine-grained bundles that were consolidated) -- from the target
  profile's extensions directory. Optionally strips the marker-guarded
  OutlookPro block from user.js and removes userChrome.css.

  Non-destructive to your mail: does NOT delete any mailbox, message,
  address book, calendar, filter, or account setting. Only touches files
  the OutlookPro installer put there.

  Idempotent -- safe to re-run.

.PARAMETER ProfileName
  Profile name substring OR full profile-dir path. Omit to auto-detect the
  default profile from profiles.ini.

.PARAMETER KeepPrefs
  If set, leaves the OutlookPro block in user.js in place. Default is to
  remove the marker-guarded block only (never touches unrelated prefs).

.PARAMETER KeepUserChromeCss
  If set, leaves profile\chrome\userChrome.css alone. Default is to remove
  the file we installed (a backup with the .op-backup suffix is preserved
  first if we detect our own header comment).

.EXAMPLE
  .\uninstall.ps1
  .\uninstall.ps1 -ProfileName default-release
  .\uninstall.ps1 -KeepPrefs -KeepUserChromeCss
#>
param(
  [string]$ProfileName        = "",
  [switch]$KeepPrefs,
  [switch]$KeepUserChromeCss
)

$ErrorActionPreference = "Stop"

# All 23 possible OutlookPro extension IDs (13 current + 10 legacy).
$AllBundleIds = @(
  # Current 13
  "outlookpro-adfs-oauth@oss.local",
  "outlookpro-archive@oss.local",
  "outlookpro-archive-dialog@oss.local",
  "outlookpro-cards-default@oss.local",
  "outlookpro-header@oss.local",
  "outlookpro-composer@oss.local",
  "outlookpro-composer-plus@oss.local",
  "outlookpro-ews@oss.local",
  "outlookpro-mapi-http@oss.local",
  "outlookpro-people@oss.local",
  "outlookpro-ribbon@oss.local",
  "outlookpro-rules@oss.local",
  "outlookpro-search@oss.local",
  "outlookpro-triage@oss.local",
  "outlookpro-view@oss.local",
  # Legacy 10 (consolidated into the current bundles)
  "outlookpro-auto-archive@oss.local",
  "outlookpro-auto-reply@oss.local",
  "outlookpro-compose-in-tab@oss.local",
  "outlookpro-ews-calendar@oss.local",
  "outlookpro-ews-contacts@oss.local",
  "outlookpro-folder-size@oss.local",
  "outlookpro-quick-rule@oss.local",
  "outlookpro-recall@oss.local",
  "outlookpro-reply-all-fix@oss.local",
  "outlookpro-server-rules@oss.local"
)

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " OutlookPro Complete Uninstall"                                -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# ---------- 1. Stop TB ----------
Write-Host "Step 1/5   Stopping Thunderbird (if running)..." -ForegroundColor Cyan
Get-Process thunderbird -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 3

# ---------- 2. Resolve profile ----------
Write-Host "Step 2/5   Resolving Thunderbird profile..." -ForegroundColor Cyan
$profilesRoot = Join-Path $env:APPDATA "Thunderbird\Profiles"
$profileDir = $null

if ($ProfileName -and (Test-Path $ProfileName)) {
  $profileDir = (Resolve-Path $ProfileName).Path
} elseif ($ProfileName) {
  $match = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
           Where-Object { $_.Name -like "*$ProfileName*" } |
           Select-Object -First 1
  if ($match) { $profileDir = $match.FullName }
} else {
  $pi = Join-Path $env:APPDATA "Thunderbird\profiles.ini"
  if (Test-Path $pi) {
    $lines = Get-Content $pi
    $inInstall = $false
    foreach ($ln in $lines) {
      if ($ln -match "^\[Install")  { $inInstall = $true;  continue }
      if ($ln -match "^\[")         { $inInstall = $false; continue }
      if ($inInstall -and $ln -match "^Default\s*=\s*(.+)$") {
        $relPath   = $Matches[1].Trim()
        $candidate = Join-Path (Split-Path $pi -Parent) $relPath
        if (Test-Path $candidate) { $profileDir = $candidate; break }
      }
    }
    if (-not $profileDir) {
      $fallback = Get-ChildItem $profilesRoot -Directory -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -like "*.default-release" } |
                  Sort-Object LastWriteTime -Descending |
                  Select-Object -First 1
      if ($fallback) { $profileDir = $fallback.FullName }
    }
  }
}
if (-not $profileDir -or -not (Test-Path $profileDir)) {
  throw "Could not resolve TB profile. Pass -ProfileName <name-or-path>."
}
Write-Host "  Profile: $profileDir" -ForegroundColor Green

$extDir = Join-Path $profileDir "extensions"

# ---------- 3. Remove all OutlookPro XPIs ----------
Write-Host "Step 3/5   Removing all OutlookPro XPIs..." -ForegroundColor Cyan
$removed = 0; $missing = 0
foreach ($id in $AllBundleIds) {
  $p = Join-Path $extDir "$id.xpi"
  if (Test-Path $p) {
    Remove-Item $p -Force
    Write-Host ("  [DEL]  {0}" -f "$id.xpi") -ForegroundColor DarkYellow
    $removed++
  } else {
    $missing++
  }
}
Write-Host ("  Removed {0}, {1} not present" -f $removed, $missing) -ForegroundColor Green

# Clear per-extension storage (IndexedDB) for each id -- otherwise
# a later reinstall inherits stale storage.local from the old build.
$storageRoot = Join-Path $profileDir "storage\default"
if (Test-Path $storageRoot) {
  Get-ChildItem $storageRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    foreach ($id in $AllBundleIds) {
      # storage keys are like "moz-extension+++<uuid>" -- we can't map back
      # easily, but the short name usually appears in an accompanying folder
      $shortName = $id -replace "@oss\.local$",""
      if ($_.Name -like "*$shortName*") {
        Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host ("  [STOR] cleared {0}" -f $_.Name) -ForegroundColor DarkGray
      }
    }
  }
}

# ---------- 4. Strip OutlookPro block from user.js (unless -KeepPrefs) ----------
Write-Host "Step 4/5   Handling user.js..." -ForegroundColor Cyan
$userJs = Join-Path $profileDir "user.js"
if ($KeepPrefs) {
  Write-Host "  [SKIP] -KeepPrefs supplied" -ForegroundColor DarkGray
} elseif (-not (Test-Path $userJs)) {
  Write-Host "  [--]   no user.js in profile" -ForegroundColor DarkGray
} else {
  $content = Get-Content $userJs -Raw
  $marker  = "# --- OutlookPro user.js template (managed block) ---"
  $endMark = "# --- end OutlookPro template ---"
  if ($content -match [regex]::Escape($marker)) {
    $pattern = [regex]::Escape($marker) + "[\s\S]*?" + [regex]::Escape($endMark) + "\s*"
    $newContent = [regex]::Replace($content, $pattern, "")
    Set-Content -Path $userJs -Value $newContent -Encoding ASCII
    Write-Host "  [OK]   removed OutlookPro managed block from user.js" -ForegroundColor Green
  } else {
    Write-Host "  [--]   no OutlookPro marker found in user.js -- nothing to strip" -ForegroundColor DarkGray
  }
}

# ---------- 5. Remove userChrome.css (unless -KeepUserChromeCss) ----------
Write-Host "Step 5/5   Handling userChrome.css..." -ForegroundColor Cyan
$userChrome = Join-Path $profileDir "chrome\userChrome.css"
if ($KeepUserChromeCss) {
  Write-Host "  [SKIP] -KeepUserChromeCss supplied" -ForegroundColor DarkGray
} elseif (-not (Test-Path $userChrome)) {
  Write-Host "  [--]   no userChrome.css in profile" -ForegroundColor DarkGray
} else {
  # Only remove if it looks like ours (backup first)
  $css = Get-Content $userChrome -Raw
  if ($css -match "OutlookPro") {
    $bak = "$userChrome.op-backup"
    Copy-Item $userChrome $bak -Force
    Remove-Item $userChrome -Force
    Write-Host "  [OK]   removed userChrome.css (backup: $bak)" -ForegroundColor Green
  } else {
    Write-Host "  [KEEP] userChrome.css exists but has no OutlookPro marker -- left alone" -ForegroundColor DarkGray
  }
}

# Bust addonStartup cache
$cache = Join-Path $profileDir "addonStartup.json.lz4"
if (Test-Path $cache) { Remove-Item $cache -Force }

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " OutlookPro uninstall complete. Launch Thunderbird when ready." -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
