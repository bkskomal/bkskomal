"""
Native Gantt chart recipe.

A Gantt is a horizontal BAR chart with two series: a transparent "offset" (the
task start) and a visible "duration" bar, stacked. PowerPoint renders this as a
real, editable chart.
"""
from __future__ import annotations

from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.util import Emu, Pt

EMU_PER_PX = 9525


def _px(v: float) -> Emu:
    return Emu(int(round(v * EMU_PER_PX)))


def add_gantt(slide, source: dict, primary_hex: str) -> None:
    """Render a Gantt for source['gantt'] as a stacked horizontal bar chart."""
    g = source.get("gantt") or {}
    tasks = g.get("tasks") or []
    if not tasks:
        return

    # Bars render bottom-up in BAR charts, so reverse to read top-down.
    tasks = list(reversed(tasks))
    cats = [str(t.get("label", "")) for t in tasks]
    offsets = [float(t.get("start", 0)) for t in tasks]
    durations = [max(0.1, float(t.get("end", 0)) - float(t.get("start", 0))) for t in tasks]

    cd = CategoryChartData()
    cd.categories = cats
    cd.add_series("offset", offsets)
    cd.add_series("duration", durations)

    # chart region mirrors layouts.ts gantt (x≈M, below the title)
    gframe = slide.shapes.add_chart(XL_CHART_TYPE.BAR_STACKED, _px(88), _px(280), _px(1104), _px(300), cd)
    chart = gframe.chart
    chart.has_legend = False

    plot = chart.plots[0]
    plot.gap_width = 60
    series = plot.series

    # series 0 = invisible offset
    series[0].format.fill.background()
    series[0].format.line.fill.background()
    # series 1 = the visible duration bar
    series[1].format.fill.solid()
    series[1].format.fill.fore_color.rgb = RGBColor.from_string(primary_hex.upper())
    series[1].format.line.fill.background()

    cat_axis = chart.category_axis
    cat_axis.tick_labels.font.size = Pt(11)
    val_axis = chart.value_axis
    val_axis.has_major_gridlines = True
    val_axis.minimum_scale = 0
