# PPTMaker Export Service (python-pptx)

A small FastAPI service that renders a PPTMaker **Deck JSON** into a high-fidelity,
**editable** `.pptx` — with true gradient fills and crisp native shapes that go
beyond the in-browser JS exporter.

It is deterministic code **we** wrote. It does **not** execute any AI-generated
code — it just consumes the same Deck JSON the web app already produces.

## Run

```bash
cd pyexport
pip install -r requirements.txt
uvicorn app:app --port 8910
```

Then set this in the web app's `.env.local` and restart `npm run dev`:

```env
NEXT_PUBLIC_PYEXPORT_URL=http://localhost:8910
```

An extra **"Download HD .pptx (gradients)"** option appears in the editor's
Export menu.

## API

- `GET /health` → `{ "ok": true }`
- `POST /export` with body `{ "deck": <Deck JSON> }` → the `.pptx` file.

## What it renders

| Element | Fidelity |
|---------|----------|
| Backgrounds | solid + **linear gradients** |
| Shapes (rect/rounded/ellipse/triangle/blob) | solid + gradient fills, rotation, alpha |
| Text | font family/size/weight/italic, color, align, vertical anchor, line spacing, bullets/numbers |
| Images | embedded data-URL pictures |
| Brand kit | logo, header, footer, page numbers (recomputed server-side) |
| Theme tokens | `token:*` resolved against the deck theme + brand overrides |

## Self-test

```bash
python renderer.py   # writes selftest.pptx
```

## Notes / roadmap
- Gradients use a two-stop linear fill (matches the canvas).
- Future: detect chart/table blocks (via block metadata) and emit **native**
  PowerPoint charts/tables instead of pre-rendered shapes.
