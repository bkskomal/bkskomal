"""
Import an existing .pptx into OATIGenie's editable Deck model (inverse of
renderer.py). Best-effort: text boxes, pictures, auto-shapes and tables become
editable SlideElements positioned on the 1280x720 canvas. Themes aren't parsed —
the client wraps the returned slides with a default theme/brand.
"""
from __future__ import annotations

import base64
import io

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.util import Emu

CANVAS_W = 1280
CANVAS_H = 720
EMU_PER_PX = 9525  # 914400 EMU/inch / 96 px/inch

# reverse of renderer.SHAPE_MAP (MSO auto-shape -> our ShapeKind), keyed by enum name
REVERSE_SHAPE = {
    "ROUNDED_RECTANGLE": "roundedRect",
    "RECTANGLE": "rect",
    "OVAL": "ellipse",
    "ISOSCELES_TRIANGLE": "triangle",
    "TRAPEZOID": "trapezoid",
    "CHEVRON": "chevron",
    "RIGHT_ARROW": "arrowRight",
    "HEXAGON": "hexagon",
    "REGULAR_PENTAGON": "pentagon",
    "DIAMOND": "diamond",
    "STAR_5_POINT": "star",
    "PARALLELOGRAM": "parallelogram",
}


def _hex(color) -> str | None:
    try:
        if color and color.type is not None and color.rgb is not None:
            return "#" + str(color.rgb)
    except Exception:
        return None
    return None


def _px(emu, scale: float) -> int:
    if emu is None:
        return 0
    return round((emu / EMU_PER_PX) * scale)


def _text_element(shape, sx: float, sy: float, eid: str) -> dict | None:
    tf = shape.text_frame
    text = "\n".join(p.text for p in tf.paragraphs).strip()
    if not text:
        return None
    # sample the first run for size / weight / color
    size = 18.0
    bold = False
    color = None
    align = "left"
    for p in tf.paragraphs:
        if p.alignment is not None:
            align = {1: "left", 2: "center", 3: "right"}.get(int(p.alignment), "left")
        for r in p.runs:
            if r.font.size is not None:
                size = r.font.size.pt
            if r.font.bold:
                bold = True
            color = _hex(r.font.color) or color
            break
        if size:
            break
    role = "title" if size >= 30 else "heading" if size >= 22 else "body"
    el = {
        "id": eid, "type": "text", "text": text,
        "x": _px(shape.left, sx), "y": _px(shape.top, sy),
        "w": _px(shape.width, sx) or 400, "h": _px(shape.height, sy) or 60,
        "role": role, "fontSize": round(size), "align": align, "valign": "top",
    }
    if bold:
        el["fontWeight"] = 700
    if color:
        el["color"] = color
    return el


def _picture_element(shape, sx: float, sy: float, eid: str) -> dict | None:
    try:
        img = shape.image
        data = base64.b64encode(img.blob).decode("ascii")
        src = f"data:{img.content_type};base64,{data}"
    except Exception:
        return None
    return {
        "id": eid, "type": "image", "src": src, "fit": "cover",
        "x": _px(shape.left, sx), "y": _px(shape.top, sy),
        "w": _px(shape.width, sx) or 320, "h": _px(shape.height, sy) or 240,
    }


def _shape_element(shape, sx: float, sy: float, eid: str) -> dict | None:
    kind = "rect"
    try:
        name = shape.auto_shape_type.name if shape.auto_shape_type is not None else None
        kind = REVERSE_SHAPE.get(name, "rect")
    except Exception:
        kind = "rect"
    el = {
        "id": eid, "type": "shape", "shape": kind,
        "x": _px(shape.left, sx), "y": _px(shape.top, sy),
        "w": _px(shape.width, sx) or 100, "h": _px(shape.height, sy) or 100,
    }
    try:
        if shape.fill.type is not None:
            fh = _hex(shape.fill.fore_color)
            if fh:
                el["fill"] = fh
    except Exception:
        pass
    # a shape may also carry text
    out = [el]
    try:
        if shape.has_text_frame and shape.text_frame.text.strip():
            t = _text_element(shape, sx, sy, eid + "t")
            if t:
                t["valign"] = "middle"
                t["align"] = "center"
                out.append(t)
    except Exception:
        pass
    return out


def _table_elements(shape, sx: float, sy: float, base: str) -> list[dict]:
    out: list[dict] = []
    tbl = shape.table
    x0, y0 = _px(shape.left, sx), _px(shape.top, sy)
    w, h = _px(shape.width, sx) or 800, _px(shape.height, sy) or 300
    rows = len(tbl.rows)
    cols = len(tbl.columns)
    if not rows or not cols:
        return out
    cw, ch = w / cols, h / rows
    for r in range(rows):
        for c in range(cols):
            txt = tbl.cell(r, c).text.strip()
            if not txt:
                continue
            out.append({
                "id": f"{base}-{r}-{c}", "type": "text", "text": txt,
                "x": round(x0 + c * cw + 8), "y": round(y0 + r * ch + 6),
                "w": round(cw - 16), "h": round(ch - 12),
                "role": "heading" if r == 0 else "body", "fontSize": 16,
                "fontWeight": 700 if r == 0 else 400, "align": "left", "valign": "middle",
            })
    return out


def _walk(shapes, sx: float, sy: float, prefix: str, out: list[dict]) -> None:
    for i, shape in enumerate(shapes):
        eid = f"{prefix}-{i}"
        try:
            st = shape.shape_type
            if st == MSO_SHAPE_TYPE.GROUP:
                _walk(shape.shapes, sx, sy, eid, out)
                continue
            if st == MSO_SHAPE_TYPE.PICTURE:
                el = _picture_element(shape, sx, sy, eid)
                if el:
                    out.append(el)
                continue
            if shape.has_table:
                out.extend(_table_elements(shape, sx, sy, eid))
                continue
            if st == MSO_SHAPE_TYPE.AUTO_SHAPE:
                els = _shape_element(shape, sx, sy, eid)
                if els:
                    out.extend(els)
                continue
            if shape.has_text_frame:
                el = _text_element(shape, sx, sy, eid)
                if el:
                    out.append(el)
        except Exception:
            continue


def parse_pptx(data: bytes) -> dict:
    prs = Presentation(io.BytesIO(data))
    sw_px = (prs.slide_width or Emu(12192000)) / EMU_PER_PX
    sh_px = (prs.slide_height or Emu(6858000)) / EMU_PER_PX
    sx = CANVAS_W / sw_px if sw_px else 1
    sy = CANVAS_H / sh_px if sh_px else 1

    slides: list[dict] = []
    title = "Imported presentation"
    for si, slide in enumerate(prs.slides):
        elements: list[dict] = []
        _walk(slide.shapes, sx, sy, f"s{si}", elements)
        # z-order by document order so stacking is stable
        for zi, el in enumerate(elements):
            el["z"] = zi
        layout = "cover" if si == 0 else "bullets"
        slides.append({"id": f"imp-{si}", "layout": layout, "elements": elements})
        if si == 0:
            for el in elements:
                if el.get("type") == "text" and el.get("role") == "title":
                    title = el["text"].split("\n")[0][:80]
                    break

    return {"title": title, "size": {"w": CANVAS_W, "h": CANVAS_H}, "slides": slides, "slideCount": len(slides)}
