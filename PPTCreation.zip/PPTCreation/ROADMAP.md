# OATIGenie — Roadmap to the World's #1 AI Presentation System

_Last updated: 2026-07-01_

OATIGenie is an AI-native, multi-skill assistant whose flagship skill builds fully-editable
PowerPoint decks from a chat or an outline, powered by a self-hosted GPT-OSS-120B model.
This document tracks where we stand and the phased plan to become the best in class.

## Guiding principles
1. **Editable, native output** — never flatten to images; export real `.pptx` shapes/charts/tables. (Our biggest moat.)
2. **Fidelity** — honor the user's content 1:1 when they provide structure; compose only when asked.
3. **Agentic** — every feature must be operable from chat, not just the UI.
4. **Self-hosted / data-sovereign** — runs on the org's own GPT-OSS-120B; nothing leaves the tenant.
5. **Design-guaranteed** — the AI emits semantic content; a deterministic layout engine guarantees on-brand output.

## Where we stand (2026-07-01)

| Dimension | Status | Notes |
|---|---|---|
| AI generation (topic → deck) | ✅ Strong | robust parse/salvage, `max_tokens` scaling |
| Outline fidelity (1:1) | ✅ Strong | deterministic outline parser + source toast |
| Editable `.pptx` / HD export | ✅ Strong | native shapes/charts/tables via python-pptx |
| Editor (elements, shapes, brand, present) | ✅ Strong | 14 shapes, 25-item library, undo/redo, snapping |
| Agentic chat control | ✅ Strong | live capability manifest, ~19 actions |
| Premium chrome + template polish | ✅ Good | header/footer presets, refined-corporate styles |
| Self-learning (RAG + prefs + evals) | ✅ Strong (P1.3) | LLM-as-judge pass-rate measured + persisted; DPO data captured |
| **Imagery (AI gen + stock)** | ✅ Shipped (P0.1) | stock search + AI gen + chat + editor panel |
| **`.pptx` import** | ✅ Shipped (P0.2) | parses existing decks into editable elements |
| Charts / data depth | ✅ Shipped (P1.1) | column/bar/line/area/pie/donut, multi-series, CSV→chart, native export |
| Cloud + sharing + versions | ✅ Shipped (P1.2) | Postgres decks, share links, version history |
| Enterprise brand governance / SSO | ✅ Shipped (P2.2) | org brand + locks, domain access rules, OIDC SSO config |
| Real-time collaboration | 🔴 Gap (P2.1) | none |
| Curated content-filled templates | 🔴 Gap (P2.3) | style×theme combos only |

## Phase 0 — Table stakes (close the visible gaps) — ✅ DONE
- **P0.1 Imagery** ✅ — stock search (Picsum keyless + Unsplash/Pexels), AI generation (OpenAI-compatible), editor Images panel, chat `add_image`/`generate_image`, smart placement.
- **P0.2 `.pptx` import** ✅ — `pyexport/importer.py` parses shapes/text/pictures/tables into editable elements; "Import PowerPoint" button on the gallery opens the deck in the editor. Validated by export→import round-trip.

## Phase 1 — Lead, not just compete
- **P1.1 Charts & data** ✅ — first-class `ChartElement` (column/bar/line/area/pie/donut, multi-series), SVG rendering in the editor, native chart export in both pipelines, CSV/TSV paste → chart, chat `add_chart`, editor Chart menu.
- **P1.2 Cloud & sharing** ✅ — `decks` + `deck_versions` tables, save/list/get/delete API, share-link tokens + public read-only viewer (`/share/[token]`), version snapshots on every save, editor Save/Share/History controls. Graceful fallback when Postgres is down.
- **P1.3 Measured AI quality** ✅ — `judgeAnswer` LLM-as-judge (0–100 + pass), `/api/evals/run` replays the suite through the assistant and scores it, `eval_runs`/`eval_results` tables, admin "Model quality" pass-rate card, LLM-judge CLI runner. (DPO/LoRA fine-tuning from captured preference pairs remains.)

## Phase 2 — Moat
- **P2.1 Collaboration:** real-time co-editing, presence, comments. _(remaining)_
- **P2.2 Brand governance + SSO** ✅ — server-side org config (`org_config`): enforced brand kit + per-field **locks** (colors/fonts/logo/footer) honored in the editor, new decks inherit the org brand, **email-domain access rules** (allowed domains + domain→role) enforced at sign-up, **OIDC SSO** config + gated "Sign in with SSO" + authorize-URL start route. Admin "Organization" tab (Super Admin).
- **P2.3 Curated templates:** designed, content-filled starter decks (not just style×theme combos); onboarding. _(remaining)_

## Execution model
Gaps are closed **one at a time, each validated** (typecheck + functional test + live check) before the next.
Progress is recorded in project memory and reflected in the status table above.
