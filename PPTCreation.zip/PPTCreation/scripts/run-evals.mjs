/**
 * Eval harness runner — regression-tests the assistant with an LLM-as-judge.
 *
 * Triggers /api/evals/run, which replays each saved eval prompt through the
 * assistant, scores each reply with the model acting as judge, aggregates a
 * pass-rate, and persists the run. Use before shipping a prompt/model change.
 *
 *   node scripts/run-evals.mjs                # against http://localhost:3000
 *   BASE=http://localhost:3000 node scripts/run-evals.mjs
 */
const BASE = process.env.BASE || "http://localhost:3000";

const res = await fetch(`${BASE}/api/evals/run`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({}),
});
const data = await res.json();
if (!res.ok || data.error) {
  console.error("Eval run failed:", data.error ?? res.status);
  process.exit(1);
}

const { run, results } = data;
console.log(`\nEval run — ${run.passed}/${run.total} passed · avg score ${run.avgScore} · model ${run.model}\n`);
for (const [i, r] of results.entries()) {
  const mark = r.pass ? "PASS" : "FAIL";
  console.log(`${String(i + 1).padStart(2)}. [${mark} ${String(r.score).padStart(3)}] ${r.prompt.slice(0, 56)}`);
  console.log(`     ${r.reason}`);
}
const rate = run.total ? Math.round((run.passed / run.total) * 100) : 0;
console.log(`\nPass-rate: ${rate}%`);
