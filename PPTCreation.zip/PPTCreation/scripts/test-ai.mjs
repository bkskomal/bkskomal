/**
 * Standalone connectivity + generation smoke test for the GPT-OSS-120B endpoint.
 * Reads OPENAI_BASE_URL / OPENAI_API_KEY / AI_MODEL from .env.local (or the
 * environment) and (1) lists models, (2) runs a tiny JSON generation.
 *
 *   node scripts/test-ai.mjs
 */
import { readFileSync } from "node:fs";
import OpenAI from "openai";

// minimal .env.local loader (no dependency)
try {
  const env = readFileSync(new URL("../.env.local", import.meta.url), "utf8");
  for (const line of env.split("\n")) {
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
} catch {
  console.log("(no .env.local found — using process env / defaults)");
}

if (process.env.AI_TLS_INSECURE === "true") {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  console.log("(AI_TLS_INSECURE=true — trusting self-signed cert for this dev run)");
}

const baseURL = process.env.OPENAI_BASE_URL || "http://localhost:8080/v1";
const apiKey = process.env.OPENAI_API_KEY || "local";
const model = process.env.AI_MODEL || "openai/gpt-oss-120b";

console.log("Base URL:", baseURL);
console.log("Model:   ", model);
console.log("API key: ", apiKey ? `${apiKey.slice(0, 4)}…(${apiKey.length} chars)` : "(none)");

const client = new OpenAI({ baseURL, apiKey });

try {
  console.log("\n[1/2] Listing models…");
  const models = await client.models.list();
  console.log("  OK:", models.data.map((m) => m.id).slice(0, 10).join(", ") || "(empty)");
} catch (e) {
  console.error("  Model list failed:", e.message);
}

try {
  console.log("\n[2/2] Generating a 3-slide deck (JSON)…");
  const t = Date.now();
  const res = await client.chat.completions.create({
    model,
    temperature: 0.7,
    messages: [
      { role: "system", content: "You output strict JSON only." },
      {
        role: "user",
        content:
          'Return JSON {"title":string,"slides":[{"layout":"cover"|"bullets"|"closing","title":string,"bullets"?:string[]}]} for a 3-slide deck about a coffee subscription startup.',
      },
    ],
    response_format: { type: "json_object" },
  });
  const txt = res.choices[0]?.message?.content ?? "";
  console.log(`  OK in ${((Date.now() - t) / 1000).toFixed(1)}s. Sample:\n`);
  console.log(txt.slice(0, 800));
} catch (e) {
  console.error("  Generation failed:", e.message);
  console.error("  → Check base URL (needs /v1), API key, and model id.");
}
