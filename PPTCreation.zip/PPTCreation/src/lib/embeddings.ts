import OpenAI from "openai";
import { EMBED_DIM } from "./db";

/**
 * Server-only embeddings for exemplar RAG.
 *
 * Uses an OpenAI-compatible /embeddings endpoint when configured; otherwise
 * falls back to a deterministic hashing embedding so RAG still works out of the
 * box (lower quality, but functional).
 *
 *   EMBED_BASE_URL, EMBED_MODEL, EMBED_API_KEY, EMBED_DIM
 */
export interface EmbedOverride {
  baseUrl?: string;
  model?: string;
  apiKey?: string;
}

export async function embed(text: string, ov?: EmbedOverride): Promise<number[]> {
  const model = ov?.model || process.env.EMBED_MODEL;
  const baseURL = ov?.baseUrl || process.env.EMBED_BASE_URL || process.env.OPENAI_BASE_URL;
  if (model && baseURL) {
    try {
      const client = new OpenAI({ baseURL, apiKey: ov?.apiKey || process.env.EMBED_API_KEY || process.env.OPENAI_API_KEY || "local" });
      const res = await client.embeddings.create({ model, input: text.slice(0, 8000) });
      const v = res.data[0]?.embedding;
      if (Array.isArray(v) && v.length === EMBED_DIM) return v;
    } catch {
      /* fall through to hashing */
    }
  }
  return hashEmbed(text);
}

/** Deterministic bag-of-words hashing embedding, L2-normalized. */
function hashEmbed(text: string): number[] {
  const v = new Array(EMBED_DIM).fill(0);
  const tokens = text.toLowerCase().match(/[a-z0-9]+/g) ?? [];
  for (const tok of tokens) {
    let h = 2166136261;
    for (let i = 0; i < tok.length; i++) h = (h ^ tok.charCodeAt(i)) * 16777619;
    const idx = Math.abs(h) % EMBED_DIM;
    v[idx] += 1;
  }
  const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0)) || 1;
  return v.map((x) => x / norm);
}

/** pgvector literal, e.g. "[0.1,0.2,...]". */
export function toVectorLiteral(v: number[]): string {
  return `[${v.join(",")}]`;
}
