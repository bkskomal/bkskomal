import * as XLSX from "xlsx";

/**
 * World-class workbook comparison.
 *
 * Instead of a naive cell-by-cell grid diff (which turns one inserted row into a
 * cascade of false "modified" cells), this does CONTEXT-AWARE comparison:
 *  - treats row 1 as headers and matches COLUMNS by name (handles reordering,
 *    added / removed columns),
 *  - infers a KEY (single OR composite column set) and matches ROWS by key
 *    (so add / remove / reorder are detected correctly, with per-field changes),
 *  - falls back to positional matching when a sheet has no usable key.
 *
 * Accuracy hardening (decisions ride on this):
 *  - every tab is compared (union of sheet names),
 *  - RENAMED tabs are detected by row-content overlap and compared as one tab,
 *  - dates / booleans / numbers are normalised so formatting never causes false diffs,
 *  - COMPOSITE keys (e.g. Region+SKU) when no single column is unique,
 *  - the key can be OVERRIDDEN per sheet (single or multi-column, or positional),
 *  - duplicate key values are detected and matched positionally within the group,
 *  - optional numeric TOLERANCE (e.g. treat 100.00 vs 100.01 as equal), with a
 *    percentage delta shown on every changed number,
 *  - optional case- / whitespace-insensitive matching.
 */
export interface Workbook {
  name: string;
  sheets: Record<string, unknown[][]>;
}

export interface CompareOptions {
  /** treat row 1 as a header row (default true). If false, columns are Col 1..N and every row is data. */
  firstRowHeader?: boolean;
  /** case-insensitive value matching (default false). */
  ignoreCase?: boolean;
  /** collapse/ignore internal + surrounding whitespace when matching (default false). */
  ignoreWhitespace?: boolean;
  /** treat two numbers within this percentage of each other as equal (default 0 = exact). */
  numericTolerancePct?: number;
  /** per-sheet key override: single column, composite [cols], or POSITION_KEY to force positional. */
  keys?: Record<string, string | string[]>;
}

export interface FieldChange {
  col: string;
  old: string;
  new: string;
  /** signed % change for numeric fields, e.g. "+5.6%" (undefined for non-numeric). */
  delta?: string;
}

export interface RowChange {
  key: string;
  type: "added" | "removed" | "modified";
  fields: FieldChange[];
  /** full row values keyed by column, for the merged export */
  values: Record<string, string>;
}

export interface SheetDiff {
  name: string;
  status: "added" | "removed" | "changed" | "same";
  headers: string[];
  /** resolved key columns (empty = positional). */
  keyColumns: string[];
  /** joined key label for display / the export ("A + B", or null when positional). */
  keyColumn: string | null;
  /** columns eligible to be chosen as a key (present in both files), for the UI selector. */
  keyCandidates: string[];
  /** false when the key has repeated values (matching is then positional within the group). */
  keyUnique: boolean;
  /** original tab name this was compared against, when a rename was detected. */
  renamedFrom: string | null;
  /** human note about matching quality / caveats. */
  note: string | null;
  addedCols: string[];
  removedCols: string[];
  rows: RowChange[];
  added: number;
  removed: number;
  modified: number;
}

export interface CompareResult {
  a: string;
  b: string;
  sheets: SheetDiff[];
  totals: { added: number; removed: number; modified: number; sheetsChanged: number };
}

export const POSITION_KEY = "__position__";

export async function parseWorkbook(file: File): Promise<Workbook> {
  const buf = await file.arrayBuffer();
  // cellDates -> real Date objects (dates compare by value); raw -> keep numbers as numbers.
  const wb = XLSX.read(buf, { type: "array", cellDates: true });
  const sheets: Record<string, unknown[][]> = {};
  for (const name of wb.SheetNames) {
    sheets[name] = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, defval: "", blankrows: false, raw: true }) as unknown[][];
  }
  return { name: file.name, sheets };
}

/** Canonical string for a cell VALUE — stable across Excel's formatting quirks. */
const s = (v: unknown): string => {
  if (v === undefined || v === null) return "";
  if (v instanceof Date) {
    const iso = v.toISOString();
    return iso.endsWith("T00:00:00.000Z") ? iso.slice(0, 10) : iso.slice(0, 16).replace("T", " ");
  }
  if (typeof v === "number") return Number.isInteger(v) ? String(v) : String(Number(v.toFixed(10)));
  if (typeof v === "boolean") return v ? "TRUE" : "FALSE";
  return String(v).trim();
};

/** Comparison-normalised form of an already-canonical string (applies match options). */
const norm = (val: string, opts: CompareOptions): string => {
  let x = val;
  if (opts.ignoreWhitespace) x = x.replace(/\s+/g, " ").trim();
  if (opts.ignoreCase) x = x.toLowerCase();
  return x;
};

// Numeric coercion — text "90" and number 90 are the same to a human, so don't read as a change.
// Guarded: leading-zero strings ("007", ZIP "01001") are identifiers, NOT numbers, and stay literal.
const LEADING_ZERO = /^-?0\d/;
const numericValue = (x: string): number | null => {
  if (x === "" || LEADING_ZERO.test(x)) return null;
  if (!/^-?\d+(\.\d+)?$/.test(x)) return null;
  const n = Number(x);
  return Number.isFinite(n) ? n : null;
};

/** True when two canonical cell strings mean the same thing (options + numeric equality + tolerance). */
const valuesEqual = (a: string, b: string, opts: CompareOptions): boolean => {
  if (norm(a, opts) === norm(b, opts)) return true;
  const na = numericValue(a);
  const nb = numericValue(b);
  if (na === null || nb === null) return false;
  if (na === nb) return true;
  const tol = opts.numericTolerancePct ?? 0;
  if (tol <= 0) return false;
  const denom = Math.max(Math.abs(na), Math.abs(nb)) || 1;
  return (Math.abs(na - nb) / denom) * 100 <= tol;
};

/** Signed percent change for two numeric cells, e.g. "+5.6%" — undefined if not both numeric. */
const pctDelta = (a: string, b: string): string | undefined => {
  const na = numericValue(a);
  const nb = numericValue(b);
  if (na === null || nb === null || na === 0) return undefined;
  const pct = ((nb - na) / Math.abs(na)) * 100;
  const r = Math.abs(pct) >= 10 ? Math.round(pct) : Math.round(pct * 10) / 10;
  return `${r > 0 ? "+" : ""}${r}%`;
};

/** Canonical token for one key cell (numeric-aware, so 90 and "90" match). */
const keyCanon = (raw: string, opts: CompareOptions): string => {
  const v = norm(raw ?? "", opts);
  const n = numericValue(v);
  return n !== null ? "#" + n : v;
};

const SEP = "";

/** Composite key bucket value across one or more columns ("" = no usable key on this row). */
const keyValueFor = (rec: Record<string, string>, cols: string[], opts: CompareOptions): string => {
  const parts = cols.map((c) => keyCanon(rec[c] ?? "", opts));
  return parts.every((p) => p === "") ? "" : parts.join(SEP);
};

const keyDisplay = (rec: Record<string, string>, cols: string[]): string => cols.map((c) => rec[c] ?? "").join(" · ");

/** Turn a sheet (array of rows) into headers + record objects. */
function records(rows: unknown[][], firstRowHeader: boolean): { headers: string[]; recs: Record<string, string>[] } {
  if (!rows.length) return { headers: [], recs: [] };
  const width = Math.max(...rows.map((r) => (r as unknown[]).length));
  const headers = firstRowHeader
    ? Array.from({ length: width }, (_, i) => s((rows[0] as unknown[])[i]) || `Col ${i + 1}`)
    : Array.from({ length: width }, (_, i) => `Col ${i + 1}`);
  const body = firstRowHeader ? rows.slice(1) : rows;
  const recs = body
    .map((r) => {
      const o: Record<string, string> = {};
      headers.forEach((h, i) => (o[h] = s((r as unknown[])[i])));
      return o;
    })
    .filter((o) => Object.values(o).some((v) => v !== ""));
  return { headers, recs };
}

const uniqueness = (rows: Record<string, string>[], cols: string[], opts: CompareOptions): number => {
  const vals = rows.map((r) => keyValueFor(r, cols, opts)).filter((v) => v !== "");
  return vals.length ? new Set(vals).size / vals.length : 0;
};
const filledFrac = (rows: Record<string, string>[], cols: string[]): number =>
  rows.filter((r) => cols.some((c) => (r[c] ?? "") !== "")).length / Math.max(rows.length, 1);

/** How well a key's VALUES persist A→B — real keys carry over, volatile measures don't. */
const keyStability = (A: Record<string, string>[], B: Record<string, string>[], cols: string[], opts: CompareOptions): number => {
  const sa = new Set(A.map((r) => keyValueFor(r, cols, opts)).filter((v) => v !== ""));
  const sb = new Set(B.map((r) => keyValueFor(r, cols, opts)).filter((v) => v !== ""));
  return jaccard(sa, sb);
};

/**
 * Infer the best key column-set: consider every unique-enough single column AND
 * composite pairs/triples, then pick the one whose values persist best across the
 * two files (stability). This stops a volatile-but-unique measure (e.g. Qty) from
 * being chosen over a stable identifier (e.g. Region+SKU). Ties → fewer cols, then leftmost.
 */
function inferKey(common: string[], A: Record<string, string>[], B: Record<string, string>[], opts: CompareOptions): string[] {
  const cands: string[][] = [];
  for (const c of common) {
    if (Math.min(uniqueness(A, [c], opts), uniqueness(B, [c], opts)) > 0.9 && filledFrac(A, [c]) > 0.8 && filledFrac(B, [c]) > 0.8) cands.push([c]);
  }
  const ranked = common
    .map((c) => ({ c, u: Math.min(uniqueness(A, [c], opts), uniqueness(B, [c], opts)) }))
    .sort((x, y) => y.u - x.u)
    .slice(0, 6)
    .map((x) => x.c);
  const combos: string[][] = [];
  for (let i = 0; i < ranked.length; i++) for (let j = i + 1; j < ranked.length; j++) combos.push([ranked[i], ranked[j]]);
  for (let i = 0; i < ranked.length; i++) for (let j = i + 1; j < ranked.length; j++) for (let k = j + 1; k < ranked.length; k++) combos.push([ranked[i], ranked[j], ranked[k]]);
  for (const combo of combos) {
    if (Math.min(uniqueness(A, combo, opts), uniqueness(B, combo, opts)) > 0.98 && filledFrac(A, combo) > 0.8 && filledFrac(B, combo) > 0.8) cands.push(combo);
  }
  if (!cands.length) return [];
  const scored = cands.map((cols) => ({ cols, stab: keyStability(A, B, cols, opts), n: cols.length, idx: Math.min(...cols.map((c) => common.indexOf(c))) }));
  scored.sort((x, y) => y.stab - x.stab || x.n - y.n || x.idx - y.idx);
  return scored[0].cols;
}

/** Resolve the key columns for a sheet: explicit override (single/composite/positional) > inference. */
function resolveKey(name: string, common: string[], a: Record<string, string>[], b: Record<string, string>[], opts: CompareOptions): string[] {
  const ov = opts.keys?.[name];
  if (ov === POSITION_KEY) return [];
  if (Array.isArray(ov)) {
    const valid = ov.filter((c) => common.includes(c));
    if (valid.length) return valid;
  } else if (typeof ov === "string" && common.includes(ov)) {
    return [ov];
  }
  return inferKey(common, a, b, opts);
}

function groupByKey(recs: Record<string, string>[], cols: string[], opts: CompareOptions) {
  const m = new Map<string, Record<string, string>[]>();
  let emptyKeys = 0;
  let dup = false;
  for (const r of recs) {
    const kv = keyValueFor(r, cols, opts);
    if (kv === "") {
      emptyKeys++;
      continue;
    }
    const bucket = m.get(kv);
    if (bucket) {
      bucket.push(r);
      dup = true;
    } else {
      m.set(kv, [r]);
    }
  }
  return { m, emptyKeys, dup };
}

function jaccard(a: Set<string>, b: Set<string>): number {
  if (!a.size && !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}

/** Row-content signature set (full-row identity) — one signal for rename detection. */
function rowSignatures(recs: Record<string, string>[]): Set<string> {
  return new Set(recs.map((r) => Object.keys(r).sort().map((k) => `${k}=${r[k]}`).join("|")));
}

/**
 * Likelihood two tabs (present in only one file each) are the SAME tab renamed.
 * Uses header overlap plus the best identifier-column persistence — so it still
 * fires when the data itself changed (which whole-row identity would miss). 0 = not a rename.
 */
function renameScore(a: { headers: string[]; recs: Record<string, string>[] }, b: { headers: string[]; recs: Record<string, string>[] }): number {
  const headerSim = jaccard(new Set(a.headers), new Set(b.headers));
  if (headerSim < 0.6 || !a.recs.length || !b.recs.length) return 0;
  const rowSim = jaccard(rowSignatures(a.recs), rowSignatures(b.recs));
  let idSim = 0;
  for (const c of a.headers.filter((h) => b.headers.includes(h))) {
    const sa = new Set(a.recs.map((r) => r[c]).filter((v) => v !== ""));
    const sb = new Set(b.recs.map((r) => r[c]).filter((v) => v !== ""));
    idSim = Math.max(idSim, jaccard(sa, sb));
  }
  const content = Math.max(rowSim, idSim);
  return content >= 0.5 ? headerSim * 0.5 + content * 0.5 : 0;
}

function compareSheet(name: string, rawA: unknown[][], rawB: unknown[][], o: CompareOptions, extraNote?: string): SheetDiff {
  const a = records(rawA, o.firstRowHeader!);
  const b = records(rawB, o.firstRowHeader!);
  const headers = Array.from(new Set([...a.headers, ...b.headers]));
  const common = a.headers.filter((h) => b.headers.includes(h));
  const addedCols = b.headers.filter((h) => !a.headers.includes(h));
  const removedCols = a.headers.filter((h) => !b.headers.includes(h));
  const keyColumns = resolveKey(name, common, a.recs, b.recs, o);

  const rows: RowChange[] = [];
  let added = 0, removed = 0, modified = 0;
  let keyUnique = true;
  const notes: string[] = [];
  if (extraNote) notes.push(extraNote);

  const fieldDiff = (ra: Record<string, string>, rb: Record<string, string>): FieldChange[] => {
    const fields: FieldChange[] = [];
    for (const col of headers) {
      const ov = ra[col] ?? "";
      const nv = rb[col] ?? "";
      if (!valuesEqual(ov, nv, o)) fields.push({ col, old: ov, new: nv, delta: pctDelta(ov, nv) });
    }
    return fields;
  };

  if (keyColumns.length) {
    const ga = groupByKey(a.recs, keyColumns, o);
    const gb = groupByKey(b.recs, keyColumns, o);
    keyUnique = !ga.dup && !gb.dup;
    const keys = Array.from(new Set([...ga.m.keys(), ...gb.m.keys()]));
    for (const kv of keys) {
      const la = ga.m.get(kv) ?? [];
      const lb = gb.m.get(kv) ?? [];
      const display = keyDisplay(la[0] ?? lb[0], keyColumns) || kv;
      const n = Math.max(la.length, lb.length);
      for (let i = 0; i < n; i++) {
        const ra = la[i];
        const rb = lb[i];
        if (ra && rb) {
          const fields = fieldDiff(ra, rb);
          if (fields.length) { rows.push({ key: display, type: "modified", fields, values: rb }); modified++; }
        } else if (rb) { rows.push({ key: display, type: "added", fields: [], values: rb }); added++; }
        else if (ra) { rows.push({ key: display, type: "removed", fields: [], values: ra }); removed++; }
      }
    }
    const label = keyColumns.join(" + ");
    if (!keyUnique) notes.push(`Key "${label}" has duplicate values — those rows were matched in order; pick a more unique key if this looks off.`);
    const emptyTotal = ga.emptyKeys + gb.emptyKeys;
    if (emptyTotal) notes.push(`${emptyTotal} row(s) had a blank "${label}" and were skipped from key matching.`);
  } else {
    notes.push("No unique key column found — rows matched by position. Reordered rows may show as changes; choose a key column above for exact matching.");
    const n = Math.max(a.recs.length, b.recs.length);
    for (let i = 0; i < n; i++) {
      const ra = a.recs[i];
      const rb = b.recs[i];
      const k = String(i + 1);
      if (ra && rb) {
        const fields = fieldDiff(ra, rb);
        if (fields.length) { rows.push({ key: k, type: "modified", fields, values: rb }); modified++; }
      } else if (rb) { rows.push({ key: k, type: "added", fields: [], values: rb }); added++; }
      else if (ra) { rows.push({ key: k, type: "removed", fields: [], values: ra }); removed++; }
    }
  }

  const changed = added || removed || modified || addedCols.length || removedCols.length;
  return {
    name,
    status: changed ? "changed" : "same",
    headers,
    keyColumns,
    keyColumn: keyColumns.length ? keyColumns.join(" + ") : null,
    keyCandidates: common,
    keyUnique,
    renamedFrom: null,
    note: notes.length ? notes.join(" ") : null,
    addedCols,
    removedCols,
    rows,
    added,
    removed,
    modified,
  };
}

export function compareWorkbooks(A: Workbook, B: Workbook, opts: CompareOptions = {}): CompareResult {
  const o: CompareOptions = { firstRowHeader: true, ignoreCase: false, ignoreWhitespace: false, numericTolerancePct: 0, keys: {}, ...opts };
  const inBoth = Object.keys(A.sheets).filter((n) => n in B.sheets);
  const onlyA = Object.keys(A.sheets).filter((n) => !(n in B.sheets));
  const onlyB = Object.keys(B.sheets).filter((n) => !(n in A.sheets));

  // Detect renamed tabs: pair an only-in-A tab with an only-in-B tab by header + identifier overlap.
  const recA = new Map(onlyA.map((n) => [n, records(A.sheets[n], o.firstRowHeader!)]));
  const recB = new Map(onlyB.map((n) => [n, records(B.sheets[n], o.firstRowHeader!)]));
  const renamePairs: [string, string][] = [];
  const usedB = new Set<string>();
  for (const na of onlyA) {
    let best: string | null = null;
    let bestScore = 0; // renameScore returns 0 when it isn't confidently a rename
    for (const nb of onlyB) {
      if (usedB.has(nb)) continue;
      const score = renameScore(recA.get(na)!, recB.get(nb)!);
      if (score > bestScore) { bestScore = score; best = nb; }
    }
    if (best) { renamePairs.push([na, best]); usedB.add(best); }
  }
  const renamedA = new Set(renamePairs.map((p) => p[0]));

  const sheets: SheetDiff[] = [];
  let tAdded = 0, tRemoved = 0, tModified = 0, sheetsChanged = 0;
  const tally = (sh: SheetDiff) => {
    tAdded += sh.added; tRemoved += sh.removed; tModified += sh.modified;
    if (sh.status !== "same") sheetsChanged++;
    sheets.push(sh);
  };

  // ordering: keep A's tab order, then renamed (under new name), then B-only tabs
  for (const name of Object.keys(A.sheets)) {
    if (name in B.sheets) tally(compareSheet(name, A.sheets[name], B.sheets[name], o));
  }
  for (const [na, nb] of renamePairs) {
    const sh = compareSheet(nb, A.sheets[na], B.sheets[nb], o, `Renamed from "${na}".`);
    sh.renamedFrom = na;
    if (sh.status === "same") sh.status = "changed"; // a rename is itself a change worth surfacing
    tally(sh);
  }
  for (const name of onlyB) {
    if (!usedB.has(name)) tally(emptySheet(name, "added", B.sheets[name], o));
  }
  for (const name of onlyA) {
    if (!renamedA.has(name)) tally(emptySheet(name, "removed", A.sheets[name], o));
  }

  return { a: A.name, b: B.name, sheets, totals: { added: tAdded, removed: tRemoved, modified: tModified, sheetsChanged } };
}

function emptySheet(name: string, status: "added" | "removed", rows: unknown[][] | undefined, o: CompareOptions): SheetDiff {
  const r = rows ? records(rows, o.firstRowHeader!) : { headers: [], recs: [] };
  return {
    name,
    status,
    headers: r.headers,
    keyColumns: [],
    keyColumn: null,
    keyCandidates: [],
    keyUnique: true,
    renamedFrom: null,
    note: status === "added" ? "This tab exists only in the updated file." : "This tab was removed — it exists only in the original file.",
    addedCols: [],
    removedCols: [],
    rows: r.recs.map((v, i) => ({ key: String(i + 1), type: status === "added" ? "added" : "removed", fields: [], values: v })),
    added: status === "added" ? r.recs.length : 0,
    removed: status === "removed" ? r.recs.length : 0,
    modified: 0,
  };
}

/** Compact text summary for the AI + docked chat. */
export function summarizeDiff(r: CompareResult): string {
  const lines = r.sheets
    .filter((sh) => sh.status !== "same")
    .map((sh) => {
      if (sh.status === "added") return `- Tab "${sh.name}": entirely new (${sh.added} rows).`;
      if (sh.status === "removed") return `- Tab "${sh.name}": removed.`;
      const rn = sh.renamedFrom ? `renamed from "${sh.renamedFrom}"; ` : "";
      const cols = [sh.addedCols.length ? `cols added: ${sh.addedCols.join(", ")}` : "", sh.removedCols.length ? `cols removed: ${sh.removedCols.join(", ")}` : ""].filter(Boolean).join("; ");
      const ex = sh.rows
        .filter((x) => x.type === "modified")
        .slice(0, 5)
        .map((x) => `[${x.key}] ${x.fields.map((f) => `${f.col}: "${f.old}"→"${f.new}"${f.delta ? ` (${f.delta})` : ""}`).join(", ")}`)
        .join("; ");
      return `- Tab "${sh.name}" (${rn}key=${sh.keyColumn ?? "row position"}): +${sh.added} rows, −${sh.removed} rows, ~${sh.modified} changed. ${cols} ${ex ? "e.g. " + ex : ""}`.trim();
    });
  const tabWord = r.sheets.length === 1 ? "tab" : "tabs";
  return `Comparing ${r.a} → ${r.b}. Compared ${r.sheets.length} ${tabWord}. Totals: ${r.totals.added} rows added, ${r.totals.removed} removed, ${r.totals.modified} modified across ${r.totals.sheetsChanged} tab(s).\n${lines.join("\n")}`;
}
