import { newId } from "./layouts";
import { withDb } from "./db";
import { embed, toVectorLiteral, type EmbedOverride } from "./embeddings";

/**
 * Exemplar RAG — the self-improving core.
 *
 * On 👍, we store the (prompt, answer) as an "exemplar" with its embedding.
 * On each new query, we retrieve the most similar approved exemplars and inject
 * them as few-shot guidance — so the assistant gets better at what users like,
 * with NO model retraining.
 */

export interface Exemplar {
  prompt: string;
  answer: string;
}

/** Persist a 👍'd exchange as a retrievable exemplar. */
export async function saveExemplar(
  input: { userId: string; skill: string; prompt: string; answer: string },
  ov?: EmbedOverride,
): Promise<void> {
  if (!input.prompt.trim() || !input.answer.trim()) return;
  await withDb(async (p) => {
    const vec = toVectorLiteral(await embed(`${input.skill}: ${input.prompt}`, ov));
    await p.query(
      `INSERT INTO exemplars (id, user_id, skill, prompt, answer, embedding)
       VALUES ($1,$2,$3,$4,$5,$6::vector)`,
      [newId(), input.userId, input.skill, input.prompt, input.answer, vec],
    );
    return true;
  }, undefined);
}

/** Retrieve the top-k most similar approved exemplars for a query. */
export async function retrieveExemplars(query: string, k = 3, ov?: EmbedOverride): Promise<Exemplar[]> {
  if (!query.trim()) return [];
  return withDb(async (p) => {
    const vec = toVectorLiteral(await embed(query, ov));
    const res = await p.query(
      `SELECT prompt, answer FROM exemplars
       ORDER BY embedding <=> $1::vector
       LIMIT $2`,
      [vec, k],
    );
    return res.rows as Exemplar[];
  }, []);
}

/** Format retrieved exemplars for injection into a system prompt. */
export function exemplarBlock(exemplars: Exemplar[]): string {
  if (!exemplars.length) return "";
  const items = exemplars
    .map((e, i) => `Example ${i + 1}:\nUser: ${e.prompt}\nAssistant: ${e.answer}`)
    .join("\n\n");
  return `\n\nHere are past answers users RATED HIGHLY for similar requests — match their style and quality:\n${items}`;
}
