import { create } from "zustand";
import { persist } from "zustand/middleware";
import { newId } from "./layouts";
import type { BrandKit } from "./types";

export interface SavedBrandKit {
  id: string;
  name: string;
  kit: BrandKit;
}

interface BrandKitState {
  kits: SavedBrandKit[];
  save: (name: string, kit: BrandKit) => void;
  remove: (id: string) => void;
}

/** Reusable brand kits (logo, colors, fonts, header/footer) saved across decks. */
export const useBrandKits = create<BrandKitState>()(
  persist(
    (set) => ({
      kits: [],
      save: (name, kit) =>
        set((s) => ({ kits: [...s.kits, { id: newId(), name: name.trim() || "Brand kit", kit }] })),
      remove: (id) => set((s) => ({ kits: s.kits.filter((k) => k.id !== id) })),
    }),
    { name: "pptmaker-brandkits" },
  ),
);
