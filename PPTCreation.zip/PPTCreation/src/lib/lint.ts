import { clampToCanvas } from "./geometry";
import { CANVAS } from "./utils";
import type { ColorValue, SlideElement } from "./types";

/**
 * Design lint + auto-repair. Guarantees every slide looks intentional:
 *  - CLAMP: content that runs off the canvas is pulled back inside,
 *  - CONTRAST: text sitting on a brand-colored / dark fill is switched to an
 *    on-fill color so it never disappears,
 *  - OVERLAP: badly overlapping text is nudged clear.
 * Deterministic and token-aware, so it works in the editor and both exporters.
 * Decorative bleed (z<0), brand chrome, and full-bleed backgrounds are left alone.
 */

const VIVID = new Set<ColorValue>(["token:primary", "token:accent", "token:secondary"]);
const W = CANVAS.w;
const H = CANVAS.h;

function lum(hex: string): number {
  const c = hex.replace("#", "");
  if (c.length < 6) return 0.5;
  return (0.299 * parseInt(c.slice(0, 2), 16) + 0.587 * parseInt(c.slice(2, 4), 16) + 0.114 * parseInt(c.slice(4, 6), 16)) / 255;
}

/** Is a fill (token or hex) a vivid/dark background that needs light (on-fill) text? */
function needsOnFill(fill: ColorValue | undefined): boolean {
  if (!fill) return false;
  if (VIVID.has(fill)) return true;
  if (typeof fill === "string" && fill.startsWith("#")) return lum(fill) < 0.4;
  return false;
}
function isLightFill(fill: ColorValue | undefined): boolean {
  if (fill === "token:surface" || fill === "token:background") return true;
  if (typeof fill === "string" && fill.startsWith("#")) return lum(fill) > 0.75;
  return false;
}

const box = (e: SlideElement) => ({ x: e.x, y: e.y, w: e.w, h: e.h });
function overlapFrac(a: SlideElement, b: SlideElement): number {
  const xo = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
  const yo = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  const inter = xo * yo;
  const min = Math.min(a.w * a.h, b.w * b.h) || 1;
  return inter / min;
}

const isFullBleed = (e: SlideElement) => e.type === "shape" && e.w >= W * 0.95 && e.h >= H * 0.95;
const isContent = (e: SlideElement) => !e.brand && (e.z ?? 0) >= 0 && !isFullBleed(e);

export interface RepairOpts {
  clampOffCanvas?: boolean;
  fixContrast?: boolean;
  fixOverlap?: boolean;
  margin?: number;
}

/** Repair a slide's elements in place. Returns the number of fixes applied. */
export function repairSlide(elements: SlideElement[], opts: RepairOpts = {}): number {
  const { clampOffCanvas = true, fixContrast = true, fixOverlap = false, margin = 24 } = opts;
  let fixes = 0;

  // ---- off-canvas clamp (content only; decor/backgrounds bleed by design) ----
  if (clampOffCanvas) {
    for (const e of elements) {
      if (!isContent(e)) continue;
      const off = e.x < 0 || e.y < 0 || e.x + e.w > W || e.y + e.h > H;
      if (!off) continue;
      const c = clampToCanvas(box(e), margin);
      if (c.x !== e.x || c.y !== e.y || c.w !== e.w || c.h !== e.h) {
        e.x = c.x; e.y = c.y; e.w = c.w; e.h = c.h;
        fixes++;
      }
    }
  }

  // ---- contrast: text on a vivid/dark fill → on-fill color; on a light fill → dark text ----
  if (fixContrast) {
    for (const e of elements) {
      if (e.type !== "text") continue;
      // topmost fill-bearing element beneath this text that it sits on
      let backingFill: ColorValue | undefined;
      let bestZ = -Infinity;
      for (const o of elements) {
        if (o === e || (o.type !== "shape")) continue;
        const fill = o.gradient?.[0] ?? o.fill;
        if (!fill) continue;
        if (overlapFrac(e, o) < 0.6) continue;
        const oz = o.z ?? 0;
        if (oz <= (e.z ?? 0) && oz >= bestZ) { bestZ = oz; backingFill = fill; }
      }
      if (!backingFill) continue;
      if (needsOnFill(backingFill) && e.color !== "token:onPrimary") { e.color = "token:onPrimary"; fixes++; }
      else if (isLightFill(backingFill) && e.color === "token:onPrimary") { e.color = "token:text"; fixes++; }
    }
  }

  // ---- overlap: nudge a text element clear of a text element it badly covers ----
  if (fixOverlap) {
    const texts = elements.filter((e) => e.type === "text" && isContent(e));
    for (let i = 0; i < texts.length; i++) {
      for (let j = i + 1; j < texts.length; j++) {
        const a = texts[i], b = texts[j];
        if (overlapFrac(a, b) < 0.55) continue;
        const below = Math.max(a.y + a.h, b.y + b.h) + 12;
        const target = a.y <= b.y ? b : a; // move the lower one further down
        const ny = Math.min(below, H - target.h - 12);
        if (ny > target.y) { target.y = ny; fixes++; }
      }
    }
  }

  return fixes;
}
