import { withDb } from "./db";

/**
 * Organization governance (server-side): the enforced brand kit + lock flags,
 * email-domain access rules, and SSO provider config. One row ("default").
 * Degrades to sensible defaults when Postgres is unavailable.
 */

export interface OrgBrand {
  logoUrl?: string;
  primaryColor?: string;
  accentColor?: string;
  fontHeading?: string;
  fontBody?: string;
  footerText?: string;
}

export interface OrgLocks {
  colors: boolean;
  fonts: boolean;
  logo: boolean;
  footer: boolean;
}

export interface OrgSso {
  enabled: boolean;
  provider?: string; // display name, e.g. "Okta"
  issuer?: string;
  clientId?: string;
  clientSecret?: string;
}

export interface BrandPresetDef {
  id: string;
  name: string;
  brand: Record<string, unknown>; // a Partial<BrandKit>
  themeId?: string;
}

export interface OrgConfig {
  name: string;
  brand: OrgBrand;
  locks: OrgLocks;
  /** reusable, named brand presets (brand kit + theme) users can apply by name */
  brandPresets: BrandPresetDef[];
  /** approved logo/image URLs users may pick from */
  approvedAssets: string[];
  /** if set, only these email domains may sign up (e.g. ["oati.com"]) */
  allowedDomains: string[];
  /** email-domain → role, e.g. { "oati.com": "superadmin" } */
  domainRoles: Record<string, "superadmin" | "user">;
  sso: OrgSso;
}

export const DEFAULT_ORG: OrgConfig = {
  name: "OATI",
  brand: {},
  locks: { colors: false, fonts: false, logo: false, footer: false },
  brandPresets: [],
  approvedAssets: [],
  allowedDomains: [],
  domainRoles: {},
  sso: { enabled: false },
};

export async function getOrg(): Promise<OrgConfig> {
  return withDb(async (p) => {
    const r = await p.query("SELECT data FROM org_config WHERE id='default'");
    if (!r.rowCount) return DEFAULT_ORG;
    return { ...DEFAULT_ORG, ...(r.rows[0].data as Partial<OrgConfig>) };
  }, DEFAULT_ORG);
}

export async function saveOrg(config: OrgConfig): Promise<boolean> {
  return withDb(async (p) => {
    await p.query(
      `INSERT INTO org_config (id, data, updated_at) VALUES ('default', $1, now())
       ON CONFLICT (id) DO UPDATE SET data=EXCLUDED.data, updated_at=now()`,
      [config],
    );
    return true;
  }, false);
}

/** Public-safe view (no SSO client secret) for non-admin clients. */
export function sanitizeOrg(o: OrgConfig) {
  return {
    name: o.name,
    brand: o.brand,
    locks: o.locks,
    brandPresets: o.brandPresets,
    approvedAssets: o.approvedAssets,
    allowedDomains: o.allowedDomains,
    domainRoles: o.domainRoles,
    sso: { enabled: o.sso.enabled, provider: o.sso.provider },
  };
}
