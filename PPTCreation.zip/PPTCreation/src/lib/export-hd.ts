import { deckFromImport, type ImportedDeck } from "./deck";
import type { Deck } from "./types";

/**
 * Optional high-fidelity export via the python-pptx microservice (pyexport/).
 * Enabled when NEXT_PUBLIC_PYEXPORT_URL is set. The service consumes the same
 * Deck JSON and returns an editable .pptx with true gradients + crisp shapes.
 */
export const PYEXPORT_URL = process.env.NEXT_PUBLIC_PYEXPORT_URL;

/** Import an existing .pptx into an editable Deck via the pyexport service. */
export async function importDeckFromPptx(file: File): Promise<Deck> {
  if (!PYEXPORT_URL) throw new Error("Import needs the export service (NEXT_PUBLIC_PYEXPORT_URL).");
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch(`${PYEXPORT_URL.replace(/\/$/, "")}/import-pptx`, { method: "POST", body: fd });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Import failed (${res.status}). ${text.slice(0, 200)}`);
  }
  const raw = (await res.json()) as ImportedDeck;
  return deckFromImport(raw);
}

export async function exportDeckHD(deck: Deck): Promise<void> {
  if (!PYEXPORT_URL) throw new Error("HD export is not configured (NEXT_PUBLIC_PYEXPORT_URL).");
  const res = await fetch(`${PYEXPORT_URL.replace(/\/$/, "")}/export`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ deck }),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`HD export failed (${res.status}). ${text}`);
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${(deck.title || "presentation").replace(/[^\w\d-]+/g, "_").slice(0, 60)}.pptx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
