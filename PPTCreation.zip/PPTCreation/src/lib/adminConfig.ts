import { create } from "zustand";
import { persist } from "zustand/middleware";

/**
 * Admin-only platform configuration, editable from Settings (Super Admin) and
 * sent to the server per-request — no .env edits needed.
 *
 * Embeddings default to the local BGE service (pyexport /v1/embeddings).
 */
export type ImageProvider = "picsum" | "unsplash" | "pexels";

export interface ImageConfig {
  provider: ImageProvider;
  apiKey?: string;
  genBaseUrl?: string;
  genModel?: string;
  genApiKey?: string;
}

interface AdminConfigState {
  embedBaseUrl: string;
  embedModel: string;
  ragTopK: number;
  ragEnabled: boolean;
  // imagery (stock search + AI generation)
  imageProvider: ImageProvider;
  imageApiKey: string;
  imageGenBaseUrl: string;
  imageGenModel: string;
  imageGenApiKey: string;
  set: (patch: Partial<Omit<AdminConfigState, "set" | "embedOverride" | "imageOverride">>) => void;
  /** override sent to the server for embeddings ({} => server uses its own default/fallback) */
  embedOverride: () => { baseUrl?: string; model?: string };
  /** config sent to the image API routes (keyless Picsum works with no setup) */
  imageOverride: () => ImageConfig;
}

export const useAdminConfig = create<AdminConfigState>()(
  persist(
    (set, get) => ({
      embedBaseUrl: "http://localhost:8910/v1",
      embedModel: "BAAI/bge-base-en-v1.5",
      ragTopK: 3,
      ragEnabled: true,
      imageProvider: "picsum",
      imageApiKey: "",
      imageGenBaseUrl: "",
      imageGenModel: "",
      imageGenApiKey: "",
      set: (patch) => set(patch),
      embedOverride: () => {
        const { embedBaseUrl, embedModel } = get();
        return embedBaseUrl && embedModel ? { baseUrl: embedBaseUrl, model: embedModel } : {};
      },
      imageOverride: () => {
        const { imageProvider, imageApiKey, imageGenBaseUrl, imageGenModel, imageGenApiKey } = get();
        return {
          provider: imageProvider,
          apiKey: imageApiKey || undefined,
          genBaseUrl: imageGenBaseUrl || undefined,
          genModel: imageGenModel || undefined,
          genApiKey: imageGenApiKey || undefined,
        };
      },
    }),
    { name: "oatigenie-admin" },
  ),
);
