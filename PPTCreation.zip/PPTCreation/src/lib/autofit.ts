import type { SlideElement, TextElement } from "./types";

/**
 * Deterministic text auto-fit. AI-generated content is unpredictable in length,
 * and the #1 thing that makes a deck look amateur is text overflowing or clipping
 * its box. We estimate whether text fits a box at its designed size and shrink the
 * font (never grow) until it fits — using a character-advance model so it works
 * identically in the editor AND in both export pipelines (no DOM measurement).
 */

// average glyph advance as a fraction of font size (Inter/Calibri ≈ 0.5; pad a little)
const ADV = 0.52;
const ADV_BOLD = 0.55;

function contentLines(el: TextElement): string[] {
  if (el.items && el.items.length && el.listStyle !== "none") return el.items.map(String);
  return String(el.text ?? "").split("\n");
}

/** Does `lines` fit a w×h box at font size `f`? Accounts for wrapping + list markers. */
function fits(lines: string[], w: number, h: number, f: number, lineHeight: number, weight: number, list: boolean): boolean {
  const adv = weight >= 700 ? ADV_BOLD : ADV;
  const marker = list ? 1.6 * f : 0; // bullet/number indent eats width
  const usable = Math.max(1, w - marker);
  const cpl = Math.max(1, Math.floor(usable / (f * adv)));
  let rows = 0;
  for (const ln of lines) {
    const len = ln.trim().length;
    rows += Math.max(1, Math.ceil(len / cpl));
  }
  return rows * f * lineHeight <= h;
}

/** Fit one text element in place — shrinks fontSize only when it would overflow. */
export function autofitTextElement(el: TextElement): void {
  const base = el.fontSize ?? 18;
  if (!el.w || !el.h || base <= 0) return;
  const lines = contentLines(el);
  if (!lines.length) return;
  const lineHeight = el.lineHeight ?? 1.2;
  const weight = el.fontWeight ?? 400;
  const list = !!(el.items && el.items.length && el.listStyle !== "none");
  // don't shrink below a role-aware floor (keeps things readable)
  const floor = Math.max(11, Math.round(base * 0.5));
  if (fits(lines, el.w, el.h, base, lineHeight, weight, list)) return;
  for (let f = base - 1; f >= floor; f--) {
    if (fits(lines, el.w, el.h, f, lineHeight, weight, list)) {
      el.fontSize = f;
      return;
    }
  }
  el.fontSize = floor;
}

/** Apply auto-fit to every text element on a slide (mutates in place). */
export function autofitSlide(elements: SlideElement[]): void {
  for (const el of elements) if (el.type === "text") autofitTextElement(el);
}
