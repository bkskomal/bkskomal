import { create } from "zustand";
import { persist } from "zustand/middleware";
import { newId } from "./layouts";

/**
 * Captured user feedback on assistant replies — WITH context, so it can drive a
 * self-improving loop (preference data, good-answer exemplar memory, evals).
 *
 * Stored locally for now; mirrors the Postgres `feedback` table we'll add for a
 * real backend (see the architecture notes in the chat).
 */
export interface FeedbackEvent {
  id: string;
  userId: string;
  convId?: string;
  rating: "up" | "down";
  model: string;
  /** the user prompt that produced the reply */
  prompt: string;
  /** the assistant reply being rated */
  answer: string;
  reason?: string;
  at: number;
}

interface FeedbackState {
  events: FeedbackEvent[];
  add: (ev: Omit<FeedbackEvent, "id" | "at">) => void;
  remove: (id: string) => void;
  clear: (userId?: string) => void;
  forUser: (userId: string) => FeedbackEvent[];
}

export const useFeedback = create<FeedbackState>()(
  persist(
    (set, get) => ({
      events: [],
      add: (ev) =>
        set((s) => ({ events: [{ ...ev, id: newId(), at: Date.now() }, ...s.events].slice(0, 1000) })),
      remove: (id) => set((s) => ({ events: s.events.filter((e) => e.id !== id) })),
      clear: (userId) =>
        set((s) => ({ events: userId ? s.events.filter((e) => e.userId !== userId) : [] })),
      forUser: (userId) => get().events.filter((e) => e.userId === userId).sort((a, b) => b.at - a.at),
    }),
    { name: "oatigenie-feedback" },
  ),
);
