import { CANVAS } from "./utils";

export interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Keep a box fully inside the slide canvas (no clipping off the edges). */
export function clampToCanvas(b: Box, margin = 8): Box {
  const w = Math.min(b.w, CANVAS.w - margin * 2);
  const h = Math.min(b.h, CANVAS.h - margin * 2);
  return {
    w,
    h,
    x: Math.round(Math.max(margin, Math.min(b.x, CANVAS.w - w - margin))),
    y: Math.round(Math.max(margin, Math.min(b.y, CANVAS.h - h - margin))),
  };
}

function overlapArea(a: Box, b: Box): number {
  const xo = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
  const yo = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  return xo * yo;
}

/**
 * Place a (resized) box so it stays on-canvas and overlaps the given obstacles
 * as little as possible. Keeps the box where it is if there's no collision;
 * otherwise scans candidate positions and picks the clearest. This is what keeps
 * a freshly-resized logo/image from covering the slide's text.
 */
export function placeClear(box: Box, obstacles: Box[]): Box {
  const start = clampToCanvas(box);
  const startScore = obstacles.reduce((s, o) => s + overlapArea(start, o), 0);
  if (startScore === 0) return start;

  let best = start;
  let bestScore = startScore;
  const steps = 6;
  const stepX = (CANVAS.w - box.w - 16) / steps;
  const stepY = (CANVAS.h - box.h - 16) / steps;
  for (let gy = 0; gy <= steps; gy++) {
    for (let gx = 0; gx <= steps; gx++) {
      const cand = clampToCanvas({ ...box, x: 8 + gx * stepX, y: 8 + gy * stepY });
      const score = obstacles.reduce((s, o) => s + overlapArea(cand, o), 0);
      if (score < bestScore) {
        bestScore = score;
        best = cand;
        if (score === 0) return best;
      }
    }
  }
  return best;
}
