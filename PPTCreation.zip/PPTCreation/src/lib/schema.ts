import { z } from "zod";

/**
 * Schema the AI assistant must conform to. We deliberately keep the AI's job
 * SEMANTIC (outline + per-slide content + a layout choice) rather than letting
 * it place pixels. The deterministic layout engine (layouts.ts) turns this into
 * positioned SlideElements, which guarantees on-brand, beautiful output.
 */

export const aiSlideSchema = z.object({
  layout: z
    .string()
    .describe("One of the allowed block ids provided in the prompt."),
  variant: z
    .string()
    .optional()
    .describe(
      "Optional visual style for blocks that support it: statGrid ('cards'|'minimal'|'circles'), bullets ('dots'|'checks'|'cards'), process ('horizontal'|'vertical').",
    ),
  title: z.string().describe("Slide title / headline."),
  subtitle: z.string().optional().describe("Optional supporting line."),
  kicker: z
    .string()
    .optional()
    .describe("Tiny eyebrow label above the title, e.g. 'INTRODUCTION'."),
  bullets: z
    .array(z.string())
    .optional()
    .describe("Bullet points / agenda items for list-style blocks. 3-6 concise items."),
  body: z.string().optional().describe("A short paragraph of body copy."),
  pills: z.array(z.string()).optional().describe("2-5 short action words for a cover (e.g. Detect, Classify, Enforce)."),
  quote: z.string().optional().describe("Quote text for the 'quote' block."),
  attribution: z.string().optional().describe("Who said the quote."),
  stat: z
    .object({ value: z.string(), label: z.string() })
    .optional()
    .describe("Big number + caption for the 'stat' block."),
  // --- block data ---
  stats: z
    .array(z.object({ value: z.string(), label: z.string() }))
    .optional()
    .describe("2-4 metric cards for the 'statGrid' block."),
  steps: z
    .array(z.object({ title: z.string(), description: z.string().optional() }))
    .optional()
    .describe("3-5 ordered steps for the 'process' block."),
  columns: z
    .array(z.object({ heading: z.string(), points: z.array(z.string()) }))
    .optional()
    .describe("2-3 labelled columns for the 'comparison' block."),
  timeline: z
    .array(z.object({ label: z.string(), title: z.string(), description: z.string().optional() }))
    .optional()
    .describe("3-5 milestones for the 'timeline' block (label = date/phase)."),
  team: z
    .array(z.object({ name: z.string(), role: z.string() }))
    .optional()
    .describe("2-6 people for the 'team' block."),
  chart: z
    .object({
      unit: z.string().optional(),
      type: z.enum(["bar", "column", "line", "area", "pie", "donut"]).optional(),
      data: z.array(z.object({ label: z.string(), value: z.number() })).optional(),
      categories: z.array(z.string()).optional(),
      series: z.array(z.object({ name: z.string(), data: z.array(z.number()) })).optional(),
    })
    .optional()
    .describe("Chart for the 'chart' block. Single series: data[{label,value}]. Multi-series: categories[] + series[{name,data[]}]. type defaults to 'column' (bar|column|line|area|pie|donut)."),
  callout: z.string().optional().describe("A single highlighted statement for the 'callout' block."),
  // --- premium recipe blocks ---
  kpis: z
    .array(z.object({ value: z.string(), label: z.string(), delta: z.string().optional() }))
    .optional()
    .describe("3-6 KPI tiles for the 'kpiDashboard' block; delta like '+12%' or '-3%'."),
  gantt: z
    .object({
      unit: z.string().optional(),
      tasks: z.array(z.object({ label: z.string(), start: z.number(), end: z.number() })),
    })
    .optional()
    .describe("Tasks for the 'gantt' block; start/end are numeric periods (e.g. months 0..12)."),
  org: z
    .array(z.object({ name: z.string(), role: z.string(), level: z.number() }))
    .optional()
    .describe("Nodes for the 'orgChart' block; level 0 = top, 1, 2… down the hierarchy."),
  funnel: z
    .array(z.object({ label: z.string(), value: z.string().optional() }))
    .optional()
    .describe("Stages (top→bottom, widest→narrowest) for the 'funnel' block."),
  pyramid: z
    .array(z.object({ label: z.string(), description: z.string().optional() }))
    .optional()
    .describe("Levels (top→bottom, narrow→wide) for the 'pyramid' block."),
  notes: z.string().optional().describe("Speaker notes for the presenter."),
});

export const aiDeckSchema = z.object({
  title: z.string(),
  subtitle: z.string().optional(),
  slides: z.array(aiSlideSchema).min(1).max(40),
});

export type AISlide = z.infer<typeof aiSlideSchema>;
export type AIDeck = z.infer<typeof aiDeckSchema>;

/** JSON-schema-ish description embedded in the prompt for models without tool calling. */
export const AI_DECK_FORMAT_HINT = `Return STRICT JSON, no markdown fences, matching:
{
  "title": string,
  "subtitle"?: string,
  "slides": [
    {
      "layout": <one of the block ids listed above>,
      "title": string,
      "subtitle"?: string,
      "kicker"?: string,
      "bullets"?: string[],
      "body"?: string,
      "quote"?: string,
      "attribution"?: string,
      "stat"?: { "value": string, "label": string },
      "stats"?: [{ "value": string, "label": string }],
      "steps"?: [{ "title": string, "description"?: string }],
      "columns"?: [{ "heading": string, "points": string[] }],
      "timeline"?: [{ "label": string, "title": string, "description"?: string }],
      "team"?: [{ "name": string, "role": string }],
      "chart"?: { "unit"?: string, "data": [{ "label": string, "value": number }] },
      "callout"?: string,
      "kpis"?: [{ "value": string, "label": string, "delta"?: string }],
      "gantt"?: { "unit"?: string, "tasks": [{ "label": string, "start": number, "end": number }] },
      "notes"?: string
    }
  ]
}
Populate the data field that matches each block (e.g. "statGrid" -> "stats", "process" -> "steps",
"comparison" -> "columns", "timeline" -> "timeline", "team" -> "team", "chart" -> "chart").`;
