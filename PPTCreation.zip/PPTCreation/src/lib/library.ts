import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { newId } from "./layouts";
import { idbStorage } from "./idbStorage";
import type { Deck } from "./types";

/**
 * The deck library — every presentation the user has created, saved to
 * IndexedDB (large quota; image-heavy decks overflow localStorage).
 */
interface LibraryState {
  decks: Record<string, Deck>;
  upsert: (deck: Deck) => void;
  remove: (id: string) => void;
  duplicate: (id: string) => Deck | null;
  rename: (id: string, title: string) => void;
}

export const useLibrary = create<LibraryState>()(
  persist(
    (set, get) => ({
      decks: {},
      upsert: (deck) => set((s) => ({ decks: { ...s.decks, [deck.id]: deck } })),
      remove: (id) =>
        set((s) => {
          const next = { ...s.decks };
          delete next[id];
          return { decks: next };
        }),
      duplicate: (id) => {
        const d = get().decks[id];
        if (!d) return null;
        const copy: Deck = { ...d, id: newId(), title: `${d.title} (copy)`, updatedAt: Date.now() };
        set((s) => ({ decks: { ...s.decks, [copy.id]: copy } }));
        return copy;
      },
      rename: (id, title) =>
        set((s) =>
          s.decks[id]
            ? { decks: { ...s.decks, [id]: { ...s.decks[id], title, updatedAt: Date.now() } } }
            : s,
        ),
    }),
    { name: "pptmaker-library", storage: createJSONStorage(() => idbStorage) },
  ),
);

/** Decks sorted most-recently-updated first. */
export function listDecks(decks: Record<string, Deck>): Deck[] {
  return Object.values(decks).sort((a, b) => b.updatedAt - a.updatedAt);
}
