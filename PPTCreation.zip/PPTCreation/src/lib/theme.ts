import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ThemeName = "light" | "solarized-light" | "dark" | "solarized-dark";
export type ThemeSetting = ThemeName | "system";

/** Cycle order for the single toggle button. */
export const THEME_ORDER: ThemeName[] = ["light", "solarized-light", "dark", "solarized-dark"];

export const THEME_LABELS: Record<ThemeName, string> = {
  light: "Light",
  "solarized-light": "Solarized Light",
  dark: "Dark",
  "solarized-dark": "Solarized Dark",
};

function systemTheme(): ThemeName {
  if (typeof window === "undefined") return "dark";
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

interface ThemeState {
  setting: ThemeSetting; // "system" until the user picks one
  resolved: () => ThemeName;
  set: (t: ThemeSetting) => void;
  cycle: () => void;
}

export const useTheme = create<ThemeState>()(
  persist(
    (set, get) => ({
      setting: "system",
      resolved: () => (get().setting === "system" ? systemTheme() : (get().setting as ThemeName)),
      set: (t) => set({ setting: t }),
      cycle: () => {
        const cur = get().resolved();
        const i = THEME_ORDER.indexOf(cur);
        set({ setting: THEME_ORDER[(i + 1) % THEME_ORDER.length] });
      },
    }),
    { name: "oatigenie-theme" },
  ),
);
