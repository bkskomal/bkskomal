import { aiSlideSchema, type AIDeck, type AISlide } from "./schema";

/**
 * Deterministic outline → deck parser.
 *
 * When a user provides a structured, slide-by-slide outline (e.g. "## Slide 1 – …"
 * with bullets underneath), we honour it 1:1 instead of letting the model rewrite
 * it into a lossy brief. This guarantees the deck mirrors exactly what they typed:
 * every slide, title, bullet and section is preserved. Layouts are chosen from the
 * shape of each slide's content (cover / comparison / bullets / closing …).
 *
 * Returns null when the text isn't a recognisable multi-slide outline, so the
 * caller can fall back to normal AI generation.
 */

const stripInline = (s: string): string =>
  s
    .replace(/`([^`]*)`/g, "$1")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/__([^_]+)__/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/_([^_]+)_/g, "$1")
    .replace(/^\s*#{1,6}\s*/, "")
    .trim();

const SLIDE_HEAD = /^#{1,6}\s*slide\s*(\d+)\s*[–—:.\-]*\s*(.*)$/i;
const ANY_HEAD = /^(#{1,6})\s+(.*)$/;
const BULLET = /^\s*([*\-+•✓✔]|\d+[.)])\s+(.+)$/;
const BOLD_LABEL = /^\s*\*\*([^*]+?):?\*\*\s*(.*)$/; // **Subtitle:** value

interface Section {
  heading?: string;
  points: string[];
  para: string[];
}

interface RawSlide {
  title: string;
  index: number | null; // explicit "Slide N" number, else null
  lines: string[];
}

/** Split the document into front-matter + slide chunks. */
function segment(text: string): { front: string[]; slides: RawSlide[] } | null {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  const slides: RawSlide[] = [];
  const front: string[] = [];
  let sawSlideKeyword = false;

  for (const line of lines) {
    if (/^\s*---+\s*$/.test(line)) continue; // horizontal rules are separators
    const slideM = line.match(SLIDE_HEAD);
    if (slideM) {
      sawSlideKeyword = true;
      slides.push({ title: stripInline(slideM[2]) || `Slide ${slideM[1]}`, index: Number(slideM[1]), lines: [] });
      continue;
    }
    const headM = line.match(ANY_HEAD);
    const level = headM ? headM[1].length : 0;
    // H2 always starts a new slide; an H1 before any slide is the deck title (front matter).
    if (headM && (level === 2 || (level === 1 && slides.length > 0))) {
      slides.push({ title: stripInline(headM[2]), index: null, lines: [] });
      continue;
    }
    if (slides.length) slides[slides.length - 1].lines.push(line);
    else front.push(line);
  }

  if (!slides.length) return null;
  // Only treat as a real outline if it's clearly multi-slide (explicit "Slide N" or ≥3 sections).
  if (!sawSlideKeyword && slides.length < 3) return null;
  return { front, slides };
}

const isQuoted = (s: string): boolean => /^["“](.+)["”]$/.test(s.trim());
const unquote = (s: string): string => s.trim().replace(/^["“]/, "").replace(/["”]$/, "").trim();

/** Parse a slide's body lines into sections (headed groups + bullets + paragraphs). Order preserved. */
function parseSections(lines: string[]): { sections: Section[]; subtitle?: string } {
  const sections: Section[] = [{ points: [], para: [] }];
  let subtitle: string | undefined;
  let pendingLabel: string | null = null;

  const cur = () => sections[sections.length - 1];

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) { pendingLabel = null; continue; }

    // **Subtitle:** value  (or the value on the next line)
    const labelM = line.match(BOLD_LABEL);
    if (labelM) {
      const label = labelM[1].trim().toLowerCase();
      const value = stripInline(labelM[2]);
      if (label === "subtitle") { if (value) subtitle = value; else pendingLabel = "subtitle"; continue; }
      // other bold labels act as a mini section heading
      sections.push({ heading: stripInline(labelM[1]), points: [], para: value ? [value] : [] });
      continue;
    }

    // sub-heading (### / ####) → new section
    const headM = line.match(ANY_HEAD);
    if (headM && headM[1].length >= 3) {
      sections.push({ heading: stripInline(headM[2]), points: [], para: [] });
      continue;
    }

    // bullet / numbered item
    const bulletM = line.match(BULLET);
    if (bulletM) { cur().points.push(stripInline(bulletM[2])); pendingLabel = null; continue; }

    const clean = stripInline(line);
    if (pendingLabel === "subtitle") { subtitle = clean; pendingLabel = null; continue; }
    cur().para.push(clean); // quoted lines are kept here, in order — nothing is dropped
  }

  const filtered = sections.filter((s) => s.heading || s.points.length || s.para.length);
  return { sections: filtered.length ? filtered : [{ points: [], para: [] }], subtitle };
}

const clean = (s: AISlide) => aiSlideSchema.parse(s);

/** Build one AISlide from a raw slide chunk, choosing a layout from its content shape. */
function buildSlide(raw: RawSlide, position: number): AISlide {
  const { sections, subtitle } = parseSections(raw.lines);
  const title = raw.title || "Slide";
  const headed = sections.filter((s) => s.heading && (s.points.length || s.para.length));
  const allPoints = sections.flatMap((s) => s.points);
  const allPara = sections.flatMap((s) => s.para);
  const bodyText = allPara.join(" ").trim();
  const isFirst = position === 0;

  // Title / cover slide
  if (isFirst || /^title slide$/i.test(title) || /^title$/i.test(title)) {
    const firstHead = sections.find((s) => s.heading)?.heading;
    const sub = subtitle || firstHead || allPara[0];
    return clean({ layout: "cover", title: /^title/i.test(title) ? firstHead || "Presentation" : title, subtitle: sub, notes: bodyText || undefined });
  }

  // Closing / thank-you slide — by title (a trailing "activities" section may come after it)
  if (!isFirst && /(thank you|thank-you|^thanks|closing)/i.test(title)) {
    const parts: string[] = [];
    for (const s of sections) {
      if (s.heading && !/thank/i.test(s.heading)) parts.push(s.heading);
      parts.push(...s.points, ...s.para);
    }
    const quoteLine = parts.find(isQuoted);
    const sub = subtitle || parts.find((p) => !isQuoted(p));
    return clean({ layout: "closing", title, subtitle: sub, body: quoteLine ? unquote(quoteLine) : undefined });
  }

  // Pure quote slide: the whole body is a single quoted line
  if (allPoints.length === 0 && headed.length === 0 && allPara.length === 1 && isQuoted(allPara[0])) {
    return clean({ layout: "quote", title, quote: unquote(allPara[0]) });
  }

  // 2–3 headed sections with bullets → comparison columns
  const columnar = headed.filter((s) => s.points.length > 0);
  if (columnar.length >= 2 && columnar.length <= 3 && columnar.length === headed.length) {
    return clean({
      layout: "comparison",
      title,
      subtitle: subtitle || undefined,
      columns: columnar.map((s) => ({ heading: s.heading!, points: s.points })),
    });
  }

  // >3 headed groups → compress each group into one bullet so nothing is lost
  if (headed.length > 3) {
    const bullets = headed.map((s) => (s.points.length ? `${s.heading}: ${s.points.join(", ")}` : s.heading!));
    return clean({ layout: "bullets", title, subtitle: subtitle || undefined, bullets, notes: bodyText || undefined });
  }

  // Plain bullet list (optionally with a lead paragraph as body/subtitle)
  if (allPoints.length) {
    const lead = allPara.length ? bodyText : undefined;
    return clean({ layout: "bullets", title, subtitle: subtitle || (lead && lead.length < 120 ? lead : undefined), bullets: allPoints, body: lead && lead.length >= 120 ? lead : undefined });
  }

  // No bullets — preserve the prose. Single short line → callout; otherwise each line a bullet.
  if (allPara.length === 1 && bodyText.length <= 140) {
    return clean({ layout: "callout", title, subtitle, callout: bodyText });
  }
  if (allPara.length >= 1) {
    return clean({ layout: "bullets", title, subtitle, bullets: allPara.slice(0, 12) });
  }
  return clean({ layout: "bullets", title, subtitle, body: title });
}

/** Deck title/subtitle from the front matter. */
function deckMeta(front: string[]): { title?: string; subtitle?: string } {
  let title: string | undefined;
  let subtitle: string | undefined;
  for (const line of front) {
    const h = line.match(ANY_HEAD);
    if (h) {
      const t = stripInline(h[2]).replace(/^(powerpoint|presentation)\s*[:\-–]\s*/i, "").trim();
      if (!title) title = t;
      else if (!subtitle) subtitle = t;
    }
  }
  return { title, subtitle };
}

/** Detect + parse a structured outline into a full deck, or return null. */
export function parseOutlineToDeck(text: string): AIDeck | null {
  if (!text || text.length < 60) return null;
  const seg = segment(text);
  if (!seg || seg.slides.length < 3) return null;

  const slides: AISlide[] = [];
  seg.slides.forEach((raw, i) => {
    try {
      slides.push(buildSlide(raw, i));
    } catch {
      // never let one odd slide break the whole outline
      slides.push(aiSlideSchema.parse({ layout: "bullets", title: raw.title || "Slide", body: raw.lines.join(" ").trim() || raw.title }));
    }
  });
  if (slides.length < 3) return null;

  const meta = deckMeta(seg.front);
  const title = meta.title || slides[0].title || "Presentation";
  return { title, subtitle: meta.subtitle, slides: slides.slice(0, 40) };
}
