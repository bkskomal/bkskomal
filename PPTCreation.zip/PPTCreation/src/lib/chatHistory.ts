import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface ChatMsg {
  role: "user" | "assistant";
  content: string;
  actions?: string[];
  thumbs?: string[]; // attachment previews (stripped when persisted)
  streaming?: boolean;
}

interface ChatHistoryState {
  byDeck: Record<string, ChatMsg[]>;
  get: (deckId: string) => ChatMsg[];
  set: (deckId: string, msgs: ChatMsg[]) => void;
  clear: (deckId: string) => void;
}

const CAP = 60; // keep the most recent messages per deck

/** Chat history persisted per deck, so a conversation survives reloads. */
export const useChatHistory = create<ChatHistoryState>()(
  persist(
    (set, getState) => ({
      byDeck: {},
      get: (deckId) => getState().byDeck[deckId] ?? [],
      set: (deckId, msgs) =>
        set((s) => ({ byDeck: { ...s.byDeck, [deckId]: msgs.slice(-CAP) } })),
      clear: (deckId) =>
        set((s) => {
          const next = { ...s.byDeck };
          delete next[deckId];
          return { byDeck: next };
        }),
    }),
    {
      name: "pptmaker-chat",
      // don't persist streaming flags or heavy attachment data URLs
      partialize: (state) => ({
        byDeck: Object.fromEntries(
          Object.entries(state.byDeck).map(([k, v]) => [
            k,
            v.map((m) => ({ ...m, thumbs: undefined, streaming: undefined })),
          ]),
        ),
      }),
    },
  ),
);
