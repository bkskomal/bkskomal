import { create } from "zustand";
import { persist } from "zustand/middleware";
import { newId } from "./layouts";

/** A configurable model endpoint (OpenAI-compatible). */
export interface ModelConfig {
  id: string;
  name: string;
  /** OpenAI-compatible base URL; empty = use the server's default (GPT-OSS). */
  baseUrl?: string;
  /** API key; empty = use the server default. Stored locally (demo). */
  apiKey?: string;
  model: string;
  builtIn?: boolean;
}

const DEFAULT: ModelConfig = { id: "gpt-oss", name: "GPT-OSS-120B", model: "openai/gpt-oss-120b", builtIn: true };

interface ModelState {
  models: ModelConfig[];
  activeId: string;
  active: () => ModelConfig;
  /** the override sent to the API for the active model (empty for the built-in default) */
  override: () => { baseUrl?: string; apiKey?: string; model?: string };
  setActive: (id: string) => void;
  add: (cfg: Omit<ModelConfig, "id">) => void;
  update: (id: string, patch: Partial<ModelConfig>) => void;
  remove: (id: string) => void;
  ensureSeed: () => void;
}

export const useModels = create<ModelState>()(
  persist(
    (set, get) => ({
      models: [DEFAULT],
      activeId: DEFAULT.id,
      active: () => get().models.find((m) => m.id === get().activeId) ?? DEFAULT,
      override: () => {
        const a = get().active();
        if (a.builtIn) return {}; // server uses its env config
        return { baseUrl: a.baseUrl || undefined, apiKey: a.apiKey || undefined, model: a.model || undefined };
      },
      setActive: (id) => set({ activeId: id }),
      add: (cfg) => set((s) => ({ models: [...s.models, { ...cfg, id: newId() }] })),
      update: (id, patch) =>
        set((s) => ({ models: s.models.map((m) => (m.id === id ? { ...m, ...patch } : m)) })),
      remove: (id) =>
        set((s) => {
          const models = s.models.filter((m) => m.id !== id);
          return { models, activeId: s.activeId === id ? models[0]?.id ?? DEFAULT.id : s.activeId };
        }),
      ensureSeed: () => {
        if (!get().models.some((m) => m.id === DEFAULT.id)) set((s) => ({ models: [DEFAULT, ...s.models] }));
      },
    }),
    { name: "oatigenie-models" },
  ),
);
