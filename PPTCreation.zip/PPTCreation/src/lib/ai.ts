import OpenAI from "openai";
import { AI_DECK_FORMAT_HINT, aiDeckSchema, aiSlideSchema, type AIDeck, type AISlide } from "./schema";
import { LAYOUT_IDS } from "./layouts";
import { parseOutlineToDeck } from "./outline";
import { buildAgentManifest } from "./capabilities";
import type { ChatAction } from "./chatActions";

// Dev-only: trust self-signed certs (e.g. internal OATI dev endpoints). The
// production-correct fix is to set NODE_EXTRA_CA_CERTS to your CA bundle.
if (process.env.AI_TLS_INSECURE === "true") {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
}

/**
 * Server-only. Talks to any OpenAI-compatible endpoint (vLLM, TGI, Ollama,
 * llama.cpp server, or a hosted gateway) serving GPT-OSS-120B.
 *
 * Configure via env:
 *   OPENAI_BASE_URL  e.g. http://localhost:8000/v1
 *   OPENAI_API_KEY   any non-empty string for local servers (e.g. "local")
 *   AI_MODEL         e.g. openai/gpt-oss-120b
 */
export interface ModelOverride {
  baseUrl?: string;
  apiKey?: string;
  model?: string;
}

function client(ov?: ModelOverride) {
  return new OpenAI({
    baseURL: ov?.baseUrl || process.env.OPENAI_BASE_URL || "http://localhost:8000/v1",
    apiKey: ov?.apiKey || process.env.OPENAI_API_KEY || "local",
  });
}

const MODEL = (ov?: ModelOverride) => ov?.model || process.env.AI_MODEL || "openai/gpt-oss-120b";

const SYSTEM = `You are the slide-writing engine inside PPTMaker, a world-class presentation tool.
You design clear, modern, persuasive decks. You do NOT lay out pixels — you choose a BLOCK for each
slide and fill its content; PPTMaker's design engine renders it beautifully and on-brand.

Block catalog (use the matching data field):
- cover: title slide. title, subtitle, kicker.
- sectionHeader: full-bleed divider. title, kicker.
- agenda: numbered outline. bullets (3-6 sections).
- bullets: key points. bullets (3-5).
- twoColumn: two simple lists. bullets (split automatically).
- comparison: side-by-side. columns: [{heading, points[]}] (2-3).
- statGrid: metric cards. stats: [{value, label}] (2-4).
- process: ordered steps. steps: [{title, description}] (3-5).
- timeline: milestones. timeline: [{label, title, description}] (3-5).
- team: people. team: [{name, role}] (2-6).
- chart: bar chart. chart: {unit?, data:[{label, value}]} (3-6 bars).
- callout: one bold highlighted statement. callout (string).
- quote: testimonial. quote + attribution.
- stat: one huge number. stat: {value, label}.
- imageRight / imageLeft: text + a visual panel. title, body, bullets.
- closing: thank-you / CTA. title, subtitle.

Allowed layout ids ONLY: ${LAYOUT_IDS.join(", ")}.

Rules:
- First slide is "cover"; last slide is "closing".
- VARY the blocks — a great deck mixes agenda, statGrid, process, comparison, timeline, chart, quote, etc. Do not just repeat "bullets".
- Choose the block that best fits the content (a single number -> stat; metrics -> statGrid; how-it-works -> process; options -> comparison; roadmap -> timeline).
- Keep titles punchy (max ~8 words). Bullets 3-5 items, each under ~12 words.
- Write concise speaker "notes" for each slide.
- Never invent fake statistics for real companies; keep placeholders generic if unsure.`;

export interface GenerateInput {
  prompt: string;
  slideCount?: number;
  audience?: string;
  tone?: string;
  /** raw slide-by-slide outline the user supplied — honoured 1:1 when it parses. */
  outline?: string;
}

export interface GenerateResult {
  deck: AIDeck;
  /** "outline" = honoured the user's outline 1:1; "ai" = composed by the model. */
  source: "outline" | "ai";
}

export async function generateDeck(input: GenerateInput, ov?: ModelOverride): Promise<GenerateResult> {
  // Fidelity path: if the user gave a structured, slide-by-slide outline, honour it
  // verbatim (deterministic — no model rewrite, no dropped slides) instead of a lossy brief.
  const outlineText = input.outline ?? input.prompt;
  const direct = parseOutlineToDeck(outlineText);
  if (direct && direct.slides.length >= 3) return { deck: direct, source: "outline" };

  const count = Math.min(Math.max(input.slideCount ?? 8, 3), 20);
  const user = `Create a ${count}-slide presentation.
Topic / brief: ${input.prompt}
${input.audience ? `Audience: ${input.audience}` : ""}
${input.tone ? `Tone: ${input.tone}` : ""}

${AI_DECK_FORMAT_HINT}`;

  const completion = await client(ov).chat.completions.create({
    model: MODEL(ov),
    temperature: 0.7,
    // scale the output budget to the deck size so large decks don't truncate mid-JSON
    max_tokens: Math.min(16000, 2000 + count * 700),
    messages: [
      { role: "system", content: SYSTEM },
      { role: "user", content: user },
    ],
    response_format: { type: "json_object" },
  });

  const raw = completion.choices[0]?.message?.content ?? "";
  return { deck: parseDeck(raw), source: "ai" };
}

export interface RegenerateInput {
  current: AISlide;
  deckTitle?: string;
  /** optional layout to force (for "change layout"); else the model may keep or improve it */
  layout?: string;
  /** optional freeform instruction, e.g. "make it punchier" */
  instruction?: string;
}

/** Regenerate a single slide's semantic content (optionally into a new layout). */
export async function regenerateSlide(input: RegenerateInput): Promise<AISlide> {
  const target = input.layout
    ? `Use the "${input.layout}" block and populate its matching data field.`
    : `Keep the same block ("${input.current.layout}") unless another fits much better.`;

  const user = `You are improving ONE slide of the deck${input.deckTitle ? ` "${input.deckTitle}"` : ""}.
${target}
${input.instruction ? `Instruction: ${input.instruction}` : "Rewrite the content to be sharper and more compelling; you may change the wording and supporting points."}

Current slide JSON:
${JSON.stringify(input.current)}

Allowed layout ids: ${LAYOUT_IDS.join(", ")}.
Return STRICT JSON for the single slide only (no "slides" wrapper), with "layout", "title", and the data field for that block.`;

  const completion = await client().chat.completions.create({
    model: MODEL(),
    temperature: 0.7,
    messages: [
      { role: "system", content: SYSTEM },
      { role: "user", content: user },
    ],
    response_format: { type: "json_object" },
  });

  const raw = completion.choices[0]?.message?.content ?? "";
  const parsed = aiSlideSchema.safeParse(extractJson(raw));
  if (!parsed.success) {
    throw new Error(`AI returned invalid slide JSON: ${parsed.error.issues.map((i) => i.message).join("; ")}`);
  }
  // if a layout was forced, honor it even if the model drifted
  return input.layout ? { ...parsed.data, layout: input.layout } : parsed.data;
}

export type AssistTask = "improve" | "shorten" | "expand" | "fix" | "notes";

export interface AssistInput {
  task: AssistTask;
  text?: string;
  items?: string[];
  /** surrounding slide context to ground "notes" and rewrites */
  context?: string;
}

const ASSIST_INSTRUCTIONS: Record<AssistTask, string> = {
  improve: "Rewrite to be clearer, punchier and more professional. Keep the same meaning and roughly the same length.",
  shorten: "Make it significantly more concise. Cut filler, keep the core message.",
  expand: "Expand with a little more useful detail, but stay concise and presentation-appropriate.",
  fix: "Fix grammar, spelling and punctuation. Do not change the meaning or tone.",
  notes: "Write concise, natural speaker notes (2-4 sentences) a presenter would say for this slide.",
};

/** Single-purpose text helper for inline AI actions. Returns {text} or {items}. */
export async function assistText(input: AssistInput): Promise<{ text?: string; items?: string[] }> {
  const isList = Array.isArray(input.items) && input.items.length > 0;
  const subject = isList ? input.items!.map((i) => `- ${i}`).join("\n") : input.text ?? "";

  const shape =
    input.task === "notes"
      ? `{"text": string}`
      : isList
        ? `{"items": string[]}`
        : `{"text": string}`;

  const user = `Task: ${ASSIST_INSTRUCTIONS[input.task]}
${input.context ? `Slide context: ${input.context}\n` : ""}Content:
${subject}

Return STRICT JSON only, no markdown, matching: ${shape}`;

  const completion = await client().chat.completions.create({
    model: MODEL(),
    temperature: 0.5,
    messages: [
      { role: "system", content: "You are a precise presentation copy editor. Return only valid JSON." },
      { role: "user", content: user },
    ],
    response_format: { type: "json_object" },
  });

  const raw = completion.choices[0]?.message?.content ?? "";
  const json = extractJson(raw) as { text?: string; items?: string[] };
  if (input.task === "notes") return { text: String(json.text ?? "").trim() };
  if (isList && Array.isArray(json.items)) return { items: json.items.map((s) => String(s)) };
  return { text: String(json.text ?? subject).trim() };
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface ChatTurnResult {
  reply: string;
  actions: ChatAction[];
  /** false when the agent intends to take further actions in a follow-up step */
  done: boolean;
}

const CHAT_SYSTEM = `You are PPTMaker's AI assistant. You help users BUILD and EDIT presentations by
conversing and by emitting ACTIONS that drive the app's real features. You are warm, concise, and proactive,
and you know the app's full capabilities listed below. Slide positions are 0-based "index".

${buildAgentManifest()}

An AISlide is: { layout, title, subtitle?, kicker?, bullets?, body?, quote?, attribution?, stat?, stats?, steps?, columns?, timeline?, team?, chart?, callout?, notes? }.
A good deck STARTS with a cover, ENDS with closing, and VARIES the blocks.

GROUNDING — the deck state below tells you which slide is CURRENT and which element is SELECTED:
- "this slide" / "the current slide" → use the index marked CURRENT.
- "this" / "the selected text" / "make it bigger/red/bold" → use style_element or set_element_text (they act on the SELECTED element). If nothing is selected, say so briefly instead of guessing.

Branding & resize intents → actions:
- "add the OATI logo" / "add our logo" → set_brand { patch: { logoPreset: "oati" } } (applies to ALL slides)
- "add a nice header and footer" → set_brand { patch: { showHeader: true, showFooter: true, headerStyle: "band", footerStyle: "band", footerText: <fitting confidential line> } }
- "make our brand color red" → set_brand { patch: { primaryColor: "#CC0000" } }
- "increase the logo size on all slides" / "bigger logo everywhere" → set_brand { patch: { logoScale: 1.5 } } (decrease → 0.7)
- "make the logo bigger on the first slide" → set_slide_logo_scale { index: 0, scale: 1.5 }
- "make the selected image/element bigger" → style_element { scale: 1.3 } (smaller → 0.75)
- "make the image on slide 3 bigger" → resize_element { index: 2, scale: 1.3 }
- "increase the font size of this slide" → scale_fonts { scope: "slide", factor: 1.2 } (decrease → 0.85)
- "increase the font size across all slides" → scale_fonts { scope: "all", factor: 1.2 }

MULTI-STEP: For big jobs (e.g. "tighten every slide", "rebrand the whole deck") do a FEW actions now and set "done": false;
you will be called again with the updated deck state to continue. Set "done": true once the request is fully satisfied.
Editing many slides one-at-a-time across steps is encouraged — it keeps each step focused.

ALWAYS reply with STRICT JSON (no markdown). Each action is a FLAT object with a "type" field, e.g.:
{ "reply": "Here's your deck!", "done": true, "actions": [
  { "type": "set_deck", "title": "BrewBox", "themeId": "paper", "slides": [ { "layout": "cover", "title": "BrewBox" } ] },
  { "type": "set_brand", "patch": { "logoPreset": "oati" } }
] }
"reply" is a short friendly message. If the user is just chatting/asking, return empty actions with done:true.
Never include actions the user didn't ask for. Allowed layouts: ${LAYOUT_IDS.join(", ")}.`;

/** One conversational turn. Returns a short reply + actions + whether it's done. */
export async function chatTurn(messages: ChatMessage[], deckSummary: string, ov?: ModelOverride): Promise<ChatTurnResult> {
  const sys = `${CHAT_SYSTEM}\n\nCurrent deck state:\n${deckSummary}`;
  const completion = await client(ov).chat.completions.create({
    model: MODEL(ov),
    temperature: 0.6,
    messages: [
      { role: "system", content: sys },
      ...messages.map((m) => ({ role: m.role, content: m.content })),
    ],
    response_format: { type: "json_object" },
  });
  return parseChatResult(completion.choices[0]?.message?.content ?? "");
}

function parseChatResult(raw: string): ChatTurnResult {
  const json = extractJson(raw) as { reply?: string; actions?: unknown[]; done?: boolean };
  const actions = Array.isArray(json.actions) ? json.actions.map(normalizeAction).filter(Boolean) : [];
  return {
    reply: String(json.reply ?? "Done.").trim(),
    actions: actions as ChatAction[],
    done: json.done !== false, // default to done unless explicitly false
  };
}

/**
 * Streaming variant. Streams ONLY the human-readable "reply" text (extracted
 * from the partial JSON server-side) via onReplyDelta, then returns the fully
 * parsed result (reply + actions + done) once the stream completes.
 */
export async function chatTurnStream(
  messages: ChatMessage[],
  deckSummary: string,
  onReplyDelta: (text: string) => void,
  ov?: ModelOverride,
): Promise<ChatTurnResult> {
  const sys = `${CHAT_SYSTEM}\n\nCurrent deck state:\n${deckSummary}\n\nIMPORTANT: put "reply" FIRST in your JSON so the user sees it stream immediately.`;
  const stream = await client(ov).chat.completions.create({
    model: MODEL(ov),
    temperature: 0.6,
    messages: [
      { role: "system", content: sys },
      ...messages.map((m) => ({ role: m.role, content: m.content })),
    ],
    response_format: { type: "json_object" },
    stream: true,
  });

  let raw = "";
  let sentLen = 0;
  for await (const chunk of stream) {
    const delta = chunk.choices[0]?.delta?.content ?? "";
    if (!delta) continue;
    raw += delta;
    const reply = extractPartialReply(raw);
    if (reply.length > sentLen) {
      onReplyDelta(reply.slice(sentLen));
      sentLen = reply.length;
    }
  }
  return parseChatResult(raw);
}

/** Explain a file diff in business terms (context-aware summary). */
export async function summarizeChanges(diff: string, ov?: ModelOverride): Promise<string> {
  const completion = await client(ov).chat.completions.create({
    model: MODEL(ov),
    temperature: 0.4,
    messages: [
      {
        role: "system",
        content:
          "You explain data/document changes to a business audience. Given a diff, understand what the data represents and write a SHORT markdown summary (3-6 bullets): the most important changes and why they might matter. Be specific, cite values, do not invent data. End with a one-line 'Bottom line:'.",
      },
      { role: "user", content: diff.slice(0, 12000) },
    ],
  });
  return completion.choices[0]?.message?.content ?? "";
}

// ---------------------------------------------------------------- general assistant (multi-skill)
export interface AssistantResult {
  reply: string;
  /** a skill to launch, decided by the assistant */
  open?: { skill: "ppt" | "compare"; brief?: string; slideCount?: number };
}

const ASSISTANT_SYSTEM = `You are a helpful, friendly AI assistant with SKILLS. Answer in concise markdown.

SKILL "ppt" — create a PowerPoint presentation. If the user asks to create / make / build / generate /
design a presentation, deck, slides, pitch, or similar, set "open" to
{ "skill":"ppt", "brief": <the content brief>, "slideCount": <number if they gave one> }
and in "reply" say you're opening the presentation creator.
IMPORTANT: if the user has provided a detailed outline or slide-by-slide content ANYWHERE in the
conversation, copy that outline into "brief" FAITHFULLY AND IN FULL — preserve every slide, title,
bullet and note. Do NOT summarise, shorten, or drop slides. Fidelity to the user's content matters more
than brevity. Only write a short brief of your own when the user gave just a topic.

SKILL "compare" — compare two files (Excel / CSV). If the user asks to compare / diff two files,
spreadsheets, or Excel sheets, set "open" to { "skill":"compare" } and in "reply" say you're opening the
Compare Files tool where they can drop the two files.

Otherwise just help normally and omit "open".

ALWAYS return STRICT JSON (no markdown fences): { "reply": string, "open"?: { "skill":"ppt"|"compare", "brief"?: string, "slideCount"?: number } }.
Put "reply" FIRST so it streams to the user immediately.`;

function parseAssistant(raw: string): AssistantResult {
  const json = extractJson(raw) as { reply?: string; open?: AssistantResult["open"] };
  const open = json.open && (json.open.skill === "ppt" || json.open.skill === "compare") ? json.open : undefined;
  return { reply: String(json.reply ?? "").trim() || "…", open };
}

/** Non-streaming assistant reply — used by the eval harness to replay a prompt. */
export async function assistantOnce(prompt: string, ov?: ModelOverride): Promise<string> {
  const completion = await client(ov).chat.completions.create({
    model: MODEL(ov),
    temperature: 0.6,
    messages: [{ role: "system", content: ASSISTANT_SYSTEM }, { role: "user", content: prompt }],
    response_format: { type: "json_object" },
  });
  return parseAssistant(completion.choices[0]?.message?.content ?? "").reply;
}

export interface Judgement {
  score: number; // 0-100
  pass: boolean;
  reason: string;
}

/**
 * LLM-as-judge: score an assistant answer for a prompt (optionally vs a reference).
 * Far better than lexical overlap for open-ended replies. pass = score >= 70.
 */
export async function judgeAnswer(input: { prompt: string; answer: string; reference?: string }, ov?: ModelOverride): Promise<Judgement> {
  const sys =
    "You are a strict but fair evaluator of an AI presentation assistant. Score the ANSWER for the PROMPT on: " +
    "relevance, correctness, completeness, and usefulness; if a REFERENCE is given, also judge alignment to it. " +
    'Return STRICT JSON only: {"score": <0-100 integer>, "pass": <boolean>, "reason": "<one sentence>"}. pass = score >= 70.';
  const user = `PROMPT:\n${input.prompt}\n\nANSWER:\n${input.answer || "(empty)"}\n${input.reference ? `\nREFERENCE (ideal answer):\n${input.reference}\n` : ""}`;
  try {
    const completion = await client(ov).chat.completions.create({
      model: MODEL(ov),
      temperature: 0.1,
      messages: [{ role: "system", content: sys }, { role: "user", content: user.slice(0, 8000) }],
      response_format: { type: "json_object" },
    });
    const j = extractJson(completion.choices[0]?.message?.content ?? "") as Partial<Judgement>;
    const score = Math.max(0, Math.min(100, Math.round(Number(j.score) || 0)));
    return { score, pass: typeof j.pass === "boolean" ? j.pass : score >= 70, reason: String(j.reason ?? "").slice(0, 300) };
  } catch (e) {
    return { score: 0, pass: false, reason: `judge error: ${e instanceof Error ? e.message : "unknown"}` };
  }
}

/** Streaming general assistant turn. Streams the reply; returns {reply, open}. */
export async function assistantStream(
  messages: ChatMessage[],
  onReplyDelta: (text: string) => void,
  ov?: ModelOverride,
  augment?: string,
): Promise<AssistantResult> {
  const stream = await client(ov).chat.completions.create({
    model: MODEL(ov),
    temperature: 0.6,
    // headroom so a faithful, full-outline brief isn't truncated mid-JSON
    max_tokens: 8000,
    messages: [{ role: "system", content: ASSISTANT_SYSTEM + (augment ?? "") }, ...messages.map((m) => ({ role: m.role, content: m.content }))],
    response_format: { type: "json_object" },
    stream: true,
  });
  let raw = "";
  let sentLen = 0;
  for await (const chunk of stream) {
    const delta = chunk.choices[0]?.delta?.content ?? "";
    if (!delta) continue;
    raw += delta;
    const reply = extractPartialReply(raw);
    if (reply.length > sentLen) {
      onReplyDelta(reply.slice(sentLen));
      sentLen = reply.length;
    }
  }
  return parseAssistant(raw);
}

/** Pull the (possibly incomplete) "reply" string value out of streaming JSON. */
function extractPartialReply(raw: string): string {
  const key = raw.indexOf('"reply"');
  if (key < 0) return "";
  const colon = raw.indexOf(":", key + 7);
  if (colon < 0) return "";
  const open = raw.indexOf('"', colon + 1);
  if (open < 0) return "";
  const esc: Record<string, string> = { n: "\n", t: "\t", r: "\r", '"': '"', "\\": "\\", "/": "/" };
  let out = "";
  for (let j = open + 1; j < raw.length; j++) {
    const c = raw[j];
    if (c === "\\") {
      const n = raw[j + 1];
      if (n === undefined) break;
      out += esc[n] ?? n;
      j++;
      continue;
    }
    if (c === '"') break;
    out += c;
  }
  return out;
}

/** Tolerate the model nesting actions as {"set_deck": {...}} instead of {"type":"set_deck", ...}. */
function normalizeAction(a: unknown): ChatAction | null {
  if (!a || typeof a !== "object") return null;
  const obj = a as Record<string, unknown>;
  if (typeof obj.type === "string") return obj as ChatAction;
  const keys = Object.keys(obj);
  if (keys.length === 1 && obj[keys[0]] && typeof obj[keys[0]] === "object") {
    return { type: keys[0], ...(obj[keys[0]] as object) } as ChatAction;
  }
  return null;
}

const str = (v: unknown): string => (typeof v === "string" ? v : v == null ? "" : String(v));
const LAYOUT_SET = new Set(LAYOUT_IDS);

/** Unwrap the many shapes models return into { title?, subtitle?, slides: unknown[] }. */
function unwrapDeck(json: unknown): { title?: unknown; subtitle?: unknown; slides: unknown[] } {
  if (Array.isArray(json)) return { slides: json };
  if (json && typeof json === "object") {
    const o = json as Record<string, unknown>;
    if (Array.isArray(o.slides)) return { title: o.title, subtitle: o.subtitle, slides: o.slides };
    // common wrapper keys
    for (const k of ["deck", "presentation", "result", "data", "output"]) {
      if (o[k] && typeof o[k] === "object") {
        const inner = unwrapDeck(o[k]);
        if (inner.slides.length) return inner;
      }
    }
    // any array-of-objects property → treat as slides
    for (const v of Object.values(o)) {
      if (Array.isArray(v) && v.some((x) => x && typeof x === "object")) return { title: o.title, subtitle: o.subtitle, slides: v };
    }
    // a single slide object
    if (o.layout || o.title || o.bullets || o.body) return { slides: [o] };
  }
  return { slides: [] };
}

/** Infer a sensible layout id from whichever content fields a slide carries. */
function inferLayout(o: Record<string, unknown>): string {
  const has = (k: string) => o[k] != null && (!Array.isArray(o[k]) || (o[k] as unknown[]).length > 0);
  if (has("quote") || has("attribution")) return "quote";
  if (has("kpis")) return "kpiDashboard";
  if (has("stats")) return "statGrid";
  if (has("stat")) return "stat";
  if (has("gantt")) return "gantt";
  if (has("chart")) return "chart";
  if (has("steps")) return "process";
  if (has("columns")) return "comparison";
  if (has("timeline")) return "timeline";
  if (has("org")) return "orgChart";
  if (has("team")) return "team";
  if (has("funnel")) return "funnel";
  if (has("pyramid")) return "pyramid";
  if (has("callout") && !has("bullets") && !has("body")) return "callout";
  if (has("bullets")) return "bullets";
  return "bullets";
}

/** Coerce a loose slide object into schema shape (guarantee layout + title; fix common type slips). */
function coerceSlide(raw: unknown): AISlide | null {
  if (!raw || typeof raw !== "object") return null;
  const o: Record<string, unknown> = { ...(raw as Record<string, unknown>) };

  // bullets given as a single string → split into lines
  if (typeof o.bullets === "string") o.bullets = (o.bullets as string).split(/\r?\n|•/).map((s) => s.trim()).filter(Boolean);
  // chart / gantt / org numeric fields sometimes arrive as strings
  const num = (v: unknown) => (typeof v === "number" ? v : Number(String(v).replace(/[^0-9.-]/g, "")) || 0);
  if (o.chart && typeof o.chart === "object" && Array.isArray((o.chart as Record<string, unknown>).data))
    (o.chart as { data: { value: unknown }[] }).data.forEach((d) => (d.value = num(d.value)));
  if (o.gantt && typeof o.gantt === "object" && Array.isArray((o.gantt as Record<string, unknown>).tasks))
    (o.gantt as { tasks: { start: unknown; end: unknown }[] }).tasks.forEach((t) => { t.start = num(t.start); t.end = num(t.end); });
  if (Array.isArray(o.org)) (o.org as { level: unknown }[]).forEach((n) => (n.level = num(n.level)));

  // guarantee layout
  if (typeof o.layout !== "string" || !LAYOUT_SET.has(o.layout as string)) o.layout = inferLayout(o);
  // guarantee title
  if (typeof o.title !== "string" || !o.title.trim()) {
    o.title =
      str(o.subtitle).trim() ||
      str(o.kicker).trim() ||
      str(o.callout).trim() ||
      (Array.isArray(o.bullets) && o.bullets.length ? str((o.bullets as unknown[])[0]) : "") ||
      str(o.body).slice(0, 60).trim() ||
      "Slide";
  }

  const parsed = aiSlideSchema.safeParse(o);
  if (parsed.success) return parsed.data;
  // last resort: keep the slide as a simple bullets/body slide so it still renders
  const safe = aiSlideSchema.safeParse({
    layout: "bullets",
    title: str(o.title) || "Slide",
    subtitle: typeof o.subtitle === "string" ? o.subtitle : undefined,
    bullets: Array.isArray(o.bullets) ? (o.bullets as unknown[]).map(str).filter(Boolean).slice(0, 6) : undefined,
    body: typeof o.body === "string" ? o.body : undefined,
    notes: typeof o.notes === "string" ? o.notes : undefined,
  });
  return safe.success ? safe.data : null;
}

/**
 * Robustly extract + validate the deck JSON the model returned. Never rejects a whole
 * deck for one malformed slide — it unwraps odd shapes, repairs missing layout/title,
 * and salvages every slide it can, so decisions-grade output always renders.
 */
export function parseDeck(raw: string): AIDeck {
  const json = extractJson(raw);
  const obj = unwrapDeck(json);
  const slides = obj.slides.map(coerceSlide).filter((s): s is AISlide => s !== null).slice(0, 40);
  if (!slides.length) {
    const peek = JSON.stringify(json).slice(0, 200);
    throw new Error(`AI returned no usable slides. Output began: ${peek}`);
  }
  const title = str(obj.title).trim() || slides[0].title || "Presentation";
  const subtitle = str(obj.subtitle).trim() || undefined;
  return { title, subtitle, slides };
}

function extractJson(raw: string): unknown {
  const trimmed = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    // grab the outermost {...}
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(trimmed.slice(start, end + 1));
    }
    throw new Error("Could not parse JSON from model output.");
  }
}
