import { newId } from "./layouts";
import { useAdminConfig } from "./adminConfig";
import { useEditor } from "./store";
import { CANVAS } from "./utils";
import type { Deck, ImageElement } from "./types";

/**
 * Auto-imagery: fill the image panel on imageLeft/imageRight slides with a
 * RELEVANT stock photo (query = the slide's title). Runs progressively in the
 * background after a deck opens, so the deck shows instantly and images pop in.
 *
 * Only runs when a query-based provider (Unsplash/Pexels) is configured — the
 * keyless Picsum default returns random images, so we keep the on-brand gradient
 * instead of degrading the design with an irrelevant photo.
 */
const REGION = {
  imageRight: { x: CANVAS.w - 520, y: 0, w: 520, h: CANVAS.h },
  imageLeft: { x: 0, y: 0, w: 520, h: CANVAS.h },
} as const;

export function enrichDeckImagery(deck: Deck): void {
  const cfg = useAdminConfig.getState().imageOverride();
  if (cfg.provider === "picsum" || !cfg.apiKey) return; // only when relevant search is available

  for (const slide of deck.slides) {
    const region = REGION[slide.layout as keyof typeof REGION];
    if (!region) continue;
    if (slide.elements.some((e) => e.type === "image")) continue;
    const query = slide.source?.title?.trim();
    if (!query) continue;
    void placeImage(slide.id, query, region, cfg);
  }
}

async function placeImage(
  slideId: string,
  query: string,
  region: { x: number; y: number; w: number; h: number },
  cfg: { provider: string; apiKey?: string },
): Promise<void> {
  try {
    const r = await fetch("/api/images/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, provider: cfg.provider, apiKey: cfg.apiKey, count: 1 }),
    }).then((x) => x.json());
    const url = r.images?.[0]?.url as string | undefined;
    if (!url) return;

    // re-read the slide (user may have edited) and only add if still no image
    const slide = useEditor.getState().deck?.slides.find((s) => s.id === slideId);
    if (!slide || slide.elements.some((e) => e.type === "image")) return;
    const img: ImageElement = { id: newId(), type: "image", src: url, fit: "cover", ...region, z: 1 };
    // place just above the gradient panel (which sits at z 0), under the text
    useEditor.getState().setSlideElements(slideId, [...slide.elements, img]);
  } catch {
    /* best-effort — a missing image just leaves the gradient panel */
  }
}
