import { buildSlide, rebuildSlide } from "./layouts";
import { deckFromAI } from "./deck";
import { makeChart, makeImage } from "./elements";
import { INSERT_ITEMS } from "./inserts";
import { useAdminConfig } from "./adminConfig";
import { useOrg } from "./org";
import { repairSlide } from "./lint";
import type { ChartKind } from "./types";
import { THEMES } from "./themes";
import { DEFAULT_STYLE } from "./styles";
import { clampToCanvas, placeClear } from "./geometry";
import { useEditor, clearHistory } from "./store";
import type { AISlide } from "./schema";
import type { BrandKit, SlideBackground, SlideElement } from "./types";

/** An image the user attached in chat, resolvable by index in place_attachment. */
export interface ChatAttachment {
  id: string;
  name: string;
  type: string;
  dataUrl: string;
}

/**
 * The verbs the chat agent can perform — each maps onto the editor store. The
 * model returns a list of these; the client executes them. This is how "chat to
 * build a deck" drives the real PPTMaker features (blocks, themes, brand).
 * Slide positions are 0-based `index`.
 */
export type ChatAction =
  | { type: "set_deck"; title?: string; themeId?: string; slides: AISlide[] }
  | { type: "add_slides"; slides: AISlide[]; afterIndex?: number }
  | { type: "edit_slide"; index: number; slide: AISlide }
  | { type: "delete_slide"; index: number }
  | { type: "duplicate_slide"; index: number }
  | { type: "move_slide"; from: number; to: number }
  | { type: "reorder_slides"; order: number[] }
  | { type: "set_slide_background"; index: number; background: SlideBackground }
  | { type: "set_theme"; themeId: string }
  | { type: "set_brand"; patch: Partial<BrandKit> & { logoPreset?: string; brandPreset?: string } }
  | { type: "set_title"; title: string }
  | { type: "auto_brand"; mode?: "light" | "dark" }
  | { type: "set_slide_logo_scale"; index: number; scale: number }
  | { type: "scale_fonts"; scope: "slide" | "all"; index?: number; factor: number }
  | { type: "resize_element"; index: number; target?: "image" | "largest"; scale?: number; w?: number; h?: number }
  | { type: "style_element"; patch: Partial<SlideElement>; scale?: number }
  | { type: "set_element_text"; text: string }
  | { type: "add_resource"; itemId: string; slideIndex?: number }
  | { type: "add_image"; query: string; slideIndex?: number }
  | { type: "generate_image"; prompt: string; slideIndex?: number }
  | { type: "add_chart"; chartType?: ChartKind; categories?: string[]; series?: { name: string; data: number[] }[]; unit?: string; slideIndex?: number }
  | { type: "cleanup"; slideIndex?: number }
  | { type: "place_attachment"; index: number; as: "image" | "logo"; slideIndex?: number };

/** Bundled logos the agent can apply by name (e.g. "add the OATI logo"). */
const LOGO_PRESETS: Record<string, string> = {
  oati: "/oati-logo.png",
};

/** Insert an image URL onto a slide, nudged clear of existing content. Returns the slide index. */
function placeImageOnSlide(s: ReturnType<typeof useEditor.getState>, slideIndex: number | undefined, src: string): number {
  if (!s.deck) throw new Error("no deck");
  const idx = slideIndex ?? s.deck.slides.findIndex((x) => x.id === s.currentSlideId);
  const i = idx >= 0 ? idx : 0;
  const slide = s.deck.slides[i];
  if (!slide) throw new Error("no target slide");
  const img = makeImage(src);
  const obstacles = slide.elements
    .filter((e) => !e.brand && !e.dataViz && (e.type === "text" || e.type === "shape"))
    .map((e) => ({ x: e.x, y: e.y, w: e.w, h: e.h }));
  const placed = placeClear({ x: img.x, y: img.y, w: img.w, h: img.h }, obstacles);
  s.addElement(slide.id, { ...img, ...placed });
  s.setCurrentSlide(slide.id);
  return i;
}

/** Apply a list of actions to the editor store; returns human-readable summaries. */
export async function applyChatActions(
  actions: ChatAction[],
  attachments: ChatAttachment[] = [],
): Promise<string[]> {
  const done: string[] = [];
  for (const a of actions) {
    try {
      done.push(await applyOne(a, attachments));
    } catch (e) {
      done.push(`⚠️ Couldn't apply ${a.type}: ${e instanceof Error ? e.message : "error"}`);
    }
  }
  return done;
}

async function applyOne(a: ChatAction, attachments: ChatAttachment[]): Promise<string> {
  const s = useEditor.getState();

  switch (a.type) {
    case "set_deck": {
      const built = deckFromAI({ title: a.title ?? "Untitled", slides: a.slides });
      const cur = s.deck;
      built.theme = a.themeId && THEMES[a.themeId] ? THEMES[a.themeId] : cur?.theme ?? built.theme;
      if (cur) built.brand = cur.brand;
      s.setDeck(built);
      clearHistory();
      return `Created a ${a.slides.length}-slide deck${a.title ? ` “${a.title}”` : ""}.`;
    }
    case "add_slides": {
      if (!s.deck) throw new Error("no deck");
      const afterId =
        a.afterIndex != null ? s.deck.slides[a.afterIndex]?.id : s.currentSlideId ?? undefined;
      let prev = afterId;
      const style = s.deck.style ?? DEFAULT_STYLE;
      a.slides.forEach((ai) => {
        const slide = buildSlide(ai, style);
        useEditor.getState().addSlide(slide, prev);
        prev = slide.id;
      });
      return `Added ${a.slides.length} slide${a.slides.length > 1 ? "s" : ""}.`;
    }
    case "edit_slide": {
      if (!s.deck) throw new Error("no deck");
      const target = s.deck.slides[a.index];
      if (!target) throw new Error(`no slide #${a.index}`);
      // MERGE the provided fields onto the existing semantic source so the model
      // can send only what changes (e.g. just {title}) without wiping content.
      const base = target.source ?? { layout: target.layout, title: "" };
      const merged = { ...base, ...a.slide };
      s.setSlide(target.id, rebuildSlide(merged, target.id, target.notes, s.deck.style ?? DEFAULT_STYLE));
      s.setCurrentSlide(target.id); // jump to the changed slide
      return `Updated slide ${a.index + 1}.`;
    }
    case "delete_slide": {
      if (!s.deck) throw new Error("no deck");
      const target = s.deck.slides[a.index];
      if (!target) throw new Error(`no slide #${a.index}`);
      s.deleteSlide(target.id);
      return `Deleted slide ${a.index + 1}.`;
    }
    case "duplicate_slide": {
      if (!s.deck) throw new Error("no deck");
      const target = s.deck.slides[a.index];
      if (!target) throw new Error(`no slide #${a.index}`);
      s.duplicateSlide(target.id);
      return `Duplicated slide ${a.index + 1}.`;
    }
    case "move_slide": {
      if (!s.deck) throw new Error("no deck");
      const target = s.deck.slides[a.from];
      if (!target) throw new Error(`no slide #${a.from}`);
      s.moveSlide(target.id, a.to);
      return `Moved slide ${a.from + 1} to position ${a.to + 1}.`;
    }
    case "reorder_slides": {
      if (!s.deck) throw new Error("no deck");
      const slides = a.order.map((i) => s.deck!.slides[i]).filter(Boolean);
      if (slides.length !== s.deck.slides.length) throw new Error("order must include every slide once");
      s.setDeck({ ...s.deck, slides });
      return `Reordered slides.`;
    }
    case "set_slide_background": {
      if (!s.deck) throw new Error("no deck");
      const target = s.deck.slides[a.index];
      if (!target) throw new Error(`no slide #${a.index}`);
      s.setSlide(target.id, { ...target, background: a.background });
      s.setCurrentSlide(target.id);
      return `Updated slide ${a.index + 1} background.`;
    }
    case "scale_fonts": {
      if (!s.deck) throw new Error("no deck");
      const factor = a.factor || 1.2;
      const clamp = (n: number) => Math.max(8, Math.min(240, Math.round(n)));
      const scaleSlide = (sl: (typeof s.deck.slides)[number]) => ({
        ...sl,
        elements: sl.elements.map((e) =>
          e.type === "text" && e.fontSize ? { ...e, fontSize: clamp(e.fontSize * factor) } : e,
        ),
      });
      if (a.scope === "all") {
        s.setDeck({ ...s.deck, slides: s.deck.slides.map(scaleSlide) });
        return `${factor >= 1 ? "Increased" : "Decreased"} font size across all slides.`;
      }
      const idx = a.index ?? s.deck.slides.findIndex((x) => x.id === s.currentSlideId);
      const target = s.deck.slides[idx];
      if (!target) throw new Error("no target slide");
      s.setSlide(target.id, scaleSlide(target));
      s.setCurrentSlide(target.id);
      return `${factor >= 1 ? "Increased" : "Decreased"} font size on slide ${idx + 1}.`;
    }
    case "set_slide_logo_scale": {
      if (!s.deck) throw new Error("no deck");
      const t = s.deck.slides[a.index];
      if (!t) throw new Error(`no slide #${a.index}`);
      const scale = Math.max(0.3, Math.min(3, a.scale));
      s.setSlide(t.id, { ...t, logoScale: scale });
      s.setCurrentSlide(t.id);
      return `Set the logo size on slide ${a.index + 1} to ${scale}×.`;
    }
    case "resize_element": {
      if (!s.deck) throw new Error("no deck");
      const sl = s.deck.slides[a.index];
      if (!sl) throw new Error(`no slide #${a.index}`);
      const imgs = sl.elements.filter((e) => e.type === "image");
      if (!imgs.length) throw new Error(`no image on slide ${a.index + 1}`);
      const target = a.target === "largest" ? imgs.reduce((p, c) => (c.w * c.h > p.w * p.h ? c : p)) : imgs[0];
      const sized = a.scale
        ? scalePatch(target, a.scale)
        : { x: target.x, y: target.y, w: a.w ?? target.w, h: a.h ?? target.h };
      // keep it on-canvas and out of the slide's text so it never clips/overlaps
      const obstacles = sl.elements
        .filter((e) => e.id !== target.id && !e.brand && !e.dataViz && (e.type === "text" || e.type === "shape"))
        .map((e) => ({ x: e.x, y: e.y, w: e.w, h: e.h }));
      const placed = placeClear({ x: sized.x, y: sized.y, w: sized.w, h: sized.h }, obstacles);
      s.updateElement(sl.id, target.id, placed);
      s.setCurrentSlide(sl.id);
      return `Resized and repositioned an image on slide ${a.index + 1} so it stays clear of other content.`;
    }
    case "style_element": {
      if (!s.currentSlideId || !s.selectedElementId) throw new Error("no element is selected");
      let patch: Partial<SlideElement> = { ...a.patch };
      if (a.scale) {
        const sl = s.deck?.slides.find((x) => x.id === s.currentSlideId);
        const el = sl?.elements.find((e) => e.id === s.selectedElementId);
        if (el) {
          const scaled = scalePatch(el, a.scale);
          patch = { ...patch, ...clampToCanvas(scaled) }; // keep it on the slide
        }
      }
      s.updateElement(s.currentSlideId, s.selectedElementId, patch);
      return `Restyled the selected element.`;
    }
    case "set_element_text": {
      if (!s.currentSlideId || !s.selectedElementId) throw new Error("no element is selected");
      s.updateElement(s.currentSlideId, s.selectedElementId, { text: a.text } as Partial<SlideElement>);
      return `Updated the selected text.`;
    }
    case "place_attachment": {
      if (!s.deck) throw new Error("no deck");
      const att = attachments[a.index];
      if (!att) throw new Error(`no attachment #${a.index}`);
      if (a.as === "logo") {
        s.updateBrand({ logoUrl: att.dataUrl });
        return `Set the attached image as the logo on every slide.`;
      }
      const idx = a.slideIndex ?? s.deck.slides.findIndex((x) => x.id === s.currentSlideId);
      const slide = s.deck.slides[idx];
      if (!slide) throw new Error("no target slide");
      const img = makeImage(att.dataUrl);
      const obstacles = slide.elements
        .filter((e) => !e.brand && !e.dataViz && (e.type === "text" || e.type === "shape"))
        .map((e) => ({ x: e.x, y: e.y, w: e.w, h: e.h }));
      const placed = placeClear({ x: img.x, y: img.y, w: img.w, h: img.h }, obstacles);
      s.addElement(slide.id, { ...img, ...placed });
      s.setCurrentSlide(slide.id);
      return `Added the attached image to slide ${idx + 1}.`;
    }
    case "set_theme": {
      if (!s.deck) throw new Error("no deck");
      const theme = THEMES[a.themeId];
      if (!theme) throw new Error(`unknown theme ${a.themeId}`);
      s.setDeck({ ...s.deck, theme });
      return `Applied the ${theme.name} theme.`;
    }
    case "set_brand": {
      const { logoPreset, brandPreset, ...patch } = a.patch;
      const finalPatch: Partial<BrandKit> = { ...patch };
      if (finalPatch.logoScale != null) finalPatch.logoScale = Math.max(0.3, Math.min(3, finalPatch.logoScale));
      let note = "";
      // one-shot brand DESIGN preset — applies the layout; all text stays dynamic
      if (brandPreset === "oati") {
        finalPatch.logoUrl = await toDataUrl(LOGO_PRESETS.oati);
        finalPatch.showHeader = true;
        finalPatch.headerPreset = "banner";
        if (finalPatch.headerText == null && s.deck) finalPatch.headerText = s.deck.title;
        finalPatch.showFooter = true;
        finalPatch.footerPreset = "band";
        if (finalPatch.footerText == null) finalPatch.footerText = "PROPRIETARY AND CONFIDENTIAL";
        finalPatch.showPageNumbers = true;
        finalPatch.logoScale = finalPatch.logoScale ?? 1.1;
        // apply the navy/red house style unless the user already chose a matching light/dark theme
        if (s.deck && s.deck.theme.id !== "boardroom" && s.deck.theme.id !== "executive") {
          s.setDeck({ ...s.deck, theme: THEMES.boardroom });
        }
        note = " Applied the OATI brand design — banner header, footer & house style (content stays yours).";
      } else if (brandPreset) {
        // a saved org brand preset (by id or name)
        const saved = useOrg.getState().org.brandPresets?.find((p) => p.id === brandPreset || p.name.toLowerCase() === brandPreset.toLowerCase());
        if (saved) {
          Object.assign(finalPatch, saved.brand);
          if (saved.themeId && THEMES[saved.themeId] && s.deck) s.setDeck({ ...s.deck, theme: THEMES[saved.themeId] });
          note = ` Applied the "${saved.name}" brand preset.`;
        }
      }
      if (logoPreset && LOGO_PRESETS[logoPreset]) {
        finalPatch.logoUrl = await toDataUrl(LOGO_PRESETS[logoPreset]);
        note += ` ${logoPreset.toUpperCase()} logo added to every slide.`;
      }
      s.updateBrand(finalPatch);
      return `Updated branding.${note}`.trim();
    }
    case "add_image": {
      if (!s.deck) throw new Error("no deck");
      const cfg = useAdminConfig.getState().imageOverride();
      const r = await fetch("/api/images/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: a.query, provider: cfg.provider, apiKey: cfg.apiKey, count: 1 }),
      }).then((x) => x.json());
      if (!r.images?.length) throw new Error(r.hint ?? r.error ?? "no images found");
      const idx = placeImageOnSlide(s, a.slideIndex, r.images[0].url);
      return `Added a “${a.query}” image to slide ${idx + 1}.`;
    }
    case "generate_image": {
      if (!s.deck) throw new Error("no deck");
      const cfg = useAdminConfig.getState().imageOverride();
      const r = await fetch("/api/images/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: a.prompt, baseUrl: cfg.genBaseUrl, model: cfg.genModel, apiKey: cfg.genApiKey }),
      }).then((x) => x.json());
      if (!r.url) throw new Error(r.hint ?? r.error ?? "generation failed");
      const idx = placeImageOnSlide(s, a.slideIndex, r.url);
      return `Generated an image for “${a.prompt}” and added it to slide ${idx + 1}.`;
    }
    case "cleanup": {
      if (!s.deck) throw new Error("no deck");
      const idx = a.slideIndex ?? s.deck.slides.findIndex((x) => x.id === s.currentSlideId);
      const i = idx >= 0 ? idx : 0;
      const slide = s.deck.slides[i];
      if (!slide) throw new Error("no target slide");
      const els = slide.elements.map((e) => ({ ...e }));
      const n = repairSlide(els, { clampOffCanvas: true, fixContrast: true, fixOverlap: true });
      if (n) s.setDeck({ ...s.deck, slides: s.deck.slides.map((sl, k) => (k === i ? { ...sl, elements: els } : sl)) });
      return n ? `Cleaned up slide ${i + 1} — ${n} fix${n === 1 ? "" : "es"} (off-canvas / contrast / overlap).` : `Slide ${i + 1} already looks clean.`;
    }
    case "add_chart": {
      if (!s.deck) throw new Error("no deck");
      const idx = a.slideIndex ?? s.deck.slides.findIndex((x) => x.id === s.currentSlideId);
      const i = idx >= 0 ? idx : 0;
      const slide = s.deck.slides[i];
      if (!slide) throw new Error("no target slide");
      const chart = makeChart(a.chartType ?? "column");
      if (a.categories?.length) chart.categories = a.categories;
      if (a.series?.length) chart.series = a.series;
      if (a.unit) chart.unit = a.unit;
      chart.legend = (a.series?.length ?? 1) > 1;
      s.addElement(slide.id, chart);
      s.setCurrentSlide(slide.id);
      return `Added a ${chart.chartType} chart to slide ${i + 1}.`;
    }
    case "add_resource": {
      if (!s.deck) throw new Error("no deck");
      const item = INSERT_ITEMS.find((it) => it.id === a.itemId);
      if (!item) throw new Error(`unknown resource "${a.itemId}"`);
      const slideId = a.slideIndex != null ? s.deck.slides[a.slideIndex]?.id : s.currentSlideId ?? s.deck.slides[0]?.id;
      if (!slideId) throw new Error("no target slide");
      const idx = s.deck.slides.findIndex((sl) => sl.id === slideId);
      s.setCurrentSlide(slideId);
      s.addElements(slideId, item.make());
      return `Added the ${item.label} ${item.category} to slide ${idx + 1}.`;
    }
    case "set_title": {
      s.setTitle(a.title);
      return `Renamed the deck to “${a.title}”.`;
    }
    case "auto_brand": {
      if (!s.deck) throw new Error("no deck");
      const logo = s.deck.brand.logoUrl;
      if (!logo) throw new Error("no logo set — add a logo first");
      const { extractPalette, themeFromPalette } = await import("./palette");
      const palette = await extractPalette(logo);
      s.setDeck({ ...s.deck, theme: themeFromPalette(palette, a.mode ?? "light") });
      s.updateBrand({ primaryColor: undefined, accentColor: undefined });
      return `Generated a theme from the logo.`;
    }
    default:
      return "No-op.";
  }
}

/** Resize an element by a factor while keeping it centered. */
function scalePatch(el: { x: number; y: number; w: number; h: number }, scale: number) {
  const nw = Math.round(el.w * scale);
  const nh = Math.round(el.h * scale);
  return { w: nw, h: nh, x: Math.round(el.x - (nw - el.w) / 2), y: Math.round(el.y - (nh - el.h) / 2) };
}

/** Fetch a bundled asset and convert to a data URL so it embeds in exports. */
async function toDataUrl(path: string): Promise<string> {
  const res = await fetch(path);
  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = reject;
    fr.readAsDataURL(blob);
  });
}
