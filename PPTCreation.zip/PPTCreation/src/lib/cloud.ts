import type { Deck } from "./types";

/** Client wrappers around the cloud deck API (/api/decks…). */

export interface CloudDeckSummary {
  id: string;
  title: string;
  updatedAt: string;
  shared: boolean;
}
export interface CloudVersion {
  id: string;
  title: string;
  createdAt: string;
}

export async function cloudSave(userId: string, deck: Deck): Promise<{ ok: boolean; id: string; error?: string }> {
  const res = await fetch("/api/decks", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, deck }),
  });
  const data = await res.json();
  if (!res.ok) return { ok: false, id: data.id ?? deck.id, error: data.error };
  return data;
}

export async function cloudList(userId: string): Promise<CloudDeckSummary[]> {
  const res = await fetch(`/api/decks?userId=${encodeURIComponent(userId)}`);
  const data = await res.json();
  return data.decks ?? [];
}

export async function cloudLoad(userId: string, id: string): Promise<Deck | null> {
  const res = await fetch(`/api/decks/${id}?userId=${encodeURIComponent(userId)}`);
  if (!res.ok) return null;
  return (await res.json()).deck as Deck;
}

export async function cloudDelete(userId: string, id: string): Promise<boolean> {
  const res = await fetch(`/api/decks/${id}?userId=${encodeURIComponent(userId)}`, { method: "DELETE" });
  return (await res.json()).ok ?? false;
}

export async function cloudShare(userId: string, id: string): Promise<string> {
  const res = await fetch(`/api/decks/${id}/share`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Share failed");
  return data.token as string;
}

export async function cloudVersions(userId: string, id: string): Promise<CloudVersion[]> {
  const res = await fetch(`/api/decks/${id}/versions?userId=${encodeURIComponent(userId)}`);
  return (await res.json()).versions ?? [];
}

export async function cloudRestore(userId: string, id: string, versionId: string): Promise<Deck | null> {
  const res = await fetch(`/api/decks/${id}/versions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, versionId }),
  });
  if (!res.ok) return null;
  return (await res.json()).deck as Deck;
}
