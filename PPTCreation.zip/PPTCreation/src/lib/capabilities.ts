import { LAYOUTS } from "./layouts";
import { THEME_LIST } from "./themes";
import { INSERT_CATEGORIES, INSERT_ITEMS } from "./inserts";

/**
 * Single source of truth for what the AI agent can do. The agent's system prompt
 * is GENERATED from this + the live LAYOUTS/THEMES registries, so when a block,
 * theme, or action is added the agent immediately "knows" it — no prompt drift.
 */

/** Which AISlide data field each block consumes. */
export const BLOCK_DATA: Record<string, string> = {
  cover: "title, subtitle, kicker",
  sectionHeader: "title, kicker",
  agenda: "bullets[] (3-6)",
  bullets: "bullets[] (3-5)",
  twoColumn: "bullets[] (split into 2)",
  comparison: "columns[{heading, points[]}] (2-3)",
  statGrid: "stats[{value, label}] (2-4)",
  cardGrid: "steps[{title, description}] (4-8) — feature cards with colored chips",
  process: "steps[{title, description}] (3-5)",
  timeline: "timeline[{label, title, description}] (3-5)",
  team: "team[{name, role}] (2-6)",
  orgChart: "org[{name, role, level}] (level 0=top) — hierarchy",
  funnel: "funnel[{label, value?}] (top→bottom, widest→narrowest)",
  pyramid: "pyramid[{label, description?}] (top→bottom, narrow→wide)",
  chart: "chart{unit?, data[{label, value}]} (3-6 bars)",
  callout: "callout (one bold line)",
  kpiDashboard: "kpis[{value, label, delta?}] (3-6) — premium metric tiles",
  gantt: "gantt{unit?, tasks[{label, start, end}]} — project timeline (native chart on HD export)",
  quote: "quote, attribution",
  stat: "stat{value, label}",
  imageRight: "title, body, bullets[]",
  imageLeft: "title, body, bullets[]",
  closing: "title, subtitle",
};

export interface ActionSpec {
  name: string;
  signature: string;
  when: string;
}

export const ACTIONS: ActionSpec[] = [
  { name: "set_deck", signature: "{ title, themeId?, slides: AISlide[] }", when: "create or fully replace the deck" },
  { name: "add_slides", signature: "{ slides: AISlide[], afterIndex? }", when: "add one or more slides" },
  { name: "edit_slide", signature: "{ index, slide }", when: "change one slide — fields you send are MERGED onto it, so send ONLY what changes (e.g. just {title}, or {layout, ...newData} to relayout). Untouched content is preserved." },
  { name: "delete_slide", signature: "{ index }", when: "remove a slide" },
  { name: "duplicate_slide", signature: "{ index }", when: "duplicate a slide" },
  { name: "move_slide", signature: "{ from, to }", when: "reorder a single slide" },
  { name: "reorder_slides", signature: "{ order: number[] }", when: "reorder all slides (full 0-based permutation)" },
  { name: "set_slide_background", signature: "{ index, background:{ type:'solid'|'gradient', color?, gradient?:[a,b], gradientAngle? } }", when: "change one slide's background" },
  { name: "set_theme", signature: "{ themeId }", when: "change the visual theme" },
  { name: "set_brand", signature: "{ patch }", when: "branding for ALL slides — logo, header/footer, colors, fonts" },
  { name: "set_title", signature: "{ title }", when: "rename the deck" },
  { name: "auto_brand", signature: "{ mode?: 'light'|'dark' }", when: "generate a theme from the deck's logo colors (needs a logo set first)" },
  { name: "set_slide_logo_scale", signature: "{ index, scale }", when: "resize the brand logo on ONE slide (scale e.g. 1.5 = 50% bigger)" },
  { name: "scale_fonts", signature: "{ scope:'slide'|'all', index?, factor }", when: "increase/decrease all text sizes (factor 1.2 = bigger, 0.85 = smaller); scope 'slide' uses index or current slide" },
  { name: "resize_element", signature: "{ index, target?:'image'|'largest', scale?, w?, h? }", when: "resize an image element on a slide (use scale to grow/shrink)" },
  { name: "style_element", signature: "{ patch?:{ fontSize?, fontWeight?, color?, align?, italic? }, scale? }", when: "restyle/resize the user's CURRENTLY SELECTED element (scale e.g. 1.3 to enlarge)" },
  { name: "set_element_text", signature: "{ text }", when: "replace the text of the user's CURRENTLY SELECTED element" },
  { name: "add_resource", signature: "{ itemId, slideIndex? }", when: "insert a PREBUILT shape / component / diagram (see RESOURCES) onto a slide, e.g. 'add a funnel diagram' -> itemId 'funnel3'. Omit slideIndex for the current slide." },
  { name: "add_image", signature: "{ query, slideIndex? }", when: "find and insert a STOCK photo matching a search query, e.g. 'add a photo of a city skyline' -> query 'city skyline'" },
  { name: "generate_image", signature: "{ prompt, slideIndex? }", when: "GENERATE an AI image from a description and insert it, e.g. 'create an illustration of a rocket launch'" },
  { name: "add_chart", signature: "{ chartType?:'column'|'bar'|'line'|'area'|'pie'|'donut', categories:string[], series:[{name,data:number[]}], unit?, slideIndex? }", when: "insert a data CHART, e.g. 'add a line chart of revenue by quarter'. Use categories for the x-axis and one series per line/bar set." },
  { name: "cleanup", signature: "{ slideIndex? }", when: "auto-fix a slide's layout — pull off-canvas items back in, fix unreadable text-on-fill contrast, and separate overlapping text. Use for 'clean up / fix this slide'." },
  { name: "place_attachment", signature: "{ index, as:'image'|'logo', slideIndex? }", when: "use an image the user ATTACHED (listed in their message) — insert it on a slide or set it as the logo" },
];

export const BRAND_KEYS =
  'brandPreset ("oati" = one-shot OATI house style: BANNER header (logo + title + subtitle + accent rule) + footer + navy/red theme, for "add OATI header and footer" / "make it OATI-branded"; OR a SAVED org preset by name, e.g. "use the Acme brand"; all text stays dynamic), ' +
  'logoPreset ("oati" = bundled OATI logo on every slide), logoScale (number, e.g. 1.5 = bigger logo on ALL slides), ' +
  "headerText, headerSubtext (second line under the banner title), footerText, showHeader (bool), showFooter (bool), showPageNumbers (bool), " +
  'headerPreset (premium header style: "banner"|"rule"|"minimal"|"band"|"sidebar"|"gradientBar"), ' +
  'footerPreset (premium footer style: "line"|"band"|"confidential"|"pageOnly"), ' +
  "primaryColor (#hex), accentColor (#hex), fontHeading, fontBody. " +
  'To ADD a header, set showHeader:true and a headerPreset (default "rule") and usually a headerText; ' +
  'to ADD a footer, set showFooter:true and a footerPreset (default "line") with footerText and/or showPageNumbers. ' +
  "To change header/footer wording just set headerText/footerText.";

/** Build the capability section of the agent prompt from the live registries. */
export function buildAgentManifest(): string {
  const blocks = LAYOUTS.map((l) => `  - ${l.id} (${l.hint}) -> ${BLOCK_DATA[l.id] ?? "title"}`).join("\n");
  const themes = THEME_LIST.map((t) => `${t.id} (${t.name}${t.dark ? ", dark" : ""})`).join(", ");
  const actions = ACTIONS.map((a) => `  - ${a.name}: ${a.signature} — ${a.when}`).join("\n");
  const resources = INSERT_CATEGORIES.map(
    (c) => `  ${c.label}: ${INSERT_ITEMS.filter((it) => it.category === c.id).map((it) => `${it.id} (${it.label})`).join(", ")}`,
  ).join("\n");
  return `ACTIONS (each a FLAT object with a "type" field):
${actions}

set_brand.patch keys: ${BRAND_KEYS}

BLOCKS (layout -> data field to populate):
${blocks}

RESOURCES (itemId for add_resource, grouped):
${resources}

LAYOUT TIPS — pick the block that fits the content: cardGrid for FEATURE / COMPONENT / CAPABILITY / MODULE lists (each item = a short title + one-line description, 4-8 items); statGrid for metrics; process for ordered steps; timeline for dated milestones; comparison for A-vs-B.

VARIANTS (optional "variant" on a slide for visual variety): statGrid: cards|minimal|circles; bullets: dots|checks|cards; process: horizontal|vertical.

THEME ids: ${themes}`;
}
