import { create } from "zustand";
import type { Role } from "./auth";
import type { BrandKit, Deck } from "./types";

/** Client-side org governance: brand + locks + domain rules, fetched from /api/org. */

export interface OrgView {
  name: string;
  brand: {
    logoUrl?: string;
    primaryColor?: string;
    accentColor?: string;
    fontHeading?: string;
    fontBody?: string;
    footerText?: string;
  };
  locks: { colors: boolean; fonts: boolean; logo: boolean; footer: boolean };
  brandPresets: { id: string; name: string; brand: Record<string, unknown>; themeId?: string }[];
  approvedAssets: string[];
  allowedDomains: string[];
  domainRoles: Record<string, Role>;
  sso: { enabled: boolean; provider?: string };
}

const EMPTY: OrgView = {
  name: "OATI",
  brand: {},
  locks: { colors: false, fonts: false, logo: false, footer: false },
  brandPresets: [],
  approvedAssets: [],
  allowedDomains: [],
  domainRoles: {},
  sso: { enabled: false },
};

interface OrgState {
  org: OrgView;
  loaded: boolean;
  load: () => Promise<void>;
}

export const useOrg = create<OrgState>((set) => ({
  org: EMPTY,
  loaded: false,
  load: async () => {
    try {
      const r = await fetch("/api/org").then((x) => x.json());
      if (r.org) set({ org: { ...EMPTY, ...r.org }, loaded: true });
      else set({ loaded: true });
    } catch {
      set({ loaded: true });
    }
  },
}));

/** Decide whether an email may sign up and which role it gets, per org policy. */
export function resolveAccess(email: string, org: OrgView): { allowed: boolean; role: Role; reason?: string } {
  const domain = email.trim().toLowerCase().split("@")[1] ?? "";
  if (org.allowedDomains.length && !org.allowedDomains.includes(domain)) {
    return { allowed: false, role: "user", reason: `Only ${org.allowedDomains.join(", ")} email addresses may sign up.` };
  }
  const role = org.domainRoles[domain] ?? "user";
  return { allowed: true, role };
}

/** Merge the enforced org brand into a deck's brand kit (locked fields always win). */
export function applyOrgBrand(deck: Deck, org: OrgView): Deck {
  const b = org.brand;
  const brand: BrandKit = { ...deck.brand };
  const set = <K extends keyof BrandKit>(k: K, v: BrandKit[K] | undefined, locked: boolean) => {
    if (v != null && v !== "" && (locked || brand[k] == null)) brand[k] = v;
  };
  set("primaryColor", b.primaryColor, org.locks.colors);
  set("accentColor", b.accentColor, org.locks.colors);
  set("fontHeading", b.fontHeading, org.locks.fonts);
  set("fontBody", b.fontBody, org.locks.fonts);
  set("logoUrl", b.logoUrl, org.locks.logo);
  set("footerText", b.footerText, org.locks.footer);
  return { ...deck, brand };
}
