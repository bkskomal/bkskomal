/**
 * Skill registry — the assistant is a multi-tool platform. Each skill is a
 * capability the assistant can route to. PPT creation is live today; more skills
 * (Excel comparison, etc.) slot in here as they're built.
 */
export interface Skill {
  id: string;
  name: string;
  description: string;
  live: boolean;
  /** example prompt shown on the assistant home */
  example: string;
}

export const SKILLS: Skill[] = [
  {
    id: "ppt",
    name: "Presentations",
    description: "Create editable, on-brand PowerPoint decks by chatting.",
    live: true,
    example: "Create a 10-slide investor pitch for an AI startup",
  },
  {
    id: "compare",
    name: "Compare Files",
    description:
      "Drop two Excel/CSV files — compares every tab and cell, highlighting what's added, removed, and modified.",
    live: true,
    example: "Compare two Excel files and highlight the differences",
  },
];

export const liveSkills = () => SKILLS.filter((s) => s.live);
