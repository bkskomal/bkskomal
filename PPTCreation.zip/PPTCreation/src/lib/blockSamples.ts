import type { AISlide } from "./schema";

/** Placeholder content for each block, used by the "add slide" block picker. */
export const BLOCK_SAMPLES: Record<string, AISlide> = {
  cover: { layout: "cover", kicker: "Subtitle", title: "Your big title", subtitle: "A short supporting line" },
  sectionHeader: { layout: "sectionHeader", kicker: "Section", title: "Section title" },
  agenda: {
    layout: "agenda",
    title: "Agenda",
    bullets: ["Introduction", "The problem", "Our solution", "Results", "Next steps"],
  },
  bullets: { layout: "bullets", title: "Key points", bullets: ["First point", "Second point", "Third point"] },
  twoColumn: {
    layout: "twoColumn",
    title: "Two columns",
    bullets: ["Item one", "Item two", "Item three", "Item four"],
  },
  comparison: {
    layout: "comparison",
    title: "Comparison",
    columns: [
      { heading: "Option A", points: ["Benefit one", "Benefit two", "Benefit three"] },
      { heading: "Option B", points: ["Benefit one", "Benefit two", "Benefit three"] },
    ],
  },
  statGrid: {
    layout: "statGrid",
    title: "By the numbers",
    stats: [
      { value: "92%", label: "Customer satisfaction" },
      { value: "3.2x", label: "Faster than before" },
      { value: "$1.4M", label: "Saved annually" },
    ],
  },
  process: {
    layout: "process",
    title: "How it works",
    steps: [
      { title: "Capture", description: "Bring your data in" },
      { title: "Process", description: "AI does the work" },
      { title: "Deliver", description: "Share the result" },
    ],
  },
  timeline: {
    layout: "timeline",
    title: "Roadmap",
    timeline: [
      { label: "Q1", title: "Launch", description: "Ship the MVP" },
      { label: "Q2", title: "Grow", description: "Onboard customers" },
      { label: "Q3", title: "Scale", description: "Expand globally" },
    ],
  },
  team: {
    layout: "team",
    title: "Meet the team",
    team: [
      { name: "Alex Kim", role: "CEO" },
      { name: "Sam Lee", role: "CTO" },
      { name: "Jordan Tao", role: "Design" },
    ],
  },
  chart: {
    layout: "chart",
    title: "Growth",
    chart: { unit: "k", data: [{ label: "Jan", value: 12 }, { label: "Feb", value: 19 }, { label: "Mar", value: 28 }, { label: "Apr", value: 41 }] },
  },
  callout: { layout: "callout", kicker: "Remember", title: "Callout", callout: "One bold idea your audience will remember." },
  kpiDashboard: {
    layout: "kpiDashboard",
    kicker: "Q3 2026",
    title: "Performance dashboard",
    kpis: [
      { value: "$4.2M", label: "Annual recurring revenue", delta: "+18%" },
      { value: "1,284", label: "Active customers", delta: "+9%" },
      { value: "1.8%", label: "Monthly churn", delta: "-0.4%" },
      { value: "62", label: "Net promoter score", delta: "+5" },
      { value: "3.2x", label: "LTV / CAC", delta: "+0.3" },
      { value: "94%", label: "Gross margin", delta: "+1%" },
    ],
  },
  gantt: {
    layout: "gantt",
    kicker: "2026",
    title: "Delivery roadmap",
    gantt: {
      unit: "",
      tasks: [
        { label: "Discovery & research", start: 0, end: 2 },
        { label: "Design system", start: 1, end: 4 },
        { label: "Core build", start: 3, end: 8 },
        { label: "Beta & QA", start: 7, end: 10 },
        { label: "Launch", start: 10, end: 12 },
      ],
    },
  },
  orgChart: {
    layout: "orgChart",
    title: "Org structure",
    org: [
      { name: "Alex Kim", role: "CEO", level: 0 },
      { name: "Sam Lee", role: "CTO", level: 1 },
      { name: "Jordan Tao", role: "VP Sales", level: 1 },
      { name: "Riya Shah", role: "VP Ops", level: 1 },
    ],
  },
  funnel: {
    layout: "funnel",
    title: "Conversion funnel",
    funnel: [
      { label: "Visitors", value: "50,000" },
      { label: "Signups", value: "12,000" },
      { label: "Activated", value: "4,500" },
      { label: "Paying", value: "1,200" },
    ],
  },
  pyramid: {
    layout: "pyramid",
    title: "Strategy pyramid",
    pyramid: [
      { label: "Vision" },
      { label: "Strategy" },
      { label: "Initiatives" },
      { label: "Execution" },
    ],
  },
  quote: { layout: "quote", title: "Quote", quote: "A memorable line that lands.", attribution: "Someone notable" },
  stat: { layout: "stat", kicker: "Headline", title: "One big number", stat: { value: "100%", label: "What it measures" } },
  imageRight: { layout: "imageRight", kicker: "Feature", title: "Text with a visual", body: "Describe the idea here.", bullets: ["Point one", "Point two"] },
  imageLeft: { layout: "imageLeft", kicker: "Feature", title: "Visual with text", body: "Describe the idea here.", bullets: ["Point one", "Point two"] },
  closing: { layout: "closing", title: "Thank you", subtitle: "hello@yourcompany.com" },
};
