/**
 * PPTMaker core data model.
 *
 * A Deck is the single source of truth. The DOM canvas renders it, the AI
 * assistant emits/edits it (validated against schema.ts), and the exporter
 * (pptx/pdf) consumes it. Positions are in pixels on a fixed logical canvas
 * (see CANVAS in utils.ts); the exporter converts px -> inches.
 *
 * Colors may be a literal hex ("#0EA5E9") or a theme token reference written
 * as "token:primary" — resolved against the active Theme at render/export time.
 */

export type ColorValue = string; // "#RRGGBB" | "token:<name>" | "transparent"

export type TextRole =
  | "title"
  | "subtitle"
  | "heading"
  | "body"
  | "bullet"
  | "caption"
  | "quote"
  | "kicker"; // small eyebrow label above a title

export type Align = "left" | "center" | "right";
export type VAlign = "top" | "middle" | "bottom";
export type ListStyle = "none" | "bullet" | "number";

export interface BaseElement {
  id: string;
  type: ElementType;
  /** px on the logical canvas */
  x: number;
  y: number;
  w: number;
  h: number;
  rotation?: number;
  opacity?: number;
  /** stacking order; higher renders on top */
  z?: number;
  /** marks brand-injected chrome (logo/header/footer) so it can be re-synced */
  brand?: boolean;
  locked?: boolean;
  /** marks data-visualization primitives (chart bars/labels) the HD exporter
   * replaces with a NATIVE PowerPoint chart */
  dataViz?: boolean;
}

export type ElementType = "text" | "image" | "shape" | "line" | "icon" | "chart";

export interface TextElement extends BaseElement {
  type: "text";
  text: string;
  role?: TextRole;
  fontSize?: number;
  fontFamily?: string;
  fontWeight?: number;
  italic?: boolean;
  color?: ColorValue;
  align?: Align;
  valign?: VAlign;
  lineHeight?: number;
  letterSpacing?: number;
  listStyle?: ListStyle;
  /** for multi-bullet blocks, one string per line */
  items?: string[];
}

export interface ImageElement extends BaseElement {
  type: "image";
  /** data URL or remote URL */
  src: string;
  alt?: string;
  fit?: "cover" | "contain";
  radius?: number;
}

export type ShapeKind =
  | "rect"
  | "roundedRect"
  | "ellipse"
  | "triangle"
  | "trapezoid"
  | "blob"
  | "chevron"
  | "arrowRight"
  | "hexagon"
  | "pentagon"
  | "diamond"
  | "star"
  | "parallelogram"
  | "pill";

export interface ShapeElement extends BaseElement {
  type: "shape";
  shape: ShapeKind;
  fill?: ColorValue;
  stroke?: ColorValue;
  strokeWidth?: number;
  radius?: number;
  /** optional decorative gradient: [from, to] colors */
  gradient?: [ColorValue, ColorValue];
  gradientAngle?: number;
}

export interface IconElement extends BaseElement {
  type: "icon";
  /** lucide icon name, e.g. "rocket" */
  name: string;
  color?: ColorValue;
  strokeWidth?: number;
}

export type ChartKind = "bar" | "column" | "line" | "area" | "pie" | "donut";

export interface ChartSeries {
  name: string;
  data: number[];
}

/** A first-class, natively-exportable chart (multi-series, multiple types). */
export interface ChartElement extends BaseElement {
  type: "chart";
  chartType: ChartKind;
  categories: string[];
  series: ChartSeries[];
  unit?: string;
  legend?: boolean;
  /** explicit series colors; falls back to the theme palette */
  palette?: string[];
  title?: string;
}

export type SlideElement =
  | TextElement
  | ImageElement
  | ShapeElement
  | IconElement
  | ChartElement;

export interface SlideBackground {
  type: "solid" | "gradient" | "image";
  color?: ColorValue;
  gradient?: [ColorValue, ColorValue];
  gradientAngle?: number;
  src?: string;
}

export interface Slide {
  id: string;
  /** layout id used to (re)generate / restyle this slide */
  layout: string;
  background?: SlideBackground;
  elements: SlideElement[];
  notes?: string;
  /** per-slide override of the brand logo size (else uses BrandKit.logoScale) */
  logoScale?: number;
  /** the semantic content this slide was built from — enables "change layout",
   * "regenerate", and native chart/table export without losing meaning */
  source?: import("./schema").AISlide;
}

/** Resolvable color palette + typography for a deck. */
export interface Theme {
  id: string;
  name: string;
  dark?: boolean;
  colors: {
    background: string;
    surface: string;
    primary: string;
    secondary: string;
    accent: string;
    text: string;
    textMuted: string;
    onPrimary: string;
  };
  fonts: {
    heading: string;
    body: string;
  };
}

export type LogoPlacement =
  | "top-left"
  | "top-right"
  | "bottom-left"
  | "bottom-right";

export type ChromeStyle = "bar" | "band";

/** Prebuilt premium header styles (a curated resource collection). */
export type HeaderPreset = "rule" | "band" | "minimal" | "sidebar" | "gradientBar" | "banner";
/** Prebuilt premium footer styles. */
export type FooterPreset = "line" | "band" | "pageOnly" | "confidential";

/** Brand customization applied across every slide in one place. */
export interface BrandKit {
  logoUrl?: string; // data URL
  logoPlacement: LogoPlacement;
  logoScale: number; // 0.5 - 2
  headerText?: string;
  /** optional second line under the header title (used by the "banner" preset) */
  headerSubtext?: string;
  footerText?: string;
  showPageNumbers: boolean;
  /** header/footer chrome — consistent across templates, styled per theme */
  showHeader: boolean;
  showFooter: boolean;
  headerStyle: ChromeStyle; // legacy: "bar" = accent rule, "band" = solid strip
  footerStyle: ChromeStyle;
  /** premium prebuilt chrome presets (take precedence over headerStyle/footerStyle) */
  headerPreset?: HeaderPreset;
  footerPreset?: FooterPreset;
  /** optional overrides on top of the theme palette */
  primaryColor?: string;
  accentColor?: string;
  fontHeading?: string;
  fontBody?: string;
}

/** Visual personality of a template — what makes two same-color decks look different. */
export interface DeckStyle {
  cover: "centered" | "leftRule" | "split" | "bigType" | "gradientHero" | "sidebar" | "heroGlance";
  bg: "plain" | "blob" | "sideBand" | "arc" | "dots" | "diagonal" | "grid";
  accent: "bar" | "dot" | "line" | "bracket" | "none";
  headScale: number; // multiplies heading font sizes
  bodyScale: number; // multiplies body font sizes
  radius: number; // base corner radius for cards
}

export interface Deck {
  id: string;
  title: string;
  subtitle?: string;
  /** logical canvas size in px */
  size: { w: number; h: number };
  templateId?: string;
  theme: Theme;
  brand: BrandKit;
  /** visual personality (cover/background/accent/type) — defaults applied if absent */
  style?: DeckStyle;
  slides: Slide[];
  createdAt: number;
  updatedAt: number;
}

export type TemplateCategory =
  | "Pitch"
  | "Business"
  | "Marketing"
  | "Education"
  | "Creative"
  | "Minimal"
  | "Data"
  | "Portfolio";

/** A pickable starting point shown in the gallery. */
export interface Template {
  id: string;
  name: string;
  category: TemplateCategory;
  description: string;
  theme: Theme;
  /** visual personality (cover/background/accent/type) */
  style: DeckStyle;
  /** tags drive search + AI layout selection */
  tags: string[];
  /** optional brand-kit overrides baked into the template (e.g. banner header, logo) */
  brand?: Partial<BrandKit>;
  /** builds the starter slides for this template */
  build: (ctx: TemplateBuildContext) => Slide[];
}

export interface TemplateBuildContext {
  title: string;
  subtitle?: string;
}
