import { CANVAS } from "./utils";

/** A snap guide line to draw on the canvas while dragging. */
export interface Guide {
  axis: "x" | "y";
  /** canvas-space position of the line */
  pos: number;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

const THRESHOLD = 6; // canvas px

/**
 * Snap a moving rect's edges/centers to other rects + the canvas edges/center.
 * Returns the adjusted position and the guide lines to render.
 */
export function snapMove(rect: Rect, others: Rect[]): { x: number; y: number; guides: Guide[] } {
  const guides: Guide[] = [];

  // candidate target lines (canvas + every other element)
  const vLines = lineTargets(others, "x");
  const hLines = lineTargets(others, "y");

  const { value: x, guide: gx } = snapAxis(rect.x, rect.w, vLines);
  const { value: y, guide: gy } = snapAxis(rect.y, rect.h, hLines);

  if (gx !== null) guides.push({ axis: "x", pos: gx });
  if (gy !== null) guides.push({ axis: "y", pos: gy });

  return { x, y, guides };
}

function lineTargets(others: Rect[], axis: "x" | "y"): number[] {
  const max = axis === "x" ? CANVAS.w : CANVAS.h;
  const lines = [0, max / 2, max]; // canvas edges + center
  for (const o of others) {
    const start = axis === "x" ? o.x : o.y;
    const size = axis === "x" ? o.w : o.h;
    lines.push(start, start + size / 2, start + size);
  }
  return lines;
}

/** Try to snap the three points (start / center / end) of a moving span to any target line. */
function snapAxis(
  start: number,
  size: number,
  targets: number[],
): { value: number; guide: number | null } {
  const points = [
    { offset: 0, val: start }, // leading edge
    { offset: size / 2, val: start + size / 2 }, // center
    { offset: size, val: start + size }, // trailing edge
  ];

  let best: { delta: number; value: number; guide: number } | null = null;
  for (const p of points) {
    for (const t of targets) {
      const delta = Math.abs(p.val - t);
      if (delta <= THRESHOLD && (!best || delta < best.delta)) {
        best = { delta, value: t - p.offset, guide: t };
      }
    }
  }
  return best ? { value: Math.round(best.value), guide: best.guide } : { value: start, guide: null };
}

export type ResizeHandle = "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w";

/** Apply a resize delta (in canvas px) to a rect for a given handle. */
export function applyResize(
  rect: Rect,
  handle: ResizeHandle,
  dx: number,
  dy: number,
  opts: { lockAspect?: boolean; min?: number } = {},
): Rect {
  const min = opts.min ?? 24;
  let { x, y, w, h } = rect;
  const east = handle.includes("e");
  const west = handle.includes("w");
  const north = handle.includes("n");
  const south = handle.includes("s");

  if (east) w = Math.max(min, rect.w + dx);
  if (west) {
    w = Math.max(min, rect.w - dx);
    x = rect.x + (rect.w - w);
  }
  if (south) h = Math.max(min, rect.h + dy);
  if (north) {
    h = Math.max(min, rect.h - dy);
    y = rect.y + (rect.h - h);
  }

  if (opts.lockAspect && (east || west) && (north || south)) {
    const ratio = rect.w / rect.h;
    // drive height from width, keeping the anchored corner fixed
    const newH = w / ratio;
    if (north) y = rect.y + (rect.h - newH);
    h = newH;
  }

  return { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) };
}
