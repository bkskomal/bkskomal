import type { StateStorage } from "zustand/middleware";

/**
 * IndexedDB-backed storage for the editor deck. localStorage caps at ~5 MB, which
 * image-heavy decks (logos + stock/AI images embedded as data URLs) blow past —
 * throwing QuotaExceededError mid-edit. IndexedDB has a far larger quota (tens–
 * hundreds of MB) and its async API means a failed write can't crash a reducer.
 *
 * getItem transparently migrates any existing value from the old localStorage key.
 */
const DB_NAME = "pptmaker";
const STORE = "kv";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") return reject(new Error("no indexedDB"));
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbGet(key: string): Promise<string | null> {
  const db = await openDb();
  return new Promise((resolve) => {
    const req = db.transaction(STORE, "readonly").objectStore(STORE).get(key);
    req.onsuccess = () => resolve((req.result as string | undefined) ?? null);
    req.onerror = () => resolve(null);
  });
}

async function idbSet(key: string, value: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

async function idbDel(key: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
}

export const idbStorage: StateStorage = {
  getItem: async (name) => {
    try {
      const v = await idbGet(name);
      if (v != null) return v;
      // one-time migration from the legacy localStorage key
      if (typeof localStorage !== "undefined") {
        const legacy = localStorage.getItem(name);
        if (legacy != null) {
          try { await idbSet(name, legacy); localStorage.removeItem(name); } catch { /* ignore */ }
          return legacy;
        }
      }
      return null;
    } catch {
      return null;
    }
  },
  setItem: async (name, value) => {
    try {
      await idbSet(name, value);
    } catch (e) {
      // never let an autosave failure surface as an app error
      console.warn("[persist] deck save failed (too large?) — use Save to cloud:", (e as Error)?.message);
    }
  },
  removeItem: async (name) => {
    try { await idbDel(name); } catch { /* ignore */ }
  },
};
