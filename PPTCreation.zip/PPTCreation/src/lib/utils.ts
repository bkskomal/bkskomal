import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Tailwind-aware className combiner. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Logical slide canvas size (16:9). 96px === 1 inch, so 1280x720 -> 13.33" x 7.5". */
export const CANVAS = { w: 1280, h: 720 } as const;
export const PX_PER_INCH = 96;

/** Convert canvas px to PowerPoint inches for export. */
export const pxToIn = (px: number) => px / PX_PER_INCH;
