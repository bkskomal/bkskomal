import { readableOn } from "./color";
import type { Theme } from "./types";

/**
 * Extract a brand palette from a logo image (client-side, no deps) and derive a
 * full Theme. We sample the image onto a small canvas, bucket colors, drop
 * near-white / near-black / greys, and rank by frequency × saturation so the
 * vibrant brand colors win.
 */

interface RGB {
  r: number;
  g: number;
  b: number;
}

function toHex({ r, g, b }: RGB): string {
  const h = (n: number) => n.toString(16).padStart(2, "0");
  return `#${h(r)}${h(g)}${h(b)}`.toUpperCase();
}

function saturation({ r, g, b }: RGB): number {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  if (max === 0) return 0;
  return (max - min) / max;
}

function hue({ r, g, b }: RGB): number {
  const rn = r / 255, gn = g / 255, bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const d = max - min;
  if (d === 0) return 0;
  let h = 0;
  if (max === rn) h = ((gn - bn) / d) % 6;
  else if (max === gn) h = (bn - rn) / d + 2;
  else h = (rn - gn) / d + 4;
  h *= 60;
  return h < 0 ? h + 360 : h;
}

function hueDist(a: number, b: number): number {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
}

function mix(hex: string, withHex: string, t: number): string {
  const a = hexToRgb(hex);
  const b = hexToRgb(withHex);
  const r = Math.round(a.r + (b.r - a.r) * t);
  const g = Math.round(a.g + (b.g - a.g) * t);
  const bl = Math.round(a.b + (b.b - a.b) * t);
  return toHex({ r, g, b: bl });
}

function hexToRgb(hex: string): RGB {
  const c = hex.replace("#", "");
  return { r: parseInt(c.slice(0, 2), 16), g: parseInt(c.slice(2, 4), 16), b: parseInt(c.slice(4, 6), 16) };
}

export interface Palette {
  primary: string;
  accent: string;
  swatches: string[];
}

export async function extractPalette(dataUrl: string): Promise<Palette> {
  const img = await loadImage(dataUrl);
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  ctx.drawImage(img, 0, 0, size, size);
  const { data } = ctx.getImageData(0, 0, size, size);

  const buckets = new Map<string, { rgb: RGB; count: number }>();
  for (let i = 0; i < data.length; i += 4) {
    const a = data[i + 3];
    if (a < 128) continue; // skip transparent
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    if (max > 240 && min > 240) continue; // near-white
    if (max < 24) continue; // near-black
    const rgb = { r, g, b };
    if (saturation(rgb) < 0.18) continue; // greys
    const key = `${r >> 5}-${g >> 5}-${b >> 5}`; // coarse 32-step buckets
    const cur = buckets.get(key);
    if (cur) cur.count++;
    else buckets.set(key, { rgb, count: 1 });
  }

  const ranked = [...buckets.values()]
    .sort((a, b) => b.count * saturation(b.rgb) - a.count * saturation(a.rgb))
    .map((x) => x.rgb);

  if (ranked.length === 0) {
    // fallback: a neutral indigo brand
    return { primary: "#4F46E5", accent: "#06B6D4", swatches: ["#4F46E5", "#06B6D4"] };
  }

  const primary = ranked[0];
  const primaryHue = hue(primary);
  // accent = the most vibrant color with a clearly different hue
  const accentRgb = ranked.find((c) => hueDist(hue(c), primaryHue) > 40);
  const primaryHex = toHex(primary);
  const accentHex = accentRgb ? toHex(accentRgb) : mix(primaryHex, "#FFFFFF", 0); // placeholder

  return {
    primary: primaryHex,
    accent: accentRgb ? accentHex : rotateAccent(primaryHex),
    swatches: ranked.slice(0, 6).map(toHex),
  };
}

/** Derive a complementary-ish accent when the logo is monochrome. */
function rotateAccent(hex: string): string {
  // simple: shift toward a warm/cool partner by mixing
  return mix(hex, "#F59E0B", 0.5);
}

export function themeFromPalette(p: Palette, mode: "light" | "dark" = "light"): Theme {
  if (mode === "dark") {
    return {
      id: "brand-custom",
      name: "Your Brand",
      dark: true,
      colors: {
        background: "#0E1116",
        surface: mix("#0E1116", p.primary, 0.16),
        primary: p.primary,
        secondary: p.accent,
        accent: p.accent,
        text: "#F4F6FB",
        textMuted: "#9AA4B2",
        onPrimary: readableOn(p.primary),
      },
      fonts: { heading: "Inter", body: "Inter" },
    };
  }
  return {
    id: "brand-custom",
    name: "Your Brand",
    colors: {
      background: "#FFFFFF",
      surface: mix(p.primary, "#FFFFFF", 0.92),
      primary: p.primary,
      secondary: p.accent,
      accent: p.accent,
      text: "#161A22",
      textMuted: "#6B7280",
      onPrimary: readableOn(p.primary),
    },
    fonts: { heading: "Inter", body: "Inter" },
  };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}
