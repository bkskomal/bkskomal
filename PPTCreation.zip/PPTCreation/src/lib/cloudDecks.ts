import { nanoid } from "nanoid";
import { withDb } from "./db";

/**
 * Server-only cloud persistence for decks: save/list/get/delete, share links, and
 * version snapshots. Degrades gracefully — every function returns a safe fallback
 * when Postgres is unavailable, so the app still works fully local.
 */

export interface DeckSummary {
  id: string;
  title: string;
  updatedAt: string;
  shared: boolean;
}

/** Upsert a deck for a user; snapshots the previous version on change. */
export async function saveDeck(userId: string, deck: { id?: string; title?: string } & Record<string, unknown>): Promise<{ ok: boolean; id: string }> {
  const id = (deck.id as string) || nanoid(10);
  const title = (deck.title as string) || "Untitled";
  const body = { ...deck, id };
  return withDb<{ ok: boolean; id: string }>(async (p) => {
    // snapshot the current stored version before overwriting
    const prev = await p.query("SELECT data, title FROM decks WHERE id=$1 AND user_id=$2", [id, userId]);
    if (prev.rowCount) {
      await p.query("INSERT INTO deck_versions (id, deck_id, title, data) VALUES ($1,$2,$3,$4)", [nanoid(12), id, prev.rows[0].title, prev.rows[0].data]);
      // keep only the latest 20 versions
      await p.query("DELETE FROM deck_versions WHERE deck_id=$1 AND id NOT IN (SELECT id FROM deck_versions WHERE deck_id=$1 ORDER BY created_at DESC LIMIT 20)", [id]);
    }
    await p.query(
      `INSERT INTO decks (id, user_id, title, data, updated_at) VALUES ($1,$2,$3,$4, now())
       ON CONFLICT (id) DO UPDATE SET title=EXCLUDED.title, data=EXCLUDED.data, updated_at=now()
       WHERE decks.user_id=$2`,
      [id, userId, title, body],
    );
    return { ok: true, id };
  }, { ok: false, id });
}

export async function listDecks(userId: string): Promise<DeckSummary[]> {
  return withDb(async (p) => {
    const r = await p.query("SELECT id, title, updated_at, share_token FROM decks WHERE user_id=$1 ORDER BY updated_at DESC LIMIT 100", [userId]);
    return r.rows.map((x) => ({ id: x.id, title: x.title, updatedAt: x.updated_at, shared: !!x.share_token }));
  }, []);
}

export async function getDeck(userId: string, id: string): Promise<Record<string, unknown> | null> {
  return withDb(async (p) => {
    const r = await p.query("SELECT data FROM decks WHERE id=$1 AND user_id=$2", [id, userId]);
    return r.rowCount ? (r.rows[0].data as Record<string, unknown>) : null;
  }, null);
}

export async function deleteDeck(userId: string, id: string): Promise<boolean> {
  return withDb(async (p) => {
    await p.query("DELETE FROM deck_versions WHERE deck_id=$1", [id]);
    const r = await p.query("DELETE FROM decks WHERE id=$1 AND user_id=$2", [id, userId]);
    return (r.rowCount ?? 0) > 0;
  }, false);
}

/** Enable sharing → returns a stable public token (idempotent). */
export async function shareDeck(userId: string, id: string): Promise<string | null> {
  return withDb(async (p) => {
    const existing = await p.query("SELECT share_token FROM decks WHERE id=$1 AND user_id=$2", [id, userId]);
    if (!existing.rowCount) return null;
    if (existing.rows[0].share_token) return existing.rows[0].share_token as string;
    const token = nanoid(16);
    await p.query("UPDATE decks SET share_token=$1 WHERE id=$2 AND user_id=$3", [token, id, userId]);
    return token;
  }, null);
}

export async function unshareDeck(userId: string, id: string): Promise<boolean> {
  return withDb(async (p) => {
    const r = await p.query("UPDATE decks SET share_token=NULL WHERE id=$1 AND user_id=$2", [id, userId]);
    return (r.rowCount ?? 0) > 0;
  }, false);
}

/** Public read-only fetch by share token (no auth). */
export async function getSharedDeck(token: string): Promise<Record<string, unknown> | null> {
  return withDb(async (p) => {
    const r = await p.query("SELECT data FROM decks WHERE share_token=$1", [token]);
    return r.rowCount ? (r.rows[0].data as Record<string, unknown>) : null;
  }, null);
}

export interface VersionSummary {
  id: string;
  title: string;
  createdAt: string;
}

export async function listVersions(userId: string, id: string): Promise<VersionSummary[]> {
  return withDb(async (p) => {
    const owns = await p.query("SELECT 1 FROM decks WHERE id=$1 AND user_id=$2", [id, userId]);
    if (!owns.rowCount) return [];
    const r = await p.query("SELECT id, title, created_at FROM deck_versions WHERE deck_id=$1 ORDER BY created_at DESC", [id]);
    return r.rows.map((x) => ({ id: x.id, title: x.title, createdAt: x.created_at }));
  }, []);
}

/** Restore a past version into the live deck (current state is snapshotted first via saveDeck semantics). */
export async function restoreVersion(userId: string, id: string, versionId: string): Promise<Record<string, unknown> | null> {
  return withDb(async (p) => {
    const owns = await p.query("SELECT data, title FROM decks WHERE id=$1 AND user_id=$2", [id, userId]);
    if (!owns.rowCount) return null;
    const v = await p.query("SELECT data, title FROM deck_versions WHERE id=$1 AND deck_id=$2", [versionId, id]);
    if (!v.rowCount) return null;
    // snapshot current, then restore
    await p.query("INSERT INTO deck_versions (id, deck_id, title, data) VALUES ($1,$2,$3,$4)", [nanoid(12), id, owns.rows[0].title, owns.rows[0].data]);
    await p.query("UPDATE decks SET data=$1, title=$2, updated_at=now() WHERE id=$3 AND user_id=$4", [v.rows[0].data, v.rows[0].title, id, userId]);
    return v.rows[0].data as Record<string, unknown>;
  }, null);
}
