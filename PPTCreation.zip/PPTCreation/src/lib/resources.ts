import type { FooterPreset, HeaderPreset } from "./types";

/**
 * Curated catalog of prebuilt, premium slide "resources" — header styles, footer
 * styles and logo lockups. One source of truth used by BOTH the editor Insert
 * panel (to browse + click) and the AI capability manifest (so chat can add them
 * by name and edit their text). Each preset renders via brandChrome() using the
 * deck's theme colors, so it stays on-brand automatically.
 */

export interface ResourcePreset<T extends string> {
  id: T;
  label: string;
  desc: string;
}

export const HEADER_PRESETS: ResourcePreset<HeaderPreset>[] = [
  { id: "banner", label: "Brand banner", desc: "Logo + title + subtitle on a brand band with an accent rule" },
  { id: "rule", label: "Accent rule", desc: "Logo left · title right, thin gradient rule on top" },
  { id: "minimal", label: "Minimal", desc: "Clean logo + title with a hairline underline" },
  { id: "band", label: "Band", desc: "Solid strip with a gradient accent under it" },
  { id: "sidebar", label: "Side accent", desc: "Vertical accent bar with logo + title" },
  { id: "gradientBar", label: "Gradient bar", desc: "Bold primary→accent band, white title" },
];

export const FOOTER_PRESETS: ResourcePreset<FooterPreset>[] = [
  { id: "line", label: "Hairline", desc: "Footer text left · page number right, thin rule" },
  { id: "band", label: "Band", desc: "Solid strip with footer text + page number" },
  { id: "confidential", label: "Confidential pill", desc: "Accent tag pill left · page number right" },
  { id: "pageOnly", label: "Page only", desc: "Just a centered page number" },
];

/** Bundled logo lockups the agent can apply by name. */
export const LOGO_RESOURCES = [{ id: "oati", label: "OATI logo", desc: "The OATI wordmark on every slide" }];

export const HEADER_PRESET_IDS = HEADER_PRESETS.map((p) => p.id);
export const FOOTER_PRESET_IDS = FOOTER_PRESETS.map((p) => p.id);
