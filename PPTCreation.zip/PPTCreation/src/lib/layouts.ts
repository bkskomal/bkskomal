import { nanoid } from "nanoid";
import { CANVAS } from "./utils";
import { DEFAULT_STYLE } from "./styles";
import { autofitSlide } from "./autofit";
import { repairSlide } from "./lint";
import type { AISlide } from "./schema";
import type {
  ChartElement,
  ChartKind,
  DeckStyle,
  ShapeElement,
  Slide,
  SlideBackground,
  SlideElement,
  TextElement,
} from "./types";

/** The style in effect during the current buildSlide call (set synchronously). */
let activeStyle: DeckStyle = DEFAULT_STYLE;

/**
 * Deterministic layout engine. Maps a semantic AISlide -> a positioned Slide.
 * Keeping placement here (not in the model) is what makes every generated slide
 * consistent and on-brand. Colors use "token:*" so theme + brand resolve later.
 */

const M = 88; // page margin
const W = CANVAS.w;
const H = CANVAS.h;

const id = () => nanoid(8);

function text(p: Partial<TextElement> & { text: string }): TextElement {
  return {
    id: id(),
    type: "text",
    x: M,
    y: M,
    w: W - M * 2,
    h: 80,
    align: "left",
    valign: "top",
    color: "token:text",
    ...p,
  };
}

function shape(p: Partial<ShapeElement> & { shape: ShapeElement["shape"] }): ShapeElement {
  return {
    id: id(),
    type: "shape",
    x: 0,
    y: 0,
    w: 100,
    h: 100,
    ...p,
  };
}

export interface LayoutMeta {
  id: string;
  name: string;
  /** preview hint for the layout switcher */
  hint: string;
}

export const LAYOUTS: LayoutMeta[] = [
  { id: "cover", name: "Cover", hint: "Title slide" },
  { id: "sectionHeader", name: "Section", hint: "Divider" },
  { id: "agenda", name: "Agenda", hint: "Numbered outline" },
  { id: "bullets", name: "Bullets", hint: "Key points" },
  { id: "twoColumn", name: "Two Column", hint: "Two lists" },
  { id: "comparison", name: "Comparison", hint: "Columns w/ headers" },
  { id: "statGrid", name: "Stat Grid", hint: "Metric cards" },
  { id: "cardGrid", name: "Card Grid", hint: "Feature cards w/ chips" },
  { id: "kpiDashboard", name: "KPI Dashboard", hint: "Premium metrics" },
  { id: "gantt", name: "Gantt", hint: "Project timeline" },
  { id: "process", name: "Process", hint: "Ordered steps" },
  { id: "timeline", name: "Timeline", hint: "Milestones" },
  { id: "team", name: "Team", hint: "People grid" },
  { id: "orgChart", name: "Org Chart", hint: "Hierarchy" },
  { id: "funnel", name: "Funnel", hint: "Stages" },
  { id: "pyramid", name: "Pyramid", hint: "Layers" },
  { id: "chart", name: "Chart", hint: "Bar chart" },
  { id: "callout", name: "Callout", hint: "Highlight" },
  { id: "quote", name: "Quote", hint: "Pull quote" },
  { id: "stat", name: "Stat", hint: "Big number" },
  { id: "imageRight", name: "Image Right", hint: "Text + visual" },
  { id: "imageLeft", name: "Image Left", hint: "Visual + text" },
  { id: "closing", name: "Closing", hint: "Thank you" },
];

export const LAYOUT_IDS = LAYOUTS.map((l) => l.id);

type Builder = (ai: AISlide) => { background?: SlideBackground; elements: SlideElement[] };

const builders: Record<string, Builder> = {
  cover: (ai) => coverByStyle(ai),

  sectionHeader: (ai) => ({
    background: {
      type: "gradient",
      gradient: ["token:primary", "token:accent"],
      gradientAngle: 120,
    },
    elements: [
      ai.kicker
        ? text({
            text: ai.kicker.toUpperCase(),
            y: 280,
            h: 36,
            align: "center",
            fontSize: 18,
            fontWeight: 700,
            letterSpacing: 4,
            color: "token:onPrimary",
            opacity: 0.85,
          })
        : null,
      text({
        text: ai.title,
        role: "title",
        y: 320,
        h: 140,
        align: "center",
        fontSize: 60,
        fontWeight: 800,
        color: "token:onPrimary",
      }),
    ].filter(Boolean) as SlideElement[],
  }),

  bullets: (ai) => {
    const items = ai.bullets ?? [];
    const variant = ai.variant ?? "dots";
    const head = [accentBar(), ai.kicker ? kicker(ai.kicker) : null, title(ai.title)].filter(Boolean) as SlideElement[];

    if (variant === "checks" || variant === "cards") {
      const n = Math.max(items.length, 1);
      const rowH = Math.min(76, (560 - 260) / n);
      const rows = items.flatMap((it, i) => {
        const y = 260 + i * rowH;
        const card =
          variant === "cards"
            ? [shape({ shape: "roundedRect", x: M, y, w: W - M * 2, h: rowH - 12, fill: "token:surface", radius: 14 })]
            : [];
        return [
          ...card,
          text({ text: "✓", x: M + 18, y, w: 40, h: rowH - 12, valign: "middle", fontSize: 26, fontWeight: 800, color: "token:primary" }),
          text({ text: it, x: M + 64, y, w: W - M * 2 - 88, h: rowH - 12, valign: "middle", fontSize: 24, color: "token:text" }),
        ];
      });
      return { elements: [...head, ...rows] as SlideElement[] };
    }

    return {
      elements: [
        ...head,
        {
          id: id(),
          type: "text",
          x: M,
          y: 250,
          w: W - M * 2,
          h: 380,
          role: "bullet",
          listStyle: "bullet",
          items,
          text: items.join("\n"),
          fontSize: 26,
          lineHeight: 1.7,
          color: "token:text",
        } as TextElement,
      ] as SlideElement[],
    };
  },

  twoColumn: (ai) => {
    // tolerate the model filling `columns` instead of `bullets`
    const items = ai.bullets ?? (ai.columns ? ai.columns.flatMap((c) => c.points) : []);
    const mid = Math.ceil(items.length / 2);
    const colW = (W - M * 2 - 56) / 2;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        column(items.slice(0, mid), M, 250, colW),
        column(items.slice(mid), M + colW + 56, 250, colW),
      ].filter(Boolean) as SlideElement[],
    };
  },

  quote: (ai) => ({
    background: { type: "solid", color: "token:surface" },
    elements: [
      text({
        text: "“",
        x: M,
        y: 120,
        h: 160,
        w: 200,
        fontSize: 200,
        fontWeight: 800,
        color: "token:primary",
        opacity: 0.25,
      }),
      text({
        text: ai.quote ?? ai.title,
        role: "quote",
        x: M + 40,
        y: 230,
        w: W - M * 2 - 80,
        h: 260,
        fontSize: 40,
        italic: true,
        fontWeight: 600,
        lineHeight: 1.4,
        color: "token:text",
      }),
      ai.attribution
        ? text({
            text: `— ${ai.attribution}`,
            x: M + 40,
            y: 510,
            h: 40,
            fontSize: 22,
            fontWeight: 700,
            color: "token:primary",
          })
        : null,
    ].filter(Boolean) as SlideElement[],
  }),

  stat: (ai) => ({
    elements: [
      accentBar(),
      ai.kicker ? kicker(ai.kicker) : null,
      title(ai.title),
      text({
        text: ai.stat?.value ?? "100%",
        x: M,
        y: 280,
        h: 180,
        w: W - M * 2,
        align: "center",
        fontSize: 160,
        fontWeight: 800,
        color: "token:primary",
      }),
      text({
        text: ai.stat?.label ?? ai.subtitle ?? "",
        x: M,
        y: 480,
        h: 60,
        w: W - M * 2,
        align: "center",
        fontSize: 26,
        color: "token:textMuted",
      }),
    ].filter(Boolean) as SlideElement[],
  }),

  imageRight: (ai) => {
    const items = ai.bullets ?? [];
    return {
      elements: [
        shape({
          shape: "roundedRect",
          x: W - 520,
          y: 0,
          w: 520,
          h: H,
          gradient: ["token:primary", "token:accent"],
          gradientAngle: 160,
          radius: 0,
        }),
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title, 640),
        ai.body
          ? text({
              text: ai.body,
              y: 250,
              w: 600,
              h: 120,
              fontSize: 22,
              lineHeight: 1.5,
              color: "token:textMuted",
            })
          : null,
        items.length
          ? ({
              id: id(),
              type: "text",
              x: M,
              y: ai.body ? 380 : 260,
              w: 600,
              h: 280,
              role: "bullet",
              listStyle: "bullet",
              items,
              text: items.join("\n"),
              fontSize: 22,
              lineHeight: 1.7,
              color: "token:text",
            } as TextElement)
          : null,
      ].filter(Boolean) as SlideElement[],
    };
  },

  imageLeft: (ai) => {
    const items = ai.bullets ?? [];
    return {
      elements: [
        shape({
          shape: "roundedRect",
          x: 0,
          y: 0,
          w: 520,
          h: H,
          gradient: ["token:accent", "token:primary"],
          gradientAngle: 160,
          radius: 0,
        }),
        shape({ shape: "roundedRect", x: 560, y: 96, w: 56, h: 8, fill: "token:primary", radius: 4 }),
        ai.kicker
          ? text({ text: ai.kicker.toUpperCase(), x: 560, y: 124, h: 30, fontSize: 16, fontWeight: 700, letterSpacing: 3, color: "token:primary" })
          : null,
        text({ text: ai.title, role: "title", x: 560, y: 158, w: 632, h: 80, fontSize: 44, fontWeight: 800, lineHeight: 1.1 }),
        ai.body
          ? text({ text: ai.body, x: 560, y: 250, w: 632, h: 120, fontSize: 22, lineHeight: 1.5, color: "token:textMuted" })
          : null,
        items.length
          ? ({ id: id(), type: "text", x: 560, y: ai.body ? 380 : 260, w: 632, h: 280, role: "bullet", listStyle: "bullet", items, text: items.join("\n"), fontSize: 22, lineHeight: 1.7, color: "token:text" } as TextElement)
          : null,
      ].filter(Boolean) as SlideElement[],
    };
  },

  agenda: (ai) => {
    const items = ai.bullets ?? [];
    const rowH = Math.min(86, (H - 280) / Math.max(items.length, 1));
    return {
      elements: [
        accentBar(),
        kicker(ai.kicker ?? "Agenda"),
        title(ai.title),
        ...items.flatMap((item, i) => {
          const y = 250 + i * rowH;
          const d = Math.min(56, rowH - 16);
          return [
            shape({ shape: "ellipse", x: M, y, w: d, h: d, fill: "token:primary" }),
            text({ text: String(i + 1), x: M, y, w: d, h: d, align: "center", valign: "middle", fontSize: d * 0.42, fontWeight: 800, color: "token:onPrimary" }),
            text({ text: item, x: M + d + 28, y, w: W - M * 2 - d - 28, h: d, valign: "middle", fontSize: 26, fontWeight: 600, color: "token:text" }),
          ];
        }),
      ] as SlideElement[],
    };
  },

  statGrid: (ai) => {
    const stats = ai.stats ?? (ai.stat ? [ai.stat] : []);
    const n = Math.max(stats.length, 1);
    const gap = 28;
    const cardW = (W - M * 2 - gap * (n - 1)) / n;
    const variant = ai.variant ?? "cards";
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        ...stats.flatMap((s, i) => {
          const x = M + i * (cardW + gap);
          if (variant === "minimal") {
            return [
              shape({ shape: "roundedRect", x: x + cardW / 2 - 28, y: 310, w: 56, h: 6, fill: "token:primary", radius: 3 }),
              text({ text: s.value, x: x + 12, y: 340, w: cardW - 24, h: 110, align: "center", fontSize: 80, fontWeight: 800, color: "token:text" }),
              text({ text: s.label, x: x + 16, y: 458, w: cardW - 32, h: 70, align: "center", fontSize: 20, lineHeight: 1.3, color: "token:textMuted" }),
            ];
          }
          if (variant === "circles") {
            const d = Math.min(cardW - 24, 200);
            return [
              shape({ shape: "ellipse", x: x + cardW / 2 - d / 2, y: 300, w: d, h: d, gradient: ["token:primary", "token:accent"], gradientAngle: 135 }),
              text({ text: s.value, x: x + cardW / 2 - d / 2, y: 300, w: d, h: d, align: "center", valign: "middle", fontSize: 52, fontWeight: 800, color: "token:onPrimary" }),
              text({ text: s.label, x: x + 12, y: 312 + d, w: cardW - 24, h: 60, align: "center", fontSize: 19, lineHeight: 1.3, color: "token:textMuted" }),
            ];
          }
          return [
            shape({ shape: "roundedRect", x, y: 300, w: cardW, h: 250, fill: "token:surface", radius: Math.max(12, activeStyle.radius) }),
            shape({ shape: "roundedRect", x: x + 28, y: 300, w: cardW - 56, h: 4, fill: "token:primary", radius: 2 }),
            text({ text: s.value, x: x + 16, y: 346, w: cardW - 32, h: 104, align: "center", fontSize: 68, fontWeight: 800, letterSpacing: -1, color: "token:primary" }),
            text({ text: s.label, x: x + 24, y: 462, w: cardW - 48, h: 70, align: "center", fontSize: 18, lineHeight: 1.4, color: "token:textMuted" }),
          ];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  cardGrid: (ai) => {
    const cards = ai.steps ?? (ai.bullets ?? []).map((b) => ({ title: b, description: undefined as string | undefined }));
    const n = Math.max(cards.length, 1);
    const cols = Math.min(4, n);
    const gap = 24;
    const topY = 292;
    const cardW = (W - M * 2 - gap * (cols - 1)) / cols;
    const rows = Math.ceil(n / cols);
    const cardH = Math.min(196, (632 - topY - gap * (rows - 1)) / rows);
    const CHIP = ["#7C3AED", "#2563EB", "#DC2626", "#059669", "#0D9488", "#EA580C", "#16A34A", "#DB2777"];
    const head = [accentBar(), ai.kicker ? kicker(ai.kicker) : null, title(ai.title)].filter(Boolean) as SlideElement[];
    return {
      elements: [
        ...head,
        ...cards.flatMap((c, i) => {
          const col = i % cols, row = Math.floor(i / cols);
          const x = M + col * (cardW + gap), y = topY + row * (cardH + gap);
          return [
            shape({ shape: "roundedRect", x, y, w: cardW, h: cardH, fill: "token:surface", radius: 14 }),
            shape({ shape: "roundedRect", x: x + 22, y: y + 22, w: 34, h: 34, radius: 8, fill: CHIP[i % CHIP.length] }),
            text({ text: c.title, x: x + 22, y: y + 70, w: cardW - 44, h: 32, fontSize: 18, fontWeight: 700, color: "token:text" }),
            c.description ? text({ text: c.description, x: x + 22, y: y + 104, w: cardW - 44, h: cardH - 116, fontSize: 13, lineHeight: 1.35, color: "token:textMuted" }) : null,
          ].filter(Boolean) as SlideElement[];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  comparison: (ai) => {
    // tolerate the model filling `bullets` instead of `columns`
    const cols =
      ai.columns ??
      (ai.bullets ? [{ heading: ai.subtitle ?? "Highlights", points: ai.bullets }] : []);
    const n = Math.max(cols.length, 1);
    const gap = 32;
    const colW = (W - M * 2 - gap * (n - 1)) / n;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        ...cols.flatMap((c, i) => {
          const x = M + i * (colW + gap);
          const r = Math.max(12, activeStyle.radius);
          return [
            { ...shape({ shape: "roundedRect", x, y: 280, w: colW, h: 360, fill: "token:surface", radius: r }), dataViz: true },
            { ...shape({ shape: "roundedRect", x, y: 280, w: colW, h: 58, fill: i % 2 ? "token:accent" : "token:primary", radius: r }), dataViz: true },
            { ...shape({ shape: "rect", x, y: 308, w: colW, h: 30, fill: i % 2 ? "token:accent" : "token:primary" }), dataViz: true },
            { ...text({ text: c.heading, x: x + 16, y: 280, w: colW - 32, h: 58, align: "center", valign: "middle", fontSize: 21, fontWeight: 700, letterSpacing: 0.3, color: "token:onPrimary" }), dataViz: true },
            { id: id(), type: "text", x: x + 30, y: 372, w: colW - 58, h: 250, role: "bullet", listStyle: "bullet", items: c.points, text: c.points.join("\n"), fontSize: 19, lineHeight: 1.65, color: "token:text", dataViz: true } as TextElement,
          ];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  process: (ai) => {
    const steps = ai.steps ?? [];
    const n = Math.max(steps.length, 1);
    const gap = 28;
    const cardW = (W - M * 2 - gap * (n - 1)) / n;
    const head = [accentBar(), ai.kicker ? kicker(ai.kicker) : null, title(ai.title)].filter(Boolean) as SlideElement[];

    if (ai.variant === "vertical") {
      const rowH = Math.min(86, (560 - 260) / n);
      return {
        elements: [
          ...head,
          ...steps.flatMap((s, i) => {
            const y = 260 + i * rowH;
            return [
              shape({ shape: "ellipse", x: M, y, w: 52, h: 52, fill: "token:primary" }),
              text({ text: String(i + 1), x: M, y, w: 52, h: 52, align: "center", valign: "middle", fontSize: 24, fontWeight: 800, color: "token:onPrimary" }),
              text({ text: s.title, x: M + 76, y, w: W - M * 2 - 76, h: 30, fontSize: 22, fontWeight: 700, color: "token:text" }),
              s.description
                ? text({ text: s.description, x: M + 76, y: y + 30, w: W - M * 2 - 76, h: rowH - 36, fontSize: 16, lineHeight: 1.35, color: "token:textMuted" })
                : null,
            ].filter(Boolean) as SlideElement[];
          }),
        ] as SlideElement[],
      };
    }

    const firstCx = M + cardW / 2;
    const lastCx = M + (n - 1) * (cardW + gap) + cardW / 2;
    return {
      elements: [
        ...head,
        // connector line behind the nodes ties the steps together
        n > 1 ? shape({ shape: "rect", x: firstCx, y: 331, w: lastCx - firstCx, h: 2, fill: "token:textMuted", opacity: 0.25 }) : null,
        ...steps.flatMap((s, i) => {
          const x = M + i * (cardW + gap);
          const ccx = x + cardW / 2;
          return [
            shape({ shape: "ellipse", x: ccx - 30, y: 302, w: 60, h: 60, gradient: ["token:primary", "token:accent"], gradientAngle: 135 }),
            text({ text: String(i + 1), x: ccx - 30, y: 302, w: 60, h: 60, align: "center", valign: "middle", fontSize: 26, fontWeight: 800, color: "token:onPrimary" }),
            text({ text: s.title, x, y: 386, w: cardW, h: 52, align: "center", fontSize: 21, fontWeight: 700, color: "token:text" }),
            s.description
              ? text({ text: s.description, x: x + 8, y: 440, w: cardW - 16, h: 150, align: "center", fontSize: 16, lineHeight: 1.5, color: "token:textMuted" })
              : null,
          ].filter(Boolean) as SlideElement[];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  timeline: (ai) => {
    const items = ai.timeline ?? [];
    const n = Math.max(items.length, 1);
    const lineY = 420;
    const step = (W - M * 2) / n;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        shape({ shape: "roundedRect", x: M, y: lineY - 2, w: W - M * 2, h: 4, gradient: ["token:primary", "token:accent"], gradientAngle: 90, radius: 2 }),
        ...items.flatMap((it, i) => {
          const cx = M + step * i + step / 2;
          const above = i % 2 === 0;
          const bx = cx - step / 2 + 10;
          const bw = step - 20;
          const dateY = above ? 258 : lineY + 30;
          const titleY = above ? 292 : lineY + 62;
          const descY = above ? 328 : lineY + 98;
          return [
            // node: ring + gradient dot
            shape({ shape: "ellipse", x: cx - 17, y: lineY - 17, w: 34, h: 34, fill: "token:surface" }),
            shape({ shape: "ellipse", x: cx - 10, y: lineY - 10, w: 20, h: 20, gradient: ["token:primary", "token:accent"], gradientAngle: 135 }),
            text({ text: it.label, x: bx, y: dateY, w: bw, h: 30, align: "center", fontSize: 17, fontWeight: 800, letterSpacing: 0.5, color: "token:accent" }),
            text({ text: it.title, x: bx, y: titleY, w: bw, h: 34, align: "center", fontSize: 19, fontWeight: 700, color: "token:text" }),
            it.description
              ? text({ text: it.description, x: bx, y: descY, w: bw, h: 66, align: "center", fontSize: 14, lineHeight: 1.4, color: "token:textMuted" })
              : null,
          ].filter(Boolean) as SlideElement[];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  team: (ai) => {
    const people = ai.team ?? [];
    const perRow = people.length <= 3 ? people.length || 1 : Math.ceil(people.length / 2) > 4 ? 4 : Math.ceil(people.length / 2);
    const gap = 32;
    const cellW = (W - M * 2 - gap * (perRow - 1)) / perRow;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        ...people.flatMap((p, i) => {
          const col = i % perRow;
          const row = Math.floor(i / perRow);
          const x = M + col * (cellW + gap);
          const y = 290 + row * 220;
          const initials = p.name.split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();
          return [
            shape({ shape: "ellipse", x: x + cellW / 2 - 56, y, w: 112, h: 112, fill: "token:surface" }),
            text({ text: initials, x: x + cellW / 2 - 56, y, w: 112, h: 112, align: "center", valign: "middle", fontSize: 40, fontWeight: 800, color: "token:primary" }),
            text({ text: p.name, x, y: y + 124, w: cellW, h: 32, align: "center", fontSize: 22, fontWeight: 700, color: "token:text" }),
            text({ text: p.role, x, y: y + 158, w: cellW, h: 28, align: "center", fontSize: 17, color: "token:textMuted" }),
          ];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  chart: (ai) => {
    const c = ai.chart ?? {};
    const categories = c.categories ?? (c.data ?? []).map((d) => d.label);
    const series = c.series ?? [{ name: ai.title || "Series", data: (c.data ?? []).map((d) => d.value) }];
    const chartType: ChartKind = c.type ?? "column";
    const chartEl: ChartElement = {
      id: id(),
      type: "chart",
      chartType,
      categories,
      series,
      unit: c.unit,
      legend: series.length > 1,
      x: M,
      y: 288,
      w: W - M * 2,
      h: 340,
      z: 5,
    };
    return {
      elements: [accentBar(), ai.kicker ? kicker(ai.kicker) : null, title(ai.title), chartEl].filter(Boolean) as SlideElement[],
    };
  },

  kpiDashboard: (ai) => {
    const kpis = ai.kpis ?? (ai.stats ?? []).map((s) => ({ ...s, delta: undefined }));
    const n = Math.max(kpis.length, 1);
    const perRow = n <= 3 ? n : 3;
    const gap = 24;
    const cardW = (W - M * 2 - gap * (perRow - 1)) / perRow;
    const rows = Math.ceil(n / perRow);
    const cardH = rows > 1 ? 150 : 240;
    const topY = 290;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        ...kpis.flatMap((k, i) => {
          const col = i % perRow;
          const row = Math.floor(i / perRow);
          const x = M + col * (cardW + gap);
          const y = topY + row * (cardH + gap);
          const up = /^\+|↑|up/i.test(k.delta ?? "");
          const down = /^-|↓|down/i.test(k.delta ?? "");
          const r = Math.max(12, activeStyle.radius);
          const deltaColor = up ? "#16A34A" : down ? "#DC2626" : "token:textMuted";
          return [
            shape({ shape: "roundedRect", x, y, w: cardW, h: cardH, fill: "token:surface", radius: r }),
            shape({ shape: "roundedRect", x, y, w: 5, h: cardH, gradient: ["token:primary", "token:accent"], gradientAngle: 0, radius: 2 }),
            text({ text: k.value, x: x + 28, y: y + 24, w: cardW - 56, h: 70, fontSize: 50, fontWeight: 800, letterSpacing: -1, color: "token:primary" }),
            text({ text: k.label, x: x + 28, y: y + (rows > 1 ? 96 : 122), w: cardW - 56, h: 50, fontSize: 17, lineHeight: 1.3, color: "token:textMuted" }),
            k.delta
              ? { ...shape({ shape: "roundedRect", x: x + cardW - 96, y: y + 26, w: 68, h: 30, fill: deltaColor, opacity: 0.14, radius: 15 }) }
              : null,
            k.delta
              ? text({ text: k.delta, x: x + cardW - 96, y: y + 26, w: 68, h: 30, align: "center", valign: "middle", fontSize: 15, fontWeight: 700, color: deltaColor })
              : null,
          ].filter(Boolean) as SlideElement[];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  gantt: (ai) => {
    const tasks = ai.gantt?.tasks ?? [];
    const n = Math.max(tasks.length, 1);
    const minS = Math.min(...tasks.map((t) => t.start), 0);
    const maxE = Math.max(...tasks.map((t) => t.end), minS + 1);
    const span = maxE - minS || 1;
    const labelW = 280;
    const chartX = M + labelW;
    const chartW = W - M - chartX;
    const topY = 290;
    const rowH = Math.min(58, (560 - topY) / n);
    const barH = rowH * 0.62;
    const scale = chartW / span;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        // baseline axis
        { ...shape({ shape: "rect", x: chartX, y: topY - 8, w: chartW, h: 2, fill: "token:textMuted", opacity: 0.3 }), dataViz: true },
        ...tasks.flatMap((t, i) => {
          const y = topY + i * rowH;
          const bx = chartX + (t.start - minS) * scale;
          const bw = Math.max(10, (t.end - t.start) * scale);
          return [
            { ...text({ text: t.label, x: M, y, w: labelW - 16, h: barH, valign: "middle", fontSize: 17, fontWeight: 600, color: "token:text" }), dataViz: true },
            { ...shape({ shape: "roundedRect", x: bx, y: y + (rowH - barH) / 2, w: bw, h: barH, gradient: ["token:primary", "token:accent"], gradientAngle: 0, radius: barH / 2 }), dataViz: true },
            { ...text({ text: `${t.start}–${t.end}${ai.gantt?.unit ?? ""}`, x: bx, y: y + (rowH - barH) / 2, w: Math.max(bw, 80), h: barH, align: "center", valign: "middle", fontSize: 13, fontWeight: 700, color: "token:onPrimary" }), dataViz: true },
          ];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  orgChart: (ai) => {
    const nodes = ai.org ?? [];
    const levels = new Map<number, typeof nodes>();
    nodes.forEach((nd) => {
      const arr = levels.get(nd.level) ?? [];
      arr.push(nd);
      levels.set(nd.level, arr);
    });
    const levelKeys = [...levels.keys()].sort((a, b) => a - b);
    const boxW = 220;
    const boxH = 76;
    const topY = 280;
    const vGap = 130;
    const els: SlideElement[] = [accentBar(), title(ai.title)];
    if (ai.kicker) els.push(kicker(ai.kicker));

    const centers = new Map<number, number[]>();
    levelKeys.forEach((lvl, li) => {
      const row = levels.get(lvl)!;
      const totalW = row.length * boxW + (row.length - 1) * 40;
      const startX = (W - totalW) / 2;
      const y = topY + li * vGap;
      const xs: number[] = [];
      row.forEach((nd, i) => {
        const x = startX + i * (boxW + 40);
        xs.push(x + boxW / 2);
        const top = lvl === 0;
        els.push(shape({ shape: "roundedRect", x, y, w: boxW, h: boxH, fill: top ? "token:primary" : "token:surface", radius: 12 }));
        els.push(text({ text: nd.name, x: x + 12, y: y + 14, w: boxW - 24, h: 26, align: "center", fontSize: 18, fontWeight: 700, color: top ? "token:onPrimary" : "token:text" }));
        els.push(text({ text: nd.role, x: x + 12, y: y + 42, w: boxW - 24, h: 22, align: "center", fontSize: 13, color: top ? "token:onPrimary" : "token:textMuted" }));
      });
      centers.set(lvl, xs);
    });

    // connectors: a simple bus from each level to the next
    for (let li = 0; li < levelKeys.length - 1; li++) {
      const parentXs = centers.get(levelKeys[li])!;
      const childXs = centers.get(levelKeys[li + 1])!;
      const parentCx = parentXs.reduce((a, b) => a + b, 0) / parentXs.length;
      const yA = topY + li * vGap + boxH;
      const yB = topY + (li + 1) * vGap;
      const busY = (yA + yB) / 2;
      els.push(shape({ shape: "rect", x: parentCx - 1, y: yA, w: 2, h: busY - yA, fill: "token:textMuted", opacity: 0.5 }));
      const minX = Math.min(...childXs);
      const maxX = Math.max(...childXs);
      els.push(shape({ shape: "rect", x: minX, y: busY, w: maxX - minX || 2, h: 2, fill: "token:textMuted", opacity: 0.5 }));
      childXs.forEach((cx) => els.push(shape({ shape: "rect", x: cx - 1, y: busY, w: 2, h: yB - busY, fill: "token:textMuted", opacity: 0.5 })));
    }
    return { elements: els };
  },

  funnel: (ai) => {
    const stages = ai.funnel ?? [];
    const n = Math.max(stages.length, 1);
    const topW = 760;
    const minW = 300;
    const h = Math.min(78, (560 - 290) / n);
    const gap = 10;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        ...stages.flatMap((st, i) => {
          const w = topW - ((topW - minW) * i) / Math.max(n - 1, 1);
          const x = (W - w) / 2;
          const y = 300 + i * (h + gap);
          return [
            shape({ shape: "trapezoid", x, y, w, h, gradient: ["token:primary", "token:accent"], gradientAngle: 90, opacity: 1 - i * 0.12 }),
            text({ text: st.value ? `${st.label} — ${st.value}` : st.label, x, y, w, h, align: "center", valign: "middle", fontSize: 20, fontWeight: 700, color: "token:onPrimary" }),
          ];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  pyramid: (ai) => {
    const levelsArr = ai.pyramid ?? [];
    const n = Math.max(levelsArr.length, 1);
    const maxW = 820;
    const minW = 200;
    const h = Math.min(86, (560 - 290) / n);
    const gap = 8;
    return {
      elements: [
        accentBar(),
        ai.kicker ? kicker(ai.kicker) : null,
        title(ai.title),
        ...levelsArr.flatMap((lv, i) => {
          const w = minW + ((maxW - minW) * i) / Math.max(n - 1, 1);
          const x = (W - w) / 2;
          const y = 300 + i * (h + gap);
          return [
            shape({ shape: i === 0 ? "triangle" : "trapezoid", x, y, w, h, gradient: ["token:accent", "token:primary"], gradientAngle: 90, opacity: 0.6 + (i / n) * 0.4 }),
            text({ text: lv.description ? `${lv.label} — ${lv.description}` : lv.label, x, y, w, h, align: "center", valign: "middle", fontSize: 18, fontWeight: 700, color: "token:onPrimary" }),
          ];
        }),
      ].filter(Boolean) as SlideElement[],
    };
  },

  callout: (ai) => ({
    elements: [
      shape({ shape: "roundedRect", x: M, y: 200, w: W - M * 2, h: 320, gradient: ["token:primary", "token:accent"], gradientAngle: 135, radius: 32 }),
      ai.kicker
        ? text({ text: ai.kicker.toUpperCase(), x: M + 60, y: 250, w: W - M * 2 - 120, h: 36, align: "center", fontSize: 16, fontWeight: 700, letterSpacing: 3, color: "token:onPrimary", opacity: 0.85 })
        : null,
      text({ text: ai.callout ?? ai.title, x: M + 60, y: 300, w: W - M * 2 - 120, h: 160, align: "center", valign: "middle", fontSize: 40, fontWeight: 800, lineHeight: 1.25, color: "token:onPrimary" }),
    ].filter(Boolean) as SlideElement[],
  }),

  closing: (ai) => ({
    background: {
      type: "gradient",
      gradient: ["token:background", "token:surface"],
      gradientAngle: 145,
    },
    elements: [
      shape({
        shape: "blob",
        x: -160,
        y: H - 360,
        w: 560,
        h: 560,
        gradient: ["token:accent", "token:primary"],
        gradientAngle: 135,
        opacity: 0.85,
      }),
      text({
        text: ai.title,
        role: "title",
        y: 280,
        h: 140,
        align: "center",
        fontSize: 66,
        fontWeight: 800,
      }),
      ai.subtitle
        ? text({
            text: ai.subtitle,
            y: 430,
            h: 60,
            align: "center",
            fontSize: 24,
            color: "token:textMuted",
          })
        : null,
    ].filter(Boolean) as SlideElement[],
  }),
};

// ---- shared pieces ----
/** Accent mark above a title — restrained, refined-corporate marks. */
function accentBar(): ShapeElement {
  switch (activeStyle.accent) {
    case "dot":
      return shape({ shape: "ellipse", x: M, y: 102, w: 14, h: 14, fill: "token:primary" });
    case "line":
      return shape({ shape: "rect", x: M, y: 106, w: 72, h: 2, fill: "token:primary" });
    case "bracket":
      return shape({ shape: "rect", x: M, y: 100, w: 5, h: 42, fill: "token:primary" });
    case "none":
      return shape({ shape: "rect", x: M, y: 96, w: 1, h: 1, fill: "transparent", opacity: 0 });
    default:
      return shape({ shape: "roundedRect", x: M, y: 102, w: 38, h: 4, fill: "token:primary", radius: 2 });
  }
}

function kicker(t: string): TextElement {
  return text({
    text: t.toUpperCase(),
    role: "kicker",
    y: 128,
    h: 26,
    fontSize: 13,
    fontWeight: 700,
    letterSpacing: 2.5,
    color: "token:primary",
  });
}

function title(t: string, w = W - M * 2): TextElement {
  return text({
    text: t,
    role: "title",
    y: 160,
    h: 84,
    w,
    fontSize: Math.round(42 * activeStyle.headScale),
    fontWeight: 700,
    lineHeight: 1.14,
    letterSpacing: -0.5,
  });
}

/** Background decorations behind content (z:-1), varied per style. */
function decor(): SlideElement[] {
  const z = -1;
  switch (activeStyle.bg) {
    case "blob":
      return [
        { ...shape({ shape: "blob", x: W - 400, y: -200, w: 540, h: 540, gradient: ["token:primary", "token:accent"], gradientAngle: 135, opacity: 0.07 }), z },
        { ...shape({ shape: "ellipse", x: -160, y: H - 220, w: 340, h: 340, fill: "token:secondary", opacity: 0.05 }), z },
      ];
    case "sideBand":
      return [{ ...shape({ shape: "rect", x: 0, y: 0, w: 8, h: H, gradient: ["token:primary", "token:accent"], gradientAngle: 90 }), z }];
    case "arc":
      return [{ ...shape({ shape: "ellipse", x: W / 2 - 560, y: -880, w: 1120, h: 1080, fill: "token:primary", opacity: 0.05 }), z }];
    case "dots": {
      const dots: SlideElement[] = [];
      for (let r = 0; r < 4; r++)
        for (let c = 0; c < 6; c++)
          dots.push({ ...shape({ shape: "ellipse", x: W - 216 + c * 30, y: 24 + r * 30, w: 8, h: 8, fill: "token:primary", opacity: 0.18 }), z });
      return dots;
    }
    case "diagonal":
      return [{ ...shape({ shape: "rect", x: W - 240, y: -200, w: 180, h: 1200, rotation: 22, gradient: ["token:primary", "token:accent"], gradientAngle: 90, opacity: 0.05 }), z }];
    case "grid": {
      const lines: SlideElement[] = [];
      for (let c = 1; c < 8; c++) lines.push({ ...shape({ shape: "rect", x: (W / 8) * c, y: 0, w: 1, h: H, fill: "token:textMuted", opacity: 0.04 }), z });
      for (let r = 1; r < 5; r++) lines.push({ ...shape({ shape: "rect", x: 0, y: (H / 5) * r, w: W, h: 1, fill: "token:textMuted", opacity: 0.04 }), z });
      return lines;
    }
    default:
      return [];
  }
}

/** Style-driven cover compositions. */
function coverByStyle(ai: AISlide): { background?: SlideBackground; elements: SlideElement[] } {
  const hs = activeStyle.headScale;
  const kick = ai.kicker
    ? text({ text: ai.kicker.toUpperCase(), role: "kicker", y: 196, h: 36, fontSize: 18, fontWeight: 700, letterSpacing: 3, color: "token:primary" })
    : null;

  switch (activeStyle.cover) {
    case "gradientHero":
      return {
        background: { type: "gradient", gradient: ["token:primary", "token:accent"], gradientAngle: 130 },
        elements: [
          shape({ shape: "ellipse", x: W - 360, y: H - 360, w: 620, h: 620, fill: "token:onPrimary", opacity: 0.08 }),
          ai.kicker ? text({ text: ai.kicker.toUpperCase(), y: 232, h: 34, fontSize: 15, fontWeight: 700, letterSpacing: 3.5, color: "token:onPrimary", opacity: 0.85 }) : null,
          text({ text: ai.title, role: "title", y: 282, h: 200, w: 900, fontSize: Math.round(64 * hs), fontWeight: 700, lineHeight: 1.08, letterSpacing: -0.5, color: "token:onPrimary" }),
          ai.subtitle ? text({ text: ai.subtitle, y: 496, h: 80, w: 800, fontSize: 24, color: "token:onPrimary", opacity: 0.9, lineHeight: 1.4 }) : null,
        ].filter(Boolean) as SlideElement[],
      };
    case "split":
      return {
        background: { type: "solid", color: "token:background" },
        elements: [
          shape({ shape: "rect", x: W - 440, y: 0, w: 440, h: H, gradient: ["token:primary", "token:accent"], gradientAngle: 160 }),
          shape({ shape: "ellipse", x: W - 300, y: H - 280, w: 360, h: 360, fill: "token:onPrimary", opacity: 0.1 }),
          kick,
          text({ text: ai.title, role: "title", y: 250, h: 200, w: 680, fontSize: Math.round(58 * hs), fontWeight: 700, lineHeight: 1.1, letterSpacing: -0.5 }),
          ai.subtitle ? text({ text: ai.subtitle, y: 476, h: 90, w: 640, fontSize: 23, color: "token:textMuted", lineHeight: 1.4 }) : null,
        ].filter(Boolean) as SlideElement[],
      };
    case "leftRule":
      return {
        background: { type: "solid", color: "token:background" },
        elements: [
          shape({ shape: "rect", x: M, y: 222, w: 4, h: 236, fill: "token:primary" }),
          ai.kicker ? text({ text: ai.kicker.toUpperCase(), x: M + 32, y: 232, h: 32, fontSize: 15, fontWeight: 700, letterSpacing: 2.5, color: "token:primary" }) : null,
          text({ text: ai.title, role: "title", x: M + 32, y: 276, h: 180, w: 880, fontSize: Math.round(56 * hs), fontWeight: 700, lineHeight: 1.1, letterSpacing: -0.5 }),
          ai.subtitle ? text({ text: ai.subtitle, x: M + 32, y: 474, h: 80, w: 780, fontSize: 23, color: "token:textMuted", lineHeight: 1.4 }) : null,
        ].filter(Boolean) as SlideElement[],
      };
    case "bigType":
      return {
        background: { type: "solid", color: "token:background" },
        elements: [
          ...decor(),
          ai.kicker ? text({ text: ai.kicker.toUpperCase(), y: 176, h: 34, fontSize: 15, fontWeight: 700, letterSpacing: 3.5, color: "token:primary" }) : null,
          text({ text: ai.title, role: "title", y: 224, h: 320, w: W - M * 2, fontSize: Math.round(84 * hs), fontWeight: 800, lineHeight: 1.02, letterSpacing: -1.5 }),
          ai.subtitle ? text({ text: ai.subtitle, y: 566, h: 70, w: 900, fontSize: 24, color: "token:textMuted", lineHeight: 1.35 }) : null,
        ].filter(Boolean) as SlideElement[],
      };
    case "sidebar":
      return {
        background: { type: "solid", color: "token:background" },
        elements: [
          shape({ shape: "rect", x: 0, y: 0, w: 500, h: H, gradient: ["token:primary", "token:accent"], gradientAngle: 155 }),
          shape({ shape: "ellipse", x: 260, y: H - 300, w: 380, h: 380, fill: "token:onPrimary", opacity: 0.08 }),
          shape({ shape: "roundedRect", x: 64, y: 232, w: 40, h: 4, fill: "token:onPrimary", opacity: 0.8, radius: 2 }),
          ai.kicker ? text({ text: ai.kicker.toUpperCase(), x: 64, y: 254, h: 32, w: 372, fontSize: 14, fontWeight: 700, letterSpacing: 2.5, color: "token:onPrimary", opacity: 0.9 }) : null,
          text({ text: ai.title, role: "title", x: 64, y: 296, h: 220, w: 380, fontSize: Math.round(46 * hs), fontWeight: 700, lineHeight: 1.12, letterSpacing: -0.5, color: "token:onPrimary" }),
          ai.subtitle ? text({ text: ai.subtitle, x: 560, y: 300, h: 200, w: W - 560 - M, fontSize: 24, color: "token:textMuted", lineHeight: 1.5 }) : null,
        ].filter(Boolean) as SlideElement[],
      };
    case "heroGlance": {
      const pills = ai.pills ?? [];
      const glance = ai.bullets ?? [];
      const pillCols = ["token:primary", "token:accent", "token:secondary"];
      const pillW = 150, pillH = 46, pillGap = 14;
      const els: SlideElement[] = [
        shape({ shape: "rect", x: 764, y: 70, w: 4, h: H - 140, fill: "token:accent" }),
        ai.kicker ? text({ text: ai.kicker.toUpperCase(), x: M, y: 150, w: 640, h: 32, fontSize: 16, fontWeight: 700, letterSpacing: 3, color: "token:accent" }) : null,
        text({ text: ai.title, role: "title", x: M, y: 196, w: 640, h: 170, fontSize: Math.round(56 * hs), fontWeight: 800, lineHeight: 1.04, letterSpacing: -1, color: "token:text" }),
        ai.subtitle ? text({ text: ai.subtitle, x: M, y: 372, w: 630, h: 58, fontSize: 24, color: "token:text", opacity: 0.9, lineHeight: 1.3 }) : null,
        ai.body ? text({ text: ai.body, x: M, y: 434, w: 600, h: 80, fontSize: 16, color: "token:textMuted", lineHeight: 1.45 }) : null,
        ...pills.slice(0, 4).flatMap((p, i) => {
          const x = M + i * (pillW + pillGap);
          return [
            shape({ shape: "roundedRect", x, y: 538, w: pillW, h: pillH, radius: 8, fill: pillCols[i % pillCols.length] }),
            text({ text: p, x, y: 538, w: pillW, h: pillH, align: "center", valign: "middle", fontSize: 16, fontWeight: 700, color: "token:onPrimary" }),
          ];
        }),
        text({ text: "AT A GLANCE", x: 812, y: 120, w: 380, h: 30, fontSize: 15, fontWeight: 700, letterSpacing: 2, color: "token:textMuted" }),
        ...glance.slice(0, 6).flatMap((g, i) => {
          const y = 172 + i * 62;
          return [
            shape({ shape: "rect", x: 812, y: y + 4, w: 4, h: 22, fill: "token:accent" }),
            text({ text: g, x: 830, y, w: 366, h: 52, fontSize: 16, fontWeight: 600, color: "token:text", lineHeight: 1.2, valign: "middle" }),
          ];
        }),
      ].filter(Boolean) as SlideElement[];
      return { background: { type: "solid", color: "token:background" }, elements: els };
    }
    default: // "centered"
      return {
        background: { type: "gradient", gradient: ["token:background", "token:surface"], gradientAngle: 145 },
        elements: [
          shape({ shape: "blob", x: W - 460, y: -120, w: 620, h: 620, gradient: ["token:primary", "token:accent"], gradientAngle: 135, opacity: 0.85 }),
          shape({ shape: "ellipse", x: -120, y: H - 220, w: 360, h: 360, fill: "token:secondary", opacity: 0.14 }),
          ai.kicker ? text({ text: ai.kicker.toUpperCase(), role: "kicker", y: 206, h: 34, fontSize: 15, fontWeight: 700, letterSpacing: 3, color: "token:primary" }) : null,
          text({ text: ai.title, role: "title", y: 254, h: 200, w: 760, fontSize: Math.round(64 * hs), fontWeight: 700, lineHeight: 1.08, letterSpacing: -0.5 }),
          ai.subtitle ? text({ text: ai.subtitle, role: "subtitle", y: 474, h: 90, w: 700, fontSize: 24, color: "token:textMuted", lineHeight: 1.4 }) : null,
        ].filter(Boolean) as SlideElement[],
      };
  }
}

function column(items: string[], x: number, y: number, w: number): TextElement {
  return {
    id: id(),
    type: "text",
    x,
    y,
    w,
    h: 360,
    role: "bullet",
    listStyle: "bullet",
    items,
    text: items.join("\n"),
    fontSize: 24,
    lineHeight: 1.7,
    color: "token:text",
  };
}

const FULL_BLEED = new Set(["cover", "sectionHeader", "closing", "callout", "quote"]);

/** Build a positioned Slide from a semantic AISlide. Falls back to bullets. */
export function buildSlide(ai: AISlide, style: DeckStyle = DEFAULT_STYLE): Slide {
  activeStyle = style;
  const layout = builders[ai.layout] ? ai.layout : "bullets";
  const builder = builders[layout];
  const { background, elements } = builder(ai);
  // shrink any text that would overflow its box → decks never clip (editor + export)
  autofitSlide(elements);
  // safety net: pull stray content on-canvas + fix text-on-fill contrast (no overlap moves — layouts are tuned)
  repairSlide(elements, { fixOverlap: false });
  // prepend background decorations on content slides (full-bleed handle their own)
  const withDecor = FULL_BLEED.has(layout) ? elements : [...decor(), ...elements];
  activeStyle = DEFAULT_STYLE;
  return {
    id: id(),
    layout,
    background,
    elements: withDecor,
    notes: ai.notes,
    source: ai,
  };
}

/** Rebuild a slide's elements from its semantic source under a new layout,
 *  preserving the slide id and any edited notes. */
export function rebuildSlide(ai: AISlide, keepId: string, notes?: string, style: DeckStyle = DEFAULT_STYLE): Slide {
  const built = buildSlide({ ...ai }, style);
  return { ...built, id: keepId, notes: notes ?? built.notes };
}

export { id as newId };
