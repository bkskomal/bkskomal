import { clampToCanvas } from "./geometry";
import { readablePreferred, resolveColor } from "./color";
import { CANVAS } from "./utils";
import type { BrandKit, FooterPreset, HeaderPreset, SlideElement, Theme } from "./types";

/**
 * Header / footer chrome is computed at render/export time from the Brand Kit
 * rather than baked into each slide — so one change applies everywhere, every
 * template shares the SAME structure, and each picks up its theme colors (via
 * token:* fills). A curated set of PREMIUM PRESETS gives distinct, polished looks
 * (rule / band / minimal / sidebar / gradientBar for headers; line / band /
 * pageOnly / confidential for footers).
 *
 * Header AND footer are suppressed on full-bleed layouts (cover / section /
 * closing) so those stay clean; the logo may still float there.
 */
const FULL_BLEED = new Set(["cover", "sectionHeader", "closing"]);

const HEADER_H = 74;
const FOOTER_H = 44;

const resolveHeaderPreset = (b: BrandKit): HeaderPreset => b.headerPreset ?? (b.headerStyle === "band" ? "band" : "rule");
const resolveFooterPreset = (b: BrandKit): FooterPreset => b.footerPreset ?? (b.footerStyle === "band" ? "band" : "line");

export function brandChrome(
  brand: BrandKit,
  layout: string,
  pageIndex: number,
  pageCount: number,
  slideLogoScale?: number,
  theme?: Theme,
): SlideElement[] {
  const out: SlideElement[] = [];
  const W = CANVAS.w;
  const H = CANVAS.h;
  const pad = 40;
  const fullBleed = FULL_BLEED.has(layout);
  const logoSize = 48 * (slideLogoScale ?? brand.logoScale ?? 1);

  // ---------- header (content slides only) ----------
  if (brand.showHeader && !fullBleed) {
    out.push(...headerElements(resolveHeaderPreset(brand), brand, W, pad, logoSize, theme));
  }

  // logo floats on full-bleed slides (no header band there) — larger on the cover
  if (brand.logoUrl && fullBleed) {
    const top = brand.logoPlacement.startsWith("top");
    const left = brand.logoPlacement.endsWith("left");
    const ls = layout === "cover" ? logoSize * 1.8 : logoSize;
    const box = clampToCanvas(
      { x: left ? pad : W - pad - ls * 2.4, y: top ? pad : H - pad - ls, w: ls * 2.4, h: ls },
      6,
    );
    out.push({ id: "brand-logo", type: "image", brand: true, src: brand.logoUrl, fit: "contain", ...box, z: 42 });
  }

  // ---------- footer (content slides only) ----------
  if (brand.showFooter && !fullBleed) {
    out.push(...footerElements(resolveFooterPreset(brand), brand, W, H, pad, pageIndex, pageCount));
  }

  return out;
}

// ---------------------------------------------------------------- headers
/**
 * Design pattern from the OATI house style: a solid brand band with the logo on
 * the left, a bold title + a lighter subtitle beside it, and a thin accent rule
 * under the band. All text is DYNAMIC (headerText / headerSubtext); colors come
 * from the theme so it adapts to dark/light.
 */
const BANNER_H = 88;
function bannerHeader(brand: BrandKit, W: number, pad: number, logoSize: number, theme?: Theme): SlideElement[] {
  const out: SlideElement[] = [];
  out.push({ id: "brand-header-band", type: "shape", brand: true, shape: "rect", x: 0, y: 0, w: W, h: BANNER_H, fill: "token:surface", z: 40 });
  out.push({ id: "brand-header-rule", type: "shape", brand: true, shape: "rect", x: 0, y: BANNER_H, w: W, h: 4, fill: "token:accent", z: 41 });
  let x = pad;
  if (brand.logoUrl) {
    const box = clampToCanvas({ x: pad, y: (BANNER_H - logoSize) / 2, w: logoSize * 2.4, h: logoSize }, 6);
    out.push({ id: "brand-logo", type: "image", brand: true, src: brand.logoUrl, fit: "contain", ...box, z: 42 });
    x = box.x + box.w + 22;
  }
  const hasSub = !!brand.headerSubtext;
  if (brand.headerText) {
    out.push({
      id: "brand-header-text", type: "text", brand: true, text: brand.headerText,
      x, y: hasSub ? 18 : 0, w: W - x - pad, h: hasSub ? 34 : BANNER_H,
      align: "left", valign: hasSub ? "bottom" : "middle", fontSize: 26, fontWeight: 700, color: "token:text", z: 42,
    });
  }
  if (brand.headerSubtext) {
    // keep the accent-blue subtitle, but auto-fall-back if it wouldn't read on the band
    const subColor = theme
      ? readablePreferred(
          resolveColor("token:surface", theme, brand, "#1A2B4A"),
          resolveColor("token:secondary", theme, brand, "#2563EB"),
          [resolveColor("token:textMuted", theme, brand, "#8C9BAB"), resolveColor("token:text", theme, brand, "#FFFFFF")],
        )
      : "token:secondary";
    out.push({
      id: "brand-header-sub", type: "text", brand: true, text: brand.headerSubtext,
      x, y: 52, w: W - x - pad, h: 26, align: "left", valign: "top", fontSize: 14, fontWeight: 600, color: subColor, z: 42,
    });
  }
  return out;
}

function headerElements(preset: HeaderPreset, brand: BrandKit, W: number, pad: number, logoSize: number, theme?: Theme): SlideElement[] {
  if (preset === "banner") return bannerHeader(brand, W, pad, logoSize, theme);
  const out: SlideElement[] = [];
  const onGradient = preset === "gradientBar";
  const textColor = onGradient ? "token:onPrimary" : "token:textMuted";

  // background per preset
  if (preset === "band") {
    out.push({ id: "brand-header-band", type: "shape", brand: true, shape: "rect", x: 0, y: 0, w: W, h: HEADER_H, fill: "token:surface", z: 40 });
    out.push({ id: "brand-header-rule", type: "shape", brand: true, shape: "rect", x: 0, y: HEADER_H, w: W, h: 4, gradient: ["token:primary", "token:accent"], gradientAngle: 90, z: 41 });
  } else if (preset === "gradientBar") {
    out.push({ id: "brand-header-band", type: "shape", brand: true, shape: "rect", x: 0, y: 0, w: W, h: HEADER_H, gradient: ["token:primary", "token:accent"], gradientAngle: 90, z: 40 });
  } else if (preset === "rule") {
    out.push({ id: "brand-header-rule", type: "shape", brand: true, shape: "rect", x: 0, y: 0, w: W, h: 6, gradient: ["token:primary", "token:accent"], gradientAngle: 90, z: 41 });
  } else if (preset === "sidebar") {
    out.push({ id: "brand-header-side", type: "shape", brand: true, shape: "rect", x: 0, y: 0, w: 8, h: HEADER_H, gradient: ["token:primary", "token:accent"], gradientAngle: 0, z: 41 });
    out.push({ id: "brand-header-rule", type: "shape", brand: true, shape: "rect", x: 0, y: HEADER_H - 2, w: W, h: 2, fill: "token:accent", opacity: 0.35, z: 41 });
  } else if (preset === "minimal") {
    out.push({ id: "brand-header-rule", type: "shape", brand: true, shape: "rect", x: pad, y: HEADER_H - 2, w: W - pad * 2, h: 2, fill: "token:accent", opacity: 0.4, z: 41 });
  }

  const logoX = preset === "sidebar" ? pad + 20 : pad;
  if (brand.logoUrl) {
    const box = clampToCanvas({ x: logoX, y: (HEADER_H - logoSize) / 2, w: logoSize * 2.4, h: logoSize }, 6);
    out.push({ id: "brand-logo", type: "image", brand: true, src: brand.logoUrl, fit: "contain", ...box, z: 42 });
  }

  if (brand.headerText) {
    out.push({
      id: "brand-header-text",
      type: "text",
      brand: true,
      text: brand.headerText.toUpperCase(),
      x: W - 460,
      y: 0,
      w: 420,
      h: HEADER_H,
      align: "right",
      valign: "middle",
      fontSize: 14,
      fontWeight: 700,
      letterSpacing: 2,
      color: textColor,
      z: 42,
    });
  }
  return out;
}

// ---------------------------------------------------------------- footers
function footerElements(preset: FooterPreset, brand: BrandKit, W: number, H: number, pad: number, pageIndex: number, pageCount: number): SlideElement[] {
  const out: SlideElement[] = [];
  const y = H - FOOTER_H;
  const page = `${pageIndex + 1} / ${pageCount}`;

  if (preset === "band") {
    out.push({ id: "brand-footer-band", type: "shape", brand: true, shape: "rect", x: 0, y, w: W, h: FOOTER_H, fill: "token:surface", opacity: 0.9, z: 40 });
  } else if (preset === "line") {
    out.push({ id: "brand-footer-rule", type: "shape", brand: true, shape: "rect", x: pad, y, w: W - pad * 2, h: 2, fill: "token:accent", opacity: 0.3, z: 40 });
  }

  // pageOnly: a single centered page number, nothing else
  if (preset === "pageOnly") {
    out.push({ id: "brand-page", type: "text", brand: true, text: page, x: W / 2 - 100, y, w: 200, h: FOOTER_H, align: "center", valign: "middle", fontSize: 12, letterSpacing: 1, color: "token:textMuted", z: 42 });
    return out;
  }

  // confidential: an accent pill on the left, page on the right
  if (preset === "confidential") {
    const label = (brand.footerText || "Confidential").toUpperCase();
    const pillW = Math.min(260, 24 + label.length * 8.5);
    out.push({ id: "brand-footer-pill", type: "shape", brand: true, shape: "roundedRect", radius: 999, x: pad, y: y + 8, w: pillW, h: FOOTER_H - 16, fill: "token:accent", opacity: 0.16, z: 40 });
    out.push({ id: "brand-footer", type: "text", brand: true, text: label, x: pad, y: y + 8, w: pillW, h: FOOTER_H - 16, align: "center", valign: "middle", fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: "token:accent", z: 42 });
    out.push({ id: "brand-page", type: "text", brand: true, text: page, x: W - 140, y, w: 100, h: FOOTER_H, align: "right", valign: "middle", fontSize: 12, color: "token:textMuted", z: 42 });
    return out;
  }

  // line / band: footer text left, page right
  if (brand.footerText) {
    out.push({ id: "brand-footer", type: "text", brand: true, text: brand.footerText, x: pad, y, w: W - 240, h: FOOTER_H, valign: "middle", fontSize: 12, letterSpacing: 1, color: "token:textMuted", z: 42 });
  }
  if (brand.showPageNumbers) {
    out.push({ id: "brand-page", type: "text", brand: true, text: page, x: W - 140, y, w: 100, h: FOOTER_H, align: "right", valign: "middle", fontSize: 12, color: "token:textMuted", z: 42 });
  }
  return out;
}
