import type { BrandKit, ColorValue, Theme } from "./types";

/**
 * Resolve a ColorValue ("#hex" | "token:name" | "transparent") to a concrete
 * CSS/hex string, honoring Brand Kit overrides for primary/accent.
 */
export function resolveColor(
  value: ColorValue | undefined,
  theme: Theme,
  brand?: BrandKit,
  fallback = "transparent",
): string {
  if (!value) return fallback;
  if (value === "transparent") return "transparent";
  if (value.startsWith("#")) return value;

  if (value.startsWith("token:")) {
    const token = value.slice(6) as keyof Theme["colors"];
    if (token === "primary" && brand?.primaryColor) return brand.primaryColor;
    if (token === "accent" && brand?.accentColor) return brand.accentColor;
    const resolved = theme.colors[token];
    return resolved ?? fallback;
  }
  return value;
}

export function resolveFont(
  family: string | undefined,
  role: "heading" | "body",
  theme: Theme,
  brand?: BrandKit,
): string {
  if (family) return family;
  if (role === "heading") return brand?.fontHeading ?? theme.fonts.heading;
  return brand?.fontBody ?? theme.fonts.body;
}

/** Build a CSS gradient string from two colors + angle. */
export function gradientCss(
  from: string,
  to: string,
  angle = 135,
): string {
  return `linear-gradient(${angle}deg, ${from}, ${to})`;
}

function luminance(hex: string): number {
  const c = hex.replace("#", "");
  if (c.length < 6) return 0.5;
  const r = parseInt(c.slice(0, 2), 16);
  const g = parseInt(c.slice(2, 4), 16);
  const b = parseInt(c.slice(4, 6), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
}

/** Pick readable foreground (#fff/#111) for a given hex background. */
export function readableOn(hex: string): string {
  return luminance(hex) > 0.55 ? "#111111" : "#ffffff";
}

/** Keep `preferred` if it reads clearly on `bg`, else fall back to the best of `fallbacks`. */
export function readablePreferred(bg: string, preferred: string, fallbacks: string[]): string {
  return Math.abs(luminance(preferred) - luminance(bg)) >= 0.16 ? preferred : bestContrast(bg, fallbacks);
}

/** From candidate colors, pick the one with the most luminance contrast vs a background. */
export function bestContrast(bg: string, candidates: string[]): string {
  const lb = luminance(bg);
  let best = candidates[0] ?? "#ffffff";
  let bestDiff = -1;
  for (const c of candidates) {
    const d = Math.abs(luminance(c) - lb);
    if (d > bestDiff) { bestDiff = d; best = c; }
  }
  return best;
}
