import { nanoid } from "nanoid";
import { getTemplate } from "./templates";
import { buildSlide } from "./layouts";
import { repairSlide } from "./lint";
import { THEMES } from "./themes";
import { DEFAULT_STYLE } from "./styles";
import type { AIDeck } from "./schema";
import type { BrandKit, Deck, Template } from "./types";
import { CANVAS } from "./utils";

export const defaultBrand: BrandKit = {
  logoPlacement: "top-left",
  logoScale: 1,
  showPageNumbers: true,
  showHeader: true,
  showFooter: true,
  headerStyle: "bar",
  footerStyle: "band",
  footerText: "PROPRIETARY AND CONFIDENTIAL",
};

export function createDeckFromTemplate(
  template: Template,
  ctx: { title: string; subtitle?: string },
): Deck {
  const now = Date.now();
  const tb = template.brand ?? {};
  return {
    id: nanoid(10),
    title: ctx.title || template.name,
    subtitle: ctx.subtitle,
    size: { w: CANVAS.w, h: CANVAS.h },
    templateId: template.id,
    theme: template.theme,
    style: template.style,
    // bake in the template's brand; a banner header takes its title from the deck
    brand: { ...defaultBrand, ...tb, headerText: tb.headerText ?? (tb.headerPreset ? ctx.title || template.name : defaultBrand.headerText) },
    slides: template.build(ctx),
    createdAt: now,
    updatedAt: now,
  };
}

export interface ImportedDeck {
  title: string;
  size?: { w: number; h: number };
  slides: { id?: string; layout?: string; elements: unknown[] }[];
}

/** Wrap an imported .pptx (already-positioned elements) into an editable Deck. */
export function deckFromImport(raw: ImportedDeck): Deck {
  const now = Date.now();
  return {
    id: nanoid(10),
    title: raw.title || "Imported presentation",
    size: { w: CANVAS.w, h: CANVAS.h },
    theme: THEMES.midnight,
    style: DEFAULT_STYLE,
    // imported slides carry their own baked layout/colors — don't overlay header/footer chrome
    brand: { ...defaultBrand, showHeader: false, showFooter: false, footerText: undefined },
    slides: (raw.slides ?? []).map((s) => {
      const elements = (s.elements ?? []) as Deck["slides"][number]["elements"];
      // imported decks are messy — clamp off-canvas, fix contrast, and un-overlap
      repairSlide(elements, { clampOffCanvas: true, fixContrast: true, fixOverlap: true });
      return { id: s.id || nanoid(8), layout: s.layout || "bullets", elements };
    }),
    createdAt: now,
    updatedAt: now,
  };
}

/** Derive cover action-pills from the deck's section titles (leading words). */
function derivePills(slides: { layout: string; title?: string }[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const s of slides) {
    if (s.layout === "cover" || s.layout === "closing" || !s.title) continue;
    const first = s.title.trim().split(/\s+/)[0].replace(/[^A-Za-z]/g, "");
    const key = first.toLowerCase();
    if (first.length < 3 || first.length > 12 || seen.has(key)) continue;
    seen.add(key);
    out.push(first);
    if (out.length >= 4) break;
  }
  return out;
}

/** Build a Deck from AI output, keeping the (already chosen) template's theme. */
export function deckFromAI(ai: AIDeck, templateId?: string): Deck {
  const now = Date.now();
  const template = templateId ? getTemplate(templateId) : undefined;
  const style = template?.style ?? DEFAULT_STYLE;
  const tb = template?.brand ?? {};
  // hero cover with no pills → derive them from the deck's section verbs
  const slides = ai.slides.map((s) => ({ ...s }));
  if (style.cover === "heroGlance") {
    const cover = slides.find((s) => s.layout === "cover");
    if (cover && !(cover.pills && cover.pills.length)) cover.pills = derivePills(slides);
  }
  return {
    id: nanoid(10),
    title: ai.title,
    subtitle: ai.subtitle,
    size: { w: CANVAS.w, h: CANVAS.h },
    templateId,
    theme: template?.theme ?? THEMES.midnight,
    style,
    brand: { ...defaultBrand, ...tb, headerText: tb.headerText ?? (tb.headerPreset ? ai.title : defaultBrand.headerText) },
    slides: slides.map((s) => buildSlide(s, style)),
    createdAt: now,
    updatedAt: now,
  };
}
