import { newId } from "./layouts";
import { withDb } from "./db";

/**
 * Conversation/message persistence + preference & eval capture.
 * All calls no-op gracefully when the DB is unavailable.
 */

/** Store one user→assistant turn (upserts the conversation). */
export async function saveTurn(input: {
  userId: string;
  convId?: string;
  userMessage: string;
  assistantMessage: string;
  model: string;
}): Promise<void> {
  if (!input.convId || (!input.userMessage && !input.assistantMessage)) return;
  await withDb(async (p) => {
    await p.query(
      `INSERT INTO conversations (id, user_id, title)
       VALUES ($1,$2,$3) ON CONFLICT (id) DO NOTHING`,
      [input.convId, input.userId, input.userMessage.slice(0, 60) || "Chat"],
    );
    if (input.userMessage)
      await p.query(
        `INSERT INTO messages (id, conversation_id, user_id, role, content, model) VALUES ($1,$2,$3,'user',$4,$5)`,
        [newId(), input.convId, input.userId, input.userMessage, input.model],
      );
    if (input.assistantMessage)
      await p.query(
        `INSERT INTO messages (id, conversation_id, user_id, role, content, model) VALUES ($1,$2,$3,'assistant',$4,$5)`,
        [newId(), input.convId, input.userId, input.assistantMessage, input.model],
      );
    return true;
  }, undefined);
}

/** A (prompt, rejected, chosen) preference pair — training data for DPO/LoRA. */
export async function savePreference(input: {
  userId: string;
  prompt: string;
  rejected: string;
  chosen: string;
  model: string;
}): Promise<void> {
  if (!input.prompt.trim() || !input.chosen.trim() || input.rejected === input.chosen) return;
  await withDb(async (p) => {
    await p.query(
      `INSERT INTO preference_pairs (id, user_id, prompt, rejected, chosen, model) VALUES ($1,$2,$3,$4,$5,$6)`,
      [newId(), input.userId, input.prompt, input.rejected, input.chosen, input.model],
    );
    return true;
  }, undefined);
}

export async function saveEval(input: { userId: string; skill: string; prompt: string; expected: string }): Promise<void> {
  if (!input.prompt.trim()) return;
  await withDb(async (p) => {
    await p.query(`INSERT INTO evals (id, user_id, skill, prompt, expected) VALUES ($1,$2,$3,$4,$5)`, [
      newId(),
      input.userId,
      input.skill,
      input.prompt,
      input.expected,
    ]);
    return true;
  }, undefined);
}

export interface EvalCase {
  id: string;
  prompt: string;
  expected: string;
  skill: string;
}

export async function listEvals(): Promise<EvalCase[]> {
  return withDb(
    async (p) => (await p.query("SELECT id, prompt, expected, skill FROM evals ORDER BY created_at")).rows as EvalCase[],
    [],
  );
}

export interface EvalResult {
  evalId: string;
  prompt: string;
  score: number;
  pass: boolean;
  reason: string;
  reply: string;
}
export interface EvalRunSummary {
  id: string;
  total: number;
  passed: number;
  avgScore: number;
  model: string;
  createdAt?: string;
}

/** Persist an eval run + its per-case results. */
export async function saveEvalRun(run: EvalRunSummary, results: EvalResult[]): Promise<void> {
  await withDb(async (p) => {
    await p.query("INSERT INTO eval_runs (id, total, passed, avg_score, model) VALUES ($1,$2,$3,$4,$5)", [
      run.id, run.total, run.passed, run.avgScore, run.model,
    ]);
    for (const r of results) {
      await p.query(
        "INSERT INTO eval_results (id, run_id, eval_id, prompt, score, pass, reason, reply) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",
        [newId(), run.id, r.evalId, r.prompt, r.score, r.pass, r.reason, r.reply.slice(0, 4000)],
      );
    }
    return true;
  }, undefined);
}

/** The most recent eval run (for the admin dashboard). */
export async function latestEvalRun(): Promise<EvalRunSummary | null> {
  return withDb(async (p) => {
    const r = await p.query("SELECT id, total, passed, avg_score, model, created_at FROM eval_runs ORDER BY created_at DESC LIMIT 1");
    if (!r.rowCount) return null;
    const x = r.rows[0];
    return { id: x.id, total: x.total, passed: x.passed, avgScore: x.avg_score, model: x.model, createdAt: x.created_at };
  }, null);
}

/** Counts for the admin Training-data view. */
export async function trainingCounts(): Promise<{ messages: number; preferences: number; evals: number }> {
  return withDb(
    async (p) => {
      const m = await p.query("SELECT count(*)::int AS n FROM messages");
      const pr = await p.query("SELECT count(*)::int AS n FROM preference_pairs");
      const ev = await p.query("SELECT count(*)::int AS n FROM evals");
      return { messages: m.rows[0].n, preferences: pr.rows[0].n, evals: ev.rows[0].n };
    },
    { messages: 0, preferences: 0, evals: 0 },
  );
}
