import { buildSlide } from "./layouts";
import { THEMES } from "./themes";
import { STYLE_LIST } from "./styles";
import type { AISlide } from "./schema";
import type { BrandKit, DeckStyle, Slide, Template, TemplateBuildContext, TemplateCategory } from "./types";

/**
 * The template gallery. Templates are data-driven: a theme + a flavored set of
 * starter slides. Adding a new one is one descriptor entry — this is how the
 * library scales toward (and past) 50 without bespoke code each time.
 */

interface Descriptor {
  id: string;
  name: string;
  category: TemplateCategory;
  themeId: keyof typeof THEMES;
  description: string;
  tags: string[];
  /** content flavor used to seed the starter deck */
  flavor: Flavor;
  /** optional explicit style (else spread across presets) */
  style?: DeckStyle;
  /** optional baked-in brand kit (banner header, logo, footer…) */
  brand?: Partial<BrandKit>;
}

type Flavor =
  | "pitch"
  | "report"
  | "marketing"
  | "lesson"
  | "story"
  | "minimal"
  | "data"
  | "portfolio"
  | "platform";

/** Sample starter content per flavor — replaced the moment the user runs AI or edits. */
function starterSlides(flavor: Flavor, ctx: TemplateBuildContext): AISlide[] {
  const title = ctx.title || "Your Presentation";
  const subtitle = ctx.subtitle || "Made with PPTMaker";
  const base: Record<Flavor, AISlide[]> = {
    pitch: [
      { layout: "cover", kicker: "Pitch Deck", title, subtitle },
      { layout: "bullets", kicker: "Problem", title: "The problem we solve", bullets: ["Today's solutions are slow and costly", "Users are frustrated and switching", "The market is wide open"] },
      { layout: "stat", kicker: "Opportunity", title: "A massive market", stat: { value: "$12B", label: "Addressable market by 2030" } },
      { layout: "imageRight", kicker: "Product", title: "How it works", body: "A delightfully simple flow that gets users to value in seconds.", bullets: ["Sign up in one click", "AI does the heavy lifting", "Share anywhere"] },
      { layout: "closing", title: "Let's build the future", subtitle: "hello@yourcompany.com" },
    ],
    report: [
      { layout: "cover", kicker: "Quarterly Review", title, subtitle },
      { layout: "twoColumn", title: "Highlights & lowlights", bullets: ["Revenue up 24% QoQ", "Churn down to 1.8%", "Launched 3 features", "Hiring behind plan", "Infra costs rising", "NPS at 62"] },
      { layout: "stat", kicker: "Growth", title: "Revenue", stat: { value: "+24%", label: "Quarter over quarter" } },
      { layout: "bullets", kicker: "Next quarter", title: "Where we focus", bullets: ["Enterprise readiness", "Self-serve onboarding", "Cost optimization"] },
      { layout: "closing", title: "Questions?", subtitle: "Thank you" },
    ],
    marketing: [
      { layout: "cover", kicker: "Campaign", title, subtitle },
      { layout: "sectionHeader", kicker: "The big idea", title: "Make them feel something" },
      { layout: "bullets", kicker: "Audience", title: "Who we're talking to", bullets: ["Busy professionals 25-40", "Mobile-first", "Value speed over everything"] },
      { layout: "quote", title: "Testimonial", quote: "This completely changed how our team works.", attribution: "A very happy customer" },
      { layout: "closing", title: "Let's launch", subtitle: "#MadeWithPPTMaker" },
    ],
    lesson: [
      { layout: "cover", kicker: "Lesson", title, subtitle },
      { layout: "bullets", kicker: "Objectives", title: "By the end you'll know", bullets: ["The core concept", "Why it matters", "How to apply it"] },
      { layout: "twoColumn", title: "Key terms", bullets: ["Definition one", "Definition two", "Definition three", "Definition four"] },
      { layout: "quote", title: "Why it matters", quote: "Tell me and I forget. Teach me and I remember. Involve me and I learn.", attribution: "Benjamin Franklin" },
      { layout: "closing", title: "Great work!", subtitle: "Questions welcome" },
    ],
    story: [
      { layout: "cover", kicker: "A Story", title, subtitle },
      { layout: "sectionHeader", kicker: "Chapter 1", title: "Where it begins" },
      { layout: "imageRight", title: "The turning point", body: "Every great story has a moment everything changes.", bullets: ["Setup", "Conflict", "Resolution"] },
      { layout: "quote", title: "A thought", quote: "The best way to predict the future is to create it.", attribution: "Peter Drucker" },
      { layout: "closing", title: "The end", subtitle: "...or the beginning?" },
    ],
    minimal: [
      { layout: "cover", title, subtitle },
      { layout: "bullets", title: "Three things", bullets: ["First", "Second", "Third"] },
      { layout: "stat", title: "One number that matters", stat: { value: "100%", label: "Focus" } },
      { layout: "quote", title: "On simplicity", quote: "Simplicity is the ultimate sophistication.", attribution: "Leonardo da Vinci" },
      { layout: "closing", title: "Thank you" },
    ],
    data: [
      { layout: "cover", kicker: "Data Story", title, subtitle },
      { layout: "stat", kicker: "Headline", title: "The number to remember", stat: { value: "3.2x", label: "Faster than last year" } },
      { layout: "twoColumn", title: "What the data shows", bullets: ["Trend is up and to the right", "Driven by segment B", "Cohorts retain better", "Seasonality matters", "Outliers explained", "Confidence high"] },
      { layout: "bullets", kicker: "So what", title: "Recommendations", bullets: ["Double down on segment B", "Fix the leaky funnel", "Re-run in 30 days"] },
      { layout: "closing", title: "Discussion", subtitle: "Let's dig in" },
    ],
    portfolio: [
      { layout: "cover", kicker: "Portfolio", title, subtitle },
      { layout: "sectionHeader", kicker: "Selected work", title: "Things I'm proud of" },
      { layout: "imageRight", title: "Project spotlight", body: "A short description of the project, the role, and the impact.", bullets: ["Role: Lead", "Impact: +40%", "Year: 2026"] },
      { layout: "quote", title: "Design philosophy", quote: "Design is intelligence made visible.", attribution: "Alina Wheeler" },
      { layout: "closing", title: "Let's work together", subtitle: "you@portfolio.com" },
    ],
    // OATI house style: hero cover + component grid, banner header, navy/red theme
    platform: [
      {
        layout: "cover", kicker: "AI-Native Platform", title, subtitle,
        body: "Protecting sensitive data across endpoints, email, web, network & cloud — with explainable, AI-assisted enforcement.",
        pills: ["Detect", "Classify", "Enforce", "Discover"],
        bullets: ["Rules + AI two-tier detection", "Explainable verdicts", "Endpoint · Web · Mail · Network", "Data-at-rest discovery", "GenAI / LLM guardrails", "Real-time modern console"],
      },
      {
        layout: "cardGrid", kicker: "Components", title: "What makes up the platform",
        steps: [
          { title: "Detection Engine", description: "Classifies content; explainable" },
          { title: "Endpoint Agent", description: "Files / USB / clipboard" },
          { title: "Web Guard", description: "Blocks uploads / forms" },
          { title: "Mail Gateway", description: "SMTP body + attachments" },
          { title: "DSPM Scanner", description: "Data-at-rest discovery" },
          { title: "Control Plane", description: "Policy, decisions, RBAC, audit" },
          { title: "AI Scrutiny", description: "Tier-2 model adjudication" },
          { title: "Console", description: "Real-time admin & analyst UI" },
        ],
      },
      {
        layout: "process", kicker: "How it works", title: "Detect → decide → enforce",
        steps: [
          { title: "Inspect", description: "Content is classified inline" },
          { title: "Adjudicate", description: "Rules first, AI for the hard cases" },
          { title: "Enforce", description: "Block, quarantine or redact" },
        ],
      },
      {
        layout: "statGrid", kicker: "At a glance", title: "By the numbers",
        stats: [{ value: "2-tier", label: "Rules + AI detection" }, { value: "5", label: "Enforcement surfaces" }, { value: "Real-time", label: "Analyst console" }],
      },
      { layout: "closing", title: "Thank you", subtitle: "Protect what matters" },
    ],
  };
  return base[flavor];
}

const DESCRIPTORS: Descriptor[] = [
  // --- Pitch ---
  { id: "pitch-midnight", name: "Midnight Pitch", category: "Pitch", themeId: "midnight", flavor: "pitch", description: "Bold, investor-ready dark deck with gradient accents.", tags: ["startup", "investor", "dark", "bold"] },
  { id: "pitch-aurora", name: "Aurora Launch", category: "Pitch", themeId: "aurora", flavor: "pitch", description: "Vibrant gradients for product launches.", tags: ["launch", "product", "gradient"] },
  { id: "pitch-slate", name: "Slate Ventures", category: "Pitch", themeId: "slate", flavor: "pitch", description: "Sharp, technical, VC-grade.", tags: ["vc", "tech", "dark"] },
  { id: "pitch-carbon", name: "Carbon Bold", category: "Pitch", themeId: "carbon", flavor: "pitch", description: "High-contrast black with electric yellow.", tags: ["bold", "contrast", "modern"] },
  { id: "pitch-ocean", name: "Ocean Seed", category: "Pitch", themeId: "ocean", flavor: "pitch", description: "Calm, trustworthy blues for early-stage.", tags: ["seed", "trust", "blue"] },
  { id: "pitch-royal", name: "Royal Raise", category: "Pitch", themeId: "royal", flavor: "pitch", description: "Premium indigo + gold for Series A.", tags: ["premium", "gold", "raise"] },
  { id: "pitch-coral", name: "Coral Hype", category: "Pitch", themeId: "coral", flavor: "pitch", description: "Energetic red for consumer brands.", tags: ["consumer", "energetic", "red"] },
  { id: "pitch-forest", name: "Forest Impact", category: "Pitch", themeId: "forest", flavor: "pitch", description: "Green, mission-driven and sustainable.", tags: ["impact", "green", "mission"] },

  // --- Business ---
  { id: "biz-mono", name: "Mono Report", category: "Business", themeId: "mono", flavor: "report", description: "Clean monochrome for quarterly reviews.", tags: ["report", "corporate", "clean"] },
  { id: "biz-paper", name: "Executive Paper", category: "Business", themeId: "paper", flavor: "report", description: "Editorial serif headings, board-ready.", tags: ["executive", "serif", "board"] },
  { id: "biz-ocean", name: "Ocean Briefing", category: "Business", themeId: "ocean", flavor: "report", description: "Professional blue corporate briefing.", tags: ["briefing", "corporate", "blue"] },
  { id: "biz-slate", name: "Slate Operations", category: "Business", themeId: "slate", flavor: "report", description: "Dark ops dashboard aesthetic.", tags: ["ops", "dark", "dashboard"] },
  { id: "biz-forest", name: "Forest Strategy", category: "Business", themeId: "forest", flavor: "report", description: "Grounded green strategy deck.", tags: ["strategy", "green"] },
  { id: "biz-royal", name: "Royal Boardroom", category: "Business", themeId: "royal", flavor: "report", description: "Prestige indigo for the boardroom.", tags: ["board", "prestige"] },
  { id: "biz-midnight", name: "Midnight Metrics", category: "Business", themeId: "midnight", flavor: "report", description: "Dark deck built around the numbers.", tags: ["metrics", "dark"] },
  { id: "biz-sunset", name: "Sunset Update", category: "Business", themeId: "sunset", flavor: "report", description: "Warm, human company update.", tags: ["update", "warm"] },
  { id: "biz-boardroom", name: "Boardroom", category: "Business", themeId: "boardroom", flavor: "report", description: "Navy + red corporate boardroom deck.", tags: ["boardroom", "corporate", "navy", "executive"] },
  {
    id: "biz-oati-platform", name: "OATI Platform", category: "Business", themeId: "boardroom", flavor: "platform",
    description: "OATI house style — banner header, navy/red theme, hero cover + component grid.",
    tags: ["oati", "platform", "product", "corporate", "navy", "banner", "dlp"],
    style: { cover: "heroGlance", bg: "plain", accent: "line", headScale: 1, bodyScale: 1, radius: 14 },
    brand: { headerPreset: "banner", footerPreset: "band", showHeader: true, showFooter: true, showPageNumbers: true, footerText: "PROPRIETARY AND CONFIDENTIAL", logoUrl: "/oati-logo.png", logoScale: 1.1 },
  },
  { id: "biz-executive", name: "Executive Brief", category: "Business", themeId: "executive", flavor: "report", description: "Crisp light executive briefing.", tags: ["executive", "brief", "corporate", "light"] },

  // --- Marketing ---
  { id: "mkt-coral", name: "Coral Campaign", category: "Marketing", themeId: "coral", flavor: "marketing", description: "Punchy campaign deck that pops.", tags: ["campaign", "punchy", "red"] },
  { id: "mkt-sunset", name: "Sunset Brand", category: "Marketing", themeId: "sunset", flavor: "marketing", description: "Warm gradients for brand stories.", tags: ["brand", "warm", "gradient"] },
  { id: "mkt-blossom", name: "Blossom Social", category: "Marketing", themeId: "blossom", flavor: "marketing", description: "Playful pink for social campaigns.", tags: ["social", "playful", "pink"] },
  { id: "mkt-aurora", name: "Aurora Growth", category: "Marketing", themeId: "aurora", flavor: "marketing", description: "Growth-team gradients.", tags: ["growth", "gradient"] },
  { id: "mkt-midnight", name: "Midnight Drop", category: "Marketing", themeId: "midnight", flavor: "marketing", description: "Hype reveal for a big drop.", tags: ["hype", "reveal", "dark"] },
  { id: "mkt-ocean", name: "Ocean Funnel", category: "Marketing", themeId: "ocean", flavor: "marketing", description: "Clean blue for performance marketing.", tags: ["performance", "funnel"] },
  { id: "mkt-carbon", name: "Carbon Promo", category: "Marketing", themeId: "carbon", flavor: "marketing", description: "Bold black promo deck.", tags: ["promo", "bold"] },

  // --- Education ---
  { id: "edu-forest", name: "Forest Classroom", category: "Education", themeId: "forest", flavor: "lesson", description: "Friendly green for lessons.", tags: ["lesson", "school", "green"] },
  { id: "edu-ocean", name: "Ocean Lecture", category: "Education", themeId: "ocean", flavor: "lesson", description: "Calm blue lecture template.", tags: ["lecture", "university"] },
  { id: "edu-paper", name: "Paper Seminar", category: "Education", themeId: "paper", flavor: "lesson", description: "Academic serif seminar.", tags: ["seminar", "academic", "serif"] },
  { id: "edu-sunset", name: "Sunset Workshop", category: "Education", themeId: "sunset", flavor: "lesson", description: "Warm, hands-on workshop vibe.", tags: ["workshop", "warm"] },
  { id: "edu-blossom", name: "Blossom Kids", category: "Education", themeId: "blossom", flavor: "lesson", description: "Bright and fun for younger learners.", tags: ["kids", "fun", "bright"] },
  { id: "edu-mono", name: "Mono Course", category: "Education", themeId: "mono", flavor: "lesson", description: "Distraction-free online course.", tags: ["course", "online", "clean"] },

  // --- Creative ---
  { id: "cre-blossom", name: "Blossom Story", category: "Creative", themeId: "blossom", flavor: "story", description: "Romantic pink storytelling.", tags: ["story", "pink"] },
  { id: "cre-royal", name: "Royal Tale", category: "Creative", themeId: "royal", flavor: "story", description: "Cinematic indigo + gold narrative.", tags: ["cinematic", "narrative"] },
  { id: "cre-sunset", name: "Sunset Journey", category: "Creative", themeId: "sunset", flavor: "story", description: "Warm journey storytelling.", tags: ["journey", "warm"] },
  { id: "cre-aurora", name: "Aurora Dreams", category: "Creative", themeId: "aurora", flavor: "story", description: "Dreamy gradient narrative.", tags: ["dreamy", "gradient"] },
  { id: "cre-carbon", name: "Carbon Noir", category: "Creative", themeId: "carbon", flavor: "story", description: "Moody black-and-yellow noir.", tags: ["noir", "moody"] },
  { id: "cre-coral", name: "Coral Pop", category: "Creative", themeId: "coral", flavor: "story", description: "Pop-art energy.", tags: ["pop", "energetic"] },

  // --- Minimal ---
  { id: "min-mono", name: "Pure Mono", category: "Minimal", themeId: "mono", flavor: "minimal", description: "Maximum focus, zero noise.", tags: ["minimal", "focus", "mono"] },
  { id: "min-paper", name: "Paper Minimal", category: "Minimal", themeId: "paper", flavor: "minimal", description: "Whitespace-first elegance.", tags: ["minimal", "whitespace"] },
  { id: "min-slate", name: "Slate Minimal", category: "Minimal", themeId: "slate", flavor: "minimal", description: "Dark minimalism.", tags: ["minimal", "dark"] },
  { id: "min-ocean", name: "Ocean Minimal", category: "Minimal", themeId: "ocean", flavor: "minimal", description: "Quiet blue minimalism.", tags: ["minimal", "blue"] },
  { id: "min-forest", name: "Forest Minimal", category: "Minimal", themeId: "forest", flavor: "minimal", description: "Calm green minimalism.", tags: ["minimal", "green"] },

  // --- Data ---
  { id: "data-slate", name: "Slate Analytics", category: "Data", themeId: "slate", flavor: "data", description: "Dark analytics storytelling.", tags: ["analytics", "dark", "charts"] },
  { id: "data-ocean", name: "Ocean Insights", category: "Data", themeId: "ocean", flavor: "data", description: "Trustworthy blue data deck.", tags: ["insights", "blue"] },
  { id: "data-mono", name: "Mono Metrics", category: "Data", themeId: "mono", flavor: "data", description: "Clean metrics, no clutter.", tags: ["metrics", "clean"] },
  { id: "data-midnight", name: "Midnight Dashboard", category: "Data", themeId: "midnight", flavor: "data", description: "Glowing KPIs on dark.", tags: ["kpi", "dashboard", "dark"] },
  { id: "data-carbon", name: "Carbon Figures", category: "Data", themeId: "carbon", flavor: "data", description: "High-contrast figures.", tags: ["figures", "contrast"] },

  // --- Portfolio ---
  { id: "port-paper", name: "Paper Portfolio", category: "Portfolio", themeId: "paper", flavor: "portfolio", description: "Editorial portfolio for designers.", tags: ["portfolio", "designer", "serif"] },
  { id: "port-carbon", name: "Carbon Showcase", category: "Portfolio", themeId: "carbon", flavor: "portfolio", description: "Bold black showcase.", tags: ["showcase", "bold"] },
  { id: "port-blossom", name: "Blossom Folio", category: "Portfolio", themeId: "blossom", flavor: "portfolio", description: "Soft pink creative folio.", tags: ["folio", "creative"] },
  { id: "port-aurora", name: "Aurora Creative", category: "Portfolio", themeId: "aurora", flavor: "portfolio", description: "Gradient creative portfolio.", tags: ["creative", "gradient"] },
  { id: "port-royal", name: "Royal Studio", category: "Portfolio", themeId: "royal", flavor: "portfolio", description: "Luxe studio portfolio.", tags: ["studio", "luxe"] },
];

function toTemplate(d: Descriptor, idx: number): Template {
  // spread distinct style presets across templates (coprime stride) so even
  // same-theme templates look different in cover, background, accent & type.
  const style = d.style ?? STYLE_LIST[(idx * 7) % STYLE_LIST.length];
  return {
    id: d.id,
    name: d.name,
    category: d.category,
    description: d.description,
    tags: d.tags,
    theme: THEMES[d.themeId],
    style,
    brand: d.brand,
    build: (ctx): Slide[] => starterSlides(d.flavor, ctx).map((s) => buildSlide(s, style)),
  };
}

export const TEMPLATES: Template[] = DESCRIPTORS.map(toTemplate);

export const TEMPLATE_CATEGORIES: TemplateCategory[] = [
  "Pitch",
  "Business",
  "Marketing",
  "Education",
  "Creative",
  "Minimal",
  "Data",
  "Portfolio",
];

export function getTemplate(id: string): Template | undefined {
  return TEMPLATES.find((t) => t.id === id);
}
