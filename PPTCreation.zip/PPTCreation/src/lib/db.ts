import { Pool } from "pg";

/**
 * Server-only Postgres access for the self-learning backend.
 *
 * Everything degrades gracefully: if DATABASE_URL is unset or the DB is
 * unreachable, `withDb` returns null and callers fall back to local behavior —
 * the app never breaks when Postgres isn't running.
 *
 * Configure in .env.local:
 *   DATABASE_URL=postgres://user:pass@localhost:55432/oatigenie
 *   EMBED_DIM=768   (must match your embedding model's dimension)
 */
let pool: Pool | null = null;
let schemaReady = false;
let disabled = false;

export const EMBED_DIM = Number(process.env.EMBED_DIM || 768);

function getPool(): Pool | null {
  if (disabled) return null;
  if (!process.env.DATABASE_URL) {
    disabled = true;
    return null;
  }
  if (!pool) {
    pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 5, connectionTimeoutMillis: 4000 });
    pool.on("error", () => {});
  }
  return pool;
}

const SCHEMA = `
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE IF NOT EXISTS app_users (
  id TEXT PRIMARY KEY, email TEXT UNIQUE, name TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY, user_id TEXT, title TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY, conversation_id TEXT, user_id TEXT, role TEXT, content TEXT,
  model TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, user_id TEXT, conv_id TEXT, rating TEXT, model TEXT,
  prompt TEXT, answer TEXT, reason TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS exemplars (
  id TEXT PRIMARY KEY, user_id TEXT, skill TEXT, prompt TEXT, answer TEXT,
  embedding vector(${EMBED_DIM}), upvotes INT DEFAULT 1, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS exemplars_embed_idx ON exemplars USING hnsw (embedding vector_cosine_ops);
CREATE TABLE IF NOT EXISTS preference_pairs (
  id TEXT PRIMARY KEY, user_id TEXT, prompt TEXT, rejected TEXT, chosen TEXT,
  model TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS evals (
  id TEXT PRIMARY KEY, user_id TEXT, skill TEXT, prompt TEXT, expected TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS decks (
  id TEXT PRIMARY KEY, user_id TEXT, title TEXT, data JSONB,
  share_token TEXT UNIQUE, updated_at TIMESTAMPTZ DEFAULT now(), created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS decks_user_idx ON decks (user_id, updated_at DESC);
CREATE TABLE IF NOT EXISTS deck_versions (
  id TEXT PRIMARY KEY, deck_id TEXT, title TEXT, data JSONB, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS deck_versions_idx ON deck_versions (deck_id, created_at DESC);
CREATE TABLE IF NOT EXISTS eval_runs (
  id TEXT PRIMARY KEY, total INT, passed INT, avg_score REAL, model TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS eval_results (
  id TEXT PRIMARY KEY, run_id TEXT, eval_id TEXT, prompt TEXT, score REAL, pass BOOLEAN,
  reason TEXT, reply TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS eval_results_run_idx ON eval_results (run_id);
CREATE TABLE IF NOT EXISTS org_config (
  id TEXT PRIMARY KEY, data JSONB, updated_at TIMESTAMPTZ DEFAULT now()
);
`;

async function ensureSchema(p: Pool): Promise<boolean> {
  if (schemaReady) return true;
  try {
    await p.query(SCHEMA);
    schemaReady = true;
    return true;
  } catch (e) {
    // pgvector missing / no perms / unreachable — disable DB features quietly
    console.warn("[db] schema init failed, disabling DB features:", (e as Error).message);
    disabled = true;
    return false;
  }
}

/** Run `fn` with a ready pool, or return `fallback` if the DB is unavailable. */
export async function withDb<T>(fn: (p: Pool) => Promise<T>, fallback: T): Promise<T> {
  const p = getPool();
  if (!p) return fallback;
  if (!(await ensureSchema(p))) return fallback;
  try {
    return await fn(p);
  } catch (e) {
    console.warn("[db] query failed:", (e as Error).message);
    return fallback;
  }
}

export function dbEnabled(): boolean {
  return !disabled && !!process.env.DATABASE_URL;
}
