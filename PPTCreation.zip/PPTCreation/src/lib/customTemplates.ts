import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { nanoid } from "nanoid";
import { newId } from "./layouts";
import { idbStorage } from "./idbStorage";
import { CANVAS } from "./utils";
import type { BrandKit, Deck, DeckStyle, Slide, TemplateCategory, Theme } from "./types";

/**
 * User-created templates. Any deck — including an imported .pptx — can be saved
 * as a reusable template (its theme, style, brand and positioned slides). New
 * decks are then spun up from it. Persisted to IndexedDB (decks hold images).
 */
export interface CustomTemplate {
  id: string;
  name: string;
  description?: string;
  category: TemplateCategory;
  createdAt: number;
  updatedAt: number;
  payload: {
    subtitle?: string;
    theme: Theme;
    style?: DeckStyle;
    brand: BrandKit;
    slides: Slide[];
  };
}

/** Snapshot a deck into a template payload (deep-cloned, no shared refs). */
export function captureDeck(deck: Deck): CustomTemplate["payload"] {
  return JSON.parse(JSON.stringify({ subtitle: deck.subtitle, theme: deck.theme, style: deck.style, brand: deck.brand, slides: deck.slides }));
}

/** Instantiate a fresh, editable Deck from a saved template (new ids throughout). */
export function deckFromCustomTemplate(t: CustomTemplate, title?: string): Deck {
  const now = Date.now();
  const p = JSON.parse(JSON.stringify(t.payload)) as CustomTemplate["payload"];
  return {
    id: nanoid(10),
    title: title?.trim() || t.name,
    subtitle: p.subtitle,
    size: { w: CANVAS.w, h: CANVAS.h },
    templateId: t.id,
    theme: p.theme,
    style: p.style,
    brand: p.brand,
    slides: p.slides.map((s) => ({ ...s, id: newId(), elements: s.elements.map((e) => ({ ...e, id: newId() })) })),
    createdAt: now,
    updatedAt: now,
  };
}

interface CustomTemplateState {
  templates: Record<string, CustomTemplate>;
  /** create a new template from a deck; returns its id */
  saveFromDeck: (deck: Deck, meta: { name: string; category: TemplateCategory; description?: string }) => string;
  /** overwrite an existing template's design from a deck */
  updateFromDeck: (id: string, deck: Deck) => void;
  rename: (id: string, name: string) => void;
  remove: (id: string) => void;
}

export const useCustomTemplates = create<CustomTemplateState>()(
  persist(
    (set) => ({
      templates: {},
      saveFromDeck: (deck, meta) => {
        const id = nanoid(10);
        const now = Date.now();
        const t: CustomTemplate = { id, name: meta.name.trim() || "Untitled template", description: meta.description, category: meta.category, createdAt: now, updatedAt: now, payload: captureDeck(deck) };
        set((s) => ({ templates: { ...s.templates, [id]: t } }));
        return id;
      },
      updateFromDeck: (id, deck) =>
        set((s) => (s.templates[id] ? { templates: { ...s.templates, [id]: { ...s.templates[id], payload: captureDeck(deck), updatedAt: Date.now() } } } : s)),
      rename: (id, name) =>
        set((s) => (s.templates[id] ? { templates: { ...s.templates, [id]: { ...s.templates[id], name: name.trim() || s.templates[id].name, updatedAt: Date.now() } } } : s)),
      remove: (id) =>
        set((s) => {
          const next = { ...s.templates };
          delete next[id];
          return { templates: next };
        }),
    }),
    { name: "pptmaker-custom-templates", storage: createJSONStorage(() => idbStorage) },
  ),
);

export function listCustomTemplates(map: Record<string, CustomTemplate>): CustomTemplate[] {
  return Object.values(map).sort((a, b) => b.updatedAt - a.updatedAt);
}
