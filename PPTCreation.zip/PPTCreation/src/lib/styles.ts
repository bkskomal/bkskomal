import type { DeckStyle } from "./types";

/**
 * Style presets give templates distinct visual personalities. Combined with the
 * 14 themes, this is what makes the 50+ templates genuinely different — different
 * cover compositions, background decorations, accent shapes and typography.
 */
export const DEFAULT_STYLE: DeckStyle = {
  cover: "centered",
  bg: "plain",
  accent: "bar",
  headScale: 1,
  bodyScale: 1,
  radius: 16,
};

export const STYLE_PRESETS: Record<string, DeckStyle> = {
  bold: { cover: "bigType", bg: "blob", accent: "bar", headScale: 1.18, bodyScale: 1, radius: 20 },
  editorial: { cover: "leftRule", bg: "plain", accent: "line", headScale: 1.12, bodyScale: 1.05, radius: 4 },
  geometric: { cover: "split", bg: "diagonal", accent: "bracket", headScale: 1, bodyScale: 0.98, radius: 10 },
  playful: { cover: "centered", bg: "dots", accent: "dot", headScale: 1.06, bodyScale: 1, radius: 24 },
  corporate: { cover: "sidebar", bg: "sideBand", accent: "bar", headScale: 1, bodyScale: 0.95, radius: 12 },
  minimal: { cover: "leftRule", bg: "plain", accent: "line", headScale: 0.92, bodyScale: 1, radius: 6 },
  techy: { cover: "split", bg: "grid", accent: "bracket", headScale: 1, bodyScale: 0.95, radius: 8 },
  organic: { cover: "bigType", bg: "arc", accent: "dot", headScale: 1.1, bodyScale: 1.05, radius: 26 },
  prestige: { cover: "gradientHero", bg: "arc", accent: "line", headScale: 1.08, bodyScale: 1, radius: 14 },
  vivid: { cover: "split", bg: "blob", accent: "bar", headScale: 1.1, bodyScale: 1, radius: 18 },
  // refined-corporate presets: generous whitespace, restrained accents, crisp hierarchy
  refined: { cover: "sidebar", bg: "plain", accent: "line", headScale: 1, bodyScale: 1, radius: 12 },
  consulting: { cover: "leftRule", bg: "sideBand", accent: "bar", headScale: 1, bodyScale: 0.98, radius: 10 },
  boardroom: { cover: "gradientHero", bg: "plain", accent: "line", headScale: 1.02, bodyScale: 0.98, radius: 10 },
};

export const STYLE_LIST = Object.values(STYLE_PRESETS);
export const STYLE_IDS = Object.keys(STYLE_PRESETS);
