import { create } from "zustand";
import { persist } from "zustand/middleware";
import { newId } from "./layouts";

/**
 * Lightweight LOCAL auth so we can keep per-user chat history without a backend.
 * NOTE: this is a browser-only demo — passwords are lightly hashed and stored in
 * localStorage. Production must move to a real backend (NextAuth / DB / bcrypt).
 */
export type Role = "superadmin" | "user";

export interface User {
  id: string;
  name: string;
  email: string;
  passHash: string;
  role: Role;
}

interface AuthState {
  users: User[];
  currentId: string | null;
  signup: (name: string, email: string, password: string, role?: Role) => { ok: boolean; error?: string };
  login: (email: string, password: string) => { ok: boolean; error?: string };
  logout: () => void;
  current: () => User | null;
  isSuperAdmin: () => boolean;
  updateName: (name: string) => void;
  ensureSeed: () => void;
}

/** Pre-seeded demo account so OATIGenie is usable out of the box. */
export const DEMO = { name: "OATI Genie", email: "demo@oati.com", password: "oatigenie" };

/** Non-cryptographic hash — demo only. */
function hash(s: string): string {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = (h * 33) ^ s.charCodeAt(i);
  return (h >>> 0).toString(36);
}

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      users: [],
      currentId: null,
      current: () => get().users.find((u) => u.id === get().currentId) ?? null,
      isSuperAdmin: () => get().users.find((u) => u.id === get().currentId)?.role === "superadmin",
      signup: (name, email, password, role = "user") => {
        email = email.trim().toLowerCase();
        if (!name.trim() || !email || password.length < 4)
          return { ok: false, error: "Enter a name, email, and a password (4+ chars)." };
        if (get().users.some((u) => u.email === email))
          return { ok: false, error: "An account with that email already exists." };
        const user: User = { id: newId(), name: name.trim(), email, passHash: hash(password), role };
        set((s) => ({ users: [...s.users, user], currentId: user.id }));
        return { ok: true };
      },
      login: (email, password) => {
        email = email.trim().toLowerCase();
        const user = get().users.find((u) => u.email === email);
        if (!user || user.passHash !== hash(password))
          return { ok: false, error: "Invalid email or password." };
        set({ currentId: user.id });
        return { ok: true };
      },
      logout: () => set({ currentId: null }),
      updateName: (name) =>
        set((s) => ({
          users: s.users.map((u) => (u.id === s.currentId ? { ...u, name: name.trim() || u.name } : u)),
        })),
      ensureSeed: () => {
        const existing = get().users.find((u) => u.email === DEMO.email);
        if (existing) {
          // make sure the demo account is Super Admin (migrates older records)
          if (existing.role !== "superadmin")
            set((s) => ({ users: s.users.map((u) => (u.id === existing.id ? { ...u, role: "superadmin" } : u)) }));
          return;
        }
        set((s) => ({
          users: [...s.users, { id: newId(), name: DEMO.name, email: DEMO.email, passHash: hash(DEMO.password), role: "superadmin" }],
        }));
      },
    }),
    { name: "oatigenie-auth" },
  ),
);
