import { create } from "zustand";
import { useStore } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { temporal } from "zundo";
import { idbStorage } from "./idbStorage";
import { newId } from "./layouts";
import type {
  BrandKit,
  Deck,
  Slide,
  SlideElement,
} from "./types";

/**
 * Editor state. The Deck is the single source of truth; selection + UI state
 * live alongside it. Every mutation bumps updatedAt and (lightly) persists.
 */
interface EditorState {
  deck: Deck | null;
  currentSlideId: string | null;
  selectedElementId: string | null;

  setDeck: (deck: Deck) => void;
  setCurrentSlide: (slideId: string) => void;
  selectElement: (elementId: string | null) => void;

  // deck-level
  updateBrand: (patch: Partial<BrandKit>) => void;
  setTitle: (title: string) => void;

  // slides
  addSlide: (slide: Slide, afterId?: string) => void;
  duplicateSlide: (slideId: string) => void;
  deleteSlide: (slideId: string) => void;
  /** replace a slide's content in place (keeps its position) */
  setSlide: (slideId: string, slide: Slide) => void;
  moveSlide: (slideId: string, toIndex: number) => void;
  setSlideNotes: (slideId: string, notes: string) => void;

  // elements
  addElement: (slideId: string, element: SlideElement) => void;
  addElements: (slideId: string, elements: SlideElement[]) => void;
  updateElement: (slideId: string, elementId: string, patch: Partial<SlideElement>) => void;
  deleteElement: (slideId: string, elementId: string) => void;
  duplicateElement: (slideId: string, elementId: string) => void;
  /** replace all of a slide's elements at once (used by Polish) */
  setSlideElements: (slideId: string, elements: SlideElement[]) => void;
}

function touch(deck: Deck): Deck {
  return { ...deck, updatedAt: Date.now() };
}

export const useEditor = create<EditorState>()(
  temporal(
    persist(
    (set) => ({
  deck: null,
  currentSlideId: null,
  selectedElementId: null,

  setDeck: (deck) =>
    set({ deck, currentSlideId: deck.slides[0]?.id ?? null, selectedElementId: null }),

  setCurrentSlide: (slideId) => set({ currentSlideId: slideId, selectedElementId: null }),
  selectElement: (elementId) => set({ selectedElementId: elementId }),

  updateBrand: (patch) =>
    set((s) => (s.deck ? { deck: touch({ ...s.deck, brand: { ...s.deck.brand, ...patch } }) } : s)),

  setTitle: (title) => set((s) => (s.deck ? { deck: touch({ ...s.deck, title }) } : s)),

  addSlide: (slide, afterId) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = [...s.deck.slides];
      const idx = afterId ? slides.findIndex((sl) => sl.id === afterId) + 1 : slides.length;
      slides.splice(idx, 0, slide);
      return { deck: touch({ ...s.deck, slides }), currentSlideId: slide.id };
    }),

  duplicateSlide: (slideId) =>
    set((s) => {
      if (!s.deck) return s;
      const idx = s.deck.slides.findIndex((sl) => sl.id === slideId);
      if (idx < 0) return s;
      const orig = s.deck.slides[idx];
      const copy: Slide = {
        ...orig,
        id: newId(),
        elements: orig.elements.map((e) => ({ ...e, id: newId() })),
      };
      const slides = [...s.deck.slides];
      slides.splice(idx + 1, 0, copy);
      return { deck: touch({ ...s.deck, slides }), currentSlideId: copy.id };
    }),

  deleteSlide: (slideId) =>
    set((s) => {
      if (!s.deck || s.deck.slides.length <= 1) return s;
      const idx = s.deck.slides.findIndex((sl) => sl.id === slideId);
      const slides = s.deck.slides.filter((sl) => sl.id !== slideId);
      const nextCurrent =
        s.currentSlideId === slideId
          ? slides[Math.min(idx, slides.length - 1)]?.id ?? null
          : s.currentSlideId;
      return { deck: touch({ ...s.deck, slides }), currentSlideId: nextCurrent };
    }),

  moveSlide: (slideId, toIndex) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = [...s.deck.slides];
      const from = slides.findIndex((sl) => sl.id === slideId);
      if (from < 0) return s;
      const [moved] = slides.splice(from, 1);
      slides.splice(Math.max(0, Math.min(toIndex, slides.length)), 0, moved);
      return { deck: touch({ ...s.deck, slides }) };
    }),

  setSlide: (slideId, slide) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = s.deck.slides.map((sl) => (sl.id === slideId ? slide : sl));
      return { deck: touch({ ...s.deck, slides }), selectedElementId: null };
    }),

  setSlideNotes: (slideId, notes) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = s.deck.slides.map((sl) => (sl.id === slideId ? { ...sl, notes } : sl));
      return { deck: touch({ ...s.deck, slides }) };
    }),

  addElement: (slideId, element) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = s.deck.slides.map((sl) =>
        sl.id !== slideId ? sl : { ...sl, elements: [...sl.elements, element] },
      );
      return { deck: touch({ ...s.deck, slides }), selectedElementId: element.id };
    }),

  addElements: (slideId, elements) =>
    set((s) => {
      if (!s.deck || !elements.length) return s;
      const slides = s.deck.slides.map((sl) =>
        sl.id !== slideId ? sl : { ...sl, elements: [...sl.elements, ...elements] },
      );
      // select the last (usually the top text) so it's easy to nudge into place
      return { deck: touch({ ...s.deck, slides }), selectedElementId: elements[elements.length - 1].id };
    }),

  setSlideElements: (slideId, elements) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = s.deck.slides.map((sl) => (sl.id !== slideId ? sl : { ...sl, elements }));
      return { deck: touch({ ...s.deck, slides }) };
    }),

  duplicateElement: (slideId, elementId) =>
    set((s) => {
      if (!s.deck) return s;
      let newSel = s.selectedElementId;
      const slides = s.deck.slides.map((sl) => {
        if (sl.id !== slideId) return sl;
        const orig = sl.elements.find((e) => e.id === elementId);
        if (!orig) return sl;
        const copy = { ...orig, id: newId(), x: orig.x + 24, y: orig.y + 24 };
        newSel = copy.id;
        return { ...sl, elements: [...sl.elements, copy] };
      });
      return { deck: touch({ ...s.deck, slides }), selectedElementId: newSel };
    }),

  updateElement: (slideId, elementId, patch) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = s.deck.slides.map((sl) =>
        sl.id !== slideId
          ? sl
          : {
              ...sl,
              elements: sl.elements.map((e) =>
                e.id === elementId ? ({ ...e, ...patch } as SlideElement) : e,
              ),
            },
      );
      return { deck: touch({ ...s.deck, slides }) };
    }),

  deleteElement: (slideId, elementId) =>
    set((s) => {
      if (!s.deck) return s;
      const slides = s.deck.slides.map((sl) =>
        sl.id !== slideId ? sl : { ...sl, elements: sl.elements.filter((e) => e.id !== elementId) },
      );
      return {
        deck: touch({ ...s.deck, slides }),
        selectedElementId: s.selectedElementId === elementId ? null : s.selectedElementId,
      };
    }),
    }),
    {
      name: "pptmaker-deck",
      // IndexedDB (large quota, async) — image-heavy decks overflow localStorage's ~5 MB
      storage: createJSONStorage(() => idbStorage),
      partialize: (s) => ({ deck: s.deck, currentSlideId: s.currentSlideId }),
    },
    ),
    {
      // Undo/redo tracks only the deck. Debounce so a drag or a burst of typing
      // collapses into a single history step.
      limit: 100,
      partialize: (state) => ({ deck: state.deck }),
      handleSet: (handleSet) => {
        let timer: ReturnType<typeof setTimeout> | undefined;
        return (pastState) => {
          if (timer) clearTimeout(timer);
          timer = setTimeout(() => handleSet(pastState), 350);
        };
      },
    },
  ),
);

/** React hooks for the undo/redo (temporal) store. */
export const useCanUndo = () => useStore(useEditor.temporal, (s) => s.pastStates.length > 0);
export const useCanRedo = () => useStore(useEditor.temporal, (s) => s.futureStates.length > 0);
export const undo = () => useEditor.temporal.getState().undo();
export const redo = () => useEditor.temporal.getState().redo();
export const clearHistory = () => useEditor.temporal.getState().clear();
