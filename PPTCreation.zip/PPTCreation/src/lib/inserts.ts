import { newId } from "./layouts";
import { CANVAS } from "./utils";
import type { IconElement, ShapeElement, SlideElement, TextElement } from "./types";

/**
 * Prebuilt insertable resources — SHAPES (single premium shapes), COMPONENTS
 * (badges, cards, callouts) and DIAGRAMS (multi-element compositions: process,
 * matrix, venn, pyramid, funnel, timeline, comparison). Each item's make()
 * returns loose SlideElement[] the user can move/edit; all use token:* colors so
 * they pick up the deck theme and export as native shapes.
 */

const W = CANVAS.w;
const H = CANVAS.h;
const cx = W / 2;
const cy = H / 2;

type ShapeP = Partial<ShapeElement> & { shape: ShapeElement["shape"]; x: number; y: number; w: number; h: number };
const sh = (p: ShapeP): ShapeElement => ({ id: newId(), type: "shape", fill: "token:primary", z: 5, ...p });

type TextP = Partial<TextElement> & { x: number; y: number; w: number; h: number };
const tx = (text: string, p: TextP): TextElement => ({
  id: newId(), type: "text", text, role: "body", align: "center", valign: "middle", color: "token:text", fontSize: 18, fontWeight: 600, z: 12, ...p,
});

type IconP = Partial<IconElement> & { x: number; y: number; w: number; h: number };
const ic = (name: string, p: IconP): IconElement => ({ id: newId(), type: "icon", name, color: "token:onPrimary", strokeWidth: 2, z: 13, ...p });

export interface InsertItem {
  id: string;
  label: string;
  category: "shape" | "component" | "diagram";
  make: () => SlideElement[];
}

// ---------------------------------------------------------------- single shapes
const shapeItem = (id: string, label: string, shape: ShapeElement["shape"], w: number, h: number, extra?: Partial<ShapeElement>): InsertItem => ({
  id,
  label,
  category: "shape",
  make: () => [sh({ shape, x: cx - w / 2, y: cy - h / 2, w, h, radius: 20, opacity: 0.92, ...extra })],
});

const SHAPES: InsertItem[] = [
  shapeItem("chevron", "Chevron", "chevron", 300, 110, { gradient: ["token:primary", "token:accent"], gradientAngle: 90 }),
  shapeItem("arrowRight", "Arrow", "arrowRight", 300, 130, { fill: "token:accent" }),
  shapeItem("hexagon", "Hexagon", "hexagon", 200, 200),
  shapeItem("pentagon", "Pentagon", "pentagon", 200, 200, { fill: "token:accent" }),
  shapeItem("diamond", "Diamond", "diamond", 200, 200),
  shapeItem("star", "Star", "star", 200, 200, { fill: "token:accent" }),
  shapeItem("parallelogram", "Parallelogram", "parallelogram", 300, 150),
  shapeItem("pill", "Pill", "pill", 320, 96),
  shapeItem("roundedRect", "Rounded box", "roundedRect", 320, 200, { radius: 24 }),
  shapeItem("ellipse", "Ellipse", "ellipse", 240, 240),
  shapeItem("triangle", "Triangle", "triangle", 220, 200),
  shapeItem("line", "Line", "rect", 360, 6, { fill: "token:accent", opacity: 1, radius: 3 }),
];

// ---------------------------------------------------------------- components
const COMPONENTS: InsertItem[] = [
  {
    id: "statCard", label: "Stat card", category: "component",
    make: () => {
      const w = 300, h = 190, x = cx - w / 2, y = cy - h / 2;
      return [
        sh({ shape: "roundedRect", x, y, w, h, radius: 22, fill: "token:surface" }),
        sh({ shape: "roundedRect", x, y, w, h: 8, radius: 4, gradient: ["token:primary", "token:accent"], gradientAngle: 90 }),
        tx("87%", { x: x + 16, y: y + 34, w: w - 32, h: 80, fontSize: 64, fontWeight: 800, color: "token:primary" }),
        tx("Key metric label", { x: x + 16, y: y + 120, w: w - 32, h: 40, fontSize: 16, fontWeight: 600, color: "token:textMuted" }),
      ];
    },
  },
  {
    id: "badge", label: "Badge", category: "component",
    make: () => {
      const s = 140, x = cx - s / 2, y = cy - s / 2;
      return [
        sh({ shape: "star", x, y, w: s, h: s, fill: "token:accent", opacity: 1 }),
        tx("NEW", { x, y, w: s, h: s, fontSize: 22, fontWeight: 800, color: "token:onPrimary" }),
      ];
    },
  },
  {
    id: "ribbon", label: "Ribbon banner", category: "component",
    make: () => {
      const w = 380, h = 70, x = cx - w / 2, y = cy - h / 2, fold = 26;
      return [
        sh({ shape: "triangle", x: x - fold, y: y + h - 4, w: fold + 8, h: 22, fill: "token:primary", opacity: 0.6, rotation: 90 }),
        sh({ shape: "triangle", x: x + w - 8, y: y + h - 4, w: fold + 8, h: 22, fill: "token:primary", opacity: 0.6, rotation: 270 }),
        sh({ shape: "rect", x, y, w, h, gradient: ["token:primary", "token:accent"], gradientAngle: 90, opacity: 1 }),
        tx("FEATURED", { x, y, w, h, fontSize: 24, fontWeight: 800, letterSpacing: 3, color: "token:onPrimary" }),
      ];
    },
  },
  {
    id: "callout", label: "Callout", category: "component",
    make: () => {
      const w = 440, h = 150, x = cx - w / 2, y = cy - h / 2;
      return [
        sh({ shape: "roundedRect", x, y, w, h, radius: 20, fill: "token:surface" }),
        sh({ shape: "triangle", x: x + 48, y: y + h - 2, w: 40, h: 26, fill: "token:surface", rotation: 180 }),
        sh({ shape: "roundedRect", x, y, w: 8, h, radius: 4, fill: "token:accent" }),
        tx("Add your callout text here — a short, punchy statement.", { x: x + 28, y: y + 20, w: w - 48, h: h - 40, align: "left", fontSize: 20, fontWeight: 600, color: "token:text" }),
      ];
    },
  },
  {
    id: "iconBadge", label: "Icon badge", category: "component",
    make: () => {
      const s = 130, x = cx - s / 2, y = cy - s / 2;
      return [
        sh({ shape: "ellipse", x, y, w: s, h: s, gradient: ["token:primary", "token:accent"], gradientAngle: 135, opacity: 1 }),
        ic("rocket", { x: x + s / 4, y: y + s / 4, w: s / 2, h: s / 2, color: "token:onPrimary" }),
      ];
    },
  },
];

// ---------------------------------------------------------------- diagrams
const nodeText = (t: string, x: number, y: number, w: number, h: number, over?: Partial<TextElement>): TextElement =>
  tx(t, { x, y, w, h, fontSize: 18, fontWeight: 700, color: "token:onPrimary", ...over });

const DIAGRAMS: InsertItem[] = [
  {
    id: "process3", label: "Process (3)", category: "diagram",
    make: () => {
      const out: SlideElement[] = [];
      const w = 340, h = 104, y = cy - h / 2, gap = 300;
      const startX = cx - (gap * 2 + w) / 2 + w / 2 - 20; // visual centering
      for (let i = 0; i < 3; i++) {
        const x = 150 + i * gap;
        out.push(sh({ shape: "chevron", x, y, w, h, gradient: ["token:primary", "token:accent"], gradientAngle: 90, opacity: 1 - i * 0.15 }));
        out.push(nodeText(`Step ${i + 1}`, x + 30, y, w - 90, h));
      }
      void startX;
      return out;
    },
  },
  {
    id: "arrowFlow3", label: "Arrow flow (3)", category: "diagram",
    make: () => {
      const out: SlideElement[] = [];
      const w = 300, h = 120, y = cy - h / 2, gap = 300;
      for (let i = 0; i < 3; i++) {
        const x = 170 + i * gap;
        out.push(sh({ shape: "arrowRight", x, y, w, h, fill: i % 2 ? "token:accent" : "token:primary", opacity: 1 }));
        out.push(nodeText(`Phase ${i + 1}`, x, y, w - 70, h));
      }
      return out;
    },
  },
  {
    id: "matrix2x2", label: "2×2 Matrix", category: "diagram",
    make: () => {
      const out: SlideElement[] = [];
      const tileW = 340, tileH = 190, gap = 20;
      const x0 = cx - tileW - gap / 2, y0 = cy - tileH - gap / 2;
      const tints: [number, string][] = [[0, "token:primary"], [1, "token:accent"], [2, "token:accent"], [3, "token:primary"]];
      tints.forEach(([i, fill]) => {
        const c = i % 2, r = Math.floor(i / 2);
        const x = x0 + c * (tileW + gap), y = y0 + r * (tileH + gap);
        out.push(sh({ shape: "roundedRect", x, y, w: tileW, h: tileH, radius: 16, fill, opacity: 0.85 }));
        out.push(nodeText(`Quadrant ${i + 1}`, x, y, tileW, tileH));
      });
      return out;
    },
  },
  {
    id: "venn2", label: "Venn (2)", category: "diagram",
    make: () => {
      const d = 300, y = cy - d / 2;
      const lx = cx - d + 70, rx = cx - 70;
      return [
        sh({ shape: "ellipse", x: lx, y, w: d, h: d, fill: "token:primary", opacity: 0.45 }),
        sh({ shape: "ellipse", x: rx, y, w: d, h: d, fill: "token:accent", opacity: 0.45 }),
        tx("Set A", { x: lx - 20, y: cy - 20, w: 140, h: 40, fontWeight: 700, color: "token:onPrimary" }),
        tx("Set B", { x: rx + d - 120, y: cy - 20, w: 140, h: 40, fontWeight: 700, color: "token:onPrimary" }),
        tx("Both", { x: cx - 60, y: cy - 20, w: 120, h: 40, fontWeight: 700, color: "token:text" }),
      ];
    },
  },
  {
    id: "pyramid3", label: "Pyramid (3)", category: "diagram",
    make: () => {
      const out: SlideElement[] = [];
      const widths = [240, 400, 560];
      const h = 92, top = cy - (h * 3) / 2;
      widths.forEach((w, i) => {
        const x = cx - w / 2, y = top + i * (h + 6);
        out.push(sh({ shape: i === 0 ? "triangle" : "trapezoid", x, y, w, h, gradient: ["token:accent", "token:primary"], gradientAngle: 90, opacity: 0.7 + i * 0.15 }));
        out.push(nodeText(`Tier ${i + 1}`, x, y + (i === 0 ? 20 : 0), w, h - (i === 0 ? 20 : 0)));
      });
      return out;
    },
  },
  {
    id: "funnel3", label: "Funnel (3)", category: "diagram",
    make: () => {
      const out: SlideElement[] = [];
      const widths = [560, 400, 240];
      const h = 90, top = cy - (h * 3) / 2;
      widths.forEach((w, i) => {
        const x = cx - w / 2, y = top + i * (h + 6);
        // trapezoid rotated 180° = wider at the TOP → funnel narrowing downward
        out.push(sh({ shape: "trapezoid", x, y, w, h, rotation: 180, gradient: ["token:primary", "token:accent"], gradientAngle: 90, opacity: 1 - i * 0.12 }));
        out.push(nodeText(`Stage ${i + 1}`, x, y, w, h));
      });
      return out;
    },
  },
  {
    id: "timeline4", label: "Timeline (4)", category: "diagram",
    make: () => {
      const out: SlideElement[] = [];
      const x0 = 170, x1 = W - 170, n = 4;
      out.push(sh({ shape: "rect", x: x0, y: cy - 2, w: x1 - x0, h: 4, fill: "token:accent", opacity: 0.6, radius: 2 }));
      for (let i = 0; i < n; i++) {
        const x = x0 + (i * (x1 - x0)) / (n - 1);
        out.push(sh({ shape: "ellipse", x: x - 14, y: cy - 14, w: 28, h: 28, fill: i % 2 ? "token:accent" : "token:primary", opacity: 1 }));
        const above = i % 2 === 0;
        out.push(tx(`Milestone ${i + 1}`, { x: x - 90, y: above ? cy - 90 : cy + 30, w: 180, h: 30, fontSize: 16, fontWeight: 700, color: "token:text" }));
        out.push(tx(`Q${i + 1}`, { x: x - 90, y: above ? cy - 58 : cy + 60, w: 180, h: 24, fontSize: 13, color: "token:textMuted" }));
      }
      return out;
    },
  },
  {
    id: "comparison2", label: "Comparison (2)", category: "diagram",
    make: () => {
      const out: SlideElement[] = [];
      const w = 470, h = 360, y = cy - h / 2, gap = 40;
      const cols: [number, string, string][] = [[cx - w - gap / 2, "token:primary", "Option A"], [cx + gap / 2, "token:accent", "Option B"]];
      cols.forEach(([x, accent, title]) => {
        out.push(sh({ shape: "roundedRect", x, y, w, h, radius: 20, fill: "token:surface" }));
        out.push(sh({ shape: "roundedRect", x, y, w, h: 60, radius: 20, fill: accent, opacity: 1 }));
        out.push(sh({ shape: "rect", x, y: y + 30, w, h: 30, fill: accent, opacity: 1 })); // square off bottom of header
        out.push(nodeText(title, x, y, w, 60, { fontSize: 22, fontWeight: 800 }));
        for (let i = 0; i < 3; i++) {
          out.push(sh({ shape: "ellipse", x: x + 30, y: y + 96 + i * 60, w: 12, h: 12, fill: accent, opacity: 1 }));
          out.push(tx("Point goes here", { x: x + 54, y: y + 80 + i * 60, w: w - 80, h: 40, align: "left", fontSize: 17, fontWeight: 500, color: "token:text" }));
        }
      });
      return out;
    },
  },
];

export const INSERT_ITEMS: InsertItem[] = [...SHAPES, ...COMPONENTS, ...DIAGRAMS];

export const INSERT_CATEGORIES: { id: InsertItem["category"]; label: string }[] = [
  { id: "shape", label: "Shapes" },
  { id: "component", label: "Components" },
  { id: "diagram", label: "Diagrams" },
];
