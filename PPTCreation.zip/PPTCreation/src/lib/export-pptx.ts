import pptxgen from "pptxgenjs";
import { brandChrome } from "./brand";
import { resolveColor, resolveFont } from "./color";
import { pxToIn } from "./utils";
import type { ChartElement, Deck, ShapeElement, Slide, SlideElement, TextElement } from "./types";

/**
 * Export a Deck to an EDITABLE .pptx. Each element becomes a native PowerPoint
 * object (text box / shape / picture) so the recipient can keep editing in
 * PowerPoint or Google Slides.
 *
 * Note: gradients are approximated with their primary stop (PPTX gradient fills
 * are not portably supported); the PDF / web-share exports keep full fidelity.
 */

// px -> points (96px/in, 72pt/in)
const pt = (px: number) => +(px * 0.75).toFixed(1);
const hex = (c: string) => (c === "transparent" ? undefined : c.replace("#", "").toUpperCase());

export async function exportDeckToPptx(deck: Deck): Promise<void> {
  const pptx = new pptxgen();
  pptx.defineLayout({ name: "PPTM", width: pxToIn(deck.size.w), height: pxToIn(deck.size.h) });
  pptx.layout = "PPTM";
  pptx.author = "PPTMaker";
  pptx.title = deck.title;

  deck.slides.forEach((slide, i) => {
    const s = pptx.addSlide();
    paintBackground(s, slide, deck);

    const chrome = brandChrome(deck.brand, slide.layout, i, deck.slides.length, slide.logoScale, deck.theme);
    [...slide.elements, ...chrome]
      .sort((a, b) => (a.z ?? 0) - (b.z ?? 0))
      .forEach((el) => addElement(s, el, deck));

    if (slide.notes) s.addNotes(slide.notes);
  });

  await pptx.writeFile({ fileName: `${safeName(deck.title)}.pptx` });
}

function paintBackground(s: pptxgen.Slide, slide: Slide, deck: Deck) {
  const b = slide.background;
  let color = deck.theme.colors.background;
  if (b?.type === "solid" && b.color)
    color = resolveColor(b.color, deck.theme, deck.brand, color);
  else if (b?.type === "gradient" && b.gradient)
    color = resolveColor(b.gradient[0], deck.theme, deck.brand, color);
  const h = hex(color);
  if (h) s.background = { color: h };
}

function addElement(s: pptxgen.Slide, el: SlideElement, deck: Deck) {
  const geo = {
    x: pxToIn(el.x),
    y: pxToIn(el.y),
    w: pxToIn(el.w),
    h: pxToIn(el.h),
    rotate: el.rotation,
  };

  if (el.type === "text") return addText(s, el, geo, deck);
  if (el.type === "shape") return addShape(s, el, geo, deck);
  if (el.type === "chart") return addChart(s, el, geo, deck);
  if (el.type === "image") {
    s.addImage({ ...geo, data: el.src, sizing: { type: el.fit === "contain" ? "contain" : "cover", w: geo.w, h: geo.h } });
  }
  // icons are skipped in pptx export for v1
}

const PPTX_CHART_TYPE: Record<string, pptxgen.CHART_NAME> = {
  column: "bar", bar: "bar", line: "line", area: "area", pie: "pie", donut: "doughnut",
};

function addChart(
  s: pptxgen.Slide,
  el: ChartElement,
  geo: { x: number; y: number; w: number; h: number },
  deck: Deck,
) {
  const palette = (el.palette?.length ? el.palette : ["token:primary", "token:accent", "token:secondary", "token:textMuted"]).map((c) =>
    hex(resolveColor(c, deck.theme, deck.brand, "#6366F1")) ?? "6366F1",
  );
  const type = PPTX_CHART_TYPE[el.chartType] ?? "bar";
  const radial = el.chartType === "pie" || el.chartType === "donut";
  const data = radial
    ? [{ name: el.series[0]?.name ?? "Series", labels: el.categories, values: el.series[0]?.data ?? [] }]
    : el.series.map((se) => ({ name: se.name, labels: el.categories, values: se.data }));
  s.addChart(type, data, {
    ...geo,
    barDir: el.chartType === "bar" ? "bar" : "col",
    chartColors: palette,
    showLegend: !!el.legend && el.series.length > 1,
    legendPos: "b",
    showValue: false,
    holeSize: el.chartType === "donut" ? 55 : undefined,
  });
}

function addText(
  s: pptxgen.Slide,
  el: TextElement,
  geo: { x: number; y: number; w: number; h: number; rotate?: number },
  deck: Deck,
) {
  const role =
    el.role === "title" || el.role === "heading" || el.role === "quote" ? "heading" : "body";
  const opts: pptxgen.TextPropsOptions = {
    ...geo,
    fontSize: pt(el.fontSize ?? 24),
    bold: (el.fontWeight ?? 400) >= 600,
    italic: el.italic,
    color: hex(resolveColor(el.color, deck.theme, deck.brand, deck.theme.colors.text)),
    fontFace: resolveFont(el.fontFamily, role, deck.theme, deck.brand),
    align: el.align ?? "left",
    valign: el.valign === "middle" ? "middle" : el.valign === "bottom" ? "bottom" : "top",
    lineSpacingMultiple: el.lineHeight ?? 1.2,
    charSpacing: el.letterSpacing,
  };

  if (el.items && el.items.length && el.listStyle !== "none") {
    const runs: pptxgen.TextProps[] = el.items.map((text) => ({
      text,
      options: {
        bullet: el.listStyle === "number" ? { type: "number" } : true,
        breakLine: true,
      },
    }));
    s.addText(runs, opts);
  } else {
    s.addText(el.text, opts);
  }
}

function addShape(
  s: pptxgen.Slide,
  el: ShapeElement,
  geo: { x: number; y: number; w: number; h: number; rotate?: number },
  deck: Deck,
) {
  const fillColor = el.gradient
    ? resolveColor(el.gradient[0], deck.theme, deck.brand)
    : resolveColor(el.fill, deck.theme, deck.brand, "transparent");
  const fillHex = hex(fillColor);

  // map our ShapeKind -> pptxgen ShapeType (native, editable PowerPoint shapes)
  const SHAPE_TYPE: Record<string, string> = {
    ellipse: "ellipse",
    blob: "ellipse",
    triangle: "triangle",
    trapezoid: "trapezoid",
    roundedRect: "roundRect",
    pill: "roundRect",
    chevron: "chevron",
    arrowRight: "rightArrow",
    hexagon: "hexagon",
    pentagon: "pentagon",
    diamond: "diamond",
    star: "star5",
    parallelogram: "parallelogram",
    rect: "rect",
  };
  const type = SHAPE_TYPE[el.shape] ?? "rect";
  const rounded = el.shape === "roundedRect" || el.shape === "pill";

  s.addShape(type as pptxgen.ShapeType, {
    ...geo,
    fill: fillHex ? { color: fillHex, transparency: el.opacity ? Math.round((1 - el.opacity) * 100) : 0 } : undefined,
    line: el.stroke
      ? { color: hex(resolveColor(el.stroke, deck.theme, deck.brand)) ?? "000000", width: el.strokeWidth ?? 1 }
      : { type: "none" },
    rectRadius: rounded ? pxToIn(el.shape === "pill" ? el.h * 0.5 : el.radius ?? 16) : undefined,
  });
}

function safeName(s: string) {
  return s.replace(/[^\w\d-]+/g, "_").slice(0, 60) || "presentation";
}
