import { newId } from "./layouts";
import { CANVAS } from "./utils";
import type { ChartElement, ChartKind, IconElement, ImageElement, ShapeElement, SlideElement, TextElement } from "./types";

/** Factories for inserting fresh elements, centered on the canvas. */

export function makeText(): TextElement {
  return {
    id: newId(),
    type: "text",
    text: "Double-click to edit",
    role: "body",
    x: CANVAS.w / 2 - 300,
    y: CANVAS.h / 2 - 40,
    w: 600,
    h: 80,
    fontSize: 32,
    fontWeight: 600,
    align: "center",
    valign: "middle",
    color: "token:text",
    z: 10,
  };
}

export function makeShape(shape: ShapeElement["shape"] = "roundedRect"): ShapeElement {
  return {
    id: newId(),
    type: "shape",
    shape,
    x: CANVAS.w / 2 - 160,
    y: CANVAS.h / 2 - 120,
    w: 320,
    h: 240,
    fill: "token:primary",
    radius: 24,
    opacity: 0.9,
    z: 5,
  };
}

export function makeIcon(name: string): IconElement {
  return {
    id: newId(),
    type: "icon",
    name,
    x: CANVAS.w / 2 - 40,
    y: CANVAS.h / 2 - 40,
    w: 80,
    h: 80,
    color: "token:primary",
    strokeWidth: 2,
    z: 10,
  };
}

/** Curated icon set offered in the picker (kebab-case lucide names). */
export const ICON_CHOICES = [
  "rocket", "target", "trending-up", "users", "shield", "zap",
  "check-circle", "star", "globe", "lightbulb", "bar-chart-3", "dollar-sign",
  "clock", "award", "heart", "settings", "lock", "mail",
  "cloud", "database", "code", "cpu", "layers", "briefcase",
  "flag", "gift", "map-pin", "phone", "search", "thumbs-up",
];

export function makeChart(chartType: ChartKind = "column"): ChartElement {
  return {
    id: newId(),
    type: "chart",
    chartType,
    categories: ["Q1", "Q2", "Q3", "Q4"],
    series: [{ name: "Revenue", data: [42, 58, 51, 73] }],
    legend: false,
    x: CANVAS.w / 2 - 380,
    y: CANVAS.h / 2 - 200,
    w: 760,
    h: 400,
    z: 10,
  };
}

/**
 * Parse pasted tabular data (CSV / TSV) into chart categories + series.
 * Row 1 = header (first cell ignored = category label, rest = series names).
 * Column 1 = category labels. Remaining cells = numbers.
 */
export function parseTable(text: string): { categories: string[]; series: { name: string; data: number[] }[] } | null {
  const rows = text
    .trim()
    .split(/\r?\n/)
    .map((r) => r.split(/\t|,/).map((c) => c.trim()))
    .filter((r) => r.some((c) => c !== ""));
  if (rows.length < 2) return null;
  const header = rows[0];
  const seriesNames = header.slice(1).map((h, i) => h || `Series ${i + 1}`);
  const categories: string[] = [];
  const series = seriesNames.map((name) => ({ name, data: [] as number[] }));
  for (const r of rows.slice(1)) {
    categories.push(r[0] || `Item ${categories.length + 1}`);
    seriesNames.forEach((_, i) => {
      const n = Number(String(r[i + 1] ?? "").replace(/[^0-9.\-]/g, ""));
      series[i].data.push(Number.isFinite(n) ? n : 0);
    });
  }
  if (!series.length || !categories.length) return null;
  return { categories, series };
}

export function makeImage(src: string): ImageElement {
  return {
    id: newId(),
    type: "image",
    src,
    x: CANVAS.w / 2 - 240,
    y: CANVAS.h / 2 - 160,
    w: 480,
    h: 320,
    fit: "cover",
    radius: 16,
    z: 10,
  };
}

/** Read a File into a data URL (for logo/image uploads). */
export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

export type { SlideElement };
