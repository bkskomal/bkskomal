import { create } from "zustand";
import { persist } from "zustand/middleware";
import { newId } from "./layouts";
import type { ChatMsg } from "./chatHistory";

/** A saved assistant conversation (the ChatGPT/Claude-style history items). */
export interface Conversation {
  id: string;
  title: string;
  messages: ChatMsg[];
  createdAt: number;
  updatedAt: number;
}

interface ConversationState {
  byUser: Record<string, Conversation[]>;
  list: (userId: string) => Conversation[];
  create: (userId: string) => string; // returns new conversation id
  get: (userId: string, convId: string) => Conversation | undefined;
  setMessages: (userId: string, convId: string, messages: ChatMsg[]) => void;
  rename: (userId: string, convId: string, title: string) => void;
  remove: (userId: string, convId: string) => void;
  clearAll: (userId: string) => void;
}

const CAP_MSGS = 200;

/** Derive a short title from the first user message. */
function titleFrom(messages: ChatMsg[]): string {
  const first = messages.find((m) => m.role === "user");
  const t = (first?.content ?? "New chat").trim().replace(/\s+/g, " ");
  return t.length > 42 ? `${t.slice(0, 42)}…` : t || "New chat";
}

export const useConversations = create<ConversationState>()(
  persist(
    (set, get) => ({
      byUser: {},
      list: (userId) => [...(get().byUser[userId] ?? [])].sort((a, b) => b.updatedAt - a.updatedAt),
      create: (userId) => {
        const conv: Conversation = { id: newId(), title: "New chat", messages: [], createdAt: 0, updatedAt: 0 };
        set((s) => ({ byUser: { ...s.byUser, [userId]: [conv, ...(s.byUser[userId] ?? [])] } }));
        return conv.id;
      },
      get: (userId, convId) => (get().byUser[userId] ?? []).find((c) => c.id === convId),
      setMessages: (userId, convId, messages) =>
        set((s) => {
          const list = s.byUser[userId] ?? [];
          const stamp = list.find((c) => c.id === convId)?.updatedAt ?? 0;
          const now = stamp + 1; // monotonic without Date.now (unavailable in some envs)
          const stripped = messages.slice(-CAP_MSGS).map((m) => ({ ...m, streaming: undefined }));
          const next = list.map((c) =>
            c.id === convId
              ? { ...c, messages: stripped, updatedAt: now, title: c.title === "New chat" ? titleFrom(stripped) : c.title }
              : c,
          );
          return { byUser: { ...s.byUser, [userId]: next } };
        }),
      rename: (userId, convId, title) =>
        set((s) => ({
          byUser: {
            ...s.byUser,
            [userId]: (s.byUser[userId] ?? []).map((c) => (c.id === convId ? { ...c, title: title.trim() || c.title } : c)),
          },
        })),
      remove: (userId, convId) =>
        set((s) => ({
          byUser: { ...s.byUser, [userId]: (s.byUser[userId] ?? []).filter((c) => c.id !== convId) },
        })),
      clearAll: (userId) => set((s) => ({ byUser: { ...s.byUser, [userId]: [] } })),
    }),
    { name: "pptmaker-conversations" },
  ),
);
