"use client";

import { useEffect } from "react";
import { useTheme } from "@/lib/theme";

/** Applies the resolved theme to <html data-theme> and reacts to system changes. */
export function ThemeApplier() {
  const setting = useTheme((s) => s.setting);
  const resolved = useTheme((s) => s.resolved);

  useEffect(() => {
    const apply = () => document.documentElement.setAttribute("data-theme", resolved());
    apply();
    if (setting === "system") {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      mq.addEventListener("change", apply);
      return () => mq.removeEventListener("change", apply);
    }
  }, [setting, resolved]);

  return null;
}
