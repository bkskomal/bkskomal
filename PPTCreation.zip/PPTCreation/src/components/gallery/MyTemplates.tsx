"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LayoutTemplate, Pencil, Trash2 } from "lucide-react";
import { SlideView } from "@/components/SlideView";
import { deckFromCustomTemplate, listCustomTemplates, useCustomTemplates } from "@/lib/customTemplates";
import { clearHistory, useEditor } from "@/lib/store";
import { toast } from "@/lib/toast";

const W = 300;

/** User-created templates (saved from any deck, incl. imported .pptx). Manage + use. */
export function MyTemplates() {
  const router = useRouter();
  const map = useCustomTemplates((s) => s.templates);
  const rename = useCustomTemplates((s) => s.rename);
  const remove = useCustomTemplates((s) => s.remove);
  const setDeck = useEditor((s) => s.setDeck);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) return null;
  const templates = listCustomTemplates(map);
  if (templates.length === 0) return null;

  function use(id: string) {
    const t = map[id];
    if (!t) return;
    setDeck(deckFromCustomTemplate(t));
    clearHistory();
    router.push("/editor");
  }

  return (
    <section className="mx-auto max-w-7xl px-6 pt-8">
      <h2 className="mb-1 flex items-center gap-2 text-lg font-semibold text-zinc-200">
        <LayoutTemplate size={18} className="text-indigo-400" /> Your templates
      </h2>
      <p className="mb-4 text-sm text-zinc-500">Saved from your decks — start a new presentation from any of them.</p>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {templates.map((t) => (
          <div
            key={t.id}
            className="group relative cursor-pointer overflow-hidden rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] transition-all hover:border-indigo-400/60 hover:shadow-xl hover:shadow-indigo-500/10"
            onClick={() => use(t.id)}
          >
            <div className="relative bg-black/40" style={{ height: W * (9 / 16) }}>
              {t.payload.slides[0] && (
                <SlideView slide={t.payload.slides[0]} theme={t.payload.theme} brand={t.payload.brand} pageIndex={0} pageCount={t.payload.slides.length} width={W} />
              )}
            </div>
            <div className="flex items-center justify-between p-3">
              <div className="min-w-0">
                <h3 className="truncate text-sm font-semibold text-zinc-100">{t.name}</h3>
                <p className="text-xs text-zinc-500">{t.category} · {t.payload.slides.length} slides</p>
              </div>
            </div>
            <div className="absolute right-2 top-2 flex gap-1 opacity-0 transition group-hover:opacity-100">
              <IconBtn
                title="Rename"
                onClick={(e) => {
                  e.stopPropagation();
                  const name = window.prompt("Rename template", t.name);
                  if (name?.trim()) rename(t.id, name.trim());
                }}
              >
                <Pencil size={14} />
              </IconBtn>
              <IconBtn
                title="Delete"
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm(`Delete template “${t.name}”?`)) { remove(t.id); toast.success("Template deleted"); }
                }}
              >
                <Trash2 size={14} />
              </IconBtn>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function IconBtn({ children, title, onClick }: { children: React.ReactNode; title: string; onClick: (e: React.MouseEvent) => void }) {
  return (
    <button title={title} onClick={onClick} className="rounded-md bg-black/70 p-1.5 text-zinc-300 hover:bg-black hover:text-white">
      {children}
    </button>
  );
}
