"use client";

import { useMemo } from "react";
import { defaultBrand } from "@/lib/deck";
import { SlideView } from "@/components/SlideView";
import type { Template } from "@/lib/types";

const PREVIEW_W = 320;

export function TemplateCard({
  template,
  onPick,
}: {
  template: Template;
  onPick: (t: Template) => void;
}) {
  const slides = useMemo(
    () => template.build({ title: template.name, subtitle: template.description }),
    [template],
  );

  return (
    <button
      onClick={() => onPick(template)}
      className="group text-left rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] overflow-hidden transition-all hover:border-indigo-400/60 hover:shadow-xl hover:shadow-indigo-500/10 hover:-translate-y-0.5"
    >
      <div className="relative overflow-hidden bg-black/40" style={{ height: PREVIEW_W * (9 / 16) }}>
        <SlideView
          slide={slides[0]}
          theme={template.theme}
          brand={defaultBrand}
          pageIndex={0}
          pageCount={slides.length}
          width={PREVIEW_W}
        />
        <div className="absolute inset-0 ring-1 ring-inset ring-white/5" />
      </div>
      <div className="p-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-semibold text-sm text-zinc-100 truncate">{template.name}</h3>
          <span className="shrink-0 rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-medium text-zinc-400">
            {template.category}
          </span>
        </div>
        <p className="mt-0.5 text-xs text-zinc-500 line-clamp-1">{template.description}</p>
      </div>
    </button>
  );
}
