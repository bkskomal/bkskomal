"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Sparkles, Loader2, LayoutTemplate, X } from "lucide-react";
import { Button, Field, inputCls, Modal } from "@/components/ui";
import { createDeckFromTemplate, deckFromAI } from "@/lib/deck";
import { applyOrgBrand, useOrg } from "@/lib/org";
import { enrichDeckImagery } from "@/lib/imagery";
import { clearHistory, useEditor } from "@/lib/store";
import { toast } from "@/lib/toast";
import type { AIDeck } from "@/lib/schema";
import type { Template } from "@/lib/types";

export function CreateDialog({
  template,
  onClose,
}: {
  template: Template | null;
  onClose: () => void;
}) {
  const router = useRouter();
  const setDeck = useEditor((s) => s.setDeck);
  const [mode, setMode] = useState<"template" | "ai">("ai");
  const [title, setTitle] = useState("");
  const [brief, setBrief] = useState("");
  const [tone, setTone] = useState("confident, modern");
  const [slideCount, setSlideCount] = useState(8);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<{ msg: string; hint?: string } | null>(null);

  if (!template) return null;

  const finalTitle = title.trim() || template.name;

  async function startTemplate() {
    const deck = createDeckFromTemplate(template!, { title: finalTitle });
    setDeck(deck);
    clearHistory();
    router.push("/editor");
  }

  async function startAI() {
    if (!brief.trim()) {
      setError({ msg: "Tell the AI what your presentation is about." });
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: brief, slideCount, tone }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError({ msg: data.error ?? "Generation failed", hint: data.hint });
        return;
      }
      const ai = data.deck as AIDeck;
      const n = ai.slides?.length ?? 0;
      if (data.source === "outline") toast.success(`Outline honored — ${n}/${n} slides built from your content`);
      else toast.info(`AI-generated — ${n} slides`);
      const deck = applyOrgBrand(deckFromAI(ai, template!.id), useOrg.getState().org);
      if (title.trim()) deck.title = title.trim();
      setDeck(deck);
      clearHistory();
      enrichDeckImagery(useEditor.getState().deck!);
      router.push("/editor");
    } catch (e) {
      setError({ msg: e instanceof Error ? e.message : "Network error" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={!!template} onClose={busy ? () => {} : onClose}>
      <div className="flex items-start justify-between p-5 pb-0">
        <div>
          <h2 className="text-lg font-semibold">Create with “{template.name}”</h2>
          <p className="text-sm text-zinc-400">{template.description}</p>
        </div>
        <button onClick={onClose} className="rounded-md p-1 text-zinc-500 hover:bg-white/5">
          <X size={18} />
        </button>
      </div>

      <div className="p-5 space-y-4">
        <div className="grid grid-cols-2 gap-2 rounded-lg bg-[#0e1016] p-1">
          <TabBtn active={mode === "ai"} onClick={() => setMode("ai")} icon={<Sparkles size={15} />}>
            Write with AI
          </TabBtn>
          <TabBtn
            active={mode === "template"}
            onClick={() => setMode("template")}
            icon={<LayoutTemplate size={15} />}
          >
            Start from template
          </TabBtn>
        </div>

        <Field label="Presentation title">
          <input
            className={inputCls}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={template.name}
          />
        </Field>

        {mode === "ai" && (
          <>
            <Field label="What's it about?" hint="A sentence or a full brief — the more the better.">
              <textarea
                className={inputCls}
                rows={3}
                value={brief}
                onChange={(e) => setBrief(e.target.value)}
                placeholder="e.g. A seed pitch for an AI tool that turns meeting notes into action items"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Slides">
                <input
                  type="number"
                  min={3}
                  max={20}
                  className={inputCls}
                  value={slideCount}
                  onChange={(e) => setSlideCount(Number(e.target.value))}
                />
              </Field>
              <Field label="Tone">
                <input className={inputCls} value={tone} onChange={(e) => setTone(e.target.value)} />
              </Field>
            </div>
          </>
        )}

        {error && (
          <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-200">
            <div>{error.msg}</div>
            {error.hint && <div className="mt-1 text-rose-300/70 text-xs">{error.hint}</div>}
          </div>
        )}
      </div>

      <div className="flex justify-end gap-2 border-t border-[var(--app-border)] p-4">
        <Button variant="ghost" onClick={onClose} disabled={busy}>
          Cancel
        </Button>
        {mode === "ai" ? (
          <Button onClick={startAI} disabled={busy}>
            {busy ? <Loader2 className="animate-spin" size={16} /> : <Sparkles size={16} />}
            {busy ? "Generating…" : "Generate deck"}
          </Button>
        ) : (
          <Button onClick={startTemplate}>
            <LayoutTemplate size={16} /> Open editor
          </Button>
        )}
      </div>
    </Modal>
  );
}

function TabBtn({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-center gap-2 rounded-md py-2 text-sm font-medium transition ${
        active ? "bg-indigo-500 text-white" : "text-zinc-400 hover:text-zinc-200"
      }`}
    >
      {icon}
      {children}
    </button>
  );
}
