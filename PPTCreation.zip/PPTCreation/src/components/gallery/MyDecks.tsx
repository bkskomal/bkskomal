"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Copy, Trash2 } from "lucide-react";
import { SlideView } from "@/components/SlideView";
import { listDecks, useLibrary } from "@/lib/library";
import { clearHistory, useEditor } from "@/lib/store";

const W = 300;

export function MyDecks() {
  const router = useRouter();
  const decksMap = useLibrary((s) => s.decks);
  const duplicate = useLibrary((s) => s.duplicate);
  const remove = useLibrary((s) => s.remove);
  const setDeck = useEditor((s) => s.setDeck);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) return null;
  const decks = listDecks(decksMap);
  if (decks.length === 0) return null;

  function open(id: string) {
    const d = decksMap[id];
    if (!d) return;
    setDeck(d);
    clearHistory();
    router.push("/editor");
  }

  return (
    <section className="mx-auto max-w-7xl px-6 pt-8">
      <h2 className="mb-4 text-lg font-semibold text-zinc-200">Your presentations</h2>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {decks.map((deck) => (
          <div
            key={deck.id}
            className="group relative cursor-pointer overflow-hidden rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] transition-all hover:border-indigo-400/60 hover:shadow-xl hover:shadow-indigo-500/10"
            onClick={() => open(deck.id)}
          >
            <div className="relative bg-black/40" style={{ height: W * (9 / 16) }}>
              {deck.slides[0] && (
                <SlideView
                  slide={deck.slides[0]}
                  theme={deck.theme}
                  brand={deck.brand}
                  pageIndex={0}
                  pageCount={deck.slides.length}
                  width={W}
                />
              )}
            </div>
            <div className="flex items-center justify-between p-3">
              <div className="min-w-0">
                <h3 className="truncate text-sm font-semibold text-zinc-100">{deck.title}</h3>
                <p className="text-xs text-zinc-500">
                  {deck.slides.length} slides · {timeAgo(deck.updatedAt)}
                </p>
              </div>
            </div>
            <div className="absolute right-2 top-2 flex gap-1 opacity-0 transition group-hover:opacity-100">
              <IconBtn
                title="Duplicate"
                onClick={(e) => {
                  e.stopPropagation();
                  duplicate(deck.id);
                }}
              >
                <Copy size={14} />
              </IconBtn>
              <IconBtn
                title="Delete"
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm(`Delete “${deck.title}”? This cannot be undone.`)) remove(deck.id);
                }}
              >
                <Trash2 size={14} />
              </IconBtn>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function IconBtn({
  children,
  title,
  onClick,
}: {
  children: React.ReactNode;
  title: string;
  onClick: (e: React.MouseEvent) => void;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className="rounded-md bg-black/70 p-1.5 text-zinc-300 hover:bg-black hover:text-white"
    >
      {children}
    </button>
  );
}

function timeAgo(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}
