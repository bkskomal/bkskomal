"use client";

import { AlertCircle, CheckCircle2, Info, X } from "lucide-react";
import { useToasts, type ToastKind } from "@/lib/toast";

const ICON: Record<ToastKind, React.ReactNode> = {
  success: <CheckCircle2 size={18} className="text-emerald-400" />,
  error: <AlertCircle size={18} className="text-rose-400" />,
  info: <Info size={18} className="text-indigo-400" />,
};

export function Toaster() {
  const toasts = useToasts((s) => s.toasts);
  const dismiss = useToasts((s) => s.dismiss);

  return (
    <div className="pointer-events-none fixed bottom-5 right-5 z-[100] flex w-80 flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="fade-up pointer-events-auto flex items-start gap-3 rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] p-3 shadow-2xl"
        >
          <span className="mt-0.5 shrink-0">{ICON[t.kind]}</span>
          <p className="flex-1 text-sm text-zinc-100">{t.message}</p>
          <button onClick={() => dismiss(t.id)} className="text-zinc-500 hover:text-zinc-200">
            <X size={15} />
          </button>
        </div>
      ))}
    </div>
  );
}
