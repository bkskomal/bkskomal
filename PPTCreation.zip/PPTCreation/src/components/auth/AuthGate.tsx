"use client";

import { useEffect, useState } from "react";
import { KeyRound, Sparkles } from "lucide-react";
import { Button, Field, inputCls } from "@/components/ui";
import { DEMO, useAuth } from "@/lib/auth";
import { resolveAccess, useOrg } from "@/lib/org";
import { toast } from "@/lib/toast";

/** Gates the app behind a lightweight local login/signup. */
export function AuthGate({ children }: { children: React.ReactNode }) {
  const currentId = useAuth((s) => s.currentId);
  const ensureSeed = useAuth((s) => s.ensureSeed);
  const loadOrg = useOrg((s) => s.load);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    ensureSeed();
    loadOrg();
    setMounted(true);
  }, [ensureSeed, loadOrg]);

  if (!mounted) return null;
  if (!currentId) return <AuthScreen />;
  return <>{children}</>;
}

function AuthScreen() {
  const signup = useAuth((s) => s.signup);
  const login = useAuth((s) => s.login);
  const org = useOrg((s) => s.org);
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState(DEMO.email);
  const [password, setPassword] = useState(DEMO.password);
  const [error, setError] = useState<string | null>(null);

  function submit() {
    setError(null);
    if (mode === "signup") {
      const access = resolveAccess(email, org);
      if (!access.allowed) return setError(access.reason ?? "Sign-up is restricted.");
      const res = signup(name, email, password, access.role);
      if (!res.ok) return setError(res.error ?? "Something went wrong.");
    } else {
      const res = login(email, password);
      if (!res.ok) return setError(res.error ?? "Something went wrong.");
    }
  }

  async function ssoSignIn() {
    try {
      const r = await fetch("/api/auth/sso/start", { method: "POST" }).then((x) => x.json());
      if (r.authorizeUrl) window.location.href = r.authorizeUrl;
      else toast.error(r.error ?? "SSO isn't fully configured yet.");
    } catch {
      toast.error("Couldn't start SSO.");
    }
  }

  return (
    <div className="flex flex-1 items-center justify-center p-4">
      <div className="w-full max-w-sm rounded-2xl border border-[var(--app-border)] bg-[var(--app-panel)] p-6 shadow-2xl">
        <div className="mb-5 flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500">
            <Sparkles size={18} className="text-white" />
          </div>
          <div>
            <div className="text-sm font-semibold">OATIGenie</div>
            <div className="text-xs text-[var(--app-muted)]">Your multi-skill AI assistant</div>
          </div>
        </div>

        <div className="mb-4 grid grid-cols-2 gap-1 rounded-lg bg-[var(--app-elev)] p-1 text-sm">
          {(["signup", "login"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`rounded-md py-1.5 font-medium capitalize ${mode === m ? "bg-indigo-500 text-white" : "text-[var(--app-muted)]"}`}
            >
              {m === "signup" ? "Sign up" : "Log in"}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {mode === "signup" && (
            <Field label="Name">
              <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
            </Field>
          )}
          <Field label="Email">
            <input
              className={inputCls}
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              placeholder="you@company.com"
            />
          </Field>
          <Field label="Password">
            <input
              className={inputCls}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              placeholder="••••••••"
            />
          </Field>
          {error && <p className="text-sm text-rose-400">{error}</p>}
          <Button className="w-full" onClick={submit}>
            {mode === "signup" ? "Create account" : "Log in"}
          </Button>
          {org.sso.enabled && (
            <button onClick={ssoSignIn} className="flex w-full items-center justify-center gap-2 rounded-lg border border-[var(--app-border)] py-2 text-sm font-medium text-[var(--app-text)] hover:bg-[var(--app-hover)]">
              <KeyRound size={15} /> Sign in with {org.sso.provider || "SSO"}
            </button>
          )}
          {org.allowedDomains.length > 0 && mode === "signup" && (
            <p className="text-center text-[11px] text-[var(--app-faint)]">Sign-up limited to: {org.allowedDomains.join(", ")}</p>
          )}
          <div className="rounded-lg border border-[var(--app-border)] bg-[var(--app-elev)] p-2.5 text-center text-[11px] text-[var(--app-muted)]">
            <span className="text-[var(--app-muted)]">Demo login</span> — {DEMO.email} / {DEMO.password}
            <div className="mt-0.5 text-[var(--app-faint)]">Local accounts (this browser). Production would use real auth.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
