"use client";

import { useState } from "react";
import { useEffect } from "react";
import { Building2, Check, Cpu, Database, Download, FlaskConical, Loader2, Lock, Monitor, Moon, Palette, Plus, Shield, ThumbsDown, ThumbsUp, Sun, SunMedium, Trash2, User, X } from "lucide-react";
import { Button, Field, inputCls } from "@/components/ui";
import { THEME_LABELS, THEME_ORDER, useTheme, type ThemeName } from "@/lib/theme";
import { useModels } from "@/lib/models";
import { useAuth } from "@/lib/auth";
import { useOrg } from "@/lib/org";
import { useAdminConfig } from "@/lib/adminConfig";
import { useConversations } from "@/lib/conversations";
import { useFeedback } from "@/lib/feedback";
import { toast } from "@/lib/toast";

const THEME_ICON: Record<ThemeName, React.ReactNode> = {
  light: <Sun size={15} />,
  "solarized-light": <SunMedium size={15} />,
  dark: <Moon size={15} />,
  "solarized-dark": <Moon size={15} className="text-amber-400" />,
};

type Tab = "appearance" | "account" | "models" | "platform" | "feedback" | "org";

export function Settings({ open, onClose, userId }: { open: boolean; onClose: () => void; userId: string }) {
  const isAdmin = useAuth((s) => s.isSuperAdmin());
  const [tab, setTab] = useState<Tab>("appearance");
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onMouseDown={onClose}>
      <div
        className="fade-up flex h-[540px] w-full max-w-2xl overflow-hidden rounded-2xl border border-[var(--app-border)] bg-[var(--app-panel)] shadow-2xl"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="w-48 shrink-0 border-r border-[var(--app-border)] p-3">
          <div className="mb-2 px-2 text-sm font-semibold text-[var(--app-text)]">Settings</div>
          <SideTab active={tab === "appearance"} onClick={() => setTab("appearance")} icon={<Palette size={15} />}>Appearance</SideTab>
          <SideTab active={tab === "account"} onClick={() => setTab("account")} icon={<User size={15} />}>Account</SideTab>
          {isAdmin && (
            <>
              <div className="mt-3 mb-1 flex items-center gap-1.5 px-2 text-[11px] font-semibold uppercase tracking-wide text-[var(--app-faint)]">
                <Shield size={12} /> Admin
              </div>
              <SideTab active={tab === "org"} onClick={() => setTab("org")} icon={<Building2 size={15} />}>Organization</SideTab>
              <SideTab active={tab === "models"} onClick={() => setTab("models")} icon={<Cpu size={15} />}>Models</SideTab>
              <SideTab active={tab === "platform"} onClick={() => setTab("platform")} icon={<Database size={15} />}>Embeddings &amp; Data</SideTab>
              <SideTab active={tab === "feedback"} onClick={() => setTab("feedback")} icon={<ThumbsUp size={15} />}>Training data</SideTab>
            </>
          )}
        </div>
        <div className="relative flex-1 overflow-y-auto p-5">
          <button onClick={onClose} className="absolute right-3 top-3 rounded-md p-1 text-[var(--app-muted)] hover:bg-[var(--app-hover)]">
            <X size={18} />
          </button>
          {tab === "appearance" && <Appearance />}
          {tab === "account" && <Account userId={userId} onClose={onClose} />}
          {isAdmin && tab === "org" && <Organization />}
          {isAdmin && tab === "models" && <Models />}
          {isAdmin && tab === "platform" && <Platform />}
          {isAdmin && tab === "feedback" && <FeedbackPanel userId={userId} />}
        </div>
      </div>
    </div>
  );
}

function Platform() {
  const cfg = useAdminConfig();
  const [status, setStatus] = useState<{ persisted?: boolean; feedback?: number; exemplars?: number }>({});
  useEffect(() => {
    fetch("/api/feedback").then((r) => r.json()).then(setStatus).catch(() => {});
  }, []);

  async function reset(action: string, label: string) {
    if (!confirm(`${label}?`)) return;
    await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }) });
    toast.success("Done");
    fetch("/api/feedback").then((r) => r.json()).then(setStatus).catch(() => {});
  }

  return (
    <div className="space-y-5">
      <div>
        <h3 className="mb-1 text-lg font-semibold text-[var(--app-text)]">Embeddings &amp; Vector DB</h3>
        <p className="mb-3 text-sm text-[var(--app-muted)]">Powers the self-learning exemplar retrieval (RAG).</p>
        <div className="mb-3 rounded-xl border border-[var(--app-border)] p-3 text-sm">
          <div className="flex items-center gap-2">
            <span className={`h-2 w-2 rounded-full ${status.persisted ? "bg-emerald-400" : "bg-zinc-500"}`} />
            <span className="text-[var(--app-text)]">Vector DB {status.persisted ? "connected" : "not connected"}</span>
          </div>
          <div className="mt-1 text-xs text-[var(--app-muted)]">{status.feedback ?? 0} feedback · {status.exemplars ?? 0} exemplars</div>
        </div>
        <Field label="Embedding endpoint (base URL)">
          <input className={inputCls} value={cfg.embedBaseUrl} onChange={(e) => cfg.set({ embedBaseUrl: e.target.value })} placeholder="http://localhost:8910/v1" />
        </Field>
        <div className="mt-2">
          <Field label="Embedding model">
            <input className={inputCls} value={cfg.embedModel} onChange={(e) => cfg.set({ embedModel: e.target.value })} placeholder="BAAI/bge-base-en-v1.5" />
          </Field>
        </div>
      </div>

      <div>
        <h3 className="mb-2 text-sm font-semibold text-[var(--app-text)]">Retrieval (RAG)</h3>
        <label className="mb-2 flex items-center justify-between text-sm text-[var(--app-text)]">
          Use past 👍 answers to steer replies
          <input type="checkbox" checked={cfg.ragEnabled} onChange={(e) => cfg.set({ ragEnabled: e.target.checked })} className="h-4 w-4 accent-indigo-500" />
        </label>
        <Field label={`Examples to retrieve: ${cfg.ragTopK}`}>
          <input type="range" min={1} max={8} value={cfg.ragTopK} onChange={(e) => cfg.set({ ragTopK: Number(e.target.value) })} className="w-full accent-indigo-500" />
        </Field>
      </div>

      <div className="border-t border-[var(--app-border)] pt-3">
        <h3 className="mb-2 text-sm font-semibold text-[var(--app-text)]">Imagery</h3>
        <Field label="Stock photo provider">
          <select className={inputCls} value={cfg.imageProvider} onChange={(e) => cfg.set({ imageProvider: e.target.value as typeof cfg.imageProvider })}>
            <option value="picsum">Picsum (keyless, non-specific)</option>
            <option value="unsplash">Unsplash (API key)</option>
            <option value="pexels">Pexels (API key)</option>
          </select>
        </Field>
        {cfg.imageProvider !== "picsum" && (
          <Field label={`${cfg.imageProvider === "unsplash" ? "Unsplash Access Key" : "Pexels API Key"}`}>
            <input className={inputCls} value={cfg.imageApiKey} onChange={(e) => cfg.set({ imageApiKey: e.target.value })} placeholder="Paste API key" />
          </Field>
        )}
        <div className="mt-2 grid grid-cols-2 gap-2">
          <Field label="AI image endpoint (OpenAI-compatible)">
            <input className={inputCls} value={cfg.imageGenBaseUrl} onChange={(e) => cfg.set({ imageGenBaseUrl: e.target.value })} placeholder="https://…/v1" />
          </Field>
          <Field label="Image model">
            <input className={inputCls} value={cfg.imageGenModel} onChange={(e) => cfg.set({ imageGenModel: e.target.value })} placeholder="gpt-image-1" />
          </Field>
        </div>
        <Field label="AI image API key (optional)">
          <input className={inputCls} value={cfg.imageGenApiKey} onChange={(e) => cfg.set({ imageGenApiKey: e.target.value })} placeholder="Bearer token" />
        </Field>
        <p className="mt-1 text-[11px] text-[var(--app-faint)]">Picsum works with no setup. Add Unsplash/Pexels for relevant search, and an images endpoint for AI generation.</p>
      </div>

      <div className="flex flex-wrap gap-2 border-t border-[var(--app-border)] pt-3">
        <Button size="sm" variant="outline" onClick={() => reset("clear-exemplars", "Rebuild index (clears learned exemplars)")}>Rebuild index</Button>
        <Button size="sm" variant="ghost" onClick={() => reset("clear-feedback", "Delete all stored feedback")}>Clear feedback data</Button>
      </div>
      <p className="text-[11px] text-[var(--app-faint)]">Changing the embedding model requires a rebuild (vectors must share one space).</p>
    </div>
  );
}

interface OrgAdmin {
  name: string;
  brand: { logoUrl?: string; primaryColor?: string; accentColor?: string; fontHeading?: string; fontBody?: string; footerText?: string };
  locks: { colors: boolean; fonts: boolean; logo: boolean; footer: boolean };
  brandPresets: { id: string; name: string; brand: Record<string, unknown>; themeId?: string }[];
  approvedAssets: string[];
  allowedDomains: string[];
  domainRoles: Record<string, "superadmin" | "user">;
  sso: { enabled: boolean; provider?: string; issuer?: string; clientId?: string; clientSecret?: string };
}

function Organization() {
  const reloadOrg = useOrg((s) => s.load);
  const [cfg, setCfg] = useState<OrgAdmin | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/org?admin=1").then((r) => r.json()).then((j) => setCfg(j.org)).catch(() => {});
  }, []);

  if (!cfg) return <div className="flex justify-center py-10"><Loader2 className="animate-spin text-[var(--app-muted)]" /></div>;

  const patch = (p: Partial<OrgAdmin>) => setCfg({ ...cfg, ...p });
  const patchBrand = (p: Partial<OrgAdmin["brand"]>) => setCfg({ ...cfg, brand: { ...cfg.brand, ...p } });
  const patchLock = (p: Partial<OrgAdmin["locks"]>) => setCfg({ ...cfg, locks: { ...cfg.locks, ...p } });
  const patchSso = (p: Partial<OrgAdmin["sso"]>) => setCfg({ ...cfg, sso: { ...cfg.sso, ...p } });

  async function save() {
    setSaving(true);
    try {
      const r = await fetch("/api/org", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isSuperAdmin: true, config: cfg }),
      }).then((x) => x.json());
      if (r.error) return toast.error(r.error);
      await reloadOrg();
      toast.success("Organization settings saved");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  const LockRow = ({ label, k }: { label: string; k: keyof OrgAdmin["locks"] }) => (
    <label className="flex items-center justify-between text-sm text-[var(--app-text)]">
      <span className="flex items-center gap-1.5"><Lock size={13} className={cfg.locks[k] ? "text-amber-400" : "text-[var(--app-faint)]"} /> Lock {label}</span>
      <input type="checkbox" checked={cfg.locks[k]} onChange={(e) => patchLock({ [k]: e.target.checked } as Partial<OrgAdmin["locks"]>)} className="h-4 w-4 accent-indigo-500" />
    </label>
  );

  return (
    <div className="space-y-4">
      <div>
        <h3 className="mb-1 text-lg font-semibold text-[var(--app-text)]">Organization</h3>
        <p className="text-sm text-[var(--app-muted)]">Enforce a company brand and control who can access OATIGenie. Applies to every user.</p>
      </div>

      <Field label="Organization name">
        <input className={inputCls} value={cfg.name} onChange={(e) => patch({ name: e.target.value })} />
      </Field>

      <div className="rounded-xl border border-[var(--app-border)] p-3">
        <div className="mb-2 text-sm font-medium text-[var(--app-text)]">Brand kit (applied to new decks)</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Primary color"><input className={inputCls} value={cfg.brand.primaryColor ?? ""} placeholder="#6366F1" onChange={(e) => patchBrand({ primaryColor: e.target.value || undefined })} /></Field>
          <Field label="Accent color"><input className={inputCls} value={cfg.brand.accentColor ?? ""} placeholder="#22D3EE" onChange={(e) => patchBrand({ accentColor: e.target.value || undefined })} /></Field>
          <Field label="Heading font"><input className={inputCls} value={cfg.brand.fontHeading ?? ""} placeholder="Inter" onChange={(e) => patchBrand({ fontHeading: e.target.value || undefined })} /></Field>
          <Field label="Body font"><input className={inputCls} value={cfg.brand.fontBody ?? ""} placeholder="Inter" onChange={(e) => patchBrand({ fontBody: e.target.value || undefined })} /></Field>
        </div>
        <Field label="Logo URL"><input className={inputCls} value={cfg.brand.logoUrl ?? ""} placeholder="https://… or data URL" onChange={(e) => patchBrand({ logoUrl: e.target.value || undefined })} /></Field>
        <Field label="Footer text"><input className={inputCls} value={cfg.brand.footerText ?? ""} placeholder="PROPRIETARY AND CONFIDENTIAL" onChange={(e) => patchBrand({ footerText: e.target.value || undefined })} /></Field>
        <div className="mt-2 space-y-1.5">
          <LockRow label="colors" k="colors" />
          <LockRow label="fonts" k="fonts" />
          <LockRow label="logo" k="logo" />
          <LockRow label="footer" k="footer" />
        </div>
        <p className="mt-1 text-[11px] text-[var(--app-faint)]">Locked fields can’t be changed by users in the editor.</p>
      </div>

      <div className="rounded-xl border border-[var(--app-border)] p-3">
        <div className="mb-2 text-sm font-medium text-[var(--app-text)]">Brand presets ({(cfg.brandPresets ?? []).length})</div>
        {(cfg.brandPresets ?? []).length === 0 ? (
          <p className="text-[11px] text-[var(--app-faint)]">Save one from the editor: Brand panel → “Save as org brand preset”. Users apply it via chat: “use the &lt;name&gt; brand”.</p>
        ) : (
          <div className="space-y-1">
            {cfg.brandPresets.map((p) => (
              <div key={p.id} className="flex items-center justify-between rounded-md bg-[var(--app-hover)] px-2.5 py-1.5 text-sm">
                <span className="text-[var(--app-text)]">{p.name}{p.themeId ? <span className="ml-1 text-[11px] text-[var(--app-faint)]">· {p.themeId}</span> : null}</span>
                <button className="text-[var(--app-muted)] hover:text-rose-400" onClick={() => patch({ brandPresets: cfg.brandPresets.filter((x) => x.id !== p.id) })}>✕</button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-xl border border-[var(--app-border)] p-3">
        <div className="mb-2 text-sm font-medium text-[var(--app-text)]">Approved assets</div>
        <Field label="Approved image / logo URLs (one per line)">
          <textarea className={inputCls} rows={3} value={(cfg.approvedAssets ?? []).join("\n")} placeholder="https://…/logo.png"
            onChange={(e) => patch({ approvedAssets: e.target.value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean) })} />
        </Field>
        <p className="text-[11px] text-[var(--app-faint)]">Shown in the editor’s image picker under “Brand” so users insert only sanctioned imagery.</p>
      </div>

      <div className="rounded-xl border border-[var(--app-border)] p-3">
        <div className="mb-2 text-sm font-medium text-[var(--app-text)]">Access governance</div>
        <Field label="Allowed email domains (comma-separated; blank = any)">
          <input className={inputCls} value={cfg.allowedDomains.join(", ")} placeholder="oati.com, contractor.com"
            onChange={(e) => patch({ allowedDomains: e.target.value.split(",").map((d) => d.trim().toLowerCase()).filter(Boolean) })} />
        </Field>
        <Field label="Admin domains (get Super Admin, comma-separated)">
          <input className={inputCls}
            value={Object.entries(cfg.domainRoles).filter(([, r]) => r === "superadmin").map(([d]) => d).join(", ")}
            placeholder="oati.com"
            onChange={(e) => {
              const admins = e.target.value.split(",").map((d) => d.trim().toLowerCase()).filter(Boolean);
              patch({ domainRoles: Object.fromEntries(admins.map((d) => [d, "superadmin" as const])) });
            }} />
        </Field>
      </div>

      <div className="rounded-xl border border-[var(--app-border)] p-3">
        <label className="mb-2 flex items-center justify-between text-sm font-medium text-[var(--app-text)]">
          Single Sign-On (OIDC)
          <input type="checkbox" checked={cfg.sso.enabled} onChange={(e) => patchSso({ enabled: e.target.checked })} className="h-4 w-4 accent-indigo-500" />
        </label>
        {cfg.sso.enabled && (
          <div className="space-y-2">
            <Field label="Provider name"><input className={inputCls} value={cfg.sso.provider ?? ""} placeholder="Okta / Azure AD / Google" onChange={(e) => patchSso({ provider: e.target.value })} /></Field>
            <Field label="Issuer URL"><input className={inputCls} value={cfg.sso.issuer ?? ""} placeholder="https://your-idp/.well-known/openid-configuration" onChange={(e) => patchSso({ issuer: e.target.value })} /></Field>
            <div className="grid grid-cols-2 gap-2">
              <Field label="Client ID"><input className={inputCls} value={cfg.sso.clientId ?? ""} onChange={(e) => patchSso({ clientId: e.target.value })} /></Field>
              <Field label="Client secret"><input className={inputCls} type="password" value={cfg.sso.clientSecret ?? ""} onChange={(e) => patchSso({ clientSecret: e.target.value })} /></Field>
            </div>
          </div>
        )}
      </div>

      <Button onClick={save} disabled={saving} className="w-full">
        {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />} Save organization settings
      </Button>
    </div>
  );
}

function SideTab({ active, onClick, icon, children }: { active: boolean; onClick: () => void; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm ${active ? "bg-[var(--app-hover)] text-[var(--app-text)]" : "text-[var(--app-muted)] hover:bg-[var(--app-hover)]"}`}
    >
      {icon}
      {children}
    </button>
  );
}

function Appearance() {
  const setting = useTheme((s) => s.setting);
  const setTheme = useTheme((s) => s.set);
  return (
    <div>
      <h3 className="mb-1 text-lg font-semibold text-[var(--app-text)]">Appearance</h3>
      <p className="mb-4 text-sm text-[var(--app-muted)]">Choose a theme. “System” follows your OS setting.</p>
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setTheme("system")}
          className={`flex items-center gap-2 rounded-xl border p-3 text-sm ${setting === "system" ? "border-indigo-400 ring-1 ring-indigo-400/40" : "border-[var(--app-border)] hover:bg-[var(--app-hover)]"} text-[var(--app-text)]`}
        >
          <Monitor size={15} /> System {setting === "system" && <Check size={14} className="ml-auto text-indigo-400" />}
        </button>
        {THEME_ORDER.map((t) => (
          <button
            key={t}
            onClick={() => setTheme(t)}
            className={`flex items-center gap-2 rounded-xl border p-3 text-sm ${setting === t ? "border-indigo-400 ring-1 ring-indigo-400/40" : "border-[var(--app-border)] hover:bg-[var(--app-hover)]"} text-[var(--app-text)]`}
          >
            {THEME_ICON[t]} {THEME_LABELS[t]} {setting === t && <Check size={14} className="ml-auto text-indigo-400" />}
          </button>
        ))}
      </div>
    </div>
  );
}

function Models() {
  const models = useModels((s) => s.models);
  const activeId = useModels((s) => s.activeId);
  const setActive = useModels((s) => s.setActive);
  const add = useModels((s) => s.add);
  const remove = useModels((s) => s.remove);
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState({ name: "", baseUrl: "", apiKey: "", model: "" });

  return (
    <div>
      <h3 className="mb-1 text-lg font-semibold text-[var(--app-text)]">Models</h3>
      <p className="mb-4 text-sm text-[var(--app-muted)]">Pick the active model, or add any OpenAI-compatible endpoint.</p>
      <div className="space-y-2">
        {models.map((m) => (
          <div key={m.id} className={`flex items-center gap-3 rounded-xl border p-3 ${m.id === activeId ? "border-indigo-400" : "border-[var(--app-border)]"}`}>
            <button onClick={() => setActive(m.id)} className="flex h-5 w-5 items-center justify-center rounded-full border border-[var(--app-border)]">
              {m.id === activeId && <span className="h-2.5 w-2.5 rounded-full bg-indigo-500" />}
            </button>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium text-[var(--app-text)]">{m.name}</div>
              <div className="truncate text-xs text-[var(--app-muted)]">{m.model}{m.baseUrl ? ` · ${m.baseUrl}` : m.builtIn ? " · built-in" : ""}</div>
            </div>
            {!m.builtIn && (
              <button onClick={() => remove(m.id)} className="rounded-md p-1 text-[var(--app-muted)] hover:text-rose-400">
                <Trash2 size={15} />
              </button>
            )}
          </div>
        ))}
      </div>

      {adding ? (
        <div className="mt-3 space-y-2 rounded-xl border border-[var(--app-border)] p-3">
          <Field label="Name"><input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. GPT-4o (OpenAI)" /></Field>
          <Field label="Model id"><input className={inputCls} value={draft.model} onChange={(e) => setDraft({ ...draft, model: e.target.value })} placeholder="gpt-4o-mini" /></Field>
          <Field label="Base URL"><input className={inputCls} value={draft.baseUrl} onChange={(e) => setDraft({ ...draft, baseUrl: e.target.value })} placeholder="https://api.openai.com/v1" /></Field>
          <Field label="API key"><input className={inputCls} type="password" value={draft.apiKey} onChange={(e) => setDraft({ ...draft, apiKey: e.target.value })} placeholder="sk-…" /></Field>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setAdding(false)}>Cancel</Button>
            <Button
              size="sm"
              onClick={() => {
                if (!draft.name.trim() || !draft.model.trim()) return toast.error("Name and model id are required.");
                add(draft);
                setDraft({ name: "", baseUrl: "", apiKey: "", model: "" });
                setAdding(false);
                toast.success("Model added");
              }}
            >
              Add model
            </Button>
          </div>
        </div>
      ) : (
        <Button variant="outline" size="sm" className="mt-3" onClick={() => setAdding(true)}>
          <Plus size={15} /> Add model
        </Button>
      )}
      <p className="mt-3 text-[11px] text-[var(--app-faint)]">Keys are stored locally in this browser (demo).</p>
    </div>
  );
}

async function exportEndpoint(url: string, key: string, filename: string) {
  const data = await fetch(url).then((r) => r.json()).then((j) => j[key] ?? []);
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

function FeedbackPanel({ userId }: { userId: string }) {
  const events = useFeedback((s) => s.events).filter((e) => e.userId === userId).sort((a, b) => b.at - a.at);
  const clear = useFeedback((s) => s.clear);
  const ups = events.filter((e) => e.rating === "up").length;
  const downs = events.filter((e) => e.rating === "down").length;
  const [train, setTrain] = useState<{ messages: number; preferences: number; evals: number }>({ messages: 0, preferences: 0, evals: 0 });
  const [latestRun, setLatestRun] = useState<{ total: number; passed: number; avgScore: number; createdAt?: string } | null>(null);
  const [running, setRunning] = useState(false);
  useEffect(() => {
    fetch("/api/feedback").then((r) => r.json()).then((j) => j.training && setTrain(j.training)).catch(() => {});
    fetch("/api/evals").then((r) => r.json()).then((j) => setLatestRun(j.latestRun ?? null)).catch(() => {});
  }, []);

  async function runEvals() {
    setRunning(true);
    try {
      const r = await fetch("/api/evals/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}) }).then((x) => x.json());
      if (r.error) return toast.error(r.error);
      setLatestRun(r.run);
      toast.success(`Evals done — ${r.run.passed}/${r.run.total} passed (avg ${r.run.avgScore})`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Eval run failed");
    } finally {
      setRunning(false);
    }
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify(events, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "oatigenie-feedback.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <h3 className="mb-1 text-lg font-semibold text-[var(--app-text)]">Feedback</h3>
      <p className="mb-4 text-sm text-[var(--app-muted)]">
        Your 👍/👎 are captured with the prompt, reply and model — the data an AI can learn from.
      </p>
      <div className="mb-4 flex gap-3">
        <div className="flex items-center gap-2 rounded-xl border border-[var(--app-border)] px-3 py-2 text-sm text-[var(--app-text)]">
          <ThumbsUp size={15} className="text-emerald-400" /> {ups} liked
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-[var(--app-border)] px-3 py-2 text-sm text-[var(--app-text)]">
          <ThumbsDown size={15} className="text-rose-400" /> {downs} disliked
        </div>
      </div>
      <div className="mb-3 flex gap-2">
        <Button size="sm" variant="outline" onClick={exportJson} disabled={!events.length}>
          <Download size={14} /> Export local
        </Button>
        <Button size="sm" variant="ghost" onClick={() => { if (confirm("Clear all feedback?")) clear(userId); }} disabled={!events.length}>
          Clear
        </Button>
      </div>

      {/* Model quality — LLM-as-judge pass-rate */}
      <div className="mb-4 rounded-xl border border-[var(--app-border)] p-3">
        <div className="mb-2 flex items-center justify-between">
          <div className="text-sm font-medium text-[var(--app-text)]">Model quality (LLM-as-judge)</div>
          <Button size="sm" onClick={runEvals} disabled={running}>
            {running ? <Loader2 size={14} className="animate-spin" /> : <FlaskConical size={14} />}
            {running ? "Running…" : "Run evals"}
          </Button>
        </div>
        {latestRun ? (
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="rounded-lg bg-[var(--app-hover)] py-2"><div className="text-lg font-semibold text-emerald-400">{latestRun.total ? Math.round((latestRun.passed / latestRun.total) * 100) : 0}%</div>pass-rate</div>
            <div className="rounded-lg bg-[var(--app-hover)] py-2"><div className="text-lg font-semibold text-[var(--app-text)]">{latestRun.avgScore}</div>avg score</div>
            <div className="rounded-lg bg-[var(--app-hover)] py-2"><div className="text-lg font-semibold text-[var(--app-text)]">{latestRun.passed}/{latestRun.total}</div>passed</div>
          </div>
        ) : (
          <p className="text-[11px] text-[var(--app-faint)]">No run yet. Save eval cases (👍 → Save as eval case), then Run evals to score the model with an LLM judge.</p>
        )}
      </div>

      {/* Server-side training dataset (Postgres) */}
      <div className="mb-4 rounded-xl border border-[var(--app-border)] p-3">
        <div className="mb-2 text-sm font-medium text-[var(--app-text)]">Training dataset (server)</div>
        <div className="mb-2 grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-lg bg-[var(--app-hover)] py-2"><div className="text-lg font-semibold text-[var(--app-text)]">{train.messages}</div>messages</div>
          <div className="rounded-lg bg-[var(--app-hover)] py-2"><div className="text-lg font-semibold text-[var(--app-text)]">{train.preferences}</div>preference pairs</div>
          <div className="rounded-lg bg-[var(--app-hover)] py-2"><div className="text-lg font-semibold text-[var(--app-text)]">{train.evals}</div>eval cases</div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => exportEndpoint("/api/preference", "preferences", "preference-pairs.json")}>
            <Download size={14} /> Preference pairs
          </Button>
          <Button size="sm" variant="outline" onClick={() => exportEndpoint("/api/evals", "evals", "evals.json")}>
            <Download size={14} /> Eval set
          </Button>
        </div>
        <p className="mt-2 text-[11px] text-[var(--app-faint)]">Preference pairs → DPO/LoRA fine-tuning. Eval set → regression testing (run scripts/run-evals.mjs).</p>
      </div>
      <div className="space-y-2">
        {events.length === 0 && <p className="text-sm text-[var(--app-muted)]">No feedback yet. Rate replies with 👍 / 👎.</p>}
        {events.slice(0, 30).map((e) => (
          <div key={e.id} className="rounded-lg border border-[var(--app-border)] p-2.5 text-xs">
            <div className="mb-1 flex items-center gap-2">
              {e.rating === "up" ? <ThumbsUp size={13} className="text-emerald-400" /> : <ThumbsDown size={13} className="text-rose-400" />}
              <span className="text-[var(--app-muted)]">{e.model}</span>
            </div>
            <div className="text-[var(--app-muted)]">Prompt: <span className="text-[var(--app-text)]">{e.prompt.slice(0, 100) || "—"}</span></div>
            <div className="mt-0.5 line-clamp-2 text-[var(--app-muted)]">Reply: <span className="text-[var(--app-text)]">{e.answer.slice(0, 160)}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Account({ userId, onClose }: { userId: string; onClose: () => void }) {
  const users = useAuth((s) => s.users);
  const currentId = useAuth((s) => s.currentId);
  const updateName = useAuth((s) => s.updateName);
  const logout = useAuth((s) => s.logout);
  const clearAll = useConversations((s) => s.clearAll);
  const user = users.find((u) => u.id === currentId);
  const [name, setName] = useState(user?.name ?? "");

  return (
    <div>
      <h3 className="mb-4 text-lg font-semibold text-[var(--app-text)]">Account</h3>
      <div className="space-y-3">
        <Field label="Display name">
          <div className="flex gap-2">
            <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} />
            <Button size="sm" variant="subtle" onClick={() => { updateName(name); toast.success("Name updated"); }}>Save</Button>
          </div>
        </Field>
        <Field label="Email"><input className={inputCls} value={user?.email ?? ""} disabled /></Field>
        <div className="flex flex-wrap gap-2 pt-2">
          <Button variant="outline" size="sm" onClick={() => { if (confirm("Delete all conversations?")) { clearAll(userId); toast.success("Cleared"); onClose(); } }}>
            <Trash2 size={14} /> Clear all chats
          </Button>
          <Button variant="outline" size="sm" onClick={() => { logout(); onClose(); }}>Log out</Button>
        </div>
      </div>
    </div>
  );
}
