"use client";

import { useEffect, useState } from "react";
import { Moon, Sun, SunMedium } from "lucide-react";
import { THEME_LABELS, useTheme, type ThemeName } from "@/lib/theme";

const ICON: Record<ThemeName, React.ReactNode> = {
  light: <Sun size={17} />,
  "solarized-light": <SunMedium size={17} className="text-amber-500" />,
  dark: <Moon size={17} />,
  "solarized-dark": <Moon size={17} className="text-amber-400" />,
};

/** One button that cycles light → solarized-light → dark → solarized-dark. */
export function ThemeCycler() {
  const cycle = useTheme((s) => s.cycle);
  const resolved = useTheme((s) => s.resolved);
  // avoid SSR/client mismatch — render after mount
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <div className="h-9 w-9" />;
  const cur = resolved();

  return (
    <button
      onClick={cycle}
      title={`Theme: ${THEME_LABELS[cur]} (click to change)`}
      className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]"
    >
      {ICON[cur]}
    </button>
  );
}
