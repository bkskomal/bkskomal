"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp, ChevronDown, Mic, Plus, Square, X } from "lucide-react";
import { SKILLS } from "@/lib/skills";
import { useModels } from "@/lib/models";
import { fileToDataUrl } from "@/lib/elements";
import { newId } from "@/lib/layouts";
import type { ChatAttachment } from "@/lib/chatActions";

interface SlashItem {
  id: string;
  label: string;
  hint?: string;
  insert: string;
  live: boolean;
}

const SLASH_ITEMS: SlashItem[] = [
  ...SKILLS.map((s) => ({ id: s.id, label: s.name, hint: s.description, insert: s.example, live: s.live })),
  { id: "brainstorm", label: "Brainstorm", hint: "Ideas & angles", insert: "Brainstorm ideas for ", live: true },
  { id: "summarize", label: "Summarize", hint: "Condense text", insert: "Summarize this: ", live: true },
  { id: "write", label: "Write", hint: "Draft copy", insert: "Write a ", live: true },
];

/** Premium chat composer: attach, auto-grow, "/" skill menu, voice dictation, send/stop. */
export function Composer({
  value,
  onChange,
  onSubmit,
  onStop,
  busy = false,
  variant = "docked",
  placeholder = "Message OATIGenie…   (type / for skills)",
  autoFocus,
}: {
  value: string;
  onChange: (v: string) => void;
  onSubmit: (text: string, attachments: ChatAttachment[]) => void;
  onStop?: () => void;
  busy?: boolean;
  variant?: "hero" | "docked";
  placeholder?: string;
  autoFocus?: boolean;
}) {
  const models = useModels((s) => s.models);
  const activeId = useModels((s) => s.activeId);
  const setActiveModel = useModels((s) => s.setActive);
  const activeModel = models.find((m) => m.id === activeId);
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [listening, setListening] = useState(false);
  const [slashSel, setSlashSel] = useState(0);
  const [modelMenu, setModelMenu] = useState(false);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<{ stop: () => void } | null>(null);

  const showSlash = value.startsWith("/");
  const slashQuery = showSlash ? value.slice(1).toLowerCase() : "";
  const slashItems = showSlash
    ? SLASH_ITEMS.filter((s) => s.label.toLowerCase().includes(slashQuery) || (s.hint ?? "").toLowerCase().includes(slashQuery))
    : [];

  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 200)}px`;
  }, [value]);

  useEffect(() => {
    if (autoFocus) taRef.current?.focus();
  }, [autoFocus]);

  async function addFiles(files: FileList | File[]) {
    const imgs = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (!imgs.length) return;
    const next = await Promise.all(
      imgs.map(async (f) => ({ id: newId(), name: f.name || "image", type: f.type, dataUrl: await fileToDataUrl(f) })),
    );
    setAttachments((a) => [...a, ...next]);
  }

  function submit() {
    if (busy) return;
    if (!value.trim() && attachments.length === 0) return;
    onSubmit(value, attachments);
    setAttachments([]);
  }

  function pickSlash(item: SlashItem) {
    if (!item.live) return;
    onChange(item.insert);
    setTimeout(() => taRef.current?.focus(), 0);
  }

  function toggleMic() {
    const SR = (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown }).SpeechRecognition
      ?? (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition;
    if (!SR) {
      alert("Voice input isn't supported in this browser.");
      return;
    }
    if (listening) {
      recRef.current?.stop();
      return;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rec = new (SR as any)();
    rec.lang = "en-US";
    rec.interimResults = true;
    rec.continuous = false;
    let base = value ? value + " " : "";
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rec.onresult = (e: any) => {
      let text = "";
      for (let i = 0; i < e.results.length; i++) text += e.results[i][0].transcript;
      onChange(base + text);
    };
    rec.onend = () => {
      setListening(false);
      base = "";
    };
    rec.onerror = () => setListening(false);
    rec.start();
    setListening(true);
    recRef.current = rec;
  }

  return (
    <div className="relative">
      {showSlash && slashItems.length > 0 && (
        <div className="absolute bottom-full left-0 mb-2 w-72 overflow-hidden rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] shadow-2xl">
          {slashItems.map((s, i) => (
            <button
              key={s.id}
              onMouseEnter={() => setSlashSel(i)}
              onClick={() => pickSlash(s)}
              disabled={!s.live}
              className={`flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm ${
                i === slashSel ? "bg-[var(--app-hover)]" : ""
              } ${s.live ? "text-[var(--app-text)] hover:bg-[var(--app-hover)]" : "text-[var(--app-muted)]"}`}
            >
              <span className="font-medium">
                {s.label}
                {!s.live && <span className="ml-1 text-[10px]">(soon)</span>}
              </span>
              {s.hint && <span className="max-w-[55%] truncate text-xs text-[var(--app-muted)]">{s.hint}</span>}
            </button>
          ))}
        </div>
      )}

      <div
        className={`rounded-[26px] border bg-[var(--app-elev)] shadow-lg transition ${
          dragOver ? "border-indigo-400 ring-2 ring-indigo-400/40" : "border-[var(--app-border)]"
        } ${variant === "hero" ? "p-3" : "p-2.5"}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
        }}
      >
        {attachments.length > 0 && (
          <div className="mb-2 flex flex-wrap gap-2 px-1">
            {attachments.map((a) => (
              <div key={a.id} className="group relative">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={a.dataUrl} alt={a.name} className="h-12 w-12 rounded-lg object-cover ring-1 ring-white/15" />
                <button
                  onClick={() => setAttachments((l) => l.filter((x) => x.id !== a.id))}
                  className="absolute -right-1.5 -top-1.5 rounded-full bg-black/80 p-0.5 text-[var(--app-text)] opacity-0 group-hover:opacity-100 hover:text-white"
                >
                  <X size={12} />
                </button>
              </div>
            ))}
          </div>
        )}

        <textarea
          ref={taRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onPaste={(e) => {
            const imgs = Array.from(e.clipboardData.files).filter((f) => f.type.startsWith("image/"));
            if (imgs.length) {
              e.preventDefault();
              addFiles(imgs);
            }
          }}
          onKeyDown={(e) => {
            if (showSlash && slashItems.length) {
              if (e.key === "ArrowDown") {
                e.preventDefault();
                setSlashSel((s) => (s + 1) % slashItems.length);
                return;
              }
              if (e.key === "ArrowUp") {
                e.preventDefault();
                setSlashSel((s) => (s - 1 + slashItems.length) % slashItems.length);
                return;
              }
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                pickSlash(slashItems[slashSel]);
                return;
              }
            }
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
          rows={1}
          placeholder={placeholder}
          className="max-h-52 w-full resize-none bg-transparent px-2 pt-1.5 text-[15px] text-[var(--app-text)] outline-none placeholder:text-[var(--app-muted)]"
        />

        <div className="mt-1 flex items-center justify-between px-1">
          <div className="flex items-center gap-1">
            <button
              onClick={() => fileRef.current?.click()}
              title="Attach image"
              className="flex h-8 w-8 items-center justify-center rounded-full text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]"
            >
              <Plus size={18} />
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files) addFiles(e.target.files);
                e.target.value = "";
              }}
            />
            <div className="relative ml-1">
              <button
                onClick={() => setModelMenu((m) => !m)}
                className="flex items-center gap-1 rounded-md px-1.5 py-1 text-xs text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]"
              >
                {activeModel?.name ?? "Model"} <ChevronDown size={12} />
              </button>
              {modelMenu && (
                <>
                  <div className="fixed inset-0 z-20" onClick={() => setModelMenu(false)} />
                  <div className="absolute bottom-full left-0 z-30 mb-1 w-52 overflow-hidden rounded-lg border border-[var(--app-border)] bg-[var(--app-panel)] shadow-2xl">
                    {models.map((m) => (
                      <button
                        key={m.id}
                        onClick={() => {
                          setActiveModel(m.id);
                          setModelMenu(false);
                        }}
                        className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm text-[var(--app-text)] hover:bg-[var(--app-hover)]"
                      >
                        <span className="truncate">{m.name}</span>
                        {m.id === activeId && <span className="h-2 w-2 shrink-0 rounded-full bg-indigo-500" />}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={toggleMic}
              title="Dictate"
              className={`flex h-8 w-8 items-center justify-center rounded-full transition ${
                listening ? "bg-rose-500/20 text-rose-400" : "text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]"
              }`}
            >
              <Mic size={17} className={listening ? "animate-pulse" : ""} />
            </button>
            {busy ? (
              <button onClick={onStop} title="Stop" className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-500 text-white hover:bg-rose-400">
                <Square size={15} fill="currentColor" />
              </button>
            ) : (
              <button
                onClick={submit}
                disabled={!value.trim() && attachments.length === 0}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--app-text)] text-[var(--app-bg)] transition hover:opacity-90 disabled:opacity-30"
              >
                <ArrowUp size={18} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
