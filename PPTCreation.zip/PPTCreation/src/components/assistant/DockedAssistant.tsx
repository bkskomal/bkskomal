"use client";

import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ChevronRight, MessageSquare, Sparkles } from "lucide-react";
import { Composer } from "./Composer";
import { useModels } from "@/lib/models";
import { useAdminConfig } from "@/lib/adminConfig";
import { toast } from "@/lib/toast";

interface Msg {
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
}

/** A compact, right-docked general assistant — used alongside tools (e.g. Compare Files). */
export function DockedAssistant({ title = "Assistant", getContext }: { title?: string; getContext?: () => string }) {
  const [open, setOpen] = useState(true);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || busy) return;
    const ctx = getContext?.() ?? "";
    const base = [...messages, { role: "user" as const, content }];
    setMessages(base);
    setInput("");
    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;
    setMessages((m) => [...m, { role: "assistant", content: "", streaming: true }]);

    const apiConvo = [
      ...(ctx ? [{ role: "user" as const, content: `Context for this session:\n${ctx}` }] : []),
      ...base.map((m) => ({ role: m.role, content: m.content })),
    ];
    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiConvo, model: useModels.getState().override(), embed: useAdminConfig.getState().embedOverride(), ragEnabled: false }),
        signal: controller.signal,
      });
      const reader = res.body!.getReader();
      const dec = new TextDecoder();
      let buf = "", reply = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n");
        buf = parts.pop() ?? "";
        for (const p of parts) {
          const line = p.trim();
          if (!line.startsWith("data:")) continue;
          const obj = JSON.parse(line.slice(5).trim());
          if (obj.type === "delta") {
            reply += obj.text;
            setMessages((m) => {
              const c = [...m];
              c[c.length - 1] = { role: "assistant", content: reply, streaming: true };
              return c;
            });
          } else if (obj.type === "final") reply = obj.result?.reply ?? reply;
          else if (obj.type === "error") toast.error(obj.hint ?? obj.error);
        }
      }
      setMessages((m) => {
        const c = [...m];
        c[c.length - 1] = { role: "assistant", content: reply || "…" };
        return c;
      });
    } catch (e) {
      if (!(e instanceof DOMException && e.name === "AbortError")) toast.error("Network error");
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  }

  if (!open) {
    return (
      <aside className="flex w-11 shrink-0 flex-col items-center border-l border-[var(--app-border)] bg-[var(--app-panel)] py-3">
        <button onClick={() => setOpen(true)} title="Open assistant" className="flex flex-col items-center gap-2 rounded-lg p-2 text-indigo-400 hover:bg-[var(--app-hover)]">
          <MessageSquare size={20} />
          <span className="text-[10px] font-semibold uppercase tracking-wide [writing-mode:vertical-rl]">Assistant</span>
        </button>
      </aside>
    );
  }

  return (
    <aside className="flex w-[360px] shrink-0 flex-col border-l border-[var(--app-border)] bg-[var(--app-panel)]">
      <div className="flex h-12 items-center justify-between border-b border-[var(--app-border)] px-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-[var(--app-text)]">
          <Sparkles size={16} className="text-indigo-400" /> {title}
        </div>
        <button onClick={() => setOpen(false)} title="Minimize" className="rounded-md p-1 text-[var(--app-muted)] hover:bg-[var(--app-hover)]">
          <ChevronRight size={18} />
        </button>
      </div>
      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto p-4">
        {messages.length === 0 && (
          <p className="text-sm text-[var(--app-muted)]">Ask me about your files or anything else. I can help interpret the comparison.</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "flex justify-end" : ""}>
            <div className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-sm ${m.role === "user" ? "bg-indigo-500 text-white" : "bg-[var(--app-hover)] text-[var(--app-text)]"}`}>
              {m.role === "assistant" ? (
                <div className="chat-md"><ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content || "…"}</ReactMarkdown></div>
              ) : (
                <p className="whitespace-pre-wrap">{m.content}</p>
              )}
            </div>
          </div>
        ))}
      </div>
      <div className="border-t border-[var(--app-border)] p-3">
        <Composer value={input} onChange={setInput} onSubmit={send} onStop={() => abortRef.current?.abort()} busy={busy} placeholder="Ask about the comparison…" />
      </div>
    </aside>
  );
}
