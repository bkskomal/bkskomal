"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Check,
  Copy,
  FileText,
  FlaskConical,
  GitCompareArrows,
  LayoutTemplate,
  Loader2,
  LogOut,
  MessageSquarePlus,
  PanelLeft,
  Presentation,
  RefreshCw,
  Search,
  Settings2,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
  Trash2,
} from "lucide-react";
import { Composer } from "./Composer";
import { ThemeCycler } from "./ThemeCycler";
import { Settings } from "./Settings";
import { useAuth } from "@/lib/auth";
import { useModels } from "@/lib/models";
import { useFeedback } from "@/lib/feedback";
import { useAdminConfig } from "@/lib/adminConfig";
import { useConversations } from "@/lib/conversations";
import type { ChatMsg } from "@/lib/chatHistory";
import type { ChatAttachment } from "@/lib/chatActions";
import { deckFromAI } from "@/lib/deck";
import { applyOrgBrand, useOrg } from "@/lib/org";
import { enrichDeckImagery } from "@/lib/imagery";
import { clearHistory, useEditor } from "@/lib/store";
import { useChatUI } from "@/components/editor/ChatPanel";
import { toast } from "@/lib/toast";

/**
 * Find a structured, slide-by-slide outline in the conversation (most recent first)
 * so it can be sent verbatim to the generator and honoured 1:1 — rather than the
 * lossy brief the chat model writes. Returns undefined when no clear outline exists.
 */
function detectOutline(convo: { role: string; content: string }[]): string | undefined {
  for (let i = convo.length - 1; i >= 0; i--) {
    const m = convo[i];
    if (m.role !== "user") continue;
    const c = m.content ?? "";
    if (c.length < 400) continue;
    const slideHeads = (c.match(/(^|\n)\s*#{0,6}\s*slide\s*\d+/gi) || []).length;
    const h2 = (c.match(/(^|\n)#{1,2}\s+\S/g) || []).length;
    if (slideHeads >= 3 || h2 >= 4) return c;
  }
  return undefined;
}

interface StepResult {
  reply?: string;
  open?: { skill: "ppt"; brief: string; slideCount?: number };
  error?: string;
  aborted?: boolean;
}

const STARTERS = [
  { icon: <Presentation size={16} />, label: "Create a presentation", prompt: "Create a 10-slide investor pitch for an AI startup", live: true, href: undefined as string | undefined },
  { icon: <GitCompareArrows size={16} />, label: "Compare files", prompt: "", live: true, href: "/compare" },
  { icon: <Sparkles size={16} />, label: "Brainstorm", prompt: "Brainstorm 10 ideas for ", live: true, href: undefined },
  { icon: <FileText size={16} />, label: "Write", prompt: "Write a professional email to ", live: true, href: undefined },
];

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export function AssistantApp() {
  const router = useRouter();
  // derive the current user reactively from currentId + users so the greeting
  // always reflects whoever is logged in (and updates on rename)
  const currentId = useAuth((s) => s.currentId);
  const users = useAuth((s) => s.users);
  const logout = useAuth((s) => s.logout);
  const updateName = useAuth((s) => s.updateName);
  const isAdmin = useAuth((s) => s.isSuperAdmin());
  const user = users.find((u) => u.id === currentId) ?? null;
  const userId = user?.id ?? "";
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState("");

  const convList = useConversations((s) => s.byUser[userId] ?? []);
  const createConv = useConversations((s) => s.create);
  const getConv = useConversations((s) => s.get);
  const saveConv = useConversations((s) => s.setMessages);
  const removeConv = useConversations((s) => s.remove);

  const [convId, setConvId] = useState("");
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [launching, setLaunching] = useState(false);
  const [sidebar, setSidebar] = useState(true);
  const [search, setSearch] = useState("");
  const [copied, setCopied] = useState<number | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [feedback, setFeedback] = useState<Record<number, "up" | "down">>({});
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!userId) return;
    const list = useConversations.getState().byUser[userId] ?? [];
    const id = list[0]?.id ?? createConv(userId);
    setConvId(id);
    setMessages(useConversations.getState().get(userId, id)?.messages ?? []);
  }, [userId, createConv]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  useEffect(() => {
    if (userId && convId && !busy && messages.length) saveConv(userId, convId, messages);
  }, [messages, busy, userId, convId, saveConv]);

  const sortedConvs = useMemo(
    () =>
      [...convList]
        .sort((a, b) => b.updatedAt - a.updatedAt)
        .filter((c) => !search.trim() || c.title.toLowerCase().includes(search.toLowerCase())),
    [convList, search],
  );

  function openConversation(id: string) {
    setConvId(id);
    setMessages(getConv(userId, id)?.messages ?? []);
  }
  function newConversation() {
    const id = createConv(userId);
    setConvId(id);
    setMessages([]);
    setInput("");
  }

  async function saveEvalCase(i: number) {
    const answer = messages[i]?.content ?? "";
    let prompt = "";
    for (let k = i - 1; k >= 0; k--) if (messages[k].role === "user") { prompt = messages[k].content; break; }
    if (!prompt) return;
    await fetch("/api/evals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, skill: "chat", prompt, expected: answer }),
    }).catch(() => {});
    toast.success("Saved as an eval case");
  }

  async function copyMsg(text: string, i: number) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(i);
      setTimeout(() => setCopied((c) => (c === i ? null : c)), 1200);
    } catch {
      toast.error("Couldn't copy");
    }
  }

  function rate(i: number, v: "up" | "down") {
    const already = feedback[i] === v;
    setFeedback((f) => {
      const next = { ...f };
      if (next[i] === v) delete next[i];
      else next[i] = v;
      return next;
    });
    if (already) return;
    // capture with context so it can train/evaluate the assistant later
    const answer = messages[i]?.content ?? "";
    let prompt = "";
    for (let k = i - 1; k >= 0; k--) if (messages[k].role === "user") { prompt = messages[k].content; break; }
    const model = useModels.getState().active().name;
    useFeedback.getState().add({ userId, convId, rating: v, model, prompt, answer });
    // persist to the self-learning backend (👍 becomes a RAG exemplar); no-op if DB is off
    fetch("/api/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, convId, rating: v, model, prompt, answer, skill: "chat", embed: useAdminConfig.getState().embedOverride() }),
    }).catch(() => {});
    toast.success(v === "up" ? "Thanks for the feedback!" : "Thanks — we'll use this to improve.");
  }


  async function launchPpt(brief: string, slideCount?: number, outline?: string) {
    setLaunching(true);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: brief, slideCount, outline, model: useModels.getState().override() }),
      });
      const data = await res.json();
      if (!res.ok) return toast.error(data.hint ?? data.error ?? "Couldn't build the presentation");
      const n = data.deck?.slides?.length ?? 0;
      if (data.source === "outline") toast.success(`Outline honored — ${n}/${n} slides built from your content`);
      else toast.info(`AI-generated — ${n} slides`);
      useEditor.getState().setDeck(applyOrgBrand(deckFromAI(data.deck), useOrg.getState().org));
      clearHistory();
      enrichDeckImagery(useEditor.getState().deck!); // fills image slides with relevant photos (if configured)
      useChatUI.getState().set(true);
      router.push("/editor");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Network error");
    } finally {
      setLaunching(false);
    }
  }

  async function streamStep(apiConvo: { role: "user" | "assistant"; content: string }[], signal: AbortSignal, onDelta: (t: string) => void): Promise<StepResult> {
    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: apiConvo,
          userId,
          convId,
          model: useModels.getState().override(),
          embed: useAdminConfig.getState().embedOverride(),
          ragTopK: useAdminConfig.getState().ragTopK,
          ragEnabled: useAdminConfig.getState().ragEnabled,
        }),
        signal,
      });
      if (!res.ok || !res.body) return { error: `Assistant failed (${res.status})` };
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let final: StepResult | null = null;
      let error: StepResult | null = null;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n");
        buf = parts.pop() ?? "";
        for (const p of parts) {
          const line = p.trim();
          if (!line.startsWith("data:")) continue;
          const obj = JSON.parse(line.slice(5).trim());
          if (obj.type === "delta") onDelta(obj.text);
          else if (obj.type === "final") final = obj.result;
          else if (obj.type === "error") error = { error: obj.hint ?? obj.error };
        }
      }
      return error ?? final ?? { error: "No response" };
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return { aborted: true };
      return { error: e instanceof Error ? e.message : "Network error" };
    }
  }

  async function runTurn(base: ChatMsg[], apiConvo: { role: "user" | "assistant"; content: string }[]): Promise<StepResult> {
    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;
    setMessages([...base, { role: "assistant", content: "", streaming: true }]);
    const onDelta = (t: string) =>
      setMessages((m) => {
        const copy = [...m];
        const last = copy[copy.length - 1];
        if (last?.role === "assistant") copy[copy.length - 1] = { ...last, content: last.content + t };
        return copy;
      });
    const result = await streamStep(apiConvo, controller.signal, onDelta);
    setMessages((m) => {
      const copy = [...m];
      const text = result.aborted
        ? copy[copy.length - 1]?.content || "⏹ Stopped."
        : result.error
          ? result.error
          : result.reply ?? "Done.";
      copy[copy.length - 1] = { role: "assistant", content: text };
      return copy;
    });
    setBusy(false);
    abortRef.current = null;
    if (result.open?.skill === "ppt") await launchPpt(result.open.brief ?? "A presentation", result.open.slideCount, detectOutline(apiConvo));
    else if (result.open?.skill === "compare") router.push("/compare");
    return result;
  }

  function send(text: string, attachments: ChatAttachment[] = []) {
    const content = text.trim();
    if ((!content && attachments.length === 0) || busy) return;
    const note = attachments.length ? `\n\n[User attached ${attachments.length} file(s): ${attachments.map((a) => a.name).join(", ")}]` : "";
    const base: ChatMsg[] = [...messages, { role: "user", content: content || "(attachment)", thumbs: attachments.map((a) => a.dataUrl) }];
    setMessages(base);
    setInput("");
    const apiConvo = [...messages.map((m) => ({ role: m.role, content: m.content })), { role: "user" as const, content: content + note }];
    runTurn(base, apiConvo);
  }

  async function regenerateLast() {
    if (busy) return;
    let idx = -1;
    for (let i = messages.length - 1; i >= 0; i--) if (messages[i].role === "user") { idx = i; break; }
    if (idx < 0) return;
    const prompt = messages[idx].content;
    const rejected = messages[idx + 1]?.role === "assistant" ? messages[idx + 1].content : "";
    const trimmed = messages.slice(0, idx + 1);
    const result = await runTurn(trimmed, trimmed.map((m) => ({ role: m.role, content: m.content })));
    // a regenerate = a preference pair: old answer rejected, new answer chosen (DPO/LoRA data)
    if (rejected && result?.reply && result.reply !== rejected) {
      fetch("/api/preference", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, prompt, rejected, chosen: result.reply, model: useModels.getState().active().name }),
      }).catch(() => {});
    }
  }

  const empty = messages.length === 0;
  const firstName = user?.name?.split(" ")[0] ?? "there";

  return (
    <div className="flex flex-1 overflow-hidden">
      {/* Sidebar */}
      {sidebar && (
        <aside className="flex w-64 shrink-0 flex-col border-r border-[var(--app-border)] bg-[var(--app-panel)]">
          <div className="flex items-center justify-between px-3.5 pb-1 pt-3.5">
            <div className="flex items-center gap-2">
              <Sparkles size={17} className="text-indigo-400" />
              <span className="text-[15px] font-semibold text-[var(--app-text)]">OATIGenie</span>
            </div>
            <button onClick={() => setSidebar(false)} title="Collapse sidebar" className="rounded-md p-1.5 text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
              <PanelLeft size={17} />
            </button>
          </div>
          <div className="p-2">
            <button
              onClick={newConversation}
              className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium text-[var(--app-text)] hover:bg-[var(--app-hover)]"
            >
              <MessageSquarePlus size={17} className="text-[var(--app-muted)]" /> New chat
            </button>
          </div>
          <div className="px-3 pb-2">
            <div className="flex items-center gap-2 rounded-lg bg-[var(--app-elev)] px-2.5">
              <Search size={14} className="text-[var(--app-muted)]" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search chats"
                className="h-8 flex-1 bg-transparent text-sm outline-none placeholder:text-[var(--app-faint)]"
              />
            </div>
          </div>
          <div className="flex-1 space-y-0.5 overflow-y-auto px-2">
            {sortedConvs.map((c) => (
              <div key={c.id} className="group relative">
                <button
                  onClick={() => openConversation(c.id)}
                  className={`block w-full truncate rounded-lg px-3 py-2 pr-8 text-left text-sm ${
                    c.id === convId ? "bg-[var(--app-hover)] text-[var(--app-text)]" : "text-[var(--app-muted)] hover:bg-[var(--app-hover)]"
                  }`}
                >
                  {c.title}
                </button>
                <button
                  onClick={() => {
                    removeConv(userId, c.id);
                    if (c.id === convId) newConversation();
                  }}
                  className="absolute right-1.5 top-1.5 rounded p-1 text-[var(--app-faint)] opacity-0 hover:text-rose-400 group-hover:opacity-100"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
          </div>
          <div className="border-t border-[var(--app-border)] p-3">
            <button onClick={() => setSettingsOpen(true)} className="mb-1 flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
              <Settings2 size={15} /> Settings
            </button>
            <Link href="/templates" className="mb-1 flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
              <LayoutTemplate size={15} /> PPT Creation
            </Link>
            <Link href="/compare" className="mb-2 flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
              <GitCompareArrows size={15} /> Compare Files
            </Link>
            <div className="flex items-center justify-between rounded-lg px-2 py-1.5">
              <div className="flex min-w-0 items-center gap-2">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-indigo-500 text-xs font-bold text-white">
                  {firstName[0]?.toUpperCase()}
                </div>
                <div className="min-w-0">
                  {editingName ? (
                    <input
                      autoFocus
                      value={nameDraft}
                      onChange={(e) => setNameDraft(e.target.value)}
                      onBlur={() => {
                        updateName(nameDraft);
                        setEditingName(false);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          updateName(nameDraft);
                          setEditingName(false);
                        }
                        if (e.key === "Escape") setEditingName(false);
                      }}
                      className="w-full rounded bg-[var(--app-elev)] px-1.5 py-0.5 text-sm text-[var(--app-text)] outline-none ring-1 ring-indigo-400/50"
                    />
                  ) : (
                    <button
                      onClick={() => {
                        setNameDraft(user?.name ?? "");
                        setEditingName(true);
                      }}
                      title="Edit your name"
                      className="block max-w-full truncate text-left text-sm font-medium text-[var(--app-text)] hover:text-white"
                    >
                      {user?.name}
                    </button>
                  )}
                  <div className="truncate text-xs text-[var(--app-muted)]">{user?.email}</div>
                </div>
              </div>
              <button onClick={logout} title="Log out" className="rounded-md p-1.5 text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
                <LogOut size={16} />
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* Collapsed: slim icon rail */}
      {!sidebar && (
        <aside className="flex w-14 shrink-0 flex-col items-center gap-1 border-r border-[var(--app-border)] bg-[var(--app-panel)] py-3">
          <RailBtn title="Expand sidebar" onClick={() => setSidebar(true)}>
            <PanelLeft size={18} />
          </RailBtn>
          <div className="my-1 h-px w-6 bg-[var(--app-border)]" />
          <RailBtn title="New chat" onClick={newConversation}>
            <MessageSquarePlus size={18} />
          </RailBtn>
          <RailBtn title="Search chats" onClick={() => setSidebar(true)}>
            <Search size={18} />
          </RailBtn>
          <Link href="/templates" title="PPT Creation" className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
            <LayoutTemplate size={18} />
          </Link>
          <Link href="/compare" title="Compare Files" className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
            <GitCompareArrows size={18} />
          </Link>
          <RailBtn title="Settings" onClick={() => setSettingsOpen(true)}>
            <Settings2 size={18} />
          </RailBtn>
          <div className="flex-1" />
          <button
            onClick={() => setSidebar(true)}
            title={user?.name}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-500 text-xs font-bold text-white"
          >
            {firstName[0]?.toUpperCase()}
          </button>
        </aside>
      )}

      {/* Main */}
      <main className="flex flex-1 flex-col">
        <div className="flex h-11 items-center justify-end gap-1 px-3">
          {!sidebar && (
            <button onClick={() => setSidebar(true)} title="Open sidebar" className="mr-auto rounded-md p-1.5 text-[var(--app-muted)] hover:bg-[var(--app-hover)]">
              <PanelLeft size={17} />
            </button>
          )}
          <ThemeCycler />
        </div>
        {empty ? (
          /* ---- Empty state: centered hero ---- */
          <div className="flex flex-1 flex-col items-center justify-center px-4">
            <div className="mb-6 flex items-center gap-3">
              <Sparkles size={26} className="text-indigo-400" />
              <h1 className="text-3xl font-semibold text-[var(--app-text)]" style={{ fontFamily: "'Playfair Display', serif" }}>
                {greeting()}, {firstName}
              </h1>
            </div>
            <div className="w-full max-w-2xl">
              <Composer value={input} onChange={setInput} onSubmit={send} onStop={() => abortRef.current?.abort()} busy={busy} variant="hero" autoFocus />
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {STARTERS.map((s) => (
                  <button
                    key={s.label}
                    onClick={() => {
                      if (!s.live) return;
                      if (s.href) return void router.push(s.href);
                      const p = s.prompt.trim();
                      if (p.endsWith("for") || p.endsWith("to")) setInput(s.prompt);
                      else send(s.prompt);
                    }}
                    disabled={!s.live}
                    className="flex items-center gap-2 rounded-full border border-[var(--app-border)] px-3.5 py-2 text-sm text-[var(--app-text)] transition hover:border-indigo-400/60 hover:bg-[var(--app-hover)] disabled:opacity-50"
                  >
                    <span className="text-indigo-400">{s.icon}</span>
                    {s.label}
                    {!s.live && <span className="text-[10px] text-[var(--app-muted)]">soon</span>}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* ---- Active chat ---- */
          <>
            <div ref={scrollRef} className="flex-1 overflow-y-auto">
              <div className="mx-auto max-w-3xl px-4 py-6">
                <div className="space-y-5">
                  {messages.map((m, i) => (
                    <div key={i} className={`group ${m.role === "user" ? "flex justify-end" : "flex gap-3"}`}>
                      {m.role === "assistant" && (
                        <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-indigo-500">
                          <Sparkles size={14} className="text-white" />
                        </div>
                      )}
                      <div className={m.role === "user" ? "max-w-[80%]" : "flex-1"}>
                        {m.thumbs && m.thumbs.length > 0 && (
                          <div className="mb-1.5 flex flex-wrap justify-end gap-1.5">
                            {m.thumbs.map((t, j) => (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img key={j} src={t} alt="" className="h-16 w-16 rounded-lg object-cover ring-1 ring-white/15" />
                            ))}
                          </div>
                        )}
                        <div className={m.role === "user" ? "rounded-2xl bg-indigo-500 px-4 py-2.5 text-white" : "pt-1"}>
                          {m.role === "assistant" ? (
                            m.content ? (
                              <div className="chat-md">
                                <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                                {m.streaming && <span className="ml-0.5 inline-block h-3.5 w-1.5 animate-pulse bg-indigo-400 align-middle" />}
                              </div>
                            ) : (
                              <span className="inline-flex gap-1 py-1">
                                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500 [animation-delay:-0.2s]" />
                                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500 [animation-delay:-0.1s]" />
                                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500" />
                              </span>
                            )
                          ) : (
                            <p className="whitespace-pre-wrap text-sm">{m.content}</p>
                          )}
                        </div>
                        {m.role === "assistant" && !m.streaming && m.content && (
                          <div className="mt-1 flex gap-0.5 opacity-0 transition group-hover:opacity-100">
                            <ActionBtn title="Copy" onClick={() => copyMsg(m.content, i)}>
                              {copied === i ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                            </ActionBtn>
                            <ActionBtn title="Good response" onClick={() => rate(i, "up")}>
                              <ThumbsUp size={14} className={feedback[i] === "up" ? "text-emerald-400" : ""} />
                            </ActionBtn>
                            <ActionBtn title="Bad response" onClick={() => rate(i, "down")}>
                              <ThumbsDown size={14} className={feedback[i] === "down" ? "text-rose-400" : ""} />
                            </ActionBtn>
                            {i === messages.length - 1 && (
                              <ActionBtn title="Regenerate" onClick={regenerateLast} disabled={busy}>
                                <RefreshCw size={14} />
                              </ActionBtn>
                            )}
                            {isAdmin && (
                              <ActionBtn title="Save as eval case" onClick={() => saveEvalCase(i)}>
                                <FlaskConical size={14} />
                              </ActionBtn>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {launching && (
                    <div className="flex items-center gap-2 text-sm text-indigo-300">
                      <Loader2 size={15} className="animate-spin" /> Building your presentation…
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="px-4 pb-4">
              <div className="mx-auto max-w-3xl">
                <Composer value={input} onChange={setInput} onSubmit={send} onStop={() => abortRef.current?.abort()} busy={busy} />
                <p className="mt-1.5 text-center text-[11px] text-[var(--app-faint)]">
                  OATIGenie can create presentations today — more skills are on the way.
                </p>
              </div>
            </div>
          </>
        )}
      </main>

      <Settings open={settingsOpen} onClose={() => setSettingsOpen(false)} userId={userId} />
    </div>
  );
}

function ActionBtn({ children, title, onClick, disabled }: { children: React.ReactNode; title: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className="rounded-md p-1.5 text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)] disabled:opacity-40"
    >
      {children}
    </button>
  );
}

function RailBtn({ children, title, onClick }: { children: React.ReactNode; title: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]"
    >
      {children}
    </button>
  );
}
