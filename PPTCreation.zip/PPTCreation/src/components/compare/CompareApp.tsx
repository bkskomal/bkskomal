"use client";

import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { AlertTriangle, ArrowLeft, Download, FileSpreadsheet, FileText, FileType2, GitCompareArrows, Loader2, RotateCcw, Sparkles, Upload, X } from "lucide-react";
import { DockedAssistant } from "@/components/assistant/DockedAssistant";
import { compareWorkbooks, parseWorkbook, summarizeDiff, POSITION_KEY, type CompareOptions, type CompareResult, type SheetDiff, type Workbook } from "@/lib/compare";
import { PYEXPORT_URL } from "@/lib/export-hd";
import { useModels } from "@/lib/models";
import { toast } from "@/lib/toast";

type FileKind = "sheet" | "docx" | "pdf";
const KINDS: { id: FileKind; label: string; accept: string; icon: React.ReactNode; doc?: boolean }[] = [
  { id: "sheet", label: "Excel / CSV", accept: ".xlsx,.xls,.csv", icon: <FileSpreadsheet size={16} /> },
  { id: "docx", label: "Word", accept: ".docx", icon: <FileType2 size={16} />, doc: true },
  { id: "pdf", label: "PDF", accept: ".pdf", icon: <FileType2 size={16} />, doc: true },
];

interface DocBlock { type: "equal" | "added" | "removed"; text: string }

export function CompareApp() {
  const [kind, setKind] = useState<FileKind>("sheet");
  const [a, setA] = useState<File | null>(null);
  const [b, setB] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [dlBusy, setDlBusy] = useState(false);
  const [sheetResult, setSheetResult] = useState<CompareResult | null>(null);
  const [docResult, setDocResult] = useState<{ blocks: DocBlock[]; added: number; removed: number } | null>(null);
  const [aiSummary, setAiSummary] = useState("");
  // parsed workbooks are kept so the comparison can be re-run instantly when accuracy options change
  const books = useRef<{ a: Workbook; b: Workbook } | null>(null);
  const [opts, setOpts] = useState<CompareOptions>({ firstRowHeader: true, ignoreCase: false, ignoreWhitespace: false, keys: {} });
  const isDoc = KINDS.find((k) => k.id === kind)!.doc;
  const hasResult = !!sheetResult || !!docResult;

  /** Re-run the (client-side) workbook diff with the current options, refresh AI narrative. */
  function recompute(next: CompareOptions) {
    setOpts(next);
    if (!books.current) return;
    const result = compareWorkbooks(books.current.a, books.current.b, next);
    setSheetResult(result);
    summarize(summarizeDiff(result));
  }

  async function summarize(diffText: string) {
    try {
      const r = await fetch("/api/summarize-diff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ diff: diffText, model: useModels.getState().override() }),
      }).then((x) => x.json());
      if (r.summary) setAiSummary(r.summary);
    } catch {
      /* summary is best-effort */
    }
  }

  async function start() {
    if (!a || !b) return;
    setBusy(true);
    setAiSummary("");
    try {
      if (isDoc) {
        if (!PYEXPORT_URL) throw new Error("Comparison service not configured (NEXT_PUBLIC_PYEXPORT_URL).");
        const fd = new FormData();
        fd.append("original", a);
        fd.append("updated", b);
        const res = await fetch(`${PYEXPORT_URL.replace(/\/$/, "")}/compare-doc?kind=${kind}`, { method: "POST", body: fd });
        if (!res.ok) throw new Error("Couldn't read those documents");
        const data = await res.json();
        setDocResult(data);
        const diffText = data.blocks.filter((x: DocBlock) => x.type !== "equal").map((x: DocBlock) => `${x.type === "added" ? "+" : "-"} ${x.text}`).slice(0, 200).join("\n");
        summarize(`Document diff (${a.name} → ${b.name}):\n${diffText}`);
      } else {
        const [wa, wb] = await Promise.all([parseWorkbook(a), parseWorkbook(b)]);
        books.current = { a: wa, b: wb };
        const freshOpts = { firstRowHeader: true, ignoreCase: false, ignoreWhitespace: false, keys: {} };
        setOpts(freshOpts);
        const result = compareWorkbooks(wa, wb, freshOpts);
        setSheetResult(result);
        summarize(summarizeDiff(result));
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Comparison failed");
    } finally {
      setBusy(false);
    }
  }

  async function download() {
    if (!a || !b) return;
    setDlBusy(true);
    try {
      if (!PYEXPORT_URL) throw new Error("Export service not configured.");
      let res: Response;
      let filename: string;
      if (isDoc) {
        const fd = new FormData();
        fd.append("original", a);
        fd.append("updated", b);
        res = await fetch(`${PYEXPORT_URL.replace(/\/$/, "")}/compare-doc-docx?kind=${kind}`, { method: "POST", body: fd });
        filename = "comparison-redline.docx";
      } else {
        res = await fetch(`${PYEXPORT_URL.replace(/\/$/, "")}/build-diff-xlsx`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ result: sheetResult, aiSummary }),
        });
        filename = "comparison-report.xlsx";
      }
      if (!res.ok) throw new Error("Couldn't build the document");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const el = document.createElement("a");
      el.href = url;
      el.download = filename;
      el.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Network error");
    } finally {
      setDlBusy(false);
    }
  }

  function reset() {
    setA(null);
    setB(null);
    setSheetResult(null);
    setDocResult(null);
    setAiSummary("");
    books.current = null;
    setOpts({ firstRowHeader: true, ignoreCase: false, ignoreWhitespace: false, keys: {} });
  }

  const accept = KINDS.find((k) => k.id === kind)!.accept;
  const context = useMemo(
    () => () => (sheetResult ? summarizeDiff(sheetResult) : docResult ? `Document diff: ${docResult.added} added, ${docResult.removed} removed lines.` : "No comparison run yet."),
    [sheetResult, docResult],
  );

  return (
    <div className="flex flex-1 overflow-hidden">
      <main className="flex flex-1 flex-col overflow-hidden">
        <div className="flex h-12 shrink-0 items-center gap-3 border-b border-[var(--app-border)] px-4">
          <Link href="/" className="flex items-center gap-1.5 text-sm text-[var(--app-muted)] hover:text-[var(--app-text)]">
            <ArrowLeft size={15} /> Assistant
          </Link>
          <div className="h-5 w-px bg-[var(--app-border)]" />
          <span className="flex items-center gap-2 text-sm font-semibold text-[var(--app-text)]">
            <GitCompareArrows size={16} className="text-indigo-400" /> Compare Files
          </span>
          {hasResult && (
            <div className="ml-auto flex items-center gap-2">
              <button onClick={download} disabled={dlBusy} className="flex items-center gap-1.5 rounded-lg bg-indigo-500 px-3 py-1.5 text-sm font-medium text-white hover:bg-indigo-400 disabled:opacity-50">
                {dlBusy ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                {isDoc ? "Redline .docx" : "Merged report .xlsx"}
              </button>
              <button onClick={reset} className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm text-[var(--app-muted)] hover:bg-[var(--app-hover)] hover:text-[var(--app-text)]">
                <RotateCcw size={14} /> New
              </button>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto">
          {!hasResult ? (
            <div className="mx-auto flex min-h-full max-w-3xl flex-col items-center justify-center px-4 py-8">
              <h1 className="text-2xl font-semibold text-[var(--app-text)]">Compare two files</h1>
              <p className="mt-1 text-sm text-[var(--app-muted)]">Context-aware diff — matched by keys (single or composite), not cell positions. Every tab compared, renamed tabs detected, Excel↔CSV supported. AI explains what changed.</p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {KINDS.map((k) => (
                  <button key={k.id} onClick={() => { setKind(k.id); reset(); }} className={`flex items-center gap-2 rounded-full border px-3.5 py-2 text-sm ${kind === k.id ? "border-indigo-400 bg-indigo-500/10 text-[var(--app-text)]" : "border-[var(--app-border)] text-[var(--app-muted)] hover:bg-[var(--app-hover)]"}`}>
                    {k.icon} {k.label}
                  </button>
                ))}
              </div>
              <div className="mt-6 grid w-full grid-cols-1 gap-4 sm:grid-cols-2">
                <Drop label="Original file" file={a} onFile={setA} accept={accept} />
                <Drop label="Updated file" file={b} onFile={setB} accept={accept} />
              </div>
              <button onClick={start} disabled={!a || !b || busy} className="mt-6 flex items-center gap-2 rounded-xl bg-indigo-500 px-6 py-2.5 text-sm font-medium text-white hover:bg-indigo-400 disabled:opacity-40">
                {busy ? <Loader2 size={16} className="animate-spin" /> : <GitCompareArrows size={16} />}
                Start comparison
              </button>
            </div>
          ) : (
            <div className="mx-auto max-w-4xl px-4 py-6">
              {aiSummary && (
                <div className="mb-5 rounded-xl border border-indigo-500/30 bg-indigo-500/5 p-4">
                  <div className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-indigo-300"><Sparkles size={15} /> What changed</div>
                  <div className="chat-md text-[var(--app-text)]"><ReactMarkdown remarkPlugins={[remarkGfm]}>{aiSummary}</ReactMarkdown></div>
                </div>
              )}
              {sheetResult && <SheetResults result={sheetResult} opts={opts} onOpts={recompute} />}
              {docResult && <DocResults doc={docResult} />}
            </div>
          )}
        </div>
      </main>

      <DockedAssistant title="Assistant" getContext={context} />
    </div>
  );
}

function SheetResults({ result, opts, onOpts }: { result: CompareResult; opts: CompareOptions; onOpts: (o: CompareOptions) => void }) {
  const { totals } = result;
  return (
    <>
      <div className="mb-3 flex flex-wrap items-center gap-3 text-sm">
        <span className="text-[var(--app-muted)]"><b className="text-[var(--app-text)]">{result.a}</b> → <b className="text-[var(--app-text)]">{result.b}</b></span>
        <span className="text-xs text-[var(--app-muted)]">· compared {result.sheets.length} tab{result.sheets.length === 1 ? "" : "s"}</span>
        <Chip color="emerald" label={`${totals.added} rows added`} />
        <Chip color="rose" label={`${totals.removed} removed`} />
        <Chip color="amber" label={`${totals.modified} modified`} />
      </div>

      {/* Accuracy controls — matching options are applied instantly, client-side */}
      <div className="mb-4 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-[var(--app-border)] bg-[var(--app-hover)]/50 px-3 py-2 text-xs">
        <span className="font-medium text-[var(--app-muted)]">Matching:</span>
        <Toggle checked={opts.firstRowHeader !== false} onChange={(v) => onOpts({ ...opts, firstRowHeader: v })} label="First row is header" />
        <Toggle checked={!!opts.ignoreCase} onChange={(v) => onOpts({ ...opts, ignoreCase: v })} label="Ignore case" />
        <Toggle checked={!!opts.ignoreWhitespace} onChange={(v) => onOpts({ ...opts, ignoreWhitespace: v })} label="Ignore whitespace" />
        <label className="flex items-center gap-1.5 text-[var(--app-muted)]">
          Number tolerance
          <select
            value={opts.numericTolerancePct ?? 0}
            onChange={(e) => onOpts({ ...opts, numericTolerancePct: Number(e.target.value) })}
            className="rounded border border-[var(--app-border)] bg-[var(--app-bg)] px-1.5 py-0.5 text-xs text-[var(--app-text)]"
          >
            <option value={0}>Exact</option>
            <option value={0.1}>± 0.1%</option>
            <option value={1}>± 1%</option>
            <option value={5}>± 5%</option>
          </select>
        </label>
      </div>

      {result.sheets.map((sh) => (
        <div key={sh.name} className="mb-4 overflow-hidden rounded-xl border border-[var(--app-border)]">
          <div className="flex flex-wrap items-center justify-between gap-2 bg-[var(--app-hover)] px-3 py-2">
            <span className="flex flex-wrap items-center gap-2 text-sm font-medium text-[var(--app-text)]">
              {sh.name}
              {sh.renamedFrom && <span className="rounded bg-sky-500/15 px-1.5 py-0.5 text-[10px] font-normal text-sky-300">renamed from “{sh.renamedFrom}”</span>}
              {sh.keyCandidates.length > 0 && sh.status !== "same" && <KeySelector sheet={sh.name} sh={sh} opts={opts} onOpts={onOpts} />}
            </span>
            <span className="text-xs text-[var(--app-muted)]">
              {sh.status === "same" ? "no changes" : `+${sh.added} −${sh.removed} ~${sh.modified}`}
              {sh.addedCols.length > 0 && <span className="ml-2 text-emerald-400">+cols: {sh.addedCols.join(", ")}</span>}
              {sh.removedCols.length > 0 && <span className="ml-2 text-rose-400">−cols: {sh.removedCols.join(", ")}</span>}
            </span>
          </div>
          {sh.note && (
            <div className={`flex items-start gap-1.5 px-3 py-1.5 text-xs ${sh.keyUnique && sh.status !== "same" && sh.keyColumn ? "text-[var(--app-muted)]" : "text-amber-400"}`}>
              {(!sh.keyUnique || !sh.keyColumn) && sh.status === "changed" && <AlertTriangle size={13} className="mt-0.5 shrink-0" />}
              <span>{sh.note}</span>
            </div>
          )}
          {sh.rows.length > 0 && (
            <table className="w-full text-left text-xs">
              <thead className="text-[var(--app-muted)]"><tr><th className="px-3 py-1.5 font-medium">Change</th><th className="px-3 py-1.5 font-medium">{sh.keyColumn ?? "Row"}</th><th className="px-3 py-1.5 font-medium">Details</th></tr></thead>
              <tbody>
                {sh.rows.slice(0, 80).map((row, i) => (
                  <tr key={i} className="border-t border-[var(--app-border)] align-top">
                    <td className={`px-3 py-1.5 font-medium ${row.type === "added" ? "text-emerald-400" : row.type === "removed" ? "text-rose-400" : "text-amber-400"}`}>{row.type}</td>
                    <td className="px-3 py-1.5 font-mono text-[var(--app-muted)]">{row.key}</td>
                    <td className="px-3 py-1.5 text-[var(--app-text)]">
                      {row.type === "modified"
                        ? row.fields.map((f, j) => (<div key={j}><span className="text-[var(--app-muted)]">{f.col}:</span> <span className="text-rose-400 line-through">{f.old || "—"}</span> → <span className="text-emerald-400">{f.new || "—"}</span>{f.delta && <span className="ml-1 rounded bg-amber-500/15 px-1 text-[10px] text-amber-300">{f.delta}</span>}</div>))
                        : Object.entries(row.values).slice(0, 6).map(([k, v]) => v && `${k}: ${v}`).filter(Boolean).join(" · ")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {sh.rows.length > 80 && <div className="px-3 py-2 text-xs text-[var(--app-muted)]">+ {sh.rows.length - 80} more changes (in the downloaded report)…</div>}
        </div>
      ))}
    </>
  );
}

function DocResults({ doc }: { doc: { blocks: DocBlock[]; added: number; removed: number } }) {
  return (
    <>
      <div className="mb-4 flex items-center gap-3 text-sm">
        <Chip color="emerald" label={`${doc.added} added`} />
        <Chip color="rose" label={`${doc.removed} removed`} />
        <span className="text-[var(--app-muted)]">lines</span>
      </div>
      <div className="rounded-xl border border-[var(--app-border)] p-3 font-mono text-xs leading-relaxed">
        {doc.blocks.slice(0, 400).map((b, i) => (
          <div key={i} className={b.type === "added" ? "bg-emerald-500/10 text-emerald-300" : b.type === "removed" ? "bg-rose-500/10 text-rose-300 line-through" : "text-[var(--app-muted)]"}>
            {(b.type === "added" ? "+ " : b.type === "removed" ? "− " : "  ") + b.text}
          </div>
        ))}
        {doc.blocks.length > 400 && <div className="mt-2 text-[var(--app-muted)]">+ {doc.blocks.length - 400} more lines (in the downloaded redline)…</div>}
      </div>
    </>
  );
}

function Drop({ label, file, onFile, accept }: { label: string; file: File | null; onFile: (f: File | null) => void; accept: string }) {
  const ref = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  return (
    <div>
      <div className="mb-1.5 text-xs font-medium text-[var(--app-muted)]">{label}</div>
      <div
        onClick={() => ref.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); if (e.dataTransfer.files[0]) onFile(e.dataTransfer.files[0]); }}
        className={`flex h-32 cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-4 text-center transition ${over ? "border-indigo-400 bg-indigo-500/5" : "border-[var(--app-border)] hover:bg-[var(--app-hover)]"}`}
      >
        {file ? (
          <div className="flex items-center gap-2 text-sm text-[var(--app-text)]">
            <FileText size={18} className="text-indigo-400" />
            <span className="max-w-[180px] truncate">{file.name}</span>
            <button onClick={(e) => { e.stopPropagation(); onFile(null); }} className="text-[var(--app-muted)] hover:text-rose-400"><X size={15} /></button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-1 text-[var(--app-muted)]"><Upload size={20} /><span className="text-sm">Drop a file or click to browse</span></div>
        )}
        <input ref={ref} type="file" accept={accept} className="hidden" onChange={(e) => onFile(e.target.files?.[0] ?? null)} />
      </div>
    </div>
  );
}

function Chip({ color, label }: { color: "emerald" | "rose" | "amber"; label: string }) {
  const c = { emerald: "text-emerald-400", rose: "text-rose-400", amber: "text-amber-400" }[color];
  return <span className={`rounded-full bg-[var(--app-hover)] px-2.5 py-1 text-xs font-medium ${c}`}>{label}</span>;
}

/** Per-tab key picker: shows the resolved key column(s), supports composite keys, positional, or auto. */
function KeySelector({ sheet, sh, opts, onOpts }: { sheet: string; sh: SheetDiff; opts: CompareOptions; onOpts: (o: CompareOptions) => void }) {
  const override = opts.keys?.[sheet];
  const isPosition = override === POSITION_KEY;
  const explicit = override !== undefined;
  const selected = Array.isArray(override) ? override : typeof override === "string" && override !== POSITION_KEY ? [override] : [];
  const remaining = sh.keyCandidates.filter((c) => !selected.includes(c));
  const shown = explicit && !isPosition ? selected : sh.keyColumns;

  const setKeys = (val: string | string[] | undefined) => {
    const keys = { ...(opts.keys ?? {}) };
    if (val === undefined) delete keys[sheet];
    else keys[sheet] = val;
    onOpts({ ...opts, keys });
  };
  const add = (c: string) => { const next = [...selected, c]; setKeys(next.length === 1 ? next[0] : next); };
  const remove = (c: string) => { const next = selected.filter((x) => x !== c); setKeys(next.length ? (next.length === 1 ? next[0] : next) : undefined); };

  return (
    <span className="flex flex-wrap items-center gap-1 text-xs font-normal text-[var(--app-muted)]">
      key:
      {isPosition || !shown.length ? (
        <span className="rounded bg-[var(--app-hover)] px-1.5 py-0.5">row position</span>
      ) : (
        shown.map((c) => (
          <span key={c} className="flex items-center gap-0.5 rounded bg-indigo-500/15 px-1.5 py-0.5 text-indigo-300">
            {c}
            {explicit && <button onClick={() => remove(c)} className="hover:text-rose-400"><X size={11} /></button>}
          </span>
        ))
      )}
      {!explicit && shown.length > 0 && <span className="text-[10px] opacity-60">(auto)</span>}
      {remaining.length > 0 && !isPosition && (
        <select value="" onChange={(e) => e.target.value && add(e.target.value)} className="rounded border border-[var(--app-border)] bg-[var(--app-bg)] px-1 py-0.5 text-xs text-[var(--app-text)]">
          <option value="">+ col</option>
          {remaining.map((c) => (<option key={c} value={c}>{c}</option>))}
        </select>
      )}
      <button onClick={() => setKeys(POSITION_KEY)} title="Match rows by position" className="underline decoration-dotted hover:text-[var(--app-text)]">position</button>
      {explicit && <button onClick={() => setKeys(undefined)} title="Automatic key detection" className="underline decoration-dotted hover:text-[var(--app-text)]">auto</button>}
    </span>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex cursor-pointer select-none items-center gap-1.5 text-[var(--app-muted)] hover:text-[var(--app-text)]">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-3.5 w-3.5 accent-indigo-500" />
      {label}
    </label>
  );
}
