"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import {
  Check,
  ChevronDown,
  CloudUpload,
  Download,
  FileText,
  History,
  LayoutTemplate,
  Loader2,
  MessageSquare,
  Play,
  Presentation,
  Share2,
  Sparkles,
} from "lucide-react";
import { useChatUI } from "@/components/editor/ChatPanel";
import { Button, Field, inputCls, Modal } from "@/components/ui";
import { listCustomTemplates, useCustomTemplates } from "@/lib/customTemplates";
import { TEMPLATE_CATEGORIES } from "@/lib/templates";
import type { TemplateCategory } from "@/lib/types";
import { exportDeckToPptx } from "@/lib/export-pptx";
import { exportDeckHD, PYEXPORT_URL } from "@/lib/export-hd";
import { deckFromAI } from "@/lib/deck";
import { cloudRestore, cloudSave, cloudShare, cloudVersions, type CloudVersion } from "@/lib/cloud";
import { useAuth } from "@/lib/auth";
import { clearHistory, useEditor } from "@/lib/store";
import { toast } from "@/lib/toast";
import type { AIDeck } from "@/lib/schema";

export function Topbar() {
  const router = useRouter();
  const deck = useEditor((s) => s.deck);
  const setDeck = useEditor((s) => s.setDeck);
  const setTitle = useEditor((s) => s.setTitle);
  const uid = useAuth((s) => s.currentId);
  const [menu, setMenu] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [histOpen, setHistOpen] = useState(false);
  const [versions, setVersions] = useState<CloudVersion[]>([]);
  const [tplOpen, setTplOpen] = useState(false);
  const [tplName, setTplName] = useState("");
  const [tplCat, setTplCat] = useState<TemplateCategory>("Business");
  const [tplTarget, setTplTarget] = useState(""); // "" = new; else an existing template id to overwrite
  const saveTemplate = useCustomTemplates((s) => s.saveFromDeck);
  const updateTemplate = useCustomTemplates((s) => s.updateFromDeck);
  const templatesMap = useCustomTemplates((s) => s.templates);

  if (!deck) return null;

  const myTemplates = listCustomTemplates(templatesMap);

  function doSaveTemplate() {
    if (tplTarget) {
      updateTemplate(tplTarget, deck!);
      toast.success(`Updated “${templatesMap[tplTarget]?.name ?? "template"}”`);
    } else {
      if (!tplName.trim()) return;
      saveTemplate(deck!, { name: tplName.trim(), category: tplCat });
      toast.success(`Saved “${tplName.trim()}” to your templates`);
    }
    setTplOpen(false);
    setTplName("");
    setTplTarget("");
  }

  async function saveToCloud(): Promise<boolean> {
    if (!uid) { toast.error("Sign in to save to the cloud."); return false; }
    setSaving(true);
    try {
      const r = await cloudSave(uid, deck!);
      if (!r.ok) throw new Error(r.error ?? "Cloud unavailable");
      toast.success("Saved to the cloud");
      return true;
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
      return false;
    } finally {
      setSaving(false);
    }
  }

  async function share() {
    if (!uid) { toast.error("Sign in to share."); return; }
    setSaving(true);
    try {
      await cloudSave(uid, deck!); // ensure persisted
      const token = await cloudShare(uid, deck!.id);
      const url = `${window.location.origin}/share/${token}`;
      await navigator.clipboard.writeText(url).catch(() => {});
      toast.success("Share link copied to clipboard");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Share failed");
    } finally {
      setSaving(false);
    }
  }

  async function openHistory() {
    if (!uid) { toast.error("Sign in to view history."); return; }
    setVersions(await cloudVersions(uid, deck!.id));
    setHistOpen(true);
  }

  async function restore(versionId: string) {
    if (!uid) return;
    const restored = await cloudRestore(uid, deck!.id, versionId);
    if (restored) {
      setDeck(restored);
      clearHistory();
      toast.success("Restored a previous version");
    } else {
      toast.error("Restore failed");
    }
    setHistOpen(false);
  }

  async function downloadPptx() {
    setExporting(true);
    try {
      await exportDeckToPptx(deck!);
      toast.success("PowerPoint downloaded.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Export failed");
    } finally {
      setExporting(false);
      setMenu(false);
    }
  }

  async function downloadHD() {
    setExporting(true);
    try {
      await exportDeckHD(deck!);
      toast.success("HD PowerPoint downloaded.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "HD export failed");
    } finally {
      setExporting(false);
      setMenu(false);
    }
  }

  async function downloadCode() {
    setMenu(false);
    if (!PYEXPORT_URL) return toast.error("Code export needs the export service.");
    try {
      const res = await fetch(`${PYEXPORT_URL.replace(/\/$/, "")}/export-code`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deck }),
      });
      if (!res.ok) throw new Error(`Code export failed (${res.status})`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const el = document.createElement("a");
      el.href = url;
      el.download = `${(deck!.title || "deck").replace(/[^\w\d-]+/g, "_").slice(0, 60)}.py`;
      el.click();
      URL.revokeObjectURL(url);
      toast.success("Python (python-pptx) script downloaded.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Code export failed");
    }
  }

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-[var(--app-border)] bg-[var(--app-panel)] px-4">
      <div className="flex items-center gap-3">
        <Link href="/" className="text-sm font-semibold text-zinc-400 hover:text-zinc-100">
          ← Assistant
        </Link>
        <div className="h-5 w-px bg-[var(--app-border)]" />
        <input
          value={deck.title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-56 rounded-md bg-transparent px-2 py-1 text-sm font-medium text-zinc-100 hover:bg-white/5 focus:bg-white/5 focus:outline-none"
        />
        <span className="flex items-center gap-1 text-xs text-zinc-500">
          <Check size={13} className="text-emerald-400" /> Saved
        </span>
      </div>

      <div className="flex items-center gap-2">
        <Button variant="subtle" size="sm" onClick={() => useChatUI.getState().toggle()}>
          <MessageSquare size={15} /> Assistant
        </Button>
        <Button variant="subtle" size="sm" onClick={() => setAiOpen(true)}>
          <Sparkles size={15} /> AI rewrite
        </Button>
        <Button variant="subtle" size="sm" onClick={saveToCloud} disabled={saving}>
          {saving ? <Loader2 size={15} className="animate-spin" /> : <CloudUpload size={15} />} Save
        </Button>
        <Button variant="subtle" size="sm" onClick={share} disabled={saving}>
          <Share2 size={15} /> Share
        </Button>
        <Button variant="subtle" size="sm" onClick={openHistory}>
          <History size={15} /> History
        </Button>
        <Button variant="outline" size="sm" onClick={() => router.push("/present")}>
          <Play size={15} /> Present
        </Button>
        <div className="relative">
          <Button size="sm" onClick={() => setMenu((m) => !m)}>
            <Download size={15} /> Export <ChevronDown size={14} />
          </Button>
          {menu && (
            <>
              <div className="fixed inset-0 z-20" onClick={() => setMenu(false)} />
              <div className="absolute right-0 z-30 mt-1 w-52 overflow-hidden rounded-lg border border-[var(--app-border)] bg-[var(--app-panel)] shadow-xl">
                <MenuItem onClick={downloadPptx} icon={exporting ? <Loader2 className="animate-spin" size={15} /> : <Presentation size={15} />}>
                  {exporting ? "Building .pptx…" : "Download PowerPoint (.pptx)"}
                </MenuItem>
                {PYEXPORT_URL && (
                  <MenuItem onClick={downloadHD} icon={<Sparkles size={15} />}>
                    Download HD .pptx (gradients)
                  </MenuItem>
                )}
                {PYEXPORT_URL && (
                  <MenuItem onClick={downloadCode} icon={<FileText size={15} />}>
                    Export as Python (python-pptx)
                  </MenuItem>
                )}
                <MenuItem
                  onClick={() => {
                    setMenu(false);
                    window.open("/print", "_blank");
                  }}
                  icon={<FileText size={15} />}
                >
                  Save as PDF (print)
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    setMenu(false);
                    router.push("/present");
                  }}
                  icon={<Play size={15} />}
                >
                  Present full screen
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    setMenu(false);
                    setTplName(deck.title || "");
                    setTplOpen(true);
                  }}
                  icon={<LayoutTemplate size={15} />}
                >
                  Save as template…
                </MenuItem>
              </div>
            </>
          )}
        </div>
      </div>

      <Modal open={histOpen} onClose={() => setHistOpen(false)}>
        <div className="p-5">
          <h2 className="mb-1 text-lg font-semibold">Version history</h2>
          <p className="mb-4 text-sm text-zinc-400">Each cloud save snapshots the prior version (latest 20 kept).</p>
          {versions.length === 0 ? (
            <p className="py-8 text-center text-sm text-zinc-500">No previous versions yet. Save to the cloud to start a history.</p>
          ) : (
            <div className="max-h-80 space-y-1 overflow-y-auto">
              {versions.map((v) => (
                <div key={v.id} className="flex items-center justify-between rounded-lg border border-[var(--app-border)] px-3 py-2">
                  <div className="min-w-0">
                    <div className="truncate text-sm text-zinc-200">{v.title}</div>
                    <div className="text-xs text-zinc-500">{new Date(v.createdAt).toLocaleString()}</div>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => restore(v.id)}>Restore</Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>

      <Modal open={tplOpen} onClose={() => setTplOpen(false)}>
        <div className="p-5">
          <h2 className="mb-1 text-lg font-semibold">Save as template</h2>
          <p className="mb-4 text-sm text-zinc-400">Reuse this deck’s design (theme, brand, layouts) to start new presentations. Great for imported, professionally-built decks.</p>
          {myTemplates.length > 0 && (
            <Field label="Save to">
              <select className={inputCls} value={tplTarget} onChange={(e) => setTplTarget(e.target.value)}>
                <option value="">New template</option>
                {myTemplates.map((t) => <option key={t.id} value={t.id}>Update “{t.name}”</option>)}
              </select>
            </Field>
          )}
          {!tplTarget && (
            <>
              <div className={myTemplates.length > 0 ? "mt-3" : ""}>
                <Field label="Template name">
                  <input className={inputCls} value={tplName} onChange={(e) => setTplName(e.target.value)} placeholder="e.g. OATI Corporate" autoFocus onKeyDown={(e) => e.key === "Enter" && doSaveTemplate()} />
                </Field>
              </div>
              <div className="mt-3">
                <Field label="Category">
                  <select className={inputCls} value={tplCat} onChange={(e) => setTplCat(e.target.value as TemplateCategory)}>
                    {TEMPLATE_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </Field>
              </div>
            </>
          )}
          {tplTarget && <p className="text-sm text-amber-300">This will overwrite “{templatesMap[tplTarget]?.name}” with the current deck’s design.</p>}
        </div>
        <div className="flex justify-end gap-2 border-t border-[var(--app-border)] p-4">
          <Button variant="ghost" onClick={() => setTplOpen(false)}>Cancel</Button>
          <Button onClick={doSaveTemplate} disabled={!tplTarget && !tplName.trim()}>
            <LayoutTemplate size={16} /> {tplTarget ? "Update template" : "Save template"}
          </Button>
        </div>
      </Modal>

      <AIRewriteDialog
        open={aiOpen}
        onClose={() => setAiOpen(false)}
        onDeck={(ai) => {
          const next = deckFromAI(ai, deck.templateId);
          // keep the user's current look & brand
          setDeck({ ...next, theme: deck.theme, brand: deck.brand, title: deck.title });
          clearHistory();
          setAiOpen(false);
        }}
      />
    </header>
  );
}

function MenuItem({
  children,
  icon,
  onClick,
}: {
  children: React.ReactNode;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-2.5 px-3 py-2.5 text-left text-sm text-zinc-200 hover:bg-white/5"
    >
      {icon}
      {children}
    </button>
  );
}

function AIRewriteDialog({
  open,
  onClose,
  onDeck,
}: {
  open: boolean;
  onClose: () => void;
  onDeck: (ai: AIDeck) => void;
}) {
  const [brief, setBrief] = useState("");
  const [slideCount, setSlideCount] = useState(8);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function go() {
    if (!brief.trim()) {
      setError("Describe the deck you want.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: brief, slideCount }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.hint ?? data.error ?? "Failed");
        return;
      }
      onDeck(data.deck as AIDeck);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Network error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={busy ? () => {} : onClose}>
      <div className="p-5">
        <h2 className="mb-1 text-lg font-semibold">Rewrite this deck with AI</h2>
        <p className="mb-4 text-sm text-zinc-400">
          Your theme and brand stay; the content is regenerated.
        </p>
        <Field label="Brief">
          <textarea
            className={inputCls}
            rows={3}
            value={brief}
            onChange={(e) => setBrief(e.target.value)}
            placeholder="Describe your presentation…"
          />
        </Field>
        <div className="mt-3">
          <Field label="Slides">
            <input
              type="number"
              min={3}
              max={20}
              className={inputCls}
              value={slideCount}
              onChange={(e) => setSlideCount(Number(e.target.value))}
            />
          </Field>
        </div>
        {error && <p className="mt-3 text-sm text-rose-300">{error}</p>}
      </div>
      <div className="flex justify-end gap-2 border-t border-[var(--app-border)] p-4">
        <Button variant="ghost" onClick={onClose} disabled={busy}>
          Cancel
        </Button>
        <Button onClick={go} disabled={busy}>
          {busy ? <Loader2 className="animate-spin" size={16} /> : <Sparkles size={16} />}
          {busy ? "Writing…" : "Generate"}
        </Button>
      </div>
    </Modal>
  );
}
