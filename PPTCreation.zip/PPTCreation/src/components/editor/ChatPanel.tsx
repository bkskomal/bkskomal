"use client";

import { useEffect, useRef, useState } from "react";
import { create } from "zustand";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Bot,
  Check,
  ChevronRight,
  Copy,
  MessageSquare,
  Paperclip,
  RefreshCw,
  Send,
  Sparkles,
  Square,
  Trash2,
  X,
} from "lucide-react";
import { applyChatActions, type ChatAttachment, type ChatAction } from "@/lib/chatActions";
import { useChatHistory, type ChatMsg } from "@/lib/chatHistory";
import { fileToDataUrl } from "@/lib/elements";
import { newId } from "@/lib/layouts";
import { useEditor } from "@/lib/store";
import { toast } from "@/lib/toast";
import type { Deck, TextElement } from "@/lib/types";

interface StepResult {
  reply?: string;
  actions?: ChatAction[];
  done?: boolean;
  error?: string;
  aborted?: boolean;
}

/** Shared open/close state so the Topbar button and the panel coordinate. */
export const useChatUI = create<{ open: boolean; toggle: () => void; set: (v: boolean) => void }>(
  (set) => ({
    open: false,
    toggle: () => set((s) => ({ open: !s.open })),
    set: (v) => set({ open: v }),
  }),
);

type Msg = ChatMsg;

const SUGGESTIONS = [
  "Create a 10-slide investor pitch for an AI meal-kit startup",
  "Add a timeline slide for our 2026 roadmap",
  "Turn slide 3 into a comparison",
  "Use the boardroom theme and set the footer to ‘Confidential’",
];

export function ChatPanel() {
  const open = useChatUI((s) => s.open);
  const close = () => useChatUI.getState().set(false);
  const deck = useEditor((s) => s.deck);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [copied, setCopied] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const histRef = useRef<string[]>([]); // previously sent prompts
  const histPos = useRef<number | null>(null); // null = not navigating
  const abortRef = useRef<AbortController | null>(null);

  /** Read one streaming step: streams reply text via onDelta, returns final result. */
  async function streamStep(
    apiConvo: { role: "user" | "assistant"; content: string }[],
    signal: AbortSignal,
    onDelta: (t: string) => void,
  ): Promise<StepResult> {
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiConvo, deckSummary: summarize(useEditor.getState().deck), stream: true }),
        signal,
      });
      if (!res.ok || !res.body) return { error: `Chat failed (${res.status})` };
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let final: StepResult | null = null;
      let error: StepResult | null = null;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n");
        buf = parts.pop() ?? "";
        for (const p of parts) {
          const line = p.trim();
          if (!line.startsWith("data:")) continue;
          const obj = JSON.parse(line.slice(5).trim());
          if (obj.type === "delta") onDelta(obj.text);
          else if (obj.type === "final") final = obj.result;
          else if (obj.type === "error") error = { error: obj.hint ?? obj.error };
        }
      }
      return error ?? final ?? { error: "No response" };
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return { aborted: true };
      return { error: e instanceof Error ? e.message : "Network error" };
    }
  }

  function stop() {
    abortRef.current?.abort();
  }

  const deckId = deck?.id;

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  // load this deck's saved conversation when the deck changes
  useEffect(() => {
    if (deckId) setMessages(useChatHistory.getState().get(deckId));
    else setMessages([]);
  }, [deckId]);

  // persist after each completed turn (not on every streaming token)
  useEffect(() => {
    if (deckId && !busy && messages.length) useChatHistory.getState().set(deckId, messages);
  }, [messages, busy, deckId]);

  async function copyMsg(text: string, i: number) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(i);
      setTimeout(() => setCopied((c) => (c === i ? null : c)), 1200);
    } catch {
      toast.error("Couldn't copy");
    }
  }

  function clearChat() {
    if (busy) return;
    setMessages([]);
    if (deckId) useChatHistory.getState().clear(deckId);
  }

  function regenerateLast() {
    if (busy) return;
    let idx = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === "user") {
        idx = i;
        break;
      }
    }
    if (idx < 0) return;
    const trimmed = messages.slice(0, idx + 1);
    setMessages(trimmed);
    runSteps(
      trimmed.map((m) => ({ role: m.role, content: m.content })),
      [],
    );
  }

  // auto-grow the textarea with content, up to a max height
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 180)}px`;
  }, [input]);

  async function addFiles(files: FileList | File[]) {
    const imgs = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (!imgs.length) return;
    const next = await Promise.all(
      imgs.map(async (f) => ({ id: newId(), name: f.name || "image", type: f.type, dataUrl: await fileToDataUrl(f) })),
    );
    setAttachments((a) => [...a, ...next]);
  }

  async function send(text: string) {
    const content = text.trim();
    const atts = attachments;
    if ((!content && atts.length === 0) || busy) return;

    if (content) {
      histRef.current = [...histRef.current.filter((h) => h !== content), content];
    }
    histPos.current = null;

    const shown = content || (atts.length ? "(attached image)" : "");
    setMessages((m) => [...m, { role: "user", content: shown, thumbs: atts.map((a) => a.dataUrl) }]);
    setInput("");
    setAttachments([]);
    setBusy(true);

    // note attachments to the model so it can decide to place_attachment
    const attachNote = atts.length
      ? `\n\n[User attached ${atts.length} image(s): ${atts.map((a, i) => `[${i}] ${a.name}`).join(", ")}. Use place_attachment to insert or set as logo if relevant.]`
      : "";

    // Conversation sent to the model (each step's reply IS shown to the user).
    const apiConvo: { role: "user" | "assistant"; content: string }[] = [
      ...messages.map((m) => ({ role: m.role, content: m.content })),
      { role: "user", content: content + attachNote },
    ];
    runSteps(apiConvo, atts);
  }

  /** Drive the multi-step streaming loop; shared by send() and regenerateLast(). */
  async function runSteps(
    convoIn: { role: "user" | "assistant"; content: string }[],
    atts: ChatAttachment[],
  ) {
    let apiConvo = convoIn;
    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;
    const MAX_STEPS = 5;
    try {
      for (let step = 0; step < MAX_STEPS; step++) {
        // add a streaming placeholder bubble that fills in as text arrives
        setMessages((m) => [...m, { role: "assistant", content: "", streaming: true }]);
        const onDelta = (t: string) =>
          setMessages((m) => {
            const copy = [...m];
            const last = copy[copy.length - 1];
            if (last?.role === "assistant") copy[copy.length - 1] = { ...last, content: last.content + t };
            return copy;
          });

        const result = await streamStep(apiConvo, controller.signal, onDelta);

        if (result.aborted) {
          setMessages((m) => {
            const copy = [...m];
            const last = copy[copy.length - 1];
            if (last?.role === "assistant")
              copy[copy.length - 1] = { ...last, streaming: false, content: last.content || "⏹ Stopped." };
            return copy;
          });
          return;
        }
        if (result.error) {
          toast.error(result.error);
          setMessages((m) => {
            const copy = [...m];
            copy[copy.length - 1] = { role: "assistant", content: result.error ?? "Something went wrong." };
            return copy;
          });
          return;
        }

        const summaries = result.actions?.length ? await applyChatActions(result.actions, atts) : [];
        setMessages((m) => {
          const copy = [...m];
          copy[copy.length - 1] = { role: "assistant", content: result.reply ?? "Done.", actions: summaries };
          return copy;
        });
        apiConvo = [...apiConvo, { role: "assistant", content: result.reply ?? "" }];

        if (result.done || !result.actions?.length) break;
        apiConvo = [...apiConvo, { role: "user", content: "Continue with the remaining work. Set done:true when finished." }];
        await new Promise((r) => setTimeout(r, 300));
      }
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  }

  // Collapsed: a slim always-docked rail you can expand.
  if (!open) {
    return (
      <aside className="flex w-11 shrink-0 flex-col items-center border-l border-[var(--app-border)] bg-[var(--app-panel)] py-3">
        <button
          onClick={() => useChatUI.getState().set(true)}
          title="Open AI Assistant"
          className="flex flex-col items-center gap-2 rounded-lg p-2 text-indigo-400 hover:bg-white/5"
        >
          <MessageSquare size={20} />
          <span className="text-[10px] font-semibold uppercase tracking-wide [writing-mode:vertical-rl]">
            Assistant
          </span>
        </button>
      </aside>
    );
  }

  return (
    <aside className="flex w-[380px] shrink-0 flex-col border-l border-[var(--app-border)] bg-[var(--app-panel)]">
      <div className="flex h-12 items-center justify-between border-b border-[var(--app-border)] px-4">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Sparkles size={16} className="text-indigo-400" /> AI Assistant
        </div>
        <div className="flex items-center gap-1">
          {messages.length > 0 && (
            <button
              onClick={clearChat}
              title="Clear conversation"
              className="rounded-md p-1 text-zinc-500 hover:bg-white/5 hover:text-zinc-200"
            >
              <Trash2 size={16} />
            </button>
          )}
          <button
            onClick={close}
            title="Minimize"
            className="rounded-md p-1 text-zinc-500 hover:bg-white/5 hover:text-zinc-200"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto p-4">
        {messages.length === 0 && (
          <div className="space-y-3">
            <div className="flex items-start gap-2 text-sm text-zinc-400">
              <Bot size={18} className="mt-0.5 shrink-0 text-indigo-400" />
              <p>Tell me what you want to present and I&apos;ll build it — then ask me to tweak any slide, theme, or branding.</p>
            </div>
            <div className="space-y-1.5">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="block w-full rounded-lg border border-[var(--app-border)] px-3 py-2 text-left text-xs text-zinc-300 hover:border-indigo-400/60 hover:bg-white/5"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={`group ${m.role === "user" ? "flex flex-col items-end" : ""}`}>
            <div
              className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm ${
                m.role === "user"
                  ? "bg-indigo-500 text-white"
                  : "bg-white/5 text-zinc-100"
              }`}
            >
              {m.thumbs && m.thumbs.length > 0 && (
                <div className="mb-1.5 flex flex-wrap gap-1.5">
                  {m.thumbs.map((t, j) => (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img key={j} src={t} alt="attachment" className="h-14 w-14 rounded-lg object-cover ring-1 ring-white/20" />
                  ))}
                </div>
              )}
              {m.role === "assistant" ? (
                m.content ? (
                  <div className="chat-md">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                    {m.streaming && <span className="ml-0.5 inline-block h-3.5 w-1.5 animate-pulse bg-indigo-400 align-middle" />}
                  </div>
                ) : (
                  <span className="inline-flex gap-1 py-1">
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500 [animation-delay:-0.2s]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500 [animation-delay:-0.1s]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500" />
                  </span>
                )
              ) : (
                <p className="whitespace-pre-wrap">{m.content}</p>
              )}
              {m.actions && m.actions.length > 0 && (
                <ul className="mt-2 space-y-1 border-t border-white/10 pt-2 text-xs text-emerald-300">
                  {m.actions.map((a, j) => (
                    <li key={j}>✓ {a}</li>
                  ))}
                </ul>
              )}
            </div>

            {m.role === "assistant" && !m.streaming && m.content && (
              <div className="mt-1 flex gap-1 opacity-0 transition group-hover:opacity-100">
                <button
                  onClick={() => copyMsg(m.content, i)}
                  title="Copy"
                  className="rounded-md p-1 text-zinc-500 hover:bg-white/5 hover:text-zinc-200"
                >
                  {copied === i ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                </button>
                {i === messages.length - 1 && (
                  <button
                    onClick={regenerateLast}
                    disabled={busy}
                    title="Regenerate"
                    className="rounded-md p-1 text-zinc-500 hover:bg-white/5 hover:text-zinc-200 disabled:opacity-40"
                  >
                    <RefreshCw size={14} />
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="border-t border-[var(--app-border)] p-3">
        <div
          className={`rounded-xl border bg-[#0e1016] p-2 transition ${
            dragOver ? "border-indigo-400 ring-2 ring-indigo-400/40" : "border-[var(--app-border)]"
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
          }}
        >
          {attachments.length > 0 && (
            <div className="mb-2 flex flex-wrap gap-2">
              {attachments.map((a) => (
                <div key={a.id} className="group relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={a.dataUrl} alt={a.name} className="h-12 w-12 rounded-lg object-cover ring-1 ring-white/15" />
                  <button
                    onClick={() => setAttachments((list) => list.filter((x) => x.id !== a.id))}
                    className="absolute -right-1.5 -top-1.5 rounded-full bg-black/80 p-0.5 text-zinc-300 opacity-0 transition group-hover:opacity-100 hover:text-white"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-end gap-2">
            <button
              onClick={() => fileRef.current?.click()}
              title="Attach image"
              className="mb-0.5 rounded-lg p-1.5 text-zinc-400 hover:bg-white/10 hover:text-zinc-100"
            >
              <Paperclip size={17} />
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files) addFiles(e.target.files);
                e.target.value = "";
              }}
            />
            <textarea
              ref={taRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onPaste={(e) => {
                const imgs = Array.from(e.clipboardData.files).filter((f) => f.type.startsWith("image/"));
                if (imgs.length) {
                  e.preventDefault();
                  addFiles(imgs);
                }
              }}
              onKeyDown={(e) => {
                const ta = e.currentTarget;
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                  return;
                }
                // ↑/↓ recall previous prompts (like a terminal), when at the edges
                if (e.key === "ArrowUp" && ta.selectionStart === 0) {
                  const h = histRef.current;
                  if (!h.length) return;
                  e.preventDefault();
                  histPos.current = histPos.current === null ? h.length - 1 : Math.max(0, histPos.current - 1);
                  setInput(h[histPos.current]);
                } else if (e.key === "ArrowDown" && ta.selectionStart === ta.value.length) {
                  const h = histRef.current;
                  if (histPos.current === null) return;
                  e.preventDefault();
                  if (histPos.current >= h.length - 1) {
                    histPos.current = null;
                    setInput("");
                  } else {
                    histPos.current += 1;
                    setInput(h[histPos.current]);
                  }
                }
              }}
              rows={1}
              placeholder={deck ? "Ask me to change anything…  (↑ for history, paste or drop an image)" : "Describe the deck you want…"}
              className="flex-1 resize-none bg-transparent py-1.5 text-sm text-zinc-100 outline-none placeholder:text-zinc-600"
            />
            {busy ? (
              <button
                onClick={stop}
                title="Stop"
                className="rounded-lg bg-rose-500 p-2 text-white hover:bg-rose-400"
              >
                <Square size={16} fill="currentColor" />
              </button>
            ) : (
              <button
                onClick={() => send(input)}
                disabled={!input.trim() && attachments.length === 0}
                className="rounded-lg bg-indigo-500 p-2 text-white hover:bg-indigo-400 disabled:opacity-40"
              >
                <Send size={16} />
              </button>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}

function summarize(deck: Deck | null): string {
  if (!deck) return "No deck open yet. Use set_deck to create one.";
  const { currentSlideId, selectedElementId } = useEditor.getState();
  const currentIndex = deck.slides.findIndex((s) => s.id === currentSlideId);

  const slides = deck.slides
    .map((s, i) => {
      const t = s.elements.find((e) => e.type === "text" && (e.role === "title" || e.role === "heading"));
      const title = t && "text" in t ? (t as TextElement).text : "(untitled)";
      const here = i === currentIndex ? "  <- CURRENT" : "";
      return `${i}. [${s.layout}] ${title}${here}`;
    })
    .join("\n");

  let sel = "Selected element: none";
  if (selectedElementId && currentIndex >= 0) {
    const el = deck.slides[currentIndex].elements.find((e) => e.id === selectedElementId);
    if (el) {
      const txt = el.type === "text" && "text" in el ? ` "${(el as TextElement).text.slice(0, 40)}"` : "";
      sel = `Selected element: a ${el.type}${txt} on the current slide`;
    }
  }

  return `Title: ${deck.title}\nTheme: ${deck.theme.id}\nViewing slide: ${currentIndex}\n${sel}\nSlides (0-based):\n${slides}`;
}
