"use client";

import { useEffect } from "react";
import { redo, undo, useEditor } from "@/lib/store";

/** Editor keyboard shortcuts. Ignores events while typing in inputs. */
export function useShortcuts() {
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const t = e.target as HTMLElement | null;
      const typing =
        t &&
        (t.tagName === "INPUT" ||
          t.tagName === "TEXTAREA" ||
          t.isContentEditable ||
          t.tagName === "SELECT");

      const mod = e.ctrlKey || e.metaKey;

      // Undo / redo work even while typing (standard editor behavior).
      if (mod && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
        return;
      }
      if (mod && e.key.toLowerCase() === "y") {
        e.preventDefault();
        redo();
        return;
      }

      if (typing) return;

      const { deck, currentSlideId, selectedElementId } = useEditor.getState();
      if (!deck || !currentSlideId) return;

      if (mod && e.key.toLowerCase() === "d" && selectedElementId) {
        e.preventDefault();
        useEditor.getState().duplicateElement(currentSlideId, selectedElementId);
        return;
      }

      if ((e.key === "Delete" || e.key === "Backspace") && selectedElementId) {
        e.preventDefault();
        useEditor.getState().deleteElement(currentSlideId, selectedElementId);
        return;
      }

      // Arrow-key nudge (Shift = 10px steps)
      if (selectedElementId && e.key.startsWith("Arrow")) {
        const slide = deck.slides.find((s) => s.id === currentSlideId);
        const el = slide?.elements.find((x) => x.id === selectedElementId);
        if (!el) return;
        e.preventDefault();
        const step = e.shiftKey ? 10 : 1;
        const dx = e.key === "ArrowLeft" ? -step : e.key === "ArrowRight" ? step : 0;
        const dy = e.key === "ArrowUp" ? -step : e.key === "ArrowDown" ? step : 0;
        useEditor.getState().updateElement(currentSlideId, selectedElementId, {
          x: el.x + dx,
          y: el.y + dy,
        });
      }
    }

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
}
