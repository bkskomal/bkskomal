"use client";

import { useState } from "react";
import { AreaChart, BarChart3, BarChartHorizontal, LineChart, PieChart } from "lucide-react";
import { useEditor } from "@/lib/store";
import { makeChart, parseTable } from "@/lib/elements";
import { toast } from "@/lib/toast";
import type { ChartKind } from "@/lib/types";

const TYPES: { id: ChartKind; label: string; icon: React.ReactNode }[] = [
  { id: "column", label: "Column", icon: <BarChart3 size={16} /> },
  { id: "bar", label: "Bar", icon: <BarChartHorizontal size={16} /> },
  { id: "line", label: "Line", icon: <LineChart size={16} /> },
  { id: "area", label: "Area", icon: <AreaChart size={16} /> },
  { id: "pie", label: "Pie", icon: <PieChart size={16} /> },
  { id: "donut", label: "Donut", icon: <PieChart size={16} /> },
];

const SAMPLE = "Quarter,Revenue,Costs\nQ1,42,30\nQ2,58,34\nQ3,51,38\nQ4,73,40";

/** Insert a data chart: pick a type, paste CSV/TSV data (optional), insert. */
export function ChartMenu() {
  const currentSlideId = useEditor((s) => s.currentSlideId);
  const addElement = useEditor((s) => s.addElement);
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<ChartKind>("column");
  const [data, setData] = useState(SAMPLE);

  function insert() {
    if (!currentSlideId) return;
    const chart = makeChart(type);
    const parsed = parseTable(data);
    if (parsed) {
      chart.categories = parsed.categories;
      chart.series = parsed.series;
      chart.legend = parsed.series.length > 1;
    }
    addElement(currentSlideId, chart);
    setOpen(false);
    toast.success("Chart added");
  }

  return (
    <div className="relative">
      <button
        title="Add chart"
        aria-label="Add chart"
        onClick={() => setOpen((o) => !o)}
        className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-300 transition hover:bg-white/10 hover:text-white"
      >
        <BarChart3 size={17} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-20" onClick={() => setOpen(false)} />
          <div className="absolute left-0 z-30 mt-1 w-80 rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] p-3 shadow-2xl">
            <div className="mb-2 grid grid-cols-3 gap-1.5">
              {TYPES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setType(t.id)}
                  className={`flex items-center justify-center gap-1.5 rounded-lg border px-2 py-1.5 text-xs ${type === t.id ? "border-indigo-400 bg-indigo-500/10 text-white" : "border-[var(--app-border)] text-zinc-400 hover:bg-white/5"}`}
                >
                  {t.icon} {t.label}
                </button>
              ))}
            </div>
            <label className="mb-1 block text-[11px] font-medium text-zinc-400">Data (CSV / TSV — header row, first column = labels)</label>
            <textarea
              value={data}
              onChange={(e) => setData(e.target.value)}
              spellCheck={false}
              rows={6}
              className="w-full resize-y rounded-lg border border-[var(--app-border)] bg-[var(--app-bg)] p-2 font-mono text-xs text-[var(--app-text)] outline-none focus:border-indigo-400"
            />
            <button onClick={insert} className="mt-2 w-full rounded-lg bg-indigo-500 py-1.5 text-sm font-medium text-white hover:bg-indigo-400">
              Insert chart
            </button>
          </div>
        </>
      )}
    </div>
  );
}
