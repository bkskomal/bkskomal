"use client";

import { useEffect, useRef, useState } from "react";
import {
  Building2,
  Image as ImageIcon,
  Loader2,
  Lock,
  Palette,
  Scissors,
  SlidersHorizontal,
  Sparkles,
  Type,
  Upload,
  Wand2,
} from "lucide-react";
import { useOrg } from "@/lib/org";
import { useAuth } from "@/lib/auth";
import { Button, Field, inputCls } from "@/components/ui";
import { THEME_LIST } from "@/lib/themes";
import { LAYOUTS, rebuildSlide } from "@/lib/layouts";
import { resolveColor } from "@/lib/color";
import { useEditor } from "@/lib/store";
import { useBrandKits } from "@/lib/brandkits";
import { HEADER_PRESETS, FOOTER_PRESETS } from "@/lib/resources";
import { toast } from "@/lib/toast";
import type { BrandKit, FooterPreset, HeaderPreset, LogoPlacement, Slide, TextElement } from "@/lib/types";

const FONTS = ["Inter", "Poppins", "Sora", "Playfair Display", "Calibri", "Georgia", "Arial"];
const BLOCK_VARIANTS: Record<string, string[]> = {
  statGrid: ["cards", "minimal", "circles"],
  bullets: ["dots", "checks", "cards"],
  process: ["horizontal", "vertical"],
};
const PLACEMENTS: LogoPlacement[] = ["top-left", "top-right", "bottom-left", "bottom-right"];

type Tab = "slide" | "design" | "brand" | "element";

export function Inspector() {
  const deck = useEditor((s) => s.deck);
  const selectedId = useEditor((s) => s.selectedElementId);
  const [tab, setTab] = useState<Tab>("slide");

  if (!deck) return null;
  const activeTab: Tab = selectedId ? "element" : tab === "element" ? "slide" : tab;

  return (
    <aside className="flex w-72 shrink-0 flex-col border-l border-[var(--app-border)] bg-[var(--app-panel)]">
      <div className="flex border-b border-[var(--app-border)]">
        <TabButton active={activeTab === "slide"} onClick={() => setTab("slide")} icon={<Sparkles size={15} />}>
          Slide
        </TabButton>
        <TabButton active={activeTab === "design"} onClick={() => setTab("design")} icon={<Palette size={15} />}>
          Design
        </TabButton>
        <TabButton active={activeTab === "brand"} onClick={() => setTab("brand")} icon={<ImageIcon size={15} />}>
          Brand
        </TabButton>
        <TabButton active={activeTab === "element"} onClick={() => setTab("element")} icon={<SlidersHorizontal size={15} />}>
          Element
        </TabButton>
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === "slide" && <SlidePanel />}
        {activeTab === "design" && <DesignPanel />}
        {activeTab === "brand" && <BrandPanel />}
        {activeTab === "element" && <ElementPanel />}
      </div>
    </aside>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-1 items-center justify-center gap-1.5 py-2.5 text-xs font-medium transition ${
        active ? "border-b-2 border-indigo-500 text-zinc-100" : "text-zinc-500 hover:text-zinc-300"
      }`}
    >
      {icon}
      {children}
    </button>
  );
}

// ---------- Slide (AI + layout) ----------
function SlidePanel() {
  const deck = useEditor((s) => s.deck)!;
  const currentSlideId = useEditor((s) => s.currentSlideId)!;
  const setSlide = useEditor((s) => s.setSlide);
  const setSlideNotes = useEditor((s) => s.setSlideNotes);
  const [busy, setBusy] = useState<string | null>(null);
  const [instruction, setInstruction] = useState("");

  const slide = deck.slides.find((s) => s.id === currentSlideId);
  if (!slide) return null;

  function changeLayout(layoutId: string) {
    if (!slide!.source) {
      toast.error("This slide has no AI source to re-layout. Try Regenerate.");
      return;
    }
    setSlide(slide!.id, rebuildSlide({ ...slide!.source, layout: layoutId }, slide!.id, slide!.notes, deck.style));
  }

  async function regenerate(layout?: string) {
    setBusy(layout ? `layout:${layout}` : "regen");
    try {
      const res = await fetch("/api/regenerate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          current: slide!.source ?? { layout: slide!.layout, title: deck.title },
          deckTitle: deck.title,
          layout,
          instruction: instruction || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.hint ?? data.error ?? "Regenerate failed");
        return;
      }
      setSlide(slide!.id, rebuildSlide(data.slide, slide!.id, slide!.notes, deck.style));
      toast.success("Slide regenerated");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Network error");
    } finally {
      setBusy(null);
    }
  }

  async function generateNotes() {
    setBusy("notes");
    try {
      const title = slide!.elements.find((e) => e.type === "text" && (e.role === "title" || e.role === "heading"));
      const ctx = title && "text" in title ? (title as TextElement).text : deck.title;
      const res = await fetch("/api/assist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task: "notes", text: JSON.stringify(slide!.source ?? {}), context: ctx }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.hint ?? data.error ?? "Failed");
        return;
      }
      setSlideNotes(slide!.id, data.result.text ?? "");
      toast.success("Speaker notes generated");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Network error");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-5">
      <div className="rounded-lg border border-indigo-500/30 bg-indigo-500/5 p-3">
        <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-indigo-300">
          <Sparkles size={13} /> AI
        </div>
        <textarea
          className={inputCls}
          rows={2}
          placeholder="Optional: how to change this slide…"
          value={instruction}
          onChange={(e) => setInstruction(e.target.value)}
        />
        <Button size="sm" className="mt-2 w-full" onClick={() => regenerate()} disabled={busy !== null}>
          {busy === "regen" ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14} />}
          Regenerate this slide
        </Button>
      </div>

      <div>
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">Layout</h3>
        <div className="grid grid-cols-2 gap-1.5">
          {LAYOUTS.map((l) => (
            <button
              key={l.id}
              onClick={() => changeLayout(l.id)}
              className={`rounded-md px-2 py-1.5 text-left text-xs transition ${
                slide.layout === l.id
                  ? "bg-indigo-500 text-white"
                  : "bg-white/5 text-zinc-300 hover:bg-white/10"
              }`}
            >
              {l.name}
            </button>
          ))}
        </div>
        <p className="mt-1.5 text-[11px] text-zinc-500">Switches layout using this slide&apos;s content.</p>
      </div>

      {BLOCK_VARIANTS[slide.layout] && (
        <div>
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">Style</h3>
          <div className="flex flex-wrap gap-1.5">
            {BLOCK_VARIANTS[slide.layout].map((v) => {
              const active = (slide.source?.variant ?? BLOCK_VARIANTS[slide.layout][0]) === v;
              return (
                <button
                  key={v}
                  onClick={() => {
                    if (!slide.source) return;
                    setSlide(slide.id, rebuildSlide({ ...slide.source, variant: v }, slide.id, slide.notes, deck.style));
                  }}
                  className={`rounded-md px-3 py-1.5 text-xs capitalize transition ${
                    active ? "bg-indigo-500 text-white" : "bg-white/5 text-zinc-300 hover:bg-white/10"
                  }`}
                >
                  {v}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {deck.brand.logoUrl && (
        <div>
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
            Logo size (this slide) — {(slide.logoScale ?? deck.brand.logoScale ?? 1).toFixed(1)}×
          </h3>
          <input
            type="range"
            min={0.5}
            max={2.5}
            step={0.1}
            value={slide.logoScale ?? deck.brand.logoScale ?? 1}
            onChange={(e) => setSlide(slide.id, { ...slide, logoScale: Number(e.target.value) })}
            className="w-full accent-indigo-500"
          />
        </div>
      )}

      <div>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Speaker notes</h3>
          <button
            onClick={generateNotes}
            disabled={busy !== null}
            className="flex items-center gap-1 text-xs text-indigo-300 hover:text-indigo-200 disabled:opacity-40"
          >
            {busy === "notes" ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
            Generate
          </button>
        </div>
        <textarea
          className={inputCls}
          rows={5}
          placeholder="Notes the presenter will see…"
          value={slide.notes ?? ""}
          onChange={(e) => setSlideNotes(slide.id, e.target.value)}
        />
      </div>
    </div>
  );
}

// ---------- Design (theme) ----------
function DesignPanel() {
  const deck = useEditor((s) => s.deck)!;
  const setDeck = useEditor((s) => s.setDeck);

  return (
    <div className="space-y-4">
      <div>
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">Theme</h3>
        <div className="grid grid-cols-2 gap-2">
          {THEME_LIST.map((t) => {
            const active = t.id === deck.theme.id;
            return (
              <button
                key={t.id}
                onClick={() => setDeck({ ...deck, theme: t })}
                className={`rounded-lg border p-2 text-left transition ${
                  active ? "border-indigo-500" : "border-[var(--app-border)] hover:border-white/20"
                }`}
              >
                <div className="mb-1.5 flex gap-1">
                  {[t.colors.primary, t.colors.accent, t.colors.secondary].map((c) => (
                    <span key={c} className="h-4 w-4 rounded-full" style={{ background: c }} />
                  ))}
                </div>
                <span className="text-xs text-zinc-300">{t.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---------- Brand Kit ----------
/** Wraps a control that the org has locked — disables it with a badge. */
function Locked({ on, children }: { on: boolean; children: React.ReactNode }) {
  if (!on) return <>{children}</>;
  return (
    <div className="relative">
      <div className="pointer-events-none select-none opacity-50">{children}</div>
      <span className="absolute right-1 top-1 flex items-center gap-1 rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] text-amber-300"><Lock size={10} /> Org-locked</span>
    </div>
  );
}

function BrandPanel() {
  const deck = useEditor((s) => s.deck)!;
  const brand = deck.brand;
  const updateBrand = useEditor((s) => s.updateBrand);
  const locks = useOrg((s) => s.org.locks);
  const loadOrg = useOrg((s) => s.load);
  const orgLoaded = useOrg((s) => s.loaded);
  useEffect(() => { if (!orgLoaded) loadOrg(); }, [orgLoaded, loadOrg]);
  const fileRef = useRef<HTMLInputElement>(null);
  const setDeck = useEditor((s) => s.setDeck);
  const savedKits = useBrandKits((s) => s.kits);
  const saveKit = useBrandKits((s) => s.save);
  const removeKit = useBrandKits((s) => s.remove);
  const [kitName, setKitName] = useState("");
  const [brandMode, setBrandMode] = useState<"light" | "dark">("light");
  const [extracting, setExtracting] = useState(false);

  const isAdmin = useAuth((s) => s.isSuperAdmin());

  async function saveOrgPreset() {
    const name = window.prompt("Name this org brand preset (everyone can apply it by name):");
    if (!name?.trim()) return;
    try {
      const cur = await fetch("/api/org?admin=1").then((r) => r.json()).then((j) => j.org);
      const preset = {
        id: Math.random().toString(36).slice(2, 10),
        name: name.trim(),
        themeId: deck.theme.id,
        brand: {
          primaryColor: brand.primaryColor, accentColor: brand.accentColor,
          fontHeading: brand.fontHeading, fontBody: brand.fontBody,
          logoUrl: brand.logoUrl, footerText: brand.footerText,
          headerText: brand.headerText, headerSubtext: brand.headerSubtext,
          headerPreset: brand.headerPreset, footerPreset: brand.footerPreset,
          showHeader: brand.showHeader, showFooter: brand.showFooter, showPageNumbers: brand.showPageNumbers, logoScale: brand.logoScale,
        },
      };
      cur.brandPresets = [...(cur.brandPresets ?? []), preset];
      const r = await fetch("/api/org", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ isSuperAdmin: true, config: cur }) }).then((x) => x.json());
      if (r.error) return toast.error(r.error);
      useOrg.getState().load();
      toast.success(`Saved “${name.trim()}” — apply it anytime via chat: “use the ${name.trim()} brand”`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't save preset");
    }
  }

  async function autoBrand() {
    if (!brand.logoUrl) return;
    setExtracting(true);
    try {
      const { extractPalette, themeFromPalette } = await import("@/lib/palette");
      const palette = await extractPalette(brand.logoUrl);
      setDeck({ ...deck, theme: themeFromPalette(palette, brandMode) });
      updateBrand({ primaryColor: undefined, accentColor: undefined });
      toast.success("Brand theme generated from your logo");
    } catch {
      toast.error("Couldn't read colors from that logo");
    } finally {
      setExtracting(false);
    }
  }

  function onLogo(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => updateBrand({ logoUrl: String(reader.result) });
    reader.readAsDataURL(file);
  }

  return (
    <div className="space-y-4">
      <Field label="Logo">
        <div className="flex items-center gap-2">
          {brand.logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={brand.logoUrl} alt="logo" className="h-10 w-10 rounded bg-white/5 object-contain p-1" />
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded bg-white/5 text-zinc-600">
              <ImageIcon size={16} />
            </div>
          )}
          <Button variant="subtle" size="sm" onClick={() => fileRef.current?.click()}>
            <Upload size={14} /> Upload
          </Button>
          {brand.logoUrl && (
            <Button variant="ghost" size="sm" onClick={() => updateBrand({ logoUrl: undefined })}>
              Remove
            </Button>
          )}
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onLogo} />
        </div>
      </Field>

      {brand.logoUrl && (
        <div className="space-y-2 rounded-lg border border-indigo-500/30 bg-indigo-500/5 p-3">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-xs font-semibold text-indigo-300">
              <Sparkles size={13} /> Auto-brand
            </span>
            <div className="flex gap-0.5 rounded-md bg-[#0e1016] p-0.5">
              {(["light", "dark"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setBrandMode(m)}
                  className={`rounded px-2 py-0.5 text-xs capitalize ${
                    brandMode === m ? "bg-indigo-500 text-white" : "text-zinc-400"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>
          <Button size="sm" className="w-full" onClick={autoBrand} disabled={extracting}>
            {extracting ? <Loader2 size={14} className="animate-spin" /> : <Palette size={14} />}
            Match theme to logo
          </Button>
          <p className="text-[11px] text-zinc-500">Extracts your logo&apos;s colors into a matching {brandMode} theme.</p>
        </div>
      )}

      {brand.logoUrl && (
        <>
          <Field label="Logo position">
            <select
              className={inputCls}
              value={brand.logoPlacement}
              onChange={(e) => updateBrand({ logoPlacement: e.target.value as LogoPlacement })}
            >
              {PLACEMENTS.map((p) => (
                <option key={p} value={p}>
                  {p.replace("-", " ")}
                </option>
              ))}
            </select>
          </Field>
          <Field label={`Logo size (${brand.logoScale.toFixed(1)}x)`}>
            <input
              type="range"
              min={0.5}
              max={2}
              step={0.1}
              value={brand.logoScale}
              onChange={(e) => updateBrand({ logoScale: Number(e.target.value) })}
              className="w-full accent-indigo-500"
            />
          </Field>
        </>
      )}

      <Field label="Header text">
        <input
          className={inputCls}
          value={brand.headerText ?? ""}
          placeholder="Optional header / PPT name"
          onChange={(e) => updateBrand({ headerText: e.target.value || undefined })}
        />
      </Field>
      <Field label="Header subtitle (banner)">
        <input
          className={inputCls}
          value={brand.headerSubtext ?? ""}
          placeholder="e.g. What makes up the platform"
          onChange={(e) => updateBrand({ headerSubtext: e.target.value || undefined })}
        />
      </Field>
      <Locked on={locks.footer}>
        <Field label="Footer text">
          <input
            className={inputCls}
            value={brand.footerText ?? ""}
            placeholder="e.g. Confidential — 2026"
            onChange={(e) => updateBrand({ footerText: e.target.value || undefined })}
          />
        </Field>
      </Locked>

      <label className="flex items-center justify-between text-sm text-zinc-300">
        Page numbers
        <input
          type="checkbox"
          checked={brand.showPageNumbers}
          onChange={(e) => updateBrand({ showPageNumbers: e.target.checked })}
          className="h-4 w-4 accent-indigo-500"
        />
      </label>

      {/* Header / footer chrome — prebuilt premium presets */}
      <div className="space-y-3 rounded-lg border border-[var(--app-border)] p-3">
        <PresetSection
          title="Header"
          on={brand.showHeader}
          onToggle={(v) => updateBrand({ showHeader: v })}
          current={resolveHeaderPreset(brand)}
          presets={HEADER_PRESETS}
          onPick={(id) => updateBrand({ showHeader: true, headerPreset: id })}
          renderPreview={(id) => <HeaderThumb preset={id} />}
        />
        <PresetSection
          title="Footer"
          on={brand.showFooter}
          onToggle={(v) => updateBrand({ showFooter: v })}
          current={resolveFooterPreset(brand)}
          presets={FOOTER_PRESETS}
          onPick={(id) => updateBrand({ showFooter: true, footerPreset: id })}
          renderPreview={(id) => <FooterThumb preset={id} />}
        />
        <p className="text-[11px] text-zinc-500">Header &amp; footer show on content slides — cover, section &amp; closing stay clean.</p>
      </div>

      <Locked on={locks.colors}>
        <div className="grid grid-cols-2 gap-3">
          <ColorField
            label="Primary"
            value={brand.primaryColor ?? deck.theme.colors.primary}
            onChange={(v) => updateBrand({ primaryColor: v })}
            onReset={brand.primaryColor ? () => updateBrand({ primaryColor: undefined }) : undefined}
          />
          <ColorField
            label="Accent"
            value={brand.accentColor ?? deck.theme.colors.accent}
            onChange={(v) => updateBrand({ accentColor: v })}
            onReset={brand.accentColor ? () => updateBrand({ accentColor: undefined }) : undefined}
          />
        </div>
      </Locked>

      <Locked on={locks.fonts}>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Heading font">
            <select
              className={inputCls}
              value={brand.fontHeading ?? deck.theme.fonts.heading}
              onChange={(e) => updateBrand({ fontHeading: e.target.value })}
            >
              {FONTS.map((f) => (
                <option key={f}>{f}</option>
              ))}
            </select>
          </Field>
          <Field label="Body font">
            <select
              className={inputCls}
              value={brand.fontBody ?? deck.theme.fonts.body}
              onChange={(e) => updateBrand({ fontBody: e.target.value })}
            >
              {FONTS.map((f) => (
                <option key={f}>{f}</option>
              ))}
            </select>
          </Field>
        </div>
      </Locked>

      {isAdmin && (
        <div className="border-t border-[var(--app-border)] pt-4">
          <Button size="sm" variant="subtle" className="w-full" onClick={saveOrgPreset}>
            <Building2 size={14} /> Save as org brand preset
          </Button>
          <p className="mt-1 text-[11px] text-zinc-500">Shares this look org-wide; anyone can apply it by name via chat.</p>
        </div>
      )}

      {/* Saved brand kits */}
      <div className="border-t border-[var(--app-border)] pt-4">
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">Saved brand kits</h3>
        <div className="flex gap-2">
          <input
            className={inputCls}
            placeholder="Name this kit"
            value={kitName}
            onChange={(e) => setKitName(e.target.value)}
          />
          <Button
            size="sm"
            variant="subtle"
            onClick={() => {
              saveKit(kitName || "Brand kit", brand);
              setKitName("");
              toast.success("Brand kit saved");
            }}
          >
            Save
          </Button>
        </div>
        {savedKits.length > 0 && (
          <div className="mt-3 space-y-1.5">
            {savedKits.map((k) => (
              <div key={k.id} className="flex items-center justify-between rounded-md bg-white/5 px-2.5 py-1.5">
                <button
                  className="flex-1 text-left text-sm text-zinc-200 hover:text-white"
                  onClick={() => {
                    updateBrand(k.kit);
                    toast.success(`Applied “${k.name}”`);
                  }}
                >
                  {k.name}
                </button>
                <button className="text-zinc-500 hover:text-rose-400" onClick={() => removeKit(k.id)}>
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const resolveHeaderPreset = (b: BrandKit): HeaderPreset => b.headerPreset ?? (b.headerStyle === "band" ? "band" : "rule");
const resolveFooterPreset = (b: BrandKit): FooterPreset => b.footerPreset ?? (b.footerStyle === "band" ? "band" : "line");

/** A titled on/off section with a grid of clickable prebuilt presets (the resource picker). */
function PresetSection<T extends string>({
  title,
  on,
  onToggle,
  current,
  presets,
  onPick,
  renderPreview,
}: {
  title: string;
  on: boolean;
  onToggle: (v: boolean) => void;
  current: T;
  presets: { id: T; label: string; desc: string }[];
  onPick: (id: T) => void;
  renderPreview: (id: T) => React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-2 flex items-center gap-2 text-sm text-zinc-300">
        <input type="checkbox" checked={on} onChange={(e) => onToggle(e.target.checked)} className="h-4 w-4 accent-indigo-500" />
        {title}
      </label>
      <div className={`grid grid-cols-2 gap-1.5 ${on ? "" : "pointer-events-none opacity-40"}`}>
        {presets.map((p) => {
          const active = on && current === p.id;
          return (
            <button
              key={p.id}
              onClick={() => onPick(p.id)}
              title={p.desc}
              className={`overflow-hidden rounded-md border text-left transition ${active ? "border-indigo-400 ring-1 ring-indigo-400/40" : "border-[var(--app-border)] hover:border-zinc-500"}`}
            >
              <div className="h-9 w-full bg-[#0e1016]">{renderPreview(p.id)}</div>
              <div className="truncate px-1.5 py-1 text-[10px] font-medium text-zinc-300">{p.label}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/** Tiny visual of each header preset (schematic, not theme-exact). */
function HeaderThumb({ preset }: { preset: HeaderPreset }) {
  const bar = "absolute left-0 right-0 h-[3px] bg-gradient-to-r from-indigo-400 to-sky-400";
  return (
    <div className="relative h-full w-full px-1.5 py-1">
      {preset === "banner" && (<><div className="absolute inset-x-0 top-0 h-5 bg-zinc-700/70" /><div className="absolute inset-x-0 top-5 h-[3px] bg-rose-500" /></>)}
      {preset === "rule" && <div className={`${bar} top-0`} />}
      {preset === "band" && (<><div className="absolute inset-x-0 top-0 h-4 bg-zinc-700/60" /><div className={`${bar} top-4`} /></>)}
      {preset === "gradientBar" && <div className="absolute inset-x-0 top-0 h-4 bg-gradient-to-r from-indigo-500 to-sky-500" />}
      {preset === "sidebar" && <div className="absolute left-0 top-0 h-4 w-[3px] bg-gradient-to-b from-indigo-400 to-sky-400" />}
      {preset === "minimal" && <div className="absolute inset-x-1.5 top-[15px] h-px bg-zinc-500" />}
      <div className={`relative flex items-center gap-1 ${preset === "sidebar" ? "pl-1" : ""} ${preset === "gradientBar" ? "text-white" : "text-zinc-400"}`}>
        <div className="h-1.5 w-4 rounded-sm bg-current opacity-70" />
        <div className="ml-auto h-1 w-6 rounded-sm bg-current opacity-50" />
      </div>
    </div>
  );
}

/** Tiny visual of each footer preset. */
function FooterThumb({ preset }: { preset: FooterPreset }) {
  return (
    <div className="relative h-full w-full px-1.5">
      {preset === "band" && <div className="absolute inset-x-0 bottom-0 h-3.5 bg-zinc-700/60" />}
      {preset === "line" && <div className="absolute inset-x-1.5 bottom-3 h-px bg-indigo-400/40" />}
      <div className="absolute inset-x-1.5 bottom-1 flex items-center text-zinc-400">
        {preset === "confidential" && <div className="h-2 w-8 rounded-full bg-indigo-400/30" />}
        {preset === "line" || preset === "band" ? <div className="h-1 w-6 rounded-sm bg-current opacity-50" /> : null}
        {preset === "pageOnly" ? <div className="mx-auto h-1 w-4 rounded-sm bg-current opacity-60" /> : <div className="ml-auto h-1 w-3 rounded-sm bg-current opacity-60" />}
      </div>
    </div>
  );
}

function ColorField({
  label,
  value,
  onChange,
  onReset,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  onReset?: () => void;
}) {
  return (
    <div>
      <span className="mb-1.5 block text-xs font-medium text-zinc-400">{label}</span>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-8 w-10 cursor-pointer rounded border border-[var(--app-border)] bg-transparent"
        />
        {onReset && (
          <button onClick={onReset} className="text-xs text-zinc-500 hover:text-zinc-300">
            reset
          </button>
        )}
      </div>
    </div>
  );
}

// ---------- Selected element ----------
function ElementPanel() {
  const deck = useEditor((s) => s.deck)!;
  const currentSlideId = useEditor((s) => s.currentSlideId)!;
  const selectedId = useEditor((s) => s.selectedElementId);
  const updateElement = useEditor((s) => s.updateElement);
  const deleteElement = useEditor((s) => s.deleteElement);

  const slide = deck.slides.find((s) => s.id === currentSlideId);
  const el = slide?.elements.find((e) => e.id === selectedId);

  if (!el) {
    return (
      <div className="py-10 text-center text-sm text-zinc-500">
        <Type className="mx-auto mb-2 opacity-50" />
        Click any element on the slide to edit it.
      </div>
    );
  }

  const patch = (p: Partial<typeof el>) => updateElement(slide!.id, el.id, p);

  return (
    <div className="space-y-4">
      {el.type === "text" && <AITextActions slide={slide!} el={el as TextElement} />}
      {el.type === "text" && (
        <>
          {(el as TextElement).items ? (
            <Field label="List items (one per line)">
              <textarea
                className={inputCls}
                rows={6}
                value={(el as TextElement).items!.join("\n")}
                onChange={(e) => {
                  const items = e.target.value.split("\n");
                  patch({ items, text: items.join("\n") } as Partial<TextElement>);
                }}
              />
            </Field>
          ) : (
            <Field label="Text">
              <textarea
                className={inputCls}
                rows={3}
                value={(el as TextElement).text}
                onChange={(e) => patch({ text: e.target.value } as Partial<TextElement>)}
              />
            </Field>
          )}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Size">
              <input
                type="number"
                className={inputCls}
                value={(el as TextElement).fontSize ?? 24}
                onChange={(e) => patch({ fontSize: Number(e.target.value) } as Partial<TextElement>)}
              />
            </Field>
            <Field label="Weight">
              <select
                className={inputCls}
                value={(el as TextElement).fontWeight ?? 400}
                onChange={(e) => patch({ fontWeight: Number(e.target.value) } as Partial<TextElement>)}
              >
                {[400, 500, 600, 700, 800].map((w) => (
                  <option key={w} value={w}>
                    {w}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <Field label="Align">
            <div className="grid grid-cols-3 gap-1 rounded-lg bg-[#0e1016] p-1">
              {(["left", "center", "right"] as const).map((a) => (
                <button
                  key={a}
                  onClick={() => patch({ align: a } as Partial<TextElement>)}
                  className={`rounded py-1.5 text-xs capitalize ${
                    (el as TextElement).align === a ? "bg-indigo-500 text-white" : "text-zinc-400"
                  }`}
                >
                  {a}
                </button>
              ))}
            </div>
          </Field>
          <ColorField
            label="Color"
            value={resolveColor((el as TextElement).color, deck.theme, deck.brand, deck.theme.colors.text)}
            onChange={(v) => patch({ color: v } as Partial<TextElement>)}
          />
        </>
      )}

      {el.type !== "text" && (
        <p className="text-sm text-zinc-400">
          {el.type} element selected. Drag it on the canvas to reposition.
        </p>
      )}

      <Button variant="outline" size="sm" className="w-full" onClick={() => deleteElement(slide!.id, el.id)}>
        Delete element
      </Button>
    </div>
  );
}

// ---------- Inline AI text actions ----------
const AI_ACTIONS = [
  { task: "improve", label: "Improve", icon: <Wand2 size={13} /> },
  { task: "shorten", label: "Shorten", icon: <Scissors size={13} /> },
  { task: "expand", label: "Expand", icon: <Sparkles size={13} /> },
  { task: "fix", label: "Fix grammar", icon: <Type size={13} /> },
] as const;

function AITextActions({ slide, el }: { slide: Slide; el: TextElement }) {
  const updateElement = useEditor((s) => s.updateElement);
  const [busy, setBusy] = useState<string | null>(null);
  const isList = !!el.items;

  function slideContext(): string {
    const title = slide.elements.find((e) => e.type === "text" && (e.role === "title" || e.role === "heading"));
    return title && "text" in title ? (title as TextElement).text : "";
  }

  async function run(task: string) {
    setBusy(task);
    try {
      const res = await fetch("/api/assist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          task,
          text: isList ? undefined : el.text,
          items: isList ? el.items : undefined,
          context: slideContext(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.hint ?? data.error ?? "AI request failed");
        return;
      }
      const r = data.result as { text?: string; items?: string[] };
      if (r.items) updateElement(slide.id, el.id, { items: r.items, text: r.items.join("\n") } as Partial<TextElement>);
      else if (r.text) updateElement(slide.id, el.id, { text: r.text } as Partial<TextElement>);
      toast.success("Updated with AI");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Network error");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="rounded-lg border border-indigo-500/30 bg-indigo-500/5 p-2.5">
      <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-indigo-300">
        <Sparkles size={13} /> AI assist
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        {AI_ACTIONS.map((a) => (
          <button
            key={a.task}
            disabled={busy !== null}
            onClick={() => run(a.task)}
            className="flex items-center justify-center gap-1.5 rounded-md bg-white/5 py-1.5 text-xs font-medium text-zinc-200 transition hover:bg-white/10 disabled:opacity-40"
          >
            {busy === a.task ? <Loader2 size={13} className="animate-spin" /> : a.icon}
            {a.label}
          </button>
        ))}
      </div>
    </div>
  );
}
