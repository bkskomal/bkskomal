"use client";

import { useRef, useState } from "react";
import * as Lucide from "lucide-react";
import {
  Circle,
  Copy,
  Image as ImageIcon,
  LayoutGrid,
  Redo2,
  Smile,
  Sparkles,
  Square,
  Trash2,
  Triangle,
  Type,
  Undo2,
} from "lucide-react";
import { fileToDataUrl, ICON_CHOICES, makeIcon, makeImage, makeShape, makeText } from "@/lib/elements";
import { INSERT_CATEGORIES, INSERT_ITEMS, type InsertItem } from "@/lib/inserts";
import { autofitSlide } from "@/lib/autofit";
import { repairSlide } from "@/lib/lint";
import { toast } from "@/lib/toast";
import { ImagesMenu } from "./ImagesMenu";
import { ChartMenu } from "./ChartMenu";
import {
  redo,
  undo,
  useCanRedo,
  useCanUndo,
  useEditor,
} from "@/lib/store";
import type { ShapeElement } from "@/lib/types";

export function Toolbar() {
  const currentSlideId = useEditor((s) => s.currentSlideId);
  const selectedElementId = useEditor((s) => s.selectedElementId);
  const addElement = useEditor((s) => s.addElement);
  const addElements = useEditor((s) => s.addElements);
  const setSlideElements = useEditor((s) => s.setSlideElements);
  const duplicateElement = useEditor((s) => s.duplicateElement);
  const deleteElement = useEditor((s) => s.deleteElement);
  const canUndo = useCanUndo();
  const canRedo = useCanRedo();
  const fileRef = useRef<HTMLInputElement>(null);
  const [shapeMenu, setShapeMenu] = useState(false);
  const [iconMenu, setIconMenu] = useState(false);
  const [libMenu, setLibMenu] = useState(false);
  const [libCat, setLibCat] = useState<InsertItem["category"]>("shape");

  if (!currentSlideId) return null;

  const addShape = (shape: ShapeElement["shape"]) => {
    addElement(currentSlideId, makeShape(shape));
    setShapeMenu(false);
  };

  async function onImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !currentSlideId) return;
    const url = await fileToDataUrl(file);
    addElement(currentSlideId, makeImage(url));
    e.target.value = "";
  }

  function polish() {
    if (!currentSlideId) return;
    const slide = useEditor.getState().deck?.slides.find((s) => s.id === currentSlideId);
    if (!slide) return;
    const els = slide.elements.map((e) => ({ ...e }));
    autofitSlide(els);
    const n = repairSlide(els, { clampOffCanvas: true, fixContrast: true, fixOverlap: true });
    setSlideElements(currentSlideId, els);
    toast.success(n ? `Polished — fit text + ${n} fix${n === 1 ? "" : "es"}` : "Polished — text refit, already tidy ✨");
  }

  return (
    <div className="flex h-12 shrink-0 items-center gap-1 border-b border-[var(--app-border)] bg-[var(--app-panel)] px-3">
      <ToolBtn label="Undo (Ctrl+Z)" disabled={!canUndo} onClick={undo}>
        <Undo2 size={17} />
      </ToolBtn>
      <ToolBtn label="Redo (Ctrl+Shift+Z)" disabled={!canRedo} onClick={redo}>
        <Redo2 size={17} />
      </ToolBtn>

      <Divider />

      <ToolBtn label="Add text" onClick={() => addElement(currentSlideId, makeText())}>
        <Type size={17} />
      </ToolBtn>

      <div className="relative">
        <ToolBtn label="Add shape" onClick={() => setShapeMenu((m) => !m)}>
          <Square size={17} />
        </ToolBtn>
        {shapeMenu && (
          <>
            <div className="fixed inset-0 z-20" onClick={() => setShapeMenu(false)} />
            <div className="absolute left-0 z-30 mt-1 flex gap-1 rounded-lg border border-[var(--app-border)] bg-[var(--app-panel)] p-1 shadow-xl">
              <ToolBtn label="Rectangle" onClick={() => addShape("roundedRect")}>
                <Square size={17} />
              </ToolBtn>
              <ToolBtn label="Ellipse" onClick={() => addShape("ellipse")}>
                <Circle size={17} />
              </ToolBtn>
              <ToolBtn label="Triangle" onClick={() => addShape("triangle")}>
                <Triangle size={17} />
              </ToolBtn>
            </div>
          </>
        )}
      </div>

      <div className="relative">
        <ToolBtn label="Insert from library" onClick={() => setLibMenu((m) => !m)}>
          <LayoutGrid size={17} />
        </ToolBtn>
        {libMenu && (
          <>
            <div className="fixed inset-0 z-20" onClick={() => setLibMenu(false)} />
            <div className="absolute left-0 z-30 mt-1 w-80 rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] p-2 shadow-2xl">
              <div className="mb-2 flex gap-1 rounded-lg bg-[#0e1016] p-0.5">
                {INSERT_CATEGORIES.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setLibCat(c.id)}
                    className={`flex-1 rounded-md px-2 py-1 text-xs font-medium ${libCat === c.id ? "bg-indigo-500 text-white" : "text-zinc-400 hover:text-zinc-200"}`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
              <div className="grid max-h-80 grid-cols-2 gap-1.5 overflow-y-auto">
                {INSERT_ITEMS.filter((it) => it.category === libCat).map((it) => (
                  <button
                    key={it.id}
                    onClick={() => { addElements(currentSlideId, it.make()); setLibMenu(false); }}
                    className="flex items-center gap-2 rounded-lg border border-[var(--app-border)] px-2.5 py-2 text-left text-xs text-zinc-300 transition hover:border-indigo-400 hover:bg-white/5"
                  >
                    <InsertGlyph item={it} />
                    <span className="truncate">{it.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      <ToolBtn label="Upload image" onClick={() => fileRef.current?.click()}>
        <ImageIcon size={17} />
      </ToolBtn>
      <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onImage} />

      <ImagesMenu />
      <ChartMenu />

      <Divider />
      <button
        title="Polish slide — fit text, fix contrast & overlaps"
        onClick={polish}
        className="flex h-9 items-center gap-1.5 rounded-lg px-2.5 text-sm font-medium text-indigo-300 transition hover:bg-indigo-500/10 hover:text-indigo-200"
      >
        <Sparkles size={16} /> Polish
      </button>

      <div className="relative">
        <ToolBtn label="Add icon" onClick={() => setIconMenu((m) => !m)}>
          <Smile size={17} />
        </ToolBtn>
        {iconMenu && (
          <>
            <div className="fixed inset-0 z-20" onClick={() => setIconMenu(false)} />
            <div className="absolute left-0 z-30 mt-1 grid w-64 grid-cols-6 gap-1 rounded-lg border border-[var(--app-border)] bg-[var(--app-panel)] p-2 shadow-xl">
              {ICON_CHOICES.map((name) => {
                const Comp = (Lucide as unknown as Record<string, React.ComponentType<{ size?: number }>>)[pascal(name)];
                if (!Comp) return null;
                return (
                  <button
                    key={name}
                    title={name}
                    onClick={() => {
                      addElement(currentSlideId, makeIcon(name));
                      setIconMenu(false);
                    }}
                    className="flex h-9 w-9 items-center justify-center rounded-md text-zinc-300 hover:bg-white/10 hover:text-white"
                  >
                    <Comp size={18} />
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>

      {selectedElementId && (
        <>
          <Divider />
          <ToolBtn label="Duplicate (Ctrl+D)" onClick={() => duplicateElement(currentSlideId, selectedElementId)}>
            <Copy size={17} />
          </ToolBtn>
          <ToolBtn label="Delete (Del)" onClick={() => deleteElement(currentSlideId, selectedElementId)}>
            <Trash2 size={17} />
          </ToolBtn>
        </>
      )}
    </div>
  );
}

function ToolBtn({
  children,
  label,
  onClick,
  disabled,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      title={label}
      aria-label={label}
      onClick={onClick}
      disabled={disabled}
      className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-300 transition hover:bg-white/10 hover:text-white disabled:opacity-30 disabled:hover:bg-transparent"
    >
      {children}
    </button>
  );
}

function Divider() {
  return <div className="mx-1 h-6 w-px bg-[var(--app-border)]" />;
}

/** A tiny schematic glyph so each library item reads at a glance. */
function InsertGlyph({ item }: { item: InsertItem }) {
  const g = "shrink-0 text-indigo-300";
  if (item.category === "diagram") {
    const map: Record<string, React.ReactNode> = {
      process3: <>▸▸▸</>,
      arrowFlow3: <>→→→</>,
      matrix2x2: <span className="grid grid-cols-2 gap-px">{[0, 1, 2, 3].map((i) => <span key={i} className="block h-1.5 w-1.5 bg-current" />)}</span>,
      venn2: <>◐◑</>,
      pyramid3: <>△</>,
      funnel3: <>▽</>,
      timeline4: <>•—•</>,
      comparison2: <>▮▮</>,
    };
    return <span className={`flex h-4 w-4 items-center justify-center text-[10px] ${g}`}>{map[item.id] ?? "◆"}</span>;
  }
  if (item.category === "component") return <span className={`flex h-4 w-4 items-center justify-center text-[11px] ${g}`}>◈</span>;
  const glyph: Record<string, string> = { chevron: "❯", arrowRight: "→", hexagon: "⬡", pentagon: "⬠", diamond: "◆", star: "★", parallelogram: "▱", pill: "▭", roundedRect: "▢", ellipse: "●", triangle: "▲", line: "—" };
  return <span className={`flex h-4 w-4 items-center justify-center text-[12px] ${g}`}>{glyph[item.id] ?? "◆"}</span>;
}

function pascal(name: string): string {
  return name
    .split(/[-_ ]/)
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join("");
}
