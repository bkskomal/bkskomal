"use client";

import { useState } from "react";
import { Copy, Plus, Trash2 } from "lucide-react";
import { SlideView } from "@/components/SlideView";
import { buildSlide, LAYOUTS } from "@/lib/layouts";
import { BLOCK_SAMPLES } from "@/lib/blockSamples";
import { useEditor } from "@/lib/store";

export function SlideList() {
  const deck = useEditor((s) => s.deck);
  const currentSlideId = useEditor((s) => s.currentSlideId);
  const setCurrentSlide = useEditor((s) => s.setCurrentSlide);
  const addSlide = useEditor((s) => s.addSlide);
  const duplicateSlide = useEditor((s) => s.duplicateSlide);
  const deleteSlide = useEditor((s) => s.deleteSlide);
  const [picker, setPicker] = useState(false);

  if (!deck) return null;

  function addBlock(layoutId: string) {
    const sample = BLOCK_SAMPLES[layoutId] ?? BLOCK_SAMPLES.bullets;
    addSlide(buildSlide(sample, deck?.style), currentSlideId ?? undefined);
    setPicker(false);
  }

  return (
    <aside className="flex w-56 shrink-0 flex-col border-r border-[var(--app-border)] bg-[var(--app-panel)]">
      <div className="relative flex items-center justify-between px-3 py-2.5 text-xs font-medium text-zinc-400">
        <span>{deck.slides.length} slides</span>
        <button onClick={() => setPicker((p) => !p)} className="rounded-md p-1 text-zinc-400 hover:bg-white/5 hover:text-zinc-100" title="Add slide">
          <Plus size={16} />
        </button>
        {picker && (
          <>
            <div className="fixed inset-0 z-20" onClick={() => setPicker(false)} />
            <div className="absolute right-2 top-10 z-30 grid max-h-80 w-44 grid-cols-1 gap-0.5 overflow-y-auto rounded-lg border border-[var(--app-border)] bg-[var(--app-panel)] p-1 shadow-xl">
              {LAYOUTS.map((l) => (
                <button
                  key={l.id}
                  onClick={() => addBlock(l.id)}
                  className="flex items-center justify-between rounded-md px-2.5 py-1.5 text-left text-xs text-zinc-200 hover:bg-white/10"
                >
                  <span className="font-medium">{l.name}</span>
                  <span className="text-[10px] text-zinc-500">{l.hint}</span>
                </button>
              ))}
            </div>
          </>
        )}
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto px-3 pb-3">
        {deck.slides.map((slide, i) => {
          const active = slide.id === currentSlideId;
          return (
            <div key={slide.id} className="group relative">
              <button
                onClick={() => setCurrentSlide(slide.id)}
                className={`block w-full overflow-hidden rounded-lg ring-2 transition ${
                  active ? "ring-indigo-500" : "ring-transparent hover:ring-white/10"
                }`}
              >
                <span className="absolute left-1 top-1 z-10 rounded bg-black/60 px-1.5 text-[10px] font-medium text-zinc-200">
                  {i + 1}
                </span>
                <SlideView
                  slide={slide}
                  theme={deck.theme}
                  brand={deck.brand}
                  pageIndex={i}
                  pageCount={deck.slides.length}
                  width={192}
                />
              </button>
              <div className="absolute right-1 top-1 z-10 flex gap-1 opacity-0 transition group-hover:opacity-100">
                <IconBtn title="Duplicate" onClick={() => duplicateSlide(slide.id)}>
                  <Copy size={13} />
                </IconBtn>
                {deck.slides.length > 1 && (
                  <IconBtn title="Delete" onClick={() => deleteSlide(slide.id)}>
                    <Trash2 size={13} />
                  </IconBtn>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </aside>
  );
}

function IconBtn({
  children,
  title,
  onClick,
}: {
  children: React.ReactNode;
  title: string;
  onClick: () => void;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className="rounded bg-black/70 p-1 text-zinc-300 hover:bg-black hover:text-white"
    >
      {children}
    </button>
  );
}
