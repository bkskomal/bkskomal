"use client";

import { useEffect, useState } from "react";
import { ImagePlus, Loader2, Search, ShieldCheck, Sparkles } from "lucide-react";
import { useEditor } from "@/lib/store";
import { useAdminConfig } from "@/lib/adminConfig";
import { useOrg } from "@/lib/org";
import { makeImage } from "@/lib/elements";
import { toast } from "@/lib/toast";

interface Stock {
  url: string;
  thumb: string;
  alt: string;
  credit?: string;
}

/** Insert imagery: stock photo search (keyless by default) + AI image generation. */
export function ImagesMenu() {
  const currentSlideId = useEditor((s) => s.currentSlideId);
  const addElement = useEditor((s) => s.addElement);
  const imageOverride = useAdminConfig((s) => s.imageOverride);
  const provider = useAdminConfig((s) => s.imageProvider);

  const approved = useOrg((s) => s.org.approvedAssets);
  const loadOrg = useOrg((s) => s.load);
  const orgLoaded = useOrg((s) => s.loaded);
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"stock" | "ai" | "brand">("stock");
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<Stock[]>([]);
  const [genUrl, setGenUrl] = useState<string | null>(null);

  async function search() {
    if (!q.trim()) return;
    setBusy(true);
    try {
      const cfg = imageOverride();
      const r = await fetch("/api/images/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: q, provider: cfg.provider, apiKey: cfg.apiKey, count: 12 }),
      }).then((x) => x.json());
      if (r.error) throw new Error(r.hint ?? r.error);
      setResults(r.images ?? []);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Search failed");
    } finally {
      setBusy(false);
    }
  }

  async function generate() {
    if (!q.trim()) return;
    setBusy(true);
    setGenUrl(null);
    try {
      const cfg = imageOverride();
      const r = await fetch("/api/images/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: q, baseUrl: cfg.genBaseUrl, model: cfg.genModel, apiKey: cfg.genApiKey }),
      }).then((x) => x.json());
      if (!r.url) throw new Error(r.hint ?? r.error ?? "Generation failed");
      setGenUrl(r.url);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Generation failed");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => { if (open && !orgLoaded) loadOrg(); }, [open, orgLoaded, loadOrg]);

  function insert(url: string) {
    if (!currentSlideId) return;
    addElement(currentSlideId, makeImage(url));
    setOpen(false);
    toast.success("Image added");
  }

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") (tab === "stock" ? search() : generate());
  };

  return (
    <div className="relative">
      <button
        title="Add image (stock or AI)"
        aria-label="Add image"
        onClick={() => setOpen((o) => !o)}
        className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-300 transition hover:bg-white/10 hover:text-white"
      >
        <ImagePlus size={17} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-20" onClick={() => setOpen(false)} />
          <div className="absolute left-0 z-30 mt-1 w-96 rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] p-3 shadow-2xl">
            <div className="mb-2 flex gap-1 rounded-lg bg-[#0e1016] p-0.5 text-xs">
              <button onClick={() => setTab("stock")} className={`flex flex-1 items-center justify-center gap-1.5 rounded-md py-1.5 font-medium ${tab === "stock" ? "bg-indigo-500 text-white" : "text-zinc-400"}`}>
                <Search size={13} /> Stock
              </button>
              <button onClick={() => setTab("ai")} className={`flex flex-1 items-center justify-center gap-1.5 rounded-md py-1.5 font-medium ${tab === "ai" ? "bg-indigo-500 text-white" : "text-zinc-400"}`}>
                <Sparkles size={13} /> AI generate
              </button>
              {approved.length > 0 && (
                <button onClick={() => setTab("brand")} className={`flex flex-1 items-center justify-center gap-1.5 rounded-md py-1.5 font-medium ${tab === "brand" ? "bg-indigo-500 text-white" : "text-zinc-400"}`}>
                  <ShieldCheck size={13} /> Brand
                </button>
              )}
            </div>

            {tab === "brand" && (
              <div className="mt-2 grid max-h-72 grid-cols-3 gap-1.5 overflow-y-auto">
                {approved.map((url, i) => (
                  <button key={i} onClick={() => insert(url)} className="overflow-hidden rounded-md border border-[var(--app-border)] hover:border-indigo-400">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={url} alt="approved asset" className="h-20 w-full bg-white/5 object-contain p-1" loading="lazy" />
                  </button>
                ))}
              </div>
            )}

            {tab !== "brand" && (
            <div className="flex gap-1.5">
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={onKey}
                placeholder={tab === "stock" ? "Search photos…" : "Describe an image…"}
                className="min-w-0 flex-1 rounded-lg border border-[var(--app-border)] bg-[var(--app-bg)] px-3 py-1.5 text-sm text-[var(--app-text)] outline-none focus:border-indigo-400"
              />
              <button
                onClick={tab === "stock" ? search : generate}
                disabled={busy || !q.trim()}
                className="flex items-center gap-1 rounded-lg bg-indigo-500 px-3 py-1.5 text-sm font-medium text-white hover:bg-indigo-400 disabled:opacity-40"
              >
                {busy ? <Loader2 size={14} className="animate-spin" /> : tab === "stock" ? <Search size={14} /> : <Sparkles size={14} />}
                {tab === "stock" ? "Search" : "Create"}
              </button>
            </div>
            )}

            {tab === "stock" && (
              <>
                <p className="mt-1.5 text-[10px] text-zinc-500">Provider: {provider}{provider === "picsum" ? " (keyless — set Unsplash/Pexels in Settings for relevant results)" : ""}</p>
                <div className="mt-2 grid max-h-72 grid-cols-3 gap-1.5 overflow-y-auto">
                  {results.map((im, i) => (
                    <button key={i} onClick={() => insert(im.url)} title={im.alt} className="group relative overflow-hidden rounded-md border border-[var(--app-border)] hover:border-indigo-400">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={im.thumb} alt={im.alt} className="h-20 w-full object-cover" loading="lazy" />
                    </button>
                  ))}
                  {!results.length && !busy && <p className="col-span-3 py-6 text-center text-xs text-zinc-500">Search to find photos.</p>}
                </div>
              </>
            )}

            {tab === "ai" && (
              <div className="mt-2">
                {genUrl ? (
                  <div className="space-y-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={genUrl} alt="Generated" className="max-h-56 w-full rounded-lg object-contain" />
                    <button onClick={() => insert(genUrl)} className="w-full rounded-lg bg-indigo-500 py-1.5 text-sm font-medium text-white hover:bg-indigo-400">Insert image</button>
                  </div>
                ) : (
                  <p className="py-6 text-center text-xs text-zinc-500">{busy ? "Generating…" : "Describe an image and click Create."}</p>
                )}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
