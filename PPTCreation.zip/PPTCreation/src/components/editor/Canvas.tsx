"use client";

import { useEffect, useRef, useState } from "react";
import { SlideView } from "@/components/SlideView";
import { useEditor } from "@/lib/store";

export function Canvas() {
  const deck = useEditor((s) => s.deck);
  const currentSlideId = useEditor((s) => s.currentSlideId);
  const selectedElementId = useEditor((s) => s.selectedElementId);
  const selectElement = useEditor((s) => s.selectElement);
  const updateElement = useEditor((s) => s.updateElement);

  const wrapRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(960);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const w = entries[0].contentRect.width;
      setWidth(Math.max(320, Math.min(w - 64, 1100)));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  if (!deck) return null;
  const slide = deck.slides.find((s) => s.id === currentSlideId) ?? deck.slides[0];
  const index = deck.slides.findIndex((s) => s.id === slide.id);

  return (
    <div ref={wrapRef} className="flex flex-1 items-center justify-center overflow-auto p-8">
      <div className="rounded-xl shadow-2xl shadow-black/50 ring-1 ring-white/10">
        <SlideView
          slide={slide}
          theme={deck.theme}
          brand={deck.brand}
          pageIndex={index}
          pageCount={deck.slides.length}
          width={width}
          interactive
          selectedElementId={selectedElementId}
          onSelectElement={selectElement}
          onUpdateElement={(id, patch) => updateElement(slide.id, id, patch)}
          onUpdateText={(id, patch) =>
            updateElement(slide.id, id, {
              ...patch,
              ...(patch.items ? { text: patch.items.join("\n") } : {}),
            })
          }
        />
      </div>
    </div>
  );
}
