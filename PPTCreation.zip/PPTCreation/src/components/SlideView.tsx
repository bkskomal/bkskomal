"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import * as Lucide from "lucide-react";
import { brandChrome } from "@/lib/brand";
import { gradientCss, resolveColor, resolveFont } from "@/lib/color";
import {
  applyResize,
  snapMove,
  type Guide,
  type Rect,
  type ResizeHandle,
} from "@/lib/snapping";
import { CANVAS } from "@/lib/utils";
import type {
  BrandKit,
  ShapeElement,
  Slide,
  SlideElement,
  TextElement,
  Theme,
} from "@/lib/types";

interface Props {
  slide: Slide;
  theme: Theme;
  brand: BrandKit;
  pageIndex: number;
  pageCount: number;
  /** rendered width in px; height derives from 16:9 */
  width: number;
  selectedElementId?: string | null;
  onSelectElement?: (id: string | null) => void;
  /** generic element update (move / resize / rotate) */
  onUpdateElement?: (id: string, patch: Partial<SlideElement>) => void;
  /** commit inline text edits (double-click a text box to edit on the canvas) */
  onUpdateText?: (id: string, patch: { text?: string; items?: string[] }) => void;
  interactive?: boolean;
}

/**
 * Renders a Slide to scaled DOM. Always draws at the logical 1280x720 canvas and
 * uses a CSS transform to fit `width`, so the same component powers the big
 * editor canvas, the sidebar thumbnails, and the gallery previews identically.
 */
export function SlideView({
  slide,
  theme,
  brand,
  pageIndex,
  pageCount,
  width,
  selectedElementId,
  onSelectElement,
  onUpdateElement,
  onUpdateText,
  interactive = false,
}: Props) {
  const scale = width / CANVAS.w;
  const height = width * (CANVAS.h / CANVAS.w);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [guides, setGuides] = useState<Guide[]>([]);
  const surfaceRef = useRef<HTMLDivElement>(null);

  const elements = useMemo(() => {
    const chrome = brandChrome(brand, slide.layout, pageIndex, pageCount, slide.logoScale, theme);
    return [...slide.elements, ...chrome].sort((a, b) => (a.z ?? 0) - (b.z ?? 0));
  }, [slide.elements, slide.layout, slide.logoScale, brand, pageIndex, pageCount]);

  const selectedEl = slide.elements.find((e) => e.id === selectedElementId) ?? null;

  /** Convert a pointer event to canvas-space coordinates. */
  const toCanvas = (clientX: number, clientY: number) => {
    const rect = surfaceRef.current?.getBoundingClientRect();
    if (!rect) return { x: clientX, y: clientY };
    return { x: (clientX - rect.left) / scale, y: (clientY - rect.top) / scale };
  };

  const others = (id: string): Rect[] =>
    slide.elements.filter((e) => e.id !== id && !e.brand).map((e) => ({ x: e.x, y: e.y, w: e.w, h: e.h }));

  function beginMove(el: SlideElement, e: React.PointerEvent) {
    if (!onUpdateElement || el.locked) return;
    const start = toCanvas(e.clientX, e.clientY);
    const origin = { x: el.x, y: el.y };
    const targets = others(el.id);
    let moved = false;
    const move = (ev: PointerEvent) => {
      const p = toCanvas(ev.clientX, ev.clientY);
      const nx = origin.x + (p.x - start.x);
      const ny = origin.y + (p.y - start.y);
      if (Math.abs(p.x - start.x) > 2 || Math.abs(p.y - start.y) > 2) moved = true;
      if (!moved) return;
      const snapped = snapMove({ x: nx, y: ny, w: el.w, h: el.h }, targets);
      setGuides(snapped.guides);
      onUpdateElement(el.id, { x: snapped.x, y: snapped.y });
    };
    const up = () => {
      setGuides([]);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  function beginResize(el: SlideElement, handle: ResizeHandle, e: React.PointerEvent) {
    if (!onUpdateElement || el.locked) return;
    e.stopPropagation();
    const start = toCanvas(e.clientX, e.clientY);
    const rect0 = { x: el.x, y: el.y, w: el.w, h: el.h };
    const lockAspect = el.type === "image";
    const move = (ev: PointerEvent) => {
      const p = toCanvas(ev.clientX, ev.clientY);
      const next = applyResize(rect0, handle, p.x - start.x, p.y - start.y, {
        lockAspect: lockAspect || ev.shiftKey,
      });
      onUpdateElement(el.id, next);
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  function beginRotate(el: SlideElement, e: React.PointerEvent) {
    if (!onUpdateElement || el.locked) return;
    e.stopPropagation();
    const cx = el.x + el.w / 2;
    const cy = el.y + el.h / 2;
    const move = (ev: PointerEvent) => {
      const p = toCanvas(ev.clientX, ev.clientY);
      let deg = (Math.atan2(p.y - cy, p.x - cx) * 180) / Math.PI + 90;
      if (ev.shiftKey) deg = Math.round(deg / 15) * 15; // snap to 15°
      onUpdateElement(el.id, { rotation: Math.round(deg) });
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  const bg = slideBackground(slide, theme, brand);

  return (
    <div
      style={{ width, height }}
      className="relative overflow-hidden"
      onPointerDown={
        interactive
          ? () => {
              onSelectElement?.(null);
              setEditingId(null);
            }
          : undefined
      }
    >
      <div
        ref={surfaceRef}
        style={{
          width: CANVAS.w,
          height: CANVAS.h,
          transform: `scale(${scale})`,
          transformOrigin: "top left",
          background: bg,
        }}
        className="absolute top-0 left-0"
      >
        {elements.map((el) => (
          <ElementView
            key={el.id}
            el={el}
            theme={theme}
            brand={brand}
            selected={interactive && el.id === selectedElementId}
            editing={interactive && el.id === editingId}
            onSelect={
              interactive && !el.brand
                ? () => onSelectElement?.(el.id)
                : undefined
            }
            onBeginMove={
              interactive && !el.brand && !el.locked && onUpdateElement
                ? (e) => beginMove(el, e)
                : undefined
            }
            onStartEdit={
              interactive && !el.brand && el.type === "text" && onUpdateText
                ? () => {
                    onSelectElement?.(el.id);
                    setEditingId(el.id);
                  }
                : undefined
            }
            onUpdateText={onUpdateText}
            onEndEdit={() => setEditingId(null)}
          />
        ))}

        {/* snap guides */}
        {guides.map((g, i) =>
          g.axis === "x" ? (
            <div
              key={i}
              style={{ position: "absolute", left: g.pos, top: 0, width: 1, height: CANVAS.h, background: "#ec4899" }}
            />
          ) : (
            <div
              key={i}
              style={{ position: "absolute", top: g.pos, left: 0, height: 1, width: CANVAS.w, background: "#ec4899" }}
            />
          ),
        )}

        {/* selection handles */}
        {interactive && selectedEl && !selectedEl.brand && editingId !== selectedEl.id && onUpdateElement && (
          <SelectionLayer
            el={selectedEl}
            scale={scale}
            onResize={(handle, e) => beginResize(selectedEl, handle, e)}
            onRotate={(e) => beginRotate(selectedEl, e)}
          />
        )}
      </div>
    </div>
  );
}

const HANDLES: { key: ResizeHandle; cx: number; cy: number; cursor: string }[] = [
  { key: "nw", cx: 0, cy: 0, cursor: "nwse-resize" },
  { key: "n", cx: 0.5, cy: 0, cursor: "ns-resize" },
  { key: "ne", cx: 1, cy: 0, cursor: "nesw-resize" },
  { key: "e", cx: 1, cy: 0.5, cursor: "ew-resize" },
  { key: "se", cx: 1, cy: 1, cursor: "nwse-resize" },
  { key: "s", cx: 0.5, cy: 1, cursor: "ns-resize" },
  { key: "sw", cx: 0, cy: 1, cursor: "nesw-resize" },
  { key: "w", cx: 0, cy: 0.5, cursor: "ew-resize" },
];

/** Resize/rotate handles drawn around the selected element (scales with canvas). */
function SelectionLayer({
  el,
  scale,
  onResize,
  onRotate,
}: {
  el: SlideElement;
  scale: number;
  onResize: (handle: ResizeHandle, e: React.PointerEvent) => void;
  onRotate: (e: React.PointerEvent) => void;
}) {
  const hs = 11 / scale; // on-screen-constant handle size
  const bw = 1.5 / scale;
  const rotOffset = 30 / scale;
  const handleStyle: React.CSSProperties = {
    position: "absolute",
    width: hs,
    height: hs,
    background: "#ffffff",
    border: `${bw}px solid #6366f1`,
    borderRadius: hs * 0.25,
    pointerEvents: "auto",
  };

  return (
    <div
      style={{
        position: "absolute",
        left: el.x,
        top: el.y,
        width: el.w,
        height: el.h,
        transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined,
        transformOrigin: "center",
        pointerEvents: "none",
      }}
    >
      <div style={{ position: "absolute", inset: 0, border: `${bw}px solid #6366f1` }} />

      {/* rotate handle */}
      <div
        style={{
          position: "absolute",
          left: el.w / 2,
          top: -rotOffset,
          width: 0,
          height: rotOffset,
          borderLeft: `${bw}px solid #6366f1`,
        }}
      />
      <div
        onPointerDown={onRotate}
        title="Rotate (hold Shift for 15°)"
        style={{
          position: "absolute",
          left: el.w / 2 - hs / 2,
          top: -rotOffset - hs,
          width: hs,
          height: hs,
          background: "#6366f1",
          borderRadius: "50%",
          pointerEvents: "auto",
          cursor: "grab",
        }}
      />

      {HANDLES.map((h) => (
        <div
          key={h.key}
          onPointerDown={(e) => onResize(h.key, e)}
          style={{
            ...handleStyle,
            left: el.w * h.cx - hs / 2,
            top: el.h * h.cy - hs / 2,
            cursor: h.cursor,
          }}
        />
      ))}
    </div>
  );
}

function slideBackground(slide: Slide, theme: Theme, brand: BrandKit): string {
  const b = slide.background;
  if (!b) return resolveColor("token:background", theme, brand, theme.colors.background);
  if (b.type === "solid")
    return resolveColor(b.color, theme, brand, theme.colors.background);
  if (b.type === "gradient" && b.gradient)
    return gradientCss(
      resolveColor(b.gradient[0], theme, brand),
      resolveColor(b.gradient[1], theme, brand),
      b.gradientAngle,
    );
  if (b.type === "image" && b.src) return `center / cover no-repeat url(${b.src})`;
  return theme.colors.background;
}

function ElementView({
  el,
  theme,
  brand,
  selected,
  editing,
  onSelect,
  onBeginMove,
  onStartEdit,
  onUpdateText,
  onEndEdit,
}: {
  el: SlideElement;
  theme: Theme;
  brand: BrandKit;
  selected: boolean;
  editing: boolean;
  onSelect?: () => void;
  onBeginMove?: (e: React.PointerEvent) => void;
  onStartEdit?: () => void;
  onUpdateText?: (id: string, patch: { text?: string; items?: string[] }) => void;
  onEndEdit?: () => void;
}) {
  function handlePointerDown(e: React.PointerEvent) {
    if (!onSelect || editing) return;
    e.stopPropagation();
    onSelect();
    onBeginMove?.(e);
  }

  const base: React.CSSProperties = {
    position: "absolute",
    left: el.x,
    top: el.y,
    width: el.w,
    height: el.h,
    opacity: el.opacity ?? 1,
    transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined,
    cursor: editing ? "text" : onBeginMove ? "grab" : onSelect ? "pointer" : "default",
    outline: editing ? "2px solid #6366f1" : selected && !onBeginMove ? "2px solid #3b82f6" : undefined,
    outlineOffset: 2,
    touchAction: "none",
  };

  return (
    <div
      style={base}
      onPointerDown={handlePointerDown}
      onDoubleClick={
        onStartEdit
          ? (e) => {
              e.stopPropagation();
              onStartEdit();
            }
          : undefined
      }
    >
      {el.type === "text" && (
        <TextView
          el={el}
          theme={theme}
          brand={brand}
          editing={editing}
          onUpdateText={onUpdateText}
          onEndEdit={onEndEdit}
        />
      )}
      {el.type === "shape" && <ShapeView el={el} theme={theme} brand={brand} />}
      {el.type === "image" && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={el.src}
          alt={el.alt ?? ""}
          style={{
            width: "100%",
            height: "100%",
            objectFit: el.fit ?? "cover",
            borderRadius: el.radius ?? 0,
          }}
        />
      )}
      {el.type === "icon" && <IconView el={el} theme={theme} brand={brand} />}
      {el.type === "chart" && <ChartView el={el} theme={theme} brand={brand} />}
    </div>
  );
}

function TextView({
  el,
  theme,
  brand,
  editing,
  onUpdateText,
  onEndEdit,
}: {
  el: TextElement;
  theme: Theme;
  brand: BrandKit;
  editing?: boolean;
  onUpdateText?: (id: string, patch: { text?: string; items?: string[] }) => void;
  onEndEdit?: () => void;
}) {
  const role = el.role === "title" || el.role === "heading" || el.role === "quote" ? "heading" : "body";
  const isList = !!(el.items && el.listStyle !== "none");
  const common: React.CSSProperties = {
    width: "100%",
    height: "100%",
    color: resolveColor(el.color, theme, brand, theme.colors.text),
    fontFamily: `${resolveFont(el.fontFamily, role, theme, brand)}, sans-serif`,
    fontSize: el.fontSize ?? 24,
    fontWeight: el.fontWeight ?? 400,
    fontStyle: el.italic ? "italic" : "normal",
    textAlign: el.align ?? "left",
    lineHeight: el.lineHeight ?? 1.3,
    letterSpacing: el.letterSpacing ? `${el.letterSpacing}px` : undefined,
    display: "flex",
    flexDirection: "column",
    justifyContent:
      el.valign === "middle" ? "center" : el.valign === "bottom" ? "flex-end" : "flex-start",
    overflow: "hidden",
    wordBreak: "break-word",
  };

  if (editing && onUpdateText) {
    return (
      <InlineTextEditor
        el={el}
        isList={isList}
        style={common}
        onChange={(value) =>
          onUpdateText(
            el.id,
            isList ? { items: value.split("\n") } : { text: value },
          )
        }
        onCommit={() => {
          if (isList) {
            // drop empty trailing lines on commit
            onUpdateText(el.id, { items: (el.items ?? []).filter((s) => s.trim() !== "") });
          }
          onEndEdit?.();
        }}
      />
    );
  }

  if (el.items && el.items.length && el.listStyle !== "none") {
    const ordered = el.listStyle === "number";
    const ListTag = ordered ? "ol" : "ul";
    return (
      <div style={common}>
        <ListTag
          style={{
            margin: 0,
            paddingLeft: 0,
            listStyle: "none",
            display: "flex",
            flexDirection: "column",
            gap: `${(el.fontSize ?? 24) * 0.5}px`,
          }}
        >
          {el.items.map((item, i) => (
            <li key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
              <span
                style={{
                  color: resolveColor("token:primary", theme, brand),
                  fontWeight: 800,
                  flexShrink: 0,
                  lineHeight: el.lineHeight ?? 1.3,
                }}
              >
                {ordered ? `${i + 1}.` : "•"}
              </span>
              <span>{item}</span>
            </li>
          ))}
        </ListTag>
      </div>
    );
  }

  return <div style={common}>{el.text}</div>;
}

function InlineTextEditor({
  el,
  isList,
  style,
  onChange,
  onCommit,
}: {
  el: TextElement;
  isList: boolean;
  style: React.CSSProperties;
  onChange: (value: string) => void;
  onCommit: () => void;
}) {
  const ref = useRef<HTMLTextAreaElement>(null);
  const [value, setValue] = useState(isList ? (el.items ?? []).join("\n") : el.text);

  useEffect(() => {
    const ta = ref.current;
    if (ta) {
      ta.focus();
      ta.select();
    }
  }, []);

  return (
    <textarea
      ref={ref}
      value={value}
      onChange={(e) => {
        setValue(e.target.value);
        onChange(e.target.value);
      }}
      onBlur={onCommit}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === "Escape") {
          e.preventDefault();
          onCommit();
        }
        // Plain (single-value) text commits on Enter; lists keep Enter for new items.
        if (e.key === "Enter" && !e.shiftKey && !isList) {
          e.preventDefault();
          onCommit();
        }
      }}
      onPointerDown={(e) => e.stopPropagation()}
      spellCheck={false}
      style={{
        width: "100%",
        height: "100%",
        margin: 0,
        padding: 0,
        border: "none",
        outline: "none",
        resize: "none",
        background: "transparent",
        color: style.color,
        fontFamily: style.fontFamily,
        fontSize: style.fontSize,
        fontWeight: style.fontWeight,
        fontStyle: style.fontStyle,
        textAlign: style.textAlign,
        lineHeight: style.lineHeight,
        letterSpacing: style.letterSpacing,
        overflow: "hidden",
      }}
    />
  );
}

function ShapeView({ el, theme, brand }: { el: ShapeElement; theme: Theme; brand: BrandKit }) {
  const background = el.gradient
    ? gradientCss(
        resolveColor(el.gradient[0], theme, brand),
        resolveColor(el.gradient[1], theme, brand),
        el.gradientAngle,
      )
    : resolveColor(el.fill, theme, brand, "transparent");

  const style: React.CSSProperties = {
    width: "100%",
    height: "100%",
    background,
    border: el.stroke
      ? `${el.strokeWidth ?? 2}px solid ${resolveColor(el.stroke, theme, brand)}`
      : undefined,
  };

  switch (el.shape) {
    case "ellipse":
      style.borderRadius = "50%";
      break;
    case "roundedRect":
      style.borderRadius = el.radius ?? 16;
      break;
    case "triangle":
      style.clipPath = "polygon(50% 0%, 0% 100%, 100% 100%)";
      break;
    case "trapezoid":
      style.clipPath = "polygon(18% 0%, 82% 0%, 100% 100%, 0% 100%)";
      break;
    case "blob":
      style.borderRadius = "42% 58% 70% 30% / 45% 45% 55% 55%";
      break;
    case "chevron":
      style.clipPath = "polygon(0% 0%, 75% 0%, 100% 50%, 75% 100%, 0% 100%, 25% 50%)";
      break;
    case "arrowRight":
      style.clipPath = "polygon(0% 25%, 60% 25%, 60% 0%, 100% 50%, 60% 100%, 60% 75%, 0% 75%)";
      break;
    case "hexagon":
      style.clipPath = "polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)";
      break;
    case "pentagon":
      style.clipPath = "polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)";
      break;
    case "diamond":
      style.clipPath = "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)";
      break;
    case "star":
      style.clipPath = "polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)";
      break;
    case "parallelogram":
      style.clipPath = "polygon(20% 0%, 100% 0%, 80% 100%, 0% 100%)";
      break;
    case "pill":
      style.borderRadius = 999;
      break;
    default:
      style.borderRadius = el.radius ?? 0;
  }

  return <div style={style} />;
}

function ChartView({ el, theme, brand }: { el: import("@/lib/types").ChartElement; theme: Theme; brand: BrandKit }) {
  const W = el.w;
  const H = el.h;
  const pal = (el.palette?.length ? el.palette : ["token:primary", "token:accent", "token:secondary", "token:textMuted"]).map((c) => resolveColor(c, theme, brand, "#6366F1"));
  const axis = resolveColor("token:textMuted", theme, brand, "#94A3B8");
  const txt = resolveColor("token:text", theme, brand, "#111827");
  const bg = resolveColor("token:surface", theme, brand, "#1A2238");
  const cats = el.categories ?? [];
  const series = el.series ?? [];
  const legendH = el.legend && series.length ? 24 : 0;
  const isRadial = el.chartType === "pie" || el.chartType === "donut";
  const isBar = el.chartType === "bar";

  const legend = legendH ? (
    <g>
      {series.map((s, j) => {
        const lw = Math.min(140, W / series.length);
        const lx = 8 + j * lw;
        return (
          <g key={j} transform={`translate(${lx}, 4)`}>
            <rect width={12} height={12} rx={2} fill={pal[j % pal.length]} />
            <text x={17} y={10} fontSize={11} fill={txt}>{s.name}</text>
          </g>
        );
      })}
    </g>
  ) : null;

  let body: React.ReactNode = null;

  if (isRadial) {
    const vals = (series[0]?.data ?? []).map((v) => Math.max(0, v));
    const total = vals.reduce((a, b) => a + b, 0) || 1;
    const cx = W / 2;
    const cy = legendH + (H - legendH) / 2;
    const r = Math.min(W, H - legendH) / 2 - 12;
    let a0 = -Math.PI / 2;
    const arcs = vals.map((v, i) => {
      const a1 = a0 + (v / total) * Math.PI * 2;
      const x0 = cx + r * Math.cos(a0), y0 = cy + r * Math.sin(a0);
      const x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
      const large = a1 - a0 > Math.PI ? 1 : 0;
      const d = `M ${cx} ${cy} L ${x0} ${y0} A ${r} ${r} 0 ${large} 1 ${x1} ${y1} Z`;
      a0 = a1;
      return <path key={i} d={d} fill={pal[i % pal.length]} />;
    });
    body = (
      <g>
        {arcs}
        {el.chartType === "donut" && <circle cx={cx} cy={cy} r={r * 0.58} fill={bg} />}
      </g>
    );
  } else {
    const padL = isBar ? 72 : 44;
    const padR = 14;
    const padT = legendH + 8;
    const padB = 30;
    const pw = W - padL - padR;
    const ph = H - padT - padB;
    const x0 = padL;
    const yBase = H - padB;
    const maxV = Math.max(1, ...series.flatMap((s) => s.data.map((v) => Math.max(0, v))));
    const n = cats.length || 1;

    const grid = [0, 0.5, 1].map((f, i) => {
      const gy = yBase - f * ph;
      return <line key={i} x1={x0} y1={gy} x2={x0 + pw} y2={gy} stroke={axis} strokeOpacity={0.18} strokeWidth={1} />;
    });

    if (isBar) {
      const rowH = ph / n;
      const bh = Math.min(rowH / (series.length + 0.4), 46);
      body = (
        <g>
          {grid}
          {cats.map((c, i) => (
            <text key={"l" + i} x={x0 - 8} y={padT + i * rowH + rowH / 2} fontSize={11} fill={axis} textAnchor="end" dominantBaseline="middle">{String(c).slice(0, 12)}</text>
          ))}
          {series.map((s, j) => s.data.map((v, i) => {
            const bw = (Math.max(0, v) / maxV) * pw;
            const y = padT + i * rowH + (rowH - bh * series.length) / 2 + j * bh;
            return <rect key={`${j}-${i}`} x={x0} y={y} width={Math.max(1, bw)} height={bh * 0.88} rx={3} fill={pal[j % pal.length]} />;
          }))}
        </g>
      );
    } else {
      const groupW = pw / n;
      const cx = (i: number) => x0 + (i + 0.5) * groupW;
      const cy = (v: number) => yBase - (Math.max(0, v) / maxV) * ph;
      body = (
        <g>
          {grid}
          <text x={x0 - 6} y={padT + 8} fontSize={10} fill={axis} textAnchor="end">{Math.round(maxV)}</text>
          {cats.map((c, i) => (
            <text key={"x" + i} x={cx(i)} y={yBase + 14} fontSize={11} fill={axis} textAnchor="middle">{String(c).slice(0, 10)}</text>
          ))}
          {el.chartType === "column" && series.map((s, j) => {
            const bw = Math.min(groupW / (series.length + 0.4), 64);
            return s.data.map((v, i) => {
              const h = (Math.max(0, v) / maxV) * ph;
              const bx = cx(i) - (bw * series.length) / 2 + j * bw;
              return <rect key={`${j}-${i}`} x={bx} y={yBase - h} width={bw * 0.86} height={Math.max(1, h)} rx={3} fill={pal[j % pal.length]} />;
            });
          })}
          {(el.chartType === "line" || el.chartType === "area") && series.map((s, j) => {
            const pts = s.data.map((v, i) => `${cx(i)},${cy(v)}`).join(" ");
            const col = pal[j % pal.length];
            return (
              <g key={j}>
                {el.chartType === "area" && <polygon points={`${x0},${yBase} ${pts} ${x0 + pw},${yBase}`} fill={col} fillOpacity={0.18} />}
                <polyline points={pts} fill="none" stroke={col} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />
                {s.data.map((v, i) => <circle key={i} cx={cx(i)} cy={cy(v)} r={3} fill={col} />)}
              </g>
            );
          })}
        </g>
      );
    }
  }

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" style={{ overflow: "visible" }}>
      {legend}
      {body}
    </svg>
  );
}

function IconView({ el, theme, brand }: { el: import("@/lib/types").IconElement; theme: Theme; brand: BrandKit }) {
  const name = el.name
    .split(/[-_ ]/)
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join("");
  const Comp = (Lucide as unknown as Record<string, React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>>)[name];
  if (!Comp) return null;
  return (
    <Comp
      size={Math.min(el.w, el.h)}
      color={resolveColor(el.color, theme, brand, theme.colors.primary)}
      strokeWidth={el.strokeWidth ?? 2}
    />
  );
}
