"use client";

import { cn } from "@/lib/utils";

export function Button({
  className,
  variant = "primary",
  size = "md",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "outline" | "subtle";
  size?: "sm" | "md" | "lg";
}) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-all disabled:opacity-50 disabled:pointer-events-none focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400/60",
        size === "sm" && "h-8 px-3 text-sm",
        size === "md" && "h-10 px-4 text-sm",
        size === "lg" && "h-12 px-6 text-base",
        variant === "primary" &&
          "bg-indigo-500 text-white hover:bg-indigo-400 shadow-lg shadow-indigo-500/20",
        variant === "outline" &&
          "border border-[var(--app-border)] text-[var(--app-text)] hover:bg-[var(--app-hover)]",
        variant === "ghost" && "text-[var(--app-text)] hover:bg-[var(--app-hover)]",
        variant === "subtle" && "bg-[var(--app-hover)] text-[var(--app-text)] hover:bg-[var(--app-hover)]",
        className,
      )}
      {...props}
    />
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-[var(--app-muted)]">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-[var(--app-muted)]">{hint}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-lg bg-[var(--app-elev)] border border-[var(--app-border)] px-3 py-2 text-sm text-[var(--app-text)] placeholder:text-[var(--app-faint)] focus:outline-none focus:border-indigo-400/70 focus:ring-1 focus:ring-indigo-400/40";

export function Modal({
  open,
  onClose,
  children,
  width = 560,
}: {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  width?: number;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
      onMouseDown={onClose}
    >
      <div
        className="fade-up w-full rounded-2xl border border-[var(--app-border)] bg-[var(--app-panel)] shadow-2xl"
        style={{ maxWidth: width }}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}
