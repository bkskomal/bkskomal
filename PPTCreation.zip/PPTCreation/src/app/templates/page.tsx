"use client";

import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Loader2, MessageSquare, Search, Sparkles, Upload, Wand2 } from "lucide-react";
import { TEMPLATE_CATEGORIES, TEMPLATES } from "@/lib/templates";
import { TemplateCard } from "@/components/gallery/TemplateCard";
import { CreateDialog } from "@/components/gallery/CreateDialog";
import { MyDecks } from "@/components/gallery/MyDecks";
import { MyTemplates } from "@/components/gallery/MyTemplates";
import { importDeckFromPptx } from "@/lib/export-hd";
import { clearHistory, useEditor } from "@/lib/store";
import { toast } from "@/lib/toast";
import type { Template, TemplateCategory } from "@/lib/types";

export default function GalleryPage() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<TemplateCategory | "All">("All");
  const [picked, setPicked] = useState<Template | null>(null);
  const [importing, setImporting] = useState(false);
  const importRef = useRef<HTMLInputElement>(null);

  async function onImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setImporting(true);
    try {
      const deck = await importDeckFromPptx(file);
      useEditor.getState().setDeck(deck);
      clearHistory();
      const n = deck.slides.length;
      toast.success(`Imported ${n} slide${n === 1 ? "" : "s"} — now editable`);
      router.push("/editor");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Import failed");
    } finally {
      setImporting(false);
    }
  }

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return TEMPLATES.filter((t) => {
      if (cat !== "All" && t.category !== cat) return false;
      if (!q) return true;
      return (
        t.name.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.tags.some((tag) => tag.includes(q)) ||
        t.category.toLowerCase().includes(q)
      );
    });
  }, [query, cat]);

  return (
    <div data-theme="dark" className="flex-1 bg-[var(--app-bg)] text-[var(--app-text)]">
      <header className="border-b border-[var(--app-border)] bg-gradient-to-b from-indigo-500/10 to-transparent">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <Link href="/" className="mb-4 inline-flex items-center gap-1.5 text-sm text-zinc-400 hover:text-zinc-100">
            <ArrowLeft size={15} /> Assistant
          </Link>
          <div className="flex items-center gap-2 text-indigo-300 text-sm font-medium">
            <Sparkles size={16} /> Powered by GPT-OSS-120B
          </div>
          <h1 className="mt-3 text-4xl md:text-5xl font-extrabold tracking-tight">
            Beautiful presentations,
            <span className="bg-gradient-to-r from-indigo-400 to-fuchsia-400 bg-clip-text text-transparent"> in minutes.</span>
          </h1>
          <p className="mt-3 max-w-2xl text-zinc-400">
            Pick one of {TEMPLATES.length} world-class templates, or just{" "}
            <Link href="/" className="text-indigo-300 underline">ask the assistant</Link> to build one for you.
          </p>

          <div className="mt-6 flex max-w-2xl flex-col gap-2 sm:flex-row sm:items-center">
            <div className="flex flex-1 items-center gap-2 rounded-xl border border-[var(--app-border)] bg-[var(--app-panel)] px-3">
              <Search size={18} className="text-zinc-500" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search templates — pitch, dark, minimal, marketing…"
                className="h-12 flex-1 bg-transparent text-sm outline-none placeholder:text-zinc-600"
              />
            </div>
            <Link
              href="/"
              className="inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-lg bg-indigo-500 px-6 text-sm font-medium text-white hover:bg-indigo-400"
            >
              <MessageSquare size={18} /> Build with AI chat
            </Link>
            <button
              onClick={() => importRef.current?.click()}
              disabled={importing}
              className="inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-lg border border-[var(--app-border)] bg-[var(--app-panel)] px-5 text-sm font-medium text-zinc-200 hover:bg-white/5 disabled:opacity-50"
            >
              {importing ? <Loader2 size={18} className="animate-spin" /> : <Upload size={18} />} Import PowerPoint
            </button>
            <input ref={importRef} type="file" accept=".pptx" className="hidden" onChange={onImport} />
          </div>
        </div>
      </header>

      <div className="sticky top-0 z-10 border-b border-[var(--app-border)] bg-[#0a0b0f]/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-6 py-3">
          {(["All", ...TEMPLATE_CATEGORIES] as const).map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-sm font-medium transition ${
                cat === c ? "bg-indigo-500 text-white" : "bg-white/5 text-zinc-400 hover:text-zinc-200"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <MyTemplates />
      <MyDecks />

      <main className="mx-auto max-w-7xl px-6 py-8">
        <h2 className="mb-4 text-lg font-semibold text-zinc-200">Start from a template</h2>
        {filtered.length === 0 ? (
          <div className="py-24 text-center text-zinc-500">
            <Wand2 className="mx-auto mb-3" />
            No templates match “{query}”. Try a different search.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((t) => (
              <TemplateCard key={t.id} template={t} onPick={setPicked} />
            ))}
          </div>
        )}
      </main>

      <CreateDialog template={picked} onClose={() => setPicked(null)} />
    </div>
  );
}
