"use client";

import { useEffect, useState } from "react";
import { SlideView } from "@/components/SlideView";
import { useEditor } from "@/lib/store";

/**
 * Print-optimized view: one slide per landscape page. Users pick "Save as PDF"
 * in the browser print dialog. Auto-opens print once mounted.
 */
export default function PrintPage() {
  const deck = useEditor((s) => s.deck);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (mounted && deck) {
      const t = setTimeout(() => window.print(), 600);
      return () => clearTimeout(t);
    }
  }, [mounted, deck]);

  if (!mounted) return null;
  if (!deck) return <div className="p-10 text-zinc-400">No deck to print.</div>;

  return (
    <div className="bg-white">
      <style>{`
        @page { size: 1280px 720px; margin: 0; }
        @media print {
          html, body { background: #fff; }
          .slide-page { page-break-after: always; break-after: page; }
        }
      `}</style>
      {deck.slides.map((slide, i) => (
        <div key={slide.id} className="slide-page" style={{ width: 1280, height: 720 }}>
          <SlideView
            slide={slide}
            theme={deck.theme}
            brand={deck.brand}
            pageIndex={i}
            pageCount={deck.slides.length}
            width={1280}
          />
        </div>
      ))}
    </div>
  );
}
