"use client";

import { use, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Loader2, Presentation } from "lucide-react";
import { SlideView } from "@/components/SlideView";
import type { Deck } from "@/lib/types";

/** Public, read-only viewer for a shared deck (no auth). */
export default function SharePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params);
  const [deck, setDeck] = useState<Deck | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [i, setI] = useState(0);
  const [w, setW] = useState(1000);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch(`/api/share/${token}`)
      .then((r) => r.json())
      .then((d) => (d.deck ? setDeck(d.deck as Deck) : setError(d.error ?? "Not found")))
      .catch(() => setError("Couldn't load this presentation."));
  }, [token]);

  useEffect(() => {
    function fit() {
      const cw = wrap.current?.clientWidth ?? window.innerWidth;
      setW(Math.min(cw, (window.innerHeight - 120) * (16 / 9)));
    }
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, [deck]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!deck) return;
      if (e.key === "ArrowRight" || e.key === " ") setI((p) => Math.min(p + 1, deck.slides.length - 1));
      if (e.key === "ArrowLeft") setI((p) => Math.max(p - 1, 0));
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [deck]);

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-[#0a0b0f] text-zinc-400">
        <Presentation size={28} />
        <p>{error}</p>
      </div>
    );
  }
  if (!deck) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0a0b0f] text-zinc-400">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  const slide = deck.slides[i];
  return (
    <div className="flex min-h-screen flex-col bg-[#0a0b0f]">
      <header className="flex items-center justify-between border-b border-white/10 px-5 py-3">
        <div className="flex items-center gap-2 text-sm font-medium text-zinc-200">
          <Presentation size={16} className="text-indigo-400" /> {deck.title}
        </div>
        <span className="text-xs text-zinc-500">Shared presentation · read-only</span>
      </header>
      <main ref={wrap} className="flex flex-1 flex-col items-center justify-center gap-4 p-6">
        <div className="overflow-hidden rounded-xl shadow-2xl ring-1 ring-white/10">
          <SlideView slide={slide} theme={deck.theme} brand={deck.brand} pageIndex={i} pageCount={deck.slides.length} width={w} />
        </div>
        <div className="flex items-center gap-4 rounded-full bg-white/10 px-4 py-2 text-white/80">
          <button onClick={() => setI((p) => Math.max(p - 1, 0))} disabled={i === 0} className="disabled:opacity-30">
            <ChevronLeft />
          </button>
          <span className="text-sm tabular-nums">{i + 1} / {deck.slides.length}</span>
          <button onClick={() => setI((p) => Math.min(p + 1, deck.slides.length - 1))} disabled={i === deck.slides.length - 1} className="disabled:opacity-30">
            <ChevronRight />
          </button>
        </div>
      </main>
    </div>
  );
}
