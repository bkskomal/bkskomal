"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Canvas } from "@/components/editor/Canvas";
import { ChatPanel } from "@/components/editor/ChatPanel";
import { Inspector } from "@/components/editor/Inspector";
import { SlideList } from "@/components/editor/SlideList";
import { Toolbar } from "@/components/editor/Toolbar";
import { Topbar } from "@/components/editor/Topbar";
import { useShortcuts } from "@/components/editor/useShortcuts";
import { AuthGate } from "@/components/auth/AuthGate";
import { Button } from "@/components/ui";
import { useEditor } from "@/lib/store";
import { useLibrary } from "@/lib/library";

export default function EditorPage() {
  return (
    <AuthGate>
      <Editor />
    </AuthGate>
  );
}

function Editor() {
  const deck = useEditor((s) => s.deck);
  const upsert = useLibrary((s) => s.upsert);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  useShortcuts();

  // Autosave the active deck into the library (debounced).
  useEffect(() => {
    if (!deck) return;
    const t = setTimeout(() => upsert(deck), 600);
    return () => clearTimeout(t);
  }, [deck, upsert]);

  if (!mounted) return null;

  if (!deck) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center">
        <p className="text-zinc-400">No presentation open yet.</p>
        <Link href="/">
          <Button>Back to assistant</Button>
        </Link>
      </div>
    );
  }

  return (
    <div data-theme="dark" className="flex flex-1 flex-col overflow-hidden bg-[var(--app-bg)] text-[var(--app-text)]">
      <Topbar />
      <div className="flex flex-1 overflow-hidden">
        <SlideList />
        <div className="flex flex-1 flex-col overflow-hidden">
          <Toolbar />
          <Canvas />
        </div>
        <Inspector />
        <ChatPanel />
      </div>
    </div>
  );
}
