"use client";

import { AuthGate } from "@/components/auth/AuthGate";
import { AssistantApp } from "@/components/assistant/AssistantApp";

export default function Home() {
  return (
    <AuthGate>
      <AssistantApp />
    </AuthGate>
  );
}
