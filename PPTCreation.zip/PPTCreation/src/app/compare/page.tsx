"use client";

import { AuthGate } from "@/components/auth/AuthGate";
import { CompareApp } from "@/components/compare/CompareApp";

export default function ComparePage() {
  return (
    <AuthGate>
      <CompareApp />
    </AuthGate>
  );
}
