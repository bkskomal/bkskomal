import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { Toaster } from "@/components/Toaster";
import { ThemeApplier } from "@/components/ThemeApplier";
import "./globals.css";

const inter = Inter({ variable: "--font-ui", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "OATIGenie — your multi-skill AI assistant",
  description:
    "Chat with OATIGenie to build beautiful presentations (and more skills soon), powered by GPT-OSS-120B.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${inter.variable} h-full antialiased`}>
      <head>
        {/* Template fonts — loaded by literal family name so slides render true-to-export. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700;800&family=Sora:wght@400;600;700;800&family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,800;1,500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-full flex flex-col bg-[var(--app-bg)] text-[var(--app-text)]">
        <ThemeApplier />
        {children}
        <Toaster />
      </body>
    </html>
  );
}
