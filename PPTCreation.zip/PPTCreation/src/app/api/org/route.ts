import { NextResponse } from "next/server";
import { DEFAULT_ORG, getOrg, sanitizeOrg, saveOrg, type OrgConfig } from "@/lib/orgConfig";

export const runtime = "nodejs";

/** GET → org governance for clients. `?admin=1` returns the full config (Super Admin UI). */
export async function GET(req: Request) {
  const admin = new URL(req.url).searchParams.get("admin") === "1";
  const org = await getOrg();
  return NextResponse.json({ org: admin ? org : sanitizeOrg(org) });
}

/** PUT → replace org config (Super Admin). Demo-grade: trusts the client's admin flag. */
export async function PUT(req: Request) {
  const body = await req.json().catch(() => ({}));
  if (!body?.isSuperAdmin) return NextResponse.json({ error: "Super Admin required." }, { status: 403 });
  const config: OrgConfig = { ...DEFAULT_ORG, ...(body.config ?? {}) };
  const ok = await saveOrg(config);
  if (!ok) return NextResponse.json({ error: "Governance store unavailable (Postgres not reachable)." }, { status: 503 });
  return NextResponse.json({ ok: true, org: sanitizeOrg(config) });
}
