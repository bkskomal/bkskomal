import { NextResponse } from "next/server";
import { dbEnabled, withDb } from "@/lib/db";
import { savePreference } from "@/lib/persist";

export const runtime = "nodejs";

/** GET → export preference pairs (DPO/LoRA training data). */
export async function GET() {
  const rows = await withDb(
    async (p) => (await p.query("SELECT prompt, rejected, chosen, model FROM preference_pairs ORDER BY created_at")).rows,
    [],
  );
  return NextResponse.json({ persisted: dbEnabled(), preferences: rows });
}

/** Store a (prompt, rejected, chosen) preference pair — DPO/LoRA training data. */
export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  const { userId = "", prompt = "", rejected = "", chosen = "", model = "" } = b ?? {};
  if (!prompt || !chosen) return NextResponse.json({ error: "prompt and chosen required" }, { status: 400 });
  await savePreference({ userId, prompt, rejected, chosen, model });
  return NextResponse.json({ ok: true, persisted: dbEnabled() });
}
