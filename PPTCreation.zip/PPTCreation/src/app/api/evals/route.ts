import { NextResponse } from "next/server";
import { dbEnabled } from "@/lib/db";
import { latestEvalRun, listEvals, saveEval } from "@/lib/persist";

export const runtime = "nodejs";

/** GET → list eval cases + the latest judged run (for the runner + admin dashboard). */
export async function GET() {
  return NextResponse.json({ persisted: dbEnabled(), evals: await listEvals(), latestRun: await latestEvalRun() });
}

/** POST → add an eval case (an exchange the assistant should reproduce well). */
export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  const { userId = "", skill = "chat", prompt = "", expected = "" } = b ?? {};
  if (!prompt) return NextResponse.json({ error: "prompt required" }, { status: 400 });
  await saveEval({ userId, skill, prompt, expected });
  return NextResponse.json({ ok: true, persisted: dbEnabled() });
}
