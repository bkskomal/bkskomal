import { NextResponse } from "next/server";
import { assistantOnce, judgeAnswer } from "@/lib/ai";
import { listEvals, saveEvalRun, type EvalResult } from "@/lib/persist";
import { newId } from "@/lib/layouts";

export const runtime = "nodejs";
export const maxDuration = 300;

/**
 * Run the full eval suite: replay each saved case through the assistant, judge
 * the reply with the LLM-as-judge, aggregate a pass-rate, and persist the run.
 */
export async function POST(req: Request) {
  const { model } = await req.json().catch(() => ({}));
  const cases = await listEvals();
  if (!cases.length) return NextResponse.json({ error: "No eval cases yet. Save some first (👍 → Save as eval case)." }, { status: 400 });

  const results: EvalResult[] = [];
  for (const c of cases) {
    let reply = "";
    try {
      reply = await assistantOnce(c.prompt, model);
    } catch (e) {
      reply = `(assistant error: ${e instanceof Error ? e.message : "unknown"})`;
    }
    const j = await judgeAnswer({ prompt: c.prompt, answer: reply, reference: c.expected || undefined }, model);
    results.push({ evalId: c.id, prompt: c.prompt, score: j.score, pass: j.pass, reason: j.reason, reply });
  }

  const passed = results.filter((r) => r.pass).length;
  const avgScore = Math.round(results.reduce((a, r) => a + r.score, 0) / results.length);
  const run = { id: newId(), total: results.length, passed, avgScore, model: model?.model ?? "default" };
  await saveEvalRun(run, results);

  return NextResponse.json({ run, results });
}
