import { NextResponse } from "next/server";
import { regenerateSlide } from "@/lib/ai";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body?.current?.layout || !body?.current?.title) {
      return NextResponse.json({ error: "Missing 'current' slide." }, { status: 400 });
    }
    const slide = await regenerateSlide({
      current: body.current,
      deckTitle: body.deckTitle,
      layout: body.layout,
      instruction: body.instruction,
    });
    return NextResponse.json({ slide });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Regenerate failed";
    const hint = /ECONNREFUSED|fetch failed|self-signed|certificate/i.test(message)
      ? "Could not reach the model server (check OPENAI_BASE_URL / AI_TLS_INSECURE)."
      : undefined;
    return NextResponse.json({ error: message, hint }, { status: 500 });
  }
}
