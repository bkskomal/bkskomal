import { NextResponse } from "next/server";
import { chatTurn, chatTurnStream, type ChatMessage } from "@/lib/ai";

export const runtime = "nodejs";
export const maxDuration = 90;

function hintFor(message: string): string | undefined {
  return /ECONNREFUSED|fetch failed|self-signed|certificate/i.test(message)
    ? "Could not reach the model server (check OPENAI_BASE_URL / AI_TLS_INSECURE)."
    : undefined;
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const messages: ChatMessage[] = Array.isArray(body?.messages) ? body.messages : [];
  if (messages.length === 0) {
    return NextResponse.json({ error: "No messages." }, { status: 400 });
  }
  const deckSummary = String(body?.deckSummary ?? "No deck open yet.");

  // --- streaming (SSE): reply text streams, then a final structured event ---
  if (body?.stream) {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        const send = (obj: unknown) => controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
        try {
          const result = await chatTurnStream(messages, deckSummary, (text) => send({ type: "delta", text }), body?.model);
          send({ type: "final", result });
        } catch (err) {
          const message = err instanceof Error ? err.message : "Chat failed";
          send({ type: "error", error: message, hint: hintFor(message) });
        } finally {
          controller.close();
        }
      },
    });
    return new Response(stream, {
      headers: { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform" },
    });
  }

  // --- non-streaming JSON (used by tests / simple callers) ---
  try {
    const result = await chatTurn(messages, deckSummary, body?.model);
    return NextResponse.json(result);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Chat failed";
    return NextResponse.json({ error: message, hint: hintFor(message) }, { status: 500 });
  }
}
