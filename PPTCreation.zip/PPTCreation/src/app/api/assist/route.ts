import { NextResponse } from "next/server";
import { assistText, type AssistTask } from "@/lib/ai";

export const runtime = "nodejs";
export const maxDuration = 60;

const TASKS: AssistTask[] = ["improve", "shorten", "expand", "fix", "notes"];

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!TASKS.includes(body?.task)) {
      return NextResponse.json({ error: "Invalid 'task'." }, { status: 400 });
    }
    const result = await assistText({
      task: body.task,
      text: body.text,
      items: body.items,
      context: body.context,
    });
    return NextResponse.json({ result });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Assist failed";
    const hint = /401|403|unauthorized/i.test(message)
      ? "Set a valid OPENAI_API_KEY in .env.local."
      : /ECONNREFUSED|fetch failed|self-signed|certificate/i.test(message)
        ? "Could not reach the model server (check OPENAI_BASE_URL / AI_TLS_INSECURE)."
        : undefined;
    return NextResponse.json({ error: message, hint }, { status: 500 });
  }
}
