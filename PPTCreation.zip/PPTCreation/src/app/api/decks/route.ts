import { NextResponse } from "next/server";
import { listDecks, saveDeck } from "@/lib/cloudDecks";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const userId = new URL(req.url).searchParams.get("userId") ?? "";
  if (!userId) return NextResponse.json({ decks: [] });
  return NextResponse.json({ decks: await listDecks(userId) });
}

export async function POST(req: Request) {
  const { userId, deck } = await req.json();
  if (!userId || !deck) return NextResponse.json({ error: "userId and deck required" }, { status: 400 });
  const res = await saveDeck(userId, deck);
  if (!res.ok) return NextResponse.json({ error: "Cloud save unavailable (Postgres not reachable).", id: res.id }, { status: 503 });
  return NextResponse.json(res);
}
