import { NextResponse } from "next/server";
import { shareDeck, unshareDeck } from "@/lib/cloudDecks";

export const runtime = "nodejs";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { userId } = await req.json();
  const token = await shareDeck(userId ?? "", id);
  if (!token) return NextResponse.json({ error: "Couldn't create a share link (save the deck to the cloud first)." }, { status: 400 });
  return NextResponse.json({ token });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const userId = new URL(req.url).searchParams.get("userId") ?? "";
  return NextResponse.json({ ok: await unshareDeck(userId, id) });
}
