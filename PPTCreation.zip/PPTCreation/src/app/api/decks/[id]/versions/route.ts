import { NextResponse } from "next/server";
import { listVersions, restoreVersion } from "@/lib/cloudDecks";

export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const userId = new URL(req.url).searchParams.get("userId") ?? "";
  return NextResponse.json({ versions: await listVersions(userId, id) });
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { userId, versionId } = await req.json();
  const deck = await restoreVersion(userId ?? "", id, versionId);
  if (!deck) return NextResponse.json({ error: "restore failed" }, { status: 400 });
  return NextResponse.json({ deck });
}
