import { NextResponse } from "next/server";
import { deleteDeck, getDeck } from "@/lib/cloudDecks";

export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const userId = new URL(req.url).searchParams.get("userId") ?? "";
  const deck = await getDeck(userId, id);
  if (!deck) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json({ deck });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const userId = new URL(req.url).searchParams.get("userId") ?? "";
  return NextResponse.json({ ok: await deleteDeck(userId, id) });
}
