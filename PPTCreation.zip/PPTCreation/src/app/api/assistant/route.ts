import { assistantStream, type ChatMessage } from "@/lib/ai";
import { exemplarBlock, retrieveExemplars } from "@/lib/rag";
import { saveTurn } from "@/lib/persist";

export const runtime = "nodejs";
export const maxDuration = 90;

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const messages: ChatMessage[] = Array.isArray(body?.messages) ? body.messages : [];
  if (messages.length === 0) {
    return new Response(JSON.stringify({ error: "No messages." }), { status: 400 });
  }

  // Exemplar RAG: pull past highly-rated answers for this query and steer with them.
  const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
  const augment = body?.ragEnabled === false ? "" : exemplarBlock(await retrieveExemplars(lastUser, body?.ragTopK ?? 3, body?.embed));

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) => controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
      try {
        const result = await assistantStream(messages, (text) => send({ type: "delta", text }), body?.model, augment);
        send({ type: "final", result });
        // persist the turn for history + training data (no-op if DB off)
        saveTurn({
          userId: body?.userId ?? "",
          convId: body?.convId,
          userMessage: lastUser,
          assistantMessage: result.reply,
          model: body?.model?.model ?? "GPT-OSS-120B",
        }).catch(() => {});
      } catch (err) {
        const message = err instanceof Error ? err.message : "Assistant failed";
        const hint = /ECONNREFUSED|fetch failed|self-signed|certificate/i.test(message)
          ? "Could not reach the model server (check OPENAI_BASE_URL / AI_TLS_INSECURE)."
          : undefined;
        send({ type: "error", error: message, hint });
      } finally {
        controller.close();
      }
    },
  });
  return new Response(stream, {
    headers: { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform" },
  });
}
