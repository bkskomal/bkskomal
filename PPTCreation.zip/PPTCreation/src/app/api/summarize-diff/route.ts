import { NextResponse } from "next/server";
import { summarizeChanges } from "@/lib/ai";

export const runtime = "nodejs";
export const maxDuration = 60;

/** POST { diff, model? } -> { summary } — an AI, context-aware explanation of the changes. */
export async function POST(req: Request) {
  try {
    const { diff, model } = await req.json();
    if (!diff || typeof diff !== "string") return NextResponse.json({ error: "diff required" }, { status: 400 });
    const summary = await summarizeChanges(diff, model);
    return NextResponse.json({ summary });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Summarize failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
