import { NextResponse } from "next/server";
import { getSharedDeck } from "@/lib/cloudDecks";

export const runtime = "nodejs";

export async function GET(_req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const deck = await getSharedDeck(token);
  if (!deck) return NextResponse.json({ error: "This shared presentation was not found or is no longer public." }, { status: 404 });
  return NextResponse.json({ deck });
}
