import { NextResponse } from "next/server";

export const runtime = "nodejs";

export interface StockImage {
  url: string; // full-size, usable in the slide
  thumb: string; // small preview for the grid
  alt: string;
  credit?: string;
  link?: string;
}

/**
 * Stock image search. Provider is chosen in Settings (admin); Picsum is the
 * keyless default so the feature works out of the box (it returns tasteful
 * photos seeded by the query — not query-relevant, but immediately usable).
 * Unsplash / Pexels give real query-relevant results when an API key is set.
 */
export async function POST(req: Request) {
  try {
    const { query, provider = "picsum", apiKey, count = 12 } = await req.json();
    const q = String(query ?? "").trim() || "abstract";

    if (provider === "unsplash" && apiKey) {
      const r = await fetch(`https://api.unsplash.com/search/photos?query=${encodeURIComponent(q)}&per_page=${count}&client_id=${apiKey}`);
      if (!r.ok) throw new Error(`Unsplash ${r.status}`);
      const data = await r.json();
      const images: StockImage[] = (data.results ?? []).map((p: Record<string, unknown>) => {
        const urls = p.urls as Record<string, string>;
        const user = p.user as Record<string, string> | undefined;
        return { url: urls.regular, thumb: urls.small, alt: (p.alt_description as string) || q, credit: user?.name, link: (p.links as Record<string, string>)?.html };
      });
      return NextResponse.json({ images, provider });
    }

    if (provider === "pexels" && apiKey) {
      const r = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(q)}&per_page=${count}`, { headers: { Authorization: apiKey } });
      if (!r.ok) throw new Error(`Pexels ${r.status}`);
      const data = await r.json();
      const images: StockImage[] = (data.photos ?? []).map((p: Record<string, unknown>) => {
        const src = p.src as Record<string, string>;
        return { url: src.large, thumb: src.medium, alt: (p.alt as string) || q, credit: p.photographer as string, link: p.url as string };
      });
      return NextResponse.json({ images, provider });
    }

    // Keyless Picsum fallback — deterministic, seeded by the query so results are stable.
    const seed = encodeURIComponent(q.toLowerCase().replace(/\s+/g, "-"));
    const images: StockImage[] = Array.from({ length: count }, (_, i) => ({
      url: `https://picsum.photos/seed/${seed}-${i}/1200/800`,
      thumb: `https://picsum.photos/seed/${seed}-${i}/300/200`,
      alt: q,
      credit: "Lorem Picsum",
      link: "https://picsum.photos",
    }));
    return NextResponse.json({ images, provider: "picsum" });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Image search failed";
    return NextResponse.json({ error: message, hint: "Check the stock provider + API key in Settings → Platform." }, { status: 500 });
  }
}
