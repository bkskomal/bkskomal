import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 120;

/**
 * AI image generation via any OpenAI-compatible images endpoint (configured in
 * Settings → Platform). Returns a data URL so the image embeds into the deck and
 * survives export without a live host. Degrades with a clear message when unset.
 */
export async function POST(req: Request) {
  try {
    const { prompt, baseUrl, model, apiKey, size = "1024x1024" } = await req.json();
    const p = String(prompt ?? "").trim();
    if (!p) return NextResponse.json({ error: "Missing 'prompt'." }, { status: 400 });
    if (!baseUrl) {
      return NextResponse.json(
        { error: "Image generation isn't configured.", hint: "Add an OpenAI-compatible images endpoint in Settings → Platform → Imagery." },
        { status: 400 },
      );
    }

    const res = await fetch(`${String(baseUrl).replace(/\/$/, "")}/images/generations`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}) },
      body: JSON.stringify({ model: model || "gpt-image-1", prompt: p, size, response_format: "b64_json", n: 1 }),
    });
    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      throw new Error(`Image endpoint ${res.status}${detail ? `: ${detail.slice(0, 200)}` : ""}`);
    }
    const data = await res.json();
    const item = data?.data?.[0] ?? {};
    const url = item.b64_json ? `data:image/png;base64,${item.b64_json}` : item.url;
    if (!url) throw new Error("Image endpoint returned no image.");
    return NextResponse.json({ url });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Image generation failed";
    return NextResponse.json({ error: message, hint: "Check the images endpoint / model in Settings → Platform." }, { status: 500 });
  }
}
