import { NextResponse } from "next/server";
import { getOrg } from "@/lib/orgConfig";

export const runtime = "nodejs";

/**
 * Begin an OIDC (authorization-code) sign-in. Builds the IdP authorize URL from
 * the org SSO config. Returns a clear message when SSO isn't fully configured.
 * (The /callback exchange completes the flow in production.)
 */
export async function POST(req: Request) {
  const org = await getOrg();
  const sso = org.sso;
  if (!sso.enabled) return NextResponse.json({ error: "SSO is not enabled." }, { status: 400 });
  if (!sso.issuer || !sso.clientId) {
    return NextResponse.json({ error: "SSO isn't fully configured (issuer + client ID required in Settings → Organization)." }, { status: 400 });
  }
  try {
    // discover the authorization endpoint from the issuer's OIDC metadata
    const base = sso.issuer.replace(/\/$/, "");
    const wellKnown = base.endsWith("/openid-configuration") ? base : `${base}/.well-known/openid-configuration`;
    const meta = await fetch(wellKnown).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    const authEndpoint = meta?.authorization_endpoint as string | undefined;
    if (!authEndpoint) return NextResponse.json({ error: "Couldn't reach the identity provider's OIDC metadata." }, { status: 502 });

    const origin = new URL(req.url).origin;
    const params = new URLSearchParams({
      response_type: "code",
      client_id: sso.clientId,
      redirect_uri: `${origin}/api/auth/sso/callback`,
      scope: "openid email profile",
      state: Math.random().toString(36).slice(2),
    });
    return NextResponse.json({ authorizeUrl: `${authEndpoint}?${params.toString()}`, provider: sso.provider });
  } catch (e) {
    return NextResponse.json({ error: `SSO start failed: ${e instanceof Error ? e.message : "unknown"}` }, { status: 500 });
  }
}
