import { NextResponse } from "next/server";
import { generateDeck } from "@/lib/ai";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body?.prompt || typeof body.prompt !== "string") {
      return NextResponse.json({ error: "Missing 'prompt'." }, { status: 400 });
    }
    const { deck, source } = await generateDeck(
      {
        prompt: body.prompt,
        slideCount: body.slideCount,
        audience: body.audience,
        tone: body.tone,
        outline: typeof body.outline === "string" ? body.outline : undefined,
      },
      body.model,
    );
    return NextResponse.json({ deck, source });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Generation failed";
    // Surface a friendly hint for the common misconfigurations.
    let hint: string | undefined;
    if (/ECONNREFUSED|fetch failed|ENOTFOUND/i.test(message))
      hint = "Could not reach the model server. Check OPENAI_BASE_URL / AI_MODEL in your .env.local.";
    else if (/401|403|unauthorized|forbidden|api key/i.test(message))
      hint = "The endpoint rejected the request — set a valid OPENAI_API_KEY in your .env.local.";
    else if (/404|not found|model/i.test(message))
      hint = "Model not found at this endpoint. Check AI_MODEL matches a model the server serves.";
    return NextResponse.json({ error: message, hint }, { status: 500 });
  }
}
