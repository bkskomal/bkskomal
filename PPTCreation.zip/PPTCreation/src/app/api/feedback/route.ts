import { NextResponse } from "next/server";
import { newId } from "@/lib/layouts";
import { dbEnabled, withDb } from "@/lib/db";
import { retrieveExemplars, saveExemplar } from "@/lib/rag";
import { trainingCounts } from "@/lib/persist";

export const runtime = "nodejs";

/** GET /api/feedback?probe=<query> — counts + a retrieval probe, to verify the RAG loop. */
export async function GET(req: Request) {
  const probe = new URL(req.url).searchParams.get("probe") ?? "";
  const counts = await withDb(async (p) => {
    const fb = await p.query("SELECT count(*)::int AS n FROM feedback");
    const ex = await p.query("SELECT count(*)::int AS n FROM exemplars");
    return { feedback: fb.rows[0].n as number, exemplars: ex.rows[0].n as number };
  }, { feedback: 0, exemplars: 0 });
  const eb = new URL(req.url).searchParams.get("eb");
  const em = new URL(req.url).searchParams.get("em");
  const ov = eb && em ? { baseUrl: eb, model: em } : undefined;
  const retrieved = probe ? await retrieveExemplars(probe, 3, ov) : [];
  const training = await trainingCounts();
  return NextResponse.json({ persisted: dbEnabled(), ...counts, training, retrieved });
}

export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  const { userId = "", convId, rating, model = "", prompt = "", answer = "", reason, skill = "chat" } = b ?? {};
  if (rating !== "up" && rating !== "down") {
    return NextResponse.json({ error: "rating must be up|down" }, { status: 400 });
  }

  // store the feedback row (no-op if DB not configured)
  await withDb(async (p) => {
    await p.query(
      `INSERT INTO feedback (id, user_id, conv_id, rating, model, prompt, answer, reason)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [newId(), userId, convId ?? null, rating, model, prompt, answer, reason ?? null],
    );
    return true;
  }, undefined);

  // 👍 → becomes a retrievable exemplar for future RAG
  if (rating === "up") await saveExemplar({ userId, skill, prompt, answer }, b?.embed);

  return NextResponse.json({ ok: true, persisted: dbEnabled() });
}
