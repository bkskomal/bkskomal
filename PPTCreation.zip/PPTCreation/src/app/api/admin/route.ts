import { NextResponse } from "next/server";
import { dbEnabled, withDb } from "@/lib/db";

export const runtime = "nodejs";

/** Admin maintenance actions (UI is Super-Admin gated). */
export async function POST(req: Request) {
  const { action } = await req.json().catch(() => ({}));
  if (action === "clear-exemplars") {
    await withDb(async (p) => (await p.query("TRUNCATE exemplars"), true), undefined);
    return NextResponse.json({ ok: true, persisted: dbEnabled() });
  }
  if (action === "clear-feedback") {
    await withDb(async (p) => (await p.query("TRUNCATE feedback"), true), undefined);
    return NextResponse.json({ ok: true, persisted: dbEnabled() });
  }
  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}
