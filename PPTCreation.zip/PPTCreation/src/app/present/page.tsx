"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { SlideView } from "@/components/SlideView";
import { useEditor } from "@/lib/store";

export default function PresentPage() {
  const router = useRouter();
  const deck = useEditor((s) => s.deck);
  const [i, setI] = useState(0);
  const [w, setW] = useState(1280);
  const ref = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    function fit() {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      setW(Math.min(vw, vh * (16 / 9)));
    }
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!deck) return;
      if (e.key === "ArrowRight" || e.key === " ") setI((p) => Math.min(p + 1, deck.slides.length - 1));
      if (e.key === "ArrowLeft") setI((p) => Math.max(p - 1, 0));
      if (e.key === "Escape") router.push("/editor");
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [deck, router]);

  if (!mounted) return null;
  if (!deck) {
    return (
      <div className="flex flex-1 items-center justify-center text-zinc-400">
        Nothing to present. <button className="ml-2 underline" onClick={() => router.push("/")}>Pick a template</button>
      </div>
    );
  }

  const slide = deck.slides[i];

  return (
    <div ref={ref} className="fixed inset-0 z-50 flex items-center justify-center bg-black">
      <SlideView
        slide={slide}
        theme={deck.theme}
        brand={deck.brand}
        pageIndex={i}
        pageCount={deck.slides.length}
        width={w}
      />
      <button
        onClick={() => router.push("/editor")}
        className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white/70 hover:bg-white/20"
      >
        <X size={20} />
      </button>
      <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 items-center gap-4 rounded-full bg-white/10 px-4 py-2 text-white/80 backdrop-blur">
        <button onClick={() => setI((p) => Math.max(p - 1, 0))} disabled={i === 0}>
          <ChevronLeft />
        </button>
        <span className="text-sm tabular-nums">
          {i + 1} / {deck.slides.length}
        </span>
        <button onClick={() => setI((p) => Math.min(p + 1, deck.slides.length - 1))} disabled={i === deck.slides.length - 1}>
          <ChevronRight />
        </button>
      </div>
    </div>
  );
}
