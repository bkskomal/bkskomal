# PPTMaker

**AI-assisted presentation builder.** Pick one of 50 world-class templates, let
GPT-OSS-120B write the deck, brand it with your logo in one click, edit on a
live canvas, and export an **editable PowerPoint** (`.pptx`), a PDF, or present
full-screen in the browser.

> Status: working MVP. Built with Next.js 16 (App Router), TypeScript, Tailwind v4, Zustand.

---

## Quick start

```bash
npm install
cp .env.example .env.local   # then point it at your GPT-OSS-120B endpoint
npm run dev                  # http://localhost:3000
```

### Connecting GPT-OSS-120B

The app talks to **any OpenAI-compatible endpoint** (vLLM, TGI, Ollama,
llama.cpp server, or a hosted gateway). Set in `.env.local`:

```env
OPENAI_BASE_URL=http://localhost:8000/v1   # note the /v1 suffix
OPENAI_API_KEY=local                       # local servers accept any non-empty value
AI_MODEL=openai/gpt-oss-120b
```

Example with vLLM:

```bash
vllm serve openai/gpt-oss-120b --port 8000
```

The templates and editor work fully **without** a model — AI is an assist, not a
dependency. If the model server is unreachable, the UI shows a friendly hint.

---

## How it works

The whole app revolves around one idea: **a Deck is a single JSON source of
truth.** The canvas renders it, the AI emits/edits it, and the exporter consumes
it — so what you see is what you export.

```
Template ─┐
          ├─► Deck (JSON) ──► SlideView (DOM canvas)   ← you edit here
AI (GPT) ─┘        │          └─► .pptx / PDF / Present  ← same model, exported
                   └─ Theme + Brand Kit resolved at render time
```

### Why the AI never places pixels

GPT-OSS produces **semantic** slides — a layout id + title + bullets/quote/stat
+ notes (validated by a Zod schema). The deterministic **layout engine**
(`src/lib/layouts.ts`) turns that into positioned elements. This is the trick
that keeps every generated slide consistent, on-brand, and beautiful instead of
a free-form mess.

### Brand Kit applies everywhere, instantly

Logo, header, footer, and page numbers are **computed at render time** from the
Brand Kit (`src/lib/brand.ts`) rather than baked into each slide. Change the
logo once → all slides update. Brand colors/fonts override the theme tokens.

---

## Project structure

```
src/
  lib/
    types.ts        Deck / Slide / Element / Theme / BrandKit / Template model
    schema.ts       Zod schema the AI must conform to
    themes.ts       12 curated palette + type pairings
    layouts.ts      semantic AISlide -> positioned Slide (the design engine)
    templates.ts    50 templates across 8 categories (data-driven)
    brand.ts        Brand Kit -> render-time chrome (logo/header/footer)
    color.ts        token + brand color/font resolution
    deck.ts         build a Deck from a template or from AI output
    store.ts        Zustand editor state (persisted to localStorage)
    ai.ts           server-only OpenAI-compatible client
    export-pptx.ts  Deck -> editable .pptx (pptxgenjs)
  components/
    SlideView.tsx   the shared DOM renderer (canvas, thumbnails, gallery, print)
    gallery/        template gallery + create dialog
    editor/         Topbar, SlideList, Canvas, Inspector (Design/Brand/Element)
  app/
    page.tsx        template gallery (home)
    editor/         the editor
    present/        full-screen presenter (arrow keys / Esc)
    print/          one-slide-per-page view for "Save as PDF"
    api/generate/   POST -> generateDeck()
```

## Export fidelity

| Format        | Fidelity | Notes |
|---------------|----------|-------|
| `.pptx`       | High, **editable** | Native text boxes / shapes / images. Gradients approximate to their primary color (PPTX gradient fills aren't portable). |
| PDF (print)   | Pixel-perfect | Browser "Save as PDF" from the print view. |
| Present       | Pixel-perfect | Full-screen, keyboard-driven. |

## Roadmap

- Inline (double-click) text editing on the canvas
- Resize/rotate handles + snapping guides
- Charts and tables (native pptx chart export)
- AI image generation + stock image search
- Hosted share links (requires the persistence/backend layer)
- Grow the template library past 50 with seasonal/industry packs

## License

TBD.
