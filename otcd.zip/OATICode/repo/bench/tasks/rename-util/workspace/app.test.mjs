import assert from "node:assert/strict";
import { test } from "node:test";
import { greet } from "./app.mjs";
import { parseUser } from "./util.mjs";

test("parseUser exported from util.mjs", () => {
	assert.deepEqual(parseUser("alice:30"), { name: "alice", age: 30 });
});

test("app.greet uses the renamed utility", () => {
	assert.equal(greet("bob:42"), "Hello bob, age 42.");
});
