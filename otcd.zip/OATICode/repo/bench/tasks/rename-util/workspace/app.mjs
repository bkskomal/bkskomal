import { parseFoo } from "./util.mjs";

export function greet(raw) {
	const user = parseFoo(raw);
	return `Hello ${user.name}, age ${user.age}.`;
}
