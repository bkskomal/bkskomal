export function parseFoo(raw) {
	if (typeof raw !== "string") throw new Error("parseFoo: expected string");
	const [name, age] = raw.split(":");
	return { name: name.trim(), age: Number(age) };
}
