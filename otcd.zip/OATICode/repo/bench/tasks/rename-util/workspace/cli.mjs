import { parseFoo } from "./util.mjs";

export function main(arg) {
	const user = parseFoo(arg);
	process.stdout.write(`${user.name} ${user.age}\n`);
}
