// Memoize the result of an async fetcher. Multiple concurrent calls
// for the SAME key must trigger the fetcher exactly ONCE — all callers
// share the in-flight promise's eventual value.
export function makeCache() {
	const store = new Map();
	return {
		// BUG: this implementation has a race. Two concurrent calls for the
		// same key both see `store.has(key) === false` (the check happens
		// BEFORE either await resolves), then both run the fetcher, then
		// both write to the store. The fetcher fires N times instead of once.
		async getOrCache(key, fetcher) {
			if (store.has(key)) return store.get(key);
			const value = await fetcher();
			store.set(key, value);
			return value;
		},
		// Test helper — count entries.
		size() {
			return store.size;
		},
	};
}
