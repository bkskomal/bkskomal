import assert from "node:assert/strict";
import { test } from "node:test";
import { makeCache } from "./cache.mjs";

function deferred() {
	let resolve;
	const promise = new Promise((res) => {
		resolve = res;
	});
	return { promise, resolve };
}

test("single call hits the fetcher once and returns the value", async () => {
	const cache = makeCache();
	let calls = 0;
	const v = await cache.getOrCache("k", async () => {
		calls++;
		return 42;
	});
	assert.equal(v, 42);
	assert.equal(calls, 1);
});

test("repeated calls after resolution hit the cache (no extra fetches)", async () => {
	const cache = makeCache();
	let calls = 0;
	const fetcher = async () => {
		calls++;
		return calls;
	};
	await cache.getOrCache("k", fetcher);
	await cache.getOrCache("k", fetcher);
	await cache.getOrCache("k", fetcher);
	assert.equal(calls, 1);
});

test("10 concurrent calls for the SAME key trigger the fetcher exactly once (stampede fix)", async () => {
	const cache = makeCache();
	const gate = deferred();
	let calls = 0;
	const fetcher = async () => {
		calls++;
		await gate.promise; // hold the fetcher open
		return "computed";
	};
	// Fire 10 concurrent requests — they all hit getOrCache before the
	// first fetcher resolves.
	const promises = Array.from({ length: 10 }, () => cache.getOrCache("k", fetcher));
	// Yield so the awaits inside getOrCache get a chance to run.
	await new Promise((r) => setImmediate(r));
	// Now release the fetcher; all 10 callers should resolve to the same value.
	gate.resolve();
	const values = await Promise.all(promises);
	for (const v of values) assert.equal(v, "computed");
	// The critical assertion — fetcher fired ONCE for the stampede.
	assert.equal(
		calls,
		1,
		`Expected exactly 1 fetcher call across 10 concurrent requests; got ${calls}`,
	);
});

test("different keys don't share the in-flight promise (one fetch per distinct key)", async () => {
	const cache = makeCache();
	let calls = 0;
	const fetcher = async () => {
		calls++;
		return calls;
	};
	await Promise.all([
		cache.getOrCache("a", fetcher),
		cache.getOrCache("b", fetcher),
		cache.getOrCache("c", fetcher),
	]);
	assert.equal(calls, 3);
});

test("after a stampede resolves, the cached value is still returned to later callers", async () => {
	const cache = makeCache();
	let calls = 0;
	const fetcher = async () => {
		calls++;
		return "value";
	};
	const [, , , later] = await Promise.all([
		cache.getOrCache("k", fetcher),
		cache.getOrCache("k", fetcher),
		cache.getOrCache("k", fetcher),
		(async () => {
			await new Promise((r) => setImmediate(r));
			await new Promise((r) => setImmediate(r));
			return cache.getOrCache("k", fetcher);
		})(),
	]);
	assert.equal(later, "value");
	assert.equal(calls, 1);
});
