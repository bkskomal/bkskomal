import assert from "node:assert/strict";
import { test } from "node:test";
import { formatPhone } from "./format-phone.mjs";

const EXPECTED = "(212) 555-1234";

test("paren + space + dash form", () => {
	assert.equal(formatPhone("(212) 555-1234"), EXPECTED);
});

test("dashes only", () => {
	assert.equal(formatPhone("212-555-1234"), EXPECTED);
});

test("dots", () => {
	assert.equal(formatPhone("212.555.1234"), EXPECTED);
});

test("digits only", () => {
	assert.equal(formatPhone("2125551234"), EXPECTED);
});

test("leading +1 country code", () => {
	assert.equal(formatPhone("+1 212 555 1234"), EXPECTED);
});

test("rejects too few digits", () => {
	assert.throws(() => formatPhone("212-555"), /formatPhone/);
});

test("rejects letters", () => {
	assert.throws(() => formatPhone("212-555-CALL"), /formatPhone/);
});

test("rejects non-string input", () => {
	assert.throws(() => formatPhone(2125551234), /formatPhone/);
});
