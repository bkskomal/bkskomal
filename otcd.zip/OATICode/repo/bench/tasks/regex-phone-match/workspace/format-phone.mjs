// Normalize a US phone number into "(NNN) NNN-NNNN" format.
// Accepts:
//   "(212) 555-1234"
//   "212-555-1234"
//   "212.555.1234"
//   "2125551234"
//   "+1 212 555 1234"  (leading country code stripped)
// Throws Error("formatPhone: invalid number") for anything else.
export function formatPhone(input) {
	if (typeof input !== "string") throw new Error("formatPhone: invalid number");
	// BUG: this strip pattern only removes spaces and parens — leaves dots and dashes,
	// so "212.555.1234" → "212.555.1234" which fails the digit-only check below.
	// Also doesn't handle the leading "+1" country code.
	const digits = input.replace(/[ ()]/g, "");
	if (!/^\d{10}$/.test(digits)) throw new Error("formatPhone: invalid number");
	return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
}
