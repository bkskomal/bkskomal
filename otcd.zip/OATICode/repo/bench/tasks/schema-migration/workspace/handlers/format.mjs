import { fullName } from "../types/user.mjs";

// Format a user as a CSV row: id, name, email, age
export function formatCsv(user) {
	return [user.id, fullName(user), user.email, user.age].join(",");
}
