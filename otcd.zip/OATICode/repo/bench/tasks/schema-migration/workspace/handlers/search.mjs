import { fullName } from "../types/user.mjs";

// Case-insensitive substring match against the user's name.
export function searchByName(users, query) {
	const q = query.toLowerCase();
	return users.filter((u) => fullName(u).toLowerCase().includes(q));
}
