import { fullName } from "../types/user.mjs";

export function greet(user) {
	return `Hello, ${fullName(user)}!`;
}
