import { lastName } from "../types/user.mjs";

// Sort users alphabetically by last name (a→z).
export function sortByLastName(users) {
	return [...users].sort((a, b) => {
		const la = lastName(a).toLowerCase();
		const lb = lastName(b).toLowerCase();
		return la < lb ? -1 : la > lb ? 1 : 0;
	});
}
