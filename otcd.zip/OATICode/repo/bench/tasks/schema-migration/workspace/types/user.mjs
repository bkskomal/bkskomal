// User shape used across handlers/.
//
// CURRENT: name is a single string.
// TARGET:  split into firstName + lastName (both required, both non-empty).
//
// makeUser is the canonical constructor; every handler reads via accessors
// defined here so the migration's blast radius is bounded.

export function makeUser({ id, name, email, age }) {
	if (typeof name !== "string" || name.length === 0) {
		throw new Error("makeUser: name is required");
	}
	return Object.freeze({ id, name, email, age });
}

export function fullName(user) {
	return user.name;
}

export function lastName(user) {
	const parts = user.name.split(" ");
	return parts[parts.length - 1];
}
