import assert from "node:assert/strict";
import { test } from "node:test";
import { formatCsv } from "./handlers/format.mjs";
import { greet } from "./handlers/greet.mjs";
import { searchByName } from "./handlers/search.mjs";
import { sortByLastName } from "./handlers/sort.mjs";
import { fullName, lastName, makeUser } from "./types/user.mjs";

// All tests construct users with the NEW shape: firstName + lastName.
// The migration is complete when these construct cleanly AND every
// handler still produces correct results.

test("makeUser: constructs from firstName + lastName", () => {
	const u = makeUser({ id: "1", firstName: "Alice", lastName: "Walker", email: "a@x.com", age: 30 });
	assert.equal(u.firstName, "Alice");
	assert.equal(u.lastName, "Walker");
});

test("makeUser: rejects when firstName is missing/empty", () => {
	assert.throws(() => makeUser({ id: "1", lastName: "Walker", email: "a@x.com", age: 30 }));
	assert.throws(() =>
		makeUser({ id: "1", firstName: "", lastName: "Walker", email: "a@x.com", age: 30 }),
	);
});

test("makeUser: rejects when lastName is missing/empty", () => {
	assert.throws(() => makeUser({ id: "1", firstName: "Alice", email: "a@x.com", age: 30 }));
	assert.throws(() =>
		makeUser({ id: "1", firstName: "Alice", lastName: "", email: "a@x.com", age: 30 }),
	);
});

test("fullName(user) returns 'First Last'", () => {
	const u = makeUser({ id: "1", firstName: "Alice", lastName: "Walker", email: "a@x.com", age: 30 });
	assert.equal(fullName(u), "Alice Walker");
});

test("lastName(user) returns just the last name", () => {
	const u = makeUser({ id: "1", firstName: "Alice", lastName: "Walker", email: "a@x.com", age: 30 });
	assert.equal(lastName(u), "Walker");
});

test("greet still produces 'Hello, First Last!'", () => {
	const u = makeUser({ id: "1", firstName: "Alice", lastName: "Walker", email: "a@x.com", age: 30 });
	assert.equal(greet(u), "Hello, Alice Walker!");
});

test("formatCsv produces id,full name,email,age", () => {
	const u = makeUser({ id: "1", firstName: "Alice", lastName: "Walker", email: "a@x.com", age: 30 });
	assert.equal(formatCsv(u), "1,Alice Walker,a@x.com,30");
});

test("searchByName matches against the combined first + last", () => {
	const users = [
		makeUser({ id: "1", firstName: "Alice", lastName: "Walker", email: "a@x.com", age: 30 }),
		makeUser({ id: "2", firstName: "Bob", lastName: "Adams", email: "b@x.com", age: 25 }),
		makeUser({ id: "3", firstName: "Carol", lastName: "Walker", email: "c@x.com", age: 40 }),
	];
	const wallkers = searchByName(users, "walker");
	assert.equal(wallkers.length, 2);
});

test("sortByLastName orders by lastName ascending", () => {
	const users = [
		makeUser({ id: "1", firstName: "Carol", lastName: "Walker", email: "c@x.com", age: 40 }),
		makeUser({ id: "2", firstName: "Bob", lastName: "Adams", email: "b@x.com", age: 25 }),
		makeUser({ id: "3", firstName: "Alice", lastName: "Murphy", email: "a@x.com", age: 30 }),
	];
	const sorted = sortByLastName(users);
	assert.deepEqual(
		sorted.map((u) => u.lastName),
		["Adams", "Murphy", "Walker"],
	);
});
