// Route: GET /users
export function listUsers({ token, logger, db }) {
	if (!token || !token.startsWith("Bearer ")) {
		logger.warn({ route: "listUsers", reason: "missing-or-bad-token" });
		return { status: 401, body: { error: "unauthorized" } };
	}
	logger.info({ route: "listUsers" });
	return { status: 200, body: db };
}
