// Route: PUT /users/:id
export function updateUser({ token, id, patch, logger, db }) {
	if (!token || !token.startsWith("Bearer ")) {
		logger.warn({ route: "updateUser", reason: "missing-or-bad-token" });
		return { status: 401, body: { error: "unauthorized" } };
	}
	logger.info({ route: "updateUser", id });
	const idx = db.findIndex((u) => u.id === id);
	if (idx < 0) return { status: 404, body: { error: "not found" } };
	db[idx] = { ...db[idx], ...patch };
	return { status: 200, body: db[idx] };
}
