// Route: GET /users/:id
export function getUser({ token, id, logger, db }) {
	if (!token || !token.startsWith("Bearer ")) {
		logger.warn({ route: "getUser", reason: "missing-or-bad-token" });
		return { status: 401, body: { error: "unauthorized" } };
	}
	logger.info({ route: "getUser", id });
	const user = db.find((u) => u.id === id);
	if (!user) return { status: 404, body: { error: "not found" } };
	return { status: 200, body: user };
}
