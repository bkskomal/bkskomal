// Route: DELETE /users/:id
export function deleteUser({ token, id, logger, db }) {
	if (!token || !token.startsWith("Bearer ")) {
		logger.warn({ route: "deleteUser", reason: "missing-or-bad-token" });
		return { status: 401, body: { error: "unauthorized" } };
	}
	logger.info({ route: "deleteUser", id });
	const idx = db.findIndex((u) => u.id === id);
	if (idx < 0) return { status: 404, body: { error: "not found" } };
	db.splice(idx, 1);
	return { status: 204, body: null };
}
