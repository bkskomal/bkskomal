// Route: POST /users
export function createUser({ token, body, logger, db }) {
	if (!token || !token.startsWith("Bearer ")) {
		logger.warn({ route: "createUser", reason: "missing-or-bad-token" });
		return { status: 401, body: { error: "unauthorized" } };
	}
	logger.info({ route: "createUser" });
	const id = String(db.length + 1);
	const user = { id, ...body };
	db.push(user);
	return { status: 201, body: user };
}
