import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import { test } from "node:test";
import { createUser } from "./routes/create-user.mjs";
import { deleteUser } from "./routes/delete-user.mjs";
import { getUser } from "./routes/get-user.mjs";
import { listUsers } from "./routes/list-users.mjs";
import { updateUser } from "./routes/update-user.mjs";

function mkLogger() {
	const calls = [];
	return {
		calls,
		info: (x) => calls.push(["info", x]),
		warn: (x) => calls.push(["warn", x]),
	};
}

test("middleware module exists and exports authAndLog", async () => {
	const mod = await import("./middleware/auth-and-log.mjs");
	assert.equal(typeof mod.authAndLog, "function");
});

test("getUser: 200 with valid token", () => {
	const db = [{ id: "1", name: "alice" }];
	const r = getUser({ token: "Bearer x", id: "1", logger: mkLogger(), db });
	assert.equal(r.status, 200);
	assert.equal(r.body.name, "alice");
});

test("getUser: 401 with missing token", () => {
	const r = getUser({ token: "", id: "1", logger: mkLogger(), db: [] });
	assert.equal(r.status, 401);
});

test("listUsers: 200 returns db", () => {
	const db = [{ id: "1" }, { id: "2" }];
	const r = listUsers({ token: "Bearer x", logger: mkLogger(), db });
	assert.equal(r.status, 200);
	assert.equal(r.body.length, 2);
});

test("updateUser: 200 patches existing", () => {
	const db = [{ id: "1", name: "alice" }];
	const r = updateUser({
		token: "Bearer x",
		id: "1",
		patch: { name: "alicia" },
		logger: mkLogger(),
		db,
	});
	assert.equal(r.status, 200);
	assert.equal(r.body.name, "alicia");
});

test("deleteUser: 204 removes", () => {
	const db = [{ id: "1" }];
	const r = deleteUser({ token: "Bearer x", id: "1", logger: mkLogger(), db });
	assert.equal(r.status, 204);
	assert.equal(db.length, 0);
});

test("createUser: 201 inserts", () => {
	const db = [];
	const r = createUser({ token: "Bearer x", body: { name: "bob" }, logger: mkLogger(), db });
	assert.equal(r.status, 201);
	assert.equal(r.body.name, "bob");
});

test("refactor: auth-token check is no longer duplicated across route files", () => {
	const routeFiles = ["get-user", "list-users", "update-user", "delete-user", "create-user"];
	const here = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1"));
	const sigil = `!token.startsWith("Bearer ")`;
	let duplications = 0;
	for (const r of routeFiles) {
		const content = fs.readFileSync(path.join(here, "routes", `${r}.mjs`), "utf8");
		if (content.includes(sigil)) duplications++;
	}
	assert.ok(
		duplications === 0,
		`Expected route files to no longer contain the inline auth check (it should live in the middleware). Found duplicated check in ${duplications} route file(s).`,
	);
});

test("all routes log their own route name via the middleware", () => {
	const cases = [
		() => getUser({ token: "Bearer x", id: "1", logger: log1, db: [{ id: "1" }] }),
		() => listUsers({ token: "Bearer x", logger: log2, db: [] }),
		() => createUser({ token: "Bearer x", body: { name: "n" }, logger: log3, db: [] }),
	];
	const log1 = mkLogger();
	const log2 = mkLogger();
	const log3 = mkLogger();
	cases[0]();
	cases[1]();
	cases[2]();
	assert.ok(log1.calls.some(([_lvl, x]) => x.route === "getUser"));
	assert.ok(log2.calls.some(([_lvl, x]) => x.route === "listUsers"));
	assert.ok(log3.calls.some(([_lvl, x]) => x.route === "createUser"));
});
