import assert from "node:assert/strict";
import { test } from "node:test";
import { cartEntryLine, cartTotalLine } from "./total.mjs";

test("entries with only positive amounts format correctly", () => {
	const entries = [
		{ description: "Shirt", amount: 25 },
		{ description: "Socks", amount: 8.5 },
	];
	assert.equal(cartTotalLine(entries), "Total: $33.50");
});

test("refund entries (negative amounts) format the sign in front of the dollar", () => {
	const refund = { description: "Refund — defective shirt", amount: -25 };
	// Sign must be before $, not between $ and the digits.
	assert.equal(cartEntryLine(refund), "Refund — defective shirt: -$25.00");
});

test("net-negative cart shows total with the sign in front", () => {
	const entries = [
		{ description: "Gift card", amount: -50 },
		{ description: "Latte", amount: 5.5 },
	];
	assert.equal(cartTotalLine(entries), "Total: -$44.50");
});

test("zero total renders cleanly", () => {
	assert.equal(cartTotalLine([{ description: "Free sample", amount: 0 }]), "Total: $0.00");
});

test("rounding on cents stays sign-correct", () => {
	const entry = { description: "Tax refund (rounded)", amount: -0.005 };
	// Math.round of -0.5 in JS rounds toward +∞, so -0.005 * 100 = -0.5 → -0.
	// Either "-$0.00" or "$0.00" would be acceptable; the test pins
	// "$0.00" because -0 prefixed by - looks wrong to a human reader.
	const out = cartEntryLine(entry);
	assert.ok(out === "Tax refund (rounded): $0.00" || out === "Tax refund (rounded): -$0.00");
});
