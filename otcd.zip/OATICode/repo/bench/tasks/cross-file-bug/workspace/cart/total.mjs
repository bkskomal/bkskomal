import { formatMoney } from "../lib/format-money.mjs";

// A cart entry is { description, amount }. Amounts can be negative for
// refunds, discounts, gift-card redemptions, etc.
export function cartTotalLine(entries) {
	const total = entries.reduce((acc, e) => acc + e.amount, 0);
	return `Total: ${formatMoney(total)}`;
}

export function cartEntryLine(entry) {
	return `${entry.description}: ${formatMoney(entry.amount)}`;
}
