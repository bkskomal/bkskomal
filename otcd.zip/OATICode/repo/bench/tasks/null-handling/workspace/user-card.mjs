// Render a one-line summary of a user record for display.
// Real production data: name MAY be missing, email MAY be missing,
// age MAY be null. Must NEVER throw — show "—" for missing fields.
export function renderUserCard(user) {
	if (!user || typeof user !== "object") throw new Error("renderUserCard: expected an object");
	// BUG: assumes every field exists and is a string. Crashes when
	// name is null (toUpperCase on null), email is missing (.toLowerCase
	// on undefined), or age is null (numeric comparison on null is weird).
	const name = user.name.toUpperCase();
	const email = user.email.toLowerCase();
	const ageBracket = user.age < 18 ? "minor" : "adult";
	return `${name} <${email}> [${ageBracket}]`;
}
