import assert from "node:assert/strict";
import { test } from "node:test";
import { renderUserCard } from "./user-card.mjs";

test("full record renders cleanly", () => {
	const out = renderUserCard({ name: "alice", email: "ALICE@EXAMPLE.COM", age: 30 });
	assert.equal(out, "ALICE <alice@example.com> [adult]");
});

test("missing email shows placeholder", () => {
	const out = renderUserCard({ name: "bob", age: 25 });
	assert.match(out, /BOB/);
	assert.match(out, /—|<->/); // dash placeholder for missing email
});

test("null name does NOT crash", () => {
	const out = renderUserCard({ name: null, email: "x@y.z", age: 20 });
	assert.match(out, /—/);
});

test("missing age does NOT crash", () => {
	const out = renderUserCard({ name: "carol", email: "c@x.com" });
	assert.match(out, /CAROL/);
	// No `[minor]` / `[adult]` claim when age is unknown.
	assert.doesNotMatch(out, /\[minor\]/);
});

test("empty object yields all placeholders", () => {
	const out = renderUserCard({});
	assert.match(out, /—/);
});

test("still throws on non-object input", () => {
	assert.throws(() => renderUserCard(null), /renderUserCard/);
	assert.throws(() => renderUserCard("alice"), /renderUserCard/);
});
