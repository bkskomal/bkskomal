"""CLI: print "Hello <name>, you are <age> years old." given --name and --age."""

import argparse
import sys


def main(argv):
    parser = argparse.ArgumentParser()
    # BUG 1: --name has the wrong dest (capitalisation), so args.name is None.
    parser.add_argument("--name", dest="Name")
    # BUG 2: --age is parsed as string by default; the f-string output below
    # would be fine, but the test also checks an arithmetic operation
    # (`args.age + 1`) which raises TypeError on a string.
    parser.add_argument("--age")
    # BUG 3: neither flag is required, so missing flags produce None instead
    # of an argparse error (the tests expect a non-zero exit + usage message
    # when a flag is missing).
    args = parser.parse_args(argv)
    print(f"Hello {args.name}, you are {args.age} years old.")
    print(f"Next year you'll be {args.age + 1}.")


if __name__ == "__main__":
    main(sys.argv[1:])
