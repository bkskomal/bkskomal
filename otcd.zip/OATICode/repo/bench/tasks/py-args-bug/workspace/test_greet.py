"""Subprocess-based tests for greet.py."""

import subprocess
import sys
import unittest


def run_greet(args):
    return subprocess.run(
        [sys.executable, "greet.py", *args], capture_output=True, text=True, timeout=10
    )


class TestGreet(unittest.TestCase):
    def test_full_args_emits_greeting(self):
        r = run_greet(["--name", "alice", "--age", "30"])
        self.assertEqual(r.returncode, 0, msg=f"stderr: {r.stderr}")
        self.assertIn("Hello alice, you are 30 years old.", r.stdout)

    def test_age_arithmetic_works(self):
        r = run_greet(["--name", "bob", "--age", "25"])
        self.assertEqual(r.returncode, 0, msg=f"stderr: {r.stderr}")
        self.assertIn("Next year you'll be 26.", r.stdout)

    def test_missing_name_is_an_error(self):
        r = run_greet(["--age", "30"])
        self.assertNotEqual(r.returncode, 0)

    def test_missing_age_is_an_error(self):
        r = run_greet(["--name", "alice"])
        self.assertNotEqual(r.returncode, 0)


if __name__ == "__main__":
    unittest.main()
