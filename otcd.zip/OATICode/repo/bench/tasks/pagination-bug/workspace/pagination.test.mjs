import assert from "node:assert/strict";
import { test } from "node:test";
import { paginate } from "./paginate.mjs";

const items = ["a", "b", "c", "d", "e", "f", "g"];

test("page 1 returns the first slice", () => {
	assert.deepEqual(paginate(items, 1, 3), ["a", "b", "c"]);
});

test("page 2 returns the second slice", () => {
	assert.deepEqual(paginate(items, 2, 3), ["d", "e", "f"]);
});

test("page 3 returns the final partial slice", () => {
	assert.deepEqual(paginate(items, 3, 3), ["g"]);
});

test("page beyond range returns empty", () => {
	assert.deepEqual(paginate(items, 4, 3), []);
});
