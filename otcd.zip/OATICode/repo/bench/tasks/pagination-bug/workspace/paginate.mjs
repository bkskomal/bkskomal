// Return the slice of `items` that belongs on the given 1-indexed page.
// `page` is 1-based; `pageSize` is positive.
export function paginate(items, page, pageSize) {
	// BUG: off-by-one — should be (page - 1) * pageSize, not page * pageSize.
	const start = page * pageSize;
	return items.slice(start, start + pageSize);
}
