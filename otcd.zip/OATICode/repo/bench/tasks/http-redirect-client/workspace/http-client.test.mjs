import assert from "node:assert/strict";
import http from "node:http";
import { after, before, test } from "node:test";
import { fetchFollow } from "./http-client.mjs";

let server;
let baseUrl;

before(async () => {
	server = http.createServer((req, res) => {
		const url = req.url;
		// Routes:
		//   /ok            → 200 "hello"
		//   /missing       → 404 "nope"
		//   /one           → 302 → /ok
		//   /chain         → 302 → /step2
		//   /step2         → 302 → /step3
		//   /step3         → 302 → /ok
		//   /to-missing    → 302 → /missing
		//   /infinite      → 302 → /infinite (self-loop)
		//   /loop-a        → 302 → /loop-b
		//   /loop-b        → 302 → /loop-a
		//   /relative      → 302 → "ok" (relative path)
		//   /deep1..deepN  → 302 → /deepN+1 (used for over-limit test)
		if (url === "/ok") {
			res.writeHead(200, { "content-type": "text/plain" });
			res.end("hello");
			return;
		}
		if (url === "/missing") {
			res.writeHead(404, { "content-type": "text/plain" });
			res.end("nope");
			return;
		}
		if (url === "/one") {
			res.writeHead(302, { location: "/ok" });
			res.end();
			return;
		}
		if (url === "/chain") {
			res.writeHead(302, { location: "/step2" });
			res.end();
			return;
		}
		if (url === "/step2") {
			res.writeHead(302, { location: "/step3" });
			res.end();
			return;
		}
		if (url === "/step3") {
			res.writeHead(302, { location: "/ok" });
			res.end();
			return;
		}
		if (url === "/to-missing") {
			res.writeHead(302, { location: "/missing" });
			res.end();
			return;
		}
		if (url === "/loop-a") {
			res.writeHead(302, { location: "/loop-b" });
			res.end();
			return;
		}
		if (url === "/loop-b") {
			res.writeHead(302, { location: "/loop-a" });
			res.end();
			return;
		}
		if (url === "/relative") {
			res.writeHead(302, { location: "ok" });
			res.end();
			return;
		}
		const deep = /^\/deep(\d+)$/.exec(url ?? "");
		if (deep) {
			const n = Number(deep[1]);
			res.writeHead(302, { location: `/deep${n + 1}` });
			res.end();
			return;
		}
		res.writeHead(500);
		res.end("unhandled");
	});
	await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
	const addr = server.address();
	baseUrl = `http://127.0.0.1:${addr.port}`;
});

after(async () => {
	await new Promise((resolve) => server.close(resolve));
});

test("no-redirect 200 returns body and final URL", async () => {
	const r = await fetchFollow(`${baseUrl}/ok`);
	assert.equal(r.status, 200);
	assert.equal(r.body, "hello");
	assert.equal(r.url, `${baseUrl}/ok`);
});

test("single redirect follows to 200", async () => {
	const r = await fetchFollow(`${baseUrl}/one`);
	assert.equal(r.status, 200);
	assert.equal(r.body, "hello");
	assert.equal(r.url, `${baseUrl}/ok`);
});

test("three-hop chain resolves to 200", async () => {
	const r = await fetchFollow(`${baseUrl}/chain`);
	assert.equal(r.status, 200);
	assert.equal(r.url, `${baseUrl}/ok`);
});

test("redirect to a 404 returns the 404 (does not throw)", async () => {
	const r = await fetchFollow(`${baseUrl}/to-missing`);
	assert.equal(r.status, 404);
	assert.equal(r.body, "nope");
	assert.equal(r.url, `${baseUrl}/missing`);
});

test("exceeding maxRedirects throws", async () => {
	// /deep1 → /deep2 → ... never terminates.
	await assert.rejects(
		() => fetchFollow(`${baseUrl}/deep1`, { maxRedirects: 3 }),
		/too many redirects/,
	);
});

test("circular A→B→A throws with the circular-redirect message", async () => {
	await assert.rejects(() => fetchFollow(`${baseUrl}/loop-a`), /circular redirect/);
});

test("relative Location header is resolved against the current URL", async () => {
	const r = await fetchFollow(`${baseUrl}/relative`);
	assert.equal(r.status, 200);
	assert.equal(r.body, "hello");
});
