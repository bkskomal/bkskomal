// fetchFollow(url, opts) — follow HTTP 3xx redirects and return the
// final response.
//
// Args:
//   url             - string URL to fetch (http:// only for tests).
//   opts.maxRedirects - cap on redirect hops (default 5). Exceeding it
//                       throws Error("fetchFollow: too many redirects").
//
// Behavior:
//   - On a non-3xx response, return { status, body, url } where `url` is
//     the FINAL URL after following any redirects, `body` is the body
//     as a UTF-8 string.
//   - On a 3xx response with a Location header, fetch the Location URL
//     (resolve relative paths against the current URL) and recurse.
//   - Detect circular redirects: visiting a URL already in the chain
//     throws Error("fetchFollow: circular redirect").
//   - Network errors propagate (don't wrap).
//
// Use Node's built-in `node:http` module. No external dependencies.
export async function fetchFollow(_url, _opts = {}) {
	throw new Error("fetchFollow: not yet implemented");
}
