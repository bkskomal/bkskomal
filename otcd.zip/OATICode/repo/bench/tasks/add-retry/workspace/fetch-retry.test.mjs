import assert from "node:assert/strict";
import { test } from "node:test";
import { fetchWithRetry } from "./fetch-retry.mjs";

function makeSleep() {
	const calls = [];
	return {
		calls,
		sleep: async (ms) => {
			calls.push(ms);
		},
	};
}

test("returns immediately on first-attempt success", async () => {
	const { sleep, calls } = makeSleep();
	let attempts = 0;
	const r = await fetchWithRetry({
		doFetch: async () => {
			attempts++;
			return { status: 200, body: "ok" };
		},
		maxAttempts: 3,
		baseDelayMs: 10,
		sleep,
	});
	assert.equal(attempts, 1);
	assert.equal(r.status, 200);
	assert.deepEqual(calls, []); // no sleeps when first try succeeds
});

test("retries on thrown error, returns after recovery", async () => {
	const { sleep, calls } = makeSleep();
	let attempts = 0;
	const r = await fetchWithRetry({
		doFetch: async () => {
			attempts++;
			if (attempts < 3) throw new Error("network");
			return { status: 200, body: "finally" };
		},
		maxAttempts: 5,
		baseDelayMs: 10,
		sleep,
	});
	assert.equal(attempts, 3);
	assert.equal(r.body, "finally");
	// Two sleeps: 10ms before retry #1 and 20ms before retry #2.
	assert.deepEqual(calls, [10, 20]);
});

test("retries on 5xx, returns recovered response", async () => {
	const { sleep, calls } = makeSleep();
	const statuses = [503, 502, 200];
	const r = await fetchWithRetry({
		doFetch: async () => ({ status: statuses.shift(), body: null }),
		maxAttempts: 5,
		baseDelayMs: 5,
		sleep,
	});
	assert.equal(r.status, 200);
	assert.deepEqual(calls, [5, 10]);
});

test("does NOT retry on 4xx (returns immediately)", async () => {
	const { sleep, calls } = makeSleep();
	let attempts = 0;
	const r = await fetchWithRetry({
		doFetch: async () => {
			attempts++;
			return { status: 404, body: "missing" };
		},
		maxAttempts: 5,
		baseDelayMs: 10,
		sleep,
	});
	assert.equal(attempts, 1);
	assert.equal(r.status, 404);
	assert.deepEqual(calls, []);
});

test("returns last response after exhausting retries on 5xx", async () => {
	const { sleep, calls } = makeSleep();
	let attempts = 0;
	const r = await fetchWithRetry({
		doFetch: async () => {
			attempts++;
			return { status: 503, body: `attempt ${attempts}` };
		},
		maxAttempts: 3,
		baseDelayMs: 10,
		sleep,
	});
	assert.equal(attempts, 3);
	assert.equal(r.status, 503);
	assert.equal(r.body, "attempt 3");
	// 2 sleeps between 3 attempts.
	assert.deepEqual(calls, [10, 20]);
});

test("rethrows the last error after exhausting retries on throws", async () => {
	const { sleep } = makeSleep();
	let attempts = 0;
	await assert.rejects(async () => {
		await fetchWithRetry({
			doFetch: async () => {
				attempts++;
				throw new Error(`boom ${attempts}`);
			},
			maxAttempts: 3,
			baseDelayMs: 5,
			sleep,
		});
	}, /boom 3/);
	assert.equal(attempts, 3);
});
