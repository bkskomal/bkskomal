// Retry a fetch-like call with exponential backoff.
//
// Args:
//   doFetch     - async fn() returning a Response-shaped { status, body }
//   maxAttempts - max total calls (must be >= 1). On failure exhaustion,
//                 the LAST result is returned (or last error rethrown).
//   baseDelayMs - delay before retry #1 is baseDelayMs; retry #2 is
//                 baseDelayMs * 2; retry #3 is baseDelayMs * 4; etc.
//   sleep       - async fn(ms) — injected so tests can fake timing.
//
// Retry triggers:
//   - doFetch() throws  → retry (until exhausted)
//   - doFetch() returns response with status >= 500 → retry
//   - response with status < 500 (incl 4xx) → NO retry, return immediately.
export async function fetchWithRetry({ doFetch, maxAttempts, baseDelayMs, sleep }) {
	throw new Error("fetchWithRetry: not yet implemented");
}
