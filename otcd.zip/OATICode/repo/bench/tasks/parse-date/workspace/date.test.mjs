import assert from "node:assert/strict";
import { test } from "node:test";
import { parseDate } from "./date.mjs";

test("parses an ISO 8601 string", () => {
	const d = parseDate("2026-06-02T10:30:00Z");
	assert.ok(d instanceof Date);
	assert.equal(d.toISOString(), "2026-06-02T10:30:00.000Z");
});

test("parses a stringified Unix timestamp (ms)", () => {
	const d = parseDate("1717322200000");
	assert.ok(d instanceof Date);
	assert.equal(d.getTime(), 1717322200000);
});

test("throws for non-string input", () => {
	assert.throws(() => parseDate(12345), /parseDate/);
	assert.throws(() => parseDate(null), /parseDate/);
});

test("throws for unparseable garbage", () => {
	assert.throws(() => parseDate("not a date"), /parseDate/);
	assert.throws(() => parseDate(""), /parseDate/);
});
