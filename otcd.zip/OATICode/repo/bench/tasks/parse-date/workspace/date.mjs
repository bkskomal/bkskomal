// Parse a date string. Accepts:
//   - ISO 8601 like "2026-06-02T10:30:00Z"
//   - Stringified Unix timestamp in ms, like "1717322200000"
// Throws Error("parseDate: ...") for anything else (non-string, blank,
// unparseable garbage).
export function parseDate(_str) {
	throw new Error("parseDate: not yet implemented");
}
