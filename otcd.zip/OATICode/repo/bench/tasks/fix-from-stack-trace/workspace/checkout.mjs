import { calculateTax } from "./lib/tax.mjs";

// processCheckout builds an order and runs it through the tax helper.
//
// `cart` is the items array, `customer` carries shipping info:
//   customer = { name: "...", address: { state: "CA", zip: "..." } }
export function processCheckout(cart, customer) {
	const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
	const order = {
		subtotal,
		// BUG: the field is named `shippingAddress` in calculateTax's contract
		// (see lib/tax.mjs), but here we pass `address`. The TypeError
		// surfaces inside tax.mjs (`order.shippingAddress` is undefined,
		// so `.state` throws) — but the fix belongs HERE.
		address: customer.address,
	};
	const tax = calculateTax(order);
	return {
		subtotal,
		tax,
		total: Math.round((subtotal + tax) * 100) / 100,
	};
}
