import assert from "node:assert/strict";
import * as fs from "node:fs";
import { test } from "node:test";
import { processCheckout } from "./checkout.mjs";

test("checkout with CA tax rate", () => {
	const cart = [
		{ price: 100, quantity: 1 },
		{ price: 25, quantity: 2 },
	];
	const customer = { name: "alice", address: { state: "CA", zip: "94103" } };
	const r = processCheckout(cart, customer);
	assert.equal(r.subtotal, 150);
	assert.equal(r.tax, 10.88); // 150 * 0.0725 = 10.875 → rounded to 10.88
	assert.equal(r.total, 160.88);
});

test("checkout with OR (zero tax)", () => {
	const r = processCheckout([{ price: 50, quantity: 1 }], {
		name: "bob",
		address: { state: "OR", zip: "97201" },
	});
	assert.equal(r.tax, 0);
	assert.equal(r.total, 50);
});

test("checkout with unknown state defaults to 0 tax", () => {
	const r = processCheckout([{ price: 10, quantity: 1 }], {
		name: "carol",
		address: { state: "ZZ", zip: "00000" },
	});
	assert.equal(r.tax, 0);
});

test("lib/tax.mjs signature is unchanged (no shippingAddress rename to address)", () => {
	const src = fs.readFileSync(new URL("./lib/tax.mjs", import.meta.url), "utf8");
	assert.match(
		src,
		/order\.shippingAddress\.state/,
		"lib/tax.mjs must still reference order.shippingAddress — the fix belongs in checkout.mjs (the caller), not in the helper.",
	);
});
