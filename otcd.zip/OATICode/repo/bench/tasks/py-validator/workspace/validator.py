"""Email validation. Stdlib only — no `email_validator` package."""


def validate_email(addr):
    """Return True for syntactically valid email addresses, False otherwise.

    Rules (kept simple to be unambiguous for the benchmark):
      - Must be a non-empty string.
      - Must contain exactly one "@".
      - Both sides of the "@" must be non-empty.
      - The right side (domain) must contain at least one ".".
      - The TLD (text after the last ".") must be non-empty.
      - Leading or trailing whitespace makes the address invalid.
      - Non-string inputs (None, int, etc.) are invalid (do NOT raise).
    """
    raise NotImplementedError("validate_email: not yet implemented")
