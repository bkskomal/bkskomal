import unittest
from validator import validate_email


class TestValidateEmail(unittest.TestCase):
    def test_accepts_typical(self):
        self.assertTrue(validate_email("alice@example.com"))
        self.assertTrue(validate_email("a.b+tag@sub.example.co.uk"))

    def test_rejects_empty_string(self):
        self.assertFalse(validate_email(""))

    def test_rejects_missing_at(self):
        self.assertFalse(validate_email("aliceexample.com"))

    def test_rejects_missing_dot_in_domain(self):
        self.assertFalse(validate_email("alice@localhost"))

    def test_rejects_empty_local(self):
        self.assertFalse(validate_email("@example.com"))

    def test_rejects_empty_domain(self):
        self.assertFalse(validate_email("alice@"))

    def test_rejects_empty_tld(self):
        self.assertFalse(validate_email("alice@example."))

    def test_rejects_leading_whitespace(self):
        self.assertFalse(validate_email(" alice@example.com"))

    def test_rejects_trailing_whitespace(self):
        self.assertFalse(validate_email("alice@example.com "))

    def test_rejects_non_string(self):
        self.assertFalse(validate_email(None))
        self.assertFalse(validate_email(12345))
        self.assertFalse(validate_email(["a@b.c"]))


if __name__ == "__main__":
    unittest.main()
