# OATI Code — Benchmark Harness

End-to-end task pass-rate measurement for the OATI agent loop. Each task
ships with a pre-baked broken or incomplete workspace plus a validation
command that determines pass/fail. The runner copies the workspace into a
temp dir, runs the agent against the task prompt with auto-approve on,
runs the validation command, and writes a markdown report.

## Why

Without a benchmark there's no way to measure whether a refactor in
`agent-core`, a new model integration, or a prompt change made things
better or worse. The harness gives us a fast (<5 min for the sample set)
sanity check on every meaningful change. It's also the foundation for
public benchmarks: a SWE-bench Verified ingester can emit the same
`BenchTask` shape and reuse this runner.

## Prereqs

- Node 20+
- Python 3 (for tasks tagged `python`) — uses stdlib `unittest`, no extra packages
- For SWE-bench Verified tasks: `git`, `pip`, and the project's dependencies (some tasks install heavy stacks — numpy / scipy / django / etc.)

## Run it

```bash
# Build the harness bundle (run once, or whenever you change bench/src/).
npm run bench:agent:build

# Run the curated 14-task seed suite against your provider.
OPENAI_BASE_URL=https://your-litellm-or-vllm-endpoint/v1 \
OPENAI_API_KEY=sk-... \
OATI_BENCH_MODEL=moonshotai/kimi-k2-instruct-0925 \
npm run bench:agent

# Or filter by tag / single task:
npm run bench:agent -- --filter bug
npm run bench:agent -- --filter python
npm run bench:agent -- --filter pagination-bug

# Smoke-test your environment WITHOUT burning model tokens (just runs
# setup + validate; pass means task is already correct, fail means
# task is broken-as-expected which is what we want).
npm run bench:agent -- --validate-only

# Cap the suite at the first N tasks — useful with SWE-bench (below).
npm run bench:agent -- --limit 5
```

## SWE-bench Verified

OATI's bench format is intentionally compatible with [SWE-bench Verified](https://www.swebench.com/). One ingester command converts the canonical JSONL release into our task manifest layout:

```bash
# 1. Download the SWE-bench Verified JSONL from HuggingFace:
#    https://huggingface.co/datasets/princeton-nlp/SWE-bench_Verified
#    (file: data/test-00000-of-00001.parquet — convert to JSONL with
#     `datasets` or `pandas.read_parquet().to_json(orient='records', lines=True)`)

# 2. Ingest it. Writes one task per entry to bench/tasks/swe/.
npm run bench:agent:ingest-swe -- --path /path/to/swe-bench-verified.jsonl

# 3. Smoke-test 3 tasks WITHOUT the agent first — checks your git/pip
#    environment can clone + apply the test patches.
npm run bench:agent -- --filter swe-bench --limit 3 --validate-only

# 4. Run them for real with the agent.
npm run bench:agent -- --filter swe-bench --limit 3
```

Each SWE-bench task's `setup` command clones the repo at the right commit and applies the `test_patch` so the FAIL_TO_PASS tests exist for the agent to satisfy. The `validate` command runs those tests with `python -m pytest -x`. Tasks that need exotic project dependencies (pinned numpy versions, system libs, etc.) may surface as **errors** rather than fail/pass — that's expected without Docker isolation. Filter on a stable subset first:

```bash
# Tasks group by repo via auto-generated tags:
npm run bench:agent -- --filter swe-django   # just django tasks
npm run bench:agent -- --filter swe-sympy
```

## Current task suite (14 tasks)

| Task | Language | Shape | Files | Notes |
| --- | --- | --- | --- | --- |
| `pagination-bug` | TS | bug | 1 | Off-by-one in paginate(). |
| `parse-date` | TS | feature | 1 | Implement parseDate() (ISO + Unix ms). |
| `rename-util` | TS | refactor | 3 | Rename a symbol across imports. |
| `regex-phone-match` | TS | bug | 1 | Phone-number regex mishandles multiple input shapes. |
| `null-handling` | TS | bug | 1 | Function crashes on null/undefined fields. |
| `extract-shared` | TS | refactor | 5+1 | Extract duplicated auth/log boilerplate to a middleware module. Exercises repo-map orientation. |
| `add-retry` | TS | feature | 1 | Implement exponential-backoff retry with injected sleep + transient-error semantics. |
| `py-args-bug` | Python | bug | 1 | argparse setup with three bugs (dest typo, type coercion, required flag). |
| `py-validator` | Python | feature | 1 | Implement validate_email() with edge-case rules. |
| `cross-file-bug` | TS | bug | 3 | Symptom shows in cart code; fix is upstream in lib/format-money.mjs. Trace from failure to source. |
| `async-race` | TS | bug | 1 | Fix a cache-stampede race — concurrent calls for the same key trigger the fetcher N times instead of 1. |
| `http-redirect-client` | TS | feature | 1 | Implement fetchFollow() with redirect-following, max-hop cap, circular-redirect detection. Real local HTTP server. |
| `fix-from-stack-trace` | TS | bug | 3 | TypeError stack points at lib/tax.mjs; actual bug is the caller in checkout.mjs. Test pins lib/tax.mjs as off-limits. |
| `schema-migration` | TS | refactor | 6 | Split User.name → firstName + lastName, propagate through type + 4 handlers. |

The report lands at `bench/out/report.md`; raw results at
`bench/out/results.jsonl`.

## Task format

Each task is a directory under `bench/tasks/<name>/`:

```
bench/tasks/my-task/
  task.json          # manifest (BenchTask shape — see src/types.ts)
  workspace/         # pre-baked starting state (gets copied to a temp dir per run)
```

Minimal `task.json`:

```json
{
  "name": "my-task",
  "description": "One-line human description",
  "tags": ["bug", "ts"],
  "prompt": "Tell the model what to do. Reference files by name. Tell it how to verify.",
  "validate": { "command": "node --test test.mjs", "timeoutMs": 30000 }
}
```

Optional fields: `setup` (one-time prep before the agent starts),
`maxIterations` (per-task iteration cap), `workspaceDir` (rename the
default `workspace/` subdir).

## Adding a new task

1. Pick a kebab-case name.
2. `mkdir -p bench/tasks/<name>/workspace`.
3. Drop the broken/incomplete code into `workspace/`.
4. Write a test that the agent's fix should make pass.
5. Write `task.json` pointing `validate.command` at that test.
6. Run `npm run bench --workspace=@oati/bench -- --filter <name>` to
   sanity-check it.

Good task qualities:

- **Unambiguous validation** — exit-0 means done, period. No fuzzy LLM
  graders.
- **Self-contained** — `node`-only is ideal; pip/npm install drags out
  runtime.
- **Detectably broken at the start** — `validate` should fail BEFORE the
  agent runs (otherwise the "pass" is unearned). Verify this manually.
- **One concept per task** — bug fix OR refactor OR feature, not a
  Cartesian product. Mix tags to taxonomize.

## What's measured

The markdown report includes for every task:

- Pass/fail/error status
- Wall-clock duration
- Agent iterations consumed
- Tokens (input/output) when the provider reports them
- Files the agent mutated (empty list = "investigated but didn't act")
- Validate command output on failure (truncated)

The headline at the top:
`N/M passed (P%). F failed, E errored. Wall-clock: T seconds.`
