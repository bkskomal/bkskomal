import { build } from "esbuild";

// 2026-06-02: bundle both the bench runner and the SWE-bench ingester
// as separate CJS entry points sharing the same external-dep config.
const common = {
	bundle: true,
	platform: "node",
	target: "node20",
	format: "cjs",
	sourcemap: true,
	minify: false,
	logLevel: "info",
	external: [
		"puppeteer-core",
		"web-tree-sitter",
		"screenshot-desktop",
		"@nut-tree-fork/nut-js",
		"pngjs",
	],
};

await build({
	...common,
	entryPoints: ["src/cli.ts"],
	outfile: "dist/cli.cjs",
});
console.log("[bench] built dist/cli.cjs");

await build({
	...common,
	entryPoints: ["src/ingest-cli.ts"],
	outfile: "dist/ingest-cli.cjs",
});
console.log("[bench] built dist/ingest-cli.cjs");
