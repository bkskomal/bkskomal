import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { Agent } from "@oati/agent-core";
import { createOpenAICompatibleProvider } from "@oati/providers";
import type { ModeConfig } from "@oati/shared";
import { builtinTools } from "@oati/tools";
import { type BenchHostState, copyDirSync, createBenchHost, runSync } from "./bench-host";
import type { BenchConfig, BenchResult, BenchTask } from "./types";

/**
 * 2026-06-02: single-task runner. Sets up an isolated temp workspace,
 * spawns the OATI agent with the task's prompt, runs the validate
 * command, returns a BenchResult. The runner is deliberately
 * filesystem-driven (no Docker yet) so it works on developer laptops
 * for fast iteration — Docker isolation comes when we scale to
 * SWE-bench Verified's full 500 tasks.
 */
export async function runTask(
	task: BenchTask,
	config: BenchConfig,
	taskDir: string,
): Promise<BenchResult> {
	const startedAt = Date.now();
	const workspacePath = fs.mkdtempSync(path.join(os.tmpdir(), `oati-bench-${task.name}-`));
	const sourceWorkspace = path.join(taskDir, task.workspaceDir ?? "workspace");
	const state: BenchHostState = { mutatedPaths: [] };
	let iterations = 0;
	let tokenInput = 0;
	let tokenOutput = 0;

	try {
		// Stage 1: copy task's pre-baked workspace into the temp dir.
		if (!fs.existsSync(sourceWorkspace)) {
			return errorResult(
				task,
				workspacePath,
				`task workspace not found: ${sourceWorkspace}`,
				Date.now() - startedAt,
				state.mutatedPaths,
			);
		}
		copyDirSync(sourceWorkspace, workspacePath);

		// Stage 2: optional per-task setup (npm install, pip install, etc.).
		if (task.setup) {
			const setupRes = runSync(task.setup.command, workspacePath, task.setup.timeoutMs ?? 120_000);
			if (setupRes.code !== 0) {
				return errorResult(
					task,
					workspacePath,
					`setup command failed (exit ${setupRes.code}): ${setupRes.out.slice(0, 500)}`,
					Date.now() - startedAt,
					state.mutatedPaths,
				);
			}
		}

		// Stage 3: spin up the agent and run the task prompt — UNLESS the
		// runner is in --validate-only mode, in which case we skip straight
		// to the validate command to check whether the task's environment +
		// expected-failure state are wired correctly. This separates
		// environment-setup failures from agent-capability failures BEFORE
		// burning model tokens.
		if (!config.validateOnly) {
			const provider = createOpenAICompatibleProvider({
				id: "bench-provider",
				displayName: "Bench Provider",
				baseUrl: config.providerUrl,
				apiKey: config.providerKey,
			});
			const host = createBenchHost(workspacePath, state);
			const mode: ModeConfig = {
				id: "bench",
				displayName: "Bench",
				systemPrompt:
					"You are OATI Code running in benchmark mode. Your job: read the user's task carefully, examine the workspace, and apply the minimum changes needed to satisfy the task. Use write_file / batch_file_edit to make changes. Run tests or commands via `exec` when you need to verify. Stop when you've made the change — do NOT add features beyond what's asked.",
				enabledTools: "all",
				enablePlanner: false,
				enableCritic: false,
				maxParallelAgents: 1,
				maxIterations: task.maxIterations ?? config.maxIterations ?? 30,
			};
			const agent = new Agent(
				{
					id: `bench-${task.name}`,
					provider,
					tools: builtinTools,
					host,
					mode,
				},
				{ modelId: config.modelId },
			);
			agent.on((ev) => {
				if (ev.type === "iteration") iterations = ev.n;
				else if (ev.type === "usage") {
					tokenInput += ev.inputTokens;
					tokenOutput += ev.outputTokens;
				}
			});
			try {
				await agent.run({ userMessage: task.prompt });
			} catch (err) {
				return errorResult(
					task,
					workspacePath,
					`agent crashed: ${err instanceof Error ? err.message : String(err)}`,
					Date.now() - startedAt,
					state.mutatedPaths,
					iterations,
					tokenInput,
					tokenOutput,
				);
			}
		}

		// Stage 4: run the validate command and capture pass/fail.
		const validateRes = runSync(
			task.validate.command,
			workspacePath,
			task.validate.timeoutMs ?? 120_000,
		);
		const status: BenchResult["status"] = validateRes.code === 0 ? "pass" : "fail";
		return {
			task,
			status,
			durationMs: Date.now() - startedAt,
			iterations,
			tokens: tokenInput + tokenOutput > 0 ? { input: tokenInput, output: tokenOutput } : undefined,
			validateStdout: validateRes.out.slice(0, 4000),
			validateStderr: "",
			workspacePath,
			mutatedPaths: state.mutatedPaths,
		};
	} catch (err) {
		return errorResult(
			task,
			workspacePath,
			`runner exception: ${err instanceof Error ? err.message : String(err)}`,
			Date.now() - startedAt,
			state.mutatedPaths,
			iterations,
			tokenInput,
			tokenOutput,
		);
	}
}

function errorResult(
	task: BenchTask,
	workspacePath: string,
	reason: string,
	durationMs: number,
	mutatedPaths: readonly string[],
	iterations = 0,
	tokenInput = 0,
	tokenOutput = 0,
): BenchResult {
	return {
		task,
		status: "error",
		durationMs,
		iterations,
		tokens: tokenInput + tokenOutput > 0 ? { input: tokenInput, output: tokenOutput } : undefined,
		validateStdout: "",
		validateStderr: "",
		workspacePath,
		errorReason: reason,
		mutatedPaths: [...mutatedPaths],
	};
}
