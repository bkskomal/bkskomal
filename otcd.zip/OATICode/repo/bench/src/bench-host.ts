import { execSync, spawn } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import type { ExecOptions, ExecResult, HostContext } from "@oati/shared";

/**
 * 2026-06-02: headless HostContext for the benchmark harness. Backed by
 * the real filesystem under a workspace root, auto-approves every tool
 * call (the benchmark always runs in maximum-autonomy mode), no-ops the
 * UI methods (showDiff, requestApproval). Tracks mutated paths so the
 * benchmark report can show whether the agent actually wrote anything
 * — a strong signal of "investigated but didn't act" failures.
 */
export interface BenchHostState {
	readonly mutatedPaths: string[];
}

export function createBenchHost(workspaceRoot: string, state: BenchHostState): HostContext {
	const resolve = (p: string): string => {
		if (path.isAbsolute(p)) return p;
		return path.join(workspaceRoot, p);
	};
	const markMutation = (p: string) => {
		const rel = path.isAbsolute(p) ? path.relative(workspaceRoot, p).replace(/\\/g, "/") : p;
		if (!state.mutatedPaths.includes(rel)) state.mutatedPaths.push(rel);
	};

	return {
		async readFile(p: string) {
			return fs.promises.readFile(resolve(p), "utf8");
		},
		async writeFile(p: string, content: string) {
			const full = resolve(p);
			await fs.promises.mkdir(path.dirname(full), { recursive: true });
			await fs.promises.writeFile(full, content, "utf8");
			markMutation(p);
		},
		async fileExists(p: string) {
			try {
				await fs.promises.access(resolve(p));
				return true;
			} catch {
				return false;
			}
		},
		async exec(command: string, options?: ExecOptions): Promise<ExecResult> {
			return runShellCommand(command, {
				cwd: options?.cwd ? resolve(options.cwd) : workspaceRoot,
				timeoutMs: options?.timeoutMs ?? 60_000,
				shell: options?.shell ?? "auto",
				// HostContext.exec's onChunk signature is (chunk, isStderr) — we
				// fold both streams through it; the benchmark runner doesn't
				// distinguish them.
				onChunk: options?.onChunk ? (chunk: string) => options.onChunk?.(chunk, false) : undefined,
			});
		},
		workspaceRoot() {
			return workspaceRoot;
		},
		async requestApproval() {
			// Benchmark runs without human-in-the-loop. Auto-approve every
			// mutating tool. Tools whose schema is gated for safety reasons
			// (e.g., delete_file) still run — that's intentional for the
			// "can the agent solve this" measurement.
			return true;
		},
		async showDiff() {
			// noop in benchmark
		},
		log(_level, _message) {
			// Silent — the runner captures its own logs.
		},
	};
}

interface ShellOpts {
	readonly cwd: string;
	readonly timeoutMs: number;
	readonly shell: string;
	readonly onChunk?: (chunk: string) => void;
}

function runShellCommand(command: string, opts: ShellOpts): Promise<ExecResult> {
	return new Promise<ExecResult>((resolve) => {
		const isWindows = process.platform === "win32";
		const shellCmd =
			opts.shell === "pwsh" || opts.shell === "powershell"
				? "pwsh"
				: opts.shell === "bash" || opts.shell === "sh"
					? "bash"
					: isWindows
						? "cmd.exe"
						: "/bin/sh";
		const shellArgs =
			shellCmd === "cmd.exe"
				? ["/d", "/s", "/c", command]
				: shellCmd === "pwsh"
					? ["-NoProfile", "-Command", command]
					: ["-c", command];
		const child = spawn(shellCmd, shellArgs, {
			cwd: opts.cwd,
			env: process.env,
			stdio: ["ignore", "pipe", "pipe"],
		});
		let stdout = "";
		let stderr = "";
		let timedOut = false;
		const timer = setTimeout(() => {
			timedOut = true;
			child.kill("SIGTERM");
		}, opts.timeoutMs);
		child.stdout.on("data", (chunk: Buffer) => {
			const text = chunk.toString();
			stdout += text;
			if (opts.onChunk) opts.onChunk(text);
		});
		child.stderr.on("data", (chunk: Buffer) => {
			stderr += chunk.toString();
		});
		child.on("close", (code) => {
			clearTimeout(timer);
			resolve({
				stdout,
				stderr: timedOut ? `${stderr}\n[bench-host: timeout after ${opts.timeoutMs}ms]` : stderr,
				exitCode: timedOut ? 124 : (code ?? 1),
			});
		});
		child.on("error", (err) => {
			clearTimeout(timer);
			resolve({
				stdout,
				stderr: `${stderr}\n[bench-host: spawn error: ${err.message}]`,
				exitCode: 127,
			});
		});
	});
}

/**
 * Copy a directory recursively. Used to pin the task's starting
 * workspace into an isolated temp dir per run, so concurrent tasks
 * don't trample each other.
 */
export function copyDirSync(src: string, dest: string): void {
	fs.mkdirSync(dest, { recursive: true });
	for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
		const s = path.join(src, entry.name);
		const d = path.join(dest, entry.name);
		if (entry.isDirectory()) copyDirSync(s, d);
		else if (entry.isFile()) fs.copyFileSync(s, d);
	}
}

/**
 * Run a synchronous shell command and return its exit code + stdout.
 * Used for the per-task setup phase (where streaming isn't useful).
 */
export function runSync(
	command: string,
	cwd: string,
	timeoutMs: number,
): { code: number; out: string } {
	try {
		const out = execSync(command, {
			cwd,
			timeout: timeoutMs,
			stdio: ["ignore", "pipe", "pipe"],
		}).toString();
		return { code: 0, out };
	} catch (err) {
		const out = (err as { stdout?: Buffer; stderr?: Buffer }).stdout?.toString() ?? "";
		const errOut = (err as { stderr?: Buffer }).stderr?.toString() ?? "";
		return { code: (err as { status?: number }).status ?? 1, out: `${out}\n${errOut}` };
	}
}
