/**
 * 2026-06-02: OATI Code internal benchmark harness — type definitions.
 *
 * The benchmark answers one question per task: given a problem statement
 * and a starting workspace, can the agent produce a patch that makes the
 * task's validation command pass?
 *
 * Tasks live under bench/tasks/<name>/. Each task has a JSON manifest
 * plus a pre-baked broken/incomplete workspace. The runner copies the
 * workspace to a temp dir, spawns the agent against it with the prompt,
 * then runs the validation command and records pass/fail.
 *
 * Format is intentionally agnostic of SWE-bench's schema so we can layer
 * a SWE-bench-Verified ingester on top later without rewriting the
 * runner — that ingester would just emit BenchTask objects.
 */

export interface BenchTask {
	/** Stable identifier, kebab-case. Used as the task directory name. */
	readonly name: string;
	/** One-line human description. Shown in reports. */
	readonly description: string;
	/** Tags for filtering — "bug", "refactor", "feature", "ts", "py", etc. */
	readonly tags: readonly string[];
	/**
	 * Path (relative to the task directory) to the pre-baked workspace that
	 * gets copied into a temp dir at run time. Defaults to "workspace".
	 */
	readonly workspaceDir?: string;
	/** The user-message prompt handed to the agent. */
	readonly prompt: string;
	/**
	 * Validation command executed in the workspace temp dir after the
	 * agent finishes. Pass when exit code === 0. The runner passes
	 * `cwd` automatically so the command shouldn't include `cd`.
	 */
	readonly validate: {
		readonly command: string;
		/** Per-task timeout. Defaults to 120000 (2 min) when unset. */
		readonly timeoutMs?: number;
	};
	/**
	 * Optional setup command run AFTER copying the workspace and BEFORE
	 * the agent starts. Use for `npm install` or similar one-time setup
	 * that shouldn't count toward the agent's work. Exit code 0 expected.
	 */
	readonly setup?: {
		readonly command: string;
		readonly timeoutMs?: number;
	};
	/**
	 * Optional cap on agent iterations. Default is whatever the runner's
	 * config says (typically 25-40).
	 */
	readonly maxIterations?: number;
}

export interface BenchResult {
	readonly task: BenchTask;
	/** "pass" — validate exited 0; "fail" — non-zero or timeout; "error" — runner-internal failure (agent crashed, setup failed). */
	readonly status: "pass" | "fail" | "error";
	/** Wall-clock duration of the full task (setup + agent + validate). */
	readonly durationMs: number;
	/** Agent-loop iterations actually consumed. */
	readonly iterations: number;
	/** Tokens consumed in the agent run (best-effort; null when provider doesn't report). */
	readonly tokens?: {
		readonly input: number;
		readonly output: number;
	};
	/** Validate-stage stdout (capped). Useful for diagnosing failures. */
	readonly validateStdout: string;
	/** Validate-stage stderr (capped). */
	readonly validateStderr: string;
	/** Path of the temp workspace directory used for the run. Useful for post-mortem. */
	readonly workspacePath: string;
	/** When status === "error", a short reason. */
	readonly errorReason?: string;
	/**
	 * List of file paths the agent mutated during the turn (collected via
	 * write_file / batch_file_edit tool calls). Empty when the agent
	 * never wrote anything — a strong signal of "investigated but
	 * didn't act."
	 */
	readonly mutatedPaths: readonly string[];
}

export interface BenchConfig {
	/** Provider endpoint URL — defaults to OPENAI_BASE_URL env var. */
	readonly providerUrl: string;
	/** Provider API key — defaults to OPENAI_API_KEY env var. */
	readonly providerKey: string;
	/** Model id — defaults to OATI_BENCH_MODEL env var or moonshotai/kimi-k2. */
	readonly modelId: string;
	/** Max parallel tasks (defaults to 1 — most benchmarks are sequential to avoid resource contention). */
	readonly concurrency?: number;
	/** Default max agent iterations per task; tasks may override. */
	readonly maxIterations?: number;
	/** Where to write the markdown report. */
	readonly reportPath: string;
	/** Where to write the raw JSONL of results. */
	readonly resultsPath: string;
	/**
	 * 2026-06-02: when set, cap the suite at the first N tasks (after
	 * filtering). Useful for SWE-bench Verified — running all 500 is a
	 * cluster-scale job; smoke-testing on 10 takes minutes.
	 */
	readonly limit?: number;
	/**
	 * 2026-06-02: skip the agent invocation entirely; run only setup +
	 * validate. Tells the user "does my environment even pass these
	 * tasks with the reference solution baked in?" — separates
	 * environment-setup failures from agent-capability failures
	 * BEFORE you burn tokens. Pass=task-is-already-correct (probably
	 * misconfigured), fail=task-is-broken-as-expected (good baseline).
	 */
	readonly validateOnly?: boolean;
}
