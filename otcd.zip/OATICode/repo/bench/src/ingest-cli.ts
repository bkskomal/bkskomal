import * as path from "node:path";
import { ingestSweBenchJsonl } from "./swe-bench-ingest";

/**
 * 2026-06-02: CLI wrapper for the SWE-bench Verified ingester. Reads
 * a JSONL file (downloaded from the SWE-bench Verified release on
 * HuggingFace) and writes per-task manifests under bench/tasks/swe/.
 *
 * Usage:
 *   node bench/dist/ingest-cli.cjs --path /path/to/swe-bench-verified.jsonl
 *   node bench/dist/ingest-cli.cjs --path ... --limit 20 --overwrite
 *
 * The output goes to `bench/tasks/swe/<instance_id>/` by default. After
 * ingestion, the normal bench runner can target the subset:
 *
 *   npm run bench --workspace=@oati/bench -- --filter swe-bench
 *   npm run bench --workspace=@oati/bench -- --filter swe-django
 *   npm run bench --workspace=@oati/bench -- --filter swe-django --limit 5
 *
 * Or smoke-test the environment without burning model tokens first:
 *
 *   npm run bench -- --filter swe-bench --validate-only --limit 3
 */
async function main() {
	const args = parseArgs(process.argv.slice(2));
	if (!args.path) {
		console.error("[ingest] --path <swe-bench-verified.jsonl> is required.");
		process.exit(2);
	}
	// __dirname when bundled is bench/dist/; bench root is ONE level up.
	const benchRoot = path.resolve(__dirname, "..");
	const outDir = args.outDir ?? path.join(benchRoot, "tasks", "swe");
	console.log(`[ingest] reading ${args.path}`);
	console.log(`[ingest] writing manifests to ${outDir}`);
	if (args.limit) console.log(`[ingest] limited to first ${args.limit} entries`);
	if (args.overwrite) console.log("[ingest] overwriting any existing manifests");
	const result = ingestSweBenchJsonl(args.path, {
		outDir,
		limit: args.limit,
		overwrite: args.overwrite,
	});
	console.log(
		`[ingest] DONE — wrote ${result.written}, skipped ${result.skipped}, errored ${result.errors.length}`,
	);
	if (result.errors.length > 0) {
		console.log("[ingest] first 5 errors:");
		for (const e of result.errors.slice(0, 5)) {
			console.log(`  - ${e.instanceId}: ${e.reason}`);
		}
	}
	process.exit(result.errors.length === 0 ? 0 : 1);
}

interface IngestCliArgs {
	path?: string;
	outDir?: string;
	limit?: number;
	overwrite?: boolean;
}

function parseArgs(argv: readonly string[]): IngestCliArgs {
	const out: IngestCliArgs = {};
	for (let i = 0; i < argv.length; i++) {
		const a = argv[i];
		const next = argv[i + 1];
		switch (a) {
			case "--path":
				out.path = next;
				i++;
				break;
			case "--out":
			case "--out-dir":
				out.outDir = next;
				i++;
				break;
			case "--limit":
				out.limit = Number(next);
				i++;
				break;
			case "--overwrite":
				out.overwrite = true;
				break;
			case "--help":
			case "-h":
				printHelp();
				process.exit(0);
				break;
		}
	}
	return out;
}

function printHelp() {
	console.log(`OATI Code — SWE-bench Verified ingester

Usage:
  node bench/dist/ingest-cli.cjs --path <swe-bench-verified.jsonl> [flags]

Flags:
  --path <file>         Path to the SWE-bench Verified JSONL file (required).
  --out <dir>           Output directory (default: bench/tasks/swe).
  --limit <n>           Only ingest the first N entries (smoke testing).
  --overwrite           Overwrite existing task manifests (default: skip).
  -h, --help            Show this help.

After ingestion, run the suite with the new SWE-bench tasks:
  npm run bench --workspace=@oati/bench -- --filter swe-bench --limit 5
`);
}

main().catch((err) => {
	console.error("[ingest] fatal:", err);
	process.exit(1);
});
