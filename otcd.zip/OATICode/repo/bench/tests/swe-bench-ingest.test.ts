import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	type SweBenchEntry,
	buildBenchTask,
	ingestSweBenchJsonl,
	parseTestList,
	slugifyInstanceId,
} from "../src/swe-bench-ingest";

// Minimal representative SWE-bench Verified entry shape. Real entries
// carry more fields (hints_text, env_install_commit, etc.) but those
// aren't used by the ingester.
const sample: SweBenchEntry = {
	instance_id: "django__django-12345",
	repo: "django/django",
	base_commit: "abc123def456",
	problem_statement:
		"BUG: QuerySet.filter() crashes when called with a Q() expression nested 3 deep.\n\nSteps to repro:\n1. Make a model\n2. Call .filter(Q(Q(Q(field='x'))))",
	test_patch:
		"diff --git a/tests/queries/test_q.py b/tests/queries/test_q.py\n+def test_nested_q...",
	FAIL_TO_PASS: JSON.stringify(["tests/queries/test_q.py::TestQ::test_nested"]),
	PASS_TO_PASS: JSON.stringify([
		"tests/queries/test_q.py::TestQ::test_basic",
		"tests/queries/test_q.py::TestQ::test_other",
	]),
	version: "5.0",
};

describe("slugifyInstanceId", () => {
	it("converts double-underscore to single dash", () => {
		expect(slugifyInstanceId("django__django-12345")).toBe("django-django-12345");
		expect(slugifyInstanceId("sympy__sympy-99")).toBe("sympy-sympy-99");
	});

	it("strips filesystem-unsafe characters", () => {
		expect(slugifyInstanceId("foo/bar:baz?")).toBe("foo-bar-baz-");
	});

	it("leaves clean ids unchanged", () => {
		expect(slugifyInstanceId("clean-id-42")).toBe("clean-id-42");
	});
});

describe("parseTestList", () => {
	it("parses a JSON-encoded array of strings", () => {
		expect(parseTestList('["a", "b", "c"]')).toEqual(["a", "b", "c"]);
	});

	it("returns [] for undefined", () => {
		expect(parseTestList(undefined)).toEqual([]);
	});

	it("returns [] for malformed JSON", () => {
		expect(parseTestList("not json")).toEqual([]);
	});

	it("returns [] for non-string array entries", () => {
		expect(parseTestList("[1, 2, 3]")).toEqual([]);
	});

	it("returns [] for non-array JSON", () => {
		expect(parseTestList('{"key": "val"}')).toEqual([]);
	});
});

describe("buildBenchTask", () => {
	it("produces a name with the swe- prefix and slugified instance_id", () => {
		const task = buildBenchTask(sample);
		expect(task.name).toBe("swe-django-django-12345");
	});

	it("derives the description from the first line of the problem statement", () => {
		const task = buildBenchTask(sample);
		expect(task.description).toContain("QuerySet.filter() crashes");
		expect(task.description.length).toBeLessThanOrEqual(200);
	});

	it("tags the task with swe-bench, python, and per-repo identifiers", () => {
		const task = buildBenchTask(sample);
		expect(task.tags).toContain("swe-bench");
		expect(task.tags).toContain("python");
		expect(task.tags).toContain("swe-django");
		expect(task.tags).toContain("swe-django"); // owner & repo collide → same string in this case
	});

	it("builds a setup command that clones the repo at the base commit", () => {
		const task = buildBenchTask(sample);
		expect(task.setup?.command).toContain("git init");
		expect(task.setup?.command).toContain("github.com/django/django.git");
		expect(task.setup?.command).toContain(sample.base_commit);
		// Applies the test_patch from the parent task dir.
		expect(task.setup?.command).toContain("../test_patch.diff");
		// Attempts to install the project.
		expect(task.setup?.command).toContain("pip install");
	});

	it("validate command runs the FAIL_TO_PASS tests by node id", () => {
		const task = buildBenchTask(sample);
		expect(task.validate.command).toContain("pytest");
		expect(task.validate.command).toContain("tests/queries/test_q.py::TestQ::test_nested");
	});

	it("falls back to a full pytest run when FAIL_TO_PASS is empty", () => {
		const task = buildBenchTask({ ...sample, FAIL_TO_PASS: undefined });
		expect(task.validate.command).toMatch(/python -m pytest -x\s*$/);
	});

	it("bumps maxIterations above the default (SWE-bench tasks need many turns)", () => {
		const task = buildBenchTask(sample);
		expect(task.maxIterations).toBeGreaterThan(30);
	});

	it("prompt includes the problem statement and a fix-and-verify framing", () => {
		const task = buildBenchTask(sample);
		expect(task.prompt).toContain("QuerySet.filter() crashes");
		expect(task.prompt).toContain("Investigate");
		// Must NOT mention SWE-bench (would leak the benchmark framing).
		expect(task.prompt).not.toMatch(/SWE.?bench/i);
	});
});

describe("ingestSweBenchJsonl (integration)", () => {
	let tmpDir: string;
	let jsonlPath: string;
	let outDir: string;

	beforeEach(() => {
		tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "oati-bench-ingest-"));
		jsonlPath = path.join(tmpDir, "swe-bench.jsonl");
		outDir = path.join(tmpDir, "out");
	});

	afterEach(() => {
		fs.rmSync(tmpDir, { recursive: true, force: true });
	});

	it("writes one task directory per JSONL entry", () => {
		const entries = [sample, { ...sample, instance_id: "sympy__sympy-99", repo: "sympy/sympy" }];
		fs.writeFileSync(jsonlPath, entries.map((e) => JSON.stringify(e)).join("\n"), "utf8");
		const result = ingestSweBenchJsonl(jsonlPath, { outDir });
		expect(result.written).toBe(2);
		expect(result.errors).toEqual([]);
		expect(fs.existsSync(path.join(outDir, "django-django-12345", "task.json"))).toBe(true);
		expect(fs.existsSync(path.join(outDir, "sympy-sympy-99", "task.json"))).toBe(true);
	});

	it("writes the test_patch as a sibling diff file", () => {
		fs.writeFileSync(jsonlPath, JSON.stringify(sample), "utf8");
		ingestSweBenchJsonl(jsonlPath, { outDir });
		const patchPath = path.join(outDir, "django-django-12345", "test_patch.diff");
		expect(fs.existsSync(patchPath)).toBe(true);
		expect(fs.readFileSync(patchPath, "utf8")).toContain("def test_nested_q");
	});

	it("writes a per-task README with the problem statement and pass criteria", () => {
		fs.writeFileSync(jsonlPath, JSON.stringify(sample), "utf8");
		ingestSweBenchJsonl(jsonlPath, { outDir });
		const readme = fs.readFileSync(path.join(outDir, "django-django-12345", "README.md"), "utf8");
		expect(readme).toContain("SWE-bench Verified");
		expect(readme).toContain("django/django");
		expect(readme).toContain("QuerySet.filter() crashes");
		expect(readme).toContain("test_nested");
	});

	it("respects --limit", () => {
		const entries = Array.from({ length: 10 }, (_, i) => ({
			...sample,
			instance_id: `repo__owner-${i}`,
		}));
		fs.writeFileSync(jsonlPath, entries.map((e) => JSON.stringify(e)).join("\n"), "utf8");
		const result = ingestSweBenchJsonl(jsonlPath, { outDir, limit: 3 });
		expect(result.written).toBe(3);
	});

	it("skips entries whose manifests already exist by default", () => {
		fs.writeFileSync(jsonlPath, JSON.stringify(sample), "utf8");
		ingestSweBenchJsonl(jsonlPath, { outDir });
		const second = ingestSweBenchJsonl(jsonlPath, { outDir });
		expect(second.written).toBe(0);
		expect(second.skipped).toBe(1);
	});

	it("overwrites existing manifests when --overwrite is set", () => {
		fs.writeFileSync(jsonlPath, JSON.stringify(sample), "utf8");
		ingestSweBenchJsonl(jsonlPath, { outDir });
		const second = ingestSweBenchJsonl(jsonlPath, { outDir, overwrite: true });
		expect(second.written).toBe(1);
		expect(second.skipped).toBe(0);
	});

	it("reports malformed JSONL lines without aborting the whole batch", () => {
		const lines = [
			JSON.stringify(sample),
			"this is not JSON",
			JSON.stringify({ ...sample, instance_id: "good__id-2" }),
		];
		fs.writeFileSync(jsonlPath, lines.join("\n"), "utf8");
		const result = ingestSweBenchJsonl(jsonlPath, { outDir });
		expect(result.written).toBe(2);
		expect(result.errors).toHaveLength(1);
		expect(result.errors[0].reason).toMatch(/JSON parse failed/);
	});
});
