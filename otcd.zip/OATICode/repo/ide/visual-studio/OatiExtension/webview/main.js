"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // ../../node_modules/preact/dist/preact.module.js
  var n;
  var l;
  var u;
  var t;
  var i;
  var r;
  var o;
  var e;
  var f;
  var c;
  var a;
  var s;
  var h;
  var p;
  var v;
  var y;
  var d = {};
  var w = [];
  var _ = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  var g = Array.isArray;
  function m(n3, l5) {
    for (var u4 in l5) n3[u4] = l5[u4];
    return n3;
  }
  function b(n3) {
    n3 && n3.parentNode && n3.parentNode.removeChild(n3);
  }
  function k(l5, u4, t4) {
    var i5, r4, o4, e4 = {};
    for (o4 in u4) "key" == o4 ? i5 = u4[o4] : "ref" == o4 ? r4 = u4[o4] : e4[o4] = u4[o4];
    if (arguments.length > 2 && (e4.children = arguments.length > 3 ? n.call(arguments, 2) : t4), "function" == typeof l5 && null != l5.defaultProps) for (o4 in l5.defaultProps) void 0 === e4[o4] && (e4[o4] = l5.defaultProps[o4]);
    return x(l5, e4, i5, r4, null);
  }
  function x(n3, t4, i5, r4, o4) {
    var e4 = { type: n3, props: t4, key: i5, ref: r4, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: null == o4 ? ++u : o4, __i: -1, __u: 0 };
    return null == o4 && null != l.vnode && l.vnode(e4), e4;
  }
  function S(n3) {
    return n3.children;
  }
  function C(n3, l5) {
    this.props = n3, this.context = l5;
  }
  function $(n3, l5) {
    if (null == l5) return n3.__ ? $(n3.__, n3.__i + 1) : null;
    for (var u4; l5 < n3.__k.length; l5++) if (null != (u4 = n3.__k[l5]) && null != u4.__e) return u4.__e;
    return "function" == typeof n3.type ? $(n3) : null;
  }
  function I(n3) {
    if (n3.__P && n3.__d) {
      var u4 = n3.__v, t4 = u4.__e, i5 = [], r4 = [], o4 = m({}, u4);
      o4.__v = u4.__v + 1, l.vnode && l.vnode(o4), q(n3.__P, o4, u4, n3.__n, n3.__P.namespaceURI, 32 & u4.__u ? [t4] : null, i5, null == t4 ? $(u4) : t4, !!(32 & u4.__u), r4), o4.__v = u4.__v, o4.__.__k[o4.__i] = o4, D(i5, o4, r4), u4.__e = u4.__ = null, o4.__e != t4 && P(o4);
    }
  }
  function P(n3) {
    if (null != (n3 = n3.__) && null != n3.__c) return n3.__e = n3.__c.base = null, n3.__k.some(function(l5) {
      if (null != l5 && null != l5.__e) return n3.__e = n3.__c.base = l5.__e;
    }), P(n3);
  }
  function A(n3) {
    (!n3.__d && (n3.__d = true) && i.push(n3) && !H.__r++ || r != l.debounceRendering) && ((r = l.debounceRendering) || o)(H);
  }
  function H() {
    try {
      for (var n3, l5 = 1; i.length; ) i.length > l5 && i.sort(e), n3 = i.shift(), l5 = i.length, I(n3);
    } finally {
      i.length = H.__r = 0;
    }
  }
  function L(n3, l5, u4, t4, i5, r4, o4, e4, f5, c4, a4) {
    var s5, h5, p5, v5, y4, _3, g3, m4 = t4 && t4.__k || w, b3 = l5.length;
    for (f5 = T(u4, l5, m4, f5, b3), s5 = 0; s5 < b3; s5++) null != (p5 = u4.__k[s5]) && (h5 = -1 != p5.__i && m4[p5.__i] || d, p5.__i = s5, _3 = q(n3, p5, h5, i5, r4, o4, e4, f5, c4, a4), v5 = p5.__e, p5.ref && h5.ref != p5.ref && (h5.ref && J(h5.ref, null, p5), a4.push(p5.ref, p5.__c || v5, p5)), null == y4 && null != v5 && (y4 = v5), (g3 = !!(4 & p5.__u)) || h5.__k === p5.__k ? (f5 = j(p5, f5, n3, g3), g3 && h5.__e && (h5.__e = null)) : "function" == typeof p5.type && void 0 !== _3 ? f5 = _3 : v5 && (f5 = v5.nextSibling), p5.__u &= -7);
    return u4.__e = y4, f5;
  }
  function T(n3, l5, u4, t4, i5) {
    var r4, o4, e4, f5, c4, a4 = u4.length, s5 = a4, h5 = 0;
    for (n3.__k = new Array(i5), r4 = 0; r4 < i5; r4++) null != (o4 = l5[r4]) && "boolean" != typeof o4 && "function" != typeof o4 ? ("string" == typeof o4 || "number" == typeof o4 || "bigint" == typeof o4 || o4.constructor == String ? o4 = n3.__k[r4] = x(null, o4, null, null, null) : g(o4) ? o4 = n3.__k[r4] = x(S, { children: o4 }, null, null, null) : void 0 === o4.constructor && o4.__b > 0 ? o4 = n3.__k[r4] = x(o4.type, o4.props, o4.key, o4.ref ? o4.ref : null, o4.__v) : n3.__k[r4] = o4, f5 = r4 + h5, o4.__ = n3, o4.__b = n3.__b + 1, e4 = null, -1 != (c4 = o4.__i = O(o4, u4, f5, s5)) && (s5--, (e4 = u4[c4]) && (e4.__u |= 2)), null == e4 || null == e4.__v ? (-1 == c4 && (i5 > a4 ? h5-- : i5 < a4 && h5++), "function" != typeof o4.type && (o4.__u |= 4)) : c4 != f5 && (c4 == f5 - 1 ? h5-- : c4 == f5 + 1 ? h5++ : (c4 > f5 ? h5-- : h5++, o4.__u |= 4))) : n3.__k[r4] = null;
    if (s5) for (r4 = 0; r4 < a4; r4++) null != (e4 = u4[r4]) && 0 == (2 & e4.__u) && (e4.__e == t4 && (t4 = $(e4)), K(e4, e4));
    return t4;
  }
  function j(n3, l5, u4, t4) {
    var i5, r4;
    if ("function" == typeof n3.type) {
      for (i5 = n3.__k, r4 = 0; i5 && r4 < i5.length; r4++) i5[r4] && (i5[r4].__ = n3, l5 = j(i5[r4], l5, u4, t4));
      return l5;
    }
    n3.__e != l5 && (t4 && (l5 && n3.type && !l5.parentNode && (l5 = $(n3)), u4.insertBefore(n3.__e, l5 || null)), l5 = n3.__e);
    do {
      l5 = l5 && l5.nextSibling;
    } while (null != l5 && 8 == l5.nodeType);
    return l5;
  }
  function O(n3, l5, u4, t4) {
    var i5, r4, o4, e4 = n3.key, f5 = n3.type, c4 = l5[u4], a4 = null != c4 && 0 == (2 & c4.__u);
    if (null === c4 && null == e4 || a4 && e4 == c4.key && f5 == c4.type) return u4;
    if (t4 > (a4 ? 1 : 0)) {
      for (i5 = u4 - 1, r4 = u4 + 1; i5 >= 0 || r4 < l5.length; ) if (null != (c4 = l5[o4 = i5 >= 0 ? i5-- : r4++]) && 0 == (2 & c4.__u) && e4 == c4.key && f5 == c4.type) return o4;
    }
    return -1;
  }
  function z(n3, l5, u4) {
    "-" == l5[0] ? n3.setProperty(l5, null == u4 ? "" : u4) : n3[l5] = null == u4 ? "" : "number" != typeof u4 || _.test(l5) ? u4 : u4 + "px";
  }
  function N(n3, l5, u4, t4, i5) {
    var r4, o4;
    n: if ("style" == l5) if ("string" == typeof u4) n3.style.cssText = u4;
    else {
      if ("string" == typeof t4 && (n3.style.cssText = t4 = ""), t4) for (l5 in t4) u4 && l5 in u4 || z(n3.style, l5, "");
      if (u4) for (l5 in u4) t4 && u4[l5] == t4[l5] || z(n3.style, l5, u4[l5]);
    }
    else if ("o" == l5[0] && "n" == l5[1]) r4 = l5 != (l5 = l5.replace(s, "$1")), o4 = l5.toLowerCase(), l5 = o4 in n3 || "onFocusOut" == l5 || "onFocusIn" == l5 ? o4.slice(2) : l5.slice(2), n3.l || (n3.l = {}), n3.l[l5 + r4] = u4, u4 ? t4 ? u4[a] = t4[a] : (u4[a] = h, n3.addEventListener(l5, r4 ? v : p, r4)) : n3.removeEventListener(l5, r4 ? v : p, r4);
    else {
      if ("http://www.w3.org/2000/svg" == i5) l5 = l5.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != l5 && "height" != l5 && "href" != l5 && "list" != l5 && "form" != l5 && "tabIndex" != l5 && "download" != l5 && "rowSpan" != l5 && "colSpan" != l5 && "role" != l5 && "popover" != l5 && l5 in n3) try {
        n3[l5] = null == u4 ? "" : u4;
        break n;
      } catch (n4) {
      }
      "function" == typeof u4 || (null == u4 || false === u4 && "-" != l5[4] ? n3.removeAttribute(l5) : n3.setAttribute(l5, "popover" == l5 && 1 == u4 ? "" : u4));
    }
  }
  function V(n3) {
    return function(u4) {
      if (this.l) {
        var t4 = this.l[u4.type + n3];
        if (null == u4[c]) u4[c] = h++;
        else if (u4[c] < t4[a]) return;
        return t4(l.event ? l.event(u4) : u4);
      }
    };
  }
  function q(n3, u4, t4, i5, r4, o4, e4, f5, c4, a4) {
    var s5, h5, p5, v5, y4, d5, _3, k3, x3, M, $2, I2, P2, A3, H2, T3 = u4.type;
    if (void 0 !== u4.constructor) return null;
    128 & t4.__u && (c4 = !!(32 & t4.__u), o4 = [f5 = u4.__e = t4.__e]), (s5 = l.__b) && s5(u4);
    n: if ("function" == typeof T3) try {
      if (k3 = u4.props, x3 = T3.prototype && T3.prototype.render, M = (s5 = T3.contextType) && i5[s5.__c], $2 = s5 ? M ? M.props.value : s5.__ : i5, t4.__c ? _3 = (h5 = u4.__c = t4.__c).__ = h5.__E : (x3 ? u4.__c = h5 = new T3(k3, $2) : (u4.__c = h5 = new C(k3, $2), h5.constructor = T3, h5.render = Q), M && M.sub(h5), h5.state || (h5.state = {}), h5.__n = i5, p5 = h5.__d = true, h5.__h = [], h5._sb = []), x3 && null == h5.__s && (h5.__s = h5.state), x3 && null != T3.getDerivedStateFromProps && (h5.__s == h5.state && (h5.__s = m({}, h5.__s)), m(h5.__s, T3.getDerivedStateFromProps(k3, h5.__s))), v5 = h5.props, y4 = h5.state, h5.__v = u4, p5) x3 && null == T3.getDerivedStateFromProps && null != h5.componentWillMount && h5.componentWillMount(), x3 && null != h5.componentDidMount && h5.__h.push(h5.componentDidMount);
      else {
        if (x3 && null == T3.getDerivedStateFromProps && k3 !== v5 && null != h5.componentWillReceiveProps && h5.componentWillReceiveProps(k3, $2), u4.__v == t4.__v || !h5.__e && null != h5.shouldComponentUpdate && false === h5.shouldComponentUpdate(k3, h5.__s, $2)) {
          u4.__v != t4.__v && (h5.props = k3, h5.state = h5.__s, h5.__d = false), u4.__e = t4.__e, u4.__k = t4.__k, u4.__k.some(function(n4) {
            n4 && (n4.__ = u4);
          }), w.push.apply(h5.__h, h5._sb), h5._sb = [], h5.__h.length && e4.push(h5);
          break n;
        }
        null != h5.componentWillUpdate && h5.componentWillUpdate(k3, h5.__s, $2), x3 && null != h5.componentDidUpdate && h5.__h.push(function() {
          h5.componentDidUpdate(v5, y4, d5);
        });
      }
      if (h5.context = $2, h5.props = k3, h5.__P = n3, h5.__e = false, I2 = l.__r, P2 = 0, x3) h5.state = h5.__s, h5.__d = false, I2 && I2(u4), s5 = h5.render(h5.props, h5.state, h5.context), w.push.apply(h5.__h, h5._sb), h5._sb = [];
      else do {
        h5.__d = false, I2 && I2(u4), s5 = h5.render(h5.props, h5.state, h5.context), h5.state = h5.__s;
      } while (h5.__d && ++P2 < 25);
      h5.state = h5.__s, null != h5.getChildContext && (i5 = m(m({}, i5), h5.getChildContext())), x3 && !p5 && null != h5.getSnapshotBeforeUpdate && (d5 = h5.getSnapshotBeforeUpdate(v5, y4)), A3 = null != s5 && s5.type === S && null == s5.key ? E(s5.props.children) : s5, f5 = L(n3, g(A3) ? A3 : [A3], u4, t4, i5, r4, o4, e4, f5, c4, a4), h5.base = u4.__e, u4.__u &= -161, h5.__h.length && e4.push(h5), _3 && (h5.__E = h5.__ = null);
    } catch (n4) {
      if (u4.__v = null, c4 || null != o4) if (n4.then) {
        for (u4.__u |= c4 ? 160 : 128; f5 && 8 == f5.nodeType && f5.nextSibling; ) f5 = f5.nextSibling;
        o4[o4.indexOf(f5)] = null, u4.__e = f5;
      } else {
        for (H2 = o4.length; H2--; ) b(o4[H2]);
        B(u4);
      }
      else u4.__e = t4.__e, u4.__k = t4.__k, n4.then || B(u4);
      l.__e(n4, u4, t4);
    }
    else null == o4 && u4.__v == t4.__v ? (u4.__k = t4.__k, u4.__e = t4.__e) : f5 = u4.__e = G(t4.__e, u4, t4, i5, r4, o4, e4, c4, a4);
    return (s5 = l.diffed) && s5(u4), 128 & u4.__u ? void 0 : f5;
  }
  function B(n3) {
    n3 && (n3.__c && (n3.__c.__e = true), n3.__k && n3.__k.some(B));
  }
  function D(n3, u4, t4) {
    for (var i5 = 0; i5 < t4.length; i5++) J(t4[i5], t4[++i5], t4[++i5]);
    l.__c && l.__c(u4, n3), n3.some(function(u5) {
      try {
        n3 = u5.__h, u5.__h = [], n3.some(function(n4) {
          n4.call(u5);
        });
      } catch (n4) {
        l.__e(n4, u5.__v);
      }
    });
  }
  function E(n3) {
    return "object" != typeof n3 || null == n3 || n3.__b > 0 ? n3 : g(n3) ? n3.map(E) : void 0 !== n3.constructor ? null : m({}, n3);
  }
  function G(u4, t4, i5, r4, o4, e4, f5, c4, a4) {
    var s5, h5, p5, v5, y4, w4, _3, m4 = i5.props || d, k3 = t4.props, x3 = t4.type;
    if ("svg" == x3 ? o4 = "http://www.w3.org/2000/svg" : "math" == x3 ? o4 = "http://www.w3.org/1998/Math/MathML" : o4 || (o4 = "http://www.w3.org/1999/xhtml"), null != e4) {
      for (s5 = 0; s5 < e4.length; s5++) if ((y4 = e4[s5]) && "setAttribute" in y4 == !!x3 && (x3 ? y4.localName == x3 : 3 == y4.nodeType)) {
        u4 = y4, e4[s5] = null;
        break;
      }
    }
    if (null == u4) {
      if (null == x3) return document.createTextNode(k3);
      u4 = document.createElementNS(o4, x3, k3.is && k3), c4 && (l.__m && l.__m(t4, e4), c4 = false), e4 = null;
    }
    if (null == x3) m4 === k3 || c4 && u4.data == k3 || (u4.data = k3);
    else {
      if (e4 = "textarea" == x3 && null != k3.defaultValue ? null : e4 && n.call(u4.childNodes), !c4 && null != e4) for (m4 = {}, s5 = 0; s5 < u4.attributes.length; s5++) m4[(y4 = u4.attributes[s5]).name] = y4.value;
      for (s5 in m4) y4 = m4[s5], "dangerouslySetInnerHTML" == s5 ? p5 = y4 : "children" == s5 || s5 in k3 || "value" == s5 && "defaultValue" in k3 || "checked" == s5 && "defaultChecked" in k3 || N(u4, s5, null, y4, o4);
      for (s5 in k3) y4 = k3[s5], "children" == s5 ? v5 = y4 : "dangerouslySetInnerHTML" == s5 ? h5 = y4 : "value" == s5 ? w4 = y4 : "checked" == s5 ? _3 = y4 : c4 && "function" != typeof y4 || m4[s5] === y4 || N(u4, s5, y4, m4[s5], o4);
      if (h5) c4 || p5 && (h5.__html == p5.__html || h5.__html == u4.innerHTML) || (u4.innerHTML = h5.__html), t4.__k = [];
      else if (p5 && (u4.innerHTML = ""), L("template" == t4.type ? u4.content : u4, g(v5) ? v5 : [v5], t4, i5, r4, "foreignObject" == x3 ? "http://www.w3.org/1999/xhtml" : o4, e4, f5, e4 ? e4[0] : i5.__k && $(i5, 0), c4, a4), null != e4) for (s5 = e4.length; s5--; ) b(e4[s5]);
      c4 && "textarea" != x3 || (s5 = "value", "progress" == x3 && null == w4 ? u4.removeAttribute("value") : null != w4 && (w4 !== u4[s5] || "progress" == x3 && !w4 || "option" == x3 && w4 != m4[s5]) && N(u4, s5, w4, m4[s5], o4), s5 = "checked", null != _3 && _3 != u4[s5] && N(u4, s5, _3, m4[s5], o4));
    }
    return u4;
  }
  function J(n3, u4, t4) {
    try {
      if ("function" == typeof n3) {
        var i5 = "function" == typeof n3.__u;
        i5 && n3.__u(), i5 && null == u4 || (n3.__u = n3(u4));
      } else n3.current = u4;
    } catch (n4) {
      l.__e(n4, t4);
    }
  }
  function K(n3, u4, t4) {
    var i5, r4;
    if (l.unmount && l.unmount(n3), (i5 = n3.ref) && (i5.current && i5.current != n3.__e || J(i5, null, u4)), null != (i5 = n3.__c)) {
      if (i5.componentWillUnmount) try {
        i5.componentWillUnmount();
      } catch (n4) {
        l.__e(n4, u4);
      }
      i5.base = i5.__P = null;
    }
    if (i5 = n3.__k) for (r4 = 0; r4 < i5.length; r4++) i5[r4] && K(i5[r4], u4, t4 || "function" != typeof n3.type);
    t4 || b(n3.__e), n3.__c = n3.__ = n3.__e = void 0;
  }
  function Q(n3, l5, u4) {
    return this.constructor(n3, u4);
  }
  function R(u4, t4, i5) {
    var r4, o4, e4, f5;
    t4 == document && (t4 = document.documentElement), l.__ && l.__(u4, t4), o4 = (r4 = "function" == typeof i5) ? null : i5 && i5.__k || t4.__k, e4 = [], f5 = [], q(t4, u4 = (!r4 && i5 || t4).__k = k(S, null, [u4]), o4 || d, d, t4.namespaceURI, !r4 && i5 ? [i5] : o4 ? null : t4.firstChild ? n.call(t4.childNodes) : null, e4, !r4 && i5 ? i5 : o4 ? o4.__e : t4.firstChild, r4, f5), D(e4, u4, f5);
  }
  n = w.slice, l = { __e: function(n3, l5, u4, t4) {
    for (var i5, r4, o4; l5 = l5.__; ) if ((i5 = l5.__c) && !i5.__) try {
      if ((r4 = i5.constructor) && null != r4.getDerivedStateFromError && (i5.setState(r4.getDerivedStateFromError(n3)), o4 = i5.__d), null != i5.componentDidCatch && (i5.componentDidCatch(n3, t4 || {}), o4 = i5.__d), o4) return i5.__E = i5;
    } catch (l6) {
      n3 = l6;
    }
    throw n3;
  } }, u = 0, t = function(n3) {
    return null != n3 && void 0 === n3.constructor;
  }, C.prototype.setState = function(n3, l5) {
    var u4;
    u4 = null != this.__s && this.__s != this.state ? this.__s : this.__s = m({}, this.state), "function" == typeof n3 && (n3 = n3(m({}, u4), this.props)), n3 && m(u4, n3), null != n3 && this.__v && (l5 && this._sb.push(l5), A(this));
  }, C.prototype.forceUpdate = function(n3) {
    this.__v && (this.__e = true, n3 && this.__h.push(n3), A(this));
  }, C.prototype.render = S, i = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e = function(n3, l5) {
    return n3.__v.__b - l5.__v.__b;
  }, H.__r = 0, f = Math.random().toString(8), c = "__d" + f, a = "__a" + f, s = /(PointerCapture)$|Capture$/i, h = 0, p = V(false), v = V(true), y = 0;

  // ../shared/src/config.ts
  var DEFAULT_CONFIG = {
    activeProviderId: "default",
    activeModeId: "code",
    providers: [
      {
        id: "default",
        type: "openai-compatible",
        displayName: "OpenAI Compatible",
        preset: "openai-compatible",
        baseUrl: "http://localhost:4000/v1",
        defaultModel: ""
      },
      // R3-B: Ollama (local) preset — ships out-of-the-box so users with a
      // running `ollama serve` can pick it from the provider dropdown without
      // having to type the baseUrl by hand. Cost-zero because it runs locally;
      // the pricing table simply has no entry for ollama model ids.
      {
        id: "ollama",
        type: "openai-compatible",
        displayName: "Ollama (local)",
        preset: "ollama",
        baseUrl: "http://localhost:11434/v1",
        defaultModel: "llama3.1:8b"
      }
    ],
    modes: [
      {
        id: "ask",
        displayName: "Ask",
        description: "Read-only Q&A \u2014 explore the codebase, no edits or shell commands.",
        systemPrompt: "You are OATI Code in read-only Q&A mode. Answer questions about the user's project using the read-only tools available to you. Never propose changes to files; if the user asks for changes, suggest switching to Code or Auto Edit mode.",
        enabledTools: ["read_file", "search_files", "workspace_context", "fetch_url"],
        enablePlanner: false,
        enableCritic: false,
        maxParallelAgents: 1,
        maxIterations: 12,
        temperature: 0.2
      },
      {
        id: "plan",
        displayName: "Plan",
        description: "Read-only investigation \u2014 produces a written plan, no edits.",
        systemPrompt: "You are OATI Code in planning mode. Investigate the user's project with read-only tools, then produce a clear step-by-step implementation plan. Do not edit files. End with a concise summary of the recommended approach and any open questions.",
        enabledTools: ["read_file", "search_files", "workspace_context", "fetch_url"],
        enablePlanner: true,
        // Critic is off by default — interactive modes follow the Claude/Cline
        // pattern: a single high-quality model output per turn, no separate
        // retry layer. Power users can re-enable it via Settings.
        enableCritic: false,
        maxParallelAgents: 1,
        maxIterations: 16,
        temperature: 0.2
      },
      {
        id: "code",
        displayName: "Code",
        description: "Edits with approval \u2014 you confirm every file write and shell command.",
        systemPrompt: "You are OATI Code, a careful agentic coding assistant. Use tools to inspect and modify the user's project. Always preview file changes before writing. You may use `spawn_agent` to delegate self-contained sub-tasks to a fresh sub-agent.",
        enabledTools: "all",
        enablePlanner: false,
        enableCritic: false,
        maxParallelAgents: 4,
        maxIterations: 20,
        temperature: 0.2
      },
      {
        id: "auto-edit",
        displayName: "Auto Edit",
        description: "Edits auto-approved; agent loops until done. Confirms destructive shell commands.",
        systemPrompt: [
          "You are OATI Code in auto-edit mode.",
          "",
          "## Operating loop",
          "- You run autonomously: keep iterating with tools until the user's task is complete. Do NOT stop after the first turn \u2014 verify the change, run tests if relevant, and only finish when the task is actually done or genuinely blocked.",
          "- File edits run without approval prompts. Always preview the change in chat before writing so the user has a trail.",
          "- Destructive shell commands (`rm -rf`, dropping data, `git push --force`, `git reset --hard`, `npm uninstall`, etc.) MUST be explained and confirmed before running.",
          "",
          "## Parallel work",
          "- For independent subtasks (e.g. updating N unrelated files, scanning multiple directories, running a checklist of investigations), use `spawn_parallel_agents` to fan out instead of doing them serially. Each sub-agent gets its own focused task description.",
          "- For a single self-contained sub-task, prefer `spawn_agent`. Reserve `spawn_parallel_agents` for true fanout (2+ truly independent tasks).",
          "",
          "## Recovery",
          "- On a tool error, diagnose the root cause and try a different approach. Don't bail just because one call failed \u2014 the loop exists so you can self-correct.",
          "- If you genuinely cannot proceed, summarize what was attempted, what failed, and what the user can do."
        ].join("\n"),
        enabledTools: "all",
        enablePlanner: false,
        // Critic off by default — see comment on Plan mode. Auto-Edit is
        // still interactive (user is watching); critic noise hurt more than
        // it helped during dogfooding.
        enableCritic: false,
        maxParallelAgents: 6,
        maxIterations: 40,
        temperature: 0.2,
        autoApprove: true
      },
      {
        id: "auto",
        displayName: "Auto",
        description: "Full agentic loop \u2014 planner + parallel agents, no approval prompts.",
        systemPrompt: [
          "You are OATI Code in Auto mode \u2014 the most aggressive agentic configuration.",
          "",
          "## Operating loop",
          "- You operate autonomously end-to-end. Keep iterating with tools until the user's task is genuinely complete. Don't stop after one round of changes \u2014 verify them with reads, tests, builds, or sanity checks as appropriate.",
          "- All edits and shell commands run without approval prompts. With that power, be deliberate: state what you're about to do for anything irreversible (force-pushes, destructive rm, dropping data, deleting branches) BEFORE doing it.",
          "- Self-correct as you go: after writing, read back. After running, check the output. The iteration cap exists so you can verify your own work in the same turn rather than relying on an external critic.",
          "",
          "## Parallel work \u2014 first-class strategy",
          "- The instant you identify 2+ independent subtasks, call `spawn_parallel_agents` with a task per sub-agent. Examples that should fan out:",
          "  \u2022 Updating N unrelated files with similar refactors (one agent per file).",
          "  \u2022 Investigating multiple subsystems in parallel (one agent per area).",
          "  \u2022 Running a batch of independent checks (one agent per check).",
          "- For a single sub-task that needs its own context window, use `spawn_agent`.",
          "- Serializing independent work wastes the loop budget \u2014 fan out aggressively.",
          "",
          "## Recovery",
          "- Tool errors are signals, not stop conditions. Diagnose and try again with a different approach. The iteration cap is high precisely so you can self-correct.",
          "- If you truly hit a wall, summarize what you tried, what blocked it, and the user's options. Don't fake completion."
        ].join("\n"),
        enabledTools: "all",
        enablePlanner: true,
        // Critic off by default to match Claude / Cline behavior. The
        // iteration cap is high enough that the model can self-correct
        // within a single turn (read back what it wrote, run tests, etc.)
        // without an external critic-retry layer adding noise.
        enableCritic: false,
        maxParallelAgents: 8,
        maxIterations: 80,
        maxRetries: 1,
        temperature: 0.2,
        autoApprove: true
      }
    ]
  };

  // ../shared/src/presets.ts
  var OPENROUTER_CODING_MODELS = [
    {
      id: "anthropic/claude-sonnet-4",
      label: "Claude Sonnet 4 (Anthropic)",
      note: "best all-rounder for coding"
    },
    {
      id: "anthropic/claude-opus-4",
      label: "Claude Opus 4 (Anthropic)",
      note: "highest quality, slower / pricier"
    },
    {
      id: "anthropic/claude-haiku-4-5",
      label: "Claude Haiku 4.5 (Anthropic)",
      note: "fast and cheap"
    },
    {
      id: "openai/gpt-4o",
      label: "GPT-4o (OpenAI)",
      note: "strong all-rounder"
    },
    {
      id: "openai/gpt-4o-mini",
      label: "GPT-4o mini (OpenAI)",
      note: "fast, very cheap"
    },
    {
      id: "openai/o3-mini",
      label: "o3-mini (OpenAI)",
      note: "reasoning, good for hard problems"
    },
    {
      id: "google/gemini-2.0-flash-001",
      label: "Gemini 2.0 Flash (Google)",
      note: "fast, large context"
    },
    {
      id: "google/gemini-2.0-pro-exp",
      label: "Gemini 2.0 Pro (Google)",
      note: "deeper reasoning"
    },
    {
      id: "deepseek/deepseek-r1",
      label: "DeepSeek R1",
      note: "open reasoning, often cheap on OpenRouter"
    },
    {
      id: "deepseek/deepseek-chat",
      label: "DeepSeek V3",
      note: "fast, code-strong, cheap"
    },
    {
      id: "qwen/qwen-2.5-coder-32b-instruct",
      label: "Qwen 2.5 Coder 32B (Alibaba)",
      note: "code-specialized"
    },
    {
      id: "meta-llama/llama-3.3-70b-instruct",
      label: "Llama 3.3 70B (Meta)",
      note: "open, broad coverage"
    },
    // --- Free tier ---
    {
      id: "deepseek/deepseek-r1:free",
      label: "DeepSeek R1 (free)",
      note: "reasoning, no cost",
      free: true
    },
    {
      id: "meta-llama/llama-3.3-70b-instruct:free",
      label: "Llama 3.3 70B (free)",
      note: "open weights, no cost",
      free: true
    },
    {
      id: "qwen/qwen-2.5-coder-32b-instruct:free",
      label: "Qwen 2.5 Coder 32B (free)",
      note: "code-specialized, no cost",
      free: true
    }
  ];
  var PROVIDER_PRESETS = [
    {
      id: "openai-compatible",
      providerType: "openai-compatible",
      displayName: "OpenAI Compatible",
      baseUrl: "",
      defaultModel: "",
      requiresApiKey: false,
      modelPlaceholder: "e.g. claude-sonnet-4-6, gpt-4o, etc.",
      baseUrlEditable: true,
      apiKeyHelp: "Optional. Set if your gateway requires it. Stored in VS Code's SecretStorage."
    },
    {
      id: "openai",
      providerType: "openai-compatible",
      displayName: "OpenAI",
      baseUrl: "https://api.openai.com/v1",
      defaultModel: "gpt-4o",
      requiresApiKey: true,
      modelPlaceholder: "gpt-4o, gpt-4o-mini, o3-mini",
      baseUrlEditable: false,
      curatedModels: [
        { id: "gpt-4o", label: "GPT-4o", note: "strong all-rounder" },
        { id: "gpt-4o-mini", label: "GPT-4o mini", note: "fast, cheap" },
        { id: "o3-mini", label: "o3-mini", note: "reasoning" },
        { id: "o3", label: "o3", note: "frontier reasoning" }
      ]
    },
    {
      id: "openrouter",
      providerType: "openai-compatible",
      displayName: "OpenRouter",
      baseUrl: "https://openrouter.ai/api/v1",
      defaultModel: "anthropic/claude-sonnet-4",
      requiresApiKey: true,
      modelPlaceholder: "e.g. anthropic/claude-sonnet-4, openai/gpt-4o",
      baseUrlEditable: false,
      extraHeaders: {
        "HTTP-Referer": "https://github.com/sbkkomal/codeassistant",
        "X-Title": "OATI Code"
      },
      curatedModels: OPENROUTER_CODING_MODELS
    },
    {
      id: "litellm",
      providerType: "openai-compatible",
      displayName: "LiteLLM",
      baseUrl: "http://localhost:4000/v1",
      defaultModel: "",
      requiresApiKey: false,
      modelPlaceholder: "model alias from your LiteLLM config",
      baseUrlEditable: true
    },
    {
      id: "unillm",
      providerType: "openai-compatible",
      displayName: "unillm",
      baseUrl: "http://localhost:8080/v1",
      defaultModel: "claude-sonnet-4-6",
      requiresApiKey: false,
      modelPlaceholder: "claude-sonnet-4-6",
      baseUrlEditable: true
    },
    {
      id: "ollama",
      providerType: "openai-compatible",
      displayName: "Ollama",
      baseUrl: "http://localhost:11434/v1",
      defaultModel: "qwen2.5-coder:7b",
      requiresApiKey: false,
      modelPlaceholder: "e.g. qwen2.5-coder:7b, llama3.3",
      baseUrlEditable: true
    },
    {
      id: "anthropic",
      providerType: "anthropic",
      displayName: "Anthropic (native)",
      baseUrl: "https://api.anthropic.com/v1",
      defaultModel: "claude-sonnet-4-6",
      requiresApiKey: true,
      modelPlaceholder: "claude-sonnet-4-6, claude-opus-4-7, claude-haiku-4-5-20251001",
      baseUrlEditable: false,
      apiKeyHelp: "Anthropic API key. Uses native /v1/messages format with x-api-key header. Stored in VS Code's SecretStorage.",
      curatedModels: [
        { id: "claude-sonnet-4-6", label: "Claude Sonnet 4.6", note: "fast, capable" },
        { id: "claude-opus-4-7", label: "Claude Opus 4.7", note: "frontier" },
        { id: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5", note: "cheap, fast" }
      ]
    },
    {
      id: "custom",
      providerType: "openai-compatible",
      displayName: "Custom",
      baseUrl: "",
      defaultModel: "",
      requiresApiKey: false,
      modelPlaceholder: "",
      baseUrlEditable: true
    }
  ];
  function getPreset(id) {
    return PROVIDER_PRESETS.find((p5) => p5.id === id) ?? PROVIDER_PRESETS[0];
  }

  // ../shared/src/mcp-presets.ts
  var MCP_SERVER_PRESETS = [
    {
      id: "filesystem",
      displayName: "Filesystem",
      description: "Read/write files in specified directories. Pass each allowed directory as an arg.",
      command: "npx",
      args: ["-y", "@modelcontextprotocol/server-filesystem", "."],
      approval: "prompt"
    },
    {
      id: "memory",
      displayName: "Memory (knowledge graph)",
      description: "Persist arbitrary facts and recall them across sessions. Useful for long-running projects.",
      command: "npx",
      args: ["-y", "@modelcontextprotocol/server-memory"],
      approval: "auto"
    },
    {
      id: "fetch",
      displayName: "Fetch",
      description: "HTTP fetch with content extraction. Returns markdown-ified page text. (Python-based; needs uvx.)",
      command: "uvx",
      args: ["mcp-server-fetch"],
      approval: "prompt"
    },
    {
      id: "sequential-thinking",
      displayName: "Sequential Thinking",
      description: "Structured multi-step reasoning aid. Helps the agent break down complex problems.",
      command: "npx",
      args: ["-y", "@modelcontextprotocol/server-sequential-thinking"],
      approval: "auto"
    },
    {
      id: "github",
      displayName: "GitHub",
      description: "Search repos, read issues/PRs, file ops on GitHub. Requires GITHUB_PERSONAL_ACCESS_TOKEN.",
      command: "npx",
      args: ["-y", "@modelcontextprotocol/server-github"],
      requiredEnvVars: ["GITHUB_PERSONAL_ACCESS_TOKEN"],
      approval: "prompt"
    },
    {
      id: "brave-search",
      displayName: "Brave Search",
      description: "Web search via Brave Search API. Requires BRAVE_API_KEY (free tier available).",
      command: "npx",
      args: ["-y", "@modelcontextprotocol/server-brave-search"],
      requiredEnvVars: ["BRAVE_API_KEY"],
      approval: "auto"
    },
    {
      id: "sqlite",
      displayName: "SQLite",
      description: "Query and manipulate a local SQLite database. Pass the .db file path as the last arg.",
      command: "uvx",
      args: ["mcp-server-sqlite", "--db-path", "./oati.db"],
      approval: "prompt"
    },
    {
      id: "puppeteer",
      displayName: "Puppeteer (browser)",
      description: "Headless Chromium for screenshots, scraping, and dynamic page interaction.",
      command: "npx",
      args: ["-y", "@modelcontextprotocol/server-puppeteer"],
      approval: "prompt"
    }
  ];
  function materializePreset(preset, overrides = {}) {
    return {
      id: overrides.id ?? `mcp_${preset.id}_${Date.now().toString(36)}`,
      displayName: preset.displayName,
      command: preset.command,
      args: [...preset.args],
      enabled: overrides.enabled ?? false,
      approval: preset.approval ?? "prompt"
    };
  }

  // ../shared/src/pricing.ts
  var MODEL_RATES = [
    {
      match: "claude-opus-4-7",
      displayName: "Claude Opus 4.7",
      inputPerMillion: 15,
      outputPerMillion: 75
    },
    {
      match: "claude-opus-4-6",
      displayName: "Claude Opus 4.6",
      inputPerMillion: 15,
      outputPerMillion: 75
    },
    { match: "claude-opus", displayName: "Claude Opus", inputPerMillion: 15, outputPerMillion: 75 },
    {
      match: "claude-sonnet-4-6",
      displayName: "Claude Sonnet 4.6",
      inputPerMillion: 3,
      outputPerMillion: 15
    },
    {
      match: "claude-sonnet-4",
      displayName: "Claude Sonnet 4",
      inputPerMillion: 3,
      outputPerMillion: 15
    },
    { match: "claude-sonnet", displayName: "Claude Sonnet", inputPerMillion: 3, outputPerMillion: 15 },
    {
      match: "claude-haiku-4-5",
      displayName: "Claude Haiku 4.5",
      inputPerMillion: 1,
      outputPerMillion: 5
    },
    { match: "claude-haiku", displayName: "Claude Haiku", inputPerMillion: 1, outputPerMillion: 5 },
    { match: "gpt-4o-mini", displayName: "GPT-4o mini", inputPerMillion: 0.15, outputPerMillion: 0.6 },
    { match: "gpt-4o", displayName: "GPT-4o", inputPerMillion: 2.5, outputPerMillion: 10 },
    { match: "o3-mini", displayName: "o3-mini", inputPerMillion: 1.1, outputPerMillion: 4.4 },
    { match: "o3", displayName: "o3", inputPerMillion: 2, outputPerMillion: 8 },
    { match: "gpt-4-turbo", displayName: "GPT-4 Turbo", inputPerMillion: 10, outputPerMillion: 30 },
    { match: "gpt-4", displayName: "GPT-4", inputPerMillion: 30, outputPerMillion: 60 },
    { match: "gpt-3.5", displayName: "GPT-3.5", inputPerMillion: 0.5, outputPerMillion: 1.5 }
  ];
  function findRate(modelId) {
    const id = modelId.toLowerCase();
    return MODEL_RATES.find((r4) => id.includes(r4.match));
  }
  function estimateCost(modelId, inputTokens, outputTokens) {
    const rate = findRate(modelId);
    if (!rate) return void 0;
    const inputUsd = inputTokens / 1e6 * rate.inputPerMillion;
    const outputUsd = outputTokens / 1e6 * rate.outputPerMillion;
    return {
      inputUsd,
      outputUsd,
      totalUsd: inputUsd + outputUsd,
      rate
    };
  }
  function formatUsd(amount) {
    if (amount < 0.01) return `$${amount.toFixed(4)}`;
    if (amount < 1) return `$${amount.toFixed(3)}`;
    return `$${amount.toFixed(2)}`;
  }

  // ../shared/src/ui-message.ts
  var STREAMING_OUTPUT_CAP = 64 * 1024;
  function pickPathFromArgs(args) {
    if (!args || typeof args !== "object") return void 0;
    const a4 = args;
    for (const k3 of ["path", "file", "filePath", "uri", "target"]) {
      const v5 = a4[k3];
      if (typeof v5 === "string" && v5.length > 0) return v5;
    }
    return void 0;
  }
  function summarizeToolArgs(name, args) {
    const path = pickPathFromArgs(args);
    if (path) return path;
    if (args && typeof args === "object") {
      const a4 = args;
      const lower = name.toLowerCase();
      if (lower.includes("exec") || lower.includes("run")) {
        const cmd = a4.command ?? a4.cmd;
        if (typeof cmd === "string") return cmd;
      }
      if (lower.includes("fetch")) {
        const url = a4.url;
        if (typeof url === "string") return url;
      }
      for (const k3 of ["query", "pattern", "description", "summary"]) {
        const v5 = a4[k3];
        if (typeof v5 === "string" && v5.length > 0) return v5;
      }
    }
    if (args !== void 0) {
      const s5 = JSON.stringify(args);
      return s5.length > 80 ? `${s5.slice(0, 80)}\u2026` : s5;
    }
    return void 0;
  }

  // ../../node_modules/preact/hooks/dist/hooks.module.js
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = 0;
  var f2 = [];
  var c2 = l;
  var e2 = c2.__b;
  var a2 = c2.__r;
  var v2 = c2.diffed;
  var l2 = c2.__c;
  var m2 = c2.unmount;
  var s2 = c2.__;
  function p2(n3, t4) {
    c2.__h && c2.__h(r2, n3, o2 || t4), o2 = 0;
    var u4 = r2.__H || (r2.__H = { __: [], __h: [] });
    return n3 >= u4.__.length && u4.__.push({}), u4.__[n3];
  }
  function d2(n3) {
    return o2 = 1, h2(D2, n3);
  }
  function h2(n3, u4, i5) {
    var o4 = p2(t2++, 2);
    if (o4.t = n3, !o4.__c && (o4.__ = [i5 ? i5(u4) : D2(void 0, u4), function(n4) {
      var t4 = o4.__N ? o4.__N[0] : o4.__[0], r4 = o4.t(t4, n4);
      t4 !== r4 && (o4.__N = [r4, o4.__[1]], o4.__c.setState({}));
    }], o4.__c = r2, !r2.__f)) {
      var f5 = function(n4, t4, r4) {
        if (!o4.__c.__H) return true;
        var u5 = o4.__c.__H.__.filter(function(n5) {
          return n5.__c;
        });
        if (u5.every(function(n5) {
          return !n5.__N;
        })) return !c4 || c4.call(this, n4, t4, r4);
        var i6 = o4.__c.props !== n4;
        return u5.some(function(n5) {
          if (n5.__N) {
            var t5 = n5.__[0];
            n5.__ = n5.__N, n5.__N = void 0, t5 !== n5.__[0] && (i6 = true);
          }
        }), c4 && c4.call(this, n4, t4, r4) || i6;
      };
      r2.__f = true;
      var c4 = r2.shouldComponentUpdate, e4 = r2.componentWillUpdate;
      r2.componentWillUpdate = function(n4, t4, r4) {
        if (this.__e) {
          var u5 = c4;
          c4 = void 0, f5(n4, t4, r4), c4 = u5;
        }
        e4 && e4.call(this, n4, t4, r4);
      }, r2.shouldComponentUpdate = f5;
    }
    return o4.__N || o4.__;
  }
  function y2(n3, u4) {
    var i5 = p2(t2++, 3);
    !c2.__s && C2(i5.__H, u4) && (i5.__ = n3, i5.u = u4, r2.__H.__h.push(i5));
  }
  function A2(n3) {
    return o2 = 5, T2(function() {
      return { current: n3 };
    }, []);
  }
  function T2(n3, r4) {
    var u4 = p2(t2++, 7);
    return C2(u4.__H, r4) && (u4.__ = n3(), u4.__H = r4, u4.__h = n3), u4.__;
  }
  function j2() {
    for (var n3; n3 = f2.shift(); ) {
      var t4 = n3.__H;
      if (n3.__P && t4) try {
        t4.__h.some(z2), t4.__h.some(B2), t4.__h = [];
      } catch (r4) {
        t4.__h = [], c2.__e(r4, n3.__v);
      }
    }
  }
  c2.__b = function(n3) {
    r2 = null, e2 && e2(n3);
  }, c2.__ = function(n3, t4) {
    n3 && t4.__k && t4.__k.__m && (n3.__m = t4.__k.__m), s2 && s2(n3, t4);
  }, c2.__r = function(n3) {
    a2 && a2(n3), t2 = 0;
    var i5 = (r2 = n3.__c).__H;
    i5 && (u2 === r2 ? (i5.__h = [], r2.__h = [], i5.__.some(function(n4) {
      n4.__N && (n4.__ = n4.__N), n4.u = n4.__N = void 0;
    })) : (i5.__h.some(z2), i5.__h.some(B2), i5.__h = [], t2 = 0)), u2 = r2;
  }, c2.diffed = function(n3) {
    v2 && v2(n3);
    var t4 = n3.__c;
    t4 && t4.__H && (t4.__H.__h.length && (1 !== f2.push(t4) && i2 === c2.requestAnimationFrame || ((i2 = c2.requestAnimationFrame) || w2)(j2)), t4.__H.__.some(function(n4) {
      n4.u && (n4.__H = n4.u), n4.u = void 0;
    })), u2 = r2 = null;
  }, c2.__c = function(n3, t4) {
    t4.some(function(n4) {
      try {
        n4.__h.some(z2), n4.__h = n4.__h.filter(function(n5) {
          return !n5.__ || B2(n5);
        });
      } catch (r4) {
        t4.some(function(n5) {
          n5.__h && (n5.__h = []);
        }), t4 = [], c2.__e(r4, n4.__v);
      }
    }), l2 && l2(n3, t4);
  }, c2.unmount = function(n3) {
    m2 && m2(n3);
    var t4, r4 = n3.__c;
    r4 && r4.__H && (r4.__H.__.some(function(n4) {
      try {
        z2(n4);
      } catch (n5) {
        t4 = n5;
      }
    }), r4.__H = void 0, t4 && c2.__e(t4, r4.__v));
  };
  var k2 = "function" == typeof requestAnimationFrame;
  function w2(n3) {
    var t4, r4 = function() {
      clearTimeout(u4), k2 && cancelAnimationFrame(t4), setTimeout(n3);
    }, u4 = setTimeout(r4, 35);
    k2 && (t4 = requestAnimationFrame(r4));
  }
  function z2(n3) {
    var t4 = r2, u4 = n3.__c;
    "function" == typeof u4 && (n3.__c = void 0, u4()), r2 = t4;
  }
  function B2(n3) {
    var t4 = r2;
    n3.__c = n3.__(), r2 = t4;
  }
  function C2(n3, t4) {
    return !n3 || n3.length !== t4.length || t4.some(function(t5, r4) {
      return t5 !== n3[r4];
    });
  }
  function D2(n3, t4) {
    return "function" == typeof t4 ? t4(n3) : t4;
  }

  // ../../node_modules/@preact/signals-core/dist/signals-core.module.js
  var i3 = Symbol.for("preact-signals");
  function t3() {
    if (!(s3 > 1)) {
      var i5, t4 = false;
      !function() {
        var i6 = c3;
        c3 = void 0;
        while (void 0 !== i6) {
          if (i6.S.v === i6.v) i6.S.i = i6.i;
          i6 = i6.o;
        }
      }();
      while (void 0 !== h3) {
        var n3 = h3;
        h3 = void 0;
        v3++;
        while (void 0 !== n3) {
          var r4 = n3.u;
          n3.u = void 0;
          n3.f &= -3;
          if (!(8 & n3.f) && w3(n3)) try {
            n3.c();
          } catch (n4) {
            if (!t4) {
              i5 = n4;
              t4 = true;
            }
          }
          n3 = r4;
        }
      }
      v3 = 0;
      s3--;
      if (t4) throw i5;
    } else s3--;
  }
  var r3 = void 0;
  function o3(i5) {
    var t4 = r3;
    r3 = void 0;
    try {
      return i5();
    } finally {
      r3 = t4;
    }
  }
  var f3;
  var h3 = void 0;
  var s3 = 0;
  var v3 = 0;
  var e3 = 0;
  var c3 = void 0;
  var d3 = 0;
  function a3(i5) {
    if (void 0 !== r3) {
      var t4 = i5.n;
      if (void 0 === t4 || t4.t !== r3) {
        t4 = { i: 0, S: i5, p: r3.s, n: void 0, t: r3, e: void 0, x: void 0, r: t4 };
        if (void 0 !== r3.s) r3.s.n = t4;
        r3.s = t4;
        i5.n = t4;
        if (32 & r3.f) i5.S(t4);
        return t4;
      } else if (-1 === t4.i) {
        t4.i = 0;
        if (void 0 !== t4.n) {
          t4.n.p = t4.p;
          if (void 0 !== t4.p) t4.p.n = t4.n;
          t4.p = r3.s;
          t4.n = void 0;
          r3.s.n = t4;
          r3.s = t4;
        }
        return t4;
      }
    }
  }
  function l3(i5, t4) {
    this.v = i5;
    this.i = 0;
    this.n = void 0;
    this.t = void 0;
    this.l = 0;
    this.W = null == t4 ? void 0 : t4.watched;
    this.Z = null == t4 ? void 0 : t4.unwatched;
    this.name = null == t4 ? void 0 : t4.name;
  }
  l3.prototype.brand = i3;
  l3.prototype.h = function() {
    return true;
  };
  l3.prototype.S = function(i5) {
    var t4 = this, n3 = this.t;
    if (n3 !== i5 && void 0 === i5.e) {
      i5.x = n3;
      this.t = i5;
      if (void 0 !== n3) n3.e = i5;
      else o3(function() {
        var i6;
        null == (i6 = t4.W) || i6.call(t4);
      });
    }
  };
  l3.prototype.U = function(i5) {
    var t4 = this;
    if (void 0 !== this.t) {
      var n3 = i5.e, r4 = i5.x;
      if (void 0 !== n3) {
        n3.x = r4;
        i5.e = void 0;
      }
      if (void 0 !== r4) {
        r4.e = n3;
        i5.x = void 0;
      }
      if (i5 === this.t) {
        this.t = r4;
        if (void 0 === r4) o3(function() {
          var i6;
          null == (i6 = t4.Z) || i6.call(t4);
        });
      }
    }
  };
  l3.prototype.subscribe = function(i5) {
    var t4 = this;
    return j3(function() {
      var n3 = t4.value, o4 = r3;
      r3 = void 0;
      try {
        i5(n3);
      } finally {
        r3 = o4;
      }
    }, { name: "sub" });
  };
  l3.prototype.valueOf = function() {
    return this.value;
  };
  l3.prototype.toString = function() {
    return this.value + "";
  };
  l3.prototype.toJSON = function() {
    return this.value;
  };
  l3.prototype.peek = function() {
    var i5 = this;
    return o3(function() {
      return i5.value;
    });
  };
  Object.defineProperty(l3.prototype, "value", { get: function() {
    var i5 = a3(this);
    if (void 0 !== i5) i5.i = this.i;
    return this.v;
  }, set: function(i5) {
    if (i5 !== this.v) {
      if (v3 > 100) throw new Error("Cycle detected");
      !function(i6) {
        if (0 !== s3 && 0 === v3) {
          if (i6.l !== e3) {
            i6.l = e3;
            c3 = { S: i6, v: i6.v, i: i6.i, o: c3 };
          }
        }
      }(this);
      this.v = i5;
      this.i++;
      d3++;
      s3++;
      try {
        for (var n3 = this.t; void 0 !== n3; n3 = n3.x) n3.t.N();
      } finally {
        t3();
      }
    }
  } });
  function y3(i5, t4) {
    return new l3(i5, t4);
  }
  function w3(i5) {
    for (var t4 = i5.s; void 0 !== t4; t4 = t4.n) if (t4.S.i !== t4.i || !t4.S.h() || t4.S.i !== t4.i) return true;
    return false;
  }
  function _2(i5) {
    for (var t4 = i5.s; void 0 !== t4; t4 = t4.n) {
      var n3 = t4.S.n;
      if (void 0 !== n3) t4.r = n3;
      t4.S.n = t4;
      t4.i = -1;
      if (void 0 === t4.n) {
        i5.s = t4;
        break;
      }
    }
  }
  function b2(i5) {
    var t4 = i5.s, n3 = void 0;
    while (void 0 !== t4) {
      var r4 = t4.p;
      if (-1 === t4.i) {
        t4.S.U(t4);
        if (void 0 !== r4) r4.n = t4.n;
        if (void 0 !== t4.n) t4.n.p = r4;
      } else n3 = t4;
      t4.S.n = t4.r;
      if (void 0 !== t4.r) t4.r = void 0;
      t4 = r4;
    }
    i5.s = n3;
  }
  function p3(i5, t4) {
    l3.call(this, void 0);
    this.x = i5;
    this.s = void 0;
    this.g = d3 - 1;
    this.f = 4;
    this.W = null == t4 ? void 0 : t4.watched;
    this.Z = null == t4 ? void 0 : t4.unwatched;
    this.name = null == t4 ? void 0 : t4.name;
  }
  p3.prototype = new l3();
  p3.prototype.h = function() {
    this.f &= -3;
    if (1 & this.f) return false;
    if (32 == (36 & this.f)) return true;
    this.f &= -5;
    if (this.g === d3) return true;
    this.g = d3;
    this.f |= 1;
    if (this.i > 0 && !w3(this)) {
      this.f &= -2;
      return true;
    }
    var i5 = r3;
    try {
      _2(this);
      r3 = this;
      var t4 = this.x();
      if (16 & this.f || this.v !== t4 || 0 === this.i) {
        this.v = t4;
        this.f &= -17;
        this.i++;
      }
    } catch (i6) {
      this.v = i6;
      this.f |= 16;
      this.i++;
    }
    r3 = i5;
    b2(this);
    this.f &= -2;
    return true;
  };
  p3.prototype.S = function(i5) {
    if (void 0 === this.t) {
      this.f |= 36;
      for (var t4 = this.s; void 0 !== t4; t4 = t4.n) t4.S.S(t4);
    }
    l3.prototype.S.call(this, i5);
  };
  p3.prototype.U = function(i5) {
    if (void 0 !== this.t) {
      l3.prototype.U.call(this, i5);
      if (void 0 === this.t) {
        this.f &= -33;
        for (var t4 = this.s; void 0 !== t4; t4 = t4.n) t4.S.U(t4);
      }
    }
  };
  p3.prototype.N = function() {
    if (!(2 & this.f)) {
      this.f |= 6;
      for (var i5 = this.t; void 0 !== i5; i5 = i5.x) i5.t.N();
    }
  };
  Object.defineProperty(p3.prototype, "value", { get: function() {
    if (1 & this.f) throw new Error("Cycle detected");
    var i5 = a3(this);
    this.h();
    if (void 0 !== i5) i5.i = this.i;
    if (16 & this.f) throw this.v;
    return this.v;
  } });
  function g2(i5, t4) {
    return new p3(i5, t4);
  }
  function S2(i5) {
    var n3 = i5.m;
    i5.m = void 0;
    if ("function" == typeof n3) {
      s3++;
      var o4 = r3;
      r3 = void 0;
      try {
        n3();
      } catch (t4) {
        i5.f &= -2;
        i5.f |= 8;
        m3(i5);
        throw t4;
      } finally {
        r3 = o4;
        t3();
      }
    }
  }
  function m3(i5) {
    for (var t4 = i5.s; void 0 !== t4; t4 = t4.n) t4.S.U(t4);
    i5.x = void 0;
    i5.s = void 0;
    S2(i5);
  }
  function x2(i5) {
    if (r3 !== this) throw new Error("Out-of-order effect");
    b2(this);
    r3 = i5;
    this.f &= -2;
    if (8 & this.f) m3(this);
    t3();
  }
  function E2(i5, t4) {
    this.x = i5;
    this.m = void 0;
    this.s = void 0;
    this.u = void 0;
    this.f = 32;
    this.name = null == t4 ? void 0 : t4.name;
    if (f3) f3.push(this);
  }
  E2.prototype.c = function() {
    var i5 = this.S();
    try {
      if (8 & this.f) return;
      if (void 0 === this.x) return;
      var t4 = this.x();
      if ("function" == typeof t4) this.m = t4;
    } finally {
      i5();
    }
  };
  E2.prototype.S = function() {
    if (1 & this.f) throw new Error("Cycle detected");
    this.f |= 1;
    this.f &= -9;
    S2(this);
    _2(this);
    s3++;
    var i5 = r3;
    r3 = this;
    return x2.bind(this, i5);
  };
  E2.prototype.N = function() {
    if (!(2 & this.f)) {
      this.f |= 2;
      this.u = h3;
      h3 = this;
    }
  };
  E2.prototype.d = function() {
    this.f |= 8;
    if (!(1 & this.f)) m3(this);
  };
  E2.prototype.dispose = function() {
    this.d();
  };
  function j3(i5, t4) {
    var n3 = new E2(i5, t4);
    try {
      n3.c();
    } catch (i6) {
      n3.d();
      throw i6;
    }
    var r4 = n3.d.bind(n3);
    r4[Symbol.dispose] = r4;
    return r4;
  }

  // ../../node_modules/@preact/signals/dist/signals.module.js
  var v4;
  var s4;
  function l4(i5, n3) {
    l[i5] = n3.bind(null, l[i5] || function() {
    });
  }
  function d4(i5) {
    if (s4) {
      var r4 = s4;
      s4 = void 0;
      r4();
    }
    s4 = i5 && i5.S();
  }
  function h4(i5) {
    var r4 = this, f5 = i5.data, o4 = useSignal(f5);
    o4.value = f5;
    var e4 = T2(function() {
      var i6 = r4.__v;
      while (i6 = i6.__) if (i6.__c) {
        i6.__c.__$f |= 4;
        break;
      }
      r4.__$u.c = function() {
        var i7, t4 = r4.__$u.S(), f6 = e4.value;
        t4();
        if (t(f6) || 3 !== (null == (i7 = r4.base) ? void 0 : i7.nodeType)) {
          r4.__$f |= 1;
          r4.setState({});
        } else r4.base.data = f6;
      };
      return g2(function() {
        var i7 = o4.value.value;
        return 0 === i7 ? 0 : true === i7 ? "" : i7 || "";
      });
    }, []);
    return e4.value;
  }
  h4.displayName = "_st";
  Object.defineProperties(l3.prototype, { constructor: { configurable: true, value: void 0 }, type: { configurable: true, value: h4 }, props: { configurable: true, get: function() {
    return { data: this };
  } }, __b: { configurable: true, value: 1 } });
  l4("__b", function(i5, r4) {
    if ("string" == typeof r4.type) {
      var n3, t4 = r4.props;
      for (var f5 in t4) if ("children" !== f5) {
        var o4 = t4[f5];
        if (o4 instanceof l3) {
          if (!n3) r4.__np = n3 = {};
          n3[f5] = o4;
          t4[f5] = o4.peek();
        }
      }
    }
    i5(r4);
  });
  l4("__r", function(i5, r4) {
    i5(r4);
    d4();
    var n3, t4 = r4.__c;
    if (t4) {
      t4.__$f &= -2;
      if (void 0 === (n3 = t4.__$u)) t4.__$u = n3 = function(i6) {
        var r5;
        j3(function() {
          r5 = this;
        });
        r5.c = function() {
          t4.__$f |= 1;
          t4.setState({});
        };
        return r5;
      }();
    }
    v4 = t4;
    d4(n3);
  });
  l4("__e", function(i5, r4, n3, t4) {
    d4();
    v4 = void 0;
    i5(r4, n3, t4);
  });
  l4("diffed", function(i5, r4) {
    d4();
    v4 = void 0;
    var n3;
    if ("string" == typeof r4.type && (n3 = r4.__e)) {
      var t4 = r4.__np, f5 = r4.props;
      if (t4) {
        var o4 = n3.U;
        if (o4) for (var e4 in o4) {
          var u4 = o4[e4];
          if (void 0 !== u4 && !(e4 in t4)) {
            u4.d();
            o4[e4] = void 0;
          }
        }
        else n3.U = o4 = {};
        for (var a4 in t4) {
          var c4 = o4[a4], s5 = t4[a4];
          if (void 0 === c4) {
            c4 = p4(n3, a4, s5, f5);
            o4[a4] = c4;
          } else c4.o(s5, f5);
        }
      }
    }
    i5(r4);
  });
  function p4(i5, r4, n3, t4) {
    var f5 = r4 in i5 && void 0 === i5.ownerSVGElement, o4 = y3(n3);
    return { o: function(i6, r5) {
      o4.value = i6;
      t4 = r5;
    }, d: j3(function() {
      var n4 = o4.value.value;
      if (t4[r4] !== n4) {
        t4[r4] = n4;
        if (f5) i5[r4] = n4;
        else if (n4) i5.setAttribute(r4, n4);
        else i5.removeAttribute(r4);
      }
    }) };
  }
  l4("unmount", function(i5, r4) {
    if ("string" == typeof r4.type) {
      var n3 = r4.__e;
      if (n3) {
        var t4 = n3.U;
        if (t4) {
          n3.U = void 0;
          for (var f5 in t4) {
            var o4 = t4[f5];
            if (o4) o4.d();
          }
        }
      }
    } else {
      var e4 = r4.__c;
      if (e4) {
        var u4 = e4.__$u;
        if (u4) {
          e4.__$u = void 0;
          u4.d();
        }
      }
    }
    i5(r4);
  });
  l4("__h", function(i5, r4, n3, t4) {
    if (t4 < 3 || 9 === t4) r4.__$f |= 2;
    i5(r4, n3, t4);
  });
  C.prototype.shouldComponentUpdate = function(i5, r4) {
    if (this.__R) return true;
    var n3 = this.__$u, t4 = n3 && void 0 !== n3.s;
    for (var f5 in r4) return true;
    if (this.__f || "boolean" == typeof this.u && true === this.u) {
      if (!(t4 || 2 & this.__$f || 4 & this.__$f)) return true;
      if (1 & this.__$f) return true;
    } else {
      if (!(t4 || 4 & this.__$f)) return true;
      if (3 & this.__$f) return true;
    }
    for (var o4 in i5) if ("__source" !== o4 && i5[o4] !== this.props[o4]) return true;
    for (var e4 in this.props) if (!(e4 in i5)) return true;
    return false;
  };
  function useSignal(i5) {
    return T2(function() {
      return y3(i5);
    }, []);
  }
  function useComputed(i5) {
    var r4 = A2(i5);
    r4.current = i5;
    v4.__$f |= 4;
    return T2(function() {
      return g2(function() {
        return r4.current();
      });
    }, []);
  }

  // ../../node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
  var f4 = 0;
  var i4 = Array.isArray;
  function u3(e4, t4, n3, o4, i5, u4) {
    t4 || (t4 = {});
    var a4, c4, p5 = t4;
    if ("ref" in p5) for (c4 in p5 = {}, t4) "ref" == c4 ? a4 = t4[c4] : p5[c4] = t4[c4];
    var l5 = { type: e4, props: p5, key: n3, ref: a4, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --f4, __i: -1, __u: 0, __source: i5, __self: u4 };
    if ("function" == typeof e4 && (a4 = e4.defaultProps)) for (c4 in a4) void 0 === p5[c4] && (p5[c4] = a4[c4]);
    return l.vnode && l.vnode(l5), l5;
  }

  // src/components/approval-dialog.tsx
  function ApprovalDialog({ request, onApprove, onDeny }) {
    const diff = request.preview?.diff;
    return /* @__PURE__ */ u3("div", { class: "oati-approval", children: [
      /* @__PURE__ */ u3("div", { class: "oati-approval-title", children: [
        "Approve ",
        /* @__PURE__ */ u3("code", { children: request.toolName }),
        "?"
      ] }),
      request.summary && /* @__PURE__ */ u3("div", { class: "oati-approval-summary", children: request.summary }),
      diff ? /* @__PURE__ */ u3("div", { class: "oati-approval-diff", children: [
        /* @__PURE__ */ u3("div", { class: "oati-approval-diff-path", children: diff.path }),
        /* @__PURE__ */ u3(InlineDiff, { before: diff.before, after: diff.after })
      ] }) : /* @__PURE__ */ u3("pre", { class: "oati-approval-args", children: JSON.stringify(request.args, null, 2) }),
      request.preview?.note && /* @__PURE__ */ u3("div", { class: "oati-approval-note", children: request.preview.note }),
      /* @__PURE__ */ u3("div", { class: "oati-approval-actions", children: [
        /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-approve", onClick: onApprove, children: "Approve" }),
        /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-deny", onClick: onDeny, children: "Deny" })
      ] })
    ] });
  }
  function InlineDiff({ before, after }) {
    const beforeLines = before.split("\n");
    const afterLines = after.split("\n");
    const beforeSet = new Set(beforeLines);
    const afterSet = new Set(afterLines);
    const rows = [];
    let i5 = 0;
    let j4 = 0;
    while (i5 < beforeLines.length || j4 < afterLines.length) {
      const a4 = beforeLines[i5];
      const b3 = afterLines[j4];
      if (i5 >= beforeLines.length) {
        rows.push({ sign: "+", text: b3 });
        j4++;
      } else if (j4 >= afterLines.length) {
        rows.push({ sign: "-", text: a4 });
        i5++;
      } else if (a4 === b3) {
        rows.push({ sign: " ", text: a4 });
        i5++;
        j4++;
      } else if (!afterSet.has(a4)) {
        rows.push({ sign: "-", text: a4 });
        i5++;
      } else if (!beforeSet.has(b3)) {
        rows.push({ sign: "+", text: b3 });
        j4++;
      } else {
        rows.push({ sign: " ", text: a4 });
        i5++;
        j4++;
      }
    }
    const maxRows = 60;
    const display = rows.length > maxRows ? rows.slice(0, maxRows) : rows;
    const truncated = rows.length > maxRows;
    return /* @__PURE__ */ u3("div", { class: "oati-inline-diff", children: [
      display.map((r4, idx) => /* @__PURE__ */ u3(
        "div",
        {
          class: `oati-diff-row oati-diff-${r4.sign === "+" ? "add" : r4.sign === "-" ? "del" : "ctx"}`,
          children: [
            /* @__PURE__ */ u3("span", { class: "oati-diff-sign", children: r4.sign }),
            /* @__PURE__ */ u3("span", { class: "oati-diff-text", children: r4.text })
          ]
        },
        `${idx}-${r4.sign}`
      )),
      truncated && /* @__PURE__ */ u3("div", { class: "oati-diff-truncated", children: [
        "\u2026 ",
        rows.length - maxRows,
        " more lines (see VS Code diff editor)"
      ] })
    ] });
  }

  // src/components/icons.tsx
  function svgProps(size, className) {
    return {
      xmlns: "http://www.w3.org/2000/svg",
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      "stroke-width": "1.8",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "aria-hidden": true,
      class: className
    };
  }
  function SendIcon({ size = 16, class: className, title = "Send" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("path", { d: "M22 2 11 13" }),
      /* @__PURE__ */ u3("path", { d: "M22 2 15 22l-4-9-9-4 20-7Z" })
    ] });
  }
  function StopIcon({ size = 16, class: className, title = "Stop" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("rect", { x: "6", y: "6", width: "12", height: "12", rx: "1.5" })
    ] });
  }
  function PaperclipIcon({ size = 16, class: className, title = "Attach" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("path", { d: "m21.44 11.05-9.19 9.19a6 6 0 1 1-8.49-8.49l9.19-9.19a4 4 0 1 1 5.66 5.66l-9.2 9.19a2 2 0 1 1-2.83-2.83l8.49-8.48" })
    ] });
  }
  function CopyIcon({ size = 14, class: className, title = "Copy" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2" }),
      /* @__PURE__ */ u3("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })
    ] });
  }
  function CheckIcon({ size = 14, class: className, title = "Done" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("path", { d: "M20 6 9 17l-5-5" })
    ] });
  }
  function XIcon({ size = 14, class: className, title = "Close" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("path", { d: "M18 6 6 18M6 6l12 12" })
    ] });
  }
  function FileIcon({ size = 14, class: className, title = "File" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("path", { d: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }),
      /* @__PURE__ */ u3("path", { d: "M14 2v6h6" })
    ] });
  }
  function MicIcon({ size = 16, class: className, title = "Voice input" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("rect", { x: "9", y: "2", width: "6", height: "13", rx: "3" }),
      /* @__PURE__ */ u3("path", { d: "M5 11a7 7 0 0 0 14 0" }),
      /* @__PURE__ */ u3("path", { d: "M12 18v4" }),
      /* @__PURE__ */ u3("path", { d: "M8 22h8" })
    ] });
  }
  function EditIcon({ size = 16, class: className, title = "Rename" }) {
    return /* @__PURE__ */ u3("svg", { ...svgProps(size, className), children: [
      /* @__PURE__ */ u3("title", { children: title }),
      /* @__PURE__ */ u3("path", { d: "M12 20h9" }),
      /* @__PURE__ */ u3("path", { d: "M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" })
    ] });
  }

  // src/components/attached-selection.tsx
  function formatAttachedSelection(s5) {
    const lang = s5.language ?? "";
    const range = s5.startLine === s5.endLine ? `${s5.startLine}` : `${s5.startLine}-${s5.endLine}`;
    const fence = "```";
    return `(from ${s5.path}:${range})

${fence}${lang}
${s5.text}
${fence}`;
  }
  function AttachedSelectionBanner({ selection, onRemove }) {
    const range = selection.startLine === selection.endLine ? `${selection.startLine}` : `${selection.startLine}-${selection.endLine}`;
    const previewLines = selection.text.split(/\r?\n/);
    const previewSummary = previewLines.length === 1 ? selection.text.length > 60 ? `${selection.text.slice(0, 60)}\u2026` : selection.text : `${previewLines.length} lines`;
    return /* @__PURE__ */ u3("div", { class: "oati-attached-selection", title: `${selection.path}:${range}`, children: [
      /* @__PURE__ */ u3("span", { class: "oati-attached-selection-path", children: [
        selection.path,
        ":",
        range
      ] }),
      /* @__PURE__ */ u3("span", { class: "oati-attached-selection-preview", children: previewSummary }),
      /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: "oati-attached-selection-remove",
          onClick: onRemove,
          title: "Remove attached selection",
          "aria-label": "Remove attached selection",
          children: /* @__PURE__ */ u3(XIcon, { size: 12 })
        }
      )
    ] });
  }

  // src/components/background-task-tray.tsx
  function BackgroundTaskTray({ tasks, onCancel }) {
    if (tasks.length === 0) return null;
    return /* @__PURE__ */ u3("div", { class: "oati-bg-tray", children: [
      /* @__PURE__ */ u3("div", { class: "oati-bg-tray-header", children: [
        /* @__PURE__ */ u3("span", { class: "oati-bg-tray-icon", "aria-hidden": "true", children: "\u23F1" }),
        /* @__PURE__ */ u3("span", { class: "oati-bg-tray-title", children: [
          "Background tasks \xB7 ",
          tasks.length
        ] })
      ] }),
      /* @__PURE__ */ u3("ul", { class: "oati-bg-tray-list", children: tasks.map((t4) => /* @__PURE__ */ u3("li", { class: "oati-bg-tray-item", children: [
        /* @__PURE__ */ u3("span", { class: "oati-bg-tray-dot", "aria-hidden": "true" }),
        /* @__PURE__ */ u3("span", { class: "oati-bg-tray-label", title: t4.label, children: t4.label }),
        t4.kind && /* @__PURE__ */ u3("span", { class: "oati-bg-tray-kind", children: t4.kind }),
        /* @__PURE__ */ u3("span", { class: "oati-bg-tray-time", children: relativeTime(t4.startedAt) }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-bg-tray-stop",
            onClick: () => onCancel(t4.id),
            title: "Stop task",
            "aria-label": `Stop ${t4.label}`,
            children: "Stop"
          }
        )
      ] }, t4.id)) })
    ] });
  }
  function relativeTime(iso) {
    const startedMs = Date.parse(iso);
    if (Number.isNaN(startedMs)) return "";
    const elapsedMs = Date.now() - startedMs;
    if (elapsedMs < 1e3) return "now";
    const s5 = Math.floor(elapsedMs / 1e3);
    if (s5 < 60) return `${s5}s`;
    const m4 = Math.floor(s5 / 60);
    if (m4 < 60) return `${m4}m`;
    const h5 = Math.floor(m4 / 60);
    return `${h5}h ${m4 % 60}m`;
  }

  // src/components/compare-view.tsx
  function CompareView(props) {
    const bothDone = (props.leftState.status === "ok" || props.leftState.status === "error") && (props.rightState.status === "ok" || props.rightState.status === "error");
    return /* @__PURE__ */ u3("dialog", { class: "oati-compare-overlay", "aria-label": "Side-by-side compare", open: true, children: /* @__PURE__ */ u3("div", { class: "oati-compare-panel", children: [
      /* @__PURE__ */ u3("header", { class: "oati-compare-header", children: [
        /* @__PURE__ */ u3("h2", { children: "Side-by-side compare" }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-icon-btn",
            onClick: props.onClose,
            "aria-label": "Close compare view",
            title: "Close (cancels in-flight runs)",
            children: "\u2715"
          }
        )
      ] }),
      /* @__PURE__ */ u3("div", { class: "oati-compare-instruction", children: [
        /* @__PURE__ */ u3("span", { class: "oati-compare-instruction-label", children: "Prompt:" }),
        /* @__PURE__ */ u3("span", { class: "oati-compare-instruction-text", children: props.instruction })
      ] }),
      /* @__PURE__ */ u3("div", { class: "oati-compare-columns", children: [
        /* @__PURE__ */ u3(CompareColumn, { label: "Left", side: props.left, state: props.leftState }),
        /* @__PURE__ */ u3(CompareColumn, { label: "Right", side: props.right, state: props.rightState })
      ] }),
      /* @__PURE__ */ u3("footer", { class: "oati-compare-footer", children: [
        /* @__PURE__ */ u3("span", { class: "oati-compare-status", children: bothDone ? "Both runs finished." : "Streaming\u2026 closing the modal will cancel any in-flight runs." }),
        /* @__PURE__ */ u3("button", { type: "button", class: "composer-btn composer-btn-primary", onClick: props.onClose, children: bothDone ? "Close" : "Cancel and close" })
      ] })
    ] }) });
  }
  function CompareColumn({
    label,
    side,
    state
  }) {
    const statusLabel = state.status === "pending" ? "Waiting\u2026" : state.status === "streaming" ? "Streaming\u2026" : state.status === "ok" ? "Done" : `Error: ${state.message ?? "(unknown)"}`;
    const headerSubtitle = side.model ? `${side.providerId} \xB7 ${side.model}` : side.providerId;
    return /* @__PURE__ */ u3("section", { class: "oati-compare-col", "aria-label": `${label} column`, children: [
      /* @__PURE__ */ u3("header", { class: "oati-compare-col-header", children: [
        /* @__PURE__ */ u3("span", { class: "oati-compare-col-label", children: label }),
        /* @__PURE__ */ u3("span", { class: "oati-compare-col-meta", children: headerSubtitle }),
        /* @__PURE__ */ u3("span", { class: `oati-compare-col-status oati-compare-col-status-${state.status}`, children: statusLabel })
      ] }),
      /* @__PURE__ */ u3("div", { class: "oati-compare-col-body", children: [
        state.text.length === 0 && state.status === "pending" ? /* @__PURE__ */ u3("span", { class: "oati-compare-col-placeholder", children: "Waiting for response\u2026" }) : /* @__PURE__ */ u3("pre", { class: "oati-compare-col-text", children: state.text }),
        state.status === "streaming" && /* @__PURE__ */ u3("span", { class: "oati-cursor", children: "\u258D" })
      ] })
    ] });
  }

  // src/components/composer-panel.tsx
  function ComposerPanel(props) {
    const [instruction, setInstruction] = d2(props.initialInstruction ?? "");
    const [selectedPath, setSelectedPath] = d2(void 0);
    y2(() => {
      if (!selectedPath && props.files.length > 0) {
        setSelectedPath(props.files[0].path);
      }
    }, [props.files, selectedPath]);
    y2(() => {
      if (props.initialInstruction && props.initialInstruction !== instruction) {
        setInstruction(props.initialInstruction);
      }
    }, [props.initialInstruction]);
    const selected = props.files.find((f5) => f5.path === selectedPath);
    const running = props.status === "running";
    const canAcceptAll = props.files.length > 0 && props.files.some((f5) => f5.state !== "rejected") && props.status !== "running";
    const handleSubmit = () => {
      const text = instruction.trim();
      if (!text || running) return;
      props.onSubmit(text);
    };
    return /* @__PURE__ */ u3("div", { class: "composer-overlay", "aria-label": "Multi-file Composer", children: /* @__PURE__ */ u3("div", { class: "composer-panel", children: [
      /* @__PURE__ */ u3("header", { class: "composer-header", children: [
        /* @__PURE__ */ u3("div", { class: "composer-header-title", children: "Multi-file Composer" }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "composer-header-close",
            "aria-label": "Close composer",
            onClick: props.onClose,
            children: "\xD7"
          }
        )
      ] }),
      /* @__PURE__ */ u3("section", { class: "composer-prompt", children: [
        /* @__PURE__ */ u3(
          "textarea",
          {
            class: "composer-prompt-input",
            placeholder: "Describe what to build (e.g. 'scaffold a Login page with form + API call + tests')",
            value: instruction,
            disabled: running,
            onInput: (e4) => setInstruction(e4.target.value),
            onKeyDown: (e4) => {
              if (e4.key === "Enter" && (e4.metaKey || e4.ctrlKey)) {
                e4.preventDefault();
                handleSubmit();
              }
            },
            rows: 3
          }
        ),
        /* @__PURE__ */ u3("div", { class: "composer-prompt-actions", children: /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "composer-btn composer-btn-primary",
            disabled: running || instruction.trim().length === 0,
            onClick: handleSubmit,
            children: running ? "Generating..." : "Generate"
          }
        ) })
      ] }),
      props.status === "error" && props.errorMessage && /* @__PURE__ */ u3("div", { class: "composer-error", role: "alert", children: props.errorMessage }),
      props.status === "applied" && /* @__PURE__ */ u3("output", { class: "composer-applied", children: [
        "Applied ",
        props.appliedPaths?.length ?? 0,
        " file",
        (props.appliedPaths?.length ?? 0) === 1 ? "" : "s",
        ". Undo with the editor's standard Undo (one stroke)."
      ] }),
      /* @__PURE__ */ u3("div", { class: "composer-body", children: [
        /* @__PURE__ */ u3("nav", { class: "composer-rail", "aria-label": "Proposed files", children: [
          props.files.length === 0 && !running && /* @__PURE__ */ u3("div", { class: "composer-empty", children: "No proposed files yet." }),
          props.files.map((f5) => /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: `composer-file-row${selectedPath === f5.path ? " is-selected" : ""}${f5.state === "accepted" ? " is-accepted" : ""}${f5.state === "rejected" ? " is-rejected" : ""}`,
              onClick: () => setSelectedPath(f5.path),
              children: [
                /* @__PURE__ */ u3("span", { class: "composer-file-state", children: f5.state === "accepted" ? "\u2713" : f5.state === "rejected" ? "\u2717" : "\xB7" }),
                /* @__PURE__ */ u3("span", { class: "composer-file-path", children: f5.path })
              ]
            },
            f5.path
          ))
        ] }),
        /* @__PURE__ */ u3("section", { class: "composer-detail", "aria-live": "polite", children: selected ? /* @__PURE__ */ u3(S, { children: [
          /* @__PURE__ */ u3("header", { class: "composer-detail-header", children: [
            /* @__PURE__ */ u3("span", { class: "composer-detail-path", children: selected.path }),
            /* @__PURE__ */ u3("span", { class: "composer-detail-actions", children: [
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "composer-btn",
                  disabled: selected.state === "accepted",
                  onClick: () => props.onAcceptFile(selected.path),
                  children: "Accept"
                }
              ),
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "composer-btn",
                  disabled: selected.state === "rejected",
                  onClick: () => props.onRejectFile(selected.path),
                  children: "Reject"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ u3(SideBySideDiff, { before: selected.before, after: selected.after })
        ] }) : /* @__PURE__ */ u3("div", { class: "composer-empty", children: "Select a file on the left to review its diff." }) })
      ] }),
      /* @__PURE__ */ u3("footer", { class: "composer-footer", children: [
        /* @__PURE__ */ u3("button", { type: "button", class: "composer-btn", onClick: props.onDiscard, disabled: running, children: "Discard" }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "composer-btn composer-btn-primary",
            disabled: !canAcceptAll,
            onClick: props.onAcceptAll,
            children: "Accept All"
          }
        )
      ] })
    ] }) });
  }
  function SideBySideDiff({ before, after }) {
    const rows = diffRows(before, after);
    const MAX = 400;
    const truncated = rows.length > MAX;
    const display = truncated ? rows.slice(0, MAX) : rows;
    return /* @__PURE__ */ u3("div", { class: "composer-diff", children: [
      /* @__PURE__ */ u3("div", { class: "composer-diff-cols", children: [
        /* @__PURE__ */ u3("div", { class: "composer-diff-col composer-diff-col-before", children: display.map((r4) => /* @__PURE__ */ u3(
          "div",
          {
            class: `composer-diff-line${r4.left === void 0 ? " is-empty" : r4.kind === "del" ? " is-del" : ""}`,
            children: [
              /* @__PURE__ */ u3("span", { class: "composer-diff-sign", children: r4.left === void 0 ? " " : r4.kind === "del" ? "-" : " " }),
              /* @__PURE__ */ u3("span", { class: "composer-diff-text", children: r4.left ?? "" })
            ]
          },
          r4.key
        )) }),
        /* @__PURE__ */ u3("div", { class: "composer-diff-col composer-diff-col-after", children: display.map((r4) => /* @__PURE__ */ u3(
          "div",
          {
            class: `composer-diff-line${r4.right === void 0 ? " is-empty" : r4.kind === "add" ? " is-add" : ""}`,
            children: [
              /* @__PURE__ */ u3("span", { class: "composer-diff-sign", children: r4.right === void 0 ? " " : r4.kind === "add" ? "+" : " " }),
              /* @__PURE__ */ u3("span", { class: "composer-diff-text", children: r4.right ?? "" })
            ]
          },
          r4.key
        )) })
      ] }),
      truncated && /* @__PURE__ */ u3("div", { class: "composer-diff-truncated", children: [
        "\u2026 ",
        rows.length - MAX,
        " more lines (review remainder via the file directly)."
      ] })
    ] });
  }
  function diffRows(before, after) {
    const a4 = before.split("\n");
    const b3 = after.split("\n");
    const aSet = new Set(a4);
    const bSet = new Set(b3);
    const rows = [];
    const seen = /* @__PURE__ */ new Map();
    const push = (row) => {
      const base = `${row.kind}|${row.left ?? ""}|${row.right ?? ""}`;
      const n3 = (seen.get(base) ?? 0) + 1;
      seen.set(base, n3);
      rows.push({ ...row, key: `${base}#${n3}` });
    };
    let i5 = 0;
    let j4 = 0;
    while (i5 < a4.length || j4 < b3.length) {
      const x3 = a4[i5];
      const y4 = b3[j4];
      if (i5 >= a4.length) {
        push({ left: void 0, right: y4, kind: "add" });
        j4++;
      } else if (j4 >= b3.length) {
        push({ left: x3, right: void 0, kind: "del" });
        i5++;
      } else if (x3 === y4) {
        push({ left: x3, right: y4, kind: "ctx" });
        i5++;
        j4++;
      } else if (!bSet.has(x3)) {
        push({ left: x3, right: void 0, kind: "del" });
        i5++;
      } else if (!aSet.has(y4)) {
        push({ left: void 0, right: y4, kind: "add" });
        j4++;
      } else {
        push({ left: x3, right: y4, kind: "ctx" });
        i5++;
        j4++;
      }
    }
    return rows;
  }

  // src/components/mode-picker.tsx
  function ModePicker({ modes: modes2, activeId, onSelect, activeModel }) {
    const open = useSignal(false);
    const containerRef = A2(null);
    const active = modes2.find((m4) => m4.id === activeId) ?? modes2[0];
    y2(() => {
      if (!open.value) return;
      const onDocClick = (e4) => {
        if (containerRef.current && !containerRef.current.contains(e4.target)) {
          open.value = false;
        }
      };
      document.addEventListener("mousedown", onDocClick);
      return () => document.removeEventListener("mousedown", onDocClick);
    }, [open, open.value]);
    if (!active) return null;
    return /* @__PURE__ */ u3("div", { ref: containerRef, class: "oati-mode-picker", children: [
      /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: `oati-mode-pill${active.autoApprove ? " oati-mode-pill-auto" : ""}`,
          title: activeModel ? `${active.description ?? active.displayName} \xB7 model: ${activeModel}` : active.description ?? active.displayName,
          onClick: () => {
            open.value = !open.value;
          },
          children: [
            /* @__PURE__ */ u3("span", { class: "oati-mode-pill-dot", "aria-hidden": "true" }),
            /* @__PURE__ */ u3("span", { class: "oati-mode-pill-label", children: active.displayName }),
            activeModel && /* @__PURE__ */ u3("span", { class: "oati-mode-pill-model", title: activeModel, children: shortenModelId(activeModel) }),
            /* @__PURE__ */ u3("span", { class: "oati-mode-pill-chevron", "aria-hidden": "true", children: "\u25BE" })
          ]
        }
      ),
      open.value && /* @__PURE__ */ u3("div", { class: "oati-mode-menu", role: "menu", children: [
        /* @__PURE__ */ u3("div", { class: "oati-mode-menu-header", children: "Switch mode" }),
        modes2.map((m4) => {
          const isActive = m4.id === active.id;
          return /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: `oati-mode-menu-item${isActive ? " oati-mode-menu-item-active" : ""}`,
              onClick: () => {
                onSelect(m4.id);
                open.value = false;
              },
              title: m4.description ?? m4.displayName,
              children: [
                /* @__PURE__ */ u3("div", { class: "oati-mode-menu-row", children: [
                  /* @__PURE__ */ u3("span", { class: "oati-mode-menu-name", children: m4.displayName }),
                  /* @__PURE__ */ u3("span", { class: "oati-mode-menu-badges", children: [
                    m4.autoApprove && /* @__PURE__ */ u3("span", { class: "oati-mode-badge oati-mode-badge-auto", children: "auto" }),
                    m4.enablePlanner && /* @__PURE__ */ u3("span", { class: "oati-mode-badge", children: "plan" }),
                    m4.enableCritic && /* @__PURE__ */ u3("span", { class: "oati-mode-badge", children: "critic" })
                  ] })
                ] }),
                m4.description && /* @__PURE__ */ u3("div", { class: "oati-mode-menu-desc", children: m4.description })
              ]
            },
            m4.id
          );
        })
      ] })
    ] });
  }
  function shortenModelId(id) {
    const trimmed = id.trim();
    if (trimmed.length === 0) return trimmed;
    const tail = trimmed.split(/[/:]/).pop() ?? trimmed;
    return tail.length > 24 ? `${tail.slice(0, 23)}\u2026` : tail;
  }

  // src/components/input.tsx
  function Input({
    disabled,
    onSend,
    onCancel,
    onPickAttachment,
    attachments: attachments2,
    onRemoveAttachment,
    onAddImageAttachment,
    slashCommands,
    workspaceFiles: workspaceFiles2,
    contextMentions,
    promptHistory: promptHistory2,
    modes: modes2,
    activeMode: activeMode2,
    onModeChange,
    activeModel,
    injectionVersion,
    injectedText,
    decorateOutgoing
  }) {
    const text = useSignal("");
    const suggestions = useSignal([]);
    const activeIdx = useSignal(0);
    const historyIdx = useSignal(-1);
    const draftBeforeHistory = useSignal("");
    const textareaRef = A2(null);
    const isListening = useSignal(false);
    const recognitionRef = A2(null);
    const textAtListenStart = A2("");
    y2(() => {
      if (injectionVersion === void 0 || injectedText === void 0) return;
      text.value = injectedText;
      historyIdx.value = -1;
      suggestions.value = [];
      autoResize();
      queueMicrotask(() => {
        const ta = textareaRef.current;
        if (!ta) return;
        ta.focus();
        ta.setSelectionRange(ta.value.length, ta.value.length);
      });
    }, [injectionVersion]);
    y2(() => {
      autoResize();
      return () => {
        try {
          recognitionRef.current?.stop();
        } catch {
        }
      };
    }, []);
    const autoResize = () => {
      const ta = textareaRef.current;
      if (!ta) return;
      ta.style.height = "auto";
      ta.style.height = `${Math.min(Math.max(ta.scrollHeight, 28), 280)}px`;
    };
    const resetHeight = () => {
      const ta = textareaRef.current;
      if (!ta) return;
      ta.style.height = "28px";
    };
    const speechSupported = () => {
      const w4 = window;
      return Boolean(w4.SpeechRecognition || w4.webkitSpeechRecognition);
    };
    const startListening = () => {
      const w4 = window;
      const Ctor = w4.SpeechRecognition ?? w4.webkitSpeechRecognition;
      if (!Ctor) return;
      const rec = new Ctor();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = navigator.language || "en-US";
      textAtListenStart.current = text.value;
      rec.onresult = (e4) => {
        let finalChunk = "";
        let interim = "";
        for (let i5 = e4.resultIndex; i5 < e4.results.length; i5++) {
          const r4 = e4.results[i5];
          if (r4.isFinal) finalChunk += r4[0].transcript;
          else interim += r4[0].transcript;
        }
        if (finalChunk) {
          const base2 = textAtListenStart.current;
          const sep2 = base2.length > 0 && !/\s$/.test(base2) ? " " : "";
          textAtListenStart.current = base2 + sep2 + finalChunk.trim();
        }
        const base = textAtListenStart.current;
        const sep = base.length > 0 && interim && !/\s$/.test(base) ? " " : "";
        text.value = base + sep + interim;
        historyIdx.value = -1;
        autoResize();
      };
      rec.onerror = () => {
        isListening.value = false;
      };
      rec.onend = () => {
        isListening.value = false;
        recognitionRef.current = null;
        text.value = textAtListenStart.current;
        autoResize();
      };
      recognitionRef.current = rec;
      try {
        rec.start();
        isListening.value = true;
      } catch {
        isListening.value = false;
      }
    };
    const stopListening = () => {
      try {
        recognitionRef.current?.stop();
      } catch {
      }
      isListening.value = false;
    };
    const toggleListening = () => {
      if (isListening.value) stopListening();
      else startListening();
    };
    const openSlashMenu = () => {
      const ta = textareaRef.current;
      if (ta) ta.focus();
      text.value = "/";
      updateSuggestions("/", 1);
      autoResize();
    };
    const updateSuggestions = (raw, caret) => {
      const before = raw.slice(0, caret);
      if (raw.startsWith("/") && !raw.includes("\n")) {
        const partial = raw.slice(1).toLowerCase();
        const filtered = slashCommands.filter((c4) => c4.name.toLowerCase().startsWith(partial)).slice(0, 8).map((c4) => ({
          kind: "slash",
          value: `/${c4.name}`,
          label: `/${c4.name}`,
          description: c4.description
        }));
        suggestions.value = filtered;
        activeIdx.value = 0;
        return;
      }
      const tokenMatch = /@([\w./\\-]*)$/.exec(before);
      if (tokenMatch) {
        const partial = tokenMatch[1].toLowerCase();
        const mentionHits = (contextMentions ?? []).filter((m4) => m4.mention.slice(1).toLowerCase().startsWith(partial)).slice(0, 8).map((m4) => ({
          kind: "mention",
          value: m4.mention,
          label: m4.mention,
          description: m4.description
        }));
        const fileHits = workspaceFiles2 && workspaceFiles2.length > 0 ? workspaceFiles2.filter((f5) => f5.toLowerCase().includes(partial)).slice(0, Math.max(0, 8 - mentionHits.length)).map((f5) => ({
          kind: "file",
          value: f5,
          label: f5
        })) : [];
        const merged = [...mentionHits, ...fileHits];
        if (merged.length > 0) {
          suggestions.value = merged;
          activeIdx.value = 0;
          return;
        }
      }
      suggestions.value = [];
    };
    const applySuggestion = (s5) => {
      const ta = textareaRef.current;
      const caret = ta?.selectionStart ?? text.value.length;
      const before = text.value.slice(0, caret);
      const after = text.value.slice(caret);
      if (s5.kind === "slash") {
        text.value = s5.value;
        suggestions.value = [];
        autoResize();
        return;
      }
      const replacement = s5.kind === "mention" ? `${s5.value} ` : `@${s5.value} `;
      const replaced = before.replace(/@([\w./\\-]*)$/, replacement);
      text.value = replaced + after;
      suggestions.value = [];
      autoResize();
    };
    const buildFinalMessage = (prompt) => {
      if (attachments2.length === 0) return prompt;
      const blocks = [];
      for (const a4 of attachments2) {
        const fence = a4.language ?? "";
        const trunc = a4.truncated ? " (truncated)" : "";
        blocks.push(`Attached file: \`${a4.path}\`${trunc}

\`\`\`${fence}
${a4.text}
\`\`\``);
      }
      return `${blocks.join("\n\n")}

${prompt}`;
    };
    const submit = () => {
      const t4 = text.value.trim();
      if (t4.length === 0 && attachments2.length === 0) return;
      if (t4.startsWith("/")) {
        const body = t4.slice(1);
        const firstSpace = body.search(/\s/);
        const name = (firstSpace === -1 ? body : body.slice(0, firstSpace)).toLowerCase();
        const rest = firstSpace === -1 ? "" : body.slice(firstSpace + 1);
        const cmd = slashCommands.find((c4) => c4.name.toLowerCase() === name);
        if (cmd) {
          cmd.run(rest);
          text.value = "";
          suggestions.value = [];
          historyIdx.value = -1;
          resetHeight();
          return;
        }
      }
      const decorated = decorateOutgoing ? decorateOutgoing(t4) : t4;
      onSend(buildFinalMessage(decorated));
      text.value = "";
      suggestions.value = [];
      historyIdx.value = -1;
      draftBeforeHistory.value = "";
      resetHeight();
    };
    const isCursorAtTop = () => {
      const ta = textareaRef.current;
      if (!ta) return true;
      const sel = ta.selectionStart ?? 0;
      const before = ta.value.slice(0, sel);
      return !before.includes("\n");
    };
    const isCursorAtBottom = () => {
      const ta = textareaRef.current;
      if (!ta) return true;
      const sel = ta.selectionStart ?? 0;
      const after = ta.value.slice(sel);
      return !after.includes("\n");
    };
    const navigateHistory = (delta) => {
      if (promptHistory2.length === 0) return;
      const newIdx = delta === -1 ? historyIdx.value < 0 ? promptHistory2.length - 1 : Math.max(0, historyIdx.value - 1) : historyIdx.value < 0 ? -1 : historyIdx.value + 1;
      if (newIdx >= promptHistory2.length || newIdx < 0) {
        historyIdx.value = -1;
        text.value = draftBeforeHistory.value;
        autoResize();
        return;
      }
      if (historyIdx.value < 0) draftBeforeHistory.value = text.value;
      historyIdx.value = newIdx;
      text.value = promptHistory2[newIdx];
      autoResize();
    };
    const handlePaste = (e4) => {
      if (!onAddImageAttachment) return;
      const items = e4.clipboardData?.items;
      if (!items) return;
      for (let i5 = 0; i5 < items.length; i5++) {
        const it = items[i5];
        if (it.kind !== "file") continue;
        if (!it.type.startsWith("image/")) continue;
        const file = it.getAsFile();
        if (!file) continue;
        e4.preventDefault();
        ingestImageFile(file, "pasted-image");
        return;
      }
    };
    const ingestImageFile = (file, fallbackName) => {
      if (!onAddImageAttachment) return;
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = typeof reader.result === "string" ? reader.result : "";
        if (!dataUrl) return;
        const id = `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
        const name = file.name && file.name.length > 0 ? file.name : fallbackName;
        onAddImageAttachment({
          id,
          name,
          path: `clipboard:${id}`,
          text: "",
          truncated: false,
          imageDataUrl: dataUrl,
          mimeType: file.type || "image/png"
        });
      };
      reader.readAsDataURL(file);
    };
    const isDraggingFile = useSignal(false);
    const handleDragOver = (e4) => {
      if (!onAddImageAttachment) return;
      const types = e4.dataTransfer?.types;
      if (!types || !Array.from(types).includes("Files")) return;
      e4.preventDefault();
      if (e4.dataTransfer) e4.dataTransfer.dropEffect = "copy";
      isDraggingFile.value = true;
    };
    const handleDragLeave = (e4) => {
      if (e4.currentTarget === e4.target) isDraggingFile.value = false;
    };
    const handleDrop = (e4) => {
      if (!onAddImageAttachment) return;
      const files = e4.dataTransfer?.files;
      if (!files || files.length === 0) {
        isDraggingFile.value = false;
        return;
      }
      e4.preventDefault();
      isDraggingFile.value = false;
      for (let i5 = 0; i5 < files.length; i5++) {
        const f5 = files[i5];
        if (f5.type.startsWith("image/")) ingestImageFile(f5, "dropped-image");
      }
    };
    const handleKey = (e4) => {
      const sug = suggestions.value;
      if (sug.length > 0) {
        if (e4.key === "ArrowDown") {
          e4.preventDefault();
          activeIdx.value = (activeIdx.value + 1) % sug.length;
          return;
        }
        if (e4.key === "ArrowUp") {
          e4.preventDefault();
          activeIdx.value = (activeIdx.value - 1 + sug.length) % sug.length;
          return;
        }
        if (e4.key === "Tab" || e4.key === "Enter" && !e4.shiftKey) {
          e4.preventDefault();
          applySuggestion(sug[activeIdx.value]);
          return;
        }
        if (e4.key === "Escape") {
          e4.preventDefault();
          suggestions.value = [];
          return;
        }
      }
      if (e4.key === "ArrowUp" && isCursorAtTop()) {
        e4.preventDefault();
        navigateHistory(-1);
        return;
      }
      if (e4.key === "ArrowDown" && historyIdx.value >= 0 && isCursorAtBottom()) {
        e4.preventDefault();
        navigateHistory(1);
        return;
      }
      if (e4.key === "Enter" && !e4.shiftKey && !disabled) {
        e4.preventDefault();
        submit();
      }
    };
    const canSubmit = text.value.trim().length > 0 || attachments2.length > 0;
    return /* @__PURE__ */ u3(
      "div",
      {
        class: `oati-composer-outer${isDraggingFile.value ? " oati-composer-outer-dragging" : ""}`,
        onDragOver: handleDragOver,
        onDragLeave: handleDragLeave,
        onDrop: handleDrop,
        children: [
          isDraggingFile.value && /* @__PURE__ */ u3("div", { class: "oati-composer-drop-overlay", "aria-hidden": "true", children: "Drop image to attach" }),
          suggestions.value.length > 0 && // biome-ignore lint/a11y/useSemanticElements: native <select> can't host rich autocomplete rows with descriptions.
          // biome-ignore lint/a11y/useFocusableInteractive: focus stays on the textarea; suggestions are advisory.
          /* @__PURE__ */ u3("div", { class: "oati-suggestions", role: "listbox", tabindex: -1, children: suggestions.value.map((s5, i5) => /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: `oati-suggestion${i5 === activeIdx.value ? " oati-suggestion-active" : ""}`,
              onMouseDown: (e4) => {
                e4.preventDefault();
                applySuggestion(s5);
              },
              children: [
                /* @__PURE__ */ u3("span", { class: "oati-suggestion-label", children: s5.label }),
                s5.description && /* @__PURE__ */ u3("span", { class: "oati-suggestion-desc", children: s5.description })
              ]
            },
            `${s5.kind}_${s5.value}`
          )) }),
          /* @__PURE__ */ u3("div", { class: `oati-composer${disabled ? " oati-composer-disabled" : ""}`, children: [
            attachments2.length > 0 && /* @__PURE__ */ u3("div", { class: "oati-attachments", children: attachments2.map((a4) => /* @__PURE__ */ u3("span", { class: "oati-attachment-chip", title: a4.path, children: [
              a4.imageDataUrl && /* @__PURE__ */ u3("img", { src: a4.imageDataUrl, alt: a4.name, class: "oati-attachment-thumb" }),
              /* @__PURE__ */ u3("span", { class: "oati-attachment-name", children: a4.imageDataUrl ? a4.name : `@${a4.name}` }),
              a4.truncated && /* @__PURE__ */ u3("span", { class: "oati-attachment-truncated", children: "truncated" }),
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-attachment-remove",
                  onClick: () => onRemoveAttachment(a4.id),
                  title: "Remove attachment",
                  "aria-label": `Remove ${a4.name}`,
                  children: /* @__PURE__ */ u3(XIcon, { size: 12 })
                }
              )
            ] }, a4.id)) }),
            /* @__PURE__ */ u3("div", { class: "oati-composer-textwrap", children: [
              /* @__PURE__ */ u3(
                "textarea",
                {
                  ref: textareaRef,
                  class: "oati-composer-textarea",
                  value: text.value,
                  onInput: (e4) => {
                    const el = e4.target;
                    text.value = el.value;
                    historyIdx.value = -1;
                    updateSuggestions(el.value, el.selectionStart ?? el.value.length);
                    autoResize();
                  },
                  onKeyDown: handleKey,
                  onPaste: handlePaste,
                  placeholder: disabled ? "Working\u2026" : "Ask anything.  /  for commands \xB7 @ for files \xB7 \u2191/\u2193 for history \xB7 Shift+Enter for newline",
                  disabled: disabled && !onCancel,
                  rows: 1
                }
              ),
              speechSupported() && /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: `oati-composer-mic${isListening.value ? " oati-composer-mic-listening" : ""}`,
                  onClick: toggleListening,
                  disabled: disabled && !isListening.value,
                  title: isListening.value ? "Stop voice input" : "Start voice input",
                  "aria-label": isListening.value ? "Stop voice input" : "Start voice input",
                  children: /* @__PURE__ */ u3(MicIcon, { size: 16 })
                }
              )
            ] }),
            /* @__PURE__ */ u3("div", { class: "oati-composer-actions", children: [
              /* @__PURE__ */ u3("div", { class: "oati-composer-actions-left", children: [
                /* @__PURE__ */ u3(
                  "button",
                  {
                    type: "button",
                    class: "oati-composer-icon",
                    onClick: onPickAttachment,
                    disabled,
                    title: "Attach a file",
                    "aria-label": "Attach a file",
                    children: /* @__PURE__ */ u3(PaperclipIcon, { size: 16 })
                  }
                ),
                /* @__PURE__ */ u3(
                  "button",
                  {
                    type: "button",
                    class: "oati-composer-icon",
                    onClick: openSlashMenu,
                    disabled,
                    title: "Slash commands",
                    "aria-label": "Slash commands",
                    children: /* @__PURE__ */ u3(SlashGlyph, {})
                  }
                )
              ] }),
              /* @__PURE__ */ u3("div", { class: "oati-composer-actions-right", children: [
                modes2.length > 0 && /* @__PURE__ */ u3(
                  ModePicker,
                  {
                    modes: modes2,
                    activeId: activeMode2,
                    onSelect: onModeChange,
                    ...activeModel ? { activeModel } : {}
                  }
                ),
                onCancel ? /* @__PURE__ */ u3(
                  "button",
                  {
                    type: "button",
                    onClick: onCancel,
                    class: "oati-composer-send oati-composer-send-stop",
                    title: "Stop generation",
                    "aria-label": "Stop generation",
                    children: /* @__PURE__ */ u3(StopIcon, { size: 16 })
                  }
                ) : /* @__PURE__ */ u3(
                  "button",
                  {
                    type: "button",
                    onClick: submit,
                    disabled: disabled || !canSubmit,
                    class: "oati-composer-send",
                    title: "Send (Enter)",
                    "aria-label": "Send message",
                    children: /* @__PURE__ */ u3(SendIcon, { size: 16 })
                  }
                )
              ] })
            ] })
          ] })
        ]
      }
    );
  }
  function SlashGlyph() {
    return /* @__PURE__ */ u3(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: "16",
        height: "16",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        "stroke-width": "1.8",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "aria-hidden": true,
        children: [
          /* @__PURE__ */ u3("title", { children: "Slash commands" }),
          /* @__PURE__ */ u3("rect", { x: "3", y: "3", width: "18", height: "18", rx: "3" }),
          /* @__PURE__ */ u3("path", { d: "m9 17 6-10" })
        ]
      }
    );
  }

  // node_modules/marked/lib/marked.esm.js
  function _getDefaults() {
    return {
      async: false,
      breaks: false,
      extensions: null,
      gfm: true,
      hooks: null,
      pedantic: false,
      renderer: null,
      silent: false,
      tokenizer: null,
      walkTokens: null
    };
  }
  var _defaults = _getDefaults();
  function changeDefaults(newDefaults) {
    _defaults = newDefaults;
  }
  var noopTest = { exec: () => null };
  function edit(regex, opt = "") {
    let source = typeof regex === "string" ? regex : regex.source;
    const obj = {
      replace: (name, val) => {
        let valSource = typeof val === "string" ? val : val.source;
        valSource = valSource.replace(other.caret, "$1");
        source = source.replace(name, valSource);
        return obj;
      },
      getRegex: () => {
        return new RegExp(source, opt);
      }
    };
    return obj;
  }
  var other = {
    codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
    outputLinkReplace: /\\([\[\]])/g,
    indentCodeCompensation: /^(\s+)(?:```)/,
    beginningSpace: /^\s+/,
    endingHash: /#$/,
    startingSpaceChar: /^ /,
    endingSpaceChar: / $/,
    nonSpaceChar: /[^ ]/,
    newLineCharGlobal: /\n/g,
    tabCharGlobal: /\t/g,
    multipleSpaceGlobal: /\s+/g,
    blankLine: /^[ \t]*$/,
    doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
    blockquoteStart: /^ {0,3}>/,
    blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
    blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
    listReplaceTabs: /^\t+/,
    listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
    listIsTask: /^\[[ xX]\] /,
    listReplaceTask: /^\[[ xX]\] +/,
    anyLine: /\n.*\n/,
    hrefBrackets: /^<(.*)>$/,
    tableDelimiter: /[:|]/,
    tableAlignChars: /^\||\| *$/g,
    tableRowBlankLine: /\n[ \t]*$/,
    tableAlignRight: /^ *-+: *$/,
    tableAlignCenter: /^ *:-+: *$/,
    tableAlignLeft: /^ *:-+ *$/,
    startATag: /^<a /i,
    endATag: /^<\/a>/i,
    startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
    endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
    startAngleBracket: /^</,
    endAngleBracket: />$/,
    pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
    unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
    escapeTest: /[&<>"']/,
    escapeReplace: /[&<>"']/g,
    escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
    escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
    unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
    caret: /(^|[^\[])\^/g,
    percentDecode: /%25/g,
    findPipe: /\|/g,
    splitPipe: / \|/,
    slashPipe: /\\\|/g,
    carriageReturn: /\r\n|\r/g,
    spaceLine: /^ +$/gm,
    notSpaceStart: /^\S*/,
    endingNewline: /\n$/,
    listItemRegex: (bull) => new RegExp(`^( {0,3}${bull})((?:[	 ][^\\n]*)?(?:\\n|$))`),
    nextBulletRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
    hrRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
    fencesBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:\`\`\`|~~~)`),
    headingBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}#`),
    htmlBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}<(?:[a-z].*>|!--)`, "i")
  };
  var newline = /^(?:[ \t]*(?:\n|$))+/;
  var blockCode = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/;
  var fences = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/;
  var hr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/;
  var heading = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/;
  var bullet = /(?:[*+-]|\d{1,9}[.)])/;
  var lheadingCore = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/;
  var lheading = edit(lheadingCore).replace(/bull/g, bullet).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex();
  var lheadingGfm = edit(lheadingCore).replace(/bull/g, bullet).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex();
  var _paragraph = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/;
  var blockText = /^[^\n]+/;
  var _blockLabel = /(?!\s*\])(?:\\.|[^\[\]\\])+/;
  var def = edit(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", _blockLabel).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex();
  var list = edit(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, bullet).getRegex();
  var _tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
  var _comment = /<!--(?:-?>|[\s\S]*?(?:-->|$))/;
  var html = edit(
    "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))",
    "i"
  ).replace("comment", _comment).replace("tag", _tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
  var paragraph = edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
  var blockquote = edit(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", paragraph).getRegex();
  var blockNormal = {
    blockquote,
    code: blockCode,
    def,
    fences,
    heading,
    hr,
    html,
    lheading,
    list,
    newline,
    paragraph,
    table: noopTest,
    text: blockText
  };
  var gfmTable = edit(
    "^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
  ).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
  var blockGfm = {
    ...blockNormal,
    lheading: lheadingGfm,
    table: gfmTable,
    paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", gfmTable).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex()
  };
  var blockPedantic = {
    ...blockNormal,
    html: edit(
      `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`
    ).replace("comment", _comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
    def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
    heading: /^(#{1,6})(.*)(?:\n+|$)/,
    fences: noopTest,
    // fences not supported
    lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " *#{1,6} *[^\n]").replace("lheading", lheading).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
  };
  var escape = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/;
  var inlineCode = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/;
  var br = /^( {2,}|\\)\n(?!\s*$)/;
  var inlineText = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/;
  var _punctuation = /[\p{P}\p{S}]/u;
  var _punctuationOrSpace = /[\s\p{P}\p{S}]/u;
  var _notPunctuationOrSpace = /[^\s\p{P}\p{S}]/u;
  var punctuation = edit(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, _punctuationOrSpace).getRegex();
  var _punctuationGfmStrongEm = /(?!~)[\p{P}\p{S}]/u;
  var _punctuationOrSpaceGfmStrongEm = /(?!~)[\s\p{P}\p{S}]/u;
  var _notPunctuationOrSpaceGfmStrongEm = /(?:[^\s\p{P}\p{S}]|~)/u;
  var blockSkip = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g;
  var emStrongLDelimCore = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/;
  var emStrongLDelim = edit(emStrongLDelimCore, "u").replace(/punct/g, _punctuation).getRegex();
  var emStrongLDelimGfm = edit(emStrongLDelimCore, "u").replace(/punct/g, _punctuationGfmStrongEm).getRegex();
  var emStrongRDelimAstCore = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)";
  var emStrongRDelimAst = edit(emStrongRDelimAstCore, "gu").replace(/notPunctSpace/g, _notPunctuationOrSpace).replace(/punctSpace/g, _punctuationOrSpace).replace(/punct/g, _punctuation).getRegex();
  var emStrongRDelimAstGfm = edit(emStrongRDelimAstCore, "gu").replace(/notPunctSpace/g, _notPunctuationOrSpaceGfmStrongEm).replace(/punctSpace/g, _punctuationOrSpaceGfmStrongEm).replace(/punct/g, _punctuationGfmStrongEm).getRegex();
  var emStrongRDelimUnd = edit(
    "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)",
    "gu"
  ).replace(/notPunctSpace/g, _notPunctuationOrSpace).replace(/punctSpace/g, _punctuationOrSpace).replace(/punct/g, _punctuation).getRegex();
  var anyPunctuation = edit(/\\(punct)/, "gu").replace(/punct/g, _punctuation).getRegex();
  var autolink = edit(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex();
  var _inlineComment = edit(_comment).replace("(?:-->|$)", "-->").getRegex();
  var tag = edit(
    "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>"
  ).replace("comment", _inlineComment).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex();
  var _inlineLabel = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/;
  var link = edit(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", _inlineLabel).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex();
  var reflink = edit(/^!?\[(label)\]\[(ref)\]/).replace("label", _inlineLabel).replace("ref", _blockLabel).getRegex();
  var nolink = edit(/^!?\[(ref)\](?:\[\])?/).replace("ref", _blockLabel).getRegex();
  var reflinkSearch = edit("reflink|nolink(?!\\()", "g").replace("reflink", reflink).replace("nolink", nolink).getRegex();
  var inlineNormal = {
    _backpedal: noopTest,
    // only used for GFM url
    anyPunctuation,
    autolink,
    blockSkip,
    br,
    code: inlineCode,
    del: noopTest,
    emStrongLDelim,
    emStrongRDelimAst,
    emStrongRDelimUnd,
    escape,
    link,
    nolink,
    punctuation,
    reflink,
    reflinkSearch,
    tag,
    text: inlineText,
    url: noopTest
  };
  var inlinePedantic = {
    ...inlineNormal,
    link: edit(/^!?\[(label)\]\((.*?)\)/).replace("label", _inlineLabel).getRegex(),
    reflink: edit(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", _inlineLabel).getRegex()
  };
  var inlineGfm = {
    ...inlineNormal,
    emStrongRDelimAst: emStrongRDelimAstGfm,
    emStrongLDelim: emStrongLDelimGfm,
    url: edit(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
    _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
    del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
    text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
  };
  var inlineBreaks = {
    ...inlineGfm,
    br: edit(br).replace("{2,}", "*").getRegex(),
    text: edit(inlineGfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
  };
  var block = {
    normal: blockNormal,
    gfm: blockGfm,
    pedantic: blockPedantic
  };
  var inline = {
    normal: inlineNormal,
    gfm: inlineGfm,
    breaks: inlineBreaks,
    pedantic: inlinePedantic
  };
  var escapeReplacements = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var getEscapeReplacement = (ch) => escapeReplacements[ch];
  function escape2(html2, encode) {
    if (encode) {
      if (other.escapeTest.test(html2)) {
        return html2.replace(other.escapeReplace, getEscapeReplacement);
      }
    } else {
      if (other.escapeTestNoEncode.test(html2)) {
        return html2.replace(other.escapeReplaceNoEncode, getEscapeReplacement);
      }
    }
    return html2;
  }
  function cleanUrl(href) {
    try {
      href = encodeURI(href).replace(other.percentDecode, "%");
    } catch {
      return null;
    }
    return href;
  }
  function splitCells(tableRow, count) {
    const row = tableRow.replace(other.findPipe, (match, offset, str) => {
      let escaped = false;
      let curr = offset;
      while (--curr >= 0 && str[curr] === "\\") escaped = !escaped;
      if (escaped) {
        return "|";
      } else {
        return " |";
      }
    }), cells = row.split(other.splitPipe);
    let i5 = 0;
    if (!cells[0].trim()) {
      cells.shift();
    }
    if (cells.length > 0 && !cells.at(-1)?.trim()) {
      cells.pop();
    }
    if (count) {
      if (cells.length > count) {
        cells.splice(count);
      } else {
        while (cells.length < count) cells.push("");
      }
    }
    for (; i5 < cells.length; i5++) {
      cells[i5] = cells[i5].trim().replace(other.slashPipe, "|");
    }
    return cells;
  }
  function rtrim(str, c4, invert) {
    const l5 = str.length;
    if (l5 === 0) {
      return "";
    }
    let suffLen = 0;
    while (suffLen < l5) {
      const currChar = str.charAt(l5 - suffLen - 1);
      if (currChar === c4 && !invert) {
        suffLen++;
      } else if (currChar !== c4 && invert) {
        suffLen++;
      } else {
        break;
      }
    }
    return str.slice(0, l5 - suffLen);
  }
  function findClosingBracket(str, b3) {
    if (str.indexOf(b3[1]) === -1) {
      return -1;
    }
    let level = 0;
    for (let i5 = 0; i5 < str.length; i5++) {
      if (str[i5] === "\\") {
        i5++;
      } else if (str[i5] === b3[0]) {
        level++;
      } else if (str[i5] === b3[1]) {
        level--;
        if (level < 0) {
          return i5;
        }
      }
    }
    if (level > 0) {
      return -2;
    }
    return -1;
  }
  function outputLink(cap, link2, raw, lexer2, rules) {
    const href = link2.href;
    const title = link2.title || null;
    const text = cap[1].replace(rules.other.outputLinkReplace, "$1");
    lexer2.state.inLink = true;
    const token = {
      type: cap[0].charAt(0) === "!" ? "image" : "link",
      raw,
      href,
      title,
      text,
      tokens: lexer2.inlineTokens(text)
    };
    lexer2.state.inLink = false;
    return token;
  }
  function indentCodeCompensation(raw, text, rules) {
    const matchIndentToCode = raw.match(rules.other.indentCodeCompensation);
    if (matchIndentToCode === null) {
      return text;
    }
    const indentToCode = matchIndentToCode[1];
    return text.split("\n").map((node) => {
      const matchIndentInNode = node.match(rules.other.beginningSpace);
      if (matchIndentInNode === null) {
        return node;
      }
      const [indentInNode] = matchIndentInNode;
      if (indentInNode.length >= indentToCode.length) {
        return node.slice(indentToCode.length);
      }
      return node;
    }).join("\n");
  }
  var _Tokenizer = class {
    // set by the lexer
    constructor(options2) {
      __publicField(this, "options");
      __publicField(this, "rules");
      // set by the lexer
      __publicField(this, "lexer");
      this.options = options2 || _defaults;
    }
    space(src) {
      const cap = this.rules.block.newline.exec(src);
      if (cap && cap[0].length > 0) {
        return {
          type: "space",
          raw: cap[0]
        };
      }
    }
    code(src) {
      const cap = this.rules.block.code.exec(src);
      if (cap) {
        const text = cap[0].replace(this.rules.other.codeRemoveIndent, "");
        return {
          type: "code",
          raw: cap[0],
          codeBlockStyle: "indented",
          text: !this.options.pedantic ? rtrim(text, "\n") : text
        };
      }
    }
    fences(src) {
      const cap = this.rules.block.fences.exec(src);
      if (cap) {
        const raw = cap[0];
        const text = indentCodeCompensation(raw, cap[3] || "", this.rules);
        return {
          type: "code",
          raw,
          lang: cap[2] ? cap[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : cap[2],
          text
        };
      }
    }
    heading(src) {
      const cap = this.rules.block.heading.exec(src);
      if (cap) {
        let text = cap[2].trim();
        if (this.rules.other.endingHash.test(text)) {
          const trimmed = rtrim(text, "#");
          if (this.options.pedantic) {
            text = trimmed.trim();
          } else if (!trimmed || this.rules.other.endingSpaceChar.test(trimmed)) {
            text = trimmed.trim();
          }
        }
        return {
          type: "heading",
          raw: cap[0],
          depth: cap[1].length,
          text,
          tokens: this.lexer.inline(text)
        };
      }
    }
    hr(src) {
      const cap = this.rules.block.hr.exec(src);
      if (cap) {
        return {
          type: "hr",
          raw: rtrim(cap[0], "\n")
        };
      }
    }
    blockquote(src) {
      const cap = this.rules.block.blockquote.exec(src);
      if (cap) {
        let lines = rtrim(cap[0], "\n").split("\n");
        let raw = "";
        let text = "";
        const tokens = [];
        while (lines.length > 0) {
          let inBlockquote = false;
          const currentLines = [];
          let i5;
          for (i5 = 0; i5 < lines.length; i5++) {
            if (this.rules.other.blockquoteStart.test(lines[i5])) {
              currentLines.push(lines[i5]);
              inBlockquote = true;
            } else if (!inBlockquote) {
              currentLines.push(lines[i5]);
            } else {
              break;
            }
          }
          lines = lines.slice(i5);
          const currentRaw = currentLines.join("\n");
          const currentText = currentRaw.replace(this.rules.other.blockquoteSetextReplace, "\n    $1").replace(this.rules.other.blockquoteSetextReplace2, "");
          raw = raw ? `${raw}
${currentRaw}` : currentRaw;
          text = text ? `${text}
${currentText}` : currentText;
          const top = this.lexer.state.top;
          this.lexer.state.top = true;
          this.lexer.blockTokens(currentText, tokens, true);
          this.lexer.state.top = top;
          if (lines.length === 0) {
            break;
          }
          const lastToken = tokens.at(-1);
          if (lastToken?.type === "code") {
            break;
          } else if (lastToken?.type === "blockquote") {
            const oldToken = lastToken;
            const newText = oldToken.raw + "\n" + lines.join("\n");
            const newToken = this.blockquote(newText);
            tokens[tokens.length - 1] = newToken;
            raw = raw.substring(0, raw.length - oldToken.raw.length) + newToken.raw;
            text = text.substring(0, text.length - oldToken.text.length) + newToken.text;
            break;
          } else if (lastToken?.type === "list") {
            const oldToken = lastToken;
            const newText = oldToken.raw + "\n" + lines.join("\n");
            const newToken = this.list(newText);
            tokens[tokens.length - 1] = newToken;
            raw = raw.substring(0, raw.length - lastToken.raw.length) + newToken.raw;
            text = text.substring(0, text.length - oldToken.raw.length) + newToken.raw;
            lines = newText.substring(tokens.at(-1).raw.length).split("\n");
            continue;
          }
        }
        return {
          type: "blockquote",
          raw,
          tokens,
          text
        };
      }
    }
    list(src) {
      let cap = this.rules.block.list.exec(src);
      if (cap) {
        let bull = cap[1].trim();
        const isordered = bull.length > 1;
        const list2 = {
          type: "list",
          raw: "",
          ordered: isordered,
          start: isordered ? +bull.slice(0, -1) : "",
          loose: false,
          items: []
        };
        bull = isordered ? `\\d{1,9}\\${bull.slice(-1)}` : `\\${bull}`;
        if (this.options.pedantic) {
          bull = isordered ? bull : "[*+-]";
        }
        const itemRegex = this.rules.other.listItemRegex(bull);
        let endsWithBlankLine = false;
        while (src) {
          let endEarly = false;
          let raw = "";
          let itemContents = "";
          if (!(cap = itemRegex.exec(src))) {
            break;
          }
          if (this.rules.block.hr.test(src)) {
            break;
          }
          raw = cap[0];
          src = src.substring(raw.length);
          let line = cap[2].split("\n", 1)[0].replace(this.rules.other.listReplaceTabs, (t4) => " ".repeat(3 * t4.length));
          let nextLine = src.split("\n", 1)[0];
          let blankLine = !line.trim();
          let indent = 0;
          if (this.options.pedantic) {
            indent = 2;
            itemContents = line.trimStart();
          } else if (blankLine) {
            indent = cap[1].length + 1;
          } else {
            indent = cap[2].search(this.rules.other.nonSpaceChar);
            indent = indent > 4 ? 1 : indent;
            itemContents = line.slice(indent);
            indent += cap[1].length;
          }
          if (blankLine && this.rules.other.blankLine.test(nextLine)) {
            raw += nextLine + "\n";
            src = src.substring(nextLine.length + 1);
            endEarly = true;
          }
          if (!endEarly) {
            const nextBulletRegex = this.rules.other.nextBulletRegex(indent);
            const hrRegex = this.rules.other.hrRegex(indent);
            const fencesBeginRegex = this.rules.other.fencesBeginRegex(indent);
            const headingBeginRegex = this.rules.other.headingBeginRegex(indent);
            const htmlBeginRegex = this.rules.other.htmlBeginRegex(indent);
            while (src) {
              const rawLine = src.split("\n", 1)[0];
              let nextLineWithoutTabs;
              nextLine = rawLine;
              if (this.options.pedantic) {
                nextLine = nextLine.replace(this.rules.other.listReplaceNesting, "  ");
                nextLineWithoutTabs = nextLine;
              } else {
                nextLineWithoutTabs = nextLine.replace(this.rules.other.tabCharGlobal, "    ");
              }
              if (fencesBeginRegex.test(nextLine)) {
                break;
              }
              if (headingBeginRegex.test(nextLine)) {
                break;
              }
              if (htmlBeginRegex.test(nextLine)) {
                break;
              }
              if (nextBulletRegex.test(nextLine)) {
                break;
              }
              if (hrRegex.test(nextLine)) {
                break;
              }
              if (nextLineWithoutTabs.search(this.rules.other.nonSpaceChar) >= indent || !nextLine.trim()) {
                itemContents += "\n" + nextLineWithoutTabs.slice(indent);
              } else {
                if (blankLine) {
                  break;
                }
                if (line.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4) {
                  break;
                }
                if (fencesBeginRegex.test(line)) {
                  break;
                }
                if (headingBeginRegex.test(line)) {
                  break;
                }
                if (hrRegex.test(line)) {
                  break;
                }
                itemContents += "\n" + nextLine;
              }
              if (!blankLine && !nextLine.trim()) {
                blankLine = true;
              }
              raw += rawLine + "\n";
              src = src.substring(rawLine.length + 1);
              line = nextLineWithoutTabs.slice(indent);
            }
          }
          if (!list2.loose) {
            if (endsWithBlankLine) {
              list2.loose = true;
            } else if (this.rules.other.doubleBlankLine.test(raw)) {
              endsWithBlankLine = true;
            }
          }
          let istask = null;
          let ischecked;
          if (this.options.gfm) {
            istask = this.rules.other.listIsTask.exec(itemContents);
            if (istask) {
              ischecked = istask[0] !== "[ ] ";
              itemContents = itemContents.replace(this.rules.other.listReplaceTask, "");
            }
          }
          list2.items.push({
            type: "list_item",
            raw,
            task: !!istask,
            checked: ischecked,
            loose: false,
            text: itemContents,
            tokens: []
          });
          list2.raw += raw;
        }
        const lastItem = list2.items.at(-1);
        if (lastItem) {
          lastItem.raw = lastItem.raw.trimEnd();
          lastItem.text = lastItem.text.trimEnd();
        } else {
          return;
        }
        list2.raw = list2.raw.trimEnd();
        for (let i5 = 0; i5 < list2.items.length; i5++) {
          this.lexer.state.top = false;
          list2.items[i5].tokens = this.lexer.blockTokens(list2.items[i5].text, []);
          if (!list2.loose) {
            const spacers = list2.items[i5].tokens.filter((t4) => t4.type === "space");
            const hasMultipleLineBreaks = spacers.length > 0 && spacers.some((t4) => this.rules.other.anyLine.test(t4.raw));
            list2.loose = hasMultipleLineBreaks;
          }
        }
        if (list2.loose) {
          for (let i5 = 0; i5 < list2.items.length; i5++) {
            list2.items[i5].loose = true;
          }
        }
        return list2;
      }
    }
    html(src) {
      const cap = this.rules.block.html.exec(src);
      if (cap) {
        const token = {
          type: "html",
          block: true,
          raw: cap[0],
          pre: cap[1] === "pre" || cap[1] === "script" || cap[1] === "style",
          text: cap[0]
        };
        return token;
      }
    }
    def(src) {
      const cap = this.rules.block.def.exec(src);
      if (cap) {
        const tag2 = cap[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " ");
        const href = cap[2] ? cap[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "";
        const title = cap[3] ? cap[3].substring(1, cap[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : cap[3];
        return {
          type: "def",
          tag: tag2,
          raw: cap[0],
          href,
          title
        };
      }
    }
    table(src) {
      const cap = this.rules.block.table.exec(src);
      if (!cap) {
        return;
      }
      if (!this.rules.other.tableDelimiter.test(cap[2])) {
        return;
      }
      const headers = splitCells(cap[1]);
      const aligns = cap[2].replace(this.rules.other.tableAlignChars, "").split("|");
      const rows = cap[3]?.trim() ? cap[3].replace(this.rules.other.tableRowBlankLine, "").split("\n") : [];
      const item = {
        type: "table",
        raw: cap[0],
        header: [],
        align: [],
        rows: []
      };
      if (headers.length !== aligns.length) {
        return;
      }
      for (const align of aligns) {
        if (this.rules.other.tableAlignRight.test(align)) {
          item.align.push("right");
        } else if (this.rules.other.tableAlignCenter.test(align)) {
          item.align.push("center");
        } else if (this.rules.other.tableAlignLeft.test(align)) {
          item.align.push("left");
        } else {
          item.align.push(null);
        }
      }
      for (let i5 = 0; i5 < headers.length; i5++) {
        item.header.push({
          text: headers[i5],
          tokens: this.lexer.inline(headers[i5]),
          header: true,
          align: item.align[i5]
        });
      }
      for (const row of rows) {
        item.rows.push(splitCells(row, item.header.length).map((cell, i5) => {
          return {
            text: cell,
            tokens: this.lexer.inline(cell),
            header: false,
            align: item.align[i5]
          };
        }));
      }
      return item;
    }
    lheading(src) {
      const cap = this.rules.block.lheading.exec(src);
      if (cap) {
        return {
          type: "heading",
          raw: cap[0],
          depth: cap[2].charAt(0) === "=" ? 1 : 2,
          text: cap[1],
          tokens: this.lexer.inline(cap[1])
        };
      }
    }
    paragraph(src) {
      const cap = this.rules.block.paragraph.exec(src);
      if (cap) {
        const text = cap[1].charAt(cap[1].length - 1) === "\n" ? cap[1].slice(0, -1) : cap[1];
        return {
          type: "paragraph",
          raw: cap[0],
          text,
          tokens: this.lexer.inline(text)
        };
      }
    }
    text(src) {
      const cap = this.rules.block.text.exec(src);
      if (cap) {
        return {
          type: "text",
          raw: cap[0],
          text: cap[0],
          tokens: this.lexer.inline(cap[0])
        };
      }
    }
    escape(src) {
      const cap = this.rules.inline.escape.exec(src);
      if (cap) {
        return {
          type: "escape",
          raw: cap[0],
          text: cap[1]
        };
      }
    }
    tag(src) {
      const cap = this.rules.inline.tag.exec(src);
      if (cap) {
        if (!this.lexer.state.inLink && this.rules.other.startATag.test(cap[0])) {
          this.lexer.state.inLink = true;
        } else if (this.lexer.state.inLink && this.rules.other.endATag.test(cap[0])) {
          this.lexer.state.inLink = false;
        }
        if (!this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(cap[0])) {
          this.lexer.state.inRawBlock = true;
        } else if (this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(cap[0])) {
          this.lexer.state.inRawBlock = false;
        }
        return {
          type: "html",
          raw: cap[0],
          inLink: this.lexer.state.inLink,
          inRawBlock: this.lexer.state.inRawBlock,
          block: false,
          text: cap[0]
        };
      }
    }
    link(src) {
      const cap = this.rules.inline.link.exec(src);
      if (cap) {
        const trimmedUrl = cap[2].trim();
        if (!this.options.pedantic && this.rules.other.startAngleBracket.test(trimmedUrl)) {
          if (!this.rules.other.endAngleBracket.test(trimmedUrl)) {
            return;
          }
          const rtrimSlash = rtrim(trimmedUrl.slice(0, -1), "\\");
          if ((trimmedUrl.length - rtrimSlash.length) % 2 === 0) {
            return;
          }
        } else {
          const lastParenIndex = findClosingBracket(cap[2], "()");
          if (lastParenIndex === -2) {
            return;
          }
          if (lastParenIndex > -1) {
            const start = cap[0].indexOf("!") === 0 ? 5 : 4;
            const linkLen = start + cap[1].length + lastParenIndex;
            cap[2] = cap[2].substring(0, lastParenIndex);
            cap[0] = cap[0].substring(0, linkLen).trim();
            cap[3] = "";
          }
        }
        let href = cap[2];
        let title = "";
        if (this.options.pedantic) {
          const link2 = this.rules.other.pedanticHrefTitle.exec(href);
          if (link2) {
            href = link2[1];
            title = link2[3];
          }
        } else {
          title = cap[3] ? cap[3].slice(1, -1) : "";
        }
        href = href.trim();
        if (this.rules.other.startAngleBracket.test(href)) {
          if (this.options.pedantic && !this.rules.other.endAngleBracket.test(trimmedUrl)) {
            href = href.slice(1);
          } else {
            href = href.slice(1, -1);
          }
        }
        return outputLink(cap, {
          href: href ? href.replace(this.rules.inline.anyPunctuation, "$1") : href,
          title: title ? title.replace(this.rules.inline.anyPunctuation, "$1") : title
        }, cap[0], this.lexer, this.rules);
      }
    }
    reflink(src, links) {
      let cap;
      if ((cap = this.rules.inline.reflink.exec(src)) || (cap = this.rules.inline.nolink.exec(src))) {
        const linkString = (cap[2] || cap[1]).replace(this.rules.other.multipleSpaceGlobal, " ");
        const link2 = links[linkString.toLowerCase()];
        if (!link2) {
          const text = cap[0].charAt(0);
          return {
            type: "text",
            raw: text,
            text
          };
        }
        return outputLink(cap, link2, cap[0], this.lexer, this.rules);
      }
    }
    emStrong(src, maskedSrc, prevChar = "") {
      let match = this.rules.inline.emStrongLDelim.exec(src);
      if (!match) return;
      if (match[3] && prevChar.match(this.rules.other.unicodeAlphaNumeric)) return;
      const nextChar = match[1] || match[2] || "";
      if (!nextChar || !prevChar || this.rules.inline.punctuation.exec(prevChar)) {
        const lLength = [...match[0]].length - 1;
        let rDelim, rLength, delimTotal = lLength, midDelimTotal = 0;
        const endReg = match[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
        endReg.lastIndex = 0;
        maskedSrc = maskedSrc.slice(-1 * src.length + lLength);
        while ((match = endReg.exec(maskedSrc)) != null) {
          rDelim = match[1] || match[2] || match[3] || match[4] || match[5] || match[6];
          if (!rDelim) continue;
          rLength = [...rDelim].length;
          if (match[3] || match[4]) {
            delimTotal += rLength;
            continue;
          } else if (match[5] || match[6]) {
            if (lLength % 3 && !((lLength + rLength) % 3)) {
              midDelimTotal += rLength;
              continue;
            }
          }
          delimTotal -= rLength;
          if (delimTotal > 0) continue;
          rLength = Math.min(rLength, rLength + delimTotal + midDelimTotal);
          const lastCharLength = [...match[0]][0].length;
          const raw = src.slice(0, lLength + match.index + lastCharLength + rLength);
          if (Math.min(lLength, rLength) % 2) {
            const text2 = raw.slice(1, -1);
            return {
              type: "em",
              raw,
              text: text2,
              tokens: this.lexer.inlineTokens(text2)
            };
          }
          const text = raw.slice(2, -2);
          return {
            type: "strong",
            raw,
            text,
            tokens: this.lexer.inlineTokens(text)
          };
        }
      }
    }
    codespan(src) {
      const cap = this.rules.inline.code.exec(src);
      if (cap) {
        let text = cap[2].replace(this.rules.other.newLineCharGlobal, " ");
        const hasNonSpaceChars = this.rules.other.nonSpaceChar.test(text);
        const hasSpaceCharsOnBothEnds = this.rules.other.startingSpaceChar.test(text) && this.rules.other.endingSpaceChar.test(text);
        if (hasNonSpaceChars && hasSpaceCharsOnBothEnds) {
          text = text.substring(1, text.length - 1);
        }
        return {
          type: "codespan",
          raw: cap[0],
          text
        };
      }
    }
    br(src) {
      const cap = this.rules.inline.br.exec(src);
      if (cap) {
        return {
          type: "br",
          raw: cap[0]
        };
      }
    }
    del(src) {
      const cap = this.rules.inline.del.exec(src);
      if (cap) {
        return {
          type: "del",
          raw: cap[0],
          text: cap[2],
          tokens: this.lexer.inlineTokens(cap[2])
        };
      }
    }
    autolink(src) {
      const cap = this.rules.inline.autolink.exec(src);
      if (cap) {
        let text, href;
        if (cap[2] === "@") {
          text = cap[1];
          href = "mailto:" + text;
        } else {
          text = cap[1];
          href = text;
        }
        return {
          type: "link",
          raw: cap[0],
          text,
          href,
          tokens: [
            {
              type: "text",
              raw: text,
              text
            }
          ]
        };
      }
    }
    url(src) {
      let cap;
      if (cap = this.rules.inline.url.exec(src)) {
        let text, href;
        if (cap[2] === "@") {
          text = cap[0];
          href = "mailto:" + text;
        } else {
          let prevCapZero;
          do {
            prevCapZero = cap[0];
            cap[0] = this.rules.inline._backpedal.exec(cap[0])?.[0] ?? "";
          } while (prevCapZero !== cap[0]);
          text = cap[0];
          if (cap[1] === "www.") {
            href = "http://" + cap[0];
          } else {
            href = cap[0];
          }
        }
        return {
          type: "link",
          raw: cap[0],
          text,
          href,
          tokens: [
            {
              type: "text",
              raw: text,
              text
            }
          ]
        };
      }
    }
    inlineText(src) {
      const cap = this.rules.inline.text.exec(src);
      if (cap) {
        const escaped = this.lexer.state.inRawBlock;
        return {
          type: "text",
          raw: cap[0],
          text: cap[0],
          escaped
        };
      }
    }
  };
  var _Lexer = class __Lexer {
    constructor(options2) {
      __publicField(this, "tokens");
      __publicField(this, "options");
      __publicField(this, "state");
      __publicField(this, "tokenizer");
      __publicField(this, "inlineQueue");
      this.tokens = [];
      this.tokens.links = /* @__PURE__ */ Object.create(null);
      this.options = options2 || _defaults;
      this.options.tokenizer = this.options.tokenizer || new _Tokenizer();
      this.tokenizer = this.options.tokenizer;
      this.tokenizer.options = this.options;
      this.tokenizer.lexer = this;
      this.inlineQueue = [];
      this.state = {
        inLink: false,
        inRawBlock: false,
        top: true
      };
      const rules = {
        other,
        block: block.normal,
        inline: inline.normal
      };
      if (this.options.pedantic) {
        rules.block = block.pedantic;
        rules.inline = inline.pedantic;
      } else if (this.options.gfm) {
        rules.block = block.gfm;
        if (this.options.breaks) {
          rules.inline = inline.breaks;
        } else {
          rules.inline = inline.gfm;
        }
      }
      this.tokenizer.rules = rules;
    }
    /**
     * Expose Rules
     */
    static get rules() {
      return {
        block,
        inline
      };
    }
    /**
     * Static Lex Method
     */
    static lex(src, options2) {
      const lexer2 = new __Lexer(options2);
      return lexer2.lex(src);
    }
    /**
     * Static Lex Inline Method
     */
    static lexInline(src, options2) {
      const lexer2 = new __Lexer(options2);
      return lexer2.inlineTokens(src);
    }
    /**
     * Preprocessing
     */
    lex(src) {
      src = src.replace(other.carriageReturn, "\n");
      this.blockTokens(src, this.tokens);
      for (let i5 = 0; i5 < this.inlineQueue.length; i5++) {
        const next = this.inlineQueue[i5];
        this.inlineTokens(next.src, next.tokens);
      }
      this.inlineQueue = [];
      return this.tokens;
    }
    blockTokens(src, tokens = [], lastParagraphClipped = false) {
      if (this.options.pedantic) {
        src = src.replace(other.tabCharGlobal, "    ").replace(other.spaceLine, "");
      }
      while (src) {
        let token;
        if (this.options.extensions?.block?.some((extTokenizer) => {
          if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
            src = src.substring(token.raw.length);
            tokens.push(token);
            return true;
          }
          return false;
        })) {
          continue;
        }
        if (token = this.tokenizer.space(src)) {
          src = src.substring(token.raw.length);
          const lastToken = tokens.at(-1);
          if (token.raw.length === 1 && lastToken !== void 0) {
            lastToken.raw += "\n";
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (token = this.tokenizer.code(src)) {
          src = src.substring(token.raw.length);
          const lastToken = tokens.at(-1);
          if (lastToken?.type === "paragraph" || lastToken?.type === "text") {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.text;
            this.inlineQueue.at(-1).src = lastToken.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (token = this.tokenizer.fences(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.heading(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.hr(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.blockquote(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.list(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.html(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.def(src)) {
          src = src.substring(token.raw.length);
          const lastToken = tokens.at(-1);
          if (lastToken?.type === "paragraph" || lastToken?.type === "text") {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.raw;
            this.inlineQueue.at(-1).src = lastToken.text;
          } else if (!this.tokens.links[token.tag]) {
            this.tokens.links[token.tag] = {
              href: token.href,
              title: token.title
            };
          }
          continue;
        }
        if (token = this.tokenizer.table(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.lheading(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        let cutSrc = src;
        if (this.options.extensions?.startBlock) {
          let startIndex = Infinity;
          const tempSrc = src.slice(1);
          let tempStart;
          this.options.extensions.startBlock.forEach((getStartIndex) => {
            tempStart = getStartIndex.call({ lexer: this }, tempSrc);
            if (typeof tempStart === "number" && tempStart >= 0) {
              startIndex = Math.min(startIndex, tempStart);
            }
          });
          if (startIndex < Infinity && startIndex >= 0) {
            cutSrc = src.substring(0, startIndex + 1);
          }
        }
        if (this.state.top && (token = this.tokenizer.paragraph(cutSrc))) {
          const lastToken = tokens.at(-1);
          if (lastParagraphClipped && lastToken?.type === "paragraph") {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.text;
            this.inlineQueue.pop();
            this.inlineQueue.at(-1).src = lastToken.text;
          } else {
            tokens.push(token);
          }
          lastParagraphClipped = cutSrc.length !== src.length;
          src = src.substring(token.raw.length);
          continue;
        }
        if (token = this.tokenizer.text(src)) {
          src = src.substring(token.raw.length);
          const lastToken = tokens.at(-1);
          if (lastToken?.type === "text") {
            lastToken.raw += "\n" + token.raw;
            lastToken.text += "\n" + token.text;
            this.inlineQueue.pop();
            this.inlineQueue.at(-1).src = lastToken.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (src) {
          const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
          if (this.options.silent) {
            console.error(errMsg);
            break;
          } else {
            throw new Error(errMsg);
          }
        }
      }
      this.state.top = true;
      return tokens;
    }
    inline(src, tokens = []) {
      this.inlineQueue.push({ src, tokens });
      return tokens;
    }
    /**
     * Lexing/Compiling
     */
    inlineTokens(src, tokens = []) {
      let maskedSrc = src;
      let match = null;
      if (this.tokens.links) {
        const links = Object.keys(this.tokens.links);
        if (links.length > 0) {
          while ((match = this.tokenizer.rules.inline.reflinkSearch.exec(maskedSrc)) != null) {
            if (links.includes(match[0].slice(match[0].lastIndexOf("[") + 1, -1))) {
              maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex);
            }
          }
        }
      }
      while ((match = this.tokenizer.rules.inline.anyPunctuation.exec(maskedSrc)) != null) {
        maskedSrc = maskedSrc.slice(0, match.index) + "++" + maskedSrc.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
      }
      while ((match = this.tokenizer.rules.inline.blockSkip.exec(maskedSrc)) != null) {
        maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
      }
      let keepPrevChar = false;
      let prevChar = "";
      while (src) {
        if (!keepPrevChar) {
          prevChar = "";
        }
        keepPrevChar = false;
        let token;
        if (this.options.extensions?.inline?.some((extTokenizer) => {
          if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
            src = src.substring(token.raw.length);
            tokens.push(token);
            return true;
          }
          return false;
        })) {
          continue;
        }
        if (token = this.tokenizer.escape(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.tag(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.link(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.reflink(src, this.tokens.links)) {
          src = src.substring(token.raw.length);
          const lastToken = tokens.at(-1);
          if (token.type === "text" && lastToken?.type === "text") {
            lastToken.raw += token.raw;
            lastToken.text += token.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (token = this.tokenizer.emStrong(src, maskedSrc, prevChar)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.codespan(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.br(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.del(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (token = this.tokenizer.autolink(src)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        if (!this.state.inLink && (token = this.tokenizer.url(src))) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          continue;
        }
        let cutSrc = src;
        if (this.options.extensions?.startInline) {
          let startIndex = Infinity;
          const tempSrc = src.slice(1);
          let tempStart;
          this.options.extensions.startInline.forEach((getStartIndex) => {
            tempStart = getStartIndex.call({ lexer: this }, tempSrc);
            if (typeof tempStart === "number" && tempStart >= 0) {
              startIndex = Math.min(startIndex, tempStart);
            }
          });
          if (startIndex < Infinity && startIndex >= 0) {
            cutSrc = src.substring(0, startIndex + 1);
          }
        }
        if (token = this.tokenizer.inlineText(cutSrc)) {
          src = src.substring(token.raw.length);
          if (token.raw.slice(-1) !== "_") {
            prevChar = token.raw.slice(-1);
          }
          keepPrevChar = true;
          const lastToken = tokens.at(-1);
          if (lastToken?.type === "text") {
            lastToken.raw += token.raw;
            lastToken.text += token.text;
          } else {
            tokens.push(token);
          }
          continue;
        }
        if (src) {
          const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
          if (this.options.silent) {
            console.error(errMsg);
            break;
          } else {
            throw new Error(errMsg);
          }
        }
      }
      return tokens;
    }
  };
  var _Renderer = class {
    // set by the parser
    constructor(options2) {
      __publicField(this, "options");
      __publicField(this, "parser");
      this.options = options2 || _defaults;
    }
    space(token) {
      return "";
    }
    code({ text, lang, escaped }) {
      const langString = (lang || "").match(other.notSpaceStart)?.[0];
      const code = text.replace(other.endingNewline, "") + "\n";
      if (!langString) {
        return "<pre><code>" + (escaped ? code : escape2(code, true)) + "</code></pre>\n";
      }
      return '<pre><code class="language-' + escape2(langString) + '">' + (escaped ? code : escape2(code, true)) + "</code></pre>\n";
    }
    blockquote({ tokens }) {
      const body = this.parser.parse(tokens);
      return `<blockquote>
${body}</blockquote>
`;
    }
    html({ text }) {
      return text;
    }
    heading({ tokens, depth }) {
      return `<h${depth}>${this.parser.parseInline(tokens)}</h${depth}>
`;
    }
    hr(token) {
      return "<hr>\n";
    }
    list(token) {
      const ordered = token.ordered;
      const start = token.start;
      let body = "";
      for (let j4 = 0; j4 < token.items.length; j4++) {
        const item = token.items[j4];
        body += this.listitem(item);
      }
      const type = ordered ? "ol" : "ul";
      const startAttr = ordered && start !== 1 ? ' start="' + start + '"' : "";
      return "<" + type + startAttr + ">\n" + body + "</" + type + ">\n";
    }
    listitem(item) {
      let itemBody = "";
      if (item.task) {
        const checkbox = this.checkbox({ checked: !!item.checked });
        if (item.loose) {
          if (item.tokens[0]?.type === "paragraph") {
            item.tokens[0].text = checkbox + " " + item.tokens[0].text;
            if (item.tokens[0].tokens && item.tokens[0].tokens.length > 0 && item.tokens[0].tokens[0].type === "text") {
              item.tokens[0].tokens[0].text = checkbox + " " + escape2(item.tokens[0].tokens[0].text);
              item.tokens[0].tokens[0].escaped = true;
            }
          } else {
            item.tokens.unshift({
              type: "text",
              raw: checkbox + " ",
              text: checkbox + " ",
              escaped: true
            });
          }
        } else {
          itemBody += checkbox + " ";
        }
      }
      itemBody += this.parser.parse(item.tokens, !!item.loose);
      return `<li>${itemBody}</li>
`;
    }
    checkbox({ checked }) {
      return "<input " + (checked ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
    }
    paragraph({ tokens }) {
      return `<p>${this.parser.parseInline(tokens)}</p>
`;
    }
    table(token) {
      let header = "";
      let cell = "";
      for (let j4 = 0; j4 < token.header.length; j4++) {
        cell += this.tablecell(token.header[j4]);
      }
      header += this.tablerow({ text: cell });
      let body = "";
      for (let j4 = 0; j4 < token.rows.length; j4++) {
        const row = token.rows[j4];
        cell = "";
        for (let k3 = 0; k3 < row.length; k3++) {
          cell += this.tablecell(row[k3]);
        }
        body += this.tablerow({ text: cell });
      }
      if (body) body = `<tbody>${body}</tbody>`;
      return "<table>\n<thead>\n" + header + "</thead>\n" + body + "</table>\n";
    }
    tablerow({ text }) {
      return `<tr>
${text}</tr>
`;
    }
    tablecell(token) {
      const content = this.parser.parseInline(token.tokens);
      const type = token.header ? "th" : "td";
      const tag2 = token.align ? `<${type} align="${token.align}">` : `<${type}>`;
      return tag2 + content + `</${type}>
`;
    }
    /**
     * span level renderer
     */
    strong({ tokens }) {
      return `<strong>${this.parser.parseInline(tokens)}</strong>`;
    }
    em({ tokens }) {
      return `<em>${this.parser.parseInline(tokens)}</em>`;
    }
    codespan({ text }) {
      return `<code>${escape2(text, true)}</code>`;
    }
    br(token) {
      return "<br>";
    }
    del({ tokens }) {
      return `<del>${this.parser.parseInline(tokens)}</del>`;
    }
    link({ href, title, tokens }) {
      const text = this.parser.parseInline(tokens);
      const cleanHref = cleanUrl(href);
      if (cleanHref === null) {
        return text;
      }
      href = cleanHref;
      let out = '<a href="' + href + '"';
      if (title) {
        out += ' title="' + escape2(title) + '"';
      }
      out += ">" + text + "</a>";
      return out;
    }
    image({ href, title, text, tokens }) {
      if (tokens) {
        text = this.parser.parseInline(tokens, this.parser.textRenderer);
      }
      const cleanHref = cleanUrl(href);
      if (cleanHref === null) {
        return escape2(text);
      }
      href = cleanHref;
      let out = `<img src="${href}" alt="${text}"`;
      if (title) {
        out += ` title="${escape2(title)}"`;
      }
      out += ">";
      return out;
    }
    text(token) {
      return "tokens" in token && token.tokens ? this.parser.parseInline(token.tokens) : "escaped" in token && token.escaped ? token.text : escape2(token.text);
    }
  };
  var _TextRenderer = class {
    // no need for block level renderers
    strong({ text }) {
      return text;
    }
    em({ text }) {
      return text;
    }
    codespan({ text }) {
      return text;
    }
    del({ text }) {
      return text;
    }
    html({ text }) {
      return text;
    }
    text({ text }) {
      return text;
    }
    link({ text }) {
      return "" + text;
    }
    image({ text }) {
      return "" + text;
    }
    br() {
      return "";
    }
  };
  var _Parser = class __Parser {
    constructor(options2) {
      __publicField(this, "options");
      __publicField(this, "renderer");
      __publicField(this, "textRenderer");
      this.options = options2 || _defaults;
      this.options.renderer = this.options.renderer || new _Renderer();
      this.renderer = this.options.renderer;
      this.renderer.options = this.options;
      this.renderer.parser = this;
      this.textRenderer = new _TextRenderer();
    }
    /**
     * Static Parse Method
     */
    static parse(tokens, options2) {
      const parser2 = new __Parser(options2);
      return parser2.parse(tokens);
    }
    /**
     * Static Parse Inline Method
     */
    static parseInline(tokens, options2) {
      const parser2 = new __Parser(options2);
      return parser2.parseInline(tokens);
    }
    /**
     * Parse Loop
     */
    parse(tokens, top = true) {
      let out = "";
      for (let i5 = 0; i5 < tokens.length; i5++) {
        const anyToken = tokens[i5];
        if (this.options.extensions?.renderers?.[anyToken.type]) {
          const genericToken = anyToken;
          const ret = this.options.extensions.renderers[genericToken.type].call({ parser: this }, genericToken);
          if (ret !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(genericToken.type)) {
            out += ret || "";
            continue;
          }
        }
        const token = anyToken;
        switch (token.type) {
          case "space": {
            out += this.renderer.space(token);
            continue;
          }
          case "hr": {
            out += this.renderer.hr(token);
            continue;
          }
          case "heading": {
            out += this.renderer.heading(token);
            continue;
          }
          case "code": {
            out += this.renderer.code(token);
            continue;
          }
          case "table": {
            out += this.renderer.table(token);
            continue;
          }
          case "blockquote": {
            out += this.renderer.blockquote(token);
            continue;
          }
          case "list": {
            out += this.renderer.list(token);
            continue;
          }
          case "html": {
            out += this.renderer.html(token);
            continue;
          }
          case "paragraph": {
            out += this.renderer.paragraph(token);
            continue;
          }
          case "text": {
            let textToken = token;
            let body = this.renderer.text(textToken);
            while (i5 + 1 < tokens.length && tokens[i5 + 1].type === "text") {
              textToken = tokens[++i5];
              body += "\n" + this.renderer.text(textToken);
            }
            if (top) {
              out += this.renderer.paragraph({
                type: "paragraph",
                raw: body,
                text: body,
                tokens: [{ type: "text", raw: body, text: body, escaped: true }]
              });
            } else {
              out += body;
            }
            continue;
          }
          default: {
            const errMsg = 'Token with "' + token.type + '" type was not found.';
            if (this.options.silent) {
              console.error(errMsg);
              return "";
            } else {
              throw new Error(errMsg);
            }
          }
        }
      }
      return out;
    }
    /**
     * Parse Inline Tokens
     */
    parseInline(tokens, renderer = this.renderer) {
      let out = "";
      for (let i5 = 0; i5 < tokens.length; i5++) {
        const anyToken = tokens[i5];
        if (this.options.extensions?.renderers?.[anyToken.type]) {
          const ret = this.options.extensions.renderers[anyToken.type].call({ parser: this }, anyToken);
          if (ret !== false || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(anyToken.type)) {
            out += ret || "";
            continue;
          }
        }
        const token = anyToken;
        switch (token.type) {
          case "escape": {
            out += renderer.text(token);
            break;
          }
          case "html": {
            out += renderer.html(token);
            break;
          }
          case "link": {
            out += renderer.link(token);
            break;
          }
          case "image": {
            out += renderer.image(token);
            break;
          }
          case "strong": {
            out += renderer.strong(token);
            break;
          }
          case "em": {
            out += renderer.em(token);
            break;
          }
          case "codespan": {
            out += renderer.codespan(token);
            break;
          }
          case "br": {
            out += renderer.br(token);
            break;
          }
          case "del": {
            out += renderer.del(token);
            break;
          }
          case "text": {
            out += renderer.text(token);
            break;
          }
          default: {
            const errMsg = 'Token with "' + token.type + '" type was not found.';
            if (this.options.silent) {
              console.error(errMsg);
              return "";
            } else {
              throw new Error(errMsg);
            }
          }
        }
      }
      return out;
    }
  };
  var _a;
  var _Hooks = (_a = class {
    constructor(options2) {
      __publicField(this, "options");
      __publicField(this, "block");
      this.options = options2 || _defaults;
    }
    /**
     * Process markdown before marked
     */
    preprocess(markdown) {
      return markdown;
    }
    /**
     * Process HTML after marked is finished
     */
    postprocess(html2) {
      return html2;
    }
    /**
     * Process all tokens before walk tokens
     */
    processAllTokens(tokens) {
      return tokens;
    }
    /**
     * Provide function to tokenize markdown
     */
    provideLexer() {
      return this.block ? _Lexer.lex : _Lexer.lexInline;
    }
    /**
     * Provide function to parse tokens
     */
    provideParser() {
      return this.block ? _Parser.parse : _Parser.parseInline;
    }
  }, __publicField(_a, "passThroughHooks", /* @__PURE__ */ new Set([
    "preprocess",
    "postprocess",
    "processAllTokens"
  ])), _a);
  var Marked = class {
    constructor(...args) {
      __publicField(this, "defaults", _getDefaults());
      __publicField(this, "options", this.setOptions);
      __publicField(this, "parse", this.parseMarkdown(true));
      __publicField(this, "parseInline", this.parseMarkdown(false));
      __publicField(this, "Parser", _Parser);
      __publicField(this, "Renderer", _Renderer);
      __publicField(this, "TextRenderer", _TextRenderer);
      __publicField(this, "Lexer", _Lexer);
      __publicField(this, "Tokenizer", _Tokenizer);
      __publicField(this, "Hooks", _Hooks);
      this.use(...args);
    }
    /**
     * Run callback for every token
     */
    walkTokens(tokens, callback) {
      let values = [];
      for (const token of tokens) {
        values = values.concat(callback.call(this, token));
        switch (token.type) {
          case "table": {
            const tableToken = token;
            for (const cell of tableToken.header) {
              values = values.concat(this.walkTokens(cell.tokens, callback));
            }
            for (const row of tableToken.rows) {
              for (const cell of row) {
                values = values.concat(this.walkTokens(cell.tokens, callback));
              }
            }
            break;
          }
          case "list": {
            const listToken = token;
            values = values.concat(this.walkTokens(listToken.items, callback));
            break;
          }
          default: {
            const genericToken = token;
            if (this.defaults.extensions?.childTokens?.[genericToken.type]) {
              this.defaults.extensions.childTokens[genericToken.type].forEach((childTokens) => {
                const tokens2 = genericToken[childTokens].flat(Infinity);
                values = values.concat(this.walkTokens(tokens2, callback));
              });
            } else if (genericToken.tokens) {
              values = values.concat(this.walkTokens(genericToken.tokens, callback));
            }
          }
        }
      }
      return values;
    }
    use(...args) {
      const extensions = this.defaults.extensions || { renderers: {}, childTokens: {} };
      args.forEach((pack) => {
        const opts = { ...pack };
        opts.async = this.defaults.async || opts.async || false;
        if (pack.extensions) {
          pack.extensions.forEach((ext) => {
            if (!ext.name) {
              throw new Error("extension name required");
            }
            if ("renderer" in ext) {
              const prevRenderer = extensions.renderers[ext.name];
              if (prevRenderer) {
                extensions.renderers[ext.name] = function(...args2) {
                  let ret = ext.renderer.apply(this, args2);
                  if (ret === false) {
                    ret = prevRenderer.apply(this, args2);
                  }
                  return ret;
                };
              } else {
                extensions.renderers[ext.name] = ext.renderer;
              }
            }
            if ("tokenizer" in ext) {
              if (!ext.level || ext.level !== "block" && ext.level !== "inline") {
                throw new Error("extension level must be 'block' or 'inline'");
              }
              const extLevel = extensions[ext.level];
              if (extLevel) {
                extLevel.unshift(ext.tokenizer);
              } else {
                extensions[ext.level] = [ext.tokenizer];
              }
              if (ext.start) {
                if (ext.level === "block") {
                  if (extensions.startBlock) {
                    extensions.startBlock.push(ext.start);
                  } else {
                    extensions.startBlock = [ext.start];
                  }
                } else if (ext.level === "inline") {
                  if (extensions.startInline) {
                    extensions.startInline.push(ext.start);
                  } else {
                    extensions.startInline = [ext.start];
                  }
                }
              }
            }
            if ("childTokens" in ext && ext.childTokens) {
              extensions.childTokens[ext.name] = ext.childTokens;
            }
          });
          opts.extensions = extensions;
        }
        if (pack.renderer) {
          const renderer = this.defaults.renderer || new _Renderer(this.defaults);
          for (const prop in pack.renderer) {
            if (!(prop in renderer)) {
              throw new Error(`renderer '${prop}' does not exist`);
            }
            if (["options", "parser"].includes(prop)) {
              continue;
            }
            const rendererProp = prop;
            const rendererFunc = pack.renderer[rendererProp];
            const prevRenderer = renderer[rendererProp];
            renderer[rendererProp] = (...args2) => {
              let ret = rendererFunc.apply(renderer, args2);
              if (ret === false) {
                ret = prevRenderer.apply(renderer, args2);
              }
              return ret || "";
            };
          }
          opts.renderer = renderer;
        }
        if (pack.tokenizer) {
          const tokenizer = this.defaults.tokenizer || new _Tokenizer(this.defaults);
          for (const prop in pack.tokenizer) {
            if (!(prop in tokenizer)) {
              throw new Error(`tokenizer '${prop}' does not exist`);
            }
            if (["options", "rules", "lexer"].includes(prop)) {
              continue;
            }
            const tokenizerProp = prop;
            const tokenizerFunc = pack.tokenizer[tokenizerProp];
            const prevTokenizer = tokenizer[tokenizerProp];
            tokenizer[tokenizerProp] = (...args2) => {
              let ret = tokenizerFunc.apply(tokenizer, args2);
              if (ret === false) {
                ret = prevTokenizer.apply(tokenizer, args2);
              }
              return ret;
            };
          }
          opts.tokenizer = tokenizer;
        }
        if (pack.hooks) {
          const hooks = this.defaults.hooks || new _Hooks();
          for (const prop in pack.hooks) {
            if (!(prop in hooks)) {
              throw new Error(`hook '${prop}' does not exist`);
            }
            if (["options", "block"].includes(prop)) {
              continue;
            }
            const hooksProp = prop;
            const hooksFunc = pack.hooks[hooksProp];
            const prevHook = hooks[hooksProp];
            if (_Hooks.passThroughHooks.has(prop)) {
              hooks[hooksProp] = (arg) => {
                if (this.defaults.async) {
                  return Promise.resolve(hooksFunc.call(hooks, arg)).then((ret2) => {
                    return prevHook.call(hooks, ret2);
                  });
                }
                const ret = hooksFunc.call(hooks, arg);
                return prevHook.call(hooks, ret);
              };
            } else {
              hooks[hooksProp] = (...args2) => {
                let ret = hooksFunc.apply(hooks, args2);
                if (ret === false) {
                  ret = prevHook.apply(hooks, args2);
                }
                return ret;
              };
            }
          }
          opts.hooks = hooks;
        }
        if (pack.walkTokens) {
          const walkTokens2 = this.defaults.walkTokens;
          const packWalktokens = pack.walkTokens;
          opts.walkTokens = function(token) {
            let values = [];
            values.push(packWalktokens.call(this, token));
            if (walkTokens2) {
              values = values.concat(walkTokens2.call(this, token));
            }
            return values;
          };
        }
        this.defaults = { ...this.defaults, ...opts };
      });
      return this;
    }
    setOptions(opt) {
      this.defaults = { ...this.defaults, ...opt };
      return this;
    }
    lexer(src, options2) {
      return _Lexer.lex(src, options2 ?? this.defaults);
    }
    parser(tokens, options2) {
      return _Parser.parse(tokens, options2 ?? this.defaults);
    }
    parseMarkdown(blockType) {
      const parse2 = (src, options2) => {
        const origOpt = { ...options2 };
        const opt = { ...this.defaults, ...origOpt };
        const throwError = this.onError(!!opt.silent, !!opt.async);
        if (this.defaults.async === true && origOpt.async === false) {
          return throwError(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
        }
        if (typeof src === "undefined" || src === null) {
          return throwError(new Error("marked(): input parameter is undefined or null"));
        }
        if (typeof src !== "string") {
          return throwError(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(src) + ", string expected"));
        }
        if (opt.hooks) {
          opt.hooks.options = opt;
          opt.hooks.block = blockType;
        }
        const lexer2 = opt.hooks ? opt.hooks.provideLexer() : blockType ? _Lexer.lex : _Lexer.lexInline;
        const parser2 = opt.hooks ? opt.hooks.provideParser() : blockType ? _Parser.parse : _Parser.parseInline;
        if (opt.async) {
          return Promise.resolve(opt.hooks ? opt.hooks.preprocess(src) : src).then((src2) => lexer2(src2, opt)).then((tokens) => opt.hooks ? opt.hooks.processAllTokens(tokens) : tokens).then((tokens) => opt.walkTokens ? Promise.all(this.walkTokens(tokens, opt.walkTokens)).then(() => tokens) : tokens).then((tokens) => parser2(tokens, opt)).then((html2) => opt.hooks ? opt.hooks.postprocess(html2) : html2).catch(throwError);
        }
        try {
          if (opt.hooks) {
            src = opt.hooks.preprocess(src);
          }
          let tokens = lexer2(src, opt);
          if (opt.hooks) {
            tokens = opt.hooks.processAllTokens(tokens);
          }
          if (opt.walkTokens) {
            this.walkTokens(tokens, opt.walkTokens);
          }
          let html2 = parser2(tokens, opt);
          if (opt.hooks) {
            html2 = opt.hooks.postprocess(html2);
          }
          return html2;
        } catch (e4) {
          return throwError(e4);
        }
      };
      return parse2;
    }
    onError(silent, async) {
      return (e4) => {
        e4.message += "\nPlease report this to https://github.com/markedjs/marked.";
        if (silent) {
          const msg = "<p>An error occurred:</p><pre>" + escape2(e4.message + "", true) + "</pre>";
          if (async) {
            return Promise.resolve(msg);
          }
          return msg;
        }
        if (async) {
          return Promise.reject(e4);
        }
        throw e4;
      };
    }
  };
  var markedInstance = new Marked();
  function marked(src, opt) {
    return markedInstance.parse(src, opt);
  }
  marked.options = marked.setOptions = function(options2) {
    markedInstance.setOptions(options2);
    marked.defaults = markedInstance.defaults;
    changeDefaults(marked.defaults);
    return marked;
  };
  marked.getDefaults = _getDefaults;
  marked.defaults = _defaults;
  marked.use = function(...args) {
    markedInstance.use(...args);
    marked.defaults = markedInstance.defaults;
    changeDefaults(marked.defaults);
    return marked;
  };
  marked.walkTokens = function(tokens, callback) {
    return markedInstance.walkTokens(tokens, callback);
  };
  marked.parseInline = markedInstance.parseInline;
  marked.Parser = _Parser;
  marked.parser = _Parser.parse;
  marked.Renderer = _Renderer;
  marked.TextRenderer = _TextRenderer;
  marked.Lexer = _Lexer;
  marked.lexer = _Lexer.lex;
  marked.Tokenizer = _Tokenizer;
  marked.Hooks = _Hooks;
  marked.parse = marked;
  var options = marked.options;
  var setOptions = marked.setOptions;
  var use = marked.use;
  var walkTokens = marked.walkTokens;
  var parseInline = marked.parseInline;
  var parser = _Parser.parse;
  var lexer = _Lexer.lex;

  // src/components/markdown.tsx
  marked.setOptions({
    gfm: true,
    breaks: false,
    pedantic: false
  });
  function Markdown({ text }) {
    const html2 = renderMarkdown(text);
    const ref = A2(null);
    y2(() => {
      const root2 = ref.current;
      if (!root2) return;
      const blocks = root2.querySelectorAll("pre.oati-code");
      const cleanups = [];
      for (const pre of Array.from(blocks)) {
        if (pre.querySelector(".oati-code-copy")) continue;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "oati-code-copy";
        btn.textContent = "Copy";
        btn.title = "Copy code";
        const onClick = async () => {
          const codeEl = pre.querySelector("code");
          const value = codeEl?.textContent ?? "";
          try {
            await navigator.clipboard.writeText(value);
            btn.textContent = "Copied!";
            setTimeout(() => {
              btn.textContent = "Copy";
            }, 1200);
          } catch {
            btn.textContent = "Copy failed";
            setTimeout(() => {
              btn.textContent = "Copy";
            }, 1200);
          }
        };
        btn.addEventListener("click", onClick);
        pre.appendChild(btn);
        cleanups.push(() => btn.removeEventListener("click", onClick));
      }
      return () => {
        for (const c4 of cleanups) c4();
      };
    }, [html2]);
    return /* @__PURE__ */ u3(
      "div",
      {
        ref,
        class: "oati-markdown",
        dangerouslySetInnerHTML: { __html: html2 }
      }
    );
  }
  function renderMarkdown(text) {
    const result = marked.parse(text, { async: false });
    const raw = typeof result === "string" ? result : "";
    return postProcess(raw);
  }
  function postProcess(html2) {
    const withCode = html2.replace(
      /<pre><code(\s+class="language-([^"]+)")?>/g,
      (_3, classAttr, lang) => {
        if (lang) {
          return `<pre class="oati-code" data-lang="${escapeAttr(lang)}"><span class="oati-code-lang">${escapeHtml(lang)}</span><code${classAttr ?? ""}>`;
        }
        return `<pre class="oati-code"><code${classAttr ?? ""}>`;
      }
    );
    const withTables = withCode.replace(/<table>/g, '<div class="oati-table-wrap"><table class="oati-table">').replace(/<\/table>/g, "</table></div>");
    return withTables;
  }
  function escapeHtml(s5) {
    return s5.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function escapeAttr(s5) {
    return s5.replace(/"/g, "&quot;").replace(/</g, "&lt;");
  }

  // src/components/tool-card.tsx
  function ToolCard({ card, onOpenPath }) {
    const expanded = useSignal(false);
    const status = !card.result ? "running" : card.result.isError ? "error" : "ok";
    const summary = card.summary ?? "";
    const outputPreview = card.result ? renderPreview(card.result.output) : "";
    const lineCount = outputPreview ? outputPreview.split("\n").length : 0;
    const canExpand = outputPreview.length > 0;
    const streaming = card.streamingOutput ?? "";
    const isStreaming = !card.result && streaming.length > 0;
    const category = categorizeTool(card.name);
    const displayName = prettifyToolName(card.name);
    return /* @__PURE__ */ u3("div", { class: `oati-toolcard oati-toolcard-${status}`, "data-category": category, children: [
      /* @__PURE__ */ u3("div", { class: "oati-toolcard-row", children: [
        /* @__PURE__ */ u3("span", { class: `oati-toolcard-status oati-toolcard-status-${status}`, "aria-hidden": "true" }),
        /* @__PURE__ */ u3(FileIcon, { size: 13, class: "oati-toolcard-icon", title: card.name }),
        /* @__PURE__ */ u3("span", { class: "oati-toolcard-name", children: displayName }),
        summary && /* @__PURE__ */ u3("span", { class: "oati-toolcard-summary", title: summary, children: summary }),
        /* @__PURE__ */ u3("span", { class: "oati-toolcard-spacer" }),
        card.result && lineCount > 0 && /* @__PURE__ */ u3("span", { class: "oati-toolcard-meta", children: [
          lineCount,
          " ",
          lineCount === 1 ? "line" : "lines"
        ] }),
        card.path && onOpenPath && /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-toolcard-action",
            onClick: (e4) => {
              e4.stopPropagation();
              if (card.path) onOpenPath(card.path);
            },
            title: `Open ${card.path}`,
            children: "Open"
          }
        ),
        canExpand && /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-toolcard-action",
            onClick: () => {
              expanded.value = !expanded.value;
            },
            title: expanded.value ? "Collapse" : "Expand",
            "aria-expanded": expanded.value,
            children: expanded.value ? "Hide" : "Show"
          }
        )
      ] }),
      isStreaming && /* @__PURE__ */ u3("pre", { class: "oati-toolcard-output oati-toolcard-streaming", children: /* @__PURE__ */ u3("code", { children: truncateForDisplay(streaming) }) }),
      canExpand && expanded.value && /* @__PURE__ */ u3("pre", { class: "oati-toolcard-output", children: /* @__PURE__ */ u3("code", { children: truncateForDisplay(outputPreview) }) })
    ] });
  }
  function renderPreview(output) {
    if (typeof output === "string") return output;
    try {
      return JSON.stringify(output, null, 2);
    } catch {
      return String(output);
    }
  }
  function truncateForDisplay(s5) {
    const MAX = 2e4;
    if (s5.length <= MAX) return s5;
    return `${s5.slice(0, MAX)}

\u2026[${s5.length - MAX} more chars truncated \u2014 click Open to view the file]`;
  }
  function categorizeTool(name) {
    if (name === "read_file" || name === "list_dir" || name === "get_workspace_context" || name === "read_notebook" || name === "read_notebook_cell" || name === "find_definition" || name === "find_references" || name === "symbols_in_file" || name === "read_shared_notes" || name === "recall_facts" || name === "list_snippets" || name === "list_knowledge" || name === "get_diagnostics" || name === "list_hooks" || name === "list_skills") {
      return "read";
    }
    if (name === "write_file" || name === "edit_notebook_cell" || name === "insert_notebook_cell" || name === "delete_notebook_cell" || name === "save_snippet" || name === "smart_apply_patch" || name === "multi_cursor_edit" || name === "remember_fact" || name === "write_shared_note") {
      return "write";
    }
    if (name === "grep_search" || name === "code_semantic_search" || name === "codebase_deep_search" || name === "search_conversations" || name === "search_knowledge") {
      return "search";
    }
    if (name === "exec" || name === "run_tests" || name === "run_notebook_cell" || name === "start_background_task" || name === "run_recipe") {
      return "exec";
    }
    if (name === "fetch_url" || name === "web_search" || name === "browser_open" || name === "browser_navigate" || name === "browser_screenshot" || name === "browser_eval" || name === "browser_close") {
      return "web";
    }
    if (name.startsWith("debug_") || name === "screenshot") return "debug";
    if (name.startsWith("git_") || name.startsWith("gh_") || name === "suggest_commit_message") {
      return "git";
    }
    if (name.startsWith("debug_")) return "debug";
    return "other";
  }
  function prettifyToolName(name) {
    const map = {
      read_file: "Read",
      write_file: "Write",
      list_dir: "List",
      grep_search: "Grep",
      code_semantic_search: "Search",
      codebase_deep_search: "Search",
      exec: "Run",
      run_tests: "Test",
      fetch_url: "Fetch",
      web_search: "Web",
      smart_apply_patch: "Apply",
      multi_cursor_edit: "Edit",
      read_notebook: "Read notebook",
      read_notebook_cell: "Read cell",
      edit_notebook_cell: "Edit cell",
      insert_notebook_cell: "Insert cell",
      delete_notebook_cell: "Delete cell",
      run_notebook_cell: "Run cell",
      get_workspace_context: "Context",
      get_diagnostics: "Diagnostics",
      find_definition: "Definition",
      find_references: "References",
      symbols_in_file: "Symbols",
      git_status: "Git status",
      git_diff: "Git diff",
      git_commit: "Git commit",
      git_open_pr: "Open PR",
      gh_issue_read: "Issue",
      gh_issue_comment: "Comment",
      suggest_commit_message: "Commit msg",
      spawn_agent: "Sub-agent",
      spawn_parallel_agents: "Parallel agents",
      remember_fact: "Remember",
      recall_facts: "Recall",
      render_diagram: "Diagram"
    };
    return map[name] ?? name;
  }

  // src/components/message-list.tsx
  function MessageList({
    messages: messages2,
    onOpenPath,
    onRegenerateFrom,
    onCancel,
    onForkFrom,
    onTogglePin,
    jumpToMessageId: jumpToMessageId2,
    showTokenUsage: showTokenUsage2,
    showStopButton: showStopButton2
  }) {
    const containerRef = A2(null);
    const wasNearBottom = A2(true);
    const lastMessageId = A2(void 0);
    y2(() => {
      const el = containerRef.current;
      if (!el) return;
      const onScroll = () => {
        const dist = el.scrollHeight - el.scrollTop - el.clientHeight;
        wasNearBottom.current = dist < 80;
      };
      el.addEventListener("scroll", onScroll, { passive: true });
      return () => el.removeEventListener("scroll", onScroll);
    }, []);
    y2(() => {
      const el = containerRef.current;
      if (!el) return;
      const last = messages2[messages2.length - 1];
      const isNewMessage = last?.id !== lastMessageId.current;
      lastMessageId.current = last?.id;
      if (isNewMessage || wasNearBottom.current) {
        el.scrollTop = el.scrollHeight;
      }
    }, [messages2]);
    y2(() => {
      if (!jumpToMessageId2) return;
      const el = containerRef.current;
      if (!el) return;
      const target = el.querySelector(`[data-message-id="${jumpToMessageId2}"]`);
      if (!target) return;
      target.scrollIntoView({ behavior: "smooth", block: "center" });
      target.classList.add("oati-message-flash");
      const t4 = window.setTimeout(() => {
        target.classList.remove("oati-message-flash");
      }, 1400);
      return () => window.clearTimeout(t4);
    }, [jumpToMessageId2]);
    return /* @__PURE__ */ u3("div", { ref: containerRef, class: "oati-messages", children: messages2.map((m4) => /* @__PURE__ */ u3(
      MessageBubble,
      {
        message: m4,
        onOpenPath,
        onRegenerateFrom,
        onCancel,
        onForkFrom,
        onTogglePin,
        showTokenUsage: showTokenUsage2,
        showStopButton: showStopButton2
      },
      m4.id
    )) });
  }
  var USER_MESSAGE_COLLAPSE_CHARS = 600;
  var USER_MESSAGE_COLLAPSE_LINES = 10;
  var ASSISTANT_MESSAGE_COLLAPSE_CHARS = 6e3;
  var ASSISTANT_MESSAGE_COLLAPSE_LINES = 80;
  function shouldCollapseFor(role, text) {
    const charLimit = role === "assistant" ? ASSISTANT_MESSAGE_COLLAPSE_CHARS : USER_MESSAGE_COLLAPSE_CHARS;
    const lineLimit = role === "assistant" ? ASSISTANT_MESSAGE_COLLAPSE_LINES : USER_MESSAGE_COLLAPSE_LINES;
    if (text.length > charLimit) return true;
    let lines = 1;
    for (let i5 = 0; i5 < text.length; i5++) {
      if (text.charCodeAt(i5) === 10) {
        lines++;
        if (lines > lineLimit) return true;
      }
    }
    return false;
  }
  function truncatedPreviewFor(role, text) {
    const charLimit = role === "assistant" ? ASSISTANT_MESSAGE_COLLAPSE_CHARS : USER_MESSAGE_COLLAPSE_CHARS;
    const lineLimit = role === "assistant" ? ASSISTANT_MESSAGE_COLLAPSE_LINES : USER_MESSAGE_COLLAPSE_LINES;
    const lines = text.split("\n");
    const kept = lines.slice(0, lineLimit).join("\n");
    if (kept.length <= charLimit) return kept;
    return kept.slice(0, charLimit);
  }
  var shouldCollapse = (text) => shouldCollapseFor("user", text);
  var truncatedPreview = (text) => truncatedPreviewFor("user", text);
  var COLLAPSE_REPEAT_THRESHOLD = 3;
  function collapseRepeatedLines(text) {
    if (!text.includes("\n")) return text;
    const lines = text.split("\n");
    const out = [];
    let i5 = 0;
    let collapsed = false;
    while (i5 < lines.length) {
      const line = lines[i5];
      const trimmed = line.trim();
      if (trimmed.length === 0) {
        out.push(line);
        i5++;
        continue;
      }
      let j4 = i5 + 1;
      while (j4 < lines.length && lines[j4].trim() === trimmed) j4++;
      const runLength = j4 - i5;
      if (runLength >= COLLAPSE_REPEAT_THRESHOLD) {
        out.push(`${line}  _\xD7 ${runLength}_`);
        collapsed = true;
      } else {
        for (let k3 = i5; k3 < j4; k3++) out.push(lines[k3]);
      }
      i5 = j4;
    }
    return collapsed ? out.join("\n") : text;
  }
  function MessageBubble({
    message,
    onOpenPath,
    onRegenerateFrom,
    onCancel,
    onForkFrom,
    onTogglePin,
    showTokenUsage: showTokenUsage2,
    showStopButton: showStopButton2
  }) {
    const bodyRef = A2(null);
    const [editing, setEditing] = d2(false);
    const [draft, setDraft] = d2("");
    const [expanded, setExpanded] = d2(false);
    const editTextareaRef = A2(null);
    y2(() => {
      if (editing && editTextareaRef.current) {
        const ta = editTextareaRef.current;
        ta.focus();
        ta.setSelectionRange(ta.value.length, ta.value.length);
      }
    }, [editing]);
    if (message.toolCard) {
      return /* @__PURE__ */ u3("div", { class: `oati-message oati-message-${message.role}`, children: /* @__PURE__ */ u3(ToolCard, { card: message.toolCard, onOpenPath }) });
    }
    const useMarkdown = message.role === "assistant" || message.role === "system";
    const showActions = message.role === "assistant" || message.role === "user";
    const canEdit = message.role === "user" && onRegenerateFrom !== void 0;
    const handleCopy = async () => {
      const text = bodyRef.current?.innerText ?? message.text;
      try {
        await navigator.clipboard.writeText(text);
      } catch {
      }
    };
    const startEdit = () => {
      setDraft(message.text);
      setEditing(true);
    };
    const cancelEdit = () => {
      setEditing(false);
      setDraft("");
    };
    const saveEdit = () => {
      const next = draft.trim();
      if (next.length === 0) return;
      if (next === message.text.trim()) {
        cancelEdit();
        return;
      }
      onRegenerateFrom?.(message.id, next);
      setEditing(false);
      setDraft("");
    };
    const onEditKey = (e4) => {
      if (e4.key === "Escape") {
        e4.preventDefault();
        cancelEdit();
      } else if (e4.key === "Enter" && (e4.ctrlKey || e4.metaKey)) {
        e4.preventDefault();
        saveEdit();
      }
    };
    return /* @__PURE__ */ u3(
      "div",
      {
        class: `oati-message oati-message-${message.role}${message.pinned ? " oati-message-pinned" : ""}`,
        "data-message-id": message.id,
        children: [
          message.role !== "system" && /* @__PURE__ */ u3("div", { class: "oati-message-header", children: [
            /* @__PURE__ */ u3("span", { class: "oati-message-role", "aria-hidden": "true" }),
            showActions && !editing && /* @__PURE__ */ u3("div", { class: "oati-message-actions", children: [
              canEdit && /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-icon-btn oati-icon-btn-sm",
                  title: "Edit and regenerate from this prompt",
                  onClick: startEdit,
                  "aria-label": "Edit message",
                  children: /* @__PURE__ */ u3(EditIcon, { size: 12 })
                }
              ),
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-icon-btn oati-icon-btn-sm",
                  title: "Copy message",
                  onClick: handleCopy,
                  "aria-label": "Copy message",
                  children: /* @__PURE__ */ u3(CopyIcon, { size: 12 })
                }
              ),
              onTogglePin && /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-icon-btn oati-icon-btn-sm",
                  title: message.pinned ? "Unpin message" : "Pin message",
                  onClick: () => onTogglePin(message.id, !message.pinned),
                  "aria-label": message.pinned ? "Unpin message" : "Pin message",
                  children: message.pinned ? "\u{1F4CC}" : "\u{1F4CD}"
                }
              ),
              onForkFrom && /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-icon-btn oati-icon-btn-sm",
                  title: "Fork conversation from here",
                  onClick: () => onForkFrom(message.id),
                  "aria-label": "Fork conversation from here",
                  children: "\u2442"
                }
              )
            ] })
          ] }),
          editing ? /* @__PURE__ */ u3("div", { class: "oati-message-edit", children: [
            /* @__PURE__ */ u3(
              "textarea",
              {
                ref: editTextareaRef,
                class: "oati-message-edit-textarea",
                value: draft,
                onInput: (e4) => setDraft(e4.target.value),
                onKeyDown: onEditKey,
                rows: Math.max(2, Math.min(12, draft.split("\n").length + 1)),
                "aria-label": "Edit user message"
              }
            ),
            /* @__PURE__ */ u3("div", { class: "oati-message-edit-actions", children: [
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-icon-btn oati-icon-btn-sm",
                  title: "Cancel (Esc)",
                  onClick: cancelEdit,
                  "aria-label": "Cancel edit",
                  children: /* @__PURE__ */ u3(XIcon, { size: 12 })
                }
              ),
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-icon-btn oati-icon-btn-sm",
                  title: "Save and regenerate (Ctrl+Enter)",
                  onClick: saveEdit,
                  "aria-label": "Save edit and regenerate",
                  disabled: draft.trim().length === 0 || draft.trim() === message.text.trim(),
                  children: /* @__PURE__ */ u3(CheckIcon, { size: 12 })
                }
              )
            ] })
          ] }) : /* @__PURE__ */ u3("div", { ref: bodyRef, class: "oati-message-text", children: [
            useMarkdown ? /* @__PURE__ */ u3(
              AssistantOrSystemBody,
              {
                role: message.role,
                text: message.text,
                expanded,
                onToggleExpanded: () => setExpanded((v5) => !v5)
              }
            ) : /* @__PURE__ */ u3(
              UserMessageBody,
              {
                text: message.text,
                pending: message.pending,
                expanded,
                onToggleExpanded: () => setExpanded((v5) => !v5)
              }
            ),
            message.role === "assistant" && message.pending ? /* @__PURE__ */ u3("span", { class: "oati-message-streaming-row", children: [
              /* @__PURE__ */ u3("span", { class: "oati-cursor", children: "\u258D" }),
              showStopButton2 && onCancel && /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-message-stop",
                  title: "Stop generating (Esc, /stop)",
                  onClick: onCancel,
                  "aria-label": "Stop generating",
                  children: [
                    /* @__PURE__ */ u3(StopIcon, { size: 11 }),
                    /* @__PURE__ */ u3("span", { children: "Stop" })
                  ]
                }
              )
            ] }) : null,
            message.images && message.images.length > 0 && /* @__PURE__ */ u3("div", { class: "oati-message-images", children: message.images.map((img, i5) => (
              // biome-ignore lint/suspicious/noArrayIndexKey: pasted images have no stable id; index is fine.
              /* @__PURE__ */ u3("img", { src: img.dataUrl, alt: "attached", class: "oati-message-image" }, i5)
            )) }),
            showTokenUsage2 && message.role === "assistant" && message.tokens && /* @__PURE__ */ u3(TokenInline, { input: message.tokens.input, output: message.tokens.output }),
            showTokenUsage2 && message.role === "assistant" && typeof message.durationMs === "number" && /* @__PURE__ */ u3(DurationInline, { ms: message.durationMs })
          ] })
        ]
      }
    );
  }
  function AssistantOrSystemBody({
    role,
    text,
    expanded,
    onToggleExpanded
  }) {
    const compacted = collapseRepeatedLines(text);
    const collapsible = shouldCollapseFor(role, compacted);
    if (!collapsible || expanded) {
      return /* @__PURE__ */ u3(S, { children: [
        /* @__PURE__ */ u3(Markdown, { text: compacted }),
        collapsible && /* @__PURE__ */ u3("button", { type: "button", class: "oati-message-showmore", onClick: onToggleExpanded, children: "Show less" })
      ] });
    }
    const preview = truncatedPreviewFor(role, compacted);
    const hiddenChars = compacted.length - preview.length;
    return /* @__PURE__ */ u3(S, { children: [
      /* @__PURE__ */ u3(Markdown, { text: preview }),
      /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: "oati-message-showmore",
          onClick: onToggleExpanded,
          title: `Reveal ${hiddenChars.toLocaleString()} more characters`,
          children: [
            "Show more (",
            hiddenChars.toLocaleString(),
            " more chars)"
          ]
        }
      )
    ] });
  }
  function UserMessageBody({
    text,
    pending,
    expanded,
    onToggleExpanded
  }) {
    const collapsible = shouldCollapse(text);
    if (!collapsible || expanded) {
      return /* @__PURE__ */ u3(S, { children: [
        text,
        pending ? " \u258D" : "",
        collapsible && /* @__PURE__ */ u3("button", { type: "button", class: "oati-message-showmore", onClick: onToggleExpanded, children: "Show less" })
      ] });
    }
    const preview = truncatedPreview(text);
    const hiddenChars = text.length - preview.length;
    return /* @__PURE__ */ u3(S, { children: [
      preview,
      /* @__PURE__ */ u3("span", { class: "oati-message-truncated", children: "\u2026" }),
      /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: "oati-message-showmore",
          onClick: onToggleExpanded,
          title: `Reveal ${hiddenChars.toLocaleString()} more characters`,
          children: [
            "Show more (",
            hiddenChars.toLocaleString(),
            " more chars)"
          ]
        }
      )
    ] });
  }
  function TokenInline({ input, output }) {
    if (input === 0 && output === 0) return null;
    return /* @__PURE__ */ u3("span", { class: "oati-message-tokens", title: "Tokens used by this assistant turn", children: [
      "\u2193",
      formatShortTokens(input),
      " \u2191",
      formatShortTokens(output)
    ] });
  }
  function formatShortTokens(n3) {
    if (n3 < 1e3) return String(n3);
    if (n3 < 1e6) return `${(n3 / 1e3).toFixed(1)}k`;
    return `${(n3 / 1e6).toFixed(2)}M`;
  }
  function DurationInline({ ms }) {
    return /* @__PURE__ */ u3("span", { class: "oati-message-duration", title: "Wall-clock time for this turn", children: [
      "(in ",
      formatShortDuration(ms),
      ")"
    ] });
  }
  function formatShortDuration(ms) {
    if (ms < 1) return "<1ms";
    if (ms < 1e3) return `${Math.round(ms)}ms`;
    return `${(ms / 1e3).toFixed(ms < 1e4 ? 1 : 0)}s`;
  }

  // src/components/onboarding-tour.tsx
  var ONBOARDING_STORAGE_KEY = "oati.onboarding.completed";
  var STEPS = [
    {
      title: "1. Pick a mode",
      body: "Use the mode picker to switch between Ask, Plan, Code, Auto Edit, and Auto. Each mode preconfigures tools, approval policy, and prompts.",
      highlight: [".oati-mode-picker", ".mode-picker", "[data-onboarding='mode-picker']"]
    },
    {
      title: "2. Ask anything",
      body: "Type a question or paste code. Use @ to mention workspace files, and Shift+Enter for newlines. Drop image attachments straight in.",
      highlight: [".oati-input", ".oati-composer", "textarea", "[data-onboarding='composer']"]
    },
    {
      title: "3. Slash commands",
      body: "Type / at the start of the input to see commands: /compact to trim history, /cost for token totals, /split for a second pane, /help for the full list.",
      highlight: [".oati-input", ".oati-composer", "textarea", "[data-onboarding='composer']"]
    },
    {
      title: "4. Settings & API keys",
      body: "Open Settings (gear icon) to bring your own provider key. Keys are stored in VS Code SecretStorage \u2014 they never leave this machine and aren't synced.",
      highlight: ["[aria-label='Settings']", ".oati-header-actions [aria-label='Settings']"]
    }
  ];
  var PADDING = 6;
  function findTargetRect(selectors) {
    if (!selectors) return null;
    if (typeof document === "undefined") return null;
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el instanceof HTMLElement) {
        const rect = el.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          return {
            top: Math.max(0, rect.top - PADDING),
            left: Math.max(0, rect.left - PADDING),
            width: rect.width + PADDING * 2,
            height: rect.height + PADDING * 2
          };
        }
      }
    }
    return null;
  }
  function OnboardingTour({ onDismiss }) {
    const [step, setStep] = d2(0);
    const [rect, setRect] = d2(null);
    const current = STEPS[step];
    y2(() => {
      const update = () => setRect(findTargetRect(current.highlight));
      update();
      window.addEventListener("resize", update);
      const id = window.setInterval(update, 500);
      return () => {
        window.removeEventListener("resize", update);
        window.clearInterval(id);
      };
    }, [current]);
    const isLast = step === STEPS.length - 1;
    const handleNext = () => {
      if (isLast) {
        onDismiss();
      } else {
        setStep((s5) => s5 + 1);
      }
    };
    const handleSkip = () => onDismiss();
    const overlayPieces = T2(() => {
      if (!rect) {
        return [{ key: "full", style: { inset: "0" } }];
      }
      const { top, left, width, height } = rect;
      return [
        { key: "top", style: { left: "0", top: "0", right: "0", height: `${top}px` } },
        {
          key: "bottom",
          style: { left: "0", top: `${top + height}px`, right: "0", bottom: "0" }
        },
        {
          key: "left",
          style: { left: "0", top: `${top}px`, width: `${left}px`, height: `${height}px` }
        },
        {
          key: "right",
          style: {
            left: `${left + width}px`,
            top: `${top}px`,
            right: "0",
            height: `${height}px`
          }
        }
      ];
    }, [rect]);
    return /* @__PURE__ */ u3("div", { class: "oati-onboarding-root", "aria-label": "OATI Code onboarding tour", children: [
      overlayPieces.map((piece) => /* @__PURE__ */ u3(
        "div",
        {
          class: "oati-onboarding-veil",
          style: {
            position: "fixed",
            background: "rgba(0, 0, 0, 0.55)",
            zIndex: 9998,
            pointerEvents: "none",
            ...piece.style
          }
        },
        piece.key
      )),
      rect && /* @__PURE__ */ u3(
        "div",
        {
          class: "oati-onboarding-ring",
          style: {
            position: "fixed",
            top: `${rect.top}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            height: `${rect.height}px`,
            border: "2px solid var(--vscode-focusBorder, #0e639c)",
            borderRadius: "6px",
            boxShadow: "0 0 0 4px rgba(14, 99, 156, 0.35)",
            zIndex: 9999,
            pointerEvents: "none"
          }
        }
      ),
      /* @__PURE__ */ u3(
        "div",
        {
          class: "oati-onboarding-card",
          style: {
            position: "fixed",
            bottom: "32px",
            right: "32px",
            maxWidth: "360px",
            background: "var(--vscode-editorWidget-background, #252526)",
            color: "var(--vscode-editorWidget-foreground, #cccccc)",
            border: "1px solid var(--vscode-editorWidget-border, #454545)",
            borderRadius: "8px",
            boxShadow: "0 8px 32px rgba(0, 0, 0, 0.45)",
            padding: "16px 18px",
            zIndex: 1e4,
            fontSize: "13px",
            lineHeight: "1.45"
          },
          children: [
            /* @__PURE__ */ u3(
              "div",
              {
                style: {
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "baseline",
                  marginBottom: "8px"
                },
                children: [
                  /* @__PURE__ */ u3("strong", { style: { fontSize: "14px" }, children: current.title }),
                  /* @__PURE__ */ u3("span", { style: { opacity: 0.7, fontSize: "11px" }, children: [
                    step + 1,
                    " / ",
                    STEPS.length
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ u3("p", { style: { margin: "0 0 12px 0" }, children: current.body }),
            /* @__PURE__ */ u3("div", { style: { display: "flex", gap: "8px", justifyContent: "flex-end" }, children: [
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  onClick: handleSkip,
                  style: {
                    background: "transparent",
                    border: "1px solid var(--vscode-button-border, transparent)",
                    color: "var(--vscode-button-secondaryForeground, #cccccc)",
                    padding: "4px 12px",
                    borderRadius: "4px",
                    cursor: "pointer"
                  },
                  children: "Skip tour"
                }
              ),
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  onClick: handleNext,
                  style: {
                    background: "var(--vscode-button-background, #0e639c)",
                    color: "var(--vscode-button-foreground, #ffffff)",
                    border: "none",
                    padding: "4px 14px",
                    borderRadius: "4px",
                    cursor: "pointer",
                    fontWeight: 600
                  },
                  children: isLast ? "Got it" : "Next"
                }
              )
            ] })
          ]
        }
      )
    ] });
  }
  function isOnboardingCompleted() {
    try {
      if (typeof localStorage === "undefined") return true;
      return localStorage.getItem(ONBOARDING_STORAGE_KEY) === "1";
    } catch {
      return true;
    }
  }
  function markOnboardingCompleted() {
    try {
      if (typeof localStorage === "undefined") return;
      localStorage.setItem(ONBOARDING_STORAGE_KEY, "1");
    } catch {
    }
  }

  // src/components/plan-proposal.tsx
  function PlanProposalBanner({ plan, onExecute, onDismiss }) {
    const steps = plan.steps ?? [];
    if (steps.length === 0) return null;
    return /* @__PURE__ */ u3("div", { class: "oati-plan-banner", children: [
      /* @__PURE__ */ u3("div", { class: "oati-plan-banner-header", children: [
        /* @__PURE__ */ u3("span", { class: "oati-plan-banner-icon", "aria-hidden": "true", children: "\u25C8" }),
        /* @__PURE__ */ u3("span", { class: "oati-plan-banner-title", children: [
          "Plan ready \xB7 ",
          steps.length,
          " steps"
        ] }),
        /* @__PURE__ */ u3("span", { class: "oati-plan-banner-spacer" }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-plan-banner-execute",
            onClick: () => onExecute(plan),
            title: "Run the plan now",
            children: "Execute \u25B6"
          }
        ),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-plan-banner-dismiss",
            onClick: onDismiss,
            title: "Dismiss without executing",
            "aria-label": "Dismiss plan",
            children: "\xD7"
          }
        )
      ] }),
      /* @__PURE__ */ u3("ol", { class: "oati-plan-banner-steps", children: steps.map((s5) => /* @__PURE__ */ u3("li", { class: "oati-plan-banner-step", children: [
        /* @__PURE__ */ u3("span", { class: "oati-plan-banner-step-n", children: [
          s5.n,
          "."
        ] }),
        /* @__PURE__ */ u3("span", { class: "oati-plan-banner-step-desc", children: s5.description }),
        s5.rationale && /* @__PURE__ */ u3("span", { class: "oati-plan-banner-step-rationale", children: [
          " \u2014 ",
          s5.rationale
        ] })
      ] }, s5.n)) })
    ] });
  }

  // src/components/progress-indicator.tsx
  function ProgressIndicator({ running, status }) {
    if (!running) return null;
    const label = describe(status);
    return /* @__PURE__ */ u3("output", { class: "oati-progress", "aria-live": "polite", children: [
      /* @__PURE__ */ u3("span", { class: "oati-progress-spinner", "aria-hidden": "true" }),
      /* @__PURE__ */ u3("span", { class: "oati-progress-label", children: label }),
      (status.inputTokens > 0 || status.outputTokens > 0) && /* @__PURE__ */ u3("span", { class: "oati-progress-tokens", children: [
        "\u2193",
        formatTokens(status.inputTokens),
        " \u2191",
        formatTokens(status.outputTokens)
      ] })
    ] });
  }
  function describe(status) {
    if (status.currentTool) {
      const detail = summarizeArgs(status.currentTool, status.currentToolArgs);
      return detail ? `Running ${status.currentTool} \u2014 ${detail}` : `Running ${status.currentTool}\u2026`;
    }
    if (status.retryAttempt && status.retryAttempt > 0) {
      return `Retry attempt ${status.retryAttempt}\u2026`;
    }
    if (status.stage === "planner") return "Planning\u2026";
    if (status.stage === "critic") return "Reviewing result\u2026";
    if (status.stage === "executor" || status.iteration) {
      return status.iteration ? `Thinking (iteration ${status.iteration})\u2026` : "Thinking\u2026";
    }
    return "Thinking\u2026";
  }
  function summarizeArgs(tool, args) {
    if (!args || typeof args !== "object") return void 0;
    const a4 = args;
    const path = pickString(a4, ["path", "file", "filePath", "uri"]);
    if (path) return truncate(path, 60);
    if (tool.toLowerCase().includes("exec")) {
      const cmd = pickString(a4, ["command", "cmd"]);
      if (cmd) return truncate(cmd, 60);
    }
    if (tool.toLowerCase().includes("fetch")) {
      const url = pickString(a4, ["url"]);
      if (url) return truncate(url, 60);
    }
    const summary = pickString(a4, ["summary", "description", "query"]);
    if (summary) return truncate(summary, 60);
    return void 0;
  }
  function pickString(o4, keys) {
    for (const k3 of keys) {
      const v5 = o4[k3];
      if (typeof v5 === "string" && v5.length > 0) return v5;
    }
    return void 0;
  }
  function truncate(s5, n3) {
    const flat = s5.replace(/\s+/g, " ").trim();
    return flat.length > n3 ? `${flat.slice(0, n3)}\u2026` : flat;
  }
  function formatTokens(n3) {
    if (n3 < 1e3) return String(n3);
    if (n3 < 1e6) return `${(n3 / 1e3).toFixed(1)}k`;
    return `${(n3 / 1e6).toFixed(2)}M`;
  }

  // src/components/experimental-section.tsx
  function ExperimentalSection({ bus }) {
    const supervisorEnabled = useSignal(localBool("oati.supervisor.enabled", false));
    const supervisorInterval = useSignal(localNum("oati.supervisor.intervalSeconds", 120));
    const streamingEnabled = useSignal(localBool("oati.streamingWrites.enabled", true));
    const inlineEnabled = useSignal(localBool("oati.inlineCompletion.enabled", true));
    y2(() => {
      const persist = (key, value) => {
        try {
          localStorage.setItem(key, JSON.stringify(value));
        } catch {
        }
      };
      persist("oati.supervisor.enabled", supervisorEnabled.value);
      persist("oati.supervisor.intervalSeconds", supervisorInterval.value);
      persist("oati.streamingWrites.enabled", streamingEnabled.value);
      persist("oati.inlineCompletion.enabled", inlineEnabled.value);
    }, [
      supervisorEnabled.value,
      supervisorInterval.value,
      streamingEnabled.value,
      inlineEnabled.value
    ]);
    const writeConfig = (key, value) => {
      bus.send({
        type: "run_vscode_command",
        command: "oati.config.set",
        args: [key, value]
      });
    };
    return /* @__PURE__ */ u3("div", { class: "oati-experimental", children: [
      /* @__PURE__ */ u3("div", { class: "oati-help", style: { marginBottom: "8px" }, children: "Toggles below write to VS Code's workspace configuration. Each takes effect immediately \u2014 no reload required." }),
      /* @__PURE__ */ u3("label", { class: "oati-experimental-row", children: [
        /* @__PURE__ */ u3(
          "input",
          {
            type: "checkbox",
            checked: supervisorEnabled.value,
            onChange: (e4) => {
              const next = e4.target.checked;
              supervisorEnabled.value = next;
              writeConfig("oati.supervisor.enabled", next);
            }
          }
        ),
        /* @__PURE__ */ u3("div", { class: "oati-experimental-row-body", children: [
          /* @__PURE__ */ u3("div", { class: "oati-experimental-row-title", children: "Background supervisor agent" }),
          /* @__PURE__ */ u3("div", { class: "oati-experimental-row-desc", children: "Watches recent edits and posts non-blocking suggestions below the chat. Issues extra model calls \u2014 off by default." })
        ] })
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-experimental-row", children: [
        /* @__PURE__ */ u3("span", { class: "oati-experimental-spacer" }),
        /* @__PURE__ */ u3("div", { class: "oati-experimental-row-body", children: [
          /* @__PURE__ */ u3("div", { class: "oati-experimental-row-title", children: "Supervisor interval (seconds)" }),
          /* @__PURE__ */ u3(
            "input",
            {
              type: "number",
              min: 30,
              max: 1800,
              step: 30,
              value: supervisorInterval.value,
              onInput: (e4) => {
                const raw = Number(e4.target.value);
                const v5 = Math.max(30, Math.min(1800, Number.isFinite(raw) ? raw : 120));
                supervisorInterval.value = v5;
                writeConfig("oati.supervisor.intervalSeconds", v5);
              }
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-experimental-row", children: [
        /* @__PURE__ */ u3(
          "input",
          {
            type: "checkbox",
            checked: streamingEnabled.value,
            onChange: (e4) => {
              const next = e4.target.checked;
              streamingEnabled.value = next;
              writeConfig("oati.streamingWrites.enabled", next);
            }
          }
        ),
        /* @__PURE__ */ u3("div", { class: "oati-experimental-row-body", children: [
          /* @__PURE__ */ u3("div", { class: "oati-experimental-row-title", children: "Animate file writes" }),
          /* @__PURE__ */ u3("div", { class: "oati-experimental-row-desc", children: "Stream `write_file` results into the editor in small chunks (Cursor / Claude-style). Files over 24KB always write instantly." })
        ] })
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-experimental-row", children: [
        /* @__PURE__ */ u3(
          "input",
          {
            type: "checkbox",
            checked: inlineEnabled.value,
            onChange: (e4) => {
              const next = e4.target.checked;
              inlineEnabled.value = next;
              writeConfig("oati.inlineCompletion.enabled", next);
            }
          }
        ),
        /* @__PURE__ */ u3("div", { class: "oati-experimental-row-body", children: [
          /* @__PURE__ */ u3("div", { class: "oati-experimental-row-title", children: "Inline ghost-text completion" }),
          /* @__PURE__ */ u3("div", { class: "oati-experimental-row-desc", children: "Cursor-style suggestions as you type. Tab to accept, Esc to dismiss, Alt+] / Alt+[ to cycle alternates." })
        ] })
      ] })
    ] });
  }
  function localBool(key, fallback) {
    try {
      const v5 = localStorage.getItem(key);
      if (v5 === null) return fallback;
      return JSON.parse(v5) === true;
    } catch {
      return fallback;
    }
  }
  function localNum(key, fallback) {
    try {
      const v5 = localStorage.getItem(key);
      if (v5 === null) return fallback;
      const n3 = Number(JSON.parse(v5));
      return Number.isFinite(n3) ? n3 : fallback;
    } catch {
      return fallback;
    }
  }

  // src/components/hooks-editor.tsx
  var EVENTS = [
    "PreToolUse",
    "PostToolUse",
    "UserPromptSubmit",
    "SessionStart",
    "Stop"
  ];
  function HooksEditor({ snapshot, onSave }) {
    const hooks = snapshot.config.hooks ?? [];
    const draftEvent = useSignal("PreToolUse");
    const draftMatcher = useSignal("");
    const draftCommand = useSignal("");
    const draftTimeout = useSignal(5e3);
    const draftBlocking = useSignal(false);
    const addExpanded = useSignal(false);
    const commit = (nextHooks) => {
      const cfg = snapshot.config;
      onSave(
        {
          activeProviderId: cfg.activeProviderId,
          activeModeId: cfg.activeModeId,
          providers: [...cfg.providers],
          modes: [...cfg.modes],
          ...cfg.mcpServers ? { mcpServers: [...cfg.mcpServers] } : {},
          hooks: [...nextHooks]
        },
        void 0
      );
    };
    const addHook = () => {
      const command = draftCommand.value.trim();
      if (command.length === 0) return;
      const matcher = draftMatcher.value.trim();
      const newHook = {
        event: draftEvent.value,
        command,
        ...matcher ? { matcher } : {},
        ...draftTimeout.value && draftTimeout.value !== 5e3 ? { timeout: draftTimeout.value } : {},
        ...draftBlocking.value ? { blocking: true } : {}
      };
      commit([...hooks, newHook]);
      draftCommand.value = "";
      draftMatcher.value = "";
      draftBlocking.value = false;
      draftTimeout.value = 5e3;
      addExpanded.value = false;
    };
    const removeHook = (idx) => {
      commit(hooks.filter((_3, i5) => i5 !== idx));
    };
    return /* @__PURE__ */ u3("div", { class: "oati-hooks-editor", children: [
      /* @__PURE__ */ u3("div", { class: "oati-help", style: { marginBottom: "12px" }, children: [
        "Hooks let external commands react to agent events. The matched shell command receives the event payload on stdin and may emit a JSON verdict on stdout to block or rewrite the event. Authored hooks land in ",
        /* @__PURE__ */ u3("code", { children: ".oati/hooks.json" }),
        "."
      ] }),
      hooks.length === 0 ? /* @__PURE__ */ u3("div", { class: "oati-hooks-empty", children: [
        "No hooks configured yet. Add one below \u2014 common starting points:",
        /* @__PURE__ */ u3("ul", { children: [
          /* @__PURE__ */ u3("li", { children: [
            /* @__PURE__ */ u3("code", { children: "PreToolUse" }),
            " + matcher ",
            /* @__PURE__ */ u3("code", { children: "write_file" }),
            " \u2192 run a linter on pending edits."
          ] }),
          /* @__PURE__ */ u3("li", { children: [
            /* @__PURE__ */ u3("code", { children: "UserPromptSubmit" }),
            " \u2192 block prompts that touch secrets."
          ] }),
          /* @__PURE__ */ u3("li", { children: [
            /* @__PURE__ */ u3("code", { children: "Stop" }),
            " \u2192 send a desktop notification when the agent finishes."
          ] })
        ] })
      ] }) : /* @__PURE__ */ u3("table", { class: "oati-hooks-table", children: [
        /* @__PURE__ */ u3("thead", { children: /* @__PURE__ */ u3("tr", { children: [
          /* @__PURE__ */ u3("th", { children: "Event" }),
          /* @__PURE__ */ u3("th", { children: "Matcher" }),
          /* @__PURE__ */ u3("th", { children: "Command" }),
          /* @__PURE__ */ u3("th", { children: "Flags" }),
          /* @__PURE__ */ u3("th", { "aria-label": "Actions" })
        ] }) }),
        /* @__PURE__ */ u3("tbody", { children: hooks.map((h5, i5) => /* @__PURE__ */ u3("tr", { children: [
          /* @__PURE__ */ u3("td", { children: /* @__PURE__ */ u3("span", { class: "oati-hooks-event", children: h5.event }) }),
          /* @__PURE__ */ u3("td", { class: "oati-hooks-matcher", children: h5.matcher ? /* @__PURE__ */ u3("code", { children: h5.matcher }) : /* @__PURE__ */ u3("span", { class: "oati-muted", children: "*" }) }),
          /* @__PURE__ */ u3("td", { class: "oati-hooks-command", children: /* @__PURE__ */ u3("code", { title: h5.command, children: h5.command }) }),
          /* @__PURE__ */ u3("td", { class: "oati-hooks-flags", children: [
            h5.blocking && /* @__PURE__ */ u3("span", { class: "oati-hooks-flag-blocking", children: "blocking" }),
            h5.timeout && /* @__PURE__ */ u3("span", { class: "oati-hooks-flag-timeout", children: [
              h5.timeout,
              "ms"
            ] })
          ] }),
          /* @__PURE__ */ u3("td", { children: /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-btn oati-btn-link",
              onClick: () => removeHook(i5),
              title: "Delete hook",
              "aria-label": "Delete hook",
              children: "Delete"
            }
          ) })
        ] }, `${h5.event}-${i5}-${h5.command}`)) })
      ] }),
      addExpanded.value ? /* @__PURE__ */ u3("div", { class: "oati-hooks-add-form", children: [
        /* @__PURE__ */ u3("div", { class: "oati-hooks-add-row", children: [
          /* @__PURE__ */ u3("label", { class: "oati-hooks-label", children: [
            "Event",
            /* @__PURE__ */ u3(
              "select",
              {
                value: draftEvent.value,
                onChange: (e4) => {
                  draftEvent.value = e4.target.value;
                },
                children: EVENTS.map((ev) => /* @__PURE__ */ u3("option", { value: ev, children: ev }, ev))
              }
            )
          ] }),
          /* @__PURE__ */ u3("label", { class: "oati-hooks-label", children: [
            "Matcher",
            /* @__PURE__ */ u3(
              "input",
              {
                type: "text",
                value: draftMatcher.value,
                placeholder: "e.g. write_file (optional)",
                onInput: (e4) => {
                  draftMatcher.value = e4.target.value;
                }
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ u3("label", { class: "oati-hooks-label oati-hooks-label-full", children: [
          "Command",
          /* @__PURE__ */ u3(
            "input",
            {
              type: "text",
              value: draftCommand.value,
              placeholder: "e.g. ./scripts/lint-pending.sh",
              onInput: (e4) => {
                draftCommand.value = e4.target.value;
              }
            }
          )
        ] }),
        /* @__PURE__ */ u3("div", { class: "oati-hooks-add-row", children: [
          /* @__PURE__ */ u3("label", { class: "oati-hooks-label", children: [
            "Timeout (ms)",
            /* @__PURE__ */ u3(
              "input",
              {
                type: "number",
                value: draftTimeout.value,
                min: 500,
                max: 6e4,
                step: 500,
                onInput: (e4) => {
                  draftTimeout.value = Number(e4.target.value) || 5e3;
                }
              }
            )
          ] }),
          /* @__PURE__ */ u3("label", { class: "oati-hooks-label oati-hooks-checkbox", children: [
            /* @__PURE__ */ u3(
              "input",
              {
                type: "checkbox",
                checked: draftBlocking.value,
                onChange: (e4) => {
                  draftBlocking.value = e4.target.checked;
                }
              }
            ),
            "Blocking (wait for verdict before proceeding)"
          ] })
        ] }),
        /* @__PURE__ */ u3("div", { class: "oati-hooks-add-actions", children: [
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-primary", onClick: addHook, children: "Add hook" }),
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-btn oati-btn-secondary",
              onClick: () => {
                addExpanded.value = false;
              },
              children: "Cancel"
            }
          )
        ] })
      ] }) : /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: "oati-btn oati-btn-secondary",
          onClick: () => {
            addExpanded.value = true;
          },
          children: "+ Add hook"
        }
      )
    ] });
  }

  // src/components/mcp-editor.tsx
  function McpServersEditor({ snapshot, onSave }) {
    const config = snapshot.config;
    const servers = useSignal([...config.mcpServers ?? []]);
    const commit = (next) => {
      servers.value = next;
      onSave(
        {
          activeProviderId: config.activeProviderId,
          activeModeId: config.activeModeId,
          providers: [...config.providers],
          modes: [...config.modes],
          mcpServers: next
        },
        void 0
      );
    };
    const handleAdd = () => {
      const id = `mcp_${Date.now().toString(36)}`;
      commit([
        ...servers.value,
        {
          id,
          displayName: "New MCP Server",
          command: "",
          args: [],
          enabled: false,
          approval: "prompt"
        }
      ]);
    };
    const handleAddPreset = (presetId) => {
      const preset = MCP_SERVER_PRESETS.find((p5) => p5.id === presetId);
      if (!preset) return;
      commit([...servers.value, materializePreset(preset)]);
    };
    const handleDelete = (id) => {
      commit(servers.value.filter((s5) => s5.id !== id));
    };
    const handleChange = (id, patch) => {
      commit(servers.value.map((s5) => s5.id === id ? { ...s5, ...patch } : s5));
    };
    return /* @__PURE__ */ u3(S, { children: [
      servers.value.length === 0 && /* @__PURE__ */ u3("div", { class: "oati-empty oati-mcp-empty", children: "No MCP servers configured. Add one to load external tools (e.g. a filesystem server, a database server, etc.)." }),
      servers.value.map((srv) => /* @__PURE__ */ u3(
        McpServerRow,
        {
          server: srv,
          onChange: (patch) => handleChange(srv.id, patch),
          onDelete: () => handleDelete(srv.id)
        },
        srv.id
      )),
      /* @__PURE__ */ u3("div", { class: "oati-mcp-add-row", children: [
        /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-secondary", onClick: handleAdd, children: "\uFF0B Add Custom" }),
        /* @__PURE__ */ u3(
          "select",
          {
            class: "oati-mcp-preset-select",
            value: "",
            onChange: (e4) => {
              const v5 = e4.target.value;
              if (v5) {
                handleAddPreset(v5);
                e4.target.value = "";
              }
            },
            children: [
              /* @__PURE__ */ u3("option", { value: "", children: "\uFF0B Add from preset..." }),
              MCP_SERVER_PRESETS.map((p5) => /* @__PURE__ */ u3("option", { value: p5.id, title: p5.description, children: [
                p5.displayName,
                p5.requiredEnvVars ? "  \u{1F511}" : ""
              ] }, p5.id))
            ]
          }
        )
      ] })
    ] });
  }
  function McpServerRow({ server, onChange, onDelete }) {
    const argsText = (server.args ?? []).join(" ");
    const envText = formatEnv(server.env);
    return /* @__PURE__ */ u3("div", { class: "oati-mcp-row", children: [
      /* @__PURE__ */ u3("div", { class: "oati-mcp-row-header", children: [
        /* @__PURE__ */ u3(
          "input",
          {
            type: "checkbox",
            checked: server.enabled,
            title: "Enable / disable this server",
            onChange: (e4) => onChange({ enabled: e4.target.checked })
          }
        ),
        /* @__PURE__ */ u3(
          "input",
          {
            type: "text",
            class: "oati-mcp-name",
            value: server.displayName,
            placeholder: "Display name",
            onInput: (e4) => onChange({ displayName: e4.target.value })
          }
        ),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-btn oati-btn-secondary oati-btn-icon",
            onClick: onDelete,
            title: "Delete",
            "aria-label": "Delete MCP server",
            children: "\u{1F5D1}"
          }
        )
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-field", children: [
        /* @__PURE__ */ u3("span", { class: "oati-label", children: "Command" }),
        /* @__PURE__ */ u3(
          "input",
          {
            type: "text",
            value: server.command,
            placeholder: "npx, python, /path/to/server, ...",
            onInput: (e4) => onChange({ command: e4.target.value })
          }
        )
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-field", children: [
        /* @__PURE__ */ u3("span", { class: "oati-label", children: "Arguments (space-separated)" }),
        /* @__PURE__ */ u3(
          "input",
          {
            type: "text",
            value: argsText,
            placeholder: "-y @modelcontextprotocol/server-filesystem /path",
            onInput: (e4) => onChange({ args: splitArgs(e4.target.value) })
          }
        )
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-field", children: [
        /* @__PURE__ */ u3("span", { class: "oati-label", children: "Environment (KEY=VALUE, one per line)" }),
        /* @__PURE__ */ u3(
          "textarea",
          {
            rows: 2,
            value: envText,
            placeholder: "API_TOKEN=xxx",
            onInput: (e4) => onChange({ env: parseEnv(e4.target.value) })
          }
        )
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-field", children: [
        /* @__PURE__ */ u3("span", { class: "oati-label", children: "Tool approval policy" }),
        /* @__PURE__ */ u3(
          "select",
          {
            value: server.approval ?? "prompt",
            onChange: (e4) => onChange({
              approval: e4.target.value
            }),
            children: [
              /* @__PURE__ */ u3("option", { value: "prompt", children: "Prompt (recommended)" }),
              /* @__PURE__ */ u3("option", { value: "auto", children: "Auto-approve" }),
              /* @__PURE__ */ u3("option", { value: "deny", children: "Deny" })
            ]
          }
        )
      ] })
    ] });
  }
  function splitArgs(s5) {
    const trimmed = s5.trim();
    if (!trimmed) return [];
    return trimmed.split(/\s+/);
  }
  function formatEnv(env) {
    if (!env) return "";
    return Object.entries(env).map(([k3, v5]) => `${k3}=${v5}`).join("\n");
  }
  function parseEnv(s5) {
    const out = {};
    for (const line of s5.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eq = trimmed.indexOf("=");
      if (eq < 0) continue;
      const key = trimmed.slice(0, eq).trim();
      const value = trimmed.slice(eq + 1).trim();
      if (key) out[key] = value;
    }
    return Object.keys(out).length > 0 ? out : void 0;
  }

  // src/components/settings-panel.tsx
  function AgentBehaviorEditor({ snapshot, onSave }) {
    const config = snapshot.config;
    const activeMode2 = config.modes.find((m4) => m4.id === config.activeModeId) ?? config.modes[0];
    if (!activeMode2) return null;
    const update = (patch) => {
      const newMode = { ...activeMode2, ...patch };
      const newModes = config.modes.map((m4) => m4.id === activeMode2.id ? newMode : m4);
      onSave(
        {
          activeProviderId: config.activeProviderId,
          activeModeId: config.activeModeId,
          providers: [...config.providers],
          modes: newModes
        },
        void 0
      );
    };
    return /* @__PURE__ */ u3(S, { children: [
      /* @__PURE__ */ u3("label", { class: "oati-field oati-field-row", children: [
        /* @__PURE__ */ u3(
          "input",
          {
            type: "checkbox",
            checked: activeMode2.enablePlanner,
            onChange: (e4) => update({ enablePlanner: e4.target.checked })
          }
        ),
        /* @__PURE__ */ u3("span", { children: [
          /* @__PURE__ */ u3("strong", { children: "Planner stage" }),
          " \u2014 agent writes an explicit plan before acting."
        ] })
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-field oati-field-row", children: [
        /* @__PURE__ */ u3(
          "input",
          {
            type: "checkbox",
            checked: activeMode2.enableCritic,
            onChange: (e4) => update({ enableCritic: e4.target.checked })
          }
        ),
        /* @__PURE__ */ u3("span", { children: [
          /* @__PURE__ */ u3("strong", { children: "Critic stage" }),
          " \u2014 agent self-reviews work at the end."
        ] })
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-field", children: [
        /* @__PURE__ */ u3("span", { class: "oati-label", children: [
          "Max parallel sub-agents (current: ",
          activeMode2.maxParallelAgents,
          ")"
        ] }),
        /* @__PURE__ */ u3(
          "input",
          {
            type: "number",
            min: "1",
            max: "16",
            value: String(activeMode2.maxParallelAgents),
            onChange: (e4) => {
              const v5 = Number(e4.target.value);
              if (Number.isFinite(v5) && v5 >= 1) update({ maxParallelAgents: v5 });
            }
          }
        ),
        /* @__PURE__ */ u3("span", { class: "oati-help", children: [
          "Used by the ",
          /* @__PURE__ */ u3("code", { children: "spawn_agent" }),
          " tool. 1 disables sub-agents; 4 is a good default."
        ] })
      ] }),
      /* @__PURE__ */ u3("label", { class: "oati-field", children: [
        /* @__PURE__ */ u3("span", { class: "oati-label", children: "Max iterations per agent run" }),
        /* @__PURE__ */ u3(
          "input",
          {
            type: "number",
            min: "1",
            max: "200",
            value: String(activeMode2.maxIterations),
            onChange: (e4) => {
              const v5 = Number(e4.target.value);
              if (Number.isFinite(v5) && v5 >= 1) update({ maxIterations: v5 });
            }
          }
        )
      ] })
    ] });
  }
  function SettingsPanel({
    snapshot,
    testResult,
    onSave,
    onDone,
    onTestConnection,
    bus
  }) {
    const config = snapshot.config;
    const providers = useSignal([...config.providers]);
    const activeProviderId = useSignal(config.activeProviderId);
    const selectedProviderId = useSignal(config.activeProviderId);
    const preset = useSignal("openai-compatible");
    const displayName = useSignal("");
    const baseUrl = useSignal("");
    const model = useSignal("");
    const apiKey = useSignal("");
    const apiKeyTouched = useSignal(false);
    y2(() => {
      providers.value = [...config.providers];
      activeProviderId.value = config.activeProviderId;
      const stillExists = config.providers.some((p5) => p5.id === selectedProviderId.value);
      if (!stillExists) selectedProviderId.value = config.activeProviderId;
      loadDraftFrom(selectedProviderId.value, config.providers);
    }, [snapshot]);
    const selected = useComputed(
      () => providers.value.find((p5) => p5.id === selectedProviderId.value) ?? providers.value[0]
    );
    function loadDraftFrom(id, list2) {
      const p5 = list2.find((x3) => x3.id === id) ?? list2[0];
      if (!p5) return;
      preset.value = p5.preset;
      displayName.value = p5.displayName;
      baseUrl.value = p5.baseUrl;
      model.value = p5.defaultModel;
      apiKey.value = "";
      apiKeyTouched.value = false;
    }
    function commitDraftToProviders() {
      const sel = selected.value;
      if (!sel) return providers.value;
      const meta = getPreset(preset.value);
      const updated = {
        ...sel,
        type: meta.providerType,
        preset: preset.value,
        displayName: displayName.value || meta.displayName,
        baseUrl: baseUrl.value.trim(),
        defaultModel: model.value.trim(),
        extraHeaders: meta.extraHeaders
      };
      return providers.value.map((p5) => p5.id === sel.id ? updated : p5);
    }
    const handleSelectProvider = (id) => {
      providers.value = commitDraftToProviders();
      selectedProviderId.value = id;
      loadDraftFrom(id, providers.value);
    };
    const handlePresetChange = (id) => {
      preset.value = id;
      const meta = getPreset(id);
      if (meta.baseUrl) baseUrl.value = meta.baseUrl;
      if (meta.defaultModel && !model.value.trim()) model.value = meta.defaultModel;
      if (!displayName.value || displayName.value === getPreset(selected.value?.preset ?? "custom").displayName) {
        displayName.value = meta.displayName;
      }
    };
    const handleAddProvider = () => {
      providers.value = commitDraftToProviders();
      const newId = `provider_${Date.now().toString(36)}`;
      const meta = getPreset("openai-compatible");
      const newProvider = {
        id: newId,
        type: "openai-compatible",
        displayName: `${meta.displayName} (new)`,
        preset: "openai-compatible",
        baseUrl: "",
        defaultModel: ""
      };
      providers.value = [...providers.value, newProvider];
      selectedProviderId.value = newId;
      loadDraftFrom(newId, providers.value);
    };
    const handleDeleteProvider = () => {
      const sel = selected.value;
      if (!sel || providers.value.length <= 1) return;
      const remaining = providers.value.filter((p5) => p5.id !== sel.id);
      providers.value = remaining;
      if (activeProviderId.value === sel.id) {
        activeProviderId.value = remaining[0]?.id ?? "";
      }
      const nextSelected = remaining[0]?.id ?? "";
      selectedProviderId.value = nextSelected;
      if (nextSelected) loadDraftFrom(nextSelected, remaining);
    };
    const handleMakeActive = () => {
      const sel = selected.value;
      if (!sel) return;
      activeProviderId.value = sel.id;
    };
    const handleDone = () => {
      const finalList = commitDraftToProviders();
      const apiKeyChange = apiKeyTouched.value && selected.value ? { providerId: selected.value.id, value: apiKey.value } : void 0;
      onSave(
        {
          activeProviderId: activeProviderId.value,
          activeModeId: config.activeModeId,
          providers: finalList
        },
        apiKeyChange
      );
      onDone();
    };
    const handleTestConnectionClick = () => {
      const sel = selected.value;
      if (!sel) return;
      const finalList = commitDraftToProviders();
      const apiKeyChange = apiKeyTouched.value ? { providerId: sel.id, value: apiKey.value } : void 0;
      onSave(
        {
          activeProviderId: activeProviderId.value,
          activeModeId: config.activeModeId,
          providers: finalList
        },
        apiKeyChange
      );
      providers.value = finalList;
      if (apiKeyChange) apiKeyTouched.value = false;
      onTestConnection(sel.id);
    };
    if (!selected.value) {
      return /* @__PURE__ */ u3("div", { class: "oati-settings", children: [
        /* @__PURE__ */ u3("div", { class: "oati-settings-header", children: [
          /* @__PURE__ */ u3("h2", { children: "Settings" }),
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn", onClick: handleAddProvider, children: "Add Provider" })
        ] }),
        /* @__PURE__ */ u3("div", { class: "oati-empty", children: 'No providers configured. Click "Add Provider" to begin.' })
      ] });
    }
    const presetMeta = useComputed(() => getPreset(preset.value));
    const hasKey = snapshot.hasApiKey[selected.value.id] ?? false;
    const baseUrlLocked = !presetMeta.value.baseUrlEditable && preset.value !== "openai-compatible";
    const isActive = activeProviderId.value === selected.value.id;
    const canDelete = providers.value.length > 1;
    return /* @__PURE__ */ u3("div", { class: "oati-settings", children: [
      /* @__PURE__ */ u3("div", { class: "oati-settings-header", children: [
        /* @__PURE__ */ u3("h2", { children: "Settings" }),
        /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn", onClick: handleDone, children: "Done" })
      ] }),
      /* @__PURE__ */ u3("section", { class: "oati-settings-section", children: [
        /* @__PURE__ */ u3("h3", { children: "Providers" }),
        /* @__PURE__ */ u3("div", { class: "oati-provider-toolbar", children: [
          /* @__PURE__ */ u3(
            "select",
            {
              value: selectedProviderId.value,
              onChange: (e4) => handleSelectProvider(e4.target.value),
              children: providers.value.map((p5) => /* @__PURE__ */ u3("option", { value: p5.id, children: [
                p5.displayName,
                p5.id === activeProviderId.value ? "  \u2605" : ""
              ] }, p5.id))
            }
          ),
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-btn oati-btn-secondary",
              onClick: handleAddProvider,
              title: "Add new provider",
              "aria-label": "Add new provider",
              children: "\uFF0B"
            }
          ),
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-btn oati-btn-secondary",
              onClick: handleDeleteProvider,
              disabled: !canDelete,
              title: canDelete ? "Delete this provider" : "Cannot delete the last provider",
              "aria-label": "Delete provider",
              children: "\u{1F5D1}"
            }
          ),
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-btn oati-btn-secondary",
              onClick: handleMakeActive,
              disabled: isActive,
              title: isActive ? "Already active" : "Set as active provider",
              children: isActive ? "Active \u2605" : "Make Active"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ u3("section", { class: "oati-settings-section", children: [
        /* @__PURE__ */ u3("h3", { children: "Agent Behavior" }),
        /* @__PURE__ */ u3(AgentBehaviorEditor, { snapshot, onSave })
      ] }),
      /* @__PURE__ */ u3("section", { class: "oati-settings-section", children: [
        /* @__PURE__ */ u3("h3", { children: "API Configuration" }),
        /* @__PURE__ */ u3("label", { class: "oati-field", children: [
          /* @__PURE__ */ u3("span", { class: "oati-label", children: "Display Name" }),
          /* @__PURE__ */ u3(
            "input",
            {
              type: "text",
              value: displayName.value,
              onInput: (e4) => {
                displayName.value = e4.target.value;
              },
              placeholder: "Friendly name shown in the dropdown"
            }
          )
        ] }),
        /* @__PURE__ */ u3("label", { class: "oati-field", children: [
          /* @__PURE__ */ u3("span", { class: "oati-label", children: "API Provider" }),
          /* @__PURE__ */ u3(
            "select",
            {
              value: preset.value,
              onChange: (e4) => handlePresetChange(e4.target.value),
              children: PROVIDER_PRESETS.map((p5) => /* @__PURE__ */ u3("option", { value: p5.id, children: p5.displayName }, p5.id))
            }
          )
        ] }),
        /* @__PURE__ */ u3("label", { class: "oati-field", children: [
          /* @__PURE__ */ u3("span", { class: "oati-label", children: "Base URL" }),
          /* @__PURE__ */ u3(
            "input",
            {
              type: "text",
              value: baseUrl.value,
              onInput: (e4) => {
                baseUrl.value = e4.target.value;
              },
              disabled: baseUrlLocked,
              placeholder: "https://..."
            }
          )
        ] }),
        /* @__PURE__ */ u3("label", { class: "oati-field", children: [
          /* @__PURE__ */ u3("span", { class: "oati-label", children: [
            presetMeta.value.displayName,
            " API Key"
          ] }),
          /* @__PURE__ */ u3(
            "input",
            {
              type: "password",
              value: apiKey.value,
              placeholder: hasKey ? "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022 (stored)" : "Enter API Key...",
              onInput: (e4) => {
                apiKey.value = e4.target.value;
                apiKeyTouched.value = true;
              }
            }
          ),
          /* @__PURE__ */ u3("span", { class: "oati-help", children: presetMeta.value.apiKeyHelp ?? "Stored in VS Code's SecretStorage. Only used to make API requests from this extension." })
        ] }),
        /* @__PURE__ */ u3("label", { class: "oati-field", children: [
          /* @__PURE__ */ u3("span", { class: "oati-label", children: "Model ID" }),
          (() => {
            const curated = presetMeta.value.curatedModels;
            if (!curated || curated.length === 0) {
              return /* @__PURE__ */ u3(
                "input",
                {
                  type: "text",
                  value: model.value,
                  placeholder: presetMeta.value.modelPlaceholder,
                  onInput: (e4) => {
                    model.value = e4.target.value;
                  }
                }
              );
            }
            const matched = curated.find((m4) => m4.id === model.value);
            const usingCustom = !matched && model.value.length > 0;
            return /* @__PURE__ */ u3(S, { children: [
              /* @__PURE__ */ u3(
                "select",
                {
                  value: matched ? matched.id : usingCustom ? "__custom__" : "",
                  onChange: (e4) => {
                    const v5 = e4.target.value;
                    if (v5 === "__custom__") {
                      model.value = "";
                      return;
                    }
                    model.value = v5;
                  },
                  children: [
                    /* @__PURE__ */ u3("option", { value: "", disabled: true, children: "Select a model\u2026" }),
                    curated.map((m4) => /* @__PURE__ */ u3("option", { value: m4.id, children: [
                      m4.label,
                      m4.free ? "  \u{1F4B8} free" : "",
                      m4.note ? `  \u2014 ${m4.note}` : ""
                    ] }, m4.id)),
                    /* @__PURE__ */ u3("option", { value: "__custom__", children: "Custom\u2026 (type any model id)" })
                  ]
                }
              ),
              (usingCustom || !matched) && /* @__PURE__ */ u3(
                "input",
                {
                  type: "text",
                  value: model.value,
                  placeholder: presetMeta.value.modelPlaceholder,
                  onInput: (e4) => {
                    model.value = e4.target.value;
                  },
                  style: { marginTop: "6px" }
                }
              )
            ] });
          })()
        ] }),
        /* @__PURE__ */ u3("div", { class: "oati-settings-actions", children: [
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-secondary", onClick: handleTestConnectionClick, children: "Test Connection" }),
          testResult && testResult.providerId === selected.value.id && /* @__PURE__ */ u3("span", { class: `oati-test-result ${testResult.ok ? "oati-test-ok" : "oati-test-fail"}`, children: [
            testResult.ok ? "\u2713" : "\u2717",
            " ",
            testResult.message ?? ""
          ] })
        ] })
      ] }),
      /* @__PURE__ */ u3("section", { class: "oati-settings-section", children: [
        /* @__PURE__ */ u3("h3", { children: "MCP Servers" }),
        /* @__PURE__ */ u3("div", { class: "oati-help", style: { marginBottom: "12px" }, children: "Configure Model Context Protocol servers to load external tools. Each server runs as a subprocess and exposes tools via stdio JSON-RPC." }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-btn oati-btn-secondary",
            onClick: () => window.dispatchEvent(new CustomEvent("oati:open-marketplace")),
            style: { marginBottom: "8px" },
            children: "Browse MCP marketplace\u2026"
          }
        ),
        /* @__PURE__ */ u3(McpServersEditor, { snapshot, onSave })
      ] }),
      /* @__PURE__ */ u3("section", { class: "oati-settings-section", children: [
        /* @__PURE__ */ u3("h3", { children: "Hooks" }),
        /* @__PURE__ */ u3(HooksEditor, { snapshot, onSave })
      ] }),
      bus && /* @__PURE__ */ u3("section", { class: "oati-settings-section", children: [
        /* @__PURE__ */ u3("h3", { children: "Experimental" }),
        /* @__PURE__ */ u3(ExperimentalSection, { bus })
      ] })
    ] });
  }

  // src/components/supervisor-panel.tsx
  function SupervisorPanel({ items, onDismiss, onClear, onOpenPath, onRunNow }) {
    if (items.length === 0) return null;
    return /* @__PURE__ */ u3("div", { class: "oati-supervisor-panel", children: [
      /* @__PURE__ */ u3("div", { class: "oati-supervisor-header", children: [
        /* @__PURE__ */ u3("span", { class: "oati-supervisor-icon", "aria-hidden": "true", children: "\u2726" }),
        /* @__PURE__ */ u3("span", { class: "oati-supervisor-title", children: [
          "Supervisor \xB7 ",
          items.length
        ] }),
        /* @__PURE__ */ u3("span", { class: "oati-supervisor-spacer" }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-supervisor-action",
            onClick: onRunNow,
            title: "Re-scan recent edits now",
            children: "Re-scan"
          }
        ),
        /* @__PURE__ */ u3("button", { type: "button", class: "oati-supervisor-action", onClick: onClear, title: "Dismiss all", children: "Clear" })
      ] }),
      /* @__PURE__ */ u3("ul", { class: "oati-supervisor-list", children: items.map((s5) => /* @__PURE__ */ u3("li", { class: `oati-supervisor-item oati-supervisor-item-${s5.severity}`, children: [
        /* @__PURE__ */ u3("span", { class: "oati-supervisor-dot", "aria-hidden": "true" }),
        /* @__PURE__ */ u3("div", { class: "oati-supervisor-body", children: [
          /* @__PURE__ */ u3("span", { class: "oati-supervisor-message", children: s5.message }),
          s5.path && /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-supervisor-jump",
              onClick: () => onOpenPath?.(s5.path ?? "", s5.line),
              title: s5.line ? `${s5.path}:${s5.line}` : s5.path,
              children: [
                s5.path,
                s5.line ? `:${s5.line}` : ""
              ]
            }
          )
        ] }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-supervisor-dismiss",
            onClick: () => onDismiss(s5.id),
            title: "Dismiss",
            "aria-label": "Dismiss suggestion",
            children: "\xD7"
          }
        )
      ] }, s5.id)) })
    ] });
  }

  // src/components/todo-list.tsx
  function TodoListPanel({ items }) {
    const collapsed = useSignal(false);
    if (items.length === 0) return null;
    const total = items.length;
    const done = items.filter((t4) => t4.status === "completed").length;
    const inProgress = items.filter((t4) => t4.status === "in_progress").length;
    const pending = total - done - inProgress;
    return /* @__PURE__ */ u3("div", { class: "oati-todo-panel", children: [
      /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: "oati-todo-header",
          onClick: () => {
            collapsed.value = !collapsed.value;
          },
          title: collapsed.value ? "Expand task list" : "Collapse task list",
          children: [
            /* @__PURE__ */ u3("span", { class: "oati-todo-header-icon", "aria-hidden": "true", children: collapsed.value ? "\u25B8" : "\u25BE" }),
            /* @__PURE__ */ u3("span", { class: "oati-todo-header-label", children: "Tasks" }),
            /* @__PURE__ */ u3("span", { class: "oati-todo-header-counts", children: [
              done,
              "/",
              total,
              inProgress > 0 ? ` \xB7 ${inProgress} active` : "",
              pending > 0 ? ` \xB7 ${pending} pending` : ""
            ] }),
            /* @__PURE__ */ u3("span", { class: "oati-todo-header-progress", "aria-hidden": "true", children: /* @__PURE__ */ u3(
              "span",
              {
                class: "oati-todo-header-progress-fill",
                style: `width: ${total === 0 ? 0 : Math.round(done / total * 100)}%`
              }
            ) })
          ]
        }
      ),
      !collapsed.value && /* @__PURE__ */ u3("ul", { class: "oati-todo-list", children: items.map((item, idx) => /* @__PURE__ */ u3("li", { class: `oati-todo-item oati-todo-item-${item.status}`, children: [
        /* @__PURE__ */ u3("span", { class: "oati-todo-marker", "aria-hidden": "true", children: item.status === "completed" ? "\u2713" : item.status === "in_progress" ? "\u25CF" : "\u25CB" }),
        /* @__PURE__ */ u3("span", { class: "oati-todo-text", children: item.status === "in_progress" && item.activeForm ? item.activeForm : item.content })
      ] }, `${idx}-${item.content}`)) })
    ] });
  }

  // src/components/welcome.tsx
  function Welcome({ snapshot, onOpenSettings, onSave }) {
    const ollamaModels = useSignal(null);
    const ollamaChecked = useSignal(false);
    y2(() => {
      void detectOllama().then((models) => {
        ollamaModels.value = models;
        ollamaChecked.value = true;
      });
    }, []);
    const handleQuickStartOllama = () => {
      if (!snapshot || !ollamaModels.value || ollamaModels.value.length === 0) return;
      const meta = getPreset("ollama");
      const firstModel = ollamaModels.value[0].name;
      const newProvider = {
        id: "ollama-local",
        type: "openai-compatible",
        displayName: "Ollama (local)",
        preset: "ollama",
        baseUrl: meta.baseUrl,
        defaultModel: firstModel
      };
      const existing = snapshot.config.providers.find((p5) => p5.id === "ollama-local");
      const providers = existing ? snapshot.config.providers.map((p5) => p5.id === "ollama-local" ? newProvider : p5) : [...snapshot.config.providers, newProvider];
      onSave(
        {
          activeProviderId: "ollama-local",
          activeModeId: snapshot.config.activeModeId,
          providers,
          modes: [...snapshot.config.modes]
        },
        void 0
      );
    };
    return /* @__PURE__ */ u3("div", { class: "oati-welcome", children: [
      /* @__PURE__ */ u3("div", { class: "oati-welcome-hero", children: [
        /* @__PURE__ */ u3("h2", { children: "Welcome to OATI Code" }),
        /* @__PURE__ */ u3("p", { children: "A configurable agentic coding assistant. Multi-provider, MCP-native, built to be your daily driver." })
      ] }),
      /* @__PURE__ */ u3("div", { class: "oati-welcome-card", children: [
        /* @__PURE__ */ u3("h3", { children: "Get started" }),
        /* @__PURE__ */ u3("p", { children: "Configure a provider to begin. You have a few options:" }),
        /* @__PURE__ */ u3("ul", { children: [
          /* @__PURE__ */ u3("li", { children: [
            /* @__PURE__ */ u3("strong", { children: "Bring your own key" }),
            " \u2014 OpenAI, Anthropic, OpenRouter, or any OpenAI-compatible gateway."
          ] }),
          /* @__PURE__ */ u3("li", { children: [
            /* @__PURE__ */ u3("strong", { children: "Local LLM" }),
            " \u2014 Ollama, LM Studio, or LiteLLM running on your machine."
          ] }),
          /* @__PURE__ */ u3("li", { children: [
            /* @__PURE__ */ u3("strong", { children: "Custom" }),
            " \u2014 anything that speaks the OpenAI Chat Completions API."
          ] })
        ] }),
        /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn", onClick: onOpenSettings, children: "Open Settings \u2192" })
      ] }),
      ollamaChecked.value && ollamaModels.value && ollamaModels.value.length > 0 && /* @__PURE__ */ u3("div", { class: "oati-welcome-card oati-welcome-detected", children: [
        /* @__PURE__ */ u3("div", { class: "oati-welcome-detected-row", children: [
          /* @__PURE__ */ u3("span", { class: "oati-welcome-detected-tag", children: "DETECTED" }),
          /* @__PURE__ */ u3("strong", { children: "Ollama running on localhost:11434" })
        ] }),
        /* @__PURE__ */ u3("p", { children: [
          "We can wire it up in one click using the first available model:",
          " ",
          /* @__PURE__ */ u3("code", { children: ollamaModels.value[0].name }),
          ollamaModels.value.length > 1 ? ` (and ${ollamaModels.value.length - 1} other${ollamaModels.value.length > 2 ? "s" : ""} you can switch to in Settings)` : "",
          "."
        ] }),
        /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-quickstart", onClick: handleQuickStartOllama, children: "\u26A1 Quick start with Ollama" })
      ] }),
      /* @__PURE__ */ u3("div", { class: "oati-welcome-tip", children: [
        /* @__PURE__ */ u3("strong", { children: "Tip:" }),
        " open the Command Palette and search for ",
        /* @__PURE__ */ u3("code", { children: "OATI" }),
        " to see all available commands."
      ] })
    ] });
  }
  async function detectOllama() {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 1e3);
      const res = await fetch("http://localhost:11434/api/tags", {
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) return null;
      const data = await res.json();
      const models = (data.models ?? []).filter((m4) => typeof m4.name === "string").map((m4) => ({ name: m4.name }));
      return models;
    } catch {
      return null;
    }
  }

  // ../rpc/src/index.ts
  var Bus = class {
    constructor(transport) {
      this.transport = transport;
      __publicField(this, "listeners", /* @__PURE__ */ new Set());
      __publicField(this, "disposeTransport");
      this.disposeTransport = this.transport.onMessage((env) => {
        if (env.v !== 1) return;
        for (const fn of this.listeners) fn(env.body);
      });
    }
    send(body) {
      this.transport.postMessage({ v: 1, body });
    }
    on(listener) {
      this.listeners.add(listener);
      return () => this.listeners.delete(listener);
    }
    dispose() {
      this.listeners.clear();
      this.disposeTransport();
    }
  };

  // src/transport.ts
  var vscode = window.acquireVsCodeApi?.();
  var webview2 = !vscode ? window.chrome?.webview : void 0;
  function createWebviewBus() {
    return new Bus({
      postMessage(msg) {
        if (vscode) {
          vscode.postMessage(msg);
          return;
        }
        if (webview2) {
          webview2.postMessage(msg);
        }
      },
      onMessage(handler) {
        if (webview2) {
          const wv2Listener = (ev) => {
            const data = ev.data;
            if (data && typeof data === "object" && data.v === 1) handler(data);
          };
          webview2.addEventListener("message", wv2Listener);
          return () => webview2.removeEventListener("message", wv2Listener);
        }
        const listener = (ev) => {
          const data = ev.data;
          if (data && typeof data === "object" && data.v === 1) handler(data);
        };
        window.addEventListener("message", listener);
        return () => window.removeEventListener("message", listener);
      }
    });
  }

  // src/vendor/load-mermaid.ts
  var mermaidPromise;
  function loadMermaid() {
    if (mermaidPromise) return mermaidPromise;
    mermaidPromise = new Promise((resolve, reject) => {
      const existing = window.OATIMermaid?.mermaid;
      if (existing) {
        initOnce(existing);
        resolve(existing);
        return;
      }
      const src = window.__OATI_VENDOR_MERMAID__;
      if (!src) {
        reject(new Error("vendor-mermaid URL not provided by host"));
        return;
      }
      const dedup = document.querySelector(`script[data-oati-vendor="mermaid"]`);
      const script = dedup ?? document.createElement("script");
      if (!dedup) {
        script.src = src;
        script.async = true;
        script.dataset.oatiVendor = "mermaid";
        document.head.appendChild(script);
      }
      const onLoad = () => {
        const api = window.OATIMermaid?.mermaid;
        if (!api) {
          reject(new Error("vendor-mermaid loaded but did not expose OATIMermaid.mermaid"));
          return;
        }
        initOnce(api);
        resolve(api);
      };
      const onError = () => reject(new Error(`failed to load ${src}`));
      if (dedup && window.OATIMermaid?.mermaid) {
        onLoad();
        return;
      }
      script.addEventListener("load", onLoad, { once: true });
      script.addEventListener("error", onError, { once: true });
    });
    return mermaidPromise;
  }
  var initialized = false;
  function initOnce(api) {
    if (initialized) return;
    initialized = true;
    api.initialize({
      startOnLoad: false,
      securityLevel: "strict",
      theme: "default",
      fontFamily: "var(--vscode-editor-font-family, monospace)"
    });
  }

  // src/components/diagram-renderer.tsx
  function DiagramRenderer({ id, mermaid, title }) {
    const containerRef = A2(null);
    const [svg, setSvg] = d2(void 0);
    const [error, setError] = d2(void 0);
    y2(() => {
      let cancelled = false;
      (async () => {
        try {
          const api = await loadMermaid();
          const safeId = `oati-diagram-${id.replace(/[^A-Za-z0-9_-]/g, "_")}`;
          const result = await api.render(safeId, mermaid);
          if (!cancelled) {
            setSvg(result.svg);
            setError(void 0);
          }
        } catch (err) {
          if (!cancelled) {
            setError(err instanceof Error ? err.message : String(err));
          }
        }
      })();
      return () => {
        cancelled = true;
      };
    }, [id, mermaid]);
    return /* @__PURE__ */ u3("figure", { class: "oati-diagram", "aria-label": title ?? "Diagram", children: [
      title ? /* @__PURE__ */ u3("figcaption", { class: "oati-diagram-title", children: title }) : null,
      error ? /* @__PURE__ */ u3("div", { class: "oati-diagram-error", children: [
        /* @__PURE__ */ u3("div", { class: "oati-diagram-error-msg", children: [
          "Diagram render failed: ",
          error
        ] }),
        /* @__PURE__ */ u3("pre", { class: "oati-diagram-source", children: mermaid })
      ] }) : svg ? /* @__PURE__ */ u3(
        "div",
        {
          ref: containerRef,
          class: "oati-diagram-svg",
          dangerouslySetInnerHTML: { __html: svg }
        }
      ) : /* @__PURE__ */ u3("div", { class: "oati-diagram-loading", children: "Rendering diagram\u2026" })
    ] });
  }

  // src/components/marketplace-view.tsx
  var CATEGORY_ORDER = [
    "filesystem",
    "git",
    "database",
    "search",
    "ai",
    "misc"
  ];
  var CATEGORY_LABEL = {
    filesystem: "Filesystem",
    git: "Git & Code Hosts",
    database: "Databases",
    search: "Search & Web",
    ai: "AI & Memory",
    misc: "Miscellaneous"
  };
  function MarketplaceView({ items, onInstall, onUninstall, onToggle, onClose }) {
    const [pending, setPending] = d2(null);
    const grouped = T2(() => {
      const buckets = /* @__PURE__ */ new Map();
      for (const it of items) {
        const list2 = buckets.get(it.category) ?? [];
        list2.push(it);
        buckets.set(it.category, list2);
      }
      return CATEGORY_ORDER.map((cat) => ({
        category: cat,
        items: buckets.get(cat) ?? []
      })).filter((g3) => g3.items.length > 0);
    }, [items]);
    const requestEnable = (item) => {
      setPending({
        id: item.id,
        displayName: item.displayName,
        kind: item.installed ? "enable" : "install-and-enable"
      });
    };
    const confirmPending = () => {
      if (!pending) return;
      if (pending.kind === "install-and-enable") {
        onInstall(pending.id);
        onToggle(pending.id, true);
      } else {
        onToggle(pending.id, true);
      }
      setPending(null);
    };
    const cancelPending = () => setPending(null);
    return /* @__PURE__ */ u3("div", { class: "marketplace-overlay", "aria-label": "MCP Marketplace", children: /* @__PURE__ */ u3("div", { class: "marketplace-panel", children: [
      /* @__PURE__ */ u3("header", { class: "marketplace-header", children: [
        /* @__PURE__ */ u3("div", { class: "marketplace-header-title", children: "MCP Server Marketplace" }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "marketplace-close",
            onClick: onClose,
            "aria-label": "Close marketplace",
            title: "Close",
            children: "\xD7"
          }
        )
      ] }),
      /* @__PURE__ */ u3("div", { class: "marketplace-help", children: "Browse curated Model Context Protocol servers and add them to your config. Each server runs as a local subprocess on your machine \u2014 review the description before enabling." }),
      pending && /* @__PURE__ */ u3("div", { class: "marketplace-approval", role: "alertdialog", children: [
        /* @__PURE__ */ u3("div", { class: "marketplace-approval-title", children: [
          "\u26A0 Enable ",
          /* @__PURE__ */ u3("strong", { children: pending.displayName }),
          "?"
        ] }),
        /* @__PURE__ */ u3("div", { class: "marketplace-approval-body", children: "This is a third-party MCP server. Enabling it will spawn the configured command as a subprocess on your machine with access to whatever the server exposes. Only enable servers you trust." }),
        /* @__PURE__ */ u3("div", { class: "marketplace-approval-actions", children: [
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn", onClick: cancelPending, children: "Cancel" }),
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-primary", onClick: confirmPending, children: pending.kind === "install-and-enable" ? "Install & Enable" : "Enable" })
        ] })
      ] }),
      /* @__PURE__ */ u3("div", { class: "marketplace-list", children: [
        items.length === 0 && /* @__PURE__ */ u3("div", { class: "oati-empty", children: "No marketplace entries available." }),
        grouped.map((group) => /* @__PURE__ */ u3("section", { class: "marketplace-group", children: [
          /* @__PURE__ */ u3("h3", { class: "marketplace-group-title", children: CATEGORY_LABEL[group.category] }),
          /* @__PURE__ */ u3("div", { class: "marketplace-group-items", children: group.items.map((item) => /* @__PURE__ */ u3(
            MarketplaceRow,
            {
              item,
              onInstall: () => onInstall(item.id),
              onUninstall: () => onUninstall(item.id),
              onRequestEnable: () => requestEnable(item),
              onDisable: () => onToggle(item.id, false)
            },
            item.id
          )) })
        ] }, group.category))
      ] })
    ] }) });
  }
  function MarketplaceRow({ item, onInstall, onUninstall, onRequestEnable, onDisable }) {
    const status = !item.installed ? "not-installed" : item.enabled ? "enabled" : "installed";
    return /* @__PURE__ */ u3("article", { class: `marketplace-row marketplace-row-${status}`, children: [
      /* @__PURE__ */ u3("div", { class: "marketplace-row-main", children: [
        /* @__PURE__ */ u3("div", { class: "marketplace-row-head", children: [
          /* @__PURE__ */ u3("span", { class: "marketplace-row-name", children: item.displayName }),
          item.homepage && /* @__PURE__ */ u3(
            "a",
            {
              class: "marketplace-row-link",
              href: item.homepage,
              target: "_blank",
              rel: "noreferrer",
              title: "Open homepage",
              children: "\u2197"
            }
          ),
          /* @__PURE__ */ u3("span", { class: `marketplace-row-badge marketplace-row-badge-${status}`, children: status === "enabled" ? "\u25CF Running" : status === "installed" ? "\u25CB Installed" : "Not installed" })
        ] }),
        /* @__PURE__ */ u3("div", { class: "marketplace-row-desc", children: item.description })
      ] }),
      /* @__PURE__ */ u3("div", { class: "marketplace-row-actions", children: [
        !item.installed && /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-primary", onClick: onInstall, children: "Install" }),
        item.installed && !item.enabled && /* @__PURE__ */ u3(S, { children: [
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn oati-btn-primary", onClick: onRequestEnable, children: "Enable" }),
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn", onClick: onUninstall, children: "Uninstall" })
        ] }),
        item.installed && item.enabled && /* @__PURE__ */ u3(S, { children: [
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn", onClick: onDisable, children: "Disable" }),
          /* @__PURE__ */ u3("button", { type: "button", class: "oati-btn", onClick: onUninstall, children: "Uninstall" })
        ] })
      ] })
    ] });
  }

  // src/components/multi-file-diff.tsx
  function MultiFileDiff(props) {
    const [selectedPath, setSelectedPath] = d2(props.files[0]?.path);
    const [accepted, setAccepted] = d2({});
    y2(() => {
      if (!selectedPath && props.files.length > 0) {
        setSelectedPath(props.files[0].path);
      }
    }, [props.files, selectedPath]);
    const tree = T2(() => buildTree(props.files.map((f5) => f5.path)), [props.files]);
    const selected = props.files.find((f5) => f5.path === selectedPath);
    const handleAcceptHunk = (path, idx) => {
      setAccepted((cur) => {
        const next = { ...cur };
        const existing = next[path] ?? /* @__PURE__ */ new Set();
        const set = new Set(existing);
        set.add(idx);
        next[path] = set;
        return next;
      });
      props.onAcceptHunk?.(path, idx);
    };
    return /* @__PURE__ */ u3("div", { class: "multi-diff-overlay", "aria-label": "Multi-file diff", children: /* @__PURE__ */ u3("div", { class: "multi-diff-panel", children: [
      /* @__PURE__ */ u3("header", { class: "multi-diff-header", children: [
        /* @__PURE__ */ u3("div", { class: "multi-diff-title", children: [
          "Multi-file Diff (",
          props.files.length,
          " files)"
        ] }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "multi-diff-close",
            "aria-label": "Close multi-file diff",
            onClick: props.onClose,
            children: "\xD7"
          }
        )
      ] }),
      /* @__PURE__ */ u3("div", { class: "multi-diff-body", children: [
        /* @__PURE__ */ u3("nav", { class: "multi-diff-rail", "aria-label": "File tree", children: tree.map((node) => /* @__PURE__ */ u3(
          TreeView,
          {
            node,
            selectedPath,
            onSelect: setSelectedPath,
            depth: 0
          },
          node.path
        )) }),
        /* @__PURE__ */ u3("section", { class: "multi-diff-detail", "aria-live": "polite", children: selected ? /* @__PURE__ */ u3(
          FileDiffView,
          {
            file: selected,
            acceptedHunks: accepted[selected.path] ?? /* @__PURE__ */ new Set(),
            onAcceptHunk: (idx) => handleAcceptHunk(selected.path, idx)
          }
        ) : /* @__PURE__ */ u3("div", { class: "multi-diff-empty", children: "Select a file on the left." }) })
      ] })
    ] }) });
  }
  function TreeView({ node, selectedPath, onSelect, depth }) {
    if (node.isFile) {
      const isSel = selectedPath === node.path;
      return /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: `multi-diff-row multi-diff-file${isSel ? " is-selected" : ""}`,
          style: { paddingLeft: `${8 + depth * 12}px` },
          onClick: () => onSelect(node.path),
          children: [
            /* @__PURE__ */ u3("span", { class: "multi-diff-row-icon", children: "\xB7" }),
            /* @__PURE__ */ u3("span", { class: "multi-diff-row-name", children: node.name })
          ]
        }
      );
    }
    return /* @__PURE__ */ u3(S, { children: [
      /* @__PURE__ */ u3("div", { class: "multi-diff-row multi-diff-dir", style: { paddingLeft: `${8 + depth * 12}px` }, children: [
        /* @__PURE__ */ u3("span", { class: "multi-diff-row-icon", children: "\u25BE" }),
        /* @__PURE__ */ u3("span", { class: "multi-diff-row-name", children: node.name })
      ] }),
      node.children.map((c4) => /* @__PURE__ */ u3(
        TreeView,
        {
          node: c4,
          selectedPath,
          onSelect,
          depth: depth + 1
        },
        c4.path
      ))
    ] });
  }
  function FileDiffView({ file, acceptedHunks, onAcceptHunk }) {
    const hunks = T2(() => computeHunkRows(file.before, file.after), [file]);
    return /* @__PURE__ */ u3("div", { class: "multi-diff-file-view", children: [
      /* @__PURE__ */ u3("header", { class: "multi-diff-file-header", children: [
        /* @__PURE__ */ u3("span", { class: "multi-diff-file-path", children: file.path }),
        /* @__PURE__ */ u3("span", { class: "multi-diff-file-counts", children: [
          hunks.length,
          " hunk",
          hunks.length === 1 ? "" : "s"
        ] })
      ] }),
      hunks.length === 0 ? /* @__PURE__ */ u3("div", { class: "multi-diff-empty", children: "No changes." }) : hunks.map((h5, idx) => /* @__PURE__ */ u3(
        "div",
        {
          class: `multi-diff-hunk${acceptedHunks.has(idx) ? " is-accepted" : ""}`,
          children: [
            /* @__PURE__ */ u3("header", { class: "multi-diff-hunk-header", children: [
              /* @__PURE__ */ u3("span", { class: "multi-diff-hunk-label", children: [
                "Hunk ",
                idx + 1,
                " (lines ",
                h5.beforeStart + 1,
                "-",
                h5.beforeEnd + 1,
                " \u2192 ",
                h5.afterStart + 1,
                "-",
                h5.afterEnd + 1,
                ")"
              ] }),
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "multi-diff-btn",
                  disabled: acceptedHunks.has(idx),
                  onClick: () => onAcceptHunk(idx),
                  children: acceptedHunks.has(idx) ? "Accepted" : "Accept hunk"
                }
              )
            ] }),
            /* @__PURE__ */ u3("div", { class: "multi-diff-hunk-cols", children: [
              /* @__PURE__ */ u3("div", { class: "multi-diff-hunk-col multi-diff-col-before", children: h5.rows.map((r4) => /* @__PURE__ */ u3(
                "div",
                {
                  class: `multi-diff-line${r4.left === void 0 ? " is-empty" : r4.kind === "del" ? " is-del" : ""}`,
                  children: [
                    /* @__PURE__ */ u3("span", { class: "multi-diff-sign", children: r4.left === void 0 ? " " : r4.kind === "del" ? "-" : " " }),
                    /* @__PURE__ */ u3("span", { class: "multi-diff-text", children: r4.left ?? "" })
                  ]
                },
                `b|${r4.kind}|${r4.left ?? "_"}|${r4.right ?? "_"}|${r4.seq}`
              )) }),
              /* @__PURE__ */ u3("div", { class: "multi-diff-hunk-col multi-diff-col-after", children: h5.rows.map((r4) => /* @__PURE__ */ u3(
                "div",
                {
                  class: `multi-diff-line${r4.right === void 0 ? " is-empty" : r4.kind === "add" ? " is-add" : ""}`,
                  children: [
                    /* @__PURE__ */ u3("span", { class: "multi-diff-sign", children: r4.right === void 0 ? " " : r4.kind === "add" ? "+" : " " }),
                    /* @__PURE__ */ u3("span", { class: "multi-diff-text", children: r4.right ?? "" })
                  ]
                },
                `a|${r4.kind}|${r4.left ?? "_"}|${r4.right ?? "_"}|${r4.seq}`
              )) })
            ] })
          ]
        },
        `${file.path}-h${idx}`
      ))
    ] });
  }
  function computeHunkRows(before, after) {
    const a4 = before.split("\n");
    const b3 = after.split("\n");
    const aSet = new Set(a4);
    const bSet = new Set(b3);
    const raw = [];
    let i5 = 0;
    let j4 = 0;
    while (i5 < a4.length || j4 < b3.length) {
      const x3 = a4[i5];
      const y4 = b3[j4];
      if (i5 >= a4.length) {
        raw.push({ left: void 0, right: y4, kind: "add", aIdx: i5, bIdx: j4 });
        j4++;
      } else if (j4 >= b3.length) {
        raw.push({ left: x3, right: void 0, kind: "del", aIdx: i5, bIdx: j4 });
        i5++;
      } else if (x3 === y4) {
        raw.push({ left: x3, right: y4, kind: "ctx", aIdx: i5, bIdx: j4 });
        i5++;
        j4++;
      } else if (!bSet.has(x3)) {
        raw.push({ left: x3, right: void 0, kind: "del", aIdx: i5, bIdx: j4 });
        i5++;
      } else if (!aSet.has(y4)) {
        raw.push({ left: void 0, right: y4, kind: "add", aIdx: i5, bIdx: j4 });
        j4++;
      } else {
        raw.push({ left: x3, right: y4, kind: "ctx", aIdx: i5, bIdx: j4 });
        i5++;
        j4++;
      }
    }
    const hunks = [];
    let h5 = [];
    const flush = () => {
      if (h5.length === 0) return;
      const first = h5[0];
      const last = h5[h5.length - 1];
      hunks.push({
        rows: h5.map(({ left, right, kind }, seq) => ({ left, right, kind, seq })),
        beforeStart: first.aIdx,
        beforeEnd: last.aIdx,
        afterStart: first.bIdx,
        afterEnd: last.bIdx
      });
      h5 = [];
    };
    let inHunk = false;
    for (let k3 = 0; k3 < raw.length; k3++) {
      const r4 = raw[k3];
      if (r4.kind !== "ctx") {
        if (!inHunk) {
          if (k3 > 0 && raw[k3 - 1].kind === "ctx") h5.push(raw[k3 - 1]);
          inHunk = true;
        }
        h5.push(r4);
      } else if (inHunk) {
        h5.push(r4);
        if (k3 + 1 >= raw.length || raw[k3 + 1].kind === "ctx") {
          flush();
          inHunk = false;
        }
      }
    }
    flush();
    return hunks;
  }
  function buildTree(paths) {
    const roots = [];
    for (const p5 of paths) {
      const parts = p5.split("/").filter((s5) => s5.length > 0);
      let parent = roots;
      let accum = "";
      for (let i5 = 0; i5 < parts.length; i5++) {
        const name = parts[i5];
        accum = accum ? `${accum}/${name}` : name;
        const isFile = i5 === parts.length - 1;
        let node = parent.find((n3) => n3.name === name && n3.isFile === isFile);
        if (!node) {
          node = { name, path: isFile ? p5 : accum, isFile, children: [] };
          parent.push(node);
        }
        parent = node.children;
      }
    }
    return roots;
  }

  // src/components/perf-panel.tsx
  function PerfPanel({ snapshot, onRefresh, onClose }) {
    const didMountRef = A2(false);
    y2(() => {
      if (didMountRef.current) return;
      didMountRef.current = true;
      onRefresh();
    }, [onRefresh]);
    const turns = snapshot?.turns ?? [];
    const heatmap = snapshot?.heatmap ?? [];
    return /* @__PURE__ */ u3("dialog", { class: "oati-perf-overlay", "aria-label": "Performance HUD", open: true, children: /* @__PURE__ */ u3("div", { class: "oati-perf-panel", children: [
      /* @__PURE__ */ u3("header", { class: "oati-perf-header", children: [
        /* @__PURE__ */ u3("h2", { children: "Performance HUD" }),
        /* @__PURE__ */ u3("div", { class: "oati-perf-header-actions", children: [
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "composer-btn",
              onClick: onRefresh,
              title: "Refetch the latest perf snapshot from the host",
              children: "Refresh"
            }
          ),
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-icon-btn",
              onClick: onClose,
              "aria-label": "Close performance HUD",
              title: "Close",
              children: "\u2715"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ u3("section", { class: "oati-perf-section", children: [
        /* @__PURE__ */ u3("h3", { class: "oati-perf-section-title", children: "Recent turns" }),
        turns.length === 0 ? /* @__PURE__ */ u3("p", { class: "oati-perf-empty", children: "No turns recorded yet. Send a message and reopen this panel." }) : /* @__PURE__ */ u3("table", { class: "oati-perf-table", children: [
          /* @__PURE__ */ u3("thead", { children: /* @__PURE__ */ u3("tr", { children: [
            /* @__PURE__ */ u3("th", { scope: "col", children: "Message" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "Duration" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "Tools" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "\u2193 In" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "\u2191 Out" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "Cost" })
          ] }) }),
          /* @__PURE__ */ u3("tbody", { children: turns.map((t4) => /* @__PURE__ */ u3("tr", { children: [
            /* @__PURE__ */ u3("td", { children: /* @__PURE__ */ u3("code", { class: "oati-perf-msgid", children: t4.msgId }) }),
            /* @__PURE__ */ u3("td", { children: formatDuration(t4.durationMs) }),
            /* @__PURE__ */ u3("td", { children: t4.toolCalls }),
            /* @__PURE__ */ u3("td", { children: formatTokens2(t4.inputTokens) }),
            /* @__PURE__ */ u3("td", { children: formatTokens2(t4.outputTokens) }),
            /* @__PURE__ */ u3("td", { children: t4.cost > 0 ? formatUsd2(t4.cost) : "\u2014" })
          ] }, t4.msgId)) })
        ] })
      ] }),
      /* @__PURE__ */ u3("section", { class: "oati-perf-section", children: [
        /* @__PURE__ */ u3("h3", { class: "oati-perf-section-title", children: "Slowest tools" }),
        heatmap.length === 0 ? /* @__PURE__ */ u3("p", { class: "oati-perf-empty", children: "No tool invocations recorded in the recent window." }) : /* @__PURE__ */ u3("table", { class: "oati-perf-table", children: [
          /* @__PURE__ */ u3("thead", { children: /* @__PURE__ */ u3("tr", { children: [
            /* @__PURE__ */ u3("th", { scope: "col", children: "Tool" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "Count" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "p50" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "p95" }),
            /* @__PURE__ */ u3("th", { scope: "col", children: "Error rate" })
          ] }) }),
          /* @__PURE__ */ u3("tbody", { children: heatmap.map((h5) => /* @__PURE__ */ u3("tr", { children: [
            /* @__PURE__ */ u3("td", { children: /* @__PURE__ */ u3("code", { class: "oati-perf-tool", children: h5.tool }) }),
            /* @__PURE__ */ u3("td", { children: h5.count }),
            /* @__PURE__ */ u3("td", { children: formatDuration(h5.p50Ms) }),
            /* @__PURE__ */ u3("td", { children: formatDuration(h5.p95Ms) }),
            /* @__PURE__ */ u3("td", { children: formatErrorRate(h5.errorRate) })
          ] }, h5.tool)) })
        ] })
      ] })
    ] }) });
  }
  function formatDuration(ms) {
    if (ms < 1) return "<1ms";
    if (ms < 1e3) return `${Math.round(ms)}ms`;
    return `${(ms / 1e3).toFixed(ms < 1e4 ? 2 : 1)}s`;
  }
  function formatTokens2(n3) {
    if (n3 < 1e3) return String(n3);
    if (n3 < 1e6) return `${(n3 / 1e3).toFixed(1)}k`;
    return `${(n3 / 1e6).toFixed(2)}M`;
  }
  function formatUsd2(n3) {
    if (n3 < 0.01) return `$${n3.toFixed(4)}`;
    if (n3 < 1) return `$${n3.toFixed(3)}`;
    return `$${n3.toFixed(2)}`;
  }
  function formatErrorRate(r4) {
    if (r4 === 0) return "0%";
    const pct = r4 * 100;
    if (pct < 1) return `${pct.toFixed(1)}%`;
    return `${Math.round(pct)}%`;
  }

  // src/components/plan-editor.tsx
  var STATUS_ICON = {
    pending: "\u25CB",
    running: "\u25D0",
    done: "\u25CF",
    skipped: "\u2014",
    failed: "\u2717"
  };
  function PlanEditor(props) {
    const [draggingId, setDraggingId] = d2(void 0);
    const [draft, setDraft] = d2(props.plan);
    y2(() => {
      setDraft((prev) => {
        const propsById = new Map(props.plan.steps.map((s5) => [s5.id, s5]));
        const prevById = new Map(prev.steps.map((s5) => [s5.id, s5]));
        const sameOrder = prev.steps.length === props.plan.steps.length && prev.steps.every((s5, i5) => props.plan.steps[i5]?.id === s5.id);
        const orderedIds = sameOrder ? prev.steps.map((s5) => s5.id) : props.plan.steps.map((s5) => s5.id);
        const merged = orderedIds.map((id) => {
          const propStep = propsById.get(id);
          const prevStep = prevById.get(id);
          if (!propStep && !prevStep) return void 0;
          if (!propStep) return prevStep;
          if (!prevStep) return propStep;
          return {
            ...propStep,
            title: prevStep.title,
            body: prevStep.body,
            ...prevStep.dependsOn ? { dependsOn: prevStep.dependsOn } : {}
          };
        }).filter((s5) => !!s5);
        return { ...props.plan, steps: merged };
      });
    }, [props.plan]);
    const commit = (next) => {
      setDraft(next);
      props.onChange(next);
    };
    const updateStep = (id, patch) => {
      const next = {
        ...draft,
        steps: draft.steps.map((s5) => s5.id === id ? { ...s5, ...patch } : s5)
      };
      commit(next);
    };
    const deleteStep = (id) => {
      const next = {
        ...draft,
        steps: draft.steps.filter((s5) => s5.id !== id)
      };
      commit(next);
    };
    const addStep = () => {
      const nextNum = draft.steps.length + 1;
      const newStep = {
        id: `s${nextNum}_${Date.now().toString(36).slice(-4)}`,
        title: "New step",
        body: "Done when \u2026",
        status: "pending"
      };
      commit({ ...draft, steps: [...draft.steps, newStep] });
    };
    const reorder = (fromId, toId) => {
      if (fromId === toId) return;
      const fromIdx = draft.steps.findIndex((s5) => s5.id === fromId);
      const toIdx = draft.steps.findIndex((s5) => s5.id === toId);
      if (fromIdx < 0 || toIdx < 0) return;
      const next = [...draft.steps];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      commit({ ...draft, steps: next });
    };
    const isExecuting = draft.state === "executing";
    const isTerminal = draft.state === "completed" || draft.state === "cancelled";
    return /* @__PURE__ */ u3("aside", { class: "oati-plan-editor", "aria-label": "Structured plan editor", children: [
      /* @__PURE__ */ u3("header", { class: "oati-plan-editor-header", children: [
        /* @__PURE__ */ u3("div", { class: "oati-plan-editor-title", children: [
          /* @__PURE__ */ u3("span", { class: "oati-plan-editor-icon", "aria-hidden": "true", children: "\u{1F4CB}" }),
          /* @__PURE__ */ u3("span", { class: "oati-plan-editor-goal", children: draft.goal || "(no goal)" })
        ] }),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-icon-btn oati-plan-editor-close",
            title: "Close plan editor",
            "aria-label": "Close plan editor",
            onClick: props.onClose,
            children: "\xD7"
          }
        )
      ] }),
      /* @__PURE__ */ u3("div", { class: "oati-plan-editor-meta", children: [
        /* @__PURE__ */ u3("span", { class: `oati-plan-editor-state oati-plan-editor-state-${draft.state}`, children: draft.state }),
        /* @__PURE__ */ u3("span", { class: "oati-plan-editor-count", children: [
          draft.steps.length,
          " step",
          draft.steps.length === 1 ? "" : "s"
        ] })
      ] }),
      /* @__PURE__ */ u3("ol", { class: "oati-plan-editor-steps", children: draft.steps.map((step) => /* @__PURE__ */ u3(
        "li",
        {
          class: `oati-plan-step oati-plan-step-${step.status} ${draggingId === step.id ? "oati-plan-step-dragging" : ""}`,
          draggable: !isExecuting,
          onDragStart: (e4) => {
            setDraggingId(step.id);
            if (e4.dataTransfer) {
              e4.dataTransfer.effectAllowed = "move";
              e4.dataTransfer.setData("text/plain", step.id);
            }
          },
          onDragOver: (e4) => {
            e4.preventDefault();
            if (e4.dataTransfer) e4.dataTransfer.dropEffect = "move";
          },
          onDrop: (e4) => {
            e4.preventDefault();
            const from = e4.dataTransfer?.getData("text/plain");
            if (from) reorder(from, step.id);
            setDraggingId(void 0);
          },
          onDragEnd: () => setDraggingId(void 0),
          children: [
            /* @__PURE__ */ u3("div", { class: "oati-plan-step-row", children: [
              /* @__PURE__ */ u3("span", { class: "oati-plan-step-handle", "aria-hidden": "true", title: "Drag to reorder", children: "\u22EE\u22EE" }),
              /* @__PURE__ */ u3("span", { class: "oati-plan-step-status", title: `status: ${step.status}`, children: STATUS_ICON[step.status] }),
              /* @__PURE__ */ u3(
                "input",
                {
                  class: "oati-plan-step-title",
                  type: "text",
                  value: step.title,
                  disabled: isExecuting,
                  onInput: (e4) => updateStep(step.id, { title: e4.target.value })
                }
              ),
              /* @__PURE__ */ u3(
                "button",
                {
                  type: "button",
                  class: "oati-icon-btn oati-icon-btn-sm oati-plan-step-delete",
                  title: "Delete step",
                  "aria-label": `Delete step ${step.id}`,
                  disabled: isExecuting,
                  onClick: () => deleteStep(step.id),
                  children: "\u{1F5D1}"
                }
              )
            ] }),
            /* @__PURE__ */ u3(
              "textarea",
              {
                class: "oati-plan-step-body",
                value: step.body,
                rows: 2,
                disabled: isExecuting,
                onInput: (e4) => updateStep(step.id, { body: e4.target.value })
              }
            ),
            step.dependsOn && step.dependsOn.length > 0 && /* @__PURE__ */ u3("div", { class: "oati-plan-step-deps", children: [
              "depends on: ",
              step.dependsOn.join(", ")
            ] }),
            step.result && /* @__PURE__ */ u3("details", { class: "oati-plan-step-result", children: [
              /* @__PURE__ */ u3("summary", { children: "Result" }),
              /* @__PURE__ */ u3("pre", { children: step.result })
            ] })
          ]
        },
        step.id
      )) }),
      /* @__PURE__ */ u3("div", { class: "oati-plan-editor-add", children: /* @__PURE__ */ u3("button", { type: "button", class: "oati-plan-editor-btn", disabled: isExecuting, onClick: addStep, children: "+ Add step" }) }),
      /* @__PURE__ */ u3("footer", { class: "oati-plan-editor-footer", children: [
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-plan-editor-btn oati-plan-editor-btn-primary",
            disabled: isExecuting || isTerminal || draft.steps.length === 0,
            onClick: () => props.onExecute(draft.id),
            children: isExecuting ? "Executing\u2026" : "Execute"
          }
        ),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-plan-editor-btn",
            disabled: !isExecuting,
            onClick: () => props.onCancel(draft.id),
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-plan-editor-btn",
            disabled: draft.steps.length === 0,
            onClick: () => props.onSaveAsRecipe(draft),
            title: "Persist this plan as a recipe under .oati/recipes/",
            children: "Save as recipe"
          }
        )
      ] })
    ] });
  }

  // src/app.tsx
  var messages = y3([]);
  var modes = y3([]);
  var activeMode = y3("");
  var pendingApproval = y3(null);
  var pendingSecretWarning = y3(null);
  var isAgentRunning = y3(false);
  var errorBanner = y3(null);
  var view = y3("chat");
  var settingsSnapshot = y3(null);
  var todos = y3([]);
  var proposedPlan = y3(null);
  var backgroundTasksTray = y3([]);
  var checkpointsList = y3([]);
  var supervisorItems = y3([]);
  var workspaceInfo = y3(void 0);
  var connectionTestResult = y3(void 0);
  var sessionInputTokens = y3(0);
  var sessionOutputTokens = y3(0);
  var workspaceFiles = y3([]);
  var agentStatus = y3({ inputTokens: 0, outputTokens: 0 });
  var attachments = y3([]);
  var promptHistory = y3([]);
  var customCommands = y3([]);
  var contextProviderMentions = y3([]);
  var attachedSelection = y3(null);
  var composerInjectedText = y3("");
  var composerInjectionVersion = y3(0);
  var onboardingCompleted = y3(isOnboardingCompleted());
  var SHOW_TOKEN_USAGE_KEY = "oati.showTokenUsage";
  var showTokenUsage = y3(
    (() => {
      try {
        return localStorage.getItem(SHOW_TOKEN_USAGE_KEY) === "1";
      } catch {
        return false;
      }
    })()
  );
  var SHOW_STOP_BUTTON_KEY = "oati.showStopButton";
  var showStopButton = y3(
    (() => {
      try {
        return localStorage.getItem(SHOW_STOP_BUTTON_KEY) === "1";
      } catch {
        return false;
      }
    })()
  );
  var routeBadge = y3(null);
  var prReviewBanner = y3(null);
  var diagrams = y3([]);
  var pendingDiagramTitle = y3(void 0);
  var snippetsCatalog = y3([]);
  var templatesCatalog = y3([]);
  var pendingSnippetSaveName = y3(void 0);
  var pendingSnippetResolution = y3(null);
  var pendingNotebookResolution = y3(null);
  var pendingCodebaseResolution = y3(null);
  var embedderState = y3(null);
  var composerOpen = y3(false);
  var composerFiles = y3([]);
  var composerStatus = y3(
    "idle"
  );
  var composerError = y3(void 0);
  var composerAppliedPaths = y3(void 0);
  var composerInitialInstruction = y3("");
  var multiFileDiffOpen = y3(false);
  var multiFileDiffFiles = y3([]);
  var pinnedMessageIds = y3([]);
  var jumpToMessageId = y3(void 0);
  var forkInfo = y3(null);
  var compareSession = y3(null);
  var compareLeftState = y3({ text: "", status: "pending" });
  var compareRightState = y3({ text: "", status: "pending" });
  var diagnosticsCount = y3({
    errors: 0,
    warnings: 0
  });
  var knowledgeState = y3({
    docs: 0,
    rulesActive: false
  });
  var offlineMode = y3({
    offline: false,
    localProviders: []
  });
  var debugSession = y3({ active: false });
  var marketplaceOpen = y3(false);
  var marketplaceItems = y3([]);
  var perfPanelOpen = y3(false);
  var perfSnapshot = y3(void 0);
  var perfDurationByMsgId = y3({});
  var currentTurnStartedAt = y3(void 0);
  var currentPlan = y3(null);
  var planPanelOpen = y3(false);
  var personas = y3([]);
  var activePersonaId = y3(null);
  var recipesCatalog = y3([]);
  function resetAgentStatus() {
    agentStatus.value = { inputTokens: 0, outputTokens: 0 };
  }
  function App() {
    const bus = T2(() => createWebviewBus(), []);
    y2(() => {
      const unsub = bus.on((msg) => {
        if (msg.type === "init") {
          modes.value = [...msg.modes];
          activeMode.value = msg.activeModeId;
          workspaceFiles.value = msg.workspaceFiles;
          customCommands.value = msg.customCommands ?? [];
        } else if (msg.type === "agent_event") {
          handleAgentEvent(msg.event);
        } else if (msg.type === "approval_request") {
          pendingApproval.value = msg.request;
        } else if (msg.type === "secret_warning") {
          pendingSecretWarning.value = {
            id: msg.id,
            summary: msg.summary,
            matches: msg.matches
          };
        } else if (msg.type === "settings") {
          settingsSnapshot.value = msg.snapshot;
          if (msg.snapshot.config.activeModeId !== activeMode.value) {
            activeMode.value = msg.snapshot.config.activeModeId;
          }
        } else if (msg.type === "show_view") {
          view.value = msg.view;
        } else if (msg.type === "todos_updated") {
          todos.value = msg.items;
        } else if (msg.type === "background_tasks_snapshot") {
          backgroundTasksTray.value = msg.tasks;
        } else if (msg.type === "checkpoints_list") {
          checkpointsList.value = msg.items;
        } else if (msg.type === "supervisor_suggestions") {
          supervisorItems.value = msg.items;
        } else if (msg.type === "workspace_info") {
          workspaceInfo.value = msg.info;
        } else if (msg.type === "connection_test_result") {
          connectionTestResult.value = {
            providerId: msg.providerId,
            ok: msg.ok,
            message: msg.message
          };
        } else if (msg.type === "attachment_ready") {
          attachments.value = [
            ...attachments.value,
            {
              id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
              name: msg.name,
              path: msg.path,
              language: msg.language,
              text: msg.text,
              truncated: msg.truncated
            }
          ];
        } else if (msg.type === "attach_selection") {
          attachedSelection.value = {
            path: msg.path,
            language: msg.language,
            text: msg.text,
            startLine: msg.startLine,
            endLine: msg.endLine
          };
        } else if (msg.type === "prefill_prompt") {
          composerInjectedText.value = msg.text;
          composerInjectionVersion.value = composerInjectionVersion.value + 1;
        } else if (msg.type === "restore_session") {
          messages.value = [...msg.messages];
          isAgentRunning.value = false;
          sessionInputTokens.value = 0;
          sessionOutputTokens.value = 0;
          resetAgentStatus();
          attachments.value = [];
          attachedSelection.value = null;
        } else if (msg.type === "indexing_progress") {
          const isDone = !!msg.done_indexing;
          const text = isDone ? `Indexed ${msg.total} files (${msg.chunks ?? 0} chunks) \u2014 semantic search enabled.` : `Indexing... ${msg.done} / ${msg.total}${msg.file ? ` \u2014 ${msg.file}` : ""}`;
          const existing = messages.value.findIndex((m4) => m4.id === "indexing_progress");
          if (existing >= 0) {
            const next = [...messages.value];
            next[existing] = { id: "indexing_progress", role: "system", text };
            messages.value = next;
          } else {
            messages.value = [...messages.value, { id: "indexing_progress", role: "system", text }];
          }
        } else if (msg.type === "error") {
          if (msg.message) {
            errorBanner.value = msg.message;
            messages.value = [
              ...messages.value.map(
                (m4) => m4.role === "assistant" && m4.pending ? { ...m4, pending: false } : m4
              ),
              {
                id: `err_${Date.now()}`,
                role: "system",
                text: `\u26A0\uFE0F **Error:** ${msg.message}`
              }
            ];
          }
          isAgentRunning.value = false;
          resetAgentStatus();
        } else if (msg.type === "composer_started") {
          composerOpen.value = true;
          composerFiles.value = [];
          composerStatus.value = "idle";
          composerError.value = void 0;
          composerAppliedPaths.value = void 0;
        } else if (msg.type === "composer_file_preview") {
          const existing = composerFiles.value.find((f5) => f5.path === msg.path);
          const next = {
            path: msg.path,
            before: msg.before,
            after: msg.after,
            ...msg.language ? { language: msg.language } : {},
            state: existing?.state ?? "pending"
          };
          if (existing) {
            composerFiles.value = composerFiles.value.map((f5) => f5.path === msg.path ? next : f5);
          } else {
            composerFiles.value = [...composerFiles.value, next];
          }
          composerStatus.value = "running";
        } else if (msg.type === "composer_done") {
          if (msg.status === "ok") {
            composerStatus.value = composerFiles.value.length > 0 ? "ready" : "idle";
            composerError.value = void 0;
          } else if (msg.status === "cancelled") {
            composerStatus.value = "cancelled";
            composerError.value = void 0;
          } else {
            composerStatus.value = "error";
            composerError.value = msg.message;
          }
        } else if (msg.type === "composer_applied") {
          composerAppliedPaths.value = msg.paths;
          composerStatus.value = "applied";
          composerFiles.value = [];
        } else if (msg.type === "route_decision") {
          routeBadge.value = {
            providerId: msg.providerId,
            ...msg.model ? { model: msg.model } : {},
            ...msg.reason ? { reason: msg.reason } : {}
          };
        } else if (msg.type === "pinned_messages_state") {
          pinnedMessageIds.value = msg.pinnedIds;
          const set = new Set(msg.pinnedIds);
          messages.value = messages.value.map(
            (m4) => set.has(m4.id) === !!m4.pinned ? m4 : { ...m4, pinned: set.has(m4.id) }
          );
        } else if (msg.type === "fork_info") {
          forkInfo.value = {
            parentSessionId: msg.parentSessionId,
            forkedAtMessageId: msg.forkedAtMessageId,
            ...msg.parentTitle ? { parentTitle: msg.parentTitle } : {}
          };
        } else if (msg.type === "compare_chunk") {
          if (msg.side === "left") {
            const prev = compareLeftState.value;
            compareLeftState.value = {
              ...prev,
              text: prev.text + msg.chunk,
              status: prev.status === "ok" || prev.status === "error" ? prev.status : "streaming"
            };
          } else {
            const prev = compareRightState.value;
            compareRightState.value = {
              ...prev,
              text: prev.text + msg.chunk,
              status: prev.status === "ok" || prev.status === "error" ? prev.status : "streaming"
            };
          }
        } else if (msg.type === "compare_done") {
          const next = {
            text: msg.side === "left" ? compareLeftState.value.text : compareRightState.value.text,
            status: msg.status,
            ...msg.message ? { message: msg.message } : {}
          };
          if (msg.side === "left") compareLeftState.value = next;
          else compareRightState.value = next;
        } else if (msg.type === "pr_review_started") {
          prReviewBanner.value = {
            url: msg.url,
            status: "running",
            number: msg.number,
            owner: msg.owner,
            repo: msg.repo
          };
          isAgentRunning.value = true;
        } else if (msg.type === "pr_review_finished") {
          prReviewBanner.value = {
            url: msg.url,
            status: msg.status,
            ...prReviewBanner.value ? {
              number: prReviewBanner.value.number,
              owner: prReviewBanner.value.owner,
              repo: prReviewBanner.value.repo
            } : {},
            ...msg.message ? { message: msg.message } : {}
          };
          if (msg.status === "error" && msg.message) {
            messages.value = [
              ...messages.value,
              {
                id: `pr_err_${Date.now()}`,
                role: "system",
                text: `PR review failed: ${msg.message}`
              }
            ];
          }
        } else if (msg.type === "templates_list") {
          templatesCatalog.value = msg.items;
          messages.value = [
            ...messages.value,
            {
              id: `tpl_list_${Date.now()}`,
              role: "system",
              text: msg.items.length === 0 ? "No project templates are bundled." : `**Available templates** \u2014 use \`/init <name>\` to apply.
${msg.items.map((t4) => `- \`${t4.name}\` \u2014 ${t4.description}`).join("\n")}`
            }
          ];
        } else if (msg.type === "template_applied") {
          const lines = [
            `**Template '${msg.name}' applied.**`,
            msg.created.length > 0 ? `Created (${msg.created.length}):` : "",
            ...msg.created.map((p5) => `- ${p5}`),
            msg.skipped.length > 0 ? `Skipped existing (${msg.skipped.length}):` : "",
            ...msg.skipped.map((p5) => `- ${p5}`)
          ].filter((s5) => s5.length > 0);
          messages.value = [
            ...messages.value,
            {
              id: `tpl_done_${Date.now()}`,
              role: "system",
              text: lines.join("\n")
            }
          ];
        } else if (msg.type === "snippets_list") {
          snippetsCatalog.value = msg.items;
          const body = msg.items.length === 0 ? "No snippets saved yet. Use `/save <name>` to capture the previous assistant reply." : `**Saved snippets** \u2014 type \`@snip:<name>\` to insert at send time.
${msg.items.map((s5) => `- \`@snip:${s5.name}\` \u2014 ${s5.description}`).join("\n")}`;
          messages.value = [
            ...messages.value,
            { id: `snip_list_${Date.now()}`, role: "system", text: body }
          ];
        } else if (msg.type === "snippet_saved") {
          const text = msg.ok ? `Saved snippet \`${msg.name}\`. Use \`@snip:${msg.name}\` to insert it.` : `Failed to save snippet \`${msg.name}\`${msg.message ? `: ${msg.message}` : "."}`;
          messages.value = [...messages.value, { id: `snip_saved_${Date.now()}`, role: "system", text }];
          pendingSnippetSaveName.value = void 0;
        } else if (msg.type === "snippet_body") {
          const pending = pendingSnippetResolution.value;
          if (pending && pending.name === msg.name) {
            pendingSnippetResolution.value = null;
            if (msg.body !== void 0) {
              const replaced = pending.placeholder.replace(`@snip:${pending.name}`, msg.body);
              const finalText = replaced + pending.remainder;
              messages.value = [
                ...messages.value,
                { id: `u_${Date.now()}`, role: "user", text: finalText }
              ];
              isAgentRunning.value = true;
              resetAgentStatus();
              bus.send({ type: "user_message", content: finalText });
            } else {
              messages.value = [
                ...messages.value,
                {
                  id: `snip_err_${Date.now()}`,
                  role: "system",
                  text: `Could not resolve \`@snip:${msg.name}\`${msg.message ? `: ${msg.message}` : "."}`
                }
              ];
              isAgentRunning.value = false;
            }
          }
        } else if (msg.type === "notebook_cell_body") {
          const pending = pendingNotebookResolution.value;
          if (pending && pending.path === msg.path && pending.index === msg.index) {
            pendingNotebookResolution.value = null;
            if (msg.body !== void 0) {
              const mention = `@notebook:${pending.path}:${pending.index}`;
              const fenced = `

--- ${pending.path} (cell ${pending.index}) ---
\`\`\`
${msg.body}
\`\`\`
`;
              const replaced = pending.placeholder.replace(mention, fenced);
              const finalText = replaced + pending.remainder;
              messages.value = [
                ...messages.value,
                { id: `u_${Date.now()}`, role: "user", text: finalText }
              ];
              isAgentRunning.value = true;
              resetAgentStatus();
              bus.send({ type: "user_message", content: finalText });
            } else {
              messages.value = [
                ...messages.value,
                {
                  id: `nbcell_err_${Date.now()}`,
                  role: "system",
                  text: `Could not resolve \`@notebook:${msg.path}:${msg.index}\`${msg.message ? `: ${msg.message}` : "."}`
                }
              ];
              isAgentRunning.value = false;
            }
          }
        } else if (msg.type === "codebase_deep_search_results") {
          const pending = pendingCodebaseResolution.value;
          if (pending && pending.query === msg.query) {
            pendingCodebaseResolution.value = null;
            let prepended = pending.originalText;
            if (msg.hits.length > 0) {
              const block2 = msg.hits.slice(0, 20).map(
                (h5, i5) => `### ${i5 + 1}. ${h5.filePath}:${h5.startLine}-${h5.endLine} (score=${h5.score.toFixed(3)})
\`\`\`
${h5.content}
\`\`\``
              ).join("\n\n");
              prepended = `Top relevant code chunks for \`${msg.query}\`:

${block2}

---

${pending.originalText}`;
            } else {
              messages.value = [
                ...messages.value,
                {
                  id: `cb_empty_${Date.now()}`,
                  role: "system",
                  text: `No matches for \`@codebase ${msg.query}\`. Try /reindex.`
                }
              ];
            }
            messages.value = [...messages.value, { id: `u_${Date.now()}`, role: "user", text: prepended }];
            isAgentRunning.value = true;
            resetAgentStatus();
            bus.send({ type: "user_message", content: prepended });
          }
        } else if (msg.type === "embedder_state") {
          embedderState.value = {
            id: msg.id,
            displayName: msg.displayName,
            dimensions: msg.dimensions,
            chunks: msg.indexed.chunks,
            files: msg.indexed.files,
            reindexRequired: msg.reindexRequired
          };
        } else if (msg.type === "diagram_render") {
          const existing = diagrams.value.find((d5) => d5.id === msg.id);
          if (existing) {
            diagrams.value = diagrams.value.map(
              (d5) => d5.id === msg.id ? { id: d5.id, mermaid: msg.mermaid, ...msg.title ? { title: msg.title } : {} } : d5
            );
          } else {
            diagrams.value = [
              ...diagrams.value,
              { id: msg.id, mermaid: msg.mermaid, ...msg.title ? { title: msg.title } : {} }
            ];
          }
        } else if (msg.type === "diagnostics_count") {
          diagnosticsCount.value = { errors: msg.errors, warnings: msg.warnings };
        } else if (msg.type === "marketplace_state") {
          marketplaceItems.value = msg.items.map((it) => ({
            id: it.id,
            displayName: it.displayName,
            description: it.description,
            category: it.category,
            installed: it.installed,
            enabled: it.enabled,
            ...it.homepage ? { homepage: it.homepage } : {}
          }));
        } else if (msg.type === "marketplace_open") {
          marketplaceOpen.value = true;
        } else if (msg.type === "perf_snapshot") {
          perfSnapshot.value = { turns: msg.turns, heatmap: msg.heatmap };
          const map = {};
          for (const t4 of msg.turns) map[t4.msgId] = t4.durationMs;
          perfDurationByMsgId.value = map;
        } else if (msg.type === "knowledge_state") {
          knowledgeState.value = { docs: msg.docs, rulesActive: msg.rulesActive };
          if (msg.entries) {
            const body = msg.entries.length === 0 ? "No knowledge docs yet. Add markdown files under `.oati/knowledge/` to enable RAG." : `**Indexed knowledge** (${msg.entries.length} doc${msg.entries.length === 1 ? "" : "s"}):
${msg.entries.map((e4) => `- \`${e4.path}\` \u2014 ${e4.title}`).join("\n")}`;
            messages.value = [
              ...messages.value,
              { id: `know_list_${Date.now()}`, role: "system", text: body }
            ];
          }
        } else if (msg.type === "conversation_search_results") {
          const body = msg.items.length === 0 ? `No matches for \`${msg.query}\`.` : `**Search results for \`${msg.query}\`** (${msg.items.length})
${msg.items.map(
            (it) => `- [${it.role}@${it.sessionId.slice(0, 8)}:${it.messageId}](command:oati.sessions.open?${encodeURIComponent(JSON.stringify(it.sessionId))}) \u2014 ${it.snippet.replace(/\n+/g, " ").slice(0, 160)}`
          ).join("\n")}`;
          messages.value = [
            ...messages.value,
            { id: `search_${Date.now()}`, role: "system", text: body }
          ];
        } else if (msg.type === "personas_list") {
          personas.value = msg.items;
          activePersonaId.value = msg.activeId;
        } else if (msg.type === "recipes_list") {
          recipesCatalog.value = msg.items;
          const body = msg.items.length === 0 ? "No recipes saved yet. Drop one at `.oati/recipes/<name>.md` with `name:`, `description:`, and `steps:` front-matter." : `**Available recipes** \u2014 use \`/recipe <name>\` to run one.
${msg.items.map((r4) => `- \`${r4.name}\` \u2014 ${r4.description}`).join("\n")}`;
          messages.value = [
            ...messages.value,
            { id: `rec_list_${Date.now()}`, role: "system", text: body }
          ];
        } else if (msg.type === "recipe_step_started") {
          messages.value = [
            ...messages.value,
            {
              id: `rec_step_${msg.name}_${msg.index}_start`,
              role: "system",
              text: `Recipe \`${msg.name}\` \u2014 step ${msg.index + 1}/${msg.total}: ${msg.text}`
            }
          ];
          isAgentRunning.value = true;
        } else if (msg.type === "recipe_step_done") {
          const label = msg.ok ? "ok" : "failed";
          messages.value = [
            ...messages.value,
            {
              id: `rec_step_${msg.name}_${msg.index}_done`,
              role: "system",
              text: `Recipe \`${msg.name}\` \u2014 step ${msg.index + 1}/${msg.total} ${label}${msg.message ? `: ${msg.message}` : "."}`
            }
          ];
          if (msg.index + 1 >= msg.total || !msg.ok) {
            isAgentRunning.value = false;
          }
        } else if (msg.type === "offline_mode") {
          offlineMode.value = { offline: msg.offline, localProviders: msg.localProviders };
        } else if (msg.type === "debug_session_state") {
          debugSession.value = msg.active ? {
            active: true,
            ...msg.sessionType ? { sessionType: msg.sessionType } : {},
            ...msg.sessionName ? { sessionName: msg.sessionName } : {},
            ...msg.stoppedThreadId !== void 0 ? { stoppedThreadId: msg.stoppedThreadId } : {}
          } : { active: false };
        } else if (msg.type === "streaming_diff_partial") {
          const existing = composerFiles.value.find((f5) => f5.path === msg.path);
          if (!existing) {
            composerFiles.value = [
              ...composerFiles.value,
              { path: msg.path, before: "", after: msg.content, state: "pending" }
            ];
          } else {
            composerFiles.value = composerFiles.value.map(
              (f5) => f5.path === msg.path ? { ...f5, after: msg.content } : f5
            );
          }
          composerStatus.value = "running";
        } else if (msg.type === "multi_file_diff_open") {
          multiFileDiffFiles.value = msg.files;
          multiFileDiffOpen.value = true;
        } else if (msg.type === "plan_proposed") {
          currentPlan.value = msg.plan;
          planPanelOpen.value = true;
        } else if (msg.type === "plan_step_status") {
          const cur = currentPlan.value;
          if (cur && cur.id === msg.planId) {
            currentPlan.value = {
              ...cur,
              steps: cur.steps.map(
                (s5) => s5.id === msg.stepId ? {
                  ...s5,
                  status: msg.status,
                  ...msg.result !== void 0 ? { result: msg.result } : {}
                } : s5
              ),
              state: cur.state === "draft" ? "executing" : cur.state
            };
          }
        } else if (msg.type === "plan_completed") {
          const cur = currentPlan.value;
          if (cur && cur.id === msg.planId) {
            currentPlan.value = {
              ...cur,
              state: msg.status === "completed" ? "completed" : "cancelled"
            };
          }
          const label = msg.status === "completed" ? "completed" : msg.status === "cancelled" ? "cancelled" : "failed";
          messages.value = [
            ...messages.value,
            {
              id: `plan_done_${msg.planId}`,
              role: "system",
              text: `Plan ${label}.`
            }
          ];
        } else if (msg.type === "context_providers_list") {
          contextProviderMentions.value = msg.items;
        }
      });
      bus.send({ type: "ready" });
      bus.send({ type: "request_session_meta" });
      const handleOpenMarketplace = () => {
        marketplaceOpen.value = true;
        view.value = "chat";
        bus.send({ type: "marketplace_list_request" });
      };
      window.addEventListener("oati:open-marketplace", handleOpenMarketplace);
      return () => {
        unsub();
        bus.dispose();
        window.removeEventListener("oati:open-marketplace", handleOpenMarketplace);
      };
    }, [bus]);
    const handleSend = (text) => {
      const cbMatch = /@codebase\s+(.+)/.exec(text);
      if (cbMatch) {
        const query = cbMatch[1].trim();
        if (query.length > 0) {
          pendingCodebaseResolution.value = { originalText: text, query };
          messages.value = [
            ...messages.value,
            {
              id: `cb_pending_${Date.now()}`,
              role: "system",
              text: `Searching codebase for \`${query}\`\u2026`
            }
          ];
          bus.send({ type: "codebase_deep_search_request", query });
          return;
        }
      }
      const nbMatch = /@notebook:([^\s:]+):(\d+)/.exec(text);
      if (nbMatch) {
        const nbPath = nbMatch[1];
        const nbIndex = Number.parseInt(nbMatch[2], 10);
        const nbIdx = nbMatch.index ?? 0;
        const placeholder = text.slice(0, nbIdx + nbMatch[0].length);
        const remainder = text.slice(nbIdx + nbMatch[0].length);
        pendingNotebookResolution.value = {
          placeholder,
          path: nbPath,
          index: nbIndex,
          remainder
        };
        messages.value = [
          ...messages.value,
          {
            id: `nbcell_pending_${Date.now()}`,
            role: "system",
            text: `Resolving \`@notebook:${nbPath}:${nbIndex}\`\u2026`
          }
        ];
        bus.send({ type: "read_notebook_cell_request", path: nbPath, index: nbIndex });
        return;
      }
      const snipMatch = /@snip:([a-zA-Z0-9_-]+)/.exec(text);
      if (snipMatch) {
        const name = snipMatch[1];
        const idx = snipMatch.index ?? 0;
        const placeholder = text.slice(0, idx + snipMatch[0].length);
        const remainder = text.slice(idx + snipMatch[0].length);
        pendingSnippetResolution.value = { placeholder, name, remainder };
        messages.value = [
          ...messages.value,
          {
            id: `snip_pending_${Date.now()}`,
            role: "system",
            text: `Resolving \`@snip:${name}\`\u2026`
          }
        ];
        bus.send({ type: "read_snippet_request", name });
        return;
      }
      const id = `u_${Date.now()}`;
      const imgAttachments = attachments.value.filter((a4) => a4.imageDataUrl && a4.mimeType);
      const images = imgAttachments.map((a4) => ({
        mimeType: a4.mimeType,
        dataUrl: a4.imageDataUrl
      }));
      messages.value = [
        ...messages.value,
        {
          id,
          role: "user",
          text,
          ...images.length > 0 ? { images } : {}
        }
      ];
      const userTyped = stripAttachmentPrefix(text);
      if (userTyped.length > 0) {
        const trimmed = [...promptHistory.value.filter((p5) => p5 !== userTyped), userTyped];
        promptHistory.value = trimmed.slice(-50);
      }
      attachments.value = [];
      isAgentRunning.value = true;
      resetAgentStatus();
      routeBadge.value = null;
      currentTurnStartedAt.value = Date.now();
      bus.send({
        type: "user_message",
        content: text,
        ...images.length > 0 ? {
          attachments: images.map((i5) => ({
            kind: "image",
            mimeType: i5.mimeType,
            dataUrl: i5.dataUrl
          }))
        } : {}
      });
    };
    const handleRegenerateFrom = (messageId, newContent) => {
      const idx = messages.value.findIndex((m4) => m4.id === messageId);
      if (idx < 0) return;
      const before = messages.value.slice(0, idx);
      messages.value = [...before, { ...messages.value[idx], text: newContent }];
      isAgentRunning.value = true;
      resetAgentStatus();
      bus.send({ type: "regenerate_from", messageId, content: newContent });
    };
    const handleCancel = () => bus.send({ type: "cancel" });
    const handleApproval = (approved) => {
      const req = pendingApproval.value;
      if (!req) return;
      bus.send({ type: "approval_response", id: req.id, approved });
      pendingApproval.value = null;
    };
    const handleSecretChoice = (choice) => {
      const w4 = pendingSecretWarning.value;
      if (!w4) return;
      bus.send({ type: "secret_confirm", id: w4.id, choice });
      pendingSecretWarning.value = null;
    };
    const handleModeChange = (modeId) => {
      activeMode.value = modeId;
      bus.send({ type: "set_mode", modeId });
    };
    const openSettings = () => {
      if (!settingsSnapshot.value) bus.send({ type: "get_settings" });
      view.value = "settings";
    };
    const handleNewChat = () => {
      bus.send({ type: "new_session" });
    };
    const handleClearCurrent = () => {
      bus.send({ type: "clear_session" });
    };
    const handlePickAttachment = () => {
      bus.send({ type: "pick_attachment" });
    };
    const handleSplitChat = () => {
      bus.send({ type: "split_chat" });
    };
    const handleOpenPath = (path) => {
      bus.send({ type: "open_file", path });
    };
    const handleRenameChat = () => {
      bus.send({ type: "rename_current_session" });
    };
    const handleRemoveAttachment = (id) => {
      attachments.value = attachments.value.filter((a4) => a4.id !== id);
    };
    const handleAddImageAttachment = (att) => {
      attachments.value = [...attachments.value, att];
    };
    const handleSettingsSave = (settings, apiKey) => {
      bus.send({ type: "update_settings", settings });
      if (apiKey) {
        if (apiKey.value.trim().length === 0) {
          bus.send({ type: "delete_api_key", providerId: apiKey.providerId });
        } else {
          bus.send({
            type: "update_api_key",
            providerId: apiKey.providerId,
            apiKey: apiKey.value
          });
        }
      }
    };
    const handleSettingsDone = () => {
      view.value = "chat";
    };
    const handleTestConnection = (providerId) => {
      connectionTestResult.value = void 0;
      bus.send({ type: "test_connection", providerId });
    };
    const handleForkFrom = (messageId) => {
      bus.send({ type: "fork_conversation", atMessageId: messageId });
    };
    const handleTogglePin = (messageId, pinned) => {
      messages.value = messages.value.map((m4) => m4.id === messageId ? { ...m4, pinned } : m4);
      const set = new Set(pinnedMessageIds.value);
      if (pinned) set.add(messageId);
      else set.delete(messageId);
      pinnedMessageIds.value = [...set];
      bus.send({ type: "pin_message", messageId, pinned });
    };
    const handleJumpToPinned = (messageId) => {
      jumpToMessageId.value = messageId;
      window.setTimeout(() => {
        if (jumpToMessageId.value === messageId) jumpToMessageId.value = void 0;
      }, 50);
    };
    const openCompare = (spec) => {
      compareSession.value = spec;
      compareLeftState.value = { text: "", status: "pending" };
      compareRightState.value = { text: "", status: "pending" };
      bus.send({
        type: "compare_request",
        instruction: spec.instruction,
        left: spec.left,
        right: spec.right
      });
    };
    const closeCompare = () => {
      bus.send({ type: "compare_cancel" });
      compareSession.value = null;
      compareLeftState.value = { text: "", status: "pending" };
      compareRightState.value = { text: "", status: "pending" };
    };
    const openCompareFromComposer = (instruction) => {
      const snap = settingsSnapshot.value;
      if (!snap) {
        errorBanner.value = "Settings not loaded yet \u2014 try again in a moment.";
        return;
      }
      const providers = snap.config.providers;
      if (providers.length < 1) {
        errorBanner.value = "Configure at least one provider before running a compare.";
        return;
      }
      const left = providers[0];
      const right = providers[1] ?? providers[0];
      openCompare({
        instruction,
        left: {
          providerId: left.id,
          ...left.defaultModel ? { model: left.defaultModel } : {}
        },
        right: {
          providerId: right.id,
          ...right.defaultModel ? { model: right.defaultModel } : {}
        }
      });
    };
    const slashCommands = [
      { name: "new", description: "Start a new chat in a new tab", run: handleNewChat },
      { name: "clear", description: "Clear messages in the current chat", run: handleClearCurrent },
      { name: "settings", description: "Open settings", run: openSettings },
      { name: "attach", description: "Attach a file to your next message", run: handlePickAttachment },
      { name: "split", description: "Split chat into a new editor group", run: handleSplitChat },
      { name: "rename", description: "Rename the current chat", run: handleRenameChat },
      {
        name: "cost",
        description: "Show session token totals and estimated USD cost",
        run: () => {
          messages.value = [
            ...messages.value,
            {
              id: `cost_${Date.now()}`,
              role: "system",
              text: buildCostMessage(
                sessionInputTokens.value,
                sessionOutputTokens.value,
                settingsSnapshot.value
              )
            }
          ];
        }
      },
      {
        name: "compact",
        description: "Trim middle history to keep the agent focused",
        run: () => {
          bus.send({ type: "compact_history" });
        }
      },
      {
        name: "reindex",
        description: "Rebuild the semantic-search index for this workspace",
        run: () => {
          messages.value = messages.value.filter((m4) => m4.id !== "indexing_progress");
          messages.value = [
            ...messages.value,
            { id: "indexing_progress", role: "system", text: "Indexing... 0 / ?" }
          ];
          bus.send({ type: "reindex_codebase" });
        }
      },
      {
        name: "stop",
        description: "Stop the running agent",
        run: () => {
          if (isAgentRunning.value) handleCancel();
        }
      },
      // R2-E: /share — export the current session as Markdown via host save-dialog.
      {
        name: "share",
        description: "Export this chat as Markdown",
        run: () => {
          bus.send({ type: "share_session_request" });
        }
      },
      {
        name: "help",
        description: "Show keyboard shortcuts and tips",
        run: () => {
          messages.value = [
            ...messages.value,
            {
              id: `help_${Date.now()}`,
              role: "system",
              text: HELP_TEXT
            }
          ];
        }
      },
      // Custom commands loaded from `<workspace>/.oati/commands/*.md`. The host
      // owns the template; the webview just sends the typed input back so the
      // chat-panel can expand it and run the resulting prompt through the agent.
      ...customCommands.value.map((c4) => ({
        name: c4.name,
        description: c4.description,
        run: () => {
          bus.send({ type: "run_custom_command", name: c4.name, input: "" });
        }
      })),
      // R2-A: open the multi-file composer overlay. Trailing text after the
      // command name becomes the initial instruction.
      {
        name: "composer",
        description: "Open the multi-file composer (generate N files at once)",
        run: (rest) => {
          composerOpen.value = true;
          composerFiles.value = [];
          composerStatus.value = "idle";
          composerError.value = void 0;
          composerAppliedPaths.value = void 0;
          const initial = (rest ?? "").trim();
          composerInitialInstruction.value = initial;
          bus.send({ type: "open_composer" });
          if (initial.length > 0) {
            composerStatus.value = "running";
            bus.send({ type: "composer_submit", instruction: initial });
          }
        }
      },
      // R3-E: /from-issue <url> — kick off the issue → branch → PR scaffold workflow.
      {
        name: "from-issue",
        description: "Scaffold a branch and PR from a GitHub issue URL",
        run: (rest) => {
          const url = (rest ?? "").trim();
          if (url.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `from_issue_help_${Date.now()}`,
                role: "system",
                text: "Usage: /from-issue https://github.com/owner/repo/issues/123"
              }
            ];
            return;
          }
          bus.send({ type: "start_from_issue", url });
        }
      },
      // R3-D: side-by-side compare. `/compare <prompt>` opens the modal
      // with the first two configured providers' default models.
      {
        name: "compare",
        description: "Run side-by-side with two providers/models",
        run: (rest) => {
          const instruction = (rest ?? "").trim();
          if (instruction.length === 0) {
            errorBanner.value = "Usage: /compare <prompt> \u2014 runs the prompt against two providers in parallel.";
            return;
          }
          openCompareFromComposer(instruction);
        }
      },
      // R3-C: PR review — `/review-pr <github-pr-url>` kicks off a one-shot
      // review run streamed back as a normal chat turn, bracketed by a status
      // banner above the messages.
      {
        name: "review-pr",
        description: "Review a GitHub PR (paste the PR URL)",
        run: (rest) => {
          const url = (rest ?? "").trim();
          if (url.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `pr_help_${Date.now()}`,
                role: "system",
                text: "Usage: `/review-pr <github-pr-url>` \u2014 e.g. `/review-pr https://github.com/owner/repo/pull/123`."
              }
            ];
            return;
          }
          messages.value = [
            ...messages.value,
            {
              id: `pr_kick_${Date.now()}`,
              role: "user",
              text: `/review-pr ${url}`
            }
          ];
          isAgentRunning.value = true;
          resetAgentStatus();
          bus.send({ type: "review_pr_request", url });
        }
      },
      // R4-D: /marketplace — open the MCP server marketplace overlay and
      // request a fresh state snapshot from the host.
      {
        name: "marketplace",
        description: "Browse curated MCP servers and install them",
        run: () => {
          marketplaceOpen.value = true;
          bus.send({ type: "marketplace_list_request" });
        }
      },
      // R4-E: performance HUD — open the modal and request a fresh snapshot.
      // The PerfPanel auto-refreshes once on mount; this just opens it.
      {
        name: "perf",
        description: "Show performance HUD (recent turns + slow-tool heatmap)",
        run: () => {
          perfPanelOpen.value = true;
          bus.send({ type: "perf_request" });
        }
      },
      // Toggle the inline `↓Nk ↑M (in 4.2s)` badge under each assistant
      // reply. Off by default so the chat reads as a clean trace; power
      // users can flip it on with `/tokens` and the setting persists in
      // localStorage so it survives a reload.
      {
        name: "tokens",
        description: "Toggle inline token + duration badges on assistant replies",
        run: () => {
          const next = !showTokenUsage.value;
          showTokenUsage.value = next;
          try {
            localStorage.setItem(SHOW_TOKEN_USAGE_KEY, next ? "1" : "0");
          } catch {
          }
          messages.value = [
            ...messages.value,
            {
              id: `tokens_${Date.now()}`,
              role: "system",
              text: `Token + duration badges are now **${next ? "ON" : "OFF"}**.`
            }
          ];
        }
      },
      // Toggle the inline Stop button that sits next to the streaming
      // cursor on a still-generating assistant bubble. Off by default
      // because the composer area also exposes a cancel control while
      // the model is generating; keeping both visible cluttered the
      // trace. Persisted in localStorage.
      {
        name: "stop-button",
        description: "Toggle the inline Stop button on streaming assistant bubbles",
        run: () => {
          const next = !showStopButton.value;
          showStopButton.value = next;
          try {
            localStorage.setItem(SHOW_STOP_BUTTON_KEY, next ? "1" : "0");
          } catch {
          }
          messages.value = [
            ...messages.value,
            {
              id: `stopbtn_${Date.now()}`,
              role: "system",
              text: `Inline Stop button is now **${next ? "ON" : "OFF"}**.`
            }
          ];
        }
      },
      // R4-C: snippet library — `/save <name>` captures the previous
      // assistant message (or the current composer text when there is no
      // assistant reply yet) into `.oati/snippets/<name>.md`.
      {
        name: "save",
        description: "Save the previous assistant message as a snippet (.oati/snippets/<name>.md)",
        run: (rest) => {
          const name = (rest ?? "").trim().split(/\s+/)[0] ?? "";
          if (name.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `save_help_${Date.now()}`,
                role: "system",
                text: "Usage: `/save <name>` \u2014 slug must be letters, digits, underscore, or dash."
              }
            ];
            return;
          }
          const list2 = messages.value;
          let body = "";
          for (let i5 = list2.length - 1; i5 >= 0; i5--) {
            const m4 = list2[i5];
            if (m4.role === "assistant" && m4.text.trim().length > 0) {
              body = m4.text;
              break;
            }
          }
          if (body.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `save_help_${Date.now()}`,
                role: "system",
                text: "No assistant message yet \u2014 type the snippet text into the input and submit `/save <name>` again, or send a turn first."
              }
            ];
            return;
          }
          pendingSnippetSaveName.value = name;
          bus.send({ type: "save_snippet_request", name, body });
        }
      },
      // R4-C: `/snippets` — fetch and display the catalog inline as a
      // system message. Each entry surfaces as `@snip:<name>` for quick
      // insertion via the existing mention pipeline.
      {
        name: "snippets",
        description: "List saved snippets (.oati/snippets/*.md)",
        run: () => {
          bus.send({ type: "list_snippets_request" });
        }
      },
      // R4-C: `/init <template>` — apply a built-in project template under
      // the workspace root. Empty input opens a picker (shows the catalog).
      {
        name: "init",
        description: "Initialize a built-in project template (e.g. /init react-ts)",
        run: (rest) => {
          const name = (rest ?? "").trim().split(/\s+/)[0] ?? "";
          if (name.length === 0) {
            bus.send({ type: "list_templates_request" });
            return;
          }
          bus.send({ type: "apply_template_request", name });
        }
      },
      // R5-B: `/knowledge` — request the host's snapshot of indexed
      // knowledge docs and surface it inline. The host replies with a
      // `knowledge_state` event carrying `entries`, which the handler
      // above renders as a system message.
      {
        name: "knowledge",
        description: "List indexed knowledge docs (.oati/knowledge/**/*.md)",
        run: () => {
          bus.send({ type: "knowledge_list_request" });
        }
      },
      // R5-C: /search <query> — semantic search across every past session.
      {
        name: "search",
        description: "Search past chat sessions semantically (e.g. /search auth flow)",
        run: (rest) => {
          const query = (rest ?? "").trim();
          if (query.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `search_help_${Date.now()}`,
                role: "system",
                text: "Usage: `/search <query>` \u2014 e.g. `/search how did we configure auth?`."
              }
            ];
            return;
          }
          bus.send({ type: "search_conversations_request", query });
        }
      },
      // R3-C: diagram — frontend variant. Instead of calling render_diagram
      // directly, ask the agent for mermaid source and then render the reply.
      // The webview parses the next assistant turn for a mermaid block; if no
      // fenced block is found it falls back to using the whole reply as the
      // source.
      {
        name: "diagram",
        description: "Generate and render a Mermaid diagram (e.g. /diagram auth flow)",
        run: (rest) => {
          const prompt = (rest ?? "").trim();
          if (prompt.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `diag_help_${Date.now()}`,
                role: "system",
                text: "Usage: `/diagram <what to draw>` \u2014 e.g. `/diagram sequence of auth handshake`."
              }
            ];
            return;
          }
          const instruction = [
            `Generate a mermaid diagram for: ${prompt}.`,
            "Reply with just the mermaid source (no prose, no markdown fence)."
          ].join(" ");
          const userText = `/diagram ${prompt}`;
          messages.value = [...messages.value, { id: `u_${Date.now()}`, role: "user", text: userText }];
          pendingDiagramTitle.value = prompt;
          isAgentRunning.value = true;
          resetAgentStatus();
          bus.send({ type: "user_message", content: instruction });
        }
      },
      // R5-D: /persona <id> — switch the active persona; empty input clears it.
      {
        name: "persona",
        description: "Switch the active agent persona (empty = clear)",
        run: (rest) => {
          const raw = (rest ?? "").trim();
          if (raw.length === 0) {
            bus.send({ type: "set_persona", personaId: null });
            return;
          }
          const id = raw.split(/\s+/)[0];
          const known = personas.value.find((p5) => p5.id === id);
          if (!known) {
            messages.value = [
              ...messages.value,
              {
                id: `persona_help_${Date.now()}`,
                role: "system",
                text: `Unknown persona \`${id}\`. Run \`/personas\` to see the catalog.`
              }
            ];
            return;
          }
          bus.send({ type: "set_persona", personaId: id });
        }
      },
      // R5-D: /personas — list the built-in persona catalog inline.
      {
        name: "personas",
        description: "List available agent personas",
        run: () => {
          const items = personas.value;
          const body = items.length === 0 ? "No personas available. (The catalog is bundled \u2014 this usually means the host hasn't sent `personas_list` yet.)" : `**Available personas** \u2014 use \`/persona <id>\` to switch.
${items.map(
            (p5) => `- \`${p5.id}\`${p5.id === activePersonaId.value ? " (active)" : ""} \u2014 ${p5.displayName}: ${p5.description}`
          ).join("\n")}`;
          messages.value = [
            ...messages.value,
            { id: `personas_list_${Date.now()}`, role: "system", text: body }
          ];
        }
      },
      // R5-D: /recipe <name> — sequence a saved workflow's steps.
      {
        name: "recipe",
        description: "Run a saved recipe (multi-step workflow)",
        run: (rest) => {
          const name = (rest ?? "").trim().split(/\s+/)[0] ?? "";
          if (name.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `recipe_help_${Date.now()}`,
                role: "system",
                text: "Usage: `/recipe <name>` \u2014 run `/recipes` to see what's available."
              }
            ];
            return;
          }
          messages.value = [
            ...messages.value,
            {
              id: `recipe_kick_${Date.now()}`,
              role: "user",
              text: `/recipe ${name}`
            }
          ];
          isAgentRunning.value = true;
          resetAgentStatus();
          bus.send({ type: "run_recipe", name });
        }
      },
      // R5-D: /recipes — list catalog under .oati/recipes/*.md.
      {
        name: "recipes",
        description: "List saved recipes (.oati/recipes/*.md)",
        run: () => {
          bus.send({ type: "list_recipes_request" });
        }
      },
      // R6-D: /diff — open the multi-file diff overlay against the most recent
      // composer state. Falls back to a friendly system message when no
      // composer files are available.
      {
        name: "diff",
        description: "Open the multi-file diff overlay (review the latest composer state)",
        run: () => {
          const files = composerFiles.value.map((f5) => ({
            path: f5.path,
            before: f5.before,
            after: f5.after
          }));
          if (files.length === 0) {
            messages.value = [
              ...messages.value,
              {
                id: `diff_help_${Date.now()}`,
                role: "system",
                text: "No composer files to review yet \u2014 run `/composer <task>` first, then `/diff`."
              }
            ];
            return;
          }
          multiFileDiffFiles.value = files;
          multiFileDiffOpen.value = true;
        }
      },
      // Session checkpoints — /checkpoint [label], /restore, /restore <id>
      {
        name: "checkpoint",
        description: "Snapshot the current conversation as a restorable checkpoint",
        run: (rest) => {
          const label = (rest ?? "").trim();
          bus.send({ type: "checkpoint_create", ...label ? { label } : {} });
          messages.value = [
            ...messages.value,
            {
              id: `sys_cp_${Date.now()}`,
              role: "system",
              text: label ? `Checkpoint created: **${label}**.` : "Checkpoint created."
            }
          ];
        }
      },
      {
        name: "restore",
        description: "List checkpoints \u2014 or /restore <id> to roll back",
        run: (rest) => {
          const id = (rest ?? "").trim();
          if (id.length > 0) {
            bus.send({ type: "checkpoint_restore", id });
            return;
          }
          bus.send({ type: "checkpoint_list_request" });
          const list2 = checkpointsList.value;
          const body = list2.length === 0 ? "No checkpoints yet. Use `/checkpoint` to create one." : [
            "Checkpoints (most-recent first):",
            "",
            ...list2.map(
              (c4) => `- **${c4.id}** \u2014 ${c4.label} (${c4.createdAt.slice(0, 19).replace("T", " ")}, ${c4.fileCount} turns)`
            ),
            "",
            "Run `/restore <id>` to roll the session back."
          ].join("\n");
          messages.value = [
            ...messages.value,
            { id: `sys_cps_${Date.now()}`, role: "system", text: body }
          ];
        }
      },
      // /test-fix — run the test-driven loop manually (auto-modes do this
      // automatically). Sends a follow-up user turn that nudges the agent.
      {
        name: "test-fix",
        description: "Run tests and have the agent iterate on failures until they pass",
        run: () => {
          const instruction = [
            "Run the project's tests. If any fail, investigate the root cause and",
            "propose / apply targeted fixes, then re-run the tests. Iterate until",
            "either all tests pass or you genuinely cannot make further progress.",
            "Use the `run_tests` tool, `get_diagnostics`, and `read_file` as needed."
          ].join(" ");
          messages.value = [
            ...messages.value,
            { id: `u_${Date.now()}`, role: "user", text: "/test-fix" }
          ];
          isAgentRunning.value = true;
          resetAgentStatus();
          bus.send({ type: "user_message", content: instruction });
        }
      },
      // /export — dump the session as markdown into .oati/exports/. PDF
      // hands off to the bundled pdf-creation skill.
      {
        name: "export",
        description: "Export this conversation to .oati/exports/ (markdown by default)",
        run: (rest) => {
          const fmt = (rest ?? "").trim().toLowerCase();
          const format = fmt === "pdf" ? "pdf" : "markdown";
          bus.send({ type: "export_conversation", format });
        }
      },
      // /supervise — manually trigger a supervisor pass right now (the
      // background scheduler runs it automatically every N seconds when
      // `oati.supervisor.enabled` is on).
      {
        name: "supervise",
        description: "Run the background supervisor agent now (review recent edits)",
        run: () => {
          bus.send({ type: "supervisor_run_now" });
          messages.value = [
            ...messages.value,
            {
              id: `sys_sup_${Date.now()}`,
              role: "system",
              text: "\u{1F50D} Supervisor pass kicked off \u2014 suggestions will appear in the panel below the chat. Enable / disable via `oati.supervisor.enabled` in VS Code settings or the OATI Settings panel."
            }
          ];
        }
      },
      // /inline — quick toggle + keybinding crib sheet for the inline
      // ghost-text completion provider. The actual settings live in VS
      // Code's workspace config under `oati.inlineCompletion.*`.
      {
        name: "inline",
        description: "Toggle inline ghost-text completion (Tab to accept) and show keybindings",
        run: () => {
          bus.send({ type: "run_vscode_command", command: "oati.toggleInlineCompletion" });
          messages.value = [
            ...messages.value,
            {
              id: `sys_inline_${Date.now()}`,
              role: "system",
              text: [
                "**Inline completion** \u2014 Cursor-style ghost text driven by the active model.",
                "",
                "**Keybindings**",
                "- `Tab` \u2014 accept full suggestion",
                "- `Esc` \u2014 dismiss",
                "- `Ctrl/Cmd + \u2192` \u2014 accept next word only",
                "- `Alt + ]` / `Alt + [` \u2014 cycle alternative suggestions",
                "",
                "Run `/inline` again to flip the global enabled flag.",
                "Tweak languages, debounce, multi-line via `oati.inlineCompletion.*` in VS Code settings."
              ].join("\n")
            }
          ];
        }
      }
    ];
    return /* @__PURE__ */ u3("div", { class: "oati-root", children: [
      /* @__PURE__ */ u3("header", { class: "oati-header oati-header-pills-only", children: /* @__PURE__ */ u3("div", { class: "oati-header-actions", children: [
        view.value === "chat" && workspaceInfo.value && /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-project-chip",
            title: workspaceInfo.value.isMultiRoot ? `Active project (1 of ${workspaceInfo.value.folderCount} folders): ${workspaceInfo.value.path}
Click to copy path` : `${workspaceInfo.value.path}
Click to copy path`,
            onClick: () => {
              const p5 = workspaceInfo.value?.path;
              if (!p5) return;
              void navigator.clipboard?.writeText(p5).catch(() => void 0);
            },
            children: [
              /* @__PURE__ */ u3("span", { class: "oati-project-chip-icon", "aria-hidden": "true", children: "\u{1F4C1}" }),
              /* @__PURE__ */ u3("span", { class: "oati-project-chip-name", children: workspaceInfo.value.name }),
              workspaceInfo.value.isMultiRoot && /* @__PURE__ */ u3("span", { class: "oati-project-chip-multi", title: "Multi-root workspace", children: [
                "+",
                workspaceInfo.value.folderCount - 1
              ] })
            ]
          }
        ),
        view.value === "chat" && (diagnosticsCount.value.errors > 0 || diagnosticsCount.value.warnings > 0) && /* @__PURE__ */ u3(
          "span",
          {
            class: "oati-diagnostics-pill",
            title: `${diagnosticsCount.value.errors} error(s), ${diagnosticsCount.value.warnings} warning(s) in the workspace`,
            "aria-label": `${diagnosticsCount.value.errors} errors and ${diagnosticsCount.value.warnings} warnings`,
            children: [
              diagnosticsCount.value.errors > 0 && /* @__PURE__ */ u3("span", { class: "oati-diagnostics-pill-errors", children: [
                "\u2717",
                " ",
                diagnosticsCount.value.errors
              ] }),
              diagnosticsCount.value.errors > 0 && diagnosticsCount.value.warnings > 0 && /* @__PURE__ */ u3("span", { class: "oati-diagnostics-pill-sep", children: " \xB7 " }),
              diagnosticsCount.value.warnings > 0 && /* @__PURE__ */ u3("span", { class: "oati-diagnostics-pill-warnings", children: [
                "\u26A0",
                " ",
                diagnosticsCount.value.warnings
              ] })
            ]
          }
        ),
        view.value === "chat" && knowledgeState.value.docs > 0 && /* @__PURE__ */ u3(
          "span",
          {
            class: "oati-knowledge-pill",
            title: `${knowledgeState.value.docs} knowledge doc(s) indexed under .oati/knowledge/`,
            "aria-label": `${knowledgeState.value.docs} knowledge docs`,
            children: [
              "\u{1F4DA}",
              " ",
              knowledgeState.value.docs
            ]
          }
        ),
        view.value === "chat" && knowledgeState.value.rulesActive && /* @__PURE__ */ u3(
          "span",
          {
            class: "oati-rules-pill",
            title: ".oati/rules.md is active for every turn",
            "aria-label": "Project rules active",
            children: "\u{1F4DC} rules"
          }
        ),
        showTokenUsage.value && view.value === "chat" && (sessionInputTokens.value > 0 || sessionOutputTokens.value > 0) && /* @__PURE__ */ u3(
          TokenBadge,
          {
            inputTokens: sessionInputTokens.value,
            outputTokens: sessionOutputTokens.value,
            snapshot: settingsSnapshot.value
          }
        ),
        view.value === "chat" && activePersonaId.value && /* @__PURE__ */ u3(
          "span",
          {
            class: "oati-persona-chip",
            title: `Active persona: ${activePersonaId.value}. Use /persona to switch or clear.`,
            children: personas.value.find((p5) => p5.id === activePersonaId.value)?.displayName ?? activePersonaId.value
          }
        ),
        view.value === "chat" && offlineMode.value.offline && /* @__PURE__ */ u3(
          "span",
          {
            class: "oati-offline-pill",
            title: `All configured providers are local: ${offlineMode.value.localProviders.join(", ") || "(none)"}`,
            "aria-label": "Offline mode \u2014 no network egress",
            children: [
              "\u{1F512}",
              " Offline"
            ]
          }
        ),
        view.value === "chat" && embedderState.value && /* @__PURE__ */ u3(
          "span",
          {
            class: embedderState.value.reindexRequired ? "oati-embedder-pill oati-embedder-pill--stale" : "oati-embedder-pill",
            title: embedderState.value.reindexRequired ? `Embedder changed (${embedderState.value.displayName}); reindex required for the new vector space.` : `Codebase embedder: ${embedderState.value.displayName}. ${embedderState.value.chunks} chunks across ${embedderState.value.files} files.`,
            "aria-label": `Codebase embedder ${embedderState.value.id} ${embedderState.value.dimensions}`,
            children: [
              "\u{1F4E6}",
              " ",
              embedderState.value.id,
              ":",
              embedderState.value.dimensions
            ]
          }
        ),
        view.value === "chat" && debugSession.value.active && /* @__PURE__ */ u3(
          "span",
          {
            class: "oati-debug-pill",
            title: debugSession.value.stoppedThreadId !== void 0 ? `Debug session paused (thread ${debugSession.value.stoppedThreadId})` : `Debug session active${debugSession.value.sessionName ? `: ${debugSession.value.sessionName}` : ""}`,
            "aria-label": "Debug session active",
            children: [
              "\u{1F41E}",
              " Debugging",
              debugSession.value.sessionType ? ` (${debugSession.value.sessionType})` : ""
            ]
          }
        )
      ] }) }),
      errorBanner.value && /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          class: "oati-error",
          onClick: () => {
            errorBanner.value = null;
          },
          children: errorBanner.value
        }
      ),
      composerOpen.value && /* @__PURE__ */ u3(
        ComposerPanel,
        {
          files: composerFiles.value,
          status: composerStatus.value,
          errorMessage: composerError.value,
          appliedPaths: composerAppliedPaths.value,
          initialInstruction: composerInitialInstruction.value,
          onSubmit: (instruction) => {
            composerStatus.value = "running";
            composerError.value = void 0;
            composerFiles.value = [];
            composerAppliedPaths.value = void 0;
            composerInitialInstruction.value = instruction;
            bus.send({ type: "composer_submit", instruction });
          },
          onAcceptFile: (path) => {
            composerFiles.value = composerFiles.value.map(
              (f5) => f5.path === path ? { ...f5, state: "accepted" } : f5
            );
            bus.send({ type: "composer_accept_file", path });
          },
          onRejectFile: (path) => {
            composerFiles.value = composerFiles.value.map(
              (f5) => f5.path === path ? { ...f5, state: "rejected" } : f5
            );
            bus.send({ type: "composer_reject_file", path });
          },
          onAcceptAll: () => {
            composerFiles.value = composerFiles.value.map(
              (f5) => f5.state === "rejected" ? f5 : { ...f5, state: "accepted" }
            );
            bus.send({ type: "composer_accept_all" });
          },
          onDiscard: () => {
            bus.send({ type: "composer_discard" });
            composerOpen.value = false;
            composerFiles.value = [];
            composerStatus.value = "idle";
            composerError.value = void 0;
            composerAppliedPaths.value = void 0;
            composerInitialInstruction.value = "";
          },
          onClose: () => {
            bus.send({ type: "composer_discard" });
            composerOpen.value = false;
          }
        }
      ),
      multiFileDiffOpen.value && /* @__PURE__ */ u3(
        MultiFileDiff,
        {
          files: multiFileDiffFiles.value,
          onClose: () => {
            multiFileDiffOpen.value = false;
          }
        }
      ),
      view.value === "settings" ? settingsSnapshot.value ? /* @__PURE__ */ u3(
        SettingsPanel,
        {
          snapshot: settingsSnapshot.value,
          testResult: connectionTestResult.value,
          onSave: handleSettingsSave,
          onDone: handleSettingsDone,
          onTestConnection: handleTestConnection,
          bus
        }
      ) : /* @__PURE__ */ u3("div", { class: "oati-empty", children: "Loading settings..." }) : /* @__PURE__ */ u3(S, { children: [
        shouldShowWelcome(messages.value, settingsSnapshot.value) ? /* @__PURE__ */ u3(
          Welcome,
          {
            snapshot: settingsSnapshot.value,
            onOpenSettings: openSettings,
            onSave: handleSettingsSave
          }
        ) : /* @__PURE__ */ u3(S, { children: [
          forkInfo.value && /* @__PURE__ */ u3("output", { class: "oati-fork-banner", children: [
            /* @__PURE__ */ u3("span", { class: "oati-fork-icon", children: "\u2442" }),
            /* @__PURE__ */ u3("span", { class: "oati-fork-text", children: [
              "Forked from",
              " ",
              /* @__PURE__ */ u3("strong", { children: forkInfo.value.parentTitle ?? forkInfo.value.parentSessionId }),
              " at message",
              " ",
              /* @__PURE__ */ u3("code", { children: forkInfo.value.forkedAtMessageId })
            ] })
          ] }),
          pinnedMessageIds.value.length > 0 && /* @__PURE__ */ u3(
            PinnedRail,
            {
              messages: messages.value,
              pinnedIds: pinnedMessageIds.value,
              onJump: handleJumpToPinned,
              onUnpin: (id) => handleTogglePin(id, false)
            }
          ),
          /* @__PURE__ */ u3(TodoListPanel, { items: todos.value }),
          proposedPlan.value && /* @__PURE__ */ u3(
            PlanProposalBanner,
            {
              plan: proposedPlan.value,
              onExecute: (p5) => {
                bus.send({ type: "execute_plan", plan: p5 });
                proposedPlan.value = null;
              },
              onDismiss: () => {
                proposedPlan.value = null;
              }
            }
          ),
          backgroundTasksTray.value.length > 0 && /* @__PURE__ */ u3(
            BackgroundTaskTray,
            {
              tasks: backgroundTasksTray.value,
              onCancel: (id) => bus.send({ type: "background_task_cancel", id })
            }
          ),
          /* @__PURE__ */ u3(
            SupervisorPanel,
            {
              items: supervisorItems.value,
              onDismiss: (id) => bus.send({ type: "supervisor_dismiss", id }),
              onClear: () => bus.send({ type: "supervisor_clear" }),
              onRunNow: () => bus.send({ type: "supervisor_run_now" }),
              onOpenPath: (p5, line) => handleOpenPath(line ? `${p5}:${line}` : p5)
            }
          ),
          messages.value.length === 0 ? /* @__PURE__ */ u3("div", { class: "oati-empty-session", children: [
            /* @__PURE__ */ u3("div", { class: "oati-empty-session-icon", "aria-hidden": "true", children: "\u2726" }),
            /* @__PURE__ */ u3("div", { class: "oati-empty-session-text", children: "What would you like to work on? Ask about this codebase or describe what you want to build." })
          ] }) : /* @__PURE__ */ u3(
            MessageList,
            {
              messages: messages.value,
              onOpenPath: handleOpenPath,
              onRegenerateFrom: handleRegenerateFrom,
              onCancel: isAgentRunning.value ? handleCancel : void 0,
              onForkFrom: handleForkFrom,
              onTogglePin: handleTogglePin,
              jumpToMessageId: jumpToMessageId.value,
              showTokenUsage: showTokenUsage.value,
              showStopButton: showStopButton.value
            }
          )
        ] }),
        pendingApproval.value && /* @__PURE__ */ u3(
          ApprovalDialog,
          {
            request: pendingApproval.value,
            onApprove: () => handleApproval(true),
            onDeny: () => handleApproval(false)
          }
        ),
        pendingSecretWarning.value && /* @__PURE__ */ u3("div", { class: "secret-warning-banner", role: "alertdialog", children: [
          /* @__PURE__ */ u3("div", { class: "secret-warning-title", children: [
            "\u26A0 ",
            pendingSecretWarning.value.matches.length,
            " potential secret",
            pendingSecretWarning.value.matches.length === 1 ? "" : "s",
            " detected:",
            " ",
            pendingSecretWarning.value.summary
          ] }),
          /* @__PURE__ */ u3("div", { class: "secret-warning-actions", children: [
            /* @__PURE__ */ u3("button", { type: "button", onClick: () => handleSecretChoice("send"), children: "Send anyway" }),
            /* @__PURE__ */ u3("button", { type: "button", class: "primary", onClick: () => handleSecretChoice("redact"), children: "Redact and send" }),
            /* @__PURE__ */ u3("button", { type: "button", onClick: () => handleSecretChoice("cancel"), children: "Cancel" })
          ] })
        ] }),
        prReviewBanner.value && /* @__PURE__ */ u3("output", { class: `oati-pr-review-banner oati-pr-review-${prReviewBanner.value.status}`, children: [
          /* @__PURE__ */ u3("div", { class: "oati-pr-review-text", children: [
            prReviewBanner.value.status === "running" ? "Reviewing" : "Review",
            " ",
            prReviewBanner.value.owner && prReviewBanner.value.repo ? `${prReviewBanner.value.owner}/${prReviewBanner.value.repo}#${prReviewBanner.value.number ?? ""}` : prReviewBanner.value.url,
            prReviewBanner.value.status !== "running" ? ` \u2014 ${prReviewBanner.value.status}` : "\u2026",
            prReviewBanner.value.message ? `: ${prReviewBanner.value.message}` : ""
          ] }),
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-pr-review-close",
              onClick: () => {
                prReviewBanner.value = null;
              },
              "aria-label": "Dismiss PR review status",
              children: "\xD7"
            }
          )
        ] }),
        diagrams.value.length > 0 && /* @__PURE__ */ u3("div", { class: "oati-diagrams-stack", children: diagrams.value.map((d5) => /* @__PURE__ */ u3("div", { class: "oati-diagram-wrapper", children: [
          /* @__PURE__ */ u3(DiagramRenderer, { id: d5.id, mermaid: d5.mermaid, title: d5.title }),
          /* @__PURE__ */ u3(
            "button",
            {
              type: "button",
              class: "oati-diagram-close",
              onClick: () => {
                diagrams.value = diagrams.value.filter((x3) => x3.id !== d5.id);
              },
              "aria-label": "Remove diagram",
              children: "\xD7"
            }
          )
        ] }, d5.id)) }),
        /* @__PURE__ */ u3(ProgressIndicator, { running: isAgentRunning.value, status: agentStatus.value }),
        attachedSelection.value && /* @__PURE__ */ u3(
          AttachedSelectionBanner,
          {
            selection: attachedSelection.value,
            onRemove: () => {
              attachedSelection.value = null;
            }
          }
        ),
        routeBadge.value && /* @__PURE__ */ u3(RouteBadgeBanner, { badge: routeBadge.value }),
        /* @__PURE__ */ u3(
          Input,
          {
            disabled: isAgentRunning.value || !!pendingApproval.value,
            onSend: handleSend,
            onCancel: isAgentRunning.value ? handleCancel : void 0,
            onPickAttachment: handlePickAttachment,
            attachments: attachments.value,
            onRemoveAttachment: handleRemoveAttachment,
            onAddImageAttachment: handleAddImageAttachment,
            slashCommands,
            workspaceFiles: workspaceFiles.value,
            contextMentions: contextProviderMentions.value,
            promptHistory: promptHistory.value,
            modes: modes.value,
            activeMode: activeMode.value,
            onModeChange: handleModeChange,
            ...resolveActiveModelId(settingsSnapshot.value) ? { activeModel: resolveActiveModelId(settingsSnapshot.value) } : {},
            injectionVersion: composerInjectionVersion.value,
            injectedText: composerInjectedText.value,
            decorateOutgoing: (text) => {
              const sel = attachedSelection.value;
              if (!sel) return text;
              attachedSelection.value = null;
              return `${formatAttachedSelection(sel)}

${text}`;
            }
          }
        )
      ] }),
      !onboardingCompleted.value && /* @__PURE__ */ u3(
        OnboardingTour,
        {
          onDismiss: () => {
            markOnboardingCompleted();
            onboardingCompleted.value = true;
            bus.send({ type: "onboarding_dismissed" });
          }
        }
      ),
      compareSession.value && /* @__PURE__ */ u3(
        CompareView,
        {
          instruction: compareSession.value.instruction,
          left: compareSession.value.left,
          right: compareSession.value.right,
          leftState: compareLeftState.value,
          rightState: compareRightState.value,
          onClose: closeCompare
        }
      ),
      marketplaceOpen.value && /* @__PURE__ */ u3(
        MarketplaceView,
        {
          items: marketplaceItems.value,
          onInstall: (id) => bus.send({ type: "marketplace_install", id }),
          onUninstall: (id) => bus.send({ type: "marketplace_uninstall", id }),
          onToggle: (id, enabled) => bus.send({ type: "marketplace_toggle", id, enabled }),
          onClose: () => {
            marketplaceOpen.value = false;
          }
        }
      ),
      perfPanelOpen.value && /* @__PURE__ */ u3(
        PerfPanel,
        {
          snapshot: perfSnapshot.value,
          onRefresh: () => bus.send({ type: "perf_request" }),
          onClose: () => {
            perfPanelOpen.value = false;
          }
        }
      ),
      planPanelOpen.value && currentPlan.value && /* @__PURE__ */ u3(
        PlanEditor,
        {
          plan: currentPlan.value,
          onChange: (plan) => {
            currentPlan.value = plan;
            bus.send({ type: "plan_edit", plan });
          },
          onExecute: (planId) => {
            bus.send({ type: "plan_execute", planId });
          },
          onCancel: (planId) => {
            bus.send({ type: "plan_cancel", planId });
          },
          onSaveAsRecipe: (plan) => {
            const body = [
              `Goal: ${plan.goal}`,
              "",
              ...plan.steps.map((s5, i5) => `${i5 + 1}. ${s5.title}
   ${s5.body}`)
            ].join("\n");
            const name = `plan_${plan.id}`;
            bus.send({
              type: "save_snippet_request",
              name,
              body,
              description: `Saved plan: ${plan.goal.slice(0, 60)}`
            });
          },
          onClose: () => {
            planPanelOpen.value = false;
          }
        }
      )
    ] });
  }
  function PinnedRail({
    messages: messages2,
    pinnedIds,
    onJump,
    onUnpin
  }) {
    const idSet = new Set(pinnedIds);
    const pinned = messages2.filter((m4) => idSet.has(m4.id));
    if (pinned.length === 0) return null;
    return /* @__PURE__ */ u3("section", { class: "oati-pinned-rail", "aria-label": "Pinned messages", children: [
      /* @__PURE__ */ u3("span", { class: "oati-pinned-rail-label", children: "\u{1F4CC} Pinned" }),
      /* @__PURE__ */ u3("div", { class: "oati-pinned-rail-items", children: pinned.map((m4) => /* @__PURE__ */ u3("div", { class: "oati-pinned-rail-item", children: [
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-pinned-rail-jump",
            title: "Jump to message",
            onClick: () => onJump(m4.id),
            children: [
              /* @__PURE__ */ u3("span", { class: "oati-pinned-rail-role", children: m4.role }),
              /* @__PURE__ */ u3("span", { class: "oati-pinned-rail-text", children: [
                m4.text.slice(0, 80),
                m4.text.length > 80 ? "\u2026" : ""
              ] })
            ]
          }
        ),
        /* @__PURE__ */ u3(
          "button",
          {
            type: "button",
            class: "oati-icon-btn oati-icon-btn-sm",
            title: "Unpin",
            "aria-label": `Unpin message ${m4.id}`,
            onClick: () => onUnpin(m4.id),
            children: "\u2715"
          }
        )
      ] }, m4.id)) })
    ] });
  }
  var HELP_TEXT = [
    "**OATI Code keyboard & commands**",
    "",
    "- `Enter` \u2014 send message",
    "- `Shift+Enter` \u2014 newline",
    "- `\u2191` / `\u2193` \u2014 navigate previous prompts when the cursor is at the edge of the input",
    "- `/` at the start of input \u2014 slash commands",
    "- `@` anywhere \u2014 mention a workspace file",
    "",
    "**Slash commands**",
    "",
    "- `/new` \u2014 new chat tab",
    "- `/clear` \u2014 clear current chat",
    "- `/settings` \u2014 open settings",
    "- `/attach` \u2014 attach a file to the next message",
    "- `/stop` \u2014 stop the running agent",
    "- `/help` \u2014 show this help",
    "",
    "Open the **OATI Code** icon in the Activity Bar (left edge) to browse all chats."
  ].join("\n");
  function shouldShowWelcome(messages2, snapshot) {
    if (messages2.length > 0) return false;
    if (!snapshot) return true;
    const active = snapshot.config.providers.find((p5) => p5.id === snapshot.config.activeProviderId);
    if (!active) return true;
    const modelMissing = !active.defaultModel || active.defaultModel.trim().length === 0;
    return modelMissing;
  }
  function stripAttachmentPrefix(text) {
    const idx = text.search(/\n\n(?!Attached file:)/);
    if (text.startsWith("Attached file:") && idx > 0) {
      return text.slice(idx + 2).trim();
    }
    return text.trim();
  }
  function handleAgentEvent(ev) {
    if (ev.type === "text_delta") {
      const list2 = messages.value;
      const last = list2[list2.length - 1];
      if (last && last.role === "assistant" && last.pending) {
        messages.value = [...list2.slice(0, -1), { ...last, text: last.text + ev.text }];
      } else {
        messages.value = [
          ...list2,
          { id: `a_${Date.now()}`, role: "assistant", text: ev.text, pending: true }
        ];
      }
    } else if (ev.type === "tool_call") {
      agentStatus.value = {
        ...agentStatus.value,
        currentTool: ev.call.name,
        currentToolArgs: ev.call.args
      };
      const card = {
        callId: ev.call.id,
        name: ev.call.name,
        args: ev.call.args,
        summary: summarizeToolArgs(ev.call.name, ev.call.args),
        path: pickPathFromArgs(ev.call.args)
      };
      const prev = messages.value;
      const lastIdx = prev.length - 1;
      const base = lastIdx >= 0 && prev[lastIdx].role === "assistant" && prev[lastIdx].pending ? [...prev.slice(0, lastIdx), { ...prev[lastIdx], pending: false }] : prev;
      messages.value = [
        ...base,
        {
          id: `t_${ev.call.id}`,
          role: "tool",
          text: `\u2192 ${ev.call.name}(${truncate2(JSON.stringify(ev.call.args), 200)})`,
          toolCard: card
        }
      ];
    } else if (ev.type === "tool_progress") {
      const list2 = messages.value;
      const idx = list2.findIndex(
        (m4) => m4.toolCard && m4.toolCard.callId === ev.callId && !m4.toolCard.result
      );
      if (idx < 0) return;
      const existing = list2[idx];
      const card = existing.toolCard;
      const prev = card.streamingOutput ?? "";
      const room = STREAMING_OUTPUT_CAP - prev.length;
      if (room <= 0) return;
      const appended = ev.chunk.length > room ? ev.chunk.slice(0, room) : ev.chunk;
      const next = {
        ...existing,
        toolCard: { ...card, streamingOutput: prev + appended }
      };
      messages.value = [...list2.slice(0, idx), next, ...list2.slice(idx + 1)];
    } else if (ev.type === "tool_result") {
      const out = ev.result.output;
      const preview = typeof out === "string" ? out : JSON.stringify(out);
      agentStatus.value = {
        ...agentStatus.value,
        currentTool: void 0,
        currentToolArgs: void 0
      };
      const list2 = messages.value;
      const idx = list2.findIndex(
        (m4) => m4.toolCard && m4.toolCard.callId === ev.result.id && !m4.toolCard.result
      );
      if (idx >= 0) {
        const existing = list2[idx];
        const card = existing.toolCard;
        const { streamingOutput: _drop, ...rest } = card;
        const next = {
          ...existing,
          text: `${ev.result.isError ? "\u2717" : "\u2713"} ${truncate2(preview, 500)}`,
          toolCard: { ...rest, result: { isError: ev.result.isError, output: ev.result.output } }
        };
        messages.value = [...list2.slice(0, idx), next, ...list2.slice(idx + 1)];
      } else {
        messages.value = [
          ...list2,
          {
            id: `r_${ev.result.id}`,
            role: "tool",
            text: `${ev.result.isError ? "\u2717" : "\u2713"} ${truncate2(preview, 500)}`,
            toolCard: {
              callId: ev.result.id,
              name: "(unknown tool)",
              args: void 0,
              result: { isError: ev.result.isError, output: ev.result.output }
            }
          }
        ];
      }
    } else if (ev.type === "usage") {
      sessionInputTokens.value += ev.inputTokens;
      sessionOutputTokens.value += ev.outputTokens;
      agentStatus.value = {
        ...agentStatus.value,
        inputTokens: agentStatus.value.inputTokens + ev.inputTokens,
        outputTokens: agentStatus.value.outputTokens + ev.outputTokens
      };
      const list2 = messages.value;
      for (let i5 = list2.length - 1; i5 >= 0; i5--) {
        const m4 = list2[i5];
        if (m4.role !== "assistant") continue;
        const prev = m4.tokens ?? { input: 0, output: 0 };
        messages.value = [
          ...list2.slice(0, i5),
          {
            ...m4,
            tokens: {
              input: prev.input + ev.inputTokens,
              output: prev.output + ev.outputTokens
            }
          },
          ...list2.slice(i5 + 1)
        ];
        break;
      }
    } else if (ev.type === "iteration") {
      agentStatus.value = { ...agentStatus.value, iteration: ev.n };
    } else if (ev.type === "stage_started") {
      agentStatus.value = { ...agentStatus.value, stage: ev.stage };
    } else if (ev.type === "stage_done") {
      if (agentStatus.value.stage === ev.stage) {
        agentStatus.value = { ...agentStatus.value, stage: void 0 };
      }
    } else if (ev.type === "plan") {
      proposedPlan.value = ev.plan;
      const lines = ["\u{1F4CB} **Plan from planner stage**", ""];
      if (ev.plan.steps.length === 0) {
        lines.push("_(planner returned no parseable steps)_");
      } else {
        for (const s5 of ev.plan.steps) {
          const tail = s5.rationale ? ` \u2014 _${s5.rationale}_` : "";
          lines.push(`${s5.n}. ${s5.description}${tail}`);
        }
      }
      messages.value = [
        ...messages.value,
        { id: `plan_${Date.now()}`, role: "system", text: lines.join("\n") }
      ];
    } else if (ev.type === "critique") {
    } else if (ev.type === "retry") {
      agentStatus.value = { ...agentStatus.value, retryAttempt: ev.attempt };
    } else if (ev.type === "done") {
      const startedAt = currentTurnStartedAt.value;
      const durationMs = startedAt !== void 0 ? Date.now() - startedAt : void 0;
      currentTurnStartedAt.value = void 0;
      const list2 = messages.value;
      let lastAssistantIdx = -1;
      const cleared = list2.map((m4, i5) => {
        if (m4.role === "assistant") {
          lastAssistantIdx = i5;
          if (m4.pending) return { ...m4, pending: false };
        }
        return m4;
      });
      if (durationMs !== void 0 && lastAssistantIdx >= 0) {
        cleared[lastAssistantIdx] = { ...cleared[lastAssistantIdx], durationMs };
      }
      if (cleared !== list2 || durationMs !== void 0 && lastAssistantIdx >= 0) {
        messages.value = cleared;
      }
      isAgentRunning.value = false;
      resetAgentStatus();
      const diagramTitle = pendingDiagramTitle.value;
      if (diagramTitle !== void 0) {
        pendingDiagramTitle.value = void 0;
        const finalList = messages.value;
        const finalLast = finalList[finalList.length - 1];
        if (finalLast && finalLast.role === "assistant") {
          const src = extractMermaidSource(finalLast.text);
          if (src.length > 0) {
            diagrams.value = [
              ...diagrams.value,
              { id: `dg_${Date.now()}`, mermaid: src, title: diagramTitle }
            ];
          }
        }
      }
    } else if (ev.type === "error") {
      errorBanner.value = ev.message;
      const list2 = messages.value;
      let mutated = false;
      const cleared = list2.map((m4) => {
        if (m4.role === "assistant" && m4.pending) {
          mutated = true;
          return { ...m4, pending: false };
        }
        return m4;
      });
      const withError = [
        ...mutated ? cleared : list2,
        {
          id: `err_${Date.now()}`,
          role: "system",
          text: `\u26A0\uFE0F **Agent error:** ${ev.message}`
        }
      ];
      messages.value = withError;
      isAgentRunning.value = false;
      resetAgentStatus();
    }
  }
  function truncate2(s5, n3) {
    return s5.length > n3 ? `${s5.slice(0, n3)}\u2026` : s5;
  }
  function formatTokens3(n3) {
    if (n3 < 1e3) return String(n3);
    if (n3 < 1e6) return `${(n3 / 1e3).toFixed(1)}k`;
    return `${(n3 / 1e6).toFixed(2)}M`;
  }
  function TokenBadge({ inputTokens, outputTokens, snapshot }) {
    const modelId = resolveActiveModelId(snapshot);
    const cost = modelId ? estimateCost(modelId, inputTokens, outputTokens) : void 0;
    const tokens = `\u2193${formatTokens3(inputTokens)} \u2191${formatTokens3(outputTokens)}`;
    const title = cost ? `Session tokens (in / out)
In: ${formatUsd(cost.inputUsd)}
Out: ${formatUsd(cost.outputUsd)}
Total: ${formatUsd(cost.totalUsd)} (${cost.rate.displayName})` : "Session tokens (in / out). Cost unknown for this model.";
    return /* @__PURE__ */ u3("span", { class: "oati-token-badge", title, children: [
      tokens,
      cost ? /* @__PURE__ */ u3(S, { children: [
        " \xB7 ",
        formatUsd(cost.totalUsd)
      ] }) : null
    ] });
  }
  function buildCostMessage(inputTokens, outputTokens, snapshot) {
    const lines = [
      "**Session usage**",
      "",
      `- Input tokens: \`${inputTokens.toLocaleString()}\``,
      `- Output tokens: \`${outputTokens.toLocaleString()}\``
    ];
    const modelId = resolveActiveModelId(snapshot);
    const cost = modelId ? estimateCost(modelId, inputTokens, outputTokens) : void 0;
    if (cost) {
      lines.push(
        `- Estimated cost: **${formatUsd(cost.totalUsd)}** (${cost.rate.displayName})`,
        `  - input ${formatUsd(cost.inputUsd)} \xB7 output ${formatUsd(cost.outputUsd)}`
      );
    } else {
      lines.push("- _Cost unknown for this model (no pricing entry)._");
    }
    return lines.join("\n");
  }
  function RouteBadgeBanner({ badge }) {
    const label = badge.model ? `via ${badge.providerId}:${badge.model}` : `via ${badge.providerId}`;
    const title = badge.reason ? `${label} \u2014 ${badge.reason}` : label;
    return /* @__PURE__ */ u3("output", { class: "oati-route-badge", title, children: [
      /* @__PURE__ */ u3("span", { class: "oati-route-badge-dot", "aria-hidden": "true", children: "\u2933" }),
      /* @__PURE__ */ u3("span", { class: "oati-route-badge-label", children: label })
    ] });
  }
  function resolveActiveModelId(snapshot) {
    if (!snapshot) return void 0;
    const cfg = snapshot.config;
    const activeMode2 = cfg.modes.find((m4) => m4.id === cfg.activeModeId) ?? cfg.modes[0];
    if (activeMode2?.modelId) return activeMode2.modelId;
    const providerId = activeMode2?.providerId ?? cfg.activeProviderId;
    const provider = cfg.providers.find((p5) => p5.id === providerId);
    return provider?.defaultModel || void 0;
  }
  function extractMermaidSource(text) {
    const trimmed = text.trim();
    if (trimmed.length === 0) return "";
    const fence = /```(?:mermaid)?\s*\r?\n([\s\S]*?)\r?\n```/i.exec(trimmed);
    if (fence) return fence[1].trim();
    return trimmed;
  }

  // src/main.tsx
  var root = document.getElementById("root");
  if (root) R(/* @__PURE__ */ u3(App, {}), root);
})();
//# sourceMappingURL=main.js.map
