// In-editor experience stubs (round R1).
//
// The VS Code/Antigravity extension ships inline diff Accept/Reject/Modify,
// a Ctrl+K inline-edit prompt, "Add to chat" on selections, and AI Code Lens
// shortcuts (Explain / Test / Refactor) for every detected function or class.
//
// None of those are wired up in the Visual Studio bridge yet — they each
// need a real port to the IVsTextManager / IWpfTextView / IVsTextLayer stack
// before they can hook the editor surface. Stubs live here so we have a
// single, grep-friendly entry point for the next round.

namespace Oati.VisualStudio.InEditorExperience
{
    // TODO(vs): inline diff / Ctrl+K / code lens — port in round N
    internal static class InlineDiff
    {
        // TODO(vs): inline diff — port in round N (decorations + Accept/Reject/Modify code lenses)
    }

    // TODO(vs): inline diff / Ctrl+K / code lens — port in round N
    internal static class InlineEdit
    {
        // TODO(vs): Ctrl+K — port in round N (input box anchored to caret + streamed rewrite)
    }

    // TODO(vs): inline diff / Ctrl+K / code lens — port in round N
    internal static class SelectionToOatiCode
    {
        // TODO(vs): Add to OATI Code — port in round N (route active selection into the OATI Code composer)
    }

    // TODO(vs): inline diff / Ctrl+K / code lens — port in round N
    internal static class AiCodeLens
    {
        // TODO(vs): Explain/Test/Refactor lenses — port in round N (IViewTaggerProvider + ITagger<IntraTextAdornmentTag>)
    }
}
