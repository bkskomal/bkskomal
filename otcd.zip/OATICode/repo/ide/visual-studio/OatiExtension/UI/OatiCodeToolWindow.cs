using System;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.Shell;

namespace Oati.VisualStudio.UI
{
    /// <summary>
    /// OATI Code tool window pane. The actual UI lives in
    /// <see cref="OatiCodeToolWindowControl"/> — a WPF user-control that
    /// hosts a WebView2 instance pointed at the shared Preact bundle.
    /// </summary>
    [Guid("c7d8e9f0-3456-4abc-9876-2b3c4d5e6f70")]
    public class OatiCodeToolWindow : ToolWindowPane
    {
        public OatiCodeToolWindow() : base(null)
        {
            Caption = "OATI Code";
            Content = new OatiCodeToolWindowControl();
        }
    }
}
