using System;
using System.ComponentModel.Design;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using Oati.VisualStudio.UI;
using Task = System.Threading.Tasks.Task;

namespace Oati.VisualStudio
{
    /// <summary>
    /// "Tools → OATI Code: Open" menu entry. Reveals the OATI Code tool
    /// window (creates it on first use). Identical handler shape to the VS
    /// SDK template; the command id matches the .vsct symbol so both menus
    /// fire the same route.
    /// </summary>
    internal sealed class OpenOatiCodeCommand
    {
        public const int CommandId = 0x0100;
        public static readonly Guid CommandSet = new Guid("a9b8c7d6-2345-4def-9876-1a2b3c4d5e7f");

        private readonly AsyncPackage _package;

        private OpenOatiCodeCommand(AsyncPackage package, OleMenuCommandService commandService)
        {
            _package = package ?? throw new ArgumentNullException(nameof(package));
            var menuCommandId = new CommandID(CommandSet, CommandId);
            var menuItem = new MenuCommand(Execute, menuCommandId);
            commandService.AddCommand(menuItem);
        }

        public static async Task InitializeAsync(AsyncPackage package)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);
            var commandService = await package.GetServiceAsync(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (commandService == null) return;
            _ = new OpenOatiCodeCommand(package, commandService);
        }

        private void Execute(object sender, EventArgs e)
        {
            _package.JoinableTaskFactory.RunAsync(async () =>
            {
                await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
                var window = await _package.ShowToolWindowAsync(typeof(OatiCodeToolWindow), 0, true, _package.DisposalToken);
                if (window == null || window.Frame == null)
                    throw new NotSupportedException("Cannot create OATI Code tool window");
            }).FileAndForget("oati/open-oati-code");
        }
    }
}
