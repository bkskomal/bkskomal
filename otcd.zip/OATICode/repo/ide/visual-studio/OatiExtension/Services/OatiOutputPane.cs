// Copyright OATI Technology. MIT-licensed.

using System;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using Task = System.Threading.Tasks.Task;

namespace Oati.VisualStudio.Services
{
    /// <summary>
    /// Single "OATI Code" output pane shared across the package — sidecar
    /// logs, RPC bridge diagnostics, and workspace-tracker events all
    /// land here so the user has one place to look.
    /// </summary>
    public sealed class OatiOutputPane
    {
        private static readonly Guid PaneGuid = new("90c4a8e5-2c9a-4ad5-9b62-4dc04d6f4f9a");
        private readonly AsyncPackage _package;
        private IVsOutputWindowPane? _pane;

        public OatiOutputPane(AsyncPackage package)
        {
            _package = package;
        }

        public void WriteLine(string line)
        {
            // Fire-and-forget. Pane creation runs on the UI thread, but
            // callers (sidecar event handlers, background tasks) may not
            // already be there.
            _ = WriteLineAsync(line);
        }

        public async Task WriteLineAsync(string line)
        {
            try
            {
                await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
                if (_pane is null)
                {
                    var outputWindow =
                        (IVsOutputWindow?)await _package.GetServiceAsync(typeof(SVsOutputWindow));
                    if (outputWindow is null) return;
                    var guid = PaneGuid;
                    outputWindow.CreatePane(ref guid, "OATI Code", 1, 1);
                    outputWindow.GetPane(ref guid, out _pane);
                }
                _pane?.OutputStringThreadSafe(line + Environment.NewLine);
            }
            catch
            {
                // Output pane creation is best-effort; never throw into callers.
            }
        }
    }
}
