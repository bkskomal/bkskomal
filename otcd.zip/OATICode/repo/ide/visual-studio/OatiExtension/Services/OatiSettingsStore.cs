using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Oati.VisualStudio.Services
{
    /// <summary>
    /// Visual Studio analogue of the VS Code SettingsStore in the npm workspace.
    /// Persists non-secret config to %APPDATA%/OATI Code/settings.json
    /// and API keys to a sibling secrets.bin via DPAPI (CurrentUser scope).
    /// </summary>
    public sealed class OatiSettingsStore
    {
        private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("OATI.v1.entropy");

        private readonly string _baseDir;
        private readonly string _configPath;
        private readonly string _secretsPath;

        public OatiSettingsStore()
        {
            _baseDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "OATI Code");
            Directory.CreateDirectory(_baseDir);
            _configPath = Path.Combine(_baseDir, "settings.json");
            _secretsPath = Path.Combine(_baseDir, "secrets.bin");
        }

        public JsonDocument LoadConfig()
        {
            if (!File.Exists(_configPath))
            {
                return JsonDocument.Parse(DefaultConfigJson());
            }
            try
            {
                var text = File.ReadAllText(_configPath, Encoding.UTF8);
                return MigrateModes(JsonDocument.Parse(text));
            }
            catch
            {
                return JsonDocument.Parse(DefaultConfigJson());
            }
        }

        /// <summary>
        /// Older saved configs only contained the single "code" mode. Merge in any of
        /// the standard built-in modes (ask, plan, auto-edit, auto) that are missing
        /// so the mode picker shows the full set without forcing the user to wipe
        /// their settings file. User-customized modes (renamed displayName, edited
        /// systemPrompt, etc.) are preserved untouched.
        /// </summary>
        private static JsonDocument MigrateModes(JsonDocument doc)
        {
            if (!doc.RootElement.TryGetProperty("modes", out var modesProp)
                || modesProp.ValueKind != JsonValueKind.Array)
            {
                return doc;
            }

            var existingIds = new HashSet<string>(StringComparer.Ordinal);
            foreach (var m in modesProp.EnumerateArray())
            {
                if (m.TryGetProperty("id", out var idProp) && idProp.ValueKind == JsonValueKind.String)
                {
                    var id = idProp.GetString();
                    if (!string.IsNullOrEmpty(id)) existingIds.Add(id!);
                }
            }

            using var defaultsDoc = JsonDocument.Parse(DefaultConfigJson());
            var defaultModes = defaultsDoc.RootElement.GetProperty("modes");
            var toAppend = new List<JsonElement>();
            foreach (var defMode in defaultModes.EnumerateArray())
            {
                var defId = defMode.GetProperty("id").GetString();
                if (defId != null && !existingIds.Contains(defId))
                {
                    toAppend.Add(defMode);
                }
            }
            if (toAppend.Count == 0) return doc;

            // Re-serialize with the appended modes. JsonDocument is immutable so we
            // round-trip through a writer.
            using var ms = new MemoryStream();
            using (var writer = new Utf8JsonWriter(ms, new JsonWriterOptions { Indented = true }))
            {
                writer.WriteStartObject();
                foreach (var prop in doc.RootElement.EnumerateObject())
                {
                    if (prop.Name == "modes")
                    {
                        writer.WritePropertyName("modes");
                        writer.WriteStartArray();
                        foreach (var existing in modesProp.EnumerateArray())
                        {
                            existing.WriteTo(writer);
                        }
                        foreach (var added in toAppend)
                        {
                            added.WriteTo(writer);
                        }
                        writer.WriteEndArray();
                    }
                    else
                    {
                        prop.WriteTo(writer);
                    }
                }
                writer.WriteEndObject();
            }
            doc.Dispose();
            ms.Position = 0;
            return JsonDocument.Parse(ms.ToArray());
        }

        public void SaveConfig(JsonElement config)
        {
            var text = JsonSerializer.Serialize(
                config,
                new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_configPath, text, Encoding.UTF8);
        }

        public Dictionary<string, bool> GetHasApiKeyMap(IEnumerable<string> providerIds)
        {
            var keys = LoadSecrets();
            var map = new Dictionary<string, bool>();
            foreach (var id in providerIds)
            {
                map[id] = keys.TryGetValue(id, out var v) && !string.IsNullOrEmpty(v);
            }
            return map;
        }

        public string? GetApiKey(string providerId)
        {
            return LoadSecrets().TryGetValue(providerId, out var v) ? v : null;
        }

        public void SetApiKey(string providerId, string apiKey)
        {
            var secrets = LoadSecrets();
            secrets[providerId] = apiKey;
            SaveSecrets(secrets);
        }

        public void DeleteApiKey(string providerId)
        {
            var secrets = LoadSecrets();
            if (secrets.Remove(providerId))
            {
                SaveSecrets(secrets);
            }
        }

        private Dictionary<string, string> LoadSecrets()
        {
            if (!File.Exists(_secretsPath)) return new Dictionary<string, string>();
            try
            {
                var encrypted = File.ReadAllBytes(_secretsPath);
                var decrypted = ProtectedData.Unprotect(encrypted, Entropy, DataProtectionScope.CurrentUser);
                var json = Encoding.UTF8.GetString(decrypted);
                return JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                       ?? new Dictionary<string, string>();
            }
            catch
            {
                // Corrupt/wrong-user; start fresh rather than crashing.
                return new Dictionary<string, string>();
            }
        }

        private void SaveSecrets(Dictionary<string, string> secrets)
        {
            var json = JsonSerializer.Serialize(secrets);
            var bytes = Encoding.UTF8.GetBytes(json);
            var encrypted = ProtectedData.Protect(bytes, Entropy, DataProtectionScope.CurrentUser);
            File.WriteAllBytes(_secretsPath, encrypted);
        }

        /// <summary>
        /// Default config shipped to fresh installs. Mirrors packages/shared/src/config.ts
        /// DEFAULT_CONFIG so the VS shell exposes the same mode catalog (Ask, Plan, Code,
        /// Auto Edit, Auto) as the VS Code path. Keep the two in sync when adding modes.
        /// </summary>
        private static string DefaultConfigJson()
        {
            return @"{
  ""activeProviderId"": ""default"",
  ""activeModeId"": ""code"",
  ""providers"": [
    {
      ""id"": ""default"",
      ""type"": ""openai-compatible"",
      ""displayName"": ""OpenAI Compatible"",
      ""preset"": ""openai-compatible"",
      ""baseUrl"": ""http://localhost:4000/v1"",
      ""defaultModel"": """"
    }
  ],
  ""modes"": [
    {
      ""id"": ""ask"",
      ""displayName"": ""Ask"",
      ""description"": ""Read-only Q&A — explore the codebase, no edits or shell commands."",
      ""systemPrompt"": ""You are OATI Code in read-only Q&A mode. Answer questions about the user's project using the read-only tools available to you. Never propose changes to files; if the user asks for changes, suggest switching to Code or Auto Edit mode."",
      ""enabledTools"": [""read_file"", ""search_files"", ""workspace_context"", ""fetch_url""],
      ""enablePlanner"": false,
      ""enableCritic"": false,
      ""maxParallelAgents"": 1,
      ""maxIterations"": 12,
      ""temperature"": 0.2
    },
    {
      ""id"": ""plan"",
      ""displayName"": ""Plan"",
      ""description"": ""Planner + critic over read-only tools — produces a written plan, no edits."",
      ""systemPrompt"": ""You are OATI Code in planning mode. Investigate the user's project with read-only tools, then produce a clear step-by-step implementation plan. Do not edit files. End with a concise summary of the recommended approach and any open questions."",
      ""enabledTools"": [""read_file"", ""search_files"", ""workspace_context"", ""fetch_url""],
      ""enablePlanner"": true,
      ""enableCritic"": true,
      ""maxParallelAgents"": 1,
      ""maxIterations"": 16,
      ""temperature"": 0.2
    },
    {
      ""id"": ""code"",
      ""displayName"": ""Code"",
      ""description"": ""Edits with approval — you confirm every file write and shell command."",
      ""systemPrompt"": ""You are OATI Code, a careful agentic coding assistant. Use tools to inspect and modify the user's project. Always preview file changes before writing. You may use `spawn_agent` to delegate self-contained sub-tasks to a fresh sub-agent."",
      ""enabledTools"": ""all"",
      ""enablePlanner"": false,
      ""enableCritic"": false,
      ""maxParallelAgents"": 4,
      ""maxIterations"": 20,
      ""temperature"": 0.2
    },
    {
      ""id"": ""auto-edit"",
      ""displayName"": ""Auto Edit"",
      ""description"": ""Edits auto-approved; agent loops until done. Confirms destructive shell commands."",
      ""systemPrompt"": ""You are OATI Code in auto-edit mode. You operate autonomously: keep iterating with tools until the task is complete. File edits run without approval prompts (preview them in chat first). Destructive shell commands (rm -rf, dropping data, git push --force, etc.) MUST be explained and confirmed before running. For 2+ independent subtasks use `spawn_parallel_agents` to fan out; for a single self-contained subtask prefer `spawn_agent`. Diagnose tool errors and retry — don't bail on the first failure."",
      ""enabledTools"": ""all"",
      ""enablePlanner"": false,
      ""enableCritic"": true,
      ""maxParallelAgents"": 6,
      ""maxIterations"": 40,
      ""temperature"": 0.2,
      ""autoApprove"": true
    },
    {
      ""id"": ""auto"",
      ""displayName"": ""Auto"",
      ""description"": ""Full agentic loop — planner + critic + parallel agents, no approval prompts."",
      ""systemPrompt"": ""You are OATI Code in Auto mode — the most aggressive agentic configuration. You operate autonomously end-to-end. Keep iterating with tools until the user's task is genuinely complete; verify with reads, tests, or builds as appropriate. All edits and shell commands run without approval prompts — be deliberate, state intent before anything irreversible. The instant you spot 2+ independent subtasks, call `spawn_parallel_agents` to fan out (one task per sub-agent). Don't serialize independent work. Tool errors are signals: diagnose and try a different approach. The iteration cap is high precisely so you can self-correct."",
      ""enabledTools"": ""all"",
      ""enablePlanner"": true,
      ""enableCritic"": true,
      ""maxParallelAgents"": 8,
      ""maxIterations"": 80,
      ""maxRetries"": 2,
      ""temperature"": 0.2,
      ""autoApprove"": true
    }
  ]
}";
        }
    }
}
