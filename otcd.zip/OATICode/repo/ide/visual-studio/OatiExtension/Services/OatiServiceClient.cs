using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Oati.VisualStudio.Services
{
    /// <summary>
    /// HTTP+SSE client for the local oati-service (packages/agent-service).
    /// Implements POST /v1/agent/run with streaming response parsing.
    /// </summary>
    public sealed class OatiServiceClient : IDisposable
    {
        private readonly HttpClient _http;
        private readonly string _baseUrl;
        private readonly string? _token;

        public OatiServiceClient(string baseUrl, string? token = null)
        {
            _baseUrl = baseUrl.TrimEnd('/');
            _token = token;
            _http = new HttpClient { Timeout = Timeout.InfiniteTimeSpan };
            if (!string.IsNullOrEmpty(token))
                _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        public async Task<bool> HealthAsync(CancellationToken ct = default)
        {
            try
            {
                using var resp = await _http.GetAsync($"{_baseUrl}/v1/health", ct).ConfigureAwait(false);
                return resp.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Resolve a pending tool-approval initiated by the service via an
        /// <c>approval_request</c> SSE event. The service holds a Promise keyed
        /// by <paramref name="id"/>; this POST settles it.
        /// </summary>
        public async Task<bool> ApproveAsync(string id, bool approved, CancellationToken ct = default)
        {
            var body = JsonSerializer.Serialize(new { approved });
            using var req = new HttpRequestMessage(
                HttpMethod.Post,
                $"{_baseUrl}/v1/approval/{Uri.EscapeDataString(id)}")
            {
                Content = new StringContent(body, Encoding.UTF8, "application/json"),
            };
            try
            {
                using var resp = await _http.SendAsync(req, ct).ConfigureAwait(false);
                return resp.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        public async IAsyncEnumerable<JsonElement> RunAgentAsync(
            object requestBody,
            [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
        {
            var json = JsonSerializer.Serialize(requestBody);
            using var req = new HttpRequestMessage(HttpMethod.Post, $"{_baseUrl}/v1/agent/run")
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json"),
            };
            req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/event-stream"));

            using var resp = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
            resp.EnsureSuccessStatusCode();

            using var stream = await resp.Content.ReadAsStreamAsync().ConfigureAwait(false);
            using var reader = new StreamReader(stream, Encoding.UTF8);

            while (!reader.EndOfStream)
            {
                if (ct.IsCancellationRequested) yield break;
                var line = await reader.ReadLineAsync().ConfigureAwait(false);
                if (line == null) break;
                if (!line.StartsWith("data:", StringComparison.Ordinal)) continue;
                var payload = line.Substring(5).Trim();
                if (payload.Length == 0 || payload == "[DONE]") continue;
                JsonElement parsed;
                try
                {
                    using var doc = JsonDocument.Parse(payload);
                    parsed = doc.RootElement.Clone();
                }
                catch
                {
                    continue;
                }
                yield return parsed;
            }
        }

        public void Dispose() => _http.Dispose();
    }
}
