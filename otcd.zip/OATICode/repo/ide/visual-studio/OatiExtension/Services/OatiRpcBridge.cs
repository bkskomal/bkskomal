using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Wpf;

namespace Oati.VisualStudio.Services
{
    /// <summary>
    /// Bridges the embedded @oati/webview-ui bundle to the local OatiServiceClient.
    ///
    /// Inbound (webview → C#):
    ///   ready              → push init + settings
    ///   user_message       → POST /v1/agent/run; stream SSE → agent_event push
    ///   approval_response  → POST /v1/approval/{id}; the service-side agent unblocks
    ///   get_settings       → push settings
    ///   update_settings    → write config to disk + push fresh settings
    ///   update_api_key     → write secret via DPAPI + push fresh settings
    ///   delete_api_key     → wipe secret + push fresh settings
    ///   cancel             → abort current run
    ///   set_mode           → patch activeModeId in config
    ///   test_connection    → ping /v1/health
    ///
    /// Outbound (C# → webview):
    ///   init               → modes + active id
    ///   settings           → {config, hasApiKey}
    ///   agent_event        → each AgentEvent from the SSE stream
    ///   approval_request   → forwarded from the SSE stream when a tool needs approval
    ///   connection_test_result → reply to test_connection
    ///   error              → user-visible error banner
    /// </summary>
    public sealed class OatiRpcBridge
    {
        private readonly WebView2 _webview;
        private readonly OatiSettingsStore _store;
        private readonly OatiServiceClient _client;
        private readonly Dispatcher _dispatcher;
        private CancellationTokenSource? _currentRun;

        public OatiRpcBridge(WebView2 webview, OatiSettingsStore store, OatiServiceClient client)
        {
            _webview = webview;
            _store = store;
            _client = client;
            _dispatcher = webview.Dispatcher;
        }

        public async void HandleIncoming(string rawJson)
        {
            try
            {
                using var doc = JsonDocument.Parse(rawJson);
                if (!doc.RootElement.TryGetProperty("v", out var vProp) || vProp.GetInt32() != 1) return;
                if (!doc.RootElement.TryGetProperty("body", out var body)) return;
                if (!body.TryGetProperty("type", out var typeProp)) return;
                var msgType = typeProp.GetString();

                switch (msgType)
                {
                    case "ready":
                        PushInit();
                        PushSettings();
                        break;
                    case "user_message":
                        await HandleUserMessage(body);
                        break;
                    case "cancel":
                        _currentRun?.Cancel();
                        break;
                    case "get_settings":
                        PushSettings();
                        break;
                    case "update_settings":
                        HandleUpdateSettings(body);
                        PushSettings();
                        break;
                    case "update_api_key":
                        HandleUpdateApiKey(body);
                        PushSettings();
                        break;
                    case "delete_api_key":
                        HandleDeleteApiKey(body);
                        PushSettings();
                        break;
                    case "set_mode":
                        HandleSetMode(body);
                        PushSettings();
                        break;
                    case "test_connection":
                        await HandleTestConnection(body);
                        break;
                    case "approval_response":
                        await HandleApprovalResponse(body);
                        break;
                    case "regenerate_from":
                        // VS bridge doesn't have session history wired up yet, so we
                        // can't truncate-and-rerun. Log + no-op so the webview doesn't
                        // crash on the new RPC variant; the VS Code host handles this
                        // fully. Wire up later when VS gets a per-session model.
                        System.Diagnostics.Debug.WriteLine("[oati-vs] regenerate_from: not implemented in VS yet");
                        break;
                    case "compact_history":
                        System.Diagnostics.Debug.WriteLine("[oati-vs] compact_history: not implemented in VS yet");
                        break;
                    // TODO(vs): project memory — load <workspace>/.oati/OATI.md (and the
                    // fallback list mirroring packages/extension-host/src/project-memory.ts)
                    // and prepend its contents to the active mode's systemPrompt before
                    // posting /v1/agent/run. Re-read on every user_message so saves take
                    // effect on the next prompt.
                    // TODO(vs): custom slash commands — scan <workspace>/.oati/commands/*.md
                    // at "ready", include the resulting summaries in the init payload as
                    // `customCommands`, and handle a new "run_custom_command" inbound RPC
                    // by template-expanding the matching command into a user_message.
                    // TODO(vs): hooks — read RootConfig.hooks from disk and run the
                    // PreToolUse / PostToolUse / UserPromptSubmit / SessionStart / Stop
                    // lifecycle hooks mirroring HookRunner. PreToolUse runs before the
                    // approval prompt; a blocking allow:false should short-circuit the
                    // /v1/approval call with a user-facing error banner.
                    default:
                        System.Diagnostics.Debug.WriteLine($"[oati-vs] unhandled msg type: {msgType}");
                        break;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[oati-vs] HandleIncoming error: {ex}");
                PushError($"Bridge error: {ex.Message}");
            }
        }

        private void PushInit()
        {
            using var cfg = _store.LoadConfig();
            var modes = new List<object>();
            int modesArrayLen = -1;
            if (cfg.RootElement.TryGetProperty("modes", out var modesProp)
                && modesProp.ValueKind == JsonValueKind.Array)
            {
                modesArrayLen = modesProp.GetArrayLength();
                foreach (var m in modesProp.EnumerateArray())
                {
                    modes.Add(new
                    {
                        id = TryGetString(m, "id"),
                        displayName = TryGetString(m, "displayName"),
                        description = TryGetString(m, "description"),
                        autoApprove = TryGetBool(m, "autoApprove"),
                        enablePlanner = TryGetBool(m, "enablePlanner"),
                        enableCritic = TryGetBool(m, "enableCritic"),
                    });
                }
            }
            var activeModeId = TryGetString(cfg.RootElement, "activeModeId") ?? "";
            // The webview's init handler reads msg.sessionId / msg.workspaceFiles
            // and stores them in signals; sending undefined trips downstream
            // string operations and leaves the settings panel stuck on "Loading...".
            // VS has no per-session model yet, so use a stable sentinel id and an
            // empty workspace-file list.
            System.Diagnostics.Debug.WriteLine(
                $"[oati-vs] PushInit: settings.json has {modesArrayLen} mode(s) -> serializing {modes.Count} into init; ids=[" +
                string.Join(",", modes.ConvertAll(o => o.GetType().GetProperty("id")?.GetValue(o)?.ToString() ?? "?")) +
                $"] activeModeId='{activeModeId}'");
            PushToWebview(new
            {
                type = "init",
                modes,
                activeModeId,
                sessionId = "vs-default",
                workspaceFiles = Array.Empty<string>(),
            });
        }

        private static string? TryGetString(JsonElement el, string prop)
        {
            return el.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String
                ? v.GetString()
                : null;
        }

        private static bool TryGetBool(JsonElement el, string prop)
        {
            return el.TryGetProperty(prop, out var v)
                && (v.ValueKind == JsonValueKind.True
                    || (v.ValueKind == JsonValueKind.String && v.GetString() == "true"));
        }

        private void PushSettings()
        {
            using var cfg = _store.LoadConfig();
            var providerIds = new List<string>();
            if (cfg.RootElement.TryGetProperty("providers", out var providers))
            {
                foreach (var p in providers.EnumerateArray())
                {
                    var id = p.GetProperty("id").GetString();
                    if (!string.IsNullOrEmpty(id)) providerIds.Add(id!);
                }
            }
            var hasApiKey = _store.GetHasApiKeyMap(providerIds);
            // Clone the config tree into a serializable shape (JsonElement → object).
            var configObject = JsonDocumentToObject(cfg.RootElement);
            PushToWebview(new { type = "settings", snapshot = new { config = configObject, hasApiKey } });
        }

        private async Task HandleUserMessage(JsonElement body)
        {
            var content = body.GetProperty("content").GetString() ?? "";
            using var cfg = _store.LoadConfig();
            var (providerConfig, apiKey, modelId, mode) = BuildRunArgs(cfg.RootElement);
            if (providerConfig == null || mode == null || string.IsNullOrEmpty(modelId))
            {
                PushError("No model or mode configured. Open OATI Settings first.");
                return;
            }

            _currentRun?.Cancel();
            _currentRun = new CancellationTokenSource();
            var ct = _currentRun.Token;

            var requestBody = new
            {
                providerConfig,
                apiKey,
                modelId,
                mode,
                userMessage = content,
            };

            try
            {
                await foreach (var ev in _client.RunAgentAsync(requestBody, ct))
                {
                    if (!ev.TryGetProperty("type", out var tProp)) continue;
                    var t = tProp.GetString();
                    switch (t)
                    {
                        case "history_snapshot":
                            // Service-internal; not surfaced to the webview.
                            continue;
                        case "approval_request":
                            // The service is awaiting our answer on /v1/approval/{id}.
                            // Forward the request to the webview verbatim so the user
                            // sees the standard approval dialog.
                            if (ev.TryGetProperty("request", out var reqProp))
                            {
                                PushToWebview(new
                                {
                                    type = "approval_request",
                                    request = JsonDocumentToObject(reqProp),
                                });
                            }
                            continue;
                        default:
                            // Every other SSE message is a regular AgentEvent.
                            PushToWebview(new { type = "agent_event", @event = JsonDocumentToObject(ev) });
                            continue;
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // user-initiated; no error banner needed
            }
            catch (Exception ex)
            {
                PushError($"Agent run failed: {ex.Message}");
            }
        }

        private void HandleUpdateSettings(JsonElement body)
        {
            if (!body.TryGetProperty("settings", out var s)) return;
            using var cfg = _store.LoadConfig();
            var merged = MergeSettings(cfg.RootElement, s);
            _store.SaveConfig(merged);
        }

        private void HandleUpdateApiKey(JsonElement body)
        {
            var providerId = body.GetProperty("providerId").GetString();
            var apiKey = body.GetProperty("apiKey").GetString();
            if (string.IsNullOrEmpty(providerId) || apiKey == null) return;
            _store.SetApiKey(providerId!, apiKey);
        }

        private void HandleDeleteApiKey(JsonElement body)
        {
            var providerId = body.GetProperty("providerId").GetString();
            if (string.IsNullOrEmpty(providerId)) return;
            _store.DeleteApiKey(providerId!);
        }

        private void HandleSetMode(JsonElement body)
        {
            var modeId = body.GetProperty("modeId").GetString();
            if (string.IsNullOrEmpty(modeId)) return;
            using var cfg = _store.LoadConfig();
            var doc = JsonDocumentToObject(cfg.RootElement);
            if (doc is Dictionary<string, object?> dict)
            {
                dict["activeModeId"] = modeId;
                _store.SaveConfig(SerializeObjectToElement(dict));
            }
        }

        private async Task HandleApprovalResponse(JsonElement body)
        {
            if (!body.TryGetProperty("id", out var idProp)) return;
            if (!body.TryGetProperty("approved", out var approvedProp)) return;
            var id = idProp.GetString();
            if (string.IsNullOrEmpty(id)) return;
            var approved = approvedProp.ValueKind == JsonValueKind.True;
            var ok = await _client.ApproveAsync(id!, approved).ConfigureAwait(false);
            if (!ok)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[oati-vs] approval POST failed or expired for id={id}");
            }
        }

        private async Task HandleTestConnection(JsonElement body)
        {
            var providerId = body.GetProperty("providerId").GetString();
            var ok = await _client.HealthAsync(default);
            PushToWebview(new
            {
                type = "connection_test_result",
                providerId,
                ok,
                message = ok ? "Service reachable" : "Service unreachable",
            });
        }

        private (object? providerConfig, string? apiKey, string modelId, object? mode) BuildRunArgs(JsonElement root)
        {
            string activeProviderId = root.TryGetProperty("activeProviderId", out var ap)
                ? ap.GetString() ?? ""
                : "";
            string activeModeId = root.TryGetProperty("activeModeId", out var am)
                ? am.GetString() ?? ""
                : "";

            object? providerConfig = null;
            string modelId = "";
            if (root.TryGetProperty("providers", out var providers))
            {
                foreach (var p in providers.EnumerateArray())
                {
                    if (p.GetProperty("id").GetString() == activeProviderId)
                    {
                        providerConfig = JsonDocumentToObject(p);
                        modelId = p.TryGetProperty("defaultModel", out var dm) ? dm.GetString() ?? "" : "";
                        break;
                    }
                }
            }

            object? mode = null;
            if (root.TryGetProperty("modes", out var modes))
            {
                foreach (var m in modes.EnumerateArray())
                {
                    if (m.GetProperty("id").GetString() == activeModeId)
                    {
                        mode = JsonDocumentToObject(m);
                        var explicitModel = m.TryGetProperty("modelId", out var mid) ? mid.GetString() : null;
                        if (!string.IsNullOrEmpty(explicitModel)) modelId = explicitModel!;
                        break;
                    }
                }
            }

            var apiKey = _store.GetApiKey(activeProviderId);
            return (providerConfig, apiKey, modelId, mode);
        }

        private JsonElement MergeSettings(JsonElement currentRoot, JsonElement update)
        {
            var current = (Dictionary<string, object?>)JsonDocumentToObject(currentRoot)!;
            if (update.TryGetProperty("activeProviderId", out var apid))
                current["activeProviderId"] = apid.GetString();
            if (update.TryGetProperty("activeModeId", out var amid))
                current["activeModeId"] = amid.GetString();
            if (update.TryGetProperty("providers", out var providers))
                current["providers"] = JsonDocumentToObject(providers);
            if (update.TryGetProperty("modes", out var modes))
                current["modes"] = JsonDocumentToObject(modes);
            if (update.TryGetProperty("mcpServers", out var mcp))
                current["mcpServers"] = JsonDocumentToObject(mcp);
            return SerializeObjectToElement(current);
        }

        private static object? JsonDocumentToObject(JsonElement el)
        {
            switch (el.ValueKind)
            {
                case JsonValueKind.Object:
                    var dict = new Dictionary<string, object?>();
                    foreach (var prop in el.EnumerateObject())
                        dict[prop.Name] = JsonDocumentToObject(prop.Value);
                    return dict;
                case JsonValueKind.Array:
                    var list = new List<object?>();
                    foreach (var item in el.EnumerateArray())
                        list.Add(JsonDocumentToObject(item));
                    return list;
                case JsonValueKind.String: return el.GetString();
                case JsonValueKind.Number:
                    if (el.TryGetInt64(out var i)) return i;
                    return el.GetDouble();
                case JsonValueKind.True: return true;
                case JsonValueKind.False: return false;
                case JsonValueKind.Null: return null;
                default: return null;
            }
        }

        private static JsonElement SerializeObjectToElement(object? value)
        {
            var json = JsonSerializer.Serialize(value);
            return JsonDocument.Parse(json).RootElement.Clone();
        }

        private void PushToWebview(object body)
        {
            void Send()
            {
                try
                {
                    var envelope = new { v = 1, body };
                    var json = JsonSerializer.Serialize(envelope);
                    _webview.CoreWebView2?.PostWebMessageAsJson(json);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[oati-vs] PostWebMessage error: {ex}");
                }
            }

            if (_dispatcher.CheckAccess()) Send();
            else _dispatcher.BeginInvoke(new Action(Send));
        }

        /// <summary>
        /// Surface a user-visible error banner in the chat. Public so the host control
        /// can fire it for non-conversational issues like "oati-service unreachable".
        /// </summary>
        public void PushError(string message)
        {
            PushToWebview(new { type = "error", message });
        }

        /// <summary>
        /// Periodically poll /v1/health. On every transition (reachable ↔ unreachable),
        /// push a single banner so the user knows the state of the service.
        /// </summary>
        public async Task RunHealthMonitorAsync(TimeSpan interval, CancellationToken ct)
        {
            bool? lastOk = null;
            while (!ct.IsCancellationRequested)
            {
                bool ok;
                try { ok = await _client.HealthAsync(ct).ConfigureAwait(false); }
                catch { ok = false; }

                if (lastOk is null && !ok)
                {
                    PushError(
                        "OATI service is not reachable. Start it with: " +
                        "node packages/agent-service/dist/cli.js — or set OATI_SERVICE_URL.");
                }
                else if (lastOk == false && ok)
                {
                    PushToWebview(new { type = "error", message = "" }); // clears the banner
                }
                else if (lastOk == true && !ok)
                {
                    PushError("OATI service became unreachable. Is it still running?");
                }

                lastOk = ok;
                try { await Task.Delay(interval, ct).ConfigureAwait(false); }
                catch (TaskCanceledException) { break; }
            }
        }
    }
}
