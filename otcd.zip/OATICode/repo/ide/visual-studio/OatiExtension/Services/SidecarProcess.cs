// Copyright OATI Technology. MIT-licensed.

using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace Oati.VisualStudio.Services
{
    /// <summary>
    /// Auto-spawns the Node-based <c>@oati/agent-service</c> sidecar on
    /// extension load so the user never has to manually start it.
    ///
    /// Lifecycle:
    ///   1. Picks an OS-assigned free localhost port (no collisions when
    ///      multiple VS instances run simultaneously).
    ///   2. Generates a per-instance bearer token; the same token is
    ///      passed to <see cref="OatiServiceClient"/> via
    ///      <see cref="BaseUrl"/> + <see cref="AuthToken"/>.
    ///   3. Spawns <c>node &lt;extensionDir&gt;/sidecar/cli.cjs</c> with
    ///      <c>OATI_SERVICE_HOST</c>, <c>OATI_SERVICE_PORT</c>,
    ///      <c>OATI_SERVICE_TOKEN</c>, and <c>OATI_WORKSPACE_ROOT</c>
    ///      env vars.
    ///   4. Pipes stdout / stderr into the OATI Code output pane.
    ///   5. Polls <c>/v1/health</c> for up to 20s; emits a "ready" event
    ///      to anyone listening so the tool window can stop showing the
    ///      "not reachable" banner.
    ///   6. Restarts on crash with capped exponential backoff (max 5
    ///      consecutive failures).
    ///
    /// The class is intentionally singleton-friendly — call
    /// <see cref="StartAsync"/> from the package's
    /// <c>InitializeAsync</c>; the tool window reads <see cref="BaseUrl"/>
    /// to build its <see cref="OatiServiceClient"/>.
    /// </summary>
    public sealed class SidecarProcess : IDisposable
    {
        private readonly OatiOutputPane _log;
        private readonly object _lock = new();
        private Process? _process;
        private CancellationTokenSource? _cts;
        private int _consecutiveFailures;
        private string? _workspaceRoot;

        public string? BaseUrl { get; private set; }
        public string? AuthToken { get; private set; }
        public bool IsRunning => _process is { HasExited: false };

        public event EventHandler? Ready;

        public SidecarProcess(OatiOutputPane log)
        {
            _log = log;
        }

        /// <summary>
        /// Start (or restart) the sidecar. Safe to call from any thread —
        /// internal locking guarantees only one child process exists.
        /// </summary>
        public async Task StartAsync(string? workspaceRoot)
        {
            lock (_lock)
            {
                if (IsRunning) return;
                _cts = new CancellationTokenSource();
                _workspaceRoot = workspaceRoot;
            }

            var port = FindFreePort();
            var token = GenerateToken();
            var cliPath = ResolveCliPath();
            if (cliPath is null)
            {
                _log.WriteLine(
                    "[sidecar] could not locate cli.cjs alongside the extension. " +
                    "Did you forget to run `npm run build` and bundle the sidecar?");
                return;
            }
            var nodeExe = ResolveNodeExe();
            if (nodeExe is null)
            {
                _log.WriteLine(
                    "[sidecar] node.exe not found on PATH. Install Node 20+ " +
                    "or set OATI_NODE_PATH to the absolute path of node.exe.");
                return;
            }

            var psi = new ProcessStartInfo
            {
                FileName = nodeExe,
                Arguments = $"\"{cliPath}\"",
                WorkingDirectory = Path.GetDirectoryName(cliPath) ?? Environment.CurrentDirectory,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };
            psi.EnvironmentVariables["OATI_SERVICE_HOST"] = "127.0.0.1";
            psi.EnvironmentVariables["OATI_SERVICE_PORT"] = port.ToString();
            psi.EnvironmentVariables["OATI_SERVICE_TOKEN"] = token;
            psi.EnvironmentVariables["OATI_WORKSPACE_ROOT"] = workspaceRoot ?? Environment.CurrentDirectory;

            try
            {
                _process = Process.Start(psi);
            }
            catch (Exception ex)
            {
                _log.WriteLine("[sidecar] Process.Start failed: " + ex.Message);
                return;
            }

            if (_process is null)
            {
                _log.WriteLine("[sidecar] Process.Start returned null.");
                return;
            }

            BaseUrl = $"http://127.0.0.1:{port}";
            AuthToken = token;
            _process.EnableRaisingEvents = true;
            _process.OutputDataReceived += (_, e) =>
            {
                if (!string.IsNullOrEmpty(e.Data)) _log.WriteLine("[sidecar] " + e.Data);
            };
            _process.ErrorDataReceived += (_, e) =>
            {
                if (!string.IsNullOrEmpty(e.Data)) _log.WriteLine("[sidecar:err] " + e.Data);
            };
            _process.Exited += OnExited;
            _process.BeginOutputReadLine();
            _process.BeginErrorReadLine();
            _log.WriteLine(
                $"[sidecar] started pid={_process.Id} port={port} workspace={workspaceRoot ?? "(none)"}");

            await WaitUntilHealthyAsync(_cts?.Token ?? CancellationToken.None).ConfigureAwait(false);
        }

        /// <summary>
        /// Inform the sidecar that the workspace root changed (e.g. the
        /// user opened a different solution). The next agent run will
        /// pick up the new path.
        /// </summary>
        public async Task UpdateWorkspaceAsync(string? newPath)
        {
            _workspaceRoot = newPath;
            if (!IsRunning || BaseUrl is null) return;
            try
            {
                using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(2) };
                if (!string.IsNullOrEmpty(AuthToken))
                {
                    http.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue("Bearer", AuthToken);
                }
                var body = "{\"workspaceRoot\":\"" + (newPath ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"}";
                using var content = new StringContent(body, System.Text.Encoding.UTF8, "application/json");
                await http.PostAsync(BaseUrl + "/v1/workspace", content).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _log.WriteLine("[sidecar] workspace update failed: " + ex.Message);
            }
        }

        private void OnExited(object? sender, EventArgs e)
        {
            var exitCode = _process?.ExitCode ?? -1;
            _log.WriteLine($"[sidecar] exited code={exitCode}");
            _process = null;
            BaseUrl = null;
            AuthToken = null;

            _consecutiveFailures++;
            if (_consecutiveFailures > 5)
            {
                _log.WriteLine("[sidecar] giving up after 5 consecutive crashes");
                return;
            }
            var delaySec = Math.Min(30, 1 << Math.Min(5, _consecutiveFailures));
            _ = Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(TimeSpan.FromSeconds(delaySec)).ConfigureAwait(false);
                    await StartAsync(_workspaceRoot).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _log.WriteLine("[sidecar] restart failed: " + ex.Message);
                }
            });
        }

        private async Task WaitUntilHealthyAsync(CancellationToken ct)
        {
            if (BaseUrl is null) return;
            using var http = new HttpClient { Timeout = TimeSpan.FromMilliseconds(800) };
            if (!string.IsNullOrEmpty(AuthToken))
            {
                http.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", AuthToken);
            }
            var deadline = DateTime.UtcNow.AddSeconds(20);
            while (DateTime.UtcNow < deadline && !ct.IsCancellationRequested)
            {
                try
                {
                    using var resp = await http.GetAsync(BaseUrl + "/v1/health", ct).ConfigureAwait(false);
                    if (resp.IsSuccessStatusCode)
                    {
                        _consecutiveFailures = 0;
                        _log.WriteLine("[sidecar] healthy");
                        Ready?.Invoke(this, EventArgs.Empty);
                        return;
                    }
                }
                catch
                {
                    // not yet listening — back off
                }
                await Task.Delay(300, ct).ConfigureAwait(false);
            }
            _log.WriteLine("[sidecar] never reported healthy within 20s — UI will retry on user action");
        }

        // ------------------------------------------------------------------
        // Resolution helpers
        // ------------------------------------------------------------------

        private static int FindFreePort()
        {
            // OS-assigned ephemeral port — guaranteed free at probe time.
            var listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Start();
            try
            {
                return ((IPEndPoint)listener.LocalEndpoint).Port;
            }
            finally
            {
                listener.Stop();
            }
        }

        private static string GenerateToken()
        {
            // 24 random bytes → 48 hex chars. Plenty of entropy to keep
            // other localhost processes from spoofing the sidecar.
            var bytes = new byte[24];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(bytes);
            return BitConverter.ToString(bytes).Replace("-", "").ToLowerInvariant();
        }

        private static string? ResolveCliPath()
        {
            // The VSIX install layout places the bundled sidecar at
            //   <extension>/sidecar/cli.cjs
            // We resolve relative to the assembly's location so it works
            // whether VS extracted us to %LOCALAPPDATA% or a custom dir.
            var asm = Assembly.GetExecutingAssembly().Location;
            var baseDir = Path.GetDirectoryName(asm);
            if (baseDir is null) return null;

            // First-choice path is `<ext>/sidecar/cli.cjs` (what the
            // OatiExtension.csproj content-includes layout produces).
            // Fall back to `<ext>/sidecar/agent-service/cli.cjs` for
            // older packaging layouts.
            string[] candidates =
            {
                Path.Combine(baseDir, "sidecar", "cli.cjs"),
                Path.Combine(baseDir, "sidecar", "agent-service", "cli.cjs"),
                Path.Combine(baseDir, "agent-service", "dist", "cli.cjs"),
            };
            foreach (var p in candidates)
            {
                if (File.Exists(p)) return p;
            }
            return null;
        }

        private static string? ResolveNodeExe()
        {
            // Honor an explicit override first — useful when the user
            // installs Node into a non-PATH location (e.g. nvm-windows
            // with a freshly switched version).
            var overridePath = Environment.GetEnvironmentVariable("OATI_NODE_PATH");
            if (!string.IsNullOrEmpty(overridePath) && File.Exists(overridePath))
            {
                return overridePath;
            }
            var pathVar = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (var dir in pathVar.Split(Path.PathSeparator))
            {
                if (string.IsNullOrWhiteSpace(dir)) continue;
                var candidate = Path.Combine(dir, "node.exe");
                if (File.Exists(candidate)) return candidate;
            }
            // Well-known install locations.
            var pf = Environment.GetEnvironmentVariable("ProgramFiles") ?? "C:\\Program Files";
            var direct = Path.Combine(pf, "nodejs", "node.exe");
            if (File.Exists(direct)) return direct;
            return null;
        }

        public void Dispose()
        {
            try
            {
                _cts?.Cancel();
                if (_process is { HasExited: false })
                {
                    _process.Kill();
                }
            }
            catch
            {
                // best-effort during shutdown
            }
            finally
            {
                _process?.Dispose();
                _process = null;
                _cts?.Dispose();
                _cts = null;
            }
        }
    }
}
