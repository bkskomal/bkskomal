# Bundles packages/webview-ui/dist into ide/visual-studio/OatiExtension/webview/
# so the VSIX ships the same Preact bundle the VS Code extension uses.
#
# Run from anywhere; resolves paths relative to the script.

[CmdletBinding()]
param(
	[switch]$SkipBuild
)

$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Resolve-Path (Join-Path $scriptDir '..\..\..')
$webviewUi = Join-Path $repoRoot 'packages\webview-ui'
$dist = Join-Path $webviewUi 'dist'
$target = Join-Path $scriptDir '..\OatiExtension\webview'
$target = Resolve-Path -LiteralPath $target -ErrorAction SilentlyContinue
if (-not $target) {
	$target = (Join-Path $scriptDir '..\OatiExtension\webview')
	New-Item -ItemType Directory -Path $target -Force | Out-Null
	$target = Resolve-Path -LiteralPath $target
}

if (-not $SkipBuild) {
	Write-Host "[bundle-webview] building webview-ui..."
	Push-Location $webviewUi
	try {
		# Invoke npm through cmd.exe to avoid a PowerShell quirk where the call
		# operator + Out-Host pipe occasionally mangles the first argument when
		# talking to .cmd shims (we'd see "Unknown command: 'pm'" instead of
		# 'run build').
		cmd /c "npm run build"
		if ($LASTEXITCODE -ne 0) { throw "webview-ui build failed (exit $LASTEXITCODE)" }
	}
	finally {
		Pop-Location
	}
}

if (-not (Test-Path $dist)) {
	throw "webview-ui dist not found at $dist. Run 'npm run build --workspace=@oati/webview-ui' first."
}

Write-Host "[bundle-webview] copying $dist -> $target"
Remove-Item -Path (Join-Path $target '*') -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path (Join-Path $dist '*') -Destination $target -Recurse -Force

# Generate the HTML wrapper that boots the bundle inside WebView2.
$indexHtml = @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>OATI Code</title>
<link rel="stylesheet" href="styles.css" />
</head>
<body>
<div id="root"></div>
<script src="main.js"></script>
</body>
</html>
'@
$indexPath = Join-Path $target 'index.html'
Set-Content -Path $indexPath -Value $indexHtml -Encoding UTF8 -NoNewline:$false

$jsBytes = (Get-Item (Join-Path $target 'main.js')).Length
$cssBytes = (Get-Item (Join-Path $target 'styles.css')).Length
Write-Host ("[bundle-webview] done: main.js {0:N0} bytes, styles.css {1:N0} bytes" -f $jsBytes, $cssBytes)
