<#
.SYNOPSIS
    One-shot build of the OATI Code Visual Studio extension. Runs `npm run
    build` for the JS bundles, locates MSBuild via vswhere (no PATH setup
    required), and produces bin\Release\net472\OatiExtension.vsix.

.DESCRIPTION
    Resolves MSBuild the same way Visual Studio installers do — by
    asking the official vswhere.exe shipped at
    "%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe".
    Works against any 2022 SKU (Community, Pro, Enterprise, Build Tools).

.PARAMETER Configuration
    Build configuration. Default: Release.

.PARAMETER SkipNpm
    Skip the `npm run build` step. Use when you've already produced the
    webview-ui / agent-service bundles and just want to repackage the VSIX.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\build-vsix.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\build-vsix.ps1 -SkipNpm
#>

[CmdletBinding()]
param(
    [ValidateSet('Debug','Release')]
    [string]$Configuration = 'Release',

    [switch]$SkipNpm
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Repo root + project layout
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot    = (Resolve-Path (Join-Path $ScriptDir '..\..\..')).Path
$VsExtensionRoot = (Resolve-Path (Join-Path $ScriptDir '..')).Path
$ProjectPath = Join-Path $VsExtensionRoot 'OatiExtension\OatiExtension.csproj'

function Resolve-MSBuild {
    # Honor an explicit override if the user knows where their MSBuild lives.
    $envMsbuild = $env:OATI_MSBUILD_PATH
    if ($envMsbuild -and (Test-Path $envMsbuild)) { return $envMsbuild }

    # vswhere is the canonical resolver. It's at a stable path on every
    # machine that has VS 2017+ Build Tools or the IDE installed.
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path $vswhere)) {
        $vswhere = Join-Path $env:ProgramFiles 'Microsoft Visual Studio\Installer\vswhere.exe'
    }
    if (-not (Test-Path $vswhere)) {
        throw @"
vswhere.exe not found. Install one of:
  - Visual Studio 2022 (any edition) with the "Visual Studio extension development" workload
  - Visual Studio 2022 Build Tools (smaller, no IDE)

Or set OATI_MSBUILD_PATH to the absolute path of your MSBuild.exe.
"@
    }

    # Ask vswhere for the latest VS install that has MSBuild bundled.
    $installPath = & $vswhere -latest `
        -prerelease `
        -requires Microsoft.Component.MSBuild `
        -property installationPath
    if ([string]::IsNullOrWhiteSpace($installPath)) {
        throw "No Visual Studio 2022 install with MSBuild found. Install the 'Visual Studio extension development' workload."
    }
    # Walk the standard layout. Current/Bin is the active release; if a
    # preview-only SKU returns nothing there, fall through to the legacy 15.0 path.
    $candidates = @(
        (Join-Path $installPath 'MSBuild\Current\Bin\MSBuild.exe'),
        (Join-Path $installPath 'MSBuild\15.0\Bin\MSBuild.exe')
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { return $c }
    }
    throw "Found VS at $installPath but couldn't locate MSBuild.exe under MSBuild\Current\Bin or MSBuild\15.0\Bin."
}

function Step([string]$Name) {
    Write-Host ""
    Write-Host "▸ $Name" -ForegroundColor Cyan
}

# ------------------------------------------------------------------
# 1. Build the JS bundles (npm)
# ------------------------------------------------------------------
if (-not $SkipNpm) {
    Step "npm install + npm run build (in $RepoRoot)"
    Push-Location $RepoRoot
    try {
        if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
            throw "npm not found on PATH. Install Node 20+ from https://nodejs.org or use nvm-windows."
        }
        & npm install
        if ($LASTEXITCODE -ne 0) { throw "npm install failed (exit $LASTEXITCODE)" }
        & npm run build
        if ($LASTEXITCODE -ne 0) { throw "npm run build failed (exit $LASTEXITCODE)" }
    }
    finally { Pop-Location }
} else {
    Step "Skipping npm step (SkipNpm requested)"
}

# Sanity-check the produced artifacts the VSIX bundles in.
$sidecarCli = Join-Path $RepoRoot 'packages\agent-service\dist\cli.cjs'
$webviewIdx = Join-Path $RepoRoot 'packages\webview-ui\dist\index.html'
if (-not (Test-Path $sidecarCli)) {
    Write-Warning "agent-service\dist\cli.cjs missing — extension will install but the sidecar won't spawn."
}
if (-not (Test-Path $webviewIdx)) {
    Write-Warning "webview-ui\dist\index.html missing — tool window will show the 'bundle not found' page."
}

# ------------------------------------------------------------------
# 2. Resolve + run MSBuild
# ------------------------------------------------------------------
$msbuild = Resolve-MSBuild
Step "Building VSIX with $msbuild"
Write-Host "Project       : $ProjectPath"
Write-Host "Configuration : $Configuration"

& $msbuild $ProjectPath '/t:Restore;Rebuild' "/p:Configuration=$Configuration" '/nologo' '/v:minimal'
if ($LASTEXITCODE -ne 0) {
    throw "MSBuild failed (exit $LASTEXITCODE)"
}

# ------------------------------------------------------------------
# 3. Report output
# ------------------------------------------------------------------
$vsix = Join-Path $VsExtensionRoot "OatiExtension\bin\$Configuration\net472\OatiExtension.vsix"
if (Test-Path $vsix) {
    $size = (Get-Item $vsix).Length / 1KB
    Write-Host ""
    Write-Host "✓ Built: $vsix" -ForegroundColor Green
    Write-Host ("  size : {0:N1} KB" -f $size)
    Write-Host ""
    Write-Host "Install: double-click the .vsix to launch VSIX Installer," -ForegroundColor Gray
    Write-Host "         then restart Visual Studio." -ForegroundColor Gray
} else {
    throw "Build reported success but VSIX is missing at $vsix"
}
