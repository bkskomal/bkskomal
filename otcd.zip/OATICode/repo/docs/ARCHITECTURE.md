# Architecture

OATI Code is a TypeScript monorepo with one C# project. Every IDE shell is a thin layer that constructs a `HostContext` (fs, exec, approval, diff), registers tools and providers, instantiates a `Conductor`, and bridges its UI to agent events.

This document is the orientation read for contributors. For end-user-facing structure, see the [README](../README.md).

## One-paragraph version

`agent-core` is pure TypeScript with zero IDE dependencies. It owns the agent loop, the conductor (multi-agent coordinator), and registries for tools and providers. The VS Code shell (`extension-host`) constructs a `HostContext` from the editor API, wires `ChatPanel` ↔ `Conductor`, and serializes agent events to a Preact webview over a typed RPC bus. The same conductor is wrapped as an HTTP+SSE service (`@oati/agent-service`) so non-Node IDEs (Visual Studio today, JetBrains tomorrow) can consume it without re-implementing the loop.

## Diagram

```
┌──────────────────────────────────────────────────────────────────────────┐
│ packages/agent-core (pure TS, ZERO IDE imports)                          │
│   Agent · Conductor · ToolRegistry · ProviderRegistry · Stages           │
│   planner-v2 · critic · summarizer · test-driven-loop                    │
└──────┬──────────────────────────────────────────────────────────────────┘
       │
       ├── packages/providers     openai-compatible · anthropic · ollama
       ├── packages/tools         58 single-file plugins, registry.ts
       ├── packages/mcp-client    stdio JSON-RPC + tool registration
       ├── packages/codebase-index   tree-sitter chunker + sqlite store
       └── packages/shared        types · presets · pricing · ui-message
       │
       ▼
┌──────────────────────────────────────────────────────────────────────────┐
│ packages/extension-host (VS Code shell)                                  │
│   ChatPanel · SessionStore · SettingsStore · ProviderManager             │
│   McpManager · MarketplaceManager · CodebaseIndexManager                 │
│   HostContext · DiffProvider · InlineDiff · Composer                     │
│   SecretScanner · AuditLog · Budget · AutoRevertGuard · Policy           │
│   InlineCompletion · HoverExplain · PredictiveEdit                       │
│   DebugBridge · DiagnosticsBridge · NotebookBridge · Hooks               │
└──────┬──────────────────────────────────────────────────────────────────┘
       │ typed RPC bus (@oati/rpc)
       ▼
┌──────────────────────────────────────────────────────────────────────────┐
│ packages/webview-ui (Preact 10 + signals)                                │
│   ChatPanel UI · ApprovalDialog · ComposerPanel · MarketplaceView        │
│   PerfPanel · SettingsPanel · CompareView · MultiFileDiff                │
│   Same bundle runs inside the VS Code webview AND the WebView2 host.     │
└──────────────────────────────────────────────────────────────────────────┘

         ┌─────────────────────────────────────────────┐
         │ packages/agent-service (Node HTTP+SSE)      │
         │   wraps the same agent-core Conductor       │
         │   Bearer-token auth, OATI_WORKSPACE_ROOT    │
         └────────────────────┬────────────────────────┘
                              │
                              ▼
              ide/visual-studio (C# VSIX)
              WebView2 hosts the same Preact bundle,
              OatiServiceClient streams events back.
```

## Package layout

```
OATICodingAssistantReal/
├── packages/
│   ├── shared/            Types + presets + ui-message converter. ZERO runtime aside from preset data.
│   ├── rpc/               Typed Bus<In, Out> for host ↔ webview messages.
│   ├── agent-core/        Agent, Conductor, ToolRegistry, ProviderRegistry, stages (planner-v2, critic).
│   ├── providers/         openai-compatible + anthropic native + ollama flavor.
│   ├── tools/             58 single-file tool plugins + registry.ts.
│   ├── mcp-client/        Model Context Protocol client (stdio JSON-RPC).
│   ├── codebase-index/    Tree-sitter chunker + sqlite-backed embedding store.
│   ├── webview-ui/        Preact + signals chat UI. Markdown rendering, inline diff, MCP UI.
│   ├── extension-host/    The VS Code shell. See below for the file roster.
│   └── agent-service/     Standalone HTTP+SSE wrapper around agent-core.
└── ide/
    └── visual-studio/     C# VSIX. WebView2 hosts the webview bundle, OatiServiceClient streams events.
```

## Architectural rules

These are checked by typecheck + biome + tests; PRs that violate them get flagged.

1. **`agent-core` has zero IDE imports.** No `import * as vscode`. The loop must remain reusable in agent-service.
2. **`webview-ui` only talks to host via `@oati/rpc`.** No direct file system, no direct provider calls, no `fetch`.
3. **`shared/` is types-only**, with the exception of preset data and the conversation→UiMessage converter (pure functions, no side effects).
4. **Tools are single-file plugins** in `packages/tools/src/*.ts`. Add by writing a file + appending to `registry.ts`. No central switch.
5. **Providers are single-file plugins** dispatched by `ProviderType` through `factory.ts`.
6. **Every feature is configurable on/off.** Planner, critic, parallel agents, MCP servers, inline completion — all gated by config flags.
7. **API keys live in SecretStorage / DPAPI.** The webview only sees `hasApiKey: boolean`.
8. **Per-tool approval policy:** `auto` (silent), `prompt` (asks user), `deny` (always refuse). Modes can override.

## The conductor + agent loop

```
Conductor.run(userMessage)
  └── Agent.run(systemPrompt + history + tools)
       └── for iter in 0..maxIterations:
            ├── provider.streamCompletion(...)
            ├── parse tool_call(s) from the response
            ├── for each tool_call:
            │    ├── policy check (.oati/policy.yaml + mode.enabledTools)
            │    ├── hook PreToolUse (if blocking)
            │    ├── requestApproval (if approval == "prompt" and !autoApprove)
            │    ├── tool.handler(args, hostContext)
            │    └── hook PostToolUse (fire-and-forget unless blocking)
            ├── if response has no tool_call → break
            └── feed tool results back as next turn
```

The conductor adds:

- **Stages** — optional planner-v2 (system-prompt injection or dedicated planner model) and critic (post-turn review with retry budget).
- **Sub-agents** — `spawn_agent` / `spawn_parallel_agents` re-enter the conductor with a fresh history and bounded iteration cap.
- **Cost accounting** — every dispatch reports tokens; the budget module enforces session/day/model caps and refuses dispatch past hard ceilings.
- **Audit pass** — every tool call and every dispatched message is recorded to `.oati/audit.log`.

## RPC bus

`@oati/rpc` is a tiny typed message bus. `WebviewToHost` and `HostToWebview` are discriminated unions in `packages/shared/src/messages.ts`. The bus is duplex and order-preserving; no broker, no schema validation at runtime (the types are the contract).

Pattern:

```ts
// host
bus.send({ type: "agent_event", event: "tool_started", ... });
bus.on("user_message", (msg) => agent.run(msg.content));

// webview
bus.send({ type: "user_message", content: input });
bus.on("agent_event", (e) => render(e));
```

## Provider abstraction

`Provider` in `agent-core` is a narrow interface:

```ts
interface Provider {
  streamCompletion(req): AsyncIterable<ProviderEvent>;
  estimateCost(req): EstimatedCost;        // optional
  countTokens(text): number;               // optional
}
```

`providers/factory.ts` switches on `ProviderType` (`"openai-compatible"` | `"anthropic"`) and instantiates the right adapter. Adding a third native provider is a single-file change plus a switch case.

## Tool abstraction

`ToolSpec` in `shared/tools.ts`:

```ts
interface ToolSpec<Args, Result> {
  name: string;
  description: string;
  schema: JsonSchema;                     // JSON Schema for `Args`
  approval: "auto" | "prompt" | "deny";
  handler: (args, ctx, callCtx?) => Promise<Result>;
  prepareApprovalPreview?: (args, ctx) => Promise<ApprovalPreview>;
  scope?: "sub-agent";                    // restrict to spawn_parallel_agents subagents
}
```

The host wires:

- `ctx.fs.readFile`, `ctx.fs.writeFile`, `ctx.fs.list`, `ctx.fs.stat` — abstract filesystem.
- `ctx.exec(cmd, opts)` — shell execution.
- `ctx.requestApproval(...)` — pops the dialog.
- `ctx.showDiff(...)` — opens the native diff editor.
- `ctx.emitToolProgress(...)` — streams partial output to the chat.

Tools never `import * as vscode` directly — they only see the `HostContext`. This is what lets the same tool code run inside the VS Code extension AND `agent-service`.

## The webview

`packages/webview-ui` is a single-bundle Preact 10 app with signals for state. It auto-detects whether it's running inside the VS Code webview API or a WebView2 control and picks the appropriate transport. The exact same bundle (`dist/main.js` + `dist/styles.css`) ships in both shells.

Key components:

- `app.tsx` — top-level state, message dispatch, slash-command catalog.
- `components/approval-dialog.tsx` — tool approval with inline diff.
- `components/composer-panel.tsx` — multi-file generation.
- `components/marketplace-view.tsx` — MCP marketplace.
- `components/perf-panel.tsx` — performance HUD.
- `components/settings-panel.tsx` — providers/modes/MCP/hooks/budget.
- `components/compare-view.tsx` — side-by-side dual-provider compare.

## Standalone service

`@oati/agent-service` exposes the same conductor as an HTTP+SSE API:

```
GET  /v1/health            → { status: "ok" }
GET  /v1/tools             → { tools: [{name, description, schema}, ...] }
POST /v1/agent/run         → SSE stream of AgentEvent
```

Auth: `Authorization: Bearer ${OATI_SERVICE_TOKEN}`. Workspace root pinned by `OATI_WORKSPACE_ROOT`. The Visual Studio extension talks to this; future JetBrains and CLI shells will too.

## Building

esbuild bundles every workspace that ships code (extension-host, webview-ui, agent-service). No webpack, no rollup. Bundle sizes are budgeted in `bundle-budgets.json` and enforced in CI (`scripts/check-bundle-size.mjs`).

```powershell
npm install
npm run build           # builds all workspaces
npm run typecheck       # tsc --noEmit per workspace
npm test                # vitest run (798 tests)
npm run lint            # biome check .
```

## Testing

Vitest. 798 tests across ~84 files at 0.1.0:

- `packages/agent-core/tests/` — loop semantics, stages, summarizer, test-driven loop.
- `packages/providers/tests/` — SSE parsing for OpenAI-compatible and Anthropic.
- `packages/tools/tests/` — every built-in tool has at least one happy path + one failure path.
- `packages/mcp-client/tests/` — JSON-RPC framing, capability negotiation.
- `packages/extension-host/tests/` — host modules with mocked `vscode` namespace.
- `packages/shared/tests/` — presets, pricing, ui-message converter, agent events.

There's also a `packages/extension-host/test-electron/` runner for end-to-end webview tests (out of scope for this round; documented separately).

## Where to start when adding a feature

| Feature kind | Start here |
|---|---|
| New built-in tool | `packages/tools/src/<name>.ts` + append to `registry.ts` + `node scripts/gen-tools-doc.mjs`. |
| New provider | `packages/providers/src/<name>.ts` + switch in `factory.ts` + preset in `shared/presets.ts`. |
| New slash command | `packages/webview-ui/src/app.tsx` — append to `slashCommands` array; wire host handler in `chat-panel.ts`. |
| New mode | `packages/shared/src/config.ts` — append to `DEFAULT_CONFIG.modes`. |
| New persona | `packages/extension-host/src/personas.ts` — append to `PERSONAS`. |
| New MCP marketplace entry | `packages/extension-host/src/mcp-registry.ts` — append to `MCP_REGISTRY`. |
| New `oati.*` setting | `packages/extension-host/package.json` (`contributes.configuration`) + read it in the relevant module. |

## See also

- [CONFIGURATION.md](CONFIGURATION.md) — config shapes.
- [TOOLS.md](TOOLS.md) — auto-generated tool catalog.
- [SECURITY.md](SECURITY.md) — threat model.
- [MCP.md](MCP.md) — MCP server integration.
- [`CLAUDE.md`](../CLAUDE.md) — engineering notes for contributors and AI assistants.
