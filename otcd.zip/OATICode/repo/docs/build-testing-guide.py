"""Generate OATI_Code_Testing_Guide.docx — full install/test instructions
for VS Code (dev + .vsix + marketplace) and Visual Studio 2022.

Run with:
    python docs/build-testing-guide.py
The doc is written next to this script as docs/OATI_Code_Testing_Guide.docx.
"""
from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, RGBColor, Inches

OUT = Path(__file__).parent / "OATI_Code_Testing_Guide.docx"


# --------------- helpers ---------------------------------------------------


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)


def add_para(doc: Document, text: str, *, bold: bool = False, italic: bool = False) -> None:
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.size = Pt(11)
    r.bold = bold
    r.italic = italic


def add_bullet(doc: Document, text: str, level: int = 0) -> None:
    p = doc.add_paragraph(text, style="List Bullet" if level == 0 else "List Bullet 2")
    for r in p.runs:
        r.font.size = Pt(11)


def add_numbered(doc: Document, text: str) -> None:
    p = doc.add_paragraph(text, style="List Number")
    for r in p.runs:
        r.font.size = Pt(11)


def add_code(doc: Document, code: str) -> None:
    """Insert a code block as a single light-gray-shaded paragraph in monospace."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.left_indent = Inches(0.25)
    pf.space_before = Pt(4)
    pf.space_after = Pt(8)
    # Add a light gray shading via XML
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), "F2F2F2")
    pPr.append(shd)
    r = p.add_run(code)
    r.font.name = "Consolas"
    rPr = r._r.get_or_add_rPr()
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), "Consolas")
    rFonts.set(qn("w:hAnsi"), "Consolas")
    rFonts.set(qn("w:cs"), "Consolas")
    rPr.append(rFonts)
    r.font.size = Pt(10)
    r.font.color.rgb = RGBColor(0x1F, 0x1F, 0x1F)


def add_inline_code(p, text: str) -> None:
    r = p.add_run(text)
    r.font.name = "Consolas"
    r.font.size = Pt(10)
    rPr = r._r.get_or_add_rPr()
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), "Consolas")
    rFonts.set(qn("w:hAnsi"), "Consolas")
    rFonts.set(qn("w:cs"), "Consolas")
    rPr.append(rFonts)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), "F2F2F2")
    rPr.append(shd)


def add_note(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), "FFF8E1")
    pPr.append(shd)
    r = p.add_run("NOTE: ")
    r.bold = True
    r.font.size = Pt(11)
    r2 = p.add_run(text)
    r2.font.size = Pt(11)


def add_table(doc: Document, headers: list[str], rows: list[list[str]]) -> None:
    t = doc.add_table(rows=1 + len(rows), cols=len(headers))
    t.style = "Light Grid Accent 1"
    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = h
        for p in hdr[i].paragraphs:
            for r in p.runs:
                r.bold = True
                r.font.size = Pt(11)
    for ri, row in enumerate(rows, start=1):
        cells = t.rows[ri].cells
        for ci, val in enumerate(row):
            cells[ci].text = val
            for p in cells[ci].paragraphs:
                for r in p.runs:
                    r.font.size = Pt(10)


def add_page_break(doc: Document) -> None:
    doc.add_page_break()


def add_toc(doc: Document) -> None:
    """Insert a real Word Table of Contents field.

    Word builds the actual list (with page numbers) when the user opens the doc
    and accepts the "Update fields" prompt, or with right-click → Update Field.
    """
    p = doc.add_paragraph()

    def _run_with(child: OxmlElement) -> None:
        r = OxmlElement("w:r")
        r.append(child)
        p._p.append(r)

    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    begin.set(qn("w:dirty"), "true")
    _run_with(begin)

    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = 'TOC \\o "1-3" \\h \\z \\u'
    _run_with(instr)

    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    _run_with(sep)

    # Placeholder text shown until Word updates the field.
    placeholder_run = OxmlElement("w:r")
    pt = OxmlElement("w:t")
    pt.text = "Right-click here → Update Field to populate the Table of Contents."
    placeholder_run.append(pt)
    p._p.append(placeholder_run)

    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    _run_with(end)


def enable_auto_update_fields(doc: Document) -> None:
    """Tell Word to refresh fields (including the TOC) on document open."""
    settings = doc.settings.element
    upd = OxmlElement("w:updateFields")
    upd.set(qn("w:val"), "true")
    settings.append(upd)


# --------------- content ---------------------------------------------------


def build_doc() -> Document:
    doc = Document()

    # Base style
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    # --- Title page ------------------------------------------------------
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t = title.add_run("OATI Code")
    t.font.size = Pt(40)
    t.bold = True
    t.font.color.rgb = RGBColor(0x6E, 0x2C, 0xCF)

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    s = subtitle.add_run("Testing & Installation Guide")
    s.font.size = Pt(20)
    s.font.color.rgb = RGBColor(0x06, 0xB6, 0xD4)

    tag = doc.add_paragraph()
    tag.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tr = tag.add_run(
        "Configurable agentic coding assistant — VS Code (dev / VSIX / Marketplace) "
        "and Visual Studio 2022."
    )
    tr.font.size = Pt(11)
    tr.italic = True

    for _ in range(2):
        doc.add_paragraph()

    add_heading(doc, "Table of Contents", level=1)
    add_para(
        doc,
        "Word builds the page-numbered list below from the document's headings. "
        "When you open this file Word will offer to update fields — click Yes. "
        "Otherwise, right-click the placeholder → Update Field.",
        italic=True,
    )
    add_toc(doc)

    add_page_break(doc)

    # --- 1. Layout & prerequisites --------------------------------------
    add_heading(doc, "1. Repository layout & prerequisites", level=1)

    add_para(doc, "Repository root:")
    add_code(doc, r"E:\AI\Self\OATICodingAssistantReal")

    add_para(doc, "Key paths used throughout this guide:")
    add_table(
        doc,
        ["Path", "Purpose"],
        [
            ["packages/extension-host", "VS Code extension (TypeScript)"],
            ["packages/webview-ui", "Shared Preact chat UI bundle"],
            ["packages/agent-service", "HTTP+SSE service consumed by Visual Studio"],
            ["packages/agent-core", "Pure TypeScript agent loop (zero IDE deps)"],
            ["ide/visual-studio/OatiExtension", "Visual Studio 2022 VSIX project (C#)"],
            ["ide/visual-studio/scripts/bundle-webview.ps1", "Copies webview bundle into the VSIX"],
            ["dist/oati-coding-assistant.vsix", "Built VS Code package (after Section 3)"],
        ],
    )

    add_heading(doc, "Prerequisites (common)", level=2)
    add_bullet(doc, "Windows 10/11 with PowerShell 5+ or PowerShell 7")
    add_bullet(doc, "Node.js 20+ and npm 10+ (verify with `node -v` and `npm -v`)")
    add_bullet(doc, "Git for Windows")
    add_bullet(doc, "Microsoft Edge WebView2 Runtime (preinstalled on Windows 11)")

    add_heading(doc, "First-time setup", level=2)
    add_numbered(doc, "Open a regular PowerShell terminal.")
    add_numbered(doc, "cd into the repo root.")
    add_code(doc, "cd E:\\AI\\Self\\OATICodingAssistantReal")
    add_numbered(doc, "Install dependencies for all workspaces:")
    add_code(doc, "npm install")
    add_numbered(doc, "Build everything once to verify a clean state:")
    add_code(doc, "npm run build")
    add_numbered(doc, "Run the test suite — expect 154 passing tests across 22 files.")
    add_code(doc, "npm test")

    add_page_break(doc)

    # --- 2. VS Code F5 ---------------------------------------------------
    add_heading(doc, "2. VS Code — develop and test (F5)", level=1)
    add_para(
        doc,
        "F5 is the fastest path: VS Code launches an Extension Development Host "
        "window with the latest source loaded, and reloads on demand. Nothing is "
        "installed into your real VS Code profile.",
    )

    add_heading(doc, "Prerequisites", level=2)
    add_bullet(doc, "VS Code 1.90 or later")
    add_bullet(doc, "Common setup from Section 1 already done")

    add_heading(doc, "Steps", level=2)
    add_numbered(doc, "Open the repository in VS Code:")
    add_code(doc, "code E:\\AI\\Self\\OATICodingAssistantReal")
    add_numbered(
        doc,
        "When VS Code asks about the recommended extensions, accept them (it just "
        "ensures the Biome extension is suggested; the build works without it).",
    )
    add_numbered(
        doc,
        "Press F5. The first run prompts you to pick a debug configuration — "
        'choose "Extension Development Host". A second VS Code window opens with '
        "[Extension Development Host] in the title bar.",
    )
    add_numbered(
        doc,
        "Inside the dev host, click the new OATI Code icon in the Activity Bar "
        "(left edge — the violet/cyan gradient with the orbiting agents mark). "
        "The Chats tree view appears.",
    )
    add_numbered(
        doc,
        "Click the + button in the tree title to open a new chat tab. The chat "
        "opens in the editor area beside your source.",
    )
    add_numbered(
        doc,
        "Click the gear icon in the chat header → Settings. Pick a provider "
        "preset (OpenRouter is easiest), paste an API key, set a Model ID, then "
        'click "Test Connection". You should see a 200 OK from /models.',
    )
    add_numbered(doc, "Go back to chat and send a message. Watch:")
    add_bullet(doc, "Tool calls render as collapsible cards instead of dumping file contents", level=1)
    add_bullet(doc, "Live progress strip shows the current tool / iteration", level=1)
    add_bullet(doc, "Mode pill (Ask / Plan / Code / Auto Edit / Full Auto) at the bottom-right", level=1)
    add_bullet(doc, "Markdown tables and code blocks render correctly", level=1)

    add_heading(doc, "Iterating while the dev host is open", level=2)
    add_bullet(doc, "Edit TypeScript in the original window")
    p = doc.add_paragraph(style="List Bullet")
    p.add_run("Rebuild the changed package: ")
    add_inline_code(p, "npm run build --workspace=@oati/webview-ui")
    add_bullet(doc, "In the dev host: Ctrl+R reloads the webview / extension")

    add_note(
        doc,
        "Edits to the extension-host code require an extension reload "
        "(Ctrl+R in the dev host). Webview-only changes (Preact UI) also need "
        "the bundle to be rebuilt first; esbuild's `npm run watch` in webview-ui "
        "keeps it incremental.",
    )

    add_page_break(doc)

    # --- 3. VS Code .vsix ------------------------------------------------
    add_heading(doc, "3. VS Code — build and install a .vsix locally", level=1)
    add_para(
        doc,
        "The .vsix is a self-contained installer you can hand to a teammate or "
        "install on your machine without publishing to the Marketplace.",
    )

    add_heading(doc, "Build the .vsix", level=2)
    add_numbered(doc, "From a regular PowerShell at the repo root:")
    add_code(doc, "npm run build")
    add_numbered(doc, "Package the extension host workspace into a .vsix:")
    add_code(doc, "npm run package --workspace=oati-coding-assistant")
    add_para(doc, "The output lands at:")
    add_code(doc, r"dist\oati-coding-assistant.vsix")

    add_heading(doc, "Install the .vsix into VS Code", level=2)
    add_para(doc, "There are three equivalent options:")

    add_para(doc, "Option A — from the command line:", bold=True)
    add_code(doc, "code --install-extension dist\\oati-coding-assistant.vsix")

    add_para(doc, "Option B — from the VS Code UI:", bold=True)
    add_numbered(doc, "Open the Extensions view (Ctrl+Shift+X).")
    add_numbered(doc, 'Click the "…" menu in the top-right of the Extensions sidebar.')
    add_numbered(doc, "Choose 'Install from VSIX…' and pick the file.")

    add_para(doc, "Option C — drag & drop:", bold=True)
    add_numbered(doc, "Drag the .vsix file into the Extensions sidebar.")

    add_para(doc, "VS Code may prompt you to reload — accept.")

    add_heading(doc, "Verify the install", level=2)
    add_bullet(doc, 'The "OATI Code" icon appears in the Activity Bar.')
    add_bullet(doc, "Command palette (Ctrl+Shift+P) → searching `OATI` shows the commands.")
    add_bullet(doc, "Settings → Extensions → OATI Code is listed.")

    add_heading(doc, "Uninstall", level=2)
    add_code(doc, "code --uninstall-extension oati.oati-coding-assistant")
    add_para(doc, "Or right-click the extension in the sidebar → Uninstall.")

    add_page_break(doc)

    # --- 4. VS Code Marketplace ------------------------------------------
    add_heading(doc, "4. VS Code — publish to the Marketplace", level=1)
    add_para(
        doc,
        "Publishing pushes the .vsix to the Visual Studio Marketplace so anyone "
        "can install OATI Code with one click. You only need to do this once you "
        "are confident in a release.",
    )

    add_heading(doc, "One-time setup", level=2)
    add_numbered(
        doc,
        "Create an Azure DevOps organization if you don't have one: "
        "https://dev.azure.com.",
    )
    add_numbered(
        doc,
        "Generate a Personal Access Token (PAT): User settings → Personal access "
        "tokens → New Token. Organization = All accessible organizations. "
        "Scopes → Marketplace → Manage. Copy the token immediately; it is shown only once.",
    )
    add_numbered(
        doc,
        "Create a publisher in the Marketplace management portal "
        "(https://marketplace.visualstudio.com/manage). The publisher ID must "
        "match the `publisher` field in packages/extension-host/package.json "
        "(currently `oati`).",
    )
    add_numbered(doc, "Log in vsce with your PAT (once per machine):")
    add_code(doc, "npx @vscode/vsce login oati")
    add_para(doc, "Paste the PAT when prompted.")

    add_heading(doc, "Pre-publish checklist", level=2)
    add_bullet(doc, "Bump the version in packages/extension-host/package.json")
    add_bullet(doc, "Update README.md if user-facing behavior changed")
    add_bullet(doc, "Run `npm run build`, `npm test`, `npm run lint` — all must pass")
    add_bullet(doc, "Confirm packages/extension-host/assets/icon.png exists (128×128)")
    add_bullet(doc, "Smoke-test the .vsix locally (Section 3) before pushing")

    add_heading(doc, "Publish", level=2)
    add_numbered(doc, "Build and publish in one shot:")
    add_code(
        doc,
        "cd packages\\extension-host\nnpx @vscode/vsce publish",
    )
    add_para(
        doc,
        'vsce will package the .vsix and upload it. After ~30 seconds the listing '
        "is live; allow up to 5 minutes for global propagation.",
    )

    add_para(doc, "Specific version bump variants:")
    add_code(
        doc,
        "npx @vscode/vsce publish patch     # 0.1.0 -> 0.1.1\n"
        "npx @vscode/vsce publish minor     # 0.1.0 -> 0.2.0\n"
        "npx @vscode/vsce publish 0.3.0     # explicit",
    )

    add_heading(doc, "Unpublish or hide a bad version", level=2)
    add_code(doc, "npx @vscode/vsce unpublish oati.oati-coding-assistant@0.1.1")
    add_para(
        doc,
        "Prefer publishing a fixed version over unpublishing — Marketplace caches "
        "the bad build for ~24h regardless.",
    )

    add_note(
        doc,
        "Marketplace publishing is irreversible in the sense that the listing "
        "is public from the moment it goes live. Do not publish your first "
        "version until you have run the .vsix install (Section 3) end-to-end "
        "on a clean machine.",
    )

    add_page_break(doc)

    # --- 5. Visual Studio 2022 F5 ---------------------------------------
    add_heading(doc, "5. Visual Studio 2022 — develop and test (F5)", level=1)
    add_para(
        doc,
        "The Visual Studio extension is a thin C# host that loads the same Preact "
        "bundle inside a WebView2 control. The agent loop runs in a separate "
        "Node process (oati-service) that the C# host talks to over HTTP+SSE.",
    )

    add_heading(doc, "Prerequisites", level=2)
    add_bullet(doc, "Visual Studio 2022 (Community/Pro/Enterprise) 17.8 or later")
    add_bullet(doc, "Workload: Visual Studio extension development")
    add_bullet(doc, "Individual component: .NET Framework 4.7.2 targeting pack")
    add_bullet(doc, "Microsoft Edge WebView2 Runtime")

    add_heading(doc, "Step 1 — Rebuild the webview bundle for VS", level=2)
    add_para(
        doc,
        "The VS extension ships the webview as static files inside the VSIX. "
        "Rebundle whenever the Preact UI changes.",
    )
    add_code(
        doc,
        "powershell -ExecutionPolicy Bypass -File "
        "E:\\AI\\Self\\OATICodingAssistantReal\\ide\\visual-studio\\scripts\\bundle-webview.ps1",
    )
    add_para(doc, "Pass -SkipBuild if packages/webview-ui/dist is already current:")
    add_code(
        doc,
        "powershell -ExecutionPolicy Bypass -File "
        "E:\\AI\\Self\\OATICodingAssistantReal\\ide\\visual-studio\\scripts\\bundle-webview.ps1 -SkipBuild",
    )
    add_note(
        doc,
        "Use a regular PowerShell window, not the Package Manager Console "
        "inside Visual Studio. The PMC starts in your solution's directory "
        "(not the repo root), so a relative path like "
        "ide\\visual-studio\\scripts\\... won't resolve. If you must use the "
        "PMC, always pass an absolute path (as shown above).",
    )

    add_heading(doc, "Step 2 — Build the agent service", level=2)
    add_code(doc, "npm run build --workspace=@oati/agent-service")

    add_heading(doc, "Step 3 — Start the agent service", level=2)
    add_para(
        doc,
        "Open a dedicated PowerShell terminal and keep it open for the whole "
        "VS testing session:",
    )
    add_code(
        doc,
        "cd E:\\AI\\Self\\OATICodingAssistantReal\nnpm run start --workspace=@oati/agent-service",
    )
    add_para(doc, "You should see something like:")
    add_code(doc, "oati-service listening on http://127.0.0.1:8765")

    add_heading(doc, "Step 4 — Open the project in Visual Studio", level=2)
    add_para(doc, "There is no .sln file yet. Either:")
    add_bullet(doc, "File → Open → Project/Solution → pick OatiExtension.csproj, or")
    add_bullet(
        doc,
        "Right-click OatiExtension.csproj in Explorer → Open with → Visual Studio 2022.",
    )
    add_para(doc, "Wait for NuGet to finish restoring packages.")

    add_para(doc, "Optional — generate a .sln so VS remembers the layout:", bold=True)
    add_code(
        doc,
        "cd ide\\visual-studio\n"
        "dotnet new sln -n OatiExtension\n"
        "dotnet sln add OatiExtension\\OatiExtension.csproj",
    )

    add_heading(doc, "Step 5 — Build and launch (F5)", level=2)
    add_numbered(doc, "Build → Build Solution (Ctrl+Shift+B) to surface errors early.")
    add_numbered(
        doc,
        "Press F5. A second Visual Studio window opens with "
        "[Experimental Instance] in its title — your extension is loaded there.",
    )

    add_heading(doc, "Step 6 — Open the chat tool window", level=2)
    add_numbered(doc, "In the Experimental Instance: Tools → OATI: Open Chat.")
    add_numbered(
        doc,
        "A dockable tool window appears. Drag it to a side dock if you want it pinned.",
    )
    add_numbered(
        doc,
        "Inside the tool window the same Preact UI loads as in VS Code — "
        "header, mode pill, composer, etc.",
    )

    add_heading(doc, "Step 7 — Configure and chat", level=2)
    add_numbered(doc, "Click the gear icon → Settings.")
    add_numbered(doc, "Pick a provider, paste API key, set Model ID.")
    add_numbered(doc, 'Click "Test Connection" — it should hit the agent service successfully.')
    add_numbered(doc, "Send a chat message. The C# bridge forwards it to the agent service.")

    add_heading(doc, "Known gaps in the Visual Studio shell", level=2)
    add_para(doc, "The VS port is thinner than the VS Code port. Currently not wired:")
    add_table(
        doc,
        ["Feature", "VS Code", "Visual Studio"],
        [
            ["Multi-session tabs + Activity Bar tree", "Yes", "Single tool window only"],
            ["Click Open on tool cards", "Opens file", "No-op (RPC not bridged)"],
            ["Split chat", "Moves panel to new editor group", "No-op"],
            ["File attachments (paperclip)", "VS Code file picker", "Not bridged"],
            ["Mic / voice-to-text", "Web Speech API", "Likely silent in WebView2"],
            ["Approval dialogs", "Native webview dialog", "Wired"],
            ["Settings persistence", "globalState + SecretStorage", "WritableSettingsStore + DPAPI"],
        ],
    )

    add_page_break(doc)

    # --- 6. Visual Studio .vsix ------------------------------------------
    add_heading(doc, "6. Visual Studio 2022 — build and install a .vsix locally", level=1)
    add_para(
        doc,
        "Once F5 works, you can package the VSIX and install it into your real "
        "Visual Studio so it persists across sessions and survives restarts.",
    )

    add_heading(doc, "Build the .vsix", level=2)
    add_numbered(doc, "Open a Developer PowerShell for VS 2022 (Start menu → search 'Developer PowerShell').")
    add_numbered(doc, "From the repo root, rebundle the webview and rebuild:")
    add_code(
        doc,
        "cd ide\\visual-studio\n"
        "powershell -ExecutionPolicy Bypass -File scripts\\bundle-webview.ps1\n"
        "msbuild OatiExtension\\OatiExtension.csproj /restore /p:Configuration=Release",
    )
    add_para(doc, "Output:")
    add_code(doc, r"ide\visual-studio\OatiExtension\bin\Release\OatiExtension.vsix")

    add_note(
        doc,
        "VSSDK.BuildTools can be finicky from the command line with SDK-style "
        "csproj. If msbuild produces the DLL but not the .vsix, an easy "
        "fallback: open the project in Visual Studio and use Build → Build "
        "Solution. The .vsix lands in the same output folder either way.",
    )

    add_heading(doc, "Install the .vsix into Visual Studio", level=2)
    add_para(doc, "Two equivalent options:")

    add_para(doc, "Option A — double-click installer:", bold=True)
    add_numbered(doc, "Close all Visual Studio windows.")
    add_numbered(doc, "Double-click OatiExtension.vsix.")
    add_numbered(
        doc,
        "VSIX Installer launches → pick which VS editions to install into (Community / Pro / Enterprise / Build Tools).",
    )
    add_numbered(doc, "Click Install. Reopen Visual Studio after the installer finishes.")

    add_para(doc, "Option B — Extensions Manager:", bold=True)
    add_numbered(doc, "In Visual Studio: Extensions → Manage Extensions.")
    add_numbered(doc, "Click Install from... → pick the .vsix.")
    add_numbered(doc, "Restart Visual Studio when prompted.")

    add_heading(doc, "Verify the install", level=2)
    add_bullet(doc, "Tools menu shows OATI: Open Chat.")
    add_bullet(doc, "Extensions → Manage Extensions → Installed lists OATICodingAssistant.")
    add_bullet(doc, "Opening the tool window loads the Preact UI inside WebView2.")

    add_heading(doc, "Uninstall", level=2)
    add_bullet(doc, "Extensions → Manage Extensions → Installed → OATICodingAssistant → Uninstall.")
    add_bullet(doc, "Restart Visual Studio to complete removal.")

    add_heading(doc, "Publishing to the VS Marketplace (later)", level=2)
    add_para(
        doc,
        "When you are ready to publish to the Visual Studio Marketplace "
        "(separate from the VS Code Marketplace):",
    )
    add_numbered(doc, "Sign in at https://marketplace.visualstudio.com/manage/createpublisher.")
    add_numbered(
        doc,
        "Use Extensions → Manage Extensions → Publish to upload the .vsix, or upload "
        "directly through the manage portal.",
    )
    add_numbered(
        doc,
        "The listing is reviewed by Microsoft; allow 1–2 business days for "
        "first-time publishers.",
    )

    add_page_break(doc)

    # --- 7. Smoke tests + troubleshooting --------------------------------
    add_heading(doc, "7. Smoke tests, common errors, and troubleshooting", level=1)

    add_heading(doc, "Smoke-test checklist", level=2)
    add_bullet(doc, "Activity Bar icon appears (VS Code) / Tools menu entry appears (VS)")
    add_bullet(doc, "Chat tab opens beside the source editor")
    add_bullet(doc, "Test Connection succeeds against your configured provider")
    add_bullet(doc, 'Sending "Hi" updates the chat title in the tree immediately')
    add_bullet(doc, "+ New chat reuses an existing empty session instead of piling them up")
    add_bullet(doc, "Mode pill opens upward and lets you switch between modes")
    add_bullet(doc, "Tool calls render as compact cards (not file dumps)")
    add_bullet(doc, "Clicking Open on a tool card opens the file in the editor (VS Code only for now)")
    add_bullet(doc, "Markdown tables render with header shading and alternating rows")
    add_bullet(doc, "Slash commands work: /new, /clear, /settings, /attach, /split, /rename, /help")
    add_bullet(doc, "Delete chat shows a non-modal toast (no native OS popup)")

    add_heading(doc, "Common errors", level=2)
    add_table(
        doc,
        ["Symptom", "Cause", "Fix"],
        [
            [
                "Test Connection: 'fetch failed [ECONNREFUSED]'",
                "Antivirus / firewall is blocking Node from making outbound TCP, OR HTTPS_PROXY is set to a proxy that isn't running.",
                "Open the error toast — it now lists every IP+port tried. Whitelist node.exe in your AV. Unset HTTPS_PROXY if not needed.",
            ],
            [
                "Test Connection: 'fetch failed' with no detail",
                "Pre-error-improvement build.",
                "Pull latest main and rebuild.",
            ],
            [
                "C# build: CS1069 HttpClient not found",
                "Framework reference missing in SDK-style csproj.",
                "Already fixed in OatiExtension.csproj — close the project and reopen.",
            ],
            [
                "Webview blank in VS",
                "Bundle missing or WebView2 runtime missing.",
                "Re-run bundle-webview.ps1; install WebView2 Evergreen Standalone.",
            ],
            [
                "Sidebar fills with 'New chat' entries",
                "Pre-fix build.",
                "Pull latest main — duplicates are now reused.",
            ],
            [
                "Tab title stays 'New chat' after sending",
                "Pre-fix build.",
                "Pull latest main — title saves optimistically.",
            ],
            [
                "Tables render as plain text with literal pipes",
                "Pre-fix build (paragraph collector swallowed the table).",
                "Pull latest main.",
            ],
        ],
    )

    add_heading(doc, "Where to look for logs", level=2)
    add_bullet(doc, "VS Code: View → Output → dropdown 'OATICodingAssistant'")
    add_bullet(doc, "VS Code dev host: Help → Toggle Developer Tools → Console")
    add_bullet(doc, "Visual Studio: View → Output → dropdown 'OATI'")
    add_bullet(doc, "Agent service: the PowerShell window where you started it")

    add_heading(doc, "Resetting state", level=2)
    add_para(doc, "If sessions or settings look corrupted, remove the storage:")
    add_bullet(doc, "VS Code: Command Palette → 'Developer: Open Extension Storage Folder' → delete contents")
    add_bullet(doc, "Visual Studio: tools window menu → Reset (or delete the settings folder under %LOCALAPPDATA%\\Microsoft\\VisualStudio\\17.0_<hash>\\Extensions)")

    add_heading(doc, "Getting help", level=2)
    add_bullet(doc, "Repo: https://github.com/sbkkomal/codeassistant")
    add_bullet(doc, "Open an issue with: VS version, OS build, error output, repro steps.")

    return doc


def main() -> None:
    doc = build_doc()
    enable_auto_update_fields(doc)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(f"[build-testing-guide] wrote {OUT} ({OUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
