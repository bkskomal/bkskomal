# Deploying OATI Code with Kimi K2.6 (self-hosted vLLM)

The recommended production path for Kimi K2.6 is a self-hosted vLLM
endpoint that emits OpenAI-compatible responses. OATI Code's existing
defenses (KimiNativeToolParser, false-Done check, empty-args coercion)
remain valuable as safety nets, but with a correctly configured vLLM
deployment the bulk of tool calls flow through the native OpenAI envelope
and never need them.

This doc captures what your serving infra needs to be right. Sources are
listed at the bottom — verify against current vLLM / Moonshot docs when
you upgrade either side.

## Requirements

- **vLLM 0.19.1** (Moonshot's official recommendation in their
  [`deploy_guidance.md`](https://huggingface.co/moonshotai/Kimi-K2.6/blob/main/docs/deploy_guidance.md)).
  Older builds miss the K2-Thinking / K2.6 reasoning-content fixes
  (PR [vllm-project/vllm#37438](https://github.com/vllm-project/vllm/pull/37438)).
- **8×H200** (or H20) single node, `--tensor-parallel-size 8`. Native INT4
  weights ship in the model repo — no extra quantization flag needed.
- **Do NOT requantize to FP4.** Moonshot's
  [K2 Vendor Verifier](https://github.com/MoonshotAI/K2-Vendor-Verifier)
  shows FP4 leaks special-token markers more than INT4/FP8/BF16.
- **Do NOT pass `--chat-template`.** vLLM auto-uses the Jinja template
  bundled in `tokenizer_config.json` (Moonshot's recent fixes are baked
  in). Passing an external template overrides those fixes.

## Launch command

```bash
vllm serve moonshotai/Kimi-K2.6 \
  --tensor-parallel-size 8 \
  --enable-auto-tool-choice \
  --tool-call-parser kimi_k2 \
  --reasoning-parser kimi_k2 \
  --trust-remote-code
```

Two parsers, two roles:

| Flag                              | What it does                                                                                  |
| --------------------------------- | --------------------------------------------------------------------------------------------- |
| `--enable-auto-tool-choice`       | Tells vLLM to *run* a tool parser at all. Without this `--tool-call-parser` is a no-op.       |
| `--tool-call-parser kimi_k2`      | Strips `<\|tool_call_begin\|>...<\|tool_call_end\|>` markers, emits OpenAI-shape `tool_calls`. |
| `--reasoning-parser kimi_k2`      | Routes `<think>...</think>` content to `delta.reasoning_content` (OATI surfaces it inline).   |
| `--trust-remote-code`             | Required for Moonshot's bundled chat template.                                                |

K2.6 enables Thinking by default. You cannot disable it via
`enable_thinking: false` in the request — that flag is silently ignored
(vLLM issue [#30082](https://github.com/vllm-project/vllm/issues/30082)
closed "not planned"). The `--reasoning-parser kimi_k2` flag is therefore
not optional for K2.6 — without it, `<think>` blocks leak into the user-
facing `content` channel.

For high-throughput add `--decode-context-parallel-size 8`.

## Pointing OATI Code at vLLM

In OATI Code's settings, configure a provider:

- **Base URL**: `https://your-vllm-host/v1` (the OpenAI-compatible endpoint).
- **API Key**: whatever auth you put in front of vLLM (or empty if internal).
- **Model ID**: `moonshotai/Kimi-K2.6`.

OATI Code auto-detects Kimi K2 from the model id (`/kimi[-_./]?k2/i`) and
applies the kimi-native handling: wire `tools` array sent (Kimi needs the
schema), KimiNativeToolParser engaged as a streaming safety net, and the
false-Done file-existence check armed end-of-turn. No additional config
required.

The OpenRouter `provider.order` routing block is *not* injected for
non-OpenRouter base URLs — your vLLM endpoint sees a clean OpenAI request.

## Known issues to monitor

- **Streaming tool calls truncated**
  ([vllm-project/vllm#41182](https://github.com/vllm-project/vllm/issues/41182)).
  Content BEFORE the tool-call section streams fine, but tokens between
  `<|tool_calls_section_begin|>` and `<|tool_calls_section_end|>` can
  produce "Not enough token" and yield an empty `delta.tool_calls`.
  OATI Code's KimiNativeToolParser catches this case from the leaked
  text channel.
- **Empty-args Pydantic rejection**
  ([MoonshotAI/Kimi-K2#100](https://github.com/MoonshotAI/Kimi-K2/issues/100)).
  vLLM rejects calls with missing `arguments`. OATI Code coerces empty
  args to `{}` on its side; the handler's own arg-guard then surfaces
  a clean "field required" error.
- **Tool hallucination**. vLLM has no constrained-decoding enforcer yet.
  The false-Done file-existence check is the client-side mitigation.
- **K2 Vendor Verifier ceiling ~83.57% F1** on vLLM after the October
  2025 fixes. ~16-17% of tool calls hit *some* corner case; OATI Code's
  safety nets bridge that gap.

## Diagnosing a misbehaving deployment

1. Confirm vLLM came up with both parsers:
   ```bash
   curl -s https://your-vllm-host/v1/models | jq
   ```
   The launch log should mention `kimi_k2` for both tool-call and
   reasoning parsers.
2. Hit the endpoint directly (bypassing OATI Code) with a single-tool
   request and confirm `tool_calls` populates correctly:
   ```bash
   curl -N -X POST https://your-vllm-host/v1/chat/completions \
     -H 'Content-Type: application/json' -H 'Authorization: Bearer ...' \
     -d '{
       "model": "moonshotai/Kimi-K2.6",
       "stream": true,
       "tools": [{"type":"function","function":{
         "name":"echo","description":"echo",
         "parameters":{"type":"object","properties":{"x":{"type":"string"}},"required":["x"]}
       }}],
       "messages":[{"role":"user","content":"call echo with x=hi"}]
     }'
   ```
   Look for `delta.tool_calls` events. Markers in `delta.content`
   indicate the parser isn't doing its job — verify the launch flags.
3. Open the **OATI Code** Output channel in VS Code. The raw HTTP
   request body is logged there; confirm `tools[0].function.name` is
   present and not empty.

## Sources

- [Moonshot Kimi K2.6 deploy guidance](https://huggingface.co/moonshotai/Kimi-K2.6/blob/main/docs/deploy_guidance.md)
- [vLLM Tool Calling docs](https://docs.vllm.ai/en/stable/features/tool_calling/)
- [vLLM Recipes — Kimi-K2-Thinking](https://docs.vllm.ai/projects/recipes/en/latest/moonshotai/Kimi-K2-Think.html)
- [vLLM blog — Chasing 100% Accuracy on Kimi K2 (Oct 2025)](https://blog.vllm.ai/2025/10/28/Kimi-K2-Accuracy.html)
- [`kimi_k2_tool_parser` API](https://docs.vllm.ai/en/latest/api/vllm/entrypoints/openai/tool_parsers/kimi_k2_tool_parser.html)
- [K2 Vendor Verifier (provider accuracy)](https://github.com/MoonshotAI/K2-Vendor-Verifier)
