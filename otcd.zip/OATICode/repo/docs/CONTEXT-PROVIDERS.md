# Pluggable Context Providers (R8-C)

OATI Code exposes a registry of **context providers** — small modules that
resolve an `@`-mention typed in the chat composer into a markdown block
that gets spliced into the outgoing user message. Built-ins ship with the
extension; you can drop your own into `<workspace>/.oati/context-providers/`
to extend the system without recompiling.

## Built-in mentions

| Mention | What it does |
| --- | --- |
| `@problems[:<path>]` | Dumps active VS Code diagnostics, optionally filtered by file. |
| `@terminal` | Last 200 lines of the active terminal (requires a tracked terminal). |
| `@git-diff[:--staged] [:<path>]` | `git diff` output of the working tree (or `--staged` / `--cached`). |
| `@docs:<url>` | Fetches a doc URL, strips HTML, returns markdown. |
| `@web:<query>` | Runs a web search and returns the top 3 snippets. |
| `@github-issue:<num>` or `@github-issue:<owner>/<repo>#<num>` | Issue body + first 5 comments via the `gh` CLI. |
| `@search:<query> [--glob=<pattern>]` | Workspace-wide grep (ripgrep). |
| `@open-tabs` | Open editor tabs with the first 50 lines of each. |
| `@selection` | The current editor selection (1-based line range + content). |

Mentions appear in the composer's autocomplete dropdown alongside file
paths (`@src/foo.ts`) and saved snippets (`@snip:<name>`). The agent itself
can also request any of these on demand through the
`resolve_context_mention` tool — handy when the model decides mid-turn that
it needs fresh diagnostics or a `git diff`.

## Writing a custom provider

Drop a CommonJS module at `<workspace>/.oati/context-providers/<id>.js`. The
file must export a `ContextProvider` shape:

```js
// .oati/context-providers/jira.js
module.exports = {
  id: "jira",                          // stable lookup key
  mention: "@jira",                    // literal token the user types
  description: "Fetch a Jira ticket.", // shown in the autocomplete dropdown
  async resolve(arg, host) {
    // `arg` is whatever follows the colon: `@jira:ABC-123` → "ABC-123"
    // `host` is the same HostContext your tools see (readFile, exec, …).
    const result = await host.exec(`jira-cli view ${arg}`);
    return result.stdout || `_jira lookup failed: ${result.stderr}_`;
  },
};
```

### Sandbox rules

User-provided plugins run in a `node:vm` sandbox. The sandbox provides:

- `module` / `exports` (CommonJS hooks)
- `console.log` / `warn` / `error` (no-ops by default — failures still surface in the host log)
- `setTimeout` / `clearTimeout`

It **does not** provide:

- `require()` — calls throw a synchronous error. Pure-JS plugins only.
- VS Code APIs — go through the `host` argument instead.
- File-system access — use `host.readFile` / `host.writeFile`.

### Cap

A workspace can register at most **10** user providers. Surplus plugins are
skipped at activation and logged.

### Errors

If a plugin throws or doesn't export a `ContextProvider`, the host logs the
reason and continues activation. The composer just doesn't see the broken
mention — your other plugins keep working.

## How the agent uses it

The agent can call `resolve_context_mention` directly:

```json
{
  "name": "resolve_context_mention",
  "arguments": { "mention": "@problems", "arg": "src/parser.ts" }
}
```

The tool returns the same markdown block the composer would splice in. This
lets the agent fetch context on demand instead of asking the user to paste
it.
