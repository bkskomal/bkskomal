# Configuration reference

OATI Code splits configuration into two places:

1. **VS Code settings** (`oati.*`) — flags that govern the extension shell (inline completion, hover explain, auto-revert, PR watcher). User-editable from `Ctrl+,`.
2. **Settings panel** (gear icon in the chat) — providers, modes, MCP servers, hooks, budgets, routing, model budgets. Persisted as JSON in VS Code's `globalState` so workspace policy can govern it.

Everything else lives under `<workspace>/.oati/` and is configured by dropping files in (recipes, knowledge, rules, snippets, custom commands, policy).

## `oati.*` VS Code settings

### Inline-diff defaults

```jsonc
"oati.inlineDiff.defaultMode": "review"
```

Fallback inline-diff mode for modes that don't set their own. Allowed values:

- `"review"` — edits surface as in-editor decorations + Accept/Reject/Modify code lenses. User opts in per hunk.
- `"auto-apply"` — writes go through immediately; the user sees the diff in chat but no inline gate.

Modes with `autoApprove: true` default to `auto-apply` regardless of this setting.

### Hover explain

```jsonc
"oati.hoverExplain.enabled": true
```

When enabled, hovering over a function declaration (TypeScript, JavaScript, Python, Go, Rust) asks the active model for a 2-sentence explanation in the hover popup. Results are cached for 30 minutes per function. Disable to silence model traffic on hover.

### Inline completion (Copilot-style ghost text)

```jsonc
"oati.inlineCompletion.enabled": true,
"oati.inlineCompletion.debounceMs": 200,
"oati.inlineCompletion.maxTokens": 80,
"oati.inlineCompletion.languages": [
  "typescript", "javascript", "python", "go",
  "rust", "java", "cpp", "csharp"
]
```

- `debounceMs` — milliseconds of keyboard idle before a completion is requested. Lower = snappier, more provider calls.
- `maxTokens` — max tokens per completion. Kept tight so latency stays acceptable; 80 covers most line-completion cases.
- `languages` — language ids for which inline completion is active. Pass `[]` to enable for all languages (will produce noisy traffic).
- Toggle at runtime with `OATI Code: Toggle Inline Completion`.

### Predictive next-edit (experimental)

```jsonc
"oati.predictiveEdit.enabled": false
```

When enabled, OATI Code shows ghost-text predictions of your next edit after pausing on a line. Accept with Tab. Off by default because every pause triggers a model call — leave off unless you've configured a fast/cheap model.

### Auto-revert safety net

```jsonc
"oati.autoRevert.enabled": false,
"oati.autoRevert.requireTests": true
```

When an Auto* turn writes files **and** the post-turn `run_tests` invocation reports new failures, automatically revert the writes to their pre-turn contents.

- `requireTests` (default `true`) — only auto-revert when `run_tests` actually fired during the turn. Set to `false` to revert on any post-turn signal (e.g. lint failure surfaced via diagnostics).
- Toggle at runtime: `OATI Code: Toggle Auto-Revert Safety Net`.

Reverts are applied through `vscode.workspace.applyEdit`, so they show up in the standard undo stack. Files created during the turn are not deleted — only modified files are restored.

### Memory consolidation

```jsonc
"oati.memoryConsolidation.autoEvery": 0,
"oati.memoryConsolidation.daysOld": 30
```

- `autoEvery` — when `> 0`, automatically run memory consolidation on activation if `lastConsolidationAt` is older than this many days. `0` (default) disables auto-runs; use `OATI Code: Consolidate Memory` for one-shot runs.
- `daysOld` — sessions older than this many days are eligible for consolidation.

Consolidation walks older sessions and promotes 1–3 lessons each to `.oati/facts.json` (dedup case-insensitive). Useful for compressing long-term project knowledge.

### PR watcher

```jsonc
"oati.prWatch.enabled": false,
"oati.prWatch.intervalMinutes": 5,
"oati.prWatch.autoComment": false
```

- Polls `gh pr list` for new pull requests on the workspace's GitHub repo and offers to auto-review.
- `intervalMinutes` — polling interval (minimum 1).
- `autoComment` — when `true`, the auto-review is posted as a PR comment automatically. When `false` (default), a notification with a `Review now` button is shown.

## Settings-panel configuration (`RootConfig`)

The chat's gear icon opens the Settings panel; the underlying JSON shape is `RootConfig` in `packages/shared/src/config.ts`:

```ts
interface RootConfig {
  activeProviderId: string;
  activeModeId: string;
  providers: ProviderConfig[];
  modes: ModeConfig[];
  mcpServers?: McpServerConfig[];
  hooks?: HookConfig[];
  budget?: BudgetConfig;
  auditLog?: boolean;            // default true
  routing?: RoutingConfig;
  modelBudgets?: ModelBudget[];
}
```

### Providers

```ts
interface ProviderConfig {
  id: string;                    // stable id, used by activeProviderId
  type: "openai-compatible" | "anthropic";
  displayName: string;
  preset: ProviderPresetId;      // see "Presets" below
  baseUrl: string;
  defaultModel: string;
  extraHeaders?: Record<string, string>;
}
```

API keys are NOT stored here — they live in `SecretStorage` keyed by `provider.id`. The Settings panel shows `hasApiKey: boolean`; the webview never sees raw values.

**Presets** populate sensible defaults when you pick from the dropdown:

| Preset id | `displayName` | `baseUrl` | `type` |
|---|---|---|---|
| `openai` | OpenAI | `https://api.openai.com/v1` | openai-compatible |
| `anthropic` | Anthropic | `https://api.anthropic.com/v1` | anthropic |
| `openrouter` | OpenRouter | `https://openrouter.ai/api/v1` | openai-compatible (adds HTTP-Referer + X-Title) |
| `litellm` | LiteLLM | `http://localhost:4000/v1` | openai-compatible |
| `unillm` | unillm | `http://localhost:8080/v1` | openai-compatible |
| `ollama` | Ollama (local) | `http://localhost:11434/v1` | openai-compatible |
| `openai-compatible` | OpenAI Compatible | (you set) | openai-compatible |
| `custom` | Custom | (blank) | openai-compatible |

### Modes

```ts
interface ModeConfig {
  id: string;
  displayName: string;
  description?: string;
  systemPrompt: string;
  enabledTools: string[] | "all";
  providerId?: string;           // override active provider
  modelId?: string;              // override default model
  plannerModelId?: string;       // cheap/fast model for planning
  criticModelId?: string;        // dedicated model for critique
  maxRetries?: number;           // critic-driven retries; default 1
  enablePlanner: boolean;
  enableCritic: boolean;
  maxParallelAgents: number;
  maxIterations: number;
  temperature?: number;
  autoApprove?: boolean;         // skip approval dialog
  inlineDiffMode?: "auto-apply" | "review";
}
```

Five modes ship by default:

| Mode | Tools | Planner | Critic | Auto-approve | Max iters |
|---|---|:--:|:--:|:--:|:--:|
| `ask` | read-only (4 tools) | — | — | — | 12 |
| `plan` | read-only (4 tools) | ✓ | ✓ | — | 16 |
| `code` | all | — | — | — | 20 |
| `auto-edit` | all | — | ✓ | ✓ | 40 |
| `auto` | all | ✓ | ✓ | ✓ | 80 |

To add a custom mode: append to `modes[]` and bump `activeModeId` to switch.

### MCP servers

```ts
interface McpServerConfig {
  id: string;
  displayName: string;
  command: string;
  args?: string[];
  env?: Record<string, string>;
  enabled: boolean;
  approval?: "auto" | "prompt" | "deny";   // default "prompt"
}
```

Use `/marketplace` to install curated servers; manual entries are fine too. See [MCP.md](MCP.md) for the full guide.

### Hooks

```ts
interface HookConfig {
  event: "PreToolUse" | "PostToolUse" | "UserPromptSubmit" | "SessionStart" | "Stop";
  matcher?: string;     // substring or simple glob (* / ?)
  command: string;      // shell command; stdin gets the event payload as JSON
  timeout?: number;     // ms; default 5000
  blocking?: boolean;   // if true, agent waits for verdict
}
```

The hook's stdout is parsed as `{allow, reason?, modifiedPayload?}` JSON when `blocking: true`; otherwise the hook is treated as a passive observer.

Example — block `exec` of anything starting with `rm `:

```jsonc
{
  "event": "PreToolUse",
  "matcher": "exec",
  "blocking": true,
  "command": "node ./hooks/guard-rm.js",
  "timeout": 2000
}
```

### Budget

```ts
interface BudgetConfig {
  perSessionAlertUsd?: number;     // soft alert, default $5
  perSessionHardCapUsd?: number;   // refuse dispatch past this, default unset
  perDayHardCapUsd?: number;       // org-wide cap, default $50
}
```

Workspace policy (`.oati/policy.yaml`) may tighten these but never widen them.

### Per-model budgets

```ts
interface ModelBudget {
  providerId: string;
  modelId?: string;          // substring match; omit = applies to every model
  dailyUsd?: number;
  monthlyUsd?: number;
}
```

Example — cap Sonnet at $20/day:

```jsonc
{
  "modelBudgets": [
    { "providerId": "anthropic", "modelId": "sonnet", "dailyUsd": 20 }
  ]
}
```

### Routing

```ts
interface RoutingConfig {
  enabled: boolean;
  rules: { when: "trivial" | "easy" | "medium" | "hard"; providerId: string; model?: string }[];
  fallback?: { providerId: string; model?: string };
}
```

Each upcoming turn is classified into `trivial | easy | medium | hard`; the first matching rule wins. On HTTP 429 from the primary, the router falls back to `fallback` after one bounded retry.

Example — cheap default, big model for hard turns:

```jsonc
{
  "routing": {
    "enabled": true,
    "rules": [
      { "when": "trivial", "providerId": "ollama", "model": "llama3.1:8b" },
      { "when": "easy",    "providerId": "ollama", "model": "llama3.1:8b" },
      { "when": "medium",  "providerId": "openai", "model": "gpt-4o-mini" },
      { "when": "hard",    "providerId": "anthropic", "model": "claude-3-7-sonnet" }
    ],
    "fallback": { "providerId": "openai", "model": "gpt-4o-mini" }
  }
}
```

### Audit log

```jsonc
{ "auditLog": true }
```

When `false`, the append-only `.oati/audit.log` is not written. Default `true`. Useful for tests and short-lived experiments. See [SECURITY.md](SECURITY.md).

## Environment variables

| Variable | Used by | Purpose |
|---|---|---|
| `OATI_WORKSPACE_ROOT` | `@oati/agent-service` | Pins the standalone service's allowed workspace root. |
| `OATI_SERVICE_TOKEN` | `@oati/agent-service` | Bearer token required on every `/v1/*` request. |
| `OATI_DISABLE_INDEX` | extension-host | Skip the semantic-search index build on startup (debug). |
| `OATI_DEBUG` | extension-host | Verbose logging to the OATI Code output channel. |

API keys are read from `SecretStorage`, never from env vars, by design.

## Workspace files

| File | Configures |
|---|---|
| `.oati/policy.yaml` | Allow/deny lists for providers, models, tools, modes; budget tightening. |
| `.oati/rules.md` | Global project rules; prepended to every system prompt. |
| `.oati/rules-<lang>.md` | Per-language rules (`typescript`, `python`, `go`, `rust`, etc.). |
| `.oati/facts.json` | Persistent facts (managed by `remember_fact` / `consolidate_memory`). |
| `.oati/recipes/<name>.md` | Multi-step workflows. See [RECIPES.md](RECIPES.md). |
| `.oati/commands/<name>.md` | Custom slash commands. |
| `.oati/snippets/<name>.md` | Reusable snippets. |
| `.oati/knowledge/**/*.md` | Knowledge base for RAG. |
| `.oati/schedule.json` | Cron-style recurring tasks (coming soon). |
