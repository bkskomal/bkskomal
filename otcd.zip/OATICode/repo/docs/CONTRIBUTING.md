# Contributing — developer workflow

This file documents the local-dev tooling. For project-wide conventions and PR rules, see the repo-root [CONTRIBUTING.md](../CONTRIBUTING.md).

## Setup

```powershell
npm install
```

That single command also runs the `prepare` script, which wires up [husky](https://typicode.github.io/husky/) git hooks under `.husky/`. After this, every `git commit` and `git push` from this clone runs the checks below.

If hooks ever stop firing (e.g. after a manual `git init` or a stale `core.hooksPath`), re-run `npx husky install` to re-register them.

## Daily workflow

### `git commit`

The **pre-commit** hook runs `npx lint-staged`, which applies `npx biome check --fix --no-errors-on-unmatched` to staged `*.{ts,tsx,js,mjs,jsonc}` files and re-stages the formatted result. `*.cs` files are intentionally not formatted in the hook — Visual Studio's built-in formatter handles them.

### `git push`

The **pre-push** hook runs `npm test --silent`. The vitest suite is fast (~5 s for the full 221-test baseline); if anything is red the push is blocked.

### Common scripts

| Script | What it does |
| --- | --- |
| `npm run build` | Build every workspace that defines a `build` script |
| `npm run typecheck` | Run `tsc --noEmit` per workspace |
| `npm test` | Run vitest once (CI mode) |
| `npm run test:watch` | Vitest watch mode in the terminal |
| `npm run test:ui` | Interactive vitest UI at http://localhost:51204 |
| `npm run test:coverage` | Vitest with v8 coverage; HTML report in `coverage/` |
| `npm run lint` | `biome check .` |
| `npm run format` | `biome format --write .` |
| `npm run check:bundles` | Enforce the bundle-size budgets in `bundle-budgets.json` |
| `npm run check` | typecheck → test → lint → build → check:bundles (the "is my PR ready" command) |
| `npm run docs:api` | Generate TypeDoc API docs to `docs/api/` |
| `npm run analyze` | Open an interactive bundle treemap (`esbuild-visualizer`) for the webview-ui bundle |
| `npm run health` | One-screen repo snapshot: LOC, tests, deps, TODOs, bundle sizes |

### Bundle-size budgets

Every release-shipped artifact has a hard ceiling in [`bundle-budgets.json`](../bundle-budgets.json). `npm run check:bundles` reads that file, compares the on-disk bytes of each entry, and fails CI if anything is over.

To raise a budget intentionally:

1. Run `npm run analyze` to see *what* is eating the bytes (the treemap visualizer reads `packages/webview-ui/dist/meta.json`, which esbuild now emits on every build). For other bundles, pass `--metadata packages/extension-host/dist/meta.json` etc.
2. If the growth is justified (new feature, unavoidable dep), edit the `max` field in `bundle-budgets.json` and explain the reason in the commit message.

Initial budgets were set by taking the current build sizes, adding 20% headroom, and rounding up to the next 10 KB.

### Coverage reports

`npm run test:coverage` writes an HTML report to `coverage/index.html`. The `coverage/` directory is gitignored — it's regenerated on every run.

### API docs

`npm run docs:api` regenerates TypeDoc HTML under `docs/api/`. That directory is gitignored — open it locally with your browser; do not commit it.

## Escape hatch

If a hook is in the way of an emergency (revert a broken main, ship a hotfix at 2 a.m.), bypass it with:

```powershell
git commit --no-verify -m "hotfix: ..."
git push --no-verify
```

Use this sparingly — anything that needed `--no-verify` should be followed by a normal-workflow PR that gets the suite back to green.
