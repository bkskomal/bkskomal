# Contributing to OATICodingAssistant

Thanks for considering a contribution. This project is small, opinionated, and changing fast — read this file once before opening a PR so we agree on what the PR should look like.

## Quick start

```powershell
git clone https://github.com/sbkkomal/codeassistant.git
cd codeassistant
npm install
npm run build
npm test          # 118 tests, ~3 s
npm run typecheck
npx biome check .
```

Press **F5** in VS Code to launch the extension dev host with the extension loaded.

## Repository layout

See [README.md](README.md#repository-layout) for the package map. Short version:

- `packages/agent-core/` is **pure TypeScript with zero IDE deps**. This is the rule that holds the whole architecture together. If you find yourself reaching for `import * as vscode` here, stop.
- `packages/webview-ui/` only talks to its host through `@oati/rpc`. No `fetch`, no `fs`, no provider calls.
- `packages/shared/` is **types + pure data only**. The single exceptions are presets and the conversation→UiMessage converter.
- `ide/visual-studio/` is pure C#. It's not part of the npm workspace and `npm run build` does not touch it.

See [CLAUDE.md](CLAUDE.md) for the full set of architectural rules.

## How to add a tool

1. Drop a new file in `packages/tools/src/<name>.ts` exporting a `ToolSpec`.
2. Add it to `packages/tools/src/registry.ts` and re-export from `index.ts`.
3. Add tests in `packages/tools/tests/<name>.test.ts` using `makeMockHost()` from `mock-host.ts`.

No central switch statement to edit; the registry picks it up automatically.

## How to add a provider

1. Drop a new file in `packages/providers/src/<name>.ts` exporting a factory `createXxxProvider(config)`.
2. Extend `ProviderType` in `packages/shared/src/config.ts`.
3. Add the dispatch case in `packages/providers/src/factory.ts`.
4. Add a preset entry in `packages/shared/src/presets.ts`.
5. Add tests in `packages/providers/tests/<name>.test.ts`.

## Conventions

- **TypeScript, strict mode**, ESM source, `moduleResolution: "bundler"`.
- **Biome** for lint + format. The CI step is `npx biome check .` — make sure it passes locally first. `npx biome check --write .` autofixes most things.
- **Tabs** for indentation, **double quotes** for strings, **semicolons always**.
- **No comments** unless the WHY is non-obvious. Names should carry the meaning.
- **No new dependencies** without a clear reason. The whole VS Code bundle is 165 KB — keep it that way.
- **Tests are required** for new logic in `shared/`, `agent-core/`, `providers/`, `tools/`, `mcp-client/`, and `extension-host` storage. The other packages (webview-ui, extension-host runtime, agent-service runtime) are tested via integration when there's time.

## Commit messages

- Imperative mood, ~50 chars in the subject, blank line, body if needed.
- One concept per commit. If you're tempted to write "and", split it.
- Reference issues by number (`Closes #42`) when applicable.

## Pull requests

- Small and focused. < 400 lines of diff is the sweet spot.
- All CI checks must pass: typecheck, build, test, biome.
- Update [CHANGELOG.md](CHANGELOG.md) under the `[Unreleased]` section if the change is user-visible.
- If you're touching public types in `shared/`, bump downstream packages' tests accordingly.

## Releasing

Maintainer flow:

1. Bump version in `packages/extension-host/package.json`.
2. Move the relevant `[Unreleased]` notes in `CHANGELOG.md` under a new `[X.Y.Z]` section.
3. Commit and tag: `git tag v0.1.1 && git push --tags`.
4. GitHub Actions builds the VSIX and creates a draft release with the file attached.
5. Verify the release, then `vsce publish` from the maintainer's machine (we don't push the PAT into CI).

## Reporting bugs / requesting features

Use the issue templates at [github.com/sbkkomal/codeassistant/issues/new/choose](https://github.com/sbkkomal/codeassistant/issues/new/choose). The bug template asks for the model + provider you were using, which is usually half the answer.

## Security

If you've found something that looks like a security issue (API-key leak, sandbox escape, supply-chain concern), please follow [SECURITY.md](SECURITY.md) instead of filing a public issue.

## License

By contributing, you agree that your contribution will be released under the [MIT License](LICENSE) that covers the project.
