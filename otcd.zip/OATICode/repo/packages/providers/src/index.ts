export { createOpenAICompatibleProvider } from "./openai-compatible";
export type { OpenAICompatibleConfig } from "./openai-compatible";
export { createAnthropicProvider } from "./anthropic";
export type { AnthropicConfig } from "./anthropic";
export { createProviderFromConfig } from "./factory";
// R3-B: Ollama local provider
export {
	createOllamaProvider,
	OLLAMA_DEFAULT_BASE_URL,
	OLLAMA_DEFAULT_MODEL,
} from "./ollama";
export type { OllamaConfig } from "./ollama";
