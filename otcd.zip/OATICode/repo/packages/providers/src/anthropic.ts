// Phase B carry-over (2026-05-25): same per-request branching the
// openai-compatible provider uses. Lets users route Kimi-class open-
// weight models through Anthropic's gateway and still get inline-XML
// tool format (rare config, but supported for completeness).
import {
	type InlineParsedToolCall,
	InlineXmlToolParser,
	KimiNativeToolParser,
	type KimiParsedToolCall,
	buildInlineXmlToolPrompt,
} from "@oati/agent-core";
import {
	type ConversationMessage,
	type ProviderRequest,
	type ProviderSpec,
	type ProviderStreamEvent,
	type ToolSpec,
	detectModelQuirks,
} from "@oati/shared";
import { retryFetch } from "./retry-fetch";

export interface AnthropicConfig {
	readonly id: string;
	readonly displayName: string;
	readonly baseUrl?: string;
	readonly apiKey?: string;
	readonly anthropicVersion?: string;
	readonly extraHeaders?: Readonly<Record<string, string>>;
}

type AnthropicContentBlock =
	| { type: "text"; text: string }
	| { type: "tool_use"; id: string; name: string; input: unknown }
	| {
			type: "tool_result";
			tool_use_id: string;
			content: string;
			is_error?: boolean;
	  }
	| {
			type: "image";
			source: { type: "base64"; media_type: string; data: string };
	  };

interface AnthropicMessage {
	role: "user" | "assistant";
	content: string | AnthropicContentBlock[];
}

interface AnthropicToolDef {
	name: string;
	description: string;
	input_schema: unknown;
}

interface AnthropicWireEvent {
	type: string;
	index?: number;
	content_block?: { type: string; id?: string; name?: string };
	delta?: {
		type?: string;
		text?: string;
		partial_json?: string;
		stop_reason?: string;
	};
	usage?: { input_tokens?: number; output_tokens?: number };
	message?: { usage?: { input_tokens?: number; output_tokens?: number } };
	error?: { message?: string; type?: string };
}

interface BlockState {
	type: "text" | "tool_use";
	id?: string;
	name?: string;
	partialInput: string;
}

export function createAnthropicProvider(config: AnthropicConfig): ProviderSpec {
	const baseUrl = (config.baseUrl ?? "https://api.anthropic.com/v1").replace(/\/$/, "");
	const version = config.anthropicVersion ?? "2023-06-01";

	return {
		id: config.id,
		displayName: config.displayName,
		async *stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			const headers: Record<string, string> = {
				"Content-Type": "application/json",
				"anthropic-version": version,
				Accept: "text/event-stream",
				...(config.extraHeaders ?? {}),
			};
			if (config.apiKey) headers["x-api-key"] = config.apiKey;

			// Phase B carry-over: per-request tool-call protocol selection.
			// Same three modes as openai-compatible:
			//   - openai-tools — frontier (default for Claude family)
			//   - inline-xml   — Cline-style XML; suppresses wire tools
			//   - kimi-native  — Kimi K2 / K2.6 native markers; needs the
			//     wire tools array to know what's callable. Parser is a
			//     safety net for gateways that leak markers as text.
			const modelQuirks = detectModelQuirks(req.modelId);
			const toolCallFormat = modelQuirks.toolCallFormat;
			const useInlineXml = toolCallFormat === "inline-xml";
			const useKimiNative = toolCallFormat === "kimi-native";
			// Only inline-xml suppresses wire tools. Kimi keeps the schema.
			const suppressWireTools = useInlineXml;
			const inlineParser =
				useInlineXml && req.tools ? new InlineXmlToolParser(req.tools.map((t) => t.name)) : undefined;
			const kimiParser =
				useKimiNative && req.tools ? new KimiNativeToolParser(req.tools.map((t) => t.name)) : undefined;
			const augmentedSystem =
				useInlineXml && req.tools && req.tools.length > 0
					? `${req.systemPrompt ?? ""}\n\n${buildInlineXmlToolPrompt(req.tools)}`.trim()
					: req.systemPrompt;

			// 2026-06-05: omit `temperature` when the model rejects it
			// (Claude Opus 4.7+ — `temperature is deprecated for this model`).
			// `requiresTemperature` (if set) wins over the request's value;
			// omit takes precedence over both.
			const wireTemperature = modelQuirks.omitTemperature
				? undefined
				: (modelQuirks.requiresTemperature ?? req.temperature);
			const body = {
				model: req.modelId,
				max_tokens: req.maxTokens ?? 4096,
				system: augmentedSystem,
				messages: toAnthropicMessages(req.messages),
				tools:
					!suppressWireTools && req.tools && req.tools.length > 0
						? req.tools.map(toAnthropicTool)
						: undefined,
				...(wireTemperature !== undefined ? { temperature: wireTemperature } : {}),
				stream: true,
			};

			let response: Response;
			try {
				response = await retryFetch(
					`${baseUrl}/messages`,
					{
						method: "POST",
						headers,
						body: JSON.stringify(body),
						signal: req.signal,
					},
					{
						onRetry: ({ attempt, reason, delayMs }) => {
							console.warn(`[anthropic] retry attempt ${attempt}: ${reason} — backing off ${delayMs}ms`);
						},
					},
				);
			} catch (err) {
				yield {
					type: "error",
					message: `Anthropic request failed: ${err instanceof Error ? err.message : String(err)}`,
				};
				yield { type: "message_end", stopReason: "error" };
				return;
			}

			if (!response.ok || !response.body) {
				const detail = await safeReadText(response);
				yield {
					type: "error",
					message: `Anthropic HTTP ${response.status} ${response.statusText}${detail ? `: ${detail}` : ""}`,
				};
				yield { type: "message_end", stopReason: "error" };
				return;
			}

			const blocks = new Map<number, BlockState>();
			let stopReason: "end" | "tool_use" | "max_tokens" | "error" = "end";

			const decoder = new TextDecoder();
			let buf = "";

			outer: for await (const chunk of response.body as unknown as AsyncIterable<Uint8Array>) {
				buf += decoder.decode(chunk, { stream: true });
				while (true) {
					const nlIdx = buf.indexOf("\n");
					if (nlIdx < 0) break;
					const line = buf.slice(0, nlIdx).trim();
					buf = buf.slice(nlIdx + 1);
					if (!line.startsWith("data:")) continue;
					const payload = line.slice(5).trim();
					if (!payload) continue;

					let evt: AnthropicWireEvent;
					try {
						evt = JSON.parse(payload);
					} catch {
						continue;
					}

					if (evt.type === "content_block_start" && evt.index !== undefined) {
						const cb = evt.content_block;
						if (cb?.type === "text") {
							blocks.set(evt.index, { type: "text", partialInput: "" });
						} else if (cb?.type === "tool_use") {
							blocks.set(evt.index, {
								type: "tool_use",
								id: cb.id,
								name: cb.name,
								partialInput: "",
							});
						}
					} else if (evt.type === "content_block_delta" && evt.index !== undefined) {
						const block = blocks.get(evt.index);
						if (!block) continue;
						const delta = evt.delta;
						if (delta?.type === "text_delta" && block.type === "text" && delta.text) {
							if (inlineParser) {
								// Phase B: inline-XML path. Feed each text delta to
								// the parser; emit safe text + any completed tool
								// calls. Partial tool tags hold safely across
								// SSE chunk boundaries.
								const chunk = inlineParser.feed(delta.text);
								if (chunk.text.length > 0) {
									yield { type: "text_delta", text: chunk.text };
								}
								for (const call of chunk.toolCalls) {
									yield emitInlineToolCall(call);
									stopReason = "tool_use";
								}
							} else if (kimiParser) {
								// 2026-05-25: Kimi K2 / K2.6 native marker path.
								const chunk = kimiParser.feed(delta.text);
								if (chunk.text.length > 0) {
									yield { type: "text_delta", text: chunk.text };
								}
								for (const call of chunk.toolCalls) {
									yield emitKimiToolCall(call);
									stopReason = "tool_use";
								}
							} else {
								yield { type: "text_delta", text: delta.text };
							}
						} else if (
							delta?.type === "input_json_delta" &&
							block.type === "tool_use" &&
							typeof delta.partial_json === "string"
						) {
							block.partialInput += delta.partial_json;
						}
					} else if (evt.type === "content_block_stop" && evt.index !== undefined) {
						const block = blocks.get(evt.index);
						if (!block) continue;
						if (block.type === "tool_use" && block.id && block.name) {
							let args: unknown = {};
							if (block.partialInput) {
								try {
									args = JSON.parse(block.partialInput);
								} catch {
									args = { _raw: block.partialInput };
								}
							}
							yield { type: "tool_call", id: block.id, name: block.name, args };
						}
						blocks.delete(evt.index);
					} else if (evt.type === "message_delta") {
						const sr = evt.delta?.stop_reason;
						if (sr === "tool_use") stopReason = "tool_use";
						else if (sr === "max_tokens") stopReason = "max_tokens";
						// Phase B carry-over: don't downgrade "tool_use" back to
						// "end" on the message_delta. For inline-XML models, the
						// parser may have already set stopReason="tool_use" from
						// a completed tool block in the text stream; Anthropic
						// still reports end_turn/stop_sequence at the envelope
						// level since it sees only text. The inline tool_call
						// must win — otherwise the agent loop thinks the turn
						// ended cleanly and skips executing the tool.
						else if ((sr === "end_turn" || sr === "stop_sequence") && stopReason !== "tool_use")
							stopReason = "end";
						if (evt.usage) {
							yield {
								type: "usage",
								usage: {
									inputTokens: evt.usage.input_tokens ?? 0,
									outputTokens: evt.usage.output_tokens ?? 0,
								},
							};
						}
					} else if (evt.type === "message_start" && evt.message?.usage) {
						yield {
							type: "usage",
							usage: {
								inputTokens: evt.message.usage.input_tokens ?? 0,
								outputTokens: evt.message.usage.output_tokens ?? 0,
							},
						};
					} else if (evt.type === "message_stop") {
						break outer;
					} else if (evt.type === "error") {
						yield {
							type: "error",
							message: evt.error?.message ?? "Anthropic stream error",
						};
						stopReason = "error";
						break outer;
					}
				}
			}

			// Phase B carry-over: flush the inline-XML parser at end-of-
			// stream. Tail text or a tool block that completed on the
			// final chunk gets emitted now; otherwise it'd be silently
			// dropped.
			if (inlineParser) {
				const tail = inlineParser.finalize();
				if (tail.text.length > 0) {
					yield { type: "text_delta", text: tail.text };
				}
				for (const call of tail.toolCalls) {
					yield emitInlineToolCall(call);
					stopReason = "tool_use";
				}
			}
			if (kimiParser) {
				const tail = kimiParser.finalize();
				if (tail.text.length > 0) {
					yield { type: "text_delta", text: tail.text };
				}
				for (const call of tail.toolCalls) {
					yield emitKimiToolCall(call);
					stopReason = "tool_use";
				}
			}

			yield { type: "message_end", stopReason };
		},
	};
}

/**
 * Phase B carry-over: convert an InlineParsedToolCall (from the XML
 * parser) into a `tool_call` ProviderStreamEvent so downstream sees
 * the same shape as the Anthropic-native tools envelope produces.
 */
function emitInlineToolCall(call: InlineParsedToolCall): ProviderStreamEvent {
	return {
		type: "tool_call",
		id: call.id,
		name: call.name,
		args: call.args as Record<string, unknown>,
	};
}

function emitKimiToolCall(call: KimiParsedToolCall): ProviderStreamEvent {
	return {
		type: "tool_call",
		id: call.id,
		name: call.name,
		args: call.args,
	};
}

function toAnthropicMessages(messages: readonly ConversationMessage[]): AnthropicMessage[] {
	const out: AnthropicMessage[] = [];
	// 2026-06-01: image-history pruning, mirror of openai-compatible.ts. Old
	// screenshots replay on every turn and balloon vision-token cost. Keep
	// only the most recent image-bearing user message; earlier ones get a
	// breadcrumb instead.
	let lastImageMsgIdx = -1;
	for (let i = 0; i < messages.length; i++) {
		if (messages[i].role === "user" && messages[i].parts.some((p) => p.kind === "image")) {
			lastImageMsgIdx = i;
		}
	}
	// 2026-06-06: pre-scan every assistant message for tool_use ids so we
	// can drop orphan tool_result blocks before the wire body is built.
	// Anthropic STRICTLY enforces the pairing — sending a tool_result whose
	// tool_use_id has no matching tool_use returns:
	//   400 invalid_request_error
	//   "unexpected tool_use_id found in tool_result blocks: <id>.
	//    Each tool_result block must have a corresponding tool_use block
	//    in the previous message."
	// OpenAI tolerates the same shape silently. The known offender is the
	// agent's loop-guard synth (`loop_guard_*` ids — see agent.ts), but the
	// filter is generic: any tool_result whose id isn't a known tool_use is
	// stripped. The original output stays in the agent's internal history;
	// only the WIRE body is filtered. Loop-guard advice still reaches the
	// model via the next user turn's system note / chat error event.
	const validToolUseIds = new Set<string>();
	for (const msg of messages) {
		if (msg.role !== "assistant") continue;
		for (const p of msg.parts) {
			if (p.kind === "tool_call" && p.id) validToolUseIds.add(p.id);
		}
	}
	for (let i = 0; i < messages.length; i++) {
		const msg = messages[i];
		if (msg.role === "system") continue; // system prompt lives in the top-level `system` field

		if (msg.role === "tool") {
			const blocks: AnthropicContentBlock[] = [];
			for (const part of msg.parts) {
				if (part.kind === "tool_result") {
					// Drop orphan tool_result blocks — Anthropic 400s without this.
					if (!validToolUseIds.has(part.id)) continue;
					const content = typeof part.output === "string" ? part.output : JSON.stringify(part.output);
					blocks.push({
						type: "tool_result",
						tool_use_id: part.id,
						content,
						...(part.isError ? { is_error: true } : {}),
					});
				}
			}
			if (blocks.length > 0) out.push({ role: "user", content: blocks });
			continue;
		}

		if (msg.role === "user") {
			const hasImages = msg.parts.some((p) => p.kind === "image");
			// Stale image-bearing message — replace images with a breadcrumb.
			if (hasImages && i !== lastImageMsgIdx) {
				const imageCount = msg.parts.filter((p) => p.kind === "image").length;
				const text = msg.parts
					.filter((p) => p.kind === "text")
					.map((p) => (p as { text: string }).text)
					.join("");
				const breadcrumb = `[${imageCount} earlier screenshot${imageCount === 1 ? "" : "s"} hidden to stay within the token limit — re-capture if you need to look again.]`;
				out.push({ role: "user", content: text.length > 0 ? `${text}\n\n${breadcrumb}` : breadcrumb });
				continue;
			}
			const texts: string[] = [];
			const images: AnthropicContentBlock[] = [];
			for (const p of msg.parts) {
				if (p.kind === "text") texts.push(p.text);
				else if (p.kind === "image") {
					const { mediaType, data } = splitImageDataUrl(p.dataUrl, p.mimeType);
					images.push({
						type: "image",
						source: { type: "base64", media_type: mediaType, data },
					});
				}
			}
			const text = texts.join("");
			if (images.length > 0) {
				const blocks: AnthropicContentBlock[] = [...images];
				if (text) blocks.push({ type: "text", text });
				out.push({ role: "user", content: blocks });
			} else if (text) {
				out.push({ role: "user", content: text });
			}
			continue;
		}

		if (msg.role === "assistant") {
			const blocks: AnthropicContentBlock[] = [];
			for (const part of msg.parts) {
				if (part.kind === "text") blocks.push({ type: "text", text: part.text });
				else if (part.kind === "tool_call") {
					blocks.push({ type: "tool_use", id: part.id, name: part.name, input: part.args });
				}
			}
			if (blocks.length > 0) out.push({ role: "assistant", content: blocks });
		}
	}
	return out;
}

function toAnthropicTool(t: ToolSpec): AnthropicToolDef {
	return {
		name: t.name,
		description: t.description,
		input_schema: t.schema,
	};
}

async function safeReadText(response: Response): Promise<string> {
	try {
		return (await response.text()).slice(0, 500);
	} catch {
		return "";
	}
}

/**
 * Anthropic's `image` block needs the raw base64 and a separate media_type.
 * Strip the `data:image/png;base64,` prefix if present; fall back to the
 * caller-supplied mimeType when the URL doesn't carry one.
 */
function splitImageDataUrl(
	dataUrl: string,
	fallbackMime: string,
): { mediaType: string; data: string } {
	const m = /^data:([^;,]+);base64,(.*)$/i.exec(dataUrl);
	if (m) return { mediaType: m[1], data: m[2] };
	return { mediaType: fallbackMime, data: dataUrl };
}
