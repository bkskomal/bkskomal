// 2026-05-25: Phase B — inline-XML tool format for open-weight models.
// `openai-compatible.ts` decides per-request which format to use based
// on `detectModelQuirks(modelId).toolCallFormat`. When `inline-xml`,
// we suppress the `tools` array, inject the format description into
// the system prompt, and route the streamed text through the parser.
import {
	type InlineParsedToolCall,
	InlineXmlToolParser,
	KimiNativeToolParser,
	type KimiParsedToolCall,
	buildInlineXmlToolPrompt,
} from "@oati/agent-core";
import {
	type ConversationMessage,
	type MessagePart,
	type ProviderRequest,
	type ProviderSpec,
	type ProviderStreamEvent,
	type ToolSpec,
	buildPromptForShape,
	detectModelQuirks,
} from "@oati/shared";
import { retryFetch } from "./retry-fetch";

export interface OpenAICompatibleConfig {
	readonly id: string;
	readonly displayName: string;
	readonly baseUrl: string;
	readonly apiKey?: string;
	readonly extraHeaders?: Readonly<Record<string, string>>;
	/**
	 * Optional override for the OpenRouter `provider` routing block (only
	 * sent when the baseUrl points at openrouter.ai and the request is for
	 * a Kimi K2 family model). Lets a power user pin to one specific
	 * provider, change the order list, or disable fallbacks.
	 *
	 * Defaults (when omitted, applied only on OpenRouter + Kimi K2 model):
	 *   { order: ["Fireworks", "Together", "Novita", "SiliconFlow"],
	 *     require_parameters: true,
	 *     allow_fallbacks: true }
	 *
	 * Background: OpenRouter routes Kimi K2.6 across ~13 providers per
	 * request, and several (DeepInfra FP4, Baseten, Groq via OR) leak
	 * Kimi's native `<|tool_call_begin|>` tokens as raw text instead of
	 * structured tool_calls. The defaults pin to providers with the best
	 * tool-call F1 per Moonshot's K2 Vendor Verifier (Fireworks ≥99%,
	 * Together, Novita, SiliconFlow). Setting this to `null` disables
	 * the injection entirely.
	 */
	readonly openrouterProviderRouting?: OpenRouterProviderRouting | null;
}

export interface OpenRouterProviderRouting {
	readonly order?: readonly string[];
	readonly only?: readonly string[];
	readonly ignore?: readonly string[];
	readonly require_parameters?: boolean;
	readonly allow_fallbacks?: boolean;
}

type WireContentPart =
	| { type: "text"; text: string }
	| { type: "image_url"; image_url: { url: string } };

interface WireToolCall {
	id: string;
	type: "function";
	function: { name: string; arguments: string };
}

interface WireMessage {
	role: "system" | "user" | "assistant" | "tool";
	content: string | WireContentPart[] | null;
	tool_call_id?: string;
	tool_calls?: WireToolCall[];
	/**
	 * 2026-06-01: thinking-mode reasoning trace on assistant turns. Kimi
	 * K2.6 REQUIRES this when replaying assistant messages that originally
	 * had reasoning_content — it errors with "thinking is enabled but
	 * reasoning_content is missing in assistant tool call message at
	 * index N" otherwise. Other endpoints ignore the field if they don't
	 * care, so it's safe to always emit when present.
	 */
	reasoning_content?: string;
}

interface WireToolDef {
	type: "function";
	function: {
		name: string;
		description: string;
		parameters: unknown;
	};
}

interface WireChunkDelta {
	content?: string;
	/**
	 * Reasoning-mode token stream. DeepSeek-R1 and several Qwen variants
	 * use `reasoning_content`; some gateways (and the OpenAI Responses-API-
	 * shim shape) use `reasoning`. We accept both — see the consumer below.
	 */
	reasoning_content?: string;
	reasoning?: string;
	tool_calls?: Array<{
		index: number;
		id?: string;
		function?: { name?: string; arguments?: string };
	}>;
}

interface WireChunk {
	choices?: Array<{
		delta?: WireChunkDelta;
		finish_reason?: string | null;
	}>;
	usage?: {
		prompt_tokens?: number;
		completion_tokens?: number;
		total_tokens?: number;
	};
}

export function createOpenAICompatibleProvider(config: OpenAICompatibleConfig): ProviderSpec {
	return {
		id: config.id,
		displayName: config.displayName,
		async *stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			const headers: Record<string, string> = {
				"Content-Type": "application/json",
				Accept: "text/event-stream",
				...(config.extraHeaders ?? {}),
			};
			if (config.apiKey) headers.Authorization = `Bearer ${config.apiKey}`;

			// 2026-05-25: pick tool-call protocol per model.
			//   - "openai-tools" — frontier models (Claude, GPT, Gemini)
			//     use the structured `tools` envelope. Wire tools sent.
			//   - "inline-xml" — Cline-style `<tool>...</tool>` for most
			//     open-weight models (Qwen, DeepSeek, Gemma, Llama). Wire
			//     tools SUPPRESSED; the schema goes into the system prompt
			//     via buildInlineXmlToolPrompt; the parser pulls calls out
			//     of the text channel.
			//   - "kimi-native" — Kimi K2 / K2.6 was TRAINED on OpenAI-
			//     style function-call schemas; it needs to SEE the tools
			//     array to know what's available. Then it emits its
			//     native `<|tool_call_begin|>` markers. Most gateways
			//     convert those to OpenAI tool_call deltas on the wire,
			//     but some leak them as raw text — the KimiNativeToolParser
			//     handles the text-leak path. So: wire tools STAY ON for
			//     Kimi, AND we keep the parser as a safety net.
			// Bug fixed (2026-05-25): previously suppressed wire tools
			// for Kimi too, leaving the model with no schema. Result:
			// JSON spec dumps and hallucinated completions.
			const modelQuirks = detectModelQuirks(req.modelId);
			const toolCallFormat = modelQuirks.toolCallFormat;
			const useInlineXml = toolCallFormat === "inline-xml";
			const useKimiNative = toolCallFormat === "kimi-native";
			// Only inline-xml suppresses wire tools. Kimi gets the schema.
			const suppressWireTools = useInlineXml;
			const inlineParser =
				useInlineXml && req.tools ? new InlineXmlToolParser(req.tools.map((t) => t.name)) : undefined;
			const kimiParser =
				useKimiNative && req.tools ? new KimiNativeToolParser(req.tools.map((t) => t.name)) : undefined;
			// kimi-native keeps the regular system prompt — the wire tools
			// array already tells Kimi what's available in the format it
			// was trained on. The XML addendum is inline-xml-only.
			const augmentedSystem =
				useInlineXml && req.tools && req.tools.length > 0
					? `${req.systemPrompt ?? ""}\n\n${buildInlineXmlToolPrompt(req.tools)}`.trim()
					: req.systemPrompt;

			// 2026-06-03: collect wire-filter diagnostics so we can warn
			// the caller when malformed entries got dropped. Without this,
			// a session whose history contained empty-id tool_calls would
			// silently drop them and the wire body could end up
			// imbalanced; surfacing the drop count lets the agent's
			// chat-visible error channel name what went wrong.
			const wireDiagnostics = {
				droppedToolCallIds: [] as string[],
				droppedToolResultIds: [] as string[],
			};
			// 2026-06-05: omit `temperature` when the model rejects it.
			// Applies to Claude Opus 4.7+ routed via OpenRouter / LiteLLM —
			// the gateway forwards to Anthropic, which now rejects the
			// field. `requiresTemperature` (if set) wins over the request's
			// value; `omitTemperature` takes precedence over both.
			const wireTemperature = modelQuirks.omitTemperature
				? undefined
				: (modelQuirks.requiresTemperature ?? req.temperature);
			// 2026-06-16: vLLM /v1/completions fallback for models whose
			// gateway has no tokenizer chat_template AND blocks request-side
			// templates (Gemma 4, Qwen 3 Coder on the OATI internal gateway).
			// The completions endpoint takes a raw prompt string, side-
			// stepping the chat-template machinery entirely. Kimi / Claude /
			// GPT / gpt-oss / Gemma 3 leave `useCompletionsFallback` unset
			// and fall through to the normal /v1/chat/completions path below.
			if (modelQuirks.useCompletionsFallback && modelQuirks.promptShape) {
				const wireMessages = flattenToolRolesForChatTemplate(
					toWireMessages(augmentedSystem, req.messages, wireDiagnostics),
				);
				yield* streamFromCompletions({
					config,
					req,
					headers,
					wireMessages,
					promptShape: modelQuirks.promptShape,
					maxTokens: req.maxTokens,
					temperature: wireTemperature,
				});
				return;
			}
			const body: Record<string, unknown> = {
				model: req.modelId,
				messages: toWireMessages(augmentedSystem, req.messages, wireDiagnostics),
				// inline-XML mode deliberately suppresses `tools` — that
				// format lives in the system prompt. Every other mode
				// (including kimi-native) sends the schema so the model
				// knows what's callable.
				tools:
					!suppressWireTools && req.tools && req.tools.length > 0
						? req.tools.map(toWireTool)
						: undefined,
				stream: true,
				...(wireTemperature !== undefined ? { temperature: wireTemperature } : {}),
				max_tokens: req.maxTokens,
			};

			// 2026-05-25: OpenRouter provider routing for Kimi K2.
			// When the base URL is OpenRouter AND the model is Kimi K2 family,
			// inject a `provider` block that pins to providers with the best
			// tool-call F1 per Moonshot's K2 Vendor Verifier. Without this,
			// OR's per-request load balancer can land on a provider that
			// streams `<|tool_call_begin|>` tokens as text (DeepInfra FP4,
			// Baseten, Groq via OR) and our parsers / safety nets pick up
			// the slack — but it's better not to land there in the first
			// place. Skipped on non-OR endpoints (self-hosted vLLM, Moonshot
			// direct) and overridable per OpenAICompatibleConfig.
			const requestHasImage = req.messages.some(
				(m) => m.role === "user" && m.parts.some((p) => p.kind === "image"),
			);
			const providerBlock = resolveOpenRouterProviderBlock(
				config.baseUrl,
				req.modelId,
				config.openrouterProviderRouting,
				{ hasImageInput: requestHasImage },
			);
			if (providerBlock) body.provider = providerBlock;

			// 2026-06-03: surface the wire-filter diagnostic before fetch.
			// If any entries got dropped, yield an error event so the
			// chat shows what happened. This doesn't fail the request —
			// the filter has already balanced the wire as best it could
			// — but it tells the user/agent that history needed cleanup.
			const totalDropped =
				wireDiagnostics.droppedToolCallIds.length + wireDiagnostics.droppedToolResultIds.length;
			if (totalDropped > 0) {
				yield {
					type: "error",
					message: `[wire-filter] dropped ${wireDiagnostics.droppedToolCallIds.length} empty-id tool_call${wireDiagnostics.droppedToolCallIds.length === 1 ? "" : "s"} and ${wireDiagnostics.droppedToolResultIds.length} empty-id tool_result${wireDiagnostics.droppedToolResultIds.length === 1 ? "" : "s"} from the wire body. Session history likely contains corruption from an earlier turn; the agent's repair pass should clean it on next save.`,
				};
			}

			// 2026-05-27: provider-level retry for the "200 OK with empty SSE
			// body" failure mode (OpenRouter burst, upstream timeout, route
			// hiccup that returns the envelope but no content). One retry of
			// the same request often recovers because the gateway re-routes.
			// We can ONLY retry while no useful events have been yielded yet
			// — once the consumer has seen tokens, re-issuing the request
			// would duplicate output. Tracked per-attempt via `usefulYielded`.
			const MAX_EMPTY_STREAM_RETRIES = 1;
			let providerAttempt = 0;
			while (providerAttempt <= MAX_EMPTY_STREAM_RETRIES + 1) {
				providerAttempt++;
				let usefulYielded = false;

				let response: Response;
				try {
					response = await retryFetch(
						`${config.baseUrl.replace(/\/$/, "")}/chat/completions`,
						{
							method: "POST",
							headers,
							body: JSON.stringify(body),
							signal: req.signal,
						},
						{
							onRetry: ({ attempt, reason, delayMs }) => {
								console.warn(
									`[${config.id}] retry attempt ${attempt}: ${reason} — backing off ${delayMs}ms`,
								);
							},
						},
					);
				} catch (err) {
					yield {
						type: "error",
						message: `${config.displayName} request failed: ${
							err instanceof Error ? err.message : String(err)
						}`,
					};
					yield { type: "message_end", stopReason: "error" };
					return;
				}

				if (!response.ok || !response.body) {
					const detail = await safeReadText(response);
					// 2026-06-01: gateways that pre-flight requests (e.g. the
					// OATI LLM Gateway's vision-capability check) return
					// HTTP 4xx + a structured `{"error": {"type", "message",
					// "hint", "missing_capabilities", ...}}` body. Format it
					// nicely so the user sees the actionable hint instead of
					// the generic "HTTP 400 {...stringified body...}". Falls
					// back to the legacy format when the body isn't a
					// recognised structured envelope.
					const formatted = formatStructuredErrorBody(detail);
					yield {
						type: "error",
						message:
							formatted ??
							`${config.displayName} HTTP ${response.status} ${response.statusText}${
								detail ? `: ${detail}` : ""
							}`,
					};
					yield { type: "message_end", stopReason: "error" };
					return;
				}

				// 2026-06-01: universal request diagnostic — fires for EVERY
				// upstream provider regardless of base URL. Previously this
				// only ran for OpenRouter (`isOpenRouterBaseUrl`), which
				// meant users on LiteLLM gateways, vLLM, Moonshot direct,
				// or any other endpoint got NO visibility into request
				// routing. We were debugging a LiteLLM empty-stream issue
				// for hours with all the diagnostic landing in unused OR
				// code. Now the prefix is `[provider-routing]` for ANY
				// endpoint and includes the base URL host so we can tell
				// providers apart at a glance.
				const hasImageInRequest = req.messages.some(
					(m) => m.role === "user" && m.parts.some((p) => p.kind === "image"),
				);
				const requestBytes = (b: unknown) => (typeof b === "string" ? b.length : 0);
				const orProvider = response.headers.get("openrouter-provider-name");
				const orCost = response.headers.get("openrouter-cost");
				const orGenId = response.headers.get("openrouter-generation-id");
				const contentType = response.headers.get("content-type") ?? "?";
				const reqBytes = requestBytes(JSON.stringify(body));
				const hostLabel = (() => {
					try {
						return new URL(config.baseUrl).host;
					} catch {
						return config.baseUrl;
					}
				})();
				const parts = [
					`host=${hostLabel}`,
					`model=${req.modelId}`,
					`status=${response.status}`,
					`content-type=${contentType.split(";")[0]}`,
					`req-bytes=${reqBytes}`,
				];
				if (hasImageInRequest) parts.push("image-bearing");
				if (orProvider) parts.push(`or-provider=${orProvider}`);
				if (orCost) parts.push(`or-cost=${orCost}`);
				if (orGenId) parts.push(`or-gen=${orGenId}`);
				const diagMsg = `[provider-routing] ${parts.join(" ")}`;
				console.info(`[${config.id}] ${diagMsg}`);
				yield { type: "error", message: diagMsg };

				const decoder = new TextDecoder();
				let buf = "";
				const partialCalls = new Map<number, { id?: string; name?: string; args: string }>();
				let stopReason: "end" | "tool_use" | "max_tokens" | "error" = "end";
				// Reasoning-stream bookkeeping: emit the "💭 " prefix once on the
				// first reasoning_content delta, and emit a blank-line separator
				// once when the model transitions back to regular `content`.
				let sawReasoning = false;
				let emittedReasoningSeparator = false;
				// 2026-06-01: track raw response bytes + a snippet of the first
				// SSE payload so an empty-stream symptom can be diagnosed
				// without another reproduction. When usefulYielded stays false
				// at end of stream, we emit a diagnostic with these so the user
				// can SEE whether the upstream returned nothing, returned an
				// error wrapper, or returned content we failed to decode.
				let totalResponseBytes = 0;
				let firstNonEmptyPayloadSnippet = "";
				// 2026-06-01: when the upstream embeds an error envelope in
				// an otherwise-200-OK SSE stream (LiteLLM does this with
				// `stream_failed`, the Moonshot direct API does it with
				// `{"error":{"message":"..."}}`), we want to terminate the
				// turn IMMEDIATELY with a clear message rather than wasting
				// the empty-stream retry budget. This holds the parsed
				// upstream error so the post-loop guard can short-circuit.
				let upstreamErrorMessage: string | undefined;

				outer: for await (const chunk of response.body as unknown as AsyncIterable<Uint8Array>) {
					totalResponseBytes += chunk.length;
					buf += decoder.decode(chunk, { stream: true });
					while (true) {
						const nlIdx = buf.indexOf("\n");
						if (nlIdx < 0) break;
						const line = buf.slice(0, nlIdx).trim();
						buf = buf.slice(nlIdx + 1);
						if (!line.startsWith("data:")) continue;
						const payload = line.slice(5).trim();
						if (payload === "[DONE]") {
							if (partialCalls.size > 0) stopReason = "tool_use";
							break outer;
						}
						if (firstNonEmptyPayloadSnippet === "" && payload.length > 0) {
							firstNonEmptyPayloadSnippet = payload.slice(0, 300);
						}
						let parsed: WireChunk;
						try {
							parsed = JSON.parse(payload);
						} catch {
							continue;
						}
						// 2026-06-01: error envelopes in the SSE stream. LiteLLM
						// gateways wrap upstream failures in
						// `{"error":{"code":"stream_failed","message":"..."}}`;
						// Moonshot direct uses `{"error":{"message":"..."}}`.
						// Both arrive over an HTTP 200 + text/event-stream
						// response, so the only way to surface them as the
						// useful error they are is to inspect each SSE
						// payload. Once we spot one, capture the message and
						// stop parsing — the post-loop short-circuit will
						// yield it as a terminal error and skip the retry.
						const errObj = (parsed as { error?: unknown }).error;
						if (errObj && typeof errObj === "object") {
							upstreamErrorMessage = extractUpstreamErrorMessage(errObj);
							if (upstreamErrorMessage) {
								stopReason = "error";
								break outer;
							}
						}
						if (parsed.usage) {
							yield {
								type: "usage",
								usage: {
									inputTokens: parsed.usage.prompt_tokens ?? 0,
									outputTokens: parsed.usage.completion_tokens ?? 0,
								},
							};
						}
						const delta = parsed.choices?.[0]?.delta;
						if (!delta) continue;
						// 2026-05-25: reasoning-model support. DeepSeek-R1, GPT-o1,
						// Kimi K2.6 in thinking mode, and several Qwen / Mistral
						// reasoning variants stream their tokens through
						// `delta.reasoning_content` (or `delta.reasoning`) rather
						// than `delta.content`.
						// 2026-06-01 redesign: separate `reasoning_delta` event
						// instead of prefixing text_delta with "💭 ". Reason: the
						// agent loop needs to capture reasoning into a
						// ReasoningPart on history (Moonshot K2.6 REQUIRES the
						// reasoning_content round-trip — replaying assistant
						// messages without their original reasoning trail
						// produces "thinking is enabled but reasoning_content is
						// missing in assistant tool call message at index N").
						// The webview learns to render reasoning_delta with the
						// 💭 marker; here we just pipe the raw content through.
						// The reasoning stream NEVER goes through the inline-XML
						// parser — Cline-style tool tags belong in the `content`
						// channel by spec, and reasoning text often contains
						// literal `<` characters from the model talking about
						// code, which would trip false-positive partial-tag holds.
						const reasoningDelta = delta.reasoning_content ?? delta.reasoning;
						if (typeof reasoningDelta === "string" && reasoningDelta.length > 0) {
							usefulYielded = true;
							sawReasoning = true;
							yield { type: "reasoning_delta", text: reasoningDelta };
						}
						if (delta.content) {
							usefulYielded = true;
							// Transition out of reasoning back to regular output —
							// add a separating newline so the answer is visually
							// distinct from the thought trail above it.
							if (sawReasoning && !emittedReasoningSeparator) {
								yield { type: "text_delta", text: "\n\n" };
								emittedReasoningSeparator = true;
							}
							if (inlineParser) {
								// 2026-05-25: inline-XML path. The text delta may
								// contain partial tool tags. The parser holds back
								// any in-progress tag, only emits SAFE plain text,
								// and yields completed tool calls as they assemble.
								const chunk = inlineParser.feed(delta.content);
								if (chunk.text.length > 0) {
									yield { type: "text_delta", text: chunk.text };
								}
								for (const call of chunk.toolCalls) {
									yield emitInlineToolCall(call);
									stopReason = "tool_use";
								}
							} else if (kimiParser) {
								// 2026-05-25: Kimi K2 / K2.6 native marker path.
								// Same buffering invariants — partial markers held
								// across SSE chunks, safe text emitted, completed
								// tool blocks become `tool_call` events.
								const chunk = kimiParser.feed(delta.content);
								if (chunk.text.length > 0) {
									yield { type: "text_delta", text: chunk.text };
								}
								for (const call of chunk.toolCalls) {
									yield emitKimiToolCall(call);
									stopReason = "tool_use";
								}
							} else {
								yield { type: "text_delta", text: delta.content };
							}
						}
						if (delta.tool_calls) {
							usefulYielded = true;
							for (const tc of delta.tool_calls) {
								const acc = partialCalls.get(tc.index) ?? { args: "" };
								if (tc.id) acc.id = tc.id;
								if (tc.function?.name) acc.name = tc.function.name;
								if (tc.function?.arguments) acc.args += tc.function.arguments;
								partialCalls.set(tc.index, acc);
							}
						}
						const finish = parsed.choices?.[0]?.finish_reason;
						if (finish === "tool_calls") stopReason = "tool_use";
						else if (finish === "length") stopReason = "max_tokens";
						// 2026-05-25: don't downgrade `tool_use` back to `end`.
						// When inline-XML or kimi-native parsers extract a tool
						// call from the text channel, they set stopReason to
						// "tool_use" — but the upstream gateway still reports
						// finish_reason="stop" because at its envelope level it
						// only saw text. The inline tool signal must win or the
						// agent loop will treat the turn as ended and never
						// execute the call.
						else if (finish === "stop" && stopReason !== "tool_use") stopReason = "end";
					}
				}

				for (const [, call] of partialCalls) {
					if (!call.name) continue;
					let parsedArgs: unknown = {};
					if (call.args) {
						parsedArgs = parseToolArgsLenient(call.args);
					}
					yield {
						type: "tool_call",
						id: call.id ?? `tc_${Math.random().toString(36).slice(2, 10)}`,
						name: call.name,
						args: parsedArgs,
					};
				}

				// 2026-05-25: inline-XML path closeout. After the stream ends,
				// flush any text the parser was holding (e.g., trailing prose
				// after the last tool tag) and any tool block that completed
				// on the final chunk. Also stamps `stopReason = "tool_use"`
				// when a flushed tool call appeared so the agent loop keeps
				// iterating instead of treating the turn as ended.
				if (inlineParser) {
					const tail = inlineParser.finalize();
					if (tail.text.length > 0) {
						usefulYielded = true;
						yield { type: "text_delta", text: tail.text };
					}
					for (const call of tail.toolCalls) {
						usefulYielded = true;
						yield emitInlineToolCall(call);
						stopReason = "tool_use";
					}
				}
				if (kimiParser) {
					const tail = kimiParser.finalize();
					if (tail.text.length > 0) {
						usefulYielded = true;
						yield { type: "text_delta", text: tail.text };
					}
					for (const call of tail.toolCalls) {
						usefulYielded = true;
						yield emitKimiToolCall(call);
						stopReason = "tool_use";
					}
				}

				// 2026-05-27: if nothing useful was emitted during this attempt
				// AND we haven't exhausted retries, restart the fetch. This
				// catches the "200 OK with empty SSE body" failure (gateway
				// 2026-06-01: upstream error envelope short-circuit. When
				// LiteLLM (or any gateway) embeds `{"error":...}` inside an
				// otherwise-200 SSE stream, yield the message as a terminal
				// error and DO NOT retry — retrying gets the same answer
				// and just wastes round-trips + clutters chat. Common
				// triggers: "No endpoints found that support image input"
				// (vision misconfig), "Rate limit exceeded" (quota),
				// authentication failures that the gateway 200-OK'd.
				if (upstreamErrorMessage) {
					yield {
						type: "error",
						message: `Upstream provider error: ${upstreamErrorMessage}`,
					};
					yield { type: "message_end", stopReason: "error" };
					return;
				}
				// flake) before the agent loop ever sees an empty turn.
				if (!usefulYielded && providerAttempt <= MAX_EMPTY_STREAM_RETRIES) {
					console.warn(
						`[${config.id}] empty stream on attempt ${providerAttempt} — retrying provider request`,
					);
					// 2026-06-01: surface WHAT the upstream returned so we can
					// tell whether it was truly empty, returned content we
					// failed to decode, or returned an error envelope we don't
					// recognise. Without this we keep blind-fixing
					// hypothetical bugs.
					const snippet = firstNonEmptyPayloadSnippet
						? firstNonEmptyPayloadSnippet
						: "(no SSE data: lines received)";
					yield {
						type: "error",
						message: `[provider-routing] empty-stream attempt ${providerAttempt} — bytes=${totalResponseBytes} first-payload="${snippet.replace(/\n/g, "\\n")}"`,
					};
					continue;
				}

				yield { type: "message_end", stopReason };
				return;
			} // end while
		},
	};
}

/**
 * Convert an `InlineParsedToolCall` (from the XML parser) into a
 * `tool_call` ProviderStreamEvent so the downstream agent loop sees a
 * shape identical to what the OpenAI-tools path produces.
 */
/**
 * 2026-06-01: pull a human-readable error message out of an upstream
 * error envelope embedded in an SSE stream. Handles three shapes we've
 * seen in the wild:
 *
 *   Shape A (Moonshot direct, OpenAI):
 *     {"error":{"message":"Rate limit","code":429}}
 *
 *   Shape B (LiteLLM gateway pre-2026-06-01 — the message field is
 *   itself a JSON-stringified envelope wrapping the real upstream
 *   error):
 *     {"error":{"code":"stream_failed",
 *               "message":"{\"error\":{\"message\":\"No endpoints found
 *                 that support image input\",\"code\":404}}"}}
 *
 *   Shape C (OATI LLM Gateway 2026-06-01+ — structured pre-flight
 *   refusal with a `type` discriminator and an actionable `hint`):
 *     {"error":{"type":"incompatible_route","code":400,
 *               "message":"Model 'X' doesn't support: ['vision']",
 *               "missing_capabilities":["vision"],
 *               "hint":"Add `capabilities: [vision]` to..."}}
 *
 * For shape B we unwrap one level — the real human message lives in
 * the inner `error.message`. For shape C we append the hint and the
 * missing-capabilities list. If unwrapping fails, fall back to the
 * outer message string (truncated to keep the chat message readable).
 *
 * Exported for tests.
 */
export function extractUpstreamErrorMessage(errObj: unknown): string | undefined {
	if (!errObj || typeof errObj !== "object") return undefined;
	const outer = errObj as {
		type?: unknown;
		code?: unknown;
		message?: unknown;
		hint?: unknown;
		missing_capabilities?: unknown;
	};
	const outerMessage = typeof outer.message === "string" ? outer.message : "";
	const outerCode = outer.code !== undefined ? String(outer.code) : "";

	// Shape C: structured pre-flight error with a hint. Highest priority
	// because the hint is the most actionable thing we can show.
	const hint = typeof outer.hint === "string" ? outer.hint : "";
	const missing = Array.isArray(outer.missing_capabilities)
		? (outer.missing_capabilities as unknown[]).filter((c): c is string => typeof c === "string")
		: [];
	const type = typeof outer.type === "string" ? outer.type : "";
	if (hint || missing.length > 0 || type === "incompatible_route") {
		const parts: string[] = [];
		// If the headline message is itself a JSON-stringified error envelope
		// (older gateway versions may still nest), unwrap one level to keep
		// the chat surface readable. Falls back to the raw message if the
		// unwrap fails — losing nothing.
		let headline = outerMessage;
		if (headline.startsWith("{") || headline.startsWith("[")) {
			try {
				const inner = JSON.parse(headline) as { error?: { message?: unknown } };
				const innerMessage =
					inner.error && typeof inner.error.message === "string" ? inner.error.message : "";
				if (innerMessage) headline = innerMessage;
			} catch {
				/* keep the raw headline */
			}
		}
		if (headline) parts.push(headline);
		if (missing.length > 0) parts.push(`Missing capabilities: ${missing.join(", ")}`);
		if (hint) parts.push(`💡 ${hint}`);
		if (parts.length > 0) {
			return outerCode ? `${parts.join("\n")} (code=${outerCode})` : parts.join("\n");
		}
	}

	// Shape B unwrap: outer.message is a JSON-stringified inner envelope.
	if (outerMessage.startsWith("{") || outerMessage.startsWith("[")) {
		try {
			const inner = JSON.parse(outerMessage) as { error?: { message?: unknown; code?: unknown } };
			const innerMessage =
				inner.error && typeof inner.error.message === "string" ? inner.error.message : "";
			const innerCode = inner.error?.code !== undefined ? String(inner.error.code) : "";
			if (innerMessage) {
				const codeSuffix = innerCode ? ` (code=${innerCode})` : "";
				const outerCodeTag = outerCode ? ` [${outerCode}]` : "";
				return `${innerMessage}${codeSuffix}${outerCodeTag}`;
			}
		} catch {
			/* fall through to the outer message */
		}
	}
	if (!outerMessage) return undefined;
	const truncated = outerMessage.length > 500 ? `${outerMessage.slice(0, 500)}…` : outerMessage;
	return outerCode ? `${truncated} (code=${outerCode})` : truncated;
}

/**
 * 2026-06-01: format a structured error response body (HTTP 4xx with
 * `{"error": {...}}` JSON) into a chat-renderable message. Used by the
 * `!response.ok` branch so pre-flight failures from the OATI LLM
 * Gateway (e.g. `incompatible_route`) show their hint directly
 * instead of being buried in a stringified body. Returns undefined
 * when the body isn't a recognized structured envelope — caller falls
 * back to the legacy "HTTP N: <body>" format.
 *
 * Exported for tests.
 */
export function formatStructuredErrorBody(body: string): string | undefined {
	if (!body || (!body.startsWith("{") && !body.startsWith("["))) return undefined;
	try {
		const parsed = JSON.parse(body) as { error?: unknown };
		return extractUpstreamErrorMessage(parsed.error);
	} catch {
		return undefined;
	}
}

function emitInlineToolCall(call: InlineParsedToolCall): ProviderStreamEvent {
	return {
		type: "tool_call",
		id: call.id,
		name: call.name,
		args: call.args as Record<string, unknown>,
	};
}

/**
 * Same shim as `emitInlineToolCall` but for the Kimi-native parser. Kept
 * separate so the parser modules can evolve independently — the agent's
 * `tool_call` event consumer doesn't care which parser produced the
 * call, just that the shape matches.
 */
function emitKimiToolCall(call: KimiParsedToolCall): ProviderStreamEvent {
	return {
		type: "tool_call",
		id: call.id,
		name: call.name,
		args: call.args,
	};
}

/**
 * Decide whether (and what) to send as the OpenRouter `provider` routing
 * block. Returns `undefined` to omit the block entirely (non-OR endpoints,
 * non-Kimi models, or explicit user opt-out via `routing === null`).
 *
 * The default block pins Kimi K2 to high-tool-call-accuracy providers
 * per Moonshot's K2 Vendor Verifier. Users can override per-config to
 * tighten (only/ignore) or loosen (allow_fallbacks: false).
 */
export interface ResolveProviderBlockOptions {
	readonly hasImageInput?: boolean;
}

export function resolveOpenRouterProviderBlock(
	baseUrl: string,
	modelId: string,
	override: OpenRouterProviderRouting | null | undefined,
	opts: ResolveProviderBlockOptions = {},
): OpenRouterProviderRouting | undefined {
	// Explicit opt-out.
	if (override === null) return undefined;
	if (!isOpenRouterBaseUrl(baseUrl)) return undefined;
	if (!isKimiK2Model(modelId)) return undefined;
	if (override) return override;
	// 2026-06-01: image-bearing requests get HARD-PINNED to MoonshotAI
	// (their own first-party provider on OpenRouter) with
	// allow_fallbacks=false. Reason: K2.6 added native vision in April
	// 2026 but not every third-party provider on OR has shipped vision
	// support yet. The earlier soft `order:[moonshotai, ...]` directive
	// was either being ignored or OR was routing to a fallback after
	// MoonshotAI declined — either way, user-attached images returned
	// empty stream. `only` is the hard pin per OR API docs; if
	// MoonshotAI is down the request will error explicitly (which we
	// can surface), instead of silently empty-streaming via a third-
	// party that can't handle vision.
	if (opts.hasImageInput) {
		return {
			only: ["moonshotai"],
			require_parameters: true,
			allow_fallbacks: false,
		};
	}
	// Default routing for text-only Kimi K2 / K2.6 turns: keep the
	// previous tool-F1-optimized provider list. MoonshotAI first;
	// fallbacks to high-tool-F1 third-parties so text-only turns still
	// get the throughput / cost benefits when MoonshotAI is rate-
	// limited. OpenRouter provider slugs are lowercase per their docs.
	return {
		order: ["moonshotai", "fireworks", "together", "novita", "siliconflow"],
		require_parameters: true,
		allow_fallbacks: true,
	};
}

function isOpenRouterBaseUrl(baseUrl: string): boolean {
	try {
		const u = new URL(baseUrl);
		return u.hostname === "openrouter.ai" || u.hostname.endsWith(".openrouter.ai");
	} catch {
		return false;
	}
}

function isKimiK2Model(modelId: string): boolean {
	return /kimi[-_./]?k2/i.test(modelId);
}

async function safeReadText(response: Response): Promise<string> {
	try {
		const t = await response.text();
		return t.slice(0, 500);
	} catch {
		return "";
	}
}

/**
 * Lenient parser for the streamed `function.arguments` field.
 *
 * The OpenAI wire contract says `arguments` is a JSON-encoded string of
 * an object. In practice, smaller / open-weight models bend the rules:
 *
 *   - Kimi K2 / K2.6 sometimes emits `arguments` as a JSON-string of a
 *     JSON-string of the object (double-encoded). Strict `JSON.parse`
 *     yields a plain string instead of the object, which then crashes
 *     every tool guard.
 *   - Some models inline literal control characters (raw \n, \t, \r)
 *     inside string values rather than escaping them. Strict JSON
 *     considers that a syntax error — but the intent is obvious, so
 *     we re-escape and retry rather than giving up.
 *
 * Strategy: try strict parse first (the common case), then a couple of
 * targeted repairs. If everything fails, fall back to `{ _raw: ... }`
 * — `normalizeToolArgs` in agent-core will take a second pass and the
 * tool itself can surface a precise error if it really is garbage.
 */
export function parseToolArgsLenient(raw: string): unknown {
	// (1) Strict parse — the happy path.
	try {
		return JSON.parse(raw);
	} catch {
		/* fall through */
	}
	// (2) Re-escape literal control chars inside string values. Some
	// models emit `"content":"line1\nline2"` with a raw newline byte
	// instead of an escaped `\n`. This walks the string and replaces
	// control bytes that appear *inside* a JSON string region.
	const repaired = escapeLiteralControlChars(raw);
	if (repaired !== raw) {
		try {
			return JSON.parse(repaired);
		} catch {
			/* fall through */
		}
	}
	// (3) Final fallback — hand the raw payload to the agent layer,
	// which has its own deep-unwrap logic (see normalizeToolArgs).
	return { _raw: raw };
}

/**
 * Walk a JSON-ish string, tracking whether we're inside a string literal,
 * and replace bare control characters with their escaped forms. Outside
 * of string literals we leave whitespace alone (those control chars are
 * already legal there).
 */
function escapeLiteralControlChars(s: string): string {
	let out = "";
	let inString = false;
	let prevBackslash = false;
	for (let i = 0; i < s.length; i++) {
		const ch = s[i];
		const code = s.charCodeAt(i);
		if (inString) {
			if (prevBackslash) {
				out += ch;
				prevBackslash = false;
				continue;
			}
			if (ch === "\\") {
				out += ch;
				prevBackslash = true;
				continue;
			}
			if (ch === '"') {
				out += ch;
				inString = false;
				continue;
			}
			if (code === 0x0a) {
				out += "\\n";
				continue;
			}
			if (code === 0x0d) {
				out += "\\r";
				continue;
			}
			if (code === 0x09) {
				out += "\\t";
				continue;
			}
			if (code < 0x20) {
				out += `\\u${code.toString(16).padStart(4, "0")}`;
				continue;
			}
			out += ch;
			continue;
		}
		if (ch === '"') {
			inString = true;
		}
		out += ch;
	}
	return out;
}

/**
 * 2026-06-16: stream from vLLM's /v1/completions endpoint instead of
 * /v1/chat/completions. The completions endpoint takes a raw prompt
 * string and returns text_completion SSE chunks — no chat template
 * machinery, so it works on vLLM gateways that have neither a tokenizer
 * chat_template nor `--trust-request-chat-template` enabled.
 *
 * Used when ModelQuirks declares `useCompletionsFallback: true` (Gemma 4,
 * Qwen 3 Coder on the OATI internal gateway). Doesn't touch the
 * /chat/completions code path used by Kimi / Claude / GPT / gpt-oss /
 * Gemma 3 — those models keep their existing behaviour.
 *
 * The function:
 *   1. Renders the wire messages to a flat prompt via the shape-specific
 *      builder (`buildGemmaPrompt` for Gemma turns, `buildChatMLPrompt`
 *      for ChatML).
 *   2. POSTs `{model, prompt, stream, max_tokens, temperature, stop}` to
 *      `${baseUrl}/completions` (note: NO trailing `/chat/`).
 *   3. Parses `data: {...}` SSE blocks shaped like
 *      `{choices: [{text, finish_reason}]}` — the text_completion shape,
 *      not the chat-completion delta shape — and emits each `text`
 *      fragment as a `text_delta` ProviderStreamEvent.
 *   4. Emits `message_end` with the appropriate stopReason on completion.
 *
 * Errors / 4xx surface the upstream body as a single `error` event then
 * `message_end {stopReason:"error"}`, matching the existing path's
 * behaviour so the agent's stuck-loop / chat-error handling stays the
 * same.
 */
async function* streamFromCompletions(opts: {
	config: OpenAICompatibleConfig;
	req: ProviderRequest;
	headers: Record<string, string>;
	wireMessages: readonly WireMessage[];
	promptShape: "gemma" | "chatml";
	maxTokens?: number;
	temperature?: number;
}): AsyncIterable<ProviderStreamEvent> {
	const { config, req, headers, wireMessages, promptShape, maxTokens, temperature } = opts;
	// Render the prompt. The wire messages are already tool-flattened,
	// but the builder takes a simpler PromptMessage shape — drop content
	// that isn't a string (image multi-part content blocks don't apply
	// to the text-only completions endpoint).
	const promptMessages: { role: "system" | "user" | "assistant"; content: string }[] = [];
	for (const m of wireMessages) {
		if (m.role === "tool") continue;
		const content = typeof m.content === "string" ? m.content : "";
		promptMessages.push({ role: m.role, content });
	}
	const { prompt, stop } = buildPromptForShape(promptShape, promptMessages);

	const body: Record<string, unknown> = {
		model: req.modelId,
		prompt,
		stream: true,
		max_tokens: maxTokens,
		stop: [...stop],
		...(temperature !== undefined ? { temperature } : {}),
	};

	let response: Response;
	try {
		response = await retryFetch(
			`${config.baseUrl.replace(/\/$/, "")}/completions`,
			{
				method: "POST",
				headers,
				body: JSON.stringify(body),
				signal: req.signal,
			},
			{
				onRetry: ({ attempt, reason, delayMs }) => {
					console.warn(
						`[${config.id}] /v1/completions retry attempt ${attempt}: ${reason} — backing off ${delayMs}ms`,
					);
				},
			},
		);
	} catch (err) {
		yield {
			type: "error",
			message: `${config.displayName} /v1/completions request failed: ${
				err instanceof Error ? err.message : String(err)
			}`,
		};
		yield { type: "message_end", stopReason: "error" };
		return;
	}

	// One-line diagnostic so the chat surface can confirm which endpoint
	// was hit — same shape as the /chat/completions path's `[provider-routing]`
	// line so existing log scrapers keep working.
	const hostLabel = (() => {
		try {
			return new URL(config.baseUrl).host;
		} catch {
			return config.baseUrl;
		}
	})();
	console.info(
		`[${config.id}] [provider-routing] host=${hostLabel} model=${req.modelId} status=${response.status} endpoint=/v1/completions promptShape=${promptShape}`,
	);

	if (!response.ok || !response.body) {
		const text = await response.text().catch(() => "(no body)");
		// Try to surface the upstream JSON error message verbatim so the
		// chat UI can show what the server actually said (e.g. the
		// "Chat template is passed with request..." error that prompted
		// this fallback path's existence).
		let userMessage = text;
		try {
			const parsed = JSON.parse(text) as { error?: { message?: string }; message?: string };
			userMessage =
				parsed.error?.message ?? parsed.message ?? text;
		} catch {
			/* keep raw body */
		}
		yield {
			type: "error",
			message: `${config.displayName} HTTP ${response.status} ${response.statusText}: ${userMessage}`,
		};
		yield { type: "message_end", stopReason: "error" };
		return;
	}

	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let buf = "";
	let stopReason: "end" | "max_tokens" | "error" = "end";
	let yieldedAny = false;
	let totalBytes = 0;
	let dataLinesSeen = 0;
	let parseErrors = 0;
	let firstPayloadSnippet = "";

	/**
	 * Process one logical SSE block (everything between two `\n\n`
	 * boundaries OR the tail of the stream). Multiple `data:` lines per
	 * block is rare on vLLM but allowed by spec, so we still iterate.
	 */
	const processBlock = function* (
		block: string,
	): Generator<ProviderStreamEvent, "end" | "max_tokens" | undefined, void> {
		let blockStop: "end" | "max_tokens" | undefined;
		for (const rawLine of block.split(/\r?\n/)) {
			const line = rawLine.replace(/^\s+/, "");
			if (!line.startsWith("data:")) continue;
			const payload = line.slice("data:".length).replace(/^\s/, "");
			if (payload === "[DONE]") continue;
			if (payload.length === 0) continue;
			dataLinesSeen++;
			if (firstPayloadSnippet === "") firstPayloadSnippet = payload.slice(0, 200);
			let parsed: { choices?: Array<{ text?: string; finish_reason?: string | null }> };
			try {
				parsed = JSON.parse(payload);
			} catch {
				parseErrors++;
				continue;
			}
			const choice = parsed.choices?.[0];
			if (!choice) continue;
			// 2026-06-16: yield ANY text — even single characters arriving
			// in tiny chunks. Empty-string deltas (which vLLM emits as
			// warmup before the first real token) get filtered.
			if (typeof choice.text === "string" && choice.text.length > 0) {
				yield { type: "text_delta", text: choice.text };
				yieldedAny = true;
			}
			if (choice.finish_reason) {
				if (choice.finish_reason === "length") blockStop = "max_tokens";
				else blockStop = "end";
			}
		}
		return blockStop;
	};

	try {
		while (true) {
			const { value, done } = await reader.read();
			if (done) break;
			if (value) totalBytes += value.byteLength;
			buf += decoder.decode(value, { stream: true });
			// SSE blocks are separated by `\n\n` (or `\r\n\r\n`).
			while (true) {
				const sepLF = buf.indexOf("\n\n");
				const sepCRLF = buf.indexOf("\r\n\r\n");
				let sepAt = -1;
				let sepLen = 0;
				if (sepLF >= 0 && (sepCRLF < 0 || sepLF < sepCRLF)) {
					sepAt = sepLF;
					sepLen = 2;
				} else if (sepCRLF >= 0) {
					sepAt = sepCRLF;
					sepLen = 4;
				}
				if (sepAt < 0) break;
				const block = buf.slice(0, sepAt);
				buf = buf.slice(sepAt + sepLen);
				const blockResult = yield* processBlock(block);
				if (blockResult) stopReason = blockResult;
			}
		}
		// Flush any tail (vLLM occasionally closes without a final \n\n).
		if (buf.trim().length > 0) {
			const blockResult = yield* processBlock(buf);
			if (blockResult) stopReason = blockResult;
			buf = "";
		}
	} catch (err) {
		yield {
			type: "error",
			message: `${config.displayName} /v1/completions stream error: ${
				err instanceof Error ? err.message : String(err)
			}`,
		};
		stopReason = "error";
	}

	// 2026-06-16: always emit a diagnostic summarising what came back so
	// "empty response" failures can be triaged. Surfaces in chat as an
	// `Agent diagnostic` chip (filtered to Diagnostics mode by the
	// webview's isInternalAgentDiagnosticMessage check on the
	// `[completions-fallback]` prefix).
	yield {
		type: "error",
		message: `[completions-fallback] ${config.id} model=${req.modelId} bytes=${totalBytes} data-lines=${dataLinesSeen} parse-errors=${parseErrors} yielded=${yieldedAny} stop=${stopReason} firstPayload=${firstPayloadSnippet.slice(0, 120)}`,
	};

	if (!yieldedAny && stopReason === "end") {
		yield {
			type: "error",
			message: `${config.displayName} /v1/completions returned no usable text. The gateway returned ${totalBytes} bytes across ${dataLinesSeen} data lines (parse errors: ${parseErrors}). First payload snippet: ${firstPayloadSnippet}`,
		};
		stopReason = "error";
	}

	yield { type: "message_end", stopReason };
}

/**
 * 2026-06-16: collapse `tool` roles + assistant `tool_calls` into inline
 * text so a 3-role chat_template (system / user / assistant) can render
 * the conversation without choking.
 *
 * Only runs when `ModelQuirks.chatTemplate` is set (Gemma 4, Qwen 3
 * Coder via the OATI vLLM gateway today). Other models — Kimi, Claude,
 * GPT, gpt-oss, anything with a tokenizer-defined chat_template — skip
 * this step and keep the structured tool messages they were built with.
 *
 * Wire shape transformation:
 *
 *   role:"tool" content:"<result>"
 *      → role:"user" content:"Tool result (id=<id>):\n<result>"
 *
 *   role:"assistant" content:"think.." tool_calls:[{name,args,id}]
 *      → role:"assistant" content:"think..\n\n[Calling tool <name>(<args>)]"
 *      (the tool_calls array is dropped from the wire entry)
 *
 * The transformation is deliberately verbose-textual rather than trying
 * to emit the model's native tool-call syntax: in inline-XML mode the
 * model's text already contains the XML markers, so re-serialising
 * tool_calls as XML would risk double-encoding. Plain English is what
 * Gemma / Qwen 3 actually need to follow the prior turn's reasoning.
 */
function flattenToolRolesForChatTemplate(messages: readonly WireMessage[]): WireMessage[] {
	const out: WireMessage[] = [];
	for (const msg of messages) {
		if (msg.role === "tool") {
			const text = typeof msg.content === "string" ? msg.content : JSON.stringify(msg.content);
			const idTag = msg.tool_call_id ? ` (id=${msg.tool_call_id})` : "";
			out.push({
				role: "user",
				content: `Tool result${idTag}:\n${text}`,
			});
			continue;
		}
		if (msg.role === "assistant" && msg.tool_calls && msg.tool_calls.length > 0) {
			const callLines = msg.tool_calls.map(
				(tc) => `[Calling tool ${tc.function.name}(${tc.function.arguments})]`,
			);
			const baseText =
				typeof msg.content === "string"
					? msg.content
					: msg.content === null
						? ""
						: msg.content
								.filter((p): p is { type: "text"; text: string } => p.type === "text")
								.map((p) => p.text)
								.join("");
			const combined = [baseText, ...callLines].filter((s) => s.length > 0).join("\n\n");
			const next: WireMessage = { role: "assistant", content: combined };
			if (msg.reasoning_content) next.reasoning_content = msg.reasoning_content;
			out.push(next);
			continue;
		}
		out.push(msg);
	}
	return out;
}

function toWireMessages(
	systemPrompt: string | undefined,
	messages: readonly ConversationMessage[],
	/**
	 * 2026-06-03: optional diagnostic sink. When provided, the wire
	 * filter pushes notes about entries it dropped (empty-id tool_calls /
	 * tool_results) so the agent loop can surface a chat-visible warning
	 * before the request goes out. Helps explain otherwise-mysterious
	 * "tool_call_id is not found" upstream errors.
	 */
	diagnostics?: { droppedToolCallIds: string[]; droppedToolResultIds: string[] },
): WireMessage[] {
	const out: WireMessage[] = [];
	const droppedToolCallIds = diagnostics?.droppedToolCallIds ?? [];
	const droppedToolResultIds = diagnostics?.droppedToolResultIds ?? [];
	if (systemPrompt) out.push({ role: "system", content: systemPrompt });
	// 2026-06-01: image-history pruning. Every prior screenshot replayed
	// on every turn balloons vision-token cost — a live trace hit 950k
	// tokens vs a 262k cap after a fullPage screenshot. Old screenshots
	// are rarely re-referenced; we keep only the MOST RECENT user message
	// that carries images and replace prior images with a breadcrumb so
	// the model still knows an image existed there. The stored history is
	// untouched — pruning happens only at wire-serialization time.
	let lastImageMsgIdx = -1;
	for (let i = 0; i < messages.length; i++) {
		if (messages[i].role === "user" && messages[i].parts.some((p) => p.kind === "image")) {
			lastImageMsgIdx = i;
		}
	}
	// 2026-06-03: pre-scan to compute the set of tool_call_ids that will
	// survive the wire filter. Any tool_result whose id isn't in this set
	// (because the matching assistant tool_call was dropped — empty id,
	// empty name, etc.) MUST also be dropped, otherwise the wire body
	// becomes imbalanced and the upstream rejects with `tool_call_id
	// <id> is not found`. Live-bug: a model emitted a tool_call with an
	// empty function name; the prior filter dropped the assistant entry
	// but kept the tool_result, producing an orphan-on-the-wire that
	// confused the upstream's pair matcher.
	const validToolCallIds = new Set<string>();
	for (const m of messages) {
		if (m.role !== "assistant") continue;
		for (const p of m.parts) {
			if (p.kind !== "tool_call") continue;
			if (typeof p.id !== "string" || p.id.length === 0) continue;
			if (typeof p.name !== "string" || p.name.length === 0) continue;
			validToolCallIds.add(p.id);
		}
	}
	for (let i = 0; i < messages.length; i++) {
		const msg = messages[i];
		if (msg.role === "tool") {
			for (const part of msg.parts) {
				if (part.kind === "tool_result") {
					// 2026-06-01: defense-in-depth. An empty tool_call_id
					// gets rejected by OpenAI's validator with `tool_call_id
					//   is not found` (note the double space — empty id
					// interpolated). The agent-core layer synthesizes
					// fallback ids at ingestion, but a session loaded from
					// disk with corrupted state could still surface one;
					// filter here so the wire request stays valid.
					if (typeof part.id !== "string" || part.id.length === 0) {
						droppedToolResultIds.push(`(empty:idx ${i})`);
						continue;
					}
					// 2026-06-03: also drop tool_results whose id doesn't
					// match any surviving assistant tool_call. Without this,
					// the wire body ends up with orphan tool_results (the
					// matching assistant call was dropped for some other
					// reason — empty name, malformed shape) and the
					// upstream rejects with `tool_call_id <id> not found`.
					if (!validToolCallIds.has(part.id)) {
						droppedToolResultIds.push(`(orphan:${part.id}:idx ${i})`);
						continue;
					}
					out.push({
						role: "tool",
						tool_call_id: part.id,
						content: typeof part.output === "string" ? part.output : JSON.stringify(part.output),
					});
				}
			}
			continue;
		}
		// User turns with images need OpenAI's multi-part content array shape so
		// vision-capable models can see them. Plain-text turns stay as strings to
		// stay compatible with older OpenAI-compatible endpoints.
		if (msg.role === "user" && msg.parts.some((p) => p.kind === "image")) {
			// Prune: if this is NOT the most recent image-bearing user message,
			// strip the ImagePart payload and replace with a breadcrumb.
			if (i !== lastImageMsgIdx) {
				const imageCount = msg.parts.filter((p) => p.kind === "image").length;
				const text = partsToWireContent(msg.parts);
				const breadcrumb = `[${imageCount} earlier screenshot${imageCount === 1 ? "" : "s"} hidden to stay within the token limit — re-capture if you need to look again.]`;
				out.push({
					role: "user",
					content: text.length > 0 ? `${text}\n\n${breadcrumb}` : breadcrumb,
				});
				continue;
			}
			const blocks: WireContentPart[] = [];
			for (const p of msg.parts) {
				if (p.kind === "image") {
					blocks.push({ type: "image_url", image_url: { url: p.dataUrl } });
				}
			}
			const text = partsToWireContent(msg.parts);
			if (text) blocks.push({ type: "text", text });
			out.push({ role: "user", content: blocks });
			continue;
		}
		// Assistant turns may carry tool_calls in addition to (or instead of)
		// text. OpenAI's wire format requires those calls to appear as a
		// top-level `tool_calls` array so the subsequent `role:"tool"` reply
		// can be matched via `tool_call_id`. If we drop them, the API rejects
		// the next request with "tool message references unknown tool_call_id"
		// (or, worse, hangs waiting on a malformed conversation).
		if (msg.role === "assistant") {
			const toolCalls: WireToolCall[] = [];
			const reasoningChunks: string[] = [];
			for (const p of msg.parts) {
				if (p.kind === "tool_call") {
					// 2026-06-01: skip tool_calls with empty ids — they'd
					// produce unmatchable pairs on the wire (see the matching
					// guard in the role:"tool" branch above).
					if (typeof p.id !== "string" || p.id.length === 0) {
						droppedToolCallIds.push(`(empty:asst ${i})`);
						continue;
					}
					// 2026-06-03: also skip tool_calls with empty function
					// name. Live-bug: a model emitted a malformed tool-call
					// marker that produced `function.name === ""`. The
					// upstream's validator either rejects the request OR
					// fails to register the id in its pair-matcher; the
					// subsequent tool_result then looks like an orphan
					// reference and the user sees `tool_call_id <id> not
					// found`. Drop the malformed call entirely (the matching
					// tool_result will also drop because validToolCallIds
					// excludes it).
					if (typeof p.name !== "string" || p.name.length === 0) {
						droppedToolCallIds.push(`(empty-name:${p.id}:asst ${i})`);
						continue;
					}
					toolCalls.push({
						id: p.id,
						type: "function",
						function: {
							name: p.name,
							arguments: typeof p.args === "string" ? p.args : JSON.stringify(p.args ?? {}),
						},
					});
				} else if (p.kind === "reasoning") {
					reasoningChunks.push(p.text);
				}
			}
			const text = partsToWireContent(msg.parts);
			const wire: WireMessage = {
				role: "assistant",
				content: text.length > 0 ? text : null,
			};
			if (toolCalls.length > 0) wire.tool_calls = toolCalls;
			// 2026-06-01: round-trip reasoning_content for thinking-mode
			// models. Kimi K2.6 hard-requires this on replay; other
			// endpoints ignore it.
			const reasoning = reasoningChunks.join("");
			if (reasoning.length > 0) wire.reasoning_content = reasoning;
			out.push(wire);
			continue;
		}
		out.push({ role: msg.role, content: partsToWireContent(msg.parts) });
	}
	return out;
}

function partsToWireContent(parts: readonly MessagePart[]): string {
	const texts: string[] = [];
	for (const p of parts) {
		if (p.kind === "text") texts.push(p.text);
	}
	return texts.join("");
}

function toWireTool(t: ToolSpec): WireToolDef {
	return {
		type: "function",
		function: { name: t.name, description: t.description, parameters: t.schema },
	};
}
