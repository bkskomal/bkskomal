// Provider-level retry layer. Wraps fetch with classification-aware
// exponential backoff + jitter, respecting the `Retry-After` header when
// the server sends one. OpenRouter in particular is bursty on hot models
// (Kimi K2.6 routinely returns 429s during peak hours) and treating those
// as hard failures was costing users a turn. With this in place a single
// 429 or upstream 502 produces a brief pause + retry rather than a
// surfaced error.
//
// Scope: ONLY the initial request fetch. We do NOT retry mid-stream — once
// the server has started sending tokens, replaying the prompt would
// duplicate output. Mid-stream failures still propagate as errors.

export interface RetryFetchOptions {
	readonly maxAttempts?: number;
	readonly baseDelayMs?: number;
	readonly maxDelayMs?: number;
	/** Called before each retry. Useful for surfacing diagnostics. */
	readonly onRetry?: (info: {
		readonly attempt: number;
		readonly reason: string;
		readonly delayMs: number;
	}) => void;
}

const RETRY_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);
const DEFAULT_MAX_ATTEMPTS = 4;
const DEFAULT_BASE_DELAY_MS = 500;
const DEFAULT_MAX_DELAY_MS = 8000;
const RETRY_AFTER_CAP_MS = 60_000;

function classifyNetworkError(err: unknown): { retry: boolean; reason: string } {
	if (!(err instanceof Error)) return { retry: false, reason: String(err) };
	const msg = err.message.toLowerCase();
	if (msg.includes("abort") || (err as { name?: string }).name === "AbortError") {
		return { retry: false, reason: "aborted" };
	}
	if (msg.includes("econnreset")) return { retry: true, reason: "ECONNRESET" };
	if (msg.includes("etimedout") || msg.includes("timed out")) {
		return { retry: true, reason: "ETIMEDOUT" };
	}
	if (msg.includes("enotfound")) return { retry: false, reason: "ENOTFOUND" };
	if (msg.includes("econnrefused")) return { retry: false, reason: "ECONNREFUSED" };
	if (msg.includes("fetch failed") || msg.includes("network")) {
		return { retry: true, reason: "network" };
	}
	return { retry: false, reason: err.message };
}

function jitteredBackoff(attempt: number, base: number, max: number): number {
	const exp = Math.min(max, base * 2 ** (attempt - 1));
	// +/-30% jitter so a thundering herd of clients hitting the same 429
	// don't all retry at the same instant.
	const jitter = (Math.random() - 0.5) * exp * 0.3;
	return Math.max(50, Math.floor(exp + jitter));
}

function parseRetryAfter(header: string | null): number | undefined {
	if (!header) return undefined;
	const seconds = Number(header);
	if (Number.isFinite(seconds) && seconds >= 0) {
		return Math.min(RETRY_AFTER_CAP_MS, Math.floor(seconds * 1000));
	}
	const dateMs = Date.parse(header);
	if (Number.isFinite(dateMs)) {
		return Math.max(0, Math.min(RETRY_AFTER_CAP_MS, dateMs - Date.now()));
	}
	return undefined;
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
	return new Promise((resolve, reject) => {
		if (signal?.aborted) {
			reject(new DOMException("Aborted", "AbortError"));
			return;
		}
		const t = setTimeout(() => {
			cleanup();
			resolve();
		}, ms);
		const onAbort = () => {
			clearTimeout(t);
			cleanup();
			reject(new DOMException("Aborted", "AbortError"));
		};
		const cleanup = () => signal?.removeEventListener("abort", onAbort);
		signal?.addEventListener("abort", onAbort);
	});
}

export async function retryFetch(
	url: string,
	init: RequestInit & { signal?: AbortSignal },
	options: RetryFetchOptions = {},
): Promise<Response> {
	const maxAttempts = options.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;
	const baseDelay = options.baseDelayMs ?? DEFAULT_BASE_DELAY_MS;
	const maxDelay = options.maxDelayMs ?? DEFAULT_MAX_DELAY_MS;

	let lastError: unknown;
	for (let attempt = 1; attempt <= maxAttempts; attempt++) {
		if (init.signal?.aborted) {
			throw new DOMException("Aborted", "AbortError");
		}
		try {
			const response = await fetch(url, init);
			if (response.ok) return response;
			const status = response.status;
			if (!RETRY_STATUS.has(status) || attempt === maxAttempts) {
				return response;
			}
			const retryAfter = parseRetryAfter(response.headers.get("retry-after"));
			const delayMs = retryAfter ?? jitteredBackoff(attempt, baseDelay, maxDelay);
			options.onRetry?.({
				attempt,
				reason: `HTTP ${status}${response.statusText ? ` ${response.statusText}` : ""}`,
				delayMs,
			});
			// Drain the body so the underlying connection can be reused.
			try {
				await response.body?.cancel();
			} catch {
				/* ignore */
			}
			await sleep(delayMs, init.signal);
		} catch (err) {
			lastError = err;
			const { retry, reason } = classifyNetworkError(err);
			if (!retry || attempt === maxAttempts) throw err;
			const delayMs = jitteredBackoff(attempt, baseDelay, maxDelay);
			options.onRetry?.({ attempt, reason, delayMs });
			await sleep(delayMs, init.signal);
		}
	}
	throw lastError ?? new Error("retryFetch: exhausted attempts");
}
