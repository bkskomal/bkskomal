// R3-B: Ollama provider unit tests.
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { OLLAMA_DEFAULT_BASE_URL, OLLAMA_DEFAULT_MODEL, createOllamaProvider } from "../src/ollama";

function mkSseStream(lines: readonly string[]): ReadableStream<Uint8Array> {
	const encoder = new TextEncoder();
	return new ReadableStream({
		start(controller) {
			for (const line of lines) controller.enqueue(encoder.encode(`${line}\n`));
			controller.close();
		},
	});
}

describe("ollama provider (R3-B)", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("defaults to localhost:11434/v1 and the default model", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					// 2026-05-27: include a minimal content delta so the
					// provider-level empty-stream retry doesn't fire — these
					// tests are about config plumbing, not stream content.
					'data: {"choices":[{"delta":{"content":"ok"}}]}',
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);
		const provider = createOllamaProvider();
		// Empty modelId on the request should fall through to the configured default
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "",
		})) {
			// drain
		}
		expect(fetchMock).toHaveBeenCalledOnce();
		const [url, init] = fetchMock.mock.calls[0];
		expect(String(url)).toBe(`${OLLAMA_DEFAULT_BASE_URL}/chat/completions`);
		const body = JSON.parse((init as RequestInit).body as string) as { model: string };
		expect(body.model).toBe(OLLAMA_DEFAULT_MODEL);
	});

	it("does not set Authorization when no apiKey is provided", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					// 2026-05-27: include a minimal content delta so the
					// provider-level empty-stream retry doesn't fire — these
					// tests are about config plumbing, not stream content.
					'data: {"choices":[{"delta":{"content":"ok"}}]}',
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);
		const provider = createOllamaProvider({ model: "llama3.1:8b" });
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "llama3.1:8b",
		})) {
			// drain
		}
		const init = fetchMock.mock.calls[0][1] as RequestInit;
		const headers = init.headers as Record<string, string>;
		expect(headers.Authorization).toBeUndefined();
	});

	it("forwards apiKey when set (for reverse-proxied ollama setups)", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					// 2026-05-27: include a minimal content delta so the
					// provider-level empty-stream retry doesn't fire — these
					// tests are about config plumbing, not stream content.
					'data: {"choices":[{"delta":{"content":"ok"}}]}',
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);
		const provider = createOllamaProvider({ apiKey: "secret" });
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "llama3.1:8b",
		})) {
			// drain
		}
		const init = fetchMock.mock.calls[0][1] as RequestInit;
		const headers = init.headers as Record<string, string>;
		expect(headers.Authorization).toBe("Bearer secret");
	});

	it("respects a per-request modelId / temperature / maxTokens override", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					// 2026-05-27: include a minimal content delta so the
					// provider-level empty-stream retry doesn't fire — these
					// tests are about config plumbing, not stream content.
					'data: {"choices":[{"delta":{"content":"ok"}}]}',
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);
		const provider = createOllamaProvider({
			model: "llama3.1:8b",
			temperature: 0.1,
			maxTokens: 100,
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "qwen2.5-coder:7b",
			temperature: 0.7,
			maxTokens: 50,
		})) {
			// drain
		}
		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			model: string;
			temperature: number;
			max_tokens: number;
		};
		expect(body.model).toBe("qwen2.5-coder:7b");
		expect(body.temperature).toBe(0.7);
		expect(body.max_tokens).toBe(50);
	});

	it("honors a custom baseUrl override", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					// 2026-05-27: include a minimal content delta so the
					// provider-level empty-stream retry doesn't fire — these
					// tests are about config plumbing, not stream content.
					'data: {"choices":[{"delta":{"content":"ok"}}]}',
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);
		const provider = createOllamaProvider({ baseUrl: "http://my-box:9000/v1" });
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "llama3.1:8b",
		})) {
			// drain
		}
		expect(String(fetchMock.mock.calls[0][0])).toBe("http://my-box:9000/v1/chat/completions");
	});
});
