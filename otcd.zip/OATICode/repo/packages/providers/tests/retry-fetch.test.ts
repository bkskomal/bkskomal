import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { retryFetch } from "../src/retry-fetch";

const ORIGINAL_FETCH = globalThis.fetch;

function makeResponse(status: number, headers: Record<string, string> = {}): Response {
	return new Response("body", { status, headers });
}

describe("retryFetch", () => {
	beforeEach(() => {
		vi.useFakeTimers();
	});
	afterEach(() => {
		vi.useRealTimers();
		globalThis.fetch = ORIGINAL_FETCH;
	});

	it("returns the first 2xx response without retrying", async () => {
		const fetchSpy = vi.fn().mockResolvedValue(makeResponse(200));
		globalThis.fetch = fetchSpy as unknown as typeof fetch;
		const p = retryFetch("https://example.com", {});
		await vi.runAllTimersAsync();
		const res = await p;
		expect(res.status).toBe(200);
		expect(fetchSpy).toHaveBeenCalledTimes(1);
	});

	it("retries on 429 then succeeds", async () => {
		const onRetry = vi.fn();
		const fetchSpy = vi
			.fn()
			.mockResolvedValueOnce(makeResponse(429))
			.mockResolvedValueOnce(makeResponse(200));
		globalThis.fetch = fetchSpy as unknown as typeof fetch;
		const p = retryFetch("https://example.com", {}, { baseDelayMs: 10, maxDelayMs: 50, onRetry });
		await vi.runAllTimersAsync();
		const res = await p;
		expect(res.status).toBe(200);
		expect(fetchSpy).toHaveBeenCalledTimes(2);
		expect(onRetry).toHaveBeenCalledTimes(1);
		expect(onRetry.mock.calls[0][0].reason).toMatch(/429/);
	});

	it("returns the last error response after exhausting attempts", async () => {
		const fetchSpy = vi.fn().mockResolvedValue(makeResponse(503));
		globalThis.fetch = fetchSpy as unknown as typeof fetch;
		const p = retryFetch(
			"https://example.com",
			{},
			{ maxAttempts: 2, baseDelayMs: 10, maxDelayMs: 30 },
		);
		await vi.runAllTimersAsync();
		const res = await p;
		expect(res.status).toBe(503);
		expect(fetchSpy).toHaveBeenCalledTimes(2);
	});

	it("respects the Retry-After header (seconds)", async () => {
		const onRetry = vi.fn();
		const fetchSpy = vi
			.fn()
			.mockResolvedValueOnce(makeResponse(429, { "retry-after": "1" }))
			.mockResolvedValueOnce(makeResponse(200));
		globalThis.fetch = fetchSpy as unknown as typeof fetch;
		const p = retryFetch("https://example.com", {}, { onRetry });
		await vi.runAllTimersAsync();
		const res = await p;
		expect(res.status).toBe(200);
		expect(onRetry.mock.calls[0][0].delayMs).toBe(1000);
	});

	it("does NOT retry 4xx other than 408/425/429", async () => {
		const fetchSpy = vi.fn().mockResolvedValue(makeResponse(400));
		globalThis.fetch = fetchSpy as unknown as typeof fetch;
		const p = retryFetch("https://example.com", {});
		await vi.runAllTimersAsync();
		const res = await p;
		expect(res.status).toBe(400);
		expect(fetchSpy).toHaveBeenCalledTimes(1);
	});

	it("retries transient network errors and then succeeds", async () => {
		const onRetry = vi.fn();
		const fetchSpy = vi
			.fn()
			.mockRejectedValueOnce(new Error("fetch failed"))
			.mockResolvedValueOnce(makeResponse(200));
		globalThis.fetch = fetchSpy as unknown as typeof fetch;
		const p = retryFetch("https://example.com", {}, { baseDelayMs: 10, maxDelayMs: 30, onRetry });
		await vi.runAllTimersAsync();
		const res = await p;
		expect(res.status).toBe(200);
		expect(onRetry).toHaveBeenCalledTimes(1);
	});

	it("does NOT retry on AbortError", async () => {
		const controller = new AbortController();
		const fetchSpy = vi.fn(async () => {
			throw new DOMException("Aborted", "AbortError");
		});
		globalThis.fetch = fetchSpy as unknown as typeof fetch;
		controller.abort();
		await expect(retryFetch("https://example.com", { signal: controller.signal })).rejects.toThrow();
		expect(fetchSpy).toHaveBeenCalledTimes(0);
	});
});
