import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createAnthropicProvider } from "../src/anthropic";

function mkSseStream(lines: readonly string[]): ReadableStream<Uint8Array> {
	const encoder = new TextEncoder();
	return new ReadableStream({
		start(controller) {
			for (const line of lines) controller.enqueue(encoder.encode(`${line}\n`));
			controller.close();
		},
	});
}

describe("anthropic provider", () => {
	const originalFetch = global.fetch;

	beforeEach(() => {
		global.fetch = vi.fn();
	});

	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("parses a basic text response and emits message_end with stopReason 'end'", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"type":"message_start","message":{"id":"m1","model":"x","usage":{"input_tokens":10,"output_tokens":0}}}',
					"",
					'data: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}',
					"",
					'data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Hello"}}',
					"",
					'data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":" there"}}',
					"",
					'data: {"type":"content_block_stop","index":0}',
					"",
					'data: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":5}}',
					"",
					'data: {"type":"message_stop"}',
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);

		const provider = createAnthropicProvider({
			id: "a",
			displayName: "A",
			apiKey: "sk-ant-key",
		});
		const events: Array<{ type: string; [k: string]: unknown }> = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "claude-sonnet-4-6",
		})) {
			events.push(ev as { type: string });
		}

		const text = events
			.filter((e) => e.type === "text_delta")
			.map((e) => e.text as string)
			.join("");
		expect(text).toBe("Hello there");

		const usages = events.filter((e) => e.type === "usage");
		expect(usages.length).toBeGreaterThanOrEqual(1);

		const last = events[events.length - 1];
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("end");
	});

	it("assembles a tool_use block from input_json_delta partials", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"type":"message_start","message":{"id":"m2","model":"x","usage":{"input_tokens":12,"output_tokens":0}}}',
					"",
					'data: {"type":"content_block_start","index":0,"content_block":{"type":"tool_use","id":"toolu_1","name":"read_file","input":{}}}',
					"",
					'data: {"type":"content_block_delta","index":0,"delta":{"type":"input_json_delta","partial_json":"{\\"pa"}}',
					"",
					'data: {"type":"content_block_delta","index":0,"delta":{"type":"input_json_delta","partial_json":"th\\":\\"src/index.ts\\"}"}}',
					"",
					'data: {"type":"content_block_stop","index":0}',
					"",
					'data: {"type":"message_delta","delta":{"stop_reason":"tool_use"},"usage":{"output_tokens":18}}',
					"",
					'data: {"type":"message_stop"}',
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);

		const provider = createAnthropicProvider({ id: "a", displayName: "A", apiKey: "k" });
		const events: Array<{ type: string; [k: string]: unknown }> = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "read it" }] }],
			modelId: "claude-sonnet-4-6",
		})) {
			events.push(ev as { type: string });
		}

		const toolCall = events.find((e) => e.type === "tool_call");
		expect(toolCall).toBeDefined();
		expect(toolCall?.id).toBe("toolu_1");
		expect(toolCall?.name).toBe("read_file");
		expect(toolCall?.args).toEqual({ path: "src/index.ts" });

		const last = events[events.length - 1];
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("tool_use");
	});

	it("sends the x-api-key header and anthropic-version, not Authorization", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(mkSseStream(['data: {"type":"message_stop"}']), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);

		const provider = createAnthropicProvider({
			id: "a",
			displayName: "A",
			apiKey: "sk-ant-secret",
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "claude-sonnet-4-6",
		})) {
			// drain
		}

		expect(fetchMock).toHaveBeenCalledOnce();
		const init = fetchMock.mock.calls[0][1] as RequestInit;
		const headers = init.headers as Record<string, string>;
		expect(headers["x-api-key"]).toBe("sk-ant-secret");
		expect(headers["anthropic-version"]).toBe("2023-06-01");
		expect(headers.Authorization).toBeUndefined();
	});

	it("hits /v1/messages on the configured base URL", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(mkSseStream(['data: {"type":"message_stop"}']), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);

		const provider = createAnthropicProvider({
			id: "a",
			displayName: "A",
			apiKey: "k",
			baseUrl: "https://proxy.example/anthropic/v1",
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "claude-sonnet-4-6",
		})) {
			// drain
		}

		expect(fetchMock.mock.calls[0][0]).toBe("https://proxy.example/anthropic/v1/messages");
	});

	it("maps assistant tool_call back to a tool_use block when sending history", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(mkSseStream(['data: {"type":"message_stop"}']), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);

		const provider = createAnthropicProvider({ id: "a", displayName: "A", apiKey: "k" });
		for await (const _ev of provider.stream({
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "do it" }] },
				{
					role: "assistant",
					parts: [
						{ kind: "text", text: "calling tool" },
						{
							kind: "tool_call",
							id: "tc_1",
							name: "read_file",
							args: { path: "x.ts" },
						},
					],
				},
				{
					role: "tool",
					parts: [{ kind: "tool_result", id: "tc_1", output: "contents", isError: false }],
				},
			],
			modelId: "claude-sonnet-4-6",
		})) {
			// drain
		}

		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			messages: Array<{ role: string; content: unknown }>;
		};
		// The assistant turn should include a tool_use block; the tool result becomes a user role
		// with a tool_result block (Anthropic's convention).
		const assistantTurn = body.messages.find((m) => m.role === "assistant");
		expect(assistantTurn).toBeDefined();
		const assistantContent = assistantTurn?.content as Array<{ type: string }>;
		expect(assistantContent.some((b) => b.type === "tool_use")).toBe(true);

		const userTurns = body.messages.filter((m) => m.role === "user");
		const hasToolResultUser = userTurns.some((m) => {
			const c = m.content;
			return Array.isArray(c) && c.some((b: { type: string }) => b.type === "tool_result");
		});
		expect(hasToolResultUser).toBe(true);
	});

	// ---------------------------------------------------------------
	// Phase B carry-over: when an open-weight model (Kimi, Qwen, etc.)
	// is routed through Anthropic's gateway, suppress the structured
	// `tools` array and inject the inline-XML format addendum into the
	// system prompt. Claude's own family keeps the native envelope.
	// ---------------------------------------------------------------
	it("inline-xml branch: suppresses wire tools array and injects XML prompt for Kimi-class models", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(mkSseStream(['data: {"type":"message_stop"}']), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);

		const provider = createAnthropicProvider({ id: "a", displayName: "A", apiKey: "k" });
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "list files" }] }],
			modelId: "qwen-3-coder",
			systemPrompt: "You are a helpful assistant.",
			tools: [
				{
					name: "read_file",
					description: "read a file",
					schema: { type: "object", properties: { path: { type: "string" } } },
					approval: "auto",
					handler: async () => "",
				},
			],
		})) {
			// drain
		}

		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			tools?: unknown;
			system?: string;
		};
		// Inline-XML path must NOT send a wire-level tools array — the
		// model can't reliably emit Anthropic's structured tool envelope.
		expect(body.tools).toBeUndefined();
		// Instead, the XML format addendum lives in the system prompt.
		expect(body.system).toContain("You are a helpful assistant.");
		expect(body.system).toMatch(/<read_file>/);
	});

	it("inline-xml branch: frontier Claude STILL uses the native Anthropic tools envelope", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(mkSseStream(['data: {"type":"message_stop"}']), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);

		const provider = createAnthropicProvider({ id: "a", displayName: "A", apiKey: "k" });
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "list files" }] }],
			modelId: "claude-sonnet-4-6",
			systemPrompt: "You are a helpful assistant.",
			tools: [
				{
					name: "read_file",
					description: "read a file",
					schema: { type: "object", properties: { path: { type: "string" } } },
					approval: "auto",
					handler: async () => "",
				},
			],
		})) {
			// drain
		}

		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			tools?: Array<{ name: string }>;
			system?: string;
		};
		// Claude gets the structured envelope — no XML addendum.
		expect(Array.isArray(body.tools)).toBe(true);
		expect(body.tools?.[0]?.name).toBe("read_file");
		expect(body.system).toBe("You are a helpful assistant.");
		expect(body.system).not.toMatch(/<read_file>/);
	});

	it("inline-xml branch: parses tool calls from streamed text deltas for open-weight models", async () => {
		// Anthropic's stream delivers the XML inside text_delta events, since
		// for inline-xml models we suppress the structured tool_use channel.
		// The provider must feed those deltas through InlineXmlToolParser and
		// emit a `tool_call` ProviderStreamEvent when a complete `<tool>` block
		// arrives — same shape downstream sees from the native envelope.
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"type":"message_start","message":{"id":"m","model":"x","usage":{"input_tokens":5,"output_tokens":0}}}',
					"",
					'data: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}',
					"",
					'data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Let me read it. "}}',
					"",
					'data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"<read_file><path>foo.ts</path></read_file>"}}',
					"",
					'data: {"type":"content_block_stop","index":0}',
					"",
					'data: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":12}}',
					"",
					'data: {"type":"message_stop"}',
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);

		const provider = createAnthropicProvider({ id: "a", displayName: "A", apiKey: "k" });
		const events: Array<{ type: string; [k: string]: unknown }> = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "read foo" }] }],
			modelId: "qwen-3-coder",
			tools: [
				{
					name: "read_file",
					description: "read a file",
					schema: { type: "object", properties: { path: { type: "string" } } },
					approval: "auto",
					handler: async () => "",
				},
			],
		})) {
			events.push(ev as { type: string });
		}

		// "Let me read it. " streams through as text; the <read_file> block
		// becomes a tool_call. The markup itself must NOT appear in text_delta
		// output — the parser strips it.
		const text = events
			.filter((e) => e.type === "text_delta")
			.map((e) => e.text as string)
			.join("");
		expect(text).toMatch(/Let me read it/);
		expect(text).not.toMatch(/<read_file>/);

		const toolCall = events.find((e) => e.type === "tool_call");
		expect(toolCall).toBeDefined();
		expect(toolCall?.name).toBe("read_file");
		expect(toolCall?.args).toEqual({ path: "foo.ts" });

		// Inline-XML tool calls flip the stopReason to "tool_use" so the
		// agent loop knows to execute and re-prompt, not declare done.
		const last = events[events.length - 1];
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("tool_use");
	});

	it("maps user image parts to Anthropic base64 image blocks", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(mkSseStream(['data: {"type":"message_stop"}']), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);

		const provider = createAnthropicProvider({ id: "a", displayName: "A", apiKey: "k" });
		for await (const _ev of provider.stream({
			messages: [
				{
					role: "user",
					parts: [
						{ kind: "text", text: "what's this?" },
						{
							kind: "image",
							mimeType: "image/png",
							dataUrl: "data:image/png;base64,AAAA",
						},
					],
				},
			],
			modelId: "claude-sonnet-4-6",
		})) {
			// drain
		}

		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			messages: Array<{ role: string; content: unknown }>;
		};
		const userTurn = body.messages.find((m) => m.role === "user");
		expect(Array.isArray(userTurn?.content)).toBe(true);
		const blocks = userTurn?.content as Array<{
			type: string;
			source?: { type: string; media_type: string; data: string };
		}>;
		const image = blocks.find((b) => b.type === "image");
		expect(image).toBeDefined();
		expect(image?.source?.type).toBe("base64");
		expect(image?.source?.media_type).toBe("image/png");
		expect(image?.source?.data).toBe("AAAA");
	});
});
