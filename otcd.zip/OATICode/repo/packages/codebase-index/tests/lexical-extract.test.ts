import { describe, expect, it } from "vitest";
import { buildLexicalRegex, extractLexicalPatterns } from "../src/lexical-extract";

describe("extractLexicalPatterns", () => {
	it("returns [] for pure English queries", () => {
		expect(extractLexicalPatterns("where is authentication validated")).toEqual([]);
		expect(extractLexicalPatterns("find code that handles billing")).toEqual([]);
		expect(extractLexicalPatterns("how does the agent work")).toEqual([]);
	});

	it("returns [] for empty / whitespace / non-string inputs", () => {
		expect(extractLexicalPatterns("")).toEqual([]);
		expect(extractLexicalPatterns("   ")).toEqual([]);
		// @ts-expect-error: defensive against accidental misuse
		expect(extractLexicalPatterns(undefined)).toEqual([]);
		// @ts-expect-error: defensive against accidental misuse
		expect(extractLexicalPatterns(null)).toEqual([]);
	});

	it("extracts camelCase identifiers", () => {
		expect(extractLexicalPatterns("find calls to authenticateUser please")).toEqual([
			"authenticateUser",
		]);
		expect(extractLexicalPatterns("look at getUserById and setUserAge")).toEqual([
			"getUserById",
			"setUserAge",
		]);
	});

	it("extracts PascalCase identifiers", () => {
		expect(extractLexicalPatterns("where is MyClass defined")).toEqual(["MyClass"]);
	});

	it("extracts snake_case identifiers", () => {
		expect(extractLexicalPatterns("when does run_tests fire")).toEqual(["run_tests"]);
		expect(extractLexicalPatterns("looking at file_path_resolver")).toEqual(["file_path_resolver"]);
	});

	it("extracts SCREAMING_SNAKE_CASE constants", () => {
		expect(extractLexicalPatterns("what does MAX_RETRIES default to")).toEqual(["MAX_RETRIES"]);
	});

	it("extracts quoted strings (single and double)", () => {
		expect(extractLexicalPatterns('where is "deprecated" used')).toEqual(["deprecated"]);
		expect(extractLexicalPatterns("look for 'feature_flag' references")).toEqual(["feature_flag"]);
	});

	it("filters out common keywords even when capitalized", () => {
		// `If` or `For` look PascalCase-adjacent — make sure they don't slip in.
		expect(extractLexicalPatterns("If you find for loops")).toEqual([]);
		expect(extractLexicalPatterns("the function class return statement")).toEqual([]);
	});

	it("dedupes case-insensitively", () => {
		// Same token in two cases — keep the first.
		const got = extractLexicalPatterns("authenticateUser and AuthenticateUser");
		expect(got).toEqual(["authenticateUser"]);
	});

	it("filters tokens shorter than 3 chars or longer than 80", () => {
		// Single short letters and 2-char tokens never make it through.
		expect(extractLexicalPatterns("a b c d e")).toEqual([]);
		// A token longer than 80 chars is dropped (almost always garbage).
		const long = `${"a".repeat(50)}_${"b".repeat(50)}`;
		expect(extractLexicalPatterns(long)).toEqual([]);
		// 3-char snake_case tokens ARE kept — they're rare but valid.
		expect(extractLexicalPatterns("look at d_e")).toEqual(["d_e"]);
	});

	it("preserves first-seen order across multiple patterns", () => {
		const got = extractLexicalPatterns(
			"the MAX_RETRIES default is used by retryHandler in retry_state",
		);
		expect(got).toEqual(["MAX_RETRIES", "retryHandler", "retry_state"]);
	});

	it("mixes quoted strings and identifiers cleanly", () => {
		const got = extractLexicalPatterns('search for "TODO" and todoHandler');
		expect(got).toContain("TODO");
		expect(got).toContain("todoHandler");
	});
});

describe("buildLexicalRegex", () => {
	it("returns undefined for empty input (skip signal)", () => {
		expect(buildLexicalRegex([])).toBeUndefined();
	});

	it("returns a single bare token when only one pattern", () => {
		expect(buildLexicalRegex(["authenticateUser"])).toBe("authenticateUser");
	});

	it("ORs multiple patterns with parentheses", () => {
		expect(buildLexicalRegex(["foo", "bar"])).toBe("(foo|bar)");
		expect(buildLexicalRegex(["a", "b", "c"])).toBe("(a|b|c)");
	});

	it("escapes regex meta-characters in tokens", () => {
		// `foo.bar` should match literally, not as "foo[anything]bar"
		expect(buildLexicalRegex(["foo.bar"])).toBe("foo\\.bar");
		expect(buildLexicalRegex(["a+b"])).toBe("a\\+b");
		expect(buildLexicalRegex(["fn()"])).toBe("fn\\(\\)");
	});
});
