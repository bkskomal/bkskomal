import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { CodebaseIndex, TfIdfEmbedder } from "../src";
import { TagEmbedder, makeTempWorkspace, write } from "./helpers";

describe("CodebaseIndex", () => {
	let ws: { root: string; cleanup: () => void };

	beforeEach(() => {
		ws = makeTempWorkspace();
	});

	afterEach(() => ws.cleanup());

	it("indexes a tiny workspace and finds the expected file by tag", async () => {
		// Three files, each tagged with a distinct topic via the test embedder.
		write(ws.root, "src/auth.ts", "// authentication module __TAG_1__\nexport function login() {}\n");
		write(ws.root, "src/billing.ts", "// billing module __TAG_2__\nexport function charge() {}\n");
		write(ws.root, "src/render.ts", "// rendering module __TAG_3__\nexport function render() {}\n");
		const embedder = new TagEmbedder();
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder,
		});
		const result = await idx.indexAll();
		expect(result.indexed).toBeGreaterThan(0);
		const stats = idx.stats();
		expect(stats.files).toBe(3);

		const hits = await idx.query("looking for __TAG_1__ logic", { k: 3 });
		expect(hits[0].filePath).toBe("src/auth.ts");
		idx.close();
	});

	it("query returns empty for empty input", async () => {
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		expect(await idx.query("")).toEqual([]);
		expect(await idx.query("   ")).toEqual([]);
		idx.close();
	});

	it("filters results by extension", async () => {
		write(ws.root, "a.ts", "// auth __TAG_1__\n");
		write(ws.root, "b.py", "# auth __TAG_1__\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		const tsOnly = await idx.query("about __TAG_1__", { filter: { extensions: ["ts"] }, k: 5 });
		expect(tsOnly.length).toBeGreaterThan(0);
		for (const h of tsOnly) expect(h.filePath.endsWith(".ts")).toBe(true);
		idx.close();
	});

	it("incremental reindex skips unchanged files", async () => {
		write(ws.root, "src/a.ts", "// __TAG_1__\nexport function f() { return 1; }\n");
		const embedder = new TagEmbedder();
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder,
		});
		const first = await idx.indexAll();
		expect(first.indexed).toBeGreaterThan(0);
		const callsAfterFirst = embedder.calls;

		// Second pass with no file changes — content_hash should make every chunk a no-op.
		const second = await idx.indexAll();
		expect(second.indexed).toBe(0);
		expect(embedder.calls).toBe(callsAfterFirst);
		idx.close();
	});

	it("re-embeds only changed chunks on incremental reindex", async () => {
		// Two chunks. We change exactly one.
		write(
			ws.root,
			"src/a.ts",
			[
				"export function alpha() {",
				"  return '__TAG_1__';",
				"}",
				"",
				"export function beta() {",
				"  return '__TAG_2__';",
				"}",
			].join("\n"),
		);
		const embedder = new TagEmbedder();
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder,
		});
		await idx.indexAll();
		const callsBefore = embedder.calls;

		// Modify just `beta` to a new tag.
		write(
			ws.root,
			"src/a.ts",
			[
				"export function alpha() {",
				"  return '__TAG_1__';",
				"}",
				"",
				"export function beta() {",
				"  return '__TAG_9__';",
				"}",
			].join("\n"),
		);
		await idx.indexAll();
		// We expect at most ONE additional embedding call (for beta). Because the
		// chunker can produce slightly different line counts, this is a conservative
		// upper bound rather than exact equality.
		expect(embedder.calls - callsBefore).toBeLessThanOrEqual(2);
		expect(embedder.calls).toBeGreaterThan(callsBefore);

		const hits = await idx.query("looking for __TAG_9__", { k: 1 });
		expect(hits[0].content).toContain("__TAG_9__");
		idx.close();
	});

	it("invalidate drops a file's chunks", async () => {
		write(ws.root, "a.ts", "// __TAG_1__\nexport const a = 1;\n");
		write(ws.root, "b.ts", "// __TAG_2__\nexport const b = 2;\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		expect(idx.stats().files).toBe(2);
		await idx.invalidate(path.join(ws.root, "a.ts"));
		expect(idx.stats().files).toBe(1);
		const hits = await idx.query("looking for __TAG_1__", { k: 3 });
		// a.ts is gone; b.ts shouldn't dominate the __TAG_1__ query but the index
		// is non-empty so we should still get *some* result that isn't a.ts.
		for (const h of hits) expect(h.filePath).not.toBe("a.ts");
		idx.close();
	});

	it("indexFile updates a single file without a full walk", async () => {
		write(ws.root, "a.ts", "// __TAG_1__\nexport const a = 1;\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		// Modify and call indexFile directly.
		write(ws.root, "a.ts", "// __TAG_7__\nexport const a = 7;\n");
		await idx.indexFile(path.join(ws.root, "a.ts"));
		const hits = await idx.query("looking for __TAG_7__", { k: 1 });
		expect(hits[0].filePath).toBe("a.ts");
		idx.close();
	});

	it("emits progress events during indexAll", async () => {
		for (let i = 0; i < 5; i++) {
			write(ws.root, `src/f${i}.ts`, `// content __TAG_${i}__\n`);
		}
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		const events: { done: number; total: number; file?: string }[] = [];
		await idx.indexAll({ onProgress: (p) => events.push(p) });
		// At least one event per file plus a final "done == total" event.
		expect(events.length).toBeGreaterThanOrEqual(5);
		const last = events[events.length - 1];
		expect(last.done).toBe(last.total);
		idx.close();
	});

	it("prunes chunks for files deleted between runs", async () => {
		const fileA = write(ws.root, "a.ts", "// __TAG_1__\nexport const a = 1;\n");
		write(ws.root, "b.ts", "// __TAG_2__\nexport const b = 2;\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		expect(idx.stats().files).toBe(2);
		// Physically delete a.ts, then reindex.
		const fs = await import("node:fs");
		fs.unlinkSync(fileA);
		await idx.indexAll();
		expect(idx.stats().files).toBe(1);
		idx.close();
	});

	it("ranks correctly with the TF-IDF fallback", async () => {
		write(
			ws.root,
			"src/auth.ts",
			"export function authenticateUser(name: string, password: string) { return verifyPassword(name, password); }",
		);
		write(
			ws.root,
			"src/render.ts",
			"export function renderHtmlTemplate(tpl: string, ctx: object) { return tpl.replace(/{.*}/g, ''); }",
		);
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TfIdfEmbedder(),
		});
		await idx.indexAll();
		const hits = await idx.query("authenticate users with a password", { k: 2 });
		expect(hits[0].filePath).toBe("src/auth.ts");
		idx.close();
	});

	// Phase 1.1: hybrid retrieval via Reciprocal Rank Fusion.
	describe("hybrid retrieval (lexical + semantic via RRF)", () => {
		it("boosts a file that appears in both semantic and lexical rankings", async () => {
			// Three files: auth has the semantic tag, billing has the literal
			// string the lexical query will hit AND the same semantic tag.
			// With hybrid enabled, a file that appears in BOTH rankings
			// should outrank one that only appears in semantic.
			write(ws.root, "src/auth.ts", "// __TAG_1__\nexport function login() {}\n");
			write(
				ws.root,
				"src/billing.ts",
				"// __TAG_1__\nexport function chargeCard() { /* TODO_LITERAL_MATCH */ }\n",
			);
			write(ws.root, "src/render.ts", "// __TAG_3__\nexport function render() {}\n");
			const idx = new CodebaseIndex({
				workspaceRoot: ws.root,
				dbPath: ":memory:",
				embedder: new TagEmbedder(),
			});
			await idx.indexAll();

			// Lexical hits ONLY billing.ts (the literal string lives there).
			// Hybrid should now elevate billing above auth.
			const lexicalQuery = async () => [
				{
					filePath: "src/billing.ts",
					startLine: 2,
					endLine: 2,
					content: "TODO_LITERAL_MATCH",
					score: 1.0,
				},
			];
			const hybrid = await idx.query("__TAG_1__ logic", { k: 3, lexicalQuery });
			expect(hybrid[0].filePath).toBe("src/billing.ts");

			idx.close();
		});

		it("degrades to pure semantic when the lexical callback throws", async () => {
			write(ws.root, "src/x.ts", "// __TAG_1__\nexport const x = 1;\n");
			const idx = new CodebaseIndex({
				workspaceRoot: ws.root,
				dbPath: ":memory:",
				embedder: new TagEmbedder(),
			});
			await idx.indexAll();
			const lexicalQuery = async () => {
				throw new Error("ripgrep blew up");
			};
			// Did NOT throw, and still found the semantic hit.
			const hits = await idx.query("__TAG_1__", { k: 3, lexicalQuery });
			expect(hits[0].filePath).toBe("src/x.ts");
			idx.close();
		});

		it("returns semantic results when the lexical callback yields no matches", async () => {
			write(ws.root, "src/x.ts", "// __TAG_1__\nexport const x = 1;\n");
			const idx = new CodebaseIndex({
				workspaceRoot: ws.root,
				dbPath: ":memory:",
				embedder: new TagEmbedder(),
			});
			await idx.indexAll();
			const hits = await idx.query("__TAG_1__", {
				k: 3,
				lexicalQuery: async () => [],
			});
			expect(hits[0].filePath).toBe("src/x.ts");
			idx.close();
		});
	});
});
