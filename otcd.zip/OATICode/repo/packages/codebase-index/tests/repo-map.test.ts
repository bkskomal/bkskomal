import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { buildRepoMap } from "../src/repo-map";
import { makeTempWorkspace, write } from "./helpers";

describe("buildRepoMap (Aider-style top-level orientation)", () => {
	let ws: { root: string; cleanup: () => void };
	beforeEach(() => {
		ws = makeTempWorkspace();
	});
	afterEach(() => ws.cleanup());

	it("renders symbols from multiple files in a compressed text block", () => {
		write(ws.root, "src/cart.ts", "export class Cart {}\nexport function compute() {}\n");
		write(ws.root, "src/api.py", "def get_cart():\n    pass\nclass CartService:\n    pass\n");
		const result = buildRepoMap(ws.root);
		expect(result.text).toContain("## Repo Map");
		expect(result.text).toContain("src/cart.ts");
		expect(result.text).toContain("Cart");
		expect(result.text).toContain("compute");
		expect(result.text).toContain("src/api.py");
		expect(result.text).toContain("get_cart");
		expect(result.text).toContain("CartService");
		expect(result.filesShown).toBe(2);
		expect(result.filesSkipped).toBe(0);
	});

	it("respects the token budget — skips files when the budget would be exceeded", () => {
		// 50 files × ~80 chars each ≈ 4000 chars. With a 200-char budget we
		// should fit only a couple and report the rest as skipped.
		for (let i = 0; i < 50; i++) {
			write(ws.root, `src/f${i}.ts`, `export function fn${i}() {}\n`);
		}
		const result = buildRepoMap(ws.root, { tokenBudget: 50 });
		expect(result.filesShown).toBeGreaterThan(0);
		expect(result.filesShown).toBeLessThan(50);
		expect(result.filesSkipped).toBeGreaterThan(0);
		expect(result.text).toMatch(/truncated/i);
	});

	it("ignores files with no extractable symbols (no noise lines)", () => {
		write(ws.root, "src/empty.ts", "// just a comment\n");
		write(ws.root, "src/real.ts", "export function ok() {}\n");
		const result = buildRepoMap(ws.root);
		// real.ts shows; empty.ts is silently dropped.
		expect(result.text).toContain("src/real.ts");
		expect(result.text).not.toContain("src/empty.ts");
	});

	it("emits a heading entry for Markdown files (READMEs are valuable repo-map content)", () => {
		write(ws.root, "README.md", "# My Project\n\nIntro paragraph.\n");
		write(ws.root, "src/code.ts", "export const X = 1;\n");
		const result = buildRepoMap(ws.root);
		expect(result.text).toContain("README.md");
		expect(result.text).toContain("My Project");
	});

	it("caps per-file symbol count and surfaces an overflow note", () => {
		const lines: string[] = [];
		for (let i = 0; i < 80; i++) lines.push(`export function fn${i}() {}`);
		write(ws.root, "src/big.ts", `${lines.join("\n")}\n`);
		const result = buildRepoMap(ws.root, { symbolsPerFile: 10 });
		expect(result.text).toContain("fn0");
		expect(result.text).toContain("fn9"); // last one shown
		expect(result.text).not.toContain("fn79");
		expect(result.text).toMatch(/more symbols not shown/);
	});

	it("returns a usable result on an empty workspace (no symbols anywhere)", () => {
		write(ws.root, "data.json", '{ "x": 1 }');
		write(ws.root, "image.bin", "binary garbage");
		const result = buildRepoMap(ws.root);
		expect(result.text).toContain("## Repo Map");
		expect(result.filesShown).toBe(0);
	});
});
