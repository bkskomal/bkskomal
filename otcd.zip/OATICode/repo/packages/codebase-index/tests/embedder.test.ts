import { describe, expect, it } from "vitest";
import {
	OpenAICompatEmbedder,
	TF_IDF_DIM,
	TfIdfEmbedder,
	cosineSimilarity,
	l2Normalize,
	tokenize,
} from "../src/embedder";

describe("tokenize", () => {
	it("splits on word boundaries", () => {
		const tokens = tokenize("foo bar-baz_qux");
		expect(tokens).toEqual(expect.arrayContaining(["foo", "bar", "baz", "qux"]));
	});

	it("emits subtokens for camelCase identifiers", () => {
		const tokens = tokenize("parseHttpRequest");
		// camelCase split should produce 'parse', 'http', 'request'.
		expect(tokens).toEqual(expect.arrayContaining(["parse", "http", "request"]));
	});

	it("emits subtokens for snake_case", () => {
		const tokens = tokenize("user_id_lookup");
		expect(tokens).toEqual(expect.arrayContaining(["user", "id", "lookup"]));
	});
});

describe("l2Normalize", () => {
	it("scales to unit length", () => {
		const v = new Float32Array([3, 4, 0]);
		l2Normalize(v);
		expect(v[0]).toBeCloseTo(0.6, 5);
		expect(v[1]).toBeCloseTo(0.8, 5);
		expect(v[2]).toBe(0);
	});

	it("leaves a zero vector alone", () => {
		const v = new Float32Array([0, 0, 0]);
		l2Normalize(v);
		expect(v[0]).toBe(0);
	});
});

describe("cosineSimilarity", () => {
	it("returns 1 for identical normalized vectors", () => {
		const v = l2Normalize(new Float32Array([1, 2, 3]));
		expect(cosineSimilarity(v, v)).toBeCloseTo(1, 5);
	});

	it("returns ~0 for orthogonal vectors", () => {
		const a = l2Normalize(new Float32Array([1, 0]));
		const b = l2Normalize(new Float32Array([0, 1]));
		expect(cosineSimilarity(a, b)).toBeCloseTo(0, 5);
	});

	it("returns 0 for mismatched dimensions", () => {
		expect(cosineSimilarity(new Float32Array([1]), new Float32Array([1, 0]))).toBe(0);
	});
});

describe("TfIdfEmbedder", () => {
	it("produces 256-dim vectors by default", async () => {
		const e = new TfIdfEmbedder();
		expect(e.dim).toBe(TF_IDF_DIM);
		const [v] = await e.embed(["hello world"]);
		expect(v.length).toBe(TF_IDF_DIM);
	});

	it("is deterministic across runs", async () => {
		const a = new TfIdfEmbedder();
		const b = new TfIdfEmbedder();
		const [va] = await a.embed(["function parseRequest(req) { return req; }"]);
		const [vb] = await b.embed(["function parseRequest(req) { return req; }"]);
		for (let i = 0; i < va.length; i++) {
			expect(vb[i]).toBe(va[i]);
		}
	});

	it("ranks the matching document above unrelated ones", async () => {
		const e = new TfIdfEmbedder();
		const docs = [
			"def authenticate_user(name, password): return verify_password(name, password)",
			"def render_html_template(template, context): return template.format(**context)",
			"def calculate_quarterly_revenue(transactions): return sum(t.amount for t in transactions)",
		];
		const [a, b, c] = await e.embed(docs);
		const [q] = await e.embed(["how do we authenticate users with passwords"]);
		const scores = [cosineSimilarity(q, a), cosineSimilarity(q, b), cosineSimilarity(q, c)];
		// `authenticate_user` doc shares "authenticate", "user", "password" with the query.
		expect(scores[0]).toBeGreaterThan(scores[1]);
		expect(scores[0]).toBeGreaterThan(scores[2]);
	});

	it("returns vectors of the requested dimension", async () => {
		const e = new TfIdfEmbedder(64);
		const [v] = await e.embed(["test"]);
		expect(v.length).toBe(64);
	});
});

describe("OpenAICompatEmbedder", () => {
	it("posts to {baseUrl}/embeddings and parses the response", async () => {
		const seen: { url: string; body: string }[] = [];
		const fakeFetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
			const url = typeof input === "string" ? input : input.toString();
			seen.push({ url, body: (init?.body as string) ?? "" });
			return new Response(
				JSON.stringify({
					data: [{ embedding: [0.6, 0.8] }, { embedding: [1, 0] }],
				}),
				{ status: 200, headers: { "content-type": "application/json" } },
			);
		}) as unknown as typeof fetch;
		const e = new OpenAICompatEmbedder({
			baseUrl: "https://api.example.com/v1/",
			apiKey: "sk-test",
			model: "test-embed",
			dimensions: 2,
			fetchImpl: fakeFetch,
		});
		const vecs = await e.embed(["hello", "world"]);
		expect(seen[0].url).toBe("https://api.example.com/v1/embeddings");
		expect(seen[0].body).toContain('"model":"test-embed"');
		expect(vecs).toHaveLength(2);
		// First vector was [0.6, 0.8] → already unit-length → unchanged.
		expect(vecs[0][0]).toBeCloseTo(0.6, 5);
		expect(vecs[0][1]).toBeCloseTo(0.8, 5);
	});

	it("throws when the response shape is wrong", async () => {
		const fakeFetch = (async () =>
			new Response(JSON.stringify({ data: [] }), { status: 200 })) as unknown as typeof fetch;
		const e = new OpenAICompatEmbedder({
			baseUrl: "https://api.example.com/v1",
			apiKey: "sk-test",
			model: "test-embed",
			dimensions: 2,
			fetchImpl: fakeFetch,
		});
		await expect(e.embed(["hello"])).rejects.toThrow(/expected 1 vectors/);
	});

	it("throws on non-2xx responses with status detail", async () => {
		const fakeFetch = (async () =>
			new Response("internal error", { status: 500 })) as unknown as typeof fetch;
		const e = new OpenAICompatEmbedder({
			baseUrl: "https://api.example.com/v1",
			apiKey: "sk-test",
			model: "test-embed",
			dimensions: 2,
			fetchImpl: fakeFetch,
		});
		await expect(e.embed(["hello"])).rejects.toThrow(/embeddings request failed \(500\)/);
	});
});
