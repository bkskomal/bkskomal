import { describe, expect, it } from "vitest";
import { extractSymbols, languageForExtension } from "../src/symbol-extract";

describe("symbol-extract — TypeScript / JavaScript", () => {
	it("captures exported functions with their line numbers", () => {
		const code = [
			"// header",
			"",
			"export function add(a: number, b: number) {",
			"  return a + b;",
			"}",
			"",
			"function privateHelper() {}",
		].join("\n");
		const syms = extractSymbols(code, "typescript");
		const add = syms.find((s) => s.name === "add");
		expect(add).toBeDefined();
		expect(add?.kind).toBe("function");
		expect(add?.exported).toBe(true);
		expect(add?.line).toBe(3);
		const priv = syms.find((s) => s.name === "privateHelper");
		expect(priv?.exported).toBe(false);
	});

	it("captures classes, interfaces, types, enums", () => {
		const code = [
			"export class Cart {}",
			"export interface CartItem { id: string }",
			"export type CartId = string;",
			"export enum CartStatus { Active, Empty }",
		].join("\n");
		const syms = extractSymbols(code, "typescript");
		expect(syms.find((s) => s.kind === "class" && s.name === "Cart")).toBeDefined();
		expect(syms.find((s) => s.kind === "interface" && s.name === "CartItem")).toBeDefined();
		expect(syms.find((s) => s.kind === "type" && s.name === "CartId")).toBeDefined();
		expect(syms.find((s) => s.kind === "enum" && s.name === "CartStatus")).toBeDefined();
	});

	it("captures async functions and arrow-const declarations", () => {
		const code = ["export async function load() {}", "export const handler = async () => {}"].join(
			"\n",
		);
		const syms = extractSymbols(code, "typescript");
		expect(syms.find((s) => s.name === "load")).toBeDefined();
		expect(syms.find((s) => s.name === "handler")).toBeDefined();
	});
});

describe("symbol-extract — Python", () => {
	it("captures def and class declarations with private heuristic", () => {
		const code = [
			"def public_fn():\n    pass",
			"def _private_fn():\n    pass",
			"class Foo:\n    pass",
		].join("\n");
		const syms = extractSymbols(code, "python");
		expect(syms.find((s) => s.name === "public_fn")?.exported).toBe(true);
		expect(syms.find((s) => s.name === "_private_fn")?.exported).toBe(false);
		expect(syms.find((s) => s.kind === "class" && s.name === "Foo")).toBeDefined();
	});
});

describe("symbol-extract — C#", () => {
	it("captures classes and methods", () => {
		const code = [
			"public class CartService {",
			"  public async Task<int> Compute(int a) { return a + 1; }",
			"  private void Helper() {}",
			"}",
		].join("\n");
		const syms = extractSymbols(code, "csharp");
		expect(syms.find((s) => s.kind === "class" && s.name === "CartService")).toBeDefined();
		expect(syms.find((s) => s.name === "Compute")).toBeDefined();
	});

	it("ignores control-flow keywords masquerading as method names", () => {
		const code = ["public class Foo {", "  public void M() { if (x) { return; } }", "}"].join("\n");
		const syms = extractSymbols(code, "csharp");
		expect(syms.find((s) => s.name === "if")).toBeUndefined();
		expect(syms.find((s) => s.name === "return")).toBeUndefined();
	});
});

describe("symbol-extract — Go", () => {
	it("captures top-level funcs and types, marks PascalCase as exported", () => {
		const code = [
			"package main",
			"",
			"func Run() {}",
			"func helper() {}",
			"type Cart struct { id string }",
			"type internal struct { x int }",
		].join("\n");
		const syms = extractSymbols(code, "go");
		expect(syms.find((s) => s.name === "Run")?.exported).toBe(true);
		expect(syms.find((s) => s.name === "helper")?.exported).toBe(false);
		expect(syms.find((s) => s.kind === "class" && s.name === "Cart")?.exported).toBe(true);
	});
});

describe("symbol-extract — Rust", () => {
	it("captures pub fn, struct, enum, trait", () => {
		const code = [
			"pub fn run() {}",
			"fn helper() {}",
			"pub struct Cart {}",
			"pub enum Status { Ok, Err }",
			"pub trait Storage {}",
		].join("\n");
		const syms = extractSymbols(code, "rust");
		expect(syms.find((s) => s.name === "run")?.exported).toBe(true);
		expect(syms.find((s) => s.name === "helper")?.exported).toBe(false);
		expect(syms.find((s) => s.kind === "class" && s.name === "Cart")).toBeDefined();
		expect(syms.find((s) => s.kind === "enum" && s.name === "Status")).toBeDefined();
		expect(syms.find((s) => s.kind === "interface" && s.name === "Storage")).toBeDefined();
	});
});

describe("symbol-extract — Markdown", () => {
	it("captures only the first H1 as a heading symbol", () => {
		const code = ["# Main Title", "## Subhead", "# Second H1 (ignored)"].join("\n");
		const syms = extractSymbols(code, "markdown");
		expect(syms).toHaveLength(1);
		expect(syms[0].kind).toBe("heading");
		expect(syms[0].name).toBe("Main Title");
	});
});

describe("languageForExtension", () => {
	it("maps common extensions correctly", () => {
		expect(languageForExtension(".ts")).toBe("typescript");
		expect(languageForExtension("tsx")).toBe("tsx");
		expect(languageForExtension(".py")).toBe("python");
		expect(languageForExtension(".cs")).toBe("csharp");
		expect(languageForExtension(".rs")).toBe("rust");
		expect(languageForExtension(".go")).toBe("go");
		expect(languageForExtension(".md")).toBe("markdown");
	});

	it("returns undefined for unknown / binary extensions", () => {
		expect(languageForExtension(".png")).toBeUndefined();
		expect(languageForExtension(".bin")).toBeUndefined();
		expect(languageForExtension("")).toBeUndefined();
	});
});
