// R8-B: tests for the LLM-as-reranker.
//
// We feed the reranker a mock LLM that returns canned score strings, and
// verify:
//   - candidates are sorted by the model's score, not the original embedding
//     order
//   - the prompt contains an entry per candidate with the truncated snippet
//   - parse failures fall back to embedding order (no crash)
//   - rows past `maxCandidates` are preserved at the tail without rerank
//   - the parser is tolerant of trailing prose / clamps out-of-range scores

import { describe, expect, it } from "vitest";
import { LLMReranker, type RerankCandidate, buildRerankPrompt, parseRerankScores } from "../src";

function makeCandidates(n: number): RerankCandidate[] {
	const out: RerankCandidate[] = [];
	for (let i = 0; i < n; i++) {
		out.push({
			filePath: `src/file_${i}.ts`,
			startLine: 1,
			endLine: 10,
			content: `// content for file ${i}\n`.repeat(20),
			score: 1 - i * 0.01,
		});
	}
	return out;
}

describe("parseRerankScores", () => {
	it("parses `id:score` pairs across newlines", () => {
		const out = parseRerankScores("1:7\n2:9\n3:3", 3);
		expect(out).toEqual([7, 9, 3]);
	});

	it("clamps scores above 10; ignores unparseable negatives", () => {
		const out = parseRerankScores("1:15\n2:-3\n3:8", 3);
		// `1:15` → clamped to 10. `2:-3` → skipped (negative sign isn't a digit
		// to the `\d:\d` regex; defensive — we never want NaN sneaking through).
		// `3:8` → 8.
		expect(out[0]).toBe(10);
		expect(out[1]).toBeUndefined();
		expect(out[2]).toBe(8);
	});

	it("survives trailing prose", () => {
		const out = parseRerankScores("1:8\n2:6\n3:5\n\nThese are my scores. I hope they help!", 3);
		expect(out).toEqual([8, 6, 5]);
	});

	it("returns undefined for skipped rows", () => {
		const out = parseRerankScores("1:9\n3:4", 3);
		expect(out[0]).toBe(9);
		expect(out[1]).toBeUndefined();
		expect(out[2]).toBe(4);
	});

	it("ignores ids outside the candidate range", () => {
		const out = parseRerankScores("9:9\n1:5", 2);
		expect(out).toEqual([5, undefined]);
	});
});

describe("buildRerankPrompt", () => {
	it("includes a numbered entry per candidate", () => {
		const cs = makeCandidates(3);
		const p = buildRerankPrompt("find auth", cs, 30);
		expect(p).toContain("Query: find auth");
		expect(p).toContain("[1] src/file_0.ts:1-10");
		expect(p).toContain("[2] src/file_1.ts:1-10");
		expect(p).toContain("[3] src/file_2.ts:1-10");
	});

	it("truncates long snippets to the configured cap", () => {
		const cs = makeCandidates(1);
		const p = buildRerankPrompt("q", cs, 25);
		// The truncated line should appear with an ellipsis sentinel.
		expect(p).toMatch(/\.\.\.|…/);
	});
});

describe("LLMReranker", () => {
	it("reorders candidates by LLM score", async () => {
		const cs = makeCandidates(3);
		// Embedding order is [0, 1, 2]; tell the reranker to score [3, 9, 5].
		const rr = new LLMReranker({
			callLlm: async () => "1:3\n2:9\n3:5",
		});
		const out = await rr.rerank("q", cs);
		expect(out[0].filePath).toBe("src/file_1.ts");
		expect(out[1].filePath).toBe("src/file_2.ts");
		expect(out[2].filePath).toBe("src/file_0.ts");
		expect(out[0].rerankScore).toBe(9);
	});

	it("falls back to embedding order on parse failure", async () => {
		const cs = makeCandidates(3);
		const rr = new LLMReranker({
			callLlm: async () => "I cannot help with that.",
		});
		const out = await rr.rerank("q", cs);
		// All scores undefined → fall back to embedding score. Sort is stable
		// for equal-rerankScore rows BUT we copied rerankScore from `c.score`,
		// so the input ordering (descending `score`) is preserved.
		expect(out.map((o) => o.filePath)).toEqual(["src/file_0.ts", "src/file_1.ts", "src/file_2.ts"]);
	});

	it("falls back to embedding order on LLM error", async () => {
		const cs = makeCandidates(2);
		const rr = new LLMReranker({
			callLlm: async () => {
				throw new Error("network down");
			},
		});
		const out = await rr.rerank("q", cs);
		expect(out).toHaveLength(2);
		expect(out[0].filePath).toBe("src/file_0.ts");
		expect(out[1].filePath).toBe("src/file_1.ts");
	});

	it("preserves rows beyond maxCandidates at the tail", async () => {
		const cs = makeCandidates(5);
		const rr = new LLMReranker({
			callLlm: async () => "1:1\n2:9\n3:2",
			maxCandidates: 3,
		});
		const out = await rr.rerank("q", cs);
		expect(out).toHaveLength(5);
		// First 3 are reranked.
		expect(out[0].filePath).toBe("src/file_1.ts"); // got "9"
		// Last 2 preserve embedding order at the tail.
		expect(out[3].filePath).toBe("src/file_3.ts");
		expect(out[4].filePath).toBe("src/file_4.ts");
	});

	it("returns empty for empty candidates", async () => {
		let called = false;
		const rr = new LLMReranker({
			callLlm: async () => {
				called = true;
				return "";
			},
		});
		const out = await rr.rerank("q", []);
		expect(out).toEqual([]);
		expect(called).toBe(false);
	});

	it("truncates snippets in the prompt to snippetCharCap", async () => {
		let captured = "";
		const rr = new LLMReranker({
			callLlm: async (prompt) => {
				captured = prompt;
				return "1:5";
			},
			snippetCharCap: 20,
		});
		const cs: RerankCandidate[] = [
			{
				filePath: "x.ts",
				startLine: 1,
				endLine: 1,
				content: "A".repeat(500),
				score: 1,
			},
		];
		await rr.rerank("q", cs);
		// The huge A-string must not appear verbatim in the prompt.
		expect(captured.includes("A".repeat(50))).toBe(false);
		expect(captured.length).toBeLessThan(2_000);
	});
});
