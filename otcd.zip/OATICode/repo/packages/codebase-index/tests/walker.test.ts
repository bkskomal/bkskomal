import * as fs from "node:fs";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { isIndexableExtension, walkWorkspace } from "../src/walker";
import { makeTempWorkspace, write } from "./helpers";

describe("isIndexableExtension", () => {
	it("recognizes source-code extensions", () => {
		expect(isIndexableExtension("foo.ts")).toBe(true);
		expect(isIndexableExtension("foo.py")).toBe(true);
		expect(isIndexableExtension("README.md")).toBe(true);
	});

	it("rejects binaries and unknown formats", () => {
		expect(isIndexableExtension("foo.png")).toBe(false);
		expect(isIndexableExtension("foo.zip")).toBe(false);
		expect(isIndexableExtension("foo")).toBe(false);
	});
});

describe("walkWorkspace", () => {
	let ws: { root: string; cleanup: () => void };
	beforeEach(() => {
		ws = makeTempWorkspace();
	});
	afterEach(() => ws.cleanup());

	it("yields indexable files", () => {
		write(ws.root, "src/a.ts", "// a");
		write(ws.root, "src/b.py", "# b");
		write(ws.root, "README.md", "# readme");
		const files = [...walkWorkspace(ws.root)].map((f) =>
			path.relative(ws.root, f).replace(/\\/g, "/"),
		);
		expect(files.sort()).toEqual(["README.md", "src/a.ts", "src/b.py"]);
	});

	it("skips node_modules / .git / dist by default", () => {
		write(ws.root, "src/a.ts", "// a");
		write(ws.root, "node_modules/foo/index.js", "// nm");
		write(ws.root, ".git/config", "[core]");
		write(ws.root, "dist/bundle.js", "// dist");
		const files = [...walkWorkspace(ws.root)].map((f) =>
			path.relative(ws.root, f).replace(/\\/g, "/"),
		);
		expect(files).toEqual(["src/a.ts"]);
	});

	it("respects .gitignore entries", () => {
		write(ws.root, ".gitignore", "secret.ts\nbuild/\n");
		write(ws.root, "secret.ts", "// secret");
		write(ws.root, "src/a.ts", "// a");
		write(ws.root, "build/output.js", "// build");
		const files = [...walkWorkspace(ws.root)].map((f) =>
			path.relative(ws.root, f).replace(/\\/g, "/"),
		);
		expect(files).toEqual(["src/a.ts"]);
	});

	it("supports nested .gitignore inheritance", () => {
		write(ws.root, ".gitignore", "*.log\n");
		write(ws.root, "logs/.gitignore", "!important.log\n");
		write(ws.root, "logs/important.log", "keep");
		write(ws.root, "logs/noise.log", "skip");
		write(ws.root, "logs/other.ts", "// keep");
		const files = [...walkWorkspace(ws.root)].map((f) =>
			path.relative(ws.root, f).replace(/\\/g, "/"),
		);
		// Note: *.log is excluded, important.log is re-included via negation in nested gitignore
		// (We don't include .log in INDEXABLE_EXTENSIONS, so important.log wouldn't be
		// indexed anyway — but we *do* need to confirm the .ts file is still found.)
		expect(files).toContain("logs/other.ts");
	});

	it("ignores symlinked directories (does not follow them)", () => {
		write(ws.root, "src/a.ts", "// a");
		// Create a symlink that would otherwise cause a cycle if followed.
		try {
			fs.symlinkSync(ws.root, path.join(ws.root, "self_link"), "dir");
		} catch {
			// Some platforms / CI environments disallow symlinks. Skip.
			return;
		}
		const files = [...walkWorkspace(ws.root)].map((f) =>
			path.relative(ws.root, f).replace(/\\/g, "/"),
		);
		// Should contain a.ts exactly once — no doubling through the symlink.
		expect(files.filter((f) => f.endsWith("a.ts"))).toHaveLength(1);
	});
});
