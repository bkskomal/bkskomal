// R8-B: tests for the pluggable embedder providers.
//
// We exercise each provider with a stub fetch that asserts:
//   - the URL we POST to
//   - the JSON body shape (model, input, dimensions/input_type/etc.)
//   - that the response embeddings come back as Float32Array, L2-normalized
//   - that non-2xx and shape-mismatched responses surface useful errors
//   - that missing API keys produce a "configure the key" error
//
// No live network. All three remote providers (OpenAI, Voyage, Cohere) share
// the same general expectations; the per-provider asserts diverge where the
// real APIs do.

import { describe, expect, it } from "vitest";
import {
	CohereEmbedder,
	OpenAIEmbedder,
	TfIdfEmbedderProvider,
	VoyageEmbedder,
	createEmbedder,
} from "../src/embedders";

const okJson = (payload: unknown): Response =>
	new Response(JSON.stringify(payload), {
		status: 200,
		headers: { "content-type": "application/json" },
	});

function fixedKey(key: string) {
	return async () => key;
}

describe("TfIdfEmbedderProvider", () => {
	it("identifies as 'tfidf' with 256-dim by default", async () => {
		const e = new TfIdfEmbedderProvider();
		expect(e.id).toBe("tfidf");
		expect(e.dimensions).toBe(256);
		expect(e.dim).toBe(256);
		const [v] = await e.embed(["hello world"]);
		expect(v).toBeInstanceOf(Float32Array);
		expect(v.length).toBe(256);
	});

	it("requires no API key (offline default)", async () => {
		const e = new TfIdfEmbedderProvider(64);
		// No getSecret was passed — calling embed must still succeed.
		const [v] = await e.embed(["abc"]);
		expect(v.length).toBe(64);
	});
});

describe("OpenAIEmbedder", () => {
	it("POSTs to /v1/embeddings with the right payload and parses vectors", async () => {
		const seen: { url: string; init: RequestInit | undefined }[] = [];
		const fakeFetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
			const url = typeof input === "string" ? input : input.toString();
			seen.push({ url, init });
			return okJson({ data: [{ embedding: [0.6, 0.8] }, { embedding: [1, 0] }] });
		}) as unknown as typeof fetch;
		const e = new OpenAIEmbedder({
			model: "text-embedding-3-small",
			dimensions: 2,
			getSecret: fixedKey("sk-test"),
			fetchImpl: fakeFetch,
		});
		const vecs = await e.embed(["hello", "world"]);
		expect(seen[0].url).toBe("https://api.openai.com/v1/embeddings");
		const body = JSON.parse((seen[0].init?.body as string) ?? "{}");
		expect(body.model).toBe("text-embedding-3-small");
		expect(body.input).toEqual(["hello", "world"]);
		expect(body.dimensions).toBe(2);
		expect(body.encoding_format).toBe("float");
		const headers = (seen[0].init?.headers ?? {}) as Record<string, string>;
		expect(headers.Authorization).toBe("Bearer sk-test");
		expect(vecs).toHaveLength(2);
		// Already unit-length → unchanged.
		expect(vecs[0][0]).toBeCloseTo(0.6, 5);
		expect(vecs[0][1]).toBeCloseTo(0.8, 5);
	});

	it("throws a 'configure the key' error when the secret is missing", async () => {
		const fakeFetch = (async () => okJson({ data: [] })) as unknown as typeof fetch;
		const e = new OpenAIEmbedder({
			getSecret: async () => undefined,
			fetchImpl: fakeFetch,
		});
		await expect(e.embed(["x"])).rejects.toThrow(/API key not set/);
	});

	it("surfaces non-2xx with status code in the message", async () => {
		const fakeFetch = (async () =>
			new Response("rate limited", { status: 429 })) as unknown as typeof fetch;
		const e = new OpenAIEmbedder({
			getSecret: fixedKey("sk-test"),
			fetchImpl: fakeFetch,
		});
		await expect(e.embed(["x"])).rejects.toThrow(/OpenAI embeddings failed \(429\)/);
	});

	it("rejects a shape-mismatched response", async () => {
		const fakeFetch = (async () =>
			okJson({ data: [{ embedding: [1, 0] }] })) as unknown as typeof fetch;
		const e = new OpenAIEmbedder({
			getSecret: fixedKey("sk-test"),
			fetchImpl: fakeFetch,
		});
		await expect(e.embed(["a", "b", "c"])).rejects.toThrow(/expected 3 vectors/);
	});
});

describe("VoyageEmbedder", () => {
	it("POSTs to voyage's /v1/embeddings with input_type=document by default", async () => {
		const seen: { url: string; body: string }[] = [];
		const fakeFetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
			const url = typeof input === "string" ? input : input.toString();
			seen.push({ url, body: (init?.body as string) ?? "" });
			return okJson({ data: [{ embedding: [0.6, 0.8] }] });
		}) as unknown as typeof fetch;
		const e = new VoyageEmbedder({
			model: "voyage-code-3",
			dimensions: 2,
			getSecret: fixedKey("vk-test"),
			fetchImpl: fakeFetch,
		});
		const vecs = await e.embed(["fn foo()"]);
		expect(seen[0].url).toBe("https://api.voyageai.com/v1/embeddings");
		const body = JSON.parse(seen[0].body);
		expect(body.model).toBe("voyage-code-3");
		expect(body.input).toEqual(["fn foo()"]);
		expect(body.input_type).toBe("document");
		expect(body.output_dimension).toBe(2);
		expect(vecs[0][0]).toBeCloseTo(0.6, 5);
	});

	it("honors an explicit input_type override (query mode)", async () => {
		const seen: string[] = [];
		const fakeFetch = (async (_input: unknown, init?: RequestInit) => {
			seen.push((init?.body as string) ?? "");
			return okJson({ data: [{ embedding: [1, 0] }] });
		}) as unknown as typeof fetch;
		const e = new VoyageEmbedder({
			dimensions: 2,
			inputType: "query",
			getSecret: fixedKey("vk-test"),
			fetchImpl: fakeFetch,
		});
		await e.embed(["where is auth validated"]);
		expect(JSON.parse(seen[0]).input_type).toBe("query");
	});

	it("throws on missing key", async () => {
		const fakeFetch = (async () => okJson({})) as unknown as typeof fetch;
		const e = new VoyageEmbedder({
			getSecret: async () => undefined,
			fetchImpl: fakeFetch,
		});
		await expect(e.embed(["x"])).rejects.toThrow(/API key not set/);
	});
});

describe("CohereEmbedder", () => {
	it("POSTs to /v1/embed with texts + input_type + embedding_types", async () => {
		const seen: { url: string; body: string }[] = [];
		const fakeFetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
			const url = typeof input === "string" ? input : input.toString();
			seen.push({ url, body: (init?.body as string) ?? "" });
			return okJson({ embeddings: { float: [[0.6, 0.8]] } });
		}) as unknown as typeof fetch;
		const e = new CohereEmbedder({
			model: "embed-english-v3.0",
			dimensions: 2,
			getSecret: fixedKey("co-test"),
			fetchImpl: fakeFetch,
		});
		const vecs = await e.embed(["hello"]);
		expect(seen[0].url).toBe("https://api.cohere.com/v1/embed");
		const body = JSON.parse(seen[0].body);
		expect(body.model).toBe("embed-english-v3.0");
		expect(body.texts).toEqual(["hello"]);
		expect(body.input_type).toBe("search_document");
		expect(body.embedding_types).toEqual(["float"]);
		expect(vecs[0][0]).toBeCloseTo(0.6, 5);
	});

	it("accepts the legacy `embeddings: number[][]` shape", async () => {
		const fakeFetch = (async () => okJson({ embeddings: [[1, 0]] })) as unknown as typeof fetch;
		const e = new CohereEmbedder({
			dimensions: 2,
			getSecret: fixedKey("co-test"),
			fetchImpl: fakeFetch,
		});
		const vecs = await e.embed(["a"]);
		expect(vecs[0][0]).toBeCloseTo(1, 5);
	});

	it("surfaces non-2xx with status code", async () => {
		const fakeFetch = (async () =>
			new Response("forbidden", { status: 403 })) as unknown as typeof fetch;
		const e = new CohereEmbedder({
			getSecret: fixedKey("co-test"),
			fetchImpl: fakeFetch,
		});
		await expect(e.embed(["x"])).rejects.toThrow(/Cohere embeddings failed \(403\)/);
	});
});

describe("createEmbedder factory", () => {
	it("dispatches by id", () => {
		const tfidf = createEmbedder({ id: "tfidf", getSecret: async () => undefined });
		expect(tfidf.id).toBe("tfidf");

		const openai = createEmbedder({ id: "openai", getSecret: fixedKey("k") });
		expect(openai.id).toBe("openai");
		expect(openai.dimensions).toBe(1536);

		const voyage = createEmbedder({ id: "voyage", getSecret: fixedKey("k") });
		expect(voyage.id).toBe("voyage");
		expect(voyage.dimensions).toBe(1024);

		const cohere = createEmbedder({ id: "cohere", getSecret: fixedKey("k") });
		expect(cohere.id).toBe("cohere");
		expect(cohere.dimensions).toBe(1024);
	});

	it("honors dimension overrides", () => {
		const openai = createEmbedder({
			id: "openai",
			dimensions: 512,
			getSecret: fixedKey("k"),
		});
		expect(openai.dimensions).toBe(512);
	});
});
