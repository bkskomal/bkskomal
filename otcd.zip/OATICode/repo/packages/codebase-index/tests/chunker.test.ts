import { describe, expect, it } from "vitest";
import { MAX_CHUNK_CHARS, chunkContent, languageForPath } from "../src/chunker";

describe("languageForPath", () => {
	it("maps common extensions", () => {
		expect(languageForPath("src/foo.ts")).toBe("ts");
		expect(languageForPath("a.tsx")).toBe("ts");
		expect(languageForPath("a.py")).toBe("py");
		expect(languageForPath("a.go")).toBe("go");
		expect(languageForPath("a.md")).toBe("md");
		expect(languageForPath("a.json")).toBe("json");
	});

	it("falls back to text for unknown extensions", () => {
		expect(languageForPath("Dockerfile")).toBe("text");
		expect(languageForPath("a.xyz")).toBe("text");
	});

	it("is case-insensitive on extensions", () => {
		expect(languageForPath("FOO.TS")).toBe("ts");
		expect(languageForPath("README.MD")).toBe("md");
	});
});

describe("chunkContent", () => {
	it("returns no chunks for empty input", () => {
		expect(chunkContent("", "ts")).toEqual([]);
	});

	it("splits TypeScript by top-level functions", () => {
		// Each function body is intentionally padded past MIN_CHUNK_CHARS (64
		// chars) so the post-process merger doesn't collapse them into one
		// chunk. Real codebases hit this naturally; the test just needs to
		// model that to exercise the boundary-detection branch.
		const body = (tag: string) =>
			[
				"  const result = doSomethingComputational();",
				`  console.log("running ${tag}");`,
				"  for (let i = 0; i < 10; i++) result.push(i);",
				"  return result;",
			].join("\n");
		const src = [
			"// header comment file-level docs",
			"export function alpha() {",
			body("alpha"),
			"}",
			"",
			"export function beta() {",
			body("beta"),
			"}",
			"",
			"export function gamma() {",
			body("gamma"),
			"}",
		].join("\n");
		const chunks = chunkContent(src, "ts");
		expect(chunks.length).toBeGreaterThanOrEqual(2);
		const joined = chunks.map((c) => c.content).join("\n");
		expect(joined).toContain("function alpha");
		expect(joined).toContain("function beta");
		expect(joined).toContain("function gamma");
	});

	it("splits Python by def/class", () => {
		// Padded function bodies so post-process merging keeps the splits.
		const body = (tag: string) =>
			[
				`    """${tag} does the thing"""`,
				"    result = []",
				"    for i in range(10):",
				`        result.append(("${tag}", i))`,
				"    return result",
			].join("\n");
		const src = [
			"def foo():",
			body("foo"),
			"",
			"def bar():",
			body("bar"),
			"",
			"class Baz:",
			"    def m(self):",
			body("baz_m"),
		].join("\n");
		const chunks = chunkContent(src, "py");
		expect(chunks.length).toBeGreaterThanOrEqual(2);
		const all = chunks.map((c) => c.content).join("\n");
		expect(all).toContain("def foo");
		expect(all).toContain("class Baz");
	});

	it("uses sliding window for plain text", () => {
		// 100 lines of content, language=text → no boundary patterns.
		const lines = Array.from({ length: 100 }, (_, i) => `line ${i + 1}`);
		const chunks = chunkContent(lines.join("\n"), "text");
		expect(chunks.length).toBeGreaterThan(1);
		// First chunk starts at line 1.
		expect(chunks[0].startLine).toBe(1);
		// Coverage is contiguous: each chunk's endLine + 1 == next startLine.
		for (let i = 1; i < chunks.length; i++) {
			expect(chunks[i].startLine).toBe(chunks[i - 1].endLine + 1);
		}
	});

	it("never produces a chunk larger than MAX_CHUNK_CHARS", () => {
		// A single huge function body. The chunker must still split it.
		const huge = `function big() {\n${"  doSomething();\n".repeat(2000)}}\n`;
		const chunks = chunkContent(huge, "ts");
		for (const c of chunks) {
			expect(c.content.length).toBeLessThanOrEqual(MAX_CHUNK_CHARS);
		}
	});

	it("skips files over MAX_FILE_BYTES", () => {
		const enormous = "x".repeat(2_000_000);
		expect(chunkContent(enormous, "ts")).toEqual([]);
	});

	it("merges tiny adjacent chunks", () => {
		// Three near-empty exports — would naively produce 3 minuscule chunks,
		// but the post-process merges them.
		const src = ["export const a = 1;", "export const b = 2;", "export const c = 3;"].join("\n");
		const chunks = chunkContent(src, "ts");
		// We don't care about the exact count, only that we didn't emit 3 fragments
		// when one consolidated chunk would do.
		expect(chunks.length).toBeLessThanOrEqual(2);
	});

	it("reports correct startLine/endLine", () => {
		const src = [
			"// 1",
			"export function alpha() {", // 2
			"  return 1;", // 3
			"}", // 4
			"", // 5
			"export function beta() {", // 6
			"  return 2;", // 7
			"}", // 8
		].join("\n");
		const chunks = chunkContent(src, "ts");
		// Lines should be 1-based and contiguous across chunks.
		expect(chunks[0].startLine).toBe(1);
		expect(chunks[chunks.length - 1].endLine).toBe(8);
	});
});
