import { describe, expect, it } from "vitest";
import { rrfMerge } from "../src/rrf-merge";

// Helper: make a ranking from a list of ids. Payload === id for brevity.
const r = (...ids: string[]) => ids.map((id) => ({ id, payload: id }));

describe("rrfMerge — core behaviour", () => {
	it("returns empty when all rankings are empty", () => {
		expect(rrfMerge<string>([[], []])).toEqual([]);
	});

	it("returns the input ranking unchanged (shape-wise) when there is only one", () => {
		const out = rrfMerge([r("a", "b", "c")]);
		expect(out.map((x) => x.id)).toEqual(["a", "b", "c"]);
		// Scores must be monotonically non-increasing.
		expect(out[0].score).toBeGreaterThan(out[1].score);
		expect(out[1].score).toBeGreaterThan(out[2].score);
	});

	it("an item ranked highly in both inputs beats items ranked highly in only one", () => {
		// `b` is rank-2 in both, others are rank-1 in only one ranking.
		const out = rrfMerge([r("a", "b", "c"), r("d", "b", "e")]);
		expect(out[0].id).toBe("b");
	});

	it("documents that appear in only one ranking still get a score", () => {
		const out = rrfMerge([r("a", "b"), r("c", "d")]);
		const ids = out.map((x) => x.id);
		expect(ids).toContain("a");
		expect(ids).toContain("c");
	});

	it("matches the formula 1/(k + rank) with k=60 (default)", () => {
		const out = rrfMerge([r("only")]);
		expect(out[0].score).toBeCloseTo(1 / 61, 10);
	});

	it("respects a custom k", () => {
		const out = rrfMerge([r("only")], { k: 10 });
		expect(out[0].score).toBeCloseTo(1 / 11, 10);
	});

	it("sums contributions for an item appearing in multiple rankings", () => {
		const out = rrfMerge([r("x"), r("x")]); // appears rank-1 in two rankings
		expect(out[0].score).toBeCloseTo(2 / 61, 10);
	});

	it("applies per-ranking weights", () => {
		const out = rrfMerge([r("a"), r("b")], { weights: [10, 1] });
		// a's contribution = 10/61, b's = 1/61
		expect(out[0].id).toBe("a");
		expect(out[0].score).toBeCloseTo(10 / 61, 10);
		expect(out[1].score).toBeCloseTo(1 / 61, 10);
	});

	it("throws when weights length does not match rankings length", () => {
		expect(() => rrfMerge([r("a"), r("b")], { weights: [1] })).toThrow(/weights length/);
	});
});

describe("rrfMerge — ranks diagnostic", () => {
	it("records the rank each item had in each input ranking", () => {
		const out = rrfMerge([r("a", "b", "c"), r("x", "b", "y")]);
		const b = out.find((x) => x.id === "b");
		// b is rank-2 in both rankings.
		expect(b?.ranks).toEqual([2, 2]);

		const a = out.find((x) => x.id === "a");
		// a is only in ranking 0, at rank 1; absent from ranking 1.
		expect(a?.ranks).toEqual([1, undefined]);

		const x = out.find((x) => x.id === "x");
		expect(x?.ranks).toEqual([undefined, 1]);
	});
});

describe("rrfMerge — tie-breaking", () => {
	it("breaks ties by first-seen insertion order (stable)", () => {
		// Both rankings put their items at rank 1, so each item gets the
		// same RRF score. The first-seen one (from the first ranking) wins.
		const out = rrfMerge([r("a"), r("b")]);
		expect(out.map((x) => x.id)).toEqual(["a", "b"]);
		// Confirm the scores are equal.
		expect(out[0].score).toEqual(out[1].score);
	});

	it("ties between three items resolve in insertion order", () => {
		const out = rrfMerge([r("first"), r("second"), r("third")]);
		expect(out.map((x) => x.id)).toEqual(["first", "second", "third"]);
	});
});

describe("rrfMerge — limit", () => {
	it("truncates to the requested limit", () => {
		const out = rrfMerge([r("a", "b", "c", "d", "e")], { limit: 3 });
		expect(out).toHaveLength(3);
		expect(out.map((x) => x.id)).toEqual(["a", "b", "c"]);
	});

	it("does not truncate when limit exceeds the merged size", () => {
		const out = rrfMerge([r("a", "b")], { limit: 99 });
		expect(out).toHaveLength(2);
	});
});

describe("rrfMerge — payload", () => {
	it("preserves the first-seen payload for an id (semantic ranking wins by convention)", () => {
		// Same id, different payloads — first one wins. This is how we let
		// the semantic ranking's symbol-rich snippet survive a lexical hit
		// for the same chunk.
		const out = rrfMerge([
			[{ id: "x", payload: { from: "semantic", symbol: "foo" } }],
			[{ id: "x", payload: { from: "lexical" } }],
		]);
		expect(out[0].payload).toEqual({ from: "semantic", symbol: "foo" });
	});
});
