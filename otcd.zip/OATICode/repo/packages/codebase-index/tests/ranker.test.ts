import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { CodebaseIndex, rankFiles } from "../src";
import { TagEmbedder, makeTempWorkspace, write } from "./helpers";

describe("rankFiles", () => {
	let ws: { root: string; cleanup: () => void };

	beforeEach(() => {
		ws = makeTempWorkspace();
	});

	afterEach(() => ws.cleanup());

	it("ranks the semantic match highest when prompt is informative", async () => {
		write(ws.root, "src/auth.ts", "// __TAG_1__ auth logic\n");
		write(ws.root, "src/billing.ts", "// __TAG_2__ billing\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		const ranked = await rankFiles(idx, {
			prompt: "looking for __TAG_1__",
			openFiles: [],
			recentlyEdited: [],
		});
		expect(ranked[0].filePath).toBe("src/auth.ts");
		idx.close();
	});

	it("boosts open files over unrelated ones when prompt is empty", async () => {
		write(ws.root, "src/a.ts", "// a\n");
		write(ws.root, "src/b.ts", "// b\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		const ranked = await rankFiles(idx, {
			prompt: "",
			openFiles: ["src/b.ts"],
			recentlyEdited: [],
		});
		expect(ranked.find((r) => r.filePath === "src/b.ts")?.score).toBeGreaterThan(
			ranked.find((r) => r.filePath === "src/a.ts")?.score ?? 0,
		);
		idx.close();
	});

	it("decays recency boost with position", async () => {
		write(ws.root, "src/a.ts", "// a\n");
		write(ws.root, "src/b.ts", "// b\n");
		write(ws.root, "src/c.ts", "// c\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		const ranked = await rankFiles(idx, {
			prompt: "",
			openFiles: [],
			recentlyEdited: ["src/a.ts", "src/b.ts", "src/c.ts"],
		});
		const a = ranked.find((r) => r.filePath === "src/a.ts");
		const c = ranked.find((r) => r.filePath === "src/c.ts");
		expect(a?.breakdown.recencyBoost ?? 0).toBeGreaterThan(c?.breakdown.recencyBoost ?? 0);
		idx.close();
	});

	it("returns the requested number of files", async () => {
		for (let i = 0; i < 8; i++) write(ws.root, `src/f${i}.ts`, `// __TAG_${i}__ content\n`);
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		const ranked = await rankFiles(idx, {
			prompt: "anything",
			openFiles: ["src/f1.ts"],
			recentlyEdited: ["src/f2.ts"],
			k: 3,
		});
		expect(ranked.length).toBeLessThanOrEqual(3);
		idx.close();
	});

	it("applies proximity boost to siblings of open files", async () => {
		write(ws.root, "src/auth/login.ts", "// login\n");
		write(ws.root, "src/auth/register.ts", "// register\n");
		write(ws.root, "src/billing/charge.ts", "// charge\n");
		const idx = new CodebaseIndex({
			workspaceRoot: ws.root,
			dbPath: ":memory:",
			embedder: new TagEmbedder(),
		});
		await idx.indexAll();
		const ranked = await rankFiles(idx, {
			prompt: "",
			openFiles: ["src/auth/login.ts"],
			recentlyEdited: [],
		});
		const reg = ranked.find((r) => r.filePath === "src/auth/register.ts");
		const charge = ranked.find((r) => r.filePath === "src/billing/charge.ts");
		// `register.ts` is a sibling of the open `login.ts`; `charge.ts` is in a different package.
		expect(reg?.breakdown.proximity ?? 0).toBeGreaterThan(charge?.breakdown.proximity ?? 0);
		idx.close();
	});
});
