// R4-A: validate that the tree-sitter chunker actually fires when bundled
// grammars are present, and that it falls back cleanly when they're not.
//
// The bundled wasm grammars live at `packages/codebase-index/grammars/`
// (populated by `scripts/sync-grammars.mjs`). The tests below detect that
// directory at runtime; if the grammars haven't been synced yet (fresh
// clone, never built) the AST assertions become smoke tests that confirm
// the chunker returns `null` and the smart entry point falls back to regex.

import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { afterAll, afterEach, describe, expect, it } from "vitest";
import { chunkContentSmart } from "../src/chunker";
import {
	_resetTreeSitterCacheForTests,
	_setGrammarsDirForTests,
	chunkContentTreeSitter,
} from "../src/treesitter-chunker";

const __dirname = dirname(fileURLToPath(import.meta.url));
const grammarsDir = resolve(__dirname, "..", "grammars");
const grammarsAvailable = existsSync(resolve(grammarsDir, "tree-sitter-typescript.wasm"));

const TS_SRC = [
	"// header",
	"export function alpha(): number {",
	"  return 1;",
	"}",
	"",
	"export class Beta {",
	"  greet(name: string): string {",
	"    return `hi ${name}`;",
	"  }",
	"}",
	"",
	"export function gamma(x: number): number {",
	"  return x * 2;",
	"}",
].join("\n");

const PY_SRC = [
	"# header",
	"def alpha():",
	'    """alpha doc"""',
	"    return 1",
	"",
	"class Beta:",
	"    def greet(self, name):",
	"        return f'hi {name}'",
	"",
	"def gamma(x):",
	"    return x * 2",
].join("\n");

afterEach(() => {
	_resetTreeSitterCacheForTests();
	_setGrammarsDirForTests(undefined);
});

afterAll(() => {
	_resetTreeSitterCacheForTests();
	_setGrammarsDirForTests(undefined);
});

describe("treesitter-chunker (bundled grammars)", () => {
	it.skipIf(!grammarsAvailable)("emits symbol-named chunks for TypeScript", async () => {
		const chunks = await chunkContentTreeSitter(TS_SRC, "ts");
		expect(chunks).not.toBeNull();
		// biome-ignore lint/style/noNonNullAssertion: guarded by the assertion above.
		const c = chunks!;
		const names = c.map((ch) => ch.symbolName).filter(Boolean);
		expect(names).toContain("alpha");
		expect(names).toContain("Beta");
		expect(names).toContain("gamma");
	});

	it.skipIf(!grammarsAvailable)("emits symbol-named chunks for Python", async () => {
		const chunks = await chunkContentTreeSitter(PY_SRC, "py");
		expect(chunks).not.toBeNull();
		// biome-ignore lint/style/noNonNullAssertion: guarded by the assertion above.
		const c = chunks!;
		const names = c.map((ch) => ch.symbolName).filter(Boolean);
		expect(names).toContain("alpha");
		expect(names).toContain("Beta");
		expect(names).toContain("gamma");
	});

	it("falls back to regex chunker when grammars are missing", async () => {
		// Point the grammar lookup at an empty directory; the tree-sitter
		// chunker should return null and `chunkContentSmart` should fall
		// back to regex without throwing.
		_setGrammarsDirForTests(resolve(__dirname, "no-such-dir"));
		const direct = await chunkContentTreeSitter(TS_SRC, "ts");
		expect(direct).toBeNull();
		// And the smart entry point still produces chunks via regex.
		const smart = await chunkContentSmart(TS_SRC, "ts");
		expect(smart.length).toBeGreaterThan(0);
		// Regex-only chunks have no symbolName set.
		for (const ch of smart) {
			expect(ch.symbolName).toBeUndefined();
		}
	});

	it("returns null for unsupported languages", async () => {
		const result = await chunkContentTreeSitter("hello world", "md");
		expect(result).toBeNull();
	});
});
