import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { Embedder } from "../src";

/**
 * Make a sandboxed workspace under the OS temp dir. The caller gets back the
 * absolute path; tests should pass `cleanup` to vitest's `afterEach` so we
 * don't leak GB of test data across runs.
 */
export function makeTempWorkspace(prefix = "codebase-index-test-"): {
	root: string;
	cleanup: () => void;
} {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), prefix));
	return {
		root,
		cleanup: () => {
			try {
				fs.rmSync(root, { recursive: true, force: true });
			} catch {
				/* best-effort */
			}
		},
	};
}

export function write(root: string, relPath: string, content: string): string {
	const abs = path.join(root, relPath);
	fs.mkdirSync(path.dirname(abs), { recursive: true });
	fs.writeFileSync(abs, content, "utf-8");
	return abs;
}

/**
 * Test embedder that returns a stable, controllable vector for each input.
 *
 * Mode "tag": looks for tokens of the form `__TAG_x__` in the text and creates
 * a one-hot vector at slot `x`. Lets a test say "this chunk is about topic 3,
 * and that query is about topic 3" without depending on token-collision details.
 *
 * Mode "tfidf": delegates to a real `TfIdfEmbedder`-equivalent hash. Useful for
 * end-to-end tests that want realistic ranking behavior.
 */
export class TagEmbedder implements Embedder {
	readonly dim: number;
	private callCount = 0;

	constructor(dim = 16) {
		this.dim = dim;
	}

	get calls(): number {
		return this.callCount;
	}

	async embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		this.callCount += texts.length;
		return texts.map((t) => {
			const vec = new Float32Array(this.dim);
			const matches = [...t.matchAll(/__TAG_(\d+)__/g)];
			if (matches.length === 0) {
				// No tag → emit a tiny background signal so cosine isn't 0 against everything.
				vec[0] = 0.1;
				return vec;
			}
			for (const m of matches) {
				const slot = Number.parseInt(m[1], 10) % this.dim;
				vec[slot] += 1;
			}
			// Normalize so cosine == dot.
			let n = 0;
			for (let i = 0; i < this.dim; i++) n += vec[i] * vec[i];
			if (n > 0) {
				const inv = 1 / Math.sqrt(n);
				for (let i = 0; i < this.dim; i++) vec[i] *= inv;
			}
			return vec;
		});
	}
}
