// Reciprocal Rank Fusion (RRF) for hybrid retrieval.
//
// Why RRF: combining a semantic ranking with a lexical ranking is hard
// because the two systems produce scores on incomparable scales —
// cosine similarity sits in [0, 1], ripgrep returns match counts, BM25
// gives unbounded positive numbers. Normalizing them all to a shared
// scale requires per-query calibration and falls apart on outliers.
//
// RRF sidesteps the problem entirely by ignoring the raw scores and
// using only the *rank* of each document in each ranking. The formula:
//
//   rrf(d) = Σ over each ranking r:  1 / (k + rank_r(d))
//
// where `rank_r(d)` is 1-indexed (the top result has rank 1, second 2,
// etc.) and `k` is a constant (60 in the original paper, robust across
// domains). Documents that rank high in either input get a high RRF
// score; documents that rank high in BOTH get a much higher one.
//
// Reference: Cormack et al., "Reciprocal Rank Fusion outperforms
// Condorcet and Individual Rank Learning Methods" (SIGIR 2009). This
// is what Elastic, Vespa, and Sourcegraph all use in production for
// hybrid lexical + vector search. Standard k=60, but exposed for
// tuning in case a domain wants different head/tail weighting.
//
// Pure module — no I/O, no async, trivially testable.

/**
 * A single ranked item from one of the input rankings.
 *
 * `id` is whatever uniquely identifies a document across both rankings;
 * for our chunk-level search it's `${filePath}:${startLine}-${endLine}`.
 * Two items with the same id from different rankings are treated as the
 * same document and their contributions sum.
 *
 * `payload` is opaque — RRF doesn't read it. Callers stash the original
 * search result here so they can reconstruct the merged top-k without a
 * second lookup pass.
 */
export interface RankedItem<P> {
	readonly id: string;
	readonly payload: P;
}

export interface RrfOptions {
	/**
	 * The `k` constant in the RRF formula. The standard value is 60 —
	 * raising it flattens the head/tail contribution gap, lowering it
	 * sharpens it. Don't change without a query-quality reason.
	 */
	readonly k?: number;
	/**
	 * How many merged results to return. Defaults to the size of the
	 * larger input; cap it when you know the consumer only needs top-N.
	 */
	readonly limit?: number;
	/**
	 * Per-ranking weight. Default is 1.0 for every ranking — equal
	 * voice. Set 0 < w < 1 to attenuate one ranking's contribution,
	 * > 1 to amplify. RRF is robust to modest weight changes; large
	 * imbalances just collapse to one of the inputs.
	 */
	readonly weights?: readonly number[];
}

export interface MergedResult<P> {
	readonly id: string;
	readonly payload: P;
	readonly score: number;
	/**
	 * Diagnostic: for each input ranking, what rank did this item have?
	 * `undefined` means it didn't appear in that ranking. Useful for
	 * "why did this rank so high" debugging without re-running queries.
	 */
	readonly ranks: readonly (number | undefined)[];
}

/**
 * Merge N rankings into a single ranked list via Reciprocal Rank Fusion.
 *
 * The first `payload` encountered for a given id wins — if the semantic
 * and lexical rankings carry slightly different payloads for the same
 * chunk (e.g., different snippet windows), the caller controls priority
 * by passing the preferred ranking first. For our case we put semantic
 * first because its chunks carry symbol metadata that the lexical hits
 * lack.
 *
 * Stable for ties: when two items have identical RRF scores, the one
 * that appeared first in the first ranking wins. Important because the
 * standard formula is otherwise insensitive to tied scores.
 */
export function rrfMerge<P>(
	rankings: ReadonlyArray<readonly RankedItem<P>[]>,
	options: RrfOptions = {},
): MergedResult<P>[] {
	const k = options.k ?? 60;
	const weights = options.weights ?? rankings.map(() => 1);
	if (weights.length !== rankings.length) {
		throw new Error(
			`rrfMerge: weights length (${weights.length}) must match rankings length (${rankings.length})`,
		);
	}

	// Build a map id -> accumulator. We track the first-seen payload, the
	// running RRF score, the per-ranking rank, and an insertion index so
	// ties resolve deterministically rather than depending on Map order.
	interface Accum<P> {
		payload: P;
		score: number;
		ranks: (number | undefined)[];
		insertionIdx: number;
	}
	const acc = new Map<string, Accum<P>>();
	let nextInsertion = 0;

	for (let rIdx = 0; rIdx < rankings.length; rIdx++) {
		const ranking = rankings[rIdx];
		const w = weights[rIdx];
		for (let i = 0; i < ranking.length; i++) {
			const item = ranking[i];
			const rank = i + 1; // 1-indexed
			const contribution = w * (1 / (k + rank));
			const existing = acc.get(item.id);
			if (existing) {
				existing.score += contribution;
				existing.ranks[rIdx] = rank;
			} else {
				const ranks: (number | undefined)[] = new Array(rankings.length).fill(undefined);
				ranks[rIdx] = rank;
				acc.set(item.id, {
					payload: item.payload,
					score: contribution,
					ranks,
					insertionIdx: nextInsertion++,
				});
			}
		}
	}

	const merged: MergedResult<P>[] = [];
	for (const [id, a] of acc) {
		merged.push({ id, payload: a.payload, score: a.score, ranks: a.ranks });
	}
	// Sort by score DESC, breaking ties by insertion order ASC (stable).
	merged.sort((x, y) => {
		if (y.score !== x.score) return y.score - x.score;
		const xa = acc.get(x.id);
		const ya = acc.get(y.id);
		return (xa?.insertionIdx ?? 0) - (ya?.insertionIdx ?? 0);
	});

	const limit = options.limit ?? merged.length;
	return merged.slice(0, limit);
}

/**
 * Collapse a chunk-level ranking to a file-level ranking, keeping the
 * single best-scoring entry per file. This is the right prep step
 * before RRF when one ranking is chunk-level (semantic) and the other
 * is line-level or coarser (lexical) — different chunks of the same
 * file would otherwise compete with themselves instead of cooperating.
 *
 * Stable for ties: when two chunks of the same file share the top
 * score, the one that appeared first in the input ranking is kept.
 *
 * Generic over result shape — any object carrying `filePath` and
 * `score` works. The output is `RankedItem` shape ready for `rrfMerge`.
 */
export function collapseToFileLevel<T extends { filePath: string; score: number }>(
	results: readonly T[],
): RankedItem<T>[] {
	const byFile = new Map<string, T>();
	// Iterate in input order so ties resolve to first-seen.
	for (const r of results) {
		const existing = byFile.get(r.filePath);
		if (!existing || r.score > existing.score) {
			byFile.set(r.filePath, r);
		}
	}
	// Preserve order by score (input is assumed sorted DESC, but be
	// defensive — RRF only reads rank, but the merge's tie-break uses
	// insertion order, so we want the best-scoring files first).
	const ordered = [...byFile.values()].sort((a, b) => b.score - a.score);
	return ordered.map((r) => ({ id: r.filePath, payload: r }));
}
