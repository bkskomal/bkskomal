import * as path from "node:path";
import type { CodebaseIndex } from "./codebase-index";

/**
 * File-level relevance ranking for the `@file` autocomplete and the agent's
 * "smart context" prompt. The model already gets to call `code_semantic_search`
 * directly, but pre-seeding the workspaceFiles list with likely-relevant paths
 * means the user (and the model's first turn) doesn't have to scroll past 500
 * unrelated tree entries.
 *
 * Signals combined:
 *   1. **Semantic similarity** — embed the user's prompt, look up top-N chunks
 *      in the index, group by file, take max chunk score. (Heaviest signal,
 *      strongest predictor when present.)
 *   2. **Open editor files** — files the user currently has open get a flat
 *      boost. "What I'm looking at right now" is a strong context signal.
 *   3. **Recently edited (git log)** — files touched in the last N commits.
 *      Decays with index in the list so the most recent change wins.
 *   4. **Import-graph proximity** — files in the same directory subtree as the
 *      open files, OR files whose paths show up textually in the open files'
 *      contents (treated as an import-edge approximation without parsing).
 *
 * The weights are deliberately rough; the goal is **ordering** rather than
 * absolute calibration. We expose the raw breakdown so consumers can tune or
 * debug the ranking from the UI.
 */

export interface RankInput {
	/** User prompt to embed for semantic similarity. May be empty. */
	readonly prompt: string;
	/** Workspace-relative paths the user currently has open. */
	readonly openFiles: readonly string[];
	/** Workspace-relative paths the user recently edited (most recent first). */
	readonly recentlyEdited: readonly string[];
	/** Optional cap on the number of files returned (default 20). */
	readonly k?: number;
	/** Optional snippets of open files keyed by relative path — used for import-edge text search. */
	readonly openFileContents?: Readonly<Record<string, string>>;
}

export interface FileRankBreakdown {
	readonly semantic: number;
	readonly openBoost: number;
	readonly recencyBoost: number;
	readonly proximity: number;
}

export interface RankResult {
	readonly filePath: string;
	readonly score: number;
	readonly breakdown: FileRankBreakdown;
}

/**
 * Tunable weights. Kept here (not in a config) because they're an
 * implementation detail of the ranking algorithm, not a user-facing knob.
 */
const W_SEMANTIC = 1.0;
const W_OPEN = 0.6;
const W_RECENCY = 0.4;
const W_PROXIMITY = 0.3;

/** How many semantic-search hits to consider when aggregating per-file scores. */
const SEMANTIC_TOP_K = 40;

export async function rankFiles(
	index: CodebaseIndex,
	input: RankInput,
): Promise<readonly RankResult[]> {
	const breakdowns = new Map<string, FileRankBreakdown>();
	const touch = (file: string, patch: Partial<FileRankBreakdown>) => {
		const prev = breakdowns.get(file) ?? {
			semantic: 0,
			openBoost: 0,
			recencyBoost: 0,
			proximity: 0,
		};
		breakdowns.set(file, { ...prev, ...patch });
	};

	// 1. Semantic — take top-K chunks, fold into per-file max.
	if (input.prompt.trim().length > 0) {
		const hits = await index.query(input.prompt, { k: SEMANTIC_TOP_K });
		const perFile = new Map<string, number>();
		for (const h of hits) {
			const existing = perFile.get(h.filePath) ?? 0;
			if (h.score > existing) perFile.set(h.filePath, h.score);
		}
		for (const [file, score] of perFile) touch(file, { semantic: score });
	}

	// 2. Open editor files — flat boost of 1.0 (post-weight). Falls off if a
	// file shows up multiple times in `openFiles` (shouldn't, but be defensive).
	for (const f of input.openFiles) {
		const norm = normalizeRel(f);
		touch(norm, { openBoost: 1 });
	}

	// 3. Recently edited — exponential decay over position. Most recent = 1.0,
	// position N = 1 / (1 + N/5) so the first ~5 entries get meaningful weight
	// and the tail tapers off without ever hitting zero (you might still want
	// to surface "this file from 50 commits ago").
	for (let i = 0; i < input.recentlyEdited.length; i++) {
		const norm = normalizeRel(input.recentlyEdited[i]);
		const decay = 1 / (1 + i / 5);
		// `touch` overwrites — but a file appearing earlier in the list (more
		// recent) gives a strictly larger decay, so first-write-wins is correct.
		if ((breakdowns.get(norm)?.recencyBoost ?? 0) < decay) {
			touch(norm, { recencyBoost: decay });
		}
	}

	// 4. Proximity — files that share a long directory prefix with an open
	// file, or that are imported by name in an open file's content. Both are
	// crude but cheap; the model can ignore them if they're noise.
	//
	// Candidate set includes everything the index knows about, so siblings of
	// open files surface even when they didn't land a semantic hit. This is
	// the whole point of proximity — "you opened login.ts, you probably also
	// want register.ts" — and it requires considering files that have no
	// other score yet.
	const candidates = new Set<string>(breakdowns.keys());
	for (const f of index.listFiles()) candidates.add(normalizeRel(f));
	for (const candidate of candidates) {
		let bestProx = 0;
		for (const openFile of input.openFiles) {
			const prox = sharedPrefixScore(candidate, normalizeRel(openFile));
			if (prox > bestProx) bestProx = prox;
		}
		// Also scan open file contents for textual references to this path's
		// basename. An imperfect import-graph proxy: it catches `import x from "./foo"`
		// and `require("./foo")` without parsing the AST.
		if (input.openFileContents) {
			const base = path.basename(candidate).replace(/\.[^.]+$/, "");
			if (base.length >= 3) {
				for (const [openPath, content] of Object.entries(input.openFileContents)) {
					if (normalizeRel(openPath) === candidate) continue;
					if (content.includes(base)) {
						bestProx = Math.max(bestProx, 0.5);
						break;
					}
				}
			}
		}
		if (bestProx > 0) {
			touch(candidate, { proximity: bestProx });
		}
	}

	const k = input.k ?? 20;
	const results: RankResult[] = [];
	for (const [filePath, breakdown] of breakdowns) {
		const score =
			W_SEMANTIC * breakdown.semantic +
			W_OPEN * breakdown.openBoost +
			W_RECENCY * breakdown.recencyBoost +
			W_PROXIMITY * breakdown.proximity;
		if (score > 0) results.push({ filePath, score, breakdown });
	}
	results.sort((a, b) => b.score - a.score);
	return results.slice(0, k);
}

function normalizeRel(p: string): string {
	return p.replace(/\\/g, "/");
}

/**
 * Score for "how close" two paths are in the directory tree. Returns the
 * fraction of common leading path segments, capped at 1.0. Two files in the
 * same directory get 1.0; cousins in the same top-level package get a smaller
 * fraction.
 *
 * Worked example:
 *   sharedPrefixScore("src/auth/login.ts", "src/auth/register.ts")  → 2/3 ≈ 0.67
 *   sharedPrefixScore("src/auth/login.ts", "src/billing/charge.ts") → 1/3 ≈ 0.33
 *   sharedPrefixScore("src/auth/login.ts", "tests/auth/login.t.ts") → 0
 */
function sharedPrefixScore(a: string, b: string): number {
	if (a === b) return 0; // ignore self — we're ranking *other* files
	const aSeg = a.split("/");
	const bSeg = b.split("/");
	const minLen = Math.min(aSeg.length, bSeg.length);
	let shared = 0;
	for (let i = 0; i < minLen; i++) {
		if (aSeg[i] !== bSeg[i]) break;
		shared++;
	}
	const denom = Math.max(aSeg.length, bSeg.length);
	if (denom === 0) return 0;
	return shared / denom;
}
