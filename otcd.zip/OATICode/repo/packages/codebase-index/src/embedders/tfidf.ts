// R8-B: TF-IDF embedder wrapped under the EmbedderProvider interface.
//
// The existing `TfIdfEmbedder` in `../embedder.ts` already implements the
// thin `Embedder` interface. This adapter adds the metadata fields the host
// + UI need (id, displayName, dimensions) without changing the underlying
// math. Kept as the default so the index remains offline-capable.

import { TF_IDF_DIM, TfIdfEmbedder } from "../embedder";
import type { EmbedderProvider } from "./registry";

export class TfIdfEmbedderProvider implements EmbedderProvider {
	readonly id = "tfidf";
	readonly displayName = "Local TF-IDF (offline)";
	readonly dimensions: number;
	readonly dim: number;
	private readonly inner: TfIdfEmbedder;

	constructor(dim: number = TF_IDF_DIM) {
		this.dimensions = dim;
		this.dim = dim;
		this.inner = new TfIdfEmbedder(dim);
	}

	embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		return this.inner.embed(texts);
	}
}

/**
 * Factory wrapper kept symmetric with the remote-provider factories so the
 * host can dispatch on `EmbedderId` without special-casing tfidf.
 */
export function createTfIdfEmbedder(dim?: number): TfIdfEmbedderProvider {
	return new TfIdfEmbedderProvider(dim);
}
