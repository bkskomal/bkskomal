// R8-B: Voyage AI embeddings provider (`voyage-code-3`).
//
// Voyage's API mirrors OpenAI's shape closely but uses its own host and adds
// an `input_type` field that distinguishes "document" (indexing) from "query"
// (search). We bake in "document" for indexing calls; the reranker / query
// path passes `inputType: "query"` via the second arg. Default model is
// `voyage-code-3` (1024-dim), tuned for code retrieval.

import { l2Normalize } from "../embedder";
import type { EmbedderProvider, GetSecret } from "./registry";
import { SECRET_KEYS } from "./registry";

export interface VoyageEmbedderOptions {
	readonly model?: string;
	readonly dimensions?: number;
	readonly baseUrl?: string;
	readonly getSecret: GetSecret;
	readonly fetchImpl?: typeof fetch;
	/**
	 * Voyage distinguishes "document" (indexing) from "query" (search). The
	 * EmbedderProvider interface only has one `embed()` so we default to
	 * "document" — re-querying through the same instance is still meaningful
	 * because cosine on cross-typed vectors is well-defined, just slightly
	 * less accurate than a query-typed embed.
	 */
	readonly inputType?: "document" | "query";
}

interface VoyageEmbeddingsResponse {
	readonly data?: readonly { readonly embedding: readonly number[] }[];
	readonly detail?: string;
	readonly error?: string;
}

const DEFAULT_MODEL = "voyage-code-3";
const DEFAULT_DIMENSIONS = 1024;
const DEFAULT_BASE_URL = "https://api.voyageai.com/v1";

export class VoyageEmbedder implements EmbedderProvider {
	readonly id = "voyage";
	readonly displayName: string;
	readonly dimensions: number;
	readonly dim: number;
	private readonly model: string;
	private readonly url: string;
	private readonly inputType: "document" | "query";
	private readonly getSecret: GetSecret;
	private readonly fetchImpl: typeof fetch;
	private cachedKey: string | undefined;

	constructor(opts: VoyageEmbedderOptions) {
		this.model = opts.model ?? DEFAULT_MODEL;
		this.dimensions = opts.dimensions ?? DEFAULT_DIMENSIONS;
		this.dim = this.dimensions;
		this.displayName = `Voyage ${this.model}`;
		const base = (opts.baseUrl ?? DEFAULT_BASE_URL).replace(/\/$/, "");
		this.url = `${base}/embeddings`;
		this.inputType = opts.inputType ?? "document";
		this.getSecret = opts.getSecret;
		this.fetchImpl = opts.fetchImpl ?? fetch;
	}

	private async resolveKey(): Promise<string> {
		if (this.cachedKey) return this.cachedKey;
		const k = await this.getSecret(SECRET_KEYS.voyage);
		if (!k) {
			throw new Error(
				"Voyage embedder: API key not set. Run `OATI Code: Set Codebase Embedder API Key` to configure it.",
			);
		}
		this.cachedKey = k;
		return k;
	}

	async embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		if (texts.length === 0) return [];
		const apiKey = await this.resolveKey();
		const body: Record<string, unknown> = {
			model: this.model,
			input: [...texts],
			input_type: this.inputType,
			// Voyage v3+ supports the `output_dimension` field for adjustable dims.
			output_dimension: this.dimensions,
		};
		const res = await this.fetchImpl(this.url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`,
			},
			body: JSON.stringify(body),
		});
		if (!res.ok) {
			let detail = "";
			try {
				detail = (await res.text()).slice(0, 200);
			} catch {
				/* swallow */
			}
			throw new Error(`Voyage embeddings failed (${res.status}): ${detail}`);
		}
		const json = (await res.json()) as VoyageEmbeddingsResponse;
		if (json.error || json.detail) {
			throw new Error(`Voyage embeddings error: ${json.error ?? json.detail}`);
		}
		if (!json.data || json.data.length !== texts.length) {
			throw new Error(
				`Voyage embeddings: expected ${texts.length} vectors, got ${json.data?.length ?? 0}`,
			);
		}
		return json.data.map((d) => {
			const arr = new Float32Array(d.embedding.length);
			for (let i = 0; i < d.embedding.length; i++) arr[i] = d.embedding[i];
			l2Normalize(arr);
			return arr;
		});
	}
}

export function createVoyageEmbedder(opts: VoyageEmbedderOptions): VoyageEmbedder {
	return new VoyageEmbedder(opts);
}
