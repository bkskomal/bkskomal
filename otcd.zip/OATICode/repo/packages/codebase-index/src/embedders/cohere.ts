// R8-B: Cohere embeddings provider (`embed-english-v3.0`).
//
// Cohere's API differs from OpenAI's: `texts` (plural) instead of `input`,
// a required `input_type` field, and `embeddings` (plural) on the response
// shaped as either `embeddings: number[][]` (legacy) or
// `embeddings: { float: number[][] }` (v3, with the `embedding_types` knob).
// We always request `embedding_types: ["float"]` so the shape is predictable.

import { l2Normalize } from "../embedder";
import type { EmbedderProvider, GetSecret } from "./registry";
import { SECRET_KEYS } from "./registry";

export interface CohereEmbedderOptions {
	readonly model?: string;
	readonly dimensions?: number;
	readonly baseUrl?: string;
	readonly getSecret: GetSecret;
	readonly fetchImpl?: typeof fetch;
	/**
	 * Cohere requires this field. "search_document" for indexing, "search_query"
	 * for retrieval — same document/query split as Voyage. Defaults to
	 * "search_document" since the EmbedderProvider interface is single-mode.
	 */
	readonly inputType?: "search_document" | "search_query" | "classification" | "clustering";
}

interface CohereEmbeddingsResponse {
	readonly embeddings?:
		| readonly (readonly number[])[]
		| { readonly float?: readonly (readonly number[])[] };
	readonly message?: string;
}

const DEFAULT_MODEL = "embed-english-v3.0";
const DEFAULT_DIMENSIONS = 1024;
const DEFAULT_BASE_URL = "https://api.cohere.com/v1";

export class CohereEmbedder implements EmbedderProvider {
	readonly id = "cohere";
	readonly displayName: string;
	readonly dimensions: number;
	readonly dim: number;
	private readonly model: string;
	private readonly url: string;
	private readonly inputType: "search_document" | "search_query" | "classification" | "clustering";
	private readonly getSecret: GetSecret;
	private readonly fetchImpl: typeof fetch;
	private cachedKey: string | undefined;

	constructor(opts: CohereEmbedderOptions) {
		this.model = opts.model ?? DEFAULT_MODEL;
		this.dimensions = opts.dimensions ?? DEFAULT_DIMENSIONS;
		this.dim = this.dimensions;
		this.displayName = `Cohere ${this.model}`;
		const base = (opts.baseUrl ?? DEFAULT_BASE_URL).replace(/\/$/, "");
		this.url = `${base}/embed`;
		this.inputType = opts.inputType ?? "search_document";
		this.getSecret = opts.getSecret;
		this.fetchImpl = opts.fetchImpl ?? fetch;
	}

	private async resolveKey(): Promise<string> {
		if (this.cachedKey) return this.cachedKey;
		const k = await this.getSecret(SECRET_KEYS.cohere);
		if (!k) {
			throw new Error(
				"Cohere embedder: API key not set. Run `OATI Code: Set Codebase Embedder API Key` to configure it.",
			);
		}
		this.cachedKey = k;
		return k;
	}

	async embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		if (texts.length === 0) return [];
		const apiKey = await this.resolveKey();
		const body: Record<string, unknown> = {
			model: this.model,
			texts: [...texts],
			input_type: this.inputType,
			embedding_types: ["float"],
		};
		const res = await this.fetchImpl(this.url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`,
			},
			body: JSON.stringify(body),
		});
		if (!res.ok) {
			let detail = "";
			try {
				detail = (await res.text()).slice(0, 200);
			} catch {
				/* swallow */
			}
			throw new Error(`Cohere embeddings failed (${res.status}): ${detail}`);
		}
		const json = (await res.json()) as CohereEmbeddingsResponse;
		if (json.message && !json.embeddings) {
			throw new Error(`Cohere embeddings error: ${json.message}`);
		}
		const vectors = extractVectors(json.embeddings);
		if (!vectors || vectors.length !== texts.length) {
			throw new Error(
				`Cohere embeddings: expected ${texts.length} vectors, got ${vectors?.length ?? 0}`,
			);
		}
		return vectors.map((v) => {
			const arr = new Float32Array(v.length);
			for (let i = 0; i < v.length; i++) arr[i] = v[i];
			l2Normalize(arr);
			return arr;
		});
	}
}

function extractVectors(
	raw:
		| readonly (readonly number[])[]
		| { readonly float?: readonly (readonly number[])[] }
		| undefined,
): readonly (readonly number[])[] | undefined {
	if (!raw) return undefined;
	if (Array.isArray(raw)) return raw;
	if (typeof raw === "object" && "float" in raw && Array.isArray(raw.float)) return raw.float;
	return undefined;
}

export function createCohereEmbedder(opts: CohereEmbedderOptions): CohereEmbedder {
	return new CohereEmbedder(opts);
}
