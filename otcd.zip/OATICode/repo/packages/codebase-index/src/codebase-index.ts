import { promises as fs } from "node:fs";
import * as path from "node:path";
import type { SymbolLookupProvider } from "@oati/shared";
import { type Chunk, chunkContentSmart, languageForPath } from "./chunker";
import { type Embedder, TfIdfEmbedder, cosineSimilarity } from "./embedder";
import { contentHash } from "./hash";
import { IndexStore } from "./index-store";
// R8-B: LLM-as-reranker (opt-in via SearchOptions.rerank).
import { LLMReranker, type RerankCandidate, type RerankerOptions } from "./reranker";
// Phase 1.1 (2026-05-23): Reciprocal Rank Fusion for hybrid semantic +
// lexical retrieval. Opt-in via SearchOptions.lexicalQuery — when a
// caller supplies a lexical ranking (typically ripgrep-backed) we run
// both rankings, collapse to file-level, and merge via RRF before
// reranking. Pure addition: when `lexicalQuery` is undefined the path
// is identical to pre-1.1 behaviour.
import { collapseToFileLevel, rrfMerge } from "./rrf-merge";
import { buildSymbolGraphHop, symbolGraphBoost } from "./symbol-graph";
import { walkWorkspace } from "./walker";

/** Indexing progress event payload. */
export interface IndexProgress {
	readonly done: number;
	readonly total: number;
	readonly file?: string;
}

export interface IndexAllOptions {
	readonly onProgress?: (p: IndexProgress) => void;
}

export interface IndexAllResult {
	readonly indexed: number;
	readonly skipped: number;
}

export interface SearchOptions {
	readonly k?: number;
	readonly filter?: {
		readonly extensions?: readonly string[];
	};
	/**
	 * Apply a small multiplicative boost (×1.2 by default) to chunks living in
	 * files that are one hop away in the symbol graph from a symbol referenced
	 * by the query. Defaults to `true` when both a `symbols` provider and a
	 * seed are available, no-op otherwise. APPENDED in R3-A.
	 */
	readonly symbolGraphBoost?: boolean;
	/** Optional symbols provider used to walk one hop for the boost. */
	readonly symbols?: SymbolLookupProvider;
	/**
	 * Optional seed for the symbol-graph hop. When omitted we skip the walk —
	 * we don't try to re-derive a symbol from the natural-language query, that
	 * would need its own resolver and is out of scope for this re-rank pass.
	 */
	readonly symbolSeed?: {
		readonly path: string;
		readonly line: number;
		readonly character: number;
		readonly symbol: string;
	};
	// R8-B: opt-in LLM-as-reranker. When `rerank` is non-null, the top-N
	// embedding hits are re-scored by the active LLM before the final top-k
	// is returned. See `reranker.ts` for the contract.
	readonly rerank?: {
		readonly callLlm: RerankerOptions["callLlm"];
		readonly maxCandidates?: number;
		readonly snippetCharCap?: number;
		readonly signal?: AbortSignal;
	};
	/**
	 * Phase 1.1: optional lexical-ranking callback for hybrid retrieval.
	 * When provided, we run lexical search in parallel with the semantic
	 * ranking and merge via Reciprocal Rank Fusion (file-level) before
	 * the optional rerank step.
	 *
	 * The callback is expected to wrap whatever lexical primitive the
	 * host has — ripgrep, VS Code workspace search, etc. — and return
	 * results in `SearchResult` shape (file/line span + content +
	 * arbitrary score). The score isn't read by RRF; only the order
	 * matters. Errors propagate; if you want best-effort, swallow them
	 * inside the callback and return `[]`.
	 *
	 * Pre-merge collapse to file-level handles the impedance mismatch
	 * between lexical (line-level matches) and semantic (chunk-level
	 * matches) — both rankings collapse to "best result per file" so a
	 * file that appears in both gets the RRF amplification it deserves.
	 */
	readonly lexicalQuery?: (query: string) => Promise<readonly SearchResult[]>;
	/**
	 * Phase 1.1: weights for the two RRF input rankings, [semantic, lexical].
	 * Default [1, 1] — equal voice. Bump the semantic weight when you
	 * trust the embedder; bump the lexical weight when you trust the
	 * pattern (e.g., the query is in quotes or contains identifiers).
	 * Ignored when `lexicalQuery` is undefined.
	 */
	readonly hybridWeights?: readonly [number, number];
}

export interface SearchResult {
	readonly filePath: string;
	readonly startLine: number;
	readonly endLine: number;
	readonly content: string;
	readonly score: number;
}

export interface CodebaseIndexOptions {
	readonly workspaceRoot: string;
	readonly dbPath: string;
	readonly embedder: Embedder;
}

const DEFAULT_K = 10;

/**
 * Workspace-scoped semantic search index.
 *
 * Lifecycle:
 *   - Construct → opens (or creates) the SQLite DB at `dbPath`.
 *   - `indexAll()` walks the workspace, chunks each file, embeds new/changed
 *     chunks, and removes vectors for files that disappeared.
 *   - `query(text)` embeds the query and scores every stored vector against it
 *     (brute force — fast enough at <100k chunks).
 *   - `indexFile(abs)` / `invalidate(abs)` keep the index hot when a single
 *     file changes (called from the host's file-system watcher).
 *
 * The class is single-threaded; concurrent `indexAll` calls will compete on
 * the same SQLite handle. Higher layers should serialize via a mutex if they
 * want parallel writes (none today).
 */
export class CodebaseIndex {
	private readonly store: IndexStore;
	private readonly workspaceRoot: string;
	private readonly embedder: Embedder;

	constructor(opts: CodebaseIndexOptions) {
		this.workspaceRoot = path.resolve(opts.workspaceRoot);
		this.embedder = opts.embedder;
		// R8-B: forward the embedder id (when the underlying object implements
		// EmbedderProvider) so the store can persist it for the reindex prompt.
		const id = (opts.embedder as { id?: string }).id;
		this.store = new IndexStore(opts.dbPath, opts.embedder.dim, id);
	}

	/**
	 * Walk the workspace and index every indexable file. Files unchanged since
	 * the previous run are detected by content_hash and skipped (no embedding
	 * call). Returns counters so the UI can report meaningful progress.
	 */
	async indexAll(opts: IndexAllOptions = {}): Promise<IndexAllResult> {
		const files: string[] = [];
		for (const abs of walkWorkspace(this.workspaceRoot)) files.push(abs);
		const seenFiles = new Set<string>();
		let indexed = 0;
		let skipped = 0;
		for (let i = 0; i < files.length; i++) {
			const abs = files[i];
			seenFiles.add(this.relPath(abs));
			opts.onProgress?.({ done: i, total: files.length, file: this.relPath(abs) });
			const result = await this.indexFileInternal(abs);
			indexed += result.indexed;
			skipped += result.skipped;
		}
		opts.onProgress?.({ done: files.length, total: files.length });
		// Prune chunks belonging to files that no longer exist on disk. We compare
		// against the full set we just walked so deleted files are cleaned up in
		// the same pass.
		this.pruneMissingFiles(seenFiles);
		return { indexed, skipped };
	}

	/** Index (or re-index) a single file. Path may be absolute or workspace-relative. */
	async indexFile(absOrRelPath: string): Promise<void> {
		const abs = this.absPath(absOrRelPath);
		await this.indexFileInternal(abs);
	}

	/** Drop all chunks for the given file. Used when a file is deleted on disk. */
	async invalidate(absOrRelPath: string): Promise<void> {
		const rel = this.relPath(this.absPath(absOrRelPath));
		this.store.deleteFile(rel);
	}

	/**
	 * Semantic search. Embeds the query, then computes cosine similarity against
	 * every stored vector. The top `k` results are returned in descending order.
	 *
	 * Brute force is O(N·dim) but the constants are tiny in JS (Float32Array dot
	 * products run at memory bandwidth) and it dominates an HNSW index up to
	 * ~50k chunks. Worth revisiting only when users start indexing monorepos
	 * with hundreds of thousands of chunks.
	 */
	async query(text: string, opts: SearchOptions = {}): Promise<SearchResult[]> {
		const k = opts.k ?? DEFAULT_K;
		if (!text.trim()) return [];
		const [queryVec] = await this.embedder.embed([text]);
		if (!queryVec) return [];
		const extensions = opts.filter?.extensions?.map((e) => e.toLowerCase().replace(/^\./, ""));

		// Symbol-graph re-rank prep. Run the LSP hop *before* scoring so the
		// boost is just a multiplicative pass over results — keeps the hot loop
		// the same shape it was before. Default ON when both a provider and a
		// seed are supplied; explicitly disabled when opts.symbolGraphBoost is
		// false. We never derive the seed ourselves — see SearchOptions.
		const boostEnabled = opts.symbolGraphBoost ?? true;
		let neighbors: ReadonlySet<string> = new Set();
		if (boostEnabled && opts.symbols && opts.symbolSeed) {
			try {
				const hop = await buildSymbolGraphHop(
					opts.symbols,
					opts.symbolSeed.path,
					opts.symbolSeed.line,
					opts.symbolSeed.character,
					opts.symbolSeed.symbol,
				);
				neighbors = hop.neighbors;
			} catch {
				// Re-rank is best-effort.
			}
		}

		const all = this.store.all();
		const scored: SearchResult[] = [];
		for (const row of all) {
			if (extensions && extensions.length > 0) {
				const dot = row.filePath.toLowerCase().lastIndexOf(".");
				if (dot < 0) continue;
				const ext = row.filePath.toLowerCase().slice(dot + 1);
				if (!extensions.includes(ext)) continue;
			}
			const base = cosineSimilarity(queryVec, row.vector);
			const score = base * symbolGraphBoost(row.filePath, neighbors);
			scored.push({
				filePath: row.filePath,
				startLine: row.startLine,
				endLine: row.endLine,
				content: row.content,
				score,
			});
		}
		scored.sort((a, b) => b.score - a.score);

		// Phase 1.1: hybrid semantic + lexical via RRF. We run the lexical
		// callback in parallel with the semantic work above ideally — but
		// the simpler shape here (after the semantic loop) is honest about
		// what's actually concurrent and keeps the diff small. Most
		// lexical implementations (ripgrep) finish in tens of ms anyway;
		// the wall time difference is negligible relative to the embed
		// step. Collapse each ranking to its best entry per file BEFORE
		// merging — see `SearchOptions.lexicalQuery` for the rationale.
		let candidates: SearchResult[] = scored;
		if (opts.lexicalQuery) {
			let lexical: readonly SearchResult[] = [];
			try {
				lexical = await opts.lexicalQuery(text);
			} catch {
				// Lexical is best-effort. If it throws, hybrid degrades to
				// pure semantic. Better than failing the whole query.
			}
			if (lexical.length > 0) {
				const semFileLevel = collapseToFileLevel(scored);
				const lexFileLevel = collapseToFileLevel(lexical);
				const weights = opts.hybridWeights ?? ([1, 1] as const);
				const merged = rrfMerge<SearchResult>([semFileLevel, lexFileLevel], {
					weights: [weights[0], weights[1]],
				});
				candidates = merged.map((m) => ({
					filePath: m.payload.filePath,
					startLine: m.payload.startLine,
					endLine: m.payload.endLine,
					content: m.payload.content,
					// RRF scores are tiny (~0.01–0.03). The downstream code only
					// reads `score` for display, so we preserve the magnitude as
					// emitted by RRF — the relative ordering is the point.
					score: m.score,
				}));
			}
		}

		// R8-B: optional LLM-as-reranker. We rerank a wider top-N (caller-defined
		// `maxCandidates`, default 20) then truncate to the user-requested `k`.
		// This is the same gap-closing trick Cursor uses to lift coarse vector
		// search to "what the user actually wants".
		if (opts.rerank) {
			const max = opts.rerank.maxCandidates ?? 20;
			const head = candidates.slice(0, Math.max(k, max));
			const reranker = new LLMReranker({
				callLlm: opts.rerank.callLlm,
				...(opts.rerank.maxCandidates !== undefined
					? { maxCandidates: opts.rerank.maxCandidates }
					: {}),
				...(opts.rerank.snippetCharCap !== undefined
					? { snippetCharCap: opts.rerank.snippetCharCap }
					: {}),
				...(opts.rerank.signal ? { signal: opts.rerank.signal } : {}),
			});
			const rerankInput: RerankCandidate[] = head.map((h) => ({
				filePath: h.filePath,
				startLine: h.startLine,
				endLine: h.endLine,
				content: h.content,
				score: h.score,
			}));
			const reranked = await reranker.rerank(text, rerankInput);
			return reranked.slice(0, k).map((r) => ({
				filePath: r.filePath,
				startLine: r.startLine,
				endLine: r.endLine,
				content: r.content,
				score: r.rerankScore,
			}));
		}
		return candidates.slice(0, k);
	}

	/** Number of chunks/files currently indexed. */
	stats(): { chunks: number; files: number } {
		return this.store.stats();
	}

	// R8-B: expose the embedder id + dimensions actually used to build the
	// current SQLite index so the host can label the webview pill and detect
	// "user changed embedder; reindex required".
	getEmbedderInfo(): { readonly id: string | undefined; readonly dim: number } {
		return { id: this.store.getEmbedderId(), dim: this.store.getDim() };
	}

	/**
	 * Distinct file paths currently in the index. Used by the ranker to seed
	 * its candidate set when proximity/recency boosts should apply even though
	 * no semantic hit landed for the file. Returns workspace-relative paths.
	 */
	listFiles(): string[] {
		// `store.all()` returns one row per chunk; collapse to a set of paths.
		// Not the cheapest call but the ranker is invoked at-most a few times
		// per second (autocomplete focus + each agent turn).
		const seen = new Set<string>();
		for (const row of this.store.all()) seen.add(row.filePath);
		return [...seen];
	}

	close(): void {
		this.store.close();
	}

	private async indexFileInternal(abs: string): Promise<{ indexed: number; skipped: number }> {
		const rel = this.relPath(abs);
		let content: string;
		try {
			content = await fs.readFile(abs, "utf-8");
		} catch {
			// File vanished between walk and read, or it's a binary we can't decode.
			// Drop any old chunks for it so we don't keep serving stale data.
			this.store.deleteFile(rel);
			return { indexed: 0, skipped: 0 };
		}
		const language = languageForPath(rel);
		// R4-A: switched from sync `chunkContent` to async `chunkContentSmart`
		// so TS/JS/Python/Go/Rust go through the tree-sitter chunker when
		// the bundled grammar is available. The smart variant silently falls
		// back to the regex chunker on miss, so behavior degrades gracefully
		// in dev/test where grammars aren't always present.
		const chunks = await chunkContentSmart(content, language);
		if (chunks.length === 0) {
			this.store.deleteFile(rel);
			return { indexed: 0, skipped: 0 };
		}

		// Compute hashes up front so we can short-circuit unchanged chunks before
		// paying for an embedding call. Existing chunks at the same (file, lines)
		// with the same hash are no-ops in `store.upsert`.
		const hashes = chunks.map((c) => contentHash(c.content));
		const existing = new Map<string, string>();
		for (const row of this.store.listForFile(rel)) {
			existing.set(coordKey(row.startLine, row.endLine), row.contentHash);
		}

		// Decide which chunks need new embeddings. If the file's chunk
		// boundaries have shifted (deletions, large edits), we wipe the file's
		// rows and re-embed from scratch. Otherwise we re-embed only the chunks
		// whose content_hash changed — preserves cache hits on append-mostly
		// edits, which dominate real-world editing patterns.
		const newCoords = new Set(chunks.map((c) => coordKey(c.startLine, c.endLine)));
		const hasStaleCoords = [...existing.keys()].some((k) => !newCoords.has(k));

		const toEmbed: { chunk: Chunk; hash: string }[] = [];
		if (hasStaleCoords) {
			this.store.deleteFile(rel);
			for (let i = 0; i < chunks.length; i++) {
				toEmbed.push({ chunk: chunks[i], hash: hashes[i] });
			}
		} else {
			for (let i = 0; i < chunks.length; i++) {
				const c = chunks[i];
				const key = coordKey(c.startLine, c.endLine);
				if (existing.get(key) === hashes[i]) continue;
				toEmbed.push({ chunk: c, hash: hashes[i] });
			}
		}

		if (toEmbed.length === 0) {
			return { indexed: 0, skipped: chunks.length };
		}

		const vectors = await this.embedder.embed(toEmbed.map((t) => t.chunk.content));
		let indexed = 0;
		for (let i = 0; i < toEmbed.length; i++) {
			const t = toEmbed[i];
			const v = vectors[i];
			if (!v) continue;
			if (this.store.upsert(rel, t.chunk.startLine, t.chunk.endLine, t.chunk.content, t.hash, v)) {
				indexed++;
			}
		}
		return { indexed, skipped: chunks.length - toEmbed.length };
	}

	private pruneMissingFiles(seen: Set<string>): void {
		const stats = this.store.all();
		const known = new Set(stats.map((r) => r.filePath));
		for (const f of known) {
			if (!seen.has(f)) this.store.deleteFile(f);
		}
	}

	private absPath(p: string): string {
		return path.isAbsolute(p) ? p : path.join(this.workspaceRoot, p);
	}

	private relPath(abs: string): string {
		const rel = path.relative(this.workspaceRoot, abs);
		return rel.replace(/\\/g, "/");
	}
}

/**
 * Default factory: if no embedder is provided, fall back to TF-IDF. This is
 * the path the extension host takes when the active provider doesn't expose
 * `/v1/embeddings`, so the index is always usable.
 */
export function createDefaultIndex(workspaceRoot: string, dbPath: string): CodebaseIndex {
	return new CodebaseIndex({
		workspaceRoot,
		dbPath,
		embedder: new TfIdfEmbedder(),
	});
}

function coordKey(start: number, end: number): string {
	return `${start}:${end}`;
}
