// R8-B: LLM-as-reranker.
//
// First-pass retrieval (embedding cosine + symbol-graph boost) returns a
// candidate set. The reranker asks the active LLM to score each candidate's
// relevance to the query on a 0-10 scale via a single one-shot call, then
// returns the candidates sorted by that score. This is the same trick Cursor
// uses to close the gap between coarse vector search and what the user
// actually wants.
//
// Cost / latency notes:
//   - One LLM call per `rerank()` (not per candidate). The prompt asks for
//     scores in a compact `id:score` form.
//   - Top-20 candidates only. Each snippet truncated to 200 chars in the
//     prompt so the rerank call stays well under any model's context window.
//   - On parse failure the reranker degrades gracefully — we return the
//     input order so the user still gets *something* back.

export interface RerankCandidate {
	readonly filePath: string;
	readonly startLine: number;
	readonly endLine: number;
	readonly content: string;
	readonly score: number;
}

export interface RerankResult extends RerankCandidate {
	/** LLM-assigned relevance score in [0, 10]. */
	readonly rerankScore: number;
}

/**
 * Minimal LLM-call shape the reranker depends on. The host wires this to the
 * active `ProviderSpec.stream()` and accumulates the text deltas; we keep the
 * interface plain (string in, string out) so the reranker is provider-agnostic
 * and trivially testable.
 */
export type LlmCallFn = (prompt: string, signal?: AbortSignal) => Promise<string>;

export interface RerankerOptions {
	readonly callLlm: LlmCallFn;
	/** Cap on candidates sent to the LLM. Default 20. */
	readonly maxCandidates?: number;
	/** Per-snippet truncation in the rerank prompt. Default 200 chars. */
	readonly snippetCharCap?: number;
	/** Abort the rerank call if it hangs. */
	readonly signal?: AbortSignal;
}

const DEFAULT_MAX = 20;
const DEFAULT_SNIPPET_CAP = 200;

/**
 * Re-rank a candidate list using an LLM. Returns the candidates sorted by the
 * LLM-assigned `rerankScore` in descending order. Candidates beyond
 * `maxCandidates` are dropped from the call but preserved at the tail of the
 * result (with their original embedding score) so the caller still sees them.
 */
export class LLMReranker {
	private readonly callLlm: LlmCallFn;
	private readonly maxCandidates: number;
	private readonly snippetCharCap: number;
	private readonly signal: AbortSignal | undefined;

	constructor(opts: RerankerOptions) {
		this.callLlm = opts.callLlm;
		this.maxCandidates = opts.maxCandidates ?? DEFAULT_MAX;
		this.snippetCharCap = opts.snippetCharCap ?? DEFAULT_SNIPPET_CAP;
		this.signal = opts.signal;
	}

	async rerank(query: string, candidates: readonly RerankCandidate[]): Promise<RerankResult[]> {
		if (candidates.length === 0) return [];
		const head = candidates.slice(0, this.maxCandidates);
		const tail = candidates.slice(this.maxCandidates);
		const prompt = buildPrompt(query, head, this.snippetCharCap);

		let raw: string;
		try {
			raw = await this.callLlm(prompt, this.signal);
		} catch {
			// Degrade gracefully on transport errors — return embedding order.
			return [
				...head.map((c) => ({ ...c, rerankScore: c.score })),
				...tail.map((c) => ({ ...c, rerankScore: c.score })),
			];
		}

		const scores = parseScores(raw, head.length);
		const reranked: RerankResult[] = head.map((c, i) => ({
			...c,
			// Fall back to the embedding score when the model skipped a row.
			rerankScore: scores[i] ?? c.score,
		}));
		reranked.sort((a, b) => b.rerankScore - a.rerankScore);
		// Tail keeps its original ordering but with its original score doubled
		// as `rerankScore` so a "0/10" reranked hit still beats nothing.
		const tailResults: RerankResult[] = tail.map((c) => ({ ...c, rerankScore: c.score }));
		return [...reranked, ...tailResults];
	}
}

/**
 * Build the rerank prompt. The format is deliberately compact so the model's
 * reply stays short — one number per candidate, separated by newlines or
 * commas. The system instructions live inline so we don't depend on the
 * provider's `systemPrompt` field (Anthropic / OpenAI / Voyage all phrase it
 * differently).
 */
export function buildPrompt(
	query: string,
	candidates: readonly RerankCandidate[],
	snippetCharCap: number,
): string {
	const lines: string[] = [];
	lines.push(
		"You are a code-search reranker. Score how relevant each candidate snippet is to the user's query on a 0-10 integer scale (10 = highly relevant; 0 = unrelated).",
		"",
		"Reply with EXACTLY one line per candidate, in the format `<id>:<score>` (e.g. `3:7`). Do not include any other text, prose, or commentary.",
		"",
		`Query: ${query}`,
		"",
		"Candidates:",
	);
	for (let i = 0; i < candidates.length; i++) {
		const c = candidates[i];
		const snippet = truncate(c.content, snippetCharCap);
		lines.push(`--- [${i + 1}] ${c.filePath}:${c.startLine}-${c.endLine} ---`, snippet);
	}
	lines.push("", "Scores:");
	return lines.join("\n");
}

function truncate(s: string, cap: number): string {
	if (s.length <= cap) return s;
	return `${s.slice(0, cap)}…`;
}

/**
 * Parse the LLM's reply. Accepts `<id>:<score>` (one per line OR comma /
 * whitespace separated). Robust to a trailing prose summary the model might
 * tack on. Returns a parallel array of scores aligned to the candidate index;
 * missing entries are returned as `undefined`.
 */
export function parseScores(raw: string, count: number): readonly (number | undefined)[] {
	const out: (number | undefined)[] = new Array(count).fill(undefined);
	// Match every `digit(s):digit(s)` pair (with optional decimal on the score).
	const pairRe = /(\d{1,3})\s*[:=]\s*(\d{1,3}(?:\.\d+)?)/g;
	let m: RegExpExecArray | null;
	for (m = pairRe.exec(raw); m !== null; m = pairRe.exec(raw)) {
		const id = Number.parseInt(m[1], 10);
		const score = Number.parseFloat(m[2]);
		if (!Number.isFinite(score)) continue;
		// Candidates were emitted 1-indexed in the prompt.
		const idx = id - 1;
		if (idx >= 0 && idx < count) {
			// Clamp to [0, 10] — some models emit 11 or "10.5" out of enthusiasm.
			out[idx] = Math.max(0, Math.min(10, score));
		}
	}
	return out;
}
