/**
 * 2026-06-01: regex-based top-level symbol extractor for repo-map
 * generation (Aider-style). Trades tree-sitter precision for zero
 * dependencies and ~10× speed — for a repo-map's purpose (orienting the
 * model with "what exists where") that's the right trade. False
 * positives produce a wrong line number; false negatives lose a symbol.
 * Both are recoverable: the model can always read_file to drill in.
 *
 * Languages covered: TS/JS, Python, C# (.NET), Go, Rust, Java, Ruby.
 * Markdown gets a special-case "first H1" extract because READMEs / docs
 * are valuable repo-map entries.
 */

export interface ExtractedSymbol {
	readonly kind: "function" | "class" | "interface" | "type" | "const" | "enum" | "heading";
	readonly name: string;
	/** 1-indexed line number where the symbol's declaration starts. */
	readonly line: number;
	/** True when the declaration carries an explicit `export` keyword (TS/JS) or visibility hint elsewhere. */
	readonly exported?: boolean;
}

export function extractSymbols(content: string, language: string): ExtractedSymbol[] {
	const lang = language.toLowerCase();
	if (lang === "typescript" || lang === "javascript" || lang === "tsx" || lang === "jsx") {
		return extractTsJs(content);
	}
	if (lang === "python") return extractPython(content);
	if (lang === "csharp" || lang === "c#" || lang === "cs") return extractCSharp(content);
	if (lang === "go") return extractGo(content);
	if (lang === "rust") return extractRust(content);
	if (lang === "java") return extractJava(content);
	if (lang === "ruby") return extractRuby(content);
	if (lang === "markdown" || lang === "md") return extractMarkdown(content);
	return [];
}

// Map a file extension to a language tag the extractor understands.
export function languageForExtension(ext: string): string | undefined {
	const e = ext.toLowerCase().replace(/^\./, "");
	const map: Record<string, string> = {
		ts: "typescript",
		tsx: "tsx",
		js: "javascript",
		jsx: "jsx",
		mjs: "javascript",
		cjs: "javascript",
		py: "python",
		cs: "csharp",
		go: "go",
		rs: "rust",
		java: "java",
		rb: "ruby",
		md: "markdown",
	};
	return map[e];
}

function lineOf(content: string, offset: number): number {
	let line = 1;
	for (let i = 0; i < offset && i < content.length; i++) {
		if (content.charCodeAt(i) === 10) line++;
	}
	return line;
}

function extractTsJs(content: string): ExtractedSymbol[] {
	const out: ExtractedSymbol[] = [];
	// Combined pattern — capture either the `export?` prefix + the declaration.
	const patterns: { re: RegExp; kind: ExtractedSymbol["kind"] }[] = [
		{ re: /^[ \t]*(export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)/gm, kind: "function" },
		{ re: /^[ \t]*(export\s+)?class\s+([A-Za-z_$][\w$]*)/gm, kind: "class" },
		{ re: /^[ \t]*(export\s+)?interface\s+([A-Za-z_$][\w$]*)/gm, kind: "interface" },
		{ re: /^[ \t]*(export\s+)?type\s+([A-Za-z_$][\w$]*)\s*=/gm, kind: "type" },
		{ re: /^[ \t]*(export\s+)?enum\s+([A-Za-z_$][\w$]*)/gm, kind: "enum" },
		// const arrow functions and top-level const declarations.
		{
			re: /^[ \t]*(export\s+)?const\s+([A-Za-z_$][\w$]*)\s*(?::|=)/gm,
			kind: "const",
		},
	];
	for (const { re, kind } of patterns) {
		re.lastIndex = 0;
		let m: RegExpExecArray | null = re.exec(content);
		while (m !== null) {
			out.push({
				kind,
				name: m[2],
				line: lineOf(content, m.index),
				exported: Boolean(m[1]),
			});
			m = re.exec(content);
		}
	}
	return dedupeAndSort(out);
}

function extractPython(content: string): ExtractedSymbol[] {
	const out: ExtractedSymbol[] = [];
	const fn = /^[ \t]*(?:async\s+)?def\s+([A-Za-z_][\w]*)/gm;
	const cls = /^[ \t]*class\s+([A-Za-z_][\w]*)/gm;
	let m = fn.exec(content);
	while (m !== null) {
		out.push({
			kind: "function",
			name: m[1],
			line: lineOf(content, m.index),
			exported: !m[1].startsWith("_"),
		});
		m = fn.exec(content);
	}
	m = cls.exec(content);
	while (m !== null) {
		out.push({
			kind: "class",
			name: m[1],
			line: lineOf(content, m.index),
			exported: !m[1].startsWith("_"),
		});
		m = cls.exec(content);
	}
	return dedupeAndSort(out);
}

function extractCSharp(content: string): ExtractedSymbol[] {
	const out: ExtractedSymbol[] = [];
	// Class / interface / record / struct / enum
	const decl =
		/^[ \t]*(?:public|internal|private|protected)?\s*(?:static\s+|abstract\s+|sealed\s+|partial\s+)*(class|interface|record|struct|enum)\s+([A-Za-z_][\w]*)/gm;
	let m = decl.exec(content);
	while (m !== null) {
		const kind = m[1] === "interface" ? "interface" : m[1] === "enum" ? "enum" : "class";
		out.push({ kind, name: m[2], line: lineOf(content, m.index), exported: true });
		m = decl.exec(content);
	}
	// Methods — `public/internal/private/protected/static? ReturnType Name(...)`
	const method =
		/^[ \t]*(?:public|internal|private|protected)?\s*(?:static\s+|virtual\s+|override\s+|async\s+|abstract\s+)*(?:[A-Za-z_][\w<>?,.\s]*?)\s+([A-Za-z_][\w]*)\s*\(/gm;
	m = method.exec(content);
	while (m !== null) {
		// Filter out obvious noise — constructors look like `public ClassName(` and
		// we lose them harmlessly because the preceding type token is missing in
		// our regex match, but `if/for/while/switch/foreach/using/return/etc.`
		// can leak through. Skip keywords.
		const name = m[1];
		if (CS_KEYWORDS.has(name)) {
			m = method.exec(content);
			continue;
		}
		out.push({ kind: "function", name, line: lineOf(content, m.index), exported: true });
		m = method.exec(content);
	}
	return dedupeAndSort(out);
}

const CS_KEYWORDS = new Set([
	"if",
	"for",
	"foreach",
	"while",
	"switch",
	"using",
	"return",
	"new",
	"throw",
	"catch",
	"try",
	"lock",
	"do",
	"else",
]);

function extractGo(content: string): ExtractedSymbol[] {
	const out: ExtractedSymbol[] = [];
	const fn = /^func\s+(?:\([^)]+\)\s*)?([A-Za-z_][\w]*)/gm;
	const type = /^type\s+([A-Za-z_][\w]*)\s+(struct|interface|[A-Za-z_])/gm;
	let m = fn.exec(content);
	while (m !== null) {
		const name = m[1];
		out.push({
			kind: "function",
			name,
			line: lineOf(content, m.index),
			exported: /^[A-Z]/.test(name),
		});
		m = fn.exec(content);
	}
	m = type.exec(content);
	while (m !== null) {
		const name = m[1];
		const kind: ExtractedSymbol["kind"] =
			m[2] === "interface" ? "interface" : m[2] === "struct" ? "class" : "type";
		out.push({ kind, name, line: lineOf(content, m.index), exported: /^[A-Z]/.test(name) });
		m = type.exec(content);
	}
	return dedupeAndSort(out);
}

function extractRust(content: string): ExtractedSymbol[] {
	const out: ExtractedSymbol[] = [];
	const fn = /^[ \t]*(pub\s+)?(?:async\s+)?fn\s+([A-Za-z_][\w]*)/gm;
	const struct = /^[ \t]*(pub\s+)?struct\s+([A-Za-z_][\w]*)/gm;
	const enumRe = /^[ \t]*(pub\s+)?enum\s+([A-Za-z_][\w]*)/gm;
	const trait = /^[ \t]*(pub\s+)?trait\s+([A-Za-z_][\w]*)/gm;
	for (const [re, kind] of [
		[fn, "function"] as const,
		[struct, "class"] as const,
		[enumRe, "enum"] as const,
		[trait, "interface"] as const,
	]) {
		let m = re.exec(content);
		while (m !== null) {
			out.push({
				kind,
				name: m[2],
				line: lineOf(content, m.index),
				exported: Boolean(m[1]),
			});
			m = re.exec(content);
		}
	}
	return dedupeAndSort(out);
}

function extractJava(content: string): ExtractedSymbol[] {
	const out: ExtractedSymbol[] = [];
	const cls =
		/^[ \t]*(?:public|private|protected)?\s*(?:static\s+|abstract\s+|final\s+)*(class|interface|enum)\s+([A-Za-z_][\w]*)/gm;
	let m = cls.exec(content);
	while (m !== null) {
		const kind = m[1] === "interface" ? "interface" : m[1] === "enum" ? "enum" : "class";
		out.push({ kind, name: m[2], line: lineOf(content, m.index), exported: true });
		m = cls.exec(content);
	}
	return dedupeAndSort(out);
}

function extractRuby(content: string): ExtractedSymbol[] {
	const out: ExtractedSymbol[] = [];
	const cls = /^[ \t]*class\s+([A-Za-z_][\w:]*)/gm;
	const mod = /^[ \t]*module\s+([A-Za-z_][\w:]*)/gm;
	const def = /^[ \t]*def\s+([A-Za-z_?!=][\w?!=]*)/gm;
	let m = cls.exec(content);
	while (m !== null) {
		out.push({ kind: "class", name: m[1], line: lineOf(content, m.index), exported: true });
		m = cls.exec(content);
	}
	m = mod.exec(content);
	while (m !== null) {
		out.push({ kind: "class", name: m[1], line: lineOf(content, m.index), exported: true });
		m = mod.exec(content);
	}
	m = def.exec(content);
	while (m !== null) {
		out.push({ kind: "function", name: m[1], line: lineOf(content, m.index) });
		m = def.exec(content);
	}
	return dedupeAndSort(out);
}

function extractMarkdown(content: string): ExtractedSymbol[] {
	// Capture just the first H1 — repo maps want a label, not a TOC.
	const m = /^#\s+(.+)$/m.exec(content);
	if (!m) return [];
	return [{ kind: "heading", name: m[1].trim(), line: lineOf(content, m.index) }];
}

function dedupeAndSort(syms: ExtractedSymbol[]): ExtractedSymbol[] {
	const seen = new Set<string>();
	const out: ExtractedSymbol[] = [];
	for (const s of syms.sort((a, b) => a.line - b.line)) {
		const key = `${s.kind}:${s.name}:${s.line}`;
		if (seen.has(key)) continue;
		seen.add(key);
		out.push(s);
	}
	return out;
}
