/**
 * Heuristic source-code chunker.
 *
 * Tree-sitter would give us tighter boundaries but adds a native dep and ~10MB
 * of grammars for marginal recall improvement on the ranking task. A few
 * language-aware regexes get us most of the way there: split on top-level
 * `function`/`class`/`export` lines, fall back to fixed-size sliding windows for
 * files that don't match anything (markdown, configs, large data files).
 *
 * Chunk size targets ~40 lines / ~1500 chars — large enough to embed
 * meaningfully, small enough that 10-20 chunks fit in a model's reranking
 * context. We never produce a chunk larger than `MAX_CHUNK_CHARS`; oversize
 * functions get broken at line boundaries.
 */

/** Soft upper bound on chunk size. Embedders typically handle ~8k tokens; staying
 * well below that leaves headroom for prefix instructions and avoids truncation. */
export const MAX_CHUNK_CHARS = 4000;
/** Soft lower bound — chunks smaller than this are merged with neighbors. */
export const MIN_CHUNK_CHARS = 64;
/** Fallback sliding-window size when no language-specific boundary is found. */
export const SLIDING_WINDOW_LINES = 40;
/** Don't try to chunk files bigger than this (binary blobs, minified JS, generated SQL). */
export const MAX_FILE_BYTES = 1_500_000;

export interface Chunk {
	readonly startLine: number; // 1-based, inclusive
	readonly endLine: number; // 1-based, inclusive
	readonly content: string;
	/**
	 * Optional symbol name for the chunk. Populated by the tree-sitter chunker
	 * (top-level function/class/method name); left undefined for chunks emitted
	 * by the regex/sliding-window fallback. Downstream ranking uses this when
	 * present as a tie-breaker / boost signal. APPENDED in R3-A.
	 */
	readonly symbolName?: string;
}

/** Language families we recognize. Anything unmapped falls back to `text`. */
export type Language =
	| "ts"
	| "js"
	| "py"
	| "go"
	| "rs"
	| "java"
	| "cs"
	| "rb"
	| "php"
	| "cpp"
	| "c"
	| "kt"
	| "swift"
	| "scala"
	| "lua"
	| "sh"
	| "md"
	| "json"
	| "yaml"
	| "toml"
	| "html"
	| "css"
	| "sql"
	| "text";

/**
 * Map file extension to a language family. The mapping is intentionally narrow:
 * unrecognized extensions get `text` which uses the sliding-window fallback,
 * which still produces reasonable chunks for novel formats.
 */
export function languageForPath(path: string): Language {
	const lower = path.toLowerCase();
	const dot = lower.lastIndexOf(".");
	if (dot < 0) return "text";
	const ext = lower.slice(dot + 1);
	switch (ext) {
		case "ts":
		case "tsx":
		case "mts":
		case "cts":
			return "ts";
		case "js":
		case "jsx":
		case "mjs":
		case "cjs":
			return "js";
		case "py":
		case "pyi":
			return "py";
		case "go":
			return "go";
		case "rs":
			return "rs";
		case "java":
			return "java";
		case "cs":
			return "cs";
		case "rb":
			return "rb";
		case "php":
			return "php";
		case "cpp":
		case "cxx":
		case "cc":
		case "hpp":
		case "hxx":
			return "cpp";
		case "c":
		case "h":
			return "c";
		case "kt":
		case "kts":
			return "kt";
		case "swift":
			return "swift";
		case "scala":
		case "sc":
			return "scala";
		case "lua":
			return "lua";
		case "sh":
		case "bash":
		case "zsh":
			return "sh";
		case "md":
		case "markdown":
			return "md";
		case "json":
			return "json";
		case "yaml":
		case "yml":
			return "yaml";
		case "toml":
			return "toml";
		case "html":
		case "htm":
			return "html";
		case "css":
		case "scss":
		case "less":
			return "css";
		case "sql":
			return "sql";
		default:
			return "text";
	}
}

/**
 * Per-language boundary regexes. Each regex is tested against a single line and
 * indicates "this line begins a new top-level declaration". A negative match
 * means the line is part of the current chunk.
 *
 * The patterns are deliberately permissive: missing a boundary is fine (chunk
 * just gets bigger and is split later by size), false positives are also fine
 * (an extra split rarely hurts recall).
 */
const BOUNDARY_PATTERNS: Readonly<Record<Language, readonly RegExp[]>> = {
	ts: [
		/^\s*(export\s+)?(async\s+)?function\s+\w+/,
		/^\s*(export\s+)?(abstract\s+)?class\s+\w+/,
		/^\s*(export\s+)?interface\s+\w+/,
		/^\s*(export\s+)?type\s+\w+\s*=/,
		/^\s*(export\s+)?enum\s+\w+/,
		/^\s*(export\s+)?const\s+\w+\s*=\s*(async\s+)?(\(|function)/,
	],
	js: [
		/^\s*(export\s+)?(async\s+)?function\s+\w+/,
		/^\s*(export\s+)?class\s+\w+/,
		/^\s*(export\s+)?const\s+\w+\s*=\s*(async\s+)?(\(|function)/,
	],
	py: [/^\s*def\s+\w+\s*\(/, /^\s*async\s+def\s+\w+\s*\(/, /^\s*class\s+\w+/],
	go: [/^\s*func\s+(\([^)]+\)\s+)?\w+\s*\(/, /^\s*type\s+\w+\s+(struct|interface)/],
	rs: [/^\s*(pub\s+)?(async\s+)?fn\s+\w+/, /^\s*(pub\s+)?(struct|enum|trait|impl)\s+\w+/],
	java: [
		/^\s*(public|protected|private|static|final|abstract|\s)+[\w<>\[\]]+\s+\w+\s*\(/,
		/^\s*(public|protected|private)?\s*(abstract\s+)?(class|interface|enum)\s+\w+/,
	],
	cs: [
		/^\s*(public|protected|private|internal|static|virtual|override|abstract|async|\s)+[\w<>\[\]]+\s+\w+\s*\(/,
		/^\s*(public|protected|private|internal)?\s*(static\s+)?(class|interface|struct|enum|record)\s+\w+/,
		/^\s*namespace\s+[\w.]+/,
	],
	rb: [/^\s*def\s+\w+/, /^\s*class\s+\w+/, /^\s*module\s+\w+/],
	php: [
		/^\s*(public|protected|private|static|\s)*function\s+\w+/,
		/^\s*(class|trait|interface)\s+\w+/,
	],
	cpp: [/^\s*[\w:~]+\s*\([^;]*$/, /^\s*(class|struct|namespace)\s+\w+/, /^\s*template\s*</],
	c: [/^\w[\w\s*]*\s+\*?\w+\s*\([^;]*$/, /^\s*(struct|enum|union)\s+\w+/],
	kt: [/^\s*(suspend\s+)?fun\s+\w+/, /^\s*(class|object|interface)\s+\w+/],
	swift: [/^\s*func\s+\w+/, /^\s*(class|struct|enum|protocol|extension)\s+\w+/],
	scala: [/^\s*def\s+\w+/, /^\s*(class|object|trait|case\s+class)\s+\w+/],
	lua: [/^\s*function\s+[\w.:]+/, /^\s*local\s+function\s+\w+/],
	sh: [/^\s*(function\s+)?\w+\s*\(\)\s*\{/],
	md: [/^#{1,3}\s+/],
	json: [],
	yaml: [/^\w[^:]*:\s*$/],
	toml: [/^\s*\[[^\]]+\]/],
	html: [/^\s*<(section|article|div|main|header|footer)\b/i],
	css: [/^\s*\.?\#?[\w-]+\s*\{?\s*$/, /^\s*@media\b/],
	sql: [/^\s*(CREATE|ALTER|DROP|INSERT|UPDATE|DELETE|SELECT)\b/i],
	text: [],
};

/**
 * Split `content` into chunks by language. Each chunk's `startLine`/`endLine`
 * refer to the original file (1-based, inclusive).
 *
 * Algorithm:
 *   1. If the content exceeds `MAX_FILE_BYTES`, return [] (skip indexing).
 *   2. Walk lines, accumulating into a buffer. A boundary line flushes the
 *      buffer (if non-trivial) before starting the new chunk.
 *   3. If the buffer grows past `MAX_CHUNK_CHARS`, split at line boundaries.
 *   4. After walking, post-process: merge runs of tiny chunks into neighbors so
 *      we don't waste vectors on 5-line snippets.
 *   5. If the language has no boundary patterns AND the file is bigger than
 *      `SLIDING_WINDOW_LINES`, fall back to a fixed window.
 */
export function chunkContent(content: string, language: Language): Chunk[] {
	if (content.length > MAX_FILE_BYTES) return [];
	if (content.length === 0) return [];

	const lines = content.split(/\r?\n/);
	const patterns = BOUNDARY_PATTERNS[language];
	const useBoundaries = patterns.length > 0;

	if (!useBoundaries) {
		return slidingWindow(lines);
	}

	const raw: Chunk[] = [];
	let bufStart = 1; // 1-based line index of the first line in the buffer
	let bufLines: string[] = [];
	let bufLen = 0;

	const flush = (endLine: number) => {
		if (bufLines.length === 0) return;
		const text = bufLines.join("\n");
		if (text.trim().length === 0) {
			bufLines = [];
			bufLen = 0;
			return;
		}
		raw.push({ startLine: bufStart, endLine, content: text });
		bufLines = [];
		bufLen = 0;
	};

	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		const lineNo = i + 1;
		const isBoundary = bufLines.length > 0 && patterns.some((p) => p.test(line));
		// Force a split when the current buffer is already chunk-sized — keeps
		// monster classes from collapsing into one giant vector.
		const wouldOverflow = bufLen + line.length + 1 > MAX_CHUNK_CHARS && bufLines.length > 0;

		if (isBoundary || wouldOverflow) {
			flush(lineNo - 1);
			bufStart = lineNo;
		}
		bufLines.push(line);
		bufLen += line.length + 1;
	}
	flush(lines.length);

	return mergeTinyChunks(raw);
}

function slidingWindow(lines: readonly string[]): Chunk[] {
	const out: Chunk[] = [];
	for (let i = 0; i < lines.length; i += SLIDING_WINDOW_LINES) {
		const end = Math.min(i + SLIDING_WINDOW_LINES, lines.length);
		const slice = lines.slice(i, end);
		const text = slice.join("\n");
		if (text.trim().length === 0) continue;
		// Hard cap each window so a single multi-megabyte line doesn't explode memory.
		const content = text.length > MAX_CHUNK_CHARS ? text.slice(0, MAX_CHUNK_CHARS) : text;
		out.push({ startLine: i + 1, endLine: end, content });
	}
	return out;
}

/**
 * Merge any chunk smaller than `MIN_CHUNK_CHARS` into the previous chunk so we
 * don't waste vectors on stubs. If a tiny chunk is at the start, it merges into
 * the next one instead.
 */
function mergeTinyChunks(chunks: readonly Chunk[]): Chunk[] {
	if (chunks.length <= 1) return [...chunks];
	const out: Chunk[] = [];
	for (const c of chunks) {
		const prev = out[out.length - 1];
		if (
			prev &&
			(c.content.length < MIN_CHUNK_CHARS || prev.content.length < MIN_CHUNK_CHARS) &&
			prev.content.length + c.content.length + 1 <= MAX_CHUNK_CHARS
		) {
			out[out.length - 1] = {
				startLine: prev.startLine,
				endLine: c.endLine,
				content: `${prev.content}\n${c.content}`,
			};
		} else {
			out.push(c);
		}
	}
	return out;
}

/**
 * Async chunking entry point. Tries the tree-sitter chunker first; if it
 * returns null (language unsupported, WASM not installed, parse failed) we
 * silently fall back to the regex chunker so callers never see a hard
 * failure. APPENDED in R3-A — existing sync `chunkContent` remains exported
 * unchanged for callers that don't want to opt in to the async path.
 */
export async function chunkContentSmart(content: string, language: Language): Promise<Chunk[]> {
	// Defer the import so we don't load `web-tree-sitter` (or even resolve it)
	// for callers that never use this entry point.
	const mod = await import("./treesitter-chunker");
	try {
		const ts = await mod.chunkContentTreeSitter(content, language);
		if (ts !== null) return ts;
	} catch {
		// Swallow — silent fallback per spec.
	}
	return chunkContent(content, language);
}
