/**
 * Tree-sitter-backed source chunker.
 *
 * The legacy `chunker.ts` uses per-language regexes for boundary detection,
 * which works reasonably well but mis-splits on edge cases (nested classes,
 * decorators, multi-line signatures). This module upgrades the split to a real
 * AST walk via `web-tree-sitter` so each top-level function/class/method
 * becomes exactly one chunk, with the symbol name baked into the metadata.
 *
 * R4-A: `web-tree-sitter` is now a regular dependency and the grammar .wasm
 * files for TS/JS/Python/Go/Rust are vendored into
 * `packages/codebase-index/grammars/` by `scripts/sync-grammars.mjs` at
 * build time. If a grammar is missing we still fall back to the regex
 * chunker silently, but in published builds the AST path is the hot one.
 *
 * Grammars are loaded on demand from `<package>/grammars/tree-sitter-<lang>.wasm`.
 * The path is resolved via `import.meta.url` so it works regardless of how
 * the package is rooted (workspace, hoisted node_modules, packaged VSIX).
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import type { Chunk, Language } from "./chunker";
import { MAX_CHUNK_CHARS, MAX_FILE_BYTES } from "./chunker";

// CJS-friendly source-dir resolution. When this file is consumed as ESM
// (vitest, ESM-built extension host) `import.meta.url` resolves; when it's
// bundled into a CJS extension by esbuild, `import.meta` is empty and we
// fall back to `__dirname` instead. Either way we end up with the absolute
// directory of this source file, which is what we need to find `../grammars/`.
function resolveSourceDir(): string {
	try {
		const url = import.meta.url;
		if (url) return path.dirname(fileURLToPath(url));
	} catch {
		// import.meta unavailable in CJS context.
	}
	// biome-ignore lint/suspicious/noExplicitAny: __dirname is injected by CJS at runtime.
	if (typeof (globalThis as any).__dirname === "string") {
		// biome-ignore lint/suspicious/noExplicitAny: see above.
		return (globalThis as any).__dirname as string;
	}
	if (typeof __dirname !== "undefined") return __dirname;
	return process.cwd();
}

/**
 * Tree-sitter grammar identifiers we know how to load. Keep this list in sync
 * with the BOUNDARY_NODE_TYPES map below — a language listed here without a
 * corresponding node-type table will produce zero chunks (we'd then fall back
 * to the regex chunker, but the wasted load is avoidable).
 */
const SUPPORTED_LANGUAGES: ReadonlySet<Language> = new Set<Language>([
	"ts",
	"js",
	"py",
	"go",
	"rs",
]);

/**
 * Per-language node types that count as a "chunk boundary" — i.e. nodes whose
 * source range becomes one Chunk. We intentionally keep this to top-level
 * functions, classes, and methods. Method-level granularity is what downstream
 * ranking actually needs; finer-grained nodes (statements, expressions) would
 * produce too many tiny vectors.
 */
const BOUNDARY_NODE_TYPES: Readonly<Record<string, ReadonlySet<string>>> = {
	ts: new Set([
		"function_declaration",
		"method_definition",
		"class_declaration",
		"interface_declaration",
		"enum_declaration",
		"type_alias_declaration",
	]),
	js: new Set(["function_declaration", "method_definition", "class_declaration"]),
	py: new Set(["function_definition", "class_definition", "decorated_definition"]),
	go: new Set(["function_declaration", "method_declaration", "type_declaration"]),
	rs: new Set(["function_item", "struct_item", "enum_item", "trait_item", "impl_item"]),
};

/**
 * Map a `Language` to the bundled grammar wasm filename. These files are
 * copied out of `tree-sitter-<lang>/*.wasm` by `scripts/sync-grammars.mjs`.
 */
const GRAMMAR_FILES: Readonly<Record<string, string>> = {
	ts: "tree-sitter-typescript.wasm",
	js: "tree-sitter-javascript.wasm",
	py: "tree-sitter-python.wasm",
	go: "tree-sitter-go.wasm",
	rs: "tree-sitter-rust.wasm",
};

// Resolve the bundled grammars directory once. The source dir points at
// `<pkg>/src/treesitter-chunker.ts` (or .js after tsc); `../grammars/` is
// where sync-grammars.mjs lands the wasm files. Works for workspace-rooted
// installs and for the VSIX layout because the relative path is preserved.
//
// When this module is bundled into the CJS extension host, the bundler
// flattens `<pkg>/src/...` into a single `dist/extension.js`; in that case
// `__dirname` resolves to `<host>/dist/`, so the bundled grammars must be
// reachable from there. The extension-host build copies / references them
// out of the codebase-index package via the extension packaging step, but
// we keep the fallback below to search a few candidate locations.
const SOURCE_DIR = resolveSourceDir();
const GRAMMARS_DIR_CANDIDATES = [
	path.resolve(SOURCE_DIR, "..", "grammars"),
	path.resolve(SOURCE_DIR, "grammars"),
	path.resolve(SOURCE_DIR, "..", "..", "codebase-index", "grammars"),
];
function findGrammarsDir(): string {
	for (const dir of GRAMMARS_DIR_CANDIDATES) {
		if (fs.existsSync(dir)) return dir;
	}
	return GRAMMARS_DIR_CANDIDATES[0];
}
const GRAMMARS_DIR = findGrammarsDir();

// Internal type aliases for the lazily-imported web-tree-sitter API. Kept
// loose so we don't have to depend on the full d.ts in our public type
// surface — the only consumers are inside this module.
interface TSNode {
	readonly type: string;
	readonly startIndex: number;
	readonly endIndex: number;
	readonly startPosition: { row: number; column: number };
	readonly endPosition: { row: number; column: number };
	readonly children: readonly TSNode[];
	childForFieldName(name: string): TSNode | null;
	text: string;
}

interface ParserInstance {
	setLanguage(lang: unknown): unknown;
	parse(source: string): { rootNode: TSNode } | null;
}

interface WebTreeSitterApi {
	Parser: (new () => ParserInstance) & {
		init(opts?: unknown): Promise<void>;
	};
	Language: {
		load(input: string | Uint8Array): Promise<unknown>;
	};
}

/** Cached, post-init parser instances keyed by `Language`. */
const parserCache = new Map<Language, ParserInstance | "failed">();

let webTreeSitterModule: WebTreeSitterApi | null | undefined;
let initPromise: Promise<WebTreeSitterApi | null> | undefined;

// Test-only override; see `_setGrammarsDirForTests` below.
let grammarsDirOverride: string | undefined;

/**
 * Lazy-import `web-tree-sitter` exactly once. Returns `null` if the package
 * isn't installed or its WASM runtime can't be initialized. We cache both
 * the resolved module and the in-flight promise so concurrent callers don't
 * trigger multiple `Parser.init()` calls (which are idempotent but wasteful).
 */
async function loadWebTreeSitter(): Promise<WebTreeSitterApi | null> {
	if (webTreeSitterModule !== undefined) return webTreeSitterModule;
	if (initPromise) return initPromise;
	initPromise = (async () => {
		try {
			// `web-tree-sitter` is a normal runtime dependency in R4-A. We
			// still use a dynamic import (rather than a static one at the
			// top of the file) so that:
			//   - Bundlers can mark it external without pulling its WASM
			//     bootstrap into other bundles.
			//   - A broken/missing install degrades to "regex fallback"
			//     instead of crashing the indexer.
			// The `@vite-ignore` hint keeps Vite/esbuild from trying to
			// statically resolve the package at build time.
			const mod = (await import(/* @vite-ignore */ "web-tree-sitter")) as Record<string, unknown>;
			// v0.26 exposes Parser/Language as named exports (no default).
			// Be tolerant of either shape so an older or vendored build
			// doesn't break us.
			const api: WebTreeSitterApi = {
				Parser: (mod.Parser ??
					(mod.default as { Parser: unknown } | undefined)?.Parser) as WebTreeSitterApi["Parser"],
				Language: (mod.Language ??
					(mod.default as { Language: unknown } | undefined)?.Language) as WebTreeSitterApi["Language"],
			};
			if (!api.Parser || !api.Language) throw new Error("web-tree-sitter shape unexpected");
			await api.Parser.init();
			webTreeSitterModule = api;
			return api;
		} catch {
			webTreeSitterModule = null;
			return null;
		}
	})();
	return initPromise;
}

/**
 * Resolve a grammar's .wasm file on disk. Prefers the bundled copy under
 * `<pkg>/grammars/` (populated by `scripts/sync-grammars.mjs`); falls back
 * to a node_modules lookup so unbundled dev runs still work. The grammars
 * directory can be overridden via `_setGrammarsDirForTests` to exercise
 * the "no grammars" fallback in unit tests.
 */
function resolveGrammarWasm(language: Language): string | null {
	const fname = GRAMMAR_FILES[language];
	if (!fname) return null;
	const dir = grammarsDirOverride ?? GRAMMARS_DIR;
	const bundled = path.join(dir, fname);
	if (fs.existsSync(bundled)) return bundled;
	// When an override is set we deliberately do NOT fall back to
	// node_modules — the test wants to see the "missing grammar" path.
	if (grammarsDirOverride !== undefined) return null;
	// Dev fallback: look under the package's node_modules. Walk up to find
	// it the same way `require.resolve` would. Kept narrow (depth 6) so we
	// don't spelunk the entire FS on a miss.
	const pkgName = fname.replace(/\.wasm$/, "");
	let cwd = process.cwd();
	for (let depth = 0; depth < 6; depth++) {
		const candidate = path.join(cwd, "node_modules", pkgName, fname);
		if (fs.existsSync(candidate)) return candidate;
		const parent = path.dirname(cwd);
		if (parent === cwd) break;
		cwd = parent;
	}
	return null;
}

/**
 * Acquire (or build) a parser for `language`. Returns `null` if the grammar
 * isn't available — the caller should then fall back to the regex chunker.
 * Cached in module scope so a single parser instance is reused across
 * indexing runs.
 */
async function getParser(language: Language): Promise<ParserInstance | null> {
	if (!SUPPORTED_LANGUAGES.has(language)) return null;
	const cached = parserCache.get(language);
	if (cached === "failed") return null;
	if (cached) return cached;

	const api = await loadWebTreeSitter();
	if (!api) {
		parserCache.set(language, "failed");
		return null;
	}
	const wasmPath = resolveGrammarWasm(language);
	if (!wasmPath) {
		parserCache.set(language, "failed");
		return null;
	}
	try {
		// `Language.load` accepts either a path string or a Uint8Array. In
		// Node we read the bytes ourselves so the wasm runtime doesn't need
		// fetch/file:// support (Emscripten's default `locateFile` can be
		// fragile inside packaged extensions).
		const bytes = fs.readFileSync(wasmPath);
		const lang = await api.Language.load(new Uint8Array(bytes));
		const parser = new api.Parser();
		parser.setLanguage(lang);
		parserCache.set(language, parser);
		return parser;
	} catch {
		parserCache.set(language, "failed");
		return null;
	}
}

/**
 * Try to identify a symbol name for a boundary node by inspecting common
 * child-field names (`name`) or falling back to the first identifier child.
 * Returns undefined if we can't pin one down; the resulting chunk just won't
 * have `symbolName` set, which is fine.
 */
function symbolNameFor(node: TSNode): string | undefined {
	try {
		const named = node.childForFieldName("name");
		if (named?.text) return named.text;
	} catch {
		// Some node types don't support childForFieldName; ignore.
	}
	for (const child of node.children) {
		if (child.type === "identifier" || child.type === "type_identifier") {
			return child.text;
		}
	}
	return undefined;
}

/**
 * In TS/JS, top-level `export function …` parses as
 * `export_statement → function_declaration`. We unwrap wrapper nodes so the
 * boundary types match the inner declaration; the chunk still spans the
 * full source range of the wrapper because we use `child.startPosition`
 * before unwrapping (the wrapper covers the same lines as the inner node).
 *
 * Returns the inner declaration node if `node` is a wrapper, otherwise the
 * node itself.
 */
function unwrapBoundary(node: TSNode): TSNode {
	if (node.type === "export_statement" || node.type === "decorated_definition") {
		for (const child of node.children) {
			if (
				child.type !== "export" &&
				child.type !== "default" &&
				child.type !== "decorator" &&
				child.type !== "{" &&
				child.type !== "}"
			) {
				return child;
			}
		}
	}
	return node;
}

/**
 * Walk the top level of the AST, emitting one Chunk per boundary-typed node.
 * Anything between boundaries (imports, top-level constants) is gathered into
 * a leading "preamble" chunk so we don't drop file-level context.
 */
function collectChunks(root: TSNode, source: string, language: Language): Chunk[] {
	const types = BOUNDARY_NODE_TYPES[language];
	if (!types) return [];
	const out: Chunk[] = [];
	const lines = source.split(/\r?\n/);

	// Walk only the direct children of the root (top-level declarations). This
	// matches the spec: top-level functions/classes/methods become chunks; we
	// don't recurse into class bodies because the class itself already is one
	// chunk and embedding methods separately would explode the index size.
	let cursor = 0; // line index just past the last emitted chunk
	for (const rawChild of root.children) {
		// Unwrap `export_statement` / `decorated_definition` so we can match
		// the inner `function_declaration` etc. against BOUNDARY_NODE_TYPES.
		// We use the wrapper's source range though — the export keyword is
		// part of the chunk's text.
		const child = unwrapBoundary(rawChild);
		if (!types.has(child.type)) continue;
		const startLine = rawChild.startPosition.row + 1;
		const endLine = rawChild.endPosition.row + 1;
		// Preamble: lines between the previous boundary and this one. Skip if
		// it would be blank or smaller than a useful chunk.
		if (startLine - 1 > cursor) {
			const slice = lines.slice(cursor, startLine - 1).join("\n");
			if (slice.trim().length > 0) {
				out.push({
					startLine: cursor + 1,
					endLine: startLine - 1,
					content: clip(slice),
				});
			}
		}
		const body = lines.slice(startLine - 1, endLine).join("\n");
		out.push({
			startLine,
			endLine,
			content: clip(body),
			symbolName: symbolNameFor(child),
		});
		cursor = endLine;
	}
	// Trailing material after the last boundary.
	if (cursor < lines.length) {
		const tail = lines.slice(cursor).join("\n");
		if (tail.trim().length > 0) {
			out.push({
				startLine: cursor + 1,
				endLine: lines.length,
				content: clip(tail),
			});
		}
	}
	return out;
}

function clip(text: string): string {
	if (text.length <= MAX_CHUNK_CHARS) return text;
	return text.slice(0, MAX_CHUNK_CHARS);
}

/**
 * Public entry point. Returns `null` when tree-sitter isn't available or the
 * language isn't supported — the caller should fall back to the regex
 * chunker. Returns `[]` for files we deliberately skip (oversize).
 */
export async function chunkContentTreeSitter(
	content: string,
	language: Language,
): Promise<Chunk[] | null> {
	if (content.length > MAX_FILE_BYTES) return [];
	if (content.length === 0) return [];
	if (!SUPPORTED_LANGUAGES.has(language)) return null;
	const parser = await getParser(language);
	if (!parser) return null;
	try {
		const tree = parser.parse(content);
		if (!tree?.rootNode) return null;
		return collectChunks(tree.rootNode, content, language);
	} catch {
		return null;
	}
}

/** Test/utility hook: clear the parser cache. Used by tests; harmless in prod. */
export function _resetTreeSitterCacheForTests(): void {
	parserCache.clear();
	webTreeSitterModule = undefined;
	initPromise = undefined;
}

/**
 * Test hook: override the grammars directory. Used to simulate "missing
 * grammar" conditions without mutating the on-disk vendor copy. Pass
 * `undefined` to restore the default lookup behavior.
 */
export function _setGrammarsDirForTests(dir: string | undefined): void {
	grammarsDirOverride = dir;
	parserCache.clear();
}
