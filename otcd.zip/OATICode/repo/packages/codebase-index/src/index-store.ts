import * as fs from "node:fs";
import * as path from "node:path";
import Database, { type Database as DatabaseT, type Statement } from "better-sqlite3";

/**
 * Thin SQLite wrapper for the chunk + vector tables.
 *
 * Schema rationale:
 *   - `chunks` keyed by an auto-incrementing id, with a UNIQUE(file_path,
 *     start_line, end_line) constraint so re-indexing the same chunk is
 *     idempotent. `content_hash` lets the indexer skip re-embedding unchanged
 *     chunks (the slow path).
 *   - `vectors` stores the raw Float32Array bytes in a BLOB. One row per
 *     chunk_id; cascading delete on chunk removal.
 *   - `meta` holds the embedder dimension so we can detect a mismatched DB
 *     (e.g. user switched from OpenAI 1536 to TF-IDF 256) and reset rather
 *     than serve nonsense results.
 *
 * No vector-search extension (e.g. sqlite-vss): brute force is faster than the
 * setup overhead until ~50k chunks, and works on every platform without
 * shipping platform-specific binaries.
 */
export interface ChunkRow {
	readonly id: number;
	readonly filePath: string;
	readonly startLine: number;
	readonly endLine: number;
	readonly content: string;
	readonly contentHash: string;
}

export interface ChunkWithVector extends ChunkRow {
	readonly vector: Float32Array;
}

export class IndexStore {
	private readonly db: DatabaseT;
	private readonly dim: number;
	// R8-B: track the embedder id used to build this index so the host can
	// detect "user switched embedder; reindex required" without reading every
	// vector. `undefined` means the SQLite file pre-dates R8 (legacy).
	private readonly embedderId: string | undefined;

	private readonly insertChunk: Statement;
	private readonly insertVector: Statement;
	private readonly findChunkByHash: Statement;
	private readonly deleteChunksForFile: Statement;
	private readonly listAllChunks: Statement;
	private readonly listChunksForFile: Statement;
	private readonly countChunks: Statement;
	private readonly countFiles: Statement;

	constructor(dbPath: string, dim: number, embedderId?: string) {
		// Best-effort ensure the parent directory exists. ":memory:" passes through
		// untouched. Errors here propagate — a missing parent is a hard failure.
		if (dbPath !== ":memory:") {
			const dir = path.dirname(dbPath);
			try {
				fs.mkdirSync(dir, { recursive: true });
			} catch {
				/* permission errors will surface from the Database constructor */
			}
		}
		this.db = new Database(dbPath);
		this.dim = dim;
		// `PRAGMA journal_mode=WAL` reduces write contention if a second process
		// (e.g. an external CLI) ever opens the same file. `synchronous=NORMAL`
		// is a reasonable durability/throughput tradeoff for an index we can
		// always rebuild.
		this.db.pragma("journal_mode = WAL");
		this.db.pragma("synchronous = NORMAL");
		this.db.exec(`
			CREATE TABLE IF NOT EXISTS chunks (
				id            INTEGER PRIMARY KEY AUTOINCREMENT,
				file_path     TEXT NOT NULL,
				start_line    INTEGER NOT NULL,
				end_line      INTEGER NOT NULL,
				content       TEXT NOT NULL,
				content_hash  TEXT NOT NULL,
				UNIQUE(file_path, start_line, end_line)
			);
			CREATE INDEX IF NOT EXISTS chunks_by_path ON chunks(file_path);
			CREATE INDEX IF NOT EXISTS chunks_by_hash ON chunks(content_hash);

			CREATE TABLE IF NOT EXISTS vectors (
				chunk_id  INTEGER PRIMARY KEY,
				dim       INTEGER NOT NULL,
				vec       BLOB NOT NULL,
				FOREIGN KEY (chunk_id) REFERENCES chunks(id) ON DELETE CASCADE
			);

			CREATE TABLE IF NOT EXISTS meta (
				key   TEXT PRIMARY KEY,
				value TEXT NOT NULL
			);
		`);

		const existingDim = this.getMeta("dim");
		if (existingDim === undefined) {
			this.setMeta("dim", String(dim));
		} else if (Number.parseInt(existingDim, 10) !== dim) {
			// Dimension mismatch — wipe the data tables so we don't mix sizes.
			// Keep the schema; just zero out content. This is preferable to
			// silently failing cosine math with mis-sized vectors.
			this.db.exec("DELETE FROM vectors; DELETE FROM chunks;");
			this.setMeta("dim", String(dim));
		}

		// R8-B: persist the embedder id alongside the dim so the host can
		// notice "user switched providers" even when two providers happen to
		// share a vector length (e.g. Voyage and Cohere are both 1024).
		this.embedderId = embedderId;
		if (embedderId !== undefined) {
			const existingId = this.getMeta("embedder_id");
			if (existingId === undefined) {
				this.setMeta("embedder_id", embedderId);
			} else if (existingId !== embedderId) {
				// Mixed embeddings produce nonsense scores. Wipe and re-record.
				this.db.exec("DELETE FROM vectors; DELETE FROM chunks;");
				this.setMeta("embedder_id", embedderId);
				this.setMeta("dim", String(dim));
			}
		}

		this.insertChunk = this.db.prepare(`
			INSERT INTO chunks (file_path, start_line, end_line, content, content_hash)
			VALUES (?, ?, ?, ?, ?)
			ON CONFLICT(file_path, start_line, end_line) DO UPDATE SET
				content = excluded.content,
				content_hash = excluded.content_hash
			RETURNING id
		`);
		this.insertVector = this.db.prepare(`
			INSERT INTO vectors (chunk_id, dim, vec) VALUES (?, ?, ?)
			ON CONFLICT(chunk_id) DO UPDATE SET dim = excluded.dim, vec = excluded.vec
		`);
		this.findChunkByHash = this.db.prepare(`
			SELECT id FROM chunks WHERE file_path = ? AND start_line = ? AND end_line = ? AND content_hash = ?
		`);
		this.deleteChunksForFile = this.db.prepare("DELETE FROM chunks WHERE file_path = ?");
		this.listAllChunks = this.db.prepare(`
			SELECT c.id, c.file_path AS filePath, c.start_line AS startLine, c.end_line AS endLine,
			       c.content, c.content_hash AS contentHash, v.vec AS vec
			FROM chunks c
			JOIN vectors v ON v.chunk_id = c.id
		`);
		this.listChunksForFile = this.db.prepare(`
			SELECT id, file_path AS filePath, start_line AS startLine, end_line AS endLine,
			       content, content_hash AS contentHash
			FROM chunks WHERE file_path = ?
		`);
		this.countChunks = this.db.prepare("SELECT COUNT(*) AS n FROM chunks");
		this.countFiles = this.db.prepare("SELECT COUNT(DISTINCT file_path) AS n FROM chunks");
	}

	getDim(): number {
		return this.dim;
	}

	// R8-B: expose the embedder id persisted into the SQLite `meta` table so
	// the host can decide whether to prompt the user to reindex.
	getEmbedderId(): string | undefined {
		return this.embedderId ?? this.getMeta("embedder_id");
	}

	close(): void {
		this.db.close();
	}

	private getMeta(key: string): string | undefined {
		const row = this.db.prepare("SELECT value FROM meta WHERE key = ?").get(key) as
			| { value: string }
			| undefined;
		return row?.value;
	}

	private setMeta(key: string, value: string): void {
		this.db.prepare("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)").run(key, value);
	}

	/**
	 * Insert or update a chunk + its vector. Returns whether the row was new (true)
	 * or already had the same content_hash (false). The caller uses this to skip
	 * embedding when nothing has changed.
	 */
	upsert(
		filePath: string,
		startLine: number,
		endLine: number,
		content: string,
		contentHash: string,
		vector: Float32Array,
	): boolean {
		const existing = this.findChunkByHash.get(filePath, startLine, endLine, contentHash) as
			| { id: number }
			| undefined;
		if (existing) {
			// Same content, same coords — nothing to do. Don't even touch vectors.
			return false;
		}
		const inserted = this.insertChunk.get(filePath, startLine, endLine, content, contentHash) as {
			id: number;
		};
		this.insertVector.run(inserted.id, this.dim, vectorToBlob(vector));
		return true;
	}

	deleteFile(filePath: string): number {
		const result = this.deleteChunksForFile.run(filePath);
		return Number(result.changes);
	}

	/**
	 * Stream all (chunk, vector) pairs. Used by the brute-force search path.
	 * Returns an array — callers that need iteration over giant indexes should
	 * call `listChunksForFile` per-file instead.
	 */
	all(): ChunkWithVector[] {
		const rows = this.listAllChunks.all() as {
			id: number;
			filePath: string;
			startLine: number;
			endLine: number;
			content: string;
			contentHash: string;
			vec: Buffer;
		}[];
		return rows.map((r) => ({
			id: r.id,
			filePath: r.filePath,
			startLine: r.startLine,
			endLine: r.endLine,
			content: r.content,
			contentHash: r.contentHash,
			vector: blobToVector(r.vec, this.dim),
		}));
	}

	listForFile(filePath: string): ChunkRow[] {
		return this.listChunksForFile.all(filePath) as ChunkRow[];
	}

	stats(): { chunks: number; files: number } {
		const c = this.countChunks.get() as { n: number };
		const f = this.countFiles.get() as { n: number };
		return { chunks: c.n, files: f.n };
	}
}

function vectorToBlob(vec: Float32Array): Buffer {
	// `Buffer.from(arrayBuffer, byteOffset, length)` shares the underlying memory,
	// which is exactly what we want — no copy. better-sqlite3 then takes a copy
	// internally for the BLOB cell.
	return Buffer.from(vec.buffer, vec.byteOffset, vec.byteLength);
}

function blobToVector(blob: Buffer, dim: number): Float32Array {
	// Copy into a freshly-aligned ArrayBuffer because the Buffer returned from
	// SQLite may not be 4-byte aligned, which Float32Array requires.
	const arr = new Float32Array(dim);
	const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
	const limit = Math.min(dim, Math.floor(blob.byteLength / 4));
	for (let i = 0; i < limit; i++) arr[i] = view.getFloat32(i * 4, true);
	return arr;
}
