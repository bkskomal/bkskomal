import { createHash } from "node:crypto";

/**
 * Hash chunk content for dedupe. SHA-256 truncated to 16 hex chars (64 bits)
 * is enough collision resistance for an index of <10M chunks and keeps the
 * SQLite row width small. Truncating from the front is fine — SHA-256 has no
 * structure to exploit there.
 */
export function contentHash(content: string): string {
	return createHash("sha256").update(content).digest("hex").slice(0, 16);
}
