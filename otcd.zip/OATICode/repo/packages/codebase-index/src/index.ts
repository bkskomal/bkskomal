export {
	CodebaseIndex,
	createDefaultIndex,
} from "./codebase-index";
export type {
	CodebaseIndexOptions,
	IndexAllOptions,
	IndexAllResult,
	IndexProgress,
	SearchOptions,
	SearchResult,
} from "./codebase-index";

export {
	cosineSimilarity,
	l2Normalize,
	tokenize,
	TfIdfEmbedder,
	TF_IDF_DIM,
	OpenAICompatEmbedder,
} from "./embedder";
export type { Embedder, OpenAICompatEmbedderOptions } from "./embedder";

export {
	MAX_CHUNK_CHARS,
	MIN_CHUNK_CHARS,
	languageForPath,
	chunkContent,
	chunkContentSmart,
} from "./chunker";
export type { Chunk, Language } from "./chunker";

export { chunkContentTreeSitter } from "./treesitter-chunker";

export { buildSymbolGraphHop, symbolGraphBoost } from "./symbol-graph";
export type { SymbolGraphHop } from "./symbol-graph";

export { walkWorkspace, isIndexableExtension } from "./walker";
export type { WalkOptions } from "./walker";

export { contentHash } from "./hash";

export { rankFiles } from "./ranker";
export type { RankInput, RankResult, FileRankBreakdown } from "./ranker";

// R8-B: pluggable embedder providers + LLM-as-reranker.
export {
	EMBEDDER_CATALOG,
	EMBEDDER_IDS,
	SECRET_KEYS,
	CohereEmbedder,
	OpenAIEmbedder,
	TfIdfEmbedderProvider,
	VoyageEmbedder,
	createCohereEmbedder,
	createEmbedder,
	createOpenAIEmbedder,
	createTfIdfEmbedder,
	createVoyageEmbedder,
	getCatalogEntry,
} from "./embedders";
export type {
	CreateEmbedderOptions,
	EmbedderCatalogEntry,
	EmbedderId,
	EmbedderProvider,
	GetSecret,
} from "./embedders";

export {
	LLMReranker,
	buildPrompt as buildRerankPrompt,
	parseScores as parseRerankScores,
} from "./reranker";
export type { LlmCallFn, RerankCandidate, RerankResult, RerankerOptions } from "./reranker";

// Phase 1.1: Reciprocal Rank Fusion for hybrid retrieval. Exported so
// the host can use the same merge primitive in callers outside the
// CodebaseIndex (e.g., merging tool results from multiple search tools).
export { rrfMerge, collapseToFileLevel } from "./rrf-merge";
export type { MergedResult, RankedItem, RrfOptions } from "./rrf-merge";

// Phase 1.2: lexical pattern extraction. Tools (code_semantic_search)
// use this to decide whether a natural-language query has any
// identifier-shaped content worth handing to ripgrep — pure English
// queries skip lexical entirely; queries with identifiers get the
// hybrid path.
export { extractLexicalPatterns, buildLexicalRegex } from "./lexical-extract";

// 2026-06-01: Aider-style repo map for context-budget-aware orientation.
// Walks the workspace, extracts top-level symbols per file, renders a
// compressed text view sized to a per-turn token budget.
export { buildRepoMap } from "./repo-map";
export type { RepoMapOptions, RepoMapResult } from "./repo-map";
export { extractSymbols, languageForExtension } from "./symbol-extract";
export type { ExtractedSymbol } from "./symbol-extract";
