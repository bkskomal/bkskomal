// Extract identifier-like tokens from a natural-language query so we
// can run a useful lexical (ripgrep) pass alongside semantic search.
//
// The principle: the model writes queries that mix English ("find calls
// to authenticateUser") with code-shaped tokens. Pure English gives us
// nothing useful for grep — "authentication" matches every file that
// mentions auth in a comment. But the identifier `authenticateUser`
// almost certainly only appears at the definition + call sites. So
// when an identifier IS present, lexical search is a high-precision
// signal that pairs beautifully with semantic search's recall.
//
// This module is pure — no IO, easy to test. The caller decides what
// to do with the tokens (typically: feed them to ripgrep, OR-joined).
//
// What counts as an identifier?
//   - camelCase or PascalCase: `authenticateUser`, `MyClass`
//   - snake_case: `run_tests`, `Token_X`
//   - SCREAMING_SNAKE_CASE: `MAX_RETRIES`, `TODO_MARKER`
//   - Quoted strings: "deprecated", 'feature_flag'
//
// What we deliberately skip:
//   - Plain English words ("authentication", "validate")
//   - Single short letters (`a`, `i`, `to`)
//   - Common keywords that appear everywhere (`function`, `class`, `if`)
//
// False positives are cheap (one wasted ripgrep call, no matches, RRF
// silently ignores the empty ranking). False negatives are expensive
// (we lose the lexical signal). When in doubt, include.

const QUOTED_RE = /["']([^"'\n]{2,80})["']/g;
const CAMEL_RE = /\b([a-z][a-zA-Z0-9]*[A-Z][a-zA-Z0-9]+)\b/g;
const PASCAL_RE = /\b([A-Z][a-z]+[A-Z][a-zA-Z0-9]+)\b/g;
const SNAKE_RE = /\b([a-zA-Z][a-zA-Z0-9]*(?:_[a-zA-Z0-9]+)+)\b/g;
const SCREAMING_RE = /\b([A-Z][A-Z0-9]+(?:_[A-Z0-9]+){1,})\b/g;
// Single-word common-keyword block-list. These slip through camelCase
// (`if`, `for`) when capitalization or compound is involved; rule them
// out explicitly to keep the ripgrep call useful.
const STOP_WORDS = new Set([
	"if",
	"for",
	"while",
	"function",
	"return",
	"class",
	"const",
	"let",
	"var",
	"import",
	"export",
	"from",
	"true",
	"false",
	"null",
	"undefined",
	"new",
	"this",
	"super",
	"static",
	"async",
	"await",
	"yield",
	"public",
	"private",
	"protected",
	"interface",
	"type",
	"enum",
]);

/**
 * Pull identifier-shaped tokens out of a natural-language query.
 *
 * Returns an array of distinct tokens, ordered by first appearance.
 * Returns `[]` when nothing identifier-shaped is present — the caller
 * uses this as a signal to skip lexical search entirely.
 *
 * Tokens longer than 80 chars are dropped (likely garbage). Tokens are
 * deduped case-insensitively because ripgrep can be case-insensitive
 * anyway and we don't want to fire two near-duplicate searches.
 */
export function extractLexicalPatterns(query: string): string[] {
	if (typeof query !== "string" || query.length === 0) return [];
	const seen = new Set<string>();
	const out: string[] = [];
	const add = (raw: string) => {
		const tok = raw.trim();
		if (tok.length < 3 || tok.length > 80) return;
		if (STOP_WORDS.has(tok.toLowerCase())) return;
		const key = tok.toLowerCase();
		if (seen.has(key)) return;
		seen.add(key);
		out.push(tok);
	};
	for (const re of [QUOTED_RE, SCREAMING_RE, CAMEL_RE, PASCAL_RE, SNAKE_RE]) {
		re.lastIndex = 0;
		let m: RegExpExecArray | null;
		// biome-ignore lint/suspicious/noAssignInExpressions: standard regex-exec idiom
		while ((m = re.exec(query)) !== null) {
			add(m[1] ?? m[0]);
		}
	}
	return out;
}

/**
 * Build a single ripgrep-compatible regex that ORs the extracted
 * patterns. ripgrep handles regex alternation natively, so we issue
 * one ripgrep call instead of N. Each pattern is regex-escaped so
 * tokens with regex-meta chars (rare but possible) match literally.
 *
 * Returns `undefined` when there's nothing to search for — caller
 * treats this as the skip signal.
 */
export function buildLexicalRegex(patterns: readonly string[]): string | undefined {
	if (patterns.length === 0) return undefined;
	const escaped = patterns.map(escapeRegex);
	return escaped.length === 1 ? escaped[0] : `(${escaped.join("|")})`;
}

function escapeRegex(s: string): string {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
