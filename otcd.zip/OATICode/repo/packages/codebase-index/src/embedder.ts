/**
 * Embedder abstraction. Concrete implementations may call out to a remote
 * OpenAI-compatible `/v1/embeddings` endpoint, or — when no provider is
 * available — produce a deterministic TF-IDF vector locally so the index still
 * works in tests and offline runs.
 *
 * The vector dimension is fixed per-embedder. Mixing dims in one DB is not
 * supported; consumers should re-index when switching providers.
 */
export interface Embedder {
	/** Vector dimension produced by `embed`. Stable for the embedder's lifetime. */
	readonly dim: number;
	/** Batch-embed `texts`. Returned vectors are in the same order. */
	embed(texts: readonly string[]): Promise<readonly Float32Array[]>;
}

/**
 * Default TF-IDF dimension. 256 is the smallest power-of-two that empirically
 * survives the birthday paradox for ~50k chunks on natural-language tokens
 * (collision rate stays under ~5% per slot in tests). Going larger (512/768)
 * yields negligible recall gains for this lightweight fallback and bloats the
 * SQLite file 2-3x. Going smaller (128) makes collisions visible in unit tests.
 */
export const TF_IDF_DIM = 256;

/**
 * Pluggable token splitter. Default behavior:
 *   - split on non-word characters (matches identifier boundaries in most languages)
 *   - lowercase
 *   - also emit camelCase/snake_case sub-tokens so "parseHttpRequest" matches
 *     queries for "http" or "parse"
 */
export function tokenize(text: string): string[] {
	const out: string[] = [];
	const matches = text.toLowerCase().match(/[a-z][a-z0-9]*|\d+/g);
	if (matches) out.push(...matches);
	// Sub-token expansion for compound identifiers — apply on the ORIGINAL casing
	// so a camelCase boundary is detectable.
	const compounds = text.match(/[A-Za-z_][A-Za-z0-9_]*/g);
	if (compounds) {
		for (const c of compounds) {
			const parts = c
				.replace(/([a-z])([A-Z])/g, "$1 $2")
				.replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
				.split(/[_\s-]+/)
				.map((s) => s.toLowerCase())
				.filter((s) => s.length >= 2);
			for (const p of parts) out.push(p);
		}
	}
	return out;
}

/**
 * Deterministic hash → bucket. FNV-1a 32-bit; we don't need cryptographic
 * properties, only stable distribution across runs and machines.
 */
function fnv1a(s: string): number {
	let h = 0x811c9dc5 >>> 0;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 0x01000193) >>> 0;
	}
	return h;
}

/**
 * Build a hashed-bag-of-words vector. We use the **hashing trick** rather than
 * maintaining a vocabulary table — vocab management would force every chunk to
 * be re-encoded whenever a new term is seen. With dim=256 and 50k chunks the
 * collision rate is acceptable for ranking purposes.
 *
 * Term weighting: `1 + log(tf)` (sub-linear) so a 50-occurrence term doesn't
 * drown out everything else. IDF is applied in `TfIdfEmbedder.embed` once the
 * corpus has been seen.
 */
function hashBag(tokens: readonly string[], dim: number): Float32Array {
	const vec = new Float32Array(dim);
	if (tokens.length === 0) return vec;
	const tf = new Map<string, number>();
	for (const t of tokens) tf.set(t, (tf.get(t) ?? 0) + 1);
	for (const [term, count] of tf) {
		const slot = fnv1a(term) % dim;
		// Sign hashing: use a second hash bit to randomize sign so common terms
		// don't all pile additively into the same bucket. (Weinberger et al. 2009)
		const sign = (fnv1a(`${term}#sign`) & 1) === 0 ? 1 : -1;
		vec[slot] += sign * (1 + Math.log(count));
	}
	return vec;
}

/** L2-normalize a vector in place; safe to call on a zero vector (returns it unchanged). */
export function l2Normalize(vec: Float32Array): Float32Array {
	let norm = 0;
	for (let i = 0; i < vec.length; i++) norm += vec[i] * vec[i];
	if (norm === 0) return vec;
	const inv = 1 / Math.sqrt(norm);
	for (let i = 0; i < vec.length; i++) vec[i] *= inv;
	return vec;
}

/** Cosine similarity between two L2-normalized vectors == dot product. */
export function cosineSimilarity(a: Float32Array, b: Float32Array): number {
	if (a.length !== b.length) return 0;
	let s = 0;
	for (let i = 0; i < a.length; i++) s += a[i] * b[i];
	return s;
}

/**
 * Self-contained TF-IDF embedder. Stateless per call: the "IDF" component is
 * computed against the **current batch** which is good enough for cross-doc
 * ranking when we re-embed each chunk once at index time and re-embed the
 * query at search time.
 *
 * For true corpus-IDF we'd persist document frequencies across runs, but the
 * extra complexity isn't worth it for a fallback — the cosine similarity of
 * hashed bags-of-words already gives sensible "this chunk talks about the same
 * terms as the query" ranking.
 */
export class TfIdfEmbedder implements Embedder {
	readonly dim: number;

	constructor(dim: number = TF_IDF_DIM) {
		this.dim = dim;
	}

	async embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		const vecs: Float32Array[] = [];
		for (const text of texts) {
			const tokens = tokenize(text);
			const vec = hashBag(tokens, this.dim);
			l2Normalize(vec);
			vecs.push(vec);
		}
		return vecs;
	}
}

/**
 * Adapter for any OpenAI-compatible `/v1/embeddings` endpoint. The Embedder
 * interface is intentionally minimal; concrete providers wrap their own auth
 * and base URL outside this package.
 */
export interface OpenAICompatEmbedderOptions {
	readonly baseUrl: string;
	readonly apiKey: string;
	readonly model: string;
	/** Optional vector dimension when the provider supports `dimensions` param (e.g. OpenAI). */
	readonly dimensions?: number;
	/** Custom fetch (tests). */
	readonly fetchImpl?: typeof fetch;
}

interface EmbeddingsApiResponse {
	readonly data?: readonly { readonly embedding: readonly number[] }[];
}

/**
 * OpenAI-compatible embedder. Sends `POST {baseUrl}/embeddings` with the
 * standard `{ model, input, dimensions? }` payload. Many providers (Ollama,
 * vLLM, LM Studio, Together, Mistral, OpenAI itself) implement this contract.
 */
export class OpenAICompatEmbedder implements Embedder {
	readonly dim: number;
	private readonly url: string;
	private readonly headers: Record<string, string>;
	private readonly model: string;
	private readonly dimensions: number | undefined;
	private readonly fetchImpl: typeof fetch;

	constructor(opts: OpenAICompatEmbedderOptions) {
		const trimmed = opts.baseUrl.replace(/\/$/, "");
		this.url = `${trimmed}/embeddings`;
		this.headers = {
			"Content-Type": "application/json",
			Authorization: `Bearer ${opts.apiKey}`,
		};
		this.model = opts.model;
		this.dimensions = opts.dimensions;
		// `dim` must be known up front for the SQLite schema; fall back to 1536
		// (text-embedding-3-small default) when not provided so the index can be
		// created. Callers should pass an explicit value when the provider deviates.
		this.dim = opts.dimensions ?? 1536;
		this.fetchImpl = opts.fetchImpl ?? fetch;
	}

	async embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		if (texts.length === 0) return [];
		const body: Record<string, unknown> = {
			model: this.model,
			input: [...texts],
		};
		if (this.dimensions !== undefined) body.dimensions = this.dimensions;
		const res = await this.fetchImpl(this.url, {
			method: "POST",
			headers: this.headers,
			body: JSON.stringify(body),
		});
		if (!res.ok) {
			const text = await res.text().catch(() => "");
			throw new Error(`embeddings request failed (${res.status}): ${text.slice(0, 200)}`);
		}
		const json = (await res.json()) as EmbeddingsApiResponse;
		if (!json.data || json.data.length !== texts.length) {
			throw new Error(
				`embeddings response: expected ${texts.length} vectors, got ${json.data?.length ?? 0}`,
			);
		}
		return json.data.map((d) => {
			const arr = new Float32Array(d.embedding.length);
			for (let i = 0; i < d.embedding.length; i++) arr[i] = d.embedding[i];
			l2Normalize(arr);
			return arr;
		});
	}
}
