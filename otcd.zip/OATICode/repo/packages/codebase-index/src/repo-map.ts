import * as fs from "node:fs";
import * as path from "node:path";
import { type ExtractedSymbol, extractSymbols, languageForExtension } from "./symbol-extract";
import { walkWorkspace } from "./walker";

/**
 * 2026-06-01: Aider-style repo map. Walks the workspace, extracts top-
 * level symbols from every indexable file, and renders a compressed
 * text view the agent can drop into its system prompt. The goal: orient
 * the model with "what exists where" so it doesn't waste 50k tokens
 * grepping around to figure out the project structure.
 *
 * Token-budgeted. Per-file symbol counts get clipped, and if the full
 * map exceeds the budget we trim least-important files (no symbols,
 * trailing alphabetical) until we fit.
 */

export interface RepoMapOptions {
	/** Approximate token cap; rendering stops adding files when we'd exceed. Defaults to 8000. */
	readonly tokenBudget?: number;
	/** Max symbols rendered per file (most-significant first). Defaults to 25. */
	readonly symbolsPerFile?: number;
	/** Skip files larger than this many bytes (avoid pathological cases). Defaults to 1 MB. */
	readonly maxFileBytes?: number;
}

export interface RepoMapResult {
	readonly text: string;
	readonly filesShown: number;
	readonly filesSkipped: number;
	readonly approxTokens: number;
}

export function buildRepoMap(root: string, opts: RepoMapOptions = {}): RepoMapResult {
	const tokenBudget = opts.tokenBudget ?? 8000;
	const symbolsPerFile = opts.symbolsPerFile ?? 25;
	const maxFileBytes = opts.maxFileBytes ?? 1_000_000;

	type Entry = { relPath: string; symbols: ExtractedSymbol[] };
	const entries: Entry[] = [];
	for (const absPath of walkWorkspace(root)) {
		const ext = path.extname(absPath);
		const language = languageForExtension(ext);
		if (!language) continue;
		let content: string;
		try {
			const stat = fs.statSync(absPath);
			if (stat.size > maxFileBytes) continue;
			content = fs.readFileSync(absPath, "utf8");
		} catch {
			continue;
		}
		const syms = extractSymbols(content, language);
		if (syms.length === 0 && language !== "markdown") continue;
		entries.push({ relPath: path.relative(root, absPath).replace(/\\/g, "/"), symbols: syms });
	}
	entries.sort((a, b) => a.relPath.localeCompare(b.relPath));

	// Render each entry as a single-block, then greedily add until we'd
	// exceed the budget. Token estimate: ~4 chars per token.
	const header =
		"## Repo Map\n\nTop-level symbols per file. Use this to orient — call read_file for full contents.\n";
	const headerChars = header.length;
	const charBudget = tokenBudget * 4 - headerChars;
	const blocks: string[] = [];
	let charCount = 0;
	let filesShown = 0;
	let filesSkipped = 0;
	for (const e of entries) {
		const block = renderEntry(e.relPath, e.symbols, symbolsPerFile);
		if (charCount + block.length > charBudget) {
			filesSkipped++;
			continue;
		}
		blocks.push(block);
		charCount += block.length;
		filesShown++;
	}
	const trailer =
		filesSkipped > 0
			? `\n[Repo map truncated — ${filesSkipped} additional files not shown; call list_dir or read_file to explore.]`
			: "";
	const text = `${header}${blocks.join("\n")}${trailer}`;
	return {
		text,
		filesShown,
		filesSkipped,
		approxTokens: Math.ceil(text.length / 4),
	};
}

function renderEntry(relPath: string, symbols: ExtractedSymbol[], cap: number): string {
	if (symbols.length === 0) return `### ${relPath}\n  (no top-level symbols extracted)\n`;
	const shown = symbols.slice(0, cap);
	const overflow = symbols.length > cap ? symbols.length - cap : 0;
	const lines = shown.map(
		(s) => `  ${kindLabel(s.kind)} ${s.name}${s.exported === false ? " (private)" : ""}  :${s.line}`,
	);
	if (overflow > 0) lines.push(`  … ${overflow} more symbols not shown`);
	return `### ${relPath}\n${lines.join("\n")}\n`;
}

function kindLabel(kind: ExtractedSymbol["kind"]): string {
	switch (kind) {
		case "function":
			return "fn";
		case "class":
			return "class";
		case "interface":
			return "iface";
		case "type":
			return "type";
		case "const":
			return "const";
		case "enum":
			return "enum";
		case "heading":
			return "doc";
	}
}
