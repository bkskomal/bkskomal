/**
 * Symbol-graph helper for retrieval re-ranking.
 *
 * The codebase index gives us per-chunk semantic similarity, but a user query
 * like "how does login validate the password" leaves a lot of latent intent on
 * the table: the model knows about `validate()` *and* knows it's referenced
 * from `login.ts`, but plain embedding similarity doesn't propagate that.
 *
 * This module walks one hop of the symbol graph — given a file + a symbol
 * name, it asks the host's LSP-backed symbols provider for references and
 * definitions, dedupes the resulting file set, and returns it. The
 * `CodebaseIndex.query` path uses the returned set to apply a small boost
 * (factor 1.2) to chunks living in neighboring files. The boost is small on
 * purpose: it should nudge ordering when semantic scores are close, not
 * swamp them.
 *
 * Keeping the graph walk to a single hop is deliberate — multi-hop quickly
 * pulls in half the workspace (any file referencing `Logger.log` would be
 * "neighbor"), and the latency cost of N more LSP round-trips isn't worth
 * the marginal recall improvement on a retrieval re-rank.
 */

import type { SymbolLookupProvider } from "@oati/shared";

export interface SymbolGraphHop {
	/** Files reachable from the seed via one hop of references + definitions. */
	readonly neighbors: ReadonlySet<string>;
	/** Symbol used as the seed, for logging/debugging. */
	readonly seedSymbol: string;
	/** Whether the symbols provider was available; false → empty neighbor set. */
	readonly available: boolean;
}

/**
 * Walk one hop of the symbol graph for `symbol` declared in `path` at
 * `line`/`character`. Returns the set of neighboring file paths (workspace-
 * relative, forward-slash normalized).
 *
 * If the provider is missing, throws, or returns nothing useful, we surface
 * an empty neighbor set rather than failing — this is a re-rank signal, not
 * a primary retrieval path.
 */
export async function buildSymbolGraphHop(
	symbols: SymbolLookupProvider | undefined,
	path: string,
	line: number,
	character: number,
	symbol: string,
): Promise<SymbolGraphHop> {
	if (!symbols) {
		return { neighbors: new Set(), seedSymbol: symbol, available: false };
	}
	const out = new Set<string>();
	try {
		const refs = await symbols.findReferences(path, line, character);
		for (const r of refs) out.add(normalize(r.path));
	} catch {
		// Provider can throw if the file's language server isn't ready yet;
		// treat the same as "no refs known".
	}
	try {
		const defs = await symbols.findDefinition(path, line, character);
		for (const d of defs) out.add(normalize(d.path));
	} catch {
		// Same rationale as above.
	}
	// Don't return the seed file in its own neighbor set — the caller wants
	// *related* files, not the one they already started from.
	out.delete(normalize(path));
	return { neighbors: out, seedSymbol: symbol, available: true };
}

/**
 * Multiplicative boost for a chunk's score. Returns `factor` if `filePath` is
 * in `neighbors`, otherwise 1.0 (no-op). Pulled out so callers can apply the
 * same logic uniformly across their score arrays.
 */
export function symbolGraphBoost(
	filePath: string,
	neighbors: ReadonlySet<string>,
	factor = 1.2,
): number {
	if (neighbors.size === 0) return 1;
	if (neighbors.has(normalize(filePath))) return factor;
	return 1;
}

function normalize(p: string): string {
	return p.replace(/\\/g, "/");
}
