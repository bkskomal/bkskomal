/**
 * Kimi K2 / K2.6 native tool-call format parser.
 *
 * Background (2026-05-25 incident):
 * Phase B switched Kimi K2 from OpenAI-style function-call envelopes to
 * Cline-style inline-XML — meeting the model halfway, since inline-XML
 * matched the open-weight class's training distribution better than the
 * frontier-tuned OpenAI envelope. That helped most open-weight models.
 *
 * It did NOT fix Kimi. Kimi K2 was trained on its OWN tool-call markers
 * — special tokenizer tokens — and emits them even when we ask for
 * `<tool_name>` XML:
 *
 *     <|tool_call_begin|>functions.write_file:15<|tool_call_argument_begin|>
 *     "{"path":"apps/admin/src/pages/Settings.tsx","content":"..."}"
 *     <|tool_call_end|>
 *     <|tool_calls_section_end|>
 *
 * If the inference gateway parses these tokens out of the wire (vLLM,
 * sglang's native tool-call mode), we never see them. Most public Kimi
 * endpoints DO NOT — they stream the tokens through as raw text, and we
 * end up with markup splashed across the chat and zero tool calls
 * executed.
 *
 * This module parses those markers client-side. The principle ("harness
 * full model power, don't fight the model's training distribution") says
 * we meet Kimi where it is: accept native markers, convert to the same
 * ToolCall shape downstream consumers already use.
 *
 * Format details we handle:
 *
 *   - `<|tool_call_begin|>` opens a block.
 *   - Header (between begin and arg-begin): `functions.NAME:INDEX`,
 *     `NAME:INDEX`, or bare `NAME`. We strip the `functions.` namespace
 *     prefix and the trailing `:<digits>` index, both of which are
 *     artifacts of Kimi's prompt template — the actual tool name is
 *     what matters.
 *   - `<|tool_call_argument_begin|>` separates header from arguments.
 *   - Arguments are a JSON object — but often arrive double-wrapped:
 *     a leading `"` and trailing `"` around the actual JSON, with
 *     UNESCAPED inner quotes. We strip the outer quotes when present.
 *     `parseToolArgsLenient` handles the rest.
 *   - `<|tool_call_end|>` closes a block.
 *   - `<|tool_calls_section_end|>` is consumed as a no-op trailer.
 *
 * Streaming correctness:
 * Same invariants as InlineXmlToolParser — partial markers stay buffered
 * across SSE chunk boundaries, malformed markers fall through as text,
 * unknown tool names get treated as text.
 */

/**
 * Lenient JSON parse: strict first, then control-char repair, then a
 * `{_raw: ...}` wrap. Kept self-contained (rather than importing from
 * normalize-tool-args) so this module has no agent-core internal deps —
 * mirrors `parseToolArgsLenient` in the openai-compatible provider.
 */
function parseArgsLenient(raw: string): Record<string, unknown> {
	try {
		const v = JSON.parse(raw);
		if (v && typeof v === "object" && !Array.isArray(v)) return v as Record<string, unknown>;
	} catch {
		/* fall through */
	}
	// Second chance: escape bare control characters inside string literals.
	const repaired = escapeBareControlChars(raw);
	if (repaired !== raw) {
		try {
			const v = JSON.parse(repaired);
			if (v && typeof v === "object" && !Array.isArray(v)) return v as Record<string, unknown>;
		} catch {
			/* fall through */
		}
	}
	return { _raw: raw };
}

function escapeBareControlChars(s: string): string {
	let out = "";
	let inString = false;
	let i = 0;
	while (i < s.length) {
		const ch = s[i];
		if (!inString) {
			if (ch === '"') inString = true;
			out += ch;
			i++;
			continue;
		}
		if (ch === "\\") {
			out += ch;
			if (i + 1 < s.length) {
				out += s[i + 1];
				i += 2;
			} else {
				i++;
			}
			continue;
		}
		if (ch === '"') {
			inString = false;
			out += ch;
			i++;
			continue;
		}
		const code = ch.charCodeAt(0);
		if (code === 0x0a) out += "\\n";
		else if (code === 0x0d) out += "\\r";
		else if (code === 0x09) out += "\\t";
		else if (code < 0x20) out += `\\u${code.toString(16).padStart(4, "0")}`;
		else out += ch;
		i++;
	}
	return out;
}

export interface KimiNativeChunk {
	/** Plain text the user sees (markup stripped). */
	readonly text: string;
	/** Tool calls fully assembled from this chunk. */
	readonly toolCalls: readonly KimiParsedToolCall[];
}

export interface KimiParsedToolCall {
	readonly name: string;
	readonly args: Readonly<Record<string, unknown>>;
	readonly id: string;
}

const BEGIN = "<|tool_call_begin|>";
const ARG_BEGIN = "<|tool_call_argument_begin|>";
const END = "<|tool_call_end|>";
const SECTION_END = "<|tool_calls_section_end|>";

/**
 * Strip Kimi's prompt-template artifacts off the wire tool name so we get
 * back to the bare name that's registered in our ToolRegistry:
 *
 *   `functions.write_file:15`  → `write_file`
 *   `write_file:3`             → `write_file`
 *   `write_file`               → `write_file`
 *
 * Whitespace is trimmed. Empty result returns "".
 */
function normalizeToolName(raw: string): string {
	let name = raw.trim();
	if (name.startsWith("functions.")) name = name.slice("functions.".length);
	// Strip trailing `:<digits>` index suffix (Kimi numbers tool calls
	// within a turn — we don't need the index, downstream gives every
	// call its own id).
	name = name.replace(/:\d+$/, "");
	return name;
}

/**
 * Args often arrive as `"{"path":"...","content":"..."}"` — a `"` wrapping
 * a JSON object with UNESCAPED inner quotes. That's not valid JSON-of-
 * JSON (proper double-encoding would escape the inner quotes), it's a
 * stray pair of quotes from Kimi's tokenization artifact. Strip them
 * when they bracket the whole payload and the inner content looks like
 * an object.
 */
function unwrapArgPayload(payload: string): string {
	const trimmed = payload.trim();
	if (trimmed.length < 2) return trimmed;
	const first = trimmed[0];
	const last = trimmed[trimmed.length - 1];
	if (first === '"' && last === '"') {
		const inner = trimmed.slice(1, -1).trim();
		// Only unwrap if the inner content looks like a JSON object.
		// Defends against legitimate cases where the payload IS a quoted
		// string (rare, but possible if the tool takes a single string arg).
		if (inner.startsWith("{") && inner.endsWith("}")) return inner;
	}
	return trimmed;
}

export class KimiNativeToolParser {
	private readonly known: ReadonlySet<string>;
	private seq = 0;
	/** Unscanned bytes from the wire. */
	private pending = "";
	private state: ParserState = "idle";
	/** Buffer for the current block's header (between BEGIN and ARG_BEGIN). */
	private headerBuf = "";
	/** Buffer for the current block's args (between ARG_BEGIN and END). */
	private argBuf = "";

	constructor(knownToolNames: readonly string[]) {
		this.known = new Set(knownToolNames);
	}

	feed(chunk: string): KimiNativeChunk {
		if (chunk.length === 0) return EMPTY_CHUNK;
		this.pending += chunk;
		return this.drain(false);
	}

	finalize(): KimiNativeChunk {
		return this.drain(true);
	}

	/**
	 * Scan `pending` looking for marker boundaries. Three states:
	 *   idle      — plain text; on `<|tool_call_begin|>` → inHeader
	 *   inHeader  — collecting tool name; on `<|tool_call_argument_begin|>` → inArgs
	 *   inArgs    — collecting JSON args; on `<|tool_call_end|>` → emit + idle
	 *
	 * Section-end marker (`<|tool_calls_section_end|>`) is silently
	 * consumed wherever it appears in `idle`.
	 *
	 * Streaming safety: when a marker is partially present at the end of
	 * `pending`, we hold the suffix from the last `<` (or first `<` if
	 * none of the markers match yet) and wait for the next chunk. On
	 * `isFinal=true` we flush any pending state and emit unconsumed text.
	 */
	private drain(isFinal: boolean): KimiNativeChunk {
		let outText = "";
		const outCalls: KimiParsedToolCall[] = [];

		// End-of-stream salvage path: drain may not enter the loop at all
		// if `pending` was already exhausted by an earlier feed() call
		// that left us mid-block. The state machine still has buffered
		// content in `headerBuf` / `argBuf` that we need to either
		// resolve into a tool call (best-effort JSON parse on partial
		// args) or re-emit as literal text. Done BEFORE the loop so the
		// loop body sees consistent state on the rare case `pending` has
		// also accumulated since the prior call.
		if (isFinal && this.pending.length === 0) {
			if (this.state === "inArgs") {
				// Try to recover a tool call from what we managed to
				// buffer; lenient parse falls back to `{_raw: ...}` so
				// we never silently drop a partial block.
				this.flushBlock(outCalls);
				this.state = "idle";
			} else if (this.state === "inHeader") {
				// Header never closed. Re-emit as text — there's no
				// useful tool call to assemble from a bare name.
				outText += `${"<|tool_call_begin|>"}${this.headerBuf}`;
				this.headerBuf = "";
				this.state = "idle";
			}
		}

		outer: while (this.pending.length > 0) {
			switch (this.state) {
				case "idle": {
					// Search for the next marker boundary or `<` character.
					// We want to flush everything BEFORE the marker as text.
					const beginIdx = this.pending.indexOf(BEGIN);
					const sectionIdx = this.pending.indexOf(SECTION_END);
					// Pick whichever marker comes first (or -1 if neither).
					const firstIdx = pickFirst(beginIdx, sectionIdx);
					if (firstIdx === -1) {
						// No complete marker visible. Look for the last `<` —
						// it might be the start of a partial marker we should
						// hold for the next chunk.
						const lastLt = this.pending.lastIndexOf("<");
						if (lastLt === -1 || isFinal) {
							// Either no `<` at all, or we're finalizing —
							// flush everything as text.
							outText += this.pending;
							this.pending = "";
							break outer;
						}
						// Could be a partial marker — but only if the suffix
						// from lastLt could grow into BEGIN or SECTION_END.
						// Cheap check: if the suffix isn't a prefix of any
						// marker, flush including the `<`.
						const suffix = this.pending.slice(lastLt);
						if (couldBeMarkerPrefix(suffix)) {
							outText += this.pending.slice(0, lastLt);
							this.pending = suffix;
							break outer;
						}
						outText += this.pending;
						this.pending = "";
						break outer;
					}
					// Found a marker. Flush text before it.
					if (firstIdx > 0) outText += this.pending.slice(0, firstIdx);
					// Consume whichever marker we hit.
					if (firstIdx === sectionIdx && (beginIdx === -1 || sectionIdx < beginIdx)) {
						this.pending = this.pending.slice(sectionIdx + SECTION_END.length);
						// stay in idle
					} else {
						this.pending = this.pending.slice(beginIdx + BEGIN.length);
						this.headerBuf = "";
						this.state = "inHeader";
					}
					break;
				}
				case "inHeader": {
					const argBeginIdx = this.pending.indexOf(ARG_BEGIN);
					if (argBeginIdx === -1) {
						// Need more bytes. Drain pending into headerBuf,
						// EXCEPT a possible partial marker at the tail.
						const lastLt = this.pending.lastIndexOf("<");
						if (lastLt === -1 || !couldBeMarkerPrefix(this.pending.slice(lastLt))) {
							this.headerBuf += this.pending;
							this.pending = "";
						} else {
							this.headerBuf += this.pending.slice(0, lastLt);
							this.pending = this.pending.slice(lastLt);
						}
						if (isFinal) {
							// Stream ended mid-header. Salvage as text.
							outText += `${BEGIN}${this.headerBuf}${this.pending}`;
							this.headerBuf = "";
							this.pending = "";
							this.state = "idle";
						}
						break outer;
					}
					this.headerBuf += this.pending.slice(0, argBeginIdx);
					this.pending = this.pending.slice(argBeginIdx + ARG_BEGIN.length);
					this.argBuf = "";
					this.state = "inArgs";
					break;
				}
				case "inArgs": {
					const endIdx = this.pending.indexOf(END);
					if (endIdx === -1) {
						const lastLt = this.pending.lastIndexOf("<");
						if (lastLt === -1 || !couldBeMarkerPrefix(this.pending.slice(lastLt))) {
							this.argBuf += this.pending;
							this.pending = "";
						} else {
							this.argBuf += this.pending.slice(0, lastLt);
							this.pending = this.pending.slice(lastLt);
						}
						if (isFinal) {
							// Stream ended mid-args. Try to parse what we
							// have anyway; many partial-but-complete-enough
							// JSON payloads succeed.
							this.flushBlock(outCalls);
							if (this.pending.length > 0) {
								outText += this.pending;
								this.pending = "";
							}
							this.state = "idle";
						}
						break outer;
					}
					this.argBuf += this.pending.slice(0, endIdx);
					this.pending = this.pending.slice(endIdx + END.length);
					this.flushBlock(outCalls);
					this.state = "idle";
					break;
				}
			}
		}
		return { text: outText, toolCalls: outCalls };
	}

	private flushBlock(out: KimiParsedToolCall[]): void {
		const name = normalizeToolName(this.headerBuf);
		this.headerBuf = "";
		const payload = unwrapArgPayload(this.argBuf);
		this.argBuf = "";
		if (name.length === 0) return;
		// Tools not in the registry are silently dropped — same policy as
		// InlineXmlToolParser. Model called a tool we don't expose; the
		// downstream agent will surface that via the normal "unknown tool"
		// path if it ever materializes.
		if (this.known.size > 0 && !this.known.has(name)) return;
		const args = parseArgsLenient(payload);
		out.push({
			name,
			args,
			id: `kn_${name}_${this.seq++}`,
		});
	}
}

type ParserState = "idle" | "inHeader" | "inArgs";

const EMPTY_CHUNK: KimiNativeChunk = { text: "", toolCalls: [] };

function pickFirst(a: number, b: number): number {
	if (a === -1) return b;
	if (b === -1) return a;
	return a < b ? a : b;
}

/**
 * Could the given string (which starts with `<`) grow into one of the
 * Kimi markers? Used to decide whether to hold or flush a tail `<` when
 * we don't yet have enough bytes to see a complete marker.
 */
function couldBeMarkerPrefix(s: string): boolean {
	return (
		BEGIN.startsWith(s) || ARG_BEGIN.startsWith(s) || END.startsWith(s) || SECTION_END.startsWith(s)
	);
}
