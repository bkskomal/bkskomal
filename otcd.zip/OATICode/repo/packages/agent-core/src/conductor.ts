import type {
	AgentEvent,
	ConversationMessage,
	HostContext,
	MessagePart,
	ModeConfig,
	PlanV2,
	ToolSpec,
} from "@oati/shared";
import { Agent, type AgentOptions, type EventListener } from "./agent";
import { runCritic } from "./critic";
import { planRequest, planV2ToPromptSection } from "./planner-v2";
import type { ProviderRegistry } from "./provider-registry";
import type { ToolRegistry } from "./tool-registry";

export interface ConductorDeps {
	readonly providers: ProviderRegistry;
	readonly tools: ToolRegistry;
	readonly host: HostContext;
}

export interface SpawnRequest {
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly userMessage: string;
	readonly history?: readonly ConversationMessage[];
	readonly signal?: AbortSignal;
	/** Extra non-text parts (e.g. image attachments) for this user turn. */
	readonly userParts?: readonly MessagePart[];
	/**
	 * Visibility scope for the tools this spawn sees. When `"sub-agent"`, the
	 * conductor includes tools marked `scope: "sub-agent"` (e.g. the shared
	 * scratchpad ones). Default omits them.
	 */
	readonly toolScope?: "sub-agent";
	/**
	 * Host override applied only inside this spawn — used by
	 * `spawnSubAgentsParallel` to give each sub-agent a wrapped HostContext that
	 * routes scratchpad reads/writes into the parent's bucket.
	 */
	readonly hostOverride?: HostContext;
}

export class Conductor {
	private readonly listeners = new Set<EventListener>();
	private nextId = 1;
	private readonly active = new Map<string, Agent>();
	// R7-C bug fix: previously `cancelAll()` just emptied the active map without
	// actually signalling the in-flight agents, so calls continued to stream
	// from the provider until they completed naturally. Track per-agent
	// AbortControllers so cancelAll() can hard-stop every active run.
	private readonly aborts = new Map<string, AbortController>();

	constructor(private readonly deps: ConductorDeps) {}

	on(listener: EventListener): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	private fanOut(event: AgentEvent): void {
		for (const fn of this.listeners) fn(event);
	}

	/**
	 * 2026-05-25: mid-turn injection. The host calls this when the user
	 * sends a chat message while an agent is already running. We forward
	 * to whichever active agent is the executor (single-agent case) or
	 * fan out to every active agent (parallel case). The agent's own
	 * iteration-boundary drain picks the message up at the next safe
	 * insertion point.
	 *
	 * Returns the count of agents the message was queued onto, so the
	 * host can show "Queued (×1)" vs nothing happened when no agent is
	 * actually running.
	 */
	enqueueUserMessage(text: string): number {
		let delivered = 0;
		for (const agent of this.active.values()) {
			agent.enqueueUserMessage(text);
			delivered++;
		}
		return delivered;
	}

	/**
	 * Fire-and-forget sibling spawn. Used by the mid-turn `parallel` flow:
	 * when the user sends a new message while an agent is already working,
	 * the host calls this to start a SECOND agent immediately instead of
	 * queuing the message onto the primary agent's drain.
	 *
	 * The returned promise resolves to the spawned agent's id once the
	 * conductor has registered it. The actual run completes asynchronously
	 * — errors are reported via the existing `error` AgentEvent fan-out so
	 * callers don't need to await the run themselves.
	 *
	 * The sibling shares the same mode + provider + tools but gets an
	 * independent abort controller, history, and event stream (tagged with
	 * its own `agentId`). The primary agent is NOT affected and continues
	 * its iteration unmolested.
	 */
	spawnParallel(req: SpawnRequest): { readonly agentId: string } {
		// Reserve an id synchronously so the caller can correlate events.
		const agentId = `p${this.nextId++}`;
		// Dispatch the run on a microtask so the caller returns immediately.
		void this.runDetached(agentId, req);
		return { agentId };
	}

	private async runDetached(reservedId: string, req: SpawnRequest): Promise<void> {
		try {
			await this.spawnWithId(reservedId, req);
		} catch (err) {
			this.fanOut({
				type: "error",
				agentId: reservedId,
				message: `Parallel agent failed: ${err instanceof Error ? err.message : String(err)}`,
			});
		}
	}

	/** True iff at least one active agent has queued user input. */
	hasPendingUserInput(): boolean {
		for (const agent of this.active.values()) {
			if (agent.hasPendingUserInput()) return true;
		}
		return false;
	}

	/** True iff at least one agent is currently running. */
	isAnyAgentActive(): boolean {
		return this.active.size > 0;
	}

	cancelAll(): void {
		for (const ctrl of this.aborts.values()) {
			try {
				ctrl.abort();
			} catch {
				/* abort() never throws but be defensive */
			}
		}
		this.aborts.clear();
		this.active.clear();
	}

	async spawn(req: SpawnRequest): Promise<readonly ConversationMessage[]> {
		const id = `a${this.nextId++}`;
		return this.spawnWithId(id, req);
	}

	private async spawnWithId(id: string, req: SpawnRequest): Promise<readonly ConversationMessage[]> {
		if (this.active.size >= req.mode.maxParallelAgents) {
			throw new Error(
				`Parallel agent cap reached (${req.mode.maxParallelAgents}); current=${this.active.size}`,
			);
		}

		const providerId = req.mode.providerId ?? this.deps.providers.list()[0]?.id;
		if (!providerId) throw new Error("No providers registered");

		const provider = this.deps.providers.require(providerId);
		const tools = this.gatherTools(req.mode.enabledTools, req.toolScope);
		const options: AgentOptions = { modelId: req.modelId };
		const host = req.hostOverride ?? this.deps.host;

		// --- PLANNER stage (optional) ----------------------------------------
		// Phase 5 (2026-06-04): conductor's auto-planner uses V2 planRequest.
		// The plan is emitted as a `plan` AgentEvent carrying a PlanV2; the
		// chat-panel translates it into a `plan_proposed` webview message so
		// the PlanEditor side panel renders the steps. The executor stage
		// runs immediately afterwards — auto-mode does NOT wait for user
		// approval (slash `/plan` is the approval-gated path).
		let plan: PlanV2 | undefined;
		if (req.mode.enablePlanner) {
			this.fanOut({ type: "stage_started", agentId: id, stage: "planner" });
			try {
				const rawPlan = await planRequest({
					provider,
					modelId: req.mode.plannerModelId ?? req.modelId,
					userTask: req.userMessage,
					...(req.signal ? { signal: req.signal } : {}),
				});
				// Auto-mode flips the state to "executing" so the editor
				// renders read-only — users can't edit a plan that's already
				// being run.
				plan = { ...rawPlan, state: "executing" };
				this.fanOut({ type: "plan", agentId: id, plan });
			} catch (err) {
				this.fanOut({
					type: "error",
					agentId: id,
					message: `Planner stage failed: ${err instanceof Error ? err.message : String(err)}`,
				});
			} finally {
				this.fanOut({ type: "stage_done", agentId: id, stage: "planner" });
			}
		}

		// --- EXECUTOR stage --------------------------------------------------
		this.fanOut({ type: "stage_started", agentId: id, stage: "executor" });

		const executorMode: ModeConfig = plan
			? {
					...req.mode,
					systemPrompt: combinePrompt(req.mode.systemPrompt, planV2ToPromptSection(plan)),
				}
			: req.mode;

		const agent = new Agent(
			{ id, provider, tools, host, mode: executorMode },
			options,
			req.history ?? [],
		);
		const offExec = agent.on((ev) => this.fanOut(ev));
		this.active.set(id, agent);
		// R7-C: register an AbortController so cancelAll() can actually stop us.
		// We chain to the caller-supplied signal so external aborts still flow.
		const execAbort = linkAbort(req.signal);
		this.aborts.set(id, execAbort);

		try {
			await agent.run({
				userMessage: req.userMessage,
				userParts: req.userParts,
				signal: execAbort.signal,
			});
		} finally {
			offExec();
			this.active.delete(id);
			this.aborts.delete(id);
			this.fanOut({ type: "stage_done", agentId: id, stage: "executor" });
		}

		let history: readonly ConversationMessage[] = agent.getHistory();

		// --- CRITIC stage (optional, with up to maxRetries retries) ----------
		if (req.mode.enableCritic) {
			const maxRetries = req.mode.maxRetries ?? 1;
			for (let attempt = 0; attempt <= maxRetries; attempt++) {
				if (req.signal?.aborted) break;

				this.fanOut({ type: "stage_started", agentId: id, stage: "critic" });
				let critique: import("@oati/shared").Critique;
				try {
					critique = await runCritic({
						provider,
						modelId: req.mode.criticModelId ?? req.modelId,
						userTask: req.userMessage,
						executorSummary: extractFinalAssistantText(history),
						signal: req.signal,
					});
					this.fanOut({ type: "critique", agentId: id, critique });
				} catch (err) {
					this.fanOut({
						type: "error",
						agentId: id,
						message: `Critic stage failed: ${err instanceof Error ? err.message : String(err)}`,
					});
					break;
				} finally {
					this.fanOut({ type: "stage_done", agentId: id, stage: "critic" });
				}

				if (critique.verdict === "approved" || attempt >= maxRetries) break;

				// Retry: run the executor again with the critic's feedback as the next user turn.
				this.fanOut({
					type: "retry",
					agentId: id,
					attempt: attempt + 1,
					reason: critique.feedback ?? "Critic requested revision",
				});

				if (this.active.size >= req.mode.maxParallelAgents) break;
				const retryId = `${id}_r${attempt + 1}`;
				const retryAgent = new Agent(
					{ id: retryId, provider, tools, host, mode: executorMode },
					options,
					history,
				);
				const offRetry = retryAgent.on((ev) => this.fanOut(ev));
				this.active.set(retryId, retryAgent);
				const retryAbort = linkAbort(req.signal);
				this.aborts.set(retryId, retryAbort);

				this.fanOut({ type: "stage_started", agentId: id, stage: "executor" });
				try {
					await retryAgent.run({
						userMessage: `[Critic feedback]\n${critique.feedback ?? ""}`.trim(),
						signal: retryAbort.signal,
					});
				} finally {
					offRetry();
					this.active.delete(retryId);
					this.aborts.delete(retryId);
					this.fanOut({ type: "stage_done", agentId: id, stage: "executor" });
				}
				history = retryAgent.getHistory();
			}
		}

		return history;
	}

	private gatherTools(filter: ModeConfig["enabledTools"], scope?: "sub-agent"): ToolSpec[] {
		if (filter === "all") return this.deps.tools.list({ scope });
		return this.deps.tools.list({ filter, scope });
	}
}

function combinePrompt(systemPrompt: string, addition: string): string {
	if (!addition) return systemPrompt;
	return `${systemPrompt}\n\n${addition}`;
}

/**
 * R7-C: Create an AbortController that aborts when `parent` aborts. Used to
 * give the Conductor a handle to cancel each in-flight agent run without
 * losing the caller's own abort plumbing.
 */
function linkAbort(parent: AbortSignal | undefined): AbortController {
	const ctrl = new AbortController();
	if (!parent) return ctrl;
	if (parent.aborted) {
		ctrl.abort();
		return ctrl;
	}
	const onAbort = () => ctrl.abort();
	parent.addEventListener("abort", onAbort, { once: true });
	// When our local controller aborts (e.g. via cancelAll), drop the listener
	// from the parent so we don't pin it after we're done.
	ctrl.signal.addEventListener("abort", () => parent.removeEventListener("abort", onAbort), {
		once: true,
	});
	return ctrl;
}

function extractFinalAssistantText(history: readonly ConversationMessage[]): string {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		const chunks: string[] = [];
		for (const p of msg.parts) if (p.kind === "text") chunks.push(p.text);
		const text = chunks.join("");
		if (text.trim().length > 0) return text;
	}
	return "(agent produced no text output)";
}
