// Phase 2.2 (2026-05-23): tool filter at dispatch.
//
// Given the model the agent is about to run, drop tools the model
// can't reliably use. Today that means hiding `spawn_agent` /
// `spawn_parallel_agents` from small open-weight + local models that
// lose track of concurrent sub-agent results in their context. The
// model never sees the tool in its tool list, so it never tries to
// call it — no confused "tool failed" output, no wasted iterations.
//
// Single point of policy: the mapping from the tool-side
// `ToolCapabilityRequirement` enum to the `ModelQuirks` boolean field
// lives here. Adding a new capability is one row in the switch.
//
// Pure function — no IO. Trivially testable.

import { type ModelQuirks, type ToolSpec, detectModelQuirks } from "@oati/shared";

/**
 * Filter a tool list down to the tools the active model can actually
 * use. When `modelId` is undefined or unknown, conservative defaults
 * apply (no spawn-sub-agents, no plan) — better to give the model a
 * smaller toolbelt than to silently let a weak model attempt orchestration.
 *
 * Returns a NEW array. The original is not mutated; this is safe to
 * call from multiple places without surprising shared-state effects.
 *
 * Tools without a `requiredCapability` are always included.
 */
export function filterToolsForModel(
	tools: readonly ToolSpec[],
	modelId: string | undefined,
): ToolSpec[] {
	const quirks = detectModelQuirks(modelId ?? "");
	return tools.filter((t) => isToolAllowedForQuirks(t, quirks));
}

/**
 * Lower-level variant for callers that already have the quirks
 * resolved (avoids the regex walk in `detectModelQuirks` on hot paths).
 */
export function isToolAllowedForQuirks(tool: ToolSpec, quirks: ModelQuirks): boolean {
	if (!tool.requiredCapability) return true;
	switch (tool.requiredCapability) {
		case "spawn-sub-agents":
			return quirks.canSpawnSubAgents;
		case "plan":
			return quirks.canPlan;
		default: {
			// Compile-time exhaustiveness check. If a new capability is
			// added to ToolCapabilityRequirement without updating this
			// switch, TypeScript will flag the assignment below. At
			// runtime, conservative default: hide the tool. Better to
			// silently miss a feature than crash the agent loop.
			const _exhaustive: never = tool.requiredCapability;
			void _exhaustive;
			return false;
		}
	}
}
