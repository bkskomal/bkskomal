// 2026-05-29: critic battle-test fixtures.
//
// A curated set of realistic (task, executor_summary, critic_reply) tuples
// that exercise the critic across the situations it actually meets in
// production. We need this for three reasons:
//
//   1. PARSER REGRESSION GUARD — when someone tweaks the critic's prompt or
//      tag format, these fixtures catch parser breakage immediately.
//   2. DOCUMENTED EXPECTED BEHAVIOR — the fixture file is the canonical
//      answer to "what should the critic do in case X?". A reviewer can
//      read it without spinning up an LLM.
//   3. GROUND TRUTH FOR REAL-LLM EVAL — a separate opt-in script (not part
//      of the test suite) replays each task + executor_summary against the
//      configured provider and compares the LIVE critic's verdict to the
//      fixture's expected verdict. Precision/recall fall out for free.
//
// Categories:
//   - "approval"  — agent did the work; critic should approve.
//   - "rejection" — agent gave up / shipped broken work; critic should reject.
//   - "edge"      — ambiguous or noisy critic responses; we document the
//                   defensive default (approve to avoid wasted retries).

export type CriticBattleCategory = "approval" | "rejection" | "edge";

export interface CriticBattleCase {
	readonly name: string;
	readonly category: CriticBattleCategory;
	readonly task: string;
	readonly executorSummary: string;
	/** What the critic LLM would emit for this case (used for parser tests). */
	readonly mockedCriticReply: string;
	/** Verdict we expect parseCritique to produce. */
	readonly expectedVerdict: "approved" | "needs_retry";
	/** When verdict is needs_retry, the feedback should mention this substring. */
	readonly expectedFeedbackContains?: string;
}

export const CRITIC_BATTLE_CASES: readonly CriticBattleCase[] = [
	// === APPROVAL CASES ============================================
	{
		name: "simple-rename-completed",
		category: "approval",
		task: "Rename `parseFoo` to `parseBar` across the codebase.",
		executorSummary:
			"Updated parseFoo → parseBar in src/foo.ts (definition) and 3 import sites in src/{a,b,c}.ts. Tests pass.",
		mockedCriticReply: `<critique>{"verdict":"approved"}</critique>`,
		expectedVerdict: "approved",
	},
	{
		name: "bug-fix-with-regression-test",
		category: "approval",
		task: "Fix the off-by-one in pagination — page 1 currently shows results 0-9 instead of 1-10.",
		executorSummary:
			"Fixed offset calculation in paginate.ts (changed `start = page * size` to `start = (page - 1) * size`). Added regression test in paginate.test.ts that exercises page=1 and page=5. Both pass.",
		mockedCriticReply: `<critique>{"verdict":"approved"}</critique>`,
		expectedVerdict: "approved",
	},
	{
		name: "approved-with-leading-whitespace",
		category: "approval",
		task: "Add a healthcheck endpoint.",
		executorSummary: "Added GET /healthz returning {status:'ok'}. Test passes.",
		mockedCriticReply: `  <critique>\n  {"verdict":"approved"}\n  </critique>  `,
		expectedVerdict: "approved",
	},
	{
		name: "approved-case-insensitive-tag",
		category: "approval",
		task: "Add a comment explaining the cache TTL choice.",
		executorSummary:
			"Added a 3-line comment above CACHE_TTL_MS explaining the 5-min Anthropic cache.",
		mockedCriticReply: `<CRITIQUE>{"verdict":"approved"}</CRITIQUE>`,
		expectedVerdict: "approved",
	},

	// === REJECTION CASES ===========================================
	{
		name: "gave-up-partway",
		category: "rejection",
		task: "Replace all uses of `axios` with `fetch` across the API client.",
		executorSummary:
			"I migrated 2 of the 6 axios call sites and stopped because the interceptor pattern is complex. The remaining 4 sites still use axios.",
		mockedCriticReply: `<critique>{"verdict":"needs_retry","feedback":"4 of 6 call sites still use axios — the migration is incomplete. Continue with the remaining sites using the same fetch wrapper you introduced in src/client/a.ts."}</critique>`,
		expectedVerdict: "needs_retry",
		expectedFeedbackContains: "incomplete",
	},
	{
		name: "claimed-done-but-tests-fail",
		category: "rejection",
		task: "Implement the user-profile API endpoint per spec.",
		executorSummary:
			"Implemented GET /users/:id. Tests run but 3 of 8 fail — they expect a 404 on missing users but the handler returns 500.",
		mockedCriticReply: `<critique>{"verdict":"needs_retry","feedback":"3 of 8 tests fail. The missing-user case should return 404, not 500 — add a not-found check before serialization."}</critique>`,
		expectedVerdict: "needs_retry",
		expectedFeedbackContains: "404",
	},
	{
		name: "missed-the-core-ask",
		category: "rejection",
		task: "Add input validation to prevent SQL injection on the /search endpoint.",
		executorSummary:
			"I added a length check (max 200 chars) on the query param and a regression test for that. Length validation is in place.",
		mockedCriticReply: `<critique>{"verdict":"needs_retry","feedback":"Length check does not prevent SQL injection — the core ask was input sanitization or parameterized queries. Replace string interpolation in db.query with parameterized binding."}</critique>`,
		expectedVerdict: "needs_retry",
		expectedFeedbackContains: "parameterized",
	},
	{
		name: "rejection-with-trailing-noise",
		category: "rejection",
		task: "Delete the deprecated /v1 routes.",
		executorSummary: "Removed routes/v1/index.ts.",
		mockedCriticReply: `<critique>{"verdict":"needs_retry","feedback":"Only deleted the index — the v1/*.ts handler files and their tests still reference paths that no longer route. Sweep the v1 directory and its imports."}</critique>\n\n[stop]`,
		expectedVerdict: "needs_retry",
		expectedFeedbackContains: "v1",
	},

	// === EDGE CASES =================================================
	{
		name: "missing-feedback-on-rejection",
		category: "edge",
		task: "Add a /metrics endpoint.",
		executorSummary: "Done.",
		mockedCriticReply: `<critique>{"verdict":"needs_retry"}</critique>`,
		expectedVerdict: "needs_retry",
		expectedFeedbackContains: "without specifying",
	},
	{
		name: "unknown-verdict-defaults-to-approved",
		category: "edge",
		task: "Add unit tests for the formatter.",
		executorSummary: "Added 4 unit tests covering the documented cases.",
		mockedCriticReply: `<critique>{"verdict":"maybe"}</critique>`,
		expectedVerdict: "approved",
	},
	{
		name: "no-tags-defaults-to-approved",
		category: "edge",
		task: "Format the README.",
		executorSummary: "Re-flowed the README to 80 cols.",
		mockedCriticReply: "Looks fine to me, no issues spotted.",
		expectedVerdict: "approved",
	},
	{
		name: "malformed-json-defaults-to-approved",
		category: "edge",
		task: "Rename a variable.",
		executorSummary: "Renamed userId → user_id in three files.",
		mockedCriticReply: "<critique>{verdict: needs_retry, feedback: ???}</critique>",
		expectedVerdict: "approved",
	},
	{
		name: "empty-critique-tags",
		category: "edge",
		task: "Bump the version to 1.2.0.",
		executorSummary: "Updated package.json version to 1.2.0.",
		mockedCriticReply: "<critique></critique>",
		expectedVerdict: "approved",
	},
];

/**
 * Returns counts by category. Useful for the opt-in real-LLM eval script
 * to report coverage / precision / recall scoped per bucket.
 */
export function countByCategory(
	cases: readonly CriticBattleCase[] = CRITIC_BATTLE_CASES,
): Readonly<Record<CriticBattleCategory, number>> {
	const acc: Record<CriticBattleCategory, number> = { approval: 0, rejection: 0, edge: 0 };
	for (const c of cases) acc[c.category]++;
	return acc;
}
