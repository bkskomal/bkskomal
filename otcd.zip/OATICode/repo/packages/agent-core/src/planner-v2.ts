// R6-A: Structured Plan v2 — `planner-v2.ts`.
//
// Two entry points:
//
//   - `planRequest(request, opts)`  one-shot LLM call → `PlanV2` (3-8 steps,
//     each with title/body/dependsOn). Strict JSON parsing with one retry
//     on malformed output.
//   - `executePlan(plan, opts)`     walks the steps in topological order and
//     dispatches each as its own `Conductor.spawn()` turn. A tiny critic
//     call after each step grades it against its acceptance criterion; on
//     "No" the step is marked failed with up to one retry.

import type {
	ConversationMessage,
	ModeConfig,
	PlanStepStatus,
	PlanV2,
	PlanV2Step,
	ProviderSpec,
} from "@oati/shared";
import type { Conductor } from "./conductor";

const PLANNER_V2_SYSTEM_PROMPT = `You are an expert task planner producing a STRUCTURED plan.

Constraints:
- 3 to 8 steps total.
- Each step must have:
  * a stable id ("s1", "s2", ...),
  * a short title (one line, action-oriented),
  * a body that includes a CONCRETE acceptance criterion ("Done when ...") so a downstream agent can verify it,
  * an optional dependsOn array listing the ids of prerequisite steps when ordering matters.
- Use dependsOn only when the step truly needs the predecessor's output; parallelizable steps should omit it.

Respond ONLY with JSON wrapped in <plan-v2>...</plan-v2> tags in this exact shape:

<plan-v2>
{
  "goal": "<one-line restatement of the user's request>",
  "steps": [
    { "id": "s1", "title": "Inspect the module", "body": "Read foo.ts and list all exports. Done when the exports are enumerated.", "dependsOn": [] },
    { "id": "s2", "title": "Refactor exports", "body": "Apply the rename. Done when src and tests pass.", "dependsOn": ["s1"] }
  ]
}
</plan-v2>

Emit nothing outside the tags.`;

export interface PlanRequestOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	readonly userTask: string;
	readonly signal?: AbortSignal;
	/** Defaults to 0.1 — structured plans want determinism. */
	readonly temperature?: number;
	/** When true, skip the one-shot malformed-output retry (used by tests). */
	readonly disableRetry?: boolean;
	/** Override the id factory; tests pass a deterministic stub. */
	readonly makeId?: () => string;
	/** Override the timestamp factory; tests pass a fixed value. */
	readonly now?: () => Date;
}

/**
 * Issue a single LLM call asking for a `PlanV2`. On a malformed/unparseable
 * response the request is retried exactly once with a stricter reminder; if
 * the retry also fails, a placeholder plan with a single "fix-up" step is
 * returned so the caller still has something to render.
 */
export async function planRequest(opts: PlanRequestOptions): Promise<PlanV2> {
	const first = await oneShotPlan(opts, false);
	if (first.steps.length >= 3) return first;
	if (opts.disableRetry) return first;
	const retry = await oneShotPlan(opts, true);
	if (retry.steps.length >= 1) return retry;
	// Final fallback so executePlan still has something to walk.
	return {
		id: makePlanId(opts),
		goal: opts.userTask,
		steps: [
			{
				id: "s1",
				title: "Address the request",
				body: `${opts.userTask}\n\nDone when the user's request has been addressed.`,
				status: "pending",
			},
		],
		createdAt: nowIso(opts),
		state: "draft",
	};
}

async function oneShotPlan(opts: PlanRequestOptions, stricter: boolean): Promise<PlanV2> {
	const chunks: string[] = [];
	const stream = opts.provider.stream({
		messages: [
			{
				role: "user",
				parts: [{ kind: "text", text: opts.userTask }],
			},
		],
		modelId: opts.modelId,
		systemPrompt:
			PLANNER_V2_SYSTEM_PROMPT +
			(stricter
				? "\n\nPREVIOUS RESPONSE WAS NOT VALID JSON. Strictly emit ONE <plan-v2>{...}</plan-v2> block. No prose."
				: ""),
		temperature: opts.temperature ?? 0.1,
		signal: opts.signal,
	});
	for await (const ev of stream) {
		if (ev.type === "text_delta") chunks.push(ev.text);
	}
	return parsePlanV2(chunks.join(""), opts);
}

export interface ParseOptions {
	readonly makeId?: () => string;
	readonly now?: () => Date;
}

/**
 * Strictly parse a `PlanV2` out of an LLM reply. Returns a draft plan with
 * `steps` empty when the tag is missing / JSON malformed / steps array is
 * empty so the caller can decide whether to retry.
 */
export function parsePlanV2(raw: string, opts?: ParseOptions): PlanV2 {
	const id = makePlanId(opts);
	const createdAt = nowIso(opts);
	const match = /<plan-v2>([\s\S]*?)<\/plan-v2>/i.exec(raw);
	if (!match) return { id, goal: "", steps: [], createdAt, state: "draft" };
	const inner = match[1].trim();
	let parsed: { goal?: unknown; steps?: unknown };
	try {
		parsed = JSON.parse(inner) as { goal?: unknown; steps?: unknown };
	} catch {
		return { id, goal: "", steps: [], createdAt, state: "draft" };
	}
	const goal = typeof parsed.goal === "string" ? parsed.goal : "";
	if (!Array.isArray(parsed.steps)) return { id, goal, steps: [], createdAt, state: "draft" };
	const steps: PlanV2Step[] = [];
	for (const s of parsed.steps as unknown[]) {
		if (typeof s !== "object" || s === null) continue;
		const obj = s as {
			id?: unknown;
			title?: unknown;
			body?: unknown;
			dependsOn?: unknown;
			estimatedTokens?: unknown;
		};
		const title = typeof obj.title === "string" ? obj.title.trim() : "";
		const body = typeof obj.body === "string" ? obj.body.trim() : "";
		if (title.length === 0 || body.length === 0) continue;
		const stepId =
			typeof obj.id === "string" && obj.id.trim().length > 0 ? obj.id.trim() : `s${steps.length + 1}`;
		const dependsOn = Array.isArray(obj.dependsOn)
			? (obj.dependsOn as unknown[]).filter((d): d is string => typeof d === "string")
			: undefined;
		const estimatedTokens =
			typeof obj.estimatedTokens === "number" && Number.isFinite(obj.estimatedTokens)
				? obj.estimatedTokens
				: undefined;
		steps.push({
			id: stepId,
			title,
			body,
			...(dependsOn && dependsOn.length > 0 ? { dependsOn } : {}),
			status: "pending" as PlanStepStatus,
			...(estimatedTokens !== undefined ? { estimatedTokens } : {}),
		});
	}
	return { id, goal, steps, createdAt, state: "draft" };
}

/**
 * Walk the plan's steps in topological order. Each step is dispatched as a
 * separate `Conductor.spawn()` turn whose user message is the step's
 * title + body. The plan object is treated as immutable; the running copy is
 * returned at the end with per-step status + result populated.
 */
export interface ExecutePlanOptions {
	readonly conductor: Conductor;
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly provider: ProviderSpec;
	readonly signal?: AbortSignal;
	/** When true, keep executing even if a step is marked failed. */
	readonly continueOnFailure?: boolean;
	/** Optional callback fired after each step's status changes. */
	readonly onStepStatus?: (stepId: string, status: PlanStepStatus, result?: string) => void;
	/** Override the critic call (mostly for tests). */
	readonly critic?: CriticFn;
}

export interface ExecutePlanResult {
	readonly plan: PlanV2;
	readonly status: "completed" | "cancelled" | "failed";
}

export type CriticFn = (args: {
	readonly step: PlanV2Step;
	readonly result: string;
	readonly signal?: AbortSignal;
}) => Promise<{ ok: boolean; reason: string }>;

export async function executePlan(
	plan: PlanV2,
	opts: ExecutePlanOptions,
): Promise<ExecutePlanResult> {
	const ordered = topoSort(plan.steps);
	const stepStatus = new Map<string, PlanStepStatus>(plan.steps.map((s) => [s.id, s.status]));
	const stepResult = new Map<string, string>();
	for (const s of plan.steps) {
		if (typeof s.result === "string") stepResult.set(s.id, s.result);
	}

	const critic = opts.critic ?? defaultCritic(opts.provider, opts.modelId);

	const setStatus = (stepId: string, status: PlanStepStatus, result?: string) => {
		stepStatus.set(stepId, status);
		if (result !== undefined) stepResult.set(stepId, result);
		if (opts.onStepStatus) opts.onStepStatus(stepId, status, result);
	};

	let overall: "completed" | "cancelled" | "failed" = "completed";

	for (const step of ordered) {
		if (opts.signal?.aborted) {
			overall = "cancelled";
			break;
		}

		// Skip when any prerequisite already failed (unless continueOnFailure).
		const prereqs = step.dependsOn ?? [];
		const blocked = prereqs.some((d) => stepStatus.get(d) === "failed");
		if (blocked && !opts.continueOnFailure) {
			setStatus(step.id, "skipped", "Skipped — prerequisite failed.");
			continue;
		}

		setStatus(step.id, "running");

		let resultText = "";
		let stepFailed = false;
		try {
			const userMessage = `# ${step.title}\n\n${step.body}`;
			const history = await opts.conductor.spawn({
				mode: opts.mode,
				modelId: opts.modelId,
				userMessage,
				...(opts.signal ? { signal: opts.signal } : {}),
			});
			resultText = extractFinalAssistantText(history);
		} catch (err) {
			stepFailed = true;
			resultText = err instanceof Error ? err.message : String(err);
		}

		if (stepFailed) {
			setStatus(step.id, "failed", resultText);
			if (!opts.continueOnFailure) {
				overall = "failed";
				break;
			}
			continue;
		}

		// Tiny critic: did this step satisfy its acceptance criterion?
		let verdict: { ok: boolean; reason: string };
		try {
			verdict = await critic({
				step,
				result: resultText,
				...(opts.signal ? { signal: opts.signal } : {}),
			});
		} catch {
			verdict = { ok: true, reason: "critic unavailable" };
		}

		if (!verdict.ok) {
			// Up to 1 retry.
			setStatus(step.id, "running", resultText);
			let retryResult = "";
			let retryFailed = false;
			try {
				const retryMessage = `# ${step.title} (retry)\n\n${step.body}\n\n[Critic feedback from previous attempt]\n${verdict.reason}`;
				const retryHistory = await opts.conductor.spawn({
					mode: opts.mode,
					modelId: opts.modelId,
					userMessage: retryMessage,
					...(opts.signal ? { signal: opts.signal } : {}),
				});
				retryResult = extractFinalAssistantText(retryHistory);
			} catch (err) {
				retryFailed = true;
				retryResult = err instanceof Error ? err.message : String(err);
			}

			if (retryFailed) {
				setStatus(step.id, "failed", retryResult);
				if (!opts.continueOnFailure) {
					overall = "failed";
					break;
				}
				continue;
			}

			let retryVerdict: { ok: boolean; reason: string };
			try {
				retryVerdict = await critic({
					step,
					result: retryResult,
					...(opts.signal ? { signal: opts.signal } : {}),
				});
			} catch {
				retryVerdict = { ok: true, reason: "critic unavailable" };
			}

			if (retryVerdict.ok) {
				setStatus(step.id, "done", retryResult);
			} else {
				setStatus(
					step.id,
					"failed",
					`${retryResult}\n\n[Critic still rejected: ${retryVerdict.reason}]`,
				);
				if (!opts.continueOnFailure) {
					overall = "failed";
					break;
				}
			}
		} else {
			setStatus(step.id, "done", resultText);
		}
	}

	const finalSteps: PlanV2Step[] = plan.steps.map((s) => ({
		...s,
		status: stepStatus.get(s.id) ?? s.status,
		...(stepResult.has(s.id) ? { result: stepResult.get(s.id) } : {}),
	}));
	return {
		plan: { ...plan, steps: finalSteps, state: overall === "completed" ? "completed" : "cancelled" },
		status: overall,
	};
}

/** Topologically sort steps by their `dependsOn` edges. Cycles fall back to insertion order. */
export function topoSort(steps: readonly PlanV2Step[]): readonly PlanV2Step[] {
	const remaining = new Map(steps.map((s) => [s.id, s] as const));
	const result: PlanV2Step[] = [];
	const visiting = new Set<string>();
	const visited = new Set<string>();

	const visit = (id: string): void => {
		if (visited.has(id) || visiting.has(id)) return;
		visiting.add(id);
		const node = remaining.get(id);
		if (node) {
			for (const dep of node.dependsOn ?? []) {
				if (remaining.has(dep)) visit(dep);
			}
			visited.add(id);
			result.push(node);
		}
		visiting.delete(id);
	};

	for (const s of steps) visit(s.id);
	// Any step not visited (orphans) appended in original order.
	for (const s of steps) {
		if (!visited.has(s.id)) result.push(s);
	}
	return result;
}

function defaultCritic(provider: ProviderSpec, modelId: string): CriticFn {
	return async ({ step, result, signal }) => {
		const chunks: string[] = [];
		const stream = provider.stream({
			messages: [
				{
					role: "user",
					parts: [
						{
							kind: "text",
							text: `Step title: ${step.title}\nAcceptance criterion (extract from step body):\n${step.body}\n\nAgent result:\n${result}\n\nDid the agent satisfy the acceptance criterion? Reply with one line in the form \"Yes: <one-sentence reason>\" or \"No: <one-sentence reason>\".`,
						},
					],
				},
			],
			modelId,
			systemPrompt:
				'You are a terse, strict reviewer. Reply with EXACTLY one line in the form "Yes: <reason>" or "No: <reason>". No extra text.',
			temperature: 0.1,
			...(signal ? { signal } : {}),
		});
		for await (const ev of stream) {
			if (ev.type === "text_delta") chunks.push(ev.text);
		}
		const text = chunks.join("").trim();
		const m = /^\s*(yes|no)\s*[:\-]\s*(.+)$/i.exec(text);
		if (!m) return { ok: true, reason: text.slice(0, 200) || "unrecognized critic reply" };
		return { ok: m[1].toLowerCase() === "yes", reason: m[2].trim() };
	};
}

/**
 * Render a `PlanV2` as a compact text section the executor's system prompt
 * can incorporate. Phase 5 replacement for the legacy
 * `planToPromptSection`; we drop the rationale-tail format and surface the
 * step body's first line instead (the V2 prompt instructs the planner to
 * lead each body with the acceptance criterion).
 */
export function planV2ToPromptSection(plan: PlanV2): string {
	if (plan.steps.length === 0) return "";
	const lines: string[] = ["[Plan — follow but adapt if needed]", `Goal: ${plan.goal}`];
	for (const step of plan.steps) {
		const summary = firstLine(step.body);
		lines.push(`- ${step.title}${summary ? `: ${summary}` : ""}`);
	}
	return lines.join("\n");
}

function firstLine(s: string): string {
	const i = s.indexOf("\n");
	return (i === -1 ? s : s.slice(0, i)).trim();
}

function extractFinalAssistantText(history: readonly ConversationMessage[]): string {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		const chunks: string[] = [];
		for (const p of msg.parts) if (p.kind === "text") chunks.push(p.text);
		const text = chunks.join("");
		if (text.trim().length > 0) return text;
	}
	return "(agent produced no text output)";
}

let counter = 0;
function makePlanId(opts?: { makeId?: () => string }): string {
	if (opts?.makeId) return opts.makeId();
	counter = (counter + 1) % 1_000_000;
	return `plan_${Date.now().toString(36)}_${counter.toString(36)}`;
}

function nowIso(opts?: { now?: () => Date }): string {
	return (opts?.now ?? (() => new Date()))().toISOString();
}
