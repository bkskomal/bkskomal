import type { ProviderSpec } from "@oati/shared";

export class ProviderRegistry {
	private readonly providers = new Map<string, ProviderSpec>();

	register(spec: ProviderSpec): void {
		if (this.providers.has(spec.id)) {
			throw new Error(`Provider already registered: ${spec.id}`);
		}
		this.providers.set(spec.id, spec);
	}

	unregister(id: string): boolean {
		return this.providers.delete(id);
	}

	get(id: string): ProviderSpec | undefined {
		return this.providers.get(id);
	}

	require(id: string): ProviderSpec {
		const p = this.providers.get(id);
		if (!p) throw new Error(`Provider not found: ${id}`);
		return p;
	}

	list(): ProviderSpec[] {
		return [...this.providers.values()];
	}
}
