/**
 * Tool-call argument normalization.
 *
 * Extracted from agent.ts because (a) the hot path is independently
 * useful — the openai-compatible provider can call it too — and (b) it
 * needs to be loadable by the bench harness without dragging in the
 * Agent class (which uses TS parameter properties that Node's
 * `--experimental-strip-types` loader rejects).
 *
 * Re-exported from agent.ts so existing imports keep working.
 */

/**
 * Walk a string-or-object value through repeated JSON.parse until it
 * resolves to an object (or we give up). Returns the object on success,
 * `undefined` when we run out of depth / hit unparseable JSON even
 * after a control-char repair attempt / land on a non-object scalar.
 *
 * Why control-char repair is HERE and not just in the provider:
 * Kimi (and other open-weight models) emit `arguments` as a JSON-
 * encoded string of an object. Decoding the OUTER layer yields an
 * inner string that — because the original payload had multi-line
 * `content` — now contains literal `\n`/`\t` bytes where strict JSON
 * forbids them. The provider's `parseToolArgsLenient` only repairs
 * the ORIGINAL string; the inner layers it produces by decoding still
 * carry the same hazard. Without applying the same repair at each
 * unwrap layer, multi-line tool-call args (write_file with code, exec
 * with multi-line scripts) silently lose the unwrap chain and the
 * tool ends up with `{_raw: "..."}` or a bare string.
 *
 * Worst observed in the wild: Kimi K2 emits 2 layers of JSON-string
 * over the object, plus the provider's `_raw` wrapper → 3 strings to
 * peel. On 2026-05-24 we saw a 4-level `_raw`-of-`_raw`-of-... case
 * with quadruple-escaped quotes, so the prior `maxDepth = 4` was
 * being exhausted before reaching the object. Bumped to 8 — runtime
 * cost is trivial (each layer is one JSON.parse on a strictly
 * shrinking string) and the headroom matters when the model gets
 * confused about its own output format.
 */
function deepUnwrapToObject(start: unknown, maxDepth = 8): Record<string, unknown> | undefined {
	let cur = start;
	for (let i = 0; i < maxDepth; i++) {
		if (cur === null || cur === undefined) return undefined;
		if (typeof cur === "object" && !Array.isArray(cur)) {
			return cur as Record<string, unknown>;
		}
		if (typeof cur === "string") {
			const parsed = tryParseLenient(cur);
			if (parsed === undefined) return undefined;
			cur = parsed;
			continue;
		}
		// number, boolean, array — not a valid tool-arg shape.
		return undefined;
	}
	return undefined;
}

/**
 * Parse a string as JSON; if strict parse fails, try once more after
 * escaping bare control characters (raw `\n`, `\t`, `\r`, ...) inside
 * string literals. Returns `undefined` only when both attempts fail.
 *
 * Mirrors `parseToolArgsLenient` from the openai-compatible provider
 * but is defined here so `agent-core` doesn't need to depend on
 * `@oati/providers`. The implementations should stay in sync — if
 * one is updated, update both. There's a regression test covering the
 * multi-line `content` field case in `agent-core/tests/agent.test.ts`.
 */
function tryParseLenient(raw: string): unknown {
	try {
		return JSON.parse(raw);
	} catch {
		/* fall through */
	}
	const repaired = escapeLiteralControlChars(raw);
	if (repaired !== raw) {
		try {
			return JSON.parse(repaired);
		} catch {
			/* fall through */
		}
	}
	return undefined;
}

/**
 * Walk a JSON-ish string, tracking whether we're inside a string
 * literal, and replace bare control characters with their escaped
 * forms. Outside of string literals we leave whitespace alone (those
 * control chars are already legal there).
 *
 * Backslash handling: when we see `\` inside a string, the NEXT char
 * is part of an escape sequence — pass it through verbatim (whether
 * it's `\n`, `\"`, `\\`, etc.). Without this, an escaped quote `\"`
 * would be misread as the string-closing quote.
 */
function escapeLiteralControlChars(s: string): string {
	let out = "";
	let inString = false;
	let prevBackslash = false;
	for (let i = 0; i < s.length; i++) {
		const ch = s[i];
		const code = s.charCodeAt(i);
		if (inString) {
			if (prevBackslash) {
				out += ch;
				prevBackslash = false;
				continue;
			}
			if (ch === "\\") {
				out += ch;
				prevBackslash = true;
				continue;
			}
			if (ch === '"') {
				out += ch;
				inString = false;
				continue;
			}
			if (code === 0x0a) {
				out += "\\n";
				continue;
			}
			if (code === 0x0d) {
				out += "\\r";
				continue;
			}
			if (code === 0x09) {
				out += "\\t";
				continue;
			}
			if (code < 0x20) {
				out += `\\u${code.toString(16).padStart(4, "0")}`;
				continue;
			}
			out += ch;
			continue;
		}
		if (ch === '"') {
			inString = true;
		}
		out += ch;
	}
	return out;
}

/**
 * Normalize tool-call arguments before dispatch.
 *
 * Real-world providers + models emit several pathological argument
 * shapes that all crash naive tool guards. We unwrap them transparently
 * so the model doesn't have to:
 *
 *   1. **JSON-string-of-object** — some smaller / open-weight models
 *      (Kimi K2, Qwen, etc.) emit `arguments: "{\"path\":\"foo\"}"`
 *      literally as a string. Our provider's `JSON.parse` succeeds
 *      (a JSON string IS valid JSON) but yields a plain string, not
 *      an object. Parse repeatedly until we reach the object.
 *   2. **`{_raw: "..."}` wrapper** — the openai-compatible provider's
 *      last-ditch fallback when arguments aren't valid JSON. The
 *      payload itself can also be double- or triple-wrapped.
 *   3. **Mixed nesting** — once Kimi has been told once that we use
 *      `_raw`, it sometimes "helpfully" wraps its OWN args as
 *      `"{\"_raw\":\"\\\"{...}\\\"\"}"` — a top-level JSON string that
 *      parses to a `{_raw: ...}` object whose payload is yet more
 *      wrapped JSON. The loop below handles that by re-normalizing
 *      until the shape stabilizes, with a hard cap to prevent
 *      pathological inputs from spinning.
 *
 * NOTE 2026-05-23: after we stripped the negative-example reminder
 * from the system prompt, Kimi K2.6 emits clean objects on the first
 * try and this function is inert in the steady state. It stays as a
 * defensive safety net — if it starts firing again on a capable model,
 * the system prompt is probably the culprit, not the model.
 *
 * Returns the input unchanged when it's already an object/null/etc, or
 * when unwrapping fails — the downstream tool will then reject with its
 * own targeted error message rather than us swallowing the problem.
 */
export function normalizeToolArgs(args: unknown): unknown {
	let cur: unknown = args;
	// Outer iteration cap. We alternate between string and `{_raw: ...}`
	// shapes; each iteration peels one layer. 10 iterations handles the
	// 4-level `_raw`-nested cases observed in the wild on 2026-05-24
	// with comfortable headroom and zero practical cost.
	for (let i = 0; i < 10; i++) {
		// 2026-05-25: empty-args coercion. When the model emits a tool call
		// with no arguments, providers may forward `null` / `undefined` /
		// `""` to us. Coerce to `{}` so the handler can safely destructure
		// missing fields and surface its own "field required" error,
		// instead of crashing on `args.path` against a null receiver.
		// Closes the class of Moonshot K2 issue #100 (vLLM Pydantic-side
		// rejection) on the CLIENT side — vLLM still has to ship its own
		// fix for the server-side validation pre-empt.
		if (cur === null || cur === undefined) return {};
		if (typeof cur === "string") {
			if (cur.trim().length === 0) return {};
			const unwrapped = deepUnwrapToObject(cur);
			if (unwrapped) {
				cur = unwrapped;
				continue;
			}
			return cur;
		}
		if (typeof cur === "object" && !Array.isArray(cur)) {
			const obj = cur as Record<string, unknown>;
			const keys = Object.keys(obj);
			if (keys.length === 1 && keys[0] === "_raw" && typeof obj._raw === "string") {
				const unwrapped = deepUnwrapToObject(obj._raw);
				if (unwrapped) {
					cur = unwrapped;
					continue;
				}
				return cur;
			}
			return cur;
		}
		return cur;
	}
	return cur;
}
