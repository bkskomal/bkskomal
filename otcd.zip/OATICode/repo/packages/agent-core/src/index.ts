export { Agent, detectRunawayRepetition } from "./agent";
// Phase 2.2: model-capability-aware tool filter. Exposed so hosts that
// build their own toolbelt outside the Agent constructor (e.g., a custom
// dispatcher or the spawn-parallel-agents fan-out) can apply the same
// gating policy without re-implementing the capability → field mapping.
export { filterToolsForModel, isToolAllowedForQuirks } from "./tool-filter";
// Phase B (2026-05-25): inline-XML tool format for open-weight models.
// Built + parsed in agent-core so providers (openai-compatible) can opt
// in per-request via `detectModelQuirks(modelId).toolCallFormat`.
export {
	buildInlineXmlToolPrompt,
	buildInlineXmlToolDescription,
} from "./inline-xml-format";
export { InlineXmlToolParser } from "./inline-xml-parser";
export type { InlineXmlChunk, InlineParsedToolCall } from "./inline-xml-parser";
// 2026-05-25: Kimi K2 / K2.6 emit their native `<|tool_call_begin|>`
// markers even when the inline-XML format is in the system prompt. The
// dedicated parser handles those markers client-side so tool calls land
// in history instead of splashing as raw text across the chat.
export { KimiNativeToolParser } from "./kimi-native-parser";
export type { KimiNativeChunk, KimiParsedToolCall } from "./kimi-native-parser";
export { Conductor } from "./conductor";
export { ToolRegistry } from "./tool-registry";
export { ProviderRegistry } from "./provider-registry";
export { runCritic, parseCritique } from "./critic";
export type { CriticOptions } from "./critic";
// Critic battle-test fixtures + helpers.
export { CRITIC_BATTLE_CASES, countByCategory } from "./critic-fixtures";
export type { CriticBattleCase, CriticBattleCategory } from "./critic-fixtures";
export { applyStagesToSystemPrompt } from "./stages";
export type { AgentDeps, AgentOptions } from "./agent";
export {
	summarizeHistorySegment,
	renderSegmentAsTranscript,
	SUMMARIZER_SYSTEM_PROMPT,
} from "./summarizer";
export type { SummarizerOptions } from "./summarizer";
export { runWithTests } from "./test-driven-loop";
export type {
	TestDrivenLoopOptions,
	TestDrivenLoopResult,
	TestDrivenFailure,
} from "./test-driven-loop";
// R6-A: Structured Plan v2 — planner + executor + topo-sort helper.
export {
	planRequest,
	executePlan,
	parsePlanV2,
	planV2ToPromptSection,
	topoSort,
} from "./planner-v2";
export type {
	PlanRequestOptions,
	ExecutePlanOptions,
	ExecutePlanResult,
	CriticFn,
	ParseOptions,
} from "./planner-v2";
