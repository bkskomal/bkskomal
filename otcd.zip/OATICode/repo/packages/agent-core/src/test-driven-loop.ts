import type {
	AgentEvent,
	ConversationMessage,
	HostContext,
	ModeConfig,
	ToolSpec,
} from "@oati/shared";
import type { Conductor } from "./conductor";

/**
 * Per-run configuration for the test-driven loop. `maxFixIterations` is a hard
 * upper bound on follow-up "fix failing tests" turns the loop will issue. The
 * loop runs `run_tests` once after the supplied history, then iterates only
 * when tests fail AND the fix turn actually edits files.
 */
export interface TestDrivenLoopOptions {
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly providerId: string;
	readonly signal?: AbortSignal;
	/** Defaults to 3. Hard-capped to 5 to keep the loop bounded. */
	readonly maxFixIterations?: number;
	/**
	 * Tool list used to look up `run_tests`. We look it up by name instead of
	 * importing from `@oati/tools` so this module avoids a hard dep on the tools
	 * package.
	 */
	readonly tools: readonly ToolSpec[];
	/** HostContext to run `run_tests` against. */
	readonly host: HostContext;
	/**
	 * Whether the just-completed agent turn touched any files. Caller tracks
	 * this from `tool_call` events for `write_file`. When false the loop skips
	 * running tests entirely (nothing changed).
	 */
	readonly touchedFiles: boolean;
	/** Optional log sink for diagnostics. */
	readonly log?: (msg: string) => void;
	/**
	 * Optional chat-visible status notifier. When provided, the loop emits
	 * one short status line at each phase boundary ("Running tests…", "12
	 * failures — attempting fix 1/3…", "All tests passing"). Lets the user
	 * see what'\''s happening without parsing the agent log; chat-panel wires
	 * this to a `text_delta` AgentEvent that lands as a system bubble.
	 */
	readonly notifyChat?: (text: string) => void;
	/**
	 * When true, ask the user (via host.requestApproval) before each fix
	 * iteration. Default false to preserve the existing auto-mode behavior.
	 * Set true on user-driven runs (e.g. the /test-loop slash command) so a
	 * runaway loop can't make 5 fix attempts the user didn'\''t approve.
	 */
	readonly requireApprovalBetweenIterations?: boolean;
	/**
	 * When true, override the "auto-mode only" gate and run the loop even
	 * in chat/code/plan modes. Used by the /test-loop slash command so the
	 * user can opt in explicitly. Default false (legacy auto-only gate).
	 */
	readonly bypassAutoModeGate?: boolean;
}

export interface TestDrivenLoopResult {
	readonly history: readonly ConversationMessage[];
	/** How many fix iterations actually ran. */
	readonly fixIterations: number;
	/** Whether tests were run at all (false in non-auto modes or when no files touched). */
	readonly testsRan: boolean;
	/** Final exit code from the last `run_tests` invocation, or undefined. */
	readonly finalExitCode?: number;
	/** Final failure list from the last `run_tests` invocation. */
	readonly finalFailures: readonly TestDrivenFailure[];
}

export interface TestDrivenFailure {
	readonly name: string;
	readonly snippet: string;
}

const HARD_MAX_FIX_ITERATIONS = 5;

interface RunTestsToolResult {
	readonly exitCode: number;
	readonly summary: string;
	readonly failures: readonly TestDrivenFailure[];
	readonly runner: string;
}

function isRunTestsResult(v: unknown): v is RunTestsToolResult {
	if (typeof v !== "object" || v === null) return false;
	const r = v as RunTestsToolResult;
	return typeof r.exitCode === "number" && Array.isArray(r.failures);
}

/**
 * After an agent turn finishes, run the test suite and (when failures exist)
 * feed them back to the agent as a follow-up user turn. Repeats up to
 * `maxFixIterations` times. The helper is a thin wrapper around
 * `Conductor.spawn` and the `run_tests` tool — it does NOT replace the
 * initial agent run; callers do that themselves and pass the resulting
 * history in.
 *
 * Only runs in `auto-edit`, `auto`, or any mode with `autoApprove: true`.
 * Non-auto modes return immediately as a no-op so the helper is safe to wire
 * in unconditionally.
 */
export async function runWithTests(
	conductor: Conductor,
	history: readonly ConversationMessage[],
	opts: TestDrivenLoopOptions,
): Promise<TestDrivenLoopResult> {
	const log = opts.log ?? (() => undefined);
	const notify = opts.notifyChat ?? (() => undefined);
	const mode = opts.mode;
	const isAutoMode = mode.id === "auto-edit" || mode.id === "auto" || mode.autoApprove === true;

	if ((!isAutoMode && !opts.bypassAutoModeGate) || !opts.touchedFiles) {
		return { history, fixIterations: 0, testsRan: false, finalFailures: [] };
	}

	const runTestsTool = opts.tools.find((t) => t.name === "run_tests");
	if (!runTestsTool) {
		log("[test-driven-loop] run_tests tool not registered; skipping post-turn verification.");
		return { history, fixIterations: 0, testsRan: false, finalFailures: [] };
	}

	const cap = Math.min(opts.maxFixIterations ?? 3, HARD_MAX_FIX_ITERATIONS);
	let currentHistory: readonly ConversationMessage[] = history;
	let lastFailures: readonly TestDrivenFailure[] = [];
	let lastExitCode: number | undefined;
	let fixIterations = 0;

	for (let attempt = 0; attempt <= cap; attempt++) {
		if (opts.signal?.aborted) break;
		notify(
			attempt === 0
				? "🧪 Running test suite…"
				: `🔁 Re-running test suite (after fix attempt ${attempt})…`,
		);
		const raw = await runTestsTool.handler({}, opts.host, {
			callId: `tdl_run_${attempt}`,
			agentId: "tdl",
		});
		if (!isRunTestsResult(raw)) {
			log("[test-driven-loop] run_tests returned an unexpected shape; bailing.");
			notify("⚠️ Test runner returned an unexpected shape; stopping the loop.");
			break;
		}
		lastExitCode = raw.exitCode;
		lastFailures = raw.failures;
		log(
			`[test-driven-loop] attempt=${attempt} exit=${raw.exitCode} failures=${raw.failures.length} runner=${raw.runner}`,
		);
		if (raw.exitCode === 0) {
			notify(`✅ All tests passing (${raw.runner}).`);
			return {
				history: currentHistory,
				fixIterations,
				testsRan: true,
				finalExitCode: raw.exitCode,
				finalFailures: [],
			};
		}
		if (attempt >= cap) {
			notify(
				`⛔ Stopping after ${attempt} fix attempt${attempt === 1 ? "" : "s"} — tests still failing (${raw.failures.length}). Review and ask me to continue manually.`,
			);
			break;
		}

		// User-as-approval-gate. Default off (auto-mode behavior unchanged),
		// flipped on by /test-loop and similar user-driven entry points.
		if (opts.requireApprovalBetweenIterations) {
			const approveMsg = `Tests failed (${raw.failures.length}). Attempt fix iteration ${attempt + 1}/${cap}?`;
			notify(`❓ ${approveMsg}`);
			let approved = false;
			try {
				approved = await opts.host.requestApproval({
					toolName: "test-driven-loop",
					args: { attempt: attempt + 1, failures: raw.failures.length, runner: raw.runner },
					summary: approveMsg,
				});
			} catch (err) {
				log(
					`[test-driven-loop] approval check failed: ${err instanceof Error ? err.message : String(err)}; treating as denied.`,
				);
			}
			if (!approved) {
				notify("⏸ User declined further fix iterations.");
				break;
			}
		} else {
			notify(`🔧 ${raw.failures.length} test failure(s) — attempting fix ${attempt + 1}/${cap}…`);
		}

		fixIterations++;
		const failureBlock = raw.failures
			.slice(0, 5)
			.map((f, i) => `### Failure ${i + 1}: ${f.name}\n\n\`\`\`\n${f.snippet}\n\`\`\``)
			.join("\n\n");
		const fixPrompt = [
			"Tests still failing after your last change. Please diagnose and fix the root cause, then I will re-run the suite automatically.",
			"",
			`Runner: ${raw.runner}`,
			`Exit code: ${raw.exitCode}`,
			`Summary: ${raw.summary}`,
			"",
			failureBlock || "(no parsed failures — see runner output above)",
		].join("\n");

		// Track write_file calls in the fix turn so we only re-run tests when
		// the agent actually edited something.
		let touchedInFix = false;
		const onEvent = (ev: AgentEvent) => {
			if (ev.type === "tool_call" && ev.call.name === "write_file") {
				touchedInFix = true;
			}
		};
		const off = conductor.on(onEvent);
		try {
			currentHistory = await conductor.spawn({
				mode: { ...mode, providerId: opts.providerId },
				modelId: opts.modelId,
				userMessage: fixPrompt,
				history: currentHistory,
				signal: opts.signal,
			});
		} finally {
			off();
		}
		if (!touchedInFix) {
			log("[test-driven-loop] fix turn made no file edits; stopping loop.");
			notify("🛑 Fix turn made no file edits; stopping the loop.");
			break;
		}
	}

	return {
		history: currentHistory,
		fixIterations,
		testsRan: true,
		finalExitCode: lastExitCode,
		finalFailures: lastFailures,
	};
}
