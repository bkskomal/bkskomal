/**
 * Inline-XML tool-call parser (Phase B, Cline-style inline tools).
 *
 * Why this exists:
 * Frontier-grade providers (OpenAI/Anthropic) give us a structured
 * tool-call envelope alongside the assistant message. Open-weight
 * models accessed via OpenAI-compatible gateways — Kimi K2, Qwen,
 * DeepSeek — either don't support that envelope reliably or hallucinate
 * arguments badly enough that the inline-XML protocol (Cline / Roo /
 * Aider) outperforms it in practice. For those models we ask the model
 * to emit tool calls as `<tool_name><arg>value</arg></tool_name>`
 * directly in the assistant text and parse them out here.
 *
 * Invariants we preserve:
 *   - Streaming-safe: the SSE stream can split a tag across chunk
 *     boundaries. We never emit partial markup as text to the chat
 *     bubble — only safely-flushed plain text or fully-assembled tool
 *     calls.
 *   - Lossless on malformed input: if the model emits a half-finished
 *     tool tag, we'd rather show the user the raw text than throw.
 *   - Pass-through on unknown tags: the model might be writing
 *     example code that contains XML-looking text. Only tag names in
 *     `knownToolNames` get treated as tool boundaries.
 */

/**
 * Result of feeding one text chunk to the parser. Callers consume each
 * field — text content gets streamed to the chat bubble, completed tool
 * calls get emitted as `tool_call` events.
 */
export interface InlineXmlChunk {
	/** Plain text the user sees in the assistant bubble (no tool markup). */
	readonly text: string;
	/** Tool calls fully assembled from this chunk. May be 0, 1, or many. */
	readonly toolCalls: readonly InlineParsedToolCall[];
}

export interface InlineParsedToolCall {
	/** Tool name (matches the outer tag). */
	readonly name: string;
	/** Argument object built from inner tags. */
	readonly args: Readonly<Record<string, string>>;
	/** Stable id derived from position + name. */
	readonly id: string;
}

/**
 * Identifier characters legal inside a tag name (tool or arg). Anything
 * outside this set means we're not looking at a tag — pass through as
 * literal text. Mirrors the spec: `[a-zA-Z0-9_-]+`.
 */
function isNameChar(ch: string): boolean {
	if (ch.length !== 1) return false;
	const c = ch.charCodeAt(0);
	if (c >= 0x30 && c <= 0x39) return true; // 0-9
	if (c >= 0x41 && c <= 0x5a) return true; // A-Z
	if (c >= 0x61 && c <= 0x7a) return true; // a-z
	if (c === 0x5f || c === 0x2d) return true; // _ -
	return false;
}

/**
 * Stateful streaming parser. Construct one per provider stream; call
 * `feed(chunk)` for each text delta; call `finalize()` after the
 * provider's message_end event to flush any trailing text and detect
 * incomplete tool blocks.
 *
 * `knownToolNames` is the set of tool names that are valid for this
 * run; tags that aren't in the set get passed through as literal text
 * (the model might be writing example code containing XML-looking text).
 *
 * Design decision (interleaved text): when text appears on either side
 * of a tool tag (e.g. `before <read_file>...</read_file> after`), we
 * emit "before " and " after" with their surrounding spaces intact, so
 * the caller's concatenation yields `"before  after"` — two spaces, one
 * from each side of the consumed tool block. The tool markup itself is
 * removed but the whitespace the model wrote around it is preserved.
 * This is the simplest rule and matches what users expect when copying
 * the assistant message.
 *
 * Buffering model: we consume bytes from the input one character at a
 * time. The unscanned tail lives in `this.pending`; everything we've
 * scanned has been committed either to emitted text (returned) or to
 * the in-progress tool/arg buffers (instance fields). `this.pending` is
 * therefore always the suffix that we haven't yet looked at — when a
 * tag is split across chunks, the next chunk's bytes are appended to
 * `pending` and scanning resumes seamlessly using the state machine
 * fields we left behind.
 */
export class InlineXmlToolParser {
	private readonly known: ReadonlySet<string>;
	private seq = 0;

	/** Unscanned input bytes. Consumed left-to-right by `drain()`. */
	private pending = "";

	/** Current state-machine position. */
	private state: ParserState = "idle";

	/**
	 * Tag-name accumulator. Holds the name being read in inToolOpen /
	 * inToolClose / inArgOpen / inArgClose, plus a leading `<` we'd
	 * also held back so we can re-emit it as literal text if the tag
	 * turns out to be bogus. The exact form-of-bytes-held varies by
	 * state — see comments at each state.
	 */
	private tagBuf = "";

	/** Tool currently being assembled (set when state is in-tool). */
	private currentToolName = "";
	private currentArgs: Record<string, string> = {};
	private currentArgName = "";
	private currentArgValue = "";

	constructor(knownToolNames: readonly string[]) {
		this.known = new Set(knownToolNames);
	}

	feed(chunk: string): InlineXmlChunk {
		if (chunk.length === 0) return EMPTY_CHUNK;
		this.pending += chunk;
		return this.drain(false);
	}

	finalize(): InlineXmlChunk {
		return this.drain(true);
	}

	// ---------------------------------------------------------------
	// State machine
	//
	// Each state consumes bytes from the front of `this.pending` and
	// either (a) commits them to in-progress structures (tagBuf,
	// currentArgValue, ...), (b) emits resolved text to `outText`, or
	// (c) emits a completed tool call. We exit the loop when we run
	// out of bytes or when we can't decide without more input.
	//
	// States:
	//   idle           — outside any tool, accumulating plain text
	//                    Pending head is plain text. On `<` we enter
	//                    inToolOpen and tagBuf becomes `<`.
	//   inToolOpen     — read `<` plus possibly some name chars.
	//                    tagBuf = `<` + accumulated name. On `>` with
	//                    a known name, transition to inToolContent.
	//                    On any non-name non-`>` char, flush tagBuf as
	//                    literal text and return to idle.
	//   inToolContent  — between opening and closing tool tag, looking
	//                    for either `<arg>` or `</tool>`.
	//   inArgOpen      — read `<` inside a tool (next char is alpha).
	//                    tagBuf = accumulated arg name.
	//   inArgContent   — inside an arg, accumulating value.
	//   inArgClose     — read `</` inside an arg.
	//                    tagBuf = accumulated closing-name.
	//   inToolClose    — read `</` inside tool content (next char isn't
	//                    a name char following an arg — i.e. we expect
	//                    the tool name here).
	// ---------------------------------------------------------------
	private drain(isFinal: boolean): InlineXmlChunk {
		let outText = "";
		const outCalls: InlineParsedToolCall[] = [];

		while (this.pending.length > 0) {
			const ch = this.pending[0];
			switch (this.state) {
				case "idle": {
					if (ch === "<") {
						// Consume the `<` into tagBuf so we can re-emit
						// it as literal text if the tag turns out to be
						// bogus or unknown.
						this.tagBuf = "<";
						this.pending = this.pending.slice(1);
						this.state = "inToolOpen";
					} else {
						outText += ch;
						this.pending = this.pending.slice(1);
					}
					break;
				}

				case "inToolOpen": {
					// tagBuf is `<` + name chars so far.
					if (isNameChar(ch)) {
						this.tagBuf += ch;
						this.pending = this.pending.slice(1);
					} else if (ch === ">") {
						const name = this.tagBuf.slice(1);
						if (name.length > 0 && this.known.has(name)) {
							// Valid tool open. Commit.
							this.currentToolName = name;
							this.currentArgs = {};
							this.tagBuf = "";
							this.pending = this.pending.slice(1);
							this.state = "inToolContent";
						} else {
							// Unknown tag — emit `<name>` as literal
							// text and return to idle.
							outText += `${this.tagBuf}>`;
							this.tagBuf = "";
							this.pending = this.pending.slice(1);
							this.state = "idle";
						}
					} else {
						// Not a tag at all. Flush `<name-so-far` as
						// literal text and return to idle WITHOUT
						// consuming `ch` — it might start a new tag.
						outText += this.tagBuf;
						this.tagBuf = "";
						this.state = "idle";
					}
					break;
				}

				case "inToolContent": {
					if (ch === "<") {
						// Need to peek the next char to know if this is
						// `<arg>` or `</tool>`.
						if (this.pending.length < 2) {
							// Not enough bytes — wait.
							if (isFinal) {
								this.flushIncompleteTool((s) => {
									outText += s;
								});
								this.pending = "";
								this.state = "idle";
							}
							return wrap(outText, outCalls);
						}
						const next = this.pending[1];
						if (next === "/") {
							this.tagBuf = "";
							this.pending = this.pending.slice(2);
							this.state = "inToolClose";
						} else if (isNameChar(next)) {
							this.tagBuf = "";
							this.pending = this.pending.slice(1);
							this.state = "inArgOpen";
						} else {
							// `<` followed by something weird. Drop
							// it (between-args region is non-textual).
							this.pending = this.pending.slice(1);
						}
					} else {
						// Whitespace / stray chars between args — drop.
						this.pending = this.pending.slice(1);
					}
					break;
				}

				case "inArgOpen": {
					// tagBuf = accumulated arg name.
					if (isNameChar(ch)) {
						this.tagBuf += ch;
						this.pending = this.pending.slice(1);
					} else if (ch === ">" && this.tagBuf.length > 0) {
						this.currentArgName = this.tagBuf;
						this.currentArgValue = "";
						this.tagBuf = "";
						this.pending = this.pending.slice(1);
						this.state = "inArgContent";
					} else {
						// Malformed arg open. Bail the whole tool to
						// literal text — once an inner tag is broken
						// the outer tool can't be reliably
						// reconstructed, so reproduce what we have.
						this.currentArgName = this.tagBuf; // preserve name-so-far
						this.currentArgValue = "";
						this.tagBuf = "";
						this.flushIncompleteTool((s) => {
							outText += s;
						});
						this.state = "idle";
					}
					break;
				}

				case "inArgContent": {
					// Per spec: nested tags inside an arg are NOT
					// supported — they end up as literal value content.
					// The ONLY thing that closes an arg is `</argname>`.
					// `<` followed by anything other than `/` stays in
					// the value.
					if (ch === "<") {
						if (this.pending.length < 2) {
							if (isFinal) {
								this.currentArgValue += this.pending;
								this.pending = "";
								this.flushIncompleteTool((s) => {
									outText += s;
								});
								this.state = "idle";
							}
							return wrap(outText, outCalls);
						}
						const next = this.pending[1];
						if (next === "/") {
							this.tagBuf = "";
							this.pending = this.pending.slice(2);
							this.state = "inArgClose";
						} else {
							this.currentArgValue += ch;
							this.pending = this.pending.slice(1);
						}
					} else {
						this.currentArgValue += ch;
						this.pending = this.pending.slice(1);
					}
					break;
				}

				case "inArgClose": {
					if (isNameChar(ch)) {
						this.tagBuf += ch;
						this.pending = this.pending.slice(1);
					} else if (ch === ">" && this.tagBuf === this.currentArgName) {
						this.currentArgs[this.currentArgName] = trimOuterNewlines(this.currentArgValue);
						this.currentArgName = "";
						this.currentArgValue = "";
						this.tagBuf = "";
						this.pending = this.pending.slice(1);
						this.state = "inToolContent";
					} else {
						// Mismatched close-tag inside an arg: push the
						// `</...` back into the value as literal text
						// and resume content scanning. Don't consume
						// the current char — let inArgContent see it.
						this.currentArgValue += `</${this.tagBuf}`;
						this.tagBuf = "";
						this.state = "inArgContent";
					}
					break;
				}

				case "inToolClose": {
					if (isNameChar(ch)) {
						this.tagBuf += ch;
						this.pending = this.pending.slice(1);
					} else if (ch === ">" && this.tagBuf === this.currentToolName) {
						outCalls.push({
							name: this.currentToolName,
							args: { ...this.currentArgs },
							id: `ix_${this.currentToolName}_${this.seq++}`,
						});
						this.currentToolName = "";
						this.currentArgs = {};
						this.tagBuf = "";
						this.pending = this.pending.slice(1);
						this.state = "idle";
					} else {
						// Mismatched close tag for the tool. Bail to
						// literal text.
						this.flushIncompleteTool((s) => {
							outText += s;
						});
						// Also re-emit what we'd accumulated in tagBuf
						// for the close (the model wrote it).
						outText += `</${this.tagBuf}`;
						this.tagBuf = "";
						this.state = "idle";
					}
					break;
				}
			}
		}

		// Drained pending. If finalizing, flush any half-formed work.
		if (isFinal) {
			switch (this.state) {
				case "idle":
					break;
				case "inToolOpen":
					// tagBuf holds `<name-so-far`, never saw closing `>`.
					outText += this.tagBuf;
					this.tagBuf = "";
					break;
				case "inToolContent":
				case "inToolClose":
				case "inArgOpen":
				case "inArgContent":
				case "inArgClose":
					this.flushIncompleteTool((s) => {
						outText += s;
					});
					this.tagBuf = "";
					break;
			}
			this.state = "idle";
		}

		return wrap(outText, outCalls);
	}

	/**
	 * The tool block can't be completed — emit the literal text we'd
	 * have to reproduce so the user sees what the model wrote. Resets
	 * tool buffers.
	 *
	 * Best-effort reconstruction, not byte-perfect: we don't preserve
	 * whitespace between args inside the tool block (we drop it during
	 * `inToolContent`). That's an acceptable trade for keeping the
	 * scanner simple — malformed output is the rare path.
	 */
	private flushIncompleteTool(emit: (s: string) => void): void {
		if (!this.currentToolName) return;
		let s = `<${this.currentToolName}>`;
		for (const [k, v] of Object.entries(this.currentArgs)) {
			s += `<${k}>${v}</${k}>`;
		}
		if (this.currentArgName) {
			s += `<${this.currentArgName}>${this.currentArgValue}`;
		}
		emit(s);
		this.currentToolName = "";
		this.currentArgs = {};
		this.currentArgName = "";
		this.currentArgValue = "";
	}
}

type ParserState =
	| "idle"
	| "inToolOpen"
	| "inToolContent"
	| "inArgOpen"
	| "inArgContent"
	| "inArgClose"
	| "inToolClose";

const EMPTY_CHUNK: InlineXmlChunk = { text: "", toolCalls: [] };

function wrap(text: string, toolCalls: InlineParsedToolCall[]): InlineXmlChunk {
	return { text, toolCalls };
}

/**
 * Strip one leading `\n` and one trailing `\n` if present. Per spec:
 * multi-line arg values are preserved verbatim, EXCEPT for the single
 * newlines models add for readability right after `<content>` and right
 * before `</content>`. Anything beyond that (a second leading `\n`,
 * leading spaces, etc.) is preserved.
 */
function trimOuterNewlines(s: string): string {
	let start = 0;
	let end = s.length;
	if (s.charCodeAt(0) === 0x0a) start = 1;
	if (end > start && s.charCodeAt(end - 1) === 0x0a) end -= 1;
	return s.slice(start, end);
}
