// Inline-XML tool-call parser tests.
//
// These cover the streaming-parser behaviour spec'd in
// inline-xml-parser.ts:
//   - plain-text passthrough
//   - tag boundaries split across SSE chunks (the hard case)
//   - whitespace handling inside multi-line content args
//   - graceful degradation on malformed XML
//   - unknown tool names treated as literal text

import { describe, expect, it } from "vitest";
import { type InlineParsedToolCall, InlineXmlToolParser } from "../src/inline-xml-parser";

const KNOWN = ["read_file", "write_file", "exec", "list_dir"] as const;

/**
 * Feed all chunks then finalize; collect aggregated text and tool calls
 * across every step. Mirrors how the caller consumes the parser.
 */
function runChunks(chunks: readonly string[], known: readonly string[] = KNOWN) {
	const p = new InlineXmlToolParser(known);
	let text = "";
	const calls: InlineParsedToolCall[] = [];
	for (const c of chunks) {
		const out = p.feed(c);
		text += out.text;
		calls.push(...out.toolCalls);
	}
	const fin = p.finalize();
	text += fin.text;
	calls.push(...fin.toolCalls);
	return { text, calls };
}

describe("InlineXmlToolParser", () => {
	// 1
	it("passes plain text through unchanged", () => {
		const { text, calls } = runChunks(["hello world, no tools here."]);
		expect(text).toBe("hello world, no tools here.");
		expect(calls).toEqual([]);
	});

	// 2
	it("parses one complete tool in a single chunk", () => {
		const { text, calls } = runChunks(["<read_file><path>foo.ts</path></read_file>"]);
		expect(text).toBe("");
		expect(calls).toHaveLength(1);
		expect(calls[0]).toEqual({
			name: "read_file",
			args: { path: "foo.ts" },
			id: "ix_read_file_0",
		});
	});

	// 3
	it("re-assembles a tool whose tag name is split across two chunks", () => {
		const { text, calls } = runChunks(["<read_fi", "le><path>foo</path></read_file>"]);
		expect(text).toBe("");
		expect(calls).toHaveLength(1);
		expect(calls[0]?.name).toBe("read_file");
		expect(calls[0]?.args).toEqual({ path: "foo" });
	});

	// 4
	it("re-assembles a tool fed one byte at a time", () => {
		const full = "<read_file><path>foo.ts</path></read_file>";
		const chunks = full.split("");
		const { text, calls } = runChunks(chunks);
		expect(text).toBe("");
		expect(calls).toHaveLength(1);
		expect(calls[0]?.name).toBe("read_file");
		expect(calls[0]?.args).toEqual({ path: "foo.ts" });
	});

	// 5
	it("preserves multi-line arg content but trims one outer newline at each end", () => {
		const { calls } = runChunks([
			"<write_file><path>a.ts</path><content>\nline1\nline2\n</content></write_file>",
		]);
		expect(calls).toHaveLength(1);
		expect(calls[0]?.args).toEqual({ path: "a.ts", content: "line1\nline2" });
	});

	// 5b — verifying we trim only one outer newline (two leading newlines means one survives)
	it("only trims a single leading/trailing newline (deeper whitespace preserved)", () => {
		const { calls } = runChunks(["<write_file><content>\n\n  indented\n\n</content></write_file>"]);
		expect(calls[0]?.args.content).toBe("\n  indented\n");
	});

	// 6
	// DESIGN CHOICE documented inline in the parser source: text on
	// either side of a tool tag is emitted as-is, including the spaces
	// the model wrote around the tag. So `before <tool/> after` yields
	// the concatenation `"before  after"` — two spaces because both
	// the trailing space of "before " and the leading space of " after"
	// survive (the tool markup is what gets removed).
	it("interleaves plain text with tool calls and preserves surrounding whitespace", () => {
		const { text, calls } = runChunks(["before <read_file><path>x</path></read_file> after"]);
		expect(text).toBe("before  after");
		expect(calls).toHaveLength(1);
		expect(calls[0]?.args).toEqual({ path: "x" });
	});

	// 7
	it("emits two tool calls in order", () => {
		const { text, calls } = runChunks([
			"<read_file><path>a</path></read_file><read_file><path>b</path></read_file>",
		]);
		expect(text).toBe("");
		expect(calls.map((c) => c.args.path)).toEqual(["a", "b"]);
		// ids include the per-instance sequence number
		expect(calls.map((c) => c.id)).toEqual(["ix_read_file_0", "ix_read_file_1"]);
	});

	// 8
	it("passes unknown tool tags through as literal text", () => {
		const { text, calls } = runChunks(["<not_a_tool><foo>bar</foo></not_a_tool>"]);
		expect(calls).toEqual([]);
		// The unknown outer tag is emitted as `<not_a_tool>`; the
		// inner `<foo>` is then treated by idle-state scanning. Since
		// `foo` is also unknown, it likewise flushes literally. We
		// don't try to round-trip the whole XML — we just guarantee
		// no tool was claimed and the bytes are still visible.
		expect(text).toContain("<not_a_tool>");
		expect(text).toContain("</not_a_tool>");
		expect(text).toContain("foo");
		expect(text).toContain("bar");
	});

	// 9
	it("flushes an unclosed tool block on finalize as literal text", () => {
		const p = new InlineXmlToolParser(KNOWN);
		const mid = p.feed("<write_file><path>a.ts</path><content>partial");
		expect(mid.text).toBe("");
		expect(mid.toolCalls).toEqual([]);
		const end = p.finalize();
		// We get back text representing what the model emitted, with
		// the tool name and arg structure preserved as literal markup.
		expect(end.toolCalls).toEqual([]);
		expect(end.text).toContain("write_file");
		expect(end.text).toContain("a.ts");
		expect(end.text).toContain("partial");
	});

	// 10
	it("passes a bare `<` followed by a digit through as text", () => {
		const { text, calls } = runChunks(["5 < 10 and 7<3 is false"]);
		expect(calls).toEqual([]);
		expect(text).toBe("5 < 10 and 7<3 is false");
	});

	// 11
	it("preserves arg insertion order in the returned args object", () => {
		const { calls } = runChunks(["<write_file><path>a.ts</path><content>hi</content></write_file>"]);
		expect(Object.keys(calls[0]?.args ?? {})).toEqual(["path", "content"]);
	});

	// 12
	it("captures every arg when a tool has more than one", () => {
		const { calls } = runChunks(["<exec><command>ls -la</command><cwd>/tmp</cwd></exec>"]);
		expect(calls).toHaveLength(1);
		expect(calls[0]?.args).toEqual({ command: "ls -la", cwd: "/tmp" });
	});

	// extra: byte-by-byte feed for a multi-arg tool, to confirm boundaries
	// inside arg values also work
	it("handles tag splits inside an arg value boundary (byte-by-byte)", () => {
		const full = "<write_file><path>a.ts</path><content>\nhello\n</content></write_file>";
		const chunks = full.split("");
		const { text, calls } = runChunks(chunks);
		expect(text).toBe("");
		expect(calls).toHaveLength(1);
		expect(calls[0]?.args).toEqual({ path: "a.ts", content: "hello" });
	});

	// extra: `<` literal sitting between two valid tools
	it("emits plain `<` text between two valid tool calls", () => {
		const { text, calls } = runChunks([
			"<read_file><path>a</path></read_file> 1 < 2 <read_file><path>b</path></read_file>",
		]);
		expect(calls.map((c) => c.args.path)).toEqual(["a", "b"]);
		expect(text).toBe(" 1 < 2 ");
	});

	// extra: nested-tag-looking text inside an arg value stays literal
	it("keeps tag-shaped text inside an arg value as literal characters", () => {
		const { calls } = runChunks([
			"<write_file><content>const x = <T>(): T => null;</content></write_file>",
		]);
		expect(calls).toHaveLength(1);
		expect(calls[0]?.args.content).toBe("const x = <T>(): T => null;");
	});

	// extra: feed returns immediately when no terminator yet, then
	// completes on a later feed (no need to call finalize)
	it("does not require finalize() when the stream ended cleanly mid-feed", () => {
		const p = new InlineXmlToolParser(KNOWN);
		const a = p.feed("<read_file><path>x");
		expect(a.text).toBe("");
		expect(a.toolCalls).toEqual([]);
		const b = p.feed("</path></read_file>");
		expect(b.text).toBe("");
		expect(b.toolCalls).toHaveLength(1);
		expect(b.toolCalls[0]?.args).toEqual({ path: "x" });
	});

	// extra: empty feed is a no-op
	it("treats an empty feed as a no-op", () => {
		const p = new InlineXmlToolParser(KNOWN);
		const out = p.feed("");
		expect(out.text).toBe("");
		expect(out.toolCalls).toEqual([]);
	});
});
