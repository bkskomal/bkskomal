import type {
	HostContext,
	ModeConfig,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
	ToolSpec,
} from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { Agent, extractFileCreationClaims, normalizeToolArgs } from "../src/agent";

const baseMode: ModeConfig = {
	id: "test",
	displayName: "Test",
	systemPrompt: "test",
	enabledTools: "all",
	enablePlanner: false,
	enableCritic: false,
	maxParallelAgents: 1,
	maxIterations: 5,
};

function makeHost(overrides: Partial<HostContext> = {}): HostContext {
	return {
		readFile: vi.fn().mockResolvedValue(""),
		writeFile: vi.fn().mockResolvedValue(undefined),
		fileExists: vi.fn().mockResolvedValue(false),
		exec: vi.fn().mockResolvedValue({ stdout: "", stderr: "", exitCode: 0 }),
		workspaceRoot: () => "/test",
		requestApproval: vi.fn().mockResolvedValue(true),
		showDiff: vi.fn().mockResolvedValue(undefined),
		log: vi.fn(),
		...overrides,
	};
}

function makeProvider(events: ProviderStreamEvent[][]): ProviderSpec {
	let call = 0;
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest) {
			const slice = events[call++] ?? [{ type: "message_end", stopReason: "end" }];
			for (const ev of slice) yield ev;
		},
	};
}

describe("Agent", () => {
	it("runs a single turn with text-only response and emits done", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "Hello" },
				{ type: "text_delta", text: " world" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "a1", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const events: string[] = [];
		agent.on((ev) => events.push(ev.type));
		await agent.run({ userMessage: "hi" });

		expect(events).toContain("text_delta");
		expect(events).toContain("done");
		expect(agent.getHistory()).toHaveLength(2); // user + assistant
		expect(agent.getHistory()[1].role).toBe("assistant");
	});

	it("executes a tool call and continues the loop", async () => {
		const fakeTool: ToolSpec = {
			name: "echo",
			description: "echo back",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler(args) {
				return { received: args };
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "echo", args: { x: 1 } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "a2", provider, tools: [fakeTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const toolResults: unknown[] = [];
		agent.on((ev) => {
			if (ev.type === "tool_result") toolResults.push(ev.result.output);
		});
		await agent.run({ userMessage: "use echo" });

		expect(toolResults).toHaveLength(1);
		expect(toolResults[0]).toEqual({ received: { x: 1 } });
		// history: user, assistant(tool_call), tool(tool_result), assistant(text)
		expect(agent.getHistory()).toHaveLength(4);
	});

	it("denies a 'deny' policy tool with an error result", async () => {
		const denied: ToolSpec = {
			name: "danger",
			description: "should never run",
			schema: { type: "object", properties: {} },
			approval: "deny",
			async handler() {
				throw new Error("must not be called");
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "danger", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "a3", provider, tools: [denied], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		let lastResult: { output: unknown; isError: boolean } | undefined;
		agent.on((ev) => {
			if (ev.type === "tool_result") lastResult = ev.result;
		});
		await agent.run({ userMessage: "try to use danger" });

		expect(lastResult?.isError).toBe(true);
		expect(String(lastResult?.output)).toContain("denied");
	});

	it("respects requestApproval=false for prompt-policy tools", async () => {
		const host = makeHost({ requestApproval: vi.fn().mockResolvedValue(false) });
		const tool: ToolSpec = {
			name: "do_thing",
			description: "do",
			schema: { type: "object", properties: {} },
			approval: "prompt",
			async handler() {
				throw new Error("should not run");
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "do_thing", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "a4", provider, tools: [tool], host, mode: baseMode },
			{ modelId: "test-model" },
		);
		let lastResult: { output: unknown; isError: boolean } | undefined;
		agent.on((ev) => {
			if (ev.type === "tool_result") lastResult = ev.result;
		});
		await agent.run({ userMessage: "go" });

		expect(host.requestApproval).toHaveBeenCalled();
		expect(lastResult?.isError).toBe(true);
		expect(String(lastResult?.output)).toContain("declined");
	});

	it("normalizes wrapped tool-call args BEFORE preview, approval, and handler all see them", async () => {
		// Regression for Kimi K2.6: when the provider emits args as
		// `{_raw: '"{\"path\":\"foo\"}"'}`, the preview computation, the
		// approval dialog, the loop-guard fingerprint, AND the handler all
		// must see the unwrapped `{path:"foo"}` form. Previously only the
		// handler did, so previews returned no diff and the loop-guard
		// could not detect duplicate-arg retries with varying escape levels.
		const seenByPreview: unknown[] = [];
		const seenByHandler: unknown[] = [];
		const tool: ToolSpec = {
			name: "writer",
			description: "writes",
			schema: { type: "object", properties: {} },
			approval: "prompt",
			async prepareApprovalPreview(args) {
				seenByPreview.push(args);
				return {};
			},
			async handler(args) {
				seenByHandler.push(args);
				return "ok";
			},
		};
		const wrappedArgs = {
			_raw: JSON.stringify(JSON.stringify({ path: "foo.ts", content: "x" })),
		};
		const requestApproval = vi.fn().mockResolvedValue(true);
		const host = makeHost({ requestApproval });
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: wrappedArgs },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const emittedCalls: unknown[] = [];
		const agent = new Agent(
			{ id: "a-norm", provider, tools: [tool], host, mode: baseMode },
			{ modelId: "test-model" },
		);
		agent.on((ev) => {
			if (ev.type === "tool_call") emittedCalls.push(ev.call.args);
		});
		await agent.run({ userMessage: "go" });

		const expected = { path: "foo.ts", content: "x" };
		expect(seenByPreview[0]).toEqual(expected);
		expect(seenByHandler[0]).toEqual(expected);
		expect(emittedCalls[0]).toEqual(expected);
		expect(requestApproval).toHaveBeenCalledWith(expect.objectContaining({ args: expected }));
	});

	it("stops at max_iterations and emits done with that reason", async () => {
		// Provider always emits a tool call → infinite loop guard
		const tool: ToolSpec = {
			name: "loop",
			description: "loop",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return "ok";
			},
		};
		const provider: ProviderSpec = {
			id: "loop-provider",
			displayName: "loop",
			async *stream() {
				yield { type: "tool_call", id: `t${Math.random()}`, name: "loop", args: {} };
				yield { type: "message_end", stopReason: "tool_use" };
			},
		};
		const agent = new Agent(
			{
				id: "a5",
				provider,
				tools: [tool],
				host: makeHost(),
				mode: { ...baseMode, maxIterations: 3 },
			},
			{ modelId: "test-model" },
		);
		const doneReasons: string[] = [];
		agent.on((ev) => {
			if (ev.type === "done") doneReasons.push(ev.reason);
		});
		await agent.run({ userMessage: "start" });

		expect(doneReasons).toEqual(["max_iterations"]);
	});

	it("emits a single usage event AFTER the assistant message lands (per-turn attribution)", async () => {
		// Provider yields two partial usage bursts; agent should aggregate and
		// fire one usage event, ordered AFTER the user→assistant history append.
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "hi" },
				{ type: "usage", usage: { inputTokens: 10, outputTokens: 0 } },
				{ type: "usage", usage: { inputTokens: 0, outputTokens: 5 } },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "a-usage", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const events: Array<{ type: string; inputTokens?: number; outputTokens?: number }> = [];
		agent.on((ev) => {
			if (ev.type === "usage")
				events.push({
					type: ev.type,
					inputTokens: ev.inputTokens,
					outputTokens: ev.outputTokens,
				});
			else events.push({ type: ev.type });
		});
		await agent.run({ userMessage: "go" });
		const usages = events.filter((e) => e.type === "usage");
		expect(usages).toHaveLength(1);
		expect(usages[0].inputTokens).toBe(10);
		expect(usages[0].outputTokens).toBe(5);
	});

	it("safety-net wrap-up says 'Done' when recent tool calls succeeded, but warns when they FAILED", async () => {
		// Two scenarios in one test, each with its own provider sequence:
		//   (a) tool succeeds → no text in next assistant turn → wrap-up should say "Done"
		//   (b) tool fails (handler throws) → no text → wrap-up should warn the user
		//
		// This regression guards against the 2026-05-24 bug where the
		// safety net unconditionally said "✅ Done" even after tool
		// failures, misleading users about whether work succeeded.

		const failingTool: ToolSpec = {
			name: "broken",
			description: "always fails",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				throw new Error("simulated failure");
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "broken", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			// Second turn: no text, no tool calls → safety-net fires.
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "wrapup-fail", provider, tools: [failingTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "do the thing" });
		// The wrap-up should NOT claim success when the tool failed.
		const wrap = texts.join("");
		expect(wrap).toMatch(/Stopped without a written summary|failed|may NOT be complete/i);
		expect(wrap).not.toMatch(/^✅ Done/);
	});

	it("auto-continues once when the model stops mid-thought (text ends with ':' and no tool call)", async () => {
		// Live-bug regression (2026-05-25): the model wrote "Let me check the
		// workspace..." and then ended the stream. Old behavior: silent done,
		// no progress indicator, no follow-up. New behavior: inject a
		// "continue" nudge, loop once more, let the model actually do it.
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "Let me check the workspace structure:" },
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "Here's the structure: foo/, bar/." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "mid-thought", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "where are we?" });
		const history = agent.getHistory();
		// user → assistant("Let me check…") → injected user("Continue from…") → assistant("Here's…")
		expect(history).toHaveLength(4);
		expect(history[2].role).toBe("user");
		const continueText = history[2].parts.find((p) => p.kind === "text") as
			| { kind: "text"; text: string }
			| undefined;
		expect(continueText?.text).toMatch(/Continue from where you left off/);
		expect(history[3].role).toBe("assistant");
	});

	it("auto-continues when the only tool call failed and the model went silent (screenshot 2 case)", async () => {
		// Live-bug regression (2026-05-25): the model called load_skill with
		// empty args, the tool errored, and the model wrote nothing. Old
		// behavior: honest Done warning, end of turn. New behavior: nudge the
		// model to retry / recover before falling back to the warning.
		const failingTool: ToolSpec = {
			name: "broken",
			description: "always fails",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				throw new Error("simulated failure");
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "broken", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			// Iter 2: model goes completely silent after seeing the tool
			// failure. This is exactly screenshot 2's state — nothing for the
			// chat to render, no decision to relay. Auto-continue must fire.
			[{ type: "message_end", stopReason: "end" }],
			// Iter 3: after the nudge, model writes a real summary.
			[
				{ type: "text_delta", text: "That tool errored on empty args. Stopping." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "fail-recover", provider, tools: [failingTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "do the thing" });
		const history = agent.getHistory();
		// Find the injected user-role nudge.
		const userTurns = history.filter((m) => m.role === "user");
		expect(userTurns).toHaveLength(2);
		const nudgeText = userTurns[1].parts.find((p) => p.kind === "text") as
			| { kind: "text"; text: string }
			| undefined;
		expect(nudgeText?.text).toMatch(/previous tool call failed/i);
		// And the model's recovery text should be present in the final assistant turn.
		const lastAssistant = history[history.length - 1];
		expect(lastAssistant.role).toBe("assistant");
		const lastText = lastAssistant.parts.find((p) => p.kind === "text") as
			| { kind: "text"; text: string }
			| undefined;
		expect(lastText?.text).toMatch(/errored on empty args/);
	});

	it("injects an enqueued user message at the next iteration boundary (mid-turn interjection)", async () => {
		// Simulates: the user types "scratch that, do X instead" WHILE the
		// agent is mid-way through a multi-iteration turn. The new message
		// must show up in history BEFORE the model's next call, not after
		// the whole turn finishes.
		const echoTool: ToolSpec = {
			name: "echo",
			description: "echo",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler(args) {
				return { received: args };
			},
		};
		// Iter 1: tool call (gives us a between-iteration gap to enqueue).
		// Iter 2: model writes a final answer.
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "echo", args: { round: 1 } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "Acknowledged the new instruction." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "mid-turn", provider, tools: [echoTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);

		// Enqueue mid-stream: schedule on the next microtask so the call
		// lands between iterations 1 and 2.
		const injectedEvents: string[] = [];
		agent.on((ev) => {
			if (ev.type === "user_message_injected") injectedEvents.push(ev.text);
			if (ev.type === "tool_result") {
				// As soon as iter-1's tool result lands, enqueue. The next
				// iteration's drain step will pick it up.
				agent.enqueueUserMessage("Stop and do X instead");
			}
		});

		await agent.run({ userMessage: "start" });

		// The injected message must exist in history as a user-role turn.
		const history = agent.getHistory();
		const injectedUser = history.find(
			(m) =>
				m.role === "user" &&
				m.parts.some((p) => p.kind === "text" && p.text === "Stop and do X instead"),
		);
		expect(injectedUser).toBeDefined();
		expect(injectedEvents).toEqual(["Stop and do X instead"]);
		// And the queue must be empty afterwards.
		expect(agent.hasPendingUserInput()).toBe(false);
	});

	it("does NOT auto-continue twice in the same turn (one-shot guard)", async () => {
		// If the model keeps trailing off after the auto-continue nudge, we
		// must stop — otherwise the loop ping-pongs until maxIterations.
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "Let me check..." },
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "I'll start by..." },
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "Now I'll..." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "one-shot", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "do it" });
		const history = agent.getHistory();
		// user → assistant(1) → injected-continue user → assistant(2) → done
		// (no third auto-continue, even though assistant(2) ends "...")
		expect(history).toHaveLength(4);
		expect(history[3].role).toBe("assistant");
		const last = history[3].parts.find((p) => p.kind === "text") as
			| { kind: "text"; text: string }
			| undefined;
		expect(last?.text).toBe("I'll start by...");
	});

	it("safety-net wrap-up DOES say 'Done' when every recent tool call succeeded", async () => {
		const okTool: ToolSpec = {
			name: "ok_tool",
			description: "always succeeds",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return "ok";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "ok_tool", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "wrapup-ok", provider, tools: [okTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "do the thing" });
		const wrap = texts.join("");
		expect(wrap).toMatch(/^✅ Done/);
	});

	it("appends optional userParts (e.g. image parts) onto the user turn", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "a-parts", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({
			userMessage: "what is this?",
			userParts: [{ kind: "image", mimeType: "image/png", dataUrl: "data:image/png;base64,AAAA" }],
		});
		const user = agent.getHistory()[0];
		expect(user.role).toBe("user");
		expect(user.parts).toHaveLength(2);
		expect(user.parts[1]).toMatchObject({ kind: "image", mimeType: "image/png" });
	});

	it("returns from initialHistory plus newly appended turns", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initial = [
			{
				role: "user" as const,
				parts: [{ kind: "text" as const, text: "earlier" }],
			},
			{
				role: "assistant" as const,
				parts: [{ kind: "text" as const, text: "earlier reply" }],
			},
		];
		const agent = new Agent(
			{ id: "a6", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
			initial,
		);
		await agent.run({ userMessage: "follow-up" });

		const history = agent.getHistory();
		expect(history[0]).toEqual(initial[0]);
		expect(history[1]).toEqual(initial[1]);
		expect(history[2].role).toBe("user");
		expect(history[3].role).toBe("assistant");
	});
});

describe("Agent turn lifecycle events (Phase 3.1)", () => {
	it("emits exactly one turn_start before any iteration", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "hi" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "tt1", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const seen: string[] = [];
		agent.on((ev) => seen.push(ev.type));
		await agent.run({ userMessage: "hello" });
		const starts = seen.filter((t) => t === "turn_start");
		expect(starts).toHaveLength(1);
		// turn_start must come BEFORE any iteration event.
		expect(seen.indexOf("turn_start")).toBeLessThan(seen.indexOf("iteration"));
	});

	it("emits turn_end with matching turnId after the final done", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "tt2", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		let startTurnId: string | undefined;
		let endTurnId: string | undefined;
		let endOutcome: string | undefined;
		agent.on((ev) => {
			if (ev.type === "turn_start") startTurnId = ev.turnId;
			if (ev.type === "turn_end") {
				endTurnId = ev.turnId;
				endOutcome = ev.outcome;
			}
		});
		await agent.run({ userMessage: "go" });
		expect(startTurnId).toBeDefined();
		expect(endTurnId).toBe(startTurnId);
		expect(endOutcome).toBe("end");
	});

	it("emits turn_end with outcome=cancelled when the run is aborted before any iteration", async () => {
		const provider = makeProvider([]);
		const agent = new Agent(
			{ id: "tt3", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const outcomes: string[] = [];
		agent.on((ev) => {
			if (ev.type === "turn_end") outcomes.push(ev.outcome);
		});
		const abort = new AbortController();
		abort.abort();
		await agent.run({ userMessage: "x", signal: abort.signal });
		expect(outcomes).toEqual(["cancelled"]);
	});

	it("emits turn_end with outcome=max_iterations when the loop guard fires", async () => {
		// Provider loops forever; mode caps iterations at 2.
		const looper: ProviderSpec = {
			id: "loop",
			displayName: "loop",
			async *stream() {
				yield { type: "tool_call", id: `t${Math.random()}`, name: "noop", args: {} };
				yield { type: "message_end", stopReason: "tool_use" };
			},
		};
		const noopTool: ToolSpec = {
			name: "noop",
			description: "noop",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return "ok";
			},
		};
		const agent = new Agent(
			{
				id: "tt4",
				provider: looper,
				tools: [noopTool],
				host: makeHost(),
				mode: { ...baseMode, maxIterations: 2 },
			},
			{ modelId: "test-model" },
		);
		const outcomes: string[] = [];
		agent.on((ev) => {
			if (ev.type === "turn_end") outcomes.push(ev.outcome);
		});
		await agent.run({ userMessage: "start" });
		expect(outcomes).toEqual(["max_iterations"]);
	});

	it("turn_start carries the userMessage verbatim so host snapshots can label themselves", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "tt5", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		let captured: string | undefined;
		agent.on((ev) => {
			if (ev.type === "turn_start") captured = ev.userMessage;
		});
		await agent.run({ userMessage: "rename foo to bar across the codebase" });
		expect(captured).toBe("rename foo to bar across the codebase");
	});
});

describe("normalizeToolArgs", () => {
	it("passes objects through unchanged", () => {
		const obj = { path: "foo.ts" };
		expect(normalizeToolArgs(obj)).toBe(obj);
	});

	it("coerces null/undefined/empty-string to an empty object (Moonshot K2 #100 class)", () => {
		// 2026-05-25: when a provider emits a tool call with no args, the
		// downstream handler must see `{}`, not `null` — otherwise simple
		// destructuring (`const { path } = args`) blows up on a null
		// receiver before the handler's own arg-guard can surface a
		// useful "field required" error. The coercion is the last
		// defensive boundary before the tool runs.
		expect(normalizeToolArgs(null)).toEqual({});
		expect(normalizeToolArgs(undefined)).toEqual({});
		expect(normalizeToolArgs("")).toEqual({});
		expect(normalizeToolArgs("   ")).toEqual({});
	});

	it("unwraps a JSON-string of an object (single layer)", () => {
		const wrapped = JSON.stringify({ path: "foo.ts" });
		expect(normalizeToolArgs(wrapped)).toEqual({ path: "foo.ts" });
	});

	it("unwraps a double-wrapped JSON string (string-of-string-of-object)", () => {
		const wrapped = JSON.stringify(JSON.stringify({ path: "foo.ts" }));
		expect(normalizeToolArgs(wrapped)).toEqual({ path: "foo.ts" });
	});

	it("unwraps a triple-wrapped JSON string", () => {
		const wrapped = JSON.stringify(JSON.stringify(JSON.stringify({ path: "foo.ts" })));
		expect(normalizeToolArgs(wrapped)).toEqual({ path: "foo.ts" });
	});

	it("unwraps a single-wrapped `{_raw: ...}` provider fallback", () => {
		const args = { _raw: JSON.stringify({ path: "foo.ts" }) };
		expect(normalizeToolArgs(args)).toEqual({ path: "foo.ts" });
	});

	it("unwraps double-wrapped `{_raw: ...}` (Kimi K2.6 observed shape)", () => {
		// Real-world trace: _raw contains a JSON-string of a JSON-string of the obj.
		const inner = JSON.stringify({ path: "scripts.js", content: "// hi" });
		const wrappedOnce = JSON.stringify(inner);
		const args = { _raw: wrappedOnce };
		expect(normalizeToolArgs(args)).toEqual({ path: "scripts.js", content: "// hi" });
	});

	it("returns string unchanged when its JSON yields a non-object scalar", () => {
		expect(normalizeToolArgs("42")).toBe("42");
		expect(normalizeToolArgs("true")).toBe("true");
	});

	it("returns unparseable string unchanged so the tool can report a precise error", () => {
		expect(normalizeToolArgs("not json {")).toBe("not json {");
	});

	it("leaves `_raw` wrapper intact when the payload is not parseable", () => {
		const args = { _raw: "not json {" };
		expect(normalizeToolArgs(args)).toBe(args);
	});

	it("does not unwrap an object that merely contains a `_raw` key alongside others", () => {
		const args = { _raw: "{}", other: 1 };
		expect(normalizeToolArgs(args)).toBe(args);
	});

	it("unwraps a string-of-`{_raw: stringified-object}` (model self-wrapping pattern)", () => {
		// Observed in the wild: once Kimi has been told once that we use
		// `_raw`, it starts emitting `arguments` as a JSON-string of a
		// `{_raw: "..."}` envelope whose payload is more wrapped JSON.
		const real = { command: "powershell -Command Set-Content" };
		const innerStr = JSON.stringify(real); // '{"command":"..."}'
		const envelope = { _raw: JSON.stringify(innerStr) }; // {_raw: '"{\"command\":...}"'}
		const wrapped = JSON.stringify(envelope); // '"{"_raw":"\"{\\\"command\\\":..."}"'
		expect(normalizeToolArgs(wrapped)).toEqual(real);
	});

	it("unwraps `{_raw: stringified `{_raw: stringified-object}`}` (nested envelope)", () => {
		const real = { path: "scripts.js", content: "// hi" };
		const inner = { _raw: JSON.stringify(JSON.stringify(real)) };
		const outer = { _raw: JSON.stringify(inner) };
		expect(normalizeToolArgs(outer)).toEqual(real);
	});

	it("stops cleanly when iterative unwrapping cannot reach an object", () => {
		// _raw whose payload is itself just a number — not a valid tool-arg
		// shape. Should return the original envelope untouched so the tool
		// reports a precise error.
		const args = { _raw: "42" };
		expect(normalizeToolArgs(args)).toBe(args);
	});

	// 2026-05-23 regression: Kimi K2.6 was looping on multi-line content
	// args (write_file with code) because the OUTER JSON.parse succeeds
	// and yields an inner string whose embedded `\n` decoded to a raw
	// newline byte — strict JSON.parse on THAT inner string rejects.
	// The old deepUnwrapToObject gave up at the first strict-parse
	// failure on an intermediate layer; the fix repairs control chars
	// at every layer using the same logic the provider uses on the
	// outermost string.
	it("recovers when an intermediate unwrap layer has literal control chars (Kimi multi-line write)", () => {
		const real = { path: "scripts.js", content: "line1\nline2\nline3" };
		// Mimic Kimi's pathological emit: a JSON-encoded string of a
		// JSON-encoded string of the object. The OUTER decode yields the
		// inner JSON-string with the literal newline preserved — that
		// shape used to break strict-parse on the inner layer.
		const innerJson = JSON.stringify(real);
		const wrapped = JSON.stringify(innerJson);
		expect(normalizeToolArgs(wrapped)).toEqual(real);
	});

	it("recovers when `_raw` wraps a string whose payload has literal control chars", () => {
		const real = { path: "scripts.js", content: "\ttab\nnewline\rcarriage" };
		const inner = JSON.stringify(real); // ascii-safe, escaped
		// Now corrupt: pretend the wire dropped the escaping on the inner
		// control chars (this is roughly what we see when the provider
		// has already decoded one layer before reaching us).
		const corrupted = inner.replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\r/g, "\r");
		// Sanity: strict JSON.parse fails on the corrupted form.
		expect(() => JSON.parse(corrupted)).toThrow();
		// But normalize, via the lenient repair, should recover the object.
		const args = { _raw: corrupted };
		expect(normalizeToolArgs(args)).toEqual(real);
	});

	// 2026-05-24 regression: trace showed a Write call with 4 layers of
	// _raw-of-string-of-_raw nesting (quadruple-escaped quotes). The
	// previous maxDepth=4 was being exhausted; bumped to 8 with the
	// outer loop cap raised to 10 for headroom. If this test ever
	// breaks, check whether Kimi is producing even deeper nesting OR
	// the wire format changed and the prompt is teaching it again.
	it("unwraps 4 layers of `{_raw: stringified-{_raw: stringified-{_raw: stringified-object}}}`", () => {
		const real = { path: "scripts.js", content: "console.log('ok');" };
		const layer1 = { _raw: JSON.stringify(real) };
		const layer2 = { _raw: JSON.stringify(layer1) };
		const layer3 = { _raw: JSON.stringify(layer2) };
		const layer4 = { _raw: JSON.stringify(layer3) };
		expect(normalizeToolArgs(layer4)).toEqual(real);
	});

	it("unwraps 4 layers of pure stringified JSON-string nesting (no _raw envelope)", () => {
		const real = { path: "scripts.js", content: "x" };
		let cur: unknown = real;
		for (let i = 0; i < 4; i++) cur = JSON.stringify(cur);
		expect(normalizeToolArgs(cur)).toEqual(real);
	});

	// 2026-05-25: when nesting exceeds the unwrap maxDepth and normalize
	// can't reach an object, the wrapped shape would otherwise be stored
	// VERBATIM in history. The model then sees its own malformed payload
	// on every subsequent turn and the provider eventually returns empty
	// because the input is too confused to act on. Verifying here that
	// the input survives (test guards the underlying primitive); the
	// `history sanitization` test below confirms the Agent layer
	// SWAPS in a clean placeholder.
	it("returns the still-wrapped shape unchanged when nesting exceeds maxDepth (caller decides what to do)", () => {
		const real = { path: "scripts.js" };
		let cur: unknown = real;
		// 10 layers — well past the maxDepth=8 cap.
		for (let i = 0; i < 10; i++) cur = JSON.stringify(cur);
		const out = normalizeToolArgs(cur);
		// We can't get an object back at this nesting level. Make sure
		// we still return SOMETHING (not throw) so the caller can sub
		// in a placeholder.
		expect(typeof out).toBe("string");
	});
});

describe("Agent — history sanitization (Phase: 2026-05-25)", () => {
	it("does NOT poison history with megabytes of nested-stringify wrap — recovers clean args via the new smart-recovery path", async () => {
		// Build args nested DEEP enough that normalize can't reach the
		// inner object on its own (8-layer deepUnwrap cap). The 2026-05-25
		// recovery pass picks up where normalize leaves off, peeling the
		// remaining layers via strict JSON.parse until a clean object
		// surfaces. Either way the goal is: history must NOT carry
		// megabytes of escaped JSON across turns.
		const real = { path: "scripts.js", content: "x" };
		let nested: unknown = real;
		for (let i = 0; i < 12; i++) nested = JSON.stringify(nested);
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler(args) {
				return { received: args };
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: nested },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "san1", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "go" });

		const history = agent.getHistory();
		const assistantTurns = history.filter((m) => m.role === "assistant");
		const toolCallPart = assistantTurns.flatMap((m) => m.parts).find((p) => p.kind === "tool_call");
		expect(toolCallPart).toBeDefined();
		const args = (toolCallPart as { args: unknown }).args as Record<string, unknown>;
		// Recovery succeeded — args are the original clean shape.
		expect(args.path).toBe("scripts.js");
		expect(args.content).toBe("x");
		expect(args._oatiMalformed).toBeUndefined();
		// And history hasn't blown up to megabytes of nested escaping.
		expect(JSON.stringify(args).length).toBeLessThan(500);
	});

	it("emits a `[wrapped-args]` diagnostic event when the failsafe trips — so verbose-mode chat surfaces the raw payload", async () => {
		// User-driven feature (2026-05-25): when Diagnostics is ON in
		// Settings, the wrapped-args raw payload should be visible IN THE
		// CHAT so the user can copy-paste it to diagnose stuck tool calls
		// without hunting through the Output channel. The agent emits the
		// info as an `error` event with a `[wrapped-args]` prefix; the
		// webview's `isInternalAgentDiagnosticMessage` filter recognizes
		// that prefix and hides it when verboseInternals is OFF.
		const garbageRaw = "{garbled junk no quotes}";
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
				required: ["path", "content"],
			},
			approval: "auto",
			async handler(args) {
				return { received: args };
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: garbageRaw },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const errorEvents: string[] = [];
		const agent = new Agent(
			{ id: "diag", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		agent.on((ev) => {
			if (ev.type === "error") errorEvents.push(ev.message);
		});
		await agent.run({ userMessage: "go" });
		const wrappedDiagnostics = errorEvents.filter((m) => m.startsWith("[wrapped-args]"));
		expect(wrappedDiagnostics.length).toBeGreaterThan(0);
		// And the raw payload must be in the diagnostic so the user can
		// copy-paste it.
		expect(wrappedDiagnostics[0]).toContain("garbled junk");
	});

	it("emits a `[wrapped-args]` diagnostic with `recovered fields=` when smart-recovery rescues the call", async () => {
		// The success counterpart — recovery wins, but the diagnostic still
		// fires so the user can confirm the rescue happened and which
		// fields landed. Useful for diagnosing intermittent provider
		// flakiness.
		const real = { path: "scripts.js", content: "x" };
		let nested: unknown = real;
		for (let i = 0; i < 12; i++) nested = JSON.stringify(nested);
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler() {
				return "ok";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: nested },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const errorEvents: string[] = [];
		const agent = new Agent(
			{ id: "diag-ok", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		agent.on((ev) => {
			if (ev.type === "error") errorEvents.push(ev.message);
		});
		await agent.run({ userMessage: "go" });
		const recoveryDiagnostic = errorEvents.find((m) => m.includes("recovered fields="));
		expect(recoveryDiagnostic).toBeDefined();
		expect(recoveryDiagnostic).toContain("path");
		expect(recoveryDiagnostic).toContain("content");
	});

	it("prepends a one-shot self-correction note to the first tool_result when wrapped-args recovery fires", async () => {
		// The "teach once per turn" mechanism from 2026-05-29: when a
		// wrapped-args recovery succeeds, the model never sees that anything
		// went wrong, so on multi-file scaffolds it kept emitting the same
		// wrapping for every subsequent write_file. The advice note lands as
		// a prefix on the FIRST tool_result so the model reads the correction
		// before reading the call's output.
		const real = { path: "x.ts", content: "ok" };
		let nested: unknown = real;
		for (let i = 0; i < 12; i++) nested = JSON.stringify(nested);
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler() {
				return "wrote file";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: nested },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "advice", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const toolMessage = history.find((m) => m.role === "tool");
		expect(toolMessage).toBeDefined();
		const firstResult = toolMessage?.parts.find((p) => p.kind === "tool_result") as
			| { output: unknown }
			| undefined;
		expect(firstResult).toBeDefined();
		const output = String(firstResult?.output ?? "");
		expect(output).toContain("OATI auto-correction");
		expect(output).toContain("flat JSON object");
		// The actual handler output should follow the advice, separated by ---.
		expect(output).toContain("wrote file");
		expect(output.indexOf("OATI auto-correction")).toBeLessThan(output.indexOf("wrote file"));
	});

	it("does NOT prepend the self-correction when args were clean (no recovery needed)", async () => {
		// Negative case: when the model already emits clean args, no advice
		// should fire — otherwise we waste tokens and train it to ignore
		// genuine corrections.
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler() {
				return "wrote file";
			},
		};
		const provider = makeProvider([
			[
				{
					type: "tool_call",
					id: "tc1",
					name: "writer",
					args: { path: "x.ts", content: "ok" },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "no-advice", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const toolMessage = history.find((m) => m.role === "tool");
		const firstResult = toolMessage?.parts.find((p) => p.kind === "tool_result") as
			| { output: unknown }
			| undefined;
		const output = String(firstResult?.output ?? "");
		expect(output).not.toContain("OATI auto-correction");
		expect(output).toContain("wrote file");
	});

	it("self-correction note fires AT MOST ONCE per turn even when many recoveries occur", async () => {
		// 2026-05-29 live-bug regression: the original "one-shot" flag was
		// per-batch, not per-turn. A 30-call scaffold that kept tripping
		// wrapped-args recovery rendered the same teach note 15+ times in
		// chat. With the per-turn `wrappedArgsAdviceEmittedThisTurn` flag,
		// only the FIRST recovery's result carries the note; subsequent
		// recoveries still get rescued silently.
		const real = { path: "x.ts", content: "ok" };
		let nested: unknown = real;
		for (let i = 0; i < 12; i++) nested = JSON.stringify(nested);
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler() {
				return "wrote file";
			},
		};
		// Three sequential turns where each emits one wrapped-args tool call.
		// Inside one turn that's 3 separate executeToolCalls batches.
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: nested },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "tool_call", id: "tc2", name: "writer", args: nested },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "tool_call", id: "tc3", name: "writer", args: nested },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "once-per-turn", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "scaffold a project" });
		const history = agent.getHistory();
		const toolResultOutputs = history
			.filter((m) => m.role === "tool")
			.flatMap((m) =>
				m.parts.filter(
					(p): p is { kind: "tool_result"; output: unknown; id: string; isError?: boolean } =>
						p.kind === "tool_result",
				),
			)
			.map((p) => String(p.output ?? ""));
		const teachCount = toolResultOutputs.filter((o) => o.includes("OATI auto-correction")).length;
		expect(teachCount).toBe(1);
		// At least three calls got dispatched — every result that ran the
		// handler shows the "wrote file" output. Honest-Done / verify passes
		// may append an extra synthetic tool result; what matters is the
		// teach-count stays at one.
		expect(toolResultOutputs.length).toBeGreaterThanOrEqual(3);
		const handlerHits = toolResultOutputs.filter((o) => o.includes("wrote file")).length;
		expect(handlerHits).toBeGreaterThanOrEqual(3);
	});

	it("falls back to the placeholder hint when recovery genuinely can't extract the required fields", async () => {
		// Recovery CAN'T salvage everything. When the raw payload is pure
		// garbage that doesn't contain the schema's required field names,
		// the recovery pass returns undefined and the placeholder hint
		// fires. This test guards that fallback path stays alive.
		// Starts with `{` so the wrapped-args heuristic flags it; unparseable
		// JSON inside so recovery's strict-parse + regex passes both fail.
		const garbageRaw = "{garbled junk no quotes no colons just words}";
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
				required: ["path", "content"],
			},
			approval: "auto",
			async handler(args) {
				return { received: args };
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: garbageRaw },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "fallback", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const toolCallPart = history.flatMap((m) => m.parts).find((p) => p.kind === "tool_call");
		const args = (toolCallPart as { args: unknown }).args as Record<string, unknown>;
		expect(args._oatiMalformed).toBe(true);
		expect(typeof args._hint).toBe("string");
		// Placeholder stays small.
		expect(JSON.stringify(args).length).toBeLessThan(2000);
	});

	it("tryRecoverWrappedArgs rescues write_file from JSON-malformed args by regex-extracting path + content", async () => {
		// Live-bug case (2026-05-25): Kimi K2.6 emitted write_file with a
		// `content` field containing unescaped quotes/newlines, breaking
		// strict JSON parse → {_raw} → wrapped-args failsafe → model
		// gives up. The recovery pass should extract path + content from
		// the raw payload and proceed AS IF the call had been clean.
		// `import { Agent } from ...` already pulls in the recovery, but
		// the function is exported so we can test it in isolation too.
		const { tryRecoverWrappedArgs } = await import("../src/agent");
		const writeFileSchema = {
			type: "object",
			properties: {
				path: { type: "string" },
				content: { type: "string" },
			},
			required: ["path", "content"],
		};
		// Raw payload with unescaped quote inside the content string —
		// strict JSON.parse would reject this, but the greedy regex pulls
		// it through cleanly.
		const wrapped = {
			_raw: '{"path": "src/App.tsx", "content": "console.log(\\"hi\\")"}',
		};
		const recovered = tryRecoverWrappedArgs(wrapped, writeFileSchema);
		expect(recovered).toBeDefined();
		expect(recovered?.path).toBe("src/App.tsx");
		expect(recovered?.content).toBe('console.log("hi")');
	});

	it("tryRecoverWrappedArgs returns undefined when no required field can be found", async () => {
		const { tryRecoverWrappedArgs } = await import("../src/agent");
		const schema = {
			type: "object",
			properties: { path: { type: "string" }, content: { type: "string" } },
			required: ["path", "content"],
		};
		// Raw payload doesn't contain either required field name.
		const wrapped = { _raw: '{"foo": "bar"}' };
		expect(tryRecoverWrappedArgs(wrapped, schema)).toBeUndefined();
	});

	it("end-to-end: wrapped-args on write_file is RECOVERED automatically; placeholder NEVER fires when path + content are extractable", async () => {
		// The live-bug fix in action — the model emits malformed args, the
		// recovery kicks in BEFORE the failsafe, the tool handler sees
		// clean args. No "_oatiMalformed" placeholder in history.
		const writer: ToolSpec = {
			name: "write_file",
			description: "write file",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
				required: ["path", "content"],
			},
			approval: "auto",
			async handler(args) {
				return { wrote: args };
			},
		};
		// Stress: 12 layers of stringify on a payload where the innermost
		// content has unescaped quotes that would normally torpedo the
		// recovery. Recovery's greedy fallback handles it.
		const inner = '{"path":"App.tsx","content":"console.log(\\"hi\\")\\n"}';
		let nested: unknown = inner;
		for (let i = 0; i < 11; i++) nested = JSON.stringify(nested);
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "write_file", args: nested },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "recover", provider, tools: [writer], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "write the file" });
		const history = agent.getHistory();
		const toolCallPart = history.flatMap((m) => m.parts).find((p) => p.kind === "tool_call");
		const args = (toolCallPart as { args: unknown }).args as Record<string, unknown>;
		// Crucially: NOT the malformed placeholder. The recovery succeeded.
		expect(args._oatiMalformed).toBeUndefined();
		expect(args.path).toBe("App.tsx");
		expect(typeof args.content).toBe("string");
		expect(String(args.content)).toContain("console.log");
	});

	it("when recovery genuinely can't salvage args, the placeholder hint names the tool, schema, and exec-specific cause", async () => {
		// 2026-05-25 live-bug regression: when smart-recovery fails (payload
		// is too mangled to extract required fields from), the fallback
		// placeholder hint must still be actionable — name the tool, show
		// the schema, name the most likely cause + recovery path.
		// Force the fallback by feeding an unparseable garbage string that
		// doesn't contain the schema's required field names.
		// Starts with `{` so isStillWrappedAfterNormalize fires; unparseable
		// inside so smart-recovery falls through to the placeholder.
		const garbage = "{garbled payload with no command field anywhere here};";
		const execTool: ToolSpec = {
			name: "exec",
			description: "execute a shell command",
			schema: {
				type: "object",
				properties: { command: { type: "string" }, cwd: { type: "string" } },
				required: ["command"],
			},
			approval: "auto",
			async handler() {
				return { stdout: "", stderr: "", exitCode: 0 };
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "exec", args: garbage },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "exec-hint", provider, tools: [execTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "run pwsh" });
		const history = agent.getHistory();
		const toolCallPart = history.flatMap((m) => m.parts).find((p) => p.kind === "tool_call");
		const args = (toolCallPart as { args: unknown }).args as Record<string, unknown>;
		expect(args._oatiMalformed).toBe(true);
		const hint = String(args._hint);
		// The hint must name the tool by name + show its schema fields
		// so the model can pattern-match on what shape to re-emit.
		expect(hint).toMatch(/`exec`/);
		expect(hint).toMatch(/command/); // schema field name
		// And specifically warn about the heredoc / multi-line cause.
		expect(hint).toMatch(/multi-line/i);
		expect(hint).toMatch(/write_file/); // the recovery suggestion
	});

	it("leaves CLEAN args untouched in history (no false positives)", async () => {
		const okArgs = { path: "scripts.js", content: "console.log('ok');" };
		const ok: ToolSpec = {
			name: "writer",
			description: "writer",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return "ok";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "writer", args: okArgs },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "san2", provider, tools: [ok], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "go" });

		const history = agent.getHistory();
		const toolCallPart = history.flatMap((m) => m.parts).find((p) => p.kind === "tool_call");
		const args = (toolCallPart as { args: unknown }).args as Record<string, unknown>;
		// Sanitization did NOT fire — clean args preserved verbatim.
		expect(args._oatiMalformed).toBeUndefined();
		expect(args.path).toBe("scripts.js");
		expect(args.content).toBe("console.log('ok');");
	});
});

describe("extractFileCreationClaims", () => {
	it("pulls the path out of a typical '✅ Done — Created' line", () => {
		expect(
			extractFileCreationClaims("✅ Done — Created RAG_Architecture.pptx in the current workspace."),
		).toEqual(["RAG_Architecture.pptx"]);
	});

	it("matches multiple completion verbs (wrote / generated / saved)", () => {
		expect(extractFileCreationClaims("Wrote out/deck.pptx")).toEqual(["out/deck.pptx"]);
		expect(extractFileCreationClaims("Generated `report.pdf` for you.")).toEqual(["report.pdf"]);
		expect(extractFileCreationClaims("Saved to ./out/data.csv successfully.")).toEqual([
			"./out/data.csv",
		]);
	});

	it("handles backtick-wrapped paths and trailing punctuation", () => {
		expect(extractFileCreationClaims("Created `Q4_report.pdf`!")).toEqual(["Q4_report.pdf"]);
		expect(extractFileCreationClaims("Generated chart.png.")).toEqual(["chart.png"]);
	});

	it("only matches artifact extensions (skips conversational use of verbs)", () => {
		// "Created a function" — no file extension, must not match.
		expect(extractFileCreationClaims("I created a function to handle this.")).toEqual([]);
		// "Generated some ideas" — same.
		expect(extractFileCreationClaims("Generated some ideas about how to approach it.")).toEqual([]);
	});

	it("returns an empty list for empty / whitespace input", () => {
		expect(extractFileCreationClaims("")).toEqual([]);
		expect(extractFileCreationClaims("   ")).toEqual([]);
	});

	it("deduplicates when the same path appears more than once", () => {
		expect(
			extractFileCreationClaims(
				"Created deck.pptx. Saved to deck.pptx. Generated deck.pptx for review.",
			),
		).toEqual(["deck.pptx"]);
	});
});

describe("augmentGuardrailError", () => {
	it("rewrites an OpenRouter guardrail-blocked error into an actionable diagnostic", async () => {
		const { augmentGuardrailError } = await import("../src/agent");
		const raw =
			'OpenAI Compatible HTTP 403 Forbidden: {"error":{"code":"guardrail_blocked",' +
			'"message":"Prompt blocked by guardrails: prompt_injection.mode_switch",' +
			'"plugin":"guardrail_patterns","findings":[{"plugin":"guardrail_patterns",' +
			'"kind":"prompt_injection.mode_switch","severity":"high",' +
			'"message":"prompt_injection.mode_switch pattern matched in messages[61]"}]}}';
		const out = augmentGuardrailError(raw);
		expect(out).toBeDefined();
		expect(out).toMatch(/Provider guardrail blocked/);
		expect(out).toMatch(/prompt_injection\.mode_switch/);
		expect(out).toMatch(/message #61/); // the offending index extracted
		expect(out).toMatch(/`\/compact`/); // recovery option #1
		expect(out).toMatch(/OpenRouter.*Plugins/); // disable-at-provider option
	});

	it("returns undefined for non-guardrail errors (caller keeps the original message)", async () => {
		const { augmentGuardrailError } = await import("../src/agent");
		expect(augmentGuardrailError("HTTP 500 Internal Server Error")).toBeUndefined();
		expect(augmentGuardrailError("connection refused")).toBeUndefined();
		expect(augmentGuardrailError("")).toBeUndefined();
	});

	it("matches the `prompt_injection` prefix even without `guardrail_blocked`", async () => {
		// Some providers emit just the classifier name without the wrapper code.
		const { augmentGuardrailError } = await import("../src/agent");
		const out = augmentGuardrailError("classifier: prompt_injection.system_override fired");
		expect(out).toBeDefined();
		expect(out).toMatch(/prompt_injection/);
	});
});

describe("Agent — vision-capability pre-flight", () => {
	it("blocks image-bearing user messages with a clear actionable error when the model is text-only", async () => {
		// Live-bug 2026-05-26: user attached an image and asked the model a
		// question. Pre-fix the request went out, the model had no idea
		// what to do with the image_url block, and returned silent /
		// empty. Pre-flight check should fire BEFORE the request hits the
		// provider.
		//
		// 2026-05-30 update: was using moonshotai/kimi-k2 as the
		// text-only example, but K2.6 is now correctly flagged as vision-
		// capable. Switched to ollama/llama3 which stays text-only.
		const provider = makeProvider([
			// Should never be called — pre-flight bails out before streamOnce.
			[
				{ type: "text_delta", text: "this should never appear" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "vision", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "ollama/llama3" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({
			userMessage: "Did you receive this image?",
			userParts: [
				{
					kind: "image",
					mimeType: "image/png",
					dataUrl: "data:image/png;base64,AAAAAA",
				},
			],
		});
		const joined = texts.join("");
		expect(joined).toMatch(/doesn't accept image inputs/);
		expect(joined).toMatch(/Claude/);
		expect(joined).toMatch(/GPT-4o/);
		expect(joined).not.toMatch(/this should never appear/);
	});

	it("does NOT block when the model IS vision-capable (Claude/GPT/Gemini)", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "I see the image — it's a screenshot." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "vision-ok", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "claude-sonnet-4-6" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({
			userMessage: "What's in this image?",
			userParts: [
				{
					kind: "image",
					mimeType: "image/png",
					dataUrl: "data:image/png;base64,AAAAAA",
				},
			],
		});
		expect(texts.join("")).toMatch(/screenshot/);
		expect(texts.join("")).not.toMatch(/doesn't accept image inputs/);
	});

	it("does NOT block text-only messages on text-only models (no false positives)", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "Hello!" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "vision-text", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "hi" });
		expect(texts.join("")).toBe("Hello!");
	});
});

describe("Agent — guardrail-aware error handling", () => {
	it("does NOT synthesize honest-Done after a stream-level error following a successful tool call", async () => {
		// Live scenario: a few tool calls succeed, then the next provider
		// request gets 403/guardrail-blocked. Previously the agent ended
		// the turn with "✅ Done — tool calls above completed" which read
		// as "the guardrail block was actually fine, work is complete".
		// Now we skip the honest-Done synthesis when the last iteration
		// errored — the user just sees the real error bubble.
		const echoTool: ToolSpec = {
			name: "echo",
			description: "echo",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler(args) {
				return { received: args };
			},
		};
		const provider = makeProvider([
			// Iter 1: tool call succeeds.
			[
				{ type: "tool_call", id: "tc1", name: "echo", args: { x: 1 } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			// Iter 2: provider errors (guardrail) — no text, no tools.
			[
				{
					type: "error",
					message: 'HTTP 403: {"error":{"code":"guardrail_blocked","message":"Prompt blocked"}}',
				},
				{ type: "message_end", stopReason: "error" },
			],
		]);
		const agent = new Agent(
			{ id: "guardrail", provider, tools: [echoTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "go" });
		const joined = texts.join("");
		// No fake Done after the error.
		expect(joined).not.toMatch(/^✅ Done/);
		expect(joined).not.toMatch(/the tool calls above completed/);
	});
});

describe("Agent — auto-compact safety net (long-context recovery)", () => {
	it("auto-compacts a bulky session BEFORE sending (2026-06-01: was post-empty-only)", async () => {
		// Updated 2026-06-01: was post-empty-response-only. Live-bug
		// showed that for sessions where the model happily returns tool
		// calls (no empty response), history grew unbounded until the
		// provider rejected. The agent now runs `shouldAutoCompact`
		// before EVERY stream call, so a bulky history gets summarized
		// the first time it's sent — the model never sees the wall.
		const longText = "x".repeat(50_000);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		for (let i = 0; i < 30; i++) {
			initialHistory.push({ role: "user", parts: [{ kind: "text", text: `prompt ${i}` }] });
			initialHistory.push({
				role: "assistant",
				parts: [{ kind: "text", text: `${longText} block ${i}` }],
			});
		}
		const provider = makeProvider([
			// Iter 1 — the pre-stream summarize call. compactHistoryMiddle
			// uses the same provider, so this slot delivers the summary.
			[
				{ type: "text_delta", text: "Summary: lots of bulky messages." },
				{ type: "message_end", stopReason: "end" },
			],
			// Iter 2 — the actual user turn, now with a compacted history
			// the model can comfortably handle.
			[
				{ type: "text_delta", text: "Here is the real answer." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "auto-compact", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
			initialHistory,
		);
		const errorEvents: string[] = [];
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") errorEvents.push(ev.message);
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "write the summary" });
		const autoCompactMsg = errorEvents.find((m) => m.startsWith("[auto-compact]"));
		expect(autoCompactMsg).toBeDefined();
		const finalHistory = agent.getHistory();
		expect(finalHistory.length).toBeLessThan(initialHistory.length / 2);
		const sysMarker = finalHistory.find(
			(m) =>
				m.role === "system" &&
				m.parts.some((p) => p.kind === "text" && p.text.includes("Auto-compacted")),
		);
		expect(sysMarker).toBeDefined();
		expect(texts.join("")).toContain("Here is the real answer.");
	});

	it("does NOT auto-compact on a short session (no false positive)", async () => {
		// Empty response on turn 1 of a fresh session should fall through
		// to the no-output diagnostic, NOT trigger compact (history is
		// trivially small; compacting it would do nothing useful).
		const provider = makeProvider([[{ type: "message_end", stopReason: "end" }]]);
		const agent = new Agent(
			{ id: "short", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		const errorEvents: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") errorEvents.push(ev.message);
		});
		await agent.run({ userMessage: "hi" });
		// No auto-compact diagnostic.
		expect(errorEvents.find((m) => m.startsWith("[auto-compact]"))).toBeUndefined();
		// But the normal no-output diagnostic should have fired.
		expect(errorEvents.find((m) => m.includes("returned no output"))).toBeDefined();
	});
});

describe("Agent — false-Done verification", () => {
	it("appends a warning when the model claims to have created a file that does NOT exist", async () => {
		// Model emits a confident "Done — Created X" line but never fires
		// any tools. The end-of-turn check must surface a warning rather
		// than letting the lie stand.
		const provider = makeProvider([
			[
				{
					type: "text_delta",
					text: "✅ Done — Created RAG_Architecture.pptx in the current workspace.",
				},
				{ type: "message_end", stopReason: "end" },
			],
			// The auto-continue safety net may fire (the text doesn't end
			// mid-thought though, so it shouldn't). Provide a second response
			// just in case.
			[{ type: "message_end", stopReason: "end" }],
		]);
		const host = makeHost({
			fileExists: vi.fn().mockResolvedValue(false),
		});
		const agent = new Agent(
			{ id: "false-done", provider, tools: [], host, mode: baseMode },
			{ modelId: "test-model" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "make a deck" });
		const joined = texts.join("");
		expect(joined).toMatch(/False-Done check/);
		expect(joined).toMatch(/RAG_Architecture\.pptx/);
	});

	it("does NOT append a warning when the claimed file actually exists", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "✅ Done — Created out/deck.pptx." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const host = makeHost({
			fileExists: vi.fn().mockResolvedValue(true),
		});
		const agent = new Agent(
			{ id: "true-done", provider, tools: [], host, mode: baseMode },
			{ modelId: "test-model" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "make a deck" });
		expect(texts.join("")).not.toMatch(/False-Done check/);
	});

	it("fires the warning when tools DID run earlier but the Done claim is alongside the final tool call (live-bug regression)", async () => {
		// Real session pattern: iter 1 emits a few exec calls + a "Done — Created X" sentence
		// in the SAME assistant message. Iter 2 returns empty. The previous version of the
		// check looked at `lastAssistantText` from iter 2 (= "") and missed the claim. Now
		// we walk back through history to find the actual "Done" prose.
		const execTool: ToolSpec = {
			name: "exec",
			description: "execute a shell command",
			schema: { type: "object", properties: { command: { type: "string" } } },
			approval: "auto",
			async handler() {
				// Simulate the script "running" but producing no file (e.g. a runtime error).
				return { stdout: "Created E:\\OATICode\\Docs\\RAG_Architecture.pptx", stderr: "", exitCode: 0 };
			},
		};
		const provider = makeProvider([
			// Iter 1: model fires exec + emits Done text in the same iteration.
			[
				{ type: "text_delta", text: "Writing the script and running it now." },
				{ type: "tool_call", id: "tc1", name: "exec", args: { command: "python create_rag.py" } },
				{ type: "text_delta", text: " ✅ Done — Created RAG_Architecture.pptx in E:\\OATICode\\Docs." },
				{ type: "message_end", stopReason: "tool_use" },
			],
			// Iter 2: nothing left to do — empty response triggers the no-tool-calls branch.
			[{ type: "message_end", stopReason: "end" }],
		]);
		const host = makeHost({
			fileExists: vi.fn().mockResolvedValue(false), // file genuinely missing
		});
		const agent = new Agent(
			{ id: "false-done-with-tools", provider, tools: [execTool], host, mode: baseMode },
			{ modelId: "test-model" },
		);
		const texts: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") texts.push(ev.text);
		});
		await agent.run({ userMessage: "make the deck" });
		const joined = texts.join("");
		expect(joined).toMatch(/False-Done check/);
		expect(joined).toMatch(/RAG_Architecture\.pptx/);
		// And the actionable causes list MUST be in the warning so the model knows
		// what to investigate (script errored / wasn't run / path mismatch / fabricated).
		expect(joined).toMatch(/Python script errored/);
	});
});

describe("Agent — fix-intent-without-mutation auto-continue (2026-05-30)", () => {
	// Captures the live-trace failure where the user said "fix the css" and
	// the model did 8 read_files + 1 screenshot + 0 writes + claimed Done.
	// The detector injects a follow-up user nudge so the model gets another
	// shot at applying the actual fix.

	it("nudges when the user asks for a fix but the turn applies zero mutations", async () => {
		const readOnlyTool: ToolSpec = {
			name: "read_file",
			description: "read",
			schema: { type: "object", properties: { path: { type: "string" } } },
			approval: "auto",
			async handler() {
				return "file contents...";
			},
		};
		const provider = makeProvider([
			// Iter 1: model reads a file then claims Done with text.
			[
				{
					type: "tool_call",
					id: "tc1",
					name: "read_file",
					args: { path: "index.html" },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			// After read_file's result comes back, model returns text and stops.
			[
				{ type: "text_delta", text: "✅ Done — the file looks fine, no changes needed." },
				{ type: "message_end", stopReason: "end" },
			],
			// The auto-continue should inject a nudge; iter 3 is the model's
			// response to it. Provide an empty end so the loop terminates.
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "fix-intent", provider, tools: [readOnlyTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "fix the css issue on this page" });
		const history = agent.getHistory();
		// The nudge is pushed as a user message; find it.
		const userMsgs = history
			.filter((m) => m.role === "user")
			.flatMap((m) => m.parts.filter((p) => p.kind === "text"))
			.map((p) => (p as { text: string }).text);
		const nudge = userMsgs.find((t) => t.includes("didn't write or edit any file"));
		expect(nudge).toBeDefined();
		expect(nudge).toMatch(/Apply the fix NOW/i);
	});

	it("does NOT nudge when the turn actually performed a mutation", async () => {
		const writer: ToolSpec = {
			name: "write_file",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler() {
				return "wrote file";
			},
		};
		const provider = makeProvider([
			[
				{
					type: "tool_call",
					id: "tc1",
					name: "write_file",
					args: { path: "styles.css", content: "/* fixed */" },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "✅ Done — wrote the fix." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "fix-w-mutation", provider, tools: [writer], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "fix the css issue" });
		const userMsgs = agent
			.getHistory()
			.filter((m) => m.role === "user")
			.flatMap((m) => m.parts.filter((p) => p.kind === "text"))
			.map((p) => (p as { text: string }).text);
		const nudge = userMsgs.find((t) => t.includes("didn't write or edit any file"));
		expect(nudge).toBeUndefined();
	});

	it("when prompt names a specific file, the nudge calls it out by name", async () => {
		// 2026-05-30 follow-up: the EXACT live-trace failure where the user
		// said "fix index.html — path: E:/.../index.html" and the agent
		// wrote serve.py instead. Strict prompt-path relevance means the
		// detector fires, and the new buildFixIntentNudge surfaces the
		// specific path in the message so the model can't miss it.
		const writer: ToolSpec = {
			name: "write_file",
			description: "writer",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler() {
				return "wrote file";
			},
		};
		const provider = makeProvider([
			[
				{
					type: "tool_call",
					id: "tc1",
					name: "write_file",
					args: { path: "serve.py", content: "..." },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "✅ Done — set up the server." },
				{ type: "message_end", stopReason: "end" },
			],
			[{ type: "message_end", stopReason: "end" }],
		]);
		const agent = new Agent(
			{ id: "named-path", provider, tools: [writer], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "fix the css issue in index.html" });
		const userMsgs = agent
			.getHistory()
			.filter((m) => m.role === "user")
			.flatMap((m) => m.parts.filter((p) => p.kind === "text"))
			.map((p) => (p as { text: string }).text);
		const nudge = userMsgs.find((t) => t.includes("did NOT write or edit"));
		expect(nudge).toBeDefined();
		// The named file must appear in the nudge (backticked basename).
		expect(nudge).toContain("`index.html`");
		// And the "helper file" callout that shamed serve.py-style wandering.
		expect(nudge).toMatch(/helper\/scaffolding files/);
	});

	it("does NOT nudge when the user prompt has no fix intent", async () => {
		const readOnlyTool: ToolSpec = {
			name: "read_file",
			description: "read",
			schema: { type: "object", properties: { path: { type: "string" } } },
			approval: "auto",
			async handler() {
				return "file contents";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "read_file", args: { path: "x" } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "Here's what the file does: ..." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "non-fix", provider, tools: [readOnlyTool], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		await agent.run({ userMessage: "explain how this code works" });
		const userMsgs = agent
			.getHistory()
			.filter((m) => m.role === "user")
			.flatMap((m) => m.parts.filter((p) => p.kind === "text"))
			.map((p) => (p as { text: string }).text);
		const nudge = userMsgs.find((t) => t.includes("didn't write or edit any file"));
		expect(nudge).toBeUndefined();
	});
});

describe("Agent — requiresTemperature override (2026-06-01)", () => {
	it("overrides mode.temperature with the model's hard requiresTemperature", async () => {
		// Live-bug 2026-06-01: Kimi K2.6 thinking variants reject any
		// temperature other than 1. Mode config had 0.2 (good for code).
		// Without this override the upstream rejected every turn with
		// `invalid temperature: only 1 is allowed for this model`.
		let observedTemperature: number | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req: ProviderRequest) {
				observedTemperature = req.temperature;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const modeWithLowTemp = { ...baseMode, temperature: 0.2 };
		const agent = new Agent(
			{ id: "kimi", provider, tools: [], host: makeHost(), mode: modeWithLowTemp },
			{ modelId: "moonshotai/kimi-k2.6" },
		);
		await agent.run({ userMessage: "hi" });
		// Mode said 0.2 but Kimi K2.6's requiresTemperature=1 wins.
		expect(observedTemperature).toBe(1);
	});

	it("uses mode.temperature when the model has NO hard requirement", async () => {
		let observedTemperature: number | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req: ProviderRequest) {
				observedTemperature = req.temperature;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const modeWithLowTemp = { ...baseMode, temperature: 0.2 };
		const agent = new Agent(
			{ id: "claude", provider, tools: [], host: makeHost(), mode: modeWithLowTemp },
			{ modelId: "claude-sonnet-4-6" },
		);
		await agent.run({ userMessage: "hi" });
		// Claude Sonnet has no requiresTemperature, so the mode's 0.2 stands.
		expect(observedTemperature).toBe(0.2);
	});
});

describe("Agent — thinking-mode reasoning round-trip (2026-06-01)", () => {
	// Live-bug: Moonshot K2.6 thinking mode is stateful. After turn N emits
	// reasoning_content + a tool_call, turn N+1's history MUST replay that
	// reasoning_content back, or the API refuses with `thinking is enabled
	// but reasoning_content is missing in assistant tool call message at
	// index N [stream_failed]`. The agent records reasoning_delta events
	// as ReasoningPart on the assistant message so the provider can re-emit
	// `reasoning_content` on the wire.
	it("records reasoning_delta events as a ReasoningPart on the assistant message", async () => {
		const provider = makeProvider([
			[
				{ type: "reasoning_delta", text: "Hmm, " },
				{ type: "reasoning_delta", text: "let me think." },
				{ type: "text_delta", text: "42" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "kimi", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
		);
		await agent.run({ userMessage: "what is 6×7?" });
		const history = agent.getHistory();
		const assistant = history[history.length - 1];
		expect(assistant.role).toBe("assistant");
		const reasoningParts = assistant.parts.filter((p) => p.kind === "reasoning");
		expect(reasoningParts).toHaveLength(1);
		expect((reasoningParts[0] as { text: string }).text).toBe("Hmm, let me think.");
		// Regular text content is still recorded on its own part.
		const textParts = assistant.parts.filter((p) => p.kind === "text");
		expect(textParts.map((p) => (p as { text: string }).text).join("")).toBe("42");
	});

	it("surfaces reasoning to the UI as 💭-prefixed text_delta events (preserves the thinking-marker UX)", async () => {
		const provider = makeProvider([
			[
				{ type: "reasoning_delta", text: "thinking..." },
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "kimi", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
		);
		const textDeltas: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") textDeltas.push(ev.text);
		});
		await agent.run({ userMessage: "go" });
		// The 💭 marker fires exactly once at the start of reasoning, then
		// the reasoning chunks stream out as ordinary text_delta so the
		// existing chat-bubble renderer needs no changes.
		const joined = textDeltas.join("");
		expect(joined).toContain("💭 thinking...");
		expect(joined).toContain("done");
		// Marker appears only once even if many reasoning chunks arrive.
		expect(joined.match(/💭/g)?.length ?? 0).toBe(1);
	});

	it("emits no 💭 marker when the turn has no reasoning_delta events", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "plain answer" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "plain", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "claude-sonnet-4-6" },
		);
		const textDeltas: string[] = [];
		agent.on((ev) => {
			if (ev.type === "text_delta") textDeltas.push(ev.text);
		});
		await agent.run({ userMessage: "go" });
		expect(textDeltas.join("")).toBe("plain answer");
	});

	it("preserves the reasoning round-trip across a tool-call iteration (Moonshot's hard requirement)", async () => {
		const echoTool: ToolSpec = {
			name: "echo",
			description: "echoes",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler(args) {
				return { ok: true, args };
			},
		};
		const provider = makeProvider([
			[
				{ type: "reasoning_delta", text: "Let me pick a tool." },
				{ type: "tool_call", id: "call_1", name: "echo", args: { x: 1 } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "all done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "kimi", provider, tools: [echoTool], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		// First assistant turn carries BOTH the reasoning AND the tool_call —
		// this is exactly the shape Moonshot needs replayed on turn 2.
		const firstAssistant = history.find((m) => m.role === "assistant");
		expect(firstAssistant).toBeDefined();
		const hasReasoning = firstAssistant?.parts.some((p) => p.kind === "reasoning") ?? false;
		const hasToolCall = firstAssistant?.parts.some((p) => p.kind === "tool_call") ?? false;
		expect(hasReasoning).toBe(true);
		expect(hasToolCall).toBe(true);
	});
});

describe("repairOrphanToolCalls Pass-2 cleanup (2026-06-03 bug-fix)", () => {
	// Live-bug: a corrupted-on-disk session had a loose tool message
	// (not following any assistant) with an empty-id tool_result. Pass-0
	// only walks tool messages that immediately follow an assistant, so
	// this entry survived every repair cycle. The wire filter kept
	// dropping it on every turn — producing a noisy `[wire-filter]
	// dropped 1 empty-id tool_result` diagnostic that never went away.
	// Pass-2 walks the repaired output and strips empty-id tool_results
	// from EVERY tool message regardless of position.

	it("strips empty-id tool_results from tool messages that don't follow an assistant", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		const corrupted: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			// Orphan tool message — no preceding assistant. Pass-0 won't touch it.
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "", output: "orphan", isError: false }],
			},
			{ role: "user", parts: [{ kind: "text", text: "next" }] },
		];
		const { repaired } = repairOrphanToolCalls(corrupted);
		// Tool message should be GONE — all parts were empty-id tool_result,
		// so the message became empty and dropped entirely.
		const toolMsgs = repaired.filter((m) => m.role === "tool");
		expect(toolMsgs).toHaveLength(0);
	});

	it("preserves valid tool_results in the same tool message, drops only the empty-id ones", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		const mixed: import("@oati/shared").ConversationMessage[] = [
			{
				role: "tool",
				parts: [
					{ kind: "tool_result", id: "", output: "empty", isError: false },
					{ kind: "tool_result", id: "real_id", output: "kept", isError: false },
				],
			},
		];
		const { repaired } = repairOrphanToolCalls(mixed);
		expect(repaired).toHaveLength(1);
		const tool = repaired[0];
		expect(tool.parts).toHaveLength(1);
		expect((tool.parts[0] as { id: string }).id).toBe("real_id");
	});

	it("leaves clean histories unchanged (no false positives)", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		const clean: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c1", name: "echo", args: {} }],
			},
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "c1", output: "ok", isError: false }],
			},
			{ role: "user", parts: [{ kind: "text", text: "next" }] },
		];
		const { repaired, orphans } = repairOrphanToolCalls(clean);
		expect(orphans).toEqual([]);
		expect(repaired).toHaveLength(4);
	});
});

describe("Agent — synth never produces colon-prefixed ids (2026-06-03 bug-fix)", () => {
	// Live-bug: a model emitted a tool-call marker with BOTH empty id AND
	// empty function name. The prior synth produced `":0"` (colon
	// prefix) because `${ev.name}:${idx}` collapsed to `:0` when name
	// was empty. Non-empty per length check, so the wire filter
	// preserved it — but the upstream's pair matcher couldn't find it
	// and rejected with `tool_call_id  is not found`.
	it("synthesizes 'unknown:N' (not ':N') when both id and name are empty", async () => {
		const provider = makeProvider([
			[
				// Provider event with both empty id AND empty name — the
				// "(unknown tool)" case the user reported.
				{ type: "tool_call", id: "", name: "", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{
				id: "synth-noname",
				provider,
				tools: [],
				host: makeHost(),
				mode: baseMode,
			},
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const assistant = history.find(
			(m) => m.role === "assistant" && m.parts.some((p) => p.kind === "tool_call"),
		);
		const call = assistant?.parts.find((p) => p.kind === "tool_call") as { id: string };
		// The synthesized id must NOT start with a colon — that's the
		// shape that slipped past the wire filter and confused the upstream.
		expect(call.id.startsWith(":")).toBe(false);
		// It must start with the placeholder name 'unknown' (since name was empty).
		expect(call.id.startsWith("unknown")).toBe(true);
		// The matching tool_result has the same id, so the pair is intact.
		const toolMsg = history.find((m) => m.role === "tool");
		const result = toolMsg?.parts.find((p) => p.kind === "tool_result") as { id: string };
		expect(result.id).toBe(call.id);
	});
});

describe("Agent — Pass-0 rename persists even with no orphans (2026-06-03 bug-fix)", () => {
	// Live-bug repro: a reloaded session whose persisted history contained
	// PAIRED empty-id entries (assistant tool_call id="" + matching tool
	// tool_result id="") was being rejected by the upstream with
	// `tool_call_id  is not found`. The earlier repair logic correctly
	// renamed the pair via Pass-0 but only PERSISTED the result when
	// orphans were also found — so balanced empty-id pairs leaked the
	// bare empty ids straight through to the wire serializer, which
	// dropped them and produced an imbalanced wire body.

	it("rewrites paired empty-id entries in this.history even when orphans is empty", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		// Pre-load history that mirrors a reloaded-from-disk session: a
		// paired empty-id assistant tool_call + matching tool tool_result.
		// Both sides are empty-id; no orphans exist; previously the rename
		// got thrown away. The new code MUST persist the rename.
		const corruptedHistory: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "do the thing" }] },
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "", name: "browser_screenshot", args: {} }],
			},
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "", output: "stub", isError: false }],
			},
			{ role: "user", parts: [{ kind: "text", text: "next" }] },
		];
		const agent = new Agent(
			{
				id: "rename-persist",
				provider,
				tools: [],
				host: makeHost(),
				mode: baseMode,
			},
			{ modelId: "some-unknown-model" },
			corruptedHistory,
		);
		const diagnostics: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") diagnostics.push(ev.message);
		});
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		// The empty-id assistant tool_call must have been renamed to a
		// non-empty synthesized id.
		const asstWithCall = history.find(
			(m) => m.role === "assistant" && m.parts.some((p) => p.kind === "tool_call"),
		);
		const call = asstWithCall?.parts.find((p) => p.kind === "tool_call") as { id: string };
		expect(call.id.length).toBeGreaterThan(0);
		// The matching tool_result must have been renamed to the SAME id
		// (so the wire request can pair them).
		const toolMsg = history.find((m) => m.role === "tool");
		const result = toolMsg?.parts.find((p) => p.kind === "tool_result") as { id: string };
		expect(result.id).toBe(call.id);
		// A diagnostic must have fired so the user sees what happened —
		// no silent rename.
		expect(diagnostics.some((m) => m.startsWith("[history-repair]"))).toBe(true);
	});

	it("does NOT emit a diagnostic when history was already clean (no false positives)", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const cleanHistory: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "real_id_1", name: "echo", args: {} }],
			},
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "real_id_1", output: "ok", isError: false }],
			},
		];
		const agent = new Agent(
			{
				id: "clean",
				provider,
				tools: [],
				host: makeHost(),
				mode: baseMode,
			},
			{ modelId: "some-unknown-model" },
			cleanHistory,
		);
		const diagnostics: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") diagnostics.push(ev.message);
		});
		await agent.run({ userMessage: "next" });
		// No history-repair diagnostic when nothing was wrong.
		expect(diagnostics.find((m) => m.startsWith("[history-repair]"))).toBeUndefined();
	});
});

describe("Agent — empty tool_call_id resilience (2026-06-01 live-bug)", () => {
	it("synthesizes a fallback id when the provider emits an empty tool_call id", async () => {
		const echoTool: ToolSpec = {
			name: "echo",
			description: "echoes",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return "ok";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "", name: "echo", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "empty-id", provider, tools: [echoTool], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const assistant = history.find(
			(m) => m.role === "assistant" && m.parts.some((p) => p.kind === "tool_call"),
		);
		expect(assistant).toBeDefined();
		const toolCall = assistant?.parts.find((p) => p.kind === "tool_call");
		const synthesizedId = (toolCall as { id: string }).id;
		expect(synthesizedId.length).toBeGreaterThan(0);
		const toolMsg = history.find((m) => m.role === "tool");
		expect(toolMsg).toBeDefined();
		const toolResult = toolMsg?.parts.find((p) => p.kind === "tool_result");
		expect((toolResult as { id: string }).id).toBe(synthesizedId);
	});

	it("repairOrphanToolCalls renames empty-id pairs to synthesized ids (heals on-disk corruption)", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		// Shape that lands in history after a pre-fix session was saved:
		// assistant + tool both carry empty ids, paired by ORDER.
		const corrupted: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "", name: "set_workspace_root", args: { path: "/x" } }],
			},
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "", output: "ok", isError: false }],
			},
			{ role: "user", parts: [{ kind: "text", text: "again" }] },
		];
		const { repaired, orphans } = repairOrphanToolCalls(corrupted);
		// No orphans because the empty pair gets RENAMED, not detected as orphan.
		expect(orphans).toEqual([]);
		// Both sides now carry the same synthesized id.
		const asst = repaired.find((m) => m.role === "assistant");
		const tool = repaired.find((m) => m.role === "tool");
		const asstCall = asst?.parts.find((p) => p.kind === "tool_call") as { id: string };
		const toolResult = tool?.parts.find((p) => p.kind === "tool_result") as { id: string };
		expect(asstCall.id.length).toBeGreaterThan(0);
		expect(toolResult.id).toBe(asstCall.id);
		// Synthesized id includes the tool name so it's recognizable in logs.
		expect(asstCall.id).toMatch(/set_workspace_root/);
	});

	it("repairOrphanToolCalls renames N empty pairs in order (preserves call-to-result mapping)", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		const corrupted: import("@oati/shared").ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{ kind: "tool_call", id: "", name: "read_file", args: { path: "a" } },
					{ kind: "tool_call", id: "", name: "read_file", args: { path: "b" } },
				],
			},
			{
				role: "tool",
				parts: [
					{ kind: "tool_result", id: "", output: "content of a", isError: false },
					{ kind: "tool_result", id: "", output: "content of b", isError: false },
				],
			},
		];
		const { repaired } = repairOrphanToolCalls(corrupted);
		const asst = repaired.find((m) => m.role === "assistant");
		const tool = repaired.find((m) => m.role === "tool");
		const calls = asst?.parts.filter((p) => p.kind === "tool_call") as Array<{ id: string }>;
		const results = tool?.parts.filter((p) => p.kind === "tool_result") as Array<{
			id: string;
			output: unknown;
		}>;
		// Both calls got distinct ids; the matching results got the same ids
		// in the SAME order (so call-A → result-A, call-B → result-B is preserved).
		expect(calls).toHaveLength(2);
		expect(results).toHaveLength(2);
		expect(calls[0].id).not.toBe(calls[1].id);
		expect(results[0].id).toBe(calls[0].id);
		expect(results[1].id).toBe(calls[1].id);
		// Content stays correctly associated.
		expect(results[0].output).toBe("content of a");
		expect(results[1].output).toBe("content of b");
	});

	it("repairOrphanToolCalls renames empty-id calls AND repairs them when their tool_result is missing", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		const broken: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			{
				role: "assistant",
				parts: [
					{ kind: "tool_call", id: "", name: "broken_call", args: {} },
					{ kind: "tool_call", id: "real_call:1", name: "ok_call", args: {} },
				],
			},
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "real_call:1", output: "ok", isError: false }],
			},
		];
		const { repaired, orphans } = repairOrphanToolCalls(broken);
		// Empty-id call gets renamed to a synthesized id with the tool name
		// in it for traceability. Since its tool_result was missing, the
		// orphan logic correctly detects it and injects a stub.
		expect(orphans).toHaveLength(1);
		expect(orphans[0]).toMatch(/broken_call/);
		// No empty-id parts survive ANYWHERE in the repaired history.
		const allParts = repaired.flatMap((m) => m.parts);
		const anyEmptyIds = allParts.filter(
			(p) =>
				(p.kind === "tool_call" || p.kind === "tool_result") &&
				(typeof (p as { id: unknown }).id !== "string" || (p as { id: string }).id.length === 0),
		);
		expect(anyEmptyIds).toEqual([]);
	});
});

describe("Agent — project memory injection (2026-06-03)", () => {
	// The host exposes a getProjectMemory() hook. When present, the
	// agent fetches it ONCE per session and prepends to the system
	// prompt — equivalent to Claude Code's CLAUDE.md. Wrapped in
	// <project_memory> markers so the model can tell it apart from
	// the repo map block and the static system prompt.

	it("injects project memory into the system prompt when host exposes getProjectMemory", async () => {
		let observed: string | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req) {
				observed = req.systemPrompt;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const host = makeHost({
			getProjectMemory: async () =>
				"# Project conventions\n\n- Use snake_case for filenames\n- Tests live in tests/",
		});
		const agent = new Agent(
			{ id: "mem", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "go" });
		expect(observed).toContain("<project_memory>");
		expect(observed).toContain("Use snake_case for filenames");
		expect(observed).toContain("</project_memory>");
	});

	it("caches project memory across turns — host.getProjectMemory is called exactly once", async () => {
		let callCount = 0;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(_req) {
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const host = makeHost({
			getProjectMemory: async () => {
				callCount++;
				return "# stub";
			},
		});
		const agent = new Agent(
			{ id: "cache", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "first" });
		await agent.run({ userMessage: "second" });
		await agent.run({ userMessage: "third" });
		expect(callCount).toBe(1);
	});

	it("runs without project memory when host doesn't implement getProjectMemory", async () => {
		let observed: string | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req) {
				observed = req.systemPrompt;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const agent = new Agent(
			{ id: "no-mem", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "hi" });
		expect(observed).toBe(baseMode.systemPrompt);
		expect(observed).not.toContain("project_memory");
	});

	it("doesn't crash when getProjectMemory throws (falls back to no memory)", async () => {
		let observed: string | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req) {
				observed = req.systemPrompt;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const host = makeHost({
			getProjectMemory: async () => {
				throw new Error("disk on fire");
			},
		});
		const agent = new Agent(
			{ id: "err", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "hi" });
		expect(observed).toBe(baseMode.systemPrompt);
	});
});

describe("Agent — compact-to-archive (2026-06-03)", () => {
	// When the predictive auto-compact fires, the dropped middle of
	// history must get written to disk via host.appendToSessionArchive
	// so the read_session_archive tool can recover it later.

	it("appends the dropped middle to the session archive when compact fires", async () => {
		const longText = "x".repeat(50_000);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		for (let i = 0; i < 30; i++) {
			initialHistory.push({ role: "user", parts: [{ kind: "text", text: `q ${i}` }] });
			initialHistory.push({
				role: "assistant",
				parts: [{ kind: "text", text: `${longText} ${i}` }],
			});
		}
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "Summary." },
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "answer" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const archiveCalls: { sessionId: string; content: string }[] = [];
		const host = makeHost({
			appendToSessionArchive: async (sessionId: string, content: string) => {
				archiveCalls.push({ sessionId, content });
			},
		});
		const agent = new Agent(
			{ id: "archiver-1", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
			initialHistory,
		);
		await agent.run({ userMessage: "go" });
		expect(archiveCalls.length).toBeGreaterThanOrEqual(1);
		// Archive call uses the agent's session id.
		expect(archiveCalls[0].sessionId).toBe("archiver-1");
		// Content carries the timestamp marker + the dropped transcript.
		expect(archiveCalls[0].content).toContain("Compacted segment");
		expect(archiveCalls[0].content).toContain("Full transcript");
	});

	it("doesn't crash when appendToSessionArchive throws (compact still completes)", async () => {
		const longText = "x".repeat(50_000);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		for (let i = 0; i < 30; i++) {
			initialHistory.push({ role: "user", parts: [{ kind: "text", text: `q ${i}` }] });
			initialHistory.push({
				role: "assistant",
				parts: [{ kind: "text", text: `${longText} ${i}` }],
			});
		}
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "Summary." },
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "answer" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const host = makeHost({
			appendToSessionArchive: async () => {
				throw new Error("disk full");
			},
		});
		const agent = new Agent(
			{ id: "archiver-2", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
			initialHistory,
		);
		// MUST NOT throw despite the archive error.
		await expect(agent.run({ userMessage: "go" })).resolves.toBeUndefined();
		// History was still compacted (length dropped).
		expect(agent.getHistory().length).toBeLessThan(initialHistory.length);
	});
});

describe("Agent — repo map system-prompt injection (Phase 3, 2026-06-01)", () => {
	// Phase 3: the host exposes a getRepoMap() hook. When present, the
	// agent fetches it once per session and appends it to the mode's
	// system prompt for orientation. Cached for the life of the Agent —
	// subsequent turns reuse the cached string without re-walking the
	// workspace.
	it("appends host.getRepoMap() output to the system prompt on the first stream call", async () => {
		let observedSystemPrompt: string | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req) {
				observedSystemPrompt = req.systemPrompt;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const host = makeHost({
			getRepoMap: async () => "## Repo Map\n\n### src/cart.ts\n  class Cart  :1\n",
		});
		const agent = new Agent(
			{ id: "rm", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "hi" });
		expect(observedSystemPrompt).toContain("test"); // baseMode.systemPrompt is "test"
		expect(observedSystemPrompt).toContain("## Repo Map");
		expect(observedSystemPrompt).toContain("src/cart.ts");
	});

	it("caches the repo map — host.getRepoMap is only called once per Agent session", async () => {
		let callCount = 0;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(_req) {
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const host = makeHost({
			getRepoMap: async () => {
				callCount++;
				return "## Repo Map\n\n(stub)\n";
			},
		});
		const agent = new Agent(
			{ id: "cache", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "first" });
		await agent.run({ userMessage: "second" });
		await agent.run({ userMessage: "third" });
		expect(callCount).toBe(1);
	});

	it("runs without a repo map when host doesn't implement getRepoMap (no regressions for older hosts)", async () => {
		let observedSystemPrompt: string | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req) {
				observedSystemPrompt = req.systemPrompt;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		// makeHost() default doesn't set getRepoMap.
		const agent = new Agent(
			{ id: "no-map", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "hi" });
		expect(observedSystemPrompt).toBe(baseMode.systemPrompt);
		expect(observedSystemPrompt).not.toContain("Repo Map");
	});

	it("falls through gracefully when getRepoMap throws", async () => {
		let observedSystemPrompt: string | undefined;
		const provider: ProviderSpec = {
			id: "spy",
			displayName: "spy",
			async *stream(req) {
				observedSystemPrompt = req.systemPrompt;
				yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
				yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
			},
		};
		const host = makeHost({
			getRepoMap: async () => {
				throw new Error("workspace not ready");
			},
		});
		const agent = new Agent(
			{ id: "err", provider, tools: [], host, mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "hi" });
		// System prompt is the mode's base prompt — no append on failure.
		expect(observedSystemPrompt).toBe(baseMode.systemPrompt);
	});
});

describe("estimateContextBreakdown (2026-06-02)", () => {
	it("separates text from descriptions from images from tool results", async () => {
		const { estimateContextBreakdown } = await import("../src/agent");
		const breakdown = estimateContextBreakdown([
			{
				role: "user",
				parts: [{ kind: "text", text: "regular user message that has some content" }],
			},
			{
				role: "user",
				parts: [
					{
						kind: "text",
						text: "[OATI image memory] Earlier screenshot of the cart page showed a 500 error",
					},
				],
			},
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c1", name: "read_file", args: { path: "a.ts" } }],
			},
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "c1", output: "x".repeat(2000), isError: false }],
			},
		]);
		expect(breakdown.text).toBeGreaterThan(0);
		expect(breakdown.descriptions).toBeGreaterThan(0);
		expect(breakdown.toolCalls).toBeGreaterThan(0);
		expect(breakdown.toolResults).toBeGreaterThan(400);
		expect(breakdown.images).toBe(0);
		const sum =
			breakdown.text +
			breakdown.toolResults +
			breakdown.toolCalls +
			breakdown.images +
			breakdown.descriptions;
		expect(breakdown.total).toBe(sum);
	});

	it("classifies '[OATI image memory]' text as descriptions, not regular text", async () => {
		const { estimateContextBreakdown } = await import("../src/agent");
		const breakdown = estimateContextBreakdown([
			{
				role: "user",
				parts: [{ kind: "text", text: `[OATI image memory] ${"x".repeat(1000)}` }],
			},
		]);
		expect(breakdown.descriptions).toBeGreaterThan(0);
		expect(breakdown.text).toBe(0);
	});
});

describe("formatBudgetBreakdown (2026-06-02)", () => {
	it("formats the one-line diagnostic with categories above zero", async () => {
		const { formatBudgetBreakdown } = await import("../src/agent");
		const line = formatBudgetBreakdown(
			{
				total: 145_000,
				text: 80_000,
				toolResults: 25_000,
				toolCalls: 1_000,
				images: 12_000,
				descriptions: 4_000,
			},
			256_000,
		);
		expect(line).toContain("145k/256k");
		expect(line).toContain("text 80k");
		expect(line).toContain("results 25k");
		expect(line).toContain("images 12k");
		expect(line).toContain("descriptions 4k");
		expect(line).toContain("calls 1k");
	});

	it("omits zero-value categories to keep the line readable", async () => {
		const { formatBudgetBreakdown } = await import("../src/agent");
		const line = formatBudgetBreakdown(
			{
				total: 80_000,
				text: 80_000,
				toolResults: 0,
				toolCalls: 0,
				images: 0,
				descriptions: 0,
			},
			256_000,
		);
		expect(line).toContain("text 80k");
		expect(line).not.toContain("results");
		expect(line).not.toContain("images");
		expect(line).not.toContain("descriptions");
		expect(line).not.toContain("calls");
	});
});

describe("extractDescriptionHint (2026-06-02)", () => {
	it("returns the first sentence verbatim when short enough", async () => {
		const { extractDescriptionHint } = await import("../src/agent");
		expect(extractDescriptionHint("[OATI image memory] The cart page with a 500 error.")).toBe(
			"The cart page with a 500 error",
		);
	});

	it("truncates long sentences with an ellipsis", async () => {
		const { extractDescriptionHint } = await import("../src/agent");
		const long = `[OATI image memory] ${"a".repeat(200)} and more`;
		const hint = extractDescriptionHint(long);
		expect(hint).toBeDefined();
		expect(hint?.length).toBeLessThanOrEqual(60);
		expect(hint?.endsWith("...")).toBe(true);
	});

	it("returns undefined for empty descriptions", async () => {
		const { extractDescriptionHint } = await import("../src/agent");
		expect(extractDescriptionHint("[OATI image memory]")).toBeUndefined();
		expect(extractDescriptionHint("[OATI image memory]   ")).toBeUndefined();
	});

	it("handles descriptions without the prefix gracefully", async () => {
		const { extractDescriptionHint } = await import("../src/agent");
		expect(extractDescriptionHint("just a sentence without prefix.")).toBe(
			"just a sentence without prefix",
		);
	});
});

describe("Agent — image-description sliding window (2026-06-02)", () => {
	it("leaves all descriptions intact when count is at or below the window (K=10)", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		for (let i = 0; i < 5; i++) {
			initialHistory.push({
				role: "user",
				parts: [{ kind: "text", text: `[OATI image memory] screenshot ${i} of cart page` }],
			});
			initialHistory.push({ role: "assistant", parts: [{ kind: "text", text: `ack ${i}` }] });
		}
		const agent = new Agent(
			{ id: "small", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
			initialHistory,
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const intactDescs = history.filter(
			(m) =>
				m.role === "user" &&
				m.parts.some(
					(p) =>
						p.kind === "text" &&
						p.text.startsWith("[OATI image memory]") &&
						!p.text.includes("collapsed"),
				),
		);
		expect(intactDescs).toHaveLength(5);
	});

	it("collapses descriptions beyond K=10 to a short marker, keeping the most-recent intact", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		for (let i = 0; i < 15; i++) {
			initialHistory.push({
				role: "user",
				parts: [
					{
						kind: "text",
						text: `[OATI image memory] Screenshot ${i} of the cart page showed item ${i}.`,
					},
				],
			});
			initialHistory.push({ role: "assistant", parts: [{ kind: "text", text: `ack ${i}` }] });
		}
		const agent = new Agent(
			{ id: "many", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
			initialHistory,
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const collapsed = history.filter((m) =>
			m.parts.some((p) => p.kind === "text" && p.text.includes("collapsed")),
		);
		// 15 - 10 = 5 should collapse.
		expect(collapsed).toHaveLength(5);
		const intactDescs = history.filter(
			(m) =>
				m.role === "user" &&
				m.parts.some(
					(p) =>
						p.kind === "text" &&
						p.text.startsWith("[OATI image memory]") &&
						!p.text.includes("collapsed"),
				),
		);
		expect(intactDescs).toHaveLength(10);
	});

	it("preserves a page hint in the collapsed marker when the description has a label", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		for (let i = 0; i < 12; i++) {
			initialHistory.push({
				role: "user",
				parts: [
					{
						kind: "text",
						text: `[OATI image memory] Login page with submit button broken (turn ${i}).`,
					},
				],
			});
			initialHistory.push({ role: "assistant", parts: [{ kind: "text", text: `ack ${i}` }] });
		}
		const agent = new Agent(
			{ id: "hinted", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
			initialHistory,
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		const collapsedMsg = history.find((m) =>
			m.parts.some((p) => p.kind === "text" && p.text.includes("collapsed, was")),
		);
		expect(collapsedMsg).toBeDefined();
		const text = (collapsedMsg?.parts.find((p) => p.kind === "text") as { text: string }).text;
		expect(text).toContain("Login page");
	});
});

describe("Agent — proactive image-budget triage (2026-06-02)", () => {
	// Live-bug: a long-running session with multiple screenshots
	// eventually trips `tool_call_id  is not found` errors because the
	// MOST-RECENT screenshot (which the demote pass deliberately spares)
	// alone pushes the wire request past the model's 256k context cap.
	// History demote runs BETWEEN turns; it can't save us when the
	// current turn's screenshot is itself too big for the remaining
	// budget. Fix: budget-check at injection time and eagerly describe
	// the new image when it wouldn't fit.

	// Build a PNG whose IHDR says it's huge enough to trigger the
	// budget check. The IHDR is the first 24 bytes; the rest can be
	// anything (we just need the dimension probe to return a big number).
	function bigPngDataUrl(width: number, height: number): string {
		const bytes = new Uint8Array(24);
		bytes.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], 0);
		bytes.set([0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52], 8);
		bytes[16] = (width >>> 24) & 0xff;
		bytes[17] = (width >>> 16) & 0xff;
		bytes[18] = (width >>> 8) & 0xff;
		bytes[19] = width & 0xff;
		bytes[20] = (height >>> 24) & 0xff;
		bytes[21] = (height >>> 16) & 0xff;
		bytes[22] = (height >>> 8) & 0xff;
		bytes[23] = height & 0xff;
		const b64 = Buffer.from(bytes).toString("base64");
		return `data:image/png;base64,${b64}`;
	}

	it("hoists a small image as a real ImagePart when the budget can absorb it", async () => {
		const provider = makeProvider([
			[
				{
					type: "tool_call",
					id: "shot",
					name: "browser_screenshot",
					args: { fullPage: false },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "saw it" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		// 320×240 → ~390 vision tokens. Plenty of budget on a default
		// 32k unknown-model context window.
		const tinyShot = bigPngDataUrl(320, 240);
		const screenshotTool: ToolSpec = {
			name: "browser_screenshot",
			description: "fakes a screenshot",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return { dataUrl: tinyShot, downscaled: false };
			},
		};
		const agent = new Agent(
			{
				id: "ok",
				provider,
				tools: [screenshotTool],
				host: makeHost(),
				mode: baseMode,
			},
			// Use Kimi K2 (256k window + supportsVision=true) so the
			// image-injection path runs.
			{ modelId: "moonshotai/kimi-k2" },
		);
		await agent.run({ userMessage: "screenshot please" });
		const userMsg = agent
			.getHistory()
			.find((m) => m.role === "user" && m.parts.some((p) => p.kind === "image"));
		expect(userMsg).toBeDefined();
		const imagePart = userMsg?.parts.find((p) => p.kind === "image");
		expect(imagePart).toBeDefined();
	});

	it("eagerly describes the current image when it would push the request over the budget", async () => {
		// 1280×40000 → ~261k vision tokens. By itself it exceeds the
		// budget on any context window, so the budget check is guaranteed
		// to fire regardless of how much history we pre-load. Keeps the
		// test deterministic: no need to thread the needle between
		// predictive auto-compact firing and not firing.
		const bigShot = bigPngDataUrl(1280, 40000);
		const screenshotTool: ToolSpec = {
			name: "browser_screenshot",
			description: "fakes a big screenshot",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return { dataUrl: bigShot, downscaled: false };
			},
		};
		// 3 provider events: describe sub-call for the eager demote, the
		// actual model turn, the final answer.
		const provider = makeProvider([
			// The agent's first stream — model takes a screenshot.
			[
				{
					type: "tool_call",
					id: "shot",
					name: "browser_screenshot",
					args: { fullPage: true },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			// The eager describeImage sub-call kicks in because the image
			// alone (~52k vision tokens) + the pre-loaded big history would
			// overflow the 256k Kimi-K2 budget.
			[
				{ type: "text_delta", text: "The admin orders page shows 0 results and a broken header." },
				{ type: "message_end", stopReason: "end" },
			],
			// Final turn after the image is described in history.
			[
				{ type: "text_delta", text: "got it" },
				{ type: "message_end", stopReason: "end" },
			],
		]);

		// Empty initial history — the image alone is over the ceiling, so
		// we don't need bulky pre-loaded text to trip the check. Keeps
		// auto-compact out of the picture.
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];

		const agent = new Agent(
			{
				id: "tight-budget",
				provider,
				tools: [screenshotTool],
				host: makeHost(),
				mode: baseMode,
			},
			{ modelId: "moonshotai/kimi-k2" },
			initialHistory,
		);
		const errors: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") errors.push(ev.message);
		});
		// Suppress predictive auto-compact for this test by adding an
		// already-compacted marker — we want to exercise the IMAGE
		// triage path, not the unrelated history-compact path.
		await agent.run({ userMessage: "snapshot" });

		// Find the user message that hoists the tool's image.
		const injectionMsg = agent
			.getHistory()
			.slice()
			.reverse()
			.find(
				(m) =>
					m.role === "user" &&
					m.parts.some((p) => p.kind === "text" && p.text.startsWith("[OATI inlined")),
			);
		expect(injectionMsg).toBeDefined();
		// The image should NOT be an ImagePart — it should have been
		// swapped for a TextPart description.
		const hasImage = injectionMsg?.parts.some((p) => p.kind === "image") ?? false;
		expect(hasImage).toBe(false);
		// AND the parts must include the "[OATI image memory]" description
		// marker so the model knows this is the post-triage shape.
		const hasDescription = injectionMsg?.parts.some(
			(p) => p.kind === "text" && p.text.includes("[OATI image memory]"),
		);
		expect(hasDescription).toBe(true);
		// A diagnostic must have fired so the user sees what happened.
		expect(errors.some((m) => m.includes("[image-budget]"))).toBe(true);
	});

	it("falls back to a budget-explaining stub when the describe sub-call returns empty", async () => {
		const bigShot = bigPngDataUrl(1280, 40000);
		const screenshotTool: ToolSpec = {
			name: "browser_screenshot",
			description: "fakes a big screenshot",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return { dataUrl: bigShot, downscaled: false };
			},
		};
		const provider = makeProvider([
			[
				{
					type: "tool_call",
					id: "shot",
					name: "browser_screenshot",
					args: { fullPage: true },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			// Describe sub-call returns NOTHING (no text_delta events).
			[{ type: "message_end", stopReason: "end" }],
			[
				{ type: "text_delta", text: "ack" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		const agent = new Agent(
			{
				id: "no-desc",
				provider,
				tools: [screenshotTool],
				host: makeHost(),
				mode: baseMode,
			},
			{ modelId: "moonshotai/kimi-k2" },
			initialHistory,
		);
		await agent.run({ userMessage: "snapshot" });
		const injectionMsg = agent
			.getHistory()
			.slice()
			.reverse()
			.find(
				(m) =>
					m.role === "user" &&
					m.parts.some((p) => p.kind === "text" && p.text.startsWith("[OATI inlined")),
			);
		const stubPart = injectionMsg?.parts.find(
			(p) => p.kind === "text" && p.text.includes("pixels were released"),
		);
		expect(stubPart).toBeDefined();
		// Stub should cite both the history size and the image cost so
		// the model has a concrete reason rather than just "released."
		const text = (stubPart as { text: string }).text;
		expect(text).toMatch(/budget/i);
		expect(text).toMatch(/pageText|re-capture/i);
	});
});

describe("Agent — image-to-description demotion (2026-06-01)", () => {
	const tinyPng = "data:image/png;base64,iVBORw0KGgo=";

	it("swaps non-most-recent ImageParts for TextPart descriptions before the stream call", async () => {
		const provider = makeProvider([
			[
				{
					type: "text_delta",
					text: "First screenshot showed the login page with a broken submit button.",
				},
				{ type: "message_end", stopReason: "end" },
			],
			[
				{
					type: "text_delta",
					text: "Second screenshot showed the cart page with a 500 error toast.",
				},
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "Got it." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [
			{
				role: "user",
				parts: [
					{ kind: "text", text: "first capture" },
					{ kind: "image", mimeType: "image/png", dataUrl: `${tinyPng}AAAA` },
				],
			},
			{ role: "assistant", parts: [{ kind: "text", text: "looked" }] },
			{
				role: "user",
				parts: [
					{ kind: "text", text: "second capture" },
					{ kind: "image", mimeType: "image/png", dataUrl: `${tinyPng}BBBB` },
				],
			},
			{ role: "assistant", parts: [{ kind: "text", text: "looked again" }] },
			{
				role: "user",
				parts: [
					{ kind: "text", text: "third capture" },
					{ kind: "image", mimeType: "image/png", dataUrl: `${tinyPng}CCCC` },
				],
			},
		];
		const agent = new Agent(
			{ id: "demote", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
			initialHistory,
		);
		await agent.run({ userMessage: "ok" });
		const history = agent.getHistory();
		const msg0 = history[0];
		expect(msg0.parts.some((p) => p.kind === "image")).toBe(false);
		const textPart0 = msg0.parts.find(
			(p) => p.kind === "text" && p.text.startsWith("[OATI image memory]"),
		);
		expect(textPart0).toBeDefined();
		expect((textPart0 as { text: string }).text).toContain("login page");
		const msg2 = history[2];
		expect(msg2.parts.some((p) => p.kind === "image")).toBe(false);
		const textPart2 = msg2.parts.find(
			(p) => p.kind === "text" && p.text.startsWith("[OATI image memory]"),
		);
		expect((textPart2 as { text: string }).text).toContain("cart page");
		const msg4 = history[4];
		expect(msg4.parts.some((p) => p.kind === "image")).toBe(true);
	});

	it("does NOT demote when the model is text-only (no vision pipeline to optimise)", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [
			{
				role: "user",
				parts: [{ kind: "image", mimeType: "image/png", dataUrl: `${tinyPng}AAAA` }],
			},
			{ role: "assistant", parts: [{ kind: "text", text: "noted" }] },
			{
				role: "user",
				parts: [{ kind: "image", mimeType: "image/png", dataUrl: `${tinyPng}BBBB` }],
			},
		];
		const agent = new Agent(
			{ id: "no-vision", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "ollama/llama3" },
			initialHistory,
		);
		await agent.run({ userMessage: "go" });
		const history = agent.getHistory();
		expect(history[0].parts.some((p) => p.kind === "image")).toBe(true);
		expect(history[2].parts.some((p) => p.kind === "image")).toBe(true);
	});

	it("falls back to a generic breadcrumb when the describe sub-call returns empty", async () => {
		const provider = makeProvider([
			[{ type: "message_end", stopReason: "end" }],
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [
			{
				role: "user",
				parts: [{ kind: "image", mimeType: "image/png", dataUrl: `${tinyPng}AAAA` }],
			},
			{ role: "assistant", parts: [{ kind: "text", text: "noted" }] },
			{
				role: "user",
				parts: [{ kind: "image", mimeType: "image/png", dataUrl: `${tinyPng}BBBB` }],
			},
		];
		const agent = new Agent(
			{ id: "fallback", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "moonshotai/kimi-k2" },
			initialHistory,
		);
		await agent.run({ userMessage: "go" });
		const msg0 = agent.getHistory()[0];
		expect(msg0.parts.some((p) => p.kind === "image")).toBe(false);
		const textPart = msg0.parts.find(
			(p) => p.kind === "text" && p.text.startsWith("[OATI image memory]"),
		);
		expect(textPart).toBeDefined();
		expect((textPart as { text: string }).text).toMatch(/re-capture/i);
	});
});

describe("trimToolResultForHistory (2026-06-01: context-budget hygiene)", () => {
	// Phase 1a: every tool_result that lands in history needs to be
	// bounded. A 100k stdout from `exec` or a multi-thousand-line
	// `read_file` floods every subsequent turn with the same payload.
	// Cap at MAX_TOOL_RESULT_CHARS (~32k chars ≈ 8k tokens) with a clear
	// footer so the model knows it can re-call to see more.
	it("leaves small string outputs untouched", async () => {
		const { trimToolResultForHistory } = await import("../src/agent");
		const r = trimToolResultForHistory(
			{ kind: "tool_result", id: "c1", output: "hello world", isError: false },
			false,
		);
		expect(r.output).toBe("hello world");
	});

	it("truncates large string outputs and appends a footer naming the original size", async () => {
		const { trimToolResultForHistory } = await import("../src/agent");
		const big = "x".repeat(50_000);
		const r = trimToolResultForHistory(
			{ kind: "tool_result", id: "c1", output: big, isError: false },
			false,
		);
		expect(typeof r.output).toBe("string");
		const out = r.output as string;
		expect(out.length).toBeLessThan(big.length);
		expect(out).toMatch(/truncated by OATI/);
		expect(out).toMatch(/50,000/); // original size in footer
	});

	it("truncates long string fields inside object outputs (e.g. exec stdout)", async () => {
		const { trimToolResultForHistory } = await import("../src/agent");
		const r = trimToolResultForHistory(
			{
				kind: "tool_result",
				id: "c1",
				output: { stdout: "x".repeat(40_000), stderr: "ok", exitCode: 0 },
				isError: false,
			},
			false,
		);
		const out = r.output as { stdout: string; stderr: string; exitCode: number };
		expect(out.stdout.length).toBeLessThan(40_000);
		expect(out.stdout).toMatch(/truncated by OATI/);
		// Small fields stay intact.
		expect(out.stderr).toBe("ok");
		expect(out.exitCode).toBe(0);
	});

	it("strips dataUrl from object outputs when the image has been hoisted to a separate ImagePart", async () => {
		const { trimToolResultForHistory } = await import("../src/agent");
		const fakeImage = `data:image/png;base64,${"A".repeat(50_000)}`;
		const r = trimToolResultForHistory(
			{
				kind: "tool_result",
				id: "c1",
				output: { dataUrl: fakeImage, pageText: "Hello", downscaled: false },
				isError: false,
			},
			true, // hasImageHoist
		);
		const out = r.output as { dataUrl: string; pageText: string };
		expect(out.dataUrl).toMatch(/image hoisted/i);
		expect(out.dataUrl.length).toBeLessThan(200);
		// pageText (the cheap text fallback) stays intact.
		expect(out.pageText).toBe("Hello");
	});

	it("preserves dataUrl when no image hoisting happened (e.g. non-vision model path)", async () => {
		const { trimToolResultForHistory } = await import("../src/agent");
		const fakeImage = `data:image/png;base64,${"A".repeat(50_000)}`;
		const r = trimToolResultForHistory(
			{
				kind: "tool_result",
				id: "c1",
				output: { dataUrl: fakeImage, pageText: "Hello" },
				isError: false,
			},
			false, // hasImageHoist = false → no hoisting happened
		);
		// dataUrl stays as a (truncated) field — the image is the tool result.
		const out = r.output as { dataUrl: string };
		// Long-string truncation still kicks in via the field cap.
		expect(out.dataUrl.length).toBeGreaterThan(0);
		expect(out.dataUrl).toMatch(/^data:image\/png;base64,/);
	});
});

describe("quickHash (2026-06-01)", () => {
	it("produces the same hash for identical strings", async () => {
		const { quickHash } = await import("../src/agent");
		expect(quickHash("abc")).toBe(quickHash("abc"));
		expect(quickHash("x".repeat(1000))).toBe(quickHash("x".repeat(1000)));
	});

	it("produces different hashes for content that differs anywhere (head/mid/tail)", async () => {
		const { quickHash } = await import("../src/agent");
		const a = `abc${"x".repeat(500)}end`;
		const b = `ABC${"x".repeat(500)}end`; // head differs
		const c = `abc${"x".repeat(250)}Z${"x".repeat(249)}end`; // mid differs
		const d = `abc${"x".repeat(500)}END`; // tail differs
		expect(quickHash(a)).not.toBe(quickHash(b));
		expect(quickHash(a)).not.toBe(quickHash(c));
		expect(quickHash(a)).not.toBe(quickHash(d));
	});
});

describe("Agent — file-read dedup (2026-06-01)", () => {
	it("returns a short 'unchanged' stub on the second read of an unmodified file", async () => {
		const fileContent = "function add(a, b) { return a + b; }\n".repeat(500); // ~18k chars
		const readFile: ToolSpec = {
			name: "read_file",
			description: "reads a file",
			schema: { type: "object", properties: { path: { type: "string" } } },
			approval: "auto",
			async handler() {
				return fileContent;
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "c1", name: "read_file", args: { path: "src/a.ts" } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "tool_call", id: "c2", name: "read_file", args: { path: "src/a.ts" } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "dedup", provider, tools: [readFile], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "look at a.ts" });
		const history = agent.getHistory();
		const toolResults = history.flatMap((m) =>
			m.role === "tool" ? m.parts.filter((p) => p.kind === "tool_result") : [],
		);
		expect(toolResults).toHaveLength(2);
		// First read returns the actual file contents.
		const firstOutput = (toolResults[0] as { output: unknown }).output as string;
		expect(firstOutput).toContain("function add");
		// Second read returns the dedup stub — much shorter, and names the path.
		const secondOutput = (toolResults[1] as { output: unknown }).output as string;
		expect(secondOutput).toMatch(/dedup/i);
		expect(secondOutput).toContain("src/a.ts");
		expect(secondOutput.length).toBeLessThan(500);
	});

	it("re-reads the file after a write_file invalidates the cache", async () => {
		let content = "original";
		const readFile: ToolSpec = {
			name: "read_file",
			description: "reads",
			schema: { type: "object", properties: { path: { type: "string" } } },
			approval: "auto",
			async handler() {
				return content;
			},
		};
		const writeFile: ToolSpec = {
			name: "write_file",
			description: "writes",
			schema: {
				type: "object",
				properties: { path: { type: "string" }, content: { type: "string" } },
			},
			approval: "auto",
			async handler(args) {
				content = (args as { content: string }).content;
				return "wrote";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "c1", name: "read_file", args: { path: "x.ts" } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{
					type: "tool_call",
					id: "c2",
					name: "write_file",
					args: { path: "x.ts", content: "new content" },
				},
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "tool_call", id: "c3", name: "read_file", args: { path: "x.ts" } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "invalidate", provider, tools: [readFile, writeFile], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "rewrite x.ts" });
		const toolResults = agent
			.getHistory()
			.flatMap((m) => (m.role === "tool" ? m.parts.filter((p) => p.kind === "tool_result") : []));
		// Three results: read#1 (original), write, read#2 (new content — NOT dedup stub).
		expect(toolResults).toHaveLength(3);
		const lastRead = (toolResults[2] as { output: unknown }).output as string;
		expect(lastRead).toBe("new content");
		expect(lastRead).not.toMatch(/dedup/i);
	});

	it("normalizes Windows path separators so 'src/a.ts' and 'src\\\\a.ts' dedup together", async () => {
		const readFile: ToolSpec = {
			name: "read_file",
			description: "reads",
			schema: { type: "object", properties: { path: { type: "string" } } },
			approval: "auto",
			async handler() {
				return "same content";
			},
		};
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "c1", name: "read_file", args: { path: "src/a.ts" } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "tool_call", id: "c2", name: "read_file", args: { path: "src\\a.ts" } },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "norm", provider, tools: [readFile], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		await agent.run({ userMessage: "look" });
		const toolResults = agent
			.getHistory()
			.flatMap((m) => (m.role === "tool" ? m.parts.filter((p) => p.kind === "tool_result") : []));
		const secondOutput = (toolResults[1] as { output: unknown }).output as string;
		expect(secondOutput).toMatch(/dedup/i);
	});
});

describe("estimateImageVisionTokens (2026-06-01)", () => {
	// 2026-06-01: live-bug fallout — a viewport-only screenshot turn hit
	// 323k requested tokens vs a 262k cap because the flat 1200-tokens-
	// per-image estimate was 10-20× too low. Predictive auto-compact
	// thought we had plenty of room; we were already past the wall.
	// Helper: build a synthetic PNG header bearing the given width × height.
	function pngDataUrl(width: number, height: number): string {
		// PNG signature (8) + IHDR chunk header (8) + width (4 BE) + height (4 BE)
		const bytes = new Uint8Array(24);
		bytes.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], 0);
		// IHDR length = 13, type = "IHDR"
		bytes.set([0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52], 8);
		bytes[16] = (width >>> 24) & 0xff;
		bytes[17] = (width >>> 16) & 0xff;
		bytes[18] = (width >>> 8) & 0xff;
		bytes[19] = width & 0xff;
		bytes[20] = (height >>> 24) & 0xff;
		bytes[21] = (height >>> 16) & 0xff;
		bytes[22] = (height >>> 8) & 0xff;
		bytes[23] = height & 0xff;
		const b64 = Buffer.from(bytes).toString("base64");
		return `data:image/png;base64,${b64}`;
	}

	it("returns ~13k vision tokens for a 1280×800 viewport-class PNG (was 1200)", async () => {
		const { estimateImageVisionTokens } = await import("../src/agent");
		const tokens = estimateImageVisionTokens(pngDataUrl(1280, 800), "image/png");
		// 1280 × 800 / 196 ≈ 5224. We were billing 1200 — off by ~4×.
		expect(tokens).toBeGreaterThan(5000);
		expect(tokens).toBeLessThan(6000);
	});

	it("returns ~27k vision tokens for a 1280×4096 fullPage-class PNG", async () => {
		const { estimateImageVisionTokens } = await import("../src/agent");
		const tokens = estimateImageVisionTokens(pngDataUrl(1280, 4096), "image/png");
		// 1280 × 4096 / 196 ≈ 26749. Critical for the predictive auto-
		// compact — a single fullPage capture should already pressure
		// the threshold on K2.6's 256k window.
		expect(tokens).toBeGreaterThan(25000);
		expect(tokens).toBeLessThan(28000);
	});

	it("falls back to a base64-length proxy when the PNG header can't be parsed", async () => {
		const { estimateImageVisionTokens } = await import("../src/agent");
		// Deliberately malformed data URL — no PNG sig, no IHDR.
		const bogus = "data:image/png;base64,QQAA"; // a few bytes of garbage
		const tokens = estimateImageVisionTokens(bogus, "image/png");
		// Fallback estimate is at least 1 (never zero, never negative).
		expect(tokens).toBeGreaterThanOrEqual(1);
		expect(Number.isFinite(tokens)).toBe(true);
	});
});

describe("Agent — predictive auto-compact (2026-06-01)", () => {
	// Live-bug: a viewport-only screenshot turn hit `Your request exceeded
	// model token limit: 262144 (requested: 323628)`. The existing auto-
	// compact only fires AFTER an empty response, so when the model
	// happily returns a tool call instead, history grows turn after turn
	// until the provider rejects. The fix runs `shouldAutoCompact` before
	// each stream call so the request actually fits.
	it("compacts BEFORE the stream when history is past threshold (even when the model returns a tool call)", async () => {
		const longText = "x".repeat(50_000);
		const initialHistory: import("@oati/shared").ConversationMessage[] = [];
		for (let i = 0; i < 30; i++) {
			initialHistory.push({ role: "user", parts: [{ kind: "text", text: `q ${i}` }] });
			initialHistory.push({ role: "assistant", parts: [{ kind: "text", text: `${longText} ${i}` }] });
		}
		const echoTool: ToolSpec = {
			name: "echo",
			description: "echoes",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return "ok";
			},
		};
		const provider = makeProvider([
			// Summarize call (compactHistoryMiddle): returns a summary.
			[
				{ type: "text_delta", text: "Summary: bulky history." },
				{ type: "message_end", stopReason: "end" },
			],
			// First real turn — model returns a tool call, NOT empty. Without
			// the predictive trigger, the post-empty auto-compact wouldn't
			// have fired and history would have stayed huge.
			[
				{ type: "tool_call", id: "c1", name: "echo", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			// Follow-up turn after the tool result — model wraps up.
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "predictive", provider, tools: [echoTool], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
			initialHistory,
		);
		const errors: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") errors.push(ev.message);
		});
		await agent.run({ userMessage: "continue" });
		// The predictive auto-compact diagnostic must fire, mentioning the
		// model's context window so the user knows what the threshold was.
		const compactMsg = errors.find((m) => m.startsWith("[auto-compact]"));
		expect(compactMsg).toBeDefined();
		expect(compactMsg).toMatch(/nearing the model's context limit/i);
		// History shrank — middle was summarized.
		expect(agent.getHistory().length).toBeLessThan(initialHistory.length / 2);
	});

	// Live-bug 2026-06-01: after the predictive auto-compact landed,
	// the next provider call failed with `an assistant message with
	// 'tool_calls' must be followed by tool messages responding to each
	// 'tool_call_id'`. Root cause: compactHistoryMiddle's naive HEAD/TAIL
	// slice cut between an assistant tool_call and its matching tool
	// response, leaving the wire request with dangling tool_call_ids.
	it("preserves tool_call ↔ tool_result pairs across the compaction boundary (live-bug 2026-06-01)", async () => {
		// Construct a history where:
		//   [0] user — task framing
		//   [1] assistant — text only (so HEAD boundary at 2 is naive-safe)
		//   [2] assistant — has tool_call_id 'read_file:0'
		//   [3] tool — answers 'read_file:0'
		//   ... bulky filler in the middle ...
		//   [N-2] assistant — has tool_call_id 'exec:1'
		//   [N-1] tool — answers 'exec:1'
		// The naive slice at HEAD=2 and TAIL=tail-N would keep [0,1] in
		// HEAD, drop [2..N-tail], keep last TAIL in TAIL. The kept-tail's
		// leading message could easily be a `tool` role responding to a
		// call in the dropped middle — orphan.
		const longText = "x".repeat(50_000);
		const history: import("@oati/shared").ConversationMessage[] = [];
		history.push({ role: "user", parts: [{ kind: "text", text: "initial task" }] });
		history.push({ role: "assistant", parts: [{ kind: "text", text: "ok starting" }] });
		// 25 paired tool-call / tool-result turns of bulky text.
		for (let i = 0; i < 25; i++) {
			history.push({
				role: "assistant",
				parts: [
					{ kind: "tool_call", id: `read_file:${i}`, name: "read_file", args: { path: `f${i}` } },
				],
			});
			history.push({
				role: "tool",
				parts: [
					{ kind: "tool_result", id: `read_file:${i}`, output: `${longText} ${i}`, isError: false },
				],
			});
		}
		const provider = makeProvider([
			// Pre-stream compaction summary call.
			[
				{ type: "text_delta", text: "summary of dropped middle" },
				{ type: "message_end", stopReason: "end" },
			],
			// Real user turn after compaction.
			[
				{ type: "text_delta", text: "ack" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "pair-safe", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
			history,
		);
		await agent.run({ userMessage: "continue" });
		// Verify: no orphan tool messages, no unanswered tool_calls.
		const finalHistory = agent.getHistory();
		const pending = new Set<string>();
		for (const m of finalHistory) {
			if (m.role === "assistant") {
				for (const p of m.parts) if (p.kind === "tool_call") pending.add(p.id);
			} else if (m.role === "tool") {
				for (const p of m.parts) {
					if (p.kind === "tool_result") {
						// Every tool result must have a matching open call.
						expect(pending.has(p.id)).toBe(true);
						pending.delete(p.id);
					}
				}
			}
		}
		// Every tool_call in the post-compaction history is answered.
		expect(pending.size).toBe(0);
		// And the auto-compact marker is in there.
		expect(
			finalHistory.some(
				(m) =>
					m.role === "system" &&
					m.parts.some((p) => p.kind === "text" && p.text.includes("Auto-compacted")),
			),
		).toBe(true);
	});

	it("findSafeHeadBoundary advances past an unfinished tool-call group at the cut", async () => {
		const { findSafeHeadBoundary } = await import("../src/agent");
		const history: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c1", name: "read", args: {} }],
			},
			{ role: "tool", parts: [{ kind: "tool_result", id: "c1", output: "x", isError: false }] },
			{ role: "user", parts: [{ kind: "text", text: "more" }] },
		];
		// Naive minHeadEnd=2 lands right after the assistant tool_call but
		// before the tool response — must advance to 3 to include the
		// matching tool message.
		expect(findSafeHeadBoundary(history, 2)).toBe(3);
	});

	// Live-bug 2026-06-01 follow-on: a session whose history was corrupted
	// by the earlier buggy compaction can't recover — every new user
	// message hits the same `tool_call_ids did not have response messages`
	// rejection. The repair step scans for orphans and injects synthetic
	// tool_result stubs so the conversation can continue.
	it("self-heals a session whose history has orphan tool_calls from earlier corruption", async () => {
		// Reconstruct the live shape: assistant emitted tool_calls
		// `read_file:0` and `exec:1`, but their tool responses are
		// missing (dropped by the earlier buggy compaction).
		const broken: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "fix the add to cart" }] },
			{
				role: "assistant",
				parts: [
					{ kind: "tool_call", id: "read_file:0", name: "read_file", args: { path: "cart.tsx" } },
					{ kind: "tool_call", id: "exec:1", name: "exec", args: { cmd: "npm test" } },
				],
			},
			// NO tool messages here — the original responses are gone.
			{ role: "user", parts: [{ kind: "text", text: "Hey" }] },
		];
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "Got it — continuing." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "repair", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
			broken,
		);
		const errors: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") errors.push(ev.message);
		});
		await agent.run({ userMessage: "Hey again" });
		// Repair diagnostic fired and named the recovered ids.
		const repairMsg = errors.find((m) => m.startsWith("[history-repair]"));
		expect(repairMsg).toBeDefined();
		expect(repairMsg).toContain("read_file:0");
		expect(repairMsg).toContain("exec:1");
		// Post-repair history is balanced: every assistant tool_call has a
		// matching tool_result somewhere in the contiguous run after it.
		const finalHistory = agent.getHistory();
		const pending = new Set<string>();
		for (const m of finalHistory) {
			if (m.role === "assistant") {
				for (const p of m.parts) if (p.kind === "tool_call") pending.add(p.id);
			} else if (m.role === "tool") {
				for (const p of m.parts) {
					if (p.kind === "tool_result") pending.delete(p.id);
				}
			}
		}
		expect(pending.size).toBe(0);
	});

	it("repairOrphanToolCalls leaves a well-formed history unchanged", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		const clean: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c1", name: "read", args: {} }],
			},
			{ role: "tool", parts: [{ kind: "tool_result", id: "c1", output: "x", isError: false }] },
			{ role: "user", parts: [{ kind: "text", text: "next" }] },
		];
		const { repaired, orphans } = repairOrphanToolCalls(clean);
		expect(orphans).toEqual([]);
		expect(repaired).toHaveLength(clean.length);
	});

	it("repairOrphanToolCalls injects exactly one stub per missing tool_call_id", async () => {
		const { repairOrphanToolCalls } = await import("../src/agent");
		const broken: import("@oati/shared").ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{ kind: "tool_call", id: "a", name: "read", args: {} },
					{ kind: "tool_call", id: "b", name: "exec", args: {} },
				],
			},
			// Only `a` was answered — `b` is orphaned.
			{ role: "tool", parts: [{ kind: "tool_result", id: "a", output: "ok", isError: false }] },
			{ role: "user", parts: [{ kind: "text", text: "continue" }] },
		];
		const { repaired, orphans } = repairOrphanToolCalls(broken);
		expect(orphans).toEqual(["b"]);
		// Repaired layout: assistant, tool(a), tool(b-synthetic), user
		expect(repaired).toHaveLength(4);
		expect(repaired[2].role).toBe("tool");
		const stubPart = repaired[2].parts[0];
		expect(stubPart.kind).toBe("tool_result");
		if (stubPart.kind === "tool_result") {
			expect(stubPart.id).toBe("b");
			expect(stubPart.isError).toBe(true);
		}
	});

	it("findSafeTailBoundary walks forward past leading orphan tool messages", async () => {
		const { findSafeTailBoundary } = await import("../src/agent");
		const history: import("@oati/shared").ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "go" }] },
			{ role: "assistant", parts: [{ kind: "tool_call", id: "c1", name: "read", args: {} }] },
			{ role: "tool", parts: [{ kind: "tool_result", id: "c1", output: "x", isError: false }] },
			{ role: "user", parts: [{ kind: "text", text: "next" }] },
		];
		// initialTailStart=2 points at a tool message whose matching call
		// would be in the dropped middle — advance past it to the next
		// non-tool message at index 3.
		expect(findSafeTailBoundary(history, 2)).toBe(3);
	});

	it("does NOT compact a small session preemptively (no false positive)", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "hi" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "small", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "some-unknown-model" },
		);
		const errors: string[] = [];
		agent.on((ev) => {
			if (ev.type === "error") errors.push(ev.message);
		});
		await agent.run({ userMessage: "hi" });
		expect(errors.find((m) => m.startsWith("[auto-compact]"))).toBeUndefined();
	});
});
