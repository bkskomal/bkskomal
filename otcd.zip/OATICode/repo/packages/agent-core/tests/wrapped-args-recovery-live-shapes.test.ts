import { describe, expect, it } from "vitest";
import { scrubTrailingWrapperNoise, tryRecoverWrappedArgs } from "../src/agent";

/**
 * Live-bug regression suite (2026-05-26).
 *
 * Real `ev.args` shapes captured from a user's running Kimi K2.6 session
 * after they enabled Diagnostics. The model (or the gateway between it
 * and us) wraps the entire JSON args object in an extra pair of double
 * quotes, defeating strict JSON.parse. The lenient parser falls back to
 * `{_raw: <the broken string>}`, and our smart-recovery must rescue the
 * fields via regex extraction.
 *
 * Each test pins one observed shape so a future change to the recovery
 * pass can't silently regress on a case the user has actually hit.
 */
describe("wrapped-args recovery — live user-reported shapes (Kimi K2.6 via OpenRouter)", () => {
	it("list_dir: extra-quoted JSON with multiple fields", () => {
		const schema = {
			type: "object",
			properties: {
				path: { type: "string" },
				recursive: { type: "boolean" },
				max_entries: { type: "integer" },
			},
			required: ["path"],
		};
		const wrapped = {
			_raw: '"{"path":"apps/client/src","max_entries":10}"',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.path).toBe("apps/client/src");
		expect(out?.max_entries).toBe(10);
	});

	it("read_file: extra-quoted JSON with single field", () => {
		const schema = {
			type: "object",
			properties: { path: { type: "string" } },
			required: ["path"],
		};
		const wrapped = {
			_raw: '"{"path":"apps/client/src/pages/ChatPage.tsx"}"',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.path).toBe("apps/client/src/pages/ChatPage.tsx");
	});

	it("get_workspace_context: extra-quoted empty object recovers as `{}` via the strict-parse peel", () => {
		// `'"{}"'` peels through JSON.parse twice: first peel yields the
		// string `{}`, second peel yields the empty object literal. Since
		// the schema has no required fields, recovery returns the empty
		// object — the right shape for a no-arg tool.
		const schema = { type: "object", properties: {} };
		const wrapped = { _raw: '"{}"' };
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toEqual({});
	});

	it("start_background_process: OVER-ESCAPED JSON — every quote prefixed with extra backslash", () => {
		// 2026-05-26 live-bug: Kimi K2.6 emitted args where every JSON
		// quote was preceded by an extra backslash, defeating both strict
		// parse and the literal `"field"` regex. Recovery's new
		// de-escape pass strips the extra backslashes and re-parses.
		const schema = {
			type: "object",
			properties: {
				command: { type: "string" },
				label: { type: "string" },
			},
			required: ["command"],
		};
		const wrapped = {
			_raw:
				'{\\"command\\":\\"cd apps/client && pnpm dev --port 3002\\",\\"label\\":\\"Client App\\"}',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.command).toBe("cd apps/client && pnpm dev --port 3002");
		expect(out?.label).toBe("Client App");
	});

	it("start_background_process: NORMAL JSON still recovers via the strict-parse peel (no regression on the clean path)", () => {
		const schema = {
			type: "object",
			properties: {
				command: { type: "string" },
				label: { type: "string" },
			},
			required: ["command"],
		};
		const wrapped = {
			_raw: '{"command":"cd apps/admin && pnpm dev --port 3003","label":"Admin Panel"}',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.command).toBe("cd apps/admin && pnpm dev --port 3003");
		expect(out?.label).toBe("Admin Panel");
	});

	// ---------------------------------------------------------------
	// Evil-shapes suite — synthetic torture tests for the candidate
	// enumeration model. Each combines two or more failure modes that
	// individual passes wouldn't handle; the cascade in
	// `generateRepairCandidates` should still recover.
	// ---------------------------------------------------------------

	it("evil: extra-quoted + over-escaped (double whammy)", () => {
		// Outer quotes AROUND an over-escaped JSON body. Both peeling and
		// de-escape need to compose for recovery to land.
		const schema = {
			type: "object",
			properties: { path: { type: "string" } },
			required: ["path"],
		};
		const wrapped = {
			_raw: '"{\\"path\\":\\"src/file.ts\\"}"',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.path).toBe("src/file.ts");
	});

	it("evil: smart quotes substituted for straight quotes (Word-paste shape)", () => {
		// Some gateways (or users pasting from Word) substitute U+201C/D
		// for ASCII `"`. JSON.parse rejects. Recovery's smart-quote
		// normalization replaces them and re-parses.
		const schema = {
			type: "object",
			properties: { path: { type: "string" } },
			required: ["path"],
		};
		const wrapped = { _raw: "{“path”:“src/file.ts”}" };
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.path).toBe("src/file.ts");
	});

	it("evil: trailing comma before closing brace", () => {
		// Model emitted `{"path":"x",}`. Strict JSON rejects. The
		// trailing-comma repair handles it.
		const schema = {
			type: "object",
			properties: { path: { type: "string" } },
			required: ["path"],
		};
		const wrapped = { _raw: '{"path":"src/file.ts",}' };
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.path).toBe("src/file.ts");
	});

	it("evil: triply-nested stringify (string of string of string of object)", () => {
		// `JSON.stringify(JSON.stringify(JSON.stringify({path: "x"})))`.
		// The peel cascade unwraps each layer until the object surfaces.
		const inner = { path: "src/file.ts" };
		const wrapped = {
			_raw: JSON.stringify(JSON.stringify(JSON.stringify(inner))),
		};
		const schema = {
			type: "object",
			properties: { path: { type: "string" } },
			required: ["path"],
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.path).toBe("src/file.ts");
	});

	it('evil: partially de-escaped (some `\\"` survived a cleanup)', () => {
		// One pass of string.replace stripped SOME backslashes but not
		// others (or applied to a midpoint shape). Recovery's tolerant
		// regex allows optional `\\?` before each key-quote.
		const schema = {
			type: "object",
			properties: {
				command: { type: "string" },
			},
			required: ["command"],
		};
		// Mix: first key is over-escaped, second isn't.
		const wrapped = { _raw: '{\\"command\\":"echo hi"}' };
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.command).toBe("echo hi");
	});

	it("write_file: lazy regex stops at the first end-of-string, doesn't slurp content into path (live-bug 2026-05-26)", () => {
		// User reported a diff-editor title showing
		//   `OATI: out/create_rag_ppt.py","content":"\"\"\"Create modern...`
		// The previous GREEDY regex extracted `path` as everything from the
		// opening quote through the LAST `"` followed by `,` or `}` — so
		// it captured the entire content blob plus its closing quote into
		// the path field. Lazy `*?` stops at the FIRST plausible end-of-
		// value, restoring the expected `path = "out/create_rag_ppt.py"`.
		const schema = {
			type: "object",
			properties: {
				path: { type: "string" },
				content: { type: "string" },
			},
			required: ["path", "content"],
		};
		// Force the lazy fallback by using a payload where the strict
		// pass doesn't match (over-escaped + many fields). The fix matters
		// most on shapes where the strict pass can't decide.
		const wrapped = {
			_raw:
				'{\\"path\\":\\"out/create_rag_ppt.py\\",\\"content\\":\\"' +
				'\\\\"\\\\"\\\\"Create a modern, visually appealing PowerPoint presentation for RAG.\\\\"\\\\"\\\\"' +
				"\\nfrom pptx import Presentation\\nfrom pptx.util import Inches" +
				'\\"}',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		// Path must be JUST the filename — not slurped into content.
		expect(out?.path).toBe("out/create_rag_ppt.py");
		// Content must still be recovered (just verifying both fields land).
		expect(typeof out?.content).toBe("string");
		expect(String(out?.content).length).toBeGreaterThan(0);
	});

	it("evil: garbage doesn't recover — returns undefined so the placeholder fires correctly", () => {
		// Recovery must NOT hallucinate values. When the raw genuinely
		// has no `path` field anywhere, recovery returns undefined and
		// the placeholder fallback runs.
		const schema = {
			type: "object",
			properties: { path: { type: "string" } },
			required: ["path"],
		};
		const wrapped = { _raw: "{garbled junk no field names anywhere}" };
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeUndefined();
	});

	it("write_file: extra-quoted JSON with embedded escape sequences in content", () => {
		// The pattern that hit ChatPage.tsx writes: path + content where
		// content contains escaped `\n` and `\"` sequences inside the
		// double-wrapped JSON. Recovery's regex picks up both fields and
		// JSON-parse-decodes the captured strings to restore actual
		// newlines / quotes.
		const schema = {
			type: "object",
			properties: {
				path: { type: "string" },
				content: { type: "string" },
			},
			required: ["path", "content"],
		};
		const wrapped = {
			_raw:
				'"{"path":"E:/OATICode/apps/client/src/pages/ChatPage.tsx",' +
				'"content":"import React from \\"react\\";\\n\\nconst X = () => null;\\n"}"',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.path).toBe("E:/OATICode/apps/client/src/pages/ChatPage.tsx");
		expect(typeof out?.content).toBe("string");
		expect(String(out?.content)).toContain("import React");
	});
});

describe("scrubTrailingWrapperNoise", () => {
	it('strips trailing closing wrapper `"}` from URLs', () => {
		// The Kimi K2.6 case (2026-05-29): triple-wrapped browser_open args.
		// JSON.parse succeeds on the inner layer but the outer wrapper's
		// closing `"}` ends up captured inside the url value.
		expect(scrubTrailingWrapperNoise('http://localhost:8080"}')).toBe("http://localhost:8080");
		expect(scrubTrailingWrapperNoise('http://localhost:8080\\"}')).toBe("http://localhost:8080");
	});

	it("strips an absorbed sibling field from commands", () => {
		// start_background_process from the same transcript: regex grabbed
		// the command value plus the entire trailing `,"label":"..."}` chunk.
		expect(scrubTrailingWrapperNoise('python -m http.server 8080","label":"Web Server"}')).toBe(
			"python -m http.server 8080",
		);
		expect(
			scrubTrailingWrapperNoise('python -m http.server 8080\\","label\\":\\"Web Server\\"}'),
		).toBe("python -m http.server 8080");
	});

	it("strips both stacked artifacts in one call (sibling + closing wrapper)", () => {
		expect(scrubTrailingWrapperNoise('python -m http.server 8080","label":"Web Server"}\\"}')).toBe(
			"python -m http.server 8080",
		);
	});

	it("leaves clean values untouched", () => {
		expect(scrubTrailingWrapperNoise("http://localhost:8080")).toBe("http://localhost:8080");
		expect(scrubTrailingWrapperNoise("src/foo.ts")).toBe("src/foo.ts");
		expect(scrubTrailingWrapperNoise("npm install")).toBe("npm install");
		expect(scrubTrailingWrapperNoise("")).toBe("");
		// File-content-shaped strings that don't end in a wrapper artifact.
		expect(scrubTrailingWrapperNoise("function foo() { return 1; }")).toBe(
			"function foo() { return 1; }",
		);
	});

	it("does not eat legitimate trailing quotes that aren't wrapper artifacts", () => {
		// A string ending in `"` (no brace, no escape) isn't a wrapper —
		// pattern B requires the closing `}`. Keep it.
		expect(scrubTrailingWrapperNoise('he said "hi"')).toBe('he said "hi"');
	});

	it("is idempotent", () => {
		const once = scrubTrailingWrapperNoise('http://localhost:8080"}');
		const twice = scrubTrailingWrapperNoise(once);
		expect(twice).toBe(once);
	});
});

describe("tryRecoverWrappedArgs applies scrubbing post-recovery", () => {
	it("recovered URL no longer carries the wrapper's closing `\"}`", () => {
		// The actual end-to-end live-bug scenario from the user's transcript.
		const schema = {
			type: "object",
			properties: { url: { type: "string" } },
			required: ["url"],
		};
		// The triple-wrapped shape Kimi K2.6 emitted for browser_open.
		const wrapped = { _raw: '"{"url":"http://localhost:8080\\"}"' };
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.url).toBe("http://localhost:8080");
	});

	it('recovered command no longer carries the absorbed `,"label":"..."}`', () => {
		const schema = {
			type: "object",
			properties: {
				command: { type: "string" },
				label: { type: "string" },
			},
			required: ["command"],
		};
		// start_background_process: command value absorbed the label field.
		const wrapped = {
			_raw: '"{"command":"python -m http.server 8080","label":"Web Server"}"',
		};
		const out = tryRecoverWrappedArgs(wrapped, schema);
		expect(out).toBeDefined();
		expect(out?.command).toBe("python -m http.server 8080");
	});
});
