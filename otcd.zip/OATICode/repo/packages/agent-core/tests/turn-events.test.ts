// Phase 3.1/3.2 protocol contract tests.
//
// The agent-core layer doesn't import the extension-host or webview, so
// the end-to-end rollback flow (webview button → revert_turn message →
// chat-panel handler → AutoRevertGuard) lives in the extension-host
// integration tests under packages/extension-host/test-electron.
//
// What WE can verify here, model-agnostically:
//   1. Agent.run emits turn_start with a unique turnId per call
//   2. turn_start and turn_end share the same turnId
//   3. turn_end fires even when an iteration throws (try/finally)
//
// These are the invariants the chat-panel snapshot machinery relies on.
// If any of them regress, the eager-snapshot capture wires no longer
// link to the user-facing rollback button.

import type {
	AgentEvent,
	HostContext,
	ModeConfig,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
} from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { Agent } from "../src/agent";

const baseMode: ModeConfig = {
	id: "test",
	displayName: "Test",
	systemPrompt: "test",
	enabledTools: "all",
	enablePlanner: false,
	enableCritic: false,
	maxParallelAgents: 1,
	maxIterations: 5,
};

function makeHost(): HostContext {
	return {
		readFile: vi.fn().mockResolvedValue(""),
		writeFile: vi.fn().mockResolvedValue(undefined),
		fileExists: vi.fn().mockResolvedValue(false),
		exec: vi.fn().mockResolvedValue({ stdout: "", stderr: "", exitCode: 0 }),
		workspaceRoot: () => "/test",
		requestApproval: vi.fn().mockResolvedValue(true),
		showDiff: vi.fn().mockResolvedValue(undefined),
		log: vi.fn(),
	};
}

function makeProvider(events: ProviderStreamEvent[][]): ProviderSpec {
	let call = 0;
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest) {
			const slice = events[call++] ?? [{ type: "message_end", stopReason: "end" }];
			for (const ev of slice) yield ev;
		},
	};
}

describe("Agent turn lifecycle invariants for rollback (Phase 3.2 contract)", () => {
	it("each Agent.run call generates a fresh, unique turnId", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "a" },
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "b" },
				{ type: "message_end", stopReason: "end" },
			],
			[
				{ type: "text_delta", text: "c" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "rb1", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const turnIds: string[] = [];
		agent.on((ev: AgentEvent) => {
			if (ev.type === "turn_start") turnIds.push(ev.turnId);
		});
		await agent.run({ userMessage: "one" });
		await agent.run({ userMessage: "two" });
		await agent.run({ userMessage: "three" });
		expect(turnIds).toHaveLength(3);
		expect(new Set(turnIds).size).toBe(3); // all distinct
	});

	it("turn_start and turn_end share the same turnId in the same run", async () => {
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "ok" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{ id: "rb2", provider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const pairs: Array<{ start?: string; end?: string }> = [{}];
		agent.on((ev: AgentEvent) => {
			if (ev.type === "turn_start") pairs[pairs.length - 1].start = ev.turnId;
			if (ev.type === "turn_end") pairs[pairs.length - 1].end = ev.turnId;
		});
		await agent.run({ userMessage: "go" });
		expect(pairs[0].start).toBeDefined();
		expect(pairs[0].end).toBe(pairs[0].start);
	});

	it("turn_end fires from the finally block even when the stream throws", async () => {
		const throwingProvider: ProviderSpec = {
			id: "throws",
			displayName: "throws",
			async *stream() {
				yield { type: "text_delta", text: "starting..." };
				throw new Error("provider exploded mid-stream");
			},
		};
		const agent = new Agent(
			{ id: "rb3", provider: throwingProvider, tools: [], host: makeHost(), mode: baseMode },
			{ modelId: "test-model" },
		);
		const endOutcomes: string[] = [];
		agent.on((ev) => {
			if (ev.type === "turn_end") endOutcomes.push(ev.outcome);
		});
		await expect(agent.run({ userMessage: "go" })).rejects.toThrow(/provider exploded/);
		// turn_end MUST have fired even though run() rejected — that's
		// the whole point of the try/finally wrapper. Outcome stays at
		// the default "error" since no completion path ran first.
		expect(endOutcomes).toEqual(["error"]);
	});
});
