// Critic battle-test driver.
//
// Loops every fixture from `critic-fixtures.ts` through `parseCritique` and a
// mocked `runCritic` provider stream, asserting the resulting verdict matches
// what the fixture documents. This is the regression guard around the critic
// parser — any change to tag/JSON handling that breaks one of these cases
// fails the suite immediately.
//
// What this DOES NOT validate: whether the critic LLM itself produces good
// judgments. That requires a real provider, which is too slow + flaky for
// CI. The opt-in `scripts/critic-eval.mjs` companion (added separately when
// we wire it) runs the same fixtures against a configured provider to
// compute precision / recall on live LLM output.

import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { parseCritique, runCritic } from "../src/critic";
import { CRITIC_BATTLE_CASES, countByCategory } from "../src/critic-fixtures";

function mockProvider(text: string): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest) {
			yield { type: "text_delta", text } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		},
	};
}

describe("critic battle-test fixtures", () => {
	it("has meaningful coverage across categories", () => {
		const counts = countByCategory();
		// We want a real mix — not just happy-path approvals.
		expect(counts.approval).toBeGreaterThanOrEqual(3);
		expect(counts.rejection).toBeGreaterThanOrEqual(3);
		expect(counts.edge).toBeGreaterThanOrEqual(3);
	});

	for (const c of CRITIC_BATTLE_CASES) {
		describe(`[${c.category}] ${c.name}`, () => {
			it("parseCritique produces the expected verdict", () => {
				const result = parseCritique(c.mockedCriticReply);
				expect(result.verdict).toBe(c.expectedVerdict);
				if (c.expectedFeedbackContains && result.verdict === "needs_retry") {
					expect(result.feedback ?? "").toContain(c.expectedFeedbackContains);
				}
			});

			it("runCritic streams the same verdict end-to-end", async () => {
				const result = await runCritic({
					provider: mockProvider(c.mockedCriticReply),
					modelId: "mock",
					userTask: c.task,
					executorSummary: c.executorSummary,
				});
				expect(result.verdict).toBe(c.expectedVerdict);
				if (c.expectedFeedbackContains && result.verdict === "needs_retry") {
					expect(result.feedback ?? "").toContain(c.expectedFeedbackContains);
				}
			});
		});
	}
});
