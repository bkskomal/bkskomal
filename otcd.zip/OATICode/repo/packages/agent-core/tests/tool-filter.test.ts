import type { ToolSpec } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { filterToolsForModel, isToolAllowedForQuirks } from "../src/tool-filter";

// Minimal ToolSpec stubs — we only care about name + requiredCapability
// for filtering, so the rest can be no-op.
function tool(name: string, requiredCapability?: ToolSpec["requiredCapability"]): ToolSpec {
	return {
		name,
		description: "",
		schema: { type: "object", properties: {} },
		approval: "auto",
		async handler() {
			return null;
		},
		...(requiredCapability ? { requiredCapability } : {}),
	};
}

describe("filterToolsForModel", () => {
	const allTools: ToolSpec[] = [
		tool("read_file"), // ungated — always allowed
		tool("write_file"), // ungated
		tool("exec"), // ungated
		tool("spawn_agent", "spawn-sub-agents"),
		tool("spawn_parallel_agents", "spawn-sub-agents"),
		tool("make_plan", "plan"),
	];

	it("keeps every tool for a frontier model (full capability set)", () => {
		const out = filterToolsForModel(allTools, "claude-opus-4-7");
		expect(out.map((t) => t.name).sort()).toEqual(
			["read_file", "write_file", "exec", "spawn_agent", "spawn_parallel_agents", "make_plan"].sort(),
		);
	});

	it("keeps spawn + plan tools for Kimi K2.6 (open-weight-large is fully capable)", () => {
		const out = filterToolsForModel(allTools, "moonshotai/kimi-k2");
		const names = out.map((t) => t.name);
		expect(names).toContain("spawn_agent");
		expect(names).toContain("spawn_parallel_agents");
		expect(names).toContain("make_plan");
	});

	it("hides spawn-sub-agents tools from small models (Gemma 2/3)", () => {
		// 2026-06-06: switched to gemma-3 — gemma-4 was promoted to
		// open-weight-large and now gets the spawn/plan tools.
		const out = filterToolsForModel(allTools, "gemma-3");
		const names = out.map((t) => t.name);
		expect(names).not.toContain("spawn_agent");
		expect(names).not.toContain("spawn_parallel_agents");
		expect(names).not.toContain("make_plan");
		// ungated tools survive
		expect(names).toContain("read_file");
		expect(names).toContain("write_file");
		expect(names).toContain("exec");
	});

	it("hides spawn-sub-agents tools from local Ollama by default", () => {
		const out = filterToolsForModel(allTools, "ollama/qwen2.5-coder:latest");
		const names = out.map((t) => t.name);
		expect(names).not.toContain("spawn_agent");
		expect(names).not.toContain("spawn_parallel_agents");
		// Local models can still rerank (cheap one-shot) but lose plan
		// + spawn.
		expect(names).not.toContain("make_plan");
	});

	it("falls through to conservative defaults for unknown models", () => {
		const out = filterToolsForModel(allTools, "totally/made-up");
		const names = out.map((t) => t.name);
		expect(names).not.toContain("spawn_agent");
		expect(names).not.toContain("make_plan");
		expect(names).toContain("read_file");
	});

	it("uses conservative defaults when modelId is undefined", () => {
		const out = filterToolsForModel(allTools, undefined);
		const names = out.map((t) => t.name);
		expect(names).not.toContain("spawn_agent");
		expect(names).toContain("read_file");
	});

	it("returns a NEW array (does not mutate the input)", () => {
		const before = allTools.length;
		const out = filterToolsForModel(allTools, "gemma-3");
		expect(allTools).toHaveLength(before); // input unchanged
		expect(out).not.toBe(allTools); // fresh reference
	});

	it("returns an empty array when input is empty (no crash)", () => {
		expect(filterToolsForModel([], "claude-sonnet-4-6")).toEqual([]);
		expect(filterToolsForModel([], undefined)).toEqual([]);
	});
});

describe("isToolAllowedForQuirks", () => {
	const fullCapsQuirks = {
		displayName: "Test full caps",
		temperature: 0.2,
		maxTokens: 4096,
		maxIterations: 25,
		needsArgFormatReminder: false,
		needsTersenessReminder: false,
		tier: "frontier" as const,
		canSpawnSubAgents: true,
		canPlan: true,
		canRerank: true,
		parallelConcurrencyCap: 5,
		preferredPipeline: "single" as const,
	};

	const restrictedQuirks = {
		...fullCapsQuirks,
		displayName: "Test restricted",
		tier: "open-weight-small" as const,
		canSpawnSubAgents: false,
		canPlan: false,
		canRerank: false,
		parallelConcurrencyCap: 1,
	};

	it("always allows tools with no requiredCapability", () => {
		expect(isToolAllowedForQuirks(tool("read"), restrictedQuirks)).toBe(true);
	});

	it("allows gated tool when the matching capability is true", () => {
		expect(isToolAllowedForQuirks(tool("spawn", "spawn-sub-agents"), fullCapsQuirks)).toBe(true);
		expect(isToolAllowedForQuirks(tool("plan", "plan"), fullCapsQuirks)).toBe(true);
	});

	it("blocks gated tool when the matching capability is false", () => {
		expect(isToolAllowedForQuirks(tool("spawn", "spawn-sub-agents"), restrictedQuirks)).toBe(false);
		expect(isToolAllowedForQuirks(tool("plan", "plan"), restrictedQuirks)).toBe(false);
	});
});
