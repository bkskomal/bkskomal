import { describe, expect, it } from "vitest";
import { tryRecoverWrappedArgs } from "../src/agent";

const WRITE_FILE_SCHEMA = {
	type: "object",
	properties: {
		path: { type: "string" },
		content: { type: "string" },
	},
	required: ["path", "content"],
} as const;

describe("tryRecoverWrappedArgs — split-absorbed-fields post-process", () => {
	it("splits a path that absorbed content via escaped JSON boundary (Kimi K2.6 case)", () => {
		// Simulate the real-world trace: args came in as a JSON-string-
		// inside-a-string where all inner quotes were escape-encoded. The
		// regex extracted everything from the start of path through the
		// end of the value because the boundary `","content":"` had its
		// quotes escaped (`\","content\":\"`) and looked like opaque chars.
		const raw = `{"_raw":"\\"{\\\\\\"path\\\\\\":\\\\\\"index.html\\\\\\",\\\\\\"content\\\\\\":\\\\\\"<!DOCTYPE html>\\\\nhello\\\\\\"}\\""}`;
		const ev = JSON.parse(raw);
		const recovered = tryRecoverWrappedArgs(ev, WRITE_FILE_SCHEMA);
		expect(recovered).toBeDefined();
		if (!recovered) return;
		expect(recovered.path).toBe("index.html");
		// Don't assert exact content shape — the recovery may leave some
		// trailing artifacts from the escaping passes. Just confirm it's
		// a reasonable HTML-ish string.
		expect(typeof recovered.content).toBe("string");
		expect((recovered.content as string).length).toBeGreaterThan(0);
		expect((recovered.content as string).length).toBeLessThan(500);
	});

	it("preserves clean already-recovered args (no false-split)", () => {
		// When recovery finds clean fields directly, post-process should NOT
		// touch them. Pass via a string raw form so the recovery's parse
		// pass handles it.
		const raw = '{"path":"src/foo.ts","content":"hello world"}';
		const recovered = tryRecoverWrappedArgs(raw, WRITE_FILE_SCHEMA);
		expect(recovered).toBeDefined();
		expect(recovered?.path).toBe("src/foo.ts");
		expect(recovered?.content).toBe("hello world");
	});

	it("does not split when path is already clean", () => {
		// Direct call would normally not go through the regex pass since
		// the JSON parses cleanly. This confirms the parse-pass branch
		// returns its result without invoking splitAbsorbedFields.
		const recovered = tryRecoverWrappedArgs(
			'{"path":"a.txt","content":"some text with no boundary patterns"}',
			WRITE_FILE_SCHEMA,
		);
		expect(recovered?.path).toBe("a.txt");
		expect(recovered?.content).toBe("some text with no boundary patterns");
	});

	it("only splits path-shaped fields (not arbitrary required fields)", () => {
		// Two-string schema where neither field is path-shaped — even if
		// the regex absorbs one into the other, splitAbsorbedFields should
		// not run. This protects legitimate search queries that happen
		// to contain JSON-ish substrings.
		const QUERY_SCHEMA = {
			type: "object",
			properties: {
				query: { type: "string" },
				source: { type: "string" },
			},
			required: ["query", "source"],
		} as const;
		const recovered = tryRecoverWrappedArgs(
			// Synthetic raw where regex would extract both cleanly already.
			'{"query":"how to use json","source":"docs"}',
			QUERY_SCHEMA,
		);
		expect(recovered?.query).toBe("how to use json");
		expect(recovered?.source).toBe("docs");
	});
});
