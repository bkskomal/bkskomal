import type {
	HostContext,
	ModeConfig,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
} from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { Conductor } from "../src/conductor";
import { ProviderRegistry } from "../src/provider-registry";
import { ToolRegistry } from "../src/tool-registry";

function makeHost(): HostContext {
	return {
		readFile: vi.fn().mockResolvedValue(""),
		writeFile: vi.fn().mockResolvedValue(undefined),
		fileExists: vi.fn().mockResolvedValue(false),
		exec: vi.fn().mockResolvedValue({ stdout: "", stderr: "", exitCode: 0 }),
		workspaceRoot: () => "/test",
		requestApproval: vi.fn().mockResolvedValue(true),
		showDiff: vi.fn().mockResolvedValue(undefined),
		log: vi.fn(),
	};
}

/**
 * Build a provider whose stream returns canned text per call. The Conductor
 * may call the same provider for planner, executor, and critic in turn, so we
 * give each call its own scripted response.
 */
function makeProvider(scripts: readonly string[]): ProviderSpec {
	let call = 0;
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			const text = scripts[call++] ?? "";
			if (text) yield { type: "text_delta", text };
			yield { type: "message_end", stopReason: "end" };
		},
	};
}

function makeRegistry(provider: ProviderSpec): ProviderRegistry {
	const r = new ProviderRegistry();
	r.register(provider);
	return r;
}

const baseMode: ModeConfig = {
	id: "test",
	displayName: "Test",
	systemPrompt: "You are an assistant.",
	enabledTools: "all",
	enablePlanner: false,
	enableCritic: false,
	maxParallelAgents: 1,
	maxIterations: 3,
};

describe("Conductor pipeline", () => {
	it("runs only the executor when neither stage is enabled (single model call)", async () => {
		const provider = makeProvider(["Hello"]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const events: string[] = [];
		conductor.on((ev) => events.push(ev.type));
		await conductor.spawn({
			mode: baseMode,
			modelId: "any",
			userMessage: "hi",
		});
		expect(events).toContain("text_delta");
		expect(events).toContain("done");
		expect(events).not.toContain("plan");
		expect(events).not.toContain("critique");
	});

	it("runs planner + executor and emits a plan event when enablePlanner=true", async () => {
		const provider = makeProvider([
			// planner response — Phase 5 (2026-06-04): conductor uses V2 schema
			`<plan-v2>{"goal":"do it","steps":[{"id":"s1","title":"Inspect","body":"Done when noted."},{"id":"s2","title":"Refactor","body":"Done when applied."},{"id":"s3","title":"Verify","body":"Done when green."}]}</plan-v2>`,
			// executor response
			"All done.",
		]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const planEvents: unknown[] = [];
		const stageEvents: Array<{ stage: string }> = [];
		conductor.on((ev) => {
			if (ev.type === "plan") planEvents.push(ev);
			else if (ev.type === "stage_started") stageEvents.push({ stage: ev.stage });
		});
		await conductor.spawn({
			mode: { ...baseMode, enablePlanner: true },
			modelId: "any",
			userMessage: "do it",
		});
		expect(planEvents).toHaveLength(1);
		const stages = stageEvents.map((s) => s.stage);
		expect(stages).toEqual(["planner", "executor"]);
	});

	it("runs executor + critic, no retry when verdict is approved", async () => {
		const provider = makeProvider([
			"Executor said this.",
			`<critique>{"verdict":"approved"}</critique>`,
		]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const critiqueEvents: Array<{ verdict: string }> = [];
		const retryEvents: unknown[] = [];
		conductor.on((ev) => {
			if (ev.type === "critique") critiqueEvents.push({ verdict: ev.critique.verdict });
			else if (ev.type === "retry") retryEvents.push(ev);
		});
		await conductor.spawn({
			mode: { ...baseMode, enableCritic: true },
			modelId: "any",
			userMessage: "go",
		});
		expect(critiqueEvents).toHaveLength(1);
		expect(critiqueEvents[0].verdict).toBe("approved");
		expect(retryEvents).toHaveLength(0);
	});

	it("retries when critic says needs_retry, then accepts on second pass", async () => {
		const provider = makeProvider([
			// 1. executor first attempt
			"First attempt — sloppy.",
			// 2. critic first pass — wants retry
			`<critique>{"verdict":"needs_retry","feedback":"clean it up"}</critique>`,
			// 3. executor second attempt
			"Second attempt — better.",
			// 4. critic second pass — approves
			`<critique>{"verdict":"approved"}</critique>`,
		]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const retryEvents: Array<{ attempt: number; reason: string }> = [];
		const critiqueVerdicts: string[] = [];
		conductor.on((ev) => {
			if (ev.type === "retry") {
				retryEvents.push({ attempt: ev.attempt, reason: ev.reason });
			} else if (ev.type === "critique") {
				critiqueVerdicts.push(ev.critique.verdict);
			}
		});
		await conductor.spawn({
			mode: { ...baseMode, enableCritic: true, maxRetries: 1 },
			modelId: "any",
			userMessage: "go",
		});
		expect(retryEvents).toHaveLength(1);
		expect(retryEvents[0].attempt).toBe(1);
		expect(retryEvents[0].reason).toContain("clean it up");
		expect(critiqueVerdicts).toEqual(["needs_retry", "approved"]);
	});

	it("respects maxRetries — stops retrying after the cap even if still failing", async () => {
		// 5 turns: executor + critic-needs-retry + executor + critic-needs-retry + executor (no more critics — we cap at maxRetries=1, so 2 executor passes total)
		// Actually flow with maxRetries=1: critic_pass1 → retry → executor → critic_pass2 → either approve or stop
		const provider = makeProvider([
			"v1",
			`<critique>{"verdict":"needs_retry","feedback":"again"}</critique>`,
			"v2",
			`<critique>{"verdict":"needs_retry","feedback":"still wrong"}</critique>`,
		]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const retries: number[] = [];
		conductor.on((ev) => {
			if (ev.type === "retry") retries.push(ev.attempt);
		});
		await conductor.spawn({
			mode: { ...baseMode, enableCritic: true, maxRetries: 1 },
			modelId: "any",
			userMessage: "go",
		});
		expect(retries).toEqual([1]); // only one retry, never a second
	});

	it("emits stage_started/stage_done in the right order for full pipeline", async () => {
		const provider = makeProvider([
			`<plan-v2>{"goal":"g","steps":[{"id":"s1","title":"a","body":"x. Done."},{"id":"s2","title":"b","body":"y. Done."},{"id":"s3","title":"c","body":"z. Done."}]}</plan-v2>`,
			"executor",
			`<critique>{"verdict":"approved"}</critique>`,
		]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const stages: Array<{ phase: "start" | "done"; stage: string }> = [];
		conductor.on((ev) => {
			if (ev.type === "stage_started") stages.push({ phase: "start", stage: ev.stage });
			else if (ev.type === "stage_done") stages.push({ phase: "done", stage: ev.stage });
		});
		await conductor.spawn({
			mode: { ...baseMode, enablePlanner: true, enableCritic: true },
			modelId: "any",
			userMessage: "go",
		});
		expect(stages).toEqual([
			{ phase: "start", stage: "planner" },
			{ phase: "done", stage: "planner" },
			{ phase: "start", stage: "executor" },
			{ phase: "done", stage: "executor" },
			{ phase: "start", stage: "critic" },
			{ phase: "done", stage: "critic" },
		]);
	});

	// R7-C regression test: cancelAll() used to just `.clear()` the active map
	// without aborting the in-flight agents, so provider streams kept
	// consuming tokens. After the fix, cancelAll() aborts the linked
	// AbortControllers and the agent observes a cancellation.
	it("cancelAll() aborts in-flight agent runs (R7-C)", async () => {
		// Build a provider whose stream awaits its signal so cancelAll can
		// observably cut it off.
		let observedAbort = false;
		const provider: ProviderSpec = {
			id: "slow",
			displayName: "slow",
			async *stream(req) {
				yield { type: "text_delta", text: "chunk1" };
				// Wait for the abort signal to fire, then exit cooperatively.
				await new Promise<void>((resolve) => {
					if (req.signal?.aborted) {
						observedAbort = true;
						resolve();
						return;
					}
					req.signal?.addEventListener(
						"abort",
						() => {
							observedAbort = true;
							resolve();
						},
						{ once: true },
					);
				});
				yield { type: "message_end", stopReason: "end" };
			},
		};
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const runPromise = conductor.spawn({
			mode: baseMode,
			modelId: "any",
			userMessage: "go",
		});
		// Yield so the executor stage starts.
		await new Promise((r) => setTimeout(r, 10));
		conductor.cancelAll();
		await runPromise;
		expect(observedAbort).toBe(true);
	});

	it("enqueueUserMessage forwards mid-turn input to every active agent", async () => {
		// Two iterations: first call hangs on a promise we resolve mid-test so
		// the conductor reports `isAnyAgentActive() === true`. While it's
		// "running", we enqueue a message. Resolving the first call lets the
		// agent finish iteration 1; iteration 2 picks the queued message off
		// the agent's drain step and the test sees it land in history.
		let resolveFirstCall: (() => void) | undefined;
		const firstCall = new Promise<void>((r) => {
			resolveFirstCall = r;
		});
		let callIdx = 0;
		const provider: ProviderSpec = {
			id: "mock",
			displayName: "mock",
			async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
				const i = callIdx++;
				if (i === 0) {
					// Iter 1: emit some text, then HANG until the test
					// releases us — gives us time to enqueue.
					yield { type: "text_delta", text: "thinking..." };
					await firstCall;
					yield { type: "message_end", stopReason: "end" };
				} else {
					// Iter 2: just close cleanly. The drain step at the top
					// of this iteration will have pushed our queued msg
					// into history already.
					yield { type: "message_end", stopReason: "end" };
				}
			},
		};
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const runPromise = conductor.spawn({
			mode: { ...baseMode, maxIterations: 2 },
			modelId: "any",
			userMessage: "start",
		});
		// Wait for the executor stage to actually be running.
		await new Promise((r) => setTimeout(r, 20));
		expect(conductor.isAnyAgentActive()).toBe(true);
		const delivered = conductor.enqueueUserMessage("interject this");
		expect(delivered).toBe(1);
		expect(conductor.hasPendingUserInput()).toBe(true);
		// Release iter 1 so iter 2 can drain + complete.
		resolveFirstCall?.();
		const history = await runPromise;
		// Expect the injected message to live in history as a user-role turn
		// (after the original "start" user message + the iter-1 assistant text).
		const injected = history.find(
			(m) =>
				m.role === "user" && m.parts.some((p) => p.kind === "text" && p.text === "interject this"),
		);
		expect(injected).toBeDefined();
		// And once the run is over, the conductor reports no active agents.
		expect(conductor.isAnyAgentActive()).toBe(false);
	});

	// 2026-05-26: parallel mid-turn route. Mirrors the enqueue test above but
	// uses `spawnParallel()` to fork a sibling agent while the primary is
	// still streaming. Both agents end up in `active` simultaneously; both
	// produce their own assistant output tagged with distinct agentIds.
	it("spawnParallel spawns a sibling agent that runs alongside the primary", async () => {
		let resolveFirstCall: (() => void) | undefined;
		const firstCall = new Promise<void>((r) => {
			resolveFirstCall = r;
		});
		let callIdx = 0;
		const provider: ProviderSpec = {
			id: "mock",
			displayName: "mock",
			async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
				const i = callIdx++;
				if (i === 0) {
					yield { type: "text_delta", text: "primary working..." };
					await firstCall;
					yield { type: "message_end", stopReason: "end" };
				} else {
					yield { type: "text_delta", text: "sibling reply" };
					yield { type: "message_end", stopReason: "end" };
				}
			},
		};
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const seenAgentIds = new Set<string>();
		conductor.on((ev) => {
			if (ev.type === "text_delta" && ev.agentId) seenAgentIds.add(ev.agentId);
		});
		const runPromise = conductor.spawn({
			mode: { ...baseMode, maxParallelAgents: 4 },
			modelId: "any",
			userMessage: "start",
		});
		await new Promise((r) => setTimeout(r, 20));
		expect(conductor.isAnyAgentActive()).toBe(true);

		const { agentId: parallelId } = conductor.spawnParallel({
			mode: { ...baseMode, maxParallelAgents: 4 },
			modelId: "any",
			userMessage: "second task",
		});
		expect(parallelId.startsWith("p")).toBe(true);

		// Give the sibling a tick to actually start streaming.
		await new Promise((r) => setTimeout(r, 30));
		resolveFirstCall?.();
		await runPromise;
		// Both agents emitted text_delta events.
		expect(seenAgentIds.size).toBeGreaterThanOrEqual(2);
		expect(conductor.isAnyAgentActive()).toBe(false);
	});
});
