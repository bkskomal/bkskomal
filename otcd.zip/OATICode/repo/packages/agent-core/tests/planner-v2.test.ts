// R6-A: Structured Plan v2 — planner + executor tests.

import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { Conductor } from "../src/conductor";
import {
	executePlan,
	parsePlanV2,
	planRequest,
	planV2ToPromptSection,
	topoSort,
} from "../src/planner-v2";
import { ProviderRegistry } from "../src/provider-registry";
import { ToolRegistry } from "../src/tool-registry";

function streamOf(text: string): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest) {
			yield { type: "text_delta", text } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		},
	};
}

function streamForRequest(map: (req: ProviderRequest) => string): ProviderSpec {
	return {
		id: "mock-dynamic",
		displayName: "mock-dynamic",
		async *stream(req: ProviderRequest) {
			const text = map(req);
			yield { type: "text_delta", text } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		},
	};
}

const FIXED_NOW = () => new Date("2026-05-21T00:00:00.000Z");
const FIXED_ID = () => "plan_fixed";

describe("parsePlanV2", () => {
	it("extracts a valid 3-step plan", () => {
		const raw = `<plan-v2>${JSON.stringify({
			goal: "Refactor X",
			steps: [
				{ id: "s1", title: "Read", body: "Read foo.ts. Done when listed." },
				{ id: "s2", title: "Edit", body: "Apply rename. Done when tests pass.", dependsOn: ["s1"] },
				{ id: "s3", title: "Verify", body: "Run tests. Done when green.", dependsOn: ["s2"] },
			],
		})}</plan-v2>`;
		const plan = parsePlanV2(raw, { makeId: FIXED_ID, now: FIXED_NOW });
		expect(plan.id).toBe("plan_fixed");
		expect(plan.goal).toBe("Refactor X");
		expect(plan.steps).toHaveLength(3);
		expect(plan.steps[1].dependsOn).toEqual(["s1"]);
		expect(plan.steps[0].status).toBe("pending");
		expect(plan.state).toBe("draft");
	});

	it("returns an empty plan when the tag is missing", () => {
		const out = parsePlanV2("no tag", { makeId: FIXED_ID, now: FIXED_NOW });
		expect(out.steps).toEqual([]);
	});

	it("returns an empty plan when JSON is malformed", () => {
		const out = parsePlanV2("<plan-v2>{nope}</plan-v2>", { makeId: FIXED_ID, now: FIXED_NOW });
		expect(out.steps).toEqual([]);
	});

	it("drops steps missing title or body", () => {
		const raw = `<plan-v2>${JSON.stringify({
			goal: "g",
			steps: [
				{ id: "s1", title: "", body: "x" },
				{ id: "s2", title: "ok", body: "yes" },
			],
		})}</plan-v2>`;
		const out = parsePlanV2(raw, { makeId: FIXED_ID, now: FIXED_NOW });
		expect(out.steps).toHaveLength(1);
		expect(out.steps[0].id).toBe("s2");
	});

	it("assigns missing step ids", () => {
		const raw = `<plan-v2>${JSON.stringify({
			goal: "g",
			steps: [
				{ title: "a", body: "b1" },
				{ title: "c", body: "b2" },
			],
		})}</plan-v2>`;
		const out = parsePlanV2(raw, { makeId: FIXED_ID, now: FIXED_NOW });
		expect(out.steps.map((s) => s.id)).toEqual(["s1", "s2"]);
	});
});

describe("topoSort", () => {
	it("orders steps respecting dependsOn", () => {
		const out = topoSort([
			{ id: "s2", title: "B", body: "b", status: "pending", dependsOn: ["s1"] },
			{ id: "s1", title: "A", body: "a", status: "pending" },
			{ id: "s3", title: "C", body: "c", status: "pending", dependsOn: ["s2"] },
		]);
		expect(out.map((s) => s.id)).toEqual(["s1", "s2", "s3"]);
	});

	it("falls back to insertion order on cycles", () => {
		const out = topoSort([
			{ id: "s1", title: "A", body: "a", status: "pending", dependsOn: ["s2"] },
			{ id: "s2", title: "B", body: "b", status: "pending", dependsOn: ["s1"] },
		]);
		expect(out.map((s) => s.id).sort()).toEqual(["s1", "s2"]);
	});
});

describe("planRequest", () => {
	it("returns a plan on a well-formed response", async () => {
		const valid = `<plan-v2>${JSON.stringify({
			goal: "Do work",
			steps: [
				{ id: "s1", title: "Read", body: "Read. Done when done." },
				{ id: "s2", title: "Write", body: "Write. Done when written." },
				{ id: "s3", title: "Test", body: "Test. Done when green." },
			],
		})}</plan-v2>`;
		const provider = streamOf(valid);
		const plan = await planRequest({
			provider,
			modelId: "any",
			userTask: "x",
			disableRetry: true,
			makeId: FIXED_ID,
			now: FIXED_NOW,
		});
		expect(plan.steps).toHaveLength(3);
		expect(plan.goal).toBe("Do work");
	});

	it("returns a single-step fallback when the response is unparseable AND retry disabled", async () => {
		const provider = streamOf("garbage");
		const plan = await planRequest({
			provider,
			modelId: "any",
			userTask: "task",
			disableRetry: true,
			makeId: FIXED_ID,
			now: FIXED_NOW,
		});
		expect(plan.steps).toEqual([]);
	});

	it("falls back to a placeholder step when both attempts return nothing parseable", async () => {
		const provider = streamOf("not a plan");
		const plan = await planRequest({
			provider,
			modelId: "any",
			userTask: "do something",
			makeId: FIXED_ID,
			now: FIXED_NOW,
		});
		expect(plan.steps).toHaveLength(1);
		expect(plan.steps[0].title).toBe("Address the request");
	});
});

describe("executePlan", () => {
	it("walks steps in topological order and marks them done", async () => {
		const provider = streamForRequest(() => "assistant reply");
		const conductor = new Conductor({
			providers: ((): ProviderRegistry => {
				const r = new ProviderRegistry();
				r.register(provider);
				return r;
			})(),
			tools: new ToolRegistry(),
			host: makeStubHost(),
		});

		const plan = {
			id: "plan1",
			goal: "g",
			steps: [
				{ id: "s2", title: "B", body: "Done when ok", status: "pending" as const, dependsOn: ["s1"] },
				{ id: "s1", title: "A", body: "Done when ok", status: "pending" as const },
			],
			createdAt: "2026-05-21T00:00:00Z",
			state: "draft" as const,
		};
		const order: string[] = [];
		const result = await executePlan(plan, {
			conductor,
			mode: stubMode(),
			modelId: "any",
			provider,
			critic: async () => ({ ok: true, reason: "ok" }),
			onStepStatus: (id, status) => {
				if (status === "done") order.push(id);
			},
		});
		expect(order).toEqual(["s1", "s2"]);
		expect(result.status).toBe("completed");
	});

	it("retries once when the critic says No, then marks done if the retry passes", async () => {
		const provider = streamForRequest(() => "reply");
		const conductor = new Conductor({
			providers: ((): ProviderRegistry => {
				const r = new ProviderRegistry();
				r.register(provider);
				return r;
			})(),
			tools: new ToolRegistry(),
			host: makeStubHost(),
		});

		let n = 0;
		const result = await executePlan(
			{
				id: "p",
				goal: "g",
				steps: [{ id: "s1", title: "X", body: "Done when ok", status: "pending" }],
				createdAt: "t",
				state: "draft",
			},
			{
				conductor,
				mode: stubMode(),
				modelId: "any",
				provider,
				critic: async () => {
					n++;
					return n === 1 ? { ok: false, reason: "missing" } : { ok: true, reason: "now ok" };
				},
			},
		);
		expect(result.status).toBe("completed");
		expect(result.plan.steps[0].status).toBe("done");
		expect(n).toBe(2);
	});

	it("stops on a critic-rejected step when continueOnFailure is off", async () => {
		const provider = streamForRequest(() => "reply");
		const conductor = new Conductor({
			providers: ((): ProviderRegistry => {
				const r = new ProviderRegistry();
				r.register(provider);
				return r;
			})(),
			tools: new ToolRegistry(),
			host: makeStubHost(),
		});

		const result = await executePlan(
			{
				id: "p",
				goal: "g",
				steps: [
					{ id: "s1", title: "X", body: "Done when impossible", status: "pending" },
					{ id: "s2", title: "Y", body: "Done when ok", status: "pending" },
				],
				createdAt: "t",
				state: "draft",
			},
			{
				conductor,
				mode: stubMode(),
				modelId: "any",
				provider,
				critic: async () => ({ ok: false, reason: "no" }),
			},
		);
		expect(result.status).toBe("failed");
		expect(result.plan.steps[0].status).toBe("failed");
		expect(result.plan.steps[1].status).toBe("pending");
	});
});

function stubMode() {
	return {
		id: "stub",
		displayName: "stub",
		systemPrompt: "system",
		enabledTools: [] as const,
		enablePlanner: false,
		enableCritic: false,
		maxParallelAgents: 4,
		maxIterations: 4,
	};
}

describe("planV2ToPromptSection (Phase 5)", () => {
	it("emits an empty string for a plan with no steps", () => {
		expect(
			planV2ToPromptSection({
				id: "p1",
				goal: "g",
				steps: [],
				createdAt: "2026-06-04T00:00:00.000Z",
				state: "draft",
			}),
		).toBe("");
	});

	it("renders goal + title-only step lines (no rationale tail like the legacy schema)", () => {
		const out = planV2ToPromptSection({
			id: "p1",
			goal: "Migrate auth to OIDC",
			createdAt: "2026-06-04T00:00:00.000Z",
			state: "draft",
			steps: [
				{
					id: "s1",
					title: "Read the current auth flow",
					body: "Inspect auth.ts.\nDone when exports are listed.",
					status: "pending",
				},
				{
					id: "s2",
					title: "Swap the middleware",
					body: "Apply the rename.",
					status: "pending",
				},
			],
		});
		expect(out).toContain("Goal: Migrate auth to OIDC");
		expect(out).toContain("- Read the current auth flow: Inspect auth.ts.");
		expect(out).toContain("- Swap the middleware: Apply the rename.");
		// Acceptance criterion stays in the body but the prompt section only
		// surfaces the first line — keeps the executor prompt compact.
		expect(out).not.toContain("Done when exports are listed.");
	});
});

function makeStubHost() {
	return {
		readFile: async () => "",
		writeFile: async () => undefined,
		fileExists: async () => false,
		exec: async () => ({ stdout: "", stderr: "", exitCode: 0 }),
		workspaceRoot: () => undefined,
		requestApproval: async () => true,
		showDiff: async () => undefined,
		log: () => undefined,
	} as const;
}
