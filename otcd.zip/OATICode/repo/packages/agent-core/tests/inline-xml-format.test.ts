import type { JsonSchemaProperty, ToolSpec } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { buildInlineXmlToolDescription, buildInlineXmlToolPrompt } from "../src/inline-xml-format";

// Minimal ToolSpec builder — only the fields the formatter reads.
function makeTool(
	name: string,
	description: string,
	properties: Record<string, JsonSchemaProperty> = {},
	overrides: Partial<ToolSpec> = {},
): ToolSpec {
	return {
		name,
		description,
		schema: { type: "object", properties },
		approval: "auto",
		async handler() {
			return null;
		},
		...overrides,
	};
}

const readFile = makeTool("read_file", "Read the contents of a file in the workspace.", {
	path: { type: "string", description: "Path to the file" },
});

const writeFile = makeTool("write_file", "Write file contents (creates or overwrites).", {
	path: { type: "string" },
	content: { type: "string" },
});

const exec = makeTool("exec", "Run a shell command and return stdout / stderr / exit code.", {
	command: { type: "string" },
});

describe("buildInlineXmlToolPrompt", () => {
	it("returns just the header + rules section when given no tools", () => {
		const out = buildInlineXmlToolPrompt([]);
		expect(out).toContain("## Tool use (inline XML format)");
		expect(out).toContain("### Format rules");
		expect(out).toContain("### Available tools");
		// No tool blocks.
		expect(out).not.toContain("####");
		expect(out.endsWith("\n")).toBe(true);
	});

	it("renders a single simple tool with its example call", () => {
		const out = buildInlineXmlToolPrompt([readFile]);
		expect(out).toContain("#### read_file");
		expect(out).toContain("Read the contents of a file in the workspace.");
		expect(out).toContain("<read_file>");
		expect(out).toContain("<path>relative/or/absolute/path/to/file</path>");
		expect(out).toContain("</read_file>");
	});

	it("preserves a multi-line description verbatim", () => {
		const multi = makeTool(
			"do_thing",
			"First line of the description.\nSecond line with detail.\nThird line.",
			{ path: { type: "string" } },
		);
		const out = buildInlineXmlToolPrompt([multi]);
		expect(out).toContain("First line of the description.");
		expect(out).toContain("Second line with detail.");
		expect(out).toContain("Third line.");
		// The three lines stay adjacent.
		expect(out).toMatch(/First line of the description\.\nSecond line with detail\.\nThird line\./);
	});

	it("renders multi-line placeholder for a `content` field", () => {
		const out = buildInlineXmlToolPrompt([writeFile]);
		expect(out).toContain(
			"<content>\nthe full new contents of the file\nmultiple lines are fine\n</content>",
		);
	});

	it("renders the command placeholder for a `command` field", () => {
		const out = buildInlineXmlToolPrompt([exec]);
		expect(out).toContain("<command>the shell command to run</command>");
	});

	it("omits sub-agent-scoped tools from the output", () => {
		const subAgentOnly = makeTool(
			"sub_only",
			"Only visible to sub-agents.",
			{ path: { type: "string" } },
			{ scope: "sub-agent" },
		);
		const out = buildInlineXmlToolPrompt([readFile, subAgentOnly, exec]);
		expect(out).toContain("#### read_file");
		expect(out).toContain("#### exec");
		expect(out).not.toContain("#### sub_only");
		expect(out).not.toContain("<sub_only>");
	});

	it("always ends with a newline", () => {
		expect(buildInlineXmlToolPrompt([]).endsWith("\n")).toBe(true);
		expect(buildInlineXmlToolPrompt([readFile]).endsWith("\n")).toBe(true);
		expect(buildInlineXmlToolPrompt([readFile, writeFile, exec]).endsWith("\n")).toBe(true);
	});

	it("renders a tool with no properties as <name></name>", () => {
		const ping = makeTool("ping", "Health check.");
		const out = buildInlineXmlToolPrompt([ping]);
		expect(out).toContain("<ping></ping>");
	});
});

describe("buildInlineXmlToolDescription", () => {
	it("returns just the single tool block, no header", () => {
		const block = buildInlineXmlToolDescription(readFile);
		expect(block).not.toContain("## Tool use");
		expect(block).not.toContain("### Format rules");
		expect(block).not.toContain("### Available tools");
		expect(block).toContain("#### read_file");
		expect(block).toContain("Read the contents of a file in the workspace.");
		expect(block).toContain("<read_file>");
		expect(block).toContain("<path>relative/or/absolute/path/to/file</path>");
		expect(block).toContain("</read_file>");
		expect(block.endsWith("\n")).toBe(true);
	});

	it("trims trailing whitespace on each description line", () => {
		const trailing = makeTool("trail", "line one   \nline two\t\nline three", {});
		const block = buildInlineXmlToolDescription(trailing);
		expect(block).toContain("line one\nline two\nline three");
		expect(block).not.toMatch(/line one {3}/);
	});
});
