// 2026-05-30: tests for the post-tool image-injection pipeline.
//
// Tool results that carry an image (browser_screenshot's dataUrl,
// extract_image_text's dataUrl passthrough, future image-producing
// tools) get auto-injected as a synthetic user message containing an
// ImagePart so vision-capable models can actually SEE the image on
// the next turn. The image content lives inside a tool role in
// history, which neither OpenAI nor Anthropic envelopes render as a
// multimodal block — only user role ImageParts get packed properly.
//
// Gated on the active model's `supportsVision` flag from model-quirks.

import type { ProviderRequest, ProviderSpec, ProviderStreamEvent, ToolSpec } from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { Agent, collectImageInjections } from "../src/agent";

function makeProvider(turns: ProviderStreamEvent[][]): ProviderSpec {
	let i = 0;
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest) {
			const events = turns[i++] ?? [];
			for (const ev of events) yield ev;
		},
	};
}

function makeHost() {
	return {
		async readFile() {
			return "";
		},
		async writeFile() {},
		async fileExists() {
			return false;
		},
		async exec() {
			return { stdout: "", stderr: "", exitCode: 0 };
		},
		workspaceRoot() {
			return "/work";
		},
		async requestApproval() {
			return true;
		},
		async showDiff() {},
		log() {},
	};
}

const baseMode = {
	id: "default",
	displayName: "Default",
	systemPrompt: "test",
	temperature: 0.2,
	maxIterations: 5,
	enablePlanner: false,
	enableCritic: false,
	allowAskUser: true,
} as const;

const TINY_PNG_DATA_URL =
	"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";

describe("collectImageInjections", () => {
	it("extracts ImagePart from a tool_result whose output is { dataUrl: 'data:image/...;base64,...' }", () => {
		const results = [
			{
				kind: "tool_result" as const,
				id: "tc1",
				output: { dataUrl: TINY_PNG_DATA_URL, downscaled: false },
				isError: false,
			},
		];
		const out = collectImageInjections(results);
		expect(out).toHaveLength(1);
		expect(out[0]).toEqual({
			kind: "image",
			mimeType: "image/png",
			dataUrl: TINY_PNG_DATA_URL,
		});
	});

	it("skips tool results that errored", () => {
		const results = [
			{
				kind: "tool_result" as const,
				id: "tc1",
				output: { dataUrl: TINY_PNG_DATA_URL },
				isError: true,
			},
		];
		expect(collectImageInjections(results)).toHaveLength(0);
	});

	it("skips tool results whose output is a plain string", () => {
		const results = [
			{ kind: "tool_result" as const, id: "tc1", output: "wrote file", isError: false },
		];
		expect(collectImageInjections(results)).toHaveLength(0);
	});

	it("skips tool results whose output object lacks a dataUrl field", () => {
		const results = [
			{
				kind: "tool_result" as const,
				id: "tc1",
				output: { pageText: "hello", downscaled: false },
				isError: false,
			},
		];
		expect(collectImageInjections(results)).toHaveLength(0);
	});

	it("skips dataUrls that aren't image MIME types (e.g. application/pdf)", () => {
		const results = [
			{
				kind: "tool_result" as const,
				id: "tc1",
				output: { dataUrl: "data:application/pdf;base64,abcd" },
				isError: false,
			},
		];
		expect(collectImageInjections(results)).toHaveLength(0);
	});

	it("extracts multiple images from a batch of tool results", () => {
		const results = [
			{
				kind: "tool_result" as const,
				id: "a",
				output: { dataUrl: TINY_PNG_DATA_URL },
				isError: false,
			},
			{ kind: "tool_result" as const, id: "b", output: "no image", isError: false },
			{
				kind: "tool_result" as const,
				id: "c",
				output: { dataUrl: "data:image/jpeg;base64,xyz" },
				isError: false,
			},
		];
		const out = collectImageInjections(results);
		expect(out).toHaveLength(2);
		expect(out[0]).toMatchObject({ mimeType: "image/png" });
		expect(out[1]).toMatchObject({ mimeType: "image/jpeg" });
	});
});

describe("Agent — image-bearing tool results inject a follow-up user message", () => {
	const screenshotTool: ToolSpec = {
		name: "browser_screenshot",
		description: "screenshot",
		schema: { type: "object", properties: {} },
		approval: "auto",
		async handler() {
			return { dataUrl: TINY_PNG_DATA_URL, downscaled: false };
		},
	};

	it("injects a user message with ImagePart when active model is vision-capable", async () => {
		// claude-sonnet-4-6 has supportsVision: true in model-quirks.
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "browser_screenshot", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "I can see the page." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{
				id: "vision-test",
				provider,
				tools: [screenshotTool],
				host: makeHost() as never,
				mode: baseMode,
			},
			{ modelId: "claude-sonnet-4-6" },
		);
		await agent.run({ userMessage: "take a screenshot" });
		const history = agent.getHistory();
		// Find the synthetic user message — it has both a text part and an
		// image part, distinguishing it from the original user prompt.
		const synth = history.find(
			(m) =>
				m.role === "user" &&
				m.parts.some((p) => p.kind === "image") &&
				m.parts.some((p) => p.kind === "text"),
		);
		expect(synth).toBeDefined();
		const imagePart = synth?.parts.find((p) => p.kind === "image");
		expect(imagePart).toMatchObject({
			kind: "image",
			mimeType: "image/png",
			dataUrl: TINY_PNG_DATA_URL,
		});
		const textPart = synth?.parts.find((p) => p.kind === "text") as { text: string } | undefined;
		expect(textPart?.text).toMatch(/inlined.*image.*natively/i);
	});

	it("does NOT inject when active model is text-only (pageText handles it instead)", async () => {
		// 2026-05-29 lookup: deepseek-coder is text-only in model-quirks.
		// Pick any non-vision pattern; here use ollama which is text by default.
		const provider = makeProvider([
			[
				{ type: "tool_call", id: "tc1", name: "browser_screenshot", args: {} },
				{ type: "message_end", stopReason: "tool_use" },
			],
			[
				{ type: "text_delta", text: "I noted the page." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const agent = new Agent(
			{
				id: "text-test",
				provider,
				tools: [screenshotTool],
				host: makeHost() as never,
				mode: baseMode,
			},
			{ modelId: "ollama/llama3" },
		);
		await agent.run({ userMessage: "take a screenshot" });
		const history = agent.getHistory();
		const synth = history.find((m) => m.role === "user" && m.parts.some((p) => p.kind === "image"));
		expect(synth).toBeUndefined();
	});
});
