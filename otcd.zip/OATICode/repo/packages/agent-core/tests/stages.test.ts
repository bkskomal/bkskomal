import type { ModeConfig } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { applyStagesToSystemPrompt } from "../src/stages";

const baseMode: ModeConfig = {
	id: "test",
	displayName: "Test",
	systemPrompt: "You are a coding assistant.",
	enabledTools: "all",
	enablePlanner: false,
	enableCritic: false,
	maxParallelAgents: 1,
	maxIterations: 5,
};

describe("applyStagesToSystemPrompt (deprecated shim)", () => {
	it("is now a no-op — pipelining moved into the Conductor", () => {
		expect(applyStagesToSystemPrompt(baseMode)).toBe(baseMode);
	});

	it("ignores enablePlanner flag (does not mutate the prompt)", () => {
		const mode: ModeConfig = { ...baseMode, enablePlanner: true };
		expect(applyStagesToSystemPrompt(mode).systemPrompt).toBe(mode.systemPrompt);
	});

	it("ignores enableCritic flag (does not mutate the prompt)", () => {
		const mode: ModeConfig = { ...baseMode, enableCritic: true };
		expect(applyStagesToSystemPrompt(mode).systemPrompt).toBe(mode.systemPrompt);
	});
});
