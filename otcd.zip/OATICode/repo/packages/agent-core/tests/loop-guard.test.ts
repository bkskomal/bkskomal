import { describe, expect, it } from "vitest";
import { detectRunawayRepetition, detectStuckPattern } from "../src/agent";

describe("detectRunawayRepetition", () => {
	it("returns undefined for short text", () => {
		expect(detectRunawayRepetition(["hi"])).toBeUndefined();
		expect(detectRunawayRepetition(["hello there"])).toBeUndefined();
	});

	it("returns undefined for a normal varied stream", () => {
		const chunks = [
			"Let me check the file.\n",
			"Reading src/foo.ts now...\n",
			"That looks correct.\n",
			"Now I'll inspect src/bar.ts to see the related logic.\n",
			"This function calls foo() and returns the result.\n",
			"Everything seems consistent so far.\n",
		];
		expect(detectRunawayRepetition(chunks)).toBeUndefined();
	});

	it("trips when the same line is emitted back-to-back many times", () => {
		const line = "Let me verify the files were written correctly:";
		const chunks: string[] = [];
		for (let i = 0; i < 10; i++) chunks.push(`${line}\n`);
		const reason = detectRunawayRepetition(chunks);
		expect(reason).toBeDefined();
		expect(reason).toMatch(/same line repeated/);
	});

	it("does NOT trip when a line repeats only a few times", () => {
		const chunks = [
			"Step one done.\n",
			"Step one done.\n",
			"Different progress now — moving on.\n",
			"Working on step two.\n",
			"Another distinct line here.\n",
		];
		expect(detectRunawayRepetition(chunks)).toBeUndefined();
	});

	it("trips on a repeated short phrase even without newlines", () => {
		const phrase = "Verifying the files are written correctly to disk now please wait...";
		const chunks: string[] = [];
		for (let i = 0; i < 8; i++) chunks.push(phrase);
		expect(detectRunawayRepetition(chunks)).toBeDefined();
	});

	it("ignores empty strings", () => {
		expect(detectRunawayRepetition([])).toBeUndefined();
		expect(detectRunawayRepetition([""])).toBeUndefined();
	});
});

describe("detectStuckPattern", () => {
	it("returns undefined under the 3-call minimum", () => {
		expect(detectStuckPattern([])).toBeUndefined();
		expect(detectStuckPattern(["read_file::a"])).toBeUndefined();
		expect(detectStuckPattern(["read_file::a", "read_file::a"])).toBeUndefined();
	});

	it("trips when the last 3 calls are byte-identical", () => {
		const hit = detectStuckPattern(["read_file::x", "read_file::x", "read_file::x"]);
		expect(hit?.reason).toMatch(/identically 3× in a row/);
	});

	it("trips when one fingerprint repeats 3+ times in the last 6 (interleaved)", () => {
		const fps = [
			"read_file::a",
			"list_dir::b",
			"read_file::a",
			"exec::c",
			"read_file::a",
			"list_dir::d",
		];
		const hit = detectStuckPattern(fps);
		expect(hit?.reason).toMatch(/identical args 3×/);
	});

	// === Pattern 3: tool monoculture, fingerprint-diversity aware ===========

	it("does NOT trip on legitimate batch progress (5 distinct write_file calls)", () => {
		// The scaffolding regression from 2026-05-29: model scaffolds a project
		// by writing 5 different files in a row. Tool name dominates the window
		// but every call has unique args — that's progress, not a stall.
		const fps = [
			"write_file::package.json",
			"write_file::vite.config.ts",
			"write_file::tailwind.config.js",
			"write_file::tsconfig.json",
			"write_file::postcss.config.js",
		];
		expect(detectStuckPattern(fps)).toBeUndefined();
	});

	it("does NOT trip when 6 distinct write_file calls dominate the window", () => {
		const fps = [
			"write_file::a",
			"write_file::b",
			"write_file::c",
			"write_file::d",
			"write_file::e",
			"write_file::f",
		];
		expect(detectStuckPattern(fps)).toBeUndefined();
	});

	it("trips when the dominating tool keeps retrying the same args", () => {
		// Model retrying the same write_file with one small variant repeatedly.
		// Pattern 2 (same fingerprint 3+ times) catches this before pattern 3
		// gets a chance — what matters is that SOMETHING fires and the message
		// names the offending tool.
		const fps = ["write_file::a", "write_file::a", "write_file::a", "write_file::a", "write_file::b"];
		const hit = detectStuckPattern(fps);
		expect(hit).toBeDefined();
		expect(hit?.reason).toMatch(/write_file/);
	});

	it("trips on a pure single-fingerprint retry storm", () => {
		const fps = Array.from({ length: 6 }, () => "read_file::missing.ts");
		// Pattern 1 (consecutive identical) fires first, but the message still
		// surfaces the right tool name — what matters is the model gets nudged.
		const hit = detectStuckPattern(fps);
		expect(hit).toBeDefined();
		expect(hit?.reason).toMatch(/read_file/);
	});
});
