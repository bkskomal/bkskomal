// 2026-05-30: fix-intent-without-mutation detector unit tests.
//
// The runtime branch in the agent loop is exercised end-to-end in
// agent.test.ts; this file pins the pure helpers (`isFixIntent` and
// `countMutationsThisTurn`) so a future regex tweak can't silently
// regress the trigger surface.

import type { ConversationMessage } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { countMutationsThisTurn, countRelevantMutationsThisTurn, isFixIntent } from "../src/agent";

describe("isFixIntent", () => {
	it("returns false for empty / non-string inputs", () => {
		expect(isFixIntent("")).toBe(false);
		expect(isFixIntent(null as unknown as string)).toBe(false);
		expect(isFixIntent(undefined as unknown as string)).toBe(false);
	});

	it("matches direct fix verbs", () => {
		expect(isFixIntent("fix this bug")).toBe(true);
		expect(isFixIntent("please repair the build")).toBe(true);
		expect(isFixIntent("can you debug the login flow")).toBe(true);
		expect(isFixIntent("patch the security hole")).toBe(true);
		expect(isFixIntent("resolve the failing tests")).toBe(true);
		expect(isFixIntent("correct the typo in README")).toBe(true);
		expect(isFixIntent("address the lint warning")).toBe(true);
		expect(isFixIntent("sort out the css layout")).toBe(true);
	});

	it("matches stative descriptions of brokenness", () => {
		expect(isFixIntent("the page is broken")).toBe(true);
		expect(isFixIntent("dark mode is not working")).toBe(true);
		expect(isFixIntent("the button doesn't work")).toBe(true);
		expect(isFixIntent("it doesn't work on Safari")).toBe(true);
		expect(isFixIntent("the form isn't working")).toBe(true);
		expect(isFixIntent("login won't work")).toBe(true);
		expect(isFixIntent("CI is failing again")).toBe(true);
		expect(isFixIntent("there's a bug in pagination")).toBe(true);
		expect(isFixIntent("the buggy reducer keeps re-rendering")).toBe(true);
	});

	it("matches 'make it work' / 'get this working' imperatives", () => {
		expect(isFixIntent("make it work on mobile")).toBe(true);
		expect(isFixIntent("make this work properly")).toBe(true);
		expect(isFixIntent("get the build working again")).toBe(true);
		expect(isFixIntent("get this to work with the new API")).toBe(true);
	});

	it("is case-insensitive", () => {
		expect(isFixIntent("FIX THIS")).toBe(true);
		expect(isFixIntent("Repair The Build")).toBe(true);
		expect(isFixIntent("BROKEN page")).toBe(true);
	});

	it("returns false for non-fix prompts", () => {
		expect(isFixIntent("add a new page for settings")).toBe(false);
		expect(isFixIntent("explain how the auth flow works")).toBe(false);
		expect(isFixIntent("what does this function do")).toBe(false);
		expect(isFixIntent("list the files in src/")).toBe(false);
		expect(isFixIntent("write a unit test for the parser")).toBe(false);
		// "work" alone without the make/get qualifier shouldn't trigger.
		expect(isFixIntent("walk me through the architecture")).toBe(false);
	});
});

describe("countMutationsThisTurn", () => {
	function mkAssistant(toolNames: readonly string[]): ConversationMessage {
		return {
			role: "assistant",
			parts: toolNames.map((name, i) => ({
				kind: "tool_call",
				id: `tc_${i}`,
				name,
				args: {},
			})),
		};
	}
	function mkUser(text: string): ConversationMessage {
		return { role: "user", parts: [{ kind: "text", text }] };
	}

	it("returns 0 for empty history", () => {
		expect(countMutationsThisTurn([])).toBe(0);
	});

	it("returns 0 when the turn used only read-only tools", () => {
		const history: ConversationMessage[] = [
			mkUser("fix this"),
			mkAssistant(["read_file", "list_dir", "grep_search", "browser_open"]),
		];
		expect(countMutationsThisTurn(history)).toBe(0);
	});

	it("counts each write_file / batch_file_edit / smart_apply_patch", () => {
		const history: ConversationMessage[] = [
			mkUser("scaffold the app"),
			mkAssistant(["write_file", "write_file", "batch_file_edit", "smart_apply_patch"]),
		];
		expect(countMutationsThisTurn(history)).toBe(4);
	});

	it("scopes to the current turn only (ignores tool calls before the last user message)", () => {
		const history: ConversationMessage[] = [
			mkUser("first turn"),
			mkAssistant(["write_file", "write_file"]),
			mkUser("second turn — fix something"),
			mkAssistant(["read_file"]),
		];
		// The current turn started with "second turn..."; only the read_file
		// after it counts. The two write_files were a prior turn.
		expect(countMutationsThisTurn(history)).toBe(0);
	});

	it("counts notebook-cell edits as mutations", () => {
		const history: ConversationMessage[] = [
			mkUser("update the notebook"),
			mkAssistant(["edit_notebook_cell", "insert_notebook_cell", "delete_notebook_cell"]),
		];
		expect(countMutationsThisTurn(history)).toBe(3);
	});

	it("handles multiple assistant messages in one turn", () => {
		const history: ConversationMessage[] = [
			mkUser("fix the build"),
			mkAssistant(["read_file"]),
			{ role: "tool", parts: [{ kind: "tool_result", id: "x", output: "ok", isError: false }] },
			mkAssistant(["write_file"]),
		];
		expect(countMutationsThisTurn(history)).toBe(1);
	});
});

describe("countRelevantMutationsThisTurn", () => {
	function mkUser(text: string): ConversationMessage {
		return { role: "user", parts: [{ kind: "text", text }] };
	}
	function mkCall(name: string, args: Record<string, unknown>): ConversationMessage {
		return {
			role: "assistant",
			parts: [{ kind: "tool_call", id: `tc_${name}`, name, args }],
		};
	}

	it("counts a mutation that touches a file explicitly named in the prompt", () => {
		const history: ConversationMessage[] = [
			mkUser("fix the css in index.html"),
			mkCall("write_file", { path: "index.html", content: "<html>...</html>" }),
		];
		expect(countRelevantMutationsThisTurn(history, "fix the css in index.html")).toBe(1);
	});

	it("ignores writes to unrelated helper files when the user named a specific file", () => {
		// The exact live-trace failure: user said fix index.html, agent
		// wrote serve.py twice and called it done. With the relevance
		// filter, those writes don't count — the detector should still
		// fire its "you didn't actually fix it" nudge.
		const history: ConversationMessage[] = [
			mkUser("fix the css issue in index.html — path: E:/proj/index.html"),
			mkCall("write_file", { path: "serve.py", content: "..." }),
			mkCall("write_file", { path: "serve.py", content: "..." }),
		];
		expect(
			countRelevantMutationsThisTurn(
				history,
				"fix the css issue in index.html — path: E:/proj/index.html",
			),
		).toBe(0);
	});

	it("treats files the agent READ this turn as relevant — but ONLY when the prompt named no paths", () => {
		// User said only "fix this"; agent explored, read styles.css, then
		// rewrote it. The write should count because the file was in scope.
		const history: ConversationMessage[] = [
			mkUser("fix this"),
			mkCall("read_file", { path: "styles.css" }),
			mkCall("write_file", { path: "styles.css", content: "/* fixed */" }),
		];
		expect(countRelevantMutationsThisTurn(history, "fix this")).toBe(1);
	});

	it("strict hierarchy: prompt paths OVERRIDE read paths — write to a read-but-irrelevant helper doesn't count", () => {
		// 2026-05-30 follow-up: this is the EXACT failure from the live trace.
		// User said "fix index.html"; agent read serve.py and wrote it back.
		// Pre-fix, the union of {index.html, serve.py} as relevance made
		// the serve.py write satisfy the detector. Strict hierarchy now
		// scopes relevance to ONLY the prompt's paths when present.
		const history: ConversationMessage[] = [
			mkUser("fix the css in index.html"),
			mkCall("read_file", { path: "serve.py" }),
			mkCall("write_file", { path: "serve.py", content: "..." }),
		];
		expect(countRelevantMutationsThisTurn(history, "fix the css in index.html")).toBe(0);
	});

	it("falls back to counting any mutation when no relevant set can be inferred", () => {
		// User gave no path AND the agent didn't read anything. Counting
		// any write avoids false-positive nudges when the model writes a
		// reasonable file based on prompt context alone.
		const history: ConversationMessage[] = [
			mkUser("scaffold a healthcheck endpoint"),
			mkCall("write_file", { path: "src/healthz.ts", content: "..." }),
		];
		expect(countRelevantMutationsThisTurn(history, "scaffold a healthcheck endpoint")).toBe(1);
	});

	it("matches by basename — absolute path written, basename mentioned", () => {
		const history: ConversationMessage[] = [
			mkUser("fix index.html"),
			mkCall("write_file", {
				path: "E:/full/path/to/proj/index.html",
				content: "<html>...</html>",
			}),
		];
		expect(countRelevantMutationsThisTurn(history, "fix index.html")).toBe(1);
	});

	it("counts a batch_file_edit when any of its edit paths is relevant", () => {
		const history: ConversationMessage[] = [
			mkUser("fix styles.css and theme.js"),
			mkCall("batch_file_edit", {
				edits: [
					{ path: "styles.css", before: "x", after: "y" },
					{ path: "unrelated.md", before: "a", after: "b" },
				],
			}),
		];
		expect(countRelevantMutationsThisTurn(history, "fix styles.css and theme.js")).toBe(1);
	});

	it("returns 0 when the only writes are to fully unrelated files (with relevance set non-empty)", () => {
		const history: ConversationMessage[] = [
			mkUser("fix the bug in src/parser.ts"),
			mkCall("write_file", { path: "notes/draft.md", content: "..." }),
		];
		expect(countRelevantMutationsThisTurn(history, "fix the bug in src/parser.ts")).toBe(0);
	});
});
