import { describe, expect, it } from "vitest";
import { detectFieldContamination } from "../src/agent";

// Schema shape that matches the real write_file tool: two required string
// fields where the model'\''s arg-encoding sometimes collapses the JSON
// boundary between them.
const WRITE_FILE_SCHEMA = {
	type: "object",
	properties: {
		path: { type: "string" },
		content: { type: "string" },
	},
	required: ["path", "content"],
} as const;

const EXEC_SCHEMA = {
	type: "object",
	properties: {
		command: { type: "string" },
	},
	required: ["command"],
} as const;

describe("detectFieldContamination", () => {
	it("returns undefined for clean args", () => {
		expect(
			detectFieldContamination(
				{ path: "src/foo.ts", content: "console.log('hi')" },
				WRITE_FILE_SCHEMA,
			),
		).toBeUndefined();
	});

	it("detects path absorbing content (the user'''s actual failure case)", () => {
		const contam = detectFieldContamination(
			{
				path: 'execute_security_tests.py","content":"#!/usr/bin/env python3 ...',
				content: undefined,
			},
			WRITE_FILE_SCHEMA,
		);
		expect(contam).toBeDefined();
		expect(contam).toMatch(/path/);
		expect(contam).toMatch(/content/);
	});

	it("detects backslash-escaped boundary leak", () => {
		const contam = detectFieldContamination(
			{
				path: 'file.txt\\",\\"content\\":\\"the content',
				content: undefined,
			},
			WRITE_FILE_SCHEMA,
		);
		expect(contam).toBeDefined();
	});

	it("ignores tools with only one required field (no cross-contamination possible)", () => {
		expect(
			detectFieldContamination({ command: 'echo \\",\\"content\\":\\"hi' }, EXEC_SCHEMA),
		).toBeUndefined();
	});

	// 2026-05-29: previously this test asserted "if both fields populated,
	// the contamination might be legit data" — but the real-world Kimi K2.6
	// transcript showed regex-recovery extracting BOTH a corrupted path AND
	// a clean content, then writing a 9KB garbage filename to disk. Path-
	// shaped fields never legitimately contain the literal substring
	// `","<otherkey>":`, so flag it regardless of `other`'s value.
	it("flags path contamination even when content is also populated (Kimi recovery case)", () => {
		expect(
			detectFieldContamination(
				{
					path: 'some/weird","content":"path.ts',
					content: "actual file content here",
				},
				WRITE_FILE_SCHEMA,
			),
		).toBeDefined();
	});

	it("still skips contamination on non-path-like fields when other is populated", () => {
		// Generic two-string schema where neither is path-shaped — keeps the
		// old guard so a legit search query containing JSON-looking chars
		// doesn't false-positive.
		const QUERY_SCHEMA = {
			type: "object",
			properties: { query: { type: "string" }, source: { type: "string" } },
			required: ["query", "source"],
		} as const;
		expect(
			detectFieldContamination(
				{
					query: 'foo","source":"bar',
					source: "actual source value",
				},
				QUERY_SCHEMA,
			),
		).toBeUndefined();
	});

	it("returns undefined when args is not an object", () => {
		expect(detectFieldContamination(null, WRITE_FILE_SCHEMA)).toBeUndefined();
		expect(detectFieldContamination(undefined, WRITE_FILE_SCHEMA)).toBeUndefined();
		expect(detectFieldContamination("string", WRITE_FILE_SCHEMA)).toBeUndefined();
		expect(detectFieldContamination([], WRITE_FILE_SCHEMA)).toBeUndefined();
	});

	it("returns undefined when schema has no required list", () => {
		expect(
			detectFieldContamination(
				{ path: 'foo","content":"bar' },
				{ type: "object", properties: { path: { type: "string" } } },
			),
		).toBeUndefined();
	});

	it("detects boundary leak even with leading comma but no quote", () => {
		const contam = detectFieldContamination(
			{
				path: "foo.py,content:hi",
				content: "",
			},
			WRITE_FILE_SCHEMA,
		);
		expect(contam).toBeDefined();
	});

	it("handles missing field gracefully (content omitted entirely)", () => {
		const contam = detectFieldContamination(
			{ path: 'foo.py","content":"#!/usr/bin/env python3' },
			WRITE_FILE_SCHEMA,
		);
		expect(contam).toBeDefined();
	});
});
