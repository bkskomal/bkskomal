import { describe, expect, it } from "vitest";
import { detectToolArgShapeProblem } from "../src/agent";

describe("detectToolArgShapeProblem", () => {
	it("returns undefined for clean args", () => {
		expect(
			detectToolArgShapeProblem("write_file", {
				path: "src/foo.ts",
				content: "hello",
			}),
		).toBeUndefined();
	});

	it("flags a 9000-char 'path' (the Kimi K2.6 transcript case)", () => {
		// The transcript's actual failure: regex recovery extracted a path
		// that was really the whole content. mkdir then exploded with EINVAL.
		const longPath = "x".repeat(9000);
		const result = detectToolArgShapeProblem("write_file", {
			path: longPath,
			content: "doesn't matter",
		});
		expect(result).toBeDefined();
		expect(result).toMatch(/4096|too large|corrupted/i);
	});

	it("flags a path containing newlines", () => {
		const result = detectToolArgShapeProblem("write_file", {
			path: "src/foo.ts\nsome more stuff",
			content: "x",
		});
		expect(result).toBeDefined();
		expect(result).toMatch(/newline/i);
	});

	it("flags a path containing an embedded JSON field boundary", () => {
		// The literal Kimi pattern: path ends up containing `","content":"…`
		// because the args were a JSON string inside a JSON string and the
		// regex recovery misjudged the boundary.
		const result = detectToolArgShapeProblem("write_file", {
			path: 'index.html","content":"<!DOCTYPE html>',
			content: "<!DOCTYPE html>",
		});
		expect(result).toBeDefined();
		expect(result).toMatch(/JSON-field boundary|double-encoded|flat/i);
	});

	it("flags a path with unescaped double-quotes", () => {
		const result = detectToolArgShapeProblem("write_file", {
			path: 'src/"weird".ts',
			content: "x",
		});
		expect(result).toBeDefined();
		expect(result).toMatch(/quote/i);
	});

	it("does not false-positive on a normal nested path", () => {
		expect(
			detectToolArgShapeProblem("write_file", {
				path: "packages/extension-host/src/qa-execute.ts",
				content: "lots of code",
			}),
		).toBeUndefined();
	});

	it("flags an absurdly long exec command", () => {
		const result = detectToolArgShapeProblem("exec", {
			command: "x".repeat(9000),
		});
		expect(result).toBeDefined();
		expect(result).toMatch(/command|too large|write_file/i);
	});

	it("allows a reasonably-long exec command", () => {
		expect(
			detectToolArgShapeProblem("exec", {
				command: "pnpm exec vitest --run --reporter=verbose path/to/test.ts",
			}),
		).toBeUndefined();
	});

	it("returns undefined on non-object input", () => {
		expect(detectToolArgShapeProblem("write_file", null)).toBeUndefined();
		expect(detectToolArgShapeProblem("write_file", undefined)).toBeUndefined();
		expect(detectToolArgShapeProblem("write_file", "")).toBeUndefined();
		expect(detectToolArgShapeProblem("write_file", [])).toBeUndefined();
	});

	it("ignores fields whose value isn't a string", () => {
		expect(
			detectToolArgShapeProblem("write_file", {
				path: 42 as unknown as string,
				content: "x",
			}),
		).toBeUndefined();
	});

	it("only flags command field on exec-like tools", () => {
		// Non-exec tool with a 'command' that happens to be huge — not our concern.
		expect(
			detectToolArgShapeProblem("read_file", {
				command: "x".repeat(20000),
			}),
		).toBeUndefined();
	});
});
