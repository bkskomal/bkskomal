import { describe, expect, it } from "vitest";
import { KimiNativeToolParser } from "../src/kimi-native-parser";

describe("KimiNativeToolParser", () => {
	it("parses a single complete tool block into a tool call", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		const out = p.feed(
			'<|tool_call_begin|>functions.write_file:15<|tool_call_argument_begin|>{"path":"foo.ts","content":"hi"}<|tool_call_end|>',
		);
		expect(out.toolCalls).toHaveLength(1);
		expect(out.toolCalls[0].name).toBe("write_file");
		expect(out.toolCalls[0].args).toEqual({ path: "foo.ts", content: "hi" });
		expect(out.text).toBe("");
	});

	it("strips Kimi's prompt-template artifacts off the tool name", () => {
		const p = new KimiNativeToolParser(["read_file"]);
		const cases = [
			"functions.read_file:0",
			"functions.read_file:42",
			"read_file:7",
			"read_file",
			"  read_file  ",
		];
		for (const header of cases) {
			const sub = new KimiNativeToolParser(["read_file"]);
			const out = sub.feed(
				`<|tool_call_begin|>${header}<|tool_call_argument_begin|>{"path":"a.ts"}<|tool_call_end|>`,
			);
			expect(out.toolCalls).toHaveLength(1);
			expect(out.toolCalls[0].name).toBe("read_file");
		}
		// Sanity: the outer instance never had any state contamination.
		expect(p.feed("plain text").text).toBe("plain text");
	});

	it("unwraps the leading/trailing quotes Kimi often adds around the args payload", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		const out = p.feed(
			'<|tool_call_begin|>write_file:1<|tool_call_argument_begin|>"{"path":"a.ts","content":"x"}"<|tool_call_end|>',
		);
		expect(out.toolCalls).toHaveLength(1);
		expect(out.toolCalls[0].args).toEqual({ path: "a.ts", content: "x" });
	});

	it("emits plain text between tool blocks unchanged", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		const out = p.feed(
			'I will now create the file.\n<|tool_call_begin|>write_file:1<|tool_call_argument_begin|>{"path":"a.ts","content":"x"}<|tool_call_end|>\nDone.',
		);
		expect(out.text).toBe("I will now create the file.\n\nDone.");
		expect(out.toolCalls).toHaveLength(1);
	});

	it("silently consumes the <|tool_calls_section_end|> trailer", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		const out = p.feed(
			'<|tool_call_begin|>write_file:1<|tool_call_argument_begin|>{"path":"a.ts","content":"x"}<|tool_call_end|><|tool_calls_section_end|>',
		);
		expect(out.text).toBe("");
		expect(out.toolCalls).toHaveLength(1);
	});

	it("handles markers split across feed boundaries (streaming safety)", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		const r1 = p.feed("Reading… <|tool_call_be");
		expect(r1.toolCalls).toHaveLength(0);
		expect(r1.text).toBe("Reading… ");
		const r2 = p.feed("gin|>write_file:1<|tool_call_argument_be");
		expect(r2.toolCalls).toHaveLength(0);
		const r3 = p.feed('gin|>{"path":"a.ts","content":"x"}<|tool_call_e');
		expect(r3.toolCalls).toHaveLength(0);
		const r4 = p.feed("nd|>");
		expect(r4.toolCalls).toHaveLength(1);
		expect(r4.toolCalls[0].args).toEqual({ path: "a.ts", content: "x" });
	});

	it("parses multiple consecutive tool blocks in one chunk", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		const out = p.feed(
			'<|tool_call_begin|>write_file:1<|tool_call_argument_begin|>{"path":"a.ts","content":"1"}<|tool_call_end|>' +
				'<|tool_call_begin|>write_file:2<|tool_call_argument_begin|>{"path":"b.ts","content":"2"}<|tool_call_end|>' +
				"<|tool_calls_section_end|>",
		);
		expect(out.toolCalls).toHaveLength(2);
		expect(out.toolCalls[0].args).toEqual({ path: "a.ts", content: "1" });
		expect(out.toolCalls[1].args).toEqual({ path: "b.ts", content: "2" });
	});

	it("drops tool calls whose name is not in the known set (model hallucinated a tool)", () => {
		const p = new KimiNativeToolParser(["read_file"]);
		const out = p.feed(
			'<|tool_call_begin|>imaginary_tool:1<|tool_call_argument_begin|>{"a":1}<|tool_call_end|>',
		);
		expect(out.toolCalls).toHaveLength(0);
	});

	it("recovers control characters inside string literals in args (lenient JSON parse)", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		// Bare \n inside the "content" string — not valid JSON. Parser
		// should repair it before falling back to {_raw}.
		const raw =
			'<|tool_call_begin|>write_file:1<|tool_call_argument_begin|>{"path":"a.ts","content":"line1\nline2"}<|tool_call_end|>';
		const out = p.feed(raw);
		expect(out.toolCalls).toHaveLength(1);
		expect(out.toolCalls[0].args).toEqual({ path: "a.ts", content: "line1\nline2" });
	});

	it("falls back to {_raw: ...} when the args payload is unparseable garbage", () => {
		const p = new KimiNativeToolParser(["broken_tool"]);
		const out = p.feed(
			"<|tool_call_begin|>broken_tool:1<|tool_call_argument_begin|>not json at all<|tool_call_end|>",
		);
		expect(out.toolCalls).toHaveLength(1);
		expect(out.toolCalls[0].args).toEqual({ _raw: "not json at all" });
	});

	it("finalize() flushes a partial tool block as text rather than dropping it silently", () => {
		const p = new KimiNativeToolParser(["write_file"]);
		const mid = p.feed(
			'<|tool_call_begin|>write_file:1<|tool_call_argument_begin|>{"path":"a.ts","co',
		);
		expect(mid.toolCalls).toHaveLength(0);
		const tail = p.finalize();
		// Whatever we couldn't parse as JSON falls back to {_raw}, so the
		// tool call still surfaces (with garbled args) rather than being
		// lost. Better to show the user a broken call than to drop it.
		expect(tail.toolCalls).toHaveLength(1);
		expect((tail.toolCalls[0].args as { _raw?: string })._raw).toContain("a.ts");
	});
});
