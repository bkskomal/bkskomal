# OATICodingAssistant

**Configurable agentic coding assistant** for VS Code and Google Antigravity. Multi-provider, multi-IDE, MCP-native.

## Features

- 🤖 **Configurable agent loop** with optional planner and critic stages
- 🔀 **Parallel sub-agents** via `spawn_agent` tool (cap is configurable per mode)
- 🔌 **Multi-provider:** OpenAI, OpenRouter, Anthropic native, LiteLLM, unillm, Ollama, or any OpenAI-compatible gateway
- 🧰 **8 built-in tools:** read/write files, run shell commands, search, fetch URLs, spawn sub-agents
- 🪝 **Full MCP support:** stdio JSON-RPC client with 8 ready-to-use server presets (Filesystem, Memory, GitHub, Brave Search, SQLite, …)
- 📝 **Diff before write:** approval dialog shows the diff inline AND opens VS Code's native diff editor
- 💰 **Token + cost tracking:** per-model rate table gives you live USD in the header
- 💾 **Session persistence + export/import** per workspace
- 🔐 **API keys in VS Code SecretStorage** — webview never sees raw values
- 🎯 **Configurable per mode:** every capability has an on/off switch

## Quick start

1. Install the extension from the VS Code marketplace.
2. **Ctrl+Shift+P** → `OATI: Open Chat`.
3. Click the ⚙ in the panel → pick a provider preset → paste your API key → set a Model ID → **Done**.
4. Ask: *"List the TypeScript files in src/ and tell me which is the largest."*

## Commands

| Command | What it does |
|---|---|
| `OATI: Open Chat` | Opens the chat panel |
| `OATI: Open Settings` | Jump directly to the settings view |
| `OATI: New Chat (Clear History)` | Start fresh; existing conversation is wiped |
| `OATI: Export Session...` | Save current conversation to a JSON file |
| `OATI: Import Session...` | Load a previously-saved conversation |

## Configuration

All configuration is in the Settings panel inside the chat view. There are no `settings.json` keys to worry about. Settings are stored in VS Code's `globalState` and API keys in `SecretStorage` — never in your dotfiles, never in source control.

## Privacy

- The extension only talks to the LLM provider URL you configure. No telemetry.
- API keys are stored using VS Code's built-in `SecretStorage` (OS keychain).
- The webview UI runs under strict CSP — no inline scripts, no external resources.
- Conversation history persists per workspace in VS Code's `globalState`. Use **New Chat** to clear.

## Open source

MIT licensed. Source at [github.com/sbkkomal/codeassistant](https://github.com/sbkkomal/codeassistant). Built from scratch — no code shared with Cline, Continue, Aider, or any other agentic-coding tool.
