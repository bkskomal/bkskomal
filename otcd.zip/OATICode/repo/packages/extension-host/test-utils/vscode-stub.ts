/**
 * Minimal `vscode` module stub for unit tests.
 *
 * Tests pull pure helpers (state machines, regexes, prompt builders) out of
 * modules that *also* contain VS Code integration. Those modules `import *
 * as vscode from "vscode"` at the top, so importing them in Node fails with
 * `Cannot find module 'vscode'`. This stub satisfies the import; runtime
 * code paths that actually need vscode are gated behind functions that
 * tests never call.
 *
 * Add more shims here only when a new test path actually traverses one.
 */

class EventEmitter<_T = unknown> {
	private listeners: Array<(arg: unknown) => void> = [];
	readonly event = (listener: (arg: unknown) => void): { dispose(): void } => {
		this.listeners.push(listener);
		return { dispose: () => undefined };
	};
	fire(arg: unknown): void {
		for (const l of this.listeners) l(arg);
	}
	dispose(): void {
		this.listeners = [];
	}
}

class Range {
	public readonly start: Position;
	public readonly end: Position;
	constructor(
		startLineOrStart: Position | number,
		startCharOrEnd: Position | number,
		endLine?: number,
		endChar?: number,
	) {
		if (typeof startLineOrStart === "number" && typeof startCharOrEnd === "number") {
			this.start = new Position(startLineOrStart, startCharOrEnd);
			this.end = new Position(endLine ?? startLineOrStart, endChar ?? startCharOrEnd);
		} else {
			this.start = startLineOrStart as Position;
			this.end = startCharOrEnd as Position;
		}
	}
}
class Position {
	constructor(
		public readonly line: number,
		public readonly character: number,
	) {}
}

const Uri = {
	parse: (s: string) => ({ toString: () => s, fsPath: s, scheme: s.split(":")[0] }),
	file: (p: string) => ({ toString: () => `file://${p}`, fsPath: p, scheme: "file" }),
	joinPath: (base: { fsPath: string }, ...rest: string[]) => ({
		toString: () => `file://${base.fsPath}/${rest.join("/")}`,
		fsPath: `${base.fsPath}/${rest.join("/")}`,
		scheme: "file",
	}),
};

const window = {
	createTextEditorDecorationType: () => ({ dispose: () => undefined }),
	createOutputChannel: () => ({
		appendLine: () => undefined,
		dispose: () => undefined,
	}),
	visibleTextEditors: [],
	activeTextEditor: undefined,
	showInputBox: async () => undefined,
	showInformationMessage: () => undefined,
	showWarningMessage: () => undefined,
	showErrorMessage: () => undefined,
	showTextDocument: async () => undefined,
	createWebviewPanel: () => ({
		webview: {
			postMessage: () => undefined,
			onDidReceiveMessage: () => ({ dispose: () => undefined }),
		},
		dispose: () => undefined,
	}),
	// R5-A: inline-completion uses these to classify accept/reject.
	onDidChangeTextEditorSelection: (_l: (ev: unknown) => void) => ({
		dispose: () => undefined,
	}),
	onDidChangeActiveTextEditor: (_l: (ev: unknown) => void) => ({ dispose: () => undefined }),
};

const workspace = {
	workspaceFolders: undefined as undefined | Array<{ uri: { fsPath: string } }>,
	openTextDocument: async () => undefined,
	// R6-B: notebook bridge — tests overwrite this with a function returning a
	// fake `NotebookDocument` so they can exercise the bridge end-to-end.
	openNotebookDocument: async (_uri: unknown): Promise<unknown> => undefined,
	applyEdit: async () => true,
	fs: {
		readFile: async () => new Uint8Array(),
		writeFile: async () => undefined,
		stat: async () => undefined,
	},
	registerTextDocumentContentProvider: () => ({ dispose: () => undefined }),
	// R5-A: getConfiguration stub returns a tiny defaults-only object so
	// modules that read settings at import time don't blow up under vitest.
	getConfiguration: (_section?: string) => ({
		get: <T>(_key: string, defaultValue?: T): T | undefined => defaultValue,
		update: async () => undefined,
		has: (_key: string) => false,
		inspect: () => undefined,
	}),
	onDidChangeTextDocument: (_l: (ev: unknown) => void) => ({ dispose: () => undefined }),
	// R5-B: knowledge store attaches a watcher to `.oati/knowledge/**/*.md`;
	// tests never trigger real fs events so a passive stub is enough.
	createFileSystemWatcher: () => ({
		onDidChange: () => ({ dispose: () => undefined }),
		onDidCreate: () => ({ dispose: () => undefined }),
		onDidDelete: () => ({ dispose: () => undefined }),
		dispose: () => undefined,
	}),
};

class RelativePattern {
	constructor(
		public readonly base: string,
		public readonly pattern: string,
	) {}
}

const commands = {
	registerCommand: () => ({ dispose: () => undefined }),
	executeCommand: async () => undefined,
};

const languages = {
	registerCodeLensProvider: () => ({ dispose: () => undefined }),
	// R5-A: shim for inline completion provider registration.
	registerInlineCompletionItemProvider: () => ({ dispose: () => undefined }),
};

const ViewColumn = { One: 1, Two: 2, Beside: -2, Active: -1 };
const OverviewRulerLane = { Left: 1, Center: 2, Right: 4, Full: 7 };
// R5-A: ConfigurationTarget enum used when writing back the toggle setting.
const ConfigurationTarget = { Global: 1, Workspace: 2, WorkspaceFolder: 3 };
// R5-A: DecorationRangeBehavior enum referenced by predictive-edit
// (already used at runtime; tests pull these modules in transitively).
const DecorationRangeBehavior = { OpenOpen: 0, ClosedClosed: 1, OpenClosed: 2, ClosedOpen: 3 };
// R5-A: Disposable.from helper — concatenates child disposables.
const Disposable = {
	from: (...items: Array<{ dispose(): void }>) => ({
		dispose: () => {
			for (const i of items) {
				try {
					i.dispose();
				} catch {
					/* ignore */
				}
			}
		},
	}),
};

class WorkspaceEdit {
	// R6-B: tests inspect what edits were enqueued against which uri so they
	// can assert the bridge built the right NotebookEdit shape. Stored as a
	// public map keyed by `uri.toString()`.
	public readonly notebookEdits: Map<string, unknown[]> = new Map();
	replace(): void {
		// no-op
	}
	set(uri: { toString(): string }, edits: unknown[]): void {
		this.notebookEdits.set(uri.toString(), edits);
	}
}

// R6-B: notebook bridge — minimal NotebookCellKind / NotebookRange /
// NotebookCellData / NotebookEdit stubs so tests for `notebook-bridge.ts` can
// import the module without bringing in the real VS Code runtime. None of the
// stubs encode behavior beyond being typed value-holders.
const NotebookCellKind = { Markup: 1, Code: 2 } as const;

class NotebookRange {
	constructor(
		public readonly start: number,
		public readonly end: number,
	) {}
}

class NotebookCellData {
	public outputs: unknown[] = [];
	public metadata: Record<string, unknown> = {};
	constructor(
		public readonly kind: number,
		public readonly value: string,
		public readonly languageId: string,
	) {}
}

class NotebookEdit {
	static replaceCells(range: NotebookRange, cells: NotebookCellData[]): NotebookEdit {
		return new NotebookEdit("replaceCells", { range, cells });
	}
	static insertCells(index: number, cells: NotebookCellData[]): NotebookEdit {
		return new NotebookEdit("insertCells", { index, cells });
	}
	static deleteCells(range: NotebookRange): NotebookEdit {
		return new NotebookEdit("deleteCells", { range });
	}
	private constructor(
		public readonly kind: string,
		public readonly payload: unknown,
	) {}
}

class CodeLens {
	constructor(
		public readonly range: Range,
		public readonly command?: unknown,
	) {}
}

// R6-E: minimal Location + SourceBreakpoint + debug namespace stubs used by
// the debug-bridge tests. The debug bridge constructs `SourceBreakpoint`s
// when adding breakpoints and pattern-matches with `instanceof` when
// listing/removing, so we keep both classes here so the tests can exercise
// the full round-trip.
class Location {
	constructor(
		public readonly uri: { toString(): string; fsPath: string },
		public readonly range: Range,
	) {}
}

class SourceBreakpoint {
	constructor(
		public readonly location: Location,
		public readonly enabled = true,
		public readonly condition?: string,
	) {}
}

// In-memory `vscode.debug` surface so unit tests can drive DAP-style flows
// without an actual debug session. Tests reach in via the exported
// `debug` namespace to set the active session, queue custom-request replies,
// and toggle breakpoint state.
interface DebugStubSession {
	id: string;
	type: string;
	name: string;
	customRequest: (cmd: string, args?: unknown) => Promise<unknown>;
}

const debug: {
	activeDebugSession: DebugStubSession | undefined;
	breakpoints: SourceBreakpoint[];
	addBreakpoints: (bps: readonly SourceBreakpoint[]) => void;
	removeBreakpoints: (bps: readonly SourceBreakpoint[]) => void;
	registerDebugAdapterTrackerFactory: (type: string, factory: unknown) => { dispose(): void };
	onDidStartDebugSession: (l: (s: DebugStubSession) => void) => { dispose(): void };
	onDidTerminateDebugSession: (l: (s: DebugStubSession) => void) => { dispose(): void };
	onDidChangeBreakpoints: (l: (ev: unknown) => void) => { dispose(): void };
} = {
	activeDebugSession: undefined,
	breakpoints: [],
	addBreakpoints(bps) {
		for (const bp of bps) debug.breakpoints.push(bp);
	},
	removeBreakpoints(bps) {
		const set = new Set(bps);
		debug.breakpoints = debug.breakpoints.filter((bp) => !set.has(bp));
	},
	registerDebugAdapterTrackerFactory: (_type, _factory) => ({ dispose: () => undefined }),
	onDidStartDebugSession: (_l) => ({ dispose: () => undefined }),
	onDidTerminateDebugSession: (_l) => ({ dispose: () => undefined }),
	onDidChangeBreakpoints: (_l) => ({ dispose: () => undefined }),
};

export {
	EventEmitter,
	Range,
	Position,
	Uri,
	window,
	workspace,
	commands,
	languages,
	ViewColumn,
	OverviewRulerLane,
	WorkspaceEdit,
	CodeLens,
	// R5-A
	ConfigurationTarget,
	DecorationRangeBehavior,
	Disposable,
	// R5-B
	RelativePattern,
	// R6-E
	Location,
	SourceBreakpoint,
	debug,
	// R6-B: notebook bridge stubs.
	NotebookCellKind,
	NotebookRange,
	NotebookCellData,
	NotebookEdit,
};
