import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	SNIPPETS_RELATIVE_DIR,
	deleteSnippet,
	listSnippets,
	readSnippet,
	saveSnippet,
} from "../src/snippets";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "oati-snippets-"));
}

describe("snippets host module (R4-C)", () => {
	let dir: string;

	beforeEach(async () => {
		dir = await mkTempDir();
	});

	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("returns [] when the snippets dir does not exist", async () => {
		expect(await listSnippets(dir)).toEqual([]);
	});

	it("save → list round-trips name + description", async () => {
		await saveSnippet(dir, "hello", "console.log('hi');", "Say hello");
		const list = await listSnippets(dir);
		expect(list).toEqual([{ name: "hello", description: "Say hello" }]);
	});

	it("save defaults description to the snippet name", async () => {
		await saveSnippet(dir, "bare", "just a body");
		const list = await listSnippets(dir);
		expect(list[0]).toEqual({ name: "bare", description: "bare" });
	});

	it("readSnippet returns only the body, stripping the H1 line", async () => {
		await saveSnippet(dir, "x", "function hi(){}", "A function");
		const body = await readSnippet(dir, "x");
		expect(body).toBe("function hi(){}");
	});

	it("readSnippet returns null when the snippet is missing", async () => {
		expect(await readSnippet(dir, "missing")).toBeNull();
	});

	it("rejects invalid snippet names", async () => {
		await expect(saveSnippet(dir, "../escape", "body")).rejects.toThrow(/invalid snippet name/);
	});

	it("delete removes the file", async () => {
		await saveSnippet(dir, "tmp", "body");
		await deleteSnippet(dir, "tmp");
		expect(await readSnippet(dir, "tmp")).toBeNull();
	});

	it("delete is a no-op when the snippet does not exist", async () => {
		await expect(deleteSnippet(dir, "nope")).resolves.toBeUndefined();
	});

	it("listSnippets skips files whose names contain invalid characters", async () => {
		await fs.mkdir(path.join(dir, SNIPPETS_RELATIVE_DIR), { recursive: true });
		await fs.writeFile(path.join(dir, SNIPPETS_RELATIVE_DIR, "ok.md"), "# Ok\n\nbody", "utf-8");
		await fs.writeFile(
			path.join(dir, SNIPPETS_RELATIVE_DIR, "bad space.md"),
			"# Bad\n\nbody",
			"utf-8",
		);
		const list = await listSnippets(dir);
		expect(list.map((s) => s.name)).toEqual(["ok"]);
	});

	it("listSnippets falls back to the name when no H1 is present", async () => {
		await fs.mkdir(path.join(dir, SNIPPETS_RELATIVE_DIR), { recursive: true });
		await fs.writeFile(
			path.join(dir, SNIPPETS_RELATIVE_DIR, "raw.md"),
			"just text, no heading",
			"utf-8",
		);
		const list = await listSnippets(dir);
		expect(list[0]).toEqual({ name: "raw", description: "raw" });
	});
});
