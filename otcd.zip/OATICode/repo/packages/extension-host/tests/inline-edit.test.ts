import { describe, expect, it } from "vitest";
import { buildInlineEditPrompt, countChangedLines, stripCodeFences } from "../src/inline-edit";

describe("buildInlineEditPrompt", () => {
	it("includes the instruction and selection inside a fenced block", () => {
		const { system, user } = buildInlineEditPrompt("add docstring", "def f(): return 1", "python");
		expect(system).toContain("inline code-editing assistant");
		expect(system).toContain("rewritten code ONLY");
		expect(user).toContain("Rewrite the following python code per this instruction: add docstring");
		expect(user).toContain("```python\ndef f(): return 1\n```");
	});

	it("falls back to 'code' when language is empty", () => {
		const { user } = buildInlineEditPrompt("clean up", "x = 1", "");
		expect(user).toContain("Rewrite the following code code per this instruction: clean up");
		expect(user).toContain("```code\nx = 1\n```");
	});
});

describe("stripCodeFences", () => {
	it("removes leading and trailing fences", () => {
		expect(stripCodeFences("```ts\nconst x = 1;\n```")).toBe("const x = 1;");
	});

	it("returns plain text unchanged", () => {
		expect(stripCodeFences("const x = 1;")).toBe("const x = 1;");
	});

	it("handles a missing closing fence by removing only the opener", () => {
		expect(stripCodeFences("```ts\nconst x = 1;")).toBe("const x = 1;");
	});
});

describe("countChangedLines", () => {
	it("returns 0 for identical input", () => {
		expect(countChangedLines("a\nb\nc", "a\nb\nc")).toBe(0);
	});

	it("counts changed lines line-by-line", () => {
		expect(countChangedLines("a\nb\nc", "a\nB\nc")).toBe(1);
		expect(countChangedLines("a\nb\nc", "A\nB\nC")).toBe(3);
	});

	it("counts added lines as changes", () => {
		expect(countChangedLines("a", "a\nb\nc")).toBe(2);
	});
});
