import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	RECIPES_RELATIVE_DIR,
	deleteRecipe,
	listRecipes,
	parseRecipe,
	readRecipe,
	saveRecipe,
} from "../src/recipes";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "oati-recipes-"));
}

describe("recipes host module (R5-D)", () => {
	let dir: string;

	beforeEach(async () => {
		dir = await mkTempDir();
	});

	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("returns [] when the recipes dir does not exist", async () => {
		expect(await listRecipes(dir)).toEqual([]);
	});

	it("save → list round-trips name + description", async () => {
		await saveRecipe(dir, {
			name: "ship-feature",
			description: "Implement, test, commit, open PR",
			steps: ["Generate implementation", "Run tests with /run_tests"],
			context: "House rules apply.",
		});
		const list = await listRecipes(dir);
		expect(list).toEqual([{ name: "ship-feature", description: "Implement, test, commit, open PR" }]);
	});

	it("readRecipe returns the parsed steps + context", async () => {
		await saveRecipe(dir, {
			name: "demo",
			description: "Demo recipe",
			steps: ["Step one", "Step two"],
			context: "Shared context here.",
		});
		const r = await readRecipe(dir, "demo");
		expect(r).not.toBeNull();
		expect(r?.steps).toEqual(["Step one", "Step two"]);
		expect(r?.context).toBe("Shared context here.");
	});

	it("readRecipe returns null when the recipe is missing", async () => {
		expect(await readRecipe(dir, "missing")).toBeNull();
	});

	it("rejects invalid recipe names", async () => {
		await expect(
			saveRecipe(dir, { name: "../escape", description: "bad", steps: ["x"], context: "" }),
		).rejects.toThrow(/invalid recipe name/);
	});

	it("rejects recipes with no steps", async () => {
		await expect(
			saveRecipe(dir, { name: "empty", description: "no steps", steps: [], context: "" }),
		).rejects.toThrow(/at least one step/);
	});

	it("parseRecipe handles inline array shorthand", () => {
		const raw = [
			"---",
			"name: q",
			"description: quick",
			'steps: ["a", "b", "c"]',
			"---",
			"",
			"body",
		].join("\n");
		const r = parseRecipe("q", raw);
		expect(r?.steps).toEqual(["a", "b", "c"]);
		expect(r?.context).toBe("body");
	});

	it("parseRecipe returns null when front-matter is missing", () => {
		expect(parseRecipe("x", "no front matter here")).toBeNull();
	});

	it("parseRecipe returns null when there are no steps", () => {
		const raw = ["---", "name: x", "description: y", "---", ""].join("\n");
		expect(parseRecipe("x", raw)).toBeNull();
	});

	it("delete removes the file", async () => {
		await saveRecipe(dir, { name: "tmp", description: "d", steps: ["x"], context: "" });
		await deleteRecipe(dir, "tmp");
		expect(await readRecipe(dir, "tmp")).toBeNull();
	});

	it("listRecipes skips files with invalid name characters", async () => {
		await fs.mkdir(path.join(dir, RECIPES_RELATIVE_DIR), { recursive: true });
		await fs.writeFile(
			path.join(dir, RECIPES_RELATIVE_DIR, "ok.md"),
			["---", "name: ok", "description: fine", "steps:", '  - "a"', "---"].join("\n"),
			"utf-8",
		);
		await fs.writeFile(
			path.join(dir, RECIPES_RELATIVE_DIR, "bad space.md"),
			["---", "name: bad", "steps:", '  - "x"', "---"].join("\n"),
			"utf-8",
		);
		const list = await listRecipes(dir);
		expect(list.map((r) => r.name)).toEqual(["ok"]);
	});
});
