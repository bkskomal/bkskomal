// R6-E: debug-bridge unit tests. Drives the singleton with a faked
// `vscode.debug` surface (see test-utils/vscode-stub.ts). Each test resets
// the singleton + clears the stubbed state so cases are independent.
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import * as vscode from "vscode";
import { DebugBridge } from "../src/debug-bridge";

// The vscode-stub exposes `debug` as a mutable namespace; cast to our local
// shape so tests can poke at the fields without TS complaints.
const vsd = (vscode as unknown as { debug: TestDebug }).debug;

interface TestDebug {
	activeDebugSession:
		| {
				id: string;
				type: string;
				name: string;
				customRequest: (cmd: string, args?: unknown) => Promise<unknown>;
		  }
		| undefined;
	breakpoints: Array<{
		location: { uri: { toString(): string; fsPath: string }; range: { start: { line: number } } };
		enabled: boolean;
		condition?: string;
	}>;
}

function makeSession(id: string, replies: Record<string, unknown>) {
	const calls: Array<{ cmd: string; args: unknown }> = [];
	const session = {
		id,
		type: "python",
		name: `pytest session ${id}`,
		customRequest: async (cmd: string, args?: unknown) => {
			calls.push({ cmd, args });
			if (cmd in replies) return replies[cmd];
			throw new Error(`unexpected DAP request: ${cmd}`);
		},
	};
	return { session, calls };
}

beforeEach(() => {
	DebugBridge._resetForTests();
	vsd.activeDebugSession = undefined;
	vsd.breakpoints = [];
});

afterEach(() => {
	DebugBridge._resetForTests();
	vsd.activeDebugSession = undefined;
	vsd.breakpoints = [];
});

describe("DebugBridge.getActiveSession", () => {
	it("returns null when no session is active", () => {
		const bridge = DebugBridge.instance();
		expect(bridge.getActiveSession()).toBeNull();
	});

	it("returns the active session metadata", () => {
		const { session } = makeSession("s1", {});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		expect(bridge.getActiveSession()).toEqual({
			id: "s1",
			type: "python",
			name: "pytest session s1",
		});
	});
});

describe("DebugBridge.getStackFrames", () => {
	it("throws a friendly error when no session is active", async () => {
		const bridge = DebugBridge.instance();
		await expect(bridge.getStackFrames(1)).rejects.toThrow(/no active debug session/);
	});

	it("requests stackTrace with the supplied threadId", async () => {
		const { session, calls } = makeSession("s1", {
			stackTrace: {
				stackFrames: [
					{ id: 10, name: "main", line: 42, source: { path: "/tmp/foo.py" } },
					{ id: 11, name: "inner" },
				],
			},
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		const frames = await bridge.getStackFrames(7);
		expect(frames).toHaveLength(2);
		expect(frames[0]).toEqual({ id: 10, name: "main", line: 42, path: "/tmp/foo.py" });
		expect(frames[1]).toEqual({ id: 11, name: "inner" });
		expect(calls[0]).toEqual({ cmd: "stackTrace", args: { threadId: 7 } });
	});

	it("falls back to the stopped thread when no threadId is supplied", async () => {
		const { session, calls } = makeSession("s1", {
			stackTrace: { stackFrames: [{ id: 1, name: "f" }] },
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		bridge._setStoppedThread("s1", 99);
		await bridge.getStackFrames();
		expect(calls[0]).toEqual({ cmd: "stackTrace", args: { threadId: 99 } });
	});

	it("uses the first thread from `threads` when nothing else is known", async () => {
		const { session, calls } = makeSession("s1", {
			threads: { threads: [{ id: 5 }, { id: 6 }] },
			stackTrace: { stackFrames: [] },
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		await bridge.getStackFrames();
		expect(calls.map((c) => c.cmd)).toEqual(["threads", "stackTrace"]);
		expect(calls[1].args).toEqual({ threadId: 5 });
	});

	it("throws when no thread can be inferred", async () => {
		const { session } = makeSession("s1", {
			threads: { threads: [] },
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		await expect(bridge.getStackFrames()).rejects.toThrow(/no thread is currently stopped/);
	});
});

describe("DebugBridge.evaluate", () => {
	it("threads expression + frameId to the DAP", async () => {
		const { session, calls } = makeSession("s1", {
			evaluate: { result: "42" },
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		const out = await bridge.evaluate("6*7", 33);
		expect(out).toBe("42");
		expect(calls[0]).toEqual({
			cmd: "evaluate",
			args: { expression: "6*7", frameId: 33, context: "repl" },
		});
	});

	it("defaults frameId to the top of the active stack", async () => {
		const { session, calls } = makeSession("s1", {
			stackTrace: { stackFrames: [{ id: 77, name: "top" }] },
			evaluate: { result: "ok" },
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		bridge._setStoppedThread("s1", 1);
		const out = await bridge.evaluate("x");
		expect(out).toBe("ok");
		const evalCall = calls.find((c) => c.cmd === "evaluate");
		expect(evalCall?.args).toEqual({ expression: "x", frameId: 77, context: "repl" });
	});

	it("returns empty string when the adapter omits a result", async () => {
		const { session } = makeSession("s1", { evaluate: {} });
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		expect(await bridge.evaluate("noop", 1)).toBe("");
	});
});

describe("DebugBridge.getScopes & getVariables", () => {
	it("returns normalized scopes", async () => {
		const { session } = makeSession("s1", {
			scopes: {
				scopes: [
					{ name: "Locals", variablesReference: 1000, expensive: false },
					{ name: "Globals", variablesReference: 1001, expensive: true },
				],
			},
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		const scopes = await bridge.getScopes(42);
		expect(scopes).toEqual([
			{ name: "Locals", variablesReference: 1000 },
			{ name: "Globals", variablesReference: 1001 },
		]);
	});

	it("returns normalized variables and preserves the `type` field when present", async () => {
		const { session } = makeSession("s1", {
			variables: {
				variables: [
					{ name: "x", value: "1", type: "int" },
					{ name: "y", value: "hi" },
				],
			},
		});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		const vars = await bridge.getVariables(1000);
		expect(vars).toEqual([
			{ name: "x", value: "1", type: "int" },
			{ name: "y", value: "hi" },
		]);
	});
});

describe("DebugBridge breakpoints", () => {
	it("setBreakpoint adds a SourceBreakpoint at the requested line", async () => {
		const bridge = DebugBridge.instance();
		await bridge.setBreakpoint("/tmp/foo.py", 17);
		expect(vsd.breakpoints).toHaveLength(1);
		const bp = vsd.breakpoints[0];
		expect(bp.location.range.start.line).toBe(16); // 1-based on the way in -> 0-based stored
		expect(bp.enabled).toBe(true);
	});

	it("setBreakpoint forwards condition + enabled flag", async () => {
		const bridge = DebugBridge.instance();
		await bridge.setBreakpoint("/tmp/foo.py", 5, "x > 0", false);
		expect(vsd.breakpoints[0].condition).toBe("x > 0");
		expect(vsd.breakpoints[0].enabled).toBe(false);
	});

	it("listBreakpoints surfaces 1-based lines", async () => {
		const bridge = DebugBridge.instance();
		await bridge.setBreakpoint("/tmp/foo.py", 9, "cond");
		const list = bridge.listBreakpoints();
		expect(list).toHaveLength(1);
		expect(list[0]).toMatchObject({ line: 9, condition: "cond", enabled: true });
		expect(list[0].uri).toContain("foo.py");
	});

	it("removeBreakpoint clears a matching entry", async () => {
		const bridge = DebugBridge.instance();
		await bridge.setBreakpoint("/tmp/foo.py", 1);
		await bridge.setBreakpoint("/tmp/foo.py", 2);
		await bridge.removeBreakpoint("/tmp/foo.py", 1);
		const list = bridge.listBreakpoints();
		expect(list).toHaveLength(1);
		expect(list[0].line).toBe(2);
	});

	it("removeBreakpoint is a no-op when no entry matches", async () => {
		const bridge = DebugBridge.instance();
		await bridge.setBreakpoint("/tmp/foo.py", 1);
		await bridge.removeBreakpoint("/tmp/foo.py", 999);
		expect(vsd.breakpoints).toHaveLength(1);
	});
});

describe("DebugBridge state-change events", () => {
	it("notifies subscribers on _setStoppedThread + _emit", () => {
		const bridge = DebugBridge.instance();
		let calls = 0;
		const off = bridge.onStateChange(() => {
			calls++;
		});
		bridge._setStoppedThread("s1", 1);
		bridge._emit();
		bridge._emit();
		expect(calls).toBe(2);
		off();
		bridge._emit();
		expect(calls).toBe(2);
	});

	it("getStoppedThreadId reflects the last recorded state for the active session", () => {
		const { session } = makeSession("s1", {});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		expect(bridge.getStoppedThreadId()).toBeUndefined();
		bridge._setStoppedThread("s1", 7);
		expect(bridge.getStoppedThreadId()).toBe(7);
		bridge._setStoppedThread("s1", undefined);
		expect(bridge.getStoppedThreadId()).toBeUndefined();
	});

	it("_dropSession forgets per-session state", () => {
		const { session } = makeSession("s1", {});
		vsd.activeDebugSession = session;
		const bridge = DebugBridge.instance();
		bridge._setStoppedThread("s1", 7);
		bridge._dropSession("s1");
		expect(bridge.getStoppedThreadId()).toBeUndefined();
	});
});
