import { describe, expect, it } from "vitest";
import {
	RecentEditsRingBuffer,
	buildEditSnippet,
	formatRecentEditsForPrompt,
	shouldRecordEdit,
} from "../src/recent-edits";

describe("RecentEditsRingBuffer", () => {
	it("returns the N most-recent entries in reverse-chronological order", () => {
		let t = 1000;
		const buf = new RecentEditsRingBuffer({ now: () => t });
		buf.push({ path: "a.ts", languageId: "ts", snippet: "one" });
		t += 10;
		buf.push({ path: "b.ts", languageId: "ts", snippet: "two" });
		t += 10;
		buf.push({ path: "c.ts", languageId: "ts", snippet: "three" });
		const recent = buf.getRecent({ limit: 5 });
		expect(recent.map((r) => r.snippet)).toEqual(["three", "two", "one"]);
	});

	it("evicts oldest entries when capacity is exceeded", () => {
		const buf = new RecentEditsRingBuffer({ maxEntries: 3 });
		for (let i = 0; i < 5; i++) {
			buf.push({ path: `f${i}.ts`, languageId: "ts", snippet: `snippet-${i}` });
		}
		expect(buf.size()).toBe(3);
		const all = buf.getRecent({ limit: 10 });
		// Most-recent first: snippet-4, snippet-3, snippet-2.
		expect(all.map((r) => r.snippet)).toEqual(["snippet-4", "snippet-3", "snippet-2"]);
	});

	it("filters out entries older than TTL", () => {
		let t = 1000;
		const buf = new RecentEditsRingBuffer({ ttlMs: 100, now: () => t });
		buf.push({ path: "old.ts", languageId: "ts", snippet: "stale" });
		t += 200; // past TTL
		buf.push({ path: "new.ts", languageId: "ts", snippet: "fresh" });
		const recent = buf.getRecent({ limit: 10 });
		expect(recent).toHaveLength(1);
		expect(recent[0].snippet).toBe("fresh");
	});

	it("excludes edits to the current file when excludePath is set", () => {
		const buf = new RecentEditsRingBuffer();
		buf.push({ path: "a.ts", languageId: "ts", snippet: "in a" });
		buf.push({ path: "b.ts", languageId: "ts", snippet: "in b" });
		buf.push({ path: "a.ts", languageId: "ts", snippet: "in a again" });
		const cross = buf.getRecent({ limit: 10, excludePath: "a.ts" });
		expect(cross).toHaveLength(1);
		expect(cross[0].path).toBe("b.ts");
	});

	it("limit slices to N entries even when more match", () => {
		const buf = new RecentEditsRingBuffer();
		for (let i = 0; i < 10; i++) {
			buf.push({ path: `f${i}.ts`, languageId: "ts", snippet: `s${i}` });
		}
		expect(buf.getRecent({ limit: 3 })).toHaveLength(3);
	});

	it("clear() empties the buffer", () => {
		const buf = new RecentEditsRingBuffer();
		buf.push({ path: "a.ts", languageId: "ts", snippet: "x" });
		buf.clear();
		expect(buf.size()).toBe(0);
		expect(buf.getRecent({ limit: 10 })).toEqual([]);
	});
});

describe("shouldRecordEdit", () => {
	it("accepts small edits (typing range)", () => {
		expect(shouldRecordEdit(1)).toBe(true);
		expect(shouldRecordEdit(50)).toBe(true);
		expect(shouldRecordEdit(500)).toBe(true);
	});

	it("rejects bulk writes that would flood the buffer", () => {
		expect(shouldRecordEdit(1000)).toBe(false);
		expect(shouldRecordEdit(50_000)).toBe(false);
	});

	it("rejects zero-length changes (deletion-only, no insertion text)", () => {
		expect(shouldRecordEdit(0)).toBe(false);
	});

	it("rejects negative deltas (defensive)", () => {
		expect(shouldRecordEdit(-1)).toBe(false);
	});
});

describe("buildEditSnippet", () => {
	it("slices a centered window around the edit offset", () => {
		const text = "abcdefghijklmnopqrstuvwxyz";
		const out = buildEditSnippet(text, 13, 10);
		// Centered around offset 13 (m) with 5 chars each side → "ijklmnopqr".
		expect(out.length).toBeLessThanOrEqual(10);
		expect(out).toContain("m");
	});

	it("clamps to document start when offset is near the beginning", () => {
		const out = buildEditSnippet("hello world", 2, 100);
		expect(out).toBe("hello world");
	});

	it("clamps to document end when offset is near the end", () => {
		const out = buildEditSnippet("hello world", 9, 100);
		expect(out).toBe("hello world");
	});

	it("collapses whitespace runs to a single space", () => {
		const out = buildEditSnippet("hello   \n\n  world", 8, 100);
		expect(out).toBe("hello world");
	});

	it("returns empty string for empty input", () => {
		expect(buildEditSnippet("", 0)).toBe("");
	});
});

describe("formatRecentEditsForPrompt", () => {
	it("returns empty string for empty input (caller uses this as the no-context signal)", () => {
		expect(formatRecentEditsForPrompt([])).toBe("");
	});

	it("wraps each edit in <edit path=... lang=...> tags within <recent_edits>", () => {
		const out = formatRecentEditsForPrompt([
			{ path: "a.ts", languageId: "typescript", snippet: "alpha", timestamp: 0 },
			{ path: "b.py", languageId: "python", snippet: "beta", timestamp: 0 },
		]);
		expect(out).toContain("<recent_edits>");
		expect(out).toContain("</recent_edits>");
		expect(out).toContain('path="a.ts"');
		expect(out).toContain('lang="typescript"');
		expect(out).toContain("alpha");
		expect(out).toContain('path="b.py"');
		expect(out).toContain('lang="python"');
		expect(out).toContain("beta");
	});

	it("preserves order (most-recent first when caller already reversed)", () => {
		const out = formatRecentEditsForPrompt([
			{ path: "a.ts", languageId: "ts", snippet: "first", timestamp: 0 },
			{ path: "b.ts", languageId: "ts", snippet: "second", timestamp: 0 },
		]);
		expect(out.indexOf("first")).toBeLessThan(out.indexOf("second"));
	});
});
