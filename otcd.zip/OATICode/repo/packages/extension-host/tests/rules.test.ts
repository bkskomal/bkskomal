import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { assembleRulesPrelude, hasGlobalRules, loadRules } from "../src/rules";

async function mkTempWorkspace(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "oati-rules-"));
}

async function writeRule(workspace: string, file: string, body: string): Promise<void> {
	const abs = path.join(workspace, ".oati", file);
	await fs.mkdir(path.dirname(abs), { recursive: true });
	await fs.writeFile(abs, body, "utf-8");
}

describe("rules host module (R5-B)", () => {
	let workspace: string;

	beforeEach(async () => {
		workspace = await mkTempWorkspace();
	});

	afterEach(async () => {
		await fs.rm(workspace, { recursive: true, force: true });
	});

	it("returns empty rules when .oati does not exist", async () => {
		const rules = await loadRules(workspace);
		expect(rules.global).toBe("");
		expect(rules.perLanguage).toEqual({});
	});

	it("loads rules.md as the global block", async () => {
		await writeRule(workspace, "rules.md", "Always be polite.");
		const rules = await loadRules(workspace);
		expect(rules.global).toBe("Always be polite.");
	});

	it("loads rules.<lang>.md for known languages", async () => {
		await writeRule(workspace, "rules.typescript.md", "Prefer interfaces over types.");
		const rules = await loadRules(workspace);
		expect(rules.perLanguage.typescript).toBe("Prefer interfaces over types.");
	});

	it("discovers unknown language slugs that appear on disk", async () => {
		await writeRule(workspace, "rules.zig.md", "use comptime");
		const rules = await loadRules(workspace);
		expect(rules.perLanguage.zig).toBe("use comptime");
	});

	it("assembleRulesPrelude returns empty when nothing applies", () => {
		expect(assembleRulesPrelude({ global: "", perLanguage: {} })).toBe("");
	});

	it("assembleRulesPrelude emits the global block and matching language block", () => {
		const text = assembleRulesPrelude(
			{ global: "G", perLanguage: { typescript: "T" } },
			"typescript",
		);
		expect(text).toContain("=== Project Rules ===");
		expect(text).toContain("G");
		expect(text).toContain("=== typescript Rules ===");
		expect(text).toContain("T");
	});

	it("assembleRulesPrelude ignores a language with no rules", () => {
		const text = assembleRulesPrelude({ global: "G", perLanguage: { typescript: "T" } }, "python");
		expect(text).toContain("G");
		expect(text).not.toContain("Rules ===\nT");
	});

	it("hasGlobalRules reports presence of rules.md", async () => {
		expect(await hasGlobalRules(workspace)).toBe(false);
		await writeRule(workspace, "rules.md", "x");
		expect(await hasGlobalRules(workspace)).toBe(true);
	});
});
