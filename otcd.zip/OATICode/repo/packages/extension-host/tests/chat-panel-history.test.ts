import type { ConversationMessage } from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { compactHistory } from "../src/history-compaction";

function user(text: string): ConversationMessage {
	return { role: "user", parts: [{ kind: "text", text }] };
}
function assistant(text: string): ConversationMessage {
	return { role: "assistant", parts: [{ kind: "text", text }] };
}

describe("compactHistory", () => {
	it("returns the history unchanged when it fits the head+tail window", async () => {
		const h: ConversationMessage[] = [user("a"), assistant("1"), user("b"), assistant("2")];
		const out = await compactHistory(h);
		expect(out).toEqual(h);
	});

	it("keeps the first 2 and last 10 and inserts a placeholder marker when no summarizer is supplied", async () => {
		const head: ConversationMessage[] = [user("framing"), assistant("ok")];
		const middle: ConversationMessage[] = Array.from({ length: 8 }, (_, i) => user(`m${i}`));
		const tail: ConversationMessage[] = Array.from({ length: 10 }, (_, i) => assistant(`t${i}`));
		const out = await compactHistory([...head, ...middle, ...tail]);
		// 2 head + 1 marker + 10 tail = 13
		expect(out).toHaveLength(13);
		expect(out[0]).toEqual(head[0]);
		expect(out[1]).toEqual(head[1]);
		expect(out[2].role).toBe("system");
		expect((out[2].parts[0] as { text: string }).text).toContain("8 messages compacted");
		expect(out.slice(3)).toEqual(tail);
	});

	it("uses the summarizer output when supplied and includes the dropped-count header", async () => {
		const head: ConversationMessage[] = [user("framing"), assistant("ok")];
		const middle: ConversationMessage[] = Array.from({ length: 5 }, (_, i) => user(`m${i}`));
		const tail: ConversationMessage[] = Array.from({ length: 10 }, (_, i) => assistant(`t${i}`));
		const summarize = vi.fn(async (segment: readonly ConversationMessage[]) => {
			expect(segment).toHaveLength(5);
			return "User wanted X. Agent did Y. Open question: Z.";
		});

		const out = await compactHistory([...head, ...middle, ...tail], { summarize });

		expect(summarize).toHaveBeenCalledTimes(1);
		expect(out).toHaveLength(13);
		const marker = out[2];
		expect(marker.role).toBe("system");
		const text = (marker.parts[0] as { text: string }).text;
		expect(text).toContain("Summary of 5 compacted messages");
		expect(text).toContain("User wanted X. Agent did Y. Open question: Z.");
	});

	it("falls back to the placeholder marker when the summarizer throws", async () => {
		const head: ConversationMessage[] = [user("framing"), assistant("ok")];
		const middle: ConversationMessage[] = Array.from({ length: 4 }, (_, i) => user(`m${i}`));
		const tail: ConversationMessage[] = Array.from({ length: 10 }, (_, i) => assistant(`t${i}`));
		const summarize = vi.fn(async () => {
			throw new Error("provider exploded");
		});

		const out = await compactHistory([...head, ...middle, ...tail], { summarize });

		expect(summarize).toHaveBeenCalledTimes(1);
		const text = (out[2].parts[0] as { text: string }).text;
		expect(text).toContain("4 messages compacted");
		expect(text).not.toContain("Summary of");
	});

	it("falls back to the placeholder when the summarizer returns an empty string", async () => {
		const head: ConversationMessage[] = [user("a"), assistant("b")];
		const middle: ConversationMessage[] = Array.from({ length: 3 }, (_, i) => user(`m${i}`));
		const tail: ConversationMessage[] = Array.from({ length: 10 }, (_, i) => assistant(`t${i}`));
		const out = await compactHistory([...head, ...middle, ...tail], {
			summarize: async () => "   ",
		});
		const text = (out[2].parts[0] as { text: string }).text;
		expect(text).toContain("3 messages compacted");
	});
});
