// 2026-06-02: unit tests for the inline-completion status-bar helpers.
// Focused on the pure label / tooltip / relative-time builders. The
// vscode integration (createStatusBarItem, registerCommand) is exercised
// via the deps-injection seam in registerInlineCompletionStatusBar but
// would require a vscode test shim to test end-to-end — out of scope
// here; the helpers below cover the rendering logic.

import { describe, expect, it } from "vitest";
import {
	buildStatusBarLabel,
	buildStatusBarTooltip,
	formatRelative,
} from "../src/inline-completion-status-bar";

describe("buildStatusBarLabel", () => {
	it("shows the idle 'OATI' label when no completions have been shown yet", () => {
		const label = buildStatusBarLabel({
			accepted: 0,
			rejected: 0,
			shown: 0,
			lastUpdatedIso: "",
		});
		expect(label).toContain("OATI");
		expect(label).not.toContain("%");
	});

	it("renders the acceptance rate as a percentage with N/M format", () => {
		const label = buildStatusBarLabel({
			accepted: 15,
			rejected: 6,
			shown: 21,
			lastUpdatedIso: "2026-06-02T10:00:00Z",
		});
		// 15/21 = 71.4% → rounds to 71%
		expect(label).toContain("71%");
		expect(label).toContain("(15/21)");
	});

	it("rounds 50% cases correctly", () => {
		const label = buildStatusBarLabel({
			accepted: 1,
			rejected: 1,
			shown: 2,
			lastUpdatedIso: "",
		});
		expect(label).toContain("50%");
		expect(label).toContain("(1/2)");
	});

	it("handles a perfect 100% accept rate", () => {
		const label = buildStatusBarLabel({
			accepted: 10,
			rejected: 0,
			shown: 10,
			lastUpdatedIso: "",
		});
		expect(label).toContain("100%");
	});

	it("handles a 0% rate (all rejected/dismissed) when shown > 0", () => {
		const label = buildStatusBarLabel({
			accepted: 0,
			rejected: 5,
			shown: 5,
			lastUpdatedIso: "",
		});
		expect(label).toContain("0%");
		expect(label).toContain("(0/5)");
	});
});

describe("buildStatusBarTooltip", () => {
	it("shows the empty-state hint when shown === 0", () => {
		const tip = buildStatusBarTooltip({
			accepted: 0,
			rejected: 0,
			shown: 0,
			lastUpdatedIso: "",
		});
		expect(tip).toContain("No completions shown yet");
	});

	it("lists accepted / rejected / shown counts", () => {
		const tip = buildStatusBarTooltip({
			accepted: 12,
			rejected: 4,
			shown: 20,
			lastUpdatedIso: "",
		});
		expect(tip).toContain("Acceptance rate");
		expect(tip).toContain("60%"); // 12/20
		expect(tip).toContain("Accepted: 12");
		expect(tip).toContain("Rejected: 4");
		expect(tip).toContain("Shown: 20");
	});

	it("surfaces the implicit-dismiss count when shown > accepted + rejected", () => {
		const tip = buildStatusBarTooltip({
			accepted: 5,
			rejected: 5,
			shown: 20, // 10 dismissed by typing past
			lastUpdatedIso: "",
		});
		expect(tip).toContain("Dismissed by typing past: 10");
	});

	it("does NOT show the implicit-dismiss line when there are none", () => {
		const tip = buildStatusBarTooltip({
			accepted: 7,
			rejected: 3,
			shown: 10,
			lastUpdatedIso: "",
		});
		expect(tip).not.toContain("Dismissed by typing past");
	});

	it("includes the click-to-reset hint", () => {
		const tip = buildStatusBarTooltip({ accepted: 1, rejected: 0, shown: 1, lastUpdatedIso: "" });
		expect(tip).toContain("Click");
	});
});

describe("formatRelative", () => {
	const NOW = Date.parse("2026-06-02T12:00:00Z");

	it("formats seconds-ago", () => {
		expect(formatRelative("2026-06-02T11:59:30Z", NOW)).toBe("30s ago");
	});

	it("formats minutes-ago", () => {
		expect(formatRelative("2026-06-02T11:55:00Z", NOW)).toBe("5m ago");
	});

	it("formats hours-ago", () => {
		expect(formatRelative("2026-06-02T09:00:00Z", NOW)).toBe("3h ago");
	});

	it("formats days-ago", () => {
		expect(formatRelative("2026-05-30T12:00:00Z", NOW)).toBe("3d ago");
	});

	it("returns the input unchanged for an unparseable timestamp", () => {
		expect(formatRelative("not-a-date", NOW)).toBe("not-a-date");
	});

	it("clamps negative deltas to 0s (future timestamps don't render as negatives)", () => {
		expect(formatRelative("2026-06-02T12:00:30Z", NOW)).toBe("0s ago");
	});
});
