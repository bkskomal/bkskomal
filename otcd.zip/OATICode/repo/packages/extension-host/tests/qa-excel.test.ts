import { promises as fsp } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import ExcelJS from "exceljs";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	defaultSchema,
	readTemplateSchema,
	resolveSchema,
	writePlanWorkbook,
} from "../src/qa-excel";

let tmpDir: string;

beforeEach(async () => {
	tmpDir = await fsp.mkdtemp(path.join(os.tmpdir(), "oati-qa-excel-"));
});

afterEach(async () => {
	await fsp.rm(tmpDir, { recursive: true, force: true });
});

describe("defaultSchema", () => {
	it("provides 13 columns for functional plans", () => {
		const s = defaultSchema("functional");
		expect(s.allHeaders).toContain("TC-ID");
		expect(s.allHeaders).toContain("Steps");
		expect(s.allHeaders).toContain("Expected Result");
		expect(s.allHeaders).toContain("Status");
		expect(s.columnByConcept.tcId).toBe(1);
	});

	it("provides 10 columns for unit plans", () => {
		const s = defaultSchema("unit");
		expect(s.allHeaders).toContain("File");
		expect(s.allHeaders).toContain("Function");
		expect(s.allHeaders).toContain("Test Data");
	});
});

describe("readTemplateSchema", () => {
	it("returns undefined for a non-existent file", async () => {
		const result = await readTemplateSchema(path.join(tmpDir, "missing.xlsx"), "functional");
		expect(result).toBeUndefined();
	});

	it("detects header row + maps fuzzy synonyms to concepts", async () => {
		// Build a synthetic template with non-default header names.
		const wb = new ExcelJS.Workbook();
		const ws = wb.addWorksheet("plan");
		// Row 1 is a banner.
		ws.addRow(["My Team's QA Template"]);
		// Row 2 is empty.
		ws.addRow([]);
		// Row 3 is the real header.
		ws.addRow([
			"Test ID",
			"Area",
			"Sub Module",
			"Test Scenario",
			"Setup",
			"Test Steps",
			"Expected Outcome",
			"Severity",
			"Test Type",
			"Result",
			"Actual Outcome",
			"Run By",
			"Executed On",
			"Defect Link", // extra column the user added — should be preserved as opaque
		]);
		const templatePath = path.join(tmpDir, "template.xlsx");
		await wb.xlsx.writeFile(templatePath);

		const schema = await readTemplateSchema(templatePath, "functional");
		expect(schema).toBeDefined();
		if (!schema) return;
		// Banner + empty + headers → header row should be 3.
		expect(schema.headerRowIndex).toBe(3);
		// All 14 headers including the extra user column.
		expect(schema.allHeaders).toHaveLength(14);
		expect(schema.allHeaders).toContain("Defect Link");
		// Fuzzy mapping: "Test ID" → tcId, "Test Steps" → steps, etc.
		expect(schema.headerByConcept.tcId).toBe("Test ID");
		expect(schema.headerByConcept.steps).toBe("Test Steps");
		expect(schema.headerByConcept.expected).toBe("Expected Outcome");
		expect(schema.headerByConcept.status).toBe("Result");
	});
});

describe("resolveSchema", () => {
	it("falls back to defaults when no template exists", async () => {
		const { schema, templatePath } = await resolveSchema({
			workspaceRoot: tmpDir,
			kind: "functional",
			fileExists: async () => false,
		});
		expect(templatePath).toBeUndefined();
		expect(schema.allHeaders).toContain("TC-ID");
	});

	it("picks up a template when one is present", async () => {
		const wb = new ExcelJS.Workbook();
		const ws = wb.addWorksheet("plan");
		ws.addRow(["Test ID", "Module", "Title", "Steps", "Expected", "Status"]);
		const templateRel = "templates/qa-functional-template.xlsx";
		const templateAbs = path.join(tmpDir, templateRel);
		await fsp.mkdir(path.dirname(templateAbs), { recursive: true });
		await wb.xlsx.writeFile(templateAbs);

		const { schema, templatePath } = await resolveSchema({
			workspaceRoot: tmpDir,
			kind: "functional",
			fileExists: async (abs) => {
				try {
					await fsp.stat(abs);
					return true;
				} catch {
					return false;
				}
			},
		});
		expect(templatePath).toBe(templateRel);
		expect(schema.allHeaders).toHaveLength(6);
		expect(schema.headerByConcept.tcId).toBe("Test ID");
	});
});

describe("writePlanWorkbook", () => {
	it("writes a fresh workbook with default schema + cases", async () => {
		const outPath = path.join(tmpDir, "out.xlsx");
		const schema = defaultSchema("functional");
		await writePlanWorkbook({
			absPath: outPath,
			kind: "functional",
			schema,
			workspaceRoot: tmpDir,
			projectName: "Demo",
			generatedAt: new Date("2026-05-28T10:00:00Z"),
			cases: [
				{
					tcId: "TC-001",
					module: "Auth",
					feature: "Login",
					title: "Login with valid credentials",
					preconditions: "User exists",
					steps: "1. Open /login\n2. Enter creds\n3. Click submit",
					expected: "Redirect to /dashboard",
					priority: "Critical",
					type: "Smoke",
				},
			],
		});

		// Read back and verify shape.
		const wb = new ExcelJS.Workbook();
		await wb.xlsx.readFile(outPath);
		const ws = wb.worksheets[0];
		expect(ws.getCell("A1").value).toBe("TC-ID");
		// Status / Actual / Tester / Date should be empty in row 2.
		const statusCol = schema.columnByConcept.status;
		const titleCol = schema.columnByConcept.title;
		expect(ws.getRow(2).getCell(titleCol).value).toBe("Login with valid credentials");
		expect(ws.getRow(2).getCell(statusCol).value).toBe("");
	});

	it("preserves user-added columns when writing through a template", async () => {
		// Set up a template with an extra "Defect Link" column.
		const tplWb = new ExcelJS.Workbook();
		const tplWs = tplWb.addWorksheet("plan");
		tplWs.addRow(["TC-ID", "Title", "Steps", "Status", "Defect Link"]);
		const tplRel = "templates/qa-functional-template.xlsx";
		const tplAbs = path.join(tmpDir, tplRel);
		await fsp.mkdir(path.dirname(tplAbs), { recursive: true });
		await tplWb.xlsx.writeFile(tplAbs);

		const { schema } = await resolveSchema({
			workspaceRoot: tmpDir,
			kind: "functional",
			fileExists: async (abs) => {
				try {
					await fsp.stat(abs);
					return true;
				} catch {
					return false;
				}
			},
		});

		const outPath = path.join(tmpDir, "out.xlsx");
		await writePlanWorkbook({
			absPath: outPath,
			kind: "functional",
			schema,
			templatePath: tplRel,
			workspaceRoot: tmpDir,
			projectName: "Demo",
			generatedAt: new Date(),
			cases: [
				{
					tcId: "TC-001",
					module: "Auth",
					feature: "Login",
					title: "Valid login",
					preconditions: "",
					steps: "Open login page",
					expected: "Dashboard shown",
					priority: "High",
					type: "Smoke",
				},
			],
		});

		const wb = new ExcelJS.Workbook();
		await wb.xlsx.readFile(outPath);
		const ws = wb.worksheets[0];
		// The user's "Defect Link" header must still be there.
		expect(ws.getRow(1).getCell(5).value).toBe("Defect Link");
		// Title cell populated, status empty.
		expect(ws.getRow(2).getCell(2).value).toBe("Valid login");
		expect(ws.getRow(2).getCell(4).value).toBe("");
	});
});
