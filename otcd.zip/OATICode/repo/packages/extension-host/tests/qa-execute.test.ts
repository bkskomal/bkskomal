import { describe, expect, it } from "vitest";
import {
	type ExecutionResult,
	type TestCaseRow,
	classifyTestCase,
	hasDestructiveIntent,
	summarize,
} from "../src/qa-execute";

function row(partial: Partial<TestCaseRow>): TestCaseRow {
	return {
		rowNumber: partial.rowNumber ?? 2,
		tcId: partial.tcId ?? "TC-001",
		title: partial.title ?? "case",
		...(partial.file !== undefined ? { file: partial.file } : {}),
		...(partial.function !== undefined ? { function: partial.function } : {}),
		...(partial.steps !== undefined ? { steps: partial.steps } : {}),
		...(partial.expected !== undefined ? { expected: partial.expected } : {}),
		...(partial.testData !== undefined ? { testData: partial.testData } : {}),
		...(partial.status !== undefined ? { status: partial.status } : {}),
	};
}

describe("hasDestructiveIntent", () => {
	it("matches obvious destructive keywords on word boundary", () => {
		expect(hasDestructiveIntent("delete user account")).toBe(true);
		expect(hasDestructiveIntent("Drop table users")).toBe(true);
		expect(hasDestructiveIntent("purge audit log")).toBe(true);
		expect(hasDestructiveIntent("reset password")).toBe(true);
		expect(hasDestructiveIntent("truncate analytics")).toBe(true);
	});

	it("does NOT match substring false-positives", () => {
		// "completed" contains "lete" but not "delete" on a word boundary.
		expect(hasDestructiveIntent("test completed successfully")).toBe(false);
		// "resetCounter" should match (word boundary on camelCase? — no, but
		// our pattern only checks for whole-word matches via \b in regex).
		expect(hasDestructiveIntent("resetCounter")).toBe(false);
	});

	it("handles undefined / empty inputs", () => {
		expect(hasDestructiveIntent(undefined)).toBe(false);
		expect(hasDestructiveIntent("")).toBe(false);
	});

	it("matches multi-word phrases", () => {
		expect(hasDestructiveIntent("remove all users")).toBe(true);
	});
});

describe("classifyTestCase", () => {
	it("routes unit when file + function are both present", () => {
		expect(
			classifyTestCase(row({ file: "src/auth.ts", function: "validate", title: "happy path" })),
		).toBe("unit");
	});

	it("routes ui when steps mention a localhost URL", () => {
		expect(
			classifyTestCase(
				row({
					title: "login flow",
					steps: "1. Go to http://localhost:3000/login\n2. Enter creds",
				}),
			),
		).toBe("ui");
	});

	it("routes ask_user when no concrete file OR localhost URL is present", () => {
		expect(classifyTestCase(row({ title: "some manual check", steps: "Read the docs" }))).toBe(
			"ask_user",
		);
	});

	it("downgrades destructive UI tests to ask_user", () => {
		expect(
			classifyTestCase(
				row({
					title: "delete user account",
					steps: "Go to http://localhost:3000/admin",
				}),
			),
		).toBe("ask_user");
	});

	it("downgrades destructive unit tests to ask_user", () => {
		expect(
			classifyTestCase(
				row({
					file: "src/users.ts",
					function: "purgeAll",
					title: "purge cleans every row",
				}),
			),
		).toBe("ask_user");
	});

	it("refuses UI when a non-localhost URL appears in steps", () => {
		// Mixed: localhost + external. We treat any external URL as
		// disqualifying for auto-execution.
		expect(
			classifyTestCase(
				row({
					title: "API smoke",
					steps:
						"POST http://localhost:3000/api/x with body fetched from https://prod.example.com/users",
				}),
			),
		).toBe("ask_user");
	});

	it("ignores 'function' value of 'none'", () => {
		// Plan generators sometimes write `function: "none"` for non-function
		// scenarios — should NOT route to unit on that signal alone.
		expect(classifyTestCase(row({ file: "src/x.ts", function: "none", title: "smoke" }))).toBe(
			"ask_user",
		);
	});
});

describe("summarize", () => {
	it("counts statuses + routes correctly", () => {
		const results: ExecutionResult[] = [
			{ rowNumber: 2, tcId: "TC-001", route: "unit", status: "Pass", actual: "ok" },
			{ rowNumber: 3, tcId: "TC-002", route: "unit", status: "Fail", actual: "x" },
			{ rowNumber: 4, tcId: "TC-003", route: "ask_user", status: "Pass", actual: "ok" },
			{ rowNumber: 5, tcId: "TC-004", route: "ui", status: "Blocked", actual: "no spawner" },
		];
		const s = summarize(results);
		expect(s.total).toBe(4);
		expect(s.pass).toBe(2);
		expect(s.fail).toBe(1);
		expect(s.blocked).toBe(1);
		expect(s.byRoute.unit).toBe(2);
		expect(s.byRoute.ask_user).toBe(1);
		expect(s.byRoute.ui).toBe(1);
	});
});
