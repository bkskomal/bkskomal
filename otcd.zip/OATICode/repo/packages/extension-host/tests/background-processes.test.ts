// Integration test for the BackgroundProcessRegistry — actually spawns a
// short-lived process so we know the cross-platform spawn + capture +
// cleanup chain works end-to-end. Avoids dev-server-style commands that
// would hang the test runner; uses platform-portable `node -e` instead.

import { describe, expect, it } from "vitest";
import { BackgroundProcessRegistry } from "../src/background-processes";

const NODE = process.execPath;

describe("BackgroundProcessRegistry (real spawn)", () => {
	it("spawns a process, captures early stdout, and tracks the PID", async () => {
		const reg = new BackgroundProcessRegistry();
		// Print, then sleep a bit longer than the wait window so the
		// process is still "running" when start() returns. Wait window
		// is 1200ms to be robust under concurrent vitest worker load
		// where the spawn itself can take 400-600ms before stdout flows.
		const handle = await reg.start(
			`${quote(NODE)} -e "process.stdout.write('hello-bg\\n'); setTimeout(()=>{}, 5000)"`,
			process.cwd(),
			{ waitForOutputMs: 1200 },
		);
		expect(handle.pid).toBeGreaterThan(0);
		expect(handle.earlyStdout).toMatch(/hello-bg/);
		expect(handle.exitedDuringWait).toBeUndefined();
		expect(reg.list()).toHaveLength(1);
		expect(reg.list()[0].pid).toBe(handle.pid);

		const stop = await reg.stop(handle.pid);
		expect(stop.killed).toBe(true);
		expect(reg.list()).toHaveLength(0);
	});

	it("reports exitedDuringWait when the command exits inside the wait window", async () => {
		const reg = new BackgroundProcessRegistry();
		// Exit immediately with code 7.
		const handle = await reg.start(`${quote(NODE)} -e "process.exit(7)"`, process.cwd(), {
			waitForOutputMs: 1500,
		});
		expect(handle.exitedDuringWait).toBe(7);
		// Not tracked after early exit — `list` should be empty.
		expect(reg.list()).toHaveLength(0);
	});

	it("stop returns killed:false for an unknown pid", async () => {
		const reg = new BackgroundProcessRegistry();
		const out = await reg.stop(999_999);
		expect(out.killed).toBe(false);
	});

	it("disposeAll kills every tracked process", async () => {
		const reg = new BackgroundProcessRegistry();
		const h1 = await reg.start(`${quote(NODE)} -e "setTimeout(()=>{}, 10000)"`, process.cwd(), {
			waitForOutputMs: 1000,
		});
		const h2 = await reg.start(`${quote(NODE)} -e "setTimeout(()=>{}, 10000)"`, process.cwd(), {
			waitForOutputMs: 1000,
		});
		expect(reg.list()).toHaveLength(2);
		reg.disposeAll();
		// disposeAll schedules stops; SIGTERM has a 500ms grace before
		// SIGKILL inside the registry, so wait at least that long plus
		// headroom for the OS to actually reap the processes.
		await new Promise<void>((resolve) => setTimeout(resolve, 1500));
		expect(reg.list()).toHaveLength(0);
		// Sanity: PIDs were distinct.
		expect(h1.pid).not.toBe(h2.pid);
	});
});

/**
 * Cross-platform shell-quote a single argument. The registry uses
 * `shell: true` so spaces in paths (`C:\Program Files\nodejs\node.exe`)
 * have to be quoted by the caller.
 */
function quote(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}
