import { describe, expect, it } from "vitest";
import {
	computeHunks,
	createInlineDiffSession,
	isFullyResolved,
	pickInlineDiffMode,
	resolveAcceptedText,
	setHunkStatus,
} from "../src/inline-diff";

describe("computeHunks", () => {
	it("emits no hunks when before == after", () => {
		expect(computeHunks("a\nb\nc", "a\nb\nc")).toEqual([]);
	});

	it("detects a single insertion at the end", () => {
		const hunks = computeHunks("a\nb", "a\nb\nc");
		expect(hunks).toHaveLength(1);
		expect(hunks[0].addedLines).toEqual(["c"]);
		expect(hunks[0].removedLines).toEqual([]);
		expect(hunks[0].beforeStartLine).toBe(2);
		expect(hunks[0].afterStartLine).toBe(2);
	});

	it("detects a deletion in the middle", () => {
		const hunks = computeHunks("a\nb\nc", "a\nc");
		expect(hunks).toHaveLength(1);
		expect(hunks[0].removedLines).toEqual(["b"]);
		expect(hunks[0].addedLines).toEqual([]);
	});

	it("splits non-adjacent changes into separate hunks", () => {
		const hunks = computeHunks("a\nb\nc\nd\ne", "a\nB\nc\nD\ne");
		expect(hunks).toHaveLength(2);
		expect(hunks[0].removedLines).toEqual(["b"]);
		expect(hunks[0].addedLines).toEqual(["B"]);
		expect(hunks[1].removedLines).toEqual(["d"]);
		expect(hunks[1].addedLines).toEqual(["D"]);
	});

	it("treats a whole-file rewrite as a single hunk", () => {
		const hunks = computeHunks("old\nstuff", "completely\nnew\nfile");
		expect(hunks).toHaveLength(1);
		expect(hunks[0].removedLines).toEqual(["old", "stuff"]);
		expect(hunks[0].addedLines).toEqual(["completely", "new", "file"]);
	});
});

describe("resolveAcceptedText", () => {
	const diff = { path: "x.ts", before: "a\nb\nc\nd\ne", after: "a\nB\nc\nD\ne" };

	it("returns the original buffer when no hunks are accepted", () => {
		const s = createInlineDiffSession(diff);
		expect(resolveAcceptedText(s)).toBe(diff.before);
	});

	it("returns the proposed buffer when all hunks are accepted", () => {
		let s = createInlineDiffSession(diff);
		for (const h of s.hunks) s = setHunkStatus(s, h.id, "accepted");
		expect(resolveAcceptedText(s)).toBe(diff.after);
	});

	it("mixes accepted and rejected hunks", () => {
		let s = createInlineDiffSession(diff);
		// accept the first ("b" -> "B"), reject the second ("d" stays as "d")
		s = setHunkStatus(s, s.hunks[0].id, "accepted");
		s = setHunkStatus(s, s.hunks[1].id, "rejected");
		expect(resolveAcceptedText(s)).toBe("a\nB\nc\nd\ne");
	});

	it("substitutes user-provided text for modified hunks", () => {
		let s = createInlineDiffSession(diff);
		s = setHunkStatus(s, s.hunks[0].id, "modified");
		s = setHunkStatus(s, s.hunks[1].id, "accepted");
		const out = resolveAcceptedText(s, { [s.hunks[0].id]: "X" });
		expect(out).toBe("a\nX\nc\nD\ne");
	});

	it("preserves CRLF endings round-trip", () => {
		const crlfDiff = { path: "x.ts", before: "a\r\nb\r\nc", after: "a\r\nB\r\nc" };
		let s = createInlineDiffSession(crlfDiff);
		s = setHunkStatus(s, s.hunks[0].id, "accepted");
		expect(resolveAcceptedText(s)).toBe(crlfDiff.after);
	});
});

describe("isFullyResolved", () => {
	it("returns false while any hunk is still pending", () => {
		const s = createInlineDiffSession({ path: "x.ts", before: "a\nb", after: "a\nB" });
		expect(isFullyResolved(s)).toBe(false);
	});

	it("returns true once every hunk has been resolved", () => {
		let s = createInlineDiffSession({ path: "x.ts", before: "a\nb\nc", after: "a\nB\nC" });
		for (const h of s.hunks) s = setHunkStatus(s, h.id, "accepted");
		expect(isFullyResolved(s)).toBe(true);
	});
});

describe("pickInlineDiffMode", () => {
	it("falls back to review for non-autoApprove modes", () => {
		expect(pickInlineDiffMode({})).toBe("review");
	});

	it("falls back to auto-apply for autoApprove modes", () => {
		expect(pickInlineDiffMode({ autoApprove: true })).toBe("auto-apply");
	});

	it("respects explicit inlineDiffMode", () => {
		expect(pickInlineDiffMode({ autoApprove: true, inlineDiffMode: "review" })).toBe("review");
		expect(pickInlineDiffMode({ inlineDiffMode: "auto-apply" })).toBe("auto-apply");
	});
});
