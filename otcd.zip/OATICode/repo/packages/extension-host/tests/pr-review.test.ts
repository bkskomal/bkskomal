import { describe, expect, it } from "vitest";
import { PR_REVIEW_SYSTEM_PROMPT, parsePrUrl } from "../src/pr-review";

describe("parsePrUrl", () => {
	it("parses a canonical github.com PR URL", () => {
		expect(parsePrUrl("https://github.com/owner/repo/pull/123")).toEqual({
			owner: "owner",
			repo: "repo",
			number: 123,
		});
	});

	it("accepts http and www. variants", () => {
		expect(parsePrUrl("http://www.github.com/o/r/pull/7")).toEqual({
			owner: "o",
			repo: "r",
			number: 7,
		});
	});

	it("tolerates a trailing path or query string", () => {
		expect(parsePrUrl("https://github.com/o/r/pull/9/files?w=1")).toEqual({
			owner: "o",
			repo: "r",
			number: 9,
		});
	});

	it("strips a trailing .git from the repo", () => {
		expect(parsePrUrl("https://github.com/o/r.git/pull/5")).toEqual({
			owner: "o",
			repo: "r",
			number: 5,
		});
	});

	it("accepts the shorthand owner/repo#NN form", () => {
		expect(parsePrUrl("octocat/hello#42")).toEqual({
			owner: "octocat",
			repo: "hello",
			number: 42,
		});
	});

	it("rejects nonsense URLs", () => {
		expect(parsePrUrl("not a url")).toBeUndefined();
		expect(parsePrUrl("https://github.com/owner/repo/issues/123")).toBeUndefined();
		expect(parsePrUrl("https://gitlab.com/owner/repo/pull/1")).toBeUndefined();
		expect(parsePrUrl("https://github.com/owner/repo/pull/0")).toBeUndefined();
	});
});

describe("PR_REVIEW_SYSTEM_PROMPT", () => {
	it("calls out the three required sections", () => {
		expect(PR_REVIEW_SYSTEM_PROMPT).toContain("High-level summary");
		expect(PR_REVIEW_SYSTEM_PROMPT).toContain("Per-file issues");
		expect(PR_REVIEW_SYSTEM_PROMPT).toContain("Blocking concerns vs nitpicks");
	});
});
