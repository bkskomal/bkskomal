import { describe, expect, it } from "vitest";
import type { QAResult } from "../src/qa";
import { buildQAReport, buildReportPath, buildReviewReport } from "../src/report-builder";
import type { ReviewResult } from "../src/review";

const META = {
	projectName: "TestProject",
	model: "kimi-k2-6",
	generatedAt: new Date("2026-05-27T10:30:00Z"),
};

describe("buildReviewReport", () => {
	it("produces a non-empty Buffer for a clean review", async () => {
		const result: ReviewResult = {
			findings: [],
			summary: "Clean review.",
			counts: { blocking: 0, advisory: 0, off: 0 },
			skipped: [],
		};
		const buf = await buildReviewReport(result, META);
		expect(buf.length).toBeGreaterThan(2000);
		// All .docx files (which are zip archives) start with PK.
		expect(buf.slice(0, 2).toString("ascii")).toBe("PK");
	});

	it("includes findings with line numbers and diff blocks", async () => {
		const result: ReviewResult = {
			findings: [
				{
					path: "src/auth/login.ts",
					line: 42,
					category: "security",
					severity: "blocking",
					title: "SQL injection vector",
					detail: "Concatenated string in query.",
					suggestion: "Use parameterized queries.",
					suggestedFix: {
						before: "const q = 'SELECT * FROM users WHERE name = ' + name",
						after: "const q = 'SELECT * FROM users WHERE name = ?'; db.run(q, [name])",
						rationale: "Prevents injection.",
					},
				},
			],
			summary: "1 finding",
			counts: { blocking: 1, advisory: 0, off: 0 },
			skipped: [],
		};
		const buf = await buildReviewReport(result, META);
		expect(buf.length).toBeGreaterThan(3000);
		expect(buf.slice(0, 2).toString("ascii")).toBe("PK");
	});

	it("handles skipped files section", async () => {
		const result: ReviewResult = {
			findings: [],
			summary: "skipped only",
			counts: { blocking: 0, advisory: 0, off: 0 },
			skipped: [{ path: "missing.ts", reason: "ENOENT" }],
		};
		const buf = await buildReviewReport(result, META);
		expect(buf.slice(0, 2).toString("ascii")).toBe("PK");
	});
});

describe("buildQAReport", () => {
	it("produces a non-empty Buffer for a basic QA result", async () => {
		const result: QAResult = {
			subcommand: "plan",
			summary: "Generated a test plan.",
			artifacts: [{ path: "TEST_PLAN.md", content: "# Plan", purpose: "Test plan document" }],
			notes: [],
			needsTestRun: false,
		};
		const buf = await buildQAReport(result, META);
		expect(buf.length).toBeGreaterThan(2000);
		expect(buf.slice(0, 2).toString("ascii")).toBe("PK");
	});

	it("includes issues with suggested fixes when present", async () => {
		const result: QAResult = {
			subcommand: "security",
			summary: "Found 2 issues.",
			artifacts: [],
			notes: ["Consider adding rate limiting."],
			needsTestRun: false,
			issues: [
				{
					path: "src/api/users.ts",
					line: 17,
					category: "security:sql-injection",
					severity: "blocking",
					title: "Unsanitized input in SQL",
					detail: "Direct string concat in WHERE clause.",
					suggestedFix: {
						before: "WHERE name = '${name}'",
						after: "WHERE name = ? -- params: [name]",
					},
				},
				{
					path: "src/api/users.ts",
					line: 42,
					category: "security:weak-crypto",
					severity: "advisory",
					title: "MD5 used for password hash",
					detail: "MD5 is cryptographically broken.",
				},
			],
		};
		const buf = await buildQAReport(result, META);
		expect(buf.length).toBeGreaterThan(3000);
		expect(buf.slice(0, 2).toString("ascii")).toBe("PK");
	});

	it("handles artifacts-only QA results (e.g. /qa unit)", async () => {
		const result: QAResult = {
			subcommand: "unit",
			summary: "Generated 3 unit tests.",
			artifacts: [
				{ path: "tests/a.test.ts", content: "...", purpose: "tests a" },
				{ path: "tests/b.test.ts", content: "...", purpose: "tests b" },
			],
			notes: [],
			needsTestRun: true,
		};
		const buf = await buildQAReport(result, META);
		expect(buf.slice(0, 2).toString("ascii")).toBe("PK");
	});
});

describe("buildReportPath", () => {
	it("defaults to reports/ when no dir configured", () => {
		const p = buildReportPath(undefined, "code-review", undefined, new Date("2026-05-27T10:30:45Z"));
		expect(p.startsWith("reports/")).toBe(true);
		expect(p.endsWith(".docx")).toBe(true);
		expect(p).toContain("code-review");
	});

	it("respects custom output directory", () => {
		const p = buildReportPath("audit/2026", "code-review", undefined, new Date());
		expect(p.startsWith("audit/2026/")).toBe(true);
	});

	it("normalizes Windows backslashes to forward slashes", () => {
		const p = buildReportPath("audit\\reports", "qa", "security", new Date());
		expect(p).not.toContain("\\");
		expect(p).toContain("audit/reports/");
	});

	it("incorporates QA subcommand into the filename", () => {
		const p = buildReportPath(undefined, "qa", "security", new Date("2026-05-27T10:30:00Z"));
		expect(p).toContain("qa-security");
	});

	it("ISO-friendly timestamp (no colons / dots in the basename)", () => {
		const p = buildReportPath(
			undefined,
			"code-review",
			undefined,
			new Date("2026-05-27T10:30:45.123Z"),
		);
		const basename = p.split("/").pop() ?? "";
		expect(basename).not.toContain(":");
		expect(basename).not.toContain(".docx".repeat(2)); // sanity — extension only once
		// the timestamp segment should be of form 2026-05-27T10-30-45
		expect(basename).toMatch(/2026-05-27T10-30-45/);
	});

	it("trims trailing slashes from output dir", () => {
		const p = buildReportPath("reports/", "code-review", undefined, new Date());
		expect(p).not.toContain("//");
	});
});
