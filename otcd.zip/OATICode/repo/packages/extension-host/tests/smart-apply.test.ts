import { describe, expect, it } from "vitest";
import { computeSmartHunks, smartApplyEdit } from "../src/smart-apply";

describe("smartApplyEdit", () => {
	it("clean-applies when current === before", () => {
		const before = "a\nb\nc\n";
		const after = "a\nB\nc\n";
		const res = smartApplyEdit("x.ts", before, after, before);
		expect(res.status).toBe("clean");
		expect(res.merged).toBe(after);
		expect(res.conflictHunks).toBeUndefined();
	});

	it("no-op edit returns current untouched even on drift", () => {
		const before = "a\nb\n";
		const after = "a\nb\n";
		const current = "a\nB\n";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("clean");
		expect(res.merged).toBe(current);
	});

	it("merges when the hunk's context shifted lower in the file", () => {
		// Agent saw a 3-line file; user inserted a new top line before write.
		const before = "alpha\nbeta\ngamma";
		const after = "alpha\nBETA\ngamma";
		const current = "HEADER\nalpha\nbeta\ngamma";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("merged");
		expect(res.merged).toBe("HEADER\nalpha\nBETA\ngamma");
	});

	it("merges multiple hunks when each finds its context", () => {
		const before = "a\nb\nc\nd\ne";
		const after = "a\nB\nc\nD\ne";
		// User inserted lines around the edits but didn't change b/d.
		const current = "PRE\na\nb\nc\nMID\nd\ne\nPOST";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("merged");
		expect(res.merged).toBe("PRE\na\nB\nc\nMID\nD\ne\nPOST");
	});

	it("fuzzy-matches on whitespace when context lines differ only in indent", () => {
		const before = "func foo() {\n  return 1\n}";
		const after = "func foo() {\n  return 2\n}";
		// User reindented with a tab; logically same context.
		const current = "func foo() {\n\treturn 1\n}";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("merged");
		// The merged output preserves the agent's intent for the changed line.
		expect(res.merged.split("\n")).toContain("  return 2");
	});

	it("produces conflict markers when removed region drifted", () => {
		const before = "x\nold\ny";
		const after = "x\nnew\ny";
		// User edited the middle line to something else entirely; we kept the
		// surrounding context so the anchor still matches.
		const current = "x\nuser-edit\ny";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("conflict");
		expect(res.merged).toContain("<<<<<<< current");
		expect(res.merged).toContain("user-edit");
		expect(res.merged).toContain("=======");
		expect(res.merged).toContain("new");
		expect(res.merged).toContain(">>>>>>> incoming");
		expect(res.conflictHunks).toBeDefined();
		expect(res.conflictHunks?.length).toBeGreaterThan(0);
	});

	it("emits trailing conflict block when context cannot be located at all", () => {
		const before = "anchor-line\nold\ntail";
		const after = "anchor-line\nnew\ntail";
		const current = "completely-different\nfile\ncontents";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("conflict");
		expect(res.merged).toContain("<<<<<<<");
		expect(res.merged).toContain("new");
		expect(res.merged).toContain(">>>>>>>");
	});

	it("handles pure insertion at end of file", () => {
		const before = "one\ntwo";
		const after = "one\ntwo\nthree";
		const current = "one\ntwo";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("clean");
		expect(res.merged).toBe("one\ntwo\nthree");
	});

	it("handles pure deletion when context still matches", () => {
		const before = "a\nb\nc\nd";
		const after = "a\nc\nd";
		const current = "HEADER\na\nb\nc\nd";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.status).toBe("merged");
		expect(res.merged).toBe("HEADER\na\nc\nd");
	});

	it("preserves trailing newline from current", () => {
		const before = "a\nb\n";
		const after = "a\nB\n";
		const current = "a\nb\n";
		const res = smartApplyEdit("x.ts", before, after, current);
		expect(res.merged.endsWith("\n")).toBe(true);
	});
});

describe("computeSmartHunks", () => {
	it("returns no hunks when before == after", () => {
		expect(computeSmartHunks("a\nb", "a\nb")).toEqual([]);
	});

	it("annotates each hunk with surrounding context", () => {
		const hunks = computeSmartHunks("a\nb\nc\nd\ne", "a\nb\nX\nd\ne");
		expect(hunks).toHaveLength(1);
		expect(hunks[0].contextBefore).toEqual(["a", "b"]);
		expect(hunks[0].contextAfter).toEqual(["d", "e"]);
		expect(hunks[0].removed).toEqual(["c"]);
		expect(hunks[0].added).toEqual(["X"]);
	});
});
