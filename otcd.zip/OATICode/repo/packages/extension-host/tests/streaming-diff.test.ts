import { describe, expect, it } from "vitest";
import { type StreamingDiffEvent, StreamingDiffParser } from "../src/streaming-diff";

function collect(parser: StreamingDiffParser): StreamingDiffEvent[] {
	const events: StreamingDiffEvent[] = [];
	parser.on((ev) => events.push(ev));
	return events;
}

describe("StreamingDiffParser", () => {
	it("emits one complete event for a single file in one chunk", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		parser.feed('{"files":[{"path":"a.ts","content":"export const x = 1;"}]}');
		parser.end();
		const completes = events.filter((e) => e.status === "complete");
		expect(completes).toHaveLength(1);
		expect(completes[0].path).toBe("a.ts");
		expect(completes[0].content).toBe("export const x = 1;");
	});

	it("emits files in the order they appear in the stream", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		parser.feed(
			'{"files":[{"path":"first.ts","content":"AAA"},{"path":"second.ts","content":"BBB"},{"path":"third.ts","content":"CCC"}]}',
		);
		parser.end();
		const order = events.filter((e) => e.status === "complete").map((e) => e.path);
		expect(order).toEqual(["first.ts", "second.ts", "third.ts"]);
	});

	it("emits a writing event before complete when the content is large", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		// Stream a long content body in two halves; threshold is 64 chars.
		const body = "x".repeat(200);
		parser.feed(`{"files":[{"path":"big.ts","content":"${body.slice(0, 100)}`);
		parser.feed(`${body.slice(100)}"}]}`);
		parser.end();
		const forBig = events.filter((e) => e.path === "big.ts");
		const writingEvents = forBig.filter((e) => e.status === "writing");
		const completeEvents = forBig.filter((e) => e.status === "complete");
		expect(writingEvents.length).toBeGreaterThan(0);
		expect(completeEvents).toHaveLength(1);
		expect(completeEvents[0].content).toBe(body);
	});

	it("tolerates the stream being chopped mid-escape sequence", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		// Chunk boundary in the middle of a `\n` escape.
		parser.feed('{"files":[{"path":"a.ts","content":"line1\\');
		parser.feed('nline2"}]}');
		parser.end();
		const complete = events.find((e) => e.status === "complete");
		expect(complete).toBeDefined();
		expect(complete?.content).toBe("line1\nline2");
	});

	it("decodes common JSON escapes in content", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		parser.feed('{"files":[{"path":"a.ts","content":"a\\tb\\n\\"c\\\\d"}]}');
		parser.end();
		const complete = events.find((e) => e.status === "complete");
		expect(complete?.content).toBe('a\tb\n"c\\d');
	});

	it("handles a stream chopped between two files", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		parser.feed('{"files":[{"path":"a.ts","content":"A"},{"path":"b');
		parser.feed('.ts","content":"B"}]}');
		parser.end();
		const completes = events.filter((e) => e.status === "complete").map((e) => e.path);
		expect(completes).toEqual(["a.ts", "b.ts"]);
	});

	it("ignores prose preamble before the first file header", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		parser.feed('Sure! Here is the output:\n```json\n{"files":[{"path":"a.ts","content":"X"}]}\n```');
		parser.end();
		const completes = events.filter((e) => e.status === "complete");
		expect(completes).toHaveLength(1);
		expect(completes[0].content).toBe("X");
	});

	it("end() emits a final complete event if stream cut off mid-content", () => {
		const parser = new StreamingDiffParser();
		const events = collect(parser);
		parser.feed('{"files":[{"path":"a.ts","content":"partial');
		parser.end();
		const final = events.filter((e) => e.path === "a.ts");
		const complete = final[final.length - 1];
		expect(complete.status).toBe("complete");
		expect(complete.content).toBe("partial");
	});

	it("getCompletedPaths reports each file exactly once", () => {
		const parser = new StreamingDiffParser();
		collect(parser);
		parser.feed('{"files":[{"path":"a.ts","content":"1"},{"path":"b.ts","content":"2"}]}');
		parser.end();
		expect(parser.getCompletedPaths()).toEqual(["a.ts", "b.ts"]);
	});
});
