import { describe, expect, it } from "vitest";
import { redactSecrets, scanForSecrets, summarizeMatches } from "../src/secret-scanner";

describe("scanForSecrets", () => {
	it("detects an AWS access key", () => {
		const m = scanForSecrets("aws_key=AKIAIOSFODNN7EXAMPLE in config");
		expect(m).toHaveLength(1);
		expect(m[0].kind).toBe("AWS access key");
	});

	it("detects an AWS secret access key (40 char base64)", () => {
		// Has lowercase, uppercase, digits → passes validator.
		const key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";
		const m = scanForSecrets(`AWS_SECRET=${key}\n`);
		expect(m.some((x) => x.kind === "AWS secret access key")).toBe(true);
	});

	it("does NOT flag a sha1 hex digest as an AWS secret (no uppercase)", () => {
		// 40-char hex digest — common in commit hashes / sha1 sums. Should not match.
		const hex = "356a192b7913b04c54574d18c28d46e6395428ab".repeat(1).slice(0, 40);
		const m = scanForSecrets(`commit ${hex}`);
		expect(m).toHaveLength(0);
	});

	it("does NOT flag a short base64 string", () => {
		// 20 chars — under the 40-char threshold.
		const m = scanForSecrets("nonce=abcDEF1234ghiJKL5678");
		expect(m).toHaveLength(0);
	});

	it("detects multiple GitHub PAT prefixes", () => {
		const text = [
			"ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
			"gho_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
			"ghs_CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC",
		].join(" ");
		const m = scanForSecrets(text);
		expect(m).toHaveLength(3);
		for (const x of m) expect(x.kind).toBe("GitHub PAT");
	});

	it("classifies sk-ant-... as Anthropic, not OpenAI", () => {
		const m = scanForSecrets("API=sk-ant-api03-AAAAAAAAAAAAAAAAAAAAAAAA");
		expect(m).toHaveLength(1);
		expect(m[0].kind).toBe("Anthropic key");
	});

	it("classifies sk-... (long) as OpenAI", () => {
		const m = scanForSecrets("OPENAI_API_KEY=sk-proj-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
		expect(m).toHaveLength(1);
		expect(m[0].kind).toBe("OpenAI key");
	});

	it("does NOT flag sk- when the body is too short", () => {
		// "sk-" + only 10 chars → below the 40-char tail length.
		const m = scanForSecrets("token=sk-abc1234567");
		expect(m).toHaveLength(0);
	});

	it("detects JWTs (three base64url segments)", () => {
		const jwt =
			"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
		const m = scanForSecrets(`Authorization: Bearer ${jwt}`);
		expect(m).toHaveLength(1);
		expect(m[0].kind).toBe("JWT");
	});

	it("detects Slack tokens", () => {
		const m = scanForSecrets("slack=xoxb-1234567890-abcdefghijklmnop");
		expect(m).toHaveLength(1);
		expect(m[0].kind).toBe("Slack token");
	});

	it("detects PEM private-key headers (RSA / OPENSSH / generic)", () => {
		const text = [
			"-----BEGIN RSA PRIVATE KEY-----",
			"MIIBOQIBAAJBAK...",
			"-----END RSA PRIVATE KEY-----",
			"-----BEGIN OPENSSH PRIVATE KEY-----",
			"-----BEGIN PRIVATE KEY-----",
		].join("\n");
		const m = scanForSecrets(text);
		expect(m).toHaveLength(3);
		for (const x of m) expect(x.kind).toBe("Private key");
	});

	it("returns an empty list for plain text", () => {
		const m = scanForSecrets("Just a regular message about the weather.");
		expect(m).toHaveLength(0);
	});

	it("returns an empty list for empty input", () => {
		expect(scanForSecrets("")).toEqual([]);
	});

	it("orders matches by start offset", () => {
		const text = "first AKIAIOSFODNN7EXAMPLE then ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA end";
		const m = scanForSecrets(text);
		expect(m.length).toBeGreaterThan(0);
		for (let i = 1; i < m.length; i++) {
			expect(m[i].start).toBeGreaterThanOrEqual(m[i - 1].end);
		}
	});

	it("preview masks the middle of the secret", () => {
		const m = scanForSecrets("k=AKIAIOSFODNN7EXAMPLE");
		expect(m[0].preview).not.toContain("IOSFODNN7");
		expect(m[0].preview.startsWith("AKIA")).toBe(true);
	});
});

describe("redactSecrets", () => {
	it("replaces each match with [REDACTED:KIND]", () => {
		const { redacted, matches } = redactSecrets("key=AKIAIOSFODNN7EXAMPLE");
		expect(matches).toHaveLength(1);
		expect(redacted).toBe("key=[REDACTED:AWS access key]");
	});

	it("returns the original text untouched when nothing matches", () => {
		const input = "All clean here.";
		const { redacted, matches } = redactSecrets(input);
		expect(redacted).toBe(input);
		expect(matches).toHaveLength(0);
	});

	it("redacts multiple secrets in one pass without offset drift", () => {
		const text = "a=AKIAIOSFODNN7EXAMPLE b=ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
		const { redacted } = redactSecrets(text);
		expect(redacted).toBe("a=[REDACTED:AWS access key] b=[REDACTED:GitHub PAT]");
	});
});

describe("summarizeMatches", () => {
	it("groups by kind with counts", () => {
		const text = [
			"AKIAIOSFODNN7EXAMPLE",
			"AKIAIOSFODNN7EXAMPL2",
			"ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
		].join(" ");
		const matches = scanForSecrets(text);
		const summary = summarizeMatches(matches);
		expect(summary).toContain("AWS access key (2)");
		expect(summary).toContain("GitHub PAT (1)");
	});

	it("returns an empty string for an empty match list", () => {
		expect(summarizeMatches([])).toBe("");
	});
});
