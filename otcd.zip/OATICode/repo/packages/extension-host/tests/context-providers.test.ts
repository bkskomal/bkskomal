// R8-C: tests for the pluggable context-provider system. Exercises each
// built-in provider against a hand-rolled HostContext mock plus the
// user-plugin loader (sandboxing + cap enforcement).
import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type {
	DiagnosticEntry,
	DiagnosticsProvider,
	ExecResult,
	HostContext,
	WorkspaceContextSnapshot,
} from "@oati/shared";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
	MAX_USER_PROVIDERS,
	USER_PROVIDERS_RELATIVE_DIR,
	_resetContextProviders,
	getContextProvider,
	listContextProviders,
	loadUserProviders,
	registerBuiltinContextProviders,
	registerContextProvider,
	resolveContextMention,
} from "../src/context-providers";
import { docsProvider, htmlToMarkdown } from "../src/context-providers/docs";
import { gitDiffProvider } from "../src/context-providers/git-diff";
import { githubIssueProvider, parseIssueRef } from "../src/context-providers/github-issue";
import { openTabsProvider } from "../src/context-providers/open-tabs";
import { problemsProvider } from "../src/context-providers/problems";
import { parseSearchArg, searchProvider } from "../src/context-providers/search";
import { selectionProvider } from "../src/context-providers/selection";
import { type TerminalSnapshotProvider, terminalProvider } from "../src/context-providers/terminal";
import { webProvider } from "../src/context-providers/web";

interface MockHostOptions {
	readonly diagnostics?: readonly DiagnosticEntry[];
	readonly execHandler?: (cmd: string) => ExecResult | Promise<ExecResult>;
	readonly files?: Readonly<Record<string, string>>;
	readonly workspaceContext?: WorkspaceContextSnapshot;
	readonly terminalText?: string;
}

function makeMockHost(opts: MockHostOptions = {}): HostContext & {
	terminalSnapshot?: TerminalSnapshotProvider;
} {
	const diagnostics: DiagnosticsProvider = {
		async all(filter) {
			const entries = opts.diagnostics ?? [];
			if (filter?.path) return entries.filter((e) => e.path === filter.path);
			return entries;
		},
		onChange: () => () => undefined,
	};
	return {
		async readFile(p) {
			const v = opts.files?.[p];
			if (v === undefined) throw new Error(`file not found: ${p}`);
			return v;
		},
		async writeFile() {
			throw new Error("not implemented");
		},
		async fileExists(p) {
			return opts.files !== undefined && Object.hasOwn(opts.files, p);
		},
		async exec(command) {
			if (!opts.execHandler) return { stdout: "", stderr: "no exec handler", exitCode: 1 };
			return Promise.resolve(opts.execHandler(command));
		},
		workspaceRoot: () => "/workspace",
		async requestApproval() {
			return true;
		},
		async showDiff() {
			/* no-op */
		},
		log() {
			/* no-op */
		},
		diagnostics: opts.diagnostics ? diagnostics : undefined,
		async getWorkspaceContext() {
			return opts.workspaceContext ?? { openFiles: [] };
		},
		...(opts.terminalText !== undefined
			? {
					terminalSnapshot: {
						getActiveTerminalText: () => opts.terminalText,
					},
				}
			: {}),
	};
}

describe("@problems provider (R8-C)", () => {
	it("returns a friendly hint when no diagnostics bridge is attached", async () => {
		const host = makeMockHost();
		const out = await problemsProvider.resolve("", host);
		expect(out).toMatch(/No diagnostics bridge/i);
	});
	it("formats diagnostics with severity, path, and message", async () => {
		const host = makeMockHost({
			diagnostics: [
				{
					path: "src/a.ts",
					line: 12,
					column: 3,
					endLine: 12,
					endColumn: 8,
					severity: "error",
					message: "Cannot find name 'foo'",
					source: "ts",
					code: "2304",
				},
			],
		});
		const out = await problemsProvider.resolve("", host);
		expect(out).toContain("ERROR src/a.ts:12:3");
		expect(out).toContain("Cannot find name 'foo'");
	});
	it("supports a path filter via the inline arg", async () => {
		const host = makeMockHost({
			diagnostics: [
				{
					path: "a.ts",
					line: 1,
					column: 1,
					endLine: 1,
					endColumn: 1,
					severity: "warning",
					message: "a",
				},
				{
					path: "b.ts",
					line: 1,
					column: 1,
					endLine: 1,
					endColumn: 1,
					severity: "warning",
					message: "b",
				},
			],
		});
		const out = await problemsProvider.resolve("a.ts", host);
		expect(out).toContain("a.ts:1:1");
		expect(out).not.toContain("b.ts");
	});
});

describe("@terminal provider (R8-C)", () => {
	it("renders the tail of the captured terminal text", async () => {
		const host = makeMockHost({ terminalText: "line1\nline2\nline3" });
		const out = await terminalProvider.resolve("", host);
		expect(out).toContain("Active terminal");
		expect(out).toContain("line1");
		expect(out).toContain("line3");
	});
	it("returns a hint when no terminal is tracked", async () => {
		const host = makeMockHost();
		const out = await terminalProvider.resolve("", host);
		expect(out).toMatch(/No active terminal/i);
	});
});

describe("@git-diff provider (R8-C)", () => {
	it("invokes `git diff` with no args by default", async () => {
		const calls: string[] = [];
		const host = makeMockHost({
			execHandler: (cmd) => {
				calls.push(cmd);
				return { stdout: "diff --git a/x b/x", stderr: "", exitCode: 0 };
			},
		});
		const out = await gitDiffProvider.resolve("", host);
		expect(calls[0]).toBe("git diff");
		expect(out).toContain("```diff");
		expect(out).toContain("diff --git a/x b/x");
	});
	it("honors --staged", async () => {
		const calls: string[] = [];
		const host = makeMockHost({
			execHandler: (cmd) => {
				calls.push(cmd);
				return { stdout: "", stderr: "", exitCode: 0 };
			},
		});
		await gitDiffProvider.resolve("--staged", host);
		expect(calls[0]).toBe("git diff --staged");
	});
	it("rejects unsafe arguments without invoking exec", async () => {
		const calls: string[] = [];
		const host = makeMockHost({
			execHandler: (cmd) => {
				calls.push(cmd);
				return { stdout: "", stderr: "", exitCode: 0 };
			},
		});
		const out = await gitDiffProvider.resolve("foo; rm -rf /", host);
		expect(out).toMatch(/unsafe/i);
		expect(calls).toEqual([]);
	});
});

describe("@docs provider (R8-C)", () => {
	const realFetch = global.fetch;
	beforeEach(() => {
		(global as { fetch: typeof fetch }).fetch = vi
			.fn()
			.mockResolvedValue(
				new Response(
					"<html><body><h1>Title</h1><p>Hello <code>world</code></p><script>nope</script></body></html>",
					{ status: 200, headers: { "content-type": "text/html" } },
				),
			) as unknown as typeof fetch;
	});
	afterEach(() => {
		(global as { fetch: typeof fetch }).fetch = realFetch;
	});
	it("rejects non-URLs", async () => {
		const host = makeMockHost();
		const out = await docsProvider.resolve("not a url", host);
		expect(out).toMatch(/Invalid URL/i);
	});
	it("rejects non-http schemes", async () => {
		const host = makeMockHost();
		const out = await docsProvider.resolve("file:///etc/passwd", host);
		expect(out).toMatch(/Only http\/https/i);
	});
	it("fetches and strips HTML when content-type is html", async () => {
		const host = makeMockHost();
		const out = await docsProvider.resolve("https://example.com/", host);
		expect(out).toContain("# Title");
		expect(out).toContain("Hello `world`");
		expect(out).not.toContain("<script>");
	});

	it("htmlToMarkdown handles headings, code, lists", () => {
		const md = htmlToMarkdown("<h2>X</h2><ul><li>one</li><li>two</li></ul><pre>code\nblock</pre>");
		expect(md).toContain("## X");
		expect(md).toContain("- one");
		expect(md).toContain("```");
		expect(md).toContain("code");
	});
});

describe("@web provider (R8-C)", () => {
	const realFetch = global.fetch;
	afterEach(() => {
		(global as { fetch: typeof fetch }).fetch = realFetch;
	});
	it("rejects empty queries", async () => {
		const host = makeMockHost();
		const out = await webProvider.resolve("", host);
		expect(out).toMatch(/Usage/);
	});
	it("returns up to 3 results from a DDG-shaped response", async () => {
		(global as { fetch: typeof fetch }).fetch = vi
			.fn()
			.mockResolvedValue(
				new Response(
					[
						'<a class="result__a" href="https://a.test/">A title</a>',
						'<a class="result__snippet">A snippet</a>',
						'<a class="result__a" href="https://b.test/">B title</a>',
						'<a class="result__snippet">B snippet</a>',
						'<a class="result__a" href="https://c.test/">C title</a>',
						'<a class="result__snippet">C snippet</a>',
						'<a class="result__a" href="https://d.test/">D title</a>',
						'<a class="result__snippet">D snippet</a>',
					].join("\n"),
					{ status: 200 },
				),
			) as unknown as typeof fetch;
		const host = makeMockHost();
		const out = await webProvider.resolve("q", host);
		expect(out).toContain("A title");
		expect(out).toContain("B title");
		expect(out).toContain("C title");
		expect(out).not.toContain("D title");
	});
});

describe("@github-issue provider (R8-C)", () => {
	it("parses bare issue numbers", () => {
		expect(parseIssueRef("42")).toEqual({ number: 42 });
	});
	it("parses owner/repo#num", () => {
		expect(parseIssueRef("octo/cat#7")).toEqual({ owner: "octo", repo: "cat", number: 7 });
	});
	it("rejects garbage", () => {
		const out = parseIssueRef("nope");
		expect(out).toHaveProperty("error");
	});
	it("invokes `gh issue view` with the parsed args", async () => {
		const calls: string[] = [];
		const host = makeMockHost({
			execHandler: (cmd) => {
				calls.push(cmd);
				const payload = {
					title: "Test",
					body: "Body",
					state: "open",
					author: { login: "me" },
					createdAt: "2026-01-01",
					url: "https://github.com/o/r/issues/3",
					comments: [{ author: { login: "u" }, body: "c1", createdAt: "x" }],
				};
				return { stdout: JSON.stringify(payload), stderr: "", exitCode: 0 };
			},
		});
		const out = await githubIssueProvider.resolve("o/r#3", host);
		expect(calls[0]).toContain("gh issue view 3");
		expect(calls[0]).toContain("--repo");
		expect(out).toContain("Test");
		expect(out).toContain("@u");
	});
	it("surfaces gh failures gracefully", async () => {
		const host = makeMockHost({
			execHandler: () => ({ stdout: "", stderr: "not logged in", exitCode: 1 }),
		});
		const out = await githubIssueProvider.resolve("9", host);
		expect(out).toMatch(/gh issue view failed/i);
		expect(out).toContain("not logged in");
	});
});

describe("@search provider (R8-C)", () => {
	it("parses --glob suffix", () => {
		expect(parseSearchArg("TODO --glob=*.ts")).toEqual({ query: "TODO", glob: "*.ts" });
		expect(parseSearchArg("just a query")).toEqual({ query: "just a query" });
	});
	it("rejects empty queries", async () => {
		const host = makeMockHost();
		const out = await searchProvider.resolve("", host);
		expect(out).toMatch(/Usage/);
	});
	it("invokes rg and formats hits", async () => {
		const calls: string[] = [];
		const host = makeMockHost({
			execHandler: (cmd) => {
				calls.push(cmd);
				return { stdout: "src/a.ts:12:hit one\nsrc/b.ts:3:hit two", stderr: "", exitCode: 0 };
			},
		});
		const out = await searchProvider.resolve("hit --glob=*.ts", host);
		expect(calls[0]).toContain("rg");
		expect(calls[0]).toContain("--glob");
		expect(calls[0]).toContain("*.ts");
		expect(out).toContain("src/a.ts:12:hit one");
		expect(out).toContain("2 matches");
	});
	it("reports empty results without bailing", async () => {
		const host = makeMockHost({
			execHandler: () => ({ stdout: "", stderr: "", exitCode: 1 }),
		});
		const out = await searchProvider.resolve("nothing", host);
		expect(out).toMatch(/No matches/);
	});
});

describe("@open-tabs provider (R8-C)", () => {
	it("renders the first 50 lines of each open editor", async () => {
		const host = makeMockHost({
			workspaceContext: { openFiles: ["a.ts", "b.ts"] },
			files: {
				"a.ts": "alpha\nbeta\ngamma",
				"b.ts": "one\ntwo",
			},
		});
		const out = await openTabsProvider.resolve("", host);
		expect(out).toContain("a.ts");
		expect(out).toContain("alpha");
		expect(out).toContain("b.ts");
		expect(out).toContain("two");
	});
	it("returns a friendly hint when nothing is open", async () => {
		const host = makeMockHost({ workspaceContext: { openFiles: [] } });
		const out = await openTabsProvider.resolve("", host);
		expect(out).toMatch(/No open editors/i);
	});
});

describe("@selection provider (R8-C)", () => {
	it("formats the selection with the 1-based range", async () => {
		const host = makeMockHost({
			workspaceContext: {
				openFiles: ["a.ts"],
				activeFile: "a.ts",
				activeFileLanguage: "typescript",
				activeSelection: { text: "const x = 1;", startLine: 3, endLine: 3 },
			},
		});
		const out = await selectionProvider.resolve("", host);
		expect(out).toContain("`a.ts`:3-3");
		expect(out).toContain("```typescript");
		expect(out).toContain("const x = 1;");
	});
	it("returns a hint when no selection", async () => {
		const host = makeMockHost({ workspaceContext: { openFiles: [] } });
		const out = await selectionProvider.resolve("", host);
		expect(out).toMatch(/No active selection/i);
	});
});

describe("registry + resolveContextMention (R8-C)", () => {
	beforeEach(() => {
		_resetContextProviders();
		registerBuiltinContextProviders();
	});
	it("registers all 9 built-ins", () => {
		const ids = listContextProviders()
			.map((p) => p.id)
			.sort();
		expect(ids).toEqual(
			[
				"docs",
				"git-diff",
				"github-issue",
				"open-tabs",
				"problems",
				"search",
				"selection",
				"terminal",
				"web",
			].sort(),
		);
	});
	it("resolves by bare id", async () => {
		const host = makeMockHost();
		const r = await resolveContextMention("selection", undefined, host);
		expect(r.ok).toBe(true);
	});
	it("resolves by @-mention with inline arg", async () => {
		const host = makeMockHost({
			diagnostics: [
				{
					path: "x.ts",
					line: 1,
					column: 1,
					endLine: 1,
					endColumn: 1,
					severity: "error",
					message: "boom",
				},
			],
		});
		const r = await resolveContextMention("@problems:x.ts", undefined, host);
		expect(r.ok).toBe(true);
		if (r.ok) expect(r.content).toContain("x.ts");
	});
	it("returns ok=false for unknown mentions", async () => {
		const host = makeMockHost();
		const r = await resolveContextMention("@nope", undefined, host);
		expect(r.ok).toBe(false);
	});
	it("rejects providers without an @ in the mention", () => {
		expect(() =>
			registerContextProvider({
				id: "bad",
				mention: "bad",
				description: "x",
				async resolve() {
					return "";
				},
			}),
		).toThrow(/start with '@'/);
	});
});

describe("user-provider loader (R8-C)", () => {
	let dir: string;
	beforeEach(async () => {
		_resetContextProviders();
		dir = await fs.mkdtemp(path.join(os.tmpdir(), "oati-ctxp-"));
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	async function writePlugin(name: string, src: string): Promise<void> {
		await fs.mkdir(path.join(dir, USER_PROVIDERS_RELATIVE_DIR), { recursive: true });
		await fs.writeFile(path.join(dir, USER_PROVIDERS_RELATIVE_DIR, name), src, "utf-8");
	}

	it("returns empty when the dir does not exist", async () => {
		const out = await loadUserProviders(dir);
		expect(out.registered).toEqual([]);
		expect(out.skipped).toEqual([]);
	});

	it("loads a well-formed plugin and registers it", async () => {
		await writePlugin(
			"foo.js",
			`module.exports = {
				id: "foo",
				mention: "@foo",
				description: "user plugin",
				resolve: async () => "hi from foo"
			};`,
		);
		const out = await loadUserProviders(dir);
		expect(out.registered).toEqual(["foo"]);
		expect(getContextProvider("foo")).toBeDefined();
	});

	it("skips plugins that don't export a ContextProvider shape", async () => {
		await writePlugin("bad.js", "module.exports = { not: 'a provider' };");
		const out = await loadUserProviders(dir);
		expect(out.registered).toEqual([]);
		expect(out.skipped).toHaveLength(1);
		expect(out.skipped[0].file).toBe("bad.js");
	});

	it("denies require() inside sandbox", async () => {
		await writePlugin(
			"requires.js",
			"const fs = require('fs');\nmodule.exports = { id:'x', mention:'@x', description:'', resolve: async()=>'' };",
		);
		const out = await loadUserProviders(dir);
		expect(out.registered).toEqual([]);
		expect(out.skipped).toHaveLength(1);
		expect(out.skipped[0].reason).toMatch(/require/);
	});

	it("enforces the per-workspace cap", async () => {
		for (let i = 0; i < MAX_USER_PROVIDERS + 2; i++) {
			await writePlugin(
				`p${i}.js`,
				`module.exports = { id:'p${i}', mention:'@p${i}', description:'', resolve: async()=>'' };`,
			);
		}
		const out = await loadUserProviders(dir);
		expect(out.registered.length).toBe(MAX_USER_PROVIDERS);
		expect(out.skipped.length).toBeGreaterThanOrEqual(1);
		expect(out.skipped.some((s) => /cap/.test(s.reason))).toBe(true);
	});
});
