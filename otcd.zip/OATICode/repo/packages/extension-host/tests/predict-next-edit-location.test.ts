// R8-A: unit tests for the predict-next-edit-location heuristic and the
// supporting helpers (sliceFirstWord, trimTrailingDuplicates, multi-suggestion
// cycling, partial-word state machine).

import { describe, expect, it } from "vitest";
import {
	createMultiSuggestionState,
	createPartialAcceptState,
	currentSuggestion,
	cycleSuggestion,
	decodeCachedVariants,
	popPartialWord,
	resolveMaxTokens,
} from "../src/inline-completion";
import {
	findNextNonEmptyLineStart,
	predictNextEditLocation,
	sliceFirstWord,
	trimTrailingDuplicates,
} from "../src/predict-next-edit-location";

describe("predictNextEditLocation", () => {
	it("finds a <TODO> marker ahead of the cursor", () => {
		const text = "function f() {\n  return 1;\n}\n\nfunction g() {\n  <TODO>\n}\n";
		const cursor = text.indexOf("return 1;");
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: cursor,
			languageId: "typescript",
		});
		expect(out.reason).toBe("placeholder_marker");
		expect(out.marker).toBe("<TODO>");
		expect(out.offset).toBe(text.indexOf("<TODO>"));
	});

	it("finds a <FIXME> placeholder when no <TODO> is present", () => {
		const text = "a = 1\n<FIXME> something here\n";
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: 0,
			languageId: "python",
		});
		expect(out.reason).toBe("placeholder_marker");
		expect(out.marker).toBe("<FIXME>");
	});

	it("recognises // TODO comments in TypeScript", () => {
		const text = "const x = 1;\n// TODO: implement this\nconst y = 2;\n";
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: 0,
			languageId: "typescript",
		});
		expect(out.reason).toBe("todo_comment");
		expect(out.offset).toBe(text.indexOf("// TODO"));
	});

	it("recognises # TODO comments in Python", () => {
		const text = "x = 1\n# TODO: handle the edge case\ny = 2\n";
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: 0,
			languageId: "python",
		});
		expect(out.reason).toBe("todo_comment");
		expect(out.offset).toBe(text.indexOf("# TODO"));
	});

	it("recognises bare `pass` as a Python placeholder", () => {
		const text = "def foo():\n    pass\n\ndef bar():\n    return 1\n";
		const cursor = text.indexOf("def foo()");
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: cursor,
			languageId: "python",
		});
		expect(out.reason).toBe("pass_keyword");
	});

	it('recognises throw new Error("Not implemented") as a sentinel', () => {
		const text = 'function todo() {\n  throw new Error("Not implemented");\n}\n';
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: 0,
			languageId: "typescript",
		});
		expect(out.reason).toBe("not_implemented");
	});

	it("recognises unimplemented!() in Rust", () => {
		const text = "fn todo() -> i32 {\n    unimplemented!()\n}\n";
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: 0,
			languageId: "rust",
		});
		expect(out.reason).toBe("not_implemented");
	});

	it("falls back to the start of the next non-empty line", () => {
		const text = "line1\nline2\nline3\n";
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: 2,
			languageId: "typescript",
		});
		expect(out.reason).toBe("next_nonempty_line");
		expect(out.offset).toBe(text.indexOf("line2"));
	});

	it("falls back to end-of-document when no candidate exists", () => {
		const text = "only one line";
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: text.length,
			languageId: "typescript",
		});
		expect(out.reason).toBe("end_of_document");
		expect(out.offset).toBe(text.length);
	});

	it("respects the scan budget cap", () => {
		const filler = "x".repeat(5000);
		const text = `${filler}<TODO>`;
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: 0,
			languageId: "typescript",
			scanBudgetBytes: 100,
		});
		// The <TODO> is past the cap — should fall back.
		expect(out.reason).not.toBe("placeholder_marker");
	});

	it("ignores markers BEFORE the cursor", () => {
		const text = "<TODO>\nactual content\nmore content\n";
		// Cursor is past the <TODO> marker.
		const out = predictNextEditLocation({
			documentText: text,
			currentOffset: text.indexOf("actual"),
			languageId: "typescript",
		});
		expect(out.reason).not.toBe("placeholder_marker");
	});
});

describe("findNextNonEmptyLineStart", () => {
	it("returns undefined when nothing follows", () => {
		expect(findNextNonEmptyLineStart("only one", 0)).toBeUndefined();
	});

	it("skips blank lines and lands on leading non-whitespace", () => {
		const text = "a\n\n\n  b\n";
		const out = findNextNonEmptyLineStart(text, 0);
		expect(out).toBe(text.indexOf("b"));
	});
});

describe("sliceFirstWord", () => {
	it("slices a single word", () => {
		expect(sliceFirstWord("hello world")).toEqual({ word: "hello", rest: " world" });
	});

	it("slices including leading whitespace", () => {
		expect(sliceFirstWord("  hello world")).toEqual({ word: "  hello", rest: " world" });
	});

	it("treats newline as its own word", () => {
		expect(sliceFirstWord("\nrest")).toEqual({ word: "\n", rest: "rest" });
	});

	it("handles empty input", () => {
		expect(sliceFirstWord("")).toEqual({ word: "", rest: "" });
	});

	it("treats punctuation clusters as one word", () => {
		expect(sliceFirstWord("=> next")).toEqual({ word: "=>", rest: " next" });
	});
});

describe("trimTrailingDuplicates", () => {
	it("trims a tail that duplicates the line below", () => {
		// Completion ends with "return x;" — and the next line of suffix is "return x;".
		const completion = "  const y = 1;\n  return x;\n";
		const suffix = "  return x;\n}";
		const trimmed = trimTrailingDuplicates(completion, suffix);
		expect(trimmed).toBe("  const y = 1;\n");
	});

	it("leaves the completion alone when there is no overlap", () => {
		const completion = "  const z = 2;\n";
		const suffix = "function unrelated() {}";
		expect(trimTrailingDuplicates(completion, suffix)).toBe(completion);
	});

	it("handles single-line completions", () => {
		expect(trimTrailingDuplicates("foo", "bar")).toBe("foo");
	});
});

describe("multi-suggestion cycling", () => {
	it("creates a carousel from non-empty variants", () => {
		const state = createMultiSuggestionState("k", ["a", "b", "c"]);
		expect(state).toBeDefined();
		expect(state?.variants).toEqual(["a", "b", "c"]);
		expect(state?.index).toBe(0);
	});

	it("dedupes variants", () => {
		const state = createMultiSuggestionState("k", ["a", "a", "b"]);
		expect(state?.variants).toEqual(["a", "b"]);
	});

	it("drops empty variants", () => {
		const state = createMultiSuggestionState("k", ["", "  ", "real"]);
		expect(state?.variants).toEqual(["real"]);
	});

	it("returns undefined for an empty list", () => {
		expect(createMultiSuggestionState("k", [])).toBeUndefined();
		expect(createMultiSuggestionState("k", ["", ""])).toBeUndefined();
	});

	it("rotates forward and wraps around", () => {
		let state = createMultiSuggestionState("k", ["a", "b", "c"]);
		if (!state) throw new Error("expected state");
		state = cycleSuggestion(state, 1);
		expect(currentSuggestion(state)).toBe("b");
		state = cycleSuggestion(state, 1);
		expect(currentSuggestion(state)).toBe("c");
		state = cycleSuggestion(state, 1);
		expect(currentSuggestion(state)).toBe("a");
	});

	it("rotates backward and wraps around", () => {
		let state = createMultiSuggestionState("k", ["a", "b", "c"]);
		if (!state) throw new Error("expected state");
		state = cycleSuggestion(state, -1);
		expect(currentSuggestion(state)).toBe("c");
		state = cycleSuggestion(state, -1);
		expect(currentSuggestion(state)).toBe("b");
	});
});

describe("partial-word accept state machine", () => {
	it("pops one word at a time", () => {
		let state = createPartialAcceptState("anchor", "const x = 1;");
		const r1 = popPartialWord(state);
		expect(r1.consumed).toBe("const");
		state = r1.next;
		expect(state.pending).toBe(" x = 1;");
		const r2 = popPartialWord(state);
		expect(r2.consumed).toBe(" x");
		state = r2.next;
		const r3 = popPartialWord(state);
		expect(r3.consumed).toBe(" =");
	});

	it("returns empty consumed when pending is empty", () => {
		const state = createPartialAcceptState("a", "");
		const r = popPartialWord(state);
		expect(r.consumed).toBe("");
		expect(r.next.pending).toBe("");
	});
});

describe("decodeCachedVariants", () => {
	it("decodes a JSON array", () => {
		expect(decodeCachedVariants(JSON.stringify(["a", "b"]))).toEqual(["a", "b"]);
	});

	it("coerces a legacy plain string to a 1-element list", () => {
		expect(decodeCachedVariants("legacy text")).toEqual(["legacy text"]);
	});

	it("returns [] for empty input", () => {
		expect(decodeCachedVariants("")).toEqual([]);
	});

	it("skips empty strings inside the array", () => {
		expect(decodeCachedVariants(JSON.stringify(["a", "", "b"]))).toEqual(["a", "b"]);
	});
});

describe("resolveMaxTokens", () => {
	it("bumps multi-line-friendly languages to 200", () => {
		expect(resolveMaxTokens("typescript", 80)).toBe(200);
		expect(resolveMaxTokens("python", 80)).toBe(200);
		expect(resolveMaxTokens("rust", 80)).toBe(200);
	});

	it("leaves other languages at the configured cap", () => {
		expect(resolveMaxTokens("yaml", 80)).toBe(80);
		expect(resolveMaxTokens("json", 80)).toBe(80);
	});

	it("never reduces below the configured cap", () => {
		expect(resolveMaxTokens("typescript", 500)).toBe(500);
	});
});
