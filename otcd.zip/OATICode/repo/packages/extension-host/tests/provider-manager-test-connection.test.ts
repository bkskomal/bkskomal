// 2026-06-16: Test Connection used to return ok=true on any HTTP 200,
// even when the gateway's /v1/models response was an empty list. Then
// the user's first real request would 404 with "Model X not found" and
// the green checkmark in Settings made the failure baffling. The test
// here pins the new behaviour: Test Connection now parses the body and
// reports the model-availability situation honestly.

import type { ProviderConfig, RootConfig } from "@oati/shared";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ProviderManager } from "../src/provider-manager";

function mkProvider(over: Partial<ProviderConfig> = {}): ProviderConfig {
	return {
		id: "p1",
		type: "openai-compatible",
		displayName: "Test",
		preset: "openai-compatible",
		baseUrl: "http://vllm.example.com/v1",
		defaultModel: "google/gemma-4-26B-A4B",
		...over,
	};
}

function mkSettings(provider: ProviderConfig): { config: RootConfig; getApiKey: () => Promise<undefined>; on: () => () => void; hasApiKeyMap: () => Promise<Record<string, boolean>>; updateConfig: () => Promise<void>; setApiKey: () => Promise<void>; deleteApiKey: () => Promise<void>; reload: () => void; } {
	return {
		config: {
			activeProviderId: provider.id,
			activeModeId: "code",
			providers: [provider],
			modes: [],
			mcpServers: [],
		} as unknown as RootConfig,
		getApiKey: async () => undefined,
		on: () => () => undefined,
		hasApiKeyMap: async () => ({}),
		updateConfig: async () => undefined,
		setApiKey: async () => undefined,
		deleteApiKey: async () => undefined,
		reload: () => undefined,
	};
}

describe("ProviderManager.testConnection", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("FAILS with an actionable message when the gateway is up but no models are loaded (the live OATI Gemma case)", async () => {
		const mock = global.fetch as ReturnType<typeof vi.fn>;
		mock.mockResolvedValue(
			new Response(JSON.stringify({ object: "list", data: [] }), {
				status: 200,
				headers: { "content-type": "application/json" },
			}),
		);
		const provider = mkProvider();
		// biome-ignore lint/suspicious/noExplicitAny: SettingsStore shape mocked
		const pm = new ProviderManager(mkSettings(provider) as any);
		const result = await pm.testConnection(provider.id);
		expect(result.ok).toBe(false);
		expect(result.message).toMatch(/no models loaded/i);
		expect(result.message).toContain(provider.defaultModel);
	});

	it("FAILS with the loaded-but-different list when the configured model isn't in the served set", async () => {
		const mock = global.fetch as ReturnType<typeof vi.fn>;
		mock.mockResolvedValue(
			new Response(
				JSON.stringify({
					object: "list",
					data: [
						{ id: "Qwen/Qwen3-Coder-30B-A3B-Instruct" },
						{ id: "openai/gpt-oss-120b" },
					],
				}),
				{ status: 200, headers: { "content-type": "application/json" } },
			),
		);
		const provider = mkProvider({ defaultModel: "google/gemma-4-26B-A4B" });
		// biome-ignore lint/suspicious/noExplicitAny: SettingsStore shape mocked
		const pm = new ProviderManager(mkSettings(provider) as any);
		const result = await pm.testConnection(provider.id);
		expect(result.ok).toBe(false);
		expect(result.message).toContain("google/gemma-4-26B-A4B");
		expect(result.message).toContain("NOT in the served");
		// Surfaces the actually-loaded ids so the user can copy-paste.
		expect(result.message).toContain("Qwen/Qwen3-Coder-30B-A3B-Instruct");
		expect(result.message).toContain("openai/gpt-oss-120b");
	});

	it("PASSES with confirmation when the configured model IS in the served set", async () => {
		const mock = global.fetch as ReturnType<typeof vi.fn>;
		mock.mockResolvedValue(
			new Response(
				JSON.stringify({
					object: "list",
					data: [{ id: "google/gemma-4-26B-A4B", max_model_len: 262144 }],
				}),
				{ status: 200, headers: { "content-type": "application/json" } },
			),
		);
		const provider = mkProvider();
		// biome-ignore lint/suspicious/noExplicitAny: SettingsStore shape mocked
		const pm = new ProviderManager(mkSettings(provider) as any);
		const result = await pm.testConnection(provider.id);
		expect(result.ok).toBe(true);
		expect(result.message).toContain("is loaded");
		expect(result.message).toContain(provider.defaultModel);
	});

	it("PASSES (fallback to old behaviour) when the body isn't standard JSON — non-OpenAI-compatible servers", async () => {
		const mock = global.fetch as ReturnType<typeof vi.fn>;
		mock.mockResolvedValue(
			new Response("plain text response that isn't JSON", {
				status: 200,
				headers: { "content-type": "text/plain" },
			}),
		);
		const provider = mkProvider({ baseUrl: "http://custom-server.example/v1" });
		// biome-ignore lint/suspicious/noExplicitAny: SettingsStore shape mocked
		const pm = new ProviderManager(mkSettings(provider) as any);
		const result = await pm.testConnection(provider.id);
		// Falls back to the simple "200 = OK" behaviour for unusual servers.
		expect(result.ok).toBe(true);
	});

	it("PASSES with a model-count summary when defaultModel is blank (early setup)", async () => {
		const mock = global.fetch as ReturnType<typeof vi.fn>;
		mock.mockResolvedValue(
			new Response(
				JSON.stringify({
					object: "list",
					data: [{ id: "a" }, { id: "b" }],
				}),
				{ status: 200, headers: { "content-type": "application/json" } },
			),
		);
		const provider = mkProvider({ defaultModel: "" });
		// biome-ignore lint/suspicious/noExplicitAny: SettingsStore shape mocked
		const pm = new ProviderManager(mkSettings(provider) as any);
		const result = await pm.testConnection(provider.id);
		expect(result.ok).toBe(true);
		expect(result.message).toMatch(/2 models? available/i);
	});
});
