import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { FACTS_RELATIVE_PATH, addFact, loadFacts } from "../src/agent-facts";

async function makeTempWorkspace(): Promise<string> {
	const dir = await fs.mkdtemp(path.join(os.tmpdir(), "oati-facts-"));
	return dir;
}

async function writeFactsFile(workspace: string, raw: string): Promise<void> {
	const abs = path.join(workspace, FACTS_RELATIVE_PATH);
	await fs.mkdir(path.dirname(abs), { recursive: true });
	await fs.writeFile(abs, raw, "utf-8");
}

describe("agent-facts loader", () => {
	let workspace: string;

	beforeEach(async () => {
		workspace = await makeTempWorkspace();
	});

	afterEach(async () => {
		await fs.rm(workspace, { recursive: true, force: true });
	});

	it("returns an empty list when the facts file is missing", async () => {
		const out = await loadFacts(workspace);
		expect(out).toEqual([]);
	});

	it("returns an empty list for an empty workspace path", async () => {
		const out = await loadFacts("");
		expect(out).toEqual([]);
	});

	it("loads facts written previously", async () => {
		await writeFactsFile(
			workspace,
			JSON.stringify([
				{
					id: "a",
					fact: "Python files use snake_case",
					addedAt: "2026-01-01T00:00:00Z",
					source: "agent",
				},
				{
					id: "b",
					fact: "Auth middleware lives in middleware/auth.ts",
					addedAt: "2026-01-02T00:00:00Z",
					source: "user",
				},
			]),
		);
		const out = await loadFacts(workspace);
		expect(out).toHaveLength(2);
		expect(out[0].fact).toBe("Python files use snake_case");
		expect(out[1].source).toBe("user");
	});

	it("falls back to an empty list when the JSON is corrupt", async () => {
		await writeFactsFile(workspace, "{not real json");
		const out = await loadFacts(workspace);
		expect(out).toEqual([]);
	});

	it("falls back to an empty list when the JSON is the wrong shape (not an array)", async () => {
		await writeFactsFile(workspace, JSON.stringify({ facts: [] }));
		const out = await loadFacts(workspace);
		expect(out).toEqual([]);
	});

	it("skips items missing the required `fact` string but keeps valid siblings", async () => {
		await writeFactsFile(
			workspace,
			JSON.stringify([{ id: "x" }, { fact: "real one" }, { fact: 42 }]),
		);
		const out = await loadFacts(workspace);
		expect(out).toHaveLength(1);
		expect(out[0].fact).toBe("real one");
	});

	it("addFact appends a new entry to the persisted store", async () => {
		const before = await loadFacts(workspace);
		expect(before).toEqual([]);

		const after = await addFact(workspace, { fact: "Use snake_case for Python" });
		expect(after).toHaveLength(1);
		expect(after[0].fact).toBe("Use snake_case for Python");
		expect(after[0].source).toBe("agent");
		expect(after[0].id).toBeTruthy();
		expect(after[0].addedAt).toBeTruthy();

		// Verify it actually hit disk.
		const reread = await loadFacts(workspace);
		expect(reread).toHaveLength(1);
		expect(reread[0].fact).toBe("Use snake_case for Python");
	});

	it("addFact is idempotent on identical fact text", async () => {
		const first = await addFact(workspace, { fact: "Run tests after edits" });
		const second = await addFact(workspace, { fact: "Run tests after edits" });
		expect(first).toHaveLength(1);
		expect(second).toHaveLength(1);
		expect(second[0].id).toBe(first[0].id);
	});

	it("addFact dedupe is case-insensitive and whitespace-tolerant", async () => {
		await addFact(workspace, { fact: "Use   snake_case for Python" });
		const out = await addFact(workspace, { fact: "use snake_case for python" });
		expect(out).toHaveLength(1);
	});

	it("addFact accepts custom source tags", async () => {
		const out = await addFact(workspace, { fact: "x is y", source: "user" });
		expect(out[0].source).toBe("user");
	});

	it("addFact throws when no workspace root is supplied", async () => {
		await expect(addFact("", { fact: "anything" })).rejects.toThrow();
	});
});
