import { describe, expect, it } from "vitest";
import { SUPPORTED_LANGUAGES, detectSymbols, extractSymbolBody } from "../src/code-lens";

describe("detectSymbols (typescript)", () => {
	it("finds top-level functions", () => {
		const src = ["export function add(a: number, b: number): number {", "  return a + b;", "}"].join(
			"\n",
		);
		const symbols = detectSymbols(src, "typescript");
		expect(symbols).toHaveLength(1);
		expect(symbols[0]).toMatchObject({ kind: "function", name: "add", line: 0 });
	});

	it("finds async functions", () => {
		const symbols = detectSymbols("async function fetchData() {}", "typescript");
		expect(symbols[0]?.name).toBe("fetchData");
	});

	it("finds classes", () => {
		const symbols = detectSymbols("export class MyClass<T> extends Base {}", "typescript");
		expect(symbols).toHaveLength(1);
		expect(symbols[0]).toMatchObject({ kind: "class", name: "MyClass" });
	});

	it("finds arrow-function module exports", () => {
		const symbols = detectSymbols(
			"export const handler = async (req) => { return req; };",
			"typescript",
		);
		expect(symbols[0]?.name).toBe("handler");
	});

	it("ignores comments", () => {
		const symbols = detectSymbols("// function fake() {}\nfunction real() {}", "typescript");
		expect(symbols).toHaveLength(1);
		expect(symbols[0].name).toBe("real");
	});
});

describe("detectSymbols (python)", () => {
	it("finds def and async def", () => {
		const src = ["def foo(x):", "    return x", "", "async def bar():", "    pass"].join("\n");
		const symbols = detectSymbols(src, "python");
		expect(symbols.map((s) => s.name)).toEqual(["foo", "bar"]);
	});

	it("finds classes", () => {
		const symbols = detectSymbols("class Spam(Base):\n    pass", "python");
		expect(symbols).toHaveLength(1);
		expect(symbols[0]).toMatchObject({ kind: "class", name: "Spam" });
	});
});

describe("detectSymbols (go)", () => {
	it("finds funcs and methods", () => {
		const src = ["func Plain() {}", "func (r *Recv) Method(x int) error {", "  return nil", "}"].join(
			"\n",
		);
		const symbols = detectSymbols(src, "go");
		expect(symbols.map((s) => s.name)).toEqual(["Plain", "Method"]);
	});

	it("finds struct types", () => {
		const symbols = detectSymbols("type Config struct {\n  Name string\n}", "go");
		expect(symbols[0]).toMatchObject({ kind: "class", name: "Config" });
	});
});

describe("detectSymbols (rust)", () => {
	it("finds pub fns and async fns", () => {
		const src = ["pub fn foo() {}", "pub async fn bar() -> Result<()> { Ok(()) }"].join("\n");
		const symbols = detectSymbols(src, "rust");
		expect(symbols.map((s) => s.name)).toEqual(["foo", "bar"]);
	});

	it("finds structs and traits", () => {
		const src = ["pub struct Config {}", "trait Read {}"].join("\n");
		const symbols = detectSymbols(src, "rust");
		expect(symbols.map((s) => s.name)).toEqual(["Config", "Read"]);
	});
});

describe("detectSymbols (unsupported languages)", () => {
	it("returns nothing for plaintext", () => {
		expect(detectSymbols("just some text\nnothing here", "plaintext")).toEqual([]);
	});
});

describe("extractSymbolBody", () => {
	it("brace-matches TypeScript functions", () => {
		const src = ["function outer() {", "  return 1;", "}", "", "function next() {}"].join("\n");
		expect(extractSymbolBody(src, 0, "typescript")).toBe(
			["function outer() {", "  return 1;", "}"].join("\n"),
		);
	});

	it("uses indentation for Python", () => {
		const src = [
			"def foo(x):",
			"    if x:",
			"        return x",
			"    return 0",
			"",
			"def bar(): pass",
		].join("\n");
		expect(extractSymbolBody(src, 0, "python")).toBe(
			["def foo(x):", "    if x:", "        return x", "    return 0", ""].join("\n"),
		);
	});
});

describe("SUPPORTED_LANGUAGES", () => {
	it("includes the core five", () => {
		for (const lang of ["typescript", "javascript", "python", "go", "rust"]) {
			expect(SUPPORTED_LANGUAGES.has(lang)).toBe(true);
		}
	});
});
