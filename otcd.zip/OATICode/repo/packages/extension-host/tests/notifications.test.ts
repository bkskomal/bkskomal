import { describe, expect, it, vi } from "vitest";
import {
	DISCORD_SECRET_KEY,
	NotificationHub,
	SLACK_SECRET_KEY,
	__test,
} from "../src/notifications";
import { InMemorySecrets } from "../src/storage";

describe("buildSlackPayload", () => {
	const { buildSlackPayload } = __test;

	it("formats kind + title in the text and blocks", () => {
		const p = buildSlackPayload({ kind: "task_completed", title: "Build OK", body: "all good" });
		expect(p.text).toMatch(/Build OK/);
		expect(p.text).toMatch(/task_completed/);
		expect(p.blocks).toBeDefined();
		expect(Array.isArray(p.blocks)).toBe(true);
	});

	it("omits body block when no body provided", () => {
		const p = buildSlackPayload({ kind: "approval_needed", title: "Need approval" });
		expect((p.blocks ?? []).length).toBe(1);
	});
});

describe("buildDiscordPayload", () => {
	const { buildDiscordPayload } = __test;

	it("emits an embed with a color for build_failed", () => {
		const p = buildDiscordPayload({ kind: "build_failed", title: "tests failed" });
		expect(p.embeds?.[0]).toMatchObject({ title: "tests failed" });
		expect(p.embeds?.[0].color).toBe(0xe74c3c);
	});

	it("includes description when body is set", () => {
		const p = buildDiscordPayload({ kind: "task_completed", title: "done", body: "ok" });
		expect(p.embeds?.[0].description).toBe("ok");
	});
});

describe("NotificationHub", () => {
	it("no-ops when neither secret is set", async () => {
		const secrets = new InMemorySecrets();
		const fetchImpl = vi.fn(async () => new Response("", { status: 200 }));
		const hub = new NotificationHub({ secrets, fetchImpl: fetchImpl as unknown as typeof fetch });
		await hub.notify({ kind: "task_completed", title: "hi" });
		expect(fetchImpl).not.toHaveBeenCalled();
	});

	it("posts to slack only when slack url is set", async () => {
		const secrets = new InMemorySecrets();
		await secrets.store(SLACK_SECRET_KEY, "https://hooks.slack.com/services/T/B/X");
		const fetchImpl = vi.fn(async () => new Response("", { status: 200 }));
		const hub = new NotificationHub({ secrets, fetchImpl: fetchImpl as unknown as typeof fetch });
		await hub.notify({ kind: "task_completed", title: "done", body: "yay" });
		expect(fetchImpl).toHaveBeenCalledTimes(1);
		const [url, init] = fetchImpl.mock.calls[0];
		expect(url).toMatch(/hooks\.slack\.com/);
		expect(init?.method).toBe("POST");
		const body = JSON.parse((init?.body as string) ?? "{}");
		expect(body.text).toMatch(/done/);
	});

	it("posts to discord only when discord url is set", async () => {
		const secrets = new InMemorySecrets();
		await secrets.store(DISCORD_SECRET_KEY, "https://discord.com/api/webhooks/1/abc");
		const fetchImpl = vi.fn(async () => new Response("", { status: 200 }));
		const hub = new NotificationHub({ secrets, fetchImpl: fetchImpl as unknown as typeof fetch });
		await hub.notify({ kind: "build_failed", title: "tests failed" });
		expect(fetchImpl).toHaveBeenCalledTimes(1);
		const [url, init] = fetchImpl.mock.calls[0];
		expect(url).toMatch(/discord\.com/);
		const body = JSON.parse((init?.body as string) ?? "{}");
		expect(body.embeds?.[0].title).toBe("tests failed");
	});

	it("posts to both when both urls are set", async () => {
		const secrets = new InMemorySecrets();
		await secrets.store(SLACK_SECRET_KEY, "https://hooks.slack.com/services/x");
		await secrets.store(DISCORD_SECRET_KEY, "https://discord.com/api/webhooks/y");
		const fetchImpl = vi.fn(async () => new Response("", { status: 200 }));
		const hub = new NotificationHub({ secrets, fetchImpl: fetchImpl as unknown as typeof fetch });
		await hub.notify({ kind: "approval_needed", title: "approve" });
		expect(fetchImpl).toHaveBeenCalledTimes(2);
	});

	it("swallows fetch errors silently", async () => {
		const secrets = new InMemorySecrets();
		await secrets.store(SLACK_SECRET_KEY, "https://hooks.slack.com/services/x");
		const log = { lines: [] as string[], appendLine: (m: string) => log.lines.push(m) };
		const fetchImpl = vi.fn(async () => {
			throw new Error("network down");
		});
		const hub = new NotificationHub({
			secrets,
			log,
			fetchImpl: fetchImpl as unknown as typeof fetch,
		});
		// Should NOT throw.
		await hub.notify({ kind: "task_completed", title: "x" });
		expect(log.lines.some((l) => l.includes("slack POST failed"))).toBe(true);
	});
});
