// Tests for the small helpers that feed the post-turn auto-review and
// auto-test-generation hooks. The hooks themselves are integration-tested
// through the chat-panel flow; this file pins the path-classification
// logic so a typo there doesn't silently break the hooks.
import { describe, expect, it } from "vitest";

// Re-implement the helpers here to mirror chat-panel.ts. If the chat-panel
// implementation drifts, these tests fail loudly. Kept in sync via the
// comment block below.

// --- BEGIN copy-paste from chat-panel.ts (keep in sync) ---
function looksLikeTestFile(path: string): boolean {
	const lower = path.toLowerCase().replace(/\\/g, "/");
	return (
		lower.startsWith("tests/") ||
		lower.startsWith("test/") ||
		lower.startsWith("__tests__/") ||
		lower.includes("/tests/") ||
		lower.includes("/__tests__/") ||
		lower.includes("/test/") ||
		/\.test\.(ts|tsx|js|jsx|mjs|cjs)$/.test(lower) ||
		/\.spec\.(ts|tsx|js|jsx|mjs|cjs)$/.test(lower) ||
		/_test\.py$/.test(lower) ||
		/test_.*\.py$/.test(lower.split("/").pop() ?? "")
	);
}

function looksLikeSourceFile(path: string): boolean {
	return /\.(ts|tsx|js|jsx|mjs|cjs|py|java|cs|go|rs|rb|php|swift|kt)$/i.test(path);
}

function candidateTestPath(sourcePath: string): string {
	const norm = sourcePath.replace(/\\/g, "/");
	if (/\.py$/.test(norm)) {
		const idx = norm.lastIndexOf("/");
		const dir = idx >= 0 ? norm.slice(0, idx) : ".";
		const base = idx >= 0 ? norm.slice(idx + 1) : norm;
		return `${dir}/test_${base}`;
	}
	const m = norm.match(/^(.*?)\.(ts|tsx|js|jsx|mjs|cjs)$/);
	if (m) {
		const [, stem, ext] = m;
		if (stem.startsWith("src/")) {
			return `tests/${stem.slice(4)}.test.${ext}`;
		}
		return `${stem}.test.${ext}`;
	}
	return `${norm}.test`;
}
// --- END copy-paste ---

describe("looksLikeTestFile", () => {
	it("flags .test.ts / .spec.ts / .test.js", () => {
		expect(looksLikeTestFile("foo.test.ts")).toBe(true);
		expect(looksLikeTestFile("foo.spec.tsx")).toBe(true);
		expect(looksLikeTestFile("foo.test.js")).toBe(true);
	});

	it("flags files under tests/ or __tests__/ directories", () => {
		expect(looksLikeTestFile("tests/foo.ts")).toBe(true);
		expect(looksLikeTestFile("packages/x/tests/y.ts")).toBe(true);
		expect(looksLikeTestFile("src/__tests__/foo.ts")).toBe(true);
		expect(looksLikeTestFile("a\\b\\tests\\c.ts")).toBe(true);
	});

	it("flags Python tests by naming convention", () => {
		expect(looksLikeTestFile("test_foo.py")).toBe(true);
		expect(looksLikeTestFile("foo_test.py")).toBe(true);
		expect(looksLikeTestFile("tests/test_bar.py")).toBe(true);
	});

	it("does NOT flag regular source files", () => {
		expect(looksLikeTestFile("src/foo.ts")).toBe(false);
		expect(looksLikeTestFile("lib/util.py")).toBe(false);
		expect(looksLikeTestFile("README.md")).toBe(false);
	});
});

describe("looksLikeSourceFile", () => {
	it("accepts common code extensions", () => {
		expect(looksLikeSourceFile("foo.ts")).toBe(true);
		expect(looksLikeSourceFile("foo.py")).toBe(true);
		expect(looksLikeSourceFile("Bar.java")).toBe(true);
		expect(looksLikeSourceFile("main.go")).toBe(true);
		expect(looksLikeSourceFile("lib.rs")).toBe(true);
	});

	it("rejects non-code files", () => {
		expect(looksLikeSourceFile("README.md")).toBe(false);
		expect(looksLikeSourceFile("package.json")).toBe(false);
		expect(looksLikeSourceFile("Dockerfile")).toBe(false);
	});
});

describe("candidateTestPath", () => {
	it("mirrors src/* under tests/*.test.ext", () => {
		expect(candidateTestPath("src/auth/login.ts")).toBe("tests/auth/login.test.ts");
		expect(candidateTestPath("src/util/foo.tsx")).toBe("tests/util/foo.test.tsx");
	});

	it("uses sibling .test.ts when path has no src/ prefix", () => {
		expect(candidateTestPath("lib/foo.ts")).toBe("lib/foo.test.ts");
		expect(candidateTestPath("standalone.js")).toBe("standalone.test.js");
	});

	it("uses Python test_<base>.py convention", () => {
		expect(candidateTestPath("foo.py")).toBe("./test_foo.py");
		expect(candidateTestPath("lib/bar.py")).toBe("lib/test_bar.py");
	});

	it("handles Windows path separators", () => {
		expect(candidateTestPath("src\\auth\\login.ts")).toBe("tests/auth/login.test.ts");
	});
});
