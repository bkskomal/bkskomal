import { describe, expect, it, vi } from "vitest";

// Mock 'vscode' so the tracker module can import workspace.* event
// registrations under test without a real editor. Each event returns a
// disposable; we don't actually fire them through here — we exercise the
// tracker's `record` path through its public methods.
vi.mock("vscode", () => {
	const noopDispose = { dispose: () => {} };
	return {
		workspace: {
			asRelativePath: (uri: { fsPath?: string; path?: string }) => uri.fsPath ?? uri.path ?? "",
			onDidSaveTextDocument: () => noopDispose,
			onDidCreateFiles: () => noopDispose,
			onDidDeleteFiles: () => noopDispose,
			onDidRenameFiles: () => noopDispose,
		},
	};
});

import { WorkspaceChangeTracker, formatChangesAsSystemNote } from "../src/workspace-change-tracker";

// Access the private `record` via a small adapter test-double pattern:
// subclass and expose. Keeps the production surface tight.
class TestableTracker extends WorkspaceChangeTracker {
	exposeRecord(path: string, kind: "created" | "modified" | "deleted"): void {
		// biome-ignore lint/suspicious/noExplicitAny: deliberate access to private.
		(this as any).record(path, kind);
	}
}

describe("WorkspaceChangeTracker", () => {
	it("starts empty", () => {
		const t = new TestableTracker();
		expect(t.drainSinceLastTurn()).toEqual([]);
	});

	it("records and drains a save", () => {
		const t = new TestableTracker();
		t.exposeRecord("src/foo.ts", "modified");
		const out = t.drainSinceLastTurn();
		expect(out).toHaveLength(1);
		expect(out[0].path).toBe("src/foo.ts");
		expect(out[0].kind).toBe("modified");
		// Second drain returns empty (buffer cleared).
		expect(t.drainSinceLastTurn()).toEqual([]);
	});

	it("coalesces multiple saves of the same path", () => {
		const t = new TestableTracker();
		t.exposeRecord("src/foo.ts", "created");
		t.exposeRecord("src/foo.ts", "modified");
		t.exposeRecord("src/foo.ts", "modified");
		const out = t.drainSinceLastTurn();
		expect(out).toHaveLength(1);
		// Last write wins.
		expect(out[0].kind).toBe("modified");
	});

	it("ignores .git, node_modules, .oati, dist, build, out", () => {
		const t = new TestableTracker();
		t.exposeRecord(".git/HEAD", "modified");
		t.exposeRecord("node_modules/foo/index.js", "modified");
		t.exposeRecord(".oati/sessions/abc.json", "modified");
		t.exposeRecord("dist/bundle.js", "modified");
		t.exposeRecord("build/out.js", "modified");
		t.exposeRecord("out/bundle.js", "modified");
		t.exposeRecord("src/keeper.ts", "modified");
		const out = t.drainSinceLastTurn();
		expect(out).toHaveLength(1);
		expect(out[0].path).toBe("src/keeper.ts");
	});

	it("suppresses paths the agent just wrote", () => {
		const t = new TestableTracker();
		t.markAgentWrites(["src/foo.ts"]);
		t.exposeRecord("src/foo.ts", "modified");
		t.exposeRecord("src/external.ts", "modified");
		const out = t.drainSinceLastTurn();
		expect(out).toHaveLength(1);
		expect(out[0].path).toBe("src/external.ts");
	});

	it("formatChangesAsSystemNote groups by kind", () => {
		const note = formatChangesAsSystemNote([
			{ path: "src/a.ts", kind: "modified", at: 1 },
			{ path: "src/b.ts", kind: "modified", at: 2 },
			{ path: "src/c.ts", kind: "created", at: 3 },
			{ path: "src/d.ts", kind: "deleted", at: 4 },
		]);
		expect(note).toContain("[Workspace heads-up]");
		expect(note).toContain("Modified: src/a.ts, src/b.ts");
		expect(note).toContain("Created:  src/c.ts");
		expect(note).toContain("Deleted:  src/d.ts");
	});

	it("formatChangesAsSystemNote returns empty string when nothing changed", () => {
		expect(formatChangesAsSystemNote([])).toBe("");
	});

	it("formatChangesAsSystemNote truncates with +N more when over 12 files", () => {
		const many = Array.from({ length: 15 }, (_, i) => ({
			path: `src/${i}.ts`,
			kind: "modified" as const,
			at: i,
		}));
		const note = formatChangesAsSystemNote(many);
		expect(note).toMatch(/\(\+3 more\)/);
	});

	it("peek returns current state without clearing", () => {
		const t = new TestableTracker();
		t.exposeRecord("src/foo.ts", "modified");
		expect(t.peek()).toHaveLength(1);
		// Still there after peek.
		expect(t.drainSinceLastTurn()).toHaveLength(1);
	});
});
