// Live-provider critic battle-test.
//
// Replays every fixture in `critic-fixtures.ts` against the REAL provider
// you configure via env vars and reports per-category accuracy + a
// confusion matrix + precision/recall for the rejection class.
//
// Skipped by default — opt in by setting OATI_EVAL_LIVE=1. The fixture-only
// parser tests in `critic-battle.test.ts` run unconditionally; this one
// makes real network calls so it has to stay off the default path.
//
// Required env when OATI_EVAL_LIVE=1:
//   OATI_EVAL_PROVIDER_TYPE   "anthropic" | "openai-compatible"
//   OATI_EVAL_MODEL_ID        e.g. "claude-sonnet-4-6"
//   OATI_EVAL_API_KEY         provider api key
// Optional:
//   OATI_EVAL_BASE_URL        override the endpoint
//   OATI_EVAL_FILTER          substring; only run fixtures whose name contains it
//
// Cost: ~13 streaming critic calls per run (one per fixture). Cheap on
// Sonnet/Haiku, single-digit cents. Not free, hence opt-in.

import { CRITIC_BATTLE_CASES, countByCategory, runCritic } from "@oati/agent-core";
import { createProviderFromConfig } from "@oati/providers";
import type { ProviderConfig } from "@oati/shared";
import { describe, expect, it } from "vitest";

const ENABLED = process.env.OATI_EVAL_LIVE === "1";

describe.skipIf(!ENABLED)("critic battle-test against live provider", () => {
	const providerType = process.env.OATI_EVAL_PROVIDER_TYPE as ProviderConfig["type"];
	const modelId = process.env.OATI_EVAL_MODEL_ID ?? "";
	const apiKey = process.env.OATI_EVAL_API_KEY ?? "";
	const baseUrl = process.env.OATI_EVAL_BASE_URL;
	const filter = process.env.OATI_EVAL_FILTER;

	it("env is set up", () => {
		expect(providerType, "OATI_EVAL_PROVIDER_TYPE").toBeTruthy();
		expect(modelId, "OATI_EVAL_MODEL_ID").toBeTruthy();
		expect(apiKey, "OATI_EVAL_API_KEY").toBeTruthy();
	});

	it("reports accuracy + precision/recall across the fixture set", async () => {
		const config = {
			id: "eval",
			displayName: "eval",
			type: providerType,
			defaultModel: modelId,
			...(baseUrl ? { baseUrl } : {}),
		} as ProviderConfig;
		const provider = createProviderFromConfig(config, apiKey);

		const cases = filter
			? CRITIC_BATTLE_CASES.filter((c) => c.name.includes(filter))
			: CRITIC_BATTLE_CASES;
		expect(cases.length, "no fixtures matched filter").toBeGreaterThan(0);

		const coverage = countByCategory(cases);
		const header = [
			`\nRunning ${cases.length} fixture(s) against ${providerType}/${modelId}`,
			`Coverage: approval=${coverage.approval} rejection=${coverage.rejection} edge=${coverage.edge}\n`,
		].join("\n");
		console.log(header);

		const confusion = {
			approved: { approved: 0, needs_retry: 0 },
			needs_retry: { approved: 0, needs_retry: 0 },
		};
		const mismatches: Array<{ name: string; expected: string; predicted: string }> = [];

		for (const c of cases) {
			const result = await runCritic({
				provider,
				modelId,
				userTask: c.task,
				executorSummary: c.executorSummary,
			});
			confusion[c.expectedVerdict][result.verdict] += 1;
			const correct = result.verdict === c.expectedVerdict;
			console.log(
				`  [${c.category}] ${correct ? "✓" : "✗"} ${c.name} — expected=${c.expectedVerdict} predicted=${result.verdict}`,
			);
			if (!correct) {
				mismatches.push({
					name: c.name,
					expected: c.expectedVerdict,
					predicted: result.verdict,
				});
			}
		}

		const tp = confusion.needs_retry.needs_retry;
		const fp = confusion.approved.needs_retry;
		const fn = confusion.needs_retry.approved;
		const tn = confusion.approved.approved;
		const precision = tp + fp === 0 ? 1 : tp / (tp + fp);
		const recall = tp + fn === 0 ? 1 : tp / (tp + fn);
		const accuracy = (tp + tn) / Math.max(1, tp + tn + fp + fn);

		const ar = String(confusion.approved.needs_retry).padStart(8);
		const aa = String(confusion.approved.approved).padStart(8);
		const nr = String(confusion.needs_retry.needs_retry).padStart(8);
		const na = String(confusion.needs_retry.approved).padStart(8);
		const summary = [
			"\nConfusion matrix (rows=expected, cols=predicted):",
			"                  approved   needs_retry",
			`  approved        ${aa}   ${ar}`,
			`  needs_retry     ${na}   ${nr}`,
			"",
			'Rejection-class (positive = "needs_retry"):',
			`  Precision: ${(precision * 100).toFixed(1)}%`,
			`  Recall   : ${(recall * 100).toFixed(1)}%`,
			`  Accuracy : ${(accuracy * 100).toFixed(1)}%`,
			"",
		].join("\n");
		console.log(summary);

		// We don't fail the test on a few wrong verdicts — the value here is
		// the report, not a binary pass/fail. But surface mismatches so the
		// caller has a structured list to inspect.
		if (mismatches.length > 0) {
			const mismatchLines = [
				`${mismatches.length} mismatch(es):`,
				...mismatches.map((m) => `  - ${m.name}: expected=${m.expected} predicted=${m.predicted}`),
			].join("\n");
			console.log(mismatchLines);
		}

		// Soft sanity bound: the critic should beat random (50%) by a wide
		// margin on this fixture set. If we're below 65%, the prompt or model
		// is likely degraded and the run should fail loudly.
		expect(accuracy).toBeGreaterThanOrEqual(0.65);
	}, 60_000);
});
