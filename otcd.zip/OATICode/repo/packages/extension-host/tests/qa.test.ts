import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { formatQAResult, isCategoryEnabled, resolveTestFramework, runQA } from "../src/qa";

function mockProvider(responseText: string): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			yield { type: "text_delta", text: responseText };
			yield { type: "message_end", stopReason: "end" };
		},
	};
}

describe("isCategoryEnabled", () => {
	it("returns true for defaults that are advisory", () => {
		expect(isCategoryEnabled(undefined, "testPlan")).toBe(true);
		expect(isCategoryEnabled(undefined, "unitTests")).toBe(true);
		expect(isCategoryEnabled(undefined, "edgeCases")).toBe(true);
	});

	it("returns false for defaults that are off", () => {
		expect(isCategoryEnabled(undefined, "e2e")).toBe(false);
		expect(isCategoryEnabled(undefined, "mutation")).toBe(false);
	});

	it("respects explicit user overrides", () => {
		expect(isCategoryEnabled({ categories: { testPlan: "off" } }, "testPlan")).toBe(false);
		expect(isCategoryEnabled({ categories: { e2e: "advisory" } }, "e2e")).toBe(true);
	});
});

describe("resolveTestFramework", () => {
	it("returns the explicit setting when configured", () => {
		expect(resolveTestFramework({ testFramework: "pytest" }, [])).toBe("pytest");
		expect(resolveTestFramework({ testFramework: "junit" }, [])).toBe("junit");
	});

	it("falls back to auto-detect when set to 'auto' or omitted", () => {
		expect(resolveTestFramework(undefined, ['"vitest":'])).toBe("vitest");
		expect(resolveTestFramework(undefined, ['"jest":'])).toBe("jest");
		expect(resolveTestFramework(undefined, ["pyproject.toml content with pytest"])).toBe("pytest");
		expect(resolveTestFramework({ testFramework: "auto" }, ['"mocha":'])).toBe("mocha");
	});

	it("defaults to vitest for empty hints", () => {
		expect(resolveTestFramework(undefined, [])).toBe("vitest");
	});
});

describe("runQA", () => {
	it("refuses when the subcommand's category is off", async () => {
		const result = await runQA({
			provider: mockProvider("{}"),
			modelId: "any",
			cfg: { categories: { testPlan: "off" } },
			subcommand: "plan",
			args: "build a login feature",
			targetFiles: [],
			frameworkHints: [],
		});
		expect(result.summary).toMatch(/disabled/i);
		expect(result.artifacts).toHaveLength(0);
	});

	it("parses a clean JSON response with artifacts", async () => {
		const response = JSON.stringify({
			summary: "Generated 1 unit test file.",
			artifacts: [
				{
					path: "tests/auth/login.test.ts",
					content: "import { test } from 'vitest'\ntest('it works', () => {})",
					purpose: "Covers the login function happy path.",
				},
			],
			notes: ["Consider also testing token refresh."],
		});
		const result = await runQA({
			provider: mockProvider(response),
			modelId: "any",
			cfg: undefined,
			subcommand: "unit",
			args: "src/auth/login.ts",
			targetFiles: [{ path: "src/auth/login.ts", content: "export function login() {}" }],
			frameworkHints: ['"vitest":'],
		});
		expect(result.artifacts).toHaveLength(1);
		expect(result.artifacts[0].path).toBe("tests/auth/login.test.ts");
		expect(result.notes).toHaveLength(1);
		expect(result.needsTestRun).toBe(true);
	});

	it("strips ```json``` fences", async () => {
		const response =
			'```json\n{"summary":"ok","artifacts":[{"path":"a.ts","content":"x"}],"notes":[]}\n```';
		const result = await runQA({
			provider: mockProvider(response),
			modelId: "any",
			cfg: undefined,
			subcommand: "unit",
			args: "src/x.ts",
			targetFiles: [],
			frameworkHints: [],
		});
		expect(result.artifacts).toHaveLength(1);
	});

	it("handles unparseable response gracefully", async () => {
		const result = await runQA({
			provider: mockProvider("not json at all"),
			modelId: "any",
			cfg: undefined,
			subcommand: "unit",
			args: "src/x.ts",
			targetFiles: [],
			frameworkHints: [],
		});
		expect(result.artifacts).toHaveLength(0);
		expect(result.summary).toMatch(/could not parse/i);
	});

	it("surfaces provider errors", async () => {
		const errProvider: ProviderSpec = {
			id: "e",
			displayName: "e",
			async *stream(_r: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
				yield { type: "error", message: "rate limit" };
				yield { type: "message_end", stopReason: "error" };
			},
		};
		const result = await runQA({
			provider: errProvider,
			modelId: "any",
			cfg: undefined,
			subcommand: "plan",
			args: "feat",
			targetFiles: [],
			frameworkHints: [],
		});
		expect(result.summary).toMatch(/rate limit/i);
	});

	it("plan subcommand passes needsTestRun=false", async () => {
		const response = JSON.stringify({
			summary: "Plan generated",
			artifacts: [{ path: "TEST_PLAN.md", content: "# Plan" }],
			notes: [],
		});
		const result = await runQA({
			provider: mockProvider(response),
			modelId: "any",
			cfg: undefined,
			subcommand: "plan",
			args: "build search",
			targetFiles: [],
			frameworkHints: [],
		});
		expect(result.needsTestRun).toBe(false);
	});
});

describe("formatQAResult", () => {
	it("includes artifact paths in the rendered markdown", () => {
		const md = formatQAResult({
			subcommand: "unit",
			summary: "wrote 2 tests",
			artifacts: [
				{ path: "tests/a.test.ts", content: "x", purpose: "first" },
				{ path: "tests/b.test.ts", content: "y", purpose: "second" },
			],
			notes: ["consider X"],
			needsTestRun: true,
		});
		expect(md).toContain("tests/a.test.ts");
		expect(md).toContain("tests/b.test.ts");
		expect(md).toContain("consider X");
		expect(md).toContain("/test-loop");
	});

	it("does not show the test-loop nudge when needsTestRun is false", () => {
		const md = formatQAResult({
			subcommand: "plan",
			summary: "ok",
			artifacts: [{ path: "TEST_PLAN.md", content: "x", purpose: "" }],
			notes: [],
			needsTestRun: false,
		});
		expect(md).not.toContain("/test-loop");
	});
});
