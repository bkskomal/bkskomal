import { beforeEach, describe, expect, it } from "vitest";
import {
	_resetScratchpadsForTest,
	dropScratchpad,
	ensureScratchpad,
	scratchpadRead,
	scratchpadWrite,
} from "../src/scratchpad";

describe("sub-agent shared scratchpad", () => {
	beforeEach(() => {
		_resetScratchpadsForTest();
	});

	it("returns an empty list for an unknown parent agent id", () => {
		expect(scratchpadRead("nonexistent")).toEqual([]);
	});

	it("returns an empty list for an empty id (top-level agent)", () => {
		expect(scratchpadRead("")).toEqual([]);
	});

	it("write is a no-op when no bucket exists", () => {
		scratchpadWrite("orphan", "dropped");
		expect(scratchpadRead("orphan")).toEqual([]);
	});

	it("appends notes after the bucket is initialized", () => {
		ensureScratchpad("parent_A");
		scratchpadWrite("parent_A", "first finding");
		scratchpadWrite("parent_A", "second finding", "agent_B");
		const notes = scratchpadRead("parent_A");
		expect(notes).toHaveLength(2);
		expect(notes[0].note).toBe("first finding");
		expect(notes[1].author).toBe("agent_B");
	});

	it("isolates notes between parent runs", () => {
		ensureScratchpad("parent_A");
		ensureScratchpad("parent_B");
		scratchpadWrite("parent_A", "from A");
		scratchpadWrite("parent_B", "from B");
		expect(scratchpadRead("parent_A").map((n) => n.note)).toEqual(["from A"]);
		expect(scratchpadRead("parent_B").map((n) => n.note)).toEqual(["from B"]);
	});

	it("sibling sub-agents (sharing the same parent id) see each other's notes", () => {
		ensureScratchpad("parent_X");
		// Two sibling sub-agents writing under the same parent bucket.
		scratchpadWrite("parent_X", "alpha discovered", "sub_1");
		scratchpadWrite("parent_X", "beta discovered", "sub_2");
		const seen = scratchpadRead("parent_X").map((n) => n.note);
		expect(seen).toEqual(["alpha discovered", "beta discovered"]);
	});

	it("dropScratchpad clears the bucket when the parent run completes", () => {
		ensureScratchpad("parent_drop");
		scratchpadWrite("parent_drop", "ephemeral");
		expect(scratchpadRead("parent_drop")).toHaveLength(1);
		dropScratchpad("parent_drop");
		expect(scratchpadRead("parent_drop")).toEqual([]);
		// Writes after drop are silently no-op.
		scratchpadWrite("parent_drop", "after drop");
		expect(scratchpadRead("parent_drop")).toEqual([]);
	});

	it("dropScratchpad on a non-existent bucket is a no-op", () => {
		expect(() => dropScratchpad("never_existed")).not.toThrow();
	});

	it("ensureScratchpad with an empty id is a no-op", () => {
		ensureScratchpad("");
		expect(scratchpadRead("")).toEqual([]);
	});
});
