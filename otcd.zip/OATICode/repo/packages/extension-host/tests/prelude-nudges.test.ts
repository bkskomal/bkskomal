import { describe, expect, it } from "vitest";
import {
	PLAN_NUDGE,
	TDD_NUDGE,
	shouldInjectPlanNudge,
	shouldInjectTddNudge,
} from "../src/prelude-nudges";

describe("shouldInjectPlanNudge", () => {
	it("never fires when mode is off", () => {
		expect(shouldInjectPlanNudge("off", "refactor everything across the codebase")).toBe(false);
		expect(shouldInjectPlanNudge("off", "x".repeat(10_000))).toBe(false);
	});

	it("always fires when mode is on", () => {
		expect(shouldInjectPlanNudge("on", "fix typo")).toBe(true);
		expect(shouldInjectPlanNudge("on", "")).toBe(true);
	});

	describe("auto mode", () => {
		it("skips empty / whitespace prompts", () => {
			expect(shouldInjectPlanNudge("auto", "")).toBe(false);
			expect(shouldInjectPlanNudge("auto", "   \n  ")).toBe(false);
		});

		it("skips short, trivial-looking prompts", () => {
			expect(shouldInjectPlanNudge("auto", "fix this typo")).toBe(false);
			expect(shouldInjectPlanNudge("auto", "what does foo do?")).toBe(false);
			expect(shouldInjectPlanNudge("auto", "rename x to y")).toBe(false);
		});

		it("fires on long prompts even without keywords", () => {
			// Length-based trigger: anything ≥ 250 chars suggests enough context
			// to warrant a plan, even when it lacks the keyword vocabulary.
			const longProse = "Please look at the user profile screen ".repeat(8);
			expect(longProse.length).toBeGreaterThanOrEqual(250);
			expect(shouldInjectPlanNudge("auto", longProse)).toBe(true);
		});

		it("fires on multi-step keywords (refactor, rewrite, migrate)", () => {
			expect(shouldInjectPlanNudge("auto", "refactor the auth module")).toBe(true);
			expect(shouldInjectPlanNudge("auto", "rewrite the parser")).toBe(true);
			expect(shouldInjectPlanNudge("auto", "migrate from axios to fetch")).toBe(true);
		});

		it("fires on 'implement' / 'add a new' phrasing", () => {
			expect(shouldInjectPlanNudge("auto", "implement OAuth login")).toBe(true);
			expect(shouldInjectPlanNudge("auto", "add a new endpoint for /healthz")).toBe(true);
		});

		it("fires on 'across' / 'everywhere' / 'all files'", () => {
			expect(shouldInjectPlanNudge("auto", "update the import path across packages")).toBe(true);
			expect(shouldInjectPlanNudge("auto", "remove the old API call everywhere")).toBe(true);
			expect(shouldInjectPlanNudge("auto", "bump the version in all files")).toBe(true);
		});

		it("is case-insensitive on keywords", () => {
			expect(shouldInjectPlanNudge("auto", "REFACTOR the parser")).toBe(true);
			expect(shouldInjectPlanNudge("auto", "Implement OAuth")).toBe(true);
		});

		it("does not fire on innocuous uses of the word 'add'", () => {
			// "add" alone is too common — only "add a new X" triggers.
			expect(shouldInjectPlanNudge("auto", "can you add 2 and 2")).toBe(false);
			expect(shouldInjectPlanNudge("auto", "add the comment here")).toBe(false);
		});
	});
});

describe("shouldInjectTddNudge", () => {
	it("only fires when on", () => {
		expect(shouldInjectTddNudge("off")).toBe(false);
		expect(shouldInjectTddNudge("on")).toBe(true);
	});
});

describe("nudge bodies", () => {
	it("plan nudge mentions acceptance criteria", () => {
		expect(PLAN_NUDGE).toMatch(/acceptance criterion|Done when/i);
	});

	it("plan nudge tells the model to skip trivial tasks", () => {
		expect(PLAN_NUDGE).toMatch(/trivial/i);
	});

	it("tdd nudge tells the model to confirm the test fails before writing source", () => {
		expect(TDD_NUDGE).toMatch(/confirm it fails/i);
	});

	it("tdd nudge calls out cases where it doesn't apply", () => {
		expect(TDD_NUDGE).toMatch(/doesn'?t apply|refactor|prose/i);
	});
});
