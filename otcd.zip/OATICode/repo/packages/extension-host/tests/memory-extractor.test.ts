import type {
	ConversationMessage,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
} from "@oati/shared";
import { describe, expect, it } from "vitest";
import { extractMemorySuggestions, turnHasMutation } from "../src/memory-extractor";

function mockProvider(json: string): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			yield { type: "text_delta", text: json };
			yield { type: "message_end", stopReason: "end" };
		},
	};
}

const userMsg = (text: string): ConversationMessage => ({
	role: "user",
	parts: [{ kind: "text", text }],
});

const assistantWithCalls = (
	calls: readonly { name: string; args?: unknown }[],
): ConversationMessage => ({
	role: "assistant",
	parts: calls.map((c, i) => ({
		kind: "tool_call",
		id: `c${i}`,
		name: c.name,
		args: c.args ?? {},
	})),
});

describe("turnHasMutation", () => {
	it("returns false when latest turn used only investigation tools", () => {
		const history: ConversationMessage[] = [
			userMsg("explore the workspace"),
			assistantWithCalls([{ name: "workspace_context" }, { name: "read_file" }]),
		];
		expect(turnHasMutation(history)).toBe(false);
	});

	it("returns true when latest turn wrote a file", () => {
		const history: ConversationMessage[] = [
			userMsg("create foo.ts"),
			assistantWithCalls([{ name: "write_file", args: { path: "foo.ts", content: "x" } }]),
		];
		expect(turnHasMutation(history)).toBe(true);
	});

	it("returns true when latest turn ran exec", () => {
		const history: ConversationMessage[] = [
			userMsg("run tests"),
			assistantWithCalls([{ name: "exec", args: { command: "npm test" } }]),
		];
		expect(turnHasMutation(history)).toBe(true);
	});

	it("looks only at the most-recent turn (post-last-user)", () => {
		const history: ConversationMessage[] = [
			userMsg("create file"),
			assistantWithCalls([{ name: "write_file" }]),
			userMsg("now read another"),
			assistantWithCalls([{ name: "read_file" }]),
		];
		expect(turnHasMutation(history)).toBe(false);
	});

	it("returns false on empty history", () => {
		expect(turnHasMutation([])).toBe(false);
	});
});

describe("extractMemorySuggestions", () => {
	it("returns empty array when model returns []", async () => {
		const provider = mockProvider("[]");
		const out = await extractMemorySuggestions({
			provider,
			modelId: "any",
			history: [
				userMsg("set up tests"),
				assistantWithCalls([{ name: "write_file", args: { path: "vitest.config.ts" } }]),
			],
			existingFacts: [],
		});
		expect(out).toEqual([]);
	});

	it("parses a valid two-item suggestion array", async () => {
		const provider = mockProvider(
			JSON.stringify([
				{
					fact: "Tests run via vitest in this repo",
					reasoning: "Agent created vitest.config.ts",
					confidence: "high",
				},
				{
					fact: "User prefers descriptive names",
					reasoning: "User asked to rename x to parsedConfig",
					confidence: "medium",
				},
			]),
		);
		const out = await extractMemorySuggestions({
			provider,
			modelId: "any",
			history: [userMsg("set up vitest"), assistantWithCalls([{ name: "write_file" }])],
			existingFacts: [],
		});
		expect(out).toHaveLength(2);
		expect(out[0].fact).toContain("vitest");
		expect(out[0].confidence).toBe("high");
		expect(out[1].confidence).toBe("medium");
	});

	it("caps output at 2 even if model returns more", async () => {
		const provider = mockProvider(
			JSON.stringify([
				{ fact: "A", reasoning: "r", confidence: "high" },
				{ fact: "B", reasoning: "r", confidence: "high" },
				{ fact: "C", reasoning: "r", confidence: "high" },
				{ fact: "D", reasoning: "r", confidence: "high" },
			]),
		);
		const out = await extractMemorySuggestions({
			provider,
			modelId: "any",
			history: [userMsg("x"), assistantWithCalls([{ name: "write_file" }])],
			existingFacts: [],
		});
		expect(out).toHaveLength(2);
	});

	it("strips ```json fences from the model output", async () => {
		const provider = mockProvider('```json\n[{"fact":"X","reasoning":"r","confidence":"high"}]\n```');
		const out = await extractMemorySuggestions({
			provider,
			modelId: "any",
			history: [userMsg("x"), assistantWithCalls([{ name: "write_file" }])],
			existingFacts: [],
		});
		expect(out).toHaveLength(1);
		expect(out[0].fact).toBe("X");
	});

	it("returns empty array when parse fails", async () => {
		const provider = mockProvider("totally not JSON");
		const out = await extractMemorySuggestions({
			provider,
			modelId: "any",
			history: [userMsg("x"), assistantWithCalls([{ name: "write_file" }])],
			existingFacts: [],
		});
		expect(out).toEqual([]);
	});

	it("defaults missing confidence to medium", async () => {
		const provider = mockProvider(JSON.stringify([{ fact: "X", reasoning: "r" }]));
		const out = await extractMemorySuggestions({
			provider,
			modelId: "any",
			history: [userMsg("x"), assistantWithCalls([{ name: "write_file" }])],
			existingFacts: [],
		});
		expect(out).toHaveLength(1);
		expect(out[0].confidence).toBe("medium");
	});

	it("skips items missing a fact field", async () => {
		const provider = mockProvider(
			JSON.stringify([
				{ reasoning: "r", confidence: "high" },
				{ fact: "Valid one", reasoning: "r", confidence: "low" },
			]),
		);
		const out = await extractMemorySuggestions({
			provider,
			modelId: "any",
			history: [userMsg("x"), assistantWithCalls([{ name: "write_file" }])],
			existingFacts: [],
		});
		expect(out).toHaveLength(1);
		expect(out[0].fact).toBe("Valid one");
	});
});
