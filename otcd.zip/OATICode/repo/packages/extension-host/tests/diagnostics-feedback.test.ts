import type { DiagnosticEntry, DiagnosticsProvider } from "@oati/shared";
import { describe, expect, it } from "vitest";
import {
	DiagnosticsFeedbackTracker,
	formatDiagnosticsAsSystemNote,
} from "../src/diagnostics-feedback";

function fakeProvider(diagsByPass: readonly (readonly DiagnosticEntry[])[]): DiagnosticsProvider {
	let idx = 0;
	return {
		async all() {
			const out = diagsByPass[Math.min(idx, diagsByPass.length - 1)];
			idx++;
			return [...out];
		},
		onChange(_listener) {
			return () => undefined;
		},
	};
}

const errA: DiagnosticEntry = {
	path: "src/a.ts",
	line: 10,
	column: 5,
	endLine: 10,
	endColumn: 12,
	severity: "error",
	message: "Cannot find name 'foo'",
};
const errB: DiagnosticEntry = {
	path: "src/b.ts",
	line: 22,
	column: 1,
	endLine: 22,
	endColumn: 4,
	severity: "error",
	message: "Type 'X' is not assignable to type 'Y'",
};
const warnC: DiagnosticEntry = {
	path: "src/c.ts",
	line: 5,
	column: 1,
	endLine: 5,
	endColumn: 10,
	severity: "warning",
	message: "Unused import 'qux'",
};

describe("DiagnosticsFeedbackTracker", () => {
	it("first drain surfaces every current diagnostic as new", async () => {
		const t = new DiagnosticsFeedbackTracker(fakeProvider([[errA, errB]]));
		const out = await t.drainNewSince();
		expect(out).toHaveLength(2);
	});

	it("second drain returns nothing if state is unchanged", async () => {
		const t = new DiagnosticsFeedbackTracker(fakeProvider([[errA], [errA]]));
		await t.drainNewSince();
		const second = await t.drainNewSince();
		expect(second).toHaveLength(0);
	});

	it("surfaces only NEW entries between turns", async () => {
		const t = new DiagnosticsFeedbackTracker(fakeProvider([[errA], [errA, errB]]));
		await t.drainNewSince();
		const second = await t.drainNewSince();
		expect(second).toHaveLength(1);
		expect(second[0]).toBe(errB);
	});

	it("does NOT re-surface diagnostics that disappeared and came back identical", async () => {
		// Pass 1: [errA]. Pass 2: []. Pass 3: [errA].
		// After pass 2 the snapshot is empty; pass 3 sees errA again as "new" — that IS the intended behavior.
		const t = new DiagnosticsFeedbackTracker(fakeProvider([[errA], [], [errA]]));
		await t.drainNewSince();
		const passTwo = await t.drainNewSince();
		expect(passTwo).toHaveLength(0);
		const passThree = await t.drainNewSince();
		// Re-appeared → counted as new again, because between turns it had genuinely vanished.
		expect(passThree).toHaveLength(1);
	});

	it("sorts errors before warnings", async () => {
		const t = new DiagnosticsFeedbackTracker(fakeProvider([[warnC, errA, errB]]));
		const out = await t.drainNewSince();
		expect(out[0].severity).toBe("error");
		expect(out[out.length - 1].severity).toBe("warning");
	});

	it("caps at 20 entries", async () => {
		const many: DiagnosticEntry[] = [];
		for (let i = 0; i < 30; i++) {
			many.push({ ...errA, line: i, message: `err ${i}` });
		}
		const t = new DiagnosticsFeedbackTracker(fakeProvider([many]));
		const out = await t.drainNewSince();
		expect(out).toHaveLength(20);
	});

	it("formatDiagnosticsAsSystemNote returns empty string when nothing new", () => {
		expect(formatDiagnosticsAsSystemNote([])).toBe("");
	});

	it("formatDiagnosticsAsSystemNote includes path:line + message", () => {
		const note = formatDiagnosticsAsSystemNote([errA, errB, warnC]);
		expect(note).toContain("[Diagnostics]");
		expect(note).toContain("2 new errors");
		expect(note).toContain("1 warning");
		expect(note).toContain("src/a.ts:10:5");
		expect(note).toContain("Cannot find name 'foo'");
		expect(note).toContain("src/b.ts:22:1");
		expect(note).toContain("src/c.ts:5:1");
	});

	it("resetBaseline forces every current diagnostic to be re-surfaced next drain", async () => {
		const t = new DiagnosticsFeedbackTracker(fakeProvider([[errA], [errA]]));
		await t.drainNewSince();
		t.resetBaseline();
		const out = await t.drainNewSince();
		expect(out).toHaveLength(1);
	});
});
