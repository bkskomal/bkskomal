import { describe, expect, it } from "vitest";
import { assemblePersonaPrelude, getPersona, listPersonas } from "../src/personas";

describe("personas catalog (R5-D)", () => {
	it("lists six built-in personas in stable order", () => {
		const ids = listPersonas().map((p) => p.id);
		expect(ids).toEqual([
			"junior-dev",
			"senior-reviewer",
			"security-auditor",
			"perf-optimizer",
			"doc-writer",
			"refactorer",
		]);
	});

	it("each persona has a non-empty displayName, description, and addendum", () => {
		for (const p of listPersonas()) {
			expect(p.displayName.length).toBeGreaterThan(0);
			expect(p.description.length).toBeGreaterThan(0);
			expect(p.systemPromptAddendum.length).toBeGreaterThan(20);
		}
	});

	it("getPersona returns undefined for unknown / cleared ids", () => {
		expect(getPersona(undefined)).toBeUndefined();
		expect(getPersona(null)).toBeUndefined();
		expect(getPersona("")).toBeUndefined();
		expect(getPersona("nope")).toBeUndefined();
	});

	it("getPersona returns the matching record", () => {
		const p = getPersona("security-auditor");
		expect(p?.displayName).toBe("Security Auditor");
	});

	it("assemblePersonaPrelude returns empty string for unknown ids", () => {
		expect(assemblePersonaPrelude(undefined)).toBe("");
		expect(assemblePersonaPrelude("nope")).toBe("");
	});

	it("assemblePersonaPrelude returns the addendum for a known id", () => {
		const out = assemblePersonaPrelude("refactorer");
		expect(out).toContain("Persona: Refactorer");
		expect(out).toContain("zero behavior changes");
	});
});
