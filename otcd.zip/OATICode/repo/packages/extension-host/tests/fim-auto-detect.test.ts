import { describe, expect, it, vi } from "vitest";
import { maybeShowFimSuggestion, shouldSuggestFimModel } from "../src/fim-auto-detect";

describe("shouldSuggestFimModel (pure decision)", () => {
	it("does not suggest when already dismissed", () => {
		const r = shouldSuggestFimModel({
			activeChatModelId: "moonshotai/kimi-k2",
			completionModelOverride: "",
			alreadyDismissed: true,
		});
		expect(r.shouldShow).toBe(false);
		expect(r.reason).toContain("dismissed");
	});

	it("does not suggest when user already configured a completion model", () => {
		const r = shouldSuggestFimModel({
			activeChatModelId: "moonshotai/kimi-k2",
			completionModelOverride: "qwen2.5-coder:7b",
			alreadyDismissed: false,
		});
		expect(r.shouldShow).toBe(false);
		expect(r.reason).toContain("already configured");
	});

	it("does not suggest when there's no active chat model yet", () => {
		const r = shouldSuggestFimModel({
			activeChatModelId: undefined,
			completionModelOverride: "",
			alreadyDismissed: false,
		});
		expect(r.shouldShow).toBe(false);
	});

	it("does not suggest when the chat model is already FIM-capable", () => {
		// qwen-coder is fimCapable=true per model-quirks.
		const r = shouldSuggestFimModel({
			activeChatModelId: "qwen3-coder",
			completionModelOverride: "",
			alreadyDismissed: false,
		});
		expect(r.shouldShow).toBe(false);
		expect(r.reason).toContain("FIM-capable");
	});

	it("DOES suggest when chat model is heavy (Kimi K2.6)", () => {
		const r = shouldSuggestFimModel({
			activeChatModelId: "moonshotai/kimi-k2",
			completionModelOverride: "",
			alreadyDismissed: false,
		});
		expect(r.shouldShow).toBe(true);
		expect(r.reason).toContain("heavy");
	});

	it("DOES suggest when chat model is Claude (frontier-tier, fimCapable=false)", () => {
		const r = shouldSuggestFimModel({
			activeChatModelId: "claude-sonnet-4-6",
			completionModelOverride: "",
			alreadyDismissed: false,
		});
		expect(r.shouldShow).toBe(true);
	});

	it("DOES suggest when chat model is GPT-4o (frontier-tier, fimCapable=false)", () => {
		const r = shouldSuggestFimModel({
			activeChatModelId: "gpt-4o",
			completionModelOverride: "",
			alreadyDismissed: false,
		});
		expect(r.shouldShow).toBe(true);
	});
});

describe("maybeShowFimSuggestion (integration)", () => {
	function makeKv() {
		const store = new Map<string, unknown>();
		return {
			get: <T>(key: string) => store.get(key) as T | undefined,
			update: async (key: string, value: unknown) => {
				if (value === undefined) store.delete(key);
				else store.set(key, value);
			},
			__store: store,
		};
	}

	it("shows the toast when conditions match, marks dismissed afterward", async () => {
		const kv = makeKv();
		const showInfo = vi.fn(async (_msg: string, ..._actions: string[]) => undefined);
		await maybeShowFimSuggestion("moonshotai/kimi-k2", {
			kv,
			showInfo: showInfo as never,
		});
		expect(showInfo).toHaveBeenCalledTimes(1);
		expect(kv.__store.get("oati.toast.fimSuggestionShown")).toBe(true);
	});

	it("does NOT show the toast on a second call (dismissed flag set)", async () => {
		const kv = makeKv();
		const showInfo = vi.fn(async (_msg: string, ..._actions: string[]) => undefined);
		await maybeShowFimSuggestion("moonshotai/kimi-k2", {
			kv,
			showInfo: showInfo as never,
		});
		await maybeShowFimSuggestion("moonshotai/kimi-k2", {
			kv,
			showInfo: showInfo as never,
		});
		expect(showInfo).toHaveBeenCalledTimes(1);
	});

	it("opens settings when user picks the 'Open setting' action", async () => {
		const kv = makeKv();
		const showInfo = vi.fn(async (_msg: string, ...actions: string[]) => actions[0]);
		const executeCommand = vi.fn(async () => undefined);
		await maybeShowFimSuggestion("moonshotai/kimi-k2", {
			kv,
			showInfo: showInfo as never,
			executeCommand: executeCommand as never,
		});
		expect(executeCommand).toHaveBeenCalledWith(
			"workbench.action.openSettings",
			"oati.inlineCompletion.model",
		);
	});

	it("doesn't show or execute anything when chat model is already FIM-capable", async () => {
		const kv = makeKv();
		const showInfo = vi.fn(async () => undefined);
		await maybeShowFimSuggestion("qwen3-coder", {
			kv,
			showInfo: showInfo as never,
		});
		expect(showInfo).not.toHaveBeenCalled();
		// Don't mark dismissed since we didn't show — leaves the door
		// open if they later switch chat to a heavy model.
		expect(kv.__store.has("oati.toast.fimSuggestionShown")).toBe(false);
	});
});
