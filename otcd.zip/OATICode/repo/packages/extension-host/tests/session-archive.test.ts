import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	appendToSessionArchive,
	readSessionArchive,
	resolveArchivePath,
} from "../src/session-archive";

describe("resolveArchivePath", () => {
	it("places the archive under <root>/.oati/sessions/<id>/archive.md", () => {
		const p = resolveArchivePath("/work", "sess-abc");
		expect(p).toBe(path.join("/work", ".oati", "sessions", "sess-abc", "archive.md"));
	});

	it("sanitizes sessionId — strips path separators that would escape the archive dir", () => {
		const p = resolveArchivePath("/work", "../../etc/passwd");
		expect(p).toContain(path.join(".oati", "sessions"));
		// The sanitized name should NOT contain any path-traversal sequences.
		const sanitizedSegment = path.basename(path.dirname(p ?? ""));
		expect(sanitizedSegment).not.toContain("..");
		expect(sanitizedSegment).not.toContain("/");
		expect(sanitizedSegment).not.toContain("\\");
	});

	it("returns undefined when sessionId is empty or sanitizes to empty (pure dots/slashes)", () => {
		expect(resolveArchivePath("/work", "")).toBeUndefined();
		// "." and ".." now sanitize to empty (all dots stripped) → undefined.
		expect(resolveArchivePath("/work", ".")).toBeUndefined();
		expect(resolveArchivePath("/work", "..")).toBeUndefined();
		expect(resolveArchivePath("/work", "///")).toBeUndefined();
	});

	it("returns undefined when workspace root is empty", () => {
		expect(resolveArchivePath("", "session")).toBeUndefined();
	});
});

describe("appendToSessionArchive + readSessionArchive (integration)", () => {
	let tmpDir: string;
	beforeEach(() => {
		tmpDir = fs.mkdtempSync
			? fs.mkdtempSync(path.join(os.tmpdir(), "oati-archive-test-"))
			: path.join(os.tmpdir(), `oati-archive-test-${Date.now()}`);
	});
	afterEach(async () => {
		await fs.rm(tmpDir, { recursive: true, force: true });
	});

	it("creates the archive directory + file on first append", async () => {
		await appendToSessionArchive(tmpDir, "sess-1", "first block\n");
		const back = await readSessionArchive(tmpDir, "sess-1");
		expect(back).toBe("first block\n");
	});

	it("appends to an existing archive (does not overwrite)", async () => {
		await appendToSessionArchive(tmpDir, "sess-1", "first\n");
		await appendToSessionArchive(tmpDir, "sess-1", "second\n");
		const back = await readSessionArchive(tmpDir, "sess-1");
		expect(back).toBe("first\nsecond\n");
	});

	it("isolates archives per sessionId", async () => {
		await appendToSessionArchive(tmpDir, "sess-1", "for one\n");
		await appendToSessionArchive(tmpDir, "sess-2", "for two\n");
		expect(await readSessionArchive(tmpDir, "sess-1")).toBe("for one\n");
		expect(await readSessionArchive(tmpDir, "sess-2")).toBe("for two\n");
	});

	it("returns undefined when no archive has been written for the session", async () => {
		const back = await readSessionArchive(tmpDir, "ghost-session");
		expect(back).toBeUndefined();
	});
});
