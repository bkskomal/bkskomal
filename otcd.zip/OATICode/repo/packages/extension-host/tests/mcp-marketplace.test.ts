// R4-D: tests for the MCP marketplace orchestration layer.

import type { ToolRegistry } from "@oati/agent-core";
import { describe, expect, it } from "vitest";
import { McpManager } from "../src/mcp-manager";
import { MarketplaceManager } from "../src/mcp-marketplace";
import { MCP_REGISTRY } from "../src/mcp-registry";
import { SettingsStore } from "../src/settings-store";
import { InMemoryKv, InMemorySecrets } from "../src/storage";

function makeMcpManager(): { mgr: McpManager; calls: { servers: readonly unknown[] }[] } {
	const calls: { servers: readonly unknown[] }[] = [];
	// We can't easily spin up McpClient (needs subprocess), so create a fake
	// that records syncWith invocations and never starts a real process.
	const fakeTools = { register: () => {}, unregister: () => {} } as unknown as ToolRegistry;
	const fakeChannel = { appendLine: () => {} } as unknown as Parameters<typeof McpManager>[1];
	const mgr = new McpManager(fakeTools, fakeChannel);
	// Patch syncWith to record (and never actually spawn).
	(mgr as unknown as { syncWith: (s: readonly unknown[]) => Promise<void> }).syncWith = async (
		servers,
	) => {
		calls.push({ servers });
	};
	return { mgr, calls };
}

function makeStore() {
	return new SettingsStore(new InMemoryKv(), new InMemorySecrets());
}

describe("MarketplaceManager", () => {
	it("lists every registry entry with installed=false initially", () => {
		const store = makeStore();
		const { mgr } = makeMcpManager();
		const mp = new MarketplaceManager(store, mgr);
		const items = mp.list();
		expect(items).toHaveLength(MCP_REGISTRY.length);
		expect(items.every((i) => !i.installed)).toBe(true);
		expect(items.every((i) => !i.enabled)).toBe(true);
	});

	it("install appends a disabled McpServerConfig and syncs", async () => {
		const store = makeStore();
		const { mgr, calls } = makeMcpManager();
		const mp = new MarketplaceManager(store, mgr);

		await mp.install("filesystem");
		const items = mp.list();
		const fs = items.find((i) => i.entry.id === "filesystem");
		expect(fs?.installed).toBe(true);
		expect(fs?.enabled).toBe(false);
		expect(calls.length).toBeGreaterThan(0);
		// Stored row should mirror the registry install recipe.
		const stored = store.config.mcpServers?.find((s) => s.id === "filesystem");
		expect(stored?.enabled).toBe(false);
		expect(stored?.command).toBe("npx");
	});

	it("install is idempotent — second call doesn't duplicate", async () => {
		const store = makeStore();
		const { mgr } = makeMcpManager();
		const mp = new MarketplaceManager(store, mgr);

		await mp.install("git");
		await mp.install("git");
		const rows = store.config.mcpServers ?? [];
		expect(rows.filter((r) => r.id === "git")).toHaveLength(1);
	});

	it("setEnabled flips the flag and syncs the McpManager", async () => {
		const store = makeStore();
		const { mgr, calls } = makeMcpManager();
		const mp = new MarketplaceManager(store, mgr);

		await mp.install("memory");
		calls.length = 0;
		await mp.setEnabled("memory", true);

		const row = store.config.mcpServers?.find((s) => s.id === "memory");
		expect(row?.enabled).toBe(true);
		expect(calls.length).toBe(1);
		const enabledIds = (calls[0].servers as { id: string; enabled: boolean }[])
			.filter((s) => s.enabled)
			.map((s) => s.id);
		expect(enabledIds).toContain("memory");
	});

	it("setEnabled throws for entries that aren't installed yet", async () => {
		const store = makeStore();
		const { mgr } = makeMcpManager();
		const mp = new MarketplaceManager(store, mgr);
		await expect(mp.setEnabled("time", true)).rejects.toThrow(/not installed/);
	});

	it("uninstall removes the row and triggers a sync", async () => {
		const store = makeStore();
		const { mgr, calls } = makeMcpManager();
		const mp = new MarketplaceManager(store, mgr);

		await mp.install("sqlite");
		await mp.setEnabled("sqlite", true);
		calls.length = 0;

		await mp.uninstall("sqlite");
		const rows = store.config.mcpServers ?? [];
		expect(rows.find((r) => r.id === "sqlite")).toBeUndefined();
		expect(calls.length).toBe(1);
	});

	it("install throws for unknown registry ids", async () => {
		const store = makeStore();
		const { mgr } = makeMcpManager();
		const mp = new MarketplaceManager(store, mgr);
		await expect(mp.install("not-a-real-thing")).rejects.toThrow(/Unknown marketplace entry/);
	});

	it("registry contains the ten promised entries", () => {
		const ids = MCP_REGISTRY.map((e) => e.id);
		expect(ids).toContain("filesystem");
		expect(ids).toContain("git");
		expect(ids).toContain("sqlite");
		expect(ids).toContain("brave-search");
		expect(ids).toContain("puppeteer");
		expect(ids).toContain("github");
		expect(ids).toContain("slack");
		expect(ids).toContain("postgres");
		expect(ids).toContain("memory");
		expect(ids).toContain("time");
	});
});
