import { describe, expect, it } from "vitest";
import { __test } from "../src/gh-workflow";

const { slugifyTitle, buildBranchName, buildAgentInstruction } = __test;

describe("slugifyTitle", () => {
	it("lowercases and replaces non-alnum with dashes", () => {
		expect(slugifyTitle("Fix: crash on Startup!")).toBe("fix-crash-on-startup");
	});

	it("trims leading and trailing dashes", () => {
		expect(slugifyTitle("---hello world---")).toBe("hello-world");
	});

	it("caps length", () => {
		const long = "a".repeat(80);
		expect(slugifyTitle(long, 10)).toBe("aaaaaaaaaa");
	});

	it("falls back to 'issue' for empty results", () => {
		expect(slugifyTitle("!!!---!!!")).toBe("issue");
		expect(slugifyTitle("")).toBe("issue");
	});
});

describe("buildBranchName", () => {
	it("uses feature/<num>-<slug> shape", () => {
		expect(buildBranchName(42, "Add login")).toBe("feature/42-add-login");
	});

	it("respects total length cap", () => {
		const branch = buildBranchName(123, "A".repeat(200), 30);
		expect(branch.length).toBeLessThanOrEqual(30);
		expect(branch.startsWith("feature/123-")).toBe(true);
	});

	it("keeps a minimum slug length even when total cap is tight", () => {
		const branch = buildBranchName(1, "hello world", 12);
		// floor is 8 chars for the slug, regardless of cap.
		expect(branch.length).toBeGreaterThanOrEqual("feature/1-".length + 1);
	});
});

describe("buildAgentInstruction", () => {
	it("includes title, body, labels, and a scaffold task", () => {
		const text = buildAgentInstruction(
			{
				ok: true,
				title: "Fix bug",
				body: "Repro steps…",
				labels: ["bug", "p1"],
				assignees: ["alice"],
			},
			"https://github.com/x/y/issues/9",
		);
		expect(text).toContain("Fix bug");
		expect(text).toContain("Repro steps");
		expect(text).toContain("bug, p1");
		expect(text).toContain("alice");
		expect(text).toContain("https://github.com/x/y/issues/9");
		expect(text).toMatch(/scaffold/i);
	});

	it("handles missing optional fields", () => {
		const text = buildAgentInstruction({ ok: true, title: "x" }, "u");
		expect(text).toContain("x");
		expect(text).not.toContain("Labels:");
		expect(text).not.toContain("Assignees:");
	});
});
