import type { ConversationMessage } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { formatSanitizeNote, sanitizeHistory } from "../src/history-sanitizer";

describe("sanitizeHistory", () => {
	it("returns empty input unchanged", () => {
		const r = sanitizeHistory([]);
		expect(r.repaired).toBe(0);
		expect(r.history).toEqual([]);
	});

	it("leaves clean history alone (idempotent)", () => {
		const history: ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "hi" }] },
			{
				role: "assistant",
				parts: [
					{
						kind: "tool_call",
						id: "abc",
						name: "write_file",
						args: { path: "src/foo.ts", content: "ok" },
					},
				],
			},
			{ role: "tool", parts: [{ kind: "tool_result", id: "abc", output: "wrote", isError: false }] },
		];
		const r = sanitizeHistory(history);
		expect(r.repaired).toBe(0);
		expect(r.history).toEqual(history);
	});

	it("detects the user'''s actual failure case (path absorbs content)", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{
						kind: "tool_call",
						id: "call_001",
						name: "write_file",
						args: {
							path:
								'execute_security_tests.py","content":"#!/usr/bin/env python3 """ Comprehensive Security Test Suite ... lots of code ... """ class SecurityTestSuite: def __init__(self): pass',
						},
					},
				],
			},
		];
		const r = sanitizeHistory(history);
		expect(r.repaired).toBe(1);
		const repaired = r.history[0].parts[0];
		expect(repaired.kind).toBe("tool_call");
		if (repaired.kind === "tool_call") {
			expect((repaired.args as Record<string, unknown>)._oatiSanitized).toBe(true);
		}
	});

	it("detects unusually-long path field as corruption", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{
						kind: "tool_call",
						id: "x",
						name: "write_file",
						args: { path: "a".repeat(300), content: "hi" },
					},
				],
			},
		];
		const r = sanitizeHistory(history);
		expect(r.repaired).toBe(1);
	});

	it("detects contamination signature inside command field", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{
						kind: "tool_call",
						id: "y",
						name: "exec",
						args: { command: 'echo hi","content":"more stuff' },
					},
				],
			},
		];
		const r = sanitizeHistory(history);
		expect(r.repaired).toBe(1);
	});

	it("sanitizes corrupt tool_result outputs too", () => {
		const longCorrupt = `${"ok".repeat(3000)}","content":"junk`;
		const history: ConversationMessage[] = [
			{
				role: "tool",
				parts: [
					{
						kind: "tool_result",
						id: "r1",
						output: longCorrupt,
						isError: false,
					},
				],
			},
		];
		const r = sanitizeHistory(history);
		expect(r.repaired).toBe(1);
		const repaired = r.history[0].parts[0];
		if (repaired.kind === "tool_result") {
			expect(repaired.isError).toBe(true);
			expect((repaired.output as Record<string, unknown>)._oatiSanitized).toBe(true);
		}
	});

	it("preserves message order and role across sanitation", () => {
		const history: ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "first" }] },
			{
				role: "assistant",
				parts: [
					{
						kind: "tool_call",
						id: "bad",
						name: "write_file",
						args: { path: 'foo","content":"bar' },
					},
				],
			},
			{ role: "user", parts: [{ kind: "text", text: "third" }] },
		];
		const r = sanitizeHistory(history);
		expect(r.history).toHaveLength(3);
		expect(r.history[0].role).toBe("user");
		expect(r.history[1].role).toBe("assistant");
		expect(r.history[2].role).toBe("user");
	});

	it("does NOT flag content/body/source fields that legitimately contain JSON-shaped substrings", () => {
		// 2026-05-29 live-bug: scaffolding a Next.js project meant writing
		// tailwind.config.js whose source contains `content: ["./app/**/*"]`
		// — the literal substring `"content":` inside the value tripped
		// CONTAMINATION_RE and the sanitizer replaced the entire args with
		// the `_oatiSanitized` placeholder, breaking subsequent writes. The
		// fix: content/body/text fields can carry arbitrary code and should
		// not get the boundary-pattern check (path/command length guards
		// still catch the genuinely-wrapped shape since those fields stay
		// short).
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{
						kind: "tool_call",
						id: "tailwind",
						name: "write_file",
						args: {
							path: "tailwind.config.js",
							content:
								"module.exports = {\n  content: ['./app/**/*.{ts,tsx}'],\n  theme: { extend: {} },\n  plugins: [],\n};",
						},
					},
				],
			},
			{
				role: "assistant",
				parts: [
					{
						kind: "tool_call",
						id: "readme",
						name: "write_file",
						args: {
							path: "README.md",
							body: 'Example JSON: {"content": "hello", "command": "ls"} — see docs',
						},
					},
				],
			},
		];
		const r = sanitizeHistory(history);
		expect(r.repaired).toBe(0);
	});

	it("counts multiple repairs across a session", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "a", name: "write_file", args: { path: 'p","content":"x' } }],
			},
			{
				role: "assistant",
				parts: [
					{ kind: "tool_call", id: "b", name: "exec", args: { command: 'c","content":"y'.repeat(50) } },
				],
			},
		];
		const r = sanitizeHistory(history);
		expect(r.repaired).toBe(2);
	});

	it("formatSanitizeNote returns undefined for clean sessions", () => {
		const r = sanitizeHistory([]);
		expect(formatSanitizeNote(r)).toBeUndefined();
	});

	it("formatSanitizeNote returns a human-readable summary when repairs happened", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{ kind: "tool_call", id: "abc12345", name: "write_file", args: { path: 'x","content":"y' } },
				],
			},
		];
		const note = formatSanitizeNote(sanitizeHistory(history));
		expect(note).toBeDefined();
		expect(note).toContain("[History recovery]");
		expect(note).toContain("1 corrupt");
	});
});
