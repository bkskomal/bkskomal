import { describe, expect, it } from "vitest";
import { BUILTIN_TEMPLATES } from "../src/templates-builtin";

describe("BUILTIN_TEMPLATES (R4-C)", () => {
	it("ships exactly the five named templates", () => {
		expect(BUILTIN_TEMPLATES.map((t) => t.name)).toEqual([
			"react-ts",
			"node-cli",
			"fastapi",
			"express-api",
			"rust-cli",
		]);
	});

	it("every template has a non-empty description", () => {
		for (const t of BUILTIN_TEMPLATES) {
			expect(t.description.length).toBeGreaterThan(0);
		}
	});

	it("every template ships at least one file with non-empty content", () => {
		for (const t of BUILTIN_TEMPLATES) {
			expect(t.files.length).toBeGreaterThan(0);
			for (const f of t.files) {
				expect(typeof f.path).toBe("string");
				expect(f.path.length).toBeGreaterThan(0);
				expect(typeof f.content).toBe("string");
			}
		}
	});

	it("react-ts ships a package.json with React deps", () => {
		const tpl = BUILTIN_TEMPLATES.find((t) => t.name === "react-ts");
		const pkg = tpl?.files.find((f) => f.path === "package.json");
		expect(pkg?.content).toMatch(/"react"/);
	});

	it("fastapi ships an app/main.py with a FastAPI app", () => {
		const tpl = BUILTIN_TEMPLATES.find((t) => t.name === "fastapi");
		const main = tpl?.files.find((f) => f.path === "app/main.py");
		expect(main?.content).toMatch(/FastAPI/);
	});

	it("rust-cli ships a Cargo.toml with clap", () => {
		const tpl = BUILTIN_TEMPLATES.find((t) => t.name === "rust-cli");
		const cargo = tpl?.files.find((f) => f.path === "Cargo.toml");
		expect(cargo?.content).toMatch(/clap/);
	});

	it("every file path is relative (no leading slash, no .. segments)", () => {
		for (const t of BUILTIN_TEMPLATES) {
			for (const f of t.files) {
				expect(f.path.startsWith("/")).toBe(false);
				expect(f.path.includes("..")).toBe(false);
			}
		}
	});
});
