import { describe, expect, it } from "vitest";
import { InMemoryKv, InMemorySecrets } from "../src/storage";

describe("InMemoryKv", () => {
	it("get returns undefined for missing keys", () => {
		const kv = new InMemoryKv();
		expect(kv.get("x")).toBeUndefined();
	});

	it("update stores and get retrieves typed values", async () => {
		const kv = new InMemoryKv();
		await kv.update("key", { a: 1 });
		expect(kv.get<{ a: number }>("key")).toEqual({ a: 1 });
	});

	it("update with undefined deletes the key", async () => {
		const kv = new InMemoryKv();
		await kv.update("key", "value");
		await kv.update("key", undefined);
		expect(kv.get("key")).toBeUndefined();
	});
});

describe("InMemorySecrets", () => {
	it("get returns undefined for missing keys", async () => {
		const secrets = new InMemorySecrets();
		expect(await secrets.get("missing")).toBeUndefined();
	});

	it("store/get/delete round-trip", async () => {
		const secrets = new InMemorySecrets();
		await secrets.store("k", "v");
		expect(await secrets.get("k")).toBe("v");
		await secrets.delete("k");
		expect(await secrets.get("k")).toBeUndefined();
	});

	it("overwrite replaces existing values", async () => {
		const secrets = new InMemorySecrets();
		await secrets.store("k", "v1");
		await secrets.store("k", "v2");
		expect(await secrets.get("k")).toBe("v2");
	});
});
