import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	EMPTY_POLICY,
	filterModes,
	isAllowed,
	isModeAllowed,
	isModelAllowed,
	isProviderAllowed,
	isToolAllowed,
	loadPolicy,
} from "../src/policy";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "oati-policy-"));
}

async function writePolicy(dir: string, body: string): Promise<void> {
	await fs.mkdir(path.join(dir, ".oati"), { recursive: true });
	await fs.writeFile(path.join(dir, ".oati", "policy.yaml"), body, "utf-8");
}

describe("loadPolicy", () => {
	let dir: string;
	beforeEach(async () => {
		dir = await mkTempDir();
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("returns the empty policy when no file exists", async () => {
		const r = await loadPolicy(dir);
		expect(r.source).toBe("empty");
		expect(r.policy).toEqual(EMPTY_POLICY);
		expect(r.warning).toBeUndefined();
	});

	it("returns the empty policy when workspaceRoot is empty", async () => {
		const r = await loadPolicy("");
		expect(r.source).toBe("empty");
		expect(r.policy).toEqual(EMPTY_POLICY);
	});

	it("parses a fully-populated policy", async () => {
		await writePolicy(
			dir,
			[
				"providers:",
				"  allow: [openrouter, anthropic]",
				"models:",
				"  deny: ['*-preview', 'claude-opus-4-7-test']",
				"tools:",
				"  deny: [exec, spawn_parallel_agents]",
				"modes:",
				"  deny: [full-auto]",
				"budget:",
				"  perSessionHardCapUsd: 10",
				"  perDayHardCapUsd: 100",
				"",
			].join("\n"),
		);
		const r = await loadPolicy(dir);
		expect(r.source).toBe("file");
		expect(r.policy.providers.allow).toEqual(["openrouter", "anthropic"]);
		expect(r.policy.models.deny).toEqual(["*-preview", "claude-opus-4-7-test"]);
		expect(r.policy.tools.deny).toEqual(["exec", "spawn_parallel_agents"]);
		expect(r.policy.modes.deny).toEqual(["full-auto"]);
		expect(r.policy.budget?.perSessionHardCapUsd).toBe(10);
		expect(r.policy.budget?.perDayHardCapUsd).toBe(100);
	});

	it("falls back to empty policy on malformed YAML (with warning)", async () => {
		await writePolicy(dir, "providers:\n  allow: [unterminated\n");
		const r = await loadPolicy(dir);
		expect(r.source).toBe("empty");
		expect(r.policy).toEqual(EMPTY_POLICY);
		expect(r.warning).toBeDefined();
		expect(r.warning).toContain("policy.yaml");
	});

	it("treats an empty document as the empty policy", async () => {
		await writePolicy(dir, "");
		const r = await loadPolicy(dir);
		expect(r.policy).toEqual(EMPTY_POLICY);
	});

	it("ignores non-string entries in allow/deny", async () => {
		await writePolicy(
			dir,
			["providers:", "  allow:", "    - openrouter", "    - 42", "    - null", ""].join("\n"),
		);
		const r = await loadPolicy(dir);
		expect(r.policy.providers.allow).toEqual(["openrouter"]);
	});
});

describe("isAllowed and helpers", () => {
	it("denies values in the deny list", () => {
		expect(isAllowed("exec", { deny: ["exec"] })).toBe(false);
		expect(isToolAllowed({ ...EMPTY_POLICY, tools: { deny: ["exec"] } }, "exec")).toBe(false);
	});

	it("allows values not on any list", () => {
		expect(isAllowed("read_file", {})).toBe(true);
		expect(isAllowed("read_file", { deny: ["exec"] })).toBe(true);
	});

	it("with an allow list, denies everything else", () => {
		expect(
			isProviderAllowed({ ...EMPTY_POLICY, providers: { allow: ["anthropic"] } }, "anthropic"),
		).toBe(true);
		expect(
			isProviderAllowed({ ...EMPTY_POLICY, providers: { allow: ["anthropic"] } }, "openai"),
		).toBe(false);
	});

	it("supports * glob patterns", () => {
		expect(
			isModelAllowed({ ...EMPTY_POLICY, models: { deny: ["*-preview"] } }, "gpt-5-preview"),
		).toBe(false);
		expect(isModelAllowed({ ...EMPTY_POLICY, models: { deny: ["*-preview"] } }, "gpt-5")).toBe(true);
	});

	it("is case-insensitive", () => {
		expect(isModelAllowed({ ...EMPTY_POLICY, models: { deny: ["GPT-*"] } }, "gpt-5")).toBe(false);
	});

	it("deny wins over allow on the same value", () => {
		const p = { ...EMPTY_POLICY, tools: { allow: ["exec"], deny: ["exec"] } };
		expect(isToolAllowed(p, "exec")).toBe(false);
	});

	it("filterModes drops denied modes", () => {
		const policy = { ...EMPTY_POLICY, modes: { deny: ["full-auto"] } };
		const modes = [{ id: "code" }, { id: "full-auto" }, { id: "plan" }];
		const filtered = filterModes(policy, modes);
		expect(filtered.map((m) => m.id)).toEqual(["code", "plan"]);
		expect(isModeAllowed(policy, "full-auto")).toBe(false);
	});
});
