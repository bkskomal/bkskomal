import type {
	ConversationMessage,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
	ToolSpec,
} from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import {
	COMPUTER_USE_TOOL_NAMES,
	MAX_CONSECUTIVE_FAILURES,
	NotVisionCapableError,
	isVisionCapableModel,
	runComputerUseTurn,
} from "../src/computer-use";

/** Minimal HostContext stub — computer-use tools we register here don't read the host. */
function stubHost() {
	return {
		async readFile() {
			throw new Error("not used");
		},
		async writeFile() {},
		async fileExists() {
			return false;
		},
		async exec() {
			return { stdout: "", stderr: "", exitCode: 0 };
		},
		workspaceRoot() {
			return "/test";
		},
		async requestApproval() {
			return true;
		},
		async showDiff() {},
		log: () => {},
	};
}

/** Build a `ProviderSpec` whose stream() emits a scripted sequence per turn. */
function scriptedProvider(turns: ProviderStreamEvent[][]): ProviderSpec & {
	calls: ProviderRequest[];
} {
	const calls: ProviderRequest[] = [];
	let i = 0;
	return {
		id: "test",
		displayName: "Test",
		calls,
		async *stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			calls.push(req);
			const events = turns[i] ?? [];
			i++;
			for (const e of events) yield e;
		},
	};
}

/** Build the five computer-use tools as cheap stubs whose handlers we can spy on. */
function buildStubTools(
	opts: {
		screenshotHandler?: () => unknown;
		clickHandler?: () => unknown;
	} = {},
): ToolSpec[] {
	const make = (name: string, handler: () => unknown): ToolSpec => ({
		name,
		description: `stub ${name}`,
		approval: "prompt",
		schema: { type: "object", properties: {}, required: [], additionalProperties: false },
		async handler() {
			return handler();
		},
	});
	const defaultShot = () => ({
		dataUrl:
			"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
	});
	return [
		make("screenshot", opts.screenshotHandler ?? defaultShot),
		make("mouse_click", opts.clickHandler ?? (() => ({ ok: true }))),
		make("mouse_move", () => ({ ok: true })),
		make("type_text", () => ({ ok: true })),
		make("key_press", () => ({ ok: true })),
	];
}

describe("isVisionCapableModel", () => {
	it("accepts known vision-capable models", () => {
		expect(isVisionCapableModel("claude-3-5-sonnet-20241022")).toBe(true);
		expect(isVisionCapableModel("claude-3.5-sonnet-20241022")).toBe(true);
		expect(isVisionCapableModel("claude-sonnet-4-5")).toBe(true);
		expect(isVisionCapableModel("gpt-4o")).toBe(true);
		expect(isVisionCapableModel("gpt-4o-mini")).toBe(true);
		expect(isVisionCapableModel("gpt-4-vision-preview")).toBe(true);
		expect(isVisionCapableModel("gemini-1.5-pro")).toBe(true);
	});

	it("rejects text-only models", () => {
		expect(isVisionCapableModel("")).toBe(false);
		expect(isVisionCapableModel("text-davinci-003")).toBe(false);
		expect(isVisionCapableModel("gpt-3.5-turbo")).toBe(false);
		expect(isVisionCapableModel("llama3.1:8b")).toBe(false);
	});

	it("exposes the expected tool name list", () => {
		expect(COMPUTER_USE_TOOL_NAMES).toEqual([
			"screenshot",
			"mouse_click",
			"mouse_move",
			"type_text",
			"key_press",
		]);
	});
});

describe("runComputerUseTurn — vision gating", () => {
	it("throws NotVisionCapableError when the model is text-only", async () => {
		const provider = scriptedProvider([]);
		await expect(
			runComputerUseTurn({
				task: "click the button",
				modelId: "gpt-3.5-turbo",
				provider,
				// biome-ignore lint/suspicious/noExplicitAny: stub
				host: stubHost() as any,
				tools: buildStubTools(),
			}),
		).rejects.toBeInstanceOf(NotVisionCapableError);
		// Provider must never be called when the gate trips.
		expect(provider.calls.length).toBe(0);
	});

	it("rejects when a required computer-use tool is missing", async () => {
		const provider = scriptedProvider([]);
		const tools = buildStubTools().filter((t) => t.name !== "key_press");
		await expect(
			runComputerUseTurn({
				task: "click the button",
				modelId: "gpt-4o",
				provider,
				// biome-ignore lint/suspicious/noExplicitAny: stub
				host: stubHost() as any,
				tools,
			}),
		).rejects.toThrow(/key_press/);
	});
});

describe("runComputerUseTurn — retry-limit logic", () => {
	it("stops after MAX_CONSECUTIVE_FAILURES screenshot failures up-front", async () => {
		const tools = buildStubTools({
			screenshotHandler: () => {
				throw new Error("desktop unavailable");
			},
		});
		const provider = scriptedProvider([]);
		const events: string[] = [];
		const result = await runComputerUseTurn({
			task: "do a thing",
			modelId: "gpt-4o",
			provider,
			// biome-ignore lint/suspicious/noExplicitAny: stub
			host: stubHost() as any,
			tools,
			onEvent: (e) => events.push(e.type),
		});
		expect(result.stopReason).toBe("failures");
		expect(result.actions).toBe(0);
		expect(events).toContain("failure");
		expect(events).toContain("done");
		// Provider is never called when we couldn't even get the first screenshot.
		expect(provider.calls.length).toBe(0);
	});

	it("stops the run after 3 consecutive tool-call failures", async () => {
		// Tool spec where mouse_click throws every time.
		const tools = buildStubTools();
		const clickTool = tools.find((t) => t.name === "mouse_click");
		if (!clickTool) throw new Error("test setup: missing click tool");
		// biome-ignore lint/suspicious/noExplicitAny: monkey-patch a const struct for the test
		(clickTool as any).handler = vi.fn(async () => {
			throw new Error("simulated click failure");
		});
		// Every turn the model emits a single mouse_click call.
		const clickEvent: ProviderStreamEvent = {
			type: "tool_call",
			id: "c1",
			name: "mouse_click",
			args: { x: 1, y: 2 },
		};
		const provider = scriptedProvider([
			[{ ...clickEvent, id: "c1" }],
			[{ ...clickEvent, id: "c2" }],
			[{ ...clickEvent, id: "c3" }],
			// If the loop ever ran a fourth turn, this would let it run forever —
			// but the retry limit MUST stop it before we get here.
			[{ ...clickEvent, id: "c4" }],
		]);
		const result = await runComputerUseTurn({
			task: "click",
			modelId: "claude-3-5-sonnet-20241022",
			provider,
			// biome-ignore lint/suspicious/noExplicitAny: stub
			host: stubHost() as any,
			tools,
		});
		expect(result.stopReason).toBe("failures");
		expect(result.actions).toBe(MAX_CONSECUTIVE_FAILURES);
		expect(result.failures).toBe(MAX_CONSECUTIVE_FAILURES);
		// Should not have advanced to the 4th scripted turn.
		expect(provider.calls.length).toBeLessThanOrEqual(MAX_CONSECUTIVE_FAILURES);
	});

	it("ends cleanly when the model produces text-only and no tool calls", async () => {
		const tools = buildStubTools();
		const provider = scriptedProvider([
			[
				{ type: "text_delta", text: "I clicked the button — task done." },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const events: string[] = [];
		const result = await runComputerUseTurn({
			task: "click",
			modelId: "gpt-4o",
			provider,
			// biome-ignore lint/suspicious/noExplicitAny: stub
			host: stubHost() as any,
			tools,
			onEvent: (e) => events.push(e.type),
		});
		expect(result.stopReason).toBe("end");
		expect(result.actions).toBe(0);
		expect(events).toContain("screenshot");
		expect(events).toContain("done");
	});

	it("resets the consecutive-failure counter after a successful action", async () => {
		const tools = buildStubTools();
		const clickTool = tools.find((t) => t.name === "mouse_click");
		if (!clickTool) throw new Error("test setup");
		let clickN = 0;
		// biome-ignore lint/suspicious/noExplicitAny: monkey-patch
		(clickTool as any).handler = vi.fn(async () => {
			clickN++;
			// First two calls fail, third succeeds, fourth fails.
			if (clickN === 1 || clickN === 2 || clickN === 4) {
				throw new Error("flake");
			}
			return { ok: true };
		});
		const provider = scriptedProvider([
			[{ type: "tool_call", id: "1", name: "mouse_click", args: { x: 1, y: 1 } }],
			[{ type: "tool_call", id: "2", name: "mouse_click", args: { x: 2, y: 2 } }],
			[{ type: "tool_call", id: "3", name: "mouse_click", args: { x: 3, y: 3 } }],
			[{ type: "tool_call", id: "4", name: "mouse_click", args: { x: 4, y: 4 } }],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const result = await runComputerUseTurn({
			task: "click",
			modelId: "gpt-4o",
			provider,
			// biome-ignore lint/suspicious/noExplicitAny: stub
			host: stubHost() as any,
			tools,
		});
		// 2 fails, then a pass (counter resets to 0), then 1 fail, then end.
		// Should NOT trip the 3-consecutive-failure circuit-breaker.
		expect(result.stopReason).toBe("end");
		expect(clickN).toBe(4);
	});
});
