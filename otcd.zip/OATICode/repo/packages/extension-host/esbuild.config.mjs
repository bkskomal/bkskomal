import { writeFileSync } from "node:fs";
import { build, context } from "esbuild";

const isWatch = process.argv.includes("--watch");

const config = {
	entryPoints: ["src/extension.ts"],
	bundle: true,
	outfile: "dist/extension.js",
	platform: "node",
	target: "node20",
	format: "cjs",
	external: [
		"vscode",
		// Optional / dynamically-imported deps. Marking them external keeps the
		// host bundle small; the require() calls fail gracefully at runtime when
		// the package isn't installed (browser tools / treesitter chunker /
		// computer-use vision tools).
		"puppeteer-core",
		"web-tree-sitter",
		// R8-D: computer-use optional deps.
		"screenshot-desktop",
		"@nut-tree-fork/nut-js",
		"pngjs",
	],
	sourcemap: true,
	minify: false,
	metafile: true,
	logLevel: "info",
};

if (isWatch) {
	const ctx = await context(config);
	await ctx.watch();
	console.log("[esbuild] watching...");
} else {
	const result = await build(config);
	if (result.metafile) {
		writeFileSync("dist/meta.json", JSON.stringify(result.metafile));
	}
}
