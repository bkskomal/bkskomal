---
name: install-dependencies
description: Auto-detect a project's package manager (npm/pnpm/yarn/pip/cargo/go/dotnet/maven) and install its dependencies via bash
tools: [exec, read_file, list_dir, get_workspace_context]
triggers:
  - install dependencies
  - install packages
  - "npm install"
  - "pnpm install"
  - "yarn install"
  - "pip install"
  - "cargo build"
  - "go mod"
  - missing module
  - "Cannot find module"
  - "ModuleNotFoundError"
  - setup project
  - bootstrap project
  - first-time setup
---

# Skill: Install project dependencies

When the user asks "install the dependencies" — or the agent decides a
missing module is blocking the next step — run this playbook **end-to-end
through `exec` with `shell: "bash"`** so quoting and `&&` chains behave
the same on every OS.

## 1. Detect the package manager (don't assume)

Read the workspace root once via `list_dir` / `read_file` and pick the
first lockfile/manifest that exists. Lockfiles win over generic manifests
because they record the manager the project was actually set up with.

| File present                  | Manager       | Install command                      |
| ----------------------------- | ------------- | ------------------------------------ |
| `pnpm-lock.yaml`              | pnpm          | `pnpm install --frozen-lockfile`     |
| `yarn.lock`                   | Yarn 1 or 3+  | `yarn install --immutable` (v3+) or `yarn install --frozen-lockfile` (v1) |
| `package-lock.json`           | npm           | `npm ci`                             |
| `package.json` (no lockfile)  | npm (assume)  | `npm install` then commit the lockfile |
| `bun.lockb`                   | Bun           | `bun install --frozen-lockfile`      |
| `Pipfile.lock`                | pipenv        | `pipenv sync`                        |
| `poetry.lock`                 | Poetry        | `poetry install --no-root`           |
| `uv.lock`                     | uv            | `uv sync --frozen`                   |
| `requirements.txt`            | pip           | `pip install -r requirements.txt`    |
| `pyproject.toml` only         | pip + PEP 517 | `pip install -e .`                   |
| `Cargo.lock` + `Cargo.toml`   | cargo         | `cargo fetch && cargo build`         |
| `go.mod`                      | Go modules    | `go mod download && go build ./...`  |
| `*.csproj` / `*.sln`          | .NET          | `dotnet restore`                     |
| `pom.xml`                     | Maven         | `mvn -B dependency:resolve`          |
| `build.gradle` / `*.gradle.kts` | Gradle      | `./gradlew dependencies`             |
| `Gemfile.lock`                | Bundler       | `bundle install --deployment`        |
| `composer.json`               | Composer      | `composer install --no-interaction`  |

A monorepo may have several. Walk each workspace package or use the
root manager's install (e.g. `pnpm -r install` from the root).

## 2. Pick the right install verb

- **Use the lockfile-respecting verb** (`ci`, `--frozen-lockfile`, `sync`)
  by default. It's faster and reproducible.
- Switch to the loose verb (`install`, `add`) only when:
  - You are intentionally adding or upgrading a dependency.
  - The user explicitly said "update lockfile".

Never run `npm update`, `pnpm update --latest`, `yarn upgrade-interactive`
without asking — those rewrite the lockfile in surprising ways.

## 3. Pre-flight checks

Before launching the install, run a quick probe through `exec` (one
command, bash, ~200ms each):

```bash
node --version 2>/dev/null
pnpm --version 2>/dev/null
yarn --version 2>/dev/null
python --version 2>/dev/null
cargo --version 2>/dev/null
go version 2>/dev/null
dotnet --version 2>/dev/null
```

If the required tool is missing, surface a friendly message to the user
with the canonical install path for their OS (Homebrew / winget / apt).
Do NOT auto-install global tools (Node, Python, Cargo) without explicit
permission — that's a system-level change, not a project-level one.

## 4. Run the install with progress streaming

Use `exec` with `shell: "bash"` so output streams live:

```json
{
  "command": "pnpm install --frozen-lockfile",
  "shell": "bash",
  "timeoutMs": 300000
}
```

Bump `timeoutMs` to 5 minutes for fresh installs — initial dependency
graphs can be slow.

## 5. Recovery patterns

| Failure                                              | Fix                                                                |
| ---------------------------------------------------- | ------------------------------------------------------------------ |
| `ERR_PNPM_PEER_DEP_ISSUES`                           | `pnpm install --strict-peer-dependencies=false` after explaining   |
| `npm ERR! ELOCK`                                     | Tell user to close other npm sessions; don't `rm -rf node_modules` |
| `EACCES` on a path                                   | Don't `sudo`; check `~/.npmrc` `prefix` or workspace ownership     |
| `python: command not found` (only `python3` exists)  | Use `python3 -m pip install …`                                     |
| `No matching distribution for X`                     | Check Python version; some wheels need 3.10+                       |
| `error[E0658]` Rust nightly required                 | Stop — ask user before installing nightly toolchains               |
| Lockfile drift (`--frozen-lockfile` refuses)         | Stop and report; don't silently regenerate the lockfile            |

## 6. Verify the install

After install finishes (exit code 0), confirm the entry point can resolve:

- Node: `node -e "require('the-pkg')"` or `pnpm exec tsc --noEmit`
- Python: `python -c "import the_pkg"`
- Rust: `cargo check`
- Go: `go vet ./...`

A green verify step is what lets you move on to the build/run step.

## 7. Don't…

- Install global tools (`npm i -g`, `pip install --user`, `cargo install`)
  without explicit permission.
- Delete `node_modules`, `__pycache__`, `target/`, `vendor/` to "reset"
  unless the user asked. The right fix is almost never a wipe.
- Run installs in parallel from sibling workspaces — let the manager
  handle workspace ordering (e.g. `pnpm -r install`).

Once dependencies land, hand off to the [[build-projects]] skill (or
[[run-and-debug]] if the next step is launching a server).
