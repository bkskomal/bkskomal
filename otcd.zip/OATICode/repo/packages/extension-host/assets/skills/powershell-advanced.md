---
name: powershell-advanced
description: Advanced PowerShell — parameter binding, classes, modules, robust error handling, parallelism, REST APIs, CIM/WMI, services, scheduled tasks
tools: [exec, write_file, read_file, list_dir]
triggers:
  - powershell script
  - "ps1 script"
  - powershell module
  - powershell class
  - powershell function
  - "[CmdletBinding"
  - "[ValidateSet"
  - splatting
  - "ForEach-Object -Parallel"
  - "Start-Job"
  - "Invoke-RestMethod"
  - "Get-CimInstance"
  - pester test
  - scheduled task
  - new-service
  - "$ErrorActionPreference"
  - "try { } catch"
  - PSCustomObject
  - import-module
---

# Skill: Advanced PowerShell

Reach for this when the task is bigger than a one-liner — a reusable
script, a module, a process orchestrator, an API client. Pairs with the
[[powershell-commands]] skill (basics + cross-shell migration table).

Always invoke through `exec` with `shell: "pwsh"`. PowerShell 7+ for
parallelism, classes, ternary, null-coalescing; fall back to
`shell: "powershell"` only when the script depends on Desktop-only
modules (some `ActiveDirectory` cmdlets, COM-heavy automation).

## 1. Script anatomy — the production skeleton

Every `.ps1` you author should start with this. It's verbose but each
line earns its keep:

```powershell
#Requires -Version 7.2
[CmdletBinding(SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ValidateScript({ Test-Path $_ -PathType Container })]
    [string]$Path,

    [ValidateSet('staging','prod')]
    [string]$Env = 'staging',

    [ValidateRange(1,100)]
    [int]$Parallel = 4,

    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$PSDefaultParameterValues['*:ErrorAction'] = 'Stop'
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8NoBOM'

# All Write-Verbose calls light up under `-Verbose`. Use them liberally
# — silent scripts are debugging nightmares.
Write-Verbose "Running with Path=$Path Env=$Env Parallel=$Parallel"
```

What each piece buys you:
- `#Requires -Version 7.2` — refuses to run on Windows PowerShell 5.1.
- `[CmdletBinding]` — `-Verbose`, `-Debug`, `-WhatIf`, `-Confirm` for free.
- `ValidateScript / ValidateSet / ValidateRange` — input fails at parse
  time, not at line 200.
- `$ErrorActionPreference = 'Stop'` + `Set-StrictMode` — non-terminating
  errors become terminating; uninitialised variables throw. Without
  these, a `Get-ChildItem` typo silently returns 0 results.
- `$PSDefaultParameterValues['*:ErrorAction'] = 'Stop'` — even cmdlets
  the caller explicitly typed without `-ErrorAction Stop` get the strict
  treatment.

## 2. Parameter binding patterns

```powershell
# Pipeline-friendly function — accepts piped objects.
function Compress-Logs {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [System.IO.FileInfo]$File,

        [string]$Destination = '.\out'
    )
    begin   { New-Item -ItemType Directory -Force $Destination | Out-Null }
    process { Compress-Archive -Path $File.FullName -DestinationPath "$Destination\$($File.BaseName).zip" }
    end     { Write-Verbose "Compressed $($File.Count) file(s) into $Destination" }
}

Get-ChildItem -Recurse *.log | Compress-Logs -Destination .\zipped
```

`begin / process / end` is what makes the function efficient over a long
pipeline — runs the directory create ONCE, not per file.

**Splatting** for readability when calling cmdlets with many params:

```powershell
$params = @{
    Uri         = 'https://api.example.com/v1/items'
    Method      = 'POST'
    Headers     = @{ Authorization = "Bearer $env:API_KEY" }
    ContentType = 'application/json'
    Body        = ($payload | ConvertTo-Json -Depth 10)
    TimeoutSec  = 30
}
$response = Invoke-RestMethod @params
```

Beats one giant unreadable line every time.

## 3. Error handling that actually works

```powershell
function Get-RemoteUser {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Id)
    try {
        $resp = Invoke-RestMethod -Uri "https://api/users/$Id" -ErrorAction Stop
        return $resp
    }
    catch [System.Net.WebException] {
        # Only catch what you can handle; let everything else bubble.
        Write-Warning "user $Id not reachable: $($_.Exception.Message)"
        return $null
    }
    catch {
        Write-Error "Unexpected: $_"
        throw
    }
    finally {
        Write-Verbose "Get-RemoteUser($Id) done"
    }
}
```

Rules of thumb:
- `try` / `catch` only fires for **terminating** errors. Add
  `-ErrorAction Stop` to non-terminating cmdlets or set
  `$ErrorActionPreference = 'Stop'` script-wide.
- Catch specific exception types when you know how to recover; bubble
  the rest with `throw`.
- `$_.Exception.GetType().FullName` inside a generic `catch` tells you
  what to add as the next typed catch.
- `Write-Error` is for non-terminating errors; `throw` is terminating.

## 4. Parallel / concurrent work (PowerShell 7+)

```powershell
# ForEach-Object -Parallel — runs each iteration in its own runspace.
# `using:` is required to reach variables from the parent scope.
$results = $urls | ForEach-Object -ThrottleLimit $Parallel -Parallel {
    try {
        $r = Invoke-RestMethod -Uri $_ -TimeoutSec 10 -ErrorAction Stop
        [pscustomobject]@{ Url = $_; Ok = $true;  Result = $r }
    } catch {
        [pscustomobject]@{ Url = $_; Ok = $false; Error  = $_.Exception.Message }
    }
}

$ok = $results | Where-Object Ok
Write-Host "$($ok.Count)/$($results.Count) succeeded"
```

For longer-lived parallel work prefer **thread jobs** (`Start-ThreadJob`)
over `Start-Job` — they're 10× faster because there's no process startup
cost. Process jobs are for when you need true isolation.

```powershell
$jobs = 1..10 | ForEach-Object {
    Start-ThreadJob -ScriptBlock { Start-Sleep -Seconds $using:_; "done $using:_" }
}
$jobs | Wait-Job | Receive-Job
$jobs | Remove-Job
```

## 5. Classes + modules

```powershell
class User {
    [string]$Id
    [string]$Email
    [datetime]$CreatedAt = [datetime]::UtcNow

    User([string]$id, [string]$email) {
        if (-not $email -or $email -notmatch '@') {
            throw [ArgumentException]::new("Invalid email: $email")
        }
        $this.Id = $id
        $this.Email = $email
    }

    [string] ToString() { return "$($this.Id) <$($this.Email)>" }
}

$u = [User]::new('u1','x@y.io')
```

Module skeleton (`MyModule/MyModule.psm1` + `MyModule.psd1`):

```powershell
# MyModule.psm1
. $PSScriptRoot\Private\helpers.ps1
Get-ChildItem $PSScriptRoot\Public\*.ps1 | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function (Get-ChildItem $PSScriptRoot\Public\*.ps1).BaseName
```

```powershell
# MyModule.psd1 (manifest — `New-ModuleManifest` to scaffold)
@{
    RootModule        = 'MyModule.psm1'
    ModuleVersion     = '1.0.0'
    GUID              = 'put-a-real-guid-here'
    Author            = 'You'
    PowerShellVersion = '7.2'
    FunctionsToExport = @('Get-Foo','Set-Foo')
    AliasesToExport   = @()
    CmdletsToExport   = @()
}
```

Install paths: `~\Documents\PowerShell\Modules\<Name>\<Version>\…`.

## 6. REST APIs — Invoke-RestMethod patterns

```powershell
# Generic retry-with-backoff wrapper.
function Invoke-WithRetry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][scriptblock]$Action,
        [int]$MaxAttempts = 4,
        [int]$BaseDelayMs = 250
    )
    for ($i = 1; $i -le $MaxAttempts; $i++) {
        try { return & $Action }
        catch {
            if ($i -eq $MaxAttempts) { throw }
            $delay = $BaseDelayMs * [math]::Pow(2, $i - 1)
            Write-Verbose "attempt $i failed: $($_.Exception.Message) — retrying in ${delay}ms"
            Start-Sleep -Milliseconds $delay
        }
    }
}

$users = Invoke-WithRetry {
    Invoke-RestMethod -Uri 'https://api/users' -Headers @{ Authorization = "Bearer $token" }
}
```

**Pagination** with link headers:

```powershell
$next = 'https://api.github.com/repos/foo/bar/issues'
while ($next) {
    $resp = Invoke-WebRequest -Uri $next -Headers $auth
    $resp.Content | ConvertFrom-Json | ForEach-Object { $_ }   # stream items
    # Parse RFC 5988 link header.
    $link = $resp.Headers['Link']
    $next = if ($link -match '<([^>]+)>; rel="next"') { $matches[1] } else { $null }
}
```

## 7. System administration

| Goal                  | Snippet                                                                              |
| --------------------- | ------------------------------------------------------------------------------------ |
| Service status        | `Get-Service -Name nginx \| Select-Object Status,StartType`                         |
| Restart a service     | `Restart-Service nginx -Force`                                                       |
| Schedule a task       | `Register-ScheduledTask -TaskName Backup -Trigger (New-ScheduledTaskTrigger -Daily -At 3am) -Action (New-ScheduledTaskAction -Execute pwsh.exe -Argument '-File C:\scripts\backup.ps1')` |
| Inspect a service via CIM | `Get-CimInstance Win32_Service -Filter "Name='nginx'"`                          |
| Top RAM consumers     | `Get-Process \| Sort-Object WS -Descending \| Select-Object -First 5 Name,WS`       |
| Read registry         | `Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' ProductName`  |
| Disk usage by folder  | `Get-ChildItem -Recurse -ErrorAction SilentlyContinue \| Measure-Object Length -Sum`|

Prefer `Get-CimInstance` over `Get-WmiObject` — it's the modern (PS 3+),
DCOM-free replacement. WMI cmdlets are deprecated.

## 8. Pester tests for your scripts

```powershell
# tests/Get-RemoteUser.Tests.ps1
Describe 'Get-RemoteUser' {
    BeforeAll { . $PSScriptRoot\..\src\Get-RemoteUser.ps1 }

    Context 'happy path' {
        It 'returns the user' {
            Mock Invoke-RestMethod { @{ Id='u1'; Email='x@y.io' } }
            $r = Get-RemoteUser -Id 'u1'
            $r.Id | Should -Be 'u1'
        }
    }

    Context 'errors' {
        It 'returns $null on WebException' {
            Mock Invoke-RestMethod { throw [System.Net.WebException]::new('500') }
            (Get-RemoteUser -Id 'u1') | Should -BeNullOrEmpty
        }
    }
}
```

Run: `Invoke-Pester tests/ -Output Detailed`.

## 9. Pitfalls to anticipate

- **Encoding** — PowerShell 5.1 defaults files to UTF-16-LE. ALWAYS set
  `$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8NoBOM'` (PS 7+)
  or `'utf8'` (PS 5.1) at the top of any script that writes text.
- **`$null` on the left side** — `$null -eq $x` not `$x -eq $null`.
  Otherwise comparing an array to `$null` does an element-wise match and
  silently returns `$true` when the array is empty.
- **Stop-parsing for native exes** — `git log --% --format=%H` to keep
  PowerShell from parsing `%H` as a variable.
- **`-Force` on `New-Item` truncates** files. Use
  `if (-not (Test-Path x)) { New-Item -ItemType File x }` instead.
- **Long output gets paginated** by `Out-Default` when piped to a host.
  Use `| Out-Host -Paging` only when you want it; otherwise pipe to
  `Out-String -Stream` for clean text.

## 10. When to switch shells

- Heavy text processing with `sed`/`awk`/`grep` chains → [[bash-advanced]]
- Cross-platform CI script that must run on Linux runners → bash
- Anything that creates Win32 objects, manages services, queries CIM,
  edits the registry → stay in PowerShell
