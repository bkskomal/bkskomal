---
name: bash-advanced
description: Advanced bash — strict mode, arrays / associative arrays, traps, process substitution, parallel execution, robust file processing, parameter expansion, BATS tests
tools: [exec, write_file, read_file]
triggers:
  - bash script
  - "shell script"
  - bash array
  - associative array
  - bash function
  - trap
  - "set -euo pipefail"
  - process substitution
  - "xargs -P"
  - GNU parallel
  - "<("
  - heredoc
  - bats test
  - getopts
  - "${var//"
  - parameter expansion
---

# Skill: Advanced bash

Reach for this when the task is more than `cmd1 && cmd2` — a reusable
script, a runner orchestrating N jobs, robust file processing, or a CI
pipeline step. Pairs with the [[bash-commands]] skill (basics +
quoting + invocation table).

Always invoke through `exec` with `shell: "bash"`. On Windows that's
Git Bash; we explicitly do NOT rely on WSL because not every dev has it.

## 1. Script anatomy — the production skeleton

Every `.sh` you author should start here. These lines aren't decoration:

```bash
#!/usr/bin/env bash
#
# Brief: <one-line purpose>
# Usage: ./script.sh [--flag VAL ...] <positional>
#
set -Eeuo pipefail        # see §2
IFS=$'\n\t'               # see §2
shopt -s nullglob globstar    # ** for recursion; empty globs expand to nothing
trap 'on_err $LINENO "$BASH_COMMAND" $?' ERR
trap 'cleanup' EXIT

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

# ---- helpers ----------------------------------------------------------
log()  { printf '\033[36m▸\033[0m %s\n' "$*" >&2; }
warn() { printf '\033[33m!\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[31m✗\033[0m %s\n' "$*" >&2; exit 1; }

on_err() {
    local line=$1 cmd=$2 rc=$3
    warn "line $line: '$cmd' exited $rc"
}
cleanup() {
    rm -rf "${TMP:-}"
}
```

## 2. Strict mode — the parts that bite

| Flag                | Effect                                                                            |
| ------------------- | --------------------------------------------------------------------------------- |
| `set -e`            | Exit on first command error. Without it, scripts trundle past failures.            |
| `set -u`            | Treat unset variables as an error. Catches typos at runtime.                       |
| `set -o pipefail`   | Make `cmd1 \| cmd2` fail if EITHER side fails (default is "last command wins").    |
| `set -E`            | Make `ERR` traps inherit into functions/subshells.                                 |
| `IFS=$'\n\t'`       | Stop word-splitting on every space — only split on newline + tab.                  |
| `shopt -s nullglob` | An empty glob expands to nothing instead of the literal pattern (huge `rm` gotcha).|

Without `nullglob`:

```bash
rm -f *.tmp        # expands to literal `*.tmp` if no matches; rm complains
for f in *.tmp; do echo "$f"; done    # loops once with $f="*.tmp"
```

With `nullglob`, both behave correctly when there are zero matches.

## 3. Arguments + arg parsing

For real flag parsing in bash (not POSIX `getopts`):

```bash
NO_INSTALL=0
WATCH=0
PORT=5173
positional=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-install)   NO_INSTALL=1; shift ;;
        --watch)        WATCH=1; shift ;;
        --port)         PORT="$2"; shift 2 ;;
        --port=*)       PORT="${1#*=}"; shift ;;
        -h|--help)      usage; exit 0 ;;
        --)             shift; positional+=("$@"); break ;;
        -*)             die "unknown flag: $1" ;;
        *)              positional+=("$1"); shift ;;
    esac
done
set -- "${positional[@]}"
```

The `--*=value` branch + `--` terminator are the difference between a
toy parser and one you can actually ship.

## 4. Arrays + associative arrays

```bash
# Indexed array
files=(README.md package.json src/index.ts)
echo "${#files[@]}"          # 3   (length)
echo "${files[1]}"           # package.json
echo "${files[@]: -2}"       # last 2 elements
files+=(new.ts)              # append

# Iterate safely
for f in "${files[@]}"; do
    [[ -f "$f" ]] || continue
    grep -q TODO "$f" && echo "TODO in $f"
done

# Associative array (requires bash 4+; on macOS install via Homebrew bash)
declare -A counts=()
counts[apples]=5
counts[oranges]=2
for k in "${!counts[@]}"; do
    printf '%-10s %d\n' "$k" "${counts[$k]}"
done
```

Always quote `"${arr[@]}"` — unquoted `${arr[@]}` re-splits on `$IFS`
and breaks elements that contain spaces.

## 5. Parameter expansion — the swiss army knife

```bash
name=README.md.bak

echo "${name%.bak}"       # README.md            (strip suffix)
echo "${name%%.*}"        # README              (strip all-dots suffix)
echo "${name#R}"          # EADME.md.bak        (strip prefix)
echo "${name##*/}"        # basename
echo "${name%/*}"         # dirname
echo "${name//./_}"       # README_md_bak       (replace all)
echo "${name/./_}"        # README_md.bak       (replace first)
echo "${name:-default}"   # value, or 'default' if unset/empty
echo "${name:=default}"   # same, but also assign
echo "${#name}"           # length
echo "${name:0:6}"        # README              (substring)
echo "${name^^}"          # README.MD.BAK       (upper)
echo "${name,,}"          # readme.md.bak       (lower)
```

These are fork-free — no `awk`/`sed` subprocess. In a tight loop the
difference is real (1000× faster than `echo … | sed`).

## 6. Functions + locals + return values

```bash
# Convention: snake_case names, locals for everything, return code = exit.
slugify() {
    local input="$1"
    local out
    out="$(echo "$input" | tr '[:upper:]' '[:lower:]' | tr -cs 'a-z0-9' '-')"
    out="${out#-}"
    out="${out%-}"
    printf '%s' "$out"
}

slug="$(slugify "Some Title — 2024!")"
echo "$slug"   # some-title-2024
```

Bash functions return integer status (0–255). To return data, **echo**
it and capture with `$(…)`. Pass arrays into a function by
**name-reference** (`local -n arr_ref=$1`) — passing by value is awkward.

## 7. Traps — cleanup that always fires

```bash
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
trap 'echo "interrupted"; exit 130' INT TERM

# work in $TMP knowing it'll vanish whether we exit cleanly or via Ctrl-C
```

Multiple traps on `EXIT` overwrite each other — install ONE cleanup
function and have it call everything you need.

## 8. Process substitution + heredocs

```bash
# Process substitution — feed a pipeline as a filename.
diff <(sort old.txt) <(sort new.txt)

# Capture stdout and stderr separately.
{ out="$(cmd 2> >(err_log_handler))"; }

# Heredoc with variable expansion.
cat > config.yaml <<EOF
env: $ENV
port: $PORT
EOF

# Heredoc WITHOUT expansion (single-quoted delimiter — useful for code).
cat > script.py <<'EOF'
x = "$NOT_EXPANDED"
print(f"{x!r}")
EOF

# Here-string — quick stdin replacement.
read -r year month day <<< "$(date '+%Y %m %d')"
```

## 9. Parallel execution — xargs, GNU parallel, & + wait

For embarrassingly-parallel work, three good options:

```bash
# 1. xargs -P  — built-in, no extra deps, ordered output per item
printf '%s\n' files/*.csv | xargs -n1 -P8 -I{} ./process.sh {}

# 2. GNU parallel — better output handling, retries, dry-run support
parallel -j8 --halt now,fail=1 ./process.sh ::: files/*.csv

# 3. Bash & + wait — when you want fine-grained control
declare -a pids=()
for f in files/*.csv; do
    ./process.sh "$f" & pids+=($!)
    if (( ${#pids[@]} >= 8 )); then
        wait -n; pids=("${pids[@]:1}")    # bash 5+: wait for ANY child
    fi
done
wait    # drain remaining
```

`xargs -P` is the workhorse. Reach for `parallel` when you need its
specific features (retry, ETA, structured logs).

## 10. JSON + jq (the assumed dependency)

```bash
# Extract a field with a default
version="$(jq -r '.version // "0.0.0"' package.json)"

# Update one field (idempotent — round-trips through jq)
tmp="$(mktemp)"
jq '.version = "1.2.3"' package.json > "$tmp" && mv "$tmp" package.json

# Filter an array
jq -r '.items[] | select(.kind=="bug") | .id' bugs.json

# Build JSON safely (jq quotes for you — never assemble JSON with printf)
jq -n --arg user "$USER" --argjson ts "$(date +%s)" \
   '{user: $user, at: $ts}'
```

For YAML, install `yq` (`pip install yq` or Homebrew `yq` — both work).

## 11. Robust file processing — streaming over slurping

```bash
# Wrong (loads the whole file into memory)
content="$(cat huge.log)"
for line in $content; do …; done

# Right (streams line by line; quotes preserve whitespace)
while IFS= read -r line; do
    [[ "$line" == ERROR* ]] && echo "$line"
done < huge.log

# Process a list of paths NULL-delimited (handles names with newlines / spaces)
find . -name '*.bak' -print0 |
    while IFS= read -r -d '' f; do
        rm -- "$f"
    done
```

For binary-safe pipelines, always use `-print0` / `-0` / `-d ''`.

## 12. BATS — test scripts the right way

`tests/cli.bats`:

```bash
#!/usr/bin/env bats

setup() {
    PROJECT_ROOT="$(cd -- "$(dirname -- "${BATS_TEST_FILENAME}")/.." && pwd)"
    PATH="$PROJECT_ROOT/bin:$PATH"
}

@test "slugify lowercases and dashes" {
    run "$PROJECT_ROOT/bin/slugify" "Hello World!"
    [ "$status" -eq 0 ]
    [ "$output" = "hello-world" ]
}

@test "fails on empty input" {
    run "$PROJECT_ROOT/bin/slugify" ""
    [ "$status" -ne 0 ]
}
```

Run: `bats tests/`.

## 13. Gotchas / non-obvious foot-guns

- `[[ ... ]]` is bash-only; `[ ... ]` is POSIX. Prefer `[[` in a `bash`
  script — better operators (`=~`, `<`, `&&`), no word-splitting inside.
- `$?` is only meaningful immediately after a command. Capture it:
  `cmd; rc=$?`.
- A function's `local var=$(cmd)` will mask the exit code of `cmd`
  because `local` itself returns 0. Split the declaration:
  `local var; var=$(cmd) || return $?`.
- `set -e` does **not** apply inside `&&` / `||` chains or in a function
  whose return value is being tested. Use `set -E` + explicit
  `|| die "…"` instead of leaning on `-e` everywhere.
- Tilde expansion only happens when the `~` is unquoted. `"~/file"` is
  literal; use `"$HOME/file"`.

## 14. When to switch shells

- Windows-specific work (services, registry, scheduled tasks, MSI) →
  [[powershell-advanced]]
- Pipeline-object semantics (`Select-Object`, `Where-Object` style) →
  PowerShell wins
- Pure POSIX text munging, GNU coreutils, parallel jobs, cross-platform
  CI → stay in bash
