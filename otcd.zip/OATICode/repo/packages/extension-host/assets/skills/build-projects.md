---
name: build-projects
description: Build client + server projects (frontend bundlers, backend compilers, monorepos) and surface failures clearly
tools: [exec, read_file, get_diagnostics, list_dir]
triggers:
  - build the project
  - "npm run build"
  - "pnpm build"
  - "yarn build"
  - vite build
  - webpack build
  - "next build"
  - "tsc"
  - "cargo build"
  - "go build"
  - "mvn package"
  - "dotnet build"
  - production build
  - bundle the app
  - "compile"
---

# Skill: Build client + server projects

Builds are the canary for "does this codebase still work?" Pick the right
command, stream output, and convert failures into a concrete next step.

## 1. Discover the build entry point

Read `package.json` (root + workspace packages) and look at `scripts`:

- `build`, `build:prod`, `build:web`, `build:server` are common.
- `dev` / `start` is for running — not for this skill.
- If there's a custom name (`build:client`, `build:api`), run that.

For non-Node stacks check the canonical command:

| Stack           | Build command                                      |
| --------------- | -------------------------------------------------- |
| TypeScript only | `pnpm exec tsc -p tsconfig.build.json` or `tsc -b` |
| Vite            | `pnpm vite build` (or `npm run build`)             |
| Webpack         | `pnpm webpack --mode production`                   |
| Next.js         | `pnpm next build`                                  |
| Remix / Astro   | their `build` script                               |
| esbuild         | the project's `build` script (no global default)   |
| Rust            | `cargo build --release`                            |
| Go              | `go build ./...`                                   |
| .NET            | `dotnet build -c Release`                          |
| Java / Maven    | `mvn -B -DskipTests package`                       |
| Java / Gradle   | `./gradlew build -x test`                          |
| Python wheels   | `python -m build`                                  |
| Docker image    | `docker build -t name:tag .`                       |

## 2. Pick the right shell

- **Bash** (preferred) for `pnpm build && pnpm typecheck` and any chained
  commands. POSIX `&&` short-circuits correctly.
- **PowerShell** when you genuinely need cmdlets (rare for builds).
- **Auto** is fine for single-command builds (`pnpm build`) — but use bash
  the moment you chain anything.

```json
{
  "command": "pnpm install --frozen-lockfile && pnpm typecheck && pnpm build",
  "shell": "bash",
  "timeoutMs": 600000
}
```

## 3. Monorepo strategy

If the workspace has `pnpm-workspace.yaml`, `package.json#workspaces`,
`turbo.json`, or `nx.json`:

- Prefer the orchestrator's build: `pnpm -r build`, `pnpm turbo run build`,
  `pnpm nx run-many --target=build`.
- Don't `cd` into a package and build it in isolation unless the user
  asked — you'll bypass dependency ordering.

## 4. Streaming and timeouts

- Default `exec` timeout is 60s; bump to **5-10 minutes** for full builds.
- Watch for "out of memory" patterns in stderr; suggest
  `NODE_OPTIONS=--max-old-space-size=4096` when relevant.
- For long bundlers (Next, Webpack), the streamed output is your only
  signal — keep an eye on the tail for hangs.

## 5. Failure → next step

Don't just report "build failed" — read stderr and pick a recovery:

| Pattern                                          | Next step                                                          |
| ------------------------------------------------ | ------------------------------------------------------------------ |
| `Cannot find module 'X'`                         | Run [[install-dependencies]] first; the lockfile is out of sync    |
| `TS2307 / TS2304` (type errors)                  | Read the file, fix the import, re-run                              |
| `error TS5023: Unknown compiler option`          | tsconfig is incompatible with the installed TS — check version     |
| `EACCES` on a build output                       | The user has the file open in an editor / the dist is read-only    |
| `ENOSPC: no space left on device`                | Stop and surface to the user                                       |
| `out of memory`                                  | Increase `NODE_OPTIONS`; suggest dropping concurrency              |
| Vite "[plugin:foo] Transform failed"             | Read the offending file's diagnostics                              |
| Webpack `Module not found: Can't resolve 'X'`    | Same as Cannot find module                                         |
| `error: failed to compile` (Rust) `E0XXX`        | Open the file at the reported line; fix the typed error            |

Use `get_diagnostics` to compare against the LSP's view — the model
sometimes mis-reads compiler output that the LSP has already explained.

## 6. Verify

After a successful build, sanity-check the output:

- Web bundler: `list_dir dist` (or `build/`) — confirm at least one
  `.js` / `.html` exists.
- TypeScript: `pnpm exec tsc --noEmit` to confirm no leftover errors.
- Rust: `target/release/<name>` exists.
- Go: `ls bin/` (or wherever the project conventions put binaries).

## 7. Don't…

- Blindly run `pnpm install` again before every build — it slows the
  loop and isn't usually the fix.
- Delete `dist` / `build` / `target` to "force a clean build" without
  asking; many workflows keep cached outputs there.
- Pass `--force` or `-D` flags to suppress warnings — read them.

When the build is green, hand off to [[run-and-debug]] (start the
server) or report the artifacts and stop.
