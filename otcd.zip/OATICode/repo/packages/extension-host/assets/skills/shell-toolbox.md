---
name: shell-toolbox
description: Common cross-shell developer recipes (git, npm/pnpm/yarn, node, docker, http) routed to the right shell
tools: [exec, read_file]
triggers:
  - git
  - npm
  - pnpm
  - yarn
  - docker
  - curl
  - http request
  - clone
  - install dependencies
  - run tests
  - build
  - dev server
  - clone repo
  - "npm install"
  - "git clone"
---

# Skill: Shell toolbox

A short catalogue of developer-task recipes plus which shell to call
them through. Load this skill whenever the user asks for a "common
developer command" — clone, install, test, build, run, push.

## Routing rule of thumb

- POSIX one-liners (`&&`, pipes, `grep`, `find`) → `shell: "bash"`.
- Windows / cmdlet / `$env:` syntax → `shell: "pwsh"`.
- Plain single command with no special syntax → `shell: "auto"` is fine.

The detailed playbooks live in the [[bash-commands]] and
[[powershell-commands]] skills — load those for syntax and pitfall
details. This skill just gives you the canonical recipes.

## Git

| Goal              | bash                                          | pwsh                                                    |
| ----------------- | --------------------------------------------- | ------------------------------------------------------- |
| Status            | `git status --short`                          | same                                                    |
| Clone             | `git clone https://… target/`                 | same                                                    |
| Last 5 commits    | `git log --oneline -5`                        | same                                                    |
| Diff one file     | `git diff -- path/to/file`                    | same                                                    |
| Create branch     | `git switch -c feat/x`                        | same                                                    |
| Commit (multiline)| heredoc → `git commit -m "$(cat <<'EOF'\n…\nEOF\n)"` | here-string → `git commit -m @'\n…\n'@`         |
| Push current      | `git push -u origin HEAD`                     | same                                                    |
| Show remote       | `git remote -v`                               | same                                                    |

Never `--force-push`, `git reset --hard`, `git clean -fdx`, or
`git checkout -- .` without first asking the user.

## Node package managers

| Goal                | bash / pwsh                                            |
| ------------------- | ------------------------------------------------------ |
| Install (lockfile)  | `npm ci` · `pnpm install --frozen-lockfile` · `yarn --immutable` |
| Add a dep           | `npm i pkg` · `pnpm add pkg` · `yarn add pkg`          |
| Add dev dep         | `npm i -D pkg` · `pnpm add -D pkg` · `yarn add -D pkg` |
| Remove dep          | `npm rm pkg` · `pnpm remove pkg` · `yarn remove pkg`   |
| Run script          | `npm run build` · `pnpm build` · `yarn build`          |
| Run tests           | `npm test --silent` · `pnpm test` · `yarn test`        |
| Outdated            | `npm outdated` · `pnpm outdated` · `yarn outdated`     |

Use `npm ci` over `npm install` in CI-like situations — it's faster
and respects the lockfile exactly.

## Node / language runtimes

| Goal                  | command                                       |
| --------------------- | --------------------------------------------- |
| Print version         | `node --version`                              |
| Run a one-liner       | `node -e "console.log(process.version)"`     |
| Print env path        | bash: `echo $PATH` · pwsh: `$env:PATH`        |
| Run a TypeScript file | `npx tsx file.ts` (or `node --loader tsx file.ts`) |

## Docker

| Goal              | command                                                |
| ----------------- | ------------------------------------------------------ |
| List containers   | `docker ps -a`                                         |
| List images       | `docker image ls`                                      |
| Build             | `docker build -t name:tag .`                           |
| Run, ephemeral    | `docker run --rm -it name:tag`                         |
| Logs              | `docker logs --tail 200 -f container`                  |
| Stop + remove all | (only when explicitly asked — destructive)             |

## HTTP requests

| Goal              | bash                                                      | pwsh                                                                            |
| ----------------- | --------------------------------------------------------- | ------------------------------------------------------------------------------- |
| GET               | `curl -s https://api.example/x`                           | `Invoke-WebRequest -Uri https://api.example/x`                                  |
| GET JSON          | `curl -s https://api.example/x \| jq .`                   | `Invoke-RestMethod -Uri https://api.example/x`                                  |
| POST JSON         | `curl -s -X POST -H 'Content-Type: application/json' -d '{"k":"v"}' https://api.example/x` | `Invoke-RestMethod -Method Post -ContentType 'application/json' -Body '{"k":"v"}' -Uri https://…` |
| Save to file      | `curl -sLo out.zip https://…`                             | `Invoke-WebRequest -OutFile out.zip -Uri https://…`                             |

## Filesystem

| Goal                | bash                                       | pwsh                                                          |
| ------------------- | ------------------------------------------ | ------------------------------------------------------------- |
| List, hidden + size | `ls -la`                                   | `Get-ChildItem -Force \| Format-Table Mode,Length,Name`       |
| Recurse             | `find . -type f`                           | `Get-ChildItem -Recurse -File`                                |
| Search content      | `grep -rn "TODO" src/`                     | `Select-String -Pattern "TODO" -Path src\**\*.ts`             |
| Count lines         | `wc -l file`                               | `(Get-Content file \| Measure-Object -Line).Lines`            |
| Make dir (-p)       | `mkdir -p path/to/dir`                     | `New-Item -ItemType Directory -Force -Path path\to\dir`       |
| Delete recursive    | `rm -rf path`                              | `Remove-Item -Recurse -Force path`                            |

Confirm with the user before `rm -rf` / `Remove-Item -Recurse -Force`
unless the path is clearly inside a build / out directory.

## Process & environment

| Goal               | bash                          | pwsh                                                      |
| ------------------ | ----------------------------- | --------------------------------------------------------- |
| Print env var      | `echo "$PATH"`                | `$env:PATH`                                               |
| Set for one call   | `VAR=x cmd`                   | `$env:VAR = 'x'; cmd`                                     |
| Which              | `which node`                  | `(Get-Command node).Source`                               |
| Top-N processes    | `ps aux \| head -5`           | `Get-Process \| Sort-Object WS -Desc \| Select-Object -First 5` |
| Kill by name       | `pkill -f name`               | `Stop-Process -Name name -Force`                          |

## Final reminder

Always pass `shell` explicitly when you're using syntax that's
shell-specific. The default `auto` shell is cmd.exe on Windows and
sh elsewhere — both will mangle a fancy bash one-liner.
