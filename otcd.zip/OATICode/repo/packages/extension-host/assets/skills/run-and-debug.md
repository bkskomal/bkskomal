---
name: run-and-debug
description: Start dev / production servers, attach the debugger, tail logs, and shut things down cleanly
tools: [exec, read_file, get_diagnostics, get_workspace_context, start_background_task, debug_set_breakpoint, debug_continue, debug_step_over, debug_evaluate, debug_get_stack]
triggers:
  - run the project
  - run the server
  - run the client
  - start dev server
  - "npm run dev"
  - "pnpm dev"
  - "yarn dev"
  - "start the app"
  - launch the app
  - debug the
  - attach debugger
  - set breakpoint
  - tail logs
  - "node --inspect"
---

# Skill: Run + debug client/server projects

Three jobs in one playbook because they share a process model:

1. Start a dev / prod server.
2. Attach a debugger to that server.
3. Tail logs and shut down cleanly.

## 1. Find the run entry point

Read `package.json` and look for:

- `dev`, `start:dev`, `start`, `serve`, `dev:web`, `dev:api` — pick the
  closest match to the user's intent (client vs. server).
- Vite/Next/Remix all use `dev`. Express/NestJS apps usually use `start:dev`
  with nodemon or `tsx watch`.

Non-Node stacks:

| Stack         | Run command                                              |
| ------------- | -------------------------------------------------------- |
| Express/Node  | `node --enable-source-maps dist/server.js`               |
| Express + ts  | `pnpm tsx src/server.ts`                                 |
| FastAPI       | `python -m uvicorn app.main:app --reload --port 8000`    |
| Django        | `python manage.py runserver 0.0.0.0:8000`                |
| Flask         | `flask --app app run -p 5000`                            |
| Spring Boot   | `./mvnw spring-boot:run` or `./gradlew bootRun`          |
| .NET          | `dotnet run --project Server/Server.csproj`              |
| Go            | `go run ./cmd/server`                                    |
| Rust (axum)   | `cargo run --release`                                    |

## 2. Pick the right launch path

Three options, in order of preference for a dev loop:

- **`start_background_task`** — preferred for long-lived servers. Returns
  a task id; the server keeps running while you do other work. Use for
  any `--watch`, `dev`, or `serve` style command.
- **`exec` with a bumped `timeoutMs`** — only when the command is
  short-lived (a one-shot script, a CLI run).
- **A PowerShell helper script** — when the launch needs env variables,
  pre/post hooks, port checks, etc. See [[automation-scripts]] for
  authoring `.ps1` / `.sh` runners that wrap the whole flow.

Never use `exec` for a `--watch` server — it will hold the agent loop
until the timeout fires and then kill the dev server. Always wrap
long-running launches in `start_background_task`.

## 3. Port hygiene

Before launching anything that binds a port:

```bash
# Bash
lsof -iTCP:5173 -sTCP:LISTEN -n -P 2>/dev/null || echo "free"
```

```powershell
# PowerShell
Get-NetTCPConnection -State Listen -LocalPort 5173 -ErrorAction SilentlyContinue
```

If the port is busy, ask the user before killing the previous owner;
otherwise pick the next free port (Vite, Next, FastAPI all support
`--port`).

## 4. Attach a debugger

OATI Code's `debug_*` tools talk to VS Code's DAP — use them rather than
shelling out to debuggers.

### Node servers

1. Start the server with `--inspect=9229` (or rely on the project's
   existing dev script that already does it):

```bash
node --enable-source-maps --inspect=9229 dist/server.js
```

Or via the dev script:

```bash
NODE_OPTIONS="--inspect=9229" pnpm dev
```

2. In VS Code: `debug_attach` to `localhost:9229` via the workspace's
   launch.json profile. If no profile exists, author one in
   `.vscode/launch.json` (Attach to Node, port 9229).
3. Set breakpoints with `debug_set_breakpoint`; step with
   `debug_step_over`; inspect with `debug_evaluate`.

### Python servers

```bash
python -m debugpy --listen 5678 --wait-for-client -m uvicorn app.main:app
```

Attach to `localhost:5678`. Make sure the user has `debugpy` installed
(`pip install debugpy`).

### .NET servers

```bash
dotnet run --project Server/Server.csproj
```

VS Code's C# extension auto-discovers the debug target. The
`debug_*` tools handle attach via launch.json.

### Browser (client side)

For Vite/Next/CRA web apps, the right debugger is the JavaScript Debug
Terminal or "Attach to Chrome" — author a launch.json entry rather than
running anything shell-side.

## 5. Tail logs without blocking

If a server is running in a background task, tail its log file rather
than hooking the running process:

```bash
tail -n 200 -f logs/app.log
```

```powershell
Get-Content logs\app.log -Tail 200 -Wait
```

Both forms must be wrapped in `start_background_task` too — `-f` / `-Wait`
never returns.

## 6. Stop cleanly

- `start_background_task` returns an id; use the matching stop tool
  (or VS Code's task panel) to halt it.
- For an `exec`-launched process you can SIGTERM the PID:

```bash
kill -TERM "$(lsof -tiTCP:5173 -sTCP:LISTEN)"
```

```powershell
Get-NetTCPConnection -State Listen -LocalPort 5173 |
  ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
```

Confirm with the user before killing — they might want the server up.

## 7. Recovery patterns

| Symptom                                  | Next step                                                          |
| ---------------------------------------- | ------------------------------------------------------------------ |
| `EADDRINUSE`                             | Probe port owner, ask user, fall back to a new port                |
| `Cannot find module 'X'` at runtime      | Re-run [[install-dependencies]]; mismatched lockfile               |
| Server starts then exits 0 immediately   | Missing `--watch` or wrong entry point; check the dev script       |
| `error TS2307` only at runtime           | Build skipped; run [[build-projects]] first                        |
| Debugger doesn't attach                  | Confirm the inspect port matches launch.json; check firewall       |
| `connect ECONNREFUSED 127.0.0.1:5432`    | A dependent service (Postgres, Redis) isn't up; surface to user    |

## 8. Don't…

- Run a long-running server through plain `exec` (it'll be killed at the
  timeout — wasted work).
- Auto-restart a crashing server in a tight loop; surface the crash.
- Run two dev servers on the same port; check first.
- Hold the agent loop on `tail -f` foreground — background it.

When the server is up + the debugger is attached, hand control back to
the user.
