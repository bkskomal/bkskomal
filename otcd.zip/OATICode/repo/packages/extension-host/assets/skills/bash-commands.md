---
name: bash-commands
description: Run POSIX/bash commands safely from OATI Code (find, grep, sed, awk, git, npm, curl, etc.)
tools: [exec, read_file, write_file, get_workspace_context]
triggers:
  - bash
  - shell command
  - run command
  - run script
  - sh command
  - posix
  - terminal
  - "git bash"
  - "&&"
  - "||"
  - "in the terminal"
---

# Skill: Bash commands

Use this playbook when the user asks you to run a POSIX/bash command, or
when the task is naturally expressed in POSIX shell idioms (`find`, `grep`,
`sed`, `awk`, `xargs`, `&&`, `||`, here-docs, `$VAR` expansion, etc.).

## 1. Always invoke through the `exec` tool with `shell: "bash"`

```json
{
  "command": "ls -la && git status --short",
  "shell": "bash"
}
```

- On Windows the host resolves `bash` to Git Bash (`C:\Program Files\Git\bin\bash.exe`).
- On macOS/Linux the host uses `/bin/bash`.
- The user's profile is loaded (`-lc`) so `$PATH` includes their dev tools.
- Do NOT prefix with `cmd /c bash -c …` — set the `shell` parameter instead.

## 2. Pick bash over the default `auto` shell when…

- Chaining with `&&` / `||` (cmd.exe parses these differently).
- Using POSIX utilities: `find`, `grep`, `sed`, `awk`, `xargs`, `tr`, `cut`.
- Heredocs: `cat <<'EOF' ... EOF`.
- Bash-specific syntax: `$(…)`, `${var:-default}`, process substitution.
- Piping through `jq`, `yq`, `rg`, etc.

## 3. Common patterns

| Goal                          | Bash                                                       |
| ----------------------------- | ---------------------------------------------------------- |
| Find files by pattern         | `find . -type f -name "*.ts" -not -path "*/node_modules/*"` |
| Search content                | `grep -rn "TODO" src/`                                     |
| Word count                    | `wc -l file.txt`                                           |
| Count lines per dir           | `find src -name "*.ts" \| xargs wc -l \| tail -1`          |
| Replace in-place              | `sed -i 's/foo/bar/g' file.txt`                            |
| Run multiple if first passes  | `npm run build && npm test`                                |
| Capture command output        | `out=$(git rev-parse HEAD)`                                |
| Conditional                   | `if [ -f package.json ]; then echo yes; fi`                |
| JSON via jq                   | `cat pkg.json \| jq '.dependencies'`                       |
| Stream a log                  | `tail -f logs/app.log`                                     |

## 4. Quoting rules

- Use single quotes for strings without variable expansion.
- Double quotes when you need `$VAR` interpolation.
- Escape `$`, backticks, and `"` inside double quotes with `\`.
- For commit messages with newlines, use a here-doc:

```bash
git commit -m "$(cat <<'EOF'
First line
Second line
EOF
)"
```

## 5. Working directory

- The `cwd` parameter on the `exec` tool defaults to the workspace root.
- Set `cwd` explicitly when the command must run elsewhere — don't
  `cd subdir && …` because each `exec` call is its own shell with no
  persistent state.

## 6. Long-running and interactive commands

- Bash commands cannot prompt for input — the child has no TTY.
  Use non-interactive variants: `git commit --no-edit`, `npm ci` not
  `npm install`, `apt-get -y` not `apt-get install`.
- For long-running tasks (>60s), pass an explicit `timeoutMs` or split
  the work. Default timeout is 60 seconds.
- Don't background with `&` — there's no way to monitor it once the
  parent `exec` returns.

## 7. When NOT to use bash

- The command uses PowerShell cmdlets, `$env:NAME`, or pipeline objects
  → use `shell: "pwsh"` (see the `powershell-commands` skill).
- The command is a single Windows CMD builtin like `dir` or `where` →
  `shell: "cmd"` is fine; bash will also handle `ls`.
- The user explicitly asks for PowerShell.

## 8. Recovery

- If `exec` returns `exitCode: 127` with "Shell 'bash' not found", Git
  Bash isn't installed. Tell the user to install Git for Windows or fall
  back to `shell: "powershell"`.
- A non-zero exit is data, not a hard stop — read stderr, diagnose, and
  try a different approach (a different flag, a quoted path, etc.).
