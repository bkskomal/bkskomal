---
name: automation-scripts
description: Author PowerShell / bash helper scripts (build.ps1, dev.ps1, debug.ps1, build.sh) that wrap repeatable workflows for the workspace
tools: [write_file, read_file, exec, list_dir]
triggers:
  - automation script
  - powershell script
  - "create a .ps1"
  - "create a script"
  - "write a script"
  - helper script
  - dev script
  - build script
  - "build.ps1"
  - "dev.ps1"
  - "debug.ps1"
  - "build.sh"
  - "dev.sh"
  - runbook
---

# Skill: Author automation scripts

When a multi-step workflow gets repeated (install → typecheck → build →
run; or build server + build client + start both), promote it into a
versioned helper script in the workspace. Future you (and the team)
hit one command instead of remembering five.

## 1. Pick the format that matches the workspace

| Workspace signal                                  | Default format                         |
| ------------------------------------------------- | -------------------------------------- |
| Windows-first, no WSL, no Git Bash                | `.ps1`                                 |
| Cross-platform team, Linux/macOS contributors     | `.sh` (POSIX bash)                     |
| Both audiences                                    | Author both; keep them in sync         |
| Project already has `scripts/*.ps1` or `scripts/*.sh` | Match the existing convention      |

If the project uses npm scripts (`package.json#scripts`), prefer
**adding a script entry** that calls the helper — `"dev": "pwsh scripts/dev.ps1"` —
so contributors discover it via `pnpm run`.

## 2. PowerShell skeleton

Save under `scripts/<name>.ps1`. Always start with this header — it
handles strict mode + a usable trace:

```powershell
#!/usr/bin/env pwsh
[CmdletBinding()]
param(
    [switch]$NoInstall,
    [switch]$Watch,
    [int]$Port = 5173
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Run-Step {
    param([string]$Name, [scriptblock]$Body)
    Write-Host "▶ $Name" -ForegroundColor Cyan
    & $Body
    if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE"
    }
}

Push-Location $PSScriptRoot/..
try {
    if (-not $NoInstall) {
        Run-Step 'Install' { pnpm install --frozen-lockfile }
    }
    Run-Step 'Typecheck' { pnpm exec tsc --noEmit }
    Run-Step 'Build'     { pnpm build }
    if ($Watch) {
        Run-Step 'Dev'   { pnpm dev --port $Port }
    }
}
finally {
    Pop-Location
}
```

Pattern notes:

- `$ErrorActionPreference = 'Stop'` + `throw on $LASTEXITCODE` means
  any failing step halts the script. Without those, PowerShell happily
  continues after a non-zero exit.
- `Push-Location $PSScriptRoot/..` makes the script callable from
  anywhere — it always runs from the repo root.
- Parameters (`-NoInstall`, `-Watch`, `-Port 4000`) keep the script
  composable; default values keep the no-arg invocation useful.
- Use `Write-Host` with `-ForegroundColor` to make stages stand out in
  the terminal. Don't use ANSI escapes — PowerShell 5.1 mangles them.

## 3. Bash skeleton

Save under `scripts/<name>.sh`, `chmod +x` it via `exec`:

```bash
#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

NO_INSTALL=0
WATCH=0
PORT=5173
while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-install) NO_INSTALL=1; shift ;;
        --watch)      WATCH=1; shift ;;
        --port)       PORT="$2"; shift 2 ;;
        *)            echo "unknown arg: $1" >&2; exit 2 ;;
    esac
done

step() { printf '\n\033[36m▶ %s\033[0m\n' "$1"; }

if [[ $NO_INSTALL -eq 0 ]]; then
    step 'Install';   pnpm install --frozen-lockfile
fi
step 'Typecheck';     pnpm exec tsc --noEmit
step 'Build';         pnpm build
if [[ $WATCH -eq 1 ]]; then
    step 'Dev';       pnpm dev --port "$PORT"
fi
```

Pattern notes:

- `set -euo pipefail` is non-negotiable: fail on errors, undefined
  vars, and pipeline failures.
- The arg parser is hand-rolled because portable POSIX `getopts` does
  not support `--long-flags`.
- Resolve `ROOT` via `BASH_SOURCE` so the script behaves the same when
  invoked from anywhere.

## 4. Canonical wrappers to author

Most workspaces benefit from these four:

| Script           | Default behavior                                              |
| ---------------- | ------------------------------------------------------------- |
| `scripts/dev.ps1` (+ `.sh`) | Install if needed → start dev server(s) in watch mode |
| `scripts/build.ps1` (+ `.sh`) | Install → typecheck → build (no run)                |
| `scripts/test.ps1` (+ `.sh`)  | Install → run unit + integration tests              |
| `scripts/debug.ps1` (+ `.sh`) | Build → start server with `--inspect` / `debugpy`   |

For monorepos, split into `dev-client.ps1` / `dev-server.ps1` and a
combined `dev-all.ps1` that runs both in parallel (PowerShell:
`Start-Job` then `Receive-Job -Keep` until Ctrl-C).

## 5. Run-side concerns inside the script

- Detect the package manager once at the top of the script (read
  lockfile), then use it consistently — don't switch mid-script.
- Pre-flight: check `node --version`, `pnpm --version`. Fail fast with
  a clear "install Node 20+ before running this".
- Free ports for dev: probe before binding (see [[run-and-debug]]).
- For combined client + server scripts, prefer **separate processes**
  over a single super-process — easier to attach a debugger to one
  side without bringing the other down.

## 6. Wire the script into the project

After authoring `scripts/dev.ps1`:

1. Add a `package.json` script alias so contributors can run it the
   way they already run other scripts:

```json
{
  "scripts": {
    "dev": "pwsh -NoLogo -File scripts/dev.ps1 -Watch",
    "dev:posix": "bash scripts/dev.sh --watch"
  }
}
```

2. Update README.md / OATI.md with a one-line "How to run" pointing at
   the script. Discoverability is the whole point.
3. If the script supersedes an existing ad-hoc workflow, leave a one-
   line note in the README about what changed.

## 7. Verify before handing off

After writing the script:

- `pwsh -File scripts/dev.ps1 -NoInstall` (smoke test the non-install
  branch).
- `bash scripts/dev.sh --no-install` (same for the POSIX twin).
- Confirm Ctrl-C exits cleanly — if you backgrounded jobs, you need
  a `trap` (bash) or `try/finally` cleanup (PowerShell) that stops
  them.

## 8. Don't…

- Hand-edit scripts to inline secrets — read them from `.env` /
  `$env:` instead.
- Call `sudo` / `Start-Process -Verb RunAs` inside a script without
  asking the user.
- Background a server without a documented way to stop it.
- Mix `&&` chaining inside a `.ps1` that needs to run on Windows
  PowerShell 5.1 — it doesn't support `&&`. Use the `Run-Step` helper
  above instead.

Once the script exists, route future "install + build + run" prompts
through it instead of re-issuing the raw commands.
