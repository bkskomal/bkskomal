"""OATI branded PPTX template — reusable starting point.

USAGE
=====
Copy this file into your project (or .oati/templates/) and customize the
slide builders at the bottom for your specific deck. The chrome (header
bar + footer band + brand sparkle + palette) stays consistent across
slides so the whole deck reads as one brand.

CANVAS
======
10 in × 5.625 in (16:9). Calibri Light throughout.

CHROME
======
* Title slide: dark navy canvas + darker right panel + red accent stripe.
  Bold title 40pt, subtitle 22pt, chip strip + "at a glance" bullets.
* Content slides: light off-white body + full-width navy header band
  with brand sparkle + slide title (white, 19pt) + optional eyebrow
  italic. Thin navy footer band with PROPRIETARY line.

WIDGETS PROVIDED
================
* _chip(slide, x, y, w, h, label, color) — pill/chip with bold white text
* _light_card(slide, x, y, w, h, accent) — white card + colored top stripe
* _bulleted_light(slide, x, y, w, h, bullets) — red-square bullet list
* _section_eyebrow(slide, x, y, w, text) — italic muted sub-line

Edit the PALETTE block at top to re-skin the whole deck in one place.
"""
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

# ---------------------------------------------------------------------------
# Palette — edit these to re-skin the whole deck in one place.
# ---------------------------------------------------------------------------
BG_MAIN_DARK = RGBColor(0x1A, 0x2B, 0x4A)   # navy canvas (title slide)
BG_PANEL_DARK = RGBColor(0x16, 0x20, 0x38)  # darker side panel
BG_LIGHT = RGBColor(0xF8, 0xF9, 0xFA)       # body bg for content slides
HEADER_NAVY = RGBColor(0x1A, 0x2B, 0x4A)    # header + footer band
ACCENT_RED = RGBColor(0xCC, 0x00, 0x00)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
SOFT_BLUE = RGBColor(0x5B, 0x9B, 0xD5)
LIGHT_GRAY = RGBColor(0xE7, 0xE6, 0xE6)
MUTED_DARK = RGBColor(0x8C, 0x9B, 0xAB)     # muted on dark
INK = RGBColor(0x1F, 0x2A, 0x3D)            # body ink on light bg
SUBTLE_INK = RGBColor(0x4A, 0x5A, 0x70)     # secondary text on light bg
SOFT_BORDER = RGBColor(0xE0, 0xE4, 0xEA)
CARD_BG = RGBColor(0xFF, 0xFF, 0xFF)
CARD_BG_ALT = RGBColor(0xF1, 0xF3, 0xF6)
CHIP_BLUE = RGBColor(0x25, 0x63, 0xEB)
CHIP_PURPLE = RGBColor(0x7C, 0x3A, 0xED)
CHIP_ORANGE = RGBColor(0xD9, 0x77, 0x06)
CHIP_TEAL = RGBColor(0x0D, 0x94, 0x88)
CHIP_GREEN = RGBColor(0x2E, 0xA0, 0x43)
CHIP_INDIGO = RGBColor(0x31, 0x2E, 0x81)

# Canvas geometry — 10 in × 5.625 in (16:9).
SLIDE_W = Inches(10)
SLIDE_H = Inches(5.625)

# Title-slide right-panel geometry
PANEL_X = Inches(6.9)
PANEL_W = SLIDE_W - PANEL_X
STRIPE_W = Emu(54864)  # ~0.06 in red accent stripe

# Content-slide chrome geometry
HEADER_H = Inches(0.75)
FOOTER_H = Inches(0.21)
FOOTER_Y = SLIDE_H - FOOTER_H
BODY_TOP = HEADER_H + Inches(0.15)
BODY_LEFT = Inches(0.5)
BODY_RIGHT = SLIDE_W - Inches(0.5)
BODY_W = BODY_RIGHT - BODY_LEFT

# Branding — change in one place
BRAND_NAME = "Your Brand"
FOOTER_TEXT = "PROPRIETARY AND CONFIDENTIAL  |  Your Org  |  2026"


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------
def _kill_outline(shape):
    shape.line.fill.background()


def _solid(shape, color):
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    _kill_outline(shape)


def _outline(shape, color, weight=0.75):
    shape.line.color.rgb = color
    shape.line.width = Pt(weight)


def _add_rect(slide, x, y, w, h, color, *, outline=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    _solid(shape, color)
    if outline is not None:
        _outline(shape, outline)
    return shape


def _add_text(slide, x, y, w, h, text, *, size=12, bold=False, italic=False,
              color=INK, font="Calibri Light", align=PP_ALIGN.LEFT,
              anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    f = run.font
    f.name = font
    f.size = Pt(size)
    f.bold = bold
    f.italic = italic
    f.color.rgb = color
    return tb


# ---------------------------------------------------------------------------
# Branded chrome
# ---------------------------------------------------------------------------
def _brand_sparkle(slide, x, y, size=Inches(0.32), color=WHITE):
    star = slide.shapes.add_shape(MSO_SHAPE.STAR_4_POINT, x, y, size, size)
    _solid(star, color)
    return star


def _content_header(slide, title, *, eyebrow=None):
    """Navy header band + brand mark + slide title."""
    _add_rect(slide, Emu(0), Emu(0), SLIDE_W, HEADER_H, HEADER_NAVY)
    _brand_sparkle(slide, Inches(0.30), Inches(0.21), size=Inches(0.34), color=WHITE)
    _add_text(slide, Inches(0.72), Inches(0.20), Inches(1.6), Inches(0.36),
              BRAND_NAME, size=11, bold=True, color=LIGHT_GRAY,
              anchor=MSO_ANCHOR.MIDDLE)
    _add_text(slide, Inches(2.45), Inches(0.06), Inches(7.2), Inches(0.64),
              title, size=19, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    if eyebrow:
        _add_text(slide, Inches(2.45), Inches(0.45), Inches(7.2), Inches(0.25),
                  eyebrow, size=9.5, italic=True, color=MUTED_DARK)


def _content_footer(slide):
    """Thin navy footer band with proprietary line."""
    _add_rect(slide, Emu(0), FOOTER_Y, SLIDE_W, FOOTER_H, HEADER_NAVY)
    _add_text(slide, Inches(0.2), FOOTER_Y, Inches(9.6), FOOTER_H,
              FOOTER_TEXT, size=7, color=LIGHT_GRAY, font="Calibri",
              anchor=MSO_ANCHOR.MIDDLE)


def _light_canvas(slide):
    _add_rect(slide, Emu(0), Emu(0), SLIDE_W, SLIDE_H, BG_LIGHT)


# ---------------------------------------------------------------------------
# Title-slide chrome
# ---------------------------------------------------------------------------
def _title_canvas(slide):
    _add_rect(slide, Emu(0), Emu(0), SLIDE_W, SLIDE_H, BG_MAIN_DARK)
    _add_rect(slide, PANEL_X, Emu(0), PANEL_W, SLIDE_H, BG_PANEL_DARK)
    _add_rect(slide, PANEL_X, Emu(0), STRIPE_W, SLIDE_H, ACCENT_RED)


def _title_brand(slide, brand=BRAND_NAME):
    _brand_sparkle(slide, Inches(0.45), Inches(0.32), size=Inches(0.32))
    _add_text(slide, Inches(0.85), Inches(0.30), Inches(3.0), Inches(0.4),
              brand, size=15, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)


def _title_panel_header(slide, header):
    _add_text(slide, PANEL_X + Inches(0.2), Inches(0.55), PANEL_W - Inches(0.3),
              Inches(0.36), header, size=13, bold=True, color=LIGHT_GRAY)


def _title_panel_bullet(slide, idx, text):
    y = Inches(1.05) + Inches(0.52) * idx
    _add_rect(slide, PANEL_X + Inches(0.2), y, Emu(36576), Inches(0.32), ACCENT_RED)
    _add_text(slide, PANEL_X + Inches(0.3), y, PANEL_W - Inches(0.45),
              Inches(0.32), text, size=10.5, color=LIGHT_GRAY,
              anchor=MSO_ANCHOR.MIDDLE)


# ---------------------------------------------------------------------------
# Reusable widgets (light theme)
# ---------------------------------------------------------------------------
def _chip(slide, x, y, w, h, label, color, *, size=9, text_color=WHITE):
    _add_rect(slide, x, y, w, h, color)
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = label
    run.font.name = "Calibri Light"
    run.font.size = Pt(size)
    run.font.bold = True
    run.font.color.rgb = text_color


def _light_card(slide, x, y, w, h, accent_color):
    """White card with a colored top stripe + soft border."""
    _add_rect(slide, x, y, w, Inches(0.10), accent_color)
    _add_rect(slide, x, y + Inches(0.10), w, h - Inches(0.10), CARD_BG,
              outline=SOFT_BORDER)


def _bulleted_light(slide, x, y, w, h, bullets, *, size=11, color=INK):
    """Red-square bullets. Each item is a str OR a (bold_head, tail) tuple."""
    row_h = Inches(0.42)
    for i, item in enumerate(bullets):
        yy = y + row_h * i
        _add_rect(slide, x, yy + Inches(0.10), Inches(0.10), Inches(0.10), ACCENT_RED)
        tb = slide.shapes.add_textbox(x + Inches(0.22), yy, w - Inches(0.25), row_h)
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = Emu(0)
        tf.margin_top = tf.margin_bottom = Emu(0)
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.LEFT
        p.line_spacing = 1.2
        if isinstance(item, tuple):
            head, tail = item
            r1 = p.add_run()
            r1.text = f"{head} "
            r1.font.name = "Calibri Light"; r1.font.size = Pt(size); r1.font.bold = True
            r1.font.color.rgb = INK
            r2 = p.add_run()
            r2.text = tail
            r2.font.name = "Calibri Light"; r2.font.size = Pt(size)
            r2.font.color.rgb = color
        else:
            r = p.add_run()
            r.text = item
            r.font.name = "Calibri Light"; r.font.size = Pt(size)
            r.font.color.rgb = color


# ---------------------------------------------------------------------------
# Sample slide builders — customize these for your deck
# ---------------------------------------------------------------------------
def build_title_slide(prs, *, title, subtitle, eyebrow=None,
                      chips=(("Multi-Provider", CHIP_BLUE), ("MCP Native", CHIP_PURPLE),
                             ("Parallel Agents", CHIP_ORANGE), ("Open Source", CHIP_TEAL)),
                      at_a_glance=()):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _title_canvas(slide)
    _title_brand(slide)
    _add_text(slide, Inches(0.5), Inches(1.75), Inches(6.2), Inches(0.7),
              title, size=40, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    _add_text(slide, Inches(0.5), Inches(2.45), Inches(6.2), Inches(0.55),
              subtitle, size=22, color=SOFT_BLUE, anchor=MSO_ANCHOR.MIDDLE)
    if eyebrow:
        _add_text(slide, Inches(0.5), Inches(3.05), Inches(6.2), Inches(0.35),
                  eyebrow, size=13, italic=True, color=MUTED_DARK,
                  anchor=MSO_ANCHOR.MIDDLE)
    if chips:
        chip_y = Inches(3.7); chip_w = Inches(1.45); chip_h = Inches(0.36); gap = Inches(0.16)
        x = Inches(0.5)
        for label, color in chips:
            _chip(slide, x, chip_y, chip_w, chip_h, label, color)
            x += chip_w + gap
    if at_a_glance:
        _title_panel_header(slide, "At a glance")
        for i, line in enumerate(at_a_glance):
            _title_panel_bullet(slide, i, line)
    _add_text(slide, Inches(0.5), Inches(5.1), Inches(6.2), Inches(0.28),
              FOOTER_TEXT, size=9, color=MUTED_DARK)


def build_bullets_slide(prs, *, title, eyebrow, bullets, proof_card=None):
    """Two-column slide: bullets on left, optional proof-points card on right."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _light_canvas(slide)
    _content_header(slide, title, eyebrow=eyebrow)
    left_w = Inches(5.55) if proof_card else BODY_W
    _bulleted_light(slide, BODY_LEFT, BODY_TOP + Inches(0.20), left_w,
                    Inches(3.2), bullets, size=11)
    if proof_card:
        right_x = BODY_LEFT + left_w + Inches(0.30)
        right_w = BODY_RIGHT - right_x
        card_h = Inches(3.15)
        _add_rect(slide, right_x, BODY_TOP + Inches(0.20), right_w, Inches(0.10), CHIP_BLUE)
        _add_rect(slide, right_x, BODY_TOP + Inches(0.30), right_w, card_h - Inches(0.10),
                  CARD_BG, outline=SOFT_BORDER)
        _add_text(slide, right_x + Inches(0.15), BODY_TOP + Inches(0.38),
                  right_w - Inches(0.25), Inches(0.32),
                  proof_card["title"], size=12, bold=True, color=INK)
        py = BODY_TOP + Inches(0.78)
        for i, line in enumerate(proof_card["lines"]):
            yy = py + Inches(0.36) * i
            _add_rect(slide, right_x + Inches(0.18), yy + Inches(0.10),
                      Inches(0.10), Inches(0.10), ACCENT_RED)
            _add_text(slide, right_x + Inches(0.35), yy, right_w - Inches(0.45),
                      Inches(0.32), line, size=10.5, color=INK)
    _content_footer(slide)


def build_grid_slide(prs, *, title, eyebrow, cards, cols=3):
    """N-card grid (1.05" tall per row). Each card: (head, sub, accent_color)."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _light_canvas(slide)
    _content_header(slide, title, eyebrow=eyebrow)
    col_w = (BODY_W - Inches(0.10) * (cols - 1)) / cols
    row_h = Inches(1.05); col_gap = Inches(0.10); row_gap = Inches(0.12)
    grid_y = BODY_TOP + Inches(0.15)
    for i, (head, sub, color) in enumerate(cards):
        col = i % cols; row = i // cols
        x = BODY_LEFT + (col_w + col_gap) * col
        y = grid_y + (row_h + row_gap) * row
        _light_card(slide, x, y, col_w, row_h, color)
        _add_text(slide, x + Inches(0.15), y + Inches(0.20), col_w - Inches(0.25),
                  Inches(0.32), head, size=13, bold=True, color=INK)
        _add_text(slide, x + Inches(0.15), y + Inches(0.55), col_w - Inches(0.25),
                  Inches(0.45), sub, size=10, color=SUBTLE_INK)
    _content_footer(slide)


def build_table_slide(prs, *, title, eyebrow, columns, rows, highlight_col=1):
    """Comparison-table slide. `columns` = headers, `rows` = list of tuples."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _light_canvas(slide)
    _content_header(slide, title, eyebrow=eyebrow)
    n = len(columns)
    col_w = BODY_W / n
    col_widths = [col_w] * n
    table_x = BODY_LEFT
    table_y = BODY_TOP + Inches(0.10)
    header_h = Inches(0.36); row_h = Inches(0.30)
    total_w = sum(col_widths, Emu(0))
    _add_rect(slide, table_x, table_y, total_w, header_h, HEADER_NAVY)
    cx = table_x
    for label, w in zip(columns, col_widths):
        _add_text(slide, cx + Inches(0.06), table_y, w - Inches(0.10),
                  header_h, label, size=10, bold=True, color=WHITE,
                  anchor=MSO_ANCHOR.MIDDLE)
        cx += w
    ry = table_y + header_h
    for i, row in enumerate(rows):
        bg = CARD_BG_ALT if i % 2 == 0 else CARD_BG
        _add_rect(slide, table_x, ry, total_w, row_h, bg)
        cx = table_x
        for j, (cell, w) in enumerate(zip(row, col_widths)):
            color = CHIP_BLUE if j == highlight_col else (INK if j == 0 else SUBTLE_INK)
            bold = (j == highlight_col)
            _add_text(slide, cx + Inches(0.06), ry, w - Inches(0.10), row_h,
                      str(cell), size=9, bold=bold, color=color,
                      anchor=MSO_ANCHOR.MIDDLE)
            cx += w
        ry += row_h
    _content_footer(slide)


def build_closing_slide(prs, *, headline, sub, chips=(), tiles=()):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _light_canvas(slide)
    _content_header(slide, "Wrapping Up", eyebrow="Next steps")
    _add_text(slide, BODY_LEFT, BODY_TOP + Inches(0.25), BODY_W, Inches(0.55),
              headline, size=20, bold=True, color=INK,
              anchor=MSO_ANCHOR.MIDDLE, align=PP_ALIGN.CENTER)
    _add_text(slide, BODY_LEFT, BODY_TOP + Inches(0.85), BODY_W, Inches(0.35),
              sub, size=12, italic=True, color=SUBTLE_INK,
              anchor=MSO_ANCHOR.MIDDLE, align=PP_ALIGN.CENTER)
    if chips:
        chip_w = Inches(1.85); chip_h = Inches(0.45); gap = Inches(0.18)
        total = chip_w * len(chips) + gap * (len(chips) - 1)
        x = (SLIDE_W - total) / 2; y = BODY_TOP + Inches(1.55)
        for label, color in chips:
            _chip(slide, x, y, chip_w, chip_h, label, color, size=11)
            x += chip_w + gap
    if tiles:
        tile_w = Inches(3.00); tile_h = Inches(0.95); tile_gap = Inches(0.10)
        total_tw = tile_w * len(tiles) + tile_gap * (len(tiles) - 1)
        tx = (SLIDE_W - total_tw) / 2; ty = BODY_TOP + Inches(2.30)
        accents = [CHIP_BLUE, CHIP_PURPLE, CHIP_ORANGE, CHIP_TEAL]
        for i, (head, sub_text) in enumerate(tiles):
            _light_card(slide, tx, ty, tile_w, tile_h, accents[i % len(accents)])
            _add_text(slide, tx + Inches(0.15), ty + Inches(0.18),
                      tile_w - Inches(0.25), Inches(0.30),
                      head, size=12, bold=True, color=INK)
            _add_text(slide, tx + Inches(0.15), ty + Inches(0.50),
                      tile_w - Inches(0.25), Inches(0.45),
                      sub_text, size=10, color=SUBTLE_INK)
            tx += tile_w + tile_gap
    _content_footer(slide)


# ---------------------------------------------------------------------------
# Main — example usage
# ---------------------------------------------------------------------------
def main():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    build_title_slide(
        prs,
        title="Your Deck Title",
        subtitle="A Compelling Subtitle Here",
        eyebrow="Audience · Date · Author",
        at_a_glance=[
            "Key fact one",
            "Key fact two",
            "Key fact three",
            "Key fact four",
            "Key fact five",
        ],
    )

    build_bullets_slide(
        prs,
        title="Why It Matters",
        eyebrow="Three sentences on the problem",
        bullets=[
            ("Pain point one.", "Concrete description with numbers."),
            ("Pain point two.", "What breaks today and why."),
            ("Pain point three.", "Why existing solutions don't fit."),
        ],
        proof_card={
            "title": "Proof points",
            "lines": ["10× faster", "50% cheaper", "Zero downtime",
                      "MIT licensed", "Multi-cloud"],
        },
    )

    build_grid_slide(
        prs,
        title="What We Built",
        eyebrow="Six features, three columns",
        cards=[
            ("Feature One", "One-line description", CHIP_BLUE),
            ("Feature Two", "One-line description", CHIP_PURPLE),
            ("Feature Three", "One-line description", CHIP_ORANGE),
            ("Feature Four", "One-line description", CHIP_TEAL),
            ("Feature Five", "One-line description", CHIP_GREEN),
            ("Feature Six", "One-line description", CHIP_INDIGO),
        ],
    )

    build_table_slide(
        prs,
        title="Comparison",
        eyebrow="Us vs. the competition",
        columns=["Capability", "Us", "Comp A", "Comp B"],
        rows=[
            ("Multi-provider", "Yes", "No", "Limited"),
            ("Open source", "MIT", "No", "Yes"),
            ("Self-hosted", "Yes", "No", "Yes"),
        ],
    )

    build_closing_slide(
        prs,
        headline="Your closing one-liner.",
        sub="A brief follow-up sentence.",
        chips=[("Install", CHIP_BLUE), ("Configure", CHIP_PURPLE),
               ("Ship", CHIP_TEAL)],
        tiles=[
            ("Get started", "Install the extension and configure your provider."),
            ("Make it yours", "Drop in MCP servers, write skills, layer memory."),
            ("Trust the loop", "Pick a mode — read-only to fully-autonomous."),
        ],
    )

    out = Path(__file__).parent / "deck.pptx"
    prs.save(out)
    print(f"wrote {out} ({out.stat().st_size:,} bytes, {len(prs.slides)} slides)")


if __name__ == "__main__":
    main()
