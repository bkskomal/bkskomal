# Changelog

## 0.1.0 — 2026-05-20

Initial preview release.

- Configurable agent loop with planner/critic stages
- Parallel sub-agents via the `spawn_agent` tool
- 8 built-in tools: read_file, write_file, list_dir, grep_search, exec, fetch_url, spawn_agent, get_workspace_context
- Provider support: OpenAI direct, OpenAI-compatible gateways, OpenRouter, LiteLLM, unillm, Ollama, Anthropic native
- Full Model Context Protocol (MCP) client with 8 server presets
- Markdown rendering, native VS Code diff editor on write, inline diff in approval dialog
- Token + USD cost tracking
- Session persistence + export/import
- API keys stored in VS Code SecretStorage
