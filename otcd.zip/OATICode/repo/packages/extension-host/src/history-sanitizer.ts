// 2026-05-27: Session history sanitizer. The wrapped-args bug in earlier
// versions could write malformed tool_call / tool_result entries into
// history (e.g. `path: "execute_security_tests.py\",\"content\":\"..."`).
// Once those land in saved history, every subsequent agent turn reads
// them back from disk on session restore — and the model chokes on the
// confusing blob, returning empty responses on even trivial prompts
// like "Hi".
//
// This module scans a history snapshot and replaces obviously-corrupt
// tool entries with sanitized placeholders, returning both the cleaned
// history and a count of what was repaired. Idempotent: re-running on
// already-clean history returns it unchanged with `repaired: 0`.

import type { ConversationMessage } from "@oati/shared";

export interface SanitizeResult {
	readonly history: readonly ConversationMessage[];
	readonly repaired: number;
	readonly notes: readonly string[];
}

const MAX_REASONABLE_PATH_LEN = 256;
const MAX_REASONABLE_COMMAND_LEN = 8192;

// Signatures of a wrapped-args contamination: a string value containing the
// JSON boundary marker for what should be a SIBLING field. These are the
// patterns the field-contamination check catches in tryRecoverWrappedArgs.
const CONTAMINATION_RE = /["\\]?,\s*["\\]?(content|command|text|body)["\\]?\s*:/i;

// 2026-05-29: fields whose values can legitimately contain JSON-shaped
// literals (config files, code, prose, markdown documents that quote JSON
// in their bodies). Running CONTAMINATION_RE against these field values
// false-positives constantly: a tailwind.config.js with `"content": ["..."]`
// inside its source text trips the pattern even though nothing was wrapped
// or mis-encoded. The Heuristic-3 check skips these field names; the path/
// command guards above (length-based) still catch the genuinely-wrapped
// shape because those fields stay short under normal use.
const CONTAMINATION_EXEMPT_FIELDS = new Set([
	"content",
	"body",
	"text",
	"source",
	"code",
	"value",
	"message",
	"note",
	"description",
]);

function isCorruptArgs(args: unknown): boolean {
	if (!args || typeof args !== "object" || Array.isArray(args)) return false;
	const obj = args as Record<string, unknown>;
	for (const [key, val] of Object.entries(obj)) {
		if (typeof val !== "string") continue;
		// Heuristic 1: unusually long path-like fields are a strong signal
		// the value absorbed neighboring fields. Real file paths almost
		// never exceed 256 characters.
		if (
			(key === "path" || key === "filePath" || key === "file") &&
			val.length > MAX_REASONABLE_PATH_LEN
		) {
			return true;
		}
		// Heuristic 2: commands containing literal `","content":"` patterns.
		// Cross-tool contamination signature.
		if (key === "command" && val.length > MAX_REASONABLE_COMMAND_LEN) {
			return true;
		}
		// Heuristic 3: JSON-boundary syntax for known sibling field names —
		// strong signal of wrapped-args leakage WHEN the field holding it
		// shouldn't carry arbitrary JSON-shaped text. Content/body/source
		// fields legitimately do, so they're exempt from this check.
		if (CONTAMINATION_EXEMPT_FIELDS.has(key.toLowerCase())) continue;
		if (CONTAMINATION_RE.test(val)) {
			return true;
		}
	}
	return false;
}

function isCorruptOutput(output: unknown): boolean {
	if (output === null || output === undefined) return false;
	// If it's a string, check length + contamination signature.
	if (typeof output === "string") {
		return output.length > 4096 && CONTAMINATION_RE.test(output);
	}
	// If it's a structured object (e.g. {error: "...", path: "..."}), check
	// the same paths an isCorruptArgs would.
	if (typeof output === "object" && !Array.isArray(output)) {
		return isCorruptArgs(output);
	}
	return false;
}

export function sanitizeHistory(history: readonly ConversationMessage[]): SanitizeResult {
	let repaired = 0;
	const notes: string[] = [];
	const cleaned: ConversationMessage[] = [];

	for (const msg of history) {
		const newParts = msg.parts.map((part) => {
			if (part.kind === "tool_call") {
				if (isCorruptArgs(part.args)) {
					repaired++;
					const argPreview =
						typeof part.args === "object" && part.args !== null
							? Object.keys(part.args as object).join(",")
							: typeof part.args;
					notes.push(
						`tool_call ${part.name} (id=${part.id.slice(0, 8)}): corrupt args fields=${argPreview} — replaced with placeholder`,
					);
					return {
						...part,
						args: {
							_oatiSanitized: true,
							_originalTool: part.name,
							_note:
								"Args from this call were corrupted (wrapped-args / field-contamination). Ignore this entry — the model should re-issue the intent in a fresh call if the work is still needed.",
						},
					};
				}
				return part;
			}
			if (part.kind === "tool_result") {
				if (isCorruptOutput(part.output)) {
					repaired++;
					notes.push(
						`tool_result (id=${part.id.slice(0, 8)}): corrupt output — replaced with placeholder`,
					);
					return {
						...part,
						isError: true,
						output: {
							_oatiSanitized: true,
							_note:
								"This tool_result was sanitized because its content showed wrapped-args contamination. The original work, if any, did not complete cleanly.",
						},
					};
				}
				return part;
			}
			return part;
		});
		cleaned.push({ ...msg, parts: newParts });
	}

	return {
		history: cleaned,
		repaired,
		notes,
	};
}

/**
 * Summary line for the chat-panel to surface when sanitation runs.
 * Returns `undefined` when nothing was repaired so the caller can just
 * `if (note) emitNote(note)`.
 */
export function formatSanitizeNote(result: SanitizeResult): string | undefined {
	if (result.repaired === 0) return undefined;
	const head = `[History recovery] OATI sanitized ${result.repaired} corrupt tool ${result.repaired === 1 ? "entry" : "entries"} from this session's saved history. The model should now respond normally. If issues persist, click + New Session.`;
	const detail = result.notes
		.slice(0, 6)
		.map((n) => `  - ${n}`)
		.join("\n");
	const more = result.notes.length > 6 ? `\n  (+${result.notes.length - 6} more)` : "";
	return `${head}\n${detail}${more}`;
}
