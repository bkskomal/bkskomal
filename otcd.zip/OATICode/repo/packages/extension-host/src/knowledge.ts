// R5-B: Knowledge base — markdown documents under `<workspace>/.oati/knowledge/`
// indexed using the same chunker + embedder + sqlite store as the codebase
// index, but in a SEPARATE namespace (knowledge.sqlite) so semantic code
// search and knowledge search never pollute each other.
import { promises as fs } from "node:fs";
import * as path from "node:path";
import { CodebaseIndex, type SearchResult, TfIdfEmbedder } from "@oati/codebase-index";
import * as vscode from "vscode";

/** Relative directory under the workspace root that holds knowledge docs. */
export const KNOWLEDGE_RELATIVE_DIR = ".oati/knowledge";

/** Filename of the knowledge namespace's sqlite store. */
export const KNOWLEDGE_DB_FILENAME = "knowledge.sqlite";

/** Public shape of a knowledge search hit. */
export interface KnowledgeHit {
	readonly path: string;
	readonly snippet: string;
	readonly score: number;
}

export interface KnowledgeStoreOptions {
	readonly workspaceRoot: string;
	/**
	 * Optional override for the sqlite path; defaults to
	 * `<workspaceRoot>/.oati/<KNOWLEDGE_DB_FILENAME>`. Tests pass `:memory:`.
	 */
	readonly dbPath?: string;
	/** Optional logger so reindex progress shows up in the OATI output channel. */
	readonly log?: (msg: string) => void;
}

/**
 * KnowledgeStore — owns one CodebaseIndex pointed at `.oati/knowledge/**\/*.md`
 * with its own sqlite file. Constructing the store is cheap; the underlying
 * sqlite DB is opened lazily on the first `rebuild()` / `search()` call so
 * activation cost stays low.
 *
 * `rebuild()` walks the knowledge dir from scratch (vs. the codebase index's
 * gitignore-aware workspace walker) so we always pick up nested folders and
 * never have to reason about `.gitignore` interactions. File-system changes
 * inside the dir are reflected automatically via a VS Code watcher set up by
 * `attachWatcher()`; callers in non-VS Code hosts can skip the watcher.
 */
export class KnowledgeStore {
	private index: CodebaseIndex | undefined;
	private readonly workspaceRoot: string;
	private readonly dbPath: string;
	private readonly log: ((msg: string) => void) | undefined;
	private rebuilding = false;
	private rebuildQueued = false;
	private watcher: vscode.FileSystemWatcher | undefined;
	private docCount = 0;

	constructor(opts: KnowledgeStoreOptions) {
		this.workspaceRoot = opts.workspaceRoot;
		this.dbPath = opts.dbPath ?? path.join(opts.workspaceRoot, ".oati", KNOWLEDGE_DB_FILENAME);
		this.log = opts.log;
	}

	/** Number of distinct knowledge docs currently indexed. */
	docs(): number {
		return this.docCount;
	}

	/**
	 * Semantic search over the knowledge namespace. Returns `[]` until the
	 * first `rebuild()` finishes (so a cold panel doesn't accidentally inject
	 * noise into the system prompt).
	 */
	async search(query: string, k = 4): Promise<readonly KnowledgeHit[]> {
		if (!query.trim() || !this.index) return [];
		let results: SearchResult[] = [];
		try {
			results = await this.index.query(query, { k });
		} catch (err) {
			this.log?.(`[knowledge] search failed: ${err instanceof Error ? err.message : String(err)}`);
			return [];
		}
		return results.map((r) => ({
			path: r.filePath,
			snippet: r.content,
			score: r.score,
		}));
	}

	/**
	 * Walk `.oati/knowledge/` from scratch, chunk + embed every markdown file,
	 * and prune entries for deleted files. Concurrent calls collapse to a
	 * single in-flight rebuild plus at most one queued follow-up so a burst of
	 * file-watcher events doesn't fan out into N rebuilds.
	 */
	async rebuild(): Promise<{ docs: number; chunks: number }> {
		if (this.rebuilding) {
			this.rebuildQueued = true;
			return { docs: this.docCount, chunks: 0 };
		}
		this.rebuilding = true;
		try {
			const idx = this.ensureIndex();
			const docs = await collectKnowledgeFiles(this.workspaceRoot);
			this.docCount = docs.length;
			const seen = new Set<string>();
			for (const abs of docs) {
				const rel = path.relative(this.workspaceRoot, abs).replace(/\\/g, "/");
				seen.add(rel);
				try {
					await idx.indexFile(abs);
				} catch (err) {
					this.log?.(
						`[knowledge] indexFile failed for ${rel}: ${err instanceof Error ? err.message : String(err)}`,
					);
				}
			}
			// Prune deletions. `listFiles()` returns whatever's stored, so any
			// path we didn't just visit is stale.
			for (const stored of idx.listFiles()) {
				if (!seen.has(stored)) {
					try {
						await idx.invalidate(stored);
					} catch {
						/* best-effort */
					}
				}
			}
			const stats = idx.stats();
			this.log?.(`[knowledge] rebuild done: docs=${this.docCount}, chunks=${stats.chunks}`);
			return { docs: this.docCount, chunks: stats.chunks };
		} finally {
			this.rebuilding = false;
			if (this.rebuildQueued) {
				this.rebuildQueued = false;
				// Drop the await so the queued rebuild runs after the current
				// caller's Promise resolves — keeps the API predictable.
				void this.rebuild();
			}
		}
	}

	/**
	 * Set up a VS Code FileSystemWatcher over `.oati/knowledge/**\/*.md` that
	 * triggers a debounced rebuild. Returns the disposable so the host can
	 * tear it down on extension deactivate. Safe to call multiple times — the
	 * second call disposes the previous watcher first.
	 */
	attachWatcher(onChanged?: () => void): vscode.Disposable {
		this.detachWatcher();
		const pattern = new vscode.RelativePattern(this.workspaceRoot, ".oati/knowledge/**/*.md");
		const watcher = vscode.workspace.createFileSystemWatcher(pattern);
		this.watcher = watcher;
		let timer: NodeJS.Timeout | undefined;
		const schedule = () => {
			if (timer) clearTimeout(timer);
			timer = setTimeout(() => {
				void this.rebuild().then(() => onChanged?.());
			}, 500);
		};
		watcher.onDidChange(schedule);
		watcher.onDidCreate(schedule);
		watcher.onDidDelete(schedule);
		return {
			dispose: () => {
				if (timer) clearTimeout(timer);
				this.detachWatcher();
			},
		};
	}

	dispose(): void {
		this.detachWatcher();
		this.index?.close();
		this.index = undefined;
	}

	private detachWatcher(): void {
		this.watcher?.dispose();
		this.watcher = undefined;
	}

	private ensureIndex(): CodebaseIndex {
		if (this.index) return this.index;
		// Reuse the same TfIdfEmbedder defaults the codebase index uses so we
		// don't need provider wiring for knowledge to work offline.
		this.index = new CodebaseIndex({
			workspaceRoot: this.workspaceRoot,
			dbPath: this.dbPath,
			embedder: new TfIdfEmbedder(),
		});
		return this.index;
	}
}

/** Recursive walker over `<workspace>/.oati/knowledge/**\/*.md`. Absolute paths. */
async function collectKnowledgeFiles(workspaceRoot: string): Promise<string[]> {
	const root = path.join(workspaceRoot, KNOWLEDGE_RELATIVE_DIR);
	const out: string[] = [];
	async function walk(dir: string): Promise<void> {
		let entries: import("node:fs").Dirent[];
		try {
			entries = await fs.readdir(dir, { withFileTypes: true });
		} catch {
			return;
		}
		for (const entry of entries) {
			const abs = path.join(dir, entry.name);
			if (entry.isDirectory()) {
				await walk(abs);
			} else if (entry.isFile() && entry.name.toLowerCase().endsWith(".md")) {
				out.push(abs);
			}
		}
	}
	await walk(root);
	out.sort();
	return out;
}

/** Helper for tools / panels — list all knowledge docs as `{path, title, updatedAt}`. */
export async function listKnowledgeDocs(
	workspaceRoot: string,
): Promise<readonly { path: string; title: string; updatedAt: string }[]> {
	if (!workspaceRoot) return [];
	const abs = await collectKnowledgeFiles(workspaceRoot);
	const out: { path: string; title: string; updatedAt: string }[] = [];
	for (const file of abs) {
		const rel = path.relative(workspaceRoot, file).replace(/\\/g, "/");
		let title = path.basename(file, ".md");
		let updatedAt = new Date(0).toISOString();
		try {
			const raw = await fs.readFile(file, "utf-8");
			const m = /^#\s+(.+?)\s*$/m.exec(raw);
			if (m) title = m[1];
		} catch {
			/* keep filename-derived title */
		}
		try {
			const stat = await fs.stat(file);
			updatedAt = stat.mtime.toISOString();
		} catch {
			/* keep epoch */
		}
		out.push({ path: rel, title, updatedAt });
	}
	return out;
}
