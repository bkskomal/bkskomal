// R5-B: AI rules — global + per-language markdown rules loaded from
// `<workspace>/.oati/rules.md` (always injected) and
// `<workspace>/.oati/rules.<lang>.md` (injected when the active language hint
// matches). Both files are optional; missing files contribute the empty string.
import { promises as fs } from "node:fs";
import * as path from "node:path";

/** Relative directory under the workspace root that contains rules files. */
export const RULES_RELATIVE_DIR = ".oati";

/** Language hints we recognize for `rules.<lang>.md` lookups. */
export const KNOWN_RULE_LANGUAGES = [
	"typescript",
	"javascript",
	"tsx",
	"jsx",
	"python",
	"go",
	"rust",
	"java",
	"kotlin",
	"csharp",
	"cpp",
	"c",
	"ruby",
	"php",
	"swift",
	"scala",
	"lua",
	"shell",
	"bash",
	"html",
	"css",
	"scss",
	"sql",
	"markdown",
	"yaml",
	"json",
] as const;

export interface LoadedRules {
	readonly global: string;
	readonly perLanguage: Readonly<Record<string, string>>;
}

/** Slug regex for language hints — prevents `rules.../etc/passwd.md` lookups. */
const LANG_SLUG = /^[a-z0-9_-]+$/;

/**
 * Load all rules markdown files from `<workspaceRoot>/.oati/`. The global
 * `rules.md` is always read; per-language `rules.<lang>.md` files are read for
 * every known language hint (plus any directly observed `rules.<slug>.md`
 * in the directory). Missing or unreadable files contribute empty strings.
 */
export async function loadRules(workspaceRoot: string): Promise<LoadedRules> {
	const empty: LoadedRules = { global: "", perLanguage: {} };
	if (!workspaceRoot) return empty;
	const dir = path.join(workspaceRoot, RULES_RELATIVE_DIR);

	// Global rules.md.
	const global = await readFileSafe(path.join(dir, "rules.md"));

	// Discover any `rules.<lang>.md` files that exist in the directory so users
	// can add language buckets we don't know about yet, then merge in the
	// canonical KNOWN_RULE_LANGUAGES list so callers don't have to filter.
	const observed = new Set<string>();
	try {
		const entries = await fs.readdir(dir);
		for (const entry of entries) {
			const m = /^rules\.([a-zA-Z0-9_-]+)\.md$/i.exec(entry);
			if (m) observed.add(m[1].toLowerCase());
		}
	} catch {
		// Missing `.oati` dir — only the empty global remains.
	}
	for (const lang of KNOWN_RULE_LANGUAGES) observed.add(lang);

	const perLanguage: Record<string, string> = {};
	for (const lang of observed) {
		if (!LANG_SLUG.test(lang)) continue;
		const body = await readFileSafe(path.join(dir, `rules.${lang}.md`));
		if (body) perLanguage[lang] = body;
	}

	return { global, perLanguage };
}

/**
 * Build a system-prompt snippet from the loaded rules. Always includes the
 * global block when present; appends a language-specific block when
 * `activeLanguage` matches a key in `perLanguage`. Returns the empty string
 * when nothing applies so the caller can skip prepending entirely.
 */
export function assembleRulesPrelude(rules: LoadedRules, activeLanguage?: string): string {
	const sections: string[] = [];
	const global = rules.global.trim();
	if (global.length > 0) {
		sections.push(`=== Project Rules ===\n${global}`);
	}
	const lang = activeLanguage?.toLowerCase();
	if (lang) {
		const langBody = rules.perLanguage[lang];
		if (langBody && langBody.trim().length > 0) {
			sections.push(`=== ${lang} Rules ===\n${langBody.trim()}`);
		}
	}
	return sections.join("\n\n");
}

/** Cheap check used by the host indicator — true iff `rules.md` exists. */
export async function hasGlobalRules(workspaceRoot: string): Promise<boolean> {
	if (!workspaceRoot) return false;
	const abs = path.join(workspaceRoot, RULES_RELATIVE_DIR, "rules.md");
	try {
		const stat = await fs.stat(abs);
		return stat.isFile();
	} catch {
		return false;
	}
}

async function readFileSafe(abs: string): Promise<string> {
	try {
		return await fs.readFile(abs, "utf-8");
	} catch {
		return "";
	}
}
