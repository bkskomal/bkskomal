// 2026-05-28: /qa execute — read a TEST_PLAN_*.xlsx, run each test case
// via the graduated execution router, write Status / Actual / Tester /
// Date columns back to the SAME workbook. Preserves every other column
// the user has on the file.
//
// Router strategy (in order of preference):
//
//   1. UNIT — the case names a concrete file + function, or testData
//      mentions a function call. Run via the workspace's detected test
//      framework (vitest / jest / pytest / …), parse the runner's
//      pass/fail output.
//
//   2. UI — steps mention a URL, the URL is localhost, and the test
//      name doesn't match a destructive keyword. Caller hands off to
//      computer-use (the agent loop) with a tight prompt that bounds the
//      run to the specified URL.
//
//   3. ASK_USER — anything else. Surface the test in chat with
//      Pass / Fail / Blocked / Skip buttons via the existing ask_user
//      capability. Most "manual" functional tests land here.
//
// Side-effect guards block step 2 outright for destructive test names
// (delete / drop / purge / destroy / wipe / reset / truncate) — the
// classifier downgrades them to ASK_USER so the user is in the loop.

import * as path from "node:path";
import ExcelJS from "exceljs";
import type { FunctionalConcept, ResolvedSchema, UnitConcept } from "./qa-excel";
import { defaultSchema, readTemplateSchema } from "./qa-excel";

export type ExecutionRoute = "unit" | "ui" | "ask_user" | "blocked";

export interface TestCaseRow {
	readonly rowNumber: number; // 1-based row index in the worksheet
	readonly tcId: string;
	readonly title: string;
	readonly file?: string;
	readonly function?: string;
	readonly steps?: string;
	readonly expected?: string;
	readonly testData?: string;
	readonly status?: string;
}

export type TestStatus = "Pass" | "Fail" | "Blocked" | "Skipped";

export interface ExecutionResult {
	readonly rowNumber: number;
	readonly tcId: string;
	readonly route: ExecutionRoute;
	readonly status: TestStatus;
	readonly actual: string;
	readonly notes?: string;
}

/**
 * Destructive-name detector. If the title or function name matches any
 * of these (case-insensitive, word-boundary check), the test is downgraded
 * to ASK_USER even if it would otherwise route to UI or UNIT — protects
 * against an "execute" run silently dropping a production database.
 */
const DESTRUCTIVE_KEYWORDS = [
	"delete",
	"drop",
	"purge",
	"destroy",
	"wipe",
	"reset",
	"truncate",
	"erase",
	"remove all",
];

export function hasDestructiveIntent(text: string | undefined): boolean {
	if (!text) return false;
	const lower = text.toLowerCase();
	for (const kw of DESTRUCTIVE_KEYWORDS) {
		// Word-boundary match so "completed" doesn't trigger "delete".
		const pattern = new RegExp(`\\b${kw.replace(/\s+/g, "\\s+")}\\b`, "i");
		if (pattern.test(lower)) return true;
	}
	return false;
}

/**
 * Match localhost URLs in the steps text. Matches http://localhost,
 * http://127.0.0.1, http://0.0.0.0, with optional port.
 */
const LOCALHOST_URL = /https?:\/\/(?:localhost|127\.0\.0\.1|0\.0\.0\.0)(?::\d+)?(?:\/\S*)?/i;
const NON_LOCAL_URL = /https?:\/\/(?!localhost|127\.0\.0\.1|0\.0\.0\.0)[\w.-]+(?::\d+)?/i;

/**
 * Classify a test case into one of the three execution routes. Pure
 * function for testability — no side effects, no I/O.
 */
export function classifyTestCase(row: TestCaseRow): ExecutionRoute {
	// Safety first. Destructive intent in title, function name, or steps?
	if (
		hasDestructiveIntent(row.title) ||
		hasDestructiveIntent(row.function) ||
		hasDestructiveIntent(row.steps)
	) {
		return "ask_user";
	}

	// Unit route: concrete file + function reference is the strongest signal.
	const hasFunction =
		typeof row.function === "string" &&
		row.function.trim().length > 0 &&
		row.function.trim().toLowerCase() !== "none";
	const hasFile = typeof row.file === "string" && row.file.trim().length > 0;
	if (hasFunction && hasFile) {
		return "unit";
	}

	// UI route: steps mention a localhost URL (and NOT a non-localhost URL,
	// which would imply prod / staging — the safety guard demands localhost
	// only at this layer).
	if (row.steps && LOCALHOST_URL.test(row.steps) && !NON_LOCAL_URL.test(row.steps)) {
		return "ui";
	}

	// Anything we can't confidently route → hand to the user.
	return "ask_user";
}

// ---------------------------------------------------------------------------
// Excel read / write
// ---------------------------------------------------------------------------

export interface LoadedPlan {
	readonly schema: ResolvedSchema;
	readonly kind: "functional" | "unit";
	readonly rows: readonly TestCaseRow[];
	/** The exceljs workbook — held by the caller for the write phase. */
	readonly workbook: ExcelJS.Workbook;
	readonly worksheet: ExcelJS.Worksheet;
}

/**
 * Open a test-plan workbook, detect its schema, and pull every row below
 * the header into TestCaseRow form. Kind ("functional" | "unit") is
 * detected from the file name; if ambiguous, we try both schemas and pick
 * whichever resolves more concepts.
 */
export async function loadPlanWorkbook(absPath: string): Promise<LoadedPlan> {
	const wb = new ExcelJS.Workbook();
	await wb.xlsx.readFile(absPath);
	const ws = wb.worksheets.find((w) => (w.rowCount ?? 0) > 0);
	if (!ws) {
		throw new Error(`workbook at ${absPath} has no non-empty worksheet`);
	}

	// Heuristic kind detection from filename. The schema read does the
	// actual concept mapping; this just selects synonym dictionary.
	const lower = path.basename(absPath).toLowerCase();
	const guessedKind: "functional" | "unit" = lower.includes("unit") ? "unit" : "functional";

	// Try the guess first; if header detection fails, fall back to default.
	const schema = (await readTemplateSchema(absPath, guessedKind)) ?? defaultSchema(guessedKind);

	const rows: TestCaseRow[] = [];
	const headerRow = schema.headerRowIndex;
	const lastRow = ws.rowCount;
	for (let r = headerRow + 1; r <= lastRow; r++) {
		const row = ws.getRow(r);
		// Skip blank rows (no cell with any value).
		let hasValue = false;
		row.eachCell({ includeEmpty: false }, () => {
			hasValue = true;
		});
		if (!hasValue) continue;

		rows.push({
			rowNumber: r,
			tcId: readCell(row, schema, "tcId") || `Row ${r}`,
			title: readCell(row, schema, "title"),
			...(readCell(row, schema, "file") ? { file: readCell(row, schema, "file") } : {}),
			...(readCell(row, schema, "function") ? { function: readCell(row, schema, "function") } : {}),
			...(readCell(row, schema, "steps") ? { steps: readCell(row, schema, "steps") } : {}),
			...(readCell(row, schema, "expected") ? { expected: readCell(row, schema, "expected") } : {}),
			...(readCell(row, schema, "testData") ? { testData: readCell(row, schema, "testData") } : {}),
			status: readCell(row, schema, "status"),
		});
	}

	return { schema, kind: guessedKind, rows, workbook: wb, worksheet: ws };
}

function readCell(
	row: ExcelJS.Row,
	schema: ResolvedSchema,
	concept: FunctionalConcept | UnitConcept,
): string {
	const colIdx = schema.columnByConcept[concept];
	if (!colIdx) return "";
	const cell = row.getCell(colIdx);
	const v = cell.value;
	if (v === null || v === undefined) return "";
	if (typeof v === "string") return v;
	if (typeof v === "number" || typeof v === "boolean") return String(v);
	if (v instanceof Date) return v.toISOString();
	if (typeof v === "object" && "text" in v && typeof v.text === "string") return v.text;
	if (typeof v === "object" && "result" in v) return String(v.result ?? "");
	return String(v);
}

/**
 * Apply execution results to the workbook. Updates Status, Actual,
 * Tester, Date for functional plans; Status, Actual, Notes for unit
 * plans. Other columns left untouched.
 */
export async function writeResultsBack(opts: {
	readonly workbook: ExcelJS.Workbook;
	readonly worksheet: ExcelJS.Worksheet;
	readonly schema: ResolvedSchema;
	readonly results: readonly ExecutionResult[];
	readonly tester: string;
	readonly absPath: string;
	readonly executedAt: Date;
}): Promise<void> {
	const dateStr = opts.executedAt.toISOString().slice(0, 10);
	for (const r of opts.results) {
		const row = opts.worksheet.getRow(r.rowNumber);
		const statusCol = opts.schema.columnByConcept.status;
		const actualCol = opts.schema.columnByConcept.actual;
		const testerCol = opts.schema.columnByConcept.tester;
		const dateCol = opts.schema.columnByConcept.date;
		const notesCol = opts.schema.columnByConcept.notes;

		if (statusCol) row.getCell(statusCol).value = r.status;
		if (actualCol) row.getCell(actualCol).value = r.actual;
		if (testerCol) row.getCell(testerCol).value = opts.tester;
		if (dateCol) row.getCell(dateCol).value = dateStr;
		if (notesCol && r.notes) row.getCell(notesCol).value = r.notes;

		// Cell tint for quick visual scan. Green/red/amber/grey.
		const color =
			r.status === "Pass"
				? "FF22863A"
				: r.status === "Fail"
					? "FFD73A49"
					: r.status === "Blocked"
						? "FFB08800"
						: "FF6A737D";
		if (statusCol) {
			row.getCell(statusCol).font = { color: { argb: "FFFFFFFF" }, bold: true };
			row.getCell(statusCol).fill = {
				type: "pattern",
				pattern: "solid",
				fgColor: { argb: color },
			};
		}
		row.commit();
	}
	opts.workbook.modified = opts.executedAt;
	await opts.workbook.xlsx.writeFile(opts.absPath);
}

// ---------------------------------------------------------------------------
// Result roll-up for chat summary
// ---------------------------------------------------------------------------

export interface ExecutionSummary {
	readonly total: number;
	readonly pass: number;
	readonly fail: number;
	readonly blocked: number;
	readonly skipped: number;
	readonly byRoute: Readonly<Record<ExecutionRoute, number>>;
}

export function summarize(results: readonly ExecutionResult[]): ExecutionSummary {
	let pass = 0;
	let fail = 0;
	let blocked = 0;
	let skipped = 0;
	const byRoute: Record<ExecutionRoute, number> = {
		unit: 0,
		ui: 0,
		ask_user: 0,
		blocked: 0,
	};
	for (const r of results) {
		byRoute[r.route]++;
		if (r.status === "Pass") pass++;
		else if (r.status === "Fail") fail++;
		else if (r.status === "Blocked") blocked++;
		else skipped++;
	}
	return { total: results.length, pass, fail, blocked, skipped, byRoute };
}

export function formatExecutionSummary(summary: ExecutionSummary, planPath: string): string {
	const passRate = summary.total === 0 ? 0 : Math.round((summary.pass / summary.total) * 100);
	const lines: string[] = [];
	lines.push(`## /qa execute — ${planPath}`);
	lines.push("");
	lines.push(
		`**Pass rate:** ${passRate}%  ·  ✅ ${summary.pass} pass  ·  ❌ ${summary.fail} fail  ·  ⏸ ${summary.blocked} blocked  ·  ⏭ ${summary.skipped} skipped`,
	);
	lines.push("");
	lines.push(
		`**Routing:**  unit ${summary.byRoute.unit}  ·  UI ${summary.byRoute.ui}  ·  ask-user ${summary.byRoute.ask_user}`,
	);
	return lines.join("\n");
}
