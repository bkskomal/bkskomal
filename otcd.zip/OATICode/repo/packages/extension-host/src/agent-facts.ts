import { promises as fs } from "node:fs";
import * as path from "node:path";

/**
 * A single persistent fact the agent has learned about the project. Loaded
 * from `<workspace>/.oati/facts.json` and surfaced in the system prompt on
 * every turn so the model carries knowledge across sessions.
 */
export interface Fact {
	readonly id: string;
	readonly fact: string;
	/** ISO 8601 timestamp. */
	readonly addedAt: string;
	/** Free-form tag describing where the fact came from (e.g. "agent", "user"). */
	readonly source: string;
}

/** Relative path (under workspace root) of the persistent facts store. */
export const FACTS_RELATIVE_PATH = ".oati/facts.json";

/** Hard cap to prevent the file from growing unbounded. */
export const FACTS_MAX_COUNT = 500;

/**
 * Load all persistent facts for the workspace. Missing file or unreadable /
 * corrupt JSON returns an empty array — callers should treat absence as
 * "no facts" rather than as an error.
 */
export async function loadFacts(workspaceRoot: string): Promise<readonly Fact[]> {
	if (!workspaceRoot) return [];
	const abs = path.join(workspaceRoot, FACTS_RELATIVE_PATH);
	let raw: string;
	try {
		raw = await fs.readFile(abs, "utf-8");
	} catch {
		return [];
	}
	try {
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		const out: Fact[] = [];
		for (const item of parsed) {
			if (!item || typeof item !== "object") continue;
			const f = item as Partial<Fact>;
			if (typeof f.fact !== "string" || f.fact.length === 0) continue;
			out.push({
				id: typeof f.id === "string" && f.id.length > 0 ? f.id : generateId(),
				fact: f.fact,
				addedAt: typeof f.addedAt === "string" ? f.addedAt : new Date().toISOString(),
				source: typeof f.source === "string" ? f.source : "agent",
			});
		}
		return out;
	} catch {
		return [];
	}
}

/**
 * Append a single fact. Idempotent: if a fact with the same text (case-
 * insensitive, whitespace-trimmed) already exists, this is a no-op and
 * returns the existing list unchanged.
 *
 * `addFact` is responsible for creating `.oati/` if it doesn't exist yet so
 * the agent doesn't have to set the directory up manually before its first
 * `remember_fact` call.
 */
export interface AddFactInput {
	readonly fact: string;
	readonly source?: string;
	readonly id?: string;
	readonly addedAt?: string;
}

export async function addFact(workspaceRoot: string, fact: AddFactInput): Promise<readonly Fact[]> {
	if (!workspaceRoot) throw new Error("addFact: workspaceRoot is required");
	const existing = await loadFacts(workspaceRoot);
	const normalized = normalize(fact.fact);
	if (!normalized) return existing;
	if (existing.some((f) => normalize(f.fact) === normalized)) {
		return existing;
	}
	const entry: Fact = {
		id: fact.id ?? generateId(),
		fact: fact.fact.trim(),
		addedAt: fact.addedAt ?? new Date().toISOString(),
		source: fact.source ?? "agent",
	};
	const next = [...existing, entry];
	// Hard cap: oldest entries fall off first.
	const capped = next.length > FACTS_MAX_COUNT ? next.slice(next.length - FACTS_MAX_COUNT) : next;
	await persist(workspaceRoot, capped);
	return capped;
}

/**
 * 2026-05-29: drop a fact by id. Returns the new fact list (empty array
 * when nothing matched). Used by `/memory forget <id>` and `/memory prune`.
 */
export async function removeFact(workspaceRoot: string, id: string): Promise<readonly Fact[]> {
	if (!workspaceRoot) throw new Error("removeFact: workspaceRoot is required");
	const existing = await loadFacts(workspaceRoot);
	const filtered = existing.filter((f) => f.id !== id);
	if (filtered.length === existing.length) return existing; // no-op
	await persist(workspaceRoot, filtered);
	return filtered;
}

/**
 * 2026-05-29: drop every fact older than `olderThanDays` (default 90).
 * Useful for `/memory prune` when the facts.json grows stale.
 */
export async function pruneOldFacts(
	workspaceRoot: string,
	olderThanDays = 90,
): Promise<{ kept: readonly Fact[]; removed: number }> {
	if (!workspaceRoot) throw new Error("pruneOldFacts: workspaceRoot is required");
	const existing = await loadFacts(workspaceRoot);
	const cutoff = Date.now() - olderThanDays * 24 * 60 * 60 * 1000;
	const kept = existing.filter((f) => {
		const t = Date.parse(f.addedAt);
		return Number.isFinite(t) ? t >= cutoff : true; // keep entries with unparseable dates
	});
	if (kept.length === existing.length) return { kept, removed: 0 };
	await persist(workspaceRoot, kept);
	return { kept, removed: existing.length - kept.length };
}

async function persist(workspaceRoot: string, facts: readonly Fact[]): Promise<void> {
	const abs = path.join(workspaceRoot, FACTS_RELATIVE_PATH);
	await fs.mkdir(path.dirname(abs), { recursive: true });
	await fs.writeFile(abs, `${JSON.stringify(facts, null, 2)}\n`, "utf-8");
}

function normalize(s: string): string {
	return s.replace(/\s+/g, " ").trim().toLowerCase();
}

let counter = 0;
function generateId(): string {
	counter = (counter + 1) % 1_000_000;
	return `f_${Date.now().toString(36)}_${counter.toString(36)}`;
}
