// R6-C: PR-on-open auto review.
//
// Polls `gh pr list` on an interval and fires a listener whenever a new PR
// shows up since the previous poll, skipping PRs the current user authored.
// The extension subscribes and feeds new PRs through R3-C's
// `reviewPullRequest(...)` to produce a code-review summary, optionally
// posting it as a comment.
//
// The polling cadence and the auto-comment switch are read off VS Code
// settings (see `package.json` contributions); watcher creation only
// actually starts a timer when `oati.prWatch.enabled === true`. Defaults are
// conservative: polling off, no auto-commenting.

import type { ExecResult, HostContext } from "@oati/shared";

/** Shape of a single PR row as returned by `gh pr list --json …`. */
export interface PrSummary {
	readonly number: number;
	readonly headRefName: string;
	readonly createdAt: string;
	readonly author: { readonly login: string };
	readonly title?: string;
	readonly url?: string;
}

/** Minimal subset of the `gh` JSON output we depend on. */
interface GhPrListRow {
	readonly number?: unknown;
	readonly headRefName?: unknown;
	readonly createdAt?: unknown;
	readonly author?: { readonly login?: unknown } | null;
	readonly title?: unknown;
	readonly url?: unknown;
}

/**
 * Parse `gh pr list --json number,headRefName,createdAt,author[,title,url]`
 * output into a strongly-typed list. Malformed rows are silently dropped —
 * we don't want one bad row to abort the whole poll, and the agent doesn't
 * care about historical accuracy.
 *
 * Exposed for unit testing.
 */
export function parsePrList(stdout: string): readonly PrSummary[] {
	const trimmed = stdout.trim();
	if (trimmed.length === 0) return [];
	let raw: unknown;
	try {
		raw = JSON.parse(trimmed);
	} catch {
		return [];
	}
	if (!Array.isArray(raw)) return [];
	const out: PrSummary[] = [];
	for (const r of raw as GhPrListRow[]) {
		if (!r || typeof r !== "object") continue;
		const number = typeof r.number === "number" ? r.number : Number.NaN;
		const headRefName = typeof r.headRefName === "string" ? r.headRefName : "";
		const createdAt = typeof r.createdAt === "string" ? r.createdAt : "";
		const authorLogin =
			r.author && typeof r.author === "object" && typeof r.author.login === "string"
				? r.author.login
				: "";
		if (!Number.isFinite(number) || number <= 0) continue;
		if (createdAt.length === 0) continue;
		out.push({
			number,
			headRefName,
			createdAt,
			author: { login: authorLogin },
			...(typeof r.title === "string" ? { title: r.title } : {}),
			...(typeof r.url === "string" ? { url: r.url } : {}),
		});
	}
	return out;
}

/**
 * From a fresh poll batch, compute which PRs are "new since the last poll"
 * AND not authored by the current user.
 *
 * Dedup logic:
 *   - First poll (lastPollAt undefined): treat as a baseline. No PRs are
 *     emitted; we just capture the latest createdAt for the next round. This
 *     avoids spamming the user with reviews of every open PR on extension
 *     activation.
 *   - Subsequent polls: emit PRs whose createdAt > lastPollAt AND whose
 *     author.login !== currentUser. PRs already seen in `seenNumbers` are
 *     also filtered.
 *
 * Exposed for unit testing.
 */
export function computeNewPrs(
	prs: readonly PrSummary[],
	state: { readonly lastPollAt: string | undefined; readonly seenNumbers: ReadonlySet<number> },
	currentUser: string,
): readonly PrSummary[] {
	if (state.lastPollAt === undefined) {
		// Baseline poll — return nothing. Caller will advance state.
		return [];
	}
	const baseline = state.lastPollAt;
	return prs.filter(
		(p) =>
			p.createdAt > baseline &&
			!state.seenNumbers.has(p.number) &&
			p.author.login.length > 0 &&
			p.author.login.toLowerCase() !== currentUser.toLowerCase(),
	);
}

export interface PrWatcherOptions {
	readonly repo: string; // owner/repo
	readonly host: HostContext;
	readonly intervalMs: number;
	/** Login of the current user; PRs they authored are skipped. */
	readonly currentUser: string;
	readonly log?: { appendLine(msg: string): void };
}

export type PrListener = (pr: PrSummary) => void;

/**
 * A simple poll-loop wrapper around `gh pr list`. Construct, call `start()`,
 * dispose via `stop()`. `start()` is idempotent.
 *
 * `pollOnce()` is exposed for tests so they can drive the loop deterministically
 * without waiting for the interval timer.
 */
// R7-C bug fix: cap on the `seenNumbers` set so a long-lived watcher in a
// busy repo doesn't accumulate every PR number ever opened. We only need to
// remember enough recent numbers to dedupe against a single poll batch; an
// LRU-style cap is plenty.
const SEEN_NUMBERS_CAP = 2_000;

export class PrWatcher {
	private timer: NodeJS.Timeout | undefined;
	private listeners: PrListener[] = [];
	private lastPollAt: string | undefined;
	private seenNumbers = new Set<number>();
	private disposed = false;

	constructor(private readonly opts: PrWatcherOptions) {}

	onNewPr(listener: PrListener): () => void {
		this.listeners.push(listener);
		return () => {
			this.listeners = this.listeners.filter((l) => l !== listener);
		};
	}

	start(): void {
		if (this.disposed) throw new Error("PrWatcher: cannot start a disposed watcher");
		if (this.timer) return;
		// Run an immediate poll as the baseline so subsequent polls have a
		// `lastPollAt` to compare against.
		void this.pollOnce().catch((err) => this.logErr("initial poll", err));
		this.timer = setInterval(() => {
			void this.pollOnce().catch((err) => this.logErr("interval poll", err));
		}, this.opts.intervalMs);
		// Allow the process (or test runner) to exit if this is the only
		// pending timer.
		if (typeof this.timer.unref === "function") this.timer.unref();
	}

	stop(): void {
		if (this.timer) {
			clearInterval(this.timer);
			this.timer = undefined;
		}
		this.disposed = true;
		this.listeners = [];
	}

	/** Visible to tests so they can drive a single poll. */
	async pollOnce(): Promise<readonly PrSummary[]> {
		if (this.disposed) return [];
		const cmd = [
			"gh",
			"pr",
			"list",
			"-R",
			quoteArg(this.opts.repo),
			"--json",
			"number,headRefName,createdAt,author,title,url",
		].join(" ");
		const res: ExecResult = await this.opts.host.exec(cmd, { timeoutMs: 30_000 });
		if (res.exitCode !== 0) {
			this.logErr(
				"gh pr list",
				new Error(`exit ${res.exitCode}: ${res.stderr.trim() || res.stdout.trim() || "no output"}`),
			);
			return [];
		}
		const prs = parsePrList(res.stdout);
		const isBaseline = this.lastPollAt === undefined;
		const fresh = computeNewPrs(
			prs,
			{ lastPollAt: this.lastPollAt, seenNumbers: this.seenNumbers },
			this.opts.currentUser,
		);
		// Advance bookkeeping. On the baseline poll we just stash `now` and
		// remember the PR numbers we've seen so we don't double-fire them
		// later if their createdAt happens to land on a clock edge.
		const newest = prs.reduce<string | undefined>(
			(acc, p) => (acc === undefined || p.createdAt > acc ? p.createdAt : acc),
			undefined,
		);
		// On the baseline poll, anchor lastPollAt to "now" rather than the
		// newest PR — otherwise a brand-new PR opened a millisecond before
		// activation would slip past forever.
		this.lastPollAt = isBaseline ? new Date().toISOString() : (newest ?? this.lastPollAt);
		for (const p of prs) this.seenNumbers.add(p.number);
		// R7-C bug fix: trim the seenNumbers set if it has grown past the cap.
		// Set iteration order is insertion-order, so dropping the first N keeps
		// the most recently seen PR numbers. Without this cap a long-running
		// watcher in a high-velocity repo would slowly leak memory.
		if (this.seenNumbers.size > SEEN_NUMBERS_CAP) {
			const toDrop = this.seenNumbers.size - SEEN_NUMBERS_CAP;
			let i = 0;
			for (const n of this.seenNumbers) {
				if (i++ >= toDrop) break;
				this.seenNumbers.delete(n);
			}
		}
		for (const pr of fresh) {
			for (const l of this.listeners) {
				try {
					l(pr);
				} catch (err) {
					this.logErr("listener", err);
				}
			}
		}
		return fresh;
	}

	private logErr(context: string, err: unknown): void {
		const msg = err instanceof Error ? err.message : String(err);
		this.opts.log?.appendLine(`[pr-watch] ${context}: ${msg}`);
	}
}

function quoteArg(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

/**
 * Resolve the owning `owner/repo` for the current workspace from `gh`. Used
 * by the extension to construct a `PrWatcher` per workspace. Returns
 * `undefined` if `gh` isn't available or we're not inside a repo.
 */
export async function detectCurrentRepo(host: HostContext): Promise<string | undefined> {
	const res = await host.exec("gh repo view --json nameWithOwner -q .nameWithOwner", {
		timeoutMs: 15_000,
	});
	if (res.exitCode !== 0) return undefined;
	const name = res.stdout.trim();
	if (name.length === 0 || !name.includes("/")) return undefined;
	return name;
}

/**
 * Resolve the current GitHub login for the user. Used to filter PRs the user
 * authored themselves out of the auto-review feed.
 */
export async function detectCurrentUser(host: HostContext): Promise<string | undefined> {
	const res = await host.exec("gh api user -q .login", { timeoutMs: 15_000 });
	if (res.exitCode !== 0) return undefined;
	const login = res.stdout.trim();
	return login.length > 0 ? login : undefined;
}
