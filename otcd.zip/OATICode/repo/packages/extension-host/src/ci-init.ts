// 2026-05-27: CI integration. Emits a workflow file for the chosen platform
// (GitHub Actions / GitLab CI / CircleCI / Azure Pipelines) that runs the
// same checks `/review` and `/qa coverage` run locally.
//
// Inputs come from CIConfig (platform + which checks to include) and
// QAConfig (test framework + coverage thresholds). Output is one or two
// file paths + their contents. Caller (chat-panel) writes them to disk
// via host.writeFile.

import type { CIConfig, CIPlatform, QAConfig } from "@oati/shared";

export interface CIWorkflow {
	readonly path: string;
	readonly content: string;
}

export interface RunCIInitOptions {
	readonly cfg: CIConfig | undefined;
	readonly qa: QAConfig | undefined;
	/** Auto-detect hints — package.json content, pyproject.toml, etc. */
	readonly hints: readonly string[];
}

/**
 * Generate a workflow file for the configured CI platform. When platform is
 * omitted, defaults to "github". Returns the artifacts to write — caller
 * does the disk I/O so approval gates apply.
 */
export function buildCIWorkflows(opts: RunCIInitOptions): readonly CIWorkflow[] {
	const cfg = opts.cfg ?? {};
	const platform: CIPlatform = cfg.platform ?? "github";
	const nodeVersion = cfg.nodeVersion ?? "20";
	const pythonVersion = cfg.pythonVersion ?? "3.12";
	const framework = resolveFramework(opts.qa, opts.hints);
	const isPython = framework === "pytest" || framework === "unittest";

	const steps: Step[] = [];
	if (cfg.includeTypecheck !== false) {
		steps.push(typecheckStep(isPython, opts.hints));
	}
	if (cfg.includeLint !== false) {
		steps.push(lintStep(isPython, opts.hints));
	}
	if (cfg.includeTests !== false) {
		steps.push(testStep(framework));
	}
	if (cfg.includeCoverage === true) {
		steps.push(coverageStep(framework, opts.qa?.coverageThresholds));
	}

	switch (platform) {
		case "github":
			return [
				{
					path: ".github/workflows/oati-qa.yml",
					content: renderGithub(nodeVersion, pythonVersion, isPython, steps),
				},
			];
		case "gitlab":
			return [
				{
					path: ".gitlab-ci.yml",
					content: renderGitlab(nodeVersion, pythonVersion, isPython, steps),
				},
			];
		case "circleci":
			return [
				{
					path: ".circleci/config.yml",
					content: renderCircleCI(nodeVersion, pythonVersion, isPython, steps),
				},
			];
		case "azure-pipelines":
			return [
				{
					path: "azure-pipelines.yml",
					content: renderAzure(nodeVersion, pythonVersion, isPython, steps),
				},
			];
		case "tfs":
			return [
				{
					path: "azure-pipelines.yml",
					content: renderTFS(
						nodeVersion,
						pythonVersion,
						isPython,
						steps,
						cfg.tfsAgentPool ?? "Default",
						cfg.tfsGatedCheckIn === true,
					),
				},
			];
	}
}

// ---------------------------------------------------------------------------
// Step model — platform-independent description of a single CI step.
// ---------------------------------------------------------------------------
interface Step {
	readonly name: string;
	readonly run: string;
}

function resolveFramework(
	qa: QAConfig | undefined,
	hints: readonly string[],
): "vitest" | "jest" | "mocha" | "pytest" | "unittest" | "junit" {
	const explicit = qa?.testFramework;
	if (explicit && explicit !== "auto") return explicit;
	const blob = hints.join("\n").toLowerCase();
	if (blob.includes("vitest")) return "vitest";
	if (blob.includes("jest")) return "jest";
	if (blob.includes("mocha")) return "mocha";
	if (blob.includes("pytest") || blob.includes("pyproject.toml")) return "pytest";
	if (blob.includes("unittest.testcase")) return "unittest";
	if (blob.includes("junit") || blob.includes("pom.xml") || blob.includes("build.gradle")) {
		return "junit";
	}
	return "vitest";
}

function typecheckStep(isPython: boolean, hints: readonly string[]): Step {
	if (isPython) {
		const blob = hints.join("\n").toLowerCase();
		if (blob.includes("mypy")) return { name: "Typecheck", run: "mypy ." };
		if (blob.includes("pyright")) return { name: "Typecheck", run: "pyright" };
		return {
			name: "Typecheck (skipped — no mypy/pyright detected)",
			run: 'echo "no typechecker configured"',
		};
	}
	return { name: "Typecheck", run: "npx tsc --noEmit" };
}

function lintStep(isPython: boolean, hints: readonly string[]): Step {
	const blob = hints.join("\n").toLowerCase();
	if (isPython) {
		if (blob.includes("ruff")) return { name: "Lint", run: "ruff check ." };
		if (blob.includes("flake8")) return { name: "Lint", run: "flake8 ." };
		return { name: "Lint (skipped)", run: 'echo "no linter configured"' };
	}
	if (blob.includes("biome")) return { name: "Lint", run: "npx biome check ." };
	if (blob.includes("eslint")) return { name: "Lint", run: "npx eslint ." };
	return { name: "Lint (skipped)", run: 'echo "no linter configured"' };
}

function testStep(framework: string): Step {
	switch (framework) {
		case "vitest":
			return { name: "Tests", run: "npx vitest run --reporter=basic" };
		case "jest":
			return { name: "Tests", run: "npx jest --ci" };
		case "mocha":
			return { name: "Tests", run: "npx mocha" };
		case "pytest":
			return { name: "Tests", run: "pytest -q" };
		case "unittest":
			return { name: "Tests", run: "python -m unittest discover -v" };
		case "junit":
			return { name: "Tests", run: "mvn test" };
		default:
			return { name: "Tests", run: "npm test" };
	}
}

function coverageStep(framework: string, thresholds: QAConfig["coverageThresholds"]): Step {
	const lines = thresholds?.lines ?? 80;
	const branches = thresholds?.branches ?? 70;
	const functions = thresholds?.functions ?? 80;
	switch (framework) {
		case "vitest":
			return {
				name: "Coverage",
				run: `npx vitest run --coverage --coverage.thresholds.lines=${lines} --coverage.thresholds.branches=${branches} --coverage.thresholds.functions=${functions}`,
			};
		case "jest":
			return {
				name: "Coverage",
				run: `npx jest --coverage --coverageThreshold='{"global":{"lines":${lines},"branches":${branches},"functions":${functions}}}'`,
			};
		case "pytest":
			return {
				name: "Coverage",
				run: `pytest --cov --cov-fail-under=${lines}`,
			};
		default:
			return { name: "Coverage", run: 'echo "coverage step not configured for this framework"' };
	}
}

// ---------------------------------------------------------------------------
// Per-platform renderers
// ---------------------------------------------------------------------------
function renderGithub(
	node: string,
	python: string,
	isPython: boolean,
	steps: readonly Step[],
): string {
	const setup = isPython
		? `      - uses: actions/setup-python@v5\n        with:\n          python-version: "${python}"\n      - name: Install deps\n        run: |\n          if [ -f requirements.txt ]; then pip install -r requirements.txt; fi\n          if [ -f pyproject.toml ]; then pip install -e .[dev,test] || pip install -e .; fi`
		: `      - uses: actions/setup-node@v4\n        with:\n          node-version: "${node}"\n          cache: npm\n      - name: Install deps\n        run: npm ci`;
	const stepBlocks = steps.map((s) => `      - name: ${s.name}\n        run: ${s.run}`).join("\n");
	return `# OATI Code — QA workflow.
# Generated by '/ci init'. Edit freely; re-running '/ci init' will overwrite.
name: OATI QA

on:
  pull_request:
  push:
    branches: [main, master]

jobs:
  qa:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
${setup}
${stepBlocks}
`;
}

function renderGitlab(
	node: string,
	python: string,
	isPython: boolean,
	steps: readonly Step[],
): string {
	const image = isPython ? `python:${python}` : `node:${node}`;
	const install = isPython
		? "  before_script:\n    - if [ -f requirements.txt ]; then pip install -r requirements.txt; fi\n    - if [ -f pyproject.toml ]; then pip install -e .[dev,test] || pip install -e .; fi"
		: "  before_script:\n    - npm ci";
	const scriptLines = steps.map((s) => `    - ${s.run}  # ${s.name}`).join("\n");
	return `# OATI Code — QA pipeline.
# Generated by '/ci init'. Edit freely; re-running '/ci init' will overwrite.
default:
  image: ${image}

qa:
${install}
  script:
${scriptLines}
`;
}

function renderCircleCI(
	node: string,
	python: string,
	isPython: boolean,
	steps: readonly Step[],
): string {
	const image = isPython ? `cimg/python:${python}` : `cimg/node:${node}`;
	const install = isPython
		? "      - run:\n          name: Install deps\n          command: |\n            if [ -f requirements.txt ]; then pip install -r requirements.txt; fi\n            if [ -f pyproject.toml ]; then pip install -e .[dev,test] || pip install -e .; fi"
		: "      - run:\n          name: Install deps\n          command: npm ci";
	const stepBlocks = steps
		.map((s) => `      - run:\n          name: ${s.name}\n          command: ${s.run}`)
		.join("\n");
	return `# OATI Code — QA workflow.
# Generated by '/ci init'. Edit freely; re-running '/ci init' will overwrite.
version: 2.1

jobs:
  qa:
    docker:
      - image: ${image}
    steps:
      - checkout
${install}
${stepBlocks}

workflows:
  qa:
    jobs:
      - qa
`;
}

function renderAzure(
	node: string,
	python: string,
	isPython: boolean,
	steps: readonly Step[],
): string {
	const setup = isPython
		? `- task: UsePythonVersion@0\n  inputs:\n    versionSpec: "${python}"\n- script: |\n    if [ -f requirements.txt ]; then pip install -r requirements.txt; fi\n    if [ -f pyproject.toml ]; then pip install -e .[dev,test] || pip install -e .; fi\n  displayName: Install deps`
		: `- task: NodeTool@0\n  inputs:\n    versionSpec: "${node}"\n- script: npm ci\n  displayName: Install deps`;
	const stepBlocks = steps.map((s) => `- script: ${s.run}\n  displayName: ${s.name}`).join("\n");
	return `# OATI Code — QA pipeline.
# Generated by '/ci init'. Edit freely; re-running '/ci init' will overwrite.
trigger:
  - main
  - master

pr:
  - main
  - master

pool:
  vmImage: ubuntu-latest

steps:
${setup}
${stepBlocks}
`;
}

// 2026-05-27: TFS / on-prem Azure DevOps Server renderer. Same YAML
// dialect as renderAzure but tuned for the typical on-prem deployment:
//   - Self-hosted agent pool (default "Default" — admin-configurable).
//   - `pwsh:` task wrappers instead of bare `script:` (modern Windows
//     ships PowerShell 5.1; pwsh 7+ is recommended on build agents,
//     either works). Avoids the cmd-vs-bash ambiguity on Windows agents.
//   - Includes integrator-facing comments at the top explaining the
//     check-in → build → release flow and (optionally) how to wire a
//     gated-check-in policy to this pipeline.
function renderTFS(
	node: string,
	python: string,
	isPython: boolean,
	steps: readonly Step[],
	agentPool: string,
	includeGatedCheckInComment: boolean,
): string {
	const setup = isPython
		? `- task: UsePythonVersion@0\n  inputs:\n    versionSpec: "${python}"\n- pwsh: |\n    if (Test-Path requirements.txt) { pip install -r requirements.txt }\n    if (Test-Path pyproject.toml) { pip install -e ".[dev,test]" } catch { pip install -e . }\n  displayName: Install deps`
		: `- task: NodeTool@0\n  inputs:\n    versionSpec: "${node}"\n- pwsh: npm ci\n  displayName: Install deps`;
	// On TFS we render every step through `pwsh:` so the same YAML runs
	// on Windows build agents (the common case) AND Linux/macOS agents.
	const stepBlocks = steps.map((s) => `- pwsh: ${s.run}\n  displayName: ${s.name}`).join("\n");
	const gatedComment = includeGatedCheckInComment
		? `# --- Optional: gated check-in policy ---
# To require this pipeline to pass BEFORE a check-in completes
# (gated check-in), an admin should:
#   1. In TFS / Azure DevOps Server web UI, go to the repo'\''s Branches
#      view and edit the branch policy for the target branch.
#   2. Add a "Build validation" policy pointing at THIS pipeline.
#   3. Set "Path filter" if you only want gating on specific paths.
#   4. Save. New PRs / check-ins now require this pipeline to pass.
# (For TFVC-backed repos, configure "Build under associated check-in
# policies" in the team project'\''s source-control settings instead.)
`
		: "";
	return `# OATI Code — QA pipeline (TFS / Azure DevOps Server on-prem).
# Generated by '/ci init'. Edit freely; re-running '/ci init' will overwrite.
# Compatible with TFS 2018 Update 2+ and Azure DevOps Server 2019+.
${gatedComment}
trigger:
  branches:
    include:
      - main
      - master
      - develop
      - release/*

# Self-hosted agent pool — change to match your TFS deployment.
pool:
  name: ${agentPool}

steps:
${setup}
${stepBlocks}
`;
}
