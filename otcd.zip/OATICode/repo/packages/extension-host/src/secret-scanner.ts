/**
 * Outbound-traffic secret detection.
 *
 * Every user_message (and the rendered system prompt with project memory) is
 * scanned for high-confidence secret patterns before being handed to the
 * provider. The goal is to catch the obvious leaks — AWS keys, GitHub PATs,
 * OpenAI / Anthropic keys, Slack tokens, JWTs, private-key PEM headers — with
 * a low false-positive rate. We intentionally do NOT try to catch every
 * possible base64-blob-with-entropy; that's left to dedicated tools like
 * trufflehog. Here we only flag patterns specific enough to be unambiguous.
 *
 * The chat-panel uses `redactSecrets` to substitute matches with
 * `[REDACTED:KIND]` before dispatch (default behavior). The webview is also
 * notified via a `secret_warning` RPC so the user can review.
 */

export interface SecretMatch {
	/** Stable kind identifier — also used in the `[REDACTED:KIND]` placeholder. */
	readonly kind: string;
	/** A short preview of the matched substring, with the middle masked. */
	readonly preview: string;
	/** Byte offset of the first character of the match in the original string. */
	readonly start: number;
	/** Byte offset just past the last character of the match. */
	readonly end: number;
}

/** Internal pattern descriptor — one regex per secret kind. */
interface PatternSpec {
	readonly kind: string;
	readonly regex: RegExp;
	/**
	 * Optional secondary validator applied after the regex matches. Used to
	 * suppress false positives where the regex alone is too permissive (e.g.
	 * the AWS secret-key pattern which is just 40 base64 chars).
	 */
	readonly validate?: (match: string, fullText: string, start: number) => boolean;
}

const PATTERNS: readonly PatternSpec[] = [
	// AWS access key — fixed prefix + 16 uppercase alphanumerics. Unambiguous.
	{
		kind: "AWS access key",
		regex: /\bAKIA[0-9A-Z]{16}\b/g,
	},
	// AWS secret access key — 40 base64-ish chars. To avoid matching every
	// sha1 hex digest or hash blob, we require BOTH a lowercase letter AND a
	// digit AND an uppercase letter or `+`/`/`. Hex strings (`[0-9a-f]+`) fail
	// the uppercase-or-symbol test. Boundary characters allow `=` and quote
	// chars so we match keys assigned in `KEY=value` or `"key"` contexts.
	{
		kind: "AWS secret access key",
		regex: /(?<![A-Za-z0-9/+])[A-Za-z0-9/+]{40}(?![A-Za-z0-9/+])/g,
		validate: (m) => /[a-z]/.test(m) && /[0-9]/.test(m) && /[A-Z/+]/.test(m),
	},
	// GitHub personal-access tokens — `ghp_`, `gho_`, `ghu_`, `ghs_`, `ghr_`
	// followed by base62. The official format is 36+ chars after the prefix.
	{
		kind: "GitHub PAT",
		regex: /\bgh[pousr]_[A-Za-z0-9]{30,}\b/g,
	},
	// Anthropic API keys come first because they share the `sk-` prefix with
	// OpenAI; ordering ensures `sk-ant-...` is classified as Anthropic.
	{
		kind: "Anthropic key",
		regex: /\bsk-ant-[A-Za-z0-9_-]{20,}\b/g,
	},
	// OpenAI API keys — `sk-` + at least 40 chars of base64ish. The
	// "not-sk-ant-" lookahead avoids double-classifying Anthropic keys.
	{
		kind: "OpenAI key",
		regex: /\bsk-(?!ant-)[A-Za-z0-9_-]{40,}\b/g,
	},
	// Slack bot/user tokens. Multiple prefixes exist; we cover the common ones.
	{
		kind: "Slack token",
		regex: /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g,
	},
	// JWT — three base64url segments separated by `.`. The header almost
	// always starts with `eyJ` (base64 of `{"`).
	{
		kind: "JWT",
		regex: /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g,
	},
	// Private key PEM headers — covers RSA, DSA, EC, OPENSSH, and generic.
	{
		kind: "Private key",
		regex: /-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY-----/g,
	},
];

/**
 * Scan `text` for secret patterns. Returns matches in the order they were
 * found, deduplicated by `[start, end)` range. Overlapping matches from
 * different kinds keep the first (in pattern declaration order).
 */
export function scanForSecrets(text: string): readonly SecretMatch[] {
	if (!text || text.length === 0) return [];
	const matches: SecretMatch[] = [];
	const occupied: Array<[number, number]> = [];

	const overlaps = (start: number, end: number): boolean => {
		for (const [s, e] of occupied) {
			if (start < e && end > s) return true;
		}
		return false;
	};

	for (const spec of PATTERNS) {
		spec.regex.lastIndex = 0;
		let m = spec.regex.exec(text);
		while (m !== null) {
			const start = m.index;
			const end = start + m[0].length;
			if (!(spec.validate && !spec.validate(m[0], text, start)) && !overlaps(start, end)) {
				occupied.push([start, end]);
				matches.push({
					kind: spec.kind,
					preview: maskPreview(m[0]),
					start,
					end,
				});
			}
			m = spec.regex.exec(text);
		}
	}

	// Return in source order so callers can present them in a stable way.
	matches.sort((a, b) => a.start - b.start);
	return matches;
}

/**
 * Replace every detected secret in `text` with `[REDACTED:KIND]`. Returns the
 * redacted string AND the matches that were redacted (so callers can log /
 * notify the user). Non-secret text is preserved verbatim.
 */
export function redactSecrets(text: string): {
	readonly redacted: string;
	readonly matches: readonly SecretMatch[];
} {
	const matches = scanForSecrets(text);
	if (matches.length === 0) return { redacted: text, matches };
	// Walk back-to-front so earlier offsets stay valid as we splice.
	let out = text;
	for (let i = matches.length - 1; i >= 0; i--) {
		const m = matches[i];
		out = `${out.slice(0, m.start)}[REDACTED:${m.kind}]${out.slice(m.end)}`;
	}
	return { redacted: out, matches };
}

/**
 * Group a list of matches by kind into a "kind (N), other-kind (M)" string for
 * user-facing warnings. Stable order = first-seen.
 */
export function summarizeMatches(matches: readonly SecretMatch[]): string {
	if (matches.length === 0) return "";
	const counts = new Map<string, number>();
	for (const m of matches) counts.set(m.kind, (counts.get(m.kind) ?? 0) + 1);
	const parts: string[] = [];
	for (const [kind, n] of counts) parts.push(`${kind} (${n})`);
	return parts.join(", ");
}

/** Mask the middle of a secret for safe display in logs / UI. */
function maskPreview(raw: string): string {
	if (raw.length <= 8) return "*".repeat(raw.length);
	const head = raw.slice(0, 4);
	const tail = raw.slice(-4);
	return `${head}…${tail}`;
}
