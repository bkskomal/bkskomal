/**
 * R6-D: Streaming diff parser.
 *
 * The composer today (R2-A) waits for the entire JSON envelope to land before
 * surfacing previews. That works but is jarring on multi-file generations:
 * the user stares at an empty modal for 20+ seconds. This module consumes the
 * raw model stream incrementally and emits `{ path, content, status }` events
 * the moment we can tell a file is "in progress" or "complete".
 *
 * The parser is regex-based and tolerant: models sometimes wrap the JSON in
 * a fence, sometimes prefix prose, sometimes interleave path declarations
 * line-by-line. We don't try to be a JSON streaming parser (those are
 * fiddly); we look for the canonical `{ "path": "...", "content": "..." }`
 * pattern and emit `writing` events as content accumulates, then `complete`
 * once the closing quote arrives.
 */

export interface StreamingDiffEvent {
	readonly path: string;
	readonly content: string;
	readonly status: "writing" | "complete";
}

interface InFlightFile {
	path: string;
	/** Chars consumed into `content` so far (after escape decoding). */
	content: string;
	/** Whether we've already emitted at least one "writing" event. */
	emittedWriting: boolean;
}

export class StreamingDiffParser {
	private buffer = "";
	private current: InFlightFile | undefined;
	/** Set of paths we've already emitted "complete" for, so we don't re-emit. */
	private readonly completed = new Set<string>();
	private readonly listeners = new Set<(ev: StreamingDiffEvent) => void>();
	/** Throttle "writing" events to at most one per N content chars per file. */
	private static readonly WRITING_CHUNK_THRESHOLD = 64;
	private lastEmittedSize = 0;

	on(listener: (ev: StreamingDiffEvent) => void): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	/**
	 * Feed a chunk of model output. Emits zero or more events synchronously
	 * via registered listeners. Safe to call repeatedly with partial UTF-8
	 * boundary-safe text chunks; we never look at raw bytes.
	 */
	feed(chunk: string): void {
		this.buffer += chunk;
		// Two-state machine: either we're between files (looking for the next
		// `"path"`), or we're inside a file's `content` string (accumulating
		// until the unescaped closing quote).
		// Keep looping while we can make progress.
		while (this.step()) {
			// step() returns true when it consumed bytes; loop until idle.
		}
	}

	/**
	 * Signal end-of-stream. If we were mid-file when the stream cut off, emit
	 * one final "complete" event with whatever content we managed to capture.
	 * Idempotent.
	 */
	end(): void {
		if (this.current) {
			this.emit({
				path: this.current.path,
				content: this.current.content,
				status: "complete",
			});
			this.completed.add(this.current.path);
			this.current = undefined;
		}
	}

	/** Snapshot of completed file paths (for tests). */
	getCompletedPaths(): readonly string[] {
		return [...this.completed];
	}

	private step(): boolean {
		if (!this.current) {
			// Looking for the next file header. The canonical shape is
			//   { "path": "<rel>", "content": "
			// followed by content text and a closing `"`. Match `path` first,
			// then look for `content` separately so models that emit them on
			// different lines still parse.
			const pathMatch = /"path"\s*:\s*"((?:\\.|[^"\\])*)"/m.exec(this.buffer);
			if (!pathMatch) return false;
			// Make sure the `content` opener follows somewhere after.
			const after = this.buffer.slice(pathMatch.index + pathMatch[0].length);
			const contentOpen = /"content"\s*:\s*"/.exec(after);
			if (!contentOpen) return false;
			const path = decodeJsonString(pathMatch[1]);
			const consumedUpTo =
				pathMatch.index + pathMatch[0].length + contentOpen.index + contentOpen[0].length;
			this.buffer = this.buffer.slice(consumedUpTo);
			this.current = { path, content: "", emittedWriting: false };
			this.lastEmittedSize = 0;
			return true;
		}
		// Inside a content string. Walk the buffer looking for an unescaped `"`.
		// We *append* the decoded text to `current.content` rather than replace
		// it — the buffer holds only the unprocessed remainder from this and
		// prior feeds, never the prefix that has already been folded into
		// `current.content`.
		let i = 0;
		const buf = this.buffer;
		let escaped = false;
		while (i < buf.length) {
			const c = buf[i];
			if (escaped) {
				escaped = false;
				i++;
				continue;
			}
			if (c === "\\") {
				escaped = true;
				i++;
				continue;
			}
			if (c === '"') {
				// Closing quote. Decode everything up to (but not including) i
				// and append to whatever we've already accumulated.
				const raw = buf.slice(0, i);
				this.current.content += decodeJsonString(raw);
				this.emit({
					path: this.current.path,
					content: this.current.content,
					status: "complete",
				});
				this.completed.add(this.current.path);
				this.current = undefined;
				this.buffer = buf.slice(i + 1);
				return true;
			}
			i++;
		}
		// Reached end of buffer without finding the closing quote. Decode the
		// safely-terminated portion (excluding any dangling backslash) and
		// append it to `current.content`. Keep the trailing escape in the
		// buffer so the next feed can resolve it.
		const safeLen = escaped ? buf.length - 1 : buf.length;
		if (safeLen > 0) {
			this.current.content += decodeJsonString(buf.slice(0, safeLen));
		}
		if (
			this.current.content.length - this.lastEmittedSize >=
				StreamingDiffParser.WRITING_CHUNK_THRESHOLD ||
			!this.current.emittedWriting
		) {
			this.emit({
				path: this.current.path,
				content: this.current.content,
				status: "writing",
			});
			this.current.emittedWriting = true;
			this.lastEmittedSize = this.current.content.length;
		}
		this.buffer = escaped ? buf.slice(buf.length - 1) : "";
		return false;
	}

	private emit(ev: StreamingDiffEvent): void {
		for (const l of this.listeners) {
			try {
				l(ev);
			} catch {
				// Listener errors must not stop other listeners.
			}
		}
	}
}

/**
 * Decode a JSON string literal (the content between the outer quotes). We do
 * this in-line rather than `JSON.parse(`"${raw}"`)` because the partial
 * buffer may contain genuine unescaped newlines (some models stream pretty-
 * printed output) which `JSON.parse` would reject.
 */
function decodeJsonString(raw: string): string {
	let out = "";
	let i = 0;
	while (i < raw.length) {
		const c = raw[i];
		if (c === "\\" && i + 1 < raw.length) {
			const n = raw[i + 1];
			if (n === "n") out += "\n";
			else if (n === "t") out += "\t";
			else if (n === "r") out += "\r";
			else if (n === '"') out += '"';
			else if (n === "\\") out += "\\";
			else if (n === "/") out += "/";
			else if (n === "u" && i + 5 < raw.length) {
				const hex = raw.slice(i + 2, i + 6);
				const code = Number.parseInt(hex, 16);
				if (Number.isFinite(code)) {
					out += String.fromCharCode(code);
					i += 6;
					continue;
				}
				out += n;
			} else out += n;
			i += 2;
			continue;
		}
		out += c;
		i++;
	}
	return out;
}
