/**
 * R6-D: Smart-apply (three-way merge).
 *
 * When the agent proposes a `before` → `after` edit but the on-disk `current`
 * content has drifted (the user typed, another tool wrote, the linter ran)
 * the naive write would either clobber the user's work or fail because the
 * pre-image doesn't match. `smartApplyEdit` instead computes the hunks of the
 * intended change (`before` → `after`) and re-applies them against `current`
 * with fuzzy whitespace matching. Hunks that still find their context land
 * cleanly; the rest produce git-style conflict markers the user can resolve
 * in the editor.
 *
 * Pure module — no `vscode` import — so the writeFile tool path can call it
 * inside an arbitrary HostContext.
 */

export interface SmartHunk {
	/** 0-based line in `before` where the change starts. */
	readonly beforeStart: number;
	/** Lines removed (from `before`). */
	readonly removed: readonly string[];
	/** Lines added (in `after`). */
	readonly added: readonly string[];
	/** Up to 3 lines of unchanged context immediately preceding the hunk. */
	readonly contextBefore: readonly string[];
	/** Up to 3 lines of unchanged context immediately following the hunk. */
	readonly contextAfter: readonly string[];
}

export type SmartApplyStatus = "clean" | "merged" | "conflict";

export interface SmartApplyResult {
	readonly status: SmartApplyStatus;
	readonly merged: string;
	readonly conflictHunks?: readonly SmartHunk[];
}

const CONTEXT_LINES = 3;

/**
 * Three-way merge of `current` (on-disk) with the agent's intended change
 * (`before` → `after`).
 *
 * - "clean": `current === before`; we just return `after`.
 * - "merged": every hunk re-located cleanly in `current` (possibly via fuzzy
 *   whitespace match); `merged` is the post-apply text.
 * - "conflict": at least one hunk's context could not be located; the
 *   returned `merged` contains git-style `<<<<<<< / ======= / >>>>>>>`
 *   markers around each unresolved region. `conflictHunks` lists them.
 */
export function smartApplyEdit(
	_path: string,
	before: string,
	after: string,
	current: string,
): SmartApplyResult {
	// Fast path: file did not drift — direct overwrite is the agent's intent.
	if (before === current) {
		return { status: "clean", merged: after };
	}
	// No-op edit — keep whatever's on disk regardless of drift.
	if (before === after) {
		return { status: "clean", merged: current };
	}

	const hunks = computeSmartHunks(before, after);
	if (hunks.length === 0) {
		return { status: "clean", merged: current };
	}

	const currentLines = splitLines(current);
	// Two-pass: first locate every hunk against the *original* `current` (so
	// downstream hunks aren't confused by earlier hunks' applied changes),
	// then walk the file once and splice in either the new content or a
	// conflict block at each anchor in order.
	interface Plan {
		readonly hunk: SmartHunk;
		readonly anchor: number;
		readonly removedCount: number;
		readonly conflict: boolean;
	}
	const plans: Plan[] = [];
	const unlocated: SmartHunk[] = [];
	// `minAnchor` is the earliest line in `currentLines` where this hunk's
	// removed region may start — i.e. just past the previous hunk's removed
	// region. The hunk's `contextBefore` may overlap into already-consumed
	// territory (consecutive hunks share context lines), so we search from
	// the start of the file but require the anchor to land at or after
	// `minAnchor`.
	let minAnchor = 0;
	for (const h of hunks) {
		const anchor = findHunkAnchorAtOrAfter(currentLines, h, minAnchor);
		if (anchor === -1) {
			unlocated.push(h);
			continue;
		}
		const removedCount = h.removed.length;
		const removedSlice = currentLines.slice(anchor, anchor + removedCount);
		const removedMatches = fuzzyLinesEqual(removedSlice, h.removed);
		plans.push({ hunk: h, anchor, removedCount, conflict: !removedMatches });
		minAnchor = anchor + removedCount;
	}

	const out: string[] = [];
	let cursor = 0;
	let merged = false;
	let conflicted = false;
	for (const p of plans) {
		for (let i = cursor; i < p.anchor; i++) out.push(currentLines[i]);
		if (p.conflict) {
			const removedSlice = currentLines.slice(p.anchor, p.anchor + p.removedCount);
			out.push("<<<<<<< current");
			for (const l of removedSlice) out.push(l);
			out.push("=======");
			for (const l of p.hunk.added) out.push(l);
			out.push(">>>>>>> incoming");
			conflicted = true;
		} else {
			for (const l of p.hunk.added) out.push(l);
		}
		cursor = p.anchor + p.removedCount;
		merged = true;
	}
	for (let i = cursor; i < currentLines.length; i++) out.push(currentLines[i]);

	// Hunks whose contextBefore could not be located anywhere — append a
	// trailing conflict block so the user sees every dropped change.
	for (const h of unlocated) {
		out.push("<<<<<<< current");
		out.push("======= (unresolved: context not found in current file)");
		for (const l of h.added) out.push(l);
		out.push(">>>>>>> incoming");
		conflicted = true;
	}

	const mergedText = joinLines(out, current);
	const allConflicts = [...plans.filter((p) => p.conflict).map((p) => p.hunk), ...unlocated];
	if (conflicted) {
		return { status: "conflict", merged: mergedText, conflictHunks: allConflicts };
	}
	return merged ? { status: "merged", merged: mergedText } : { status: "clean", merged: current };
}

/**
 * Diff `before` → `after` into hunks. Uses a line-level LCS (same approach
 * as `inline-diff.ts`) and annotates each hunk with up to 3 lines of
 * surrounding unchanged context so we can relocate it inside a drifted file.
 */
export function computeSmartHunks(before: string, after: string): SmartHunk[] {
	const a = splitLines(before);
	const b = splitLines(after);
	const lcs = longestCommonSubsequence(a, b);
	const raw: { beforeStart: number; removed: string[]; added: string[] }[] = [];
	let i = 0;
	let j = 0;
	for (const [ai, bi] of lcs) {
		if (i < ai || j < bi) {
			raw.push({ beforeStart: i, removed: a.slice(i, ai), added: b.slice(j, bi) });
		}
		i = ai + 1;
		j = bi + 1;
	}
	if (i < a.length || j < b.length) {
		raw.push({ beforeStart: i, removed: a.slice(i), added: b.slice(j) });
	}
	return raw.map((h) => ({
		beforeStart: h.beforeStart,
		removed: h.removed,
		added: h.added,
		contextBefore: a.slice(Math.max(0, h.beforeStart - CONTEXT_LINES), h.beforeStart),
		contextAfter: a.slice(
			h.beforeStart + h.removed.length,
			h.beforeStart + h.removed.length + CONTEXT_LINES,
		),
	}));
}

/**
 * Locate a hunk's `contextBefore` inside `currentLines`, returning the line
 * where the removed region begins. (R7-A/R7-C: removed the unused
 * `findHunkAnchor` sibling; only `findHunkAnchorAtOrAfter` is called.)
 * Requires the resulting anchor (post-context
 * position) to land at or after `minAnchor`. Consecutive hunks may share
 * context lines that overlap with the previous hunk's contextAfter, so we
 * search from the start of the file but reject anchors earlier than the
 * previous hunk's removed region ended.
 *
 * Scoring order, best-match first:
 *   1. contextBefore matches AND the immediately-following lines match the
 *      hunk's `removed` region — strong signal, anchor is exact.
 *   2. contextBefore matches AND `removed` is empty (pure insertion) AND
 *      the immediately-following lines match `contextAfter` — also strong.
 *   3. contextBefore matches alone — fall-back for cases where the removed
 *      region has drifted (still emits a conflict block at this anchor).
 */
function findHunkAnchorAtOrAfter(
	currentLines: readonly string[],
	hunk: SmartHunk,
	minAnchor: number,
): number {
	// First pass: try with the FULL contextBefore and require either the
	// removed region or contextAfter to match. This is the strong-match path.
	const strong = scanForStrongAnchor(currentLines, hunk, minAnchor, hunk.contextBefore);
	if (strong !== -1) return strong;
	// Second pass: progressively shrink the contextBefore from the FRONT (drop
	// leading lines that may overlap with an earlier hunk's territory). Still
	// require a strong removed/contextAfter match.
	for (let drop = 1; drop < hunk.contextBefore.length; drop++) {
		const shrunk = hunk.contextBefore.slice(drop);
		const anchor = scanForStrongAnchor(currentLines, hunk, minAnchor, shrunk);
		if (anchor !== -1) return anchor;
	}
	// Third pass: try contextAfter alone — anchor lands at the start of a
	// matching contextAfter, with removed region preceding it.
	if (hunk.contextAfter.length > 0) {
		const afterAnchor = scanForAfterAnchor(currentLines, hunk, minAnchor);
		if (afterAnchor !== -1) return afterAnchor;
	}
	// Last resort: weak match on contextBefore alone.
	const ctx = hunk.contextBefore;
	if (ctx.length === 0) {
		if (hunk.removed.length === 0) return Math.max(minAnchor, 0);
		const slice = currentLines.slice(minAnchor, minAnchor + hunk.removed.length);
		return fuzzyLinesEqual(slice, hunk.removed) ? minAnchor : -1;
	}
	for (let start = 0; start <= currentLines.length - ctx.length; start++) {
		const anchor = start + ctx.length;
		if (anchor < minAnchor) continue;
		let ok = true;
		for (let k = 0; k < ctx.length; k++) {
			if (!fuzzyLineEqual(currentLines[start + k], ctx[k])) {
				ok = false;
				break;
			}
		}
		if (ok) return anchor;
	}
	return -1;
}

function scanForStrongAnchor(
	currentLines: readonly string[],
	hunk: SmartHunk,
	minAnchor: number,
	ctx: readonly string[],
): number {
	if (ctx.length === 0) {
		if (hunk.removed.length === 0) return Math.max(minAnchor, 0);
		// Search every position where removed could land.
		for (let start = minAnchor; start <= currentLines.length - hunk.removed.length; start++) {
			const slice = currentLines.slice(start, start + hunk.removed.length);
			if (fuzzyLinesEqual(slice, hunk.removed)) return start;
		}
		return -1;
	}
	for (let start = 0; start <= currentLines.length - ctx.length; start++) {
		const anchor = start + ctx.length;
		if (anchor < minAnchor) continue;
		let ok = true;
		for (let k = 0; k < ctx.length; k++) {
			if (!fuzzyLineEqual(currentLines[start + k], ctx[k])) {
				ok = false;
				break;
			}
		}
		if (!ok) continue;
		if (hunk.removed.length > 0) {
			const removedSlice = currentLines.slice(anchor, anchor + hunk.removed.length);
			if (fuzzyLinesEqual(removedSlice, hunk.removed)) return anchor;
		} else if (hunk.contextAfter.length > 0) {
			const afterSlice = currentLines.slice(anchor, anchor + hunk.contextAfter.length);
			if (fuzzyLinesEqual(afterSlice, hunk.contextAfter)) return anchor;
		} else {
			return anchor;
		}
	}
	return -1;
}

function scanForAfterAnchor(
	currentLines: readonly string[],
	hunk: SmartHunk,
	minAnchor: number,
): number {
	const after = hunk.contextAfter;
	const removedCount = hunk.removed.length;
	for (let start = minAnchor + removedCount; start <= currentLines.length - after.length; start++) {
		let ok = true;
		for (let k = 0; k < after.length; k++) {
			if (!fuzzyLineEqual(currentLines[start + k], after[k])) {
				ok = false;
				break;
			}
		}
		if (!ok) continue;
		const anchor = start - removedCount;
		if (anchor < minAnchor) continue;
		// Optionally verify removed region.
		if (removedCount > 0) {
			const slice = currentLines.slice(anchor, anchor + removedCount);
			if (fuzzyLinesEqual(slice, hunk.removed)) return anchor;
		} else {
			return anchor;
		}
	}
	return -1;
}

function fuzzyLineEqual(a: string, b: string): boolean {
	if (a === b) return true;
	return a.trim() === b.trim();
}

function fuzzyLinesEqual(a: readonly string[], b: readonly string[]): boolean {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) {
		if (!fuzzyLineEqual(a[i], b[i])) return false;
	}
	return true;
}

function splitLines(s: string): string[] {
	if (s.length === 0) return [];
	return s.split(/\r?\n/);
}

function joinLines(lines: readonly string[], original: string): string {
	const eol = original.includes("\r\n") ? "\r\n" : "\n";
	const text = lines.join(eol);
	// Preserve trailing newline from `original` when present.
	if (original.endsWith("\n") && !text.endsWith("\n")) return `${text}${eol}`;
	return text;
}

/**
 * Greedy LCS over two line arrays. Matches `inline-diff.ts`'s strategy: O(n²)
 * worst case but fine for typical file sizes. Returns the matched index pairs
 * in order so the caller can walk both arrays in lockstep.
 */
function longestCommonSubsequence(a: readonly string[], b: readonly string[]): [number, number][] {
	const m = a.length;
	const n = b.length;
	if (m === 0 || n === 0) return [];
	// Standard LCS DP.
	const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
	for (let i = 0; i < m; i++) {
		for (let j = 0; j < n; j++) {
			if (a[i] === b[j]) dp[i + 1][j + 1] = dp[i][j] + 1;
			else dp[i + 1][j + 1] = Math.max(dp[i][j + 1], dp[i + 1][j]);
		}
	}
	const out: [number, number][] = [];
	let i = m;
	let j = n;
	while (i > 0 && j > 0) {
		if (a[i - 1] === b[j - 1]) {
			out.push([i - 1, j - 1]);
			i--;
			j--;
		} else if (dp[i - 1][j] >= dp[i][j - 1]) {
			i--;
		} else {
			j--;
		}
	}
	return out.reverse();
}
