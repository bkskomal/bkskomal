/**
 * R5-C: auto-promote facts.
 *
 * Scans an assistant reply for lines that look like the model is calling out
 * a project-specific insight — "Note that …", "Important: …", "Remember
 * …", "Key takeaway …" — and (when the chat panel runs in an auto-approve
 * mode) writes the first such line to `<workspace>/.oati/facts.json` via the
 * existing `addFact()`. The existing dedupe in `addFact` keeps repeated
 * insights idempotent.
 *
 * Heuristics are intentionally narrow:
 *   - one fact promoted per assistant turn (cap noise; the user can still
 *     `/remember <fact>` for anything else),
 *   - skip lines that are obviously prose continuations ("Note that the
 *     function returns" without a noun-phrase looks more like prose than an
 *     insight; we still take it — false positives are cheap because dedupe
 *     squashes repeats, and the user can prune `.oati/facts.json` by hand).
 */
import { type Fact, addFact } from "./agent-facts";

const INSIGHT_PATTERNS: readonly RegExp[] = [
	// `Note that <something>.` — most common phrasing the model emits.
	/^\s*note that\s+(.{8,400}?)\s*[.!?]?\s*$/i,
	// `Important: <thing>` / `Important — <thing>`.
	/^\s*important\s*[:—-]\s*(.{6,400}?)\s*[.!?]?\s*$/i,
	// `Remember <thing>` / `Remember: <thing>` / `Remember that <thing>`.
	/^\s*remember(?:\s+that)?\s*[:,-]?\s*(.{6,400}?)\s*[.!?]?\s*$/i,
	// `Key takeaway: <thing>` / `Key takeaway — <thing>`.
	/^\s*key takeaway\s*[:—-]\s*(.{6,400}?)\s*[.!?]?\s*$/i,
	// Markdown emphasis variants: **Note:** / **Important:** / **Remember:**.
	// The colon may live either INSIDE the closing asterisks (`**Note:**`) or
	// just after them (`**Note**:`); we accept both.
	/^\s*\*+\s*(?:note|important|remember|key takeaway)\s*[:—-]?\s*\*+\s*[:—-]?\s*(.{6,400}?)\s*[.!?]?\s*$/i,
];

const MIN_FACT_CHARS = 8;
const MAX_FACT_CHARS = 280;

/**
 * Extract the first insight-looking line from `reply`, or undefined when
 * none of the heuristic patterns match. Exported for unit tests; production
 * callers use {@link promoteFactIfAny}.
 */
export function extractInsight(reply: string): string | undefined {
	if (!reply) return undefined;
	const lines = reply.split(/\r?\n/);
	for (const raw of lines) {
		const line = raw.trim();
		if (line.length < MIN_FACT_CHARS) continue;
		for (const re of INSIGHT_PATTERNS) {
			const m = re.exec(line);
			if (m?.[1]) {
				const candidate = m[1].trim().replace(/\s+/g, " ");
				if (candidate.length < MIN_FACT_CHARS) continue;
				if (candidate.length > MAX_FACT_CHARS) continue;
				return candidate;
			}
		}
	}
	return undefined;
}

export interface PromoteFactOptions {
	readonly workspaceRoot: string;
	readonly reply: string;
	/** Source tag persisted on the fact. Defaults to "agent-auto". */
	readonly source?: string;
}

/**
 * Look for an insight line in `reply` and append it to `.oati/facts.json`.
 * Returns the new fact when one was promoted, or undefined when no insight
 * matched / the fact was a duplicate / persistence failed. Errors are
 * swallowed — fact promotion is best-effort and should never break a turn.
 */
export async function promoteFactIfAny(opts: PromoteFactOptions): Promise<Fact | undefined> {
	if (!opts.workspaceRoot) return undefined;
	const candidate = extractInsight(opts.reply ?? "");
	if (!candidate) return undefined;
	try {
		const before = (await import("./agent-facts")).loadFacts(opts.workspaceRoot);
		const beforeIds = new Set((await before).map((f) => f.id));
		const after = await addFact(opts.workspaceRoot, {
			fact: candidate,
			source: opts.source ?? "agent-auto",
		});
		// `addFact` dedupes silently; only report a promotion when the list
		// actually grew.
		const promoted = after.find((f) => !beforeIds.has(f.id));
		return promoted;
	} catch {
		return undefined;
	}
}
