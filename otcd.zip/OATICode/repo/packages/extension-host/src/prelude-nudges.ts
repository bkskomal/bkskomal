// 2026-05-29: Plan-mode + TDD-mode prelude nudges.
//
// Two session-scoped toggles that change how the model approaches a turn:
//
//   PLAN MODE — Cursor-parity "show me what you're about to do" gate.
//     off:   no nudge.
//     on:    always inject the planning nudge so the model writes a numbered
//            plan with acceptance criteria BEFORE any tool calls.
//     auto:  inject the nudge only when the user's message looks non-trivial
//            (length heuristic + multi-step keyword scan). Avoids spending
//            tokens on a plan for a one-line question.
//
//   TDD MODE — test-first by default for bug fixes / new behavior.
//     off:   no nudge.
//     on:    always inject the TDD nudge teaching the model to write the
//            failing test, confirm it fails, then implement.
//
// Both nudges are deliberately short — the prompt is already heavy. We pay
// only for the words the model actually needs to internalize the workflow.
// Trigger heuristics live here as pure functions so they're testable in
// isolation from the chat-panel.

export type PlanMode = "off" | "on" | "auto";
export type TddMode = "off" | "on";

/**
 * Decide whether the planning nudge should appear in the current turn's prelude.
 * `on` always fires; `auto` checks a length + keyword heuristic; `off` never fires.
 *
 * The heuristic intentionally errs on the side of NOT planning — a wasted plan
 * costs tokens, but a missed plan only costs a follow-up correction. Keywords
 * are limited to verbs that strongly imply multi-step work.
 */
export function shouldInjectPlanNudge(mode: PlanMode, userContent: string): boolean {
	if (mode === "off") return false;
	if (mode === "on") return true;
	// auto:
	const trimmed = userContent.trim();
	if (trimmed.length === 0) return false;
	if (trimmed.length >= 250) return true;
	const multiStepKeywords =
		/\b(refactor|rewrite|migrate|implement|add (a |an |the )?new|build (a |an |the )|across|everywhere|all (the )?(files|usages|callers|tests)|every (file|module|package))\b/i;
	return multiStepKeywords.test(trimmed);
}

/**
 * Decide whether the TDD nudge should appear in the current turn's prelude.
 * TDD has no `auto` mode — the user opts in explicitly because test-first adds
 * real overhead for many tasks (UI tweaks, prose edits, exploratory questions)
 * that simply don't benefit.
 */
export function shouldInjectTddNudge(mode: TddMode): boolean {
	return mode === "on";
}

export const PLAN_NUDGE = [
	"## Planning ahead",
	"",
	"For non-trivial tasks (≥3 distinct sub-steps, multi-file refactors, anything you'd estimate to take 4+ tool calls), START your reply by drafting a SHORT numbered plan BEFORE any tool calls:",
	"",
	"```",
	"1. [Action] — Done when [observable criterion].",
	"2. [Action] — Done when [observable criterion].",
	"3. ...",
	"```",
	"",
	"Aim for 3-7 steps. Each step must name a CONCRETE acceptance criterion ('Done when tests pass', 'Done when foo.ts compiles', 'Done when grep returns zero matches') so you can self-verify as you go. After the plan, execute step-by-step. If the user pushes back, revise the plan first — don't barrel ahead.",
	"",
	"Trivial tasks (single edit, single read, answering a question, a one-line tweak) don't need a plan — just do them.",
].join("\n");

export const TDD_NUDGE = [
	"## Test-first by default",
	"",
	"For bug fixes and new behavior, follow the TDD workflow:",
	"",
	"1. Read the relevant code so you understand the current behavior.",
	"2. Write a FAILING test that captures the desired behavior. Keep it focused on the specific case.",
	"3. Run the test (`run_tests`) and CONFIRM it fails. If it accidentally passes, the test is wrong — fix it before writing source.",
	"4. Implement the change in source code.",
	"5. Re-run the test. Confirm it now passes.",
	"6. Run the broader test suite to check for regressions.",
	"",
	"When TDD doesn't apply: pure refactors that should change no behavior, formatting/style-only changes, prose-only edits, exploratory questions, or work in a codebase with no test infrastructure yet (build the test infra first).",
].join("\n");
