/*
 * R5-A inline-completion — Copilot-style ghost-text suggestions driven by
 * `vscode.languages.registerInlineCompletionItemProvider`. Fires on every
 * keystroke (debounced) rather than on pause, so the experience matches what
 * users expect from a production inline-suggestion provider.
 *
 * Sibling module to R2-E `predictive-edit.ts`. That module is opt-in and uses
 * raw editor decorations; this one is on by default and uses the proper VS
 * Code inline-completion API. They coexist: when a predictive-edit ghost is
 * currently visible (`oati.predictionVisible` context key), we skip emitting
 * an inline completion so the two suggestion surfaces don't fight each other.
 *
 * Cost & latency notes:
 *   - Tight token budget (default 80) and temperature 0.2 — completions need
 *     to be quick and deterministic, not creative.
 *   - At most ONE in-flight request per editor. New keystrokes hard-cancel
 *     the prior request via AbortController.
 *   - 30s cache keyed by documentVersion + position + line text so cursor
 *     thrash (left/right arrows, retyping a char) doesn't refetch.
 *   - 200ms debounce after the last keystroke.
 */

import type { ConversationMessage, ProviderSpec } from "@oati/shared";
import * as vscode from "vscode";
import {
	type AuditEntry,
	AuditLog,
	type InlineCompletionAuditEntry,
	nowIso,
	shortHash,
} from "./audit-log";
// R8-A: tab-to-jump, partial-word accept, multi-suggestion cycling, trim
// trailing duplicates — pure helpers live in a sibling file.
import {
	predictNextEditLocation,
	sliceFirstWord,
	trimTrailingDuplicates,
} from "./predict-next-edit-location";
import type { ProviderManager } from "./provider-manager";
import {
	RecentEditsRingBuffer,
	buildEditSnippet,
	formatRecentEditsForPrompt,
	shouldRecordEdit,
} from "./recent-edits";
import type { SettingsStore } from "./settings-store";
import type { KvStorage } from "./storage";

export interface InlineCompletionDeps {
	readonly settings: SettingsStore;
	readonly providerManager: ProviderManager;
	readonly kv: KvStorage;
	readonly log?: vscode.OutputChannel;
	/** Optional injection point for tests — defaults to a workspace-rooted AuditLog. */
	readonly auditLog?: AuditLog;
}

const STATS_KEY = "oati.inlineCompletion.stats";
const PREDICTION_CONTEXT_KEY = "oati.predictionVisible";
const CACHE_TTL_MS = 30_000;
const DEFAULT_DEBOUNCE_MS = 200;
const DEFAULT_MAX_TOKENS = 80;
const DEFAULT_WINDOW_LINES = 50;
const DEFAULT_LANGUAGES: readonly string[] = [
	"typescript",
	"javascript",
	"python",
	"go",
	"rust",
	"java",
	"cpp",
	"csharp",
];
// R8-A: bumped stop list. Triple-newline + closing fence + literal `</code>`.
const STOP_SEQUENCES = ["\n\n\n", "</code>", "```"] as const;
// R8-A: multi-line languages where users want fuller suggestions. The
// per-language max-token override pushes these to 200; everything else
// uses the configured default (80).
const MULTI_LINE_FRIENDLY_LANGUAGES = new Set<string>([
	"typescript",
	"typescriptreact",
	"javascript",
	"javascriptreact",
	"python",
	"rust",
	"go",
]);
const MULTI_LINE_MAX_TOKENS = 200;
// R8-A: multi-suggestion cycling — request N variants at different
// temperatures, cache them, expose alt+] / alt+[ to cycle.
const DEFAULT_MAX_SUGGESTIONS = 3;
const SUGGESTION_TEMPERATURES: readonly number[] = [0.0, 0.2, 0.6];
// R8-A: command ids — surfaced from package.json keybindings so the user can
// rebind freely.
export const ACCEPT_AND_JUMP_COMMAND = "oati.inlineCompletion.acceptAndJump";
export const ACCEPT_WORD_COMMAND = "oati.inlineCompletion.acceptWord";
export const NEXT_SUGGESTION_COMMAND = "oati.inlineCompletion.nextSuggestion";
export const PREV_SUGGESTION_COMMAND = "oati.inlineCompletion.prevSuggestion";

export interface InlineCompletionStats {
	accepted: number;
	rejected: number;
	shown: number;
	lastUpdatedIso: string;
}

interface CacheEntry {
	readonly key: string;
	readonly value: string;
	readonly expiresAt: number;
}

interface BuildFimPromptInput {
	readonly documentText: string;
	readonly offset: number;
	readonly languageId: string;
	readonly windowLines?: number;
	/**
	 * 2026-06-02: optional recent-edits context block from
	 * `formatRecentEditsForPrompt`. When non-empty, included between
	 * the language hint and the prefix/suffix so the model sees what
	 * the user just did in OTHER files. ~200 chars per edit × up to
	 * 3 edits = ~600 chars overhead max.
	 */
	readonly recentEditsBlock?: string;
}

interface BuildFimPromptOutput {
	readonly system: string;
	readonly user: string;
	readonly prefix: string;
	readonly suffix: string;
}

/**
 * Module-level singleton holding the latest acceptance counters. The
 * `inline_completion_stats` tool reads from this without needing to plumb
 * the host context. The values are also mirrored into a Memento so the
 * counters survive window restarts.
 */
let currentStats: InlineCompletionStats = {
	accepted: 0,
	rejected: 0,
	shown: 0,
	lastUpdatedIso: new Date(0).toISOString(),
};

/** Read the current rolling stats. Exposed for the inline_completion_stats tool. */
export function getInlineCompletionStats(): InlineCompletionStats {
	return { ...currentStats };
}

/**
 * 2026-06-02: subscribe to stats updates. Used by the status-bar UI to
 * refresh its label whenever a suggestion is shown / accepted /
 * rejected. Returns a disposable that unregisters the listener.
 */
type StatsListener = (s: InlineCompletionStats) => void;
const statsListeners: Set<StatsListener> = new Set();

export function onInlineCompletionStatsChange(listener: StatsListener): { dispose: () => void } {
	statsListeners.add(listener);
	return {
		dispose: () => {
			statsListeners.delete(listener);
		},
	};
}

function fireStatsChange(): void {
	for (const l of statsListeners) {
		try {
			l({ ...currentStats });
		} catch {
			// Status-bar / listener errors must NOT crash the completion provider.
		}
	}
}

/** Test-only reset. */
export function _resetInlineCompletionStats(): void {
	currentStats = {
		accepted: 0,
		rejected: 0,
		shown: 0,
		lastUpdatedIso: new Date(0).toISOString(),
	};
}

/**
 * Build the FIM (fill-in-the-middle) prompt. Exposed for tests — regressions
 * here directly affect suggestion quality.
 */
export function buildFimPrompt(input: BuildFimPromptInput): BuildFimPromptOutput {
	const window = Math.max(1, input.windowLines ?? DEFAULT_WINDOW_LINES);
	const text = input.documentText;
	const cursor = Math.max(0, Math.min(text.length, input.offset));

	// Walk N lines back/forward from the cursor.
	const prefixStart = walkLinesBackwards(text, cursor, window);
	const suffixEnd = walkLinesForwards(text, cursor, window);

	const prefix = text.slice(prefixStart, cursor);
	const suffix = text.slice(cursor, suffixEnd);

	const hint = languageHint(input.languageId);
	const system = [
		"You are a code-completion engine. Given the prefix and suffix of a file,",
		"return ONLY the literal characters that should be inserted at the cursor.",
		"No prose. No markdown. No code fences. No explanations.",
		"If you cannot suggest anything useful, return an empty response.",
	].join(" ");
	const userParts: string[] = [hint];
	// 2026-06-02: recent-edits block goes BEFORE the prefix/suffix so the
	// model anchors its completion on the cross-file context first, then
	// the current file's local content.
	if (input.recentEditsBlock && input.recentEditsBlock.length > 0) {
		userParts.push(input.recentEditsBlock);
	}
	userParts.push(
		"<prefix>",
		prefix,
		"</prefix>",
		"<cursor/>",
		"<suffix>",
		suffix,
		"</suffix>",
		"",
		"Insertion:",
	);
	const user = userParts.join("\n");

	return { system, user, prefix, suffix };
}

/**
 * Build the cache key for a given completion request. Exposed for tests.
 * Combines document version, cursor offset, and the current line text — that
 * way arrowing left/right on the same line still hits cache, but any edit
 * (which bumps version) invalidates.
 */
export function buildCacheKey(input: {
	uri: string;
	version: number;
	line: number;
	character: number;
	lineText: string;
}): string {
	return [input.uri, input.version, input.line, input.character, shortHash(input.lineText)].join(
		"::",
	);
}

/**
 * Trim a model response at the first occurrence of any stop sequence. The
 * shared provider API doesn't expose stop strings, so we apply them here.
 * Exposed for tests.
 */
export function applyStopSequences(
	text: string,
	stops: readonly string[] = STOP_SEQUENCES,
): string {
	let cut = text.length;
	for (const stop of stops) {
		const idx = text.indexOf(stop);
		if (idx >= 0 && idx < cut) cut = idx;
	}
	return text.slice(0, cut);
}

/**
 * Strip a leading/trailing fence the model sometimes adds in spite of the
 * "no markdown" instruction. Exposed for tests.
 */
export function stripFences(raw: string): string {
	let out = raw;
	out = out.replace(/^```[a-zA-Z0-9_+-]*\r?\n?/, "");
	out = out.replace(/\r?\n?```\s*$/, "");
	return out;
}

function languageHint(languageId: string): string {
	const id = (languageId || "").toLowerCase();
	const tag = COMMENT_BY_LANGUAGE[id] ?? "//";
	const label = LANGUAGE_LABEL[id] ?? capitalize(id || "code");
	return `${tag} ${label} code:`;
}

const LANGUAGE_LABEL: Record<string, string> = {
	typescript: "TypeScript",
	javascript: "JavaScript",
	typescriptreact: "TypeScript",
	javascriptreact: "JavaScript",
	python: "Python",
	go: "Go",
	rust: "Rust",
	java: "Java",
	cpp: "C++",
	c: "C",
	csharp: "C#",
	ruby: "Ruby",
	php: "PHP",
	shellscript: "Shell",
	html: "HTML",
	css: "CSS",
	json: "JSON",
	yaml: "YAML",
	markdown: "Markdown",
};

const COMMENT_BY_LANGUAGE: Record<string, string> = {
	python: "#",
	ruby: "#",
	yaml: "#",
	shellscript: "#",
	r: "#",
	makefile: "#",
	html: "<!--",
	css: "/*",
	markdown: ">",
};

function capitalize(s: string): string {
	if (!s) return s;
	return s[0].toUpperCase() + s.slice(1);
}

function walkLinesBackwards(text: string, from: number, lines: number): number {
	let count = 0;
	let i = from - 1;
	while (i >= 0 && count < lines) {
		if (text.charCodeAt(i) === 10 /* \n */) count++;
		i--;
	}
	return Math.max(0, i + 1);
}

function walkLinesForwards(text: string, from: number, lines: number): number {
	let count = 0;
	let i = from;
	while (i < text.length && count < lines) {
		if (text.charCodeAt(i) === 10 /* \n */) count++;
		i++;
	}
	return i;
}

/**
 * Internal: fetch a completion from the active provider, applying stop
 * sequences and the max-token cap on the client side. Returns the trimmed
 * insertion text or `undefined` if the provider yielded nothing useful.
 */
export async function fetchInlineCompletion(args: {
	provider: ProviderSpec;
	modelId: string;
	system: string;
	user: string;
	maxTokens: number;
	signal: AbortSignal;
	/** R8-A: optional override; defaults to 0.2 to preserve previous behaviour. */
	temperature?: number;
}): Promise<string | undefined> {
	const messages: ConversationMessage[] = [
		{ role: "user", parts: [{ kind: "text", text: args.user }] },
	];
	let out = "";
	const stream = args.provider.stream({
		messages,
		modelId: args.modelId,
		systemPrompt: args.system,
		temperature: args.temperature ?? 0.2,
		maxTokens: args.maxTokens,
		signal: args.signal,
	});
	for await (const ev of stream) {
		if (args.signal.aborted) return undefined;
		if (ev.type === "text_delta") {
			out += ev.text;
			// Early exit: once we've seen a stop sequence in the accumulated
			// output, no point waiting for more tokens.
			let hitStop = false;
			for (const stop of STOP_SEQUENCES) {
				if (out.includes(stop)) {
					hitStop = true;
					break;
				}
			}
			if (hitStop) break;
		} else if (ev.type === "error") {
			return undefined;
		} else if (ev.type === "message_end") {
			break;
		}
	}
	const trimmed = applyStopSequences(stripFences(out)).trimEnd();
	if (!trimmed) return undefined;
	return trimmed;
}

interface CacheStore {
	get(key: string): string | undefined;
	set(key: string, value: string): void;
}

/**
 * Tiny TTL cache. Exposed in factory form so tests can swap the clock.
 */
export function createInlineCompletionCache(now: () => number = () => Date.now()): CacheStore {
	const entries = new Map<string, CacheEntry>();
	return {
		get(key) {
			const e = entries.get(key);
			if (!e) return undefined;
			if (e.expiresAt < now()) {
				entries.delete(key);
				return undefined;
			}
			return e.value;
		},
		set(key, value) {
			entries.set(key, { key, value, expiresAt: now() + CACHE_TTL_MS });
		},
	};
}

/**
 * Coalesce keystroke bursts. Returns a wrapper that resolves the latest
 * invocation after `ms` ms of quiet; earlier pending invocations resolve to
 * `undefined`. Cancellation tokens supplied to earlier calls are NOT aborted
 * by this helper — callers manage their own AbortControllers.
 *
 * Exposed for unit tests.
 */
export function createDebouncer<T>(ms: number): (fn: () => Promise<T>) => Promise<T | undefined> {
	let pending: NodeJS.Timeout | undefined;
	let activeResolve: ((v: T | undefined) => void) | undefined;
	return (fn) => {
		if (pending) clearTimeout(pending);
		if (activeResolve) {
			const r = activeResolve;
			activeResolve = undefined;
			r(undefined);
		}
		return new Promise<T | undefined>((resolve) => {
			activeResolve = resolve;
			pending = setTimeout(() => {
				pending = undefined;
				const r = activeResolve;
				activeResolve = undefined;
				fn().then(
					(v) => r?.(v),
					() => r?.(undefined),
				);
			}, ms);
		});
	};
}

function readConfig(): {
	enabled: boolean;
	debounceMs: number;
	maxTokens: number;
	languages: readonly string[];
	tabToJump: boolean;
	multiSuggestion: boolean;
	maxSuggestions: number;
	/**
	 * 2026-06-02: optional override — when set, autocomplete uses this
	 * model id instead of the chat model. Empty string ⇒ no override.
	 */
	completionModel: string;
	/**
	 * 2026-06-02: optional provider override paired with completionModel.
	 * When set, must match a configured `oati.providers` entry. Empty ⇒
	 * use the same provider as chat.
	 */
	completionProviderId: string;
} {
	const cfg = vscode.workspace.getConfiguration("oati.inlineCompletion");
	return {
		enabled: cfg.get<boolean>("enabled", true),
		debounceMs: Math.max(0, cfg.get<number>("debounceMs", DEFAULT_DEBOUNCE_MS)),
		maxTokens: Math.max(1, cfg.get<number>("maxTokens", DEFAULT_MAX_TOKENS)),
		languages: cfg.get<readonly string[]>("languages", DEFAULT_LANGUAGES),
		// R8-A: Cursor-parity toggles.
		tabToJump: cfg.get<boolean>("tabToJump", true),
		multiSuggestion: cfg.get<boolean>("multiSuggestion", true),
		maxSuggestions: Math.max(
			1,
			Math.min(5, cfg.get<number>("maxSuggestions", DEFAULT_MAX_SUGGESTIONS)),
		),
		completionModel: cfg.get<string>("model", "").trim(),
		completionProviderId: cfg.get<string>("providerId", "").trim(),
	};
}

/**
 * 2026-06-02: resolve the (provider, modelId) pair for an autocomplete
 * request. Three cases:
 *   1. Both `completionModel` and `completionProviderId` empty → use
 *      the chat provider + chat model (preserves prior behavior).
 *   2. Only `completionModel` set → use the chat provider with that
 *      model id (lets users plug a sibling model on the same gateway).
 *   3. Both set → use the named provider with the named model (full
 *      separate-lane setup).
 * Returns undefined when the chosen provider isn't registered — caller
 * falls back to a no-suggestion outcome rather than throwing.
 *
 * Exported for unit testability.
 */
export function resolveCompletionTarget(args: {
	completionModel: string;
	completionProviderId: string;
	chatModelId: string;
	chatProviderId: string;
	providerLookup: (id: string) => ProviderSpec | undefined;
}): { provider: ProviderSpec; modelId: string } | undefined {
	const targetProviderId = args.completionProviderId || args.chatProviderId;
	const targetModelId = args.completionModel || args.chatModelId;
	if (!targetProviderId || !targetModelId) return undefined;
	const provider = args.providerLookup(targetProviderId);
	if (!provider) return undefined;
	return { provider, modelId: targetModelId };
}

/**
 * R8-A: derive a per-request max-token cap. Multi-line-friendly languages get
 * the bumped budget (200) so class bodies / function blocks survive truncation.
 * Exposed for tests.
 */
export function resolveMaxTokens(languageId: string, configured: number): number {
	if (MULTI_LINE_FRIENDLY_LANGUAGES.has((languageId || "").toLowerCase())) {
		return Math.max(configured, MULTI_LINE_MAX_TOKENS);
	}
	return configured;
}

function isPredictionVisible(): boolean {
	// VS Code doesn't expose `getContext`, but the predictive-edit module sets
	// `oati.predictionVisible` exclusively through `setContext`. We mirror its
	// state via a module-local flag, updated by our own listener on focus +
	// keystrokes that would clear it. As a fallback, we treat absence of state
	// as "no prediction visible".
	return predictionVisibleMirror;
}

let predictionVisibleMirror = false;

/**
 * Public hook so the predictive-edit module — or tests — can signal that
 * its ghost-text is visible. We don't import predictive-edit directly to
 * avoid a cycle; instead `extension.ts` calls this when wiring up.
 */
export function notifyPredictionVisible(visible: boolean): void {
	predictionVisibleMirror = visible;
}

// R8-A: ─────────────────────────────────────────────────────────────────────
// Multi-suggestion cycling state machine. Pure data structure + a few helpers
// so tests can exercise the rotation logic without booting VS Code.
// ─────────────────────────────────────────────────────────────────────────────

export interface MultiSuggestionState {
	/** All variants returned for the last `provideInlineCompletionItems` call. */
	readonly variants: readonly string[];
	/** Currently-presented variant index. */
	index: number;
	/** Key tying this carousel to a (uri, version, line, character) tuple. */
	readonly key: string;
}

/**
 * Create a fresh multi-suggestion carousel. Returns `undefined` if the
 * variants list is empty (caller should bail).
 */
export function createMultiSuggestionState(
	key: string,
	variants: readonly string[],
): MultiSuggestionState | undefined {
	const unique = dedupeVariants(variants);
	if (unique.length === 0) return undefined;
	return { key, variants: unique, index: 0 };
}

/** Rotate the carousel. Wraps around. */
export function cycleSuggestion(
	state: MultiSuggestionState,
	direction: 1 | -1,
): MultiSuggestionState {
	if (state.variants.length === 0) return state;
	const next = (state.index + direction + state.variants.length) % state.variants.length;
	return { ...state, index: next };
}

/** Return the current text. */
export function currentSuggestion(state: MultiSuggestionState): string {
	return state.variants[state.index] ?? "";
}

function dedupeVariants(variants: readonly string[]): string[] {
	const seen = new Set<string>();
	const out: string[] = [];
	for (const v of variants) {
		const trimmed = v.trimEnd();
		if (!trimmed) continue;
		if (seen.has(trimmed)) continue;
		seen.add(trimmed);
		out.push(trimmed);
	}
	return out;
}

// R8-A: ─────────────────────────────────────────────────────────────────────
// Partial word-by-word accept state machine. Holds the pending tail of the
// currently-visible suggestion, slicing off one word per `acceptWord` call.
// ─────────────────────────────────────────────────────────────────────────────

export interface PartialAcceptState {
	/** Remaining text the user has NOT yet committed. */
	pending: string;
	/** Key tying the state to (uri, line, character of the original anchor). */
	readonly anchorKey: string;
}

/**
 * Pop one word off the pending tail. Returns the consumed slice and the
 * mutated state (immutable update — returns a fresh object).
 *
 * Exposed for unit tests.
 */
export function popPartialWord(state: PartialAcceptState): {
	consumed: string;
	next: PartialAcceptState;
} {
	const { word, rest } = sliceFirstWord(state.pending);
	return {
		consumed: word,
		next: { anchorKey: state.anchorKey, pending: rest },
	};
}

/** Construct a fresh partial-accept state from a full suggestion + anchor. */
export function createPartialAcceptState(anchorKey: string, fullText: string): PartialAcceptState {
	return { anchorKey, pending: fullText };
}

// Re-export pure heuristics so the tools package + tests have a single import.
export { predictNextEditLocation, sliceFirstWord, trimTrailingDuplicates };

/**
 * Register the inline-completion provider against all languages. Returns a
 * Disposable that the caller pushes onto `context.subscriptions`.
 */
export function registerInlineCompletion(
	context: vscode.ExtensionContext,
	deps: InlineCompletionDeps,
): vscode.Disposable {
	// Hydrate the stats singleton from storage so the counters persist across
	// window restarts.
	const persisted = deps.kv.get<InlineCompletionStats>(STATS_KEY);
	if (persisted) currentStats = { ...currentStats, ...persisted };

	const cache = createInlineCompletionCache();
	const debouncers = new Map<string, ReturnType<typeof createDebouncer<string | undefined>>>();
	const inFlight = new Map<string, AbortController>();

	const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
	const auditLog = deps.auditLog ?? (workspaceRoot ? new AuditLog(workspaceRoot) : undefined);

	// Track which suggestion id corresponds to which insertion text so we can
	// classify accept vs reject on the next interaction.
	const pendingSuggestions = new Map<string, { id: string; text: string; shownAt: number }>();

	// R8-A: per-editor multi-suggestion carousel + partial-word accept state.
	// Keyed by document URI — only one suggestion may be visible per editor
	// at a time, so a single slot per URI is enough.
	const carousels = new Map<string, MultiSuggestionState>();
	const partials = new Map<string, PartialAcceptState>();

	// 2026-06-02: cross-file recent-edits buffer. Populated from the
	// existing onDidChangeTextDocument listener (which is already wired
	// up for accept-detection); fed into the FIM prompt so completions
	// in file A see what the user just typed in file B.
	const recentEdits = new RecentEditsRingBuffer();

	const persistStats = (): void => {
		void deps.kv.update(STATS_KEY, currentStats);
		// 2026-06-02: also fire the in-process listener channel so the
		// status-bar UI can refresh its label without polling.
		fireStatsChange();
	};

	const recordAudit = (
		event: InlineCompletionAuditEntry["event"],
		extra: Partial<InlineCompletionAuditEntry> = {},
	): void => {
		if (!auditLog) return;
		const entry: InlineCompletionAuditEntry = {
			kind: "inline_completion",
			ts: nowIso(),
			event,
			languageId: extra.languageId ?? "",
			suggestionBytes: extra.suggestionBytes ?? 0,
			latencyMs: extra.latencyMs ?? 0,
		};
		void auditLog.record(entry as AuditEntry);
	};

	const provider: vscode.InlineCompletionItemProvider = {
		async provideInlineCompletionItems(document, position, _ctx, token) {
			const cfg = readConfig();
			if (!cfg.enabled) return undefined;
			if (cfg.languages.length > 0 && !cfg.languages.includes(document.languageId)) {
				return undefined;
			}
			if (isPredictionVisible()) return undefined;
			if (token.isCancellationRequested) return undefined;

			const lineText = document.lineAt(position.line).text;
			const cacheKey = buildCacheKey({
				uri: document.uri.toString(),
				version: document.version,
				line: position.line,
				character: position.character,
				lineText,
			});

			const editorKey = document.uri.toString();

			// R8-A: cache hit short-circuits — no network, no debounce. The
			// cache value is now a list of variants (JSON-encoded). Old single
			// strings still parse via the legacy branch below. If the user has
			// already cycled to a non-zero index on the same carousel, honour
			// that selection rather than always resetting to variant[0].
			const cached = cache.get(cacheKey);
			if (cached) {
				const variants = decodeCachedVariants(cached);
				if (variants.length > 0) {
					const existing = carousels.get(editorKey);
					const sameCarousel = existing?.key === cacheKey ? existing : undefined;
					const carousel = sameCarousel ?? createMultiSuggestionState(cacheKey, variants);
					if (carousel) carousels.set(editorKey, carousel);
					const text = carousel ? currentSuggestion(carousel) : variants[0];
					return makeList(text, position, pendingSuggestions, editorKey, partials);
				}
			}

			// Cancel any in-flight request for this editor — keystrokes have moved on.
			const prior = inFlight.get(editorKey);
			if (prior) prior.abort();
			const ctrl = new AbortController();
			inFlight.set(editorKey, ctrl);

			// Hard-cancel when VS Code aborts us.
			const tokenSub = token.onCancellationRequested(() => ctrl.abort());

			let debouncer = debouncers.get(editorKey);
			if (!debouncer) {
				debouncer = createDebouncer<string | undefined>(cfg.debounceMs);
				debouncers.set(editorKey, debouncer);
			}

			const startedAt = Date.now();
			try {
				const variants = await debouncer(async () => {
					if (ctrl.signal.aborted) return undefined;
					const settingsCfg = deps.settings.config;
					const chatModelId = deps.providerManager.resolveActiveModelId(settingsCfg);
					if (!chatModelId) return undefined;
					const chatProviderId =
						settingsCfg.modes.find((m) => m.id === settingsCfg.activeModeId)?.providerId ??
						settingsCfg.activeProviderId;
					// 2026-06-02: resolve a separate (provider, model) pair for
					// the autocomplete lane when configured. Lets users plug a
					// fast small model for completion while keeping a frontier
					// model on chat — the Cursor pattern.
					const target = resolveCompletionTarget({
						completionModel: cfg.completionModel,
						completionProviderId: cfg.completionProviderId,
						chatModelId,
						chatProviderId,
						providerLookup: (id) => deps.providerManager.registry.get(id),
					});
					if (!target) return undefined;
					const providerSpec = target.provider;
					const modelId = target.modelId;

					// 2026-06-02: pull up to 3 recent edits from OTHER files
					// to splice into the FIM context. Excludes the current
					// file's own edits since the model already sees that
					// content via the prefix/suffix window.
					const cross = recentEdits.getRecent({
						limit: 3,
						excludePath: document.uri.fsPath,
					});
					const fim = buildFimPrompt({
						documentText: document.getText(),
						offset: document.offsetAt(position),
						languageId: document.languageId,
						recentEditsBlock: formatRecentEditsForPrompt(cross),
					});
					const tokensCap = resolveMaxTokens(document.languageId, cfg.maxTokens);
					// R8-A: multi-suggestion fan-out. When enabled, request N
					// variants at staggered temperatures. Otherwise fall back to
					// the single-shot legacy path.
					if (cfg.multiSuggestion && cfg.maxSuggestions > 1) {
						const temps = SUGGESTION_TEMPERATURES.slice(0, cfg.maxSuggestions);
						const results = await Promise.all(
							temps.map((temperature) =>
								fetchInlineCompletion({
									provider: providerSpec,
									modelId,
									system: fim.system,
									user: fim.user,
									maxTokens: tokensCap,
									signal: ctrl.signal,
									temperature,
								}).catch(() => undefined),
							),
						);
						const trimmed = results
							.filter((r): r is string => typeof r === "string" && r.length > 0)
							.map((r) => trimTrailingDuplicates(r, fim.suffix));
						return JSON.stringify(trimmed);
					}
					const out = await fetchInlineCompletion({
						provider: providerSpec,
						modelId,
						system: fim.system,
						user: fim.user,
						maxTokens: tokensCap,
						signal: ctrl.signal,
					});
					if (!out) return undefined;
					return JSON.stringify([trimTrailingDuplicates(out, fim.suffix)]);
				});

				if (!variants || ctrl.signal.aborted) return undefined;
				const variantList = decodeCachedVariants(variants);
				if (variantList.length === 0) return undefined;
				cache.set(cacheKey, variants);
				const carousel = createMultiSuggestionState(cacheKey, variantList);
				if (carousel) carousels.set(editorKey, carousel);
				const first = variantList[0];
				currentStats = {
					...currentStats,
					shown: currentStats.shown + 1,
					lastUpdatedIso: new Date().toISOString(),
				};
				persistStats();
				recordAudit("shown", {
					languageId: document.languageId,
					suggestionBytes: Buffer.byteLength(first, "utf-8"),
					latencyMs: Date.now() - startedAt,
				});
				return makeList(first, position, pendingSuggestions, editorKey, partials);
			} catch (err) {
				deps.log?.appendLine(
					`[inline-completion] failed: ${err instanceof Error ? err.message : String(err)}`,
				);
				return undefined;
			} finally {
				tokenSub.dispose();
				if (inFlight.get(editorKey) === ctrl) inFlight.delete(editorKey);
			}
		},
	};

	// VS Code 1.92+ exposes optional `handleDidShowCompletionItem` and
	// `handleDidPartiallyAcceptCompletionItem` hooks via the provider interface.
	// We assign them dynamically since the lib.d.ts in the workspace may not
	// declare them — they're harmless extras and VS Code probes for them via
	// `typeof provider.X === 'function'`.
	const enrichedProvider = provider as unknown as Record<string, unknown>;
	enrichedProvider.handleDidShowCompletionItem = (item: vscode.InlineCompletionItem): void => {
		const text = typeof item.insertText === "string" ? item.insertText : item.insertText.value;
		// no-op; counted at fetch time via `shown`.
		void text;
	};

	// Wire accept/reject via the `commands.onDidExecuteCommand`-style trick is
	// not available; instead, we register a command that VS Code triggers when
	// the user accepts an inline suggestion. The selection-change listener
	// classifies dismissal (cursor moved away without an accept) as a reject.
	const onSelChange = vscode.window.onDidChangeTextEditorSelection(() => {
		// Pending suggestions older than 5s are presumed rejected.
		const now = Date.now();
		for (const [key, sug] of pendingSuggestions) {
			if (now - sug.shownAt > 5000) {
				pendingSuggestions.delete(key);
				currentStats = {
					...currentStats,
					rejected: currentStats.rejected + 1,
					lastUpdatedIso: new Date().toISOString(),
				};
				persistStats();
				recordAudit("rejected", { suggestionBytes: Buffer.byteLength(sug.text, "utf-8") });
			}
		}
	});

	const onDocChange = vscode.workspace.onDidChangeTextDocument((ev) => {
		// If a recent suggestion's text appears in this insertion, count as accept.
		const inserted = ev.contentChanges.map((c) => c.text).join("");
		if (!inserted) return;
		// 2026-06-02: also record the edit for cross-file completion context.
		// Skip bulk writes (agent batch edits, large pastes) per
		// shouldRecordEdit — those would flood the buffer with one
		// signal-poor entry each.
		if (shouldRecordEdit(inserted.length) && ev.contentChanges.length > 0) {
			const firstChange = ev.contentChanges[0];
			const offset = ev.document.offsetAt(firstChange.range.start);
			recentEdits.push({
				path: ev.document.uri.fsPath,
				languageId: ev.document.languageId,
				snippet: buildEditSnippet(ev.document.getText(), offset),
			});
		}
		// R7-C bug fix: the original `sug.text.startsWith(inserted)` heuristic
		// fired whenever the user typed a short string (e.g. a single space)
		// that happened to be a prefix of the suggestion — inflating the
		// `accepted` counter to garbage. Require the inserted text to be at
		// least as long as the suggestion (full accept) OR to actually contain
		// the entire suggestion. Partial accepts are reported separately via
		// VS Code's `handleDidPartiallyAcceptCompletionItem` callback.
		const MIN_ACCEPT_BYTES = 3;
		if (inserted.length < MIN_ACCEPT_BYTES) return;
		for (const [key, sug] of pendingSuggestions) {
			const isFullAccept = inserted.includes(sug.text);
			if (isFullAccept) {
				pendingSuggestions.delete(key);
				currentStats = {
					...currentStats,
					accepted: currentStats.accepted + 1,
					lastUpdatedIso: new Date().toISOString(),
				};
				persistStats();
				recordAudit("accepted", {
					languageId: ev.document.languageId,
					suggestionBytes: Buffer.byteLength(sug.text, "utf-8"),
				});
				return;
			}
		}
	});

	const registration = vscode.languages.registerInlineCompletionItemProvider(
		{ pattern: "**/*" },
		provider,
	);

	const toggleCmd = vscode.commands.registerCommand("oati.toggleInlineCompletion", async () => {
		const cfg = vscode.workspace.getConfiguration("oati.inlineCompletion");
		const next = !cfg.get<boolean>("enabled", true);
		await cfg.update("enabled", next, vscode.ConfigurationTarget.Global);
		vscode.window.showInformationMessage(`OATI inline completion ${next ? "enabled" : "disabled"}.`);
	});

	// R8-A: tab-to-jump command. Fired by VS Code after the user accepts an
	// inline suggestion (we wired the command field on the item itself).
	// Heuristic: find the next placeholder / TODO / blank slot below the
	// cursor, move the caret there, then trigger a fresh inline completion.
	const acceptAndJumpCmd = vscode.commands.registerCommand(
		ACCEPT_AND_JUMP_COMMAND,
		async (args?: { acceptedText?: string }) => {
			const cfg = readConfig();
			if (!cfg.tabToJump) return;
			const editor = vscode.window.activeTextEditor;
			if (!editor) return;
			const doc = editor.document;
			const pos = editor.selection.active;
			const target = predictNextEditLocation({
				documentText: doc.getText(),
				currentOffset: doc.offsetAt(pos),
				languageId: doc.languageId,
			});
			deps.log?.appendLine(
				`[inline-completion] tab-to-jump: ${target.reason} (${args?.acceptedText?.length ?? 0} bytes accepted)`,
			);
			// Only move when the new offset is meaningfully ahead — otherwise
			// the cursor flickers in place.
			if (target.offset > doc.offsetAt(pos)) {
				const newPos = doc.positionAt(target.offset);
				editor.selection = new vscode.Selection(newPos, newPos);
				editor.revealRange(new vscode.Range(newPos, newPos));
			}
			// Kick off a fresh inline suggestion at the new location.
			await vscode.commands.executeCommand("editor.action.inlineSuggest.trigger");
		},
	);

	// R8-A: partial word-by-word accept (cmd+right / ctrl+right while a
	// suggestion is visible). Pops one word off the pending tail and inserts
	// it; remainder stays visible as ghost text on the next provider call.
	const acceptWordCmd = vscode.commands.registerCommand(ACCEPT_WORD_COMMAND, async () => {
		const editor = vscode.window.activeTextEditor;
		if (!editor) return;
		const editorKey = editor.document.uri.toString();
		const state = partials.get(editorKey);
		if (!state || state.pending.length === 0) {
			// No pending suggestion — fall back to normal word-right.
			await vscode.commands.executeCommand("cursorWordEndRight");
			return;
		}
		const { consumed, next } = popPartialWord(state);
		if (!consumed) {
			partials.delete(editorKey);
			await vscode.commands.executeCommand("cursorWordEndRight");
			return;
		}
		const pos = editor.selection.active;
		await editor.edit((eb) => {
			eb.insert(pos, consumed);
		});
		// Update state — if anything is left, keep it for the next call.
		if (next.pending.length === 0) {
			partials.delete(editorKey);
		} else {
			partials.set(editorKey, next);
			// Re-trigger so VS Code re-renders the ghost text with the remainder.
			await vscode.commands.executeCommand("editor.action.inlineSuggest.trigger");
		}
	});

	const nextSuggestionCmd = vscode.commands.registerCommand(NEXT_SUGGESTION_COMMAND, async () => {
		await rotateAndShow(1);
	});
	const prevSuggestionCmd = vscode.commands.registerCommand(PREV_SUGGESTION_COMMAND, async () => {
		await rotateAndShow(-1);
	});

	const rotateAndShow = async (direction: 1 | -1): Promise<void> => {
		const editor = vscode.window.activeTextEditor;
		if (!editor) return;
		const editorKey = editor.document.uri.toString();
		const state = carousels.get(editorKey);
		if (!state || state.variants.length <= 1) {
			// Nothing to cycle — defer to VS Code's built-in next/prev (which
			// has no concept of OUR carousel but at least won't no-op silently).
			const cmd =
				direction > 0
					? "editor.action.inlineSuggest.showNext"
					: "editor.action.inlineSuggest.showPrevious";
			await vscode.commands.executeCommand(cmd);
			return;
		}
		const rotated = cycleSuggestion(state, direction);
		carousels.set(editorKey, rotated);
		// Reset partial-accept state for the new variant so cmd+right starts
		// fresh on the now-visible suggestion.
		const anchor = editor.selection.active;
		partials.set(
			editorKey,
			createPartialAcceptState(
				`${editorKey}::${anchor.line}:${anchor.character}`,
				currentSuggestion(rotated),
			),
		);
		// Forces VS Code to re-query the provider, which returns the rotated text.
		await vscode.commands.executeCommand("editor.action.inlineSuggest.trigger");
	};

	const disposable = vscode.Disposable.from(
		registration,
		onSelChange,
		onDocChange,
		toggleCmd,
		acceptAndJumpCmd,
		acceptWordCmd,
		nextSuggestionCmd,
		prevSuggestionCmd,
		{
			dispose: () => {
				for (const ctrl of inFlight.values()) ctrl.abort();
				inFlight.clear();
				debouncers.clear();
				pendingSuggestions.clear();
				carousels.clear();
				partials.clear();
			},
		},
	);
	context.subscriptions.push(disposable);
	return disposable;
}

// R7-C bug fix: hard cap on the pendingSuggestions map. The previous
// implementation only evicted stale entries on selection change; if the user
// typed steadily without moving the cursor, the map could accumulate
// suggestions indefinitely. Cap at the most recent 32 suggestions per editor.
const PENDING_SUGGESTIONS_CAP = 32;

function makeList(
	text: string,
	position: vscode.Position,
	pending: Map<string, { id: string; text: string; shownAt: number }>,
	// R8-A: when provided, the returned item carries a `command` field firing
	// `acceptAndJump` after the user takes the suggestion. The editorKey is
	// also used to seed the partial-accept state map so cmd+right works.
	editorKey?: string,
	partials?: Map<string, PartialAcceptState>,
): vscode.InlineCompletionList {
	const item: vscode.InlineCompletionItem = {
		insertText: text,
		range: new vscode.Range(position, position),
	};
	// R8-A: attach the post-accept jump command. VS Code fires `command.command`
	// after the inline-suggest accept completes — perfect hook for tab-to-jump.
	const cfg = vscode.workspace?.getConfiguration?.("oati.inlineCompletion");
	const tabToJump = cfg?.get<boolean>("tabToJump", true) ?? true;
	if (tabToJump) {
		item.command = {
			title: "OATI: jump to next edit",
			command: ACCEPT_AND_JUMP_COMMAND,
			arguments: [{ acceptedText: text }],
		};
	}
	// R8-A: seed the partial-accept state machine so cmd+right can pop words
	// off the same suggestion the user is looking at.
	if (editorKey && partials) {
		const anchorKey = `${editorKey}::${position.line}:${position.character}`;
		partials.set(editorKey, createPartialAcceptState(anchorKey, text));
	}
	const id = `${position.line}:${position.character}:${shortHash(text)}`;
	pending.set(id, { id, text, shownAt: Date.now() });
	// Map iteration is insertion-ordered, so dropping the first N entries
	// removes the oldest suggestions — exactly what we want.
	while (pending.size > PENDING_SUGGESTIONS_CAP) {
		const first = pending.keys().next();
		if (first.done) break;
		pending.delete(first.value);
	}
	return { items: [item] };
}

/**
 * Decode the cached suggestion variants. The cache stores a JSON array of
 * strings to support multi-suggestion cycling; legacy single-string entries
 * (from earlier R5-A code paths) are coerced into a 1-element array.
 *
 * Exposed for unit tests.
 */
export function decodeCachedVariants(raw: string): string[] {
	if (!raw) return [];
	if (raw.startsWith("[")) {
		try {
			const parsed = JSON.parse(raw) as unknown;
			if (Array.isArray(parsed)) {
				const out: string[] = [];
				for (const v of parsed) {
					if (typeof v === "string" && v.length > 0) out.push(v);
				}
				return out;
			}
		} catch {
			// fall through — treat as a literal string.
		}
	}
	return [raw];
}

// Re-export the context key so the predictive-edit module (and tests) can use
// the same string without hard-coding it twice.
export const INLINE_COMPLETION_STATS_KEY = STATS_KEY;
export const INLINE_COMPLETION_PREDICTION_KEY = PREDICTION_CONTEXT_KEY;
