import type { DiffHunk, DiffPreview, HunkStatus, InlineDiffSessionState } from "@oati/shared";
import {
	createInlineDiffSession,
	isFullyResolved,
	resolveAcceptedText,
	setHunkStatus,
} from "@oati/shared";
import * as vscode from "vscode";

/**
 * Inline-diff feature. Surfaces an agent's proposed `write_file` / edit as
 * in-editor decorations (green added lines, red removed) and a floating Code
 * Lens above each hunk with Accept / Reject / Modify actions.
 *
 * Phase 3.3 (2026-06-04): the pure hunk model + LCS + state machine moved
 * to `@oati/shared/diff` so the webview's approval modal renders the
 * same diff quality as the post-write inline-diff session. This file is
 * now VS Code wiring only.
 */

// Re-exported here for the host-side callers that still reach for these.
export type { DiffHunk, HunkStatus, InlineDiffSessionState };
export { createInlineDiffSession, isFullyResolved, resolveAcceptedText, setHunkStatus };

/** Compute the hunks between two snapshots. */
export { computeHunks } from "@oati/shared";

/**
 * Decide which inline-diff path to take based on the active mode. Modes
 * that explicitly auto-approve tools default to auto-apply; everyone else
 * defaults to review. An explicit `inlineDiffMode` on the mode wins.
 */
export function pickInlineDiffMode(mode: {
	readonly autoApprove?: boolean;
	readonly inlineDiffMode?: "auto-apply" | "review";
}): "auto-apply" | "review" {
	if (mode.inlineDiffMode) return mode.inlineDiffMode;
	return mode.autoApprove ? "auto-apply" : "review";
}

// ---------------------------------------------------------------------------
// VS Code wiring
// ---------------------------------------------------------------------------

interface InlineDiffControllerOptions {
	readonly log?: vscode.OutputChannel;
}

/**
 * Live session bound to a TextDocument. Owns:
 *   - the editor decorations (green-added / red-removed gutter strips),
 *   - a CodeLensProvider that emits Accept / Reject / Modify lenses above
 *     each hunk,
 *   - per-hunk command handlers that mutate the underlying file via
 *     `vscode.workspace.applyEdit`.
 *
 * A session disposes itself once every hunk has been resolved, or when the
 * caller calls `dispose()` explicitly (e.g. the user discarded the proposal).
 */
class InlineDiffSession {
	private state: InlineDiffSessionState;
	private readonly modifications = new Map<string, string>();
	private readonly addedDecoration: vscode.TextEditorDecorationType;
	private readonly removedDecoration: vscode.TextEditorDecorationType;
	private readonly onChange = new vscode.EventEmitter<void>();
	readonly onDidChange = this.onChange.event;

	constructor(
		readonly uri: vscode.Uri,
		diff: DiffPreview,
		private readonly log?: vscode.OutputChannel,
	) {
		this.state = createInlineDiffSession(diff);
		this.addedDecoration = vscode.window.createTextEditorDecorationType({
			backgroundColor: "rgba(46, 160, 67, 0.18)",
			isWholeLine: true,
			overviewRulerColor: "rgba(46, 160, 67, 0.7)",
			overviewRulerLane: vscode.OverviewRulerLane.Right,
			gutterIconPath: undefined,
		});
		this.removedDecoration = vscode.window.createTextEditorDecorationType({
			backgroundColor: "rgba(248, 81, 73, 0.18)",
			isWholeLine: true,
			overviewRulerColor: "rgba(248, 81, 73, 0.7)",
			overviewRulerLane: vscode.OverviewRulerLane.Right,
		});
	}

	get path(): string {
		return this.state.path;
	}

	getState(): InlineDiffSessionState {
		return this.state;
	}

	/** Apply decorations to every visible editor that hosts our document. */
	refreshDecorations(): void {
		const editors = vscode.window.visibleTextEditors.filter(
			(e) => e.document.uri.toString() === this.uri.toString(),
		);
		const added: vscode.Range[] = [];
		const removed: vscode.Range[] = [];
		for (const h of this.state.hunks) {
			const status = this.state.status[h.id] ?? "pending";
			if (status !== "pending") continue;
			if (h.addedLines.length > 0) {
				added.push(new vscode.Range(h.afterStartLine, 0, h.afterEndLine, Number.MAX_SAFE_INTEGER));
			}
			if (h.removedLines.length > 0 && h.addedLines.length === 0) {
				// Pure deletion — show the marker on the line where the removal
				// would land in the after-buffer.
				removed.push(new vscode.Range(h.afterStartLine, 0, h.afterStartLine, 0));
			}
		}
		for (const ed of editors) {
			ed.setDecorations(this.addedDecoration, added);
			ed.setDecorations(this.removedDecoration, removed);
		}
	}

	/** Provide CodeLenses for the document this session owns. */
	provideCodeLenses(document: vscode.TextDocument): vscode.CodeLens[] {
		if (document.uri.toString() !== this.uri.toString()) return [];
		const lenses: vscode.CodeLens[] = [];
		for (const h of this.state.hunks) {
			const status = this.state.status[h.id] ?? "pending";
			if (status !== "pending") continue;
			const range = new vscode.Range(h.afterStartLine, 0, h.afterStartLine, 0);
			lenses.push(
				new vscode.CodeLens(range, {
					title: `OATI: Accept (+${h.addedLines.length}/-${h.removedLines.length})`,
					command: "oati.inlineDiff.accept",
					arguments: [this.uri.toString(), h.id],
				}),
				new vscode.CodeLens(range, {
					title: "Reject",
					command: "oati.inlineDiff.reject",
					arguments: [this.uri.toString(), h.id],
				}),
				new vscode.CodeLens(range, {
					title: "Modify",
					command: "oati.inlineDiff.modify",
					arguments: [this.uri.toString(), h.id],
				}),
			);
		}
		return lenses;
	}

	async accept(hunkId: string): Promise<void> {
		await this.applyHunkResolution(hunkId, "accepted");
	}

	async reject(hunkId: string): Promise<void> {
		await this.applyHunkResolution(hunkId, "rejected");
	}

	async modify(hunkId: string): Promise<void> {
		const hunk = this.state.hunks.find((h) => h.id === hunkId);
		if (!hunk) return;
		const prefilled = hunk.addedLines.join("\n");
		const next = await vscode.window.showInputBox({
			prompt: `Edit replacement for ${this.state.path}`,
			value: prefilled,
			validateInput: () => undefined,
		});
		if (next === undefined) return; // user cancelled — leave hunk pending
		this.modifications.set(hunkId, next);
		await this.applyHunkResolution(hunkId, "modified");
	}

	private async applyHunkResolution(hunkId: string, status: HunkStatus): Promise<void> {
		this.state = setHunkStatus(this.state, hunkId, status);
		this.log?.appendLine(`[inline-diff] ${status} ${this.path}#${hunkId}`);
		// Recompute the file's contents and apply as a workspace edit.
		const mods: Record<string, string> = {};
		for (const [id, txt] of this.modifications) mods[id] = txt;
		const desired = resolveAcceptedText(this.state, mods);
		try {
			const doc = await vscode.workspace.openTextDocument(this.uri);
			const wholeRange = new vscode.Range(
				new vscode.Position(0, 0),
				new vscode.Position(doc.lineCount, 0),
			);
			const edit = new vscode.WorkspaceEdit();
			edit.replace(this.uri, wholeRange, desired);
			await vscode.workspace.applyEdit(edit);
		} catch (err) {
			this.log?.appendLine(
				`[inline-diff] failed to apply edit to ${this.path}: ${
					err instanceof Error ? err.message : String(err)
				}`,
			);
		}
		this.refreshDecorations();
		this.onChange.fire();
	}

	dispose(): void {
		// Clearing the decoration types is enough — VS Code removes the visuals
		// from every editor automatically. The CodeLensProvider notices we're
		// gone via the registry and stops emitting lenses.
		this.addedDecoration.dispose();
		this.removedDecoration.dispose();
		this.onChange.dispose();
	}
}

/**
 * Top-level controller registered as a CodeLensProvider for "all files".
 * It tracks one InlineDiffSession per URI; the chat-panel calls
 * `present(diff)` whenever the agent emits a diff and the active mode is in
 * `review` mode.
 */
export class InlineDiffController implements vscode.CodeLensProvider {
	private readonly sessions = new Map<string, InlineDiffSession>();
	private readonly onDidChangeCodeLensesEmitter = new vscode.EventEmitter<void>();
	readonly onDidChangeCodeLenses = this.onDidChangeCodeLensesEmitter.event;
	private readonly log?: vscode.OutputChannel;

	constructor(opts: InlineDiffControllerOptions = {}) {
		this.log = opts.log;
	}

	provideCodeLenses(document: vscode.TextDocument): vscode.CodeLens[] {
		const key = document.uri.toString();
		const session = this.sessions.get(key);
		if (!session) return [];
		return session.provideCodeLenses(document);
	}

	/**
	 * Begin reviewing a diff inline. The file at `diff.path` must exist (the
	 * caller is expected to write the agent's *after* version to disk first
	 * so users see the proposed lines and can accept/reject them piecewise).
	 *
	 * When `openInEditor` is false, the session is still registered and the
	 * Code Lens provider stays armed — decorations + Accept/Reject lenses
	 * will appear the moment the user manually opens the file. This is the
	 * silent-writes default: don't pop the file open, but the review UI
	 * waits for the user to navigate there.
	 */
	async present(
		diff: DiffPreview,
		workspaceRoot: string | undefined,
		opts: { openInEditor?: boolean } = {},
	): Promise<void> {
		const uri = await this.resolveUri(diff.path, workspaceRoot);
		if (!uri) {
			this.log?.appendLine(`[inline-diff] cannot resolve URI for ${diff.path}`);
			return;
		}
		const key = uri.toString();
		const existing = this.sessions.get(key);
		if (existing) existing.dispose();
		const session = new InlineDiffSession(uri, diff, this.log);
		this.sessions.set(key, session);
		session.onDidChange(() => {
			if (isFullyResolved(session.getState())) {
				session.dispose();
				this.sessions.delete(key);
			}
			this.onDidChangeCodeLensesEmitter.fire();
		});
		if (opts.openInEditor !== false) {
			await vscode.window.showTextDocument(uri, { preview: false, preserveFocus: true });
		}
		session.refreshDecorations();
		this.onDidChangeCodeLensesEmitter.fire();
	}

	getSession(uriString: string): InlineDiffSession | undefined {
		return this.sessions.get(uriString);
	}

	async handleAccept(uriString: string, hunkId: string): Promise<void> {
		await this.sessions.get(uriString)?.accept(hunkId);
	}

	async handleReject(uriString: string, hunkId: string): Promise<void> {
		await this.sessions.get(uriString)?.reject(hunkId);
	}

	async handleModify(uriString: string, hunkId: string): Promise<void> {
		await this.sessions.get(uriString)?.modify(hunkId);
	}

	dispose(): void {
		for (const s of this.sessions.values()) s.dispose();
		this.sessions.clear();
		this.onDidChangeCodeLensesEmitter.dispose();
	}

	private async resolveUri(
		rawPath: string,
		workspaceRoot: string | undefined,
	): Promise<vscode.Uri | undefined> {
		const isAbsolute = /^[a-zA-Z]:[\\/]/.test(rawPath) || rawPath.startsWith("/");
		let uri: vscode.Uri;
		if (isAbsolute) {
			uri = vscode.Uri.file(rawPath);
		} else if (workspaceRoot) {
			uri = vscode.Uri.file(joinPath(workspaceRoot, rawPath));
		} else {
			const folders = vscode.workspace.workspaceFolders ?? [];
			if (folders.length === 0) return undefined;
			uri = vscode.Uri.joinPath(folders[0].uri, rawPath);
		}
		return uri;
	}
}

// ---------------------------------------------------------------------------
// Private helpers
// ---------------------------------------------------------------------------

function joinPath(root: string, relative: string): string {
	const sep = root.includes("\\") ? "\\" : "/";
	if (root.endsWith(sep)) return `${root}${relative}`;
	return `${root}${sep}${relative}`;
}
