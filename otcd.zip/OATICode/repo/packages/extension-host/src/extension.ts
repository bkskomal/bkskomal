import * as path from "node:path";
import { Conductor, ToolRegistry } from "@oati/agent-core";
import type { SessionMeta } from "@oati/shared";
// R2-B: status bar + background tasks (appended imports; do not reorder).
import { estimateCost } from "@oati/shared";
// R5-A: inject the inline-completion stats reader into the tools package so the
// inline_completion_stats tool can surface live counters.
import { _setInlineCompletionStatsReader, builtinTools } from "@oati/tools";
import * as vscode from "vscode";
import { BackgroundTaskRunner } from "./background-tasks";
import { ChatPanel } from "./chat-panel";
import { AiCodeLensProvider, extractSymbolBody } from "./code-lens";
import { CodebaseIndexManager } from "./codebase-index-manager";
// R6-C: AI commit message generation + PR watcher.
import {
	EmptyDiffError,
	formatCommitMessage,
	generateCommitMessage,
	pickPrimaryRepo,
} from "./commit-message";
// R6-E: debug bridge — activate the DAP tracker + state-change broadcaster.
import { activateDebugBridge } from "./debug-bridge";
// R4-B: diagnostics pill — tally helper used by the workspace-wide broadcaster.
import { tallyDiagnostics } from "./diagnostics-bridge";
import { OATI_DIFF_SCHEME, OatiDiffContentProvider, openDiffEditor } from "./diff-provider";
// R7-B: e2e test-only command helpers. No-ops unless OATI_E2E=1.
import { registerE2eHelpers } from "./e2e-helpers";
// R5-A: inline completion provider.
import { maybeShowFimSuggestion } from "./fim-auto-detect";
import { createHostContext, wrapHostForSubAgent } from "./host-context";
// R2-E: share session + hover-explain + predictive-edit modules.
import { registerHoverExplain } from "./hover-explain";
import { getInlineCompletionStats, registerInlineCompletion } from "./inline-completion";
import { registerInlineCompletionStatusBar } from "./inline-completion-status-bar";
import { InlineDiffController, pickInlineDiffMode } from "./inline-diff";
import { runInlineEditCommand } from "./inline-edit";
// R5-B: knowledge base — single store per workspace, shared across panels.
import { KnowledgeStore } from "./knowledge";
import { McpManager } from "./mcp-manager";
// R4-D: MCP marketplace.
import { MarketplaceManager } from "./mcp-marketplace";
// R3-E: notifications
import { DISCORD_SECRET_KEY, NotificationHub, SLACK_SECRET_KEY } from "./notifications";
import { reviewPullRequest } from "./pr-review";
// R6-C: PR-on-open auto review polling.
import { PrWatcher, detectCurrentRepo, detectCurrentUser } from "./pr-watch";
import { registerPredictiveEdit } from "./predictive-edit";
import { ProviderManager } from "./provider-manager";
import { SessionStore } from "./session-store";
import { SessionsTreeProvider } from "./sessions-tree";
import { SettingsStore } from "./settings-store";
import { exportSessionAsMarkdown } from "./share-session";
import { StatusBarManager } from "./status-bar";
import { kvFromVsCode, secretsFromVsCode } from "./storage";
import { SupervisorAgent } from "./supervisor";
import { WorkspaceChangeTracker } from "./workspace-change-tracker";

export async function activate(context: vscode.ExtensionContext): Promise<void> {
	const channel = vscode.window.createOutputChannel("OATI Code");
	channel.appendLine("[info] OATI Code activated");

	const kv = kvFromVsCode(context);
	const secrets = secretsFromVsCode(context);
	const settings = new SettingsStore(kv, secrets);
	// R5-C: forward-referenced so the `onSaved` hook can feed the cross-session
	// SessionIndex without SessionStore needing to know about embeddings. The
	// index itself is created lazily below; until then the hook is a no-op.
	const sessionIndexHolder: { current: import("./session-index").SessionIndex | undefined } = {
		current: undefined,
	};
	const session = new SessionStore(kv, {
		getWorkspaceId: () => vscode.workspace.workspaceFolders?.[0]?.uri.toString() ?? "_global",
		// R5-C: every save fans out to the conversation index so `/search`
		// and the `search_conversations` tool see fresh state. The historyTo
		// Indexable mapper drops empty / tool-only messages.
		onSaved: (sid, history) => {
			const idx = sessionIndexHolder.current;
			if (!idx) return;
			void (async () => {
				const { historyToIndexable } = await import("./session-index");
				await idx.indexSession(sid, historyToIndexable(history)).catch(() => undefined);
			})();
		},
	});
	// R5-C: instantiate the cross-session SessionIndex if we have a workspace.
	// Lives under `.oati/conversations.sqlite` next to the codebase index.
	{
		const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (root) {
			try {
				const { SessionIndex } = await import("./session-index");
				const path = await import("node:path");
				sessionIndexHolder.current = new SessionIndex({
					dbPath: path.join(root, ".oati", "conversations.sqlite"),
				});
				context.subscriptions.push({ dispose: () => sessionIndexHolder.current?.close() });
			} catch (err) {
				channel.appendLine(
					`[session-index] failed to initialize: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}
	}
	const providerManager = new ProviderManager(settings);
	await providerManager.rebuild();

	const tools = new ToolRegistry();
	for (const t of builtinTools) tools.register(t);

	// 2026-06-01: shared repo-map builder used by every host context that
	// activate() creates (main chat, sub-agents, supervisor, recipes,
	// background tasks). Walks the workspace once per Agent session;
	// agent-core caches the result so this only fires on session start.
	const buildRepoMapForWorkspace = async (opts?: { tokenBudget?: number }) => {
		const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!root) return undefined;
		try {
			const { buildRepoMap } = await import("@oati/codebase-index");
			const result = buildRepoMap(root, { tokenBudget: opts?.tokenBudget ?? 8000 });
			return result.text;
		} catch (err) {
			channel.appendLine(
				`[repo-map] build failed: ${err instanceof Error ? err.message : String(err)}`,
			);
			return undefined;
		}
	};

	// Single index per workspace; reused across all chat panels.
	const codebaseIndexManager = new CodebaseIndexManager();
	// R8-B: wire SecretStorage so remote embedders (OpenAI / Voyage / Cohere)
	// can fetch their API keys without each module reaching into `context.secrets`.
	codebaseIndexManager.setSecretStorage(context.secrets);
	context.subscriptions.push({ dispose: () => codebaseIndexManager.dispose() });
	// R8-B: when the user changes `oati.codebaseIndex.embedder`, drop the
	// current index handle so the next reindex picks up the new provider, and
	// surface a notification offering to reindex now. The IndexStore wipes its
	// data tables on an embedder-id mismatch, so we don't risk mixing vectors.
	context.subscriptions.push(
		vscode.workspace.onDidChangeConfiguration((e) => {
			if (!e.affectsConfiguration("oati.codebaseIndex.embedder")) return;
			codebaseIndexManager.resetForEmbedderChange();
			void vscode.window
				.showInformationMessage(
					"Codebase embedder changed; existing index is no longer valid. Reindex now?",
					"Reindex now",
					"Later",
				)
				.then((choice) => {
					if (choice !== "Reindex now") return;
					void codebaseIndexManager.reindex().catch((err: unknown) => {
						const m = err instanceof Error ? err.message : String(err);
						vscode.window.showErrorMessage(`Codebase reindex failed: ${m}`);
					});
				});
		}),
	);

	// R5-B: knowledge base — construct the store up front so ChatPanels can
	// reference it via opts.knowledgeStore. The initial rebuild + watcher are
	// kicked off AFTER `panels` is declared (forward reference) so the
	// rebroadcast closure has something to iterate over. Optional: when no
	// workspace is open the panel falls back to RAG-off gracefully.
	const workspaceRootForKnowledge = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
	const knowledgeStore: KnowledgeStore | undefined = workspaceRootForKnowledge
		? new KnowledgeStore({
				workspaceRoot: workspaceRootForKnowledge,
				log: (msg) => channel.appendLine(msg),
			})
		: undefined;
	if (knowledgeStore) {
		context.subscriptions.push({ dispose: () => knowledgeStore.dispose() });
	}

	const mcpManager = new McpManager(tools, channel);
	const initialMcpCount = (settings.config.mcpServers ?? []).filter((s) => s.enabled).length;
	if (initialMcpCount > 0) {
		channel.appendLine(`[mcp] starting ${initialMcpCount} enabled server(s)`);
	}
	await mcpManager.syncWith(settings.config.mcpServers ?? []);
	const offSettingsForMcp = settings.on((cfg) => {
		void mcpManager.syncWith(cfg.mcpServers ?? []);
	});

	// R4-D: marketplace manager — shared by every ChatPanel so install/toggle
	// state stays in sync across tabs (settings updates are broadcast through
	// SettingsStore listeners; the McpManager then reconciles processes).
	const marketplace = new MarketplaceManager(settings, mcpManager);

	channel.appendLine(
		`[init] providers=${providerManager.registry.list().length} tools=${tools.list().length} mcp=${initialMcpCount}`,
	);

	const diffProvider = new OatiDiffContentProvider();
	const inlineDiff = new InlineDiffController({ log: channel });
	const aiCodeLens = new AiCodeLensProvider();
	context.subscriptions.push(
		vscode.workspace.registerTextDocumentContentProvider(OATI_DIFF_SCHEME, diffProvider),
		// One controller, but we register it twice — once as a code lens provider
		// (so its Accept/Reject/Modify lenses appear) and once as a global so the
		// host can call `present(diff)` from outside the lens-provider lifecycle.
		vscode.languages.registerCodeLensProvider({ scheme: "file" }, inlineDiff),
		vscode.languages.registerCodeLensProvider({ scheme: "file" }, aiCodeLens),
		{ dispose: () => inlineDiff.dispose() },
		{ dispose: () => aiCodeLens.dispose() },
		{ dispose: () => diffProvider.dispose() },
		{ dispose: () => offSettingsForMcp() },
		{ dispose: () => mcpManager.dispose() },
	);

	// Sessions are surfaced through a custom Activity Bar webview (single
	// source of truth) — Claude-style sidebar with + New chat, search, and
	// hover rename/delete on each row.
	const sessionsTree = new SessionsTreeProvider(session);
	context.subscriptions.push(
		vscode.window.registerWebviewViewProvider("oatiSessions", sessionsTree),
	);

	// Each open chat tab is a ChatPanel keyed by session id.
	const panels = new Map<string, ChatPanel>();

	// R5-B: knowledge watcher + initial rebuild. Wired here (after `panels`
	// is in scope) so the rebroadcast closure can fan `knowledge_state` out
	// to every open ChatPanel after the store changes.
	if (knowledgeStore) {
		const rebroadcastKnowledge = () => {
			for (const p of panels.values()) void p.sendKnowledgeState();
		};
		const watcherDisposable = knowledgeStore.attachWatcher(rebroadcastKnowledge);
		context.subscriptions.push(watcherDisposable);
		void knowledgeStore
			.rebuild()
			.then(rebroadcastKnowledge)
			.catch((err: unknown) => {
				channel.appendLine(
					`[knowledge] initial rebuild failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			});
	}
	let lastFocusedPanelId: string | undefined;
	// Column to open new chat tabs in. Defaults to Beside for the first chat so
	// we don't sit on top of the user's source editor; tracks subsequent chat
	// columns so new sessions land as tabs in the same group as existing chats.
	let lastChatColumn: vscode.ViewColumn | undefined;
	// Holder for the BackgroundTaskRunner — initialized further below in a
	// scoped block, but `openPanelForSession` (defined first) captures the
	// holder by reference so the panels see the runner once it's wired.
	const backgroundTasksHolder: { current?: import("./background-tasks").BackgroundTaskRunner } = {};
	// Sessions that the user opened as Settings tabs (via `oati.openSettings`).
	// They live in the session list so the underlying ChatPanel can render,
	// but `findReusableEmptySession` excludes them so `+ New Session` doesn't
	// resurface the Settings tab instead of opening a fresh chat.
	const settingsSessions = new Set<string>();
	// Holder for the background SupervisorAgent — initialized once a
	// Conductor + ProviderManager are wired up. `openPanelForSession`
	// captures the holder by reference so panels see the supervisor
	// suggestion stream as soon as it's running.
	const supervisorHolder: { current?: SupervisorAgent } = {};
	// 2026-05-26: shared workspace change tracker. Started once on activation
	// and shared across all chat panels so each turn sees a unified
	// "files changed externally since last turn" snapshot.
	const workspaceChangeTracker = new WorkspaceChangeTracker();
	workspaceChangeTracker.start();
	context.subscriptions.push({ dispose: () => workspaceChangeTracker.stop() });

	const refreshUi = () => {
		sessionsTree.refresh();
	};

	const updateActiveDecoration = () => {
		sessionsTree.setActive(lastFocusedPanelId);
	};

	const openPanelForSession = (sessionId: string): ChatPanel => {
		const existing = panels.get(sessionId);
		if (existing) {
			existing.reveal();
			lastFocusedPanelId = sessionId;
			updateActiveDecoration();
			return existing;
		}

		// biome-ignore lint/style/useConst: forward reference — host closures below capture this binding before assignment.
		let panelRef: ChatPanel | undefined;
		// biome-ignore lint/style/useConst: forward reference — host closures below capture this binding before assignment.
		let conductorRef: Conductor | undefined;
		const host = createHostContext({
			output: channel,
			bundledSkillsDir: vscode.Uri.joinPath(context.extensionUri, "assets", "skills").fsPath,
			updateTodos: (items) => {
				panelRef?.handleTodosUpdate(items);
			},
			onWorkspaceRootChanged: (resolved) => {
				panelRef?.broadcastWorkspaceInfo(resolved);
				void panelRef?.persistWorkspaceRoot(resolved);
			},
			requestApproval: async (req) => {
				if (!panelRef) return false;
				return panelRef.requestApproval(req);
			},
			// 2026-05-27: ask_user routing — panel owns the webview round-trip.
			askUser: async (req) => {
				if (!panelRef) {
					// Headless context: fall back to picking option[0]. The
					// tool layer already handles this case, but we cover the
					// "panel-disposed-mid-call" edge here too.
					return { answer: req.options[0]?.label ?? "", autoPicked: true };
				}
				return panelRef.requestAskUser(req);
			},
			showDiff: async (diff) => {
				// 2026-05-28: gate ALL editor-popping side effects on the
				// silent-writes setting — including the standalone diff
				// editor tab that opens via vscode.diff. The previous fix
				// only covered streaming-write animation and inline-diff
				// review; this `openDiffEditor` call was still firing
				// unconditionally on every agent edit, which is the leak
				// the user was reporting.
				const animateCfg = vscode.workspace.getConfiguration("oati.streamingWrites");
				const openInEditor = animateCfg.get<boolean>("enabled", false);
				if (openInEditor) {
					await openDiffEditor(diffProvider, diff);
				}
				if (panelRef) await panelRef.showDiff(diff);
				// Inline-diff review: when the active mode opts into `review` mode
				// (the default for non-auto-approve modes), surface the diff
				// as in-editor decorations + Accept/Reject/Modify code lenses so
				// the user can resolve hunks without leaving the source file.
				//
				// 2026-05-28: when `oati.streamingWrites.enabled` is OFF
				// (the silent default), DON'T pop the file open — register
				// the inline-diff session but skip the showTextDocument
				// call. Decorations + lenses still appear the moment the
				// user manually navigates to the file. Mirrors the user's
				// mental model: "Animate file writes is off → no files
				// should open on their own."
				const cfg = settings.config;
				const activeMode = cfg.modes.find((m) => m.id === cfg.activeModeId) ?? cfg.modes[0];
				if (activeMode && pickInlineDiffMode(activeMode) === "review") {
					const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
					await inlineDiff.present(diff, root, { openInEditor }).catch((err: unknown) => {
						channel.appendLine(
							`[inline-diff] present failed: ${err instanceof Error ? err.message : String(err)}`,
						);
					});
				}
			},
			getCodebaseIndex: () => codebaseIndexManager.asSearchProvider(),
			// 2026-06-01: Aider-style repo map — top-level symbols across
			// the workspace, sized to a per-session token budget. Injected
			// into the system prompt by agent-core for orientation, cached
			// for the life of the Agent instance.
			getRepoMap: buildRepoMapForWorkspace,
			// Phase 1.3: setting-gated rerank LLM call. ChatPanel checks
			// `oati.codebaseIndex.rerank` and returns undefined when off,
			// keeping the capability off the HostContext entirely so the
			// `code_semantic_search` tool skips the rerank pass.
			getRerankerLlmCall: () => panelRef?.getRerankerLlmCall(),
			// Phase 2.3: expose the active model id so capability-aware
			// tools (spawn_parallel_agents) can clamp user-requested
			// concurrency against the model's `parallelConcurrencyCap`.
			getActiveModelId: () => {
				try {
					return providerManager.resolveActiveModelId(settings.config);
				} catch {
					return undefined;
				}
			},
			// R5-C: expose the cross-session conversation index to tools (so
			// `search_conversations` works once registered) and to any future
			// host-side feature that needs to query past chats.
			getConversationSearch: () => {
				const idx = sessionIndexHolder.current;
				if (!idx) return undefined;
				return { search: (q, o) => idx.search(q, o ?? {}) };
			},
			spawnSubAgent: async (req, opts) => {
				if (!conductorRef) throw new Error("Sub-agent spawn requested before Conductor was wired");
				const config = settings.config;
				const parent = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
				if (!parent) throw new Error("No active mode for sub-agent");
				const modelId = providerManager.resolveActiveModelId(config);
				if (!modelId) throw new Error("No model configured for sub-agent");
				const childMode = {
					...parent,
					systemPrompt: req.systemPromptOverride ?? parent.systemPrompt,
					enablePlanner: false,
					enableCritic: false,
				};
				channel.appendLine(`[sub-agent] spawning: ${req.task.slice(0, 80)}...`);
				let toolCalls = 0;
				let iterations = 0;
				const offCounter = conductorRef.on((ev) => {
					if (ev.type === "tool_call") toolCalls++;
					else if (ev.type === "iteration") iterations++;
				});
				// If a parent agent id is supplied (we are in a spawn_parallel_agents
				// batch), wrap the host so this child's scratchpad reads/writes go
				// into the parent's bucket. The conductor receives the wrapped host
				// via `hostOverride`.
				const hostOverride =
					opts?.parentAgentId && host ? wrapHostForSubAgent(host, opts.parentAgentId) : undefined;
				try {
					const history = await conductorRef.spawn({
						mode: childMode,
						modelId,
						userMessage: req.task,
						...(opts?.scope ? { toolScope: opts.scope } : {}),
						...(hostOverride ? { hostOverride } : {}),
					});
					const finalText = extractFinalAssistantText(history);
					return { text: finalText, toolCalls, iterations };
				} finally {
					offCounter();
				}
			},
			emitToolProgress: (callId, chunk) => {
				if (panelRef) panelRef.emitToolProgress(callId, chunk);
			},
		});

		const conductor = new Conductor({
			providers: providerManager.registry,
			tools,
			host,
		});
		conductorRef = conductor;

		panelRef = new ChatPanel({
			extensionUri: context.extensionUri,
			conductor,
			settings,
			providerManager,
			session,
			sessionId,
			viewColumn: lastChatColumn ?? vscode.ViewColumn.Beside,
			log: channel,
			codebaseIndexManager,
			host,
			onDispose: (id) => {
				panels.delete(id);
				// If this was a Settings tab, drop the marker so the next
				// `oati.openSettings` mints a fresh session instead of trying
				// to revive the closed one.
				const wasSettings = settingsSessions.delete(id);
				if (lastFocusedPanelId === id) {
					lastFocusedPanelId = panels.keys().next().value;
				}
				if (panels.size === 0) {
					// Reset to Beside so the next "Open Chat" doesn't try to reuse a dead column.
					lastChatColumn = undefined;
				}
				// 2026-06-16: clean up the underlying session storage entry
				// for Settings tabs. Without this, every time the user
				// opened Settings and closed it, an empty session was
				// silently retained — invisible thanks to the sidebar
				// filter, but accumulating in `.oati/sessions/`. Real
				// chats are never auto-deleted; only the transient
				// Settings entries that were minted for UI purposes.
				if (wasSettings) {
					void session.delete(id).then(() => refreshUi());
				} else {
					updateActiveDecoration();
				}
			},
			onSessionIndexChanged: () => {
				refreshUi();
			},
			onRequestNewSession: () => {
				void (async () => {
					const reusable = await findReusableEmptySession();
					if (reusable) {
						openPanelForSession(reusable);
						return;
					}
					const meta = await session.create();
					openPanelForSession(meta.id);
					refreshUi();
				})();
			},
			onFocus: (id) => {
				lastFocusedPanelId = id;
				updateActiveDecoration();
			},
			onColumnChanged: (col) => {
				lastChatColumn = col;
			},
			// R3-D: conversation branching — when a chat panel mints a fork via
			// `fork_conversation`, open a fresh panel pointed at the new
			// session id so the user sees both side-by-side. The newly opened
			// panel will request its own `fork_info` and render the linkage
			// banner.
			onForkConversation: (newSessionId) => {
				openPanelForSession(newSessionId);
				refreshUi();
			},
			// R4-D: MCP marketplace — wire the shared MarketplaceManager so
			// every panel can answer marketplace_list_request / install /
			// uninstall / toggle RPCs.
			marketplace,
			// R5-B: shared KnowledgeStore so each panel can do per-turn RAG
			// + answer the `/knowledge` slash command.
			...(knowledgeStore ? { knowledgeStore } : {}),
			// R5-C: shared cross-session search index so `/search` and the
			// `search_conversations` tool both see the same data.
			...(sessionIndexHolder.current ? { sessionIndex: sessionIndexHolder.current } : {}),
			// Shared background-task runner for the tray + Stop buttons.
			...(backgroundTasksHolder.current ? { backgroundTasks: backgroundTasksHolder.current } : {}),
			// Shared background supervisor for its suggestions panel.
			...(supervisorHolder.current ? { supervisor: supervisorHolder.current } : {}),
			workspaceChangeTracker,
		});
		panels.set(sessionId, panelRef);
		lastFocusedPanelId = sessionId;
		// Capture the resolved column so subsequent New Chats stick to the same group.
		const resolved = panelRef.getViewColumn();
		if (resolved !== undefined) lastChatColumn = resolved;
		updateActiveDecoration();
		return panelRef;
	};

	// 2026-06-03: init OATI.md from a starter template. Makes the
	// project-memory feature discoverable for users who don't know
	// the file convention exists. No-op when an OATI.md / CLAUDE.md
	// already lives in the workspace.
	const initProjectMemoryCmd = vscode.commands.registerCommand(
		"oati.initProjectMemory",
		async () => {
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			if (!root) {
				await vscode.window.showWarningMessage(
					"OATI: open a folder/workspace first — there's no workspace root to write OATI.md into.",
				);
				return;
			}
			const { initProjectMemory } = await import("./project-memory");
			const result = await initProjectMemory(root);
			if (!result.created) {
				const open = "Open existing";
				const choice = await vscode.window.showInformationMessage(
					`OATI: project memory already exists at ${result.existingPath}. Edit it directly to update what the agent knows about this project.`,
					open,
				);
				if (choice === open) {
					await vscode.commands.executeCommand("vscode.open", vscode.Uri.file(result.existingPath));
				}
				return;
			}
			const open = "Open OATI.md";
			const choice = await vscode.window.showInformationMessage(
				"OATI: created OATI.md at the workspace root. Edit it to tell the agent what it should always know about this project — the file is auto-loaded into every session's system prompt.",
				open,
			);
			if (choice === open) {
				await vscode.commands.executeCommand("vscode.open", vscode.Uri.file(result.path));
			}
		},
	);

	const openChat = vscode.commands.registerCommand("oati.openChat", async () => {
		if (lastFocusedPanelId && panels.has(lastFocusedPanelId)) {
			panels.get(lastFocusedPanelId)?.reveal();
			return;
		}
		if (panels.size > 0) {
			const first = panels.values().next().value;
			first?.reveal();
			return;
		}
		const list = await session.list();
		if (list.length > 0) {
			openPanelForSession(list[0].id);
		} else {
			const meta = await session.create();
			openPanelForSession(meta.id);
			refreshUi();
		}
	});

	const openSettings = vscode.commands.registerCommand("oati.openSettings", async () => {
		// Open Settings in a separate tab so it doesn't replace the focused
		// chat view. We mint a dedicated session (or reuse the previously-
		// allocated settings session if its panel is still open) and tag it
		// so `+ New Session` won't accidentally resurface this tab when the
		// user wants a fresh chat.
		const existingSettingsSession = [...settingsSessions].find((id) => panels.has(id));
		if (existingSettingsSession) {
			const open = panels.get(existingSettingsSession);
			open?.reveal();
			open?.openSettings();
			return;
		}
		const meta = await session.create();
		const sessionId = meta.id;
		settingsSessions.add(sessionId);
		const prevColumn = lastChatColumn;
		lastChatColumn = vscode.ViewColumn.Beside;
		const panel = openPanelForSession(sessionId);
		lastChatColumn = prevColumn;
		panel.openSettings();
		refreshUi();
	});

	// Reuse an existing empty session if there is one — avoids piles of "New
	// Session" entries when the user keeps clicking "+ New Session" without
	// sending anything. Excludes sessions reserved for the Settings tab so
	// the user always lands in a real chat.
	const findReusableEmptySession = async (): Promise<string | undefined> => {
		const list = await session.list();
		const empty = list.find(
			(s) =>
				s.messageCount === 0 &&
				(s.title === "New Session" || s.title === "New chat") &&
				!settingsSessions.has(s.id),
		);
		return empty?.id;
	};

	const newChat = vscode.commands.registerCommand("oati.newChat", async () => {
		const reusable = await findReusableEmptySession();
		if (reusable) {
			openPanelForSession(reusable);
			return;
		}
		const meta = await session.create();
		openPanelForSession(meta.id);
		refreshUi();
	});

	const openSessionCmd = vscode.commands.registerCommand(
		"oati.sessions.open",
		(sessionId: string) => {
			if (!sessionId) return;
			openPanelForSession(sessionId);
		},
	);

	const renameSessionCmd = vscode.commands.registerCommand(
		"oati.sessions.rename",
		async (arg: SessionMeta | { id: string } | undefined) => {
			const id = resolveSessionId(arg);
			if (!id) return;
			const list = await session.list();
			const meta = list.find((s) => s.id === id);
			if (!meta) return;
			const next = await vscode.window.showInputBox({
				prompt: "Rename chat",
				value: meta.title,
				validateInput: (v) => (v.trim().length === 0 ? "Title cannot be empty" : undefined),
			});
			if (!next) return;
			await session.rename(id, next.trim());
			refreshUi();
			const open = panels.get(id);
			if (open) void open.refreshTitle();
		},
	);

	const deleteSessionCmd = vscode.commands.registerCommand(
		"oati.sessions.delete",
		async (arg: SessionMeta | { id: string } | undefined) => {
			const id = resolveSessionId(arg);
			if (!id) return;
			const list = await session.list();
			const meta = list.find((s) => s.id === id);
			if (!meta) return;
			// Non-modal toast (bottom-right notification) rather than a native OS dialog.
			// Matches the lightweight in-app confirmation pattern other AI plugins use.
			const confirmed = await vscode.window.showWarningMessage(
				`Delete chat "${meta.title}"?`,
				"Delete",
				"Cancel",
			);
			if (confirmed !== "Delete") return;
			await session.delete(id);
			const owner = panels.get(id);
			if (owner) {
				panels.delete(id);
				owner.dispose();
				if (lastFocusedPanelId === id) lastFocusedPanelId = undefined;
			}
			refreshUi();
		},
	);

	// Wire the custom sidebar's row actions into the same flows the command
	// palette uses. Rename / delete from the sidebar skip the input box +
	// warning dialog because the webview already provides inline editing
	// (rename) and a modal confirm (delete).
	sessionsTree.bind({
		onOpen: (id: string) => openPanelForSession(id),
		onNew: () => {
			void vscode.commands.executeCommand("oati.newChat");
		},
		onRename: async (id: string, newTitle: string) => {
			const title = newTitle.trim();
			if (!title) return;
			await session.rename(id, title);
			refreshUi();
			const open = panels.get(id);
			if (open) void open.refreshTitle();
		},
		onDelete: async (id: string) => {
			await session.delete(id);
			const owner = panels.get(id);
			if (owner) {
				panels.delete(id);
				owner.dispose();
				if (lastFocusedPanelId === id) lastFocusedPanelId = undefined;
			}
			refreshUi();
		},
		// 2026-06-16: sessions tagged as Settings tabs are hidden from
		// the sidebar — they exist in storage so the ChatPanel renders
		// but don't show as user-facing chat history. The Set is read
		// by-reference each time so additions/removals propagate without
		// re-binding.
		getHiddenSessionIds: () => settingsSessions,
	});

	const exportSession = vscode.commands.registerCommand("oati.exportSession", async () => {
		const target =
			(lastFocusedPanelId ? panels.get(lastFocusedPanelId) : undefined) ??
			panels.values().next().value;
		const sessionId = target?.getSessionId();
		const history = target?.getHistory() ?? (sessionId ? await session.load(sessionId) : []);
		if (history.length === 0) {
			vscode.window.showInformationMessage("OATI Code:no conversation to export.");
			return;
		}
		const uri = await vscode.window.showSaveDialog({
			defaultUri: vscode.Uri.file(`oati-session-${Date.now()}.json`),
			filters: { JSON: ["json"] },
			saveLabel: "Export OATI Session",
		});
		if (!uri) return;
		const list = await session.list();
		const meta = sessionId ? list.find((s) => s.id === sessionId) : undefined;
		const text = session.serializeExport(sessionId ?? "unknown", history, meta?.title);
		await vscode.workspace.fs.writeFile(uri, Buffer.from(text, "utf-8"));
		vscode.window.showInformationMessage(`OATI: exported ${history.length} messages.`);
	});

	const importSession = vscode.commands.registerCommand("oati.importSession", async () => {
		const uris = await vscode.window.showOpenDialog({
			canSelectMany: false,
			filters: { JSON: ["json"] },
			openLabel: "Import OATI Session",
		});
		if (!uris || uris.length === 0) return;
		try {
			const buf = await vscode.workspace.fs.readFile(uris[0]);
			const text = Buffer.from(buf).toString("utf-8");
			const { history, title } = session.parseImport(text);
			const meta = await session.saveImported(history, title);
			openPanelForSession(meta.id);
			refreshUi();
			vscode.window.showInformationMessage(`OATI: imported ${history.length} messages.`);
		} catch (err) {
			vscode.window.showErrorMessage(
				`OATI: failed to import session: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	});

	// Cross-IDE-host import. OATI persists session state in `globalState`,
	// which VS Code writes to a per-host SQLite file — so sessions started
	// while running in (say) Antigravity are invisible when the same extension
	// activates inside VS Code. This command discovers every peer host on the
	// machine, lists their OATI sessions, and copies the chosen ones into the
	// current host via `SessionStore.saveImported`.
	const importFromHost = vscode.commands.registerCommand("oati.importFromIdeHost", async () => {
		const { discoverPeerHosts, readPeerCatalog, readPeerSessionHistory, workspaceLabelFromId } =
			await import("./peer-host-import");
		// Exclude the current host so users don't see themselves in the source list.
		const currentUserDataDir = path.dirname(
			path.dirname(path.dirname(context.globalStorageUri.fsPath)),
		);
		const candidates = discoverPeerHosts(currentUserDataDir);
		if (candidates.length === 0) {
			vscode.window.showInformationMessage(
				"OATI: no other VS Code-family IDE installations found on this machine.",
			);
			return;
		}
		// Step 1: read catalogs so we can show session counts in the QuickPick.
		type HostPick = vscode.QuickPickItem & {
			catalog: Awaited<ReturnType<typeof readPeerCatalog>>;
		};
		const hostItems: HostPick[] = [];
		for (const c of candidates) {
			try {
				const catalog = readPeerCatalog(c);
				if (!catalog || catalog.totalSessions === 0) {
					hostItems.push({
						label: c.label,
						description: "no OATI sessions",
						catalog: undefined,
					});
					continue;
				}
				hostItems.push({
					label: c.label,
					description: `${catalog.totalSessions} session(s) across ${catalog.workspaces.length} workspace(s)`,
					catalog,
				});
			} catch (err) {
				hostItems.push({
					label: c.label,
					description: `error: ${err instanceof Error ? err.message : String(err)}`,
					catalog: undefined,
				});
			}
		}
		const hostPick = await vscode.window.showQuickPick(hostItems, {
			placeHolder: "Pick an IDE host to import OATI sessions from",
			matchOnDescription: true,
		});
		if (!hostPick || !hostPick.catalog) return;
		const catalog = hostPick.catalog;
		// Step 2: flatten to per-session picks with workspace labels.
		type SessionPick = vscode.QuickPickItem & {
			workspaceId: string;
			sessionId: string;
		};
		const sessionItems: SessionPick[] = [];
		for (const ws of catalog.workspaces) {
			for (const s of ws.sessions) {
				sessionItems.push({
					label: s.title,
					description: `${ws.workspaceLabel} • ${s.messageCount} msg`,
					detail: `Last updated ${s.lastUpdatedAt}`,
					workspaceId: ws.workspaceId,
					sessionId: s.id,
					picked: true,
				});
			}
		}
		const sessionPicks = await vscode.window.showQuickPick(sessionItems, {
			placeHolder: `Pick sessions to import from ${hostPick.label} (toggle with Space)`,
			canPickMany: true,
			matchOnDescription: true,
			matchOnDetail: true,
		});
		if (!sessionPicks || sessionPicks.length === 0) return;
		// Step 3: copy each session into the current SessionStore. We keep
		// titles as-is — users can rename afterward from the sidebar if they
		// want — but tag the source host so duplicates stay distinguishable.
		let imported = 0;
		const errors: string[] = [];
		await vscode.window.withProgress(
			{
				location: vscode.ProgressLocation.Notification,
				title: `OATI: importing from ${hostPick.label}…`,
				cancellable: false,
			},
			async (progress) => {
				for (let i = 0; i < sessionPicks.length; i++) {
					const p = sessionPicks[i];
					progress.report({
						message: `${i + 1}/${sessionPicks.length} — ${p.label}`,
						increment: 100 / sessionPicks.length,
					});
					try {
						const history = readPeerSessionHistory(catalog.candidate, p.workspaceId, p.sessionId);
						if (history.length === 0) {
							errors.push(`${p.label}: no history payload`);
							continue;
						}
						const wsLabel = workspaceLabelFromId(p.workspaceId);
						const titledForImport = `${p.label} (${hostPick.label}/${wsLabel})`;
						await session.saveImported(history, titledForImport);
						imported++;
					} catch (err) {
						errors.push(`${p.label}: ${err instanceof Error ? err.message : String(err)}`);
					}
				}
			},
		);
		refreshUi();
		const errorTail = errors.length > 0 ? ` (${errors.length} failed)` : "";
		vscode.window.showInformationMessage(
			`OATI: imported ${imported}/${sessionPicks.length} session(s) from ${hostPick.label}${errorTail}.`,
		);
		if (errors.length > 0) {
			channel.appendLine("[import-from-host] errors:");
			for (const e of errors) channel.appendLine(`  - ${e}`);
		}
	});

	const hello = vscode.commands.registerCommand("oati.helloWorld", () => {
		vscode.window.showInformationMessage("Hello from OATI Code");
	});

	// ---------------------------------------------------------------------
	// In-editor experience commands (round R1).
	// ---------------------------------------------------------------------

	const ensureChatPanelForSelection = async (): Promise<ChatPanel | undefined> => {
		// Prefer the panel that was last focused; fall back to any open panel;
		// finally create a new chat tab so the selection has somewhere to land.
		if (lastFocusedPanelId && panels.has(lastFocusedPanelId)) {
			const p = panels.get(lastFocusedPanelId);
			if (p) {
				p.reveal();
				return p;
			}
		}
		if (panels.size > 0) {
			const p = panels.values().next().value;
			p?.reveal();
			return p;
		}
		const list = await session.list();
		const sessionId = list.length > 0 ? list[0].id : (await session.create()).id;
		const panel = openPanelForSession(sessionId);
		refreshUi();
		return panel;
	};

	const inlineDiffAccept = vscode.commands.registerCommand(
		"oati.inlineDiff.accept",
		async (uriString: string, hunkId: string) => {
			await inlineDiff.handleAccept(uriString, hunkId);
		},
	);
	const inlineDiffReject = vscode.commands.registerCommand(
		"oati.inlineDiff.reject",
		async (uriString: string, hunkId: string) => {
			await inlineDiff.handleReject(uriString, hunkId);
		},
	);
	const inlineDiffModify = vscode.commands.registerCommand(
		"oati.inlineDiff.modify",
		async (uriString: string, hunkId: string) => {
			await inlineDiff.handleModify(uriString, hunkId);
		},
	);

	const inlineEdit = vscode.commands.registerCommand("oati.inlineEdit", async () => {
		await runInlineEditCommand({
			settings,
			providerManager,
			inlineDiff,
			log: channel,
		});
	});

	const sendSelectionToChat = vscode.commands.registerCommand(
		"oati.sendSelectionToChat",
		async () => {
			const editor = vscode.window.activeTextEditor;
			if (!editor) {
				vscode.window.showWarningMessage("OATI Code: open a file and select code first.");
				return;
			}
			let range: vscode.Range = editor.selection;
			if (range.isEmpty) {
				const line = editor.document.lineAt(editor.selection.active.line);
				range = line.range;
			}
			const text = editor.document.getText(range);
			if (text.trim().length === 0) {
				vscode.window.showWarningMessage("OATI Code: selection is empty.");
				return;
			}
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			const relPath =
				root && editor.document.uri.fsPath.startsWith(root)
					? editor.document.uri.fsPath.slice(root.length + 1).replace(/\\/g, "/")
					: editor.document.uri.fsPath;
			const panel = await ensureChatPanelForSelection();
			panel?.attachSelection({
				path: relPath,
				language: editor.document.languageId,
				text,
				startLine: range.start.line + 1,
				endLine: range.end.line + 1,
			});
		},
	);

	const promptSymbol = async (
		uriString: string,
		startLine: number,
		flavor: "explain" | "test" | "refactor",
	): Promise<void> => {
		try {
			const uri = vscode.Uri.parse(uriString);
			const doc = await vscode.workspace.openTextDocument(uri);
			const body = extractSymbolBody(doc.getText(), startLine, doc.languageId);
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			const relPath =
				root && doc.uri.fsPath.startsWith(root)
					? doc.uri.fsPath.slice(root.length + 1).replace(/\\/g, "/")
					: doc.uri.fsPath;
			const prompts: Record<typeof flavor, string> = {
				explain:
					"Explain what the following code does, step by step. Highlight any non-obvious decisions or edge cases.",
				test:
					"Write thorough unit tests for the following code. Use the project's existing test framework if it's obvious from the file extension; otherwise pick a sensible default. Cover happy paths and edge cases.",
				refactor:
					"Suggest a concrete refactor for the following code to improve clarity, performance, or correctness — pick whichever improvement is most impactful. Provide the rewritten code, then a brief rationale.",
			};
			const prompt = `${prompts[flavor]}\n\n(from ${relPath}:${startLine + 1})\n\n\`\`\`${doc.languageId}\n${body}\n\`\`\``;
			const panel = await ensureChatPanelForSelection();
			panel?.prefillPrompt(prompt);
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			channel.appendLine(`[code-lens] ${flavor} failed: ${message}`);
			vscode.window.showErrorMessage(`OATI Code: ${flavor} failed — ${message}`);
		}
	};

	const explainSymbol = vscode.commands.registerCommand(
		"oati.explainSymbol",
		(uriString: string, startLine: number) => promptSymbol(uriString, startLine, "explain"),
	);
	const testSymbol = vscode.commands.registerCommand(
		"oati.testSymbol",
		(uriString: string, startLine: number) => promptSymbol(uriString, startLine, "test"),
	);
	const refactorSymbol = vscode.commands.registerCommand(
		"oati.refactorSymbol",
		(uriString: string, startLine: number) => promptSymbol(uriString, startLine, "refactor"),
	);

	// Context-menu shims that infer (uri, line) from the active editor cursor
	// so the right-click menu doesn't need its caller to pre-resolve args.
	const promptSymbolFromCursor = async (flavor: "explain" | "test" | "refactor"): Promise<void> => {
		const editor = vscode.window.activeTextEditor;
		if (!editor) return;
		await promptSymbol(editor.document.uri.toString(), editor.selection.active.line, flavor);
	};
	const explainSymbolMenu = vscode.commands.registerCommand("oati.explainSymbol.contextMenu", () =>
		promptSymbolFromCursor("explain"),
	);
	const testSymbolMenu = vscode.commands.registerCommand("oati.testSymbol.contextMenu", () =>
		promptSymbolFromCursor("test"),
	);
	const refactorSymbolMenu = vscode.commands.registerCommand("oati.refactorSymbol.contextMenu", () =>
		promptSymbolFromCursor("refactor"),
	);

	// R2-A: open the multi-file composer in the active (or newly created) chat panel.
	const openComposer = vscode.commands.registerCommand("oati.openComposer", async () => {
		const panel = await ensureChatPanelForSelection();
		panel?.openComposer();
	});

	// R4-D: open the MCP marketplace overlay in the active (or newly created)
	// chat panel. Mirrors `oati.openComposer` so users can launch it from the
	// command palette as well as via `/marketplace`.
	const openMarketplace = vscode.commands.registerCommand("oati.openMarketplace", async () => {
		const panel = await ensureChatPanelForSelection();
		panel?.openMarketplace();
	});

	context.subscriptions.push(
		openChat,
		openSettings,
		newChat,
		initProjectMemoryCmd,
		openSessionCmd,
		renameSessionCmd,
		deleteSessionCmd,
		exportSession,
		importSession,
		importFromHost,
		hello,
		inlineDiffAccept,
		inlineDiffReject,
		inlineDiffModify,
		inlineEdit,
		sendSelectionToChat,
		explainSymbol,
		testSymbol,
		refactorSymbol,
		explainSymbolMenu,
		testSymbolMenu,
		refactorSymbolMenu,
		openComposer,
		// R4-D: MCP marketplace command (`oati.openMarketplace`).
		openMarketplace,
		channel,
	);

	// R7-B: e2e helper commands. No-op unless `OATI_E2E=1`; the
	// @vscode/test-electron runner sets that env when launching VS Code.
	registerE2eHelpers(context, { inlineDiff, marketplace });

	// R2-E: share session — markdown export of the active chat. The existing
	// `oati.exportSession` command writes JSON (machine-readable, for re-import);
	// this sibling command writes Markdown that's pleasant to read or paste into
	// docs/bug reports. Also reachable from the webview via `/share` (the
	// `share_session_request` RPC arm calls this command).
	const exportSessionMarkdown = vscode.commands.registerCommand(
		"oati.exportSessionMarkdown",
		async () => {
			const target =
				(lastFocusedPanelId ? panels.get(lastFocusedPanelId) : undefined) ??
				panels.values().next().value;
			const targetSessionId = target?.getSessionId();
			const history =
				target?.getHistory() ?? (targetSessionId ? await session.load(targetSessionId) : []);
			if (history.length === 0) {
				vscode.window.showInformationMessage("OATI Code: no conversation to share.");
				return;
			}
			const list = await session.list();
			const meta = targetSessionId ? list.find((s) => s.id === targetSessionId) : undefined;
			const md = exportSessionAsMarkdown({ title: meta?.title, history });
			const uri = await vscode.window.showSaveDialog({
				defaultUri: vscode.Uri.file(`oati-session-${Date.now()}.md`),
				filters: { Markdown: ["md"] },
				saveLabel: "Share OATI Session (Markdown)",
			});
			if (!uri) return;
			await vscode.workspace.fs.writeFile(uri, Buffer.from(md, "utf-8"));
			vscode.window.showInformationMessage(`OATI: exported ${history.length} messages as Markdown.`);
		},
	);
	context.subscriptions.push(exportSessionMarkdown);

	// R2-E: hover explain — registers a HoverProvider for TS/JS/Python/Go/Rust
	// that asks the active provider for a 2-sentence summary of the hovered
	// function. Gated by `oati.hoverExplain.enabled` (default true).
	registerHoverExplain(context, {
		settings,
		providerManager,
		log: channel,
	});

	// R2-E: predictive next-edit ghost-text. Off by default
	// (`oati.predictiveEdit.enabled`). Suggestions accept on Tab via the
	// `oati.acceptPrediction` command, gated by the `oati.predictionVisible`
	// context key (declared in this module).
	registerPredictiveEdit(context, {
		settings,
		providerManager,
		log: channel,
	});

	// R5-A: inline completion (Copilot-style ghost text) — fires on keystroke,
	// debounced. Complementary to predictive-edit (pause-driven). Toggle via
	// `oati.inlineCompletion.enabled` or the `oati.toggleInlineCompletion`
	// command. Stats are surfaced to the agent via the inline_completion_stats
	// tool.
	registerInlineCompletion(context, {
		settings,
		providerManager,
		kv,
		log: channel,
	});
	// 2026-06-02: status-bar item surfacing inline-completion acceptance
	// rate. Click → QuickPick with full stats. Helps users see whether
	// the feature is actually helping; provides product signal on
	// accept rate without telemetry plumbing.
	registerInlineCompletionStatusBar({ subscriptions: context.subscriptions });
	// 2026-06-03: one-time toast suggesting a separate FIM-capable model
	// for autocomplete when the chat model is heavy (K2.6, Claude,
	// GPT-4o, Gemini). Idempotent — `oati.toast.fimSuggestionShown` in
	// KV prevents re-nagging. Fire-and-forget; failures don't break
	// activation.
	void (async () => {
		try {
			const activeModelId = providerManager.resolveActiveModelId(settings.config);
			await maybeShowFimSuggestion(activeModelId, { kv, log: channel });
		} catch (err) {
			channel.appendLine(
				`[fim-suggest] activation hook failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	})();
	_setInlineCompletionStatsReader(() => {
		const s = getInlineCompletionStats();
		const total = s.accepted + s.rejected;
		return { ...s, acceptanceRate: total === 0 ? 0 : s.accepted / total };
	});

	// Initial refresh so the tree shows existing sessions (including any migrated v1 ones).
	refreshUi();

	// R2-B: status bar
	// Long-running background tasks survive panel close; the status bar exposes
	// live cost / token usage plus a running-task count so the user can see
	// progress at a glance. We hook into newly-created ChatPanels by overriding
	// `panels.set` (the only mutation point) so existing call sites — which we
	// must not reorder — automatically wire up the listener.
	{
		const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		const backgroundTasks = new BackgroundTaskRunner({
			...(workspaceRoot ? { workspaceRoot } : {}),
			log: channel,
		});
		backgroundTasksHolder.current = backgroundTasks;

		const statusBar = new StatusBarManager({
			initialRunningTasks: backgroundTasks.runningCount(),
		});

		// "Open or focus" command — clicking the status bar lands here. Mirrors
		// `oati.openChat`'s semantics but lives behind a stable id so we can wire
		// it without depending on the existing command's ordering.
		const openOrFocusPanel = vscode.commands.registerCommand("oati.openOrFocusPanel", async () => {
			await vscode.commands.executeCommand("oati.openChat");
		});

		// Notify every open ChatPanel about background-task state changes so
		// the in-chat tray re-renders without the webview having to poll.
		const broadcastBackgroundTasks = () => {
			for (const p of panels.values()) {
				p.refreshBackgroundTasksTray();
			}
		};
		const offProgress = backgroundTasks.onProgress(() => {
			statusBar.setRunningTasks(backgroundTasks.runningCount());
			broadcastBackgroundTasks();
		});
		const offCompleted = backgroundTasks.onCompleted(() => {
			statusBar.setRunningTasks(backgroundTasks.runningCount());
			broadcastBackgroundTasks();
		});

		// R3-E: notifications — POST a Slack/Discord webhook when a background
		// task completes (success or error). Webhook URLs come from
		// SecretStorage; if neither is set the hub silently no-ops.
		const notifier = new NotificationHub({ secrets, log: channel });
		const offNotify = backgroundTasks.onCompleted((taskId, result) => {
			const list = backgroundTasks.list();
			const meta = list.find((t) => t.id === taskId);
			const label = meta?.label ?? taskId;
			const kind =
				result.status === "completed"
					? "task_completed"
					: result.status === "error"
						? "build_failed"
						: "task_completed";
			void notifier.notify({
				kind,
				title: `${result.status === "error" ? "Task failed" : "Task done"}: ${label}`,
				body: result.summary,
			});
		});

		// Helper: resolve the currently active model id for cost estimation.
		const resolveActiveModelId = (): string | undefined => {
			const cfg = settings.config;
			const activeMode = cfg.modes.find((m) => m.id === cfg.activeModeId) ?? cfg.modes[0];
			if (activeMode?.modelId) return activeMode.modelId;
			const providerId = activeMode?.providerId ?? cfg.activeProviderId;
			const provider = cfg.providers.find((p) => p.id === providerId);
			return provider?.defaultModel || undefined;
		};

		// Wrap `panels.set` so any future ChatPanel that lands in the map gets a
		// status-bar listener wired up. The original `set` is preserved verbatim
		// — we just chain a side-effect after it returns.
		const originalSet = panels.set.bind(panels);
		panels.set = ((key: string, value: ChatPanel) => {
			originalSet(key, value);
			try {
				value.attachConductorListener((ev) => {
					if (ev.type !== "usage") return;
					const modelId = resolveActiveModelId();
					const cost = modelId ? estimateCost(modelId, ev.inputTokens, ev.outputTokens) : undefined;
					statusBar.handleAgentEvent(ev, cost?.totalUsd ?? 0);
				});
			} catch (err) {
				channel.appendLine(
					`[status-bar] attach failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
			return panels;
		}) as typeof panels.set;

		context.subscriptions.push(
			openOrFocusPanel,
			{ dispose: () => offProgress() },
			{ dispose: () => offCompleted() },
			{ dispose: () => backgroundTasks.dispose() },
			{ dispose: () => statusBar.dispose() },
			// R3-E: notifications
			{ dispose: () => offNotify() },
		);

		// Background supervisor agent. Dedicated Conductor so the supervisor's
		// model calls can't get tangled up with the user's interactive runs.
		const supervisorHost = createHostContext({
			output: channel,
			requestApproval: async () => false, // supervisor is read-only
			showDiff: async () => {},
		});
		const supervisorConductor = new Conductor({
			providers: providerManager.registry,
			tools,
			host: supervisorHost,
		});
		const supervisor = new SupervisorAgent({
			conductor: supervisorConductor,
			providerManager,
			settings,
			log: channel,
		});
		supervisorHolder.current = supervisor;
		// Broadcast suggestion changes to every open chat panel.
		const offSupervisor = supervisor.onChange((snap) => {
			for (const p of panels.values()) {
				p.pushSupervisorSuggestions(snap);
			}
		});
		// Re-read config on change so flipping the toggle takes effect without restart.
		const onCfgChange = vscode.workspace.onDidChangeConfiguration((e) => {
			if (!e.affectsConfiguration("oati.supervisor")) return;
			const enabled = vscode.workspace
				.getConfiguration("oati.supervisor")
				.get<boolean>("enabled", false);
			if (enabled) {
				supervisor.start();
			} else {
				supervisor.stop();
				supervisor.clear();
			}
		});
		supervisor.start();

		// `oati.config.set` — let the webview Settings panel flip workspace-
		// scope toggles (supervisor, streamingWrites, inlineCompletion) via
		// the standard `run_vscode_command` RPC. Restricted to keys under
		// `oati.*` so the webview can't write to arbitrary config namespaces.
		const setConfigCmd = vscode.commands.registerCommand(
			"oati.config.set",
			async (key?: unknown, value?: unknown) => {
				if (typeof key !== "string" || !key.startsWith("oati.")) return;
				const dot = key.lastIndexOf(".");
				if (dot < 0) return;
				const section = key.slice(0, dot);
				const field = key.slice(dot + 1);
				await vscode.workspace
					.getConfiguration(section)
					.update(field, value, vscode.ConfigurationTarget.Global);
			},
		);

		context.subscriptions.push(
			{ dispose: () => offSupervisor() },
			{ dispose: () => onCfgChange.dispose() },
			{ dispose: () => supervisor.stop() },
			setConfigCmd,
		);
	}

	// R3-E: notifications — webhook setter commands. Prompts for a URL and
	// stores it in SecretStorage so the NotificationHub picks it up on the
	// next task completion. Empty input clears the stored value.
	const setSlackWebhook = vscode.commands.registerCommand("oati.setSlackWebhook", async () => {
		const current = await secrets.get(SLACK_SECRET_KEY);
		const next = await vscode.window.showInputBox({
			prompt: "Slack incoming-webhook URL (leave blank to clear)",
			value: current ?? "",
			placeHolder: "https://hooks.slack.com/services/...",
			password: true,
			ignoreFocusOut: true,
		});
		if (next === undefined) return;
		if (next.trim().length === 0) {
			await secrets.delete(SLACK_SECRET_KEY);
			vscode.window.showInformationMessage("OATI: Slack webhook cleared.");
		} else {
			await secrets.store(SLACK_SECRET_KEY, next.trim());
			vscode.window.showInformationMessage("OATI: Slack webhook saved.");
		}
	});
	const setDiscordWebhook = vscode.commands.registerCommand("oati.setDiscordWebhook", async () => {
		const current = await secrets.get(DISCORD_SECRET_KEY);
		const next = await vscode.window.showInputBox({
			prompt: "Discord webhook URL (leave blank to clear)",
			value: current ?? "",
			placeHolder: "https://discord.com/api/webhooks/...",
			password: true,
			ignoreFocusOut: true,
		});
		if (next === undefined) return;
		if (next.trim().length === 0) {
			await secrets.delete(DISCORD_SECRET_KEY);
			vscode.window.showInformationMessage("OATI: Discord webhook cleared.");
		} else {
			await secrets.store(DISCORD_SECRET_KEY, next.trim());
			vscode.window.showInformationMessage("OATI: Discord webhook saved.");
		}
	});
	context.subscriptions.push(setSlackWebhook, setDiscordWebhook);

	// R4-B: diagnostics pill — subscribe to workspace-wide diagnostic changes
	// and broadcast a tally to every open ChatPanel. Debounced 500ms so a
	// burst of LSP updates (e.g. after a save in a large TS project) doesn't
	// flood the webview. The first broadcast fires immediately at activate
	// so newly opened panels pick up the current totals without waiting for
	// the next change event.
	{
		let debounceTimer: NodeJS.Timeout | undefined;
		let lastBroadcast: { errors: number; warnings: number } | undefined;
		const broadcast = () => {
			const totals = tallyDiagnostics();
			// Skip no-op broadcasts to keep webview render churn low.
			if (
				lastBroadcast &&
				lastBroadcast.errors === totals.errors &&
				lastBroadcast.warnings === totals.warnings
			) {
				return;
			}
			lastBroadcast = totals;
			for (const p of panels.values()) {
				p.postToWebview({
					type: "diagnostics_count",
					errors: totals.errors,
					warnings: totals.warnings,
				});
			}
		};
		const sub = vscode.languages.onDidChangeDiagnostics(() => {
			if (debounceTimer) clearTimeout(debounceTimer);
			debounceTimer = setTimeout(broadcast, 500);
		});
		// Prime any panels that already exist (rare on activate, but cheap).
		broadcast();
		context.subscriptions.push(sub, {
			dispose: () => {
				if (debounceTimer) clearTimeout(debounceTimer);
			},
		});

		// Wrap `panels.set` again (already wrapped by status-bar block above) so
		// freshly opened panels receive the current tally on mount without
		// waiting for the next diagnostics change.
		const originalSet = panels.set.bind(panels);
		panels.set = ((key: string, value: ChatPanel) => {
			originalSet(key, value);
			try {
				const totals = lastBroadcast ?? tallyDiagnostics();
				value.postToWebview({
					type: "diagnostics_count",
					errors: totals.errors,
					warnings: totals.warnings,
				});
			} catch (err) {
				channel.appendLine(
					`[diagnostics-pill] prime failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
			return panels;
		}) as typeof panels.set;
	}

	// R4-C: project templates — `oati.initTemplate` picks a template via
	// QuickPick, then applies it under the chosen target directory (workspace
	// root by default, with a "Choose folder…" affordance). The webview's
	// `/init` slash command bypasses this command and talks RPC directly so
	// keyboard-driven users never leave the chat.
	const initTemplate = vscode.commands.registerCommand("oati.initTemplate", async () => {
		const { listTemplates, applyTemplate } = await import("./templates");
		const items = listTemplates();
		const pick = await vscode.window.showQuickPick(
			items.map((t) => ({ label: t.name, description: t.description, name: t.name })),
			{
				placeHolder: "Pick a project template to initialize",
				matchOnDescription: true,
			},
		);
		if (!pick) return;
		const folders = vscode.workspace.workspaceFolders ?? [];
		let target: vscode.Uri | undefined = folders.length === 1 ? folders[0].uri : folders[0]?.uri;
		if (folders.length === 0) {
			const picked = await vscode.window.showOpenDialog({
				canSelectFolders: true,
				canSelectFiles: false,
				canSelectMany: false,
				openLabel: "Initialize template here",
			});
			if (!picked || picked.length === 0) return;
			target = picked[0];
		}
		if (!target) {
			vscode.window.showErrorMessage("OATI: pick a target folder first.");
			return;
		}
		try {
			const host = createHostContext({
				output: channel,
				requestApproval: async () => true,
				showDiff: async () => {
					/* no-op for template init */
				},
				getCodebaseIndex: () => codebaseIndexManager.asSearchProvider(),
			});
			const result = await applyTemplate(pick.name, target, { host, log: channel });
			vscode.window.showInformationMessage(
				`OATI: template '${pick.name}' applied. Created ${result.created.length}, skipped ${result.skipped.length}.`,
			);
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			vscode.window.showErrorMessage(`OATI: template init failed — ${message}`);
		}
	});
	context.subscriptions.push(initTemplate);

	// R5-E: offline badge — broadcast `offline_mode` to every open panel on
	// activate and any time settings change. The webview header shows a small
	// "🔒 Offline" pill when every configured provider is local.
	{
		const { isOfflineMode, localProviderIds } = await import("./offline-mode");
		const broadcastOffline = () => {
			const cfg = settings.config;
			const offline = isOfflineMode(cfg);
			const localProviders = localProviderIds(cfg);
			for (const p of panels.values()) {
				p.postToWebview({ type: "offline_mode", offline, localProviders });
			}
		};
		broadcastOffline();
		const offSettings = settings.on(() => broadcastOffline());
		// Also prime newly-opened panels by wrapping panels.set (already wrapped
		// twice above; this is a third tail).
		const originalSet = panels.set.bind(panels);
		panels.set = ((key: string, value: ChatPanel) => {
			originalSet(key, value);
			try {
				const cfg = settings.config;
				value.postToWebview({
					type: "offline_mode",
					offline: isOfflineMode(cfg),
					localProviders: localProviderIds(cfg),
				});
			} catch (err) {
				channel.appendLine(
					`[offline-mode] prime failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
			return panels;
		}) as typeof panels.set;
		context.subscriptions.push({ dispose: () => offSettings() });
	}

	// R5-E: toggle the auto-revert safety net via command palette. Mirrors
	// the `oati.autoRevert.enabled` setting (workspace scope) so users don't
	// have to dive into settings.json.
	{
		const toggle = vscode.commands.registerCommand("oati.toggleAutoRevert", async () => {
			const ar = vscode.workspace.getConfiguration("oati.autoRevert");
			const next = !ar.get<boolean>("enabled", false);
			await ar.update("enabled", next, vscode.ConfigurationTarget.Workspace);
			vscode.window.showInformationMessage(
				`OATI: auto-revert safety net is now ${next ? "ON" : "OFF"}.`,
			);
		});
		context.subscriptions.push(toggle);
	}

	// R6-A: memory consolidation — manual command + optional auto-schedule.
	// The command walks sessions older than `oati.memoryConsolidation.daysOld`
	// and promotes 1-3 "lessons learned" each into `<workspace>/.oati/facts.json`.
	{
		const LAST_RUN_KEY = "oati.memoryConsolidator.lastRunAt";
		const resolveActiveModelIdForMemory = (): string | undefined => {
			const cfg = settings.config;
			const activeMode = cfg.modes.find((m) => m.id === cfg.activeModeId) ?? cfg.modes[0];
			if (activeMode?.modelId) return activeMode.modelId;
			const providerId = activeMode?.providerId ?? cfg.activeProviderId;
			const provider = cfg.providers.find((p) => p.id === providerId);
			return provider?.defaultModel || undefined;
		};
		const runConsolidation = async (silent: boolean): Promise<void> => {
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			if (!root) {
				if (!silent)
					vscode.window.showWarningMessage("OATI: open a workspace before consolidating memory.");
				return;
			}
			const modelId = resolveActiveModelIdForMemory();
			if (!modelId) {
				if (!silent)
					vscode.window.showWarningMessage("OATI: no model configured — set one in Settings first.");
				return;
			}
			const cfg = vscode.workspace.getConfiguration("oati.memoryConsolidation");
			const daysOld = cfg.get<number>("daysOld", 30);
			try {
				const { consolidateOldSessions } = await import("./memory-consolidator");
				const provider = providerManager.registry.list()[0];
				if (!provider) {
					if (!silent) vscode.window.showWarningMessage("OATI: no provider registered.");
					return;
				}
				const result = await consolidateOldSessions(session, {
					workspaceRoot: root,
					provider,
					modelId,
					daysOld,
				});
				await kv.update(LAST_RUN_KEY, new Date().toISOString());
				const note = `OATI memory: scanned ${result.scanned} session(s), promoted ${result.promoted} fact(s) (skipped ${result.skipped}).`;
				if (!silent) vscode.window.showInformationMessage(note);
				else channel.appendLine(`[memory-consolidator] ${note}`);
			} catch (err) {
				const message = err instanceof Error ? err.message : String(err);
				channel.appendLine(`[memory-consolidator] failed: ${message}`);
				if (!silent) vscode.window.showErrorMessage(`OATI memory consolidation failed: ${message}`);
			}
		};
		const consolidate = vscode.commands.registerCommand("oati.consolidateMemory", () =>
			runConsolidation(false),
		);
		context.subscriptions.push(consolidate);
		// Optional auto-schedule.
		const cfg = vscode.workspace.getConfiguration("oati.memoryConsolidation");
		const autoEvery = cfg.get<number>("autoEvery", 0);
		if (autoEvery > 0) {
			const lastIso = kv.get<string>(LAST_RUN_KEY);
			const lastMs = lastIso ? Date.parse(lastIso) : 0;
			const ageDays = (Date.now() - lastMs) / (24 * 60 * 60 * 1000);
			if (!Number.isFinite(lastMs) || lastMs === 0 || ageDays >= autoEvery) {
				void runConsolidation(true);
			}
		}
	}

	// R6-E: debug session pill — register the DebugAdapterTracker that
	// observes `stopped` / `continued` DAP events, then broadcast a
	// `debug_session_state` envelope to every open panel on any change. New
	// panels also get primed via the panels.set wrapper below (the fourth
	// such tail; the diagnostics + offline blocks each wrap once too).
	{
		const debugBridge = activateDebugBridge(context);
		const broadcastDebug = () => {
			const active = debugBridge.getActiveSession();
			const envelope: import("@oati/shared").HostToWebview = active
				? {
						type: "debug_session_state",
						active: true,
						sessionType: active.type,
						sessionName: active.name,
						...(debugBridge.getStoppedThreadId() !== undefined
							? { stoppedThreadId: debugBridge.getStoppedThreadId() as number }
							: {}),
					}
				: { type: "debug_session_state", active: false };
			for (const p of panels.values()) p.postToWebview(envelope);
		};
		const off = debugBridge.onStateChange(broadcastDebug);
		// Prime existing panels on activate.
		broadcastDebug();
		const originalSet = panels.set.bind(panels);
		panels.set = ((key: string, value: ChatPanel) => {
			originalSet(key, value);
			try {
				const active = debugBridge.getActiveSession();
				const envelope: import("@oati/shared").HostToWebview = active
					? {
							type: "debug_session_state",
							active: true,
							sessionType: active.type,
							sessionName: active.name,
							...(debugBridge.getStoppedThreadId() !== undefined
								? { stoppedThreadId: debugBridge.getStoppedThreadId() as number }
								: {}),
						}
					: { type: "debug_session_state", active: false };
				value.postToWebview(envelope);
			} catch (err) {
				channel.appendLine(
					`[debug-bridge] prime failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
			return panels;
		}) as typeof panels.set;
		context.subscriptions.push({ dispose: () => off() });
	}

	// R6-C: AI commit message generation.
	// Command resolves the active mode + model, runs a one-shot agent turn against
	// the staged diff, and pokes the result into the built-in git extension's SCM
	// input box.
	{
		const cmd = vscode.commands.registerCommand("oati.generateCommitMessage", async () => {
			const config = settings.config;
			const baseMode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
			if (!baseMode) {
				vscode.window.showErrorMessage("OATI: no agent mode configured.");
				return;
			}
			const modelId = providerManager.resolveActiveModelId(config);
			if (!modelId) {
				vscode.window.showErrorMessage(
					"OATI: no model configured. Open OATI: Open Settings and set a Model ID.",
				);
				return;
			}
			// Build a minimal host + one-shot conductor for the commit-message turn.
			// Approvals auto-deny because this flow shouldn't trigger tool prompts.
			const host = createHostContext({
				output: channel,
				requestApproval: async () => false,
				showDiff: async () => {
					/* no-op for commit-message */
				},
				getCodebaseIndex: () => codebaseIndexManager.asSearchProvider(),
			});
			const conductor = new Conductor({ providers: providerManager.registry, tools, host });
			await vscode.window.withProgress(
				{
					location: vscode.ProgressLocation.SourceControl,
					title: "OATI: generating commit message…",
				},
				async () => {
					try {
						const msg = await generateCommitMessage({
							host,
							conductor,
							mode: baseMode,
							modelId,
							providerId: config.activeProviderId,
						});
						const formatted = formatCommitMessage(msg);
						const gitExt = vscode.extensions.getExtension<unknown>("vscode.git");
						if (!gitExt) {
							vscode.window.showWarningMessage(
								"OATI: built-in Git extension not found; copying message to clipboard instead.",
							);
							await vscode.env.clipboard.writeText(formatted);
							return;
						}
						const ext = gitExt.isActive ? gitExt.exports : await gitExt.activate();
						// vscode.git uses an `.getAPI(version)` accessor — see
						// https://github.com/microsoft/vscode/tree/main/extensions/git
						const api =
							typeof (ext as { getAPI?: (v: number) => unknown }).getAPI === "function"
								? ((ext as { getAPI: (v: number) => unknown }).getAPI(1) as {
										repositories: { inputBox: { value: string }; rootUri?: { fsPath: string } }[];
									})
								: undefined;
						const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
						const repo = pickPrimaryRepo(api, wsRoot);
						if (!repo) {
							vscode.window.showWarningMessage(
								"OATI: no git repository in this workspace; copying message to clipboard instead.",
							);
							await vscode.env.clipboard.writeText(formatted);
							return;
						}
						repo.inputBox.value = formatted;
						channel.appendLine(
							`[commit-message] populated SCM input box (${msg.subject.length}c subject)`,
						);
					} catch (err) {
						if (err instanceof EmptyDiffError) {
							vscode.window.showWarningMessage(`OATI: ${err.message}`);
							return;
						}
						const message = err instanceof Error ? err.message : String(err);
						channel.appendLine(`[commit-message] failed: ${message}`);
						vscode.window.showErrorMessage(`OATI: commit message generation failed — ${message}`);
					}
				},
			);
		});
		context.subscriptions.push(cmd);
	}

	// R6-C: PR-on-open auto review.
	// Polls `gh pr list` on an interval and, for any new PR not authored by the
	// current user, runs the existing reviewPullRequest(...) helper from R3-C
	// in a background slot. Posts the review as a PR comment when
	// `oati.prWatch.autoComment` is true; otherwise notifies with a "Review now"
	// button that opens the chat panel and runs the review interactively.
	{
		const watchCfg = () => vscode.workspace.getConfiguration("oati.prWatch");
		const watchers = new Map<string, PrWatcher>();
		let activeRepo: string | undefined;

		const stopAllWatchers = () => {
			for (const w of watchers.values()) w.stop();
			watchers.clear();
		};

		const ensureWatcher = async (): Promise<void> => {
			const cfg = watchCfg();
			const enabled = cfg.get<boolean>("enabled", false);
			if (!enabled) {
				stopAllWatchers();
				return;
			}
			// Probe a one-shot host so we can call `gh repo view` / `gh api user`.
			const host = createHostContext({
				output: channel,
				requestApproval: async () => false,
				showDiff: async () => undefined,
				getCodebaseIndex: () => codebaseIndexManager.asSearchProvider(),
			});
			let repo = activeRepo;
			if (!repo) {
				repo = await detectCurrentRepo(host);
				activeRepo = repo;
			}
			if (!repo) {
				channel.appendLine("[pr-watch] no GitHub repo detected (run gh auth login + git remote add)");
				return;
			}
			if (watchers.has(repo)) return;
			const currentUser = (await detectCurrentUser(host)) ?? "";
			const intervalMinutes = Math.max(1, cfg.get<number>("intervalMinutes", 5));
			const watcher = new PrWatcher({
				repo,
				host,
				intervalMs: intervalMinutes * 60_000,
				currentUser,
				log: channel,
			});
			watcher.onNewPr((pr) => {
				const autoComment = watchCfg().get<boolean>("autoComment", false);
				const url = pr.url ?? `https://github.com/${repo}/pull/${pr.number}`;
				channel.appendLine(`[pr-watch] new PR #${pr.number} by ${pr.author.login}`);
				void (async () => {
					if (!autoComment) {
						const choice = await vscode.window.showInformationMessage(
							`OATI: new PR #${pr.number} by ${pr.author.login}${pr.title ? ` — ${pr.title}` : ""}`,
							"Review now",
							"Dismiss",
						);
						if (choice === "Review now") {
							// Open the chat panel and forward the request to the
							// existing review path.
							await vscode.commands.executeCommand("oati.openChat");
							// Defer to the panel-level RPC via a shared command.
							await vscode.commands.executeCommand("oati.reviewPullRequest", url);
						}
						return;
					}
					// autoComment: drive reviewPullRequest in the background. Build a
					// throwaway conductor + mode for the one-shot run.
					const config = settings.config;
					const baseMode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
					const modelId = providerManager.resolveActiveModelId(config);
					if (!baseMode || !modelId) {
						channel.appendLine("[pr-watch] skip autoComment — no mode or model configured");
						return;
					}
					const bgHost = createHostContext({
						output: channel,
						// Auto-approve the post step since this is the explicit opt-in path.
						requestApproval: async () => true,
						showDiff: async () => undefined,
						getCodebaseIndex: () => codebaseIndexManager.asSearchProvider(),
					});
					const conductor = new Conductor({ providers: providerManager.registry, tools, host: bgHost });
					try {
						const result = await reviewPullRequest(
							{ url, postComments: true },
							{
								host: bgHost,
								conductor,
								mode: baseMode,
								modelId,
								providerId: config.activeProviderId,
								history: [],
							},
						);
						if (result.status === "ok") {
							vscode.window.showInformationMessage(`OATI: posted review on PR #${pr.number}.`);
						} else if (result.status === "error") {
							channel.appendLine(`[pr-watch] review failed: ${result.message ?? "unknown"}`);
						}
					} catch (err) {
						const msg = err instanceof Error ? err.message : String(err);
						channel.appendLine(`[pr-watch] review threw: ${msg}`);
					}
				})();
			});
			watcher.start();
			watchers.set(repo, watcher);
			channel.appendLine(
				`[pr-watch] started on ${repo} every ${intervalMinutes}min (autoComment=${cfg.get<boolean>("autoComment", false)})`,
			);
		};

		// React to settings changes (toggle on/off, change interval).
		const offCfg = vscode.workspace.onDidChangeConfiguration((ev) => {
			if (ev.affectsConfiguration("oati.prWatch")) {
				stopAllWatchers();
				void ensureWatcher();
			}
		});

		// Toggle command — mirrors `oati.toggleAutoRevert` shape.
		const toggleCmd = vscode.commands.registerCommand("oati.togglePrWatch", async () => {
			const cfg = watchCfg();
			const next = !cfg.get<boolean>("enabled", false);
			await cfg.update("enabled", next, vscode.ConfigurationTarget.Workspace);
			vscode.window.showInformationMessage(`OATI: PR-on-open watch is now ${next ? "ON" : "OFF"}.`);
		});

		// Forwarder command so the "Review now" notification button can hop into
		// the chat panel's existing review path without each notification needing
		// to know about the webview RPC.
		const reviewCmd = vscode.commands.registerCommand(
			"oati.reviewPullRequest",
			async (url?: string) => {
				const target =
					url ??
					(await vscode.window.showInputBox({
						prompt: "GitHub PR URL to review",
						placeHolder: "https://github.com/owner/repo/pull/123",
					}));
				if (!target) return;
				await vscode.commands.executeCommand("oati.openChat");
				const panel =
					(lastFocusedPanelId ? panels.get(lastFocusedPanelId) : undefined) ??
					panels.values().next().value;
				panel?.prefillPrompt(`/review-pr ${target}`);
			},
		);

		context.subscriptions.push(
			toggleCmd,
			reviewCmd,
			{ dispose: () => offCfg.dispose() },
			{ dispose: () => stopAllWatchers() },
		);

		// Kick off the initial watcher (no-op if disabled).
		void ensureWatcher();
	}
}

export function deactivate(): void {
	// no-op
}

function resolveSessionId(arg: SessionMeta | { id: string } | undefined): string | undefined {
	if (!arg) return undefined;
	if (typeof arg === "string") return arg;
	if ("id" in arg && typeof arg.id === "string") return arg.id;
	return undefined;
}

function extractFinalAssistantText(
	history: readonly import("@oati/shared").ConversationMessage[],
): string {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		const chunks: string[] = [];
		for (const p of msg.parts) if (p.kind === "text") chunks.push(p.text);
		const text = chunks.join("");
		if (text.trim().length > 0) return text;
	}
	return "(sub-agent produced no text output)";
}
