// R4-C: snippet library — markdown files under <workspace>/.oati/snippets/.
// Each file's H1 line is the description; the rest (after the H1) is the body.
import { promises as fs } from "node:fs";
import * as path from "node:path";

/** Slug shape — same as the custom-slash-command convention. */
const VALID_NAME = /^[a-zA-Z0-9_-]+$/;

export interface SnippetSummary {
	readonly name: string;
	readonly description: string;
}

/** Relative directory under the workspace root that stores snippets. */
export const SNIPPETS_RELATIVE_DIR = ".oati/snippets";

function snippetsDir(workspaceRoot: string): string {
	return path.join(workspaceRoot, SNIPPETS_RELATIVE_DIR);
}

function snippetFile(workspaceRoot: string, name: string): string {
	return path.join(snippetsDir(workspaceRoot), `${name}.md`);
}

function isValidName(name: string): boolean {
	return VALID_NAME.test(name);
}

/**
 * List every snippet in `<workspaceRoot>/.oati/snippets/*.md`. Missing
 * directory returns `[]`; unreadable / invalid files are silently skipped.
 * Sorted by name for stable UI ordering.
 */
export async function listSnippets(workspaceRoot: string): Promise<SnippetSummary[]> {
	if (!workspaceRoot) return [];
	const dir = snippetsDir(workspaceRoot);
	let entries: string[];
	try {
		entries = await fs.readdir(dir);
	} catch {
		return [];
	}
	const out: SnippetSummary[] = [];
	for (const entry of entries) {
		if (!entry.toLowerCase().endsWith(".md")) continue;
		const name = entry.slice(0, -3);
		if (!isValidName(name)) continue;
		const abs = path.join(dir, entry);
		let raw: string;
		try {
			const stat = await fs.stat(abs);
			if (!stat.isFile()) continue;
			raw = await fs.readFile(abs, "utf-8");
		} catch {
			continue;
		}
		out.push({ name, description: extractDescription(raw, name) });
	}
	out.sort((a, b) => a.name.localeCompare(b.name));
	return out;
}

/**
 * Read just the snippet body — everything AFTER the first H1 line. Returns
 * `null` when the snippet doesn't exist; throws on other I/O errors so callers
 * can surface a friendly message.
 */
export async function readSnippet(workspaceRoot: string, name: string): Promise<string | null> {
	if (!workspaceRoot || !isValidName(name)) return null;
	const abs = snippetFile(workspaceRoot, name);
	let raw: string;
	try {
		raw = await fs.readFile(abs, "utf-8");
	} catch (err) {
		if ((err as NodeJS.ErrnoException).code === "ENOENT") return null;
		throw err;
	}
	return extractBody(raw);
}

/**
 * Save (create or overwrite) a snippet. The on-disk file always carries a
 * single H1 description on the first line — synthesizing one from the snippet
 * name when the caller doesn't provide an explicit description.
 */
export async function saveSnippet(
	workspaceRoot: string,
	name: string,
	body: string,
	description?: string,
): Promise<void> {
	if (!workspaceRoot) throw new Error("saveSnippet: workspaceRoot is required");
	if (!isValidName(name)) {
		throw new Error(
			`saveSnippet: invalid snippet name '${name}'. Use letters, digits, underscore, or dash.`,
		);
	}
	const dir = snippetsDir(workspaceRoot);
	await fs.mkdir(dir, { recursive: true });
	const desc = (description ?? name).trim() || name;
	const trimmedBody = body.replace(/^\r?\n+/, "");
	const doc = `# ${desc}\n\n${trimmedBody}${trimmedBody.endsWith("\n") ? "" : "\n"}`;
	await fs.writeFile(snippetFile(workspaceRoot, name), doc, "utf-8");
}

/** Delete a snippet. Silently no-ops when the snippet doesn't exist. */
export async function deleteSnippet(workspaceRoot: string, name: string): Promise<void> {
	if (!workspaceRoot || !isValidName(name)) return;
	try {
		await fs.unlink(snippetFile(workspaceRoot, name));
	} catch (err) {
		if ((err as NodeJS.ErrnoException).code === "ENOENT") return;
		throw err;
	}
}

function extractDescription(raw: string, fallback: string): string {
	const lines = raw.split(/\r?\n/);
	for (const line of lines) {
		if (line.trim().length === 0) continue;
		const m = /^#\s+(.+?)\s*$/.exec(line);
		if (m) return m[1];
		break;
	}
	return fallback;
}

function extractBody(raw: string): string {
	const lines = raw.split(/\r?\n/);
	let bodyStart = 0;
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		if (line.trim().length === 0) continue;
		if (/^#\s+/.test(line)) {
			bodyStart = i + 1;
			// Skip a single blank line after the H1 so the body reads cleanly.
			if (lines[bodyStart]?.trim().length === 0) bodyStart++;
		}
		break;
	}
	return lines.slice(bodyStart).join("\n").replace(/\s+$/, "");
}
