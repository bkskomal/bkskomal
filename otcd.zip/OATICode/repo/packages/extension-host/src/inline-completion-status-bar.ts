import * as vscode from "vscode";
import {
	type InlineCompletionStats,
	getInlineCompletionStats,
	onInlineCompletionStatsChange,
} from "./inline-completion";

/**
 * 2026-06-02: status-bar item that surfaces inline-completion value to
 * the user — accepted count and acceptance rate against the chat-model
 * activity bar. Cursor / Copilot both do this; without it, users have
 * no signal that the feature is helping (or how often it's right) and
 * accept rate is invisible to product decisions.
 *
 * Click opens a QuickPick with the full stats breakdown and a "reset"
 * action.
 */

export const SHOW_STATS_COMMAND = "oati.inlineCompletion.showStats";

/**
 * Compose the status-bar label. Exported pure for unit testability.
 *
 *   - When `shown === 0`: `↹ OATI` (idle — no completions yet this session)
 *   - When `shown > 0`:    `↹ {rate}% ({accepted}/{shown})`
 *
 * The rate is computed as accepted / shown × 100 (rounded). Rejected
 * count is informational only and goes in the tooltip — it's the diff
 * between shown and accepted minus the "neither accepted nor rejected"
 * case (user just kept typing, suggestion dismissed implicitly).
 */
export function buildStatusBarLabel(stats: InlineCompletionStats): string {
	if (stats.shown === 0) return "$(arrow-right) OATI";
	const rate = Math.round((stats.accepted / stats.shown) * 100);
	return `$(arrow-right) ${rate}% (${stats.accepted}/${stats.shown})`;
}

/**
 * Compose the tooltip markdown source string. Returned as plain text
 * (no vscode-specific wrapper) so it's testable without a vscode
 * module shim; the caller wraps it in `vscode.MarkdownString` at the
 * actual assignment site.
 */
export function buildStatusBarTooltip(stats: InlineCompletionStats): string {
	const lines: string[] = ["**OATI Inline Completion**", ""];
	if (stats.shown === 0) {
		lines.push(
			"No completions shown yet this session. Start typing in a supported file to see ghost-text suggestions.",
		);
	} else {
		const rate = Math.round((stats.accepted / stats.shown) * 100);
		lines.push(`- Acceptance rate: **${rate}%**`);
		lines.push(`- Accepted: ${stats.accepted}`);
		lines.push(`- Rejected: ${stats.rejected}`);
		lines.push(`- Shown: ${stats.shown}`);
		const implicit = stats.shown - stats.accepted - stats.rejected;
		if (implicit > 0) {
			lines.push(
				`- Dismissed by typing past: ${implicit} _(user kept typing without explicit accept/reject)_`,
			);
		}
	}
	lines.push("");
	lines.push("_Click to see details and reset counters._");
	return lines.join("\n");
}

export interface StatusBarDeps {
	/** Subscriptions array — the extension's context.subscriptions. */
	readonly subscriptions: Array<{ dispose: () => void }>;
	/** Optional override for tests; defaults to vscode.window.createStatusBarItem. */
	readonly createStatusBarItem?: typeof vscode.window.createStatusBarItem;
	/** Optional override for tests; defaults to vscode.commands.registerCommand. */
	readonly registerCommand?: typeof vscode.commands.registerCommand;
	/** Optional override for tests; defaults to vscode.window.showQuickPick. */
	readonly showQuickPick?: typeof vscode.window.showQuickPick;
}

/**
 * Register the status-bar item + click command. Idempotent across
 * activations only if the caller hands fresh deps; we don't track
 * global state. Returns the disposables registered (they're also
 * pushed to `deps.subscriptions`).
 */
export function registerInlineCompletionStatusBar(deps: StatusBarDeps): { dispose: () => void } {
	const createItem =
		deps.createStatusBarItem ?? vscode.window.createStatusBarItem.bind(vscode.window);
	const registerCmd = deps.registerCommand ?? vscode.commands.registerCommand.bind(vscode.commands);
	const showQp = deps.showQuickPick ?? vscode.window.showQuickPick.bind(vscode.window);

	const item = createItem(vscode.StatusBarAlignment.Right, 99);
	item.command = SHOW_STATS_COMMAND;
	const refresh = (s: InlineCompletionStats) => {
		item.text = buildStatusBarLabel(s);
		const md = new vscode.MarkdownString(buildStatusBarTooltip(s), true);
		md.isTrusted = false;
		item.tooltip = md;
	};
	refresh(getInlineCompletionStats());
	item.show();
	const statsSub = onInlineCompletionStatsChange(refresh);

	const cmd = registerCmd(SHOW_STATS_COMMAND, async () => {
		const s = getInlineCompletionStats();
		const items: vscode.QuickPickItem[] = [
			{
				label: "$(arrow-right) Acceptance rate",
				description:
					s.shown === 0
						? "no completions yet"
						: `${Math.round((s.accepted / s.shown) * 100)}% (${s.accepted}/${s.shown})`,
			},
			{ label: "Accepted", description: String(s.accepted) },
			{ label: "Rejected", description: String(s.rejected) },
			{ label: "Shown", description: String(s.shown) },
			{
				label: "Last updated",
				description: s.lastUpdatedIso ? formatRelative(s.lastUpdatedIso) : "never",
			},
		];
		await showQp(items, {
			title: "OATI Inline Completion — session stats",
			placeHolder: "Stats are persisted across window restarts.",
		});
	});

	const disposable = {
		dispose: () => {
			statsSub.dispose();
			item.dispose();
			cmd.dispose();
		},
	};
	deps.subscriptions.push(disposable);
	return disposable;
}

/**
 * Render an ISO timestamp as a human-friendly relative string. Exported
 * pure for testability.
 */
export function formatRelative(iso: string, now: number = Date.now()): string {
	const t = new Date(iso).getTime();
	if (Number.isNaN(t)) return iso;
	const deltaSec = Math.max(0, Math.round((now - t) / 1000));
	if (deltaSec < 60) return `${deltaSec}s ago`;
	const min = Math.round(deltaSec / 60);
	if (min < 60) return `${min}m ago`;
	const hr = Math.round(min / 60);
	if (hr < 24) return `${hr}h ago`;
	const day = Math.round(hr / 24);
	return `${day}d ago`;
}
