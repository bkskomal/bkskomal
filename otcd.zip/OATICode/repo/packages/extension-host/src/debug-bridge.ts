// R6-E: debug-bridge — wraps VS Code's Debug API (DAP) so the agent (via
// `ctx.debug`) can introspect a running debug session (stack frames, scopes,
// variables, evaluate) and manage source breakpoints. Mirrors the
// extension-host's existing diagnostics-bridge / symbols-provider pattern:
// the heavy lifting happens here so the @oati/tools package can stay
// platform-agnostic and just typecheck against the `DebugBridgeProvider`
// interface from @oati/shared.
//
// Lifecycle:
//   - `activate(context)` registers a DebugAdapterTracker on every session
//     so we can observe `stopped` events and remember which thread is
//     currently halted. The tracker is the only way to surface "stopped at
//     X" without polling the DAP each call.
//   - All DAP queries route through `vscode.debug.activeDebugSession`. When
//     there is no active session the bridge methods throw a friendly error
//     that tools convert into a "no debug session" agent-facing message.
//
// Coordinates: VS Code's Debug API speaks 1-based line numbers (the same as
// the DAP protocol), so the bridge does NOT translate. Source URIs are
// normalized to `file://` URIs on the way out so the agent can match against
// `vscode.Uri.toString()` output elsewhere.
import * as path from "node:path";
import type { DebugBreakpoint, DebugBridgeProvider, DebugFrame } from "@oati/shared";
import * as vscode from "vscode";

interface SessionState {
	stoppedThreadId?: number;
}

/** Singleton holder so chat-panel and tools see the same state. */
export class DebugBridge implements DebugBridgeProvider {
	private static _instance: DebugBridge | undefined;

	/** Per-session DAP state (currently just the stopped thread id). */
	private readonly sessions = new Map<string, SessionState>();
	/**
	 * Listeners invoked whenever the session state observable changes:
	 * session start/stop, or a `stopped` event flips the active thread.
	 * Used by chat-panel to broadcast `debug_session_state` to the webview.
	 */
	private readonly listeners = new Set<() => void>();

	static instance(): DebugBridge {
		if (!DebugBridge._instance) DebugBridge._instance = new DebugBridge();
		return DebugBridge._instance;
	}

	/** Test-only: reset the singleton between unit tests. */
	static _resetForTests(): void {
		DebugBridge._instance = undefined;
	}

	/** Subscribe to state-change events. Returns an unsubscribe fn. */
	onStateChange(listener: () => void): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	private emitStateChange(): void {
		for (const l of this.listeners) {
			try {
				l();
			} catch {
				// listeners must not break the bridge — swallow.
			}
		}
	}

	getActiveSession(): { id: string; type: string; name: string } | null {
		const s = vscode.debug.activeDebugSession;
		if (!s) return null;
		return { id: s.id, type: s.type, name: s.name };
	}

	/**
	 * Thread id of the currently stopped frame, if any. Populated from the
	 * `stopped` DAP event observed by our DebugAdapterTracker; cleared on
	 * `continued`/session-end. Tools that take an optional `threadId` use
	 * this as the default.
	 */
	getStoppedThreadId(): number | undefined {
		const s = vscode.debug.activeDebugSession;
		if (!s) return undefined;
		return this.sessions.get(s.id)?.stoppedThreadId;
	}

	async getStackFrames(threadId?: number): Promise<readonly DebugFrame[]> {
		const session = this.requireSession();
		const tid = threadId ?? this.getStoppedThreadId() ?? (await this.firstThreadId(session));
		if (tid === undefined) {
			throw new Error("debug-bridge: no thread is currently stopped (and no threadId supplied)");
		}
		const resp = (await session.customRequest("stackTrace", { threadId: tid })) as
			| { stackFrames?: readonly DapStackFrame[] }
			| undefined;
		const frames = resp?.stackFrames ?? [];
		return frames.map((f) => {
			const frame: DebugFrame = {
				id: f.id,
				name: f.name,
				...(f.source?.path ? { path: f.source.path } : {}),
				...(typeof f.line === "number" ? { line: f.line } : {}),
			};
			return frame;
		});
	}

	async evaluate(expression: string, frameId?: number): Promise<string> {
		const session = this.requireSession();
		let fid = frameId;
		if (fid === undefined) {
			const frames = await this.getStackFrames();
			if (frames.length === 0) {
				throw new Error("debug-bridge: evaluate requires a frameId (no active stack to default to)");
			}
			fid = frames[0].id;
		}
		const resp = (await session.customRequest("evaluate", {
			expression,
			frameId: fid,
			context: "repl",
		})) as { result?: string } | undefined;
		return resp?.result ?? "";
	}

	async getScopes(
		frameId: number,
	): Promise<readonly { name: string; variablesReference: number }[]> {
		const session = this.requireSession();
		const resp = (await session.customRequest("scopes", { frameId })) as
			| { scopes?: readonly DapScope[] }
			| undefined;
		const scopes = resp?.scopes ?? [];
		return scopes.map((s) => ({ name: s.name, variablesReference: s.variablesReference }));
	}

	async getVariables(
		variablesReference: number,
	): Promise<readonly { name: string; value: string; type?: string }[]> {
		const session = this.requireSession();
		const resp = (await session.customRequest("variables", { variablesReference })) as
			| { variables?: readonly DapVariable[] }
			| undefined;
		const vars = resp?.variables ?? [];
		return vars.map((v) => {
			const out: { name: string; value: string; type?: string } = {
				name: v.name,
				value: v.value,
				...(v.type ? { type: v.type } : {}),
			};
			return out;
		});
	}

	listBreakpoints(): readonly DebugBreakpoint[] {
		const out: DebugBreakpoint[] = [];
		for (const bp of vscode.debug.breakpoints) {
			if (!(bp instanceof vscode.SourceBreakpoint)) continue;
			out.push({
				uri: bp.location.uri.toString(),
				// vscode.Location.range is 0-based; DAP and our spec are 1-based.
				line: bp.location.range.start.line + 1,
				...(bp.condition ? { condition: bp.condition } : {}),
				enabled: bp.enabled,
			});
		}
		return out;
	}

	async setBreakpoint(uri: string, line: number, condition?: string, enabled = true): Promise<void> {
		const resolvedUri = this.resolveUri(uri);
		const safeLine = Math.max(1, Math.floor(line));
		// VS Code's Location takes a 0-based line; the public API for the
		// agent is 1-based to match LSP/our index conventions.
		const location = new vscode.Location(
			resolvedUri,
			new vscode.Range(safeLine - 1, 0, safeLine - 1, 0),
		);
		const bp = new vscode.SourceBreakpoint(location, enabled, condition);
		vscode.debug.addBreakpoints([bp]);
	}

	async removeBreakpoint(uri: string, line: number): Promise<void> {
		const resolvedUri = this.resolveUri(uri);
		const safeLine = Math.max(1, Math.floor(line));
		const target = resolvedUri.toString();
		const matches: vscode.Breakpoint[] = [];
		for (const bp of vscode.debug.breakpoints) {
			if (!(bp instanceof vscode.SourceBreakpoint)) continue;
			if (bp.location.uri.toString() !== target) continue;
			if (bp.location.range.start.line + 1 !== safeLine) continue;
			matches.push(bp);
		}
		if (matches.length > 0) {
			vscode.debug.removeBreakpoints(matches);
		}
	}

	/** Test-only hook: simulate a `stopped` DAP event arriving for a session. */
	_recordStoppedForTests(sessionId: string, threadId: number | undefined): void {
		const state = this.sessions.get(sessionId) ?? {};
		if (threadId === undefined) state.stoppedThreadId = undefined;
		else state.stoppedThreadId = threadId;
		this.sessions.set(sessionId, state);
		this.emitStateChange();
	}

	/** Test-only hook: forget a session (mirrors what onDidTerminateDebugSession does). */
	_terminateForTests(sessionId: string): void {
		this.sessions.delete(sessionId);
		this.emitStateChange();
	}

	/** Test-only hook: notify subscribers (used by the chat-panel wiring tests). */
	_notifyForTests(): void {
		this.emitStateChange();
	}

	private requireSession(): vscode.DebugSession {
		const s = vscode.debug.activeDebugSession;
		if (!s) {
			throw new Error("debug-bridge: no active debug session");
		}
		return s;
	}

	private async firstThreadId(session: vscode.DebugSession): Promise<number | undefined> {
		try {
			const resp = (await session.customRequest("threads")) as
				| { threads?: readonly { id: number }[] }
				| undefined;
			return resp?.threads?.[0]?.id;
		} catch {
			return undefined;
		}
	}

	private resolveUri(p: string): vscode.Uri {
		// Already a URI string?
		if (/^[a-z][a-z0-9+.-]*:/i.test(p)) {
			try {
				return vscode.Uri.parse(p);
			} catch {
				// fall through to path-based resolution
			}
		}
		if (path.isAbsolute(p)) return vscode.Uri.file(p);
		const root = vscode.workspace.workspaceFolders?.[0]?.uri;
		if (!root) {
			// Last resort — treat as a bare file path so callers in test harnesses
			// without a workspace still get a deterministic URI.
			return vscode.Uri.file(p);
		}
		return vscode.Uri.joinPath(root, p);
	}

	/** Trigger registered listeners — used by the activate() wiring below. */
	_emit(): void {
		this.emitStateChange();
	}

	/** Per-session state setter used by the DebugAdapterTracker. */
	_setStoppedThread(sessionId: string, threadId: number | undefined): void {
		const state = this.sessions.get(sessionId) ?? {};
		if (threadId === undefined) state.stoppedThreadId = undefined;
		else state.stoppedThreadId = threadId;
		this.sessions.set(sessionId, state);
	}

	_dropSession(sessionId: string): void {
		this.sessions.delete(sessionId);
	}
}

// --- DAP message shapes (subset). Kept private so the tools package can't
// depend on them; callers see the normalized shapes from `@oati/shared`.
interface DapStackFrame {
	readonly id: number;
	readonly name: string;
	readonly line?: number;
	readonly source?: { readonly path?: string };
}
interface DapScope {
	readonly name: string;
	readonly variablesReference: number;
}
interface DapVariable {
	readonly name: string;
	readonly value: string;
	readonly type?: string;
}

/**
 * Register the DebugAdapterTracker that feeds `stopped` events into the
 * bridge, plus session start/terminate listeners that emit state-change
 * pulses so chat-panel can broadcast `debug_session_state` to the webview.
 *
 * Idempotent: safe to call multiple times in a single activation (later
 * calls add additional disposables but don't double-register the singleton).
 */
export function activateDebugBridge(context: vscode.ExtensionContext): DebugBridge {
	const bridge = DebugBridge.instance();

	const trackerFactory: vscode.DebugAdapterTrackerFactory = {
		createDebugAdapterTracker(session: vscode.DebugSession) {
			return {
				onDidSendMessage(msg: { type?: string; event?: string; body?: { threadId?: number } }) {
					if (msg.type !== "event") return;
					if (msg.event === "stopped") {
						bridge._setStoppedThread(session.id, msg.body?.threadId);
						bridge._emit();
					} else if (msg.event === "continued") {
						bridge._setStoppedThread(session.id, undefined);
						bridge._emit();
					}
				},
				onWillStopSession() {
					bridge._dropSession(session.id);
					bridge._emit();
				},
			};
		},
	};

	// `*` matches every debug type — Python, Node, Go, etc. — so we observe
	// the entire workspace without enumerating known adapters.
	const trackerDisposable = vscode.debug.registerDebugAdapterTrackerFactory("*", trackerFactory);
	const startSub = vscode.debug.onDidStartDebugSession(() => bridge._emit());
	const endSub = vscode.debug.onDidTerminateDebugSession((s) => {
		bridge._dropSession(s.id);
		bridge._emit();
	});
	const bpSub = vscode.debug.onDidChangeBreakpoints(() => bridge._emit());

	context.subscriptions.push(trackerDisposable, startSub, endSub, bpSub);
	return bridge;
}
