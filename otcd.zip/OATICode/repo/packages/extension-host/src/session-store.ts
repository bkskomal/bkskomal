import {
	type ConversationMessage,
	type SessionIndex,
	type SessionMeta,
	deriveSessionTitle,
} from "@oati/shared";
import type { KvStorage } from "./storage";

const LEGACY_KEY_PREFIX = "oati.session.v1.";
const INDEX_KEY_PREFIX = "oati.session-index.v2.";
const DATA_KEY_PREFIX = "oati.session-data.v2.";

const MAX_HISTORY_BYTES = 1_000_000;
const EXPORT_VERSION = 1;

export interface SessionExport {
	readonly version: number;
	readonly exportedAt: string;
	readonly workspaceHint?: string;
	readonly title?: string;
	readonly history: readonly ConversationMessage[];
}

export interface SessionStoreOptions {
	/** Returns a stable per-workspace key suffix, e.g. the workspace folder URI. */
	getWorkspaceId(): string;
	/** Optional override for the timestamp used in exports/metadata. Tests pass a fixed value. */
	now?: () => Date;
	/** Optional id factory; tests override for determinism. */
	makeId?: () => string;
	// R5-C: invoked after every successful `save(sessionId, history)`. Used by
	// the host to feed the conversation search index incrementally without
	// SessionStore needing to know anything about embeddings. Errors thrown by
	// the hook are caught and swallowed — persistence must never be blocked
	// by an indexing failure.
	readonly onSaved?: (sessionId: string, history: readonly ConversationMessage[]) => void;
}

/**
 * Multi-session conversation store.
 *
 * Storage layout (per workspace):
 *   index: `oati.session-index.v2.<workspaceId>`   → SessionIndex (small)
 *   data:  `oati.session-data.v2.<workspaceId>.<sessionId>` → ConversationMessage[]
 *
 * On first access we migrate any legacy `oati.session.v1.<workspaceId>` entry
 * into a single "Legacy session" so existing users don't lose their history.
 */
export class SessionStore {
	private migrated = false;
	// R7-C bug fix: serialize all index-touching operations behind a single
	// promise chain so two concurrent saves (or save+rename, save+delete, etc.)
	// can't race on read-modify-write of the index. Without this, the
	// `readIndex() → writeIndex()` pattern in `save`/`rename`/`clearOne`/`delete`
	// silently dropped one of the updates whenever a second mutation landed
	// between the read and the write of the first.
	private indexLock: Promise<unknown> = Promise.resolve();

	constructor(
		private readonly kv: KvStorage,
		private readonly opts: SessionStoreOptions,
	) {}

	// R7-C: critical-section helper. All public methods that read-modify-write
	// the session index funnel through `withIndexLock` so updates are strictly
	// serialized per SessionStore instance. Errors do not poison the chain —
	// the next caller gets a fresh `Promise.resolve()` start point.
	private withIndexLock<T>(fn: () => Promise<T>): Promise<T> {
		const next = this.indexLock.then(fn, fn);
		// Swallow rejection on the chained promise so a thrown error doesn't
		// permanently break the lock for subsequent callers.
		this.indexLock = next.catch(() => undefined);
		return next;
	}

	private indexKey(): string {
		return INDEX_KEY_PREFIX + this.opts.getWorkspaceId();
	}

	private dataKey(sessionId: string): string {
		return `${DATA_KEY_PREFIX}${this.opts.getWorkspaceId()}.${sessionId}`;
	}

	// 2026-05-27: per-session workspace-root key. Stores the resolved path
	// the user / agent picked via `set_workspace_root` so reload restores
	// it instead of falling back to the IDE's first folder.
	private workspaceRootKey(sessionId: string): string {
		return `${DATA_KEY_PREFIX}${this.opts.getWorkspaceId()}.${sessionId}.workspaceRoot`;
	}

	/** Read the persisted workspace-root override for this session, if any. */
	async getWorkspaceRoot(sessionId: string): Promise<string | undefined> {
		const v = this.kv.get<string>(this.workspaceRootKey(sessionId));
		return typeof v === "string" && v.length > 0 ? v : undefined;
	}

	/** Persist the workspace-root override for this session. */
	async setWorkspaceRoot(sessionId: string, root: string | undefined): Promise<void> {
		await this.kv.update(
			this.workspaceRootKey(sessionId),
			root && root.length > 0 ? root : undefined,
		);
	}

	private legacyKey(): string {
		return LEGACY_KEY_PREFIX + this.opts.getWorkspaceId();
	}

	private now(): Date {
		return (this.opts.now ?? (() => new Date()))();
	}

	private nowIso(): string {
		return this.now().toISOString();
	}

	private newId(): string {
		if (this.opts.makeId) return this.opts.makeId();
		const ts = Date.now().toString(36);
		const rnd = Math.random().toString(36).slice(2, 8);
		return `s_${ts}_${rnd}`;
	}

	private async readIndex(): Promise<SessionIndex> {
		await this.maybeMigrate();
		const stored = this.kv.get<SessionIndex>(this.indexKey());
		if (stored && Array.isArray(stored.sessions)) return stored;
		return { version: 2, sessions: [] };
	}

	private async writeIndex(idx: SessionIndex): Promise<void> {
		await this.kv.update(this.indexKey(), idx);
	}

	private async maybeMigrate(): Promise<void> {
		if (this.migrated) return;
		this.migrated = true;
		const existingIndex = this.kv.get<SessionIndex>(this.indexKey());
		if (existingIndex) return;

		const legacy = this.kv.get<readonly ConversationMessage[]>(this.legacyKey());
		if (legacy && Array.isArray(legacy) && legacy.length > 0) {
			const id = this.newId();
			const ts = this.nowIso();
			const firstUser = legacy.find((m) => m.role === "user");
			const firstUserText = firstUser ? extractTextFromMessage(firstUser) : undefined;
			const meta: SessionMeta = {
				id,
				title: firstUserText ? deriveSessionTitle(firstUserText) : "Legacy session",
				createdAt: ts,
				lastUpdatedAt: ts,
				messageCount: legacy.length,
			};
			await this.kv.update(this.dataKey(id), legacy);
			await this.writeIndex({ version: 2, sessions: [meta] });
			await this.kv.update(this.legacyKey(), undefined);
		}
	}

	async list(): Promise<readonly SessionMeta[]> {
		const idx = await this.readIndex();
		return idx.sessions;
	}

	async getCurrentOrCreate(): Promise<SessionMeta> {
		const idx = await this.readIndex();
		if (idx.sessions.length > 0) return idx.sessions[0];
		return this.create();
	}

	async create(initialTitle = "New Session"): Promise<SessionMeta> {
		return this.withIndexLock(async () => {
			const idx = await this.readIndex();
			const ts = this.nowIso();
			const meta: SessionMeta = {
				id: this.newId(),
				title: initialTitle,
				createdAt: ts,
				lastUpdatedAt: ts,
				messageCount: 0,
			};
			await this.writeIndex({
				version: 2,
				sessions: [meta, ...idx.sessions],
			});
			return meta;
		});
	}

	async load(sessionId: string): Promise<ConversationMessage[]> {
		await this.maybeMigrate();
		const stored = this.kv.get<readonly ConversationMessage[]>(this.dataKey(sessionId));
		if (!stored || !Array.isArray(stored)) return [];
		return [...stored];
	}

	async save(sessionId: string, history: readonly ConversationMessage[]): Promise<void> {
		return this.withIndexLock(() => this.saveLocked(sessionId, history));
	}

	private async saveLocked(
		sessionId: string,
		history: readonly ConversationMessage[],
	): Promise<void> {
		const serialized = JSON.stringify(history);
		const trimmed =
			serialized.length > MAX_HISTORY_BYTES ? trimHistory(history, MAX_HISTORY_BYTES) : history;
		await this.kv.update(this.dataKey(sessionId), trimmed);

		const idx = await this.readIndex();
		const existing = idx.sessions.find((s) => s.id === sessionId);
		const firstUser = trimmed.find((m) => m.role === "user");
		const firstUserText = firstUser ? extractTextFromMessage(firstUser) : undefined;
		const derivedTitle =
			existing &&
			existing.title !== "New Session" &&
			existing.title !== "New chat" &&
			existing.title !== "Legacy session"
				? existing.title
				: deriveSessionTitle(firstUserText);
		const updatedMeta: SessionMeta = {
			id: sessionId,
			title: derivedTitle,
			createdAt: existing?.createdAt ?? this.nowIso(),
			lastUpdatedAt: this.nowIso(),
			messageCount: trimmed.length,
			// R3-D: preserve fork linkage across saves so the UI can keep showing
			// "Forked from X at message Y" after subsequent turns.
			...(existing?.parentSessionId ? { parentSessionId: existing.parentSessionId } : {}),
			...(existing?.forkedAtMessageId ? { forkedAtMessageId: existing.forkedAtMessageId } : {}),
			// R5-D: persist active persona id across saves so the addendum is
			// re-applied automatically on the next runUserTurn after reload.
			...(existing?.personaId ? { personaId: existing.personaId } : {}),
		};
		const others = idx.sessions.filter((s) => s.id !== sessionId);
		await this.writeIndex({
			version: 2,
			sessions: [updatedMeta, ...others],
		});
		// R5-C: fire the observer hook after the canonical write has
		// completed, so a downstream indexer never sees a state more recent
		// than what's on disk. Errors are isolated — indexing must not break
		// chat persistence.
		if (this.opts.onSaved) {
			try {
				this.opts.onSaved(sessionId, trimmed);
			} catch {
				/* best-effort; indexing failures don't break save */
			}
		}
	}

	async clearOne(sessionId: string): Promise<void> {
		return this.withIndexLock(async () => {
			await this.kv.update(this.dataKey(sessionId), undefined);
			const idx = await this.readIndex();
			const existing = idx.sessions.find((s) => s.id === sessionId);
			if (!existing) return;
			const others = idx.sessions.filter((s) => s.id !== sessionId);
			const reset: SessionMeta = {
				...existing,
				title: "New Session",
				lastUpdatedAt: this.nowIso(),
				messageCount: 0,
			};
			await this.writeIndex({
				version: 2,
				sessions: [reset, ...others],
			});
		});
	}

	async delete(sessionId: string): Promise<void> {
		return this.withIndexLock(async () => {
			await this.kv.update(this.dataKey(sessionId), undefined);
			const idx = await this.readIndex();
			await this.writeIndex({
				version: 2,
				sessions: idx.sessions.filter((s) => s.id !== sessionId),
			});
		});
	}

	async rename(sessionId: string, title: string): Promise<void> {
		return this.withIndexLock(async () => {
			const idx = await this.readIndex();
			const existing = idx.sessions.find((s) => s.id === sessionId);
			if (!existing) return;
			const others = idx.sessions.filter((s) => s.id !== sessionId);
			const trimmedTitle = title.trim().slice(0, 100);
			const renamed: SessionMeta = {
				...existing,
				title: trimmedTitle.length === 0 ? existing.title : trimmedTitle,
				lastUpdatedAt: this.nowIso(),
			};
			await this.writeIndex({
				version: 2,
				sessions: [renamed, ...others],
			});
		});
	}

	serializeExport(
		_sessionId: string,
		history: readonly ConversationMessage[],
		title?: string,
	): string {
		const exp: SessionExport = {
			version: EXPORT_VERSION,
			exportedAt: this.nowIso(),
			workspaceHint: this.opts.getWorkspaceId(),
			title,
			history,
		};
		return JSON.stringify(exp, null, 2);
	}

	parseImport(text: string): { title?: string; history: ConversationMessage[] } {
		const parsed = JSON.parse(text) as SessionExport;
		if (
			typeof parsed !== "object" ||
			parsed === null ||
			typeof parsed.version !== "number" ||
			!Array.isArray(parsed.history)
		) {
			throw new Error("Invalid session file format");
		}
		if (parsed.version !== EXPORT_VERSION) {
			throw new Error(`Unsupported session version: ${parsed.version} (expected ${EXPORT_VERSION})`);
		}
		return { title: parsed.title, history: [...parsed.history] };
	}

	/** Create a fresh session and seed it with imported history in one step. */
	async saveImported(history: readonly ConversationMessage[], title?: string): Promise<SessionMeta> {
		const initialTitle =
			title ?? deriveSessionTitle(extractTextFromMessage(history.find((m) => m.role === "user")));
		const meta = await this.create(initialTitle);
		await this.save(meta.id, history);
		const after = await this.readIndex();
		return after.sessions.find((s) => s.id === meta.id) ?? meta;
	}

	// R3-D: conversation branching — create a new session whose metadata
	// records the parent session id and the UiMessage id the fork was taken
	// at. Caller is responsible for seeding the new session's history (see
	// `conversation-branching.ts`). Returns the canonical meta after a write.
	async createFork(args: {
		readonly parentSessionId: string;
		readonly forkedAtMessageId: string;
		readonly title?: string;
	}): Promise<SessionMeta> {
		return this.withIndexLock(async () => {
			const idx = await this.readIndex();
			const ts = this.nowIso();
			const meta: SessionMeta = {
				id: this.newId(),
				title: args.title?.trim().length ? args.title.trim().slice(0, 100) : "Forked chat",
				createdAt: ts,
				lastUpdatedAt: ts,
				messageCount: 0,
				parentSessionId: args.parentSessionId,
				forkedAtMessageId: args.forkedAtMessageId,
			};
			await this.writeIndex({
				version: 2,
				sessions: [meta, ...idx.sessions],
			});
			return meta;
		});
	}

	// R3-D: pinned-message persistence. Stored on a separate kv key so we
	// don't bloat the per-session history blob and so the set survives
	// `clearOne` (which wipes history but keeps the session row).
	private pinKey(sessionId: string): string {
		return `oati.session-pins.v1.${this.opts.getWorkspaceId()}.${sessionId}`;
	}

	async loadPinned(sessionId: string): Promise<readonly string[]> {
		const stored = this.kv.get<readonly string[]>(this.pinKey(sessionId));
		return Array.isArray(stored) ? [...stored] : [];
	}

	async setPinned(sessionId: string, messageId: string, pinned: boolean): Promise<void> {
		// R7-C bug fix: concurrent pin/unpin calls on the same session would
		// race on the read-modify-write of the pin set. Funnel through the same
		// lock as the index so the set is consistent.
		return this.withIndexLock(async () => {
			const current = await this.loadPinned(sessionId);
			const set = new Set(current);
			if (pinned) set.add(messageId);
			else set.delete(messageId);
			await this.kv.update(this.pinKey(sessionId), [...set]);
		});
	}

	// R5-D: persona switching. Stored directly on the SessionMeta row so it
	// rides along with the index payload (small, no extra kv round-trip). Pass
	// `null` (or an empty string) to clear the active persona.
	async setPersona(sessionId: string, personaId: string | null): Promise<SessionMeta | undefined> {
		return this.withIndexLock(async () => {
			const idx = await this.readIndex();
			const existing = idx.sessions.find((s) => s.id === sessionId);
			if (!existing) return undefined;
			const others = idx.sessions.filter((s) => s.id !== sessionId);
			const normalized = personaId && personaId.trim().length > 0 ? personaId.trim() : undefined;
			const updated: SessionMeta = {
				id: existing.id,
				title: existing.title,
				createdAt: existing.createdAt,
				lastUpdatedAt: this.nowIso(),
				messageCount: existing.messageCount,
				...(existing.parentSessionId ? { parentSessionId: existing.parentSessionId } : {}),
				...(existing.forkedAtMessageId ? { forkedAtMessageId: existing.forkedAtMessageId } : {}),
				...(normalized ? { personaId: normalized } : {}),
			};
			await this.writeIndex({
				version: 2,
				sessions: [updated, ...others],
			});
			return updated;
		});
	}

	// R5-D: read-only convenience used by ChatPanel.runUserTurn to look up the
	// active persona without paying for a full list().
	async getPersona(sessionId: string): Promise<string | undefined> {
		const idx = await this.readIndex();
		return idx.sessions.find((s) => s.id === sessionId)?.personaId;
	}
}

function trimHistory(
	history: readonly ConversationMessage[],
	maxBytes: number,
): ConversationMessage[] {
	let kept = [...history];
	while (JSON.stringify(kept).length > maxBytes && kept.length > 2) {
		kept = kept.slice(2);
	}
	return kept;
}

function extractTextFromMessage(msg: ConversationMessage | undefined): string | undefined {
	if (!msg) return undefined;
	for (const p of msg.parts) {
		if (p.kind === "text" && p.text.trim().length > 0) return p.text;
	}
	return undefined;
}
