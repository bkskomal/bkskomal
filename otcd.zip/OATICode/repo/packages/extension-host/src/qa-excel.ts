// 2026-05-28: QA-testing Excel I/O. Drives the new test-plan flow:
//
//   /qa discover  → produces a project understanding map
//   /qa plan      → writes TEST_PLAN_*.xlsx (this module's main job)
//   /qa execute   → reads the same xlsx, runs cases, writes Status/Actual
//   /qa report    → reads the executed xlsx → Word summary
//
// Two big design choices baked in here:
//
// 1. **Template-first.** Real QA teams have their own xlsx templates with
//    custom column names ("Test Steps" vs "Steps to Execute") and styled
//    header rows. We scan the workspace for known template paths and use
//    fuzzy header matching to map our concept of "TC-ID / Module / Steps"
//    onto whatever the team calls them. No template found → fall back to
//    a sensible default schema.
//
// 2. **Round-trip safe.** /qa execute opens the user's file, updates
//    Status + Actual + Date columns, and saves back — preserving every
//    column the user added (defect link, severity, owner, …). exceljs
//    keeps formatting + formulas across the read-then-write.

import * as path from "node:path";
import ExcelJS from "exceljs";

/** Logical column concepts we know about. Templates may name them differently. */
export type FunctionalConcept =
	| "tcId"
	| "module"
	| "feature"
	| "title"
	| "preconditions"
	| "steps"
	| "expected"
	| "priority"
	| "type"
	| "status"
	| "actual"
	| "tester"
	| "date";

export type UnitConcept =
	| "tcId"
	| "file"
	| "function"
	| "title"
	| "preconditions"
	| "testData"
	| "expected"
	| "status"
	| "actual"
	| "notes";

export type Concept = FunctionalConcept | UnitConcept;

export type PlanKind = "functional" | "unit";

/**
 * Resolved column schema. `headerByConcept` is the actual header string
 * (as it appears in the xlsx) that the concept maps to. `columnByConcept`
 * is the 1-based column index. When a template is read, both come from
 * the template; when we generate fresh, both come from DEFAULTS.
 */
export interface ResolvedSchema {
	readonly headerRowIndex: number; // 1-based row containing the headers
	readonly headerByConcept: Readonly<Record<Concept, string>>;
	readonly columnByConcept: Readonly<Record<Concept, number>>;
	/** All headers in order — preserves user-added columns we don't know about. */
	readonly allHeaders: readonly string[];
}

/** Default column lists when no template is found in the workspace. */
const DEFAULT_FUNCTIONAL_HEADERS: readonly { concept: FunctionalConcept; header: string }[] = [
	{ concept: "tcId", header: "TC-ID" },
	{ concept: "module", header: "Module" },
	{ concept: "feature", header: "Feature" },
	{ concept: "title", header: "Title" },
	{ concept: "preconditions", header: "Preconditions" },
	{ concept: "steps", header: "Steps" },
	{ concept: "expected", header: "Expected Result" },
	{ concept: "priority", header: "Priority" },
	{ concept: "type", header: "Type" },
	{ concept: "status", header: "Status" },
	{ concept: "actual", header: "Actual Result" },
	{ concept: "tester", header: "Tester" },
	{ concept: "date", header: "Date" },
];

const DEFAULT_UNIT_HEADERS: readonly { concept: UnitConcept; header: string }[] = [
	{ concept: "tcId", header: "TC-ID" },
	{ concept: "file", header: "File" },
	{ concept: "function", header: "Function" },
	{ concept: "title", header: "Test Case" },
	{ concept: "preconditions", header: "Preconditions" },
	{ concept: "testData", header: "Test Data" },
	{ concept: "expected", header: "Expected" },
	{ concept: "status", header: "Status" },
	{ concept: "actual", header: "Actual" },
	{ concept: "notes", header: "Notes" },
];

/**
 * Fuzzy header → concept dictionary. Lowercase + stripped of non-alphanumerics
 * before comparison. Order matters: the first matching synonym wins, so put
 * the most specific synonyms first.
 */
const FUNCTIONAL_SYNONYMS: Readonly<Record<FunctionalConcept, readonly string[]>> = {
	tcId: ["tcid", "testcaseid", "tc#", "id", "testid"],
	module: ["module", "component", "area", "feature_area"],
	feature: ["feature", "submodule", "function_area"],
	title: ["title", "testcasename", "testname", "scenario", "name", "summary"],
	preconditions: ["preconditions", "prerequisite", "prerequisites", "precondition", "setup"],
	steps: ["steps", "teststeps", "stepstoexecute", "procedure", "actions", "execution"],
	expected: [
		"expectedresult",
		"expected",
		"expectedoutcome",
		"expectation",
		"expectedbehaviour",
		"expectedbehavior",
	],
	priority: ["priority", "severity", "criticality"],
	type: ["type", "testtype", "category", "kind"],
	status: ["status", "result", "passfail", "outcome"],
	actual: ["actualresult", "actual", "actualoutcome"],
	tester: ["tester", "executedby", "assignee", "owner", "runby"],
	date: ["date", "executiondate", "rundate", "executedon"],
};

const UNIT_SYNONYMS: Readonly<Record<UnitConcept, readonly string[]>> = {
	tcId: ["tcid", "testcaseid", "tc#", "id"],
	file: ["file", "filename", "filepath", "source"],
	function: ["function", "method", "symbol", "unit"],
	title: ["title", "testcasename", "testname", "scenario", "name", "summary", "testcase"],
	preconditions: ["preconditions", "prerequisite", "prerequisites", "setup"],
	testData: ["testdata", "inputs", "input", "parameters", "args"],
	expected: ["expected", "expectedresult", "expectedoutput", "expectedreturn"],
	status: ["status", "result", "passfail", "outcome"],
	actual: ["actual", "actualresult", "actualoutput"],
	notes: ["notes", "remarks", "comments"],
};

function normalizeHeader(s: string): string {
	return s.toLowerCase().replace(/[^a-z0-9]/g, "");
}

/**
 * Try to map a header string onto a known concept. Returns undefined if no
 * synonym matches — user-added columns we don't know about are preserved
 * but treated as opaque.
 */
function matchConcept<C extends string>(
	header: string,
	synonyms: Readonly<Record<C, readonly string[]>>,
): C | undefined {
	const norm = normalizeHeader(header);
	for (const concept of Object.keys(synonyms) as C[]) {
		for (const syn of synonyms[concept]) {
			if (norm === syn || (norm.length >= 3 && norm.includes(syn))) return concept;
		}
	}
	return undefined;
}

/**
 * Workspace-relative paths we'll look for as the source template. First
 * existing one wins. Lowercase comparisons throughout for case-insensitive
 * filesystems.
 */
const TEMPLATE_CANDIDATES_FUNCTIONAL = [
	"templates/qa-functional-template.xlsx",
	".qa/qa-functional-template.xlsx",
	".qa/functional-template.xlsx",
	"qa-functional-template.xlsx",
];
const TEMPLATE_CANDIDATES_UNIT = [
	"templates/qa-unit-template.xlsx",
	".qa/qa-unit-template.xlsx",
	".qa/unit-template.xlsx",
	"qa-unit-template.xlsx",
];

export function templateCandidatesFor(kind: PlanKind): readonly string[] {
	return kind === "functional" ? TEMPLATE_CANDIDATES_FUNCTIONAL : TEMPLATE_CANDIDATES_UNIT;
}

/**
 * Inspect an exceljs Worksheet for the first row that "looks like" a header
 * row — i.e. mostly non-empty string cells. Real-world templates often have
 * a title banner at row 1 or 2 before the actual headers start.
 *
 * Returns the 1-based row index or undefined if none found in the first 10 rows.
 */
function findHeaderRow(ws: ExcelJS.Worksheet): number | undefined {
	for (let r = 1; r <= Math.min(10, ws.rowCount || 10); r++) {
		const row = ws.getRow(r);
		let stringCells = 0;
		let totalCells = 0;
		row.eachCell({ includeEmpty: false }, (cell) => {
			totalCells++;
			if (typeof cell.value === "string" && cell.value.trim().length > 0) stringCells++;
		});
		// Heuristic: header row has ≥ 3 non-empty string cells AND no formulas.
		if (totalCells >= 3 && stringCells === totalCells && stringCells >= 3) {
			return r;
		}
	}
	return undefined;
}

/**
 * Read an existing template xlsx and resolve its column schema. Returns
 * `undefined` if the file can't be parsed or doesn't have a recognizable
 * header row — the caller falls back to the default schema in that case.
 */
export async function readTemplateSchema(
	absolutePath: string,
	kind: PlanKind,
): Promise<ResolvedSchema | undefined> {
	try {
		const wb = new ExcelJS.Workbook();
		await wb.xlsx.readFile(absolutePath);
		// Use the first worksheet that has any data.
		const ws = wb.worksheets.find((w) => (w.rowCount ?? 0) > 0);
		if (!ws) return undefined;
		const headerRowIndex = findHeaderRow(ws);
		if (headerRowIndex === undefined) return undefined;

		const headerRow = ws.getRow(headerRowIndex);
		const synonyms = kind === "functional" ? FUNCTIONAL_SYNONYMS : UNIT_SYNONYMS;

		const allHeaders: string[] = [];
		const headerByConcept: Partial<Record<Concept, string>> = {};
		const columnByConcept: Partial<Record<Concept, number>> = {};
		headerRow.eachCell({ includeEmpty: false }, (cell, colIdx) => {
			const text = typeof cell.value === "string" ? cell.value : String(cell.value ?? "");
			allHeaders.push(text);
			const concept = matchConcept(text, synonyms as Readonly<Record<string, readonly string[]>>);
			if (concept && !(concept in columnByConcept)) {
				headerByConcept[concept as Concept] = text;
				columnByConcept[concept as Concept] = colIdx;
			}
		});

		return {
			headerRowIndex,
			headerByConcept: headerByConcept as Readonly<Record<Concept, string>>,
			columnByConcept: columnByConcept as Readonly<Record<Concept, number>>,
			allHeaders,
		};
	} catch {
		return undefined;
	}
}

/** Build the default schema when no template is found. */
export function defaultSchema(kind: PlanKind): ResolvedSchema {
	const defs = kind === "functional" ? DEFAULT_FUNCTIONAL_HEADERS : DEFAULT_UNIT_HEADERS;
	const headerByConcept: Partial<Record<Concept, string>> = {};
	const columnByConcept: Partial<Record<Concept, number>> = {};
	const allHeaders: string[] = [];
	defs.forEach((d, i) => {
		headerByConcept[d.concept] = d.header;
		columnByConcept[d.concept] = i + 1;
		allHeaders.push(d.header);
	});
	return {
		headerRowIndex: 1,
		headerByConcept: headerByConcept as Readonly<Record<Concept, string>>,
		columnByConcept: columnByConcept as Readonly<Record<Concept, number>>,
		allHeaders,
	};
}

/**
 * Resolve which schema to use for a /qa plan run. Tries the known template
 * paths in order; first existing + parseable wins. Falls back to default.
 */
export async function resolveSchema(opts: {
	readonly workspaceRoot: string;
	readonly kind: PlanKind;
	readonly fileExists: (absPath: string) => Promise<boolean>;
}): Promise<{ schema: ResolvedSchema; templatePath?: string }> {
	for (const rel of templateCandidatesFor(opts.kind)) {
		const abs = path.join(opts.workspaceRoot, rel);
		if (await opts.fileExists(abs)) {
			const schema = await readTemplateSchema(abs, opts.kind);
			if (schema) return { schema, templatePath: rel };
		}
	}
	return { schema: defaultSchema(opts.kind) };
}

// ---------------------------------------------------------------------------
// Writing
// ---------------------------------------------------------------------------

export interface FunctionalTestCase {
	readonly tcId: string;
	readonly module: string;
	readonly feature: string;
	readonly title: string;
	readonly preconditions: string;
	readonly steps: string;
	readonly expected: string;
	readonly priority: "Critical" | "High" | "Medium" | "Low";
	readonly type: "Smoke" | "Functional" | "Regression" | "Integration" | "Edge";
}

export interface UnitTestCase {
	readonly tcId: string;
	readonly file: string;
	readonly function: string;
	readonly title: string;
	readonly preconditions: string;
	readonly testData: string;
	readonly expected: string;
	readonly notes?: string;
}

export type TestCase = FunctionalTestCase | UnitTestCase;

/**
 * Write a plan workbook to disk. If `templatePath` is provided (resolved
 * earlier by resolveSchema), the template is loaded as the base so styling
 * + frozen rows + validation lists are preserved; otherwise a fresh
 * workbook is created with the default schema's headers.
 *
 * Status / Actual / Tester / Date columns are intentionally left empty —
 * those are populated by /qa execute on a later run.
 */
export async function writePlanWorkbook(opts: {
	readonly absPath: string;
	readonly kind: PlanKind;
	readonly schema: ResolvedSchema;
	readonly templatePath?: string;
	readonly workspaceRoot: string;
	readonly cases: readonly TestCase[];
	readonly projectName: string;
	readonly generatedAt: Date;
}): Promise<void> {
	const wb = new ExcelJS.Workbook();
	if (opts.templatePath) {
		await wb.xlsx.readFile(path.join(opts.workspaceRoot, opts.templatePath));
	}

	// Pick / create the target sheet.
	let ws: ExcelJS.Worksheet;
	if (opts.templatePath) {
		const found = wb.worksheets.find((w) => (w.rowCount ?? 0) > 0);
		if (!found) {
			throw new Error("template workbook has no non-empty worksheets");
		}
		ws = found;
		// When using a template, drop any sample rows BELOW the header row so
		// we start with a clean slate for our generated cases.
		while (ws.rowCount > opts.schema.headerRowIndex) {
			ws.spliceRows(opts.schema.headerRowIndex + 1, 1);
		}
	} else {
		ws = wb.addWorksheet(opts.kind === "functional" ? "Functional Tests" : "Unit Tests");
		const headerRow = ws.addRow(opts.schema.allHeaders);
		headerRow.font = { bold: true };
		headerRow.fill = {
			type: "pattern",
			pattern: "solid",
			fgColor: { argb: "FF1A2B4A" },
		};
		headerRow.alignment = { vertical: "middle", horizontal: "left" };
		headerRow.eachCell((cell) => {
			cell.font = { ...cell.font, bold: true, color: { argb: "FFFFFFFF" } };
		});
		// Reasonable initial column widths.
		ws.columns = opts.schema.allHeaders.map((h) => ({
			header: h,
			width: estimateColumnWidth(h),
		}));
		ws.views = [{ state: "frozen", ySplit: 1 }];
	}

	for (const tc of opts.cases) {
		const row = new Array(opts.schema.allHeaders.length).fill("");
		for (const [conceptKey, colIdx] of Object.entries(opts.schema.columnByConcept)) {
			const value = (tc as unknown as Record<string, unknown>)[conceptKey];
			if (value !== undefined && colIdx !== undefined) {
				row[colIdx - 1] = String(value);
			}
		}
		ws.addRow(row);
	}

	// Metadata so /qa execute and /qa report can identify our files.
	wb.creator = "OATI Code";
	wb.lastModifiedBy = "OATI Code";
	wb.created = opts.generatedAt;
	wb.modified = opts.generatedAt;
	wb.title = `${opts.projectName} — ${opts.kind === "functional" ? "Functional" : "Unit"} Test Plan`;

	await wb.xlsx.writeFile(opts.absPath);
}

function estimateColumnWidth(header: string): number {
	const lower = header.toLowerCase();
	if (lower.includes("step") || lower.includes("expected") || lower.includes("precondition")) {
		return 50;
	}
	if (lower.includes("title") || lower.includes("test case") || lower.includes("notes")) {
		return 35;
	}
	if (lower.includes("id")) return 10;
	return 18;
}
