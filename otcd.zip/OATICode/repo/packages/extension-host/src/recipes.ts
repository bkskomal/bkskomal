// R5-D: Recipes — saved multi-step workflows that drive the agent through a
// sequence of separate user turns. Stored as YAML-front-matter markdown under
// <workspace>/.oati/recipes/<name>.md so they're versionable + human-editable.
//
// Schema:
//
//   ---
//   name: ship-feature
//   description: Implement, test, commit, open PR
//   steps:
//     - "Generate implementation"
//     - "Run tests with /run_tests"
//     - "If green, /git_commit then /git_open_pr"
//   ---
//   <free-form additional context>
//
// `runRecipe` sequences the steps as N back-to-back conductor spawns, feeding
// the prior step's full conversation history into the next so the agent has
// continuity. Each step is dispatched as a normal user turn so existing
// instrumentation (audit log, perf collector, secret scanner) keeps working.

import { promises as fs } from "node:fs";
import * as path from "node:path";
import type { Conductor } from "@oati/agent-core";
import type { ConversationMessage, HostContext, ModeConfig } from "@oati/shared";

/** Slug shape — same convention as snippets and custom slash commands. */
const VALID_NAME = /^[a-zA-Z0-9_-]+$/;

export interface RecipeSummary {
	readonly name: string;
	readonly description: string;
}

export interface Recipe {
	readonly name: string;
	readonly description: string;
	readonly steps: readonly string[];
	/** Anything below the front-matter — surfaced to the model on every step. */
	readonly context: string;
}

export const RECIPES_RELATIVE_DIR = ".oati/recipes";

function recipesDir(workspaceRoot: string): string {
	return path.join(workspaceRoot, RECIPES_RELATIVE_DIR);
}

function recipeFile(workspaceRoot: string, name: string): string {
	return path.join(recipesDir(workspaceRoot), `${name}.md`);
}

function isValidName(name: string): boolean {
	return VALID_NAME.test(name);
}

/**
 * Enumerate every recipe under `<workspaceRoot>/.oati/recipes/*.md`. Missing
 * directory returns `[]`; unreadable or schema-invalid files are skipped
 * silently so a single broken recipe can't take down the whole picker.
 */
export async function listRecipes(workspaceRoot: string): Promise<RecipeSummary[]> {
	if (!workspaceRoot) return [];
	const dir = recipesDir(workspaceRoot);
	let entries: string[];
	try {
		entries = await fs.readdir(dir);
	} catch {
		return [];
	}
	const out: RecipeSummary[] = [];
	for (const entry of entries) {
		if (!entry.toLowerCase().endsWith(".md")) continue;
		const name = entry.slice(0, -3);
		if (!isValidName(name)) continue;
		const abs = path.join(dir, entry);
		let raw: string;
		try {
			const stat = await fs.stat(abs);
			if (!stat.isFile()) continue;
			raw = await fs.readFile(abs, "utf-8");
		} catch {
			continue;
		}
		const parsed = parseRecipe(name, raw);
		if (!parsed) continue;
		out.push({ name: parsed.name, description: parsed.description });
	}
	out.sort((a, b) => a.name.localeCompare(b.name));
	return out;
}

/**
 * Load a single recipe by name. Returns `null` when the file is missing or the
 * front-matter doesn't parse — callers surface a friendly "Unknown recipe"
 * message in either case.
 */
export async function readRecipe(workspaceRoot: string, name: string): Promise<Recipe | null> {
	if (!workspaceRoot || !isValidName(name)) return null;
	const abs = recipeFile(workspaceRoot, name);
	let raw: string;
	try {
		raw = await fs.readFile(abs, "utf-8");
	} catch (err) {
		if ((err as NodeJS.ErrnoException).code === "ENOENT") return null;
		throw err;
	}
	return parseRecipe(name, raw);
}

/**
 * Serialize a recipe to disk. Always writes a normalized front-matter block
 * so round-tripping is stable. Overwrites by name.
 */
export async function saveRecipe(workspaceRoot: string, recipe: Recipe): Promise<void> {
	if (!workspaceRoot) throw new Error("saveRecipe: workspaceRoot is required");
	if (!isValidName(recipe.name)) {
		throw new Error(
			`saveRecipe: invalid recipe name '${recipe.name}'. Use letters, digits, underscore, or dash.`,
		);
	}
	if (recipe.steps.length === 0) {
		throw new Error("saveRecipe: a recipe must have at least one step");
	}
	const dir = recipesDir(workspaceRoot);
	await fs.mkdir(dir, { recursive: true });
	const front = serializeFrontMatter(recipe);
	const context = recipe.context.length > 0 ? `\n${recipe.context.replace(/\s+$/, "")}\n` : "";
	const doc = `---\n${front}---\n${context}`;
	await fs.writeFile(recipeFile(workspaceRoot, recipe.name), doc, "utf-8");
}

/** Delete a recipe. Silently no-ops when the file is missing. */
export async function deleteRecipe(workspaceRoot: string, name: string): Promise<void> {
	if (!workspaceRoot || !isValidName(name)) return;
	try {
		await fs.unlink(recipeFile(workspaceRoot, name));
	} catch (err) {
		if ((err as NodeJS.ErrnoException).code === "ENOENT") return;
		throw err;
	}
}

export interface RunRecipeOptions {
	readonly conductor: Conductor;
	readonly host: HostContext;
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly providerId: string;
	/** Existing chat history to seed the first step's conversation. */
	readonly history?: readonly ConversationMessage[];
	readonly signal?: AbortSignal;
	/** Fired before each step's agent spawn so callers can surface progress. */
	readonly onStepStarted?: (step: { index: number; total: number; text: string }) => void;
	/** Fired after each step completes (success OR failure). */
	readonly onStepDone?: (step: {
		index: number;
		total: number;
		ok: boolean;
		message?: string;
	}) => void;
	readonly log?: { appendLine(msg: string): void };
}

export interface RunRecipeResult {
	readonly status: "ok" | "cancelled" | "error";
	readonly history: readonly ConversationMessage[];
	readonly completedSteps: number;
	readonly message?: string;
}

/**
 * Sequence the recipe's steps as N independent agent turns. The conversation
 * history accumulates across steps so the agent sees its own prior work; the
 * recipe's free-form `context` block is also prepended to every step prompt so
 * shared instructions don't have to be repeated.
 */
export async function runRecipe(name: string, deps: RunRecipeOptions): Promise<RunRecipeResult> {
	const log = (msg: string) => deps.log?.appendLine(`[recipes] ${msg}`);
	const root = deps.host.workspaceRoot();
	if (!root) {
		return {
			status: "error",
			history: deps.history ?? [],
			completedSteps: 0,
			message: "runRecipe: no workspace folder open.",
		};
	}
	const recipe = await readRecipe(root, name);
	if (!recipe) {
		return {
			status: "error",
			history: deps.history ?? [],
			completedSteps: 0,
			message: `Unknown recipe: ${name}`,
		};
	}
	let history: readonly ConversationMessage[] = deps.history ?? [];
	let completed = 0;
	for (let i = 0; i < recipe.steps.length; i++) {
		if (deps.signal?.aborted) {
			return {
				status: "cancelled",
				history,
				completedSteps: completed,
				message: "Cancelled before next step.",
			};
		}
		const stepText = recipe.steps[i].trim();
		if (stepText.length === 0) continue;
		const prompt = renderStepPrompt(recipe, i, stepText);
		deps.onStepStarted?.({ index: i, total: recipe.steps.length, text: stepText });
		log(`step ${i + 1}/${recipe.steps.length} → ${truncate(stepText, 80)}`);
		try {
			const updated = await deps.conductor.spawn({
				mode: { ...deps.mode, providerId: deps.providerId },
				modelId: deps.modelId,
				userMessage: prompt,
				history,
				...(deps.signal ? { signal: deps.signal } : {}),
			});
			history = [...updated];
			completed++;
			deps.onStepDone?.({ index: i, total: recipe.steps.length, ok: true });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			log(`step ${i + 1} failed: ${message}`);
			deps.onStepDone?.({
				index: i,
				total: recipe.steps.length,
				ok: false,
				message,
			});
			return {
				status: deps.signal?.aborted ? "cancelled" : "error",
				history,
				completedSteps: completed,
				message,
			};
		}
	}
	return { status: "ok", history, completedSteps: completed };
}

/** Build the per-step prompt — recipe context + step number + step text. */
function renderStepPrompt(recipe: Recipe, index: number, stepText: string): string {
	const header = `## Recipe '${recipe.name}' — step ${index + 1} of ${recipe.steps.length}`;
	const body =
		recipe.context.trim().length > 0
			? `${header}\n\n${recipe.context.trim()}\n\n---\n\n${stepText}`
			: `${header}\n\n${stepText}`;
	return body;
}

/**
 * Tiny YAML-front-matter parser. We intentionally roll a tolerant parser
 * rather than pulling `js-yaml` into the runtime — recipes only need the
 * shape `name: …`, `description: …`, and `steps: ["…"]`. Returns `null` when
 * the file lacks a front-matter block or has no usable steps.
 */
export function parseRecipe(name: string, raw: string): Recipe | null {
	const m = /^---\s*\r?\n([\s\S]*?)\r?\n---\s*\r?\n?([\s\S]*)$/.exec(raw);
	if (!m) return null;
	const front = m[1];
	const context = (m[2] ?? "").replace(/^\s+|\s+$/g, "");
	const lines = front.split(/\r?\n/);
	let parsedName: string | undefined;
	let description = name;
	const steps: string[] = [];
	let inSteps = false;
	for (const rawLine of lines) {
		const line = rawLine.replace(/\s+$/, "");
		if (line.length === 0) continue;
		if (inSteps) {
			const stepMatch = /^\s*-\s*(.*)$/.exec(line);
			if (stepMatch) {
				steps.push(unquote(stepMatch[1]));
				continue;
			}
			// Non-list line ends the steps block.
			inSteps = false;
		}
		const kv = /^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$/.exec(line);
		if (!kv) continue;
		const key = kv[1].toLowerCase();
		const value = kv[2];
		if (key === "steps") {
			if (value.trim().length === 0) {
				inSteps = true;
			} else {
				// Inline `steps: [a, b]` — accept the common shorthand.
				const inline = parseInlineArray(value);
				for (const s of inline) steps.push(s);
			}
			continue;
		}
		if (key === "name") parsedName = unquote(value);
		else if (key === "description") description = unquote(value);
	}
	if (steps.length === 0) return null;
	return {
		name: parsedName ?? name,
		description: description.length > 0 ? description : name,
		steps,
		context,
	};
}

function serializeFrontMatter(recipe: Recipe): string {
	const lines: string[] = [];
	lines.push(`name: ${quoteIfNeeded(recipe.name)}`);
	lines.push(`description: ${quoteIfNeeded(recipe.description)}`);
	lines.push("steps:");
	for (const s of recipe.steps) lines.push(`  - ${quoteIfNeeded(s)}`);
	return `${lines.join("\n")}\n`;
}

function unquote(s: string): string {
	const trimmed = s.trim();
	if (
		(trimmed.startsWith('"') && trimmed.endsWith('"')) ||
		(trimmed.startsWith("'") && trimmed.endsWith("'"))
	) {
		return trimmed.slice(1, -1).replace(/\\"/g, '"').replace(/\\'/g, "'");
	}
	return trimmed;
}

function quoteIfNeeded(s: string): string {
	if (s.length === 0) return '""';
	if (/[:#\n"']/.test(s) || s !== s.trim()) {
		return `"${s.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
	}
	return s;
}

function parseInlineArray(raw: string): string[] {
	const inner = raw.trim();
	if (!inner.startsWith("[") || !inner.endsWith("]")) return [];
	const body = inner.slice(1, -1).trim();
	if (body.length === 0) return [];
	const out: string[] = [];
	let buf = "";
	let quote: '"' | "'" | undefined;
	for (let i = 0; i < body.length; i++) {
		const ch = body[i];
		if (quote) {
			if (ch === quote) quote = undefined;
			else buf += ch;
			continue;
		}
		if (ch === '"' || ch === "'") {
			quote = ch;
			continue;
		}
		if (ch === ",") {
			const v = buf.trim();
			if (v.length > 0) out.push(v);
			buf = "";
			continue;
		}
		buf += ch;
	}
	const tail = buf.trim();
	if (tail.length > 0) out.push(tail);
	return out;
}

function truncate(s: string, n: number): string {
	const flat = s.replace(/\s+/g, " ").trim();
	return flat.length > n ? `${flat.slice(0, n)}…` : flat;
}
