// 2026-05-23: background-process registry for HostContext.startBackgroundProcess.
//
// One instance per chat panel. Tracks PIDs spawned via the registry so
// (a) the model can stop them by PID later via `stop_background_process`,
// (b) the panel's dispose() can kill orphan dev servers automatically,
// and (c) the UI can surface a "N servers running" badge later.
//
// Deliberately node-side only — no VS Code dependency, so this same
// module can be reused by the sidecar's `node-host-context.ts` later
// if we decide to consolidate (today they're independent copies).

import * as cp from "node:child_process";
import type { BackgroundProcessHandle, BackgroundProcessOptions } from "@oati/shared";

const EARLY_OUTPUT_CAP = 8 * 1024;
const DEFAULT_WAIT_MS = 1500;
const MIN_WAIT_MS = 100;
const MAX_WAIT_MS = 10_000;

interface InternalEntry {
	readonly child: cp.ChildProcess;
	readonly handle: BackgroundProcessHandle;
}

export class BackgroundProcessRegistry {
	private readonly entries = new Map<number, InternalEntry>();

	async start(
		command: string,
		defaultCwd: string,
		options?: BackgroundProcessOptions,
	): Promise<BackgroundProcessHandle> {
		const cwd = options?.cwd ?? defaultCwd;
		const label = options?.label ?? command;
		const waitMs = clamp(options?.waitForOutputMs ?? DEFAULT_WAIT_MS, MIN_WAIT_MS, MAX_WAIT_MS);

		// Use shell: true so the model can pass "npm run dev" / "python -m
		// http.server 8000" as a single string rather than having to split
		// argv. `detached: false` keeps the child in our process group so
		// the OS cleans it up if VS Code crashes — we still call kill()
		// explicitly on session end for normal shutdown.
		const child = cp.spawn(command, {
			cwd,
			env: { ...process.env, ...(options?.env ?? {}) },
			shell: true,
			detached: false,
		});

		if (!child.pid) {
			throw new Error(`Failed to spawn background process: ${command}`);
		}

		let earlyStdout = "";
		let earlyStderr = "";
		const onStdout = (chunk: Buffer | string): void => {
			if (earlyStdout.length >= EARLY_OUTPUT_CAP) return;
			const next = earlyStdout + chunk.toString();
			earlyStdout = next.length > EARLY_OUTPUT_CAP ? next.slice(0, EARLY_OUTPUT_CAP) : next;
		};
		const onStderr = (chunk: Buffer | string): void => {
			if (earlyStderr.length >= EARLY_OUTPUT_CAP) return;
			const next = earlyStderr + chunk.toString();
			earlyStderr = next.length > EARLY_OUTPUT_CAP ? next.slice(0, EARLY_OUTPUT_CAP) : next;
		};
		child.stdout?.on("data", onStdout);
		child.stderr?.on("data", onStderr);

		let exitDuringWait: number | undefined;
		const exitDuringWaitPromise = new Promise<void>((resolve) => {
			child.once("exit", (code) => {
				exitDuringWait = code ?? -1;
				resolve();
			});
		});

		// Race the output-capture window against an early exit. Whichever
		// fires first ends the wait; the model gets meaningful output
		// either way.
		await Promise.race([
			new Promise<void>((resolve) => setTimeout(resolve, waitMs)),
			exitDuringWaitPromise,
		]);

		// Stop accumulating early output — once we return, further
		// stdout/stderr is not surfaced through this object. The child
		// keeps running and writing to its pipes; those just get drained
		// silently. (If we let the listeners stay attached, a long-lived
		// chatty server would leak memory holding gigabytes of stdout.)
		child.stdout?.removeListener("data", onStdout);
		child.stderr?.removeListener("data", onStderr);
		child.stdout?.resume();
		child.stderr?.resume();

		const handle: BackgroundProcessHandle = {
			pid: child.pid,
			command,
			cwd,
			label,
			startedAt: Date.now(),
			earlyStdout,
			earlyStderr,
			...(exitDuringWait !== undefined ? { exitedDuringWait: exitDuringWait } : {}),
		};

		if (exitDuringWait === undefined) {
			// Only track running processes. If the command already
			// exited during the wait, the PID is stale — no point
			// holding a reference for `stop` to find.
			this.entries.set(child.pid, { child, handle });
			child.once("exit", () => {
				this.entries.delete(child.pid as number);
			});
		}

		return handle;
	}

	async stop(pid: number): Promise<{ killed: boolean }> {
		const entry = this.entries.get(pid);
		if (!entry) return { killed: false };
		try {
			entry.child.kill("SIGTERM");
			// Give the process 500ms to exit gracefully; if it's still
			// alive, escalate to SIGKILL. Matters for noisy dev servers
			// that trap SIGTERM and stall their cleanup.
			await new Promise<void>((resolve) => setTimeout(resolve, 500));
			if (!entry.child.killed) {
				try {
					entry.child.kill("SIGKILL");
				} catch {
					/* best-effort */
				}
			}
			return { killed: true };
		} finally {
			this.entries.delete(pid);
		}
	}

	list(): readonly BackgroundProcessHandle[] {
		return [...this.entries.values()].map((e) => e.handle);
	}

	/** Kill every tracked process. Called from panel/session dispose. */
	disposeAll(): void {
		for (const [pid] of this.entries) {
			void this.stop(pid);
		}
	}
}

function clamp(n: number, lo: number, hi: number): number {
	return Math.max(lo, Math.min(hi, n));
}
