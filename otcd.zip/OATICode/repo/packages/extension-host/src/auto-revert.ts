// R5-E: auto-revert safety net.
//
// Wraps a sequence of file writes that an Auto* turn issued (via the
// `write_file` tool) and remembers each file's *pre-turn* contents. If the
// post-turn `run_tests` invocation reports NEW failures (i.e. failures present
// after the turn that weren't present before), `revert(turnId)` restores the
// captured snapshots through `vscode.workspace.applyEdit` so the workspace
// returns to its pre-turn shape.
//
// The guard is intentionally narrow: it does NOT auto-revert when a test was
// already broken before the turn (a regression-only safety net), and it only
// restores files we actually snapshotted. Files created during the turn are
// detected (their snapshot kind is `"absent"`) and deleted on revert; files
// the turn deleted are recreated from the snapshot.

import * as vscode from "vscode";

/** Pre-turn state for a single file path. */
export type FileSnapshot =
	| { readonly kind: "present"; readonly path: string; readonly content: string }
	| { readonly kind: "absent"; readonly path: string };

/** A full snapshot taken at `start()` time. */
export interface TurnSnapshot {
	readonly turnId: string;
	readonly files: readonly FileSnapshot[];
	readonly capturedAt: number;
}

/** Logging sink (optional; vscode.OutputChannel is the typical implementation). */
export interface AutoRevertLog {
	appendLine(line: string): void;
}

export interface AutoRevertOptions {
	readonly log?: AutoRevertLog;
	/**
	 * Workspace-relative root used to resolve plain paths. When omitted, callers
	 * must hand the guard absolute fsPaths and `vscode.Uri.file` works.
	 */
	readonly workspaceRoot?: string;
	/** Injected for tests. Defaults to `vscode.workspace.fs` + `applyEdit`. */
	readonly fs?: AutoRevertFs;
}

/**
 * Minimal filesystem surface the guard needs. Lives in `vscode.workspace.fs`
 * at runtime; tests substitute an in-memory shim.
 */
export interface AutoRevertFs {
	readFile(uri: vscode.Uri): Promise<Uint8Array>;
	writeFile(uri: vscode.Uri, content: Uint8Array): Promise<void>;
	stat(uri: vscode.Uri): Promise<{ size: number }>;
	delete(uri: vscode.Uri): Promise<void>;
}

/**
 * Guard that snapshots files, then restores them when the post-turn verdict
 * says a regression appeared. One instance per ChatPanel; many concurrent
 * turnIds may coexist (sub-agent turns nest under their own ids).
 */
export class AutoRevertGuard {
	private readonly snapshots = new Map<string, TurnSnapshot>();
	private readonly opts: AutoRevertOptions;

	constructor(opts: AutoRevertOptions = {}) {
		this.opts = opts;
	}

	/**
	 * Snapshot the *pre-turn* state of `paths`. Returns the captured snapshot
	 * (also stored internally keyed by `turnId`).
	 *
	 * Idempotent for the same `turnId` — re-calling appends additional paths
	 * to the existing snapshot rather than overwriting it. This matters when
	 * the agent issues additional `write_file` calls after the initial batch.
	 */
	async start(turnId: string, paths: readonly string[]): Promise<TurnSnapshot> {
		const existing = this.snapshots.get(turnId);
		const seen = new Set(existing?.files.map((f) => f.path) ?? []);
		const fresh: FileSnapshot[] = [];
		for (const rawPath of paths) {
			if (seen.has(rawPath)) continue;
			seen.add(rawPath);
			fresh.push(await this.snapshotOne(rawPath));
		}
		const merged: TurnSnapshot = {
			turnId,
			capturedAt: existing?.capturedAt ?? Date.now(),
			files: [...(existing?.files ?? []), ...fresh],
		};
		this.snapshots.set(turnId, merged);
		this.opts.log?.appendLine(
			`[auto-revert] snapshot turn=${turnId} files=${merged.files.length} (added=${fresh.length})`,
		);
		return merged;
	}

	/**
	 * Mark a turn as successfully committed — drops the snapshot so memory
	 * doesn't grow unbounded across long sessions. Always safe to call.
	 */
	commit(turnId: string): void {
		const had = this.snapshots.delete(turnId);
		if (had) this.opts.log?.appendLine(`[auto-revert] commit turn=${turnId}`);
	}

	/**
	 * Restore every file in the snapshot to its pre-turn contents. Returns the
	 * workspace-relative (or absolute, depending on what was passed at start)
	 * paths that were actually restored. Files we could not restore (e.g. the
	 * snapshot read failed) are logged and omitted from the returned list.
	 */
	async revert(turnId: string, reason: string): Promise<readonly string[]> {
		const snap = this.snapshots.get(turnId);
		if (!snap) {
			this.opts.log?.appendLine(`[auto-revert] revert turn=${turnId} — no snapshot`);
			return [];
		}
		this.opts.log?.appendLine(
			`[auto-revert] reverting turn=${turnId} files=${snap.files.length} reason=${reason}`,
		);
		const restored: string[] = [];
		const edit = new vscode.WorkspaceEdit();
		const deletions: vscode.Uri[] = [];
		const creations: { uri: vscode.Uri; content: string }[] = [];
		for (const file of snap.files) {
			const uri = this.resolveUri(file.path);
			if (file.kind === "absent") {
				// File didn't exist pre-turn → delete whatever was created.
				deletions.push(uri);
				restored.push(file.path);
			} else {
				// File existed pre-turn → rewrite to its original contents via WorkspaceEdit
				// so VS Code's undo stack, dirty-buffer reconciliation, and listeners all
				// see the change in the canonical way.
				try {
					const doc = await vscode.workspace.openTextDocument(uri);
					const fullRange = new vscode.Range(doc.positionAt(0), doc.positionAt(doc.getText().length));
					edit.replace(uri, fullRange, file.content);
					restored.push(file.path);
				} catch {
					// Doc couldn't be opened — fall through to a direct fs.writeFile via the
					// shim so we still get the content back even if VS Code can't open it.
					creations.push({ uri, content: file.content });
					restored.push(file.path);
				}
			}
		}
		try {
			if (edit.size > 0) await vscode.workspace.applyEdit(edit);
		} catch (err) {
			this.opts.log?.appendLine(
				`[auto-revert] applyEdit failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		const fs = this.opts.fs ?? vscode.workspace.fs;
		for (const uri of deletions) {
			try {
				await fs.delete(uri);
			} catch (err) {
				this.opts.log?.appendLine(
					`[auto-revert] delete failed for ${uri.fsPath}: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}
		for (const { uri, content } of creations) {
			try {
				await fs.writeFile(uri, new TextEncoder().encode(content));
			} catch (err) {
				this.opts.log?.appendLine(
					`[auto-revert] writeFile fallback failed for ${uri.fsPath}: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}
		this.snapshots.delete(turnId);
		return restored;
	}

	/** Exposed for tests. */
	getSnapshot(turnId: string): TurnSnapshot | undefined {
		return this.snapshots.get(turnId);
	}

	private async snapshotOne(rawPath: string): Promise<FileSnapshot> {
		const uri = this.resolveUri(rawPath);
		const fs = this.opts.fs ?? vscode.workspace.fs;
		try {
			const buf = await fs.readFile(uri);
			const content = new TextDecoder().decode(buf);
			return { kind: "present", path: rawPath, content };
		} catch {
			return { kind: "absent", path: rawPath };
		}
	}

	private resolveUri(rawPath: string): vscode.Uri {
		if (/^[a-zA-Z]:[\\/]/.test(rawPath) || rawPath.startsWith("/")) {
			return vscode.Uri.file(rawPath);
		}
		if (this.opts.workspaceRoot) {
			return vscode.Uri.file(
				`${this.opts.workspaceRoot.replace(/[\\/]$/, "")}/${rawPath.replace(/^[\\/]/, "")}`,
			);
		}
		return vscode.Uri.file(rawPath);
	}
}

/**
 * Diff the failure lists. A failure is considered "new" when its `name`
 * appears in `after` but not in `before`. Useful as the post-turn check that
 * gates the `revert()` call.
 */
export function newFailures(
	before: readonly { readonly name: string }[],
	after: readonly { readonly name: string }[],
): readonly { readonly name: string }[] {
	const beforeNames = new Set(before.map((f) => f.name));
	return after.filter((f) => !beforeNames.has(f.name));
}
