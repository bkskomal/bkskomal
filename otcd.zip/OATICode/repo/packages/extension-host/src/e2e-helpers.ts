// R7-B: e2e test-only helpers. Registers a tiny set of internal commands and
// surfaces that the in-VS-Code Mocha suite uses to drive flows that aren't
// exposed via the user-facing command palette.
//
// These commands are ONLY registered when `process.env.OATI_E2E === "1"` so
// they cannot leak into normal user sessions. Each command's name is namespaced
// under `oati._test.*` to make that intent obvious.
//
// @internal — do not document or call from production code paths.

import type { DiffPreview } from "@oati/shared";
import * as vscode from "vscode";
import type { InlineDiffController } from "./inline-diff";
import type { MarketplaceManager } from "./mcp-marketplace";
import { redactSecrets, scanForSecrets, summarizeMatches } from "./secret-scanner";

/** @internal */
export interface E2eHelperDeps {
	readonly inlineDiff: InlineDiffController;
	readonly marketplace: MarketplaceManager;
}

/**
 * Register the e2e helper commands. No-op when `OATI_E2E` is not set so
 * normal users never see these in the command palette.
 *
 * @internal
 */
export function registerE2eHelpers(context: vscode.ExtensionContext, deps: E2eHelperDeps): void {
	if (process.env.OATI_E2E !== "1") return;

	// Present an inline diff session against an in-memory file. Returns the
	// raw code lenses VS Code's CodeLens provider emits, so a test can assert
	// on the hunk line ranges.
	const present = vscode.commands.registerCommand(
		"oati._test.presentInlineDiff",
		async (args: { path: string; before: string; after: string }) => {
			const uri = vscode.Uri.file(args.path);
			// Write the "after" content so the file exists on disk for the
			// controller. The controller is responsible for the rendering.
			await vscode.workspace.fs.writeFile(uri, Buffer.from(args.after, "utf-8"));
			const diff: DiffPreview = {
				path: args.path,
				before: args.before,
				after: args.after,
			};
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			await deps.inlineDiff.present(diff, root);
			const lenses = await vscode.commands.executeCommand<vscode.CodeLens[]>(
				"vscode.executeCodeLensProvider",
				uri,
			);
			// Filter to lenses our controller owns by checking the command id.
			const ours = (lenses ?? []).filter((l) => {
				const cmd = l.command?.command ?? "";
				return cmd.startsWith("oati.inlineDiff.");
			});
			return ours.map((l) => ({
				command: l.command?.command,
				startLine: l.range.start.line,
				endLine: l.range.end.line,
			}));
		},
	);

	// Snapshot the marketplace state. Mirrors what `marketplace_state` would
	// carry to the webview without needing to instantiate a panel.
	const marketState = vscode.commands.registerCommand("oati._test.marketplaceState", () => {
		return deps.marketplace.list().map((item) => ({
			id: item.entry.id,
			displayName: item.entry.displayName,
			installed: item.installed,
			enabled: item.enabled,
		}));
	});

	// Scan a string with the same redactor the chat-panel uses before any
	// provider call. Lets tests verify the BEFORE-call guarantee without
	// having to wire a fake provider.
	const scan = vscode.commands.registerCommand(
		"oati._test.scanForSecrets",
		(args: { text: string }) => {
			const matches = scanForSecrets(args.text);
			const redacted = redactSecrets(args.text);
			return {
				count: matches.length,
				summary: summarizeMatches(matches),
				matches: matches.map((m) => ({ kind: m.kind, preview: m.preview })),
				redacted: redacted.redacted,
			};
		},
	);

	context.subscriptions.push(present, marketState, scan);
}
