import type * as vscode from "vscode";

/**
 * Minimal key/value storage interface. Modeled after VS Code's `Memento` so
 * the real `context.globalState` satisfies it directly, and tests can provide
 * a one-liner in-memory implementation.
 */
export interface KvStorage {
	get<T>(key: string): T | undefined;
	update(key: string, value: unknown): Promise<void>;
}

/**
 * Minimal secret storage interface. Modeled after VS Code's `SecretStorage`.
 */
export interface SecretStorage {
	get(key: string): Promise<string | undefined>;
	store(key: string, value: string): Promise<void>;
	delete(key: string): Promise<void>;
}

export function kvFromVsCode(context: vscode.ExtensionContext): KvStorage {
	return {
		get: <T>(key: string) => context.globalState.get<T>(key),
		update: (key, value) =>
			Promise.resolve(context.globalState.update(key, value)).then(() => undefined),
	};
}

export function secretsFromVsCode(context: vscode.ExtensionContext): SecretStorage {
	return {
		get: (key) => Promise.resolve(context.secrets.get(key)),
		store: (key, value) => Promise.resolve(context.secrets.store(key, value)),
		delete: (key) => Promise.resolve(context.secrets.delete(key)),
	};
}

/** In-memory KV for tests. */
export class InMemoryKv implements KvStorage {
	private readonly data = new Map<string, unknown>();
	get<T>(key: string): T | undefined {
		return this.data.get(key) as T | undefined;
	}
	async update(key: string, value: unknown): Promise<void> {
		if (value === undefined) this.data.delete(key);
		else this.data.set(key, value);
	}
}

/** In-memory secret store for tests. */
export class InMemorySecrets implements SecretStorage {
	private readonly data = new Map<string, string>();
	async get(key: string): Promise<string | undefined> {
		return this.data.get(key);
	}
	async store(key: string, value: string): Promise<void> {
		this.data.set(key, value);
	}
	async delete(key: string): Promise<void> {
		this.data.delete(key);
	}
}
