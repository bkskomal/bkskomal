// 2026-05-28: Word .docx builder for an executed QA test plan. Reads the
// LoadedPlan handed in by /qa report, projects every row's Status onto a
// summary table + by-module breakdown + failures section, and produces a
// buffer the chat-panel writes to disk.
//
// Style mirrors the existing review/QA report builders so all three OATI
// documents read as one family: brand-navy header, severity-style chips,
// monospace path bands for any source references.

import {
	AlignmentType,
	BorderStyle,
	Document,
	HeadingLevel,
	Packer,
	Paragraph,
	ShadingType,
	Table,
	TableCell,
	TableRow,
	TextRun,
	WidthType,
} from "docx";
import type { ExecutionResult, LoadedPlan, TestStatus } from "./qa-execute";

const BRAND_NAVY = "1A2B4A";
const STATUS_COLOR: Readonly<Record<TestStatus, string>> = {
	Pass: "22863A",
	Fail: "D73A49",
	Blocked: "B08800",
	Skipped: "6A737D",
};

export interface BuildOptions {
	readonly plan: LoadedPlan;
	readonly projectName: string;
	readonly generatedAt: Date;
}

interface RowSnapshot {
	readonly tcId: string;
	readonly title: string;
	readonly module?: string;
	readonly status: TestStatus | "";
	readonly actual?: string;
}

function readStatus(raw: string | undefined): TestStatus | "" {
	if (!raw) return "";
	const t = raw.trim();
	if (/^pass(ed)?$/i.test(t)) return "Pass";
	if (/^fail(ed)?$/i.test(t)) return "Fail";
	if (/^blocked$/i.test(t)) return "Blocked";
	if (/^skip(ped)?$/i.test(t)) return "Skipped";
	return "";
}

export async function buildQAExecutedReport(opts: BuildOptions): Promise<Buffer> {
	const ws = opts.plan.worksheet;
	const schema = opts.plan.schema;
	const statusCol = schema.columnByConcept.status;
	const actualCol = schema.columnByConcept.actual;
	const titleCol = schema.columnByConcept.title;
	const tcCol = schema.columnByConcept.tcId;
	const moduleCol = (schema.columnByConcept as Record<string, number>).module;

	const rows: RowSnapshot[] = [];
	for (let r = schema.headerRowIndex + 1; r <= ws.rowCount; r++) {
		const xlRow = ws.getRow(r);
		const tcId = stringCell(xlRow.getCell(tcCol).value);
		const title = stringCell(xlRow.getCell(titleCol).value);
		if (!tcId && !title) continue;
		const status = readStatus(statusCol ? stringCell(xlRow.getCell(statusCol).value) : "");
		const actual = actualCol ? stringCell(xlRow.getCell(actualCol).value) : "";
		const mod = moduleCol ? stringCell(xlRow.getCell(moduleCol).value) : "";
		rows.push({
			tcId,
			title,
			...(mod ? { module: mod } : {}),
			status,
			...(actual ? { actual } : {}),
		});
	}

	const total = rows.length;
	const pass = rows.filter((r) => r.status === "Pass").length;
	const fail = rows.filter((r) => r.status === "Fail").length;
	const blocked = rows.filter((r) => r.status === "Blocked").length;
	const skipped = rows.filter((r) => r.status === "Skipped").length;
	const passRate = total === 0 ? 0 : Math.round((pass / total) * 100);

	const children: (Paragraph | Table)[] = [];

	// Title
	children.push(
		new Paragraph({
			heading: HeadingLevel.HEADING_1,
			children: [
				new TextRun({
					text: `QA Report — ${opts.projectName}`,
					bold: true,
					color: BRAND_NAVY,
					size: 36,
				}),
			],
		}),
	);
	children.push(
		new Paragraph({
			children: [
				new TextRun({
					text: `${opts.plan.kind === "functional" ? "Functional" : "Unit"} test plan, ${opts.generatedAt.toLocaleString()}`,
					italics: true,
					color: "555555",
					size: 22,
				}),
			],
		}),
	);
	children.push(emptyParagraph());

	// Summary table (4 cells)
	children.push(
		new Paragraph({
			heading: HeadingLevel.HEADING_2,
			children: [new TextRun({ text: "Summary", color: BRAND_NAVY })],
		}),
	);
	children.push(
		new Paragraph({
			children: [
				new TextRun({ text: "Pass rate: ", bold: true }),
				new TextRun({
					text: `${passRate}%`,
					bold: true,
					size: 28,
					color:
						passRate >= 80
							? STATUS_COLOR.Pass
							: passRate >= 50
								? STATUS_COLOR.Blocked
								: STATUS_COLOR.Fail,
				}),
				new TextRun({ text: `  (${pass} / ${total} cases)` }),
			],
		}),
	);
	children.push(buildStatusTable({ pass, fail, blocked, skipped }));
	children.push(emptyParagraph());

	// By-module breakdown (only meaningful for functional plans)
	if (opts.plan.kind === "functional") {
		const byModule = new Map<
			string,
			{ pass: number; fail: number; blocked: number; skipped: number }
		>();
		for (const r of rows) {
			const key = r.module ?? "(unspecified)";
			const entry = byModule.get(key) ?? { pass: 0, fail: 0, blocked: 0, skipped: 0 };
			if (r.status === "Pass") entry.pass++;
			else if (r.status === "Fail") entry.fail++;
			else if (r.status === "Blocked") entry.blocked++;
			else if (r.status === "Skipped") entry.skipped++;
			byModule.set(key, entry);
		}
		children.push(
			new Paragraph({
				heading: HeadingLevel.HEADING_2,
				children: [new TextRun({ text: "By module", color: BRAND_NAVY })],
			}),
		);
		children.push(buildByModuleTable(byModule));
		children.push(emptyParagraph());
	}

	// Failures section
	const failures = rows.filter((r) => r.status === "Fail" || r.status === "Blocked");
	if (failures.length > 0) {
		children.push(
			new Paragraph({
				heading: HeadingLevel.HEADING_2,
				children: [
					new TextRun({
						text: `Failures and blockers (${failures.length})`,
						color: STATUS_COLOR.Fail,
					}),
				],
			}),
		);
		for (const f of failures) {
			children.push(
				new Paragraph({
					children: [
						new TextRun({ text: `${f.tcId}: `, bold: true, color: BRAND_NAVY }),
						new TextRun({ text: f.title, bold: true }),
						new TextRun({
							text: `  ${f.status}`,
							bold: true,
							color: STATUS_COLOR[f.status as TestStatus] ?? "000000",
						}),
					],
				}),
			);
			if (f.actual) {
				children.push(
					new Paragraph({
						children: [
							new TextRun({ text: "Actual: ", italics: true }),
							new TextRun({ text: f.actual.slice(0, 800) }),
						],
					}),
				);
			}
			children.push(emptyParagraph());
		}
	} else {
		children.push(
			new Paragraph({
				children: [
					new TextRun({
						text: "No failures recorded — all executed cases passed.",
						italics: true,
						color: STATUS_COLOR.Pass,
					}),
				],
			}),
		);
	}

	const doc = new Document({
		creator: "OATI Code",
		title: `QA Report — ${opts.projectName}`,
		sections: [{ children }],
	});
	return Packer.toBuffer(doc);
}

function buildStatusTable(counts: {
	pass: number;
	fail: number;
	blocked: number;
	skipped: number;
}): Table {
	const cells = [
		statusCell("Pass", counts.pass, STATUS_COLOR.Pass),
		statusCell("Fail", counts.fail, STATUS_COLOR.Fail),
		statusCell("Blocked", counts.blocked, STATUS_COLOR.Blocked),
		statusCell("Skipped", counts.skipped, STATUS_COLOR.Skipped),
	];
	return new Table({
		rows: [new TableRow({ children: cells })],
		width: { size: 100, type: WidthType.PERCENTAGE },
	});
}

function statusCell(label: string, value: number, colorHex: string): TableCell {
	return new TableCell({
		width: { size: 25, type: WidthType.PERCENTAGE },
		shading: { type: ShadingType.CLEAR, fill: colorHex, color: "auto" },
		children: [
			new Paragraph({
				alignment: AlignmentType.CENTER,
				children: [
					new TextRun({
						text: `${value}`,
						bold: true,
						color: "FFFFFF",
						size: 36,
					}),
				],
			}),
			new Paragraph({
				alignment: AlignmentType.CENTER,
				children: [new TextRun({ text: label, color: "FFFFFF", size: 20 })],
			}),
		],
	});
}

function buildByModuleTable(
	byModule: ReadonlyMap<string, { pass: number; fail: number; blocked: number; skipped: number }>,
): Table {
	const headerRow = new TableRow({
		children: ["Module", "Pass", "Fail", "Blocked", "Skipped"].map(
			(h) =>
				new TableCell({
					shading: { type: ShadingType.CLEAR, fill: BRAND_NAVY, color: "auto" },
					children: [
						new Paragraph({
							children: [new TextRun({ text: h, bold: true, color: "FFFFFF" })],
						}),
					],
				}),
		),
	});
	const dataRows = Array.from(byModule.entries()).map(
		([mod, counts]) =>
			new TableRow({
				children: [
					new TableCell({ children: [new Paragraph(mod)] }),
					new TableCell({ children: [new Paragraph(String(counts.pass))] }),
					new TableCell({ children: [new Paragraph(String(counts.fail))] }),
					new TableCell({ children: [new Paragraph(String(counts.blocked))] }),
					new TableCell({ children: [new Paragraph(String(counts.skipped))] }),
				],
			}),
	);
	return new Table({
		rows: [headerRow, ...dataRows],
		width: { size: 100, type: WidthType.PERCENTAGE },
		borders: defaultBorders(),
	});
}

function defaultBorders() {
	const b = { style: BorderStyle.SINGLE, size: 4, color: "DDDDDD" };
	return { top: b, bottom: b, left: b, right: b, insideHorizontal: b, insideVertical: b };
}

function emptyParagraph(): Paragraph {
	return new Paragraph({ children: [] });
}

function stringCell(v: unknown): string {
	if (v === null || v === undefined) return "";
	if (typeof v === "string") return v;
	if (typeof v === "number" || typeof v === "boolean") return String(v);
	if (v instanceof Date) return v.toISOString();
	if (typeof v === "object" && "text" in v && typeof (v as { text?: unknown }).text === "string") {
		return (v as { text: string }).text;
	}
	return String(v);
}

// Avoid the unused-import warning when the executor isn't used here.
void (undefined as unknown as ExecutionResult);
