import * as fs from "node:fs";
import * as path from "node:path";
import type { Conductor } from "@oati/agent-core";
import type { AgentEvent, ConversationMessage, ModeConfig } from "@oati/shared";

/**
 * Background tasks runner.
 *
 * Long-running agent jobs survive panel close / window blur by being
 * dispatched through the {@link BackgroundTaskRunner} instead of being
 * tied to a specific {@link ChatPanel}'s lifetime. Each task gets its own
 * {@link AbortController}, an on-disk JSON record under
 * `<workspace>/.oati/tasks/<id>.json` so completed runs persist across
 * VS Code restarts, and a pair of event emitters so panels (or the status
 * bar) can subscribe to per-task progress.
 *
 * Rehydration: on construction, any task file whose `status` was still
 * `"running"` is downgraded to `"interrupted"` — VS Code was shut down
 * mid-task, the underlying provider stream is long gone, and we want the
 * task to show up in history as "interrupted" rather than pretending it's
 * still chugging along.
 */

export type TaskStatus = "running" | "completed" | "cancelled" | "error" | "interrupted";

export interface BackgroundTask {
	readonly id: string;
	readonly label: string;
	readonly status: TaskStatus;
	readonly startedAt: string;
	readonly lastUpdate: string;
	readonly messagesCount: number;
	readonly cost: number;
	readonly inputTokens: number;
	readonly outputTokens: number;
	readonly summary?: string;
}

export interface StartBackgroundTaskInput {
	readonly userMessage: string;
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly history?: readonly ConversationMessage[];
	/** Short human-readable label shown in the status bar / task list. */
	readonly label?: string;
}

export interface StartBackgroundTaskOptions {
	readonly conductor: Conductor;
	/** Used to estimate cost on the fly (returns USD per a token usage burst). */
	readonly estimateUsd?: (modelId: string, inputTokens: number, outputTokens: number) => number;
}

export interface BackgroundTaskResult {
	readonly status: Exclude<TaskStatus, "running" | "interrupted">;
	readonly summary: string;
}

export type ProgressListener = (taskId: string, chunk: string) => void;
export type CompletedListener = (taskId: string, result: BackgroundTaskResult) => void;

interface InternalTask {
	state: BackgroundTask;
	controller: AbortController;
	modelId: string;
	/** Disposer for the conductor event subscription. Always called on completion. */
	offConductor?: () => void;
}

export interface BackgroundTaskRunnerOptions {
	/** Absolute workspace root. When undefined, tasks are kept in-memory only. */
	readonly workspaceRoot?: string;
	/** Optional logger for diagnostics. */
	readonly log?: { appendLine(msg: string): void };
}

const TASKS_DIRNAME = path.join(".oati", "tasks");

export class BackgroundTaskRunner {
	private readonly tasks = new Map<string, InternalTask>();
	private readonly progressListeners = new Set<ProgressListener>();
	private readonly completedListeners = new Set<CompletedListener>();
	private nextId = 1;

	constructor(private readonly opts: BackgroundTaskRunnerOptions = {}) {
		this.rehydrate();
	}

	/** All known tasks, most-recent-first. */
	list(): readonly BackgroundTask[] {
		return Array.from(this.tasks.values())
			.map((t) => t.state)
			.sort((a, b) => (a.startedAt < b.startedAt ? 1 : -1));
	}

	/** Number of tasks currently in `running` state. */
	runningCount(): number {
		let n = 0;
		for (const t of this.tasks.values()) if (t.state.status === "running") n++;
		return n;
	}

	onProgress(listener: ProgressListener): () => void {
		this.progressListeners.add(listener);
		return () => this.progressListeners.delete(listener);
	}

	onCompleted(listener: CompletedListener): () => void {
		this.completedListeners.add(listener);
		return () => this.completedListeners.delete(listener);
	}

	start(input: StartBackgroundTaskInput, opts: StartBackgroundTaskOptions): string {
		const id = this.allocateId();
		const now = new Date().toISOString();
		const label = (input.label ?? input.userMessage).slice(0, 80).trim() || "background task";
		const controller = new AbortController();
		const internal: InternalTask = {
			state: {
				id,
				label,
				status: "running",
				startedAt: now,
				lastUpdate: now,
				messagesCount: 0,
				cost: 0,
				inputTokens: 0,
				outputTokens: 0,
			},
			controller,
			modelId: input.modelId,
		};
		this.tasks.set(id, internal);
		this.persist(internal.state);

		// Subscribe to conductor events so we can stream progress + accumulate
		// per-task usage. The subscription is disposed in the finally block of
		// the async runner below.
		const off = opts.conductor.on((ev) => this.onConductorEvent(id, ev, opts.estimateUsd));
		internal.offConductor = off;

		// Fire-and-forget — the caller gets the task id immediately, the
		// conductor runs to completion in the background. Errors are routed
		// into the task's status, never thrown.
		void this.runUntilDone(internal, input, opts);

		return id;
	}

	async cancel(taskId: string): Promise<void> {
		const t = this.tasks.get(taskId);
		if (!t) return;
		if (t.state.status !== "running") return;
		t.controller.abort();
		this.updateState(t, { status: "cancelled" });
		this.emitCompleted(taskId, { status: "cancelled", summary: "Cancelled by user." });
	}

	/** Stop watching all tasks and abort any in-flight ones. Idempotent. */
	dispose(): void {
		for (const t of this.tasks.values()) {
			if (t.state.status === "running") {
				try {
					t.controller.abort();
				} catch {
					// best-effort
				}
			}
			t.offConductor?.();
		}
		this.progressListeners.clear();
		this.completedListeners.clear();
	}

	// ------------------------------------------------------------------
	// Internals
	// ------------------------------------------------------------------

	private allocateId(): string {
		return `bt_${Date.now().toString(36)}_${(this.nextId++).toString(36)}`;
	}

	private onConductorEvent(
		taskId: string,
		ev: AgentEvent,
		estimateUsd?: (modelId: string, inputTokens: number, outputTokens: number) => number,
	): void {
		const t = this.tasks.get(taskId);
		if (!t || t.state.status !== "running") return;

		if (ev.type === "text_delta") {
			this.emitProgress(taskId, ev.text);
		} else if (ev.type === "tool_call") {
			this.emitProgress(taskId, `→ ${ev.call.name}\n`);
		} else if (ev.type === "tool_result") {
			this.updateState(t, { messagesCount: t.state.messagesCount + 1 });
		} else if (ev.type === "usage") {
			const inputTokens = t.state.inputTokens + ev.inputTokens;
			const outputTokens = t.state.outputTokens + ev.outputTokens;
			const delta = estimateUsd?.(t.modelId, ev.inputTokens, ev.outputTokens) ?? 0;
			this.updateState(t, {
				inputTokens,
				outputTokens,
				cost: t.state.cost + delta,
			});
		}
	}

	private async runUntilDone(
		internal: InternalTask,
		input: StartBackgroundTaskInput,
		opts: StartBackgroundTaskOptions,
	): Promise<void> {
		const { conductor } = opts;
		try {
			await conductor.spawn({
				mode: input.mode,
				modelId: input.modelId,
				userMessage: input.userMessage,
				...(input.history ? { history: input.history } : {}),
				signal: internal.controller.signal,
			});
			if (internal.state.status === "running") {
				this.updateState(internal, { status: "completed" });
				this.emitCompleted(internal.state.id, {
					status: "completed",
					summary: `Completed with ${internal.state.messagesCount} tool result(s).`,
				});
			}
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			if (internal.controller.signal.aborted && internal.state.status === "cancelled") {
				// Already marked by cancel(); nothing else to do.
				return;
			}
			this.updateState(internal, { status: "error", summary: message });
			this.emitCompleted(internal.state.id, { status: "error", summary: message });
			this.opts.log?.appendLine(`[background-tasks] ${internal.state.id} failed: ${message}`);
		} finally {
			internal.offConductor?.();
			internal.offConductor = undefined;
		}
	}

	private updateState(t: InternalTask, patch: Partial<BackgroundTask>): void {
		const next: BackgroundTask = {
			...t.state,
			...patch,
			lastUpdate: new Date().toISOString(),
		};
		t.state = next;
		this.persist(next);
	}

	private emitProgress(taskId: string, chunk: string): void {
		for (const l of this.progressListeners) {
			try {
				l(taskId, chunk);
			} catch {
				// listeners are best-effort
			}
		}
	}

	private emitCompleted(taskId: string, result: BackgroundTaskResult): void {
		for (const l of this.completedListeners) {
			try {
				l(taskId, result);
			} catch {
				// listeners are best-effort
			}
		}
	}

	private tasksDir(): string | undefined {
		const root = this.opts.workspaceRoot;
		if (!root) return undefined;
		return path.join(root, TASKS_DIRNAME);
	}

	private persist(state: BackgroundTask): void {
		const dir = this.tasksDir();
		if (!dir) return;
		try {
			fs.mkdirSync(dir, { recursive: true });
			const file = path.join(dir, `${state.id}.json`);
			fs.writeFileSync(file, JSON.stringify(state, null, 2), "utf-8");
		} catch (err) {
			this.opts.log?.appendLine(
				`[background-tasks] persist ${state.id} failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}

	private rehydrate(): void {
		const dir = this.tasksDir();
		if (!dir) return;
		let entries: string[];
		try {
			entries = fs.readdirSync(dir).filter((f) => f.endsWith(".json"));
		} catch {
			// dir doesn't exist yet — nothing to rehydrate
			return;
		}
		for (const file of entries) {
			try {
				const text = fs.readFileSync(path.join(dir, file), "utf-8");
				const raw = JSON.parse(text) as Partial<BackgroundTask>;
				if (!raw.id || !raw.status) continue;
				const status: TaskStatus = raw.status === "running" ? "interrupted" : raw.status;
				const state: BackgroundTask = {
					id: raw.id,
					label: raw.label ?? "(unnamed task)",
					status,
					startedAt: raw.startedAt ?? new Date(0).toISOString(),
					lastUpdate: new Date().toISOString(),
					messagesCount: raw.messagesCount ?? 0,
					cost: raw.cost ?? 0,
					inputTokens: raw.inputTokens ?? 0,
					outputTokens: raw.outputTokens ?? 0,
					summary: raw.summary,
				};
				// Rehydrated tasks have no live AbortController/Conductor — they
				// exist only as history rows. We still register them so list() sees
				// them; cancel() is a no-op for non-running statuses.
				this.tasks.set(state.id, {
					state,
					controller: new AbortController(),
					modelId: "",
				});
				if (status === "interrupted") {
					this.persist(state);
				}
			} catch (err) {
				this.opts.log?.appendLine(
					`[background-tasks] rehydrate ${file} failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}
	}
}
