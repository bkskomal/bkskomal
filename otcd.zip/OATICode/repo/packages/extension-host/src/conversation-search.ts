/**
 * R5-C: thin helper around `SessionIndex` for the host-side `/search`
 * command and the `search_conversations` tool. Both surfaces share the same
 * scoring / filtering rules — keeping that logic here avoids two slightly
 * different result shapes drifting apart.
 */
import type { ConversationHit, SessionIndex } from "./session-index";

export interface ConversationSearchOptions {
	readonly k?: number;
	readonly sessionId?: string;
}

/**
 * Run a semantic search against the conversation index and return the hits
 * in descending score order. Falsy / empty queries return an empty array
 * rather than throwing, so callers can pipe user input through unchecked.
 */
export async function searchConversations(
	index: SessionIndex | undefined,
	query: string,
	opts: ConversationSearchOptions = {},
): Promise<readonly ConversationHit[]> {
	if (!index) return [];
	const trimmed = (query ?? "").trim();
	if (trimmed.length === 0) return [];
	return index.search(trimmed, {
		...(opts.k !== undefined ? { k: opts.k } : {}),
		...(opts.sessionId ? { sessionId: opts.sessionId } : {}),
	});
}
