/**
 * 2026-06-02: bounded ring buffer of recent edits across open files,
 * used to enrich the inline-completion FIM prompt with "the user just
 * did X over there" context. Mirrors Cursor's behavior where edits in
 * file A inform completions in file B (e.g., you rename a function in
 * one file and start typing the same call site in another — the model
 * sees the rename and suggests the new name).
 *
 * Design:
 *   - Ring buffer capped at MAX_ENTRIES (default 10). Oldest entries
 *     drop when capacity is exceeded.
 *   - Each entry stores a SMALL snippet around the edit point (≤200
 *     chars on each side), not the full file diff — keeps the prompt
 *     budget bounded.
 *   - Edits older than TTL_MS are filtered out at read time.
 *   - Agent-driven bulk writes (write_file with full content replacement)
 *     should be skipped by the caller — call `shouldRecordEdit()` before
 *     `push()`. Otherwise a single agent batch would flood the buffer.
 */

export interface RecentEdit {
	readonly path: string;
	readonly languageId: string;
	/** When the edit happened (ms since epoch). */
	readonly timestamp: number;
	/**
	 * 1-2 sentences of context around the edit point. The format is
	 * `<snippet>` — we don't carry the actual diff because the prompt
	 * already has the model see the current state of the destination
	 * file; what matters is "what was this user just thinking about."
	 */
	readonly snippet: string;
}

const DEFAULT_MAX_ENTRIES = 10;
const DEFAULT_TTL_MS = 5 * 60_000; // 5 minutes
const DEFAULT_SNIPPET_CHARS = 200;
/** Above this character delta, treat the edit as a bulk write and skip recording. */
const BULK_EDIT_THRESHOLD_CHARS = 1000;

export interface RecentEditsOptions {
	readonly maxEntries?: number;
	readonly ttlMs?: number;
	readonly now?: () => number;
}

export class RecentEditsRingBuffer {
	private readonly entries: RecentEdit[] = [];
	private readonly maxEntries: number;
	private readonly ttlMs: number;
	private readonly now: () => number;

	constructor(opts: RecentEditsOptions = {}) {
		this.maxEntries = opts.maxEntries ?? DEFAULT_MAX_ENTRIES;
		this.ttlMs = opts.ttlMs ?? DEFAULT_TTL_MS;
		this.now = opts.now ?? (() => Date.now());
	}

	push(edit: Omit<RecentEdit, "timestamp"> & { timestamp?: number }): void {
		const stamped: RecentEdit = {
			path: edit.path,
			languageId: edit.languageId,
			snippet: edit.snippet,
			timestamp: edit.timestamp ?? this.now(),
		};
		this.entries.push(stamped);
		if (this.entries.length > this.maxEntries) {
			this.entries.shift();
		}
	}

	/**
	 * Return the N most-recent edits that haven't yet aged out, optionally
	 * excluding edits made to a specific path (the path the user is
	 * currently completing in — they already see that file's content).
	 */
	getRecent(opts: { limit: number; excludePath?: string }): readonly RecentEdit[] {
		const cutoff = this.now() - this.ttlMs;
		const fresh = this.entries.filter((e) => e.timestamp >= cutoff);
		const filtered = opts.excludePath ? fresh.filter((e) => e.path !== opts.excludePath) : fresh;
		// Most-recent first.
		return filtered.slice(-opts.limit).reverse();
	}

	clear(): void {
		this.entries.length = 0;
	}

	size(): number {
		return this.entries.length;
	}
}

/**
 * Heuristic: should we record this text change as a "recent edit," or
 * is it a bulk write that would just flood the buffer? Skip when the
 * total character delta is huge (likely agent write_file or a paste
 * of >1000 chars). Exported for testability.
 */
export function shouldRecordEdit(deltaChars: number): boolean {
	return deltaChars > 0 && deltaChars < BULK_EDIT_THRESHOLD_CHARS;
}

/**
 * Slice a small window of context around the edit position. Used by
 * the caller to pull a snippet from the document just after the edit
 * fires. Exported for testability.
 */
export function buildEditSnippet(
	documentText: string,
	editOffset: number,
	maxChars: number = DEFAULT_SNIPPET_CHARS,
): string {
	const start = Math.max(0, editOffset - Math.floor(maxChars / 2));
	const end = Math.min(documentText.length, editOffset + Math.floor(maxChars / 2));
	let snippet = documentText.slice(start, end);
	// Collapse runs of whitespace so we get more signal per character.
	snippet = snippet.replace(/\s+/g, " ").trim();
	return snippet;
}

/**
 * Format the recent-edits block for inclusion in the FIM prompt's user
 * message. Returns an empty string when there are no edits to show
 * (caller should still call it; the empty-string return is the
 * "include nothing" signal).
 */
export function formatRecentEditsForPrompt(edits: readonly RecentEdit[]): string {
	if (edits.length === 0) return "";
	const lines: string[] = ["<recent_edits>"];
	for (const e of edits) {
		lines.push(`<edit path="${e.path}" lang="${e.languageId}">`);
		lines.push(e.snippet);
		lines.push("</edit>");
	}
	lines.push("</recent_edits>");
	return lines.join("\n");
}
