/*
 * R8-A: predict-next-edit-location — pure heuristic that, given the current
 * document text and the cursor position the user just accepted a completion
 * at, returns the offset of the next likely edit. Powers the "tab-to-jump"
 * behaviour that lets the user keep tabbing through a stream of suggestions
 * without ever touching the mouse.
 *
 * Heuristics order (first match wins):
 *   1. Explicit placeholder markers on or after the current line:
 *        - <TODO>, <FIXME>, <CURSOR>, <here>
 *        - // TODO, // FIXME (or # / -- for Python / SQL)
 *        - the literal `pass` keyword (Python placeholder body)
 *        - `throw new Error("Not implemented")` and friends
 *   2. The start of the next non-empty line below the cursor.
 *   3. End of document fallback.
 *
 * Pure — no VS Code or provider deps — so it's testable in isolation.
 */

export interface PredictNextEditInput {
	readonly documentText: string;
	/** 0-based offset of the cursor immediately after the accepted completion. */
	readonly currentOffset: number;
	/** Language id, used to pick the right comment-style placeholder regex. */
	readonly languageId: string;
	/** Optional: cap how many bytes ahead we'll scan. Defaults to 4 KiB. */
	readonly scanBudgetBytes?: number;
}

export interface PredictNextEditOutput {
	readonly offset: number;
	readonly reason:
		| "placeholder_marker"
		| "todo_comment"
		| "pass_keyword"
		| "not_implemented"
		| "next_nonempty_line"
		| "end_of_document";
	/** The literal marker text matched (for telemetry / tests). Empty for the EOF fallback. */
	readonly marker: string;
}

const DEFAULT_SCAN_BYTES = 4096;

// Placeholders we recognise as "obviously the next spot to edit". Ordered by
// priority — first hit in the scan window wins.
const PLACEHOLDER_MARKERS: readonly string[] = [
	"<TODO>",
	"<FIXME>",
	"<CURSOR>",
	"<HERE>",
	"<todo>",
	"<fixme>",
	"<cursor>",
	"<here>",
];

const NOT_IMPLEMENTED_SNIPPETS: readonly string[] = [
	'throw new Error("Not implemented")',
	"throw new Error('Not implemented')",
	'throw new Error("not implemented")',
	"raise NotImplementedError",
	"unimplemented!()",
	"todo!()",
	"TODO()",
];

const TODO_COMMENT_BY_LANGUAGE: Record<string, readonly RegExp[]> = {
	python: [/^\s*#\s*(TODO|FIXME)\b/m, /^\s*pass\s*$/m],
	ruby: [/^\s*#\s*(TODO|FIXME)\b/m],
	yaml: [/^\s*#\s*(TODO|FIXME)\b/m],
	shellscript: [/^\s*#\s*(TODO|FIXME)\b/m],
	sql: [/^\s*--\s*(TODO|FIXME)\b/m],
	html: [/<!--\s*(TODO|FIXME)/m],
};

const DEFAULT_TODO_REGEXES: readonly RegExp[] = [
	/^\s*\/\/\s*(TODO|FIXME)\b/m,
	/^\s*\/\*\s*(TODO|FIXME)\b/m,
];

/**
 * Run the heuristic. Pure — exposed for unit tests.
 */
export function predictNextEditLocation(input: PredictNextEditInput): PredictNextEditOutput {
	const text = input.documentText;
	const start = Math.max(0, Math.min(text.length, input.currentOffset));
	const end = Math.min(text.length, start + (input.scanBudgetBytes ?? DEFAULT_SCAN_BYTES));
	const window = text.slice(start, end);

	// 1a. Explicit placeholder markers.
	let bestMarkerIdx = -1;
	let bestMarker = "";
	for (const marker of PLACEHOLDER_MARKERS) {
		const idx = window.indexOf(marker);
		if (idx >= 0 && (bestMarkerIdx === -1 || idx < bestMarkerIdx)) {
			bestMarkerIdx = idx;
			bestMarker = marker;
		}
	}
	if (bestMarkerIdx >= 0) {
		return {
			offset: start + bestMarkerIdx,
			reason: "placeholder_marker",
			marker: bestMarker,
		};
	}

	// 1b. Not-implemented sentinel snippets.
	let bestSentinelIdx = -1;
	let bestSentinel = "";
	for (const snippet of NOT_IMPLEMENTED_SNIPPETS) {
		const idx = window.indexOf(snippet);
		if (idx >= 0 && (bestSentinelIdx === -1 || idx < bestSentinelIdx)) {
			bestSentinelIdx = idx;
			bestSentinel = snippet;
		}
	}
	if (bestSentinelIdx >= 0) {
		return {
			offset: start + bestSentinelIdx,
			reason: "not_implemented",
			marker: bestSentinel,
		};
	}

	// 1c. TODO / FIXME comments, language-aware.
	const id = (input.languageId || "").toLowerCase();
	const regexes = TODO_COMMENT_BY_LANGUAGE[id] ?? DEFAULT_TODO_REGEXES;
	let bestRegexIdx = -1;
	let bestRegexMatch = "";
	let bestRegexReason: PredictNextEditOutput["reason"] = "todo_comment";
	for (const re of regexes) {
		const match = re.exec(window);
		if (match && (bestRegexIdx === -1 || match.index < bestRegexIdx)) {
			bestRegexIdx = match.index;
			bestRegexMatch = match[0];
			// Python `pass` is a separate reason for downstream telemetry.
			bestRegexReason = /^\s*pass\s*$/.test(match[0]) ? "pass_keyword" : "todo_comment";
		}
	}
	if (bestRegexIdx >= 0) {
		return {
			offset: start + bestRegexIdx,
			reason: bestRegexReason,
			marker: bestRegexMatch.trim(),
		};
	}

	// 2. Start of the next non-empty line below the cursor. We skip the
	// trailing portion of the current line because that's the line we just
	// completed onto.
	const nextLine = findNextNonEmptyLineStart(text, start);
	if (nextLine !== undefined) {
		return { offset: nextLine, reason: "next_nonempty_line", marker: "" };
	}

	// 3. End of document.
	return { offset: text.length, reason: "end_of_document", marker: "" };
}

/**
 * Walk forwards from `from` and return the offset of the first non-empty line
 * strictly below the line containing `from`. Returns `undefined` when no such
 * line exists.
 */
export function findNextNonEmptyLineStart(text: string, from: number): number | undefined {
	const len = text.length;
	let i = Math.max(0, Math.min(len, from));
	// Skip to the end of the current line first.
	while (i < len && text.charCodeAt(i) !== 10 /* \n */) i++;
	while (i < len) {
		// Skip past the newline character.
		if (text.charCodeAt(i) === 10) i++;
		// Find the next newline (or end) to bound this candidate line.
		let lineEnd = i;
		while (lineEnd < len && text.charCodeAt(lineEnd) !== 10) lineEnd++;
		const candidate = text.slice(i, lineEnd);
		if (candidate.trim().length > 0) {
			// Position at the first non-whitespace character of the candidate.
			let lead = 0;
			while (lead < candidate.length && /\s/.test(candidate[lead])) lead++;
			return i + lead;
		}
		i = lineEnd;
	}
	return undefined;
}

/**
 * Slice a single word from the start of `text`. A "word" is the leading run
 * of non-whitespace characters PLUS any trailing whitespace up to (but not
 * including) the next non-whitespace character. This matches the VS Code
 * `cursorWordRight` semantics — perfect for "accept one word at a time".
 *
 * Exposed for the partial-word-accept state machine.
 */
export function sliceFirstWord(text: string): { word: string; rest: string } {
	if (text.length === 0) return { word: "", rest: "" };
	let i = 0;
	// Leading whitespace becomes part of the slice — accepting "  foo" should
	// leave the cursor before "foo" so the user can edit it.
	while (i < text.length && /\s/.test(text[i]) && text[i] !== "\n") i++;
	// If the first char was a newline, treat the newline as the whole "word".
	if (i === 0 && text[0] === "\n") {
		return { word: "\n", rest: text.slice(1) };
	}
	// Then take the run of word characters (or punctuation cluster).
	const isWordChar = (c: string): boolean => /[\w$]/.test(c);
	const firstNonWs = text[i];
	if (firstNonWs && isWordChar(firstNonWs)) {
		while (i < text.length && isWordChar(text[i])) i++;
	} else {
		// A punctuation cluster — take the run of non-word non-whitespace chars.
		while (i < text.length && !isWordChar(text[i]) && !/\s/.test(text[i])) i++;
	}
	return { word: text.slice(0, i), rest: text.slice(i) };
}

/**
 * If the model's completion text already exists verbatim on the next line of
 * the document, trim it from the completion. Prevents the Cursor "double-typed"
 * artefact where the suggestion repeats the line below.
 *
 * Exposed for unit tests.
 */
export function trimTrailingDuplicates(completion: string, suffixText: string): string {
	if (!completion) return completion;
	// Only fire when the completion ENDS at a line boundary — duplicating
	// mid-line content is rare and the trim would be over-aggressive.
	if (!completion.endsWith("\n") && completion.includes("\n")) {
		// Walk back from the end one line at a time and try the longest tail
		// that matches the start of suffixText.
		const lines = completion.split("\n");
		for (let take = lines.length; take > 0; take--) {
			const tail = lines.slice(-take).join("\n");
			if (suffixText.startsWith(tail)) {
				const keep = lines.slice(0, lines.length - take).join("\n");
				return keep;
			}
		}
		return completion;
	}
	// Multi-line completion ending in newline: check if the trailing N lines
	// already appear at the start of suffixText.
	const lines = completion.split("\n");
	for (let take = lines.length - 1; take > 0; take--) {
		const tail = `${lines.slice(-take - 1, -1).join("\n")}\n`;
		if (suffixText.startsWith(tail)) {
			const keep = lines.slice(0, lines.length - take - 1).join("\n");
			return keep.length > 0 ? `${keep}\n` : "";
		}
	}
	return completion;
}
