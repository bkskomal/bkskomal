/*
 * R2-E predictive-edit — once the user pauses on a line after editing, ask
 * the model "what's the next likely edit in this file" and surface it as a
 * ghost-text decoration appended to the current line. Accept on Tab via the
 * `oati.acceptPrediction` command, which is gated by a context key so the
 * binding only steals Tab when a prediction is actually showing.
 *
 * This feature is off by default (`oati.predictiveEdit.enabled`) — it's
 * inherently chatty (one provider call per pause) and not every user wants
 * the editor whispering suggestions at them.
 *
 * Performance budget:
 *   - At most one in-flight request at any time. New keystrokes hard-cancel.
 *   - 800ms idle threshold before we even consider asking.
 *   - Tracks the last few document changes so the prompt has local context
 *     without re-sending the whole file each time.
 */

import type { ConversationMessage } from "@oati/shared";
import * as vscode from "vscode";
import type { ProviderManager } from "./provider-manager";
import type { SettingsStore } from "./settings-store";

export interface PredictiveEditDeps {
	readonly settings: SettingsStore;
	readonly providerManager: ProviderManager;
	readonly log?: vscode.OutputChannel;
}

const PAUSE_MS = 800;
const MAX_RECENT_CHANGES = 6;
const MAX_PREDICTION_CHARS = 80;
const CONTEXT_KEY = "oati.predictionVisible";

interface RecentChange {
	readonly range: string; // serialized for the prompt only
	readonly text: string;
}

export function registerPredictiveEdit(
	context: vscode.ExtensionContext,
	deps: PredictiveEditDeps,
): vscode.Disposable {
	const ghostDecoration = vscode.window.createTextEditorDecorationType({
		after: {
			color: new vscode.ThemeColor("editorGhostText.foreground"),
			fontStyle: "italic",
		},
		rangeBehavior: vscode.DecorationRangeBehavior.ClosedClosed,
	});

	const recentChanges: RecentChange[] = [];
	let pauseTimer: NodeJS.Timeout | undefined;
	let inflightAbort: AbortController | undefined;
	let currentPrediction:
		| { editor: vscode.TextEditor; position: vscode.Position; text: string }
		| undefined;

	const clearPrediction = () => {
		currentPrediction = undefined;
		for (const ed of vscode.window.visibleTextEditors) {
			ed.setDecorations(ghostDecoration, []);
		}
		void vscode.commands.executeCommand("setContext", CONTEXT_KEY, false);
	};

	const cancelInflight = () => {
		inflightAbort?.abort();
		inflightAbort = undefined;
	};

	// Track recent text changes so the next-edit prompt has continuity. We
	// keep just the tail of the change stream — the model doesn't need the
	// full file history, just "what was the user last fiddling with".
	const changeSub = vscode.workspace.onDidChangeTextDocument((ev) => {
		if (!isEnabled()) return;
		// Any keystroke kills a pending pause and any visible prediction —
		// the user's intent has moved on.
		if (pauseTimer) {
			clearTimeout(pauseTimer);
			pauseTimer = undefined;
		}
		cancelInflight();
		clearPrediction();

		for (const change of ev.contentChanges) {
			recentChanges.push({
				range: `${change.range.start.line}:${change.range.start.character}-${change.range.end.line}:${change.range.end.character}`,
				text: change.text,
			});
			if (recentChanges.length > MAX_RECENT_CHANGES) recentChanges.shift();
		}
	});

	const selectionSub = vscode.window.onDidChangeTextEditorSelection((ev) => {
		if (!isEnabled()) return;
		if (recentChanges.length === 0) return; // wait for a real edit first
		if (pauseTimer) clearTimeout(pauseTimer);
		cancelInflight();
		clearPrediction();
		pauseTimer = setTimeout(() => {
			void runPrediction(ev.textEditor);
		}, PAUSE_MS);
	});

	const runPrediction = async (editor: vscode.TextEditor): Promise<void> => {
		if (!isEnabled()) return;
		const abort = new AbortController();
		inflightAbort = abort;
		try {
			const suggestion = await fetchSuggestion(deps, editor, recentChanges, abort.signal);
			if (abort.signal.aborted || !suggestion) return;
			showPrediction(editor, suggestion, ghostDecoration);
			currentPrediction = {
				editor,
				position: editor.selection.active,
				text: suggestion,
			};
			void vscode.commands.executeCommand("setContext", CONTEXT_KEY, true);
		} catch (err) {
			deps.log?.appendLine(
				`[predictive-edit] failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		} finally {
			if (inflightAbort === abort) inflightAbort = undefined;
		}
	};

	const acceptCmd = vscode.commands.registerCommand("oati.acceptPrediction", async () => {
		const p = currentPrediction;
		if (!p) return;
		// Insert at the cached position, then clear. If the user moved the
		// cursor between prediction-show and Tab, fall back to current cursor
		// — better than silently dropping the suggestion.
		const insertAt = p.editor.selection.active ?? p.position;
		await p.editor.edit((eb) => {
			eb.insert(insertAt, p.text);
		});
		clearPrediction();
	});

	// When the active editor changes, drop any lingering ghost-text so the
	// suggestion doesn't appear "stuck" in a now-background tab.
	const focusSub = vscode.window.onDidChangeActiveTextEditor(() => {
		cancelInflight();
		clearPrediction();
	});

	const disposable = vscode.Disposable.from(
		changeSub,
		selectionSub,
		focusSub,
		acceptCmd,
		{ dispose: () => ghostDecoration.dispose() },
		{
			dispose: () => {
				if (pauseTimer) clearTimeout(pauseTimer);
				cancelInflight();
			},
		},
	);
	context.subscriptions.push(disposable);
	return disposable;
}

function isEnabled(): boolean {
	const cfg = vscode.workspace.getConfiguration("oati.predictiveEdit");
	return cfg.get<boolean>("enabled", false);
}

function showPrediction(
	editor: vscode.TextEditor,
	text: string,
	decoration: vscode.TextEditorDecorationType,
): void {
	const pos = editor.selection.active;
	const range = new vscode.Range(pos, pos);
	editor.setDecorations(decoration, [
		{
			range,
			renderOptions: {
				after: {
					contentText: text,
				},
			},
		},
	]);
}

async function fetchSuggestion(
	deps: PredictiveEditDeps,
	editor: vscode.TextEditor,
	recentChanges: readonly RecentChange[],
	signal: AbortSignal,
): Promise<string | undefined> {
	const config = deps.settings.config;
	const modelId = deps.providerManager.resolveActiveModelId(config);
	if (!modelId) return undefined;
	const providerId =
		config.modes.find((m) => m.id === config.activeModeId)?.providerId ?? config.activeProviderId;
	const provider = deps.providerManager.registry.get(providerId);
	if (!provider) return undefined;

	const doc = editor.document;
	const pos = editor.selection.active;
	const before = doc.getText(new vscode.Range(new vscode.Position(0, 0), pos));
	const after = doc.getText(new vscode.Range(pos, doc.positionAt(doc.getText().length)));
	// Trim window — keep the prompt cheap. The model only needs nearby
	// context to predict the next-keystroke-sized edit.
	const beforeTail = before.slice(-1500);
	const afterHead = after.slice(0, 500);

	const changesSummary = recentChanges
		.map((c) => `- range ${c.range}: ${JSON.stringify(c.text)}`)
		.join("\n");

	const userPrompt = [
		"You are predicting the user's NEXT edit in this file given recent changes.",
		"Reply with ONLY the literal characters to insert at the cursor position.",
		"No prose, no markdown, no code fences. Empty reply if no useful prediction.",
		"",
		`Language: ${doc.languageId}`,
		"",
		"Recent changes (most recent last):",
		changesSummary || "(none)",
		"",
		"Code before cursor:",
		"```",
		beforeTail,
		"```",
		"",
		"Code after cursor:",
		"```",
		afterHead,
		"```",
	].join("\n");

	const messages: ConversationMessage[] = [
		{ role: "user", parts: [{ kind: "text", text: userPrompt }] },
	];

	let out = "";
	const stream = provider.stream({
		messages,
		modelId,
		systemPrompt:
			"You predict the user's next keystrokes in a code file. Reply with the literal insertion only.",
		temperature: 0.1,
	});
	for await (const ev of stream) {
		if (signal.aborted) return undefined;
		if (ev.type === "text_delta") {
			out += ev.text;
			if (out.length > MAX_PREDICTION_CHARS * 2) break; // overshoot guard
		} else if (ev.type === "error") {
			return undefined;
		} else if (ev.type === "message_end") {
			break;
		}
	}
	const cleaned = out
		.replace(/^```[a-zA-Z0-9_+-]*\r?\n?/, "")
		.replace(/\r?\n?```$/, "")
		.trim();
	if (!cleaned) return undefined;
	// Cap the suggestion size so the ghost-text doesn't run off the screen.
	return cleaned.length > MAX_PREDICTION_CHARS ? cleaned.slice(0, MAX_PREDICTION_CHARS) : cleaned;
}
