import * as path from "node:path";
import type { ConversationMessage, HostContext, ProviderSpec } from "@oati/shared";
import * as vscode from "vscode";
// R6-D: streaming diff partials.
import { type StreamingDiffEvent, StreamingDiffParser } from "./streaming-diff";

/**
 * Multi-file Composer — R2-A.
 *
 * Drives a one-shot multi-file generation against the active provider. The
 * model is asked (via a tailored system prompt) to emit a strict JSON envelope
 * of `{ files: [{ path, content }] }`. The composer parses that envelope,
 * loads each pre-image from disk (or treats it as empty for new files), and
 * surfaces per-file diffs to the webview via host callbacks.
 *
 * Per-file accept/reject is tracked in `proposed`; `commit()` writes every
 * accepted file inside a single `vscode.WorkspaceEdit` so undo is one stroke.
 *
 * Intentionally does NOT reuse the full Agent/Conductor loop — composers don't
 * call tools, they emit a JSON blob — so we stream directly from the provider.
 */

export interface ProposedFile {
	readonly path: string;
	readonly before: string;
	readonly after: string;
	readonly language?: string;
	accepted: boolean;
	rejected: boolean;
}

export interface ComposerDeps {
	readonly host: HostContext;
	readonly provider: ProviderSpec;
	readonly modelId: string;
	/**
	 * Emit a preview for a single proposed file. Called once per file as the
	 * envelope is parsed and the pre-image is loaded.
	 */
	emitFilePreview(file: {
		path: string;
		before: string;
		after: string;
		language?: string;
	}): void;
	/** Emit terminal status (ok / cancelled / error). */
	emitDone(status: "ok" | "cancelled" | "error", message?: string): void;
	/** Emit the list of paths that were written during commit. */
	emitApplied(paths: readonly string[]): void;
	// R6-D: optional sink for streaming partial previews. When supplied, the
	// composer pipes each chunk of the provider stream through a
	// `StreamingDiffParser` and fans the incremental events out here.
	emitStreamingPartial?(ev: StreamingDiffEvent): void;
	readonly log?: vscode.OutputChannel;
}

/** Built once, exported so tests can pin the wording. */
export const COMPOSER_SYSTEM_PROMPT = [
	"You are a multi-file code-generation assistant.",
	"",
	"The user will describe a high-level task. Respond with a SINGLE JSON object",
	"and nothing else (no prose, no markdown fences, no commentary). Schema:",
	"",
	'  { "files": [ { "path": "relative/path.ext", "content": "<full file body>" }, ... ] }',
	"",
	"Rules:",
	'- "path" is workspace-relative; use forward slashes; never start with "/" or "..".',
	'- "content" is the COMPLETE final file body, not a diff or patch.',
	"- Include every file the task requires (source, tests, types, config).",
	"- Do not include files you did not change.",
	"- Output ONLY the JSON object. No leading/trailing text, no code fence.",
].join("\n");

export class Composer {
	/** Proposed files keyed by workspace-relative path. */
	private readonly proposed = new Map<string, ProposedFile>();
	private running = false;
	private currentAbort: AbortController | undefined;

	constructor(private readonly deps: ComposerDeps) {}

	/** Snapshot of currently proposed files (for tests / introspection). */
	getFiles(): readonly ProposedFile[] {
		return [...this.proposed.values()];
	}

	/**
	 * Drive a one-shot generation. Resolves once the envelope has been parsed
	 * and every preview emitted, OR a terminal error has been reported. The
	 * caller is then expected to wait for per-file accept/reject RPCs and
	 * eventually call `commit()` or `discard()`.
	 */
	async run(
		instruction: string,
		contextFiles: readonly string[] = [],
		signal?: AbortSignal,
	): Promise<void> {
		if (this.running) {
			this.deps.emitDone("error", "Composer is already running.");
			return;
		}
		this.running = true;
		this.proposed.clear();
		this.currentAbort = new AbortController();
		const composedSignal = mergeSignals(signal, this.currentAbort.signal);

		try {
			const userPrompt = await this.buildUserPrompt(instruction, contextFiles);
			let envelope: ComposerEnvelope | undefined;
			let lastError: string | undefined;
			// One retry after a soft failure: the retry message includes the parse
			// error so the model can self-correct on schema misses.
			for (let attempt = 0; attempt < 2 && !envelope; attempt++) {
				if (composedSignal.aborted) {
					this.deps.emitDone("cancelled");
					return;
				}
				const messages: ConversationMessage[] = [
					{ role: "user", parts: [{ kind: "text", text: userPrompt }] },
				];
				if (attempt === 1 && lastError) {
					messages.push({
						role: "user",
						parts: [
							{
								kind: "text",
								text: [
									"Your previous reply could not be parsed:",
									lastError,
									"",
									"Reply again with ONLY the JSON object described in the system prompt.",
								].join("\n"),
							},
						],
					});
				}
				const raw = await this.streamOnce(messages, composedSignal);
				const parsed = parseComposerEnvelope(raw);
				if (parsed.ok) {
					envelope = parsed.value;
				} else {
					lastError = parsed.error;
					this.deps.log?.appendLine(`[composer] parse failed (attempt ${attempt + 1}): ${parsed.error}`);
				}
			}

			if (!envelope) {
				this.deps.emitDone(
					"error",
					`Model did not return a valid composer envelope after one retry: ${lastError ?? "unknown error"}`,
				);
				return;
			}

			if (envelope.files.length === 0) {
				this.deps.emitDone("ok", "No files were proposed.");
				return;
			}

			for (const f of envelope.files) {
				const rel = normalizeRelPath(f.path);
				if (!rel) {
					this.deps.log?.appendLine(`[composer] skipping invalid path: ${f.path}`);
					continue;
				}
				const before = await safeReadFile(this.deps.host, rel);
				const language = guessLanguage(rel);
				const proposed: ProposedFile = {
					path: rel,
					before,
					after: f.content,
					accepted: false,
					rejected: false,
					...(language ? { language } : {}),
				};
				this.proposed.set(rel, proposed);
				this.deps.emitFilePreview({
					path: rel,
					before,
					after: f.content,
					...(language ? { language } : {}),
				});
			}
			this.deps.emitDone("ok");
		} catch (err) {
			if (composedSignal.aborted) {
				this.deps.emitDone("cancelled");
			} else {
				const message = err instanceof Error ? err.message : String(err);
				this.deps.log?.appendLine(`[composer] run failed: ${message}`);
				this.deps.emitDone("error", message);
			}
		} finally {
			this.running = false;
			this.currentAbort = undefined;
		}
	}

	acceptFile(p: string): void {
		const f = this.proposed.get(p);
		if (!f) return;
		f.accepted = true;
		f.rejected = false;
	}

	rejectFile(p: string): void {
		const f = this.proposed.get(p);
		if (!f) return;
		f.rejected = true;
		f.accepted = false;
	}

	acceptAll(): void {
		for (const f of this.proposed.values()) {
			if (!f.rejected) f.accepted = true;
		}
	}

	/** Cancel any in-flight provider stream and drop proposed state. */
	discard(): void {
		this.currentAbort?.abort();
		this.proposed.clear();
	}

	/**
	 * Write every accepted file using a single `vscode.WorkspaceEdit` so VS
	 * Code groups them into one undo. Files outside the workspace are skipped
	 * with a log line; new files are created in-place.
	 */
	async commit(): Promise<readonly string[]> {
		const accepted = [...this.proposed.values()].filter((f) => f.accepted && !f.rejected);
		if (accepted.length === 0) {
			this.deps.emitApplied([]);
			return [];
		}
		const workspaceRoot = this.deps.host.workspaceRoot();
		if (!workspaceRoot) {
			this.deps.emitDone("error", "No workspace folder open — cannot apply composer changes.");
			return [];
		}
		const edit = new vscode.WorkspaceEdit();
		const written: string[] = [];
		for (const f of accepted) {
			const abs = path.isAbsolute(f.path) ? f.path : path.join(workspaceRoot, f.path);
			const uri = vscode.Uri.file(abs);
			const exists = await fileExists(uri);
			if (!exists) {
				edit.createFile(uri, { ignoreIfExists: true, overwrite: false });
			}
			const wholeRange = await wholeDocumentRange(uri, exists);
			edit.replace(uri, wholeRange, f.after);
			written.push(f.path);
		}
		const ok = await vscode.workspace.applyEdit(edit);
		if (!ok) {
			this.deps.emitDone("error", "VS Code refused to apply the composer edit.");
			return [];
		}
		this.deps.emitApplied(written);
		this.proposed.clear();
		return written;
	}

	private async buildUserPrompt(
		instruction: string,
		contextFiles: readonly string[],
	): Promise<string> {
		const parts: string[] = [];
		parts.push(`Task:\n${instruction}`);
		if (contextFiles.length > 0) {
			parts.push("");
			parts.push("Context files (for reference; you may modify or leave them alone):");
			for (const rel of contextFiles) {
				const content = await safeReadFile(this.deps.host, rel);
				const lang = guessLanguage(rel) ?? "";
				parts.push("");
				parts.push(`--- ${rel} ---`);
				parts.push(`\`\`\`${lang}\n${content}\n\`\`\``);
			}
		}
		return parts.join("\n");
	}

	private async streamOnce(
		messages: readonly ConversationMessage[],
		signal: AbortSignal,
	): Promise<string> {
		let out = "";
		// R6-D: streaming partial preview. Each text_delta is also fed to a
		// StreamingDiffParser so the webview can render placeholders for files
		// the model is still writing.
		const parser = this.deps.emitStreamingPartial ? new StreamingDiffParser() : undefined;
		const unsub = parser?.on((pev) => this.deps.emitStreamingPartial?.(pev));
		try {
			for await (const ev of this.deps.provider.stream({
				messages,
				modelId: this.deps.modelId,
				systemPrompt: COMPOSER_SYSTEM_PROMPT,
				temperature: 0.2,
				signal,
			})) {
				if (ev.type === "text_delta") {
					out += ev.text;
					parser?.feed(ev.text);
				} else if (ev.type === "error") throw new Error(ev.message);
				else if (ev.type === "message_end") break;
			}
			parser?.end();
		} finally {
			unsub?.();
		}
		return out;
	}
}

interface ComposerEnvelope {
	readonly files: readonly { readonly path: string; readonly content: string }[];
}

/**
 * Parse the composer envelope strictly. Accepts either a bare JSON object or
 * one wrapped in a ```json fence (some providers can't help themselves). On
 * failure returns a friendly error string the caller can show the user.
 */
export function parseComposerEnvelope(
	raw: string,
): { ok: true; value: ComposerEnvelope } | { ok: false; error: string } {
	const trimmed = raw.trim();
	if (trimmed.length === 0) return { ok: false, error: "Empty response from model" };
	let jsonText = trimmed;
	const fence = /^```(?:json)?\s*\r?\n([\s\S]*?)\r?\n```$/m.exec(trimmed);
	if (fence) jsonText = fence[1].trim();
	// Some models prefix prose. Try to locate the first { and last } as a
	// last-ditch effort before bailing.
	if (!jsonText.startsWith("{")) {
		const first = jsonText.indexOf("{");
		const last = jsonText.lastIndexOf("}");
		if (first >= 0 && last > first) jsonText = jsonText.slice(first, last + 1);
	}
	let obj: unknown;
	try {
		obj = JSON.parse(jsonText);
	} catch (err) {
		return {
			ok: false,
			error: `JSON parse error: ${err instanceof Error ? err.message : String(err)}`,
		};
	}
	if (!obj || typeof obj !== "object") {
		return { ok: false, error: "Top-level value is not an object" };
	}
	const files = (obj as { files?: unknown }).files;
	if (!Array.isArray(files)) {
		return { ok: false, error: 'Missing "files" array' };
	}
	const out: { path: string; content: string }[] = [];
	for (let i = 0; i < files.length; i++) {
		const entry = files[i];
		if (!entry || typeof entry !== "object") {
			return { ok: false, error: `files[${i}] is not an object` };
		}
		const p = (entry as { path?: unknown }).path;
		const c = (entry as { content?: unknown }).content;
		if (typeof p !== "string" || p.length === 0) {
			return { ok: false, error: `files[${i}].path must be a non-empty string` };
		}
		if (typeof c !== "string") {
			return { ok: false, error: `files[${i}].content must be a string` };
		}
		out.push({ path: p, content: c });
	}
	return { ok: true, value: { files: out } };
}

/** Normalize and validate a workspace-relative path. Returns "" for rejected. */
function normalizeRelPath(p: string): string {
	let rel = p.replace(/\\/g, "/").trim();
	if (rel.startsWith("/")) rel = rel.slice(1);
	if (rel.length === 0) return "";
	// Block traversal — the model should never return ".." segments.
	const segs = rel.split("/");
	for (const s of segs) {
		if (s === ".." || s === "") return "";
	}
	return rel;
}

async function safeReadFile(host: HostContext, rel: string): Promise<string> {
	try {
		if (!(await host.fileExists(rel))) return "";
		return await host.readFile(rel);
	} catch {
		return "";
	}
}

async function fileExists(uri: vscode.Uri): Promise<boolean> {
	try {
		await vscode.workspace.fs.stat(uri);
		return true;
	} catch {
		return false;
	}
}

async function wholeDocumentRange(uri: vscode.Uri, exists: boolean): Promise<vscode.Range> {
	if (!exists) {
		return new vscode.Range(new vscode.Position(0, 0), new vscode.Position(0, 0));
	}
	try {
		const doc = await vscode.workspace.openTextDocument(uri);
		return new vscode.Range(new vscode.Position(0, 0), new vscode.Position(doc.lineCount, 0));
	} catch {
		return new vscode.Range(new vscode.Position(0, 0), new vscode.Position(0, 0));
	}
}

function guessLanguage(name: string): string | undefined {
	const ext = name.split(".").pop()?.toLowerCase();
	if (!ext) return undefined;
	const map: Record<string, string> = {
		ts: "typescript",
		tsx: "tsx",
		js: "javascript",
		jsx: "jsx",
		py: "python",
		rb: "ruby",
		go: "go",
		rs: "rust",
		java: "java",
		kt: "kotlin",
		cs: "csharp",
		cpp: "cpp",
		c: "c",
		h: "c",
		hpp: "cpp",
		md: "markdown",
		json: "json",
		yml: "yaml",
		yaml: "yaml",
		toml: "toml",
		sh: "bash",
		ps1: "powershell",
		html: "html",
		css: "css",
		scss: "scss",
		sql: "sql",
		xml: "xml",
	};
	return map[ext];
}

// R7-C bug fix: the previous implementation never removed its abort listeners
// from `a` (the caller-supplied signal). If the caller reused the same
// AbortController across many composer runs (or the parent signal lived for
// the lifetime of the panel), each run leaked one listener on `a`. Now we
// detach both listeners once either signal fires, so the merged signal is
// safe to use in long-lived processes.
function mergeSignals(a: AbortSignal | undefined, b: AbortSignal): AbortSignal {
	if (!a) return b;
	if (a.aborted) return a;
	if (b.aborted) return b;
	const ctrl = new AbortController();
	const cleanup = (): void => {
		a.removeEventListener("abort", onA);
		b.removeEventListener("abort", onB);
	};
	const onA = () => {
		cleanup();
		ctrl.abort();
	};
	const onB = () => {
		cleanup();
		ctrl.abort();
	};
	a.addEventListener("abort", onA, { once: true });
	b.addEventListener("abort", onB, { once: true });
	return ctrl.signal;
}
