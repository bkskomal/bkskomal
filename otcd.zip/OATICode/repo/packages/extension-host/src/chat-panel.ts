import { promises as fsp } from "node:fs";
import * as nodePath from "node:path";
import { type Conductor, executePlan, planRequest, runWithTests } from "@oati/agent-core";
import { Bus, type HostBus } from "@oati/rpc";
import {
	type ApprovalRequest,
	type ConversationMessage,
	type CustomCommandSummary,
	type DiffPreview,
	type HostContext,
	type HostToWebview,
	type MessagePart,
	type RpcEnvelope,
	type SecretMatchSummary,
	type ToolSpec,
	type UiMessage,
	type WebviewToHost,
	buildModelPromptAddendum,
	conversationToUiMessages,
} from "@oati/shared";
import * as vscode from "vscode";
import { loadFacts } from "./agent-facts";
import { AuditLog, estimateTokens, hashArgs, nowIso, shortHash } from "./audit-log";
import { AutoRevertGuard, newFailures } from "./auto-revert";
import { Budget } from "./budget";
// R5-E: per-model budget + auto-revert safety net.
import { PerModelBudget } from "./budget";
import type { CodebaseIndexManager } from "./codebase-index-manager";
import { Composer } from "./composer";
// R8-C: pluggable context-provider registry.
import {
	listContextProviders,
	loadUserProviders,
	registerBuiltinContextProviders,
} from "./context-providers";
// R3-D: conversation branching helper.
import { forkConversation } from "./conversation-branching";
import {
	type CustomSlashCommand,
	applyCustomCommandTemplate,
	loadCustomSlashCommands,
} from "./custom-slash-commands";
import { DiagnosticsFeedbackTracker, formatDiagnosticsAsSystemNote } from "./diagnostics-feedback";
// R3-E: import for /from-issue workflow (appended; do not reorder).
import { startFromIssue } from "./gh-workflow";
import { compactHistory, makeProviderSummarizer } from "./history-compaction";
import { formatSanitizeNote, sanitizeHistory } from "./history-sanitizer";
import { HookRunner } from "./hook-runner";
// R8-E: hook system v2 + skills loader.
import {
	type HookV2Entry,
	type HookEvent as HookV2Event,
	HookV2Runner,
	loadHooksV2,
} from "./hooks-v2";
// R5-B: rules + knowledge base helpers (append-only import).
import { type KnowledgeStore, listKnowledgeDocs } from "./knowledge";
// R3-B: model router
import {
	ModelRouter,
	type RouteDecision,
	looksLikeRateLimit,
	parseRouteOverride,
} from "./model-router";
// R4-E: per-turn performance HUD collector.
import { PerfCollector } from "./perf-collector";
// R5-D: agent personas + recipes — appended imports; do not reorder.
import { assemblePersonaPrelude, getPersona, listPersonas } from "./personas";
import {
	EMPTY_POLICY,
	type Policy,
	filterModes,
	isModeAllowed,
	isModelAllowed,
	isProviderAllowed,
	isToolAllowed,
	loadPolicy,
} from "./policy";
// R3-C: PR review handler — appended import; do not reorder.
import { reviewPullRequest } from "./pr-review";
import {
	PLAN_NUDGE,
	type PlanMode,
	TDD_NUDGE,
	type TddMode,
	shouldInjectPlanNudge,
	shouldInjectTddNudge,
} from "./prelude-nudges";
import { loadGlobalMemory, loadProjectMemory } from "./project-memory";
import type { ProviderManager } from "./provider-manager";
import { listRecipes, runRecipe } from "./recipes";
import { assembleRulesPrelude, hasGlobalRules, loadRules } from "./rules";
import { type SecretMatch, redactSecrets, summarizeMatches } from "./secret-scanner";
import type { SessionStore } from "./session-store";
import type { SettingsStore } from "./settings-store";
import { type Skill, assembleSkillsPrelude, loadSkills, matchSkills } from "./skills";
import { onWorkspaceChanged, resolvePrimaryWorkspacePath, resolveWorkspaceInfo } from "./workspace";
import { formatChangesAsSystemNote } from "./workspace-change-tracker";

// 2026-05-30: Tools that mutate workspace state. After AUTO_VERIFY_THRESHOLD
// of these in a single turn, we auto-run the project's test/build command
// so compile errors surface to the user (and the model, on its next turn)
// instead of hiding behind a confident "Done" claim.
const MUTATING_TOOL_NAMES = new Set([
	"write_file",
	"batch_file_edit",
	"edit_notebook_cell",
	"insert_notebook_cell",
	"delete_notebook_cell",
	"smart_apply_patch",
	"multi_cursor_edit",
]);
const AUTO_VERIFY_THRESHOLD = 3;

/**
 * 2026-06-05: Resolve the webview-ui dist directory across both dev and
 * packaged modes.
 *
 * In the monorepo, `extension-host` is a sibling of `webview-ui`, so the
 * built webview assets live at `<extensionUri>/../webview-ui/dist/`.
 *
 * In a packaged VSIX there is no `../webview-ui/` — the package script
 * copies the webview's dist into the extension's own `dist/webview/` folder
 * so everything ships under one extension root. We probe the packaged
 * location first and fall back to the dev location.
 *
 * vscode.workspace.fs is async so we use Node's `fs.existsSync` here; the
 * extension already runs in a Node host and the check is cheap.
 */
function resolveWebviewDistDir(extensionUri: vscode.Uri): vscode.Uri {
	const packaged = vscode.Uri.joinPath(extensionUri, "dist", "webview");
	try {
		// eslint-disable-next-line @typescript-eslint/no-require-imports
		const fs = require("node:fs") as typeof import("node:fs");
		if (fs.existsSync(packaged.fsPath)) return packaged;
	} catch {
		/* fall through to dev path */
	}
	return vscode.Uri.joinPath(extensionUri, "..", "webview-ui", "dist");
}

/**
 * Closing guidance appended to every mode's system prompt. Pushes the
 * model to end every turn with a clear "done / partial / blocked"
 * statement plus a concrete next step — the absence of this was the
 * single biggest dogfooding complaint: the agent would edit a file and
 * then say nothing, leaving the user to guess whether anything happened.
 *
 * Kept short and prescriptive so it doesn't bloat the context window.
 * Lives at the END of the system prompt because recency biases models
 * toward following the most recent instruction.
 */
const CONCLUSION_GUIDANCE = [
	"## When a tool fails or returns nothing useful",
	"",
	"Do NOT call the same tool with the same arguments a second time hoping for a different result — that is a wasted iteration. After ANY failed / empty tool result you must change at least ONE thing:",
	"",
	"- **Switch path style** — try the absolute path if the relative one failed (and vice versa). On Windows that means `E:\\\\Folder\\\\file.ts`, not `./file.ts`.",
	"- **Confirm the workspace** — call `get_workspace_context` to see what root your relative paths resolve against. If it's wrong, use absolute paths instead.",
	"- **Inspect the parent** — call `list_dir` on the folder you expected the file to be in. Maybe it's spelled differently, lives one folder up, or doesn't exist.",
	"- **Pick a different tool** — `exec` with `cat` / `Get-Content` / `Select-String` is a fine fallback when `read_file` keeps refusing. `exec` with `where` / `Get-Command` finds binaries `which` couldn't.",
	'- **Switch shells** — if a `bash` command failed and Git Bash might be missing, retry with `shell: "pwsh"`. The reverse also applies on Linux/macOS.',
	"",
	"After 2 failed attempts at the same goal, stop trying variants of the same call — write a short status to the user explaining what failed, what you've tried, and what you need from them to unblock.",
	"",
	"## How to conclude every turn",
	"",
	"After your last tool call (or after a non-tool answer), write a brief wrap-up of 1–3 short lines. The wrap-up MUST include:",
	"",
	"1. **A status verdict** — one of:",
	'   - "✅ Done — <one-line summary of what changed>."',
	'   - "⚠️ Partial — <what works>; <what is still missing>."',
	'   - "❌ Blocked — <reason>; <what you need from the user>."',
	'2. **One next step or question** — e.g. "Try the menu now — let me know if any item still doesn\'t navigate." or "Want me to add a regression test?" or "Should I commit this?"',
	"",
	"Skip the wrap-up only when the user asked a pure information question and there's nothing to verify. Never end a turn that touched files, ran commands, or invoked tools without a wrap-up — silence after a tool run is the worst UX failure.",
	"",
	"## When to ask the user a clarifying question",
	"",
	"You have an `ask_user` tool that pauses the turn and shows the user a chip-strip of 2–6 options. Use it ONLY when:",
	"",
	'1. The choice **meaningfully changes the outcome** — e.g. "create a new file or extend the existing one?" — not "2 spaces or 4?" when surrounding code makes the answer obvious.',
	"2. You **cannot reasonably infer** the right answer from the workspace, prior turns, or the task description.",
	"",
	"Rules of engagement:",
	"",
	"- **Bundle options** — one `ask_user` call with 3 choices is FAR better than 3 sequential yes/no calls. Always include all the realistic paths in a single call.",
	"- **Order by likelihood** — put your best guess FIRST so the cursor lands on the most likely option. The user reviews and clicks; the chip strip is shown in every mode.",
	"- **Don't stall** — if you can decide on your own, decide. `ask_user` is for genuine ambiguity, not for delegating thinking.",
	"- **Don't ask twice** — if the user already answered a similar question this session, don't re-ask.",
	'- **Keep labels short** — short imperative phrases ("Extract helper", "Inline", "Skip"); use the optional `description` field when the label alone is unclear.',
].join("\n");

export interface ChatPanelOptions {
	readonly extensionUri: vscode.Uri;
	readonly conductor: Conductor;
	readonly settings: SettingsStore;
	readonly providerManager: ProviderManager;
	readonly session: SessionStore;
	readonly sessionId: string;
	/** Which editor group to open the panel in. Defaults to ViewColumn.Beside. */
	readonly viewColumn?: vscode.ViewColumn;
	readonly log?: vscode.OutputChannel;
	/**
	 * Optional shared codebase-index manager. When present, the panel exposes
	 * a `reindex_codebase` RPC so the webview can drive a full rebuild and
	 * receive `indexing_progress` events back.
	 */
	readonly codebaseIndexManager?: CodebaseIndexManager;
	/**
	 * Optional host context + tool list. Used both by the multi-file composer
	 * for file I/O (R2-A) and to drive the test-driven loop helper after
	 * auto*-mode turns. When omitted the composer command is a no-op and the
	 * loop is silently skipped (no behavior change).
	 */
	readonly host?: HostContext;
	readonly tools?: readonly ToolSpec[];
	/** Called when this panel is disposed; lets extension.ts drop it from its map. */
	onDispose(sessionId: string): void;
	/** Called whenever this panel mutates the session index so the tree view can refresh. */
	onSessionIndexChanged(): void;
	/** Called when the user clicks "New chat" in this panel's header. */
	onRequestNewSession(): void;
	/** Called when this panel becomes the active editor so the tree can highlight its row. */
	onFocus(sessionId: string): void;
	/** Called whenever the panel's column changes so siblings can co-locate. */
	onColumnChanged?(column: vscode.ViewColumn): void;
	// R3-D: invoked after a successful `fork_conversation` so the extension can
	// open a fresh chat panel pointed at the new session id. When undefined,
	// the host still mints the session but the user has to open it manually
	// via the sessions tree.
	onForkConversation?(newSessionId: string): void;
	// R4-D: shared MCP marketplace manager (curated registry + install/toggle
	// orchestration). When omitted, the marketplace RPC arms reply with an
	// empty state so the webview can still render gracefully.
	readonly marketplace?: import("./mcp-marketplace").MarketplaceManager;
	// R5-B: shared knowledge store (one per workspace, indexes
	// `.oati/knowledge/`). Optional — when omitted the panel still loads
	// rules but RAG + the `/knowledge` slash command degrade gracefully.
	readonly knowledgeStore?: KnowledgeStore;
	// R5-C: shared cross-session conversation index. When present, the panel
	// answers `search_conversations_request` RPCs from the webview by
	// querying the same SessionIndex that SessionStore feeds on every save.
	// Optional so test harnesses and older callers stay valid.
	readonly sessionIndex?: import("./session-index").SessionIndex;
	// Shared BackgroundTaskRunner so the panel can render the tray of
	// currently-running tasks + offer a Stop button per task. When omitted,
	// the tray RPCs reply with an empty list (no-op).
	readonly backgroundTasks?: import("./background-tasks").BackgroundTaskRunner;
	// Optional handle to the shared SupervisorAgent so panel-side actions
	// (`supervisor_dismiss` / `supervisor_clear` / `supervisor_run_now`)
	// can reach it without a global singleton.
	readonly supervisor?: import("./supervisor").SupervisorAgent;
	// 2026-05-26: shared WorkspaceChangeTracker — drained at the start of
	// each user turn so the agent gets a "files changed externally since
	// last turn" heads-up. Optional: omit and external-change awareness
	// degrades to "off" (the agent works as before).
	readonly workspaceChangeTracker?: import("./workspace-change-tracker").WorkspaceChangeTracker;
}

export class ChatPanel {
	private readonly panel: vscode.WebviewPanel;
	private readonly bus: HostBus;
	private readonly pendingApprovals = new Map<string, (approved: boolean) => void>();
	private nextApprovalId = 1;
	// 2026-05-27: ask_user pending resolvers — same pattern as pendingApprovals.
	// The map value resolves the promise returned by `requestAskUser` when
	// the webview sends back an `ask_user_response` for matching id.
	private readonly pendingAskUser = new Map<
		string,
		(answer: import("@oati/shared").AskUserAnswer) => void
	>();
	private currentAbort: AbortController | undefined;
	private readonly disposables: vscode.Disposable[] = [];
	private history: ConversationMessage[] = [];
	private sessionId: string;
	private readonly hookRunner: HookRunner;
	// R8-E: v2 runner sits next to the R1 `hookRunner`. Both fire in parallel —
	// v2 is the source of truth for the 8-event surface (Notification /
	// SubagentStop / SessionEnd, etc.), while the legacy runner continues to
	// drive R1's narrower set so existing tests + saved configs keep working
	// through the migration window.
	private hookV2: HookV2Runner = new HookV2Runner([]);
	// R8-E: skills cache. Hydrated lazily on the first user turn (and on each
	// SessionStart) so authors can edit `.oati/skills/*.md` without
	// restarting. `undefined` means "not loaded yet"; an empty array means
	// "loaded and there are no skills here".
	private skills: readonly Skill[] | undefined;
	/**
	 * Tool name lookup keyed by call id, populated as the conductor emits `tool_call`
	 * events. Needed because the matching `tool_result` event carries only the call
	 * id, but PostToolUse hooks match on tool name.
	 */
	private readonly toolNamesByCallId = new Map<string, string>();
	/** Custom slash commands loaded from `.oati/commands/*.md` at session start. */
	private customCommands: readonly CustomSlashCommand[] = [];
	private nextSystemMessageId = 1;
	private readonly auditLog: AuditLog;
	// 2026-06-06: not `readonly` — rebuilt by the update_settings handler
	// when the user edits Budget Guardrails in Settings so the new caps
	// take effect on the very next dispatch.
	private budget: Budget;
	// R5-E: per-model budget + auto-revert guard.
	private readonly perModelBudget: PerModelBudget;
	private readonly autoRevert: AutoRevertGuard;
	private policy: Policy = EMPTY_POLICY;
	// Phase 5 (2026-05-25): currently-proposed PlanV2 awaiting user approval.
	// Set when /plan emits a proposal via planRequest; cleared when the user
	// dismisses or once executePlan completes. The plan_edit handler mutates
	// this in place when the user reorders / tweaks steps before executing.
	private currentPlanV2: import("@oati/shared").PlanV2 | undefined;
	private currentPlanAbort: AbortController | undefined;
	// 2026-05-29: session-window-scoped workflow modes. Plan mode = the model
	// drafts a numbered plan before tool calls; TDD mode = test-first by
	// default. Toggled via `/plan-mode` and `/tdd` slash commands.
	//
	// Default flipped to "auto" (2026-05-30) after multiple live-trace
	// regressions where the model produced incomplete multi-file scaffolds
	// without a plan. "auto" only injects the planning nudge when the
	// user's message is non-trivial (≥250 chars OR multi-step keywords),
	// so trivial prompts stay unimpacted. TDD stays off because its
	// overhead doesn't match every task.
	private planMode: PlanMode = "auto";
	private tddMode: TddMode = "off";
	// 2026-05-30: auto-verify counter. Counts how many MUTATING tool calls
	// (write_file, batch_file_edit, edit_notebook_cell, etc.) ran in the
	// current turn. When the turn ends cleanly and the count exceeds
	// AUTO_VERIFY_THRESHOLD, we run the project's test/build runner so the
	// model can react to compile errors before claiming Done. Reset to 0
	// at user-message receipt.
	private mutatingToolCallsThisTurn = 0;
	private autoVerifyRunning = false;
	/** Per-tool-call start timestamps, used to compute audit-log durationMs. */
	private readonly toolStartTimes = new Map<string, number>();
	/** Per-session resolvers for outstanding `secret_warning` confirmations. */
	private readonly pendingSecretConfirms = new Map<
		string,
		(choice: "send" | "redact" | "cancel") => void
	>();
	private nextSecretId = 1;
	/** R2-A: lazy-created multi-file composer for the current panel. */
	private composer: Composer | undefined;
	// R3-D: pinned UiMessage ids for the current session. Hydrated from
	// SessionStore on `ready` and mutated by `pin_message`.
	private pinnedIds = new Set<string>();
	// R3-D: in-flight side-by-side compare runs. Two AbortControllers (one per
	// side) so closing the modal can cancel both. Cleared on each request.
	private compareAborts: { left?: AbortController; right?: AbortController } = {};
	// R4-E: per-turn performance collector. Lives for the panel's lifetime so
	// the perf modal can pull recent turns across multiple sends.
	private readonly perf = new PerfCollector();
	// R4-E: the in-flight turn's msgId. Mirrors `userMessageIdForIndex` so the
	// summary lines up with the user bubble the webview rendered.
	private currentTurnMsgId: string | undefined;
	// 2026-05-26: diagnostics feedback. Constructed lazily on first turn when
	// host.diagnostics is available, then memoized for the panel lifetime so
	// each turn diffs against the prior turn's snapshot.
	private diagnosticsFeedback: DiagnosticsFeedbackTracker | undefined;
	// 2026-05-27: tracks paths the AGENT (not the developer) wrote in the
	// most recent turn. `/review @model` and `/review @auto` use this to
	// auto-target the model's own work without the user listing files.
	private lastModelWrittenPaths: readonly string[] = [];
	// 2026-05-27 Phase 4: cache for the `.oati/review-rules.md` file (or
	// whatever path the user configured). Invalidated by a per-path
	// FileSystemWatcher so edits take effect on the next /review without
	// a session restart. Map value is `null` to encode "file confirmed
	// missing" (so we don't re-attempt reads); a string is the cached
	// content.
	private customRulesCache = new Map<string, string | null>();
	private customRulesWatcher: vscode.FileSystemWatcher | undefined;
	private customRulesWatcherPath: string | undefined;
	// Tracks whether the webview has sent its `ready` handshake. Messages
	// posted before this is true can be dropped (window 'message' listener
	// isn't attached yet), so `openSettings()` defers when ready=false.
	private isReady = false;
	private pendingView: "chat" | "settings" | undefined;
	// Agent-managed todo list snapshot (Claude TodoWrite-style). Replaced
	// in full each time the agent calls `todo_write`; broadcast to the
	// webview and persisted next to the session history.
	private todos: readonly import("@oati/shared").UiTodoItem[] = [];
	// Subscription that keeps the webview in sync with the currently-open
	// project (multi-root + active-editor aware). Disposed in `dispose()`.
	private workspaceSub: vscode.Disposable | undefined;

	constructor(private readonly opts: ChatPanelOptions) {
		this.sessionId = opts.sessionId;
		opts.log?.appendLine(`[chat-panel] opening session ${this.sessionId}`);

		this.hookRunner = new HookRunner(opts.settings.config.hooks, {
			log: opts.log,
			stopTimeoutMs: 1000,
		});
		// R8-E: hydrate the v2 runner asynchronously — it reads
		// `.oati/hooks.json` from disk (with the legacy `RootConfig.hooks`
		// shim) and replaces the empty default. We don't await here so panel
		// creation stays sync; the first PreToolUse / UserPromptSubmit
		// invocation will see the empty runner if it races, which is
		// equivalent to "no v2 hooks configured" — safe fail-open.
		void this.initHooksV2();

		// Audit log + budget controller. Workspace-scoped; gracefully degrade to
		// /tmp-equivalent when there's no folder open (no .oati to write to).
		const workspacePath = getPrimaryWorkspacePath() ?? "";
		const cfg = opts.settings.config;
		this.auditLog = new AuditLog(workspacePath, { enabled: cfg.auditLog !== false });
		this.budget = new Budget(workspacePath, cfg.budget);
		// R5-E: per-model budget + auto-revert guard (workspace-scoped).
		this.perModelBudget = new PerModelBudget(workspacePath);
		this.autoRevert = new AutoRevertGuard({
			...(opts.log ? { log: opts.log } : {}),
			...(workspacePath ? { workspaceRoot: workspacePath } : {}),
		});
		// 2026-05-26: diagnostics feedback. Only meaningful when the host
		// exposes a diagnostics provider (VS Code does; headless test
		// hosts may not). When unavailable, runUserTurn's `if
		// (this.diagnosticsFeedback)` gate makes this a no-op.
		if (opts.host?.diagnostics) {
			this.diagnosticsFeedback = new DiagnosticsFeedbackTracker(opts.host.diagnostics);
		}

		this.panel = vscode.window.createWebviewPanel(
			"oati.chat",
			"OATI Code",
			opts.viewColumn ?? vscode.ViewColumn.Beside,
			{
				enableScripts: true,
				retainContextWhenHidden: true,
				localResourceRoots: [resolveWebviewDistDir(opts.extensionUri)],
			},
		);

		this.panel.webview.html = this.buildHtml();

		this.bus = new Bus<WebviewToHost, HostToWebview>({
			postMessage: (msg) => {
				this.panel.webview.postMessage(msg);
			},
			onMessage: (handler) => {
				const sub = this.panel.webview.onDidReceiveMessage((data: unknown) => {
					if (data && typeof data === "object" && (data as RpcEnvelope<WebviewToHost>).v === 1) {
						handler(data as RpcEnvelope<WebviewToHost>);
					}
				});
				return () => sub.dispose();
			},
		});

		this.bus.on((msg) => {
			void this.onMessage(msg);
		});

		const offConductor = this.opts.conductor.on((ev) => {
			// Forward to the webview first so streaming stays snappy; hook side-effects
			// run alongside it without blocking the UI.
			this.bus.send({ type: "agent_event", event: ev });
			// R4-E: feed the perf collector. Cheap, sync; safe to call before any
			// async hook work. `markTurnStart` is owned by runUserTurn so this is
			// a no-op when no turn is active.
			if (this.currentTurnMsgId !== undefined) {
				this.perf.recordEvent(this.sessionId, ev);
			}
			if (ev.type === "tool_call") {
				this.toolNamesByCallId.set(ev.call.id, ev.call.name);
				this.toolStartTimes.set(ev.call.id, Date.now());
				if (MUTATING_TOOL_NAMES.has(ev.call.name)) {
					this.mutatingToolCallsThisTurn += 1;
				}
			} else if (ev.type === "done" && ev.reason === "end") {
				const count = this.mutatingToolCallsThisTurn;
				if (count >= AUTO_VERIFY_THRESHOLD && !this.autoVerifyRunning) {
					void this.runAutoVerify(count);
				}
			} else if (ev.type === "tool_result") {
				const name = this.toolNamesByCallId.get(ev.result.id) ?? "";
				this.toolNamesByCallId.delete(ev.result.id);
				const startedAt = this.toolStartTimes.get(ev.result.id);
				this.toolStartTimes.delete(ev.result.id);
				const durationMs = startedAt ? Date.now() - startedAt : 0;
				// PostToolUse is fire-and-forget — we don't have a place to surface a
				// blocking verdict here without entangling with the conductor loop, so
				// the user's `blocking` flag is effectively ignored for now.
				void this.hookRunner.runPostToolUse(name, ev.result.output);
				// R8-E: v2 PostToolUse — fan the same event to the v2 runner so
				// `.oati/hooks.json` subscribers see the result + duration. Fire-
				// and-forget; PostToolUse can't unwind the result.
				void this.fireHookV2({
					kind: "PostToolUse",
					payload: {
						toolName: name,
						result: ev.result.output,
						isError: ev.result.isError,
						durationMs,
					},
				});
				// R8-E: SubagentStop — when the just-finished tool is one that
				// spawns a child agent loop, emit a SubagentStop with a
				// summary derived from the tool's result. This is the only
				// place we know the sub-agent run terminated (the conductor
				// doesn't fan a dedicated event for it).
				if (name === "spawn_agent" || name === "spawn_parallel_agents") {
					const status: "ok" | "error" = ev.result.isError ? "error" : "ok";
					const summary = (() => {
						const o = ev.result.output;
						if (typeof o === "string") return o.slice(0, 240);
						if (o && typeof o === "object") {
							const s = (o as { summary?: unknown }).summary;
							if (typeof s === "string") return s.slice(0, 240);
						}
						return undefined;
					})();
					void this.fireHookV2({
						kind: "SubagentStop",
						payload: {
							agentId: ev.result.id,
							status,
							...(summary ? { summary } : {}),
						},
					});
				}
				void this.recordToolAudit(name, ev.result.output, ev.result.isError, durationMs);
			} else if (ev.type === "usage") {
				void this.handleUsage(ev.inputTokens, ev.outputTokens);
			} else if (ev.type === "text_delta") {
				// Streaming deltas aren't audited individually — we record the
				// final assistant turn after the conductor returns.
			}
		});
		this.disposables.push({ dispose: offConductor });

		const offSettings = this.opts.settings.on(() => {
			void this.pushSettings();
		});
		this.disposables.push({ dispose: offSettings });

		this.disposables.push(
			this.panel.onDidDispose(() => {
				this.dispose();
			}),
		);

		this.disposables.push(
			this.panel.onDidChangeViewState((e) => {
				if (e.webviewPanel.active) this.opts.onFocus(this.sessionId);
				const col = e.webviewPanel.viewColumn;
				if (col !== undefined) this.opts.onColumnChanged?.(col);
			}),
		);

		// Keep the webview in sync with the currently-open project. Fires on
		// folder add/remove and on active-editor change (multi-root aware).
		this.workspaceSub = onWorkspaceChanged((info) => {
			if (!this.isReady) return;
			this.bus.send({ type: "workspace_info", ...(info ? { info } : {}) });
		});
		this.disposables.push(this.workspaceSub);

		// SessionStart hooks fire-and-forget so panel creation isn't gated on them.
		void this.hookRunner.runSessionStart();
		// R8-E: v2 SessionStart — observer-only for now (block:false makes no
		// sense for SessionStart). Runs after we kick off the legacy variant so
		// any user-configured `SessionStart` hook in `.oati/hooks.json` fires
		// alongside the legacy one without double-blocking.
		void this.fireHookV2({
			kind: "SessionStart",
			payload: { sessionId: this.sessionId },
		});
	}

	// R8-E: load `.oati/hooks.json` (with the legacy `RootConfig.hooks` shim)
	// and swap in the resulting v2 runner. Called once on construction and
	// again whenever settings change so re-saving the config picks up new
	// hooks without a panel reload.
	private async initHooksV2(): Promise<void> {
		const workspacePath = getPrimaryWorkspacePath();
		const { hooks, source, warning } = await loadHooksV2(
			workspacePath,
			this.opts.settings.config.hooks,
		);
		if (warning) this.opts.log?.appendLine(`[chat-panel] R8-E hooks-v2: ${warning}`);
		this.hookV2 = new HookV2Runner(hooks, {
			...(this.opts.log ? { log: this.opts.log } : {}),
			stopTimeoutMs: 1000,
		});
		this.opts.log?.appendLine(
			`[chat-panel] R8-E hooks-v2 loaded ${hooks.length} entr${hooks.length === 1 ? "y" : "ies"} (source=${source})`,
		);
	}

	// R8-E: convenience wrapper — fires the v2 event and returns the verdict.
	// Wrapped so the call sites in this file don't need to import the union
	// shape themselves.
	private async fireHookV2<E extends HookV2Event>(event: E) {
		return this.hookV2.fire(event);
	}

	// R8-E: ensure `this.skills` is hydrated. Returns the cached array after
	// the first call.
	private async ensureSkills(): Promise<readonly Skill[]> {
		if (this.skills) return this.skills;
		try {
			const workspacePath = getPrimaryWorkspacePath();
			this.skills = await loadSkills(workspacePath, this.opts.host?.bundledSkillsDir);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] R8-E skills load failed: ${err instanceof Error ? err.message : String(err)}`,
			);
			this.skills = [];
		}
		return this.skills;
	}

	getViewColumn(): vscode.ViewColumn | undefined {
		return this.panel.viewColumn;
	}

	getSessionId(): string {
		return this.sessionId;
	}

	reveal(): void {
		this.panel.reveal();
	}

	openSettings(): void {
		if (!this.isReady) {
			// Webview hasn't attached its message listener yet — buffer the
			// intent and the `ready` handler will replay it.
			this.pendingView = "settings";
			return;
		}
		this.bus.send({ type: "show_view", view: "settings" });
	}

	/**
	 * Replace the agent-managed todo list for this panel. Called from the
	 * host context when the agent invokes `todo_write`. Snapshot is held
	 * in memory and re-broadcast on the next `ready` handshake; we don't
	 * persist to disk because Claude-style sessions also start with an
	 * empty list each conversation.
	 */
	handleTodosUpdate(items: readonly import("@oati/shared").UiTodoItem[]): void {
		this.todos = items;
		if (this.isReady) {
			this.bus.send({ type: "todos_updated", items });
		}
	}

	getHistory(): readonly ConversationMessage[] {
		return this.history;
	}

	/** Recompute the tab title after a rename. */
	async refreshTitle(): Promise<void> {
		this.panel.title = await this.computeTitle();
	}

	async requestApproval(req: Omit<ApprovalRequest, "id">): Promise<boolean> {
		// Policy lockdown wins over everything else — a tool denied by
		// `.oati/policy.yaml` is never runnable, regardless of approval state.
		if (!isToolAllowed(this.policy, req.toolName)) {
			const message = `Tool '${req.toolName}' blocked by .oati/policy.yaml`;
			this.opts.log?.appendLine(`[chat-panel] ${message}`);
			this.bus.send({ type: "error", message });
			return false;
		}

		// PreToolUse hooks get the first say — a denying hook short-circuits both
		// auto-approve and the user-facing approval dialog.
		const verdict = await this.hookRunner.runPreToolUse(req.toolName, req.args);
		if (!verdict.allow) {
			const reason = verdict.reason ?? "Blocked by PreToolUse hook";
			this.opts.log?.appendLine(`[chat-panel] PreToolUse blocked ${req.toolName}: ${reason}`);
			this.bus.send({ type: "error", message: `${req.toolName}: ${reason}` });
			return false;
		}
		// R8-E: v2 PreToolUse — runs after the legacy hook so any user who has
		// migrated to `.oati/hooks.json` gets the richer 8-event surface
		// without losing the existing R1 wiring. A v2 hook with
		// `blockOnFailure: true` blocks; otherwise it's observer-only.
		const v2Verdict = await this.fireHookV2({
			kind: "PreToolUse",
			payload: { toolName: req.toolName, args: req.args },
		});
		if (!v2Verdict.allow) {
			const reason = v2Verdict.reason ?? "Blocked by PreToolUse hook (v2)";
			this.opts.log?.appendLine(`[chat-panel] R8-E PreToolUse(v2) blocked ${req.toolName}: ${reason}`);
			this.bus.send({ type: "error", message: `${req.toolName}: ${reason}` });
			return false;
		}

		const cfg = this.opts.settings.config;
		const activeMode = cfg.modes.find((m) => m.id === cfg.activeModeId);
		if (activeMode?.autoApprove) {
			this.opts.log?.appendLine(`[chat-panel] auto-approving ${req.toolName} (mode=${activeMode.id})`);
			return true;
		}
		const id = `ap_${this.nextApprovalId++}`;
		// R8-E: surface a v2 Notification so e.g. a desktop-notify hook can
		// alert the user that the agent is waiting on approval.
		void this.fireHookV2({
			kind: "Notification",
			payload: {
				kind: "approval_needed",
				title: `Approval needed: ${req.toolName}`,
				...(req.summary ? { body: req.summary } : {}),
			},
		});
		return new Promise<boolean>((resolve) => {
			this.pendingApprovals.set(id, resolve);
			this.bus.send({
				type: "approval_request",
				request: {
					id,
					toolName: req.toolName,
					args: req.args,
					summary: req.summary,
					preview: req.preview,
				},
			});
		});
	}

	async showDiff(diff: DiffPreview): Promise<void> {
		this.bus.send({ type: "diff_preview", diff });
	}

	// 2026-05-27: ask the user a multiple-choice clarifying question.
	// Resolves with the chosen option's label OR, when the active mode
	// is set to "auto-pick-first", immediately returns option[0] without
	// prompting (the chat gets a system note so the choice is visible).
	// When the mode is "never", the promise rejects so the model sees an
	// error explaining clarifying questions are disabled.
	async requestAskUser(
		req: import("@oati/shared").AskUserRequest,
	): Promise<import("@oati/shared").AskUserAnswer> {
		const cfg = this.opts.settings.config;
		const activeMode = cfg.modes.find((m) => m.id === cfg.activeModeId) ?? cfg.modes[0];
		const policy = resolveAskUserPolicy(activeMode);

		if (policy === "never") {
			// Surface a clear chat note explaining why and refuse.
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "ask_user",
					text: `🚫 \`ask_user\` is disabled for the **${activeMode?.id ?? "current"}** mode. The model tried to ask: "${truncate(req.question, 200)}"\n`,
				},
			});
			throw new Error(
				`ask_user disabled by mode policy (allowAskUser='never' for mode '${activeMode?.id ?? "unknown"}'). Make the decision yourself or switch to a mode that permits clarifying questions.`,
			);
		}

		if (policy === "auto-pick-first") {
			const picked = req.options[0];
			const alternatives = req.options
				.slice(1)
				.map((o) => `\`${o.label}\``)
				.join(", ");
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "ask_user",
					text: `🤖 Auto-picked **${picked.label}** for: "${truncate(req.question, 200)}"${alternatives ? ` _(alternatives: ${alternatives})_` : ""}\n`,
				},
			});
			return { answer: picked.label, autoPicked: true };
		}

		// "always" — round-trip through the webview.
		this.bus.send({ type: "ask_user_request", request: req });
		return new Promise((resolve) => {
			this.pendingAskUser.set(req.id, resolve);
		});
	}

	/**
	 * Forward a streaming tool-progress chunk to the webview as a synthetic
	 * `tool_progress` agent event. Wired into `HostContext.emitToolProgress`
	 * so tools like `exec` can fan stdout to the UI as it arrives.
	 */
	emitToolProgress(callId: string, chunk: string): void {
		// R3-C: intercept the `render_diagram` sentinel chunk so it's routed to
		// the `diagram_render` HostToWebview channel instead of the normal
		// tool_progress stream (which would render as raw text in the tool card).
		const diagramMarker = "oati-diagram-render";
		if (chunk.startsWith(diagramMarker)) {
			try {
				const json = chunk.slice(diagramMarker.length);
				const parsed = JSON.parse(json) as {
					kind?: string;
					id?: string;
					mermaid?: string;
					title?: string;
				};
				if (
					parsed.kind === "oati.render_diagram" &&
					typeof parsed.id === "string" &&
					typeof parsed.mermaid === "string"
				) {
					this.bus.send({
						type: "diagram_render",
						id: parsed.id,
						mermaid: parsed.mermaid,
						...(parsed.title ? { title: parsed.title } : {}),
					});
					return;
				}
			} catch {
				// Fall through to the normal tool_progress path on malformed sentinel.
			}
		}
		this.bus.send({
			type: "agent_event",
			event: { type: "tool_progress", agentId: "", callId, chunk },
		});
	}

	/**
	 * Reveal this panel and attach a code selection to the next user message.
	 * Called by the `oati.sendSelectionToChat` editor command.
	 */
	attachSelection(args: {
		readonly path: string;
		readonly language?: string;
		readonly text: string;
		readonly startLine: number;
		readonly endLine: number;
	}): void {
		this.panel.reveal(undefined, true);
		this.bus.send({
			type: "attach_selection",
			path: args.path,
			...(args.language ? { language: args.language } : {}),
			text: args.text,
			startLine: args.startLine,
			endLine: args.endLine,
		});
	}

	/** Reveal this panel and prefill the composer with `text`. */
	prefillPrompt(text: string): void {
		this.panel.reveal(undefined, true);
		this.bus.send({ type: "prefill_prompt", text });
	}

	/**
	 * R2-A: Reveal this panel and ask the webview to open the multi-file
	 * composer overlay. Invoked by the `oati.openComposer` VS Code command.
	 */
	openComposer(): void {
		this.panel.reveal(undefined, true);
		this.bus.send({ type: "composer_started" });
	}

	// R4-D: Reveal this panel and ask the webview to open the MCP marketplace
	// overlay. Invoked by the `oati.openMarketplace` VS Code command. Also
	// pushes a fresh `marketplace_state` so the overlay has data on first paint.
	openMarketplace(): void {
		this.panel.reveal(undefined, true);
		this.bus.send({ type: "marketplace_open" });
		this.sendMarketplaceState();
	}

	private async computeTitle(): Promise<string> {
		const list = await this.opts.session.list();
		const meta = list.find((s) => s.id === this.sessionId);
		// Empty / unsent chats just show the brand. Once the user has sent something
		// (so the title was derived from their first message or they renamed it),
		// surface that in the tab to differentiate multiple open chats.
		if (!meta || meta.title === "New Session" || meta.title === "New chat") return "OATI Code";
		return `OATI Code · ${truncate(meta.title, 32)}`;
	}

	private async onMessage(msg: WebviewToHost): Promise<void> {
		switch (msg.type) {
			case "ready": {
				this.isReady = true;
				const config = this.opts.settings.config;
				const rawHistory = await this.opts.session.load(this.sessionId);
				// 2026-05-27: sanitize on load. Sessions that previously
				// hit wrapped-args corruption may still have corrupt tool
				// entries in their saved JSON. Scrubbing on load makes
				// those sessions usable again instead of returning empty
				// on every prompt.
				const sanitized = sanitizeHistory(rawHistory);
				this.history = [...sanitized.history];
				if (sanitized.repaired > 0) {
					// Persist the cleaned version immediately so the
					// corruption is gone from disk for next time too.
					await this.opts.session.save(this.sessionId, this.history);
					const note = formatSanitizeNote(sanitized);
					if (note) {
						this.opts.log?.appendLine(
							`[chat-panel] history sanitizer repaired ${sanitized.repaired} entries on session ${this.sessionId}`,
						);
						this.bus.send({
							type: "agent_event",
							event: { type: "text_delta", agentId: "sanitizer", text: `${note}\n` },
						});
					}
				}
				// 2026-05-27: restore the per-session workspace-root override
				// before anything else looks at workspacePath. Set via
				// `set_workspace_root` in a prior run and persisted by
				// SessionStore.setWorkspaceRoot — this makes the override
				// stick across reloads instead of resetting to the IDE
				// default.
				try {
					const savedRoot = await this.opts.session.getWorkspaceRoot(this.sessionId);
					if (savedRoot && this.opts.host?.setWorkspaceRoot) {
						await this.opts.host.setWorkspaceRoot(savedRoot);
						this.opts.log?.appendLine(
							`[chat-panel] restored workspace root for session ${this.sessionId}: ${savedRoot}`,
						);
					}
				} catch (err) {
					this.opts.log?.appendLine(
						`[chat-panel] failed to restore workspace root: ${err instanceof Error ? err.message : String(err)}`,
					);
				}
				this.panel.title = await this.computeTitle();
				const workspaceFiles = await listWorkspaceFiles();
				// 2026-05-28: prefer the host's effective root so the per-
				// session override restored just above (line ~833) is honored.
				// Without this, custom slash commands, memory, and policy load
				// from the IDE's first folder even when the user explicitly
				// pointed the session at a different project.
				const workspacePath = this.opts.host?.workspaceRoot?.() ?? getPrimaryWorkspacePath();
				this.customCommands = workspacePath ? await loadCustomSlashCommands(workspacePath) : [];
				const customCommandSummaries: CustomCommandSummary[] = this.customCommands.map((c) => ({
					name: c.name,
					description: c.description,
					...(c.icon ? { icon: c.icon } : {}),
					...(c.category ? { category: c.category } : {}),
					...(c.aliases && c.aliases.length > 0 ? { aliases: [...c.aliases] } : {}),
				}));
				const memory = workspacePath ? await loadProjectMemory(workspacePath) : undefined;
				// Workspace policy is materialized once at session start. A change
				// to `.oati/policy.yaml` requires a chat reload — keeps the
				// in-memory copy consistent throughout the session.
				if (workspacePath) {
					const loaded = await loadPolicy(workspacePath);
					this.policy = loaded.policy;
					if (loaded.warning) {
						this.opts.log?.appendLine(`[chat-panel] policy: ${loaded.warning}`);
					}
				}
				const modeSummaries = config.modes.map((m) => ({
					id: m.id,
					displayName: m.displayName,
					description: m.description,
					autoApprove: m.autoApprove,
					enablePlanner: m.enablePlanner,
					enableCritic: m.enableCritic,
				}));
				// Hide policy-denied modes from the picker entirely.
				const visibleModes = filterModes(this.policy, modeSummaries);
				this.bus.send({
					type: "init",
					modes: visibleModes,
					activeModeId: config.activeModeId,
					sessionId: this.sessionId,
					workspaceFiles,
					...(customCommandSummaries.length > 0 ? { customCommands: customCommandSummaries } : {}),
				});
				// Replay any view intent that was queued before the handshake —
				// e.g. `oati.openSettings` called `panel.openSettings()` right
				// after the panel was constructed.
				if (this.pendingView) {
					this.bus.send({ type: "show_view", view: this.pendingView });
					this.pendingView = undefined;
				}
				// Re-broadcast the agent-managed todo list so the checklist
				// panel rehydrates on webview reload.
				if (this.todos.length > 0) {
					this.bus.send({ type: "todos_updated", items: this.todos });
				}
				// Replay any queued supervisor snapshot, OR push the current
				// live snapshot if the supervisor is already running.
				const supSnap = this.pendingSupervisorSnapshot ?? this.opts.supervisor?.getSuggestions();
				if (supSnap && supSnap.length > 0) {
					this.bus.send({ type: "supervisor_suggestions", items: supSnap });
				}
				this.pendingSupervisorSnapshot = undefined;
				// Push the currently-detected project so the chat header
				// shows it immediately — without this the user has no way
				// to verify which folder OATI Code is operating in.
				//
				// 2026-05-28: if the per-session workspace override was just
				// restored, the chip needs to reflect THAT path, not the
				// IDE's first folder. Restore already fires
				// broadcastWorkspaceInfo via the host callback, but that
				// async broadcast can race against this synchronous one and
				// the wrong value used to win. Resolve from the host first
				// so this broadcast is always authoritative.
				const hostRoot = this.opts.host?.workspaceRoot?.();
				const wsInfo = hostRoot
					? {
							path: hostRoot,
							name: nodePath.basename(hostRoot) || hostRoot,
							isMultiRoot: (vscode.workspace.workspaceFolders?.length ?? 0) > 1,
							folderCount: vscode.workspace.workspaceFolders?.length ?? 1,
						}
					: resolveWorkspaceInfo();
				this.bus.send({ type: "workspace_info", ...(wsInfo ? { info: wsInfo } : {}) });
				// R8-C: ensure context-provider registry is hydrated, then broadcast
				// the unified mention list (built-ins + user plugins under
				// `.oati/context-providers/`) so the autocomplete dropdown can offer
				// every `@`-mention in one place.
				registerBuiltinContextProviders();
				if (workspacePath) {
					await loadUserProviders(workspacePath, (m) => this.opts.log?.appendLine(m));
				}
				this.bus.send({
					type: "context_providers_list",
					items: listContextProviders().map((p) => ({
						mention: p.mention,
						description: p.description,
					})),
				});
				// R5-D: surface the built-in persona catalog + the active persona for
				// this session so the chip + picker can render on first paint.
				await this.sendPersonasList();
				await this.pushSettings();
				// Re-hydrate the chat UI from canonical history. If we just loaded a
				// project memory file, prepend a one-time system notice so the user
				// has a visible signal that their `OATI.md` was picked up.
				const restored: UiMessage[] = [];
				if (memory) {
					restored.push({
						id: `sys_memory_${this.nextSystemMessageId++}`,
						role: "system",
						text: `📋 Loaded project memory from ${memory.path}`,
					});
				}
				if (this.history.length > 0) {
					restored.push(...conversationToUiMessages(this.history));
				}
				// 2026-05-26: ALWAYS send restore_session, even when empty.
				// The webview uses this message as the "session is now
				// initialized" signal to gate the Welcome hero — without it,
				// clicking a history item briefly flashed Welcome before the
				// real messages landed. Sending an empty array tells the
				// webview "yes, this session is genuinely empty (or has no
				// recoverable history)" so it can decide whether to render
				// Welcome or the empty-chat composer.
				this.bus.send({ type: "restore_session", messages: restored });
				// R5-B: prime the knowledge/rules indicator on first paint so
				// the header shows `📚 N` / `📜 rules` without waiting for a
				// rebuild event.
				void this.sendKnowledgeState();
				// R8-B: prime the codebase-embedder pill on first paint.
				this.sendEmbedderState();
				return;
			}

			case "user_message": {
				// 2026-05-25: mid-turn injection. If an agent is currently
				// running, the user typing a new message means "fold this
				// into the current run" — NOT "spawn a new turn". Two
				// strategies, selected per-mode via `mode.midTurnBehavior`:
				//
				// - "queue" (default): append to the in-flight agent's input
				//   queue, picked up at the next iteration boundary. Best
				//   for follow-up clarifications to the same task.
				// - "parallel" (2026-05-26): spawn a sibling agent with the
				//   same mode + history-up-to-now, running independently.
				//   Best when the second message is a separate task and the
				//   primary should keep working. Requires the model to
				//   handle parallel calls well (Kimi K2.6, Claude).
				//
				// Image attachments are ignored on the queue path (the
				// agent's queue is text-only). They DO flow through the
				// parallel path because that goes through full `spawn`.
				if (this.opts.conductor.isAnyAgentActive()) {
					const config = this.opts.settings.config;
					const activeMode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
					const behavior = activeMode?.midTurnBehavior ?? "queue";
					if (behavior === "parallel") {
						const parallelParts: MessagePart[] = [];
						if (msg.attachments) {
							for (const att of msg.attachments) {
								if (att.kind === "image") {
									parallelParts.push({
										kind: "image",
										mimeType: att.mimeType,
										dataUrl: att.dataUrl,
									});
								}
							}
						}
						const modelId = this.opts.providerManager.resolveActiveModelId(config);
						if (!modelId) {
							this.opts.log?.appendLine(
								"[chat-panel] mid-turn parallel: no model resolvable, falling back to queue",
							);
							this.opts.conductor.enqueueUserMessage(msg.content);
							return;
						}
						const { agentId } = this.opts.conductor.spawnParallel({
							mode: {
								...activeMode,
								providerId: activeMode?.providerId ?? config.activeProviderId,
								enableCritic: false,
							},
							modelId,
							userMessage: msg.content,
							history: this.history,
							userParts: parallelParts.length > 0 ? parallelParts : undefined,
						});
						this.opts.log?.appendLine(
							`[chat-panel] mid-turn parallel → spawned ${agentId}; content=${truncate(msg.content, 80)}`,
						);
						return;
					}
					const delivered = this.opts.conductor.enqueueUserMessage(msg.content);
					this.opts.log?.appendLine(
						`[chat-panel] mid-turn enqueue → ${delivered} agent(s); content=${truncate(msg.content, 80)}`,
					);
					return;
				}
				// Extract image attachments (if any) so the provider sees them this turn.
				const imageParts: MessagePart[] = [];
				if (msg.attachments) {
					for (const att of msg.attachments) {
						if (att.kind === "image") {
							imageParts.push({
								kind: "image",
								mimeType: att.mimeType,
								dataUrl: att.dataUrl,
							});
						}
					}
				}
				await this.runUserTurn(msg.content, imageParts.length > 0 ? imageParts : undefined);
				return;
			}

			case "run_custom_command": {
				const cmd = this.customCommands.find((c) => c.name === msg.name);
				if (!cmd) {
					this.opts.log?.appendLine(`[chat-panel] run_custom_command: no such command '${msg.name}'`);
					this.bus.send({
						type: "error",
						message: `Unknown custom command: /${msg.name}`,
					});
					return;
				}
				const expanded = applyCustomCommandTemplate(cmd.template, msg.input);
				this.opts.log?.appendLine(
					`[chat-panel] run_custom_command '${msg.name}' (${expanded.length} chars)`,
				);
				await this.runUserTurn(expanded);
				return;
			}

			case "background_tasks_list_request": {
				this.sendBackgroundTasksSnapshot();
				return;
			}

			case "background_task_cancel": {
				await this.opts.backgroundTasks?.cancel(msg.id);
				this.sendBackgroundTasksSnapshot();
				return;
			}

			case "checkpoint_create": {
				await this.createCheckpoint(msg.label);
				return;
			}

			case "checkpoint_list_request": {
				await this.sendCheckpointsList();
				return;
			}

			case "checkpoint_restore": {
				await this.restoreCheckpoint(msg.id);
				return;
			}

			case "checkpoint_delete": {
				await this.deleteCheckpoint(msg.id);
				return;
			}

			case "export_conversation": {
				await this.exportConversation(msg.format);
				return;
			}

			case "set_workspace_root": {
				// `/cwd <path>` from the composer. We route through the
				// host context's setWorkspaceRoot capability — it validates
				// the path, updates the per-panel override, and fires the
				// onWorkspaceRootChanged callback which broadcasts a fresh
				// `workspace_info` event.
				const host = this.opts.host;
				if (!host?.setWorkspaceRoot) {
					this.bus.send({
						type: "error",
						message: "Changing workspace root isn't supported by this host.",
					});
					return;
				}
				try {
					const resolved = await host.setWorkspaceRoot(msg.path);
					this.opts.log?.appendLine(`[chat-panel] /cwd → ${resolved}`);
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.bus.send({ type: "error", message });
				}
				return;
			}

			case "memory_save_suggestion": {
				// 2026-05-29: user clicked "Save" on a post-turn memory
				// suggestion. Persist via the existing addFact helper.
				const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
				if (!wsRoot) return;
				try {
					const { addFact } = await import("./agent-facts");
					await addFact(wsRoot, { fact: msg.fact, source: "agent-suggested" });
				} catch (err) {
					this.opts.log?.appendLine(
						`[chat-panel] memory_save_suggestion failed: ${err instanceof Error ? err.message : String(err)}`,
					);
				}
				return;
			}

			case "memory_dismiss_suggestions": {
				// 2026-05-29: webview cleared the suggestions UI. Nothing
				// to do host-side — the suggestions weren't persisted yet.
				return;
			}

			case "supervisor_dismiss": {
				this.opts.supervisor?.dismiss(msg.id);
				return;
			}

			case "supervisor_clear": {
				this.opts.supervisor?.clear();
				return;
			}

			case "supervisor_run_now": {
				await this.opts.supervisor?.triggerNow();
				return;
			}

			case "run_vscode_command": {
				// Allow-list to prevent the webview from firing arbitrary VS
				// Code commands. Anything under the `oati.*` namespace is fair
				// game because it's our own extension surface; everything else
				// is rejected with a log entry.
				if (!msg.command.startsWith("oati.")) {
					this.opts.log?.appendLine(
						`[chat-panel] refused run_vscode_command outside oati.* namespace: ${msg.command}`,
					);
					return;
				}
				try {
					const args = msg.args ?? [];
					await vscode.commands.executeCommand(msg.command, ...args);
				} catch (err) {
					this.opts.log?.appendLine(
						`[chat-panel] run_vscode_command failed: ${msg.command} — ${err instanceof Error ? err.message : String(err)}`,
					);
				}
				return;
			}

			case "plan_edit": {
				// Phase 5 (2026-05-25): user edited the proposed plan in the
				// PlanEditor (drag-reorder steps, tweak titles/bodies, add/
				// remove). We persist the new shape in `currentPlanV2` and
				// echo it back as `plan_proposed` so the webview confirms
				// the canonical state.
				if (!msg.plan || typeof msg.plan.id !== "string") {
					this.bus.send({ type: "error", message: "plan_edit: missing plan or plan.id" });
					return;
				}
				this.currentPlanV2 = msg.plan;
				this.bus.send({ type: "plan_proposed", plan: msg.plan });
				return;
			}

			case "plan_execute": {
				// Phase 5: user pressed "Execute" in the PlanEditor. Walk
				// the steps in topological order via planner-v2's
				// `executePlan`, dispatching each step as its own
				// `Conductor.spawn()`. Per-step status changes get streamed
				// back as `plan_step_status` events so the UI animates the
				// row icons. Final outcome arrives as `plan_completed`.
				const plan = this.currentPlanV2;
				if (!plan || plan.id !== msg.planId) {
					this.bus.send({
						type: "error",
						message:
							"plan_execute: no proposed plan with that id is in memory. The plan may have been dismissed or the host restarted — re-propose with /plan.",
					});
					return;
				}
				const config = this.opts.settings.config;
				const mode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
				if (!mode) {
					this.bus.send({ type: "error", message: "No active mode configured" });
					return;
				}
				const provider = this.opts.providerManager.registry.get(config.activeProviderId);
				if (!provider) {
					this.bus.send({
						type: "error",
						message: `plan_execute: no active provider (id=${config.activeProviderId})`,
					});
					return;
				}
				const modelId = this.opts.providerManager.resolveActiveModelId(config);
				this.currentPlanAbort = new AbortController();
				try {
					const result = await executePlan(plan, {
						conductor: this.opts.conductor,
						mode,
						modelId,
						provider,
						signal: this.currentPlanAbort.signal,
						onStepStatus: (stepId, status, stepResult) => {
							this.bus.send({
								type: "plan_step_status",
								planId: plan.id,
								stepId,
								status,
								...(stepResult !== undefined ? { result: stepResult } : {}),
							});
						},
					});
					this.bus.send({
						type: "plan_completed",
						planId: plan.id,
						status: result.status,
					});
					// Final state — clear the slot so a fresh `/plan` proposal
					// can replace it without a stale id collision.
					this.currentPlanV2 = undefined;
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] plan_execute failed: ${message}`);
					this.bus.send({
						type: "plan_completed",
						planId: plan.id,
						status: "failed",
					});
				} finally {
					this.currentPlanAbort = undefined;
				}
				return;
			}

			case "plan_cancel": {
				// Phase 5: user pressed "Cancel" on an in-flight plan or
				// dismissed an unstarted proposal. If executePlan is
				// running, abort its signal; either way clear the slot.
				if (this.currentPlanAbort) {
					this.currentPlanAbort.abort();
					this.currentPlanAbort = undefined;
				}
				const planId = this.currentPlanV2?.id;
				this.currentPlanV2 = undefined;
				if (planId) {
					this.bus.send({
						type: "plan_completed",
						planId,
						status: "cancelled",
					});
				}
				return;
			}

			case "regenerate_from": {
				// Map the UiMessage id back to its index in canonical history.
				// `userMessageIdForIndex(n)` in @oati/shared is the inverse.
				const targetIndex = parseUserMessageHistoryIndex(msg.messageId);
				if (
					targetIndex < 0 ||
					targetIndex >= this.history.length ||
					this.history[targetIndex].role !== "user"
				) {
					this.opts.log?.appendLine(
						`[chat-panel] regenerate_from: no matching user message for id=${msg.messageId}`,
					);
					this.bus.send({
						type: "error",
						message: "Could not find that user message to regenerate from.",
					});
					return;
				}

				const config = this.opts.settings.config;
				const mode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
				if (!mode) {
					this.bus.send({ type: "error", message: "No agent mode configured" });
					return;
				}
				const modelId = this.opts.providerManager.resolveActiveModelId(config);
				if (!modelId) {
					this.bus.send({
						type: "error",
						message: "No model configured. Open OATI: Open Settings and set a Model ID.",
					});
					return;
				}

				// Preserve image parts from the original turn so editing the text
				// doesn't drop attached screenshots.
				const original = this.history[targetIndex];
				const carriedImages = original.parts.filter((p) => p.kind === "image") as MessagePart[];

				// Truncate everything from the target user turn onward, then append
				// the edited turn so the conductor re-runs from there.
				const truncated = this.history.slice(0, targetIndex);
				const editedParts: MessagePart[] = [{ kind: "text", text: msg.content }];
				for (const p of carriedImages) editedParts.push(p);
				const optimisticHistory: ConversationMessage[] = [
					...truncated,
					{ role: "user", parts: editedParts },
				];
				this.history = optimisticHistory;
				await this.opts.session.save(this.sessionId, this.history);
				this.bus.send({
					type: "restore_session",
					messages: conversationToUiMessages(this.history),
				});
				this.panel.title = await this.computeTitle();
				this.opts.onSessionIndexChanged();

				this.currentAbort = new AbortController();
				const startedAt = Date.now();
				this.opts.log?.appendLine(
					`[chat-panel] regenerate_from idx=${targetIndex} (model=${modelId}, history=${truncated.length})`,
				);
				try {
					const updated = await this.opts.conductor.spawn({
						// Force critic off — same rationale as runUserTurn's dispatch site.
						mode: { ...mode, providerId: config.activeProviderId, enableCritic: false },
						modelId,
						userMessage: msg.content,
						history: truncated,
						userParts: carriedImages.length > 0 ? carriedImages : undefined,
						signal: this.currentAbort.signal,
					});
					this.history = [...updated];
					await this.opts.session.save(this.sessionId, this.history);
					this.panel.title = await this.computeTitle();
					this.opts.onSessionIndexChanged();
					this.opts.log?.appendLine(
						`[chat-panel] regenerate_from done (${Date.now() - startedAt}ms, history=${this.history.length})`,
					);
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] regenerate_from failed: ${message}`);
					this.bus.send({ type: "error", message });
				}
				return;
			}

			case "compact_history": {
				// Surface an immediate "Compacting…" notice so the user knows the LLM
				// summary is in flight; replaced with the real compacted history once
				// the summarizer call returns.
				const placeholderId = `sys_compact_${this.nextSystemMessageId++}`;
				const optimistic: UiMessage[] = [
					...conversationToUiMessages(this.history),
					{
						id: placeholderId,
						role: "system",
						text: "Compacting conversation…",
						pending: true,
					},
				];
				this.bus.send({ type: "restore_session", messages: optimistic });

				const config = this.opts.settings.config;
				const providerId = config.activeProviderId;
				const provider = this.opts.providerManager.registry.get(providerId);
				const modelId = this.opts.providerManager.resolveActiveModelId(config);
				const summarize = provider && modelId ? makeProviderSummarizer(provider, modelId) : undefined;

				const compacted = await compactHistory(this.history, summarize ? { summarize } : {});
				this.history = compacted;
				await this.opts.session.save(this.sessionId, this.history);
				this.bus.send({
					type: "restore_session",
					messages: conversationToUiMessages(this.history),
				});
				this.opts.onSessionIndexChanged();
				return;
			}

			case "reindex_codebase": {
				// Fire-and-forget — the webview drives this via /reindex and
				// displays progress in its own message stream. We don't block the
				// RPC loop because indexAll can take many seconds on large repos.
				const mgr = this.opts.codebaseIndexManager;
				if (!mgr) {
					this.bus.send({ type: "error", message: "Codebase index not available." });
					return;
				}
				this.opts.log?.appendLine("[chat-panel] reindex_codebase: starting");
				void mgr
					.reindex((p) => {
						this.bus.send({
							type: "indexing_progress",
							done: p.done,
							total: p.total,
							file: p.file,
						});
					})
					.then((result) => {
						if (!result.ok) {
							this.bus.send({
								type: "error",
								message: result.message ?? "Indexing failed.",
							});
							return;
						}
						this.bus.send({
							type: "indexing_progress",
							done: result.files,
							total: result.files,
							chunks: result.chunks,
							done_indexing: true,
						});
						// R8-B: refresh the embedder pill with the just-rebuilt counts.
						this.sendEmbedderState();
						this.opts.log?.appendLine(
							`[chat-panel] reindex_codebase: done (files=${result.files}, chunks=${result.chunks})`,
						);
					})
					.catch((err: unknown) => {
						const message = err instanceof Error ? err.message : String(err);
						this.opts.log?.appendLine(`[chat-panel] reindex_codebase failed: ${message}`);
						this.bus.send({ type: "error", message: `Indexing failed: ${message}` });
					});
				return;
			}

			// R2-E: /share slash command — webview asks host to run the
			// markdown exporter command (which owns the save-dialog flow).
			case "share_session_request": {
				try {
					await vscode.commands.executeCommand("oati.exportSessionMarkdown");
				} catch (err) {
					this.opts.log?.appendLine(
						`[chat-panel] share_session_request failed: ${err instanceof Error ? err.message : String(err)}`,
					);
				}
				return;
			}

			case "clear_session": {
				this.history = [];
				await this.opts.session.clearOne(this.sessionId);
				this.bus.send({ type: "restore_session", messages: [] });
				this.panel.title = await this.computeTitle();
				this.opts.onSessionIndexChanged();
				return;
			}

			case "new_session": {
				this.opts.onRequestNewSession();
				return;
			}

			case "revert_turn": {
				// Phase 3.2: user-initiated rollback of a previous agent turn.
				// Delegates to the AutoRevertGuard that's been collecting
				// per-turn snapshots eagerly (see the conductor.on handler
				// in handleUserMessage where turn_start triggers the
				// initial start() call). When no snapshot exists for the
				// given turnId — already committed, or the turn predates
				// the eager-capture wiring — `restored` comes back empty
				// and the webview surfaces a friendly "nothing to roll
				// back" notice. Errors caught and reported so a failing
				// revert never crashes the chat panel.
				try {
					const restored = await this.autoRevert.revert(msg.turnId, "user requested rollback");
					this.bus.send({
						type: "turn_rollback_complete",
						turnId: msg.turnId,
						restored,
					});
					if (restored.length > 0) {
						this.opts.log?.appendLine(
							`[chat-panel] revert_turn ${msg.turnId}: restored ${restored.length} file(s)`,
						);
					}
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] revert_turn ${msg.turnId} failed: ${message}`);
					this.bus.send({
						type: "turn_rollback_complete",
						turnId: msg.turnId,
						restored: [],
						error: message,
					});
				}
				return;
			}

			case "pick_attachment": {
				await this.pickAttachment();
				return;
			}

			case "split_chat": {
				try {
					this.panel.reveal();
					await vscode.commands.executeCommand("workbench.action.moveEditorToRightGroup");
				} catch {
					/* if no right group exists, VS Code creates one */
				}
				return;
			}

			case "open_file": {
				await this.openFile(msg.path);
				return;
			}

			case "rename_current_session": {
				const list = await this.opts.session.list();
				const meta = list.find((s) => s.id === this.sessionId);
				const next = await vscode.window.showInputBox({
					prompt: "Rename chat",
					value: meta?.title ?? "",
					validateInput: (v) => (v.trim().length === 0 ? "Title cannot be empty" : undefined),
				});
				if (!next) return;
				await this.opts.session.rename(this.sessionId, next.trim());
				await this.refreshTitle();
				this.opts.onSessionIndexChanged();
				return;
			}

			case "cancel":
				this.currentAbort?.abort();
				return;

			case "approval_response": {
				const resolver = this.pendingApprovals.get(msg.id);
				if (resolver) {
					resolver(msg.approved);
					this.pendingApprovals.delete(msg.id);
				}
				return;
			}

			case "ask_user_response": {
				const resolver = this.pendingAskUser.get(msg.id);
				if (resolver) {
					resolver({
						answer: msg.answer,
						...(msg.other ? { other: true } : {}),
					});
					this.pendingAskUser.delete(msg.id);
				}
				return;
			}

			case "secret_confirm": {
				const resolver = this.pendingSecretConfirms.get(msg.id);
				if (resolver) {
					resolver(msg.choice);
					this.pendingSecretConfirms.delete(msg.id);
				}
				return;
			}

			case "set_mode": {
				const cfg = this.opts.settings.config;
				if (cfg.modes.some((m) => m.id === msg.modeId)) {
					await this.opts.settings.updateConfig({
						activeProviderId: cfg.activeProviderId,
						activeModeId: msg.modeId,
						providers: cfg.providers,
					});
				}
				return;
			}

			case "get_settings":
				await this.pushSettings();
				return;

			case "update_settings": {
				await this.opts.settings.updateConfig(msg.settings);
				await this.opts.providerManager.rebuild();
				// 2026-06-06: budget config is captured at chat-panel
				// construction; when the user edits Budget Guardrails in
				// Settings, rebuild the instance so the new caps take
				// effect on the very next dispatch rather than after a
				// window reload.
				if (msg.settings.budget !== undefined) {
					const workspacePath = getPrimaryWorkspacePath() ?? "";
					this.budget = new Budget(workspacePath, this.opts.settings.config.budget);
				}
				await this.pushSettings();
				return;
			}

			case "update_api_key": {
				await this.opts.settings.setApiKey(msg.providerId, msg.apiKey);
				await this.opts.providerManager.rebuild();
				await this.pushSettings();
				return;
			}

			case "delete_api_key": {
				await this.opts.settings.deleteApiKey(msg.providerId);
				await this.opts.providerManager.rebuild();
				await this.pushSettings();
				return;
			}

			case "test_connection": {
				const result = await this.opts.providerManager.testConnection(msg.providerId);
				this.bus.send({
					type: "connection_test_result",
					providerId: msg.providerId,
					ok: result.ok,
					message: result.message,
				});
				return;
			}

			// R2-A: composer (multi-file generation) — APPENDED handlers; do not reorder.
			case "open_composer": {
				this.bus.send({ type: "composer_started" });
				return;
			}

			case "composer_submit": {
				await this.handleComposerSubmit(msg.instruction, msg.contextFiles ?? []);
				return;
			}

			case "composer_accept_file": {
				this.composer?.acceptFile(msg.path);
				return;
			}

			case "composer_reject_file": {
				this.composer?.rejectFile(msg.path);
				return;
			}

			case "composer_accept_all": {
				if (!this.composer) return;
				this.composer.acceptAll();
				try {
					await this.composer.commit();
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] composer commit failed: ${message}`);
					this.bus.send({ type: "composer_done", status: "error", message });
				}
				return;
			}

			case "composer_discard": {
				this.composer?.discard();
				this.composer = undefined;
				return;
			}

			// R3-E: /from-issue <url> — drive the issue → branch → PR scaffold workflow.
			case "start_from_issue": {
				const host = this.opts.host;
				if (!host) {
					this.bus.send({
						type: "error",
						message: "start_from_issue: no HostContext wired into this panel.",
					});
					return;
				}
				const config = this.opts.settings.config;
				const mode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
				if (!mode) {
					this.bus.send({ type: "error", message: "No agent mode configured" });
					return;
				}
				const modelId = this.opts.providerManager.resolveActiveModelId(config);
				if (!modelId) {
					this.bus.send({
						type: "error",
						message: "No model configured. Open OATI: Open Settings and set a Model ID.",
					});
					return;
				}
				this.opts.log?.appendLine(`[chat-panel] start_from_issue: ${msg.url}`);
				try {
					const result = await startFromIssue(msg.url, {
						conductor: this.opts.conductor,
						host,
						mode: { ...mode, providerId: config.activeProviderId },
						modelId,
						history: this.history,
						...(this.opts.log ? { log: this.opts.log } : {}),
					});
					if (result.status === "error") {
						this.bus.send({ type: "error", message: result.message });
					} else {
						this.opts.log?.appendLine(
							`[chat-panel] start_from_issue → ${result.status}: ${result.message}`,
						);
					}
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] start_from_issue failed: ${message}`);
					this.bus.send({ type: "error", message });
				}
				return;
			}

			// R3-D: conversation branching — clone history up to the chosen
			// message into a fresh session and ask extension.ts to open it.
			case "fork_conversation": {
				try {
					const result = await forkConversation(this.opts.session, {
						sessionId: this.sessionId,
						atMessageId: msg.atMessageId,
					});
					this.opts.log?.appendLine(
						`[chat-panel] fork_conversation: cloned ${result.clonedCount} msgs from ${this.sessionId} -> ${result.newSessionId}`,
					);
					this.opts.onSessionIndexChanged();
					this.opts.onForkConversation?.(result.newSessionId);
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] fork_conversation failed: ${message}`);
					this.bus.send({ type: "error", message: `Fork failed: ${message}` });
				}
				return;
			}

			// R3-D: side-by-side compare — fan two concurrent agent runs out,
			// tag streamed chunks by side, surface a terminal `compare_done`
			// per side. Runs are independent of `currentAbort` so they don't
			// interfere with normal chat dispatch.
			case "compare_request": {
				await this.handleCompareRequest(msg.instruction, msg.left, msg.right);
				return;
			}

			case "compare_cancel": {
				this.compareAborts.left?.abort();
				this.compareAborts.right?.abort();
				this.compareAborts = {};
				this.opts.log?.appendLine("[chat-panel] compare_cancel: aborted in-flight runs");
				return;
			}

			// R3-D: webview hydration — fetch pinned ids + fork linkage from
			// the store and push them back. Idempotent; called once on mount.
			case "request_session_meta": {
				try {
					const stored = await this.opts.session.loadPinned(this.sessionId);
					this.pinnedIds = new Set(stored);
					this.bus.send({ type: "pinned_messages_state", pinnedIds: [...stored] });
					const list = await this.opts.session.list();
					const meta = list.find((s) => s.id === this.sessionId);
					if (meta?.parentSessionId && meta.forkedAtMessageId) {
						const parent = list.find((s) => s.id === meta.parentSessionId);
						this.bus.send({
							type: "fork_info",
							parentSessionId: meta.parentSessionId,
							forkedAtMessageId: meta.forkedAtMessageId,
							...(parent?.title ? { parentTitle: parent.title } : {}),
						});
					}
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] request_session_meta failed: ${message}`);
				}
				return;
			}

			// R3-D: pinned messages — update the in-memory set and persist.
			case "pin_message": {
				if (msg.pinned) this.pinnedIds.add(msg.messageId);
				else this.pinnedIds.delete(msg.messageId);
				try {
					await this.opts.session.setPinned(this.sessionId, msg.messageId, msg.pinned);
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] pin_message persist failed: ${message}`);
				}
				return;
			}

			// R3-C: PR review mode. Append-only arm; do not reorder.
			case "review_pr_request": {
				await this.handleReviewPrRequest(msg.url);
				return;
			}

			// R4-D: MCP marketplace — list/install/uninstall/toggle. Append-only
			// arms; do not reorder. All four ultimately reply with a fresh
			// `marketplace_state` so the webview reconciles in one place.
			case "marketplace_list_request": {
				this.sendMarketplaceState();
				return;
			}
			case "marketplace_install": {
				await this.handleMarketplaceMutate(() => this.opts.marketplace?.install(msg.id));
				return;
			}
			case "marketplace_uninstall": {
				await this.handleMarketplaceMutate(() => this.opts.marketplace?.uninstall(msg.id));
				return;
			}
			case "marketplace_toggle": {
				await this.handleMarketplaceMutate(() =>
					this.opts.marketplace?.setEnabled(msg.id, msg.enabled),
				);
				return;
			}

			// R4-E: performance HUD snapshot — return the last 20 turns + the
			// slowest-tool heatmap for this session.
			case "perf_request": {
				const sessionId = msg.sessionId ?? this.sessionId;
				const recent = this.perf.getRecent(sessionId);
				const heatmap = this.perf.getHeatmap();
				this.bus.send({
					type: "perf_snapshot",
					turns: recent.map((t) => ({
						msgId: t.msgId,
						durationMs: t.durationMs,
						toolCalls: t.toolCalls,
						inputTokens: t.inputTokens,
						outputTokens: t.outputTokens,
						cost: t.cost,
					})),
					heatmap: heatmap.map((h) => ({
						tool: h.tool,
						count: h.count,
						p50Ms: h.p50Ms,
						p95Ms: h.p95Ms,
						errorRate: h.errorRate,
					})),
				});
				return;
			}

			// R4-C: project templates — list catalog + apply selected template.
			case "list_templates_request": {
				await this.handleListTemplatesRequest();
				return;
			}

			// R4-C: project templates — materialize the named template.
			case "apply_template_request": {
				await this.handleApplyTemplateRequest(msg.name, msg.targetDir);
				return;
			}

			// R4-C: snippet library — list/save/read.
			case "list_snippets_request": {
				await this.handleListSnippetsRequest();
				return;
			}

			case "save_snippet_request": {
				await this.handleSaveSnippetRequest(msg.name, msg.body, msg.description);
				return;
			}

			case "read_snippet_request": {
				await this.handleReadSnippetRequest(msg.name);
				return;
			}

			// R5-B: `/knowledge` — webview asks for a snapshot of the
			// knowledge base (doc list + rules flag). Host replies with a
			// single `knowledge_state` event carrying the entries.
			case "knowledge_list_request": {
				await this.handleKnowledgeListRequest();
				return;
			}

			// R5-C: conversation search — answer `/search <query>` by querying
			// the cross-session index and shipping a single results event back.
			case "search_conversations_request": {
				await this.handleSearchConversationsRequest(msg.query);
				return;
			}

			// R5-D: persona switching — persist the new persona id (or clear it)
			// and reply with a fresh `personas_list` so the chip + picker stay in
			// sync with persistence.
			case "set_persona": {
				await this.handleSetPersona(msg.personaId);
				return;
			}

			// R5-D: recipes — list the catalog under .oati/recipes/*.md.
			case "list_recipes_request": {
				await this.handleListRecipesRequest();
				return;
			}

			// R5-D: recipes — sequence a named recipe's steps as N agent turns.
			case "run_recipe": {
				await this.handleRunRecipe(msg.name);
				return;
			}

			// R6-B: `@notebook:<path>:<index>` mention — resolve a cell's source
			// so the webview can splice it into the outgoing message before
			// dispatch. Replies with `notebook_cell_body`.
			case "read_notebook_cell_request": {
				await this.handleReadNotebookCellRequest(msg.path, msg.index);
				return;
			}

			// R8-E: /hooks slash command — webview asks for the v2 hook entries.
			case "list_hooks_request": {
				await this.handleListHooksRequest();
				return;
			}

			// R8-E: /skills slash command — webview asks for the skill catalog.
			case "list_skills_request": {
				await this.handleListSkillsRequest();
				return;
			}

			// R8-B: `@codebase <query>` first-class mention. Runs a deep
			// semantic search (k=20, rerank if enabled) and replies with
			// `codebase_deep_search_results`. The webview prepends those hits
			// to the outgoing user message as a "Top relevant code chunks"
			// block before sending `user_message`.
			case "codebase_deep_search_request": {
				await this.handleCodebaseDeepSearchRequest(msg.query);
				return;
			}
		}
	}

	// R8-E: /hooks handler — re-read `.oati/hooks.json` so users editing the
	// file see fresh state without restarting, then ship a snapshot back.
	private async handleListHooksRequest(): Promise<void> {
		try {
			const workspacePath = getPrimaryWorkspacePath();
			const { hooks, source, warning } = await loadHooksV2(
				workspacePath,
				this.opts.settings.config.hooks,
			);
			if (warning) this.opts.log?.appendLine(`[chat-panel] R8-E /hooks: ${warning}`);
			const entries = hooks.map((h: HookV2Entry) => ({
				event: h.event,
				command: h.command,
				...(h.matcher !== undefined ? { matcher: h.matcher } : {}),
				...(h.blockOnFailure ? { blockOnFailure: true } : {}),
				...(h.timeout !== undefined ? { timeout: h.timeout } : {}),
			}));
			this.bus.send({ type: "hooks_list", source, entries });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] R8-E list_hooks failed: ${message}`);
			this.bus.send({ type: "hooks_list", source: "empty", entries: [] });
		}
	}

	// R8-E: /skills handler — re-read `.oati/skills/*.md` so users editing
	// skills see the fresh catalog. Also refreshes the panel's cached
	// `this.skills` so the next user turn picks up the same list.
	private async handleListSkillsRequest(): Promise<void> {
		try {
			const workspacePath = getPrimaryWorkspacePath();
			const fresh = await loadSkills(workspacePath, this.opts.host?.bundledSkillsDir);
			this.skills = fresh;
			this.bus.send({
				type: "skills_list",
				items: fresh.map((s) => ({
					name: s.name,
					description: s.description,
					triggers: s.triggers,
					tools: s.tools,
				})),
			});
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] R8-E list_skills failed: ${message}`);
			this.bus.send({ type: "skills_list", items: [] });
		}
	}

	// R5-D: persona handlers + helpers. Append-only; do not reorder.
	private async sendPersonasList(): Promise<void> {
		const items = listPersonas().map((p) => ({
			id: p.id,
			displayName: p.displayName,
			description: p.description,
		}));
		const activeId = (await this.opts.session.getPersona(this.sessionId)) ?? null;
		this.bus.send({ type: "personas_list", items, activeId });
	}

	private async handleSetPersona(personaId: string | null): Promise<void> {
		if (personaId !== null && getPersona(personaId) === undefined) {
			this.bus.send({
				type: "error",
				message: `Unknown persona '${personaId}'. Run /personas to see the catalog.`,
			});
			return;
		}
		try {
			await this.opts.session.setPersona(this.sessionId, personaId);
			const label = personaId ? `'${personaId}'` : "(cleared)";
			this.opts.log?.appendLine(`[chat-panel] R5-D set_persona → ${label}`);
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] set_persona failed: ${message}`);
			this.bus.send({ type: "error", message: `Could not set persona: ${message}` });
		}
		await this.sendPersonasList();
	}

	// R5-D: recipes — list + run handlers backed by the `./recipes` host module.
	private async handleListRecipesRequest(): Promise<void> {
		try {
			const root = getPrimaryWorkspacePath() ?? "";
			const items = await listRecipes(root);
			this.bus.send({ type: "recipes_list", items });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] list_recipes failed: ${message}`);
			this.bus.send({ type: "recipes_list", items: [] });
		}
	}

	private async handleRunRecipe(name: string): Promise<void> {
		const host = this.opts.host;
		if (!host) {
			this.bus.send({
				type: "error",
				message: "run_recipe: no HostContext wired into this panel.",
			});
			return;
		}
		const config = this.opts.settings.config;
		const mode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
		if (!mode) {
			this.bus.send({ type: "error", message: "No agent mode configured" });
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		if (!modelId) {
			this.bus.send({
				type: "error",
				message: "No model configured. Open OATI: Open Settings and set a Model ID.",
			});
			return;
		}
		this.currentAbort = new AbortController();
		this.opts.log?.appendLine(`[chat-panel] R5-D run_recipe '${name}' starting`);
		try {
			const result = await runRecipe(name, {
				conductor: this.opts.conductor,
				host,
				mode,
				modelId,
				providerId: config.activeProviderId,
				history: this.history,
				signal: this.currentAbort.signal,
				onStepStarted: (s) => {
					this.bus.send({
						type: "recipe_step_started",
						name,
						index: s.index,
						total: s.total,
						text: s.text,
					});
				},
				onStepDone: (s) => {
					this.bus.send({
						type: "recipe_step_done",
						name,
						index: s.index,
						total: s.total,
						ok: s.ok,
						...(s.message ? { message: s.message } : {}),
					});
				},
				...(this.opts.log ? { log: this.opts.log } : {}),
			});
			if (result.history.length > 0) {
				this.history = [...result.history];
				await this.opts.session.save(this.sessionId, this.history);
				this.panel.title = await this.computeTitle();
				this.opts.onSessionIndexChanged();
			}
			this.opts.log?.appendLine(
				`[chat-panel] R5-D run_recipe '${name}' → ${result.status} (${result.completedSteps} steps)`,
			);
			if (result.status === "error" && result.message) {
				this.bus.send({ type: "error", message: `Recipe '${name}': ${result.message}` });
			}
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] run_recipe '${name}' threw: ${message}`);
			this.bus.send({ type: "error", message });
		}
	}

	// R5-C: handle `/search <query>` from the webview. Falls back to an empty
	// result set with a friendly message when no SessionIndex is wired (e.g.
	// a test harness that didn't pass one).
	private async handleSearchConversationsRequest(query: string): Promise<void> {
		const q = (query ?? "").trim();
		try {
			const { searchConversations } = await import("./conversation-search");
			const hits = await searchConversations(this.opts.sessionIndex, q, { k: 10 });
			this.bus.send({
				type: "conversation_search_results",
				query: q,
				items: hits.map((h) => ({
					sessionId: h.sessionId,
					messageId: h.messageId,
					role: h.role,
					snippet: h.snippet,
					createdAt: h.createdAt,
				})),
			});
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] search_conversations failed: ${message}`);
			this.bus.send({ type: "conversation_search_results", query: q, items: [] });
		}
	}

	// R5-B: send the current knowledge_state to the webview. `withEntries=true`
	// also enumerates the doc list (used by `/knowledge`); the lightweight
	// activation broadcast omits it so the message stays small.
	async sendKnowledgeState(withEntries = false): Promise<void> {
		try {
			const root = getPrimaryWorkspacePath() ?? "";
			const docs = this.opts.knowledgeStore?.docs() ?? 0;
			const rulesActive = root ? await hasGlobalRules(root) : false;
			const payload: HostToWebview = withEntries
				? {
						type: "knowledge_state",
						docs,
						rulesActive,
						entries: root ? await listKnowledgeDocs(root) : [],
					}
				: { type: "knowledge_state", docs, rulesActive };
			this.bus.send(payload);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] R5-B knowledge_state send failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}

	// R5-B: `/knowledge` arm — broadcast the full snapshot (with entries).
	private async handleKnowledgeListRequest(): Promise<void> {
		await this.sendKnowledgeState(true);
	}

	// R4-C: project templates — reply with the static built-in catalog.
	private async handleListTemplatesRequest(): Promise<void> {
		try {
			const { listTemplates } = await import("./templates");
			const items = listTemplates().map((t) => ({ name: t.name, description: t.description }));
			this.bus.send({ type: "templates_list", items });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] list_templates failed: ${message}`);
			this.bus.send({ type: "error", message: `Templates unavailable: ${message}` });
		}
	}

	// R4-C: project templates — materialize the named template under either an
	// explicit target directory or the first workspace folder.
	private async handleApplyTemplateRequest(name: string, targetDir?: string): Promise<void> {
		try {
			const { applyTemplate } = await import("./templates");
			const dirUri = targetDir
				? vscode.Uri.file(targetDir)
				: vscode.workspace.workspaceFolders?.[0]?.uri;
			if (!dirUri) {
				this.bus.send({
					type: "error",
					message: "apply_template: no workspace folder open and no targetDir provided.",
				});
				return;
			}
			const result = await applyTemplate(name, dirUri, {
				...(this.opts.host ? { host: this.opts.host } : {}),
				...(this.opts.log ? { log: this.opts.log } : {}),
			});
			this.bus.send({
				type: "template_applied",
				name,
				created: result.created,
				skipped: result.skipped,
			});
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] apply_template '${name}' failed: ${message}`);
			this.bus.send({ type: "error", message: `Template apply failed: ${message}` });
		}
	}

	// R4-C: snippet library — list/save/read handlers backed by the
	// `./snippets` host module. Each handler swallows non-existent workspaces
	// with a friendly reply rather than failing the RPC loop.
	private async handleListSnippetsRequest(): Promise<void> {
		try {
			const { listSnippets } = await import("./snippets");
			const root = getPrimaryWorkspacePath() ?? "";
			const items = await listSnippets(root);
			this.bus.send({ type: "snippets_list", items });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] list_snippets failed: ${message}`);
			this.bus.send({ type: "snippets_list", items: [] });
		}
	}

	private async handleSaveSnippetRequest(
		name: string,
		body: string,
		description?: string,
	): Promise<void> {
		try {
			const { saveSnippet } = await import("./snippets");
			const root = getPrimaryWorkspacePath();
			if (!root) {
				this.bus.send({
					type: "snippet_saved",
					name,
					ok: false,
					message: "No workspace folder open.",
				});
				return;
			}
			await saveSnippet(root, name, body, description);
			this.opts.log?.appendLine(`[chat-panel] saved snippet '${name}' (${body.length} chars)`);
			this.bus.send({ type: "snippet_saved", name, ok: true });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] save_snippet '${name}' failed: ${message}`);
			this.bus.send({ type: "snippet_saved", name, ok: false, message });
		}
	}

	private async handleReadSnippetRequest(name: string): Promise<void> {
		try {
			const { readSnippet } = await import("./snippets");
			const root = getPrimaryWorkspacePath();
			if (!root) {
				this.bus.send({
					type: "snippet_body",
					name,
					message: "No workspace folder open.",
				});
				return;
			}
			const body = await readSnippet(root, name);
			if (body === null) {
				this.bus.send({
					type: "snippet_body",
					name,
					message: `Snippet '${name}' not found in .oati/snippets.`,
				});
				return;
			}
			this.bus.send({ type: "snippet_body", name, body });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] read_snippet '${name}' failed: ${message}`);
			this.bus.send({ type: "snippet_body", name, message });
		}
	}

	// R6-B: `@notebook:<path>:<index>` resolver — read a single cell's source
	// from the host's notebook bridge (or, as a fallback, by parsing the
	// on-disk JSON envelope directly). The webview splices this into the
	// outgoing user message just like `@snip:<name>` does, so we keep the
	// payload tight: source only, no outputs.
	private async handleReadNotebookCellRequest(p: string, index: number): Promise<void> {
		try {
			const host = this.opts.host;
			if (!host) {
				this.bus.send({
					type: "notebook_cell_body",
					path: p,
					index,
					message: "Host context is not available for notebook resolution.",
				});
				return;
			}
			const notebooks = host.notebooks;
			let cellSource: string | undefined;
			if (notebooks) {
				const cells = await notebooks.read(p, false);
				if (index >= 0 && index < cells.length) {
					cellSource = cells[index].source;
				} else {
					this.bus.send({
						type: "notebook_cell_body",
						path: p,
						index,
						message: `Cell index ${index} out of range (notebook has ${cells.length} cells).`,
					});
					return;
				}
			} else if (await host.fileExists(p)) {
				// R6-B: fallback parser — avoid pulling `@oati/tools` here because
				// its barrel exports are owned by R6-A. Inline a tiny nbformat
				// reader good enough for the mention resolver.
				const raw = await host.readFile(p);
				const cellSourceAt = readNotebookCellSource(raw, index);
				if (cellSourceAt.kind === "ok") {
					cellSource = cellSourceAt.source;
				} else {
					this.bus.send({
						type: "notebook_cell_body",
						path: p,
						index,
						message: cellSourceAt.message,
					});
					return;
				}
			} else {
				this.bus.send({
					type: "notebook_cell_body",
					path: p,
					index,
					message: `Notebook '${p}' not found in the workspace.`,
				});
				return;
			}
			this.bus.send({ type: "notebook_cell_body", path: p, index, body: cellSource });
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] read_notebook_cell '${p}#${index}' failed: ${message}`);
			this.bus.send({ type: "notebook_cell_body", path: p, index, message });
		}
	}

	// R8-B: emit the current codebase-embedder identity so the webview header
	// pill can render `📦 <id>:<dim>`. Idempotent; safe to call repeatedly.
	// `reindexRequired` is true when the persisted SQLite store was built with
	// a different embedder than the one the user just selected.
	private sendEmbedderState(): void {
		const mgr = this.opts.codebaseIndexManager;
		if (!mgr) return;
		// Touching getOrCreate triggers index construction with the active
		// embedder; cheap because the store opens on demand.
		const idx = mgr.getOrCreate();
		const active = mgr.getActiveEmbedderInfo();
		if (!active) return;
		const stats = idx ? idx.stats() : { chunks: 0, files: 0 };
		const persistedId = idx ? idx.getEmbedderInfo().id : undefined;
		const reindexRequired = persistedId !== undefined && persistedId !== active.id;
		this.bus.send({
			type: "embedder_state",
			id: active.id,
			displayName: active.displayName,
			dimensions: active.dimensions,
			indexed: { chunks: stats.chunks, files: stats.files },
			reindexRequired,
		});
	}

	// R8-B: `@codebase <query>` resolver. Runs a deep semantic search via the
	// shared CodebaseIndexManager and replies with `codebase_deep_search_results`.
	// The webview prepends the hits to the outgoing user message as a
	// "Top relevant code chunks" block before dispatching `user_message`. The
	// reranker (when enabled by `oati.codebaseIndex.rerank`) runs host-side
	// because it needs the active provider for its LLM call.
	private async handleCodebaseDeepSearchRequest(query: string): Promise<void> {
		const mgr = this.opts.codebaseIndexManager;
		if (!mgr) {
			this.bus.send({
				type: "codebase_deep_search_results",
				query,
				hits: [],
			});
			return;
		}
		try {
			const k = 20;
			const cfg = vscode.workspace.getConfiguration("oati.codebaseIndex");
			const rerankEnabled = cfg.get<boolean>("rerank") === true;
			const idx = mgr.getOrCreate();
			if (!idx) {
				this.bus.send({ type: "codebase_deep_search_results", query, hits: [] });
				return;
			}
			let hits: {
				filePath: string;
				startLine: number;
				endLine: number;
				content: string;
				score: number;
			}[];
			if (rerankEnabled) {
				const callLlm = this.buildRerankerLlmCall();
				hits = await idx.query(query, { k, rerank: { callLlm, maxCandidates: 20 } });
			} else {
				hits = await idx.query(query, { k });
			}
			const info = idx.getEmbedderInfo();
			this.bus.send({
				type: "codebase_deep_search_results",
				query,
				hits,
				...(info.id ? { embedder: { id: info.id, dimensions: info.dim } } : {}),
				reranked: rerankEnabled,
			});
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] codebase_deep_search '${query}' failed: ${message}`);
			this.bus.send({
				type: "codebase_deep_search_results",
				query,
				hits: [],
			});
		}
	}

	/**
	 * Phase 1.3: public capability gate used by createHostContext deps.
	 * Returns the rerank LLM call only when the user has opted in via
	 * `oati.codebaseIndex.rerank = true`. When the setting is off,
	 * returns undefined and the `code_semantic_search` tool skips the
	 * rerank pass — RRF-merged hybrid results are returned directly.
	 */
	getRerankerLlmCall(): ((prompt: string, signal?: AbortSignal) => Promise<string>) | undefined {
		const cfg = vscode.workspace.getConfiguration("oati.codebaseIndex");
		if (cfg.get<boolean>("rerank") !== true) return undefined;
		return this.buildRerankerLlmCall();
	}

	// R8-B: bridge from the LLMReranker's `LlmCallFn` to the active provider's
	// streaming interface. We accumulate text deltas into a single string and
	// stop on `message_end`. This keeps the reranker provider-agnostic.
	private buildRerankerLlmCall(): (prompt: string, signal?: AbortSignal) => Promise<string> {
		const providerManager = this.opts.providerManager;
		const settings = this.opts.settings;
		return async (prompt: string, signal?: AbortSignal): Promise<string> => {
			const cfg = settings.config;
			const providerId = cfg.activeProviderId;
			const provider = providerManager.registry.get(providerId);
			if (!provider) throw new Error(`No active provider for rerank (id=${providerId})`);
			const modelId = providerManager.resolveActiveModelId(cfg);
			const req = {
				messages: [{ role: "user" as const, parts: [{ kind: "text" as const, text: prompt }] }],
				modelId,
				maxTokens: 512,
				temperature: 0,
				...(signal ? { signal } : {}),
			};
			let text = "";
			for await (const ev of provider.stream(req)) {
				if (ev.type === "text_delta") text += ev.text;
				else if (ev.type === "message_end") break;
				else if (ev.type === "error") throw new Error(ev.message);
			}
			return text;
		};
	}

	// R4-D: snapshot the marketplace state and push it to the webview.
	private sendMarketplaceState(): void {
		const items = this.opts.marketplace?.list() ?? [];
		this.bus.send({
			type: "marketplace_state",
			items: items.map((it) => ({
				id: it.entry.id,
				displayName: it.entry.displayName,
				description: it.entry.description,
				category: it.entry.category,
				installed: it.installed,
				enabled: it.enabled,
				...(it.entry.homepage ? { homepage: it.entry.homepage } : {}),
			})),
		});
	}

	// R4-D: shared wrapper for the three mutation RPCs — run the mutation,
	// surface any error to the webview, and always emit the fresh state so
	// the UI converges even on partial failure.
	private async handleMarketplaceMutate(fn: () => Promise<void> | undefined): Promise<void> {
		try {
			await fn();
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] marketplace mutation failed: ${message}`);
			this.bus.send({ type: "error", message: `MCP marketplace: ${message}` });
		}
		this.sendMarketplaceState();
	}

	// R3-C: PR review handler. Lives next to the message-dispatch block so the
	// shared resolve-mode/model boilerplate (and history mutation) sits in one
	// place. Streams events to the webview as a normal chat turn, bookended by
	// `pr_review_started` / `pr_review_finished` for status-banner UX.
	private async handleReviewPrRequest(url: string): Promise<void> {
		const host = this.opts.host;
		if (!host) {
			this.bus.send({
				type: "pr_review_finished",
				url,
				status: "error",
				message: "PR review unavailable: no HostContext wired into this panel.",
			});
			return;
		}
		const config = this.opts.settings.config;
		const baseMode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
		if (!baseMode) {
			this.bus.send({
				type: "pr_review_finished",
				url,
				status: "error",
				message: "No agent mode configured",
			});
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		if (!modelId) {
			this.bus.send({
				type: "pr_review_finished",
				url,
				status: "error",
				message: "No model configured. Open OATI: Open Settings and set a Model ID.",
			});
			return;
		}

		// Parse first so we can emit `pr_review_started` with the metadata the
		// webview needs to render its status banner before the gh fetch starts.
		const { parsePrUrl } = await import("./pr-review");
		const parsed = parsePrUrl(url);
		if (!parsed) {
			this.bus.send({
				type: "pr_review_finished",
				url,
				status: "error",
				message: `Could not parse PR URL: ${url}. Expected https://github.com/owner/repo/pull/NN.`,
			});
			return;
		}
		this.bus.send({
			type: "pr_review_started",
			url,
			number: parsed.number,
			owner: parsed.owner,
			repo: parsed.repo,
		});

		this.currentAbort = new AbortController();
		this.opts.log?.appendLine(
			`[chat-panel] review_pr_request ${parsed.owner}/${parsed.repo}#${parsed.number} (model=${modelId})`,
		);
		try {
			const result = await reviewPullRequest(
				{ url },
				{
					host,
					conductor: this.opts.conductor,
					mode: baseMode,
					modelId,
					providerId: config.activeProviderId,
					history: this.history,
					signal: this.currentAbort.signal,
				},
			);
			if (result.status === "ok") {
				this.history = [...result.history];
				await this.opts.session.save(this.sessionId, this.history);
				this.panel.title = await this.computeTitle();
				this.opts.onSessionIndexChanged();
			}
			this.bus.send({
				type: "pr_review_finished",
				url,
				status: result.status,
				...(result.summary ? { summary: result.summary } : {}),
				...(result.message ? { message: result.message } : {}),
			});
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] review_pr_request failed: ${message}`);
			this.bus.send({ type: "pr_review_finished", url, status: "error", message });
		}
	}

	/**
	 * R2-A: Drive a composer run. Resolves the active provider/model, then
	 * spins up a `Composer` that streams a JSON envelope and emits one preview
	 * per file. Per-file accept/reject and final commit are routed through
	 * subsequent RPCs.
	 */
	private async handleComposerSubmit(
		instruction: string,
		contextFiles: readonly string[],
	): Promise<void> {
		const host = this.opts.host;
		if (!host) {
			this.bus.send({
				type: "composer_done",
				status: "error",
				message: "Composer unavailable: no HostContext wired into this panel.",
			});
			return;
		}
		const config = this.opts.settings.config;
		const providerId = config.activeProviderId;
		const provider = this.opts.providerManager.registry.get(providerId);
		if (!provider) {
			this.bus.send({
				type: "composer_done",
				status: "error",
				message: `Provider not registered: ${providerId}`,
			});
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		if (!modelId) {
			this.bus.send({
				type: "composer_done",
				status: "error",
				message: "No model configured. Open OATI: Open Settings and set a Model ID.",
			});
			return;
		}

		// Build (or replace) the composer for this run. Each run is independent.
		this.composer = new Composer({
			host,
			provider,
			modelId,
			emitFilePreview: (f) => {
				this.bus.send({
					type: "composer_file_preview",
					path: f.path,
					before: f.before,
					after: f.after,
					...(f.language ? { language: f.language } : {}),
				});
			},
			emitDone: (status, message) => {
				this.bus.send({
					type: "composer_done",
					status,
					...(message ? { message } : {}),
				});
			},
			emitApplied: (paths) => {
				this.bus.send({ type: "composer_applied", paths });
			},
			// R6-D: streaming preview — fan partials out to the webview as the
			// model emits them so the composer-panel can show "writing..."
			// placeholders before the full envelope lands.
			emitStreamingPartial: (ev) => {
				this.bus.send({
					type: "streaming_diff_partial",
					path: ev.path,
					content: ev.content,
					status: ev.status,
				});
			},
			...(this.opts.log ? { log: this.opts.log } : {}),
		});
		this.opts.log?.appendLine(
			`[chat-panel] composer_submit (model=${modelId}, ctxFiles=${contextFiles.length}, prompt=${truncate(instruction, 80)})`,
		);
		await this.composer.run(instruction, contextFiles);
	}

	// 2026-05-27: slash commands DON'T run the agent loop — they handle
	// their own work and return. But the webview optimistically sets
	// `isAgentRunning = true` when the user submits, expecting a `done`
	// event from the conductor to clear it. Without that event the
	// "Thinking..." indicator and the Stop button stay frozen forever.
	// This helper fires a synthetic `done` so the webview unwinds the
	// in-flight state cleanly. Call from every slash-command exit path.
	private signalSlashCommandDone(agentId: string): void {
		this.bus.send({
			type: "agent_event",
			event: { type: "done", agentId, reason: "end" },
		});
	}

	// 2026-05-27: find all source files in the workspace for /review @workspace.
	// Uses VS Code'\''s workspace.findFiles glob API — fast (uses ripgrep under
	// the hood) and respects .gitignore-like patterns via the exclude clause.
	// Returns workspace-relative paths sorted alphabetically so re-runs are
	// deterministic.
	private async findWorkspaceSourceFiles(): Promise<string[]> {
		const SOURCE_GLOB =
			"**/*.{ts,tsx,js,jsx,mjs,cjs,cs,py,java,go,rs,rb,php,swift,kt,scala,vue,svelte}";
		const EXCLUDE_GLOB =
			"{**/node_modules/**,**/.git/**,**/dist/**,**/build/**,**/out/**,**/bin/**,**/obj/**,**/.next/**,**/.oati/**,**/reports/**,**/coverage/**,**/.venv/**,**/__pycache__/**,**/target/**}";
		try {
			const uris = await vscode.workspace.findFiles(SOURCE_GLOB, EXCLUDE_GLOB);
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			const paths = uris.map((uri) => {
				if (root) {
					const rel = nodePath.relative(root, uri.fsPath);
					if (!rel.startsWith("..") && !nodePath.isAbsolute(rel)) {
						return rel.replace(/\\/g, "/");
					}
				}
				return uri.fsPath;
			});
			return paths.sort();
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] findWorkspaceSourceFiles failed: ${err instanceof Error ? err.message : String(err)}`,
			);
			return [];
		}
	}

	// 2026-05-27: when `cfg.generateWordReport` is true, build a Word
	// report from the review result and write it to disk. Returns the
	// absolute path so callers can surface it in chat. Best-effort —
	// failures are logged and return undefined.
	private async maybeWriteReviewReport(
		cfg: import("@oati/shared").ReviewConfig | undefined,
		modelId: string,
		result: import("./review").ReviewResult,
	): Promise<string | undefined> {
		if (!cfg?.generateWordReport) return undefined;
		try {
			const { buildReviewReport, buildReportPath } = await import("./report-builder");
			const now = new Date();
			const root = vscode.workspace.workspaceFolders?.[0];
			const projectName = root?.name ?? "Workspace";
			const buffer = await buildReviewReport(result, {
				projectName,
				model: modelId,
				generatedAt: now,
			});
			const relPath = buildReportPath(cfg.reportOutputDir, "code-review", undefined, now);
			return this.writeReportBuffer(relPath, buffer);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] review report build failed: ${err instanceof Error ? err.message : String(err)}`,
			);
			return undefined;
		}
	}

	// 2026-05-27: QA-side equivalent of maybeWriteReviewReport.
	private async maybeWriteQAReport(
		cfg: import("@oati/shared").QAConfig | undefined,
		modelId: string,
		result: import("./qa").QAResult,
	): Promise<string | undefined> {
		if (!cfg?.generateWordReport) return undefined;
		try {
			const { buildQAReport, buildReportPath } = await import("./report-builder");
			const now = new Date();
			const root = vscode.workspace.workspaceFolders?.[0];
			const projectName = root?.name ?? "Workspace";
			const buffer = await buildQAReport(result, {
				projectName,
				model: modelId,
				generatedAt: now,
			});
			const relPath = buildReportPath(cfg.reportOutputDir, "qa", result.subcommand, now);
			return this.writeReportBuffer(relPath, buffer);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] qa report build failed: ${err instanceof Error ? err.message : String(err)}`,
			);
			return undefined;
		}
	}

	// 2026-05-27: write a generated .docx report to disk. The `docx`
	// library produces a Buffer (binary); we use Node fs directly here
	// rather than host.writeFile (which is string-only). The path is
	// resolved against the primary workspace root so it lands next to
	// the user's source rather than at the extension install location.
	private async writeReportBuffer(relPath: string, buffer: Buffer): Promise<string | undefined> {
		const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!root) {
			this.opts.log?.appendLine(
				`[chat-panel] report not written — no workspace folder open (would have been: ${relPath})`,
			);
			return undefined;
		}
		const absPath = nodePath.isAbsolute(relPath) ? relPath : nodePath.join(root, relPath);
		try {
			await fsp.mkdir(nodePath.dirname(absPath), { recursive: true });
			await fsp.writeFile(absPath, buffer);
			await this.maybeAutoOpenReport(absPath);
			return absPath;
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] report write failed (${absPath}): ${err instanceof Error ? err.message : String(err)}`,
			);
			return undefined;
		}
	}

	// 2026-05-27: open a freshly-written report so the user doesn't have
	// to hunt for it. Respects the `oati.reports.autoOpen` setting which
	// defaults ON. `.docx` and similar binary formats go through the OS
	// default app via env.openExternal; text formats (`.md`, `.txt`,
	// `.yaml`) open as a non-preview editor tab. Failures are silent —
	// the file is already on disk and the chat surfaces the path.
	private async maybeAutoOpenReport(absPath: string): Promise<void> {
		const cfg = vscode.workspace.getConfiguration("oati.reports");
		if (!cfg.get<boolean>("autoOpen", true)) return;
		const ext = nodePath.extname(absPath).toLowerCase();
		const uri = vscode.Uri.file(absPath);
		try {
			if (ext === ".md" || ext === ".txt" || ext === ".yaml" || ext === ".yml") {
				const doc = await vscode.workspace.openTextDocument(uri);
				await vscode.window.showTextDocument(doc, {
					preview: false,
					preserveFocus: true,
				});
			} else {
				// .docx / .pdf / anything VS Code can't render natively —
				// hand off to the OS default handler (Word, system PDF
				// viewer, etc.).
				await vscode.env.openExternal(uri);
			}
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] auto-open skipped for ${absPath}: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}

	// 2026-05-27 Phase 4: load the workspace `.oati/review-rules.md` (or
	// whatever path is configured), caching the result. A FileSystemWatcher
	// scoped to THIS path invalidates the cache when the user edits the
	// file, so the next /review picks up changes without a session restart.
	//
	// Returns undefined when:
	//   - no path is configured
	//   - the file doesn't exist
	//   - reading throws (permission errors, etc.)
	// The "doesn't exist" case is cached as `null` in the map so repeated
	// /review calls don't keep failing the read.
	private async loadCustomReviewRules(rawPath: string | undefined): Promise<string | undefined> {
		if (!rawPath || !this.opts.host) return undefined;
		// Normalize so absolute/relative variants of the same path share
		// the cache entry. The watcher uses the raw form (VS Code resolves
		// relative paths against the first workspace folder).
		const key = rawPath.replace(/\\/g, "/");

		// Set up the watcher lazily, scoped to JUST this file. When the
		// configured path changes (user updates Settings), dispose the
		// old watcher and create a new one.
		if (this.customRulesWatcherPath !== key) {
			if (this.customRulesWatcher) {
				try {
					this.customRulesWatcher.dispose();
				} catch {
					/* watcher dispose never throws but be defensive */
				}
			}
			try {
				const root = vscode.workspace.workspaceFolders?.[0];
				if (root) {
					this.customRulesWatcher = vscode.workspace.createFileSystemWatcher(
						new vscode.RelativePattern(root, rawPath),
					);
					const invalidate = () => {
						this.customRulesCache.delete(key);
						this.opts.log?.appendLine(`[chat-panel] review-rules cache invalidated for ${key}`);
					};
					this.customRulesWatcher.onDidChange(invalidate);
					this.customRulesWatcher.onDidCreate(invalidate);
					this.customRulesWatcher.onDidDelete(invalidate);
				}
				this.customRulesWatcherPath = key;
			} catch (err) {
				this.opts.log?.appendLine(
					`[chat-panel] review-rules watcher setup failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}

		// Cache hit (including the "file confirmed missing" marker).
		if (this.customRulesCache.has(key)) {
			const cached = this.customRulesCache.get(key);
			return cached === null ? undefined : cached;
		}

		// Miss — read + cache the outcome.
		try {
			const content = await this.opts.host.readFile(rawPath);
			this.customRulesCache.set(key, content);
			return content;
		} catch {
			this.customRulesCache.set(key, null);
			return undefined;
		}
	}

	// 2026-05-27: post-turn auto-review. Runs the review subsystem on the
	// agent's writes when `cfg.review.autoReviewModelWrites === true`. Fires
	// fire-and-forget so a slow review doesn't block the next user message.
	// Capped at 5 files to keep cost predictable.
	private async maybeAutoReview(
		writtenPaths: readonly string[],
		config: import("@oati/shared").RootConfig,
	): Promise<void> {
		const cfg = config.review;
		if (!cfg || cfg.enabled === false || cfg.autoReviewModelWrites !== true) return;
		if (writtenPaths.length === 0 || !this.opts.host) return;
		const provider = this.opts.providerManager.registry.get(config.activeProviderId);
		if (!provider) return;
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		const host = this.opts.host;
		const targetPaths = writtenPaths.slice(0, 5);
		const files: { path: string; content: string }[] = [];
		for (const p of targetPaths) {
			try {
				const content = await host.readFile(p);
				files.push({ path: p, content });
			} catch {
				/* skip silently */
			}
		}
		if (files.length === 0) return;
		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "review",
				text: `🔍 Auto-review of ${files.length} file${files.length === 1 ? "" : "s"} from this turn…\n`,
			},
		});
		const { runReview } = await import("./review");
		const customRules = await this.loadCustomReviewRules(cfg.customRulesPath);
		const result = await runReview({
			provider,
			modelId,
			cfg,
			files,
			...(customRules ? { customRules } : {}),
		});
		await this.maybeWriteReviewReport(cfg, modelId, result);
		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "review", text: `${result.summary}\n` },
		});
	}

	// 2026-05-27: post-turn auto-test-generation. When the agent wrote a
	// SOURCE file that doesn't have a matching test file, generate one. One
	// generation per turn (don't spam the model with N parallel test
	// generations).
	private async maybeAutoGenerateTests(
		writtenPaths: readonly string[],
		config: import("@oati/shared").RootConfig,
		modelId: string,
	): Promise<void> {
		const cfg = config.qa;
		if (!cfg || cfg.enabled === false || cfg.autoGenerateTests !== true) return;
		if (writtenPaths.length === 0 || !this.opts.host) return;
		const provider = this.opts.providerManager.registry.get(config.activeProviderId);
		if (!provider) return;
		const host = this.opts.host;
		// Pick the first source file that has no companion test.
		let target: string | undefined;
		for (const p of writtenPaths) {
			if (looksLikeTestFile(p)) continue;
			if (!looksLikeSourceFile(p)) continue;
			const testPath = candidateTestPath(p);
			let testExists = false;
			try {
				await host.readFile(testPath);
				testExists = true;
			} catch {
				/* doesn't exist — good */
			}
			if (!testExists) {
				target = p;
				break;
			}
		}
		if (!target) return;
		let sourceContent: string;
		try {
			sourceContent = await host.readFile(target);
		} catch {
			return;
		}
		// Auto-detect framework from package.json / pyproject.toml.
		const frameworkHints: string[] = [];
		for (const probe of ["package.json", "pyproject.toml", "pom.xml", "build.gradle"]) {
			try {
				const c = await host.readFile(probe);
				frameworkHints.push(c.slice(0, 4096));
			} catch {
				/* not present */
			}
		}
		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `🧪 Auto-generating unit tests for \`${target}\`…\n`,
			},
		});
		const { runQA, formatQAResult } = await import("./qa");
		const result = await runQA({
			provider,
			modelId,
			cfg,
			subcommand: "unit",
			args: target,
			targetFiles: [{ path: target, content: sourceContent }],
			frameworkHints,
		});
		for (const a of result.artifacts) {
			try {
				await host.writeFile(a.path, a.content);
			} catch (err) {
				this.opts.log?.appendLine(
					`[chat-panel] auto-test write failed: ${a.path} — ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}
		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "qa", text: `${formatQAResult(result)}\n` },
		});
	}

	// 2026-05-27: /review slash-command implementation. Scope routing:
	//   /review                    — auto: model writes + dev edits this session
	//   /review @model             — only files the agent wrote this session
	//   /review @developer         — only files the developer edited externally
	//   /review @last-turn         — most recent agent turn only
	//   /review @workspace, @all   — walk the workspace for source files (cap 20)
	//   /review path/a path/b      — explicit file list
	private async runReviewCommand(args: string): Promise<void> {
		const cfg = this.opts.settings.config.review;
		if (cfg?.enabled === false) {
			this.bus.send({
				type: "error",
				message:
					"/review: code review is disabled in this workspace's settings. Open Settings → Code Review to enable.",
			});
			return;
		}
		if (!this.opts.host) {
			this.bus.send({ type: "error", message: "/review: host context not available." });
			return;
		}
		const config = this.opts.settings.config;
		const provider = this.opts.providerManager.registry.get(config.activeProviderId);
		if (!provider) {
			this.bus.send({ type: "error", message: "/review: no active provider." });
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);

		// Resolve target file list from args.
		const scope = args || "@auto";
		const explicitPaths = scope.startsWith("@") ? [] : scope.split(/\s+/).filter(Boolean);
		const targetPaths = new Set<string>(explicitPaths);
		if (scope === "@auto" || scope === "@model" || scope === "@last-turn") {
			for (const p of this.lastModelWrittenPaths) targetPaths.add(p);
		}
		if ((scope === "@auto" || scope === "@developer") && this.opts.workspaceChangeTracker) {
			for (const c of this.opts.workspaceChangeTracker.peek()) {
				if (c.kind !== "deleted") targetPaths.add(c.path);
			}
		}
		// 2026-05-27: @workspace / @all — walk the workspace for source files
		// and review them all. runReview internally batches model calls
		// (BATCH_SIZE files per call) so a large repo doesn't blow the
		// context window. Keep a generous safety cap so a 50K-file repo
		// doesn't quietly become a one-hour billable run; the user can
		// re-run with explicit paths to target a subset.
		if (scope === "@workspace" || scope === "@all") {
			const allFound = await this.findWorkspaceSourceFiles();
			const WORKSPACE_REVIEW_CAP = 500;
			const filesToReview = allFound.slice(0, WORKSPACE_REVIEW_CAP);
			for (const p of filesToReview) targetPaths.add(p);
			if (allFound.length > WORKSPACE_REVIEW_CAP) {
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "review",
						text: `⚠️ Workspace has ${allFound.length} source files; reviewing the first ${WORKSPACE_REVIEW_CAP} alphabetically. Re-run with explicit paths to target a subset.\n`,
					},
				});
			} else if (allFound.length > 0) {
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "review",
						text: `🗂 Reviewing all ${allFound.length} source files in the workspace…\n`,
					},
				});
			}
		}
		if (targetPaths.size === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "review",
					text:
						"## /review — no files to review\n\nTry one of:\n\n- `/review @workspace` — review every source file in the workspace (capped at 20)\n- `/review path/a path/b` — review specific files\n- `/review @model` — review files the agent just wrote (after running an agent turn)\n- `/review @developer` — review files you'\\''ve edited externally since the last turn\n",
				},
			});
			return;
		}

		// Load file contents. Skip files that fail to load.
		// 2026-05-27: try ABSOLUTE path first when the input is workspace-
		// relative — host.readFile resolves relatives against the per-panel
		// workspace-root override which can differ from VS Code's first
		// workspace folder (the source of truth findWorkspaceSourceFiles
		// uses). If absolute fails, fall back to the relative form so the
		// existing path-aware logic still works.
		const files: { path: string; content: string }[] = [];
		const skipped: { path: string; reason: string }[] = [];
		const host = this.opts.host;
		const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		for (const p of targetPaths) {
			const candidates: string[] = [];
			if (wsRoot && !nodePath.isAbsolute(p)) {
				candidates.push(nodePath.join(wsRoot, p));
			}
			candidates.push(p);
			let loaded = false;
			let lastErr = "unknown";
			for (const candidate of candidates) {
				try {
					const content = await host.readFile(candidate);
					files.push({ path: p, content });
					loaded = true;
					break;
				} catch (err) {
					lastErr = err instanceof Error ? err.message : String(err);
				}
			}
			if (!loaded) {
				skipped.push({ path: p, reason: lastErr });
				this.opts.log?.appendLine(`[chat-panel] /review skipped ${p}: ${lastErr.slice(0, 200)}`);
			}
		}

		// Status note before the (potentially slow) model call.
		// 2026-05-27: when there are enough files to require batching,
		// hint at the batch count so a 9-batch run doesn't look stuck.
		const REVIEW_BATCH_SIZE = 15;
		const batchCount = Math.max(1, Math.ceil(files.length / REVIEW_BATCH_SIZE));
		const batchHint = batchCount > 1 ? ` in ${batchCount} batches` : "";
		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "review",
				text: `🔍 Reviewing ${files.length} file${files.length === 1 ? "" : "s"}${batchHint}…\n`,
			},
		});

		// 2026-05-27: seed the Update-Todos panel with one entry per batch
		// so the user sees a checklist that ticks off as the model finishes
		// each chunk. Only kicks in when there's actually more than one
		// batch — a single-call review is already obvious from the chat.
		type UiTodoItem = import("@oati/shared").UiTodoItem;
		let reviewTodos: UiTodoItem[] = [];
		if (batchCount > 1) {
			reviewTodos = Array.from({ length: batchCount }, (_, i) => {
				const start = i * REVIEW_BATCH_SIZE + 1;
				const end = Math.min(start + REVIEW_BATCH_SIZE - 1, files.length);
				return {
					content: `Review files ${start}–${end} (batch ${i + 1}/${batchCount})`,
					activeForm: `Reviewing files ${start}–${end} (batch ${i + 1}/${batchCount})`,
					status: i === 0 ? "in_progress" : "pending",
				} satisfies UiTodoItem;
			});
			this.handleTodosUpdate(reviewTodos);
		}

		const { runReview } = await import("./review");
		const customRules = await this.loadCustomReviewRules(cfg?.customRulesPath);
		const result = await runReview({
			provider,
			modelId,
			cfg,
			files,
			...(customRules ? { customRules } : {}),
			signal: this.currentAbort?.signal,
			onBatchProgress: (info) => {
				// 2026-05-27: only emit a progress line when there's actually
				// more than one batch — for a small review the single-call
				// "🔍 Reviewing N files…" line above is already the status.
				if (info.batchCount <= 1) return;
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "review",
						text: `  · batch ${info.batchIndex + 1}/${info.batchCount} done (${info.filesInBatch} files, ${info.findingsSoFar} findings so far)\n`,
					},
				});
				// Tick this batch off and mark the next one as in-progress.
				if (reviewTodos.length > 0) {
					reviewTodos = reviewTodos.map((t, i) => ({
						...t,
						status:
							i <= info.batchIndex ? "completed" : i === info.batchIndex + 1 ? "in_progress" : "pending",
					}));
					this.handleTodosUpdate(reviewTodos);
				}
			},
		});

		// Clear the review checklist once the model is done — the chat
		// summary below carries the final state; leaving stale todos
		// behind would clutter the panel for the next turn.
		if (reviewTodos.length > 0) {
			this.handleTodosUpdate([]);
		}

		// Append skipped to the summary so the user sees what wasn't reviewed.
		let summary = result.summary;
		if (skipped.length > 0) {
			// 2026-05-27: include the reason for the FIRST few skipped files so
			// the user can see WHY they were dropped (path resolution, binary
			// guard, permission, etc.) rather than just a list of names.
			const sample = skipped
				.slice(0, 3)
				.map((s) => `  - \`${s.path}\` — ${s.reason.slice(0, 160)}`)
				.join("\n");
			const more = skipped.length > 3 ? `\n  (+${skipped.length - 3} more)` : "";
			summary += `\n\n**Skipped ${skipped.length} file${skipped.length === 1 ? "" : "s"}:**\n${sample}${more}`;
		}

		const reportPath = await this.maybeWriteReviewReport(cfg, modelId, result);
		if (reportPath) {
			summary += `\n\n📄 Word report saved to \`${reportPath}\`.`;
		}

		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "review", text: `${summary}\n` },
		});
	}

	// 2026-05-27: /qa <subcommand> [...args]
	private async runQACommand(args: string): Promise<void> {
		const cfg = this.opts.settings.config.qa;
		if (cfg?.enabled === false) {
			this.bus.send({
				type: "error",
				message: "/qa: QA testing is disabled. Open Settings → QA Testing to enable.",
			});
			return;
		}
		if (!this.opts.host) {
			this.bus.send({ type: "error", message: "/qa: host context not available." });
			return;
		}

		// 2026-05-28: route the new "QA team" workflows BEFORE the legacy
		// regex so `/qa plan functional`, `/qa plan unit`, and `/qa discover`
		// take precedence over the existing markdown-plan / inline-tests path.
		const trimmed = args.trim();
		if (trimmed === "discover" || trimmed.startsWith("discover ")) {
			await this.runQADiscover();
			return;
		}
		if (trimmed === "plan functional" || trimmed.startsWith("plan functional ")) {
			await this.runQAPlanExcel("functional");
			return;
		}
		if (trimmed === "plan unit" || trimmed.startsWith("plan unit ")) {
			await this.runQAPlanExcel("unit");
			return;
		}
		if (trimmed.startsWith("execute ") || trimmed === "execute") {
			await this.runQAExecute(trimmed.slice("execute".length).trim());
			return;
		}
		if (trimmed.startsWith("report ") || trimmed === "report") {
			await this.runQAReport(trimmed.slice("report".length).trim());
			return;
		}
		if (trimmed === "cycle" || trimmed.startsWith("cycle ")) {
			await this.runQACycle(trimmed.slice("cycle".length).trim());
			return;
		}

		const m = args.match(/^(plan|unit|edge|regression|coverage|security)(?:\s+([\s\S]+))?$/);
		if (!m) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text:
						"## /qa — subcommands\n\n**Excel test-plan workflow (recommended for QA teams):**\n\n- `/qa discover` — read the workspace, produce a functional understanding map\n- `/qa plan functional` — write TEST_PLAN_FUNCTIONAL.xlsx\n- `/qa plan unit` — write TEST_PLAN_UNIT.xlsx\n- `/qa execute <plan>.xlsx` — run the cases, write Status / Actual back to the same file\n- `/qa report <plan>.xlsx` — Word `.docx` summary of an executed plan\n- `/qa cycle [functional|unit|both]` — umbrella: discover → plan → execute → report in one go\n\n**One-shot test generation (lightweight, code-only):**\n\n- `/qa plan <feature>` — generate a TEST_PLAN.md\n- `/qa unit <file|function>` — unit tests for the given target\n- `/qa unit @workspace` — unit tests for every source file in the workspace (batched)\n- `/qa edge <file|function>` — edge-case battery\n- `/qa edge @workspace` — edge cases across every source file\n- `/qa regression <bug>` — failing repro test\n- `/qa coverage` — gap-targeted tests\n- `/qa security <file>` — OWASP-style tests\n- `/qa security @workspace` — security tests across every source file\n",
				},
			});
			return;
		}
		const sub = m[1] as import("./qa").QASubcommand;
		const subArgs = (m[2] ?? "").trim();

		const config = this.opts.settings.config;
		const provider = this.opts.providerManager.registry.get(config.activeProviderId);
		if (!provider) {
			this.bus.send({ type: "error", message: "/qa: no active provider." });
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		const host = this.opts.host;

		// Heuristic: pick target files. For `plan` we treat subArgs as a
		// description; for the others, treat subArgs as a file path
		// (whitespace-separated for multi).
		const targetFiles: { path: string; content: string }[] = [];
		if (sub !== "plan" && sub !== "coverage") {
			for (const p of subArgs.split(/\s+/).filter(Boolean)) {
				if (!p.match(/\.(ts|tsx|js|jsx|mjs|cjs|py|java|cs|go|rs|rb|php|swift|kt)$/i)) {
					continue; // skip non-source tokens (likely a description fragment)
				}
				try {
					const content = await host.readFile(p);
					targetFiles.push({ path: p, content });
				} catch {
					/* file may not exist yet; skip silently */
				}
			}
		}

		// Auto-detect test framework from package.json / pyproject.toml if available.
		const frameworkHints: string[] = [];
		for (const probe of ["package.json", "pyproject.toml", "pom.xml", "build.gradle"]) {
			try {
				const content = await host.readFile(probe);
				frameworkHints.push(content.slice(0, 4096));
			} catch {
				/* not present */
			}
		}

		// 2026-05-27: `/qa <unit|edge|security> @workspace` — walk every
		// source file in the workspace and run /qa per batch, mirroring
		// `/review @workspace`. Only meaningful for the file-targeted
		// subcommands: `plan` and `regression` take a description, not
		// paths, and `coverage` already scans the whole project.
		if (
			(sub === "unit" || sub === "edge" || sub === "security") &&
			(subArgs === "@workspace" || subArgs === "@all")
		) {
			await this.runQAWorkspace(sub, cfg, host, modelId, provider, frameworkHints);
			return;
		}

		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "qa", text: `🧪 /qa ${sub} running…\n` },
		});

		// 2026-05-27: emit a 4-step checklist so the user sees the QA run
		// decompose into phases. The model call is the slow step (10–60s);
		// the others usually flash by, but seeing them tick off makes the
		// "what is it doing" feel concrete instead of "stuck on Thinking…".
		type UiTodoItem = import("@oati/shared").UiTodoItem;
		const wantsReport = cfg?.generateWordReport === true;
		const qaTodos: UiTodoItem[] = [
			{
				content: `Generate ${sub} content`,
				activeForm: `Generating ${sub} content`,
				status: "in_progress",
			},
			{
				content: "Write generated artifacts",
				activeForm: "Writing generated artifacts",
				status: "pending",
			},
			...(wantsReport
				? [
						{
							content: "Build Word report",
							activeForm: "Building Word report",
							status: "pending",
						} satisfies UiTodoItem,
					]
				: []),
		];
		this.handleTodosUpdate(qaTodos);

		const { runQA, formatQAResult } = await import("./qa");
		const result = await runQA({
			provider,
			modelId,
			cfg,
			subcommand: sub,
			args: subArgs,
			targetFiles,
			frameworkHints,
			...(this.currentAbort ? { signal: this.currentAbort.signal } : {}),
		});

		// Mark phase 1 done, phase 2 in-progress.
		qaTodos[0] = { ...qaTodos[0], status: "completed" };
		qaTodos[1] = { ...qaTodos[1], status: "in_progress" };
		this.handleTodosUpdate(qaTodos);

		// Write artifacts via host.writeFile (already approval-gated by host).
		const written: string[] = [];
		const writeErrors: { path: string; error: string }[] = [];
		for (const a of result.artifacts) {
			try {
				await host.writeFile(a.path, a.content);
				written.push(a.path);
			} catch (err) {
				writeErrors.push({ path: a.path, error: err instanceof Error ? err.message : String(err) });
			}
		}

		// Mark phase 2 done; phase 3 (report) in-progress if present.
		qaTodos[1] = { ...qaTodos[1], status: "completed" };
		if (qaTodos[2]) {
			qaTodos[2] = { ...qaTodos[2], status: "in_progress" };
		}
		this.handleTodosUpdate(qaTodos);

		// 2026-05-27: `/qa plan` produces TEST_PLAN.md (or whatever path
		// the prompt named). Auto-open it so the user lands directly on
		// the plan instead of having to find it in the explorer. Other
		// subcommands generate test source files which the user usually
		// runs rather than reads, so we keep those silent and let the
		// tool card surface the path.
		if (sub === "plan" && written.length > 0) {
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			const planPath = written[0];
			const absPath =
				root && !nodePath.isAbsolute(planPath) ? nodePath.join(root, planPath) : planPath;
			await this.maybeAutoOpenReport(absPath);
		}

		let summary = formatQAResult(result);
		if (written.length > 0) {
			summary += `\n\n_Wrote ${written.length} file${written.length === 1 ? "" : "s"}._`;
		}
		if (writeErrors.length > 0) {
			const errorList = writeErrors.map((e) => `- \`${e.path}\` — ${e.error}`).join("\n");
			summary += `\n\n### Write failures\n${errorList}`;
		}

		const reportPath = await this.maybeWriteQAReport(cfg, modelId, result);
		if (reportPath) {
			summary += `\n\n📄 Word report saved to \`${reportPath}\`.`;
		}

		// Mark the report phase done (if it existed) and clear the
		// checklist so the panel doesn't carry stale entries into the
		// next turn.
		if (qaTodos[2]) {
			qaTodos[2] = { ...qaTodos[2], status: "completed" };
			this.handleTodosUpdate(qaTodos);
		}
		this.handleTodosUpdate([]);

		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "qa", text: `${summary}\n` },
		});
	}

	// 2026-05-28: `/qa discover` — produce a functional understanding map
	// of the workspace (modules, user flows, integrations). Saved to
	// `.qa/discover.json` so `/qa plan functional` and `/qa plan unit`
	// can reuse it without re-asking the model.
	private async runQADiscover(): Promise<void> {
		const host = this.opts.host;
		if (!host) {
			this.bus.send({ type: "error", message: "/qa discover: host context not available." });
			return;
		}
		const config = this.opts.settings.config;
		const provider = this.opts.providerManager.registry.get(config.activeProviderId);
		if (!provider) {
			this.bus.send({ type: "error", message: "/qa discover: no active provider." });
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);

		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "qa", text: "🔎 Reading project files…\n" },
		});

		// Feed the model a small, high-signal slice of the workspace.
		const candidates = [
			"README.md",
			"readme.md",
			"package.json",
			"pyproject.toml",
			"pom.xml",
			"Cargo.toml",
			"go.mod",
			"src/index.ts",
			"src/main.ts",
			"src/app.ts",
			"src/index.js",
			"src/main.py",
			"main.py",
			"app.py",
		];
		const contextFiles: { path: string; content: string }[] = [];
		for (const c of candidates) {
			try {
				const content = await host.readFile(c);
				contextFiles.push({ path: c, content });
			} catch {
				/* skip */
			}
		}
		if (contextFiles.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text:
						"Could not find a recognizable project root file (README, package.json, pyproject.toml, …). Make sure the workspace is set correctly.\n",
				},
			});
			return;
		}

		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "qa", text: "🧠 Generating project map…\n" },
		});

		const { discoverProject, formatProjectMapMarkdown } = await import("./qa-plan-generator");
		const map = await discoverProject({
			provider,
			modelId,
			contextFiles,
			...(this.currentAbort ? { signal: this.currentAbort.signal } : {}),
		});

		// Cache for plan generators. Pretty-printed JSON so a human can
		// edit it between phases — that's the value of the discover step.
		try {
			await host.writeFile(".qa/discover.json", JSON.stringify(map, null, 2));
		} catch (err) {
			this.opts.log?.appendLine(
				`[qa-discover] couldn't write .qa/discover.json: ${err instanceof Error ? err.message : String(err)}`,
			);
		}

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `${formatProjectMapMarkdown(map)}\n\n_Saved to_ \`.qa/discover.json\`. Edit it (or rerun \`/qa discover\`), then \`/qa plan functional\` or \`/qa plan unit\`.\n`,
			},
		});
	}

	// 2026-05-28: `/qa plan functional|unit` — generate a TEST_PLAN_*.xlsx
	// from the cached discover map. Detects an existing user template
	// and uses its column schema; otherwise falls back to a sensible default.
	private async runQAPlanExcel(kind: "functional" | "unit"): Promise<void> {
		const host = this.opts.host;
		if (!host) {
			this.bus.send({ type: "error", message: `/qa plan ${kind}: host context not available.` });
			return;
		}
		const config = this.opts.settings.config;
		const provider = this.opts.providerManager.registry.get(config.activeProviderId);
		if (!provider) {
			this.bus.send({ type: "error", message: `/qa plan ${kind}: no active provider.` });
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!wsRoot) {
			this.bus.send({
				type: "error",
				message: `/qa plan ${kind}: no workspace folder open.`,
			});
			return;
		}

		// 2026-05-28: 4-phase todo list so the user sees plan progress.
		// Auto-clears at end so cycle/standalone callers both stay tidy.
		type UiTodoItem = import("@oati/shared").UiTodoItem;
		let planTodos: UiTodoItem[] = [
			{
				content: "Load project map",
				activeForm: "Loading project map",
				status: "in_progress",
			},
			{
				content: "Resolve schema (template or default)",
				activeForm: "Resolving schema",
				status: "pending",
			},
			{
				content: `Generate ${kind} test cases (LLM call)`,
				activeForm: `Generating ${kind} test cases`,
				status: "pending",
			},
			{
				content: "Write workbook",
				activeForm: "Writing workbook",
				status: "pending",
			},
		];
		this.handleTodosUpdate(planTodos);
		const advancePlanPhase = (justDone: number) => {
			planTodos = planTodos.map((t, i) => ({
				...t,
				status: i <= justDone ? "completed" : i === justDone + 1 ? "in_progress" : "pending",
			}));
			this.handleTodosUpdate(planTodos);
		};

		// Load (or regenerate) the project map.
		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "qa", text: "📖 Loading project map…\n" },
		});
		const { discoverProject, generateFunctionalCases, generateUnitCases } = await import(
			"./qa-plan-generator"
		);
		let map: Awaited<ReturnType<typeof discoverProject>>;
		try {
			const cached = await host.readFile(".qa/discover.json");
			map = JSON.parse(cached) as Awaited<ReturnType<typeof discoverProject>>;
		} catch {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: "No cached map found — running `/qa discover` first.\n",
				},
			});
			await this.runQADiscover();
			try {
				const cached = await host.readFile(".qa/discover.json");
				map = JSON.parse(cached) as Awaited<ReturnType<typeof discoverProject>>;
			} catch (err) {
				this.bus.send({
					type: "error",
					message: `/qa plan ${kind}: discover failed: ${err instanceof Error ? err.message : String(err)}`,
				});
				return;
			}
		}

		// Map loaded — advance to phase 2.
		advancePlanPhase(0);

		// Resolve schema (template detection vs default).
		const { resolveSchema, writePlanWorkbook } = await import("./qa-excel");
		const schemaInfo = await resolveSchema({
			workspaceRoot: wsRoot,
			kind,
			fileExists: async (abs) => {
				try {
					await fsp.stat(abs);
					return true;
				} catch {
					return false;
				}
			},
		});
		if (schemaInfo.templatePath) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: `🗂 Using template \`${schemaInfo.templatePath}\` (${schemaInfo.schema.allHeaders.length} columns).\n`,
				},
			});
		} else {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: `📝 No template found — using default ${kind} schema.\n`,
				},
			});
		}

		// Schema resolved — advance to phase 3.
		advancePlanPhase(1);

		// Generate cases.
		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `🧪 Generating ${kind} test cases…\n`,
			},
		});

		let cases: (import("./qa-excel").FunctionalTestCase | import("./qa-excel").UnitTestCase)[];
		try {
			if (kind === "functional") {
				cases = await generateFunctionalCases({
					provider,
					modelId,
					projectMap: map,
					...(this.currentAbort ? { signal: this.currentAbort.signal } : {}),
				});
			} else {
				// For unit, hand the model a few source files as context — pick the
				// first 8 source files found in the workspace (commit 2 will add
				// per-file plans + better file picking).
				const sourceUris = await vscode.workspace.findFiles(
					"{src/**,**/*.{ts,tsx,js,jsx,py,go,rs,cs,java}}",
					"{**/node_modules/**,**/.git/**,**/dist/**,**/out/**,**/bin/**,**/obj/**}",
					8,
				);
				const sourceFiles: { path: string; content: string }[] = [];
				for (const u of sourceUris) {
					const rel = nodePath.relative(wsRoot, u.fsPath).replace(/\\/g, "/");
					try {
						const content = await host.readFile(u.fsPath);
						sourceFiles.push({ path: rel, content });
					} catch {
						/* skip */
					}
				}
				cases = await generateUnitCases({
					provider,
					modelId,
					projectMap: map,
					sourceFiles,
					...(this.currentAbort ? { signal: this.currentAbort.signal } : {}),
				});
			}
		} catch (err) {
			this.bus.send({
				type: "error",
				message: `/qa plan ${kind}: ${err instanceof Error ? err.message : String(err)}`,
			});
			return;
		}

		if (cases.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text:
						"Model returned zero test cases. Try `/qa discover` again or refine the project map at `.qa/discover.json`.\n",
				},
			});
			return;
		}

		// Cases generated — advance to phase 4 (write).
		advancePlanPhase(2);

		// Write to disk.
		const outDir = this.opts.settings.config.qa?.reportOutputDir ?? "reports";
		const projectName = vscode.workspace.workspaceFolders?.[0]?.name ?? "Workspace";
		const filename = kind === "functional" ? "TEST_PLAN_FUNCTIONAL.xlsx" : "TEST_PLAN_UNIT.xlsx";
		const relPath = `${outDir}/${filename}`;
		const absPath = nodePath.isAbsolute(relPath) ? relPath : nodePath.join(wsRoot, relPath);
		try {
			await fsp.mkdir(nodePath.dirname(absPath), { recursive: true });
			await writePlanWorkbook({
				absPath,
				kind,
				schema: schemaInfo.schema,
				...(schemaInfo.templatePath ? { templatePath: schemaInfo.templatePath } : {}),
				workspaceRoot: wsRoot,
				cases,
				projectName,
				generatedAt: new Date(),
			});
		} catch (err) {
			this.bus.send({
				type: "error",
				message: `/qa plan ${kind}: write failed: ${err instanceof Error ? err.message : String(err)}`,
			});
			return;
		}

		// Phase 4 complete — clear so the panel is tidy for the next turn.
		advancePlanPhase(3);
		this.handleTodosUpdate([]);

		await this.maybeAutoOpenReport(absPath);

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `✅ Wrote ${cases.length} ${kind} test case${cases.length === 1 ? "" : "s"} to \`${relPath}\`.\n\nNext: open the file, edit / add columns / mark priorities, then \`/qa execute ${relPath}\` to run the cases and write results back.\n`,
			},
		});
	}

	// 2026-05-28: `/qa execute <path>.xlsx` — load a test plan, route each
	// case via the graduated router, write Status/Actual back to the same
	// workbook. Unit tests run via the test framework; UI tests against
	// localhost; ambiguous + destructive cases surface via ask_user so
	// the user is in the loop.
	private async runQAExecute(rawPath: string): Promise<void> {
		const host = this.opts.host;
		if (!host) {
			this.bus.send({ type: "error", message: "/qa execute: host context not available." });
			return;
		}
		if (rawPath.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text:
						"Usage: `/qa execute <path>.xlsx` — point to a TEST_PLAN_FUNCTIONAL.xlsx or TEST_PLAN_UNIT.xlsx file.\n",
				},
			});
			return;
		}
		const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!wsRoot) {
			this.bus.send({ type: "error", message: "/qa execute: no workspace folder open." });
			return;
		}
		const absPath = nodePath.isAbsolute(rawPath) ? rawPath : nodePath.join(wsRoot, rawPath);
		try {
			await fsp.stat(absPath);
		} catch {
			this.bus.send({
				type: "error",
				message: `/qa execute: file not found — ${absPath}`,
			});
			return;
		}

		const {
			loadPlanWorkbook,
			classifyTestCase,
			writeResultsBack,
			summarize,
			formatExecutionSummary,
		} = await import("./qa-execute");

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `📂 Loading \`${rawPath}\`…\n`,
			},
		});

		let plan: Awaited<ReturnType<typeof loadPlanWorkbook>>;
		try {
			plan = await loadPlanWorkbook(absPath);
		} catch (err) {
			this.bus.send({
				type: "error",
				message: `/qa execute: load failed: ${err instanceof Error ? err.message : String(err)}`,
			});
			return;
		}

		if (plan.rows.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: "The plan has no test cases below the header row. Nothing to execute.\n",
				},
			});
			return;
		}

		// Seed the todo panel — one entry per case.
		type UiTodoItem = import("@oati/shared").UiTodoItem;
		let qaTodos: UiTodoItem[] = plan.rows.map((row, i) => ({
			content: `${row.tcId} — ${row.title}`,
			activeForm: `Running ${row.tcId} — ${row.title}`,
			status: i === 0 ? "in_progress" : "pending",
		}));
		this.handleTodosUpdate(qaTodos);

		const results: Awaited<ReturnType<typeof classifyTestCase>>[] = [];
		void results; // ts noise — keep the import expressive
		const executionResults: import("./qa-execute").ExecutionResult[] = [];

		for (let i = 0; i < plan.rows.length; i++) {
			if (this.currentAbort?.signal.aborted) {
				for (let j = i; j < plan.rows.length; j++) {
					executionResults.push({
						rowNumber: plan.rows[j].rowNumber,
						tcId: plan.rows[j].tcId,
						route: "ask_user",
						status: "Skipped",
						actual: "cancelled by user",
					});
				}
				break;
			}
			const row = plan.rows[i];
			const route = classifyTestCase(row);
			let result: import("./qa-execute").ExecutionResult;
			try {
				if (route === "unit" && plan.kind === "unit") {
					result = await this.executeUnitCase(row);
				} else if (route === "ui") {
					result = await this.executeUiCase(row);
				} else {
					result = await this.executeAskUserCase(row);
				}
			} catch (err) {
				result = {
					rowNumber: row.rowNumber,
					tcId: row.tcId,
					route,
					status: "Blocked",
					actual: `execution error: ${err instanceof Error ? err.message : String(err)}`,
				};
			}
			executionResults.push(result);

			// Tick the panel forward.
			qaTodos = qaTodos.map((t, j) => ({
				...t,
				status: j <= i ? "completed" : j === i + 1 ? "in_progress" : "pending",
			}));
			this.handleTodosUpdate(qaTodos);

			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: `  · ${row.tcId} → **${result.status}** (${route})\n`,
				},
			});
		}

		// Write Status / Actual back to the same workbook.
		try {
			await writeResultsBack({
				workbook: plan.workbook,
				worksheet: plan.worksheet,
				schema: plan.schema,
				results: executionResults,
				tester: "OATI Code",
				absPath,
				executedAt: new Date(),
			});
		} catch (err) {
			this.bus.send({
				type: "error",
				message: `/qa execute: write-back failed: ${err instanceof Error ? err.message : String(err)}`,
			});
			return;
		}

		this.handleTodosUpdate([]);
		const summary = summarize(executionResults);
		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `${formatExecutionSummary(summary, rawPath)}\n\nResults written back to \`${rawPath}\`. Run \`/qa report ${rawPath}\` for a Word summary.\n`,
			},
		});
	}

	// ---- per-route executors ----

	private async executeUnitCase(
		row: import("./qa-execute").TestCaseRow,
	): Promise<import("./qa-execute").ExecutionResult> {
		// Best-effort: run the workspace's test command filtered to this
		// function's name. We don't try to be clever about which framework;
		// the user's package.json `test` script is the source of truth.
		// If `run_tests` tool would have detected vitest/jest/pytest, we'd
		// use that — but the executor here keeps the surface minimal.
		const target = `${row.function ?? ""} ${row.title ?? ""}`.trim();
		const cmd = pickTestCommand(target);
		const host = this.opts.host;
		if (!host) {
			return {
				rowNumber: row.rowNumber,
				tcId: row.tcId,
				route: "unit",
				status: "Blocked",
				actual: "host not available",
			};
		}
		try {
			const res = await host.exec(cmd, { timeoutMs: 60_000 });
			const passed = res.exitCode === 0;
			return {
				rowNumber: row.rowNumber,
				tcId: row.tcId,
				route: "unit",
				status: passed ? "Pass" : "Fail",
				actual: passed
					? "test runner reported success"
					: `exit ${res.exitCode}: ${(res.stdout + res.stderr).slice(0, 800)}`,
			};
		} catch (err) {
			return {
				rowNumber: row.rowNumber,
				tcId: row.tcId,
				route: "unit",
				status: "Blocked",
				actual: err instanceof Error ? err.message : String(err),
			};
		}
	}

	private async executeUiCase(
		row: import("./qa-execute").TestCaseRow,
	): Promise<import("./qa-execute").ExecutionResult> {
		// Computer-use integration is intentionally minimal here — the
		// agent loop already has the capability; we surface the test as a
		// prompt the user can hand to the agent rather than auto-spawning
		// a parallel session. This keeps commit 2 small and safe; commit
		// 3+ can add an automatic spawn.
		return {
			rowNumber: row.rowNumber,
			tcId: row.tcId,
			route: "ui",
			status: "Blocked",
			actual:
				"UI tests need computer-use spawning; for now run them manually or paste the steps into a fresh agent turn. Auto-spawn lands in a follow-up.",
		};
	}

	private async executeAskUserCase(
		row: import("./qa-execute").TestCaseRow,
	): Promise<import("./qa-execute").ExecutionResult> {
		const host = this.opts.host;
		if (!host?.askUser) {
			return {
				rowNumber: row.rowNumber,
				tcId: row.tcId,
				route: "ask_user",
				status: "Skipped",
				actual: "ask_user not available in this host",
			};
		}
		const steps = (row.steps ?? "").slice(0, 800);
		const expected = (row.expected ?? "").slice(0, 400);
		try {
			const ans = await host.askUser({
				id: `qa_exec_${row.tcId}_${Date.now()}`,
				question: `**${row.tcId} — ${row.title}**\n\n*Steps:*\n${steps}\n\n*Expected:* ${expected}\n\nMark result:`,
				options: [{ label: "Pass" }, { label: "Fail" }, { label: "Blocked" }, { label: "Skip" }],
				allowOther: true,
			});
			const status: import("./qa-execute").TestStatus =
				ans.answer === "Pass"
					? "Pass"
					: ans.answer === "Fail"
						? "Fail"
						: ans.answer === "Blocked"
							? "Blocked"
							: "Skipped";
			return {
				rowNumber: row.rowNumber,
				tcId: row.tcId,
				route: "ask_user",
				status,
				actual: ans.answer === "Pass" ? "user confirmed pass" : ans.answer,
				...(ans.autoPicked ? { notes: "auto-picked first option" } : {}),
			};
		} catch (err) {
			return {
				rowNumber: row.rowNumber,
				tcId: row.tcId,
				route: "ask_user",
				status: "Skipped",
				actual: err instanceof Error ? err.message : String(err),
			};
		}
	}

	// 2026-05-28: `/qa report <plan>.xlsx` — read an executed plan and
	// generate a Word .docx summary with pass rate, failed cases, by-module
	// breakdown.
	private async runQAReport(rawPath: string): Promise<void> {
		const host = this.opts.host;
		if (!host) {
			this.bus.send({ type: "error", message: "/qa report: host context not available." });
			return;
		}
		if (rawPath.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: "Usage: `/qa report <path>.xlsx` — point to an executed test plan.\n",
				},
			});
			return;
		}
		const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!wsRoot) {
			this.bus.send({ type: "error", message: "/qa report: no workspace folder open." });
			return;
		}
		const absPath = nodePath.isAbsolute(rawPath) ? rawPath : nodePath.join(wsRoot, rawPath);
		try {
			await fsp.stat(absPath);
		} catch {
			this.bus.send({
				type: "error",
				message: `/qa report: file not found — ${absPath}`,
			});
			return;
		}

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `📊 Building Word report from \`${rawPath}\`…\n`,
			},
		});

		const { loadPlanWorkbook } = await import("./qa-execute");
		const { buildQAExecutedReport } = await import("./qa-report");
		const plan = await loadPlanWorkbook(absPath);
		const projectName = vscode.workspace.workspaceFolders?.[0]?.name ?? "Workspace";
		const buffer = await buildQAExecutedReport({
			plan,
			projectName,
			generatedAt: new Date(),
		});

		const outDir = this.opts.settings.config.qa?.reportOutputDir ?? "reports";
		const stamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-");
		const reportRel = `${outDir}/qa-report-${stamp}.docx`;
		const reportAbs = nodePath.isAbsolute(reportRel) ? reportRel : nodePath.join(wsRoot, reportRel);
		await fsp.mkdir(nodePath.dirname(reportAbs), { recursive: true });
		await fsp.writeFile(reportAbs, buffer);
		await this.maybeAutoOpenReport(reportAbs);

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `📄 Wrote \`${reportRel}\`.\n`,
			},
		});
	}

	// 2026-05-28: `/qa cycle [functional|unit|both]` — umbrella that runs
	// discover → plan → execute → report in one shot. Default `both`.
	private async runQACycle(args: string): Promise<void> {
		const arg = args.trim().toLowerCase();
		const kinds: ("functional" | "unit")[] =
			arg === "functional" ? ["functional"] : arg === "unit" ? ["unit"] : ["functional", "unit"];

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `🔄 /qa cycle — running discover → plan → execute → report for: ${kinds.join(", ")}\n`,
			},
		});

		// 2026-05-28: layered phase todos. Build a single list at the cycle
		// level (discover + plan/execute/report per kind). Nested calls
		// manage their own detailed todo list during their phase (plan
		// shows 4 phases, execute shows per-case); when each nested call
		// returns, we RESTORE the cycle-level view with that phase ticked
		// off. So the panel reads:
		//   - During discover: cycle phase view ("Discovering project")
		//   - During plan: plan's 4-phase view, then back to cycle
		//   - During execute: per-case list, then back to cycle
		//   - During report: cycle phase view ("Building functional report")
		type UiTodoItem = import("@oati/shared").UiTodoItem;
		const cyclePhases: UiTodoItem[] = [
			{
				content: "Discover project",
				activeForm: "Discovering project",
				status: "in_progress",
			},
		];
		for (const kind of kinds) {
			cyclePhases.push(
				{
					content: `Plan ${kind} tests`,
					activeForm: `Planning ${kind} tests`,
					status: "pending",
				},
				{
					content: `Execute ${kind} plan`,
					activeForm: `Executing ${kind} plan`,
					status: "pending",
				},
				{
					content: `Build ${kind} Word report`,
					activeForm: `Building ${kind} Word report`,
					status: "pending",
				},
			);
		}
		this.handleTodosUpdate(cyclePhases);

		const restoreCycleView = (justDoneIdx: number) => {
			for (let i = 0; i < cyclePhases.length; i++) {
				if (i <= justDoneIdx) {
					cyclePhases[i] = { ...cyclePhases[i], status: "completed" };
				} else if (i === justDoneIdx + 1) {
					cyclePhases[i] = { ...cyclePhases[i], status: "in_progress" };
				} else {
					cyclePhases[i] = { ...cyclePhases[i], status: "pending" };
				}
			}
			this.handleTodosUpdate(cyclePhases);
		};

		await this.runQADiscover();
		restoreCycleView(0);
		const outDir = this.opts.settings.config.qa?.reportOutputDir ?? "reports";

		let phaseIdx = 0; // 0 = discover (just done)
		for (const kind of kinds) {
			await this.runQAPlanExcel(kind);
			phaseIdx++;
			restoreCycleView(phaseIdx);

			const planRel =
				kind === "functional" ? `${outDir}/TEST_PLAN_FUNCTIONAL.xlsx` : `${outDir}/TEST_PLAN_UNIT.xlsx`;
			await this.runQAExecute(planRel);
			phaseIdx++;
			restoreCycleView(phaseIdx);

			await this.runQAReport(planRel);
			phaseIdx++;
			restoreCycleView(phaseIdx);
		}

		// Final cleanup — every phase marked done, then clear.
		this.handleTodosUpdate([]);

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: "✅ /qa cycle complete.\n",
			},
		});
	}

	// 2026-05-27: `/qa <unit|edge|security> @workspace` — batched QA
	// across every source file in the workspace. Mirrors the shape of
	// /review @workspace: cap at 500 files, 15 files per model call,
	// accumulate artifacts/issues across batches, emit a todo
	// checklist that ticks off per batch, and write everything at the
	// end via host.writeFile (already approval-gated).
	private async runQAWorkspace(
		sub: import("./qa").QASubcommand,
		cfg: import("@oati/shared").QAConfig | undefined,
		host: NonNullable<typeof this.opts.host>,
		modelId: string,
		provider: import("@oati/shared").ProviderSpec,
		frameworkHints: readonly string[],
	): Promise<void> {
		type UiTodoItem = import("@oati/shared").UiTodoItem;
		type QAArtifact = import("./qa").QAArtifact;
		type QAIssue = import("./qa").QAIssue;
		const QA_BATCH_SIZE = 15;
		const WORKSPACE_QA_CAP = 500;

		const allFound = await this.findWorkspaceSourceFiles();
		if (allFound.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: `## /qa ${sub} @workspace — no source files found\n\nThe workspace scan returned no matching source files. Re-run with explicit paths to QA specific files.\n`,
				},
			});
			return;
		}
		const targets = allFound.slice(0, WORKSPACE_QA_CAP);
		if (allFound.length > WORKSPACE_QA_CAP) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: `⚠️ Workspace has ${allFound.length} source files; running /qa ${sub} on the first ${WORKSPACE_QA_CAP} alphabetically. Re-run with explicit paths to target a subset.\n`,
				},
			});
		}

		// Load file contents. Skip files that fail to load — mirror the
		// absolute-then-relative path resolution /review uses so the
		// per-panel workspace-root override is honored.
		const loaded: { path: string; content: string }[] = [];
		const loadSkipped: { path: string; reason: string }[] = [];
		const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		for (const p of targets) {
			const candidates: string[] = [];
			if (wsRoot && !nodePath.isAbsolute(p)) {
				candidates.push(nodePath.join(wsRoot, p));
			}
			candidates.push(p);
			let ok = false;
			let lastErr = "unknown";
			for (const candidate of candidates) {
				try {
					const content = await host.readFile(candidate);
					loaded.push({ path: p, content });
					ok = true;
					break;
				} catch (err) {
					lastErr = err instanceof Error ? err.message : String(err);
				}
			}
			if (!ok) {
				loadSkipped.push({ path: p, reason: lastErr });
			}
		}

		if (loaded.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: `## /qa ${sub} @workspace — every file failed to load\n\nFirst error: ${loadSkipped[0]?.reason ?? "unknown"}\n`,
				},
			});
			return;
		}

		const batches: (typeof loaded)[] = [];
		for (let i = 0; i < loaded.length; i += QA_BATCH_SIZE) {
			batches.push(loaded.slice(i, i + QA_BATCH_SIZE));
		}

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "qa",
				text: `🧪 /qa ${sub} @workspace — ${loaded.length} files in ${batches.length} batch${batches.length === 1 ? "" : "es"}…\n`,
			},
		});

		// Seed the Update-Todos panel — one entry per batch, just like /review.
		let qaTodos: UiTodoItem[] = batches.map((_batch, i) => {
			const start = i * QA_BATCH_SIZE + 1;
			const end = Math.min(start + QA_BATCH_SIZE - 1, loaded.length);
			return {
				content: `QA ${sub} files ${start}–${end} (batch ${i + 1}/${batches.length})`,
				activeForm: `Running /qa ${sub} on files ${start}–${end} (batch ${i + 1}/${batches.length})`,
				status: i === 0 ? "in_progress" : "pending",
			} satisfies UiTodoItem;
		});
		this.handleTodosUpdate(qaTodos);

		const { runQA } = await import("./qa");
		const allArtifacts: QAArtifact[] = [];
		const allIssues: QAIssue[] = [];
		const allNotes: string[] = [];
		const batchSkipped: { path: string; reason: string }[] = [];
		let needsTestRun = false;

		for (let bi = 0; bi < batches.length; bi++) {
			if (this.currentAbort?.signal.aborted) {
				for (const f of batches.slice(bi).flat()) {
					batchSkipped.push({ path: f.path, reason: "cancelled" });
				}
				break;
			}
			const batch = batches[bi];
			try {
				const result = await runQA({
					provider,
					modelId,
					cfg,
					subcommand: sub,
					args: batch.map((f) => f.path).join(" "),
					targetFiles: batch,
					frameworkHints,
					...(this.currentAbort ? { signal: this.currentAbort.signal } : {}),
				});
				allArtifacts.push(...result.artifacts);
				if (result.issues) allIssues.push(...result.issues);
				allNotes.push(...result.notes);
				needsTestRun = needsTestRun || result.needsTestRun;
			} catch (err) {
				const reason = err instanceof Error ? err.message : String(err);
				for (const f of batch) {
					batchSkipped.push({ path: f.path, reason });
				}
			}
			// Tick this batch off, bump the next one to in_progress.
			qaTodos = qaTodos.map((t, i) => ({
				...t,
				status: i <= bi ? "completed" : i === bi + 1 ? "in_progress" : "pending",
			}));
			this.handleTodosUpdate(qaTodos);
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "qa",
					text: `  · batch ${bi + 1}/${batches.length} done (${batch.length} files, ${allArtifacts.length} artifacts so far)\n`,
				},
			});
		}

		// Write every accumulated artifact via host.writeFile.
		const written: string[] = [];
		const writeErrors: { path: string; error: string }[] = [];
		for (const a of allArtifacts) {
			try {
				await host.writeFile(a.path, a.content);
				written.push(a.path);
			} catch (err) {
				writeErrors.push({ path: a.path, error: err instanceof Error ? err.message : String(err) });
			}
		}

		// Compose the final summary. Borrows the shape of formatQAResult
		// but rolls up multi-batch totals so the user sees one number per
		// dimension instead of N separate per-batch summaries.
		const blockingCount = allIssues.filter((i) => i.severity === "blocking").length;
		const advisoryCount = allIssues.filter((i) => i.severity === "advisory").length;
		let summary = `## /qa ${sub} @workspace — ${loaded.length} files\n\n`;
		summary += `**Batches:** ${batches.length}  ·  **Artifacts:** ${allArtifacts.length}  ·  **Issues:** ${allIssues.length} (${blockingCount} blocking, ${advisoryCount} advisory)\n`;
		if (needsTestRun) {
			summary += "\n_Run the generated tests to confirm they pass / fail as expected._\n";
		}
		if (written.length > 0) {
			summary += `\n_Wrote ${written.length} file${written.length === 1 ? "" : "s"}._`;
		}
		if (writeErrors.length > 0) {
			const errorList = writeErrors
				.slice(0, 5)
				.map((e) => `- \`${e.path}\` — ${e.error}`)
				.join("\n");
			const more = writeErrors.length > 5 ? `\n  (+${writeErrors.length - 5} more)` : "";
			summary += `\n\n### Write failures\n${errorList}${more}`;
		}
		const totalSkipped = loadSkipped.length + batchSkipped.length;
		if (totalSkipped > 0) {
			const sample = [...loadSkipped, ...batchSkipped]
				.slice(0, 3)
				.map((s) => `  - \`${s.path}\` — ${s.reason.slice(0, 160)}`)
				.join("\n");
			const more = totalSkipped > 3 ? `\n  (+${totalSkipped - 3} more)` : "";
			summary += `\n\n**Skipped ${totalSkipped} file${totalSkipped === 1 ? "" : "s"}:**\n${sample}${more}`;
		}

		// Word report — feed the merged result through the existing
		// builder so /qa @workspace produces a single rolled-up document.
		const mergedResult: import("./qa").QAResult = {
			subcommand: sub,
			summary,
			artifacts: allArtifacts,
			notes: allNotes,
			needsTestRun,
			issues: allIssues,
		};
		const reportPath = await this.maybeWriteQAReport(cfg, modelId, mergedResult);
		if (reportPath) {
			summary += `\n\n📄 Word report saved to \`${reportPath}\`.`;
		}

		this.handleTodosUpdate([]);
		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "qa", text: `${summary}\n` },
		});
	}

	// 2026-05-29: /plan-mode — toggle plan-first workflow for this panel.
	//   /plan-mode             — show current mode
	//   /plan-mode on          — always inject the planning nudge
	//   /plan-mode off         — never inject (default)
	//   /plan-mode auto        — inject only for non-trivial-looking turns
	private runPlanModeCommand(args: string): void {
		const sub = args.trim().toLowerCase();
		if (sub.length === 0 || sub === "status") {
			this.emitSystemNote(
				"plan-mode",
				`Plan mode is currently **${this.planMode}**. Toggle with \`/plan-mode on|off|auto\`.\n\n- **on**: every turn includes the planning nudge — model drafts a numbered plan before tool calls.\n- **auto**: nudge fires only for turns that look non-trivial (≥250 chars or multi-step keywords).\n- **off**: no nudge.`,
			);
			return;
		}
		if (sub === "on" || sub === "off" || sub === "auto") {
			this.planMode = sub;
			this.emitSystemNote("plan-mode", `Plan mode set to **${sub}**.`);
			return;
		}
		this.emitSystemNote(
			"plan-mode",
			`Unknown subcommand \`${sub}\`. Use \`/plan-mode on|off|auto|status\`.`,
		);
	}

	// 2026-05-29: /tdd — toggle test-first workflow for this panel.
	//   /tdd            — show current mode
	//   /tdd on         — inject the TDD nudge every turn
	//   /tdd off        — disable (default)
	private runTddCommand(args: string): void {
		const sub = args.trim().toLowerCase();
		if (sub.length === 0 || sub === "status") {
			this.emitSystemNote(
				"tdd",
				`TDD mode is currently **${this.tddMode}**. Toggle with \`/tdd on|off\`.\n\nWhen on, the model writes a failing test before source for bug fixes / new behavior.`,
			);
			return;
		}
		if (sub === "on" || sub === "off") {
			this.tddMode = sub;
			this.emitSystemNote("tdd", `TDD mode set to **${sub}**.`);
			return;
		}
		this.emitSystemNote("tdd", `Unknown subcommand \`${sub}\`. Use \`/tdd on|off|status\`.`);
	}

	private emitSystemNote(agentId: string, text: string): void {
		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId, text: `${text}\n` },
		});
	}

	// 2026-05-30: auto-verify. Runs the project's detected test/build
	// command after the agent finished a turn that mutated ≥
	// AUTO_VERIFY_THRESHOLD files. Goal: surface compile / test failures
	// the model wouldn't have noticed otherwise so the user can ask for
	// a fix on the next turn (or the agent's resume / auto-continue can
	// pick it up). Best-effort: no runner detected → quietly skip. Tool
	// error → surface as a system note, never block.
	private async runAutoVerify(mutationCount: number): Promise<void> {
		if (this.autoVerifyRunning) return;
		this.autoVerifyRunning = true;
		try {
			const { detectRunner } = await import("@oati/tools");
			const host = this.opts.host;
			if (!host) return;
			const detection = await detectRunner(host);
			if (detection.kind === "none") {
				// No test/build runner detected — nothing to verify against.
				return;
			}
			const command = detection.buildCommand({});
			this.emitSystemNote(
				"auto-verify",
				`🔍 **Auto-verify** — ${mutationCount} files mutated this turn. Running \`${command}\` to check for breakage…`,
			);
			let result: { stdout: string; stderr: string; exitCode: number } | undefined;
			try {
				result = await host.exec(command, { timeoutMs: 120_000 });
			} catch (err) {
				const message = err instanceof Error ? err.message : String(err);
				this.emitSystemNote(
					"auto-verify",
					`⚠️ Auto-verify couldn't launch \`${command}\`: ${message}. You may need to run it manually.`,
				);
				return;
			}
			if (result.exitCode === 0) {
				this.emitSystemNote(
					"auto-verify",
					`✅ Auto-verify passed (\`${command}\` exit 0). Your ${mutationCount} edits this turn didn't break the build/tests.`,
				);
				return;
			}
			// Failed: show a tight summary so the user/model can act. Cap
			// the output so a 10k-line stack trace doesn't drown the chat.
			const blob = `${result.stdout}\n${result.stderr}`.trim();
			const TAIL_BYTES = 2_000;
			const tail =
				blob.length > TAIL_BYTES
					? `…(${blob.length - TAIL_BYTES} earlier bytes omitted)\n${blob.slice(-TAIL_BYTES)}`
					: blob;
			this.emitSystemNote(
				"auto-verify",
				[
					`❌ **Auto-verify failed** — \`${command}\` exit ${result.exitCode}.`,
					"",
					`This turn mutated ${mutationCount} files; the build/test runner reports breakage. Tail of the output:`,
					"",
					"```",
					tail || "(no output captured)",
					"```",
					"",
					"Ask the agent to fix this, or investigate manually.",
				].join("\n"),
			);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] auto-verify error: ${err instanceof Error ? err.message : String(err)}`,
			);
		} finally {
			this.autoVerifyRunning = false;
		}
	}

	// 2026-05-29: /memory — manage persistent project memory.
	//   /memory              — list current OATI.md + facts (default)
	//   /memory show         — alias for default
	//   /memory edit         — open OATI.md in the editor
	//   /memory add <fact>   — append a fact without going through the agent
	//   /memory forget <id>  — drop a single fact by id
	//   /memory prune [days] — drop facts older than N days (default 90)
	private async runMemoryCommand(args: string): Promise<void> {
		const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!wsRoot) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "memory",
					text: "/memory: no workspace folder open.\n",
				},
			});
			return;
		}

		const trimmed = args.trim();
		const sub = trimmed.length === 0 ? "show" : trimmed.split(/\s+/)[0].toLowerCase();
		const rest = trimmed.slice(sub.length).trim();

		const { loadProjectMemory, loadGlobalMemory } = await import("./project-memory");
		const { loadFacts, addFact, removeFact, pruneOldFacts } = await import("./agent-facts");

		if (sub === "show") {
			const [globalMem, projectMem, facts] = await Promise.all([
				loadGlobalMemory(),
				loadProjectMemory(wsRoot),
				loadFacts(wsRoot),
			]);
			const lines: string[] = ["## Memory snapshot", ""];
			if (globalMem) {
				lines.push(`### Global memory (\`${globalMem.path}\`)`);
				lines.push("");
				lines.push(
					"```markdown",
					globalMem.content.slice(0, 2000) +
						(globalMem.content.length > 2000
							? `\n…[+${globalMem.content.length - 2000} more chars]`
							: ""),
					"```",
					"",
				);
			} else {
				lines.push("### Global memory");
				lines.push("");
				lines.push("_None found. Create `~/.oati/OATI.md` to add global preferences._");
				lines.push("");
			}
			if (projectMem) {
				lines.push(`### Project memory (\`${projectMem.path}\`)`);
				lines.push("");
				lines.push(
					"```markdown",
					projectMem.content.slice(0, 2000) +
						(projectMem.content.length > 2000
							? `\n…[+${projectMem.content.length - 2000} more chars]`
							: ""),
					"```",
					"",
				);
			} else {
				lines.push("### Project memory");
				lines.push("");
				lines.push("_None found. Run `/memory edit` to create `OATI.md` in this workspace._");
				lines.push("");
			}
			lines.push(`### Persistent facts (${facts.length})`);
			lines.push("");
			if (facts.length === 0) {
				lines.push(
					"_No facts recorded. The agent will use `remember_fact` automatically as it learns about your project. You can also `/memory add <fact text>` to seed one._",
				);
			} else {
				for (const f of facts) {
					lines.push(`- **${f.id}** (${f.source}, ${f.addedAt.slice(0, 10)}) — ${f.fact}`);
				}
			}
			lines.push("");
			lines.push(
				"**Subcommands:** `/memory edit`, `/memory add <fact>`, `/memory forget <id>`, `/memory prune [days]`.",
			);
			this.bus.send({
				type: "agent_event",
				event: { type: "text_delta", agentId: "memory", text: `${lines.join("\n")}\n` },
			});
			return;
		}

		if (sub === "edit") {
			const candidates = [".oati/OATI.md", "OATI.md", ".claude/CLAUDE.md", "CLAUDE.md"];
			let targetRel: string | undefined;
			for (const rel of candidates) {
				try {
					await fsp.stat(nodePath.join(wsRoot, rel));
					targetRel = rel;
					break;
				} catch {
					/* not present */
				}
			}
			if (!targetRel) {
				// Create a starter at `.oati/OATI.md`.
				targetRel = ".oati/OATI.md";
				const abs = nodePath.join(wsRoot, targetRel);
				await fsp.mkdir(nodePath.dirname(abs), { recursive: true });
				const starter = [
					"# Project memory",
					"",
					"Notes the agent should remember about this project.",
					"",
					"## Conventions",
					"",
					'- (e.g. "use tabs", "vitest as the test runner")',
					"",
					"## Architecture facts",
					"",
					'- (e.g. "the backend is at packages/server")',
					"",
					"## User preferences",
					"",
					'- (e.g. "prefer descriptive variable names over short ones")',
					"",
				].join("\n");
				await fsp.writeFile(abs, starter, "utf-8");
			}
			const uri = vscode.Uri.file(nodePath.join(wsRoot, targetRel));
			try {
				const doc = await vscode.workspace.openTextDocument(uri);
				await vscode.window.showTextDocument(doc, { preview: false, preserveFocus: false });
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "memory",
						text: `📝 Opened \`${targetRel}\`. Edits take effect on the next chat turn.\n`,
					},
				});
			} catch (err) {
				this.bus.send({
					type: "error",
					message: `/memory edit: ${err instanceof Error ? err.message : String(err)}`,
				});
			}
			return;
		}

		if (sub === "add") {
			const factText = rest;
			if (factText.length === 0) {
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "memory",
						text: "Usage: `/memory add <one-line fact>`\n",
					},
				});
				return;
			}
			const updated = await addFact(wsRoot, { fact: factText, source: "user" });
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "memory",
					text: `✅ Remembered: ${factText} (now ${updated.length} fact${updated.length === 1 ? "" : "s"})\n`,
				},
			});
			return;
		}

		if (sub === "forget") {
			const id = rest;
			if (id.length === 0) {
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "memory",
						text: "Usage: `/memory forget <fact-id>` — find IDs via `/memory show`.\n",
					},
				});
				return;
			}
			const before = await loadFacts(wsRoot);
			const after = await removeFact(wsRoot, id);
			if (after.length === before.length) {
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "memory",
						text: `No fact with id \`${id}\`. Use \`/memory show\` to list current IDs.\n`,
					},
				});
			} else {
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "memory",
						text: `🗑️ Dropped fact \`${id}\`. ${after.length} fact${after.length === 1 ? "" : "s"} remaining.\n`,
					},
				});
			}
			return;
		}

		if (sub === "prune") {
			const days = rest.length > 0 ? Number.parseInt(rest, 10) : 90;
			if (!Number.isFinite(days) || days <= 0) {
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "memory",
						text: "Usage: `/memory prune [days]` — default 90.\n",
					},
				});
				return;
			}
			const result = await pruneOldFacts(wsRoot, days);
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "memory",
					text: `🧹 Pruned ${result.removed} fact${result.removed === 1 ? "" : "s"} older than ${days} days. ${result.kept.length} remaining.\n`,
				},
			});
			return;
		}

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "memory",
				text: `Unknown subcommand: \`${sub}\`. Use \`/memory\` (or \`/memory show\`) to see current state. Subcommands: \`show\`, \`edit\`, \`add <fact>\`, \`forget <id>\`, \`prune [days]\`.\n`,
			},
		});
	}

	// 2026-05-28: /sbom — scan workspace dependencies for vulnerabilities.
	// Opt-in (oati.sbom.enabled); walks the workspace for manifest files,
	// hands them to runSbom which queries OSV.dev for CVE matches.
	private async runSBOMCommand(_args: string): Promise<void> {
		const cfg = this.opts.settings.config.sbom;
		if (!cfg?.enabled) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "sbom",
					text:
						"## /sbom — disabled\n\nSBOM scanning is off in this workspace. Open Settings → SBOM (or set `oati.sbom.enabled: true`) to enable it. The feature scans your dependency manifests and looks up known CVEs via OSV.dev.\n",
				},
			});
			return;
		}
		if (!this.opts.host) {
			this.bus.send({ type: "error", message: "/sbom: host context not available." });
			return;
		}

		// Manifest globs — keep in sync with the parsers in sbom.ts.
		// Commit 1 only handles package.json; commit 2 adds the rest.
		const MANIFEST_GLOBS = "{**/package.json}";
		const EXCLUDE =
			"{**/node_modules/**,**/.git/**,**/dist/**,**/out/**,**/bin/**,**/obj/**,**/.vscode-test/**}";

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "sbom",
				text: "🔎 Scanning workspace for manifest files…\n",
			},
		});

		const uris = await vscode.workspace.findFiles(MANIFEST_GLOBS, EXCLUDE, 500);
		const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		const manifests: { path: string; content: string }[] = [];
		for (const u of uris) {
			const rel = wsRoot ? nodePath.relative(wsRoot, u.fsPath).replace(/\\/g, "/") : u.fsPath;
			try {
				const content = await this.opts.host.readFile(u.fsPath);
				manifests.push({ path: rel, content });
			} catch (err) {
				this.opts.log?.appendLine(
					`[sbom] could not read ${rel}: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}

		if (manifests.length === 0) {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "sbom",
					text: "No supported manifest files found in the workspace.\n",
				},
			});
			return;
		}

		this.bus.send({
			type: "agent_event",
			event: {
				type: "text_delta",
				agentId: "sbom",
				text: `📦 Querying OSV.dev for ${manifests.length} manifest${manifests.length === 1 ? "" : "s"}…\n`,
			},
		});

		const { runSbom } = await import("./sbom");
		const result = await runSbom({
			cfg,
			manifests,
			...(this.currentAbort ? { signal: this.currentAbort.signal } : {}),
		});

		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "sbom", text: `${result.summary}\n` },
		});
	}

	// 2026-05-27: /ci init [platform] — emits a CI workflow file.
	private async runCICommand(args: string): Promise<void> {
		const cfg = this.opts.settings.config.ci;
		if (cfg?.enabled === false) {
			this.bus.send({
				type: "error",
				message: "/ci: CI integration is disabled in this workspace's settings.",
			});
			return;
		}
		if (!this.opts.host) {
			this.bus.send({ type: "error", message: "/ci: host context not available." });
			return;
		}
		const sub = args.split(/\s+/)[0] ?? "";
		if (sub !== "init") {
			this.bus.send({
				type: "agent_event",
				event: {
					type: "text_delta",
					agentId: "ci",
					text:
						"## /ci — subcommands\n\n- `/ci init [github|gitlab|circleci|azure-pipelines|tfs]` — emit a CI workflow file based on your QA + CI settings\n",
				},
			});
			return;
		}
		const platformArg = (args.split(/\s+/)[1] ?? "").trim();
		const platform =
			platformArg === "github" ||
			platformArg === "gitlab" ||
			platformArg === "circleci" ||
			platformArg === "azure-pipelines" ||
			platformArg === "tfs"
				? (platformArg as import("@oati/shared").CIPlatform)
				: (cfg?.platform ?? "github");

		// Auto-detect hints from package.json / pyproject.toml etc.
		const host = this.opts.host;
		const hints: string[] = [];
		for (const probe of [
			"package.json",
			"pyproject.toml",
			"requirements.txt",
			"pom.xml",
			"build.gradle",
		]) {
			try {
				const c = await host.readFile(probe);
				hints.push(`### ${probe}\n${c.slice(0, 4096)}`);
			} catch {
				/* not present */
			}
		}

		const { buildCIWorkflows } = await import("./ci-init");
		const workflows = buildCIWorkflows({
			cfg: { ...cfg, platform },
			qa: this.opts.settings.config.qa,
			hints,
		});

		const written: string[] = [];
		const errors: { path: string; error: string }[] = [];
		for (const w of workflows) {
			try {
				await host.writeFile(w.path, w.content);
				written.push(w.path);
			} catch (err) {
				errors.push({ path: w.path, error: err instanceof Error ? err.message : String(err) });
			}
		}

		const lines: string[] = [
			`## /ci init — platform: \`${platform}\``,
			"",
			`Wrote ${written.length} workflow file${written.length === 1 ? "" : "s"}:`,
		];
		for (const p of written) lines.push(`- \`${p}\``);
		if (errors.length > 0) {
			lines.push("", "### Write failures");
			for (const e of errors) lines.push(`- \`${e.path}\` — ${e.error}`);
		}
		lines.push(
			"",
			"_Edit the file freely — re-running `/ci init` overwrites it. Tune step inclusion in Settings → CI._",
		);
		this.bus.send({
			type: "agent_event",
			event: { type: "text_delta", agentId: "ci", text: `${lines.join("\n")}\n` },
		});
	}

	/**
	 * Shared "send a user turn through the agent" path used by both the raw
	 * `user_message` RPC and `run_custom_command` (which expands its template
	 * into normal user text before calling here). Centralizing here keeps the
	 * project-memory reload and hook gating in one place.
	 */
	private async runUserTurn(content: string, imageParts?: readonly MessagePart[]): Promise<void> {
		// 2026-05-27: every new turn — including slash commands like
		// /review and /qa — gets a fresh AbortController. Without this,
		// stopping a /review @workspace mid-flight leaves `currentAbort`
		// in the aborted state; the *next* /review @workspace would then
		// see signal.aborted=true on the very first batch and skip every
		// file with reason "cancelled" (the symptom: "0 findings, 125
		// skipped"). The downstream user_message path also resets this
		// later, but slash dispatches happen before that point.
		this.currentAbort = new AbortController();
		// 2026-05-30: reset the auto-verify mutation counter so the
		// next turn's count starts at zero.
		this.mutatingToolCallsThisTurn = 0;

		// Phase 5: `/plan <task>` triggers the planner-v2 propose-and-wait
		// flow. We call planRequest directly (NOT through the conductor's
		// agent loop), stash the result in `currentPlanV2`, and emit
		// `plan_proposed`. The webview's PlanEditor then renders for
		// review; the user clicks Execute (or Cancel) and the matching
		// handler above (plan_execute / plan_cancel) takes over.
		// Surgically inserted here so we don't have to fork runUserTurn
		// downstream — every other path stays unchanged.
		// /test-loop — user-driven entry point for the test-driven loop. Runs
		// `run_tests`; if anything fails, asks for approval and lets the agent
		// attempt a fix iteration. Repeats up to 5 times with per-iteration
		// approval. Lets users opt into automatic test-fix-test from any mode,
		// not just auto-mode.
		if (content.trim() === "/test-loop" || content.trim().startsWith("/test-loop ")) {
			try {
				if (!this.opts.host || !this.opts.tools) {
					this.bus.send({
						type: "error",
						message: "/test-loop: host or tools not wired into this chat panel.",
					});
					return;
				}
				const config = this.opts.settings.config;
				const activeMode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
				const modelIdForLoop = this.opts.providerManager.resolveActiveModelId(config);
				if (!activeMode || !modelIdForLoop) {
					this.bus.send({
						type: "error",
						message: "/test-loop: no active mode or model configured.",
					});
					return;
				}
				this.bus.send({
					type: "agent_event",
					event: {
						type: "text_delta",
						agentId: "tdl",
						text: "▶ /test-loop starting — I'll run the test suite and propose fixes per failure.\n",
					},
				});
				try {
					const tdl = await runWithTests(this.opts.conductor, this.history, {
						mode: activeMode,
						modelId: modelIdForLoop,
						providerId: config.activeProviderId,
						tools: this.opts.tools,
						host: this.opts.host,
						touchedFiles: true,
						bypassAutoModeGate: true,
						requireApprovalBetweenIterations: true,
						log: (m) => this.opts.log?.appendLine(m),
						notifyChat: (text) => {
							this.bus.send({
								type: "agent_event",
								event: { type: "text_delta", agentId: "tdl", text: `${text}\n` },
							});
						},
					});
					if (tdl.history.length !== this.history.length) {
						this.history = [...tdl.history];
						await this.opts.session.save(this.sessionId, this.history);
					}
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] /test-loop failed: ${message}`);
					this.bus.send({ type: "error", message: `/test-loop failed: ${message}` });
				}
			} finally {
				this.signalSlashCommandDone("tdl");
			}
			return;
		}

		// 2026-05-27: /review — runs the code-review subsystem.
		// Usage:
		//   /review                  — reviews files the agent itself wrote in the current session
		//                              (model self-review) PLUS files the developer changed externally
		//                              (via WorkspaceChangeTracker).
		//   /review <path1> <path2>  — reviews specific files
		//   /review @last-turn       — reviews files written in the previous agent turn only
		//   /review @developer       — reviews files the developer changed externally only
		//   /review @model           — reviews files the agent wrote only
		if (content.trim() === "/review" || content.trim().startsWith("/review ")) {
			try {
				await this.runReviewCommand(content.replace(/^\s*\/review\s*/, "").trim());
			} finally {
				this.signalSlashCommandDone("review");
			}
			return;
		}

		// 2026-05-27: /qa SUBCOMMAND — QA testing helpers.
		// Subcommands:
		//   /qa plan <feature>       — writes a TEST_PLAN.md
		//   /qa unit <file|function> — generates unit tests
		//   /qa edge <file|function> — systematic edge-case battery
		//   /qa regression <bug>     — failing test reproducing a bug
		//   /qa coverage             — gap-targeted tests
		//   /qa security <file>      — OWASP-style adversarial tests
		if (content.trim() === "/qa" || content.trim().startsWith("/qa ")) {
			try {
				await this.runQACommand(content.replace(/^\s*\/qa\s*/, "").trim());
			} finally {
				this.signalSlashCommandDone("qa");
			}
			return;
		}

		// 2026-05-27: /ci init [platform] — generates a CI workflow file
		// for the chosen platform (github / gitlab / circleci /
		// azure-pipelines). Reads CIConfig + QAConfig to decide which
		// steps to include.
		if (content.trim() === "/ci" || content.trim().startsWith("/ci ")) {
			try {
				await this.runCICommand(content.replace(/^\s*\/ci\s*/, "").trim());
			} finally {
				this.signalSlashCommandDone("ci");
			}
			return;
		}

		// 2026-05-28: /sbom — scan workspace manifests for vulnerabilities
		// via OSV.dev. Off by default; user must enable via
		// `oati.sbom.enabled`.
		if (content.trim() === "/sbom" || content.trim().startsWith("/sbom ")) {
			try {
				await this.runSBOMCommand(content.replace(/^\s*\/sbom\s*/, "").trim());
			} finally {
				this.signalSlashCommandDone("sbom");
			}
			return;
		}

		// 2026-05-29: /memory — manage the persistent project memory
		// (OATI.md + .oati/facts.json). Subcommands: show, edit, prune,
		// forget <id>, add <fact>. Without args, lists the current state.
		if (content.trim() === "/memory" || content.trim().startsWith("/memory ")) {
			try {
				await this.runMemoryCommand(content.replace(/^\s*\/memory\s*/, "").trim());
			} finally {
				this.signalSlashCommandDone("memory");
			}
			return;
		}

		if (content.trim() === "/plan-mode" || content.trim().startsWith("/plan-mode ")) {
			try {
				this.runPlanModeCommand(content.replace(/^\s*\/plan-mode\s*/, "").trim());
			} finally {
				this.signalSlashCommandDone("plan-mode");
			}
			return;
		}

		if (content.trim() === "/tdd" || content.trim().startsWith("/tdd ")) {
			try {
				this.runTddCommand(content.replace(/^\s*\/tdd\s*/, "").trim());
			} finally {
				this.signalSlashCommandDone("tdd");
			}
			return;
		}

		if (content.trim().startsWith("/plan ") || content.trim() === "/plan") {
			try {
				const task = content.replace(/^\s*\/plan\s*/, "").trim();
				if (task.length === 0) {
					this.bus.send({
						type: "error",
						message:
							"/plan: provide a task after the command, e.g. `/plan rename foo to bar across the codebase`.",
					});
					return;
				}
				const config = this.opts.settings.config;
				const provider = this.opts.providerManager.registry.get(config.activeProviderId);
				if (!provider) {
					this.bus.send({
						type: "error",
						message: `/plan: no active provider (id=${config.activeProviderId})`,
					});
					return;
				}
				const modelId = this.opts.providerManager.resolveActiveModelId(config);
				try {
					const plan = await planRequest({
						provider,
						modelId,
						userTask: task,
					});
					this.currentPlanV2 = plan;
					this.bus.send({ type: "plan_proposed", plan });
				} catch (err) {
					const message = err instanceof Error ? err.message : String(err);
					this.opts.log?.appendLine(`[chat-panel] /plan failed: ${message}`);
					this.bus.send({
						type: "error",
						message: `/plan failed: ${message}`,
					});
				}
			} finally {
				this.signalSlashCommandDone("plan");
			}
			return;
		}

		// UserPromptSubmit runs before anything else so a blocking hook can refuse
		// the turn entirely. Any verdict.allow:false is a hard stop — no history
		// mutation, no agent spawn.
		const verdict = await this.hookRunner.runUserPromptSubmit(content);
		if (!verdict.allow) {
			const reason = verdict.reason ?? "Blocked by UserPromptSubmit hook";
			this.opts.log?.appendLine(`[chat-panel] user_message blocked: ${reason}`);
			this.bus.send({ type: "error", message: reason });
			return;
		}
		// R8-E: v2 UserPromptSubmit. Runs after the legacy hook (R1 already had
		// this event so we keep that order for backward compat). A v2 hook
		// returning a `modifiedPayload.text` rewrites the prompt going forward;
		// `blockOnFailure: true` halts the turn entirely.
		let mutableContent = content;
		const v2PromptVerdict = await this.fireHookV2({
			kind: "UserPromptSubmit",
			payload: { text: mutableContent },
		});
		if (!v2PromptVerdict.allow) {
			const reason = v2PromptVerdict.reason ?? "Blocked by UserPromptSubmit hook (v2)";
			this.opts.log?.appendLine(`[chat-panel] R8-E UserPromptSubmit(v2) blocked: ${reason}`);
			this.bus.send({ type: "error", message: reason });
			return;
		}
		if (
			v2PromptVerdict.payload &&
			typeof (v2PromptVerdict.payload as { text?: unknown }).text === "string" &&
			(v2PromptVerdict.payload as { text: string }).text !== mutableContent
		) {
			mutableContent = (v2PromptVerdict.payload as { text: string }).text;
			this.opts.log?.appendLine("[chat-panel] R8-E UserPromptSubmit(v2) rewrote prompt content");
		}
		// Use `effectiveContent` from here on so a v2 hook that rewrote the
		// prompt actually changes what the agent sees. We don't reassign the
		// `content` parameter (biome `noParameterAssign`); locals are fine.
		const effectiveContent = mutableContent;

		this.currentAbort = new AbortController();
		const config = this.opts.settings.config;
		const baseMode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
		if (!baseMode) {
			this.opts.log?.appendLine("[chat-panel] user_message rejected: no mode");
			this.bus.send({ type: "error", message: "No agent mode configured" });
			return;
		}
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		if (!modelId) {
			this.opts.log?.appendLine(
				`[chat-panel] user_message rejected: no model for provider ${config.activeProviderId}`,
			);
			this.bus.send({
				type: "error",
				message: "No model configured. Open OATI: Open Settings and set a Model ID.",
			});
			return;
		}

		// Policy gating — refuse early when the active provider / model / mode
		// is denied by `.oati/policy.yaml`. We surface a clear "blocked by policy"
		// error rather than a confusing downstream failure.
		if (!isProviderAllowed(this.policy, config.activeProviderId)) {
			const message = `Provider '${config.activeProviderId}' blocked by .oati/policy.yaml`;
			this.opts.log?.appendLine(`[chat-panel] ${message}`);
			this.bus.send({ type: "error", message });
			return;
		}
		if (!isModelAllowed(this.policy, modelId)) {
			const message = `Model '${modelId}' blocked by .oati/policy.yaml`;
			this.opts.log?.appendLine(`[chat-panel] ${message}`);
			this.bus.send({ type: "error", message });
			return;
		}
		if (!isModeAllowed(this.policy, baseMode.id)) {
			const message = `Mode '${baseMode.id}' blocked by .oati/policy.yaml`;
			this.opts.log?.appendLine(`[chat-panel] ${message}`);
			this.bus.send({ type: "error", message });
			return;
		}

		// R5-E: per-model budget — gate BEFORE the global budget check so a
		// (provider, model)-specific cap can refuse dispatch even when the
		// session/day pots have room. Uses the currently active mode's model
		// (or the provider's default) as the lookup key.
		{
			const cfgForBudget = this.opts.settings.config;
			const activeProviderId =
				cfgForBudget.modes.find((m) => m.id === cfgForBudget.activeModeId)?.providerId ??
				cfgForBudget.activeProviderId;
			const activeModelId = this.opts.providerManager.resolveActiveModelId(cfgForBudget);
			const perModelVerdict = await this.perModelBudget.checkPerModelBudget(
				cfgForBudget.modelBudgets,
				activeProviderId,
				activeModelId,
			);
			if (!perModelVerdict.allowed) {
				const reason = perModelVerdict.reason ?? "Per-model budget exceeded.";
				this.opts.log?.appendLine(`[chat-panel] per-model budget blocked: ${reason}`);
				this.bus.send({ type: "error", message: reason });
				return;
			}
		}

		// Budget gating — refuse before dispatch if the per-session hard cap or
		// per-day org cap is already exhausted. The Budget controller surfaces a
		// human-readable reason.
		const dispatchVerdict = await this.budget.checkDispatch();
		if (dispatchVerdict.kind === "blocked") {
			this.opts.log?.appendLine(`[chat-panel] budget blocked: ${dispatchVerdict.reason}`);
			this.bus.send({ type: "error", message: dispatchVerdict.reason });
			return;
		}

		// Re-read project memory + persistent facts on every turn so users can
		// edit OATI.md and `.oati/facts.json` and have the next prompt see the
		// new content without restarting the extension.
		const workspacePath = getPrimaryWorkspacePath();
		// Three-tier memory: global (~/.oati/OATI.md) → project (.oati/OATI.md)
		// → facts. The global tier is prepended so user-wide preferences win
		// before project-specific context, matching Claude's CLAUDE.md
		// hierarchy.
		const [globalMemory, memory] = await Promise.all([
			loadGlobalMemory(),
			workspacePath ? loadProjectMemory(workspacePath) : Promise.resolve(undefined),
		]);
		const facts = workspacePath ? await loadFacts(workspacePath) : [];
		const globalMemoryText = globalMemory
			? `## Global user preferences (from ${globalMemory.path})\n${globalMemory.content}`
			: "";
		const memoryText = memory?.content ?? "";
		const factsSection =
			facts.length > 0 ? `## Persistent facts\n${facts.map((f) => `- ${f.fact}`).join("\n")}` : "";
		// R5-B: rules — load `.oati/rules.md` + per-language `rules.<lang>.md`
		// and prepend them to the prelude. Active language is derived from the
		// editor's active document (when available) so the right language
		// bucket is picked up without the user having to configure anything.
		let rulesSection = "";
		try {
			if (workspacePath) {
				const loadedRules = await loadRules(workspacePath);
				const activeLang = vscode.window.activeTextEditor?.document.languageId;
				rulesSection = assembleRulesPrelude(loadedRules, activeLang);
			}
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] R5-B rules load skipped: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		// R5-B: rules end
		// R5-D: persona — prepend the active persona's addendum (when any) so it
		// layers atop project memory + facts before the mode's own system prompt.
		const personaPrelude = assemblePersonaPrelude(await this.opts.session.getPersona(this.sessionId));
		// R8-E: skills — surface any skill whose `triggers` match the (possibly
		// rewritten) user prompt so the agent knows it can `load_skill` to fetch
		// the playbook. The body itself is NOT inlined — only a one-liner per
		// matched skill goes into the prelude.
		let skillsSection = "";
		try {
			const allSkills = await this.ensureSkills();
			const matched = matchSkills(allSkills, effectiveContent);
			skillsSection = assembleSkillsPrelude(matched);
			if (matched.length > 0) {
				this.opts.log?.appendLine(
					`[chat-panel] R8-E skills matched: ${matched.map((s) => s.name).join(", ")}`,
				);
			}
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] R8-E skills match skipped: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		// 2026-05-29: remember_fact usage nudge. The tool's been around for
		// a while but the model rarely calls it because it's one of 76+
		// tools competing for attention in the schema. A tiny, action-
		// oriented prompt section makes it part of the routine: when you
		// learn a stable fact about THIS project (test framework, file
		// conventions, the user's strong preferences), call
		// `remember_fact` so the knowledge survives session boundaries.
		// Kept under 200 tokens so it doesn't bloat the prelude.
		const memoryUsageNudge = [
			"## Persistent memory",
			"",
			"You have a `remember_fact` tool. When you discover something STABLE about this project that will matter next session — the test framework, naming conventions, the user's strong preferences, integration quirks — call `remember_fact` with a one-line summary. Don't hoard knowledge in a single session; persist it.",
			"",
			'Good targets: "Tests run via vitest", "The backend lives in packages/server", "The user prefers descriptive names over short ones", "MUI v5 (not v4) — keep imports under @mui/material".',
			"",
			'Bad targets: anything turn-specific ("we just edited foo.ts"), anything obvious from the workspace structure, anything you\'re not confident is true.',
		].join("\n");

		// 2026-05-29: refactor pattern nudge. When the user asks for any
		// change that touches more than one file (rename a symbol, change
		// an import path, swap a library version, update a config value
		// everywhere), the model historically issued N separate write_file
		// calls — each its own approval, each its own chance to fail. The
		// `batch_file_edit` tool lets the model declare the whole intent
		// in ONE call: a list of (path, before, after) entries. This nudge
		// teaches the model to recognize the pattern.
		const refactorNudge = [
			"## Multi-file refactors",
			"",
			"When the user's request involves the SAME conceptual change across multiple files (rename `parseFoo` → `parseBar` everywhere, swap an import path, update a config value in every package, switch a library version, etc.), prefer ONE `batch_file_edit` call over N separate `write_file` calls. It's faster, lands as a single user approval, and the result is auditable in one place.",
			"",
			"`batch_file_edit` takes a list of `{ path, before, after }` entries. Each `before` must match exactly once per file — include enough surrounding context so the match is unambiguous. Failed entries (no match / multiple matches) come back in the result; you can fix them on the next iteration without losing the entries that succeeded.",
			"",
			"Use `write_file` for first-time file creation and for changes that aren't a clean find-and-replace. Use `batch_file_edit` when the same kind of edit applies to multiple files at once.",
		].join("\n");

		// 2026-05-30: code-graph awareness. The find_references /
		// find_definition / symbols_in_file tools exist but the model
		// rarely reaches for them — it grep-and-edits blindly, which is
		// how broken downstream callers slip through after a rename. This
		// nudge teaches the model to use the LSP-backed tools before any
		// symbol-level change, and points it at batch_file_edit for the
		// follow-up.
		const codeGraphNudge = [
			"## Before renaming or removing a symbol",
			"",
			"Run `find_references` on the symbol FIRST. Treat the result as the work-list: every site needs the corresponding edit, or you'll ship broken callers. `find_definition` resolves the original declaration; `symbols_in_file` enumerates everything in a file when you need a quick map. These are LSP-backed and far more accurate than a `grep_search` on the bare name (which misses scoped variables and includes string-literal hits).",
			"",
			"For cross-file edits driven by the reference list, prefer `batch_file_edit` over a series of `write_file` calls — see the multi-file refactors section above.",
		].join("\n");

		// 2026-05-29: per-turn workflow nudges, gated by panel-level toggles.
		// `/plan-mode` and `/tdd` flip these flags; the nudges only render when
		// they'd actually change behavior so we don't waste prompt budget.
		const planNudge = shouldInjectPlanNudge(this.planMode, effectiveContent) ? PLAN_NUDGE : "";
		const tddNudge = shouldInjectTddNudge(this.tddMode) ? TDD_NUDGE : "";

		const prelude = [
			personaPrelude,
			rulesSection,
			skillsSection,
			globalMemoryText,
			memoryText,
			factsSection,
			memoryUsageNudge,
			refactorNudge,
			codeGraphNudge,
			planNudge,
			tddNudge,
		]
			.filter((s) => s.length > 0)
			.join("\n\n");

		// Secret-scan the outbound payload BEFORE building optimistic history —
		// check both the user message and the rendered system prompt (with
		// memory + facts) so an inlined AWS key anywhere still gets caught.
		// Default behavior is "redact and send" without blocking.
		// Per-model addendum — Kimi K2 / Qwen / Gemma need explicit
		// "args must be a JSON object" + terseness reminders that frontier
		// models don't. The registry lives in @oati/shared/model-quirks.
		const modelAddendum = buildModelPromptAddendum(modelId);
		const renderedSystem = `${prelude ? `${prelude}\n\n---\n\n${baseMode.systemPrompt}` : baseMode.systemPrompt}\n\n${CONCLUSION_GUIDANCE}${modelAddendum ? `\n\n${modelAddendum}` : ""}`;
		const scanned = await this.scanAndConfirm(effectiveContent, renderedSystem);
		if (scanned.kind === "cancel") {
			this.opts.log?.appendLine("[chat-panel] user cancelled after secret warning");
			return;
		}
		const safeContent = scanned.content;
		const safeSystemPrompt = scanned.systemPrompt;

		const mode = { ...baseMode, systemPrompt: safeSystemPrompt };

		// 2026-05-26: workspace-change awareness — drain any files that
		// changed on disk since the previous turn ended (manual edits, git
		// pull, external formatters) and prepend a tagged heads-up so the
		// model knows its mental model may be stale. Empty buffer is a
		// no-op; agent-written paths are excluded (caller marks those at
		// the end of each turn).
		let safeContentForTurn = safeContent;
		const tracker = this.opts.workspaceChangeTracker;
		if (tracker) {
			const externalChanges = tracker.drainSinceLastTurn();
			if (externalChanges.length > 0) {
				const note = formatChangesAsSystemNote(externalChanges);
				if (note) {
					safeContentForTurn = `${note}\n\n${safeContentForTurn}`;
					this.opts.log?.appendLine(
						`[chat-panel] workspace heads-up: ${externalChanges.length} external file change(s) injected into turn`,
					);
				}
			}
		}
		// 2026-05-26: diagnostics feedback loop. When tests/typecheck fail
		// between turns the new errors get surfaced at the top of the next
		// user message so the agent sees them without the user pasting.
		// Only NEW entries (not present at prior turn end) are injected;
		// pre-existing ones the model already saw are not re-pushed.
		if (this.diagnosticsFeedback) {
			try {
				const newDiags = await this.diagnosticsFeedback.drainNewSince();
				if (newDiags.length > 0) {
					const diagNote = formatDiagnosticsAsSystemNote(newDiags);
					if (diagNote) {
						safeContentForTurn = `${diagNote}\n\n${safeContentForTurn}`;
						this.opts.log?.appendLine(
							`[chat-panel] diagnostics heads-up: ${newDiags.length} new diagnostic(s) injected into turn`,
						);
					}
				}
			} catch (err) {
				this.opts.log?.appendLine(
					`[chat-panel] diagnostics feedback drain failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}

		// Save the user message to the session right away so the sidebar title
		// and message count update immediately rather than after the agent run.
		const userParts: MessagePart[] = [{ kind: "text", text: safeContentForTurn }];
		if (imageParts) for (const p of imageParts) userParts.push(p);
		const optimisticHistory: ConversationMessage[] = [
			...this.history,
			{ role: "user", parts: userParts },
		];
		this.history = optimisticHistory;
		await this.opts.session.save(this.sessionId, this.history);
		this.panel.title = await this.computeTitle();
		this.opts.onSessionIndexChanged();

		// R4-E: open a perf turn keyed by the user-message ui id. We use the
		// same `userMessageIdForIndex` shape the webview renders so the inline
		// "(in 4.2s)" badge can look the turn up by message id.
		this.currentTurnMsgId = `u_h${optimisticHistory.length - 1}`;
		this.perf.markTurnStart(this.sessionId, this.currentTurnMsgId, Date.now(), modelId);

		// Audit the user message (hash-only — no raw content stored).
		void this.auditLog.record({
			kind: "message",
			ts: nowIso(),
			sessionId: this.sessionId,
			role: "user",
			contentHash: shortHash(safeContent),
			contentBytes: safeContent.length,
			tokenCount: estimateTokens(safeContent),
		});

		// R3-B: model router — pick a provider/model for THIS turn based on the
		// optional `routing` config. When routing is disabled (or unconfigured)
		// `route` is the legacy defaults so the rest of the code path is
		// identical. We also strip a leading `/route fast|slow` override off
		// the prompt so it doesn't leak into the LLM context.
		const overrideParse = parseRouteOverride(safeContent);
		const routedContent = overrideParse.remainingPrompt;
		const route = this.pickRoute(
			routedContent,
			optimisticHistory.slice(0, -1),
			overrideParse.override,
		);
		if (!route.isDefault) {
			this.bus.send({
				type: "route_decision",
				providerId: route.providerId,
				...(route.model ? { model: route.model } : {}),
				reason: route.reason,
			});
			this.opts.log?.appendLine(
				`[chat-panel] R3-B route: provider=${route.providerId} model=${route.model ?? "(default)"} (${route.reason})`,
			);
		}
		// R3-B: model router end

		// R4-B: diagnostics context — when the workspace has open errors, prepend
		// a one-line note to the system prompt so the agent knows to consider
		// running `get_diagnostics`. Capped at MAX_DIAG_CONTEXT chars so a flood
		// of LSP messages can't blow the prompt window. Silently skipped when
		// `errors === 0` or when the host has no diagnostics bridge.
		let effectiveMode = mode;
		try {
			if (this.opts.host?.diagnostics) {
				const all = await this.opts.host.diagnostics.all();
				let errors = 0;
				let warnings = 0;
				for (const d of all) {
					if (d.severity === "error") errors++;
					else if (d.severity === "warning") warnings++;
				}
				if (errors > 0) {
					const MAX_DIAG_CONTEXT = 200;
					const note = `Current workspace diagnostics: ${errors} errors, ${warnings} warnings. Use \`get_diagnostics\` if relevant.`;
					const capped = note.length > MAX_DIAG_CONTEXT ? note.slice(0, MAX_DIAG_CONTEXT) : note;
					effectiveMode = { ...mode, systemPrompt: `${capped}\n\n${mode.systemPrompt}` };
				}
			}
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] R4-B diagnostics context skipped: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		// R4-B: diagnostics context end
		// R5-B: knowledge RAG — when the user query is non-trivial and the
		// knowledge store has at least one indexed doc, query top-4 chunks and
		// prepend them as a "Relevant project knowledge:" block. Hard-capped at
		// MAX_KNOWLEDGE_CONTEXT chars total so a verbose doc can't blow the
		// context budget. Best-effort: any failure is logged and skipped.
		try {
			const store = this.opts.knowledgeStore;
			if (store && routedContent.trim().length > 30 && store.docs() > 0) {
				const MAX_KNOWLEDGE_CONTEXT = 2000;
				const hits = await store.search(routedContent, 4);
				if (hits.length > 0) {
					const lines: string[] = ["Relevant project knowledge:"];
					let used = lines[0].length;
					for (const h of hits) {
						const block = `\n- ${h.path}\n${h.snippet}`;
						if (used + block.length > MAX_KNOWLEDGE_CONTEXT) break;
						lines.push(block);
						used += block.length;
					}
					const note = lines.join("");
					effectiveMode = {
						...effectiveMode,
						systemPrompt: `${note}\n\n${effectiveMode.systemPrompt}`,
					};
				}
			}
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] R5-B knowledge RAG skipped: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		// R5-B: knowledge RAG end

		const effectiveProviderId = route.providerId;
		const effectiveModelId = route.model ?? modelId;

		const startedAt = Date.now();
		this.opts.log?.appendLine(
			`[chat-panel] agent run starting (session=${this.sessionId}, mode=${mode.id}, model=${effectiveModelId}, history=${this.history.length}, memory=${memory ? "yes" : "no"}, images=${imageParts?.length ?? 0}, prompt=${truncate(safeContent, 80)})`,
		);
		try {
			// Track write_file calls so the auto*-mode test-driven loop knows whether
			// the turn touched files. Negligible overhead when not in auto mode.
			let touchedFiles = false;
			// R5-E: collect the workspace-relative paths written during this turn so
			// AutoRevertGuard can snapshot/restore them if a regression appears.
			const writtenPaths: string[] = [];
			// 2026-05-26: per-file new-vs-modified classification for the
			// post-turn "Changed files" chip strip. We capture this at the
			// moment the tool_call event fires (BEFORE the write happens),
			// because once the file is on disk we'd misclassify "new" as
			// "modified". Map keyed by path so the same path written twice
			// in a turn keeps its FIRST classification (which is correct).
			const fileKinds = new Map<string, "new" | "modified">();
			// Phase 3.2: eager per-turn snapshot capture. When the agent emits
			// `turn_start` we register the turnId with AutoRevertGuard (empty
			// path set). As `write_file` tool calls fire during the turn we
			// extend the snapshot incrementally — start() is idempotent for
			// the same turnId and only appends paths not yet seen. This makes
			// every turn rollback-able via the `revert_turn` RPC, not just
			// turns that tripped the auto-revert-on-test-failure path.
			let currentTurnId: string | undefined;
			// 2026-05-26: in-flight snapshot. Accumulates the assistant'\''s
			// streaming text so a periodic save can persist it BEFORE the
			// turn completes. Without this, a webview reload or extension
			// crash during a long agent reply loses every token streamed
			// since the user message. Reset on each `message_end`.
			let inFlightAssistantText = "";
			const startSnapshotTimer = (): NodeJS.Timeout =>
				setInterval(() => {
					if (inFlightAssistantText.length === 0) return;
					const inFlightHistory: ConversationMessage[] = [
						...this.history,
						{
							role: "assistant",
							parts: [{ kind: "text", text: inFlightAssistantText }],
						},
					];
					this.opts.session.save(this.sessionId, inFlightHistory).catch((err) => {
						this.opts.log?.appendLine(
							`[chat-panel] in-flight snapshot save failed: ${err instanceof Error ? err.message : String(err)}`,
						);
					});
				}, 5000);
			let snapshotTimer: NodeJS.Timeout | undefined;
			const offWatch = this.opts.conductor.on((ev) => {
				if (ev.type === "text_delta") {
					inFlightAssistantText += ev.text;
				} else if (ev.type === "iteration" || ev.type === "turn_end") {
					// One assistant message just landed in history (the
					// agent's per-iteration commit). Reset the in-flight
					// buffer so the next iteration starts fresh.
					inFlightAssistantText = "";
				}
				if (ev.type === "turn_start") {
					currentTurnId = ev.turnId;
					if (!snapshotTimer) snapshotTimer = startSnapshotTimer();
					// Eagerly register the turnId so subsequent start() calls
					// merge into a single snapshot under this id.
					void this.autoRevert.start(ev.turnId, []).catch((err: unknown) => {
						this.opts.log?.appendLine(
							`[chat-panel] auto-revert turn_start failed: ${err instanceof Error ? err.message : String(err)}`,
						);
					});
				} else if (ev.type === "tool_call" && ev.call.name === "write_file") {
					touchedFiles = true;
					const a = ev.call.args as { path?: unknown } | null | undefined;
					if (a && typeof a.path === "string") {
						writtenPaths.push(a.path);
						// 2026-05-26: classify new vs modified BEFORE the write
						// hits disk. fileExists is async but we don't need to
						// await it for snapshotting; fire-and-forget keyed by
						// the path. First-write wins (matches "what was the
						// state at the start of this turn?" semantics).
						if (!fileKinds.has(a.path)) {
							const pathForClassify = a.path;
							const hostForClassify = this.opts.host;
							if (hostForClassify) {
								void hostForClassify
									.fileExists(pathForClassify)
									.then((exists) => {
										if (!fileKinds.has(pathForClassify)) {
											fileKinds.set(pathForClassify, exists ? "modified" : "new");
										}
									})
									.catch(() => {
										/* default to "modified" if existence check fails */
										if (!fileKinds.has(pathForClassify)) {
											fileKinds.set(pathForClassify, "modified");
										}
									});
							} else {
								// No host available (test path / non-VS Code embed) — default
								// to "modified" so the chip still appears with reasonable
								// styling.
								fileKinds.set(pathForClassify, "modified");
							}
						}
						// Capture the pre-image NOW (before the write happens
						// at handler-execution time downstream). Idempotent
						// per-path; no-op if we've already snapshotted this file.
						if (currentTurnId) {
							const turnIdForCapture = currentTurnId;
							void this.autoRevert.start(turnIdForCapture, [a.path]).catch((err: unknown) => {
								this.opts.log?.appendLine(
									`[chat-panel] auto-revert per-write snapshot failed: ${err instanceof Error ? err.message : String(err)}`,
								);
							});
						}
					}
				}
			});
			let updated: readonly ConversationMessage[];
			try {
				updated = await this.spawnWithRateLimitFallback({
					// R4-B: diagnostics context — `effectiveMode` is `mode` with an
					// optional one-line diagnostics note prepended; identical to
					// `mode` when the workspace has no open errors.
					mode: effectiveMode,
					providerId: effectiveProviderId,
					modelId: effectiveModelId,
					content: routedContent,
					history: optimisticHistory.slice(0, -1),
					...(imageParts && imageParts.length > 0 ? { imageParts } : {}),
					signal: this.currentAbort.signal,
				});
			} finally {
				offWatch();
				// 2026-05-26: stop in-flight snapshot timer. Normal turn-end
				// saves below pick up the canonical history.
				if (snapshotTimer) {
					clearInterval(snapshotTimer);
					snapshotTimer = undefined;
				}
				// 2026-05-26: emit the per-turn changed-files list to the
				// webview. The chip strip below the assistant bubble lets the
				// user open each file (new) or its diff vs pre-turn state
				// (modified). Only fires when there's at least one write; a
				// turn that didn't touch files doesn't get an empty strip.
				if (currentTurnId && writtenPaths.length > 0) {
					const seen = new Set<string>();
					const files: Array<{ path: string; kind: "new" | "modified" }> = [];
					for (const p of writtenPaths) {
						if (seen.has(p)) continue;
						seen.add(p);
						files.push({ path: p, kind: fileKinds.get(p) ?? "modified" });
					}
					this.bus.send({ type: "turn_files_changed", turnId: currentTurnId, files });
				}
				// 2026-05-26: hand the agent-written paths to the workspace
				// change tracker so the auto-save events the editor fires
				// (Format-on-Save, hot reloaders, etc.) for those same
				// paths are NOT re-flagged as external changes on the next
				// turn. Reset window per turn.
				if (this.opts.workspaceChangeTracker) {
					this.opts.workspaceChangeTracker.markAgentWrites(writtenPaths);
				}
				// 2026-05-27: remember the model's writes for /review @model.
				// Replaces (not appends) on each turn so the list always
				// reflects the MOST RECENT turn's work.
				this.lastModelWrittenPaths = [...writtenPaths];
			}
			this.history = [...updated];
			// 2026-05-27: auto-review + auto-QA hooks. Fire on the same
			// turn-end point as the test-driven loop, but gated separately:
			// the user can have one on, both on, or neither.
			void this.maybeAutoReview(writtenPaths, config).catch((err) => {
				this.opts.log?.appendLine(
					`[chat-panel] auto-review failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			});
			void this.maybeAutoGenerateTests(writtenPaths, config, modelId).catch((err) => {
				this.opts.log?.appendLine(
					`[chat-panel] auto-test-gen failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			});
			// Auto*-mode test-driven loop: after the agent's turn, re-run the suite
			// and let it iterate on failures. Guarded behind autoApprove so non-auto
			// modes never trigger background test runs.
			if (mode.autoApprove && this.opts.host && this.opts.tools && touchedFiles) {
				const tdl = await runWithTests(this.opts.conductor, this.history, {
					mode,
					modelId,
					providerId: config.activeProviderId,
					signal: this.currentAbort.signal,
					tools: this.opts.tools,
					host: this.opts.host,
					touchedFiles: true,
					log: (m) => this.opts.log?.appendLine(m),
					notifyChat: (text) => {
						this.bus.send({
							type: "agent_event",
							event: { type: "text_delta", agentId: "tdl", text: `${text}\n` },
						});
					},
				}).catch((err) => {
					this.opts.log?.appendLine(`[chat-panel] test-driven loop failed: ${err}`);
					return undefined;
				});
				if (tdl) this.history = [...tdl.history];

				// R5-E: auto-revert safety net. When `oati.autoRevert.enabled` is on
				// AND the test-driven loop reports NEW failures (regressions), undo
				// the file writes from this turn via WorkspaceEdit so the workspace
				// returns to its pre-turn shape. Opt-in (default false) and gated
				// behind autoApprove so non-auto modes never trip it.
				try {
					const ar = vscode.workspace.getConfiguration("oati.autoRevert");
					const arEnabled = ar.get<boolean>("enabled", false);
					const arRequireTests = ar.get<boolean>("requireTests", true);
					if (arEnabled && writtenPaths.length > 0 && tdl) {
						if (arRequireTests && !tdl.testsRan) {
							this.opts.log?.appendLine(
								"[chat-panel] auto-revert: tests did not run; skipping (requireTests=true).",
							);
						} else if (tdl.finalFailures.length > 0) {
							// We don't have pre-turn failures available here (the TDL helper
							// doesn't surface a baseline); treat any final failure under
							// auto-revert.enabled as a regression suspect. The
							// `newFailures` helper exists for callers that DO have a
							// baseline (e.g. future enhancements).
							const turnId = `tdl_${this.sessionId}_${startedAt}`;
							await this.autoRevert.start(turnId, writtenPaths);
							const restored = await this.autoRevert.revert(
								turnId,
								`test failures after turn: ${tdl.finalFailures.length}`,
							);
							if (restored.length > 0) {
								const sysText = `↩︎ Auto-reverted ${restored.length} file(s) because tests failed after this turn: ${restored.join(", ")}`;
								this.opts.log?.appendLine(`[chat-panel] ${sysText}`);
								const updatedUi = [
									...conversationToUiMessages(this.history),
									{
										id: `sys_revert_${this.nextSystemMessageId++}`,
										role: "system" as const,
										text: sysText,
									},
								];
								this.bus.send({ type: "restore_session", messages: updatedUi });
								// Defensive: include a `newFailures` reference so the import isn't shaken out.
								void newFailures;
							}
						}
					}
				} catch (err) {
					this.opts.log?.appendLine(
						`[chat-panel] auto-revert failed: ${err instanceof Error ? err.message : String(err)}`,
					);
				}
			}
			await this.opts.session.save(this.sessionId, this.history);
			this.panel.title = await this.computeTitle();
			this.opts.onSessionIndexChanged();
			// Audit the final assistant turn so the log includes the full round-trip.
			const last = this.history[this.history.length - 1];
			if (last && last.role === "assistant") {
				const text = stringifyAssistantText(last);
				void this.auditLog.record({
					kind: "message",
					ts: nowIso(),
					sessionId: this.sessionId,
					role: "assistant",
					contentHash: shortHash(text),
					contentBytes: text.length,
					tokenCount: estimateTokens(text),
				});
			}
			this.opts.log?.appendLine(
				`[chat-panel] agent run done (${Date.now() - startedAt}ms, history=${this.history.length})`,
			);
			// R4-E: close the perf turn on success.
			if (this.currentTurnMsgId !== undefined) {
				this.perf.markTurnEnd(this.sessionId);
				this.currentTurnMsgId = undefined;
			}
			// R5-C: fact promoter — auto-extract one insight per assistant turn
			// into .oati/facts.json. Auto-modes only so manual flows stay
			// in the user's control.
			if (mode.autoApprove && last && last.role === "assistant") {
				const wsRoot = getPrimaryWorkspacePath();
				if (wsRoot) {
					const { promoteFactIfAny } = await import("./fact-promoter");
					void promoteFactIfAny({ workspaceRoot: wsRoot, reply: stringifyAssistantText(last) });
				}
			}

			// 2026-05-29: LLM-driven memory auto-extract. Complements the
			// regex fact-promoter (R5-C) — the regex catches "Note that…"
			// patterns in auto-mode; this runs in INTERACTIVE modes after
			// a turn that did real work, asks the model for 0-2 stable
			// facts about the project, and surfaces them as one-click
			// chips for the user to approve. Fires as a sidecar (doesn't
			// block save / title update); failure silently no-ops.
			const memCfg = vscode.workspace.getConfiguration("oati.memory.autoExtract");
			if (!mode.autoApprove && memCfg.get<boolean>("enabled", true) && this.opts.host) {
				const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
				const provider = this.opts.providerManager.registry.get(effectiveProviderId);
				if (wsRoot && provider) {
					const historySnapshot = [...this.history];
					void (async () => {
						try {
							const { turnHasMutation, extractMemorySuggestions } = await import("./memory-extractor");
							if (!turnHasMutation(historySnapshot)) return;
							const existing = await loadFacts(wsRoot);
							const suggestions = await extractMemorySuggestions({
								provider,
								modelId: effectiveModelId,
								history: historySnapshot,
								existingFacts: existing.map((f) => f.fact),
							});
							if (suggestions.length > 0) {
								this.bus.send({
									type: "memory_suggestions",
									items: suggestions,
								});
							}
						} catch (err) {
							this.opts.log?.appendLine(
								`[chat-panel] memory auto-extract failed: ${err instanceof Error ? err.message : String(err)}`,
							);
						}
					})();
				}
			}
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.opts.log?.appendLine(`[chat-panel] agent run failed: ${message}`);
			this.bus.send({ type: "error", message });
			// R4-E: still close the turn on failure so the duration is captured.
			if (this.currentTurnMsgId !== undefined) {
				this.perf.markTurnEnd(this.sessionId);
				this.currentTurnMsgId = undefined;
			}
		}
	}

	/**
	 * Run the secret-scanner over the outbound message and (when matches exist)
	 * confirm the user's choice via a `secret_warning` banner. Default behavior
	 * is "redact and send" — we don't block by default. When the webview never
	 * replies (e.g. closed during a long agent run) we treat that as "redact".
	 */
	private async scanAndConfirm(
		content: string,
		systemPrompt: string,
	): Promise<
		| { readonly kind: "ok"; readonly content: string; readonly systemPrompt: string }
		| { readonly kind: "cancel" }
	> {
		// Scan both halves of the outbound payload — user message AND the
		// rendered system prompt (which carries project memory contents).
		const userScan = redactSecrets(content);
		const sysScan = redactSecrets(systemPrompt);
		const allMatches: SecretMatch[] = [...userScan.matches, ...sysScan.matches];
		if (allMatches.length === 0) {
			return { kind: "ok", content, systemPrompt };
		}
		const summary = summarizeMatches(allMatches);
		this.opts.log?.appendLine(
			`[chat-panel] secret-scan detected ${allMatches.length} match(es): ${summary}`,
		);
		const id = `sec_${this.nextSecretId++}`;
		const matchSummaries: SecretMatchSummary[] = allMatches.map((m) => ({
			kind: m.kind,
			preview: m.preview,
		}));
		// Wait for the webview's choice, but fall back to "redact" after a
		// short timeout so a closed/hung webview doesn't deadlock the flow.
		const choice = await new Promise<"send" | "redact" | "cancel">((resolve) => {
			this.pendingSecretConfirms.set(id, resolve);
			this.bus.send({ type: "secret_warning", id, summary, matches: matchSummaries });
			// R8-E: fan a v2 Notification so user-defined hooks can mirror the
			// banner to Slack / OS notifications without subscribing to the
			// full event stream.
			void this.fireHookV2({
				kind: "Notification",
				payload: { kind: "secret_warning", title: "Secret detected", body: summary },
			});
			setTimeout(() => {
				const r = this.pendingSecretConfirms.get(id);
				if (r) {
					this.pendingSecretConfirms.delete(id);
					r("redact");
				}
			}, 10_000);
		});
		if (choice === "cancel") return { kind: "cancel" };
		if (choice === "send") {
			// Send original content verbatim — user explicitly overrode the safety net.
			return { kind: "ok", content, systemPrompt };
		}
		// "redact" (default) — substitute every match with [REDACTED:KIND].
		return { kind: "ok", content: userScan.redacted, systemPrompt: sysScan.redacted };
	}

	private async recordToolAudit(
		toolName: string,
		output: unknown,
		isError: boolean,
		durationMs: number,
	): Promise<void> {
		const config = this.opts.settings.config;
		const mode = config.modes.find((m) => m.id === config.activeModeId);
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		const serialized = typeof output === "string" ? output : JSON.stringify(output ?? "");
		await this.auditLog.record({
			kind: "tool",
			ts: nowIso(),
			sessionId: this.sessionId,
			mode: mode?.id ?? "",
			modelId,
			toolName,
			argsHash: hashArgs(output),
			resultBytes: serialized.length,
			isError,
			durationMs,
		});
	}

	// R3-B: model router — choose the provider/model for this turn.
	private pickRoute(
		prompt: string,
		history: readonly ConversationMessage[],
		override: "fast" | "slow" | undefined,
	): RouteDecision {
		const config = this.opts.settings.config;
		const routingCfg = config.routing;
		const defaultProviderId = config.activeProviderId;
		const defaultModel = this.opts.providerManager.resolveActiveModelId(config);
		if (!routingCfg || !routingCfg.enabled) {
			return {
				providerId: defaultProviderId,
				...(defaultModel ? { model: defaultModel } : {}),
				reason: "routing disabled",
				bucket: "easy",
				isDefault: true,
			};
		}
		const router = new ModelRouter(routingCfg, {
			defaultProviderId,
			...(defaultModel ? { defaultModel } : {}),
		});
		return router.pick({
			prompt,
			history,
			...(override ? { override } : {}),
		});
	}

	// R3-B: spawn + rate-limit fallback. Retries once against the same primary
	// when a 429 surfaces; on a second 429, switches to the routing.fallback
	// target (when configured) and tries one more time. Beyond that the error
	// bubbles up unchanged so the user sees a real failure rather than infinite
	// retries.
	private async spawnWithRateLimitFallback(args: {
		readonly mode: import("@oati/shared").ModeConfig;
		readonly providerId: string;
		readonly modelId: string;
		readonly content: string;
		readonly history: readonly ConversationMessage[];
		readonly imageParts?: readonly MessagePart[];
		readonly signal?: AbortSignal;
	}): Promise<readonly ConversationMessage[]> {
		const cfg = this.opts.settings.config;
		const fallback = cfg.routing?.fallback;
		// Hard-disable the critic stage at the dispatch site regardless of the
		// saved mode config. The critic-retry loop has a bad chat UX —
		// existing user installs still have `enableCritic: true` persisted
		// from before the default flipped, so we force it off here. Users
		// who want it back can recreate a mode with the flag on after a
		// future Settings UI exposes it. See the matching change in the
		// shared default config + the R8.1 dogfood commit for rationale.
		const safeMode = { ...args.mode, providerId: undefined, enableCritic: false };
		const callOnce = async (providerId: string, modelId: string) => {
			return this.opts.conductor.spawn({
				mode: { ...safeMode, providerId },
				modelId,
				userMessage: args.content,
				history: args.history,
				...(args.imageParts && args.imageParts.length > 0 ? { userParts: args.imageParts } : {}),
				...(args.signal ? { signal: args.signal } : {}),
			});
		};

		try {
			return await callOnce(args.providerId, args.modelId);
		} catch (err) {
			const msg = err instanceof Error ? err.message : String(err);
			if (!looksLikeRateLimit(msg)) throw err;
			// Short bounded backoff before the first retry. Capped at 30s per spec.
			const waitMs = parseRetryAfterMs(msg) ?? 1000;
			this.opts.log?.appendLine(
				`[chat-panel] R3-B rate-limited (primary=${args.providerId}); retrying in ${Math.min(waitMs, 30_000)}ms`,
			);
			await sleep(Math.min(waitMs, 30_000));
			try {
				return await callOnce(args.providerId, args.modelId);
			} catch (err2) {
				const msg2 = err2 instanceof Error ? err2.message : String(err2);
				if (!looksLikeRateLimit(msg2) || !fallback) throw err2;
				this.opts.log?.appendLine(
					`[chat-panel] R3-B rate-limited twice; falling back to ${fallback.providerId}`,
				);
				this.bus.send({
					type: "route_decision",
					providerId: fallback.providerId,
					...(fallback.model ? { model: fallback.model } : {}),
					reason: "rate-limit fallback",
				});
				return callOnce(fallback.providerId, fallback.model ?? args.modelId);
			}
		}
	}

	/**
	 * Tally a usage event and fire the soft-alert banner the first time the
	 * per-session threshold is crossed. Hard-cap enforcement happens on the
	 * NEXT `checkDispatch()` call so the current run completes cleanly.
	 */
	private async handleUsage(inputTokens: number, outputTokens: number): Promise<void> {
		const config = this.opts.settings.config;
		const modelId = this.opts.providerManager.resolveActiveModelId(config);
		if (!modelId) return;
		const r = await this.budget.recordUsage(modelId, inputTokens, outputTokens);
		// R5-E: per-model budget — tally into the (provider, model) bucket too.
		try {
			const providerId =
				config.modes.find((m) => m.id === config.activeModeId)?.providerId ?? config.activeProviderId;
			await this.perModelBudget.recordUsage(providerId, modelId, inputTokens, outputTokens);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] per-model recordUsage failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		if (r.softAlertFired) {
			const message = `Session cost reached ${formatUsd(r.sessionCostUsd)}. Continue with caution.`;
			this.opts.log?.appendLine(`[chat-panel] budget soft alert: ${message}`);
			this.bus.send({ type: "error", message });
		}
	}

	private async openFile(rawPath: string): Promise<void> {
		// Resolve the path: absolute wins; otherwise prefer the SESSION's
		// active workspace root (the agent may have called set_workspace_root
		// to point outside the IDE folder) and fall back to vscode's
		// workspaceFolders[0] only as a last resort. This was a real-world
		// regression (2026-05-29) — model worked in E:\AI\OATICode\LLMApp11
		// while VS Code's open folder was the OATI repo, so clicking Open
		// on the tool card resolved against the wrong root and produced
		// "file directory does not exist".
		const rawErrors: string[] = [];
		try {
			let target: vscode.Uri | undefined;
			if (/^[a-zA-Z]:[\\/]/.test(rawPath) || rawPath.startsWith("/")) {
				target = vscode.Uri.file(rawPath);
			} else {
				const sessionRoot = this.opts.host?.workspaceRoot?.();
				const folders = vscode.workspace.workspaceFolders ?? [];
				const root = sessionRoot ?? folders[0]?.uri.fsPath;
				if (root) {
					target = vscode.Uri.file(nodePath.join(root, rawPath));
				}
			}
			if (!target) {
				rawErrors.push(`No workspace root available to resolve relative path ${rawPath}`);
			} else {
				const doc = await vscode.workspace.openTextDocument(target);
				await vscode.window.showTextDocument(doc, { preview: true, preserveFocus: false });
				return;
			}
		} catch (err) {
			rawErrors.push(err instanceof Error ? err.message : String(err));
		}
		// Surface the failure as a VS Code notification — NOT as an agent
		// error event. The agent may still be running; routing user-action
		// failures through `bus.send({ type: "error" })` triggers the
		// webview's terminal-error handler which kills the activity
		// indicator and flips isAgentRunning to false. That's wrong: the
		// click was a user action independent of the agent loop.
		const detail = rawErrors.join("; ");
		this.opts.log?.appendLine(`[chat-panel] openFile(${rawPath}) failed: ${detail}`);
		void vscode.window.showWarningMessage(`OATI: could not open ${rawPath} — ${detail}`);
	}

	private async pickAttachment(): Promise<void> {
		const uris = await vscode.window.showOpenDialog({
			canSelectMany: false,
			openLabel: "Attach to chat",
		});
		if (!uris || uris.length === 0) return;
		const uri = uris[0];
		try {
			const buf = await vscode.workspace.fs.readFile(uri);
			const MAX_BYTES = 200_000;
			const truncated = buf.byteLength > MAX_BYTES;
			const sliced = truncated ? buf.slice(0, MAX_BYTES) : buf;
			const text = Buffer.from(sliced).toString("utf-8");
			const folders = vscode.workspace.workspaceFolders ?? [];
			let path = uri.fsPath;
			for (const f of folders) {
				if (path.startsWith(f.uri.fsPath)) {
					path = path.slice(f.uri.fsPath.length + 1).replace(/\\/g, "/");
					break;
				}
			}
			const name = path.split(/[\\/]/).pop() ?? path;
			const language = guessLanguage(name);
			this.bus.send({
				type: "attachment_ready",
				name,
				path,
				language,
				text,
				truncated,
			});
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			this.bus.send({ type: "error", message: `Could not read attachment: ${message}` });
		}
	}

	private async pushSettings(): Promise<void> {
		const config = this.opts.settings.config;
		const hasApiKey = await this.opts.settings.hasApiKeyMap();
		this.bus.send({ type: "settings", snapshot: { config, hasApiKey } });
	}

	private buildHtml(): string {
		const distDir = resolveWebviewDistDir(this.opts.extensionUri);
		const scriptUri = this.panel.webview.asWebviewUri(vscode.Uri.joinPath(distDir, "main.js"));
		const stylesUri = this.panel.webview.asWebviewUri(vscode.Uri.joinPath(distDir, "styles.css"));
		// R4-A: mermaid is built as a separate vendor chunk and lazy-loaded
		// at runtime via load-mermaid.ts. We hand it the asWebviewUri up front
		// so the loader doesn't have to know about VS Code resource roots; the
		// CSP `script-src 'nonce-...'` directive permits this script because
		// the loader uses a same-origin <script> tag whose nonce we forward.
		const vendorMermaidUri = this.panel.webview.asWebviewUri(
			vscode.Uri.joinPath(distDir, "vendor-mermaid.js"),
		);
		const nonce = makeNonce();
		const cspSource = this.panel.webview.cspSource;
		// `script-src` only allows nonce'd inline scripts and the loader uses
		// `document.createElement("script")` without a nonce, which the CSP
		// would block. Allowing `${cspSource}` for script-src lets the lazy
		// vendor chunk load via webview URI while still blocking arbitrary
		// remotes.
		const csp = `default-src 'none'; style-src ${cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}' ${cspSource}; img-src ${cspSource} data:; font-src ${cspSource};`;
		return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Security-Policy" content="${csp}" />
<title>OATI Code</title>
<link rel="stylesheet" href="${stylesUri}" />
</head>
<body>
<div id="root"></div>
<script nonce="${nonce}">window.__OATI_VENDOR_MERMAID__ = ${JSON.stringify(vendorMermaidUri.toString())};</script>
<script nonce="${nonce}" src="${scriptUri}"></script>
</body>
</html>`;
	}

	dispose(): void {
		this.opts.log?.appendLine(`[chat-panel] disposing session ${this.sessionId}`);
		// Stop hooks run fire-and-forget with a 1s cap (set on the runner) — we can't
		// reasonably await them here because dispose may be called synchronously by
		// VS Code while the editor tears down.
		void this.hookRunner.runStop();
		// R8-E: v2 Stop + SessionEnd — observer-only. Disposal is the only
		// place SessionEnd fires; it lets users hang a "log out / persist
		// state" hook off panel close without polling.
		void this.fireHookV2({ kind: "Stop", payload: { sessionId: this.sessionId } });
		void this.fireHookV2({ kind: "SessionEnd", payload: { sessionId: this.sessionId } });
		this.currentAbort?.abort();
		// R7-C bug fix: also abort the composer if a run is in-flight when the
		// panel disposes (e.g. user closes the editor mid-stream). Without this,
		// the provider stream keeps draining tokens into a dead bus.
		this.composer?.discard();
		this.composer = undefined;
		// R7-C bug fix: previously we just `clear()`-ed pendingApprovals on
		// dispose without resolving the resolvers. Any tool waiting on
		// `requestApproval(...)` would hang forever, pinning the agent loop
		// and leaking promise chains. Resolve every outstanding approval as
		// "false" (declined) so callers unwind cleanly.
		for (const resolve of this.pendingApprovals.values()) resolve(false);
		this.pendingApprovals.clear();
		// 2026-05-27: resolve any in-flight ask_user calls with option[0]
		// so the agent loop doesn't hang on a closed panel. Same pattern as
		// approvals — declining is the safe close-on-dispose default.
		for (const resolve of this.pendingAskUser.values()) {
			resolve({ answer: "", autoPicked: true });
		}
		this.pendingAskUser.clear();
		// Resolve any outstanding secret confirms as "cancel" so callers don't hang.
		for (const resolve of this.pendingSecretConfirms.values()) resolve("cancel");
		this.pendingSecretConfirms.clear();
		this.toolNamesByCallId.clear();
		this.toolStartTimes.clear();
		// 2026-05-27 Phase 4: dispose the review-rules watcher (if any) so
		// VS Code stops feeding events into this dead panel.
		if (this.customRulesWatcher) {
			try {
				this.customRulesWatcher.dispose();
			} catch {
				/* never throws but be defensive */
			}
			this.customRulesWatcher = undefined;
		}
		this.customRulesCache.clear();
		// 2026-05-23: kill every background process this panel started.
		// Calls the host's stop method via the public HostContext API
		// (no direct registry access). Best-effort — failures are logged
		// but never block dispose.
		try {
			const running = this.opts.host?.listBackgroundProcesses?.() ?? [];
			for (const handle of running) {
				void this.opts.host?.stopBackgroundProcess?.(handle.pid).catch((err: unknown) => {
					this.opts.log?.appendLine(
						`[chat-panel] failed to stop background pid=${handle.pid}: ${err instanceof Error ? err.message : String(err)}`,
					);
				});
			}
			if (running.length > 0) {
				this.opts.log?.appendLine(
					`[chat-panel] dispose: killed ${running.length} background process${running.length === 1 ? "" : "es"}`,
				);
			}
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] background-process cleanup failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		for (const d of this.disposables) d.dispose();
		this.bus.dispose();
		this.opts.onDispose(this.sessionId);
	}

	// R2-B: status-bar wiring.
	// Subscribes the caller to this panel's underlying conductor events so the
	// status bar (or other listeners) can react to per-turn usage without
	// reaching into ChatPanel's private fields. The returned disposer is
	// idempotent and is also dropped when the panel is disposed.
	attachConductorListener(listener: (ev: import("@oati/shared").AgentEvent) => void): () => void {
		const off = this.opts.conductor.on(listener);
		this.disposables.push({ dispose: off });
		return off;
	}

	// R4-B: diagnostics pill — public escape hatch so extension.ts can
	// broadcast a `HostToWebview` envelope (currently the diagnostics_count
	// payload) into this panel's webview without reaching into `this.bus`.
	postToWebview(msg: HostToWebview): void {
		try {
			this.bus.send(msg);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] postToWebview failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}

	/**
	 * R3-D: drive a side-by-side compare. Spawns two independent Conductor
	 * runs (one per side) with different provider/model overrides, fans
	 * streaming text deltas back tagged by side, and emits a terminal
	 * `compare_done` per side. Each side has its own AbortController so the
	 * webview's `compare_cancel` can cancel both atomically.
	 *
	 * Note: we deliberately bypass the panel's session history — these are
	 * exploratory runs, not chat turns. Tools are also disabled (empty
	 * `enabledTools`) to keep the runs fast and self-contained.
	 */
	private async handleCompareRequest(
		instruction: string,
		left: { providerId: string; model?: string },
		right: { providerId: string; model?: string },
	): Promise<void> {
		// Cancel any prior in-flight compare so a rapid resubmit doesn't leak.
		this.compareAborts.left?.abort();
		this.compareAborts.right?.abort();
		this.compareAborts = {
			left: new AbortController(),
			right: new AbortController(),
		};

		const cfg = this.opts.settings.config;
		const baseMode = cfg.modes.find((m) => m.id === cfg.activeModeId) ?? cfg.modes[0];
		if (!baseMode) {
			this.bus.send({
				type: "compare_done",
				side: "left",
				status: "error",
				message: "No mode configured",
			});
			this.bus.send({
				type: "compare_done",
				side: "right",
				status: "error",
				message: "No mode configured",
			});
			return;
		}
		// Compare runs are exploratory — strip planner/critic and disable
		// tools so we stick to a single text response per side.
		const compareMode = {
			...baseMode,
			enablePlanner: false,
			enableCritic: false,
			enabledTools: [],
		};

		const runSide = async (side: "left" | "right", spec: { providerId: string; model?: string }) => {
			const provider = this.opts.providerManager.registry.get(spec.providerId);
			if (!provider) {
				this.bus.send({
					type: "compare_done",
					side,
					status: "error",
					message: `Provider not registered: ${spec.providerId}`,
				});
				return;
			}
			const fallbackModelId = this.opts.providerManager.resolveActiveModelId(cfg);
			const modelId = spec.model ?? fallbackModelId;
			if (!modelId) {
				this.bus.send({
					type: "compare_done",
					side,
					status: "error",
					message: "No model configured",
				});
				return;
			}
			const abort = this.compareAborts[side];
			try {
				// Stream directly off the provider to keep both compare runs
				// fully independent of the chat-panel's Conductor (which is
				// driving the normal chat flow). Tools are omitted so we get
				// a single text response per side.
				const stream = provider.stream({
					modelId,
					systemPrompt: compareMode.systemPrompt,
					messages: [{ role: "user", parts: [{ kind: "text", text: instruction }] }],
					tools: [],
					...(abort ? { signal: abort.signal } : {}),
				});
				for await (const ev of stream) {
					if (ev.type === "text_delta") {
						this.bus.send({ type: "compare_chunk", side, chunk: ev.text });
					} else if (ev.type === "error") {
						this.bus.send({
							type: "compare_done",
							side,
							status: "error",
							message: ev.message,
						});
						return;
					}
				}
				this.bus.send({ type: "compare_done", side, status: "ok" });
			} catch (err) {
				const message = err instanceof Error ? err.message : String(err);
				const aborted = abort?.signal.aborted === true;
				this.bus.send({
					type: "compare_done",
					side,
					status: "error",
					message: aborted ? "Cancelled" : message,
				});
			}
		};

		this.opts.log?.appendLine(
			`[chat-panel] compare_request left=${left.providerId}/${left.model ?? "(default)"} right=${right.providerId}/${right.model ?? "(default)"}`,
		);
		// Fire both runs in parallel; don't await — they complete independently
		// and each emits its own `compare_done`.
		void runSide("left", left);
		void runSide("right", right);
	}

	// ----------------------------------------------------------------------
	// Background-task tray
	// ----------------------------------------------------------------------

	private sendBackgroundTasksSnapshot(): void {
		const runner = this.opts.backgroundTasks;
		const running = runner ? runner.list().filter((t) => t.status === "running") : [];
		this.bus.send({
			type: "background_tasks_snapshot",
			tasks: running.map((t) => ({
				id: t.id,
				label: t.label,
				startedAt: t.startedAt,
				kind: "agent",
			})),
		});
	}

	/** Called from extension.ts when the BackgroundTaskRunner state changes. */
	refreshBackgroundTasksTray(): void {
		if (this.isReady) this.sendBackgroundTasksSnapshot();
	}

	/**
	 * Called from the host context after `setWorkspaceRoot` succeeds —
	 * pushes a fresh `workspace_info` event so the webview's project chip
	 * and any other workspace-aware UI updates without a panel reload.
	 */
	broadcastWorkspaceInfo(resolved: string): void {
		if (!this.isReady) return;
		this.bus.send({
			type: "workspace_info",
			info: {
				path: resolved,
				name: nodePath.basename(resolved) || resolved,
				isMultiRoot: (vscode.workspace.workspaceFolders?.length ?? 0) > 1,
				folderCount: vscode.workspace.workspaceFolders?.length ?? 1,
			},
		});
	}

	/**
	 * Called from the host context after `setWorkspaceRoot` succeeds —
	 * writes the resolved path to SessionStore so reloading the window
	 * restores the override instead of falling back to the IDE default.
	 */
	async persistWorkspaceRoot(resolved: string): Promise<void> {
		try {
			await this.opts.session.setWorkspaceRoot(this.sessionId, resolved);
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] failed to persist workspace root: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}

	/** Called from extension.ts when the SupervisorAgent emits a new snapshot. */
	pushSupervisorSuggestions(items: readonly import("./supervisor").SupervisorSuggestion[]): void {
		if (!this.isReady) {
			this.pendingSupervisorSnapshot = items;
			return;
		}
		this.bus.send({ type: "supervisor_suggestions", items });
	}
	private pendingSupervisorSnapshot:
		| readonly import("./supervisor").SupervisorSuggestion[]
		| undefined;

	// ----------------------------------------------------------------------
	// Session checkpoints (/checkpoint, /restore)
	// ----------------------------------------------------------------------

	private checkpointsDir(): string | undefined {
		const root = getPrimaryWorkspacePath();
		if (!root) return undefined;
		return nodePath.join(root, ".oati", "checkpoints");
	}

	private async createCheckpoint(label?: string): Promise<void> {
		const dir = this.checkpointsDir();
		if (!dir) {
			this.bus.send({
				type: "error",
				message: "Checkpoints require an open workspace folder.",
			});
			return;
		}
		const fs = await import("node:fs/promises");
		const pathMod = await import("node:path");
		await fs.mkdir(dir, { recursive: true });
		const id = `cp_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
		const meta = {
			id,
			label: label?.trim() || `Checkpoint ${new Date().toLocaleString()}`,
			createdAt: new Date().toISOString(),
			sessionId: this.sessionId,
			history: this.history,
		};
		await fs.writeFile(pathMod.join(dir, `${id}.json`), JSON.stringify(meta, null, 2), "utf-8");
		this.opts.log?.appendLine(`[chat-panel] checkpoint created: ${id} (${meta.label})`);
		await this.sendCheckpointsList();
	}

	private async sendCheckpointsList(): Promise<void> {
		const dir = this.checkpointsDir();
		if (!dir) {
			this.bus.send({ type: "checkpoints_list", items: [] });
			return;
		}
		const fs = await import("node:fs/promises");
		const pathMod = await import("node:path");
		const items: {
			id: string;
			label: string;
			createdAt: string;
			fileCount: number;
		}[] = [];
		try {
			const entries = await fs.readdir(dir);
			for (const f of entries) {
				if (!f.endsWith(".json")) continue;
				try {
					const text = await fs.readFile(pathMod.join(dir, f), "utf-8");
					const meta = JSON.parse(text) as {
						id?: string;
						label?: string;
						createdAt?: string;
						history?: unknown[];
					};
					if (!meta.id) continue;
					items.push({
						id: meta.id,
						label: meta.label ?? meta.id,
						createdAt: meta.createdAt ?? "",
						fileCount: Array.isArray(meta.history) ? meta.history.length : 0,
					});
				} catch {
					/* skip malformed checkpoint */
				}
			}
		} catch {
			/* directory may not exist yet */
		}
		items.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
		this.bus.send({ type: "checkpoints_list", items });
	}

	private async restoreCheckpoint(id: string): Promise<void> {
		const dir = this.checkpointsDir();
		if (!dir) return;
		const fs = await import("node:fs/promises");
		const pathMod = await import("node:path");
		try {
			const text = await fs.readFile(pathMod.join(dir, `${id}.json`), "utf-8");
			const meta = JSON.parse(text) as { history?: ConversationMessage[] };
			if (!meta.history || !Array.isArray(meta.history)) {
				this.bus.send({ type: "error", message: `Checkpoint ${id} has no history payload.` });
				return;
			}
			this.history = [...meta.history];
			await this.opts.session.save(this.sessionId, this.history);
			this.bus.send({
				type: "restore_session",
				messages: conversationToUiMessages(this.history),
			});
			this.opts.onSessionIndexChanged();
			this.opts.log?.appendLine(`[chat-panel] checkpoint restored: ${id}`);
		} catch (err) {
			this.bus.send({
				type: "error",
				message: `Restore failed: ${err instanceof Error ? err.message : String(err)}`,
			});
		}
	}

	private async deleteCheckpoint(id: string): Promise<void> {
		const dir = this.checkpointsDir();
		if (!dir) return;
		const fs = await import("node:fs/promises");
		const pathMod = await import("node:path");
		try {
			await fs.unlink(pathMod.join(dir, `${id}.json`));
		} catch (err) {
			this.opts.log?.appendLine(
				`[chat-panel] checkpoint delete ${id} failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
		await this.sendCheckpointsList();
	}

	// ----------------------------------------------------------------------
	// Conversation export
	// ----------------------------------------------------------------------

	private async exportConversation(format: "markdown" | "pdf"): Promise<void> {
		const root = getPrimaryWorkspacePath();
		if (!root) {
			this.bus.send({
				type: "error",
				message: "Export requires an open workspace folder.",
			});
			return;
		}
		const md = this.renderConversationMarkdown();
		const pathMod = await import("node:path");
		const fs = await import("node:fs/promises");
		const outDir = pathMod.join(root, ".oati", "exports");
		await fs.mkdir(outDir, { recursive: true });
		const stamp = new Date().toISOString().replace(/[:.]/g, "-");
		const mdPath = pathMod.join(outDir, `session-${this.sessionId}-${stamp}.md`);
		await fs.writeFile(mdPath, md, "utf-8");
		this.opts.log?.appendLine(`[chat-panel] exported markdown: ${mdPath}`);
		this.bus.send({
			type: "error",
			message:
				format === "pdf"
					? `Wrote markdown to ${mdPath}. To convert to PDF, ask the agent: "convert ${pathMod.basename(mdPath)} to PDF" — the bundled code-driven-artifacts skill will pick the right engine.`
					: `Exported conversation → ${mdPath}`,
		});
	}

	private renderConversationMarkdown(): string {
		const lines: string[] = [
			`# OATI Code session — ${this.sessionId}`,
			`Exported ${new Date().toISOString()}`,
			"",
		];
		for (const m of this.history) {
			const role = m.role === "user" ? "User" : m.role === "assistant" ? "Assistant" : m.role;
			lines.push(`## ${role}`);
			for (const p of m.parts) {
				if (p.kind === "text") {
					lines.push(p.text, "");
				} else if (p.kind === "tool_call") {
					lines.push(
						`*tool call:* \`${p.name}\``,
						"```json",
						JSON.stringify(p.args, null, 2),
						"```",
						"",
					);
				} else if (p.kind === "tool_result") {
					const out = typeof p.output === "string" ? p.output : JSON.stringify(p.output, null, 2);
					lines.push(
						`*tool result:* (${p.isError ? "error" : "ok"})`,
						"```",
						out.slice(0, 4000),
						"```",
						"",
					);
				} else if (p.kind === "image") {
					lines.push("*[image attached]*", "");
				}
			}
		}
		return lines.join("\n");
	}
}

/**
 * Resolves the workspace path the panel should treat as "the project".
 * Delegates to the central resolver so tools, hooks, memory loader, and
 * the chat panel all agree on what "the current project" means even in
 * multi-root workspaces.
 */
/**
 * 2026-05-28: minimal heuristic for /qa execute's unit route. We don't
 * try to be smart about which framework to invoke — npm/pnpm `test` is
 * the conventional entry point and any decent setup wires it to the
 * right runner. We pass a name pattern so vitest/jest/pytest narrow to
 * the matching test. Falls back to plain `npm test` when there's no
 * usable target string.
 */
function pickTestCommand(target: string): string {
	const cleaned = target
		.replace(/[^A-Za-z0-9_.\- ]/g, "")
		.trim()
		.slice(0, 80);
	if (cleaned.length === 0) return "npm test";
	// Most JS runners accept a substring filter as the last arg. pytest's
	// `-k` works too. Routing per-framework is commit 3+ work — for now
	// we trust the userland `test` script to do the right thing.
	return `npm test -- ${JSON.stringify(cleaned)}`;
}

function getPrimaryWorkspacePath(): string | undefined {
	return resolvePrimaryWorkspacePath();
}

async function listWorkspaceFiles(): Promise<string[]> {
	try {
		const uris = await vscode.workspace.findFiles(
			"**/*",
			"{**/node_modules/**,**/.git/**,**/dist/**,**/out/**,**/bin/**,**/obj/**,**/.vscode-test/**}",
			500,
		);
		const folders = vscode.workspace.workspaceFolders ?? [];
		return uris
			.map((uri) => {
				for (const f of folders) {
					const root = f.uri.fsPath;
					if (uri.fsPath.startsWith(root)) {
						return uri.fsPath.slice(root.length + 1).replace(/\\/g, "/");
					}
				}
				return uri.fsPath;
			})
			.sort();
	} catch {
		return [];
	}
}

function truncate(s: string, n: number): string {
	const flat = s.replace(/\s+/g, " ").trim();
	return flat.length > n ? `${flat.slice(0, n)}…` : flat;
}

// 2026-05-27: resolve the ask_user policy for a mode. Explicit setting wins;
// otherwise auto/auto-edit modes default to "auto-pick-first" (preserves the
// "run without me" contract while still surfacing the model'\''s ambiguity in
// chat) and everything else defaults to "always".
function resolveAskUserPolicy(
	mode: import("@oati/shared").ModeConfig | undefined,
): "always" | "auto-pick-first" | "never" {
	// 2026-06-06: ask_user now defaults to "always" in every mode,
	// including Auto. Previously Auto / Auto-Edit silently picked
	// options[0], which surprised users — the model believed it had asked
	// and the user never saw the chips. The autoApprove flag still gates
	// tool-call APPROVAL prompts (read-write-exec), which is what users
	// reach for when they choose Auto mode. Clarifying questions are
	// short and infrequent — Claude doesn't suppress them in any mode
	// and we should match. Users who want true unattended autonomy can
	// set `allowAskUser: "auto-pick-first"` (or `"never"`) explicitly on
	// the mode config; that override still wins below.
	if (!mode) return "always";
	if (mode.allowAskUser) return mode.allowAskUser;
	return "always";
}

// 2026-05-27: helpers for the post-turn auto-test-generation hook.

function looksLikeTestFile(path: string): boolean {
	const lower = path.toLowerCase().replace(/\\/g, "/");
	return (
		lower.startsWith("tests/") ||
		lower.startsWith("test/") ||
		lower.startsWith("__tests__/") ||
		lower.includes("/tests/") ||
		lower.includes("/__tests__/") ||
		lower.includes("/test/") ||
		/\.test\.(ts|tsx|js|jsx|mjs|cjs)$/.test(lower) ||
		/\.spec\.(ts|tsx|js|jsx|mjs|cjs)$/.test(lower) ||
		/_test\.py$/.test(lower) ||
		/test_.*\.py$/.test(lower.split("/").pop() ?? "")
	);
}

function looksLikeSourceFile(path: string): boolean {
	return /\.(ts|tsx|js|jsx|mjs|cjs|py|java|cs|go|rs|rb|php|swift|kt)$/i.test(path);
}

/**
 * Compute the conventional test-file path for a given source file. Mirrors
 * the source under a sibling `tests/` directory and inserts `.test` before
 * the extension. JS / TS only — Python uses `test_<name>.py` next to source.
 */
function candidateTestPath(sourcePath: string): string {
	const norm = sourcePath.replace(/\\/g, "/");
	if (/\.py$/.test(norm)) {
		const idx = norm.lastIndexOf("/");
		const dir = idx >= 0 ? norm.slice(0, idx) : ".";
		const base = idx >= 0 ? norm.slice(idx + 1) : norm;
		return `${dir}/test_${base}`;
	}
	const m = norm.match(/^(.*?)\.(ts|tsx|js|jsx|mjs|cjs)$/);
	if (m) {
		// src/foo/bar.ts → tests/foo/bar.test.ts (when "src/" present),
		// otherwise <same-dir>/<name>.test.ts
		const [, stem, ext] = m;
		if (stem.startsWith("src/")) {
			return `tests/${stem.slice(4)}.test.${ext}`;
		}
		return `${stem}.test.${ext}`;
	}
	return `${norm}.test`;
}

/**
 * Inverse of `userMessageIdForIndex(n) === "u_h" + n`. Returns -1 when the id
 * isn't in the expected shape so the caller can surface a friendly error.
 */
function parseUserMessageHistoryIndex(uiMessageId: string): number {
	const m = /^u_h(\d+)$/.exec(uiMessageId);
	if (!m) return -1;
	const n = Number.parseInt(m[1], 10);
	return Number.isFinite(n) ? n : -1;
}

function guessLanguage(name: string): string | undefined {
	const ext = name.split(".").pop()?.toLowerCase();
	if (!ext) return undefined;
	const map: Record<string, string> = {
		ts: "typescript",
		tsx: "tsx",
		js: "javascript",
		jsx: "jsx",
		py: "python",
		rb: "ruby",
		go: "go",
		rs: "rust",
		java: "java",
		kt: "kotlin",
		cs: "csharp",
		cpp: "cpp",
		c: "c",
		h: "c",
		hpp: "cpp",
		md: "markdown",
		json: "json",
		yml: "yaml",
		yaml: "yaml",
		toml: "toml",
		sh: "bash",
		ps1: "powershell",
		html: "html",
		css: "css",
		scss: "scss",
		sql: "sql",
		xml: "xml",
	};
	return map[ext];
}

function makeNonce(): string {
	const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	let s = "";
	for (let i = 0; i < 32; i++) s += chars[Math.floor(Math.random() * chars.length)];
	return s;
}

/** Concatenate all text parts in an assistant turn, for audit-log hashing. */
function stringifyAssistantText(message: ConversationMessage): string {
	const parts: string[] = [];
	for (const p of message.parts) {
		if (p.kind === "text") parts.push(p.text);
	}
	return parts.join("");
}

// R6-B: tiny nbformat reader for the `@notebook:<path>:<cell-index>` mention
// resolver. Mirrors the more featureful parser in `@oati/tools/read-notebook`,
// but pared down to just the bit the mention pipeline needs: pull a single
// cell's source out of the raw JSON. Inlined to avoid cross-package barrel
// edits owned by R6-A.
function readNotebookCellSource(
	raw: string,
	index: number,
): { kind: "ok"; source: string } | { kind: "err"; message: string } {
	let nb: unknown;
	try {
		nb = JSON.parse(raw);
	} catch (err) {
		return {
			kind: "err",
			message: `Notebook is not valid JSON: ${err instanceof Error ? err.message : String(err)}`,
		};
	}
	if (!nb || typeof nb !== "object") {
		return { kind: "err", message: "Notebook envelope is not an object." };
	}
	const cells = (nb as { cells?: unknown }).cells;
	if (!Array.isArray(cells)) {
		return { kind: "err", message: "Notebook envelope is missing `cells` array." };
	}
	if (index < 0 || index >= cells.length) {
		return {
			kind: "err",
			message: `Cell index ${index} out of range (notebook has ${cells.length} cells).`,
		};
	}
	const cell = cells[index];
	if (!cell || typeof cell !== "object") {
		return { kind: "err", message: `Cell ${index} is not an object.` };
	}
	const src = (cell as { source?: unknown }).source;
	const source = Array.isArray(src)
		? src.map((s) => String(s)).join("")
		: typeof src === "string"
			? src
			: "";
	return { kind: "ok", source };
}

/** Tiny USD formatter — duplicates the shared `formatUsd` to avoid an extra import. */
function formatUsd(amount: number): string {
	if (amount < 0.01) return `$${amount.toFixed(4)}`;
	if (amount < 1) return `$${amount.toFixed(3)}`;
	return `$${amount.toFixed(2)}`;
}

// R3-B: rate-limit helpers
function sleep(ms: number): Promise<void> {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Best-effort parse of a `Retry-After` hint out of an error message. Many
 * providers shove the upstream JSON into their thrown Error.message, so a
 * shallow regex sweep handles both `retry-after: 12` headers and
 * `"retry_after": 12.5` JSON shapes. Returns ms or undefined.
 */
function parseRetryAfterMs(message: string): number | undefined {
	const headerMatch = /retry[-_ ]?after[:= ]+(\d+(?:\.\d+)?)/i.exec(message);
	if (headerMatch) {
		const seconds = Number.parseFloat(headerMatch[1]);
		if (Number.isFinite(seconds) && seconds >= 0) return Math.round(seconds * 1000);
	}
	return undefined;
}
