// R4-C: project-template applier. Uses `vscode.workspace.fs` so it works
// across VS Code's URI schemes (local, virtual workspaces, etc.). Approval is
// gated through `host.requestApproval` because we may write many files.
import type { HostContext } from "@oati/shared";
import * as vscode from "vscode";
import { BUILTIN_TEMPLATES, type Template } from "./templates-builtin";

export type { Template, TemplateFile } from "./templates-builtin";

export interface ApplyTemplateOptions {
	/**
	 * When true, existing files are overwritten. Default false — existing files
	 * are added to `skipped` and never touched.
	 */
	readonly overwrite?: boolean;
	/** When provided, used to ask the user before any write happens. */
	readonly host?: HostContext;
	/** Optional logging sink. */
	readonly log?: vscode.OutputChannel;
}

export interface ApplyTemplateResult {
	readonly created: readonly string[];
	readonly skipped: readonly string[];
}

/** Public list of templates the UI surfaces. Order matches the array order. */
export function listTemplates(): readonly Template[] {
	return BUILTIN_TEMPLATES;
}

/** Lookup helper used by the slash-command / RPC dispatch layer. */
export function findTemplate(name: string): Template | undefined {
	return BUILTIN_TEMPLATES.find((t) => t.name === name);
}

/**
 * Materialize `template.files` under `targetDir`. Honors `overwrite` for each
 * file: when false, an existing file is added to `skipped` and not touched.
 * Per-template approval is asked once up front via `host.requestApproval` (when
 * a host is wired), so the user sees a single "init template X under Y" prompt
 * rather than one per file.
 */
export async function applyTemplate(
	name: string,
	targetDir: vscode.Uri,
	opts: ApplyTemplateOptions = {},
): Promise<ApplyTemplateResult> {
	const template = findTemplate(name);
	if (!template) {
		throw new Error(`applyTemplate: unknown template '${name}'`);
	}

	if (opts.host) {
		const approved = await opts.host.requestApproval({
			toolName: "init_template",
			args: { name, targetDir: targetDir.fsPath, fileCount: template.files.length },
			summary: `Initialize template '${name}' (${template.files.length} files) under ${targetDir.fsPath}`,
		});
		if (!approved) {
			opts.log?.appendLine(`[templates] user declined applyTemplate name=${name}`);
			return { created: [], skipped: template.files.map((f) => f.path) };
		}
	}

	const created: string[] = [];
	const skipped: string[] = [];

	for (const file of template.files) {
		const fileUri = vscode.Uri.joinPath(targetDir, ...file.path.split("/"));
		const exists = await fileExists(fileUri);
		if (exists && !opts.overwrite) {
			skipped.push(file.path);
			continue;
		}
		const dir = vscode.Uri.joinPath(fileUri, "..");
		try {
			await vscode.workspace.fs.createDirectory(dir);
		} catch {
			// createDirectory throws when the parent already exists in some hosts;
			// ignore — the next writeFile will fail loudly if there's a real issue.
		}
		await vscode.workspace.fs.writeFile(fileUri, Buffer.from(file.content, "utf-8"));
		created.push(file.path);
	}

	opts.log?.appendLine(
		`[templates] applied '${name}' under ${targetDir.fsPath} created=${created.length} skipped=${skipped.length}`,
	);
	return { created, skipped };
}

async function fileExists(uri: vscode.Uri): Promise<boolean> {
	try {
		await vscode.workspace.fs.stat(uri);
		return true;
	} catch {
		return false;
	}
}
