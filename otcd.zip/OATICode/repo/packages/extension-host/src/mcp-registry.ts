// R4-D: Curated MCP server marketplace registry.
//
// Static, hand-curated list of well-known MCP servers from the public
// ecosystem. Each entry maps to an install recipe (command + args + env) that
// the MarketplaceManager can drop into the user's settings as an
// `McpServerConfig`. Kept disabled by default; user opts in via the
// marketplace view (which surfaces the third-party-code warning banner).
//
// Sourced from the @modelcontextprotocol org and first-party partner servers;
// invocation pattern is `npx -y @modelcontextprotocol/server-<name>` so the
// user doesn't have to install anything globally.

export interface McpRegistryEntry {
	readonly id: string;
	readonly displayName: string;
	readonly description: string;
	readonly homepage?: string;
	readonly install: {
		readonly command: string;
		readonly args?: readonly string[];
		readonly env?: Readonly<Record<string, string>>;
	};
	readonly category: "filesystem" | "git" | "search" | "ai" | "database" | "misc";
}

export const MCP_REGISTRY: readonly McpRegistryEntry[] = [
	{
		id: "filesystem",
		displayName: "Filesystem",
		description:
			"Read and write files in allowed directories. Pass each allowed directory as an extra argument.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-filesystem", "."],
		},
		category: "filesystem",
	},
	{
		id: "git",
		displayName: "Git",
		description: "Inspect and operate on a local git repository (status, log, diff, blame, show).",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/git",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-git"],
		},
		category: "git",
	},
	{
		id: "github",
		displayName: "GitHub",
		description:
			"Search repos, read/create issues and PRs, file operations on GitHub. Set GITHUB_PERSONAL_ACCESS_TOKEN in the env.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/github",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-github"],
			env: { GITHUB_PERSONAL_ACCESS_TOKEN: "" },
		},
		category: "git",
	},
	{
		id: "brave-search",
		displayName: "Brave Search",
		description:
			"Web search via the Brave Search API. Set BRAVE_API_KEY in the env (free tier available).",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/brave-search",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-brave-search"],
			env: { BRAVE_API_KEY: "" },
		},
		category: "search",
	},
	{
		id: "puppeteer",
		displayName: "Puppeteer",
		description: "Headless Chromium for screenshots, scraping, and dynamic page interaction.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/puppeteer",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-puppeteer"],
		},
		category: "search",
	},
	{
		id: "sqlite",
		displayName: "SQLite",
		description:
			"Query and modify a local SQLite database file. Edit the args to point at your .db file.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/sqlite",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-sqlite", "--db-path", "./oati.db"],
		},
		category: "database",
	},
	{
		id: "postgres",
		displayName: "Postgres",
		description:
			"Read-only access to a Postgres database. Pass the connection URL as the last argument.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/postgres",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-postgres", "postgresql://localhost/postgres"],
		},
		category: "database",
	},
	{
		id: "slack",
		displayName: "Slack",
		description:
			"Read messages and post to Slack channels. Set SLACK_BOT_TOKEN and SLACK_TEAM_ID in the env.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/slack",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-slack"],
			env: { SLACK_BOT_TOKEN: "", SLACK_TEAM_ID: "" },
		},
		category: "misc",
	},
	{
		id: "memory",
		displayName: "Memory",
		description:
			"Persist arbitrary facts in a knowledge-graph store and recall them across sessions.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/memory",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-memory"],
		},
		category: "ai",
	},
	{
		id: "time",
		displayName: "Time",
		description:
			"Lookup current time, time-zone conversion, and time arithmetic — useful for scheduling-aware agents.",
		homepage: "https://github.com/modelcontextprotocol/servers/tree/main/src/time",
		install: {
			command: "npx",
			args: ["-y", "@modelcontextprotocol/server-time"],
		},
		category: "misc",
	},
];

export function getMcpRegistryEntry(id: string): McpRegistryEntry | undefined {
	return MCP_REGISTRY.find((e) => e.id === id);
}
