// R8-C: @search:<query> — workspace-wide grep. Optional `--glob=...` suffix
// (space-separated) restricts the file filter.
import type { ContextProvider } from "./registry";

const DEFAULT_CAP = 20;

interface ParsedSearch {
	readonly query: string;
	readonly glob?: string;
}

export function parseSearchArg(arg: string): ParsedSearch {
	const tokens = arg.trim().split(/\s+/);
	const out: string[] = [];
	let glob: string | undefined;
	for (const t of tokens) {
		if (t.startsWith("--glob=")) {
			glob = t.slice("--glob=".length);
		} else if (t.length > 0) {
			out.push(t);
		}
	}
	return { query: out.join(" "), ...(glob ? { glob } : {}) };
}

function shellQuote(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

export const searchProvider: ContextProvider = {
	id: "search",
	mention: "@search",
	description:
		"Grep across the workspace. Arg: `<query>` and optional `--glob=<pattern>` (e.g. `@search:TODO --glob=*.ts`).",
	async resolve(arg, host) {
		const { query, glob } = parseSearchArg(arg);
		if (!query) return "_Usage: `@search:<pattern> [--glob=<glob>]`._";
		const rgArgs = [
			"--no-heading",
			"--line-number",
			"--ignore-case",
			"--max-count",
			String(DEFAULT_CAP),
		];
		if (glob) {
			rgArgs.push("--glob", glob);
		}
		const cmd = `rg ${rgArgs.map(shellQuote).join(" ")} ${shellQuote(query)} .`;
		const rg = await host.exec(cmd, { timeoutMs: 15_000 });
		if (rg.exitCode !== 0 && rg.exitCode !== 1) {
			return `_@search failed (exit ${rg.exitCode}): ${(rg.stderr || rg.stdout).slice(0, 500)}._`;
		}
		const lines = rg.stdout
			.split("\n")
			.map((s) => s.trim())
			.filter((s) => s.length > 0)
			.slice(0, DEFAULT_CAP);
		if (lines.length === 0) {
			return `_No matches for \`${query}\`${glob ? ` (glob: ${glob})` : ""}._`;
		}
		const header = `**@search:** \`${query}\`${glob ? ` (glob: \`${glob}\`)` : ""} — ${lines.length} match${lines.length === 1 ? "" : "es"}`;
		return `${header}\n\n\`\`\`\n${lines.join("\n")}\n\`\`\``;
	},
};
