// R8-C: @problems — dump active VS Code diagnostics (R4-B bridge).
import type { ContextProvider } from "./registry";

const DEFAULT_CAP = 50;

export const problemsProvider: ContextProvider = {
	id: "problems",
	mention: "@problems",
	description:
		"Current LSP diagnostics (errors/warnings) across the workspace. Optional path filter.",
	async resolve(arg, host) {
		if (!host.diagnostics) {
			return "_No diagnostics bridge available in this host._";
		}
		const trimmed = arg.trim();
		const opts: { path?: string } = trimmed ? { path: trimmed } : {};
		const entries = await host.diagnostics.all(opts);
		if (entries.length === 0) {
			return trimmed ? `_No diagnostics for_ \`${trimmed}\`.` : "_No diagnostics in the workspace._";
		}
		const shown = entries.slice(0, DEFAULT_CAP);
		const lines = shown.map((d) => {
			const where = `${d.path}:${d.line}:${d.column}`;
			const sev = d.severity.toUpperCase();
			const src = d.source ? ` [${d.source}]` : "";
			return `- ${sev} ${where}${src} — ${d.message}`;
		});
		const header = `**Diagnostics** (${entries.length} total${entries.length > shown.length ? `, showing first ${shown.length}` : ""})`;
		return `${header}\n${lines.join("\n")}`;
	},
};
