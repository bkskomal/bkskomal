// R8-C: @open-tabs — list of open editor tabs with their first 50 lines.
import type { ContextProvider } from "./registry";

const HEAD_LINES = 50;
const MAX_FILES = 10;

export const openTabsProvider: ContextProvider = {
	id: "open-tabs",
	mention: "@open-tabs",
	description: `Open editor tabs with the first ${HEAD_LINES} lines of each.`,
	async resolve(_arg, host) {
		const ctx = await host.getWorkspaceContext?.();
		if (!ctx) return "_No workspace context available._";
		const files = ctx.openFiles.slice(0, MAX_FILES);
		if (files.length === 0) return "_No open editors._";
		const blocks: string[] = [];
		for (const f of files) {
			let head = "";
			try {
				const content = await host.readFile(f);
				head = content.split(/\r?\n/).slice(0, HEAD_LINES).join("\n");
			} catch (err) {
				head = `(read failed: ${err instanceof Error ? err.message : String(err)})`;
			}
			blocks.push(`**\`${f}\`** (first ${HEAD_LINES} lines)\n\`\`\`\n${head}\n\`\`\``);
		}
		const trailer =
			ctx.openFiles.length > files.length
				? `\n\n_…${ctx.openFiles.length - files.length} more tab(s) omitted._`
				: "";
		return `${blocks.join("\n\n")}${trailer}`;
	},
};
