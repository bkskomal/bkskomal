// R8-C: @docs:<url> — fetch a doc URL, strip HTML, return markdown-flavoured text.
//
// Reuses the same logic R1's `fetch_url` tool relies on (a plain `fetch` GET
// with a body cap) but post-processes the response so it's usable as chat
// context. We don't import the tool spec directly — the tool sits inside an
// approval-gated wrapper and we want this provider to be auto-resolvable.
import type { ContextProvider } from "./registry";

const DEFAULT_MAX_BYTES = 256_000;
const DEFAULT_TIMEOUT_MS = 15_000;

function decodeEntities(text: string): string {
	return text
		.replace(/&#(\d+);/g, (_m, n: string) => {
			const code = Number.parseInt(n, 10);
			if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return _m;
			try {
				return String.fromCodePoint(code);
			} catch {
				return _m;
			}
		})
		.replace(/&amp;/g, "&")
		.replace(/&lt;/g, "<")
		.replace(/&gt;/g, ">")
		.replace(/&quot;/g, '"')
		.replace(/&#39;/g, "'")
		.replace(/&nbsp;/g, " ");
}

/**
 * Strip HTML and collapse whitespace into something resembling markdown. This
 * is deliberately simple — we drop script/style/nav blocks, convert headings
 * and list items into prefix markers, and ditch everything else.
 */
export function htmlToMarkdown(html: string): string {
	let text = html;
	// Remove blocks we never want to surface.
	text = text.replace(/<script\b[\s\S]*?<\/script>/gi, "");
	text = text.replace(/<style\b[\s\S]*?<\/style>/gi, "");
	text = text.replace(/<nav\b[\s\S]*?<\/nav>/gi, "");
	text = text.replace(/<header\b[\s\S]*?<\/header>/gi, "");
	text = text.replace(/<footer\b[\s\S]*?<\/footer>/gi, "");
	// Headings: pull the level + content.
	text = text.replace(/<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi, (_m, lvl: string, content: string) => {
		return `\n${"#".repeat(Number.parseInt(lvl, 10))} ${stripTags(content).trim()}\n`;
	});
	// Code blocks.
	text = text.replace(
		/<pre[^>]*>([\s\S]*?)<\/pre>/gi,
		(_m, c: string) => `\n\`\`\`\n${stripTags(c)}\n\`\`\`\n`,
	);
	// Inline code.
	text = text.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_m, c: string) => `\`${stripTags(c)}\``);
	// Lists.
	text = text.replace(
		/<li[^>]*>([\s\S]*?)<\/li>/gi,
		(_m, c: string) => `\n- ${stripTags(c).trim()}`,
	);
	// Paragraph / line breaks.
	text = text.replace(/<\/p>/gi, "\n\n").replace(/<br\s*\/?>(?!<\/p>)/gi, "\n");
	// Strip everything else.
	text = stripTags(text);
	text = decodeEntities(text);
	// Collapse runs of blank lines and trailing whitespace.
	text = text
		.replace(/[ \t]+\n/g, "\n")
		.replace(/\n{3,}/g, "\n\n")
		.trim();
	return text;
}

function stripTags(s: string): string {
	return s.replace(/<[^>]*>/g, "");
}

export const docsProvider: ContextProvider = {
	id: "docs",
	mention: "@docs",
	description: "Fetch a doc URL and return its text (HTML stripped). Arg: full https URL.",
	async resolve(arg) {
		const url = arg.trim();
		if (!url) {
			return "_Usage: `@docs:<https-url>`._";
		}
		let parsed: URL;
		try {
			parsed = new URL(url);
		} catch {
			return `_Invalid URL: ${url}._`;
		}
		if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
			return `_Only http/https supported (got ${parsed.protocol})._`;
		}
		const ctrl = new AbortController();
		const timer = setTimeout(() => ctrl.abort(), DEFAULT_TIMEOUT_MS);
		try {
			const response = await fetch(parsed.toString(), {
				method: "GET",
				signal: ctrl.signal,
				redirect: "follow",
			});
			const buf = await response.arrayBuffer();
			const truncated = buf.byteLength > DEFAULT_MAX_BYTES;
			const sliced = truncated ? buf.slice(0, DEFAULT_MAX_BYTES) : buf;
			const decoder = new TextDecoder("utf-8", { fatal: false });
			const body = decoder.decode(sliced);
			const contentType = response.headers.get("content-type") ?? "";
			const looksHtml = contentType.includes("html") || /<html[\s>]/i.test(body);
			const md = looksHtml ? htmlToMarkdown(body) : body.trim();
			const header = `**${parsed.toString()}** (${response.status})${truncated ? " — truncated" : ""}`;
			return `${header}\n\n${md}`;
		} catch (err) {
			if (err instanceof Error && err.name === "AbortError") {
				return `_@docs request timed out: ${url}._`;
			}
			return `_@docs fetch failed: ${err instanceof Error ? err.message : String(err)}._`;
		} finally {
			clearTimeout(timer);
		}
	},
};
