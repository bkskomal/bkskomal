// R8-C: @git-diff — output of `git diff` against the working tree. Optional
// arg can be `--staged`, a specific file path, or both space-separated.
import type { ContextProvider } from "./registry";

const TRUNC_BYTES = 64 * 1024;

export const gitDiffProvider: ContextProvider = {
	id: "git-diff",
	mention: "@git-diff",
	description: "Output of `git diff`. Optional arg: `--staged`, a file path, or both.",
	async resolve(arg, host) {
		const trimmed = arg.trim();
		// Whitelist to avoid argv injection — `--staged`, `--cached`, file paths
		// without shell metacharacters. Reject anything else.
		const parts = trimmed.length === 0 ? [] : trimmed.split(/\s+/);
		const safeParts: string[] = [];
		for (const p of parts) {
			if (p === "--staged" || p === "--cached") {
				safeParts.push(p);
				continue;
			}
			if (/^[A-Za-z0-9_./-]+$/.test(p)) {
				safeParts.push(p);
				continue;
			}
			return `_Rejected unsafe @git-diff argument: \`${p}\`._`;
		}
		const cmd = ["git", "diff", ...safeParts].join(" ");
		const result = await host.exec(cmd, { timeoutMs: 15_000 });
		if (result.exitCode !== 0) {
			const err = (result.stderr || result.stdout).trim();
			return `_git diff failed (exit ${result.exitCode}): ${err.slice(0, 500) || "no output"}._`;
		}
		const body = result.stdout;
		if (body.trim().length === 0) {
			return safeParts.includes("--staged") || safeParts.includes("--cached")
				? "_No staged changes._"
				: "_Working tree is clean._";
		}
		const truncated = body.length > TRUNC_BYTES;
		const shown = truncated ? `${body.slice(0, TRUNC_BYTES)}\n…(truncated)` : body;
		return [`**\`${cmd}\`**:`, "```diff", shown, "```"].join("\n");
	},
};
