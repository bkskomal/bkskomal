// R8-C: @github-issue:<num> or @github-issue:<owner>/<repo>#<num>
//
// Fetches the issue body + the first 5 comments using the `gh` CLI. When
// `gh` isn't installed the provider returns a friendly hint instead of
// failing the whole composer turn.
import type { ContextProvider } from "./registry";

interface IssueRef {
	readonly owner?: string;
	readonly repo?: string;
	readonly number: number;
}

export function parseIssueRef(arg: string): IssueRef | { error: string } {
	const trimmed = arg.trim();
	if (!trimmed) return { error: "missing issue reference" };
	// Form 1: just a number.
	if (/^\d+$/.test(trimmed)) {
		return { number: Number.parseInt(trimmed, 10) };
	}
	// Form 2: owner/repo#num
	const m = /^([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)#(\d+)$/.exec(trimmed);
	if (m) {
		return { owner: m[1], repo: m[2], number: Number.parseInt(m[3], 10) };
	}
	return {
		error: `unrecognized format — expected '<num>' or '<owner>/<repo>#<num>' (got '${trimmed}')`,
	};
}

function shellQuote(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

export const githubIssueProvider: ContextProvider = {
	id: "github-issue",
	mention: "@github-issue",
	description: "Fetch a GitHub issue's body and first 5 comments via the `gh` CLI.",
	async resolve(arg, host) {
		const parsed = parseIssueRef(arg);
		if ("error" in parsed) return `_@github-issue: ${parsed.error}._`;
		const repoFlag =
			parsed.owner && parsed.repo ? ` --repo ${shellQuote(`${parsed.owner}/${parsed.repo}`)}` : "";
		const fields = "title,body,state,author,createdAt,url,comments";
		const cmd = `gh issue view ${parsed.number}${repoFlag} --json ${shellQuote(fields)}`;
		const result = await host.exec(cmd, { timeoutMs: 15_000 });
		if (result.exitCode !== 0) {
			const err = (result.stderr || result.stdout).trim();
			return `_gh issue view failed (exit ${result.exitCode}): ${err.slice(0, 500) || "no output"}._`;
		}
		let payload: {
			title?: string;
			body?: string;
			state?: string;
			author?: { login?: string };
			createdAt?: string;
			url?: string;
			comments?: { author?: { login?: string }; body?: string; createdAt?: string }[];
		};
		try {
			payload = JSON.parse(result.stdout);
		} catch (err) {
			return `_@github-issue: failed to parse gh output: ${err instanceof Error ? err.message : String(err)}._`;
		}
		const header = [
			`**${payload.title ?? `Issue #${parsed.number}`}** — ${payload.state ?? "?"}`,
			`Author: ${payload.author?.login ?? "?"} · Created: ${payload.createdAt ?? "?"}`,
			payload.url ? `URL: ${payload.url}` : "",
		]
			.filter((s) => s.length > 0)
			.join("\n");
		const body = (payload.body ?? "").trim() || "_(no body)_";
		const comments = (payload.comments ?? []).slice(0, 5);
		const commentBlock =
			comments.length === 0
				? ""
				: `\n\n**First ${comments.length} comments:**\n${comments
						.map(
							(c, i) =>
								`\n${i + 1}. @${c.author?.login ?? "?"} (${c.createdAt ?? "?"}):\n${(c.body ?? "").trim()}`,
						)
						.join("\n")}`;
		return `${header}\n\n${body}${commentBlock}`;
	},
};
