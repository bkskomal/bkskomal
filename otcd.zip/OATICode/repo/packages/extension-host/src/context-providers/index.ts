// R8-C: barrel + activation helpers for the pluggable context-provider system.
import { promises as fs } from "node:fs";
import * as path from "node:path";
import * as vm from "node:vm";
import { docsProvider } from "./docs";
import { gitDiffProvider } from "./git-diff";
import { githubIssueProvider } from "./github-issue";
import { openTabsProvider } from "./open-tabs";
import { problemsProvider } from "./problems";
import {
	type ContextProvider,
	MAX_USER_PROVIDERS,
	registerContextProvider,
	tryAcceptUserProvider,
} from "./registry";
import { searchProvider } from "./search";
import { selectionProvider } from "./selection";
import { terminalProvider } from "./terminal";
import { webProvider } from "./web";

export {
	type ContextProvider,
	getContextProvider,
	getContextProviderByMention,
	listContextProviders,
	registerContextProvider,
	MAX_USER_PROVIDERS,
	_resetContextProviders,
} from "./registry";

/** Idempotent: subsequent calls are no-ops because `Map.set` overwrites. */
export function registerBuiltinContextProviders(): void {
	registerContextProvider(problemsProvider);
	registerContextProvider(terminalProvider);
	registerContextProvider(gitDiffProvider);
	registerContextProvider(docsProvider);
	registerContextProvider(webProvider);
	registerContextProvider(githubIssueProvider);
	registerContextProvider(searchProvider);
	registerContextProvider(openTabsProvider);
	registerContextProvider(selectionProvider);
}

/** Relative directory under the workspace root for user plugins. */
export const USER_PROVIDERS_RELATIVE_DIR = ".oati/context-providers";

function isContextProvider(v: unknown): v is ContextProvider {
	if (typeof v !== "object" || v === null) return false;
	const p = v as ContextProvider;
	return (
		typeof p.id === "string" &&
		typeof p.mention === "string" &&
		typeof p.description === "string" &&
		typeof p.resolve === "function"
	);
}

export interface LoadUserProvidersResult {
	readonly registered: readonly string[];
	readonly skipped: readonly { readonly file: string; readonly reason: string }[];
}

/**
 * Load every `<workspace>/.oati/context-providers/*.js` file in a sandboxed vm
 * context and register the exported provider. Sandboxing here is best-effort
 * isolation, not a security boundary — the user already trusts the workspace.
 * The hard cap (10 per workspace) is enforced by the registry.
 */
export async function loadUserProviders(
	workspaceRoot: string,
	log?: (msg: string) => void,
): Promise<LoadUserProvidersResult> {
	if (!workspaceRoot) return { registered: [], skipped: [] };
	const dir = path.join(workspaceRoot, USER_PROVIDERS_RELATIVE_DIR);
	let entries: string[];
	try {
		entries = await fs.readdir(dir);
	} catch {
		return { registered: [], skipped: [] };
	}
	const registered: string[] = [];
	const skipped: { file: string; reason: string }[] = [];
	for (const entry of entries) {
		if (!entry.toLowerCase().endsWith(".js")) continue;
		const abs = path.join(dir, entry);
		if (!tryAcceptUserProvider(workspaceRoot)) {
			skipped.push({
				file: entry,
				reason: `cap of ${MAX_USER_PROVIDERS} user providers reached`,
			});
			break;
		}
		try {
			const source = await fs.readFile(abs, "utf-8");
			const moduleExports: { exports: unknown } = { exports: {} };
			// Build a tiny CommonJS shim: provide `module`, `exports`, `require`
			// (stubbed), and nothing else. The sandbox doesn't share globals
			// with the host so the plugin can't reach into VS Code internals
			// directly — it has to go through the HostContext it's handed at
			// resolve time.
			const sandbox = {
				module: moduleExports,
				exports: moduleExports.exports,
				console: { log: () => undefined, warn: () => undefined, error: () => undefined },
				require: (_id: string) => {
					throw new Error(`require() is not available in context-provider plugins (asked for '${_id}')`);
				},
				setTimeout,
				clearTimeout,
			};
			vm.createContext(sandbox);
			const script = new vm.Script(source, { filename: abs });
			script.runInContext(sandbox, { timeout: 1000 });
			const exported =
				(moduleExports.exports as { default?: unknown }).default ?? moduleExports.exports;
			if (!isContextProvider(exported)) {
				skipped.push({ file: entry, reason: "module did not export a ContextProvider shape" });
				continue;
			}
			registerContextProvider(exported);
			registered.push(exported.id);
		} catch (err) {
			skipped.push({
				file: entry,
				reason: err instanceof Error ? err.message : String(err),
			});
		}
	}
	if (log && (registered.length > 0 || skipped.length > 0)) {
		log(
			`[context-providers] loaded ${registered.length} user provider(s)${skipped.length > 0 ? `; skipped ${skipped.length}` : ""}`,
		);
		for (const s of skipped) {
			log(`[context-providers] skipped ${s.file}: ${s.reason}`);
		}
	}
	return { registered, skipped };
}

/**
 * Resolve a single mention against the registry. `mention` may be the bare
 * id (`problems`), the literal `@mention` (`@problems`), or carry an inline
 * argument (`docs:https://…` or `@docs:https://…`).
 */
export async function resolveContextMention(
	mention: string,
	arg: string | undefined,
	host: import("@oati/shared").HostContext,
): Promise<{ ok: true; content: string } | { ok: false; error: string }> {
	const { listContextProviders, getContextProviderByMention, getContextProvider } = await import(
		"./registry"
	);
	const trimmed = mention.trim();
	if (!trimmed) return { ok: false, error: "mention is empty" };
	// Split off inline argument (`docs:https://…`).
	const colonIdx = trimmed.indexOf(":");
	const head = colonIdx === -1 ? trimmed : trimmed.slice(0, colonIdx);
	const inlineArg = colonIdx === -1 ? "" : trimmed.slice(colonIdx + 1);
	const provider = getContextProviderByMention(head) ?? getContextProvider(head.replace(/^@/, ""));
	if (!provider) {
		const known = listContextProviders()
			.map((p) => p.mention)
			.join(", ");
		return {
			ok: false,
			error: `no context provider matches '${head}'. Known: ${known || "(none)"}.`,
		};
	}
	const finalArg = arg !== undefined && arg !== "" ? arg : inlineArg;
	try {
		const content = await provider.resolve(finalArg, host);
		return { ok: true, content };
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : String(err),
		};
	}
}
