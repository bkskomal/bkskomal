// R8-C: @selection — current editor selection (1-based range + content).
import type { ContextProvider } from "./registry";

export const selectionProvider: ContextProvider = {
	id: "selection",
	mention: "@selection",
	description: "Current editor selection with 1-based line range.",
	async resolve(_arg, host) {
		const ctx = await host.getWorkspaceContext?.();
		if (!ctx) return "_No workspace context available._";
		const sel = ctx.activeSelection;
		if (!sel) {
			return "_No active selection. Highlight code in an editor first._";
		}
		const where = ctx.activeFile
			? `\`${ctx.activeFile}\`:${sel.startLine}-${sel.endLine}`
			: `lines ${sel.startLine}-${sel.endLine}`;
		const lang = ctx.activeFileLanguage ?? "";
		return `**Selection** (${where})\n\`\`\`${lang}\n${sel.text}\n\`\`\``;
	},
};
