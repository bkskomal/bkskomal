// R3-B: Multi-model routing.
//
// Decides which provider/model should serve the *next* turn based on a small
// rule table from `RootConfig.routing`. Three classification signals are
// combined into a single difficulty bucket (trivial / easy / medium / hard):
//
//   1. Prompt length — quick proxy for "is this a one-liner or an essay".
//   2. Recent tool-call density — when the previous assistant turn fired a
//      bunch of tool calls, the model is clearly chewing on something hard,
//      so the next turn earns a "hard" bump.
//   3. Slash-command override (`/route fast` / `/route slow`) — one-shot
//      escape hatch the user types when they know better than the heuristic.
//
// A separate rate-limit helper (`withRetryFallback`) wraps a provider stream
// so a 429 from the primary degrades to a fallback target after one bounded
// retry.

import type {
	ConversationMessage,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
	RouteRule,
	RoutingConfig,
} from "@oati/shared";

/** What the router decided for the upcoming turn. */
export interface RouteDecision {
	readonly providerId: string;
	readonly model?: string;
	/** Why this route fired — exposed mostly for logging and UI tooltips. */
	readonly reason: string;
	/** Resolved difficulty class (after override + heuristics). */
	readonly bucket: RouteRule["when"];
	/** True when no rule matched and the router fell through to the default. */
	readonly isDefault: boolean;
}

/** Inputs the router needs to classify a turn. */
export interface PickInput {
	readonly prompt: string;
	readonly history: readonly ConversationMessage[];
	/** When set, forces the classification — see `parseRouteOverride`. */
	readonly override?: "fast" | "slow";
}

/** A `/route fast` / `/route slow` slash command parsed off the user's prompt. */
export interface RouteOverrideParse {
	readonly override?: "fast" | "slow";
	/** Prompt with the leading `/route X` token stripped (or the original if none). */
	readonly remainingPrompt: string;
}

/**
 * Tease apart a `/route fast` or `/route slow` prefix off the user's prompt.
 * Anything else (or no prefix at all) returns the prompt unchanged. The
 * override applies to ONE turn — callers shouldn't persist it.
 */
export function parseRouteOverride(prompt: string): RouteOverrideParse {
	const m = /^\s*\/route\s+(fast|slow)\b\s*/i.exec(prompt);
	if (!m) return { remainingPrompt: prompt };
	const override = m[1].toLowerCase() as "fast" | "slow";
	return { override, remainingPrompt: prompt.slice(m[0].length) };
}

/**
 * Returns the bucket inferred from prompt length + recent tool-call density,
 * before any user override is applied. Exposed for unit testing — callers
 * normally hit `ModelRouter.classify`.
 */
export function classifyDifficulty(
	prompt: string,
	history: readonly ConversationMessage[],
): RouteRule["when"] {
	// 1. Recent tool-call estimate from the LAST assistant turn. We walk
	//    backward to the most recent assistant message (skipping pure tool
	//    rows) and count its `tool_call` parts. >5 calls in a single turn
	//    is a strong signal the model is in deep agentic territory.
	const toolCalls = countRecentToolCalls(history);
	if (toolCalls > 5) return "hard";

	// 2. Prompt length heuristic — coarse but works as a sanity floor.
	const len = prompt.length;
	if (len < 200) return "trivial";
	if (len < 1000) return "easy";
	if (len < 4000) return "medium";
	return "hard";
}

function countRecentToolCalls(history: readonly ConversationMessage[]): number {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		let n = 0;
		for (const p of msg.parts) if (p.kind === "tool_call") n++;
		return n;
	}
	return 0;
}

const OVERRIDE_BUCKET: Record<"fast" | "slow", RouteRule["when"]> = {
	fast: "trivial",
	slow: "hard",
};

export interface ModelRouterOptions {
	/**
	 * Final fallback when neither rules nor an override produce a match. The
	 * agent loop's existing single-provider behavior — provided so the router
	 * is a strict superset of the legacy code path.
	 */
	readonly defaultProviderId: string;
	readonly defaultModel?: string;
}

/**
 * `ModelRouter` is intentionally tiny — it owns the classification heuristic
 * and the rule lookup, nothing more. The actual provider streaming stays in
 * `chat-panel.ts`; the router just tells it which provider/model to use.
 */
export class ModelRouter {
	private readonly rules: readonly RouteRule[];

	constructor(
		private readonly config: RoutingConfig,
		private readonly opts: ModelRouterOptions,
	) {
		// Only rules whose providerId / shape look reasonable. We deliberately
		// don't validate the providerId against the registry here — that's a
		// runtime concern handled at pick-time so a typo'd rule produces a
		// clear "unknown provider" error instead of being silently dropped.
		this.rules = config.rules ?? [];
	}

	/** Combine override + heuristics into a single bucket. */
	classify(input: PickInput): RouteRule["when"] {
		if (input.override) return OVERRIDE_BUCKET[input.override];
		return classifyDifficulty(input.prompt, input.history);
	}

	/**
	 * Pick the provider/model for the next turn. When routing is disabled or
	 * no rule matches, returns the configured defaults so callers can use a
	 * single code path. The `isDefault` flag lets the UI badge only fire when
	 * a non-default route actually triggered.
	 */
	pick(input: PickInput): RouteDecision {
		if (!this.config.enabled) {
			return {
				providerId: this.opts.defaultProviderId,
				...(this.opts.defaultModel ? { model: this.opts.defaultModel } : {}),
				reason: "routing disabled",
				bucket: "easy",
				isDefault: true,
			};
		}

		const bucket = this.classify(input);
		const match = this.rules.find((r) => r.when === bucket);
		if (match) {
			return {
				providerId: match.providerId,
				...(match.model ? { model: match.model } : {}),
				reason: `matched rule when=${bucket}${input.override ? ` (override=${input.override})` : ""}`,
				bucket,
				isDefault: false,
			};
		}
		return {
			providerId: this.opts.defaultProviderId,
			...(this.opts.defaultModel ? { model: this.opts.defaultModel } : {}),
			reason: `no rule for ${bucket}; using default`,
			bucket,
			isDefault: true,
		};
	}

	/** The configured fallback, if any. Used by `withRetryFallback`. */
	getFallback(): RoutingConfig["fallback"] {
		return this.config.fallback;
	}
}

// ---------------------------------------------------------------------------
// Rate-limit aware retry/fallback wrapper.
// ---------------------------------------------------------------------------

/** Resolves a provider spec by id. Caller supplies this so we don't import a
 * concrete registry type and keep the router decoupled. */
export type ProviderLookup = (providerId: string) => ProviderSpec | undefined;

export interface FallbackTarget {
	readonly providerId: string;
	readonly model?: string;
}

/**
 * Wrap a provider's `stream` call so HTTP-429 / "rate_limit_exceeded" failures
 * trigger one bounded retry against the same primary, then fall through to
 * the configured fallback target. The wrapper is implemented as an async
 * generator so it preserves streaming behavior to the conductor.
 *
 * Semantics:
 *   - Detect the rate-limit either via an `error` event from the primary
 *     stream whose message looks like `429` / `rate_limit`, or a thrown
 *     error matching the same.
 *   - Sleep min(retry-after, 30s). When `Retry-After` is unknown we use 1s.
 *   - On the SECOND failure, switch to `fallback` and stream from there.
 *   - When `fallback` is unset, surface the original error to the caller.
 *
 * NOTE: we can't peek `Retry-After` from the provider abstraction because the
 * Response is internal to the stream. So `retryAfterMs` is supplied by the
 * caller when available; otherwise we use a small default backoff.
 */
export async function* withRetryFallback(
	primary: { readonly providerId: string; readonly model?: string },
	request: ProviderRequest,
	lookup: ProviderLookup,
	fallback: FallbackTarget | undefined,
	opts: {
		readonly retryAfterMs?: number;
		readonly sleep?: (ms: number) => Promise<void>;
		readonly onSwitchToFallback?: (reason: string) => void;
	} = {},
): AsyncIterable<ProviderStreamEvent> {
	const sleep = opts.sleep ?? defaultSleep;
	const maxBackoffMs = 30_000;

	for (let attempt = 0; attempt < 2; attempt++) {
		const spec = lookup(primary.providerId);
		if (!spec) {
			yield {
				type: "error",
				message: `Router: unknown provider '${primary.providerId}'`,
			};
			yield { type: "message_end", stopReason: "error" };
			return;
		}
		const req: ProviderRequest = {
			...request,
			modelId: primary.model ?? request.modelId,
		};
		const result = await collectUntilRateLimit(spec, req);
		// Replay buffered events to the caller in order — by the time we get
		// here, either the stream finished successfully or we detected a 429.
		for (const ev of result.events) yield ev;
		if (!result.rateLimited) return;
		// First 429: backoff + retry against the same primary. Second 429:
		// fall through to the fallback below.
		if (attempt === 0) {
			const wait = Math.min(opts.retryAfterMs ?? 1000, maxBackoffMs);
			await sleep(wait);
			continue;
		}
		// Second attempt also rate-limited — switch to fallback if we have one.
		if (!fallback) {
			yield {
				type: "error",
				message: `Provider '${primary.providerId}' rate-limited and no fallback configured.`,
			};
			yield { type: "message_end", stopReason: "error" };
			return;
		}
		opts.onSwitchToFallback?.(
			`Primary '${primary.providerId}' rate-limited; switching to fallback '${fallback.providerId}'.`,
		);
		const fbSpec = lookup(fallback.providerId);
		if (!fbSpec) {
			yield {
				type: "error",
				message: `Router fallback unknown: '${fallback.providerId}'`,
			};
			yield { type: "message_end", stopReason: "error" };
			return;
		}
		const fbReq: ProviderRequest = {
			...request,
			modelId: fallback.model ?? request.modelId,
		};
		yield* fbSpec.stream(fbReq);
		return;
	}
}

interface CollectResult {
	readonly events: readonly ProviderStreamEvent[];
	readonly rateLimited: boolean;
}

/**
 * Drain a provider stream into a buffer, watching for a rate-limit error in
 * the event stream. We have to drain into memory because async generators in
 * `withRetryFallback` need the ability to discard a half-streamed attempt
 * and switch providers cleanly. For a routed turn this is fine — by the time
 * we know it's rate-limited the stream is short.
 */
async function collectUntilRateLimit(
	spec: ProviderSpec,
	req: ProviderRequest,
): Promise<CollectResult> {
	const buffered: ProviderStreamEvent[] = [];
	try {
		for await (const ev of spec.stream(req)) {
			if (ev.type === "error" && looksLikeRateLimit(ev.message)) {
				return { events: [], rateLimited: true };
			}
			buffered.push(ev);
		}
	} catch (err) {
		if (looksLikeRateLimit(err instanceof Error ? err.message : String(err))) {
			return { events: [], rateLimited: true };
		}
		// Non-rate-limit errors: re-emit as an error event so the caller's
		// conductor sees a clean terminal pair. We deliberately don't rethrow
		// because the wrapper is mid-iteration.
		buffered.push({
			type: "error",
			message: err instanceof Error ? err.message : String(err),
		});
		buffered.push({ type: "message_end", stopReason: "error" });
	}
	return { events: buffered, rateLimited: false };
}

/** Lightweight pattern match — covers both HTTP-status-coded and JSON-coded 429s. */
export function looksLikeRateLimit(message: string): boolean {
	if (!message) return false;
	const m = message.toLowerCase();
	return (
		m.includes("429") ||
		m.includes("rate_limit_exceeded") ||
		m.includes("rate limit") ||
		m.includes("too many requests")
	);
}

function defaultSleep(ms: number): Promise<void> {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
