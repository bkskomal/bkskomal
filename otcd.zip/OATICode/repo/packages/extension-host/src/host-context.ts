import * as cp from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import type {
	ApprovalRequest,
	BackgroundProcessHandle,
	BackgroundProcessOptions,
	CodebaseSearchProvider,
	DiffPreview,
	DocumentSymbol,
	ExecOptions,
	ExecResult,
	ExecShell,
	HostContext,
	LogLevel,
	PersistentFact,
	ScratchpadNote,
	SpawnSubAgentsOptions,
	SubAgentRequest,
	SubAgentResult,
	SymbolHit,
	SymbolLookupProvider,
	WorkspaceContextSnapshot,
} from "@oati/shared";
import * as vscode from "vscode";
import { addFact as addFactStore, loadFacts as loadFactsStore } from "./agent-facts";
import { BackgroundProcessRegistry } from "./background-processes";
// R8-C: pluggable context-provider bridge — surfaces the in-process registry
// to tools via `ctx.contextProviders` without leaking the implementation.
import { listContextProviders, resolveContextMention } from "./context-providers";
// R6-E: debug bridge — wraps vscode.debug.* for the agent's debug_* tools.
import { DebugBridge } from "./debug-bridge";
// R4-B: diagnostics bridge
import { createDiagnosticsProvider } from "./diagnostics-bridge";
// R6-B: notebook bridge
import { createNotebookProvider } from "./notebook-bridge";
import {
	dropScratchpad,
	ensureScratchpad,
	scratchpadRead as readScratchpad,
	scratchpadWrite as writeScratchpad,
} from "./scratchpad";
import { resolvePrimaryWorkspacePath } from "./workspace";

export interface HostContextDeps {
	readonly output: vscode.OutputChannel;
	requestApproval(req: Omit<ApprovalRequest, "id">): Promise<boolean>;
	// 2026-05-27: optional ask-user round-trip. ChatPanel implements this
	// (per-panel webview pump). When omitted the host falls back to the
	// askUserTool's default (auto-pick option[0]) — useful for headless /
	// test harnesses.
	askUser?(
		req: import("@oati/shared").AskUserRequest,
	): Promise<import("@oati/shared").AskUserAnswer>;
	showDiff(diff: DiffPreview): Promise<void>;
	spawnSubAgent?(req: SubAgentRequest, opts?: SpawnSubAgentsOptions): Promise<SubAgentResult>;
	/**
	 * Optional channel for tool-progress events. Wired by chat-panel.ts so the
	 * webview can render streaming tool output as it arrives.
	 */
	emitToolProgress?(callId: string, chunk: string): void;
	/**
	 * Optional codebase index. The extension-host lazy-creates one against the
	 * active workspace on first use and reuses it across panels; pass that
	 * shared instance through here.
	 */
	getCodebaseIndex?(): CodebaseSearchProvider | undefined;
	// R5-C: optional cross-session conversation index. Wired the same way as
	// `getCodebaseIndex` — extension.ts owns the lifecycle and passes a
	// getter so the host can return undefined until the index is ready.
	getConversationSearch?(): import("@oati/shared").ConversationSearchProvider | undefined;
	/**
	 * Absolute path to the bundled skills directory shipped with the
	 * extension. When set, the skills loader merges these built-in playbooks
	 * with any workspace-local skills under `.oati/skills`.
	 */
	readonly bundledSkillsDir?: string;
	/**
	 * Update the agent-managed todo list for the current session. Wired by
	 * the chat-panel so the snapshot is both persisted and broadcast to the
	 * webview as a `todos_updated` event.
	 */
	updateTodos?(items: readonly import("@oati/shared").UiTodoItem[]): void;
	/**
	 * Notify when the workspace-root override changes. Chat panel hooks
	 * this to broadcast a fresh `workspace_info` event to the webview so
	 * the project chip reflects the new path.
	 */
	onWorkspaceRootChanged?(resolved: string): void;
	/**
	 * Phase 1.3: lazy getter for the rerank LLM call. Returns undefined
	 * when the user has not opted into reranking via
	 * `oati.codebaseIndex.rerank`. The chat panel owns the gating
	 * (setting check + provider lookup) so the host-context layer stays
	 * unaware of VS Code config plumbing.
	 */
	getRerankerLlmCall?(): ((prompt: string, signal?: AbortSignal) => Promise<string>) | undefined;
	/**
	 * Phase 2.3: lazy getter for the active model id. Returns the
	 * resolved model id from the currently-active provider + settings
	 * snapshot. Used by capability-aware tools (e.g.,
	 * `spawn_parallel_agents`) to look up per-model caps in
	 * `detectModelQuirks`. Returns undefined before any model is wired.
	 */
	getActiveModelId?(): string | undefined;
	/**
	 * 2026-06-01: optional repo-map builder. Called once per Agent
	 * session by the agent loop; the returned string is appended to the
	 * mode's system prompt for orientation. Implementations should bound
	 * their output to `opts.tokenBudget` (advisory, defaults to 8000).
	 * Returning undefined / empty string is fine — the agent runs
	 * without a repo map in that case.
	 */
	getRepoMap?(opts?: { tokenBudget?: number }): Promise<string | undefined>;
}

export function createHostContext(deps: HostContextDeps): HostContext {
	const decoder = new TextDecoder();
	const encoder = new TextEncoder();
	// Per-panel workspace-root override — populated by `setWorkspaceRoot`
	// (invoked from the `set_workspace_root` tool or the `/cwd` slash
	// command). When set, takes precedence over the IDE's idea of the
	// primary workspace path for THIS panel's tool calls.
	let workspaceOverride: string | undefined;
	// 2026-05-23: per-panel registry for `start_background_process`.
	// Exposed via the registry methods on the returned host. ChatPanel
	// hooks dispose() to `bgRegistry.disposeAll()` so orphan dev servers
	// never outlive their chat panel.
	const bgRegistry = new BackgroundProcessRegistry();

	function effectiveRoot(): string | undefined {
		return workspaceOverride ?? resolvePrimaryWorkspacePath();
	}

	function resolvePath(p: string): vscode.Uri {
		if (path.isAbsolute(p)) return vscode.Uri.file(p);
		// CRITICAL: prefer the per-panel override (set via set_workspace_root
		// or /cwd) so relative paths follow what the user / model just said.
		// Falling through to workspaceFolders[0] freezes the root at IDE
		// startup time and silently breaks every relative path after a
		// workspace switch.
		const overrideOrIdeRoot = effectiveRoot();
		if (overrideOrIdeRoot) return vscode.Uri.file(path.resolve(overrideOrIdeRoot, p));
		const root = vscode.workspace.workspaceFolders?.[0]?.uri;
		if (!root) throw new Error("No workspace folder open");
		return vscode.Uri.joinPath(root, p);
	}

	const base: HostContext = {
		async readFile(p: string): Promise<string> {
			const uri = resolvePath(p);
			try {
				const data = await vscode.workspace.fs.readFile(uri);
				return decoder.decode(data);
			} catch (err) {
				throw new Error(
					await formatPathError(
						"read_file",
						p,
						uri.fsPath,
						effectiveRoot() ?? "(no workspace open)",
						err,
					),
				);
			}
		},
		async writeFile(p: string, content: string): Promise<void> {
			const uri = resolvePath(p);
			try {
				await vscode.workspace.fs.writeFile(uri, encoder.encode(content));
			} catch (err) {
				throw new Error(
					await formatPathError(
						"write_file",
						p,
						uri.fsPath,
						effectiveRoot() ?? "(no workspace open)",
						err,
					),
				);
			}
		},
		async readDir(p, dirOpts) {
			const uri = resolvePath(p);
			const cap = Math.min(dirOpts?.maxEntries ?? 500, 2000);
			try {
				const items = await vscode.workspace.fs.readDirectory(uri);
				const entries: { name: string; type: "file" | "directory" }[] = [];
				if (dirOpts?.recursive) {
					const walk = async (dirUri: vscode.Uri, prefix: string): Promise<void> => {
						if (entries.length >= cap) return;
						const inner = await vscode.workspace.fs.readDirectory(dirUri);
						for (const [name, type] of inner) {
							if (entries.length >= cap) break;
							const rel = prefix ? `${prefix}/${name}` : name;
							const isDir = (type & vscode.FileType.Directory) !== 0;
							entries.push({ name: rel, type: isDir ? "directory" : "file" });
							if (isDir) await walk(vscode.Uri.joinPath(dirUri, name), rel);
						}
					};
					await walk(uri, "");
				} else {
					for (const [name, type] of items.slice(0, cap)) {
						entries.push({
							name,
							type: (type & vscode.FileType.Directory) !== 0 ? "directory" : "file",
						});
					}
				}
				entries.sort((a, b) => {
					if (a.type !== b.type) return a.type === "directory" ? -1 : 1;
					return a.name.localeCompare(b.name);
				});
				return { path: uri.fsPath, entries, truncated: entries.length >= cap };
			} catch (err) {
				throw new Error(
					await formatPathError(
						"list_dir",
						p,
						uri.fsPath,
						effectiveRoot() ?? "(no workspace open)",
						err,
					),
				);
			}
		},
		async streamFileWrite(
			p: string,
			content: string,
			opts?: { chunkChars?: number; frameMs?: number },
		): Promise<void> {
			const uri = resolvePath(p);
			const animationCfg = vscode.workspace.getConfiguration("oati.streamingWrites");
			const animationEnabled = animationCfg.get<boolean>("enabled", true);
			// Bail out on giant files — animation feels slow and the editor
			// chokes if we push 100k chunks. Threshold of 24KB matches what
			// Cursor switches to "instant apply" at.
			const MAX_ANIMATED_BYTES = 24 * 1024;
			if (!animationEnabled || content.length > MAX_ANIMATED_BYTES) {
				await vscode.workspace.fs.writeFile(uri, encoder.encode(content));
				return;
			}
			const chunkChars = Math.max(40, Math.min(512, opts?.chunkChars ?? 160));
			const frameMs = Math.max(8, Math.min(48, opts?.frameMs ?? 16));
			try {
				// Make sure the file exists on disk first so showTextDocument
				// has something to open, even for brand-new files.
				try {
					await vscode.workspace.fs.stat(uri);
				} catch {
					await vscode.workspace.fs.writeFile(uri, new Uint8Array());
				}
				const doc = await vscode.workspace.openTextDocument(uri);
				const editor = await vscode.window.showTextDocument(doc, {
					preview: false,
					preserveFocus: true,
				});
				// Clear existing content as a single edit so we don't fight
				// the user's cursor mid-stream.
				const fullRange = new vscode.Range(doc.positionAt(0), doc.positionAt(doc.getText().length));
				await editor.edit((eb) => {
					eb.delete(fullRange);
				});
				// Push the new content in chunks; brief async sleep between
				// frames so the user sees the file growing line-by-line.
				for (let i = 0; i < content.length; i += chunkChars) {
					const slice = content.slice(i, i + chunkChars);
					await editor.edit((eb) => {
						eb.insert(doc.positionAt(doc.getText().length), slice);
					});
					// Keep viewport pinned to the writing position.
					const endPos = doc.positionAt(doc.getText().length);
					editor.revealRange(new vscode.Range(endPos, endPos));
					await new Promise<void>((resolve) => setTimeout(resolve, frameMs));
				}
				// Persist to disk (the editor.edit changes only the in-memory
				// buffer; explicit save commits it).
				await doc.save();
			} catch {
				// Any failure: fall back to the plain write so the agent isn't
				// stuck in a half-animated state.
				await vscode.workspace.fs.writeFile(uri, encoder.encode(content));
			}
		},
		async fileExists(p: string): Promise<boolean> {
			try {
				await vscode.workspace.fs.stat(resolvePath(p));
				return true;
			} catch {
				return false;
			}
		},
		async exec(command: string, options?: ExecOptions): Promise<ExecResult> {
			// CRITICAL: honour the workspace override first (set via
			// set_workspace_root / /cwd) so shell commands run from the
			// folder the user / model just selected — not the frozen
			// workspaceFolders[0] snapshot from IDE startup.
			const cwd = options?.cwd ?? effectiveRoot();
			const env = { ...process.env, ...(options?.env ?? {}) };
			const timeout = options?.timeoutMs ?? 60_000;
			const shell = options?.shell ?? "auto";
			// All non-`auto` shells go through the streaming spawn path so the
			// shell executable and arguments can be resolved explicitly. For
			// `auto`, keep the historical cp.exec behavior to preserve existing
			// stderr ordering semantics when no progress callback is wired.
			if (options?.onChunk || shell !== "auto") {
				const onChunk = options?.onChunk ?? (() => {});
				return execStreaming(command, { cwd, env, timeout, onChunk, shell });
			}
			return new Promise<ExecResult>((resolve) => {
				cp.exec(
					command,
					{
						cwd,
						timeout,
						env,
						maxBuffer: 10 * 1024 * 1024,
					},
					(err, stdout, stderr) => {
						// R7-C bug fix: previous logic checked `typeof err.code === "number"`,
						// but Node's `cp.exec` callback err object exposes the exit code
						// as `err.code: number` while `NodeJS.ErrnoException.code` is
						// typed as `string`. The narrow cast worked at runtime but failed
						// to distinguish exit-code errors from spawn errors (ENOENT
						// returns code as a string like "ENOENT"). Use a properly typed
						// extraction so a non-zero exit surfaces as the real exit code
						// and a spawn failure surfaces as `1`.
						const execErr = err as (Error & { code?: number | string }) | null;
						let exitCode = 0;
						if (execErr) {
							if (typeof execErr.code === "number") {
								exitCode = execErr.code;
							} else {
								// Either a string error code (ENOENT, etc) or a signal kill.
								exitCode = 1;
							}
						}
						resolve({
							stdout: stdout?.toString() ?? "",
							stderr: stderr?.toString() ?? "",
							exitCode,
						});
					},
				);
			});
		},
		workspaceRoot(): string | undefined {
			// Active-editor-aware in multi-root workspaces so tools that read
			// the project root land in the folder the user is actually editing.
			// See `workspace.ts` for the resolution rules.
			//
			// The user (or model) may have overridden the root for the current
			// session via the `set_workspace_root` tool or the `/cwd` slash
			// command. Override wins; otherwise fall back to the IDE's view.
			return workspaceOverride ?? resolvePrimaryWorkspacePath();
		},
		async setWorkspaceRoot(p: string): Promise<string> {
			const fs = await import("node:fs/promises");
			const current = workspaceOverride ?? resolvePrimaryWorkspacePath();
			const resolved = path.isAbsolute(p) ? p : path.resolve(current ?? process.cwd(), p);
			try {
				const stat = await fs.stat(resolved);
				if (!stat.isDirectory()) {
					throw new Error(`${resolved} exists but is not a directory`);
				}
			} catch (err) {
				const msg = err instanceof Error ? err.message : String(err);
				throw new Error(`Cannot set workspace root to ${resolved}: ${msg}`);
			}
			workspaceOverride = resolved;
			try {
				deps.onWorkspaceRootChanged?.(resolved);
			} catch {
				/* notification is best-effort */
			}
			return resolved;
		},
		requestApproval(req) {
			return deps.requestApproval(req);
		},
		// 2026-05-27: ask_user round-trip. When deps.askUser is omitted
		// (test harness, headless) we don't define the method at all on
		// the returned context — the askUserTool sees `ctx.askUser ===
		// undefined` and falls back to auto-picking option[0].
		...(deps.askUser
			? {
					askUser(req: import("@oati/shared").AskUserRequest) {
						if (!deps.askUser) throw new Error("askUser not wired");
						return deps.askUser(req);
					},
				}
			: {}),
		async showDiff(diff: DiffPreview): Promise<void> {
			await deps.showDiff(diff);
		},
		log(level: LogLevel, message: string): void {
			deps.output.appendLine(`[${level}] ${message}`);
		},
		spawnSubAgent: deps.spawnSubAgent
			? (req) => {
					if (!deps.spawnSubAgent) throw new Error("spawnSubAgent not wired");
					return deps.spawnSubAgent(req);
				}
			: undefined,
		spawnSubAgentsParallel: deps.spawnSubAgent
			? async (requests, concurrency, opts) => {
					const spawn = deps.spawnSubAgent;
					if (!spawn) throw new Error("spawnSubAgent not wired");
					const reqs = [...requests];
					if (reqs.length === 0) return [];
					const cap = Math.max(1, Math.min(concurrency, reqs.length));
					// Mint a parent agent id for this batch so sibling sub-agents
					// share a scratchpad bucket.
					const parentAgentId = opts?.parentAgentId ?? `parent_${nextParentId()}`;
					ensureScratchpad(parentAgentId);
					const childOpts: SpawnSubAgentsOptions = {
						parentAgentId,
						scope: "sub-agent",
					};
					const results: SubAgentResult[] = new Array(reqs.length);
					try {
						await pool(reqs, cap, async (req, idx) => {
							results[idx] = await spawn(req, childOpts);
						});
					} finally {
						// Drop the scratchpad bucket as soon as the parent run completes
						// so we don't accumulate per-run state across the extension's
						// lifetime.
						dropScratchpad(parentAgentId);
					}
					return results;
				}
			: undefined,
		get codebaseIndex(): CodebaseSearchProvider | undefined {
			return deps.getCodebaseIndex?.();
		},
		// 2026-06-01: repo-map provider. Delegates to the dep getter so
		// the actual workspace walk + symbol extract runs inside the
		// extension-host process (the agent-core layer stays
		// filesystem-agnostic).
		...(deps.getRepoMap
			? {
					async getRepoMap(opts?: { tokenBudget?: number }): Promise<string | undefined> {
						return deps.getRepoMap?.(opts);
					},
				}
			: {}),
		// 2026-06-03: project memory (OATI.md / CLAUDE.md). Read at
		// workspace root, returned as the file's text content. Reuses
		// the existing `loadProjectMemory` helper that already supports
		// the candidate-paths convention. Stays in-process; the agent
		// caches the result for the life of the session.
		async getProjectMemory(): Promise<string | undefined> {
			const root = effectiveRoot();
			if (!root) return undefined;
			try {
				const { loadProjectMemory } = await import("./project-memory");
				const memory = await loadProjectMemory(root);
				return memory?.content;
			} catch (err) {
				deps.output.appendLine(
					`[project-memory] load failed: ${err instanceof Error ? err.message : String(err)}`,
				);
				return undefined;
			}
		},
		// 2026-06-03: append-to-project-memory. Bootstraps OATI.md from
		// the starter template when no memory file exists. Used by the
		// suggest_project_memory_addition tool so the model can propose
		// durable facts at end-of-turn.
		async appendToProjectMemory(chunk: string, source?: "agent" | "user"): Promise<{ path: string }> {
			const root = effectiveRoot();
			if (!root) throw new Error("appendToProjectMemory: no workspace root");
			const { appendToProjectMemory } = await import("./project-memory");
			return appendToProjectMemory(root, chunk, source);
		},
		// 2026-06-03: per-session archive — append/read the markdown
		// file under `.oati/sessions/<sessionId>/archive.md`. Used by
		// the agent's predictive compact to preserve the dropped middle
		// of history and by the `read_session_archive` tool to recover
		// detail later.
		async appendToSessionArchive(sessionId: string, content: string): Promise<void> {
			const root = effectiveRoot();
			if (!root) return;
			try {
				const { appendToSessionArchive } = await import("./session-archive");
				await appendToSessionArchive(root, sessionId, content);
			} catch (err) {
				deps.output.appendLine(
					`[session-archive] append failed: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		},
		async readSessionArchive(sessionId: string): Promise<string | undefined> {
			const root = effectiveRoot();
			if (!root) return undefined;
			try {
				const { readSessionArchive } = await import("./session-archive");
				return await readSessionArchive(root, sessionId);
			} catch {
				return undefined;
			}
		},
		// Phase 1.3: lazy getter so the setting-gated rerank capability
		// reflects the CURRENT setting value at each call (a user can
		// toggle reranking mid-session without rebuilding the host).
		get rerankerLlmCall() {
			return deps.getRerankerLlmCall?.();
		},
		// Phase 2.3: lazy getter so the active model id reflects what's
		// currently selected. Mid-session model switches via the picker
		// take effect on the next tool call without rebuilding the host.
		get activeModelId() {
			return deps.getActiveModelId?.();
		},
		// 2026-05-23: background-process registry. Resolves the working
		// directory at call time using the per-panel override (set by
		// `set_workspace_root` or `/cwd`) so dev servers spawn from the
		// directory the user is actually working in.
		async startBackgroundProcess(
			command: string,
			options?: BackgroundProcessOptions,
		): Promise<BackgroundProcessHandle> {
			const cwd = options?.cwd ?? effectiveRoot() ?? process.cwd();
			return bgRegistry.start(command, cwd, options);
		},
		async stopBackgroundProcess(pid: number) {
			return bgRegistry.stop(pid);
		},
		listBackgroundProcesses() {
			return bgRegistry.list();
		},
		// R5-C: surface the cross-session conversation index to tools (e.g.
		// `search_conversations`). Lazily resolved through the dep getter so
		// the host can return undefined until the index is initialized.
		get conversationSearch() {
			return deps.getConversationSearch?.();
		},
		async getWorkspaceContext(): Promise<WorkspaceContextSnapshot> {
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			const activeEditor = vscode.window.activeTextEditor;
			const openFiles = vscode.window.visibleTextEditors
				.map((ed) => relativize(ed.document.uri.fsPath, root))
				.filter((p): p is string => !!p);

			const result: WorkspaceContextSnapshot = {
				workspaceRoot: root,
				openFiles,
			};

			if (!activeEditor) return result;

			const activeFile = relativize(activeEditor.document.uri.fsPath, root);
			const lang = activeEditor.document.languageId;
			const sel = activeEditor.selection;
			const hasSelection = !sel.isEmpty;

			return {
				...result,
				activeFile,
				activeFileLanguage: lang,
				...(hasSelection
					? {
							activeSelection: {
								text: activeEditor.document.getText(sel),
								startLine: sel.start.line + 1,
								endLine: sel.end.line + 1,
							},
						}
					: {}),
			};
		},
		async loadFacts(): Promise<readonly PersistentFact[]> {
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			if (!root) return [];
			return loadFactsStore(root);
		},
		async addFact(fact): Promise<readonly PersistentFact[]> {
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			if (!root) throw new Error("addFact: no workspace folder open");
			return addFactStore(root, fact);
		},
		scratchpadWrite(agentId: string, note: string): void {
			// Top-level agents use ""; their writes are dropped. Sub-agents get a
			// wrapper that rewrites "" → their parent id so this branch only fires
			// for ill-formed direct calls from the top-level agent.
			writeScratchpad(agentId, note);
		},
		scratchpadRead(agentId: string): readonly ScratchpadNote[] {
			return readScratchpad(agentId);
		},
		emitToolProgress(callId, chunk) {
			deps.emitToolProgress?.(callId, chunk);
		},
		// APPENDED in R3-A — LSP-backed lookups via vscode.commands.executeCommand.
		symbols: createSymbolsProvider(),
		// R4-B: diagnostics bridge — read/subscribe to LSP diagnostics.
		diagnostics: createDiagnosticsProvider(),
		// R6-E: debug bridge — DAP session introspection + breakpoint mgmt.
		debug: DebugBridge.instance(),
		// R6-B: notebooks — read/edit/execute .ipynb cells via the VS Code
		// notebook API. Non-VS Code hosts wire a different HostContext that
		// omits this field.
		notebooks: createNotebookProvider(),
		// R8-C: pluggable context-provider registry — surfaced to tools (and
		// thence the agent) so `resolve_context_mention` can fetch any
		// registered mention without re-implementing the lookup table.
		contextProviders: {
			async resolve(mention, arg) {
				const result = await resolveContextMention(mention, arg, base);
				if (!result.ok) throw new Error(result.error);
				return result.content;
			},
			list() {
				return listContextProviders().map((p) => ({
					id: p.id,
					mention: p.mention,
					description: p.description,
				}));
			},
		},
		...(deps.bundledSkillsDir ? { bundledSkillsDir: deps.bundledSkillsDir } : {}),
		...(deps.updateTodos
			? {
					updateTodos: (items: readonly import("@oati/shared").UiTodoItem[]) => {
						deps.updateTodos?.(items);
					},
				}
			: {}),
	};

	return base;
}

/**
 * Wrap a HostContext so all scratchpad reads/writes silently route into
 * `parentAgentId`'s bucket. Used by `spawnSubAgent` to give each child sub-agent
 * a view of its parent's shared scratchpad without the agent loop needing to
 * thread the id explicitly.
 */
export function wrapHostForSubAgent(base: HostContext, parentAgentId: string): HostContext {
	return {
		...base,
		scratchpadWrite(_agentId: string, note: string): void {
			base.scratchpadWrite?.(parentAgentId, note);
		},
		scratchpadRead(_agentId: string): readonly ScratchpadNote[] {
			return base.scratchpadRead?.(parentAgentId) ?? [];
		},
	};
}

let parentIdCounter = 0;
function nextParentId(): string {
	parentIdCounter = (parentIdCounter + 1) % 1_000_000;
	return `${Date.now().toString(36)}_${parentIdCounter.toString(36)}`;
}

/**
 * Tiny concurrency pool: run `fn(item, index)` for each item with at most `n`
 * promises in flight at once. Errors propagate (rejects the whole pool, no
 * partial-result accumulator — callers wanting per-item errors should wrap
 * `fn` to return a discriminated union).
 */
async function pool<T>(
	items: readonly T[],
	n: number,
	fn: (item: T, index: number) => Promise<void>,
): Promise<void> {
	if (items.length === 0) return;
	const slots = Math.max(1, Math.min(n, items.length));
	let next = 0;
	const workers = new Array(slots).fill(0).map(async () => {
		while (true) {
			const idx = next++;
			if (idx >= items.length) return;
			await fn(items[idx], idx);
		}
	});
	await Promise.all(workers);
}

function relativize(absPath: string, root: string | undefined): string {
	if (!root) return absPath;
	const rel = path.relative(root, absPath);
	if (rel.startsWith("..") || path.isAbsolute(rel)) return absPath;
	return rel.replace(/\\/g, "/");
}

/**
 * Spawn a shell with stdout/stderr piped so chunks can be streamed live to the
 * caller's `onChunk` callback. Falls back to the same ExecResult shape as the
 * buffered path so callers don't need to care which mode was used.
 *
 * Total buffered output is capped at `STREAM_OUTPUT_CAP_BYTES` to mirror the
 * existing 10 MB maxBuffer; chunks past the cap are still streamed to the UI
 * (so live tailing isn't truncated visually) but the buffered ExecResult is
 * truncated with a tail marker.
 */
const STREAM_OUTPUT_CAP_BYTES = 10 * 1024 * 1024;

interface ExecStreamOptions {
	readonly cwd?: string;
	readonly env: NodeJS.ProcessEnv;
	readonly timeout: number;
	readonly onChunk: (chunk: string, stderr: boolean) => void;
	readonly shell?: ExecShell;
}

/**
 * Resolve a logical shell name into a real executable + argv. Falls back
 * gracefully on Windows: `bash` finds Git Bash by walking known install
 * roots, `pwsh` falls back to `powershell.exe` if PowerShell 7 isn't
 * installed. Returns `undefined` only when the requested shell genuinely
 * can't be located on this machine.
 *
 * PowerShell invocations deliberately do NOT pass `-ExecutionPolicy Bypass`
 * — we run under the user's existing machine policy. If a script is
 * blocked, the user should change their policy explicitly, not have the
 * extension override it.
 */
function resolveShell(
	shell: ExecShell,
	command: string,
): { exe: string; args: readonly string[] } | undefined {
	const isWindows = process.platform === "win32";
	const findOnPath = (name: string): string | undefined => {
		const exts = isWindows ? (process.env.PATHEXT ?? ".COM;.EXE;.BAT;.CMD").split(";") : [""];
		for (const dir of (process.env.PATH ?? "").split(path.delimiter)) {
			if (!dir) continue;
			for (const ext of exts) {
				const candidate = path.join(dir, name + (isWindows ? ext.toLowerCase() : ext));
				try {
					if (fs.existsSync(candidate)) return candidate;
				} catch {
					/* ignore */
				}
			}
		}
		return undefined;
	};
	const resolveBashWindows = (): string | undefined => {
		const candidates = [
			"C:\\Program Files\\Git\\bin\\bash.exe",
			"C:\\Program Files\\Git\\usr\\bin\\bash.exe",
			"C:\\Program Files (x86)\\Git\\bin\\bash.exe",
			path.join(process.env.ProgramW6432 ?? "", "Git", "bin", "bash.exe"),
			path.join(process.env.LOCALAPPDATA ?? "", "Programs", "Git", "bin", "bash.exe"),
		];
		for (const c of candidates) {
			try {
				if (c && fs.existsSync(c)) return c;
			} catch {
				/* ignore */
			}
		}
		return findOnPath("bash");
	};
	switch (shell) {
		case "auto":
			return isWindows
				? { exe: "cmd.exe", args: ["/d", "/s", "/c", command] }
				: { exe: "/bin/sh", args: ["-c", command] };
		case "sh":
			return { exe: isWindows ? "sh.exe" : "/bin/sh", args: ["-c", command] };
		case "cmd":
			return { exe: "cmd.exe", args: ["/d", "/s", "/c", command] };
		case "bash": {
			const exe = isWindows ? resolveBashWindows() : "/bin/bash";
			if (!exe) return undefined;
			return { exe, args: ["-lc", command] };
		}
		case "pwsh": {
			const exe = findOnPath("pwsh") ?? (isWindows ? "powershell.exe" : undefined);
			if (!exe) return undefined;
			return { exe, args: ["-NoProfile", "-NonInteractive", "-Command", command] };
		}
		case "powershell": {
			const exe = isWindows ? "powershell.exe" : findOnPath("pwsh");
			if (!exe) return undefined;
			return { exe, args: ["-NoProfile", "-NonInteractive", "-Command", command] };
		}
	}
}

function execStreaming(command: string, opts: ExecStreamOptions): Promise<ExecResult> {
	return new Promise<ExecResult>((resolve) => {
		const resolved = resolveShell(opts.shell ?? "auto", command);
		if (!resolved) {
			resolve({
				stdout: "",
				stderr: `Shell '${opts.shell}' not found on this machine.`,
				exitCode: 127,
			});
			return;
		}
		const child = cp.spawn(resolved.exe, [...resolved.args], {
			cwd: opts.cwd,
			env: opts.env,
			windowsHide: true,
		});

		let stdout = "";
		let stderr = "";
		let stdoutBytes = 0;
		let stderrBytes = 0;
		let settled = false;

		// 2026-05-28: kill-escalation. SIGTERM doesn't reliably kill long-
		// running servers (dotnet run, npm start, python http.server, …)
		// — on Windows it's a soft signal and on POSIX many runtimes
		// install handlers that swallow it. Without escalation, the
		// 'close' event never fires and the exec promise hangs forever,
		// blocking the agent turn indefinitely. Three-stage ladder:
		//   t = timeout: SIGTERM (try a clean shutdown)
		//   t + 5s:      hard kill (taskkill /F /T on Windows, SIGKILL elsewhere)
		//   t + 7s:      force-resolve with exitCode=124 so the agent
		//                isn't stuck even if the process is unkillable.
		let hardKillTimer: ReturnType<typeof setTimeout> | undefined;
		let forceResolveTimer: ReturnType<typeof setTimeout> | undefined;
		const timer = setTimeout(() => {
			try {
				child.kill("SIGTERM");
			} catch {
				/* ignore */
			}
			hardKillTimer = setTimeout(() => {
				if (settled) return;
				try {
					if (process.platform === "win32" && typeof child.pid === "number") {
						// /F = force, /T = also kill the child tree.
						cp.spawn("taskkill", ["/F", "/T", "/PID", String(child.pid)], {
							stdio: "ignore",
						});
					} else {
						child.kill("SIGKILL");
					}
				} catch {
					/* ignore */
				}
				forceResolveTimer = setTimeout(() => {
					if (settled) return;
					settled = true;
					resolve({
						stdout,
						stderr: `${stderr}\n[exec] command exceeded ${opts.timeout}ms timeout — force-killed after ${opts.timeout + 5000}ms`,
						exitCode: 124,
					});
				}, 2000);
			}, 5000);
		}, opts.timeout);

		const append = (data: Buffer | string, isErr: boolean) => {
			const text = typeof data === "string" ? data : data.toString("utf-8");
			opts.onChunk(text, isErr);
			if (isErr) {
				if (stderrBytes < STREAM_OUTPUT_CAP_BYTES) {
					stderr += text;
					stderrBytes += text.length;
				}
			} else if (stdoutBytes < STREAM_OUTPUT_CAP_BYTES) {
				stdout += text;
				stdoutBytes += text.length;
			}
		};

		child.stdout?.on("data", (d) => append(d, false));
		child.stderr?.on("data", (d) => append(d, true));

		const settle = (code: number | null, sigErr?: NodeJS.ErrnoException) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			if (hardKillTimer) clearTimeout(hardKillTimer);
			if (forceResolveTimer) clearTimeout(forceResolveTimer);
			const exitCode = typeof code === "number" ? code : sigErr ? 1 : 0;
			resolve({ stdout, stderr, exitCode });
		};

		child.on("close", (code) => settle(code));
		child.on("error", (err) => settle(null, err as NodeJS.ErrnoException));
	});
}

/**
 * Build the `symbols` capability that wraps `vscode.commands.executeCommand`
 * for the LSP-backed lookups exposed to the agent (references, definition,
 * document symbols). APPENDED in R3-A.
 *
 * Coordinate conventions:
 *   - The HostContext API takes 1-based line numbers (matching the rest of
 *     our index types) and 0-based column numbers (matching LSP/vscode).
 *   - LSP positions are 0-based on both axes; we translate `line - 1` on the
 *     way down and `line + 1` on the way back up.
 */
function createSymbolsProvider(): SymbolLookupProvider {
	function resolveUri(p: string): vscode.Uri {
		if (path.isAbsolute(p)) return vscode.Uri.file(p);
		const root = vscode.workspace.workspaceFolders?.[0]?.uri;
		if (!root) throw new Error("No workspace folder open");
		return vscode.Uri.joinPath(root, p);
	}

	async function snippetFor(uri: vscode.Uri, line0: number): Promise<string> {
		try {
			const doc = await vscode.workspace.openTextDocument(uri);
			const line = Math.max(0, Math.min(line0, doc.lineCount - 1));
			return doc.lineAt(line).text;
		} catch {
			return "";
		}
	}

	function relativize(uri: vscode.Uri): string {
		const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!root) return uri.fsPath;
		const rel = path.relative(root, uri.fsPath);
		if (rel.startsWith("..") || path.isAbsolute(rel)) return uri.fsPath;
		return rel.replace(/\\/g, "/");
	}

	async function locationsToHits(
		locations: readonly (vscode.Location | vscode.LocationLink)[] | undefined,
	): Promise<readonly SymbolHit[]> {
		if (!locations || locations.length === 0) return [];
		const out: SymbolHit[] = [];
		for (const loc of locations) {
			const targetUri = "targetUri" in loc ? loc.targetUri : loc.uri;
			const targetRange = "targetRange" in loc ? loc.targetRange : loc.range;
			const line0 = targetRange.start.line;
			const snippet = await snippetFor(targetUri, line0);
			out.push({
				path: relativize(targetUri),
				line: line0 + 1,
				character: targetRange.start.character,
				snippet,
			});
		}
		return out;
	}

	function symbolKindName(kind: vscode.SymbolKind): string {
		// vscode.SymbolKind is a numeric enum; map to a stable string the
		// agent can grep on. Falling back to the numeric value is fine — it's
		// still informative even when a new kind shows up.
		const names: Record<number, string> = {
			0: "File",
			1: "Module",
			2: "Namespace",
			3: "Package",
			4: "Class",
			5: "Method",
			6: "Property",
			7: "Field",
			8: "Constructor",
			9: "Enum",
			10: "Interface",
			11: "Function",
			12: "Variable",
			13: "Constant",
			14: "String",
			15: "Number",
			16: "Boolean",
			17: "Array",
			18: "Object",
			19: "Key",
			20: "Null",
			21: "EnumMember",
			22: "Struct",
			23: "Event",
			24: "Operator",
			25: "TypeParameter",
		};
		return names[kind as unknown as number] ?? String(kind);
	}

	function flattenDocumentSymbols(
		symbols: readonly vscode.DocumentSymbol[] | undefined,
		parent: string | undefined,
		out: DocumentSymbol[],
	): void {
		if (!symbols) return;
		for (const s of symbols) {
			out.push({
				name: s.name,
				kind: symbolKindName(s.kind),
				line: s.range.start.line + 1,
				endLine: s.range.end.line + 1,
				...(parent ? { parent } : {}),
			});
			if (s.children && s.children.length > 0) {
				flattenDocumentSymbols(s.children, s.name, out);
			}
		}
	}

	return {
		async findReferences(p, line, character) {
			const uri = resolveUri(p);
			const pos = new vscode.Position(Math.max(0, line - 1), Math.max(0, character));
			const locs = await vscode.commands.executeCommand<vscode.Location[]>(
				"vscode.executeReferenceProvider",
				uri,
				pos,
			);
			return locationsToHits(locs);
		},
		async findDefinition(p, line, character) {
			const uri = resolveUri(p);
			const pos = new vscode.Position(Math.max(0, line - 1), Math.max(0, character));
			const locs = await vscode.commands.executeCommand<(vscode.Location | vscode.LocationLink)[]>(
				"vscode.executeDefinitionProvider",
				uri,
				pos,
			);
			return locationsToHits(locs);
		},
		async documentSymbols(p) {
			const uri = resolveUri(p);
			// vscode.executeDocumentSymbolProvider returns either DocumentSymbol[]
			// (hierarchical) or SymbolInformation[] (flat) depending on the
			// provider. The DocumentSymbol path is the common case for the
			// languages we care about; we flatten it to match our spec.
			const result = await vscode.commands.executeCommand<vscode.DocumentSymbol[]>(
				"vscode.executeDocumentSymbolProvider",
				uri,
			);
			const flat: DocumentSymbol[] = [];
			flattenDocumentSymbols(result, undefined, flat);
			return flat;
		},
	};
}

/**
 * Claude-style diagnostic for file-IO failures. Same shape as the
 * sidecar `formatPathError` — the model gets the resolved path, the
 * workspace root that resolved it, a peek at the parent directory, and
 * concrete next-step suggestions instead of a bare ENOENT string.
 */
async function formatPathError(
	tool: string,
	requestedPath: string,
	resolvedPath: string,
	workspaceRoot: string,
	err: unknown,
): Promise<string> {
	const code = (err as NodeJS.ErrnoException | undefined)?.code ?? "";
	const baseMsg = err instanceof Error ? err.message : String(err);
	const lines: string[] = [
		`${tool} failed (${code || "error"}): ${baseMsg}`,
		"",
		`  Requested path  : ${requestedPath}`,
		`  Resolved path   : ${resolvedPath}`,
		`  Workspace root  : ${workspaceRoot}`,
	];
	const isMissing =
		code === "ENOENT" || code === "FileNotFound" || baseMsg.toLowerCase().includes("not found");
	if (isMissing) {
		const parent = path.dirname(resolvedPath);
		const basename = path.basename(resolvedPath);
		try {
			const parentUri = vscode.Uri.file(parent);
			const entries = await vscode.workspace.fs.readDirectory(parentUri);
			const names = entries
				.slice(0, 40)
				.map(([name, type]) => (type === vscode.FileType.Directory ? `${name}/` : name));
			lines.push("", `  Parent (${parent}) contains:`);
			for (const n of names) lines.push(`    - ${n}`);
			if (entries.length > 40) lines.push(`    … and ${entries.length - 40} more`);
			const suggestions = entries
				.map(([name]) => name)
				.filter(
					(n) =>
						n.toLowerCase().includes(basename.toLowerCase()) ||
						basename.toLowerCase().includes(n.toLowerCase()),
				)
				.slice(0, 5);
			if (suggestions.length > 0) {
				lines.push("", `  Did you mean: ${suggestions.join(", ")}`);
			}
		} catch (parentErr) {
			lines.push(
				"",
				`  Parent directory unreadable: ${parentErr instanceof Error ? parentErr.message : String(parentErr)}`,
				"  → The workspace root itself may be wrong. Call set_workspace_root with the absolute project path.",
			);
		}
	}
	lines.push(
		"",
		"Next steps you can try (pick ONE — do NOT retry the same call):",
		"  1. If the workspace root looks wrong, call set_workspace_root with the correct absolute path.",
		"  2. If the path looks wrong, call list_dir on its parent folder to verify the spelling.",
		"  3. If you used a relative path, retry with an absolute path. If absolute was wrong, the file does not exist there.",
		"  4. After 2 failed attempts, STOP and tell the user what failed and what you need.",
	);
	return lines.join("\n");
}
