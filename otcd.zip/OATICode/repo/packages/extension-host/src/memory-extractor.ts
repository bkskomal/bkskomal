// 2026-05-29: post-turn memory auto-extract. After a successful agent
// turn that did real work (writes, exec, edits), fire a SMALL LLM call
// against the active provider asking for 0-2 stable facts about the
// project that would be useful to remember for next session.
//
// The extraction is intentionally CONSERVATIVE:
//   - Returns nothing when the turn doesn't reveal a stable fact
//   - Marks each suggestion with confidence + reasoning so the user
//     can quickly judge before clicking Save
//   - Skips turn-specific stuff ("we just edited foo.ts") and things
//     obvious from the workspace structure
//
// This runs as a SIDECAR — not part of the agent loop. The main turn
// has already ended; we make one extra small completion call to
// produce a JSON array of suggestions, then surface them to the user.

import type { ConversationMessage, ProviderSpec } from "@oati/shared";

export interface MemorySuggestion {
	readonly fact: string;
	/** One-sentence reason — why is this stable / project-level? */
	readonly reasoning: string;
	/** "high" / "medium" / "low" — drives sort order in the UI. */
	readonly confidence: "high" | "medium" | "low";
}

export interface ExtractOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	/**
	 * Conversation history from the just-completed turn. The extractor
	 * picks the most-recent user message + every assistant/tool result
	 * after it as "this turn's evidence."
	 */
	readonly history: readonly ConversationMessage[];
	/**
	 * Facts already persisted — the extractor is told to skip
	 * suggestions duplicating these.
	 */
	readonly existingFacts: readonly string[];
	readonly signal?: AbortSignal;
}

/**
 * Should we even attempt extraction for this turn? Look at the most
 * recent assistant message — if its tool calls are ALL investigatory
 * (read-only) or ALL slash-command outputs, skip; nothing to learn yet.
 * Mutation tools (write_file, edit, exec, multi_cursor_edit, …) are
 * the signal that real project knowledge was acted on.
 */
const MUTATION_TOOLS = new Set([
	"write_file",
	"multi_cursor_edit",
	"smart_apply_patch",
	"edit_notebook_cell",
	"insert_notebook_cell",
	"delete_notebook_cell",
	"exec",
	"run_tests",
	"git_commit",
	"git_open_pr",
	"start_background_process",
	"stop_background_process",
	"remember_fact",
	"save_snippet",
]);

export function turnHasMutation(history: readonly ConversationMessage[]): boolean {
	// Walk back to the most recent user message; inspect every assistant
	// message after it for mutation-shaped tool calls.
	let lastUserIdx = -1;
	for (let i = history.length - 1; i >= 0; i--) {
		if (history[i].role === "user") {
			lastUserIdx = i;
			break;
		}
	}
	if (lastUserIdx < 0) return false;
	for (let i = lastUserIdx + 1; i < history.length; i++) {
		const m = history[i];
		if (m.role !== "assistant") continue;
		for (const p of m.parts) {
			if (p.kind === "tool_call" && MUTATION_TOOLS.has(p.name)) return true;
		}
	}
	return false;
}

export async function extractMemorySuggestions(opts: ExtractOptions): Promise<MemorySuggestion[]> {
	const evidence = summarizeRecentTurn(opts.history);
	if (evidence.length === 0) return [];

	const existingBlock =
		opts.existingFacts.length > 0
			? `## Facts already remembered (DO NOT suggest duplicates)\n\n${opts.existingFacts.map((f) => `- ${f}`).join("\n")}\n\n`
			: "";

	const prompt = `You are a memory curator for a coding assistant. Look at the recent agent turn below and propose 0-2 STABLE PROJECT-LEVEL FACTS worth remembering across sessions.

${existingBlock}## Recent turn

${evidence}

## What to suggest

Stable facts are things that will be true NEXT session too:
- Build / test / lint tooling ("Tests run via vitest in this repo")
- File-system conventions ("The backend lives in packages/server")
- User preferences expressed explicitly ("User prefers tabs over spaces")
- Integration quirks ("Auth uses Auth0 with SPA flow")
- Architecture choices ("Frontend is Preact, NOT React")

## What NOT to suggest

- Turn-specific actions ("We just edited foo.ts")
- Things visible from the workspace tree ("There's a package.json")
- Anything you're not confident is true
- Anything matching the already-remembered list above

## Output

Return ONLY a JSON array (no prose, no code fences) of objects:

\`\`\`
[
  { "fact": "Tests run via vitest", "reasoning": "Agent invoked 'npm test' which delegated to vitest per package.json", "confidence": "high" },
  { "fact": "User prefers descriptive variable names", "reasoning": "User explicitly asked to rename 'x' to 'parsedConfig'", "confidence": "medium" }
]
\`\`\`

Empty array \`[]\` is correct when nothing stable was learned. Be conservative — better to suggest 0 than to suggest noise.`;

	let raw = "";
	try {
		for await (const ev of opts.provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: prompt }] }],
			modelId: opts.modelId,
			temperature: 0.1,
			maxTokens: 800,
			...(opts.signal ? { signal: opts.signal } : {}),
		})) {
			if (ev.type === "text_delta") raw += ev.text;
			if (ev.type === "error") return [];
		}
	} catch {
		return [];
	}

	return parseSuggestions(raw);
}

function summarizeRecentTurn(history: readonly ConversationMessage[]): string {
	let lastUserIdx = -1;
	for (let i = history.length - 1; i >= 0; i--) {
		if (history[i].role === "user") {
			lastUserIdx = i;
			break;
		}
	}
	if (lastUserIdx < 0) return "";

	const blocks: string[] = [];
	const tail = history.slice(lastUserIdx);
	for (const msg of tail) {
		if (msg.role === "user") {
			const text = msg.parts
				.filter((p) => p.kind === "text")
				.map((p) => (p as { text: string }).text)
				.join("\n")
				.slice(0, 500);
			if (text.length > 0) blocks.push(`### User\n\n${text}`);
		} else if (msg.role === "assistant") {
			const textParts = msg.parts
				.filter((p) => p.kind === "text")
				.map((p) => (p as { text: string }).text)
				.join("\n")
				.slice(0, 800);
			const toolCalls = msg.parts
				.filter((p) => p.kind === "tool_call")
				.map((p) => {
					const tc = p as { name: string; args: unknown };
					const args = truncateForPrompt(JSON.stringify(tc.args ?? {}), 240);
					return `- ${tc.name}(${args})`;
				});
			const parts: string[] = [];
			if (textParts.length > 0) parts.push(textParts);
			if (toolCalls.length > 0) parts.push(`Tool calls:\n${toolCalls.join("\n")}`);
			if (parts.length > 0) blocks.push(`### Assistant\n\n${parts.join("\n\n")}`);
		} else if (msg.role === "tool") {
			const results = msg.parts
				.filter((p) => p.kind === "tool_result")
				.map((p) => {
					const tr = p as { output: unknown; isError?: boolean };
					const out = truncateForPrompt(
						typeof tr.output === "string" ? tr.output : JSON.stringify(tr.output),
						300,
					);
					return `${tr.isError ? "(error) " : ""}${out}`;
				});
			if (results.length > 0) blocks.push(`### Tool results\n\n${results.join("\n\n")}`);
		}
	}

	// Hard cap the whole evidence string so big turns don't blow the
	// extraction prompt budget.
	const joined = blocks.join("\n\n");
	return joined.length > 12_000 ? `${joined.slice(0, 12_000)}\n\n…[truncated]` : joined;
}

function truncateForPrompt(s: string, max: number): string {
	if (s.length <= max) return s;
	return `${s.slice(0, max)}…`;
}

function parseSuggestions(raw: string): MemorySuggestion[] {
	let t = raw.trim();
	const fence = t.match(/```(?:json)?\s*\n([\s\S]*?)\n```/);
	if (fence) t = fence[1].trim();
	let parsed: unknown;
	try {
		parsed = JSON.parse(t);
	} catch {
		return [];
	}
	if (!Array.isArray(parsed)) return [];

	const out: MemorySuggestion[] = [];
	for (const item of parsed) {
		if (!item || typeof item !== "object") continue;
		const o = item as Record<string, unknown>;
		const fact = typeof o.fact === "string" ? o.fact.trim() : "";
		const reasoning = typeof o.reasoning === "string" ? o.reasoning.trim() : "";
		if (fact.length === 0) continue;
		const confidence: MemorySuggestion["confidence"] =
			o.confidence === "high" ? "high" : o.confidence === "low" ? "low" : "medium";
		out.push({ fact, reasoning, confidence });
	}
	// Hard cap at 2 — the model is told 0-2 but we enforce.
	return out.slice(0, 2);
}
