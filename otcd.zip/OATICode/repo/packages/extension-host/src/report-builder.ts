// 2026-05-27: Comprehensive Word (.docx) report generation for /review
// and /qa outputs. Uses the `docx` npm package — pure JS, no native
// deps — to assemble a structured document with branded heading style,
// per-file finding/issue groupings, severity counts, and diff-style
// suggested-fix blocks.
//
// The caller (chat-panel) writes the returned Buffer directly to disk
// via Node's fs API rather than going through HostContext.writeFile,
// because writeFile is string-only and a .docx is binary.

import {
	AlignmentType,
	Document,
	HeadingLevel,
	Packer,
	Paragraph,
	ShadingType,
	Table,
	TableCell,
	TableRow,
	TextRun,
	WidthType,
} from "docx";
import type { QAIssue, QAResult } from "./qa";
import type { ReviewFinding, ReviewResult } from "./review";

export interface ReportMeta {
	readonly projectName: string;
	readonly model: string;
	readonly generatedAt: Date;
}

const BRAND_NAVY = "1A2B4A";
const SEVERITY_BLOCKING = "C0392B";
const SEVERITY_ADVISORY = "D97706";
const SOFT_GREY = "F1F3F6";
const SUBTLE_INK = "4A5A70";

function brandHeading(
	text: string,
	level: (typeof HeadingLevel)[keyof typeof HeadingLevel],
): Paragraph {
	return new Paragraph({
		heading: level,
		children: [new TextRun({ text, bold: true, color: BRAND_NAVY })],
		spacing: { before: 240, after: 120 },
	});
}

function metaParagraph(label: string, value: string): Paragraph {
	return new Paragraph({
		children: [
			new TextRun({ text: `${label}: `, bold: true, color: SUBTLE_INK, size: 20 }),
			new TextRun({ text: value, size: 20 }),
		],
		spacing: { after: 60 },
	});
}

function severityChip(severity: "blocking" | "advisory" | "off"): TableCell {
	const color = severity === "blocking" ? SEVERITY_BLOCKING : SEVERITY_ADVISORY;
	const label = severity === "blocking" ? "BLOCKING" : severity === "advisory" ? "ADVISORY" : "OFF";
	return new TableCell({
		shading: { type: ShadingType.CLEAR, fill: color },
		children: [
			new Paragraph({
				alignment: AlignmentType.CENTER,
				children: [new TextRun({ text: label, bold: true, color: "FFFFFF", size: 16 })],
			}),
		],
		width: { size: 1200, type: WidthType.DXA },
	});
}

function diffBlock(before: string, after: string, rationale?: string): Paragraph[] {
	const paragraphs: Paragraph[] = [
		new Paragraph({
			children: [new TextRun({ text: "Suggested fix:", bold: true, color: SUBTLE_INK, size: 20 })],
			spacing: { before: 80, after: 40 },
		}),
	];
	for (const line of before.split("\n")) {
		paragraphs.push(
			new Paragraph({
				shading: { type: ShadingType.CLEAR, fill: "FDEAEA" },
				children: [
					new TextRun({ text: "- ", color: SEVERITY_BLOCKING, font: "Consolas", size: 18 }),
					new TextRun({ text: line, font: "Consolas", size: 18 }),
				],
			}),
		);
	}
	for (const line of after.split("\n")) {
		paragraphs.push(
			new Paragraph({
				shading: { type: ShadingType.CLEAR, fill: "EAF7EA" },
				children: [
					new TextRun({ text: "+ ", color: "2E8B57", font: "Consolas", size: 18 }),
					new TextRun({ text: line, font: "Consolas", size: 18 }),
				],
			}),
		);
	}
	if (rationale) {
		paragraphs.push(
			new Paragraph({
				children: [
					new TextRun({ text: "Why: ", bold: true, color: SUBTLE_INK, size: 20 }),
					new TextRun({ text: rationale, italics: true, size: 20 }),
				],
				spacing: { before: 40, after: 80 },
			}),
		);
	}
	return paragraphs;
}

function findingParagraphs(f: ReviewFinding): Paragraph[] {
	const locText = f.line !== undefined ? ` — line ${f.line}` : "";
	const out: Paragraph[] = [
		new Paragraph({
			spacing: { before: 160, after: 60 },
			children: [
				new TextRun({
					text: `[${f.category}] `,
					bold: true,
					color: f.severity === "blocking" ? SEVERITY_BLOCKING : SEVERITY_ADVISORY,
					size: 22,
				}),
				new TextRun({ text: f.title, bold: true, size: 22 }),
				new TextRun({ text: locText, color: SUBTLE_INK, size: 22 }),
			],
		}),
	];
	if (f.detail) {
		out.push(new Paragraph({ children: [new TextRun({ text: f.detail, size: 20 })] }));
	}
	if (f.suggestion) {
		out.push(
			new Paragraph({
				spacing: { before: 40 },
				children: [
					new TextRun({ text: "→ ", color: SUBTLE_INK, bold: true, size: 20 }),
					new TextRun({ text: f.suggestion, size: 20 }),
				],
			}),
		);
	}
	if (f.suggestedFix) {
		out.push(...diffBlock(f.suggestedFix.before, f.suggestedFix.after, f.suggestedFix.rationale));
	}
	return out;
}

function qaIssueParagraphs(i: QAIssue): Paragraph[] {
	const locText = i.line !== undefined ? ` — line ${i.line}` : "";
	const out: Paragraph[] = [
		new Paragraph({
			spacing: { before: 160, after: 60 },
			children: [
				new TextRun({
					text: `[${i.category}] `,
					bold: true,
					color: i.severity === "blocking" ? SEVERITY_BLOCKING : SEVERITY_ADVISORY,
					size: 22,
				}),
				new TextRun({ text: i.title, bold: true, size: 22 }),
				new TextRun({ text: locText, color: SUBTLE_INK, size: 22 }),
			],
		}),
	];
	if (i.detail) {
		out.push(new Paragraph({ children: [new TextRun({ text: i.detail, size: 20 })] }));
	}
	if (i.suggestedFix) {
		out.push(...diffBlock(i.suggestedFix.before, i.suggestedFix.after, i.suggestedFix.rationale));
	}
	return out;
}

function countsTable(counts: { blocking: number; advisory: number }): Table {
	return new Table({
		width: { size: 5000, type: WidthType.DXA },
		rows: [
			new TableRow({
				children: [
					new TableCell({
						shading: { type: ShadingType.CLEAR, fill: BRAND_NAVY },
						children: [
							new Paragraph({
								alignment: AlignmentType.CENTER,
								children: [new TextRun({ text: "Severity", bold: true, color: "FFFFFF", size: 20 })],
							}),
						],
					}),
					new TableCell({
						shading: { type: ShadingType.CLEAR, fill: BRAND_NAVY },
						children: [
							new Paragraph({
								alignment: AlignmentType.CENTER,
								children: [new TextRun({ text: "Count", bold: true, color: "FFFFFF", size: 20 })],
							}),
						],
					}),
				],
			}),
			new TableRow({
				children: [
					severityChip("blocking"),
					new TableCell({
						children: [
							new Paragraph({
								alignment: AlignmentType.CENTER,
								children: [new TextRun({ text: String(counts.blocking), bold: true, size: 22 })],
							}),
						],
					}),
				],
			}),
			new TableRow({
				children: [
					severityChip("advisory"),
					new TableCell({
						children: [
							new Paragraph({
								alignment: AlignmentType.CENTER,
								children: [new TextRun({ text: String(counts.advisory), bold: true, size: 22 })],
							}),
						],
					}),
				],
			}),
		],
	});
}

/**
 * Build a Word report for a code review. Returns a Buffer the caller
 * writes to disk via fs.writeFile (NOT host.writeFile, which is
 * string-only — .docx is binary).
 */
export async function buildReviewReport(result: ReviewResult, meta: ReportMeta): Promise<Buffer> {
	const byFile = new Map<string, ReviewFinding[]>();
	for (const f of result.findings) {
		const list = byFile.get(f.path) ?? [];
		list.push(f);
		byFile.set(f.path, list);
	}
	const children: (Paragraph | Table)[] = [
		brandHeading("Code Review Report", HeadingLevel.HEADING_1),
		metaParagraph("Project", meta.projectName),
		metaParagraph("Generated", meta.generatedAt.toISOString().replace("T", " ").slice(0, 19)),
		metaParagraph("Reviewer", `OATI Code · ${meta.model}`),
		metaParagraph("Files reviewed", String(byFile.size || "(none)")),
		brandHeading("Severity summary", HeadingLevel.HEADING_2),
		countsTable(result.counts),
	];
	if (result.findings.length === 0) {
		children.push(
			new Paragraph({
				spacing: { before: 240 },
				children: [
					new TextRun({
						text: "No findings — review came back clean.",
						italics: true,
						color: SUBTLE_INK,
					}),
				],
			}),
		);
	} else {
		children.push(brandHeading("Findings by file", HeadingLevel.HEADING_2));
		for (const [path, list] of byFile) {
			children.push(
				new Paragraph({
					spacing: { before: 240, after: 80 },
					shading: { type: ShadingType.CLEAR, fill: SOFT_GREY },
					children: [new TextRun({ text: path, bold: true, font: "Consolas", size: 22 })],
				}),
			);
			list.sort((a, b) => {
				if (a.severity !== b.severity) {
					if (a.severity === "blocking") return -1;
					if (b.severity === "blocking") return 1;
				}
				return (a.line ?? 0) - (b.line ?? 0);
			});
			for (const f of list) children.push(...findingParagraphs(f));
		}
	}
	if (result.skipped.length > 0) {
		children.push(
			brandHeading("Skipped files", HeadingLevel.HEADING_2),
			...result.skipped.map(
				(s) =>
					new Paragraph({
						children: [
							new TextRun({ text: s.path, font: "Consolas", size: 20 }),
							new TextRun({ text: ` — ${s.reason}`, color: SUBTLE_INK, size: 20 }),
						],
					}),
			),
		);
	}
	const doc = new Document({ sections: [{ properties: {}, children }] });
	return Packer.toBuffer(doc) as Promise<Buffer>;
}

/**
 * Build a Word report for a QA run. Includes the generated test
 * artifacts (path + purpose) and any issues the model surfaced
 * (mostly /qa security + /qa coverage) with file + line + diff fixes.
 */
export async function buildQAReport(result: QAResult, meta: ReportMeta): Promise<Buffer> {
	const children: (Paragraph | Table)[] = [
		brandHeading(`QA Report — /qa ${result.subcommand}`, HeadingLevel.HEADING_1),
		metaParagraph("Project", meta.projectName),
		metaParagraph("Generated", meta.generatedAt.toISOString().replace("T", " ").slice(0, 19)),
		metaParagraph("Tooling", `OATI Code · ${meta.model}`),
		brandHeading("Summary", HeadingLevel.HEADING_2),
		new Paragraph({ children: [new TextRun({ text: result.summary, size: 22 })] }),
	];

	if (result.artifacts.length > 0) {
		children.push(brandHeading("Generated artifacts", HeadingLevel.HEADING_2));
		for (const a of result.artifacts) {
			children.push(
				new Paragraph({
					spacing: { before: 80 },
					children: [
						new TextRun({ text: a.path, bold: true, font: "Consolas", size: 22 }),
						...(a.purpose ? [new TextRun({ text: ` — ${a.purpose}`, color: SUBTLE_INK, size: 22 })] : []),
					],
				}),
			);
		}
	}

	if (result.issues && result.issues.length > 0) {
		const byFile = new Map<string, QAIssue[]>();
		for (const i of result.issues) {
			const list = byFile.get(i.path) ?? [];
			list.push(i);
			byFile.set(i.path, list);
		}
		const blocking = result.issues.filter((i) => i.severity === "blocking").length;
		const advisory = result.issues.length - blocking;
		children.push(
			brandHeading("Issues found", HeadingLevel.HEADING_2),
			countsTable({ blocking, advisory }),
		);
		for (const [path, list] of byFile) {
			children.push(
				new Paragraph({
					spacing: { before: 240, after: 80 },
					shading: { type: ShadingType.CLEAR, fill: SOFT_GREY },
					children: [new TextRun({ text: path, bold: true, font: "Consolas", size: 22 })],
				}),
			);
			list.sort((a, b) => {
				if (a.severity !== b.severity) {
					if (a.severity === "blocking") return -1;
					if (b.severity === "blocking") return 1;
				}
				return (a.line ?? 0) - (b.line ?? 0);
			});
			for (const i of list) children.push(...qaIssueParagraphs(i));
		}
	}

	if (result.notes.length > 0) {
		children.push(brandHeading("Notes", HeadingLevel.HEADING_2));
		for (const n of result.notes) {
			children.push(
				new Paragraph({
					spacing: { before: 40 },
					children: [
						new TextRun({ text: "• ", color: SUBTLE_INK, size: 20 }),
						new TextRun({ text: n, size: 20 }),
					],
				}),
			);
		}
	}

	const doc = new Document({ sections: [{ properties: {}, children }] });
	return Packer.toBuffer(doc) as Promise<Buffer>;
}

/**
 * Compute the report file path. Inputs: workspace root + configured
 * output dir + report type + timestamp. Returns a workspace-relative
 * path so the caller can resolve against fs cwd consistently.
 */
export function buildReportPath(
	outputDir: string | undefined,
	kind: "code-review" | "qa",
	subcommand: string | undefined,
	at: Date,
): string {
	const dir = outputDir?.trim() || "reports";
	const ts = at.toISOString().replace(/[:.]/g, "-").slice(0, 19);
	const slug = kind === "qa" && subcommand ? `qa-${subcommand}` : kind;
	return `${dir.replace(/\\/g, "/").replace(/\/+$/, "")}/${slug}-${ts}.docx`;
}
