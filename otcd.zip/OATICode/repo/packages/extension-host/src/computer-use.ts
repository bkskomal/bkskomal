// R8-D: computer-use loop helper — orchestrates a vision-capable model that
// drives the screen via the screenshot / mouse_* / type_text / key_press
// tools. Lives outside the regular agent loop so we can keep the
// vision-only feedback cycle (screenshot → action → screenshot) tight and
// surface a friendly "needs vision model" error up-front rather than
// failing mid-turn.

import type {
	ConversationMessage,
	HostContext,
	MessagePart,
	ProviderSpec,
	ToolCallPart,
	ToolResultPart,
	ToolSpec,
} from "@oati/shared";

/** Pattern allow-list of model ids that accept image inputs we care about. */
const VISION_PATTERNS: readonly RegExp[] = [
	/claude-3(?:[-.]\d+)?-(?:sonnet|opus|haiku)/i,
	/claude-3\.5-sonnet/i,
	/claude-3\.7-sonnet/i,
	/claude-opus-4/i,
	/claude-sonnet-4/i,
	/claude-3-5-sonnet/i,
	/gpt-4o/i,
	/gpt-4\.1/i,
	/gpt-4-vision/i,
	/gpt-4-turbo/i,
	/o1-pro/i,
	/gemini-1\.5/i,
	/gemini-2/i,
];

/**
 * Best-effort guess whether `modelId` accepts image inputs. We intentionally
 * stay generous: false negatives cause user-visible "not vision-capable"
 * errors, which is the right safety failure mode for computer-use.
 */
export function isVisionCapableModel(modelId: string): boolean {
	if (!modelId) return false;
	const m = modelId.trim();
	return VISION_PATTERNS.some((re) => re.test(m));
}

/** Names of the tools this loop expects to be available. */
export const COMPUTER_USE_TOOL_NAMES: readonly string[] = [
	"screenshot",
	"mouse_click",
	"mouse_move",
	"type_text",
	"key_press",
];

/**
 * Maximum consecutive *failures* the loop tolerates before bailing. A
 * "failure" is a tool call that threw or that the screenshot tool reported
 * as errored. Successful screenshots reset the counter.
 */
export const MAX_CONSECUTIVE_FAILURES = 3;

/** Default ceiling on actions even when the model never returns a clean stop. */
const DEFAULT_MAX_ACTIONS = 25;

export interface ComputerUseTurnOptions {
	readonly task: string;
	readonly modelId: string;
	readonly provider: ProviderSpec;
	readonly host: HostContext;
	readonly tools: readonly ToolSpec[];
	/** Optional cap; defaults to 25. */
	readonly maxActions?: number;
	readonly signal?: AbortSignal;
	/** Optional sink for status events (used by the chat panel for UI updates). */
	readonly onEvent?: (e: ComputerUseEvent) => void;
}

export type ComputerUseEvent =
	| { readonly type: "started"; readonly modelId: string }
	| { readonly type: "screenshot"; readonly dataUrl: string }
	| { readonly type: "action"; readonly call: ToolCallPart }
	| { readonly type: "action_result"; readonly result: ToolResultPart }
	| { readonly type: "failure"; readonly message: string; readonly consecutive: number }
	| { readonly type: "done"; readonly reason: "end" | "max_actions" | "failures" | "cancelled" };

export interface ComputerUseTurnResult {
	readonly actions: number;
	readonly failures: number;
	readonly stopReason: "end" | "max_actions" | "failures" | "cancelled";
}

/**
 * Lightweight error surfaced when the active model isn't vision-capable.
 * Caller (chat panel) catches this and pipes the message into the chat
 * stream so the user sees a clear explanation rather than a stack trace.
 */
export class NotVisionCapableError extends Error {
	constructor(modelId: string) {
		super(
			`Computer-use requires a vision-capable model (Claude 3.5 Sonnet+, GPT-4o, GPT-4 Vision, Gemini 1.5+). Active model "${modelId}" doesn't support image inputs — switch models in the provider picker before trying again.`,
		);
		this.name = "NotVisionCapableError";
	}
}

/**
 * Run a single computer-use turn. The loop:
 *   1. Captures a screenshot.
 *   2. Sends it (plus the task description and history) to the model.
 *   3. Executes any tool calls the model emitted (mouse / keyboard / screenshot).
 *   4. Captures a fresh screenshot after each batch of actions and feeds it back.
 *   5. Stops on plain-text completion, max-actions, or 3 consecutive failures.
 */
export async function runComputerUseTurn(
	opts: ComputerUseTurnOptions,
): Promise<ComputerUseTurnResult> {
	if (!isVisionCapableModel(opts.modelId)) {
		throw new NotVisionCapableError(opts.modelId);
	}
	const toolMap = new Map(opts.tools.map((t) => [t.name, t]));
	for (const name of COMPUTER_USE_TOOL_NAMES) {
		if (!toolMap.has(name)) {
			throw new Error(
				`Computer-use: required tool "${name}" is not registered. Has R8-A wired it into the registry yet?`,
			);
		}
	}
	const screenshotTool = toolMap.get("screenshot") as ToolSpec;
	const maxActions = opts.maxActions ?? DEFAULT_MAX_ACTIONS;
	const emit = (e: ComputerUseEvent) => opts.onEvent?.(e);
	emit({ type: "started", modelId: opts.modelId });

	const history: ConversationMessage[] = [];
	const systemPrompt = buildSystemPrompt(opts.task);

	let consecutiveFailures = 0;
	let actions = 0;
	let stopReason: ComputerUseTurnResult["stopReason"] = "end";

	const initial = await safeScreenshot(screenshotTool, opts.host);
	if (!initial.ok) {
		emit({ type: "failure", message: initial.error, consecutive: 1 });
		emit({ type: "done", reason: "failures" });
		return { actions: 0, failures: 1, stopReason: "failures" };
	}
	emit({ type: "screenshot", dataUrl: initial.dataUrl });

	pushUserTurn(history, opts.task, initial.dataUrl);

	while (actions < maxActions) {
		if (opts.signal?.aborted) {
			stopReason = "cancelled";
			break;
		}
		const { text, calls } = await streamOneTurn(opts, systemPrompt, history);
		const assistantParts: MessagePart[] = [];
		if (text) assistantParts.push({ kind: "text", text });
		for (const c of calls) assistantParts.push(c);
		history.push({ role: "assistant", parts: assistantParts });

		if (calls.length === 0) {
			stopReason = "end";
			break;
		}

		const results: ToolResultPart[] = [];
		for (const call of calls) {
			emit({ type: "action", call });
			const tool = toolMap.get(call.name);
			if (!tool) {
				consecutiveFailures++;
				const errResult: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output: `unknown tool: ${call.name}`,
					isError: true,
				};
				results.push(errResult);
				emit({
					type: "failure",
					message: `unknown tool: ${call.name}`,
					consecutive: consecutiveFailures,
				});
				continue;
			}
			try {
				const output = await tool.handler(call.args, opts.host, {
					callId: call.id,
					agentId: "computer-use",
				});
				const result: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output,
					isError: false,
				};
				results.push(result);
				emit({ type: "action_result", result });
				consecutiveFailures = 0;
			} catch (err) {
				const msg = err instanceof Error ? err.message : String(err);
				const result: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output: msg,
					isError: true,
				};
				results.push(result);
				consecutiveFailures++;
				emit({ type: "failure", message: msg, consecutive: consecutiveFailures });
			}
			actions++;
			if (actions >= maxActions) break;
		}
		history.push({ role: "tool", parts: results });

		if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
			stopReason = "failures";
			break;
		}
		if (actions >= maxActions) {
			stopReason = "max_actions";
			break;
		}

		// Feed back a fresh frame so the model can see the post-action state.
		const next = await safeScreenshot(screenshotTool, opts.host);
		if (!next.ok) {
			consecutiveFailures++;
			emit({ type: "failure", message: next.error, consecutive: consecutiveFailures });
			if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
				stopReason = "failures";
				break;
			}
			continue;
		}
		emit({ type: "screenshot", dataUrl: next.dataUrl });
		history.push({
			role: "user",
			parts: [
				{ kind: "text", text: "Updated screenshot after your action." },
				{ kind: "image", mimeType: "image/png", dataUrl: next.dataUrl },
			],
		});
	}

	emit({ type: "done", reason: stopReason });
	return { actions, failures: consecutiveFailures, stopReason };
}

function pushUserTurn(history: ConversationMessage[], task: string, dataUrl: string): void {
	history.push({
		role: "user",
		parts: [
			{
				kind: "text",
				text: [
					`Task: ${task}`,
					"",
					"You are controlling a computer via screen capture plus mouse/keyboard tools. Look at the screenshot, decide on the smallest next action, and call one of the tools (mouse_click, mouse_move, type_text, key_press, screenshot). When the task is complete, reply with plain text describing what you did and stop calling tools.",
				].join("\n"),
			},
			{ kind: "image", mimeType: "image/png", dataUrl },
		],
	});
}

function buildSystemPrompt(task: string): string {
	return [
		"You are OATI Code in computer-use mode. The user's task is:",
		`  ${task}`,
		"",
		"You see the desktop through screenshots and act through these tools:",
		"  - screenshot({ region?, displayId? }) – grab a fresh frame",
		"  - mouse_move({ x, y }) – move cursor without clicking",
		"  - mouse_click({ x, y, button?, double? }) – click at coords",
		"  - type_text({ text, delay? }) – type a literal string",
		"  - key_press({ key, modifiers? }) – press a key or chord (e.g. `cmd+s`, `ctrl+shift+p`)",
		"",
		"Rules:",
		"  - Take ONE small action per turn (a single click or a single key chord).",
		"  - After each action a fresh screenshot is fed back; re-read the screen before deciding the next step.",
		"  - If the screen does not change as expected, try a different approach — do NOT retry the same action three times in a row.",
		"  - When the task is finished, stop calling tools and reply with a short summary.",
	].join("\n");
}

interface ScreenshotOk {
	readonly ok: true;
	readonly dataUrl: string;
}
interface ScreenshotErr {
	readonly ok: false;
	readonly error: string;
}

async function safeScreenshot(
	tool: ToolSpec,
	host: HostContext,
): Promise<ScreenshotOk | ScreenshotErr> {
	try {
		const out = (await tool.handler({}, host, {
			callId: `cu-${Date.now()}`,
			agentId: "computer-use",
		})) as { dataUrl?: string };
		if (typeof out?.dataUrl !== "string") {
			return { ok: false, error: "screenshot tool returned no dataUrl" };
		}
		return { ok: true, dataUrl: out.dataUrl };
	} catch (err) {
		return { ok: false, error: err instanceof Error ? err.message : String(err) };
	}
}

interface TurnSlice {
	readonly text: string;
	readonly calls: readonly ToolCallPart[];
}

/**
 * Drive the provider stream for a single assistant turn and collect any tool
 * calls plus accumulated text. Mirrors the inner-most chunk loop in
 * `Agent.streamOnce` but stripped down — we don't emit AgentEvents to the
 * outer chat panel, only the typed `ComputerUseEvent` channel.
 */
async function streamOneTurn(
	opts: ComputerUseTurnOptions,
	systemPrompt: string,
	history: readonly ConversationMessage[],
): Promise<TurnSlice> {
	const tools = opts.tools.filter((t) => COMPUTER_USE_TOOL_NAMES.includes(t.name));
	const stream = opts.provider.stream({
		modelId: opts.modelId,
		systemPrompt,
		messages: history,
		tools,
		signal: opts.signal,
	});
	const calls: ToolCallPart[] = [];
	let text = "";
	for await (const chunk of stream) {
		if (chunk.type === "text_delta") {
			text += chunk.text;
		} else if (chunk.type === "tool_call") {
			calls.push({ kind: "tool_call", id: chunk.id, name: chunk.name, args: chunk.args });
		}
	}
	return { text, calls };
}
