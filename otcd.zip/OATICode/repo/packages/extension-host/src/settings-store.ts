import {
	DEFAULT_CONFIG,
	type ModeConfig,
	type ProviderConfig,
	type RootConfig,
} from "@oati/shared";
import type { KvStorage, SecretStorage } from "./storage";

const CONFIG_KEY = "oati.config.v1";
const SECRET_PREFIX = "oati.apiKey.";

export type SettingsListener = (config: RootConfig) => void;

export class SettingsStore {
	private cached: RootConfig;
	private readonly listeners = new Set<SettingsListener>();

	constructor(
		private readonly kv: KvStorage,
		private readonly secrets: SecretStorage,
	) {
		const { config, migrated } = this.loadFromState();
		this.cached = config;
		// Persist the migration so the next launch reads the upgraded config
		// directly — otherwise we'd re-augment every boot from kv.
		if (migrated) {
			void this.kv.update(CONFIG_KEY, config);
		}
	}

	get config(): RootConfig {
		return this.cached;
	}

	on(listener: SettingsListener): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	async updateConfig(next: {
		readonly activeProviderId?: string;
		readonly activeModeId?: string;
		readonly providers?: readonly ProviderConfig[];
		readonly modes?: readonly import("@oati/shared").ModeConfig[];
		readonly mcpServers?: readonly import("@oati/shared").McpServerConfig[];
		readonly hooks?: readonly import("@oati/shared").HookConfig[];
		readonly verboseInternals?: boolean;
		readonly review?: import("@oati/shared").ReviewConfig;
		readonly qa?: import("@oati/shared").QAConfig;
		readonly ci?: import("@oati/shared").CIConfig;
		readonly sbom?: import("@oati/shared").SBOMConfig;
		readonly budget?: import("@oati/shared").BudgetConfig;
	}): Promise<void> {
		// Each field is optional so callers can patch one slice (e.g. just
		// `hooks` from the Hooks editor) without re-sending the whole
		// configuration object. Missing fields fall back to the cached
		// snapshot.
		const merged: RootConfig = {
			...this.cached,
			activeProviderId: next.activeProviderId ?? this.cached.activeProviderId,
			activeModeId: next.activeModeId ?? this.cached.activeModeId,
			providers: next.providers ?? this.cached.providers,
			modes: next.modes ?? this.cached.modes,
			mcpServers: next.mcpServers ?? this.cached.mcpServers,
			...(next.hooks ? { hooks: next.hooks } : {}),
			// 2026-05-24: persist diagnostics toggle. Explicit undefined check
			// rather than `??` so flipping the toggle from `true` back to
			// `false` actually saves (otherwise `false ?? cached` would
			// preserve the prior value).
			...(next.verboseInternals !== undefined ? { verboseInternals: next.verboseInternals } : {}),
			// 2026-05-27: review + qa config blocks. Patch-shaped: callers
			// can update one without touching the other.
			...(next.review !== undefined ? { review: next.review } : {}),
			...(next.qa !== undefined ? { qa: next.qa } : {}),
			...(next.ci !== undefined ? { ci: next.ci } : {}),
			...(next.sbom !== undefined ? { sbom: next.sbom } : {}),
			// 2026-06-06: budget guardrails. Patch-shaped — an empty object
			// `{}` clears every cap (back to DEFAULT_BUDGET values from
			// extension-host/budget.ts); omitting the field leaves the
			// prior values untouched.
			...(next.budget !== undefined ? { budget: next.budget } : {}),
		};
		this.cached = merged;
		await this.kv.update(CONFIG_KEY, merged);
		this.notify();
	}

	async getApiKey(providerId: string): Promise<string | undefined> {
		return this.secrets.get(SECRET_PREFIX + providerId);
	}

	async setApiKey(providerId: string, apiKey: string): Promise<void> {
		await this.secrets.store(SECRET_PREFIX + providerId, apiKey);
		this.notify();
	}

	async deleteApiKey(providerId: string): Promise<void> {
		await this.secrets.delete(SECRET_PREFIX + providerId);
		this.notify();
	}

	async hasApiKeyMap(): Promise<Record<string, boolean>> {
		const map: Record<string, boolean> = {};
		for (const p of this.cached.providers) {
			const v = await this.getApiKey(p.id);
			map[p.id] = !!v && v.length > 0;
		}
		return map;
	}

	private loadFromState(): { config: RootConfig; migrated: boolean } {
		const stored = this.kv.get<RootConfig>(CONFIG_KEY);
		if (!stored || !isValidRootConfig(stored)) {
			return { config: DEFAULT_CONFIG, migrated: false };
		}
		const { modes, migrated } = mergeMissingBuiltinModes(stored.modes);
		return {
			config: {
				activeProviderId: stored.activeProviderId,
				activeModeId: stored.activeModeId,
				providers: stored.providers,
				modes,
				mcpServers: stored.mcpServers,
			},
			migrated,
		};
	}

	private notify(): void {
		for (const fn of this.listeners) fn(this.cached);
	}
}

function isValidRootConfig(v: unknown): v is RootConfig {
	if (typeof v !== "object" || v === null) return false;
	const c = v as RootConfig;
	return (
		typeof c.activeProviderId === "string" &&
		typeof c.activeModeId === "string" &&
		Array.isArray(c.providers) &&
		Array.isArray(c.modes)
	);
}

/**
 * Older builds saved only the single "code" mode. Bring users forward by
 * appending any built-in modes (ask, plan, auto-edit, auto) that are missing,
 * preserving every mode the user already had — including any they renamed or
 * customized. Returns `migrated: true` when the list changed so the caller
 * can persist the upgrade.
 */
function mergeMissingBuiltinModes(stored: readonly ModeConfig[]): {
	modes: readonly ModeConfig[];
	migrated: boolean;
} {
	if (stored.length === 0) {
		return { modes: DEFAULT_CONFIG.modes, migrated: true };
	}
	const have = new Set(stored.map((m) => m.id));
	const toAppend = DEFAULT_CONFIG.modes.filter((m) => !have.has(m.id));
	if (toAppend.length === 0) return { modes: stored, migrated: false };
	return { modes: [...stored, ...toAppend], migrated: true };
}
