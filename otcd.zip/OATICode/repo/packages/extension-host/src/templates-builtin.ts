// R4-C: built-in project templates. Each template ships a minimal-but-runnable
// scaffold — enough to `npm install && npm run dev` (or equivalent) without
// being a full app. Add new templates by appending to the `BUILTIN_TEMPLATES`
// array; the registration order is also the listing order in the UI.

export interface TemplateFile {
	readonly path: string;
	readonly content: string;
}

export interface Template {
	readonly name: string;
	readonly description: string;
	readonly files: readonly TemplateFile[];
}

const reactTsTemplate: Template = {
	name: "react-ts",
	description: "Minimal React + TypeScript + Vite scaffold",
	files: [
		{
			path: "package.json",
			content: `${JSON.stringify(
				{
					name: "react-ts-app",
					private: true,
					version: "0.0.0",
					type: "module",
					scripts: {
						dev: "vite",
						build: "tsc && vite build",
						preview: "vite preview",
					},
					dependencies: {
						react: "^18.3.1",
						"react-dom": "^18.3.1",
					},
					devDependencies: {
						"@types/react": "^18.3.3",
						"@types/react-dom": "^18.3.0",
						"@vitejs/plugin-react": "^4.3.1",
						typescript: "^5.5.3",
						vite: "^5.4.0",
					},
				},
				null,
				2,
			)}\n`,
		},
		{
			path: "tsconfig.json",
			content: `${JSON.stringify(
				{
					compilerOptions: {
						target: "ES2020",
						useDefineForClassFields: true,
						lib: ["ES2020", "DOM", "DOM.Iterable"],
						module: "ESNext",
						skipLibCheck: true,
						moduleResolution: "Bundler",
						resolveJsonModule: true,
						isolatedModules: true,
						noEmit: true,
						jsx: "react-jsx",
						strict: true,
					},
					include: ["src"],
				},
				null,
				2,
			)}\n`,
		},
		{
			path: "vite.config.ts",
			content: `import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
	plugins: [react()],
});
`,
		},
		{
			path: "index.html",
			content: `<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>React + TS</title>
	</head>
	<body>
		<div id="root"></div>
		<script type="module" src="/src/main.tsx"></script>
	</body>
</html>
`,
		},
		{
			path: "src/main.tsx",
			content: `import React from "react";
import ReactDOM from "react-dom/client";
import { App } from "./App";

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
	<React.StrictMode>
		<App />
	</React.StrictMode>,
);
`,
		},
		{
			path: "src/App.tsx",
			content: `import { useState } from "react";

export function App() {
	const [count, setCount] = useState(0);
	return (
		<main>
			<h1>React + TypeScript</h1>
			<button type="button" onClick={() => setCount((c) => c + 1)}>
				count is {count}
			</button>
		</main>
	);
}
`,
		},
		{
			path: ".gitignore",
			content: "node_modules\ndist\n.vite\n",
		},
	],
};

const nodeCliTemplate: Template = {
	name: "node-cli",
	description: "Node.js CLI in TypeScript with vitest + husky",
	files: [
		{
			path: "package.json",
			content: `${JSON.stringify(
				{
					name: "node-cli",
					version: "0.0.0",
					private: true,
					type: "module",
					bin: { "node-cli": "dist/index.js" },
					scripts: {
						build: "tsc",
						start: "node dist/index.js",
						dev: "tsx src/index.ts",
						test: "vitest run",
						prepare: "husky install",
					},
					devDependencies: {
						"@types/node": "^22.0.0",
						husky: "^9.1.7",
						tsx: "^4.19.0",
						typescript: "^5.5.3",
						vitest: "^2.1.0",
					},
				},
				null,
				2,
			)}\n`,
		},
		{
			path: "tsconfig.json",
			content: `${JSON.stringify(
				{
					compilerOptions: {
						target: "ES2022",
						module: "ES2022",
						moduleResolution: "Bundler",
						outDir: "dist",
						strict: true,
						esModuleInterop: true,
						skipLibCheck: true,
						declaration: true,
					},
					include: ["src"],
				},
				null,
				2,
			)}\n`,
		},
		{
			path: "src/index.ts",
			content: `#!/usr/bin/env node
import { hello } from "./hello.js";

const name = process.argv[2] ?? "world";
console.log(hello(name));
`,
		},
		{
			path: "src/hello.ts",
			content: `export function hello(name: string): string {
	return \`Hello, \${name}!\`;
}
`,
		},
		{
			path: "src/hello.test.ts",
			content: `import { describe, expect, it } from "vitest";
import { hello } from "./hello.js";

describe("hello", () => {
	it("greets the named target", () => {
		expect(hello("world")).toBe("Hello, world!");
	});
});
`,
		},
		{
			path: ".gitignore",
			content: "node_modules\ndist\n",
		},
	],
};

const fastapiTemplate: Template = {
	name: "fastapi",
	description: "Python FastAPI starter with pytest",
	files: [
		{
			path: "pyproject.toml",
			content: `[project]
name = "fastapi-app"
version = "0.0.0"
requires-python = ">=3.10"
dependencies = [
	"fastapi>=0.115",
	"uvicorn[standard]>=0.30",
]

[project.optional-dependencies]
dev = ["pytest>=8.0", "httpx>=0.27"]
`,
		},
		{
			path: "app/__init__.py",
			content: "",
		},
		{
			path: "app/main.py",
			content: `from fastapi import FastAPI

app = FastAPI(title="fastapi-app")


@app.get("/")
def read_root() -> dict[str, str]:
	return {"hello": "world"}


@app.get("/items/{item_id}")
def read_item(item_id: int) -> dict[str, int]:
	return {"item_id": item_id}
`,
		},
		{
			path: "tests/__init__.py",
			content: "",
		},
		{
			path: "tests/test_main.py",
			content: `from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_root() -> None:
	response = client.get("/")
	assert response.status_code == 200
	assert response.json() == {"hello": "world"}


def test_item() -> None:
	response = client.get("/items/42")
	assert response.status_code == 200
	assert response.json() == {"item_id": 42}
`,
		},
		{
			path: ".gitignore",
			content: "__pycache__\n.venv\n*.pyc\n.pytest_cache\n",
		},
		{
			path: "README.md",
			content: `# fastapi-app

\`\`\`bash
pip install -e .[dev]
uvicorn app.main:app --reload
pytest
\`\`\`
`,
		},
	],
};

const expressApiTemplate: Template = {
	name: "express-api",
	description: "Express + TypeScript + zod API starter",
	files: [
		{
			path: "package.json",
			content: `${JSON.stringify(
				{
					name: "express-api",
					version: "0.0.0",
					private: true,
					type: "module",
					scripts: {
						build: "tsc",
						start: "node dist/index.js",
						dev: "tsx src/index.ts",
					},
					dependencies: {
						express: "^4.21.0",
						zod: "^3.23.8",
					},
					devDependencies: {
						"@types/express": "^4.17.21",
						"@types/node": "^22.0.0",
						tsx: "^4.19.0",
						typescript: "^5.5.3",
					},
				},
				null,
				2,
			)}\n`,
		},
		{
			path: "tsconfig.json",
			content: `${JSON.stringify(
				{
					compilerOptions: {
						target: "ES2022",
						module: "ES2022",
						moduleResolution: "Bundler",
						outDir: "dist",
						strict: true,
						esModuleInterop: true,
						skipLibCheck: true,
					},
					include: ["src"],
				},
				null,
				2,
			)}\n`,
		},
		{
			path: "src/index.ts",
			content: `import express from "express";
import { z } from "zod";

const app = express();
app.use(express.json());

const echoSchema = z.object({ message: z.string().min(1) });

app.post("/echo", (req, res) => {
	const parsed = echoSchema.safeParse(req.body);
	if (!parsed.success) {
		res.status(400).json({ error: parsed.error.flatten() });
		return;
	}
	res.json({ message: parsed.data.message });
});

app.get("/health", (_req, res) => {
	res.json({ ok: true });
});

const port = Number(process.env.PORT ?? 3000);
app.listen(port, () => {
	// eslint-disable-next-line no-console
	console.log(\`Listening on http://localhost:\${port}\`);
});
`,
		},
		{
			path: ".gitignore",
			content: "node_modules\ndist\n",
		},
	],
};

const rustCliTemplate: Template = {
	name: "rust-cli",
	description: "Rust CLI with clap + thiserror",
	files: [
		{
			path: "Cargo.toml",
			content: `[package]
name = "rust-cli"
version = "0.0.0"
edition = "2021"

[dependencies]
clap = { version = "4.5", features = ["derive"] }
thiserror = "1.0"

[[bin]]
name = "rust-cli"
path = "src/main.rs"
`,
		},
		{
			path: "src/main.rs",
			content: `use clap::Parser;
use thiserror::Error;

#[derive(Debug, Parser)]
#[command(version, about = "rust-cli", long_about = None)]
struct Cli {
	#[arg(short, long, default_value = "world")]
	name: String,
}

#[derive(Debug, Error)]
enum CliError {
	#[error("empty name")]
	EmptyName,
}

fn greet(name: &str) -> Result<String, CliError> {
	if name.is_empty() {
		return Err(CliError::EmptyName);
	}
	Ok(format!("Hello, {name}!"))
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
	let cli = Cli::parse();
	println!("{}", greet(&cli.name)?);
	Ok(())
}
`,
		},
		{
			path: ".gitignore",
			content: "target\nCargo.lock\n",
		},
	],
};

export const BUILTIN_TEMPLATES: readonly Template[] = [
	reactTsTemplate,
	nodeCliTemplate,
	fastapiTemplate,
	expressApiTemplate,
	rustCliTemplate,
] as const;
