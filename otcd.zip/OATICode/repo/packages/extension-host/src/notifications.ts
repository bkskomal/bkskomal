// R3-E: Slack/Discord webhook notifications.
//
// Pull webhook URLs from VS Code's SecretStorage (they're sensitive) under
// the keys `oati.slackWebhookUrl` and `oati.discordWebhookUrl`. If neither
// is configured the hub silently no-ops — callers can sprinkle `notify()`
// calls without worrying about whether the user has opted in.
//
// All network failures are caught and logged best-effort; we never throw
// out of `notify()` so callers can sit on it without try/catch.

import type { SecretStorage } from "./storage";

export type NotificationKind = "task_completed" | "approval_needed" | "build_failed";

export interface NotificationEvent {
	readonly kind: NotificationKind;
	readonly title: string;
	readonly body?: string;
}

export interface NotificationHubOptions {
	readonly secrets: SecretStorage;
	readonly log?: { appendLine(msg: string): void };
	/**
	 * Optional fetch override — primarily for tests. Defaults to the global
	 * `fetch` if available.
	 */
	readonly fetchImpl?: typeof fetch;
}

export const SLACK_SECRET_KEY = "oati.slackWebhookUrl";
export const DISCORD_SECRET_KEY = "oati.discordWebhookUrl";

interface SlackPayload {
	text: string;
	blocks?: unknown[];
}

interface DiscordPayload {
	content?: string;
	embeds?: Array<{
		title: string;
		description?: string;
		color?: number;
	}>;
}

const KIND_EMOJI: Record<NotificationKind, string> = {
	task_completed: ":white_check_mark:",
	approval_needed: ":bell:",
	build_failed: ":x:",
};

const KIND_DISCORD_COLOR: Record<NotificationKind, number> = {
	task_completed: 0x2ecc71, // green
	approval_needed: 0xf1c40f, // yellow
	build_failed: 0xe74c3c, // red
};

function buildSlackPayload(ev: NotificationEvent): SlackPayload {
	const emoji = KIND_EMOJI[ev.kind];
	const headline = `${emoji} *${ev.title}* (_${ev.kind}_)`;
	const text = ev.body ? `${headline}\n${ev.body}` : headline;
	return {
		text,
		blocks: [
			{
				type: "section",
				text: { type: "mrkdwn", text: headline },
			},
			...(ev.body
				? [
						{
							type: "section",
							text: { type: "mrkdwn", text: ev.body },
						},
					]
				: []),
		],
	};
}

function buildDiscordPayload(ev: NotificationEvent): DiscordPayload {
	return {
		embeds: [
			{
				title: ev.title,
				...(ev.body ? { description: ev.body } : {}),
				color: KIND_DISCORD_COLOR[ev.kind],
			},
		],
	};
}

export class NotificationHub {
	private readonly secrets: SecretStorage;
	private readonly log?: { appendLine(msg: string): void };
	private readonly fetchImpl: typeof fetch;

	constructor(opts: NotificationHubOptions) {
		this.secrets = opts.secrets;
		this.log = opts.log;
		// `fetch` is global in Node 18+ and in modern VS Code; fall back to a
		// no-op that just records the lack of a transport.
		const f = opts.fetchImpl ?? (typeof fetch === "function" ? fetch.bind(globalThis) : undefined);
		if (!f) {
			this.fetchImpl = (async () => {
				throw new Error("fetch is not available in this runtime");
			}) as typeof fetch;
		} else {
			this.fetchImpl = f;
		}
	}

	async notify(event: NotificationEvent): Promise<void> {
		try {
			const [slackUrl, discordUrl] = await Promise.all([
				this.secrets.get(SLACK_SECRET_KEY),
				this.secrets.get(DISCORD_SECRET_KEY),
			]);
			const tasks: Promise<unknown>[] = [];
			if (slackUrl && slackUrl.trim().length > 0) {
				tasks.push(this.postSlack(slackUrl.trim(), event));
			}
			if (discordUrl && discordUrl.trim().length > 0) {
				tasks.push(this.postDiscord(discordUrl.trim(), event));
			}
			if (tasks.length === 0) return;
			await Promise.allSettled(tasks);
		} catch (err) {
			this.log?.appendLine(
				`[notifications] notify(${event.kind}) failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}

	private async postSlack(url: string, event: NotificationEvent): Promise<void> {
		try {
			const payload = buildSlackPayload(event);
			const res = await this.fetchImpl(url, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload),
			});
			if (!res.ok) {
				this.log?.appendLine(`[notifications] slack POST → ${res.status}`);
			}
		} catch (err) {
			this.log?.appendLine(
				`[notifications] slack POST failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}

	private async postDiscord(url: string, event: NotificationEvent): Promise<void> {
		try {
			const payload = buildDiscordPayload(event);
			const res = await this.fetchImpl(url, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload),
			});
			if (!res.ok) {
				this.log?.appendLine(`[notifications] discord POST → ${res.status}`);
			}
		} catch (err) {
			this.log?.appendLine(
				`[notifications] discord POST failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	}
}

// Exported for tests.
export const __test = { buildSlackPayload, buildDiscordPayload };
