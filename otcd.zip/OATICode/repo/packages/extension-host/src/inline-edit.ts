import type { ConversationMessage, ProviderSpec, RootConfig } from "@oati/shared";
import * as vscode from "vscode";
import type { InlineDiffController } from "./inline-diff";
import type { ProviderManager } from "./provider-manager";
import type { SettingsStore } from "./settings-store";

/**
 * Ctrl+K inline edit. Pops a small input box anchored to the cursor; sends
 * the user's instruction + the current selection to the active provider's
 * model; streams the response back into the editor, replacing the selection.
 *
 * Big rewrites (>3 changed lines) opt into the inline-diff review flow so
 * the user gets per-hunk Accept/Reject before the edit lands. Small edits
 * apply straight away with a quick selection highlight.
 */

export interface InlineEditDeps {
	readonly settings: SettingsStore;
	readonly providerManager: ProviderManager;
	readonly inlineDiff: InlineDiffController;
	readonly log?: vscode.OutputChannel;
}

/**
 * Build the system + user prompt for an inline edit. Exposed for tests so
 * we can pin the wording (regressions here break model output quality).
 */
export function buildInlineEditPrompt(
	instruction: string,
	selection: string,
	language: string,
): { system: string; user: string } {
	const lang = language || "code";
	return {
		system: [
			"You are an inline code-editing assistant. Rewrite the user's selected code per their instruction.",
			"",
			"Output rules:",
			"- Reply with the rewritten code ONLY. No prose, no markdown, no fenced code blocks.",
			"- Preserve the original indentation style and the trailing newline (or lack thereof).",
			"- Match the existing language idioms and naming conventions visible in the selection.",
			"- If the instruction is ambiguous, make the most useful interpretation and proceed; do not ask questions.",
		].join("\n"),
		user: `Rewrite the following ${lang} code per this instruction: ${instruction}\n\n\`\`\`${lang}\n${selection}\n\`\`\``,
	};
}

/** Strip a possible fenced code block from the model's reply. */
export function stripCodeFences(text: string): string {
	const trimmed = text.trim();
	const fence = /^```[a-zA-Z0-9_+-]*\r?\n([\s\S]*?)\r?\n```$/m.exec(trimmed);
	if (fence) return fence[1];
	return text.replace(/^```[a-zA-Z0-9_+-]*\r?\n/, "").replace(/\r?\n```$/, "");
}

/** Count meaningful line changes between two strings (used to gate review mode). */
export function countChangedLines(a: string, b: string): number {
	if (a === b) return 0;
	const aLines = a.split(/\r?\n/);
	const bLines = b.split(/\r?\n/);
	const max = Math.max(aLines.length, bLines.length);
	let changed = 0;
	for (let i = 0; i < max; i++) {
		if ((aLines[i] ?? "") !== (bLines[i] ?? "")) changed++;
	}
	return changed;
}

/**
 * VS Code command handler — registered in extension.ts as `oati.inlineEdit`.
 */
export async function runInlineEditCommand(deps: InlineEditDeps): Promise<void> {
	const editor = vscode.window.activeTextEditor;
	if (!editor) {
		vscode.window.showWarningMessage("OATI Code: open a file first to use Ctrl+K inline edit.");
		return;
	}

	// Selection or, as a fallback, the current line.
	let range: vscode.Range = editor.selection;
	if (range.isEmpty) {
		const line = editor.document.lineAt(editor.selection.active.line);
		range = line.range;
	}
	const original = editor.document.getText(range);
	if (original.trim().length === 0) {
		vscode.window.showWarningMessage(
			"OATI Code: nothing selected — place your cursor in code or select text.",
		);
		return;
	}

	const instruction = await vscode.window.showInputBox({
		prompt: "OATI Code · Rewrite selection",
		placeHolder: "Rewrite selection (e.g. 'add error handling')",
		ignoreFocusOut: false,
	});
	if (!instruction || instruction.trim().length === 0) return;

	const config = deps.settings.config;
	const modelId = deps.providerManager.resolveActiveModelId(config);
	if (!modelId) {
		vscode.window.showErrorMessage(
			"OATI Code: no model configured — open OATI: Open Settings and set a Model ID.",
		);
		return;
	}
	const providerId = resolveProviderId(config);
	const provider = deps.providerManager.registry.get(providerId);
	if (!provider) {
		vscode.window.showErrorMessage(`OATI Code: provider not registered: ${providerId}`);
		return;
	}

	const language = editor.document.languageId;
	deps.log?.appendLine(
		`[inline-edit] '${instruction.slice(0, 60)}' (model=${modelId}, lang=${language}, ${original.length}b)`,
	);

	try {
		const result = await streamRewrite(provider, modelId, instruction, original, language);
		const stripped = stripCodeFences(result);
		if (stripped === original) {
			deps.log?.appendLine("[inline-edit] no-op rewrite");
			return;
		}
		const changedLines = countChangedLines(original, stripped);
		if (changedLines > 3) {
			// Hand off to inline-diff for a per-hunk review.
			deps.log?.appendLine(`[inline-edit] ${changedLines} changed lines — handing off to inline-diff`);
			const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			// We need a path for the DiffPreview — use the document's path.
			const docPath = editor.document.uri.fsPath;
			// Build a synthetic diff over the *whole document* (the inline-diff
			// controller works on a file-level after-text). We replace just the
			// selected range so untouched code reads identical to before.
			const fullBefore = editor.document.getText();
			const fullAfter = replaceRange(editor.document, range, stripped);
			await deps.inlineDiff.present(
				{ path: docPath, before: fullBefore, after: fullAfter },
				workspaceRoot,
			);
		} else {
			// Small edit — apply right away with a brief highlight.
			const edit = new vscode.WorkspaceEdit();
			edit.replace(editor.document.uri, range, stripped);
			await vscode.workspace.applyEdit(edit);
			await flashRange(editor, range, stripped);
		}
	} catch (err) {
		const message = err instanceof Error ? err.message : String(err);
		deps.log?.appendLine(`[inline-edit] failed: ${message}`);
		vscode.window.showErrorMessage(`OATI Code: inline edit failed — ${message}`);
	}
}

async function streamRewrite(
	provider: ProviderSpec,
	modelId: string,
	instruction: string,
	selection: string,
	language: string,
): Promise<string> {
	const { system, user } = buildInlineEditPrompt(instruction, selection, language);
	const messages: ConversationMessage[] = [{ role: "user", parts: [{ kind: "text", text: user }] }];
	let out = "";
	for await (const ev of provider.stream({
		messages,
		modelId,
		systemPrompt: system,
		temperature: 0.2,
	})) {
		if (ev.type === "text_delta") out += ev.text;
		else if (ev.type === "error") throw new Error(ev.message);
		else if (ev.type === "message_end") break;
	}
	return out;
}

function resolveProviderId(config: RootConfig): string {
	const mode = config.modes.find((m) => m.id === config.activeModeId);
	return mode?.providerId ?? config.activeProviderId;
}

function replaceRange(doc: vscode.TextDocument, range: vscode.Range, replacement: string): string {
	const head = doc.getText(new vscode.Range(new vscode.Position(0, 0), range.start));
	const tail = doc.getText(new vscode.Range(range.end, doc.positionAt(doc.getText().length)));
	return head + replacement + tail;
}

async function flashRange(
	editor: vscode.TextEditor,
	range: vscode.Range,
	newText: string,
): Promise<void> {
	const newEndOffset = editor.document.offsetAt(range.start) + newText.length;
	const newEnd = editor.document.positionAt(newEndOffset);
	const flashRangeFinal = new vscode.Range(range.start, newEnd);
	const decoration = vscode.window.createTextEditorDecorationType({
		backgroundColor: "rgba(116, 199, 236, 0.30)",
		isWholeLine: false,
	});
	editor.setDecorations(decoration, [flashRangeFinal]);
	setTimeout(() => decoration.dispose(), 700);
}
