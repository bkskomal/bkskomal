// 2026-05-27: Code-review subsystem. Drives the `/review` slash command.
//
// Inputs:
//   - File paths to review (caller-supplied OR auto-detected from
//     WorkspaceChangeTracker / agent's writtenPaths)
//   - ReviewConfig from RootConfig
//   - Provider + model id (same as the agent uses for chat)
//
// Output:
//   - A structured Findings list, severity-ranked
//   - A markdown-formatted summary suitable for chat display
//
// The actual review work is done by the model — we send it the file
// contents + a carefully-structured prompt that lists ONLY the enabled
// categories. The model returns JSON-structured findings; we parse,
// filter, and rank.

import type { ProviderSpec, ReviewConfig, ReviewSeverity } from "@oati/shared";

export interface ReviewFinding {
	readonly path: string;
	readonly line?: number;
	readonly column?: number;
	readonly endLine?: number;
	readonly category: keyof NonNullable<ReviewConfig["categories"]>;
	readonly severity: ReviewSeverity;
	readonly title: string;
	readonly detail: string;
	/** One-line summary of the recommended change. Optional. */
	readonly suggestion?: string;
	/**
	 * 2026-05-27: concrete diff-style fix. When the model can produce a
	 * specific code-level patch, it returns this — `before` quotes the
	 * offending lines verbatim, `after` is the replacement. The markdown
	 * summary renders it as a diff block; the Word report includes it as
	 * a fenced code block. Optional — many findings are conceptual and
	 * don't have a single-line fix.
	 */
	readonly suggestedFix?: {
		readonly before: string;
		readonly after: string;
		readonly rationale?: string;
	};
}

export interface ReviewResult {
	readonly findings: readonly ReviewFinding[];
	readonly summary: string;
	/** Severity rollup. Lets the caller decide whether to block on "blocking" findings. */
	readonly counts: {
		readonly blocking: number;
		readonly advisory: number;
		readonly off: number;
	};
	/** Did any file fail to load? */
	readonly skipped: readonly { readonly path: string; readonly reason: string }[];
}

const DEFAULT_CATEGORIES: NonNullable<ReviewConfig["categories"]> = {
	style: "advisory",
	documentation: "advisory",
	codingStandards: "advisory",
	correctness: "advisory",
	security: "advisory",
	performance: "advisory",
	maintainability: "advisory",
	testing: "advisory",
	typeSafety: "advisory",
	dependencies: "advisory",
	architecture: "advisory",
	accessibility: "off",
	i18n: "off",
	observability: "off",
};

function resolveCategories(cfg: ReviewConfig | undefined): NonNullable<ReviewConfig["categories"]> {
	return { ...DEFAULT_CATEGORIES, ...(cfg?.categories ?? {}) };
}

function enabledCategoryList(cats: NonNullable<ReviewConfig["categories"]>): string[] {
	return Object.entries(cats)
		.filter(([, sev]) => sev && sev !== "off")
		.map(([name]) => name);
}

const CATEGORY_BRIEFS: Record<keyof NonNullable<ReviewConfig["categories"]>, string> = {
	style:
		"Indentation, line length, naming conventions (camelCase / snake_case / PascalCase per language), spacing around operators, trailing whitespace.",
	documentation:
		"PRESENCE: missing function / class / module docstrings; complex logic without inline comments; stale TODOs / FIXMEs left in code. QUALITY: redundant comments that just restate the code (e.g. `// increment i` next to `i++`); outdated comments where the code has changed but the comment hasn't; misleading comments that contradict actual behavior; commented-out blocks of code left as cruft (should be deleted, version control has the history); wrong-format comments (e.g. JSDoc block on a one-line private helper). A finding should explain WHICH issue and quote the offending line.",
	codingStandards:
		"Project-specific conventions visible in the surrounding code (file structure, export patterns, error-handling shapes).",
	correctness:
		"Off-by-one errors, missing null / undefined checks, swallowed exceptions, missing resource cleanup, unreachable code, race conditions in async paths.",
	security:
		"SQL injection (string-concat queries), command injection (shell calls with user input), hardcoded secrets / API keys, weak crypto (MD5 / SHA1), path traversal, insecure deserialization (eval / pickle), missing auth checks, sensitive data in logs.",
	performance:
		"O(n²) operations on large inputs, N+1 DB query patterns, synchronous blocking in async paths, catastrophic-backtracking regex, missing memoization, event-listener leaks.",
	maintainability:
		"Function length over ~50 lines, cyclomatic complexity over ~10, nesting deeper than 4 levels, magic numbers / strings, duplication, mixed responsibilities.",
	testing:
		"Public functions without tests, missing edge cases (empty / null / max / negative / unicode / very long), weak assertions, unclear test names.",
	typeSafety:
		"`any` / `unknown` types in public APIs, missing return-type annotations, type assertions instead of proper guards (only relevant in TypeScript / mypy projects).",
	dependencies:
		"Newly-introduced dependencies that duplicate existing functionality, unmaintained packages, missing version pins, use of deprecated APIs.",
	architecture:
		"Layer violations (UI calling DB directly), circular imports, god files / modules, breaking changes without versioning.",
	accessibility:
		"Missing ARIA labels, no keyboard navigation, color-contrast failures, no screen-reader text — UI code only.",
	i18n:
		"Hardcoded user-facing strings instead of message catalogs, locale-sensitive date / number formatting assumptions, locale-blind sorting.",
	observability:
		"`console.log` instead of a structured logger, missing error context (no request id / stack trace), critical paths without metrics.",
};

export interface RunReviewOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	readonly cfg: ReviewConfig | undefined;
	readonly files: readonly { readonly path: string; readonly content: string }[];
	readonly customRules?: string;
	readonly signal?: AbortSignal;
	/**
	 * 2026-05-27: per-batch progress callback. When files.length exceeds
	 * BATCH_SIZE the review is split into sequential batches; this fires
	 * after each one so the caller can stream a status line to the user.
	 */
	readonly onBatchProgress?: (info: {
		readonly batchIndex: number;
		readonly batchCount: number;
		readonly filesInBatch: number;
		readonly findingsSoFar: number;
	}) => void;
}

// 2026-05-27: how many files we feed the model per call. Bundling all 100+
// files into one prompt blows the context window for any non-frontier
// model and tanks per-file fidelity even on a 256K-context model — the
// reviewer's attention thins out and findings collapse to vague summaries.
// 15 is a sweet spot: ~75KB of code per call, ~20K tokens, leaves room for
// the JSON output and keeps each file in the model's working set.
const BATCH_SIZE = 15;

export async function runReview(opts: RunReviewOptions): Promise<ReviewResult> {
	const cats = resolveCategories(opts.cfg);
	const enabled = enabledCategoryList(cats);
	if (enabled.length === 0) {
		return {
			findings: [],
			summary: "All review categories are disabled.",
			counts: { blocking: 0, advisory: 0, off: 14 },
			skipped: [],
		};
	}

	if (opts.files.length === 0) {
		return {
			findings: [],
			summary: "No files to review.",
			counts: { blocking: 0, advisory: 0, off: 0 },
			skipped: [],
		};
	}

	// Split into sequential batches. Single-batch behavior is preserved
	// for ≤BATCH_SIZE: same prompt, same output, no extra callbacks fired.
	const batches: (typeof opts.files)[] = [];
	for (let i = 0; i < opts.files.length; i += BATCH_SIZE) {
		batches.push(opts.files.slice(i, i + BATCH_SIZE));
	}

	const findings: ReviewFinding[] = [];
	const skipped: { path: string; reason: string }[] = [];

	for (let bi = 0; bi < batches.length; bi++) {
		if (opts.signal?.aborted) {
			skipped.push(
				...batches
					.slice(bi)
					.flat()
					.map((f) => ({ path: f.path, reason: "cancelled" })),
			);
			break;
		}
		const batch = batches[bi];
		const prompt = buildReviewPrompt(batch, cats, opts.customRules);
		let raw = "";
		try {
			for await (const ev of opts.provider.stream({
				messages: [{ role: "user", parts: [{ kind: "text", text: prompt }] }],
				modelId: opts.modelId,
				temperature: 0.0,
				signal: opts.signal,
			})) {
				if (ev.type === "text_delta") raw += ev.text;
				if (ev.type === "error") {
					// Provider failure on one batch shouldn't blow away findings
					// already collected from previous batches — mark this batch
					// as skipped and move on.
					skipped.push(...batch.map((f) => ({ path: f.path, reason: `provider: ${ev.message}` })));
					raw = "";
					break;
				}
			}
		} catch (err) {
			const msg = err instanceof Error ? err.message : String(err);
			skipped.push(...batch.map((f) => ({ path: f.path, reason: `exception: ${msg}` })));
			raw = "";
		}

		if (raw.length > 0) {
			for (const f of parseFindings(raw)) {
				const userSev = cats[f.category];
				if (!userSev || userSev === "off") continue;
				findings.push({ ...f, severity: userSev });
			}
		}

		opts.onBatchProgress?.({
			batchIndex: bi,
			batchCount: batches.length,
			filesInBatch: batch.length,
			findingsSoFar: findings.length,
		});
	}

	const counts = {
		blocking: findings.filter((f) => f.severity === "blocking").length,
		advisory: findings.filter((f) => f.severity === "advisory").length,
		off: 0,
	};

	return {
		findings,
		summary: formatReviewSummary(findings, counts, opts.files.length, skipped),
		counts,
		skipped,
	};
}

function buildReviewPrompt(
	files: readonly { path: string; content: string }[],
	cats: NonNullable<ReviewConfig["categories"]>,
	customRules: string | undefined,
): string {
	const enabled = enabledCategoryList(cats);
	const catLines = enabled
		.map((c) => `  - **${c}**: ${CATEGORY_BRIEFS[c as keyof typeof CATEGORY_BRIEFS]}`)
		.join("\n");
	const fileBlocks = files
		.map((f) => `### File: ${f.path}\n\n\`\`\`\n${f.content}\n\`\`\``)
		.join("\n\n");
	const customRulesBlock = customRules ? `\n\n## Project-specific rules\n\n${customRules}\n` : "";
	return `You are a code reviewer. Produce ONLY a JSON array of findings — no prose, no markdown wrapper. Each finding must be:

\`\`\`json
{
  "path": "src/foo.ts",
  "line": 42,
  "column": 5,
  "endLine": 43,
  "category": "security",
  "severity": "advisory",
  "title": "Short headline (max 80 chars)",
  "detail": "What the issue is, in 1-3 sentences.",
  "suggestion": "Concrete change to make in plain prose. Optional.",
  "suggestedFix": {
    "before": "the EXACT lines from the source that should change, copy-pasted verbatim",
    "after": "the EXACT replacement lines",
    "rationale": "Why this change. One sentence. Optional."
  }
}
\`\`\`

**ALWAYS include \`suggestedFix\`** when the finding has a clear single-block code-level patch — style violations, missing null checks, simple security fixes, redundant comments, etc. Omit it ONLY for conceptual / architectural findings where there is no single right answer.

When you include \`suggestedFix\`:
- \`before\` MUST be a verbatim quote of the offending source lines (the user will apply this as a literal find-and-replace).
- \`after\` MUST compile / run as a drop-in replacement — same imports, same indentation, no \`...\` placeholders.
- Keep the patch SCOPED — quote 1-10 lines, not a whole function. If the fix is bigger than that, leave a prose \`suggestion\` instead and let the user follow up.

Categories you can use:

${catLines}

Severity values: "advisory" or "blocking". Use "blocking" ONLY for clear correctness or security bugs that would break the app or expose data. Style nits are always "advisory".

If the code is clean for an enabled category, do NOT emit empty findings — omit the category from the result entirely.

Be specific. Cite line numbers. If a finding spans multiple lines, set endLine. Don'\''t flag stylistic preferences that aren'\''t actually wrong.

Limit yourself to **20 findings total** across all files — pick the highest-impact ones if more are present.

## Files to review

${fileBlocks}${customRulesBlock}

## Output

Return ONLY the JSON array. No text before or after.`;
}

function parseFindings(raw: string): ReviewFinding[] {
	// Strip the model's habit of wrapping JSON in ```json fences.
	let t = raw.trim();
	const fenceMatch = t.match(/```(?:json)?\s*\n([\s\S]*?)\n```/);
	if (fenceMatch) t = fenceMatch[1].trim();
	// Sometimes the model emits a JSON object wrapper instead of an array.
	const objMatch = t.match(/\{[\s\S]*"findings"\s*:\s*(\[[\s\S]*?\])[\s\S]*\}/);
	if (objMatch) t = objMatch[1];

	let parsed: unknown;
	try {
		parsed = JSON.parse(t);
	} catch {
		return [];
	}
	if (!Array.isArray(parsed)) return [];

	const out: ReviewFinding[] = [];
	for (const item of parsed) {
		if (!item || typeof item !== "object") continue;
		const o = item as Record<string, unknown>;
		if (typeof o.path !== "string" || typeof o.title !== "string") continue;
		if (typeof o.category !== "string") continue;
		const cat = o.category as keyof NonNullable<ReviewConfig["categories"]>;
		const severity: ReviewSeverity =
			o.severity === "blocking" ? "blocking" : o.severity === "off" ? "off" : "advisory";
		let suggestedFix: ReviewFinding["suggestedFix"];
		const sf = o.suggestedFix;
		if (sf && typeof sf === "object" && !Array.isArray(sf)) {
			const sfo = sf as Record<string, unknown>;
			if (typeof sfo.before === "string" && typeof sfo.after === "string") {
				suggestedFix = {
					before: sfo.before,
					after: sfo.after,
					...(typeof sfo.rationale === "string" ? { rationale: sfo.rationale } : {}),
				};
			}
		}
		out.push({
			path: o.path,
			line: typeof o.line === "number" ? o.line : undefined,
			column: typeof o.column === "number" ? o.column : undefined,
			endLine: typeof o.endLine === "number" ? o.endLine : undefined,
			category: cat,
			severity,
			title: o.title,
			detail: typeof o.detail === "string" ? o.detail : "",
			suggestion: typeof o.suggestion === "string" ? o.suggestion : undefined,
			...(suggestedFix ? { suggestedFix } : {}),
		});
	}
	return out;
}

function formatReviewSummary(
	findings: readonly ReviewFinding[],
	counts: { blocking: number; advisory: number; off: number },
	fileCount: number,
	skipped: readonly { path: string; reason: string }[],
): string {
	if (findings.length === 0 && skipped.length === 0) {
		return `✅ Review clean across ${fileCount} file${fileCount === 1 ? "" : "s"}.`;
	}
	const plural = findings.length === 1 ? "" : "s";
	const breakdown =
		counts.blocking > 0 ? ` (${counts.blocking} blocking, ${counts.advisory} advisory)` : "";
	const lines: string[] = [`## Code review — ${findings.length} finding${plural}${breakdown}`];
	const byFile = new Map<string, ReviewFinding[]>();
	for (const f of findings) {
		const list = byFile.get(f.path) ?? [];
		list.push(f);
		byFile.set(f.path, list);
	}
	for (const [path, list] of byFile) {
		lines.push(`\n### \`${path}\``);
		// Sort: blocking first, then by line number
		list.sort((a, b) => {
			if (a.severity !== b.severity) {
				if (a.severity === "blocking") return -1;
				if (b.severity === "blocking") return 1;
			}
			return (a.line ?? 0) - (b.line ?? 0);
		});
		for (const f of list) {
			const icon = f.severity === "blocking" ? "🔴" : "🟡";
			const loc = f.line !== undefined ? `:${f.line}` : "";
			lines.push(`- ${icon} **[${f.category}]** ${f.title}${loc ? ` (line ${f.line})` : ""}`);
			if (f.detail) lines.push(`  ${f.detail}`);
			if (f.suggestion) lines.push(`  → ${f.suggestion}`);
			if (f.suggestedFix) {
				lines.push("  **Suggested fix:**");
				lines.push("  ```diff");
				for (const ln of f.suggestedFix.before.split("\n")) lines.push(`  - ${ln}`);
				for (const ln of f.suggestedFix.after.split("\n")) lines.push(`  + ${ln}`);
				lines.push("  ```");
				if (f.suggestedFix.rationale) lines.push(`  _${f.suggestedFix.rationale}_`);
			}
		}
	}
	if (skipped.length > 0) {
		lines.push("\n### Skipped");
		for (const s of skipped) lines.push(`- ${s.path} — ${s.reason}`);
	}
	return lines.join("\n");
}
