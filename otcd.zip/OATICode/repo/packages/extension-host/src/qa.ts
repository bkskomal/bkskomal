// 2026-05-27: QA-testing subsystem. Drives the `/qa` slash-command suite.
//
// Subcommands:
//   /qa plan <feature>         — writes TEST_PLAN.md
//   /qa unit <file|function>   — generates per-function unit tests
//   /qa edge <file|function>   — systematic edge-case battery
//   /qa regression <bug>       — failing test that reproduces a bug
//   /qa coverage               — runs coverage tool, names gaps
//   /qa security <file>        — OWASP-style adversarial tests
//
// Each subcommand returns a structured QAResult describing what was
// generated and where it landed. The caller (chat-panel) writes files
// via the agent's normal write_file flow so approval gates fire.

import type { ProviderSpec, QAConfig, QASeverity } from "@oati/shared";

export type QASubcommand = "plan" | "unit" | "edge" | "regression" | "coverage" | "security";

export interface QAResult {
	readonly subcommand: QASubcommand;
	readonly summary: string;
	/** Files the user should write (chat-panel does the write_file). */
	readonly artifacts: readonly QAArtifact[];
	/** Plain-text findings the user should READ but isn'\''t a file. */
	readonly notes: readonly string[];
	/** True iff the subcommand needs a `/qa coverage` re-run or test execution. */
	readonly needsTestRun: boolean;
	/**
	 * 2026-05-27: issues the QA analysis surfaced. Most relevant for
	 * `/qa security` (vulnerabilities) and `/qa coverage` (uncovered
	 * critical paths); optional for `/qa unit`, `/qa edge`,
	 * `/qa regression` which are primarily test-generation subcommands.
	 * Each issue carries a file path, line number, and an optional
	 * `suggestedFix` so the report can render "fix at file X line Y".
	 */
	readonly issues?: readonly QAIssue[];
}

export interface QAIssue {
	readonly path: string;
	readonly line?: number;
	readonly column?: number;
	readonly endLine?: number;
	/** Free-form category — e.g. "security:sql-injection", "coverage:gap", "test:missing-edge". */
	readonly category: string;
	readonly severity: "advisory" | "blocking";
	readonly title: string;
	readonly detail: string;
	readonly suggestedFix?: {
		readonly before: string;
		readonly after: string;
		readonly rationale?: string;
	};
}

export interface QAArtifact {
	readonly path: string;
	readonly content: string;
	readonly purpose: string; // human-readable, surfaces in chat
}

const DEFAULT_CATEGORIES: NonNullable<QAConfig["categories"]> = {
	testPlan: "advisory",
	unitTests: "advisory",
	edgeCases: "advisory",
	integration: "off",
	functional: "advisory",
	regression: "advisory",
	coverage: "advisory",
	security: "advisory",
	performance: "off",
	accessibility: "off",
	api: "off",
	e2e: "off",
	propertyBased: "off",
	mutation: "off",
	visualRegression: "off",
};

export function isCategoryEnabled(
	cfg: QAConfig | undefined,
	cat: keyof NonNullable<QAConfig["categories"]>,
): boolean {
	const cats = { ...DEFAULT_CATEGORIES, ...(cfg?.categories ?? {}) };
	const sev = cats[cat] as QASeverity | undefined;
	return sev !== undefined && sev !== "off";
}

export function resolveTestFramework(
	cfg: QAConfig | undefined,
	hints: readonly string[],
): "vitest" | "jest" | "mocha" | "pytest" | "unittest" | "junit" {
	const explicit = cfg?.testFramework;
	if (explicit && explicit !== "auto") return explicit;
	// Auto-detect from a list of file paths or package.json snippets.
	const blob = hints.join("\n").toLowerCase();
	if (blob.includes("vitest")) return "vitest";
	if (blob.includes("jest")) return "jest";
	if (blob.includes("mocha")) return "mocha";
	if (blob.includes("pytest") || blob.includes("pyproject.toml")) return "pytest";
	if (blob.includes("unittest.testcase")) return "unittest";
	if (blob.includes("junit") || blob.includes("pom.xml") || blob.includes("build.gradle"))
		return "junit";
	// Default that works for most TS / JS projects
	return "vitest";
}

export interface RunQAOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	readonly cfg: QAConfig | undefined;
	readonly subcommand: QASubcommand;
	readonly args: string;
	/** File contents the model needs as context (the target of the QA). */
	readonly targetFiles: readonly { readonly path: string; readonly content: string }[];
	/** Auto-detected hints — package.json contents, test dir, etc. */
	readonly frameworkHints: readonly string[];
	readonly signal?: AbortSignal;
}

export async function runQA(opts: RunQAOptions): Promise<QAResult> {
	// Gating by category.
	const catKey = subcommandToCategory(opts.subcommand);
	if (!isCategoryEnabled(opts.cfg, catKey)) {
		return {
			subcommand: opts.subcommand,
			summary: `\`/qa ${opts.subcommand}\` is disabled in this workspace'\''s QA settings (category: ${catKey}). Enable it in Settings → QA Testing.`,
			artifacts: [],
			notes: [],
			needsTestRun: false,
		};
	}
	const framework = resolveTestFramework(opts.cfg, opts.frameworkHints);
	const prompt = buildQAPrompt(opts.subcommand, opts.args, opts.targetFiles, framework);

	let raw = "";
	try {
		for await (const ev of opts.provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: prompt }] }],
			modelId: opts.modelId,
			temperature: 0.0,
			signal: opts.signal,
		})) {
			if (ev.type === "text_delta") raw += ev.text;
			if (ev.type === "error") {
				return {
					subcommand: opts.subcommand,
					summary: `QA provider error: ${ev.message}`,
					artifacts: [],
					notes: [],
					needsTestRun: false,
				};
			}
		}
	} catch (err) {
		return {
			subcommand: opts.subcommand,
			summary: `QA failed: ${err instanceof Error ? err.message : String(err)}`,
			artifacts: [],
			notes: [],
			needsTestRun: false,
		};
	}

	return parseQAResult(opts.subcommand, raw);
}

function subcommandToCategory(sub: QASubcommand): keyof NonNullable<QAConfig["categories"]> {
	switch (sub) {
		case "plan":
			return "testPlan";
		case "unit":
			return "unitTests";
		case "edge":
			return "edgeCases";
		case "regression":
			return "regression";
		case "coverage":
			return "coverage";
		case "security":
			return "security";
	}
}

function buildQAPrompt(
	sub: QASubcommand,
	args: string,
	targetFiles: readonly { path: string; content: string }[],
	framework: string,
): string {
	const fileBlocks = targetFiles
		.map((f) => `### File: ${f.path}\n\n\`\`\`\n${f.content}\n\`\`\``)
		.join("\n\n");
	const trailer = `
## Output format

Respond with ONLY a JSON object:

\`\`\`json
{
  "summary": "One-paragraph human-readable summary of what was produced.",
  "artifacts": [
    {
      "path": "tests/auth/login.test.ts",
      "content": "complete file contents",
      "purpose": "One-line description of what this file covers."
    }
  ],
  "notes": ["Any observations the user should READ but that aren'\''t files."],
  "issues": [
    {
      "path": "src/auth/login.ts",
      "line": 42,
      "category": "security:sql-injection",
      "severity": "blocking",
      "title": "User input concatenated into SQL",
      "detail": "The username parameter is concatenated directly into the query string; this is exploitable.",
      "suggestedFix": {
        "before": "const q = \\"SELECT * FROM users WHERE name = '\\" + name + \\"'\\";",
        "after": "const q = \\"SELECT * FROM users WHERE name = ?\\"; await db.run(q, [name]);",
        "rationale": "Parameterized queries prevent injection."
      }
    }
  ]
}
\`\`\`

Each artifact'\''s \`content\` MUST be a complete, runnable file. No placeholders. No \"// ...rest of code\". Tests MUST import from the target file path correctly.

The \`issues\` array surfaces ANALYSIS findings (vulnerabilities, coverage gaps, edge cases the existing code might mishandle). It'\''s MOST RELEVANT for \`/qa security\` and \`/qa coverage\` — for those subcommands, every real issue you found should appear here with a line number and (when possible) a \`suggestedFix\` block. For \`/qa unit\`, \`/qa edge\`, \`/qa regression\` the array can be empty if the tests themselves are the deliverable.

When you include \`suggestedFix\` on an issue:
- \`before\` must be a VERBATIM quote of the offending lines.
- \`after\` must compile / run as a drop-in replacement.
- Keep it scoped to 1-10 lines.`;

	switch (sub) {
		case "plan":
			return `You are a QA lead. Write a comprehensive TEST_PLAN.md for the feature described below.

The plan must include: scope (in/out), test strategy (manual / automated / exploratory split), risks + mitigations, prerequisites, deliverables (reports, dashboards), pass/fail criteria, schedule + milestones, and a section listing the specific test cases (functional, integration, edge, regression, security, performance) the team should write.

Be concrete. No filler. Use the project context below to make the plan ACTIONABLE — reference real files and modules, not abstract "the system".

## Feature

${args}

${targetFiles.length > 0 ? `## Workspace context\n\n${fileBlocks}\n` : ""}
${trailer}

In this case, the SOLE artifact is \`TEST_PLAN.md\` (or a path the user'\''s prompt named).`;

		case "unit":
			return `You are a test author. Generate ${framework} unit tests for the function(s) / module(s) below.

Rules:
- One test file per source file. Mirror the source path under \`tests/\` (TS / JS) or \`tests/\` next to source (Python).
- Tests are independent — no shared state across tests.
- Cover happy path AND error path for each public function.
- Use the project'\''s existing test conventions if visible in the workspace context.
- DON'\''T include edge cases here — that'\''s \`/qa edge\`. Stay focused on the core behaviors.

## Target

${args}

## Source files

${fileBlocks}

## Framework

${framework}
${trailer}`;

		case "edge":
			return `You are a fuzzing-minded test author. Generate ${framework} edge-case tests for the function(s) below.

Cover the SYSTEMATIC edge-case battery for each public function:
- Empty / null / undefined inputs
- Min / max / zero / negative numbers (where numeric)
- Very long strings (10 KB+), strings with newlines, unicode (CJK, emoji, RTL)
- Empty arrays, very large arrays
- Whitespace-only strings
- Malformed input (truncated JSON, invalid utf-8, NUL bytes)
- Boundary conditions (off-by-one)
- Concurrent / re-entrant calls (if async)

For each function, produce 5-15 edge-case tests. Don'\''t duplicate \`/qa unit\` — happy-path tests live there.

## Target

${args}

## Source files

${fileBlocks}

## Framework

${framework}
${trailer}`;

		case "regression":
			return `You are a regression-test author. From the bug description below, produce ONE minimal failing test that:
1. Reproduces the bug deterministically
2. Will pass once the bug is fixed
3. Has a name that includes the bug ID or a short slug from the description
4. Lives in \`tests/regression/\` if that directory exists, else next to the source

## Bug description

${args}

## Relevant source files

${fileBlocks}

## Framework

${framework}
${trailer}

Be SURGICAL. One test, one assertion that captures the bug. Add a comment at the top citing the bug.`;

		case "coverage":
			return `You are a coverage-gap analyst. Given the coverage output and source files below, produce:

1. A summary of which files / lines are uncovered
2. Test cases that would target the highest-impact gaps (focus on uncovered branches and error paths, not trivial getters)
3. The actual test files for those gaps (using ${framework})

## Coverage report (or hint of what to run)

${args || "(no coverage output provided — caller should run coverage first and re-invoke with the output as args)"}

## Source files

${fileBlocks}

## Framework

${framework}
${trailer}`;

		case "security":
			return `You are a security-minded test author. Generate ${framework} tests that probe the target code for the OWASP-style failure modes:

- SQL injection (if any SQL is involved)
- Command injection (if shell calls are involved)
- XSS (if HTML is generated)
- Path traversal (if filesystem paths come from user input)
- Insecure deserialization (eval / pickle / yaml.load)
- Hardcoded-secret detection (test for known-bad patterns)
- Auth bypass (if auth checks are present)
- Sensitive-data-in-logs

For each applicable failure mode, write a test that supplies a malicious payload and asserts the code RESISTS it. Skip categories that don'\''t apply to this code.

## Target

${args}

## Source files

${fileBlocks}

## Framework

${framework}
${trailer}`;
	}
}

function parseQAResult(sub: QASubcommand, raw: string): QAResult {
	let t = raw.trim();
	const fenceMatch = t.match(/```(?:json)?\s*\n([\s\S]*?)\n```/);
	if (fenceMatch) t = fenceMatch[1].trim();

	let parsed: unknown;
	try {
		parsed = JSON.parse(t);
	} catch {
		return {
			subcommand: sub,
			summary: `Could not parse \`/qa ${sub}\` output as JSON. Raw response (first 500 chars):\n\n\`\`\`\n${raw.slice(0, 500)}\n\`\`\``,
			artifacts: [],
			notes: [],
			needsTestRun: false,
		};
	}

	const obj = parsed as Record<string, unknown>;
	const artifacts: QAArtifact[] = [];
	if (Array.isArray(obj.artifacts)) {
		for (const a of obj.artifacts) {
			if (!a || typeof a !== "object") continue;
			const ao = a as Record<string, unknown>;
			if (typeof ao.path !== "string" || typeof ao.content !== "string") continue;
			artifacts.push({
				path: ao.path,
				content: ao.content,
				purpose: typeof ao.purpose === "string" ? ao.purpose : "",
			});
		}
	}
	const notes: string[] = [];
	if (Array.isArray(obj.notes)) {
		for (const n of obj.notes) {
			if (typeof n === "string") notes.push(n);
		}
	}
	const issues: QAIssue[] = [];
	if (Array.isArray(obj.issues)) {
		for (const iAny of obj.issues) {
			if (!iAny || typeof iAny !== "object") continue;
			const i = iAny as Record<string, unknown>;
			if (typeof i.path !== "string" || typeof i.title !== "string") continue;
			if (typeof i.category !== "string") continue;
			const severity: "advisory" | "blocking" = i.severity === "blocking" ? "blocking" : "advisory";
			let suggestedFix: QAIssue["suggestedFix"];
			const sf = i.suggestedFix;
			if (sf && typeof sf === "object" && !Array.isArray(sf)) {
				const sfo = sf as Record<string, unknown>;
				if (typeof sfo.before === "string" && typeof sfo.after === "string") {
					suggestedFix = {
						before: sfo.before,
						after: sfo.after,
						...(typeof sfo.rationale === "string" ? { rationale: sfo.rationale } : {}),
					};
				}
			}
			issues.push({
				path: i.path,
				line: typeof i.line === "number" ? i.line : undefined,
				column: typeof i.column === "number" ? i.column : undefined,
				endLine: typeof i.endLine === "number" ? i.endLine : undefined,
				category: i.category,
				severity,
				title: i.title,
				detail: typeof i.detail === "string" ? i.detail : "",
				...(suggestedFix ? { suggestedFix } : {}),
			});
		}
	}
	const summary = typeof obj.summary === "string" ? obj.summary : `/qa ${sub} completed.`;
	return {
		subcommand: sub,
		summary,
		artifacts,
		notes,
		needsTestRun: sub === "unit" || sub === "edge" || sub === "regression" || sub === "coverage",
		...(issues.length > 0 ? { issues } : {}),
	};
}

/** Render a QAResult as a chat-friendly markdown message. */
export function formatQAResult(result: QAResult): string {
	const lines: string[] = [`## /qa ${result.subcommand} — ${result.summary}`];
	if (result.artifacts.length > 0) {
		lines.push("\n### Artifacts");
		for (const a of result.artifacts) {
			lines.push(`- \`${a.path}\` — ${a.purpose || "(no description)"}`);
		}
	}
	if (result.issues && result.issues.length > 0) {
		lines.push(`\n### Issues found (${result.issues.length})`);
		const byFile = new Map<string, QAIssue[]>();
		for (const i of result.issues) {
			const list = byFile.get(i.path) ?? [];
			list.push(i);
			byFile.set(i.path, list);
		}
		for (const [path, list] of byFile) {
			lines.push(`\n**\`${path}\`**`);
			list.sort((a, b) => {
				if (a.severity !== b.severity) {
					if (a.severity === "blocking") return -1;
					if (b.severity === "blocking") return 1;
				}
				return (a.line ?? 0) - (b.line ?? 0);
			});
			for (const i of list) {
				const icon = i.severity === "blocking" ? "🔴" : "🟡";
				const loc = i.line !== undefined ? ` (line ${i.line})` : "";
				lines.push(`- ${icon} **[${i.category}]** ${i.title}${loc}`);
				if (i.detail) lines.push(`  ${i.detail}`);
				if (i.suggestedFix) {
					lines.push("  **Suggested fix:**");
					lines.push("  ```diff");
					for (const ln of i.suggestedFix.before.split("\n")) lines.push(`  - ${ln}`);
					for (const ln of i.suggestedFix.after.split("\n")) lines.push(`  + ${ln}`);
					lines.push("  ```");
					if (i.suggestedFix.rationale) lines.push(`  _${i.suggestedFix.rationale}_`);
				}
			}
		}
	}
	if (result.notes.length > 0) {
		lines.push("\n### Notes");
		for (const n of result.notes) lines.push(`- ${n}`);
	}
	if (result.needsTestRun && result.artifacts.length > 0) {
		lines.push(
			"\n_Run your test suite to confirm the new tests are wired up correctly (or use `/test-loop` for the auto-iterate flow)._",
		);
	}
	return lines.join("\n");
}
