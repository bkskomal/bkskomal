// 2026-05-26: Diagnostics feedback loop — surfaces NEW errors / warnings that
// appeared since the previous agent turn finished, prepending a compact note
// to the next user turn. The user'\''s ask was concrete: when tests or typecheck
// fail, the next prompt shouldn'\''t have to re-paste the failures — the agent
// should already see them.
//
// Approach: snapshot the workspace diagnostic state at the END of each turn,
// then on the NEXT turn diff the current state against it. Anything new
// (or worsened) gets surfaced as `[Diagnostics] ...` system context. Errors
// that were already there before the prior turn ended are NOT re-surfaced —
// the model has already had the chance to see them; re-injecting them every
// turn is just noise.

import type { DiagnosticEntry, DiagnosticsProvider } from "@oati/shared";

function keyOf(d: DiagnosticEntry): string {
	// Path + line + message identifies a diagnostic stably across the
	// rapid debounced re-fires the language server does as you type.
	// (Same approach VS Code'\''s own problem-panel uses for grouping.)
	return `${d.path}:${d.line}:${d.message}`;
}

const MAX_SURFACED = 20;

export class DiagnosticsFeedbackTracker {
	private lastSnapshot: ReadonlySet<string> = new Set();

	constructor(private readonly provider: DiagnosticsProvider) {}

	/**
	 * Compute the set of diagnostics that are currently present but were NOT
	 * present at the prior turn'\''s end. Errors are surfaced before warnings;
	 * within a severity the first N (by file path order) are kept.
	 *
	 * Side effect: also takes the current snapshot so subsequent calls diff
	 * against THIS turn'\''s starting state. Calling twice in a row will return
	 * an empty list the second time even if nothing changed in between.
	 */
	async drainNewSince(): Promise<readonly DiagnosticEntry[]> {
		const current = await this.provider.all({ severity: ["error", "warning"] });
		const seen = this.lastSnapshot;
		const newOnes: DiagnosticEntry[] = [];
		const nextSnapshot = new Set<string>();
		for (const d of current) {
			const k = keyOf(d);
			nextSnapshot.add(k);
			if (!seen.has(k)) newOnes.push(d);
		}
		// Sort: errors first, then warnings; stable by path:line within.
		newOnes.sort((a, b) => {
			if (a.severity !== b.severity) {
				if (a.severity === "error") return -1;
				if (b.severity === "error") return 1;
			}
			if (a.path !== b.path) return a.path.localeCompare(b.path);
			return a.line - b.line;
		});
		this.lastSnapshot = nextSnapshot;
		return newOnes.slice(0, MAX_SURFACED);
	}

	/**
	 * Reset the baseline — used when the user explicitly wants the next turn
	 * to see ALL current errors as "new" (e.g. on session restore or after a
	 * /diagnostics-refresh slash command). Rarely needed in normal flow.
	 */
	resetBaseline(): void {
		this.lastSnapshot = new Set();
	}
}

/**
 * Render a list of new diagnostics as a tagged system note. Returns an empty
 * string when nothing is new so the caller can just `if (note) prepend(note)`
 * without a length check.
 */
export function formatDiagnosticsAsSystemNote(diags: readonly DiagnosticEntry[]): string {
	if (diags.length === 0) return "";
	const errors = diags.filter((d) => d.severity === "error");
	const warnings = diags.filter((d) => d.severity === "warning");
	const errorWord = errors.length === 1 ? "" : "s";
	const warningSuffix =
		warnings.length > 0 ? ` + ${warnings.length} warning${warnings.length === 1 ? "" : "s"}` : "";
	const lines: string[] = [
		`[Diagnostics] ${errors.length} new error${errorWord}${warningSuffix} surfaced since the previous turn. If these block your goal, address them; otherwise note that you see them.`,
	];
	const toLine = (d: DiagnosticEntry): string =>
		`  ${d.severity === "error" ? "✗" : "⚠"} ${d.path}:${d.line}:${d.column} — ${d.message.replace(/\s+/g, " ").trim()}`;
	for (const d of errors.slice(0, 12)) lines.push(toLine(d));
	if (errors.length > 12) lines.push(`  (+${errors.length - 12} more errors)`);
	for (const d of warnings.slice(0, 6)) lines.push(toLine(d));
	if (warnings.length > 6) lines.push(`  (+${warnings.length - 6} more warnings)`);
	return lines.join("\n");
}
