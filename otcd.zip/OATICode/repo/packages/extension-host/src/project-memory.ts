import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

/**
 * Maximum size of project memory content (in bytes / UTF-16 code units, conservatively
 * applied as a character count). Anything beyond this is truncated with a `[truncated]`
 * suffix so an oversized memory file can't blow out the model's context window.
 */
export const PROJECT_MEMORY_MAX_BYTES = 32 * 1024;
/** Smaller cap for the global tier — it's prepended to every prompt so be conservative. */
export const GLOBAL_MEMORY_MAX_BYTES = 16 * 1024;

/**
 * User-global memory file (Claude-style three-tier memory). Layered ABOVE
 * the project memory in the prelude — global facts/preferences first, then
 * project-specific. Lookup order is first-hit-wins under `$HOME`.
 */
export const GLOBAL_MEMORY_CANDIDATES = [
	".oati/OATI.md",
	".oati/CLAUDE.md",
	".claude/CLAUDE.md",
] as const;

/**
 * Lookup order for the per-workspace project memory file. First hit wins; the rest are
 * ignored. Matches the convention used by Claude Code (`.claude/CLAUDE.md`) and a
 * project-namespaced equivalent (`.oati/OATI.md`).
 */
export const PROJECT_MEMORY_CANDIDATES = [
	".oati/OATI.md",
	"OATI.md",
	".claude/CLAUDE.md",
	"CLAUDE.md",
] as const;

export interface ProjectMemory {
	/** Absolute path of the file the content was read from. */
	readonly path: string;
	/** UTF-8 contents, capped at `PROJECT_MEMORY_MAX_BYTES` (with `[truncated]` suffix when capped). */
	readonly content: string;
}

/**
 * Find and load the first matching project memory file under `workspacePath`.
 *
 * - Returns `undefined` if nothing matches or the file is unreadable (permission
 *   denied, unexpected directory, etc.) — callers should treat any failure as
 *   "no memory available" rather than surfacing an error to the user.
 * - Content over `PROJECT_MEMORY_MAX_BYTES` is hard-truncated with a `[truncated]`
 *   marker appended so the model can tell it didn't see the full document.
 * - The result is intentionally re-read on every call rather than cached: callers
 *   invoke this before each user turn so editing the memory file and saving it
 *   takes effect on the next prompt without restarting the extension.
 */
export async function loadProjectMemory(workspacePath: string): Promise<ProjectMemory | undefined> {
	if (!workspacePath) return undefined;
	for (const rel of PROJECT_MEMORY_CANDIDATES) {
		const abs = path.join(workspacePath, rel);
		try {
			const stat = await fs.stat(abs);
			if (!stat.isFile()) continue;
			const raw = await fs.readFile(abs, "utf-8");
			const content = capContent(raw);
			return { path: abs, content };
		} catch {
			// Missing, permission denied, or some other read error — treat as "skip".
			// We deliberately don't surface the error: a missing/unreadable memory
			// file is a normal state and we already try multiple candidates.
		}
	}
	return undefined;
}

function capContent(raw: string, cap = PROJECT_MEMORY_MAX_BYTES): string {
	if (raw.length <= cap) return raw;
	return `${raw.slice(0, cap)}\n\n[truncated]`;
}

/**
 * 2026-06-03: starter template for `OATI.md`. The init command writes
 * this when no existing project memory file is detected, so the user
 * has a runnable example to edit instead of a blank file. Kept generic
 * — concrete project facts go in the placeholder bullets which read
 * like prompts ("- ..."), inviting completion.
 */
export const PROJECT_MEMORY_TEMPLATE = `# OATI.md — Project Memory

This file is auto-loaded into the agent's system prompt every session.
Edit it to tell the OATI Code agent things it should always know about
this project — conventions, stack, gotchas, where to look first.

Keep it concise (≤8KB recommended). The file lives at the repo root
and should be checked into git so every contributor's agent sees the
same context.

## Stack

- Backend:
- Frontend:
- Database:
- Deployment:

## Conventions

- File naming:
- Test layout:
- Commit messages:
- Branch naming:

## Don't do

- (Things the agent has gotten wrong in this project — add them here as
  you notice them, e.g., "don't suggest using axios; we standardized on
  fetch in PR #42")

## Where to look first

- Entry points:
- Configuration:
- Tests:

## Recent context

- (Short notes about what's currently in flight or recently changed)
`;

/**
 * 2026-06-03: initialize a new OATI.md at the workspace root if none
 * exists. Returns the absolute path written, or undefined when an
 * existing project memory file was found (the lookup walks the
 * PROJECT_MEMORY_CANDIDATES — if any candidate exists, we don't
 * overwrite). Exported for use by the `oati.initProjectMemory`
 * command.
 */
export async function initProjectMemory(
	workspacePath: string,
): Promise<{ created: true; path: string } | { created: false; existingPath: string }> {
	const existing = await loadProjectMemory(workspacePath);
	if (existing) {
		return { created: false, existingPath: existing.path };
	}
	const target = path.join(workspacePath, "OATI.md");
	await fs.writeFile(target, PROJECT_MEMORY_TEMPLATE, "utf-8");
	return { created: true, path: target };
}

/**
 * 2026-06-03: append a chunk to the workspace's project memory file.
 * Used by the `suggest_project_memory_addition` tool to surface
 * agent-proposed facts to the user — and by the future
 * `oati.appendToProjectMemory` slash command. The chunk goes under a
 * "## Suggested additions — <iso>" header so the user can review and
 * either keep the additions, move them into the right section, or
 * delete them. Append-only — never overwrites existing content.
 */
export async function appendToProjectMemory(
	workspacePath: string,
	chunk: string,
	source: "agent" | "user" = "user",
): Promise<{ path: string }> {
	if (!workspacePath) throw new Error("appendToProjectMemory: workspacePath is required");
	if (!chunk || chunk.trim().length === 0) {
		throw new Error("appendToProjectMemory: chunk is empty");
	}
	// Resolve the target path WITHOUT re-reading content — appendFile
	// preserves existing bytes verbatim, which matters when the file is
	// over the 32KB readCap (loadProjectMemory would return a truncated
	// `[truncated]`-suffixed copy that, if written back, would destroy
	// the tail).
	let targetPath: string | undefined;
	for (const rel of PROJECT_MEMORY_CANDIDATES) {
		const candidate = path.join(workspacePath, rel);
		try {
			const stat = await fs.stat(candidate);
			if (stat.isFile()) {
				targetPath = candidate;
				break;
			}
		} catch {
			/* skip — file missing */
		}
	}
	const header = `\n\n## Suggested additions — ${new Date().toISOString().slice(0, 10)} (${source})\n\n`;
	const block = `${header}${chunk.trim()}\n`;
	if (targetPath) {
		// File exists — append.
		await fs.appendFile(targetPath, block, "utf-8");
		return { path: targetPath };
	}
	// File doesn't exist — bootstrap it with the template, then append.
	const fresh = path.join(workspacePath, "OATI.md");
	await fs.writeFile(fresh, PROJECT_MEMORY_TEMPLATE + block, "utf-8");
	return { path: fresh };
}

/**
 * Load the user-global memory file from `$HOME` (Claude-style global tier).
 * Returns `undefined` if nothing is configured or readable. Capped at
 * GLOBAL_MEMORY_MAX_BYTES because this content prepends every single prompt.
 */
export async function loadGlobalMemory(): Promise<ProjectMemory | undefined> {
	const home = os.homedir();
	if (!home) return undefined;
	for (const rel of GLOBAL_MEMORY_CANDIDATES) {
		const abs = path.join(home, rel);
		try {
			const stat = await fs.stat(abs);
			if (!stat.isFile()) continue;
			const raw = await fs.readFile(abs, "utf-8");
			return { path: abs, content: capContent(raw, GLOBAL_MEMORY_MAX_BYTES) };
		} catch {
			/* skip — file missing or unreadable is the normal state */
		}
	}
	return undefined;
}
