/*
 * R2-E share / export session — produces a clean Markdown transcript suitable
 * for pasting into a doc, attaching to a bug report, or checking into a repo
 * as a session-of-record.
 *
 * The existing `oati.exportSession` command writes JSON (machine-readable,
 * preserves tool calls/results losslessly for re-import). This module covers
 * the human-readable side: H2 sections per turn, tool calls collapsed under
 * <details> so they don't drown the prose, code in fenced blocks with a
 * language hint when we can guess one.
 */

import type { ConversationMessage, MessagePart } from "@oati/shared";

/**
 * Render a conversation to Markdown.
 *
 * Shape per turn:
 *   ## User       — for user messages
 *   ## Assistant  — for assistant messages
 *   <details><summary>Tool call: <name></summary>…</details>
 *
 * System/tool-only messages are rendered as a less-prominent note so they
 * don't clutter the narrative but stay auditable.
 */
export function exportSessionAsMarkdown(session: {
	readonly title?: string;
	readonly history: readonly ConversationMessage[];
}): string {
	const out: string[] = [];
	const title = session.title?.trim() || "OATI Code session";
	out.push(`# ${title}`);
	out.push("");
	out.push(`_Exported ${new Date().toISOString()}_`);
	out.push("");

	for (const msg of session.history) {
		const heading = headingFor(msg.role);
		if (heading) {
			out.push(`## ${heading}`);
			out.push("");
		}
		for (const part of msg.parts) {
			renderPart(part, out);
		}
		out.push("");
	}

	return `${out.join("\n").trimEnd()}\n`;
}

function headingFor(role: ConversationMessage["role"]): string | undefined {
	if (role === "user") return "User";
	if (role === "assistant") return "Assistant";
	if (role === "system") return "System";
	// Tool-result messages stand on their own — no H2 to avoid double-heading
	// when the part itself emits a <details> block.
	return undefined;
}

function renderPart(part: MessagePart, out: string[]): void {
	if (part.kind === "text") {
		out.push(rewriteFencedBlocks(part.text));
		out.push("");
		return;
	}
	if (part.kind === "tool_call") {
		const args = safeStringify(part.args);
		out.push(`<details><summary>🔧 Tool call: <code>${escapeHtml(part.name)}</code></summary>`);
		out.push("");
		out.push("```json");
		out.push(args);
		out.push("```");
		out.push("");
		out.push("</details>");
		out.push("");
		return;
	}
	if (part.kind === "tool_result") {
		const body = typeof part.output === "string" ? part.output : safeStringify(part.output);
		const label = part.isError ? "❌ Tool result (error)" : "✅ Tool result";
		out.push(`<details><summary>${label} <code>${escapeHtml(part.id)}</code></summary>`);
		out.push("");
		out.push("```");
		out.push(body);
		out.push("```");
		out.push("");
		out.push("</details>");
		out.push("");
		return;
	}
	if (part.kind === "image") {
		// Inline data: URLs blow up the markdown size and most renderers strip
		// them anyway. Emit a placeholder noting MIME type so the transcript
		// stays faithful without being unreadable.
		out.push(`> _[image attachment: ${part.mimeType}]_`);
		out.push("");
		return;
	}
}

/**
 * Normalize fenced code blocks in assistant text. If a block is missing a
 * language hint, try to guess one from common shebangs / syntax markers so
 * the rendered output gets proper syntax highlighting.
 */
function rewriteFencedBlocks(text: string): string {
	return text.replace(/```([a-zA-Z0-9_+-]*)\r?\n([\s\S]*?)\r?\n```/g, (_match, lang, body) => {
		const guessed = (lang || "").trim() || guessLanguage(body);
		return `\`\`\`${guessed}\n${body}\n\`\`\``;
	});
}

/**
 * Heuristic language guesser for hint-less fenced blocks. Keep it small;
 * exotic guesses do more harm than good in a transcript context.
 */
function guessLanguage(body: string): string {
	const first = body.split(/\r?\n/, 1)[0]?.trim() ?? "";
	if (/^#!.*\bpython/.test(first)) return "python";
	if (/^#!.*\b(bash|sh)\b/.test(first)) return "bash";
	if (/^#!.*\bnode/.test(first)) return "javascript";
	if (/^\s*(import|export|const|let|function|class)\b/m.test(body)) {
		// `function` / `class` aren't TS-specific, but TS is a safer default than
		// JS for code coming out of this extension.
		return /\b(interface|type)\s+\w+\s*[={]/.test(body) ? "typescript" : "javascript";
	}
	if (/^\s*def\s+\w+\(|^\s*from\s+\w+\s+import\s/m.test(body)) return "python";
	if (/^\s*package\s+\w+|^\s*func\s+\w+\(/m.test(body)) return "go";
	if (/^\s*fn\s+\w+\(|^\s*use\s+\w+::/m.test(body)) return "rust";
	if (/^\s*<\?php/.test(body)) return "php";
	if (/^\s*<[a-zA-Z][^>]*>/.test(first)) return "html";
	if (/^\s*\{[\s\S]*\}\s*$/.test(body.trim())) return "json";
	return "";
}

function safeStringify(value: unknown): string {
	try {
		return JSON.stringify(value, null, 2);
	} catch {
		return String(value);
	}
}

function escapeHtml(s: string): string {
	return s
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;")
		.replace(/"/g, "&quot;");
}
