// R7-B: In-VS-Code Mocha entry point. Loaded by @vscode/test-electron, this
// instantiates a Mocha runner, registers every `*.test.ts` (compiled to .js)
// under this folder, and resolves/rejects according to the suite's pass/fail.
//
// Tests should be scoped to the top user flows — see `*.test.ts` siblings.

import * as path from "node:path";
import { glob } from "glob";
import Mocha = require("mocha");

/**
 * Entry point for @vscode/test-electron. Must return a Promise that resolves
 * on green and rejects on failure so the runner exits with the right code.
 */
export async function run(): Promise<void> {
	const mocha = new Mocha({
		ui: "bdd",
		color: true,
		// VS Code can be slow to spin up first-touch APIs; give each test some
		// breathing room. Individual tests can override with `this.timeout(...)`.
		timeout: 20_000,
		reporter: "spec",
	});

	const here = __dirname;
	// Pick up compiled .js files alongside this index.
	const files: readonly string[] = await glob("**/*.test.js", { cwd: here });
	for (const file of files) {
		mocha.addFile(path.resolve(here, file));
	}

	return await new Promise<void>((resolve, reject) => {
		try {
			mocha.run((failures: number) => {
				if (failures > 0) {
					reject(new Error(`${failures} test(s) failed`));
				} else {
					resolve();
				}
			});
		} catch (err) {
			reject(err as Error);
		}
	});
}
