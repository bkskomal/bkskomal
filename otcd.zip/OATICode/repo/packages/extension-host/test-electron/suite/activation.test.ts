// R7-B: Activation smoke test.
//
// Verifies the extension manifest is picked up by the live VS Code, that the
// activation handler runs to completion without throwing, and the extension
// host marks it `isActive`.

import { strict as assert } from "node:assert";
import * as vscode from "vscode";

const EXTENSION_ID = "oati.oati-coding-assistant";

describe("flow: activation", () => {
	it("extension is discoverable", () => {
		const ext = vscode.extensions.getExtension(EXTENSION_ID);
		assert.ok(ext, `extension '${EXTENSION_ID}' not found in VS Code's extension list`);
	});

	it("activate() resolves without throwing", async function () {
		const ext = vscode.extensions.getExtension(EXTENSION_ID);
		if (!ext) {
			// `it` predicate already failed in the previous case; skip rather than
			// double-report.
			console.log("[skipped] extension not installed");
			this.skip();
			return;
		}
		await ext.activate();
		assert.equal(ext.isActive, true, "extension reported inactive after activate()");
	});

	it("registers the headline command set", async () => {
		const ext = vscode.extensions.getExtension(EXTENSION_ID);
		assert.ok(ext, "extension missing");
		if (!ext.isActive) await ext.activate();
		const all = await vscode.commands.getCommands(true);
		for (const id of [
			"oati.openChat",
			"oati.openSettings",
			"oati.newChat",
			"oati.helloWorld",
			"oati.openMarketplace",
		]) {
			assert.ok(all.includes(id), `command not registered: ${id}`);
		}
	});
});
