// R7-B: Inline-diff flow.
//
// Drives the InlineDiffController through the `oati._test.presentInlineDiff`
// helper (registered only when `OATI_E2E=1`) and asserts that VS Code's
// CodeLensProvider machinery emits one accept/reject/modify lens trio per
// hunk, anchored at the expected line range.

import { strict as assert } from "node:assert";
import * as os from "node:os";
import * as path from "node:path";
import * as vscode from "vscode";

const EXTENSION_ID = "oati.oati-coding-assistant";

interface LensSummary {
	command: string;
	startLine: number;
	endLine: number;
}

describe("flow: inline-diff", () => {
	before(async () => {
		const ext = vscode.extensions.getExtension(EXTENSION_ID);
		assert.ok(ext, "extension missing");
		if (!ext.isActive) await ext.activate();
	});

	it("present() emits code lenses anchored at the hunk's after-range", async function () {
		this.timeout(20_000);

		// Use an OS-temp file rather than the workspace so the test doesn't
		// require a folder to be open.
		const tmp = path.join(os.tmpdir(), `oati-e2e-inline-${Date.now()}.ts`);
		const before = "function a() {\n  return 1;\n}\n";
		const after = "function a() {\n  return 2;\n}\n";

		let lenses: readonly LensSummary[] | undefined;
		try {
			lenses = await vscode.commands.executeCommand<readonly LensSummary[]>(
				"oati._test.presentInlineDiff",
				{ path: tmp, before, after },
			);
		} catch (err) {
			if (
				err instanceof Error &&
				/command 'oati._test\.presentInlineDiff' not found/i.test(err.message)
			) {
				console.log("[skipped] OATI_E2E not set — internal helper not registered");
				this.skip();
				return;
			}
			throw err;
		}

		assert.ok(Array.isArray(lenses), "expected an array of code lenses");
		assert.ok((lenses ?? []).length > 0, "expected at least one accept/reject/modify lens");

		// The single hunk lives on line index 1 (zero-based, second line of
		// "return X" change). Allow ±1 since the controller may anchor on the
		// line above the change to keep the lens visible.
		const anchored = (lenses ?? []).filter((l) => Math.abs(l.startLine - 1) <= 1);
		assert.ok(
			anchored.length > 0,
			`expected a lens near line 1 (the changed line) — got: ${JSON.stringify(lenses)}`,
		);

		// Sanity: each lens command should be one of the registered actions.
		for (const l of lenses ?? []) {
			assert.match(
				l.command,
				/^oati\.inlineDiff\.(accept|reject|modify)$/,
				`unexpected lens command: ${l.command}`,
			);
		}
	});
});
