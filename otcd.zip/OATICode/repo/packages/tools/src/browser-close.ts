// TODO(r2-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

import type { ToolSpec } from "@oati/shared";
import { close, isActive } from "./browser-state";

interface BrowserCloseResult {
	readonly closed: boolean;
}

export const browserCloseTool: ToolSpec = {
	name: "browser_close",
	description:
		"Close the shared Puppeteer browser window if one is open. No-op when no session is active. " +
		"Useful for explicit cleanup at the end of a debugging session.",
	schema: {
		type: "object",
		properties: {},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(): Promise<BrowserCloseResult> {
		const wasActive = isActive();
		await close();
		return { closed: wasActive };
	},
};
