// R6-B: edit_notebook_cell — replace the source of a single cell in a .ipynb.
// Backed by `ctx.notebooks.editCell`, which wraps `vscode.NotebookEdit.replaceCells`
// inside a `vscode.workspace.applyEdit` so VS Code groups the change into one
// undo. Approval is `"prompt"` and the preview surfaces a diff so the user can
// eyeball the before/after.
import type { ToolSpec } from "@oati/shared";
import { parseNotebookJson } from "./read-notebook";

interface EditNotebookCellArgs {
	readonly path: string;
	readonly index: number;
	readonly source: string;
}

function isEditNotebookCellArgs(v: unknown): v is EditNotebookCellArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as EditNotebookCellArgs;
	return (
		typeof a.path === "string" &&
		typeof a.index === "number" &&
		Number.isFinite(a.index) &&
		typeof a.source === "string"
	);
}

export const editNotebookCellTool: ToolSpec = {
	name: "edit_notebook_cell",
	description:
		"Replace the source of a single cell in a Jupyter notebook (.ipynb). Identified by 0-based index. Shows a diff preview and requires user approval. Outputs are preserved (only the source changes). Use insert_notebook_cell / delete_notebook_cell to add or remove cells.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Path to the .ipynb file, relative to workspace root or absolute.",
			},
			index: {
				type: "integer",
				description: "0-based cell index to replace.",
			},
			source: {
				type: "string",
				description: "Full new source for the cell.",
			},
		},
		required: ["path", "index", "source"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args, ctx) {
		if (!isEditNotebookCellArgs(args)) return {};
		let before = "";
		try {
			if (ctx.notebooks) {
				const cells = await ctx.notebooks.read(args.path, false);
				if (args.index >= 0 && args.index < cells.length) {
					before = cells[args.index].source;
				}
			} else if (await ctx.fileExists(args.path)) {
				const raw = await ctx.readFile(args.path);
				const cells = parseNotebookJson(raw, false);
				if (args.index >= 0 && args.index < cells.length) {
					before = cells[args.index].source;
				}
			}
		} catch {
			// Fall through with an empty `before`; the diff still surfaces the
			// proposed new source so the user can decide.
		}
		return {
			diff: {
				path: `${args.path}#cell-${args.index}`,
				before,
				after: args.source,
			},
		};
	},
	async handler(args, ctx) {
		if (!isEditNotebookCellArgs(args)) {
			throw new Error(
				"edit_notebook_cell: invalid args, expected { path: string; index: number; source: string }",
			);
		}
		if (!ctx.notebooks) {
			throw new Error(
				"edit_notebook_cell: this host has no notebook bridge — open the .ipynb in VS Code first.",
			);
		}
		await ctx.notebooks.editCell(args.path, args.index, args.source);
		return { edited: true, path: args.path, index: args.index };
	},
};
