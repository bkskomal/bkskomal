// R6-E: debug_scopes — list the variable scopes (Locals, Arguments, Globals,
// ...) available for a given stack frame in the active debug session.
// Backed by the DAP `scopes` request via `ctx.debug.getScopes`. The returned
// `variablesReference`s are opaque numbers the agent feeds into
// `debug_variables` to drill in.
// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@oati/shared";

interface DebugScopesArgs {
	readonly frameId: number;
}

function isDebugScopesArgs(v: unknown): v is DebugScopesArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as DebugScopesArgs;
	if (typeof a.frameId !== "number") return false;
	return true;
}

export const debugScopesTool: ToolSpec = {
	name: "debug_scopes",
	description:
		"List variable scopes for a stack frame in the active debug session. Returns a JSON array of {name, variablesReference}. Use this after debug_stack_frames to learn which `variablesReference`s to pass to debug_variables.",
	schema: {
		type: "object",
		properties: {
			frameId: {
				type: "integer",
				description: "DAP frame id (from debug_stack_frames).",
			},
		},
		required: ["frameId"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isDebugScopesArgs(args)) {
			throw new Error("debug_scopes: invalid args, expected { frameId: number }");
		}
		if (!ctx.debug) {
			return JSON.stringify({ scopes: [], note: "debug_scopes: no debug bridge in this host." });
		}
		if (!ctx.debug.getActiveSession()) {
			return JSON.stringify({ scopes: [], note: "debug_scopes: no active debug session." });
		}
		try {
			const scopes = await ctx.debug.getScopes(args.frameId);
			return JSON.stringify({ scopes });
		} catch (err) {
			return JSON.stringify({
				scopes: [],
				error: err instanceof Error ? err.message : String(err),
			});
		}
	},
};
