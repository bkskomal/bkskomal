// 2026-05-27: `ask_user` tool — the agent calls this when a decision
// MEANINGFULLY changes the outcome AND the model can't infer the right
// choice from context. The host either prompts the user with a chip-strip
// UI and waits for the answer, OR auto-picks the first option (auto-mode
// gate), OR refuses (mode disabled the tool). All three behaviors are
// driven by `ModeConfig.allowAskUser`.
//
// What the agent should AVOID:
//   - Asking trivial questions ("should I use 2 spaces or 4?") when the
//     surrounding code makes the answer obvious.
//   - Stalling on tasks that have a clearly-right path.
//   - Asking back-to-back questions when one would suffice — bundle
//     options into ONE call.
//
// The PROMPT addendum injected per-model reinforces these rules so the
// tool surfaces only when the value of asking exceeds the cost of
// pausing.

import type { ToolSpec } from "@oati/shared";

interface AskUserOption {
	readonly label: string;
	readonly description?: string;
}

interface AskUserArgs {
	readonly question: string;
	readonly options: readonly AskUserOption[];
	readonly allowOther?: boolean;
	readonly urgency?: "low" | "high";
}

function isAskUserArgs(v: unknown): v is AskUserArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as Record<string, unknown>;
	if (typeof a.question !== "string" || a.question.trim().length === 0) return false;
	if (!Array.isArray(a.options) || a.options.length < 2 || a.options.length > 6) return false;
	for (const opt of a.options) {
		if (typeof opt !== "object" || opt === null) return false;
		const o = opt as Record<string, unknown>;
		if (typeof o.label !== "string" || o.label.trim().length === 0) return false;
		if (o.description !== undefined && typeof o.description !== "string") return false;
	}
	if (a.allowOther !== undefined && typeof a.allowOther !== "boolean") return false;
	if (a.urgency !== undefined && a.urgency !== "low" && a.urgency !== "high") return false;
	return true;
}

// Description-policy reference (NOT in the wire description — kept here so
// future maintainers see WHY the model is told what it's told):
//
// - Use ONLY when the answer meaningfully changes what you build AND can't be
//   inferred from workspace / prior turns. Not a stalling tactic.
// - Provide 2-6 options; LIST THE MOST LIKELY ANSWER FIRST (auto modes may
//   auto-pick option[0]). Each option = { label, description? }.
// - Bundle related choices into ONE call instead of asking back-to-back.
// - `allowOther: true` is rare — only when free-text adds genuine value.
// - Returns `{ answer: string, other?: boolean, autoPicked?: boolean }`.
export const askUserTool: ToolSpec = {
	name: "ask_user",
	description:
		"Ask the user a multiple-choice clarifying question. Use when the answer changes what you build and you can't infer it from context. 2-6 options, most likely first. Bundle related choices into one call.",
	schema: {
		type: "object",
		properties: {
			question: {
				type: "string",
				description:
					"The clarifying question, one sentence ending in `?`. Be specific about what hinges on the answer.",
			},
			options: {
				type: "array",
				description:
					"2-6 options. List the MOST LIKELY correct answer FIRST — in auto modes the host may auto-pick option[0]. Each option is an object with shape `{ label: string, description?: string }` — label is a short imperative phrase; description is a one-line clarification when label alone is ambiguous.",
				items: { type: "object" },
			},
			allowOther: {
				type: "boolean",
				description:
					"When true, the UI shows a free-text input as well as the option chips. Default false. Only set true when free-text might add real value.",
			},
			urgency: {
				type: "string",
				enum: ["low", "high"],
				description:
					"Visual emphasis. 'high' is for decisions that block a critical path; the UI may render them more prominently. Default 'low'.",
			},
		},
		required: ["question", "options"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isAskUserArgs(args)) {
			throw new Error(
				"ask_user: invalid args — expected { question: string, options: [{label,description?}] (2-6), allowOther?: bool, urgency?: 'low'|'high' }",
			);
		}
		if (!ctx.askUser) {
			// Host doesn't support interactive prompting (test harness,
			// headless CLI, etc.). Fall back to picking option[0] — the
			// tool description tells the model to list its best guess
			// FIRST so this fallback is sensible.
			return {
				answer: args.options[0].label,
				other: false,
				autoPicked: true,
			};
		}
		// Generate a stable id so the host's webview round-trip can be
		// matched to this specific call.
		const id = `ask_${Math.random().toString(36).slice(2, 10)}`;
		const result = await ctx.askUser({
			id,
			question: args.question,
			options: args.options,
			allowOther: args.allowOther ?? false,
			urgency: args.urgency ?? "low",
		});
		return result;
	},
};
