import { promises as fs } from "node:fs";
import * as path from "node:path";
// TODO(r4-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@oati/shared";

interface SaveSnippetArgs {
	readonly name: string;
	readonly body: string;
	readonly description?: string;
}

function isSaveSnippetArgs(v: unknown): v is SaveSnippetArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SaveSnippetArgs;
	if (typeof a.name !== "string" || a.name.trim().length === 0) return false;
	if (typeof a.body !== "string") return false;
	if (a.description !== undefined && typeof a.description !== "string") return false;
	return true;
}

const VALID_NAME = /^[a-zA-Z0-9_-]+$/;

/**
 * R4-C: persist a markdown snippet to `<workspace>/.oati/snippets/<name>.md`.
 * Always writes an H1 description line first, synthesizing one from the
 * snippet name when the caller omits it. Approval is `prompt` so the user
 * sees every snippet the agent wants to save.
 */
export const saveSnippetTool: ToolSpec = {
	name: "save_snippet",
	description:
		"Save a markdown snippet to `<workspace>/.oati/snippets/<name>.md`. The first H1 line is the description; everything else is the snippet body. Overwrites an existing file with the same name.",
	schema: {
		type: "object",
		properties: {
			name: {
				type: "string",
				description: "Slug name (letters, digits, underscore, dash). Becomes the filename.",
			},
			body: {
				type: "string",
				description: "Snippet body (markdown). Can include fenced code blocks for language hints.",
			},
			description: {
				type: "string",
				description: "Optional short description (used as the H1 line). Defaults to the name.",
			},
		},
		required: ["name", "body"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isSaveSnippetArgs(args)) return {};
		const desc = (args.description ?? args.name).trim() || args.name;
		const after = `# ${desc}\n\n${args.body}${args.body.endsWith("\n") ? "" : "\n"}`;
		return { diff: { path: `.oati/snippets/${args.name}.md`, before: "", after } };
	},
	async handler(args, ctx): Promise<string> {
		if (!isSaveSnippetArgs(args)) throw new Error("save_snippet: invalid args");
		if (!VALID_NAME.test(args.name)) {
			throw new Error(
				`save_snippet: invalid snippet name '${args.name}'. Use letters, digits, underscore, or dash.`,
			);
		}
		const root = ctx.workspaceRoot();
		if (!root) {
			throw new Error("save_snippet: no workspace folder open.");
		}
		const dir = path.join(root, ".oati", "snippets");
		await fs.mkdir(dir, { recursive: true });
		const desc = (args.description ?? args.name).trim() || args.name;
		const trimmedBody = args.body.replace(/^\r?\n+/, "");
		const doc = `# ${desc}\n\n${trimmedBody}${trimmedBody.endsWith("\n") ? "" : "\n"}`;
		const abs = path.join(dir, `${args.name}.md`);
		await fs.writeFile(abs, doc, "utf-8");
		return `Saved snippet '${args.name}' to .oati/snippets/${args.name}.md`;
	},
};
