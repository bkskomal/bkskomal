import type { HostContext, ToolSpec } from "@oati/shared";
// R6-D: smart-apply (three-way merge) bridge.
import { smartApplyEdit } from "../../extension-host/src/smart-apply";

interface WriteFileArgs {
	readonly path: string;
	readonly content: string;
	// R6-D: optional pre-image the agent saw — when supplied we can detect
	// drift and route the write through the three-way merge.
	readonly before?: string;
}

function isWriteFileArgs(v: unknown): v is WriteFileArgs {
	if (typeof v !== "object" || v === null) return false;
	const w = v as WriteFileArgs;
	if (typeof w.path !== "string" || typeof w.content !== "string") return false;
	if (w.before !== undefined && typeof w.before !== "string") return false;
	return true;
}

// R6-D: when the agent's `before` snapshot differs from the on-disk current
// content, route through smartApplyEdit so we three-way-merge instead of
// clobbering the user's work. Keeps the bypass tight (~25 lines) and falls
// back to the naive write whenever there's no drift or no snapshot.
async function maybeSmartApply(args: WriteFileArgs, ctx: HostContext): Promise<string> {
	if (args.before === undefined) return args.content;
	const current = (await ctx.fileExists(args.path)) ? await ctx.readFile(args.path) : "";
	if (current === args.before) return args.content;
	const res = smartApplyEdit(args.path, args.before, args.content, current);
	return res.merged;
}

export const writeFileTool: ToolSpec = {
	name: "write_file",
	description:
		"Write file contents to the user's workspace. Shows a diff preview and requires user approval before applying.",
	schema: {
		type: "object",
		properties: {
			path: { type: "string", description: "Path to write, relative to workspace root or absolute." },
			content: { type: "string", description: "Full new contents of the file." },
			// R6-D: optional pre-image for drift-aware three-way merge.
			before: {
				type: "string",
				description:
					"Optional pre-image the agent was working from. When supplied and the on-disk file has drifted, a three-way merge is attempted before applying.",
			},
		},
		required: ["path", "content"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args, ctx) {
		if (!isWriteFileArgs(args)) return {};
		const before = (await ctx.fileExists(args.path)) ? await ctx.readFile(args.path) : "";
		// R6-D: preview the smart-applied result so the user sees the actual
		// post-merge buffer (with any conflict markers) in the approval dialog.
		const after = await maybeSmartApply(args, ctx);
		return { diff: { path: args.path, before, after } };
	},
	async handler(args, ctx) {
		if (!isWriteFileArgs(args)) throw new Error("write_file: invalid args");
		// R6-D: route through maybeSmartApply so drifted files get merged
		// rather than clobbered.
		const finalContent = await maybeSmartApply(args, ctx);
		// Animated streaming write — opt-in. Falls through to the buffered
		// write when streamFileWrite isn't wired (non-VS Code hosts) or when
		// the host hasn't enabled the animation flag. The host enforces a
		// size ceiling internally so we don't have to here.
		if (ctx.streamFileWrite) {
			await ctx.streamFileWrite(args.path, finalContent);
		} else {
			await ctx.writeFile(args.path, finalContent);
		}
		return { written: true, path: args.path };
	},
};
