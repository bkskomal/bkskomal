import type { ToolSpec, WorkspaceContextSnapshot } from "@oati/shared";

export const workspaceContextTool: ToolSpec = {
	name: "get_workspace_context",
	description:
		"Get the user's current IDE state: workspace root, the file they're actively viewing, any selected text, and the list of open editor tabs. Useful at the start of a task to ground the conversation in what the user is looking at.",
	schema: {
		type: "object",
		properties: {},
		additionalProperties: false,
	},
	approval: "auto",
	async handler(_args, ctx): Promise<WorkspaceContextSnapshot> {
		if (!ctx.getWorkspaceContext) {
			return {
				workspaceRoot: ctx.workspaceRoot(),
				openFiles: [],
			};
		}
		return ctx.getWorkspaceContext();
	},
};
