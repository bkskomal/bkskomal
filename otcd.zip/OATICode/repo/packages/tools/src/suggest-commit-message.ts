// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
// R6-C: agent-callable wrapper around the staged-diff → commit-message flow.
//
// This tool does NOT call back into the model itself; instead it returns the
// raw staged diff plus a structured "guide" the calling agent can use to
// craft a Conventional Commits-style message. Keeping the tool side-effect
// free means approval can be `"auto"` — no commit is created, no files are
// touched, and the agent gets a stable surface for "what would I commit?".

import type { ToolSpec } from "@oati/shared";

interface SuggestCommitMessageArgs {
	readonly maxDiffBytes?: number;
}

interface SuggestCommitMessageResult {
	readonly hasStaged: boolean;
	readonly diff: string;
	readonly diffBytes: number;
	readonly truncated: boolean;
	readonly conventionalTypes: readonly string[];
	readonly guidance: string;
}

const DEFAULT_MAX_BYTES = 80_000;
const HARD_CAP_BYTES = 500_000;

const CONVENTIONAL_TYPES = [
	"feat",
	"fix",
	"refactor",
	"docs",
	"test",
	"chore",
	"perf",
	"build",
	"ci",
	"style",
] as const;

const GUIDANCE = [
	"Format the commit message as Conventional Commits:",
	"  - Subject (line 1, <= 72 chars): `<type>(<scope>): <summary>` — no trailing period.",
	"  - Blank line.",
	"  - Optional bullet body: one self-contained bullet per line, prefixed with '- '.",
	"Pick the type from the conventionalTypes list. If the change spans multiple",
	"types, prefer the most user-visible one (feat > fix > refactor > chore).",
].join("\n");

function isArgs(v: unknown): v is SuggestCommitMessageArgs {
	if (v === undefined || v === null) return true;
	if (typeof v !== "object") return false;
	const a = v as SuggestCommitMessageArgs;
	if (a.maxDiffBytes !== undefined && typeof a.maxDiffBytes !== "number") return false;
	return true;
}

export const suggestCommitMessageTool: ToolSpec = {
	name: "suggest_commit_message",
	description:
		"Read the staged git diff and return it alongside guidance for crafting a Conventional Commits-style message. Read-only — does NOT create a commit. Use after staging changes; pair with `git_commit` to actually record the commit.",
	schema: {
		type: "object",
		properties: {
			maxDiffBytes: {
				type: "number",
				description:
					"Soft cap on returned diff size, in bytes. Defaults to 80000. Hard-capped at 500000 regardless of this value.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<SuggestCommitMessageResult> {
		if (!isArgs(args)) throw new Error("suggest_commit_message: invalid args");
		const requested = args?.maxDiffBytes ?? DEFAULT_MAX_BYTES;
		const cap = Math.max(1024, Math.min(requested, HARD_CAP_BYTES));

		const res = await ctx.exec("git diff --staged --no-color", { timeoutMs: 30_000 });
		if (res.exitCode !== 0 && res.exitCode !== 1) {
			throw new Error(
				`git diff --staged failed (exit ${res.exitCode}): ${res.stderr.trim() || res.stdout.trim() || "no output"}`,
			);
		}
		const raw = res.stdout ?? "";
		const diffBytes = raw.length;
		const hasStaged = raw.trim().length > 0;
		const truncated = diffBytes > cap;
		const diff = truncated
			? `${raw.slice(0, cap)}\n\n--- (diff truncated at ${cap} bytes; stage fewer files for full output) ---\n`
			: raw;
		return {
			hasStaged,
			diff,
			diffBytes,
			truncated,
			conventionalTypes: CONVENTIONAL_TYPES,
			guidance: hasStaged
				? GUIDANCE
				: "No staged changes. Stage files with `git add <path>` before calling this tool.",
		};
	},
};
