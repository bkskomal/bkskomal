import type { ToolSpec } from "@oati/shared";

interface SymbolsInFileArgs {
	readonly path: string;
}

function isSymbolsInFileArgs(v: unknown): v is SymbolsInFileArgs {
	return typeof v === "object" && v !== null && typeof (v as SymbolsInFileArgs).path === "string";
}

/**
 * `symbols_in_file` — wraps `vscode.executeDocumentSymbolProvider` to give the
 * agent a fast outline of a file before reading the whole thing. Returns a
 * flat list of {name, kind, line, parent?} entries; nested symbols are
 * flattened with `parent` set to the enclosing symbol's name so two methods
 * named `init` on different classes are still distinguishable.
 */
export const symbolsInFileTool: ToolSpec = {
	name: "symbols_in_file",
	description:
		"List the symbols (functions, classes, methods, variables) declared in a file using the editor's language server. Useful for getting an outline before reading a large file. Returns a flat list with `parent` set on nested symbols. Falls back gracefully when no language server is attached.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "File to outline. Relative to workspace root, or absolute.",
			},
		},
		required: ["path"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isSymbolsInFileArgs(args)) {
			throw new Error("symbols_in_file: invalid args, expected { path: string }");
		}
		if (!ctx.symbols) {
			return "symbols_in_file: no language-server bridge available in this host.";
		}
		const symbols = await ctx.symbols.documentSymbols(args.path);
		if (symbols.length === 0) {
			return `symbols_in_file: no symbols found in ${args.path}.`;
		}
		const lines = symbols.map((s) => {
			const parent = s.parent ? ` (in ${s.parent})` : "";
			return `${s.line}\t${s.kind}\t${s.name}${parent}`;
		});
		return `line\tkind\tname\n${lines.join("\n")}`;
	},
};
