// R5-A: inline_completion_stats — surface the rolling acceptance counters of
// the inline-completion provider so the agent can self-report user signal.
// Pulls from a module-level singleton in `@oati/extension-host/inline-completion`
// without going through `ctx` — the tool is read-only and the value is
// trivially serializable, so a static cross-package import is the simplest
// wiring. Tests can override via `_setInlineCompletionStatsReader`.
import type { ToolSpec } from "@oati/shared";

export interface InlineCompletionStatsSnapshot {
	readonly accepted: number;
	readonly rejected: number;
	readonly shown: number;
	readonly acceptanceRate: number;
	readonly lastUpdatedIso: string;
}

type Reader = () => InlineCompletionStatsSnapshot;

// Default reader returns zeros — overridden by the extension-host at activate
// time via `_setInlineCompletionStatsReader`. Keeps `@oati/tools` free of any
// dependency on `@oati/extension-host`.
let reader: Reader = () => ({
	accepted: 0,
	rejected: 0,
	shown: 0,
	acceptanceRate: 0,
	lastUpdatedIso: new Date(0).toISOString(),
});

/**
 * Inject the stats reader. Called from the extension-host wiring so the tool
 * can return live counters without `@oati/tools` taking a dependency on
 * `@oati/extension-host`.
 */
export function _setInlineCompletionStatsReader(fn: Reader): void {
	reader = fn;
}

export const inlineCompletionStatsTool: ToolSpec = {
	name: "inline_completion_stats",
	description:
		"R5-A: read the rolling acceptance counters of the inline-completion (ghost-text) provider. Returns {accepted, rejected, shown, acceptanceRate, lastUpdatedIso}. Useful for the agent to self-report user signal — e.g., 'your last 50 suggestions were accepted 42% of the time'. Read-only and zero-cost.",
	schema: {
		type: "object",
		properties: {},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler() {
		const snap = reader();
		const total = snap.accepted + snap.rejected;
		const acceptanceRate = total === 0 ? 0 : snap.accepted / total;
		return JSON.stringify({
			accepted: snap.accepted,
			rejected: snap.rejected,
			shown: snap.shown,
			acceptanceRate: Number(acceptanceRate.toFixed(4)),
			lastUpdatedIso: snap.lastUpdatedIso,
		});
	},
};
