// TODO(r5-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import { promises as fs } from "node:fs";
import * as path from "node:path";
import type { ToolSpec } from "@oati/shared";

/** Relative directory under the workspace root that holds knowledge docs. */
const KNOWLEDGE_RELATIVE_DIR = ".oati/knowledge";

interface KnowledgeDoc {
	readonly path: string;
	readonly title: string;
	readonly updatedAt: string;
}

interface ListKnowledgeResult {
	readonly docs: readonly KnowledgeDoc[];
}

/**
 * R5-B: list every markdown doc under `<workspace>/.oati/knowledge/**\/*.md`.
 * Returns workspace-relative paths plus a derived title (first H1 line, or
 * the filename when no H1 is present) and the file's mtime as `updatedAt`.
 * Missing knowledge dir → `{ docs: [] }` (not an error).
 */
export const listKnowledgeTool: ToolSpec = {
	name: "list_knowledge",
	description:
		"List all knowledge docs under `<workspace>/.oati/knowledge/**/*.md`. Returns the workspace-relative path, the first H1 as the title (filename fallback), and the file's modification time. Use this before `search_knowledge` to discover what's available.",
	schema: {
		type: "object",
		properties: {},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(_args, ctx): Promise<ListKnowledgeResult> {
		const root = ctx.workspaceRoot();
		if (!root) return { docs: [] };
		const docs = await collectDocs(root);
		return { docs };
	},
};

async function collectDocs(workspaceRoot: string): Promise<KnowledgeDoc[]> {
	const root = path.join(workspaceRoot, KNOWLEDGE_RELATIVE_DIR);
	const absPaths: string[] = [];
	async function walk(dir: string): Promise<void> {
		let entries: import("node:fs").Dirent[];
		try {
			entries = await fs.readdir(dir, { withFileTypes: true });
		} catch {
			return;
		}
		for (const entry of entries) {
			const abs = path.join(dir, entry.name);
			if (entry.isDirectory()) {
				await walk(abs);
			} else if (entry.isFile() && entry.name.toLowerCase().endsWith(".md")) {
				absPaths.push(abs);
			}
		}
	}
	await walk(root);
	absPaths.sort();
	const out: KnowledgeDoc[] = [];
	for (const abs of absPaths) {
		const rel = path.relative(workspaceRoot, abs).replace(/\\/g, "/");
		let title = path.basename(abs, ".md");
		let updatedAt = new Date(0).toISOString();
		try {
			const raw = await fs.readFile(abs, "utf-8");
			const m = /^#\s+(.+?)\s*$/m.exec(raw);
			if (m) title = m[1];
		} catch {
			/* keep filename-derived title */
		}
		try {
			const stat = await fs.stat(abs);
			updatedAt = stat.mtime.toISOString();
		} catch {
			/* keep epoch */
		}
		out.push({ path: rel, title, updatedAt });
	}
	return out;
}
