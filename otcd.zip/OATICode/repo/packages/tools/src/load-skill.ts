// TODO(r8-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
// R8-E: load_skill — fetch the full body of a skill the agent has been told is
// available. Skills live under `<workspace>/.oati/skills/<name>.md` with a
// YAML front-matter block (see packages/extension-host/src/skills.ts).
// Approval is `"auto"` because reading a workspace file the user committed to
// their own repo is identical in risk to a `read_file` of the same path.

import { promises as fs } from "node:fs";
import * as path from "node:path";
import type { ToolSpec } from "@oati/shared";

interface LoadSkillArgs {
	readonly name: string;
}

interface LoadSkillResult {
	readonly name: string;
	readonly description?: string;
	readonly tools?: readonly string[];
	readonly triggers?: readonly string[];
	readonly body: string;
}

const VALID_NAME = /^[a-zA-Z0-9_-]+$/;
const SKILLS_DIR_REL = ".oati/skills";

function isLoadSkillArgs(v: unknown): v is LoadSkillArgs {
	return (
		typeof v === "object" &&
		v !== null &&
		typeof (v as LoadSkillArgs).name === "string" &&
		(v as LoadSkillArgs).name.length > 0
	);
}

/**
 * Minimal in-file front-matter parser. We deliberately avoid importing
 * `js-yaml` here because the tools package stays dependency-light; the shape
 * we extract is small (name/description/tools/triggers) and easy to scan
 * line-by-line. The chat-panel side (which has yaml available) does the full
 * canonical parse for trigger matching; here we just surface the raw text.
 */
function extractFrontMatter(raw: string): {
	frontMatter: Record<string, string | string[]>;
	body: string;
} {
	const fm: Record<string, string | string[]> = {};
	const match = /^---\s*\r?\n([\s\S]*?)\r?\n---\s*\r?\n([\s\S]*)$/m.exec(raw);
	if (!match) return { frontMatter: fm, body: raw };
	const [, head, body] = match;
	const lines = head.split(/\r?\n/);
	let currentList: string[] | undefined;
	let currentKey: string | undefined;
	for (const line of lines) {
		const trimmed = line.trim();
		if (trimmed.length === 0) continue;
		if (currentList && /^[-*]\s+/.test(trimmed)) {
			currentList.push(trimmed.replace(/^[-*]\s+/, "").replace(/^["']|["']$/g, ""));
			continue;
		}
		const kv = /^([A-Za-z_][A-Za-z0-9_-]*)\s*:\s*(.*)$/.exec(line);
		if (!kv) continue;
		const [, key, value] = kv;
		const v = value.trim();
		if (v.length === 0) {
			currentList = [];
			currentKey = key;
			fm[key] = currentList;
			continue;
		}
		currentList = undefined;
		currentKey = key;
		if (v.startsWith("[") && v.endsWith("]")) {
			const items = v
				.slice(1, -1)
				.split(",")
				.map((s) => s.trim().replace(/^["']|["']$/g, ""))
				.filter((s) => s.length > 0);
			fm[key] = items;
		} else {
			fm[key] = v.replace(/^["']|["']$/g, "");
		}
	}
	void currentKey;
	return { frontMatter: fm, body: body.replace(/^\s*\n/, "") };
}

export const loadSkillTool: ToolSpec = {
	name: "load_skill",
	description:
		"Load the full body of a skill file from `<workspace>/.oati/skills/<name>.md`. Use this after the system prompt has advertised an available skill — it returns the markdown instructions (and any tools/triggers metadata) so you can follow the skill's playbook. Returns an error if the skill doesn't exist or the name is malformed.",
	schema: {
		type: "object",
		properties: {
			name: {
				type: "string",
				description: "Skill name (filename minus .md). Must match [a-zA-Z0-9_-]+.",
			},
		},
		required: ["name"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<LoadSkillResult> {
		if (!isLoadSkillArgs(args)) {
			throw new Error("load_skill: invalid args, expected { name: string }");
		}
		const name = args.name;
		if (!VALID_NAME.test(name)) {
			throw new Error(`load_skill: invalid skill name '${name}' (must match [a-zA-Z0-9_-]+)`);
		}
		const root = ctx.workspaceRoot();
		const bundled = ctx.bundledSkillsDir;
		const candidates: string[] = [];
		if (root) candidates.push(path.join(root, SKILLS_DIR_REL, `${name}.md`));
		if (bundled) candidates.push(path.join(bundled, `${name}.md`));
		if (candidates.length === 0) {
			throw new Error("load_skill: no workspace folder open and no bundled skills available.");
		}
		let raw: string | undefined;
		for (const abs of candidates) {
			try {
				raw = await fs.readFile(abs, "utf-8");
				break;
			} catch {
				/* try next candidate */
			}
		}
		if (raw === undefined) {
			throw new Error(
				`load_skill: skill '${name}' not found in workspace .oati/skills or bundled skills.`,
			);
		}
		const { frontMatter, body } = extractFrontMatter(raw);
		const description =
			typeof frontMatter.description === "string" ? frontMatter.description : undefined;
		const tools = Array.isArray(frontMatter.tools) ? frontMatter.tools : undefined;
		const triggers = Array.isArray(frontMatter.triggers) ? frontMatter.triggers : undefined;
		const result: LoadSkillResult = {
			name,
			body,
			...(description ? { description } : {}),
			...(tools ? { tools } : {}),
			...(triggers ? { triggers } : {}),
		};
		return result;
	},
};
