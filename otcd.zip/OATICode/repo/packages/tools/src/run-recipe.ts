// R5-D: run_recipe tool. Lets the agent kick off a saved multi-step workflow
// from `<workspace>/.oati/recipes/<name>.md`. Approval is `prompt` because a
// recipe can sequence destructive operations (`/git_commit`, `/git_open_pr`,
// shell commands) — the user should see which recipe is about to run before
// the conductor starts dispatching steps.
//
// The actual sequencing lives in `extension-host/src/recipes.ts`; this tool
// surface is intentionally thin so non-VS Code hosts can wire their own
// recipe runner against the same name. The host bridge listens for
// `tool_call.name === "run_recipe"` and promotes it to a `runRecipe(...)`
// call (see r5-merge TODO).
//
// TODO(r5-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

import type { ToolSpec } from "@oati/shared";

interface RunRecipeArgs {
	readonly name: string;
}

function isRunRecipeArgs(v: unknown): v is RunRecipeArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as { name?: unknown };
	return typeof a.name === "string" && a.name.trim().length > 0;
}

const VALID_NAME = /^[a-zA-Z0-9_-]+$/;

export const runRecipeTool: ToolSpec = {
	name: "run_recipe",
	description:
		"Run a saved multi-step workflow from `<workspace>/.oati/recipes/<name>.md`. Each step is dispatched as a separate agent turn, with the prior step's history fed into the next. Use this when the user has authored a recipe (e.g. `ship-feature`) and wants the agent to execute it end-to-end.",
	schema: {
		type: "object",
		properties: {
			name: {
				type: "string",
				description: "Recipe slug — matches the filename under `.oati/recipes/` minus `.md`.",
			},
		},
		required: ["name"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isRunRecipeArgs(args)) return {};
		return {
			note: `Will run recipe '${args.name}' from .oati/recipes/${args.name}.md. Each step is a separate agent turn.`,
		};
	},
	async handler(args, _ctx): Promise<string> {
		if (!isRunRecipeArgs(args)) {
			throw new Error("run_recipe: invalid args — expected { name: string }");
		}
		const name = args.name.trim();
		if (!VALID_NAME.test(name)) {
			throw new Error(
				`run_recipe: invalid recipe name '${name}'. Use letters, digits, underscore, or dash.`,
			);
		}
		// As with set_persona above, the actual sequencing is wired in the
		// extension-host bridge so this handler stays side-effect-free until
		// the merge picks it up via the registry.
		return `Recipe '${name}' queued — the host will sequence its steps as N back-to-back agent turns.`;
	},
};
