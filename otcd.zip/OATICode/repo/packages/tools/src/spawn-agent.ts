import type { ToolSpec } from "@oati/shared";

interface SpawnArgs {
	readonly task: string;
	readonly system_prompt?: string;
}

function isSpawnArgs(v: unknown): v is SpawnArgs {
	if (typeof v !== "object" || v === null) return false;
	const s = v as SpawnArgs;
	if (typeof s.task !== "string") return false;
	if (s.system_prompt !== undefined && typeof s.system_prompt !== "string") return false;
	return true;
}

export const spawnAgentTool: ToolSpec = {
	name: "spawn_agent",
	description:
		"Spawn an isolated sub-agent to handle a self-contained sub-task. The sub-agent runs with the same tool set but a fresh conversation. Use for parallelizable research/refactoring chunks. Returns the sub-agent's final answer plus stats.",
	// Phase 2.2: gate on the model's sub-agent capability. Weak models
	// (Gemma, small Llamas, generic Ollama) get this tool hidden — they
	// can't coherently track sub-agent results in their context, so
	// exposing it leads to confused output rather than parallelism.
	// Frontier + open-weight-large models see it as usual.
	requiredCapability: "spawn-sub-agents",
	schema: {
		type: "object",
		properties: {
			task: {
				type: "string",
				description: "The complete task description for the sub-agent. Be specific and self-contained.",
			},
			system_prompt: {
				type: "string",
				description:
					"Optional override for the sub-agent's system prompt. Defaults to the parent's mode prompt.",
			},
		},
		required: ["task"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isSpawnArgs(args)) throw new Error("spawn_agent: invalid args");
		if (!ctx.spawnSubAgent) {
			throw new Error(
				"spawn_agent: sub-agent spawning is not enabled in this host. Increase maxParallelAgents and ensure the host wires HostContext.spawnSubAgent.",
			);
		}
		const result = await ctx.spawnSubAgent({
			task: args.task,
			systemPromptOverride: args.system_prompt,
		});
		return result;
	},
};
