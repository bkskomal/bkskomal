// TODO(r8-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts (owned by R8-A).
// R8-D: computer-use screenshot tool — wraps the optional `screenshot-desktop`
// npm package via dynamic `import()` so the dep stays optional and the bundle
// doesn't grow when computer-use is disabled.

import type { ToolSpec } from "@oati/shared";

interface ScreenshotRegion {
	readonly x: number;
	readonly y: number;
	readonly width: number;
	readonly height: number;
}

interface ScreenshotArgs {
	readonly region?: ScreenshotRegion;
	readonly displayId?: number;
}

interface ScreenshotResult {
	readonly dataUrl: string;
	readonly width?: number;
	readonly height?: number;
	readonly displayId?: number;
}

function isRegion(v: unknown): v is ScreenshotRegion {
	if (typeof v !== "object" || v === null) return false;
	const r = v as ScreenshotRegion;
	return (
		typeof r.x === "number" &&
		typeof r.y === "number" &&
		typeof r.width === "number" &&
		typeof r.height === "number" &&
		r.width > 0 &&
		r.height > 0
	);
}

function isScreenshotArgs(v: unknown): v is ScreenshotArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as ScreenshotArgs;
	if (a.region !== undefined && !isRegion(a.region)) return false;
	if (a.displayId !== undefined && typeof a.displayId !== "number") return false;
	return true;
}

/**
 * Shape of the `screenshot-desktop` module we actually use. We accept either
 * the CJS-style default-export-as-function or an ESM namespace whose `default`
 * is the function — different bundlers and Node versions surface either shape.
 */
interface ScreenshotDesktopMod {
	(opts?: { format?: string; screen?: number }): Promise<Buffer>;
	listDisplays?: () => Promise<readonly { id: number; name?: string }[]>;
}

interface ScreenshotDesktopImportShape {
	default?: ScreenshotDesktopMod;
}

/**
 * Resolve the optional `screenshot-desktop` module. Exported for tests so
 * they can swap in a stub without touching the global module cache.
 */
export type ScreenshotImporter = () => Promise<ScreenshotDesktopMod>;

let importerOverride: ScreenshotImporter | undefined;

/** Test-only: swap in a fake importer. Pass `undefined` to restore the default. */
export function __setScreenshotImporter(fn: ScreenshotImporter | undefined): void {
	importerOverride = fn;
}

async function defaultImporter(): Promise<ScreenshotDesktopMod> {
	// @ts-expect-error optional dep — no types shipped, resolved dynamically.
	const mod = (await import("screenshot-desktop")) as unknown as
		| ScreenshotDesktopMod
		| ScreenshotDesktopImportShape;
	if (typeof mod === "function") return mod;
	if (typeof (mod as ScreenshotDesktopImportShape).default === "function") {
		return (mod as ScreenshotDesktopImportShape).default as ScreenshotDesktopMod;
	}
	throw new Error("screenshot-desktop module shape unexpected");
}

async function loadScreenshotMod(): Promise<ScreenshotDesktopMod> {
	const importer = importerOverride ?? defaultImporter;
	try {
		return await importer();
	} catch (err) {
		const msg = err instanceof Error ? err.message : String(err);
		throw new Error(
			`screenshot: optional dependency \`screenshot-desktop\` is not installed (${msg}). Install screenshot-desktop to enable computer-use screenshots.`,
		);
	}
}

/** Crop a PNG buffer to the requested region using a pure-JS PNG decoder/encoder. */
async function cropPng(buf: Buffer, region: ScreenshotRegion): Promise<Buffer> {
	// We deliberately avoid bringing in sharp/jimp — `pngjs` is tiny and pure JS.
	// If it's not installed either, fall back to returning the full image rather
	// than failing the whole tool call.
	let PngCtor: unknown;
	try {
		// @ts-expect-error optional dep — pngjs is loaded dynamically.
		const mod = await import("pngjs");
		PngCtor = (mod as { PNG?: unknown }).PNG ?? (mod as { default?: { PNG?: unknown } }).default?.PNG;
	} catch {
		return buf;
	}
	if (typeof PngCtor !== "function") return buf;
	const PNG = PngCtor as new (opts: { width?: number; height?: number }) => {
		width: number;
		height: number;
		data: Buffer;
		parse(
			b: Buffer,
			cb: (err: Error | null, png: { width: number; height: number; data: Buffer }) => void,
		): void;
		pack(): { read(): Buffer };
	};
	return await new Promise<Buffer>((resolve, reject) => {
		const reader = new PNG({});
		reader.parse(buf, (err, src) => {
			if (err) return reject(err);
			const x = Math.max(0, Math.floor(region.x));
			const y = Math.max(0, Math.floor(region.y));
			const w = Math.max(1, Math.min(Math.floor(region.width), src.width - x));
			const h = Math.max(1, Math.min(Math.floor(region.height), src.height - y));
			const out = new PNG({ width: w, height: h });
			for (let row = 0; row < h; row++) {
				const srcOff = ((y + row) * src.width + x) * 4;
				const dstOff = row * w * 4;
				src.data.copy(out.data, dstOff, srcOff, srcOff + w * 4);
			}
			const chunks: Buffer[] = [];
			const stream = out.pack();
			(stream as unknown as NodeJS.ReadableStream).on("data", (c: Buffer) => chunks.push(c));
			(stream as unknown as NodeJS.ReadableStream).on("end", () => resolve(Buffer.concat(chunks)));
			(stream as unknown as NodeJS.ReadableStream).on("error", (e: Error) => reject(e));
		});
	});
}

export const screenshotTool: ToolSpec<ScreenshotArgs, ScreenshotResult> = {
	name: "screenshot",
	description:
		"Capture a PNG screenshot of the user's desktop (or a sub-region / specific display) and return it as a base64 data URL. " +
		"Requires the optional `screenshot-desktop` dependency. Approval-gated; off by default unless `oati.computerUse.enabled` is set.",
	schema: {
		type: "object",
		properties: {
			region: {
				type: "object",
				description: "Optional sub-region to capture: { x, y, width, height } in screen pixels.",
			},
			displayId: {
				type: "integer",
				description: "Optional numeric display id (from `listDisplays`). Default: primary.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args): Promise<ScreenshotResult> {
		if (!isScreenshotArgs(args)) throw new Error("screenshot: invalid args");
		const mod = await loadScreenshotMod();
		const opts: { format: string; screen?: number } = { format: "png" };
		if (args.displayId !== undefined) opts.screen = args.displayId;
		let buf = await mod(opts);
		if (args.region) {
			buf = await cropPng(buf, args.region);
		}
		const b64 = buf.toString("base64");
		return {
			dataUrl: `data:image/png;base64,${b64}`,
			displayId: args.displayId,
		};
	},
};
