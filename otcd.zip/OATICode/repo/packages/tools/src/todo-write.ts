// `todo_write` — agent-managed task list. The model calls this whenever it
// wants to plan a multi-step task or update progress on one. The full list
// is replaced on every call (idempotent, easy to reason about); the host
// persists the snapshot per-session and forwards it to the webview which
// renders a checklist panel above the chat.
//
// This is the OATI Code equivalent of Claude's TodoWrite tool — the single
// biggest UX win for long agent runs because the user always knows what
// the agent is working on and what's left.

import type { ToolSpec, UiTodoItem } from "@oati/shared";

interface TodoWriteArgs {
	readonly todos: readonly UiTodoItem[];
}

const VALID_STATUS = new Set(["pending", "in_progress", "completed"]);

function isTodoItem(v: unknown): v is UiTodoItem {
	if (typeof v !== "object" || v === null) return false;
	const t = v as Record<string, unknown>;
	if (typeof t.content !== "string" || t.content.trim().length === 0) return false;
	if (typeof t.status !== "string" || !VALID_STATUS.has(t.status)) return false;
	if (t.activeForm !== undefined && typeof t.activeForm !== "string") return false;
	return true;
}

function isTodoWriteArgs(v: unknown): v is TodoWriteArgs {
	if (typeof v !== "object" || v === null) return false;
	const t = v as Record<string, unknown>;
	if (!Array.isArray(t.todos)) return false;
	return t.todos.every(isTodoItem);
}

// Description-policy reference:
// - Full list is REPLACED on every call — include every item (pending,
//   in_progress, completed).
// - Exactly ONE item should be in_progress at a time.
// - Each item: { content: string, activeForm?: string,
//   status: 'pending'|'in_progress'|'completed' }.
// - User sees the list as a checklist panel above the chat.
export const todoWriteTool: ToolSpec = {
	name: "todo_write",
	description:
		"Create or replace the agent's task list. Use for multi-step tasks. Include EVERY item every call; exactly ONE should be `in_progress`.",
	schema: {
		type: "object",
		properties: {
			todos: {
				type: "array",
				description:
					"Full list of todos. Each item: { content: string (imperative, e.g. 'Run tests'), activeForm?: string (present-continuous, e.g. 'Running tests'), status: 'pending' | 'in_progress' | 'completed' }. Include EVERY item every call. Exactly one item should be 'in_progress' at a time.",
				items: { type: "object" },
			},
		},
		required: ["todos"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isTodoWriteArgs(args)) {
			throw new Error("todo_write: invalid args, expected { todos: TodoItem[] }");
		}
		if (!ctx.updateTodos) {
			return {
				ok: false,
				message:
					"todo_write: this host does not support agent-managed todos. The list was not persisted.",
				count: args.todos.length,
			};
		}
		ctx.updateTodos(args.todos);
		const inProgress = args.todos.filter((t) => t.status === "in_progress").length;
		const done = args.todos.filter((t) => t.status === "completed").length;
		const pending = args.todos.filter((t) => t.status === "pending").length;
		return {
			ok: true,
			counts: { total: args.todos.length, inProgress, done, pending },
		};
	},
};
