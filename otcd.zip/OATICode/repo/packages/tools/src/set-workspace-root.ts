// `set_workspace_root` — let the model change the project root that
// relative-path tools resolve against. Useful when the user says "set the
// project path to E:\proj" — the model invokes this tool and subsequent
// `read_file("index.html")` calls land in the right folder.
//
// The host MUST validate the new path exists on disk before accepting it.
// If validation fails the tool result carries the failure message so the
// model can ask the user to clarify.
import type { ToolSpec } from "@oati/shared";

interface SetWorkspaceRootArgs {
	readonly path: string;
}

function isSetWorkspaceRootArgs(v: unknown): v is SetWorkspaceRootArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SetWorkspaceRootArgs;
	return typeof a.path === "string" && a.path.trim().length > 0;
}

export const setWorkspaceRootTool: ToolSpec = {
	name: "set_workspace_root",
	description:
		'Change the workspace / project root that relative-path tools resolve against. Use this when the user explicitly asks to switch the project folder (e.g. "set the project path to E:\\proj" or "work on the repo at /home/me/other"). Returns the absolute path that was set. Errors when the path doesn\'t exist on disk — the model should then ask the user to confirm the correct path.',
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description:
					"Absolute path to the new workspace root. Examples: `E:\\\\OATICode1\\\\OATICode`, `/Users/me/repos/foo`. Relative paths are resolved against the current root.",
			},
		},
		required: ["path"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isSetWorkspaceRootArgs(args)) {
			throw new Error("set_workspace_root: invalid args, expected { path: string }");
		}
		if (!ctx.setWorkspaceRoot) {
			return {
				ok: false,
				message:
					"set_workspace_root: this host does not support changing the workspace root from chat. Ask the user to open the desired folder in their IDE instead.",
			};
		}
		try {
			const resolved = await ctx.setWorkspaceRoot(args.path);
			return { ok: true, workspaceRoot: resolved };
		} catch (err) {
			return {
				ok: false,
				message: err instanceof Error ? err.message : `set_workspace_root failed: ${String(err)}`,
			};
		}
	},
};
