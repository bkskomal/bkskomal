import type { ToolSpec } from "@oati/shared";

interface RememberFactArgs {
	readonly fact: string;
	readonly source?: string;
}

function isRememberFactArgs(v: unknown): v is RememberFactArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as RememberFactArgs;
	if (typeof a.fact !== "string" || a.fact.trim().length === 0) return false;
	if (a.source !== undefined && typeof a.source !== "string") return false;
	return true;
}

export const rememberFactTool: ToolSpec = {
	name: "remember_fact",
	description:
		"Persist a fact about this project to `<workspace>/.oati/facts.json` so it carries across sessions. Use for stable knowledge: naming conventions, file locations, project rules. Idempotent — duplicate facts (case-insensitive) are silently skipped.",
	schema: {
		type: "object",
		properties: {
			fact: {
				type: "string",
				description: "The fact text to remember. Should be a single short sentence.",
			},
			source: {
				type: "string",
				description: "Optional source tag (e.g. 'agent', 'user'). Defaults to 'agent'.",
			},
		},
		required: ["fact"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<string> {
		if (!isRememberFactArgs(args)) throw new Error("remember_fact: invalid args");
		if (!ctx.addFact) {
			throw new Error(
				"remember_fact: persistent facts are not enabled in this host (no addFact wired).",
			);
		}
		const before = ctx.loadFacts ? await ctx.loadFacts() : [];
		const after = await ctx.addFact({ fact: args.fact, source: args.source });
		const added = after.length > before.length;
		return added
			? `Remembered: ${args.fact.trim()} (now ${after.length} fact${after.length === 1 ? "" : "s"})`
			: `Already known — skipped duplicate fact (still ${after.length} fact${after.length === 1 ? "" : "s"})`;
	},
};
