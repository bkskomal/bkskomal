import type { ToolSpec } from "@oati/shared";

interface SuggestProjectMemoryArgs {
	readonly fact: string;
	readonly rationale?: string;
}

function isSuggestProjectMemoryArgs(v: unknown): v is SuggestProjectMemoryArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SuggestProjectMemoryArgs;
	if (typeof a.fact !== "string" || a.fact.trim().length === 0) return false;
	if (a.rationale !== undefined && typeof a.rationale !== "string") return false;
	return true;
}

/**
 * 2026-06-03: agent-side suggest tool for project memory. Called when
 * the model notices something durable about the project that future
 * sessions would benefit from knowing — a non-obvious convention, a
 * gotcha it just discovered, a port number it had to negotiate, etc.
 *
 * The tool APPENDS the suggestion to OATI.md under a "Suggested
 * additions — <date>" header. The user reviews on next file open and
 * either keeps, moves into the right section, or deletes. We don't
 * ask permission at suggestion-time because the cost of a wrong
 * suggestion is "user deletes a line"; the cost of a missed
 * suggestion is "agent re-learns the same thing every session."
 *
 * Designed to be cheap and frequent — the model should err on the
 * side of suggesting rather than holding back. The Suggested-additions
 * section format makes review trivial.
 */
export const suggestProjectMemoryAdditionTool: ToolSpec = {
	name: "suggest_project_memory_addition",
	description:
		"Propose adding a durable fact to the project's OATI.md memory file (Claude-Code-style persistent context). Use when you've discovered something about this project that future sessions should know: a non-obvious convention, a port-conflict workaround, a 'this looks weird but it's intentional' moment. The fact gets appended under a 'Suggested additions' header for the user to review on next file open. Be specific — name files, ports, commands. Lean toward suggesting too often rather than missing what'll matter next session.",
	schema: {
		type: "object",
		properties: {
			fact: {
				type: "string",
				description:
					"The fact to add, written so a fresh session 2 weeks from now can act on it. Include concrete identifiers (file paths, port numbers, command flags). 1-3 sentences, no preamble.",
			},
			rationale: {
				type: "string",
				description:
					"Optional one-line note about WHY this is worth persisting — e.g. 'the agent re-discovered this in turn 12 because the user had moved the Docker setup'.",
			},
		},
		required: ["fact"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<string> {
		if (!isSuggestProjectMemoryArgs(args)) {
			throw new Error(
				"suggest_project_memory_addition: invalid args (need { fact: string, rationale?: string })",
			);
		}
		if (!ctx.appendToProjectMemory) {
			return "(project memory is not enabled in this host — no OATI.md location to append to)";
		}
		const trimmed = args.fact.trim();
		const block = args.rationale
			? `- ${trimmed}\n  _Rationale:_ ${args.rationale.trim()}`
			: `- ${trimmed}`;
		try {
			const result = await ctx.appendToProjectMemory(block, "agent");
			return `Suggested addition appended to ${result.path} (under today's "Suggested additions" header). User will review on next open.`;
		} catch (err) {
			return `Could not append suggestion: ${err instanceof Error ? err.message : String(err)}`;
		}
	},
};
