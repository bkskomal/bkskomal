import type { ToolSpec } from "@oati/shared";

interface ReadSessionArchiveArgs {
	readonly query?: string;
	readonly maxLines?: number;
}

function isReadSessionArchiveArgs(v: unknown): v is ReadSessionArchiveArgs {
	if (v === undefined || v === null) return true;
	if (typeof v !== "object") return false;
	const a = v as ReadSessionArchiveArgs;
	if (a.query !== undefined && typeof a.query !== "string") return false;
	if (a.maxLines !== undefined && typeof a.maxLines !== "number") return false;
	return true;
}

/**
 * 2026-06-03: read back the per-session archive that the agent's
 * predictive auto-compact writes when it drops the middle of history.
 *
 * Story: when the model needs detail that "got compacted away" — e.g.,
 * "what was the exact error from that test run 30 turns ago?" — the
 * in-memory summary alone is too coarse. The archive on disk keeps the
 * full transcript of every compacted segment. This tool searches it,
 * returns matching lines (with surrounding context) so the model can
 * recover specifics without forcing the user to re-explain.
 *
 * Storage: written by the host at `<workspace>/.oati/sessions/<sessionId>/
 * archive.md`. Each compact append a `## Compacted segment — <iso>`
 * heading + summary + full transcript.
 */
export const readSessionArchiveTool: ToolSpec = {
	name: "read_session_archive",
	description:
		"Search this session's compacted-history archive for content the model needs to remember but no longer sees in chat. When the predictive auto-compact dropped the middle of history, it saved the full transcript to disk; this tool searches it. Pass `query` to filter by case-insensitive substring; omit to return the full archive (capped by `maxLines`).",
	schema: {
		type: "object",
		properties: {
			query: {
				type: "string",
				description:
					"Optional substring filter (case-insensitive). Returns lines that match plus 2 lines of surrounding context. Omit to return the archive head.",
			},
			maxLines: {
				type: "number",
				description: "Cap on returned lines (default 200; max 800).",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx, callCtx): Promise<string> {
		if (!isReadSessionArchiveArgs(args)) throw new Error("read_session_archive: invalid args");
		if (!ctx.readSessionArchive) {
			return "(session archive is not enabled in this host)";
		}
		const sessionId = callCtx?.agentId;
		if (!sessionId) {
			return "(no active session id — archive lookup needs a session context)";
		}
		const archive = await ctx.readSessionArchive(sessionId);
		if (!archive || archive.length === 0) {
			return "(no archive yet — the predictive auto-compact hasn't fired this session)";
		}
		const cap = Math.max(1, Math.min(800, args?.maxLines ?? 200));
		const q = args?.query?.trim().toLowerCase();
		const lines = archive.split("\n");
		if (!q) {
			const head = lines.slice(0, cap);
			const more =
				lines.length > cap ? `\n\n[... ${lines.length - cap} more lines; pass a query to search]` : "";
			return `${head.join("\n")}${more}`;
		}
		// Substring search with ±2-line context, dedup overlapping windows.
		const hits = new Set<number>();
		for (let i = 0; i < lines.length; i++) {
			if (lines[i].toLowerCase().includes(q)) {
				for (let j = Math.max(0, i - 2); j <= Math.min(lines.length - 1, i + 2); j++) {
					hits.add(j);
				}
			}
		}
		if (hits.size === 0) return `(no matches for "${q}" in archive of ${lines.length} lines)`;
		const sorted = [...hits].sort((a, b) => a - b);
		const capped = sorted.slice(0, cap);
		const out: string[] = [];
		let last = -2;
		for (const idx of capped) {
			if (idx !== last + 1) out.push(`--- L${idx + 1} ---`);
			out.push(lines[idx]);
			last = idx;
		}
		const truncated =
			sorted.length > cap ? `\n\n[... ${sorted.length - cap} more matching lines truncated]` : "";
		return `Found ${sorted.length} matching lines (showing ${capped.length}):\n\n${out.join("\n")}${truncated}`;
	},
};
