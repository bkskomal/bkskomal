// TODO(r8-merge): R8-D internal helper — not a ToolSpec; not registered.
// R8-D: shared dynamic loader for `@nut-tree-fork/nut-js`. Centralized so the
// mouse/keyboard tools share the same friendly fallback message and so tests
// can swap a single import seam.

/**
 * Minimal subset of `@nut-tree-fork/nut-js` we actually call. Typed loosely
 * so we don't take a hard compile-time dep on the optional package.
 */
export interface NutJsApi {
	readonly mouse: {
		setPosition(pt: { x: number; y: number }): Promise<unknown> | unknown;
		leftClick(): Promise<unknown> | unknown;
		rightClick(): Promise<unknown> | unknown;
		click?(btn: unknown): Promise<unknown> | unknown;
		doubleClick?(btn: unknown): Promise<unknown> | unknown;
		pressButton?(btn: unknown): Promise<unknown> | unknown;
		releaseButton?(btn: unknown): Promise<unknown> | unknown;
	};
	readonly keyboard: {
		type(...args: unknown[]): Promise<unknown> | unknown;
		pressKey(...keys: unknown[]): Promise<unknown> | unknown;
		releaseKey(...keys: unknown[]): Promise<unknown> | unknown;
		config?: { autoDelayMs?: number };
	};
	readonly Button: { LEFT: unknown; RIGHT: unknown; MIDDLE: unknown };
	readonly Key: Readonly<Record<string, unknown>>;
	readonly Point: new (x: number, y: number) => { x: number; y: number };
}

export type NutImporter = () => Promise<NutJsApi>;

let importerOverride: NutImporter | undefined;

/** Test-only: swap in a fake importer. Pass `undefined` to restore the default. */
export function __setNutImporter(fn: NutImporter | undefined): void {
	importerOverride = fn;
}

async function defaultImporter(): Promise<NutJsApi> {
	// `@nut-tree-fork/nut-js` is an optionalDependency — runtime import is fine,
	// but type resolution fails when the package isn't installed in `node_modules`.
	// Suppress the TS error; the dynamic import either succeeds at runtime or
	// throws, in which case the caller surfaces a friendly "install nut-js" error.
	// @ts-ignore - optional dependency, not installed by default
	const mod = (await import("@nut-tree-fork/nut-js")) as unknown as NutJsApi & {
		default?: NutJsApi;
	};
	if (mod && (mod.mouse || mod.keyboard)) return mod;
	if (mod?.default) return mod.default;
	throw new Error("@nut-tree-fork/nut-js module shape unexpected");
}

export async function loadNutJs(): Promise<NutJsApi> {
	const importer = importerOverride ?? defaultImporter;
	try {
		return await importer();
	} catch (err) {
		const msg = err instanceof Error ? err.message : String(err);
		throw new Error(
			`computer-use: optional dependency \`@nut-tree-fork/nut-js\` is not installed (${msg}). Install @nut-tree-fork/nut-js to enable mouse/keyboard control.`,
		);
	}
}

/**
 * Map a VS Code-style key name (e.g. "cmd+s", "ctrl+shift+p", "Enter") into a
 * `{modifiers, key}` pair where `modifiers` are nut-js `Key.LeftCtrl` etc and
 * `key` is the final non-modifier nut-js Key constant. Throws if the trailing
 * key isn't recognized.
 */
export function resolveKeyChord(
	api: NutJsApi,
	combo: string,
	extraModifiers?: readonly string[],
): { modifiers: unknown[]; key: unknown; keyName: string } {
	const tokens = combo
		.split("+")
		.map((t) => t.trim())
		.filter((t) => t.length > 0);
	for (const m of extraModifiers ?? []) {
		if (m && !tokens.includes(m)) tokens.unshift(m);
	}
	if (tokens.length === 0) throw new Error("key_press: empty key");
	const mods: unknown[] = [];
	let final: { name: string; key: unknown } | null = null;
	for (const raw of tokens) {
		const norm = raw.toLowerCase();
		const modKey = resolveModifier(api, norm);
		if (modKey !== null) {
			mods.push(modKey);
			continue;
		}
		final = { name: raw, key: resolveLiteralKey(api, raw) };
	}
	if (!final) throw new Error(`key_press: no non-modifier key in "${combo}"`);
	return { modifiers: mods, key: final.key, keyName: final.name };
}

function resolveModifier(api: NutJsApi, lower: string): unknown | null {
	const K = api.Key;
	switch (lower) {
		case "ctrl":
		case "control":
			return K.LeftControl ?? K.LeftCtrl ?? K.Control;
		case "shift":
			return K.LeftShift ?? K.Shift;
		case "alt":
		case "option":
			return K.LeftAlt ?? K.Alt;
		case "cmd":
		case "meta":
		case "win":
		case "super":
			return K.LeftSuper ?? K.LeftWin ?? K.LeftMeta ?? K.LeftCmd ?? K.Meta;
		default:
			return null;
	}
}

function resolveLiteralKey(api: NutJsApi, raw: string): unknown {
	const K = api.Key;
	// Try literal capitalization (nut-js uses PascalCase: Key.A, Key.Enter, ...).
	const cap = raw.length === 1 ? raw.toUpperCase() : raw[0].toUpperCase() + raw.slice(1);
	if (cap in K) return K[cap as keyof typeof K];
	// Try common aliases.
	const upper = raw.toUpperCase();
	const aliases: Record<string, string[]> = {
		ESC: ["Escape"],
		ENTER: ["Return", "Enter"],
		RETURN: ["Return", "Enter"],
		SPACE: ["Space"],
		TAB: ["Tab"],
		BACKSPACE: ["Backspace"],
		DEL: ["Delete"],
		DELETE: ["Delete"],
		UP: ["Up"],
		DOWN: ["Down"],
		LEFT: ["Left"],
		RIGHT: ["Right"],
		HOME: ["Home"],
		END: ["End"],
		PAGEUP: ["PageUp"],
		PAGEDOWN: ["PageDown"],
	};
	for (const candidate of aliases[upper] ?? []) {
		if (candidate in K) return K[candidate as keyof typeof K];
	}
	throw new Error(`key_press: unknown key "${raw}"`);
}
