import type { ToolSpec } from "@oati/shared";

interface WebSearchArgs {
	readonly query: string;
	readonly maxResults?: number;
}

function isWebSearchArgs(v: unknown): v is WebSearchArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as WebSearchArgs;
	if (typeof a.query !== "string") return false;
	if (a.maxResults !== undefined && typeof a.maxResults !== "number") return false;
	return true;
}

const DEFAULT_MAX_RESULTS = 5;
const HARD_CAP_MAX_RESULTS = 10;
const TIMEOUT_MS = 10_000;

interface SearchResult {
	readonly title: string;
	readonly url: string;
	readonly snippet: string;
}

function decodeEntities(text: string): string {
	return text
		.replace(/&#(\d+);/g, (_m, n: string) => {
			const code = Number.parseInt(n, 10);
			if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return _m;
			try {
				return String.fromCodePoint(code);
			} catch {
				return _m;
			}
		})
		.replace(/&amp;/g, "&")
		.replace(/&lt;/g, "<")
		.replace(/&gt;/g, ">")
		.replace(/&quot;/g, '"')
		.replace(/&#39;/g, "'")
		.replace(/&nbsp;/g, " ");
}

function stripTags(html: string): string {
	return html.replace(/<[^>]*>/g, "");
}

function clean(raw: string): string {
	return decodeEntities(stripTags(raw)).replace(/\s+/g, " ").trim();
}

/**
 * DuckDuckGo's HTML endpoint wraps real URLs in a `/l/?uddg=<encoded>&...` redirect.
 * Unwrap when present so the tool returns the actual destination URL.
 */
function unwrapDdgUrl(href: string): string {
	try {
		// Handle protocol-relative or absolute hrefs
		const abs = href.startsWith("//") ? `https:${href}` : href;
		const u = new URL(abs, "https://html.duckduckgo.com");
		if (u.pathname === "/l/" || u.pathname.endsWith("/l/")) {
			const target = u.searchParams.get("uddg");
			if (target) return decodeURIComponent(target);
		}
		return u.toString();
	} catch {
		return href;
	}
}

export function parseDuckDuckGoHtml(html: string, limit: number): SearchResult[] {
	const results: SearchResult[] = [];
	// Capture the `<a class="result__a" href="...">title</a>` block followed eventually by `<a class="result__snippet">...</a>`.
	// Use individual regexes for title/url and for snippets, then zip by position.
	const titleRegex =
		/<a[^>]*class="[^"]*\bresult__a\b[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
	const snippetRegex = /<a[^>]*class="[^"]*\bresult__snippet\b[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;

	const titleMatches: { url: string; title: string }[] = [];
	let m: RegExpExecArray | null;
	// biome-ignore lint/suspicious/noAssignInExpressions: standard regex.exec loop
	while ((m = titleRegex.exec(html)) !== null) {
		const url = unwrapDdgUrl(m[1]);
		const title = clean(m[2]);
		if (title && url) titleMatches.push({ url, title });
	}

	const snippetMatches: string[] = [];
	// biome-ignore lint/suspicious/noAssignInExpressions: standard regex.exec loop
	while ((m = snippetRegex.exec(html)) !== null) {
		snippetMatches.push(clean(m[1]));
	}

	const n = Math.min(titleMatches.length, limit);
	for (let i = 0; i < n; i++) {
		results.push({
			title: titleMatches[i].title,
			url: titleMatches[i].url,
			snippet: snippetMatches[i] ?? "",
		});
	}
	return results;
}

function formatResults(query: string, results: readonly SearchResult[]): string {
	if (results.length === 0) {
		return `No results found for "${query}".`;
	}
	const blocks = results.map((r, i) =>
		`${i + 1}. ${r.title}\n   ${r.url}\n   ${r.snippet}`.trimEnd(),
	);
	return blocks.join("\n\n");
}

export const webSearchTool: ToolSpec = {
	name: "web_search",
	description:
		"Search the web via DuckDuckGo's HTML endpoint and return ranked results (title, URL, snippet). No API key required. Use for fresh facts, docs, and quick lookups.",
	schema: {
		type: "object",
		properties: {
			query: { type: "string", description: "Search query." },
			maxResults: {
				type: "integer",
				description: `Number of results to return. Default ${DEFAULT_MAX_RESULTS}, hard cap ${HARD_CAP_MAX_RESULTS}.`,
			},
		},
		required: ["query"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args): Promise<string> {
		if (!isWebSearchArgs(args)) throw new Error("web_search: invalid args");

		const requested = args.maxResults ?? DEFAULT_MAX_RESULTS;
		const limit = Math.max(1, Math.min(Math.floor(requested), HARD_CAP_MAX_RESULTS));
		const encoded = encodeURIComponent(args.query);
		const url = `https://html.duckduckgo.com/html/?q=${encoded}`;

		const ctrl = new AbortController();
		const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);

		try {
			const response = await fetch(url, {
				method: "GET",
				signal: ctrl.signal,
				redirect: "follow",
				headers: {
					// DuckDuckGo's HTML endpoint expects a normal browser-ish UA.
					"User-Agent": "Mozilla/5.0 (compatible; OATI-Coding-Assistant/1.0; +https://github.com/)",
					Accept: "text/html,application/xhtml+xml",
				},
			});
			const html = await response.text();
			const results = parseDuckDuckGoHtml(html, limit);
			return formatResults(args.query, results);
		} catch (err) {
			if (err instanceof Error && err.name === "AbortError") {
				throw new Error("web_search: request timed out");
			}
			throw new Error(`web_search: ${err instanceof Error ? err.message : String(err)}`);
		} finally {
			clearTimeout(timer);
		}
	},
};
