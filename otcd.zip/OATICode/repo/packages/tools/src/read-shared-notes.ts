import type { ScratchpadNote, ToolSpec } from "@oati/shared";

/**
 * Sub-agent-only tool: read all notes from the per-parent-run shared scratchpad.
 * Pairs with `write_shared_note`. Returns the notes in insertion order so a
 * sub-agent can see what siblings have surfaced so far.
 */
export const readSharedNotesTool: ToolSpec = {
	name: "read_shared_notes",
	description:
		"Read all notes from the shared scratchpad for this sub-agent batch (notes written by your siblings via write_shared_note). Returns the notes in the order they were written.",
	schema: {
		type: "object",
		properties: {},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	scope: "sub-agent",
	async handler(_args, ctx): Promise<string> {
		if (!ctx.scratchpadRead) {
			throw new Error("read_shared_notes: shared scratchpad is not available in this host.");
		}
		const notes: readonly ScratchpadNote[] = ctx.scratchpadRead("");
		if (notes.length === 0) return "(no shared notes yet)";
		const lines = notes.map((n, i) => `${i + 1}. ${n.note}  [${n.author} @ ${n.at}]`);
		return `${notes.length} shared note${notes.length === 1 ? "" : "s"}:\n${lines.join("\n")}`;
	},
};
