// R8-C: resolve_context_mention — agent-facing tool that resolves a single
// `@`-mention against the host's context-provider registry. Lets the model
// fetch context on demand (e.g. "pull the current diagnostics, then propose a
// fix") without the user having to type the mention into the composer.
//
// Approval: "auto" — context providers themselves do their own gating
// (`@docs` truncates fetched bodies, `@git-diff` rejects shell-meta args, …)
// so the wrapper here intentionally doesn't double-prompt.
//
// TODO(r8-merge): wire into `tools/src/registry.ts` (R8-A owns registration).
import type { ToolSpec } from "@oati/shared";

interface ResolveContextMentionArgs {
	readonly mention: string;
	readonly arg?: string;
}

function isResolveArgs(v: unknown): v is ResolveContextMentionArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as ResolveContextMentionArgs;
	if (typeof a.mention !== "string") return false;
	if (a.arg !== undefined && typeof a.arg !== "string") return false;
	return true;
}

export const resolveContextMentionTool: ToolSpec<ResolveContextMentionArgs, string> = {
	name: "resolve_context_mention",
	description:
		"Resolve a pluggable `@`-mention (e.g. `@problems`, `@docs`, `@git-diff`) against the host's context-provider registry and return the resulting markdown block. Use this when you need a fresh snapshot of something the user's composer would otherwise inline (diagnostics, terminal tail, git diff, web search, …). The mention may be either the bare id (`problems`) or the literal token (`@problems`); inline arguments after `:` are honored (`docs:https://example.com`). Pass `arg` separately when it's more convenient.",
	schema: {
		type: "object",
		properties: {
			mention: {
				type: "string",
				description:
					"The provider mention to resolve. Accepts `problems`, `@problems`, or `docs:https://…`.",
			},
			arg: {
				type: "string",
				description:
					"Optional argument the provider expects (e.g. a file filter for `@problems`, a URL for `@docs`). Ignored when the mention already includes one after `:`.",
			},
		},
		required: ["mention"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<string> {
		if (!isResolveArgs(args)) {
			throw new Error(
				"resolve_context_mention: invalid args — expected { mention: string; arg?: string }",
			);
		}
		const bridge = ctx.contextProviders;
		if (!bridge) {
			return "resolve_context_mention: no context-provider registry attached to this host.";
		}
		try {
			return await bridge.resolve(args.mention, args.arg);
		} catch (err) {
			const known = bridge
				.list()
				.map((p) => p.mention)
				.join(", ");
			const msg = err instanceof Error ? err.message : String(err);
			return `resolve_context_mention failed: ${msg}\nKnown mentions: ${known || "(none)"}`;
		}
	},
};
