// TODO(r8-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
// R8-E: multi_cursor_edit — apply the same insertion at N cursor positions in
// a single file. Mirrors VS Code's multi-cursor primitive: every position
// receives the same `insert` string atomically (one undo step). When wired
// from the extension-host, the inserts can flow through
// `vscode.WorkspaceEdit.insert` in a single `applyEdit` call so the IDE
// batches them; in the meantime we model the same semantics by computing
// offsets in-buffer, applying right-to-left, and writing the merged content
// back through the host's normal `writeFile` (which surfaces a diff preview).

import type { ToolSpec } from "@oati/shared";

interface CursorPosition {
	readonly line: number;
	readonly column: number;
}

interface MultiCursorEditArgs {
	readonly path: string;
	readonly positions: readonly CursorPosition[];
	readonly insert: string;
}

interface MultiCursorEditResult {
	readonly applied: number;
	readonly path: string;
	readonly skipped: readonly { readonly index: number; readonly reason: string }[];
}

function isPosition(v: unknown): v is CursorPosition {
	if (typeof v !== "object" || v === null) return false;
	const p = v as CursorPosition;
	return (
		typeof p.line === "number" &&
		Number.isFinite(p.line) &&
		p.line >= 0 &&
		typeof p.column === "number" &&
		Number.isFinite(p.column) &&
		p.column >= 0
	);
}

function isMultiCursorEditArgs(v: unknown): v is MultiCursorEditArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as MultiCursorEditArgs;
	return (
		typeof a.path === "string" &&
		Array.isArray(a.positions) &&
		a.positions.every(isPosition) &&
		typeof a.insert === "string"
	);
}

/**
 * Convert (line, column) → absolute character offset. Returns `undefined`
 * when the position is past the end of the buffer so the caller can skip it
 * rather than truncate. Lines and columns are 0-based to match VS Code's
 * `Position` API.
 */
function offsetFor(text: string, pos: CursorPosition): number | undefined {
	let offset = 0;
	let line = 0;
	while (line < pos.line) {
		const next = text.indexOf("\n", offset);
		if (next < 0) return undefined;
		offset = next + 1;
		line++;
	}
	const lineEnd = (() => {
		const next = text.indexOf("\n", offset);
		return next < 0 ? text.length : next;
	})();
	const col = Math.min(pos.column, lineEnd - offset);
	if (col < 0) return undefined;
	return offset + col;
}

/**
 * Build the post-edit buffer + a list of skipped positions. We sort the
 * positions by offset descending so each insert leaves the remaining offsets
 * valid — the trick VS Code uses internally when batching
 * `WorkspaceEdit.insert` calls.
 */
export function applyMultiCursorInsert(
	original: string,
	positions: readonly CursorPosition[],
	insert: string,
): {
	readonly after: string;
	readonly applied: number;
	readonly skipped: { index: number; reason: string }[];
} {
	const skipped: { index: number; reason: string }[] = [];
	const resolved: { index: number; offset: number }[] = [];
	for (let i = 0; i < positions.length; i++) {
		const off = offsetFor(original, positions[i]);
		if (off === undefined) {
			skipped.push({ index: i, reason: "position past end of file" });
			continue;
		}
		resolved.push({ index: i, offset: off });
	}
	// Apply right-to-left so earlier offsets remain valid as we splice.
	resolved.sort((a, b) => b.offset - a.offset);
	let after = original;
	for (const r of resolved) {
		after = `${after.slice(0, r.offset)}${insert}${after.slice(r.offset)}`;
	}
	return { after, applied: resolved.length, skipped };
}

export const multiCursorEditTool: ToolSpec = {
	name: "multi_cursor_edit",
	description:
		"Insert the same text at N cursor positions in one file, applied atomically (one undo step). Use this when you want to add the same import, the same trailing comma, the same JSDoc tag, etc., at multiple sites without writing N separate `write_file` calls. Positions are 0-based (line, column). Shows a diff preview and requires user approval.",
	schema: {
		type: "object",
		properties: {
			path: { type: "string", description: "Path of the file to edit." },
			positions: {
				type: "array",
				description:
					"List of 0-based (line, column) cursor positions where `insert` should be applied.",
				items: {
					type: "object",
					description: "A single cursor position.",
				},
			},
			insert: { type: "string", description: "Text to insert at every position." },
		},
		required: ["path", "positions", "insert"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args, ctx) {
		if (!isMultiCursorEditArgs(args)) return {};
		const before = (await ctx.fileExists(args.path)) ? await ctx.readFile(args.path) : "";
		const { after } = applyMultiCursorInsert(before, args.positions, args.insert);
		return { diff: { path: args.path, before, after } };
	},
	async handler(args, ctx): Promise<MultiCursorEditResult> {
		if (!isMultiCursorEditArgs(args)) {
			throw new Error(
				"multi_cursor_edit: invalid args, expected { path: string; positions: {line, column}[]; insert: string }",
			);
		}
		if (args.positions.length === 0) {
			return { applied: 0, path: args.path, skipped: [] };
		}
		const before = (await ctx.fileExists(args.path)) ? await ctx.readFile(args.path) : "";
		const { after, applied, skipped } = applyMultiCursorInsert(before, args.positions, args.insert);
		await ctx.writeFile(args.path, after);
		return { applied, path: args.path, skipped };
	},
};
