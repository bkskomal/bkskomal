import type { ToolSpec } from "@oati/shared";

interface ListDirArgs {
	readonly path: string;
	readonly recursive?: boolean;
	readonly max_entries?: number;
}

function isListDirArgs(v: unknown): v is ListDirArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as ListDirArgs;
	if (typeof a.path !== "string") return false;
	if (a.recursive !== undefined && typeof a.recursive !== "boolean") return false;
	if (a.max_entries !== undefined && typeof a.max_entries !== "number") return false;
	return true;
}

interface ListDirResult {
	readonly path: string;
	readonly entries: ReadonlyArray<{ name: string; type: "file" | "directory"; size?: number }>;
	readonly truncated: boolean;
}

const DEFAULT_LIMIT = 500;
const MAX_LIMIT = 2000;

export const listDirTool: ToolSpec = {
	name: "list_dir",
	description:
		"List entries in a directory. Returns file/directory names and types. Optionally recursive (capped to prevent huge dumps).",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description:
					"Directory path, relative to workspace root or absolute. Use '.' for workspace root.",
			},
			recursive: {
				type: "boolean",
				description: "If true, descend into subdirectories. Default false.",
			},
			max_entries: {
				type: "integer",
				description: `Hard cap on returned entries. Default ${DEFAULT_LIMIT}, max ${MAX_LIMIT}.`,
			},
		},
		required: ["path"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<ListDirResult> {
		if (!isListDirArgs(args)) throw new Error("list_dir: invalid args");
		const cap = Math.min(args.max_entries ?? DEFAULT_LIMIT, MAX_LIMIT);

		// Prefer the host's direct readDir capability — it resolves
		// against the host's CURRENT workspace root (including any
		// `set_workspace_root` / `/cwd` override) instead of the sidecar
		// process CWD. This was the root cause of the "list_dir returns
		// random 94 entries" bug: shelling out via `ctx.exec` honored
		// process.cwd(), not the workspace.
		if (ctx.readDir) {
			const result = await ctx.readDir(args.path, {
				recursive: args.recursive,
				maxEntries: cap,
			});
			return {
				path: result.path,
				entries: result.entries,
				truncated: result.truncated,
			};
		}

		// Fallback: shell-out for hosts that don't implement readDir.
		// Same logic as before — kept for backward compatibility with
		// custom HostContext implementations under test.
		const cmd = args.recursive
			? `node -e "const fs=require('fs');const path=require('path');function walk(d,p,out,cap){if(out.length>=cap)return;let es;try{es=fs.readdirSync(d,{withFileTypes:true})}catch{return}for(const e of es){if(out.length>=cap)break;const rel=path.posix.join(p,e.name);out.push({name:rel,type:e.isDirectory()?'directory':'file'});if(e.isDirectory())walk(path.join(d,e.name),rel,out,cap)}}const out=[];walk(process.argv[1],'',out,${cap});console.log(JSON.stringify({entries:out}))" ${quote(args.path)}`
			: `node -e "const fs=require('fs');const es=fs.readdirSync(process.argv[1],{withFileTypes:true}).slice(0,${cap}).map(e=>({name:e.name,type:e.isDirectory()?'directory':'file'}));console.log(JSON.stringify({entries:es}))" ${quote(args.path)}`;

		const res = await ctx.exec(cmd);
		if (res.exitCode !== 0) {
			throw new Error(`list_dir failed: ${res.stderr || res.stdout || `exit ${res.exitCode}`}`);
		}
		try {
			const parsed = JSON.parse(res.stdout) as { entries: ListDirResult["entries"] };
			return {
				path: args.path,
				entries: parsed.entries,
				truncated: parsed.entries.length >= cap,
			};
		} catch (err) {
			throw new Error(
				`list_dir: failed to parse output: ${err instanceof Error ? err.message : String(err)}`,
			);
		}
	},
};

function quote(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}
