import type { ToolSpec } from "@oati/shared";

interface GitOpenPrArgs {
	readonly title: string;
	readonly body: string;
	readonly base?: string;
}

interface GitOpenPrResult {
	readonly ok: boolean;
	readonly url?: string;
	readonly message: string;
	readonly stdout: string;
	readonly stderr: string;
}

function isGitOpenPrArgs(v: unknown): v is GitOpenPrArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as GitOpenPrArgs;
	if (typeof a.title !== "string" || a.title.length === 0) return false;
	if (typeof a.body !== "string") return false;
	if (a.base !== undefined && typeof a.base !== "string") return false;
	return true;
}

function quoteArg(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

/** Best-effort URL extraction from `gh pr create` output. */
function extractPrUrl(stdout: string): string | undefined {
	const m = stdout.match(/https?:\/\/\S+/);
	return m ? m[0] : undefined;
}

export const gitOpenPrTool: ToolSpec = {
	name: "git_open_pr",
	description:
		"Open a GitHub pull request for the current branch using the `gh` CLI. Requires user approval and `gh` installed on PATH.",
	schema: {
		type: "object",
		properties: {
			title: { type: "string", description: "PR title." },
			body: { type: "string", description: "PR description (markdown supported)." },
			base: {
				type: "string",
				description: "Base branch to merge into. Defaults to repo default branch.",
			},
		},
		required: ["title", "body"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isGitOpenPrArgs(args)) return {};
		const lines = [
			`PR title: ${args.title}`,
			args.base ? `Base branch: ${args.base}` : "Base branch: (repo default)",
			`Body (first 200 chars): ${args.body.slice(0, 200)}${args.body.length > 200 ? "…" : ""}`,
		];
		return { note: lines.join("\n") };
	},
	async handler(args, ctx): Promise<GitOpenPrResult> {
		if (!isGitOpenPrArgs(args)) throw new Error("git_open_pr: invalid args");

		// Detect `gh` first so we can surface a friendly install hint instead of a
		// raw "command not found" error coming back through the tool result.
		const probeCmd = process.platform === "win32" ? "where gh" : "command -v gh";
		const probe = await ctx.exec(probeCmd, { timeoutMs: 10_000 });
		if (probe.exitCode !== 0) {
			return {
				ok: false,
				message:
					"GitHub CLI (`gh`) is not installed or not on PATH. Install from https://cli.github.com/ and run `gh auth login`, then retry.",
				stdout: probe.stdout,
				stderr: probe.stderr,
			};
		}

		const parts: string[] = [
			"gh",
			"pr",
			"create",
			"--title",
			quoteArg(args.title),
			"--body",
			quoteArg(args.body),
		];
		if (args.base) {
			parts.push("--base", quoteArg(args.base));
		}
		const res = await ctx.exec(parts.join(" "), { timeoutMs: 60_000 });
		if (res.exitCode !== 0) {
			const stderr = res.stderr.trim();
			// Common "not authenticated" / "no commits to push" failures surface a
			// hint so the user knows what to fix without re-reading raw gh output.
			let hint = "";
			if (/not.*authenticated|gh auth login/i.test(stderr)) {
				hint = " Tip: run `gh auth login` first.";
			} else if (/no commits|no diff/i.test(stderr)) {
				hint = " Tip: commit and push your branch before opening a PR.";
			}
			return {
				ok: false,
				message: `gh pr create failed (exit ${res.exitCode}).${hint}`,
				stdout: res.stdout,
				stderr: res.stderr,
			};
		}
		const url = extractPrUrl(res.stdout);
		return {
			ok: true,
			url,
			message: url ? `Opened PR: ${url}` : "PR created.",
			stdout: res.stdout,
			stderr: res.stderr,
		};
	},
};
