// TODO(r2-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

/**
 * Shared lifecycle singleton for the Puppeteer-backed browser tools.
 *
 * The Round-2 browser tools (`browser_open`, `browser_navigate`,
 * `browser_screenshot`, `browser_eval`, `browser_close`) all share ONE
 * Chrome/Chromium window and ONE page so the agent has a coherent "live
 * preview" of whatever app the user is debugging. Re-opening simply reuses
 * the existing instance.
 *
 * `puppeteer-core` is loaded via dynamic `import()` inside `getOrLaunch()`
 * so the module isn't required at startup — installs that don't want a
 * browser don't pay any cost and don't get a hard error.
 */

// We intentionally keep these `unknown` at the module surface so we can
// avoid a static type-only import of `puppeteer-core` (which would force
// the package to be a hard dep). The tool files cast to local minimal
// interfaces when they need to call methods.
type Browser = {
	close(): Promise<void>;
	newPage(): Promise<Page>;
	pages(): Promise<Page[]>;
	on(event: string, listener: (...args: unknown[]) => void): void;
};

type Response = {
	status(): number;
};

type Page = {
	goto(url: string, opts?: { waitUntil?: string; timeout?: number }): Promise<Response | null>;
	title(): Promise<string>;
	url(): string;
	close(): Promise<void>;
	evaluate<T = unknown>(expression: string): Promise<T>;
	screenshot(opts: {
		encoding: "base64";
		fullPage?: boolean;
		type?: "png" | "jpeg";
		clip?: { x: number; y: number; width: number; height: number };
	}): Promise<string>;
	setViewport(opts: { width: number; height: number }): Promise<void>;
	$(selector: string): Promise<ElementHandle | null>;
};

type ElementHandle = {
	screenshot(opts: { encoding: "base64"; type?: "png" | "jpeg" }): Promise<string>;
};

export type BrowserPage = Page;
export type BrowserElementHandle = ElementHandle;

interface PuppeteerLike {
	launch(opts: {
		headless?: boolean;
		executablePath?: string;
		channel?: string;
		args?: string[];
		defaultViewport?: { width: number; height: number } | null;
	}): Promise<Browser>;
}

interface State {
	browser: Browser;
	page: Page;
}

let state: State | null = null;
let launching: Promise<State> | null = null;

/**
 * Surfaced when puppeteer can't be loaded OR can't find a Chrome/Chromium
 * binary to drive. The error message names the install hint AND lists each
 * launch attempt that failed (when relevant) so the user can see whether
 * the issue is "puppeteer-core missing" vs "Chrome not installed".
 */
export class BrowserUnavailableError extends Error {
	readonly attempts: readonly string[];
	constructor(attempts: readonly string[] = []) {
		const base =
			"Browser tools couldn't launch a Chrome/Chromium window. " +
			"Install `puppeteer-core` if it's missing, or point OATI_CHROME_PATH at a system Chrome/Chromium/Edge binary.";
		const detail =
			attempts.length > 0 ? `\n\nLaunch attempts tried:\n  - ${attempts.join("\n  - ")}` : "";
		super(`${base}${detail}`);
		this.name = "BrowserUnavailableError";
		this.attempts = attempts;
	}
}

async function loadPuppeteer(): Promise<PuppeteerLike> {
	try {
		// Dynamic import so this only runs on first browser-tool use, not at
		// startup. `puppeteer-core` is an optionalDependency that may not be
		// installed; the catch below surfaces a friendly BrowserUnavailableError
		// at runtime when the module truly isn't present. We immediately cast
		// the resolved module through `unknown` to our local `PuppeteerLike`
		// shape so we don't depend on `@types/puppeteer-core` being available.
		const mod = (await import("puppeteer-core")) as unknown as
			| { default: PuppeteerLike }
			| PuppeteerLike;
		const candidate = (mod as { default?: PuppeteerLike }).default ?? (mod as PuppeteerLike);
		if (typeof candidate?.launch !== "function") {
			throw new BrowserUnavailableError();
		}
		return candidate;
	} catch (err) {
		if (err instanceof BrowserUnavailableError) throw err;
		throw new BrowserUnavailableError();
	}
}

/**
 * Returns the live `{ browser, page }` pair, launching a new Chromium via
 * `puppeteer-core` if necessary. Subsequent calls reuse the same window.
 *
 * Launch cascade (first one that works wins):
 *   1. `OATI_CHROME_PATH` env var — explicit override.
 *   2. `channel: "chrome"` — puppeteer-core's built-in OS lookup. Works
 *      for stock Chrome installs on Windows/macOS.
 *   3. Probe well-known install paths for Chrome/Chromium/Edge. Edge is
 *      Chromium under the hood and ships on every modern Windows machine,
 *      so this catches the case where the user has no Chrome but does
 *      have Edge.
 *   4. Throw `BrowserUnavailableError` — the caller (browser_open) catches
 *      and surfaces a URL-only graceful result so the model can still
 *      communicate the URL to the user.
 */
export async function getOrLaunch(): Promise<State> {
	if (state) return state;
	if (launching) return launching;

	launching = (async () => {
		const puppeteer = await loadPuppeteer();
		const launchOpts = {
			headless: false,
			args: ["--no-first-run", "--no-default-browser-check"] as string[],
			defaultViewport: { width: 1280, height: 800 },
		};

		const explicitPath = process.env.OATI_CHROME_PATH;
		const attempts: Array<{ label: string; opts: Record<string, unknown> }> = [];
		if (explicitPath) {
			attempts.push({
				label: `OATI_CHROME_PATH=${explicitPath}`,
				opts: { executablePath: explicitPath },
			});
		} else {
			attempts.push({ label: "channel:chrome", opts: { channel: "chrome" } });
			const probed = discoverChromeExecutablePath();
			if (probed) {
				attempts.push({ label: `probed:${probed}`, opts: { executablePath: probed } });
			}
		}

		const failures: string[] = [];
		let browser: Browser | undefined;
		for (const attempt of attempts) {
			try {
				browser = await puppeteer.launch({ ...launchOpts, ...attempt.opts });
				break;
			} catch (err) {
				failures.push(`${attempt.label}: ${err instanceof Error ? err.message : String(err)}`);
			}
		}

		if (!browser) {
			throw new BrowserUnavailableError(failures);
		}

		// If the user closes the window manually, drop our cached handles.
		browser.on("disconnected", () => {
			state = null;
		});
		const existing = await browser.pages();
		const page = existing[0] ?? (await browser.newPage());
		state = { browser, page };
		return state;
	})();

	try {
		return await launching;
	} finally {
		launching = null;
	}
}

/**
 * Probe well-known install paths for a Chrome/Edge/Chromium binary. Returns
 * the first match or undefined. Exported for tests.
 */
export function discoverChromeExecutablePath(): string | undefined {
	const fs = require("node:fs") as typeof import("node:fs");
	const candidates: string[] = [];
	if (process.platform === "win32") {
		const pf = process.env.PROGRAMFILES ?? "C:\\Program Files";
		const pf86 = process.env["PROGRAMFILES(X86)"] ?? "C:\\Program Files (x86)";
		const local = process.env.LOCALAPPDATA;
		candidates.push(
			`${pf}\\Google\\Chrome\\Application\\chrome.exe`,
			`${pf86}\\Google\\Chrome\\Application\\chrome.exe`,
			`${pf}\\Microsoft\\Edge\\Application\\msedge.exe`,
			`${pf86}\\Microsoft\\Edge\\Application\\msedge.exe`,
		);
		if (local) candidates.push(`${local}\\Google\\Chrome\\Application\\chrome.exe`);
	} else if (process.platform === "darwin") {
		candidates.push(
			"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
			"/Applications/Chromium.app/Contents/MacOS/Chromium",
			"/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
		);
	} else {
		// Linux + others — typical apt/dnf install paths.
		candidates.push(
			"/usr/bin/google-chrome",
			"/usr/bin/google-chrome-stable",
			"/usr/bin/chromium",
			"/usr/bin/chromium-browser",
			"/snap/bin/chromium",
		);
	}
	for (const p of candidates) {
		try {
			if (fs.existsSync(p)) return p;
		} catch {
			/* probe never throws */
		}
	}
	return undefined;
}

/** Closes the active browser if one is running. Safe to call when idle. */
export async function close(): Promise<void> {
	const current = state;
	state = null;
	if (!current) return;
	try {
		await current.browser.close();
	} catch {
		// Best-effort cleanup; the window may already be gone.
	}
}

/** Test/diagnostic helper — true when a browser is currently live. */
export function isActive(): boolean {
	return state !== null;
}
