import type { ToolSpec } from "@oati/shared";

interface GitStatusResult {
	readonly branch?: string;
	readonly staged: readonly string[];
	readonly unstaged: readonly string[];
	readonly untracked: readonly string[];
	readonly clean: boolean;
}

/**
 * Parse the output of `git status --porcelain=v1 -b`.
 *
 * Porcelain v1 lines are 3-char prefix + path:
 *   `XY path` where X = index/staged status, Y = worktree/unstaged status.
 *   `??` is untracked, `!!` is ignored (we don't list these).
 * Branch info appears on the leading `## branchname...origin/branch` line.
 */
function parseStatus(output: string): GitStatusResult {
	const staged = new Set<string>();
	const unstaged = new Set<string>();
	const untracked = new Set<string>();
	let branch: string | undefined;

	for (const rawLine of output.split(/\r?\n/)) {
		if (rawLine.length === 0) continue;
		if (rawLine.startsWith("## ")) {
			// Format: `## branch...origin/branch [ahead 1]` or `## HEAD (no branch)`
			const rest = rawLine.slice(3);
			const m = rest.match(/^([^.\s]+)/);
			if (m) branch = m[1];
			continue;
		}
		if (rawLine.length < 3) continue;
		const x = rawLine[0];
		const y = rawLine[1];
		// path starts at column 3 — handle rename arrows: `R  old -> new`
		let path = rawLine.slice(3);
		const arrow = path.indexOf(" -> ");
		if (arrow >= 0) path = path.slice(arrow + 4);
		if (x === "?" && y === "?") {
			untracked.add(path);
			continue;
		}
		if (x !== " " && x !== "?") staged.add(path);
		if (y !== " " && y !== "?") unstaged.add(path);
	}

	return {
		branch,
		staged: [...staged].sort(),
		unstaged: [...unstaged].sort(),
		untracked: [...untracked].sort(),
		clean: staged.size === 0 && unstaged.size === 0 && untracked.size === 0,
	};
}

export const gitStatusTool: ToolSpec = {
	name: "git_status",
	description:
		"Report the workspace git status — staged, unstaged, and untracked file lists plus the current branch. Read-only.",
	schema: {
		type: "object",
		properties: {},
		additionalProperties: false,
	},
	approval: "auto",
	async handler(_args, ctx): Promise<GitStatusResult> {
		const res = await ctx.exec("git status --porcelain=v1 -b", { timeoutMs: 15_000 });
		if (res.exitCode !== 0) {
			throw new Error(
				`git status failed (exit ${res.exitCode}): ${res.stderr.trim() || res.stdout.trim() || "no output"}`,
			);
		}
		return parseStatus(res.stdout);
	},
};

// Exported for unit testing the parser without exec.
export const __test = { parseStatus };
