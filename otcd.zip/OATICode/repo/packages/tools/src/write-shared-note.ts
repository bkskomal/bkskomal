import type { ToolSpec } from "@oati/shared";

interface WriteSharedNoteArgs {
	readonly note: string;
}

function isWriteSharedNoteArgs(v: unknown): v is WriteSharedNoteArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as WriteSharedNoteArgs;
	return typeof a.note === "string" && a.note.trim().length > 0;
}

/**
 * Sub-agent-only tool: append a note to the per-parent-run shared scratchpad
 * so sibling sub-agents can see what each other have learned. Carried via
 * `HostContext.scratchpadWrite`; the actual storage lives on the host and is
 * dropped when the parent run completes.
 *
 * The per-sub-agent HostContext wrapper (set up in extension.ts'
 * `spawnSubAgentsParallel`) closes over the parent agent id so this tool
 * doesn't need to know it explicitly — passing `""` is interpreted as
 * "the parent bucket for the sub-agent invoking this call".
 *
 * Only available inside sub-agents spawned via `spawn_parallel_agents`. The
 * registry filters this tool out of the top-level agent's tool list via
 * `scope: "sub-agent"`.
 */
export const writeSharedNoteTool: ToolSpec = {
	name: "write_shared_note",
	description:
		"Append a short note (≤500 chars) to the shared scratchpad visible to your sibling sub-agents in this batch. Notes are dropped when the parent run completes. Use to surface findings other sub-agents should know.",
	schema: {
		type: "object",
		properties: {
			note: {
				type: "string",
				description: "Note text. Single line preferred; keep it under 500 characters.",
			},
		},
		required: ["note"],
		additionalProperties: false,
	},
	approval: "auto",
	scope: "sub-agent",
	async handler(args, ctx): Promise<string> {
		if (!isWriteSharedNoteArgs(args)) throw new Error("write_shared_note: invalid args");
		if (!ctx.scratchpadWrite) {
			throw new Error("write_shared_note: shared scratchpad is not available in this host.");
		}
		const trimmed = args.note.trim().slice(0, 500);
		// The per-sub-agent HostContext wrapper hard-codes the parent id; "" is
		// the wrapper's signal to write into "my parent's bucket".
		ctx.scratchpadWrite("", trimmed);
		return `Noted (${trimmed.length} chars).`;
	},
};
