// TODO(merge): R2-B authored this tool but did NOT register it. Final wiring
// into `packages/tools/src/index.ts` and `packages/tools/src/registry.ts` is
// deferred to the parent merge step because those files are owned by R2-C/D
// and concurrent edits would conflict. The parent should:
//   1. `export { startBackgroundTaskTool } from "./start-background-task";`
//      from `index.ts`.
//   2. Push `startBackgroundTaskTool` into the `builtinTools` array in
//      `registry.ts`.
//
// The tool is intentionally side-effect-free at import time — registration is
// a pure data operation.

import type { ToolSpec } from "@oati/shared";

interface StartBackgroundTaskArgs {
	readonly task: string;
	readonly label?: string;
}

function isStartBackgroundTaskArgs(v: unknown): v is StartBackgroundTaskArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as StartBackgroundTaskArgs;
	if (typeof a.task !== "string" || a.task.trim().length === 0) return false;
	if (a.label !== undefined && typeof a.label !== "string") return false;
	return true;
}

/**
 * Hand off a self-contained task to the {@link BackgroundTaskRunner}. The
 * caller (i.e. the active agent) does NOT wait for the spawned task; it
 * receives only the task id and a hint of where to look for results
 * (workspace `.oati/tasks/<id>.json`).
 *
 * The host is expected to plumb a `startBackgroundTask` method onto its
 * `HostContext`. Until that wiring lands (it depends on the merge of R2-B's
 * background-tasks module), the tool surfaces a graceful "not enabled"
 * error so partial deployments stay debuggable.
 */
export const startBackgroundTaskTool: ToolSpec<
	StartBackgroundTaskArgs,
	{ taskId: string; status: string }
> = {
	name: "start_background_task",
	description:
		"Hand off a long-running task to the background runner. Returns immediately with a task id. The task survives panel close / window blur, and its final result lands in `.oati/tasks/<id>.json` plus a status-bar notification. Prefer this over spawn_agent when you want the user to keep working while the task chugs along.",
	schema: {
		type: "object",
		properties: {
			task: {
				type: "string",
				description: "Self-contained task description (treated as the initial user message).",
			},
			label: {
				type: "string",
				description:
					"Optional short label shown in the status bar and task list. Defaults to a truncation of `task`.",
			},
		},
		required: ["task"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args, ctx) {
		if (!isStartBackgroundTaskArgs(args)) {
			throw new Error("start_background_task: invalid args (require non-empty `task` string)");
		}
		// HostContext bridge — populated by the extension host during merge.
		// Until then we surface a clear actionable error instead of crashing.
		const start = (
			ctx as unknown as {
				startBackgroundTask?: (input: {
					task: string;
					label?: string;
				}) => Promise<{ taskId: string }>;
			}
		).startBackgroundTask;
		if (!start) {
			throw new Error(
				"start_background_task: host has not wired BackgroundTaskRunner yet. Final registration is deferred to the merge step.",
			);
		}
		const result = await start({
			task: args.task,
			...(args.label ? { label: args.label } : {}),
		});
		return { taskId: result.taskId, status: "started" };
	},
};
