// TODO(r8-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts (owned by R8-A).
// R8-D: computer-use mouse_click tool — sends a synthetic click at screen
// coordinates via the optional `@nut-tree-fork/nut-js` package.

import type { ToolSpec } from "@oati/shared";
import { type NutJsApi, loadNutJs } from "./nut-loader";

interface MouseClickArgs {
	readonly x: number;
	readonly y: number;
	readonly button?: "left" | "right" | "middle";
	readonly double?: boolean;
}

interface MouseClickResult {
	readonly clicked: true;
	readonly x: number;
	readonly y: number;
	readonly button: "left" | "right" | "middle";
	readonly double: boolean;
}

function isMouseClickArgs(v: unknown): v is MouseClickArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as MouseClickArgs;
	if (typeof a.x !== "number" || typeof a.y !== "number") return false;
	if (a.button !== undefined && !["left", "right", "middle"].includes(a.button)) return false;
	if (a.double !== undefined && typeof a.double !== "boolean") return false;
	return true;
}

function buttonFor(api: NutJsApi, name: "left" | "right" | "middle"): unknown {
	if (name === "right") return api.Button.RIGHT;
	if (name === "middle") return api.Button.MIDDLE;
	return api.Button.LEFT;
}

export const mouseClickTool: ToolSpec<MouseClickArgs, MouseClickResult> = {
	name: "mouse_click",
	description:
		"Send a synthetic mouse click at screen coordinates (x, y). Optional `button` (left/right/middle) and `double` for a double-click. Approval-gated.",
	schema: {
		type: "object",
		properties: {
			x: { type: "integer", description: "Screen x-coordinate." },
			y: { type: "integer", description: "Screen y-coordinate." },
			button: {
				type: "string",
				enum: ["left", "right", "middle"],
				description: "Which mouse button. Default `left`.",
			},
			double: {
				type: "boolean",
				description: "When true, send a double click instead of a single click.",
			},
		},
		required: ["x", "y"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args): Promise<MouseClickResult> {
		if (!isMouseClickArgs(args)) throw new Error("mouse_click: invalid args");
		const api = await loadNutJs();
		const btnName = args.button ?? "left";
		const double = args.double === true;
		await api.mouse.setPosition(new api.Point(args.x, args.y));
		const btn = buttonFor(api, btnName);
		if (double && typeof api.mouse.doubleClick === "function") {
			await api.mouse.doubleClick(btn);
		} else if (typeof api.mouse.click === "function") {
			await api.mouse.click(btn);
			if (double) await api.mouse.click(btn);
		} else if (btnName === "right") {
			await api.mouse.rightClick();
			if (double) await api.mouse.rightClick();
		} else {
			await api.mouse.leftClick();
			if (double) await api.mouse.leftClick();
		}
		return { clicked: true, x: args.x, y: args.y, button: btnName, double };
	},
};
