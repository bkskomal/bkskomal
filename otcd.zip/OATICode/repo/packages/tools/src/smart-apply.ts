import type { ToolSpec } from "@oati/shared";

/**
 * R6-D: `smart_apply_patch` tool.
 *
 * Exposes the three-way merge logic from `extension-host/src/smart-apply.ts`
 * as a tool the agent can invoke explicitly. Useful when the model knows it
 * may have a stale `before` snapshot (e.g. it just ran a long-running task)
 * and wants to try a fuzzy re-apply rather than failing the write.
 *
 * The tool reads the current on-disk content via `ctx.readFile`, runs the
 * merge in-process, and returns the structured result. Approval is "prompt"
 * because the merged buffer is what we'd then write — the user should see
 * the conflict markers (if any) before committing.
 *
 * TODO(r6-merge): registration is owned by R6-A's tool-registry rework; we
 * deliberately do NOT touch `tools/src/registry.ts` or `tools/src/index.ts`
 * here. Once R6-A lands, append `smartApplyPatchTool` to the registry list.
 */

import { smartApplyEdit } from "../../extension-host/src/smart-apply";

interface SmartApplyArgs {
	readonly path: string;
	readonly before: string;
	readonly after: string;
}

function isSmartApplyArgs(v: unknown): v is SmartApplyArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SmartApplyArgs;
	return typeof a.path === "string" && typeof a.before === "string" && typeof a.after === "string";
}

export const smartApplyPatchTool: ToolSpec = {
	name: "smart_apply_patch",
	description:
		"Three-way merge an agent-authored `before` → `after` change against the current on-disk content of `path`. Returns { status: 'clean' | 'merged' | 'conflict', merged, conflictHunks? }.",
	schema: {
		type: "object",
		properties: {
			path: { type: "string", description: "Workspace-relative path to merge into." },
			before: {
				type: "string",
				description: "The pre-image the agent was working from (may be stale).",
			},
			after: { type: "string", description: "The agent's intended post-image." },
		},
		required: ["path", "before", "after"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args, ctx) {
		if (!isSmartApplyArgs(args)) return {};
		const current = (await ctx.fileExists(args.path)) ? await ctx.readFile(args.path) : "";
		const res = smartApplyEdit(args.path, args.before, args.after, current);
		return {
			diff: { path: args.path, before: current, after: res.merged },
			note:
				res.status === "conflict"
					? `Smart-apply produced ${res.conflictHunks?.length ?? 0} conflict marker(s); resolve in the editor before saving.`
					: res.status === "merged"
						? "Smart-apply re-located the change against drifted content."
						: "Smart-apply: file unchanged on disk, applying cleanly.",
		};
	},
	async handler(args, ctx) {
		if (!isSmartApplyArgs(args)) throw new Error("smart_apply_patch: invalid args");
		const current = (await ctx.fileExists(args.path)) ? await ctx.readFile(args.path) : "";
		const res = smartApplyEdit(args.path, args.before, args.after, current);
		return {
			path: args.path,
			status: res.status,
			merged: res.merged,
			conflictHunks: res.conflictHunks ?? [],
		};
	},
};
