// 2026-05-30: extract_image_text — OCR a screenshot / image file into text.
//
// Companion to `browser_screenshot`'s auto-pageText: that one uses the
// LIVE puppeteer DOM as a cheap text source for web pages. THIS tool runs
// OCR via Tesseract on an arbitrary image file or data URL — useful when
// the agent is working with a user-attached screenshot, an image asset,
// or a screenshot saved to disk between turns.
//
// Implementation: shells out to the user's `tesseract` binary via the
// host's `exec` capability. We do NOT bundle Tesseract; users install it
// themselves (apt / brew / Windows installer). If not present, the tool
// returns a friendly error pointing at the install path. We chose
// system Tesseract over tesseract.js (pure JS / WASM) because:
//   - Native binary is ~20-30× faster than WASM.
//   - tesseract.js ships a ~10MB+ language model download per run, which
//     bloats the first-call latency and storage footprint.
//   - Anyone serious about OCR already has Tesseract anyway.

import { promises as fsp } from "node:fs";
import * as os from "node:os";
import * as nodePath from "node:path";
import type { HostContext, ToolSpec } from "@oati/shared";

interface ExtractImageTextArgs {
	/** Filesystem path to an image (PNG/JPG/etc.) on disk. */
	readonly path?: string;
	/** OR: a `data:image/...;base64,...` URL — typically forwarded from browser_screenshot. */
	readonly dataUrl?: string;
	/**
	 * ISO 639-2 language code(s) for Tesseract, joined by `+` (e.g. "eng",
	 * "eng+spa"). Defaults to "eng". The user must have the trained data
	 * for non-English languages installed separately.
	 */
	readonly lang?: string;
}

function isExtractImageTextArgs(v: unknown): v is ExtractImageTextArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as ExtractImageTextArgs;
	const hasPath = typeof a.path === "string" && a.path.length > 0;
	const hasDataUrl = typeof a.dataUrl === "string" && a.dataUrl.length > 0;
	if (!hasPath && !hasDataUrl) return false;
	if (a.lang !== undefined && typeof a.lang !== "string") return false;
	return true;
}

interface ExtractImageTextResult {
	readonly text: string;
	readonly chars: number;
	/** Set when we wrote a temp file (data-URL input) so callers can audit. */
	readonly tempFile?: string;
}

const TESSERACT_MISSING_HINT = [
	"`tesseract` binary not found on PATH. Install it and retry:",
	"  - Windows: download installer from https://github.com/UB-Mannheim/tesseract/wiki and add the install dir to PATH.",
	"  - macOS:   `brew install tesseract`",
	"  - Linux:   `apt install tesseract-ocr` (or your distro's equivalent).",
	"Then verify with `tesseract --version`.",
].join("\n");

async function writeDataUrlToTemp(dataUrl: string): Promise<string> {
	const m = /^data:image\/(\w+);base64,(.+)$/i.exec(dataUrl);
	if (!m) throw new Error("extract_image_text: dataUrl must be `data:image/<type>;base64,<...>`");
	const [, ext, b64] = m;
	const buf = Buffer.from(b64, "base64");
	const tmp = nodePath.join(
		os.tmpdir(),
		`oati-ocr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}.${ext.toLowerCase()}`,
	);
	await fsp.writeFile(tmp, buf);
	return tmp;
}

function quoteForShell(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

export const extractImageTextTool: ToolSpec = {
	name: "extract_image_text",
	description:
		"OCR a screenshot or image file into text using the system `tesseract` binary. Use when the agent has an image (a screenshot saved to disk, an asset on disk, or a data URL from browser_screenshot) and needs to read what's visually rendered — e.g. verifying a page rendered correctly, reading text from a UI mock, parsing a chart label. Requires Tesseract to be installed (the tool surfaces an install hint when missing). For LIVE web pages prefer `browser_screenshot`'s built-in pageText / `browser_eval` — they're cheaper and don't need a binary.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description:
					"Path to an image file on disk (PNG/JPG/TIFF/BMP). Provide EITHER path OR dataUrl, not both.",
			},
			dataUrl: {
				type: "string",
				description:
					"A `data:image/<type>;base64,<...>` URL — typically forwarded from a prior `browser_screenshot` call's `dataUrl` field.",
			},
			lang: {
				type: "string",
				description:
					"ISO 639-2 language code for Tesseract; multiple joined with `+` (e.g. 'eng', 'eng+spa'). Defaults to 'eng'. Non-English languages need their trained data installed separately.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx: HostContext): Promise<ExtractImageTextResult> {
		if (!isExtractImageTextArgs(args)) {
			throw new Error(
				"extract_image_text: invalid args — supply { path } OR { dataUrl }, optionally with { lang }",
			);
		}
		let imagePath: string;
		let tempFile: string | undefined;
		if (args.path) {
			imagePath = args.path;
		} else {
			imagePath = await writeDataUrlToTemp(args.dataUrl as string);
			tempFile = imagePath;
		}
		const lang = args.lang ?? "eng";
		const cmd = `tesseract ${quoteForShell(imagePath)} stdout -l ${quoteForShell(lang)}`;
		let result: { stdout: string; stderr: string; exitCode: number };
		try {
			result = await ctx.exec(cmd, { timeoutMs: 60_000 });
		} catch (err) {
			if (tempFile) {
				try {
					await fsp.unlink(tempFile);
				} catch {
					/* best-effort */
				}
			}
			const message = err instanceof Error ? err.message : String(err);
			// ENOENT-style spawn errors are how Node surfaces "binary not found"
			// when exec resolves the command via the OS. Re-surface as the
			// friendly install hint instead of the cryptic ENOENT.
			if (/enoent|not recognized|command not found|no such file/i.test(message)) {
				throw new Error(`extract_image_text: ${TESSERACT_MISSING_HINT}`);
			}
			throw new Error(`extract_image_text: exec failed — ${message}`);
		}
		if (tempFile) {
			try {
				await fsp.unlink(tempFile);
			} catch {
				/* best-effort */
			}
		}
		if (result.exitCode !== 0) {
			// Tesseract uses exit codes for read failures, missing language data, etc.
			const stderrTail = result.stderr.slice(-500).trim();
			if (/tessdata|TessdataManager|Failed loading language/i.test(stderrTail)) {
				throw new Error(
					`extract_image_text: Tesseract missing language data for '${lang}'. Install the trained-data file (e.g. \`apt install tesseract-ocr-${lang}\` or download from https://github.com/tesseract-ocr/tessdata) and retry. Stderr tail: ${stderrTail}`,
				);
			}
			throw new Error(
				`extract_image_text: tesseract exit ${result.exitCode}. Stderr tail: ${stderrTail || "(empty)"}`,
			);
		}
		const text = result.stdout.trim();
		return {
			text,
			chars: text.length,
			...(tempFile ? { tempFile } : {}),
		};
	},
};
