// R6-B: insert_notebook_cell — splice a new cell into a .ipynb at the given
// 0-based index. Existing cells at and after `index` shift down by one.
// Backed by `ctx.notebooks.insertCell`, which wraps `vscode.NotebookEdit.insertCells`.
import type { ToolSpec } from "@oati/shared";

interface InsertNotebookCellArgs {
	readonly path: string;
	readonly index: number;
	readonly kind: "code" | "markdown";
	readonly source: string;
	readonly language?: string;
}

function isInsertNotebookCellArgs(v: unknown): v is InsertNotebookCellArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as InsertNotebookCellArgs;
	if (typeof a.path !== "string") return false;
	if (typeof a.index !== "number" || !Number.isFinite(a.index)) return false;
	if (a.kind !== "code" && a.kind !== "markdown") return false;
	if (typeof a.source !== "string") return false;
	if (a.language !== undefined && typeof a.language !== "string") return false;
	return true;
}

export const insertNotebookCellTool: ToolSpec = {
	name: "insert_notebook_cell",
	description:
		"Insert a new cell into a Jupyter notebook (.ipynb) at a specific 0-based index. Existing cells at or after this index shift down by one. Use index = current cell count to append. `kind` is 'code' or 'markdown'; `language` is the language id (e.g. 'python'); defaults to the notebook's primary language.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Path to the .ipynb file, relative to workspace root or absolute.",
			},
			index: {
				type: "integer",
				description: "0-based index where the new cell should land. Use cell-count to append.",
			},
			kind: {
				type: "string",
				enum: ["code", "markdown"],
				description: "Cell kind.",
			},
			source: {
				type: "string",
				description: "Cell source body.",
			},
			language: {
				type: "string",
				description:
					"Optional language id for code cells (e.g. 'python', 'typescript'). Ignored for markdown.",
			},
		},
		required: ["path", "index", "kind", "source"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isInsertNotebookCellArgs(args)) return {};
		return {
			diff: {
				path: `${args.path}#new-cell-at-${args.index}`,
				before: "",
				after: args.source,
			},
		};
	},
	async handler(args, ctx) {
		if (!isInsertNotebookCellArgs(args)) {
			throw new Error(
				"insert_notebook_cell: invalid args, expected { path: string; index: number; kind: 'code'|'markdown'; source: string; language?: string }",
			);
		}
		if (!ctx.notebooks) {
			throw new Error(
				"insert_notebook_cell: this host has no notebook bridge — open the .ipynb in VS Code first.",
			);
		}
		await ctx.notebooks.insertCell(args.path, args.index, args.kind, args.source, args.language);
		return { inserted: true, path: args.path, index: args.index };
	},
};
