// R6-B: delete_notebook_cell — remove a cell from a .ipynb at the given 0-based
// index. Backed by `ctx.notebooks.deleteCell`, which wraps `vscode.NotebookEdit`
// inside a `vscode.workspace.applyEdit` for single-stroke undo. Approval is
// `"prompt"` and the preview shows the cell that's about to disappear.
import type { ToolSpec } from "@oati/shared";
import { parseNotebookJson } from "./read-notebook";

interface DeleteNotebookCellArgs {
	readonly path: string;
	readonly index: number;
}

function isDeleteNotebookCellArgs(v: unknown): v is DeleteNotebookCellArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as DeleteNotebookCellArgs;
	return typeof a.path === "string" && typeof a.index === "number" && Number.isFinite(a.index);
}

export const deleteNotebookCellTool: ToolSpec = {
	name: "delete_notebook_cell",
	description:
		"Delete a cell from a Jupyter notebook (.ipynb) by 0-based index. Cells after `index` shift up by one. Shows a preview of the cell that will be removed and requires user approval.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Path to the .ipynb file, relative to workspace root or absolute.",
			},
			index: {
				type: "integer",
				description: "0-based cell index to remove.",
			},
		},
		required: ["path", "index"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args, ctx) {
		if (!isDeleteNotebookCellArgs(args)) return {};
		let before = "";
		try {
			if (ctx.notebooks) {
				const cells = await ctx.notebooks.read(args.path, false);
				if (args.index >= 0 && args.index < cells.length) {
					before = cells[args.index].source;
				}
			} else if (await ctx.fileExists(args.path)) {
				const raw = await ctx.readFile(args.path);
				const cells = parseNotebookJson(raw, false);
				if (args.index >= 0 && args.index < cells.length) {
					before = cells[args.index].source;
				}
			}
		} catch {
			// Fall through with an empty preview body.
		}
		return {
			diff: {
				path: `${args.path}#delete-cell-${args.index}`,
				before,
				after: "",
			},
		};
	},
	async handler(args, ctx) {
		if (!isDeleteNotebookCellArgs(args)) {
			throw new Error("delete_notebook_cell: invalid args, expected { path: string; index: number }");
		}
		if (!ctx.notebooks) {
			throw new Error(
				"delete_notebook_cell: this host has no notebook bridge — open the .ipynb in VS Code first.",
			);
		}
		await ctx.notebooks.deleteCell(args.path, args.index);
		return { deleted: true, path: args.path, index: args.index };
	},
};
