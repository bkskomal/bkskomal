// TODO(r3-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
//
// R3-C: architecture diagrams (mermaid). This tool is a thin wrapper — it
// doesn't transform anything itself; instead it asks the host to forward a
// `diagram_render` event to the webview, where the `mermaid` npm package
// renders the source in-place. Returning `{ ok: true }` keeps the agent loop
// happy without echoing the (potentially large) mermaid source back through
// the tool-result channel.

import type { ToolSpec } from "@oati/shared";

interface RenderDiagramArgs {
	readonly mermaid: string;
	readonly title?: string;
}

interface RenderDiagramResult {
	readonly ok: true;
}

function isRenderDiagramArgs(v: unknown): v is RenderDiagramArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as RenderDiagramArgs;
	if (typeof a.mermaid !== "string" || a.mermaid.length === 0) return false;
	if (a.title !== undefined && typeof a.title !== "string") return false;
	return true;
}

/**
 * The host's `emitToolProgress` channel is repurposed here as a way to nudge
 * the webview into rendering a diagram — we tag the chunk with a sentinel
 * prefix so the chat-panel can recognize it and forward as a `diagram_render`
 * event rather than treating it as raw stdout. Falls back to embedding the
 * source in the tool result when no progress channel is available.
 */
export const renderDiagramTool: ToolSpec<RenderDiagramArgs, RenderDiagramResult> = {
	name: "render_diagram",
	description:
		"Render a Mermaid diagram in the chat. Pass valid mermaid source (e.g. 'flowchart TD; A-->B'); the webview renders it inline.",
	schema: {
		type: "object",
		properties: {
			mermaid: {
				type: "string",
				description: "Mermaid diagram source (e.g. a flowchart or sequenceDiagram block).",
			},
			title: {
				type: "string",
				description: "Optional human-readable title shown above the rendered diagram.",
			},
		},
		required: ["mermaid"],
		additionalProperties: false,
	},
	// Rendering a diagram is non-destructive — no shell, no filesystem writes —
	// so it doesn't need an approval prompt. Matches the policy on the other
	// pure-read tools (`workspace_context`, `code_semantic_search`, etc.).
	approval: "auto",
	async handler(args, ctx, callCtx): Promise<RenderDiagramResult> {
		if (!isRenderDiagramArgs(args)) throw new Error("render_diagram: invalid args");
		const callId = callCtx?.callId ?? `diagram_${Date.now()}`;
		// Encode the payload as a JSON blob behind a sentinel prefix so chat-panel
		// can route it to the `diagram_render` HostToWebview channel instead of
		// the normal tool_progress stream. Falls back silently when no progress
		// channel is wired (tests, CLI runs).
		if (ctx.emitToolProgress) {
			const payload = JSON.stringify({
				kind: "oati.render_diagram",
				id: callId,
				mermaid: args.mermaid,
				...(args.title ? { title: args.title } : {}),
			});
			ctx.emitToolProgress(callId, `oati-diagram-render${payload}`);
		}
		return { ok: true };
	},
};

/**
 * Sentinel prefix used by `render_diagram` to mark its emitToolProgress
 * chunks. Exported so the chat-panel can pattern-match without duplicating
 * the literal. The triple `` sandwich keeps the marker invisible to
 * any well-behaved renderer that drops control chars.
 */
export const RENDER_DIAGRAM_MARKER = "oati-diagram-render";
