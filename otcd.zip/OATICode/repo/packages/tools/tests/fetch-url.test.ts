import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { fetchUrlTool } from "../src/fetch-url";
import { makeMockHost } from "./mock-host";

describe("fetch_url tool", () => {
	const originalFetch = global.fetch;

	beforeEach(() => {
		global.fetch = vi.fn();
	});

	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("fetches a URL and returns the body", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response("hello world", {
				status: 200,
				headers: { "content-type": "text/plain" },
			}),
		);
		const result = await fetchUrlTool.handler({ url: "https://example.com/data" }, makeMockHost());
		// biome-ignore lint/suspicious/noExplicitAny: result is unknown by ToolSpec generics, test cast OK
		const r = result as any;
		expect(r.status).toBe(200);
		expect(r.body).toBe("hello world");
		expect(r.contentType).toBe("text/plain");
		expect(r.truncated).toBe(false);
	});

	it("truncates oversized bodies", async () => {
		const big = "x".repeat(10_000);
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(big, {
				status: 200,
				headers: { "content-type": "text/plain" },
			}),
		);
		const result = await fetchUrlTool.handler(
			{ url: "https://example.com", max_bytes: 100 },
			makeMockHost(),
		);
		// biome-ignore lint/suspicious/noExplicitAny: test cast
		const r = result as any;
		expect(r.body.length).toBe(100);
		expect(r.truncated).toBe(true);
	});

	it("rejects non-http(s) schemes", async () => {
		await expect(fetchUrlTool.handler({ url: "file:///etc/passwd" }, makeMockHost())).rejects.toThrow(
			/http\/https/,
		);
	});

	it("rejects malformed URLs", async () => {
		await expect(fetchUrlTool.handler({ url: "not a url" }, makeMockHost())).rejects.toThrow(
			/invalid URL/,
		);
	});

	it("rejects invalid args shape", async () => {
		await expect(fetchUrlTool.handler({ noUrl: true }, makeMockHost())).rejects.toThrow(
			/invalid args/,
		);
	});

	it("is approval-gated (SSRF protection)", () => {
		expect(fetchUrlTool.approval).toBe("prompt");
	});
});
