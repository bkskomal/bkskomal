import { describe, expect, it } from "vitest";
import { detectRunner, parseFailures, runTestsTool } from "../src/run-tests";
import { makeMockHost } from "./mock-host";

describe("run_tests detection", () => {
	it("detects vitest from devDependencies", async () => {
		const host = makeMockHost({
			files: {
				"package.json": JSON.stringify({ devDependencies: { vitest: "^2.0" } }),
			},
		});
		const r = await detectRunner(host);
		expect(r.kind).toBe("vitest");
		expect(r.buildCommand({})).toContain("vitest");
	});

	it("detects jest", async () => {
		const host = makeMockHost({
			files: { "package.json": JSON.stringify({ devDependencies: { jest: "^29" } }) },
		});
		const r = await detectRunner(host);
		expect(r.kind).toBe("jest");
		expect(r.buildCommand({ pattern: "foo" })).toContain("-t");
	});

	it("detects mocha", async () => {
		const host = makeMockHost({
			files: { "package.json": JSON.stringify({ devDependencies: { mocha: "*" } }) },
		});
		const r = await detectRunner(host);
		expect(r.kind).toBe("mocha");
		expect(r.buildCommand({ bail: true })).toContain("--bail");
	});

	it("falls back to npm-test when scripts.test is set", async () => {
		const host = makeMockHost({
			files: { "package.json": JSON.stringify({ scripts: { test: "make test" } }) },
		});
		const r = await detectRunner(host);
		expect(r.kind).toBe("npm-test");
		expect(r.buildCommand({})).toContain("npm test");
	});

	it("detects pytest from pytest.ini", async () => {
		const host = makeMockHost({ files: { "pytest.ini": "[pytest]\n" } });
		const r = await detectRunner(host);
		expect(r.kind).toBe("pytest");
		expect(r.buildCommand({ pattern: "k", bail: true })).toMatch(/pytest .*-x.*-k/);
	});

	it("detects pytest from pyproject.toml", async () => {
		const host = makeMockHost({ files: { "pyproject.toml": "[tool.pytest]\n" } });
		const r = await detectRunner(host);
		expect(r.kind).toBe("pytest");
	});

	it("returns none when no runner found", async () => {
		const host = makeMockHost();
		const r = await detectRunner(host);
		expect(r.kind).toBe("none");
	});
});

describe("run_tests parseFailures", () => {
	it("parses vitest FAIL lines", () => {
		const out = "FAIL  tests/foo.test.ts > suite > does a thing\n  AssertionError";
		const failures = parseFailures("vitest", out, "");
		expect(failures.length).toBeGreaterThanOrEqual(1);
		expect(failures[0].name).toContain("tests/foo.test.ts");
	});

	it("parses jest ● blocks", () => {
		const out = "  ● MyComp › renders\n    Expected 1 received 2";
		const failures = parseFailures("jest", out, "");
		expect(failures[0].name).toContain("renders");
	});

	it("parses mocha numbered failures", () => {
		const out = "  1) my suite > my test\n    AssertionError\n  2) other suite > thing\n";
		const failures = parseFailures("mocha", out, "");
		expect(failures.length).toBe(2);
	});

	it("parses pytest FAILED + headers", () => {
		const out = "FAILED tests/test_x.py::test_one - assert 1 == 2";
		const failures = parseFailures("pytest", out, "");
		expect(failures[0].name).toBe("tests/test_x.py::test_one");
	});

	it("falls back to first 40 lines of stderr when no pattern matches", () => {
		const stderr = "boom\nstack frame 1\nstack frame 2\n";
		const failures = parseFailures("vitest", "", stderr);
		expect(failures.length).toBe(1);
		expect(failures[0].name).toMatch(/unparsed/);
		expect(failures[0].snippet).toContain("boom");
	});

	it("returns empty list when there is no output at all", () => {
		expect(parseFailures("vitest", "", "")).toEqual([]);
	});
});

describe("run_tests tool", () => {
	it("is read-only (auto approval)", () => {
		expect(runTestsTool.approval).toBe("auto");
	});

	it("returns a friendly result when no runner is detected", async () => {
		const host = makeMockHost();
		const r = (await runTestsTool.handler({}, host)) as {
			exitCode: number;
			runner: string;
			summary: string;
		};
		expect(r.runner).toBe("none");
		expect(r.exitCode).toBe(0);
		expect(r.summary).toMatch(/No test runner/);
	});

	it("runs the detected runner and returns parsed failures", async () => {
		const host = makeMockHost({
			files: { "package.json": JSON.stringify({ devDependencies: { vitest: "*" } }) },
			execHandler: async () => ({
				stdout: "FAIL tests/x.test.ts > something\n\nTests: 1 failed, 0 passed\n",
				stderr: "",
				exitCode: 1,
			}),
		});
		const r = (await runTestsTool.handler({}, host)) as {
			exitCode: number;
			runner: string;
			failures: readonly { name: string }[];
		};
		expect(r.runner).toBe("vitest");
		expect(r.exitCode).toBe(1);
		expect(r.failures.length).toBeGreaterThan(0);
	});
});
