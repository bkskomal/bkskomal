import type {
	ExecOptions,
	ExecResult,
	HostContext,
	SubAgentRequest,
	SubAgentResult,
} from "@oati/shared";
import { vi } from "vitest";

export interface MockHostOverrides {
	workspaceRoot?: string;
	files?: Record<string, string>;
	execHandler?: (command: string, options?: ExecOptions) => Promise<ExecResult>;
	approve?: boolean;
	subAgentResult?: SubAgentResult;
}

export interface MockHost extends HostContext {
	files: Map<string, string>;
	execCalls: Array<{ command: string; options?: ExecOptions }>;
	diffCalls: Array<{ path: string; before: string; after: string }>;
	approvalCalls: number;
	subAgentCalls: number;
	// Allow tests to override:
	exec: HostContext["exec"];
	emitToolProgress?: HostContext["emitToolProgress"];
}

export function makeMockHost(overrides: MockHostOverrides = {}): MockHost {
	const files = new Map<string, string>(Object.entries(overrides.files ?? {}));
	const execCalls: MockHost["execCalls"] = [];
	const diffCalls: MockHost["diffCalls"] = [];
	let approvalCalls = 0;
	let subAgentCalls = 0;

	const host: MockHost = {
		files,
		execCalls,
		diffCalls,
		get approvalCalls() {
			return approvalCalls;
		},
		get subAgentCalls() {
			return subAgentCalls;
		},
		async readFile(path) {
			const content = files.get(path);
			if (content === undefined) throw new Error(`ENOENT: ${path}`);
			return content;
		},
		async writeFile(path, content) {
			files.set(path, content);
		},
		async fileExists(path) {
			return files.has(path);
		},
		async exec(command, options) {
			execCalls.push({ command, options });
			if (overrides.execHandler) return overrides.execHandler(command, options);
			return { stdout: "", stderr: "", exitCode: 0 };
		},
		workspaceRoot() {
			return overrides.workspaceRoot ?? "/test/workspace";
		},
		async requestApproval() {
			approvalCalls++;
			return overrides.approve ?? true;
		},
		async showDiff(diff) {
			diffCalls.push({ path: diff.path, before: diff.before, after: diff.after });
		},
		log: vi.fn(),
		async spawnSubAgent() {
			subAgentCalls++;
			return (
				overrides.subAgentResult ?? {
					text: "(no result configured)",
					toolCalls: 0,
					iterations: 0,
				}
			);
		},
		async spawnSubAgentsParallel(requests: readonly SubAgentRequest[]) {
			// Default stub: fan out via the same code path as spawnSubAgent so
			// existing tests that don't override this method still observe
			// subAgentCalls. Tests that care about real concurrency behavior
			// should overwrite host.spawnSubAgentsParallel directly.
			const out: SubAgentResult[] = [];
			for (const _req of requests) {
				subAgentCalls++;
				out.push(
					overrides.subAgentResult ?? {
						text: "(no result configured)",
						toolCalls: 0,
						iterations: 0,
					},
				);
			}
			return out;
		},
	};

	return host;
}
