import { describe, expect, it } from "vitest";
import { builtinTools } from "../src/registry";

describe("builtin tool registry", () => {
	it("includes the core tools", () => {
		const names = builtinTools.map((t) => t.name);
		expect(names).toContain("read_file");
		expect(names).toContain("write_file");
		expect(names).toContain("exec");
		expect(names).toContain("list_dir");
		expect(names).toContain("grep_search");
		expect(names).toContain("fetch_url");
		expect(names).toContain("web_search");
		expect(names).toContain("spawn_agent");
		expect(names).toContain("spawn_parallel_agents");
		expect(names).toContain("get_workspace_context");
		expect(names).toContain("code_semantic_search");
		expect(names).toContain("git_status");
		expect(names).toContain("git_diff");
		expect(names).toContain("git_commit");
		expect(names).toContain("git_open_pr");
		expect(names).toContain("run_tests");
	});

	it("has unique tool names", () => {
		const names = builtinTools.map((t) => t.name);
		const unique = new Set(names);
		expect(unique.size).toBe(names.length);
	});

	it("every tool declares an approval policy", () => {
		for (const t of builtinTools) {
			expect(["auto", "prompt", "deny"]).toContain(t.approval);
		}
	});

	it("every tool declares an object schema", () => {
		for (const t of builtinTools) {
			expect(t.schema.type).toBe("object");
			expect(t.schema.properties).toBeDefined();
		}
	});

	it("every tool has a non-empty description", () => {
		for (const t of builtinTools) {
			expect(t.description.length).toBeGreaterThan(10);
		}
	});
});
