import type { HostContext } from "@oati/shared";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mock the puppeteer page that getOrLaunch returns. The screenshot tool calls
// `page.screenshot({ encoding: 'base64', ... })`, `page.$(...)` then
// `el.screenshot(...)` for selector mode, and (2026-05-30) `page.evaluate(...)`
// for the auto-DOM-extract for non-vision models.
let evaluateReturn: unknown = "Hello world\nLine 2\nLine 3";
// 2026-06-01: the screenshot tool now evaluates scrollHeight BEFORE
// fullPage capture so it can clip oversize pages. Tests that care about
// truncation set this to control the measured page height; the default
// is small enough to never trigger the clip path.
let scrollHeightReturn = 800;
let lastScreenshotOpts: { clip?: { width: number; height: number } } | undefined;
const pageMock = {
	url: () => "http://localhost:8080/index.html",
	async screenshot(opts: { clip?: { width: number; height: number } }) {
		lastScreenshotOpts = opts;
		return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
	},
	async $(_selector: string) {
		return null;
	},
	async setViewport(_opts: unknown) {},
	async evaluate<T>(expr: string): Promise<T> {
		// Differentiate by inspecting the expression. The scrollHeight probe
		// looks for `scrollHeight`; everything else (the innerText extract)
		// falls through to the legacy single-value return.
		if (typeof expr === "string" && expr.includes("scrollHeight")) {
			return scrollHeightReturn as T;
		}
		return evaluateReturn as T;
	},
};

vi.mock("../src/browser-state", async () => {
	const actual =
		await vi.importActual<typeof import("../src/browser-state")>("../src/browser-state");
	return {
		...actual,
		getOrLaunch: async () => ({ page: pageMock }),
	};
});

import { browserScreenshotTool } from "../src/browser-screenshot";

function mockHost(activeModelId?: string): HostContext {
	const host = {
		async readFile() {
			return "";
		},
		async writeFile() {},
		async fileExists() {
			return false;
		},
		async exec() {
			return { stdout: "", stderr: "", exitCode: 0 };
		},
		workspaceRoot() {
			return "/work";
		},
		async requestApproval() {
			return true;
		},
		async showDiff() {},
		log() {},
		...(activeModelId ? { activeModelId } : {}),
	} as unknown as HostContext;
	return host;
}

describe("browser_screenshot — vision-blindness fallback", () => {
	beforeEach(() => {
		vi.clearAllMocks();
	});

	it("returns just the dataUrl for a vision-capable model (no warning)", async () => {
		// Claude Sonnet has supportsVision: true in model-quirks.
		const host = mockHost("claude-sonnet-4-6");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			dataUrl: string;
			downscaled: boolean;
			visionWarning?: string;
		};
		expect(result.dataUrl).toMatch(/^data:image\/png;base64,/);
		expect(result.visionWarning).toBeUndefined();
	});

	it("attaches a visionWarning when the active model is text-only", async () => {
		// 2026-05-30: was kimi-k2-instruct, but K2.6 is now correctly
		// flagged as vision-capable in model-quirks. Use ollama/llama3
		// which stays text-only as a canonical non-vision baseline.
		const host = mockHost("ollama/llama3");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			dataUrl: string;
			visionWarning?: string;
		};
		expect(result.dataUrl).toMatch(/^data:image\/png;base64,/);
		expect(result.visionWarning).toBeDefined();
		expect(result.visionWarning).toMatch(/text-only/i);
		// The warning must name concrete fallbacks the model can act on,
		// not just complain. browser_eval is the primary recommendation.
		expect(result.visionWarning).toMatch(/browser_eval/);
		expect(result.visionWarning).toMatch(/read_file/);
	});

	it("warning text mentions the model id so the model knows what's blocking it", async () => {
		const host = mockHost("ollama/llama3");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			visionWarning?: string;
		};
		expect(result.visionWarning).toMatch(/llama3/i);
	});

	it("warning text mentions the page URL when no selector was used", async () => {
		const host = mockHost("ollama/llama3");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			visionWarning?: string;
		};
		expect(result.visionWarning).toContain("http://localhost:8080/index.html");
	});

	it("treats a missing activeModelId as vision-capable (no warning) — fail-open default", async () => {
		// Without modelId on ctx we can't know — be permissive so we don't
		// nag users on unknown providers. The cost of a missed warning is
		// one bad turn; the cost of nagging a vision-capable model is
		// every screenshot becomes a wall of text.
		const host = mockHost(undefined);
		const result = (await browserScreenshotTool.handler({}, host)) as {
			visionWarning?: string;
		};
		expect(result.visionWarning).toBeUndefined();
	});
});

describe("browser_screenshot — auto-DOM-extract for non-vision models", () => {
	beforeEach(() => {
		vi.clearAllMocks();
		evaluateReturn = "Hello world\nLine 2\nLine 3";
	});

	it("attaches the page's innerText as `pageText` when the active model is non-vision", async () => {
		// This is the architectural fix from the live trace — the model
		// can't see the screenshot, so we hand it the visible DOM text
		// directly. The model then sees the rendered content as text.
		const host = mockHost("moonshotai/kimi-k2-instruct");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			dataUrl: string;
			pageText?: string;
		};
		expect(result.pageText).toBe("Hello world\nLine 2\nLine 3");
	});

	it("pageText catches the broken-page case (literal `\\n` characters visible in DOM)", async () => {
		// THE live-trace failure: the rendered page literally shows `\n\n\n`
		// as visible characters. The auto-extracted innerText surfaces
		// those literal chars so the model can see the breakage.
		evaluateReturn = "AI Learning Hub\\n\\n\\nLLM\\nGenerative AI\\nContext Window\\nTokens\\n\\n";
		const host = mockHost("moonshotai/kimi-k2-instruct");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			pageText?: string;
		};
		expect(result.pageText).toContain("\\n");
		expect(result.pageText).toContain("AI Learning Hub");
	});

	it("DOES extract pageText for vision-capable models too (always-on, 2026-05-30)", async () => {
		// Previously gated on supportsVision: false. The change to always-on
		// recognises that DOM text is cheap AND useful for ALL models —
		// vision models can use it as a quick semantic check before
		// processing the image, and (until multimodal image-content-block
		// packing ships everywhere) it's the only thing some envelopes
		// actually deliver to the model from a screenshot.
		const host = mockHost("claude-sonnet-4-6");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			pageText?: string;
		};
		expect(result.pageText).toBe("Hello world\nLine 2\nLine 3");
	});

	it("does NOT extract pageText for selector-targeted screenshots", async () => {
		// In selector mode the model already knows what it's screenshotting
		// (it gave the selector). The auto-extract makes less sense there
		// and would add noise.
		const host = mockHost("moonshotai/kimi-k2-instruct");
		// Override $ mock to return an element so the selector path runs.
		const origDollar = pageMock.$;
		pageMock.$ = async () =>
			({
				async screenshot() {
					return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
				},
			}) as never;
		try {
			const result = (await browserScreenshotTool.handler({ selector: "h1" }, host)) as {
				pageText?: string;
			};
			expect(result.pageText).toBeUndefined();
		} finally {
			pageMock.$ = origDollar;
		}
	});

	it("silently omits pageText when page.evaluate throws (CSP / page-not-loaded / etc.)", async () => {
		const host = mockHost("ollama/llama3");
		const origEval = pageMock.evaluate;
		pageMock.evaluate = async () => {
			throw new Error("EvaluationFailed: page CSP blocks eval");
		};
		try {
			const result = (await browserScreenshotTool.handler({}, host)) as {
				pageText?: string;
				visionWarning?: string;
			};
			expect(result.pageText).toBeUndefined();
			// Vision warning still fires for the text-only model so it knows to fall back.
			expect(result.visionWarning).toBeDefined();
		} finally {
			pageMock.evaluate = origEval;
		}
	});

	it("warning text directs the model to check pageText FIRST when it's included", async () => {
		const host = mockHost("ollama/llama3");
		const result = (await browserScreenshotTool.handler({}, host)) as {
			visionWarning?: string;
		};
		expect(result.visionWarning).toMatch(/pageText/);
	});
});

// 2026-06-01: vision-token budget. A live trace hit 950k requested tokens
// vs a 262k cap because a fullPage screenshot of a tall page produces an
// image whose pixel count tokenizes way above the model's context. The
// fix clips fullPage to 1280×4096 and reports the true scrollHeight so
// the model knows there's more content below.
describe("browser_screenshot — fullPage pixel-budget clip", () => {
	beforeEach(() => {
		vi.clearAllMocks();
		evaluateReturn = "page content";
		scrollHeightReturn = 800;
		lastScreenshotOpts = undefined;
	});

	it("captures the full height when the page fits within the 4096px budget", async () => {
		scrollHeightReturn = 2000;
		const host = mockHost("moonshotai/kimi-k2");
		const result = (await browserScreenshotTool.handler({ fullPage: true }, host)) as {
			truncated?: { capturedHeight: number; fullScrollHeight: number };
		};
		expect(result.truncated).toBeUndefined();
		expect(lastScreenshotOpts?.clip?.height).toBe(2000);
		expect(lastScreenshotOpts?.clip?.width).toBe(1280);
	});

	it("clips to 4096px tall when the page is huge AND reports the true scrollHeight", async () => {
		// The live-bug shape: a 30000px-tall page would tokenize to ~950k
		// vision tokens. We cap at 4096 (~80k tokens) and tell the model
		// the real height so it can decide whether to scroll/re-screenshot.
		scrollHeightReturn = 30000;
		const host = mockHost("moonshotai/kimi-k2");
		const result = (await browserScreenshotTool.handler({ fullPage: true }, host)) as {
			truncated?: { capturedHeight: number; fullScrollHeight: number };
		};
		expect(result.truncated).toEqual({ capturedHeight: 4096, fullScrollHeight: 30000 });
		expect(lastScreenshotOpts?.clip?.height).toBe(4096);
		expect(lastScreenshotOpts?.clip?.width).toBe(1280);
	});

	it("does NOT use the clip path for viewport-only (fullPage:false) captures", async () => {
		// Default viewport capture stays unchanged — only fullPage triggers
		// the new measure-then-clip flow.
		scrollHeightReturn = 30000;
		const host = mockHost("moonshotai/kimi-k2");
		const result = (await browserScreenshotTool.handler({ fullPage: false }, host)) as {
			truncated?: unknown;
		};
		expect(result.truncated).toBeUndefined();
		expect(lastScreenshotOpts?.clip).toBeUndefined();
	});

	it("falls back to the height cap if scrollHeight evaluation throws", async () => {
		// A page that blocks eval (CSP) shouldn't crash the screenshot —
		// we just clip to the safe maximum and report it as truncated to
		// the safe height.
		const origEval = pageMock.evaluate;
		pageMock.evaluate = async (expr: string) => {
			if (expr.includes("scrollHeight")) throw new Error("CSP blocked eval");
			return "page text" as never;
		};
		try {
			const host = mockHost("moonshotai/kimi-k2");
			const result = (await browserScreenshotTool.handler({ fullPage: true }, host)) as {
				dataUrl: string;
				truncated?: unknown;
			};
			// Capture still succeeded, height clipped to the safe maximum,
			// no `truncated` field because scrollHeight==capturedHeight.
			expect(result.dataUrl).toMatch(/^data:image\/png;base64,/);
			expect(lastScreenshotOpts?.clip?.height).toBe(4096);
		} finally {
			pageMock.evaluate = origEval;
		}
	});
});
