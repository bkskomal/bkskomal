import { describe, expect, it } from "vitest";
import { gitCommitTool } from "../src/git-commit";
import { makeMockHost } from "./mock-host";

describe("git_commit tool", () => {
	it("is approval-gated", () => {
		expect(gitCommitTool.approval).toBe("prompt");
	});

	it("rejects empty message", async () => {
		const host = makeMockHost();
		await expect(gitCommitTool.handler({ message: "" }, host)).rejects.toThrow(/invalid args/);
	});

	it("runs git commit -m with quoted message and reports exit code", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "[main abc1234] x", stderr: "", exitCode: 0 }),
		});
		const r = (await gitCommitTool.handler({ message: "fix: stuff" }, host)) as {
			committed: boolean;
			exitCode: number;
		};
		expect(r.committed).toBe(true);
		expect(r.exitCode).toBe(0);
		expect(host.execCalls).toHaveLength(1);
		expect(host.execCalls[0].command).toMatch(/^git commit -m ["'].*fix: stuff.*["']/);
	});

	it("stages paths before committing when paths provided", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "", stderr: "", exitCode: 0 }),
		});
		await gitCommitTool.handler({ message: "wip", paths: ["src/a.ts", "src/b.ts"] }, host);
		expect(host.execCalls).toHaveLength(2);
		const addCmd = host.execCalls[0].command;
		expect(addCmd).toMatch(/^git add --/);
		expect(addCmd).toMatch(/a\.ts/);
		expect(addCmd).toMatch(/b\.ts/);
	});

	it("appends --signoff when requested", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "", stderr: "", exitCode: 0 }),
		});
		await gitCommitTool.handler({ message: "x", signoff: true }, host);
		expect(host.execCalls[0].command).toMatch(/--signoff/);
	});

	it("returns committed:false when git exits non-zero", async () => {
		const host = makeMockHost({
			execHandler: async () => ({
				stdout: "",
				stderr: "nothing to commit",
				exitCode: 1,
			}),
		});
		const r = (await gitCommitTool.handler({ message: "x" }, host)) as {
			committed: boolean;
		};
		expect(r.committed).toBe(false);
	});

	it("produces an approval preview note", async () => {
		const preview = await gitCommitTool.prepareApprovalPreview?.(
			{ message: "fix things\n\ndetails", paths: ["a"], signoff: true },
			makeMockHost(),
		);
		expect(preview?.note).toContain("fix things");
		expect(preview?.note).toContain("Will stage: a");
		expect(preview?.note).toContain("Signoff: yes");
	});
});
