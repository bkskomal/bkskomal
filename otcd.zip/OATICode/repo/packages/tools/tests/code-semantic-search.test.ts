import type { CodebaseSearchProvider, SemanticSearchHit } from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { codeSemanticSearchTool } from "../src/code-semantic-search";
import { makeMockHost } from "./mock-host";

function makeFakeIndex(
	hits: readonly SemanticSearchHit[],
	calls: { query?: string }[],
): CodebaseSearchProvider {
	return {
		async query(text, _opts) {
			calls.push({ query: text });
			return hits;
		},
	};
}

describe("code_semantic_search tool", () => {
	it("returns a friendly message when no index is configured", async () => {
		const host = makeMockHost();
		// Default mock host has no codebaseIndex — exactly the "no embeddings
		// provider" / "no /reindex yet" state we want to model.
		const result = (await codeSemanticSearchTool.handler({ query: "anything" }, host)) as string;
		expect(result).toContain("no index available");
	});

	it("formats hits as markdown blocks with file:line ranges", async () => {
		const host = makeMockHost();
		const calls: { query?: string }[] = [];
		const fake = makeFakeIndex(
			[
				{
					filePath: "src/auth.ts",
					startLine: 10,
					endLine: 20,
					content: "function authenticateUser() { return verify(); }",
					score: 0.91,
				},
				{
					filePath: "src/util.ts",
					startLine: 1,
					endLine: 5,
					content: "export const x = 1;",
					score: 0.42,
				},
			],
			calls,
		);
		(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
		const out = (await codeSemanticSearchTool.handler({ query: "where is auth" }, host)) as string;
		expect(calls[0].query).toBe("where is auth");
		expect(out).toContain("src/auth.ts:10-20");
		expect(out).toContain("src/util.ts:1-5");
		expect(out).toContain("authenticateUser");
		expect(out).toContain("score=0.910");
	});

	it("clamps k to the [1, 25] range", async () => {
		const host = makeMockHost();
		const calls: { k?: number }[] = [];
		const fake: CodebaseSearchProvider = {
			async query(_text, opts) {
				calls.push({ k: opts?.k });
				return [];
			},
		};
		(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
		await codeSemanticSearchTool.handler({ query: "x", k: 100 }, host);
		expect(calls[0].k).toBe(25);
		await codeSemanticSearchTool.handler({ query: "x", k: -5 }, host);
		expect(calls[1].k).toBe(1);
	});

	it("rejects malformed args", async () => {
		const host = makeMockHost();
		await expect(codeSemanticSearchTool.handler({ wrong: "shape" } as unknown, host)).rejects.toThrow(
			/invalid args/,
		);
	});

	it("truncates long snippets so the result stays bounded", async () => {
		const host = makeMockHost();
		const longContent = "x".repeat(2000);
		const fake = makeFakeIndex(
			[
				{
					filePath: "huge.ts",
					startLine: 1,
					endLine: 100,
					content: longContent,
					score: 0.5,
				},
			],
			[],
		);
		(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
		const out = (await codeSemanticSearchTool.handler({ query: "x" }, host)) as string;
		expect(out).toContain("(truncated)");
		// Sanity: should be much shorter than the raw 2000-char snippet.
		expect(out.length).toBeLessThan(1500);
	});

	it("forwards extension filters to the index", async () => {
		const host = makeMockHost();
		const calls: { exts?: readonly string[] }[] = [];
		const fake: CodebaseSearchProvider = {
			async query(_text, opts) {
				calls.push({ exts: opts?.filter?.extensions });
				return [];
			},
		};
		(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
		await codeSemanticSearchTool.handler({ query: "x", extensions: ["ts", "tsx"] }, host);
		expect(calls[0].exts).toEqual(["ts", "tsx"]);
	});

	// Phase 1.2: hybrid retrieval — verify the ripgrep-backed lexical
	// callback is wired through correctly without booting a real index.
	describe("hybrid lexical wiring", () => {
		it("does NOT attach a lexicalQuery callback for pure-English queries", async () => {
			const host = makeMockHost();
			const opts: Array<Record<string, unknown>> = [];
			const fake: CodebaseSearchProvider = {
				async query(_text, o) {
					opts.push((o ?? {}) as Record<string, unknown>);
					return [];
				},
			};
			(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
			await codeSemanticSearchTool.handler({ query: "where is authentication validated" }, host);
			expect(opts[0].lexicalQuery).toBeUndefined();
		});

		it("attaches a lexicalQuery callback when the query contains identifiers", async () => {
			const host = makeMockHost();
			const opts: Array<Record<string, unknown>> = [];
			const fake: CodebaseSearchProvider = {
				async query(_text, o) {
					opts.push((o ?? {}) as Record<string, unknown>);
					return [];
				},
			};
			(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
			await codeSemanticSearchTool.handler({ query: "find calls to authenticateUser" }, host);
			expect(typeof opts[0].lexicalQuery).toBe("function");
		});

		it("the lexical callback invokes ripgrep with the OR'd identifier regex", async () => {
			const execCalls: string[] = [];
			const host = makeMockHost({
				execHandler: async (cmd) => {
					execCalls.push(cmd);
					return { stdout: "", stderr: "", exitCode: 1 }; // no matches
				},
			});
			let capturedCallback: ((q: string) => Promise<readonly unknown[]>) | undefined;
			const fake: CodebaseSearchProvider = {
				async query(_text, o) {
					capturedCallback = (o as { lexicalQuery?: typeof capturedCallback })?.lexicalQuery;
					return [];
				},
			};
			(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
			await codeSemanticSearchTool.handler({ query: "look at run_tests and chargeCard" }, host);
			expect(capturedCallback).toBeDefined();
			await capturedCallback?.("look at run_tests and chargeCard");
			expect(execCalls).toHaveLength(1);
			const cmd = execCalls[0];
			expect(cmd).toMatch(/^rg /);
			// Both identifiers should appear in the OR'd regex.
			expect(cmd).toContain("run_tests");
			expect(cmd).toContain("chargeCard");
		});

		it("the lexical callback degrades to empty results when ripgrep is unavailable", async () => {
			const host = makeMockHost({
				execHandler: async () => {
					throw new Error("rg not found");
				},
			});
			let capturedCallback: ((q: string) => Promise<readonly unknown[]>) | undefined;
			const fake: CodebaseSearchProvider = {
				async query(_text, o) {
					capturedCallback = (o as { lexicalQuery?: typeof capturedCallback })?.lexicalQuery;
					return [];
				},
			};
			(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
			await codeSemanticSearchTool.handler({ query: "find authenticateUser" }, host);
			const out = await capturedCallback?.("find authenticateUser");
			// Did NOT throw; returned an empty ranking so RRF falls back to
			// pure semantic.
			expect(out).toEqual([]);
		});

		it("does NOT attach a rerank option when ctx.rerankerLlmCall is absent (default off)", async () => {
			const host = makeMockHost();
			const opts: Array<Record<string, unknown>> = [];
			const fake: CodebaseSearchProvider = {
				async query(_text, o) {
					opts.push((o ?? {}) as Record<string, unknown>);
					return [];
				},
			};
			(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
			await codeSemanticSearchTool.handler({ query: "find authenticateUser" }, host);
			expect(opts[0].rerank).toBeUndefined();
		});

		it("attaches a rerank option carrying the callLlm when ctx.rerankerLlmCall is set", async () => {
			const host = makeMockHost();
			const fakeLlmCall = vi.fn(async () => "1:8");
			(
				host as unknown as {
					rerankerLlmCall: typeof fakeLlmCall;
				}
			).rerankerLlmCall = fakeLlmCall;
			const opts: Array<Record<string, unknown>> = [];
			const fake: CodebaseSearchProvider = {
				async query(_text, o) {
					opts.push((o ?? {}) as Record<string, unknown>);
					return [];
				},
			};
			(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
			await codeSemanticSearchTool.handler({ query: "find authenticateUser" }, host);
			const rerank = opts[0].rerank as { callLlm?: unknown } | undefined;
			expect(rerank).toBeDefined();
			expect(rerank?.callLlm).toBe(fakeLlmCall);
		});

		it("the lexical callback parses ripgrep JSON match events into SearchResults", async () => {
			const sampleStdout = [
				JSON.stringify({
					type: "begin",
					data: { path: { text: "src/auth.ts" } },
				}),
				JSON.stringify({
					type: "match",
					data: {
						path: { text: "./src/auth.ts" },
						line_number: 42,
						lines: { text: "  authenticateUser(name)\n" },
					},
				}),
				JSON.stringify({ type: "end", data: {} }),
			].join("\n");
			const host = makeMockHost({
				execHandler: async () => ({ stdout: sampleStdout, stderr: "", exitCode: 0 }),
			});
			let capturedCallback:
				| ((q: string) => Promise<ReadonlyArray<{ filePath: string; startLine: number }>>)
				| undefined;
			const fake: CodebaseSearchProvider = {
				async query(_text, o) {
					capturedCallback = (o as { lexicalQuery?: typeof capturedCallback })?.lexicalQuery;
					return [];
				},
			};
			(host as unknown as { codebaseIndex: CodebaseSearchProvider }).codebaseIndex = fake;
			await codeSemanticSearchTool.handler({ query: "find authenticateUser" }, host);
			const out = await capturedCallback?.("find authenticateUser");
			expect(out).toHaveLength(1);
			expect(out?.[0].filePath).toBe("src/auth.ts"); // ./prefix stripped
			expect(out?.[0].startLine).toBe(42);
		});
	});
});
