import type { BackgroundProcessHandle, BackgroundProcessOptions } from "@oati/shared";
import { describe, expect, it } from "vitest";
import {
	listBackgroundProcessesTool,
	startBackgroundProcessTool,
	stopBackgroundProcessTool,
} from "../src/background-process";
import { makeMockHost } from "./mock-host";

// Use a real-ish handle factory so we don't have to repeat shape literals.
function fakeHandle(overrides: Partial<BackgroundProcessHandle> = {}): BackgroundProcessHandle {
	return {
		pid: 12345,
		command: "python -m http.server 8000",
		cwd: "/test",
		label: "python -m http.server 8000",
		startedAt: Date.now(),
		earlyStdout: "Serving HTTP on 0.0.0.0 port 8000\n",
		earlyStderr: "",
		...overrides,
	};
}

describe("start_background_process tool", () => {
	it("rejects malformed args", async () => {
		const host = makeMockHost();
		await expect(
			startBackgroundProcessTool.handler({ wrong: "shape" } as unknown, host),
		).rejects.toThrow(/invalid args/);
		await expect(
			startBackgroundProcessTool.handler({ command: "" } as unknown, host),
		).rejects.toThrow(/invalid args/);
	});

	it("surfaces a friendly error when the host doesn't support background processes", async () => {
		const host = makeMockHost();
		// Default mock host has no startBackgroundProcess
		await expect(startBackgroundProcessTool.handler({ command: "echo ok" }, host)).rejects.toThrow(
			/does not support background processes/,
		);
	});

	it("passes command + options through to the host and returns a flat status payload", async () => {
		const host = makeMockHost();
		const calls: Array<{ command: string; opts?: BackgroundProcessOptions }> = [];
		(
			host as unknown as {
				startBackgroundProcess: (
					command: string,
					opts?: BackgroundProcessOptions,
				) => Promise<BackgroundProcessHandle>;
			}
		).startBackgroundProcess = async (command, opts) => {
			calls.push({ command, opts });
			return fakeHandle({ command });
		};
		const result = (await startBackgroundProcessTool.handler(
			{
				command: "python -m http.server 8000",
				cwd: "/tmp",
				waitForOutputMs: 2000,
				label: "docs site",
			},
			host,
		)) as Record<string, unknown>;
		expect(calls).toHaveLength(1);
		expect(calls[0].command).toBe("python -m http.server 8000");
		expect(calls[0].opts).toEqual({
			cwd: "/tmp",
			waitForOutputMs: 2000,
			label: "docs site",
		});
		expect(result.pid).toBe(12345);
		expect(result.status).toBe("running");
		expect(result.earlyStdout).toMatch(/Serving HTTP/);
	});

	it("surfaces a warning when the process exited during the wait window", async () => {
		const host = makeMockHost();
		(
			host as unknown as {
				startBackgroundProcess: (
					command: string,
					opts?: BackgroundProcessOptions,
				) => Promise<BackgroundProcessHandle>;
			}
		).startBackgroundProcess = async () =>
			fakeHandle({
				exitedDuringWait: 1,
				earlyStdout: "",
				earlyStderr: "ModuleNotFoundError: No module named 'flask'\n",
			});
		const result = (await startBackgroundProcessTool.handler(
			{ command: "flask run" },
			host,
		)) as Record<string, unknown>;
		expect(result.exitedDuringWait).toBe(1);
		expect(result.warning).toMatch(/exited during the wait window/);
		expect(result.status).toBeUndefined(); // status is "running" only when alive
	});

	it("only sends defined options (no undefined fields leak to the host)", async () => {
		const host = makeMockHost();
		const captured: Array<{ opts?: BackgroundProcessOptions }> = [];
		(
			host as unknown as {
				startBackgroundProcess: (
					command: string,
					opts?: BackgroundProcessOptions,
				) => Promise<BackgroundProcessHandle>;
			}
		).startBackgroundProcess = async (_c, opts) => {
			captured.push({ opts });
			return fakeHandle();
		};
		await startBackgroundProcessTool.handler({ command: "echo ok" }, host);
		// Minimal call should send an EMPTY options object, not {cwd: undefined, ...}.
		expect(captured[0].opts).toEqual({});
	});
});

describe("stop_background_process tool", () => {
	it("rejects non-positive / non-integer pids", async () => {
		const host = makeMockHost();
		await expect(stopBackgroundProcessTool.handler({ pid: 0 }, host)).rejects.toThrow(/invalid args/);
		await expect(stopBackgroundProcessTool.handler({ pid: -1 }, host)).rejects.toThrow(
			/invalid args/,
		);
		await expect(stopBackgroundProcessTool.handler({ pid: "abc" } as unknown, host)).rejects.toThrow(
			/invalid args/,
		);
	});

	it("forwards pid to the host", async () => {
		const host = makeMockHost();
		const calls: number[] = [];
		(
			host as unknown as {
				stopBackgroundProcess: (pid: number) => Promise<{ killed: boolean }>;
			}
		).stopBackgroundProcess = async (pid) => {
			calls.push(pid);
			return { killed: true };
		};
		const out = (await stopBackgroundProcessTool.handler({ pid: 9999 }, host)) as {
			killed: boolean;
		};
		expect(calls).toEqual([9999]);
		expect(out.killed).toBe(true);
	});

	it("returns {killed:false} when the pid is unknown", async () => {
		const host = makeMockHost();
		(
			host as unknown as {
				stopBackgroundProcess: (pid: number) => Promise<{ killed: boolean }>;
			}
		).stopBackgroundProcess = async () => ({ killed: false });
		const out = (await stopBackgroundProcessTool.handler({ pid: 42 }, host)) as {
			killed: boolean;
		};
		expect(out.killed).toBe(false);
	});
});

describe("list_background_processes tool", () => {
	it("returns the host's running list as { running: [...] }", async () => {
		const host = makeMockHost();
		const handles = [fakeHandle({ pid: 1 }), fakeHandle({ pid: 2, command: "npm run dev" })];
		(
			host as unknown as {
				listBackgroundProcesses: () => readonly BackgroundProcessHandle[];
			}
		).listBackgroundProcesses = () => handles;
		const out = (await listBackgroundProcessesTool.handler({}, host)) as {
			running: readonly BackgroundProcessHandle[];
		};
		expect(out.running).toHaveLength(2);
		expect(out.running[0].pid).toBe(1);
		expect(out.running[1].command).toBe("npm run dev");
	});

	it("surfaces a friendly error when the host doesn't support background processes", async () => {
		const host = makeMockHost();
		await expect(listBackgroundProcessesTool.handler({}, host)).rejects.toThrow(
			/does not support background processes/,
		);
	});
});
