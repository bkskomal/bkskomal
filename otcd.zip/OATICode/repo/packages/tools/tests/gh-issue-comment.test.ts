import { describe, expect, it } from "vitest";
import { ghIssueCommentTool } from "../src/gh-issue-comment";
import { makeMockHost } from "./mock-host";

describe("gh_issue_comment tool", () => {
	it("is approval-gated", () => {
		expect(ghIssueCommentTool.approval).toBe("prompt");
	});

	it("rejects when body is missing", async () => {
		await expect(
			ghIssueCommentTool.handler({ url: "https://github.com/x/y/issues/1" }, makeMockHost()),
		).rejects.toThrow(/invalid args/);
	});

	it("returns an error when ref cannot be resolved", async () => {
		const host = makeMockHost();
		const r = (await ghIssueCommentTool.handler({ body: "hello" }, host)) as {
			ok: boolean;
			message: string;
		};
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/provide either/);
	});

	it("surfaces a friendly install message when gh is missing", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "", stderr: "not found", exitCode: 1 }),
		});
		const r = (await ghIssueCommentTool.handler(
			{ url: "https://github.com/x/y/issues/1", body: "hello" },
			host,
		)) as { ok: boolean; message: string };
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/GitHub CLI/);
	});

	it("calls gh issue comment with the right args on success", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (!cmd.includes("issue comment")) {
					return { stdout: "/usr/bin/gh", stderr: "", exitCode: 0 };
				}
				return {
					stdout: "https://github.com/x/y/issues/1#issuecomment-12345\n",
					stderr: "",
					exitCode: 0,
				};
			},
		});
		const r = (await ghIssueCommentTool.handler(
			{ owner: "x", repo: "y", number: 1, body: "ack" },
			host,
		)) as { ok: boolean; url?: string };
		expect(r.ok).toBe(true);
		expect(r.url).toMatch(/issuecomment-12345/);

		const cmd = host.execCalls[1].command;
		expect(cmd).toMatch(/gh issue comment 1/);
		expect(cmd).toMatch(/-R\s+/);
		expect(cmd).toMatch(/x\/y/);
		expect(cmd).toMatch(/-b/);
		expect(cmd).toMatch(/ack/);
	});

	it("surfaces an auth hint when gh complains about auth", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (!cmd.includes("issue comment")) {
					return { stdout: "/usr/bin/gh", stderr: "", exitCode: 0 };
				}
				return { stdout: "", stderr: "gh auth login required", exitCode: 4 };
			},
		});
		const r = (await ghIssueCommentTool.handler(
			{ url: "https://github.com/x/y/issues/1", body: "ack" },
			host,
		)) as { ok: boolean; message: string };
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/gh auth login/);
	});

	it("emits an approval preview note", async () => {
		const preview = await ghIssueCommentTool.prepareApprovalPreview?.(
			{ url: "https://github.com/x/y/issues/7", body: "hello world" },
			makeMockHost(),
		);
		expect(preview?.note).toMatch(/x\/y#7/);
		expect(preview?.note).toMatch(/hello world/);
	});
});
