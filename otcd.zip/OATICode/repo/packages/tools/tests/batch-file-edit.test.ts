import type { HostContext } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { batchFileEditTool } from "../src/batch-file-edit";

function mockHost(files: Record<string, string>): HostContext {
	const memory: Record<string, string> = { ...files };
	return {
		async readFile(p: string) {
			if (!(p in memory)) throw new Error(`ENOENT ${p}`);
			return memory[p];
		},
		async writeFile(p: string, content: string) {
			memory[p] = content;
		},
		async writeFileStreaming(p: string, content: string) {
			memory[p] = content;
		},
		async fileExists(p: string) {
			return p in memory;
		},
		async exec() {
			return { stdout: "", stderr: "", exitCode: 0 };
		},
		workspaceRoot() {
			return "/work";
		},
		async requestApproval() {
			return true;
		},
		async showDiff() {
			/* noop */
		},
		log() {
			/* noop */
		},
		__getMemory: () => memory,
	} as unknown as HostContext & { __getMemory: () => Record<string, string> };
}

describe("batch_file_edit", () => {
	it("applies a simple rename across two files", async () => {
		const host = mockHost({
			"a.ts": "export const parseFoo = (x) => x;",
			"b.ts": "import { parseFoo } from './a'; parseFoo(1);",
		});
		const result = (await batchFileEditTool.handler(
			{
				edits: [
					{ path: "a.ts", before: "parseFoo", after: "parseBar" },
					{
						path: "b.ts",
						before: "import { parseFoo } from './a'; parseFoo(1);",
						after: "import { parseBar } from './a'; parseBar(1);",
					},
				],
			},
			host,
		)) as { applied: number; skipped: number; results: { path: string; status: string }[] };
		expect(result.applied).toBe(2);
		expect(result.skipped).toBe(0);
		const mem = (host as unknown as { __getMemory: () => Record<string, string> }).__getMemory();
		expect(mem["a.ts"]).toBe("export const parseBar = (x) => x;");
		expect(mem["b.ts"]).toBe("import { parseBar } from './a'; parseBar(1);");
	});

	it("skips entries where `before` matches zero locations", async () => {
		const host = mockHost({ "x.ts": "const foo = 1;" });
		const result = (await batchFileEditTool.handler(
			{ edits: [{ path: "x.ts", before: "bar", after: "baz" }] },
			host,
		)) as { applied: number; skipped: number; results: { reason?: string }[] };
		expect(result.applied).toBe(0);
		expect(result.skipped).toBe(1);
		expect(result.results[0].reason).toMatch(/not found/i);
	});

	it("skips entries where `before` matches multiple locations", async () => {
		const host = mockHost({ "x.ts": "foo foo foo" });
		const result = (await batchFileEditTool.handler(
			{ edits: [{ path: "x.ts", before: "foo", after: "bar" }] },
			host,
		)) as { applied: number; skipped: number; results: { reason?: string }[] };
		expect(result.applied).toBe(0);
		expect(result.skipped).toBe(1);
		expect(result.results[0].reason).toMatch(/3 location/i);
	});

	it("handles multiple distinct edits to the same file in sequence", async () => {
		// First edit changes part of the file; the second edit's `before`
		// must match the result of the first.
		const host = mockHost({
			"a.ts": "const x = 1; const y = 2;",
		});
		const result = (await batchFileEditTool.handler(
			{
				edits: [
					{ path: "a.ts", before: "const x = 1;", after: "const x = 10;" },
					{ path: "a.ts", before: "const y = 2;", after: "const y = 20;" },
				],
			},
			host,
		)) as { applied: number; skipped: number };
		expect(result.applied).toBe(2);
		const mem = (host as unknown as { __getMemory: () => Record<string, string> }).__getMemory();
		expect(mem["a.ts"]).toBe("const x = 10; const y = 20;");
	});

	it("mixed: some succeed, some fail — successful writes still commit", async () => {
		const host = mockHost({
			"a.ts": "alpha",
			"b.ts": "beta",
		});
		const result = (await batchFileEditTool.handler(
			{
				edits: [
					{ path: "a.ts", before: "alpha", after: "ALPHA" }, // ok
					{ path: "b.ts", before: "zeta", after: "ZETA" }, // not found
				],
			},
			host,
		)) as { applied: number; skipped: number };
		expect(result.applied).toBe(1);
		expect(result.skipped).toBe(1);
		const mem = (host as unknown as { __getMemory: () => Record<string, string> }).__getMemory();
		expect(mem["a.ts"]).toBe("ALPHA");
		expect(mem["b.ts"]).toBe("beta"); // unchanged
	});

	it("treats empty `after` as deletion of the matched range", async () => {
		const host = mockHost({ "a.ts": "// TODO: kill this comment\ncode" });
		const result = (await batchFileEditTool.handler(
			{
				edits: [{ path: "a.ts", before: "// TODO: kill this comment\n", after: "" }],
			},
			host,
		)) as { applied: number };
		expect(result.applied).toBe(1);
		const mem = (host as unknown as { __getMemory: () => Record<string, string> }).__getMemory();
		expect(mem["a.ts"]).toBe("code");
	});

	it("returns empty result for an empty edit list", async () => {
		const host = mockHost({});
		const result = (await batchFileEditTool.handler({ edits: [] }, host)) as {
			applied: number;
			skipped: number;
		};
		expect(result.applied).toBe(0);
		expect(result.skipped).toBe(0);
	});

	it("throws on invalid args shape", async () => {
		const host = mockHost({});
		await expect(batchFileEditTool.handler({ wrong: "shape" } as unknown, host)).rejects.toThrow(
			/invalid args/,
		);
	});

	describe("prepareApprovalPreview (2026-06-02: multi-file diffs)", () => {
		it("populates a `diffs` array with one entry per affected file", async () => {
			const host = mockHost({
				"a.ts": "export const x = 1;",
				"b.ts": "import { x } from './a';",
			});
			const preview = await batchFileEditTool.prepareApprovalPreview?.(
				{
					edits: [
						{ path: "a.ts", before: "const x = 1", after: "const x = 2" },
						{ path: "b.ts", before: "import { x }", after: "import { y }" },
					],
				},
				host,
			);
			expect(preview?.diffs).toHaveLength(2);
			expect(preview?.diffs?.[0].path).toBe("a.ts");
			expect(preview?.diffs?.[0].after).toContain("const x = 2");
			expect(preview?.diffs?.[1].path).toBe("b.ts");
			expect(preview?.diffs?.[1].after).toContain("import { y }");
			// `diff` stays populated as the single-file fallback (= diffs[0]).
			expect(preview?.diff).toBeDefined();
			expect(preview?.diff?.path).toBe("a.ts");
		});

		it("composes multiple edits to the same file into ONE cumulative diff (not one per edit)", async () => {
			const host = mockHost({
				"a.ts": "let foo = 1;\nlet bar = 2;\nlet baz = 3;",
			});
			const preview = await batchFileEditTool.prepareApprovalPreview?.(
				{
					edits: [
						{ path: "a.ts", before: "let foo = 1;", after: "const foo = 1;" },
						{ path: "a.ts", before: "let bar = 2;", after: "const bar = 2;" },
						{ path: "a.ts", before: "let baz = 3;", after: "const baz = 3;" },
					],
				},
				host,
			);
			// One file → one diff entry, with all three edits composed.
			expect(preview?.diffs).toHaveLength(1);
			const after = preview?.diffs?.[0].after ?? "";
			expect(after).toContain("const foo");
			expect(after).toContain("const bar");
			expect(after).toContain("const baz");
			expect(after).not.toContain("let foo");
		});

		it("preserves entry order matching the original edit list", async () => {
			const host = mockHost({ "z.ts": "z", "a.ts": "a", "m.ts": "m" });
			const preview = await batchFileEditTool.prepareApprovalPreview?.(
				{
					edits: [
						{ path: "z.ts", before: "z", after: "Z" },
						{ path: "a.ts", before: "a", after: "A" },
						{ path: "m.ts", before: "m", after: "M" },
					],
				},
				host,
			);
			// Order follows first-appearance in the edits array, NOT alphabetical.
			expect(preview?.diffs?.map((d) => d.path)).toEqual(["z.ts", "a.ts", "m.ts"]);
		});

		it("returns empty preview for an empty edits list", async () => {
			const host = mockHost({});
			const preview = await batchFileEditTool.prepareApprovalPreview?.({ edits: [] }, host);
			expect(preview).toEqual({});
		});
	});
});
