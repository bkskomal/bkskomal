import { describe, expect, it } from "vitest";
import { __test, ghIssueReadTool } from "../src/gh-issue-read";
import { makeMockHost } from "./mock-host";

describe("parseIssueUrl", () => {
	const { parseIssueUrl } = __test;

	it("parses canonical github issue urls", () => {
		expect(parseIssueUrl("https://github.com/foo/bar/issues/42")).toEqual({
			owner: "foo",
			repo: "bar",
			number: 42,
		});
	});

	it("returns undefined for non-issue urls", () => {
		expect(parseIssueUrl("https://github.com/foo/bar/pull/42")).toBeUndefined();
		expect(parseIssueUrl("https://example.com")).toBeUndefined();
	});
});

describe("resolveIssueRef", () => {
	const { resolveIssueRef } = __test;

	it("prefers url when both url and triplet are present", () => {
		expect(
			resolveIssueRef({
				url: "https://github.com/u/r/issues/7",
				owner: "x",
				repo: "y",
				number: 1,
			}),
		).toEqual({ owner: "u", repo: "r", number: 7 });
	});

	it("falls back to triplet when no url", () => {
		expect(resolveIssueRef({ owner: "u", repo: "r", number: 7 })).toEqual({
			owner: "u",
			repo: "r",
			number: 7,
		});
	});

	it("returns undefined when neither is complete", () => {
		expect(resolveIssueRef({})).toBeUndefined();
		expect(resolveIssueRef({ owner: "u" })).toBeUndefined();
	});
});

describe("gh_issue_read tool", () => {
	it("is auto-approved", () => {
		expect(ghIssueReadTool.approval).toBe("auto");
	});

	it("rejects when no ref is provided", async () => {
		const host = makeMockHost();
		const r = (await ghIssueReadTool.handler({}, host)) as { ok: boolean; message?: string };
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/provide either/);
	});

	it("surfaces a friendly install message when gh is missing", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (cmd.includes("where gh") || cmd.includes("command -v gh")) {
					return { stdout: "", stderr: "not found", exitCode: 1 };
				}
				return { stdout: "", stderr: "", exitCode: 0 };
			},
		});
		const r = (await ghIssueReadTool.handler({ url: "https://github.com/u/r/issues/1" }, host)) as {
			ok: boolean;
			message?: string;
		};
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/GitHub CLI/);
	});

	it("calls gh issue view with the right args and parses the JSON output", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (!cmd.includes("issue view")) {
					return { stdout: "/usr/bin/gh", stderr: "", exitCode: 0 };
				}
				return {
					stdout: JSON.stringify({
						title: "Bug: crash on startup",
						body: "Steps to reproduce…",
						labels: [{ name: "bug" }, { name: "p1" }],
						assignees: [{ login: "alice" }],
						comments: [
							{ author: { login: "bob" }, body: "I see this too" },
							{ author: { login: "carol" }, body: "Repro on macOS" },
						],
					}),
					stderr: "",
					exitCode: 0,
				};
			},
		});
		const r = (await ghIssueReadTool.handler(
			{ url: "https://github.com/foo/bar/issues/42" },
			host,
		)) as {
			ok: boolean;
			title?: string;
			labels?: string[];
			assignees?: string[];
			comments?: Array<{ author: string; body: string }>;
		};
		expect(r.ok).toBe(true);
		expect(r.title).toBe("Bug: crash on startup");
		expect(r.labels).toEqual(["bug", "p1"]);
		expect(r.assignees).toEqual(["alice"]);
		expect(r.comments).toHaveLength(2);
		expect(r.comments?.[0]).toEqual({ author: "bob", body: "I see this too" });

		const viewCmd = host.execCalls[1].command;
		expect(viewCmd).toMatch(/gh issue view 42/);
		expect(viewCmd).toMatch(/-R\s+/);
		expect(viewCmd).toMatch(/foo\/bar/);
		expect(viewCmd).toMatch(/--json/);
	});

	it("returns an error when gh exits non-zero", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (!cmd.includes("issue view")) {
					return { stdout: "/usr/bin/gh", stderr: "", exitCode: 0 };
				}
				return { stdout: "", stderr: "could not resolve to an issue", exitCode: 1 };
			},
		});
		const r = (await ghIssueReadTool.handler({ owner: "x", repo: "y", number: 1 }, host)) as {
			ok: boolean;
			message?: string;
		};
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/gh issue view failed/);
	});
});
