import type { HostContext, PersistentFact } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { recallFactsTool } from "../src/recall-facts";
import { rememberFactTool } from "../src/remember-fact";
import { makeMockHost } from "./mock-host";

/**
 * Wrap a MockHost with an in-memory facts store. Mirrors the addFact dedupe
 * behavior so the tool's idempotency check exercises the real branch.
 */
function withFactStore(
	host: HostContext,
	initial: PersistentFact[] = [],
): {
	host: HostContext;
	facts: PersistentFact[];
} {
	const facts = [...initial];
	const wrapped: HostContext = {
		...host,
		async loadFacts() {
			return [...facts];
		},
		async addFact({ fact, source }) {
			const norm = fact.replace(/\s+/g, " ").trim().toLowerCase();
			if (!facts.some((f) => f.fact.replace(/\s+/g, " ").trim().toLowerCase() === norm)) {
				facts.push({
					id: `f_${facts.length + 1}`,
					fact: fact.trim(),
					addedAt: "2026-05-20T00:00:00Z",
					source: source ?? "agent",
				});
			}
			return [...facts];
		},
	};
	return { host: wrapped, facts };
}

describe("remember_fact tool", () => {
	it("appends a new fact and returns a confirmation string", async () => {
		const base = makeMockHost();
		const { host, facts } = withFactStore(base);
		const out = (await rememberFactTool.handler({ fact: "Tests live under tests/" }, host)) as string;
		expect(out).toMatch(/Remembered/i);
		expect(facts).toHaveLength(1);
		expect(facts[0].fact).toBe("Tests live under tests/");
	});

	it("is idempotent on duplicate fact text", async () => {
		const base = makeMockHost();
		const { host, facts } = withFactStore(base, [
			{ id: "f_1", fact: "Snake case in Python", addedAt: "x", source: "agent" },
		]);
		const out = (await rememberFactTool.handler({ fact: "snake case in python" }, host)) as string;
		expect(out).toMatch(/already known/i);
		expect(facts).toHaveLength(1);
	});

	it("rejects empty fact strings", async () => {
		const base = makeMockHost();
		const { host } = withFactStore(base);
		await expect(rememberFactTool.handler({ fact: "  " }, host)).rejects.toThrow(/invalid args/);
	});

	it("throws when the host does not expose addFact", async () => {
		const host = makeMockHost();
		await expect(rememberFactTool.handler({ fact: "anything" }, host)).rejects.toThrow(/not enabled/);
	});

	it("forwards an optional source tag", async () => {
		const base = makeMockHost();
		const { host, facts } = withFactStore(base);
		await rememberFactTool.handler({ fact: "a", source: "user" }, host);
		expect(facts[0].source).toBe("user");
	});

	it("is auto-approve so the loop doesn't gate routine learning", () => {
		expect(rememberFactTool.approval).toBe("auto");
	});
});

describe("recall_facts tool", () => {
	it("lists every fact when no query is supplied", async () => {
		const base = makeMockHost();
		const { host } = withFactStore(base, [
			{ id: "1", fact: "alpha", addedAt: "x", source: "agent" },
			{ id: "2", fact: "beta", addedAt: "x", source: "user" },
		]);
		const out = (await recallFactsTool.handler({}, host)) as string;
		expect(out).toContain("alpha");
		expect(out).toContain("beta");
		expect(out).toMatch(/^2 facts/);
	});

	it("filters by case-insensitive substring", async () => {
		const base = makeMockHost();
		const { host } = withFactStore(base, [
			{ id: "1", fact: "Snake case for Python", addedAt: "x", source: "agent" },
			{ id: "2", fact: "camelCase for JavaScript", addedAt: "x", source: "agent" },
		]);
		const out = (await recallFactsTool.handler({ query: "python" }, host)) as string;
		expect(out).toContain("Snake case for Python");
		expect(out).not.toContain("camelCase for JavaScript");
	});

	it("returns a friendly message when no facts match the query", async () => {
		const base = makeMockHost();
		const { host } = withFactStore(base, [{ id: "1", fact: "alpha", addedAt: "x", source: "agent" }]);
		const out = (await recallFactsTool.handler({ query: "zzz" }, host)) as string;
		expect(out).toMatch(/no facts match/i);
	});

	it("returns a friendly message when the store is empty", async () => {
		const base = makeMockHost();
		const { host } = withFactStore(base);
		const out = (await recallFactsTool.handler({}, host)) as string;
		expect(out).toMatch(/no persistent facts/i);
	});

	it("returns a friendly message when the host does not expose loadFacts", async () => {
		const host = makeMockHost();
		const out = (await recallFactsTool.handler({}, host)) as string;
		expect(out).toMatch(/not enabled/i);
	});
});
