import { describe, expect, it } from "vitest";
import { __test, gitStatusTool } from "../src/git-status";
import { makeMockHost } from "./mock-host";

describe("git_status tool", () => {
	it("is read-only (auto approval)", () => {
		expect(gitStatusTool.approval).toBe("auto");
	});

	it("invokes git with --porcelain=v1 -b", async () => {
		const host = makeMockHost({
			execHandler: async () => ({
				stdout: "## main...origin/main\n M src/foo.ts\nA  src/bar.ts\n?? notes.txt\n",
				stderr: "",
				exitCode: 0,
			}),
		});
		const result = (await gitStatusTool.handler({}, host)) as ReturnType<typeof __test.parseStatus>;
		expect(host.execCalls[0].command).toBe("git status --porcelain=v1 -b");
		expect(result.branch).toBe("main");
		expect(result.staged).toEqual(["src/bar.ts"]);
		expect(result.unstaged).toEqual(["src/foo.ts"]);
		expect(result.untracked).toEqual(["notes.txt"]);
		expect(result.clean).toBe(false);
	});

	it("reports clean when nothing changed", async () => {
		const host = makeMockHost({
			execHandler: async () => ({
				stdout: "## main...origin/main\n",
				stderr: "",
				exitCode: 0,
			}),
		});
		const result = (await gitStatusTool.handler({}, host)) as ReturnType<typeof __test.parseStatus>;
		expect(result.clean).toBe(true);
		expect(result.staged).toEqual([]);
		expect(result.unstaged).toEqual([]);
		expect(result.untracked).toEqual([]);
	});

	it("throws when git fails", async () => {
		const host = makeMockHost({
			execHandler: async () => ({
				stdout: "",
				stderr: "fatal: not a git repository",
				exitCode: 128,
			}),
		});
		await expect(gitStatusTool.handler({}, host)).rejects.toThrow(/git status failed/);
	});

	it("handles renames", () => {
		const parsed = __test.parseStatus("## main\nR  src/old.ts -> src/new.ts\n");
		expect(parsed.staged).toEqual(["src/new.ts"]);
	});
});
