import type { HostContext } from "@oati/shared";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Mock the shared browser-state module so we can drive `getOrLaunch` from the
// test without spawning an actual Chrome. `browser_open` resolves this via
// the package barrel-free path, so we mock the same specifier it imports.
const launchMock = vi.fn<[], Promise<unknown>>();

vi.mock("../src/browser-state", async () => {
	// Pull in the real exports so `BrowserUnavailableError` keeps a proper
	// constructor (the tool's `instanceof` check depends on it).
	const actual =
		await vi.importActual<typeof import("../src/browser-state")>("../src/browser-state");
	return {
		...actual,
		getOrLaunch: () => launchMock(),
	};
});

import { browserOpenTool } from "../src/browser-open";
import { BrowserUnavailableError, discoverChromeExecutablePath } from "../src/browser-state";

function mockHost(): HostContext {
	const logs: Array<{ level: string; message: string }> = [];
	const host = {
		async readFile() {
			return "";
		},
		async writeFile() {},
		async fileExists() {
			return false;
		},
		async exec() {
			return { stdout: "", stderr: "", exitCode: 0 };
		},
		workspaceRoot() {
			return "/work";
		},
		async requestApproval() {
			return true;
		},
		async showDiff() {},
		log(level: string, message: string) {
			logs.push({ level, message });
		},
		__logs: logs,
	} as unknown as HostContext & { __logs: typeof logs };
	return host;
}

describe("BrowserUnavailableError", () => {
	it("constructs a friendly message with install hint when no attempts are passed", () => {
		const err = new BrowserUnavailableError();
		expect(err.message).toMatch(/puppeteer-core/);
		expect(err.message).toMatch(/OATI_CHROME_PATH/);
		expect(err.attempts).toEqual([]);
	});

	it("lists each failed launch attempt when provided", () => {
		const err = new BrowserUnavailableError([
			"channel:chrome: Browser was not found",
			"probed:/usr/bin/chromium: ENOENT",
		]);
		expect(err.message).toContain("channel:chrome");
		expect(err.message).toContain("probed:/usr/bin/chromium");
		expect(err.attempts).toHaveLength(2);
	});
});

describe("discoverChromeExecutablePath", () => {
	it("returns either a string path or undefined without throwing", () => {
		// Whatever the test machine actually has — what matters is that the
		// probe doesn't crash on missing env vars or permission errors.
		const result = discoverChromeExecutablePath();
		expect(result === undefined || typeof result === "string").toBe(true);
	});
});

describe("browser_open fallback", () => {
	beforeEach(() => {
		launchMock.mockReset();
	});

	it("returns a URL-only result with `fallback` when puppeteer is unavailable", async () => {
		launchMock.mockRejectedValueOnce(
			new BrowserUnavailableError([
				"channel:chrome: Browser was not found at the configured executablePath",
			]),
		);
		const host = mockHost();
		const result = (await browserOpenTool.handler({ url: "http://localhost:3000" }, host)) as {
			title: string;
			url: string;
			statusCode: number | null;
			fallback?: string;
		};
		expect(result.title).toMatch(/preview unavailable/);
		expect(result.url).toBe("http://localhost:3000/");
		expect(result.statusCode).toBeNull();
		expect(result.fallback).toBeDefined();
		expect(result.fallback).toContain("http://localhost:3000");
		expect(result.fallback).toContain("channel:chrome");
	});

	it("propagates non-BrowserUnavailableError failures (e.g. network timeout)", async () => {
		launchMock.mockRejectedValueOnce(new Error("net::ERR_CONNECTION_REFUSED"));
		const host = mockHost();
		await expect(browserOpenTool.handler({ url: "http://localhost:3000" }, host)).rejects.toThrow(
			/ERR_CONNECTION_REFUSED/,
		);
	});

	it("rejects invalid URLs before reaching the launch path", async () => {
		const host = mockHost();
		await expect(browserOpenTool.handler({ url: "not a url" }, host)).rejects.toThrow(/invalid URL/);
		// launchMock should never have been called for this case.
		expect(launchMock).not.toHaveBeenCalled();
	});

	it("rejects non-http(s) schemes", async () => {
		const host = mockHost();
		await expect(browserOpenTool.handler({ url: "file:///etc/passwd" }, host)).rejects.toThrow(
			/only http\/https/,
		);
	});
});
