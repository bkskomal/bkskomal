import { describe, expect, it } from "vitest";
import { gitOpenPrTool } from "../src/git-open-pr";
import { makeMockHost } from "./mock-host";

describe("git_open_pr tool", () => {
	it("is approval-gated", () => {
		expect(gitOpenPrTool.approval).toBe("prompt");
	});

	it("rejects bad args", async () => {
		await expect(gitOpenPrTool.handler({}, makeMockHost())).rejects.toThrow(/invalid args/);
	});

	it("returns a friendly install message when gh is missing", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (cmd.includes("where gh") || cmd.includes("command -v gh")) {
					return { stdout: "", stderr: "not found", exitCode: 1 };
				}
				return { stdout: "", stderr: "", exitCode: 0 };
			},
		});
		const r = (await gitOpenPrTool.handler({ title: "t", body: "b" }, host)) as {
			ok: boolean;
			message: string;
		};
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/GitHub CLI/);
		expect(r.message).toMatch(/cli\.github\.com/);
	});

	it("calls gh pr create with title/body when gh is present", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (cmd.includes("gh") && !cmd.includes("pr create")) {
					return { stdout: "/usr/bin/gh", stderr: "", exitCode: 0 };
				}
				return {
					stdout: "https://github.com/x/y/pull/42\n",
					stderr: "",
					exitCode: 0,
				};
			},
		});
		const r = (await gitOpenPrTool.handler({ title: "Fix bug", body: "Body here" }, host)) as {
			ok: boolean;
			url?: string;
		};
		expect(r.ok).toBe(true);
		expect(r.url).toBe("https://github.com/x/y/pull/42");
		const createCmd = host.execCalls[1].command;
		expect(createCmd).toMatch(/gh pr create/);
		expect(createCmd).toMatch(/--title/);
		expect(createCmd).toMatch(/Fix bug/);
		expect(createCmd).toMatch(/--body/);
	});

	it("surfaces an auth hint when gh complains about auth", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (!cmd.includes("pr create")) {
					return { stdout: "/usr/bin/gh", stderr: "", exitCode: 0 };
				}
				return {
					stdout: "",
					stderr: "error: gh auth login required",
					exitCode: 4,
				};
			},
		});
		const r = (await gitOpenPrTool.handler({ title: "t", body: "b" }, host)) as {
			ok: boolean;
			message: string;
		};
		expect(r.ok).toBe(false);
		expect(r.message).toMatch(/gh auth login/);
	});

	it("appends --base when provided", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => {
				if (!cmd.includes("pr create")) {
					return { stdout: "/usr/bin/gh", stderr: "", exitCode: 0 };
				}
				return { stdout: "ok", stderr: "", exitCode: 0 };
			},
		});
		await gitOpenPrTool.handler({ title: "t", body: "b", base: "develop" }, host);
		expect(host.execCalls[1].command).toMatch(/--base/);
		expect(host.execCalls[1].command).toMatch(/develop/);
	});
});
