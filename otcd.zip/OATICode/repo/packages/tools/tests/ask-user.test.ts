import type { AskUserAnswer, AskUserRequest, HostContext, ToolCallContext } from "@oati/shared";
import { describe, expect, it } from "vitest";
import { askUserTool } from "../src/ask-user";
import { makeMockHost } from "./mock-host";

const CTX: ToolCallContext = { callId: "test", agentId: "test" };

function withAskUser(handler: (req: AskUserRequest) => Promise<AskUserAnswer>) {
	const host = makeMockHost() as HostContext;
	(host as HostContext & { askUser: typeof handler }).askUser = handler;
	return host;
}

describe("ask_user tool", () => {
	it("rejects invalid args (no options)", async () => {
		await expect(
			askUserTool.handler({ question: "Hi?", options: [] }, makeMockHost(), CTX),
		).rejects.toThrow(/invalid args/i);
	});

	it("rejects when only 1 option (need >= 2)", async () => {
		await expect(
			askUserTool.handler({ question: "Hi?", options: [{ label: "yes" }] }, makeMockHost(), CTX),
		).rejects.toThrow(/invalid args/i);
	});

	it("rejects when > 6 options", async () => {
		const tooMany = Array.from({ length: 7 }, (_, i) => ({ label: `opt${i}` }));
		await expect(
			askUserTool.handler({ question: "Hi?", options: tooMany }, makeMockHost(), CTX),
		).rejects.toThrow(/invalid args/i);
	});

	it("rejects empty question", async () => {
		await expect(
			askUserTool.handler(
				{ question: "  ", options: [{ label: "a" }, { label: "b" }] },
				makeMockHost(),
				CTX,
			),
		).rejects.toThrow(/invalid args/i);
	});

	it("auto-picks option[0] when host doesn't implement askUser", async () => {
		const result = await askUserTool.handler(
			{
				question: "Which approach?",
				options: [{ label: "Refactor" }, { label: "Leave as-is" }],
			},
			makeMockHost(), // no askUser method
			CTX,
		);
		expect(result).toEqual({ answer: "Refactor", other: false, autoPicked: true });
	});

	it("forwards to host.askUser when implemented and returns the host's answer", async () => {
		const host = withAskUser(async (_req) => ({ answer: "Leave as-is", autoPicked: false }));
		const result = await askUserTool.handler(
			{
				question: "Which approach?",
				options: [{ label: "Refactor" }, { label: "Leave as-is" }],
			},
			host,
			CTX,
		);
		expect(result).toEqual({ answer: "Leave as-is", autoPicked: false });
	});

	it("passes allowOther + urgency through to the host", async () => {
		let captured: AskUserRequest | undefined;
		const host = withAskUser(async (req) => {
			captured = req;
			return { answer: req.options[0].label };
		});
		await askUserTool.handler(
			{
				question: "Do X?",
				options: [{ label: "Yes" }, { label: "No" }],
				allowOther: true,
				urgency: "high",
			},
			host,
			CTX,
		);
		expect(captured?.allowOther).toBe(true);
		expect(captured?.urgency).toBe("high");
	});

	it("generates a stable id for each call (id is a string starting with 'ask_')", async () => {
		const seenIds: string[] = [];
		const host = withAskUser(async (req) => {
			seenIds.push(req.id);
			return { answer: req.options[0].label };
		});
		const opts = { question: "X?", options: [{ label: "a" }, { label: "b" }] };
		await askUserTool.handler(opts, host, CTX);
		await askUserTool.handler(opts, host, CTX);
		expect(seenIds).toHaveLength(2);
		expect(seenIds[0]).toMatch(/^ask_/);
		expect(seenIds[1]).toMatch(/^ask_/);
		expect(seenIds[0]).not.toBe(seenIds[1]);
	});

	it("handles free-text 'Other' answer when allowOther was set", async () => {
		const host = withAskUser(async (_req) => ({
			answer: "custom suggestion the user typed",
			other: true,
		}));
		const result = await askUserTool.handler(
			{
				question: "What now?",
				options: [{ label: "Continue" }, { label: "Stop" }],
				allowOther: true,
			},
			host,
			CTX,
		);
		expect(result.other).toBe(true);
		expect((result as AskUserAnswer).answer).toContain("custom suggestion");
	});

	it("schema declares both 'question' and 'options' as required", () => {
		expect(askUserTool.schema.required).toContain("question");
		expect(askUserTool.schema.required).toContain("options");
	});

	it("approval policy is 'auto' (no user gating on the tool itself)", () => {
		expect(askUserTool.approval).toBe("auto");
	});
});
