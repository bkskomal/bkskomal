// Tests for extract_image_text — the OCR tool that complements
// browser_screenshot's pageText (which only works for live web pages)
// by handling arbitrary image files / data URLs via the system
// `tesseract` binary.

import type { ExecOptions, ExecResult } from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { extractImageTextTool } from "../src/extract-image-text";
import { makeMockHost } from "./mock-host";

const TINY_PNG_DATA_URL =
	"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";

describe("extract_image_text", () => {
	it("rejects when neither path nor dataUrl is provided", async () => {
		const host = makeMockHost();
		await expect(extractImageTextTool.handler({}, host)).rejects.toThrow(/invalid args/);
		await expect(extractImageTextTool.handler({ lang: "eng" }, host)).rejects.toThrow(/invalid args/);
	});

	it("accepts a path arg and shells out to tesseract", async () => {
		const execMock = vi.fn(
			async (_cmd: string, _opts?: ExecOptions): Promise<ExecResult> => ({
				stdout: "Hello world\nLine 2\n",
				stderr: "",
				exitCode: 0,
			}),
		);
		const host = makeMockHost({ execHandler: execMock });
		const result = (await extractImageTextTool.handler({ path: "screenshot.png" }, host)) as {
			text: string;
			chars: number;
		};
		expect(result.text).toBe("Hello world\nLine 2");
		expect(result.chars).toBe(result.text.length);
		expect(execMock).toHaveBeenCalledTimes(1);
		const cmd = execMock.mock.calls[0][0];
		expect(cmd).toMatch(/^tesseract /);
		expect(cmd).toMatch(/screenshot\.png/);
		expect(cmd).toMatch(/stdout/);
		expect(cmd).toMatch(/-l/);
	});

	it("defaults language to eng when not specified", async () => {
		const execMock = vi.fn(
			async (): Promise<ExecResult> => ({
				stdout: "out",
				stderr: "",
				exitCode: 0,
			}),
		);
		const host = makeMockHost({ execHandler: execMock });
		await extractImageTextTool.handler({ path: "x.png" }, host);
		const cmd = execMock.mock.calls[0][0];
		expect(cmd).toMatch(/-l\s+['"]?eng['"]?/);
	});

	it("forwards a custom lang arg (e.g. eng+spa)", async () => {
		const execMock = vi.fn(
			async (): Promise<ExecResult> => ({
				stdout: "Hola mundo",
				stderr: "",
				exitCode: 0,
			}),
		);
		const host = makeMockHost({ execHandler: execMock });
		await extractImageTextTool.handler({ path: "x.png", lang: "eng+spa" }, host);
		const cmd = execMock.mock.calls[0][0];
		expect(cmd).toMatch(/eng\+spa/);
	});

	it("surfaces a friendly install hint when tesseract is missing", async () => {
		const execMock = vi.fn(async (): Promise<ExecResult> => {
			throw new Error("spawn tesseract ENOENT");
		});
		const host = makeMockHost({ execHandler: execMock });
		await expect(extractImageTextTool.handler({ path: "x.png" }, host)).rejects.toThrow(
			/tesseract.*not found/i,
		);
		await expect(extractImageTextTool.handler({ path: "x.png" }, host)).rejects.toThrow(
			/brew install tesseract|apt install tesseract-ocr/i,
		);
	});

	it("surfaces a friendly language-data hint when tesseract is missing a language", async () => {
		const execMock = vi.fn(
			async (): Promise<ExecResult> => ({
				stdout: "",
				stderr: "Failed loading language 'jpn' (tessdata)",
				exitCode: 1,
			}),
		);
		const host = makeMockHost({ execHandler: execMock });
		await expect(extractImageTextTool.handler({ path: "x.png", lang: "jpn" }, host)).rejects.toThrow(
			/missing language data for 'jpn'/,
		);
	});

	it("accepts a dataUrl arg and writes a temp file before invoking tesseract", async () => {
		let observedPath: string | undefined;
		const execMock = vi.fn(async (cmd: string): Promise<ExecResult> => {
			// Capture the path tesseract was called against — it should be
			// a freshly-written temp file in the OS tmpdir.
			const m = /tesseract\s+["']?(\S+?)["']?\s+stdout/.exec(cmd);
			observedPath = m?.[1];
			return { stdout: "from-data-url\n", stderr: "", exitCode: 0 };
		});
		const host = makeMockHost({ execHandler: execMock });
		const result = (await extractImageTextTool.handler({ dataUrl: TINY_PNG_DATA_URL }, host)) as {
			text: string;
			tempFile?: string;
		};
		expect(result.text).toBe("from-data-url");
		expect(result.tempFile).toBeDefined();
		expect(observedPath).toBeDefined();
		expect(observedPath).toContain("oati-ocr-");
		expect(observedPath).toMatch(/\.png$/);
	});

	it("rejects malformed dataUrls (not data:image/...;base64,...)", async () => {
		const host = makeMockHost();
		await expect(extractImageTextTool.handler({ dataUrl: "not-a-data-url" }, host)).rejects.toThrow(
			/data:image/,
		);
	});
});
