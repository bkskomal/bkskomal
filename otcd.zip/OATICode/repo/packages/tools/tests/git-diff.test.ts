import { describe, expect, it } from "vitest";
import { gitDiffTool } from "../src/git-diff";
import { makeMockHost } from "./mock-host";

describe("git_diff tool", () => {
	it("is read-only", () => {
		expect(gitDiffTool.approval).toBe("auto");
	});

	it("runs `git diff --no-color` by default", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "diff --git a/x b/x\n+hi\n", stderr: "", exitCode: 1 }),
		});
		const r = (await gitDiffTool.handler({}, host)) as {
			diff: string;
			truncated: boolean;
			staged: boolean;
		};
		expect(host.execCalls[0].command).toBe("git diff --no-color");
		expect(r.diff).toContain("diff --git");
		expect(r.truncated).toBe(false);
		expect(r.staged).toBe(false);
	});

	it("passes --cached when staged: true", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "", stderr: "", exitCode: 0 }),
		});
		await gitDiffTool.handler({ staged: true }, host);
		expect(host.execCalls[0].command).toBe("git diff --cached --no-color");
	});

	it("appends -- and quoted path filter", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "", stderr: "", exitCode: 0 }),
		});
		await gitDiffTool.handler({ paths: ["src/foo.ts", "src/bar.ts"] }, host);
		const cmd = host.execCalls[0].command;
		expect(cmd).toContain(" -- ");
		expect(cmd).toMatch(/src[\/\\]foo\.ts/);
		expect(cmd).toMatch(/src[\/\\]bar\.ts/);
	});

	it("truncates at 200 KB and sets truncated:true", async () => {
		const big = "x".repeat(300 * 1024);
		const host = makeMockHost({
			execHandler: async () => ({ stdout: big, stderr: "", exitCode: 1 }),
		});
		const r = (await gitDiffTool.handler({}, host)) as {
			diff: string;
			truncated: boolean;
			originalBytes: number;
		};
		expect(r.truncated).toBe(true);
		expect(r.originalBytes).toBe(300 * 1024);
		expect(r.diff.length).toBeGreaterThan(200 * 1024);
		expect(r.diff).toMatch(/diff truncated/);
	});

	it("throws on real git error (exit not 0 or 1)", async () => {
		const host = makeMockHost({
			execHandler: async () => ({ stdout: "", stderr: "fatal", exitCode: 128 }),
		});
		await expect(gitDiffTool.handler({}, host)).rejects.toThrow(/git diff failed/);
	});
});
