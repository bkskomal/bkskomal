import type { ExecResult } from "@oati/shared";
import { describe, expect, it, vi } from "vitest";
import { execTool } from "../src/exec";
import { makeMockHost } from "./mock-host";

describe("exec tool", () => {
	it("forwards command and options to host.exec", async () => {
		const host = makeMockHost({
			execHandler: async (cmd) => ({
				stdout: `ran: ${cmd}`,
				stderr: "",
				exitCode: 0,
			}),
		});
		const result = await execTool.handler({ command: "echo hi", cwd: "/tmp", timeoutMs: 5000 }, host);
		// biome-ignore lint/suspicious/noExplicitAny: test cast
		const r = result as any;
		expect(r.exitCode).toBe(0);
		expect(r.stdout).toContain("echo hi");
		expect(host.execCalls).toHaveLength(1);
		expect(host.execCalls[0].command).toBe("echo hi");
		expect(host.execCalls[0].options?.cwd).toBe("/tmp");
	});

	it("uses a default timeout of 60s when none provided", async () => {
		const host = makeMockHost();
		await execTool.handler({ command: "ls" }, host);
		expect(host.execCalls[0].options?.timeoutMs).toBe(60_000);
	});

	it("rejects invalid args", async () => {
		const host = makeMockHost();
		await expect(execTool.handler({ noCommand: true }, host)).rejects.toThrow(/invalid args/);
	});

	it("is approval-gated", () => {
		expect(execTool.approval).toBe("prompt");
	});

	it("does NOT pass an onChunk callback when the host lacks emitToolProgress", async () => {
		const host = makeMockHost();
		await execTool.handler({ command: "ls" }, host, { callId: "c1", agentId: "a1" });
		expect(host.execCalls[0].options?.onChunk).toBeUndefined();
	});

	it("streams chunks to host.emitToolProgress when both callId and emitToolProgress are wired", async () => {
		const emitted: { callId: string; chunk: string }[] = [];
		const host = makeMockHost();
		host.emitToolProgress = (callId, chunk) => emitted.push({ callId, chunk });
		// Mock execHandler that pretends to stream by calling onChunk a few times.
		host.exec = vi.fn(async (_cmd, opts) => {
			opts?.onChunk?.("line 1\n", false);
			opts?.onChunk?.("line 2\n", false);
			opts?.onChunk?.("warn\n", true);
			return { stdout: "line 1\nline 2\n", stderr: "warn\n", exitCode: 0 } satisfies ExecResult;
		});
		await execTool.handler({ command: "tail -f log" }, host, { callId: "call_42", agentId: "a1" });
		expect(emitted.map((e) => e.chunk)).toEqual(["line 1\n", "line 2\n", "warn\n"]);
		expect(emitted.every((e) => e.callId === "call_42")).toBe(true);
	});

	it("respects the per-call streaming byte budget (256 KB)", async () => {
		const emitted: string[] = [];
		const host = makeMockHost();
		host.emitToolProgress = (_callId, chunk) => emitted.push(chunk);
		host.exec = vi.fn(async (_cmd, opts) => {
			// Send 5 chunks of 100 KB each — total 500 KB; only ~256 KB should make it out.
			const blob = "x".repeat(100 * 1024);
			for (let i = 0; i < 5; i++) opts?.onChunk?.(blob, false);
			return { stdout: blob.repeat(5), stderr: "", exitCode: 0 } satisfies ExecResult;
		});
		await execTool.handler({ command: "yes" }, host, { callId: "c1", agentId: "a1" });
		const total = emitted.reduce((n, c) => n + c.length, 0);
		expect(total).toBeLessThanOrEqual(256 * 1024);
		expect(total).toBeGreaterThan(0);
	});
});
