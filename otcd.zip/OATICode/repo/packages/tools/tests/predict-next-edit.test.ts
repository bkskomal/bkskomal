// R8-A: tests for the predict_next_edit_location tool.

import { describe, expect, it } from "vitest";
import { predictNextEditLocationTool } from "../src/predict-next-edit";
import { makeMockHost } from "./mock-host";

describe("predict_next_edit_location tool", () => {
	it("finds a <TODO> marker and returns a JSON hit", async () => {
		const host = makeMockHost();
		const text = "function f() { return 1; }\n\nfunction g() { <TODO> }\n";
		const out = await predictNextEditLocationTool.handler(
			{
				documentText: text,
				currentOffset: 0,
				languageId: "typescript",
			},
			host,
			{} as never,
		);
		const parsed = JSON.parse(out as string) as { offset: number; reason: string; marker: string };
		expect(parsed.reason).toBe("placeholder_marker");
		expect(parsed.marker).toBe("<TODO>");
		expect(parsed.offset).toBe(text.indexOf("<TODO>"));
	});

	it("falls back to next non-empty line when no marker present", async () => {
		const host = makeMockHost();
		const text = "line1\nline2\nline3\n";
		const out = await predictNextEditLocationTool.handler(
			{
				documentText: text,
				currentOffset: 2,
				languageId: "typescript",
			},
			host,
			{} as never,
		);
		const parsed = JSON.parse(out as string) as { offset: number; reason: string };
		expect(parsed.reason).toBe("next_nonempty_line");
		expect(parsed.offset).toBe(text.indexOf("line2"));
	});

	it("handles Python pass keyword", async () => {
		const host = makeMockHost();
		const text = "def foo():\n    pass\n";
		const out = await predictNextEditLocationTool.handler(
			{ documentText: text, currentOffset: 0, languageId: "python" },
			host,
			{} as never,
		);
		const parsed = JSON.parse(out as string) as { reason: string };
		expect(parsed.reason).toBe("pass_keyword");
	});

	it("rejects malformed args", async () => {
		const host = makeMockHost();
		await expect(
			predictNextEditLocationTool.handler({ documentText: 42 } as never, host, {} as never),
		).rejects.toThrow(/invalid args/);
	});

	it("returns end_of_document when nothing remains", async () => {
		const host = makeMockHost();
		const out = await predictNextEditLocationTool.handler(
			{ documentText: "only one line", currentOffset: 13, languageId: "typescript" },
			host,
			{} as never,
		);
		const parsed = JSON.parse(out as string) as { reason: string };
		expect(parsed.reason).toBe("end_of_document");
	});

	it("exposes the auto-approval level", () => {
		expect(predictNextEditLocationTool.approval).toBe("auto");
	});
});
