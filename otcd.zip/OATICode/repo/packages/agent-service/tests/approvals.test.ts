import { describe, expect, it, vi } from "vitest";
import { PendingApprovals } from "../src/approvals";

describe("PendingApprovals", () => {
	it("register returns a unique id and a pending promise", () => {
		const reg = new PendingApprovals();
		const a = reg.register();
		const b = reg.register();
		expect(a.id).not.toBe(b.id);
		expect(reg.size()).toBe(2);
		// Clean up timers so vitest doesn't keep the loop alive
		reg.cancelAll();
	});

	it("resolve(id, true) settles the matching promise with true", async () => {
		const reg = new PendingApprovals();
		const { id, promise } = reg.register();
		expect(reg.resolve(id, true)).toBe(true);
		await expect(promise).resolves.toBe(true);
		expect(reg.size()).toBe(0);
	});

	it("resolve(id, false) settles with false", async () => {
		const reg = new PendingApprovals();
		const { id, promise } = reg.register();
		reg.resolve(id, false);
		await expect(promise).resolves.toBe(false);
	});

	it("resolve(unknownId) returns false and is a no-op", () => {
		const reg = new PendingApprovals();
		expect(reg.resolve("nope", true)).toBe(false);
	});

	it("resolve a second time on the same id is a no-op", async () => {
		const reg = new PendingApprovals();
		const { id, promise } = reg.register();
		reg.resolve(id, true);
		await promise;
		expect(reg.resolve(id, false)).toBe(false);
	});

	it("times out with `false` after the configured timeout", async () => {
		vi.useFakeTimers();
		try {
			const reg = new PendingApprovals({ timeoutMs: 1000 });
			const { promise } = reg.register();
			vi.advanceTimersByTime(1001);
			await expect(promise).resolves.toBe(false);
			expect(reg.size()).toBe(0);
		} finally {
			vi.useRealTimers();
		}
	});

	it("cancelAll() resolves every outstanding entry with false", async () => {
		const reg = new PendingApprovals();
		const a = reg.register();
		const b = reg.register();
		reg.cancelAll();
		await expect(a.promise).resolves.toBe(false);
		await expect(b.promise).resolves.toBe(false);
		expect(reg.size()).toBe(0);
	});

	it("a custom timeout overrides the default", async () => {
		vi.useFakeTimers();
		try {
			const reg = new PendingApprovals({ timeoutMs: 10_000 });
			const { promise } = reg.register(100);
			vi.advanceTimersByTime(101);
			await expect(promise).resolves.toBe(false);
		} finally {
			vi.useRealTimers();
		}
	});
});
