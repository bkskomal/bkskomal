import { writeFileSync } from "node:fs";
import { build, context } from "esbuild";

const isWatch = process.argv.includes("--watch");

const config = {
	entryPoints: ["src/cli.ts"],
	bundle: true,
	// .cjs extension so Node treats the bundle as CommonJS even though the
	// package declares "type": "module" (the package.json setting governs the
	// TypeScript source files; the built bundle stays CJS to keep esbuild's
	// node-builtin handling working).
	outfile: "dist/cli.cjs",
	platform: "node",
	target: "node20",
	format: "cjs",
	sourcemap: true,
	minify: false,
	banner: { js: "#!/usr/bin/env node" },
	metafile: true,
	logLevel: "info",
	// Optional / dynamically-imported deps. Keep them external so the CLI
	// bundle stays small; runtime imports fail gracefully if not installed.
	external: [
		"puppeteer-core",
		"web-tree-sitter",
		// R8-D: computer-use optional deps.
		"screenshot-desktop",
		"@nut-tree-fork/nut-js",
		"pngjs",
	],
};

if (isWatch) {
	const ctx = await context(config);
	await ctx.watch();
	console.log("[agent-service] watching...");
} else {
	const result = await build(config);
	if (result.metafile) {
		writeFileSync("dist/meta.json", JSON.stringify(result.metafile));
	}
}
