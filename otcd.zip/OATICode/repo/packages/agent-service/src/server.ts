import * as http from "node:http";
import { Conductor, ProviderRegistry, ToolRegistry } from "@oati/agent-core";
import { createProviderFromConfig } from "@oati/providers";
import type {
	AgentEvent,
	ConversationMessage,
	ModeConfig,
	ProviderConfig,
	RpcEnvelope,
	WebviewToHost,
} from "@oati/shared";
import { builtinTools } from "@oati/tools";
import { PendingApprovals } from "./approvals";
import { createNodeHostContext } from "./node-host-context";
import { RpcSession, createNdjsonWriter } from "./rpc-handler";
import { writeSseDone, writeSseEvent } from "./sse";

export interface ServiceOptions {
	readonly port: number;
	readonly host?: string;
	readonly token?: string;
	readonly workspaceRoot: string;
	/** Approval auto-deny timeout in ms. Default 5 minutes. */
	readonly approvalTimeoutMs?: number;
}

interface RunRequestBody {
	readonly providerConfig: ProviderConfig;
	readonly apiKey?: string;
	readonly modelId: string;
	readonly mode: ModeConfig;
	readonly userMessage: string;
	readonly history?: readonly ConversationMessage[];
}

interface ApprovalResponseBody {
	readonly approved: boolean;
}

interface ServiceState {
	readonly tools: ToolRegistry;
	readonly approvals: PendingApprovals;
	/** Live, mutable workspace root — rotated via POST /v1/workspace. */
	workspaceRoot: string;
	/** Lazy-initialized RPC session for the Visual Studio bridge. */
	rpcSession?: RpcSession;
}

function getOrCreateSession(state: ServiceState): RpcSession {
	if (!state.rpcSession) {
		state.rpcSession = new RpcSession({
			tools: state.tools,
			approvals: state.approvals,
			getWorkspaceRoot: () => state.workspaceRoot,
			setWorkspaceRoot: async (next: string) => {
				state.workspaceRoot = next;
				return next;
			},
		});
	}
	return state.rpcSession;
}

interface WorkspaceUpdateBody {
	readonly workspaceRoot?: string;
}

export async function startService(opts: ServiceOptions): Promise<http.Server> {
	const tools = new ToolRegistry();
	for (const t of builtinTools) tools.register(t);

	const state: ServiceState = {
		tools,
		approvals: new PendingApprovals({ timeoutMs: opts.approvalTimeoutMs }),
		workspaceRoot: opts.workspaceRoot,
	};

	const server = http.createServer(async (req, res) => {
		try {
			await handle(req, res, opts, state);
		} catch (err) {
			if (!res.headersSent) {
				res.writeHead(500, { "Content-Type": "application/json" });
				res.end(JSON.stringify({ error: err instanceof Error ? err.message : String(err) }));
			} else {
				res.end();
			}
		}
	});

	server.on("close", () => state.approvals.cancelAll());

	return new Promise((resolve) => {
		server.listen(opts.port, opts.host ?? "127.0.0.1", () => resolve(server));
	});
}

async function handle(
	req: http.IncomingMessage,
	res: http.ServerResponse,
	opts: ServiceOptions,
	state: ServiceState,
): Promise<void> {
	if (opts.token) {
		const auth = req.headers.authorization;
		if (auth !== `Bearer ${opts.token}`) {
			res.writeHead(401, { "Content-Type": "application/json" });
			res.end(JSON.stringify({ error: "Unauthorized" }));
			return;
		}
	}

	const url = req.url ?? "/";

	if (req.method === "GET" && url === "/v1/health") {
		res.writeHead(200, {
			"Content-Type": "application/json",
		});
		res.end(
			JSON.stringify({
				status: "ok",
				version: "0.0.1",
				workspaceRoot: state.workspaceRoot,
			}),
		);
		return;
	}

	// POST /v1/workspace — rotate the workspace root from the host. Used by
	// the Visual Studio extension when the active solution / folder changes,
	// and by future multi-root callers that switch between projects on the
	// fly. The new root is applied to every subsequent /v1/agent/run call.
	if (req.method === "POST" && url === "/v1/workspace") {
		const body = await readJson<WorkspaceUpdateBody>(req);
		const next = typeof body?.workspaceRoot === "string" ? body.workspaceRoot.trim() : "";
		if (!next) {
			res.writeHead(400, { "Content-Type": "application/json" });
			res.end(JSON.stringify({ error: "Missing or empty workspaceRoot" }));
			return;
		}
		state.workspaceRoot = next;
		res.writeHead(200, { "Content-Type": "application/json" });
		res.end(JSON.stringify({ ok: true, workspaceRoot: next }));
		return;
	}

	// POST /v1/rpc — webview-protocol bridge. Used by the Visual Studio
	// WebView2 tool window to speak the existing `WebviewToHost` /
	// `HostToWebview` protocol without a per-message endpoint per type.
	//
	// Wire shape:
	//   - Request body: a single RpcEnvelope<WebviewToHost> JSON object.
	//   - Response body: newline-delimited RpcEnvelope<HostToWebview>
	//     JSON objects, streamed as the handler produces them. The
	//     connection stays open for the duration of the operation —
	//     e.g. a `user_message` connection holds open until the
	//     conductor finishes streaming the agent run.
	//
	// One RpcSession per process for now; future iterations may key on
	// a client id passed in a header so multiple panels in one Visual
	// Studio instance get isolated history.
	if (req.method === "POST" && url === "/v1/rpc") {
		const body = await readJson<RpcEnvelope<WebviewToHost>>(req);
		if (!body || body.v !== 1 || !body.body || typeof body.body.type !== "string") {
			res.writeHead(400, { "Content-Type": "application/json" });
			res.end(JSON.stringify({ error: "Invalid RPC envelope" }));
			return;
		}
		res.writeHead(200, {
			"Content-Type": "application/x-ndjson",
			"Cache-Control": "no-cache",
			Connection: "keep-alive",
			"X-Accel-Buffering": "no",
		});
		const writer = createNdjsonWriter(res);
		const session = getOrCreateSession(state);
		try {
			await session.handle(body, writer);
		} catch (err) {
			writer.write({
				type: "error",
				message: err instanceof Error ? err.message : String(err),
			});
		}
		writer.end();
		return;
	}

	if (req.method === "GET" && url === "/v1/tools") {
		const list = state.tools.list().map((t) => ({
			name: t.name,
			description: t.description,
			schema: t.schema,
			approval: t.approval,
		}));
		res.writeHead(200, { "Content-Type": "application/json" });
		res.end(JSON.stringify(list));
		return;
	}

	// POST /v1/approval/<id>  — resolve a pending approval initiated by an SSE event
	if (req.method === "POST" && url.startsWith("/v1/approval/")) {
		const id = decodeURIComponent(url.slice("/v1/approval/".length));
		const body = await readJson<ApprovalResponseBody>(req);
		if (!body || typeof body.approved !== "boolean" || !id) {
			res.writeHead(400, { "Content-Type": "application/json" });
			res.end(JSON.stringify({ error: "Invalid approval body" }));
			return;
		}
		const matched = state.approvals.resolve(id, body.approved);
		if (!matched) {
			res.writeHead(404, { "Content-Type": "application/json" });
			res.end(JSON.stringify({ error: "Unknown or expired approval id" }));
			return;
		}
		res.writeHead(200, { "Content-Type": "application/json" });
		res.end(JSON.stringify({ ok: true }));
		return;
	}

	if (req.method === "POST" && url === "/v1/agent/run") {
		const body = await readJson<RunRequestBody>(req);
		if (!body || !body.providerConfig || !body.modelId || !body.mode || !body.userMessage) {
			res.writeHead(400, { "Content-Type": "application/json" });
			res.end(JSON.stringify({ error: "Invalid request body" }));
			return;
		}

		res.writeHead(200, {
			"Content-Type": "text/event-stream",
			"Cache-Control": "no-cache",
			Connection: "keep-alive",
			"X-Accel-Buffering": "no",
		});

		const providers = new ProviderRegistry();
		providers.register(createProviderFromConfig(body.providerConfig, body.apiKey));

		const host = createNodeHostContext({
			// Always read from the mutable state — the host (e.g. the
			// Visual Studio extension) may have rotated this via POST
			// /v1/workspace since we started.
			workspaceRoot: state.workspaceRoot,
			approve: async (approvalReq) => {
				const { id, promise } = state.approvals.register();
				writeSseEvent(res, {
					type: "approval_request",
					request: {
						id,
						toolName: approvalReq.toolName,
						args: approvalReq.args,
						summary: approvalReq.summary,
					},
				});
				return promise;
			},
		});

		const conductor = new Conductor({ providers, tools: state.tools, host });

		const off = conductor.on((ev: AgentEvent) => writeSseEvent(res, ev));
		const abort = new AbortController();
		req.on("close", () => abort.abort());

		try {
			const history = await conductor.spawn({
				mode: body.mode,
				modelId: body.modelId,
				userMessage: body.userMessage,
				history: body.history,
				signal: abort.signal,
			});
			writeSseEvent(res, { type: "history_snapshot", history });
		} catch (err) {
			writeSseEvent(res, {
				type: "error",
				agentId: "service",
				message: err instanceof Error ? err.message : String(err),
			});
		} finally {
			off();
			writeSseDone(res);
			res.end();
		}
		return;
	}

	res.writeHead(404, { "Content-Type": "application/json" });
	res.end(JSON.stringify({ error: "Not found" }));
}

async function readJson<T>(req: http.IncomingMessage): Promise<T | undefined> {
	const chunks: Buffer[] = [];
	for await (const chunk of req) chunks.push(chunk as Buffer);
	const text = Buffer.concat(chunks).toString("utf-8");
	if (text.length === 0) return undefined;
	try {
		return JSON.parse(text) as T;
	} catch {
		return undefined;
	}
}
