export interface PendingApprovalsOptions {
	/** How long a pending approval can sit before auto-denying. Default 5 min. */
	readonly timeoutMs?: number;
}

interface PendingEntry {
	resolve(approved: boolean): void;
	timer: NodeJS.Timeout;
	createdAt: number;
}

/**
 * Service-wide pending-approval registry. Owns the matching between
 * `approval_request` SSE events sent down the /v1/agent/run stream and
 * `POST /v1/approval/:id` responses arriving on a separate HTTP request.
 *
 * Auto-denies (resolves with `false`) on timeout so a misbehaving client
 * can't leave the agent loop hung forever.
 */
export class PendingApprovals {
	private readonly entries = new Map<string, PendingEntry>();
	private nextId = 1;
	private readonly defaultTimeoutMs: number;

	constructor(opts: PendingApprovalsOptions = {}) {
		this.defaultTimeoutMs = opts.timeoutMs ?? 5 * 60_000;
	}

	/** Allocate a fresh id and a promise that resolves when the user answers. */
	register(timeoutMs = this.defaultTimeoutMs): {
		id: string;
		promise: Promise<boolean>;
	} {
		const id = `ap_${this.nextId++}_${Math.random().toString(36).slice(2, 8)}`;
		const promise = new Promise<boolean>((resolve) => {
			const timer = setTimeout(() => {
				this.entries.delete(id);
				resolve(false);
			}, timeoutMs);
			this.entries.set(id, {
				resolve,
				timer,
				createdAt: Date.now(),
			});
		});
		return { id, promise };
	}

	/** Returns true if an entry matched, false if the id was unknown or already resolved. */
	resolve(id: string, approved: boolean): boolean {
		const entry = this.entries.get(id);
		if (!entry) return false;
		clearTimeout(entry.timer);
		this.entries.delete(id);
		entry.resolve(approved);
		return true;
	}

	/** For tests + introspection. */
	size(): number {
		return this.entries.size;
	}

	/** Reject everything (e.g. on shutdown). Resolves each pending entry with `false`. */
	cancelAll(): void {
		for (const [id, entry] of this.entries) {
			clearTimeout(entry.timer);
			entry.resolve(false);
			this.entries.delete(id);
		}
	}
}
