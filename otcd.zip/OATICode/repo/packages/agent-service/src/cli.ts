import { startService } from "./server";

async function main(): Promise<void> {
	const port = Number(process.env.OATI_SERVICE_PORT ?? 8765);
	const host = process.env.OATI_SERVICE_HOST ?? "127.0.0.1";
	const token = process.env.OATI_SERVICE_TOKEN;
	const workspaceRoot = process.env.OATI_WORKSPACE_ROOT ?? process.cwd();

	const server = await startService({ port, host, token, workspaceRoot });
	const addr = server.address();
	const boundPort = addr && typeof addr !== "string" ? addr.port : port;
	console.log(`[oati-service] listening on http://${host}:${boundPort}`);
	console.log(`[oati-service] workspaceRoot: ${workspaceRoot}`);
	if (token) console.log("[oati-service] auth: Bearer token required");
	else console.log("[oati-service] auth: NONE (set OATI_SERVICE_TOKEN for production)");

	const shutdown = () => {
		console.log("[oati-service] shutting down...");
		server.close(() => process.exit(0));
	};
	process.on("SIGINT", shutdown);
	process.on("SIGTERM", shutdown);
}

main().catch((err) => {
	console.error("[oati-service] fatal:", err);
	process.exit(1);
});
