import * as cp from "node:child_process";
import * as fs from "node:fs/promises";
import * as path from "node:path";
import type {
	ApprovalRequest,
	BackgroundProcessHandle,
	BackgroundProcessOptions,
	DiffPreview,
	ExecOptions,
	ExecResult,
	HostContext,
	LogLevel,
} from "@oati/shared";
import { BackgroundProcessRegistry } from "./background-processes";

export interface NodeHostContextOptions {
	readonly workspaceRoot: string;
	/** Override approval behavior. Default: always approve (service mode). */
	approve?(req: Omit<ApprovalRequest, "id">): Promise<boolean>;
	/** Override diff handling. Default: no-op. */
	showDiff?(diff: DiffPreview): Promise<void>;
	/** Override logging. Default: console.log with level prefix. */
	log?(level: LogLevel, message: string): void;
	/**
	 * Called after `setWorkspaceRoot` validates + applies a new root.
	 * The RPC bridge hooks this to re-broadcast `workspace_info` to the
	 * webview so the project chip updates.
	 */
	onWorkspaceRootChanged?(resolved: string): void;
	/**
	 * Phase 1.3 sidecar parity (2026-05-23): lazy getter for the active
	 * provider's single-shot LLM call. Used by capability-aware tools
	 * (`code_semantic_search`'s rerank pass) to layer the active model's
	 * judgment on top of coarse retrieval. Returns undefined when the
	 * caller hasn't opted in (e.g., `oati.codebaseIndex.rerank` is off).
	 */
	getRerankerLlmCall?(): ((prompt: string, signal?: AbortSignal) => Promise<string>) | undefined;
	/**
	 * Phase 2.3 sidecar parity: lazy getter for the active model id so
	 * tools (`spawn_parallel_agents`) can clamp user-requested
	 * concurrency against the per-model `parallelConcurrencyCap` from
	 * the model-quirks registry. Returns undefined when the sidecar
	 * isn't currently servicing a request and no model is bound.
	 */
	getActiveModelId?(): string | undefined;
}

/**
 * In-process HostContext for service-mode execution.
 *
 * Approval behavior is overridable. The default auto-approves — the service
 * trusts its caller to gate via its own UI. For an IDE shell that needs
 * user-driven approval, pass an `approve` callback that bridges to the shell
 * over its transport (e.g. SSE event + waiting on a follow-up HTTP POST).
 */
export function createNodeHostContext(opts: NodeHostContextOptions): HostContext {
	// Mutable so `setWorkspaceRoot` can rotate it within a session without
	// rebuilding the host. Initialized from the construction option.
	let currentRoot = opts.workspaceRoot;
	function resolvePath(p: string): string {
		return path.isAbsolute(p) ? p : path.resolve(currentRoot, p);
	}

	// 2026-05-23: per-session registry for `start_background_process`.
	// Tracked PIDs are cleaned up by callers via session-end hooks.
	const bgRegistry = new BackgroundProcessRegistry();

	return {
		async readFile(p) {
			const resolved = resolvePath(p);
			try {
				return await fs.readFile(resolved, "utf-8");
			} catch (err) {
				// Claude-style failure: tell the model the resolved path,
				// the current workspace root, and (when the file is missing)
				// a short list of what IS in the parent directory so it can
				// pivot without burning another iteration.
				throw new Error(await formatPathError("read_file", p, resolved, currentRoot, err));
			}
		},
		async writeFile(p, content) {
			const resolved = resolvePath(p);
			try {
				await fs.mkdir(path.dirname(resolved), { recursive: true });
				await fs.writeFile(resolved, content, "utf-8");
			} catch (err) {
				throw new Error(await formatPathError("write_file", p, resolved, currentRoot, err));
			}
		},
		async fileExists(p) {
			try {
				await fs.stat(resolvePath(p));
				return true;
			} catch {
				return false;
			}
		},
		async exec(command: string, execOptions?: ExecOptions): Promise<ExecResult> {
			return new Promise<ExecResult>((resolve) => {
				cp.exec(
					command,
					{
						// CRITICAL: read currentRoot, not opts.workspaceRoot.
						// set_workspace_root mutates currentRoot in-place;
						// using opts.workspaceRoot would freeze the cwd at
						// construction time and break every subsequent
						// relative-path tool call after the root changed.
						cwd: execOptions?.cwd ?? currentRoot,
						timeout: execOptions?.timeoutMs ?? 60_000,
						env: { ...process.env, ...(execOptions?.env ?? {}) },
						maxBuffer: 10 * 1024 * 1024,
					},
					(err, stdout, stderr) => {
						const exitCode =
							err && typeof (err as NodeJS.ErrnoException).code === "number"
								? ((err as NodeJS.ErrnoException).code as unknown as number)
								: err
									? 1
									: 0;
						resolve({
							stdout: stdout?.toString() ?? "",
							stderr: stderr?.toString() ?? "",
							exitCode,
						});
					},
				);
			});
		},
		workspaceRoot() {
			return currentRoot;
		},
		async readDir(p, dirOpts) {
			const resolved = resolvePath(p);
			const cap = Math.min(dirOpts?.maxEntries ?? 500, 2000);
			try {
				const root = await fs.stat(resolved);
				if (!root.isDirectory()) {
					throw new Error(`${resolved} is not a directory`);
				}
				const entries: { name: string; type: "file" | "directory"; size?: number }[] = [];
				if (dirOpts?.recursive) {
					const walk = async (dir: string, prefix: string): Promise<void> => {
						if (entries.length >= cap) return;
						const items = await fs.readdir(dir, { withFileTypes: true });
						for (const it of items) {
							if (entries.length >= cap) break;
							const rel = prefix ? `${prefix}/${it.name}` : it.name;
							const type = it.isDirectory() ? "directory" : "file";
							entries.push({ name: rel, type });
							if (it.isDirectory()) {
								await walk(path.join(dir, it.name), rel);
							}
						}
					};
					await walk(resolved, "");
				} else {
					const items = await fs.readdir(resolved, { withFileTypes: true });
					for (const it of items.slice(0, cap)) {
						entries.push({
							name: it.name,
							type: it.isDirectory() ? "directory" : "file",
						});
					}
				}
				entries.sort((a, b) => {
					if (a.type !== b.type) return a.type === "directory" ? -1 : 1;
					return a.name.localeCompare(b.name);
				});
				return { path: resolved, entries, truncated: entries.length >= cap };
			} catch (err) {
				throw new Error(await formatPathError("list_dir", p, resolved, currentRoot, err));
			}
		},
		async setWorkspaceRoot(p: string): Promise<string> {
			const resolved = path.isAbsolute(p) ? p : path.resolve(currentRoot, p);
			try {
				const stat = await fs.stat(resolved);
				if (!stat.isDirectory()) {
					throw new Error(`${resolved} exists but is not a directory`);
				}
			} catch (err) {
				const msg = err instanceof Error ? err.message : String(err);
				throw new Error(`Cannot set workspace root to ${resolved}: ${msg}`);
			}
			currentRoot = resolved;
			try {
				opts.onWorkspaceRootChanged?.(resolved);
			} catch {
				/* notification is best-effort */
			}
			return resolved;
		},
		async requestApproval(req) {
			if (opts.approve) return opts.approve(req);
			return true;
		},
		async showDiff(diff) {
			if (opts.showDiff) await opts.showDiff(diff);
		},
		log(level, message) {
			if (opts.log) opts.log(level, message);
			else console.log(`[${level}] ${message}`);
		},
		// Phase 1.3 / 2.3 sidecar parity: lazy getters mirror the
		// extension-host pattern. Each call re-evaluates so a setting
		// flip or model switch mid-session takes effect on the next
		// tool call without rebuilding the host.
		get rerankerLlmCall() {
			return opts.getRerankerLlmCall?.();
		},
		get activeModelId() {
			return opts.getActiveModelId?.();
		},
		// 2026-05-23: background-process registry. Resolves cwd at call
		// time against the mutable `currentRoot` so dev servers spawn
		// in the directory the user is currently working in (post any
		// `setWorkspaceRoot` rotation).
		async startBackgroundProcess(
			command: string,
			options?: BackgroundProcessOptions,
		): Promise<BackgroundProcessHandle> {
			const cwd = options?.cwd ?? currentRoot;
			return bgRegistry.start(command, cwd, options);
		},
		async stopBackgroundProcess(pid: number) {
			return bgRegistry.stop(pid);
		},
		listBackgroundProcesses() {
			return bgRegistry.list();
		},
	};
}

/**
 * Build a Claude-quality error message. The model's #1 failure mode is
 * misreading a terse "ENOENT" and retrying the same path. This function
 * tells it:
 *   1. exactly which path was attempted (resolved + raw input),
 *   2. what the current workspace root is,
 *   3. the OS error code + message,
 *   4. for ENOENT: a peek at the parent directory + nearest-name suggestions,
 *   5. concrete next steps (set_workspace_root, list_dir, abs vs relative).
 */
async function formatPathError(
	tool: string,
	requestedPath: string,
	resolvedPath: string,
	workspaceRoot: string,
	err: unknown,
): Promise<string> {
	const code = (err as NodeJS.ErrnoException | undefined)?.code ?? "";
	const baseMsg = err instanceof Error ? err.message : String(err);
	const lines: string[] = [
		`${tool} failed (${code || "error"}): ${baseMsg}`,
		"",
		`  Requested path  : ${requestedPath}`,
		`  Resolved path   : ${resolvedPath}`,
		`  Workspace root  : ${workspaceRoot}`,
	];

	if (code === "ENOENT") {
		// Show the parent's contents so the model can spot a typo or
		// confirm the file genuinely doesn't exist.
		const parent = path.dirname(resolvedPath);
		const basename = path.basename(resolvedPath);
		try {
			const entries = await fs.readdir(parent, { withFileTypes: true });
			const names = entries.slice(0, 40).map((e) => (e.isDirectory() ? `${e.name}/` : e.name));
			lines.push("", `  Parent (${parent}) contains:`);
			for (const n of names) lines.push(`    - ${n}`);
			if (entries.length > 40) lines.push(`    … and ${entries.length - 40} more`);

			// Nearest-name suggestions (case-insensitive substring + length).
			const suggestions = entries
				.map((e) => e.name)
				.filter(
					(n) =>
						n.toLowerCase().includes(basename.toLowerCase()) ||
						basename.toLowerCase().includes(n.toLowerCase()),
				)
				.slice(0, 5);
			if (suggestions.length > 0) {
				lines.push("", `  Did you mean: ${suggestions.join(", ")}`);
			}
		} catch (parentErr) {
			lines.push(
				"",
				`  Parent directory unreadable: ${parentErr instanceof Error ? parentErr.message : String(parentErr)}`,
				"  → The workspace root itself may be wrong. Call `set_workspace_root` with the absolute project path.",
			);
		}
	} else if (code === "EACCES" || code === "EPERM") {
		lines.push(
			"",
			`  → Permission denied. The file or its parent isn't readable/writable by the current process.`,
			`  → Don't retry the same call. Surface this to the user.`,
		);
	} else if (code === "EISDIR") {
		lines.push(
			"",
			"  → Path is a directory, not a file. Use `list_dir` for directories, `read_file` only for files.",
		);
	}

	lines.push(
		"",
		`Next steps you can try (pick ONE — don't retry the same call):`,
		"  1. If the workspace root looks wrong, call `set_workspace_root` with the correct absolute path.",
		"  2. If the path looks wrong, call `list_dir` on its parent folder to verify the spelling.",
		"  3. If you used a relative path, retry with an absolute path. If you used absolute, the file does not exist there.",
		`  4. After 2 failed attempts, STOP and tell the user: "I tried X and Y, both failed because Z. Could you confirm the correct path?"`,
	);

	return lines.join("\n");
}
