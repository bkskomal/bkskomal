/*
 * Webview-protocol RPC bridge.
 *
 * Translates the `WebviewToHost` messages emitted by the Preact webview
 * (`packages/webview-ui`) into agent-core operations, and streams
 * `HostToWebview` events back over NDJSON. Lets the Visual Studio
 * extension's WebView2 control speak the same RPC the VS Code extension
 * uses without any UI changes.
 *
 * Scope: chat MVP. The webview's protocol is large (~80 message types);
 * this bridge handles the subset that makes the chat experience work
 * end-to-end:
 *
 *   ✓ ready              - initial handshake (init + settings + workspace_info)
 *   ✓ get_settings       - re-broadcast snapshot
 *   ✓ update_settings    - mutate + persist
 *   ✓ update_api_key     - persist secret
 *   ✓ delete_api_key     - remove secret
 *   ✓ set_mode           - switch active mode
 *   ✓ user_message       - dispatch through conductor + stream events
 *   ✓ cancel             - abort the active run
 *   ✓ approval_response  - resolve a pending approval
 *   ✓ clear_session      - reset history
 *   ✓ new_session        - reset + restart
 *
 * Everything else returns an `error` envelope with a "not supported in
 * service mode" hint. The VS extension can opt in by routing those
 * messages elsewhere or by extending this handler later.
 */

import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

const nodeBasename = (p: string): string => path.basename(p) || p;
import { Conductor, ProviderRegistry, type ToolRegistry } from "@oati/agent-core";
import { createProviderFromConfig } from "@oati/providers";
import {
	type AgentEvent,
	type ConversationMessage,
	DEFAULT_CONFIG,
	type HookConfig,
	type HostToWebview,
	type ModeConfig,
	type ProviderConfig,
	type RpcEnvelope,
	type SettingsSnapshot,
	type SettingsUpdate,
	type WebviewToHost,
	buildModelPromptAddendum,
	detectModelQuirks,
} from "@oati/shared";
import type { PendingApprovals } from "./approvals";
import { createNodeHostContext } from "./node-host-context";

// ---------------------------------------------------------------------------
// Public surface
// ---------------------------------------------------------------------------

export interface RpcHandlerOptions {
	readonly tools: ToolRegistry;
	readonly approvals: PendingApprovals;
	/** Mutable workspace root; rotated via the /v1/workspace endpoint. */
	getWorkspaceRoot(): string;
	/**
	 * Apply a new workspace root and persist it for subsequent runs.
	 * Called by the `/cwd` slash command via the `set_workspace_root`
	 * RPC and by the `set_workspace_root` tool the model invokes.
	 */
	setWorkspaceRoot?(path: string): Promise<string>;
}

/** Per-connection state. One bridge instance per WebView2 panel. */
export class RpcSession {
	private history: ConversationMessage[] = [];
	private activeAbort: AbortController | undefined;

	constructor(private readonly opts: RpcHandlerOptions) {}

	/**
	 * Process a single webview RPC envelope. `writer` is the NDJSON sink
	 * for HostToWebview envelopes. Returns after the message is fully
	 * handled — for streaming messages (`user_message`) that's after the
	 * agent run finishes; for one-shot messages it's near-immediate.
	 */
	async handle(env: RpcEnvelope<WebviewToHost>, writer: NdjsonWriter): Promise<void> {
		const msg = env.body;
		try {
			switch (msg.type) {
				case "ready":
					await this.onReady(writer);
					return;
				case "get_settings":
					await this.sendSettings(writer);
					return;
				case "update_settings":
					await this.onUpdateSettings(msg.settings, writer);
					return;
				case "update_api_key":
					await setSecret(msg.providerId, msg.apiKey);
					await this.sendSettings(writer);
					return;
				case "delete_api_key":
					await setSecret(msg.providerId, undefined);
					await this.sendSettings(writer);
					return;
				case "set_mode":
					await this.onSetMode(msg.modeId, writer);
					return;
				case "user_message":
					await this.onUserMessage(msg.content, writer);
					return;
				case "cancel":
					this.activeAbort?.abort();
					return;
				case "approval_response":
					this.opts.approvals.resolve(msg.id, msg.approved);
					return;
				case "clear_session":
					this.history = [];
					await this.onReady(writer);
					return;
				case "new_session":
					this.history = [];
					await this.onReady(writer);
					return;
				case "set_workspace_root":
					await this.onSetWorkspaceRoot(msg.path, writer);
					return;
				default:
					writer.write({
						type: "error",
						message: `'${msg.type}' is not supported by the Visual Studio bridge yet. Use the VS Code extension for the full feature set.`,
					});
					return;
			}
		} catch (err) {
			writer.write({
				type: "error",
				message: err instanceof Error ? err.message : String(err),
			});
		}
	}

	// ------------------------------------------------------------------
	// Handlers
	// ------------------------------------------------------------------

	private async onReady(writer: NdjsonWriter): Promise<void> {
		const settings = await loadSettings();
		writer.write({
			type: "init",
			modes: settings.config.modes.map((m) => ({
				id: m.id,
				displayName: m.displayName,
				...(m.description ? { description: m.description } : {}),
				...(m.autoApprove ? { autoApprove: true } : {}),
				...(m.enablePlanner ? { enablePlanner: true } : {}),
				...(m.enableCritic ? { enableCritic: true } : {}),
			})),
			activeModeId: settings.config.activeModeId,
			sessionId: "vs-session",
			workspaceFiles: [],
		});
		writer.write({ type: "settings", snapshot: settings });
		const root = this.opts.getWorkspaceRoot();
		writer.write({
			type: "workspace_info",
			info: {
				path: root,
				name: path.basename(root) || root,
				isMultiRoot: false,
				folderCount: 1,
			},
		});
	}

	private async sendSettings(writer: NdjsonWriter): Promise<void> {
		writer.write({ type: "settings", snapshot: await loadSettings() });
	}

	private async onUpdateSettings(update: SettingsUpdate, writer: NdjsonWriter): Promise<void> {
		const current = await loadSettings();
		const next = {
			...current.config,
			activeProviderId: update.activeProviderId ?? current.config.activeProviderId,
			activeModeId: update.activeModeId ?? current.config.activeModeId,
			providers: update.providers ?? current.config.providers,
			modes: update.modes ?? current.config.modes,
			...(update.mcpServers ? { mcpServers: update.mcpServers } : {}),
			...(update.hooks ? { hooks: update.hooks } : {}),
			// 2026-05-24: persist diagnostics toggle. Use explicit
			// `undefined` check so flipping the value back to `false`
			// actually saves rather than falling through to the prior
			// cached value.
			...(update.verboseInternals !== undefined ? { verboseInternals: update.verboseInternals } : {}),
		};
		await saveSettings(next);
		await this.sendSettings(writer);
	}

	private async onSetMode(modeId: string, writer: NdjsonWriter): Promise<void> {
		const current = await loadSettings();
		const next = { ...current.config, activeModeId: modeId };
		await saveSettings(next);
		await this.sendSettings(writer);
	}

	private async onSetWorkspaceRoot(newPath: string, writer: NdjsonWriter): Promise<void> {
		const target = (newPath ?? "").trim();
		if (target.length === 0) {
			writer.write({
				type: "error",
				message: "/cwd: provide an absolute path (e.g. `/cwd E:\\proj`).",
			});
			return;
		}
		// Resolve relative to the current workspace, expand `~`.
		const expanded = target.startsWith("~")
			? path.resolve(os.homedir() ?? "", target.slice(1).replace(/^[\\/]+/, ""))
			: target;
		const resolved = path.isAbsolute(expanded)
			? expanded
			: path.resolve(this.opts.getWorkspaceRoot(), expanded);
		try {
			const stat = await fs.stat(resolved);
			if (!stat.isDirectory()) {
				writer.write({
					type: "error",
					message: `/cwd: ${resolved} exists but is not a directory.`,
				});
				return;
			}
		} catch (err) {
			const msg = err instanceof Error ? err.message : String(err);
			writer.write({
				type: "error",
				message: `/cwd: ${resolved} is not reachable — ${msg}`,
			});
			return;
		}
		// Persist via the holder injected from server.ts (mutates
		// state.workspaceRoot so every subsequent /v1/agent/run + tool
		// resolves paths against the new root).
		if (this.opts.setWorkspaceRoot) {
			await this.opts.setWorkspaceRoot(resolved);
		}
		writer.write({
			type: "workspace_info",
			info: {
				path: resolved,
				name: nodeBasename(resolved),
				isMultiRoot: false,
				folderCount: 1,
			},
		});
	}

	private async onUserMessage(content: string, writer: NdjsonWriter): Promise<void> {
		if (this.activeAbort) {
			writer.write({
				type: "error",
				message: "Another run is in flight — cancel it before sending a new prompt.",
			});
			return;
		}
		const settings = await loadSettings();
		const cfg = settings.config;
		const mode = cfg.modes.find((m) => m.id === cfg.activeModeId) ?? cfg.modes[0];
		if (!mode) {
			writer.write({ type: "error", message: "No active mode configured." });
			return;
		}
		const provider = cfg.providers.find((p) => p.id === cfg.activeProviderId);
		if (!provider) {
			writer.write({ type: "error", message: "No active provider configured." });
			return;
		}
		const modelId =
			(mode.modelId && mode.modelId.length > 0 ? mode.modelId : provider.defaultModel) ?? "";
		if (!modelId) {
			writer.write({
				type: "error",
				message: "No model configured. Open Settings, pick a provider, and set a default model id.",
			});
			return;
		}
		const apiKey = await getSecret(provider.id);
		const providers = new ProviderRegistry();
		try {
			providers.register(createProviderFromConfig(provider, apiKey));
		} catch (err) {
			writer.write({
				type: "error",
				message: `Provider init failed: ${err instanceof Error ? err.message : String(err)}`,
			});
			return;
		}

		const ctrl = new AbortController();
		this.activeAbort = ctrl;

		// Phase 1.3 / 2.3 sidecar parity (2026-05-23): build a per-request
		// reranker LLM call using the active provider. Gated by
		// `OATI_RERANK_ENABLED=1` env var — sidecar equivalent of the
		// VS Code `oati.codebaseIndex.rerank` setting. Default off so the
		// rerank cost only fires when the operator explicitly opts in.
		const rerankEnabled = process.env.OATI_RERANK_ENABLED === "1";
		const buildRerankerLlmCall = (): ((prompt: string, signal?: AbortSignal) => Promise<string>) => {
			return async (prompt: string, signal?: AbortSignal): Promise<string> => {
				const req = {
					messages: [{ role: "user" as const, parts: [{ kind: "text" as const, text: prompt }] }],
					modelId,
					maxTokens: 512,
					temperature: 0,
					...(signal ? { signal } : {}),
				};
				let text = "";
				const providerSpec = providers.get(provider.id);
				if (!providerSpec) throw new Error(`No active provider for rerank (id=${provider.id})`);
				for await (const ev of providerSpec.stream(req)) {
					if (ev.type === "text_delta") text += ev.text;
					else if (ev.type === "message_end") break;
					else if (ev.type === "error") throw new Error(ev.message);
				}
				return text;
			};
		};

		const host = createNodeHostContext({
			workspaceRoot: this.opts.getWorkspaceRoot(),
			approve: async (req) => {
				const { id, promise } = this.opts.approvals.register();
				writer.write({
					type: "approval_request",
					request: {
						id,
						toolName: req.toolName,
						args: req.args,
						summary: req.summary ?? "",
					},
				});
				return promise;
			},
			log: (level, message) => {
				if (level === "error") {
					writer.write({ type: "error", message });
				}
			},
			onWorkspaceRootChanged: (resolved) => {
				// When the model invokes `set_workspace_root` mid-run, push
				// the change into the sidecar's persistent state and
				// broadcast a fresh `workspace_info` event so the UI's
				// project chip reflects the new root.
				void this.opts.setWorkspaceRoot?.(resolved);
				writer.write({
					type: "workspace_info",
					info: {
						path: resolved,
						name: nodeBasename(resolved),
						isMultiRoot: false,
						folderCount: 1,
					},
				});
			},
			// Phase 2.3 sidecar parity: expose the active model id so
			// capability-aware tools (spawn_parallel_agents) can clamp
			// user-requested concurrency against the model's quirks cap.
			getActiveModelId: () => modelId,
			// Phase 1.3 sidecar parity: expose the rerank LLM call only
			// when the operator has opted in via OATI_RERANK_ENABLED=1.
			// Returning undefined keeps the rerank pass off — matches the
			// extension-host's default-off behavior.
			getRerankerLlmCall: rerankEnabled ? buildRerankerLlmCall : undefined,
		});

		const conductor = new Conductor({
			providers,
			tools: this.opts.tools,
			host,
		});
		const offConductor = conductor.on((ev: AgentEvent) => {
			writer.write({ type: "agent_event", event: ev });
		});

		try {
			// Per-model quirks: append a model-specific addendum to the
			// system prompt and bump the iteration cap for open-weight
			// models that need more rounds to finish what frontier models
			// do in 8. Read once from the central registry so adding a new
			// model later is one row in @oati/shared/model-quirks.
			const quirks = detectModelQuirks(modelId);
			const modelAddendum = buildModelPromptAddendum(modelId);
			const tunedMode = {
				...mode,
				providerId: provider.id,
				systemPrompt: modelAddendum ? `${mode.systemPrompt}\n\n${modelAddendum}` : mode.systemPrompt,
				maxIterations: Math.max(mode.maxIterations ?? 10, quirks.maxIterations),
				temperature: mode.temperature ?? quirks.temperature,
			};
			const history = await conductor.spawn({
				mode: tunedMode,
				modelId,
				userMessage: content,
				history: this.history,
				signal: ctrl.signal,
			});
			this.history = [...history];
		} catch (err) {
			writer.write({
				type: "error",
				message: err instanceof Error ? err.message : String(err),
			});
		} finally {
			offConductor();
			if (this.activeAbort === ctrl) this.activeAbort = undefined;
		}
	}
}

// ---------------------------------------------------------------------------
// NDJSON writer
// ---------------------------------------------------------------------------

export interface NdjsonWriter {
	write(msg: HostToWebview): void;
	end(): void;
}

/** Build a writer that emits NDJSON envelopes to a Node Writable. */
export function createNdjsonWriter(out: NodeJS.WritableStream): NdjsonWriter {
	return {
		write(msg) {
			const env: RpcEnvelope<HostToWebview> = { v: 1, body: msg };
			out.write(JSON.stringify(env));
			out.write("\n");
		},
		end() {
			out.end();
		},
	};
}

// ---------------------------------------------------------------------------
// Settings + secrets persistence (sidecar mode)
// ---------------------------------------------------------------------------

const SETTINGS_DIR = path.join(os.homedir() ?? process.cwd(), ".oati");
const SETTINGS_FILE = path.join(SETTINGS_DIR, "settings.json");
const SECRETS_FILE = path.join(SETTINGS_DIR, "secrets.json");

interface PersistedConfig {
	readonly activeProviderId: string;
	readonly activeModeId: string;
	readonly providers: readonly ProviderConfig[];
	readonly modes: readonly ModeConfig[];
	readonly mcpServers?: readonly unknown[];
	readonly hooks?: readonly HookConfig[];
}

async function ensureDir(): Promise<void> {
	try {
		await fs.mkdir(SETTINGS_DIR, { recursive: true });
	} catch {
		/* best-effort */
	}
}

async function loadSettings(): Promise<SettingsSnapshot> {
	await ensureDir();
	let config: PersistedConfig;
	try {
		const raw = await fs.readFile(SETTINGS_FILE, "utf-8");
		config = JSON.parse(raw) as PersistedConfig;
	} catch {
		// First run — seed with DEFAULT_CONFIG so the user has something
		// resembling the VS Code experience out of the box.
		config = {
			activeProviderId: DEFAULT_CONFIG.activeProviderId,
			activeModeId: DEFAULT_CONFIG.activeModeId,
			providers: [...DEFAULT_CONFIG.providers],
			modes: [...DEFAULT_CONFIG.modes],
		};
		await saveSettings(config);
	}
	// SettingsSnapshot is the shape the webview consumes. We only persist
	// the config slice; the `hasApiKey` map is derived from secrets on
	// every read so the webview's settings panel reflects the live state.
	const secrets = await loadSecrets();
	const hasApiKey: Record<string, boolean> = {};
	for (const p of config.providers) {
		hasApiKey[p.id] = Boolean(secrets[p.id]);
	}
	return {
		config: config as unknown as SettingsSnapshot["config"],
		hasApiKey,
	};
}

async function saveSettings(next: PersistedConfig): Promise<void> {
	await ensureDir();
	await fs.writeFile(SETTINGS_FILE, JSON.stringify(next, null, 2), "utf-8");
}

async function loadSecrets(): Promise<Record<string, string>> {
	await ensureDir();
	try {
		const raw = await fs.readFile(SECRETS_FILE, "utf-8");
		return JSON.parse(raw) as Record<string, string>;
	} catch {
		return {};
	}
}

async function getSecret(providerId: string): Promise<string | undefined> {
	const all = await loadSecrets();
	return all[providerId];
}

async function setSecret(providerId: string, value: string | undefined): Promise<void> {
	const all = await loadSecrets();
	if (value === undefined || value.length === 0) {
		delete all[providerId];
	} else {
		all[providerId] = value;
	}
	await ensureDir();
	await fs.writeFile(SECRETS_FILE, JSON.stringify(all, null, 2), {
		encoding: "utf-8",
		mode: 0o600,
	});
}
