import type * as http from "node:http";

export function writeSseEvent(res: http.ServerResponse, data: unknown): void {
	res.write(`data: ${JSON.stringify(data)}\n\n`);
}

export function writeSseDone(res: http.ServerResponse): void {
	res.write("data: [DONE]\n\n");
}
