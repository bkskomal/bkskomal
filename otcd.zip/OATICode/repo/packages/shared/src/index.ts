export * from "./agent";
export * from "./tools";
export * from "./providers";
export * from "./host-context";
export * from "./config";
export * from "./messages";
export * from "./presets";
export * from "./mcp-presets";
export * from "./pricing";
export * from "./session";
export * from "./ui-message";
// Model-quirks registry — single source of truth for per-model
// temperature/max-tokens/iterations/prompt addenda. Read by both the
// VS Code extension and the Visual Studio sidecar when building runs.
export * from "./model-quirks";
// R6-A: Structured Plan v2 — the only plan schema (Phase 5, 2026-06-04
// removed the legacy `Plan`/`PlanStep` types). Re-exported here so consumers
// can `import { PlanV2 } from "@oati/shared"`. The spec-canonical `PlanStep`
// alias is reachable via `import { PlanStep } from "@oati/shared/plan"`.
export type { PlanV2, PlanV2Step, PlanV2State, PlanStepStatus } from "./plan";
// Phase 3.3 (2026-06-04): unified hunk-based diff helpers shared between
// the extension host's InlineDiffSession and the webview's approval
// modal + diff overlay. The hunk model + LCS implementation used to live
// only in extension-host/inline-diff.ts; pulling it into shared lets the
// webview render proper hunks instead of the ad-hoc per-line set-diff.
export {
	computeHunks,
	renderHunks,
	createInlineDiffSession,
	setHunkStatus,
	resolveAcceptedText,
	isFullyResolved,
	splitLines,
	joinLines,
} from "./diff";
export type {
	DiffHunk,
	HunkStatus,
	InlineDiffSessionState,
	HunkRenderRow,
	RenderedHunk,
} from "./diff";
// Phase 0.5 follow-through (2026-06-04): hand-rolled minimal YAML parser
// for our narrow shapes (skill frontmatter + .oati/policy.yaml). Replaces
// the ~86KB js-yaml bundle weight; supports key:value, indented mappings,
// block + flow sequences, scalar types, and comments. Throws YamlMiniError
// on malformed input so callers can fall back to their empty state.
export { parseYaml, YamlMiniError } from "./yaml-mini";
export type { YamlValue } from "./yaml-mini";
// 2026-06-16: prompt builders for vLLM's /v1/completions fallback.
// Used when ModelQuirks.useCompletionsFallback is true (Gemma 4, Qwen
// 3 Coder on the OATI internal gateway) — the openai-compatible
// provider renders the prompt client-side and routes to /v1/completions
// because the gateway doesn't have a chat_template AND won't accept
// one passed via the request body.
export {
	buildGemmaPrompt,
	buildChatMLPrompt,
	buildPromptForShape,
} from "./chat-templates";
export type { PromptMessage, BuiltPrompt } from "./chat-templates";
