import type { ConversationMessage } from "./agent";

export interface UiToolCard {
	readonly callId: string;
	readonly name: string;
	readonly args: unknown;
	readonly result?: {
		readonly isError: boolean;
		readonly output: unknown;
	};
	/** Single-line description derived from args (e.g. file path or command). */
	readonly summary?: string;
	/** File path the tool acted on, if it can be inferred from args. */
	readonly path?: string;
	/**
	 * Accumulated `tool_progress` chunks for an in-flight call. Cleared once
	 * the final `result` arrives. Capped at `STREAMING_OUTPUT_CAP` bytes so the
	 * webview can't drown in megabytes of `tail -f` output.
	 */
	readonly streamingOutput?: string;
}

/** Webview-side cap on the streamingOutput buffer. */
export const STREAMING_OUTPUT_CAP = 64 * 1024;

export interface UiMessage {
	readonly id: string;
	readonly role: "user" | "assistant" | "tool" | "system";
	readonly text: string;
	readonly pending?: boolean;
	/**
	 * When present, this message should render as a compact tool-invocation card
	 * (call + optional result) instead of plain text. The `text` field is kept
	 * as a fallback for non-card UIs (e.g. logs, exports).
	 */
	readonly toolCard?: UiToolCard;
	/**
	 * Per-turn token attribution. The webview attaches the conductor's `usage`
	 * burst to the matching assistant message so the bubble can render a small
	 * ↓in ↑out badge for the turn.
	 */
	readonly tokens?: {
		readonly input: number;
		readonly output: number;
	};
	/** Image data URLs attached to a user message (rendered as inline thumbnails). */
	readonly images?: readonly {
		readonly mimeType: string;
		readonly dataUrl: string;
	}[];
	// R3-D: pinned messages — when true, the message appears in the
	// "📌 Pinned" rail. Persisted via SessionStore so a pinned set survives a
	// reload of the chat panel.
	readonly pinned?: boolean;
	// R4-E: per-turn wall-clock duration in milliseconds. Attached to the
	// last assistant bubble of a completed turn so the footer can render a
	// small "(in 4.2s)" suffix next to the token badge.
	readonly durationMs?: number;
	/**
	 * Phase 3.2 (2026-05-23): the agent turn that produced this assistant
	 * bubble. Attached when the bubble is first created from a `text_delta`
	 * event (and copied to follow-up tool cards within the same turn).
	 * The webview surfaces a "↩ Rollback" affordance on bubbles that
	 * carry a turnId — clicking it sends `{ type: "revert_turn", turnId }`
	 * which restores every file the turn wrote to its pre-turn state.
	 */
	readonly turnId?: string;
	/**
	 * 2026-05-26: per-turn list of files the agent created or modified.
	 * Attached to the LAST assistant message of the turn when the
	 * `turn_files_changed` host event arrives. Webview renders a small
	 * chip strip below the bubble — click a chip to open the file
	 * (new) or open a diff vs pre-turn state (modified).
	 */
	readonly changedFiles?: readonly {
		readonly path: string;
		readonly kind: "new" | "modified";
	}[];
}

/**
 * Stable UiMessage id for the user turn at `historyIndex` in canonical history.
 * The host uses this to map a `regenerate_from` request back to the matching
 * ConversationMessage so it can truncate from that point.
 */
export function userMessageIdForIndex(historyIndex: number): string {
	return `u_h${historyIndex}`;
}

/**
 * Convert canonical agent history into the flat UiMessage[] that the chat list renders.
 * Tool calls + their results are merged into a single tool card per call id so the chat
 * doesn't get cluttered with the full file content of every read/edit/write.
 */
export function conversationToUiMessages(history: readonly ConversationMessage[]): UiMessage[] {
	const out: UiMessage[] = [];
	const cardIndexByCallId = new Map<string, number>();
	let counter = 0;
	const id = (prefix: string) => `${prefix}_${counter++}`;
	for (let historyIndex = 0; historyIndex < history.length; historyIndex++) {
		const msg = history[historyIndex];
		if (msg.role === "user") {
			const text = collectText(msg.parts);
			const images: { mimeType: string; dataUrl: string }[] = [];
			for (const p of msg.parts) {
				if (p.kind === "image") images.push({ mimeType: p.mimeType, dataUrl: p.dataUrl });
			}
			if (text || images.length > 0) {
				out.push({
					id: userMessageIdForIndex(historyIndex),
					role: "user",
					text,
					...(images.length > 0 ? { images } : {}),
				});
			}
			continue;
		}
		if (msg.role === "assistant") {
			const text = collectText(msg.parts);
			if (text) out.push({ id: id("a"), role: "assistant", text });
			for (const p of msg.parts) {
				if (p.kind === "tool_call") {
					const summary = summarizeToolArgs(p.name, p.args);
					const path = pickPathFromArgs(p.args);
					const card: UiToolCard = {
						callId: p.id,
						name: p.name,
						args: p.args,
						summary,
						path,
					};
					out.push({
						id: id("tc"),
						role: "tool",
						text: `→ ${p.name}(${truncate(JSON.stringify(p.args), 200)})`,
						toolCard: card,
					});
					cardIndexByCallId.set(p.id, out.length - 1);
				}
			}
			continue;
		}
		if (msg.role === "tool") {
			for (const p of msg.parts) {
				if (p.kind === "tool_result") {
					const preview = typeof p.output === "string" ? p.output : JSON.stringify(p.output);
					const cardIdx = cardIndexByCallId.get(p.id);
					if (cardIdx !== undefined && out[cardIdx].toolCard) {
						const existing = out[cardIdx];
						const card = existing.toolCard as UiToolCard;
						out[cardIdx] = {
							...existing,
							toolCard: {
								...card,
								result: { isError: p.isError, output: p.output },
							},
						};
					} else {
						// Orphan result (no matching call seen) — render as a standalone card.
						out.push({
							id: id("tr"),
							role: "tool",
							text: `${p.isError ? "✗" : "✓"} ${truncate(preview, 500)}`,
							toolCard: {
								callId: p.id,
								name: "(unknown tool)",
								args: undefined,
								result: { isError: p.isError, output: p.output },
							},
						});
					}
				}
			}
		}
	}
	return out;
}

function collectText(parts: readonly { kind: string; text?: string }[]): string {
	const chunks: string[] = [];
	for (const p of parts) if (p.kind === "text" && typeof p.text === "string") chunks.push(p.text);
	return chunks.join("");
}

function truncate(s: string, n: number): string {
	return s.length > n ? `${s.slice(0, n)}…` : s;
}

/** Best-effort: pull a file path out of common tool argument shapes. */
export function pickPathFromArgs(args: unknown): string | undefined {
	if (!args || typeof args !== "object") return undefined;
	const a = args as Record<string, unknown>;
	for (const k of ["path", "file", "filePath", "uri", "target"]) {
		const v = a[k];
		if (typeof v === "string" && v.length > 0) return v;
	}
	return undefined;
}

/**
 * Single-line summary of a tool invocation for the card header.
 * Prefers file path, then command, then a generic JSON snippet.
 */
export function summarizeToolArgs(name: string, args: unknown): string | undefined {
	const path = pickPathFromArgs(args);
	if (path) return path;
	if (args && typeof args === "object") {
		const a = args as Record<string, unknown>;
		const lower = name.toLowerCase();
		if (lower.includes("exec") || lower.includes("run")) {
			const cmd = a.command ?? a.cmd;
			if (typeof cmd === "string") return cmd;
		}
		if (lower.includes("fetch")) {
			const url = a.url;
			if (typeof url === "string") return url;
		}
		for (const k of ["query", "pattern", "description", "summary"]) {
			const v = a[k];
			if (typeof v === "string" && v.length > 0) return v;
		}
	}
	if (args !== undefined) {
		const s = JSON.stringify(args);
		return s.length > 80 ? `${s.slice(0, 80)}…` : s;
	}
	return undefined;
}
