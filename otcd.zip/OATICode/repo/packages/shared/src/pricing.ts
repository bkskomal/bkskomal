export interface ModelRate {
	/** Pattern matched (case-insensitive) as a substring of the model id. */
	readonly match: string;
	readonly displayName: string;
	/** USD per 1 million input tokens. */
	readonly inputPerMillion: number;
	/** USD per 1 million output tokens. */
	readonly outputPerMillion: number;
}

/**
 * Rough public list-price reference. Use this for relative-cost intuition only;
 * actual billing depends on the provider you route through (OpenRouter markup,
 * volume discounts, prompt caching, etc.). Last refreshed early 2026.
 *
 * Matching is substring-based and ordered: the first matching entry wins.
 * Put more specific patterns first.
 */
export const MODEL_RATES: readonly ModelRate[] = [
	{
		match: "claude-opus-4-7",
		displayName: "Claude Opus 4.7",
		inputPerMillion: 15,
		outputPerMillion: 75,
	},
	{
		match: "claude-opus-4-6",
		displayName: "Claude Opus 4.6",
		inputPerMillion: 15,
		outputPerMillion: 75,
	},
	{ match: "claude-opus", displayName: "Claude Opus", inputPerMillion: 15, outputPerMillion: 75 },
	{
		match: "claude-sonnet-4-6",
		displayName: "Claude Sonnet 4.6",
		inputPerMillion: 3,
		outputPerMillion: 15,
	},
	{
		match: "claude-sonnet-4",
		displayName: "Claude Sonnet 4",
		inputPerMillion: 3,
		outputPerMillion: 15,
	},
	{ match: "claude-sonnet", displayName: "Claude Sonnet", inputPerMillion: 3, outputPerMillion: 15 },
	{
		match: "claude-haiku-4-5",
		displayName: "Claude Haiku 4.5",
		inputPerMillion: 1,
		outputPerMillion: 5,
	},
	{ match: "claude-haiku", displayName: "Claude Haiku", inputPerMillion: 1, outputPerMillion: 5 },
	{ match: "gpt-4o-mini", displayName: "GPT-4o mini", inputPerMillion: 0.15, outputPerMillion: 0.6 },
	{ match: "gpt-4o", displayName: "GPT-4o", inputPerMillion: 2.5, outputPerMillion: 10 },
	{ match: "o3-mini", displayName: "o3-mini", inputPerMillion: 1.1, outputPerMillion: 4.4 },
	{ match: "o3", displayName: "o3", inputPerMillion: 2, outputPerMillion: 8 },
	{ match: "gpt-4-turbo", displayName: "GPT-4 Turbo", inputPerMillion: 10, outputPerMillion: 30 },
	{ match: "gpt-4", displayName: "GPT-4", inputPerMillion: 30, outputPerMillion: 60 },
	{ match: "gpt-3.5", displayName: "GPT-3.5", inputPerMillion: 0.5, outputPerMillion: 1.5 },
];

export interface CostEstimate {
	readonly inputUsd: number;
	readonly outputUsd: number;
	readonly totalUsd: number;
	readonly rate: ModelRate;
}

export function findRate(modelId: string): ModelRate | undefined {
	const id = modelId.toLowerCase();
	return MODEL_RATES.find((r) => id.includes(r.match));
}

export function estimateCost(
	modelId: string,
	inputTokens: number,
	outputTokens: number,
): CostEstimate | undefined {
	const rate = findRate(modelId);
	if (!rate) return undefined;
	const inputUsd = (inputTokens / 1_000_000) * rate.inputPerMillion;
	const outputUsd = (outputTokens / 1_000_000) * rate.outputPerMillion;
	return {
		inputUsd,
		outputUsd,
		totalUsd: inputUsd + outputUsd,
		rate,
	};
}

export function formatUsd(amount: number): string {
	if (amount < 0.01) return `$${amount.toFixed(4)}`;
	if (amount < 1) return `$${amount.toFixed(3)}`;
	return `$${amount.toFixed(2)}`;
}
