// Phase 3.3 (2026-06-04): pure diff helpers shared between the extension
// host (inline-diff feature) and the webview (approval modal + diff
// overlay). Previously each layer had its own ad-hoc diff renderer; this
// module unifies them on a single LCS-based hunk model.

/** A contiguous change between `before` and `after` text. */
export interface DiffHunk {
	/** Stable identifier within a session. */
	readonly id: string;
	/** Line in `before` where the change begins (0-based). */
	readonly beforeStartLine: number;
	/** Line in `after` where the change begins (0-based). */
	readonly afterStartLine: number;
	/** Inclusive end line in `after` (0-based). For pure deletions, equals startLine. */
	readonly afterEndLine: number;
	/** Lines from `before` that were removed (may be empty for pure additions). */
	readonly removedLines: readonly string[];
	/** Lines from `after` that were added (may be empty for pure deletions). */
	readonly addedLines: readonly string[];
}

export type HunkStatus = "pending" | "accepted" | "rejected" | "modified";

export interface InlineDiffSessionState {
	readonly path: string;
	readonly before: string;
	readonly after: string;
	readonly hunks: readonly DiffHunk[];
	readonly status: Readonly<Record<string, HunkStatus>>;
}

/**
 * Compute the hunks between two snapshots. A line-level LCS keeps this
 * dependency-free; tree-sitter / Myers diff comes in a later round when we
 * need semantic alignment. This is good enough for the typical "write a
 * file" surface: small edits diff cleanly, big rewrites collapse into one
 * big hunk (which is what we want anyway).
 */
export function computeHunks(before: string, after: string): DiffHunk[] {
	const a = splitLines(before);
	const b = splitLines(after);
	const lcs = longestCommonSubsequence(a, b);
	const hunks: DiffHunk[] = [];

	let i = 0;
	let j = 0;
	let nextId = 1;
	for (const [ai, bi] of lcs) {
		if (i < ai || j < bi) {
			const removed = a.slice(i, ai);
			const added = b.slice(j, bi);
			hunks.push({
				id: `h${nextId++}`,
				beforeStartLine: i,
				afterStartLine: j,
				afterEndLine: Math.max(j, j + added.length - 1),
				removedLines: removed,
				addedLines: added,
			});
		}
		i = ai + 1;
		j = bi + 1;
	}
	if (i < a.length || j < b.length) {
		const removed = a.slice(i);
		const added = b.slice(j);
		hunks.push({
			id: `h${nextId++}`,
			beforeStartLine: i,
			afterStartLine: j,
			afterEndLine: Math.max(j, j + added.length - 1),
			removedLines: removed,
			addedLines: added,
		});
	}
	return hunks;
}

/**
 * Render a hunk as a flat list of lines with `+` / `-` / ` ` prefixes, plus
 * a small amount of leading/trailing context drawn from `before`. Used by
 * the webview's approval modal + diff overlay to render a unified-diff-
 * style view without taking a dependency on the host's LCS code path
 * twice.
 */
export interface HunkRenderRow {
	readonly sign: "+" | "-" | " ";
	readonly text: string;
}

export interface RenderedHunk {
	readonly hunk: DiffHunk;
	readonly rows: readonly HunkRenderRow[];
}

export function renderHunks(
	before: string,
	hunks: readonly DiffHunk[],
	contextLines = 2,
): RenderedHunk[] {
	const beforeLines = splitLines(before);
	const out: RenderedHunk[] = [];
	for (const h of hunks) {
		const rows: HunkRenderRow[] = [];
		const ctxStart = Math.max(0, h.beforeStartLine - contextLines);
		for (let k = ctxStart; k < h.beforeStartLine; k++) {
			rows.push({ sign: " ", text: beforeLines[k] });
		}
		for (const line of h.removedLines) rows.push({ sign: "-", text: line });
		for (const line of h.addedLines) rows.push({ sign: "+", text: line });
		const ctxAfterStart = h.beforeStartLine + h.removedLines.length;
		const ctxAfterEnd = Math.min(beforeLines.length, ctxAfterStart + contextLines);
		for (let k = ctxAfterStart; k < ctxAfterEnd; k++) {
			rows.push({ sign: " ", text: beforeLines[k] });
		}
		out.push({ hunk: h, rows });
	}
	return out;
}

/** Build an initial review session — every hunk starts pending. */
export function createInlineDiffSession(diff: {
	readonly path: string;
	readonly before: string;
	readonly after: string;
}): InlineDiffSessionState {
	const hunks = computeHunks(diff.before, diff.after);
	const status: Record<string, HunkStatus> = {};
	for (const h of hunks) status[h.id] = "pending";
	return { path: diff.path, before: diff.before, after: diff.after, hunks, status };
}

/** Mark a hunk's status. Pure — returns a new state object. */
export function setHunkStatus(
	state: InlineDiffSessionState,
	hunkId: string,
	next: HunkStatus,
): InlineDiffSessionState {
	if (!state.status[hunkId]) return state;
	if (state.status[hunkId] === next) return state;
	return { ...state, status: { ...state.status, [hunkId]: next } };
}

/**
 * Reduce the state to the final file content: hunks marked `accepted` or
 * `modified` win; `rejected` / `pending` keep the original text. For
 * `modified` hunks the caller passes the user's replacement; if absent we
 * fall back to the original `addedLines`.
 */
export function resolveAcceptedText(
	state: InlineDiffSessionState,
	modifications: Readonly<Record<string, string>> = {},
): string {
	const a = splitLines(state.before);
	const out: string[] = [];
	let cursor = 0;
	for (const h of state.hunks) {
		while (cursor < h.beforeStartLine) {
			out.push(a[cursor]);
			cursor++;
		}
		const status = state.status[h.id] ?? "pending";
		if (status === "accepted") {
			out.push(...h.addedLines);
		} else if (status === "modified") {
			const replacement = modifications[h.id];
			if (replacement !== undefined) {
				out.push(...splitLines(replacement));
			} else {
				out.push(...h.addedLines);
			}
		} else {
			out.push(...h.removedLines);
		}
		cursor += h.removedLines.length;
	}
	while (cursor < a.length) {
		out.push(a[cursor]);
		cursor++;
	}
	return joinLines(out, state.before);
}

/** True when every hunk has been resolved (accepted / rejected / modified). */
export function isFullyResolved(state: InlineDiffSessionState): boolean {
	for (const h of state.hunks) {
		if ((state.status[h.id] ?? "pending") === "pending") return false;
	}
	return true;
}

/** Split keeping `\r\n` boundaries intact for round-tripping. */
export function splitLines(text: string): string[] {
	if (text.length === 0) return [];
	const parts = text.split(/\r?\n/);
	if (parts[parts.length - 1] === "" && /\r?\n$/.test(text)) parts.pop();
	return parts;
}

export function joinLines(lines: readonly string[], original: string): string {
	const eol = /\r\n/.test(original) ? "\r\n" : "\n";
	const trailing = /\r?\n$/.test(original) ? eol : "";
	return lines.join(eol) + trailing;
}

/** Standard quadratic LCS — returns matching `(i,j)` pairs in order. */
function longestCommonSubsequence(
	a: readonly string[],
	b: readonly string[],
): Array<[number, number]> {
	const m = a.length;
	const n = b.length;
	if (m === 0 || n === 0) return [];
	const dp: number[][] = Array.from({ length: m + 1 }, () => new Array<number>(n + 1).fill(0));
	for (let i = m - 1; i >= 0; i--) {
		for (let j = n - 1; j >= 0; j--) {
			if (a[i] === b[j]) dp[i][j] = dp[i + 1][j + 1] + 1;
			else dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
		}
	}
	const out: Array<[number, number]> = [];
	let i = 0;
	let j = 0;
	while (i < m && j < n) {
		if (a[i] === b[j]) {
			out.push([i, j]);
			i++;
			j++;
		} else if (dp[i + 1][j] >= dp[i][j + 1]) {
			i++;
		} else {
			j++;
		}
	}
	return out;
}
