import type { ConversationMessage } from "./agent";
import type { ToolSpec } from "./tools";

export interface TokenUsage {
	readonly inputTokens: number;
	readonly outputTokens: number;
}

export type ProviderStreamEvent =
	| { readonly type: "text_delta"; readonly text: string }
	/**
	 * 2026-06-01: thinking-mode reasoning content (Kimi K2.6 thinking
	 * variants, DeepSeek-R1, GPT-o1, several Qwen reasoning variants).
	 * Separated from `text_delta` so consumers can:
	 *   - accumulate into a ReasoningPart on the assistant history (Moonshot
	 *     requires this round-trip; refuses next turn otherwise with
	 *     "thinking is enabled but reasoning_content is missing"), AND
	 *   - render with a 💭 marker in the UI without conflating with answer text.
	 */
	| { readonly type: "reasoning_delta"; readonly text: string }
	| {
			readonly type: "tool_call";
			readonly id: string;
			readonly name: string;
			readonly args: unknown;
	  }
	| { readonly type: "usage"; readonly usage: TokenUsage }
	| {
			readonly type: "message_end";
			readonly stopReason: "end" | "tool_use" | "max_tokens" | "error";
	  }
	| { readonly type: "error"; readonly message: string };

export interface ProviderRequest {
	readonly messages: readonly ConversationMessage[];
	readonly tools?: readonly ToolSpec[];
	readonly modelId: string;
	readonly systemPrompt?: string;
	readonly maxTokens?: number;
	readonly temperature?: number;
	readonly signal?: AbortSignal;
}

export interface ProviderSpec {
	readonly id: string;
	readonly displayName: string;
	stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent>;
}
