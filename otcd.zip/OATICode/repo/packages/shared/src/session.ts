/**
 * Per-session metadata that the host maintains in its session index.
 * The full conversation history lives under a separate per-session key
 * so the index stays small even if individual sessions grow large.
 */
export interface SessionMeta {
	readonly id: string;
	readonly title: string;
	readonly createdAt: string;
	readonly lastUpdatedAt: string;
	readonly messageCount: number;
	// R3-D: conversation branching — when this session was forked from another,
	// `parentSessionId` points at the source and `forkedAtMessageId` is the
	// UiMessage id we cloned up-to-and-including. Both default to undefined and
	// are populated by `conversation-branching.forkConversation`.
	readonly parentSessionId?: string;
	readonly forkedAtMessageId?: string;
	// R5-D: agent personas — id of the active built-in persona (see
	// `extension-host/src/personas.ts`). `undefined` (default) means no
	// persona is layered onto the active mode's system prompt. Persisted so
	// the persona survives reload + restore_session.
	readonly personaId?: string;
}

export interface SessionIndex {
	readonly version: number;
	readonly sessions: readonly SessionMeta[];
}

export function deriveSessionTitle(firstUserText: string | undefined): string {
	if (!firstUserText) return "New chat";
	const flat = firstUserText.replace(/\s+/g, " ").trim();
	if (flat.length === 0) return "New chat";
	return flat.length > 60 ? `${flat.slice(0, 60)}…` : flat;
}
