import type { DiffPreview, HostContext } from "./host-context";

export type ApprovalPolicy = "auto" | "prompt" | "deny";

export interface ApprovalPreview {
	readonly diff?: DiffPreview;
	/**
	 * 2026-06-02: multi-file approval. Tools that touch >1 file (notably
	 * batch_file_edit) populate `diffs` with one entry per affected file so
	 * the approval modal can render a navigable per-file view via the
	 * MultiFileDiff component. When set, callers should prefer `diffs`
	 * over `diff` for rendering. `diff` stays populated as a single-file
	 * fallback for hosts that haven't upgraded to the multi-file view.
	 */
	readonly diffs?: readonly DiffPreview[];
	readonly note?: string;
}

export interface JsonSchemaProperty {
	readonly type: "string" | "number" | "integer" | "boolean" | "array" | "object";
	readonly description?: string;
	readonly enum?: readonly string[];
	readonly items?: JsonSchemaProperty;
	// Object-shaped properties (and object-shaped array items) may declare a
	// nested schema so the model sees the full structure rather than just the
	// outer description. Optional — most tools still inline the shape in
	// `description` and leave these undefined.
	readonly properties?: Readonly<Record<string, JsonSchemaProperty>>;
	readonly required?: readonly string[];
	readonly default?: unknown;
}

export interface JsonSchema {
	readonly type: "object";
	readonly properties: Readonly<Record<string, JsonSchemaProperty>>;
	readonly required?: readonly string[];
	readonly additionalProperties?: boolean;
}

export interface ToolCallContext {
	/** Stable id of this tool call (matches the `ToolCallPart.id`). */
	readonly callId: string;
	/** Id of the agent that issued this call. */
	readonly agentId: string;
}

export interface ToolSpec<Args = unknown, Result = unknown> {
	readonly name: string;
	readonly description: string;
	readonly schema: JsonSchema;
	readonly approval: ApprovalPolicy;
	readonly handler: (args: Args, ctx: HostContext, callCtx?: ToolCallContext) => Promise<Result>;
	/**
	 * Optional: produce a richer preview to show in the approval dialog (e.g. a diff).
	 * Runs in the host before requestApproval, with the same args the handler will see.
	 */
	readonly prepareApprovalPreview?: (args: Args, ctx: HostContext) => Promise<ApprovalPreview>;
	/**
	 * Optional visibility scope. Tools marked `"sub-agent"` are only exposed to
	 * sub-agents spawned via `spawn_parallel_agents`; absent means the tool is
	 * generally available. The conductor/agent layers honor this filter when
	 * gathering tools for a spawn.
	 */
	readonly scope?: "sub-agent";
	/**
	 * Phase 2.2 (2026-05-23): which model capability must be true for
	 * this tool to be shown to the model. When the active model's
	 * `ModelQuirks.{capability}` is false, the tool is filtered out of
	 * the toolbelt before the agent loop ever sees it.
	 *
	 * Default absent — most tools have no capability gate and are
	 * always exposed. Only tools that demonstrably fail on weak models
	 * (sub-agent orchestration, structured plan emission) need a gate.
	 *
	 * Kept as a small string union (not a free-form string) so a typo
	 * at the call site is a compile error, not a runtime "tool silently
	 * always filtered out" footgun.
	 */
	readonly requiredCapability?: ToolCapabilityRequirement;
}

export type ToolCapabilityRequirement = "spawn-sub-agents" | "plan";

export interface ToolInvocation {
	readonly id: string;
	readonly name: string;
	readonly args: unknown;
}

export interface ToolInvocationResult {
	readonly id: string;
	readonly output: unknown;
	readonly isError: boolean;
}
