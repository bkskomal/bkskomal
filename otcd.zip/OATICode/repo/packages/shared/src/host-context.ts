export interface ApprovalRequest {
	readonly id: string;
	readonly toolName: string;
	readonly args: unknown;
	readonly summary: string;
	readonly preview?: import("./tools").ApprovalPreview;
}

export interface DiffPreview {
	readonly path: string;
	readonly before: string;
	readonly after: string;
}

// 2026-05-27: AskUser — structured clarifying-question prompt the model can
// fire from the `ask_user` tool. Per-mode policy (ModeConfig.allowAskUser)
// controls whether the host actually prompts or auto-picks.
export interface AskUserOption {
	readonly label: string;
	readonly description?: string;
}

export interface AskUserRequest {
	readonly id: string;
	readonly question: string;
	readonly options: readonly AskUserOption[];
	/** When true, the user can type a free-text "Other" response. */
	readonly allowOther?: boolean;
	/** Visual emphasis; "high" might style the prompt as urgent. */
	readonly urgency?: "low" | "high";
}

export interface AskUserAnswer {
	/** The label of the chosen option, OR the free-text the user typed. */
	readonly answer: string;
	/** True when the answer came from the free-text "Other" path. */
	readonly other?: boolean;
	/** True when the host auto-picked rather than waiting for the user. */
	readonly autoPicked?: boolean;
}

/**
 * Which shell to dispatch the command through. `"auto"` keeps the historical
 * behavior (cmd.exe on Windows, /bin/sh elsewhere). The explicit options let
 * the agent target bash on Windows (via Git Bash) or PowerShell on any
 * platform without having to hand-roll a shell prefix.
 */
export type ExecShell = "auto" | "bash" | "pwsh" | "powershell" | "cmd" | "sh";

export interface ExecOptions {
	readonly cwd?: string;
	readonly timeoutMs?: number;
	readonly env?: Readonly<Record<string, string>>;
	/**
	 * Optional streaming callback: invoked for every chunk of stdout (and stderr,
	 * with a `stderr` flag) as the child process emits them. Tools that want
	 * progressive UI can pass this so the host can fan it out to the webview.
	 */
	readonly onChunk?: (chunk: string, stderr: boolean) => void;
	/**
	 * Which shell to run the command through. Defaults to `"auto"` for
	 * backward compatibility (cmd on Windows, sh on Unix). Set to `"bash"`
	 * or `"pwsh"` to explicitly route. The host falls back gracefully when
	 * the requested shell isn't installed (e.g. pwsh → Windows PowerShell).
	 */
	readonly shell?: ExecShell;
}

export interface ExecResult {
	readonly stdout: string;
	readonly stderr: string;
	readonly exitCode: number;
}

export type LogLevel = "debug" | "info" | "warn" | "error";

export interface SubAgentRequest {
	readonly task: string;
	readonly systemPromptOverride?: string;
}

/**
 * A persistent fact the agent has learned about the project, surfaced across
 * sessions via `<workspace>/.oati/facts.json`. Mirrored from the host-side
 * loader so tools in `@oati/tools` can typecheck against it without depending
 * on the extension-host package.
 */
export interface PersistentFact {
	readonly id: string;
	readonly fact: string;
	readonly addedAt: string;
	readonly source: string;
}

export interface SubAgentResult {
	readonly text: string;
	readonly toolCalls: number;
	readonly iterations: number;
}

export interface WorkspaceContextSnapshot {
	readonly workspaceRoot?: string;
	readonly activeFile?: string;
	readonly activeFileLanguage?: string;
	readonly activeSelection?: {
		readonly text: string;
		readonly startLine: number;
		readonly endLine: number;
	};
	readonly openFiles: readonly string[];
}

/**
 * Structural shape of a semantic-search hit, surfaced to tools through
 * `HostContext.codebaseIndex`. The concrete implementation lives in the
 * `@oati/codebase-index` package; we declare the interface here so the
 * shared package doesn't have to import the index runtime.
 */
export interface SemanticSearchHit {
	readonly filePath: string;
	readonly startLine: number;
	readonly endLine: number;
	readonly content: string;
	readonly score: number;
}

export interface SemanticSearchOptions {
	readonly k?: number;
	readonly filter?: {
		readonly extensions?: readonly string[];
	};
}

/**
 * Minimal interface that any concrete codebase index must satisfy to plug
 * into a HostContext. `@oati/codebase-index`'s `CodebaseIndex` class is a
 * superset; the narrower contract here keeps the dependency graph one-way.
 */
export interface CodebaseSearchProvider {
	query(text: string, opts?: SemanticSearchOptions): Promise<readonly SemanticSearchHit[]>;
}

/**
 * Options for `HostContext.startBackgroundProcess`. All fields are
 * optional — the host applies sensible defaults (workspace root for
 * cwd, ambient environment, ~1.5s output capture window).
 */
export interface BackgroundProcessOptions {
	/** Working directory. Defaults to the host's current workspace root. */
	readonly cwd?: string;
	/** Extra environment variables merged onto `process.env`. */
	readonly env?: Readonly<Record<string, string>>;
	/**
	 * Milliseconds to wait for early stdout/stderr before returning.
	 * Lets the caller (the model) see "Listening on port 8000" logs
	 * before deciding the next move. Default 1500ms; clamped to
	 * [100, 10000] by the host.
	 */
	readonly waitForOutputMs?: number;
	/**
	 * Optional human-friendly label shown in the host UI's "running
	 * background processes" list. Defaults to the command itself.
	 */
	readonly label?: string;
}

/**
 * What the host returns for a background process. Stable across the
 * lifetime of the process — `earlyStdout/earlyStderr` are the bytes
 * captured during the `waitForOutputMs` window; further output is
 * NOT streamed back through this object (tools should use `fetch_url`
 * or other observation tools to verify subsequent behaviour).
 */
export interface BackgroundProcessHandle {
	/** OS process id. */
	readonly pid: number;
	/** The exact command string passed to start. */
	readonly command: string;
	/** Working directory the process was spawned in. */
	readonly cwd: string;
	/** Display label (defaults to command). */
	readonly label: string;
	/** Unix milliseconds since epoch when the process was spawned. */
	readonly startedAt: number;
	/** Stdout captured during the initial wait window (capped at 8KB). */
	readonly earlyStdout: string;
	/** Stderr captured during the initial wait window (capped at 8KB). */
	readonly earlyStderr: string;
	/**
	 * If the process exited DURING the wait window, the exit code is
	 * surfaced here. Undefined means "still running when we returned" —
	 * the common case for dev servers.
	 */
	readonly exitedDuringWait?: number;
}

export interface HostContext {
	readFile(path: string): Promise<string>;
	writeFile(path: string, content: string): Promise<void>;
	fileExists(path: string): Promise<boolean>;
	exec(command: string, options?: ExecOptions): Promise<ExecResult>;
	workspaceRoot(): string | undefined;
	requestApproval(req: Omit<ApprovalRequest, "id">): Promise<boolean>;
	showDiff(diff: DiffPreview): Promise<void>;
	log(level: LogLevel, message: string): void;
	/**
	 * 2026-05-27: ask the user a multiple-choice clarifying question.
	 * Returns the chosen option's label (or free-text when `allowOther`
	 * was true and the user typed). Hosts that don't implement this
	 * MAY omit it — the `ask_user` tool falls back to picking option[0]
	 * with a chat-visible note.
	 */
	askUser?(req: AskUserRequest): Promise<AskUserAnswer>;
	/** Optional: spawn a child agent with its own loop. Returns the final summary. */
	spawnSubAgent?(req: SubAgentRequest): Promise<SubAgentResult>;
	/**
	 * Optional: spawn multiple sub-agents concurrently with a concurrency cap.
	 * Results are returned in the same order as `requests`. Implementations
	 * typically reuse `spawnSubAgent` under a small in-process pool.
	 */
	spawnSubAgentsParallel?(
		requests: readonly SubAgentRequest[],
		concurrency: number,
		opts?: SpawnSubAgentsOptions,
	): Promise<readonly SubAgentResult[]>;
	/** Optional: IDE-specific context — current file, selection, open tabs. */
	getWorkspaceContext?(): Promise<WorkspaceContextSnapshot>;
	/** Optional: load persistent facts from `<workspace>/.oati/facts.json`. */
	loadFacts?(): Promise<readonly PersistentFact[]>;
	/** Optional: append a new persistent fact (idempotent on `fact` text). */
	addFact?(fact: { fact: string; source?: string }): Promise<readonly PersistentFact[]>;
	/**
	 * 2026-06-03: append a chunk to the workspace's project memory file
	 * (OATI.md / CLAUDE.md, whichever exists; bootstraps OATI.md when
	 * none does). Used by the `suggest_project_memory_addition` tool
	 * so the agent can propose durable facts at end-of-turn. Returns
	 * the absolute path written so the chat affordance can surface
	 * "Added to <path>" to the user.
	 */
	appendToProjectMemory?(chunk: string, source?: "agent" | "user"): Promise<{ path: string }>;
	/**
	 * Optional: write to the per-parent-agent shared scratchpad. Only sub-agents
	 * spawned via `spawnSubAgentsParallel` see a populated parentAgentId; the
	 * top-level agent uses the empty string and writes are dropped.
	 */
	scratchpadWrite?(agentId: string, note: string): void;
	/** Optional: read all notes from the shared scratchpad for `agentId`. */
	scratchpadRead?(agentId: string): readonly ScratchpadNote[];
	/**
	 * Optional: emit a streaming chunk for a running tool call so the UI can
	 * progressively render output. Tools opt-in via `ctx.emitToolProgress(...)`.
	 */
	emitToolProgress?(callId: string, chunk: string): void;
	/**
	 * Optional: workspace-scoped semantic code search. Lazily initialized by
	 * the host on first `code_semantic_search` invocation. When undefined, the
	 * tool surfaces a friendly "indexing not available" message rather than
	 * failing the agent loop.
	 */
	readonly codebaseIndex?: CodebaseSearchProvider;
	/**
	 * 2026-06-01: optional repo-map provider. Returns a compressed
	 * top-level-symbols view of the workspace that the agent injects into
	 * the system prompt once per session for orientation. When undefined
	 * the agent runs without a repo map (existing behavior). Sized to a
	 * token budget by the implementation; the agent passes a hint via
	 * `opts.tokenBudget` but the provider may return a smaller string.
	 */
	getRepoMap?(opts?: { tokenBudget?: number }): Promise<string | undefined>;
	/**
	 * 2026-06-03: workspace-rooted project memory file (OATI.md +
	 * optional .oati/context.md). Auto-loaded once per Agent session
	 * and prepended to the system prompt — the equivalent of Claude
	 * Code's CLAUDE.md pattern. Lets users curate facts, conventions,
	 * and "things the agent should always know" in a single editable
	 * markdown file checked into the repo. Returns undefined when no
	 * such file exists (most workspaces won't have one yet).
	 */
	getProjectMemory?(): Promise<string | undefined>;
	/**
	 * 2026-06-03: append a chunk to the per-session archive on disk
	 * (`.oati/sessions/<sessionId>/archive.md`). Called from the agent
	 * loop when a predictive compact drops the middle of history — the
	 * full pre-compact transcript gets archived so the model can read
	 * it back later via the `read_session_archive` tool when it needs
	 * detail that the in-memory summary doesn't carry. Best-effort:
	 * failures shouldn't break the agent loop.
	 */
	appendToSessionArchive?(sessionId: string, content: string): Promise<void>;
	/**
	 * 2026-06-03: read back the per-session archive. Used by the
	 * `read_session_archive` tool. Returns undefined when the archive
	 * doesn't exist or can't be read.
	 */
	readSessionArchive?(sessionId: string): Promise<string | undefined>;
	/**
	 * Optional: LSP-backed symbol lookups (references, definitions, document
	 * symbols). Wired by the extension-host against `vscode.commands.executeCommand`.
	 * When undefined the corresponding tools surface a friendly "not available"
	 * message rather than failing the agent loop. APPENDED in R3-A.
	 */
	readonly symbols?: SymbolLookupProvider;
	// R4-B: diagnostics bridge — read/subscribe to LSP-reported errors,
	// warnings, info, hints across the workspace. Wired in the extension-host
	// against `vscode.languages.getDiagnostics()` +
	// `vscode.languages.onDidChangeDiagnostics`. Non-VS Code hosts can leave
	// this undefined; the `get_diagnostics` tool surfaces a friendly fallback.
	readonly diagnostics?: DiagnosticsProvider;
	// R5-C: conversation-search bridge — semantic search across the message
	// bodies of every past session in the workspace. Lazily initialized by
	// the host on first `search_conversations` invocation. When undefined
	// the tool surfaces a friendly "not available" message rather than
	// failing the agent loop.
	readonly conversationSearch?: ConversationSearchProvider;
	// R6-E: debug bridge — read the current debug session (stack frames,
	// scopes, variables, evaluate) and manage source breakpoints. Wired by
	// the extension-host against `vscode.debug.*`; non-VS Code hosts can
	// leave this undefined and the related tools will surface a friendly
	// "no debug session" message rather than failing the agent loop.
	readonly debug?: DebugBridgeProvider;
	// R6-B: Jupyter notebook bridge — read/edit/execute .ipynb cells via
	// `vscode.workspace.openNotebookDocument` + `vscode.NotebookEdit`. When
	// undefined the related tools surface a friendly "not available" message
	// (or, for `read_notebook` / `read_notebook_cell`, fall back to parsing
	// the on-disk JSON envelope directly).
	readonly notebooks?: NotebookProvider;
	// R8-C: pluggable context-provider lookup. The extension-host wires this
	// against the in-process registry in `extension-host/src/context-providers`;
	// non-VS Code hosts (and the `resolve_context_mention` tool's unit tests)
	// can leave it undefined to opt out. The tool then surfaces a friendly
	// "not available" message rather than failing the agent loop.
	readonly contextProviders?: ContextProviderHostBridge;
	/**
	 * Phase 2.3 (2026-05-23): id of the model the agent loop is
	 * currently using (e.g., "moonshotai/kimi-k2", "claude-sonnet-4-6").
	 * Tools read this when they need to apply per-model behaviour —
	 * `spawn_parallel_agents` uses it to look up the active model's
	 * `parallelConcurrencyCap` and clamp user-requested concurrency.
	 * Undefined when no agent is currently active (host startup, etc.).
	 */
	readonly activeModelId?: string;
	/**
	 * 2026-05-23: spawn a long-running process (dev server, build
	 * watcher, anything that doesn't return) as a detached background
	 * process. Returns immediately with the PID and any early stdout
	 * captured during `waitForOutputMs` — useful so the model sees the
	 * "Listening on port 8000" log line before it has to make the next
	 * decision. The host tracks the PID and SHOULD kill the process
	 * automatically on session end so the user never leaves a chat
	 * window with orphan servers running.
	 *
	 * Wired by hosts that have process-spawn capability (extension-host
	 * + sidecar). Non-process hosts (e.g., a browser-based shell) leave
	 * this undefined and the `start_background_process` tool surfaces a
	 * friendly "not supported here" message.
	 */
	startBackgroundProcess?(
		command: string,
		options?: BackgroundProcessOptions,
	): Promise<BackgroundProcessHandle>;
	/**
	 * Stop a previously-started background process by PID. Returns
	 * `{ killed: true }` when the signal was delivered; `{ killed: false }`
	 * when the PID wasn't found (already exited, never started, or
	 * managed by a different chat panel).
	 */
	stopBackgroundProcess?(pid: number): Promise<{ killed: boolean }>;
	/**
	 * List the background processes started in this session. Used by
	 * the host UI to surface "X servers still running" warnings and by
	 * the model to query state when it forgets which PID is which.
	 */
	listBackgroundProcesses?(): readonly BackgroundProcessHandle[];
	/**
	 * Phase 1.3 (2026-05-23): single-shot LLM call exposed to tools that
	 * want to layer the active model's judgment on top of coarser
	 * retrieval (Reciprocal Rank Fusion → LLM-as-reranker). Returns the
	 * accumulated text from one streaming completion.
	 *
	 * Wired by the extension-host ONLY when the user has opted in via
	 * `oati.codebaseIndex.rerank = true`. Undefined when the setting is
	 * off — the tool then skips the rerank pass and returns hybrid-only
	 * results. Default-off keeps the search cheap unless the user has
	 * explicitly traded latency + tokens for better ranking.
	 *
	 * This capability is intentionally narrow (single prompt, single
	 * response, no tools, no conversation) so it doesn't become a
	 * footgun for "let me sneak an LLM call out of the tool layer."
	 * If a future tool needs richer LLM access, add a separate, named
	 * capability rather than widening this one.
	 */
	readonly rerankerLlmCall?: (prompt: string, signal?: AbortSignal) => Promise<string>;
	// Absolute filesystem path to the extension's bundled skills directory
	// (`<extensionRoot>/assets/skills`). When set, the skills loader merges
	// these built-in playbooks with any workspace-local skills under
	// `<workspace>/.oati/skills`. Workspace skills shadow bundled ones with
	// the same name so a user can override the default. Unset for non-VS
	// Code hosts; in that case only workspace skills are visible.
	readonly bundledSkillsDir?: string;
	// Replace the agent-managed todo list for the current session. The host
	// persists the snapshot per-session and broadcasts a `todos_updated`
	// event to the webview so the checklist panel can re-render. Called by
	// the `todo_write` tool; non-VS Code hosts may leave undefined.
	updateTodos?(items: readonly import("./messages").UiTodoItem[]): void;
	/**
	 * Mutate the project root that subsequent relative-path tool calls
	 * resolve against. Called by the `set_workspace_root` tool (so the
	 * model can react to "set the project path to X") and by the `/cwd`
	 * slash command. Returns the absolute path that was actually set,
	 * which may differ from the input if the host expanded `~` or
	 * resolved a relative input against an existing root.
	 *
	 * Implementations should reject paths that don't exist on disk and
	 * surface the failure as a thrown Error so the tool result can name
	 * the problem. Non-IDE hosts may leave undefined; the tool then
	 * surfaces a friendly "not supported" message.
	 */
	setWorkspaceRoot?(path: string): Promise<string>;
	/**
	 * Direct directory listing — honors the host's workspace root for
	 * relative paths. Lets `list_dir` skip the brittle shell-out path so
	 * the model sees real entries (not whatever the sidecar's CWD
	 * happens to contain). Throws a Claude-style error on failure.
	 */
	readDir?(
		path: string,
		opts?: { recursive?: boolean; maxEntries?: number },
	): Promise<{
		path: string;
		entries: readonly { name: string; type: "file" | "directory"; size?: number }[];
		truncated: boolean;
	}>;
	/**
	 * Animated "streaming" file write — opens the file in the editor and
	 * applies `content` in small chunks separated by short delays so the
	 * user perceives the model writing the file character-by-character
	 * (Cursor / Claude Code style). Falls back to the standard `writeFile`
	 * on errors. Optional; non-VS Code hosts may leave undefined.
	 */
	streamFileWrite?(
		path: string,
		content: string,
		opts?: { chunkChars?: number; frameMs?: number },
	): Promise<void>;
}

// R8-C: minimal contract any context-provider backend must satisfy so the
// `resolve_context_mention` tool can fetch resolved blocks without depending
// on the extension-host package. Mirrors the registry surface.
export interface ContextProviderHostBridge {
	/**
	 * Resolve a single mention against the registry. `mention` may be the bare
	 * id (`problems`) or the literal `@mention` (`@problems`); inline arguments
	 * after a `:` are honored.
	 */
	resolve(mention: string, arg: string | undefined): Promise<string>;
	/** Snapshot of every registered provider for discovery + error messages. */
	list(): readonly { readonly id: string; readonly mention: string; readonly description: string }[];
}

// R5-C: shape of a conversation-search hit, mirrored here so the shared
// package doesn't depend on the extension-host runtime. Coordinates are the
// canonical `(sessionId, messageId)` pair the chat panel uses to render
// jump links.
export interface ConversationSearchHit {
	readonly sessionId: string;
	readonly messageId: string;
	readonly role: string;
	readonly snippet: string;
	readonly score: number;
	readonly createdAt: string;
}

export interface ConversationSearchOptions {
	readonly k?: number;
	readonly sessionId?: string;
}

// R5-C: minimal contract any conversation-search backend must satisfy to
// plug into a HostContext. The extension-host's `SessionIndex` is a
// superset; the narrower contract here keeps the dependency direction
// one-way (`shared` does not import `extension-host`).
export interface ConversationSearchProvider {
	search(query: string, opts?: ConversationSearchOptions): Promise<readonly ConversationSearchHit[]>;
}

export interface SpawnSubAgentsOptions {
	/**
	 * Identifier of the agent that initiated this batch. Carried through so
	 * sibling sub-agents share the same scratchpad bucket and so per-call tools
	 * can be scoped to a single parent run.
	 */
	readonly parentAgentId?: string;
	/**
	 * Restricts the tools available to spawned sub-agents. `"sub-agent"` exposes
	 * tools marked with `scope: "sub-agent"` in addition to general-purpose
	 * tools; unset (default) leaves the inherited tool list intact.
	 */
	readonly scope?: "sub-agent";
}

export interface ScratchpadNote {
	readonly note: string;
	readonly author: string;
	readonly at: string;
}

/**
 * Result of an LSP-backed symbol lookup (definition / references). Coordinates
 * are 1-based to line up with the rest of our index types and with what tools
 * surface to the agent. `snippet` is a short excerpt around the hit so the
 * agent can decide whether to read the file in full. APPENDED in R3-A.
 */
export interface SymbolHit {
	readonly path: string;
	readonly line: number;
	readonly character?: number;
	readonly snippet: string;
}

/**
 * A symbol declared inside a single document, as returned by an LSP document-
 * symbol provider. `parent` (if present) is the name of the enclosing symbol —
 * useful for distinguishing two methods named `init` on different classes.
 * APPENDED in R3-A.
 */
export interface DocumentSymbol {
	readonly name: string;
	readonly kind: string;
	readonly line: number;
	readonly endLine?: number;
	readonly parent?: string;
}

/**
 * Optional LSP-backed lookup capability. The extension-host implementation
 * wraps `vscode.commands.executeCommand('vscode.executeReferenceProvider', ...)`
 * et al; non-VS Code hosts can leave it undefined and the related tools will
 * surface a friendly "not available in this host" message rather than failing
 * the agent loop. APPENDED in R3-A.
 */
export interface SymbolLookupProvider {
	findReferences(path: string, line: number, character: number): Promise<readonly SymbolHit[]>;
	findDefinition(path: string, line: number, character: number): Promise<readonly SymbolHit[]>;
	documentSymbols(path: string): Promise<readonly DocumentSymbol[]>;
}

// R4-B: diagnostics bridge — a single workspace-wide snapshot/subscription
// surface backed by `vscode.languages.getDiagnostics()`. Mirrored here so
// `@oati/tools` can typecheck against `ctx.diagnostics` without importing
// the extension-host package. Coordinates are 1-based on both axes to match
// the rest of our index types (LSP is 0-based; the host bridge translates).
export interface DiagnosticEntry {
	readonly path: string;
	readonly line: number;
	readonly column: number;
	readonly endLine: number;
	readonly endColumn: number;
	readonly severity: "error" | "warning" | "info" | "hint";
	readonly message: string;
	readonly source?: string;
	readonly code?: string;
}

// R4-B: diagnostics bridge — read snapshot + subscribe to changes. `all()`
// optionally filters by workspace-relative path and severity. `onChange`
// returns an unsubscribe fn; the listener receives the set of paths whose
// diagnostics changed in this batch.
export interface DiagnosticsProvider {
	/** Snapshot of all current diagnostics; optionally filtered to a path. */
	all(opts?: {
		path?: string;
		severity?: ("error" | "warning" | "info" | "hint")[];
	}): Promise<readonly DiagnosticEntry[]>;
	/** Subscribe to diagnostics changes. Returns an unsubscribe fn. */
	onChange(listener: (changedPaths: readonly string[]) => void): () => void;
}

// R6-E: debug bridge — wraps VS Code's Debug API (DAP) so the agent can
// introspect a running debug session (stack frames, scopes, variables,
// evaluate) and manage source breakpoints. Mirrored here so `@oati/tools`
// can typecheck against `ctx.debug` without depending on the extension-host
// package. Coordinates follow LSP conventions on the way in/out where they
// overlap (1-based line numbers) so they align with the rest of the
// HostContext API.
export interface DebugFrame {
	readonly id: number;
	readonly name: string;
	readonly path?: string;
	readonly line?: number;
}

// R6-E: a single workspace breakpoint as seen by the debug bridge. `uri` is
// a `file://` URI on every platform (Windows paths get normalized on the
// host side); the agent can pass either a workspace-relative path or an
// absolute path to setBreakpoint/removeBreakpoint and the host will resolve.
export interface DebugBreakpoint {
	readonly uri: string;
	readonly line: number;
	readonly condition?: string;
	readonly enabled: boolean;
}

// R6-E: minimal contract any debug-session backend must satisfy to plug into
// a HostContext. The extension-host's `DebugBridge` is a superset. Method
// docs intentionally mirror DAP semantics 1:1 — `frameId`s and
// `variablesReference`s are opaque numbers that the agent is expected to
// thread through verbatim.
export interface DebugBridgeProvider {
	getActiveSession(): { id: string; type: string; name: string } | null;
	getStackFrames(threadId?: number): Promise<readonly DebugFrame[]>;
	evaluate(expression: string, frameId?: number): Promise<string>;
	getScopes(frameId: number): Promise<readonly { name: string; variablesReference: number }[]>;
	getVariables(
		variablesReference: number,
	): Promise<readonly { name: string; value: string; type?: string }[]>;
	listBreakpoints(): readonly DebugBreakpoint[];
	setBreakpoint(uri: string, line: number, condition?: string, enabled?: boolean): Promise<void>;
	removeBreakpoint(uri: string, line: number): Promise<void>;
}

// R6-B: Jupyter notebook bridge — a snapshot view of a single cell as the
// agent and tools see it. `outputs` is omitted on `read` calls that pass
// `includeOutputs=false` (the default) so we don't ship execution payloads
// through the context window unless asked. MIME types follow VS Code's
// notebook output convention (`application/vnd.code.notebook.stdout`, etc.).
export interface NotebookCellSnapshot {
	readonly index: number;
	readonly kind: "code" | "markdown";
	readonly language: string;
	readonly source: string;
	readonly outputs?: readonly { readonly mime: string; readonly text: string }[];
}

// R6-B: Jupyter notebook bridge — read/edit/execute notebook cells. The
// extension-host implementation wraps `vscode.workspace.openNotebookDocument`
// and `vscode.NotebookEdit`; non-VS Code hosts can leave it undefined and the
// related tools either surface a friendly "not available" message or fall
// back to parsing the on-disk JSON envelope.
export interface NotebookProvider {
	read(path: string, includeOutputs?: boolean): Promise<readonly NotebookCellSnapshot[]>;
	editCell(path: string, index: number, source: string): Promise<void>;
	insertCell(
		path: string,
		index: number,
		kind: "code" | "markdown",
		source: string,
		language?: string,
	): Promise<void>;
	deleteCell(path: string, index: number): Promise<void>;
	runCell(
		path: string,
		index: number,
	): Promise<readonly { readonly mime: string; readonly text: string }[]>;
}
