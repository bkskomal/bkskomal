// 2026-06-16: prompt builders for vLLM's /v1/completions fallback.
//
// Background: when a vLLM gateway exposes Gemma or Qwen but (a) the
// tokenizer doesn't ship a chat_template AND (b) the server wasn't
// started with `--trust-request-chat-template`, neither the default
// /v1/chat/completions path nor passing chat_template in the request
// body works. The escape hatch is /v1/completions — raw text-in /
// text-out — which doesn't touch the chat-template machinery at all.
//
// The builders below render the same prompt shape the tokenizer's
// chat_template *would* render if it existed. The OpenAI-compatible
// provider calls one of these (per ModelQuirks.promptShape) when
// `useCompletionsFallback` is set, sends the resulting string to
// /v1/completions, and streams the model's raw text back.
//
// Each builder also returns the appropriate stop tokens so vLLM halts
// generation cleanly at the model's natural turn boundary.

/**
 * Per-message shape the builders accept. This is the same union
 * `WireMessage` carries in the openai-compatible provider, narrowed to
 * just the fields the prompt rendering needs (role + flat text content).
 * Callers MUST flatten any tool_calls / role:"tool" entries into inline
 * text before calling — see `flattenToolRolesForChatTemplate` in the
 * provider.
 */
export interface PromptMessage {
	readonly role: "system" | "user" | "assistant";
	readonly content: string;
}

export interface BuiltPrompt {
	readonly prompt: string;
	/** Stop sequences vLLM should respect — typically the model's end-of-turn marker. */
	readonly stop: readonly string[];
}

/**
 * Gemma turn markers. Gemma's official chat template rejects a top-level
 * `system` role, so any system message folds into the first user turn as
 * a prefix. Matches the behaviour of the Jinja template Google ships
 * with Gemma 3 — Gemma 4 uses the same turn markers.
 */
export function buildGemmaPrompt(messages: readonly PromptMessage[]): BuiltPrompt {
	let systemText = "";
	const rest: PromptMessage[] = [];
	for (const m of messages) {
		if (m.role === "system") systemText = `${systemText}${m.content}\n`.trimEnd();
		else rest.push(m);
	}
	const parts: string[] = ["<bos>"];
	let firstUserSeen = false;
	for (const m of rest) {
		if (m.role === "user") {
			parts.push("<start_of_turn>user\n");
			if (!firstUserSeen && systemText) {
				parts.push(`${systemText}\n\n`);
				firstUserSeen = true;
			}
			parts.push(`${m.content.trim()}<end_of_turn>\n`);
		} else if (m.role === "assistant") {
			parts.push(`<start_of_turn>model\n${m.content.trim()}<end_of_turn>\n`);
		}
	}
	parts.push("<start_of_turn>model\n");
	return { prompt: parts.join(""), stop: ["<end_of_turn>", "<eos>"] };
}

/**
 * ChatML turn markers. Used by Qwen 2.5 / 3, plus many other open-weight
 * models trained on the OpenAI ChatML convention. Supports system role
 * natively so no folding needed.
 */
export function buildChatMLPrompt(messages: readonly PromptMessage[]): BuiltPrompt {
	const parts: string[] = [];
	for (const m of messages) {
		parts.push(`<|im_start|>${m.role}\n${m.content}<|im_end|>\n`);
	}
	parts.push("<|im_start|>assistant\n");
	return { prompt: parts.join(""), stop: ["<|im_end|>", "<|endoftext|>"] };
}

/**
 * Dispatch helper — picks the right builder for the model's
 * `promptShape` quirk and applies it. Throws on unknown shape so a
 * silent fall-through to wrong markers doesn't produce gibberish.
 */
export function buildPromptForShape(
	shape: "gemma" | "chatml",
	messages: readonly PromptMessage[],
): BuiltPrompt {
	if (shape === "gemma") return buildGemmaPrompt(messages);
	if (shape === "chatml") return buildChatMLPrompt(messages);
	throw new Error(`Unknown promptShape: ${shape as string}`);
}
