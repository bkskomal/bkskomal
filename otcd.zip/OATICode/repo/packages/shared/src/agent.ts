export type Role = "user" | "assistant" | "system" | "tool";

export interface TextPart {
	readonly kind: "text";
	readonly text: string;
}

export interface ToolCallPart {
	readonly kind: "tool_call";
	readonly id: string;
	readonly name: string;
	readonly args: unknown;
}

export interface ToolResultPart {
	readonly kind: "tool_result";
	readonly id: string;
	readonly output: unknown;
	readonly isError: boolean;
}

export interface ImagePart {
	readonly kind: "image";
	/** MIME type, e.g. "image/png", "image/jpeg". */
	readonly mimeType: string;
	/**
	 * Either a `data:` URL (`data:image/png;base64,...`) or raw base64 (no prefix).
	 * Providers normalize as needed at request-mapping time.
	 */
	readonly dataUrl: string;
}

/**
 * 2026-06-01: thinking-mode reasoning trace from the assistant. Captured
 * when the model streams `delta.reasoning_content` (Kimi K2.6 in thinking
 * mode, DeepSeek-R1, GPT-o1, several Qwen reasoning variants). Must
 * round-trip in history for K2.6 — Moonshot's API refuses subsequent
 * turns with `thinking is enabled but reasoning_content is missing in
 * assistant tool call message at index N` when you replay an assistant
 * message without its original reasoning trail. Providers serialize
 * this as the `reasoning_content` field on the wire when it's present.
 */
export interface ReasoningPart {
	readonly kind: "reasoning";
	readonly text: string;
}

export type MessagePart = TextPart | ToolCallPart | ToolResultPart | ImagePart | ReasoningPart;

export interface ConversationMessage {
	readonly role: Role;
	readonly parts: readonly MessagePart[];
}

export type CritiqueVerdict = "approved" | "needs_retry";

export interface Critique {
	readonly verdict: CritiqueVerdict;
	/** Only present when verdict is needs_retry. */
	readonly feedback?: string;
	readonly raw: string;
}

export type PipelineStage = "planner" | "executor" | "critic";

export type AgentEvent =
	| {
			/**
			 * Phase 3.1 (2026-05-23): fires exactly once before any iteration
			 * runs for a given `Agent.run(...)` call. Hosts use this to
			 * checkpoint per-turn state (file snapshots, scratchpad bookmark,
			 * timestamp) so the work can be rolled back atomically later via
			 * `revert_turn`. `turnId` is a host-provided opaque token; the
			 * agent passes it back unchanged in the matching `turn_end`.
			 */
			readonly type: "turn_start";
			readonly agentId: string;
			readonly turnId: string;
			readonly userMessage: string;
	  }
	| {
			/**
			 * Phase 3.1: pairs with `turn_start`. Fires after the last
			 * iteration completes (success or failure). Hosts use this to
			 * finalize the checkpoint (e.g., trim retention, expose a
			 * "Revert this turn" button on the assistant bubble).
			 */
			readonly type: "turn_end";
			readonly agentId: string;
			readonly turnId: string;
			readonly outcome: "end" | "max_iterations" | "cancelled" | "error";
	  }
	| { readonly type: "text_delta"; readonly agentId: string; readonly text: string }
	| { readonly type: "tool_call"; readonly agentId: string; readonly call: ToolCallPart }
	| {
			readonly type: "tool_progress";
			readonly agentId: string;
			readonly callId: string;
			readonly chunk: string;
	  }
	| { readonly type: "tool_result"; readonly agentId: string; readonly result: ToolResultPart }
	| { readonly type: "iteration"; readonly agentId: string; readonly n: number }
	| {
			/**
			 * 2026-05-25: emitted when a mid-turn user message gets injected
			 * into the agent's history at an iteration boundary. The webview
			 * uses this to render the queued bubble as "delivered" instead
			 * of "queued", and to scroll the chat to the new entry.
			 */
			readonly type: "user_message_injected";
			readonly agentId: string;
			readonly text: string;
	  }
	| {
			readonly type: "usage";
			readonly agentId: string;
			readonly inputTokens: number;
			readonly outputTokens: number;
	  }
	| {
			readonly type: "stage_started";
			readonly agentId: string;
			readonly stage: PipelineStage;
	  }
	| {
			readonly type: "stage_done";
			readonly agentId: string;
			readonly stage: PipelineStage;
	  }
	| {
			readonly type: "plan";
			readonly agentId: string;
			readonly plan: import("./plan").PlanV2;
	  }
	| { readonly type: "critique"; readonly agentId: string; readonly critique: Critique }
	| {
			readonly type: "retry";
			readonly agentId: string;
			readonly attempt: number;
			readonly reason: string;
	  }
	| {
			readonly type: "done";
			readonly agentId: string;
			readonly reason: "end" | "max_iterations" | "cancelled" | "error";
	  }
	| { readonly type: "error"; readonly agentId: string; readonly message: string };

export interface AgentRunOptions {
	readonly userMessage: string;
	readonly signal?: AbortSignal;
	/** Optional extra non-text parts (images, etc.) appended to the user turn. */
	readonly userParts?: readonly MessagePart[];
}
