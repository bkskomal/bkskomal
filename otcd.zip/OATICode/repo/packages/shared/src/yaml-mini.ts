// Phase 0.5 follow-through (2026-06-04): hand-rolled minimal YAML parser
// for the narrow shapes OATI actually uses. Replaces the ~86KB js-yaml
// bundle weight with ~200 lines of code.
//
// Supported features (the union of what skills.ts + policy.yaml need):
//   - Top-level mappings (`key: value` lines)
//   - Indented nested mappings (consistent indent — 2 or 4 spaces, or
//     tabs; the parser tracks the depth of each line)
//   - Block sequences (`- item` lines) producing string/number arrays
//   - Flow sequences (`[a, b, c]`) producing string/number arrays
//   - Scalar types: strings (quoted with `"` / `'`, or bare), integers,
//     floats, booleans (`true`/`false`/`yes`/`no`), null (`null`/`~`/`` ``)
//   - Comments (`#` to end-of-line, except inside quoted strings)
//   - Blank lines and leading/trailing whitespace
//
// NOT supported (returns a parse error or skips the feature):
//   - Multi-line block scalars (`|` / `>`) — narrow ask; if users want
//     long descriptions, they can quote a single-line string
//   - Anchors / aliases (`&` / `*`)
//   - Complex types, tags, custom types
//   - YAML stream documents (`---` / `...` separators)
//
// On unsupported input the parser throws `YamlMiniError` so the caller can
// fall back to its empty-state behavior — same shape as js-yaml's `load`
// which throws `YAMLException` on malformed input.

export class YamlMiniError extends Error {
	constructor(
		message: string,
		readonly lineNumber: number,
	) {
		super(`YAML parse error at line ${lineNumber}: ${message}`);
		this.name = "YamlMiniError";
	}
}

export type YamlValue =
	| string
	| number
	| boolean
	| null
	| YamlValue[]
	| { [key: string]: YamlValue };

interface Line {
	readonly raw: string;
	readonly indent: number;
	readonly content: string;
	readonly lineNumber: number;
}

/**
 * Parse a YAML string into a JS value. Returns `null` for an empty or
 * comments-only document — mirrors js-yaml's behavior so callers that do
 * `parsed ?? {}` keep working unchanged.
 */
export function parseYaml(input: string): YamlValue {
	const lines = tokenize(input);
	if (lines.length === 0) return null;
	const { value, next } = parseValue(lines, 0, 0);
	if (next < lines.length) {
		throw new YamlMiniError(
			`unexpected content (indent ${lines[next].indent})`,
			lines[next].lineNumber,
		);
	}
	return value;
}

function tokenize(input: string): Line[] {
	const out: Line[] = [];
	const lines = input.split(/\r?\n/);
	for (let i = 0; i < lines.length; i++) {
		const raw = lines[i];
		const stripped = stripComment(raw);
		const trimmed = stripped.replace(/\s+$/, "");
		if (trimmed.trim().length === 0) continue;
		let indent = 0;
		while (indent < trimmed.length && (trimmed[indent] === " " || trimmed[indent] === "\t")) {
			indent++;
		}
		out.push({
			raw,
			indent,
			content: trimmed.slice(indent),
			lineNumber: i + 1,
		});
	}
	return out;
}

function stripComment(line: string): string {
	let inSingle = false;
	let inDouble = false;
	for (let i = 0; i < line.length; i++) {
		const ch = line[i];
		if (ch === '"' && !inSingle) {
			inDouble = !inDouble;
			continue;
		}
		if (ch === "'" && !inDouble) {
			inSingle = !inSingle;
			continue;
		}
		if (ch === "#" && !inSingle && !inDouble) {
			return line.slice(0, i);
		}
	}
	return line;
}

interface ParseResult {
	readonly value: YamlValue;
	readonly next: number;
}

function parseValue(lines: Line[], start: number, parentIndent: number): ParseResult {
	if (start >= lines.length) return { value: null, next: start };
	const line = lines[start];
	if (line.content.startsWith("- ") || line.content === "-") {
		return parseSequence(lines, start, line.indent);
	}
	if (line.content.includes(":")) {
		return parseMapping(lines, start, line.indent, parentIndent);
	}
	throw new YamlMiniError(`expected mapping or sequence, got "${line.content}"`, line.lineNumber);
}

function parseSequence(lines: Line[], start: number, indent: number): ParseResult {
	const items: YamlValue[] = [];
	let i = start;
	while (i < lines.length) {
		const line = lines[i];
		if (line.indent < indent) break;
		if (line.indent > indent) {
			throw new YamlMiniError("unexpected indent in sequence", line.lineNumber);
		}
		if (!(line.content.startsWith("- ") || line.content === "-")) break;
		const itemBody = line.content === "-" ? "" : line.content.slice(2);
		if (itemBody.length === 0) {
			// `-` alone — nested structure follows on the next line at deeper indent.
			if (i + 1 < lines.length && lines[i + 1].indent > indent) {
				const { value, next } = parseValue(lines, i + 1, indent);
				items.push(value);
				i = next;
				continue;
			}
			items.push(null);
			i++;
			continue;
		}
		// Inline item — could be a scalar or a "key: value" mapping entry.
		if (itemBody.includes(":") && !startsWithQuote(itemBody)) {
			// Treat as a one-line mapping; the next deeper indent (if any) extends it.
			const synthetic: Line[] = [
				{
					raw: itemBody,
					indent: indent + 2,
					content: itemBody,
					lineNumber: line.lineNumber,
				},
			];
			let j = i + 1;
			while (j < lines.length && lines[j].indent > indent) {
				synthetic.push({ ...lines[j], indent: lines[j].indent });
				j++;
			}
			const { value } = parseValue(synthetic, 0, indent + 1);
			items.push(value);
			i = j;
			continue;
		}
		items.push(parseScalar(itemBody, line.lineNumber));
		i++;
	}
	return { value: items, next: i };
}

function parseMapping(
	lines: Line[],
	start: number,
	indent: number,
	parentIndent: number,
): ParseResult {
	if (indent <= parentIndent && parentIndent > 0) {
		// We were asked to parse a mapping that's actually at the parent's
		// level — the caller is done.
		return { value: null, next: start };
	}
	const obj: { [key: string]: YamlValue } = {};
	let i = start;
	while (i < lines.length) {
		const line = lines[i];
		if (line.indent < indent) break;
		if (line.indent > indent) {
			throw new YamlMiniError("unexpected indent in mapping", line.lineNumber);
		}
		if (line.content.startsWith("- ")) break;
		const colon = findMappingColon(line.content);
		if (colon === -1) {
			throw new YamlMiniError(`expected "key: value", got "${line.content}"`, line.lineNumber);
		}
		const key = unquote(line.content.slice(0, colon).trim());
		const valueText = line.content.slice(colon + 1).trim();
		if (valueText.length === 0) {
			// Nested block follows on the next line(s).
			if (i + 1 < lines.length && lines[i + 1].indent > indent) {
				const { value, next } = parseValue(lines, i + 1, indent);
				obj[key] = value;
				i = next;
			} else {
				obj[key] = null;
				i++;
			}
			continue;
		}
		// Inline value — scalar or flow sequence.
		obj[key] = parseInlineValue(valueText, line.lineNumber);
		i++;
	}
	return { value: obj, next: i };
}

function findMappingColon(content: string): number {
	let inSingle = false;
	let inDouble = false;
	let inFlow = 0;
	for (let i = 0; i < content.length; i++) {
		const ch = content[i];
		if (ch === '"' && !inSingle) inDouble = !inDouble;
		else if (ch === "'" && !inDouble) inSingle = !inSingle;
		else if ((ch === "[" || ch === "{") && !inSingle && !inDouble) inFlow++;
		else if ((ch === "]" || ch === "}") && !inSingle && !inDouble) inFlow--;
		else if (ch === ":" && !inSingle && !inDouble && inFlow === 0) {
			// A colon is a mapping separator if it is followed by whitespace
			// or end-of-string. Otherwise it's a URL fragment or a literal.
			const next = content[i + 1];
			if (next === undefined || next === " " || next === "\t") return i;
		}
	}
	return -1;
}

function parseInlineValue(text: string, lineNumber: number): YamlValue {
	if (text.startsWith("[")) {
		if (!text.endsWith("]")) {
			throw new YamlMiniError("unterminated flow sequence (missing `]`)", lineNumber);
		}
		return parseFlowSequence(text.slice(1, -1), lineNumber);
	}
	if (text.startsWith("{")) {
		throw new YamlMiniError("flow mappings ({...}) are not supported", lineNumber);
	}
	return parseScalar(text, lineNumber);
}

function parseFlowSequence(body: string, lineNumber: number): YamlValue[] {
	const parts = splitFlow(body);
	return parts.map((p) => parseScalar(p.trim(), lineNumber));
}

function splitFlow(body: string): string[] {
	const out: string[] = [];
	let depth = 0;
	let inSingle = false;
	let inDouble = false;
	let start = 0;
	for (let i = 0; i < body.length; i++) {
		const ch = body[i];
		if (ch === '"' && !inSingle) inDouble = !inDouble;
		else if (ch === "'" && !inDouble) inSingle = !inSingle;
		else if ((ch === "[" || ch === "{") && !inSingle && !inDouble) depth++;
		else if ((ch === "]" || ch === "}") && !inSingle && !inDouble) depth--;
		else if (ch === "," && depth === 0 && !inSingle && !inDouble) {
			out.push(body.slice(start, i));
			start = i + 1;
		}
	}
	if (start < body.length) out.push(body.slice(start));
	return out.filter((s) => s.trim().length > 0);
}

function parseScalar(text: string, lineNumber: number): YamlValue {
	const trimmed = text.trim();
	if (trimmed.length === 0) return null;
	if (trimmed === "null" || trimmed === "~") return null;
	if (trimmed === "true" || trimmed === "yes" || trimmed === "True") return true;
	if (trimmed === "false" || trimmed === "no" || trimmed === "False") return false;
	if (startsWithQuote(trimmed)) {
		// A quoted scalar must terminate with the same quote. Reject e.g.
		// `name: "ok` (unterminated string) instead of treating it as a bare
		// string — callers rely on this to surface malformed YAML.
		const first = trimmed[0];
		const last = trimmed[trimmed.length - 1];
		if (trimmed.length < 2 || first !== last) {
			throw new YamlMiniError("unterminated quoted string", lineNumber);
		}
		return unquote(trimmed);
	}
	const asNumber = Number(trimmed);
	if (trimmed !== "" && Number.isFinite(asNumber) && /^-?\d+(?:\.\d+)?$/.test(trimmed)) {
		return asNumber;
	}
	return trimmed;
}

function startsWithQuote(s: string): boolean {
	return s.length > 0 && (s[0] === '"' || s[0] === "'");
}

function unquote(s: string): string {
	if (s.length < 2) return s;
	const first = s[0];
	const last = s[s.length - 1];
	if (first === '"' && last === '"') {
		return s
			.slice(1, -1)
			.replace(/\\n/g, "\n")
			.replace(/\\t/g, "\t")
			.replace(/\\"/g, '"')
			.replace(/\\\\/g, "\\");
	}
	if (first === "'" && last === "'") {
		return s.slice(1, -1).replace(/''/g, "'");
	}
	return s;
}
