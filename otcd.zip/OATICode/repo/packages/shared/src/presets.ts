import type { ProviderPresetId, ProviderType } from "./config";

export interface CuratedModel {
	readonly id: string;
	readonly label: string;
	/** Short note shown after the label in the dropdown ("fast", "free", "reasoning"). */
	readonly note?: string;
	/** Marks free-tier models so the UI can badge them. */
	readonly free?: boolean;
}

export interface ProviderPreset {
	readonly id: ProviderPresetId;
	readonly providerType: ProviderType;
	readonly displayName: string;
	readonly baseUrl: string;
	readonly defaultModel: string;
	readonly requiresApiKey: boolean;
	readonly modelPlaceholder: string;
	readonly baseUrlEditable: boolean;
	readonly apiKeyHelp?: string;
	readonly extraHeaders?: Readonly<Record<string, string>>;
	/**
	 * A curated short-list of well-known good models for this provider.
	 * When present, the SettingsPanel renders a dropdown of these (plus a
	 * "Custom…" escape hatch back to free text).
	 *
	 * This is intentionally NOT the live /models list (300+ entries for
	 * OpenRouter) — that level of choice is paralyzing and most of those
	 * models aren't great for coding anyway. Users who know what they want
	 * can still type any model id.
	 */
	readonly curatedModels?: readonly CuratedModel[];
}

/**
 * OpenRouter has 300+ models. These are the ones that consistently do well
 * for agentic coding tasks in early 2026 — frontier models from the major
 * labs, a strong open coder, and the best free options.
 */
const OPENROUTER_CODING_MODELS: readonly CuratedModel[] = [
	{
		id: "anthropic/claude-sonnet-4",
		label: "Claude Sonnet 4 (Anthropic)",
		note: "best all-rounder for coding",
	},
	{
		id: "anthropic/claude-opus-4",
		label: "Claude Opus 4 (Anthropic)",
		note: "highest quality, slower / pricier",
	},
	{
		id: "anthropic/claude-haiku-4-5",
		label: "Claude Haiku 4.5 (Anthropic)",
		note: "fast and cheap",
	},
	{
		id: "openai/gpt-4o",
		label: "GPT-4o (OpenAI)",
		note: "strong all-rounder",
	},
	{
		id: "openai/gpt-4o-mini",
		label: "GPT-4o mini (OpenAI)",
		note: "fast, very cheap",
	},
	{
		id: "openai/o3-mini",
		label: "o3-mini (OpenAI)",
		note: "reasoning, good for hard problems",
	},
	{
		id: "google/gemini-2.0-flash-001",
		label: "Gemini 2.0 Flash (Google)",
		note: "fast, large context",
	},
	{
		id: "google/gemini-2.0-pro-exp",
		label: "Gemini 2.0 Pro (Google)",
		note: "deeper reasoning",
	},
	{
		id: "deepseek/deepseek-r1",
		label: "DeepSeek R1",
		note: "open reasoning, often cheap on OpenRouter",
	},
	{
		id: "deepseek/deepseek-chat",
		label: "DeepSeek V3",
		note: "fast, code-strong, cheap",
	},
	{
		id: "qwen/qwen-2.5-coder-32b-instruct",
		label: "Qwen 2.5 Coder 32B (Alibaba)",
		note: "code-specialized",
	},
	{
		id: "meta-llama/llama-3.3-70b-instruct",
		label: "Llama 3.3 70B (Meta)",
		note: "open, broad coverage",
	},
	// --- Free tier ---
	{
		id: "deepseek/deepseek-r1:free",
		label: "DeepSeek R1 (free)",
		note: "reasoning, no cost",
		free: true,
	},
	{
		id: "meta-llama/llama-3.3-70b-instruct:free",
		label: "Llama 3.3 70B (free)",
		note: "open weights, no cost",
		free: true,
	},
	{
		id: "qwen/qwen-2.5-coder-32b-instruct:free",
		label: "Qwen 2.5 Coder 32B (free)",
		note: "code-specialized, no cost",
		free: true,
	},
];

export const PROVIDER_PRESETS: readonly ProviderPreset[] = [
	{
		id: "openai-compatible",
		providerType: "openai-compatible",
		displayName: "OpenAI Compatible",
		baseUrl: "",
		defaultModel: "",
		requiresApiKey: false,
		modelPlaceholder: "e.g. claude-sonnet-4-6, gpt-4o, etc.",
		baseUrlEditable: true,
		apiKeyHelp: "Optional. Set if your gateway requires it. Stored in VS Code's SecretStorage.",
	},
	{
		id: "openai",
		providerType: "openai-compatible",
		displayName: "OpenAI",
		baseUrl: "https://api.openai.com/v1",
		defaultModel: "gpt-4o",
		requiresApiKey: true,
		modelPlaceholder: "gpt-4o, gpt-4o-mini, o3-mini",
		baseUrlEditable: false,
		curatedModels: [
			{ id: "gpt-4o", label: "GPT-4o", note: "strong all-rounder" },
			{ id: "gpt-4o-mini", label: "GPT-4o mini", note: "fast, cheap" },
			{ id: "o3-mini", label: "o3-mini", note: "reasoning" },
			{ id: "o3", label: "o3", note: "frontier reasoning" },
		],
	},
	{
		id: "openrouter",
		providerType: "openai-compatible",
		displayName: "OpenRouter",
		baseUrl: "https://openrouter.ai/api/v1",
		defaultModel: "anthropic/claude-sonnet-4",
		requiresApiKey: true,
		modelPlaceholder: "e.g. anthropic/claude-sonnet-4, openai/gpt-4o",
		baseUrlEditable: false,
		extraHeaders: {
			"HTTP-Referer": "https://github.com/sbkkomal/codeassistant",
			"X-Title": "OATI Code",
		},
		curatedModels: OPENROUTER_CODING_MODELS,
	},
	{
		// Primary recommended provider for OATI Code. Kimi K2 / K2.6 is the
		// open-source coding workhorse — strong tool-use, very cost-effective,
		// and well-tuned by our model-quirks registry (terseness + arg-format
		// reminders applied automatically).
		id: "kimi-k2",
		providerType: "openai-compatible",
		displayName: "Kimi K2.6 (recommended)",
		baseUrl: "https://openrouter.ai/api/v1",
		defaultModel: "moonshotai/kimi-k2",
		requiresApiKey: true,
		modelPlaceholder: "moonshotai/kimi-k2 or moonshotai/kimi-k2-instruct",
		baseUrlEditable: true,
		extraHeaders: {
			"HTTP-Referer": "https://github.com/sbkkomal/codeassistant",
			"X-Title": "OATI Code",
		},
		curatedModels: [
			{
				id: "moonshotai/kimi-k2",
				label: "Kimi K2 (open-source, recommended primary)",
			},
			{
				id: "moonshotai/kimi-k2-instruct",
				label: "Kimi K2 Instruct (chat-tuned)",
			},
		],
	},
	{
		id: "litellm",
		providerType: "openai-compatible",
		displayName: "LiteLLM",
		baseUrl: "http://localhost:4000/v1",
		defaultModel: "",
		requiresApiKey: false,
		modelPlaceholder: "model alias from your LiteLLM config",
		baseUrlEditable: true,
	},
	{
		id: "unillm",
		providerType: "openai-compatible",
		displayName: "unillm",
		baseUrl: "http://localhost:8080/v1",
		defaultModel: "claude-sonnet-4-6",
		requiresApiKey: false,
		modelPlaceholder: "claude-sonnet-4-6",
		baseUrlEditable: true,
	},
	{
		id: "ollama",
		providerType: "openai-compatible",
		displayName: "Ollama",
		baseUrl: "http://localhost:11434/v1",
		defaultModel: "qwen2.5-coder:7b",
		requiresApiKey: false,
		modelPlaceholder: "e.g. qwen2.5-coder:7b, llama3.3",
		baseUrlEditable: true,
	},
	{
		id: "anthropic",
		providerType: "anthropic",
		displayName: "Anthropic (native)",
		baseUrl: "https://api.anthropic.com/v1",
		defaultModel: "claude-sonnet-4-6",
		requiresApiKey: true,
		modelPlaceholder: "claude-sonnet-4-6, claude-opus-4-7, claude-haiku-4-5-20251001",
		baseUrlEditable: false,
		apiKeyHelp:
			"Anthropic API key. Uses native /v1/messages format with x-api-key header. Stored in VS Code's SecretStorage.",
		curatedModels: [
			{ id: "claude-sonnet-4-6", label: "Claude Sonnet 4.6", note: "fast, capable" },
			{ id: "claude-opus-4-7", label: "Claude Opus 4.7", note: "frontier" },
			{ id: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5", note: "cheap, fast" },
		],
	},
	{
		// 2026-06-06: OATI Compatible — internal OATI vLLM / gateway. OpenAI-
		// compatible wire surface, network-gated rather than API-key-gated
		// (`requiresApiKey: false`). Base URL is per-model on these gateways
		// (each model is served on its own path), so the URL is editable —
		// the pre-filled default points at gpt-oss-120b for first-time setup.
		// Quirks for each model id are matched separately in model-quirks.ts.
		id: "oati-genie",
		providerType: "openai-compatible",
		displayName: "OATI Compatible",
		baseUrl: "https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1",
		defaultModel: "gpt-oss-120b",
		requiresApiKey: false,
		modelPlaceholder: "gpt-oss-120b, gemma-4, …",
		baseUrlEditable: true,
		apiKeyHelp:
			"Not required — OATI internal gateways are network-gated. Leave blank unless your gateway operator says otherwise. NOTE: each model is served on its own Base URL — pick a curated model below to see the URL to use, or paste the URL from the gateway's `/v1/models` docs page.",
		curatedModels: [
			// 2026-06-16: model IDs verified against each gateway's `/v1/models`
			// endpoint. The exact id below must be the one the gateway returns —
			// vLLM serves the HuggingFace path verbatim (`org/model-name`),
			// NOT the colloquial short name.
			{
				id: "openai/gpt-oss-120b",
				label: "gpt-oss-120b",
				note: "OpenAI open-weight 120B (128K) · Base URL: https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1",
			},
			{
				id: "google/gemma-4-26B-A4B",
				label: "gemma-4 (26B-A4B) · best in Ask mode",
				note: "Google Gemma 4 26B-A4B (256K). Best for Q&A / code explanation in Ask mode — not reliable for autonomous multi-file edits. Switch active mode to Ask in Settings → Modes before using. Base URL: http://vllm.dev.services.oati.com/gemma_4/v1",
			},
			{
				// 2026-06-20: cap raised by ops from 16K → 32K, so Qwen is
				// now viable for OATI's agentic flow (base prompt ~17.5K +
				// 4K output cap leaves ~10K conversation headroom). Routes
				// through vLLM's /v1/completions because the gateway has
				// no tokenizer chat_template AND blocks request-side
				// templates via `--trust-request-chat-template`. ContextWindow
				// in model-quirks tracks the gateway's actual max_model_len
				// (32768) so OATI's auto-compact fires before the server
				// would reject.
				id: "Qwen/Qwen3-Coder-30B-A3B-Instruct",
				label: "qwen3-coder (30B-A3B-Instruct)",
				note: "Qwen 3 Coder 30B-A3B-Instruct. Gateway capped at 32K context — short to mid-length sessions only. Use `/compact` if you hit the cap on a long session. Base URL: http://vllm.dev.services.oati.com/qwen3_coder/v1",
			},
		],
	},
	{
		id: "custom",
		providerType: "openai-compatible",
		displayName: "Custom",
		baseUrl: "",
		defaultModel: "",
		requiresApiKey: false,
		modelPlaceholder: "",
		baseUrlEditable: true,
	},
];

export function getPreset(id: ProviderPresetId): ProviderPreset {
	return PROVIDER_PRESETS.find((p) => p.id === id) ?? PROVIDER_PRESETS[0];
}
