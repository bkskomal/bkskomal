// Phase 3.3 (2026-06-04): tests for the shared diff helpers that now back
// both the host's InlineDiffSession and the webview's approval modal.

import { describe, expect, it } from "vitest";
import {
	computeHunks,
	createInlineDiffSession,
	isFullyResolved,
	renderHunks,
	resolveAcceptedText,
	setHunkStatus,
} from "../src/diff";

describe("computeHunks", () => {
	it("returns no hunks when before === after", () => {
		expect(computeHunks("a\nb\nc\n", "a\nb\nc\n")).toEqual([]);
	});

	it("collapses a single contiguous edit into one hunk", () => {
		const before = "a\nb\nc\nd\n";
		const after = "a\nX\nY\nd\n";
		const hunks = computeHunks(before, after);
		expect(hunks).toHaveLength(1);
		expect(hunks[0].removedLines).toEqual(["b", "c"]);
		expect(hunks[0].addedLines).toEqual(["X", "Y"]);
	});

	it("separates non-adjacent changes into distinct hunks", () => {
		const before = "a\nb\nc\nd\ne\nf\n";
		const after = "a\nX\nc\nd\nY\nf\n";
		const hunks = computeHunks(before, after);
		expect(hunks).toHaveLength(2);
		expect(hunks[0].addedLines).toEqual(["X"]);
		expect(hunks[1].addedLines).toEqual(["Y"]);
	});

	it("models a pure addition as a hunk with empty removedLines", () => {
		const hunks = computeHunks("a\nb\n", "a\nX\nb\n");
		expect(hunks).toHaveLength(1);
		expect(hunks[0].removedLines).toEqual([]);
		expect(hunks[0].addedLines).toEqual(["X"]);
	});

	it("models a pure deletion as a hunk with empty addedLines", () => {
		const hunks = computeHunks("a\nb\nc\n", "a\nc\n");
		expect(hunks).toHaveLength(1);
		expect(hunks[0].removedLines).toEqual(["b"]);
		expect(hunks[0].addedLines).toEqual([]);
	});

	it("assigns unique ids to consecutive hunks", () => {
		const hunks = computeHunks("a\nb\nc\n", "X\nb\nY\n");
		const ids = hunks.map((h) => h.id);
		expect(new Set(ids).size).toBe(ids.length);
	});
});

describe("renderHunks", () => {
	it("adds context lines from the before snapshot above and below each hunk", () => {
		const before = "line1\nline2\nline3\nline4\nline5\n";
		const after = "line1\nline2\nCHANGED\nline4\nline5\n";
		const hunks = computeHunks(before, after);
		const rendered = renderHunks(before, hunks, 2);
		expect(rendered).toHaveLength(1);
		// Expected rows: line1, line2 (context), -line3, +CHANGED, line4, line5 (context)
		const signs = rendered[0].rows.map((r) => r.sign).join("");
		expect(signs).toBe("  -+  ");
	});

	it("respects a context-lines override of 0", () => {
		const before = "a\nb\nc\n";
		const after = "a\nX\nc\n";
		const rendered = renderHunks(before, computeHunks(before, after), 0);
		// No context — just the -b / +X rows.
		expect(rendered[0].rows.map((r) => r.sign).join("")).toBe("-+");
	});

	it("clamps context near file boundaries", () => {
		const before = "a\nb\nc\n";
		const after = "X\nb\nc\n";
		// Change is at line 0 — no context above is possible.
		const rendered = renderHunks(before, computeHunks(before, after), 5);
		expect(rendered[0].rows[0].sign).toBe("-");
	});
});

describe("InlineDiffSession state machine", () => {
	it("starts every hunk pending", () => {
		const state = createInlineDiffSession({
			path: "x.ts",
			before: "a\nb\n",
			after: "a\nX\n",
		});
		expect(state.hunks).toHaveLength(1);
		expect(state.status[state.hunks[0].id]).toBe("pending");
		expect(isFullyResolved(state)).toBe(false);
	});

	it("setHunkStatus is pure (returns a new state, leaves the old one alone)", () => {
		const state = createInlineDiffSession({
			path: "x.ts",
			before: "a\nb\n",
			after: "a\nX\n",
		});
		const id = state.hunks[0].id;
		const next = setHunkStatus(state, id, "accepted");
		expect(state.status[id]).toBe("pending");
		expect(next.status[id]).toBe("accepted");
		expect(next).not.toBe(state);
	});

	it("isFullyResolved returns true once every hunk has been touched", () => {
		const state = createInlineDiffSession({
			path: "x.ts",
			before: "a\nb\nc\nd\ne\nf\n",
			after: "a\nX\nc\nd\nY\nf\n",
		});
		expect(isFullyResolved(state)).toBe(false);
		const s1 = setHunkStatus(state, state.hunks[0].id, "accepted");
		expect(isFullyResolved(s1)).toBe(false);
		const s2 = setHunkStatus(s1, state.hunks[1].id, "rejected");
		expect(isFullyResolved(s2)).toBe(true);
	});

	it("resolveAcceptedText keeps original text for rejected hunks and applies adds for accepted ones", () => {
		const before = "a\nb\nc\nd\ne\nf\n";
		const after = "a\nX\nc\nd\nY\nf\n";
		const state = createInlineDiffSession({ path: "x.ts", before, after });
		const accept1 = setHunkStatus(state, state.hunks[0].id, "accepted");
		const reject2 = setHunkStatus(accept1, state.hunks[1].id, "rejected");
		// First hunk (b → X) accepted, second hunk (e → Y) rejected: keep e.
		expect(resolveAcceptedText(reject2)).toBe("a\nX\nc\nd\ne\nf\n");
	});

	it("resolveAcceptedText respects per-hunk user modifications", () => {
		const before = "a\nb\nc\n";
		const after = "a\nX\nc\n";
		const state = createInlineDiffSession({ path: "x.ts", before, after });
		const id = state.hunks[0].id;
		const modified = setHunkStatus(state, id, "modified");
		const final = resolveAcceptedText(modified, { [id]: "MY_TEXT" });
		expect(final).toBe("a\nMY_TEXT\nc\n");
	});

	it("preserves CRLF line endings", () => {
		const before = "a\r\nb\r\nc\r\n";
		const after = "a\r\nX\r\nc\r\n";
		const state = createInlineDiffSession({ path: "x.ts", before, after });
		const final = resolveAcceptedText(setHunkStatus(state, state.hunks[0].id, "accepted"));
		expect(final).toBe("a\r\nX\r\nc\r\n");
	});
});
