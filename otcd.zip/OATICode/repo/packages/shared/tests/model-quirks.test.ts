import { describe, expect, it } from "vitest";
import { buildModelPromptAddendum, detectModelQuirks } from "../src/model-quirks";

describe("detectModelQuirks — pattern matching", () => {
	it("matches Kimi K2 / K2.6 variants", () => {
		const ids = [
			"moonshotai/kimi-k2",
			"moonshotai/kimi-k2-instruct",
			"kimi-k2",
			"Kimi-K2",
			"kimi_k2",
			"moonshotai/kimi-k2-instruct-0925",
		];
		for (const id of ids) {
			expect(detectModelQuirks(id).displayName).toBe("Kimi K2 / K2.6");
		}
	});

	it("matches gpt-oss variants — bare ids AND the HF path the OATI gateway returns", () => {
		// 2026-06-16: includes `openai/gpt-oss-120b` — the exact id vLLM
		// returns from /v1/models on `llm.dev.genie.oati.com/oatigenie/gpt_oss/v1`.
		const ids = ["gpt-oss-120b", "gpt-oss-20b", "gpt-oss", "GPT-OSS-120B", "openai/gpt-oss-120b"];
		for (const id of ids) {
			expect(detectModelQuirks(id).displayName).toBe("gpt-oss");
			expect(detectModelQuirks(id).contextWindow).toBe(131072);
			// OpenAI-trained — wire-format is openai-tools, not inline-xml.
			expect(detectModelQuirks(id).toolCallFormat).toBe("openai-tools");
		}
	});

	it("matches the Qwen3-Coder HF path served by the OATI vllm gateway", () => {
		// 2026-06-16: pin the exact id `vllm.dev.services.oati.com/qwen3_coder/v1`
		// returns from /v1/models so regex regressions surface here.
		expect(detectModelQuirks("Qwen/Qwen3-Coder-30B-A3B-Instruct").displayName).toBe(
			"Qwen 3 Coder",
		);
		expect(detectModelQuirks("Qwen/Qwen3-Coder-30B-A3B-Instruct").tier).toBe("open-weight-large");
	});

	// 2026-06-16: Gemma 4 and Qwen 3 Coder route through vLLM's
	// /v1/completions endpoint (raw text-in / text-out) because the OATI
	// gateway has no tokenizer chat_template AND won't accept one passed
	// via the request body. Every other model row must leave
	// useCompletionsFallback UNSET so its existing /v1/chat/completions
	// codepath (Kimi, Claude, GPT, gpt-oss, Gemma 3) is untouched.
	it("Gemma 4 declares the Gemma-shaped completions fallback", () => {
		const q = detectModelQuirks("google/gemma-4-26B-A4B");
		expect(q.useCompletionsFallback).toBe(true);
		expect(q.promptShape).toBe("gemma");
	});

	it("Qwen 3 Coder declares the ChatML-shaped completions fallback", () => {
		const q = detectModelQuirks("Qwen/Qwen3-Coder-30B-A3B-Instruct");
		expect(q.useCompletionsFallback).toBe(true);
		expect(q.promptShape).toBe("chatml");
	});

	it("models with working chat templates leave useCompletionsFallback UNSET (no interference)", () => {
		// Pinning that Kimi, Claude, GPT, gpt-oss, and Gemma 3 are all NOT
		// affected. A regex regression that accidentally attaches the
		// fallback to one of these rows would silently re-route the
		// wire request to /v1/completions on the wrong gateway.
		const untouched = [
			"moonshotai/kimi-k2",
			"claude-sonnet-4-6",
			"claude-opus-4-7",
			"gpt-4o",
			"openai/gpt-oss-120b",
			"gemma-3",
		];
		for (const id of untouched) {
			expect(detectModelQuirks(id).useCompletionsFallback, `${id}.useCompletionsFallback`).toBeUndefined();
			expect(detectModelQuirks(id).promptShape, `${id}.promptShape`).toBeUndefined();
		}
	});

	// 2026-06-06: Gemma 4 is a separate row from Gemma 2/3 — much better
	// long-context + tool use; first-match-wins ordering must put Gemma 4
	// row BEFORE the generic Gemma 2/3 row, otherwise `gemma-4` would land
	// on the conservative 8K Gemma row.
	it("matches Gemma 4 with 256K context but reading-tier capabilities", () => {
		// 2026-06-16: real-world testing on the OATI vLLM deployment
		// showed Gemma 4 narrates "I'll use the X tool" without emitting
		// tool calls and loops. canPlan/canRerank dropped to false so
		// OATI doesn't route plan/rerank work to it. Still large-tier
		// because it CAN read/explain code well at scale — the tier
		// label is about context capacity, not agentic capability.
		const ids = ["gemma-4", "gemma4", "gemma_4", "Gemma-4", "google/gemma-4-26B-A4B"];
		for (const id of ids) {
			expect(detectModelQuirks(id).displayName).toBe("Gemma 4");
			expect(detectModelQuirks(id).contextWindow).toBe(262144);
			expect(detectModelQuirks(id).canPlan).toBe(false);
			expect(detectModelQuirks(id).canRerank).toBe(false);
			expect(detectModelQuirks(id).tier).toBe("open-weight-large");
			// Loop-bounding caps so failures terminate quickly.
			expect(detectModelQuirks(id).maxTokens).toBe(2048);
			expect(detectModelQuirks(id).maxIterations).toBe(8);
			expect(detectModelQuirks(id).needsTersenessReminder).toBe(true);
		}
	});

	it("matches Gemma 2/3 with the original lightweight quirks", () => {
		for (const id of ["gemma-2", "gemma3", "gemma-3-9b"]) {
			expect(detectModelQuirks(id).displayName).toBe("Gemma");
			expect(detectModelQuirks(id).contextWindow).toBe(8192);
			expect(detectModelQuirks(id).canPlan).toBe(false);
			expect(detectModelQuirks(id).tier).toBe("open-weight-small");
		}
	});

	it("matches Claude variants", () => {
		const ids = [
			"claude-sonnet-4-6",
			"claude-opus-4-7",
			"anthropic/claude-haiku-4-5",
			"claude-3-opus",
		];
		for (const id of ids) {
			expect(detectModelQuirks(id).tier).toBe("frontier");
			expect(detectModelQuirks(id).displayName).toBe("Claude");
		}
	});

	it("flags omitTemperature on Claude Opus 4.7 and 4.8 (deprecated by Anthropic)", () => {
		const opus47 = detectModelQuirks("claude-opus-4-7");
		const opus48 = detectModelQuirks("claude-opus-4-8");
		const opusViaSlug = detectModelQuirks("anthropic/claude-opus-4-7");
		expect(opus47.omitTemperature).toBe(true);
		expect(opus48.omitTemperature).toBe(true);
		expect(opusViaSlug.omitTemperature).toBe(true);
	});

	it("does NOT flag omitTemperature on older / non-Opus Claude variants", () => {
		// Sonnet 4.6 still accepts temperature at the time of writing; same
		// for Haiku 4.5 and the 3.x lineage. Pinning this prevents the new
		// matcher from accidentally over-matching as it evolves.
		expect(detectModelQuirks("claude-sonnet-4-6").omitTemperature).toBeUndefined();
		expect(detectModelQuirks("anthropic/claude-haiku-4-5").omitTemperature).toBeUndefined();
		expect(detectModelQuirks("claude-3-opus").omitTemperature).toBeUndefined();
	});

	it("matches GPT family variants", () => {
		const ids = ["gpt-4o", "gpt-4o-mini", "openai/o3-mini", "openai/o3"];
		for (const id of ids) {
			expect(detectModelQuirks(id).tier).toBe("frontier");
			expect(detectModelQuirks(id).displayName).toBe("GPT");
		}
	});

	it("matches Gemma small open-weight variants (2/3 only — Gemma 4 was promoted)", () => {
		// 2026-06-06: Gemma 4 moved to open-weight-large in its own matcher
		// row; this test now pins ONLY the Gemma 2/3 lineage as small.
		const ids = ["gemma3", "gemma-2", "google/gemma-2-2b"];
		for (const id of ids) {
			expect(detectModelQuirks(id).tier).toBe("open-weight-small");
		}
	});

	it("falls through to unknown defaults for unrecognized model ids", () => {
		const q = detectModelQuirks("totally/made-up-2026");
		expect(q.tier).toBe("unknown");
		expect(q.displayName).toBe("Unknown model");
	});

	it("returns unknown defaults for empty id (no crash)", () => {
		const q = detectModelQuirks("");
		expect(q.tier).toBe("unknown");
	});
});

// Phase 2.1 capability flag invariants — these encode the design rules
// from project_oati_roadmap.md so accidental edits surface as test
// failures instead of silent regressions in production behaviour.
describe("ModelQuirks capability defaults (Phase 2.1)", () => {
	it("frontier models get the full capability set + max concurrency", () => {
		for (const id of ["claude-opus-4-7", "gpt-4o", "google/gemini-2.0-pro"]) {
			const q = detectModelQuirks(id);
			expect(q.canSpawnSubAgents, `${id}.canSpawnSubAgents`).toBe(true);
			expect(q.canPlan, `${id}.canPlan`).toBe(true);
			expect(q.canRerank, `${id}.canRerank`).toBe(true);
			expect(q.parallelConcurrencyCap, `${id}.parallelConcurrencyCap`).toBeGreaterThanOrEqual(5);
		}
	});

	it("open-weight-large models get the full capability set with healthy concurrency", () => {
		// 2026-05-30: per-model concurrency caps now differ — Kimi K2.6 was
		// raised to 12 to reflect its 300-agent swarm design; the others
		// stay at the conservative 3 until their own quirks are validated.
		const expectedCap: Record<string, number> = {
			"moonshotai/kimi-k2": 12,
			"qwen-3-coder": 3,
			"deepseek/deepseek-coder": 3,
			"meta-llama/llama-3.3": 3,
			"mistral-large": 3,
		};
		for (const [id, cap] of Object.entries(expectedCap)) {
			const q = detectModelQuirks(id);
			expect(q.canSpawnSubAgents, `${id}.canSpawnSubAgents`).toBe(true);
			expect(q.canPlan, `${id}.canPlan`).toBe(true);
			expect(q.canRerank, `${id}.canRerank`).toBe(true);
			expect(q.parallelConcurrencyCap, `${id}.parallelConcurrencyCap`).toBe(cap);
		}
	});

	it("small open-weight models are restricted to single-agent only", () => {
		// 2026-06-06: switched to gemma-3 — gemma-4 was promoted to large.
		const q = detectModelQuirks("gemma-3");
		expect(q.canSpawnSubAgents).toBe(false);
		expect(q.canPlan).toBe(false);
		expect(q.canRerank).toBe(false);
		expect(q.parallelConcurrencyCap).toBe(1);
		expect(q.preferredPipeline).toBe("single");
	});

	it("local Ollama models are restricted but can still rerank (cheap one-shot task)", () => {
		const q = detectModelQuirks("ollama/qwen2.5-coder:latest");
		expect(q.canSpawnSubAgents).toBe(false);
		expect(q.canPlan).toBe(false);
		expect(q.canRerank).toBe(true); // simple scoring; most local models handle this
		expect(q.parallelConcurrencyCap).toBe(1);
	});

	it("unknown models default to conservative single-agent path", () => {
		const q = detectModelQuirks("totally/made-up-2026");
		expect(q.canSpawnSubAgents).toBe(false);
		expect(q.canPlan).toBe(false);
		expect(q.canRerank).toBe(true);
		expect(q.parallelConcurrencyCap).toBe(1);
		expect(q.preferredPipeline).toBe("single");
	});

	it("every model row has a defined preferredPipeline (no undefined fall-through)", () => {
		for (const id of [
			"claude-sonnet-4-6",
			"gpt-4o",
			"moonshotai/kimi-k2",
			"gemma-4",
			"ollama/foo:latest",
			"totally/made-up",
		]) {
			const q = detectModelQuirks(id);
			expect(q.preferredPipeline).toMatch(/^(single|plan-execute|fan-out-collect)$/);
		}
	});

	it("parallelConcurrencyCap is always >= 1", () => {
		for (const id of [
			"claude-sonnet-4-6",
			"moonshotai/kimi-k2",
			"gemma-4",
			"ollama/foo:latest",
			"totally/made-up",
		]) {
			const q = detectModelQuirks(id);
			expect(q.parallelConcurrencyCap).toBeGreaterThanOrEqual(1);
		}
	});
});

describe("buildModelPromptAddendum (regression guards)", () => {
	it("returns an empty string for frontier models (no addendum needed)", () => {
		expect(buildModelPromptAddendum("claude-opus-4-7")).toBe("");
		expect(buildModelPromptAddendum("gpt-4o")).toBe("");
	});

	it("returns terseness guidance for models that need it", () => {
		const out = buildModelPromptAddendum("moonshotai/kimi-k2");
		expect(out).toContain("terse");
	});

	it("never contains a negative wire-format example (2026-05-23 post-mortem)", () => {
		// If this fails someone re-introduced the bug that taught Kimi
		// the broken double-escaped JSON shape. See
		// feedback_harness_full_model_power memory for the post-mortem.
		const kimi = buildModelPromptAddendum("moonshotai/kimi-k2");
		const gemma = buildModelPromptAddendum("gemma-4");
		const ollama = buildModelPromptAddendum("ollama/foo:latest");
		for (const out of [kimi, gemma, ollama]) {
			// No negative example in any form.
			expect(out).not.toMatch(/❌/);
			// No "wrong" label adjacent to a JSON-string-of-object
			// — the specific shape we taught the model to reproduce.
			expect(out).not.toMatch(/Wrong.*\\["{]/i);
			// Don't promise the dispatcher will fix the model's mistakes.
			expect(out).not.toMatch(/auto-unwrap/i);
		}
	});
});

describe("requiresTemperature hard constraint", () => {
	it("Kimi K2.6 requires temperature = 1 (thinking variants reject other values)", () => {
		// Live-bug 2026-06-01: Moonshot vLLM / API returned
		// `invalid temperature: only 1 is allowed for this model` for
		// every K2.6 turn until we set requiresTemperature=1 in quirks
		// AND wired the agent loop to override mode.temperature with it.
		const q = detectModelQuirks("moonshotai/kimi-k2.6");
		expect(q.requiresTemperature).toBe(1);
	});

	it("matches all Kimi K2 variants — virtual model ids land on the same row", () => {
		for (const id of [
			"moonshotai/kimi-k2",
			"moonshotai/kimi-k2.6",
			"kimi-k2-thinking",
			"kimi-k2-0905-preview",
		]) {
			expect(detectModelQuirks(id).requiresTemperature).toBe(1);
		}
	});

	it("most models have NO hard temperature constraint", () => {
		// Other models accept a range — mode.temperature should win for them.
		// Pick a few representative cases.
		for (const id of ["claude-sonnet-4-6", "gpt-4o", "qwen-3-coder", "ollama/llama3"]) {
			expect(detectModelQuirks(id).requiresTemperature).toBeUndefined();
		}
	});
});
