import { describe, expect, it } from "vitest";
import {
	type ConversationMessage,
	conversationToUiMessages,
	userMessageIdForIndex,
} from "../src/index";

describe("conversationToUiMessages", () => {
	it("renders an empty history as empty", () => {
		expect(conversationToUiMessages([])).toEqual([]);
	});

	it("converts a user text message", () => {
		const history: ConversationMessage[] = [{ role: "user", parts: [{ kind: "text", text: "hi" }] }];
		const ui = conversationToUiMessages(history);
		expect(ui).toHaveLength(1);
		expect(ui[0]).toMatchObject({ role: "user", text: "hi" });
	});

	it("converts an assistant text message", () => {
		const history: ConversationMessage[] = [
			{ role: "assistant", parts: [{ kind: "text", text: "hello there" }] },
		];
		const ui = conversationToUiMessages(history);
		expect(ui).toHaveLength(1);
		expect(ui[0]).toMatchObject({ role: "assistant", text: "hello there" });
	});

	it("emits a tool card for an assistant tool_call", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [
					{ kind: "text", text: "checking" },
					{ kind: "tool_call", id: "t1", name: "read_file", args: { path: "x.ts" } },
				],
			},
		];
		const ui = conversationToUiMessages(history);
		expect(ui).toHaveLength(2);
		expect(ui[0]).toMatchObject({ role: "assistant", text: "checking" });
		expect(ui[1].role).toBe("tool");
		expect(ui[1].toolCard).toBeDefined();
		expect(ui[1].toolCard?.name).toBe("read_file");
		expect(ui[1].toolCard?.path).toBe("x.ts");
		expect(ui[1].toolCard?.summary).toBe("x.ts");
	});

	it("merges a tool_result into the matching call's card", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "t1", name: "read_file", args: { path: "x.ts" } }],
			},
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "t1", output: "file contents", isError: false }],
			},
		];
		const ui = conversationToUiMessages(history);
		expect(ui).toHaveLength(1);
		const card = ui[0].toolCard;
		expect(card?.name).toBe("read_file");
		expect(card?.result?.isError).toBe(false);
		expect(card?.result?.output).toBe("file contents");
	});

	it("renders an orphan tool_result as its own card", () => {
		const history: ConversationMessage[] = [
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "t1", output: "boom", isError: true }],
			},
		];
		const ui = conversationToUiMessages(history);
		expect(ui).toHaveLength(1);
		expect(ui[0].toolCard?.result?.isError).toBe(true);
		expect(ui[0].text).toContain("✗");
	});

	it("gives user turns a stable id keyed off their history index", () => {
		const history: ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "first" }] },
			{ role: "assistant", parts: [{ kind: "text", text: "ok" }] },
			{ role: "user", parts: [{ kind: "text", text: "second" }] },
		];
		const ui = conversationToUiMessages(history);
		const users = ui.filter((m) => m.role === "user");
		expect(users[0].id).toBe(userMessageIdForIndex(0));
		expect(users[1].id).toBe(userMessageIdForIndex(2));
	});

	it("surfaces user image parts as inline images on the UiMessage", () => {
		const history: ConversationMessage[] = [
			{
				role: "user",
				parts: [
					{ kind: "text", text: "what's this?" },
					{ kind: "image", mimeType: "image/png", dataUrl: "data:image/png;base64,AAAA" },
				],
			},
		];
		const ui = conversationToUiMessages(history);
		expect(ui).toHaveLength(1);
		expect(ui[0].images).toEqual([{ mimeType: "image/png", dataUrl: "data:image/png;base64,AAAA" }]);
	});

	it("truncates very long tool output in the text fallback", () => {
		const huge = "x".repeat(2000);
		const history: ConversationMessage[] = [
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "t1", output: huge, isError: false }],
			},
		];
		const ui = conversationToUiMessages(history);
		expect(ui[0].text.length).toBeLessThan(600);
		expect(ui[0].text).toContain("…");
	});
});
