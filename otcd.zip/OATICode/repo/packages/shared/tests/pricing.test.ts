import { describe, expect, it } from "vitest";
import { estimateCost, findRate, formatUsd } from "../src/pricing";

describe("findRate", () => {
	it("matches a Claude Sonnet 4.6 model id", () => {
		const rate = findRate("claude-sonnet-4-6");
		expect(rate?.displayName).toContain("Sonnet");
	});

	it("matches an OpenRouter-style namespaced id by substring", () => {
		const rate = findRate("anthropic/claude-sonnet-4");
		expect(rate?.displayName).toContain("Sonnet");
	});

	it("is case-insensitive", () => {
		const rate = findRate("CLAUDE-OPUS-4-7");
		expect(rate?.displayName).toContain("Opus");
	});

	it("returns undefined for unknown models", () => {
		expect(findRate("totally-made-up-model-xyz")).toBeUndefined();
	});

	it("matches more specific patterns before generic ones", () => {
		// gpt-4o-mini should match the mini rate, not the generic gpt-4o rate
		const rate = findRate("gpt-4o-mini");
		expect(rate?.inputPerMillion).toBe(0.15);
	});
});

describe("estimateCost", () => {
	it("computes cost correctly for known models", () => {
		const est = estimateCost("claude-sonnet-4-6", 1_000_000, 500_000);
		// 1M input × $3 + 0.5M output × $15
		expect(est?.inputUsd).toBeCloseTo(3, 5);
		expect(est?.outputUsd).toBeCloseTo(7.5, 5);
		expect(est?.totalUsd).toBeCloseTo(10.5, 5);
	});

	it("returns undefined for unknown models", () => {
		expect(estimateCost("unknown-model", 100, 50)).toBeUndefined();
	});

	it("scales linearly with token count", () => {
		const small = estimateCost("claude-haiku-4-5", 1000, 500);
		const big = estimateCost("claude-haiku-4-5", 10000, 5000);
		if (!small || !big) throw new Error("expected estimates");
		expect(big.totalUsd / small.totalUsd).toBeCloseTo(10, 5);
	});
});

describe("formatUsd", () => {
	it("uses 4 decimals below $0.01", () => {
		expect(formatUsd(0.0001)).toBe("$0.0001");
	});

	it("uses 3 decimals between $0.01 and $1", () => {
		expect(formatUsd(0.123)).toBe("$0.123");
	});

	it("uses 2 decimals above $1", () => {
		expect(formatUsd(12.34567)).toBe("$12.35");
	});
});
