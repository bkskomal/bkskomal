import { describe, expect, it } from "vitest";
import { MCP_SERVER_PRESETS, getMcpPreset, materializePreset } from "../src/mcp-presets";

describe("MCP_SERVER_PRESETS", () => {
	it("has unique preset ids", () => {
		const ids = MCP_SERVER_PRESETS.map((p) => p.id);
		expect(new Set(ids).size).toBe(ids.length);
	});

	it("every preset is well-formed for its transport", () => {
		for (const p of MCP_SERVER_PRESETS) {
			if ((p.transport ?? "stdio") === "stdio") {
				expect((p.command ?? "").length).toBeGreaterThan(0);
				expect(Array.isArray(p.args ?? [])).toBe(true);
			} else {
				expect((p.url ?? "").length).toBeGreaterThan(0);
			}
		}
	});

	it("includes the official core presets", () => {
		const ids = MCP_SERVER_PRESETS.map((p) => p.id);
		expect(ids).toContain("filesystem");
		expect(ids).toContain("memory");
		expect(ids).toContain("github");
	});
});

describe("getMcpPreset", () => {
	it("returns the matching preset", () => {
		expect(getMcpPreset("filesystem")?.displayName).toBe("Filesystem");
	});

	it("returns undefined for unknown ids", () => {
		expect(getMcpPreset("not-a-thing")).toBeUndefined();
	});
});

describe("materializePreset", () => {
	it("produces a disabled McpServerConfig with the preset's command/args", () => {
		const fs = MCP_SERVER_PRESETS.find((p) => p.id === "filesystem");
		expect(fs).toBeDefined();
		if (!fs) return;
		const config = materializePreset(fs);
		expect(config.command).toBe("npx");
		expect(config.args).toEqual(fs.args);
		expect(config.enabled).toBe(false);
		expect(config.id).toMatch(/^mcp_filesystem_/);
	});

	it("respects overrides", () => {
		const memory = MCP_SERVER_PRESETS.find((p) => p.id === "memory");
		if (!memory) throw new Error("memory preset missing");
		const config = materializePreset(memory, { id: "fixed", enabled: true });
		expect(config.id).toBe("fixed");
		expect(config.enabled).toBe(true);
	});

	it("carries the preset's approval policy", () => {
		const sst = MCP_SERVER_PRESETS.find((p) => p.id === "sequential-thinking");
		if (!sst) throw new Error("sequential-thinking preset missing");
		expect(materializePreset(sst).approval).toBe("auto");
	});

	it("materializes an HTTP preset with url/headers (no command/args)", () => {
		const httpPreset = {
			id: "remote-mcp",
			displayName: "Remote MCP",
			description: "...",
			transport: "http" as const,
			url: "https://mcp.example.com/sse",
			headers: { Authorization: "Bearer ${ENV_TOKEN}" },
			approval: "prompt" as const,
		};
		const config = materializePreset(httpPreset);
		expect(config.transport).toBe("http");
		expect(config.url).toBe("https://mcp.example.com/sse");
		expect(config.headers).toEqual({ Authorization: "Bearer ${ENV_TOKEN}" });
		expect(config.command).toBeUndefined();
		expect(config.args).toBeUndefined();
	});
});
