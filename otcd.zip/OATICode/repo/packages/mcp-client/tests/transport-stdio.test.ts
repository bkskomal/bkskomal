import { describe, expect, it, vi } from "vitest";
import { StdioTransport } from "../src/transport-stdio";

describe("StdioTransport line framing", () => {
	it("parses one message per newline-delimited chunk", () => {
		const t = new StdioTransport({ command: "irrelevant" });
		const seen: unknown[] = [];
		t.on("message", (msg) => seen.push(msg));
		t.feedRawChunkForTesting(
			'{"jsonrpc":"2.0","id":1,"result":{"ok":true}}\n{"jsonrpc":"2.0","method":"notify"}\n',
		);
		expect(seen).toHaveLength(2);
		expect((seen[0] as { id: number }).id).toBe(1);
		expect((seen[1] as { method: string }).method).toBe("notify");
	});

	it("buffers a partial chunk until the newline arrives", () => {
		const t = new StdioTransport({ command: "irrelevant" });
		const seen: unknown[] = [];
		t.on("message", (msg) => seen.push(msg));
		t.feedRawChunkForTesting('{"jsonrpc":"2.0","id":1,"resul');
		expect(seen).toHaveLength(0);
		t.feedRawChunkForTesting('t":{"ok":true}}\n');
		expect(seen).toHaveLength(1);
	});

	it("emits parse_error for non-JSON lines without crashing", () => {
		const t = new StdioTransport({ command: "irrelevant" });
		const parseErrors: string[] = [];
		const messages: unknown[] = [];
		t.on("parse_error", (line) => parseErrors.push(line));
		t.on("message", (msg) => messages.push(msg));
		t.feedRawChunkForTesting('not json\n{"jsonrpc":"2.0","id":1,"result":1}\n');
		expect(parseErrors).toEqual(["not json"]);
		expect(messages).toHaveLength(1);
	});

	it("ignores non-jsonrpc objects (no jsonrpc field) silently", () => {
		const t = new StdioTransport({ command: "irrelevant" });
		const messages: unknown[] = [];
		t.on("message", (msg) => messages.push(msg));
		t.feedRawChunkForTesting('{"hello":"world"}\n');
		expect(messages).toHaveLength(0);
	});

	it("skips empty lines without errors", () => {
		const t = new StdioTransport({ command: "irrelevant" });
		const parseErrors: string[] = [];
		t.on("parse_error", (line) => parseErrors.push(line));
		t.feedRawChunkForTesting("\n\n\n");
		expect(parseErrors).toEqual([]);
	});

	it("throws if send() is called before start()", () => {
		const t = new StdioTransport({ command: "irrelevant" });
		expect(() => t.send({ jsonrpc: "2.0", id: 1, method: "x" })).toThrow();
	});

	it("close() is idempotent", () => {
		const t = new StdioTransport({ command: "irrelevant" });
		expect(() => {
			t.close();
			t.close();
		}).not.toThrow();
	});

	it("does not call spawn during construction", () => {
		// Sanity: making a transport shouldn't try to spawn anything.
		const spawned = vi.fn();
		// We can't easily intercept spawn without mocking the module,
		// but we can verify the constructor at least returns synchronously.
		const t = new StdioTransport({ command: "irrelevant" });
		expect(t).toBeDefined();
		expect(spawned).not.toHaveBeenCalled();
	});
});
