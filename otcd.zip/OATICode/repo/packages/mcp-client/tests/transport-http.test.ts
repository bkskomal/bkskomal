import { describe, expect, it, vi } from "vitest";
import { HttpTransport } from "../src/transport-http";

/**
 * Build a mock `fetch` that returns the supplied SSE-shaped chunks for
 * the GET (the long-lived stream) and JSON for any POSTs. Returns the
 * mock so tests can assert on call counts + bodies.
 */
function mockFetch(opts: {
	getChunks?: readonly string[];
	/**
	 * When true, the GET stream emits the chunks then stays OPEN. Tests
	 * that exercise send() must use this so the transport doesn't enter
	 * its "SSE stream ended → closed" state mid-test.
	 */
	getStreamStaysOpen?: boolean;
	postResponses?: readonly { status?: number; body?: string; headers?: Record<string, string> }[];
}): ReturnType<typeof vi.fn> {
	let postIdx = 0;
	const mockedFetch = vi.fn(async (_input: unknown, init?: { method?: string }) => {
		const method = init?.method ?? "GET";
		if (method === "GET") {
			const encoder = new TextEncoder();
			const chunks = opts.getChunks ?? [];
			const stream = new ReadableStream<Uint8Array>({
				start(controller) {
					for (const chunk of chunks) controller.enqueue(encoder.encode(chunk));
					// Close only when the test opted in; otherwise stay
					// open so send() doesn't trip the close guard.
					if (!opts.getStreamStaysOpen) controller.close();
				},
			});
			return new Response(stream, {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			});
		}
		// POST
		const next = opts.postResponses?.[postIdx++] ?? { status: 204 };
		return new Response(next.body ?? null, {
			status: next.status ?? 204,
			headers: next.headers ?? {},
		});
	});
	return mockedFetch;
}

describe("HttpTransport", () => {
	it("emits a `message` event for each SSE `data:` block received on the GET stream", async () => {
		const fetchMock = mockFetch({
			getChunks: [
				'data: {"jsonrpc":"2.0","id":1,"result":{"ok":true}}\n\n',
				'data: {"jsonrpc":"2.0","method":"notif","params":{"n":1}}\n\n',
			],
		});
		const t = new HttpTransport({
			url: "http://test/messages",
			fetch: fetchMock as unknown as typeof fetch,
		});
		const messages: unknown[] = [];
		t.on("message", (msg) => messages.push(msg));
		await t.start();
		// Stream is consumed asynchronously after start(); give it a tick.
		await new Promise<void>((resolve) => setTimeout(resolve, 20));
		expect(messages).toHaveLength(2);
		expect((messages[0] as { id: number }).id).toBe(1);
		expect((messages[1] as { method: string }).method).toBe("notif");
		t.close();
	});

	it("emits a `parse_error` for malformed SSE data, NOT a fatal error", async () => {
		const fetchMock = mockFetch({
			getChunks: ["data: {oops not json}\n\n"],
		});
		const t = new HttpTransport({
			url: "http://test/messages",
			fetch: fetchMock as unknown as typeof fetch,
		});
		const errors: unknown[] = [];
		const parseErrors: string[] = [];
		t.on("error", (e) => errors.push(e));
		t.on("parse_error", (p) => parseErrors.push(p));
		await t.start();
		await new Promise<void>((resolve) => setTimeout(resolve, 20));
		expect(parseErrors).toHaveLength(1);
		expect(parseErrors[0]).toContain("oops");
		expect(errors).toHaveLength(0);
		t.close();
	});

	it("send() POSTs the JSON-RPC envelope as the request body", async () => {
		const fetchMock = mockFetch({
			getChunks: [],
			getStreamStaysOpen: true,
			postResponses: [{ status: 204 }],
		});
		const t = new HttpTransport({
			url: "http://test/messages",
			fetch: fetchMock as unknown as typeof fetch,
		});
		await t.start();
		t.send({ jsonrpc: "2.0", id: 1, method: "tools/list", params: {} });
		// send() is fire-and-forget — give it a tick.
		await new Promise<void>((resolve) => setTimeout(resolve, 20));
		const postCall = fetchMock.mock.calls.find(
			(c: unknown[]) => (c[1] as { method?: string }).method === "POST",
		);
		expect(postCall).toBeDefined();
		const body = JSON.parse((postCall?.[1] as { body: string }).body) as { method: string };
		expect(body.method).toBe("tools/list");
		t.close();
	});

	it("forwards inline-JSON POST responses as `message` events (for servers that don't use SSE)", async () => {
		const fetchMock = mockFetch({
			getChunks: [],
			getStreamStaysOpen: true,
			postResponses: [
				{
					status: 200,
					body: '{"jsonrpc":"2.0","id":7,"result":{"echoed":true}}',
					headers: { "content-type": "application/json" },
				},
			],
		});
		const t = new HttpTransport({
			url: "http://test/messages",
			fetch: fetchMock as unknown as typeof fetch,
		});
		const messages: { id?: number }[] = [];
		t.on("message", (msg) => messages.push(msg as { id?: number }));
		await t.start();
		t.send({ jsonrpc: "2.0", id: 7, method: "ping", params: {} });
		await new Promise<void>((resolve) => setTimeout(resolve, 20));
		expect(messages).toHaveLength(1);
		expect(messages[0].id).toBe(7);
		t.close();
	});

	it("throws on start() when the GET returns non-OK", async () => {
		const fetchMock = vi.fn(async () => new Response("nope", { status: 503 }));
		const t = new HttpTransport({
			url: "http://test/messages",
			fetch: fetchMock as unknown as typeof fetch,
		});
		await expect(t.start()).rejects.toThrow(/503/);
	});

	it("close() aborts the SSE stream and emits exit", async () => {
		const fetchMock = mockFetch({
			getChunks: ['data: {"ok":1}\n\n'],
		});
		const t = new HttpTransport({
			url: "http://test/messages",
			fetch: fetchMock as unknown as typeof fetch,
		});
		const exits: unknown[] = [];
		t.on("exit", (info) => exits.push(info));
		await t.start();
		t.close();
		expect(exits).toHaveLength(1);
	});

	it("forwards custom headers on both GET and POST", async () => {
		const fetchMock = mockFetch({
			getChunks: [],
			getStreamStaysOpen: true,
			postResponses: [{ status: 204 }],
		});
		const t = new HttpTransport({
			url: "http://test/messages",
			headers: { Authorization: "Bearer token-xyz" },
			fetch: fetchMock as unknown as typeof fetch,
		});
		await t.start();
		t.send({ jsonrpc: "2.0", id: 1, method: "ping", params: {} });
		await new Promise<void>((resolve) => setTimeout(resolve, 20));
		// GET first.
		const getCall = fetchMock.mock.calls[0];
		const getHeaders = (getCall[1] as { headers: Record<string, string> }).headers;
		expect(getHeaders.Authorization).toBe("Bearer token-xyz");
		// Then POST.
		const postCall = fetchMock.mock.calls.find(
			(c: unknown[]) => (c[1] as { method?: string }).method === "POST",
		);
		const postHeaders = (postCall?.[1] as { headers: Record<string, string> }).headers;
		expect(postHeaders.Authorization).toBe("Bearer token-xyz");
		t.close();
	});
});
