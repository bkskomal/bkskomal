import { describe, expect, it } from "vitest";
import { McpClient } from "../src/client";
import { MCP_PROTOCOL_VERSION } from "../src/protocol";
import { FakeTransport } from "./fake-transport";

describe("McpClient", () => {
	it("completes the initialize handshake and sends notifications/initialized", async () => {
		const transport = new FakeTransport();
		transport.respondTo("initialize", {
			protocolVersion: MCP_PROTOCOL_VERSION,
			capabilities: { tools: {} },
			serverInfo: { name: "test-server", version: "1.0.0" },
		});

		const client = new McpClient(transport);
		const info = await client.start();

		expect(info.serverInfo.name).toBe("test-server");
		expect(transport.sent).toHaveLength(2);
		const initReq = transport.sent[0];
		expect(initReq.method).toBe("initialize");
		expect("id" in initReq).toBe(true);
		const initNotif = transport.sent[1];
		expect(initNotif.method).toBe("notifications/initialized");
		expect("id" in initNotif).toBe(false);
	});

	it("returns tools from tools/list after init", async () => {
		const transport = new FakeTransport();
		transport.respondTo("initialize", {
			protocolVersion: MCP_PROTOCOL_VERSION,
			capabilities: {},
			serverInfo: { name: "s", version: "1" },
		});
		transport.respondTo("tools/list", {
			tools: [
				{
					name: "echo",
					description: "Echo input",
					inputSchema: { type: "object", properties: { msg: { type: "string" } } },
				},
			],
		});

		const client = new McpClient(transport);
		await client.start();
		const tools = await client.listTools();

		expect(tools).toHaveLength(1);
		expect(tools[0].name).toBe("echo");
	});

	it("forwards tools/call results", async () => {
		const transport = new FakeTransport();
		transport.respondTo("initialize", {
			protocolVersion: MCP_PROTOCOL_VERSION,
			capabilities: {},
			serverInfo: { name: "s", version: "1" },
		});
		transport.respondTo("tools/call", {
			content: [{ type: "text", text: "the result" }],
		});

		const client = new McpClient(transport);
		await client.start();
		const result = await client.callTool("echo", { msg: "hi" });

		expect(result.content).toHaveLength(1);
		expect(result.content[0].text).toBe("the result");

		const callReq = transport.sent[2]; // init, notify, tools/call
		expect(callReq.method).toBe("tools/call");
		expect(callReq.params).toEqual({ name: "echo", arguments: { msg: "hi" } });
	});

	it("rejects on JSON-RPC error responses with code and message", async () => {
		const transport = new FakeTransport();
		transport.respondTo("initialize", {
			protocolVersion: MCP_PROTOCOL_VERSION,
			capabilities: {},
			serverInfo: { name: "s", version: "1" },
		});
		transport.failNext("tools/list", -32603, "internal error");

		const client = new McpClient(transport);
		await client.start();

		const err = await client.listTools().catch((e: Error) => e);
		expect(err).toBeInstanceOf(Error);
		expect((err as Error).message).toContain("-32603");
		expect((err as Error).message).toContain("internal error");
	});

	it("rejects pending requests when the server exits", async () => {
		const transport = new FakeTransport();
		transport.respondTo("initialize", {
			protocolVersion: MCP_PROTOCOL_VERSION,
			capabilities: {},
			serverInfo: { name: "s", version: "1" },
		});

		const client = new McpClient(transport);
		await client.start();

		// Don't register a responder for tools/list — instead trip the exit
		const inFlight = client.listTools();
		transport.simulateExit();

		await expect(inFlight).rejects.toThrow(/MCP server exited/);
	});

	it("times out a hanging request", async () => {
		const transport = new FakeTransport();
		transport.respondTo("initialize", {
			protocolVersion: MCP_PROTOCOL_VERSION,
			capabilities: {},
			serverInfo: { name: "s", version: "1" },
		});

		const client = new McpClient(transport, { requestTimeoutMs: 30 });
		await client.start();

		// No responder for tools/list registered → should time out
		await expect(client.listTools()).rejects.toThrow(/timed out/);
	});

	it("rejects calls before start()", async () => {
		const transport = new FakeTransport();
		const client = new McpClient(transport);
		await expect(client.listTools()).rejects.toThrow(/not initialized/);
	});

	it("ignores unmatched responses (mismatched id) without crashing", async () => {
		const transport = new FakeTransport();
		transport.respondTo("initialize", {
			protocolVersion: MCP_PROTOCOL_VERSION,
			capabilities: {},
			serverInfo: { name: "s", version: "1" },
		});

		const client = new McpClient(transport);
		await client.start();

		// Push a response for an id the client never sent
		transport.pushIncoming({
			jsonrpc: "2.0",
			id: 99999,
			result: { ignored: true },
		});

		// Followed by a real call that should still succeed
		transport.respondTo("tools/list", { tools: [] });
		const tools = await client.listTools();
		expect(tools).toEqual([]);
	});
});
