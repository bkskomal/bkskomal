import { EventEmitter } from "node:events";
import type { JsonRpcNotification, JsonRpcRequest, JsonRpcResponse } from "../src/protocol";
import type { IncomingMessage, McpTransport } from "../src/transport";

/**
 * In-memory transport for unit tests. Tests push canned responses with
 * `respondTo` (matched against the request method) and inspect outgoing
 * messages via `sent`.
 */
export class FakeTransport extends EventEmitter implements McpTransport {
	readonly sent: Array<JsonRpcRequest | JsonRpcNotification> = [];
	private responders: Array<(req: JsonRpcRequest) => JsonRpcResponse | undefined> = [];
	private started = false;
	private closed = false;

	async start(): Promise<void> {
		this.started = true;
	}

	send(msg: JsonRpcRequest | JsonRpcNotification): void {
		if (!this.started) throw new Error("transport not started");
		if (this.closed) throw new Error("transport closed");
		this.sent.push(msg);
		if ("id" in msg) {
			// It's a request — search responders for a match
			for (let i = 0; i < this.responders.length; i++) {
				const fn = this.responders[i];
				const response = fn(msg);
				if (response) {
					this.responders.splice(i, 1);
					// Deliver asynchronously, like a real transport
					queueMicrotask(() => this.emit("message", response));
					return;
				}
			}
		}
	}

	close(): void {
		this.closed = true;
	}

	/** Register a one-shot canned response for a given method. */
	respondTo(method: string, result: unknown): void {
		this.responders.push((req) => {
			if (req.method !== method) return undefined;
			return { jsonrpc: "2.0", id: req.id, result };
		});
	}

	/** Register a one-shot error response. */
	failNext(method: string, code: number, message: string): void {
		this.responders.push((req) => {
			if (req.method !== method) return undefined;
			return {
				jsonrpc: "2.0",
				id: req.id,
				error: { code, message },
			};
		});
	}

	/** Simulate server-initiated notification or unsolicited message. */
	pushIncoming(msg: IncomingMessage): void {
		queueMicrotask(() => this.emit("message", msg));
	}

	/** Simulate server crash. */
	simulateExit(): void {
		this.closed = true;
		this.emit("exit", { code: null, signal: null });
	}
}
