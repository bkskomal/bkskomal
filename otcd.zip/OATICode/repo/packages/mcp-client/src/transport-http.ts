// Phase 4 polish (2026-05-25): HTTP / SSE transport for MCP.
//
// The stdio transport handles MCP servers we spawn as local child
// processes. Many production-grade MCP servers (especially cloud-hosted
// ones, or shared team servers) only expose an HTTP endpoint instead.
// This transport speaks the same JSON-RPC over a POST endpoint that
// returns a long-lived SSE response stream — the standard HTTP MCP
// shape per the spec.
//
// Wire model:
//   - Each `send()` POSTs the JSON-RPC envelope to `${url}/messages`
//     (or just `url` when that already points at the messages endpoint).
//   - The server replies with `text/event-stream`. Each `data: ...`
//     line is one JSON-RPC response or notification. We parse and emit
//     `"message"` for each.
//   - One open SSE connection per transport instance. Server can push
//     notifications at any time; client `send()`s are independent POSTs.
//
// Failures (network down, 4xx/5xx, malformed SSE) all surface as
// `"error"` events so the manager's reconnect / disable policy can
// react. We never throw past `start()` once the initial connection
// is up.

import { EventEmitter } from "node:events";
import type { JsonRpcNotification, JsonRpcRequest } from "./protocol";
import type { IncomingMessage, McpTransport } from "./transport";

export interface HttpTransportOptions {
	/** Full URL to the MCP server's messages endpoint. */
	readonly url: string;
	/** Extra headers sent on every request (auth tokens, routing). */
	readonly headers?: Readonly<Record<string, string>>;
	/**
	 * Custom fetch implementation, primarily for tests. Defaults to the
	 * runtime's global `fetch`. Must support streaming response bodies
	 * (ReadableStream) for the SSE path to work.
	 */
	readonly fetch?: typeof fetch;
	/**
	 * Abort signal external callers can use to tear down the long-lived
	 * SSE connection. The transport's own `close()` also aborts.
	 */
	readonly signal?: AbortSignal;
}

export class HttpTransport extends EventEmitter implements McpTransport {
	private readonly fetchImpl: typeof fetch;
	private readonly internalAbort = new AbortController();
	private sseReader: ReadableStreamDefaultReader<Uint8Array> | undefined;
	private decoder = new TextDecoder();
	private buf = "";
	private closed = false;
	private started = false;

	constructor(private readonly opts: HttpTransportOptions) {
		super();
		this.fetchImpl = opts.fetch ?? fetch;
		if (opts.signal) {
			opts.signal.addEventListener("abort", () => this.internalAbort.abort(), {
				once: true,
			});
		}
	}

	async start(): Promise<void> {
		if (this.started) return;
		this.started = true;
		// Open the long-lived SSE GET. Some servers also accept the
		// MCP messages endpoint on POST-only and stream the response;
		// we try GET first (the more common MCP-spec path).
		let response: Response;
		try {
			response = await this.fetchImpl(this.opts.url, {
				method: "GET",
				headers: {
					Accept: "text/event-stream",
					...(this.opts.headers ?? {}),
				},
				signal: this.internalAbort.signal,
			});
		} catch (err) {
			this.closed = true;
			throw new Error(
				`HTTP MCP transport failed to connect to ${this.opts.url}: ${
					err instanceof Error ? err.message : String(err)
				}`,
			);
		}
		if (!response.ok || !response.body) {
			this.closed = true;
			throw new Error(
				`HTTP MCP transport got ${response.status} ${response.statusText} from ${this.opts.url}`,
			);
		}
		this.sseReader = response.body.getReader();
		// Read in the background — we don't await this. SSE is meant to
		// live for the duration of the session.
		void this.consumeSse();
	}

	send(msg: JsonRpcRequest | JsonRpcNotification): void {
		if (this.closed) {
			this.emit("error", new Error("HTTP MCP transport: send() after close"));
			return;
		}
		// Fire-and-forget POST. The response (if any) arrives via the
		// SSE stream we opened in start(); we don't await it here.
		void this.postOne(msg);
	}

	close(): void {
		if (this.closed) return;
		this.closed = true;
		this.internalAbort.abort();
		try {
			this.sseReader?.cancel().catch(() => undefined);
		} catch {
			/* best-effort */
		}
		this.emit("exit", { code: 0, signal: null });
	}

	private async postOne(msg: JsonRpcRequest | JsonRpcNotification): Promise<void> {
		try {
			const response = await this.fetchImpl(this.opts.url, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Accept: "application/json, text/event-stream",
					...(this.opts.headers ?? {}),
				},
				body: JSON.stringify(msg),
				signal: this.internalAbort.signal,
			});
			if (!response.ok) {
				this.emit(
					"error",
					new Error(
						`HTTP MCP POST returned ${response.status} ${response.statusText} for ${msg.method}`,
					),
				);
				return;
			}
			// Some HTTP MCP servers reply with the JSON-RPC response
			// inline on the POST instead of via the SSE channel. Accept
			// both shapes: if the response has a JSON body, parse it
			// and emit as a message.
			const contentType = response.headers.get("content-type") ?? "";
			if (contentType.includes("application/json") && response.body) {
				const text = await response.text();
				if (text.trim().length > 0) {
					this.parseAndEmit(text);
				}
			}
		} catch (err) {
			if (this.closed) return; // expected during shutdown
			this.emit(
				"error",
				new Error(
					`HTTP MCP POST failed for ${msg.method}: ${err instanceof Error ? err.message : String(err)}`,
				),
			);
		}
	}

	private async consumeSse(): Promise<void> {
		const reader = this.sseReader;
		if (!reader) return;
		try {
			while (!this.closed) {
				const { value, done } = await reader.read();
				if (done) break;
				if (!value) continue;
				this.buf += this.decoder.decode(value, { stream: true });
				// SSE messages are separated by blank lines. Each message
				// is one or more lines like `data: <json>` or `event: foo`.
				while (true) {
					const sep = this.buf.indexOf("\n\n");
					if (sep < 0) break;
					const block = this.buf.slice(0, sep);
					this.buf = this.buf.slice(sep + 2);
					this.processSseBlock(block);
				}
			}
			// Stream ended naturally — surface as exit so the manager
			// can decide whether to reconnect or drop the server.
			if (!this.closed) {
				this.closed = true;
				this.emit("exit", { code: 0, signal: null });
			}
		} catch (err) {
			if (this.closed) return;
			this.emit(
				"error",
				new Error(`HTTP MCP SSE stream error: ${err instanceof Error ? err.message : String(err)}`),
			);
		}
	}

	private processSseBlock(block: string): void {
		// Collect `data:` lines (multi-line data is concatenated per the
		// SSE spec). Other directives (event:, id:, retry:) are ignored
		// for now — JSON-RPC over SSE doesn't use them.
		const dataLines: string[] = [];
		for (const line of block.split("\n")) {
			if (line.startsWith("data:")) {
				dataLines.push(line.slice(5).replace(/^\s/, ""));
			}
		}
		if (dataLines.length === 0) return;
		const payload = dataLines.join("\n");
		if (payload.length === 0) return;
		this.parseAndEmit(payload);
	}

	private parseAndEmit(payload: string): void {
		try {
			const parsed = JSON.parse(payload) as IncomingMessage;
			this.emit("message", parsed);
		} catch {
			this.emit("parse_error", payload);
		}
	}
}
