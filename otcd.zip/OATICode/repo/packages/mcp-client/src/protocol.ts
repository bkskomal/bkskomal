export interface JsonRpcRequest {
	readonly jsonrpc: "2.0";
	readonly id: number | string;
	readonly method: string;
	readonly params?: unknown;
}

export interface JsonRpcNotification {
	readonly jsonrpc: "2.0";
	readonly method: string;
	readonly params?: unknown;
}

export interface JsonRpcResponse {
	readonly jsonrpc: "2.0";
	readonly id: number | string;
	readonly result?: unknown;
	readonly error?: JsonRpcError;
}

export interface JsonRpcError {
	readonly code: number;
	readonly message: string;
	readonly data?: unknown;
}

export interface McpServerInfo {
	readonly name: string;
	readonly version: string;
}

export interface McpClientInfo {
	readonly name: string;
	readonly version: string;
}

export interface McpInitializeResult {
	readonly protocolVersion: string;
	readonly capabilities: Record<string, unknown>;
	readonly serverInfo: McpServerInfo;
}

export interface McpTool {
	readonly name: string;
	readonly description?: string;
	readonly inputSchema: {
		readonly type: "object";
		readonly properties?: Record<string, unknown>;
		readonly required?: readonly string[];
	};
}

export interface McpListToolsResult {
	readonly tools: readonly McpTool[];
}

export interface McpContentBlock {
	readonly type: "text" | "image" | "resource";
	readonly text?: string;
	readonly data?: string;
	readonly mimeType?: string;
}

export interface McpCallToolResult {
	readonly content: readonly McpContentBlock[];
	readonly isError?: boolean;
}

export const MCP_PROTOCOL_VERSION = "2024-11-05";
