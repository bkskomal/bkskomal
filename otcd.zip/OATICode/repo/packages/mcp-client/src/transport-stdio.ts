import { type ChildProcess, spawn } from "node:child_process";
import { EventEmitter } from "node:events";
import type { JsonRpcNotification, JsonRpcRequest, JsonRpcResponse } from "./protocol";
import type { IncomingMessage, McpTransport } from "./transport";

export interface StdioTransportOptions {
	readonly command: string;
	readonly args?: readonly string[];
	readonly env?: Readonly<Record<string, string>>;
	readonly cwd?: string;
}

export class StdioTransport extends EventEmitter implements McpTransport {
	private proc: ChildProcess | undefined;
	private buf = "";
	private closed = false;

	constructor(private readonly opts: StdioTransportOptions) {
		super();
	}

	async start(): Promise<void> {
		this.proc = spawn(this.opts.command, [...(this.opts.args ?? [])], {
			env: { ...process.env, ...(this.opts.env ?? {}) },
			cwd: this.opts.cwd,
			stdio: ["pipe", "pipe", "pipe"],
		});

		this.proc.stdout?.setEncoding("utf8");
		this.proc.stdout?.on("data", (chunk: string) => this.onData(chunk));
		this.proc.stderr?.setEncoding("utf8");
		this.proc.stderr?.on("data", (chunk: string) => this.emit("stderr", chunk));
		this.proc.on("exit", (code, signal) => {
			this.closed = true;
			this.emit("exit", { code, signal });
		});
		this.proc.on("error", (err) => this.emit("error", err));

		// Wait one tick to surface immediate spawn failures
		await new Promise<void>((resolve) => setImmediate(resolve));
		if (this.closed) throw new Error(`MCP server '${this.opts.command}' exited immediately`);
	}

	send(msg: JsonRpcRequest | JsonRpcNotification): void {
		if (!this.proc || !this.proc.stdin) throw new Error("MCP transport not started");
		const line = `${JSON.stringify(msg)}\n`;
		this.proc.stdin.write(line);
	}

	close(): void {
		if (this.closed) return;
		this.closed = true;
		try {
			this.proc?.stdin?.end();
			this.proc?.kill();
		} catch {
			// ignore
		}
	}

	/** Exposed for unit tests of the line-framing logic. */
	feedRawChunkForTesting(chunk: string): void {
		this.onData(chunk);
	}

	private onData(chunk: string): void {
		this.buf += chunk;
		while (true) {
			const nl = this.buf.indexOf("\n");
			if (nl < 0) break;
			const line = this.buf.slice(0, nl).trim();
			this.buf = this.buf.slice(nl + 1);
			if (!line) continue;
			let parsed: unknown;
			try {
				parsed = JSON.parse(line);
			} catch {
				this.emit("parse_error", line);
				continue;
			}
			if (isJsonRpcMessage(parsed)) this.emit("message", parsed);
		}
	}
}

function isJsonRpcMessage(v: unknown): v is IncomingMessage {
	return typeof v === "object" && v !== null && (v as JsonRpcResponse).jsonrpc === "2.0";
}
