import type { JsonRpcNotification, JsonRpcRequest, JsonRpcResponse } from "./protocol";

export type IncomingMessage = JsonRpcResponse | JsonRpcNotification;

export type TransportEvent = "message" | "error" | "exit" | "stderr" | "parse_error";

export interface McpTransport {
	start(): Promise<void>;
	send(msg: JsonRpcRequest | JsonRpcNotification): void;
	close(): void;
	on(event: "message", listener: (msg: IncomingMessage) => void): this;
	on(event: "error", listener: (err: Error) => void): this;
	on(
		event: "exit",
		listener: (info: { code: number | null; signal: NodeJS.Signals | null }) => void,
	): this;
	on(event: "stderr", listener: (chunk: string) => void): this;
	on(event: "parse_error", listener: (line: string) => void): this;
}
