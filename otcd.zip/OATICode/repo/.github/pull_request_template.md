<!--
Thanks for the PR! A few things to check before requesting review:

1. Does CI pass locally? (`npm run typecheck && npm run build && npm test && npx biome check .`)
2. Is the diff focused on one concept? Multi-concept PRs get split before merge.
3. If you're touching public types in `shared/`, have you updated dependent packages?
4. Have you added or updated tests for new logic?
-->

## Summary

<!-- 1-3 bullets describing what this PR does. Focus on the WHY, not the WHAT
(the diff already shows what). -->

-
-

## Changes

<!-- Per-package or per-area bullets if the PR touches multiple things. -->

## Test plan

<!-- Checklist of how the reviewer (or you) verified this works. -->

- [ ] `npm run typecheck` clean
- [ ] `npm run build` clean
- [ ] `npm test` — N new tests added / existing pass
- [ ] `npx biome check .` clean
- [ ]

## Screenshots / output

<!-- For UI changes: a screenshot or screencap.
For agent-behavior changes: paste a representative transcript. -->

## Backwards compatibility

<!-- Any breaking changes? If yes, what migration path do users have? -->
