---
name: Bug report
about: Something doesn't work the way the docs say it should
title: "bug: "
labels: bug
---

## What happened

<!-- One or two sentences describing the actual behavior. -->

## What you expected

<!-- One or two sentences describing the expected behavior. -->

## Repro

<!-- The smallest sequence of steps that produces the bug. -->

1.
2.
3.

## Environment

- **OATICodingAssistant version:** <!-- e.g. 0.1.0 -->
- **IDE shell:** <!-- VS Code 1.95 / Antigravity 1.0 / Visual Studio 2022 17.8 / standalone agent-service -->
- **OS:** <!-- Windows 11 / macOS 14 / Ubuntu 24.04 -->
- **Provider preset:** <!-- OpenAI Compatible / Anthropic / OpenRouter / Ollama / unillm / LiteLLM / Custom -->
- **Model id:** <!-- e.g. claude-sonnet-4-6 -->

> **Why we ask about the model:** A lot of "agent did the wrong thing" bugs are actually model-quality issues that disappear when you switch to a stronger model. Mentioning the model lets us tell those apart from real bugs.

## Logs / output

<details><summary>Relevant excerpt from the OATICodingAssistant output channel</summary>

```
paste here — please redact API keys
```

</details>

## Additional context

<!-- Screenshots, the failing prompt, the file you asked it to modify, etc. -->
