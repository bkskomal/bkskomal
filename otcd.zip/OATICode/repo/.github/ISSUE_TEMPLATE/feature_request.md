---
name: Feature request
about: Propose a new capability or an improvement
title: "feat: "
labels: enhancement
---

## What you're trying to do

<!-- Describe the workflow this feature enables, not just the feature itself.
"I want to ask the agent to ... and have it ..." beats "add an X button". -->

## Current workaround (if any)

<!-- How are you getting by today? This tells us how urgent it is. -->

## Proposed change

<!-- A sketch of how this could work. Concrete UI mockups or API shapes are great
but optional. Pseudocode is fine. -->

## Out of scope / explicit non-goals

<!-- Anything related that you're explicitly NOT asking for, to scope the feature. -->

## Architectural notes

<!-- Optional. If you've read CLAUDE.md and have thoughts on which package this
should live in or which constraint it might brush against, share them here. -->
