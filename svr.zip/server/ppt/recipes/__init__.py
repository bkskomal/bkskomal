"""
Premium slide recipes — deterministic, hand-written python-pptx generators that
emit NATIVE PowerPoint objects (real charts, diagrams) for the highest fidelity.

The web editor renders an equivalent from primitives (so it stays editable); on
HD export these recipes take over for the data-viz region. The AI never writes
this code — it only selects a recipe (block layout) and fills its parameters.
"""
