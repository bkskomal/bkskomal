"""
PPTMaker export microservice (FastAPI).

POST /export  { "deck": <Deck JSON> }  ->  application/vnd.openxmlformats .pptx
GET  /health

Run:
    pip install -r requirements.txt
    uvicorn app:app --port 8910
"""
from __future__ import annotations

import re
from typing import Union

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel

from .renderer import render_deck
from .importer import parse_pptx
from .extract_template import extract_template
from .docx_import import extract_docx
from .codegen import generate_code
from .xlsx_compare import build_highlighted
from .diff_report import build_report
from .doc_compare import blocks_for, build_redline

app = FastAPI(title="OATIGenie Services (export + embeddings)")

# --- BGE embeddings (fastembed / ONNX, no torch) — lazy-loaded on first use ---
_embedder = None


def _get_embedder():
    global _embedder
    if _embedder is None:
        from fastembed import TextEmbedding

        _embedder = TextEmbedding(model_name="BAAI/bge-base-en-v1.5")  # 768-d
    return _embedder

# The Next.js dev app calls this from the server side; CORS open for convenience.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ExportRequest(BaseModel):
    deck: dict


def _safe_name(title: str) -> str:
    name = re.sub(r"[^\w\d-]+", "_", title or "")[:60]
    return name or "presentation"


class EmbedRequest(BaseModel):
    input: Union[str, list[str]]
    model: str | None = None


@app.post("/v1/embeddings")
def embeddings(req: EmbedRequest) -> dict:
    """OpenAI-compatible embeddings using BAAI/bge-base-en-v1.5 (768-d)."""
    texts = [req.input] if isinstance(req.input, str) else req.input
    vecs = list(_get_embedder().embed(texts))
    data = [{"object": "embedding", "index": i, "embedding": v.tolist()} for i, v in enumerate(vecs)]
    return {"object": "list", "data": data, "model": req.model or "BAAI/bge-base-en-v1.5"}


@app.post("/compare-xlsx")
async def compare_xlsx(original: UploadFile = File(...), updated: UploadFile = File(...)) -> Response:
    """Return a 3rd .xlsx = the updated file with added/removed/modified cells highlighted."""
    try:
        data = build_highlighted(await original.read(), await updated.read())
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Compare failed: {exc}") from exc
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="comparison-highlighted.xlsx"'},
    )


class DiffReportRequest(BaseModel):
    result: dict
    aiSummary: str | None = None


@app.post("/build-diff-xlsx")
def build_diff_xlsx(req: DiffReportRequest) -> Response:
    """Build a merged 'changes report' .xlsx from a context-aware diff (Excel or CSV)."""
    try:
        data = build_report({"result": req.result, "aiSummary": req.aiSummary})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Report failed: {exc}") from exc
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="comparison-report.xlsx"'},
    )


@app.post("/compare-doc")
async def compare_doc(kind: str, original: UploadFile = File(...), updated: UploadFile = File(...)) -> dict:
    """Diff two Word/PDF documents -> structured blocks (for the UI)."""
    try:
        blocks, added, removed = blocks_for(kind, await original.read(), await updated.read())
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Doc compare failed: {exc}") from exc
    return {"blocks": blocks, "added": added, "removed": removed}


@app.post("/compare-doc-docx")
async def compare_doc_docx(kind: str, original: UploadFile = File(...), updated: UploadFile = File(...)) -> Response:
    """Diff two Word/PDF documents -> a redlined .docx (insertions green, deletions struck red)."""
    try:
        blocks, added, removed = blocks_for(kind, await original.read(), await updated.read())
        data = build_redline(blocks, added, removed)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Doc compare failed: {exc}") from exc
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": 'attachment; filename="comparison-redline.docx"'},
    )


@app.post("/extract-text")
async def extract_text(file: UploadFile = File(...)) -> dict:
    """Extract plain text from an uploaded .pdf/.docx/.txt/.md for deck generation."""
    name = file.filename or "document"
    lower = name.lower()
    data = await file.read()
    try:
        if lower.endswith(".pdf"):
            import fitz  # PyMuPDF

            with fitz.open(stream=data, filetype="pdf") as pdf:
                text = "\n".join(page.get_text() for page in pdf)
        elif lower.endswith(".docx"):
            import io

            from docx import Document

            doc = Document(io.BytesIO(data))
            parts = [p.text for p in doc.paragraphs if p.text and p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    cells = [c.text.strip() for c in row.cells if c.text and c.text.strip()]
                    if cells:
                        parts.append(" | ".join(cells))
            text = "\n".join(parts)
        elif lower.endswith(".txt") or lower.endswith(".md"):
            text = data.decode("utf-8", errors="replace")
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported file type: {name}")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Extraction failed: {exc}") from exc

    text = (text or "").strip()[:24000]
    return {"text": text, "name": name, "chars": len(text)}


@app.post("/import-pptx")
async def import_pptx(file: UploadFile = File(...)) -> dict:
    """Parse an uploaded .pptx into an editable Deck (title + size + slides[])."""
    try:
        return parse_pptx(await file.read())
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Import failed: {exc}") from exc


@app.post("/extract-template")
async def extract_template_endpoint(file: UploadFile = File(...)) -> dict:
    """TEMPLATE-FROM-ANY-PPTX: derive a reusable theme + template descriptor from
    an uploaded .pptx (deterministic, no model). Returns
    { theme, descriptor, previewPalette, contrast, brand }, where `brand` carries
    the deck's lifted chrome ({ logo?, logoPlacement?, logoRelWidth?, headerText?,
    footerText?, showPageNumbers })."""
    try:
        return extract_template(await file.read(), file.filename or "presentation.pptx")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Template extraction failed: {exc}") from exc


@app.post("/import-docx")
async def import_docx(file: UploadFile = File(...)) -> dict:
    """Extract a Word .docx into slide-ready content + images (headings -> slides)."""
    try:
        return extract_docx(await file.read())
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Word import failed: {exc}") from exc


@app.post("/export-code")
def export_code(req: ExportRequest) -> Response:
    """Generate a standalone python-pptx script that rebuilds the deck."""
    if not req.deck or "slides" not in req.deck:
        raise HTTPException(status_code=400, detail="Body must be { deck: <Deck JSON> }")
    try:
        code = generate_code(req.deck)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Code gen failed: {exc}") from exc
    return Response(content=code, media_type="text/x-python",
                    headers={"Content-Disposition": f'attachment; filename="{_safe_name(req.deck.get("title", "deck"))}.py"'})


@app.get("/health")
def health() -> dict:
    return {"ok": True, "service": "oatigenie-services"}


@app.post("/export")
def export(req: ExportRequest) -> Response:
    deck = req.deck
    if not deck or "slides" not in deck:
        raise HTTPException(status_code=400, detail="Body must be { deck: <Deck JSON> }")
    try:
        data = render_deck(deck)
    except Exception as exc:  # surface a useful message to the caller
        raise HTTPException(status_code=500, detail=f"Render failed: {exc}") from exc

    filename = f"{_safe_name(deck.get('title', 'presentation'))}.pptx"
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
