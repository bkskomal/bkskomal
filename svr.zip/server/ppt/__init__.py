"""ppt tool package (mounted under /ppt)."""
