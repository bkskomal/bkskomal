"""
TEMPLATE-FROM-ANY-PPTX — deterministic visual-identity extraction (no model).

A user uploads ANY .pptx; we derive a reusable OATIGenie template + theme by
reading the file's own XML:

  * the theme color scheme (``ppt/theme/theme*.xml`` — dk1/lt1/accent1..6) and
    font scheme (major/minor latin typefaces);
  * the most-used explicit ``srgbClr`` values across the SLIDES (custom brand
    palettes almost always live on the slides / masters, not the base theme);
  * the deck background (``<p:bg>`` on masters → layouts → slides).

From those signals we infer a dark/light mode and a full
background/surface/primary/secondary/accent/text/textMuted/onPrimary mapping
(ranked by frequency x saturation, then WCAG-AA enforced between text and
background), pick the closest cover architecture from OATIGenie's vocabulary,
and return ``{ theme, descriptor, previewPalette, contrast, brand }``.

We ALSO lift the deck's visual chrome — its LOGO (the image that recurs across
the master / most slides, decoded to a base64 data URI with a derived corner
placement), and any HEADER / FOOTER / slide-number placeholders from the master
and layouts — into a ``brand`` object so a reusable template carries the source's
branding, not just its colors.

Fully deterministic: the same .pptx always yields the same template, and no LLM
is required. When a signal is missing we fall back to sensible defaults and say
so honestly in ``descriptor.notes``.
"""
from __future__ import annotations

import base64
import io
import posixpath
import re
import zipfile
from collections import Counter

# ----------------------------------------------------------------- regex probes
# Namespaces are noisy in raw OOXML, so we probe with tolerant regexes rather
# than a full DOM walk. These match the color/font/size primitives wherever they
# appear (theme, master, layout, slide).
_SRGB_RE = re.compile(r'srgbClr\s+val="([0-9A-Fa-f]{6})"')
_SYS_RE = re.compile(r'sysClr\s+val="\w+"\s+lastClr="([0-9A-Fa-f]{6})"')
_LATIN_RE = re.compile(r'<a:latin\s+typeface="([^"]+)"')
_SZ_RE = re.compile(r'\bsz="(\d{3,5})"')
_BG_BLOCK_RE = re.compile(r"<p:bg>(.*?)</p:bg>", re.DOTALL)
_ANYCLR_RE = re.compile(
    r'srgbClr\s+val="([0-9A-Fa-f]{6})"|sysClr\s+val="\w+"\s+lastClr="([0-9A-Fa-f]{6})"'
)

# theme-scheme sub-slots, in order
_SCHEME_SLOTS = ["dk1", "lt1", "dk2", "lt2", "accent1", "accent2", "accent3",
                 "accent4", "accent5", "accent6", "hlink", "folHlink"]


# ----------------------------------------------------------------- color helpers
def _rgb(hex6: str) -> tuple[int, int, int]:
    h = hex6.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _hex(r: float, g: float, b: float) -> str:
    def c(v: float) -> str:
        return f"{max(0, min(255, round(v))):02X}"
    return f"#{c(r)}{c(g)}{c(b)}"


def _lin(v: float) -> float:
    v /= 255.0
    return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4


def _lum(hex6: str) -> float:
    r, g, b = _rgb(hex6)
    return 0.2126 * _lin(r) + 0.7152 * _lin(g) + 0.0722 * _lin(b)


def _contrast(a: str, b: str) -> float:
    la, lb = _lum(a), _lum(b)
    hi, lo = (la, lb) if la >= lb else (lb, la)
    return (hi + 0.05) / (lo + 0.05)


def _sat(hex6: str) -> float:
    r, g, b = _rgb(hex6)
    mx, mn = max(r, g, b), min(r, g, b)
    return 0.0 if mx == 0 else (mx - mn) / mx


def _hue(hex6: str) -> float:
    r, g, b = (v / 255.0 for v in _rgb(hex6))
    mx, mn = max(r, g, b), min(r, g, b)
    d = mx - mn
    if d == 0:
        return 0.0
    if mx == r:
        h = ((g - b) / d) % 6
    elif mx == g:
        h = (b - r) / d + 2
    else:
        h = (r - g) / d + 4
    h *= 60
    return h + 360 if h < 0 else h


def _hue_dist(a: str, b: str) -> float:
    d = abs(_hue(a) - _hue(b))
    return min(d, 360 - d)


def _rgb_dist(a: str, b: str) -> float:
    ar, ag, ab = _rgb(a)
    br, bg, bb = _rgb(b)
    return ((ar - br) ** 2 + (ag - bg) ** 2 + (ab - bb) ** 2) ** 0.5


def _mix(a: str, b: str, t: float) -> str:
    ar, ag, ab = _rgb(a)
    br, bg, bb = _rgb(b)
    return _hex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t)


def _norm(hex6: str | None) -> str | None:
    if not hex6:
        return None
    return "#" + hex6.lstrip("#").upper()


# ----------------------------------------------------------------- zip reading
def _members(zf: zipfile.ZipFile, prefix: str) -> list[str]:
    return sorted(n for n in zf.namelist()
                  if n.startswith(prefix) and n.lower().endswith(".xml"))


def _read(zf: zipfile.ZipFile, name: str) -> str:
    try:
        return zf.read(name).decode("utf-8", errors="replace")
    except Exception:
        return ""


def _first_color(xml: str) -> str | None:
    m = _ANYCLR_RE.search(xml)
    if not m:
        return None
    return _norm(m.group(1) or m.group(2))


# ----------------------------------------------------------------- scheme parse
def _parse_scheme(theme_xml: str) -> dict[str, str]:
    """Map dk1/lt1/accent1..6 -> hex from a theme's <a:clrScheme>."""
    out: dict[str, str] = {}
    for slot in _SCHEME_SLOTS:
        m = re.search(rf"<a:{slot}>(.*?)</a:{slot}>", theme_xml, re.DOTALL)
        if not m:
            continue
        c = _first_color(m.group(1))
        if c:
            out[slot] = c
    return out


def _parse_fonts(theme_xml: str) -> tuple[str | None, str | None]:
    """(headingFont, bodyFont) from a theme's major/minor <a:latin>."""
    def face(tag: str) -> str | None:
        m = re.search(rf"<a:{tag}>(.*?)</a:{tag}>", theme_xml, re.DOTALL)
        if not m:
            return None
        f = _LATIN_RE.search(m.group(1))
        val = f.group(1).strip() if f else ""
        return val or None
    return face("majorFont"), face("minorFont")


# ----------------------------------------------------------------- font cleanup
def _clean_font(name: str | None, fallback: str) -> str:
    if not name:
        return fallback
    n = name.strip()
    # theme placeholder tokens like "+mn-lt" carry no real family
    if n.startswith("+") or not n:
        return fallback
    return n


# ----------------------------------------------------------------- brand chrome
# The logo + header/footer live in the deck's parts (master / layouts / slides)
# and their relationship files, not in the theme. We read them straight from the
# OOXML with the same tolerant-regex approach used for colors/fonts.

_PIC_RE = re.compile(r"<p:pic>(.*?)</p:pic>", re.DOTALL)
_EMBED_RE = re.compile(r'r:embed="([^"]+)"')
_OFF_RE = re.compile(r'<a:off\s+x="(-?\d+)"\s+y="(-?\d+)"')
_EXT_RE = re.compile(r'<a:ext\s+cx="(\d+)"\s+cy="(\d+)"')
_REL_RE = re.compile(r"<Relationship\b[^>]*>")
_SP_RE = re.compile(r"<p:sp>(.*?)</p:sp>", re.DOTALL)
_FLD_RE = re.compile(r"<a:fld\b.*?</a:fld>", re.DOTALL)
_AT_RE = re.compile(r"<a:t>([^<]*)</a:t>")
_SLDSZ_RE = re.compile(r'<p:sldSz\s+cx="(\d+)"\s+cy="(\d+)"')

_MIME = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
         "gif": "image/gif", "bmp": "image/bmp", "svg": "image/svg+xml",
         "webp": "image/webp", "tiff": "image/tiff", "emf": "image/emf",
         "wmf": "image/wmf"}
# formats a browser <img> can actually render (skip EMF/WMF/TIFF vector/legacy)
_WEB_SAFE = {"png", "jpg", "jpeg", "gif", "bmp", "svg", "webp"}
_MAX_LOGO_BYTES = 6 * 1024 * 1024  # don't inline an absurd payload as a "logo"


def _slide_size(zf: zipfile.ZipFile) -> tuple[int, int]:
    m = _SLDSZ_RE.search(_read(zf, "ppt/presentation.xml"))
    return (int(m.group(1)), int(m.group(2))) if m else (12192000, 6858000)


def _rels_for(zf: zipfile.ZipFile, part: str) -> dict[str, str]:
    """Map rId -> resolved internal target path for a part's .rels file."""
    d, base = part.rsplit("/", 1)
    xml = _read(zf, f"{d}/_rels/{base}.rels")
    out: dict[str, str] = {}
    for rel in _REL_RE.findall(xml):
        rid = re.search(r'Id="([^"]+)"', rel)
        tgt = re.search(r'Target="([^"]+)"', rel)
        mode = re.search(r'TargetMode="([^"]+)"', rel)
        if not rid or not tgt or (mode and mode.group(1) == "External"):
            continue
        target = tgt.group(1)
        resolved = target.lstrip("/") if target.startswith("/") \
            else posixpath.normpath(posixpath.join(d, target))
        out[rid.group(1)] = resolved.replace("\\", "/")
    return out


def _pics(xml: str) -> list[tuple[str, tuple[int, int] | None, tuple[int, int] | None]]:
    """(rId, (offX,offY)|None, (extCx,extCy)|None) for every <p:pic> in a part."""
    out = []
    for body in _PIC_RE.findall(xml):
        emb = _EMBED_RE.search(body)
        if not emb:
            continue
        off = _OFF_RE.search(body)
        ext = _EXT_RE.search(body)
        out.append((
            emb.group(1),
            (int(off.group(1)), int(off.group(2))) if off else None,
            (int(ext.group(1)), int(ext.group(2))) if ext else None,
        ))
    return out


def _corner(off: tuple[int, int] | None, ext: tuple[int, int] | None,
            W: int, H: int) -> str | None:
    if not off:
        return None
    cx = off[0] + (ext[0] / 2 if ext else 0)
    cy = off[1] + (ext[1] / 2 if ext else 0)
    return f"{'top' if cy < H / 2 else 'bottom'}-{'left' if cx < W / 2 else 'right'}"


def _ph_static_text(xml: str, ph_type: str) -> str:
    """Static (non-field) text of the first <p:sp> carrying a given placeholder."""
    ph_re = re.compile(rf'<p:ph\b[^>]*type="{ph_type}"')
    for sp in _SP_RE.findall(xml):
        if not ph_re.search(sp):
            continue
        body = _FLD_RE.sub("", sp)  # drop <a:fld> date/slide-number fields
        runs = [t.strip() for t in _AT_RE.findall(body) if t.strip()]
        # ignore the master's boilerplate ("Click to edit …") prompts
        runs = [t for t in runs if not t.lower().startswith("click to edit")]
        if runs:
            return " ".join(runs).strip()
    return ""


def _has_ph(xml: str, ph_type: str) -> bool:
    return re.search(rf'<p:ph\b[^>]*type="{ph_type}"', xml) is not None


def _extract_brand(zf: zipfile.ZipFile, slide_names: list[str],
                   layout_names: list[str], master_names: list[str],
                   notes: list[str]) -> dict:
    """Lift logo + header/footer/slide-number chrome from the deck's OOXML."""
    W, H = _slide_size(zf)
    slide_area = max(1, W * H)
    n_slides = max(1, len(slide_names))

    # --- gather every embedded picture across master / layouts / slides --------
    stats: dict[str, dict] = {}
    part_kinds = ([(m, "master") for m in master_names]
                  + [(l, "layout") for l in layout_names]
                  + [(s, "slide") for s in slide_names])
    for part, kind in part_kinds:
        xml = _read(zf, part)
        rels = _rels_for(zf, part)
        for rid, off, ext in _pics(xml):
            media = rels.get(rid)
            if not media or not media.startswith("ppt/media/"):
                continue
            st = stats.setdefault(media, {"master": False, "layout": False,
                                          "slides": set(), "occ": []})
            if kind == "master":
                st["master"] = True
            elif kind == "layout":
                st["layout"] = True
            else:
                st["slides"].add(part)
            st["occ"].append((off, ext))

    if not stats:
        notes.append("No embedded logo image found (no <p:pic> in master/layouts/slides).")
        brand: dict = {"showPageNumbers": _page_numbers(zf, layout_names, master_names)}
        _header_footer(zf, layout_names, master_names, brand, notes)
        return brand

    # --- score candidates: master-borne > widely-repeated > smallest; skip bg --
    def rel_area(st: dict) -> float | None:
        areas = [e[0] * e[1] for (_o, e) in st["occ"] if e]
        return (min(areas) / slide_area) if areas else None

    scored = []
    for media, st in stats.items():
        ra = rel_area(st)
        is_bg = ra is not None and ra >= 0.55  # full-bleed => background, not a logo
        cov = len(st["slides"]) / n_slides
        scored.append((media, st, ra, is_bg, cov))

    pool = [c for c in scored if not c[3]] or scored  # keep bg only if nothing else
    # prefer: appears on the master, then broad slide coverage, then smaller size
    pool.sort(key=lambda c: (0 if c[1]["master"] else 1, -round(c[4], 3),
                             c[2] if c[2] is not None else 1.0))
    media, st, ra, is_bg, cov = pool[0]

    brand = {"showPageNumbers": _page_numbers(zf, layout_names, master_names)}
    try:
        raw = zf.read(media)
    except Exception:
        raw = b""
    ext_name = media.rsplit(".", 1)[-1].lower()
    if not raw:
        notes.append(f"Logo candidate '{media.split('/')[-1]}' could not be read; skipped.")
    elif ext_name not in _WEB_SAFE:
        notes.append(f"Logo '{media.split('/')[-1]}' is a {ext_name.upper()} the viewer "
                     "can't render inline; skipped (colors/fonts still extracted).")
    elif len(raw) > _MAX_LOGO_BYTES:
        notes.append(f"Logo '{media.split('/')[-1]}' is too large to inline "
                     f"({len(raw) // 1024} KB); skipped.")
    else:
        uri = f"data:{_MIME.get(ext_name, 'image/png')};base64,{base64.b64encode(raw).decode('ascii')}"
        brand["logo"] = uri
        # majority-vote the corner across placements that carry an <a:off>
        corners = Counter(c for c in (_corner(o, e, W, H) for (o, e) in st["occ"]) if c)
        if corners:
            brand["logoPlacement"] = corners.most_common(1)[0][0]
        # rough relative width (of the largest placement) — a cheap size hint
        widths = [e[0] / W for (_o, e) in st["occ"] if e]
        if widths:
            brand["logoRelWidth"] = round(max(widths), 3)
        where = ("the slide master" if st["master"]
                 else f"{len(st['slides'])} of {n_slides} slides" if st["slides"]
                 else "a layout")
        notes.append(f"Logo detected: '{media.split('/')[-1]}' (recurs on {where}, "
                     f"{brand.get('logoPlacement', 'unknown')} placement).")
        if len([c for c in scored if not c[3]]) > 1:
            notes.append("Multiple candidate images were present; picked the most "
                         "logo-like (master/most-repeated, smallest, non-background).")

    _header_footer(zf, layout_names, master_names, brand, notes)
    return brand


def _page_numbers(zf: zipfile.ZipFile, layout_names: list[str],
                  master_names: list[str]) -> bool:
    """A slide-number placeholder present in master/layouts and not disabled via <p:hf>."""
    has = any(_has_ph(_read(zf, p), "sldNum") for p in master_names + layout_names)
    if not has:
        return False
    for mp in master_names:
        hf = re.search(r"<p:hf\b([^>]*)/?>", _read(zf, mp))
        if hf and re.search(r'sldNum="0"', hf.group(1)):
            return False
    return True


def _header_footer(zf: zipfile.ZipFile, layout_names: list[str],
                   master_names: list[str], brand: dict, notes: list[str]) -> None:
    """Populate brand['headerText'/'footerText'] from hdr/ftr placeholders."""
    def first_text(ph: str) -> str:
        for p in master_names + layout_names:
            t = _ph_static_text(_read(zf, p), ph)
            if t:
                return t
        return ""

    header = first_text("hdr")
    footer = first_text("ftr")
    if header:
        brand["headerText"] = header[:120]
    if footer:
        brand["footerText"] = footer[:120]
    bits = []
    if header:
        bits.append(f"header “{header[:40]}”")
    if footer:
        bits.append(f"footer “{footer[:40]}”")
    if brand.get("showPageNumbers"):
        bits.append("slide numbers")
    if bits:
        notes.append("Chrome found: " + ", ".join(bits) + ".")


# ----------------------------------------------------------------- main extract
def extract_template(data: bytes, filename: str = "presentation.pptx") -> dict:
    notes: list[str] = []
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except Exception as exc:  # not a real .pptx / zip
        raise ValueError(f"Not a readable .pptx (zip) file: {exc}") from exc

    slide_names = _members(zf, "ppt/slides/slide")
    layout_names = _members(zf, "ppt/slideLayouts/")
    master_names = _members(zf, "ppt/slideMasters/")
    theme_names = _members(zf, "ppt/theme/")
    slide_count = len(slide_names)

    # --- theme scheme + fonts (first theme = the presentation theme) -----------
    scheme: dict[str, str] = {}
    theme_heading = theme_body = None
    if theme_names:
        t0 = _read(zf, theme_names[0])
        scheme = _parse_scheme(t0)
        theme_heading, theme_body = _parse_fonts(t0)
    else:
        notes.append("No theme part found; used slide colors + defaults for the scheme.")

    # --- explicit srgbClr frequency across slides (the real custom palette) -----
    slide_colors: Counter[str] = Counter()
    face_counts: Counter[str] = Counter()       # any slide-used latin face
    head_faces: Counter[str] = Counter()        # faces on large (title) runs
    body_faces: Counter[str] = Counter()        # faces on small (body) runs
    sizes: list[int] = []
    for n in slide_names:
        xml = _read(zf, n)
        for m in _SRGB_RE.findall(xml):
            slide_colors["#" + m.upper()] += 1
        for s in _SZ_RE.findall(xml):
            sizes.append(int(s))
        # associate each run's font with its size so we can split heading vs body.
        # runs split cleanly on <a:rPr> / <a:defRPr> / <a:endParaRPr> boundaries.
        for chunk in re.split(r"(?=<a:(?:rPr|defRPr|endParaRPr)\b)", xml):
            fm = _LATIN_RE.search(chunk)
            if not fm:
                continue
            face = fm.group(1).strip()
            if not face or face.startswith("+"):
                continue
            face_counts[face] += 1
            szm = _SZ_RE.search(chunk)
            if szm:
                (head_faces if int(szm.group(1)) >= 2600 else body_faces)[face] += 1
    # layouts/masters contribute at lower weight (chrome, not content)
    for n in layout_names + master_names:
        xml = _read(zf, n)
        for m in _SRGB_RE.findall(xml):
            slide_colors["#" + m.upper()] += 1  # already low-count vs slides
    if not slide_colors:
        notes.append("No explicit slide colors; palette derived from the theme scheme.")

    # fold theme accents into the pool so decks that reference theme colors
    # (rather than literal srgbClr) still yield a palette
    for slot in ("accent1", "accent2", "accent3", "accent4", "accent5", "accent6"):
        if slot in scheme:
            slide_colors[scheme[slot]] += 3

    # --- background: master bg -> layout bg -> slide bg -> theme lt1/dk1 --------
    def _bg_from(names: list[str]) -> str | None:
        found: Counter[str] = Counter()
        for n in names:
            xml = _read(zf, n)
            for blk in _BG_BLOCK_RE.findall(xml):
                c = _first_color(blk)
                if c:
                    found[c] += 1
        return found.most_common(1)[0][0] if found else None

    bg = _bg_from(master_names) or _bg_from(layout_names) or _bg_from(slide_names)
    if not bg:
        # no explicit background: fall back to the theme's light/dark base.
        # dk2/lt1 heuristic — most business decks are light on lt1.
        bg = scheme.get("lt1") or "#FFFFFF"
        notes.append("No explicit background fill; used the theme base "
                     f"({bg}). Assumed a solid ground.")
    bg = _norm(bg) or "#FFFFFF"
    dark = _lum(bg) < 0.5
    mode = "dark" if dark else "light"

    # --- text color: frequent low-saturation color that reads on bg, else derived
    text = None
    for hexc, _cnt in slide_colors.most_common():
        if _sat(hexc) <= 0.22 and _contrast(hexc, bg) >= 4.5:
            text = hexc
            break
    if not text:
        # theme dk1/lt1 opposite the background, else computed
        cand = scheme.get("lt1") if dark else scheme.get("dk1")
        if cand and _contrast(cand, bg) >= 4.5:
            text = cand
        else:
            text = "#F1F5F9" if dark else "#111318"
    # WCAG-AA enforce text vs background (nudge toward white/black)
    text = _enforce_aa(text, bg)

    # --- primary / secondary / accent: colored fills unlike bg + text ----------
    def _is_chrome(hexc: str) -> bool:
        return (_rgb_dist(hexc, bg) < 45) or (_rgb_dist(hexc, text) < 30)

    ranked = sorted(
        ((hexc, cnt) for hexc, cnt in slide_colors.items() if not _is_chrome(hexc)),
        key=lambda kv: kv[1] * (0.4 + _sat(kv[0])),
        reverse=True,
    )
    palette_hexes = [h for h, _ in ranked]
    if palette_hexes:
        primary = palette_hexes[0]
    else:
        primary = scheme.get("accent1") or ("#38BDF8" if dark else "#4F46E5")
        notes.append("No distinct brand color on the slides; used the theme "
                     "accent (or a sensible default) as primary.")

    # accent = most hue-distant from primary among the top candidates
    rest = [h for h in palette_hexes[1:] if _rgb_dist(h, primary) >= 40]
    secondary = rest[0] if rest else _derive_accent(primary)
    accent = None
    if rest:
        accent = max(rest, key=lambda h: _hue_dist(h, primary))
    if not accent or _rgb_dist(accent, primary) < 40:
        accent = _derive_accent(primary)

    onPrimary = "#FFFFFF" if _contrast("#FFFFFF", primary) >= _contrast("#111111", primary) else "#111111"
    surface = _mix(bg, "#FFFFFF" if dark else "#000000", 0.07)
    text_muted = _mix(text, bg, 0.42)
    # keep muted text at least loosely legible
    if _contrast(text_muted, bg) < 3.0:
        text_muted = _mix(text, bg, 0.28)

    # --- fonts -----------------------------------------------------------------
    # A brand's real typography lives on the SLIDES (the theme's major/minor are
    # often the Office defaults). Prefer the dominant slide face per size bucket,
    # then any slide face, then the theme scheme, then Inter.
    top_face = face_counts.most_common(1)[0][0] if face_counts else None
    heading = (head_faces.most_common(1)[0][0] if head_faces else None) \
        or top_face or _clean_font(theme_heading, "") or "Inter"
    body = (body_faces.most_common(1)[0][0] if body_faces else None) \
        or top_face or _clean_font(theme_body, "") or heading
    if not face_counts and not theme_heading:
        notes.append("No font information found; defaulted to Inter.")
    elif not face_counts:
        notes.append("No slide-level fonts; used the theme's declared typefaces.")

    # --- type scale ------------------------------------------------------------
    title_pts = [s / 100 for s in sizes if s >= 2600]
    body_pts = [s / 100 for s in sizes if 1000 <= s <= 2400]
    head_scale = _clamp((_median(title_pts) or 42) / 42, 0.7, 2.0)
    body_scale = _clamp((_median(body_pts) or 18) / 18, 0.75, 1.6)

    # --- cover architecture (deterministic heuristic) --------------------------
    img_count = sum(_read(zf, n).count("<p:pic") for n in slide_names)
    chart_count = (len([n for n in zf.namelist() if n.startswith("ppt/charts/")])
                   + sum(_read(zf, n).count("<a:tbl>") for n in slide_names))
    strong_colors = len([h for h in palette_hexes if _sat(h) >= 0.35])
    avg_img = img_count / max(1, slide_count)
    cover, cover_reason = _pick_cover(dark, _sat(primary), avg_img, chart_count, strong_colors)
    notes.append(f"Cover architecture '{cover}' chosen ({cover_reason}).")

    category = "Data" if chart_count >= 2 else ("Business" if not dark else "Business")
    if category == "Business":
        notes.append("Category defaulted to Business (deterministic extraction "
                     "does not read slide topics).")

    base = re.sub(r"\.pptx$", "", filename, flags=re.IGNORECASE)
    base = re.sub(r"[_\-]+", " ", base).strip() or "Imported deck"
    suggested = f"{base[:40]} style"
    theme_id = "extracted-" + _hash(f"{bg}{primary}{accent}{heading}{mode}")

    style = {
        "cover": cover,
        "bg": "grid" if (dark and chart_count >= 1) else "plain",
        "accent": "bar",
        "headScale": round(head_scale, 3),
        "bodyScale": round(body_scale, 3),
        "radius": 12,
    }

    theme = {
        "id": theme_id,
        "name": base[:40] or "Extracted",
        "dark": dark,
        "colors": {
            "background": bg,
            "surface": surface,
            "primary": primary,
            "secondary": secondary,
            "accent": accent,
            "text": text,
            "textMuted": text_muted,
            "onPrimary": onPrimary,
        },
        "fonts": {"heading": heading, "body": body},
    }

    contrast = {
        "textOnBackground": round(_contrast(text, bg), 2),
        "mutedOnBackground": round(_contrast(text_muted, bg), 2),
        "onPrimaryOnPrimary": round(_contrast(onPrimary, primary), 2),
        "aa": _contrast(text, bg) >= 4.5 and _contrast(onPrimary, primary) >= 3.0,
    }

    preview_palette = [
        {"name": "Primary", "hex": primary},
        {"name": "Secondary", "hex": secondary},
        {"name": "Accent", "hex": accent},
        {"name": "Background", "hex": bg},
        {"name": "Surface", "hex": surface},
        {"name": "Text", "hex": text},
    ]

    descriptor = {
        "suggestedName": suggested,
        "category": category,
        "mode": mode,
        "cover": cover,
        "style": style,
        "fonts": {"heading": heading, "body": body},
        "sourceName": filename,
        "slideCount": slide_count,
        "imageCount": img_count,
        "chartCount": chart_count,
        "notes": notes,
    }

    # --- brand chrome: logo + header/footer/slide-number (deterministic) -------
    brand = _extract_brand(zf, slide_names, layout_names, master_names, notes)

    return {
        "theme": theme,
        "descriptor": descriptor,
        "previewPalette": preview_palette,
        "contrast": contrast,
        "brand": brand,
    }


# ----------------------------------------------------------------- small utils
def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _median(xs: list[float]) -> float | None:
    a = sorted(x for x in xs if x > 0)
    return a[len(a) // 2] if a else None


def _hash(s: str) -> str:
    h = 0
    for ch in s:
        h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    return format(h, "x")[:8]


def _derive_accent(hex6: str) -> str:
    """Rotate a color's hue ~150 deg (HSL) to get a distinct complementary accent."""
    r, g, b = _rgb(hex6)
    mx, mn = max(r, g, b), min(r, g, b)
    l = (mx + mn) / 2 / 255
    s = _sat(hex6)
    h = (_hue(hex6) + 150) % 360
    c = (1 - abs(2 * l - 1)) * s
    x = c * (1 - abs((h / 60) % 2 - 1))
    m = l - c / 2
    if h < 60:
        rr, gg, bb = c, x, 0
    elif h < 120:
        rr, gg, bb = x, c, 0
    elif h < 180:
        rr, gg, bb = 0, c, x
    elif h < 240:
        rr, gg, bb = 0, x, c
    elif h < 300:
        rr, gg, bb = x, 0, c
    else:
        rr, gg, bb = c, 0, x
    return _hex((rr + m) * 255, (gg + m) * 255, (bb + m) * 255)


def _enforce_aa(text: str, bg: str, need: float = 4.5) -> str:
    """Nudge `text` toward white/black (away from bg) until it meets WCAG AA."""
    if _contrast(text, bg) >= need:
        return text
    toward = "#FFFFFF" if _lum(bg) < 0.45 else "#111827"
    best = text
    for t in (0.15, 0.3, 0.45, 0.6, 0.8, 1.0):
        cand = _mix(text, toward, t)
        best = cand
        if _contrast(cand, bg) >= need:
            return cand
    return best


def _pick_cover(dark: bool, primary_sat: float, avg_img: float,
                chart_count: int, strong_colors: int) -> tuple[str, str]:
    """Closest cover architecture from OATIGenie's vocabulary, deterministically."""
    if avg_img >= 1.2:
        return "framedEditorial", "image-rich source deck"
    if chart_count >= 2:
        return "swissGrid", "data/table-heavy source deck"
    if strong_colors <= 1 and avg_img < 0.2:
        return "typeHero", "minimal, type-led source deck"
    if dark and primary_sat >= 0.5:
        return "colorField", "dark deck with a bold saturated brand color"
    if dark:
        return "masthead", "dark corporate deck"
    return "spine", "light editorial deck"
