"""
Compare two Word/PDF documents at the paragraph level.
Returns structured diff blocks (for the UI) and/or a REDLINED .docx download.
"""
from __future__ import annotations

import io
from difflib import SequenceMatcher

from docx import Document
from docx.shared import RGBColor

GREEN = RGBColor(0x1B, 0x5E, 0x20)
RED = RGBColor(0xB7, 0x1C, 0x1C)
GREY = RGBColor(0x55, 0x55, 0x55)


def extract(kind: str, data: bytes) -> list[str]:
    if kind == "docx":
        doc = Document(io.BytesIO(data))
        return [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    if kind == "pdf":
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        lines: list[str] = []
        for page in reader.pages:
            for ln in (page.extract_text() or "").splitlines():
                if ln.strip():
                    lines.append(ln.strip())
        return lines
    raise ValueError(f"unsupported kind: {kind}")


def diff_blocks(a: list[str], b: list[str]) -> tuple[list[dict], int, int]:
    sm = SequenceMatcher(None, a, b, autojunk=False)
    blocks: list[dict] = []
    added = removed = 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for line in b[j1:j2]:
                blocks.append({"type": "equal", "text": line})
        elif tag == "delete":
            for line in a[i1:i2]:
                blocks.append({"type": "removed", "text": line})
                removed += 1
        elif tag == "insert":
            for line in b[j1:j2]:
                blocks.append({"type": "added", "text": line})
                added += 1
        elif tag == "replace":
            for line in a[i1:i2]:
                blocks.append({"type": "removed", "text": line})
                removed += 1
            for line in b[j1:j2]:
                blocks.append({"type": "added", "text": line})
                added += 1
    return blocks, added, removed


def blocks_for(kind: str, bytes_a: bytes, bytes_b: bytes) -> tuple[list[dict], int, int]:
    return diff_blocks(extract(kind, bytes_a), extract(kind, bytes_b))


def build_redline(blocks: list[dict], added: int, removed: int) -> bytes:
    out = Document()
    out.add_heading("Document comparison", level=1)
    p = out.add_paragraph()
    r = p.add_run(f"Green = added · red strike-through = removed.  ({added} added, {removed} removed lines)")
    r.font.color.rgb = GREY
    r.italic = True
    out.add_paragraph("")
    for blk in blocks:
        t, text = blk["type"], blk["text"]
        if t == "equal":
            out.add_paragraph(text)
        else:
            run = out.add_paragraph().add_run(("+ " if t == "added" else "− ") + text)
            run.font.color.rgb = GREEN if t == "added" else RED
            run.font.strike = t == "removed"
    buf = io.BytesIO()
    out.save(buf)
    return buf.getvalue()


def compare_documents(kind: str, bytes_a: bytes, bytes_b: bytes) -> bytes:
    blocks, added, removed = blocks_for(kind, bytes_a, bytes_b)
    return build_redline(blocks, added, removed)
