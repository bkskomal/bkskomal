"""
High-fidelity PPTX renderer for PPTMaker.

Consumes the SAME Deck JSON the web app uses (the single source of truth) and
produces an editable .pptx with true gradient fills and crisp native shapes —
fidelity beyond the in-browser pptxgenjs exporter. This is deterministic code
WE wrote; it does NOT execute any AI-generated code.
"""
from __future__ import annotations

import base64
import io
from copy import deepcopy
from typing import Any

from lxml import etree
from pptx import Presentation
from .recipes.gantt import add_gantt
from pptx.chart.data import CategoryChartData, XyChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Emu, Pt

EMU_PER_PX = 9525  # 96 px/inch, 914400 EMU/inch  -> 9525 EMU/px


def px(v: float) -> Emu:
    return Emu(int(round(v * EMU_PER_PX)))


# ---------------------------------------------------------------- color tokens
def resolve_color(value: str | None, theme: dict, brand: dict, fallback: str = "FFFFFF") -> str:
    """Mirror of color.ts resolveColor — returns a 6-char hex (no #)."""
    if not value or value == "transparent":
        return fallback
    if value.startswith("#"):
        return value[1:]
    if value.startswith("token:"):
        token = value[6:]
        if token == "primary" and brand.get("primaryColor"):
            return brand["primaryColor"].lstrip("#")
        if token == "accent" and brand.get("accentColor"):
            return brand["accentColor"].lstrip("#")
        col = theme.get("colors", {}).get(token)
        return col.lstrip("#") if col else fallback
    return value.lstrip("#")


def resolve_font(family: str | None, role: str, theme: dict, brand: dict) -> str:
    if family:
        return family
    fonts = theme.get("fonts", {})
    if role == "heading":
        return brand.get("fontHeading") or fonts.get("heading", "Inter")
    return brand.get("fontBody") or fonts.get("body", "Inter")


# ---------------------------------------------------------------- gradient XML
def _srgb(hex6: str, alpha: int | None = None) -> str:
    inner = f'<a:alpha val="{alpha * 1000}"/>' if alpha is not None else ""
    return f'<a:srgbClr val="{hex6.upper()}">{inner}</a:srgbClr>' if inner else f'<a:srgbClr val="{hex6.upper()}"/>'


def set_gradient(shape, c1: str, c2: str, angle_deg: float) -> None:
    """Inject a two-stop linear gradient fill into a shape's spPr."""
    spPr = shape._element.spPr
    for tag in ("a:noFill", "a:solidFill", "a:gradFill", "a:blipFill", "a:pattFill"):
        for el in spPr.findall(qn(tag)):
            spPr.remove(el)
    # PowerPoint angle is in 60000ths of a degree, measured clockwise from 3 o'clock.
    ang = int((angle_deg % 360) * 60000)
    xml = (
        f'<a:gradFill xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" rotWithShape="1">'
        f'<a:gsLst>'
        f'<a:gs pos="0">{_srgb(c1)}</a:gs>'
        f'<a:gs pos="100000">{_srgb(c2)}</a:gs>'
        f'</a:gsLst>'
        f'<a:lin ang="{ang}" scaled="1"/>'
        f'</a:gradFill>'
    )
    spPr.append(etree.fromstring(xml))


def set_solid_alpha(shape, hex6: str, opacity: float) -> None:
    """Solid fill with alpha (opacity 0..1)."""
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor.from_string(hex6.upper())
    if opacity < 1:
        srgb = shape.fill.fore_color._xFill.find(qn("a:srgbClr"))
        if srgb is not None:
            alpha = etree.SubElement(srgb, qn("a:alpha"))
            alpha.set("val", str(int(opacity * 100000)))


SHAPE_MAP = {
    "rect": MSO_SHAPE.RECTANGLE,
    "roundedRect": MSO_SHAPE.ROUNDED_RECTANGLE,
    "pill": MSO_SHAPE.ROUNDED_RECTANGLE,
    "ellipse": MSO_SHAPE.OVAL,
    "blob": MSO_SHAPE.OVAL,
    "triangle": MSO_SHAPE.ISOSCELES_TRIANGLE,
    "trapezoid": MSO_SHAPE.TRAPEZOID,
    "chevron": MSO_SHAPE.CHEVRON,
    "arrowRight": MSO_SHAPE.RIGHT_ARROW,
    "hexagon": MSO_SHAPE.HEXAGON,
    "pentagon": MSO_SHAPE.REGULAR_PENTAGON,
    "diamond": MSO_SHAPE.DIAMOND,
    "star": MSO_SHAPE.STAR_5_POINT,
    "parallelogram": MSO_SHAPE.PARALLELOGRAM,
}

ALIGN_MAP = {"left": PP_ALIGN.LEFT, "center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT}
ANCHOR_MAP = {"top": MSO_ANCHOR.TOP, "middle": MSO_ANCHOR.MIDDLE, "bottom": MSO_ANCHOR.BOTTOM}


# ---------------------------------------------------------------- brand chrome
# Mirror of src/lib/brand.ts — premium header/footer presets. Keep both in sync.
FULL_BLEED = {"cover", "sectionHeader", "closing"}
HEADER_H = 74
FOOTER_H = 44


def _header_preset(brand: dict) -> str:
    return brand.get("headerPreset") or ("band" if brand.get("headerStyle") == "band" else "rule")


def _footer_preset(brand: dict) -> str:
    return brand.get("footerPreset") or ("band" if brand.get("footerStyle") == "band" else "line")


BANNER_H = 88


def _lum(hx: str) -> float:
    h = hx.lstrip("#")
    if len(h) < 6:
        return 0.5
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255


def _readable_pref(bg: str, pref: str, fallbacks: list[str]) -> str:
    if abs(_lum(pref) - _lum(bg)) >= 0.16:
        return pref
    return max(fallbacks, key=lambda c: abs(_lum(c) - _lum(bg)))


def _banner_header(brand: dict, W: float, pad: float, logo_size: float, theme: dict | None = None) -> list[dict]:
    out: list[dict] = []
    out.append({"id": "hb", "type": "shape", "shape": "rect", "x": 0, "y": 0, "w": W, "h": BANNER_H, "fill": "token:surface", "z": 40})
    out.append({"id": "hr", "type": "shape", "shape": "rect", "x": 0, "y": BANNER_H, "w": W, "h": 4, "fill": "token:accent", "z": 41})
    x = pad
    if brand.get("logoUrl"):
        w = logo_size * 2.4
        out.append({"id": "brand-logo", "type": "image", "src": brand["logoUrl"], "fit": "contain",
                    "x": pad, "y": (BANNER_H - logo_size) / 2, "w": w, "h": logo_size, "z": 42})
        x = pad + w + 22
    has_sub = bool(brand.get("headerSubtext"))
    if brand.get("headerText"):
        out.append({"id": "ht", "type": "text", "text": str(brand["headerText"]), "x": x, "y": 18 if has_sub else 0,
                    "w": W - x - pad, "h": 34 if has_sub else BANNER_H, "align": "left",
                    "valign": "bottom" if has_sub else "middle", "fontSize": 26, "fontWeight": 700, "color": "token:text", "z": 42})
    if has_sub:
        if theme is not None:
            surface = resolve_color("token:surface", theme, brand, "1A2B4A")
            subcol = _readable_pref(surface, resolve_color("token:secondary", theme, brand, "2563EB"),
                                    [resolve_color("token:textMuted", theme, brand, "8C9BAB"), resolve_color("token:text", theme, brand, "FFFFFF")])
        else:
            subcol = "token:secondary"
        out.append({"id": "hs", "type": "text", "text": str(brand["headerSubtext"]), "x": x, "y": 52,
                    "w": W - x - pad, "h": 26, "align": "left", "valign": "top", "fontSize": 14, "fontWeight": 600, "color": subcol, "z": 42})
    return out


def _header_elements(preset: str, brand: dict, W: float, pad: float, logo_size: float, theme: dict | None = None) -> list[dict]:
    if preset == "banner":
        return _banner_header(brand, W, pad, logo_size, theme)
    out: list[dict] = []
    text_color = "token:onPrimary" if preset == "gradientBar" else "token:textMuted"

    if preset == "band":
        out.append({"id": "hb", "type": "shape", "shape": "rect", "x": 0, "y": 0, "w": W, "h": HEADER_H, "fill": "token:surface", "z": 40})
        out.append({"id": "hr", "type": "shape", "shape": "rect", "x": 0, "y": HEADER_H, "w": W, "h": 4, "gradient": ["token:primary", "token:accent"], "gradientAngle": 90, "z": 41})
    elif preset == "gradientBar":
        out.append({"id": "hb", "type": "shape", "shape": "rect", "x": 0, "y": 0, "w": W, "h": HEADER_H, "gradient": ["token:primary", "token:accent"], "gradientAngle": 90, "z": 40})
    elif preset == "rule":
        out.append({"id": "hr", "type": "shape", "shape": "rect", "x": 0, "y": 0, "w": W, "h": 6, "gradient": ["token:primary", "token:accent"], "gradientAngle": 90, "z": 41})
    elif preset == "sidebar":
        out.append({"id": "hs", "type": "shape", "shape": "rect", "x": 0, "y": 0, "w": 8, "h": HEADER_H, "gradient": ["token:primary", "token:accent"], "gradientAngle": 0, "z": 41})
        out.append({"id": "hr", "type": "shape", "shape": "rect", "x": 0, "y": HEADER_H - 2, "w": W, "h": 2, "fill": "token:accent", "opacity": 0.35, "z": 41})
    elif preset == "minimal":
        out.append({"id": "hr", "type": "shape", "shape": "rect", "x": pad, "y": HEADER_H - 2, "w": W - pad * 2, "h": 2, "fill": "token:accent", "opacity": 0.4, "z": 41})

    logo_x = pad + 20 if preset == "sidebar" else pad
    if brand.get("logoUrl"):
        out.append({"id": "brand-logo", "type": "image", "src": brand["logoUrl"], "fit": "contain",
                    "x": logo_x, "y": (HEADER_H - logo_size) / 2, "w": logo_size * 2.4, "h": logo_size, "z": 42})
    if brand.get("headerText"):
        out.append({"id": "ht", "type": "text", "text": str(brand["headerText"]).upper(), "x": W - 460, "y": 0,
                    "w": 420, "h": HEADER_H, "align": "right", "valign": "middle", "fontSize": 14, "fontWeight": 700, "color": text_color, "z": 42})
    return out


def _footer_elements(preset: str, brand: dict, W: float, H: float, pad: float, page_index: int, page_count: int) -> list[dict]:
    out: list[dict] = []
    y = H - FOOTER_H
    page = f"{page_index + 1} / {page_count}"

    if preset == "band":
        out.append({"id": "fb", "type": "shape", "shape": "rect", "x": 0, "y": y, "w": W, "h": FOOTER_H, "fill": "token:surface", "opacity": 0.9, "z": 40})
    elif preset == "line":
        out.append({"id": "fr", "type": "shape", "shape": "rect", "x": pad, "y": y, "w": W - pad * 2, "h": 2, "fill": "token:accent", "opacity": 0.3, "z": 40})

    if preset == "pageOnly":
        out.append({"id": "brand-page", "type": "text", "text": page, "x": W / 2 - 100, "y": y, "w": 200, "h": FOOTER_H,
                    "align": "center", "valign": "middle", "fontSize": 12, "color": "token:textMuted", "z": 42})
        return out

    if preset == "confidential":
        label = (brand.get("footerText") or "Confidential").upper()
        pill_w = min(260, 24 + len(label) * 8.5)
        out.append({"id": "fp", "type": "shape", "shape": "roundedRect", "radius": 999, "x": pad, "y": y + 8, "w": pill_w, "h": FOOTER_H - 16, "fill": "token:accent", "opacity": 0.16, "z": 40})
        out.append({"id": "brand-footer", "type": "text", "text": label, "x": pad, "y": y + 8, "w": pill_w, "h": FOOTER_H - 16,
                    "align": "center", "valign": "middle", "fontSize": 11, "fontWeight": 700, "color": "token:accent", "z": 42})
        out.append({"id": "brand-page", "type": "text", "text": page, "x": W - 140, "y": y, "w": 100, "h": FOOTER_H,
                    "align": "right", "valign": "middle", "fontSize": 12, "color": "token:textMuted", "z": 42})
        return out

    if brand.get("footerText"):
        out.append({"id": "brand-footer", "type": "text", "text": brand["footerText"], "x": pad, "y": y, "w": W - 240, "h": FOOTER_H,
                    "valign": "middle", "fontSize": 12, "color": "token:textMuted", "z": 42})
    if brand.get("showPageNumbers"):
        out.append({"id": "brand-page", "type": "text", "text": page, "x": W - 140, "y": y, "w": 100, "h": FOOTER_H,
                    "align": "right", "valign": "middle", "fontSize": 12, "color": "token:textMuted", "z": 42})
    return out


def brand_chrome(brand: dict, layout: str, page_index: int, page_count: int, W: float, H: float, slide_logo_scale=None, theme: dict | None = None) -> list[dict]:
    out: list[dict] = []
    pad = 40
    full_bleed = layout in FULL_BLEED
    logo_size = 48 * (slide_logo_scale if slide_logo_scale is not None else (brand.get("logoScale") or 1))

    if brand.get("showHeader", True) and not full_bleed:
        out += _header_elements(_header_preset(brand), brand, W, pad, logo_size, theme)

    if brand.get("logoUrl") and full_bleed:
        placement = brand.get("logoPlacement", "top-left")
        top = placement.startswith("top")
        left = placement.endswith("left")
        ls = logo_size * 1.8 if layout == "cover" else logo_size
        out.append({"id": "brand-logo", "type": "image", "src": brand["logoUrl"], "fit": "contain",
                    "x": pad if left else W - pad - ls * 2.4, "y": pad if top else H - pad - ls,
                    "w": ls * 2.4, "h": ls, "z": 42})

    if brand.get("showFooter", True) and not full_bleed:
        out += _footer_elements(_footer_preset(brand), brand, W, H, pad, page_index, page_count)

    return out


# ---------------------------------------------------------------- elements
def add_text(slide, el: dict, theme: dict, brand: dict) -> None:
    tb = slide.shapes.add_textbox(px(el["x"]), px(el["y"]), px(el["w"]), px(el["h"]))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = ANCHOR_MAP.get(el.get("valign", "top"), MSO_ANCHOR.TOP)
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0

    role = "heading" if el.get("role") in ("title", "heading", "quote") else "body"
    color = resolve_color(el.get("color"), theme, brand, "111111")
    font_name = resolve_font(el.get("fontFamily"), role, theme, brand)
    size = el.get("fontSize", 24)
    weight = el.get("fontWeight", 400)
    align = ALIGN_MAP.get(el.get("align", "left"), PP_ALIGN.LEFT)
    line_h = el.get("lineHeight", 1.2)

    items = el.get("items")
    is_list = items and el.get("listStyle") not in (None, "none")
    lines = items if is_list else el.get("text", "").split("\n")

    first = True
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align
        try:
            p.line_spacing = line_h
        except Exception:
            pass
        prefix = ("• " if el.get("listStyle") != "number" else f"{i + 1}. ") if is_list else ""
        run = p.add_run()
        run.text = prefix + line
        f = run.font
        f.size = Pt(size * 0.75)
        f.bold = weight >= 600
        f.italic = bool(el.get("italic"))
        f.name = font_name
        f.color.rgb = RGBColor.from_string(color.upper())


def add_shape(slide, el: dict, theme: dict, brand: dict) -> None:
    auto = SHAPE_MAP.get(el.get("shape", "rect"), MSO_SHAPE.RECTANGLE)
    sp = slide.shapes.add_shape(auto, px(el["x"]), px(el["y"]), px(el["w"]), px(el["h"]))
    sp.line.fill.background()
    if el.get("rotation"):
        sp.rotation = el["rotation"]

    grad = el.get("gradient")
    if grad:
        set_gradient(sp, resolve_color(grad[0], theme, brand), resolve_color(grad[1], theme, brand), el.get("gradientAngle", 135))
    else:
        fill = resolve_color(el.get("fill"), theme, brand, "")
        if fill:
            set_solid_alpha(sp, fill, el.get("opacity", 1))
        else:
            sp.fill.background()


def add_native_chart(slide, source: dict, theme: dict, brand: dict) -> None:
    """Replace the flattened bar shapes with a real PowerPoint bar chart."""
    chart = source.get("chart") or {}
    data = chart.get("data") or []
    if not data:
        return
    cd = CategoryChartData()
    cd.categories = [str(d.get("label", "")) for d in data]
    cd.add_series(source.get("title", "Series"), [float(d.get("value", 0)) for d in data])
    # chart region mirrors layouts.ts: x=88, y=300, w=1104, h=300
    gframe = slide.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, px(88), px(300), px(1104), px(300), cd)
    ch = gframe.chart
    ch.has_legend = False
    plot = ch.plots[0]
    plot.has_data_labels = True
    plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
    series = plot.series[0]
    series.format.fill.solid()
    series.format.fill.fore_color.rgb = RGBColor.from_string(resolve_color("token:primary", theme, brand, "6366F1").upper())


CHART_TYPE_MAP = {
    "column": XL_CHART_TYPE.COLUMN_CLUSTERED,
    "bar": XL_CHART_TYPE.BAR_CLUSTERED,
    "line": XL_CHART_TYPE.LINE_MARKERS,
    "area": XL_CHART_TYPE.AREA,
    "pie": XL_CHART_TYPE.PIE,
    "donut": XL_CHART_TYPE.DOUGHNUT,
    "stackedColumn": XL_CHART_TYPE.COLUMN_STACKED,
    "stackedBar": XL_CHART_TYPE.BAR_STACKED,
    "stackedArea": XL_CHART_TYPE.AREA_STACKED,
    "radar": XL_CHART_TYPE.RADAR,
}


def add_chart_element(slide, el: dict, theme: dict, brand: dict) -> None:
    """Render a first-class chart element as a native, editable PowerPoint chart."""
    cats = el.get("categories") or []
    series = el.get("series") or []
    if not cats or not series:
        return
    ctype = el.get("chartType", "column")
    palette = el.get("palette") or ["token:primary", "token:accent", "token:secondary", "token:textMuted"]
    hexes = [resolve_color(c, theme, brand, "6366F1").upper().replace("#", "") for c in palette]

    def _finish(ch) -> None:
        ch.has_legend = bool(el.get("legend")) and len(series) > 1
        if ch.has_legend:
            ch.legend.position = XL_LEGEND_POSITION.BOTTOM
            ch.legend.include_in_layout = False
        try:
            for i, sr in enumerate(ch.plots[0].series):
                sr.format.fill.solid()
                sr.format.fill.fore_color.rgb = RGBColor.from_string(hexes[i % len(hexes)])
        except Exception:
            pass

    # SCATTER: needs XyChartData (not CategoryChartData). X = the numeric value
    # of the category when parseable, else its 1..n index; Y = the series value.
    if ctype == "scatter":
        def _xval(c, i):
            try:
                s = str(c).strip()
                return float(s) if s != "" else float(i + 1)
            except (TypeError, ValueError):
                return float(i + 1)
        xs = [_xval(c, i) for i, c in enumerate(cats)]
        xd = XyChartData()
        for se in series:
            sr = xd.add_series(str(se.get("name", "Series")))
            data = se.get("data", [])
            for i, x in enumerate(xs):
                y = float(data[i] or 0) if i < len(data) else 0.0
                sr.add_data_point(x, y)
        gframe = slide.shapes.add_chart(
            XL_CHART_TYPE.XY_SCATTER, px(el["x"]), px(el["y"]), px(el["w"]), px(el["h"]), xd
        )
        _finish(gframe.chart)
        return

    xl = CHART_TYPE_MAP.get(ctype, XL_CHART_TYPE.COLUMN_CLUSTERED)
    # combo: python-pptx has no reliable public API for a mixed column+line
    # multi-plot, so render every series as clustered columns (default xl).
    # TODO combo: python-pptx multi-plot fallback
    cd = CategoryChartData()
    cd.categories = [str(c) for c in cats]
    use = series[:1] if ctype in ("pie", "donut") else series
    for se in use:
        cd.add_series(str(se.get("name", "Series")), [float(v or 0) for v in se.get("data", [])])
    gframe = slide.shapes.add_chart(xl, px(el["x"]), px(el["y"]), px(el["w"]), px(el["h"]), cd)
    _finish(gframe.chart)


def add_native_table(slide, source: dict, theme: dict, brand: dict) -> None:
    """Replace the flattened comparison cards with a real PowerPoint table."""
    cols = source.get("columns") or []
    if not cols:
        return
    n_cols = len(cols)
    rows = 1 + max((len(c.get("points", [])) for c in cols), default=0)
    gframe = slide.shapes.add_table(rows, n_cols, px(88), px(280), px(1104), px(360))
    table = gframe.table
    primary = resolve_color("token:primary", theme, brand, "6366F1")
    on_primary = resolve_color("token:onPrimary", theme, brand, "FFFFFF")
    text_col = resolve_color("token:text", theme, brand, "111111")
    for ci, c in enumerate(cols):
        head = table.cell(0, ci)
        head.text = str(c.get("heading", ""))
        head.fill.solid()
        head.fill.fore_color.rgb = RGBColor.from_string(primary.upper())
        for run in head.text_frame.paragraphs[0].runs:
            run.font.bold = True
            run.font.color.rgb = RGBColor.from_string(on_primary.upper())
        points = c.get("points", [])
        for ri in range(1, rows):
            cell = table.cell(ri, ci)
            cell.text = points[ri - 1] if ri - 1 < len(points) else ""
            for run in cell.text_frame.paragraphs[0].runs:
                run.font.size = Pt(14)
                run.font.color.rgb = RGBColor.from_string(text_col.upper())


def add_image(slide, el: dict) -> None:
    src = el.get("src", "")
    if not src.startswith("data:"):
        return  # only embedded data URLs are portable
    b64 = src.split(",", 1)[1]
    stream = io.BytesIO(base64.b64decode(b64))
    slide.shapes.add_picture(stream, px(el["x"]), px(el["y"]), px(el["w"]), px(el["h"]))


# ---------------------------------------------------------------- deck
def render_deck(deck: dict) -> bytes:
    theme = deck.get("theme", {})
    brand = deck.get("brand", {})
    size = deck.get("size", {"w": 1280, "h": 720})
    W, H = size["w"], size["h"]

    prs = Presentation()
    prs.slide_width = px(W)
    prs.slide_height = px(H)
    blank = prs.slide_layouts[6]

    slides = deck.get("slides", [])
    for i, sld in enumerate(slides):
        slide = prs.slides.add_slide(blank)

        # full-bleed background (solid or gradient) as the first shape
        bg = sld.get("background")
        bg_shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, px(0), px(0), px(W), px(H))
        bg_shape.line.fill.background()
        if bg and bg.get("type") == "gradient" and bg.get("gradient"):
            set_gradient(bg_shape, resolve_color(bg["gradient"][0], theme, brand),
                         resolve_color(bg["gradient"][1], theme, brand), bg.get("gradientAngle", 135))
        else:
            color = resolve_color((bg or {}).get("color"), theme, brand, resolve_color("token:background", theme, brand, "FFFFFF"))
            bg_shape.fill.solid()
            bg_shape.fill.fore_color.rgb = RGBColor.from_string(color.upper())

        # Native chart / table: detect from the semantic source and replace the
        # flattened data-viz primitives (those tagged dataViz) with real objects.
        source = sld.get("source") or {}
        own_pre = sld.get("elements", [])
        native = None
        # legacy flattened-bar charts (tagged dataViz); new decks use a first-class chart element
        if source.get("layout") == "chart" and (source.get("chart") or {}).get("data") and any(e.get("dataViz") for e in own_pre):
            native = "chart"
        elif source.get("layout") == "comparison" and source.get("columns"):
            native = "table"
        elif source.get("layout") == "gantt" and (source.get("gantt") or {}).get("tasks"):
            native = "gantt"

        own = sld.get("elements", [])
        if native:
            own = [e for e in own if not e.get("dataViz")]

        elements = list(own) + brand_chrome(brand, sld.get("layout", ""), i, len(slides), W, H, sld.get("logoScale"), theme)
        elements.sort(key=lambda e: e.get("z", 0))
        for el in elements:
            t = el.get("type")
            if t == "text":
                add_text(slide, el, theme, brand)
            elif t == "shape":
                add_shape(slide, el, theme, brand)
            elif t == "image":
                add_image(slide, el)
            elif t == "chart":
                add_chart_element(slide, el, theme, brand)

        if native == "chart":
            add_native_chart(slide, source, theme, brand)
        elif native == "table":
            add_native_table(slide, source, theme, brand)
        elif native == "gantt":
            add_gantt(slide, source, resolve_color("token:primary", theme, brand, "6366F1"))

        if sld.get("notes"):
            slide.notes_slide.notes_text_frame.text = sld["notes"]

    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()


if __name__ == "__main__":
    # quick self-test with a tiny synthetic deck
    sample = {
        "title": "Self test",
        "size": {"w": 1280, "h": 720},
        "theme": {"colors": {"background": "#0B1020", "surface": "#161C32", "primary": "#6366F1",
                              "accent": "#F472B6", "text": "#F8FAFC", "textMuted": "#94A3B8",
                              "onPrimary": "#FFFFFF", "secondary": "#22D3EE"},
                  "fonts": {"heading": "Poppins", "body": "Inter"}},
        "brand": {"logoPlacement": "top-left", "logoScale": 1, "showPageNumbers": True, "footerText": "Self test"},
        "slides": [
            {"id": "s1", "layout": "cover",
             "background": {"type": "gradient", "gradient": ["token:background", "token:surface"], "gradientAngle": 145},
             "elements": [
                 {"id": "a", "type": "shape", "shape": "blob", "x": 820, "y": -120, "w": 620, "h": 620,
                  "gradient": ["token:primary", "token:accent"], "gradientAngle": 135, "opacity": 0.9, "z": 0},
                 {"id": "b", "type": "text", "text": "Gradient + shapes work", "role": "title",
                  "x": 88, "y": 260, "w": 760, "h": 200, "fontSize": 72, "fontWeight": 800, "color": "token:text", "z": 1},
             ]},
        ],
    }
    data = render_deck(deepcopy(sample))
    with open("selftest.pptx", "wb") as fh:
        fh.write(data)
    print(f"OK wrote selftest.pptx ({len(data)} bytes)")
