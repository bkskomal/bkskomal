"""
Build a 3rd workbook that highlights the differences between two Excel files.

The output is the UPDATED workbook with cell fills:
  green  = added   (empty in original)
  amber  = modified (different value)
  red    = removed (present in original, empty in updated — old value restored + noted)

Plus a "Changes Summary" sheet at the front. The originals are untouched.
"""
from __future__ import annotations

import io

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill

GREEN = PatternFill("solid", fgColor="C6EFCE")
AMBER = PatternFill("solid", fgColor="FFEB9C")
RED = PatternFill("solid", fgColor="FFC7CE")


def _s(v) -> str:
    return "" if v is None else str(v)


def build_highlighted(bytes_a: bytes, bytes_b: bytes) -> bytes:
    wa = load_workbook(io.BytesIO(bytes_a), data_only=True)
    out = load_workbook(io.BytesIO(bytes_b))  # updated workbook = the base for output

    summary: list[tuple[str, int, int, int, str]] = []

    for ws in out.worksheets:
        name = ws.title
        if name not in wa.sheetnames:
            # brand-new sheet: tint every non-empty cell green
            n = 0
            for row in ws.iter_rows():
                for cell in row:
                    if cell.value not in (None, ""):
                        cell.fill = GREEN
                        n += 1
            summary.append((name, n, 0, 0, "new tab"))
            continue

        wsa = wa[name]
        max_row = max(ws.max_row, wsa.max_row)
        max_col = max(ws.max_column, wsa.max_column)
        added = removed = modified = 0
        for r in range(1, max_row + 1):
            for c in range(1, max_col + 1):
                bv = ws.cell(row=r, column=c).value
                av = wsa.cell(row=r, column=c).value
                sb, sa = _s(bv), _s(av)
                if sb == sa:
                    continue
                cell = ws.cell(row=r, column=c)
                if sa == "":
                    cell.fill = GREEN
                    added += 1
                elif sb == "":
                    cell.value = av
                    cell.fill = RED
                    cell.comment = Comment(f"Removed (was: {av})", "OATIGenie")
                    removed += 1
                else:
                    cell.fill = AMBER
                    cell.comment = Comment(f"Was: {av}", "OATIGenie")
                    modified += 1
        summary.append((name, added, removed, modified, "changed" if (added or removed or modified) else "no changes"))

    # tabs that existed only in the original
    for name in wa.sheetnames:
        if name not in out.sheetnames:
            summary.append((name, 0, 0, 0, "tab removed"))

    _add_summary(out, summary)

    buf = io.BytesIO()
    out.save(buf)
    return buf.getvalue()


def _add_summary(out: Workbook, rows: list[tuple[str, int, int, int, str]]) -> None:
    ws = out.create_sheet("Changes Summary", 0)
    ws.sheet_properties.tabColor = "6366F1"
    headers = ["Tab", "Added", "Removed", "Modified", "Status"]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1A2B4A")
    for i, (name, a, rm, m, st) in enumerate(rows, start=2):
        ws.cell(row=i, column=1, value=name)
        ws.cell(row=i, column=2, value=a).fill = GREEN if a else PatternFill()
        ws.cell(row=i, column=3, value=rm).fill = RED if rm else PatternFill()
        ws.cell(row=i, column=4, value=m).fill = AMBER if m else PatternFill()
        ws.cell(row=i, column=5, value=st)
    for col, w in zip("ABCDE", (28, 10, 10, 10, 16)):
        ws.column_dimensions[col].width = w
