"""
Extract a Word (.docx) document into slide-ready content: headings become slides,
paragraphs/list-items become bullets or body, and embedded images are pulled out
as base64 data URLs (order-preserving, so each image lands on the right slide).
"""
from __future__ import annotations

import base64
import io

from docx import Document
from docx.oxml.ns import qn


def _para_images(p, doc) -> list[str]:
    urls: list[str] = []
    for blip in p._p.findall(".//" + qn("a:blip")):
        rid = blip.get(qn("r:embed")) or blip.get(qn("r:link"))
        if not rid:
            continue
        try:
            part = doc.part.related_parts[rid]
            b64 = base64.b64encode(part.blob).decode("ascii")
            urls.append(f"data:{part.content_type};base64,{b64}")
        except Exception:
            continue
    return urls


def _is_list(p) -> bool:
    pPr = p._p.pPr
    return pPr is not None and pPr.numPr is not None


def extract_docx(data: bytes) -> dict:
    doc = Document(io.BytesIO(data))
    title = (doc.core_properties.title or "").strip()

    slides: list[dict] = []
    cur: dict | None = None

    def start(t: str) -> None:
        nonlocal cur
        cur = {"title": (t or "Slide").strip(), "bullets": [], "body": [], "images": []}
        slides.append(cur)

    for p in doc.paragraphs:
        text = p.text.strip()
        imgs = _para_images(p, doc)
        style = (p.style.name if p.style else "") or ""
        is_heading = style.startswith("Heading") or style == "Title"

        if is_heading and text:
            start(text)
            if not title:
                title = text
            if imgs:
                cur["images"].extend(imgs)
            continue

        if cur is None:
            start(title or "Imported Document")
        if imgs:
            cur["images"].extend(imgs)
        if not text:
            continue
        if _is_list(p) or len(text) <= 160:
            cur["bullets"].append(text)
        else:
            cur["body"].append(text)

    out = []
    for s in slides:
        body = " ".join(s["body"]).strip()
        out.append({
            "title": s["title"],
            "bullets": s["bullets"][:8],
            "body": (body[:600] or None),
            "images": s["images"][:4],
        })
    if not out:
        out = [{"title": title or "Imported Document", "bullets": [], "body": None, "images": []}]

    return {"title": title or "Imported Document", "slides": out}
