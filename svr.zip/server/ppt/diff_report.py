"""
Build a merged "changes report" workbook from a context-aware diff (JSON from the
client's key-based comparison). Every changed row is listed with its status and
values, changed cells highlighted, plus a Summary sheet (with the AI narrative).
"""
from __future__ import annotations

import io
import re

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill

GREEN = PatternFill("solid", fgColor="C6EFCE")
AMBER = PatternFill("solid", fgColor="FFEB9C")
RED = PatternFill("solid", fgColor="FFC7CE")
HEAD = PatternFill("solid", fgColor="1A2B4A")
GREEN_H = PatternFill("solid", fgColor="2E7D32")
RED_H = PatternFill("solid", fgColor="B71C1C")


def _safe_sheet(name: str, used: set[str]) -> str:
    n = re.sub(r"[\[\]:*?/\\]", "-", str(name))[:28] or "Sheet"
    base, i = n, 1
    while n in used:
        n = f"{base[:26]}~{i}"
        i += 1
    used.add(n)
    return n


def build_report(payload: dict) -> bytes:
    result = payload.get("result", {})
    ai = payload.get("aiSummary", "")
    out = Workbook()
    used: set[str] = set()

    # ---- Summary sheet ----
    ws = out.active
    ws.title = _safe_sheet("Summary", used)
    ws.sheet_properties.tabColor = "6366F1"
    t = result.get("totals", {})
    ws["A1"] = f"Comparison: {result.get('a','A')} → {result.get('b','B')}"
    ws["A1"].font = Font(bold=True, size=13)
    ws["A2"] = f"{t.get('added',0)} rows added · {t.get('removed',0)} removed · {t.get('modified',0)} modified · {t.get('sheetsChanged',0)} tab(s) changed"
    ws["A2"].font = Font(color="555555")

    r = 4
    headers = ["Tab", "Key", "Added", "Removed", "Modified", "Cols +", "Cols −", "Note"]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=r, column=c, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = HEAD
    for sh in result.get("sheets", []):
        r += 1
        ws.cell(row=r, column=1, value=sh.get("name"))
        ws.cell(row=r, column=2, value=sh.get("keyColumn") or "row position")
        ws.cell(row=r, column=3, value=sh.get("added", 0)).fill = GREEN if sh.get("added") else PatternFill()
        ws.cell(row=r, column=4, value=sh.get("removed", 0)).fill = RED if sh.get("removed") else PatternFill()
        ws.cell(row=r, column=5, value=sh.get("modified", 0)).fill = AMBER if sh.get("modified") else PatternFill()
        ws.cell(row=r, column=6, value=", ".join(sh.get("addedCols", [])))
        ws.cell(row=r, column=7, value=", ".join(sh.get("removedCols", [])))
        note = ws.cell(row=r, column=8, value=sh.get("note") or "")
        note.alignment = Alignment(wrap_text=True)
        if sh.get("note") and not sh.get("keyUnique", True):
            note.font = Font(color="B45309")
    for col, w in zip("ABCDEFGH", (26, 16, 9, 9, 10, 18, 18, 40)):
        ws.column_dimensions[col].width = w

    if ai:
        r += 2
        ws.cell(row=r, column=1, value="AI summary").font = Font(bold=True)
        for line in str(ai).splitlines():
            r += 1
            cell = ws.cell(row=r, column=1, value=line)
            cell.alignment = Alignment(wrap_text=True)

    # ---- per-tab change sheets ----
    for sh in result.get("sheets", []):
        if sh.get("status") == "same" or not sh.get("rows"):
            continue
        cols = sh.get("headers", [])
        key = sh.get("keyColumn") or "Row"
        wss = out.create_sheet(_safe_sheet(sh.get("name", "Sheet"), used))
        header = ["Change", key] + cols
        for c, h in enumerate(header, start=1):
            cell = wss.cell(row=1, column=c, value=h)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = GREEN_H if h in sh.get("addedCols", []) else RED_H if h in sh.get("removedCols", []) else HEAD
        rownum = 2
        for row in sh.get("rows", []):
            typ = row.get("type")
            vals = row.get("values", {})
            wss.cell(row=rownum, column=1, value=typ)
            wss.cell(row=rownum, column=2, value=row.get("key"))
            changed = {f.get("col"): f for f in row.get("fields", [])}
            for ci, col in enumerate(cols, start=3):
                cell = wss.cell(row=rownum, column=ci, value=vals.get(col, ""))
                if typ == "added":
                    cell.fill = GREEN
                elif typ == "removed":
                    cell.fill = RED
                elif col in changed:
                    cell.fill = AMBER
                    cell.comment = Comment(f"Was: {changed[col].get('old','')}", "OATIGenie")
            rownum += 1
        wss.column_dimensions["A"].width = 11
        wss.column_dimensions["B"].width = 16
        for i in range(len(cols)):
            wss.column_dimensions[chr(ord("C") + i) if i < 24 else "Z"].width = 18

    buf = io.BytesIO()
    out.save(buf)
    return buf.getvalue()
