"""Storage for Project Management: projects, members, notes, plus the reused
documents + chunks RAG tables (each chunk scoped to a PROJECT via its document's
`project` column). Vectors are float32 blobs; keyword search via FTS5.

Retrieval is always project-scoped: `load_vectors(project_id)` and
`keyword_search(query, project_id)` only ever surface chunks that belong to the
given project — whether they came from an uploaded file or an indexed note.
"""
from __future__ import annotations

import json
import re
import sqlite3
import time
from typing import Optional

import numpy as np

from config import PROJECTS_DB as DB_PATH, EMBED_DIM
from rag.models import Document, Chunk

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects(
  id TEXT PRIMARY KEY, name TEXT, description TEXT, product TEXT,
  status TEXT DEFAULT 'active', created_at REAL
);
CREATE TABLE IF NOT EXISTS members(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT, name TEXT, role TEXT, added_at REAL
);
CREATE TABLE IF NOT EXISTS notes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT, kind TEXT, title TEXT, body TEXT, date TEXT, created_at REAL,
  occurred_at TEXT
);
CREATE TABLE IF NOT EXISTS tasks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT, title TEXT, description TEXT, assignee TEXT,
  status TEXT DEFAULT 'todo', priority TEXT DEFAULT 'med', due_date TEXT,
  created_at REAL, source TEXT DEFAULT 'manual', source_note_id INTEGER,
  updated_at REAL
);
CREATE TABLE IF NOT EXISTS risks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT, text TEXT, status TEXT DEFAULT 'open',
  source_note_id INTEGER, created_at REAL
);
CREATE TABLE IF NOT EXISTS milestones(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT, title TEXT, due_date TEXT, status TEXT DEFAULT 'planned', created_at REAL
);
CREATE TABLE IF NOT EXISTS activity(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT, ts REAL, type TEXT, summary TEXT, ref_id TEXT
);
CREATE TABLE IF NOT EXISTS project_access(
  project_id TEXT, user TEXT, role TEXT, granted_at REAL,
  PRIMARY KEY(project_id, user)
);
CREATE TABLE IF NOT EXISTS connectors(
  project_id TEXT, type TEXT, config_json TEXT, enabled INTEGER DEFAULT 1,
  created_at REAL, updated_at REAL,
  PRIMARY KEY(project_id, type)
);
CREATE TABLE IF NOT EXISTS sync_runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT, type TEXT, status TEXT, detail TEXT,
  created INTEGER DEFAULT 0, updated INTEGER DEFAULT 0, ts REAL
);
CREATE TABLE IF NOT EXISTS feed_tokens(
  token TEXT PRIMARY KEY, project_id TEXT, created_by TEXT, created_at REAL
);
CREATE TABLE IF NOT EXISTS notif_seen(
  project_id TEXT, user TEXT, seen_ts REAL,
  PRIMARY KEY(project_id, user)
);
CREATE INDEX IF NOT EXISTS idx_sync_runs_proj ON sync_runs(project_id, type);
CREATE INDEX IF NOT EXISTS idx_feed_tokens_proj ON feed_tokens(project_id);
CREATE INDEX IF NOT EXISTS idx_members_proj ON members(project_id);
CREATE INDEX IF NOT EXISTS idx_notes_proj ON notes(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_proj ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_milestones_proj ON milestones(project_id);
CREATE INDEX IF NOT EXISTS idx_activity_proj ON activity(project_id);
CREATE INDEX IF NOT EXISTS idx_risks_proj ON risks(project_id);

CREATE TABLE IF NOT EXISTS documents(
  doc_id TEXT PRIMARY KEY, title TEXT, doc_type TEXT, path TEXT,
  project TEXT, sha256 TEXT, mtime REAL, unit_count INTEGER, indexed_at REAL,
  stored_path TEXT, acl TEXT DEFAULT '["public"]'
);
CREATE TABLE IF NOT EXISTS chunks(
  chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
  doc_id TEXT, ord INTEGER, text TEXT, heading_context TEXT,
  token_est INTEGER, locator_json TEXT, embedding BLOB
);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(doc_id);
CREATE INDEX IF NOT EXISTS idx_documents_project ON documents(project);
"""


def _fts_query(q: str) -> Optional[str]:
    toks = [t for t in re.findall(r"[A-Za-z0-9]+", q.lower()) if len(t) > 1][:24]
    return " OR ".join(f'"{t}"' for t in toks) if toks else None


class Store:
    def __init__(self, db_path: str = DB_PATH):
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)
        self._migrate_notes_occurred_at()
        self._migrate_task_updated_at()
        self._migrate_task_external()
        self._has_fts = self._init_fts()
        # vector cache keyed by project_id ("" = all); invalidated on any chunk write
        self._vec_cache: dict[str, tuple] = {}

    def _migrate_notes_occurred_at(self) -> None:
        """Ensure notes.occurred_at exists (precise ISO datetime the timeline sorts by).
        Adds the column for pre-existing DBs and backfills it from each row's `date`
        (at noon) or, failing that, its `created_at` epoch."""
        import datetime
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(notes)")}
        if "occurred_at" not in cols:
            self.db.execute("ALTER TABLE notes ADD COLUMN occurred_at TEXT")
        # backfill any row missing a precise timestamp
        rows = self.db.execute(
            "SELECT id, date, created_at FROM notes "
            "WHERE occurred_at IS NULL OR occurred_at=''").fetchall()
        for r in rows:
            occ = self._backfill_occurred_at(r["date"], r["created_at"])
            self.db.execute("UPDATE notes SET occurred_at=? WHERE id=?", (occ, r["id"]))
        if rows:
            self.db.commit()

    @staticmethod
    def _backfill_occurred_at(date: str, created_at) -> str:
        import datetime
        date = (date or "").strip()
        if len(date) >= 10:
            # a bare date -> anchor at local noon so it lands on the right day
            return f"{date[:10]}T12:00:00"
        try:
            return datetime.datetime.fromtimestamp(float(created_at)).replace(
                microsecond=0).isoformat()
        except (TypeError, ValueError):
            return datetime.datetime.now().replace(microsecond=0).isoformat()

    def _migrate_task_updated_at(self) -> None:
        """Ensure tasks.updated_at exists (epoch of the last change). Powers the
        'stale task' signal in project_health. Backfills from created_at."""
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(tasks)")}
        if "updated_at" not in cols:
            self.db.execute("ALTER TABLE tasks ADD COLUMN updated_at REAL")
            self.db.execute("UPDATE tasks SET updated_at=created_at WHERE updated_at IS NULL")
            self.db.commit()

    def _migrate_task_external(self) -> None:
        """Ensure tasks.source_url + tasks.ext_key exist. These let an external
        connector (e.g. GitHub) link a task back to its origin URL and hold a stable
        external identity ('github:owner/repo#12') for idempotent re-sync."""
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(tasks)")}
        changed = False
        if "source_url" not in cols:
            self.db.execute("ALTER TABLE tasks ADD COLUMN source_url TEXT")
            changed = True
        if "ext_key" not in cols:
            self.db.execute("ALTER TABLE tasks ADD COLUMN ext_key TEXT")
            changed = True
        if changed:
            self.db.execute("CREATE INDEX IF NOT EXISTS idx_tasks_extkey ON tasks(project_id, ext_key)")
            self.db.commit()

    def _init_fts(self) -> bool:
        try:
            self.db.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(text, heading_context, chunk_id UNINDEXED)"
            )
            self.db.commit()
            return True
        except sqlite3.OperationalError:
            return False

    # ================================================================ projects
    def create_project(self, pid: str, name: str, description: str = "", product: str = "",
                        status: str = "active") -> dict:
        self.db.execute(
            "INSERT INTO projects(id,name,description,product,status,created_at) VALUES(?,?,?,?,?,?)",
            (pid, name, description, product, status, time.time()),
        )
        self.db.commit()
        return self.get_project(pid)

    def get_project(self, pid: str) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["member_count"] = self.db.execute(
            "SELECT COUNT(*) c FROM members WHERE project_id=?", (pid,)).fetchone()["c"]
        d["note_count"] = self.db.execute(
            "SELECT COUNT(*) c FROM notes WHERE project_id=?", (pid,)).fetchone()["c"]
        d["document_count"] = self.db.execute(
            "SELECT COUNT(*) c FROM documents WHERE project=? AND doc_type!='note'", (pid,)).fetchone()["c"]
        d["health"] = self.project_health(pid)
        return d

    def list_projects(self) -> list[dict]:
        rows = self.db.execute("SELECT id FROM projects ORDER BY created_at DESC").fetchall()
        return [self.get_project(r["id"]) for r in rows]

    def delete_project(self, pid: str) -> None:
        # drop all indexed sources (files + notes) for this project, then its rows
        for r in self.db.execute("SELECT doc_id FROM documents WHERE project=?", (pid,)).fetchall():
            self.delete_document(r["doc_id"])
        self.db.execute("DELETE FROM members WHERE project_id=?", (pid,))
        self.db.execute("DELETE FROM notes WHERE project_id=?", (pid,))
        self.db.execute("DELETE FROM projects WHERE id=?", (pid,))
        self.db.commit()

    # ================================================================ access control (RBAC)
    def grant_access(self, pid: str, user: str, role: str) -> dict:
        self.db.execute(
            "INSERT OR REPLACE INTO project_access(project_id,user,role,granted_at) VALUES(?,?,?,?)",
            (pid, user, role, time.time()),
        )
        self.db.commit()
        return {"project_id": pid, "user": user, "role": role}

    def revoke_access(self, pid: str, user: str) -> None:
        self.db.execute("DELETE FROM project_access WHERE project_id=? AND user=?", (pid, user))
        self.db.commit()

    def get_role(self, pid: str, user: str) -> Optional[str]:
        row = self.db.execute(
            "SELECT role FROM project_access WHERE project_id=? AND user=?", (pid, user)).fetchone()
        return row["role"] if row else None

    def list_access(self, pid: str) -> list[dict]:
        return [dict(r) for r in self.db.execute(
            "SELECT project_id,user,role,granted_at FROM project_access WHERE project_id=? "
            "ORDER BY granted_at", (pid,))]

    def projects_for_user(self, user: str) -> set:
        return {r["project_id"] for r in self.db.execute(
            "SELECT project_id FROM project_access WHERE user=?", (user,))}

    # ================================================================ members
    def add_member(self, pid: str, name: str, role: str = "") -> dict:
        cur = self.db.execute(
            "INSERT INTO members(project_id,name,role,added_at) VALUES(?,?,?,?)",
            (pid, name, role, time.time()),
        )
        self.db.commit()
        return {"id": cur.lastrowid, "project_id": pid, "name": name, "role": role}

    def list_members(self, pid: str) -> list[dict]:
        return [dict(r) for r in self.db.execute(
            "SELECT * FROM members WHERE project_id=? ORDER BY added_at", (pid,))]

    # ================================================================ notes
    def add_note(self, pid: str, kind: str, title: str, body: str, date: str = "",
                 occurred_at: str = "") -> dict:
        import datetime
        occurred_at = (occurred_at or "").strip()
        if not occurred_at:
            occurred_at = datetime.datetime.now().replace(microsecond=0).isoformat()
        # keep the legacy `date` column in sync (the day the note occurred)
        if not date:
            date = occurred_at[:10]
        cur = self.db.execute(
            "INSERT INTO notes(project_id,kind,title,body,date,created_at,occurred_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (pid, kind, title, body, date, time.time(), occurred_at),
        )
        self.db.commit()
        return self.get_note(cur.lastrowid)

    def get_note(self, note_id: int) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM notes WHERE id=?", (note_id,)).fetchone()
        return dict(row) if row else None

    def list_notes(self, pid: str) -> list[dict]:
        return [dict(r) for r in self.db.execute(
            "SELECT * FROM notes WHERE project_id=? "
            "ORDER BY occurred_at DESC, created_at DESC", (pid,))]

    # ================================================================ tasks
    def add_task(self, pid: str, title: str, description: str = "", assignee: str = "",
                 status: str = "todo", priority: str = "med", due_date: str = "",
                 source: str = "manual", source_note_id: Optional[int] = None,
                 source_url: str = "", ext_key: str = "") -> dict:
        now = time.time()
        cur = self.db.execute(
            """INSERT INTO tasks(project_id,title,description,assignee,status,priority,
                                 due_date,created_at,source,source_note_id,updated_at,
                                 source_url,ext_key)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (pid, title, description, assignee, status, priority, due_date, now,
             source, source_note_id, now, source_url or "", ext_key or ""),
        )
        self.db.commit()
        return self.get_task(cur.lastrowid)

    def get_task_by_ext_key(self, pid: str, ext_key: str) -> Optional[dict]:
        if not ext_key:
            return None
        row = self.db.execute(
            "SELECT * FROM tasks WHERE project_id=? AND ext_key=?", (pid, ext_key)).fetchone()
        return dict(row) if row else None

    def upsert_external_task(self, pid: str, ext_key: str, fields: dict, source: str) -> tuple[dict, bool]:
        """Create-or-update a task keyed by its stable external identity `ext_key`.
        Returns (task, created?). Connectors (e.g. GitHub) use this for idempotent sync:
        re-running updates the same task instead of duplicating it."""
        existing = self.get_task_by_ext_key(pid, ext_key)
        title = str(fields.get("title") or "").strip() or "(untitled)"
        desc = str(fields.get("description") or "")
        assignee = str(fields.get("assignee") or "")
        status = str(fields.get("status") or "todo")
        priority = str(fields.get("priority") or "med")
        due = str(fields.get("due_date") or "")
        url = str(fields.get("source_url") or "")
        if existing:
            self.db.execute(
                """UPDATE tasks SET title=?, description=?, assignee=?, status=?, priority=?,
                          due_date=?, source_url=?, updated_at=? WHERE id=?""",
                (title, desc, assignee, status, priority, due, url, time.time(), existing["id"]))
            self.db.commit()
            return self.get_task(existing["id"]), False
        t = self.add_task(pid, title=title, description=desc, assignee=assignee, status=status,
                          priority=priority, due_date=due, source=source, source_url=url, ext_key=ext_key)
        return t, True

    def get_task(self, task_id: int) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        return dict(row) if row else None

    def list_tasks(self, pid: str, status: str = "", assignee: str = "") -> list[dict]:
        sql = "SELECT * FROM tasks WHERE project_id=?"
        args: list = [pid]
        if status:
            sql += " AND status=?"; args.append(status)
        if assignee:
            sql += " AND assignee=?"; args.append(assignee)
        sql += " ORDER BY created_at DESC"
        return [dict(r) for r in self.db.execute(sql, args)]

    def update_task(self, task_id: int, fields: dict) -> Optional[dict]:
        allowed = {"title", "description", "assignee", "status", "priority", "due_date"}
        sets = {k: v for k, v in fields.items() if k in allowed}
        if sets:
            cols = ", ".join(f"{k}=?" for k in sets) + ", updated_at=?"
            self.db.execute(f"UPDATE tasks SET {cols} WHERE id=?",
                            (*sets.values(), time.time(), task_id))
            self.db.commit()
        return self.get_task(task_id)

    def delete_task(self, task_id: int) -> None:
        self.db.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        self.db.commit()

    # ================================================================ milestones
    def add_milestone(self, pid: str, title: str, due_date: str = "", status: str = "planned") -> dict:
        cur = self.db.execute(
            "INSERT INTO milestones(project_id,title,due_date,status,created_at) VALUES(?,?,?,?,?)",
            (pid, title, due_date, status, time.time()),
        )
        self.db.commit()
        return self.get_milestone(cur.lastrowid)

    def get_milestone(self, mid: int) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM milestones WHERE id=?", (mid,)).fetchone()
        return dict(row) if row else None

    def list_milestones(self, pid: str) -> list[dict]:
        return [dict(r) for r in self.db.execute(
            "SELECT * FROM milestones WHERE project_id=? ORDER BY due_date, created_at", (pid,))]

    def update_milestone(self, mid: int, fields: dict) -> Optional[dict]:
        allowed = {"title", "due_date", "status"}
        sets = {k: v for k, v in fields.items() if k in allowed}
        if sets:
            cols = ", ".join(f"{k}=?" for k in sets)
            self.db.execute(f"UPDATE milestones SET {cols} WHERE id=?", (*sets.values(), mid))
            self.db.commit()
        return self.get_milestone(mid)

    def delete_milestone(self, mid: int) -> None:
        self.db.execute("DELETE FROM milestones WHERE id=?", (mid,))
        self.db.commit()

    # ================================================================ risks
    def add_risk(self, pid: str, text: str, source_note_id: Optional[int] = None) -> Optional[dict]:
        """Record an open risk for the project. Idempotent per (project, text) so
        re-extracting the same note doesn't pile up duplicates."""
        t = (text or "").strip()
        if not t:
            return None
        row = self.db.execute(
            "SELECT id FROM risks WHERE project_id=? AND lower(text)=lower(?)", (pid, t)).fetchone()
        if row:
            return self.get_risk(row["id"])
        cur = self.db.execute(
            "INSERT INTO risks(project_id,text,status,source_note_id,created_at) VALUES(?,?,?,?,?)",
            (pid, t, "open", source_note_id, time.time()))
        self.db.commit()
        return self.get_risk(cur.lastrowid)

    def get_risk(self, rid: int) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM risks WHERE id=?", (rid,)).fetchone()
        return dict(row) if row else None

    def list_risks(self, pid: str, status: str = "") -> list[dict]:
        sql = "SELECT * FROM risks WHERE project_id=?"
        args: list = [pid]
        if status:
            sql += " AND status=?"; args.append(status)
        sql += " ORDER BY created_at DESC"
        return [dict(r) for r in self.db.execute(sql, args)]

    def resolve_risk(self, rid: int) -> Optional[dict]:
        self.db.execute("UPDATE risks SET status='resolved' WHERE id=?", (rid,))
        self.db.commit()
        return self.get_risk(rid)

    # ================================================================ activity + health
    def log_activity(self, pid: str, type_: str, summary: str, ref_id: str = "") -> None:
        self.db.execute(
            "INSERT INTO activity(project_id,ts,type,summary,ref_id) VALUES(?,?,?,?,?)",
            (pid, time.time(), type_, summary, str(ref_id)),
        )
        self.db.commit()

    def list_activity(self, pid: str, limit: int = 100) -> list[dict]:
        return [dict(r) for r in self.db.execute(
            "SELECT * FROM activity WHERE project_id=? ORDER BY ts DESC LIMIT ?", (pid, int(limit)))]

    def project_health(self, pid: str) -> dict:
        """Proactive project health: task progress + a computed status
        (on-track | at-risk | off-track) derived from overdue tasks, stale tasks
        (todo/in_progress untouched for 7+ days), open risks, and milestone timing;
        plus an `attention` list of the specific items a lead should act on."""
        import datetime
        STALE_SECS = 7 * 86400
        now = time.time()
        today = datetime.date.today().isoformat()
        horizon14 = (datetime.date.today() + datetime.timedelta(days=14)).isoformat()

        tasks = self.list_tasks(pid)
        total = len(tasks)
        done = sum(1 for t in tasks if t["status"] == "done")
        overdue = 0
        overdue_ids: set = set()
        overdue_tasks: list = []
        stale_tasks: list = []
        upcoming: list = []
        for t in tasks:
            active = t["status"] != "done"
            if active and t.get("due_date"):
                if t["due_date"] < today:
                    overdue += 1
                    overdue_ids.add(t["id"])
                    overdue_tasks.append({"id": t["id"], "title": t["title"],
                                          "due_date": t["due_date"], "assignee": t.get("assignee") or ""})
                else:
                    upcoming.append({"title": t["title"], "due_date": t["due_date"],
                                     "assignee": t.get("assignee") or ""})
        # stale: still open, not already flagged overdue, and untouched for 7+ days
        for t in tasks:
            if t["status"] in ("todo", "in_progress") and t["id"] not in overdue_ids:
                try:
                    upd = float(t.get("updated_at") or t.get("created_at") or now)
                except (TypeError, ValueError):
                    upd = now
                if now - upd >= STALE_SECS:
                    stale_tasks.append({"id": t["id"], "title": t["title"],
                                        "assignee": t.get("assignee") or "", "status": t["status"],
                                        "stale_days": int((now - upd) // 86400)})
        upcoming.sort(key=lambda x: x["due_date"])

        ms = self.list_milestones(pid)
        overdue_ms = 0
        milestones_due: list = []
        for m in ms:
            if m["status"] != "done" and m.get("due_date"):
                if m["due_date"] < today:
                    overdue_ms += 1
                    milestones_due.append({"id": m["id"], "title": m["title"],
                                           "due_date": m["due_date"], "overdue": True})
                elif m["due_date"] <= horizon14:
                    milestones_due.append({"id": m["id"], "title": m["title"],
                                           "due_date": m["due_date"], "overdue": False})
        milestones_due.sort(key=lambda x: x["due_date"])

        open_risks = len(self.list_risks(pid, status="open"))
        stale = len(stale_tasks)

        # ---- status rollup ----
        reasons: list = []
        if overdue:
            reasons.append(f"{overdue} overdue task{'s' if overdue != 1 else ''}")
        if overdue_ms:
            reasons.append(f"{overdue_ms} overdue milestone{'s' if overdue_ms != 1 else ''}")
        if stale:
            reasons.append(f"{stale} stale task{'s' if stale != 1 else ''}")
        if open_risks:
            reasons.append(f"{open_risks} open risk{'s' if open_risks != 1 else ''}")
        if overdue_ms or overdue >= 3 or (overdue >= 1 and stale >= 3):
            status = "off-track"
        elif overdue >= 1 or stale >= 2 or open_risks >= 1 or any(not d["overdue"] for d in milestones_due):
            status = "at-risk"
        else:
            status = "on-track"

        # ---- unified, click-navigable attention list ----
        attention: list = []
        for t in overdue_tasks:
            attention.append({"kind": "overdue_task", "id": t["id"], "title": t["title"],
                              "due_date": t["due_date"], "assignee": t["assignee"], "tab": "tasks"})
        for t in stale_tasks:
            attention.append({"kind": "stale_task", "id": t["id"], "title": t["title"],
                              "assignee": t["assignee"], "status": t["status"],
                              "stale_days": t["stale_days"], "tab": "tasks"})
        for m in milestones_due:
            attention.append({"kind": "milestone_due", "id": m["id"], "title": m["title"],
                              "due_date": m["due_date"], "overdue": m["overdue"], "tab": "tasks"})

        return {
            "tasks_total": total, "tasks_done": done,
            "pct_done": round(100 * done / total) if total else 0,
            "overdue": overdue,
            "in_progress": sum(1 for t in tasks if t["status"] == "in_progress"),
            "todo": sum(1 for t in tasks if t["status"] == "todo"),
            "milestones_total": len(ms),
            "milestones_done": sum(1 for m in ms if m["status"] == "done"),
            "upcoming_due": upcoming[:5],
            # proactive-health additions
            "status": status,
            "status_reasons": reasons,
            "stale": stale,
            "open_risks": open_risks,
            "overdue_milestones": overdue_ms,
            "milestones_due": milestones_due,
            "attention": attention,
        }

    # ================================================================ documents
    def get_document(self, doc_id: str) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM documents WHERE doc_id=?", (doc_id,)).fetchone()
        return dict(row) if row else None

    def upsert_document(self, doc: Document, stored_path: str = "") -> None:
        acl = doc.acl if getattr(doc, "acl", None) else ["public"]
        self.db.execute(
            """INSERT OR REPLACE INTO documents
               (doc_id,title,doc_type,path,project,sha256,mtime,unit_count,indexed_at,stored_path,acl)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (doc.doc_id, doc.title, doc.doc_type, doc.path, doc.project, doc.sha256,
             doc.mtime, doc.unit_count, doc.indexed_at, stored_path, json.dumps(acl)),
        )
        self.db.commit()

    def delete_document(self, doc_id: str) -> None:
        ids = [r["chunk_id"] for r in self.db.execute("SELECT chunk_id FROM chunks WHERE doc_id=?", (doc_id,))]
        self.db.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
        if self._has_fts and ids:
            self.db.executemany("DELETE FROM chunks_fts WHERE chunk_id=?", [(i,) for i in ids])
        self.db.execute("DELETE FROM documents WHERE doc_id=?", (doc_id,))
        self.db.commit()
        self._vec_cache = {}

    def list_documents(self, project: str = "", doc_type: str = "", query: str = "",
                        include_notes: bool = False) -> list[dict]:
        sql = "SELECT * FROM documents WHERE 1=1"
        args: list = []
        if project:
            sql += " AND project=?"; args.append(project)
        if doc_type:
            sql += " AND doc_type=?"; args.append(doc_type)
        elif not include_notes:
            sql += " AND doc_type!='note'"
        if query:
            sql += " AND title LIKE ?"; args.append(f"%{query}%")
        sql += " ORDER BY indexed_at DESC"
        return [dict(r) for r in self.db.execute(sql, args)]

    # ================================================================ chunks
    def add_chunks(self, chunks: list[Chunk], embeddings: list[np.ndarray]) -> None:
        cur = self.db.cursor()
        for c, e in zip(chunks, embeddings):
            cur.execute(
                """INSERT INTO chunks(doc_id,ord,text,heading_context,token_est,locator_json,embedding)
                   VALUES(?,?,?,?,?,?,?)""",
                (c.doc_id, c.ord, c.text, c.heading_context, c.token_est,
                 json.dumps(c.locator.to_dict()), np.asarray(e, dtype=np.float32).tobytes()),
            )
            if self._has_fts:
                cur.execute(
                    "INSERT INTO chunks_fts(text,heading_context,chunk_id) VALUES(?,?,?)",
                    (c.text, c.heading_context, cur.lastrowid),
                )
        self.db.commit()
        self._vec_cache = {}

    def get_chunk(self, chunk_id: int) -> Optional[dict]:
        row = self.db.execute(
            """SELECT c.chunk_id,c.doc_id,c.ord,c.text,c.heading_context,c.locator_json,
                      d.title AS doc_title, d.doc_type, d.project, d.path
               FROM chunks c JOIN documents d ON d.doc_id=c.doc_id WHERE c.chunk_id=?""",
            (chunk_id,),
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["locator"] = json.loads(d.pop("locator_json"))
        return d

    # ================================================================ retrieval (project-scoped)
    def load_vectors(self, project_id: str = ""):
        """(chunk_ids: int64[N], matrix: float32[N,dim]) for cosine search, restricted
        to chunks whose document belongs to `project_id`. Cached per project."""
        key = project_id or ""
        if key in self._vec_cache:
            return self._vec_cache[key]
        if project_id:
            rows = self.db.execute(
                "SELECT c.chunk_id, c.embedding FROM chunks c "
                "JOIN documents d ON d.doc_id=c.doc_id WHERE d.project=?", (project_id,)).fetchall()
        else:
            rows = self.db.execute("SELECT chunk_id, embedding FROM chunks").fetchall()
        if not rows:
            self._vec_cache[key] = (np.zeros(0, np.int64), np.zeros((0, EMBED_DIM), np.float32))
            return self._vec_cache[key]
        ids = np.fromiter((r["chunk_id"] for r in rows), dtype=np.int64, count=len(rows))
        mat = np.vstack([np.frombuffer(r["embedding"], dtype=np.float32) for r in rows])
        self._vec_cache[key] = (ids, mat)
        return self._vec_cache[key]

    def _project_chunk_ids(self, project_id: str) -> set:
        return {r["chunk_id"] for r in self.db.execute(
            "SELECT c.chunk_id FROM chunks c JOIN documents d ON d.doc_id=c.doc_id WHERE d.project=?",
            (project_id,))}

    def keyword_search(self, query: str, limit: int = 30, project_id: str = "") -> list[tuple[int, float]]:
        allowed = self._project_chunk_ids(project_id) if project_id else None
        if self._has_fts:
            fq = _fts_query(query)
            if not fq:
                return []
            try:
                rows = self.db.execute(
                    "SELECT chunk_id, bm25(chunks_fts) AS r FROM chunks_fts WHERE chunks_fts MATCH ? "
                    "ORDER BY r LIMIT ?", (fq, limit * 4 if allowed else limit),
                ).fetchall()
                out = [(int(r["chunk_id"]), -float(r["r"])) for r in rows]
                if allowed is not None:
                    out = [t for t in out if t[0] in allowed]
                return out[:limit]
            except sqlite3.OperationalError:
                pass
        like = f"%{query[:60]}%"
        rows = self.db.execute("SELECT chunk_id FROM chunks WHERE text LIKE ? LIMIT ?",
                               (like, limit * 4 if allowed else limit)).fetchall()
        out = [(int(r["chunk_id"]), 1.0) for r in rows]
        if allowed is not None:
            out = [t for t in out if t[0] in allowed]
        return out[:limit]

    # ================================================================ connectors (integrations)
    def set_connector(self, pid: str, type_: str, config: dict, enabled: bool = True) -> dict:
        now = time.time()
        existing = self.db.execute(
            "SELECT created_at FROM connectors WHERE project_id=? AND type=?", (pid, type_)).fetchone()
        created = existing["created_at"] if existing else now
        self.db.execute(
            """INSERT OR REPLACE INTO connectors(project_id,type,config_json,enabled,created_at,updated_at)
               VALUES(?,?,?,?,?,?)""",
            (pid, type_, json.dumps(config or {}), 1 if enabled else 0, created, now))
        self.db.commit()
        return self.get_connector(pid, type_)

    def get_connector(self, pid: str, type_: str) -> Optional[dict]:
        row = self.db.execute(
            "SELECT * FROM connectors WHERE project_id=? AND type=?", (pid, type_)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["enabled"] = bool(d["enabled"])
        try:
            d["config"] = json.loads(d.pop("config_json") or "{}")
        except (ValueError, TypeError):
            d["config"] = {}
        return d

    def list_connectors(self, pid: str) -> list[dict]:
        rows = self.db.execute(
            "SELECT type FROM connectors WHERE project_id=? ORDER BY type", (pid,)).fetchall()
        return [self.get_connector(pid, r["type"]) for r in rows]

    def delete_connector(self, pid: str, type_: str) -> None:
        self.db.execute("DELETE FROM connectors WHERE project_id=? AND type=?", (pid, type_))
        self.db.commit()

    def add_sync_run(self, pid: str, type_: str, status: str, detail: str,
                     created: int = 0, updated: int = 0) -> dict:
        cur = self.db.execute(
            """INSERT INTO sync_runs(project_id,type,status,detail,created,updated,ts)
               VALUES(?,?,?,?,?,?,?)""",
            (pid, type_, status, detail, int(created), int(updated), time.time()))
        self.db.commit()
        return dict(self.db.execute("SELECT * FROM sync_runs WHERE id=?", (cur.lastrowid,)).fetchone())

    def list_sync_runs(self, pid: str, type_: str = "", limit: int = 20) -> list[dict]:
        sql = "SELECT * FROM sync_runs WHERE project_id=?"
        args: list = [pid]
        if type_:
            sql += " AND type=?"; args.append(type_)
        sql += " ORDER BY ts DESC LIMIT ?"; args.append(int(limit))
        return [dict(r) for r in self.db.execute(sql, args)]

    def latest_sync_run(self, pid: str, type_: str) -> Optional[dict]:
        runs = self.list_sync_runs(pid, type_, limit=1)
        return runs[0] if runs else None

    # ================================================================ feed tokens (ICS subscribe)
    def get_feed_token(self, pid: str) -> Optional[dict]:
        row = self.db.execute(
            "SELECT * FROM feed_tokens WHERE project_id=? ORDER BY created_at DESC LIMIT 1",
            (pid,)).fetchone()
        return dict(row) if row else None

    def get_or_create_feed_token(self, pid: str, user: str = "") -> dict:
        existing = self.get_feed_token(pid)
        if existing:
            return existing
        return self.rotate_feed_token(pid, user)

    def rotate_feed_token(self, pid: str, user: str = "") -> dict:
        import secrets
        self.db.execute("DELETE FROM feed_tokens WHERE project_id=?", (pid,))
        token = secrets.token_urlsafe(24)
        self.db.execute(
            "INSERT INTO feed_tokens(token,project_id,created_by,created_at) VALUES(?,?,?,?)",
            (token, pid, user, time.time()))
        self.db.commit()
        return {"token": token, "project_id": pid, "created_by": user}

    def project_for_token(self, token: str) -> Optional[str]:
        if not token:
            return None
        row = self.db.execute(
            "SELECT project_id FROM feed_tokens WHERE token=?", (token,)).fetchone()
        return row["project_id"] if row else None

    # ================================================================ notifications (seen watermark)
    def get_notif_seen(self, pid: str, user: str) -> float:
        row = self.db.execute(
            "SELECT seen_ts FROM notif_seen WHERE project_id=? AND user=?", (pid, user)).fetchone()
        return float(row["seen_ts"]) if row else 0.0

    def set_notif_seen(self, pid: str, user: str, seen_ts: float) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO notif_seen(project_id,user,seen_ts) VALUES(?,?,?)",
            (pid, user, float(seen_ts)))
        self.db.commit()
