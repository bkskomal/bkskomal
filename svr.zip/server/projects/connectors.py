"""Integration/connector framework — a pluggable abstraction for external syncs.

A connector is described by a ConnectorSpec (id, human name, config field schema, and
capabilities) plus two callables: validate(config) and, when it supports pull-syncing,
sync(store, pid, config). Connectors register themselves into REGISTRY at import time,
so adding a new integration is: write a module with map/fetch/sync, then register a spec
here — nothing else in the app changes.

Config is persisted per-project via store.set_connector; secret fields are redacted on
read (public_config) so a token never leaves the server once saved. run_sync() executes
a connector and records a sync_run row (status/created/updated/detail) for the UI.

Capabilities:
  "sync"    — supports run_sync (pull external -> tasks)          e.g. github
  "export"  — emits an ICS subscribe feed                        e.g. calendar
  "import"  — ingests an uploaded artifact (.ics)                e.g. calendar
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

from . import github_conn


@dataclass
class ConnectorSpec:
    type: str
    name: str
    description: str
    capabilities: list[str]
    config_fields: list[dict] = field(default_factory=list)   # {key,label,type,required,secret,placeholder}
    validate: Optional[Callable[[dict], tuple]] = None
    sync: Optional[Callable] = None
    notes: str = ""

    def to_dict(self) -> dict:
        return {"type": self.type, "name": self.name, "description": self.description,
                "capabilities": self.capabilities, "config_fields": self.config_fields,
                "notes": self.notes}


REGISTRY: dict[str, ConnectorSpec] = {}


def register(spec: ConnectorSpec) -> None:
    REGISTRY[spec.type] = spec


def get_spec(type_: str) -> Optional[ConnectorSpec]:
    return REGISTRY.get(type_)


def list_specs() -> list[dict]:
    return [s.to_dict() for s in REGISTRY.values()]


def _secret_keys(spec: ConnectorSpec) -> set:
    return {f["key"] for f in spec.config_fields if f.get("secret")}


def public_config(type_: str, config: dict) -> dict:
    """Redact secret fields for client display: a saved secret shows as '••••••'."""
    spec = get_spec(type_)
    if not spec:
        return dict(config or {})
    secrets = _secret_keys(spec)
    out = {}
    for k, v in (config or {}).items():
        out[k] = ("••••••" if v else "") if k in secrets else v
    return out


def merge_config(type_: str, existing: dict, incoming: dict) -> dict:
    """Merge an incoming config over the stored one, preserving a saved secret when the
    client sends back the redaction placeholder (i.e. left the field untouched)."""
    spec = get_spec(type_)
    secrets = _secret_keys(spec) if spec else set()
    merged = dict(existing or {})
    for k, v in (incoming or {}).items():
        if k in secrets and v in ("••••••", "", None):
            continue   # keep the stored secret
        merged[k] = v
    return merged


def validate_config(type_: str, config: dict) -> tuple[bool, str]:
    spec = get_spec(type_)
    if not spec:
        return False, f"unknown connector '{type_}'"
    if spec.validate:
        return spec.validate(config)
    return True, ""


def run_sync(store, pid: str, type_: str) -> dict:
    """Execute a connector's sync and record a sync_run. Raises if the connector is not
    configured, not enabled, or does not support sync; records a 'failed' run on error."""
    spec = get_spec(type_)
    if not spec or "sync" not in spec.capabilities or not spec.sync:
        raise ValueError(f"connector '{type_}' does not support sync")
    conn = store.get_connector(pid, type_)
    if not conn:
        raise ValueError(f"connector '{type_}' is not configured for this project")
    if not conn.get("enabled", True):
        raise ValueError(f"connector '{type_}' is disabled")
    try:
        res = spec.sync(store, pid, conn["config"])
    except Exception as e:  # noqa: BLE001 — record the failure and re-raise a clean message
        store.add_sync_run(pid, type_, "failed", str(e)[:400], 0, 0)
        raise
    created = int(res.get("created", 0))
    updated = int(res.get("updated", 0))
    detail = res.get("detail") or f"{created} created, {updated} updated" + (
        f" (fetched {res['fetched']})" if "fetched" in res else "")
    run = store.add_sync_run(pid, type_, "ok", detail, created, updated)
    return {"run": run, "result": res}


# ---------------------------------------------------------------- built-in connectors
register(ConnectorSpec(
    type="github",
    name="GitHub Issues",
    description="Sync issues from a GitHub repository into project tasks (issue → task, "
                "state/labels → status/priority, link back to the issue).",
    capabilities=["sync"],
    config_fields=[
        {"key": "repo", "label": "Repository (owner/name)", "type": "text",
         "required": True, "placeholder": "octocat/hello-world"},
        {"key": "token", "label": "GitHub token (PAT)", "type": "text",
         "required": False, "secret": True, "placeholder": "ghp_… (or enable gh CLI)"},
        {"key": "state", "label": "Issue state", "type": "select",
         "options": ["all", "open", "closed"], "required": False},
        {"key": "use_gh", "label": "Use local gh CLI (if authenticated)", "type": "bool",
         "required": False},
    ],
    validate=github_conn.validate_config,
    sync=github_conn.sync,
    notes=("Live when the gh CLI is authenticated OR a token is supplied. "
           "Otherwise drop-in: the issue→task mapping is fully implemented and validated "
           "offline; it just needs credentials to fetch."),
))

register(ConnectorSpec(
    type="calendar",
    name="Calendar (ICS)",
    description="Subscribe to a live .ics feed of this project's dated tasks & milestones "
                "in any calendar app, and import events from an uploaded .ics.",
    capabilities=["export", "import"],
    config_fields=[],
    notes="Fully offline. Subscribe URL is token-gated; import maps all-day events to "
          "milestones and timed events to tasks.",
))
