"""projects tool package (mounted under /projects)."""
