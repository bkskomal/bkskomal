"""GitHub connector — sync repository issues into project tasks (one-way, issue -> task).

Live path (preferred): if the `gh` CLI is installed AND authenticated, we shell out to
it so no token has to be stored. Fallback path: the GitHub REST API behind a personal
access token stored in the connector config. Either way the MAPPING is identical and
lives in pure functions (map_issue / sync_issues) so it is unit-validatable offline
with a recorded payload — no network needed to prove the issue->task translation.

Idempotent: each issue is keyed by ext_key 'github:owner/repo#<number>', so re-syncing
updates the same task (status/labels/title) instead of creating duplicates, and links
back to the issue's html_url.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from typing import Optional

import httpx

API = "https://api.github.com"


# ---------------------------------------------------------------- config
def validate_config(config: dict) -> tuple[bool, str]:
    repo = (config or {}).get("repo", "").strip()
    if not repo or not re.match(r"^[\w.-]+/[\w.-]+$", repo):
        return False, "repo must be in 'owner/name' form"
    if not config.get("use_gh") and not (config.get("token") or "").strip():
        return False, "provide a GitHub token, or enable 'use_gh' if the gh CLI is authenticated"
    return True, ""


def gh_available() -> bool:
    return shutil.which("gh") is not None


def _gh_authed() -> bool:
    if not gh_available():
        return False
    try:
        r = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


# ---------------------------------------------------------------- mapping (pure)
def _priority_from_labels(labels: list[str]) -> str:
    low = {l.lower() for l in labels}
    for hi in ("priority: high", "priority:high", "p0", "p1", "critical", "urgent", "high priority", "high"):
        if hi in low:
            return "high"
    for lo in ("priority: low", "priority:low", "p3", "p4", "low priority", "low"):
        if lo in low:
            return "low"
    return "med"


def _status_from_issue(issue: dict, labels: list[str]) -> str:
    if (issue.get("state") or "").lower() == "closed":
        return "done"
    low = {l.lower() for l in labels}
    if low & {"in progress", "in-progress", "wip", "doing"}:
        return "in_progress"
    return "todo"


def _labels_of(issue: dict) -> list[str]:
    out = []
    for l in issue.get("labels", []) or []:
        if isinstance(l, dict):
            n = l.get("name")
        else:
            n = l
        if n:
            out.append(str(n))
    return out


def _assignee_of(issue: dict) -> str:
    a = issue.get("assignee")
    if isinstance(a, dict) and a.get("login"):
        return a["login"]
    for a in issue.get("assignees", []) or []:
        if isinstance(a, dict) and a.get("login"):
            return a["login"]
    return ""


def map_issue(issue: dict, repo: str) -> dict:
    """Translate one GitHub issue dict (REST or gh --json shape) into task fields +
    a stable ext_key. Returns None-free dict ready for store.upsert_external_task."""
    number = issue.get("number")
    labels = _labels_of(issue)
    url = issue.get("html_url") or issue.get("url") or f"https://github.com/{repo}/issues/{number}"
    body = (issue.get("body") or "").strip()
    desc = body[:1500]
    if desc:
        desc += "\n\n"
    desc += f"GitHub issue #{number}: {url}"
    return {
        "ext_key": f"github:{repo}#{number}",
        "title": issue.get("title") or f"Issue #{number}",
        "description": desc,
        "assignee": _assignee_of(issue),
        "status": _status_from_issue(issue, labels),
        "priority": _priority_from_labels(labels),
        "due_date": "",
        "source_url": url,
    }


def sync_issues(store, pid: str, repo: str, issues: list[dict]) -> dict:
    """Upsert a list of raw issue dicts into the project's tasks. Pure w.r.t. the
    network — the caller supplies the issues (fetched live OR a recorded payload)."""
    created = updated = 0
    items = []
    for issue in issues:
        if issue.get("pull_request"):   # the issues API also returns PRs; skip them
            continue
        fields = map_issue(issue, repo)
        ext_key = fields.pop("ext_key")
        task, was_created = store.upsert_external_task(pid, ext_key, fields, source="github")
        created += int(was_created)
        updated += int(not was_created)
        items.append({"number": issue.get("number"), "task_id": task["id"],
                      "title": task["title"], "status": task["status"], "created": was_created})
    return {"created": created, "updated": updated, "items": items, "repo": repo}


# ---------------------------------------------------------------- fetch (live)
def _fetch_via_gh(repo: str, state: str) -> list[dict]:
    cmd = ["gh", "issue", "list", "--repo", repo, "--state", state, "--limit", "200",
           "--json", "number,title,body,state,labels,assignees,url"]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        raise RuntimeError(f"gh issue list failed: {r.stderr.strip()[:300]}")
    data = json.loads(r.stdout or "[]")
    # normalize gh's 'url' to 'html_url' so mapping is shape-agnostic
    for it in data:
        it.setdefault("html_url", it.get("url"))
    return data


def _fetch_via_rest(repo: str, token: str, state: str) -> list[dict]:
    headers = {"Accept": "application/vnd.github+json",
               "Authorization": f"Bearer {token}",
               "X-GitHub-Api-Version": "2022-11-28"}
    out: list[dict] = []
    for page in range(1, 6):   # cap at 5 pages (500 issues)
        r = httpx.get(f"{API}/repos/{repo}/issues",
                      params={"state": state, "per_page": 100, "page": page},
                      headers=headers, timeout=30)
        r.raise_for_status()
        batch = r.json()
        if not batch:
            break
        out.extend(batch)
        if len(batch) < 100:
            break
    return out


def fetch_issues(config: dict) -> list[dict]:
    """Fetch issues live per config. Prefers the authenticated gh CLI, else REST+token."""
    repo = config["repo"].strip()
    state = config.get("state", "all")
    if config.get("use_gh"):
        if not _gh_authed():
            raise RuntimeError("use_gh is set but the gh CLI is not installed/authenticated")
        return _fetch_via_gh(repo, state)
    token = (config.get("token") or "").strip()
    if not token:
        raise RuntimeError("no GitHub token configured")
    return _fetch_via_rest(repo, token, state)


def sync(store, pid: str, config: dict) -> dict:
    """Connector entrypoint: fetch live issues, then upsert them into tasks."""
    ok, msg = validate_config(config)
    if not ok:
        raise ValueError(msg)
    issues = fetch_issues(config)
    res = sync_issues(store, pid, config["repo"].strip(), issues)
    res["fetched"] = len(issues)
    return res
