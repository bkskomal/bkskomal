"""Notifications feed — an in-app surface derived from data the project already tracks:
task assignments, due-soon / overdue tasks, and milestones landing soon. No new polling
infra; it reuses project_health() signals + the tasks table and a per-user 'seen'
watermark (notif_seen) to compute an unread count.

Each notification is click-navigable (carries a tab + ref id) and tagged `mine` when it
concerns the requesting user (assignee name or membership matching their id).
"""
from __future__ import annotations

import datetime

from .store import Store

DUE_SOON_DAYS = 3


def _matches_user(assignee: str, user: str, member_names: set) -> bool:
    """True when a task's free-text assignee refers to the requesting user id."""
    a = (assignee or "").strip().lower()
    u = (user or "").strip().lower()
    if not a:
        return False
    if a == u or u in a or a in u:
        return True
    return a in member_names and a == u


def build_feed(store: Store, pid: str, user: str) -> dict:
    """Return {notifications, unread, seen_ts}. Newest first. `unread` counts items with
    ts strictly newer than the user's seen watermark."""
    seen_ts = store.get_notif_seen(pid, user)
    today = datetime.date.today()
    today_s = today.isoformat()
    soon_s = (today + datetime.timedelta(days=DUE_SOON_DAYS)).isoformat()

    members = store.list_members(pid)
    member_names = {(m.get("name") or "").strip().lower() for m in members}
    tasks = store.list_tasks(pid)

    notifs: list[dict] = []
    for t in tasks:
        active = t.get("status") != "done"
        mine = _matches_user(t.get("assignee", ""), user, member_names)
        ts = float(t.get("updated_at") or t.get("created_at") or 0.0)
        due = t.get("due_date") or ""
        if active and due and due < today_s:
            notifs.append({
                "id": f"overdue-{t['id']}", "kind": "overdue", "ref_id": t["id"], "tab": "tasks",
                "title": t["title"], "detail": f"Overdue — was due {due}"
                + (f" · {t['assignee']}" if t.get("assignee") else ""),
                "ts": ts, "mine": mine, "severity": "high",
            })
        elif active and due and today_s <= due <= soon_s:
            notifs.append({
                "id": f"duesoon-{t['id']}", "kind": "due_soon", "ref_id": t["id"], "tab": "tasks",
                "title": t["title"], "detail": f"Due {due}"
                + (f" · {t['assignee']}" if t.get("assignee") else ""),
                "ts": ts, "mine": mine, "severity": "med",
            })
        if active and mine and t.get("assignee"):
            notifs.append({
                "id": f"assigned-{t['id']}", "kind": "assigned", "ref_id": t["id"], "tab": "tasks",
                "title": t["title"], "detail": f"Assigned to you ({t['assignee']})",
                "ts": ts, "mine": True, "severity": "med",
            })

    # milestones due soon / overdue (project-wide)
    for m in store.list_milestones(pid):
        if m.get("status") == "done" or not m.get("due_date"):
            continue
        due = m["due_date"]
        ts = float(m.get("created_at") or 0.0)
        if due < today_s:
            notifs.append({
                "id": f"ms-overdue-{m['id']}", "kind": "milestone_overdue", "ref_id": m["id"],
                "tab": "tasks", "title": m["title"], "detail": f"Milestone overdue — was due {due}",
                "ts": ts, "mine": False, "severity": "high"})
        elif due <= soon_s:
            notifs.append({
                "id": f"ms-soon-{m['id']}", "kind": "milestone_soon", "ref_id": m["id"],
                "tab": "tasks", "title": m["title"], "detail": f"Milestone due {due}",
                "ts": ts, "mine": False, "severity": "med"})

    # mine first, then higher severity, then most recent
    sev = {"high": 2, "med": 1, "low": 0}
    notifs.sort(key=lambda n: (n["mine"], sev.get(n["severity"], 0), n["ts"]), reverse=True)
    unread = sum(1 for n in notifs if n["ts"] > seen_ts)
    return {"notifications": notifs, "unread": unread, "seen_ts": seen_ts,
            "count": len(notifs)}
