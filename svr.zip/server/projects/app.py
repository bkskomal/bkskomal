"""Project Management API — AI-powered project workspace with role-based sharing.

Projects hold members, a notes timeline, tasks, milestones, and uploaded documents.
Every project has its own RAG index over BOTH its notes and its documents, powering a
grounded, project-scoped /ask with openable citations, plus two AI-native features:
note action-item extraction and a project status digest.

ACCESS CONTROL: identity comes from the `X-PM-User` header -> user id (no header =
"anonymous"); an SSO-pluggable seam mirroring Document Management's `X-DM-User`.
Each project has a `project_access` table of (user, role) with role in
read < write < admin. The creator is auto-granted admin. Every endpoint is gated:
reads need >= read, mutations need >= write, sharing/deletion need admin.

Run: uvicorn app:app --port 8930   (from service/)
"""
from __future__ import annotations

import os
import re
import tempfile
import uuid
from typing import Optional

import httpx
from fastapi import FastAPI, UploadFile, File, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel

from .store import Store
from .ingest import ingest_file, index_note
from .qa import ask as qa_ask
from .preview import ensure_preview
from . import pm
from . import connectors
from . import calendar_ics
from . import inbox
from . import notifications

app = FastAPI(title="Project Management")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
                   expose_headers=["*"])
store = Store()

_MIME = {
    "pdf": "application/pdf",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}

ROLE_RANK = {"read": 1, "write": 2, "admin": 3}
VALID_ROLES = set(ROLE_RANK)

# Suite single-sign-on: the Hub is the identity authority. We verify a Hub-minted
# token server-side and hand the frontend back the VERIFIED username. Identity on
# every subsequent request still rides the X-PM-User header (see _uid).
HUB_BASE = os.environ.get("HUB_BASE", "http://localhost:8900").rstrip("/")


def _slug(name: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", (name or "project").lower()).strip("-") or "project"
    return f"{base}-{uuid.uuid4().hex[:6]}"


def _uid(x_pm_user: Optional[str]) -> str:
    """Map the identity header to a user id. No header -> 'anonymous'."""
    return x_pm_user.strip() if x_pm_user and x_pm_user.strip() else "anonymous"


def _authz(pid: str, uid: str, need: str) -> tuple[dict, str]:
    """Load the project and enforce that `uid` holds at least role `need`.
    404 if the project doesn't exist; 403 if the caller lacks the required role."""
    p = store.get_project(pid)
    if not p:
        raise HTTPException(404, "project not found")
    role = store.get_role(pid, uid)
    if not role or ROLE_RANK[role] < ROLE_RANK[need]:
        raise HTTPException(403, f"requires '{need}' access to this project")
    p["my_role"] = role
    return p, role


# ------------------------------------------------------------------ schemas
class ProjectBody(BaseModel):
    name: str
    description: str = ""
    product: str = ""
    status: str = "active"


class MemberBody(BaseModel):
    name: str
    role: str = ""


class NoteBody(BaseModel):
    kind: str = "meeting"
    title: str = ""
    body: str
    date: str = ""
    occurred_at: str = ""   # ISO 8601 datetime the note occurred; defaults to now


class TaskBody(BaseModel):
    title: str
    description: str = ""
    assignee: str = ""
    status: str = "todo"
    priority: str = "med"
    due_date: str = ""
    source: str = "manual"
    source_note_id: int | None = None


class TaskUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    assignee: str | None = None
    status: str | None = None
    priority: str | None = None
    due_date: str | None = None


class MilestoneBody(BaseModel):
    title: str
    due_date: str = ""
    status: str = "planned"


class MilestoneUpdate(BaseModel):
    title: str | None = None
    due_date: str | None = None
    status: str | None = None


class AskBody(BaseModel):
    query: str
    k: int = 8


class ActBody(BaseModel):
    message: str


class PlanBody(BaseModel):
    goal: str = ""


class AccessBody(BaseModel):
    user: str
    role: str = "read"


class AccessDelBody(BaseModel):
    user: str


class ConnectorBody(BaseModel):
    config: dict = {}
    enabled: bool = True


class InboxBody(BaseModel):
    subject: str = ""
    body: str = ""
    sender: str = ""
    email: str = ""    # optional: a whole pasted email blob (parsed for subject/body/from)


@app.get("/health")
def health():
    return {"ok": True, "projects": len(store.list_projects())}


# ================================================================ suite SSO (consumer)
@app.get("/sso")
def sso(token: str):
    """Verify a Hub-minted SSO token and return the signed-in username.

    Consumer side of the suite SSO contract: OATIGenie opens PM with ?sso=<token>;
    the frontend calls here to resolve the VERIFIED username, then sends it as
    X-PM-User on every request as before. We never trust the token client-side —
    it's validated server-to-server against the Hub identity authority."""
    if not token or not token.strip():
        raise HTTPException(401, "missing token")
    try:
        r = httpx.get(f"{HUB_BASE}/api/sso/verify", params={"token": token}, timeout=5.0)
    except httpx.HTTPError:
        raise HTTPException(401, "sso verification unavailable")
    if r.status_code != 200:
        raise HTTPException(401, "invalid or expired token")
    username = (r.json() or {}).get("username")
    if not username:
        raise HTTPException(401, "invalid or expired token")
    return {"username": username}


# ================================================================ projects
@app.post("/projects")
def create_project(body: ProjectBody, x_pm_user: Optional[str] = Header(None)):
    uid = _uid(x_pm_user)
    pid = _slug(body.name)
    p = store.create_project(pid, body.name, body.description, body.product, body.status)
    store.grant_access(pid, uid, "admin")  # creator is admin
    store.log_activity(pid, "project_created", f"Project created by {uid}: {body.name}")
    p["my_role"] = "admin"
    return p


@app.get("/projects")
def list_projects(x_pm_user: Optional[str] = Header(None)):
    """Only the projects the caller has any access to, each tagged with their role."""
    uid = _uid(x_pm_user)
    allowed = store.projects_for_user(uid)
    out = []
    for p in store.list_projects():
        if p["id"] in allowed:
            p["my_role"] = store.get_role(p["id"], uid)
            out.append(p)
    return {"projects": out, "user": uid}


@app.get("/projects/{pid}")
def get_project(pid: str, x_pm_user: Optional[str] = Header(None)):
    p, _ = _authz(pid, _uid(x_pm_user), "read")
    return p


@app.delete("/projects/{pid}")
def delete_project(pid: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "admin")
    store.delete_project(pid)
    return {"ok": True}


# ================================================================ access control (RBAC)
@app.get("/projects/{pid}/access")
def list_access(pid: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"access": store.list_access(pid)}


@app.post("/projects/{pid}/access")
def grant_access(pid: str, body: AccessBody, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "admin")
    if body.role not in VALID_ROLES:
        raise HTTPException(400, f"role must be one of {sorted(VALID_ROLES)}")
    a = store.grant_access(pid, body.user, body.role)
    store.log_activity(pid, "access_granted", f"Shared with {body.user} as {body.role}")
    return a


@app.delete("/projects/{pid}/access")
def revoke_access(pid: str, body: AccessDelBody, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "admin")
    store.revoke_access(pid, body.user)
    store.log_activity(pid, "access_revoked", f"Revoked access for {body.user}")
    return {"ok": True}


# ================================================================ members
@app.post("/projects/{pid}/members")
def add_member(pid: str, body: MemberBody, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    m = store.add_member(pid, body.name, body.role)
    store.log_activity(pid, "member_added", f"Member added: {body.name}" + (f" ({body.role})" if body.role else ""))
    return m


@app.get("/projects/{pid}/members")
def list_members(pid: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"members": store.list_members(pid)}


# ================================================================ notes
@app.post("/projects/{pid}/notes")
def add_note(pid: str, body: NoteBody, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    note = store.add_note(pid, body.kind, body.title, body.body, body.date, body.occurred_at)
    idx = index_note(store, pid, note["id"], body.kind, body.title, body.body)
    store.log_activity(pid, "note_added",
                       f"{body.kind.capitalize()} note: {body.title or '(untitled)'}", ref_id=note["id"])
    return {**note, "indexed_chunks": idx.get("chunks", 0)}


@app.get("/projects/{pid}/notes")
def list_notes(pid: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"notes": store.list_notes(pid)}


@app.post("/projects/{pid}/notes/{note_id}/extract")
def extract_note_actions(pid: str, note_id: int, x_pm_user: Optional[str] = Header(None)):
    """AI feature 1 — extract action items + decisions + risks from a note."""
    _authz(pid, _uid(x_pm_user), "write")
    note = store.get_note(note_id)
    if not note or note["project_id"] != pid:
        raise HTTPException(404, "note not found")
    result = pm.extract_actions(note)
    # persist extracted risks into the risks store (idempotent) so proactive health
    # can factor open risks into the project status
    for r in result.get("risks", []):
        store.add_risk(pid, r, source_note_id=note_id)
    store.log_activity(pid, "note_extracted",
                       f"Extracted {len(result['action_items'])} actions / "
                       f"{len(result['decisions'])} decisions / {len(result['risks'])} risks "
                       f"from note: {note.get('title') or '(untitled)'}", ref_id=note_id)
    return result


# ================================================================ tasks
@app.post("/projects/{pid}/tasks")
def create_task(pid: str, body: TaskBody, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    t = store.add_task(pid, body.title, body.description, body.assignee, body.status,
                       body.priority, body.due_date, body.source, body.source_note_id)
    tag = " (from note)" if body.source == "extracted" else ""
    store.log_activity(pid, "task_created", f"Task created: {body.title}{tag}", ref_id=t["id"])
    return t


@app.get("/projects/{pid}/tasks")
def list_tasks(pid: str, status: str = "", assignee: str = "", x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"tasks": store.list_tasks(pid, status=status, assignee=assignee)}


@app.patch("/projects/{pid}/tasks/{task_id}")
def update_task(pid: str, task_id: int, body: TaskUpdate, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    before = store.get_task(task_id)
    if not before or before["project_id"] != pid:
        raise HTTPException(404, "task not found")
    fields = {k: v for k, v in body.model_dump().items() if v is not None}
    t = store.update_task(task_id, fields)
    if "status" in fields and fields["status"] != before["status"]:
        if fields["status"] == "done":
            store.log_activity(pid, "task_completed", f"Task completed: {t['title']}", ref_id=task_id)
        else:
            store.log_activity(pid, "task_updated", f"Task -> {fields['status']}: {t['title']}", ref_id=task_id)
    elif "assignee" in fields:
        store.log_activity(pid, "task_assigned", f"Task assigned to {fields['assignee']}: {t['title']}", ref_id=task_id)
    return t


@app.delete("/projects/{pid}/tasks/{task_id}")
def delete_task(pid: str, task_id: int, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    store.delete_task(task_id)
    return {"ok": True}


# ================================================================ milestones
@app.post("/projects/{pid}/milestones")
def create_milestone(pid: str, body: MilestoneBody, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    m = store.add_milestone(pid, body.title, body.due_date, body.status)
    store.log_activity(pid, "milestone_added", f"Milestone: {body.title}", ref_id=m["id"])
    return m


@app.get("/projects/{pid}/milestones")
def list_milestones(pid: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"milestones": store.list_milestones(pid)}


@app.patch("/projects/{pid}/milestones/{mid}")
def update_milestone(pid: str, mid: int, body: MilestoneUpdate, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    before = store.get_milestone(mid)
    if not before or before["project_id"] != pid:
        raise HTTPException(404, "milestone not found")
    fields = {k: v for k, v in body.model_dump().items() if v is not None}
    m = store.update_milestone(mid, fields)
    if fields.get("status") == "done" and before["status"] != "done":
        store.log_activity(pid, "milestone_reached", f"Milestone reached: {m['title']}", ref_id=mid)
    return m


@app.delete("/projects/{pid}/milestones/{mid}")
def delete_milestone(pid: str, mid: int, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    store.delete_milestone(mid)
    return {"ok": True}


# ================================================================ activity + health
@app.get("/projects/{pid}/activity")
def activity(pid: str, limit: int = 100, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"activity": store.list_activity(pid, limit=limit)}


@app.get("/projects/{pid}/health")
def health_stat(pid: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return store.project_health(pid)


@app.get("/projects/{pid}/insights")
def insights(pid: str, x_pm_user: Optional[str] = Header(None)):
    """Proactive health: computed status (on-track/at-risk/off-track) + the
    'attention needed' list (overdue tasks, stale tasks, milestones due <=14d)."""
    _authz(pid, _uid(x_pm_user), "read")
    return store.project_health(pid)


# ================================================================ documents
@app.post("/projects/{pid}/upload")
async def upload(pid: str, file: UploadFile = File(...), x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "write")
    suffix = os.path.splitext(file.filename or "")[1].lower()
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name
    try:
        title = os.path.splitext(os.path.basename(file.filename or "upload"))[0]
        res = ingest_file(store, tmp_path, project=pid, title=title)
        store.log_activity(pid, "document_uploaded", f"Document uploaded: {title} ({res['doc_type']})",
                           ref_id=res["doc_id"])
        return res
    finally:
        os.unlink(tmp_path)


@app.get("/projects/{pid}/documents")
def list_documents(pid: str, type: str = "", x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"documents": store.list_documents(project=pid, doc_type=type)}


# ================================================================ ask + digest
@app.post("/projects/{pid}/ask")
def ask(pid: str, body: AskBody, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return qa_ask(store, body.query, pid, k=body.k)


@app.post("/projects/{pid}/digest")
def digest(pid: str, x_pm_user: Optional[str] = Header(None)):
    """AI feature 2 — grounded exec status digest incl. task/milestone progress."""
    p, _ = _authz(pid, _uid(x_pm_user), "read")
    return pm.project_digest(store, p)


@app.post("/projects/{pid}/act")
def act(pid: str, body: ActBody, x_pm_user: Optional[str] = Header(None)):
    """AI feature 3 — agentic project chat. The model turns the instruction into a set
    of actions (create/assign/complete task, add note, add milestone) which we EXECUTE
    against the store, then confirm. Requires >= write."""
    p, _ = _authz(pid, _uid(x_pm_user), "write")
    result = pm.agentic_act(store, p, body.message)
    # log each applied change to the activity timeline (and index any agent-added note)
    for e in result["actions"]:
        if not e.get("ok"):
            continue
        typ, ref = e["type"], e.get("ref_id")
        if typ == "create_task":
            store.log_activity(pid, "task_created", f"Task created via chat: {e['task']['title']}", ref_id=ref)
        elif typ == "assign_task":
            store.log_activity(pid, "task_assigned", e["detail"], ref_id=ref)
        elif typ == "complete_task":
            store.log_activity(pid, "task_completed", e["detail"], ref_id=ref)
        elif typ == "add_milestone":
            store.log_activity(pid, "milestone_added", e["detail"], ref_id=ref)
        elif typ == "add_note":
            n = e.get("note") or {}
            if n:
                index_note(store, pid, n["id"], n.get("kind", "meeting"), n.get("title", ""), n.get("body", ""))
            store.log_activity(pid, "note_added", e["detail"], ref_id=ref)
    return result


@app.post("/projects/{pid}/plan")
def plan(pid: str, body: PlanBody, x_pm_user: Optional[str] = Header(None)):
    """AI feature 4 — draft a lightweight WBS (milestones + tasks) and insert it.
    Requires >= write."""
    p, _ = _authz(pid, _uid(x_pm_user), "write")
    result = pm.draft_plan(store, p, goal=body.goal)
    store.log_activity(pid, "plan_drafted",
                       f"AI drafted a plan: {result['milestones_created']} milestones, "
                       f"{result['tasks_created']} tasks")
    return result


# ================================================================ integrations / connectors
@app.get("/connectors")
def connector_catalog():
    """The static catalog of available connector types (framework registry)."""
    return {"connectors": connectors.list_specs()}


def _connector_view(pid: str, type_: str) -> dict:
    """A configured connector as the UI sees it: redacted config + latest run."""
    conn = store.get_connector(pid, type_)
    if not conn:
        return {}
    return {
        "type": conn["type"], "enabled": conn["enabled"],
        "config": connectors.public_config(type_, conn["config"]),
        "updated_at": conn["updated_at"],
        "latest_run": store.latest_sync_run(pid, type_),
    }


@app.get("/projects/{pid}/connectors")
def list_project_connectors(pid: str, x_pm_user: Optional[str] = Header(None)):
    """Catalog + this project's configured connectors (redacted). Read access."""
    _authz(pid, _uid(x_pm_user), "read")
    configured = {c["type"]: _connector_view(pid, c["type"]) for c in store.list_connectors(pid)}
    return {"catalog": connectors.list_specs(), "configured": configured}


@app.put("/projects/{pid}/connectors/{type_}")
def configure_connector(pid: str, type_: str, body: ConnectorBody,
                        x_pm_user: Optional[str] = Header(None)):
    """Create/update a connector's per-project config. ADMIN only. A saved secret is
    preserved when the client sends back the redaction placeholder."""
    _authz(pid, _uid(x_pm_user), "admin")
    if not connectors.get_spec(type_):
        raise HTTPException(404, f"unknown connector '{type_}'")
    existing = store.get_connector(pid, type_)
    merged = connectors.merge_config(type_, existing["config"] if existing else {}, body.config)
    ok, msg = connectors.validate_config(type_, merged)
    if not ok:
        raise HTTPException(400, msg)
    store.set_connector(pid, type_, merged, body.enabled)
    store.log_activity(pid, "connector_configured", f"Configured {type_} integration")
    return _connector_view(pid, type_)


@app.delete("/projects/{pid}/connectors/{type_}")
def remove_connector(pid: str, type_: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "admin")
    store.delete_connector(pid, type_)
    store.log_activity(pid, "connector_removed", f"Removed {type_} integration")
    return {"ok": True}


@app.post("/projects/{pid}/connectors/{type_}/sync")
def sync_connector(pid: str, type_: str, x_pm_user: Optional[str] = Header(None)):
    """Run a connector's sync (pull external -> tasks). WRITE access (it mutates tasks)."""
    _authz(pid, _uid(x_pm_user), "write")
    try:
        out = connectors.run_sync(store, pid, type_)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001 — surface live-fetch failures cleanly
        raise HTTPException(502, f"sync failed: {e}")
    res = out["result"]
    store.log_activity(pid, "connector_synced",
                       f"{type_} sync: {res.get('created', 0)} created, {res.get('updated', 0)} updated")
    return out


@app.get("/projects/{pid}/connectors/{type_}/runs")
def connector_runs(pid: str, type_: str, x_pm_user: Optional[str] = Header(None)):
    _authz(pid, _uid(x_pm_user), "read")
    return {"runs": store.list_sync_runs(pid, type_)}


# ================================================================ calendar (ICS)
@app.get("/projects/{pid}/calendar/subscription")
def calendar_subscription(pid: str, x_pm_user: Optional[str] = Header(None)):
    """The token-gated .ics subscribe URL for this project. Read access; the token
    itself grants read-only calendar access so it can be used by a calendar app."""
    _authz(pid, _uid(x_pm_user), "read")
    tok = store.get_or_create_feed_token(pid, _uid(x_pm_user))
    return {"token": tok["token"], "ics_path": f"/projects/{pid}/calendar.ics?token={tok['token']}"}


@app.post("/projects/{pid}/calendar/subscription/rotate")
def calendar_rotate(pid: str, x_pm_user: Optional[str] = Header(None)):
    """Rotate (invalidate + reissue) the calendar feed token. ADMIN only."""
    _authz(pid, _uid(x_pm_user), "admin")
    tok = store.rotate_feed_token(pid, _uid(x_pm_user))
    store.log_activity(pid, "calendar_token_rotated", "Rotated the calendar subscribe token")
    return {"token": tok["token"], "ics_path": f"/projects/{pid}/calendar.ics?token={tok['token']}"}


@app.get("/projects/{pid}/calendar.ics")
def calendar_ics_feed(pid: str, token: str = "", x_pm_user: Optional[str] = Header(None)):
    """Emit the project's tasks+milestones as a VCALENDAR. Authorized by EITHER a valid
    feed token (for calendar-app subscription, which cannot send headers) OR X-PM-User
    read access (for in-app fetches)."""
    authorized = False
    if token and store.project_for_token(token) == pid:
        authorized = True
    else:
        role = store.get_role(pid, _uid(x_pm_user))
        authorized = bool(role and ROLE_RANK[role] >= ROLE_RANK["read"])
    if not authorized:
        raise HTTPException(403, "a valid feed token or read access is required")
    p = store.get_project(pid)
    if not p:
        raise HTTPException(404, "project not found")
    ics = calendar_ics.build_calendar(p, store.list_tasks(pid), store.list_milestones(pid))
    return Response(content=ics, media_type="text/calendar; charset=utf-8",
                    headers={"Content-Disposition": f'inline; filename="{pid}.ics"'})


@app.post("/projects/{pid}/calendar/import")
async def calendar_import(pid: str, request: Request, x_pm_user: Optional[str] = Header(None)):
    """Import an .ics: create milestones (all-day events) and tasks (timed events).
    Accepts a multipart file upload, a JSON body {"ics": "..."}, or a raw text/calendar
    body. WRITE access."""
    _authz(pid, _uid(x_pm_user), "write")
    ctype = request.headers.get("content-type", "")
    text = ""
    if ctype.startswith("multipart/form-data"):
        form = await request.form()
        up = form.get("file")
        if up is not None and hasattr(up, "read"):
            text = (await up.read()).decode("utf-8", errors="replace")
        elif isinstance(form.get("ics"), str):
            text = form["ics"]
    elif ctype.startswith("application/json"):
        try:
            payload = await request.json()
        except (ValueError, TypeError):
            payload = {}
        text = str((payload or {}).get("ics") or "")
    else:
        text = (await request.body()).decode("utf-8", errors="replace")
    if not text.strip():
        raise HTTPException(400, "no ICS content provided")
    res = calendar_ics.import_events(store, pid, text)
    for t in res["tasks"]:
        store.log_activity(pid, "task_created", f"Task from calendar import: {t['title']}", ref_id=t["id"])
    for m in res["milestones"]:
        store.log_activity(pid, "milestone_added", f"Milestone from calendar import: {m['title']}", ref_id=m["id"])
    return res


# ================================================================ email-to-task ingest
@app.post("/projects/{pid}/inbox")
def inbox_ingest(pid: str, body: InboxBody, x_pm_user: Optional[str] = Header(None)):
    """Turn a posted email (subject/body/sender, or a pasted raw email) into a task via
    AI parsing (heuristic fallback offline). WRITE access."""
    _authz(pid, _uid(x_pm_user), "write")
    subject, bdy, sender = body.subject, body.body, body.sender
    if body.email and not (subject or bdy):
        subject, bdy, sender = _parse_raw_email(body.email)
    if not (subject.strip() or bdy.strip()):
        raise HTTPException(400, "provide a subject/body or a pasted email")
    res = inbox.email_to_task(store, pid, subject, bdy, sender=sender)
    store.log_activity(pid, "task_created",
                       f"Task from email ({res['via']}): {res['task']['title']}", ref_id=res["task"]["id"])
    return res


def _parse_raw_email(blob: str) -> tuple[str, str, str]:
    """Split a pasted raw email into (subject, body, from). Tolerant of header order."""
    subject = sender = ""
    lines = blob.replace("\r\n", "\n").split("\n")
    body_start = 0
    for i, ln in enumerate(lines):
        low = ln.lower()
        if low.startswith("subject:"):
            subject = ln.split(":", 1)[1].strip()
        elif low.startswith("from:"):
            sender = ln.split(":", 1)[1].strip()
        elif ln.strip() == "" and (subject or sender):
            body_start = i + 1
            break
    body = "\n".join(lines[body_start:]).strip() if body_start else blob.strip()
    return subject, body, sender


# ================================================================ notifications
@app.get("/projects/{pid}/notifications")
def get_notifications(pid: str, x_pm_user: Optional[str] = Header(None)):
    """In-app notifications for the caller: assignments, due-soon/overdue tasks and
    milestones, with an unread count vs the caller's seen watermark. Read access."""
    uid = _uid(x_pm_user)
    _authz(pid, uid, "read")
    return notifications.build_feed(store, pid, uid)


@app.post("/projects/{pid}/notifications/seen")
def mark_notifications_seen(pid: str, x_pm_user: Optional[str] = Header(None)):
    """Advance the caller's 'seen' watermark to now (clears the unread badge)."""
    import time
    uid = _uid(x_pm_user)
    _authz(pid, uid, "read")
    store.set_notif_seen(pid, uid, time.time())
    return {"ok": True}


# ================================================================ open / download source
def _doc_project(doc_id: str) -> Optional[dict]:
    return store.get_document(doc_id)


@app.get("/file/{doc_id}")
def file(doc_id: str, download: bool = False, x_pm_user: Optional[str] = Header(None)):
    d = store.get_document(doc_id)
    if not d:
        raise HTTPException(404, "document not found")
    _authz(d["project"], _uid(x_pm_user), "read")  # gate by the doc's project
    if d["doc_type"] == "note":
        raise HTTPException(400, "notes are viewed in the timeline, not as files")
    src = d.get("stored_path") or d.get("path")
    if not src or not os.path.exists(src):
        raise HTTPException(410, "source file missing")
    disp = "attachment" if download else "inline"
    return FileResponse(
        src, media_type=_MIME.get(d["doc_type"], "application/octet-stream"),
        filename=f"{d['title']}.{d['doc_type']}",
        headers={"Content-Disposition": f'{disp}; filename="{d["title"]}.{d["doc_type"]}"'},
    )


@app.get("/preview/{doc_id}")
def preview(doc_id: str, x_pm_user: Optional[str] = Header(None)):
    d = store.get_document(doc_id)
    if not d:
        raise HTTPException(404, "document not found")
    _authz(d["project"], _uid(x_pm_user), "read")
    if d["doc_type"] == "note":
        raise HTTPException(400, "notes have no PDF preview")
    src = d.get("stored_path") or d.get("path")
    pdf = ensure_preview(doc_id, src, d["doc_type"])
    if pdf:
        return FileResponse(pdf, media_type="application/pdf",
                            headers={"Content-Disposition": f'inline; filename="{d["title"]}.pdf"'})
    if src and os.path.exists(src):
        return FileResponse(src, media_type=_MIME.get(d["doc_type"], "application/octet-stream"))
    raise HTTPException(410, "source file missing")
