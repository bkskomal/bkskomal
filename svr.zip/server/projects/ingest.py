"""Ingestion for Project Management: file/note -> anchored chunks -> embeddings ->
store, all scoped to a PROJECT. Uploaded files keep a copy of the original bytes so
the workspace can re-open / download them. A note is indexed as a mini-document
(doc_type='note') so it flows through the exact same project-scoped retrieval."""
from __future__ import annotations

import hashlib
import os
import shutil
import time

from config import PROJECTS_FILES as FILES_DIR
from rag.extract import extract, extract_note, doc_type_of
from rag.embed import embed_passages
from rag.models import Document
from .store import Store

SUPPORTED = {".pdf", ".pptx", ".docx"}


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def ingest_file(store: Store, path: str, project: str, title: str | None = None) -> dict:
    """Ingest an uploaded file INTO a project. doc_id is scoped by project so the same
    file can live independently in different projects."""
    dt = doc_type_of(path)
    if not dt:
        raise ValueError(f"unsupported file type: {path}")
    sha = _sha256(path)
    did = f"{project}-{sha[:12]}"

    chunks, units = extract(path, did)
    embeddings = embed_passages([c.text for c in chunks]) if chunks else []

    stored = os.path.join(FILES_DIR, f"{did}{os.path.splitext(path)[1].lower()}")
    shutil.copy2(path, stored)
    stale_preview = os.path.join(FILES_DIR, f"{did}.preview.pdf")
    if os.path.exists(stale_preview):
        try:
            os.remove(stale_preview)
        except OSError:
            pass

    doc = Document(
        doc_id=did, title=title or os.path.splitext(os.path.basename(path))[0], doc_type=dt,
        path=path, project=project, sha256=sha, mtime=os.path.getmtime(path),
        unit_count=units, indexed_at=time.time(),
    )
    store.delete_document(did)
    store.upsert_document(doc, stored_path=stored)
    store.add_chunks(chunks, embeddings)
    return {**doc.to_dict(), "chunks": len(chunks)}


def index_note(store: Store, project: str, note_id: int, kind: str, title: str, body: str) -> dict:
    """Index (or re-index) a timeline note as a project-scoped mini-document so /ask
    retrieves over notes alongside documents."""
    did = f"{project}-note-{note_id}"
    chunks, units = extract_note(body, did, note_id, title, kind)
    embeddings = embed_passages([c.text for c in chunks]) if chunks else []
    doc = Document(
        doc_id=did, title=title or f"{kind.capitalize()} note", doc_type="note",
        path="", project=project, sha256="", mtime=time.time(),
        unit_count=units, indexed_at=time.time(),
    )
    store.delete_document(did)
    store.upsert_document(doc, stored_path="")
    if chunks:
        store.add_chunks(chunks, embeddings)
    return {**doc.to_dict(), "chunks": len(chunks)}
