"""Grounded, PROJECT-SCOPED QA: answer strictly from a project's retrieved chunks
(its notes AND documents), with ENFORCED [n] citations that each map to a locator
the UI can open at the exact slide/page/section — or scroll to the source note."""
from __future__ import annotations

import re

from .store import Store
from rag.retrieve import search, documents_for_query
from rag.llm import chat

SYSTEM = (
    "You are a project assistant. Answer the question USING ONLY the numbered sources provided "
    "(they are this project's meeting notes and documents). Cite every factual claim with a "
    "square-bracket marker like [1] or [2] referring to the source number; you may cite several "
    "like [1][3]. Do NOT use any other citation format. If the sources do not contain the answer, "
    "say exactly what is missing — never invent facts. Be concise and specific."
)

_CITE_RE = re.compile(r"\[(\d+)\]|【(\d+)†[^】]*】")


def _normalize_citations(text: str) -> str:
    return re.sub(r"【(\d+)†[^】]*】", lambda m: f"[{m.group(1)}]", text)


def ask(store: Store, query: str, project_id: str, k: int = 8, rerank: bool = True) -> dict:
    hits = search(store, query, project_id, k=k, rerank=rerank)
    if not hits:
        return {"answer": "No notes or documents are indexed for this project yet.",
                "citations": [], "documents": []}

    context = "\n\n".join(
        f"[{i + 1}] ({h['doc_title']} — {h['locator'].get('label', '')})\n{h['text'][:1200]}"
        for i, h in enumerate(hits)
    )
    raw = chat(
        [{"role": "system", "content": SYSTEM},
         {"role": "user", "content": f"Question: {query}\n\nSources:\n{context}"}],
        temperature=0.2, max_tokens=900,
    )
    answer = _normalize_citations(raw)

    used = sorted({
        int(a or b) for a, b in _CITE_RE.findall(raw) if 1 <= int(a or b) <= len(hits)
    })
    citations = [
        {"n": n, "doc_id": hits[n - 1]["doc_id"], "title": hits[n - 1]["doc_title"],
         "doc_type": hits[n - 1]["doc_type"], "open_at": hits[n - 1]["locator"],
         "score": hits[n - 1]["score"]}
        for n in used
    ]
    if not citations:
        h = hits[0]
        citations = [{"n": 1, "doc_id": h["doc_id"], "title": h["doc_title"],
                      "doc_type": h["doc_type"], "open_at": h["locator"], "score": h["score"]}]

    return {"answer": answer, "citations": citations,
            "documents": documents_for_query(store, query, project_id, k=12)}
