"""Calendar (ICS / RFC 5545) integration — fully offline, no external auth.

Two directions:
  * build_calendar(): emit a valid VCALENDAR of a project's tasks-with-due-dates and
    milestones, so it can be subscribed in any calendar app (Outlook, Google, Apple).
  * parse_calendar(): ingest an uploaded .ics and surface its VEVENTs so the importer
    can create milestones (all-day events) and tasks (timed events).

Pure standard-library: no icalendar dependency. We fold long lines and use CRLF per
the spec, escape text values, and emit all-day events with VALUE=DATE.
"""
from __future__ import annotations

import datetime
import re
from typing import Optional

PRODID = "-//OATIGenie//Project Management//EN"


# ---------------------------------------------------------------- helpers
def _esc(v: str) -> str:
    """Escape a TEXT value per RFC 5545 (backslash, semicolon, comma, newline)."""
    return (str(v or "")
            .replace("\\", "\\\\").replace(";", "\\;")
            .replace(",", "\\,").replace("\r\n", "\\n").replace("\n", "\\n"))


def _unesc(v: str) -> str:
    out = []
    i = 0
    while i < len(v):
        c = v[i]
        if c == "\\" and i + 1 < len(v):
            nxt = v[i + 1]
            out.append({"n": "\n", "N": "\n", ";": ";", ",": ",", "\\": "\\"}.get(nxt, nxt))
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _fold(line: str) -> str:
    """Fold a content line to <=75 octets with CRLF + leading space continuation."""
    b = line.encode("utf-8")
    if len(b) <= 75:
        return line
    out = []
    while len(b) > 75:
        # avoid splitting a multibyte char: back off to a safe boundary
        cut = 75
        while cut > 0 and (b[cut] & 0xC0) == 0x80:
            cut -= 1
        out.append(b[:cut].decode("utf-8"))
        b = b[cut:]
    out.append(b.decode("utf-8"))
    return "\r\n ".join(out)


def _date_compact(d: str) -> Optional[str]:
    """'YYYY-MM-DD' -> 'YYYYMMDD' (ICS DATE). Returns None if not a valid date."""
    d = (d or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", d)
    if not m:
        return None
    try:
        datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None
    return f"{m.group(1)}{m.group(2)}{m.group(3)}"


def _next_day_compact(compact: str) -> str:
    y, mo, da = int(compact[:4]), int(compact[4:6]), int(compact[6:8])
    nxt = datetime.date(y, mo, da) + datetime.timedelta(days=1)
    return nxt.strftime("%Y%m%d")


def _utc_stamp() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


# ---------------------------------------------------------------- build (export)
def build_calendar(project: dict, tasks: list[dict], milestones: list[dict]) -> str:
    """Return a valid VCALENDAR string for this project's dated tasks + milestones.

    Only items with a due_date become VEVENTs (all-day). Done items still appear but
    carry STATUS:COMPLETED so a calendar can grey them out."""
    name = project.get("name") or project.get("id") or "Project"
    stamp = _utc_stamp()
    lines: list[str] = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        f"PRODID:{PRODID}",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        _fold(f"X-WR-CALNAME:{_esc(name)}"),
        _fold(f"X-WR-CALDESC:{_esc('Project Management — tasks & milestones for ' + name)}"),
    ]

    for t in tasks:
        compact = _date_compact(t.get("due_date", ""))
        if not compact:
            continue
        uid = f"pm-task-{t['id']}@oatigenie"
        summary = f"[Task] {t.get('title', '')}"
        status = "COMPLETED" if t.get("status") == "done" else "NEEDS-ACTION"
        desc_bits = []
        if t.get("assignee"):
            desc_bits.append(f"Owner: {t['assignee']}")
        if t.get("priority"):
            desc_bits.append(f"Priority: {t['priority']}")
        if t.get("status"):
            desc_bits.append(f"Status: {t['status']}")
        if t.get("description"):
            desc_bits.append(str(t["description"]))
        if t.get("source_url"):
            desc_bits.append(f"Link: {t['source_url']}")
        desc = "\\n".join(_esc(x) for x in desc_bits)
        lines += [
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{stamp}",
            f"DTSTART;VALUE=DATE:{compact}",
            f"DTEND;VALUE=DATE:{_next_day_compact(compact)}",
            _fold(f"SUMMARY:{_esc(summary)}"),
        ]
        if desc:
            lines.append(_fold(f"DESCRIPTION:{desc}"))
        lines += [
            "CATEGORIES:TASK",
            f"STATUS:{status}",
            "END:VEVENT",
        ]

    for m in milestones:
        compact = _date_compact(m.get("due_date", ""))
        if not compact:
            continue
        uid = f"pm-milestone-{m['id']}@oatigenie"
        summary = f"[Milestone] {m.get('title', '')}"
        status = "COMPLETED" if m.get("status") == "done" else "CONFIRMED"
        lines += [
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{stamp}",
            f"DTSTART;VALUE=DATE:{compact}",
            f"DTEND;VALUE=DATE:{_next_day_compact(compact)}",
            _fold(f"SUMMARY:{_esc(summary)}"),
            _fold(f"DESCRIPTION:{_esc('Milestone status: ' + str(m.get('status', '')))}"),
            "CATEGORIES:MILESTONE",
            f"STATUS:{status}",
            "TRANSP:TRANSPARENT",
            "END:VEVENT",
        ]

    lines.append("END:VCALENDAR")
    return "\r\n".join(lines) + "\r\n"


# ---------------------------------------------------------------- parse (import)
def _unfold(text: str) -> list[str]:
    """Undo RFC 5545 line folding: a line starting with space/tab continues the prior."""
    raw = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out: list[str] = []
    for ln in raw:
        if ln[:1] in (" ", "\t") and out:
            out[-1] += ln[1:]
        else:
            out.append(ln)
    return out


def _split_prop(line: str) -> tuple[str, dict, str]:
    """'DTSTART;VALUE=DATE:20260710' -> ('DTSTART', {'VALUE':'DATE'}, '20260710')."""
    if ":" not in line:
        return "", {}, ""
    head, value = line.split(":", 1)
    parts = head.split(";")
    name = parts[0].upper()
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.upper()] = v.upper()
    return name, params, value


def _parse_dt(params: dict, value: str) -> tuple[Optional[str], bool]:
    """Return ('YYYY-MM-DD', all_day?). all_day when VALUE=DATE or a bare 8-digit date."""
    v = value.strip()
    all_day = params.get("VALUE") == "DATE" or bool(re.match(r"^\d{8}$", v))
    m = re.match(r"^(\d{4})(\d{2})(\d{2})", v)
    if not m:
        # tolerate 'YYYY-MM-DD...' just in case
        m2 = re.match(r"^(\d{4})-(\d{2})-(\d{2})", v)
        if not m2:
            return None, all_day
        return f"{m2.group(1)}-{m2.group(2)}-{m2.group(3)}", all_day
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}", all_day


def parse_calendar(text: str) -> list[dict]:
    """Parse VEVENTs from an ICS document into simple dicts:
       {uid, summary, description, date, all_day, status, categories}."""
    events: list[dict] = []
    cur: Optional[dict] = None
    for line in _unfold(text or ""):
        u = line.strip()
        if u == "BEGIN:VEVENT":
            cur = {"uid": "", "summary": "", "description": "", "date": None,
                   "all_day": True, "status": "", "categories": ""}
            continue
        if u == "END:VEVENT":
            if cur is not None:
                events.append(cur)
            cur = None
            continue
        if cur is None:
            continue
        name, params, value = _split_prop(line)
        if name == "UID":
            cur["uid"] = value.strip()
        elif name == "SUMMARY":
            cur["summary"] = _unesc(value)
        elif name == "DESCRIPTION":
            cur["description"] = _unesc(value)
        elif name == "DTSTART":
            d, all_day = _parse_dt(params, value)
            cur["date"] = d
            cur["all_day"] = all_day
        elif name == "STATUS":
            cur["status"] = value.strip().upper()
        elif name == "CATEGORIES":
            cur["categories"] = value.strip().upper()
    return events


def import_events(store, pid: str, text: str) -> dict:
    """Create milestones (all-day events) and tasks (timed events) from an ICS.

    Heuristic mapping: an all-day VEVENT (a whole-day marker) becomes a MILESTONE;
    a timed VEVENT becomes a TASK due that day. CATEGORIES:TASK/MILESTONE, when
    present (e.g. re-importing our own feed), override the heuristic. Returns counts
    and the created items."""
    events = parse_calendar(text)
    created_tasks: list = []
    created_milestones: list = []
    skipped = 0
    for ev in events:
        title = (ev.get("summary") or "").strip()
        # strip our own "[Task] "/"[Milestone] " prefix on round-trip
        title = re.sub(r"^\[(Task|Milestone)\]\s*", "", title)
        if not title or not ev.get("date"):
            skipped += 1
            continue
        cats = ev.get("categories", "")
        as_milestone = ev.get("all_day", True)
        if "TASK" in cats:
            as_milestone = False
        elif "MILESTONE" in cats:
            as_milestone = True
        done = ev.get("status") in ("COMPLETED", "CANCELLED")
        if as_milestone:
            m = store.add_milestone(pid, title=title, due_date=ev["date"],
                                    status="done" if done else "planned")
            created_milestones.append(m)
        else:
            t = store.add_task(pid, title=title, description=ev.get("description", ""),
                               due_date=ev["date"], status="done" if done else "todo",
                               source="calendar")
            created_tasks.append(t)
    return {
        "events_found": len(events),
        "tasks_created": len(created_tasks),
        "milestones_created": len(created_milestones),
        "skipped": skipped,
        "tasks": created_tasks,
        "milestones": created_milestones,
    }
