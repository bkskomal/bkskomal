"""AI-native project features built on the shared chat model:

  1. extract_actions() — pull structured action items (task/owner/due) + decisions +
     risks out of a meeting/daily note.
  2. project_digest() — a grounded exec status summary from the project's recent
     notes + documents, with key decisions and open risks.
  3. agentic_act() — turn a natural-language instruction into a set of executed
     changes (create/assign/complete task, add note, add milestone) against the store.
  4. draft_plan() — draft a lightweight WBS (milestones + tasks) for the project and
     insert it.

All parse the model's JSON defensively (gpt-oss occasionally wraps or annotates it).
"""
from __future__ import annotations

import json
import re

from .store import Store
from rag.retrieve import search
from rag.llm import chat


def _json_obj(s: str) -> dict:
    """Best-effort extract the first JSON object from a model reply."""
    if not s:
        return {}
    m = re.search(r"\{.*\}", s, re.S)
    raw = m.group(0) if m else s
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        # strip trailing commas and retry
        try:
            return json.loads(re.sub(r",\s*([}\]])", r"\1", raw))
        except (ValueError, TypeError):
            return {}


def _salvage_summary(raw: str) -> str:
    """Pull a "summary" value out of a truncated/partial JSON reply."""
    if not raw:
        return ""
    m = re.search(r'"summary"\s*:\s*"((?:[^"\\]|\\.)*)', raw, re.S)
    if m:
        try:
            return json.loads('"' + m.group(1) + '"')
        except (ValueError, TypeError):
            return m.group(1).replace('\\n', '\n').replace('\\"', '"').strip()
    return ""


# ---------------------------------------------------------------- 1. action items
_ACTIONS_SYS = (
    "You extract structured project intelligence from a meeting or daily note. "
    "Return ONLY a JSON object with exactly these keys:\n"
    '  "action_items": [ {"task": str, "owner": str|null, "due": str|null} ],\n'
    '  "decisions":   [ str, ... ],\n'
    '  "risks":       [ str, ... ]\n'
    "Rules: owner/due are null if not stated in the note. Do not invent items. "
    "A task is something someone must DO; a decision is a choice that was MADE; a risk "
    "is a threat/blocker/concern. Keep each string short and specific. No prose outside the JSON."
)


def extract_actions(note: dict) -> dict:
    body = (note.get("body") or "").strip()
    title = note.get("title") or ""
    kind = note.get("kind") or "note"
    if not body:
        return {"action_items": [], "decisions": [], "risks": []}
    raw = chat(
        [{"role": "system", "content": _ACTIONS_SYS},
         {"role": "user", "content": f"{kind.capitalize()} note titled \"{title}\":\n\n{body}"}],
        temperature=0.1, max_tokens=900,
    )
    data = _json_obj(raw)
    # normalise shape
    items = []
    for it in data.get("action_items", []) or []:
        if isinstance(it, dict):
            items.append({"task": str(it.get("task", "")).strip(),
                          "owner": (it.get("owner") or None),
                          "due": (it.get("due") or None)})
        elif isinstance(it, str) and it.strip():
            items.append({"task": it.strip(), "owner": None, "due": None})
    decisions = [str(d).strip() for d in (data.get("decisions") or []) if str(d).strip()]
    risks = [str(r).strip() for r in (data.get("risks") or []) if str(r).strip()]
    return {"action_items": [i for i in items if i["task"]], "decisions": decisions, "risks": risks}


# ---------------------------------------------------------------- 2. status digest
_DIGEST_SYS = (
    "You are a delivery lead writing a crisp executive status update for a project, "
    "grounded ONLY in the provided facts: the task progress + milestone rollup, the task and "
    "milestone lists, and the note/document source excerpts. Reflect the task progress numbers "
    "(done/total, in-progress, overdue) and milestone status explicitly in the summary. "
    "Return ONLY a JSON object with exactly these keys:\n"
    '  "summary":       markdown string (3-6 sentences on status, progress, direction),\n'
    '  "key_decisions": [ str, ... ],\n'
    '  "open_risks":    [ str, ... ],\n'
    '  "next_steps":    [ str, ... ]\n'
    "Ground every statement in the sources; if something is unknown, omit it rather than guess."
)


def project_digest(store: Store, project: dict, k: int = 12) -> dict:
    pid = project["id"]
    health = store.project_health(pid)
    tasks = store.list_tasks(pid)
    milestones = store.list_milestones(pid)

    # structured task/milestone facts the model must weave into the summary
    task_lines = [
        f"- [{t['status']}] {t['title']}"
        + (f" (owner: {t['assignee']})" if t.get("assignee") else "")
        + (f" (due: {t['due_date']})" if t.get("due_date") else "")
        for t in tasks
    ]
    ms_lines = [f"- [{m['status']}] {m['title']}" + (f" (due: {m['due_date']})" if m.get("due_date") else "")
                for m in milestones]
    progress = (
        f"Task progress: {health['tasks_done']}/{health['tasks_total']} done "
        f"({health['pct_done']}%), {health['in_progress']} in progress, "
        f"{health['overdue']} overdue. "
        f"Milestones: {health['milestones_done']}/{health['milestones_total']} reached."
    )
    upcoming = "; ".join(f"{u['title']} due {u['due_date']}" for u in health["upcoming_due"]) or "none"

    probe = f"{project.get('name','')} {project.get('product','')} status progress decisions risks next steps blockers"
    hits = search(store, probe, pid, k=k, pool=40)
    context = "\n\n".join(
        f"[{i+1}] ({h['doc_title']} — {h['locator'].get('label','')})\n{h['text'][:900]}"
        for i, h in enumerate(hits)
    ) or "(no notes/documents indexed yet)"

    header = (f"Project: {project.get('name','')}\nProduct: {project.get('product','') or 'n/a'}\n"
              f"Status: {project.get('status','')}\nDescription: {project.get('description','') or 'n/a'}\n\n"
              f"{progress}\nUpcoming due dates: {upcoming}\n\n"
              f"Tasks:\n" + ("\n".join(task_lines) or "(none)") + "\n\n"
              f"Milestones:\n" + ("\n".join(ms_lines) or "(none)"))
    msgs = [{"role": "system", "content": _DIGEST_SYS},
            {"role": "user", "content": f"{header}\n\nSource excerpts:\n{context}"}]
    raw = chat(msgs, temperature=0.2, max_tokens=1800)
    data = _json_obj(raw)
    # gpt-oss occasionally spends its whole budget on the reasoning channel and returns
    # empty content — retry once with a larger budget before falling back.
    if not data and not _salvage_summary(raw):
        raw = chat(msgs, temperature=0.3, max_tokens=2200)
        data = _json_obj(raw)
    sources = [{"doc_id": h["doc_id"], "title": h["doc_title"], "doc_type": h["doc_type"],
                "open_at": h["locator"]} for h in hits[:6]]
    return {
        "summary": (data.get("summary") or "").strip() or _salvage_summary(raw) or raw.strip(),
        "key_decisions": [str(d).strip() for d in (data.get("key_decisions") or []) if str(d).strip()],
        "open_risks": [str(r).strip() for r in (data.get("open_risks") or []) if str(r).strip()],
        "next_steps": [str(s).strip() for s in (data.get("next_steps") or []) if str(s).strip()],
        "task_progress": health,
        "milestones": milestones,
        "sources": sources,
    }


# ---------------------------------------------------------------- helpers
def _norm_prio(v) -> str:
    s = str(v or "").strip().lower()
    if s in ("low", "l"):
        return "low"
    if s in ("high", "hi", "h", "urgent", "critical"):
        return "high"
    return "med"


def _norm_kind(v) -> str:
    s = str(v or "").strip().lower()
    return s if s in ("daily", "meeting", "decision") else "meeting"


# ---------------------------------------------------------------- 3. agentic chat (act)
_ACT_SYS = (
    "You are an agentic project assistant. Read the user's instruction and the current "
    "project state, then decide which concrete changes to make. Return ONLY a JSON object "
    "with exactly these keys:\n"
    '  "message": str  — one short sentence confirming what you did,\n'
    '  "actions": [ ... ]  — the changes to apply, each an object with a "type".\n'
    "Allowed action shapes (use these exact types and arg names):\n"
    '  {"type":"create_task","title":str,"assignee":str|null,"priority":"low"|"med"|"high"|null,"due_date":"YYYY-MM-DD"|null,"description":str|null}\n'
    '  {"type":"assign_task","task_id":int|null,"task_title":str|null,"assignee":str}\n'
    '  {"type":"complete_task","task_id":int|null,"task_title":str|null}\n'
    '  {"type":"add_note","title":str|null,"body":str,"kind":"daily"|"meeting"|"decision"|null}\n'
    '  {"type":"add_milestone","title":str,"due_date":"YYYY-MM-DD"|null}\n'
    "Rules: Resolve relative dates (e.g. 'next Friday', 'end of week') to an absolute "
    "YYYY-MM-DD using the TODAY value provided. Match an assignee to one of the listed member "
    "names when the user names a person. To reference an EXISTING task (assign/complete), prefer "
    "its numeric task_id from the list; otherwise pass task_title. If the instruction is only a "
    "question and requests no change, return an empty actions list. Never invent work the user "
    "did not ask for. No prose outside the JSON."
)


def agentic_act(store: Store, project: dict, message: str, today: str = "") -> dict:
    """Parse an instruction into actions and EXECUTE them against the store. RBAC is
    enforced by the caller (needs >= write). Returns the model's confirmation message
    plus a per-action execution log."""
    import datetime
    pid = project["id"]
    today = today or datetime.date.today().isoformat()
    members = store.list_members(pid)
    tasks = store.list_tasks(pid)
    member_lines = ", ".join(m["name"] for m in members) or "(no members yet)"
    task_lines = "\n".join(
        f"  #{t['id']} [{t['status']}] {t['title']}"
        + (f" (assignee: {t['assignee']})" if t.get("assignee") else "")
        for t in tasks) or "  (no tasks yet)"
    ctx = (f"TODAY: {today}\nProject: {project.get('name','')}\n"
           f"Product: {project.get('product','') or 'n/a'}\nMembers: {member_lines}\n"
           f"Existing tasks:\n{task_lines}\n\nInstruction:\n{message}")
    raw = chat([{"role": "system", "content": _ACT_SYS},
                {"role": "user", "content": ctx}], temperature=0.1, max_tokens=1200)
    data = _json_obj(raw)
    actions = data.get("actions") or []

    def find_task(tid, title):
        if tid is not None:
            try:
                t = store.get_task(int(tid))
                if t and t["project_id"] == pid:
                    return t
            except (TypeError, ValueError):
                pass
        if title:
            want = str(title).strip().lower()
            cur = store.list_tasks(pid)
            for t in cur:
                if t["title"].strip().lower() == want:
                    return t
            for t in cur:
                if want and want in t["title"].strip().lower():
                    return t
        return None

    executed: list = []
    for a in actions:
        if not isinstance(a, dict):
            continue
        typ = a.get("type")
        try:
            if typ == "create_task":
                title = str(a.get("title", "")).strip()
                if not title:
                    executed.append({"type": typ, "ok": False, "detail": "Task had no title"}); continue
                t = store.add_task(pid, title=title, description=str(a.get("description") or ""),
                                   assignee=str(a.get("assignee") or ""), priority=_norm_prio(a.get("priority")),
                                   due_date=str(a.get("due_date") or ""), source="agent")
                detail = (f'Created task "{t["title"]}"'
                          + (f" for {t['assignee']}" if t["assignee"] else "")
                          + (f", {t['priority']} priority" if t["priority"] != "med" else "")
                          + (f", due {t['due_date']}" if t["due_date"] else ""))
                executed.append({"type": typ, "ok": True, "ref_id": t["id"], "detail": detail, "task": t})
            elif typ == "assign_task":
                t = find_task(a.get("task_id"), a.get("task_title"))
                if not t:
                    executed.append({"type": typ, "ok": False, "detail": "Could not find the task to assign"}); continue
                t2 = store.update_task(t["id"], {"assignee": str(a.get("assignee") or "")})
                executed.append({"type": typ, "ok": True, "ref_id": t["id"],
                                 "detail": f'Assigned "{t2["title"]}" to {t2["assignee"] or "nobody"}', "task": t2})
            elif typ == "complete_task":
                t = find_task(a.get("task_id"), a.get("task_title"))
                if not t:
                    executed.append({"type": typ, "ok": False, "detail": "Could not find the task to complete"}); continue
                t2 = store.update_task(t["id"], {"status": "done"})
                executed.append({"type": typ, "ok": True, "ref_id": t["id"],
                                 "detail": f'Completed "{t2["title"]}"', "task": t2})
            elif typ == "add_note":
                body = str(a.get("body") or "").strip()
                if not body:
                    executed.append({"type": typ, "ok": False, "detail": "Note had no body"}); continue
                n = store.add_note(pid, kind=_norm_kind(a.get("kind")),
                                   title=str(a.get("title") or ""), body=body)
                executed.append({"type": typ, "ok": True, "ref_id": n["id"],
                                 "detail": f'Added note "{n["title"] or "(untitled)"}"', "note": n})
            elif typ == "add_milestone":
                title = str(a.get("title", "")).strip()
                if not title:
                    executed.append({"type": typ, "ok": False, "detail": "Milestone had no title"}); continue
                m = store.add_milestone(pid, title=title, due_date=str(a.get("due_date") or ""))
                executed.append({"type": typ, "ok": True, "ref_id": m["id"],
                                 "detail": f'Added milestone "{m["title"]}"'
                                           + (f", due {m['due_date']}" if m["due_date"] else ""), "milestone": m})
            else:
                executed.append({"type": str(typ), "ok": False, "detail": f"Unknown action type '{typ}'"})
        except Exception as e:  # noqa: BLE001 — surface execution failures to the caller
            executed.append({"type": str(typ), "ok": False, "detail": f"Failed: {e}"})

    msg = (data.get("message") or "").strip()
    n_ok = sum(1 for e in executed if e.get("ok"))
    if not msg:
        msg = (f"Done — applied {n_ok} change{'s' if n_ok != 1 else ''}."
               if n_ok else "I didn't make any changes for that.")
    return {"message": msg, "actions": executed, "applied": n_ok}


# ---------------------------------------------------------------- 4. AI planning (WBS)
_PLAN_SYS = (
    "You are a delivery lead drafting a lightweight work breakdown (WBS) for a software "
    "project. From the project description, product, and optional goal, propose a realistic, "
    "sequenced plan. Return ONLY a JSON object with exactly these keys:\n"
    '  "summary": str  — 2-4 sentences describing the plan and its phases,\n'
    '  "milestones": [ {"title":str, "due_date":"YYYY-MM-DD"|null} ],\n'
    '  "tasks": [ {"title":str, "assignee":str|null, "priority":"low"|"med"|"high"|null, '
    '"due_date":"YYYY-MM-DD"|null, "milestone":str|null} ]\n'
    "Rules: propose 3-6 milestones ordered by time, and 6-14 concrete, actionable tasks spread "
    "across those milestones. Sequence due_dates sensibly starting from the TODAY value provided. "
    "Assign a task to one of the listed members when there is a natural owner, else null. "
    "No prose outside the JSON."
)


def draft_plan(store: Store, project: dict, goal: str = "", today: str = "") -> dict:
    """Draft a milestones+tasks plan from the project context and INSERT it
    (tasks -> 'todo', milestones -> 'planned'). RBAC enforced by the caller (>= write)."""
    import datetime
    pid = project["id"]
    today = today or datetime.date.today().isoformat()
    members = store.list_members(pid)
    member_lines = ", ".join(m["name"] for m in members) or "(no members yet)"
    ctx = (f"TODAY: {today}\nProject: {project.get('name','')}\n"
           f"Product: {project.get('product','') or 'n/a'}\n"
           f"Description: {project.get('description','') or 'n/a'}\nMembers: {member_lines}\n"
           f"Goal: {goal.strip() or '(none given — plan the project end to end)'}")
    raw = chat([{"role": "system", "content": _PLAN_SYS},
                {"role": "user", "content": ctx}], temperature=0.3, max_tokens=1800)
    data = _json_obj(raw)
    if not data and not _salvage_summary(raw):
        raw = chat([{"role": "system", "content": _PLAN_SYS},
                    {"role": "user", "content": ctx}], temperature=0.4, max_tokens=2200)
        data = _json_obj(raw)

    created_ms: list = []
    for m in (data.get("milestones") or []):
        if isinstance(m, dict):
            title = str(m.get("title", "")).strip(); due = str(m.get("due_date") or "")
        elif isinstance(m, str):
            title = m.strip(); due = ""
        else:
            continue
        if title:
            created_ms.append(store.add_milestone(pid, title=title, due_date=due, status="planned"))

    created_tasks: list = []
    for t in (data.get("tasks") or []):
        if isinstance(t, dict):
            title = str(t.get("title", "")).strip()
            created_tasks.append(store.add_task(
                pid, title=title, assignee=str(t.get("assignee") or ""),
                priority=_norm_prio(t.get("priority")), due_date=str(t.get("due_date") or ""),
                status="todo", source="plan")) if title else None
        elif isinstance(t, str) and t.strip():
            created_tasks.append(store.add_task(pid, title=t.strip(), status="todo", source="plan"))

    summary = (data.get("summary") or "").strip() or _salvage_summary(raw)
    return {
        "summary": summary,
        "milestones": created_ms,
        "tasks": created_tasks,
        "milestones_created": len(created_ms),
        "tasks_created": len(created_tasks),
    }
