"""Email-to-task ingest — turn a posted email (subject + body, optional sender) into a
task on the project board.

Primary path reuses the shared chat model to parse a title, owner, priority and due
date out of natural-language email text (matching an owner to a project member when
named). If the model is unreachable (offline) or returns nothing usable, a deterministic
heuristic still produces a sensible task, so the endpoint always creates something and
is offline-validatable.
"""
from __future__ import annotations

import datetime
import re

from .store import Store
from rag.llm import chat

_SYS = (
    "You convert an inbound email into ONE actionable project task. "
    "Return ONLY a JSON object with exactly these keys:\n"
    '  "title": str  — a short imperative task title (no "Re:"/"Fwd:" noise),\n'
    '  "description": str  — 1-3 sentences of context from the email,\n'
    '  "assignee": str|null  — a member name if the email clearly directs it at someone, else null,\n'
    '  "priority": "low"|"med"|"high",\n'
    '  "due_date": "YYYY-MM-DD"|null  — resolve relative dates against the TODAY value.\n'
    "Match assignee to one of the listed members when a person is named. Do not invent a due "
    "date that is not implied. No prose outside the JSON."
)

_PRIO_HI = ("urgent", "asap", "immediately", "critical", "high priority", "high-priority",
            "blocker", "p0", "p1", "eod", "end of day")
_PRIO_LO = ("whenever", "no rush", "low priority", "low-priority", "nice to have", "someday")
_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def _json_obj(s: str) -> dict:
    import json
    if not s:
        return {}
    m = re.search(r"\{.*\}", s, re.S)
    raw = m.group(0) if m else s
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        try:
            return json.loads(re.sub(r",\s*([}\]])", r"\1", raw))
        except (ValueError, TypeError):
            return {}


def _clean_subject(subject: str) -> str:
    return re.sub(r"^\s*(re|fw|fwd)\s*:\s*", "", subject or "", flags=re.I).strip()


def _norm_prio(v) -> str:
    s = str(v or "").strip().lower()
    if s in ("low", "l"):
        return "low"
    if s in ("high", "hi", "h", "urgent", "critical"):
        return "high"
    return "med"


def _heuristic_due(text: str, today: datetime.date) -> str:
    t = text.lower()
    m = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", t)
    if m:
        return m.group(1)
    # "by <Month> <day>"
    m = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{1,2})\b", t)
    if m:
        months = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
                  "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}
        mo = months[m.group(1)]
        day = int(m.group(2))
        year = today.year + (1 if mo < today.month else 0)
        try:
            return datetime.date(year, mo, day).isoformat()
        except ValueError:
            pass
    if "tomorrow" in t:
        return (today + datetime.timedelta(days=1)).isoformat()
    if "today" in t or "eod" in t or "end of day" in t:
        return today.isoformat()
    m = re.search(r"\b(?:by|on|due|before)\s+(?:next\s+)?(" + "|".join(_WEEKDAYS) + r")\b", t)
    if m:
        target = _WEEKDAYS.index(m.group(1))
        delta = (target - today.weekday()) % 7
        delta = delta or 7   # "by monday" means the coming monday, not today
        if "next" in t[max(0, m.start() - 6):m.start()]:
            delta += 7
        return (today + datetime.timedelta(days=delta)).isoformat()
    return ""


def _heuristic_assignee(text: str, members: list[dict]) -> str:
    t = text.lower()
    for m in members:
        name = (m.get("name") or "").strip()
        if not name:
            continue
        first = name.split()[0].lower()
        if re.search(rf"\b{re.escape(name.lower())}\b", t) or re.search(rf"\b{re.escape(first)}\b", t):
            return name
    m = re.search(r"@([A-Za-z0-9_.-]+)", text)
    return m.group(1) if m else ""


def _heuristic(subject: str, body: str, members: list[dict], today: datetime.date) -> dict:
    text = f"{subject}\n{body}"
    tl = text.lower()
    prio = "med"
    if any(w in tl for w in _PRIO_HI):
        prio = "high"
    elif any(w in tl for w in _PRIO_LO):
        prio = "low"
    title = _clean_subject(subject) or (body.strip().split("\n", 1)[0][:80] if body.strip() else "Email task")
    desc = (body or "").strip()
    if len(desc) > 500:
        desc = desc[:500] + "…"
    return {
        "title": title,
        "description": desc,
        "assignee": _heuristic_assignee(text, members),
        "priority": prio,
        "due_date": _heuristic_due(text, today),
    }


def parse_email(subject: str, body: str, members: list[dict], today: str = "") -> dict:
    """Parse an email into task fields. Tries the AI model first, always falls back to
    the heuristic. Returns {fields, via}."""
    tday = datetime.date.fromisoformat(today) if today else datetime.date.today()
    heur = _heuristic(subject, body, members, tday)
    member_names = ", ".join(m.get("name", "") for m in members) or "(none listed)"
    ctx = (f"TODAY: {tday.isoformat()}\nMembers: {member_names}\n\n"
           f"Subject: {subject}\n\nBody:\n{body}")
    try:
        raw = chat([{"role": "system", "content": _SYS}, {"role": "user", "content": ctx}],
                   temperature=0.1, max_tokens=500)
        data = _json_obj(raw)
    except Exception:  # noqa: BLE001 — model offline/unreachable -> heuristic
        data = {}
    if not data or not str(data.get("title") or "").strip():
        return {"fields": heur, "via": "heuristic"}
    # validate the AI assignee against real members; else keep heuristic's guess
    ai_assignee = str(data.get("assignee") or "").strip()
    names = {m.get("name", "").lower(): m.get("name", "") for m in members}
    assignee = names.get(ai_assignee.lower(), ai_assignee if ai_assignee else heur["assignee"])
    due = str(data.get("due_date") or "").strip()
    if due and not re.match(r"^\d{4}-\d{2}-\d{2}$", due):
        due = heur["due_date"]
    fields = {
        "title": str(data.get("title")).strip(),
        "description": str(data.get("description") or heur["description"]).strip(),
        "assignee": assignee,
        "priority": _norm_prio(data.get("priority")),
        "due_date": due,
    }
    return {"fields": fields, "via": "ai"}


def email_to_task(store: Store, pid: str, subject: str, body: str,
                  sender: str = "", today: str = "") -> dict:
    """Parse an email and CREATE the task. RBAC (>= write) enforced by the caller."""
    members = store.list_members(pid)
    parsed = parse_email(subject, body, members, today=today)
    f = parsed["fields"]
    src_url = f"mailto:{sender}" if sender else ""
    task = store.add_task(
        pid, title=f["title"], description=f["description"], assignee=f.get("assignee", ""),
        priority=f.get("priority", "med"), due_date=f.get("due_date", ""),
        status="todo", source="email", source_url=src_url)
    return {"task": task, "parsed": f, "via": parsed["via"], "sender": sender}
