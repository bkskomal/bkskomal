"""Preview-PDF generation for the unified viewer.

LibreOffice renders one slide per page, so a PPTX citation's `slide_index + 1` maps
directly to a preview-PDF page — one viewer opens pdf / pptx / docx at the exact spot.
PDFs are their own preview. Generation is lazy + cached (keeps ingest fast).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile

from config import PROJECTS_FILES as FILES_DIR

SOFFICE = os.environ.get("PM_SOFFICE", r"C:\Program Files\LibreOffice\program\soffice.exe")


def preview_path(doc_id: str) -> str:
    return os.path.join(FILES_DIR, f"{doc_id}.preview.pdf")


def ensure_preview(doc_id: str, source_path: str, doc_type: str) -> str | None:
    """Return a cached preview PDF path, generating it on first request. None if it
    can't be produced (e.g. LibreOffice missing) — the UI then offers download instead."""
    out = preview_path(doc_id)
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out
    if not source_path or not os.path.exists(source_path):
        return None
    if doc_type == "pdf":
        shutil.copy2(source_path, out)
        return out
    if not os.path.exists(SOFFICE):
        return None
    with tempfile.TemporaryDirectory() as td:
        profile = "file:///" + td.replace("\\", "/") + "/loprofile"
        try:
            subprocess.run(
                [SOFFICE, f"-env:UserInstallation={profile}", "--headless",
                 "--convert-to", "pdf", "--outdir", td, source_path],
                timeout=180, capture_output=True,
            )
        except Exception:
            return None
        produced = os.path.join(td, os.path.splitext(os.path.basename(source_path))[0] + ".pdf")
        if os.path.exists(produced) and os.path.getsize(produced) > 0:
            shutil.copy2(produced, out)
            return out
    return None


def preview_page(locator: dict) -> int:
    """Which preview-PDF page a locator opens at."""
    if locator.get("page"):
        return int(locator["page"])
    if locator.get("slide_index") is not None:
        return int(locator["slide_index"]) + 1
    return 1
