# OATIGenie Auth / Super-Admin API (`/auth`)

Server-side users + tool-enablement store powering the Super-Admin console. Additive
package, mounted in `app.py` under `/auth`. Backed by its **own** sqlite
(`server/data/auth.sqlite` via `config.AUTH_DB`; gitignored) — never the tool DBs.

## Identity model

There is **no session token**. Identity is the same header every tool already uses:
`X-OATI-User: <email>`. `POST /auth/login` only *verifies* credentials; the frontend
keeps sending `X-OATI-User=email` to the tools as the identity. Admin-only endpoints are
gated server-side by a dependency that resolves that header to a user and requires an
**enabled superadmin** (403 otherwise).

## Passwords

`hashlib.pbkdf2_hmac("sha256", password, salt, 240_000)`, stdlib only — no new deps.
Per-user 16-byte random salt (`secrets.token_hex`). Verification is constant-time
(`hmac.compare_digest`). Hashes/salts are **never** returned by any endpoint. Minimum
password length: 6.

## Seed

On first run an initial superadmin is created idempotently:
`demo@oati.com` / `oatigenie`, role `superadmin`, enabled. Re-runs never overwrite it, so
the seed password can be safely changed.

## Roles

`"superadmin"` | `"user"`. `enabled` is a bool. A **last-superadmin guard** blocks
disabling, demoting, or deleting the final enabled superadmin (returns 409).

## Endpoints

| Method | Path | Auth | Body | Success |
|---|---|---|---|---|
| POST | `/auth/login` | public | `{email,password}` | `200 {ok:true, user:{email,role,enabled}}` |
| GET  | `/auth/me` | `X-OATI-User` | — | `200 {email,role,enabled,created_at}` |
| GET  | `/auth/users` | superadmin | — | `200 {users:[{email,role,enabled,created_at}]}` |
| POST | `/auth/users` | superadmin | `{email,password,role?}` | `200 {ok:true, user}` |
| PATCH| `/auth/users/{email}` | superadmin | `{enabled?,role?,password?}` | `200 {ok:true, user}` |
| DELETE| `/auth/users/{email}` | superadmin | — | `200 {ok:true}` |
| GET  | `/auth/tools` | public | — | `200 {ppt,documents,projects,compare}` (booleans) |
| PUT  | `/auth/tools` | superadmin | `{ppt?,documents?,projects?,compare?}` | `200 {ppt,documents,projects,compare}` |

`user` shape is always `{email, role, enabled, created_at}` — never a hash.

### Status codes

- `401` — bad credentials or disabled account on `/auth/login`
  (`{"detail":"invalid credentials"}` / `{"detail":"account disabled"}`).
- `403` — caller is not an enabled superadmin (or unknown `X-OATI-User`) on an
  admin-only endpoint (`{"detail":"superadmin required"}` etc.).
- `400` — validation (duplicate email, short password, invalid role).
- `404` — unknown user on PATCH/DELETE, or unknown/missing caller on `/auth/me`.
- `409` — last-superadmin guard (disable / demote / delete the final superadmin).

## Tool enablement

`tools_config` key/value in the same db. Keys: `ppt`, `documents`, `projects`,
`compare`; all default `true`. `GET /auth/tools` is public so the nav can read it;
`PUT /auth/tools` is superadmin-only and accepts a partial object (only provided keys
change).

## Frontend flow

1. Login form → `POST /auth/login`. On `ok:true`, store `user.email` and send it as
   `X-OATI-User` on every subsequent request (to `/auth/*` and the tools).
2. `GET /auth/me` → learn the caller's role; show the Super-Admin console only for
   `role === "superadmin"`.
3. `GET /auth/tools` → drive which tools appear in the nav.
4. Super-Admin console → `GET/POST/PATCH/DELETE /auth/users` and `PUT /auth/tools`.
