"""User store + tool-enablement config for the OATIGenie Super-Admin console.

ONE sqlite (config.AUTH_DB, i.e. server/data/auth.sqlite), never shared with the tool
DBs. Passwords are hashed with hashlib.pbkdf2_hmac (stdlib — no new deps) using a random
per-user salt; verification is constant-time (hmac.compare_digest). Nothing here ever
returns or logs a hash.

Tables:
    users(email PK, pass_hash, salt, role, enabled, created_at)
    tools_config(key PK, enabled)              # ppt / documents / projects / compare

Seed: an initial superadmin (demo@oati.com / oatigenie) is created idempotently on first
run so the console is reachable out of the box.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import sqlite3
import time
from typing import Optional

from config import AUTH_DB

ROLES = ("superadmin", "user")
TOOL_KEYS = ("ppt", "documents", "projects", "compare")

# pbkdf2_hmac parameters (stdlib only). SHA-256, 240k iterations, 16-byte salt.
_PBKDF2_ALGO = "sha256"
_PBKDF2_ITERS = 240_000
_SALT_BYTES = 16

SEED_EMAIL = "demo@oati.com"
SEED_PASSWORD = "oatigenie"

MIN_PASSWORD_LEN = 6

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  email      TEXT PRIMARY KEY,
  pass_hash  TEXT NOT NULL,
  salt       TEXT NOT NULL,
  role       TEXT NOT NULL DEFAULT 'user',
  enabled    INTEGER NOT NULL DEFAULT 1,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS tools_config(
  key     TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1
);
"""


def _hash_password(password: str, salt_hex: str) -> str:
    """PBKDF2-HMAC-SHA256(password, salt) -> hex digest. Salt is a hex string."""
    salt = bytes.fromhex(salt_hex)
    dk = hashlib.pbkdf2_hmac(_PBKDF2_ALGO, password.encode("utf-8"), salt, _PBKDF2_ITERS)
    return dk.hex()


class AuthStore:
    def __init__(self, db_path: str = AUTH_DB):
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)
        self._seed_tools()
        self._seed_superadmin()

    # ------------------------------------------------------------------ seeding
    def _seed_tools(self) -> None:
        """Ensure every tool key exists, default enabled=1. Idempotent."""
        for key in TOOL_KEYS:
            self.db.execute(
                "INSERT OR IGNORE INTO tools_config(key, enabled) VALUES(?, 1)", (key,)
            )
        self.db.commit()

    def _seed_superadmin(self) -> None:
        """Create the initial superadmin on first run. Idempotent — never overwrites
        an existing account (so an admin can change the seed password safely)."""
        if self.get_user(SEED_EMAIL) is None:
            self.create_user(SEED_EMAIL, SEED_PASSWORD, role="superadmin", enabled=True)

    # ------------------------------------------------------------------ users
    def _row_to_public(self, row: sqlite3.Row) -> dict:
        """Public shape — NEVER includes pass_hash/salt."""
        return {
            "email": row["email"],
            "role": row["role"],
            "enabled": bool(row["enabled"]),
            "created_at": row["created_at"],
        }

    def get_user(self, email: str) -> Optional[sqlite3.Row]:
        """Raw row (incl. hash/salt) for internal use only."""
        email = (email or "").strip().lower()
        cur = self.db.execute("SELECT * FROM users WHERE email = ?", (email,))
        return cur.fetchone()

    def get_public(self, email: str) -> Optional[dict]:
        row = self.get_user(email)
        return self._row_to_public(row) if row else None

    def list_users(self) -> list[dict]:
        cur = self.db.execute(
            "SELECT email, role, enabled, created_at FROM users ORDER BY created_at ASC"
        )
        return [self._row_to_public(r) for r in cur.fetchall()]

    def count_superadmins(self, only_enabled: bool = True) -> int:
        q = "SELECT COUNT(*) AS n FROM users WHERE role = 'superadmin'"
        if only_enabled:
            q += " AND enabled = 1"
        return int(self.db.execute(q).fetchone()["n"])

    def create_user(self, email: str, password: str, role: str = "user",
                    enabled: bool = True) -> dict:
        email = (email or "").strip().lower()
        if not email or "@" not in email:
            raise ValueError("invalid email")
        if role not in ROLES:
            raise ValueError(f"invalid role (expected one of {ROLES})")
        if password is None or len(password) < MIN_PASSWORD_LEN:
            raise ValueError(f"password must be at least {MIN_PASSWORD_LEN} characters")
        if self.get_user(email) is not None:
            raise ValueError("email already exists")
        salt_hex = secrets.token_hex(_SALT_BYTES)
        pass_hash = _hash_password(password, salt_hex)
        self.db.execute(
            "INSERT INTO users(email, pass_hash, salt, role, enabled, created_at) "
            "VALUES(?,?,?,?,?,?)",
            (email, pass_hash, salt_hex, role, 1 if enabled else 0, time.time()),
        )
        self.db.commit()
        return self.get_public(email)

    def verify(self, email: str, password: str) -> dict:
        """Return {ok, user?, error?}. Constant-time compare. Disabled => ok False."""
        row = self.get_user(email)
        if row is None:
            # Still spend a hash to avoid trivial user-enumeration timing.
            _hash_password(password or "", secrets.token_hex(_SALT_BYTES))
            return {"ok": False, "error": "invalid credentials"}
        candidate = _hash_password(password or "", row["salt"])
        if not hmac.compare_digest(candidate, row["pass_hash"]):
            return {"ok": False, "error": "invalid credentials"}
        if not bool(row["enabled"]):
            return {"ok": False, "error": "account disabled", "user": self._row_to_public(row)}
        return {"ok": True, "user": self._row_to_public(row)}

    def update_user(self, email: str, *, enabled: Optional[bool] = None,
                    role: Optional[str] = None, password: Optional[str] = None) -> dict:
        row = self.get_user(email)
        if row is None:
            raise KeyError("user not found")
        email = row["email"]

        # Last-superadmin guard: block disabling or demoting the final enabled superadmin.
        if row["role"] == "superadmin" and self.count_superadmins(only_enabled=True) <= 1:
            demoting = role is not None and role != "superadmin"
            disabling = enabled is False
            if demoting or disabling:
                raise PermissionError("cannot disable or demote the last superadmin")

        sets, params = [], []
        if enabled is not None:
            sets.append("enabled = ?")
            params.append(1 if enabled else 0)
        if role is not None:
            if role not in ROLES:
                raise ValueError(f"invalid role (expected one of {ROLES})")
            sets.append("role = ?")
            params.append(role)
        if password is not None:
            if len(password) < MIN_PASSWORD_LEN:
                raise ValueError(f"password must be at least {MIN_PASSWORD_LEN} characters")
            salt_hex = secrets.token_hex(_SALT_BYTES)
            sets.append("pass_hash = ?")
            params.append(_hash_password(password, salt_hex))
            sets.append("salt = ?")
            params.append(salt_hex)
        if not sets:
            return self.get_public(email)
        params.append(email)
        self.db.execute(f"UPDATE users SET {', '.join(sets)} WHERE email = ?", params)
        self.db.commit()
        return self.get_public(email)

    def delete_user(self, email: str) -> None:
        row = self.get_user(email)
        if row is None:
            raise KeyError("user not found")
        if row["role"] == "superadmin" and self.count_superadmins(only_enabled=False) <= 1:
            raise PermissionError("cannot delete the last superadmin")
        self.db.execute("DELETE FROM users WHERE email = ?", (row["email"],))
        self.db.commit()

    # ------------------------------------------------------------------ tools config
    def get_tools(self) -> dict:
        cur = self.db.execute("SELECT key, enabled FROM tools_config")
        found = {r["key"]: bool(r["enabled"]) for r in cur.fetchall()}
        # default any missing key to True
        return {key: found.get(key, True) for key in TOOL_KEYS}

    def set_tools(self, updates: dict) -> dict:
        for key, val in updates.items():
            if key not in TOOL_KEYS or val is None:
                continue
            self.db.execute(
                "INSERT INTO tools_config(key, enabled) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET enabled = excluded.enabled",
                (key, 1 if val else 0),
            )
        self.db.commit()
        return self.get_tools()


# Module-level singleton — imported by the router and by /health.
store = AuthStore()
