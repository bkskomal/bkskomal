"""Server-side auth / users / tool-enablement for the OATIGenie Super-Admin console.

Additive package. Mounted in app.py under /auth. Backed by its OWN sqlite
(server/data/auth.sqlite via config.AUTH_DB) — never the tool DBs.
"""
from __future__ import annotations

from .router import router  # noqa: F401
from .store import AuthStore, store  # noqa: F401
