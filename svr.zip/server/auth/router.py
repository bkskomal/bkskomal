"""FastAPI router for the OATIGenie Super-Admin console, mounted at /auth.

Identity: like every tool, the caller's identity is the `X-OATI-User` header (an email).
There is NO session token — /auth/login just VERIFIES credentials; the frontend keeps
sending X-OATI-User=email to the tools as before. Admin-only endpoints are gated by a
dependency that resolves the header to a user row and 403s unless the caller is an
enabled superadmin.
"""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from .store import store, ROLES

router = APIRouter()


# ------------------------------------------------------------------ request models
class LoginBody(BaseModel):
    email: str
    password: str


class CreateUserBody(BaseModel):
    email: str
    password: str
    role: str = "user"


class UpdateUserBody(BaseModel):
    enabled: Optional[bool] = None
    role: Optional[str] = None
    password: Optional[str] = None


class ToolsBody(BaseModel):
    ppt: Optional[bool] = None
    documents: Optional[bool] = None
    projects: Optional[bool] = None
    compare: Optional[bool] = None


# ------------------------------------------------------------------ identity / gate
def _caller(x_oati_user: Optional[str]) -> Optional[dict]:
    """Resolve the X-OATI-User header to a public user dict, or None."""
    if not x_oati_user or not x_oati_user.strip():
        return None
    return store.get_public(x_oati_user.strip().lower())


def require_superadmin(x_oati_user: Optional[str] = Header(None)) -> dict:
    """Dependency: 403 unless the X-OATI-User caller is an ENABLED superadmin."""
    user = _caller(x_oati_user)
    if user is None:
        raise HTTPException(status_code=403, detail="unknown or missing caller (X-OATI-User)")
    if not user["enabled"]:
        raise HTTPException(status_code=403, detail="account disabled")
    if user["role"] != "superadmin":
        raise HTTPException(status_code=403, detail="superadmin required")
    return user


# ------------------------------------------------------------------ auth
@router.post("/login")
def login(body: LoginBody):
    result = store.verify(body.email, body.password)
    if not result["ok"]:
        raise HTTPException(status_code=401, detail=result.get("error", "invalid credentials"))
    return {"ok": True, "user": result["user"]}


@router.get("/me")
def me(x_oati_user: Optional[str] = Header(None)):
    user = _caller(x_oati_user)
    if user is None:
        raise HTTPException(status_code=404, detail="unknown or missing caller (X-OATI-User)")
    return user


# ------------------------------------------------------------------ users (superadmin)
@router.get("/users")
def list_users(x_oati_user: Optional[str] = Header(None)):
    require_superadmin(x_oati_user)
    return {"users": store.list_users()}


@router.post("/users")
def create_user(body: CreateUserBody, x_oati_user: Optional[str] = Header(None)):
    require_superadmin(x_oati_user)
    try:
        user = store.create_user(body.email, body.password, role=body.role)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "user": user}


@router.patch("/users/{email}")
def update_user(email: str, body: UpdateUserBody, x_oati_user: Optional[str] = Header(None)):
    require_superadmin(x_oati_user)
    try:
        user = store.update_user(email, enabled=body.enabled, role=body.role,
                                 password=body.password)
    except KeyError:
        raise HTTPException(status_code=404, detail="user not found")
    except PermissionError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "user": user}


@router.delete("/users/{email}")
def delete_user(email: str, x_oati_user: Optional[str] = Header(None)):
    require_superadmin(x_oati_user)
    try:
        store.delete_user(email)
    except KeyError:
        raise HTTPException(status_code=404, detail="user not found")
    except PermissionError as e:
        raise HTTPException(status_code=409, detail=str(e))
    return {"ok": True}


# ------------------------------------------------------------------ tools enablement
@router.get("/tools")
def get_tools():
    """Any caller — drives the nav. Booleans for ppt/documents/projects/compare."""
    return store.get_tools()


@router.put("/tools")
def set_tools(body: ToolsBody, x_oati_user: Optional[str] = Header(None)):
    require_superadmin(x_oati_user)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    return store.set_tools(updates)
