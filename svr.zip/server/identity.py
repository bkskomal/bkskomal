"""One identity for the whole suite: the `X-OATI-User` header.

Each mounted tool historically read its own identity header (Document Management:
X-DM-User/X-DM-Groups, Project Management: X-PM-User, Files Comparison: X-FC-User).
Rather than edit every endpoint, this small ASGI shim runs in front of each sub-app and
copies X-OATI-User (+ X-OATI-Groups) into that tool's native header BEFORE the request
reaches it. So callers send ONE header and every router derives its principals/uid from
it. The legacy headers still work when X-OATI-User is absent (backward compatible);
X-OATI-User takes precedence when both are present.

ASGI header names are lowercased bytes in `scope["headers"]`.
"""
from __future__ import annotations


class IdentityShim:
    """Map the canonical X-OATI-* headers onto a tool's legacy identity headers.

    `mapping` is {oati_header: legacy_header} in lowercase, e.g.
    {"x-oati-user": "x-dm-user", "x-oati-groups": "x-dm-groups"}.
    """

    def __init__(self, app, mapping: dict[str, str]):
        self.app = app
        self.mapping = {k.lower(): v.lower() for k, v in mapping.items()}

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return
        headers = list(scope.get("headers") or [])
        present = {k for (k, _v) in headers}
        for oati, legacy in self.mapping.items():
            ob, lb = oati.encode("latin-1"), legacy.encode("latin-1")
            val = next((v for (k, v) in headers if k == ob), None)
            if val is not None:
                # X-OATI-* wins: drop any existing legacy header, then set it.
                headers = [(k, v) for (k, v) in headers if k != lb]
                headers.append((lb, val))
        scope = dict(scope)
        scope["headers"] = headers
        await self.app(scope, receive, send)


# Per-tool header maps
DOCUMENTS_MAP = {"x-oati-user": "x-dm-user", "x-oati-groups": "x-dm-groups"}
PROJECTS_MAP = {"x-oati-user": "x-pm-user"}
COMPARE_MAP = {"x-oati-user": "x-fc-user"}
