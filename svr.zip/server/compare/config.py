"""Configuration for Files Comparison — a STANDALONE tool.

It has no dependency on the other tools in the suite. It talks ONLY to a shared AI
chat backend (an OpenAI-compatible chat endpoint) for the change summary. Comparison
itself is fully local and stateless. Swap the URL via env to run isolated.
"""
import os

# Shared chat model (OpenAI-compatible). Default: self-hosted GPT-OSS-120B.
LLM_BASE = os.environ.get("FC_LLM_BASE", "https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1")
LLM_MODEL = os.environ.get("FC_LLM_MODEL", "openai/gpt-oss-120b")
LLM_KEY = os.environ.get("FC_LLM_KEY", "none")
LLM_TLS_INSECURE = os.environ.get("FC_LLM_TLS_INSECURE", "true").lower() == "true"
