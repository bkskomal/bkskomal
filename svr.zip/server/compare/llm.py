"""GPT-OSS-120B chat client (OpenAI-compatible), same endpoint PPTMaker uses."""
from __future__ import annotations

import warnings
import httpx

from .config import LLM_BASE, LLM_MODEL, LLM_KEY, LLM_TLS_INSECURE

warnings.filterwarnings("ignore")  # silence the AI_TLS_INSECURE self-signed warning


def chat(messages: list[dict], temperature: float = 0.2, max_tokens: int = 1200) -> str:
    r = httpx.post(
        f"{LLM_BASE}/chat/completions",
        headers={"Authorization": f"Bearer {LLM_KEY}", "Content-Type": "application/json"},
        json={"model": LLM_MODEL, "messages": messages, "temperature": temperature, "max_tokens": max_tokens},
        timeout=240.0,
        verify=not LLM_TLS_INSECURE,
    )
    r.raise_for_status()
    msg = r.json()["choices"][0]["message"]
    # gpt-oss keeps chain-of-thought in a separate channel; the answer is in content.
    return (msg.get("content") or "").strip()
