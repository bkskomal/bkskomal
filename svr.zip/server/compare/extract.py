"""Anchor-preserving extraction: file -> [Chunk] with precise locators.

Each extractor chunks on the document's NATURAL boundaries (a slide, a page region,
a heading section) so the structural anchor on every chunk stays clean and openable.
This is the un-retrofittable core of the system.
"""
from __future__ import annotations

import email
import os
import re
from email import policy
from html.parser import HTMLParser
from typing import List, Tuple

from .models import Locator, Chunk, est_tokens, CHUNK_TOKENS

# openpyxl is optional - .xlsx support is enabled only when it is importable. On this
# box it is present; if it were not, .xlsx is simply omitted from EXTRACTORS/SUPPORTED.
try:
    import openpyxl  # noqa: F401
    _HAS_XLSX = True
except Exception:
    _HAS_XLSX = False

# Real OCR for scanned PDFs is intentionally NOT wired up here.
# TODO OCR: needs tesseract/easyocr (blocked: cannot install, C: full). pytesseract and
# easyocr are both absent and pip is unavailable (C: at 100%). Until one is installed we
# only DETECT scanned pages (no extractable text) and index a visible placeholder chunk
# so the page shows up in the library instead of silently vanishing.
try:
    import pytesseract  # noqa: F401
    _HAS_OCR = True
except Exception:
    try:
        import easyocr  # noqa: F401
        _HAS_OCR = True
    except Exception:
        _HAS_OCR = False


# ------------------------------------------------------------------ PDF (PyMuPDF)
def extract_pdf(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    """Page-anchored chunks. Blocks within a page are packed to ~CHUNK_TOKENS and
    never cross a page boundary, so `page` + `bbox` always point at the real spot."""
    import fitz  # PyMuPDF

    chunks: List[Chunk] = []
    doc = fitz.open(path)
    n_pages = doc.page_count
    ordn = 0

    for pno in range(n_pages):
        page = doc[pno]
        blocks = [b for b in page.get_text("blocks") if b[4] and b[4].strip()]
        # reading order: top-to-bottom, then left-to-right
        blocks.sort(key=lambda b: (round(b[1] / 4), b[0]))

        if not blocks:
            # No extractable text on this page. If it carries images it is a SCANNED page
            # (needs OCR); index a visible placeholder so it is not silently dropped.
            if page.get_images():
                msg = f"[Scanned page {pno + 1} - image only, no extractable text; OCR unavailable]"
                loc = Locator(
                    doc_type="pdf", label=f"Page {pno + 1} (scanned)", page=pno + 1,
                    needs_ocr=True, quote=msg,
                )
                chunks.append(Chunk(doc_id, ordn, msg, loc, token_est=est_tokens(msg)))
                ordn += 1
            continue

        buf_text: List[str] = []
        buf_boxes: List[tuple] = []
        buf_tokens = 0

        def flush():
            nonlocal ordn, buf_text, buf_boxes, buf_tokens
            if not buf_text:
                return
            text = "\n".join(buf_text).strip()
            if text:
                x0 = min(b[0] for b in buf_boxes); y0 = min(b[1] for b in buf_boxes)
                x1 = max(b[2] for b in buf_boxes); y1 = max(b[3] for b in buf_boxes)
                loc = Locator(
                    doc_type="pdf", label=f"Page {pno + 1}", page=pno + 1,
                    bbox=[round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)],
                    quote=text[:220],
                )
                chunks.append(Chunk(doc_id, ordn, text, loc, token_est=est_tokens(text)))
                ordn += 1
            buf_text, buf_boxes, buf_tokens = [], [], 0

        for b in blocks:
            t = b[4].strip()
            buf_text.append(t); buf_boxes.append(b); buf_tokens += est_tokens(t)
            if buf_tokens >= CHUNK_TOKENS:
                flush()
        flush()

    doc.close()
    return chunks, n_pages


# ------------------------------------------------------------------ PPTX (python-pptx)
def extract_pptx(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    """One chunk per slide (slides are naturally chunk-sized), anchored by
    `slide_index` and the id of the text shape carrying the most content."""
    from pptx import Presentation

    prs = Presentation(path)
    slides = list(prs.slides)
    chunks: List[Chunk] = []
    ordn = 0

    for i, slide in enumerate(slides):
        title = ""
        try:
            if slide.shapes.title and slide.shapes.title.text.strip():
                title = slide.shapes.title.text.strip()
        except Exception:
            pass

        texts: List[str] = []
        main_shape_id = None
        max_len = 0
        for shape in slide.shapes:
            try:
                if shape.has_text_frame:
                    t = shape.text_frame.text.strip()
                    if t:
                        texts.append(t)
                        if len(t) > max_len:
                            max_len = len(t); main_shape_id = str(shape.shape_id)
                if shape.has_table:
                    tbl = shape.table
                    rows = [" | ".join(c.text.strip() for c in row.cells) for row in tbl.rows]
                    joined = "\n".join(r for r in rows if r.strip())
                    if joined:
                        texts.append(joined)
            except Exception:
                continue

        text = "\n".join(texts).strip()
        if not text:
            continue
        loc = Locator(
            doc_type="pptx", label=f"Slide {i + 1}", slide_index=i,
            shape_id=main_shape_id, quote=(title or text)[:220],
        )
        chunks.append(Chunk(doc_id, ordn, text, loc, heading_context=title, token_est=est_tokens(text)))
        ordn += 1

    return chunks, len(slides)


# ------------------------------------------------------------------ DOCX (python-docx)
def extract_docx(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    """Section-anchored chunks. Paragraphs are grouped under their heading breadcrumb
    and packed to ~CHUNK_TOKENS; each chunk records the first paragraph index +
    heading_path so it opens at the right section. Tables become their own chunks."""
    from docx import Document as Docx

    d = Docx(path)
    chunks: List[Chunk] = []
    ordn = 0
    heading_stack: List[tuple] = []  # (level, text)

    buf: List[str] = []
    buf_start = None
    buf_tokens = 0

    def heading_path() -> list:
        return [h for _, h in heading_stack]

    def flush():
        nonlocal ordn, buf, buf_start, buf_tokens
        if not buf:
            return
        text = "\n".join(buf).strip()
        if text:
            hp = heading_path()
            label = ("§ " + " › ".join(hp)) if hp else f"Paragraph {(buf_start or 0) + 1}"
            loc = Locator(
                doc_type="docx", label=label, para_index=buf_start,
                heading_path=(hp or None), quote=text[:220],
            )
            chunks.append(Chunk(doc_id, ordn, text, loc,
                               heading_context=" › ".join(hp), token_est=est_tokens(text)))
            ordn += 1
        buf, buf_start, buf_tokens = [], None, 0

    for idx, p in enumerate(d.paragraphs):
        style = (p.style.name or "").lower() if p.style else ""
        txt = p.text.strip()
        if style.startswith("heading"):
            flush()
            try:
                level = int("".join(ch for ch in style if ch.isdigit()) or "1")
            except Exception:
                level = 1
            while heading_stack and heading_stack[-1][0] >= level:
                heading_stack.pop()
            if txt:
                heading_stack.append((level, txt))
            continue
        if not txt:
            continue
        if buf_start is None:
            buf_start = idx
        buf.append(txt); buf_tokens += est_tokens(txt)
        if buf_tokens >= CHUNK_TOKENS:
            flush()
    flush()

    for ti, tbl in enumerate(d.tables):
        rows = [" | ".join(c.text.strip() for c in row.cells) for row in tbl.rows]
        text = "\n".join(r for r in rows if r.strip())
        if text:
            loc = Locator(doc_type="docx", label=f"Table {ti + 1}", quote=text[:220])
            chunks.append(Chunk(doc_id, ordn, text, loc, token_est=est_tokens(text)))
            ordn += 1

    return chunks, len(d.paragraphs)


# ------------------------------------------------------------------ TXT / MD (stdlib)
_MD_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")


def extract_text(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    """Plain-text and Markdown. Chunks on blank-line blocks packed to ~CHUNK_TOKENS,
    tracking source line offsets so the anchor is `Lines a-b`. For Markdown, `#` headings
    build a breadcrumb (like the docx extractor) and the anchor becomes `§ <breadcrumb>`."""
    ext = os.path.splitext(path)[1].lower()
    dtype = "md" if ext in (".md", ".markdown") else "txt"
    is_md = dtype == "md"

    with open(path, encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()

    chunks: List[Chunk] = []
    ordn = 0
    heading_stack: List[tuple] = []  # (level, text)
    buf: List[str] = []
    buf_start: int | None = None
    buf_tokens = 0

    def heading_path() -> list:
        return [h for _, h in heading_stack]

    def flush(end_line: int):
        nonlocal ordn, buf, buf_start, buf_tokens
        if not buf:
            return
        text = "\n".join(buf).strip()
        if text:
            hp = heading_path()
            if is_md and hp:
                label = "§ " + " › ".join(hp)
            else:
                label = f"Lines {buf_start}-{end_line}"
            loc = Locator(
                doc_type=dtype, label=label, line_start=buf_start, line_end=end_line,
                heading_path=(hp or None) if is_md else None, quote=text[:200],
            )
            chunks.append(Chunk(doc_id, ordn, text, loc,
                               heading_context=(" › ".join(hp) if is_md else ""),
                               token_est=est_tokens(text)))
            ordn += 1
        buf, buf_start, buf_tokens = [], None, 0

    for i, line in enumerate(lines, start=1):
        m = _MD_HEADING.match(line) if is_md else None
        if m:
            flush(i - 1)
            level = len(m.group(1)); txt = m.group(2).strip().rstrip("#").strip()
            while heading_stack and heading_stack[-1][0] >= level:
                heading_stack.pop()
            if txt:
                heading_stack.append((level, txt))
            continue
        if not line.strip():
            if buf_tokens >= CHUNK_TOKENS:  # blank line = block boundary; flush if full
                flush(i - 1)
            continue
        if buf_start is None:
            buf_start = i
        buf.append(line); buf_tokens += est_tokens(line)
        if buf_tokens >= CHUNK_TOKENS:
            flush(i)
    flush(len(lines))
    return chunks, len(lines)


# ------------------------------------------------------------------ HTML (stdlib html.parser)
_HEADING_TAGS = {"h1", "h2", "h3", "h4", "h5", "h6"}
_BLOCK_TAGS = {"p", "br", "div", "li", "tr", "section", "article", "header", "footer", "blockquote"}


class _HTMLStripper(HTMLParser):
    """Collect a stream of ('heading', level, text) and ('text', data) events, skipping
    script/style. Headings drive sectioning; text is the section body."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: List[tuple] = []
        self._skip = 0
        self._h_level = 0
        self._h_buf: List[str] = []

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1
        elif tag in _HEADING_TAGS:
            self._h_level = int(tag[1]); self._h_buf = []
        elif tag in _BLOCK_TAGS:
            self.parts.append(("text", "\n"))

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self._skip:
            self._skip -= 1
        elif tag in _HEADING_TAGS and self._h_level:
            self.parts.append(("heading", self._h_level, "".join(self._h_buf).strip()))
            self._h_level = 0; self._h_buf = []

    def handle_data(self, data):
        if self._skip:
            return
        if self._h_level:
            self._h_buf.append(data)
        else:
            self.parts.append(("text", data))


def _collapse_ws(s: str) -> str:
    s = re.sub(r"[ \t\r\f\v]+", " ", s)
    s = re.sub(r" *\n *", "\n", s)
    s = re.sub(r"\n{2,}", "\n", s)
    return s.strip()


def _strip_html_str(html: str) -> str:
    p = _HTMLStripper()
    try:
        p.feed(html)
    except Exception:
        pass
    out: List[str] = []
    for kind, *rest in p.parts:
        if kind == "heading":
            out.append("\n" + rest[1] + "\n")   # rest = [level, text]
        else:
            out.append(rest[0])                  # rest = [data]
    return _collapse_ws("".join(out))


def extract_html(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    """Strip tags (stdlib), chunk by heading section, anchor `§ <heading breadcrumb>`."""
    with open(path, encoding="utf-8", errors="replace") as f:
        html = f.read()
    p = _HTMLStripper()
    p.feed(html)

    chunks: List[Chunk] = []
    ordn = 0
    section = 0
    heading_stack: List[tuple] = []
    buf: List[str] = []
    buf_tokens = 0

    def heading_path() -> list:
        return [h for _, h in heading_stack]

    def flush():
        nonlocal ordn, section, buf, buf_tokens
        text = _collapse_ws("".join(buf))
        buf, buf_tokens = [], 0
        if not text:
            return
        hp = heading_path()
        label = ("§ " + " › ".join(hp)) if hp else f"Section {section + 1}"
        loc = Locator(
            doc_type="html", label=label, section_index=section,
            heading_path=(hp or None), quote=text[:200],
        )
        chunks.append(Chunk(doc_id, ordn, text, loc,
                           heading_context=" › ".join(hp), token_est=est_tokens(text)))
        ordn += 1; section += 1

    for kind, *rest in p.parts:
        if kind == "heading":
            level, htext = rest
            flush()
            while heading_stack and heading_stack[-1][0] >= level:
                heading_stack.pop()
            if htext:
                heading_stack.append((level, htext))
        else:
            data = rest[0]
            buf.append(data); buf_tokens += est_tokens(data)
            if buf_tokens >= CHUNK_TOKENS:
                flush()
    flush()
    return chunks, max(1, len(chunks))


# ------------------------------------------------------------------ EML (stdlib email)
def _eml_body(msg) -> str:
    """Prefer text/plain; fall back to stripped text/html. Skips attachments."""
    if msg.is_multipart():
        plain = html = None
        for part in msg.walk():
            if part.is_multipart():
                continue
            disp = (part.get("Content-Disposition") or "").lower()
            if "attachment" in disp:
                continue
            ctype = part.get_content_type()
            try:
                content = part.get_content()
            except Exception:
                continue
            if ctype == "text/plain" and plain is None:
                plain = content
            elif ctype == "text/html" and html is None:
                html = content
        if plain and plain.strip():
            return plain
        if html:
            return _strip_html_str(html)
        return ""
    try:
        content = msg.get_content()
    except Exception:
        content = msg.get_payload(decode=True)
        if isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")
        content = content or ""
    if msg.get_content_type() == "text/html":
        return _strip_html_str(content)
    return content or ""


def extract_eml(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    """Parse an .eml with the stdlib email module: index subject + from/to + body.
    Anchor `Email: <subject>`; long bodies split into ~CHUNK_TOKENS parts (part ordinal
    kept on the locator)."""
    with open(path, "rb") as f:
        msg = email.message_from_binary_file(f, policy=policy.default)

    subject = (msg.get("subject") or "").strip() or "(no subject)"
    header_lines = [f"Subject: {subject}"]
    for h in ("From", "To", "Cc", "Date"):
        v = msg.get(h)
        if v:
            header_lines.append(f"{h}: {str(v).strip()}")
    header_txt = "\n".join(header_lines)
    body = _collapse_ws(_eml_body(msg) or "")

    label_base = f"Email: {subject[:80]}"
    chunks: List[Chunk] = []
    ordn = 0

    # First chunk always carries the headers so the subject/sender are retrievable +
    # highlightable. Remaining body (if long) packs into continuation parts.
    para = [p for p in re.split(r"\n\s*\n", body) if p.strip()] or ([body] if body else [])
    buf: List[str] = [header_txt]
    buf_tokens = est_tokens(header_txt)

    def flush(part: int, cont: bool):
        nonlocal ordn
        text = "\n\n".join(x for x in buf if x.strip()).strip()
        if not text:
            return
        label = label_base + (" (cont.)" if cont else "")
        loc = Locator(doc_type="eml", label=label, section_index=part, quote=text[:200])
        chunks.append(Chunk(doc_id, ordn, text, loc, heading_context=subject,
                           token_est=est_tokens(text)))
        ordn += 1

    part = 0
    for blk in para:
        buf.append(blk); buf_tokens += est_tokens(blk)
        if buf_tokens >= CHUNK_TOKENS:
            flush(part, part > 0)
            part += 1; buf = []; buf_tokens = 0
    if buf and any(x.strip() for x in buf):
        flush(part, part > 0)
    if not chunks:  # header-only email (no body)
        flush(0, False)
    return chunks, 1


# ------------------------------------------------------------------ XLSX (openpyxl, optional)
def extract_xlsx(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    """One or more chunks per worksheet: the header row is repeated into every chunk for
    context, data rows pack to ~CHUNK_TOKENS. Anchor `Sheet: <name> (rows a-b)`."""
    from openpyxl import load_workbook

    wb = load_workbook(path, read_only=True, data_only=True)
    chunks: List[Chunk] = []
    ordn = 0

    def cell(v) -> str:
        return "" if v is None else str(v).strip()

    try:
        for ws in wb.worksheets:
            rows = [
                (ridx, row)
                for ridx, row in enumerate(ws.iter_rows(values_only=True), start=1)
                if any(cell(c) for c in row)
            ]
            if not rows:
                continue
            header_ridx, header = rows[0]
            header_txt = " | ".join(cell(c) for c in header)

            if len(rows) == 1:  # header-only sheet
                loc = Locator(doc_type="xlsx", label=f"Sheet: {ws.title} (row {header_ridx})",
                              sheet=ws.title, row_start=header_ridx, row_end=header_ridx,
                              quote=header_txt[:200])
                chunks.append(Chunk(doc_id, ordn, header_txt, loc,
                                   heading_context=f"Sheet: {ws.title}", token_est=est_tokens(header_txt)))
                ordn += 1
                continue

            buf: List[str] = []
            buf_start: int | None = None
            buf_tokens = 0

            def flush(end_row: int):
                nonlocal ordn, buf, buf_start, buf_tokens
                if not buf:
                    return
                text = header_txt + "\n" + "\n".join(buf)
                loc = Locator(doc_type="xlsx",
                              label=f"Sheet: {ws.title} (rows {buf_start}-{end_row})",
                              sheet=ws.title, row_start=buf_start, row_end=end_row,
                              quote=text[:200])
                chunks.append(Chunk(doc_id, ordn, text, loc,
                                   heading_context=f"Sheet: {ws.title}", token_est=est_tokens(text)))
                ordn += 1
                buf, buf_start, buf_tokens = [], None, 0

            for ridx, row in rows[1:]:
                line = " | ".join(cell(c) for c in row)
                if buf_start is None:
                    buf_start = ridx
                buf.append(line); buf_tokens += est_tokens(line)
                if buf_tokens >= CHUNK_TOKENS:
                    flush(ridx)
            flush(rows[-1][0])
    finally:
        wb.close()
    return chunks, len(wb.worksheets)


# ------------------------------------------------------------------ dispatcher
EXTRACTORS = {
    ".pdf": extract_pdf, ".pptx": extract_pptx, ".docx": extract_docx,
    ".txt": extract_text, ".md": extract_text, ".markdown": extract_text,
    ".html": extract_html, ".htm": extract_html, ".eml": extract_eml,
}
if _HAS_XLSX:
    EXTRACTORS[".xlsx"] = extract_xlsx

_EXT_TO_TYPE = {
    ".pdf": "pdf", ".pptx": "pptx", ".docx": "docx",
    ".txt": "txt", ".md": "md", ".markdown": "md",
    ".html": "html", ".htm": "html", ".eml": "eml",
}
if _HAS_XLSX:
    _EXT_TO_TYPE[".xlsx"] = "xlsx"


def doc_type_of(path: str) -> str:
    return _EXT_TO_TYPE.get(os.path.splitext(path)[1].lower(), "")


def extract(path: str, doc_id: str) -> Tuple[List[Chunk], int]:
    ext = os.path.splitext(path)[1].lower()
    fn = EXTRACTORS.get(ext)
    if not fn:
        raise ValueError(f"unsupported file type: {ext}")
    return fn(path, doc_id)
