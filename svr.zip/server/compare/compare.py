"""Structural + textual document comparison.

Turns each file into an ORDERED list of natural units (pptx -> slide, pdf -> page,
docx/txt/md/html -> section/paragraph block, xlsx -> sheet), then aligns A vs B and
classifies every unit as same / changed / added / removed with a word-level inline
diff inside changed pairs. An LLM turns the raw change set into an executive summary.

The extraction is reused verbatim from the Document Management tool (extract.py),
so the same anchor-preserving unit boundaries drive the diff.
"""
from __future__ import annotations

import difflib
import json
import os
import re
from typing import List, Dict, Any, Optional

from .extract import extract

# similarity below which a replace-block pair is treated as remove+add rather than
# an in-place edit of the same unit.
_CHANGE_THRESHOLD = 0.35
_WORD_RE = re.compile(r"\S+|\s+")


# ---------------------------------------------------------------- unit extraction
def _unit_key(loc: dict) -> Optional[str]:
    """The natural-unit identity a chunk belongs to. Consecutive chunks sharing a key
    are merged into one comparable unit (one slide / page / sheet)."""
    if loc.get("slide_index") is not None:
        return f"slide:{loc['slide_index']}"
    if loc.get("page") is not None:
        return f"page:{loc['page']}"
    if loc.get("sheet") is not None:
        return f"sheet:{loc['sheet']}"
    return None  # docx/txt/md/html/eml — each chunk is already its own section unit


def extract_units(path: str) -> List[Dict[str, Any]]:
    """file -> ordered [{label, text}]. Groups extractor chunks by their natural unit
    so a slide/page/sheet is one comparable block even if it produced several chunks."""
    chunks, _ = extract(path, "cmp")
    units: List[Dict[str, Any]] = []
    for ch in chunks:
        d = ch.to_dict()
        loc = d.get("locator", {})
        label = loc.get("label") or f"Unit {len(units) + 1}"
        key = _unit_key(loc)
        text = (d.get("text") or "").strip()
        if key is not None and units and units[-1].get("_key") == key:
            units[-1]["text"] = (units[-1]["text"] + "\n" + text).strip()
        else:
            units.append({"label": label, "text": text, "_key": key})
    for u in units:
        u.pop("_key", None)
    return units


# ---------------------------------------------------------------- inline word diff
def _tokens(s: str) -> List[str]:
    return _WORD_RE.findall(s or "")


def _inline_segments(a_text: str, b_text: str):
    """Word-level diff -> (a_segments, b_segments). Each segment is
    {text, mark}: on A side mark in {same, del}; on B side {same, ins}."""
    a_tok, b_tok = _tokens(a_text), _tokens(b_text)
    sm = difflib.SequenceMatcher(None, a_tok, b_tok, autojunk=False)
    a_seg: List[dict] = []
    b_seg: List[dict] = []

    def push(seg, text, mark):
        if not text:
            return
        if seg and seg[-1]["mark"] == mark:
            seg[-1]["text"] += text
        else:
            seg.append({"text": text, "mark": mark})

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        a_part = "".join(a_tok[i1:i2])
        b_part = "".join(b_tok[j1:j2])
        if tag == "equal":
            push(a_seg, a_part, "same")
            push(b_seg, b_part, "same")
        elif tag == "delete":
            push(a_seg, a_part, "del")
        elif tag == "insert":
            push(b_seg, b_part, "ins")
        else:  # replace
            push(a_seg, a_part, "del")
            push(b_seg, b_part, "ins")
    return a_seg, b_seg


def _ratio(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a or "", b or "", autojunk=False).ratio()


# ---------------------------------------------------------------- alignment
def _match_replace_block(a_units, b_units, a_range, b_range, out):
    """Align a replace block: greedily pair the most-similar A/B units (>= threshold)
    as 'changed'; leftovers become 'removed' (A) / 'added' (B)."""
    pairs = []
    for ia in a_range:
        for ib in b_range:
            pairs.append((_ratio(a_units[ia]["text"], b_units[ib]["text"]), ia, ib))
    pairs.sort(reverse=True)
    used_a, used_b = set(), set()
    matched = []  # (ia, ib)
    for r, ia, ib in pairs:
        if r < _CHANGE_THRESHOLD:
            break
        if ia in used_a or ib in used_b:
            continue
        used_a.add(ia); used_b.add(ib)
        matched.append((ia, ib))
    # emit in original A order, interleaving added B units by their position
    remaining_b = [ib for ib in b_range if ib not in used_b]
    match_by_a = {ia: ib for ia, ib in matched}
    for ia in a_range:
        if ia in match_by_a:
            ib = match_by_a[ia]
            out.append(_pair_entry(a_units[ia], b_units[ib], ia))
        elif ia in used_a:
            continue
        else:
            out.append(_solo_entry(a_units[ia], "removed", ia))
    for ib in remaining_b:
        out.append(_solo_entry(b_units[ib], "added", ib))


def _pair_entry(a_unit, b_unit, index):
    same = a_unit["text"] == b_unit["text"]
    status = "same" if same else "changed"
    a_seg, b_seg = ([], []) if same else _inline_segments(a_unit["text"], b_unit["text"])
    label = b_unit["label"] or a_unit["label"]
    if a_unit["label"] and b_unit["label"] and a_unit["label"] != b_unit["label"]:
        label = f"{a_unit['label']} → {b_unit['label']}"
    return {
        "index": index, "status": status, "label": label,
        "a_text": a_unit["text"], "b_text": b_unit["text"],
        "a_segments": a_seg, "b_segments": b_seg,
        "similarity": round(_ratio(a_unit["text"], b_unit["text"]), 3),
    }


def _solo_entry(unit, status, index):
    if status == "added":
        seg = [{"text": unit["text"], "mark": "ins"}] if unit["text"] else []
        return {"index": index, "status": status, "label": unit["label"],
                "a_text": "", "b_text": unit["text"],
                "a_segments": [], "b_segments": seg, "similarity": 0.0}
    seg = [{"text": unit["text"], "mark": "del"}] if unit["text"] else []
    return {"index": index, "status": status, "label": unit["label"],
            "a_text": unit["text"], "b_text": "",
            "a_segments": seg, "b_segments": [], "similarity": 0.0}


def align_units(a_units, b_units) -> List[Dict[str, Any]]:
    """Order-preserving alignment via difflib opcodes over the unit texts. Equal blocks
    pair 1:1 (same); replace blocks are similarity-matched into changed/added/removed;
    delete/insert blocks become removed/added."""
    a_texts = [u["text"] for u in a_units]
    b_texts = [u["text"] for u in b_units]
    sm = difflib.SequenceMatcher(None, a_texts, b_texts, autojunk=False)
    out: List[Dict[str, Any]] = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                out.append(_pair_entry(a_units[i1 + k], b_units[j1 + k], i1 + k))
        elif tag == "delete":
            for ia in range(i1, i2):
                out.append(_solo_entry(a_units[ia], "removed", ia))
        elif tag == "insert":
            for ib in range(j1, j2):
                out.append(_solo_entry(b_units[ib], "added", ib))
        else:  # replace
            _match_replace_block(a_units, b_units, range(i1, i2), range(j1, j2), out)
    return out


# ---------------------------------------------------------------- AI summary
def _clip(s: str, n: int = 900) -> str:
    s = re.sub(r"\s+", " ", s or "").strip()
    return s if len(s) <= n else s[:n] + " …"


def _build_change_brief(diff: List[dict]) -> str:
    lines = []
    for d in diff:
        if d["status"] == "same":
            continue
        tag = {"added": "ADDED", "removed": "REMOVED", "changed": "CHANGED"}[d["status"]]
        lines.append(f"[{tag}] {d['label']}")
        if d["status"] == "changed":
            lines.append(f"  BEFORE: {_clip(d['a_text'], 700)}")
            lines.append(f"  AFTER:  {_clip(d['b_text'], 700)}")
        elif d["status"] == "added":
            lines.append(f"  CONTENT: {_clip(d['b_text'], 700)}")
        else:
            lines.append(f"  CONTENT: {_clip(d['a_text'], 700)}")
    return "\n".join(lines)


def ai_summary(diff: List[dict], a_name: str, b_name: str) -> Dict[str, Any]:
    """Ask GPT-OSS for an executive summary of WHAT changed and its materiality.
    Degrades gracefully to a deterministic summary if the LLM is unreachable."""
    changes = [d for d in diff if d["status"] != "same"]
    if not changes:
        return {"summary": "No material differences: the two documents are identical "
                           "across every compared unit.", "key_changes": []}
    brief = _build_change_brief(diff)
    sys_msg = (
        "You are a meticulous document-comparison analyst. You are given the structural "
        "diff between two versions of a document (A = older/left, B = newer/right). "
        "Write a concise EXECUTIVE summary of what changed and, crucially, its MATERIALITY "
        "-- call out changes to numbers, pricing, dates, names, scope, risks, and added or "
        "removed sections. Be specific (cite the actual before/after values). "
        "Respond ONLY as strict JSON: "
        '{"summary": "<2-4 sentence prose>", "key_changes": ["<short bullet>", ...]}. '
        "5-8 key_changes max, each one line, most material first."
    )
    user_msg = f"Document A: {a_name}\nDocument B: {b_name}\n\nSTRUCTURAL DIFF:\n{brief}"
    try:
        from .llm import chat
        raw = chat([{"role": "system", "content": sys_msg},
                    {"role": "user", "content": user_msg}],
                   temperature=0.2, max_tokens=1100)
        parsed = _parse_json(raw)
        if parsed and parsed.get("summary"):
            kc = parsed.get("key_changes") or []
            if not isinstance(kc, list):
                kc = [str(kc)]
            return {"summary": str(parsed["summary"]).strip(),
                    "key_changes": [str(x).strip() for x in kc if str(x).strip()]}
        if raw.strip():
            return {"summary": raw.strip(), "key_changes": []}
    except Exception as e:  # noqa: BLE001
        return _fallback_summary(diff, note=f"(AI summary unavailable: {e})")
    return _fallback_summary(diff)


def _parse_json(raw: str) -> Optional[dict]:
    if not raw:
        return None
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:  # noqa: BLE001
        return None


def _fallback_summary(diff: List[dict], note: str = "") -> Dict[str, Any]:
    c = _counts(diff)
    key = []
    for d in diff:
        if d["status"] == "changed":
            key.append(f"{d['label']}: content edited")
        elif d["status"] == "added":
            key.append(f"{d['label']}: added")
        elif d["status"] == "removed":
            key.append(f"{d['label']}: removed")
        if len(key) >= 8:
            break
    summary = (f"{c['changed']} unit(s) changed, {c['added']} added, {c['removed']} removed, "
               f"{c['same']} unchanged. {note}").strip()
    return {"summary": summary, "key_changes": key}


# ---------------------------------------------------------------- top level
def _counts(diff: List[dict]) -> Dict[str, int]:
    c = {"same": 0, "changed": 0, "added": 0, "removed": 0}
    for d in diff:
        c[d["status"]] += 1
    return c


def compare_files(path_a: str, path_b: str, name_a: str = "", name_b: str = "",
                  with_summary: bool = True) -> Dict[str, Any]:
    """Full comparison: extract -> align -> summarize."""
    name_a = name_a or os.path.basename(path_a)
    name_b = name_b or os.path.basename(path_b)
    a_units = extract_units(path_a)
    b_units = extract_units(path_b)
    diff = align_units(a_units, b_units)
    counts = _counts(diff)
    summary = ai_summary(diff, name_a, name_b) if with_summary else {"summary": "", "key_changes": []}
    return {
        "a": {"name": name_a, "units": len(a_units)},
        "b": {"name": name_b, "units": len(b_units)},
        "counts": counts,
        "summary": summary["summary"],
        "key_changes": summary["key_changes"],
        "diff": diff,
    }
