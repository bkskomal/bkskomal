"""Files Comparison API + UI — compare two documents and show what changed + an AI summary.

Standalone tool (suite app #4). One FastAPI app that serves both the JSON API and its own
inline HTML/JS UI (no npm / Next build). Comparison is fully local + stateless; only the
executive-summary step calls the shared GPT-OSS chat backend.

Run:  cd service && python -m uvicorn app:app --port 8940
"""
from __future__ import annotations

import os
import tempfile
from typing import Optional

import httpx
from fastapi import FastAPI, UploadFile, File, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from .compare import compare_files
from .extract import EXTRACTORS

app = FastAPI(title="Files Comparison")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

SUPPORTED = sorted(EXTRACTORS.keys())

# The suite Hub is the identity authority. We are a verified SSO consumer: OATIGenie
# hands off a short-lived token via ?sso=<t>, which we redeem server-side here.
HUB_BASE = os.environ.get("HUB_BASE", "http://localhost:8900").rstrip("/")


@app.get("/sso")
async def sso(token: str = ""):
    """Verify a Hub SSO handoff token server-side. Returns {"username": u} (200) or 401.

    Comparison is stateless, so identity is purely displayed (no enforcement) — this
    route just lets the frontend trust a username the Hub vouches for instead of any
    client-supplied ?identity string."""
    token = (token or "").strip()
    if not token:
        raise HTTPException(401, "missing sso token")
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get(f"{HUB_BASE}/api/sso/verify", params={"token": token})
    except httpx.HTTPError as e:
        raise HTTPException(502, f"hub unreachable: {e}")
    if r.status_code != 200:
        raise HTTPException(401, "invalid or expired sso token")
    username = (r.json() or {}).get("username")
    if not username:
        raise HTTPException(401, "invalid or expired sso token")
    return {"username": username}


@app.get("/health")
def health(identity: str = "", x_fc_user: Optional[str] = Header(None)):
    return {"ok": True, "service": "files-comparison", "port": 8940,
            "supported": SUPPORTED, "identity": (x_fc_user or identity or "").strip() or None}


@app.get("/api/me")
def me(identity: str = "", x_fc_user: Optional[str] = Header(None)):
    """Echo the caller identity the hub forwards. Comparison is stateless, so this is
    purely for suite-wide identity continuity (no enforcement)."""
    return {"identity": (x_fc_user or identity or "").strip() or None}


async def _spool(upload: UploadFile) -> str:
    suffix = os.path.splitext(upload.filename or "")[1].lower()
    if suffix not in EXTRACTORS:
        raise HTTPException(415, f"unsupported file type: {suffix or '(none)'}. "
                                 f"Supported: {', '.join(SUPPORTED)}")
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(await upload.read())
        return tmp.name


@app.post("/compare")
async def compare(a: UploadFile = File(...), b: UploadFile = File(...),
                  identity: str = "", x_fc_user: Optional[str] = Header(None)):
    """Compare two uploaded files. Returns per-unit diff + AI executive summary + counts."""
    pa = await _spool(a)
    pb = await _spool(b)
    try:
        return compare_files(pa, pb,
                             name_a=a.filename or "A", name_b=b.filename or "B")
    except Exception as e:  # noqa: BLE001
        raise HTTPException(500, f"comparison failed: {e}")
    finally:
        for p in (pa, pb):
            try:
                os.unlink(p)
            except OSError:
                pass


@app.get("/", response_class=HTMLResponse)
def index():
    return HTMLResponse(INDEX_HTML)


# ------------------------------------------------------------------ inline UI
INDEX_HTML = r"""<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Files Comparison</title>
<script>
/* set theme before first paint to avoid flash */
(function(){try{var t=localStorage.getItem('theme');
  if(!t)t=(window.matchMedia&&window.matchMedia('(prefers-color-scheme: light)').matches)?'light':'dark';
  document.documentElement.dataset.theme=t;}catch(e){document.documentElement.dataset.theme='dark';}})();
</script>
<style>
:root{
  --bg:#0a0b0f; --bg-2:#0e1016; --surface:#14161f; --surface-2:#1a1d29; --surface-3:#22273a;
  --border:rgba(255,255,255,.07); --border-strong:rgba(255,255,255,.12);
  --text:#eef0f6; --text-2:#a9afc3; --muted:#6b7189;
  --accent:#6366f1; --accent-2:#8b5cf6; --cyan:#22d3ee; --success:#34d399; --warn:#fbbf24; --danger:#f87171;
  --grad:linear-gradient(135deg,var(--accent),var(--accent-2));
  --radius-sm:8px; --radius:12px; --radius-lg:16px;
  --shadow:0 2px 8px rgba(0,0,0,.35),0 12px 32px rgba(0,0,0,.30);
  --highlight:inset 0 1px 0 rgba(255,255,255,.04);
  --ring:0 0 0 3px rgba(99,102,241,.35);
  /* diff palette (dark) */
  --add:var(--success); --add-bg:rgba(52,211,153,.14); --add-strong:rgba(52,211,153,.36); --add-ink:#7ff0c4;
  --rem:var(--danger); --rem-bg:rgba(248,113,113,.15); --rem-strong:rgba(248,113,113,.38); --rem-ink:#ffb4ae;
  --chg:var(--warn); --chg-bg:rgba(251,191,36,.14); --chg-strong:rgba(251,191,36,.36);
  --same:var(--muted); --same-bg:rgba(107,113,137,.16);
}
:root[data-theme="light"]{
  --bg:#f7f8fc; --bg-2:#eef0f7; --surface:#fff; --surface-2:#f4f5fa; --surface-3:#e9ebf3;
  --border:rgba(17,20,45,.10); --border-strong:rgba(17,20,45,.18);
  --text:#12141c; --text-2:#464c63; --muted:#868ca3;
  --accent:#6366f1; --accent-2:#8b5cf6; --cyan:#0891b2; --success:#059669; --warn:#d97706; --danger:#dc2626;
  --shadow:0 2px 8px rgba(20,22,40,.08),0 12px 32px rgba(20,22,40,.10);
  --highlight:inset 0 1px 0 rgba(255,255,255,.6);
  --ring:0 0 0 3px rgba(99,102,241,.28);
  /* diff palette (light) */
  --add:var(--success); --add-bg:rgba(5,150,105,.12); --add-strong:rgba(5,150,105,.30); --add-ink:#065f46;
  --rem:var(--danger); --rem-bg:rgba(220,38,38,.10); --rem-strong:rgba(220,38,38,.28); --rem-ink:#991b1b;
  --chg:var(--warn); --chg-bg:rgba(217,119,6,.12); --chg-strong:rgba(217,119,6,.30);
  --same:var(--muted); --same-bg:rgba(134,140,163,.14);
}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;color:var(--text);
  background:
    radial-gradient(1200px 600px at 12% -8%,color-mix(in srgb,var(--accent) 14%,transparent),transparent 60%),
    radial-gradient(1000px 560px at 100% 0%,color-mix(in srgb,var(--accent-2) 12%,transparent),transparent 55%),
    linear-gradient(180deg,var(--bg-2),var(--bg));
  background-attachment:fixed;
  font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  -webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}
a{color:var(--accent);text-decoration:none}
::selection{background:color-mix(in srgb,var(--accent) 40%,transparent)}
*{scrollbar-width:thin;scrollbar-color:var(--border-strong) transparent}
::-webkit-scrollbar{width:9px;height:9px}
::-webkit-scrollbar-thumb{background:var(--border-strong);border-radius:20px;border:2px solid transparent;background-clip:padding-box}
::-webkit-scrollbar-thumb:hover{background:var(--muted);background-clip:padding-box}
::-webkit-scrollbar-track{background:transparent}
.wrap{max-width:1200px;margin:0 auto;padding:22px 22px 90px}
@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.mount{animation:rise .32s cubic-bezier(.22,.61,.36,1) both}

/* ---- top bar ---- */
.topbar{display:flex;align-items:center;gap:14px;
  background:linear-gradient(180deg,color-mix(in srgb,var(--surface) 90%,transparent),color-mix(in srgb,var(--surface-2) 90%,transparent));
  border:1px solid var(--border);border-radius:var(--radius-lg);
  padding:14px 18px;box-shadow:var(--shadow),var(--highlight);backdrop-filter:blur(12px);margin-bottom:22px}
.brand{display:flex;align-items:center;gap:12px;min-width:0}
.logo{width:38px;height:38px;border-radius:11px;flex:none;display:grid;place-items:center;
  background:var(--grad);box-shadow:0 6px 18px color-mix(in srgb,var(--accent) 45%,transparent),var(--highlight);color:#fff}
.logo svg{width:20px;height:20px}
.brand .txt{min-width:0}
h1{font-size:17px;margin:0;font-weight:680;letter-spacing:.2px;line-height:1.2}
.sub{color:var(--text-2);font-size:12.5px}
.spacer{margin-left:auto}
.theme-toggle{width:44px;height:44px;border-radius:12px;border:1px solid var(--border-strong);
  background:var(--surface-2);color:var(--text);cursor:pointer;display:grid;place-items:center;
  transition:transform .18s cubic-bezier(.22,.61,.36,1),background .18s,border-color .18s,box-shadow .18s}
.theme-toggle:hover{background:var(--surface-3);border-color:var(--accent);transform:translateY(-1px)}
.theme-toggle:active{transform:translateY(0)}
.theme-toggle:focus-visible{outline:none;box-shadow:var(--ring)}
.theme-toggle svg{width:20px;height:20px}
.theme-toggle .moon{display:none}
:root[data-theme="light"] .theme-toggle .sun{display:none}
:root[data-theme="light"] .theme-toggle .moon{display:block}

/* ---- identity chip ---- */
.idchip{display:none;align-items:center;gap:9px;padding:7px 8px 7px 12px;border-radius:20px;
  background:color-mix(in srgb,var(--surface-3) 70%,transparent);border:1px solid var(--border-strong);
  box-shadow:var(--highlight);font-size:12.5px;color:var(--text-2);max-width:280px}
.idchip.on{display:inline-flex}
.idchip .who{display:inline-flex;align-items:center;gap:7px;min-width:0}
.idchip .dot{width:7px;height:7px;border-radius:50%;background:var(--success);flex:none;
  box-shadow:0 0 0 3px color-mix(in srgb,var(--success) 25%,transparent)}
.idchip .who b{color:var(--text);font-weight:640;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.idchip .sep{color:var(--border-strong)}
.idchip .signout{background:var(--surface-2);color:var(--text-2);border:1px solid var(--border-strong);
  border-radius:14px;padding:4px 11px;font-size:12px;font-weight:550;cursor:pointer;transition:.16s;line-height:1.3}
.idchip .signout:hover{color:var(--text);border-color:var(--danger);background:var(--surface-3)}
.idchip .signout:focus-visible{outline:none;box-shadow:var(--ring)}
.signin{display:none;align-items:center;gap:6px;font-size:12.5px;color:var(--muted);padding:7px 12px;
  border-radius:20px;border:1px solid var(--border);background:color-mix(in srgb,var(--surface-2) 60%,transparent)}
.signin.on{display:inline-flex}
.signin a{color:var(--accent);font-weight:600}
.signin svg{width:14px;height:14px;opacity:.8}

.hint{color:var(--muted);font-size:12px;margin:0 2px 18px;letter-spacing:.2px}
.hint b{color:var(--text-2);font-weight:600}

/* ---- drop zones ---- */
.drops{display:grid;grid-template-columns:1fr auto 1fr;gap:16px;align-items:stretch}
.drop{position:relative;background:linear-gradient(180deg,var(--surface),var(--surface-2));
  border:1.5px dashed var(--border-strong);border-radius:var(--radius-lg);
  padding:26px 20px;text-align:center;cursor:pointer;min-height:150px;
  display:flex;flex-direction:column;justify-content:center;align-items:center;gap:8px;
  transition:border-color .18s,background .18s,box-shadow .18s,transform .18s;box-shadow:var(--highlight)}
.drop:hover{border-color:var(--accent);transform:translateY(-2px);box-shadow:var(--shadow),var(--highlight)}
.drop.over{border-color:var(--accent);border-style:solid;box-shadow:var(--ring),var(--shadow);
  background:linear-gradient(180deg,var(--surface-2),var(--surface-3));transform:translateY(-2px)}
.drop.filled{border-style:solid;border-color:var(--border-strong);background:linear-gradient(180deg,var(--surface),var(--surface-2))}
.drop .ic{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;flex:none;
  background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent);transition:transform .18s}
.drop:hover .ic{transform:scale(1.06)}
.drop .ic svg{width:20px;height:20px}
.drop .tag{font-size:10.5px;letter-spacing:1.6px;color:var(--muted);text-transform:uppercase;font-weight:700}
.drop .fname{font-weight:600;word-break:break-all;color:var(--text);max-width:100%}
.drop.filled .fname{display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:20px;
  background:color-mix(in srgb,var(--accent) 14%,transparent);border:1px solid color-mix(in srgb,var(--accent) 30%,transparent);
  color:var(--text);font-size:13px}
.drop.filled .fname::before{content:"";width:7px;height:7px;border-radius:50%;background:var(--success);flex:none;
  box-shadow:0 0 0 3px color-mix(in srgb,var(--success) 25%,transparent)}
.drop .meta{font-size:12px;color:var(--text-2)}
.vs{align-self:center;color:var(--muted);font-weight:800;font-size:11px;letter-spacing:2px;
  padding:8px 4px;border-radius:20px}

/* ---- action bar ---- */
.bar{display:flex;align-items:center;gap:14px;margin:22px 0 4px}
button.go{position:relative;background:var(--grad);color:#fff;border:0;border-radius:11px;padding:12px 30px;
  font-size:14px;font-weight:650;letter-spacing:.2px;cursor:pointer;
  box-shadow:0 8px 22px color-mix(in srgb,var(--accent) 40%,transparent),var(--highlight);
  transition:transform .18s,box-shadow .18s,opacity .18s}
button.go:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 12px 28px color-mix(in srgb,var(--accent) 50%,transparent),var(--highlight)}
button.go:active:not(:disabled){transform:translateY(0)}
button.go:disabled{opacity:.4;cursor:not-allowed;box-shadow:none}
button.go.loading{color:transparent}
button.go.loading::after{content:"";position:absolute;inset:0;margin:auto;width:16px;height:16px;
  border:2px solid rgba(255,255,255,.4);border-top-color:#fff;border-radius:50%;animation:sp .7s linear infinite}
button.ghost{background:var(--surface-2);color:var(--text-2);border:1px solid var(--border-strong);
  border-radius:11px;padding:11px 18px;cursor:pointer;font-size:13px;font-weight:500;transition:.18s}
button.ghost:hover{color:var(--text);border-color:var(--accent);background:var(--surface-3)}
button:focus-visible{outline:none;box-shadow:var(--ring)}
.status{color:var(--text-2);font-size:13px;display:inline-flex;align-items:center;gap:8px}
.spin{display:inline-block;width:14px;height:14px;border:2px solid var(--border-strong);
  border-top-color:var(--accent);border-radius:50%;animation:sp .7s linear infinite;vertical-align:-2px}
@keyframes sp{to{transform:rotate(360deg)}}

/* ---- cards ---- */
.card{background:linear-gradient(180deg,var(--surface),var(--surface-2));
  border:1px solid var(--border);border-radius:var(--radius-lg);padding:20px 22px;margin-top:18px;
  box-shadow:var(--shadow),var(--highlight)}
.card h2{margin:0 0 12px;font-size:14px;font-weight:680;color:var(--text);display:flex;gap:9px;align-items:center;
  letter-spacing:.2px}
.card h2 .badge{width:26px;height:26px;border-radius:8px;display:grid;place-items:center;flex:none;
  background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent)}
.card h2 .badge svg{width:15px;height:15px}
.summary{white-space:pre-wrap;color:var(--text);font-size:14.5px;line-height:1.62}
.chips{display:flex;gap:9px;flex-wrap:wrap;margin:16px 0 2px}
.chip{border-radius:20px;padding:5px 13px;font-size:12.5px;font-weight:650;border:1px solid transparent;
  display:inline-flex;align-items:center;gap:5px}
.chip.add{color:var(--add);background:var(--add-bg);border-color:var(--add-strong)}
.chip.rem{color:var(--rem);background:var(--rem-bg);border-color:var(--rem-strong)}
.chip.chg{color:var(--chg);background:var(--chg-bg);border-color:var(--chg-strong)}
.chip.same{color:var(--text-2);background:var(--same-bg);border-color:var(--border-strong)}
ul.keys{margin:14px 0 0;padding:0;list-style:none;display:flex;flex-direction:column;gap:7px}
ul.keys li{position:relative;padding-left:22px;color:var(--text-2);line-height:1.5}
ul.keys li::before{content:"";position:absolute;left:4px;top:8px;width:7px;height:7px;border-radius:2px;
  background:var(--grad);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 18%,transparent)}
.metaline{margin-top:14px;padding-top:14px;border-top:1px solid var(--border);
  color:var(--muted);font-size:12px}
.metaline b{color:var(--text-2);font-weight:600}

/* ---- tools ---- */
.tools{display:flex;gap:14px;align-items:center;margin:22px 2px 10px}
.switch{display:inline-flex;align-items:center;gap:9px;color:var(--text-2);font-size:13px;cursor:pointer;user-select:none}
.switch input{position:absolute;opacity:0;width:0;height:0}
.switch .track{width:38px;height:22px;border-radius:20px;background:var(--surface-3);border:1px solid var(--border-strong);
  position:relative;transition:.18s;flex:none}
.switch .track::after{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;
  background:var(--muted);transition:.18s}
.switch input:checked + .track{background:var(--grad);border-color:transparent}
.switch input:checked + .track::after{transform:translateX(16px);background:#fff}
.switch input:focus-visible + .track{box-shadow:var(--ring)}

/* ---- diff rows ---- */
.rows{display:flex;flex-direction:column;gap:11px}
.row{border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;
  background:linear-gradient(180deg,var(--surface),var(--surface-2));box-shadow:var(--highlight);
  transition:border-color .18s,box-shadow .18s}
.row:hover{border-color:var(--border-strong)}
.row.is-same{opacity:.85}
.rhead{display:flex;align-items:center;gap:11px;padding:11px 16px;cursor:pointer;
  border-left:4px solid var(--same);transition:background .18s}
.rhead:hover{background:color-mix(in srgb,var(--surface-3) 60%,transparent)}
.row.changed .rhead{border-left-color:var(--chg)}
.row.added .rhead{border-left-color:var(--add)}
.row.removed .rhead{border-left-color:var(--rem)}
.rhead .caret{width:16px;height:16px;color:var(--muted);flex:none;transition:transform .2s}
.row.collapsed .rhead .caret{transform:rotate(-90deg)}
.rhead .lbl{font-weight:640;font-size:13.5px;color:var(--text)}
.rhead .st{font-size:10.5px;letter-spacing:.6px;text-transform:uppercase;font-weight:750;
  padding:3px 9px;border-radius:6px}
.st.changed{color:var(--chg);background:var(--chg-bg)}
.st.added{color:var(--add);background:var(--add-bg)}
.st.removed{color:var(--rem);background:var(--rem-bg)}
.st.same{color:var(--text-2);background:var(--same-bg)}
.rhead .sim{margin-left:auto;color:var(--muted);font-size:11.5px;font-variant-numeric:tabular-nums}
.rbody{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:1px solid var(--border)}
.side{padding:14px 16px;font-size:13px;white-space:pre-wrap;word-break:break-word;
  line-height:1.6;max-height:420px;overflow:auto;color:var(--text)}
.side.a{border-right:1px solid var(--border)}
.side .cap{font-size:10px;letter-spacing:1.2px;color:var(--muted);text-transform:uppercase;font-weight:700;
  display:block;margin-bottom:8px}
.side.empty{color:var(--muted);font-style:italic}
del{background:var(--rem-bg);color:var(--rem-ink);text-decoration:line-through;
  text-decoration-color:color-mix(in srgb,var(--rem) 60%,transparent);border-radius:4px;padding:0 2px}
ins{background:var(--add-bg);color:var(--add-ink);text-decoration:none;border-radius:4px;padding:0 2px}
.row.collapsed .rbody{display:none}
.empty-note{color:var(--text-2);text-align:center;padding:26px}
.err{color:var(--rem);background:var(--rem-bg);border:1px solid var(--rem-strong);
  border-radius:var(--radius);padding:13px 16px;margin-top:16px;font-weight:500}
</style></head>
<body><div class="wrap">
<div class="topbar mount">
  <div class="brand">
    <span class="logo" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h4"/><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M12 3v18"/><path d="M8 8l-2 2 2 2"/><path d="M16 8l2 2-2 2"/></svg></span>
    <span class="txt">
      <h1>Files Comparison</h1>
      <span class="sub">what changed between two documents, with an AI summary</span>
    </span>
  </div>
  <span class="spacer"></span>
  <span class="idchip" id="idchip">
    <span class="who"><span class="dot"></span>signed in as&nbsp;<b id="idname"></b></span>
    <span class="sep">·</span>
    <button class="signout" id="signout" title="Sign out">sign out</button>
  </span>
  <span class="signin" id="signin">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/></svg>
    <a href="http://localhost:3000">Sign in via OATIGenie</a>
  </span>
  <button class="theme-toggle" id="themeToggle" title="Toggle theme" aria-label="Toggle light/dark theme">
    <svg class="sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
    <svg class="moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
  </button>
</div>

<div class="hint mount">Supported: <b>pptx</b> · <b>pdf</b> · <b>docx</b> · <b>xlsx</b> · <b>txt</b> · <b>md</b> · <b>html</b> · <b>eml</b> — compare same or different types</div>

<div class="drops mount">
  <div class="drop" id="dropA" data-side="a">
    <span class="ic" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></span>
    <span class="tag">File A · older / left</span>
    <span class="fname" data-role="name">Drop a file or click</span>
    <span class="meta" data-role="meta"></span>
  </div>
  <div class="vs">VS</div>
  <div class="drop" id="dropB" data-side="b">
    <span class="ic" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></span>
    <span class="tag">File B · newer / right</span>
    <span class="fname" data-role="name">Drop a file or click</span>
    <span class="meta" data-role="meta"></span>
  </div>
</div>
<input type="file" id="fileA" hidden><input type="file" id="fileB" hidden>

<div class="bar mount">
  <button class="go" id="go" disabled>Compare</button>
  <button class="ghost" id="reset">Reset</button>
  <span class="status" id="status"></span>
</div>

<div id="results"></div>
</div>

<script>
const SUP = ["pptx","pdf","docx","xlsx","txt","md","markdown","html","htm","eml"];
/* theme toggle */
(function(){
  const btn=document.getElementById('themeToggle');
  btn.onclick=function(){
    const next=document.documentElement.dataset.theme==='light'?'dark':'light';
    document.documentElement.dataset.theme=next;
    try{localStorage.setItem('theme',next);}catch(e){}
  };
})();
const files = {a:null, b:null};
const $ = s => document.querySelector(s);

/* ---- suite SSO (verified consumer of the Hub via OATIGenie) ---- */
const OATIGENIE = "http://localhost:3000";
function renderIdentity(user){
  const chip=$("#idchip"), signin=$("#signin");
  if(user){
    $("#idname").textContent=user;
    chip.classList.add("on"); signin.classList.remove("on");
  }else{
    chip.classList.remove("on"); signin.classList.add("on");
  }
}
$("#signout").onclick=function(){
  try{localStorage.removeItem('fc_identity');}catch(e){}
  location.href=OATIGENIE;
};
(async function adoptIdentity(){
  const q=new URLSearchParams(location.search);
  const sso=q.get('sso'), legacy=q.get('identity');
  let user=null;
  if(sso){
    try{
      const r=await fetch('/sso?token='+encodeURIComponent(sso));
      if(r.ok){ user=(await r.json()).username||null; }
    }catch(e){}
  }
  if(!user && legacy){ user=legacy.trim()||null; }        // legacy ?identity fallback
  if(user){ try{localStorage.setItem('fc_identity',user);}catch(e){} }
  else{ try{user=localStorage.getItem('fc_identity')||null;}catch(e){} }
  if(sso||legacy){                                          // scrub identity params from URL
    q.delete('sso'); q.delete('identity');
    const qs=q.toString();
    history.replaceState(null,'',location.pathname+(qs?'?'+qs:'')+location.hash);
  }
  renderIdentity(user);
})();

function fmtSize(n){ if(n<1024) return n+" B"; if(n<1048576) return (n/1024).toFixed(1)+" KB"; return (n/1048576).toFixed(1)+" MB"; }

function setFile(side, f){
  files[side]=f;
  const drop = $("#drop"+side.toUpperCase());
  drop.classList.toggle("filled", !!f);
  drop.querySelector('[data-role=name]').textContent = f ? f.name : "Drop a file or click";
  drop.querySelector('[data-role=meta]').textContent = f ? fmtSize(f.size) : "";
  $("#go").disabled = !(files.a && files.b);
}

function wire(side){
  const drop = $("#drop"+side.toUpperCase());
  const input = $("#file"+side.toUpperCase());
  drop.onclick = ()=> input.click();
  input.onchange = ()=> input.files[0] && setFile(side, input.files[0]);
  drop.ondragover = e=>{e.preventDefault(); drop.classList.add("over");};
  drop.ondragleave = ()=> drop.classList.remove("over");
  drop.ondrop = e=>{e.preventDefault(); drop.classList.remove("over");
    if(e.dataTransfer.files[0]) setFile(side, e.dataTransfer.files[0]);};
}
wire("a"); wire("b");

$("#reset").onclick = ()=>{ setFile("a",null); setFile("b",null); $("#results").innerHTML=""; $("#status").textContent=""; };

function esc(s){ return (s||"").replace(/[&<>]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
function segHtml(segs, side){
  if(!segs || !segs.length) return "";
  return segs.map(s=>{
    const t = esc(s.text);
    if(s.mark==="del") return "<del>"+t+"</del>";
    if(s.mark==="ins") return "<ins>"+t+"</ins>";
    return t;
  }).join("");
}
function sideHtml(d, which){
  const segs = which==="a" ? d.a_segments : d.b_segments;
  const text = which==="a" ? d.a_text : d.b_text;
  const cap = which==="a" ? "File A" : "File B";
  if(!text && !(segs&&segs.length)) return '<div class="side '+which+' empty"><span class="cap">'+cap+'</span>—</div>';
  const body = (segs&&segs.length) ? segHtml(segs,which) : esc(text);
  return '<div class="side '+which+'"><span class="cap">'+cap+'</span>'+body+'</div>';
}

$("#go").onclick = async ()=>{
  if(!(files.a&&files.b)) return;
  const go=$("#go");
  go.disabled=true; go.classList.add("loading");
  $("#status").innerHTML='<span class="spin"></span> extracting &amp; comparing…';
  $("#results").innerHTML="";
  const fd = new FormData();
  fd.append("a", files.a); fd.append("b", files.b);
  try{
    const r = await fetch("/compare", {method:"POST", body:fd});
    if(!r.ok){ const t=await r.text(); throw new Error(t || ("HTTP "+r.status)); }
    render(await r.json());
    $("#status").textContent="";
  }catch(e){
    $("#results").innerHTML='<div class="err">'+esc(String(e.message||e))+'</div>';
    $("#status").textContent="";
  }finally{ go.disabled=false; go.classList.remove("loading"); }
};

function render(res){
  const c = res.counts;
  let h = "";
  // AI summary card
  const sparkle='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.6 4.6L18 9.2l-4.4 1.6L12 15l-1.6-4.2L6 9.2l4.4-1.6z"/><path d="M18 15l.8 2.2L21 18l-2.2.8L18 21l-.8-2.2L15 18l2.2-.8z"/></svg>';
  h += '<div class="card mount"><h2><span class="badge">'+sparkle+'</span>AI change summary</h2>';
  h += '<div class="summary">'+esc(res.summary)+'</div>';
  h += '<div class="chips">'
    + '<span class="chip add">+'+c.added+' added</span>'
    + '<span class="chip rem">−'+c.removed+' removed</span>'
    + '<span class="chip chg">~'+c.changed+' changed</span>'
    + '<span class="chip same">'+c.same+' unchanged</span></div>';
  if(res.key_changes && res.key_changes.length){
    h += '<ul class="keys">'+res.key_changes.map(k=>'<li>'+esc(k)+'</li>').join("")+'</ul>';
  }
  h += '<div class="metaline"><b>'+esc(res.a.name)+'</b> ('+res.a.units+' units) &nbsp;vs&nbsp; <b>'
    + esc(res.b.name)+'</b> ('+res.b.units+' units)</div>';
  h += '</div>';

  // controls
  h += '<div class="tools mount"><label class="switch">'
    + '<input type="checkbox" id="showSame"><span class="track"></span>show unchanged units</label></div>';

  // diff rows
  const caret='<svg class="caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>';
  h += '<div class="rows mount" id="rows">';
  res.diff.forEach(d=>{
    const collapsed = d.status!=="changed" ? " collapsed" : "";
    h += '<div class="row '+d.status+collapsed+(d.status==="same"?" is-same":"")+'" data-status="'+d.status+'">';
    h += '<div class="rhead">'+caret+'<span class="lbl">'+esc(d.label)+'</span>'
       + '<span class="st '+d.status+'">'+d.status+'</span>';
    if(d.status==="changed") h += '<span class="sim">'+Math.round(d.similarity*100)+'% similar</span>';
    h += '</div>';
    h += '<div class="rbody">'+sideHtml(d,"a")+sideHtml(d,"b")+'</div>';
    h += '</div>';
  });
  h += '</div>';
  $("#results").innerHTML = h;

  // interactions
  document.querySelectorAll("#rows .rhead").forEach(hd=>{
    hd.onclick = ()=> hd.parentElement.classList.toggle("collapsed");
  });
  const applySame = ()=>{
    const show = $("#showSame").checked;
    document.querySelectorAll("#rows .is-same").forEach(r=> r.style.display = show ? "" : "none");
  };
  $("#showSame").onchange = applySame;
  applySame();
}
</script>
</body></html>
"""
