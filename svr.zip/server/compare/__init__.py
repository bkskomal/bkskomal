"""compare tool package (mounted under /compare)."""
