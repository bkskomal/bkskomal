"""Core data contracts for Document Management.

The Locator is the heart of the system: every retrieved chunk carries a precise,
type-specific anchor captured at INGESTION time so a citation can open the source
document at the exact slide / page / section it came from. This cannot be
retrofitted, so it is defined first and everything is built around it.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional
import re
import time


@dataclass
class Locator:
    """Where a chunk lives inside its document — enough to OPEN and HIGHLIGHT it.

    Store BOTH a structural anchor (page/slide/paragraph) AND the verbatim `quote`.
    Viewers navigate by the anchor and highlight by searching `quote` within that
    scope, which is robust to re-pagination and formatting drift.
    """
    doc_type: str                     # "pdf" | "pptx" | "docx" | "txt" | "md" | "html" | "eml" | "xlsx"
    label: str                        # human display, e.g. "Slide 4", "Page 7", "§ Pricing"
    quote: str = ""                   # verbatim text to search + highlight within the anchor
    page: Optional[int] = None        # pdf, 1-based
    slide_index: Optional[int] = None # pptx, 0-based
    shape_id: Optional[str] = None    # pptx, the text shape carrying most of the chunk
    para_index: Optional[int] = None  # docx, 0-based index of the chunk's first paragraph
    heading_path: Optional[list] = None  # docx/md/html breadcrumb, e.g. ["2. Pricing", "2.1 Tiers"]
    bbox: Optional[list] = None       # pdf region [x0, y0, x1, y1] in points
    line_start: Optional[int] = None  # txt/md/html, 1-based first source line of the chunk
    line_end: Optional[int] = None    # txt/md/html, 1-based last source line of the chunk
    section_index: Optional[int] = None  # html section / eml body part ordinal (0-based)
    sheet: Optional[str] = None       # xlsx worksheet name
    row_start: Optional[int] = None   # xlsx, 1-based first row of the chunk
    row_end: Optional[int] = None     # xlsx, 1-based last row of the chunk
    needs_ocr: Optional[bool] = None  # placeholder chunk for a scanned page with no extractable text

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None and v != ""}


@dataclass
class Chunk:
    """A retrievable unit of a document, with its locator and heading context."""
    doc_id: str
    ord: int                          # order within the document
    text: str                         # text used for embedding + display
    locator: Locator
    heading_context: str = ""         # breadcrumb / slide title — boosts retrieval + display
    token_est: int = 0

    def to_dict(self) -> dict:
        d = asdict(self)
        d["locator"] = self.locator.to_dict()
        return d


@dataclass
class Document:
    """A source file in the library."""
    doc_id: str
    title: str
    doc_type: str                     # "pdf" | "pptx" | "docx" | "txt" | "md" | "html" | "eml" | "xlsx"
    path: str                         # original file path (for download / re-open)
    project: str = ""                 # tag, e.g. "autorfp" — powers "get all X documents"
    sha256: str = ""
    mtime: float = 0.0
    unit_count: int = 0               # pages / slides / paragraphs
    indexed_at: float = field(default_factory=time.time)
    acl: list = field(default_factory=lambda: ["public"])  # principals allowed to see this doc
    needs_ocr: bool = False           # any page/section had no extractable text (scanned image)

    def to_dict(self) -> dict:
        return asdict(self)


def est_tokens(s: str) -> int:
    """Cheap token estimate (~4 chars/token) — good enough for chunk sizing."""
    return max(1, len(s) // 4)


# Target chunk size in estimated tokens. Slides/sections that fit stay whole (clean
# anchors); larger units are packed up to this bound before flushing a chunk.
CHUNK_TOKENS = 280


# ------------------------------------------------------------------ version awareness
# Strip trailing version/date/revision suffixes so different revisions of one document
# collapse to a shared FAMILY key ("Pricing v2" and "Pricing final" -> "pricing"). This
# is intentionally conservative — it only trims recognised suffix tokens, never merges
# indexes, and the caller still keeps every distinct document.
_VER_SUFFIX = re.compile(
    r"""(?:
          [ _\-.(\[]*v(?:er(?:sion)?)?[ _\-.]?\d+(?:\.\d+)*[)\]]*   # v1, v2.3, ver 4, version_5
        | [ _\-.(\[]*(?:final|draft|rev(?:ision)?|revised|copy|latest|new|old|fyi)[)\]]* # final, rev
        | [ _\-.(\[]*\d{4}[-_.]\d{2}[-_.]\d{2}[)\]]*                 # 2026-07-09 date stamp
        | [ _\-.(\[]*\d{8}[)\]]*                                     # 20260709 date stamp
        | [ _\-.]*\(\s*\d+\s*\)                                      # (1), ( 2 )  — copy markers
        | [ _\-.]*\[\s*\d+\s*\]                                      # [1]
    )\s*$""",
    re.IGNORECASE | re.VERBOSE,
)


def version_family(title: str) -> str:
    """Normalize a document title to a version-agnostic FAMILY key.

    Repeatedly strips recognised trailing version/date/revision tokens, then collapses
    separators and lowercases, so all revisions of a logical document share one key.
    """
    s = (title or "").strip()
    prev = None
    while prev != s and s:
        prev = s
        s = _VER_SUFFIX.sub("", s).strip(" _-.([)]")
    s = re.sub(r"[ _\-]+", " ", s).strip()
    return s.lower() or (title or "").strip().lower()
