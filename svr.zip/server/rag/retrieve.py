"""Unified hybrid retrieval used by BOTH tools.

dense (BGE cosine) + sparse (FTS5 bm25) fused with reciprocal rank fusion, optional
LLM rerank. Every hit carries its locator + document, so a citation can open the source
at the exact anchor. Also aggregates hits into a document-level pick-list.

Two orthogonal scoping mechanisms, either/both/neither:
  - `project_id`  : restrict to one project's sources (Project Management). Passed through
                    to the store's project-scoped vector/keyword primitives.
  - `principals`  : ACL filter (Document Management). Chunks whose document the caller
                    cannot see are dropped from the fused stream BEFORE the window is
                    sliced and BEFORE rerank. Requires the store to expose
                    `visible_doc_ids`; stores without it simply skip ACL filtering.

`project_id` is positioned before `k` so Project Management's positional
`search(store, query, project_id, ...)` calls work unchanged, while Document
Management's keyword `search(store, query, k=..., principals=...)` calls also work.
"""
from __future__ import annotations

import numpy as np

from .embed import embed_query
from .rerank import llm_rerank


def _vector_search(store, qvec: np.ndarray, k: int, project_id) -> list[tuple[int, float]]:
    ids, mat = store.load_vectors(project_id)
    if mat.shape[0] == 0:
        return []
    sims = mat @ qvec  # normalized vectors → cosine
    top = np.argsort(-sims)[:k]
    return [(int(ids[i]), float(sims[i])) for i in top]


def _rrf(rankings: list[list[tuple[int, float]]], k: int = 60) -> list[tuple[int, float]]:
    scores: dict[int, float] = {}
    for ranking in rankings:
        for rank, (cid, _) in enumerate(ranking):
            scores[cid] = scores.get(cid, 0.0) + 1.0 / (k + rank + 1)
    return sorted(scores.items(), key=lambda x: -x[1])


def search(store, query: str, project_id=None, k: int = 8, pool: int = 30,
           rerank: bool = False, principals: list | None = None) -> list[dict]:
    """Top-k chunk hits, each hydrated with text + locator + document info."""
    qv = embed_query(query)
    fused = _rrf([
        _vector_search(store, qv, pool, project_id),
        store.keyword_search(query, pool, project_id=project_id),
    ])
    visible = None
    if principals is not None and hasattr(store, "visible_doc_ids"):
        visible = store.visible_doc_ids(principals)
    target = max(16, k) if rerank else k
    hits = []
    for cid, score in fused:
        row = store.get_chunk(cid)
        if not row:
            continue
        if visible is not None and row["doc_id"] not in visible:
            continue  # caller has no principal in this document's ACL
        row["score"] = round(score, 5)
        hits.append(row)
        if len(hits) >= target:
            break
    if rerank and len(hits) > 1:
        hits = llm_rerank(query, hits, top_k=k)
    return hits[:k]


def documents_for_query(store, query: str, project_id=None, k: int = 20,
                        principals: list | None = None) -> list[dict]:
    """Rank DOCUMENTS by their best matching chunk — the multi-match pick-list."""
    hits = search(store, query, project_id=project_id, k=k, pool=40, principals=principals)
    by_doc: dict[str, dict] = {}
    for h in hits:
        d = by_doc.get(h["doc_id"])
        if not d or h["score"] > d["score"]:
            by_doc[h["doc_id"]] = {
                "doc_id": h["doc_id"], "title": h["doc_title"], "doc_type": h["doc_type"],
                "project": h["project"], "score": h["score"],
                "why": h["locator"].get("quote", "")[:160], "open_at": h["locator"],
            }
    return sorted(by_doc.values(), key=lambda d: -d["score"])
