"""BGE embeddings via an OpenAI-compatible /embeddings endpoint. Passages plain; queries
get the BGE retrieval instruction (recommended for bge-*-en-v1.5). Vectors are
L2-normalized so cosine similarity is a plain dot product downstream."""
from __future__ import annotations

import httpx
import numpy as np

from config import EMBED_URL, EMBED_MODE, EMBED_MODEL

# bge-en-v1.5 recommends prefixing the QUERY (not passages) for retrieval.
QUERY_INSTRUCTION = "Represent this sentence for searching relevant passages: "

_LOCAL = None


def _local_embedder():
    """Lazy in-process BGE embedder (fastembed / ONNX, no torch). Same model the /ppt
    sidecar serves, so vectors are identical to the HTTP path."""
    global _LOCAL
    if _LOCAL is None:
        from fastembed import TextEmbedding
        _LOCAL = TextEmbedding(model_name=EMBED_MODEL)
    return _LOCAL


def _post(inputs: list[str]) -> list[np.ndarray]:
    """Embed a batch. Local (in-process fastembed) by default; HTTP when EMBED_MODE=http."""
    if EMBED_MODE != "http":
        return [np.asarray(v, dtype=np.float32) for v in _local_embedder().embed(list(inputs))]
    r = httpx.post(EMBED_URL, json={"input": inputs}, timeout=180.0)
    r.raise_for_status()
    data = r.json()["data"]
    return [np.asarray(d["embedding"], dtype=np.float32) for d in data]


def _norm(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return (v / n) if n else v


def embed_passages(texts: list[str], batch: int = 32) -> list[np.ndarray]:
    out: list[np.ndarray] = []
    for i in range(0, len(texts), batch):
        out.extend(_norm(v) for v in _post(texts[i : i + batch]))
    return out


def embed_query(text: str) -> np.ndarray:
    return _norm(_post([QUERY_INSTRUCTION + text])[0])
