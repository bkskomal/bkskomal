"""Core data contracts shared by every RAG-backed tool.

The Locator is the heart of the system: every retrieved chunk carries a precise,
type-specific anchor captured at INGESTION time so a citation can open the source at the
exact slide / page / section — or, for a NOTE, scroll a timeline to it. This is the
un-retrofittable core, so it is a UNION of the fields both tools need (documents adds
page/bbox/xlsx/needs_ocr; projects adds note_id) — all optional, so any tool populates
only what applies.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional
import re
import time


@dataclass
class Locator:
    """Where a chunk lives inside its source — enough to OPEN and HIGHLIGHT it.

    Stores BOTH a structural anchor (page/slide/paragraph/section/row/note) AND the
    verbatim `quote`. Viewers navigate by the anchor and highlight by searching `quote`
    within that scope, which is robust to re-pagination and formatting drift.
    """
    doc_type: str                     # "pdf"|"pptx"|"docx"|"txt"|"md"|"html"|"eml"|"xlsx"|"csv"|"note"
    label: str                        # human display, e.g. "Slide 4", "Page 7", "§ Pricing"
    quote: str = ""                   # verbatim text to search + highlight within the anchor
    page: Optional[int] = None        # pdf, 1-based
    slide_index: Optional[int] = None # pptx, 0-based
    shape_id: Optional[str] = None    # pptx, the text shape carrying most of the chunk
    para_index: Optional[int] = None  # docx, 0-based index of the chunk's first paragraph
    heading_path: Optional[list] = None  # docx/md/html breadcrumb, e.g. ["2. Pricing", "2.1 Tiers"]
    bbox: Optional[list] = None       # pdf region [x0, y0, x1, y1] in points
    line_start: Optional[int] = None  # txt/md/html, 1-based first source line of the chunk
    line_end: Optional[int] = None    # txt/md/html, 1-based last source line of the chunk
    section_index: Optional[int] = None  # html section / eml body part ordinal (0-based)
    sheet: Optional[str] = None       # xlsx worksheet name (or "CSV")
    row_start: Optional[int] = None   # xlsx/csv, 1-based first row of the chunk
    row_end: Optional[int] = None     # xlsx/csv, 1-based last row of the chunk
    needs_ocr: Optional[bool] = None  # placeholder chunk for a scanned page with no extractable text
    note_id: Optional[int] = None     # note, the timeline entry this chunk came from

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None and v != ""}


@dataclass
class Chunk:
    """A retrievable unit of a document/note, with its locator and heading context."""
    doc_id: str
    ord: int                          # order within the document
    text: str                         # text used for embedding + display
    locator: Locator
    heading_context: str = ""         # breadcrumb / slide title — boosts retrieval + display
    token_est: int = 0

    def to_dict(self) -> dict:
        d = asdict(self)
        d["locator"] = self.locator.to_dict()
        return d


@dataclass
class Document:
    """A source in a tool's RAG index: an uploaded file, a synced item, or an indexed note."""
    doc_id: str
    title: str
    doc_type: str
    path: str                         # original path / origin (empty for notes)
    project: str = ""                 # documents: folder tag; projects: the PROJECT ID
    sha256: str = ""
    mtime: float = 0.0
    unit_count: int = 0               # pages / slides / paragraphs / note-chunks
    indexed_at: float = field(default_factory=time.time)
    acl: list = field(default_factory=lambda: ["public"])  # principals allowed to see this doc
    needs_ocr: bool = False           # any page/section had no extractable text (scanned image)
    source_id: str = ""               # owning connector source ("" = manual upload / local file)

    def to_dict(self) -> dict:
        return asdict(self)


def est_tokens(s: str) -> int:
    """Cheap token estimate (~4 chars/token) — good enough for chunk sizing."""
    return max(1, len(s) // 4)


# Target chunk size in estimated tokens. Slides/sections that fit stay whole (clean
# anchors); larger units are packed up to this bound before flushing a chunk.
CHUNK_TOKENS = 280


# ------------------------------------------------------------------ version awareness
_VER_SUFFIX = re.compile(
    r"""(?:
          [ _\-.(\[]*v(?:er(?:sion)?)?[ _\-.]?\d+(?:\.\d+)*[)\]]*
        | [ _\-.(\[]*(?:final|draft|rev(?:ision)?|revised|copy|latest|new|old|fyi)[)\]]*
        | [ _\-.(\[]*\d{4}[-_.]\d{2}[-_.]\d{2}[)\]]*
        | [ _\-.(\[]*\d{8}[)\]]*
        | [ _\-.]*\(\s*\d+\s*\)
        | [ _\-.]*\[\s*\d+\s*\]
    )\s*$""",
    re.IGNORECASE | re.VERBOSE,
)


def version_family(title: str) -> str:
    """Normalize a document title to a version-agnostic FAMILY key so all revisions of a
    logical document share one key (never merges indexes; a grouping/awareness view only)."""
    s = (title or "").strip()
    prev = None
    while prev != s and s:
        prev = s
        s = _VER_SUFFIX.sub("", s).strip(" _-.([)]")
    s = re.sub(r"[ _\-]+", " ", s).strip()
    return s.lower() or (title or "").strip().lower()
