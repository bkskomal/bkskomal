"""Shared RAG core for the OATIGenie backend.

ONE anchor-preserving extraction + chunking + BGE-embeddings + hybrid (BGE cosine +
FTS5 bm25, fused with RRF) + LLM-rerank + citation pipeline, used by BOTH the
/documents tool (ACL/principal-scoped) and the /projects tool (project-scoped). There is
no second copy: `documents` and `projects` both import from `server.rag`.
"""
