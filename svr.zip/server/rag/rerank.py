"""LLM reranker (RankGPT-style). A cross-encoder reranker would need a local GPU model
(torch) — impractical here — so we reuse the shared chat model to score the top
candidates for relevance and reorder them. Big precision win on "open the exact right
source", with no new model server. Falls back to fusion order on any error."""
from __future__ import annotations

import json
import re

from .llm import chat

_SYS = (
    "You are a precise search-relevance ranker. Given a QUERY and numbered passages, "
    "rate how well EACH passage answers the query on a 0-10 scale (10 = directly and "
    "completely answers it; 0 = irrelevant). Return ONLY JSON: "
    '{"scores": [{"id": <int>, "score": <number>}, ...]} covering every id.'
)


def _json(s: str) -> str:
    m = re.search(r"\{.*\}", s, re.S)
    return m.group(0) if m else s


def llm_rerank(query: str, hits: list[dict], top_k: int = 8, max_candidates: int = 14) -> list[dict]:
    cand = hits[:max_candidates]
    if len(cand) <= 1:
        return hits[:top_k]
    listing = "\n".join(
        f"[{i + 1}] ({h.get('doc_title', '')} — {h['locator'].get('label', '')}) {h['text'][:350]}"
        for i, h in enumerate(cand)
    )
    try:
        raw = chat(
            [{"role": "system", "content": _SYS},
             {"role": "user", "content": f"QUERY: {query}\n\nPASSAGES:\n{listing}"}],
            temperature=0, max_tokens=400,
        )
        scores = {int(s["id"]): float(s["score"]) for s in json.loads(_json(raw)).get("scores", [])}
    except Exception:
        return hits[:top_k]
    order = sorted(range(len(cand)), key=lambda i: -scores.get(i + 1, -1.0))
    reranked = [cand[i] for i in order]
    for i, h in zip(order, reranked):
        h["rerank_score"] = scores.get(i + 1)
    reranked += hits[max_candidates:]  # keep the tail beyond the reranked window
    return reranked[:top_k]
