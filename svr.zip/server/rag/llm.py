"""GPT-OSS-120B chat client (OpenAI-compatible) — the shared chat model for the suite.

Supports one-shot `chat()` and token-streaming `chat_stream()`. gpt-oss keeps its
chain-of-thought in a separate channel; we surface only the answer content and can bound
thinking via `reasoning_effort` so tokens go to the answer (and stream fast)."""
from __future__ import annotations

import json
import warnings
from typing import Iterator

import httpx

from config import LLM_BASE, LLM_MODEL, LLM_KEY, LLM_TLS_INSECURE

warnings.filterwarnings("ignore")  # silence the self-signed-cert warning on the dev endpoint


def _body(messages, temperature, max_tokens, reasoning_effort, stream):
    body = {"model": LLM_MODEL, "messages": messages, "temperature": temperature,
            "max_tokens": max_tokens, "stream": stream}
    if reasoning_effort:
        body["reasoning_effort"] = reasoning_effort
    return body


def chat(messages: list[dict], temperature: float = 0.2, max_tokens: int = 1200,
         reasoning_effort: str | None = None) -> str:
    r = httpx.post(
        f"{LLM_BASE}/chat/completions",
        headers={"Authorization": f"Bearer {LLM_KEY}", "Content-Type": "application/json"},
        json=_body(messages, temperature, max_tokens, reasoning_effort, False),
        timeout=240.0,
        verify=not LLM_TLS_INSECURE,
    )
    r.raise_for_status()
    msg = r.json()["choices"][0]["message"]
    return (msg.get("content") or "").strip()


def chat_stream(messages: list[dict], temperature: float = 0.2, max_tokens: int = 1200,
                reasoning_effort: str | None = None) -> Iterator[str]:
    """Stream ONLY the answer tokens (delta.content); the reasoning channel is dropped."""
    with httpx.stream(
        "POST",
        f"{LLM_BASE}/chat/completions",
        headers={"Authorization": f"Bearer {LLM_KEY}", "Content-Type": "application/json"},
        json=_body(messages, temperature, max_tokens, reasoning_effort, True),
        timeout=240.0,
        verify=not LLM_TLS_INSECURE,
    ) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if not line:
                continue
            line = line.strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                delta = json.loads(data)["choices"][0]["delta"]
            except (ValueError, KeyError, IndexError):
                continue
            piece = delta.get("content")
            if piece:
                yield piece
