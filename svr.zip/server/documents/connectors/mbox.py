"""Email connector — an .mbox archive (or a folder of .eml files) becomes one document
per message. Each message is written back out as a standalone .eml and run through the
EXISTING eml extractor, so every message carries its exact anchor: `Email: <subject>`
plus a section ordinal (long bodies split into continuation parts). Messages are keyed by
Message-ID (falling back to a positional key) so re-syncing updates in place."""
from __future__ import annotations

import mailbox
import os

from .base import Connector, SyncResult, stable_doc_id


def _subject(msg) -> str:
    s = (msg.get("subject") or "").strip()
    return s or "(no subject)"


class MboxConnector(Connector):
    type = "mbox"
    label = "Email (mbox / .eml)"
    needs_credentials = False
    config_fields = [
        {"name": "path", "label": ".mbox file or folder of .eml", "kind": "text",
         "placeholder": r"E:\mail\archive.mbox", "required": True},
    ]

    def is_configured(self) -> bool:
        path = (self.config.get("path") or "").strip()
        return bool(path) and os.path.exists(path)

    def _messages(self):
        """Yield (item_key, subject, raw_bytes) for every message in the source."""
        path = os.path.abspath((self.config.get("path") or "").strip())
        if os.path.isdir(path):
            for i, fn in enumerate(sorted(os.listdir(path))):
                if not fn.lower().endswith(".eml"):
                    continue
                fp = os.path.join(path, fn)
                with open(fp, "rb") as f:
                    raw = f.read()
                import email
                from email import policy
                msg = email.message_from_bytes(raw, policy=policy.default)
                mid = (msg.get("message-id") or "").strip() or f"file:{fn}"
                yield mid, _subject(msg), raw
        else:
            box = mailbox.mbox(path)
            try:
                for i, msg in enumerate(box):
                    mid = (msg.get("message-id") or "").strip() or f"idx:{i}"
                    raw = msg.as_bytes()
                    yield mid, _subject(msg), raw
            finally:
                box.close()

    def sync(self) -> SyncResult:
        path = os.path.abspath((self.config.get("path") or "").strip())
        if not path or not os.path.exists(path):
            return SyncResult(status="error", message=f"path not found: {path}")

        res = SyncResult()
        seen: set = set()
        src_base = os.path.basename(path)
        for item_key, subject, raw in self._messages():
            did = stable_doc_id(self.source_id, item_key)
            seen.add(did)
            origin = f"mbox://{src_base}#{item_key}"
            try:
                out = self._ingest(item_key=item_key, ext=".eml", data=raw,
                                   origin=origin, title=subject[:120])
                if out.get("skipped"):
                    res.skipped += 1
                else:
                    res.added += 1
                    res.items.append({"title": subject[:120], "doc_type": "eml",
                                      "chunks": out.get("chunks")})
            except Exception as e:  # noqa: BLE001
                res.errors += 1
                res.items.append({"item": item_key, "error": f"{type(e).__name__}: {e}"})

        res.removed = self._reconcile_deletions(seen)
        res.message = f"added={res.added} skipped={res.skipped} removed={res.removed} errors={res.errors}"
        return res
