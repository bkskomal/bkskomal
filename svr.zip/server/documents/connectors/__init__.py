"""Connector registry — maps a source `type` to its Connector class and exposes the
type catalog (with config-field hints + credential gating) for the UI. Adding a source
type is: write a Connector subclass, import it here, add it to REGISTRY."""
from __future__ import annotations

from ..store import Store

from .base import Connector, SyncResult, ingest_content, stable_doc_id
from .local_folder import LocalFolderConnector
from .mbox import MboxConnector
from .url import UrlConnector
from .gdrive import GoogleDriveConnector
from .slack import SlackConnector

REGISTRY: dict[str, type[Connector]] = {
    LocalFolderConnector.type: LocalFolderConnector,
    MboxConnector.type: MboxConnector,
    UrlConnector.type: UrlConnector,
    GoogleDriveConnector.type: GoogleDriveConnector,
    SlackConnector.type: SlackConnector,
}


def connector_types() -> list[dict]:
    """Catalog for the UI: type, label, whether it needs credentials, and its config fields."""
    return [
        {"type": c.type, "label": c.label, "needs_credentials": c.needs_credentials,
         "config_fields": c.config_fields}
        for c in REGISTRY.values()
    ]


def build_connector(store: Store, source: dict) -> Connector:
    cls = REGISTRY.get(source.get("type"))
    if not cls:
        raise ValueError(f"unknown connector type: {source.get('type')}")
    return cls(store, source)


def sync_source(store: Store, source_id: str) -> dict:
    """Run one source's sync, persist its status/cursor/result, and return the outcome."""
    source = store.get_source(source_id)
    if not source:
        raise ValueError(f"unknown source: {source_id}")
    connector = build_connector(store, source)
    store.update_source(source_id, status="syncing")
    try:
        result = connector.sync()
    except Exception as e:  # noqa: BLE001
        store.update_source(source_id, status="error", last_result=f"{type(e).__name__}: {e}",
                            mark_synced=True)
        raise
    store.update_source(
        source_id,
        status=result.status if result.status != "ok" else "synced",
        cursor=result.cursor or source.get("cursor") or "",
        last_result=result.message,
        mark_synced=True,
    )
    out = result.to_dict()
    out["source_id"] = source_id
    out["doc_count"] = store.count_source_docs(source_id)
    return out


def sync_configured_sources(store: Store) -> list[dict]:
    """Background-friendly: sync every source that is fully configured (skips
    credential-gated sources with no credential, so they never error in the loop)."""
    out = []
    for s in store.list_sources():
        try:
            connector = build_connector(store, s)
        except ValueError:
            continue
        if connector.needs_credentials and not connector.is_configured():
            continue
        if not connector.is_configured():
            continue
        try:
            out.append(sync_source(store, s["source_id"]))
        except Exception:  # noqa: BLE001
            pass
    return out
