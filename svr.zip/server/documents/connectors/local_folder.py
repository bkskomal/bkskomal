"""Local folder / filesystem-tree connector — formalizes the original root-sync into the
connector framework. Walks a directory, ingests every supported file with the source's
ACL, and reconciles deletions. Files are REAL on-disk paths, so their `origin` is the true
path (open/download re-open the original) and incremental skip uses the content hash."""
from __future__ import annotations

import os

from ..ingest import ingest_file, SUPPORTED
from .base import Connector, SyncResult, stable_doc_id


class LocalFolderConnector(Connector):
    type = "local_folder"
    label = "Local folder"
    needs_credentials = False
    config_fields = [
        {"name": "path", "label": "Folder path", "kind": "text",
         "placeholder": r"E:\AI\Self\AutoRFP\docs", "required": True},
    ]

    def is_configured(self) -> bool:
        path = (self.config.get("path") or "").strip()
        return bool(path) and os.path.isdir(path)

    def sync(self) -> SyncResult:
        root = os.path.abspath((self.config.get("path") or "").strip())
        if not root or not os.path.isdir(root):
            return SyncResult(status="error", message=f"folder not found: {root}")

        res = SyncResult()
        seen: set = set()
        for r, _, files in os.walk(root):
            for fn in sorted(files):
                if os.path.splitext(fn)[1].lower() not in SUPPORTED:
                    continue
                path = os.path.join(r, fn)
                # a filesystem item is keyed by its path so one file == one logical doc
                item_key = os.path.abspath(path)
                did = stable_doc_id(self.source_id, item_key)
                seen.add(did)
                try:
                    out = ingest_file(self.store, path, project=self.project, doc_id=did,
                                      acl=self.acl, origin=item_key,
                                      title=os.path.splitext(fn)[0], source_id=self.source_id)
                    if out.get("skipped"):
                        res.skipped += 1
                    else:
                        res.added += 1
                        res.items.append({"title": out.get("title"),
                                          "doc_type": out.get("doc_type"),
                                          "chunks": out.get("chunks")})
                except Exception as e:  # noqa: BLE001
                    res.errors += 1
                    res.items.append({"path": path, "error": f"{type(e).__name__}: {e}"})

        res.removed = self._reconcile_deletions(seen)
        res.message = f"added={res.added} skipped={res.skipped} removed={res.removed} errors={res.errors}"
        return res
