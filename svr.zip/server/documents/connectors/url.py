"""URL / web-page connector — fetch one or more reachable URLs (internal suite pages,
intranet, docs) and ingest each as an HTML document. The existing HTML extractor sections
the page by its `<h1>`–`<h6>` headings, so every chunk's anchor is `§ <heading breadcrumb>`
and a citation opens at the exact section. `origin` is the URL itself, so the library shows
the real source. Incremental: unchanged pages skip on content hash."""
from __future__ import annotations

import re

import httpx

from .base import Connector, SyncResult, stable_doc_id

_TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)


def _page_title(html: str, url: str) -> str:
    m = _TITLE_RE.search(html or "")
    if m:
        t = re.sub(r"\s+", " ", m.group(1)).strip()
        if t:
            return t[:120]
    return url.rstrip("/").rsplit("/", 1)[-1] or url


class UrlConnector(Connector):
    type = "url"
    label = "Web page / URL"
    needs_credentials = False
    config_fields = [
        {"name": "urls", "label": "URLs (one per line)", "kind": "multiline",
         "placeholder": "http://intranet/handbook\nhttp://localhost:3020/about", "required": True},
    ]

    def _url_list(self) -> list[str]:
        raw = self.config.get("urls") or self.config.get("url") or ""
        if isinstance(raw, list):
            items = raw
        else:
            items = re.split(r"[\r\n,]+", str(raw))
        return [u.strip() for u in items if u.strip()]

    def is_configured(self) -> bool:
        return bool(self._url_list())

    def sync(self) -> SyncResult:
        urls = self._url_list()
        if not urls:
            return SyncResult(status="error", message="no URLs configured")

        res = SyncResult()
        seen: set = set()
        headers = {"User-Agent": "DocumentManagement-URLConnector/1.0"}
        with httpx.Client(timeout=30.0, follow_redirects=True, verify=False, headers=headers) as client:
            for url in urls:
                did = stable_doc_id(self.source_id, url)
                seen.add(did)
                try:
                    r = client.get(url)
                    r.raise_for_status()
                    ctype = (r.headers.get("content-type") or "").lower()
                    # Choose an extension so the right extractor runs (html by default).
                    if "csv" in ctype or url.lower().endswith(".csv"):
                        ext = ".csv"
                    elif url.lower().endswith((".txt", ".md")):
                        ext = ".md" if url.lower().endswith(".md") else ".txt"
                    else:
                        ext = ".html"
                    data = r.content
                    title = _page_title(r.text, url) if ext == ".html" else url.rsplit("/", 1)[-1]
                    out = self._ingest(item_key=url, ext=ext, data=data, origin=url, title=title)
                    if out.get("skipped"):
                        res.skipped += 1
                    else:
                        res.added += 1
                        res.items.append({"title": title, "doc_type": out.get("doc_type"),
                                          "url": url, "chunks": out.get("chunks")})
                except Exception as e:  # noqa: BLE001
                    res.errors += 1
                    res.items.append({"url": url, "error": f"{type(e).__name__}: {e}"})

        res.removed = self._reconcile_deletions(seen)
        res.message = f"added={res.added} skipped={res.skipped} removed={res.removed} errors={res.errors}"
        return res
