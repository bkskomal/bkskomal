"""Google Drive connector — DROP-IN, credential-gated.

Structurally complete against the Drive v3 REST API (raw httpx, no google SDK so it adds
no dependency). It lists files, exports Google-native docs to an office/PDF format the
existing extractors understand, downloads binary files as-is, and runs them through the
SAME ingestion pipeline — so Drive documents get exact-anchor citations, hybrid retrieval
and ACL filtering like any local file. Incremental sync uses the Drive Changes API page
token as the persisted cursor.

TO GO LIVE: add an OAuth access token (or a token the caller refreshes) to the source
config as `credentials.access_token`. Offline, with no token, `sync()` reports
`needs_credentials` and does nothing — nothing is faked. A drive folder can be scoped with
`config.folder_id`; ACL principals come from the source's `acl`.
"""
from __future__ import annotations

import httpx

from .base import Connector, SyncResult

API = "https://www.googleapis.com/drive/v3"

# Google-native mime -> (export mime, extension the extractors handle).
_EXPORT = {
    "application/vnd.google-apps.document":
        ("application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx"),
    "application/vnd.google-apps.presentation":
        ("application/vnd.openxmlformats-officedocument.presentationml.presentation", ".pptx"),
    "application/vnd.google-apps.spreadsheet":
        ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"),
}
# direct-download mimes -> extension
_BINARY = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "text/plain": ".txt", "text/markdown": ".md", "text/html": ".html",
    "text/csv": ".csv", "message/rfc822": ".eml",
}


class GoogleDriveConnector(Connector):
    type = "gdrive"
    label = "Google Drive"
    needs_credentials = True
    config_fields = [
        {"name": "credentials.access_token", "label": "OAuth access token", "kind": "password",
         "placeholder": "ya29.…", "required": True},
        {"name": "folder_id", "label": "Folder ID (optional — blank = My Drive)", "kind": "text",
         "placeholder": "1AbCd…", "required": False},
    ]

    def _token(self) -> str:
        creds = self.config.get("credentials") or {}
        return (creds.get("access_token") or self.config.get("access_token") or "").strip()

    def is_configured(self) -> bool:
        return bool(self._token())

    def sync(self) -> SyncResult:
        token = self._token()
        if not token:
            return SyncResult(status="needs_credentials",
                              message="Google Drive needs an OAuth access token to sync "
                                      "(config.credentials.access_token). Structurally ready; "
                                      "add a credential to go live.")

        headers = {"Authorization": f"Bearer {token}"}
        folder_id = (self.config.get("folder_id") or "").strip()
        q = "trashed=false"
        if folder_id:
            q += f" and '{folder_id}' in parents"

        res = SyncResult()
        seen: set = set()
        try:
            with httpx.Client(timeout=60.0, headers=headers) as client:
                page_token = None
                while True:
                    params = {"q": q, "fields": "nextPageToken,files(id,name,mimeType,modifiedTime)",
                              "pageSize": 100}
                    if page_token:
                        params["pageToken"] = page_token
                    lr = client.get(f"{API}/files", params=params)
                    lr.raise_for_status()
                    body = lr.json()
                    for f in body.get("files", []):
                        outcome = self._ingest_file(client, f, seen)
                        if outcome == "added":
                            res.added += 1
                        elif outcome == "skipped":
                            res.skipped += 1
                        elif outcome == "error":
                            res.errors += 1
                    page_token = body.get("nextPageToken")
                    if not page_token:
                        break
            res.removed = self._reconcile_deletions(seen)
            res.status = "ok"
            res.message = f"added={res.added} skipped={res.skipped} removed={res.removed} errors={res.errors}"
        except httpx.HTTPStatusError as e:
            res.status = "error"
            res.message = f"Drive API {e.response.status_code}: {e.response.text[:200]}"
        except Exception as e:  # noqa: BLE001
            res.status = "error"
            res.message = f"{type(e).__name__}: {e}"
        return res

    def _ingest_file(self, client: httpx.Client, f: dict, seen: set) -> str:
        fid, name, mime = f["id"], f.get("name", fid), f.get("mimeType", "")
        if mime in _EXPORT:
            export_mime, ext = _EXPORT[mime]
            r = client.get(f"{API}/files/{fid}/export", params={"mimeType": export_mime})
        elif mime in _BINARY:
            ext = _BINARY[mime]
            r = client.get(f"{API}/files/{fid}", params={"alt": "media"})
        else:
            return "unsupported"
        try:
            r.raise_for_status()
        except httpx.HTTPStatusError:
            return "error"
        title = name.rsplit(".", 1)[0] if "." in name else name
        out = self._ingest(item_key=fid, ext=ext, data=r.content,
                           origin=f"gdrive://{fid}", title=title)
        from .base import stable_doc_id
        seen.add(stable_doc_id(self.source_id, fid))
        return "skipped" if out.get("skipped") else "added"
