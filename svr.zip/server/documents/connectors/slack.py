"""Slack connector — DROP-IN, credential-gated.

Structurally complete against the Slack Web API (raw httpx, no slack SDK). For each
channel it pulls conversation history, renders the messages of a channel into a single
text document (with a stable per-message ordering), and ingests it through the SAME
pipeline. Each channel document's anchor is line-range based (the txt extractor), so a
citation opens at the message block it came from. Incremental sync persists the newest
message timestamp per channel as the cursor and pulls only newer messages next time.

ACL: channel docs are ingested with the source's ACL principals — e.g. map a private
channel to `group:slack-<channel>` so only members' principals can retrieve it.

TO GO LIVE: add a bot/user token (`credentials.bot_token`, scopes channels:history,
channels:read) to the source config. Offline, with no token, `sync()` reports
`needs_credentials` and does nothing — nothing is faked.
"""
from __future__ import annotations

import json
import time

import httpx

from .base import Connector, SyncResult, stable_doc_id

API = "https://slack.com/api"


class SlackConnector(Connector):
    type = "slack"
    label = "Slack"
    needs_credentials = True
    config_fields = [
        {"name": "credentials.bot_token", "label": "Bot token (xoxb-…)", "kind": "password",
         "placeholder": "xoxb-…", "required": True},
        {"name": "channels", "label": "Channel IDs (optional, comma-sep — blank = all public)",
         "kind": "text", "placeholder": "C0123,C0456", "required": False},
    ]

    def _token(self) -> str:
        creds = self.config.get("credentials") or {}
        return (creds.get("bot_token") or self.config.get("bot_token") or "").strip()

    def is_configured(self) -> bool:
        return bool(self._token())

    def _cursor_map(self) -> dict:
        try:
            return json.loads(self.cursor) if self.cursor else {}
        except (ValueError, TypeError):
            return {}

    def sync(self) -> SyncResult:
        token = self._token()
        if not token:
            return SyncResult(status="needs_credentials",
                              message="Slack needs a bot token to sync "
                                      "(config.credentials.bot_token, scopes channels:history + "
                                      "channels:read). Structurally ready; add a credential to go live.")

        headers = {"Authorization": f"Bearer {token}"}
        cursors = self._cursor_map()          # channel_id -> last-seen ts
        wanted = [c.strip() for c in str(self.config.get("channels") or "").split(",") if c.strip()]

        res = SyncResult()
        seen: set = set()
        try:
            with httpx.Client(timeout=60.0, headers=headers) as client:
                channels = self._list_channels(client) if not wanted else \
                    [{"id": cid, "name": cid} for cid in wanted]
                for ch in channels:
                    cid, cname = ch["id"], ch.get("name", ch["id"])
                    newest = self._sync_channel(client, cid, cname, cursors.get(cid, "0"), res, seen)
                    if newest:
                        cursors[cid] = newest
            res.removed = self._reconcile_deletions(seen)
            res.cursor = json.dumps(cursors)
            res.status = "ok"
            res.message = f"added={res.added} changed={res.changed} skipped={res.skipped} errors={res.errors}"
        except httpx.HTTPStatusError as e:
            res.status = "error"
            res.message = f"Slack API {e.response.status_code}: {e.response.text[:200]}"
        except Exception as e:  # noqa: BLE001
            res.status = "error"
            res.message = f"{type(e).__name__}: {e}"
        return res

    def _list_channels(self, client: httpx.Client) -> list[dict]:
        r = client.get(f"{API}/conversations.list",
                       params={"types": "public_channel", "limit": 200})
        r.raise_for_status()
        data = r.json()
        if not data.get("ok"):
            raise RuntimeError(data.get("error", "conversations.list failed"))
        return data.get("channels", [])

    def _sync_channel(self, client: httpx.Client, cid: str, cname: str,
                      oldest: str, res: SyncResult, seen: set) -> str:
        params = {"channel": cid, "limit": 200}
        if oldest and oldest != "0":
            params["oldest"] = oldest
        r = client.get(f"{API}/conversations.history", params=params)
        r.raise_for_status()
        data = r.json()
        if not data.get("ok"):
            res.errors += 1
            return ""
        msgs = list(reversed(data.get("messages", [])))   # chronological
        if not msgs:
            res.skipped += 1
            return ""
        lines = [f"# Slack #{cname}", ""]
        for m in msgs:
            ts = m.get("ts", "")
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(float(ts))) if ts else ""
            user = m.get("user") or m.get("username") or "unknown"
            lines.append(f"[{when}] {user}: {(m.get('text') or '').strip()}")
        body = "\n".join(lines).encode("utf-8")
        title = f"Slack #{cname}"
        # One doc per channel, updated in place each sync (content-hash skip when unchanged).
        out = self._ingest(item_key=f"channel:{cid}", ext=".md", data=body,
                           origin=f"slack://{cid}", title=title)
        seen.add(stable_doc_id(self.source_id, f"channel:{cid}"))
        if out.get("skipped"):
            res.skipped += 1
        else:
            res.added += 1
        return msgs[-1].get("ts", oldest)
