"""Connector framework — pluggable source types over the ONE ingestion pipeline.

A connector discovers items in some source (a folder, an mbox, a set of URLs, a Google
Drive, a Slack workspace), fetches each item's bytes, and hands them to `ingest_content`,
which runs the EXISTING anchor-preserving extraction + BGE indexing + provenance/preview
path unchanged. Every connector therefore inherits, for free:

  * exact-anchor citations (the locator captured by the type's extractor),
  * hybrid retrieval + reranker + the streaming /ask,
  * permission-filtered retrieval — each item is ingested with the source's ACL
    principals, so the security model keeps working across every source.

Incrementality: a connector persists a small opaque `cursor` (per-source, in the sources
table) and, per item, relies on content-hash skip inside `ingest_file` (same bytes + same
stable `origin` -> skipped). Cloud connectors (Google Drive, Slack) are structurally
complete but credential-gated: with no credential they report `needs_credentials` and do
no work; adding a token is all it takes to go live.
"""
from __future__ import annotations

import hashlib
import os
import tempfile
from dataclasses import dataclass, field, asdict

from ..ingest import ingest_file
from ..store import Store


@dataclass
class SyncResult:
    added: int = 0
    changed: int = 0
    removed: int = 0
    skipped: int = 0
    errors: int = 0
    cursor: str = ""              # opaque per-source incremental cursor to persist
    status: str = "ok"           # "ok" | "needs_credentials" | "error"
    message: str = ""
    items: list = field(default_factory=list)   # per-item outcomes (title/anchor/etc.)

    def to_dict(self) -> dict:
        return asdict(self)


def stable_doc_id(source_id: str, item_key: str) -> str:
    """Deterministic per-item doc_id so re-syncing the same item updates in place
    (never duplicates) and content-hash skip can short-circuit unchanged items."""
    return hashlib.sha256(f"{source_id}\x00{item_key}".encode("utf-8")).hexdigest()[:16]


def ingest_content(store: Store, *, source_id: str, item_key: str, ext: str,
                   data: bytes, project: str, acl: list, origin: str,
                   title: str) -> dict:
    """Materialize an item's bytes into a temp file of the right extension and run the
    real ingest pipeline. `origin` is the stored, human/stable source locator (URL,
    mbox://…#msg, gdrive://<id>, slack://<channel>/<ts>); `title` is the display name.

    The temp file is deleted after ingestion — the pipeline has already copied the bytes
    into FILES_DIR (stored_path) and built the preview, so open/download/preview and the
    exact-anchor viewer keep working with no live source connection."""
    ext = ext if ext.startswith(".") else f".{ext}"
    did = stable_doc_id(source_id, item_key)
    tmp_dir = tempfile.mkdtemp()
    # keep a meaningful basename so any fallback title is still readable
    safe = "".join(c for c in (title or item_key) if c.isalnum() or c in " _-").strip()[:60] or "item"
    tmp_path = os.path.join(tmp_dir, safe + ext)
    with open(tmp_path, "wb") as f:
        f.write(data)
    try:
        return ingest_file(store, tmp_path, project=project, doc_id=did, acl=acl,
                           origin=origin, title=title, source_id=source_id)
    finally:
        try:
            os.remove(tmp_path); os.rmdir(tmp_dir)
        except OSError:
            pass


class Connector:
    """Base class. Subclasses set `type`/`label`/`needs_credentials`, declare their
    `config_fields` (for the UI form), and implement `sync`."""

    type: str = "base"
    label: str = "Base"
    needs_credentials: bool = False
    # UI hints: [{name, label, kind: "text"|"password"|"multiline", placeholder, required}]
    config_fields: list = []

    def __init__(self, store: Store, source: dict):
        self.store = store
        self.source = source
        self.config = source.get("config") or {}
        self.source_id = source["source_id"]
        self.project = source.get("project") or ""
        self.acl = source.get("acl") or ["public"]
        self.cursor = source.get("cursor") or ""

    def is_configured(self) -> bool:
        """Whether this source has what it needs to actually sync (creds present, etc.)."""
        return True

    def sync(self) -> SyncResult:  # pragma: no cover - overridden
        raise NotImplementedError

    # -- convenience for subclasses --------------------------------------------
    def _ingest(self, *, item_key: str, ext: str, data: bytes, origin: str, title: str) -> dict:
        return ingest_content(self.store, source_id=self.source_id, item_key=item_key,
                              ext=ext, data=data, project=self.project, acl=self.acl,
                              origin=origin, title=title)

    def _reconcile_deletions(self, seen_doc_ids: set) -> int:
        """Delete docs previously ingested by this source that were NOT seen this run."""
        removed = 0
        for d in self.store.documents_for_source(self.source_id):
            if d["doc_id"] not in seen_doc_ids:
                self.store.delete_document(d["doc_id"])
                removed += 1
        return removed
