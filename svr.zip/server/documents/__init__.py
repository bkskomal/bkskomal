"""documents tool package (mounted under /documents)."""
