"""Grounded QA: answer strictly from retrieved chunks, with ENFORCED [n] citations
that each map to a locator the UI can open at the exact slide/page/section.

Three experience layers sit on top of the same permission-filtered retrieval:
  - a streaming variant (`ask_stream`) that yields answer tokens live, then the
    citations + document pick-list as a final structured event;
  - multi-turn context (`history`) so follow-ups like "what about the risks?" are
    answered WITH the prior conversation, and the retrieval query is expanded with
    the previous user turn so pronouns ("it", "that") resolve to the right chunks;
  - cross-document synthesis: when the query implies comparing/summarizing across
    sources we retrieve wider, diversify across documents, and ask for a structured
    answer that draws from and cites MULTIPLE documents.
"""
from __future__ import annotations

import re
from typing import Iterator, Optional

from .store import Store
from rag.retrieve import search, documents_for_query
from rag.llm import chat, chat_stream

SYSTEM = (
    "You are a document assistant. Answer the question USING ONLY the numbered sources provided. "
    "Cite every factual claim with a square-bracket marker like [1] or [2] that refers to the source "
    "number; you may cite several like [1][3]. Do NOT use any other citation format. "
    "If the sources do not contain the answer, say exactly what is missing — never invent facts. "
    "Be concise and specific. The numbered Sources belong to THE CURRENT question only; any earlier "
    "conversation turns are context, but citation numbers always refer to the Sources listed below."
)

SYSTEM_CROSS = (
    "You are a document analyst synthesizing an answer ACROSS MULTIPLE documents. The numbered sources "
    "come from several different files. Compare and combine what the DIFFERENT documents say: organize the "
    "answer clearly (short intro, then grouped points or per-document contrasts), and make the areas of "
    "agreement and difference explicit. Cite EVERY claim with square-bracket markers like [1] or [2][4] that "
    "refer to the source number, and be sure your citations SPAN the different documents you drew from — do "
    "not lean on a single source. Use ONLY the numbered sources; never invent facts. The numbered Sources "
    "belong to THE CURRENT question only; earlier turns are context, but citations refer to the Sources below."
)

# gpt-oss sometimes emits OpenAI file-citation markers 【3†L1-L4】 instead of [3]; accept both.
_CITE_RE = re.compile(r"\[(\d+)\]|【(\d+)†[^】]*】")

# lexical cues that the user wants a synthesis spanning several documents
_CROSS_CUES = (
    "compare", "comparison", "contrast", " versus ", " vs ", " vs.", "across", "all the",
    "all of the", "each of", "each document", "both ", "differ", "difference", "differences",
    "every ", "what do the", "what do all", "which doc", "which document", "consensus",
    "agree", "disagree", "summarize the", "summarise the", "combine", "overall",
)

# pronouns / referents that mark a follow-up leaning on the prior turn
_REFERENTS = ("it", "its", "that", "those", "this", "these", "they", "them", "their",
              "he", "she", "the same", "above", "the former", "the latter")


def _normalize_citations(text: str) -> str:
    """Rewrite any 【n†…】 markers to clean [n] for display."""
    return re.sub(r"【(\d+)†[^】]*】", lambda m: f"[{m.group(1)}]", text)


def _is_cross_doc(query: str) -> bool:
    q = f" {query.lower()} "
    return any(cue in q for cue in _CROSS_CUES)


def _last_user_turn(history: Optional[list]) -> str:
    for turn in reversed(history or []):
        if (turn.get("role") if isinstance(turn, dict) else None) == "user":
            return (turn.get("content") or "").strip()
    return ""


def _retrieval_query(query: str, history: Optional[list]) -> str:
    """Expand a follow-up with the previous user question so pronoun referents resolve.
    A short query, or one containing a referent pronoun, is treated as a follow-up and
    widened with the prior turn; standalone questions are retrieved verbatim."""
    prev = _last_user_turn(history)
    if not prev:
        return query
    ql = query.lower().strip()
    words = ql.split()
    is_followup = len(words) <= 6 or any(re.search(rf"\b{re.escape(w)}\b", ql) for w in _REFERENTS)
    return f"{prev} {query}" if is_followup else query


def _diversify(hits: list[dict], per_doc: int = 3) -> list[dict]:
    """Cap chunks per document so a cross-doc answer sees SEVERAL sources, not five
    chunks of the single best file. Preserves rank order."""
    seen: dict[str, int] = {}
    out = []
    for h in hits:
        d = h["doc_id"]
        if seen.get(d, 0) >= per_doc:
            continue
        seen[d] = seen.get(d, 0) + 1
        out.append(h)
    return out


def _history_messages(history: Optional[list], limit: int = 6) -> list[dict]:
    """Prior turns as chat messages. Strip [n] markers from earlier assistant turns so
    their (now-stale) source numbers don't collide with the current question's Sources."""
    msgs = []
    for turn in (history or [])[-limit:]:
        if not isinstance(turn, dict):
            continue
        role = turn.get("role")
        content = (turn.get("content") or "").strip()
        if role not in ("user", "assistant") or not content:
            continue
        if role == "assistant":
            content = re.sub(r"\[\d+\]", "", content).strip()
        msgs.append({"role": role, "content": content})
    return msgs


def _context(hits: list[dict]) -> str:
    return "\n\n".join(
        f"[{i + 1}] ({h['doc_title']} — {h['locator'].get('label', '')})\n{h['text'][:1200]}"
        for i, h in enumerate(hits)
    )


def _retrieve(store: Store, query: str, k: int, rerank: bool,
              principals: Optional[list], history: Optional[list]) -> tuple[list[dict], bool, str]:
    """Shared retrieval for both the one-shot and streaming paths. Returns the hydrated
    hits, whether this is a cross-doc synthesis, and the (possibly expanded) query used."""
    cross = _is_cross_doc(query)
    rq = _retrieval_query(query, history)
    eff_k = max(k, 16) if cross else k
    hits = search(store, rq, k=eff_k, rerank=rerank, principals=principals)
    if cross:
        hits = _diversify(hits, per_doc=3)
    return hits, cross, rq


def _messages(query: str, hits: list[dict], history: Optional[list], cross: bool) -> list[dict]:
    msgs = [{"role": "system", "content": SYSTEM_CROSS if cross else SYSTEM}]
    msgs += _history_messages(history)
    msgs.append({"role": "user", "content": f"Question: {query}\n\nSources:\n{_context(hits)}"})
    return msgs


def _citations(answer_raw: str, hits: list[dict]) -> list[dict]:
    used = sorted({
        int(a or b) for a, b in _CITE_RE.findall(answer_raw) if 1 <= int(a or b) <= len(hits)
    })
    cites = [
        {"n": n, "doc_id": hits[n - 1]["doc_id"], "title": hits[n - 1]["doc_title"],
         "doc_type": hits[n - 1]["doc_type"], "open_at": hits[n - 1]["locator"],
         "score": hits[n - 1]["score"]}
        for n in used
    ]
    if not cites and hits:  # always give the UI a source to open
        h = hits[0]
        cites = [{"n": 1, "doc_id": h["doc_id"], "title": h["doc_title"],
                  "doc_type": h["doc_type"], "open_at": h["locator"], "score": h["score"]}]
    return cites


def ask(store: Store, query: str, k: int = 8, rerank: bool = True,
        principals: Optional[list] = None, history: Optional[list] = None) -> dict:
    hits, cross, rq = _retrieve(store, query, k, rerank, principals, history)
    if not hits:
        return {"answer": "No matching documents are indexed for that question.",
                "citations": [], "documents": [], "cross_doc": cross}

    raw = chat(_messages(query, hits, history, cross), temperature=0.2,
               max_tokens=1600 if cross else 900, reasoning_effort="low")
    answer = _normalize_citations(raw)
    return {
        "answer": answer,
        "citations": _citations(raw, hits),
        "documents": documents_for_query(store, rq, k=12, principals=principals),
        "cross_doc": cross,
    }


def ask_stream(store: Store, query: str, k: int = 8, rerank: bool = True,
               principals: Optional[list] = None, history: Optional[list] = None) -> Iterator[dict]:
    """Generator: yields {"type":"token","text":...} as the answer streams, then a single
    {"type":"final","answer","citations","documents","cross_doc"} with everything the UI
    needs to render citation chips + the pick-list. Same retrieval/permissions as `ask`."""
    hits, cross, rq = _retrieve(store, query, k, rerank, principals, history)
    if not hits:
        msg = "No matching documents are indexed for that question."
        yield {"type": "token", "text": msg}
        yield {"type": "final", "answer": msg, "citations": [], "documents": [], "cross_doc": cross}
        return

    parts: list[str] = []
    pending = ""  # hold back an unclosed 【…】 marker so it never flashes raw across deltas

    def _emit(text: str):
        clean = _normalize_citations(text)
        parts.append(clean)
        return {"type": "token", "text": clean}

    for piece in chat_stream(_messages(query, hits, history, cross), temperature=0.2,
                             max_tokens=1600 if cross else 900, reasoning_effort="low"):
        pending += piece
        cut = pending.rfind("【")
        if cut != -1 and "】" not in pending[cut:]:
            head, pending = pending[:cut], pending[cut:]  # keep the partial marker buffered
        else:
            head, pending = pending, ""
        if head:
            yield _emit(head)
    if pending:
        yield _emit(pending)

    raw = "".join(parts)
    yield {
        "type": "final",
        "answer": _normalize_citations(raw),
        "citations": _citations(raw, hits),
        "documents": documents_for_query(store, rq, k=12, principals=principals),
        "cross_doc": cross,
    }
