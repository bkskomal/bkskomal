"""Folder-sync indexer — the piece that replaces SharePoint hosting.

Point it at a folder/share; supported files auto-index, re-index when their content
changes (mtime + content hash), and drop from the index when deleted. One logical
document tracks one file LOCATION (path-based id), so edits update in place.
"""
from __future__ import annotations

import hashlib
import os

from .store import Store
from .ingest import ingest_file, SUPPORTED


def path_id(path: str) -> str:
    return hashlib.sha256(os.path.abspath(path).encode("utf-8")).hexdigest()[:16]


def scan(root: str) -> list[tuple[str, float]]:
    out: list[tuple[str, float]] = []
    for r, _, files in os.walk(root):
        for fn in files:
            if os.path.splitext(fn)[1].lower() in SUPPORTED:
                p = os.path.join(r, fn)
                try:
                    out.append((p, os.path.getmtime(p)))
                except OSError:
                    pass
    return out


def sync_root(store: Store, root: str, project: str, acl: list | None = None) -> dict:
    root = os.path.abspath(root)
    added = changed = removed = skipped = errors = 0
    seen: set[str] = set()

    for path, mtime in scan(root):
        ap = os.path.abspath(path)
        seen.add(ap)
        did = path_id(path)
        existing = store.get_document(did)
        if existing and abs(existing.get("mtime", 0) - mtime) < 1.0:
            skipped += 1
            continue
        try:
            res = ingest_file(store, path, project=project, doc_id=did, acl=acl)
            if res.get("skipped"):
                skipped += 1
            elif existing:
                changed += 1
            else:
                added += 1
        except Exception:
            errors += 1

    # deletions: docs under this root that are no longer on disk
    for d in store.documents_under(root):
        ap = os.path.abspath(d["path"])
        if ap.startswith(root + os.sep) and ap not in seen:
            store.delete_document(d["doc_id"])
            removed += 1

    result = f"added={added} changed={changed} removed={removed} skipped={skipped} errors={errors}"
    store.mark_root_synced(root, result)
    return {"root": root, "project": project, "added": added, "changed": changed,
            "removed": removed, "skipped": skipped, "errors": errors}


def sync_all(store: Store) -> list[dict]:
    return [sync_root(store, r["root"], r["project"]) for r in store.list_roots()]
