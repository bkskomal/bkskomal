"""Storage: documents + chunks + metadata in SQLite, vectors as float32 blobs,
keyword search via FTS5. Deliberately behind a small method surface so it can be
swapped for Postgres + pgvector later without touching retrieval/ingest.
"""
from __future__ import annotations

import json
import re
import sqlite3
from typing import Optional

import numpy as np

from config import DOCUMENTS_DB as DB_PATH, EMBED_DIM
from rag.models import Document, Chunk, version_family

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents(
  doc_id TEXT PRIMARY KEY, title TEXT, doc_type TEXT, path TEXT,
  project TEXT, sha256 TEXT, mtime REAL, unit_count INTEGER, indexed_at REAL,
  stored_path TEXT, acl TEXT DEFAULT '["public"]', needs_ocr INTEGER DEFAULT 0,
  source_id TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS sources(
  source_id TEXT PRIMARY KEY, type TEXT, name TEXT, config TEXT,
  project TEXT, acl TEXT DEFAULT '["public"]', status TEXT DEFAULT 'new',
  cursor TEXT DEFAULT '', last_sync REAL DEFAULT 0, last_result TEXT DEFAULT '',
  doc_count INTEGER DEFAULT 0, added_at REAL
);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL, principal TEXT, action TEXT, query TEXT, doc_ids TEXT, n_results INTEGER
);
CREATE TABLE IF NOT EXISTS chunks(
  chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
  doc_id TEXT, ord INTEGER, text TEXT, heading_context TEXT,
  token_est INTEGER, locator_json TEXT, embedding BLOB
);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(doc_id);
CREATE INDEX IF NOT EXISTS idx_documents_path ON documents(path);
CREATE TABLE IF NOT EXISTS watched_roots(
  root TEXT PRIMARY KEY, project TEXT, added_at REAL, last_sync REAL, last_result TEXT
);
"""


def _fts_query(q: str) -> Optional[str]:
    toks = [t for t in re.findall(r"[A-Za-z0-9]+", q.lower()) if len(t) > 1][:24]
    return " OR ".join(f'"{t}"' for t in toks) if toks else None


class Store:
    def __init__(self, db_path: str = DB_PATH):
        # check_same_thread=False: FastAPI serves handlers from a threadpool. Writes are
        # serialized by the app's low concurrency; WAL keeps concurrent reads clean.
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)
        self._migrate()
        self._has_fts = self._init_fts()
        self._vec_cache: Optional[tuple] = None

    def _migrate(self) -> None:
        """Add columns introduced after the original schema to pre-existing DBs."""
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(documents)")}
        if "acl" not in cols:
            self.db.execute("ALTER TABLE documents ADD COLUMN acl TEXT DEFAULT '[\"public\"]'")
            self.db.commit()
        if "needs_ocr" not in cols:
            self.db.execute("ALTER TABLE documents ADD COLUMN needs_ocr INTEGER DEFAULT 0")
            self.db.commit()
        if "source_id" not in cols:
            self.db.execute("ALTER TABLE documents ADD COLUMN source_id TEXT DEFAULT ''")
            self.db.commit()
        # column now guaranteed to exist (fresh schema or just-added) — index it
        self.db.execute("CREATE INDEX IF NOT EXISTS idx_documents_source ON documents(source_id)")
        self.db.commit()

    def _init_fts(self) -> bool:
        try:
            self.db.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(text, heading_context, chunk_id UNINDEXED)"
            )
            self.db.commit()
            return True
        except sqlite3.OperationalError:
            return False  # fts5 unavailable → keyword search falls back to LIKE

    # ---------------------------------------------------------------- documents
    def get_document(self, doc_id: str) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM documents WHERE doc_id=?", (doc_id,)).fetchone()
        return dict(row) if row else None

    def upsert_document(self, doc: Document, stored_path: str = "") -> None:
        acl = doc.acl if getattr(doc, "acl", None) else ["public"]
        self.db.execute(
            """INSERT OR REPLACE INTO documents
               (doc_id,title,doc_type,path,project,sha256,mtime,unit_count,indexed_at,stored_path,acl,needs_ocr,source_id)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (doc.doc_id, doc.title, doc.doc_type, doc.path, doc.project, doc.sha256,
             doc.mtime, doc.unit_count, doc.indexed_at, stored_path, json.dumps(acl),
             1 if getattr(doc, "needs_ocr", False) else 0, getattr(doc, "source_id", "") or ""),
        )
        self.db.commit()

    def set_project(self, doc_id: str, project: str) -> None:
        """Move a document into a folder (path stored in the `project` field)."""
        self.db.execute("UPDATE documents SET project=? WHERE doc_id=?", (project or "", doc_id))
        self.db.commit()

    # ---------------------------------------------------------------- access control
    def set_acl(self, doc_id: str, acl: list) -> None:
        self.db.execute("UPDATE documents SET acl=? WHERE doc_id=?", (json.dumps(acl or ["public"]), doc_id))
        self.db.commit()

    def get_acl(self, doc_id: str) -> list:
        row = self.db.execute("SELECT acl FROM documents WHERE doc_id=?", (doc_id,)).fetchone()
        if not row:
            return []
        try:
            return json.loads(row["acl"]) if row["acl"] else ["public"]
        except (ValueError, TypeError):
            return ["public"]

    def is_visible(self, doc_id: str, principals) -> bool:
        """True iff the document's ACL shares at least one principal with the caller."""
        return bool(set(self.get_acl(doc_id)) & set(principals or []))

    def visible_doc_ids(self, principals) -> set:
        """Set of doc_ids whose ACL intersects the caller's principals."""
        pset = set(principals or [])
        out: set = set()
        for r in self.db.execute("SELECT doc_id, acl FROM documents"):
            try:
                acl = json.loads(r["acl"]) if r["acl"] else ["public"]
            except (ValueError, TypeError):
                acl = ["public"]
            if pset & set(acl):
                out.add(r["doc_id"])
        return out

    # ---------------------------------------------------------------- audit
    def log_audit(self, principal, action: str, query: str, doc_ids, n: int) -> None:
        import time
        if isinstance(principal, (list, set, tuple)):
            principal = ",".join(principal)
        self.db.execute(
            "INSERT INTO audit(ts,principal,action,query,doc_ids,n_results) VALUES(?,?,?,?,?,?)",
            (time.time(), principal, action, query, json.dumps(list(doc_ids or [])), int(n)),
        )
        self.db.commit()

    def list_audit(self, limit: int = 100) -> list[dict]:
        rows = self.db.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["doc_ids"] = json.loads(d["doc_ids"]) if d["doc_ids"] else []
            except (ValueError, TypeError):
                d["doc_ids"] = []
            out.append(d)
        return out

    def delete_document(self, doc_id: str) -> None:
        ids = [r["chunk_id"] for r in self.db.execute("SELECT chunk_id FROM chunks WHERE doc_id=?", (doc_id,))]
        self.db.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
        if self._has_fts and ids:
            self.db.executemany("DELETE FROM chunks_fts WHERE chunk_id=?", [(i,) for i in ids])
        self.db.execute("DELETE FROM documents WHERE doc_id=?", (doc_id,))
        self.db.commit()
        self._vec_cache = None

    def get_document_by_path(self, path: str) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM documents WHERE path=? LIMIT 1", (path,)).fetchone()
        return dict(row) if row else None

    def documents_under(self, root: str) -> list[dict]:
        return [dict(r) for r in self.db.execute("SELECT * FROM documents WHERE path LIKE ?", (root + "%",))]

    def list_documents(self, project: str = "", doc_type: str = "", query: str = "") -> list[dict]:
        sql = "SELECT * FROM documents WHERE 1=1"
        args: list = []
        if project:
            sql += " AND project=?"; args.append(project)
        if doc_type:
            sql += " AND doc_type=?"; args.append(doc_type)
        if query:
            sql += " AND title LIKE ?"; args.append(f"%{query}%")
        sql += " ORDER BY indexed_at DESC"
        return [dict(r) for r in self.db.execute(sql, args)]

    def documents_by_family(self, project: str = "", principals=None) -> list[dict]:
        """Group documents by version FAMILY so the UI can show "N versions" and mark the
        latest by mtime. Does NOT merge indexes — every distinct document is preserved and
        still independently retrievable; this is purely an awareness/grouping view."""
        docs = self.list_documents(project=project)
        if principals is not None:
            vis = self.visible_doc_ids(principals)
            docs = [d for d in docs if d["doc_id"] in vis]
        fams: dict[str, list] = {}
        for d in docs:
            fams.setdefault(version_family(d.get("title", "")), []).append(d)
        out = []
        for key, members in fams.items():
            members.sort(key=lambda x: (x.get("mtime") or 0, x.get("indexed_at") or 0), reverse=True)
            latest = members[0]["doc_id"]
            out.append({
                "family": key,
                "count": len(members),
                "latest_doc_id": latest,
                "documents": [{**m, "is_latest": (m["doc_id"] == latest)} for m in members],
            })
        out.sort(key=lambda f: (-f["count"], f["family"]))
        return out

    # ---------------------------------------------------------------- watched roots
    def add_root(self, root: str, project: str) -> None:
        import time
        self.db.execute(
            "INSERT OR REPLACE INTO watched_roots(root,project,added_at,last_sync,last_result) "
            "VALUES(?,?,?,COALESCE((SELECT last_sync FROM watched_roots WHERE root=?),0),"
            "COALESCE((SELECT last_result FROM watched_roots WHERE root=?),''))",
            (root, project, time.time(), root, root),
        )
        self.db.commit()

    def list_roots(self) -> list[dict]:
        return [dict(r) for r in self.db.execute("SELECT * FROM watched_roots ORDER BY added_at")]

    def remove_root(self, root: str) -> None:
        self.db.execute("DELETE FROM watched_roots WHERE root=?", (root,))
        self.db.commit()

    def mark_root_synced(self, root: str, result: str) -> None:
        import time
        self.db.execute("UPDATE watched_roots SET last_sync=?, last_result=? WHERE root=?", (time.time(), result, root))
        self.db.commit()

    # ---------------------------------------------------------------- connector sources
    def add_source(self, source_id: str, type: str, name: str, config: dict,
                   project: str = "", acl: list | None = None) -> dict:
        import time
        self.db.execute(
            """INSERT OR REPLACE INTO sources
               (source_id,type,name,config,project,acl,status,cursor,last_sync,last_result,doc_count,added_at)
               VALUES(?,?,?,?,?,?,?,
                      COALESCE((SELECT cursor FROM sources WHERE source_id=?),''),
                      COALESCE((SELECT last_sync FROM sources WHERE source_id=?),0),
                      COALESCE((SELECT last_result FROM sources WHERE source_id=?),''),
                      COALESCE((SELECT doc_count FROM sources WHERE source_id=?),0),
                      COALESCE((SELECT added_at FROM sources WHERE source_id=?),?))""",
            (source_id, type, name, json.dumps(config or {}), project,
             json.dumps(acl or ["public"]), "configured",
             source_id, source_id, source_id, source_id, source_id, time.time()),
        )
        self.db.commit()
        return self.get_source(source_id)

    def get_source(self, source_id: str) -> Optional[dict]:
        row = self.db.execute("SELECT * FROM sources WHERE source_id=?", (source_id,)).fetchone()
        return self._hydrate_source(row) if row else None

    def list_sources(self) -> list[dict]:
        return [self._hydrate_source(r) for r in
                self.db.execute("SELECT * FROM sources ORDER BY added_at")]

    def _hydrate_source(self, row) -> dict:
        d = dict(row)
        try:
            d["config"] = json.loads(d["config"]) if d.get("config") else {}
        except (ValueError, TypeError):
            d["config"] = {}
        try:
            d["acl"] = json.loads(d["acl"]) if d.get("acl") else ["public"]
        except (ValueError, TypeError):
            d["acl"] = ["public"]
        d["doc_count"] = self.count_source_docs(d["source_id"])
        return d

    def update_source(self, source_id: str, *, status: str | None = None, cursor: str | None = None,
                      last_result: str | None = None, mark_synced: bool = False) -> None:
        import time
        sets, args = [], []
        if status is not None:
            sets.append("status=?"); args.append(status)
        if cursor is not None:
            sets.append("cursor=?"); args.append(cursor)
        if last_result is not None:
            sets.append("last_result=?"); args.append(last_result)
        if mark_synced:
            sets.append("last_sync=?"); args.append(time.time())
        if not sets:
            return
        args.append(source_id)
        self.db.execute(f"UPDATE sources SET {', '.join(sets)} WHERE source_id=?", args)
        self.db.commit()

    def count_source_docs(self, source_id: str) -> int:
        row = self.db.execute("SELECT COUNT(*) AS n FROM documents WHERE source_id=?", (source_id,)).fetchone()
        return int(row["n"]) if row else 0

    def documents_for_source(self, source_id: str) -> list[dict]:
        return [dict(r) for r in self.db.execute("SELECT * FROM documents WHERE source_id=?", (source_id,))]

    def remove_source(self, source_id: str) -> None:
        self.db.execute("DELETE FROM sources WHERE source_id=?", (source_id,))
        self.db.commit()

    # ---------------------------------------------------------------- chunks
    def add_chunks(self, chunks: list[Chunk], embeddings: list[np.ndarray]) -> None:
        cur = self.db.cursor()
        for c, e in zip(chunks, embeddings):
            cur.execute(
                """INSERT INTO chunks(doc_id,ord,text,heading_context,token_est,locator_json,embedding)
                   VALUES(?,?,?,?,?,?,?)""",
                (c.doc_id, c.ord, c.text, c.heading_context, c.token_est,
                 json.dumps(c.locator.to_dict()), np.asarray(e, dtype=np.float32).tobytes()),
            )
            if self._has_fts:
                cur.execute(
                    "INSERT INTO chunks_fts(text,heading_context,chunk_id) VALUES(?,?,?)",
                    (c.text, c.heading_context, cur.lastrowid),
                )
        self.db.commit()
        self._vec_cache = None

    def get_chunk(self, chunk_id: int) -> Optional[dict]:
        row = self.db.execute(
            """SELECT c.chunk_id,c.doc_id,c.ord,c.text,c.heading_context,c.locator_json,
                      d.title AS doc_title, d.doc_type, d.project, d.path
               FROM chunks c JOIN documents d ON d.doc_id=c.doc_id WHERE c.chunk_id=?""",
            (chunk_id,),
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["locator"] = json.loads(d.pop("locator_json"))
        return d

    # ---------------------------------------------------------------- retrieval primitives
    def load_vectors(self, project_id=None):
        """(chunk_ids: np.int64[N], matrix: float32[N,dim]) for cosine search. Cached.
        `project_id` is accepted for a uniform store interface with the project-scoped
        tool but unused here — Document Management scopes by ACL, not by project."""
        if self._vec_cache is not None:
            return self._vec_cache
        rows = self.db.execute("SELECT chunk_id, embedding FROM chunks").fetchall()
        if not rows:
            self._vec_cache = (np.zeros(0, np.int64), np.zeros((0, EMBED_DIM), np.float32))
            return self._vec_cache
        ids = np.fromiter((r["chunk_id"] for r in rows), dtype=np.int64, count=len(rows))
        mat = np.vstack([np.frombuffer(r["embedding"], dtype=np.float32) for r in rows])
        self._vec_cache = (ids, mat)
        return self._vec_cache

    def keyword_search(self, query: str, limit: int = 30, project_id=None) -> list[tuple[int, float]]:
        # `project_id` accepted for interface uniformity; ACL filtering happens in retrieve.
        if self._has_fts:
            fq = _fts_query(query)
            if not fq:
                return []
            try:
                rows = self.db.execute(
                    "SELECT chunk_id, bm25(chunks_fts) AS r FROM chunks_fts WHERE chunks_fts MATCH ? ORDER BY r LIMIT ?",
                    (fq, limit),
                ).fetchall()
                return [(int(r["chunk_id"]), -float(r["r"])) for r in rows]  # lower bm25 = better
            except sqlite3.OperationalError:
                pass
        like = f"%{query[:60]}%"
        rows = self.db.execute("SELECT chunk_id FROM chunks WHERE text LIKE ? LIMIT ?", (like, limit)).fetchall()
        return [(int(r["chunk_id"]), 1.0) for r in rows]
