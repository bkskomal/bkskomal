"""Ingestion: file -> anchored chunks -> embeddings -> store. Keeps a copy of the
original bytes so the library can re-open / download it. Content-addressed by sha256
so re-ingesting the same file is idempotent."""
from __future__ import annotations

import hashlib
import os
import shutil
import time

from config import DOCUMENTS_FILES as FILES_DIR
from rag.extract import extract, doc_type_of, EXTRACTORS
from rag.embed import embed_passages
from rag.models import Document, Locator, Chunk, est_tokens
from .store import Store

# Kept in sync with the extractor registry so folder-sync and uploads accept exactly the
# types we can actually extract (xlsx is present only when openpyxl is installed).
SUPPORTED = set(EXTRACTORS.keys())


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def ingest_file(store: Store, path: str, project: str = "", doc_id: str | None = None,
                acl: list | None = None, origin: str | None = None,
                title: str | None = None, source_id: str = "") -> dict:
    """Ingest a file. doc_id defaults to a CONTENT hash (uploads dedupe by content);
    folder-sync passes a PATH-based id so one logical doc tracks one file location and
    re-indexes when the content changes.

    Connector items pass `origin` (a synthetic locator like a URL / mbox://file#msg3 /
    gdrive://<id>), a `title`, and a `source_id`. `path` is still the bytes we read +
    extract (a temp file for remote items), but the DB stores `origin` as the document's
    path so the library shows a meaningful source and incremental skip compares against a
    STABLE origin (temp paths change every sync). Local files leave origin=None so the
    real on-disk path is kept exactly as before."""
    dt = doc_type_of(path)
    if not dt:
        raise ValueError(f"unsupported file type: {path}")
    sha = _sha256(path)
    did = doc_id or sha[:16]
    stored_origin = origin or path
    existing = store.get_document(did)
    if existing and existing.get("sha256") == sha and existing.get("path") == stored_origin:
        if acl is not None:  # allow an ACL update without a full re-index
            store.set_acl(did, list(acl))
        return {**existing, "skipped": True}

    chunks, units = extract(path, did)

    # Coverage: a document that yields NO chunks is typically a scanned/image-only file
    # (or empty). Rather than dropping it, flag needs_ocr and index a visible placeholder
    # so it appears in the library. Per-page scanned placeholders (mixed PDFs) are emitted
    # inside extract_pdf and also carry locator.needs_ocr.
    needs_ocr = any(getattr(c.locator, "needs_ocr", None) for c in chunks)
    if not chunks:
        needs_ocr = True
        msg = "[No extractable text — likely a scanned/image document; OCR unavailable]"
        loc = Locator(doc_type=dt, label="No extractable text", needs_ocr=True, quote=msg)
        chunks = [Chunk(did, 0, msg, loc, token_est=est_tokens(msg))]

    embeddings = embed_passages([c.text for c in chunks]) if chunks else []

    stored = os.path.join(FILES_DIR, f"{did}{os.path.splitext(path)[1].lower()}")
    shutil.copy2(path, stored)  # always refresh (content may have changed on re-ingest)
    # drop any stale cached preview so it regenerates from the new content
    stale_preview = os.path.join(FILES_DIR, f"{did}.preview.pdf")
    if os.path.exists(stale_preview):
        try:
            os.remove(stale_preview)
        except OSError:
            pass

    doc = Document(
        doc_id=did, title=title or os.path.splitext(os.path.basename(path))[0], doc_type=dt,
        path=stored_origin, project=project, sha256=sha, mtime=os.path.getmtime(path),
        unit_count=units, indexed_at=time.time(), acl=list(acl) if acl else ["public"],
        needs_ocr=needs_ocr, source_id=source_id,
    )
    store.delete_document(did)
    store.upsert_document(doc, stored_path=stored)
    store.add_chunks(chunks, embeddings)
    return {**doc.to_dict(), "chunks": len(chunks), "skipped": False}


def ingest_folder(store: Store, folder: str, project: str = "", acl: list | None = None) -> list[dict]:
    out = []
    for root, _, files in os.walk(folder):
        for fn in sorted(files):
            if os.path.splitext(fn)[1].lower() in SUPPORTED:
                try:
                    out.append(ingest_file(store, os.path.join(root, fn), project, acl=acl))
                except Exception as e:
                    out.append({"path": os.path.join(root, fn), "error": f"{type(e).__name__}: {e}"})
    return out
