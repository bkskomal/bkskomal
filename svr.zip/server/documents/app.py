"""Document Management API — browse, search, ask, and open source files at anchors.

Run: uvicorn app:app --port 8920   (from service/)
"""
from __future__ import annotations

import os
import tempfile

from typing import Optional

import httpx

import json as _json

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

HUB_BASE = os.environ.get("HUB_BASE", "http://localhost:8900")

import os
import threading
import time

from .store import Store
from .ingest import ingest_file, ingest_folder
from rag.retrieve import search, documents_for_query
from .qa import ask as qa_ask, ask_stream as qa_ask_stream
from .preview import ensure_preview, preview_path
from .sync import sync_all, sync_root
from .connectors import (connector_types, sync_source, sync_configured_sources,
                        build_connector, REGISTRY)

app = FastAPI(title="Document Management")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
store = Store()

_MIME = {
    "pdf": "application/pdf",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "txt": "text/plain; charset=utf-8",
    "md": "text/markdown; charset=utf-8",
    "html": "text/html; charset=utf-8",
    "eml": "message/rfc822",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "csv": "text/csv; charset=utf-8",
}


def caller_principals(x_dm_user: Optional[str], x_dm_groups: Optional[str]) -> list[str]:
    """Map request identity headers to the caller's principal set.

    This is the SSO-pluggable seam: a real SSO/reverse-proxy populates these headers
    from the authenticated session. With no headers the caller is anonymous → `public`,
    which preserves the pre-security behavior (public docs stay world-readable).
      X-DM-User: alice          -> user:alice
      X-DM-Groups: alpha,beta    -> group:alpha, group:beta
    `public` is ALWAYS appended.
    """
    principals: list[str] = []
    if x_dm_user and x_dm_user.strip():
        principals.append(f"user:{x_dm_user.strip()}")
    if x_dm_groups:
        for g in x_dm_groups.split(","):
            g = g.strip()
            if g:
                principals.append(f"group:{g}")
    principals.append("public")
    return principals


class Turn(BaseModel):
    role: str
    content: str


class AskBody(BaseModel):
    query: str
    k: int = 8
    # prior conversation turns for multi-turn follow-ups ("what about the risks?").
    history: Optional[list[Turn]] = None


class IngestBody(BaseModel):
    path: str
    project: str = ""
    acl: Optional[list[str]] = None


class FolderBody(BaseModel):
    folder: str
    project: str = ""
    acl: Optional[list[str]] = None


class MoveBody(BaseModel):
    project: str = ""


class RenameFolderBody(BaseModel):
    old: str
    new: str


class DeleteFolderBody(BaseModel):
    path: str


@app.get("/health")
def health():
    return {"ok": True, "documents": len(store.list_documents())}


# ---- SSO (suite single sign-on consumer) ------------------------------------
@app.get("/sso")
def sso(token: Optional[str] = None):
    """Verify an SSO token against the suite Hub and return the signed-in username.

    The Hub (identity authority) exposes GET /api/sso/verify?token=<t> -> {"username": u}.
    OATIGenie opens this tool with ?sso=<token>; the frontend calls here to resolve the
    VERIFIED username, which it then sends per-request as X-DM-User. 401 on any failure.
    """
    if not token or not token.strip():
        raise HTTPException(401, "missing token")
    try:
        r = httpx.get(f"{HUB_BASE}/api/sso/verify", params={"token": token}, timeout=5.0)
    except httpx.HTTPError:
        raise HTTPException(401, "hub unreachable")
    if r.status_code != 200:
        raise HTTPException(401, "invalid token")
    username = (r.json() or {}).get("username")
    if not username:
        raise HTTPException(401, "invalid token")
    return {"username": username}


# ---- AUDIT -------------------------------------------------------------------
@app.get("/audit")
def audit(limit: int = 100):
    """Recent access-audit rows (most recent first). Each /ask logs the caller's
    principals, the query, and the doc_ids actually cited."""
    return {"audit": store.list_audit(limit=limit)}


# ---- BROWSE (manual) ---------------------------------------------------------
@app.get("/documents")
def documents(project: str = "", type: str = "", query: str = "",
              x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    principals = caller_principals(x_dm_user, x_dm_groups)
    visible = store.visible_doc_ids(principals)
    docs = store.list_documents(project=project, doc_type=type, query=query)
    return {"documents": [d for d in docs if d["doc_id"] in visible]}


@app.get("/documents/families")
def document_families(project: str = "",
                      x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Documents grouped by version family — the UI shows "N versions" and flags the
    latest by mtime. Permission-filtered; indexes are never merged."""
    principals = caller_principals(x_dm_user, x_dm_groups)
    return {"families": store.documents_by_family(project=project, principals=principals)}


# ---- SEARCH / ASK (AI RAG) ---------------------------------------------------
@app.post("/search")
def search_endpoint(body: AskBody,
                    x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    principals = caller_principals(x_dm_user, x_dm_groups)
    return {"hits": search(store, body.query, k=body.k, principals=principals)}


@app.post("/ask")
def ask_endpoint(body: AskBody,
                 x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Grounded answer + [n] citations (each openable at its anchor) + the multi-match
    document pick-list for when the query spans several files. Permission-filtered:
    only documents visible to the caller can be retrieved, ranked, or cited."""
    principals = caller_principals(x_dm_user, x_dm_groups)
    history = [t.dict() for t in (body.history or [])]
    res = qa_ask(store, body.query, k=body.k, principals=principals, history=history)
    cited = [c["doc_id"] for c in res.get("citations", [])]
    store.log_audit(principals, "ask", body.query, cited, len(cited))
    return res


@app.post("/ask/stream")
def ask_stream_endpoint(body: AskBody,
                        x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """SSE streaming version of /ask. Runs the SAME permission-filtered retrieval (reranker +
    exact-anchor locators + multi-turn history), streams the model's answer tokens as
    `data:` events, then sends a final event with citations + the document pick-list. Audit
    logging is preserved (the cited doc_ids are captured from the final event)."""
    principals = caller_principals(x_dm_user, x_dm_groups)
    history = [t.dict() for t in (body.history or [])]

    def gen():
        cited: list[str] = []
        try:
            for ev in qa_ask_stream(store, body.query, k=body.k, principals=principals, history=history):
                if ev.get("type") == "final":
                    cited = [c["doc_id"] for c in ev.get("citations", [])]
                yield f"data: {_json.dumps(ev, ensure_ascii=False)}\n\n"
        except Exception as e:  # noqa: BLE001 — surface a clean error frame; client falls back to /ask
            yield f"data: {_json.dumps({'type': 'error', 'message': str(e)})}\n\n"
        finally:
            store.log_audit(principals, "ask/stream", body.query, cited, len(cited))
            yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                                      "Connection": "keep-alive"})


@app.post("/documents/search")
def documents_search(body: AskBody,
                     x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Ranked document pick-list — 'get all AutoRFP documents' / 'load the AutoRFP ppt'."""
    principals = caller_principals(x_dm_user, x_dm_groups)
    return {"documents": documents_for_query(store, body.query, k=body.k, principals=principals)}


# ---- OPEN / DOWNLOAD the source at its anchor --------------------------------
@app.get("/file/{doc_id}")
def file(doc_id: str, download: bool = False,
         x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    d = store.get_document(doc_id)
    if not d:
        raise HTTPException(404, "document not found")
    if not store.is_visible(doc_id, caller_principals(x_dm_user, x_dm_groups)):
        raise HTTPException(403, "forbidden")
    src = d.get("stored_path") or d.get("path")
    if not src or not os.path.exists(src):
        raise HTTPException(410, "source file missing")
    disp = "attachment" if download else "inline"
    return FileResponse(
        src, media_type=_MIME.get(d["doc_type"], "application/octet-stream"),
        filename=f"{d['title']}.{d['doc_type']}",
        headers={"Content-Disposition": f'{disp}; filename="{d["title"]}.{d["doc_type"]}"'},
    )


@app.get("/preview/{doc_id}")
def preview(doc_id: str,
            x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Unified preview PDF (pdf as-is; pptx/docx rendered via LibreOffice). The UI
    opens this at the citation's page. Falls back to the original if not renderable."""
    d = store.get_document(doc_id)
    if not d:
        raise HTTPException(404, "document not found")
    if not store.is_visible(doc_id, caller_principals(x_dm_user, x_dm_groups)):
        raise HTTPException(403, "forbidden")
    src = d.get("stored_path") or d.get("path")
    pdf = ensure_preview(doc_id, src, d["doc_type"])
    if pdf:
        return FileResponse(pdf, media_type="application/pdf",
                            headers={"Content-Disposition": f'inline; filename="{d["title"]}.pdf"'})
    if src and os.path.exists(src):
        return FileResponse(src, media_type=_MIME.get(d["doc_type"], "application/octet-stream"))
    raise HTTPException(410, "source file missing")


@app.get("/documents/{doc_id}")
def document_meta(doc_id: str,
                  x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    d = store.get_document(doc_id)
    if not d:
        raise HTTPException(404, "document not found")
    if not store.is_visible(doc_id, caller_principals(x_dm_user, x_dm_groups)):
        raise HTTPException(403, "forbidden")
    return d


@app.delete("/documents/{doc_id}")
def delete_document(doc_id: str,
                    x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Remove a document from the library — index rows, chunks, the stored original, and
    the cached preview PDF. Permission-safe: 404 if unknown, 403 if not visible to the
    caller (same visibility gate as open/download)."""
    d = store.get_document(doc_id)
    if not d:
        raise HTTPException(404, "document not found")
    if not store.is_visible(doc_id, caller_principals(x_dm_user, x_dm_groups)):
        raise HTTPException(403, "forbidden")
    # remove the stored original + cached preview from disk (best-effort)
    for p in (d.get("stored_path"), preview_path(doc_id)):
        if p and os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass
    store.delete_document(doc_id)
    return {"ok": True, "deleted": doc_id}


# ---- FOLDERS 2.0 (nested path folders live in the document's `project` field) ----
@app.post("/documents/{doc_id}/move")
def move_document(doc_id: str, body: MoveBody,
                  x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Move a document into a folder — sets its `project` to the new folder PATH. Powers
    drag-a-document-into-a-folder. Permission-safe: 404 unknown, 403 not visible."""
    d = store.get_document(doc_id)
    if not d:
        raise HTTPException(404, "document not found")
    if not store.is_visible(doc_id, caller_principals(x_dm_user, x_dm_groups)):
        raise HTTPException(403, "forbidden")
    project = (body.project or "").strip().strip("/")
    store.set_project(doc_id, project)
    return {"ok": True, "doc_id": doc_id, "project": project}


@app.post("/folders/rename")
def rename_folder(body: RenameFolderBody,
                  x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Rename/move a folder path. For every VISIBLE doc whose project == old OR starts with
    `old + '/'`, replace that prefix with `new` — so renaming CodeGen also carries
    CodeGen/Backend → NewName/Backend. Permission-filtered."""
    old = (body.old or "").strip().strip("/")
    new = (body.new or "").strip().strip("/")
    if not old or not new:
        raise HTTPException(400, "old and new paths required")
    principals = caller_principals(x_dm_user, x_dm_groups)
    visible = store.visible_doc_ids(principals)
    moved = 0
    for d in store.list_documents():
        if d["doc_id"] not in visible:
            continue
        p = d.get("project") or ""
        if p == old:
            store.set_project(d["doc_id"], new)
            moved += 1
        elif p.startswith(old + "/"):
            store.set_project(d["doc_id"], new + p[len(old):])
            moved += 1
    return {"ok": True, "moved": moved, "old": old, "new": new}


@app.post("/folders/delete")
def delete_folder(body: DeleteFolderBody,
                  x_dm_user: Optional[str] = Header(None), x_dm_groups: Optional[str] = Header(None)):
    """Delete a folder subtree — every VISIBLE doc whose project == path OR starts with
    `path + '/'` is removed (stored original + cached preview + index rows), reusing the
    single-document delete path. Permission-filtered. Returns how many were deleted."""
    path = (body.path or "").strip().strip("/")
    if not path:
        raise HTTPException(400, "path required")
    principals = caller_principals(x_dm_user, x_dm_groups)
    visible = store.visible_doc_ids(principals)
    deleted = 0
    for d in store.list_documents():
        if d["doc_id"] not in visible:
            continue
        p = d.get("project") or ""
        if p == path or p.startswith(path + "/"):
            for fp in (d.get("stored_path"), preview_path(d["doc_id"])):
                if fp and os.path.exists(fp):
                    try:
                        os.remove(fp)
                    except OSError:
                        pass
            store.delete_document(d["doc_id"])
            deleted += 1
    return {"ok": True, "deleted": deleted, "path": path}


# ---- INGEST ------------------------------------------------------------------
@app.post("/ingest")
def ingest(body: IngestBody):
    return ingest_file(store, body.path, project=body.project, acl=body.acl)


@app.post("/ingest-folder")
def ingest_folder_endpoint(body: FolderBody):
    return {"results": ingest_folder(store, body.folder, project=body.project, acl=body.acl)}


@app.post("/upload")
async def upload(file: UploadFile = File(...), project: str = Form(""), acl: str = Form("")):
    import json as _json
    acl_list = None
    if acl.strip():
        try:
            acl_list = _json.loads(acl)
        except ValueError:
            acl_list = [p.strip() for p in acl.split(",") if p.strip()]
    # Preserve the ORIGINAL filename (write into a temp DIR under its real name) so the
    # document keeps its title instead of a "tmpXXXX" temp name.
    safe_name = os.path.basename((file.filename or "upload").replace("\\", "/")) or "upload"
    tmp_dir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp_dir, safe_name)
    with open(tmp_path, "wb") as f:
        f.write(await file.read())
    try:
        return ingest_file(store, tmp_path, project=project, acl=acl_list)
    finally:
        try:
            os.remove(tmp_path); os.rmdir(tmp_dir)
        except OSError:
            pass


# ---- CONNECTORS (pluggable sources: folder / mbox / url / gdrive / slack) ----
_sync_lock = threading.Lock()


class ConnectorBody(BaseModel):
    type: str
    name: str = ""
    config: dict = {}
    project: str = ""
    acl: Optional[list[str]] = None
    source_id: Optional[str] = None   # pass to update an existing source in place


@app.get("/connectors/types")
def connectors_types():
    """Catalog of available source types + their config-field hints + credential gating."""
    return {"types": connector_types()}


@app.get("/connectors")
def list_connectors():
    """Configured sources with live status, cursor, last result, and doc counts."""
    sources = store.list_sources()
    # never leak stored secrets back to the browser — redact credential blobs
    for s in sources:
        creds = (s.get("config") or {}).get("credentials")
        if isinstance(creds, dict):
            s["config"] = {**s["config"],
                           "credentials": {k: "••••" for k in creds}}
    return {"connectors": sources}


@app.post("/connectors")
def add_connector(body: ConnectorBody):
    if body.type not in REGISTRY:
        raise HTTPException(400, f"unknown connector type: {body.type}")
    import uuid
    source_id = body.source_id or f"{body.type}-{uuid.uuid4().hex[:8]}"
    name = body.name.strip() or body.type
    store.add_source(source_id, body.type, name, body.config or {},
                     project=body.project, acl=body.acl)
    return store.get_source(source_id)


@app.post("/connectors/{source_id}/sync")
def sync_connector(source_id: str):
    if not store.get_source(source_id):
        raise HTTPException(404, "source not found")
    with _sync_lock:
        try:
            return sync_source(store, source_id)
        except ValueError as e:
            raise HTTPException(400, str(e))


def _delete_source_docs(source_id: str) -> int:
    """Remove every document a source ingested (index rows + stored originals + previews)."""
    deleted = 0
    for d in store.documents_for_source(source_id):
        for fp in (d.get("stored_path"), preview_path(d["doc_id"])):
            if fp and os.path.exists(fp):
                try:
                    os.remove(fp)
                except OSError:
                    pass
        store.delete_document(d["doc_id"])
        deleted += 1
    return deleted


@app.delete("/connectors/{source_id}")
def delete_connector(source_id: str, purge: bool = True):
    """Remove a source. By default also purges the documents it ingested."""
    if not store.get_source(source_id):
        raise HTTPException(404, "source not found")
    deleted = _delete_source_docs(source_id) if purge else 0
    store.remove_source(source_id)
    return {"ok": True, "source_id": source_id, "documents_deleted": deleted}


# ---- FOLDER SYNC (replace-SharePoint) ---------------------------------------
_SYNC_INTERVAL = int(os.environ.get("DM_SYNC_INTERVAL", "120"))


@app.get("/sync/roots")
def sync_roots():
    return {"roots": store.list_roots()}


@app.post("/sync/roots")
def add_sync_root(body: FolderBody):
    root = os.path.abspath(body.folder)
    if not os.path.isdir(root):
        raise HTTPException(400, "folder not found")
    store.add_root(root, body.project)
    with _sync_lock:
        return sync_root(store, root, body.project, acl=body.acl)


@app.delete("/sync/roots")
def del_sync_root(body: FolderBody):
    store.remove_root(os.path.abspath(body.folder))
    return {"ok": True}


@app.post("/sync/run")
def run_sync():
    """Sync legacy watched roots AND every fully-configured connector source (credential-
    gated sources with no credential are skipped, never errored)."""
    with _sync_lock:
        roots = sync_all(store)
        sources = sync_configured_sources(store)
    return {"results": roots, "connectors": sources}


def _sync_loop():
    while not _STOP.wait(_SYNC_INTERVAL):
        try:
            with _sync_lock:
                if store.list_roots():
                    sync_all(store)
                if store.list_sources():
                    sync_configured_sources(store)
        except Exception:
            pass


_STOP = threading.Event()


@app.on_event("startup")
def _start_bg_sync():
    if _SYNC_INTERVAL > 0:
        threading.Thread(target=_sync_loop, daemon=True).start()
