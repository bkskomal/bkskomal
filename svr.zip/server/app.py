"""OATIGenie unified backend — ONE FastAPI app serving every tool over a shared RAG
core and a single identity.

Run (from server/):
    uvicorn app:app --port 8900

Mounted tools (each keeps its original endpoint paths, now under a prefix):
    /documents/*   Document Management  (browse / search / ask / open-at-anchor / connectors)
    /projects/*    Project Management   (projects / notes / tasks / RAG ask / integrations)
    /compare/*     Files Comparison     (xlsx / doc diff)
    /ppt/*         PPT export + embeddings sidecar (/ppt/v1/embeddings, extract-text, HD export)
    /health        aggregate health across every tool + shared services

Identity: every router derives its principals/uid from ONE header, `X-OATI-User`
(+ optional `X-OATI-Groups`). An ASGI shim maps it onto each tool's native header, and
the legacy headers (X-DM-User / X-PM-User / X-FC-User) still work as a fallback.

Shared RAG core: `server/rag/` (anchor extraction, BGE embeddings, hybrid BGE+FTS5+RRF
retrieval, LLM rerank, citations) is imported by BOTH /documents and /projects — one
module, not two copies.
"""
from __future__ import annotations

import config  # noqa: F401 — ensures the shared data dir + env are initialised first
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from identity import IdentityShim, DOCUMENTS_MAP, PROJECTS_MAP, COMPARE_MAP

# Import each tool's FastAPI application. Module import is where each tool opens its
# SQLite (fresh DBs created on first run under server/data/).
from documents.app import app as documents_app
from projects.app import app as projects_app
from compare.app import app as compare_app
from ppt.app import app as ppt_app

# Super-Admin console: users + tool-enablement store (own sqlite, additive under /auth).
from auth import router as auth_router, store as auth_store

app = FastAPI(title="OATIGenie", description="Unified backend for the OATIGenie tool suite")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"],
                   allow_headers=["*"], expose_headers=["*"])

# Mount each tool behind its prefix, wrapped by the identity shim so X-OATI-User flows in.
app.mount("/documents", IdentityShim(documents_app, DOCUMENTS_MAP))
app.mount("/projects", IdentityShim(projects_app, PROJECTS_MAP))
app.mount("/compare", IdentityShim(compare_app, COMPARE_MAP))
app.mount("/ppt", ppt_app)  # stateless; no per-user identity

# Auth / Super-Admin console — plain router (identity is X-OATI-User, same header as tools).
app.include_router(auth_router, prefix="/auth", tags=["auth"])


@app.get("/health")
def health():
    """Aggregate health: each tool subsystem + the shared services it depends on."""
    from config import EMBED_URL, EMBED_MODE, EMBED_MODEL, LLM_BASE, LLM_MODEL, EMBED_DIM

    subsystems: dict = {}

    # documents
    try:
        from documents.app import store as dm_store
        subsystems["documents"] = {"ok": True, "documents": len(dm_store.list_documents())}
    except Exception as e:  # noqa: BLE001
        subsystems["documents"] = {"ok": False, "error": str(e)}

    # projects
    try:
        from projects.app import store as pm_store
        subsystems["projects"] = {"ok": True, "projects": len(pm_store.list_projects())}
    except Exception as e:  # noqa: BLE001
        subsystems["projects"] = {"ok": False, "error": str(e)}

    # compare (stateless)
    try:
        from compare.app import SUPPORTED as fc_supported
        subsystems["compare"] = {"ok": True, "supported": fc_supported}
    except Exception as e:  # noqa: BLE001
        subsystems["compare"] = {"ok": True, "note": "stateless", "detail": str(e)}

    # ppt (embeddings + export sidecar)
    subsystems["ppt"] = {"ok": True, "endpoints": ["/ppt/v1/embeddings", "/ppt/extract-text",
                                                   "/ppt/export", "/ppt/import-pptx"]}

    # auth (users + tool-enablement)
    try:
        subsystems["auth"] = {
            "ok": True,
            "users": len(auth_store.list_users()),
            "tools_config": auth_store.get_tools(),
        }
    except Exception as e:  # noqa: BLE001
        subsystems["auth"] = {"ok": False, "error": str(e)}

    ok = all(s.get("ok") for s in subsystems.values())
    return {
        "ok": ok,
        "service": "oatigenie",
        "auth": True,
        "tools": subsystems,
        "shared_services": {
            "embeddings": {"mode": EMBED_MODE, "model": EMBED_MODEL, "dim": EMBED_DIM,
                           "url": EMBED_URL if EMBED_MODE == "http" else None},
            "chat_model": {"base": LLM_BASE, "model": LLM_MODEL},
        },
        "identity_header": "X-OATI-User",
    }
