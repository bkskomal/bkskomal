# OATIGenie unified backend (`server/`)

Phase 1 of consolidating the AI tools suite into ONE OATIGenie project. A single FastAPI
app serves every tool over **one shared RAG core** and **one identity**. This is additive
— the standalone apps (Document Management :8920, Project Management :8930, Files
Comparison, the pyexport sidecar :8910) are untouched and still run independently.

## Run

```bash
cd server
C:\Users\bkkom\.venv\Scripts\uvicorn.exe app:app --port 8900
```

Uses the existing venv at `C:\Users\bkkom\.venv` (fastapi/uvicorn/httpx/numpy + the
office/embeddings libs DM & PM already rely on). No `pip install` needed.

Health check: `GET http://localhost:8900/health` returns an aggregate of every tool
subsystem plus the shared embedding/chat services.

## Route prefixes

Each tool is mounted behind a prefix; **its original endpoint paths are preserved under
that prefix** (same convention for all tools).

| Prefix        | Tool                | Notes |
|---------------|---------------------|-------|
| `/documents/*`| Document Management | e.g. `GET /documents/documents`, `POST /documents/ask`, `POST /documents/search`, `GET /documents/file/{id}`, `GET /documents/preview/{id}`, `/documents/connectors/*`, `/documents/sync/*` |
| `/projects/*` | Project Management  | PM routes already start with `/projects`, so they nest: `GET /projects/projects`, `GET /projects/projects/{pid}`, `POST /projects/projects/{pid}/notes`, `.../tasks`, `.../ask`, `.../digest`, `.../act`, `.../plan`, `/projects/connectors` |
| `/compare/*`  | Files Comparison    | `GET /compare/health`, `POST /compare/compare`, `POST /compare/compare-xlsx`, `POST /compare/compare-doc` |
| `/ppt/*`      | PPT export + embeddings sidecar | `POST /ppt/v1/embeddings`, `POST /ppt/extract-text`, `POST /ppt/export` (HD .pptx), `POST /ppt/import-pptx`, `POST /ppt/import-docx`, `POST /ppt/export-code`, `GET /ppt/health` |
| `/health`     | Aggregate           | Per-tool status + shared services |

> Why the doubled segment for projects/documents: every tool keeps its own internal
> paths (Document Management's browse route is `GET /documents`; Project Management's list
> route is `GET /projects`). Mounting under the tool prefix yields `/documents/documents`
> and `/projects/projects` respectively. This is the faithful "same paths, now prefixed"
> mapping and is identical in spirit across all four tools.

## Identity — one header

Every router derives its principals/uid from a single header:

```
X-OATI-User:   <username or email>     e.g. demo@oati.com
X-OATI-Groups: <comma-separated>       (optional; Document Management ACLs)
```

An ASGI shim (`identity.py`) maps `X-OATI-User`/`X-OATI-Groups` onto each tool's native
header before the request reaches it:

- Documents: `X-OATI-User` → `X-DM-User`, `X-OATI-Groups` → `X-DM-Groups`
- Projects:  `X-OATI-User` → `X-PM-User`
- Compare:   `X-OATI-User` → `X-FC-User`

The **legacy per-tool headers still work** as a fallback when `X-OATI-User` is absent;
`X-OATI-User` takes precedence when both are present. Access control derives entirely from
this identity: Document Management maps it to `user:<id>` + `group:*` + `public`
principals for ACL filtering; Project Management uses it as the RBAC user id
(read < write < admin; a project's creator is auto-granted admin).

## Shared RAG core (`server/rag/`) — one copy, used by both

`/documents` and `/projects` import the **same** modules (verified: their `search` is the
identical function object; their ingest uses the identical `extract`):

- `rag/extract.py` — anchor-preserving extraction → `[Chunk]` with precise Locators
  (pdf pages+bbox, pptx slides, docx/md/html sections, txt lines, eml, xlsx/csv rows,
  and project `note`s). One superset extractor.
- `rag/models.py` — `Locator` / `Chunk` / `Document` contracts (union of both tools'
  fields), `est_tokens`, `CHUNK_TOKENS`, `version_family`.
- `rag/embed.py` — 768-dim BGE (`BAAI/bge-base-en-v1.5`). In-process via fastembed by
  default (`EMBED_MODE=local`); HTTP mode available for an external embedder.
- `rag/retrieve.py` — hybrid dense (BGE cosine) + sparse (FTS5 bm25) fused with RRF,
  optional LLM rerank. One `search()` supports BOTH ACL/principal scoping (documents)
  and project scoping (projects).
- `rag/rerank.py` — RankGPT-style LLM reranker.
- `rag/llm.py` — GPT-OSS-120B chat client (`chat` + streaming `chat_stream`).

Each tool keeps its own `store.py` (documents vs projects tables) and its own `ingest.py`
/ `qa.py` glue, but the retrieval/embedding/extraction/model logic is not duplicated.

## Data

One process, one data dir: `server/data/` (created on first run; gitignored — never
copied between machines).

- `data/documents.sqlite` (+ `documents_files/` stored originals + preview PDFs)
- `data/projects.sqlite`  (+ `projects_files/`)

Schema init is idempotent (fresh DBs created on first run; existing DBs auto-migrate).

## Config (`server/config.py`) — env with localhost defaults

| Var | Default | Purpose |
|-----|---------|---------|
| `OATI_DATA_DIR` | `server/data` | one data dir |
| `OATI_EMBED_MODE` | `local` | `local` (in-process fastembed) or `http` |
| `OATI_EMBED_MODEL` | `BAAI/bge-base-en-v1.5` | 768-dim BGE |
| `OATI_EMBED_URL` | `http://localhost:8910/v1/embeddings` | used only when `EMBED_MODE=http` |
| `OATI_EMBED_DIM` | `768` | vector dim |
| `OATI_LLM_BASE` | `https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1` | chat endpoint |
| `OATI_LLM_MODEL` | `openai/gpt-oss-120b` | chat model |
| `OATI_LLM_KEY` | `none` | bearer token |
| `OATI_LLM_TLS_INSECURE` | `true` | trust the dev self-signed cert |
| `DATABASE_URL` | (unset) | reserved for a future pgvector store backend |

Legacy per-tool vars (`DM_*`, `PM_*`, `FC_*`, `EMBED_URL`, `OPENAI_*`, `AI_MODEL`) are
honored as fallbacks so nothing that ran before breaks.

## What needs credentials / VPN to fully function

- **Chat model** (`/documents/ask`, `/documents/ask/stream`, `/projects/.../ask`,
  `/digest`, `/act`, `/plan`, note extraction, LLM rerank, email-to-task AI path):
  requires reachability to the GPT-OSS-120B endpoint (OATI dev network / VPN). Retrieval,
  ingest, embeddings, browse, tasks/notes/RBAC, ICS, and comparison all work offline.
- **Embeddings**: work offline in-process (fastembed). No VPN.
- **Connectors**: GitHub needs a token or authenticated `gh` CLI; Google Drive / Slack
  need their credentials; local_folder / mbox / url / calendar are offline.
- **Preview PDFs** for docx/pptx need LibreOffice (`soffice`) installed; pdf/txt/html
  preview and all retrieval work without it.
