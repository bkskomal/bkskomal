"""Unified configuration for the OATIGenie backend.

ONE process, ONE data dir, ONE set of shared-service endpoints. Every tool's SQLite
lives under server/data/. Shared AI infrastructure (embeddings + chat) is pointed at
by env; the OATI_* vars are the canonical names, with the legacy per-tool vars
(DM_*/PM_*/FC_*) honored as fallbacks so nothing that ran before breaks. Sensible
localhost defaults match the current standalone apps.
"""
from __future__ import annotations

import os

_HERE = os.path.dirname(os.path.abspath(__file__))


def _env(*names: str, default: str = "") -> str:
    for n in names:
        v = os.environ.get(n)
        if v is not None and v != "":
            return v
    return default


# ------------------------------------------------------------------ data dir (one place)
DATA_DIR = _env("OATI_DATA_DIR", default=os.path.join(_HERE, "data"))

DOCUMENTS_DB = _env("OATI_DOCUMENTS_DB", "DM_DB_PATH", default=os.path.join(DATA_DIR, "documents.sqlite"))
DOCUMENTS_FILES = _env("OATI_DOCUMENTS_FILES", "DM_FILES_DIR", default=os.path.join(DATA_DIR, "documents_files"))

PROJECTS_DB = _env("OATI_PROJECTS_DB", "PM_DB_PATH", default=os.path.join(DATA_DIR, "projects.sqlite"))
PROJECTS_FILES = _env("OATI_PROJECTS_FILES", "PM_FILES_DIR", default=os.path.join(DATA_DIR, "projects_files"))

# Auth / users / tool-enablement store — its OWN sqlite, never reused by the tool DBs.
AUTH_DB = _env("OATI_AUTH_DB", default=os.path.join(DATA_DIR, "auth.sqlite"))

# ------------------------------------------------------------------ shared embeddings
# 768-dim BGE (BAAI/bge-base-en-v1.5). Two modes:
#   EMBED_MODE=local (default): embed IN-PROCESS via fastembed — no HTTP round-trip, so
#     the unified app is self-contained and async ingest endpoints never deadlock on a
#     self-call. Identical vectors to the /ppt sidecar (same model).
#   EMBED_MODE=http: POST to an external OpenAI-compatible /embeddings at EMBED_URL
#     (e.g. a dedicated BGE service) — set this to fully isolate the embedder.
EMBED_MODE = _env("OATI_EMBED_MODE", default="local").lower()
EMBED_MODEL = _env("OATI_EMBED_MODEL", default="BAAI/bge-base-en-v1.5")
EMBED_URL = _env("OATI_EMBED_URL", "DM_EMBED_URL", "PM_EMBED_URL", "EMBED_URL",
                 default="http://localhost:8910/v1/embeddings")
EMBED_DIM = int(_env("OATI_EMBED_DIM", "DM_EMBED_DIM", "PM_EMBED_DIM", "EMBED_DIM", default="768"))

# ------------------------------------------------------------------ shared chat model
LLM_BASE = _env("OATI_LLM_BASE", "DM_LLM_BASE", "PM_LLM_BASE", "OPENAI_BASE_URL",
                default="https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1")
LLM_MODEL = _env("OATI_LLM_MODEL", "DM_LLM_MODEL", "PM_LLM_MODEL", "AI_MODEL",
                 default="openai/gpt-oss-120b")
LLM_KEY = _env("OATI_LLM_KEY", "DM_LLM_KEY", "PM_LLM_KEY", "OPENAI_API_KEY", default="none")
LLM_TLS_INSECURE = _env("OATI_LLM_TLS_INSECURE", "DM_LLM_TLS_INSECURE", "PM_LLM_TLS_INSECURE",
                        "AI_TLS_INSECURE", default="true").lower() == "true"

# Optional Postgres/pgvector DSN (reserved for a future store backend; unused by SQLite path)
DATABASE_URL = _env("DATABASE_URL", default="")

# ------------------------------------------------------------------ ensure dirs exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(DOCUMENTS_FILES, exist_ok=True)
os.makedirs(PROJECTS_FILES, exist_ok=True)
