# RUNBOOK — set up & run on a new machine

This backup **excludes `node_modules/` and `.next/`** (regenerable). Reinstall + rebuild below.

## Prerequisites
- **Node.js 20+** (project used Node 22) and npm
- **Python 3.10+** (for the `pyexport` microservice; uses python-pptx)
- **Docker** (for Postgres + pgvector) — OPTIONAL; app degrades gracefully without it
- Access to a **GPT-OSS-120B** OpenAI-compatible endpoint (or any OpenAI-compatible chat model)

## 1) Install JS deps + run the web app
```bash
cd PPTCreation            # (this backup)  — original path was E:\AI\Self\PPTMaker
npm install               # restores node_modules
npm run dev               # Next.js dev server on http://localhost:3000
```
Build for prod: `npm run build && npm start`. Typecheck: `npx tsc --noEmit`
(if npm cache disk is full, run the installed compiler directly: `node node_modules/typescript/bin/tsc --noEmit`).

## 2) Configure `.env.local` (repo root — create it; not in the backup if git-ignored)
```
OPENAI_BASE_URL=https://your-gpt-oss-endpoint/v1
OPENAI_API_KEY=your-key-or-"local"
AI_MODEL=openai/gpt-oss-120b
AI_TLS_INSECURE=true          # DEV ONLY: trusts self-signed certs. Prod: use NODE_EXTRA_CA_CERTS
NEXT_PUBLIC_PYEXPORT_URL=http://localhost:8910
DATABASE_URL=postgres://user:pass@localhost:55432/oatigenie   # optional (pgvector)
EMBED_DIM=768
```
Most infra config (embeddings endpoint, imagery provider keys, org brand/governance) is set in the
app's **Settings** UI (Super Admin), sent per-request — not in `.env`.

## 3) Run the pyexport microservice (HD export, import, compare, code-export, embeddings)
```bash
cd pyexport
pip install -r requirements.txt
python -m uvicorn app:app --port 8910
# health check: curl http://localhost:8910/health
```
**IMPORTANT: uvicorn does NOT auto-reload — restart this process after editing any `pyexport/*.py`.**

## 4) (Optional) Postgres + pgvector for cloud decks / self-learning / evals / governance
```bash
docker run -d --name oatigenie-pgvector -p 55432:5432 \
  -e POSTGRES_PASSWORD=pass -e POSTGRES_USER=user -e POSTGRES_DB=oatigenie \
  pgvector/pgvector:pg16
```
Set `DATABASE_URL` to match. Tables are auto-created on first use (see `src/lib/db.ts`).
Without the DB: cloud save/share/versions, org governance, RAG, and eval persistence are disabled
but the app still fully works locally (decks persist to the browser's IndexedDB).

## 5) Demo login
Seeded account (browser-local demo auth): **demo@oati.com / oatigenie** (Super Admin).
Production must replace `src/lib/auth.ts` with real backend auth.

## Quick smoke tests
- Web: `GET http://localhost:3000/` → 200; `/editor`, `/templates` → 200
- pyexport: `GET http://localhost:8910/health` → `{"service":"oatigenie-services"}`
- Generate a deck from the chat home, or import a `.pptx` from the templates gallery.

## Key scripts / commands used during development
- Typecheck: `node node_modules/typescript/bin/tsc --noEmit`
- Evals (LLM-as-judge): `node scripts/run-evals.mjs`
- Ad-hoc TS module testing: `npx tsx <file.mjs>` (tsx handles the extensionless TS imports)
