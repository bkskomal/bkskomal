# PPTMaker / OATIGenie — Project Context (for Claude on another machine)

_Generated 2026-07-02. Read this first to understand the project, then RUNBOOK.md to run it,
then SESSION_MEMORY.md for the full build history._

## What this is
An **AI-native, multi-skill assistant platform** whose flagship skill builds **fully-editable
PowerPoint decks** from a chat prompt or a pasted outline, powered by a self-hosted
**GPT-OSS-120B** model (OpenAI-compatible endpoint). Working name **OATIGenie** (rename TBD;
"OATI Tools" was under consideration). Second shipped skill: **Compare Files** (world-class
Excel/CSV/Word/PDF diff). Governance, cloud, evals and enterprise features are built out.

Ambition: "the world's best AI PPT creation tool." Roadmap + status live in `ROADMAP.md` (repo root).

## Guiding principles (do not violate)
1. **Editable, native output** — never flatten slides to images; export real `.pptx`
   shapes/charts/tables. This is the core moat.
2. **Fidelity** — honor a user's pasted outline 1:1; only compose freely when asked.
3. **Agentic** — every feature must be operable from chat (capability manifest), not just UI.
4. **Self-hosted / data-sovereign** — runs on the org's own GPT-OSS-120B; nothing leaves the tenant.
5. **Design-guaranteed** — the AI emits SEMANTIC content (AISlide); a deterministic layout
   engine turns it into positioned elements, so output is always on-brand.
6. Product decision: templates are **data-driven** (Deck JSON), NOT AI-generated python. (A
   python-pptx *code export* exists as an output option, but templates themselves are data.)

## Tech stack
- **Next.js 16** (App Router, Turbopack) + TypeScript + **Tailwind v4** (CSS-variable theming)
- **Zustand** (persisted stores; deck persistence uses **IndexedDB** via a custom adapter)
- **zundo** (undo/redo temporal middleware on the editor deck)
- `pptxgenjs` (client `.pptx` export), `xlsx`/SheetJS (compare), `react-markdown`+`remark-gfm`
- **pyexport** microservice: Python **FastAPI** + **python-pptx** (HD export, import, embeddings,
  file compare, chart/table rendering, python-code export) — runs on port **8910**
- **Postgres + pgvector** (Docker) for self-learning (RAG exemplars), cloud decks, evals, org config
- Model: **GPT-OSS-120B** via OpenAI-compatible API (OATI Genie endpoint, self-signed cert in dev)

## Architecture (the mental model)
```
User prompt / outline
      │
      ▼
 AI (GPT-OSS-120B) ── emits ──► AISlide[] (SEMANTIC: layout id + content fields)   [schema.ts]
      │                                   │
      │  (outline path: parseOutlineToDeck honors it 1:1, deterministic)           [outline.ts]
      ▼                                   ▼
 deckFromAI ─────────────────────► buildSlide(ai, style)                           [deck.ts, layouts.ts]
                                          │  builders per layout → positioned SlideElement[]
                                          │  + autofitSlide (text never overflows)  [autofit.ts]
                                          │  + repairSlide  (clamp/contrast/overlap) [lint.ts]
                                          ▼
                                    Deck { theme, style, brand, slides[] }          [types.ts]
                                          │
        ┌─────────────────────────────────┼───────────────────────────────────────┐
        ▼                                 ▼                                         ▼
  DOM canvas render                 client .pptx export                     HD .pptx / import / code
  [SlideView.tsx]                   [export-pptx.ts]                        [pyexport/renderer.py,
  + brandChrome() header/footer     + brandChrome()                         importer.py, codegen.py]
  [brand.ts]                                                                (mirrors brand.ts/layouts)
```
- **Deck** is the single source of truth. Elements are `text | image | shape | icon | chart`
  with x/y/w/h in a **1280×720** canvas (`CANVAS` in utils.ts; 96px/inch for export).
- **Colors are tokens** (`token:primary`, `token:surface`, `token:onPrimary`, …) resolved at
  render/export via `resolveColor` (color.ts) against the deck's `theme` + `brand` overrides.
  This is what makes chrome/themes adapt (dark ↔ light) without changing content.
- **brandChrome()** (brand.ts, mirrored in pyexport/renderer.py) computes header/footer/logo at
  render time from the BrandKit — one change applies everywhere; header/footer PRESETS
  (rule/minimal/band/sidebar/gradientBar/**banner**; line/band/confidential/pageOnly). The
  **banner** preset = OATI house style (logo + title + subtitle + accent rule). Chrome is
  suppressed on full-bleed layouts (cover/section/closing); cover logo is 1.8× larger.

## Services & how they connect
- **Next dev server** :3000 — the app + all `/api/*` routes.
- **pyexport** FastAPI :8910 — endpoints: `/export` (HD pptx), `/export-code` (python-pptx script),
  `/import-pptx` (parse pptx → editable deck), `/v1/embeddings` (BGE), `/compare-xlsx`,
  `/build-diff-xlsx`, `/compare-doc`, `/compare-doc-docx`, `/health`. Client reaches it via
  `NEXT_PUBLIC_PYEXPORT_URL`. **NOTE: uvicorn does NOT auto-reload — restart it after editing
  `pyexport/*.py`.**
- **Postgres pgvector** (Docker) — `DATABASE_URL`. All DB features degrade gracefully via
  `withDb(fn, fallback)` (db.ts) when the DB is down. Tables auto-created on first use.

## Feature inventory (what's built, and where)
- **Generation**: topic→deck + robust parse/salvage (`ai.ts` parseDeck), outline 1:1 fidelity
  (`outline.ts`), source toast (outline vs AI). `max_tokens` scaled to slide count.
- **21 layouts** (`layouts.ts` builders) incl. `cardGrid` (feature cards), `heroGlance` cover
  style (hero + AT-A-GLANCE panel + pills). 13 style presets (`styles.ts`), 15 themes
  (`themes.ts`; **boardroom**=dark navy/red + **executive**=light = the OATI pair).
- **Charts**: first-class `ChartElement` (column/bar/line/area/pie/donut, multi-series) with SVG
  render (SlideView ChartView) + native export both pipelines; CSV/TSV→chart (`elements.ts`
  parseTable); chat `add_chart`; editor ChartMenu.
- **Imagery**: stock search (Picsum keyless default + Unsplash/Pexels) `/api/images/search`,
  AI generation `/api/images/generate` (OpenAI-compatible), editor ImagesMenu, chat
  `add_image`/`generate_image`, auto-imagery on generation (`imagery.ts`, provider-gated).
- **Shapes/diagrams library**: 25 inserts (`inserts.ts`) — shapes/components/diagrams; Toolbar
  Library popover; chat `add_resource`. 14 shape kinds (clip-paths + both exporters).
- **Brand chrome**: header/footer presets + logo lockups (brand.ts + resources.ts); one-shot
  `brandPreset:"oati"` (banner header + footer + navy/red theme, dynamic text).
- **Templates**: 60+ built-in (`templates.ts`) incl. "OATI Platform" curated (heroGlance +
  cardGrid + banner). **Custom templates** (`customTemplates.ts`): save any deck (incl. imported
  pptx) as a reusable template; MyTemplates gallery section (use/rename/delete); overwrite existing.
- **.pptx import**: `pyexport/importer.py` → editable deck; gallery "Import PowerPoint" button
  → AI-editable in editor; imported decks auto-repaired (lint).
- **Cloud & sharing**: decks→Postgres (`cloudDecks.ts`, `/api/decks*`), share links + public
  read-only viewer (`/share/[token]`), version history; editor Save/Share/History.
- **Self-learning + evals**: pgvector exemplar RAG (👍→retrieve→inject), preference pairs,
  **LLM-as-judge** eval harness (`ai.ts judgeAnswer`, `/api/evals/run`, admin pass-rate card,
  `scripts/run-evals.mjs`). "Save as eval case" per-message action.
- **Governance + SSO**: org config (`orgConfig.ts`, `/api/org`) — enforced brand + per-field
  LOCKS (colors/fonts/logo/footer) honored in editor, new decks inherit org brand, email-domain
  access rules, OIDC SSO config + gated sign-in, approved-assets picker; saved brand presets;
  Settings "Organization" tab (Super Admin).
- **Quality engine**: **autofit** (autofit.ts — text never overflows) + **lint/repair**
  (lint.ts — clamp off-canvas, fix contrast, un-overlap); one-click **Polish** button (Toolbar);
  chat `cleanup`.
- **Editor**: full DOM editor, 14 shapes, undo/redo, snapping, brand kit, present mode
  (`/present`), export menu (client .pptx / HD .pptx / PDF-print / python code / save-as-template).
- **Compare Files skill**: context-aware Excel/CSV diff (compare.ts — composite keys, numeric
  tolerance, renamed-tab detection, cross-format) + Word/PDF diff + merged report; `/compare`.
- **Multi-skill assistant home** (ChatGPT/Claude-like), login/roles (`auth.ts` demo, local),
  Settings (themes, models, embeddings, training data, organization), feedback like/dislike.

## Config
- `.env.local` (repo root, NOT committed): `OPENAI_BASE_URL`, `OPENAI_API_KEY`, `AI_MODEL`
  (GPT-OSS-120B), `AI_TLS_INSECURE=true` (DEV ONLY — trusts self-signed OATI cert; prod uses
  `NODE_EXTRA_CA_CERTS`), `DATABASE_URL` (pgvector), `NEXT_PUBLIC_PYEXPORT_URL=http://localhost:8910`,
  optional `EMBED_DIM=768`.
- **Admin-only runtime config** lives in Settings → Platform/Organization (sent per-request, not
  in .env): embeddings endpoint, imagery providers/keys, org brand/governance. (User explicitly
  wants infra config in the Settings UI, not .env.)

## Known issues / gotchas (READ THESE)
- **uvicorn no auto-reload** — restart pyexport after editing `pyexport/*.py`.
- **Images are inline base64 data-URLs** everywhere (deck/cloud/undo). Deck persistence uses
  **IndexedDB** (`idbStorage.ts`) because localStorage's ~5MB quota overflowed on image-heavy
  decks. A future win: a blob store keyed by id.
- **python HD export only embeds `data:` image URLs** — a public-path logo (e.g. the OATI
  template's `/oati-logo.png`) renders in the editor but won't export until re-added via
  "add OATI logo"/upload (which converts to data URL).
- **Demo auth** (`auth.ts`) is browser-local, lightly hashed — NOT production. SSO `/callback`
  exchange + server sessions are the production TODO.
- **PowerShell/py files must be ASCII-only** (PS 5.1 mis-decodes non-BOM UTF-8).
- This machine had **C: drive full (0GB)** during the last session — clear C: space or the dev
  server temp + browser IndexedDB (deck autosave) can fail.

## Where to look
- Roadmap + phase status: `ROADMAP.md` (repo root).
- Full chronological build history + every validated decision: `AppContext/SESSION_MEMORY.md`.
- One-line memory index: `AppContext/MEMORY_INDEX.md`.
- Run/setup instructions: `AppContext/RUNBOOK.md`.
