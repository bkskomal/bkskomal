# AppContext — read this to understand the project

This folder captures the full context of the PPTMaker / OATIGenie project and the Claude session
that built it, so an AI assistant on another machine can pick up exactly where we left off.

## Reading order
1. **PROJECT_CONTEXT.md** — what the app is, architecture, feature inventory, config, gotchas.
   Start here.
2. **RUNBOOK.md** — how to install, configure, and run on a new machine (Next app + pyexport
   microservice + optional Postgres/pgvector).
3. **SESSION_MEMORY.md** — the curated, chronological build history: every feature and every
   validated decision, with file pointers. (This is the assistant's project memory.)
4. **MEMORY_INDEX.md** — one-line index of memory topics (also references sibling projects).
5. **SESSION_TRANSCRIPT.jsonl** — the RAW, complete Claude Code conversation that built this
   (18.7 MB). Reference only if you need exact wording/decisions not captured above.

## Also in the repo root
- **ROADMAP.md** — phased plan + current status (Phase 0/1 done, Phase 2 mostly done).

## To resume work as the assistant on the new machine
- Re-create the project memory from `SESSION_MEMORY.md` (copy it into the assistant's memory dir),
  or just keep reading it from here.
- Follow RUNBOOK.md to get the app + services running.
- Continue from the ROADMAP: remaining is **P2.1 real-time collaboration** and polish items
  (#3 smarter layout auto-selection, #4 speaker notes by default).
