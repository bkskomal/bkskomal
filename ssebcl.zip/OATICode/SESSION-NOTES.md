# OATI Code Session Notes — 2026-06-04 → 2026-06-22

Comprehensive narrative of every arc of work in this session. Grouped by
theme rather than strict chronology because related decisions ended up
spread across multiple days.

---

## 1. Roadmap closure (2026-06-04)

Started the session reviewing the project_oati_roadmap.md memory. Found
it was 11 days stale and most "deferred" items had actually been
implemented. The user wanted to "continue with Phase 5 and complete all
the pending items." That set the agenda for the first day.

### Phase 5 — Plan-Mode V2 end-to-end (commit `e99796d`)

The roadmap claimed Phase 5 needed 500+ LOC. Investigation showed the
`/plan` slash command already ran on V2 (`planRequest` + `executePlan` +
`plan_proposed` events + `PlanEditor` side panel). The real gap was the
conductor's auto-planner still calling legacy `runPlanner()`.

**Migration:**
- New `planV2ToPromptSection` helper in `planner-v2.ts` (drops the
  legacy rationale tail format).
- `conductor.ts` now calls `planRequest` instead of `runPlanner`, emits
  the plan with `state: "executing"` so the editor renders read-only in
  auto-mode (vs. the slash-command flow where it's "draft" and user-
  approval-gated).
- `AgentEvent.plan` now carries `PlanV2` not legacy `Plan`.
- Webview's legacy `proposedPlan` signal + `PlanProposalBanner` retired
  — auto-mode now uses the same `currentPlan` + `PlanEditor` UI as
  /plan.
- Deleted: `planner.ts`, `planner.test.ts`, `plan-proposal.tsx`, legacy
  `Plan`/`PlanStep` types in `shared/agent.ts`, the `execute_plan`
  webview-to-host message + chat-panel handler.
- Net: -275 LOC across 15 files. Cuts > adds (per the roadmap rule).
- `usePlannerV2` flag the earlier roadmap suggested was unnecessary;
  migration was clean enough to do unconditionally.

### Phase 3.3 — Unified hunk-based diff (commit `e8c31cc`)

Previously the approval modal had an ad-hoc per-line set-membership
diff while the post-write `InlineDiffSession` ran a real LCS-based
hunk model. Two systems, two qualities.

**Unification:**
- Pulled the pure hunk logic into `@oati/shared/diff.ts`:
  `computeHunks`, `renderHunks`, `createInlineDiffSession`,
  `setHunkStatus`, `resolveAcceptedText`, `isFullyResolved`,
  `splitLines`, `joinLines`.
- `extension-host/inline-diff.ts` now imports from shared instead of
  defining its own copies.
- `webview-ui/approval-dialog.tsx` and `diff-modal.tsx` use the same
  `computeHunks` + `renderHunks` for grouped hunks with 2–3 lines of
  context, per-hunk header showing line offset + add/del counts.
- 15 new tests in `shared/tests/diff.test.ts`.
- 270 lines of CSS for `.oati-plan-editor` (PlanEditor had no styles
  before; was rendering as default block flow — discovered later in
  the session).

### js-yaml externalization (commit `c228e65`)

Phase 0.5's deferred ~86 KB bundle win.

- New `shared/yaml-mini.ts`: hand-rolled 200-line YAML parser
  supporting the union of what `skills.ts` (frontmatter) and
  `policy.ts` (`.oati/policy.yaml`) need: top-level + indented
  mappings, block + flow sequences, scalar types, inline comments,
  proper failure on unterminated quotes / unterminated `[`.
- Removed `js-yaml` and `@types/js-yaml` from `extension-host`'s
  dependencies.
- Measured: `dist/extension.js` shrank exactly **83,922 bytes** (≈84
  KB) — basically the full predicted savings.

### MCP HTTP/SSE transport UI (commit `5187ab7`)

The MCP HTTP transport was actually fully wired in `mcp-manager.ts`
already — the only gap was the Settings UI. Added a Transport selector
to `McpServerRow`; renders URL + Headers fields when "http" chosen.
`McpServerPreset` gained optional `transport`/`url`/`headers` so HTTP
presets are first-class.

### Slash command frontmatter + popover (commit `27c4f71`)

Custom slash commands at `.oati/commands/*.md` now parse YAML
frontmatter via the new mini-parser. Recognized keys: `description`,
`icon` (emoji), `category` (chip label), `aliases` (string[]).
Webview popover renders the icon column + category chip; suggestion
filter matches name AND declared aliases (`/r` → `/review`).

### Context-budget diagnostic fix (commit `96e6d78`)

The agent's context-budget breakdown emits as `type: "error"` (the
only available diagnostic channel). The webview's
`isInternalAgentDiagnosticMessage` filter listed every other internal
prefix but missed `[context-budget]`. So when the agent fired at >60%
context usage, the chip rendered as `⚠️ Agent error` AND the activity
indicator vanished (because the error path called `resetAgentStatus`).

Fix: special-case `[context-budget]` in the error handler — render as
a persistent `📊` chat chip, never gate the indicator. The agent
keeps running, the user keeps seeing it run.

**This was the last commit before the long uncommitted run.**

---

## 2. The empty-id tool_call run (the layered fix)

Recurring issue: `tool_call_id  is not found` errors with a double
space (i.e. empty id). Source: when synthesizing tool calls from
malformed model output, the agent was producing empty ids that didn't
match any tool_use on the wire. Took 4 layered fixes (committed in
late May / early June, all in scope as of session start):

1. **synth at ingestion** never produces empty ids — uses
   `${name || "unknown"}:${idx}` so id starts with a letter
2. **Pass-0 rename in `repairOrphanToolCalls`** always persists (was
   only persisting when there were orphans)
3. **wire-filter drops empty-name AND orphan tool_results** before
   sending to OpenAI-compatible providers
4. **Pass-2 strips loose empty-id tool_results** from any tool message

After day-1 work the rest of the session built on this stable base.

---

## 3. Opus 4.7 + Claude family fixes (uncommitted)

User hit `temperature is deprecated for this model` errors when using
Claude Opus 4.7 via Anthropic native.

**Fix:**
- `ModelQuirks.omitTemperature?: boolean` — new field. When true, the
  provider omits the `temperature` field from the wire body entirely
  (distinct from `requiresTemperature` which forces a value).
- New matcher row for `/claude[-_./]?(opus)[-_./]?4[-_./]?[78]/i` —
  placed BEFORE the generic Claude row (first-match wins). Sets
  `omitTemperature: true`. Will need to extend to Sonnet/Haiku 4.7+
  when Anthropic rolls the deprecation across the family.
- Both `providers/anthropic.ts` and `providers/openai-compatible.ts`
  honor the quirk — the latter so Opus 4.7 routed via OpenRouter /
  LiteLLM (which forwards to Anthropic) also strips the field.
- 2 pinning tests in `model-quirks.test.ts`.

---

## 4. Loop-guard orphan tool_result (uncommitted)

User hit `unexpected tool_use_id found in tool_result blocks:
loop_guard_*` errors with Claude Opus 4.7. The loop-guard was
synthesizing a tool_result with a fabricated `loop_guard_*` id that
had no matching tool_use. OpenAI tolerated this; Anthropic strictly
enforced the pairing.

**Two-part fix (source + defense-in-depth):**

1. `agent.ts` — loop-guard guidance is now pushed as a real
   user-role message AFTER the tool-results message commits, not as a
   synthetic tool_result. Provider-agnostic; the model reads it on
   the next prompt as a regular user turn.

2. `providers/anthropic.ts` — pre-scan collects every assistant
   tool_use id into a Set, drops any tool_result whose tool_use_id
   isn't in the set before building the wire body. Defense-in-depth
   for sessions loaded from disk that contain corruption.

---

## 5. Context-fill chip moved to the composer

User flagged the `148.4k/200.0k · 74%` chip was taking a row of
vertical space at the top of the chat. Moved it next to the mode
picker in the composer's action row.

- Extracted `ContextFillIndicator` to its own component file with
  pure props (no parent coupling).
- Added optional `contextFill` prop on `Input`.
- Removed the top-header mount + the local copy of the component in
  `app.tsx`.
- Initial placement was to the RIGHT of the mode picker; user wanted
  LEFT-of-picker for the visual order "current usage → mode that
  determines window". Swapped the render order.

---

## 6. VSIX packaging arc (the most important fix this session)

Two compounding bugs that caused multiple wasted reinstall cycles
before being caught.

### Bug 1: `webview-ui/dist` missing from the VSIX

The extension loaded from `extensionUri + "../webview-ui/dist"` —
works in the dev monorepo but doesn't exist when packaged into a
VSIX. The chat panel rendered completely blank on a fresh install.

**Fix:**
- `chat-panel.ts` new `resolveWebviewDistDir(extensionUri)` helper:
  probes `<extensionUri>/dist/webview` first (packaged), falls back
  to `<extensionUri>/../webview-ui/dist` (dev).
- New script `packages/extension-host/scripts/copy-webview-dist.mjs`
  copies the built webview into the extension's own dist folder
  before vsce package.
- Package script: `npm run package` now runs the copy step.

### Bug 2: Package script didn't rebuild webview first

Even with the copy step in place, the script went
`build → copy → vsce package`. But `npm run build` only ran
extension-host's esbuild — not webview-ui's. So when source
changes were made to webview-ui (which was the WHOLE rest of the
session), the copy step picked up a stale main.js. UI changes
silently didn't ship.

This was the silent killer behind: the context-fill chip not
moving, Budget Guardrails entry missing in Settings, and other UI
edits seeming to "not take effect."

**Fix:**
- Package script became
  `npm run build --workspace=@oati/webview-ui && npm run build && node scripts/copy-webview-dist.mjs && vsce package`.
- Forces the webview rebuild FIRST, guarantees fresh assets in the
  VSIX.

Both fixes shipped together in the uncommitted diff. Every "rebuild
the VSIX" instance for the rest of the session is built correctly.

---

## 7. Budget guardrails — Settings UI + master toggle

User hit `Daily org budget $51.15 has reached the cap of $50.00`.
There was no Settings UI for the budget — only `RootConfig.budget`
in JSON. Built:

- `SettingsUpdate` now carries optional `budget` field.
- `settings-store.ts` persists budget updates like the other config
  slices.
- `extension-host/budget.ts` treats `0` as the "unlimited" sentinel
  (since `POSITIVE_INFINITY` doesn't survive JSON round-trips).
- `chat-panel.ts` rebuilds the `Budget` instance on update so the
  new cap takes effect on the very next dispatch (no window reload
  needed). Field dropped its `readonly`.
- New "💰 Budget Guardrails" sidebar entry between SBOM and MCP
  Servers in Settings panel. 3 numeric inputs: per-session alert,
  per-session hard cap, per-day org cap.

Then the user asked for a master enable/disable toggle:

- `BudgetConfig.enabled?: boolean` — new field. When false, every
  cap is bypassed: `checkDispatch` always returns "ok",
  `recordUsage` still tallies for cost-display but no soft/hard
  signals fire.
- `DEFAULT_BUDGET.enabled = true` for backward compat.
- UI: checkbox at the top of the Budget panel; numeric inputs grey
  out when off.

2 new pinning tests for the toggle behavior.

---

## 8. PlanEditor side panel CSS — the missing 270 lines

User screenshot showed Plan steps rendering BELOW the composer
instead of as a side panel. Investigation: the `PlanEditor`
component used `class="oati-plan-editor"` but there was NO CSS
defined for it in `styles.css`. Fell back to default block flow.

**Fix:** Added ~270 lines of CSS — `.oati-plan-editor` (fixed
position right edge, full height, min(440px, 42vw) width), header
with goal + close, scrollable step list, sticky footer, per-step
status borders (running = amber halo, failed = red, done = faded).

---

## 9. ask_user clarifying questions surface in every mode

User wanted Claude-style clarifying questions where the user picks
from chip strips. The `ask_user` tool already existed and worked,
but `resolveAskUserPolicy` was hard-coded to return
`auto-pick-first` for Auto/Auto-Edit modes. Result: the model
believed it had asked the user, the host silently picked option 0,
the user never saw the chip strip.

**Fix:** Default is now `"always"` in every mode (including Auto).
Users who want true unattended autonomy can still set
`allowAskUser: "auto-pick-first"` or `"never"` explicitly on the
mode config.

System prompt addendum updated to match: "the chip strip is shown
in every mode" instead of "in auto modes the host auto-picks
options[0]."

5 existing tests in `ask-user-policy.test.ts` updated to pin the
new behavior.

---

## 10. The OATI internal gateway arc — the bulk of days 4-7

User wanted to add internal OATI vLLM gateways as providers. Three
gateways in scope, each on a different host.

### Provider preset: "OATI Compatible" (`oati-genie` id)

- New entry in `ProviderPresetId` + `PROVIDER_PRESETS`.
- `requiresApiKey: false` (gateways are network-gated, not
  key-gated).
- Curated model list pre-populates the Model dropdown.
- Renamed "OATI Genie (internal)" → "OATI Compatible" per user
  feedback.
- Each curated model includes its per-model Base URL in the note,
  because each model is served on a different host/path:

  - `openai/gpt-oss-120b` → `https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1`
  - `google/gemma-4-26B-A4B` → `http://vllm.dev.services.oati.com/gemma_4/v1`
  - `Qwen/Qwen3-Coder-30B-A3B-Instruct` → `http://vllm.dev.services.oati.com/qwen3_coder/v1`

### Model ID verification

Initial assumption was that the user-facing model id ("gpt-oss-120b",
"gemma-4", "qwen-3-coder") was what the gateway accepted. Wrong —
vLLM serves the verbatim HuggingFace path (`org/model-name`). I
hit each gateway's `/v1/models` endpoint to read the actual id and
updated the curated entries.

Model-quirks regex was loose enough to match both short and full
paths (`/gemma[-_./]?4/i` matches both `gemma-4` and
`google/gemma-4-26B-A4B`), so no regex changes needed — just the
curated ids in the preset.

### The chat_template trust saga (Gemma + Qwen)

Hit `As of transformers v4.44, default chat template is no longer
allowed, so you must provide a chat template if the tokenizer does
not define one.` HuggingFace transformers >= 4.44 removed the
implicit fallback chat template, so Gemma/Qwen on this vLLM
deployment have no template to use.

**Attempt 1: client-side chat_template (failed)**
- New `ModelQuirks.chatTemplate?: string` carrying a Jinja string.
- Provider includes `chat_template` in the request body.
- Also flattens any tool_calls / tool_role into inline text first
  (3-role templates can't handle them).

Worked structurally, but vLLM rejected with: `Chat template is
passed with request, but --trust-request-chat-template is not set.
Refused request with untrusted chat template.` Deliberate security
guard.

**Attempt 2: switch to /v1/completions (worked)**
- Removed `chatTemplate` field. Added `useCompletionsFallback:
  boolean` and `promptShape: "gemma" | "chatml"`.
- New `streamFromCompletions()` generator in
  `providers/openai-compatible.ts`:
  - URL switches to `/completions` (not `/chat/completions`)
  - Builds a raw prompt string client-side via prompt-builder
    function for the model's shape
  - Body: `{model, prompt, stream, stop, temperature, max_tokens}`
  - Parses text_completion SSE chunks (choices[0].text not delta)
  - Emits text_delta + message_end events
- `chat-templates.ts` rewritten with `buildGemmaPrompt`,
  `buildChatMLPrompt`, `buildPromptForShape` — TypeScript prompt
  builders. Gemma folds system into first user turn, Qwen uses
  standard ChatML.

Verified by curl: `/v1/completions` works on both gateways without
chat-template restrictions.

### The empty-response Gemma debugging arc

After the completions fallback shipped, Gemma was producing empty
responses in the UI. Added a verbose `[completions-fallback]`
diagnostic to the generator that reports bytes-received,
data-lines, parse-errors, yielded, stop, and first-payload snippet.
This made the parser more permissive (handles `\r\n\r\n`
separators, flushes trailing buffer, accepts any non-empty text)
and gave the user a visible chip to triage from.

Turned out the parser was fine — the empty response was actually
stale session context loading the model into a hallucinated "Ecom →
Ecom-India" rename loop. The loop guard tripped and stopped it,
correctly.

Bigger lesson: Gemma 4 is a chat model, not a tool-trained agent
model. It hallucinates and narrates "I'll use the X tool" without
emitting the inline-XML tags. Not an OATI bug; a model capability
gap.

### Gemma tuned for its strength lane

After we agreed Gemma is Q&A / reading / Ask-mode best:

- `maxTokens` 8192 → 2048 (bounds runaway loops)
- `maxIterations` 25 → 8 (iterate-without-converging cap)
- `needsTersenessReminder` false → true (anti-narration prompt)
- `canPlan` true → false (structured-output unreliable)
- `canRerank` true → false
- `parallelConcurrencyCap` 2 → 1
- `notes` set to "Best in Ask mode for Q&A..."
- Curated label became "gemma-4 (26B-A4B) · best in Ask mode"

### Qwen 3 Coder gateway sizing saga

Initial state: gateway capped at `max_model_len=16384`. OATI's
base prompt is ~17.5K tokens — won't even fit a "Hello" request.
Marked Qwen as ⚠ "gateway too small" in the curated list.

2026-06-20: ops raised the cap from 16K → 32K. Tight but viable.

- `model-quirks.ts` contextWindow: 262144 → 32768 (track gateway
  reality, not model spec)
- `maxTokens`: 16384 → 4096 (leave ~10K conversation headroom)
- Curated label: dropped the ⚠, note updated to reflect 32K
  envelope + `/compact` advice

### Gateway state probing tool

Built into Test Connection. Previously returned `ok=true` on any
HTTP 200, even when the gateway's `/v1/models` returned an empty
list (vLLM up, no model loaded). The user's first chat then 404'd
with `Model X not found` while the Settings checkmark was lying.

**Fix (uncommitted, in `provider-manager.ts`):** After 200 OK, parse
the body and validate. Returns:
- `200 OK but the gateway has NO models loaded` — when data:[]
- `200 OK but "X" is NOT in the served model list. Loaded models:
  ...` — when configured model id missing from list (surfaces the
  actually-loaded ids for copy-paste)
- `200 OK · "X" is loaded` — when configured model is present
- `200 OK (N models available)` — when no specific model
  configured

Falls back to old behavior for non-JSON responses (Ollama, custom
servers).

5 new tests in `provider-manager-test-connection.test.ts`.

### SGLang Kimi K2.6 gateway

User showed an internal SGLang server at
`http://genieappn7.dev.oati.local:31245`. FastAPI Swagger UI
listing native SGLang endpoints (`/v1/loads`, `/health_generate`,
`/generate`, `/get_model_info`, etc.).

Diagnosed: this is SGLang, which DOES expose OpenAI-compatible
endpoints (`/v1/chat/completions`, `/v1/models`) alongside its
native ones. User had set Base URL to `/docs` (the Swagger UI
page) instead of `/v1`. Plus: `.oati.local` is internal-only;
won't resolve on machines off the OATI network.

Recommendation: switch to `/v1` and document the network-
reachability constraint. No code changes needed.

---

## 11. Settings session pollution fix (uncommitted)

User noticed: opening Settings always created a new "Untitled
chat" row in the sidebar history.

Root cause: `oati.openSettings` minted a real session in
`SessionStore` to back the Settings tab's underlying ChatPanel.
The Set tracking which ones are settings was in-memory only:
1. Sidebar listed every session including settings ones → phantom
   rows
2. Underlying session was never deleted on close → accumulating
3. After VS Code restart, Set was empty → orphans looked like
   ordinary chats

**Fix:**
- `SessionsTreeProvider.bind()` accepts optional
  `getHiddenSessionIds: () => ReadonlySet<string>` callback.
  `broadcast()` filters those ids before sending to its webview.
- `extension.ts` passes `() => settingsSessions` to the bind.
- `onDispose` now deletes the underlying session from
  `SessionStore` for Settings tabs (`session.delete(id)`). Real
  chats untouched.

---

## 12. Decisions not pursued (worth recording)

### Anthropic Agent SDK with browser OAuth

User asked about implementing browser-OAuth via
`@anthropic-ai/claude-agent-sdk` to let users authenticate with a
Pro/Max subscription. After analysis: technically possible but
gray-area on Anthropic's ToS (subscription is for personal use
through Anthropic's products; third-party routing is undefined
territory). Could break user accounts. Recommended OpenRouter
OAuth as the safe alternative.

User chose: skip both, stick with API-key flow. No code change.

### Engineering a "lite" prompt mode for tiny-context gateways

When Qwen was 16K, considered adding a per-model prompt-stripping
mode to fit the smaller window. Decided against — would force
structural compromises (which tools visible, how much guidance)
across all models. Better to wait for the gateway operator to
raise the cap (which they did).

### Auto-cleanup of stale sessions on activation

Considered adding a one-time cleanup that deletes any zero-message
sessions older than X days. Decided against — could delete real
empty sessions a user is keeping as bookmarks. Manual delete via
trash icon is fine.

---

## 13. Real-time gateway probes (commands for re-verification)

These were run periodically to verify the OATI internal gateways.
Re-run to refresh `GATEWAY-STATUS.md`:

```bash
# Gemma 4
curl -s --max-time 10 "http://vllm.dev.services.oati.com/gemma_4/v1/models"

# Qwen 3 Coder
curl -s --max-time 10 "http://vllm.dev.services.oati.com/qwen3_coder/v1/models"

# gpt-oss-120b
curl -s --max-time 10 "https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1/models"
```

Each returns `{"object":"list","data":[{...}]}` when healthy or
`{"object":"list","data":[]}` when up-but-unloaded.

---

## 14. The "make it work" recurring tension

A theme across the session: user said "make X work" multiple times
when the actual blocker was server-side (gateway empty, ops
config, etc.). Resisted the temptation to engineer client-side
workarounds for what were really upstream issues. Pattern that
emerged:

- **Always verify the gateway state first** before writing code.
  Most "X is broken" turned out to be "gateway has no model
  loaded" or "gateway is capped too small."
- **When client-side workaround IS the right answer, prefer route-
  changes over template-injection.** vLLM blocks
  request-side chat templates by default for security. The
  `/v1/completions` endpoint sidesteps that whole machinery.
- **Surface honest diagnostics.** The Test Connection
  improvement, the `[completions-fallback]` chip, the
  `[context-budget]` chip — all let the user see what's
  happening so failure modes are debuggable.

---

## 15. Open follow-ups (not actioned this session)

- **Bench harness not run against K2.6.** The harness exists
  (`npm run bench:agent`, 14 curated tasks + SWE-bench Verified
  ingester). Get a measured pass-rate to validate the
  "best-in-the-world" thesis.
- **Slash command palette UI.** Frontmatter shipped; the
  Ctrl+P-style fuzzy palette didn't.
- **OpenRouter OAuth.** Decided against shipping yet; could be
  revisited when API-key paste UX becomes a real friction.
- **Slack the OATI ops team** about the Gemma gateway being
  unloaded on demand. Recurring failure mode.
- **Commit the day's work.** 1,700 lines uncommitted across 29
  files. User hasn't asked for the commit yet; backup is the
  recovery path until they do.
