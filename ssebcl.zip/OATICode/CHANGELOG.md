# OATI Code Session Changelog — 2026-06-04 → 2026-06-22

Chronological list of every change shipped this session.

---

## Committed (in git as of 2026-06-22)

The last 7 commits, in reverse chronological order. All on `main`,
authored by Claude Opus 4.7. Run `git log --oneline -7` in the repo
to verify.

| Commit | Date | Summary |
|---|---|---|
| `96e6d78` | 2026-06-04 | `fix(webview): context-budget diagnostic no longer hides the activity bar` |
| `27c4f71` | 2026-06-04 | `feat(slash): YAML frontmatter + icon/category/aliases in the popover` |
| `5187ab7` | 2026-06-04 | `feat(mcp): expose HTTP/SSE transport in the Settings UI` |
| `c228e65` | 2026-06-04 | `perf(bundle): replace js-yaml with a 200-line mini-parser — 84 KB saved` |
| `e8c31cc` | 2026-06-04 | `feat(diff): Phase 3.3 — unified hunk-based diff renderer` |
| `e99796d` | 2026-06-04 | `feat(plan): Phase 5 — migrate conductor + UI to PlanV2; retire legacy plan` |
| `d98d8b4` | 2026-06-03 | `feat(memory): init command + suggest tool — close the project-memory loop` |

---

## Uncommitted (in working tree as of 2026-06-22)

24 modified files + 5 new files. Net +1,698 / -115 lines.
Restore from `UNCOMMITTED-DIFF.patch` + `artifacts/new-files/`.

### Group A — Opus 4.7 / Claude family fixes
- `packages/shared/src/model-quirks.ts` — new `omitTemperature?: boolean`; matcher row for Opus 4.7/4.8
- `packages/providers/src/anthropic.ts` — drops temperature when `omitTemperature` set
- `packages/providers/src/openai-compatible.ts` — same (covers Opus 4.7 via OpenRouter)
- `packages/shared/tests/model-quirks.test.ts` — 2 pinning tests

### Group B — Loop-guard orphan fix
- `packages/agent-core/src/agent.ts` — loop-guard guidance now pushed as user-role message, not synthetic tool_result
- `packages/providers/src/anthropic.ts` — defense-in-depth pre-scan drops orphan tool_results before wire body
- `packages/agent-core/tests/tool-filter.test.ts` — touched (likely incidental during refactor)

### Group C — Context-fill chip moved to composer
- `packages/webview-ui/src/components/context-fill-indicator.tsx` (NEW) — extracted component
- `packages/webview-ui/src/components/input.tsx` — new `contextFill` prop, renders chip LEFT of mode picker
- `packages/webview-ui/src/app.tsx` — removed top-header mount + local copy of component

### Group D — VSIX packaging fix
- `packages/extension-host/package.json` — package script now rebuilds webview-ui first
- `packages/extension-host/src/chat-panel.ts` — `resolveWebviewDistDir()` helper for dev vs packaged paths
- `packages/extension-host/scripts/copy-webview-dist.mjs` (NEW) — copies webview/dist into extension/dist/webview before vsce package

### Group E — Budget guardrails UI
- `packages/shared/src/config.ts` — `BudgetConfig.enabled?: boolean` new field
- `packages/shared/src/messages.ts` — `SettingsUpdate.budget?` field
- `packages/extension-host/src/budget.ts` — local BudgetConfig kept in sync; `enabled` toggle; `0` = unlimited sentinel
- `packages/extension-host/src/chat-panel.ts` — rebuilds Budget on settings update
- `packages/extension-host/src/settings-store.ts` — persists budget updates
- `packages/webview-ui/src/components/settings-panel.tsx` — new "💰 Budget Guardrails" tab with enable toggle + 3 numeric fields
- `packages/extension-host/tests/budget.test.ts` — 4 new tests (toggle, 0=unlimited semantics)

### Group F — OATI Compatible provider preset
- `packages/shared/src/presets.ts` — new `oati-genie` preset (renamed display: "OATI Compatible"); curated entries for `openai/gpt-oss-120b`, `google/gemma-4-26B-A4B`, `Qwen/Qwen3-Coder-30B-A3B-Instruct`
- `packages/shared/src/config.ts` — `oati-genie` added to `ProviderPresetId`
- `packages/shared/src/model-quirks.ts` — quirks rows for gpt-oss (`pattern: /gpt[-_./]?oss.../i`), full HF path verification for Gemma 4 + Qwen 3 Coder

### Group G — vLLM /v1/completions fallback (Gemma + Qwen)
- `packages/shared/src/chat-templates.ts` (NEW) — `buildGemmaPrompt`, `buildChatMLPrompt`, `buildPromptForShape`
- `packages/shared/src/index.ts` — re-exports the prompt builders
- `packages/shared/src/model-quirks.ts` — `useCompletionsFallback?: boolean` + `promptShape?: "gemma" | "chatml"`; populated on Gemma 4 + Qwen 3 Coder rows
- `packages/providers/src/openai-compatible.ts` — new `streamFromCompletions()` generator; `flattenToolRolesForChatTemplate()` helper
- `packages/providers/tests/openai-compatible.test.ts` — 3 new tests (Gemma POSTs to /v1/completions, Qwen does ChatML, Kimi explicitly stays on /v1/chat/completions)

### Group H — Gemma 4 tuned for Ask-mode lane
- `packages/shared/src/model-quirks.ts` — Gemma 4 row: maxTokens 8192→2048, maxIterations 25→8, needsTersenessReminder true, canPlan/canRerank false, parallelConcurrencyCap 1, notes field

### Group I — Qwen 3 Coder sized to gateway reality
- `packages/shared/src/model-quirks.ts` — Qwen contextWindow 262144→32768 (tracks ops's 32K cap), maxTokens 16384→4096
- `packages/shared/src/presets.ts` — Qwen curated entry: dropped ⚠ warning, note updated

### Group J — Test Connection honesty
- `packages/extension-host/src/provider-manager.ts` — parses `/v1/models` response body, validates configured model is in the served list; new helper `extractServedModelIds()`
- `packages/extension-host/tests/provider-manager-test-connection.test.ts` (NEW) — 5 tests pinning the new behavior

### Group K — Settings session pollution fix
- `packages/extension-host/src/sessions-tree.ts` — `bind()` accepts `getHiddenSessionIds`; `broadcast()` filters
- `packages/extension-host/src/extension.ts` — passes `() => settingsSessions`; `onDispose` now deletes session for Settings tabs

### Group L — ask_user surfaces in every mode
- `packages/extension-host/src/chat-panel.ts` — `resolveAskUserPolicy` defaults to `"always"` (was `"auto-pick-first"` for Auto/Auto-Edit)
- `packages/extension-host/tests/ask-user-policy.test.ts` — 5 tests updated

### Group M — PlanEditor side-panel CSS
- `packages/webview-ui/src/styles.css` — 270 new lines for `.oati-plan-editor*` rules

### Untracked (NEW files)
- `packages/extension-host/scripts/copy-webview-dist.mjs`
- `packages/extension-host/src/peer-host-import.ts` (cross-IDE session import, work-in-progress, ignored in current builds)
- `packages/extension-host/tests/provider-manager-test-connection.test.ts`
- `packages/shared/src/chat-templates.ts`
- `packages/webview-ui/src/components/context-fill-indicator.tsx`

---

## Test count progression

| Date | Tests | Delta |
|---|---|---|
| 2026-06-04 session start | 1,746 | baseline |
| After Phase 5 + 3.3 + js-yaml | 1,779 | +33 |
| After 06-04 evening commits | 1,789 | +10 |
| After Opus 4.7 fix | 1,791 | +2 |
| After loop-guard fix | 1,793 | +2 (then deduped to 1,791) |
| After Phase 3.3 expansion | 1,792 | +1 |
| After context-fill chip move | 1,792 | unchanged (UI tests) |
| After provider-manager Test Connection | 1,806 | +5 (provider-manager) +others |
| **2026-06-22 final** | **1,806** | **+60 over baseline** |

All 1,806 tests + 2 skipped passing as of 2026-06-22 07:33 UTC.

---

## VSIX builds (chronological)

Each build was distributed; the latest one is what's in `artifacts/`.

| Build time | SHA-256 (head) | Notable contents |
|---|---|---|
| 2026-06-05 20:17 | `e35319...` | First post-fix VSIX (webview assets fix) |
| 2026-06-05 22:24 | `4ba471...` | Opus 4.7 + ask_user always-on + Settings session fix |
| 2026-06-06 16:34 | `d7154f...` | OATI Compatible preset + Qwen 3 in curated list |
| 2026-06-16 17:12 | `4ee38a...` | Completions fallback (1st attempt — chat_template trust) |
| 2026-06-16 18:12 | `3082a2...` | Completions fallback (2nd attempt — `/v1/completions`) |
| 2026-06-16 19:41 | `9996b0...` | Gemma tuned for Ask mode |
| 2026-06-17 11:45 | `34395e...` | Test Connection validates model is loaded |
| 2026-06-20 00:25 | **`cf6f5bb486064133653ded40a4e7e6e5a18556413a43d3d7b92b0e2df9a98e40`** | **CURRENT** — Qwen sized to 32K |
