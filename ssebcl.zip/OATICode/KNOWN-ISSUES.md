# OATI Code — Known Issues + Workarounds (as of 2026-06-22)

What's broken / fragile / requires human action to fix, and what
to do about each.

---

## OATI gateway issues (server-side, can't fix in code)

### Gemma 4 gateway intermittently unloads

**Symptom:** Chat returns `Model 'google/gemma-4-26B-A4B' not found`.

**Root cause:** vLLM process is up, but the model has been unloaded
from memory. `/v1/models` returns `{"object":"list","data":[]}`.

**Verify:**
```bash
curl -s "http://vllm.dev.services.oati.com/gemma_4/v1/models"
```

**Workaround:** Slack the ops team running
`vllm.dev.services.oati.com`. Ask them to reload `google/gemma-4-26B-A4B`.
While you wait, use gpt-oss-120b.

**Why we can't fix this client-side:** No model loaded = no
inference possible. Every client hits the same wall.

### Qwen 3 Coder gateway is capped at 32K (model can do 256K)

**Symptom:** Long sessions eventually hit
`This model's maximum context length is 32768 tokens` errors.

**Root cause:** Ops set `--max-model-len 32768` on the vLLM
deployment. Qwen3-Coder-30B-A3B-Instruct natively supports 256K but
this deployment is sized smaller.

**Workaround:**
- Run `/compact` mid-session when the chat gets long
- For tasks that need large context, switch to gpt-oss-120b (128K) or
  external Kimi K2.6 (256K) instead
- Slack ops asking for `--max-model-len 65536` or higher

**OATI's handling:** `ModelQuirks.contextWindow` is set to 32768
(tracks gateway reality, not model spec). Auto-compact fires at 60%
(~20K) to stay safely under the 32K cap. If ops raises the cap, bump
the quirks value to match.

### Kimi K2.6 SGLang gateway — Base URL unverified

**Symptom:** Setting Base URL to
`http://genieappn7.dev.oati.local:31245/docs` → 404 on Test Connection.

**Root cause:** `/docs` is the FastAPI Swagger UI page (for humans),
not the API root. SGLang's OpenAI-compatible endpoints should be at
`/v1/...` but this was never verified from outside the OATI network.

**Workaround:** Set Base URL to
`http://genieappn7.dev.oati.local:31245/v1` and click Test Connection.
The new Test Connection (since 2026-06-17) will tell you definitively
whether `/v1/models` exists. If not, ops needs to enable SGLang's
OpenAI-compat surface.

**Network caveat:** `.oati.local` won't resolve on machines off the
OATI network at all.

---

## Model behavior issues (training distribution, not OATI bug)

### Gemma 4 narrates tool calls without emitting them

**Symptom:** Gemma says "I'll use the `write_file` tool to ..." but
never actually emits the inline-XML tags. Then it loops, repeating
similar announcements until OATI's loop guard trips.

**Root cause:** Gemma 4 isn't trained on tool-calling conventions
the way Kimi K2.6, gpt-oss, and Claude are. It's a chat/general-
purpose model, not an agentic model.

**Workaround:**
- Use Gemma in **Ask mode** only — Ask mode has a smaller system
  prompt and disables write tools. Gemma can still read files and
  do Q&A reliably.
- For agentic / multi-file work, use gpt-oss-120b or Kimi K2.6.
- The Gemma 4 quirks row reflects this: `canPlan: false`,
  `canRerank: false`, `maxIterations: 8` (bounds loops),
  `needsTersenessReminder: true` (anti-narration prompt).

### Stale session context bleeding into new conversations

**Symptom:** Send "Hello" and get back a response talking about an
old project (e.g., the "Ecom → Ecom-India" loop we hit).

**Root cause:** Old session history is loading along with the new
message. Either an old session was reopened, or context bleed from
a prior turn that wasn't fully compacted.

**Workaround:** Use **+ New Session** (the `+` button in the
sidebar) before starting unrelated work. Don't reuse a session
across topics if it's been long.

---

## Distribution / Network constraints

### `.oati.local` doesn't resolve outside the OATI network

**Symptom:** Colleague's home laptop can't reach the Gemma / Qwen /
Kimi gateways.

**Root cause:** `.oati.local` is internal DNS. Outside the OATI
office or VPN, it doesn't exist.

**Workaround:**
- For off-network users, point them only at gpt-oss-120b
  (`llm.dev.genie.oati.com` — public-fronted) or external API
  providers (Anthropic, OpenRouter)
- If they need internal model access, get them onto the OATI VPN

### The "Claude HTTP 404..." misleading prefix

**Symptom:** Error messages from any OATI gateway are prefixed
"Claude HTTP ..." even though they're not Claude.

**Root cause:** The user named their provider's Display Name field
"Claude" while configuring it. OATI prefixes error messages with the
provider's display name.

**Workaround:** In Settings → API Configuration → select the
misnamed provider → change Display Name to something accurate like
`OATI Gemma` or `OATI Qwen`. Cosmetic but stops the confusion.

---

## Code state issues (in the repo, not the runtime)

### 1,698 lines uncommitted on `main` as of 2026-06-22

**Symptom:** `git status` in `E:\AI\Self\OATICodingAssistantReal`
shows 24 modified + 5 new files. Last commit is `96e6d78`
(2026-06-04).

**Why:** The user hasn't asked for a commit yet. All work from this
session is in the working tree.

**Workaround:**
- The latest VSIX build (`cf6f5bb4...`) includes all this work
- This backup folder includes `UNCOMMITTED-DIFF.patch` to restore
  the source state
- When you're ready: a single `git add -A && git commit -m "..."`
  would land everything. Recommend splitting by theme using the
  groups in `CHANGELOG.md` if you want clean history.

### Tool-call training varies wildly across "open-weight" models

**Pattern observation, not a bug:** Of the OATI internal models:
- gpt-oss-120b — tool-trained (OpenAI's function-calling format) ✅
- Gemma 4 — not tool-trained, chat-mode only ⚠️
- Qwen 3 Coder — code-trained AND inline-XML-trained (worked in
  bench tests) ✅
- Kimi K2.6 — heavily tool-trained, native markers ✅

When evaluating a new model for OATI's agentic flow, test step 3 of
the "Setup for maximum success" checklist (asking it to make a
real tool call) before committing to it.

---

## OATI Code internal limitations (worth knowing about)

### Webview doesn't auto-refresh on UI source changes

**Symptom:** After installing a new VSIX, UI changes don't appear.

**Workaround:** Always run **Developer: Reload Window** (Ctrl+Shift+P)
after installing a new VSIX. VS Code caches webview HTML and won't
pick up new UI without a window reload.

### Settings tabs USED to pollute the sidebar with phantom rows

**Status:** Fixed in this session (Group K in `CHANGELOG.md`). For
sessions minted by OLD builds before that fix, the phantom rows are
still in storage as orphan sessions. Delete them manually via the
trash icon in the sidebar.

### Inline completion is a separate model lane from chat

If `oati.inlineCompletion.model` is unset (default), inline FIM
completion uses the same model as chat — which is often the wrong
model for keystroke-driven autocomplete (frontier models are too
slow and expensive). Set it to a smaller FIM-tuned model like Qwen
2.5 Coder 7B or Codestral.

---

## Reach-out list (action items for the user)

When you next get the OATI ops team's attention, ask for:

1. ✅ **Done 2026-06-20:** Raise Qwen 3 Coder `--max-model-len` from
   16K to a more usable value. Raised to 32K. Could go higher.
2. **Keep Gemma 4 loaded** — currently gets unloaded periodically
3. **Confirm Kimi K2.6 SGLang gateway exposes `/v1/...`** OpenAI-
   compat endpoints, or enable them if not
4. **Consider a docs page** listing all OATI internal model gateways
   with their URLs + model IDs, so users don't have to discover them
   one at a time
