# OATI Code — Deployment Guide

How to install the OATI Code VSIX on another machine, and configure
it to talk to one or more OATI gateways.

---

## Step 1 — Verify the VSIX integrity

The current distributable is at:
```
artifacts/oati-coding-assistant.vsix
```

Expected SHA-256:
```
cf6f5bb486064133653ded40a4e7e6e5a18556413a43d3d7b92b0e2df9a98e40
```

After copying the file to the target machine, verify it matches:

**PowerShell:**
```powershell
Get-FileHash -Algorithm SHA256 oati-coding-assistant.vsix
```

**Linux / macOS:**
```bash
sha256sum oati-coding-assistant.vsix
```

Mismatch = corrupted copy. Re-transfer.

---

## Step 2 — Prerequisites on the target machine

| Required? | What | Why |
|---|---|---|
| ✅ Yes | **VS Code ≥ 1.90.0** | Engine version pinned in package.json |
| ❌ No | Node.js | All deps inlined into the bundle |
| ⚠️ Conditional | OATI VPN / corporate network | Only if using `.oati.local` or internal `vllm.dev.services.oati.com` gateways; not needed for `llm.dev.genie.oati.com` (public-fronted) or external API providers |

---

## Step 3 — Install the VSIX

### Option A — VS Code GUI

1. Open VS Code on the target machine
2. Extensions sidebar (Ctrl+Shift+X)
3. Click the `⋯` menu (top right of the sidebar)
4. Pick **Install from VSIX…**
5. Browse to `oati-coding-assistant.vsix`
6. Click **Reload** when prompted

### Option B — Command line

```powershell
# If the user previously had OATI Code installed, uninstall first
code --uninstall-extension oati.oati-coding-assistant

# Install the new VSIX
code --install-extension "C:\path\to\oati-coding-assistant.vsix"
```

Then in VS Code: Ctrl+Shift+P → **Developer: Reload Window**.

---

## Step 4 — First-run configuration

1. Click the **OATI Code** activity bar icon (left rail)
2. The chat panel opens. Click the Settings cog in its header.
3. Go to **API Configuration** tab.
4. Add at least one provider — see Step 5 below for the recommended
   starting providers.
5. Click **Test Connection** on each provider. After this session's
   improvements, Test Connection now actually validates that:
   - The URL responds with HTTP 200
   - The response body is a valid `/v1/models` list
   - The model ID you configured is in the served list
   It will report `✅ "<model>" is loaded` or `❌ "<model>" is NOT in
   the served list. Loaded models: ...` so you can pick the right id.
6. Set one provider as **Active** (star icon)
7. In the chat, type `/init` to create an `OATI.md` project memory
   file for the workspace.

---

## Step 5 — Recommended starting providers

Add whichever set fits the user's situation:

### For users on the OATI network (or VPN'd in)

**OATI gpt-oss-120b** — the strongest currently-available OATI
internal option.

| Field | Value |
|---|---|
| Preset | OATI Compatible |
| Display Name | `OATI gpt-oss` |
| Base URL | `https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1` |
| API Key | *blank* |
| Model ID | `openai/gpt-oss-120b` (verbatim) |

**OATI Qwen 3 Coder** — code-trained, 32K window, viable for short-to-mid
sessions.

| Field | Value |
|---|---|
| Preset | OATI Compatible |
| Display Name | `OATI Qwen` |
| Base URL | `http://vllm.dev.services.oati.com/qwen3_coder/v1` |
| API Key | *blank* |
| Model ID | `Qwen/Qwen3-Coder-30B-A3B-Instruct` (verbatim) |

**OATI Gemma 4** — chat-only / Ask-mode only. Not for agentic work.

| Field | Value |
|---|---|
| Preset | OATI Compatible |
| Display Name | `OATI Gemma (Ask)` |
| Base URL | `http://vllm.dev.services.oati.com/gemma_4/v1` |
| API Key | *blank* |
| Model ID | `google/gemma-4-26B-A4B` (verbatim) |

After adding Gemma, also switch the active mode to **Ask** in
Settings → Modes before using it.

### For users off the OATI network

Only **gpt-oss-120b** works from outside (the `.oati.com` hostname is
public-fronted). Gemma, Qwen, and Kimi K2.6 all need internal access.

External API options (also work everywhere with an API key):

**Anthropic Claude direct**
| Field | Value |
|---|---|
| Preset | Anthropic (native) |
| Base URL | `https://api.anthropic.com/v1` (default) |
| API Key | from `console.anthropic.com` |
| Model ID | `claude-opus-4-7` or `claude-sonnet-4-6` |

**Kimi K2.6 via OpenRouter**
| Field | Value |
|---|---|
| Preset | Kimi K2.6 (recommended) |
| Base URL | `https://openrouter.ai/api/v1` (default) |
| API Key | from `openrouter.ai/keys` |
| Model ID | `moonshotai/kimi-k2` |

---

## Step 6 — Sanity check

In any folder with the OATI Code panel open:

1. Type `/help` → should see the help message
2. Type `What is 2 + 2?` → should respond `4` cleanly, no looping
3. If the chat panel renders blank or no response comes back, check
   the Output channel: View → Output → pick **OATI Code** from the
   dropdown.

---

## What carries over from machine to machine (in the VSIX)

- All 60+ built-in tools (read_file, write_file, exec, grep, etc.)
- 11 bundled skills (`branded-pptx`, `bash-advanced`, etc.)
- Default modes (Ask / Plan / Code / Auto-Edit / Auto)
- All provider presets (OpenAI, Anthropic, OpenRouter, Kimi K2,
  **OATI Compatible**, Ollama, LiteLLM, etc.)
- Curated model lists per provider
- 1,806 tests' worth of pinned behavior

## What does NOT carry over (each machine sets up separately)

- API keys (per-machine via VS Code's `SecretStorage`)
- Workspace `.oati/` configs (per-workspace by design — skills, MCP
  servers, hooks, slash commands)
- Session history (per-machine, in VS Code globalState)
- `OATI.md` project memory (per-workspace — run `/init` in each
  project)
- Active provider / active mode selection

---

## Uninstall

```powershell
code --uninstall-extension oati.oati-coding-assistant
```

Or via GUI: Extensions sidebar → find "OATI Code" → cog →
**Uninstall**.

This removes the extension. Session history and API keys persist in
VS Code's storage unless you also remove the storage folder manually
(`%APPDATA%\Code\User\globalStorage\oati.oati-coding-assistant\` on
Windows).

---

## Updating to a newer build

Same as installing — `code --install-extension` over the existing
install will replace it. After install, **always reload the window**
(Ctrl+Shift+P → Developer: Reload Window) — VS Code caches webview
content and won't pick up new UI without a reload.
