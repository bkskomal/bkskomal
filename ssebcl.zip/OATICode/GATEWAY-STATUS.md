# OATI Gateway Status — verified 2026-06-22

State of every OATI internal model gateway the OATI Code extension
might connect to. Each row was verified by hitting `/v1/models`
directly with curl on the date noted.

⚠️ **Gateway state changes** — re-probe before trusting any "verified"
status for time-sensitive decisions. The re-probe commands are at the
bottom of this doc.

---

## Three vLLM gateways (OpenAI-compatible)

### gpt-oss-120b — ✅ healthy

- **Hostname:** `llm.dev.genie.oati.com` (public-fronted, no VPN needed)
- **Base URL for OATI Code:** `https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1`
- **Model ID for OATI Code:** `openai/gpt-oss-120b` (verbatim from `/v1/models`)
- **API Key:** none required
- **max_model_len:** 131,072 (128K)
- **Tool-call format:** `openai-tools` (native function-calling envelope)
- **System status:** loaded and serving as of 2026-06-22
- **OATI provider preset:** "OATI Compatible" curated model
- **Recommendation:** ✅ **Best OATI-internal option for agentic work.**
  Strong tool-call training, large context window, properly configured
  server-side chat template. Use this as your primary OATI-internal
  provider.

### Gemma 4 (26B-A4B) — ⚠️ unreliable, chat-only

- **Hostname:** `vllm.dev.services.oati.com` (internal, network-gated)
- **Base URL for OATI Code:** `http://vllm.dev.services.oati.com/gemma_4/v1`
- **Model ID for OATI Code:** `google/gemma-4-26B-A4B`
- **API Key:** none required
- **max_model_len:** 262,144 (256K — full native window)
- **Tool-call format:** `inline-xml` (via `/v1/completions` fallback)
- **System status:** model has been unloaded multiple times during the
  session (`/v1/models` returns empty); ops reloads on request.
  Verified loaded as of 2026-06-22.
- **OATI provider preset:** "OATI Compatible" curated model
- **Recommendation:** ⚠️ **Use in Ask mode only.** Gemma 4 isn't tool-
  trained — it narrates "I'll use the X tool" without emitting the
  inline-XML tags. Good for Q&A, code explanation, single-file
  analysis. Avoid for multi-file edits or autonomous tasks.
- **Important:** routes through `/v1/completions` (raw prompt) instead
  of `/v1/chat/completions` because the gateway has no tokenizer
  chat_template AND blocks request-side templates. Handled
  automatically by `ModelQuirks.useCompletionsFallback: true`.

### Qwen 3 Coder (30B-A3B-Instruct) — ✅ viable (32K cap)

- **Hostname:** `vllm.dev.services.oati.com` (internal, network-gated)
- **Base URL for OATI Code:** `http://vllm.dev.services.oati.com/qwen3_coder/v1`
- **Model ID for OATI Code:** `Qwen/Qwen3-Coder-30B-A3B-Instruct`
- **API Key:** none required
- **max_model_len:** **32,768 (32K)** — ops raised it from 16K on
  2026-06-20. Tight but viable for OATI's prompts.
- **Tool-call format:** `inline-xml` (via `/v1/completions` fallback)
- **System status:** loaded as of 2026-06-22.
- **OATI provider preset:** "OATI Compatible" curated model
- **Recommendation:** ✅ **Viable for short-to-mid agentic sessions.**
  Code-trained, terse, decent tool-following. Base prompt ~17.5K
  tokens + 4K output cap leaves ~10K conversation headroom — use
  `/compact` mid-conversation if it gets long.
- **ModelQuirks contextWindow:** 32,768 (tracks deployment, not the
  256K native window). Auto-compact fires at 60% (~20K) to keep
  request well under the 32K cap.

---

## SGLang Kimi K2.6 gateway

### Kimi K2.6 — ⚠️ wrong URL in user config; partially diagnosed

- **Hostname:** `genieappn7.dev.oati.local` (internal, network-gated;
  `.oati.local` won't resolve off the OATI network at all)
- **Server type:** SGLang (FastAPI-based; exposes both native SGLang
  endpoints and OpenAI-compat endpoints)
- **Likely correct Base URL:** `http://genieappn7.dev.oati.local:31245/v1`
  (NOT `/docs` — that's the Swagger UI for humans)
- **Verification status:** unverified — user has not yet confirmed the
  `/v1/chat/completions` endpoint exists on this deployment. Could
  not probe from outside the OATI network.
- **What to do next:** Either scroll the Swagger UI at
  `http://genieappn7.dev.oati.local:31245/docs` looking for the `/v1/...`
  endpoints, OR run from a network-reachable machine:
  ```powershell
  curl.exe -s "http://genieappn7.dev.oati.local:31245/v1/models"
  ```
- If `/v1/...` endpoints exist → standard OATI Compatible preset
  setup. If they don't, ops needs to enable SGLang's OpenAI-compat
  surface (or OATI would need a native SGLang provider, not currently
  planned).

---

## External API providers (for context)

These aren't OATI gateways but were referenced multiple times. Verified
historically; specs change.

| Provider | URL | Auth | Notes |
|---|---|---|---|
| **Kimi K2.6 (OpenRouter)** | `https://openrouter.ai/api/v1` | API key | 262,144 (256K). Best for agentic coding on the primary lane. |
| **Anthropic Claude (Opus 4.7+)** | `https://api.anthropic.com/v1` | API key | 200,000 (200K). `omitTemperature: true` in quirks (Opus 4.7+ rejects the field). |
| **OpenAI GPT family** | `https://api.openai.com/v1` | API key | 128,000 (128K). |

---

## Re-probe commands

Run these from a network-reachable machine (inside OATI, or VPN'd in
for `.oati.local`):

```bash
# Three OATI vLLM gateways
echo "=== Gemma ===" ; curl -s --max-time 10 "http://vllm.dev.services.oati.com/gemma_4/v1/models"
echo ; echo "=== Qwen ===" ; curl -s --max-time 10 "http://vllm.dev.services.oati.com/qwen3_coder/v1/models"
echo ; echo "=== gpt-oss ===" ; curl -s --max-time 10 "https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1/models"

# SGLang Kimi K2.6 — requires .oati.local reachability
echo ; echo "=== Kimi K2.6 (SGLang) ===" ; curl -s --max-time 10 "http://genieappn7.dev.oati.local:31245/v1/models"
```

**What healthy responses look like:**
```json
{"object":"list","data":[{"id":"<model-id>","object":"model","max_model_len":<int>,...}]}
```

**What "gateway up but no model loaded" looks like:**
```json
{"object":"list","data":[]}
```

When OATI Code's Test Connection sees the empty case, it now reports
"200 OK but the gateway has NO models loaded" (since the uncommitted
diff). Ask the ops team to reload the model.

---

## Network reachability matrix

| Machine location | OATI internal `.oati.local`? | OATI public `oati.com`? |
|---|---|---|
| Inside OATI office / VPN'd in | ✅ Yes | ✅ Yes |
| Home / personal laptop off-network | ❌ DNS won't resolve | ✅ Yes |
| Public WiFi | ❌ No | ✅ Yes |

**Practical implication:** if you ship the OATI Code VSIX to colleagues
on personal laptops, point them at gpt-oss-120b (`llm.dev.genie.oati.com`)
not Gemma/Qwen/Kimi (which need OATI internal network access).
