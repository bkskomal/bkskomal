// 2026-06-06: extracted from app.tsx so the composer's mode-picker row
// can render the same chip. Previously the indicator only mounted in
// the top header above the chat, costing a row of vertical space; now
// it lives alongside the mode picker so the chat reclaims that space.

import type { SettingsSnapshot } from "@oati/shared";
import { detectModelQuirks } from "@oati/shared";

export interface ContextFillIndicatorProps {
	readonly currentTokens: number;
	readonly snapshot: SettingsSnapshot | null;
}

/**
 * Shows how much of the active model's context window the most recent turn
 * occupied. Lets users SEE that big-context models like Kimi K2.6 (256K)
 * are actually being used to capacity rather than artificially truncated.
 */
export function ContextFillIndicator({ currentTokens, snapshot }: ContextFillIndicatorProps) {
	const modelId = resolveActiveModelId(snapshot);
	if (!modelId) return null;
	const quirks = detectModelQuirks(modelId);
	const windowSize = quirks.contextWindow;
	if (!windowSize || windowSize <= 0) return null;
	const pct = Math.min(100, Math.round((currentTokens / windowSize) * 100));
	const tier = pct >= 80 ? "danger" : pct >= 50 ? "warn" : "ok";
	const title = `Context fill: ${formatTokens(currentTokens)} / ${formatTokens(windowSize)} (${pct}%) — last turn's prompt vs. ${modelId}'s ${formatTokens(windowSize)} window. Auto-compact fires before the model rejects.`;
	return (
		<span class={`oati-context-fill oati-context-fill--${tier}`} title={title}>
			<span class="oati-context-fill-bar" aria-hidden="true">
				<span class="oati-context-fill-bar-inner" style={{ width: `${pct}%` }} />
			</span>
			<span class="oati-context-fill-text">
				{formatTokens(currentTokens)}/{formatTokens(windowSize)} · {pct}%
			</span>
		</span>
	);
}

function formatTokens(n: number): string {
	if (n < 1000) return String(n);
	if (n < 1_000_000) return `${(n / 1000).toFixed(1)}k`;
	return `${(n / 1_000_000).toFixed(2)}M`;
}

function resolveActiveModelId(snapshot: SettingsSnapshot | null): string | undefined {
	if (!snapshot) return undefined;
	const cfg = snapshot.config;
	const activeMode = cfg.modes.find((m) => m.id === cfg.activeModeId) ?? cfg.modes[0];
	if (activeMode?.modelId) return activeMode.modelId;
	const providerId = activeMode?.providerId ?? cfg.activeProviderId;
	const provider = cfg.providers.find((p) => p.id === providerId);
	return provider?.defaultModel || undefined;
}
