﻿namespace Meet.Domain.Enums;

public enum UserRole
{
	Host = 1,
	Admin = 2
}
