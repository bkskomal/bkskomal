﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meet.Domain.Common;

public abstract class TenantEntity
{
	public Guid Id { get; set; }
	public Guid OrganizationId { get; set; }
	public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
