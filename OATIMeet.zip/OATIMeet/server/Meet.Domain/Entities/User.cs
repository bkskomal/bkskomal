﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Meet.Domain.Common;
using Meet.Domain.Enums;

namespace Meet.Domain.Entities;

public class User : TenantEntity
{
	public string Name { get; set; } = default!;
	public string Email { get; set; } = default!;

	// Identity
	public string PasswordHash { get; set; } = default!;
	public UserRole Role { get; set; } 

	public bool IsActive { get; set; } = true;
}
