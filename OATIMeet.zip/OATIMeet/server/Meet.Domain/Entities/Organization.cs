﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Meet.Domain.Common;

namespace Meet.Domain.Entities;

public class Organization : TenantEntity
{
	public string Name { get; set; } = default!;
	public string Plan { get; set; } = "Free";
}
