﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Meet.Domain.Common;

namespace Meet.Domain.Entities;

public enum MeetingStatus
{
	Scheduled = 0,
	Ready = 1,
	Active = 2,
	Ended = 3,
	Archived = 4,
	Expired = 5
}

public class Meeting : TenantEntity
{
	public string Title { get; set; } = default!;
	public string RoomName { get; set; } = default!;
	public string MeetingCode { get; set; } = default!;
	public Guid HostUserId { get; set; }

	public DateTime ScheduledTimeUtc { get; set; }
	public DateTime? ActualStartUtc { get; set; }
	public DateTime? ActualEndUtc { get; set; }

	public MeetingStatus Status { get; set; }

	public bool AllowGuests { get; set; }
	public bool EnableLobby { get; set; }
	public bool IsLocked { get; set; }
}
