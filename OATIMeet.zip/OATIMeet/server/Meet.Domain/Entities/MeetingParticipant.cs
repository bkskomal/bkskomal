﻿using Meet.Domain.Common;

namespace Meet.Domain.Entities;

public enum ParticipantType
{
	Guest = 0,
	User = 1
}

public enum ParticipantStatus
{
	Waiting = 0,
	Approved = 1,
	Rejected = 2,
	Left = 3
}

public class MeetingParticipant : TenantEntity
{
	public Guid MeetingId { get; set; }
	public string DisplayName { get; set; } = default!;

	public ParticipantType Type { get; set; }
	public ParticipantStatus Status { get; set; }

	public DateTime JoinedAtUtc { get; set; } = DateTime.UtcNow;
}
