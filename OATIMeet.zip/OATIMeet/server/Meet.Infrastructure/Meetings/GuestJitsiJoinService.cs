﻿using Meet.Application.Common;
using Meet.Application.Meetings;
using Meet.Application.Meetings.DTOs;
using Meet.Domain.Entities;
using Meet.Infrastructure.Jitsi;
using Meet.Infrastructure.Persistence;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Meet.Infrastructure.Meetings;

public class GuestJitsiJoinService : IGuestJitsiJoinService
{
	private readonly AppDbContext _db;
	private readonly IJitsiTokenService _jitsi;
	private readonly IHttpContextAccessor _accessor;

	public GuestJitsiJoinService(
		AppDbContext db,
		IJitsiTokenService jitsi,
		IHttpContextAccessor accessor)
	{
		_db = db;
		_jitsi = jitsi;
		_accessor = accessor;
	}

	public async Task<Result<GuestJitsiJoinDto>> JoinAsync(GuestJoinJitsiCommand cmd)
	{
		/* ---------------- PARTICIPANT ---------------- */

		var participant = await _db.MeetingParticipants
			.FirstOrDefaultAsync(x =>
				x.Id == cmd.ParticipantId &&
				x.MeetingId == cmd.MeetingId);

		if (participant == null)
			return Result<GuestJitsiJoinDto>.Failure("NOT_FOUND", "Participant not found");

		/* ---------------- STATUS CHECK ---------------- */

		if (participant.Status == ParticipantStatus.Waiting)
			return Result<GuestJitsiJoinDto>.Failure("WAITING", "Waiting for host approval");

		if (participant.Status == ParticipantStatus.Rejected)
			return Result<GuestJitsiJoinDto>.Failure("DENIED", "Host rejected your request");

		if (participant.Status != ParticipantStatus.Approved)
			return Result<GuestJitsiJoinDto>.Failure("DENIED", "Not allowed to join");

		/* ---------------- MEETING ---------------- */

		var meeting = await _db.Meetings
			.FirstOrDefaultAsync(x => x.Id == cmd.MeetingId);

		if (meeting == null)
			return Result<GuestJitsiJoinDto>.Failure("MEETING_NOT_FOUND", "Meeting not found");

		if (meeting.Status != MeetingStatus.Active)
			return Result<GuestJitsiJoinDto>.Failure("NOT_ACTIVE", "Meeting is not active");

		/* ---------------- JWT ---------------- */

		var jwt = _jitsi.Generate(
			meeting.RoomName,
			participant.Id.ToString(),
			participant.DisplayName,
			isModerator: false
		);

		/* ---------------- RESPONSE ---------------- */

		var http = _accessor.HttpContext!;

		return Result<GuestJitsiJoinDto>.Success(new GuestJitsiJoinDto
		{
			ServerUrl = $"{http.Request.Scheme}://{http.Request.Host}",
			RoomName = meeting.RoomName,
			Jwt = jwt,
			DisplayName = participant.DisplayName
		});
	}

	public async Task<Result<GuestJoinResponseDto>> CreateParticipantAsync(GuestJoinCommand cmd)
	{
		var meeting = await _db.Meetings
			.FirstOrDefaultAsync(x =>
				x.RoomName == cmd.MeetingCode &&
				x.Status == MeetingStatus.Active);

		if (meeting == null)
			return Result<GuestJoinResponseDto>.Failure(
				"NOT_ACTIVE",
				"Meeting is not active"
			);

		var participant = new MeetingParticipant
		{
			Id = Guid.NewGuid(),
			MeetingId = meeting.Id,
			DisplayName = cmd.DisplayName,
			Status = ParticipantStatus.Waiting,
			JoinedAtUtc = DateTime.UtcNow
		};

		_db.MeetingParticipants.Add(participant);
		await _db.SaveChangesAsync();

		return Result<GuestJoinResponseDto>.Success(new GuestJoinResponseDto
		{
			MeetingId = meeting.Id,
			ParticipantId = participant.Id,
			WaitingForApproval = true
		});
	}
}