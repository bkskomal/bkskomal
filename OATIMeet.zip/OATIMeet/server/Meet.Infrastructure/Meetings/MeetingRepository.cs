﻿using Meet.Application.Meetings;
using Meet.Domain.Entities;
using Meet.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Meet.Infrastructure.Meetings;

public class MeetingRepository : IMeetingRepository
{
	private readonly AppDbContext _db;

	public MeetingRepository(AppDbContext db)
	{
		_db = db;
	}

	public Task<Meeting?> GetByIdAsync(Guid meetingId)
		=> _db.Meetings.FirstOrDefaultAsync(x => x.Id == meetingId);

	public Task<Meeting?> GetByCodeAsync(string meetingCode)
		=> _db.Meetings.FirstOrDefaultAsync(x => x.MeetingCode == meetingCode);

	public async Task AddParticipantAsync(MeetingParticipant participant)
	{
		_db.MeetingParticipants.Add(participant);
		await Task.CompletedTask;
	}

	public Task<MeetingParticipant?> GetParticipantAsync(Guid meetingId, Guid participantId)
		=> _db.MeetingParticipants
			  .FirstOrDefaultAsync(x => x.MeetingId == meetingId && x.Id == participantId);

	public Task SaveChangesAsync()
		=> _db.SaveChangesAsync();

	public async Task<IReadOnlyList<MeetingParticipant>> GetWaitingParticipantsAsync(Guid meetingId)
	{
		return await _db.MeetingParticipants
			.Where(x =>
				x.MeetingId == meetingId &&
				x.Status == ParticipantStatus.Waiting)
			.OrderBy(x => x.JoinedAtUtc)
			.ToListAsync();
	}

	public async Task AddMeetingAsync(Meeting meeting)
	{
		_db.Meetings.Add(meeting);
		await Task.CompletedTask;
	}

	public async Task<IReadOnlyList<Meeting>> GetMeetingsForUserAsync(Guid userId)
	{
		return await _db.Meetings
			.OrderByDescending(x => x.ScheduledTimeUtc)
			.ToListAsync();
	}

	public async Task<Meeting?> GetActiveByRoomNameAsync(string roomName)
	{
		return await _db.Meetings
			.Where(x =>
				x.Title.ToLower() == roomName.ToLower() &&
				x.Status != MeetingStatus.Ended)
			.FirstOrDefaultAsync();
	}


}
