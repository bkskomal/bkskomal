﻿using Meet.Application.Common;
using Meet.Application.Meetings;
using Meet.Application.Meetings.DTOs;
using Meet.Domain.Entities;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Meet.Infrastructure.Meetings;

public class MeetingService : IMeetingService
{
	private readonly IMeetingRepository _repo;
	private readonly ILobbyNotifier _notifier;
	private readonly Guid _currentUserId;
	private  IHttpContextAccessor _accessor;
	public MeetingService(
		IMeetingRepository repo,
		ILobbyNotifier notifier,
		IHttpContextAccessor accessor)
	{
		_repo = repo;
		_notifier = notifier;
		_accessor = accessor;


		if (!TryGetCurrentUserId(out var _currentUserId))
		{
		}
		
	}

	public async Task<Result<MeetingCreatedDto>> CreateAsync(CreateMeetingCommand cmd)
	{
		Guid _currentUserId = Guid.Parse(
			_accessor.HttpContext!.User.FindFirstValue(ClaimTypes.NameIdentifier)!
		);

		var meeting = new Meeting
		{
			Id = Guid.NewGuid(),
			Title = cmd.Title,
			ScheduledTimeUtc = cmd.ScheduledTimeUtc,
			RoomName = cmd.Title, //$"meet-{Guid.NewGuid():N}",
			MeetingCode = GenerateMeetingCode(),
			HostUserId = _currentUserId,
			Status = MeetingStatus.Scheduled,
			AllowGuests = cmd.AllowGuests,
			EnableLobby = cmd.EnableLobby
		};

		await _repo.AddMeetingAsync(meeting);
		await _repo.SaveChangesAsync();

		return Result<MeetingCreatedDto>.Success(new MeetingCreatedDto
		{
			MeetingId = meeting.Id,
			MeetingCode = meeting.MeetingCode,
			RoomName	=	meeting.RoomName,
			ScheduledTimeUtc = meeting.ScheduledTimeUtc
		});
	}

	private bool TryGetCurrentUserId(out Guid userId)
	{
		userId = Guid.Empty;

		var http = _accessor.HttpContext;
		if (http?.User?.Identity?.IsAuthenticated != true)
			return false;

		var idStr = http.User.FindFirstValue(ClaimTypes.NameIdentifier);
		return Guid.TryParse(idStr, out userId);
	}

	public async Task<Result<IReadOnlyList<MeetingListItemDto>>> GetMyMeetingsAsync()
	{
		var meetings = await _repo.GetMeetingsForUserAsync(_currentUserId);

		var result = meetings.Select(x => new MeetingListItemDto
		{
			MeetingId = x.Id,
			Title = x.Title,
			ScheduledTimeUtc = x.ScheduledTimeUtc,
			Status = x.Status.ToString(),
			IsHost = x.HostUserId == _currentUserId
		}).ToList();

		return Result<IReadOnlyList<MeetingListItemDto>>.Success(result);
	}

	public async Task<Result<MeetingDetailsDto>> GetByIdAsync(Guid meetingId)
	{
		var meeting = await _repo.GetByIdAsync(meetingId);
		if (meeting == null)
			return Result<MeetingDetailsDto>.Failure("NOT_FOUND", "Meeting not found");

		return Result<MeetingDetailsDto>.Success(new MeetingDetailsDto
		{
			MeetingId = meeting.Id,
			Title = meeting.Title,
			MeetingCode = meeting.MeetingCode,
			ScheduledTimeUtc = meeting.ScheduledTimeUtc,
			Status = meeting.Status.ToString(),
			AllowGuests = meeting.AllowGuests,
			EnableLobby = meeting.EnableLobby,
			IsLocked = meeting.IsLocked,
			IsHost = meeting.HostUserId == _currentUserId
		});
	}

	public async Task<Result> UpdateAsync(Guid meetingId, UpdateMeetingCommand cmd)
	{
		var meeting = await _repo.GetByIdAsync(meetingId);
		if (meeting == null)
			return Result.Failure("NOT_FOUND", "Meeting not found");

		if (meeting.HostUserId != _currentUserId)
			return Result.Failure("FORBIDDEN", "Only host can update meeting");

		if (meeting.Status != MeetingStatus.Scheduled)
			return Result.Failure("INVALID_STATE", "Meeting already started");

		meeting.Title = cmd.Title;
		meeting.ScheduledTimeUtc = cmd.ScheduledTimeUtc;

		await _repo.SaveChangesAsync();

		// 🔔 Notify lobby listeners (API decides how)
		await _notifier.NotifyLobbyUpdated(meetingId);

		return Result.Success();
	}

	public async Task<Result> StartAsync(Guid meetingId)
	{
		var meeting = await _repo.GetByIdAsync(meetingId);
		if (meeting == null)
			return Result.Failure("NOT_FOUND", "Meeting not found");

		if (meeting.HostUserId != _currentUserId)
			return Result.Failure("FORBIDDEN", "Only host can start meeting");

		meeting.Status = MeetingStatus.Active;
		meeting.ActualStartUtc = DateTime.UtcNow;

		await _repo.SaveChangesAsync();
		await _notifier.NotifyLobbyUpdated(meetingId);

		return Result.Success();
	}

	public async Task<Result> EndAsync(Guid meetingId)
	{
		var meeting = await _repo.GetByIdAsync(meetingId);
		if (meeting == null)
			return Result.Failure("NOT_FOUND", "Meeting not found");

		if (meeting.HostUserId != _currentUserId)
			return Result.Failure("FORBIDDEN", "Only host can end meeting");

		meeting.Status = MeetingStatus.Ended;
		meeting.ActualEndUtc = DateTime.UtcNow;

		await _repo.SaveChangesAsync();
		await _notifier.NotifyLobbyUpdated(meetingId);

		return Result.Success();
	}


	public async Task<Meeting?> GetActiveByRoomNameAsync(string roomName)
	{
		var meeting = await _repo.GetActiveByRoomNameAsync(roomName);

		if (meeting == null)
		{
			return new Meeting
			{
				RoomName= "NotExist",
			};
		}

		return new Meeting
		{
			Id = meeting.Id,
			RoomName = meeting.RoomName
		};
	}

	public async Task<MeetingStatusDto> GetMeetingStatusByRoomNameAsync(string roomName)
	{
		var meeting = await _repo.GetActiveByRoomNameAsync(roomName);

		if (meeting == null)
		{
			return new MeetingStatusDto
			{
				Exists = false,
				IsActive = false
			};
		}

		return new MeetingStatusDto
		{
			Exists = true,
			IsActive = true,
			RoomName = meeting.RoomName
		};
	}

	private static string GenerateMeetingCode()
		=> Random.Shared.Next(100_000_000, 999_999_999).ToString();
}
