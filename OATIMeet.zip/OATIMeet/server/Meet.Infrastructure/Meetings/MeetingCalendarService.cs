﻿using Meet.Application.Meetings;
using Meet.Application.Meetings.DTOs;
using Meet.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace Meet.Infrastructure.Meetings;

public class MeetingCalendarService : IMeetingCalendarService
{
    private readonly AppDbContext _db;
	private readonly IConfiguration _config;

	public MeetingCalendarService(AppDbContext db, IConfiguration config)
    {
        _db = db;
		_config = config;

	}

    public async Task<CalendarFileResult?> GenerateCalendarAsync(
        string roomName,
        int durationMinutes = 60,
        int reminderMinutes = 10,
        string? recurrenceRule = null)
    {

		var appBaseUrl = "https://" + _config["Jitsi:ServerBaseUrl"];

		var meeting = await _db.Meetings
            .FirstOrDefaultAsync(x => x.Title.ToLower() == roomName.ToLower());

        if (meeting == null)
            return null;

        var start = meeting.ScheduledTimeUtc;
        var end = start.AddMinutes(durationMinutes);


		var description =
            $"Join meeting using this meeting line:\\n" +
            $"Meeting Link: {appBaseUrl}/{meeting.Title}";

		var icsLines = new List<string>
    {
	    "BEGIN:VCALENDAR",
	    "VERSION:2.0",
	    "PRODID:-//Meet App//Calendar//EN",
	    "CALSCALE:GREGORIAN",
	    "METHOD:PUBLISH",   // ✅ IMPORTANT FIX

        "BEGIN:VEVENT",
	    $"UID:{meeting.Id}",
	    $"DTSTAMP:{DateTime.UtcNow:yyyyMMddTHHmmssZ}",
	    $"DTSTART:{start:yyyyMMddTHHmmssZ}",
	    $"DTEND:{end:yyyyMMddTHHmmssZ}",
	    $"SUMMARY:{meeting.Title}",

        // ✅ Clean multiline description
        $"DESCRIPTION:Join meeting using Meeting Code: {meeting.MeetingCode}\\n" +
	    $"Meeting Link: {appBaseUrl}/{meeting.Title}",

	    "LOCATION:Meet App",

	    "END:VEVENT",
	    "END:VCALENDAR"
    };


		// ✅ Recurrence support
		if (!string.IsNullOrWhiteSpace(recurrenceRule))
        {
            icsLines.Add($"RRULE:{recurrenceRule}");
        }

        // ✅ Reminder (VALARM)
        if (reminderMinutes > 0)
        {
            icsLines.Add("BEGIN:VALARM");
            icsLines.Add($"TRIGGER:-PT{reminderMinutes}M");
            icsLines.Add("ACTION:DISPLAY");
            icsLines.Add("DESCRIPTION:Reminder");
            icsLines.Add("END:VALARM");
        }

        icsLines.Add("END:VEVENT");
        icsLines.Add("END:VCALENDAR");

        var ics = string.Join("\r\n", icsLines);

        return new CalendarFileResult
        {
            Content = Encoding.UTF8.GetBytes(ics),
            FileName = $"meet-{meeting.MeetingCode}.ics"
        };
    }



	/* -------------------- Helpers -------------------- */

	private static string Escape(string value)
    {
        return value
            .Replace("\\", "\\\\")
            .Replace(";", "\\;")
            .Replace(",", "\\,")
            .Replace("\n", "\\n")
            .Replace("\r", "");
    }
}
