﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Meet.Infrastructure.Tenant;

public class TenantProvider : ITenantProvider
{
	public Guid OrganizationId { get; }

	public TenantProvider(IHttpContextAccessor accessor)
	{
		var claim = accessor.HttpContext?.User?.FindFirst("org");
		OrganizationId = claim != null ? Guid.Parse(claim.Value) : Guid.Empty;
	}
}
