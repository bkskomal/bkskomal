﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

namespace Meet.Infrastructure.Tenant;

public class DesignTimeTenantProvider : ITenantProvider
{
	// Design-time (migrations) tenant
	public Guid OrganizationId => Guid.Empty;
}
