﻿using Meet.Application.Common;
using Meet.Application.Meetings;
using Meet.Application.Meetings.DTOs;
using Meet.Domain.Entities;
using Meet.Infrastructure.Jitsi;
using Meet.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace Meet.Infrastructure.Meetings;

public class JitsiJoinService : IJitsiJoinService
{
	private readonly AppDbContext _db;
	private readonly IJitsiTokenService _jitsi;
	private readonly IHttpContextAccessor _accessor;
	private readonly IMeetingRepository _meetingRepository;

	public JitsiJoinService(
		AppDbContext db,
		IJitsiTokenService jitsi,
		IHttpContextAccessor accessor, IMeetingRepository meetingRepository)
	{
		_db = db;
		_jitsi = jitsi;
		_accessor = accessor;
		_meetingRepository = meetingRepository;
	}

	public async Task<Result<JitsiJoinDto>> JoinAsync(string roomName)
	{
		var meeting = await _meetingRepository.GetActiveByRoomNameAsync(roomName);

		if (meeting == null)
			return Result<JitsiJoinDto>.Failure("NOT_FOUND", "Meeting not found or not active");

		var httpContext = _accessor.HttpContext!;
		var user = httpContext.User;

		// ---------------- SAFE AUTH CHECK ----------------
		var isAuthenticated = user?.Identity?.IsAuthenticated == true;

		string userId;
		string displayName;
		bool isHost = false;

		if (isAuthenticated)
		{
			userId = user.FindFirstValue(ClaimTypes.NameIdentifier)!;
			displayName = user.FindFirstValue(ClaimTypes.Name) ?? "Host";

			isHost = meeting.HostUserId == Guid.Parse(userId);
		}
		else
		{
			// Guest join
			userId = Guid.NewGuid().ToString();
			displayName = string.IsNullOrWhiteSpace("Guest") ? "Guest" : "Guest";
			isHost = false;
		}

		// ---------------- JWT GENERATION ----------------
		var jwt = _jitsi.Generate(
			meeting.RoomName,
			userId,
			displayName,
			isHost
		);

		return Result<JitsiJoinDto>.Success(new JitsiJoinDto
		{
			ServerUrl = $"{httpContext.Request.Scheme}://{httpContext.Request.Host}",
			RoomName = meeting.RoomName,
			Jwt = jwt,
			DisplayName = displayName,
			IsModerator = isHost
		});
	}
}
