﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;

namespace Meet.Infrastructure.Jitsi;

public class JitsiTokenService : IJitsiTokenService
{
	private readonly IConfiguration _config;

	public JitsiTokenService(IConfiguration config)
	{
		_config = config;
	}

	private static RSA CreateRsaFromPem(string pem)
	{
		if (string.IsNullOrWhiteSpace(pem))
			throw new ArgumentNullException(nameof(pem), "Jitsi private key is missing");

		// 🔥 Convert escaped newlines to real newlines
		pem = pem
			.Replace("\\n", "\n")
			.Replace("\r\n", "\n")
			.Trim();

		var rsa = RSA.Create();
		rsa.ImportFromPem(pem.ToCharArray());
		return rsa;
	}

	public string Generate(
		string room,
		string userId,
		string displayName,
		bool isModerator)
	{
		var appId = _config["Jitsi:AppId"]!;
		var privateKeyPem = _config["Jitsi:PrivateKey"]!;

		using var rsa = CreateRsaFromPem(privateKeyPem);

		var credentials = new SigningCredentials(
			new RsaSecurityKey(rsa),
			SecurityAlgorithms.RsaSha256
		);

		var claims = new List<Claim>
		{
			new("context", $$"""
            {
              "user": {
                "id": "{{userId}}",
                "name": "{{displayName}}",
                "moderator": {{isModerator.ToString().ToLower()}}
              }
            }
            """),
			new("room", room)
		};

		var token = new JwtSecurityToken(
			issuer: appId,
			audience: "jitsi",
			claims: claims,
			expires: DateTime.UtcNow.AddMinutes(3),
			signingCredentials: credentials
		);

		return new JwtSecurityTokenHandler().WriteToken(token);
	}
}
