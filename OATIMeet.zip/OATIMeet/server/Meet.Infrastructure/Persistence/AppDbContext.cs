﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Meet.Domain.Entities;
using Meet.Infrastructure.Tenant;
using Microsoft.EntityFrameworkCore;

namespace Meet.Infrastructure.Persistence;

public class AppDbContext : DbContext
{
	private readonly ITenantProvider _tenant;

	public AppDbContext(
		DbContextOptions<AppDbContext> options,
		ITenantProvider tenant) : base(options)
	{
		_tenant = tenant;
	}

	public DbSet<User> Users => Set<User>();
	public DbSet<Organization> Organizations => Set<Organization>();
	public DbSet<Meeting> Meetings => Set<Meeting>();
	public DbSet<MeetingParticipant> MeetingParticipants => Set<MeetingParticipant>();


	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		modelBuilder.Entity<User>()
			   .Property(x => x.Role)
			   .HasConversion<string>();

		modelBuilder.Entity<Organization>();
		modelBuilder.Entity<MeetingParticipant>();
		modelBuilder.Entity<Meeting>();

		base.OnModelCreating(modelBuilder);
	}
}

