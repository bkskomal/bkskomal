﻿using Meet.Infrastructure.Tenant;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Meet.Infrastructure.Persistence;

public class AppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
{
	public AppDbContext CreateDbContext(string[] args)
	{
		// Build configuration manually (design-time)
		var configuration = new ConfigurationBuilder()
			.SetBasePath(Directory.GetCurrentDirectory())
			.AddJsonFile("appsettings.json", optional: false)
			.AddJsonFile("appsettings.Development.json", optional: true)
			.AddEnvironmentVariables()
			.Build();

		var provider = configuration["Database:Provider"];
		var connectionString = configuration.GetConnectionString("Default");

		var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();

		switch (provider)
		{
			case "Postgres":
				optionsBuilder.UseNpgsql(connectionString);
				break;

			case "MySql":
				optionsBuilder.UseMySql(
					connectionString,
					ServerVersion.AutoDetect(connectionString)
				);
				break;

			default:
				optionsBuilder.UseSqlServer(connectionString);
				break;
		}

		return new AppDbContext(
			optionsBuilder.Options,
			new DesignTimeTenantProvider()
		);
	}
}
