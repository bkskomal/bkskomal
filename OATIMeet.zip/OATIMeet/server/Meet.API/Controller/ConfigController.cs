﻿using Microsoft.AspNetCore.Mvc;

namespace Meet.API.Controller
{
	[ApiController]
	[Route("api/v1/config")]
	public class ConfigController : ControllerBase
	{
		private readonly IConfiguration _config;

		public ConfigController(IConfiguration config)
		{
			_config = config;
		}

		[HttpGet]
		public IActionResult Get()
		{
			return Ok(new
			{
				jitsiServerBaseUrl = _config["Jitsi:ServerBaseUrl"]
			});
		}
	}
}
