﻿using Meet.Application.Auth;
using Meet.Domain.Entities;
using Meet.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Meet.Domain.Enums;
using System.Collections.Immutable;
namespace Meet.API.Controllers;

[ApiController]
[Route("api/v1/auth")]
public class AuthController : ControllerBase
{
	private readonly AppDbContext _db;
	private readonly IPasswordHasher _hasher;
	private readonly IJwtTokenService _jwt;

	public AuthController(
		AppDbContext db,
		IPasswordHasher hasher,
		IJwtTokenService jwt)
	{
		_db = db;
		_hasher = hasher;
		_jwt = jwt;
	}

	// ---------------------------
	// SIGNUP / REGISTER
	// ---------------------------
	[HttpPost("register")]
	[AllowAnonymous]
	public async Task<IActionResult> Register(RegisterCommand request)
	{
		var exists = await _db.Users.AnyAsync(x => x.Email == request.Email);
		if (exists)
		{
			return BadRequest(new
			{
				message = "Email already registered"
			});
		}

		var user = new User
		{
			Id = Guid.NewGuid(),
			Email = request.Email,
			Name = request.Name,
			PasswordHash = _hasher.Hash(request.Password),
			Role = UserRole.Host,
			IsActive = true,
			OrganizationId = Guid.NewGuid(), // single-org for now
			CreatedAtUtc = DateTime.UtcNow
		};

		_db.Users.Add(user);
		await _db.SaveChangesAsync();

		return Ok(new
		{
			message = "User registered successfully"
		});
	}

	// ---------------------------
	// LOGIN
	// ---------------------------
	[HttpPost("login")]
	[AllowAnonymous]
	public async Task<IActionResult> Login(LoginCommand request)
	{

		var user = await _db.Users
			.FirstOrDefaultAsync(x =>
				x.Email == request.Email &&
				x.IsActive);

		if (user == null || !_hasher.Verify(user.PasswordHash, request.Password))
		{
			return Unauthorized(new
			{
				message = "Invalid email or password"
			});
		}

		var token = _jwt.GenerateToken(
			user.Id,
			user.OrganizationId,
			user.Role.ToString()
		);

		return Ok(new
		{
			accessToken = token,
			expiresIn = 900
		});
	}
}
