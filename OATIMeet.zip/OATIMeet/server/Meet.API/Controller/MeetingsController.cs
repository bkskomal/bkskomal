﻿using Meet.Application.Meetings;
using Meet.Application.Meetings.DTOs;
using Meet.Infrastructure.Meetings;
using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace Meet.API.Controllers;

[ApiController]
[Authorize]
[Route("api/v1/meetings")]
public class MeetingsController : ControllerBase
{
	private readonly IMeetingService _service;
	private readonly IJitsiJoinService _jitsiJoinService;
	private readonly IGuestJitsiJoinService _guestJitsiJoinService;
	private readonly ILobbyService _lobbyService;
	private readonly IMeetingCalendarService _calendarService;

	public MeetingsController(IMeetingService service, IGuestJitsiJoinService guestJoinService, IJitsiJoinService jitsiJoinService, ILobbyService lobbyService,	IMeetingCalendarService calendarService)
	{
		_service = service;
		_guestJitsiJoinService = guestJoinService;
		_jitsiJoinService = jitsiJoinService;
		_lobbyService = lobbyService;
		_calendarService = calendarService;
	}

	[HttpPost]
	public async Task<IActionResult> Create(CreateMeetingCommand cmd)
		=> Ok(await _service.CreateAsync(cmd));

	[HttpGet]
	public async Task<IActionResult> MyMeetings()
		=> Ok(await _service.GetMyMeetingsAsync());

	[HttpGet("{id}")]
	public async Task<IActionResult> Get(Guid id)
		=> Ok(await _service.GetByIdAsync(id));

	[HttpPut("{id}")]
	public async Task<IActionResult> Update(Guid id, UpdateMeetingCommand cmd)
		=> Ok(await _service.UpdateAsync(id, cmd));

	[HttpPost("{id}/start")]
	public async Task<IActionResult> Start(Guid id)
		=> Ok(await _service.StartAsync(id));

	[HttpPost("{id}/end")]
	public async Task<IActionResult> End(Guid id)
		=> Ok(await _service.EndAsync(id));

	//[HttpPost("{id}/join")]
	//[AllowAnonymous]
	//public async Task<IActionResult> Join(Guid id)
	//{
	//	var result = await _jitsiJoinService.JoinAsync(id);
	//	return Ok(result);
	//}

	[HttpPost("{roomName}/join")]
	[AllowAnonymous]
	public async Task<IActionResult> Join(string roomName)
	{
		var result = await _jitsiJoinService.JoinAsync(roomName);
		return Ok(result);
	}


	//[HttpGet("{id}/calendar")]
	//[AllowAnonymous]
	//public async Task<IActionResult> DownloadCalendar(Guid id)
	//{
	//	var file = await _calendarService.GenerateCalendarAsync(id);
	//	if (file == null)
	//		return NotFound();

	//	return File(
	//		file.Content,
	//		file.ContentType,
	//		file.FileName
	//	);
	//}

	[HttpGet("{roomName}/calendar")]
	[AllowAnonymous]
	public async Task<IActionResult> Calendar(string roomName)
	{
		var file = await _calendarService.GenerateCalendarAsync(roomName);
		if (file == null)
			return NotFound();

		return Ok(new { file });
	}

	[HttpGet("{roomName}/downloadcalendar")]
	[AllowAnonymous]
	public async Task<IActionResult> DownloadCalendar(string roomName)
	{
		var file = await _calendarService.GenerateCalendarAsync(roomName);

		if (file == null)
			return NotFound();

		return File(
			file.Content,
			file.ContentType,
			file.FileName
		);
	}



	//[AllowAnonymous]
	//[HttpPost("guest/join")]
	//public async Task<IActionResult> GuestJoin(GuestJoinCommand cmd)
	//	=> Ok(await _guestJitsiJoinService.JoinAsync(cmd));

	[Authorize]
	[HttpGet("{id}/lobby")]
	public async Task<IActionResult> Lobby(Guid id)
		=> Ok(await _lobbyService.GetWaitingAsync(id));

	[Authorize]
	[HttpPost("{id}/lobby/{participantId}/admit")]
	public async Task<IActionResult> Admit(Guid id, Guid participantId)
		=> Ok(await _lobbyService.AdmitAsync(id, participantId));

	[Authorize]
	[HttpPost("{id}/lobby/{participantId}/reject")]
	public async Task<IActionResult> Reject(Guid id, Guid participantId)
		=> Ok(await _lobbyService.RejectAsync(id, participantId));


	[AllowAnonymous]
	[HttpPost("guest/join/jitsi")]
	public async Task<IActionResult> GuestJoinJitsi(GuestJoinJitsiCommand cmd)
		=> Ok(await _guestJitsiJoinService.JoinAsync(cmd));

	[AllowAnonymous]
	[HttpPost("guest/join")]
	public async Task<IActionResult> GuestJoin(GuestJoinCommand cmd)
	{
		var result = await _guestJitsiJoinService.CreateParticipantAsync(cmd);
		return Ok(result);
	}

	[AllowAnonymous]
	[HttpGet("status/{roomName}")]
	public async Task<IActionResult> GetStatus(string roomName)
	{
		var result = await _service.GetMeetingStatusByRoomNameAsync(roomName);
		return Ok(result);
	}



}
