﻿using Meet.API.Hubs;
using Meet.Application.Meetings;
using Microsoft.AspNetCore.SignalR;

namespace Meet.API.SignalR;

public class LobbyNotifier : ILobbyNotifier
{
	private readonly IHubContext<LobbyHub> _hub;

	public LobbyNotifier(IHubContext<LobbyHub> hub)
	{
		_hub = hub;
	}

	public Task NotifyLobbyUpdated(Guid meetingId)
		=> _hub.Clients.Group($"lobby-{meetingId}")
			.SendAsync("LobbyUpdated");

	public Task NotifyGuestApproved(Guid participantId)
		=> _hub.Clients.Group($"guest-{participantId}")
			.SendAsync("Approved");

	public Task NotifyGuestRejected(Guid participantId)
		=> _hub.Clients.Group($"guest-{participantId}")
			.SendAsync("Rejected");
}
