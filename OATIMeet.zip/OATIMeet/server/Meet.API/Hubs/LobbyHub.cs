﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace Meet.API.Hubs;

[Authorize] // host side will be authorized
public class LobbyHub : Hub
{
	
	public async Task LeaveMeetingLobby(string meetingId)
	{
		await Groups.RemoveFromGroupAsync(
			Context.ConnectionId,
			$"lobby-{meetingId}"
		);
	}

	
	public Task JoinMeetingLobby(string meetingId)
		   => Groups.AddToGroupAsync(Context.ConnectionId, $"lobby-{meetingId}");

	public Task JoinGuestChannel(string participantId)
		=> Groups.AddToGroupAsync(Context.ConnectionId, $"guest-{participantId}");
}
