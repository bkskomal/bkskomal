import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";

import Login from "./pages/Login";
import Signup from "./pages/Signup";
import GuestJoin from "./pages/GuestJoin";

import Home from "./pages/Home";
import PublicHome from "./pages/PublicHome";
import Dashboard from "./pages/Dashboard";
import MeetingRoom from "./pages/MeetingRoom";
import Settings from "./pages/Settings";

import AppLayout from "./layouts/AppLayout";

export default function App() {
  return (
    <BrowserRouter>
        <Routes>
        {/* Public entry */}
        <Route path="/" element={<PublicHome />} />

        {/* Auth pages */}
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/guest" element={<GuestJoin />} />


       <Route path="/room/:roomName" element={<MeetingRoom />} />
        
        {/* Authenticated app */}
        <Route
          path="/app"
          element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }
        >

         
          <Route path="home" element={<Home />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>

    </BrowserRouter>
  );
}
