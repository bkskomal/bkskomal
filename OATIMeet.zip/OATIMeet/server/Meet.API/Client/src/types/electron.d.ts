export {};

declare global {
  interface Window {
    electronAPI?: {
      openOutlookEvent: (ics: string) => void;
      openOutlook: () => void;
    };
  }
}
