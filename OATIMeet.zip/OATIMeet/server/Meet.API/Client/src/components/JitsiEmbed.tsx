import { useEffect, useRef } from "react";
import { getConfig } from "../config/env";
import { loadJitsiScript } from "../utils/loadJitsi";

declare global {
  interface Window {
    JitsiMeetExternalAPI: any;
  }
}

type Props = {
  roomName: string;
};

export default function JitsiEmbed({ roomName }: Props) {

  const ref = useRef<HTMLDivElement>(null);
  const apiRef = useRef<any>(null);

  const { jitsiServerBaseUrl } = getConfig();

  useEffect(() => {

    let disposed = false;

    async function startMeeting() {

      if (!ref.current) return;

      // prevent duplicate iframe
      if (apiRef.current) return;

      await loadJitsiScript();

      if (!window.JitsiMeetExternalAPI) {
        console.error("Jitsi API not available");
        return;
      }

      const guestName = localStorage.getItem("guestName");

      const api = new window.JitsiMeetExternalAPI(
        jitsiServerBaseUrl,
        {
          roomName,
          parentNode: ref.current,
          width: "100%",
          height: "100%",

          configOverwrite: {
            prejoinPageEnabled: false
          },

          userInfo: {
            displayName: guestName || "Guest"
          }
        }
      );

      apiRef.current = api;

      if (disposed) {
        api.dispose();
      }

    }

    startMeeting();

    return () => {
      disposed = true;

      if (apiRef.current) {
        apiRef.current.dispose();
        apiRef.current = null;
      }
    };

  }, [roomName]);

  return (
    <div
      ref={ref}
      style={{
        width: "100%",
        height: "100%",
        background: "#000"
      }}
    />
  );
}