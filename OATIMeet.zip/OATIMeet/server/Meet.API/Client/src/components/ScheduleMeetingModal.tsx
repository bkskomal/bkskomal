import { useState } from "react";
import api from "../api/axios";
import { API_BASE } from "../config/env";
import "./ScheduleMeetingModal.css";

type Props = {
  onClose: () => void;
};

export default function ScheduleMeetingModal({ onClose }: Props) {

  const [title, setTitle] = useState("");
  const [dateTime, setDateTime] = useState("");
  const [duration, setDuration] = useState(60);
  const [reminder, setReminder] = useState(10);
  const [recurring, setRecurring] = useState(false);
  const [enableLobby, setEnableLobby] = useState(true);
  const [loading, setLoading] = useState(false);

  async function saveMeeting() {

    if (!title.trim() || !dateTime) {
      alert("Please enter title and date");
      return;
    }

    setLoading(true);

    try {

      const res = await api.post("/meetings", {
        title,
        scheduledTimeUtc: new Date(dateTime).toISOString(),
        durationMinutes: duration,
        reminderMinutes: reminder,
        recurring,
        enableLobby
      });

      const roomName = res.data.data.roomName;

      const calendar = await api.get(`/meetings/${roomName}/calendar`);

      if (window.electronAPI) {
        await window.electronAPI.openOutlookEvent(calendar.data);
      } else {
        window.open(`${API_BASE}/meetings/${roomName}/downloadcalendar`);
      }

      onClose();

    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal-backdrop">

      <div className="modal scheduler-modal">

        <h2>Schedule Meeting</h2>

        {/* TITLE */}

        <div className="form-group">
          <label>Meeting Title</label>
          <input
            placeholder="Enter meeting title"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
        </div>

        {/* DATE TIME */}

        <div className="form-group">
          <label>Date & Time</label>
          <input
            type="datetime-local"
            value={dateTime}
            onChange={e => setDateTime(e.target.value)}
          />
        </div>

        {/* ROW CONTROLS */}

        <div className="form-row">

          <div className="form-group">
            <label>Duration</label>
            <select
              value={duration}
              onChange={e => setDuration(Number(e.target.value))}
            >
              <option value={30}>30 mins</option>
              <option value={60}>1 hour</option>
              <option value={90}>1.5 hours</option>
              <option value={120}>2 hours</option>
            </select>
          </div>

          <div className="form-group">
            <label>Reminder</label>
            <select
              value={reminder}
              onChange={e => setReminder(Number(e.target.value))}
            >
              <option value={5}>5 mins</option>
              <option value={10}>10 mins</option>
              <option value={15}>15 mins</option>
              <option value={30}>30 mins</option>
            </select>
          </div>

        </div>

        {/* CHECKBOXES */}

        <div className="form-row">

          <label>
            <input
              type="checkbox"
              checked={recurring} style={{ height: 25 }}
              onChange={e => setRecurring(e.target.checked)}
            />
            Recurring meeting
          </label>

          <label>
            <input
              type="checkbox"
              checked={enableLobby} style={{ height: 25 }}
              onChange={e => setEnableLobby(e.target.checked)}
            />
            Enable waiting room
          </label>

        </div>

        {/* ACTIONS */}

        <div className="modal-actions">

          <button onClick={onClose}>
            Cancel
          </button>

          <button
            className="primary"
            onClick={saveMeeting}
            disabled={loading}
          >
            {loading ? "Saving..." : "Save"}
          </button>

        </div>

      </div>

    </div>
  );
}