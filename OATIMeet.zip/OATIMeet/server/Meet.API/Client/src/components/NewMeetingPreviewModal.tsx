import { useEffect, useRef, useState } from "react";
import api from "../api/axios";
import { openMeetingWindow } from "../utils/meetingWindow";
import "./NewMeetingPreviewModal.css";
import { waitForMeetingReady } from "../utils/waitForMeetingReady";

type Props = {
  onClose: () => void;
  isJoinMode?: boolean;
  meetingTitle?: string;
};

export default function NewMeetingPreviewModal({
  onClose,
  isJoinMode = false,
  meetingTitle
}: Props) {

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [cameraId, setCameraId] = useState("");
  const [micId, setMicId] = useState("");

  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [micEnabled, setMicEnabled] = useState(true);

  const [meetingName, setMeetingName] = useState("");
  const [loading, setLoading] = useState(false);

  const [errorMessage, setErrorMessage] = useState("");

  /* LOAD DEVICES */

  useEffect(() => {
    async function loadDevices() {
      const mediaDevices = await navigator.mediaDevices.enumerateDevices();
      setDevices(mediaDevices);

      const cam = mediaDevices.find(d => d.kind === "videoinput");
      const mic = mediaDevices.find(d => d.kind === "audioinput");

      if (cam) setCameraId(cam.deviceId);
      if (mic) setMicId(mic.deviceId);
    }

    loadDevices();
  }, []);

  /* PREVIEW STREAM */

  useEffect(() => {

    async function startPreview() {

      try {

        stopStream();

        const stream = await navigator.mediaDevices.getUserMedia({
          video: cameraEnabled
            ? { deviceId: cameraId ? { exact: cameraId } : undefined }
            : false,
          audio: micEnabled
            ? { deviceId: micId ? { exact: micId } : undefined }
            : false
        });

        streamRef.current = stream;

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }

      } catch (err) {
        console.error("Preview failed", err);
      }

    }

    startPreview();

    return () => stopStream();

  }, [cameraId, micId, cameraEnabled, micEnabled]);

  function stopStream() {
    streamRef.current?.getTracks().forEach(track => track.stop());
    streamRef.current = null;
  }

  /* ROOM NAME */

  function generateRoomName() {
    return meetingName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "");
  }

  /* JOIN MEETING */

 async function joinMeeting() {

  if (!meetingName.trim()) {
    setErrorMessage("Please enter meeting name");
    return;
  }

  setLoading(true);

  try {

    const room = generateRoomName();

    const ready = await waitForMeetingReady(room);

    if (!ready) {
      setErrorMessage("Meeting is not active");
      return;
    }

    stopStream();

    openMeetingWindow(room);

    onClose();

  } catch (err) {

    console.error(err);
    setErrorMessage("Unable to join meeting");

  } finally {

    setLoading(false);

  }

}

  /* CREATE MEETING */

  async function handleStartMeeting() {

  if (!meetingName.trim()) {
    setErrorMessage("Please enter meeting name");
    return;
  }

  setLoading(true);

  try {

    stopStream();

    const roomName = generateRoomName();

    const res = await api.post("/meetings", {
      title: meetingName,
      roomName: roomName,
      allowGuests: true,
      enableLobby: true,
      scheduledTimeUtc: new Date().toISOString()
    });

    const created = res.data?.data;

    if (!created?.roomName) {
      throw new Error("Meeting creation failed");
    }

    const ready = await waitForMeetingReady(created.roomName);

    if (!ready) {
      setErrorMessage("Meeting failed to start");
      return;
    }

    openMeetingWindow(created.roomName);

    onClose();

  } catch (err) {

    console.error("Start meeting failed", err);
    setErrorMessage("Unable to start meeting");

  } finally {

    setLoading(false);

  }

}

  const cameras = devices.filter(d => d.kind === "videoinput");
  const mics = devices.filter(d => d.kind === "audioinput");

  return (
    <div className="modal-backdrop">

      <div className="preview-modal">

        <h2>{meetingTitle ?? (isJoinMode ? "Join Meeting" : "Create Meeting")}</h2>

        {/* ERROR POPUP */}

        {errorMessage && (
          <div className="error-popup">
            <p>{errorMessage}</p>
            <button onClick={() => setErrorMessage("")}>OK</button>
          </div>
        )}

        {/* MEETING NAME */}

        <div className="meeting-name-field">

          <label>Meeting Name</label>

          <input
            type="text"
            placeholder="Enter meeting name"
            value={meetingName}
            onChange={(e) => setMeetingName(e.target.value)}
          />

        </div>
           {/* TOGGLES */}

        <div className="preview-toggles">

          <label>
            <input
              type="checkbox"
              checked={cameraEnabled}
              onChange={e => setCameraEnabled(e.target.checked)} style={{ height: 25 }}
            />
            Camera
          </label>

          <label>
            <input
              type="checkbox"
              checked={micEnabled}
              onChange={e => setMicEnabled(e.target.checked)} style={{ height: 25 }}
            />
            Microphone
          </label>

        </div>

        {/* VIDEO */}

        <div className="preview-video-container">

          {cameraEnabled ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="preview-video"
            />
          ) : (
            <div className="camera-off">Camera Off</div>
          )}

        </div>

        {/* DEVICE SELECT */}

        <div className="preview-controls">

          <div className="control-group">

            <label>Camera</label>

            <select
              value={cameraId}
              onChange={e => setCameraId(e.target.value)}
              disabled={!cameraEnabled}
            >
              {cameras.map(cam => (
                <option key={cam.deviceId} value={cam.deviceId}>
                  {cam.label || "Camera"}
                </option>
              ))}
            </select>

          </div>

          <div className="control-group">

            <label>Microphone</label>

            <select
              value={micId}
              onChange={e => setMicId(e.target.value)}
              disabled={!micEnabled}
            >
              {mics.map(mic => (
                <option key={mic.deviceId} value={mic.deviceId}>
                  {mic.label || "Microphone"}
                </option>
              ))}
            </select>

          </div>

        </div>

     

        {/* ACTIONS */}

        <div className="modal-actions">

          <button onClick={onClose}>
            Cancel
          </button>

          <button
            className="primary"
            onClick={() => {
              if (isJoinMode) {
                joinMeeting();
              } else {
                handleStartMeeting();
              }
            }}
            disabled={loading}
          >
            {loading ? "Starting..." : isJoinMode ? "Join" : "Start"}
          </button>

        </div>

      </div>

    </div>
  );
}