import { useState } from "react";
import NewMeetingPreviewModal from "./NewMeetingPreviewModal";
import "./JoinMeetingModal.css";

type Props = {
  onClose: () => void;
  displayName?: string;
};

export default function JoinMeetingModal({ onClose, displayName }: Props) {

  const [meetingCode, setMeetingCode] = useState("");
  const [name, setName] = useState(displayName || "");

  const [showPreview, setShowPreview] = useState(false);
  const [error, setError] = useState("");

  function nextStep() {

    if (!meetingCode.trim()) {
      setError("Enter meeting code");
      return;
    }

    if (!name.trim()) {
      setError("Enter your name");
      return;
    }

    setError("");

    setShowPreview(true);
  }


  if (showPreview) {
    return (
      <NewMeetingPreviewModal
        onClose={() => setShowPreview(false)}
        isJoinMode={true}
        meetingTitle={meetingCode}
      />
    );
  }

  return (
    <div className="modal-backdrop">
      <div className="modal">

        <h2>Join Meeting</h2>

        <div className="field">
          <label>Meeting Code</label>

          <input
            autoFocus
            placeholder="Enter meeting code"
            value={meetingCode}
            onChange={(e) => setMeetingCode(e.target.value)}
          />
        </div>

        <div className="field">
          <label>Your Name</label>

          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        {error && <p className="error-text">{error}</p>}

        <div className="modal-actions">

          <button onClick={onClose}>
            Cancel
          </button>

          <button
            className="primary"
            onClick={nextStep}
          >
            Next
          </button>

        </div>

      </div>
    </div>
  );
}