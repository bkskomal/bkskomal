type Props = {
  label: string;
  icon?: "video" | "plus" | "calendar" | "share";
  color?: "orange" | "blue";
  disabled?: boolean;
  onClick?: () => void;
};

export default function ActionButton({
  label,
  icon,
  color = "blue",
  disabled,
  onClick
}: Props) {
  return (
    <button
      className={`action-btn ${color}`}
      disabled={disabled}
      onClick={onClick}
    >
      <div className={`icon ${icon}`} />
      <span>{label}</span>
    </button>
  );
}
