import { startOfWeek, addDays, format } from "date-fns";
import "./WeekCalendar.css";

type Props = {
  meetings: any[];
  onCreate: () => void;
};

export default function WeekCalendar({ meetings, onCreate }: Props) {
  const start = startOfWeek(new Date(), { weekStartsOn: 1 });
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i));

  return (
    <div className="week-calendar">
      {days.map(day => (
        <div key={day.toISOString()} className="day-column">
          <div className="day-header">
            {format(day, "EEE")}
            <span>{format(day, "d")}</span>
          </div>

          <div className="day-body">
            {meetings
              .filter(m =>
                new Date(m.scheduledTimeUtc).toDateString() ===
                day.toDateString()
              )
              .map(m => (
                <div key={m.meetingId} className="calendar-item">
                  {format(new Date(m.scheduledTimeUtc), "HH:mm")} – {m.title}
                </div>
              ))}

            <button className="add-slot" onClick={onCreate}>
              +
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
