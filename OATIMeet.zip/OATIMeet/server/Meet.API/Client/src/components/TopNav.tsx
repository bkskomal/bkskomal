import { NavLink } from "react-router-dom";
import { logout } from "../utils/auth";

export default function TopNav() {
  return (
    <div className="top-nav">
      <div className="brand">Meet</div>

      <nav className="nav-links">
        <NavLink to="/app/home">Home</NavLink>
        <NavLink to="/app/dashboard">Dashboard</NavLink>
        <NavLink to="/app/settings">Settings</NavLink>
      </nav>

      <button className="logout" onClick={logout}>
        Sign out
      </button>
    </div>
  );
}
