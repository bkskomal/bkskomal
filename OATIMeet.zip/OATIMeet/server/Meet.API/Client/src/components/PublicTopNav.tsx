import { useNavigate } from "react-router-dom";

export default function PublicTopNav() {
  const navigate = useNavigate();

  return (
    <div className="top-nav">
      <div className="brand">Meet</div>

      <div className="nav-links">
        <span className="active">Home</span>
      </div>

      <button className="nav-btn" onClick={() => navigate("/login")}>
        Sign In
      </button>
    </div>
  );
}
