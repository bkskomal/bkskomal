import { useEffect, useState } from "react";
import api from "../api/axios";
import { API_BASE, APP_BASE_URL } from "../config/env";
import { openMeetingWindow } from "../utils/meetingWindow";

type Props = {
  onClose: () => void;

  /** ✅ NEW: tells modal if opened from Schedule button */
  defaultSchedule?: boolean;
};

type CreatedMeeting = {
  meetingId: string;
  meetingCode: string;
  title: string;
  scheduledTimeUtc?: string;
};

export default function CreateMeetingModal({
  onClose,
  defaultSchedule = false
}: Props) {
  const [title, setTitle] = useState("");

  const [allowGuests, setAllowGuests] = useState(true);
  const [enableLobby, setEnableLobby] = useState(true);

  /** ⭐ Scheduling */
  const [scheduleEnabled, setScheduleEnabled] = useState(defaultSchedule);
  const [scheduledAt, setScheduledAt] = useState("");

  /** ⭐ Duration & Reminder */
  const [duration, setDuration] = useState(60);
  const [reminder, setReminder] = useState(10);

  const [created, setCreated] = useState<CreatedMeeting | null>(null);
  const [loading, setLoading] = useState(false);

  /* ✅ Default datetime (now + 30 mins) */
  useEffect(() => {
    const now = new Date();
    now.setMinutes(now.getMinutes() + 30);

    const localISO = now.toISOString().slice(0, 16);
    setScheduledAt(localISO);
  }, []);

  async function createMeeting() {
    if (!title.trim()) {
      alert("Please enter meeting title");
      return;
    }

    setLoading(true);

    try {
      const payload: any = {
        title,
        allowGuests,
        enableLobby,
        durationMinutes: duration,
        reminderMinutes: reminder
      };

      if (scheduleEnabled && scheduledAt) {
        payload.scheduledTimeUtc = new Date(scheduledAt).toISOString();
      }

      const res = await api.post("/meetings", payload);
      setCreated(res.data.data);
    } catch (err) {
      console.error("Meeting creation failed", err);
      alert("Unable to create meeting");
    } finally {
      setLoading(false);
    }
  }

  function copy(text: string) {
    navigator.clipboard?.writeText(text);
  }

  /* ===================== SUCCESS UI ===================== */

  if (created) {
    const meetingLink = `${APP_BASE_URL}/meeting/${created.meetingId}`;

    return (
      <div className="modal-backdrop">
        <div className="modal">
          <h2>Meeting Scheduled</h2>

          <div className="success-box">
            <div className="field">
              <label>Meeting Code</label>
              <div className="row">
                <code>{created.meetingCode}</code>
                <button onClick={() => copy(created.meetingCode)}>
                  Copy
                </button>
              </div>
            </div>

            <div className="field">
              <label>Meeting Link</label>
              <div className="row">
                <code className="link">{meetingLink}</code>
                <button onClick={() => copy(meetingLink)}>
                  Copy
                </button>
              </div>
            </div>

            {created.scheduledTimeUtc && (
              <div className="field">
                <label>Scheduled For</label>
                <div className="row">
                  <span>
                    {new Date(created.scheduledTimeUtc).toLocaleString()}
                  </span>
                </div>
              </div>
            )}

            <div className="share-actions">
              <button
                onClick={async () => {
                  const res = await api.get(
                    `/meetings/${created.meetingId}/calendar`
                  );

                  if (window.electronAPI) {
                    await window.electronAPI.openOutlookEvent(res.data);
                  } else {
                    window.open(
                      `${API_BASE}/meetings/${created.meetingId}/calendar`,
                      "_blank"
                    );
                  }
                }}
              >
                Open in Outlook
              </button>

              <button
                onClick={() => {
                  const body = encodeURIComponent(
                    `You're invited to a meeting.\n\nMeeting Code: ${created.meetingCode}\n\n${meetingLink}`
                  );

                  window.location.href =
                    `mailto:?subject=${encodeURIComponent(
                      created.title
                    )}&body=${body}`;
                }}
              >
                Share via Email
              </button>
            </div>
          </div>

          <div className="modal-actions">
            <button onClick={onClose}>Close</button>

            <button
              className="primary"
              onClick={() => openMeetingWindow(created.meetingId)}
            >
              Start Meeting
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ===================== CREATE FORM ===================== */

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <h2>{scheduleEnabled ? "Schedule Meeting" : "New Meeting"}</h2>

        <div className="field">
          <label>Meeting Title</label>
          <input
            placeholder="Enter meeting title"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
        </div>

        {/* ⭐ Schedule Toggle */}
        <label className="checkbox-row">
          <input
            type="checkbox"
            checked={scheduleEnabled}
            onChange={e => setScheduleEnabled(e.target.checked)}
          />
          Schedule for later
        </label>

        {scheduleEnabled && (
          <div className="schedule-grid">
            <div className="field">
              <label>Date & Time</label>
              <input
                type="datetime-local"
                value={scheduledAt}
                onChange={e => setScheduledAt(e.target.value)}
              />
            </div>

            <div className="field">
              <label>Duration</label>
              <select
                value={duration}
                onChange={e => setDuration(Number(e.target.value))}
              >
                <option value={30}>30 minutes</option>
                <option value={60}>1 hour</option>
                <option value={90}>1.5 hours</option>
                <option value={120}>2 hours</option>
              </select>
            </div>

            <div className="field">
              <label>Reminder</label>
              <select
                value={reminder}
                onChange={e => setReminder(Number(e.target.value))}
              >
                <option value={5}>5 minutes before</option>
                <option value={10}>10 minutes before</option>
                <option value={30}>30 minutes before</option>
              </select>
            </div>
          </div>
        )}

        <label className="checkbox-row">
          <input
            type="checkbox"
            checked={allowGuests}
            onChange={e => setAllowGuests(e.target.checked)}
          />
          Allow guests
        </label>

        <label className="checkbox-row">
          <input
            type="checkbox"
            checked={enableLobby}
            onChange={e => setEnableLobby(e.target.checked)}
          />
          Enable waiting room
        </label>

        <div className="modal-actions">
          <button onClick={onClose}>Cancel</button>

          <button
            className="primary"
            onClick={createMeeting}
            disabled={loading}
          >
            {loading
              ? "Saving..."
              : scheduleEnabled
              ? "Save Meeting"
              : "Create Meeting"}
          </button>
        </div>
      </div>
    </div>
  );
}
