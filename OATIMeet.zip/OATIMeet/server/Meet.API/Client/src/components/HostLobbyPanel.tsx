import { useEffect, useState } from "react";
import api from "../api/axios";
import "./HostLobbyPanel.css";

type Props = {
  meetingId: string;
};

type Participant = {
  participantId: string;
  displayName: string;
};

export default function HostLobbyPanel({ meetingId }: Props) {
  const [waiting, setWaiting] = useState<Participant[]>([]);

  async function load() {
    const res = await api.get(`/meetings/${meetingId}/lobby`);
    setWaiting(res.data.data ?? []);
  }

  async function admit(id: string) {
    await api.post(`/meetings/${meetingId}/lobby/${id}/admit`);
    load();
  }

  async function reject(id: string) {
    await api.post(`/meetings/${meetingId}/lobby/${id}/reject`);
    load();
  }

  useEffect(() => {
    load();
    const timer = setInterval(load, 3000); // simple polling (SignalR later)
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="lobby-panel">
      <h3>Waiting Room</h3>

      {waiting.length === 0 ? (
        <p className="muted">No one waiting</p>
      ) : (
        waiting.map(p => (
          <div key={p.participantId} className="lobby-row">
            <span>{p.displayName}</span>
            <div>
              <button onClick={() => admit(p.participantId)}>Admit</button>
              <button className="danger" onClick={() => reject(p.participantId)}>
                Reject
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
