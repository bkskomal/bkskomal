import * as signalR from "@microsoft/signalr";

export function createLobbyConnection(token: string) {
  return new signalR.HubConnectionBuilder()
    .withUrl("http://localhost:5000/hubs/lobby", {
      accessTokenFactory: () => token
    })
    .withAutomaticReconnect()
    .build();
}
