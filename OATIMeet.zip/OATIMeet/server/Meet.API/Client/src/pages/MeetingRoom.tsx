import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../api/axios";
import JitsiEmbed from "../components/JitsiEmbed";
import HostLobbyPanel from "../components/HostLobbyPanel";
import WaitingRoom from "./WaitingRoom";
import "./MeetingRoom.css";

type JoinInfo = {
  roomName: string;
  isHost: boolean;
  waitingForApproval: boolean;
};

export default function MeetingRoom() {

  const { meetingId } = useParams<{ meetingId: string }>();
  const { roomName } = useParams<{ roomName: string }>();

  const [joinInfo, setJoinInfo] = useState<JoinInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {

    if (!roomName) {
      setError("Invalid meeting link");
      setLoading(false);
      return;
    }

    let cancelled = false;

    async function loadJoinInfo() {

      const guestName = localStorage.getItem("guestName");

      // retry up to 5 times (handles DB commit delay)
      for (let attempt = 0; attempt < 5; attempt++) {

        try {

          const res = await api.post(`/meetings/${roomName}/join`, {
            guestName
          });

          const payload = res.data?.data ?? res.data;

          if (!cancelled) {
            setJoinInfo(payload);
            setLoading(false);
          }

          return;

        } catch (err) {

          console.warn(`Join attempt ${attempt + 1} failed`);

          if (attempt === 4) {
            if (!cancelled) {
              setError("Unable to join meeting");
              setLoading(false);
            }
            return;
          }

          // wait before retry
          await new Promise(r => setTimeout(r, 400));
        }
      }
    }

    loadJoinInfo();

    return () => {
      cancelled = true;
    };

  }, [roomName]);

  /* ---------------- STATES ---------------- */

  if (loading) {
     return (
    <div className="meeting-loading">
      <div className="spinner"></div>
      <p>Joining meeting…</p>
      </div>
    );
  }

  if (error || !joinInfo) {
    return <div className="meeting-error">{error || "Join failed"}</div>;
  }

  /* ---------------- WAITING ROOM ---------------- */

  if (joinInfo.waitingForApproval) {
    return (
      <WaitingRoom
        roomName={joinInfo.roomName}
      />
    );
  }

  /* ---------------- MEETING UI ---------------- */

  return (
    <div className="meeting-layout">

      <div className="meeting-video">
        <JitsiEmbed roomName={joinInfo.roomName} />
      </div>

      {joinInfo.isHost && (
        <div className="meeting-lobby">
          <HostLobbyPanel meetingId={meetingId!} />
        </div>
      )}

    </div>
  );
}