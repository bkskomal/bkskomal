import { useEffect, useState } from "react";
import api from "../api/axios";

type Meeting = {
  meetingId: string;
  title: string;
  scheduledTimeUtc: string;
  status: string;
};

export default function Dashboard() {
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadMeetings() {
      try {
        const res = await api.get("/meetings");
        setMeetings(res.data);
      } catch {
        setMeetings([]);
      } finally {
        setLoading(false);
      }
    }

    loadMeetings();
  }, []);

  if (loading) {
    return <div className="page">Loading meetings...</div>;
  }

  return (
    <div className="page">
      <h2>Meetings</h2>

      {meetings.length === 0 ? (
        <div className="empty-state">
          <p>No meetings yet.</p>
          <p>Create a meeting from the Home tab.</p>
        </div>
      ) : (
        <div className="meeting-list">
          {meetings.map(m => (
            <div key={m.meetingId} className="meeting-card">
              <h4>{m.title}</h4>
              <p>{new Date(m.scheduledTimeUtc).toLocaleString()}</p>
              <span className="status">{m.status}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
