import { useState } from "react";
import { login } from "../api/auth.api";
import { useNavigate, Link } from "react-router-dom";

export default function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  async function submit(e?: React.FormEvent) {

    if (e) e.preventDefault(); // prevent page refresh

    try {

      setLoading(true);

      await login(email, password);

      navigate("/app/home");

    } finally {

      setLoading(false);

    }

  }

  return (

    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}
    >

      <div className="card" style={{ width: 380 }}>

        <h2 style={{ marginBottom: 20 }}>Sign in</h2>

        {/* FORM enables Enter key login */}
        <form onSubmit={submit}>

          <input
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
          />

          <button
            type="submit"
            style={{ width: "100%", marginTop: 8 }}
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>

        </form>

        {/* Divider */}
        <div
          style={{
            textAlign: "center",
            margin: "10px 0",
            color: "#777",
            fontSize: 13
          }}
        >
        </div>

        {/* Back */}
        <button
          className="secondary"
          style={{ width: "100%" }}
          onClick={() => navigate("/")}
        >
          Back to Home
        </button>

        <p style={{ marginTop: 16, fontSize: 14 }}>
          New here? <Link to="/signup">Create an account</Link>
        </p>

      </div>

    </div>
  );
}