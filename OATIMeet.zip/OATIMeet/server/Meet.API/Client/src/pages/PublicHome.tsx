import { useState } from "react";
import { useNavigate } from "react-router-dom";
import NewMeetingPreviewModal from "../components/NewMeetingPreviewModal";

export default function PublicHome() {

  const navigate = useNavigate();

  const [showJoin, setShowJoin] = useState(false);

  return (
    <>
      <div className="public-home">

        <div className="public-center">

          <h1 className="brand">OATIMeet</h1>

          <div className="public-actions">

            <button
              className="secondary"
              onClick={() => setShowJoin(true)}
            >
              Join a Meeting
            </button>

            <button
              className="primary"
              onClick={() => navigate("/login")}
            >
              Sign In
            </button>
         <button
              className="primary"
              onClick={() => navigate("/signup")}
            >
              Sign Up
            </button>
          </div>

        </div>

      </div>

      {/* Join Meeting Modal */}

      {showJoin && (
        <NewMeetingPreviewModal
          isJoinMode={true}
          meetingTitle="Join Meeting"
          onClose={() => setShowJoin(false)}
        />
      )}

    </>
  );
}