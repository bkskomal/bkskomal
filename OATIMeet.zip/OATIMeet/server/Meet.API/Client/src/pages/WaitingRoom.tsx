import { useEffect, useState } from "react";
import api from "../api/axios";
import "./WaitingRoom.css";

type Props = {
  roomName: string;
};

export default function WaitingRoom({  roomName }: Props) {
  const [status, setStatus] = useState<
    "waiting" | "approved" | "rejected"
  >("waiting");

  roomName = roomName || "DefaultRoom"; // fallback if roomName is missing  
  useEffect(() => {
    // 🔔 Poll or SignalR later (polling for now)
    const interval = setInterval(async () => {
      try {
        const res = await api.get(
          `/meetings/${roomName}/waiting-status`
        );

        if (res.data.status === "approved") {
          setStatus("approved");
          clearInterval(interval);

          // 🔹 Join meeting
          window.location.href = `/meeting/${roomName}`;
        }

        if (res.data.status === "rejected") {
          setStatus("rejected");
          clearInterval(interval);
        }
      } catch {
        // ignore transient errors
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [roomName]);

  return (
    <div className="waiting-room">
      {status === "waiting" && (
        <>
          <h2>Waiting for host approval</h2>
          <p>Please stay on this page</p>
        </>
      )}

      {status === "rejected" && (
        <>
          <h2>Not admitted</h2>
          <p>The host rejected your request</p>
        </>
      )}
    </div>
  );
}
