export default function GuestDashboard() {
  return (
    <div className="center-container">
      <div className="card" style={{ maxWidth: 420 }}>
        <h2>Waiting for host</h2>
        <p>
          You’ll be able to join once the host admits you.
        </p>

        <div style={{ marginTop: 20 }}>
          <span className="spinner" /> Waiting…
        </div>
      </div>
    </div>
  );
}
