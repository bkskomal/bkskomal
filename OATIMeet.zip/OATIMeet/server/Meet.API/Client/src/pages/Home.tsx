import { useEffect, useState, useRef } from "react";
import ActionButton from "../components/ActionButton";
import ScheduleMeetingModal from "../components/ScheduleMeetingModal";
import NewMeetingPreviewModal from "../components/NewMeetingPreviewModal";
import api from "../api/axios";
import { openMeetingWindow } from "../utils/meetingWindow";
import { loadJitsiScript } from "../utils/loadJitsi";
import { getConfig } from "../config/env";

import "./Home.css";

type Meeting = {
  meetingId: string;
  meetingCode?: string;
  title: string;
  scheduledTimeUtc: string;
  status: string;
};

const PAGE_SIZE = 6;

export default function Home() {

  const [now, setNow] = useState(new Date());

  const [showPreview, setShowPreview] = useState(false);
  const [showSchedule, setShowSchedule] = useState(false);
  const [isJoinMode, setIsJoinMode] = useState(false);

  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter] = useState<"upcoming" | "past">("upcoming");

  const [page, setPage] = useState(1);
  const [activeMeeting] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);

  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  const menuRef = useRef<HTMLDivElement | null>(null);

  const [copied, setCopied] = useState(false);

  const { jitsiServerBaseUrl } =  getConfig();

  /* ---------------- CLOCK ---------------- */

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {

  if ("requestIdleCallback" in window) {

    requestIdleCallback(() => {
      loadJitsiScript().catch(() => {});
    });

  } else {

    setTimeout(() => {
      loadJitsiScript().catch(() => {});
    }, 2000);

  }

}, []);

  /* ---------------- LOAD MEETINGS ---------------- */

  useEffect(() => {

    async function loadMeetings() {

      try {

        const res = await api.get("/meetings");
        const list = res.data?.data;

        setMeetings(Array.isArray(list) ? list : []);

      } catch (err) {

        console.error("Failed to load meetings", err);
        setMeetings([]);

      } finally {

        setLoading(false);

      }

    }

    loadMeetings();

  }, []);

  /* ---------------- PAGE RESET ---------------- */

  useEffect(() => {
    setPage(1);
  }, [filter, selectedDate]);

  /* ---------------- MENU CLOSE ---------------- */

  useEffect(() => {

    function handleClickOutside(event: MouseEvent) {

      if (
        menuRef.current &&
        !menuRef.current.contains(event.target as Node)
      ) {
        setMenuOpen(null);
      }

    }

    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };

  }, [menuOpen]);

  /* ---------------- HELPERS ---------------- */

  function getMeetingState(timeUtc: string) {

    const nowMs = Date.now();
    const start = new Date(timeUtc).getTime();
    const end = start + 60 * 60 * 1000;

    if (nowMs >= start && nowMs <= end) return "ongoing";
    if (start > nowMs) return "upcoming";
    return "past";

  }

  function changeDay(offset: number) {

    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + offset);
    setSelectedDate(newDate);

  }

  /* ---------------- FILTER ---------------- */

  const filteredMeetings = meetings.filter(m => {

    const meetingDate = new Date(m.scheduledTimeUtc);

    return meetingDate.toDateString() === selectedDate.toDateString();

  });

  /* ---------------- PAGING ---------------- */

  const startIndex = (page - 1) * PAGE_SIZE;

  const pagedMeetings = filteredMeetings.slice(
    startIndex,
    startIndex + PAGE_SIZE
  );

  const totalPages = Math.ceil(filteredMeetings.length / PAGE_SIZE);

  /* ---------------- UI ---------------- */

  return (
    <div className="home">

      {/* TIME */}

      <div className="home-time">

        <h1>
          {now.toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
          })}
        </h1>

        <p>
          {now.toLocaleDateString(undefined, {
            weekday: "long",
            month: "long",
            day: "numeric",
            year: "numeric"
          })}
        </p>

      </div>

      {/* RETURN BUTTON */}

      {activeMeeting && (
        <button
          className="return-button"
          onClick={() => openMeetingWindow(activeMeeting)}
        >
          ← Return to Meeting
        </button>
      )}

      {/* ACTIONS */}

      <div className="home-actions">

        <ActionButton
          label="New Meeting"
          color="orange"
          icon="video"
          onClick={() => {
            setIsJoinMode(false);
            setShowPreview(true);
          }}
        />

        <ActionButton
          label="Join"
          icon="plus"
          onClick={() => {
            setIsJoinMode(true);
            setShowPreview(true);
          }}
        />

        <ActionButton
          label="Schedule"
          icon="calendar"
          onClick={() => setShowSchedule(true)}
        />

        <ActionButton
          label="Share Screen"
          icon="share"
          disabled
        />

      </div>

      {/* HEADER */}

      <div className="card-header">

        <div className="zoom-toolbar">

          <input
            type="date"
            className="date-input"
            value={selectedDate.toISOString().slice(0, 10)}
            onChange={e =>
              setSelectedDate(
                e.target.value ? new Date(e.target.value) : new Date()
              )
            }
          />

          <button className="icon-btn" onClick={() => changeDay(-1)}>‹</button>
          <button className="icon-btn" onClick={() => changeDay(1)}>›</button>

          <button
            className="today-btn"
            onClick={() => setSelectedDate(new Date())}
          >
            Today
          </button>

        </div>

      </div>

      {/* MEETINGS */}

      <div className="home-card">

  {loading ? (
    <p className="muted">Loading meetings...</p>

  ) : filteredMeetings.length === 0 ? (

    <div className="empty">
      <p>No meetings for this day.</p>

      <button
        className="link"
        onClick={() => setShowSchedule(true)}
      >
        + Schedule a meeting
      </button>
    </div>

  ) : (

    <>
      <div className="meeting-grid">

        {pagedMeetings.map(m => {

          const state = getMeetingState(m.scheduledTimeUtc);

          return (
            <div
              key={m.meetingId}
              className={`meeting-card ${state}`}
            >

              <div className="meeting-card-header">

                <strong>{m.title}</strong>

                <button
                  className="menu-button"
                  onClick={e => {
                    e.stopPropagation();
                    setMenuOpen(
                      menuOpen === m.meetingId ? null : m.meetingId
                    );
                  }}
                >
                  ⋯
                </button>

                {menuOpen === m.meetingId && (
                  <div className="meeting-menu" ref={menuRef}>

                      <button
                          onClick={() => {

                            const meetingLink = "https://" + `${jitsiServerBaseUrl}/${m.title}`;

                            navigator.clipboard.writeText(meetingLink);

                            setMenuOpen(null);      // hide menu
                            setCopied(true);        // show modal

                            setTimeout(() => {
                              setCopied(false);
                            }, 2000);

                          }}
                        >
                          Copy Link
                        </button>

                    <button
                      onClick={() => {
                         setMenuOpen(null);  
                        openMeetingWindow(m.title)
                      }
                      }
                    >
                      Start
                    </button>

                  </div>
                )}

              </div>

             <div className="meeting-time">
                <span className="meeting-date">
                  {new Date(m.scheduledTimeUtc).toLocaleDateString([], {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                  })}
                </span>

                <span className="meeting-separator"> • </span>

                <span className="meeting-hour">
                  {new Date(m.scheduledTimeUtc).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit"
                  })}
                </span>

              </div>

            </div>
          );

        })}

      </div>

      {/* PAGING */}

      {totalPages > 1 && (
        <div className="paging">

          <button
            disabled={page === 1}
            onClick={() => setPage(p => p - 1)}
          >
            ← Prev
          </button>

          <span>
            Page {page} / {totalPages}
          </span>

          <button
            disabled={page === totalPages}
            onClick={() => setPage(p => p + 1)}
          >
            Next →
          </button>

        </div>
      )}

    </>

  )}

</div>

      {/* MODALS */}

      {showPreview && (
        <NewMeetingPreviewModal
          isJoinMode={isJoinMode}
          onClose={() => setShowPreview(false)}
        />
      )}

      {showSchedule && (
        <ScheduleMeetingModal
          onClose={() => setShowSchedule(false)}
        />
      )}
      {copied && (
        <div className="copy-toast">
          Meeting link copied
        </div>
      )}
    </div>
  );
}