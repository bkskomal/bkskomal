import { useState } from "react";
import * as signalR from "@microsoft/signalr";
import { guestJoin, joinJitsi } from "../api/guest.api";

type GuestState =
  | "form"
  | "joining"
  | "waiting"
  | "approved"
  | "rejected"
  | "error";

export default function GuestJoin() {
  const [meetingCode, setMeetingCode] = useState("");
  const [name, setName] = useState("");
  const [state, setState] = useState<GuestState>("form");
  const [message, setMessage] = useState("");

  async function submit() {
    try {
      setState("joining");

      const result = await guestJoin(meetingCode, name);

      if (!result.waitingForApproval) {
        await handleApproved(result.meetingId, result.participantId);
        return;
      }

      setState("waiting");
      connectSignalR(result.participantId, result.meetingId);
    } catch {
      setState("error");
      setMessage("Unable to join meeting");
    }
  }

  async function handleApproved(
    meetingId: string,
    participantId: string
  ) {
    setState("approved");

    const joinInfo = await joinJitsi(meetingId, participantId);

    // 🚀 Launch Jitsi here (next step)
    console.log("Jitsi Info:", joinInfo);
  }

  function connectSignalR(
    participantId: string,
    meetingId: string
  ) {
    const connection = new signalR.HubConnectionBuilder()
      .withUrl("http://localhost:5000/hubs/lobby")
      .withAutomaticReconnect()
      .build();

    connection.start().then(() => {
      connection.invoke("JoinGuestChannel", participantId);
    });

    connection.on("Approved", () =>
      handleApproved(meetingId, participantId)
    );

    connection.on("Rejected", () => {
      setState("rejected");
    });
  }

  return (
    <div style={containerStyle}>
      <div className="card" style={{ width: 420 }}>
        {state === "form" && (
          <>
            <h2>Join a Meeting</h2>
            <input
              placeholder="Meeting Code"
              value={meetingCode}
              onChange={e => setMeetingCode(e.target.value)}
            />
            <input
              placeholder="Your Name"
              value={name}
              onChange={e => setName(e.target.value)}
            />
            <button onClick={submit} style={{ width: "100%" }}>
              Join
            </button>
          </>
        )}

        {state === "joining" && <p>Joining meeting…</p>}

        {state === "waiting" && (
          <>
            <h3>Waiting for host</h3>
            <p>
              The host will let you in soon.
              <br />
              Please wait…
            </p>
          </>
        )}

        {state === "approved" && (
          <p>Joining meeting…</p>
        )}

        {state === "rejected" && (
          <>
            <h3>Not admitted</h3>
            <p>The host did not admit you.</p>
          </>
        )}

        {state === "error" && (
          <p style={{ color: "red" }}>{message}</p>
        )}
      </div>
    </div>
  );
}

const containerStyle = {
  height: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "#f5f6f8"
};
