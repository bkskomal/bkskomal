import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function JoinMeeting() {
  const navigate = useNavigate();

  const [meetingId, setMeetingId] = useState("");
  const [name, setName] = useState("");

  function joinMeeting() {
    if (!meetingId.trim()) {
      alert("Enter meeting ID");
      return;
    }

    if (!name.trim()) {
      alert("Enter your name");
      return;
    }

    // store guest name
    localStorage.setItem("guestName", name);

    navigate(`/meeting/${meetingId}`);
  }

  return (
    <div className="join-page">
      <h2>Join Meeting</h2>

      <input
        placeholder="Meeting ID"
        value={meetingId}
        onChange={(e) => setMeetingId(e.target.value)}
      />

      <input
        placeholder="Your name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <button onClick={joinMeeting}>
        Join Meeting
      </button>
    </div>
  );
}