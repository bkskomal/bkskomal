import { useState } from "react";
import { signup } from "../api/auth.api";
import { useNavigate } from "react-router-dom";

export default function Signup() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  async function submit() {

    setError("");

    try {

      await signup(email, password, name);

      setSuccess(true);

      // clear form
      setEmail("");
      setPassword("");
      setName("");

    } catch (err: any) {

      setError(
        err?.response?.data?.message || "Signup failed"
      );

    }

  }

  return (
    <div className="center-container">

      <div className="card" style={{ maxWidth: 380 }}>

        <h2>Create an account</h2>

        {success ? (

          <div style={{ textAlign: "center" }}>

            <p style={{ color: "green", marginBottom: 20 }}>
              User has been registered successfully.
            </p>

            <button
              style={{ width: "100%" }}
              onClick={() => navigate("/login")}
            >
              Click here to Sign In
            </button>

          </div>

        ) : (

          <>
            {error && (
              <p style={{ color: "red" }}>{error}</p>
            )}

            <input
              placeholder="Full Name"
              value={name}
              onChange={e => setName(e.target.value)}
            />

            <input
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />

            <button
              onClick={submit}
              style={{ width: "100%" }}
            >
              Sign Up
            </button>

            <div
              style={{
                textAlign: "center",
                margin: "10px 0",
                color: "#777",
                fontSize: 13
              }}
            >
            </div>

            <button
              className="secondary"
              style={{ width: "100%" }}
              onClick={() => navigate("/")}
            >
              Back to Home
            </button>

            <p style={{ marginTop: 16, fontSize: 13 }}>
              Already have an account?{" "}
              <a href="/login">Sign in</a>
            </p>

          </>

        )}

      </div>

    </div>
  );
}