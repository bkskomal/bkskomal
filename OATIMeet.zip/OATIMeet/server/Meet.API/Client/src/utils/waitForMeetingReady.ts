import api from "../api/axios";

export async function waitForMeetingReady(roomName: string) {

  for (let i = 0; i < 10; i++) {

    try {

      const res = await api.get(`/meetings/status/${roomName}`);

      if (res.data?.exists && res.data?.isActive) {
        return true;
      }

    } catch {
      // ignore temporary errors
    }

    await new Promise(r => setTimeout(r, 200));
  }

  return false;
}