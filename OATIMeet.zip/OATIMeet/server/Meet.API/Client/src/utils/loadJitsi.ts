import { getConfig } from "../config/env";

declare global {
  interface Window {
    JitsiMeetExternalAPI: any;
  }
}

let loadingPromise: Promise<void> | null = null;

export function loadJitsiScript(): Promise<void> {

  if (window.JitsiMeetExternalAPI) {
    return Promise.resolve();
  }

  if (loadingPromise) {
    return loadingPromise;
  }

  const { jitsiServerBaseUrl } = getConfig();

  loadingPromise = new Promise((resolve, reject) => {

    const script = document.createElement("script");

    script.id = "jitsi-script";
    script.src = "https://" + `${jitsiServerBaseUrl}/external_api.js`;
    script.async = true;

    script.onload = () => resolve();

    script.onerror = () =>
      reject(new Error("Failed to load Jitsi script"));

    document.body.appendChild(script);

  });

  return loadingPromise;
}