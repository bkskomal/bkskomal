import { loadJitsiScript } from "./loadJitsi";

export async function openMeetingWindow(roomName: string) {

  // preload jitsi script before opening meeting
  try {
    await loadJitsiScript();
  } catch (e) {
    console.error("Failed to preload Jitsi", e);
  }

  const url = `${window.location.origin}/room/${roomName}`;

  window.open(
    url,
    "meetingWindow",
    "width=1400,height=900,resizable=yes"
  );
}