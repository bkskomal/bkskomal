import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useState, useRef, useEffect } from "react";
import "./AppLayout.css";
import { logout } from "../utils/auth";

export default function AppLayout() {

  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const menuRef = useRef<HTMLDivElement | null>(null);

  /* -------- CLOSE DROPDOWN WHEN CLICKING OUTSIDE -------- */

  useEffect(() => {

    function handleClickOutside(event: MouseEvent) {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target as Node)
      ) {
        setOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };

  }, []);

  return (
    <div className="app-shell">

      <header className="app-header">

        {/* LEFT */}
        <div className="header-left">
          <span className="logo">OATIMeet</span>
        </div>

        {/* CENTER */}
        <nav className="header-nav">
          <NavLink to="/app/home">Home</NavLink>
          <NavLink to="/app/settings">Settings</NavLink>
        </nav>

        {/* RIGHT */}
        <div className="header-right" ref={menuRef}>

          {/* USER MENU BUTTON */}
          <div
            className="user-menu"
            onClick={() => setOpen(prev => !prev)}
          >
            <span className="avatar">K</span>
            <span className="caret">▾</span>
          </div>

          {/* DROPDOWN */}
          {open && (
            <div className="user-dropdown">

              <button
                onClick={() => {
                  setOpen(false);
                  navigate("/app/settings");
                }}
              >
                Settings
              </button>

              <button
                className="danger"
                onClick={() => {
                  logout();
                  navigate("/");
                }}
              >
                Sign out
              </button>

            </div>
          )}

        </div>

      </header>

      <main className="app-content">
        <Outlet />
      </main>

    </div>
  );
}