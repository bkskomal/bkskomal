import api from "../api/axios";

type AppConfig = {
  jitsiServerBaseUrl: string;
};

let config: AppConfig | null = null;

export async function loadConfig() {
  try {
    const res = await api.get("/config");
    config = res.data;
  } catch (err) {
    console.error("Failed to load app config", err);
    throw err;
  }
}

export function getConfig(): AppConfig {
  if (!config) {
    throw new Error("Config not loaded. Call loadConfig() first.");
  }

  return config;
}


export const JITSI_BASE_URL = "https://chat.int.services.oati.com/callservice";
export const JITSI_DOMAIN = "chat.int.services.oati.com";
export const JITSI_BASE_PATH = "/callservice";

export const API_BASE = "http://localhost:56347/api/v1";
export const APP_BASE_URL = "http://localhost:5173";

