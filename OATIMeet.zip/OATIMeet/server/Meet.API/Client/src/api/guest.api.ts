import api from "./axios";

export async function guestJoin(
  meetingCode: string,
  displayName: string
) {
  const res = await api.post("/meetings/guest/join", {
    meetingCode,
    displayName
  });

  return res.data.data; 
  // { meetingId, participantId, waitingForApproval }
}

export async function joinJitsi(
  meetingId: string,
  participantId: string
) {
  const res = await api.post("/meetings/guest/join/jitsi", {
    meetingId,
    participantId
  });

  return res.data.data;
}
