import api from "./axios";

export async function login(email: string, password: string) {
  const res = await api.post("/auth/login", { email, password });
  localStorage.setItem("token", res.data.accessToken);
}

export async function signup(
  email: string,
  password: string,
  name: string
) {
  await api.post("/auth/register", {
    email,
    password,
    name
  });
}


