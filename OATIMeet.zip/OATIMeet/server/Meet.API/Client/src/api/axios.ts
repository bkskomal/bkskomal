import axios from "axios";

const api = axios.create({
  baseURL: " http://localhost:56347/api/v1",
  headers: {
    "Content-Type": "application/json"
  }
});

// Attach JWT automatically
api.interceptors.request.use(config => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Global error handling
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem("token");
      window.location.href = "/";
    }
    return Promise.reject(error);
  }
);

export default api;
