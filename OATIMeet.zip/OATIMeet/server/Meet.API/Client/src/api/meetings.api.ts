import api from "./axios";

export async function getMeetings() {
  const res = await api.get("/meetings");
  return res.data.data;
}

export async function getLobby(meetingId: string) {
  const res = await api.get(`/meetings/${meetingId}/lobby`);
  return res.data.data;
}

export async function admitParticipant(meetingId: string, participantId: string) {
  await api.post(`/meetings/${meetingId}/lobby/${participantId}/admit`);
}

export async function rejectParticipant(meetingId: string, participantId: string) {
  await api.post(`/meetings/${meetingId}/lobby/${participantId}/reject`);
}
