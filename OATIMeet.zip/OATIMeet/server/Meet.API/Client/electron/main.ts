import { app, BrowserWindow, ipcMain, shell } from "electron";
import path from "path";
import fs from "fs";
import os from "os";

let mainWindow: BrowserWindow | null = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, "preload.js")
    }
  });

  mainWindow.loadURL("http://localhost:5173"); // dev

  mainWindow.webContents.openDevTools();
}

app.whenReady().then(createWindow);

ipcMain.handle("open-outlook-event", async (_, meeting) => {
  console.log("IPC RECEIVED:", meeting);

  try {
    const base64 = meeting.file.content;

    const icsContent = Buffer
      .from(base64, "base64")
      .toString("utf-8");

    const filePath = path.join(
      os.tmpdir(),
      meeting.file.fileName || `meet-${Date.now()}.ics`
    );

    fs.writeFileSync(filePath, icsContent, "utf-8");

    console.log("ICS WRITTEN:", filePath);
    console.log("ICS PREVIEW:", icsContent.substring(0, 120));

    const result = await shell.openPath(filePath);
    console.log("shell.openPath result:", result);

    return { success: true };
  } catch (err: any) {
    console.error("Outlook open failed:", err);
    return { success: false, error: err.message };
  }
});



ipcMain.handle("open-outlook-app", () => {
  shell.openExternal("outlook:");
});
