import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("electronAPI", {
 openOutlookEvent: (payload: any) => {
  console.log("PRELOAD → sending IPC", payload);
  return ipcRenderer.invoke("open-outlook-event", payload);
},

  openOutlook: () =>
    ipcRenderer.invoke("open-outlook-app")
});
