﻿using Meet.API.Hubs;
using Meet.API.SignalR;
using Meet.Application.Auth;
using Meet.Application.Meetings;
using Meet.Infrastructure.Auth;
using Meet.Infrastructure.Jitsi;
using Meet.Infrastructure.Meetings;
using Meet.Infrastructure.Persistence;
using Meet.Infrastructure.Tenant;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddHttpContextAccessor();

/* Tenant */
builder.Services.AddScoped<ITenantProvider, TenantProvider>();

builder.Services.AddScoped<IPasswordHasher, PasswordHasher>();
builder.Services.AddScoped<IJwtTokenService, JwtTokenService>();

/* EF Core provider switch */
var provider = builder.Configuration["Database:Provider"];
var connectionString = builder.Configuration.GetConnectionString("Default");

builder.Services.AddDbContext<AppDbContext>(options =>
{
	switch (provider)
	{
		case "Postgres":
			options.UseNpgsql(connectionString);
			break;

		case "MySql":
			options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
			break;

		default:
			options.UseSqlServer(connectionString);
			break;
	}
});


builder.Services.AddCors(options =>
{
	options.AddPolicy("ui",
		p => p.WithOrigins("http://localhost:5173")
			  .AllowAnyHeader()
			  .AllowAnyMethod()
			  .AllowCredentials());
});


builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
	.AddJwtBearer(options =>
	{
		options.TokenValidationParameters = new TokenValidationParameters
		{
			ValidateIssuer = true,
			ValidateAudience = true,
			ValidateLifetime = true,
			ValidateIssuerSigningKey = true,

			ValidIssuer = builder.Configuration["Jwt:Issuer"],
			ValidAudience = builder.Configuration["Jwt:Audience"],
			IssuerSigningKey = new SymmetricSecurityKey(
				Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!)
			)
		};
	});

builder.Services.AddAuthorization();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
	options.SwaggerDoc("v1", new OpenApiInfo
	{
		Title = "Meet API",
		Version = "v1"
	});

	options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
	{
		Name = "Authorization",
		Type = SecuritySchemeType.Http,
		Scheme = "Bearer",
		BearerFormat = "JWT",
		In = ParameterLocation.Header,
		Description = "Enter: Bearer {your JWT token}"
	});

	options.AddSecurityRequirement(new OpenApiSecurityRequirement
	{
		{
			new OpenApiSecurityScheme
			{
				Reference = new OpenApiReference
				{
					Type = ReferenceType.SecurityScheme,
					Id = "Bearer"
				}
			},
			Array.Empty<string>()
		}
	});
});

builder.Services.AddSignalR();

builder.Services.AddScoped<IMeetingService, MeetingService>();
builder.Services.AddScoped<IJitsiTokenService, JitsiTokenService>();
builder.Services.AddScoped<IJitsiJoinService, JitsiJoinService>();
builder.Services.AddScoped<IGuestJoinService, GuestJoinService>();
builder.Services.AddScoped<ILobbyService, LobbyService>();
builder.Services.AddScoped<IGuestJitsiJoinService, GuestJitsiJoinService>();
builder.Services.AddScoped<ILobbyNotifier, LobbyNotifier>();
builder.Services.AddScoped<IMeetingRepository, MeetingRepository>();
builder.Services.AddScoped<IMeetingCalendarService, MeetingCalendarService>();



var app = builder.Build();
app.UseHttpsRedirection();
app.UseCors("ui");
app.UseAuthentication();

app.UseAuthorization();


if (app.Environment.IsDevelopment())
{
	app.UseSwagger();
	app.UseSwaggerUI();
}

app.MapHub<LobbyHub>("/hubs/lobby");


app.UseDefaultFiles();
app.UseStaticFiles();

app.UseRouting();

app.MapControllers();

app.MapFallbackToFile("index.html");


app.Run();
