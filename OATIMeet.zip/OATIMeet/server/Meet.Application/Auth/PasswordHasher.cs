﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Meet.Application.Auth;
using Microsoft.AspNetCore.Identity;

namespace Meet.Infrastructure.Auth;

public class PasswordHasher : IPasswordHasher
{
	private readonly PasswordHasher<object> _hasher = new();

	public string Hash(string password)
	{
		return _hasher.HashPassword(null!, password);
	}

	public bool Verify(string hash, string password)
	{
		var result = _hasher.VerifyHashedPassword(null!, hash, password);
		return result == PasswordVerificationResult.Success;
	}
}
