﻿namespace Meet.Application.Auth;

public class RegisterCommand
{
	public string Name { get; set; } = default!;
	public string Email { get; set; } = default!;
	public string Password { get; set; } = default!;
}
