﻿namespace Meet.Application.Auth;

public class LoginCommand
{
	public string Email { get; set; } = default!;
	public string Password { get; set; } = default!;
}
