﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meet.Application.Auth;

public interface IJwtTokenService
{
	string GenerateToken(Guid userId, Guid organizationId, string role);
}
