﻿using Meet.Application.Common;
using Meet.Application.Meetings.DTOs;

namespace Meet.Application.Meetings;

public interface ILobbyService
{
	Task<Result<IReadOnlyList<LobbyParticipantDto>>> GetWaitingAsync(Guid meetingId);
	Task<Result> AdmitAsync(Guid meetingId, Guid participantId);
	Task<Result> RejectAsync(Guid meetingId, Guid participantId);
}
