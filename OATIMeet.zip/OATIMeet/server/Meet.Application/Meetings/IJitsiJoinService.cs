﻿using Meet.Application.Common;
using Meet.Application.Meetings.DTOs;

namespace Meet.Application.Meetings;

public interface IJitsiJoinService
{
	Task<Result<JitsiJoinDto>> JoinAsync(string meetingId);
}
