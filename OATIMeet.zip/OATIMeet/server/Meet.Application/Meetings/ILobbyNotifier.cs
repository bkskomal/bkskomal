﻿namespace Meet.Application.Meetings;

public interface ILobbyNotifier
{
	Task NotifyLobbyUpdated(Guid meetingId);
	Task NotifyGuestApproved(Guid participantId);
	Task NotifyGuestRejected(Guid participantId);
}
