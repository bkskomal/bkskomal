﻿using Meet.Application.Common;
using Meet.Application.Meetings.DTOs;

namespace Meet.Application.Meetings;

public interface IGuestJitsiJoinService
{
	Task<Result<GuestJitsiJoinDto>> JoinAsync(GuestJoinJitsiCommand command);
	Task<Result<GuestJoinResponseDto>> CreateParticipantAsync(GuestJoinCommand cmd);
}
