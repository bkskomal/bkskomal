﻿using Meet.Application.Common;
using Meet.Application.Meetings.DTOs;
using Meet.Domain.Entities;

namespace Meet.Application.Meetings;

public class GuestJoinService : IGuestJoinService
{
	private readonly IMeetingRepository _repo;
	private readonly ILobbyNotifier _notifier;

	public GuestJoinService(
		IMeetingRepository repo,
		ILobbyNotifier notifier)
	{
		_repo = repo;
		_notifier = notifier;
	}

	public async Task<Result<GuestJoinResponseDto>> JoinAsync(GuestJoinCommand cmd)
	{
		var meeting = await _repo.GetByCodeAsync(cmd.MeetingCode);

		if (meeting == null)
			return Result<GuestJoinResponseDto>.Failure("NOT_FOUND", "Meeting not found");

		if (!meeting.AllowGuests)
			return Result<GuestJoinResponseDto>.Failure("GUESTS_DISABLED", "Guests not allowed");

		if (meeting.Status == MeetingStatus.Ended)
			return Result<GuestJoinResponseDto>.Failure("ENDED", "Meeting has ended");

		var participant = new MeetingParticipant
		{
			Id = Guid.NewGuid(),
			MeetingId = meeting.Id,
			DisplayName = cmd.DisplayName,
			Type = ParticipantType.Guest,
			Status = meeting.EnableLobby
				? ParticipantStatus.Waiting
				: ParticipantStatus.Approved
		};

		await _repo.AddParticipantAsync(participant);
		await _repo.SaveChangesAsync();

		// 🔔 Notify host lobby (real-time)
		await _notifier.NotifyLobbyUpdated(meeting.Id);

		return Result<GuestJoinResponseDto>.Success(new GuestJoinResponseDto
		{
			MeetingId = meeting.Id,
			WaitingForApproval = participant.Status == ParticipantStatus.Waiting
		});
	}
}
