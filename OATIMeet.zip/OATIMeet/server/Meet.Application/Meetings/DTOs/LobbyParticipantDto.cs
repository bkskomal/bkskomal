﻿namespace Meet.Application.Meetings.DTOs;

public class LobbyParticipantDto
{
	public Guid ParticipantId { get; set; }
	public string DisplayName { get; set; } = default!;
	public DateTime JoinedAtUtc { get; set; }
}
