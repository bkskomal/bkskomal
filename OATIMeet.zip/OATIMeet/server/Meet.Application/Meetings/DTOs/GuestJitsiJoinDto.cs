﻿namespace Meet.Application.Meetings.DTOs;

public class GuestJitsiJoinDto
{
	public string ServerUrl { get; set; } = default!;
	public string RoomName { get; set; } = default!;
	public string Jwt { get; set; } = default!;
	public string DisplayName { get; set; } = default!;
}
