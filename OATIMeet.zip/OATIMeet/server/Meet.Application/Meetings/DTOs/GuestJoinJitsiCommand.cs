﻿namespace Meet.Application.Meetings.DTOs;

public class GuestJoinJitsiCommand
{
	public Guid MeetingId { get; set; }
	public Guid ParticipantId { get; set; }
}
