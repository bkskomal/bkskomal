﻿namespace Meet.Application.Meetings.DTOs;

public class MeetingListItemDto
{
	public Guid MeetingId { get; set; }
	public string Title { get; set; } = default!;
	public DateTime ScheduledTimeUtc { get; set; }
	public string Status { get; set; } = default!;
	public bool IsHost { get; set; }
}
