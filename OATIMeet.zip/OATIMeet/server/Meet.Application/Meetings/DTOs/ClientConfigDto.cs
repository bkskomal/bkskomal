﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meet.Application.Meetings.DTOs
{
	public class ClientConfigDto
	{
		public string? JitsiServerBaseUrl { get; set; }
	}
}
