﻿namespace Meet.Application.Meetings.DTOs;

public class UpdateMeetingCommand
{
	public string Title { get; set; } = default!;
	public DateTime ScheduledTimeUtc { get; set; }
}
