﻿namespace Meet.Application.Meetings.DTOs;

public class GuestJoinRequest
{
	public string? GuestName { get; set; }
}