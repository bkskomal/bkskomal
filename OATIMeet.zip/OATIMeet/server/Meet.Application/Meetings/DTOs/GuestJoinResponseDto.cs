﻿namespace Meet.Application.Meetings.DTOs;

public class GuestJoinResponseDto
{
	public Guid MeetingId { get; set; }
	public Guid ParticipantId { get; set; }
	public bool WaitingForApproval { get; set; }
}
