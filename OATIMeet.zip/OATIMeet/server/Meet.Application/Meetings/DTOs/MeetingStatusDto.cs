﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meet.Application.Meetings.DTOs
{
	public class MeetingStatusDto
	{
		public bool Exists { get; set; }
		public bool IsActive { get; set; }
		public string? RoomName { get; set; }
	}
}
