﻿namespace Meet.Application.Meetings.DTOs;

public class CreateMeetingCommand
{
	public string Title { get; set; } = default!;
	public DateTime ScheduledTimeUtc { get; set; }
	public int DurationMinutes { get; set; }

	public bool AllowGuests { get; set; }
	public bool EnableLobby { get; set; }
}
