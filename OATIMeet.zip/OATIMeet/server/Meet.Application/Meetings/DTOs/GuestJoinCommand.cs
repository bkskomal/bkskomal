﻿namespace Meet.Application.Meetings.DTOs;

public class GuestJoinCommand
{
	public string MeetingCode { get; set; } = default!;
	public string DisplayName { get; set; } = default!;
}
