﻿namespace Meet.Application.Meetings.DTOs;

public class CalendarFileResult
{
	public byte[] Content { get; set; } = default!;
	public string ContentType { get; set; } = "text/calendar";
	public string FileName { get; set; } = default!;
}
