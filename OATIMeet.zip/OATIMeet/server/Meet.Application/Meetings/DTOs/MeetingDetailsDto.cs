﻿namespace Meet.Application.Meetings.DTOs;

public class MeetingDetailsDto
{
	public Guid MeetingId { get; set; }
	public string Title { get; set; } = default!;
	public string MeetingCode { get; set; } = default!;
	public DateTime ScheduledTimeUtc { get; set; }
	public string Status { get; set; } = default!;

	public bool AllowGuests { get; set; }
	public bool EnableLobby { get; set; }
	public bool IsLocked { get; set; }
	public bool IsHost { get; set; }
}
