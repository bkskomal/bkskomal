﻿using Meet.Application.Common;
using Meet.Application.Meetings.DTOs;
using Meet.Domain.Entities;

namespace Meet.Application.Meetings;

public interface IMeetingService
{
	Task<Result<MeetingCreatedDto>> CreateAsync(CreateMeetingCommand command);
	Task<Result<IReadOnlyList<MeetingListItemDto>>> GetMyMeetingsAsync();
	Task<Result<MeetingDetailsDto>> GetByIdAsync(Guid meetingId);
	Task<Result> UpdateAsync(Guid meetingId, UpdateMeetingCommand command);
	Task<Result> StartAsync(Guid meetingId);
	Task<Result> EndAsync(Guid meetingId);
	Task<Meeting?> GetActiveByRoomNameAsync(string roomName);
	Task<MeetingStatusDto> GetMeetingStatusByRoomNameAsync(string roomName);
}
