﻿using Meet.Domain.Entities;

namespace Meet.Application.Meetings;

public interface IMeetingRepository
{
	Task<Meeting?> GetByIdAsync(Guid meetingId);
	Task<Meeting?> GetByCodeAsync(string meetingCode);

	Task<MeetingParticipant?> GetParticipantAsync(Guid meetingId, Guid participantId);
	Task<IReadOnlyList<MeetingParticipant>> GetWaitingParticipantsAsync(Guid meetingId);

	Task AddParticipantAsync(MeetingParticipant participant);
	Task SaveChangesAsync();

	Task AddMeetingAsync(Meeting meeting);
	Task<IReadOnlyList<Meeting>> GetMeetingsForUserAsync(Guid userId);

	Task<Meeting?> GetActiveByRoomNameAsync(string roomName);


}
