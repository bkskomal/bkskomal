﻿using Meet.Application.Common;
using Meet.Application.Meetings.DTOs;
using Meet.Domain.Entities;

namespace Meet.Application.Meetings;

public class LobbyService : ILobbyService
{
	private readonly IMeetingRepository _repo;
	private readonly ILobbyNotifier _notifier;

	public LobbyService(
		IMeetingRepository repo,
		ILobbyNotifier notifier)
	{
		_repo = repo;
		_notifier = notifier;
	}

	public async Task<Result<IReadOnlyList<LobbyParticipantDto>>> GetWaitingAsync(Guid meetingId)
	{
		var participants = await _repo.GetWaitingParticipantsAsync(meetingId);

		var list = participants
			.Select(x => new LobbyParticipantDto
			{
				ParticipantId = x.Id,
				DisplayName = x.DisplayName,
				JoinedAtUtc = x.JoinedAtUtc
			})
			.ToList();

		return Result<IReadOnlyList<LobbyParticipantDto>>.Success(list);
	}

	public async Task<Result> AdmitAsync(Guid meetingId, Guid participantId)
	{
		var participant = await _repo.GetParticipantAsync(meetingId, participantId);

		if (participant == null)
			return Result.Failure("NOT_FOUND", "Participant not found");

		participant.Status = ParticipantStatus.Approved;

		await _repo.SaveChangesAsync();

		await _notifier.NotifyGuestApproved(participantId);
		await _notifier.NotifyLobbyUpdated(meetingId);

		return Result.Success();
	}

	public async Task<Result> RejectAsync(Guid meetingId, Guid participantId)
	{
		var participant = await _repo.GetParticipantAsync(meetingId, participantId);

		if (participant == null)
			return Result.Failure("NOT_FOUND", "Participant not found");

		participant.Status = ParticipantStatus.Rejected;

		await _repo.SaveChangesAsync();

		await _notifier.NotifyGuestRejected(participantId);
		await _notifier.NotifyLobbyUpdated(meetingId);

		return Result.Success();
	}
}
