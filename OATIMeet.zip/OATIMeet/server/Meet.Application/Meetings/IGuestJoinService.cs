﻿using Meet.Application.Common;
using Meet.Application.Meetings.DTOs;

namespace Meet.Application.Meetings;

public interface IGuestJoinService
{
	Task<Result<GuestJoinResponseDto>> JoinAsync(GuestJoinCommand command);
}
