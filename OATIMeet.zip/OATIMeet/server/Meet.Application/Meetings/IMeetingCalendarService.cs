﻿using Meet.Application.Meetings.DTOs;

namespace Meet.Application.Meetings;

public interface IMeetingCalendarService
{
	Task<CalendarFileResult?> GenerateCalendarAsync(
		string roomName,
		int durationMinutes = 60,
		int reminderMinutes = 10,
		string? recurrenceRule = null
	);

}
