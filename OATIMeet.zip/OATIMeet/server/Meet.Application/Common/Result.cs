﻿namespace Meet.Application.Common;

public class Result
{
	public bool IsSuccess { get; protected set; }
	public string? ErrorCode { get; protected set; }
	public string? ErrorMessage { get; protected set; }

	public static Result Success()
		=> new() { IsSuccess = true };

	public static Result Failure(string errorCode, string errorMessage)
		=> new()
		{
			IsSuccess = false,
			ErrorCode = errorCode,
			ErrorMessage = errorMessage
		};
}
