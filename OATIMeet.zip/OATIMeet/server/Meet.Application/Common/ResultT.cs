﻿namespace Meet.Application.Common;

public class Result<T> : Result
{
	public T? Data { get; private set; }

	public static Result<T> Success(T data)
		=> new()
		{
			IsSuccess = true,
			Data = data
		};

	public static new Result<T> Failure(string errorCode, string errorMessage)
		=> new()
		{
			IsSuccess = false,
			ErrorCode = errorCode,
			ErrorMessage = errorMessage
		};
}
