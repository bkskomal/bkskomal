﻿Write-Host ""
Write-Host "=============================="
Write-Host "OATIMeet Production Build"
Write-Host "=============================="

$root = Get-Location
$server = "$root\server\Meet.API"
$client = "$server\client"
$deploy = "$root\deploy"

# Clean deploy folder
if (Test-Path $deploy) {
    Write-Host "Cleaning deploy folder..."
    Remove-Item $deploy -Recurse -Force
}

New-Item -ItemType Directory -Path $deploy | Out-Null

Write-Host ""
Write-Host "1️⃣ Installing UI dependencies"
Write-Host ""

Set-Location $client
if (!(Test-Path "node_modules")) {
    pnpm install
}


Write-Host ""
Write-Host "2️⃣ Building React UI (output → wwwroot)"
Write-Host ""

pnpm build

Write-Host ""
Write-Host "3️⃣ Publishing .NET Server"
Write-Host ""

Set-Location $server

dotnet publish -c Release -o "$deploy\server"

Write-Host ""
Write-Host "=============================="
Write-Host "Build completed successfully"
Write-Host "=============================="

Set-Location $root