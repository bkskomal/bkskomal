#requires -Version 5.1
<#
.SYNOPSIS
  Installs TB-OutlookPro suite (in-house + 3rd-party + theme + prefs) into a Thunderbird profile.

.DESCRIPTION
  Idempotent install. Steps:
   1. Detects/verifies Thunderbird is installed and TB version >= 140.
   2. Stops Thunderbird if running.
   3. Resolves the target profile (by name or full path).
   4. Drops in-house .xpi files into <profile>/extensions/.
   5. Drops vendor (3rd-party) .xpi files (if present at vendor/ alongside this script).
   6. Copies userChrome.css → <profile>/chrome/userChrome.css.
   7. Copies user.js → <profile>/user.js (appends to existing — preserves user prefs).
   8. Ensures required prefs are set: experiments enabled, signatures bypass, legacy stylesheets.
   9. Clears addonStartup cache so TB rescans add-ons on next launch.
  10. Optionally launches Thunderbird.

  Works for both the source-tree layout (plugins at repo root) AND the
  dist/ layout (plugins under plugins/, vendor/ under vendor/).

.PARAMETER ProfileName
  Profile name to match (default: jitsitest) OR a full profile dir path.
  (Renamed from "Profile" to avoid shadowing PowerShell's automatic $Profile variable.)

.PARAMETER NoLaunch
  Don't auto-launch Thunderbird after install.

.PARAMETER NoVendor
  Skip vendor/ 3rd-party add-ons.

.PARAMETER VendorOnly
  Install only specific vendor add-ons by filename match (case-insensitive).
  Example: -VendorOnly "composeur","cardbook"

.PARAMETER ThunderbirdExe
  Full path to thunderbird.exe (default: "C:\Program Files\Mozilla Thunderbird\thunderbird.exe").

.PARAMETER MinTbVersion
  Minimum Thunderbird version to allow install (default: 140).

.EXAMPLE
  .\install.ps1
  .\install.ps1 -ProfileName default-release -NoVendor
  .\install.ps1 -ProfileName "C:\path\to\custom-profile" -VendorOnly "composeur"
#>
param(
  [string]$ProfileName = "jitsitest",
  [switch]$NoLaunch,
  [switch]$NoVendor,
  [string[]]$VendorOnly = @(),
  [string]$ThunderbirdExe = "C:\Program Files\Mozilla Thunderbird\thunderbird.exe",
  [int]$MinTbVersion = 140
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# ── 0. Verify Thunderbird ─────────────────────────────────────
Write-Host "Step 0/9   Verifying Thunderbird installation..." -ForegroundColor Cyan
if (-not (Test-Path $ThunderbirdExe)) {
  # Try x86 dir
  $alt = "C:\Program Files (x86)\Mozilla Thunderbird\thunderbird.exe"
  if (Test-Path $alt) {
    $ThunderbirdExe = $alt
  } else {
    throw "Thunderbird not found at $ThunderbirdExe or x86 path. Install TB 140+ first."
  }
}
$tbVer = (Get-Item $ThunderbirdExe).VersionInfo.ProductVersion
$tbMajor = [int]($tbVer.Split('.')[0])
if ($tbMajor -lt $MinTbVersion) {
  throw "Thunderbird $tbVer found, but version >= $MinTbVersion required (experiment APIs)."
}
Write-Host "  Thunderbird $tbVer at $ThunderbirdExe" -ForegroundColor Green

# ── 1. Resolve profile ────────────────────────────────────────
Write-Host "Step 1/9   Resolving profile..." -ForegroundColor Cyan
function Resolve-Profile([string]$p) {
  if (Test-Path $p -PathType Container) { return (Resolve-Path $p).Path }
  $profilesDir = "$env:APPDATA\Thunderbird\Profiles"
  if (-not (Test-Path $profilesDir)) {
    throw "TB profile dir not found at $profilesDir. Has Thunderbird been run at least once?"
  }
  $found = Get-ChildItem $profilesDir -Directory | Where-Object { $_.Name -like "*$p*" }
  if (-not $found) {
    Write-Host "Available profiles:" -ForegroundColor Yellow
    Get-ChildItem $profilesDir -Directory | ForEach-Object { Write-Host "  $($_.Name)" }
    throw "No profile matching '*$p*' under $profilesDir"
  }
  if ($found.Count -gt 1) {
    Write-Host "Multiple profiles match — using first:" -ForegroundColor Yellow
    $found | ForEach-Object { Write-Host "  $_" }
  }
  return $found[0].FullName
}
$profileDir = Resolve-Profile $ProfileName
Write-Host "  Profile: $profileDir" -ForegroundColor Green

# ── 2. Stop TB ───────────────────────────────────────────────
Write-Host "Step 2/9   Stopping Thunderbird (if running)..." -ForegroundColor Cyan
Get-Process thunderbird -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 4

# ── 3. Helpers ────────────────────────────────────────────────
$extDir = Join-Path $profileDir "extensions"
if (-not (Test-Path $extDir)) { New-Item -ItemType Directory -Path $extDir | Out-Null }

# Detect layout: dist (plugins/ + vendor/) vs source-tree (.xpi at root)
$pluginsDir = Join-Path $here "plugins"
if (-not (Test-Path $pluginsDir)) { $pluginsDir = $here }
$vendorDir = Join-Path $here "vendor"

# ── 4. Install in-house plugins ───────────────────────────────
Write-Host "Step 3/9   Installing in-house plugins..." -ForegroundColor Cyan
$addonIdMap = @{
  "outlookpro-quick-rule.xpi"      = "outlookpro-quick-rule@oss.local.xpi"
  "outlookpro-compose-in-tab.xpi"  = "outlookpro-compose-in-tab@oss.local.xpi"
  "outlookpro-cards-default.xpi"   = "outlookpro-cards-default@oss.local.xpi"
  "outlookpro-adfs-oauth.xpi"      = "outlookpro-adfs-oauth@oss.local.xpi"
  "outlookpro-ews-calendar.xpi"    = "outlookpro-ews-calendar@oss.local.xpi"
  "outlookpro-ews-contacts.xpi"    = "outlookpro-ews-contacts@oss.local.xpi"
  "outlookpro-mapi-http.xpi"       = "outlookpro-mapi-http@oss.local.xpi"
}
$installed = 0
foreach ($srcName in $addonIdMap.Keys) {
  $src = Join-Path $pluginsDir $srcName
  if (-not (Test-Path $src)) {
    Write-Host "  [MISS] $srcName — build with .\build_all.ps1 first" -ForegroundColor Yellow
    continue
  }
  Copy-Item $src (Join-Path $extDir $addonIdMap[$srcName]) -Force
  Write-Host ("  [OK]   {0,-46} {1,8:N0} bytes" -f $addonIdMap[$srcName], (Get-Item $src).Length) -ForegroundColor Green
  $installed++
}

# ── 5. Install vendor (3rd-party) add-ons ────────────────────
Write-Host "Step 4/9   Installing 3rd-party add-ons..." -ForegroundColor Cyan
$vendorInstalled = 0
if ($NoVendor) {
  Write-Host "  [SKIP] -NoVendor flag set" -ForegroundColor DarkGray
} elseif (-not (Test-Path $vendorDir)) {
  Write-Host "  [SKIP] no vendor/ directory" -ForegroundColor DarkGray
} else {
  $vendorFiles = Get-ChildItem $vendorDir -Filter "*.xpi" -ErrorAction SilentlyContinue
  if ($VendorOnly.Count -gt 0) {
    $vendorFiles = $vendorFiles | Where-Object {
      $name = $_.Name
      $VendorOnly | Where-Object { $name -like "*$_*" }
    }
  }
  foreach ($vf in $vendorFiles) {
    Copy-Item $vf.FullName (Join-Path $extDir $vf.Name) -Force
    Write-Host ("  [OK]   {0,-46} {1,8:N0} bytes" -f $vf.Name, $vf.Length) -ForegroundColor Green
    $vendorInstalled++
  }
  if ($vendorInstalled -eq 0) {
    Write-Host "  [INFO] vendor/ found but matched no .xpi files" -ForegroundColor DarkYellow
  }
}

# ── 6. Copy userChrome.css ────────────────────────────────────
Write-Host "Step 5/9   Installing visual theme (userChrome.css)..." -ForegroundColor Cyan
$chromeDir = Join-Path $profileDir "chrome"
if (-not (Test-Path $chromeDir)) { New-Item -ItemType Directory -Path $chromeDir | Out-Null }
$ucSrc = Join-Path $here "userChrome.css"
if (Test-Path $ucSrc) {
  Copy-Item $ucSrc (Join-Path $chromeDir "userChrome.css") -Force
  Write-Host ("  [OK]   userChrome.css ({0:N1} KB)" -f ((Get-Item $ucSrc).Length / 1KB)) -ForegroundColor Green
} else {
  Write-Host "  [SKIP] userChrome.css missing" -ForegroundColor Yellow
}

# ── 7. Merge user.js ──────────────────────────────────────────
Write-Host "Step 6/9   Merging user.js prefs..." -ForegroundColor Cyan
$userJsSrc = Join-Path $here "user.js"
$userJsDst = Join-Path $profileDir "user.js"
if (Test-Path $userJsSrc) {
  if (Test-Path $userJsDst) {
    $existing = Get-Content $userJsDst -Raw
    if ($existing -notmatch "OutlookPro user.js") {
      $new = Get-Content $userJsSrc -Raw
      Add-Content $userJsDst "`n# OutlookPro user.js applied $(Get-Date -Format 'yyyy-MM-dd')`n$new"
      Write-Host "  [OK]   user.js appended (existing prefs preserved)" -ForegroundColor Green
    } else {
      Copy-Item $userJsSrc $userJsDst -Force
      Write-Host "  [OK]   user.js overwritten (was previously installed by us)" -ForegroundColor Green
    }
  } else {
    Copy-Item $userJsSrc $userJsDst -Force
    Write-Host "  [OK]   user.js installed (fresh)" -ForegroundColor Green
  }
} else {
  Write-Host "  [SKIP] user.js missing" -ForegroundColor Yellow
}

# ── 8. Ensure required prefs ──────────────────────────────────
Write-Host "Step 7/9   Ensuring required prefs..." -ForegroundColor Cyan
$requiredPrefs = @(
  @{ key="toolkit.legacyUserProfileCustomizations.stylesheets"; line='user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);' },
  @{ key="extensions.experiments.enabled";                       line='user_pref("extensions.experiments.enabled", true);' },
  @{ key="xpinstall.signatures.required";                        line='user_pref("xpinstall.signatures.required", false);' },
  @{ key="extensions.autoDisableScopes";                         line='user_pref("extensions.autoDisableScopes", 0);' },
  @{ key="extensions.enabledScopes";                             line='user_pref("extensions.enabledScopes", 15);' }
)
$existing = if (Test-Path $userJsDst) { Get-Content $userJsDst -Raw } else { "" }
$append = ""
foreach ($p in $requiredPrefs) {
  if ($existing -notmatch [regex]::Escape($p.key)) { $append += $p.line + "`n" }
}
if ($append) {
  Add-Content $userJsDst "`n# OutlookPro install.ps1: required prefs $(Get-Date -Format 'yyyy-MM-dd')`n$append"
  Write-Host "  [OK]   added $(($append -split "`n").Count - 1) missing pref(s)" -ForegroundColor Green
} else {
  Write-Host "  [OK]   all required prefs already present" -ForegroundColor Green
}

# ── 9. Clear startup cache ───────────────────────────────────
Write-Host "Step 8/9   Clearing addon startup cache..." -ForegroundColor Cyan
$startupCache = Join-Path $profileDir "addonStartup.json.lz4"
if (Test-Path $startupCache) { Remove-Item $startupCache -Force }
Write-Host "  [OK]   addonStartup.json.lz4 cleared" -ForegroundColor Green

# ── 10. Launch ────────────────────────────────────────────────
Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host " Install complete:" -ForegroundColor Cyan
Write-Host "   In-house plugins: $installed" -ForegroundColor Cyan
Write-Host "   Vendor add-ons:   $vendorInstalled" -ForegroundColor Cyan
Write-Host "   Profile:          $profileDir" -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan

if (-not $NoLaunch) {
  Write-Host ""
  Write-Host "Step 9/9   Launching Thunderbird..." -ForegroundColor Cyan
  $profileName = (Split-Path $profileDir -Leaf) -replace '^[a-z0-9]+\.', ''
  Start-Process $ThunderbirdExe -ArgumentList "-P", $profileName, "-no-remote"
  Write-Host "  Launched. Verify add-ons via Tools → Add-ons and Themes." -ForegroundColor Green
} else {
  Write-Host ""
  Write-Host "Skipped TB launch (-NoLaunch). Run:" -ForegroundColor DarkGray
  Write-Host "  & `"$ThunderbirdExe`" -P <profile-name> -no-remote" -ForegroundColor DarkGray
}
