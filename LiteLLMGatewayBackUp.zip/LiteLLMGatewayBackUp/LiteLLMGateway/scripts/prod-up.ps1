#Requires -Version 5.1
<#
    .SYNOPSIS
        Bring up the LiteLLM Gateway stack in PRODUCTION mode.

    .DESCRIPTION
        Like dev-up.ps1, but:
          - GATEWAY_ENVIRONMENT=production  (disables the sk-dev+... shortcut)
          - uvicorn without --reload, --no-access-log, --proxy-headers
          - next start (from a pre-built ./.next bundle) — not next dev
          - if -WithObs, also brings up Prometheus + Grafana + Alertmanager
            and sets GATEWAY_GRAFANA_URL so the bus pill links to Grafana

        Assumes:
          - `gateway/.venv` exists and has LLMGateway installed
          - `admin-ui/.next/` build artefacts exist (run `npm run build` first
            if not — we'll do it for you if -RebuildUi is passed)
          - Postgres + Ollama are reachable on localhost

        For real production deploys behind nginx/Traefik, see
        docs/PRODUCTION_DEPLOY.md.

    .EXAMPLE
        # Standard prod stack
        .\scripts\prod-up.ps1

        # Rebuild the admin UI bundle first (after a code change)
        .\scripts\prod-up.ps1 -RebuildUi

        # Plus Prometheus / Grafana / Alertmanager
        .\scripts\prod-up.ps1 -WithObs
#>
[CmdletBinding()]
param(
    [switch]$WithObs,
    [switch]$RebuildUi,
    [string]$RepoRoot = (Resolve-Path "$PSScriptRoot\..").Path
)

$ErrorActionPreference = "Stop"

function Stop-PortListener {
    param([int]$Port)
    $conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    foreach ($processId in @($conns | Select-Object -ExpandProperty OwningProcess -Unique)) {
        $proc = Get-Process -Id $processId -ErrorAction SilentlyContinue
        if ($proc) {
            Write-Host ("  stopping {0} on :{1} (pid={2})" -f $proc.ProcessName, $Port, $processId)
            Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
        }
    }
}

function Wait-PortReady {
    param([int]$Port, [int]$TimeoutSec = 90)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        try {
            $tc = New-Object System.Net.Sockets.TcpClient
            $tc.Connect("127.0.0.1", $Port)
            $tc.Close()
            return $true
        } catch {
            Start-Sleep -Milliseconds 500
        }
    }
    return $false
}

# ---------------------------------------------------------------------------
# 1. Free the ports
# ---------------------------------------------------------------------------
Write-Host "==> Stopping any existing gateway / admin-ui processes..."
Stop-PortListener -Port 4000
Stop-PortListener -Port 3000
Start-Sleep -Seconds 1

# ---------------------------------------------------------------------------
# 2. Rebuild the admin UI bundle if requested
# ---------------------------------------------------------------------------
if ($RebuildUi -or -not (Test-Path "$RepoRoot\admin-ui\.next")) {
    Write-Host "==> Building admin-ui for production (this takes ~90s)..."
    Push-Location "$RepoRoot\admin-ui"
    try {
        $env:NODE_ENV = "production"
        npm run build | Out-Host
        if ($LASTEXITCODE -ne 0) { throw "next build failed (exit=$LASTEXITCODE)" }
    } finally {
        Pop-Location
    }
}

# ---------------------------------------------------------------------------
# 3. Production env
# ---------------------------------------------------------------------------
Write-Host "==> Exporting gateway env (production mode)..."
$env:GATEWAY_DB_URL          = "postgresql+asyncpg://postgres:Godis1%40321%23@localhost/litellm_gateway"
$env:GATEWAY_AUDIT_DB_URL    = "postgresql+asyncpg://postgres:Godis1%40321%23@localhost/litellm_gateway_audit"
$env:GATEWAY_REDIS_URL       = "memory://"   # OK on a single-replica dev box; switch to a real Redis URL for HA
$env:GATEWAY_PLUGINS         = "authz_tiered,quota_redis,guardrail_patterns,router_rule_based,output_scan_secrets,observe_ueba,audit_postgres,cache_redis,siem_forward"
$env:GATEWAY_ENVIRONMENT     = "production"  # disables sk-dev+ tokens
$env:GATEWAY_MASTER_KEY      = if ($env:GATEWAY_MASTER_KEY) { $env:GATEWAY_MASTER_KEY } else { "sk-master-dev" }
$env:OLLAMA_API_BASE         = "http://localhost:11434/v1"
$env:OPENROUTER_API_KEY      = if ($env:OPENROUTER_API_KEY) { $env:OPENROUTER_API_KEY } else { "dummy" }
if ($WithObs) { $env:GATEWAY_GRAFANA_URL = "http://localhost:3001" }

if ($env:GATEWAY_MASTER_KEY -eq "sk-master-dev") {
    Write-Warning "GATEWAY_MASTER_KEY is the development default. Set a real value for prod."
}

# ---------------------------------------------------------------------------
# 4. Obs profile (optional)
# ---------------------------------------------------------------------------
if ($WithObs) {
    Write-Host "==> Starting docker obs profile (Prometheus + Grafana + Alertmanager)..."
    Push-Location $RepoRoot
    try {
        docker compose --profile obs up -d prometheus grafana alertmanager | Out-Host
    } finally {
        Pop-Location
    }
}

# ---------------------------------------------------------------------------
# 5. Start gateway in prod mode
# ---------------------------------------------------------------------------
Write-Host "==> Starting gateway on :4000 (uvicorn, --no-access-log, --proxy-headers)..."
$gatewayDir = "$RepoRoot\gateway"
$gwLog      = "$RepoRoot\gateway-prod.log"
$gwErr      = "$RepoRoot\gateway-prod.err.log"
Start-Process -FilePath "$gatewayDir\.venv\Scripts\python.exe" `
    -ArgumentList "-m", "uvicorn", "gateway.main:app",
                   "--host", "127.0.0.1", "--port", "4000",
                   "--workers", "1",
                   "--no-access-log",
                   "--log-level", "warning",
                   "--proxy-headers" `
    -WorkingDirectory $gatewayDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $gwLog `
    -RedirectStandardError $gwErr

if (-not (Wait-PortReady -Port 4000 -TimeoutSec 90)) {
    Write-Error "Gateway did not come up on :4000. Tail $gwLog for details."
    exit 1
}
Write-Host "    gateway healthy"

# ---------------------------------------------------------------------------
# 6. Start admin UI in prod mode
# ---------------------------------------------------------------------------
Write-Host "==> Starting admin-ui on :3000 (next start)..."
$uiDir = "$RepoRoot\admin-ui"
$uiLog = "$RepoRoot\admin-ui-prod.log"
$uiErr = "$RepoRoot\admin-ui-prod.err.log"
Start-Process -FilePath "cmd.exe" `
    -ArgumentList "/c", "npm", "run", "start", "--", "--hostname", "0.0.0.0", "--port", "3000" `
    -WorkingDirectory $uiDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $uiLog `
    -RedirectStandardError $uiErr

if (-not (Wait-PortReady -Port 3000 -TimeoutSec 90)) {
    Write-Warning "Admin UI did not come up on :3000. Tail $uiLog for details."
} else {
    Write-Host "    admin-ui healthy"
}

# ---------------------------------------------------------------------------
# 7. Done
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================================"
Write-Host " Production stack up."
Write-Host "================================================================================"
Write-Host "  Admin UI       : http://localhost:3000   (admin / admin)"
Write-Host "  Gateway API    : http://localhost:4000"
Write-Host "  Readiness      : http://localhost:4000/ready"
Write-Host "  Metrics        : http://localhost:4000/metrics"
if ($WithObs) {
    Write-Host "  Prometheus     : http://localhost:9090"
    Write-Host "  Grafana        : http://localhost:3001  (admin / admin)"
    Write-Host "  Alertmanager   : http://localhost:9093"
}
Write-Host ""
Write-Host "  Logs:"
Write-Host "    gateway   : $gwLog"
Write-Host "    admin-ui  : $uiLog"
Write-Host ""
Write-Host "  Tear down with: .\scripts\prod-down.ps1"
Write-Host "================================================================================"
