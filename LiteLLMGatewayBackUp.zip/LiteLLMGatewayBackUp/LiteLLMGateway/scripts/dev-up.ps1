#Requires -Version 5.1
<#
    .SYNOPSIS
        Bring up the full LiteLLM Gateway local-dev stack with one command.

    .DESCRIPTION
        Stops any process on the gateway / admin-UI ports, exports the
        right env vars, starts the gateway in the background with
        --reload (so backend code changes hot-pick), confirms health,
        and prints the URLs you'd next visit. Optionally also brings up
        the docker-compose obs profile (Prometheus + Grafana +
        Alertmanager).

        Replaces the manual 5-step restart dance that was triggering
        404s every time we added a new admin endpoint.

    .EXAMPLE
        # Just gateway + admin-ui
        .\scripts\dev-up.ps1

        # Plus Prometheus / Grafana / Alertmanager
        .\scripts\dev-up.ps1 -WithObs

    .EXAMPLE
        # Stop everything started by this script
        .\scripts\dev-down.ps1
#>
[CmdletBinding()]
param(
    [switch]$WithObs,
    [string]$RepoRoot = (Resolve-Path "$PSScriptRoot\..").Path
)

$ErrorActionPreference = "Stop"

function Stop-PortListener {
    param([int]$Port)
    $conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    foreach ($processId in @($conns | Select-Object -ExpandProperty OwningProcess -Unique)) {
        $proc = Get-Process -Id $processId -ErrorAction SilentlyContinue
        if ($proc) {
            Write-Host ("  stopping {0} on :{1} (pid={2})" -f $proc.ProcessName, $Port, $processId)
            Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
        }
    }
}

function Wait-PortReady {
    param([int]$Port, [int]$TimeoutSec = 60)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        try {
            $tc = New-Object System.Net.Sockets.TcpClient
            $tc.Connect("127.0.0.1", $Port)
            $tc.Close()
            return $true
        } catch {
            Start-Sleep -Milliseconds 500
        }
    }
    return $false
}

# ---------------------------------------------------------------------------
# 1. Free the ports
# ---------------------------------------------------------------------------
Write-Host "==> Stopping any existing gateway / admin-ui processes..."
Stop-PortListener -Port 4000
Stop-PortListener -Port 3000
Start-Sleep -Seconds 1

# ---------------------------------------------------------------------------
# 2. Set env (matches the README + tests use the *_test DBs separately)
# ---------------------------------------------------------------------------
Write-Host "==> Exporting gateway env vars..."
$env:GATEWAY_DB_URL          = "postgresql+asyncpg://postgres:Godis1%40321%23@localhost/litellm_gateway"
$env:GATEWAY_AUDIT_DB_URL    = "postgresql+asyncpg://postgres:Godis1%40321%23@localhost/litellm_gateway_audit"
$env:GATEWAY_REDIS_URL       = "memory://"
$env:GATEWAY_PLUGINS         = "authz_tiered,quota_redis,guardrail_patterns,router_rule_based,output_scan_secrets,observe_ueba,audit_postgres,cache_redis,siem_forward"
$env:GATEWAY_ENVIRONMENT     = "dev"
$env:GATEWAY_MASTER_KEY      = "sk-master-dev"
$env:OLLAMA_API_BASE         = "http://localhost:11434/v1"   # /v1 required by LLMGateway's OllamaProvider
$env:OPENROUTER_API_KEY      = "dummy"
# When obs profile is up, makes the bus pill on /overview link to Grafana.
if ($WithObs) {
    $env:GATEWAY_GRAFANA_URL = "http://localhost:3001"
}

# ---------------------------------------------------------------------------
# 3. Bring up Prometheus / Grafana / Alertmanager (optional)
# ---------------------------------------------------------------------------
if ($WithObs) {
    Write-Host "==> Starting docker-compose obs profile (Prometheus + Grafana + Alertmanager)..."
    Push-Location $RepoRoot
    try {
        docker compose --profile obs up -d prometheus grafana alertmanager | Out-Host
    } finally {
        Pop-Location
    }
}

# ---------------------------------------------------------------------------
# 4. Start the gateway with --reload so future code changes hot-restart
# ---------------------------------------------------------------------------
Write-Host "==> Starting gateway on :4000 (with --reload)..."
$gatewayDir = Join-Path $RepoRoot "gateway"
$logPath    = Join-Path $RepoRoot "gateway-dev.log"
Start-Process -FilePath (Join-Path $gatewayDir ".venv\Scripts\python.exe") `
    -ArgumentList "-m", "uvicorn", "gateway.main:app",
                   "--host", "127.0.0.1", "--port", "4000",
                   "--reload", "--log-level", "warning" `
    -WorkingDirectory $gatewayDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $logPath `
    -RedirectStandardError $logPath

if (-not (Wait-PortReady -Port 4000 -TimeoutSec 60)) {
    Write-Error "Gateway did not come up on :4000 within 60s. Tail $logPath for details."
    exit 1
}
Write-Host "    gateway healthy on http://127.0.0.1:4000"

# ---------------------------------------------------------------------------
# 5. Start the admin UI (next dev) in its own background process
# ---------------------------------------------------------------------------
Write-Host "==> Starting admin-ui on :3000 (next dev --turbopack)..."
$uiDir   = Join-Path $RepoRoot "admin-ui"
$uiLog   = Join-Path $RepoRoot "admin-ui-dev.log"
Start-Process -FilePath "cmd.exe" `
    -ArgumentList "/c", "npm", "run", "dev" `
    -WorkingDirectory $uiDir `
    -WindowStyle Hidden `
    -RedirectStandardOutput $uiLog `
    -RedirectStandardError $uiLog

if (-not (Wait-PortReady -Port 3000 -TimeoutSec 90)) {
    Write-Warning "Admin UI did not come up on :3000 within 90s. Tail $uiLog for details."
}
else {
    Write-Host "    admin-ui healthy on http://127.0.0.1:3000"
}

# ---------------------------------------------------------------------------
# 6. Done — print URLs
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================================"
Write-Host " Local-dev stack up."
Write-Host "================================================================================"
Write-Host "  Admin UI       : http://localhost:3000   (admin / admin)"
Write-Host "  Gateway API    : http://localhost:4000"
Write-Host "  Metrics        : http://localhost:4000/metrics"
if ($WithObs) {
    Write-Host "  Prometheus     : http://localhost:9090"
    Write-Host "  Grafana        : http://localhost:3001  (admin / admin)"
    Write-Host "  Alertmanager   : http://localhost:9093"
}
Write-Host ""
Write-Host "  Logs:"
Write-Host "    gateway   : $logPath"
Write-Host "    admin-ui  : $uiLog"
Write-Host ""
Write-Host "  Tear down with: .\scripts\dev-down.ps1"
Write-Host "================================================================================"
