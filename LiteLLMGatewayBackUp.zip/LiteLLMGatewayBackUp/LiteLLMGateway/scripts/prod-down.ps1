#Requires -Version 5.1
<#
    .SYNOPSIS
        Tear down the production stack brought up by prod-up.ps1.
#>
[CmdletBinding()]
param([string]$RepoRoot = (Resolve-Path "$PSScriptRoot\..").Path)

$ErrorActionPreference = "Continue"

function Stop-PortListener {
    param([int]$Port)
    $conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    foreach ($processId in @($conns | Select-Object -ExpandProperty OwningProcess -Unique)) {
        $proc = Get-Process -Id $processId -ErrorAction SilentlyContinue
        if ($proc) {
            Write-Host ("  stopping {0} on :{1} (pid={2})" -f $proc.ProcessName, $Port, $processId)
            Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
        }
    }
}

Write-Host "==> Stopping gateway + admin-ui..."
Stop-PortListener -Port 4000
Stop-PortListener -Port 3000

Write-Host "==> Stopping docker obs profile (if running)..."
Push-Location $RepoRoot
try {
    docker compose --profile obs down 2>&1 | Out-Host
} catch {
    Write-Host "  (docker compose not running — skipped)"
} finally {
    Pop-Location
}

Write-Host "Done."
