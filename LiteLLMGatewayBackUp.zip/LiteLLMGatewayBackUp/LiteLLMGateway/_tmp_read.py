with open('gateway/src/gateway/api/admin.py', encoding='utf-8') as f:
    lines = f.readlines()
for i in range(1960, min(2350, len(lines))):
    print(f"{i+1}: {lines[i]}", end='')
