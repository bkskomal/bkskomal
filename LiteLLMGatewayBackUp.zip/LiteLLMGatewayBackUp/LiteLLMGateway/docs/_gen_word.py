"""Generate docs/LLMGateway-Implementation.docx.

Polished long-form companion to the deck. Uses Word's built-in Heading
styles (so the live Table of Contents auto-populates), tinted navy header
cells in every table, banded body rows, page header + footer with page
numbers, and a colour-banded cover page modelled on the OATI deck.

Reframed: Requirement → Architecture → Implementation. No roadmap /
timeline. Three model picks: Kimi K2.6, Qwen3-Coder-30B, Gemma 4 27B.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn, nsmap
from docx.shared import Cm, Inches, Pt, RGBColor
from docx.table import _Cell, Table


DOCS = Path(__file__).resolve().parent
OUT  = DOCS / "LLMGateway-Implementation.docx"
ARCH = DOCS / "architecture.png"
LOGO = DOCS / "oati-assets" / "image1.png"

# Design tokens (match the deck)
NAVY      = RGBColor(0x14, 0x1F, 0x3B)
NAVY_HEX  = "141F3B"
NAVY_BAR  = RGBColor(0x1B, 0x2A, 0x4E)
NAVY_BAR_HEX = "1B2A4E"
RED       = RGBColor(0xC8, 0x2A, 0x32)
RED_HEX   = "C82A32"
BLUE      = RGBColor(0x2E, 0x86, 0xAB)
ACCENT    = RGBColor(0x4A, 0x90, 0xE2)
MUTED     = RGBColor(0x6B, 0x72, 0x80)
LIGHT_BG  = "F5F7FA"
BAND_BG   = "F1F4F8"     # banded body row fill


# --------------------------------------------------------------------------
# Low-level helpers
# --------------------------------------------------------------------------
def set_run(run, *, size=11, bold=False, italic=False, color=None,
            font="Calibri"):
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color


def set_cell_bg(cell: _Cell, hex_fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tc_pr.append(shd)


def set_cell_borders(cell: _Cell, color_hex: str = "D0D7DE", size: int = 4):
    """Apply a thin coloured border to all four sides of a cell."""
    tc_pr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for side in ("top", "left", "bottom", "right"):
        e = OxmlElement(f"w:{side}")
        e.set(qn("w:val"), "single")
        e.set(qn("w:sz"), str(size))
        e.set(qn("w:color"), color_hex)
        tcBorders.append(e)
    tc_pr.append(tcBorders)


def style_table(tbl: Table, header_bg=NAVY_BAR_HEX, header_fg=RGBColor(0xFF, 0xFF, 0xFF),
                band_bg=BAND_BG, border_hex="D0D7DE"):
    """Apply consistent visual treatment to every table in the doc."""
    tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
    rows = tbl.rows
    # Header row
    for cell in rows[0].cells:
        set_cell_bg(cell, header_bg)
        set_cell_borders(cell, border_hex)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        for p in cell.paragraphs:
            for r in p.runs:
                r.font.color.rgb = header_fg
                r.font.bold = True
                r.font.size = Pt(10.5)
    # Body rows — banded
    for ri, row in enumerate(rows[1:], start=1):
        for cell in row.cells:
            set_cell_borders(cell, border_hex)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            if ri % 2 == 0:
                set_cell_bg(cell, band_bg)


def horizontal_band(doc, color_hex: str, height_pt: float = 6):
    """A coloured horizontal divider (rendered as a thin shaded paragraph)."""
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color_hex)
    pPr.append(shd)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after  = Pt(0)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    p.paragraph_format.line_spacing = Pt(height_pt)


def insert_field(paragraph, instr_text: str, placeholder: str = "Right-click to update"):
    """Insert a raw Word field (e.g. TOC, PAGE) so the rendered doc shows
    a live, updatable result. Uses the begin/instrText/separate/end form
    because TOC also needs a placeholder result run so the doc doesn't
    open with an empty body."""
    r = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    fld_begin.set(qn("w:dirty"), "true")
    r._r.append(fld_begin)

    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " " + instr_text + " "
    r._r.append(instr)

    fld_sep = OxmlElement("w:fldChar")
    fld_sep.set(qn("w:fldCharType"), "separate")
    r._r.append(fld_sep)

    # Placeholder result text (Word replaces it when the field is updated)
    r2 = paragraph.add_run(placeholder)
    set_run(r2, size=10, italic=True, color=MUTED)

    r3 = paragraph.add_run()
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    r3._r.append(fld_end)


# --------------------------------------------------------------------------
# Custom heading + body styles — applied once on the Document
# --------------------------------------------------------------------------
def configure_styles(doc: Document):
    # Body
    body = doc.styles["Normal"]
    body.font.name = "Calibri"
    body.font.size = Pt(11)
    body.paragraph_format.space_after = Pt(6)
    body.paragraph_format.line_spacing = 1.25

    # Headings 1-3 — use NAVY + Calibri Light to match the deck.
    for level, size, before, after in [(1, 22, 18, 8),
                                       (2, 15, 14, 6),
                                       (3, 12.5, 10, 4)]:
        style = doc.styles[f"Heading {level}"]
        style.font.name = "Calibri Light"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = NAVY
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    # Title style — used on the cover page
    title = doc.styles["Title"]
    title.font.name = "Calibri Light"
    title.font.size = Pt(40)
    title.font.bold = True
    title.font.color.rgb = NAVY

    # Subtitle
    subtitle = doc.styles["Subtitle"]
    subtitle.font.name = "Calibri Light"
    subtitle.font.size = Pt(20)
    subtitle.font.color.rgb = BLUE


# --------------------------------------------------------------------------
# Header / footer (page chrome on every page after the cover)
# --------------------------------------------------------------------------
def configure_header_footer(doc: Document):
    section = doc.sections[0]
    section.left_margin   = Cm(2.0)
    section.right_margin  = Cm(2.0)
    section.top_margin    = Cm(2.2)
    section.bottom_margin = Cm(2.0)
    section.header_distance = Cm(1.0)
    section.footer_distance = Cm(1.0)
    section.different_first_page_header_footer = True

    # Header — thin navy strip with doc title left and section eyebrow right.
    # python-docx doesn't let us draw a real coloured rectangle in the header
    # easily, so we use a styled paragraph with shading on the run.
    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    rh = hp.add_run("LLMGateway · Developer Box Integration")
    set_run(rh, size=9, bold=True, color=NAVY, font="Calibri")
    # Right tab for the section label
    tab_stops = hp.paragraph_format.tab_stops
    tab_stops.add_tab_stop(Cm(17), WD_ALIGN_PARAGRAPH.RIGHT)
    hp.add_run("\t")
    rh2 = hp.add_run("OATI Technology · " + str(date.today().year))
    set_run(rh2, size=9, italic=True, color=MUTED, font="Calibri")
    # Underline border under the header
    pPr = hp._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "3")
    bottom.set(qn("w:color"), NAVY_HEX)
    pbdr.append(bottom)
    pPr.append(pbdr)

    # Footer — page X of Y, doc tag on left.
    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    rf1 = fp.add_run("Implementation · Requirement → Architecture → Implementation")
    set_run(rf1, size=8.5, color=MUTED, font="Calibri")
    tabs = fp.paragraph_format.tab_stops
    tabs.add_tab_stop(Cm(17), WD_ALIGN_PARAGRAPH.RIGHT)
    fp.add_run("\t")
    rf2 = fp.add_run("Page ")
    set_run(rf2, size=8.5, color=MUTED, font="Calibri")
    insert_field(fp, "PAGE", placeholder="–")
    rf3 = fp.add_run(" of ")
    set_run(rf3, size=8.5, color=MUTED, font="Calibri")
    insert_field(fp, "NUMPAGES", placeholder="–")


# --------------------------------------------------------------------------
# Authoring helpers
# --------------------------------------------------------------------------
def H1(doc, text): return doc.add_heading(text, level=1)
def H2(doc, text): return doc.add_heading(text, level=2)
def H3(doc, text): return doc.add_heading(text, level=3)


def para(doc, text, *, bold=False, italic=False, color=None, size=11,
         align=None):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(text)
    set_run(run, size=size, bold=bold, italic=italic, color=color)
    if align is not None:
        p.alignment = align
    return p


def bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    r = p.add_run(text)
    set_run(r, size=11)
    return p


def table_kv(doc, rows, *, col1_w_in=1.8, col2_w_in=4.6,
             caption: str | None = None):
    if caption:
        cap = doc.add_paragraph()
        cap.paragraph_format.space_before = Pt(8)
        cap.paragraph_format.space_after  = Pt(4)
        r = cap.add_run(f"Table · {caption}")
        set_run(r, size=10, italic=True, color=MUTED)

    tbl = doc.add_table(rows=len(rows) + 1, cols=2)
    tbl.autofit = False
    # Header
    h = tbl.rows[0].cells
    for i, txt in enumerate(("Field", "Value")):
        h[i].text = ""
        run = h[i].paragraphs[0].add_run(txt)
        set_run(run, size=10.5, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
    # Body
    for ri, (k, v) in enumerate(rows, start=1):
        c1, c2 = tbl.rows[ri].cells
        for c in (c1, c2): c.text = ""
        r1 = c1.paragraphs[0].add_run(k)
        set_run(r1, size=10, bold=True, color=NAVY)
        r2 = c2.paragraphs[0].add_run(v)
        set_run(r2, size=10)
    # Column widths
    for row in tbl.rows:
        row.cells[0].width = Inches(col1_w_in)
        row.cells[1].width = Inches(col2_w_in)
    style_table(tbl)
    return tbl


def table_grid(doc, header, rows, *, col_widths_in=None,
               caption: str | None = None):
    if caption:
        cap = doc.add_paragraph()
        cap.paragraph_format.space_before = Pt(8)
        cap.paragraph_format.space_after  = Pt(4)
        r = cap.add_run(f"Table · {caption}")
        set_run(r, size=10, italic=True, color=MUTED)

    tbl = doc.add_table(rows=len(rows) + 1, cols=len(header))
    tbl.autofit = False
    for i, h in enumerate(header):
        c = tbl.rows[0].cells[i]
        c.text = ""
        run = c.paragraphs[0].add_run(h)
        set_run(run, size=10.5, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
    for ri, row in enumerate(rows, start=1):
        for ci, val in enumerate(row):
            c = tbl.rows[ri].cells[ci]
            c.text = ""
            r = c.paragraphs[0].add_run(val)
            set_run(r, size=10, bold=(ci == 0),
                    color=(NAVY if ci == 0 else None))
    if col_widths_in:
        for ci, w in enumerate(col_widths_in):
            for row in tbl.rows:
                row.cells[ci].width = Inches(w)
    style_table(tbl)
    return tbl


def cover_page(doc):
    """Coloured top band + giant title + chips for the 3 models."""
    # Top navy band ---------------------------------------------------------
    for _ in range(3):
        horizontal_band(doc, NAVY_HEX, height_pt=12)
    # Red accent strip
    horizontal_band(doc, RED_HEX, height_pt=4)

    # Logo + title + subtitle
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(40)
    p.paragraph_format.space_after = Pt(0)
    if LOGO.exists():
        r = p.add_run()
        r.add_picture(str(LOGO), width=Inches(1.6))

    t = doc.add_paragraph(style="Title")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t.paragraph_format.space_before = Pt(32)
    t.paragraph_format.space_after  = Pt(6)
    t.add_run("Developer Box Integration")

    sub = doc.add_paragraph(style="Subtitle")
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.paragraph_format.space_after = Pt(2)
    sub.add_run("via LLMGateway")

    tag = doc.add_paragraph()
    tag.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tag.paragraph_format.space_after = Pt(18)
    r = tag.add_run("Requirement · Architecture · Implementation")
    set_run(r, size=13, italic=True, color=MUTED, font="Calibri Light")

    # Three model chips as a small table
    chip_tbl = doc.add_table(rows=1, cols=3)
    chip_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    chips = [
        ("Kimi K2.6",        "Premium · cloud",          "824DE0"),
        ("Qwen3-Coder-30B",  "Workhorse · self-host",    "4A90E2"),
        ("Gemma 4 27B",      "Economy · self-host",      "2E7D32"),
    ]
    for i, (name, sub, hexc) in enumerate(chips):
        c = chip_tbl.rows[0].cells[i]
        c.text = ""
        c.width = Inches(2.0)
        set_cell_bg(c, hexc)
        set_cell_borders(c, hexc)
        c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p1 = c.paragraphs[0]
        p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p1.paragraph_format.space_after = Pt(0)
        rr = p1.add_run(name)
        set_run(rr, size=12, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
        p2 = c.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p2.paragraph_format.space_after = Pt(6)
        rs = p2.add_run(sub)
        set_run(rs, size=9, color=RGBColor(0xE7, 0xE6, 0xE6))

    # Spacer + footer attribution
    sp = doc.add_paragraph()
    sp.paragraph_format.space_before = Pt(24)
    sp = doc.add_paragraph()
    sp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = sp.add_run(f"Prepared by OATI Technology  ·  {date.today().strftime('%B %Y')}")
    set_run(r, size=10, color=MUTED)

    # Bottom red strip + navy band
    sp2 = doc.add_paragraph()
    sp2.paragraph_format.space_before = Pt(36)
    horizontal_band(doc, RED_HEX, height_pt=4)
    for _ in range(2):
        horizontal_band(doc, NAVY_HEX, height_pt=10)

    # Confidentiality marker
    cm = doc.add_paragraph()
    cm.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cm.paragraph_format.space_before = Pt(6)
    r = cm.add_run("PROPRIETARY AND CONFIDENTIAL  |  Open Access Technology International")
    set_run(r, size=8, color=MUTED)

    doc.add_page_break()


def toc_page(doc):
    """Table of Contents with a live TOC field + a List of Tables field."""
    H1(doc, "Contents")
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(8)
    r = p.add_run("Right-click the entries below and choose 'Update Field' "
                  "in Word if any heading was renamed or added.")
    set_run(r, size=10, italic=True, color=MUTED)

    # TOC field — picks up Heading 1-3
    p = doc.add_paragraph()
    insert_field(p, 'TOC \\o "1-3" \\h \\z \\u',
                 placeholder="(open in Word and press F9 to populate)")

    # List of Tables
    H2(doc, "List of Tables")
    p = doc.add_paragraph()
    insert_field(p, 'TOC \\h \\z \\c "Table"',
                 placeholder="(populated on field update)")

    doc.add_page_break()


# --------------------------------------------------------------------------
# Build
# --------------------------------------------------------------------------
def build():
    doc = Document()
    configure_styles(doc)
    configure_header_footer(doc)

    # ---- Cover + TOC -----------------------------------------------------
    cover_page(doc)
    toc_page(doc)

    # ---- 1. Executive Summary --------------------------------------------
    H1(doc, "1. Executive Summary")
    para(doc,
         "Developers across the organisation want AI coding assistants — "
         "Cline, Continue, Antigravity — without each one independently "
         "picking a model, a key, and an endpoint. This document describes "
         "the solution we have built: a policy-enforcing gateway that sits "
         "between every IDE and every model, with three coding models "
         "behind it (Kimi K2.6 in the cloud, Qwen3-Coder-30B and Gemma 4 "
         "27B self-hosted on a shared GPU box).")
    para(doc,
         "The document is organised in three parts: the requirements we "
         "set out to meet (Section 2), the architecture that meets them "
         "(Sections 3-6), and the implementation as it stands today "
         "(Sections 7-9).")

    doc.add_page_break()

    # ---- 2. Requirements -------------------------------------------------
    H1(doc, "2. Requirements")

    H2(doc, "2.1 Goals")
    bullet(doc, "Developer productivity — autocomplete, refactor, test generation.")
    bullet(doc, "IP control — no source code leaves our network.")
    bullet(doc, "Cost predictability — fixed compute spend, no per-seat AI licences.")
    bullet(doc, "Vendor independence — open weights, OpenAI-compatible API.")
    bullet(doc, "Compliance posture — full audit trail on every prompt / response.")
    bullet(doc, "Centralised control — tier ACL, DLP, budgets, UEBA enforced "
                "server-side, not per-laptop.")

    H2(doc, "2.2 Non-goals")
    bullet(doc, "Replacing senior judgement, code review, or PR approvals.")
    bullet(doc, "Mandatory adoption — opt-in pilot first, expand by evidence.")
    bullet(doc, "Matching frontier (GPT / Claude) on novel research tasks.")
    bullet(doc, "Replacing existing IDEs — additive, not disruptive.")
    bullet(doc, "Public-facing AI features — internal dev tooling only.")
    bullet(doc, "On-laptop GPU inference — all hosting is centralised.")

    H2(doc, "2.3 Drivers")
    para(doc,
         "Self-hosted coding models hit a usability tipping point in 2025. "
         "Open-weights models (Qwen3-Coder, Gemma 4) can match cloud "
         "quality on common dev tasks at zero per-token cost — provided "
         "we control the rollout. The gateway is the unit of control.")

    # ---- 3. Model Selection ----------------------------------------------
    H1(doc, "3. Model Selection")
    para(doc,
         "Three coding models, all reached via the same gateway URL. Two "
         "are self-hosted on a shared GPU box via vLLM; one is "
         "cloud-routed. Developers see them as interchangeable IDs in the "
         "model picker.")
    table_grid(doc,
        header=["Model", "Tier", "Deployment", "Use for"],
        rows=[
            ("Kimi K2.6", "PRIMARY · Premium",
             "Cloud via Moonshot / OpenRouter",
             "Senior devs, complex agent tasks"),
            ("Qwen3-Coder-30B", "SECONDARY · Workhorse",
             "Self-hosted (vLLM, shared GPU box)",
             "Everyday chat, codebase Q&A, refactors"),
            ("Gemma 4 27B", "TERTIARY · Economy",
             "Self-hosted (vLLM, same GPU box)",
             "A/B comparisons, fallback at peak"),
        ],
        col_widths_in=[1.5, 1.6, 2.1, 2.0],
        caption="Selected models and their deployment mode",
    )

    H2(doc, "3.1 Why these three")
    bullet(doc, "Kimi K2.6 — best architectural discipline + strongest multi-turn "
                "across our evaluations. ~1T params (32B active MoE) — too "
                "large to self-host, so cloud-routed and budget-controlled.")
    bullet(doc, "Qwen3-Coder-30B — Apache-2.0, 30B params (~3B active MoE), "
                "256k context. Sits at the sweet spot of capability and GPU "
                "footprint; absorbs the bulk of daily traffic at zero "
                "per-token cost.")
    bullet(doc, "Gemma 4 27B — Google open-weights with a different tokenizer "
                "to Qwen. Catches blind spots the others miss and serves as "
                "a fallback when the 30B is saturated.")

    H2(doc, "3.2 Why not the alternatives")
    bullet(doc, "DeepSeek V4 Pro is proprietary and cannot be self-hosted.")
    bullet(doc, "Smaller Qwen2.5-Coder variants don't suit the centralised "
                "GPU box plan; small models on dev laptops are out of scope.")

    doc.add_page_break()

    # ---- 4. Infrastructure -----------------------------------------------
    H1(doc, "4. Hardware Infrastructure")
    para(doc,
         "Developer laptops have no GPU and host no models. All inference "
         "happens behind a central gateway — a mix of self-hosted "
         "(Qwen3-Coder, Gemma 4) and cloud-routed (Kimi K2.6) backends.")

    H2(doc, "4.1 Developer laptop")
    table_kv(doc, [
        ("Spec",    "i5 / i7, 16-32 GB RAM, integrated graphics OK"),
        ("Runs",    "VS Code + Continue + Cline, or Antigravity IDE"),
        ("Hosts",   "No local model; talks only to the gateway"),
        ("Network", "mTLS to LLMGateway URL"),
        ("Auth",    "Personal API key bound to SSO identity"),
        ("Cost",    "Zero hardware upgrade per developer"),
    ], caption="Developer-laptop specification")

    H2(doc, "4.2 Shared GPU box (self-host)")
    table_kv(doc, [
        ("Spec",    "1× RTX 6000 Ada (48 GB) or used RTX 3090 (24 GB)"),
        ("Runs",    "vLLM (PagedAttention, batched throughput)"),
        ("Hosts",   "Qwen3-Coder-30B-A3B · Gemma 4 27B"),
        ("Perf",    "40-120 tok/s · 8-15 concurrent devs"),
        ("Network", "Private VLAN, no internet egress, gateway-only ingress"),
        ("Sizing",  "Rule of thumb: 1 GPU per ~10 active developers"),
    ], caption="Shared GPU inference box")

    H2(doc, "4.3 Cloud backend")
    table_kv(doc, [
        ("Spec",    "No hardware — Moonshot / OpenRouter API"),
        ("Runs",    "Kimi K2.6 (1T params, ~32B active MoE)"),
        ("Hosts",   "Provider-hosted; we route through gateway"),
        ("Perf",    "60-120 tok/s · effectively unlimited concurrency"),
        ("Network", "Outbound from gateway only · DLP scrubs before send"),
        ("Cost",    "Pay-per-token · budgeted per team in the gateway"),
    ], caption="Cloud-routed backend for Kimi K2.6")

    # ---- 5. Inference Backends ------------------------------------------
    H1(doc, "5. Inference Backends")
    para(doc,
         "Two backend modes behind the gateway. Both expose OpenAI-"
         "compatible HTTP APIs, so IDE plugins don't know or care which "
         "one served their request — the gateway translates between "
         "provider quirks via the LLMGateway shim.")
    table_grid(doc,
        header=["Aspect", "vLLM (self-host)", "Cloud API (Kimi K2.6)"],
        rows=[
            ("Hardware we run",  "1× shared GPU box",                       "None"),
            ("Throughput",        "40-120 tok/s (batched)",                    "60-120 tok/s"),
            ("Concurrency",       "8-15 active devs / GPU",                    "Effectively unlimited"),
            ("Cost model",        "Capex + power; zero per-token",             "Per-token; budgeted per team"),
            ("Network egress",    "Stays inside our VLAN",                     "Outbound from gateway; DLP-scrubbed"),
            ("Data residency",    "Fully on-prem",                             "Sent to provider; logged"),
            ("Failure mode",      "GPU box down → both models down",           "Provider outage; gateway fails over"),
            ("Best for",          "Bulk daily chat, autocomplete",             "Senior devs, complex agent tasks"),
        ],
        col_widths_in=[1.7, 2.4, 2.4],
        caption="Self-host vs cloud trade-offs",
    )
    para(doc,
         "Decision: vLLM on the shared GPU box for Qwen3-Coder + Gemma 4; "
         "cloud API for Kimi K2.6; both fronted by the same gateway. Dev "
         "laptops host nothing.",
         bold=True, color=NAVY, size=11)

    # ---- 6. IDE & Tooling ------------------------------------------------
    H1(doc, "6. IDE & Tooling")
    para(doc,
         "Two IDEs supported, two complementary plugins. Every plugin "
         "points at the same gateway URL and uses a personal API key "
         "bound to SSO identity.")
    table_grid(doc,
        header=["Surface", "Strengths", "Best for"],
        rows=[
            ("VS Code + Continue",
             "Free, MIT-based IDE. Inline chat + autocomplete.",
             "Autocomplete-heavy workflows."),
            ("VS Code + Cline",
             "Same IDE; autonomous agent style with multi-step file edits.",
             "Refactors, codebase Q&A."),
            ("Antigravity IDE",
             "Google-native AI IDE (free). Built-in chat + agent + autocomplete.",
             "Greenfield agent flows."),
        ],
        col_widths_in=[2.0, 2.7, 1.9],
        caption="IDE + plugin matrix",
    )

    doc.add_page_break()

    # ---- 7. Architecture -------------------------------------------------
    H1(doc, "7. Architecture")
    para(doc,
         "Six pipeline stages, in order: AuthN → AuthZ → DLP → Smart "
         "Router → Inference → Audit. A failure at any stage short-"
         "circuits with a structured error that is itself audited. "
         "Operators view and tune the system through an admin UI; "
         "developers see only the gateway URL.")

    if ARCH.exists():
        doc.add_picture(str(ARCH), width=Inches(6.5))
        last = doc.paragraphs[-1]
        last.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cp = doc.add_paragraph()
        cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cp.paragraph_format.space_after = Pt(8)
        r = cp.add_run("Figure 1 · LLMGateway system architecture")
        set_run(r, size=9, italic=True, color=MUTED)

    H2(doc, "7.1 Component summary")
    table_kv(doc, [
        ("Gateway core (FastAPI)",
         "Owns /v1/chat/completions, /v1/models, /admin/*, /metrics, /ready. "
         "Single uvicorn worker holds in-memory plugin state."),
        ("Plugin chain (6 stages)",
         "AuthN → AuthZ (tier + RPM + daily $ budget) → DLP guardrails → "
         "Smart Router → Inference + cache → Audit + UEBA."),
        ("LLMGateway shim",
         "In-house MIT-licensed provider translation. Drop-in for the "
         "LiteLLM Router; supports Ollama, OpenRouter, OpenAI, Anthropic, "
         "Bedrock, Azure, Vertex, Gemini, Groq, Together."),
        ("Admin UI (Next.js 15)",
         "Operator console with sidebar grouped by pipeline stage. BFF "
         "proxy injects the master key server-side so the browser never "
         "holds it."),
        ("Persistence",
         "Two Postgres DBs (operational + audit). Audit body AES-GCM "
         "encrypted; 4-eyes reveal flow for plaintext access."),
        ("Observability",
         "Prometheus scrapes /metrics every 5 s. Grafana hosts two "
         "provisioned dashboards (Operations, Security). Alertmanager "
         "routes alerts."),
    ], caption="Components of the LLMGateway stack")

    H2(doc, "7.2 Request flow (9 checkpoints)")
    para(doc,
         "Every prompt walks through the same nine checkpoints. A failure "
         "at any step short-circuits with a structured error — never a "
         "silent leak. Each step writes its outcome to the audit row.")
    table_grid(doc,
        header=["#", "Step", "Action"],
        rows=[
            ("1", "Developer types",  "VS Code / Antigravity → /v1/chat/completions"),
            ("2", "TLS + Auth",        "mTLS client cert + bearer key check"),
            ("3", "Identity → SSO",    "Resolve key → user, team, role"),
            ("4", "Authorization",     "Allowed model? Agent mode allowed?"),
            ("5", "Rate / quota",      "TPM, RPM, daily budget per user / team"),
            ("6", "DLP input scan",    "Presidio · regex · custom heuristics"),
            ("7", "Router decides",    "Kimi (cloud) vs Qwen3 / Gemma (vLLM)"),
            ("8", "Inference",         "Stream tokens back through gateway"),
            ("9", "Output scan + log", "Secret scan · ship audit row to SIEM"),
        ],
        col_widths_in=[0.4, 1.8, 4.3],
        caption="The nine checkpoints every prompt walks through",
    )

    doc.add_page_break()

    # ---- 8. Security -----------------------------------------------------
    H1(doc, "8. Security Model")

    H2(doc, "8.1 Threats we mitigate")
    table_grid(doc,
        header=["Layer", "Threat", "Impact if unmitigated"],
        rows=[
            ("Identity",          "Anyone on LAN hits the model anonymously",
             "Stolen laptop = free model for an attacker"),
            ("Authorization",     "Junior dev runs senior-grade agent + quotas",
             "Interns running production-grade refactors"),
            ("Data exfil (in)",   "Dev pastes PII / secrets / regulated code",
             "GDPR breach · lost IP · secrets in logs"),
            ("Data exfil (out)",  "Model regurgitates a secret it saw earlier",
             "Leaked API keys appear in chat replies"),
            ("Cost / abuse",      "One dev fires a 50-tab fuzz loop",
             "Shared GPU saturated · legit users blocked"),
            ("Audit / forensics", "\"Did anyone send our auth code to the model?\"",
             "No answer = de facto breach during review"),
        ],
        col_widths_in=[1.4, 2.5, 2.7],
        caption="Threats and their unmitigated impact",
    )

    H2(doc, "8.2 Controls")
    table_grid(doc,
        header=["Layer", "Control", "Tool / Plugin", "Example policy"],
        rows=[
            ("Auth",      "Identify the user",       "Keycloak / Entra OIDC + virtual keys",   "Personal key bound to SSO"),
            ("AuthZ",     "Which model / mode?",      "LLMGateway team & key scopes",           "Interns: 7B only · seniors: 30B + agent"),
            ("Quota",     "How much / how fast?",     "quota_redis (RPM + TPM + daily $)",      "200k tok/dev/day · 60 req/min"),
            ("DLP",       "Block sensitive prompts",  "guardrail_patterns + Presidio",          "Refuse on AWS key · redact on PII"),
            ("Routing",   "Pick the right model",     "router_rule_based",                      "Tiny prompts → Qwen3 · agent → Kimi"),
            ("Output",    "Catch leaked secrets",     "output_scan_secrets",                    "Block streams that emit secrets"),
            ("Cache",     "Avoid duplicate spend",    "cache_redis + cache_semantic",           "5 min TTL · 0.92 cosine for hits"),
            ("Audit",     "Tamper-evident log",       "audit_postgres (AES-GCM body)",          "1 row / call · 4-eyes for plaintext"),
            ("Behaviour", "Catch misuse",             "observe_ueba",                            "Auto-quarantine on threshold breach"),
            ("Network",   "No surprise egress",       "gateway-only outbound",                   "VLAN blocks dev-laptop → internet"),
        ],
        col_widths_in=[1.0, 1.7, 2.0, 2.0],
        caption="Layered controls and example policies",
    )

    doc.add_page_break()

    # ---- 9. Implementation -----------------------------------------------
    H1(doc, "9. Implementation Snapshot")
    para(doc, "What's built today, by surface area:")

    H2(doc, "9.1 Gateway")
    bullet(doc, "FastAPI :4000 with single uvicorn worker (in-memory plugin state).")
    bullet(doc, "OpenAI-compatible /v1/chat/completions + /chat/completions alias "
                "for clients that don't add /v1. /v1/models + /models likewise.")
    bullet(doc, "LLMGateway shim translates to Ollama, OpenRouter, OpenAI, "
                "Anthropic, Bedrock, Azure, Vertex, Gemini, Groq, Together.")
    bullet(doc, "Truststore (OS cert store) injected at import time so outbound "
                "HTTPS works behind SSL-inspecting antivirus (Avast / Bitdefender).")

    H2(doc, "9.2 Plugin chain")
    bullet(doc, "AuthN — auth.py with master key + DB-issued virtual keys "
                "(sha256-hashed, 8-char prefix, expires_at honoured).")
    bullet(doc, "AuthZ — authz_tiered + quota_redis. Rate-limit headers on "
                "every response so clients self-throttle.")
    bullet(doc, "DLP — guardrail_patterns with regex + heuristic detectors; "
                "configurable per-team severity threshold.")
    bullet(doc, "Smart Router — router_rule_based with a YAML rule chain and "
                "per-rule overrides table in the operational DB.")
    bullet(doc, "Inference — cache_redis (exact-hash) + cache_semantic "
                "(cosine) short-circuit before any backend cost. Streaming via SSE.")
    bullet(doc, "Audit + Observe — audit_postgres (AES-GCM body, append-only), "
                "siem_forward, output_scan_secrets, observe_ueba.")

    H2(doc, "9.3 Admin UI")
    bullet(doc, "Next.js 15 :3010. Sidebar grouped by pipeline stage "
                "(AuthN → AuthZ → DLP → Smart Router → Inference → Audit).")
    bullet(doc, "Settings page with two tabs: Models (typed form per provider, "
                "Advanced JSON fallback) and App settings (cost-metrics "
                "toggle, Providers card for OpenRouter key management).")
    bullet(doc, "OpenRouter catalog browser — search OR's 250+ models and "
                "one-click import into the local registry with pricing + "
                "context-length pre-filled.")
    bullet(doc, "Observability page embeds the two provisioned Grafana "
                "dashboards via iframe (anonymous viewer).")
    bullet(doc, "Four themes: Light, Dark, Solarized Light, Solarized Dark.")

    H2(doc, "9.4 Persistence")
    bullet(doc, "Postgres × 2 — one operational (teams, keys, models, "
                "policies, plugins, router rules, system settings) and one "
                "audit (append-only audit_log, audit_reveal_requests).")
    bullet(doc, "audit_log body AES-GCM-encrypted at rest. Plaintext reveal "
                "requires a 4-eyes approval workflow — the operator who "
                "requests cannot also approve.")
    bullet(doc, "Redis optional (rate-limit + response cache); falls back to "
                "in-process counters with memory:// for dev.")

    H2(doc, "9.5 Observability")
    bullet(doc, "Prometheus :9090 — 5-second scrape interval, 15-day "
                "retention, two alert-rule files mounted from "
                "docker/prometheus/rules/.")
    bullet(doc, "Grafana :3001 — two provisioned dashboards (Operations, "
                "Security). Anonymous viewer enabled; allow_embedding=true "
                "so the admin UI iframes them.")
    bullet(doc, "Alertmanager :9093 — routes Prometheus alerts.")

    H2(doc, "9.6 Behavioural — UEBA")
    bullet(doc, "Per-user rolling baselines on 10 signals (jailbreak attempts, "
                "refusal velocity, DLP hits/week, output-secret leaks, …).")
    bullet(doc, "Auto-quarantine when the threshold radar trips; quarantined "
                "keys can be restored from the UEBA admin page with an "
                "operator decision note (auditable).")
    bullet(doc, "JIT elevations for short-window L3_privileged tier access; "
                "each request is auditable and expires.")

    doc.add_page_break()

    # ---- 10. Scaling & Capacity -----------------------------------------
    H1(doc, "10. Scaling & Capacity")
    para(doc,
         "The gateway is mostly stateless by design. This section answers "
         "the three questions operators ask before sizing a deployment: "
         "can it cluster behind a load balancer, what is the minimum "
         "hardware footprint, and how many concurrent calls can it serve.")

    H2(doc, "10.1 Clustering")
    para(doc,
         "Yes — with conditions. Three pieces of in-process state must "
         "move to shared backends before placing a second replica behind "
         "a load balancer:")
    table_grid(doc,
        header=["State", "Today (single-worker prod)", "Multi-replica fix"],
        rows=[
            ("Rate-limit counters\n(quota_redis)",
             "In-memory dict when GATEWAY_REDIS_URL=memory://",
             "Set GATEWAY_REDIS_URL to a real Redis. Otherwise each "
             "replica enforces its own cap → effective limit = "
             "configured × N replicas."),
            ("Response cache\n(cache_redis, cache_semantic)",
             "In-process dict on memory://",
             "Same fix. Without it, cache hit rate drops by 1/N per replica."),
            ("Plugin chain + Router config",
             "Hot-reloaded on the local process after admin writes",
             "Either accept 'config changes propagate on next restart' or "
             "add a Redis pub/sub reload signal (~30 lines)."),
        ],
        col_widths_in=[1.8, 2.3, 2.5],
        caption="In-process state that must be moved to shared backends",
    )

    H3(doc, "10.1.1 Cluster-safe today")
    bullet(doc, "Postgres operational + audit databases — every replica reads "
                "and writes the same rows.")
    bullet(doc, "Audit log, DLP findings, UEBA baselines — all persist to "
                "Postgres, so any replica reading them sees the same view.")
    bullet(doc, "TLS truststore — per-process bootstrap, no shared state needed.")
    bullet(doc, "Session cookies — HMAC-signed with SESSION_SECRET; as long "
                "as every admin-UI replica has the same secret, cookies are "
                "accepted on any replica.")

    H3(doc, "10.1.2 Load-balancer considerations")
    bullet(doc, "Streaming (SSE) responses hold a TCP connection for the full "
                "generation. Use sticky sessions at the LB (nginx ip_hash or a "
                "cookie-based sticky pool), or accept that an LB failover "
                "mid-stream drops a single completion.")
    bullet(doc, "Health-check the load balancer against /ready (per-dependency "
                "probes — Postgres, Redis, Router built) rather than /healthz "
                "(liveness only).")
    bullet(doc, "Master key + SMTP password + audit AES key must be identical "
                "on every replica (typically injected from a secrets manager).")

    H3(doc, "10.1.3 Recommended topology — 100 developers")
    para(doc,
         "nginx or Traefik with ip_hash routes IDE traffic to 2-3 gateway "
         "replicas. The replicas share one Postgres instance (operational + "
         "audit databases on the same server) and one Redis. The shared "
         "GPU box hosts Qwen3-Coder-30B + Gemma 4 27B via vLLM and is "
         "reachable from each gateway replica.",
         italic=True, color=MUTED, size=10)

    H2(doc, "10.2 Hardware Sizing")

    H3(doc, "10.2.1 Single-box developer install")
    table_grid(doc,
        header=["Component", "RAM", "CPU", "Disk"],
        rows=[
            ("Gateway (uvicorn --workers 1)",
             "~250 MB idle, ~600 MB under load", "1 vCPU", "—"),
            ("Admin UI (next start)",
             "~300 MB", "0.5 vCPU", "—"),
            ("Postgres (both DBs)",
             "1-2 GB", "1 vCPU", "10 GB + audit growth (~2 KB/call)"),
            ("Redis (optional)",
             "100 MB", "0.1 vCPU", "1 GB"),
            ("Total (no GPU)",
             "~4 GB", "2 vCPU", "20 GB"),
        ],
        col_widths_in=[2.4, 1.6, 1.0, 1.6],
        caption="Single-box dev install — fits on a laptop",
    )

    H3(doc, "10.2.2 Production — 100 developers")
    para(doc,
         "Gateway, Postgres, Redis on commodity boxes; the GPU box is sized "
         "for the chosen self-hosted models.")
    table_grid(doc,
        header=["Tier", "RAM", "CPU", "Notes"],
        rows=[
            ("Gateway (2-3 replicas)",
             "8-16 GB", "4-8 vCPU",
             "Each replica ~600 MB; headroom for streaming buffers"),
            ("Postgres",
             "8-16 GB", "4 vCPU",
             "Audit log grows ~100 MB/day at 500 calls/dev/day; plan retention pruning"),
            ("Redis",
             "1 GB", "1 vCPU",
             "Rate-limit counters + response cache"),
            ("GPU box (Qwen3-Coder + Gemma 4 via vLLM)",
             "64 GB", "(GPU)",
             "1× RTX 6000 Ada (48 GB) for 30B + 27B at Q4"),
        ],
        col_widths_in=[2.0, 1.0, 1.0, 2.6],
        caption="Production sizing for ~100 active developers",
    )

    H3(doc, "10.2.3 Audit storage growth")
    para(doc,
         "audit_log row size averages ~2 KB (encrypted body + metadata). "
         "At 500 calls per dev per day × 100 devs × 365 days × 2 KB ≈ "
         "~36 GB / year in the audit DB. The retention pruner "
         "(POST /admin/audit/prune?days=90) is intended to run nightly via "
         "cron; tune the days argument to match your compliance window.")

    H2(doc, "10.3 Parallel-call Capacity")
    para(doc,
         "The honest answer: the gateway itself is almost never the "
         "bottleneck — the inference backend is. The plugin chain runs "
         "asynchronously so most of a request's lifetime is "
         "await-on-backend, not Python work.")

    H3(doc, "10.3.1 Per-stage gateway overhead")
    table_grid(doc,
        header=["Stage", "Typical latency", "Bound by"],
        rows=[
            ("AuthN",           "3-5 ms",                "Postgres latency"),
            ("AuthZ + quota",   "1-2 ms (Redis) / 0.1 ms (memory)",
                                                          "Redis or in-process"),
            ("DLP guardrails",  "2-5 ms",                "Regex pass over the prompt"),
            ("Smart Router",    "< 1 ms",                "Pure CPU"),
            ("Inference",       "30 ms - 60 s",          "Backend (dominant cost)"),
            ("Audit insert",    "3-5 ms",                "Postgres latency"),
            ("Gateway-only overhead", "~10-15 ms total", "Everything except inference"),
        ],
        col_widths_in=[2.0, 2.2, 2.5],
        caption="Per-stage gateway latency budget",
    )

    H3(doc, "10.3.2 Concurrent in-flight per worker")
    para(doc,
         "Because each request spends almost all its lifetime awaiting the "
         "backend, one async uvicorn worker holds many connections open "
         "simultaneously. The cap is set by the backend, not the gateway.")
    table_grid(doc,
        header=["Backend", "Concurrent per worker", "Real bottleneck"],
        rows=[
            ("OpenRouter / cloud (Kimi K2.6)",
             "~500-1000 streams",
             "Provider's per-key rate limit + your daily $ budget"),
            ("vLLM self-host on 1× RTX 6000 Ada (Qwen3-Coder 30B)",
             "8-15 active completions, queued beyond",
             "GPU throughput (40-120 tok/s aggregated, batched)"),
            ("Ollama (smaller local models)",
             "2-3 streams",
             "CPU/GPU + Ollama doesn't auto-batch"),
            ("Mix (Smart Router picks)",
             "Each request takes whichever fits",
             "Mix of above"),
        ],
        col_widths_in=[2.4, 2.0, 2.3],
        caption="Per-backend concurrency limits",
    )

    H3(doc, "10.3.3 Worked example — 100 devs, mixed workload")
    bullet(doc, "30 % to Kimi K2.6 (agent + senior tasks) — cloud, no concurrency limit.")
    bullet(doc, "60 % to Qwen3-Coder-30B — bounded by 1 GPU (vLLM batches ~12 concurrent).")
    bullet(doc, "10 % to Gemma 4 27B — shares the same GPU.")
    para(doc,
         "Typical dev session: ~5 chat completions per hour, ~30 s average "
         "duration. Across 100 devs in peak hour: 100 × 5 = 500 calls/hour "
         "≈ 8 calls/min. Active concurrent at any instant: 500 × 30 s ÷ "
         "3600 s ≈ ~4 concurrent streams. One GPU + one gateway worker "
         "comfortably handles 100 devs at peak with headroom.")
    para(doc,
         "The per-team daily $ budget (quota_redis) and per-team RPM are "
         "the safety nets — not raw capacity.",
         italic=True, color=MUTED, size=10)

    H3(doc, "10.3.4 Scaling levers, in order of cost")
    bullet(doc, "Daily-budget tuning (Settings → App) — cheapest. Caps "
                "overspending without adding hardware.")
    bullet(doc, "Add a second GPU — doubles concurrent self-host capacity.")
    bullet(doc, "Add a second gateway worker (uvicorn --workers 2) — "
                "requires Redis. Doubles gateway-side connection pool.")
    bullet(doc, "Add a second gateway replica behind a load balancer — for "
                "geographic redundancy or zero-downtime deploys.")

    H3(doc, "10.3.5 Hard limits today")
    bullet(doc, "scripts/prod-up.ps1 starts the gateway with --workers 1 "
                "because the in-memory quota counter and in-memory cache "
                "plugins aren't worker-safe. To go multi-worker, switch "
                "GATEWAY_REDIS_URL from memory:// to a real Redis and "
                "re-launch.")
    bullet(doc, "Postgres connection pool: pool_size=5, max_overflow=10 in "
                "db.py — caps ~15 simultaneous Postgres ops per worker. "
                "Fine for hundreds of concurrent streams since most time "
                "is await on the inference backend, not in DB.")
    bullet(doc, "Audit retention: at 500 calls/dev/day × 100 devs, audit DB "
                "grows ~36 GB/year. Run the prune endpoint nightly.")

    doc.add_page_break()

    # ---- 11. Operations --------------------------------------------------
    H1(doc, "11. Operations Runbook")
    table_kv(doc, [
        ("Bring up (dev)",      "scripts/dev-up.ps1"),
        ("Bring up (prod)",     "scripts/prod-up.ps1   (-WithObs for Prom/Grafana)"),
        ("Tear down",           "scripts/prod-down.ps1"),
        ("Gateway port",        "4000  · /v1/chat/completions · /v1/models · /admin/*"),
        ("Admin UI port",       "3010  · sidebar grouped by pipeline stage"),
        ("Observability",       "Grafana :3001 · Prometheus :9090 · Alertmanager :9093"),
        ("Health endpoints",    "/healthz (live) · /ready (per-dep) · /metrics (Prom)"),
        ("Audit retention",     "POST /admin/audit/prune?days=90  (nightly cron)"),
        ("Backups",             "pg_dump operational + audit; both stored encrypted."),
    ], caption="Day-to-day operations reference")

    doc.add_page_break()

    # ---- Appendices -----------------------------------------------------
    H1(doc, "Appendix A · Public endpoints")
    table_kv(doc, [
        ("POST /v1/chat/completions",
         "OpenAI-compatible chat (alias: /chat/completions)"),
        ("GET  /v1/models",
         "Model discovery (alias: /models)"),
        ("GET  /admin/teams",
         "Team registry"),
        ("PUT  /admin/teams/{team_id}",
         "Upsert team (tier + description)"),
        ("DELETE /admin/teams/{team_id}",
         "Delete team (refused 409 if active keys reference it)"),
        ("POST /admin/keys",
         "Issue a virtual API key"),
        ("DELETE /admin/keys/{key_id}",
         "Revoke key (idempotent 204)"),
        ("GET  /admin/providers/openrouter",
         "Read OpenRouter key state (returns prefix only)"),
        ("PUT  /admin/providers/openrouter",
         "Set / clear OpenRouter API key"),
        ("GET  /admin/providers/openrouter/models",
         "OpenRouter catalog (cached 5 min)"),
        ("POST /admin/providers/openrouter/import",
         "Import an OpenRouter model into the registry"),
        ("GET  /admin/metrics/cost-forecast",
         "Burn-rate projection (window_days × projection_days)"),
        ("GET  /admin/metrics/spend-by-model",
         "Per-model $USD/hour (gated by toggle)"),
        ("GET  /admin/settings/spend-by-model",
         "Read master cost-metrics toggle"),
        ("PUT  /admin/settings/spend-by-model",
         "Flip cost-metrics toggle"),
        ("POST /admin/models/{id}/ping",
         "One-shot availability probe"),
        ("POST /admin/audit/prune?days=N",
         "Retention sweep (dry_run by default)"),
    ], caption="Public HTTP endpoint catalogue")

    H1(doc, "Appendix B · Environment variables")
    table_kv(doc, [
        ("GATEWAY_ENVIRONMENT",   "production | dev | test  (sk-dev+ disabled in production)"),
        ("GATEWAY_MASTER_KEY",    "Server-only. Never reaches the browser."),
        ("GATEWAY_DB_URL",        "Postgres operational DSN."),
        ("GATEWAY_AUDIT_DB_URL",  "Postgres audit DSN."),
        ("GATEWAY_REDIS_URL",     "Real Redis for prod; 'memory://' for dev."),
        ("GATEWAY_PLUGINS",       "Comma-separated entry-point names to load."),
        ("OLLAMA_API_BASE",       "http://localhost:11434/v1  (trailing /v1 required)."),
        ("OPENROUTER_API_KEY",    "Env fallback when UI-managed key is not set."),
        ("SESSION_SECRET",        "HMAC key for admin-ui cookie. Stable across restarts (.env.local)."),
    ], caption="Server environment variables")

    H1(doc, "Appendix C · Troubleshooting")
    bullet(doc, "CERTIFICATE_VERIFY_FAILED from gateway → SSL-inspecting AV is "
                "intercepting upstream HTTPS. truststore handles this on Win; "
                "verify gateway/__init__.py imports truststore before any HTTP client.")
    bullet(doc, "IDE returns '404 status code (no body)' → the SDK calls "
                "/chat/completions (no /v1). The gateway aliases both; check "
                "Base URL and that the virtual key is still active.")
    bullet(doc, "Admin UI shows 'Unauthorised' → cookie expired (24 h TTL). "
                "Log out and back in.")
    bullet(doc, "DELETE /admin/keys/{id} returning 404 → fixed; now 204 "
                "idempotently regardless of prior state (RFC 9110 alignment).")

    doc.save(OUT)
    print(f"wrote {OUT}")


if __name__ == "__main__":
    build()
