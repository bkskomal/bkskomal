# Production Deployment Guide

This guide covers what you actually need to think about when running the
LiteLLM Gateway in production. The `scripts/prod-up.ps1` script handles
the local-single-host case; for everything beyond that, the recommendations
below are minimal-viable, not aspirational.

## 1. Topology

```
                           ┌─────────────────────────────────┐
   developer browser ───►  │ nginx / Caddy / Traefik         │  ◄── TLS termination
                           │ (one of: 443/80)                │      HSTS, gzip
                           └────────┬────────┬───────────────┘
                                    │        │
                            /api/*  │        │  /
                              ▼     │        ▼
                  ┌───────────────────┐  ┌────────────────────┐
                  │ gateway (uvicorn) │  │ admin-ui (next start)│
                  │ :4000             │  │ :3000                │
                  └────┬────┬─────────┘  └────────────────────┘
                       │    │
                       │    │  POST /v1/chat/completions
                       │    ▼
                       │  ┌────────────┐    ┌────────────┐
                       │  │ Ollama      │   │ OpenRouter │
                       │  │ (self-host) │   │ (cloud)    │
                       │  └────────────┘    └────────────┘
                       │
              ┌────────┴──────┬──────────────┬──────────────┐
              ▼               ▼              ▼              ▼
       ┌──────────────┐ ┌──────────────┐ ┌─────────┐  ┌──────────────┐
       │  Postgres    │ │  Postgres    │ │ Redis   │  │ Prometheus + │
       │  operational │ │  audit_log   │ │ (HA)    │  │ Grafana      │
       └──────────────┘ └──────────────┘ └─────────┘  └──────────────┘
```

## 2. Required environment variables

```bash
# Identities
GATEWAY_ENVIRONMENT=production          # disables sk-dev+ tokens (CRITICAL)
GATEWAY_MASTER_KEY=<32-byte-random>      # rotate every 90 days
GATEWAY_JWT_SECRET=<32-byte-random>

# Persistence
GATEWAY_DB_URL=postgresql+asyncpg://gw_user:<pwd>@pg.internal/litellm_gateway
GATEWAY_AUDIT_DB_URL=postgresql+asyncpg://gw_user:<pwd>@pg.internal/litellm_gateway_audit
GATEWAY_REDIS_URL=redis://redis.internal:6379/0   # NOT memory:// in prod

# Models
OLLAMA_API_BASE=http://ollama.internal:11434/v1    # /v1 IS required
OPENROUTER_API_KEY=<your-or-key>

# Optional but recommended
GATEWAY_AUDIT_KEY=<base64-32-bytes>     # enables AES-GCM ciphertext for 4-eyes reveal
GATEWAY_GRAFANA_URL=https://grafana.internal
SIEM_WEBHOOK_URL=https://splunk.internal:8088/services/collector
SIEM_AUTH_TOKEN=<splunk-hec-token>
```

The gateway will print **`PROD-CONFIG: ...`** warnings at boot for every
misconfigured slot. Read them.

## 3. TLS / reverse proxy

The gateway and admin UI both bind plain HTTP on `:4000` / `:3000`. Put
nginx / Caddy / Traefik / a cloud LB in front for TLS. Minimal nginx:

```nginx
server {
    listen 443 ssl http2;
    server_name gateway.example.com;

    ssl_certificate     /etc/letsencrypt/live/gateway.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/gateway.example.com/privkey.pem;

    # Admin UI — most requests
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Gateway API — chat-completions etc.
    location /v1/ {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_buffering off;                # streaming SSE
        proxy_read_timeout 600s;            # long completions
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /admin/ { proxy_pass http://127.0.0.1:4000; }
    location /metrics { proxy_pass http://127.0.0.1:4000; }
    location /health  { proxy_pass http://127.0.0.1:4000; }
    location /ready   { proxy_pass http://127.0.0.1:4000; }
}
```

The gateway's uvicorn is launched with `--proxy-headers` so `X-Forwarded-For`
and `X-Forwarded-Proto` propagate to logs and audit rows.

## 4. Health checks

| Probe | Port | Path | What it checks |
|---|---|---|---|
| Liveness | 4000 | `/health` | Process up. Cheap, no I/O. Use for `livenessProbe`. |
| Readiness | 4000 | `/ready` | Postgres (both DBs) + Redis + Ollama + LLM router + plugin chain. 503 if any required dep is down. Use for `readinessProbe`. |

`readinessProbe` example (kubelet):

```yaml
readinessProbe:
  httpGet:
    path: /ready
    port: 4000
  initialDelaySeconds: 10
  periodSeconds: 5
  failureThreshold: 3
```

## 5. Database hygiene

### Schema changes

Currently the gateway uses `Base.metadata.create_all` at lifespan boot —
fine for fresh deploys, brittle for schema evolution. **Future work**:
land Alembic for versioned migrations. Until then, schema changes are a
**careful manual `ALTER TABLE`** before deploying the new gateway version.

### Audit log retention

`audit_log` grows ~2 KB per chat call. At 100 req/s that's ~17 GB/day.
Use the retention endpoint on a cron:

```bash
# /etc/cron.daily/litellm-audit-prune
#!/bin/sh
curl -sS -X POST \
     -H "Authorization: Bearer $GATEWAY_MASTER_KEY" \
     "https://gateway.internal/admin/audit/prune?days=90&dry_run=false" \
     | jq .
```

The endpoint refuses `days<=0` and `days>3650` so a misconfigured
cron can't wipe the table.

### Backups

```bash
# Daily, kept 14 days locally + push to S3.
pg_dump -F c -h pg.internal -U gw_user litellm_gateway       > /backup/op-$(date +%F).dump
pg_dump -F c -h pg.internal -U gw_user litellm_gateway_audit > /backup/audit-$(date +%F).dump
aws s3 cp /backup/ s3://my-backups/gateway/ --recursive
find /backup -mtime +14 -delete
```

## 6. Multi-worker / horizontal scale

The gateway boots with `--workers 1` by default. Plugin state (UEBA
counters, rate limits, response cache, JIT-elevation cache) lives in
the worker process. To scale horizontally:

1. **Switch to real Redis** (`GATEWAY_REDIS_URL=redis://...`). All
   plugins fall back to in-memory automatically if Redis is unreachable
   — production is the wrong place for that fallback.
2. **Bump worker count** in the uvicorn command:
   `--workers $(nproc)` is a fine starting point.
3. **Run multiple gateway pods/instances**. Each instance reads / writes
   to the same shared Postgres + Redis, so plugin state is consistent.
4. **Sticky sessions are NOT required** (no per-instance state).

The audit DB and operational DB are written to by every instance — make
sure your Postgres can handle the connection pool count
(`max_connections >= workers × instances × pool_size`).

## 7. Secrets management

Don't ship `.env` files. Either:

* **Docker / Kubernetes Secrets**: mounted as env vars or files. The gateway
  reads env vars at boot; one-time read is fine.
* **HashiCorp Vault / AWS Secrets Manager**: pull at startup via a wrapper
  script that exports env vars before launching uvicorn.
* **Cloud-provider IAM**: for `OPENROUTER_API_KEY` etc., consider a
  short-lived rotating token.

`GATEWAY_AUDIT_KEY` is the most sensitive — it decrypts the audit log
ciphertext. Rotate annually; document the previous key alongside the
audit rows it encrypted.

## 8. Observability

Bring up the obs profile:

```bash
docker compose --profile obs up -d prometheus grafana alertmanager
```

Grafana dashboards are auto-provisioned from `docs/grafana/*.json`. Set
`GATEWAY_GRAFANA_URL` so the Observability Bus pill on the admin
Overview page links to it.

Wire Alertmanager to your real notification system — the default
`docker/alertmanager/alertmanager.yml` ships with a dev webhook; replace
it with PagerDuty / Slack / OpsGenie.

## 9. Common production gotchas

| Symptom | Likely cause |
|---|---|
| Streaming chat completions hang | Reverse proxy is buffering SSE. Set `proxy_buffering off` (nginx) or equivalent. |
| Per-user UEBA counters reset unexpectedly | `GATEWAY_REDIS_URL=memory://` + uvicorn reloaded. Switch to real Redis. |
| Audit DB disk filling up | Forgot to set up the retention cron. See §5. |
| Cline / Continue / aider getting 401 | `GATEWAY_ENVIRONMENT=production` (correctly) refuses `sk-dev+` tokens. Issue a real DB key via `/connect`. |
| Cost numbers all zero | Model registry has no `cost_per_1k_input`/`cost_per_1k_output`. Edit via `/settings` (Models). |
| Plugin config edits "don't take" across workers | In-memory plugin state. Real Redis fixes it. |
| `/ready` returns 503 with `ollama: false` | OLLAMA_API_BASE missing `/v1` suffix, or Ollama service down. |

## 10. Recovery runbook

* **Gateway down**: check `/health` (process), `/ready` (dependencies). If a single dep is down (Redis, Ollama), most paths still work — admin UI is still useful for triage.
* **Audit DB out of disk**: prune to a shorter retention. The gateway keeps writing to operational DB so chat traffic isn't affected; you just lose new audit rows.
* **All keys leaked**: rotate `GATEWAY_MASTER_KEY`, then revoke + reissue every team's DB keys via `/admin/keys`. Old keys hash-mismatch on lookup and return 401.
* **One user compromised**: their UEBA radar will redline; `/keys` shows the quarantine badge. Use `/admin/ueba/user/{id}/restore-keys` only after manual review.

## Future work tracked here

* **Alembic migrations** — replace `create_all`. Plan: `alembic init`, one baseline covering all current tables, swap lifespan to `alembic upgrade head`.
* **OIDC / SSO** — replace `admin / admin` literal in the admin UI. Requires an IdP decision.
* **Semantic cache** — currently exact-hash only. Embedding similarity over recent prompts would catch near-duplicates (this is the biggest single feature gap vs Portkey / Helicone).
* **Trace IDs** — group multi-call sessions in audit_log via an `X-Gateway-Trace` header.
