"""Generate docs/LLMGateway-Implementation.pptx.

Reframed deck: Requirement → Architecture → Implementation. No roadmap /
timeline slides. Three model picks: Kimi K2.6, Qwen3-Coder-30B, Gemma 4 27B.

Design lifted from:
  E:/AI/Claude/ReviewnComparison/Developer_Box_Integration_Roadmap_pending.pptx
  E:/AI/Claude/ReviewnComparison/build_gateway_hero_slide.py

Wide 16:9 canvas (13.33 × 7.5 in), navy title slide with vertical red
accent, light content slides with a navy top bar + 'PROPRIETARY' footer.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Emu, Inches, Pt


DOCS = Path(__file__).resolve().parent
OUT  = DOCS / "LLMGateway-Implementation.pptx"
LOGO = DOCS / "oati-assets" / "image1.png"
ARCH = DOCS / "architecture.png"


# -----------------------------------------------------------------------------
# Design tokens (sampled from the pending roadmap + hero slide)
# -----------------------------------------------------------------------------
NAVY      = RGBColor(0x14, 0x1F, 0x3B)       # title slide bg
NAVY_BAR  = RGBColor(0x1B, 0x2A, 0x4E)       # content slide top bar
RED       = RGBColor(0xC8, 0x2A, 0x32)       # accent
BLUE      = RGBColor(0x2E, 0x86, 0xAB)       # subtitle / primary
LIGHT_BG  = RGBColor(0xF5, 0xF7, 0xFA)       # content slide bg
PANEL_BG  = RGBColor(0xFF, 0xFF, 0xFF)       # cards
GRID      = RGBColor(0xD0, 0xD7, 0xDE)       # card borders
TEXT_DARK = RGBColor(0x1A, 0x1A, 0x1A)
TEXT_LIGHT= RGBColor(0xFF, 0xFF, 0xFF)
MUTED     = RGBColor(0x6B, 0x72, 0x80)
EYEBROW   = RGBColor(0x9C, 0xA3, 0xAF)

# Section pill palette (4 tones used across the hero + content slides)
PILL_BLUE   = RGBColor(0x4A, 0x90, 0xE2)
PILL_PURPLE = RGBColor(0x82, 0x4D, 0xE0)
PILL_RED    = RGBColor(0xC8, 0x2A, 0x32)
PILL_GREEN  = RGBColor(0x2E, 0x7D, 0x32)
PILL_ORANGE = RGBColor(0xE6, 0x86, 0x2A)


# -----------------------------------------------------------------------------
# Primitive helpers
# -----------------------------------------------------------------------------
def set_text(tf, text, *, size=14, bold=False, italic=False, color=None,
             font="Calibri", align=None, anchor=None):
    tf.clear()
    p = tf.paragraphs[0]
    if align is not None:
        p.alignment = align
    if anchor is not None:
        tf.vertical_anchor = anchor
    run = p.add_run()
    run.text = text
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color
    return run


def add_text(slide, x, y, w, h, text, *, size=14, bold=False, italic=False,
             color=TEXT_DARK, font="Calibri", align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.TOP, word_wrap=True):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tb.text_frame.word_wrap = word_wrap
    tb.text_frame.margin_left = Inches(0.04)
    tb.text_frame.margin_right = Inches(0.04)
    tb.text_frame.margin_top = Inches(0.02)
    tb.text_frame.margin_bottom = Inches(0.02)
    set_text(tb.text_frame, text, size=size, bold=bold, italic=italic,
             color=color, font=font, align=align, anchor=anchor)
    return tb


def add_rect(slide, x, y, w, h, *, fill=NAVY, line=None, line_w=None,
             radius_pct=0):
    shape = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if radius_pct else MSO_SHAPE.RECTANGLE,
        Inches(x), Inches(y), Inches(w), Inches(h),
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = line
        if line_w is not None:
            shape.line.width = Pt(line_w)
    if radius_pct:
        try: shape.adjustments[0] = radius_pct / 100
        except Exception: pass
    return shape


def add_arrow(slide, x, y, w, h, *, color=RED, direction="right"):
    sh = MSO_SHAPE.RIGHT_ARROW if direction == "right" else MSO_SHAPE.DOWN_ARROW
    s = slide.shapes.add_shape(sh, Inches(x), Inches(y), Inches(w), Inches(h))
    s.fill.solid(); s.fill.fore_color.rgb = color
    s.line.fill.background()
    return s


def chrome(slide, eyebrow: str, title: str):
    """Navy top bar + OATI logo + title + bottom 'PROPRIETARY' band."""
    add_rect(slide, 0, 0, 13.33, 7.50, fill=LIGHT_BG)
    add_rect(slide, 0, 0, 13.33, 0.70, fill=NAVY_BAR)
    if LOGO.exists():
        slide.shapes.add_picture(str(LOGO), Inches(0.20), Inches(0.08),
                                 width=Inches(0.68), height=Inches(0.54))
    add_text(slide, 1.00, 0.10, 9.00, 0.30, eyebrow,
             size=9, bold=True, color=EYEBROW, font="Calibri")
    add_text(slide, 1.00, 0.30, 11.00, 0.45, title,
             size=18, bold=True, color=TEXT_LIGHT,
             font="Calibri", anchor=MSO_ANCHOR.MIDDLE)
    # Footer band
    add_rect(slide, 0, 7.20, 13.33, 0.30, fill=NAVY_BAR)
    add_text(slide, 0.30, 7.22, 12.7, 0.26,
             f"PROPRIETARY AND CONFIDENTIAL  |  Open Access Technology International  |  {date.today().year}",
             size=9, color=RGBColor(0xCF, 0xD4, 0xDC), font="Calibri",
             anchor=MSO_ANCHOR.MIDDLE)


# -----------------------------------------------------------------------------
# Slide builders
# -----------------------------------------------------------------------------
def slide_title(prs):
    """Hero — navy bg, vertical red strip, model chips for the three picks."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    add_rect(s, 0, 0, 13.33, 7.50, fill=NAVY)
    # Vertical red accent at left of the right-hand panel
    add_rect(s, 9.50, 0, 0.06, 7.50, fill=RED)

    # Logo top-left
    if LOGO.exists():
        s.shapes.add_picture(str(LOGO), Inches(0.45), Inches(0.40),
                             width=Inches(1.20), height=Inches(0.96))
    add_text(s, 0.45, 1.45, 4.0, 0.30, "OATI Technology",
             size=11, bold=True, color=TEXT_LIGHT, font="Calibri Light")

    # Title block
    add_text(s, 0.50, 2.20, 8.50, 1.10,
             "Developer Box Integration",
             size=44, bold=True, color=TEXT_LIGHT, font="Calibri Light")
    add_text(s, 0.50, 3.20, 8.50, 0.70,
             "Coding Models served behind LLMGateway",
             size=24, color=BLUE, font="Calibri Light")
    add_text(s, 0.50, 3.90, 8.50, 0.50,
             "Requirement · Architecture · Implementation",
             size=14, color=MUTED, font="Calibri Light")

    # Three model chips
    chips = [
        ("Kimi K2.6",         PILL_PURPLE, "Premium — cloud"),
        ("Qwen3-Coder-30B",   PILL_BLUE,   "Workhorse — self-host"),
        ("Gemma 4 27B",       PILL_GREEN,  "Economy — self-host"),
    ]
    chip_x = 0.50
    for label, fill, sub in chips:
        add_rect(s, chip_x, 4.75, 2.80, 0.55, fill=fill, radius_pct=30)
        add_text(s, chip_x, 4.75, 2.80, 0.55, label,
                 size=12, bold=True, color=TEXT_LIGHT,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE,
                 font="Calibri")
        add_text(s, chip_x, 5.35, 2.80, 0.30, sub,
                 size=9, color=RGBColor(0xCF, 0xD4, 0xDC),
                 align=PP_ALIGN.CENTER, font="Calibri")
        chip_x += 2.95

    # Right-side highlight panel
    add_text(s, 9.90, 0.60, 3.20, 0.50, "This deck answers",
             size=11, color=MUTED, font="Calibri")
    add_text(s, 9.90, 0.95, 3.20, 0.55, "What we built, why, and how",
             size=15, bold=True, color=TEXT_LIGHT, font="Calibri Light")

    highlights = [
        "Why route through a gateway",
        "Which models, hosted where",
        "Plugin chain — 6 stages",
        "Threats and controls",
        "Operations runbook",
    ]
    for i, b in enumerate(highlights):
        y = 1.85 + i * 0.55
        add_rect(s, 9.90, y, 0.06, 0.45, fill=RED)
        add_text(s, 10.05, y, 3.15, 0.45, b,
                 size=11, color=TEXT_LIGHT, font="Calibri",
                 anchor=MSO_ANCHOR.MIDDLE)

    add_text(s, 0.50, 7.00, 8.0, 0.30,
             f"Prepared by OATI Technology  ·  {date.today().strftime('%B %Y')}",
             size=10, color=MUTED, font="Calibri")
    return s


def slide_motivation(prs):
    """Why now — goals + non-goals + drivers."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "REQUIREMENT", "Why we need a gateway between developers and models")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "Self-hosted coding models hit a usability tipping point in 2025. "
             "We can match cloud quality on common dev tasks without exposing "
             "source code or paying per-seat licences — provided we control the rollout.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    # Goals card
    add_rect(s, 0.50, 1.65, 6.10, 4.95, fill=PANEL_BG, line=GRID,
             line_w=0.75, radius_pct=4)
    add_rect(s, 0.50, 1.65, 6.10, 0.50, fill=PILL_GREEN, radius_pct=0)
    add_text(s, 0.70, 1.65, 5.90, 0.50, "GOALS",
             size=12, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)

    goals = [
        ("Developer productivity",  "autocomplete, refactor, test generation"),
        ("IP control",              "no source code leaves our network"),
        ("Cost predictability",     "fixed compute spend, no per-seat AI licences"),
        ("Vendor independence",     "open weights, OpenAI-compatible API"),
        ("Compliance posture",      "full audit trail on every prompt/response"),
        ("Centralised control",     "tier ACL, DLP, budgets, UEBA enforced server-side"),
    ]
    for i, (k, v) in enumerate(goals):
        y = 2.30 + i * 0.65
        add_rect(s, 0.70, y, 0.10, 0.45, fill=PILL_GREEN)
        add_text(s, 0.90, y, 2.20, 0.45, k, size=11, bold=True,
                 color=NAVY_BAR, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, 3.10, y, 3.40, 0.45, v, size=10.5,
                 color=TEXT_DARK, anchor=MSO_ANCHOR.MIDDLE)

    # Non-goals card
    add_rect(s, 6.80, 1.65, 6.05, 4.95, fill=PANEL_BG, line=GRID,
             line_w=0.75, radius_pct=4)
    add_rect(s, 6.80, 1.65, 6.05, 0.50, fill=MUTED)
    add_text(s, 7.00, 1.65, 5.85, 0.50, "NON-GOALS",
             size=12, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)

    nongoals = [
        ("Replacing senior judgement, code review, or PR approvals."),
        ("Mandatory adoption — opt-in pilot first, expand by evidence."),
        ("Matching frontier (GPT/Claude) on novel research tasks."),
        ("Replacing existing IDEs / dev tooling — additive, not disruptive."),
        ("Public-facing AI features — internal dev tooling only."),
        ("On-laptop GPU inference — all hosting is centralised."),
    ]
    for i, txt in enumerate(nongoals):
        y = 2.30 + i * 0.65
        add_rect(s, 7.00, y, 0.10, 0.45, fill=MUTED)
        add_text(s, 7.20, y, 5.55, 0.45, txt, size=11,
                 color=TEXT_DARK, anchor=MSO_ANCHOR.MIDDLE)
    return s


def slide_models(prs):
    """The three picks — Kimi / Qwen3 / Gemma."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "MODELS · 3 PICKS", "Three coding models behind the same gateway")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "All three are reached via the same LLMGateway endpoint. "
             "Two are self-hosted on a shared GPU box via vLLM; one is "
             "cloud-routed. Developers see them as interchangeable IDs in the model picker.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    models = [
        ("KIMI K2.6", "PRIMARY · Premium",  PILL_PURPLE,
         "Cloud-routed via Moonshot / OpenRouter",
         "Best architectural discipline + multi-turn",
         "~1T params (32B active MoE) — too large to self-host",
         "Pay-per-token; gateway enforces team budget",
         "Use for: senior devs, complex agent tasks"),
        ("QWEN3-CODER-30B", "SECONDARY · Workhorse", PILL_BLUE,
         "Self-hosted on shared GPU box via vLLM",
         "Apache 2.0 — commercial use OK",
         "30B params (~3B active MoE), 256k context",
         "Zero per-token cost; bounded by GPU",
         "Use for: everyday chat, codebase Q&A, refactors"),
        ("GEMMA 4 27B", "TERTIARY · Economy", PILL_GREEN,
         "Self-hosted on same GPU box via vLLM",
         "Google open-weights coding model",
         "Smaller footprint than the 30B",
         "Different tokenizer — catches blind spots",
         "Use for: A/B comparisons, fallback at peak"),
    ]
    card_w, card_h = 4.10, 5.20
    x0, gap = 0.50, 0.20
    for i, (title, tier, color, *lines) in enumerate(models):
        x = x0 + i * (card_w + gap)
        add_rect(s, x, 1.50, card_w, card_h, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x, 1.50, card_w, 0.55, fill=color)
        add_text(s, x + 0.20, 1.50, card_w - 0.40, 0.30, tier,
                 size=9, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, x + 0.20, 1.80, card_w - 0.40, 0.30, title,
                 size=15, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        for j, line in enumerate(lines):
            y = 2.30 + j * 0.55
            add_rect(s, x + 0.20, y + 0.20, 0.06, 0.20, fill=color)
            add_text(s, x + 0.32, y, card_w - 0.50, 0.55, line,
                     size=10.5, color=TEXT_DARK, anchor=MSO_ANCHOR.MIDDLE)

    add_text(s, 0.50, 6.80, 12.3, 0.30,
             "Why not other contenders? DeepSeek V4 Pro is proprietary — can't self-host. "
             "Smaller Qwen variants don't suit the centralised GPU box plan.",
             size=10, italic=True, color=MUTED, align=PP_ALIGN.CENTER, font="Calibri")
    return s


def slide_hardware(prs):
    """Three deployment lanes — laptop / GPU box / cloud."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "INFRASTRUCTURE", "Hardware reality — centralised, not on dev boxes")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "Developer laptops have no GPU and host no models. All inference "
             "happens behind a central LLMGateway — a mix of self-hosted "
             "(Qwen3-Coder, Gemma 4) and cloud-routed (Kimi K2.6) backends.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    lanes = [
        ("Developer laptop", "no GPU", PILL_BLUE, [
            ("Spec",     "i5/i7 · 16-32 GB RAM · integrated graphics OK"),
            ("Runs",     "VS Code + Continue + Cline · Antigravity IDE"),
            ("Hosts",    "NO local model · talks only to gateway"),
            ("Network",  "mTLS to LLMGateway URL"),
            ("Auth",     "Personal API key bound to SSO identity"),
            ("Cost",     "Zero hardware upgrade per developer"),
        ]),
        ("Shared GPU box", "self-host inference", PILL_RED, [
            ("Spec",     "1× RTX 6000 Ada (48 GB) or RTX 3090 (24 GB)"),
            ("Runs",     "vLLM (PagedAttention, batched throughput)"),
            ("Hosts",    "Qwen3-Coder-30B-A3B · Gemma 4 27B"),
            ("Perf",     "40-120 tok/s · 8-15 concurrent devs"),
            ("Network",  "Private VLAN, no egress, gateway-only"),
            ("Sizing",   "1 GPU per ~10 active devs"),
        ]),
        ("Cloud backend", "Kimi K2.6", PILL_PURPLE, [
            ("Spec",     "No hardware — Moonshot / OpenRouter API"),
            ("Runs",     "Kimi K2.6 (1T params, ~32B active MoE)"),
            ("Hosts",    "Provider-hosted; we route via gateway"),
            ("Perf",     "60-120 tok/s · effectively unlimited"),
            ("Network",  "Outbound from gateway · DLP-scrubbed"),
            ("Cost",     "Pay-per-token · budgeted per team"),
        ]),
    ]
    card_w, gap = 4.10, 0.20
    x0 = 0.50
    for i, (name, sub, color, rows) in enumerate(lanes):
        x = x0 + i * (card_w + gap)
        add_rect(s, x, 1.55, card_w, 5.10, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x, 1.55, card_w, 0.65, fill=color)
        add_text(s, x + 0.20, 1.55, card_w - 0.40, 0.32, name,
                 size=14, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, x + 0.20, 1.85, card_w - 0.40, 0.30, sub,
                 size=10, color=RGBColor(0xE5, 0xE7, 0xEB), anchor=MSO_ANCHOR.MIDDLE)
        for j, (k, v) in enumerate(rows):
            y = 2.40 + j * 0.65
            add_text(s, x + 0.20, y, 0.85, 0.30, k.upper(),
                     size=9, bold=True, color=MUTED)
            add_text(s, x + 0.20, y + 0.25, card_w - 0.40, 0.40, v,
                     size=10.5, color=TEXT_DARK)
    return s


def slide_backends(prs):
    """vLLM (self-host) vs Cloud API — comparison table."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "RUNTIME", "Inference backends — vLLM (self-host) vs Cloud API")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "Both modes expose OpenAI-compatible HTTP APIs. The gateway "
             "translates between provider quirks; IDE plugins never know "
             "or care which backend served their request.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    cols = ["Aspect", "vLLM · Qwen3 / Gemma 4 (self-host)", "Cloud API · Kimi K2.6"]
    rows = [
        ("Hardware we run",   "1× shared GPU box (RTX 6000 Ada / 3090)", "None — provider runs it"),
        ("Throughput",        "40-120 tok/s (batched)",                    "60-120 tok/s (provider-batched)"),
        ("Concurrency",       "8-15 active devs / GPU",                    "Effectively unlimited"),
        ("Cost model",        "Capex + power · zero per-token",            "Per-token · budgeted per team"),
        ("Network egress",    "Stays inside our VLAN",                     "Outbound from gateway · DLP-scrubbed"),
        ("Data residency",    "Fully on-prem",                             "Sent to provider · logged in audit"),
        ("Failure mode",      "GPU box down → both models down",           "Provider outage · gateway can fail-over"),
        ("Best for",          "Bulk traffic, daily chat, autocomplete",    "Senior devs, complex agent tasks"),
    ]

    table_x, table_y = 0.50, 1.60
    table_w, row_h = 12.30, 0.42
    col_widths = [3.30, 4.50, 4.50]

    # Header
    add_rect(s, table_x, table_y, table_w, row_h, fill=NAVY_BAR)
    cx = table_x
    for i, c in enumerate(cols):
        add_text(s, cx + 0.15, table_y, col_widths[i] - 0.2, row_h, c,
                 size=11, bold=True, color=TEXT_LIGHT,
                 font="Calibri", anchor=MSO_ANCHOR.MIDDLE)
        cx += col_widths[i]

    # Body
    for r, (a, b, c) in enumerate(rows):
        y = table_y + (r + 1) * row_h
        if r % 2 == 0:
            add_rect(s, table_x, y, table_w, row_h, fill=PANEL_BG)
        else:
            add_rect(s, table_x, y, table_w, row_h, fill=LIGHT_BG)
        cx = table_x
        for i, val in enumerate((a, b, c)):
            add_text(s, cx + 0.15, y, col_widths[i] - 0.2, row_h, val,
                     size=10.5,
                     bold=(i == 0),
                     color=(NAVY_BAR if i == 0 else TEXT_DARK),
                     anchor=MSO_ANCHOR.MIDDLE)
            cx += col_widths[i]

    add_text(s, 0.50, 6.40, 12.3, 0.35,
             "Decision · vLLM on one shared GPU box for Qwen3-Coder + Gemma 4; "
             "cloud API for Kimi K2.6; both fronted by the same LLMGateway.",
             size=11, bold=True, color=NAVY_BAR, font="Calibri Light")
    add_text(s, 0.50, 6.75, 12.3, 0.30,
             "Dev laptops host nothing.",
             size=10, italic=True, color=MUTED, font="Calibri")
    return s


def slide_ide(prs):
    """IDE & Tooling — VS Code + Antigravity + plugins."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "TOOLING", "IDE & plugins — same gateway, your choice of flow")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "Two IDEs supported, two complementary plugins. Every plugin "
             "points at the same gateway URL and uses a personal API key "
             "bound to SSO identity.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    panes = [
        ("VS Code + Continue", PILL_BLUE,
         ["Free, MIT-based IDE",
          "Continue: inline chat + autocomplete",
          "Talks to /v1/chat/completions",
          "Best for: autocomplete-heavy workflows"]),
        ("VS Code + Cline", PILL_PURPLE,
         ["Same IDE, autonomous agent flavour",
          "Multi-step file edits, tool use",
          "Talks to /v1/chat/completions",
          "Best for: refactors, codebase Q&A"]),
        ("Antigravity IDE", PILL_ORANGE,
         ["Google-native AI IDE (free)",
          "Built-in chat + agent + autocomplete",
          "Same OpenAI-compatible base URL",
          "Best for: greenfield agent flows"]),
    ]
    card_w, gap = 4.10, 0.20
    x0 = 0.50
    for i, (name, color, items) in enumerate(panes):
        x = x0 + i * (card_w + gap)
        add_rect(s, x, 1.55, card_w, 5.10, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x, 1.55, card_w, 0.55, fill=color)
        add_text(s, x + 0.20, 1.55, card_w - 0.40, 0.55, name,
                 size=14, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        for j, item in enumerate(items):
            y = 2.30 + j * 0.85
            add_rect(s, x + 0.20, y + 0.10, 0.06, 0.45, fill=color)
            add_text(s, x + 0.35, y, card_w - 0.55, 0.65, item,
                     size=11, color=TEXT_DARK, anchor=MSO_ANCHOR.MIDDLE)

    add_text(s, 0.50, 6.80, 12.3, 0.30,
             "Common config: Base URL = your gateway; API Key = SSO-issued virtual key.",
             size=11, italic=True, color=MUTED, font="Calibri Light",
             align=PP_ALIGN.CENTER)
    return s


def slide_architecture_hero(prs):
    """Hero — 3-lane diagram (IDE → Gateway → Models) + observability + value props."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "ARCHITECTURE", "LLMGateway — the whole story on one page")

    # Lane labels
    add_text(s, 0.40, 0.95, 2.80, 0.30, "DEVELOPER IDEs",
             size=11, bold=True, color=MUTED, align=PP_ALIGN.CENTER)
    add_text(s, 3.85, 0.95, 5.60, 0.30, "POLICY-ORIENTED GATEWAY",
             size=11, bold=True, color=RED, align=PP_ALIGN.CENTER)
    add_text(s, 10.00, 0.95, 3.00, 0.30, "MODEL BACKENDS",
             size=11, bold=True, color=MUTED, align=PP_ALIGN.CENTER)

    # ---- LEFT — Devs ----
    devs = [
        ("VS Code + Continue", "autocomplete · chat",  PILL_BLUE),
        ("VS Code + Cline",    "autonomous agent",     PILL_PURPLE),
        ("Antigravity IDE",    "native AI agent",      PILL_ORANGE),
    ]
    dx, dw, dh, dy0 = 0.40, 2.80, 1.20, 1.30
    for i, (name, sub, col) in enumerate(devs):
        dy = dy0 + i * 1.35
        add_rect(s, dx, dy, dw, dh, fill=PANEL_BG, line=GRID, line_w=0.75)
        add_rect(s, dx, dy, 0.12, dh, fill=col)
        add_text(s, dx + 0.22, dy + 0.10, dw - 0.30, 0.36, name,
                 size=13, bold=True, color=NAVY_BAR)
        add_text(s, dx + 0.22, dy + 0.48, dw - 0.30, 0.30, sub,
                 size=10, italic=True, color=MUTED)
        add_text(s, dx + 0.22, dy + 0.80, dw - 0.30, 0.30,
                 "personal API key (SSO-bound)",
                 size=9, color=PILL_BLUE)

    # Arrows from devs to gateway
    for i in range(3):
        add_arrow(s, 3.30, 1.70 + i * 1.35, 0.50, 0.36, color=RED)

    # ---- CENTER — Gateway ----
    gx, gy, gw, gh = 3.90, 1.30, 5.55, 4.95
    add_rect(s, gx, gy, gw, gh, fill=PANEL_BG, line=GRID, line_w=0.75)
    add_rect(s, gx, gy, gw, 0.55, fill=RED)
    add_text(s, gx, gy, gw, 0.55, "LLMGateway · Policy & Routing Pipeline",
             size=13, bold=True, color=TEXT_LIGHT, align=PP_ALIGN.CENTER,
             anchor=MSO_ANCHOR.MIDDLE)

    stages = [
        ("1  AuthN",            "Resolve key → user / team",                  PILL_BLUE),
        ("2  AuthZ",            "Tier check (L0…L3) · model ACL · quota",     PILL_BLUE),
        ("3  DLP",              "Presidio PII · regex · guardrail patterns",  PILL_RED),
        ("4  Smart Router",     "Auto-pick model by length, intent, budget",  PILL_PURPLE),
        ("5  Inference",        "Forward to vLLM / OpenRouter; stream back",  PILL_GREEN),
        ("6  Post-call",        "Output secret scan · cost track · audit",    NAVY_BAR),
    ]
    sx = gx + 0.20
    sw = gw - 0.40
    sy = gy + 0.70
    sh_each = 0.66
    for label, body, col in stages:
        add_rect(s, sx, sy, sw, sh_each, fill=LIGHT_BG, line=GRID, line_w=0.5)
        add_rect(s, sx, sy, 1.85, sh_each, fill=col)
        add_text(s, sx + 0.10, sy, 1.75, sh_each, label,
                 size=12, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, sx + 1.95, sy, sw - 2.10, sh_each, body,
                 size=10.5, color=TEXT_DARK, anchor=MSO_ANCHOR.MIDDLE)
        sy += sh_each + 0.04

    # Arrows from gateway to models
    for i in range(3):
        add_arrow(s, 9.55, 1.70 + i * 1.35, 0.45, 0.36, color=RED)

    # ---- RIGHT — Models ----
    models = [
        ("Kimi K2.6",         "PREMIUM · cloud",       "Moonshot / OpenRouter",  PILL_PURPLE),
        ("Qwen3-Coder-30B",   "WORKHORSE · self-host", "vLLM @ shared GPU box",   PILL_BLUE),
        ("Gemma 4 27B",       "ECONOMY · self-host",   "vLLM @ shared GPU box",   PILL_GREEN),
    ]
    mx, mw = 10.10, 2.90
    my = 1.30
    for name, tier, host, col in models:
        add_rect(s, mx, my, mw, 1.20, fill=PANEL_BG, line=GRID, line_w=0.75)
        add_rect(s, mx, my, 0.12, 1.20, fill=col)
        add_text(s, mx + 0.22, my + 0.05, mw - 0.30, 0.36, name,
                 size=13, bold=True, color=NAVY_BAR)
        add_text(s, mx + 0.22, my + 0.42, mw - 0.30, 0.30, tier,
                 size=10, bold=True, color=col)
        add_text(s, mx + 0.22, my + 0.75, mw - 0.30, 0.30, host,
                 size=10, italic=True, color=MUTED)
        my += 1.35

    # Down arrow from gateway → observability
    add_arrow(s, 6.55, 6.30, 0.35, 0.25, color=NAVY_BAR, direction="down")

    # Observability strip
    add_rect(s, 0.40, 6.58, 12.55, 0.45, fill=RGBColor(0x35, 0x46, 0x60))
    add_text(s, 0.55, 6.58, 3.0, 0.45, "OBSERVABILITY BUS",
             size=11, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
    add_text(s, 3.50, 6.58, 9.40, 0.45,
             "Postgres audit  ·  SIEM (Splunk / ELK)  ·  Prometheus + Grafana  ·  "
             "UEBA baselines  ·  4-eyes raw access",
             size=10.5, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
    return s


def slide_architecture_diagram(prs):
    """Embed the architecture.png at slide size."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "ARCHITECTURE · detail", "System diagram — components and edges")
    if ARCH.exists():
        pic = s.shapes.add_picture(str(ARCH), Inches(0.30), Inches(0.95),
                                   width=Inches(12.70))
        max_h = Inches(5.95)
        if pic.height > max_h:
            ratio = max_h / pic.height
            pic.height = max_h
            pic.width = int(pic.width * ratio)
            pic.left = Inches((13.33 - Emu(pic.width).inches) / 2)
    add_text(s, 0.30, 7.00, 12.7, 0.20,
             "Source: docs/architecture.svg · clusters: clients / admin UI / gateway core / providers / persistence / observability.",
             size=9, italic=True, color=MUTED, align=PP_ALIGN.CENTER)
    return s


def slide_request_flow(prs):
    """9-checkpoint request flow."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "REQUEST FLOW", "From keystroke to model and back — nine checkpoints")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "Every prompt walks through the same nine checkpoints. A "
             "failure at any step short-circuits with a structured error — "
             "never a silent leak. Every step writes to the audit row.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    steps = [
        ("1", "Developer types",     "VS Code / Antigravity → /v1/chat/completions"),
        ("2", "TLS + Auth",          "mTLS client cert + bearer key check"),
        ("3", "Identity → SSO",      "Resolve key → user, team, role"),
        ("4", "Authorization",       "Allowed model? Agent mode allowed?"),
        ("5", "Rate / quota",        "TPM, RPM, daily budget per user/team"),
        ("6", "DLP input scan",      "Presidio + regex + custom heuristics"),
        ("7", "Router decides",      "Kimi (cloud) vs Qwen3 / Gemma (vLLM)"),
        ("8", "Inference",           "Stream tokens back through gateway"),
        ("9", "Output scan + log",   "Secret scan · ship audit row to SIEM"),
    ]
    # 3-column grid of 3 rows
    card_w, card_h = 4.10, 1.30
    gap_x, gap_y = 0.20, 0.20
    x0, y0 = 0.50, 1.60
    for idx, (n, label, sub) in enumerate(steps):
        col = idx % 3
        row = idx // 3
        x = x0 + col * (card_w + gap_x)
        y = y0 + row * (card_h + gap_y)
        add_rect(s, x, y, card_w, card_h, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x, y, 0.55, card_h, fill=NAVY_BAR)
        add_text(s, x, y, 0.55, card_h, n,
                 size=22, bold=True, color=TEXT_LIGHT,
                 font="Calibri Light", align=PP_ALIGN.CENTER,
                 anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, x + 0.70, y + 0.15, card_w - 0.80, 0.40, label,
                 size=13, bold=True, color=NAVY_BAR)
        add_text(s, x + 0.70, y + 0.60, card_w - 0.80, 0.65, sub,
                 size=10.5, color=TEXT_DARK)

    add_text(s, 0.50, 6.85, 12.3, 0.30,
             "Any rejection at steps 2-6 returns a structured error to the IDE; "
             "the prompt is logged with the rejection reason for security review.",
             size=10, italic=True, color=MUTED, font="Calibri", align=PP_ALIGN.CENTER)
    return s


def slide_threats(prs):
    """Six security threats."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "THREATS", "Six security threats — name them before you solve them")

    threats = [
        ("Identity",           "Anyone on the LAN hits the model anonymously",     "Stolen laptop = free model for an attacker"),
        ("Authorization",      "Junior dev runs senior-grade agent + quotas",      "Interns running production-grade refactors"),
        ("Data exfil (in)",    "Dev pastes PII / secrets / regulated code",        "GDPR breach, lost IP, secrets in logs"),
        ("Data exfil (out)",   "Model regurgitates a secret it saw earlier",       "Leaked API keys appear in chat replies"),
        ("Cost / abuse",       "One dev fires a 50-tab fuzz loop",                 "Shared GPU saturated; legitimate users blocked"),
        ("Audit / forensics",  '"Did anyone send our auth code to the model?"',    "No answer = de facto breach during review"),
    ]
    card_w, card_h = 4.10, 1.65
    gap_x, gap_y = 0.20, 0.20
    x0, y0 = 0.50, 1.55
    for idx, (head, body, impact) in enumerate(threats):
        col = idx % 3
        row = idx // 3
        x = x0 + col * (card_w + gap_x)
        y = y0 + row * (card_h + gap_y)
        add_rect(s, x, y, card_w, card_h, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x, y, card_w, 0.40, fill=RED)
        add_text(s, x + 0.15, y, card_w - 0.30, 0.40, head,
                 size=12, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, x + 0.15, y + 0.50, card_w - 0.30, 0.50, body,
                 size=11, color=TEXT_DARK)
        add_text(s, x + 0.15, y + 1.05, card_w - 0.30, 0.50,
                 "Impact: " + impact,
                 size=10, italic=True, color=MUTED)

    add_text(s, 0.50, 6.85, 12.3, 0.25,
             "Each threat maps 1:1 to a control on the next slide.",
             size=10, italic=True, color=MUTED, align=PP_ALIGN.CENTER, font="Calibri")
    return s


def slide_controls(prs):
    """Threat → Tool → Policy table."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "CONTROLS", "Layered defence — threat → tool → policy")

    cols = ["Layer", "Control", "OSS / Plugin", "Example policy"]
    rows = [
        ("Auth",      "Identify the user",       "Keycloak / Entra OIDC + virtual keys",   "Personal key bound to SSO identity"),
        ("AuthZ",     "Which model / mode?",      "LLMGateway team & key scopes",            "Interns: 7B only; seniors: 30B + agent"),
        ("Quota",     "How much / how fast?",     "quota_redis (RPM + TPM + daily $)",       "200k tok/dev/day · 60 req/min"),
        ("DLP",       "Block sensitive prompts",  "guardrail_patterns + Presidio",           "Refuse on AWS key · redact on PII"),
        ("Routing",   "Pick the right model",     "router_rule_based",                       "Tiny prompts → Qwen3 · agent → Kimi"),
        ("Output",    "Catch leaked secrets",     "output_scan_secrets",                     "Block streams that emit secrets post-hoc"),
        ("Cache",     "Avoid duplicate spend",    "cache_redis + cache_semantic",            "5 min TTL · 0.92 cosine for hits"),
        ("Audit",     "Tamper-evident log",       "audit_postgres (AES-GCM body)",           "1 row / call · 4-eyes for plaintext"),
        ("Behaviour", "Catch misuse",             "observe_ueba",                            "Auto-quarantine on threshold breach"),
        ("Network",   "No surprise egress",       "gateway-only outbound",                   "VLAN blocks dev-laptop → internet"),
    ]
    table_x, table_y = 0.50, 1.45
    table_w = 12.30
    col_widths = [1.40, 2.40, 3.90, 4.60]
    row_h = 0.40

    add_rect(s, table_x, table_y, table_w, row_h, fill=NAVY_BAR)
    cx = table_x
    for i, c in enumerate(cols):
        add_text(s, cx + 0.15, table_y, col_widths[i] - 0.20, row_h, c,
                 size=11, bold=True, color=TEXT_LIGHT,
                 anchor=MSO_ANCHOR.MIDDLE)
        cx += col_widths[i]

    for r, row in enumerate(rows):
        y = table_y + (r + 1) * row_h
        add_rect(s, table_x, y, table_w, row_h,
                 fill=(PANEL_BG if r % 2 == 0 else LIGHT_BG))
        cx = table_x
        for i, val in enumerate(row):
            add_text(s, cx + 0.15, y, col_widths[i] - 0.20, row_h, val,
                     size=10.5,
                     bold=(i == 0),
                     color=(NAVY_BAR if i == 0 else TEXT_DARK),
                     anchor=MSO_ANCHOR.MIDDLE)
            cx += col_widths[i]
    return s


def slide_implementation(prs):
    """What's built — implementation snapshot."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "IMPLEMENTATION", "What's built — gateway, admin UI, observability")

    sections = [
        ("Gateway", PILL_RED, [
            "FastAPI :4000 · uvicorn",
            "/v1/chat/completions · /v1/models · /admin/* · /metrics · /ready",
            "LLMGateway shim — drop-in for LiteLLM Router",
            "Truststore (OS cert store) — works behind SSL-MITM AV",
        ]),
        ("Admin UI", PILL_BLUE, [
            "Next.js 15 :3010 · 4-theme picker (light/dark/solarized)",
            "Sidebar grouped by pipeline stage (AuthN → Audit)",
            "Settings · Models tab (typed form per provider) · App tab",
            "OpenRouter catalog browser · one-click import",
        ]),
        ("Persistence", PILL_GREEN, [
            "Postgres × 2 (operational + audit)",
            "audit_log body AES-GCM-encrypted at rest",
            "4-eyes reveal flow for plaintext access",
            "Redis (optional) · in-memory fallback for dev",
        ]),
        ("Observability", PILL_PURPLE, [
            "Prometheus :9090 · 5 s scrape · 15 d retention",
            "Grafana :3001 · 2 provisioned dashboards · iframe-embedded",
            "Alertmanager :9093 · routes Prometheus alerts",
            "UEBA per-user baselines · 10-signal radar",
        ]),
    ]
    card_w, card_h = 6.20, 2.65
    gap_x, gap_y = 0.20, 0.20
    x0, y0 = 0.50, 1.45
    for idx, (name, color, items) in enumerate(sections):
        col = idx % 2
        row = idx // 2
        x = x0 + col * (card_w + gap_x)
        y = y0 + row * (card_h + gap_y)
        add_rect(s, x, y, card_w, card_h, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x, y, card_w, 0.50, fill=color)
        add_text(s, x + 0.20, y, card_w - 0.40, 0.50, name,
                 size=14, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        for j, line in enumerate(items):
            yy = y + 0.65 + j * 0.45
            add_rect(s, x + 0.20, yy + 0.12, 0.06, 0.18, fill=color)
            add_text(s, x + 0.32, yy, card_w - 0.50, 0.45, line,
                     size=11, color=TEXT_DARK, anchor=MSO_ANCHOR.MIDDLE)

    add_text(s, 0.50, 6.85, 12.3, 0.25,
             "All built. Verify status via /ready and the admin UI's Observability page.",
             size=10, italic=True, color=MUTED, align=PP_ALIGN.CENTER, font="Calibri")
    return s


def slide_scaling(prs):
    """Clustering, sharing, and the state that must move to Redis."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "SCALING · CLUSTERING", "Yes — with conditions. Three pieces of state must shift to Redis.")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "The gateway is mostly stateless by design. Add a second "
             "replica behind a load balancer once these three caveats "
             "are addressed.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    # Left card — in-process state to migrate
    add_rect(s, 0.50, 1.55, 6.10, 4.10, fill=PANEL_BG, line=GRID,
             line_w=0.75, radius_pct=3)
    add_rect(s, 0.50, 1.55, 6.10, 0.50, fill=PILL_RED)
    add_text(s, 0.70, 1.55, 5.90, 0.50,
             "PER-PROCESS STATE — move to Redis for multi-replica",
             size=11, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)

    cards = [
        ("quota_redis",
         "In-memory counters when memory:// — each replica enforces its own RPM cap → effective limit × N."),
        ("cache_redis + cache_semantic",
         "In-process dict on memory:// — cache hit rate drops by 1/N per replica."),
        ("Plugin chain + Router config",
         "Hot-reload only the receiving process — add Redis pub/sub or accept 'effective on restart'."),
    ]
    for i, (k, v) in enumerate(cards):
        y = 2.20 + i * 1.15
        add_rect(s, 0.70, y, 0.06, 0.85, fill=PILL_RED)
        add_text(s, 0.85, y, 5.65, 0.30, k,
                 size=12, bold=True, color=NAVY_BAR)
        add_text(s, 0.85, y + 0.30, 5.65, 0.60, v,
                 size=10.5, color=TEXT_DARK)

    # Right card — cluster-safe today
    add_rect(s, 6.75, 1.55, 6.10, 4.10, fill=PANEL_BG, line=GRID,
             line_w=0.75, radius_pct=3)
    add_rect(s, 6.75, 1.55, 6.10, 0.50, fill=PILL_GREEN)
    add_text(s, 6.95, 1.55, 5.90, 0.50,
             "CLUSTER-SAFE TODAY — shared by construction",
             size=11, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)

    safe = [
        ("Postgres (op + audit)",
         "Every replica reads / writes the same rows · no extra config."),
        ("Audit log · UEBA · DLP findings",
         "Persist to Postgres · any replica sees the same view."),
        ("TLS truststore + session cookies",
         "Per-process bootstrap · same SESSION_SECRET on every replica."),
    ]
    for i, (k, v) in enumerate(safe):
        y = 2.20 + i * 1.15
        add_rect(s, 6.95, y, 0.06, 0.85, fill=PILL_GREEN)
        add_text(s, 7.10, y, 5.65, 0.30, k,
                 size=12, bold=True, color=NAVY_BAR)
        add_text(s, 7.10, y + 0.30, 5.65, 0.60, v,
                 size=10.5, color=TEXT_DARK)

    # Bottom strip — LB recipe
    add_rect(s, 0.50, 5.85, 12.35, 0.85, fill=NAVY_BAR, radius_pct=4)
    add_text(s, 0.70, 5.85, 12.15, 0.30, "RECOMMENDED TOPOLOGY · 100 DEVELOPERS",
             size=10, bold=True, color=RGBColor(0xCF, 0xD4, 0xDC),
             anchor=MSO_ANCHOR.MIDDLE)
    add_text(s, 0.70, 6.15, 12.15, 0.55,
             "nginx / Traefik with ip_hash  →  2-3 gateway replicas  →  shared Postgres + shared Redis  →  "
             "GPU box (vLLM · Qwen3-Coder-30B + Gemma 4 27B)  +  OpenRouter (Kimi K2.6).  "
             "Health-check /ready · sticky sessions for SSE streams.",
             size=11, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
    return s


def slide_capacity(prs):
    """Minimum hardware + per-backend concurrency."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "SCALING · HARDWARE", "Minimum specs + per-backend concurrency")

    # --- Hardware table (top half) ---
    add_text(s, 0.50, 0.95, 12.3, 0.30, "HARDWARE — single-box dev vs 100-dev production",
             size=11, bold=True, color=MUTED)

    cols = ["Component", "Single-box dev", "Production (100 devs)"]
    rows_hw = [
        ("Gateway",       "~600 MB · 1 vCPU · workers=1",   "8-16 GB · 4-8 vCPU · 2-3 replicas"),
        ("Admin UI",      "~300 MB · 0.5 vCPU",              "shares a gateway box"),
        ("Postgres",      "1-2 GB · 1 vCPU · 20 GB disk",    "8-16 GB · 4 vCPU · ~36 GB/year audit"),
        ("Redis",         "100 MB (or memory:// fallback)",  "1 GB · 1 vCPU"),
        ("GPU box (vLLM)","not required for dev",            "1× RTX 6000 Ada (48 GB) for 30B + 27B"),
        ("Total (no GPU)","~4 GB · 2 vCPU · 20 GB",          "see rows above"),
    ]
    table_x, table_y = 0.50, 1.30
    table_w, row_h = 12.30, 0.36
    col_widths = [2.6, 4.8, 4.9]

    add_rect(s, table_x, table_y, table_w, row_h, fill=NAVY_BAR)
    cx = table_x
    for i, c in enumerate(cols):
        add_text(s, cx + 0.15, table_y, col_widths[i] - 0.20, row_h, c,
                 size=10.5, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        cx += col_widths[i]

    for r, row in enumerate(rows_hw):
        y = table_y + (r + 1) * row_h
        add_rect(s, table_x, y, table_w, row_h,
                 fill=(PANEL_BG if r % 2 == 0 else LIGHT_BG))
        cx = table_x
        for i, val in enumerate(row):
            add_text(s, cx + 0.15, y, col_widths[i] - 0.20, row_h, val,
                     size=10, bold=(i == 0),
                     color=(NAVY_BAR if i == 0 else TEXT_DARK),
                     anchor=MSO_ANCHOR.MIDDLE)
            cx += col_widths[i]

    # --- Concurrency table (bottom half) ---
    conc_y = 4.10
    add_text(s, 0.50, conc_y, 12.3, 0.30,
             "PARALLEL CALLS — gateway-only overhead is ~10-15 ms per request. "
             "Real cap is the backend.",
             size=11, bold=True, color=MUTED)

    cols2 = ["Backend", "Concurrent per worker", "Real bottleneck"]
    rows_c = [
        ("OpenRouter / cloud (Kimi K2.6)",
         "~500-1000 streams",
         "Provider's per-key rate limit + your daily $ budget"),
        ("vLLM self-host (Qwen3-Coder 30B)",
         "8-15 active completions, queued beyond",
         "GPU throughput (40-120 tok/s aggregated, batched)"),
        ("Ollama (smaller local models)",
         "2-3 streams",
         "CPU/GPU · Ollama doesn't auto-batch"),
        ("Mix (Smart Router picks)",
         "Each request takes whichever fits",
         "Mix of the above"),
    ]
    table_y2 = conc_y + 0.40
    col_widths2 = [3.5, 4.0, 4.8]
    add_rect(s, table_x, table_y2, table_w, row_h, fill=NAVY_BAR)
    cx = table_x
    for i, c in enumerate(cols2):
        add_text(s, cx + 0.15, table_y2, col_widths2[i] - 0.20, row_h, c,
                 size=10.5, bold=True, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
        cx += col_widths2[i]
    for r, row in enumerate(rows_c):
        y = table_y2 + (r + 1) * row_h
        add_rect(s, table_x, y, table_w, row_h,
                 fill=(PANEL_BG if r % 2 == 0 else LIGHT_BG))
        cx = table_x
        for i, val in enumerate(row):
            add_text(s, cx + 0.15, y, col_widths2[i] - 0.20, row_h, val,
                     size=10, bold=(i == 0),
                     color=(NAVY_BAR if i == 0 else TEXT_DARK),
                     anchor=MSO_ANCHOR.MIDDLE)
            cx += col_widths2[i]

    # Worked example footer
    add_rect(s, 0.50, 6.65, 12.35, 0.50, fill=NAVY_BAR, radius_pct=4)
    add_text(s, 0.70, 6.65, 12.15, 0.50,
             "WORKED EXAMPLE · 100 devs × 5 calls/hr × 30 s avg = ~4 concurrent streams at peak.  "
             "One GPU + one gateway worker comfortably handles 100 devs.  "
             "Daily $ budget + RPM caps are the safety net, not raw capacity.",
             size=10.5, color=TEXT_LIGHT, anchor=MSO_ANCHOR.MIDDLE)
    return s


def slide_why_oati(prs):
    """Headline differentiators — 5 cards of what nobody else ships free."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "WHY OATI", "Everything LiteLLM charges Enterprise for · we ship MIT")

    add_text(s, 0.50, 0.95, 12.3, 0.45,
             "Other OSS gateways either route or observe. OATI is the only "
             "MIT gateway that ships AuthN, AuthZ, DLP, smart routing, "
             "inference, encrypted audit, UEBA, and a polished admin UI "
             "out of the box — with no paid tier.",
             size=13, color=TEXT_DARK, font="Calibri Light")

    cards = [
        ("MIT end-to-end",       PILL_GREEN,
         "No Enterprise SKU.",
         "DLP, audit log, PII masking, prompt-injection — \n"
         "all in the OATI core. LiteLLM gates these to paid."),
        ("AES-GCM audit",        PILL_RED,
         "Encrypted at rest.",
         "Plaintext reveal requires a separate operator's \n"
         "approval (4-eyes). Every step itself audited."),
        ("UEBA radar",           PILL_PURPLE,
         "Behavioural scoring.",
         "10 signals per user, rolling baselines. Crossing \n"
         "threshold auto-quarantines the key + alerts SOC."),
        ("Disconnect-safe audit",PILL_BLUE,
         "Mid-stream cuts logged.",
         "Verified live: client disconnect at 0.3 s still \n"
         "writes the audit row from a background task."),
        ("OpenRouter browser",   PILL_ORANGE,
         "1-click model import.",
         "Search 250+ models in the admin UI. Add fills \n"
         "pricing + context length. No JSON, no curl."),
    ]
    card_w, gap = 2.42, 0.10
    x0, y0 = 0.50, 1.70
    for i, (name, color, hero, body) in enumerate(cards):
        x = x0 + i * (card_w + gap)
        add_rect(s, x, y0, card_w, 5.05, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x, y0, card_w, 0.55, fill=color)
        add_text(s, x + 0.15, y0, card_w - 0.30, 0.55, name,
                 size=13, bold=True, color=TEXT_LIGHT,
                 anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, x + 0.20, y0 + 0.75, card_w - 0.40, 0.45, hero,
                 size=13, bold=True, color=NAVY_BAR)
        add_text(s, x + 0.20, y0 + 1.25, card_w - 0.40, 3.50, body,
                 size=10.5, color=TEXT_DARK)

    add_text(s, 0.50, 7.00, 12.3, 0.25,
             "Detailed matrix on the next slide · full write-up in "
             "docs/LLMGateway-Implementation.docx (Appendix D).",
             size=9.5, italic=True, color=MUTED, font="Calibri",
             align=PP_ALIGN.CENTER)
    return s


def slide_vs_litellm(prs):
    """Head-to-head capability matrix vs LiteLLM OSS + Enterprise."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "COMPARISON", "OATI vs LiteLLM — capability matrix")

    add_text(s, 0.50, 0.95, 12.3, 0.35,
             "Every row marked $ in LiteLLM Enterprise is a row marked "
             "Yes in OATI's MIT core.",
             size=12, color=TEXT_DARK, font="Calibri Light")

    cols = ["Capability", "LiteLLM OSS", "LiteLLM Enterprise", "OATI (MIT)"]
    # Marker glyphs that render in Calibri without unicode emoji issues
    Y, N, P, D = "Yes", "—", "partial", "$ paid"
    rows = [
        ("OpenAI-compatible HTTP proxy",                Y, Y, Y),
        ("Provider translation (Ollama, OpenRouter, OpenAI …)", Y, Y, Y),
        ("Streaming SSE + non-streaming",               Y, Y, Y),
        ("Per-team tier ACL + model permissions",       P, Y, Y),
        ("Daily $ budget + RPM caps",                   P, Y, Y),
        ("DLP / prompt injection / PII redaction",      N, D, Y),
        ("Output secret-scan post-stream",              N, D, Y),
        ("Append-only audit log",                       P, D, Y),
        ("Audit body encrypted at rest (AES-GCM)",      N, P, Y),
        ("4-eyes plaintext reveal",                     N, N, Y),
        ("UEBA per-user behavioural scoring",           N, N, Y),
        ("JIT tier elevations",                         N, N, Y),
        ("Mid-stream-disconnect audit",                 N, "?", Y),
        ("Semantic / cosine response cache",            N, D, Y),
        ("Polished admin UI",                           P, D, Y),
        ("OpenRouter catalog browser in UI",            N, N, Y),
        ("Email API key + IDE setup snippets",          N, N, Y),
        ("Per-key edit (change team without rotate)",   N, N, Y),
        ("Idempotent DELETE (RFC 9110)",                N, N, Y),
        ("Works behind SSL-MITM antivirus",             N, N, Y),
    ]

    # Table layout — tight to fit 20 rows
    table_x, table_y = 0.50, 1.40
    col_widths = [6.20, 1.95, 2.20, 1.95]
    row_h      = 0.25
    table_w    = sum(col_widths)

    # Header
    add_rect(s, table_x, table_y, table_w, 0.34, fill=NAVY_BAR)
    cx = table_x
    for i, c in enumerate(cols):
        add_text(s, cx + 0.10, table_y, col_widths[i] - 0.15, 0.34, c,
                 size=10, bold=True, color=TEXT_LIGHT,
                 anchor=MSO_ANCHOR.MIDDLE,
                 align=(PP_ALIGN.LEFT if i == 0 else PP_ALIGN.CENTER))
        cx += col_widths[i]

    # Body rows
    for r, row in enumerate(rows):
        y = table_y + 0.34 + r * row_h
        add_rect(s, table_x, y, table_w, row_h,
                 fill=(PANEL_BG if r % 2 == 0 else LIGHT_BG))
        cx = table_x
        for i, val in enumerate(row):
            colour = TEXT_DARK
            bold = False
            if i > 0:
                if val == "Yes":
                    colour = PILL_GREEN
                    bold = True
                elif val == "$ paid":
                    colour = PILL_ORANGE
                    bold = True
                elif val == "partial":
                    colour = MUTED
                elif val == "—":
                    colour = RGBColor(0xCB, 0x2A, 0x32)
                elif val == "?":
                    colour = MUTED
                    bold = True
            add_text(s, cx + 0.10, y, col_widths[i] - 0.15, row_h, val,
                     size=9.5, bold=(bold or i == 0),
                     color=(NAVY_BAR if i == 0 else colour),
                     anchor=MSO_ANCHOR.MIDDLE,
                     align=(PP_ALIGN.LEFT if i == 0 else PP_ALIGN.CENTER))
            cx += col_widths[i]

    # Legend strip
    add_text(s, 0.50, 6.95, 12.3, 0.25,
             "Yes = built in   ·   partial = available but limited   ·   "
             "$ paid = behind LiteLLM Enterprise licence   ·   — = not offered",
             size=9, italic=True, color=MUTED, font="Calibri",
             align=PP_ALIGN.CENTER)
    return s


def slide_value_props(prs):
    """Closing slide — three signature value props."""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    chrome(s, "OUTCOMES", "Three signature outcomes")

    cards = [
        ("CONTROLLED ACCESS",      PILL_BLUE,
         "Per-team tiers L0-L3 · JIT elevation · per-project virtual keys.\n"
         "Every IDE → same gateway → same policy chain."),
        ("AUTO MODEL SELECTION",   PILL_PURPLE,
         "Smart router picks the cheapest acceptable model.\n"
         "Operator override always allowed; rule chain is YAML-editable."),
        ("CONTINUOUS MONITORING",  PILL_RED,
         "UEBA scores 10 signals per user with rolling baselines.\n"
         "Auto-quarantine on misuse · full audit trail with reveal flow."),
    ]
    card_w, gap = 4.10, 0.20
    x0, y = 0.50, 1.70
    for name, color, body in cards:
        add_rect(s, x0, y, card_w, 5.00, fill=PANEL_BG, line=GRID,
                 line_w=0.75, radius_pct=3)
        add_rect(s, x0, y, card_w, 0.65, fill=color)
        add_text(s, x0 + 0.20, y, card_w - 0.40, 0.65, name,
                 size=14, bold=True, color=TEXT_LIGHT,
                 anchor=MSO_ANCHOR.MIDDLE, align=PP_ALIGN.CENTER)
        add_text(s, x0 + 0.30, y + 0.95, card_w - 0.60, 3.80, body,
                 size=13, color=TEXT_DARK, font="Calibri Light",
                 anchor=MSO_ANCHOR.TOP)
        x0 += card_w + gap

    add_text(s, 0.50, 6.85, 12.3, 0.30,
             "Companion documents: docs/LLMGateway-Implementation.docx · docs/ARCHITECTURE.md · docs/architecture.svg",
             size=10, italic=True, color=MUTED, align=PP_ALIGN.CENTER, font="Calibri")
    return s


# -----------------------------------------------------------------------------
# Driver
# -----------------------------------------------------------------------------
def build():
    prs = Presentation()
    prs.slide_width  = Inches(13.333)
    prs.slide_height = Inches(7.50)

    slide_title(prs)
    slide_motivation(prs)
    slide_models(prs)
    slide_hardware(prs)
    slide_backends(prs)
    slide_ide(prs)
    slide_architecture_hero(prs)
    slide_architecture_diagram(prs)
    slide_request_flow(prs)
    slide_threats(prs)
    slide_controls(prs)
    slide_implementation(prs)
    slide_scaling(prs)
    slide_capacity(prs)
    slide_why_oati(prs)
    slide_vs_litellm(prs)
    slide_value_props(prs)

    prs.save(OUT)
    print(f"wrote {OUT}  ({len(prs.slides)} slides)")


if __name__ == "__main__":
    build()
