"""Pillow renderer for the architecture diagram.

We can't trivially convert docs/architecture.svg to PNG on this Windows
box (no cairo / inkscape / ImageMagick), so the deck embeds a Pillow-
drawn PNG that mirrors the same layout and colour grammar. Source of
truth is still the SVG — keep both in sync when changing the diagram.
"""

from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


OUT = Path(__file__).resolve().parent / "architecture.png"

# 2× the SVG viewBox so the PNG is crisp at presentation size.
W, H = 1920, 1280


# -----------------------------------------------------------------------------
# Style tokens — same vocabulary as the SVG
# -----------------------------------------------------------------------------
PALETTE = {
    "client":   ("#fff5d2", "#d4a300"),
    "route":    ("#d9f3d2", "#43a047"),
    "engine":   ("#e6dfff", "#7e57c2"),
    "plugin":   ("#ffd8d8", "#d32f2f"),
    "llm":      ("#fdd6e6", "#c2185b"),
    "aux":      ("#ddeaff", "#1976d2"),
    "obs":      ("#efe1ff", "#6a1b9a"),
    "db_op":    ("#fff5d2", "#b48800"),
    "db_audit": ("#ffe8d6", "#b45200"),
    "db_cache": ("#ffd6d6", "#c62828"),
    "disabled": ("#f3f4f6", "#9ca3af"),
}
EDGE = {
    "control": "#2e7d32",
    "ingest":  "#1565c0",
    "model":   "#c2185b",
    "metric":  "#ef6c00",
    "grey":    "#666666",
}
TEXT_DARK  = "#1a1a1a"
TEXT_MUTED = "#4b5563"
CLUSTER    = "#94a3b8"


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    # Try common Windows fonts; fall back to PIL default at the right size.
    candidates = (
        ("seguisb.ttf" if bold else "segoeui.ttf"),
        "arial.ttf",
        "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf",
    )
    for name in candidates:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def box(d: ImageDraw.ImageDraw, x: int, y: int, w: int, h: int,
        fill_hex: str, stroke_hex: str, radius: int = 12,
        stroke_w: int = 2, dashed: bool = False):
    d.rounded_rectangle((x, y, x + w, y + h),
                        radius=radius, fill=fill_hex,
                        outline=stroke_hex if not dashed else None,
                        width=stroke_w)
    if dashed:
        _dashed_rect(d, x, y, w, h, stroke_hex, stroke_w, radius)


def _dashed_rect(d, x, y, w, h, color, width, radius):
    # Approximate a dashed outline on a rounded rect by drawing short
    # segments along each edge. Good enough for cluster boundaries.
    dash, gap = 12, 8
    pts = [
        (x + radius, y, x + w - radius, y),                 # top
        (x + w, y + radius, x + w, y + h - radius),         # right
        (x + radius, y + h, x + w - radius, y + h),         # bottom
        (x, y + radius, x, y + h - radius),                 # left
    ]
    for x1, y1, x2, y2 in pts:
        if x1 == x2:
            for j in range(y1, y2, dash + gap):
                d.line((x1, j, x1, min(j + dash, y2)), fill=color, width=width)
        else:
            for j in range(x1, x2, dash + gap):
                d.line((j, y1, min(j + dash, x2), y1), fill=color, width=width)


def label(d, text: str, x: int, y: int, size: int = 16, bold: bool = False,
          color: str = TEXT_DARK, anchor: str = "lm"):
    d.text((x, y), text, font=_font(size, bold=bold), fill=color, anchor=anchor)


def section_label(d, text, x, y):
    label(d, text.upper(), x, y, size=13, bold=True, color=TEXT_MUTED, anchor="lm")


def stage(d, idx, top, label_text, sub_text, fill, stroke):
    """One row of the plugin chain — coloured box + numbered chip."""
    x, w, h = 720, 540, 64
    box(d, x, top, w, h, fill, stroke)
    label(d, f"{idx} · {label_text}", x + 20, top + 22, size=17, bold=True)
    label(d, sub_text, x + 20, top + 46, size=12, color=TEXT_MUTED)
    # Numbered circle on the right edge of the cluster
    cx, cy, r = x + w + 30, top + h // 2, 14
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=stroke)
    label(d, str(idx), cx, cy, size=13, bold=True, color="#ffffff", anchor="mm")


def cylinder(d, cx, cy, w, h, fill, stroke):
    """Draw a 3D-ish DB cylinder centered at (cx, cy)."""
    left, right = cx - w // 2, cx + w // 2
    top, bot    = cy - h // 2, cy + h // 2
    ell_h = max(14, h // 6)
    # Body
    d.rectangle((left, top + ell_h // 2, right, bot - ell_h // 2),
                fill=fill, outline=None)
    d.line((left,  top + ell_h // 2, left,  bot - ell_h // 2), fill=stroke, width=2)
    d.line((right, top + ell_h // 2, right, bot - ell_h // 2), fill=stroke, width=2)
    # Top ellipse
    d.ellipse((left, top, right, top + ell_h), fill=fill, outline=stroke, width=2)
    # Bottom arc
    d.arc((left, bot - ell_h, right, bot), 0, 180, fill=stroke, width=2)
    # Faint highlight to suggest depth
    d.ellipse((left + 4, top + 2, right - 4, top + ell_h - 2),
              outline="#00000022", width=1)


def arrow(d, x1, y1, x2, y2, color, dashed: bool = True, width: int = 2):
    """Draw a (dashed) arrow with a small triangular head at (x2, y2)."""
    # The line
    if dashed:
        _dashed_line(d, x1, y1, x2, y2, color, width)
    else:
        d.line((x1, y1, x2, y2), fill=color, width=width)
    # Arrowhead
    import math
    angle = math.atan2(y2 - y1, x2 - x1)
    h = 10
    bx = x2 - h * math.cos(angle)
    by = y2 - h * math.sin(angle)
    px = bx - 5 * math.sin(angle)
    py = by + 5 * math.cos(angle)
    qx = bx + 5 * math.sin(angle)
    qy = by - 5 * math.cos(angle)
    d.polygon((x2, y2, px, py, qx, qy), fill=color)


def _dashed_line(d, x1, y1, x2, y2, color, width):
    import math
    total = math.hypot(x2 - x1, y2 - y1)
    if total == 0:
        return
    dash, gap = 12, 6
    n = int(total // (dash + gap)) + 1
    for k in range(n):
        s = (dash + gap) * k
        e = min(s + dash, total)
        f1 = s / total
        f2 = e / total
        d.line((x1 + (x2 - x1) * f1, y1 + (y2 - y1) * f1,
                x1 + (x2 - x1) * f2, y1 + (y2 - y1) * f2),
               fill=color, width=width)


# -----------------------------------------------------------------------------
# Draw
# -----------------------------------------------------------------------------
def main():
    im = Image.new("RGB", (W, H), "#ffffff")
    d = ImageDraw.Draw(im)

    # ---- Header
    label(d, "LLMGateway — System Architecture", W // 2, 50,
          size=34, bold=True, color=TEXT_DARK, anchor="mm")
    label(d, "Clients · Admin UI · 6-stage Plugin Chain · Inference · Persistence · Observability",
          W // 2, 90, size=15, color=TEXT_MUTED, anchor="mm")

    # ---- Clients column
    section_label(d, "Clients", 120, 140)
    box(d, 50, 160, 240, 70, *PALETTE["client"])
    label(d, "Cline / IDE", 170, 184, size=17, bold=True, anchor="mm")
    label(d, "OpenAI-compatible SDK", 170, 210, size=12, color=TEXT_MUTED, anchor="mm")

    box(d, 50, 250, 240, 70, *PALETTE["client"])
    label(d, "Admin Browser", 170, 274, size=17, bold=True, anchor="mm")
    label(d, "Operator console (HMAC cookie)", 170, 300, size=12, color=TEXT_MUTED, anchor="mm")

    # Prometheus down at the bottom-left, "scrape client"
    box(d, 50, 1010, 240, 70, *PALETTE["obs"])
    label(d, "Prometheus :9090", 170, 1034, size=17, bold=True, anchor="mm")
    label(d, "5s scrape · 15d retention", 170, 1060, size=12, color=TEXT_MUTED, anchor="mm")

    # ---- admin-ui cluster
    box(d, 320, 130, 360, 240, "#ffffff", CLUSTER, radius=18, dashed=True)
    label(d, "ADMIN-UI :3010 (NEXT.JS 15)", 500, 156, size=13, bold=True,
          color=TEXT_MUTED, anchor="mm")

    box(d, 340, 175, 320, 60, *PALETTE["client"])
    label(d, "Pages", 500, 197, size=16, bold=True, anchor="mm")
    label(d, "/teams · /keys · /metrics · /settings · …", 500, 220,
          size=11, color=TEXT_MUTED, anchor="mm")

    box(d, 340, 245, 320, 56, *PALETTE["route"])
    label(d, "BFF Proxy", 500, 266, size=16, bold=True, anchor="mm")
    label(d, "/api/gateway/[…] · injects master key", 500, 286,
          size=11, color=TEXT_MUTED, anchor="mm")

    box(d, 340, 310, 320, 48, *PALETTE["engine"])
    label(d, "Auth · HMAC cookie · 24 h TTL", 500, 334, size=13, anchor="mm")

    # ---- Gateway core cluster (the big one)
    box(d, 700, 130, 600, 870, "#ffffff", CLUSTER, radius=18, dashed=True)
    label(d, "GATEWAY CORE (FASTAPI :4000 · UVICORN · LLMGATEWAY)",
          1000, 156, size=13, bold=True, color=TEXT_MUTED, anchor="mm")

    # Public route surface — 3 small boxes
    routes = [
        (720,  "/v1/chat/completions", "+ /chat/completions alias"),
        (910,  "/v1/models",           "+ /models alias"),
        (1100, "/admin/*",             "operator CRUD"),
    ]
    for x, title, sub in routes:
        box(d, x, 175, 180, 64, *PALETTE["route"])
        label(d, title, x + 90, 197, size=14, bold=True, anchor="mm")
        label(d, sub,   x + 90, 220, size=11, color=TEXT_MUTED, anchor="mm")

    # 6 plugin chain stages
    label(d, "6-STAGE PLUGIN CHAIN (PER REQUEST)", 1000, 264,
          size=13, bold=True, color=TEXT_MUTED, anchor="mm")
    stage(d, 1, 285,  "AuthN", "auth.py · master key · DB virtual keys · expires_at",
          *PALETTE["engine"])
    stage(d, 2, 360,  "AuthZ", "authz_tiered (tier ACL) · quota_redis (RPM + daily $$)",
          *PALETTE["plugin"])
    stage(d, 3, 435,  "DLP",   "guardrail_patterns · regex + heuristic · pre-call redaction",
          *PALETTE["plugin"])
    stage(d, 4, 510,  "Smart Router", "router_rule_based · YAML chain · per-rule overrides",
          *PALETTE["engine"])
    stage(d, 5, 585,  "Inference",
          "LLMGateway shim + cache_redis + cache_semantic (cosine)",
          *PALETTE["llm"])
    stage(d, 6, 660,  "Audit",
          "audit_postgres (AES-GCM · 4-eyes reveal) · siem_forward · UEBA",
          *PALETTE["plugin"])

    # Cross-cutting strip
    label(d, "CROSS-CUTTING", 1000, 760, size=13, bold=True, color=TEXT_MUTED, anchor="mm")
    box(d, 720, 780, 180, 56, *PALETTE["aux"])
    label(d, "/metrics", 810, 800, size=14, bold=True, anchor="mm")
    label(d, "Prometheus exposition", 810, 822, size=11, color=TEXT_MUTED, anchor="mm")

    box(d, 910, 780, 180, 56, *PALETTE["aux"])
    label(d, "/ready /healthz", 1000, 800, size=14, bold=True, anchor="mm")
    label(d, "per-dep probes", 1000, 822, size=11, color=TEXT_MUTED, anchor="mm")

    box(d, 1100, 780, 180, 56, *PALETTE["aux"])
    label(d, "truststore", 1190, 800, size=14, bold=True, anchor="mm")
    label(d, "OS cert store (Win/Avast)", 1190, 822, size=11, color=TEXT_MUTED, anchor="mm")

    # system_settings + lifespan
    box(d, 720, 850, 560, 50, *PALETTE["engine"])
    label(d, "system_settings", 740, 866, size=14, bold=True, anchor="lm")
    label(d, "UI flags: cost-metrics visibility · OpenRouter API key fallback",
          740, 886, size=11, color=TEXT_MUTED, anchor="lm")

    box(d, 720, 910, 560, 50, *PALETTE["engine"])
    label(d, "Lifespan", 740, 926, size=14, bold=True, anchor="lm")
    label(d, "Seed teams/models · register plugins · cost-table · prod-env checks",
          740, 946, size=11, color=TEXT_MUTED, anchor="lm")

    # ---- Right column: providers / persistence / observability
    section_label(d, "LLM Providers", 1450, 140)

    box(d, 1370, 160, 240, 70, *PALETTE["llm"])
    label(d, "Ollama :11434", 1490, 184, size=17, bold=True, anchor="mm")
    label(d, "local · /v1 OpenAI shape", 1490, 210, size=12, color=TEXT_MUTED, anchor="mm")

    box(d, 1370, 245, 240, 70, *PALETTE["llm"])
    label(d, "OpenRouter", 1490, 269, size=17, bold=True, anchor="mm")
    label(d, "cloud · 250+ models · catalog import", 1490, 295, size=12, color=TEXT_MUTED, anchor="mm")

    box(d, 1370, 330, 240, 56, *PALETTE["disabled"], dashed=True)
    label(d, "OpenAI / Anthropic / …", 1490, 351, size=14, anchor="mm")
    label(d, "registered, disabled", 1490, 372, size=11, color=TEXT_MUTED, anchor="mm")

    # Persistence
    section_label(d, "Persistence", 1450, 420)

    cylinder(d, 1490, 480, 220, 100, *PALETTE["db_op"])
    label(d, "Postgres (operational)", 1490, 460, size=14, bold=True, anchor="mm")
    label(d, "teams · keys · models · policies", 1490, 500, size=11, color=TEXT_MUTED, anchor="mm")
    label(d, "plugins · system_settings", 1490, 516, size=11, color=TEXT_MUTED, anchor="mm")

    cylinder(d, 1490, 600, 220, 100, *PALETTE["db_audit"])
    label(d, "Postgres (audit)", 1490, 580, size=14, bold=True, anchor="mm")
    label(d, "audit_log · reveal_requests", 1490, 620, size=11, color=TEXT_MUTED, anchor="mm")
    label(d, "AES-GCM · prune cron", 1490, 636, size=11, color=TEXT_MUTED, anchor="mm")

    cylinder(d, 1490, 720, 220, 100, *PALETTE["db_cache"])
    label(d, "Redis (optional)", 1490, 700, size=14, bold=True, anchor="mm")
    label(d, "rate-limit · cache", 1490, 740, size=11, color=TEXT_MUTED, anchor="mm")
    label(d, "memory:// fallback", 1490, 756, size=11, color=TEXT_MUTED, anchor="mm")

    # Observability
    section_label(d, "Observability", 1450, 830)
    box(d, 1370, 850, 240, 60, *PALETTE["obs"])
    label(d, "Grafana :3001", 1490, 872, size=15, bold=True, anchor="mm")
    label(d, "2 dashboards · iframe-embed", 1490, 893, size=11, color=TEXT_MUTED, anchor="mm")

    box(d, 1370, 920, 240, 60, *PALETTE["obs"])
    label(d, "Alertmanager :9093", 1490, 942, size=15, bold=True, anchor="mm")
    label(d, "alert routing", 1490, 963, size=11, color=TEXT_MUTED, anchor="mm")

    # ---- Edges (a curated set; the SVG has more, this is a readable subset)
    # Browser → admin-ui
    arrow(d, 290, 285, 339, 270, EDGE["control"])
    label(d, "cookie session", 240, 248, size=11, color=EDGE["control"])

    # admin-ui BFF → /admin/*
    arrow(d, 660, 273, 1099, 200, EDGE["control"])
    label(d, "master-key proxy", 800, 215, size=11, color=EDGE["control"])

    # Cline → /v1/chat/completions
    arrow(d, 290, 195, 719, 200, EDGE["model"])
    label(d, "chat completion", 400, 178, size=11, color=EDGE["model"])

    # Inference → Ollama / OpenRouter
    arrow(d, 1280, 605, 1369, 185, EDGE["model"])
    arrow(d, 1280, 615, 1369, 275, EDGE["model"])
    label(d, "local & cloud backends", 1330, 480, size=11, color=EDGE["model"])

    # AuthN/AuthZ → Postgres operational
    arrow(d, 1280, 310, 1380, 480, EDGE["ingest"])
    arrow(d, 1280, 385, 1380, 600, EDGE["ingest"])
    label(d, "RPM / budget", 1290, 420, size=11, color=EDGE["ingest"])

    # Audit → Postgres audit
    arrow(d, 1280, 685, 1380, 600, EDGE["ingest"])
    label(d, "append-only", 1290, 660, size=11, color=EDGE["ingest"])

    # Inference cache → Redis
    arrow(d, 1280, 640, 1380, 720, EDGE["ingest"])

    # Prometheus → /metrics
    arrow(d, 290, 1030, 720, 810, EDGE["metric"])
    label(d, "scrape 5s", 320, 950, size=11, color=EDGE["metric"])

    # Grafana / Alertmanager → Prometheus
    arrow(d, 1369, 880, 290, 1020, EDGE["metric"])

    # ---- Legend
    box(d, 50, 1110, 900, 130, "#fafafa", "#cbd5e1", radius=10)
    label(d, "EDGE LEGEND", 70, 1135, size=12, bold=True, color=TEXT_MUTED)

    legend = [
        ("control", "user / control flow",       (70,  1170)),
        ("ingest",  "persistence read / write",  (70,  1200)),
        ("model",   "model / inference",         (70,  1230)),
        ("metric",  "metrics / observability",   (450, 1170)),
        ("grey",    "in-process plugin sequence",(450, 1200)),
    ]
    for tone, txt, (lx, ly) in legend:
        _dashed_line(d, lx, ly, lx + 80, ly, EDGE[tone], 2)
        label(d, txt, lx + 95, ly, size=12, color=TEXT_MUTED, anchor="lm")

    label(d, "Box colour key: yellow = client · green = HTTP route · purple = engine · "
             "red = plugin · pink = LLM · blue = utility · violet = observability",
             450, 1230, size=10, color=TEXT_MUTED, anchor="lm")

    # Footer
    label(d, "LLMGateway v0.1 · MIT · FastAPI + LLMGateway · Next.js 15 · "
             "Postgres · Redis · Prometheus / Grafana",
             W - 60, H - 25, size=10, color=TEXT_MUTED, anchor="rm")

    im.save(OUT, dpi=(192, 192))
    print(f"wrote {OUT} ({im.size[0]}×{im.size[1]})")


if __name__ == "__main__":
    main()
