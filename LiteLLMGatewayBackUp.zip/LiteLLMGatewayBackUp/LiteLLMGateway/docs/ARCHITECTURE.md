# LLMGateway — Architecture

![LLMGateway system architecture](architecture.svg)

A bird's-eye view of how a request enters the gateway, traverses six
plugin stages, hits an LLM provider, and lands as an audit row plus a
Prometheus tick — and how operators inspect all of that through the
admin UI.

The diagram and this document are kept in lock-step with the code; if
you add a new plugin / DB / backend, update both.

---

## Reading the diagram

| Color  | Meaning                                       |
|--------|-----------------------------------------------|
| Yellow | Client (OpenAI SDK, operator browser)         |
| Green  | HTTP route surface                            |
| Purple | Engine — owns state, runs logic               |
| Red    | Plugin in the request chain                   |
| Pink   | LLM provider (and the LLMGateway shim)        |
| Blue   | Cross-cutting utility (health, metrics)       |
| Violet | Observability stack                           |
| Cylinder | Stateful store (Postgres, Redis)             |
| Dashed grey box | Logical cluster boundary               |

Edge tones:

| Color  | Meaning                                       |
|--------|-----------------------------------------------|
| Green  | User / control flow (session, master key proxy) |
| Pink   | Model / inference path                        |
| Blue   | Persistence read / write                      |
| Orange | Metrics scrape + Grafana datasource           |
| Grey   | In-process plugin sequence                    |

---

## Clusters

### Clients

- **Cline / IDE** — Any OpenAI-SDK editor integration (Cline, Continue.dev,
  Aider). Points its `baseURL` at the gateway and uses a virtual key as the
  bearer. Both `/v1/chat/completions` and `/chat/completions` (no `/v1`)
  are aliased server-side so the SDK works regardless of how the user
  configures the base URL.
- **Admin Browser** — Operator console. Authenticates to the admin-ui
  via an HMAC-signed session cookie (24 h TTL); never sees the
  gateway's master key directly.

### admin-ui (Next.js 15, port 3010)

- **Pages** — every operator surface: Teams, Keys, Connect, Audit,
  Metrics, UEBA, Models, Plugins, Smart Router, Settings, etc. Sidebar
  groups items by pipeline stage (`1 · AuthN` → `6 · Audit`).
- **BFF Proxy** (`/api/gateway/[...path]`) — strips the operator's
  cookie, injects `Authorization: Bearer <GATEWAY_MASTER_KEY>` server-
  side, and forwards to the gateway. Master key never reaches the
  browser. Adds `X-Operator: <user>` so the gateway's audit row knows
  which operator performed an admin action.
- **Auth** — HMAC-SHA256-signed cookie. No third-party auth lib; the
  shape is `<payload>.<signature>` where payload is a base64url JSON
  blob with `user / iat / exp`.

### Gateway Core (FastAPI, port 4000)

The big cluster. Hosts the public route surface, the 6-stage plugin
chain, the cross-cutting utilities, and the lifespan that seeds + wires
everything at startup.

#### Public route surface

| Route                       | Purpose                                |
|----------------------------|----------------------------------------|
| `POST /v1/chat/completions` | OpenAI-compatible chat (+ `/chat/completions` alias) |
| `GET  /v1/models`           | Model discovery (+ `/models` alias) |
| `*    /admin/*`             | Operator CRUD — teams, keys, policies, models, providers, audit, UEBA, settings |
| `GET  /metrics`             | Prometheus exposition                  |
| `GET  /ready /healthz`      | Liveness + per-dependency readiness    |

#### 6-stage plugin chain

Every chat completion walks these gates in order. A failure
short-circuits with a structured error, audited at the AuthN stage so
even refused requests are visible.

1. **AuthN** — bearer-token → `Principal`. Resolves master key, DB-backed
   virtual keys (hashed; `expires_at` enforced), or the `sk-dev+...`
   shortcut (non-prod only). Carries the operator's tier + team into the
   rest of the chain.
2. **AuthZ** — `authz_tiered` checks per-tier model ACL + agent mode +
   force-override permissions. `quota_redis` enforces RPM and daily $USD
   budget; surfaces `X-RateLimit-Limit/Remaining/Reset` on every response.
3. **DLP** — `guardrail_patterns` runs regex + heuristic redaction over
   the prompt. Findings are recorded; severe ones short-circuit.
4. **Smart Router** — `router_rule_based` evaluates a YAML rule chain
   (per-rule override table in DB). Picks the actual model name and
   records the routing reason on the response.
5. **Inference** — calls LLMGateway's `litellm_compat.Router` which
   translates to the chosen provider (Ollama, OpenRouter, OpenAI, …).
   `cache_redis` + `cache_semantic` (cosine similarity) short-circuit
   on a hit before any backend cost. Streaming uses SSE; non-streaming
   returns OpenAI-shaped JSON.
6. **Audit** — `audit_postgres` writes one row per call, body
   AES-GCM-encrypted at rest. A 4-eyes reveal flow gates plaintext
   retrieval. `siem_forward` ships the same row to an external SIEM
   when configured. `output_scan_secrets` checks the response for
   leaked secrets (post-stream for streaming). `observe_ueba` computes
   per-user baselines + 10-signal radar; auto-quarantines on anomaly.

#### Cross-cutting

- **truststore** — bootstraps the OS-native cert store (CryptoAPI on
  Windows, Security framework on macOS) before any HTTP client imports
  its SSL context. Required when an SSL-inspecting antivirus (e.g.
  Avast) injects its own root into the OS store but not certifi's
  bundle.
- **system_settings** — single key-value table for UI flags
  (cost-metrics visibility, OpenRouter API key fallback). Reads happen
  at Router-build time so they don't add latency to the request path.
- **Lifespan** — seeds teams/models from `policies.yaml` +
  `litellm_config.yaml` on first boot, registers cost tables for
  pricing, validates prod-only env vars, builds the Router.

### LLM Providers

The Inference plugin fans out to whichever backend the Router rule
chose, via the LLMGateway provider translation layer.

- **Ollama** (local, port 11434) — the cheap path. Models pinned in the
  registry with `ollama_chat/...` slugs.
- **OpenRouter** (cloud) — model aggregator. Admin UI has a catalog
  browser (`/settings/models` → Browse OpenRouter) that fetches OR's
  catalog via the gateway, lets the operator one-click import any
  model. Key managed in `/settings/app` (stored in `system_settings`,
  falls back from env var).
- **OpenAI / Anthropic / Bedrock / Azure / Vertex / Gemini / Groq /
  Together** — schemas exist in the model registry's typed form
  editor; configure as needed.

### Persistence

- **Postgres (operational)** — `teams`, `virtual_keys`, `ueba_alerts`,
  `elevation_requests`, `litellm_models`, `tier_configs`,
  `guardrail_patterns`, `plugin_configs`, `router_rule_overrides`,
  `audit_reveal_requests`, `system_settings`.
- **Postgres (audit)** — `audit_log`, append-only by convention. Body
  encrypted at rest; reveal requires a 4-eyes approval workflow.
  Retention pruner runs on demand or via cron.
- **Redis** (optional) — rate-limit counters + response cache. Falls
  back to in-process counters when `GATEWAY_REDIS_URL=memory://`.

### Observability (docker compose `obs` profile)

- **Prometheus** (port 9090) — scrapes the gateway's `/metrics` every
  5 s; 15 d retention; 2 alert rule files mounted from
  `docker/prometheus/rules/`.
- **Grafana** (port 3001) — two provisioned dashboards (Operations,
  Security). Anonymous viewer enabled + `allow_embedding=true` so the
  admin UI's `/observability` page can iframe them in.
- **Alertmanager** (port 9093) — routes alerts from Prometheus.

---

## Request walk-through (happy path)

1. Cline POSTs `chat/completions` with `model: "kimi-k2.6"` to
   `http://localhost:4000`.
2. Route lands on `chat_completions` (alias of `/v1/chat/completions`).
3. **AuthN** — bearer is hashed and matched against `virtual_keys`.
   Principal is built with `tier=L1_standard`, team derived from the
   key.
4. **AuthZ** — `authz_tiered` allows the tier→model combination;
   `quota_redis` increments today's RPM, sets
   `X-RateLimit-*` headers on the response context.
5. **DLP** — `guardrail_patterns` scans the prompt, redacts any
   matching secrets in-place, records findings.
6. **Smart Router** — rule chain picks `kimi-k2.6`. Recorded as
   `X-LLM-Routing-Reason`.
7. **Inference** — exact-hash + semantic cache lookups miss; the
   Router routes to `openrouter/moonshotai/kimi-k2`. Response carries
   `cost_usd` from OR's `usage`.
8. **Audit** — one row written to `audit_log` with AES-GCM-encrypted
   body; cost row counter increments; UEBA per-user baselines update.
9. Response returned to Cline with `X-LLM-Model-Used`,
   `X-LLM-Routing-Reason`, `X-RateLimit-*`, `X-Gateway-Request-Id`,
   `X-Gateway-Trace` headers.

## Refused request walk-through

If AuthN/AuthZ/DLP rejects, the request is short-circuited as a
`RefusalError` with the structured `error` object — but the AuthN
stage's audit hook still fires so the SOC sees refused requests in the
same table as allowed ones.

---

## Where to look for what

- New plugin → add an entry-point in `pyproject.toml` under
  `[project.entry-points."gateway.plugins"]`. The Lifespan auto-loads
  it.
- New provider → register a model in `/settings/models` with the
  provider's typed form fields. The litellm_compat.Router picks it up
  on save (server-side reload).
- New UI flag → drop a key in `system_settings` (`KEY_*` constants in
  `services/system_settings.py`); read it server-side at endpoint time;
  expose a setter in `/admin/settings/*`.
- New audit dimension → migrate `audit_log`, then update
  `services/audit.py` + the relevant plugin's `post_call` hook.
