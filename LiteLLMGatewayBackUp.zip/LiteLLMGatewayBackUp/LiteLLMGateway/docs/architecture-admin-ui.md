# Admin UI security model

The admin UI is a Next.js 15 app that **never sees the gateway master key**.
Every gateway call goes through a server-side BFF proxy that authenticates
the operator via cookie and injects the master key on its way upstream.

```
┌──────────┐                              ┌──────────────┐
│ Browser  │  cookie (httpOnly, SameSite) │ Next.js BFF  │  Bearer master key │ Gateway │
│          │ ───────────────────────────► │              │ ────────────────────► │         │
│          │                              │  · /api/auth │                       │         │
│          │ ◄─────────────────────────── │  · /api/     │ ◄──────────────────── │         │
└──────────┘                              │    gateway/* │                       └─────────┘
                                          └──────────────┘
                                                ▲
                                                │ reads from process.env
                                                │  GATEWAY_MASTER_KEY
                                                │  ADMIN_USER / ADMIN_PASS
                                                │  SESSION_SECRET
```

The browser bundle contains **no secrets**.

## How a request flows

1. Operator opens `https://admin.example.com/teams`.
2. `middleware.ts` runs on the edge, verifies the HMAC-signed session
   cookie. Bad / missing cookie → redirect to `/login?next=/teams`.
3. Operator signs in via `POST /api/auth/login { user, pass }`. The route
   constant-time-compares against `ADMIN_USER` / `ADMIN_PASS` env vars and,
   on success, sets a `gw_admin_session` cookie:
   - `httpOnly: true` — JavaScript cannot read it.
   - `sameSite: lax` — protects against CSRF on top-level navigations.
   - `secure: true` in production (HTTPS only).
   - Format: `<base64url JSON payload>.<base64url HMAC-SHA256>`.
4. Operator navigates back to `/teams`. The middleware accepts the cookie
   and the page loads.
5. The page calls `fetch("/api/gateway/admin/teams")`. This hits the BFF
   route `app/api/gateway/[...path]/route.ts`, which:
   - Verifies the session cookie (re-uses the same library as middleware).
   - Reads `GATEWAY_MASTER_KEY` from server-only env.
   - Forwards the request to `${GATEWAY_URL}/admin/teams` with
     `Authorization: Bearer <master_key>` and `X-Operator: <user>`.
   - Streams the response back unchanged.

## Env vars

| Var                   | Where used     | What it does                                  |
|-----------------------|----------------|-----------------------------------------------|
| `GATEWAY_URL`         | BFF only       | Upstream gateway base URL                     |
| `GATEWAY_MASTER_KEY`  | BFF only       | Master key for admin endpoints                |
| `ADMIN_USER`          | BFF only       | Username accepted by `/api/auth/login`        |
| `ADMIN_PASS`          | BFF only       | Password (constant-time compared)             |
| `SESSION_SECRET`      | BFF + middleware | HMAC key for signing the session cookie      |
| `NEXT_PUBLIC_*`       | Browser bundle | **Never put a secret in a NEXT_PUBLIC_ var.** |

`SESSION_SECRET` should be ≥ 32 random bytes. Generate one with:

```sh
openssl rand -base64 48
```

Rotating it invalidates every active session (a real account system would
do this in stages; for a single-admin install just rotate during a quiet
window).

## What this slice does NOT (yet) do

* **OIDC / SSO.** Single admin user from env vars. Sprint 4 swaps in
  Keycloak / Entra OIDC via `next-auth` or a direct PKCE flow. The cookie
  shape is identical, so consuming code (middleware, BFF proxy) won't change.
* **CSRF tokens.** We rely on `SameSite=Lax` and same-origin fetches. If
  the admin UI ever opens cross-origin form posts (it shouldn't), add a
  double-submit cookie or origin check in the BFF route.
* **Rate limiting on /api/auth/login.** Currently uncapped. Add a Redis
  bucket in front for prod.
* **MFA.** Coming with OIDC.

## How to roll out

1. `cp admin-ui/.env.example admin-ui/.env.local` and fill in real values.
2. Generate a real `SESSION_SECRET` (see above).
3. Set `ADMIN_USER` / `ADMIN_PASS` to something other than `admin/admin`.
4. Set `GATEWAY_MASTER_KEY` to whatever the gateway is using.
5. Start the UI: `npm run dev` (or `docker compose up admin-ui`).

## Security review checklist

- [ ] Master key not in the browser bundle (`npm run build && grep -r master  .next` returns no hits)
- [ ] `/api/auth/login` returns 401 for wrong creds with same timing as wrong user
- [ ] Cookie has `httpOnly`, `sameSite=lax`, `secure` in prod
- [ ] Middleware redirects unauthenticated `/teams` → `/login?next=/teams`
- [ ] Middleware returns 401 JSON (not redirect) for unauthenticated `/api/gateway/*`
- [ ] BFF strips `Authorization` header from the inbound request before injecting its own
- [ ] BFF strips `Cookie` header from the upstream call (gateway must not see operator's cookie)
- [ ] Logout sets `Max-Age=0`
- [ ] `SESSION_SECRET` is ≥ 32 bytes and rotated quarterly
