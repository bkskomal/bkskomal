# Plugin development guide

A plugin is a Python class that subclasses `gateway.plugins.base.GatewayPlugin`
and is registered via a Python entry point. The gateway loads it at startup
and invokes the relevant lifecycle method(s) at the matching stage of each
request.

## The contract in one screen

```python
from gateway.plugins.base import (
    GatewayPlugin, PluginKind, PluginVerdict,
    HookResult, RequestContext, ResponseContext, Finding,
)

class MyPlugin(GatewayPlugin):
    name = "my_plugin"           # unique, snake_case
    kind = PluginKind.DLP        # which stage this plugin runs at
    version = "0.1.0"
    description = "What this plugin does in one sentence"

    async def setup(self, app_settings: dict) -> None:
        """Open connections, load models. Called once at startup."""

    async def teardown(self) -> None:
        """Clean up. Called once at shutdown."""

    async def on_pre_call(self, ctx: RequestContext) -> HookResult:
        """Called BEFORE inference. Can mutate ctx.messages and append findings."""
        return HookResult(verdict=PluginVerdict.ALLOW)

    async def on_route_select(self, ctx: RequestContext) -> HookResult:
        """ROUTER plugins only — pick a model and set ctx.model_selected."""
        return HookResult(verdict=PluginVerdict.ALLOW)

    async def on_post_call(self, ctx: ResponseContext) -> HookResult:
        """Called AFTER inference, with the response in ctx.response."""
        return HookResult(verdict=PluginVerdict.ALLOW)

    async def on_audit(self, ctx: ResponseContext) -> None:
        """AUDIT plugins only — write durable state. No verdict."""
```

## Plugin kinds and where they run

| Kind          | Stage             | Multiple allowed | Returns a verdict |
|---------------|-------------------|------------------|-------------------|
| `auth`        | pre-call          | yes              | yes               |
| `authz`       | pre-call          | yes              | yes               |
| `dlp`         | pre-call          | yes              | yes (may mutate)  |
| `guardrail`   | pre-call          | yes              | yes               |
| `router`      | pre-call (last)   | **exactly one**  | yes (sets model)  |
| `output_scan` | post-call         | yes              | yes (may scrub)   |
| `observe`     | post-call         | yes              | no                |
| `audit`       | post-call (last)  | yes              | no                |

Verdicts:

| Verdict        | Effect                                                    |
|----------------|-----------------------------------------------------------|
| `ALLOW`        | continue unchanged                                        |
| `ALLOW_MUTATE` | continue with mutations the plugin applied to `ctx`       |
| `WARN`         | continue; finding is recorded but doesn't block           |
| `REFUSE`       | short-circuit; gateway returns a structured 422 error     |

## Packaging your plugin

```toml
# pyproject.toml of your-org-llm-guard-plugin/
[project]
name = "your-org-llm-guard-plugin"

[project.entry-points."litellm_gateway.plugins"]
llm_guard = "your_org_llm_guard_plugin:LLMGuardPlugin"
```

Install it alongside the gateway (`pip install -e .` from the plugin
directory) and add `llm_guard` to `GATEWAY_PLUGINS`. Done. No code change in
the gateway.

## Worked example — a tiny banlist DLP plugin

```python
# my_banlist_plugin/__init__.py
from gateway.plugins.base import (
    GatewayPlugin, PluginKind, PluginVerdict,
    HookResult, RequestContext, Finding,
)

BANLIST = {"competitor-corp", "secret-project-x"}

class BanlistDLP(GatewayPlugin):
    name = "banlist_dlp"
    kind = PluginKind.DLP
    description = "Refuse prompts mentioning blocklisted keywords"

    async def on_pre_call(self, ctx: RequestContext) -> HookResult:
        findings = []
        for i, msg in enumerate(ctx.messages):
            text = (msg.get("content") or "").lower()
            for word in BANLIST:
                if word in text:
                    findings.append(Finding(
                        plugin=self.name,
                        kind="banned_keyword",
                        severity="high",
                        message=f"Banned keyword {word!r} found",
                        location=f"messages[{i}].content",
                    ))
        if findings:
            return HookResult(
                verdict=PluginVerdict.REFUSE,
                findings=findings,
                reason="Prompt contains a banned keyword",
            )
        return HookResult(verdict=PluginVerdict.ALLOW)
```

## Testing

```python
# tests/test_my_plugin.py
import pytest
from gateway.plugins.base import RequestContext, Principal, PluginVerdict
from my_banlist_plugin import BanlistDLP

@pytest.mark.asyncio
async def test_banlist_blocks_competitor_mention():
    plugin = BanlistDLP()
    ctx = RequestContext(
        request_id="t1",
        principal=Principal(user_id="alice", team_id="qa", tier="L1_standard"),
        model_requested="gemma-4-27b",
        messages=[{"role": "user", "content": "tell me about competitor-corp"}],
    )
    result = await plugin.on_pre_call(ctx)
    assert result.verdict == PluginVerdict.REFUSE
    assert len(result.findings) == 1
```

## Conventions

* **Name is destiny.** Use `<kind>_<source>` (e.g., `dlp_presidio`,
  `guardrail_llm_guard`, `router_rule_based`).
* **Be cheap.** Anything you do at pre-call adds latency to every request.
  Cache aggressively. Lazy-load models in `setup()`, never in `on_pre_call`.
* **Surface decisions.** Always emit a `Finding` — even when allowing — so
  audit + UEBA see what your plugin saw.
* **Never log raw secret values.** If you detect a credential, log the
  pattern + location, not the value itself.
* **Don't write to global state.** Use instance attributes; multiple
  gateway replicas run concurrently.
