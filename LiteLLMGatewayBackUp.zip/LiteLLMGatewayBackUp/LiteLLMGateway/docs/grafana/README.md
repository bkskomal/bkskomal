# Grafana dashboards

Two ready-to-import dashboards for the LiteLLM Gateway.

| File              | What it shows                                                       |
|-------------------|---------------------------------------------------------------------|
| `operations.json` | Request rate, latency p50/p95/p99, tokens/sec, spend, plugin lat.   |
| `security.json`   | Refusal / rate-limit / budget / DLP / UEBA / JIT-elevation panels   |

## Quickstart — local dev (recommended)

The repo's `docker-compose.yml` ships an `obs` profile that brings up Prometheus
+ Grafana with the datasource and these dashboards auto-provisioned. **No
manual import.**

```bash
# from the repo root
docker compose --profile obs up -d prometheus grafana
```

Then:

| Service     | URL                       | Login         |
|-------------|---------------------------|---------------|
| Grafana     | http://localhost:3001     | admin / admin |
| Prometheus  | http://localhost:9090     | (none)        |

The two dashboards appear under **Dashboards → Browse** (no folder — at
the root). They auto-refresh every 30s by default.

To make the **Observability Bus** banner on the Overview page link directly
to Grafana, set this env var when starting the gateway:

```bash
export GATEWAY_GRAFANA_URL=http://localhost:3001
```

The pill turns from "configured" to "active" and clicking it opens Grafana.

## Editing dashboards

`docs/grafana/` is **bind-mounted** into the Grafana container at
`/var/lib/grafana/dashboards`. Edit `operations.json` or `security.json` in
the repo and Grafana picks the change up within ~10 seconds (per the
provisioning provider's `updateIntervalSeconds`). No restart needed. Commit
the JSON the same way you commit any source file.

You can also edit a dashboard *inside* Grafana (the provisioning is
configured with `allowUiUpdates: true`); use the JSON model panel to copy
the change back into the repo. Don't forget to commit.

## Bringing it down

```bash
docker compose --profile obs down
```

Add `-v` to also wipe the Prometheus tsdb + Grafana storage if you want a
truly clean state.

## Manual import (if you don't use the compose profile)

1. Grafana → **Dashboards** → **New** → **Import**.
2. Upload the JSON file, or paste its contents.
3. When prompted, pick the Prometheus data source that scrapes the gateway's
   `/metrics` endpoint. (Variable name in the JSON: `DS_PROMETHEUS`.)
4. Save.

If you're rolling your own Prometheus, point it at the gateway:

```yaml
# prometheus.yml
scrape_configs:
  - job_name: litellm-gateway
    metrics_path: /metrics
    static_configs:
      - targets: ["host.docker.internal:4000"]   # gateway running on host
      # or:
      # - targets: ["gateway:4000"]              # gateway in the same compose network
```

## Metrics the dashboards consume

The gateway exposes the following metric families (see `gateway/src/gateway/main.py`):

| Metric                              | Type      | Labels                          |
|-------------------------------------|-----------|---------------------------------|
| `gateway_requests_total`            | counter   | verdict, model, team            |
| `gateway_request_latency_seconds`   | histogram | model                           |
| `gateway_tokens_total`              | counter   | direction, model, team          |
| `gateway_cost_usd_total`            | counter   | model, team                     |
| `gateway_dlp_hits_total`            | counter   | kind, severity                  |
| `gateway_plugin_latency_seconds`    | histogram | plugin, stage                   |
| `gateway_ueba_alerts_total`         | counter   | signal, severity                |

`verdict` values: `allow` · `refused` · `rate_limited` · `budget_exceeded` · `error`.

## Suggested Alertmanager rules

```yaml
groups:
  - name: litellm-gateway
    rules:
      - alert: GatewayHighRefusalRate
        expr: sum(rate(gateway_requests_total{verdict!="allow"}[5m]))
              / sum(rate(gateway_requests_total[5m])) > 0.20
        for: 10m
        labels: { severity: warning }
        annotations:
          summary: "Gateway refusing > 20% of traffic for 10 min"

      - alert: GatewayUEBACritical
        expr: increase(gateway_ueba_alerts_total{severity="critical"}[5m]) > 0
        labels: { severity: critical }
        annotations:
          summary: "Critical UEBA signal raised"

      - alert: GatewayBudgetExceeded
        expr: increase(gateway_requests_total{verdict="budget_exceeded"}[1h]) > 0
        labels: { severity: warning }
        annotations:
          summary: "A team has exceeded its daily budget"
```
