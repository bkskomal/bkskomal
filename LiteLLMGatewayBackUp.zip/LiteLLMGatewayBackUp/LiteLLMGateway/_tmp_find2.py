import os
for root, _, files in os.walk('gateway/src/gateway'):
    for f in files:
        if not f.endswith('.py'):
            continue
        path = os.path.join(root, f)
        with open(path, encoding='utf-8') as fh:
            for i, line in enumerate(fh, 1):
                if 'audit' in line and ('search' in line or 'csv' in line):
                    print(f"{path}:{i}:{line.rstrip()}")
