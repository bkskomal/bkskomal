"""Mock vLLM — a deterministic OpenAI-compatible inference backend.

Used as the upstream for the gateway in tests so the full request flow can
exercise real HTTP semantics (streaming, errors, retries) without a GPU.

Endpoints
---------
GET  /v1/models               list registered models (matches OpenAI shape)
POST /v1/chat/completions     non-streaming and streaming completions
POST /v1/_admin/fail-next     queue a one-shot failure on the next request
                              (used in tests for fallback / retry coverage)
GET  /health                  liveness

The response content is a deterministic echo of the last user message,
prefixed by the model name. Token counts are estimated by char/4 — close
enough for the gateway's accounting code to be exercised.
"""

from __future__ import annotations

import json
import time
import uuid
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import JSONResponse, StreamingResponse


app = FastAPI(title="Mock vLLM", version="0.1.0")

# Models served by this mock — match the names the gateway's litellm_config.yaml
# expects so the same DSN works in test and production.
MOCK_MODELS = [
    "Qwen/Qwen3-Coder-30B-A3B-Instruct",
    "google/gemma-4-27b-it",
    "moonshot/kimi-k2.6",
]

# Queue of pending failure modes (consumed FIFO by the next inference call).
_FAIL_QUEUE: list[dict[str, Any]] = []


# ---------------------------------------------------------------------------
# Health + admin
# ---------------------------------------------------------------------------
@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/v1/models")
async def list_models() -> dict[str, Any]:
    return {
        "object": "list",
        "data": [
            {"id": m, "object": "model", "created": int(time.time()), "owned_by": "mock"}
            for m in MOCK_MODELS
        ],
    }


@app.post("/v1/_admin/fail-next")
async def fail_next(status_code: int = Query(500),
                    detail: str = Query("mock-injected failure")) -> dict[str, Any]:
    """Queue a failure for the next inference call. Tests use this for
    fallback / retry assertions."""
    _FAIL_QUEUE.append({"status_code": status_code, "detail": detail})
    return {"queued": True, "pending": len(_FAIL_QUEUE)}


@app.post("/v1/_admin/reset")
async def reset() -> dict[str, Any]:
    _FAIL_QUEUE.clear()
    return {"cleared": True}


# ---------------------------------------------------------------------------
# Chat completions
# ---------------------------------------------------------------------------
@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    body = await request.json()
    model    = body.get("model", "unknown")
    messages = body.get("messages") or []
    stream   = bool(body.get("stream", False))

    # Consume one queued failure if present.
    if _FAIL_QUEUE:
        injected = _FAIL_QUEUE.pop(0)
        raise HTTPException(
            status_code=injected["status_code"],
            detail=injected["detail"],
        )

    # Build a deterministic response that echoes the last user message.
    last_user = next(
        (m.get("content", "") for m in reversed(messages) if m.get("role") == "user"),
        "",
    )
    if isinstance(last_user, list):
        # multi-modal content: just stringify the first text part for tests
        last_user = next(
            (c.get("text", "") for c in last_user if isinstance(c, dict) and c.get("type") == "text"),
            "",
        )
    answer = f"[mock {model}] You said: {last_user.strip()[:240]}"

    prompt_chars     = sum(len(str(m.get("content", ""))) for m in messages)
    prompt_tokens    = max(1, prompt_chars // 4)
    completion_tokens = max(1, len(answer) // 4)

    payload = {
        "id":      f"chatcmpl-{uuid.uuid4().hex[:24]}",
        "object":  "chat.completion",
        "created": int(time.time()),
        "model":   model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": answer},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens":     prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens":      prompt_tokens + completion_tokens,
        },
    }

    if not stream:
        return JSONResponse(content=payload)

    # SSE stream — emit the answer in 3 chunks for tests of chunked handling.
    async def gen():
        chunk_id = payload["id"]
        created  = payload["created"]
        third = max(1, len(answer) // 3)
        deltas = [answer[:third], answer[third:2 * third], answer[2 * third:]]
        for i, d in enumerate(deltas):
            evt = {
                "id":      chunk_id,
                "object":  "chat.completion.chunk",
                "created": created,
                "model":   model,
                "choices": [{
                    "index": 0,
                    "delta": {"content": d} if d else {},
                    "finish_reason": None if i < len(deltas) - 1 else "stop",
                }],
            }
            yield f"data: {json.dumps(evt)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream")
