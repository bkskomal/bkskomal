"""Tiny OpenAI-compatible mock for end-to-end gateway tests."""
__version__ = "0.1.0"
