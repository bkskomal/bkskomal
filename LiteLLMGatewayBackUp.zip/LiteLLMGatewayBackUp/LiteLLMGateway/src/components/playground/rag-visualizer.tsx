'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowRight } from 'lucide-react'

export function RAGVisualizer() {
  const steps = [
    { title: 'User Query', description: 'User asks a question' },
    { title: 'Embedding', description: 'Convert query to vector' },
    { title: 'Vector Search', description: 'Find relevant documents' },
    { title: 'Retrieval', description: 'Get top-k documents' },
    { title: 'Context Injection', description: 'Add to prompt' },
    { title: 'LLM Response', description: 'Generate answer' },
  ]

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>RAG Flow Visualization</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between overflow-x-auto">
          {steps.map((step, index) => (
            <div key={step.title} className="flex items-center">
              <div className="text-center min-w-[150px]">
                <div className="bg-blue-500 text-white px-4 py-2 rounded-lg">
                  {step.title}
                </div>
                <p className="text-sm text-gray-600 mt-1">{step.description}</p>
              </div>
              {index < steps.length - 1 && (
                <ArrowRight className="mx-4 h-4 w-4 text-gray-400" />
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}