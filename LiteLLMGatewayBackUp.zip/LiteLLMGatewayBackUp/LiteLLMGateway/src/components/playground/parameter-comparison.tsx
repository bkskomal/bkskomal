'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const models = [
  { name: 'GPT-3.5', parameters: '175B', memory: '350GB', accuracy: 85, speed: 95 },
  { name: 'GPT-4', parameters: '1.76T', memory: '3.5TB', accuracy: 95, speed: 70 },
  { name: 'Claude 3', parameters: 'Unknown', memory: 'Unknown', accuracy: 92, speed: 80 },
  { name: 'Llama 2 70B', parameters: '70B', memory: '140GB', accuracy: 80, speed: 90 },
]

export function ParameterComparison() {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {models.map((model) => (
        <Card key={model.name} className="glassmorphism">
          <CardHeader>
            <CardTitle className="text-lg">{model.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Parameters:</span>
                <Badge>{model.parameters}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Memory:</span>
                <Badge variant="outline">{model.memory}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Accuracy:</span>
                <Badge>{model.accuracy}%</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Speed:</span>
                <Badge>{model.speed}%</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}