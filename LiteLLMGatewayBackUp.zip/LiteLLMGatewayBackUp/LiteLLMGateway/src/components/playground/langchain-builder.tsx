'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useState } from 'react'

export function LangChainBuilder() {
  const [chain, setChain] = useState(['Prompt', 'LLM', 'Output'])

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>LangChain Builder</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            {chain.map((component, index) => (
              <div key={index} className="flex items-center">
                <div className="bg-purple-500 text-white px-4 py-2 rounded">
                  {component}
                </div>
                {index < chain.length - 1 && <span className="mx-2">→</span>}
              </div>
            ))}
          </div>
          <div className="flex space-x-2">
            <Button>Add Tool</Button>
            <Button>Add Memory</Button>
            <Button>Execute Chain</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}