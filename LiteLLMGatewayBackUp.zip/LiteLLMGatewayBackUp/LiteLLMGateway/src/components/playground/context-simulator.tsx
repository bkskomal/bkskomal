'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { InteractiveContextVisualizer } from '@/components/context-window/interactive-visualizer'

export function ContextSimulator() {
  return <InteractiveContextVisualizer />
}