'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { estimateTokens } from '@/lib/utils'

export function TokenCalculator() {
  const [text, setText] = useState('')
  const [language, setLanguage] = useState('english')

  const tokenCount = estimateTokens(text)
  const charCount = text.length
  const wordCount = text.split(/\s+/).filter(word => word.length > 0).length

  const getLanguageMultiplier = (lang: string) => {
    switch (lang) {
      case 'english': return 1
      case 'hindi': return 0.7
      case 'punjabi': return 0.7
      case 'chinese': return 1.5
      default: return 1
    }
  }

  const adjustedTokens = Math.ceil(tokenCount * getLanguageMultiplier(language))

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Token Calculator</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Enter Text:</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type your text here..."
                className="mt-2 min-h-[200px]"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Language:</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="mt-2 w-full p-2 border rounded-md"
              >
                <option value="english">English</option>
                <option value="hindi">Hindi</option>
                <option value="punjabi">Punjabi</option>
                <option value="chinese">Chinese</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Characters:</span>
              <Badge>{charCount}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span>Words:</span>
              <Badge>{wordCount}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span>Estimated Tokens:</span>
              <Badge variant="secondary">{adjustedTokens}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span>Cost (GPT-4):</span>
              <Badge variant="outline">${(adjustedTokens * 0.00003).toFixed(4)}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}