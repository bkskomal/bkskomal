'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const examples = [
  { text: 'Hello world', chars: 11, words: 2, tokens: 2 },
  { text: 'नमस्ते दुनिया', chars: 13, words: 2, tokens: 4 },
  { text: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ', chars: 12, words: 3, tokens: 5 },
  { text: 'console.log("Hello");', chars: 20, words: 2, tokens: 8 },
]

export function TokenComparison() {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>Token Examples by Language</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {examples.map((example, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="font-mono text-lg mb-2">{example.text}</div>
              <div className="flex space-x-4 text-sm">
                <Badge>Chars: {example.chars}</Badge>
                <Badge>Words: {example.words}</Badge>
                <Badge variant="secondary">Tokens: {example.tokens}</Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}