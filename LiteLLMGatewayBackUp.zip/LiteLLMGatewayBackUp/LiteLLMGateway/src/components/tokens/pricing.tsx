'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const pricing = [
  { model: 'GPT-4', input: 0.03, output: 0.06, per: '1K tokens' },
  { model: 'GPT-3.5', input: 0.0015, output: 0.002, per: '1K tokens' },
  { model: 'Claude 3', input: 0.008, output: 0.024, per: '1K tokens' },
  { model: 'Llama 2', input: 0.0003, output: 0.0006, per: '1K tokens' },
]

export function TokenPricing() {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>Token Pricing Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {pricing.map((model) => (
            <div key={model.model} className="flex justify-between items-center p-4 border rounded-lg">
              <div>
                <div className="font-semibold">{model.model}</div>
                <div className="text-sm text-gray-600">{model.per}</div>
              </div>
              <div className="text-right">
                <div className="text-sm">Input: ${model.input}</div>
                <div className="text-sm">Output: ${model.output}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}