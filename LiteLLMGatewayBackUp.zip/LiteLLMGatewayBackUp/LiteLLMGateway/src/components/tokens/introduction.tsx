'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export function TokenIntroduction() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Understanding Tokens</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Learn how AI models break text into tokens and why it matters for pricing and performance
        </p>
      </div>

      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle>What are Tokens?</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-300">
            Tokens are the basic units of text that AI models process. They can be words, parts of words, or even characters.
            Understanding tokens is crucial for managing costs and optimizing performance.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}