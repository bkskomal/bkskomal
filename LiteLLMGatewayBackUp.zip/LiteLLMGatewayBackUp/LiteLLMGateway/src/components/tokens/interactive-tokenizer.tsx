'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { estimateTokens } from '@/lib/utils'

export function InteractiveTokenizer() {
  const [text, setText] = useState('')
  const [language, setLanguage] = useState('english')

  const charCount = text.length
  const wordCount = text.split(/\s+/).filter(word => word.length > 0).length
  const tokenCount = estimateTokens(text)

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>Interactive Tokenizer</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter text to tokenize..."
              className="min-h-[200px]"
            />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="mt-2 w-full p-2 border rounded-md"
            >
              <option value="english">English</option>
              <option value="hindi">Hindi</option>
              <option value="punjabi">Punjabi</option>
              <option value="code">Code</option>
            </select>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span>Characters:</span>
              <Badge>{charCount}</Badge>
            </div>
            <div className="flex justify-between">
              <span>Words:</span>
              <Badge>{wordCount}</Badge>
            </div>
            <div className="flex justify-between">
              <span>Estimated Tokens:</span>
              <Badge variant="secondary">{tokenCount}</Badge>
            </div>
            <div className="flex justify-between">
              <span>Cost (GPT-4):</span>
              <Badge variant="outline">${(tokenCount * 0.00003).toFixed(4)}</Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}