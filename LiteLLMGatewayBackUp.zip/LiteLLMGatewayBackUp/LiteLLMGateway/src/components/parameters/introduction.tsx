'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export function ParameterIntroduction() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Model Parameters</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Understanding how model size affects performance, cost, and capabilities
        </p>
      </div>

      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle>What are Parameters?</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-300">
            Parameters are the learned weights and biases in neural networks that determine how the model processes information.
            More parameters generally mean better performance but higher computational costs.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}