'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const models = [
  { name: '7B', parameters: '7 Billion', memory: '~14GB', useCase: 'Mobile/Edge devices' },
  { name: '13B', parameters: '13 Billion', memory: '~26GB', useCase: 'Personal computers' },
  { name: '70B', parameters: '70 Billion', memory: '~140GB', useCase: 'Professional workstations' },
  { name: '405B', parameters: '405 Billion', memory: '~810GB', useCase: 'Enterprise servers' },
]

export function ParameterComparison() {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {models.map((model) => (
        <Card key={model.name} className="glassmorphism">
          <CardHeader>
            <CardTitle className="text-2xl">{model.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div>
                <span className="text-sm text-gray-600">Parameters:</span>
                <Badge className="ml-2">{model.parameters}</Badge>
              </div>
              <div>
                <span className="text-sm text-gray-600">Memory:</span>
                <Badge variant="outline" className="ml-2">{model.memory}</Badge>
              </div>
              <div>
                <span className="text-sm text-gray-600">Use Case:</span>
                <p className="text-sm mt-1">{model.useCase}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}