'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Cpu, Zap } from 'lucide-react'

export function TrainingVsInference() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cpu className="h-5 w-5" />
            Training Phase
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
            <li>• Process massive datasets (TBs)</li>
            <li>• Learn statistical patterns</li>
            <li>• Update model parameters</li>
            <li>• Takes weeks/months</li>
            <li>• Requires supercomputers</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Inference Phase
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
            <li>• Use trained model</li>
            <li>• Generate predictions</li>
            <li>• Fixed parameters</li>
            <li>• Real-time responses</li>
            <li>• Runs on various hardware</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}