'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Layers, ArrowRight, Play, Pause } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'

interface TransformerLayer {
  id: string
  name: string
  description: string
  color: string
}

const layers: TransformerLayer[] = [
  {
    id: 'embedding',
    name: 'Embedding Layer',
    description: 'Convert tokens to dense vectors',
    color: 'from-blue-500 to-blue-600'
  },
  {
    id: 'positional',
    name: 'Positional Encoding',
    description: 'Add position information',
    color: 'from-green-500 to-green-600'
  },
  {
    id: 'attention1',
    name: 'Multi-Head Attention',
    description: 'Process relationships between tokens',
    color: 'from-purple-500 to-purple-600'
  },
  {
    id: 'norm1',
    name: 'Layer Normalization',
    description: 'Normalize activations',
    color: 'from-orange-500 to-orange-600'
  },
  {
    id: 'ffn',
    name: 'Feed Forward',
    description: 'Non-linear transformations',
    color: 'from-red-500 to-red-600'
  },
  {
    id: 'attention2',
    name: 'Multi-Head Attention',
    description: 'Cross-attention (decoder)',
    color: 'from-purple-500 to-purple-600'
  },
  {
    id: 'norm2',
    name: 'Layer Normalization',
    description: 'Normalize activations',
    color: 'from-orange-500 to-orange-600'
  },
  {
    id: 'output',
    name: 'Output Layer',
    description: 'Generate next token probabilities',
    color: 'from-indigo-500 to-indigo-600'
  }
]

export function TransformerVisualization() {
  const [isAnimating, setIsAnimating] = useState(false)
  const [currentLayer, setCurrentLayer] = useState(0)
  const [numLayers, setNumLayers] = useState([6])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isAnimating) {
      interval = setInterval(() => {
        setCurrentLayer((prev) => (prev + 1) % layers.length)
      }, 2000)
    }
    return () => clearInterval(interval)
  }, [isAnimating])

  const handlePlay = () => {
    setIsAnimating(!isAnimating)
    if (!isAnimating) {
      setCurrentLayer(0)
    }
  }

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              Transformer Architecture
            </CardTitle>
            <CardDescription>
              Interactive visualization of transformer layers processing input tokens
            </CardDescription>
          </div>
          <Button
            size="sm"
            onClick={handlePlay}
            variant={isAnimating ? 'destructive' : 'default'}
          >
            {isAnimating ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Layer Controls */}
          <div className="flex items-center space-x-4">
            <label className="text-sm font-medium">Number of Layers:</label>
            <Slider
              value={numLayers}
              onValueChange={setNumLayers}
              max={12}
              min={1}
              step={1}
              className="w-32"
            />
            <span className="text-sm text-gray-600 dark:text-gray-300">{numLayers[0]}</span>
          </div>

          {/* Visualization */}
          <div className="relative h-96 overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800 p-4">
            <div className="flex h-full items-center justify-center">
              {/* Input Tokens */}
              <div className="flex flex-col space-y-2">
                <div className="text-xs font-medium mb-2">Input Tokens</div>
                {['The', 'cat', 'sat', 'on', 'the', 'mat'].map((token, i) => (
                  <motion.div
                    key={token}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="px-3 py-1 bg-blue-500 text-white rounded text-sm"
                  >
                    {token}
                  </motion.div>
                ))}
              </div>

              <ArrowRight className="mx-4 h-6 w-6 text-gray-400" />

              {/* Transformer Layers */}
              <div className="flex flex-col space-y-1">
                {layers.slice(0, numLayers[0]).map((layer, index) => (
                  <motion.div
                    key={layer.id}
                    initial={{ opacity: 0.3 }}
                    animate={{ 
                      opacity: isAnimating && index === currentLayer ? 1 : 0.3,
                      scale: isAnimating && index === currentLayer ? 1.05 : 1
                    }}
                    transition={{ duration: 0.3 }}
                    className={cn(
                      'px-3 py-2 rounded text-xs font-medium text-white bg-gradient-to-r ${layer.color}',
                      isAnimating && index === currentLayer && 'shadow-lg'
                    )}
                  >
                    {layer.name}
                  </motion.div>
                ))}
              </div>

              <ArrowRight className="mx-4 h-6 w-6 text-gray-400" />

              {/* Output */}
              <div className="flex flex-col space-y-2">
                <div className="text-xs font-medium mb-2">Output</div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: isAnimating ? 1 : 0.3, scale: 1 }}
                  transition={{ delay: 0.5 }}
                  className="px-3 py-1 bg-green-500 text-white rounded text-sm"
                >
                  .
                </motion.div>
              </div>
            </div>
          </div>

          {/* Layer Details */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentLayer}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
              <h4 className="font-medium mb-2">{layers[currentLayer].name}</h4>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {layers[currentLayer].description}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  )
}