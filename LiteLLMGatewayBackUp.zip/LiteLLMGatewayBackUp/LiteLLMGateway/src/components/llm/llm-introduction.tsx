'use client'

import { motion } from 'framer-motion'
import { Brain, MessageSquare, Zap } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function LLMIntroduction() {
  return (
    <section className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tight gradient-text">
          What are Large Language Models?
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Large Language Models (LLMs) are AI systems trained on vast amounts of text data to understand and generate human-like language.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="h-full glassmorphism">
            <CardHeader>
              <Brain className="h-8 w-8 text-ai-500 mb-2" />
              <CardTitle>Neural Networks</CardTitle>
              <CardDescription>Built on transformer architecture with billions of parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                LLMs use deep neural networks with attention mechanisms to process and understand language patterns.
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="h-full glassmorphism">
            <CardHeader>
              <MessageSquare className="h-8 w-8 text-neural-500 mb-2" />
              <CardTitle>Language Understanding</CardTitle>
              <CardDescription>Comprehend context, semantics, and intent</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                These models can understand context, generate coherent responses, and perform various language tasks.
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="h-full glassmorphism">
            <CardHeader>
              <Zap className="h-8 w-8 text-purple-500 mb-2" />
              <CardTitle>Zero-Shot Learning</CardTitle>
              <CardDescription>Perform tasks without specific training</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                LLMs can perform new tasks based on instructions alone, without task-specific training data.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="bg-gradient-to-r from-ai-100 to-neural-100 dark:from-ai-900 dark:to-neural-900 rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-4">How LLMs Work</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <h3 className="font-semibold mb-2">Training Phase</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
              <li>• Process massive text datasets (TBs of data)</li>
              <li>• Learn statistical patterns and relationships</li>
              <li>• Develop understanding of language structure</li>
              <li>• Build knowledge representations</li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Inference Phase</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
              <li>• Receive input text (prompt)</li>
              <li>• Process through neural network layers</li>
              <li>• Generate probability distributions</li>
              <li>• Output most likely next tokens</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}