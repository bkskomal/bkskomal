'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Eye } from 'lucide-react'

export function AttentionMechanism() {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Eye className="h-5 w-5" />
          Attention Mechanism
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-gray-600 dark:text-gray-300">
            The attention mechanism allows models to focus on relevant parts of the input when generating each output token.
          </p>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 bg-blue-100 dark:bg-blue-900 rounded-lg">
              <h4 className="font-semibold mb-2">Self-Attention</h4>
              <p className="text-sm">Focus on different parts of the same sequence</p>
            </div>
            <div className="p-4 bg-green-100 dark:bg-green-900 rounded-lg">
              <h4 className="font-semibold mb-2">Cross-Attention</h4>
              <p className="text-sm">Focus on different parts of another sequence</p>
            </div>
            <div className="p-4 bg-purple-100 dark:bg-purple-900 rounded-lg">
              <h4 className="font-semibold mb-2">Multi-Head</h4>
              <p className="text-sm">Multiple attention mechanisms in parallel</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}