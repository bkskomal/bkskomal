'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Brain } from 'lucide-react'

export function EmbeddingsDemo() {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          Word Embeddings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-gray-600 dark:text-gray-300">
            Embeddings convert words into high-dimensional vectors that capture semantic meaning.
          </p>
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
            <p className="text-sm font-mono">
              king - man + woman ≈ queen
            </p>
            <p className="text-xs text-gray-600 mt-2">
              Example of semantic relationships in embedding space
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}