'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const models = [
  { name: 'ChatGPT', company: 'OpenAI', params: '175B', context: '32K', strengths: 'General purpose' },
  { name: 'Claude', company: 'Anthropic', params: 'Unknown', context: '200K', strengths: 'Safety & reasoning' },
  { name: 'Gemini', company: 'Google', params: 'Unknown', context: '1M', strengths: 'Multimodal' },
  { name: 'Llama', company: 'Meta', params: '70B', context: '8K', strengths: 'Open source' },
  { name: 'Kimi', company: 'Moonshot', params: 'Unknown', context: '2M', strengths: 'Long context' },
]

export function ModelComparison() {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>Model Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {models.map((model) => (
            <div key={model.name} className="border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-semibold">{model.name}</h4>
                  <p className="text-sm text-gray-600">{model.company}</p>
                </div>
                <Badge>{model.context} context</Badge>
              </div>
              <div className="mt-2 flex space-x-4 text-sm">
                <span>Params: {model.params}</span>
                <span>Strengths: {model.strengths}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}