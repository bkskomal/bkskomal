import { motion } from 'framer-motion'
import { Eye, Zap, BookOpen, Play, Trophy, Share2 } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const features = [
  {
    icon: Eye,
    title: 'Visual Learning',
    description: 'Complex AI concepts explained through interactive diagrams and animations',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: Zap,
    title: 'Interactive Demos',
    description: 'Hands-on experiments with real AI models and parameters',
    color: 'from-purple-500 to-pink-500'
  },
  {
    icon: BookOpen,
    title: 'Progressive Learning',
    description: 'Structured curriculum from beginner to advanced concepts',
    color: 'from-green-500 to-emerald-500'
  },
  {
    icon: Play,
    title: 'Live Playground',
    description: 'Experiment with tokens, context windows, and model parameters',
    color: 'from-orange-500 to-red-500'
  },
  {
    icon: Trophy,
    title: 'Track Progress',
    description: 'Earn certificates and track your learning journey',
    color: 'from-yellow-500 to-amber-500'
  },
  {
    icon: Share2,
    title: 'Community',
    description: 'Learn with fellow AI enthusiasts and experts',
    color: 'from-indigo-500 to-purple-500'
  }
]

export function FeaturesSection() {
  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-900/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
            Why Learn with AI Concepts Hub?
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Experience AI education like never before with cutting-edge interactive learning
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full glassmorphism hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} flex items-center justify-center mb-4`}>
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle>{feature.title}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}