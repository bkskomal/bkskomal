'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function ContextWindowIntroduction() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Context Window</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Understanding how AI models handle memory limitations and process information
        </p>
      </div>

      <Card className="glassmorphism">
        <CardHeader>
          <CardTitle>What is Context Window?</CardTitle>
          <CardDescription>
            The context window is like the AI's short-term memory - it determines how much information the model can process at once.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Key Concepts:</h3>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• Input tokens: The text you provide to the model</li>
                <li>• Output tokens: The text the model generates</li>
                <li>• Total context: Combined input + output tokens</li>
                <li>• Memory limitations: Why models have size limits</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}