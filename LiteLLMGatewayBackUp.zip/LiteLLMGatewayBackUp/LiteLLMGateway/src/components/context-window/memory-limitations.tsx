'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertTriangle } from 'lucide-react'

export function MemoryLimitations() {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-orange-500" />
          Memory Limitations & Solutions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Common Issues:</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
              <li>• Context overflow - losing important information</li>
              <li>• Increased costs with larger context windows</li>
              <li>• Slower response times with more tokens</li>
              <li>• Difficulty maintaining conversation history</li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Solutions:</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
              <li>• Summarization - condense long conversations</li>
              <li>• RAG - retrieve relevant information on demand</li>
              <li>• Chunking - break large texts into smaller pieces</li>
              <li>• Sliding window - keep only recent context</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}