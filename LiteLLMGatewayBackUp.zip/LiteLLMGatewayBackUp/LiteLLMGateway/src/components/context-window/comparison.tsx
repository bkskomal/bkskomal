'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const data = [
  { model: 'GPT-3.5', tokens: 4096, examples: 'Short essays, code snippets' },
  { model: 'GPT-4', tokens: 8192, examples: 'Medium articles, conversations' },
  { model: 'Claude 3', tokens: 200000, examples: 'Long documents, books' },
  { model: 'Gemini Pro', tokens: 1000000, examples: 'Multiple documents, research' },
  { model: 'Kimi', tokens: 2000000, examples: 'Entire books, large datasets' },
]

export function ContextComparison() {
  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>Context Window Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="model" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="tokens" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 grid gap-2 text-sm">
          {data.map((item) => (
            <div key={item.model} className="flex justify-between">
              <span>{item.model}</span>
              <span className="text-gray-600">{item.examples}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}