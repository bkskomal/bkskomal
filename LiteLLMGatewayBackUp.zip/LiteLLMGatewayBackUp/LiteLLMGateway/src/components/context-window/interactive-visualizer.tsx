'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Text, Maximize2, Minimize2 } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { estimateTokens } from '@/lib/utils'

const CONTEXT_SIZES = [
  { size: 8192, label: '8K', color: 'bg-green-500' },
  { size: 32768, label: '32K', color: 'bg-blue-500' },
  { size: 131072, label: '128K', color: 'bg-purple-500' },
  { size: 262144, label: '256K', color: 'bg-orange-500' },
  { size: 1048576, label: '1M', color: 'bg-red-500' },
  { size: 10485760, label: '10M', color: 'bg-pink-500' },
]

export function InteractiveContextVisualizer() {
  const [text, setText] = useState('')
  const [contextSize, setContextSize] = useState([32768])
  const [selectedSize, setSelectedSize] = useState(32768)
  const [isFullScreen, setIsFullScreen] = useState(false)

  const tokenCount = estimateTokens(text)
  const percentageUsed = (tokenCount / selectedSize) * 100
  const isOverLimit = tokenCount > selectedSize

  const getFillColor = () => {
    if (isOverLimit) return 'bg-red-500'
    if (percentageUsed > 80) return 'bg-orange-500'
    if (percentageUsed > 50) return 'bg-yellow-500'
    return 'bg-green-500'
  }

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Text className="h-5 w-5" />
              Interactive Context Window Visualizer
            </CardTitle>
            <CardDescription>
              See how text fills up the context window like water in a container
            </CardDescription>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsFullScreen(!isFullScreen)}
          >
            {isFullScreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Input Section */}
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Enter your text:</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type or paste your text here to see how it fills the context window..."
                className="mt-2 min-h-[200px]"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  Characters: {text.length}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  Estimated Tokens: {tokenCount}
                </div>
              </div>
              <Badge variant={isOverLimit ? 'destructive' : 'default'}>
                {percentageUsed.toFixed(1)}% Used
              </Badge>
            </div>
          </div>

          {/* Visualization Section */}
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Context Window Size:</label>
              <div className="grid grid-cols-3 gap-2 mt-2">
                {CONTEXT_SIZES.map((size) => (
                  <Button
                    key={size.size}
                    variant={selectedSize === size.size ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedSize(size.size)}
                    className={cn(
                      selectedSize === size.size && size.color
                    )}
                  >
                    {size.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Visual Container */}
            <div className="relative">
              <div className="text-sm font-medium mb-2">Context Window Visualization</div>
              <div className="relative h-64 w-full rounded-lg border-2 border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-800 overflow-hidden">
                {/* Background */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-200 dark:to-gray-700"></div>
                
                {/* Fill */}
                <motion.div
                  className={cn('absolute bottom-0 left-0 right-0', getFillColor())}
                  initial={{ height: 0 }}
                  animate={{ height: `${Math.min(percentageUsed, 100)}%` }}
                  transition={{ duration: 0.5, ease: 'easeInOut' }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/20"></div>
                </motion.div>

                {/* Token indicators */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{tokenCount}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-300">tokens</div>
                  </div>
                </div>

                {/* Warning overlay */}
                <AnimatePresence>
                  {isOverLimit && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 bg-red-500/20 flex items-center justify-center">
                      <div className="bg-red-500 text-white px-3 py-1 rounded text-sm font-medium">
                        Context Limit Exceeded!
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Scale */}
              <div className="mt-2 flex justify-between text-xs text-gray-600 dark:text-gray-300">
                <span>0 tokens</span>
                <span>{formatNumber(selectedSize)} tokens</span>
              </div>
            </div>

            {/* Real-world Examples */}
            <div className="space-y-2">
              <div className="text-sm font-medium">Real-world Examples:</div>
              <div className="grid gap-2 text-xs">
                <div className="flex justify-between">
                  <span>Tweet (~280 chars)</span>
                  <span className="text-green-600">~70 tokens</span>
                </div>
                <div className="flex justify-between">
                  <span>Paragraph (~500 chars)</span>
                  <span className="text-green-600">~125 tokens</span>
                </div>
                <div className="flex justify-between">
                  <span>Page (~2500 chars)</span>
                  <span className="text-yellow-600">~625 tokens</span>
                </div>
                <div className="flex justify-between">
                  <span>Article (~5000 chars)</span>
                  <span className="text-orange-600">~1250 tokens</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}