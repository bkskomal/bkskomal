import { motion } from 'framer-motion'
import { Users, BookOpen, Award, Clock } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const stats = [
  {
    icon: Users,
    value: '10,000+',
    label: 'Active Learners',
    color: 'text-blue-500'
  },
  {
    icon: BookOpen,
    value: '50+',
    label: 'Interactive Lessons',
    color: 'text-green-500'
  },
  {
    icon: Award,
    value: '5,000+',
    label: 'Certificates Earned',
    color: 'text-purple-500'
  },
  {
    icon: Clock,
    value: '24/7',
    label: 'Available Anytime',
    color: 'text-orange-500'
  }
]

export function StatsSection() {
  return (
    <section className="py-20 bg-gradient-to-r from-ai-500 to-neural-500">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="glass glass-light text-center">
                <CardHeader>
                  <stat.icon className={cn('h-8 w-8 mx-auto', stat.color)} />
                </CardHeader>
                <CardContent>
                  <CardTitle className="text-3xl mb-2">{stat.value}</CardTitle>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{stat.label}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}