'use client'

import { motion } from 'framer-motion'
import { CheckCircle, Circle, Lock } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useRouter } from 'next/navigation'

const roadmap = [
  {
    level: 'Beginner',
    color: 'from-green-500 to-emerald-600',
    concepts: [
      { name: 'What is AI?', completed: true, locked: false },
      { name: 'LLM Basics', completed: true, locked: false },
      { name: 'Understanding Tokens', completed: false, locked: false },
      { name: 'Context Window Fundamentals', completed: false, locked: false },
    ],
  },
  {
    level: 'Intermediate',
    color: 'from-blue-500 to-cyan-600',
    concepts: [
      { name: 'Model Parameters Deep Dive', completed: false, locked: false },
      { name: 'RAG Architecture', completed: false, locked: false },
      { name: 'Vector Embeddings', completed: false, locked: true },
      { name: 'LangChain Basics', completed: false, locked: true },
    ],
  },
  {
    level: 'Advanced',
    color: 'from-purple-500 to-pink-600',
    concepts: [
      { name: 'MCP Protocol', completed: false, locked: true },
      { name: 'LangGraph Workflows', completed: false, locked: true },
      { name: 'Multi-Agent Systems', completed: false, locked: true },
      { name: 'Production Deployment', completed: false, locked: true },
    ],
  },
]

export function LearningRoadmap() {
  const router = useRouter()

  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-900/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
            Your Learning Journey
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Progress from beginner to advanced AI concepts with guided learning paths
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {roadmap.map((level, levelIndex) => (
            <motion.div
              key={level.level}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: levelIndex * 0.1 }}
            >
              <Card className="h-full glassmorphism hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{level.level}</CardTitle>
                    <div className="h-3 w-20 rounded-full bg-gradient-to-r ${level.color}"></div>
                  </div>
                  <CardDescription>
                    {level.level === 'Beginner' && 'Start your AI journey with fundamental concepts'}
                    {level.level === 'Intermediate' && 'Dive deeper into advanced architectures and patterns'}
                    {level.level === 'Advanced' && 'Master complex AI systems and production deployment'}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {level.concepts.map((concept, conceptIndex) => (
                      <div
                        key={concept.name}
                        className="flex items-center space-x-3 p-3 rounded-lg bg-white/50 dark:bg-gray-800/50">
                        {concept.completed ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : concept.locked ? (
                          <Lock className="h-5 w-5 text-gray-400" />
                        ) : (
                          <Circle className="h-5 w-5 text-gray-400" />
                        )}
                        <span className={cn(
                          'text-sm',
                          concept.completed && 'text-green-700 dark:text-green-300',
                          concept.locked && 'text-gray-500',
                          !concept.completed && !concept.locked && 'text-gray-700 dark:text-gray-300'
                        )}>
                          {concept.name}
                        </span>
                      </div>
                    ))}
                  </div>
                  <Button
                    className="w-full mt-4"
                    variant={level.level === 'Beginner' ? 'default' : 'outline'}
                    disabled={level.level !== 'Beginner'}
                    onClick={() => router.push('/llm-fundamentals')}
                  >
                    {level.level === 'Beginner' ? 'Start Learning' : 'Coming Soon'}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}