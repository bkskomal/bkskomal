'use client'

import { motion } from 'framer-motion'
import { Brain, Layers, Settings, Database, Link, Workflow } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useRouter } from 'next/navigation'

const concepts = [
  {
    icon: Brain,
    title: 'LLM Fundamentals',
    description: 'Learn the basics of Large Language Models',
    href: '/llm-fundamentals',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: Layers,
    title: 'Context Window',
    description: 'Understand memory limitations',
    href: '/context-window',
    color: 'from-green-500 to-emerald-500'
  },
  {
    icon: Settings,
    title: 'Tokens',
    description: 'Master tokenization and pricing',
    href: '/tokens',
    color: 'from-purple-500 to-pink-500'
  },
  {
    icon: Database,
    title: 'Parameters',
    description: 'Explore model sizes and capabilities',
    href: '/parameters',
    color: 'from-orange-500 to-red-500'
  },
  {
    icon: Link,
    title: 'RAG',
    description: 'Retrieval Augmented Generation',
    href: '/rag',
    color: 'from-indigo-500 to-purple-500'
  },
  {
    icon: Workflow,
    title: 'Playground',
    description: 'Interactive AI experiments',
    href: '/playground',
    color: 'from-yellow-500 to-amber-500'
  }
]

export function QuickNavigation() {
  const router = useRouter()

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
            Quick Start Guide
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Jump right into learning with these essential concepts
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {concepts.map((concept, index) => (
            <motion.div
              key={concept.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <Card className="h-full glassmorphism interactive-card">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${concept.color} flex items-center justify-center mb-4`}>
                    <concept.icon className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle>{concept.title}</CardTitle>
                  <CardDescription>{concept.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    className="w-full"
                    onClick={() => router.push(concept.href)}
                  >
                    Start Learning
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}