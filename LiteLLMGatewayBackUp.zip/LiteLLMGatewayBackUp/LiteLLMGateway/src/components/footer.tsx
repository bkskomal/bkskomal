'use client'

import { Github, Twitter, Linkedin, Mail } from 'lucide-react'
import Link from 'next/link'

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-4">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="h-8 w-8 bg-gradient-to-r from-ai-500 to-neural-500 rounded-lg"></div>
              <span className="text-xl font-bold">AI Concepts Hub</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Interactive platform for learning AI concepts visually. Master LLMs, RAG, MCP, and more.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Learn</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/llm-fundamentals" className="text-muted-foreground hover:text-foreground">LLM Fundamentals</Link></li>
              <li><Link href="/context-window" className="text-muted-foreground hover:text-foreground">Context Window</Link></li>
              <li><Link href="/tokens" className="text-muted-foreground hover:text-foreground">Tokens</Link></li>
              <li><Link href="/parameters" className="text-muted-foreground hover:text-foreground">Parameters</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Advanced</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/rag" className="text-muted-foreground hover:text-foreground">RAG</Link></li>
              <li><Link href="/mcp" className="text-muted-foreground hover:text-foreground">MCP</Link></li>
              <li><Link href="/langchain" className="text-muted-foreground hover:text-foreground">LangChain</Link></li>
              <li><Link href="/langgraph" className="text-muted-foreground hover:text-foreground">LangGraph</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Connect</h3>
            <div className="flex space-x-4">
              <a href="https://github.com" className="text-muted-foreground hover:text-foreground">
                <Github className="h-5 w-5" />
              </a>
              <a href="https://twitter.com" className="text-muted-foreground hover:text-foreground">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://linkedin.com" className="text-muted-foreground hover:text-foreground">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="mailto:hello@aiconceptshub.com" className="text-muted-foreground hover:text-foreground">
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            © 2024 AI Concepts Hub. All rights reserved.
          </p>
          <div className="flex space-x-4 mt-4 sm:mt-0">
            <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">Privacy</Link>
            <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}