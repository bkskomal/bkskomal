export default function MCPPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold gradient-text text-center">MCP (Model Context Protocol)</h1>
      </div>
    </div>
  )
}