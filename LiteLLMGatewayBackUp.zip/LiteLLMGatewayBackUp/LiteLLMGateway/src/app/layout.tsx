import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/theme-provider'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'AI Concepts Hub - Learn AI Visually',
  description: 'Interactive educational platform for learning AI, LLMs, RAG, MCP, LangChain, and LangGraph through visual demonstrations and hands-on examples.',
  keywords: 'AI, LLM, RAG, MCP, LangChain, LangGraph, machine learning, artificial intelligence, education, interactive learning',
  authors: [{ name: 'AI Concepts Hub' }],
  openGraph: {
    title: 'AI Concepts Hub - Learn AI Visually',
    description: 'Interactive educational platform for learning AI concepts visually',
    url: 'https://aiconceptshub.com',
    siteName: 'AI Concepts Hub',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'AI Concepts Hub',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AI Concepts Hub - Learn AI Visually',
    description: 'Interactive educational platform for learning AI concepts visually',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <div className="relative flex min-h-screen flex-col">
            <Navigation />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}