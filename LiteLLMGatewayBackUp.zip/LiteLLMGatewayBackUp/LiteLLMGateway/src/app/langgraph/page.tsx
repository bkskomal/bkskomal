export default function LangGraphPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-green-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold gradient-text text-center">LangGraph</h1>
      </div>
    </div>
  )
}