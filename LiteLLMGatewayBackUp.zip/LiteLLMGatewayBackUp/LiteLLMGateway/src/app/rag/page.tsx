import { RAGIntroduction } from '@/components/rag/introduction'

export default function RAGPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <RAGIntroduction />
        </div>
      </div>
    </div>
  )
}