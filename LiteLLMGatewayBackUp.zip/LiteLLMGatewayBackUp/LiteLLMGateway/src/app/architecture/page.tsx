export default function ArchitecturePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold gradient-text text-center">AI Architecture Center</h1>
      </div>
    </div>
  )
}