'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { TokenCalculator } from '@/components/playground/token-calculator'
import { ContextSimulator } from '@/components/playground/context-simulator'
import { ParameterComparison } from '@/components/playground/parameter-comparison'
import { RAGVisualizer } from '@/components/playground/rag-visualizer'
import { LangChainBuilder } from '@/components/playground/langchain-builder'
import { LangGraphBuilder } from '@/components/playground/langgraph-builder'

export default function PlaygroundPage() {
  const [activeTab, setActiveTab] = useState('tokens')

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold gradient-text mb-4">Interactive Playground</h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Experiment with AI concepts in real-time
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
              <TabsTrigger value="tokens">Tokens</TabsTrigger>
              <TabsTrigger value="context">Context</TabsTrigger>
              <TabsTrigger value="parameters">Parameters</TabsTrigger>
              <TabsTrigger value="rag">RAG</TabsTrigger>
              <TabsTrigger value="langchain">LangChain</TabsTrigger>
              <TabsTrigger value="langgraph">LangGraph</TabsTrigger>
            </TabsList>

            <div className="mt-8">
              <TabsContent value="tokens">
                <TokenCalculator />
              </TabsContent>
              <TabsContent value="context">
                <ContextSimulator />
              </TabsContent>
              <TabsContent value="parameters">
                <ParameterComparison />
              </TabsContent>
              <TabsContent value="rag">
                <RAGVisualizer />
              </TabsContent>
              <TabsContent value="langchain">
                <LangChainBuilder />
              </TabsContent>
              <TabsContent value="langgraph">
                <LangGraphBuilder />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  )
}