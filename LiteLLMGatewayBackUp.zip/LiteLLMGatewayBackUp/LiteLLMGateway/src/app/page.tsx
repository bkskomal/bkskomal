import { HeroSection } from '@/components/hero-section'
import { LearningRoadmap } from '@/components/learning-roadmap'
import { QuickNavigation } from '@/components/quick-navigation'
import { FeaturesSection } from '@/components/features-section'
import { StatsSection } from '@/components/stats-section'

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <FeaturesSection />
      <LearningRoadmap />
      <QuickNavigation />
      <StatsSection />
    </div>
  )
}