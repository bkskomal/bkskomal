import { LLMIntroduction } from '@/components/llm/llm-introduction'
import { TransformerVisualization } from '@/components/llm/transformer-visualization'
import { TrainingVsInference } from '@/components/llm/training-vs-inference'
import { ModelComparison } from '@/components/llm/model-comparison'
import { AttentionMechanism } from '@/components/llm/attention-mechanism'
import { EmbeddingsDemo } from '@/components/llm/embeddings-demo'

export default function LLMFundamentalsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-12">
          <LLMIntroduction />
          <TransformerVisualization />
          <AttentionMechanism />
          <TrainingVsInference />
          <EmbeddingsDemo />
          <ModelComparison />
        </div>
      </div>
    </div>
  )
}