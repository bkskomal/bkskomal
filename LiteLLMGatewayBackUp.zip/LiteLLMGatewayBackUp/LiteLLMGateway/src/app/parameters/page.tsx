import { ParameterIntroduction } from '@/components/parameters/introduction'
import { ParameterComparison } from '@/components/parameters/comparison'

export default function ParametersPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-12">
          <ParameterIntroduction />
          <ParameterComparison />
        </div>
      </div>
    </div>
  )
}