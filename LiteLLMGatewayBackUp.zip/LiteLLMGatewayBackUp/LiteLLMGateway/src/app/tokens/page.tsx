import { TokenIntroduction } from '@/components/tokens/introduction'
import { InteractiveTokenizer } from '@/components/tokens/interactive-tokenizer'
import { TokenComparison } from '@/components/tokens/comparison'
import { TokenPricing } from '@/components/tokens/pricing'

export default function TokensPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-12">
          <TokenIntroduction />
          <InteractiveTokenizer />
          <TokenComparison />
          <TokenPricing />
        </div>
      </div>
    </div>
  )
}