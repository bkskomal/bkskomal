import { ContextWindowIntroduction } from '@/components/context-window/introduction'
import { InteractiveContextVisualizer } from '@/components/context-window/interactive-visualizer'
import { ContextComparison } from '@/components/context-window/comparison'
import { MemoryLimitations } from '@/components/context-window/memory-limitations'

export default function ContextWindowPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-12">
          <ContextWindowIntroduction />
          <InteractiveContextVisualizer />
          <ContextComparison />
          <MemoryLimitations />
        </div>
      </div>
    </div>
  )
}