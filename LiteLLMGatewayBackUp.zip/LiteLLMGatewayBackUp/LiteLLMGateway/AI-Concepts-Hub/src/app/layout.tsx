import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/theme-provider'
import { Navigation } from '@/components/navigation'
import { Toaster } from '@/components/ui/toaster'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'AI Concepts Hub - Learn AI Visually',
  description: 'Interactive AI learning platform with visual explanations of LLMs, RAG, MCP, LangChain, and more',
  keywords: 'AI, LLM, RAG, MCP, LangChain, LangGraph, machine learning, artificial intelligence, tokens, context window',
  authors: [{ name: 'AI Concepts Hub' }],
  openGraph: {
    title: 'AI Concepts Hub - Learn AI Visually',
    description: 'Master AI concepts through interactive visualizations and hands-on examples',
    type: 'website',
    url: 'https://aiconceptshub.com',
    images: ['/og-image.png'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AI Concepts Hub - Learn AI Visually',
    description: 'Master AI concepts through interactive visualizations and hands-on examples',
    images: ['/og-image.png'],
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
            <Navigation />
            <main className="relative">
              {children}
            </main>
            <Toaster />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}