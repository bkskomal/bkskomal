export function TokenIntroduction() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Understanding Tokens</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Learn how AI models break text into tokens and why it matters for pricing and performance
        </p>
      </div>
      <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900 rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-4">What are Tokens?</h2>
        <p className="text-gray-600 dark:text-gray-300">
          Tokens are the basic units of text that AI models process. They can be words, parts of words, or even characters.
        </p>
      </div>
    </div>
  )
}