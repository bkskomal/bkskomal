export function ContextWindowIntroduction() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Context Window</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Understanding how AI models handle memory limitations and process information
        </p>
      </div>
      <div className="bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-4">What is Context Window?</h2>
        <p className="text-gray-600 dark:text-gray-300">
          The context window is like the AI's short-term memory - it determines how much information the model can process at once.
        </p>
      </div>
    </div>
  )
}