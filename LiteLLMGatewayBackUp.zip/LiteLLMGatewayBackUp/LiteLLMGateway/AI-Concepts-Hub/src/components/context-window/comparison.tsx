import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export function ContextComparison() {
  const models = [
    { model: 'GPT-3.5', tokens: 4096, examples: 'Short essays, code snippets' },
    { model: 'GPT-4', tokens: 8192, examples: 'Medium articles, conversations' },
    { model: 'Claude 3', tokens: 200000, examples: 'Long documents, books' },
    { model: 'Gemini Pro', tokens: 1000000, examples: 'Multiple documents, research' },
  ]

  return (
    <Card className="glassmorphism">
      <CardHeader>
        <CardTitle>Context Window Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {models.map((item) => (
            <div key={item.model} className="border rounded-lg p-4">
              <div className="flex justify-between items-center">
                <span className="font-semibold">{item.model}</span>
                <span className="text-sm text-gray-600">{item.tokens.toLocaleString()} tokens</span>
              </div>
              <p className="text-sm text-gray-600 mt-1">{item.examples}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}