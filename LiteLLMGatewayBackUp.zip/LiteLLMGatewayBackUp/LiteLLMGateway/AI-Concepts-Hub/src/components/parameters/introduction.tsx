export function ParameterIntroduction() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">Model Parameters</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Understanding how model size affects performance, cost, and capabilities
        </p>
      </div>
      <div className="bg-gradient-to-r from-orange-100 to-red-100 dark:from-orange-900 dark:to-red-900 rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-4">What are Parameters?</h2>
        <p className="text-gray-600 dark:text-gray-300">
          Parameters are the learned weights and biases in neural networks that determine how the model processes information.
        </p>
      </div>
    </div>
  )
}