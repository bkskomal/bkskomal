import Link from 'next/link'

export function Navigation() {
  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <Link href="/" className="text-xl font-bold">
            AI Concepts Hub
          </Link>
          <div className="flex space-x-6">
            <Link href="/" className="text-gray-700 hover:text-blue-600">Home</Link>
            <Link href="/llm-fundamentals" className="text-gray-700 hover:text-blue-600">LLM</Link>
            <Link href="/context-window" className="text-gray-700 hover:text-blue-600">Context</Link>
            <Link href="/tokens" className="text-gray-700 hover:text-blue-600">Tokens</Link>
            <Link href="/parameters" className="text-gray-700 hover:text-blue-600">Parameters</Link>
            <Link href="/playground" className="text-gray-700 hover:text-blue-600">Playground</Link>
          </div>
        </div>
      </div>
    </nav>
  )
}