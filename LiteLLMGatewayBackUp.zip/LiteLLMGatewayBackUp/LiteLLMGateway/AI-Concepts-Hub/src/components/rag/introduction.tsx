export function RAGIntroduction() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text">RAG (Retrieval Augmented Generation)</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Combining retrieval systems with language models to reduce hallucinations and provide accurate information
        </p>
      </div>
      <div className="bg-gradient-to-r from-green-100 to-emerald-100 dark:from-green-900 dark:to-emerald-900 rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-4">How RAG Works</h2>
        <ol className="space-y-2 text-gray-600 dark:text-gray-300">
          <li>1. User asks a question</li>
          <li>2. Query is converted to embedding</li>
          <li>3. Vector database search for relevant documents</li>
          <li>4. Retrieved context is added to prompt</li>
          <li>5. LLM generates accurate response</li>
        </ol>
      </div>
    </div>
  )
}