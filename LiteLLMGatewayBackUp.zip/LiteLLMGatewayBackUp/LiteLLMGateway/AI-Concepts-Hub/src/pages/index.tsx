export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-gray-900 mb-6">AI Concepts Hub</h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Interactive platform for learning AI concepts visually
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold mb-2">LLM Fundamentals</h3>
              <p className="text-gray-600">Learn the basics of Large Language Models</p>
            </div>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold mb-2">Context Window</h3>
              <p className="text-gray-600">Understand memory limitations</p>
            </div>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold mb-2">Interactive Playground</h3>
              <p className="text-gray-600">Experiment with AI concepts</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}