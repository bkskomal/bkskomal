export default function TokensPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">Understanding Tokens</h1>
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold mb-4">What are Tokens?</h2>
            <p className="text-gray-600 mb-4">
              Tokens are the basic units of text that AI models process. They can be words, parts of words, or even characters.
            </p>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">English</h3>
                <p className="text-sm">~1 token per word</p>
              </div>
              <div className="bg-pink-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Code</h3>
                <p className="text-sm">~2-3 tokens per word</p>
              </div>
              <div className="bg-indigo-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Asian Languages</h3>
                <p className="text-sm">~1.5-2 tokens per character</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}