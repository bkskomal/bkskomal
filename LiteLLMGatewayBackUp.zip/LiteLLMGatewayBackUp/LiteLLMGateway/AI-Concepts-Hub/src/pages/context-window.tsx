export default function ContextWindowPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">Context Window</h1>
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold mb-4">Understanding Context Windows</h2>
            <p className="text-gray-600 mb-4">
              The context window is like the AI's short-term memory - it determines how much information the model can process at once.
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Common Models</h3>
                <ul className="text-sm space-y-1">
                  <li>GPT-3.5: 4K tokens</li>
                  <li>GPT-4: 8K-32K tokens</li>
                  <li>Claude 3: 200K tokens</li>
                  <li>Gemini: 1M tokens</li>
                </ul>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Key Concepts</h3>
                <ul className="text-sm space-y-1">
                  <li>Input tokens count</li>
                  <li>Output tokens count</li>
                  <li>Memory limitations</li>
                  <li>Cost implications</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}