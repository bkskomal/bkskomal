export default function LLMFundamentalsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">LLM Fundamentals</h1>
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-semibold mb-4">What are Large Language Models?</h2>
              <p className="text-gray-600 mb-4">
                Large Language Models (LLMs) are AI systems trained on vast amounts of text data to understand and generate human-like language.
              </p>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Neural Networks</h3>
                  <p className="text-sm">Built on transformer architecture</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Language Understanding</h3>
                  <p className="text-sm">Comprehend context and semantics</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Zero-Shot Learning</h3>
                  <p className="text-sm">Perform new tasks without training</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}