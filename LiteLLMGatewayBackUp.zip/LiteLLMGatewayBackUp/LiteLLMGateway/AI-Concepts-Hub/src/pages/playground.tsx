import { useState } from 'react'
import Head from 'next/head'

export default function PlaygroundPage() {
  const [text, setText] = useState('')
  const [tokens, setTokens] = useState(0)

  const estimateTokens = (text: string) => {
    return Math.ceil(text.length / 4)
  }

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value
    setText(newText)
    setTokens(estimateTokens(newText))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Head>
        <title>Interactive Playground - AI Concepts Hub</title>
      </Head>

      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">Interactive Playground</h1>
          
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold mb-4">Token Calculator</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Enter your text:</label>
                <textarea
                  value={text}
                  onChange={handleTextChange}
                  className="w-full p-3 border rounded-lg h-32"
                  placeholder="Type your text here..."
                />
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-lg font-semibold">Estimated Tokens: {tokens}</p>
                <p className="text-sm text-gray-600">Characters: {text.length}</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}