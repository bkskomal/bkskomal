export default function ParametersPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">Model Parameters</h1>
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold mb-4">Understanding Model Sizes</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">7B Parameters</h3>
                <p className="text-sm text-gray-600">Mobile/Edge devices</p>
              </div>
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">70B Parameters</h3>
                <p className="text-sm text-gray-600">Professional workstations</p>
              </div>
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">175B Parameters</h3>
                <p className="text-sm text-gray-600">Enterprise servers</p>
              </div>
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">405B Parameters</h3>
                <p className="text-sm text-gray-600">Large-scale deployments</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}