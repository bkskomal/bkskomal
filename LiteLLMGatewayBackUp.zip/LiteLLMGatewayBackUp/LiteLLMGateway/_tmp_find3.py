import os
for root, _, files in os.walk('admin-ui/src/app'):
    for f in files:
        if not f.endswith('.tsx'):
            continue
        path = os.path.join(root, f)
        with open(path, encoding='utf-8') as fh:
            content = fh.read()
            if 'search' in content.lower() or 'Search' in content:
                print(path)
