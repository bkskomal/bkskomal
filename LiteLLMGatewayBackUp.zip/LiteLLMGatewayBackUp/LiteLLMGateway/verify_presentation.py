from pptx import Presentation

p = Presentation('OATI_Code_Update_Deck.pptx')
print(f'Total slides: {len(p.slides)}')
for i, slide in enumerate(p.slides, 1):
    print(f'Slide {i}: {len(slide.shapes)} shapes')