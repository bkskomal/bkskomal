"""Generate OATI Code Update Deck - 5 slides with features X, Y, Z, competitor comparison, and CTA"""
from pathlib import Path
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

# --- PALETTE (OATI Brand) ---
HEADER_NAVY = RGBColor(0x1A, 0x2B, 0x4A)
ACCENT_RED  = RGBColor(0xCC, 0x00, 0x00)
WHITE       = RGBColor(0xFF, 0xFF, 0xFF)
INK         = RGBColor(0x1F, 0x2A, 0x3D)
SUBTLE_INK  = RGBColor(0x4A, 0x5A, 0x70)
LIGHT_GRAY  = RGBColor(0xE7, 0xE6, 0xE6)
MUTED_DARK  = RGBColor(0x8C, 0x9B, 0xAB)
BG_LIGHT    = RGBColor(0xF8, 0xF9, 0xFA)
BG_MAIN_DARK= RGBColor(0x1A, 0x2B, 0x4A)
BG_PANEL_DARK=RGBColor(0x16, 0x20, 0x38)
SOFT_BORDER = RGBColor(0xE0, 0xE4, 0xEA)
CARD_BG     = RGBColor(0xFF, 0xFF, 0xFF)
CARD_BG_ALT = RGBColor(0xF1, 0xF3, 0xF6)
CHIP_BLUE   = RGBColor(0x25, 0x63, 0xEB)
CHIP_PURPLE = RGBColor(0x7C, 0x3A, 0xED)
CHIP_ORANGE = RGBColor(0xD9, 0x77, 0x06)
CHIP_TEAL   = RGBColor(0x0D, 0x94, 0x88)
CHIP_GREEN  = RGBColor(0x2E, 0xA0, 0x43)
CHIP_INDIGO = RGBColor(0x31, 0x2E, 0x81)
SOFT_BLUE   = RGBColor(0x5B, 0x9B, 0xD5)

# --- CANVAS (10 × 5.625 in, 16:9) ---
SLIDE_W, SLIDE_H = Inches(10), Inches(5.625)
HEADER_H = Inches(0.75)
FOOTER_H = Inches(0.21)
FOOTER_Y = SLIDE_H - FOOTER_H
BODY_TOP = HEADER_H + Inches(0.15)
BODY_LEFT = Inches(0.5)
BODY_W   = SLIDE_W - Inches(1.0)

# --- BRANDING ---
BRAND_NAME  = "OATI Code"
FOOTER_TEXT = "PROPRIETARY AND CONFIDENTIAL  |  OATI  |  2024"

# --- HELPERS ---
def _kill_outline(s): s.line.fill.background()
def _solid(s, c): s.fill.solid(); s.fill.fore_color.rgb = c; _kill_outline(s)
def _outline(s, c, w=0.75): s.line.color.rgb = c; s.line.width = Pt(w)

def _rect(slide, x, y, w, h, color, *, outline=None):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    _solid(s, color)
    if outline is not None: _outline(s, outline)
    return s

def _text(slide, x, y, w, h, text, *, size=12, bold=False, italic=False,
          color=INK, font="Calibri Light", align=PP_ALIGN.LEFT,
          anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]; p.alignment = align
    r = p.add_run(); r.text = text
    r.font.name = font; r.font.size = Pt(size); r.font.bold = bold
    r.font.italic = italic; r.font.color.rgb = color
    return tb

def _sparkle(slide, x, y, size=Inches(0.34), color=WHITE):
    s = slide.shapes.add_shape(MSO_SHAPE.STAR_4_POINT, x, y, size, size)
    _solid(s, color); return s

def _header(slide, title, eyebrow=None):
    _rect(slide, Emu(0), Emu(0), SLIDE_W, HEADER_H, HEADER_NAVY)
    _sparkle(slide, Inches(0.30), Inches(0.21))
    _text(slide, Inches(0.72), Inches(0.20), Inches(1.6), Inches(0.36),
          BRAND_NAME, size=11, bold=True, color=LIGHT_GRAY,
          anchor=MSO_ANCHOR.MIDDLE)
    _text(slide, Inches(2.45), Inches(0.06), Inches(7.2), Inches(0.64),
          title, size=19, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    if eyebrow:
        _text(slide, Inches(2.45), Inches(0.45), Inches(7.2), Inches(0.25),
              eyebrow, size=9.5, italic=True, color=MUTED_DARK)

def _footer(slide):
    _rect(slide, Emu(0), FOOTER_Y, SLIDE_W, FOOTER_H, HEADER_NAVY)
    _text(slide, Inches(0.2), FOOTER_Y, Inches(9.6), FOOTER_H,
          FOOTER_TEXT, size=7, color=LIGHT_GRAY, font="Calibri",
          anchor=MSO_ANCHOR.MIDDLE)

def _canvas_light(slide):
    _rect(slide, Emu(0), Emu(0), SLIDE_W, SLIDE_H, BG_LIGHT)

def _chip(slide, x, y, w, h, label, color, size=9):
    _rect(slide, x, y, w, h, color)
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = label
    r.font.name = "Calibri Light"; r.font.size = Pt(size)
    r.font.bold = True; r.font.color.rgb = WHITE

def _light_card(slide, x, y, w, h, accent):
    _rect(slide, x, y, w, Inches(0.10), accent)
    _rect(slide, x, y + Inches(0.10), w, h - Inches(0.10),
          CARD_BG, outline=SOFT_BORDER)

def build_title_slide(prs):
    """Slide 1: Title slide with overview"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(s, Emu(0), Emu(0), SLIDE_W, SLIDE_H, BG_MAIN_DARK)
    _rect(s, Inches(6.9), Emu(0), SLIDE_W - Inches(6.9), SLIDE_H, BG_PANEL_DARK)
    _rect(s, Inches(6.9), Emu(0), Emu(54864), SLIDE_H, ACCENT_RED)
    
    _sparkle(s, Inches(0.45), Inches(0.32))
    _text(s, Inches(0.85), Inches(0.30), Inches(3.0), Inches(0.4),
          BRAND_NAME, size=15, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    _text(s, Inches(0.5), Inches(1.75), Inches(6.2), Inches(0.7),
          "OATI Code Update", size=40, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    _text(s, Inches(0.5), Inches(2.45), Inches(6.2), Inches(0.55),
          "Features X, Y, Z & Competitive Edge", size=22, color=SOFT_BLUE, anchor=MSO_ANCHOR.MIDDLE)
    
    # Chips
    cy = Inches(3.7); cw = Inches(1.45); ch = Inches(0.36); gap = Inches(0.16)
    x = Inches(0.5)
    for label, color in [("Feature X", CHIP_BLUE), ("Feature Y", CHIP_PURPLE), ("Feature Z", CHIP_GREEN)]:
        _chip(s, x, cy, cw, ch, label, color); x += cw + gap
    
    # At a glance
    _text(s, Inches(7.1), Inches(0.55), Inches(2.7), Inches(0.36),
          "At a glance", size=13, bold=True, color=LIGHT_GRAY)
    glance = ["3 Major Features", "Competitive Analysis", "Q4 2024 Release", "Enterprise Ready"]
    for i, line in enumerate(glance):
        y = Inches(1.05) + Inches(0.52) * i
        _rect(s, Inches(7.1), y, Emu(36576), Inches(0.32), ACCENT_RED)
        _text(s, Inches(7.2), y, Inches(2.55), Inches(0.32),
              line, size=10.5, color=LIGHT_GRAY, anchor=MSO_ANCHOR.MIDDLE)

def build_feature_x_slide(prs):
    """Slide 2: Feature X - Advanced Code Intelligence"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _canvas_light(s); _header(s, "Feature X", "Advanced Code Intelligence")
    
    # Feature description
    _text(s, BODY_LEFT, BODY_TOP + Inches(0.1), BODY_W, Inches(0.4),
          "Next-generation AI-powered code analysis and optimization", size=16, bold=True, color=INK)
    
    # Key capabilities
    capabilities = [
        ("Real-time Analysis", "Instant code quality feedback as you type"),
        ("Performance Optimization", "Automatic bottleneck detection and suggestions"),
        ("Security Scanning", "Proactive vulnerability identification"),
        ("Refactoring Assistant", "AI-driven code restructuring recommendations")
    ]
    
    # Card grid
    col_w = (BODY_W - Inches(0.20)) / 2
    row_h = Inches(1.1); cg = Inches(0.20); rg = Inches(0.15)
    gy = BODY_TOP + Inches(0.6)
    
    for i, (head, desc) in enumerate(capabilities):
        col = i % 2; row = i // 2
        x = BODY_LEFT + (col_w + cg) * col
        y = gy + (row_h + rg) * row
        _light_card(s, x, y, col_w, row_h, CHIP_BLUE)
        _text(s, x + Inches(0.15), y + Inches(0.20), col_w - Inches(0.25),
              Inches(0.32), head, size=13, bold=True, color=INK)
        _text(s, x + Inches(0.15), y + Inches(0.55), col_w - Inches(0.25),
              Inches(0.45), desc, size=10, color=SUBTLE_INK)
    
    _footer(s)

def build_feature_y_slide(prs):
    """Slide 3: Feature Y - Collaborative Development"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _canvas_light(s); _header(s, "Feature Y", "Collaborative Development")
    
    _text(s, BODY_LEFT, BODY_TOP + Inches(0.1), BODY_W, Inches(0.4),
          "Seamless team collaboration with integrated workflows", size=16, bold=True, color=INK)
    
    # Collaboration features
    features = [
        ("Live Pair Programming", "Real-time shared coding sessions"),
        ("Smart Code Reviews", "AI-assisted pull request analysis"),
        ("Team Knowledge Base", "Shared documentation and best practices"),
        ("Integration Hub", "Connect with Jira, Slack, GitHub, and more")
    ]
    
    # Card grid
    col_w = (BODY_W - Inches(0.20)) / 2
    row_h = Inches(1.1); cg = Inches(0.20); rg = Inches(0.15)
    gy = BODY_TOP + Inches(0.6)
    
    for i, (head, desc) in enumerate(features):
        col = i % 2; row = i // 2
        x = BODY_LEFT + (col_w + cg) * col
        y = gy + (row_h + rg) * row
        _light_card(s, x, y, col_w, row_h, CHIP_PURPLE)
        _text(s, x + Inches(0.15), y + Inches(0.20), col_w - Inches(0.25),
              Inches(0.32), head, size=13, bold=True, color=INK)
        _text(s, x + Inches(0.15), y + Inches(0.55), col_w - Inches(0.25),
              Inches(0.45), desc, size=10, color=SUBTLE_INK)
    
    _footer(s)

def build_feature_z_slide(prs):
    """Slide 4: Feature Z - Enterprise Security"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _canvas_light(s); _header(s, "Feature Z", "Enterprise Security")
    
    _text(s, BODY_LEFT, BODY_TOP + Inches(0.1), BODY_W, Inches(0.4),
          "Comprehensive security and compliance for enterprise environments", size=16, bold=True, color=INK)
    
    # Security features
    security_features = [
        ("Zero-Trust Architecture", "End-to-end encryption and access controls"),
        ("Compliance", "SOC 2 Type II, ISO 27001, and GDPR compliance"),
        ("Advanced Threat Detection", "ML-powered anomaly detection"),
        ("Audit & Compliance", "Comprehensive logging and reporting")
    ]
    
    # Card grid
    col_w = (BODY_W - Inches(0.20)) / 2
    row_h = Inches(1.1); cg = Inches(0.20); rg = Inches(0.15)
    gy = BODY_TOP + Inches(0.6)
    
    for i, (head, desc) in enumerate(security_features):
        col = i % 2; row = i // 2
        x = BODY_LEFT + (col_w + cg) * col
        y = gy + (row_h + rg) * row
        _light_card(s, x, y, col_w, row_h, CHIP_GREEN)
        _text(s, x + Inches(0.15), y + Inches(0.20), col_w - Inches(0.25),
              Inches(0.32), head, size=13, bold=True, color=INK)
        _text(s, x + Inches(0.15), y + Inches(0.55), col_w - Inches(0.25),
              Inches(0.45), desc, size=10, color=SUBTLE_INK)
    
    _footer(s)

def build_comparison_slide(prs):
    """Slide 5: Competitive Comparison"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _canvas_light(s); _header(s, "Competitive Comparison", "How OATI Code stacks up")
    
    # Comparison table
    columns = ["Feature", "OATI Code", "GitHub Copilot", "Tabnine", "Amazon CodeWhisperer"]
    rows = [
        ["AI Code Intelligence", "✅ Advanced", "✅ Basic", "✅ Basic", "✅ Basic"],
        ["Real-time Collaboration", "✅ Built-in", "❌ Limited", "❌ Limited", "❌ Limited"],
        ["Enterprise Security", "✅ Zero-Trust", "⚠️ Basic", "⚠️ Basic", "✅ Good"],
        ["Custom Model Training", "✅ Available", "❌ Not Available", "❌ Not Available", "❌ Not Available"],
        ["On-premise Deployment", "✅ Full Support", "❌ Cloud Only", "❌ Cloud Only", "⚠️ Limited"],
        ["Pricing Model", "Enterprise", "Per-seat", "Per-seat", "Per-seat"]
    ]
    
    n = len(columns); col_w = BODY_W / n
    tx = BODY_LEFT; ty = BODY_TOP + Inches(0.1)
    hh = Inches(0.36); rh = Inches(0.30); total_w = col_w * n
    
    # Header row
    _rect(s, tx, ty, total_w, hh, HEADER_NAVY)
    cx = tx
    for label in columns:
        _text(s, cx + Inches(0.06), ty, col_w - Inches(0.10), hh,
              label, size=10, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
        cx += col_w
    
    # Data rows
    ry = ty + hh
    for i, row in enumerate(rows):
        bg = CARD_BG_ALT if i % 2 == 0 else CARD_BG
        _rect(s, tx, ry, total_w, rh, bg)
        cx = tx
        for j, cell in enumerate(row):
            color = CHIP_GREEN if j == 1 and "✅" in str(cell) else \
                   ACCENT_RED if j > 1 and "❌" in str(cell) else \
                   CHIP_ORANGE if j > 1 and "⚠️" in str(cell) else INK
            bold = (j == 1)  # Highlight OATI Code column
            _text(s, cx + Inches(0.06), ry, col_w - Inches(0.10), rh,
                  str(cell), size=9, bold=bold, color=color, anchor=MSO_ANCHOR.MIDDLE)
            cx += col_w
        ry += rh
    
    _footer(s)

def build_cta_slide(prs):
    """Slide 6: Call to Action"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(s, Emu(0), Emu(0), SLIDE_W, SLIDE_H, BG_MAIN_DARK)
    
    # Main CTA
    _text(s, Inches(0.5), Inches(1.5), Inches(9.0), Inches(1.0),
          "Ready to Transform Your Development Workflow?", size=32, bold=True, color=WHITE, 
          align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    
    _text(s, Inches(0.5), Inches(2.5), Inches(9.0), Inches(0.8),
          "Experience the power of AI-driven development with enterprise-grade security", 
          size=18, color=SOFT_BLUE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    
    # Action items
    actions = [
        "📧 Schedule a demo at oati.com/demo",
        "🚀 Start your free trial today",
        "📞 Contact our enterprise sales team"
    ]
    
    for i, action in enumerate(actions):
        y = Inches(3.5) + Inches(0.4) * i
        _text(s, Inches(0.5), y, Inches(9.0), Inches(0.35),
              action, size=14, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    
    # Contact info
    _text(s, Inches(0.5), Inches(4.8), Inches(9.0), Inches(0.3),
          "sales@oati.com | +1-800-OATI-CODE | oati.com", 
          size=12, color=LIGHT_GRAY, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

def main():
    prs = Presentation()
    prs.slide_width, prs.slide_height = SLIDE_W, SLIDE_H
    
    # Build all slides
    build_title_slide(prs)
    build_feature_x_slide(prs)
    build_feature_y_slide(prs)
    build_feature_z_slide(prs)
    build_comparison_slide(prs)
    build_cta_slide(prs)
    
    # Save the presentation
    out = Path("OATI_Code_Update_Deck.pptx")
    prs.save(out)
    print(f"Generated {out} ({out.stat().st_size:,} bytes, {len(prs.slides)} slides)")

if __name__ == "__main__":
    main()