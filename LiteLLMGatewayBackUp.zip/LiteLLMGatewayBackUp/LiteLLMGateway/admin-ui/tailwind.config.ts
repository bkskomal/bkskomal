import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // OATI brand palette
        oati: {
          navy:       "#1B2A4E",
          "navy-dark":"#141F3B",
          red:        "#C82A32",
          primary:    "#2E86AB",
          accent:     "#824DE0",
          success:    "#2E7D32",
          warning:    "#E6862A",
          muted:      "#6B7280",
        },
        // shadcn semantic tokens — map to CSS variables for dark-mode
        background:        "hsl(var(--background))",
        foreground:        "hsl(var(--foreground))",
        card:              "hsl(var(--card))",
        "card-foreground": "hsl(var(--card-foreground))",
        primary:           "hsl(var(--primary))",
        "primary-foreground": "hsl(var(--primary-foreground))",
        secondary:         "hsl(var(--secondary))",
        "secondary-foreground": "hsl(var(--secondary-foreground))",
        muted:             "hsl(var(--muted))",
        "muted-foreground":"hsl(var(--muted-foreground))",
        accent:            "hsl(var(--accent))",
        "accent-foreground": "hsl(var(--accent-foreground))",
        border:            "hsl(var(--border))",
        input:             "hsl(var(--input))",
        ring:              "hsl(var(--ring))",
        destructive:       "hsl(var(--destructive))",
        "destructive-foreground": "hsl(var(--destructive-foreground))",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        sans: ["var(--font-sans)", "Inter", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "JetBrains Mono", "ui-monospace", "Consolas", "monospace"],
      },
      letterSpacing: {
        tightest: "-0.04em",
        tighter:  "-0.02em",
      },
      boxShadow: {
        // Single, consistent card shadow — soft drop, no inset border. Works
        // on both light (Gentelella) and dark themes because alpha-blending
        // is darker than the lightest content surface either way.
        soft:    "0 1px 2px 0 rgb(0 0 0 / 0.04), 0 1px 3px 0 rgb(0 0 0 / 0.06)",
        ring:    "0 0 0 1px hsl(var(--border))",
      },
    },
  },
  plugins: [],
};

export default config;
