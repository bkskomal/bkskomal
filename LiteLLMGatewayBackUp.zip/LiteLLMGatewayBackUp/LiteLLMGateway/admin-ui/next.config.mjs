/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // The old /gateway-api/* rewrite that proxied to the gateway in the browser
  // is gone — calls now go through the BFF route /api/gateway/[...path],
  // which authenticates the operator via cookie and injects the gateway
  // master key server-side. See docs/architecture-admin-ui.md.
};

export default nextConfig;
