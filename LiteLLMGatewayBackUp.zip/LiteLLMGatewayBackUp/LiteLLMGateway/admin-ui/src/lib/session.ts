/**
 * Minimal HMAC-signed session cookie helpers.
 *
 * No third-party auth library, no JWT spec gymnastics — a session is a
 * compact `<payload>.<signature>` string where:
 *   payload   = base64url(JSON.stringify({ user, exp, iat }))
 *   signature = base64url(HMAC-SHA256(SESSION_SECRET, payload))
 *
 * The cookie is httpOnly + SameSite=Lax + secure-in-prod, so client-side
 * JavaScript cannot read or forge it. The master key for the gateway lives
 * server-side only and never enters this string.
 */

import { createHmac, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

export const COOKIE_NAME = "gw_admin_session";
export const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24;   // 24 hours

export interface Session {
  user: string;
  iat: number;   // issued-at epoch seconds
  exp: number;   // expiry epoch seconds
}

function getSecret(): Buffer {
  const s = process.env.SESSION_SECRET;
  if (!s) throw new Error("SESSION_SECRET is not set");
  return Buffer.from(s, "utf8");
}

function b64url(buf: Buffer): string {
  return buf.toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function b64urlDecode(s: string): Buffer {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return Buffer.from(s, "base64");
}

function sign(payloadB64: string): string {
  return b64url(createHmac("sha256", getSecret()).update(payloadB64).digest());
}

export function createSessionToken(user: string): { token: string; session: Session } {
  const now = Math.floor(Date.now() / 1000);
  const session: Session = { user, iat: now, exp: now + COOKIE_MAX_AGE_SECONDS };
  const payload = b64url(Buffer.from(JSON.stringify(session)));
  return { token: `${payload}.${sign(payload)}`, session };
}

export function verifySessionToken(token: string): Session | null {
  if (!token) return null;
  const dot = token.indexOf(".");
  if (dot < 1) return null;

  const payload = token.slice(0, dot);
  const sig     = token.slice(dot + 1);

  let expected: Buffer;
  try { expected = b64urlDecode(sign(payload)); } catch { return null; }
  let provided: Buffer;
  try { provided = b64urlDecode(sig); }          catch { return null; }
  if (expected.length !== provided.length)       return null;
  if (!timingSafeEqual(expected, provided))      return null;

  let parsed: Session;
  try { parsed = JSON.parse(b64urlDecode(payload).toString("utf8")) as Session; }
  catch { return null; }

  if (typeof parsed.user !== "string" || !parsed.user)               return null;
  if (typeof parsed.exp !== "number" || parsed.exp <= Date.now() / 1000) return null;
  return parsed;
}

/** Server-component / route helper to read the current session. */
export async function getSession(): Promise<Session | null> {
  const c = (await cookies()).get(COOKIE_NAME);
  return c ? verifySessionToken(c.value) : null;
}

/** Cookie options for Set-Cookie.
 *
 * Set ``COOKIE_SECURE=true`` in production (behind HTTPS). It deliberately
 * does NOT default to ``NODE_ENV==='production'`` because ``next start``
 * runs in production mode even on plain http://localhost during smoke
 * tests, and a Secure cookie would silently be dropped by the browser.
 */
export function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.COOKIE_SECURE === "true",
    path: "/",
    maxAge: COOKIE_MAX_AGE_SECONDS,
  };
}
