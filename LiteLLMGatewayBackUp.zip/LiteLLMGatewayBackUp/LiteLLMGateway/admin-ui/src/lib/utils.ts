import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Browser → BFF → Gateway. The session cookie authenticates the operator to
 * the BFF; the BFF (server-side) injects the gateway master key. No bearer
 * token in the browser, ever.
 *
 * Returns parsed JSON on success; throws an Error with status code on failure.
 * 401 from the proxy means the session expired — middleware will redirect
 * the next navigation.
 */
export async function fetchGateway<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`/api/gateway${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    credentials: "same-origin",
    cache: "no-store",
  });
  if (!res.ok) {
    let body: string | undefined;
    try { body = await res.text(); } catch { /* ignore */ }
    const err = new Error(`${res.status} ${res.statusText}${body ? `: ${body}` : ""}`);
    (err as Error & { status?: number }).status = res.status;
    throw err;
  }
  return res.json();
}
