"use client";

import { useCallback, useEffect, useState } from "react";

// Operator-tunable dashboard layout. Each section has a stable id (kept
// short and route-stable so a future page rename doesn't lose state) plus
// a human label for the customizer popover. Visibility + order are both
// persisted in localStorage so the operator's preference survives reloads.

export type DashboardSectionId =
  | "stats"
  | "activity"
  | "verdict"
  | "usage"
  | "top-models"
  | "top-teams"
  | "pipeline"
  | "plugins";

export type SectionMeta = { id: DashboardSectionId; label: string };

// Default order matches the historical layout — operators who don't open
// the customizer never notice anything changed.
export const DEFAULT_SECTIONS: SectionMeta[] = [
  { id: "stats",      label: "Quick stats (4-up)" },
  { id: "activity",   label: "Activity sparkline" },
  { id: "verdict",    label: "Verdict mix" },
  { id: "usage",      label: "Usage totals (tokens / cost)" },
  { id: "top-models", label: "Top models" },
  { id: "top-teams",  label: "Top teams" },
  { id: "pipeline",   label: "Pipeline stages" },
  { id: "plugins",    label: "Loaded plugins" },
];

type Prefs = {
  hidden: DashboardSectionId[];
  order:  DashboardSectionId[];
};

const STORAGE_KEY = "llmgw.dashboard.prefs.v1";

function loadPrefs(): Prefs {
  if (typeof window === "undefined") return { hidden: [], order: DEFAULT_SECTIONS.map((s) => s.id) };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { hidden: [], order: DEFAULT_SECTIONS.map((s) => s.id) };
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    // Sanitise: drop unknown ids, append any new defaults that weren't in the
    // saved order (so a future release adding a section doesn't hide it).
    const knownIds = new Set(DEFAULT_SECTIONS.map((s) => s.id));
    const savedOrder = (parsed.order ?? []).filter((id) => knownIds.has(id));
    const missing = DEFAULT_SECTIONS
      .map((s) => s.id)
      .filter((id) => !savedOrder.includes(id));
    return {
      hidden: (parsed.hidden ?? []).filter((id) => knownIds.has(id)),
      order:  [...savedOrder, ...missing],
    };
  } catch {
    return { hidden: [], order: DEFAULT_SECTIONS.map((s) => s.id) };
  }
}

function savePrefs(p: Prefs) {
  try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(p)); }
  catch { /* localStorage disabled — preferences just don't persist */ }
}

// Hook the dashboard calls to read + mutate layout prefs. Returns the
// effective ordered list of visible sections, plus actions to toggle a
// section or reorder.
export function useDashboardPrefs() {
  // SSR-safe initial state — start with defaults, hydrate on mount.
  const [prefs, setPrefs] = useState<Prefs>(
    { hidden: [], order: DEFAULT_SECTIONS.map((s) => s.id) },
  );
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setPrefs(loadPrefs());
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) savePrefs(prefs);
  }, [prefs, ready]);

  const toggle = useCallback((id: DashboardSectionId) => {
    setPrefs((p) => ({
      ...p,
      hidden: p.hidden.includes(id)
        ? p.hidden.filter((x) => x !== id)
        : [...p.hidden, id],
    }));
  }, []);

  const move = useCallback((from: number, to: number) => {
    setPrefs((p) => {
      if (from === to || from < 0 || to < 0) return p;
      if (from >= p.order.length || to >= p.order.length) return p;
      const next = [...p.order];
      const [picked] = next.splice(from, 1);
      next.splice(to, 0, picked);
      return { ...p, order: next };
    });
  }, []);

  const reset = useCallback(() => {
    setPrefs({ hidden: [], order: DEFAULT_SECTIONS.map((s) => s.id) });
  }, []);

  const meta = (id: DashboardSectionId) =>
    DEFAULT_SECTIONS.find((s) => s.id === id);

  const isHidden = (id: DashboardSectionId) => prefs.hidden.includes(id);

  // Resolved order: sections in saved order, dropping hidden ones.
  const visibleOrder = prefs.order.filter((id) => !isHidden(id));

  return {
    ready,
    prefs,
    visibleOrder,
    isHidden,
    toggle,
    move,
    reset,
    meta,
    all: DEFAULT_SECTIONS,
  };
}
