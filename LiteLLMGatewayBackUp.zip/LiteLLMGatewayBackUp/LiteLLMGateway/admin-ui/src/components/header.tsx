"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useTheme } from "next-themes";
import {
  ChevronDown, KeyRound, LifeBuoy, LogOut, Menu, Moon, MoonStar, Sun, SunMedium,
  User as UserIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/components/sidebar-context";
import { Breadcrumb } from "@/components/breadcrumb";

// Pages each get to drive what shows on the left side of the top bar
// (title + optional eyebrow). Wire via the existing markup later; for now
// the header is purely chrome + controls — page <h1> headings still live
// inside each page so the rest of the codebase isn't disturbed.
export function Header() {
  const router = useRouter();
  const { toggle: toggleSidebar } = useSidebar();
  const [user, setUser] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/me", { cache: "no-store", credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { if (!cancelled) setUser(d?.user ?? null); })
      .catch(() => { if (!cancelled) setUser(null); });
    return () => { cancelled = true; };
  }, []);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
    router.replace("/login");
    router.refresh();
  };

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-3 border-b border-border bg-card px-4 shadow-sm">
      {/* Left — hamburger toggle + breadcrumb + environment chip. */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={toggleSidebar}
          aria-label="Toggle sidebar"
          className="inline-flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground shrink-0"
        >
          <Menu className="h-4.5 w-4.5" />
        </button>
        <div className="hidden md:block min-w-0 truncate">
          <Breadcrumb />
        </div>
        <span
          className="ml-1 hidden lg:inline-flex items-center gap-2 rounded-md border border-border bg-secondary/60 px-3 py-1 text-[11px] font-medium tracking-tight text-muted-foreground"
          title="Gateway environment"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" aria-hidden />
          dev · localhost:4000
        </span>
      </div>

      {/* Right — theme toggle + user dropdown */}
      <div className="flex items-center gap-1.5">
        <ThemeToggle />
        <UserMenu user={user} onLogout={logout} />
      </div>
    </header>
  );
}

/* ------------------------------------------------------------------ *
 *  Theme toggle — 4-state segmented control:
 *    light, dark, solarized-light, solarized-dark.
 *  next-themes handles persistence; we just drive setTheme().
 *  Light/dark use Sun/Moon; the Solarized variants use the "Medium"
 *  glyphs (filled discs) so the two pairs read as families at a glance.
 * ------------------------------------------------------------------ */
type ThemeName = "light" | "dark" | "solarized-light" | "solarized-dark";

function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) {
    // Avoid SSR/hydration mismatch — render an inert placeholder sized
    // for four buttons.
    return <div className="h-8 w-[140px] rounded-md border border-border bg-secondary/60" aria-hidden />;
  }

  const current = (theme ?? "dark") as ThemeName;

  const options: { value: ThemeName; icon: typeof Sun; label: string }[] = [
    { value: "light",            icon: Sun,        label: "Light" },
    { value: "dark",             icon: Moon,       label: "Dark" },
    { value: "solarized-light",  icon: SunMedium,  label: "Solarized Light" },
    { value: "solarized-dark",   icon: MoonStar,   label: "Solarized Dark" },
  ];

  return (
    <div
      role="radiogroup"
      aria-label="Theme"
      className="inline-flex items-center gap-0.5 rounded-md border border-border bg-secondary/60 p-0.5"
    >
      {options.map(({ value, icon: Icon, label }) => {
        const active = current === value;
        return (
          <button
            key={value}
            role="radio"
            aria-checked={active}
            aria-label={label}
            title={label}
            onClick={() => setTheme(value)}
            className={cn(
              "flex h-7 w-7 items-center justify-center rounded-full transition-all",
              active
                ? "bg-accent text-accent-foreground shadow-sm"
                : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground",
            )}
          >
            <Icon className="h-3.5 w-3.5" />
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  User menu — avatar button + dropdown.
 *  No external dropdown lib; useState + outside-click handler is fine
 *  for a 5-item menu and avoids pulling in @radix-ui/react-dropdown-menu
 *  just for this one surface.
 * ------------------------------------------------------------------ */
function UserMenu({ user, onLogout }: { user: string | null; onLogout: () => void }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const router  = useRouter();

  // Close on outside click / Escape.
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown",   onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown",   onKey);
    };
  }, [open]);

  const initials = user ? user.slice(0, 2).toUpperCase() : "··";
  const display  = user ?? "signed out";

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
        className={cn(
          "flex items-center gap-2 rounded-md border border-border bg-secondary/60 py-1 pl-1 pr-2.5 transition-colors",
          "hover:bg-secondary",
          open && "bg-secondary",
        )}
      >
        <span
          className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-accent to-blue-500 text-[10.5px] font-semibold text-white"
          aria-hidden
        >
          {initials}
        </span>
        <span className="hidden text-[12.5px] font-medium tracking-tight sm:inline">{display}</span>
        <ChevronDown className={cn("h-3.5 w-3.5 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div
          role="menu"
          className="absolute right-0 top-[calc(100%+8px)] w-60 overflow-hidden rounded-md border border-border bg-card shadow-lg"
        >
          <div className="border-b border-border/60 px-4 py-3">
            <div className="text-xs uppercase tracking-[0.16em] text-muted-foreground/70">
              Signed in as
            </div>
            <div className="mt-0.5 truncate text-sm font-medium" title={display}>
              {display}
            </div>
          </div>

          <div className="py-1.5">
            <MenuItem
              icon={UserIcon}  label="Profile"
              onClick={() => { setOpen(false); router.push("/settings"); }}
            />
            <MenuItem
              icon={KeyRound}  label="My API keys"
              onClick={() => { setOpen(false); router.push("/keys"); }}
            />
            <MenuItem
              icon={LifeBuoy}  label="Help &amp; shortcuts"
              onClick={() => { setOpen(false); router.push("/settings"); }}
            />
          </div>

          <div className="border-t border-border/60 py-1.5">
            <MenuItem
              icon={LogOut} label="Sign out" tone="danger"
              onClick={() => { setOpen(false); onLogout(); }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

function MenuItem({
  icon: Icon, label, onClick, tone = "default",
}: {
  icon: typeof UserIcon;
  label: string;
  onClick: () => void;
  tone?: "default" | "danger";
}) {
  return (
    <button
      role="menuitem"
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-2.5 px-4 py-2 text-left text-sm transition-colors",
        tone === "danger"
          ? "text-destructive hover:bg-destructive/10"
          : "text-foreground hover:bg-secondary/70",
      )}
    >
      <Icon className="h-3.5 w-3.5 opacity-80" />
      <span dangerouslySetInnerHTML={{ __html: label }} />
    </button>
  );
}
