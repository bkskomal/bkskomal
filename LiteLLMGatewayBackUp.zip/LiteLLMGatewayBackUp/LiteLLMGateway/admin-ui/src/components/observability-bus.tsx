"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Activity } from "lucide-react";

// -------------------------------------------------------------------------
// API contract — mirrors GET /admin/observability/status verbatim.
// -------------------------------------------------------------------------

type PipeName = "postgres_audit" | "siem" | "prometheus" | "ueba" | "four_eyes";
type PipeState = "active" | "configured" | "off" | "partial";

type Pipe = {
  name:   PipeName;
  label:  string;
  state:  PipeState;
  detail: string | null;
  metric: string | null;
  href:   string | null;
};

type ObservabilityStatus = {
  pipes:        Pipe[];
  generated_at: string;
};

// Auto-refresh cadence. SIEM event counts move slowly so 30s is plenty —
// any tighter and we'd just be polling the audit DB for nothing.
const REFRESH_INTERVAL_MS = 30_000;

// Render order if the API returns the pipes in some other order. Keeping the
// chrome stable across refreshes is more important than matching server order.
const PIPE_ORDER: PipeName[] = [
  "postgres_audit",
  "siem",
  "prometheus",
  "ueba",
  "four_eyes",
];

// State → dot colour. Tailwind palette — no custom CSS.
const STATE_DOT: Record<PipeState, string> = {
  active:     "bg-emerald-500",
  configured: "bg-emerald-400",
  partial:    "bg-amber-500",
  off:        "bg-muted-foreground/40",
};

// Skeleton labels used during the initial load so the bar reserves visual
// space matching the real pipe labels (avoids a layout pop on first paint).
const SKELETON_LABELS = [
  "Postgres audit",
  "SIEM",
  "Prometheus",
  "UEBA",
  "4-eyes",
];

export function ObservabilityBus() {
  const [data, setData]       = useState<ObservabilityStatus | null>(null);
  const [error, setError]     = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const r = await fetch("/api/gateway/admin/observability/status", {
        cache: "no-store", credentials: "same-origin",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      setData((await r.json()) as ObservabilityStatus);
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  }, []);

  useEffect(() => {
    void refresh();
    const id = window.setInterval(refresh, REFRESH_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, [refresh]);

  // Sort pipes into the canonical order so the bar layout is stable across
  // refreshes regardless of how the gateway happens to serialize them.
  const pipes = data
    ? [...data.pipes].sort(
        (a, b) => PIPE_ORDER.indexOf(a.name) - PIPE_ORDER.indexOf(b.name),
      )
    : null;

  return (
    <section
      aria-label="Observability bus status"
      className="flex items-center gap-4 rounded-md border border-border bg-card px-4 py-3 shadow-soft"
    >
      {/* Left: bus label */}
      <div className="flex shrink-0 items-center gap-2 text-foreground">
        <Activity className="h-3.5 w-3.5" aria-hidden />
        <span className="text-[11px] font-semibold uppercase tracking-[0.16em]">
          Observability Bus
        </span>
      </div>

      {/* Right: pipes (or skeleton / error). no-scrollbar is a project-wide
          utility; if it's not in the Tailwind config the bar still works,
          it just shows a thin scrollbar on narrow screens. */}
      <div className="no-scrollbar flex flex-1 snap-x items-center gap-1 overflow-x-auto">
        {error ? (
          <span className="text-xs text-destructive">observability fetch failed</span>
        ) : !pipes ? (
          // Loading state — 5 placeholder pills sized to the real labels so
          // the bar doesn't reflow when data arrives.
          SKELETON_LABELS.map((lbl, i) => (
            <span key={i} className="contents">
              {i > 0 && <span className="h-4 w-px bg-border/60" aria-hidden />}
              <span className="inline-flex shrink-0 snap-start animate-pulse items-center gap-1.5 rounded-md bg-secondary/40 px-2 py-1">
                <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/30" />
                <span className="text-xs text-transparent">{lbl}</span>
              </span>
            </span>
          ))
        ) : (
          pipes.map((p, i) => (
            <span key={p.name} className="contents">
              {i > 0 && <span className="h-4 w-px bg-border/60" aria-hidden />}
              <PipePill pipe={p} />
            </span>
          ))
        )}
      </div>
    </section>
  );
}

// One pipe pill. Wrapped in a Link iff the gateway gave us an href; otherwise
// a bare span so we don't render an empty <a> that screen-readers would still
// announce as a link.
function PipePill({ pipe }: { pipe: Pipe }) {
  const inner = (
    <>
      <span
        className={"h-1.5 w-1.5 rounded-full " + STATE_DOT[pipe.state]}
        aria-hidden
      />
      <span className="text-xs text-foreground">{pipe.label}</span>
      {pipe.metric && (
        <span className="font-mono text-[10px] text-muted-foreground">
          {pipe.metric}
        </span>
      )}
    </>
  );

  // title= renders a native browser tooltip on hover. We're deliberately
  // avoiding a JS tooltip primitive here to keep the bus chrome dependency-free.
  const title = pipe.detail ?? undefined;
  const baseClass =
    "inline-flex shrink-0 snap-start items-center gap-1.5 rounded-md px-2 py-1 transition-colors";

  if (pipe.href) {
    return (
      <Link
        href={pipe.href}
        title={title}
        className={baseClass + " hover:bg-secondary/40"}
        aria-label={`${pipe.label} (${pipe.state})`}
      >
        {inner}
      </Link>
    );
  }
  return (
    <span
      title={title}
      className={baseClass}
      aria-label={`${pipe.label} (${pipe.state})`}
    >
      {inner}
    </span>
  );
}
