"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Loader2, Plus, RefreshCw, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

type CatalogModel = {
  id:                  string;
  name:                string;
  description:         string | null;
  context_length:      number | null;
  pricing_prompt_usd_per_1k:     number | null;
  pricing_completion_usd_per_1k: number | null;
};

// Modal that fetches the OpenRouter catalog and lets the operator import
// any model into the gateway registry with one click. Search filters in
// the gateway BFF (server-side) so the round-trip cost stays low even on
// the full ~250-model catalog.
export function OpenRouterBrowser({
  open, onClose, onImported,
}: {
  open: boolean;
  onClose: () => void;
  onImported?: (modelName: string) => void;
}) {
  const [models, setModels] = useState<CatalogModel[] | null>(null);
  const [err, setErr]       = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [importing, setImporting] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const reqRef = useRef(0);

  const fetchCatalog = useCallback(async (q: string, force = false) => {
    const myId = ++reqRef.current;
    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set("search", q.trim());
      if (force)    params.set("force_refresh", "true");
      const r = await fetch(
        `${GW}/admin/providers/openrouter/models?${params.toString()}`,
        { credentials: "same-origin", cache: "no-store" },
      );
      if (!r.ok) {
        const text = await r.text().catch(() => "");
        throw new Error(`${r.status} ${r.statusText}${text ? ` — ${text.slice(0, 160)}` : ""}`);
      }
      const data: CatalogModel[] = await r.json();
      if (myId !== reqRef.current) return;
      setModels(data);
      setErr(null);
    } catch (e) {
      if (myId !== reqRef.current) return;
      setErr(String(e));
      setModels([]);
    } finally {
      if (myId === reqRef.current) setRefreshing(false);
    }
  }, []);

  // Initial fetch when opened; close → reset state on next open.
  useEffect(() => {
    if (!open) return;
    setModels(null);
    setErr(null);
    setSearch("");
    void fetchCatalog("");
  }, [open, fetchCatalog]);

  // Debounced refetch on search input.
  useEffect(() => {
    if (!open) return;
    const t = window.setTimeout(() => { void fetchCatalog(search); }, 250);
    return () => window.clearTimeout(t);
  }, [search, open, fetchCatalog]);

  // Close on Escape.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const refresh = () => {
    setRefreshing(true);
    void fetchCatalog(search, true);
  };

  const importModel = async (m: CatalogModel) => {
    setImporting(m.id);
    try {
      const r = await fetch(`${GW}/admin/providers/openrouter/import`, {
        method: "POST", credentials: "same-origin", headers: JSON_HEADERS,
        body: JSON.stringify({ or_model_id: m.id, enabled: true }),
      });
      if (!r.ok) {
        const text = await r.text().catch(() => "");
        throw new Error(`${r.status} ${r.statusText}${text ? ` — ${text}` : ""}`);
      }
      const created = await r.json();
      onImported?.(created.model_name);
      onClose();
    } catch (e) {
      setErr(String(e));
    } finally {
      setImporting(null);
    }
  };

  const sorted = useMemo(() => {
    if (!models) return null;
    // Cheaper models first when search is empty — operators usually pick
    // by price when browsing.
    return [...models].sort((a, b) => {
      const ap = a.pricing_prompt_usd_per_1k ?? 99999;
      const bp = b.pricing_prompt_usd_per_1k ?? 99999;
      return ap - bp;
    });
  }, [models]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden rounded-lg border border-border bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div>
            <div className="text-[15px] font-semibold">Browse OpenRouter catalog</div>
            <div className="text-[11px] text-muted-foreground">
              {sorted ? `${sorted.length.toLocaleString()} models` : "Loading…"}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={refresh} disabled={refreshing}>
              <RefreshCw className={"mr-1.5 h-3.5 w-3.5 " + (refreshing ? "animate-spin" : "")} />
              Refresh
            </Button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="border-b border-border bg-background/30 px-4 py-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by id, name, or description (e.g. claude, kimi, qwen)…"
              className="h-9 pl-8 text-sm"
            />
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          {err && (
            <div className="m-4 rounded-md border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
              {err}
            </div>
          )}
          {!sorted ? (
            <div className="flex items-center justify-center py-12 text-sm text-muted-foreground">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Loading catalog…
            </div>
          ) : sorted.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              No models match &quot;{search}&quot;.
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {sorted.map((m) => (
                <li key={m.id} className="flex items-start gap-3 px-4 py-3 hover:bg-secondary/40">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <code className="text-[13px] font-medium text-foreground">{m.id}</code>
                      {m.context_length != null && (
                        <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">
                          {m.context_length >= 1000
                            ? `${Math.round(m.context_length / 1000)}k ctx`
                            : `${m.context_length} ctx`}
                        </span>
                      )}
                    </div>
                    {m.name && m.name !== m.id && (
                      <div className="text-[12px] text-muted-foreground">{m.name}</div>
                    )}
                    {m.description && (
                      <div className="mt-1 line-clamp-2 text-[11px] text-muted-foreground">
                        {m.description}
                      </div>
                    )}
                    <div className="mt-1 flex flex-wrap gap-3 text-[10.5px] text-muted-foreground">
                      {m.pricing_prompt_usd_per_1k != null && (
                        <span>in <strong className="text-foreground">${m.pricing_prompt_usd_per_1k}/1k</strong></span>
                      )}
                      {m.pricing_completion_usd_per_1k != null && (
                        <span>out <strong className="text-foreground">${m.pricing_completion_usd_per_1k}/1k</strong></span>
                      )}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="accent"
                    onClick={() => importModel(m)}
                    disabled={importing != null}
                    className="shrink-0"
                  >
                    {importing === m.id ? (
                      <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Plus className="mr-1 h-3.5 w-3.5" />
                    )}
                    {importing === m.id ? "Adding…" : "Add"}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
