"use client";

import { useCallback, useEffect, useState } from "react";
import { Check, KeyRound, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

type ConfigResponse = { has_key: boolean; key_prefix: string | null };
type TestResponse   = { ok: boolean; reason?: string };

// Settings → Providers section. Today: OpenRouter API key management +
// connectivity test. Future providers can drop into this card the same way.
// Key flows through the gateway's BFF; never sent to the browser after save
// (only a 12-char prefix is exposed back to the UI).
export function ProvidersCard({
  onKeyChanged,
}: {
  onKeyChanged?: () => void;
}) {
  const [cfg, setCfg]       = useState<ConfigResponse | null>(null);
  const [draft, setDraft]   = useState("");
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [msg, setMsg]       = useState<{ tone: "ok" | "err" | "info"; text: string } | null>(null);

  const refresh = useCallback(async () => {
    try {
      const r = await fetch(`${GW}/admin/providers/openrouter`, {
        credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data: ConfigResponse = await r.json();
      setCfg(data);
    } catch (e) {
      setMsg({ tone: "err", text: `Load failed: ${String(e)}` });
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      const r = await fetch(`${GW}/admin/providers/openrouter`, {
        method: "PUT", credentials: "same-origin", headers: JSON_HEADERS,
        body: JSON.stringify({ api_key: draft || null }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data: ConfigResponse = await r.json();
      setCfg(data);
      setDraft("");
      setMsg({ tone: "ok", text: data.has_key ? "Saved." : "Key cleared." });
      onKeyChanged?.();
      setTimeout(() => setMsg(null), 4000);
    } catch (e) {
      setMsg({ tone: "err", text: String(e) });
    } finally {
      setSaving(false);
    }
  };

  const runTest = async () => {
    setTesting(true);
    setMsg(null);
    try {
      const r = await fetch(`${GW}/admin/providers/openrouter/test`, {
        credentials: "same-origin", cache: "no-store",
      });
      const data: TestResponse = await r.json();
      if (data.ok) {
        setMsg({ tone: "ok", text: "Key authenticated with OpenRouter." });
      } else if (data.reason === "no_key_stored") {
        setMsg({ tone: "info", text: "No key stored yet — save one first." });
      } else {
        setMsg({ tone: "err", text: "Key rejected by OpenRouter." });
      }
    } catch (e) {
      setMsg({ tone: "err", text: String(e) });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-[15px]">
          <KeyRound className="h-4 w-4 text-accent" />
          Providers
        </CardTitle>
        <CardDescription>
          API keys and endpoints managed centrally. Stored on the gateway server;
          the browser only ever sees a prefix.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* OpenRouter row */}
        <div className="space-y-2 rounded-md border border-border bg-background/40 p-3">
          <div className="flex items-center justify-between">
            <div className="text-[13px] font-medium">OpenRouter</div>
            {cfg && (
              cfg.has_key ? (
                <span className="inline-flex items-center gap-1.5 text-[11px] text-emerald-600">
                  <Check className="h-3 w-3" /> configured
                  {cfg.key_prefix && (
                    <code className="ml-1 rounded bg-muted px-1 py-0.5 text-[10px]">{cfg.key_prefix}</code>
                  )}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <X className="h-3 w-3" /> not configured
                </span>
              )
            )}
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input
              type="password"
              autoComplete="off"
              spellCheck={false}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder={cfg?.has_key ? "Paste a new key to replace, or leave empty to keep" : "sk-or-v1-..."}
              className="flex-1 font-mono text-xs"
            />
            <div className="flex gap-2">
              <Button
                size="sm" variant="accent"
                onClick={save}
                disabled={saving || (!draft && !cfg?.has_key)}
                title={draft ? "Save key" : "Clear stored key"}
              >
                {saving ? "Saving…" : draft ? "Save" : "Clear"}
              </Button>
              <Button
                size="sm" variant="outline"
                onClick={runTest}
                disabled={testing || !cfg?.has_key}
                title="Hit OpenRouter /auth/key with the stored token"
              >
                {testing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Test"}
              </Button>
            </div>
          </div>
          {msg && (
            <div
              className={
                "text-[11px] " +
                (msg.tone === "ok"
                  ? "text-emerald-600"
                  : msg.tone === "err"
                    ? "text-destructive"
                    : "text-muted-foreground")
              }
            >
              {msg.text}
            </div>
          )}
          <p className="text-[11px] text-muted-foreground">
            Used by every model whose <code>api_key</code> is set to
            <code className="mx-1">os.environ/OPENROUTER_API_KEY</code>. Overrides the
            environment variable when present.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
