"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity, Boxes, ChevronRight, ClipboardList, Cog, Cpu, Gauge,
  GitFork, Key, KeyRound, LayoutDashboard, LineChart, Lock, LogIn,
  Plug, Plug2, ScrollText, Settings as SettingsIcon, Shield, ShieldAlert,
  ShieldCheck, ShieldX, Users, Workflow,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/components/sidebar-context";

// Sidebar groups are aligned to the 6 pipeline stages every request walks
// through: AuthN → AuthZ → DLP → Smart Router → Inference → Audit. The
// "System" group at the bottom holds cross-cutting config that isn't
// tied to a single stage.
type Item = { href: string; icon: typeof Users; label: string };

const OVERVIEW: Item = { href: "/", icon: LayoutDashboard, label: "Overview" };

const NAV_GROUPS: { id: string; heading: string; icon: typeof Users; items: Item[] }[] = [
  { id: "authn", heading: "AuthN", icon: LogIn, items: [
    { href: "/keys",    icon: Key,   label: "API Keys" },
    { href: "/connect", icon: Plug2, label: "Connect" },
  ]},
  { id: "authz", heading: "AuthZ", icon: Lock, items: [
    { href: "/teams",      icon: Users,        label: "Teams" },
    { href: "/policies",   icon: ShieldCheck,  label: "Policies" },
    { href: "/elevations", icon: ShieldAlert,  label: "JIT Elevations" },
  ]},
  { id: "dlp", heading: "DLP", icon: Shield, items: [
    { href: "/guardrails", icon: ShieldX, label: "Guardrails" },
  ]},
  { id: "router", heading: "Smart Router", icon: Workflow, items: [
    { href: "/router", icon: GitFork, label: "Rules" },
  ]},
  { id: "inference", heading: "Inference", icon: Cpu, items: [
    { href: "/settings/models", icon: Boxes, label: "Models" },
  ]},
  { id: "audit", heading: "Audit", icon: ClipboardList, items: [
    { href: "/audit",                 icon: ScrollText, label: "Log" },
    { href: "/audit/reveal-requests", icon: KeyRound,   label: "Reveal queue" },
    { href: "/monitoring",            icon: Activity,   label: "UEBA" },
    { href: "/metrics",               icon: LineChart,  label: "Metrics" },
    { href: "/observability",         icon: Gauge,      label: "Observability" },
  ]},
  { id: "system", heading: "System", icon: Cog, items: [
    { href: "/plugins",      icon: Plug,         label: "Plugins" },
    { href: "/settings/app", icon: SettingsIcon, label: "App settings" },
  ]},
];

// Persisted set of group ids currently expanded. Default = all collapsed
// per operator request; whichever group contains the active route gets
// auto-expanded on every navigation so the operator never loses sight
// of their location.
const EXPAND_STORAGE_KEY = "llmgw.sidebar.groups.expanded.v1";

export function Nav() {
  const pathname = usePathname();
  const { collapsed } = useSidebar();

  // Which group contains the current pathname? Used to force-open that
  // group every time the route changes (even if the operator manually
  // closed it earlier — your active row should always be visible).
  const activeGroupId = useMemo(() => {
    for (const g of NAV_GROUPS) {
      if (g.items.some((it) => pathname?.startsWith(it.href))) return g.id;
    }
    return null;
  }, [pathname]);

  const [expanded, setExpanded] = useState<Set<string>>(() => new Set());

  // Hydrate from localStorage on mount.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(EXPAND_STORAGE_KEY);
      if (raw) {
        const arr = JSON.parse(raw) as string[];
        if (Array.isArray(arr)) setExpanded(new Set(arr));
      }
    } catch { /* localStorage unavailable — start collapsed */ }
  }, []);

  // Auto-open the group containing the active route. Operators can still
  // manually open/close other groups; this ensures the *active* one is
  // never hidden, even after a hard reload that opened the page directly.
  useEffect(() => {
    if (!activeGroupId) return;
    setExpanded((prev) => {
      if (prev.has(activeGroupId)) return prev;
      const next = new Set(prev);
      next.add(activeGroupId);
      return next;
    });
  }, [activeGroupId]);

  // Persist (skipping the very first SSR render to avoid wiping saved state).
  useEffect(() => {
    try {
      window.localStorage.setItem(
        EXPAND_STORAGE_KEY,
        JSON.stringify(Array.from(expanded)),
      );
    } catch { /* ignore */ }
  }, [expanded]);

  const toggleGroup = useCallback((id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  return (
    <aside
      className={cn(
        "sidebar-shell sticky top-0 z-20 flex h-screen shrink-0 flex-col transition-[width] duration-200",
        collapsed ? "w-[68px]" : "w-64",
      )}
      aria-label="Primary"
    >
      {/* Brand — OATI mark + product wordmark.
          The OATI logo carries its own red gear ring + chrome wordmark, so
          we drop the previous gradient "sparkles" tile and use the PNG
          directly. In collapsed (icon-only) sidebar mode we show just the
          mark; expanded we show mark + "OATI LLMGateway" wordmark. */}
      <Link
        href="/"
        className={cn(
          "sidebar-brand flex h-14 items-center gap-3 px-4",
          collapsed && "justify-center px-0",
        )}
        aria-label="OATI LLMGateway · home"
      >
        {/* next/image is overkill for a 30 px chrome mark — a plain <img>
            keeps the bundle clean and lets the alpha PNG show through the
            navy sidebar without a forced background. */}
        {/* Solarized base02 backing tile — the OATI logo carries its own
            red-gradient halo which looks ragged on light backgrounds. A
            small deep-teal patch (matches the Solarized Dark base02
            #073642) makes the logo read consistently in every theme. */}
        <div className="flex h-12 w-16 shrink-0 items-center justify-center rounded-md bg-[#073642]">
          <img
            src="/oati-logo.png"
            alt=""
            width={56}
            height={44}
            className="h-10 w-auto select-none"
            draggable={false}
          />
        </div>
        {!collapsed && (
          <div className="brand-mark text-[16px] font-semibold tracking-tight">
            OATI&nbsp;LLMGateway
          </div>
        )}
      </Link>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4">
        {/* Overview sits outside the pipeline grouping. */}
        <div className="mb-3">
          <SidebarLink
            item={OVERVIEW}
            active={pathname === "/"}
            collapsed={collapsed}
          />
        </div>

        {NAV_GROUPS.map((group) => {
          const isOpen = collapsed ? true : expanded.has(group.id);
          const GroupIcon = group.icon;
          const isActiveGroup = activeGroupId === group.id;
          // When the sidebar is in icon-only (collapsed) mode the groups
          // can't really be collapsed any further — items render as
          // tooltipped icons grouped by a divider. We force-show them.
          return (
            <div key={group.id} className="mb-1.5 last:mb-0">
              {!collapsed && (
                <button
                  type="button"
                  onClick={() => toggleGroup(group.id)}
                  aria-expanded={isOpen}
                  aria-controls={`nav-group-${group.id}`}
                  className={cn(
                    // Headings get their own visual treatment so the eye
                    // separates parent from child at a glance: always-on
                    // dark band, semibold label, persistent left accent.
                    // The active group (containing current route) brightens
                    // the bar to the accent colour.
                    "sidebar-group-toggle relative flex w-full items-center justify-between",
                    "py-2.5 pl-5 pr-4 text-[13px] font-semibold tracking-tight transition-colors",
                    "text-[hsl(var(--sidebar-fg))] bg-[hsl(var(--sidebar-bg-deep))]/55",
                    "hover:bg-[hsl(var(--sidebar-bg-deep))]/80",
                    isActiveGroup &&
                      "bg-[hsl(var(--sidebar-active-bg))] text-[hsl(var(--sidebar-fg))]",
                  )}
                >
                  {/* Left accent bar — always visible (so a heading reads
                      as a chip), brighter when active. */}
                  <span
                    aria-hidden
                    className={cn(
                      "absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r-full transition-colors",
                      isActiveGroup
                        ? "bg-[hsl(var(--sidebar-active-bar))]"
                        : "bg-[hsl(var(--sidebar-fg-muted))]/35",
                    )}
                  />
                  <span className="flex items-center gap-3">
                    <GroupIcon className="h-4 w-4 shrink-0" aria-hidden />
                    {group.heading}
                  </span>
                  <ChevronRight
                    className={cn(
                      "h-3.5 w-3.5 opacity-70 transition-transform",
                      isOpen && "rotate-90",
                    )}
                    aria-hidden
                  />
                </button>
              )}
              {collapsed && (
                <div
                  className="mx-3 mb-1 mt-2 h-px bg-[hsl(var(--sidebar-border))]/70"
                  aria-hidden
                />
              )}
              {isOpen && (
                <div id={`nav-group-${group.id}`}>
                  {group.items.map((item) => {
                    const active = pathname?.startsWith(item.href) ?? false;
                    return (
                      <SidebarLink
                        key={item.href}
                        item={item}
                        active={active}
                        collapsed={collapsed}
                        nested
                      />
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div
        className={cn(
          "border-t border-[hsl(var(--sidebar-border))] py-3 text-[10.5px] sidebar-section-heading",
          collapsed ? "px-2 text-center" : "px-5",
        )}
      >
        {collapsed
          ? <span className="font-mono opacity-70">v0.1</span>
          : <>v0.1.0 · build {process.env.NEXT_PUBLIC_BUILD ?? "dev"}</>}
      </div>
    </aside>
  );
}

function SidebarLink({
  item, active, collapsed, nested,
}: {
  item: Item;
  active: boolean;
  collapsed: boolean;
  /** When inside a collapsible group, indent so the parent heading
   *  visibly contains the item. Top-level entries (Overview) use the
   *  same px-5 base padding as the group headings themselves. */
  nested?: boolean;
}) {
  const { icon: Icon, href, label } = item;
  return (
    <Link
      href={href}
      title={collapsed ? label : undefined}
      className={cn(
        "sidebar-item group relative flex items-center gap-3 py-2 text-[13px] transition-colors",
        // Top-level: align with headings. Nested: bump left padding so
        // the item icon line up under the heading's heading-text column.
        nested && !collapsed ? "pl-12 pr-5" : "px-5",
        active && "active",
        collapsed && "justify-center px-0 py-2.5",
      )}
      aria-current={active ? "page" : undefined}
    >
      <Icon className="h-4 w-4 shrink-0" />
      {!collapsed && <span className="font-medium">{label}</span>}
    </Link>
  );
}
