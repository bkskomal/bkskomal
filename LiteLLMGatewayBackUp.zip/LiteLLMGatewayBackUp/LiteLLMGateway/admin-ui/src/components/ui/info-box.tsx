"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";

// AdminLTE-style colored stat tile. Five tones map to AdminLTE's small-box
// palette + a primary blue + dark variant. The footer link is optional —
// when no href is given the footer slot just shows a hint line.
export type InfoBoxTone =
  | "info" | "success" | "warning" | "danger" | "primary" | "secondary" | "dark";

export function InfoBox({
  tone, value, label, icon, footer, href,
}: {
  tone:  InfoBoxTone;
  value: React.ReactNode;
  label: string;
  icon:  React.ReactNode;
  footer?: string;
  href?:   string;
}) {
  const inner = (
    <>
      <div className="relative px-4 pb-3 pt-4">
        <div className="info-value">{value}</div>
        <div className="info-label">{label}</div>
        <div className="info-icon">
          {/* Render the icon at a big size; opacity is handled by `.info-icon`. */}
          <span aria-hidden style={{ display: "inline-block" }}>
            {icon}
          </span>
        </div>
      </div>
      <div className="info-footer">
        <span>{footer ?? "More info"}</span>
        <ArrowRight className="h-3.5 w-3.5" />
      </div>
    </>
  );

  const className = `info-box info-box-${tone}`;
  if (href) {
    return (
      <Link href={href} className={className}>
        {inner}
      </Link>
    );
  }
  return <div className={className}>{inner}</div>;
}
