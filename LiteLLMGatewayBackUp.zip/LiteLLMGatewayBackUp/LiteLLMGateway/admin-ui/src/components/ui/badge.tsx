import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium tracking-wide transition-colors",
  {
    variants: {
      variant: {
        // Tinted-bg + saturated-colored-text pattern across the board so
        // every variant has readable contrast in both light and dark
        // themes. The `accent` variant previously used `text-accent-
        // foreground` (white) on a 15%-opacity teal background — white
        // on pale teal is unreadable in the light theme. Switched to
        // `text-accent` (the full teal) which mirrors how `success` /
        // `warning` / `destructive` work.
        default:     "border-transparent bg-secondary text-secondary-foreground",
        secondary:   "border-border bg-secondary text-secondary-foreground",
        destructive: "border-transparent bg-destructive/15 text-destructive",
        outline:     "border-border text-foreground",
        success:     "border-transparent bg-oati-success/20 text-oati-success",
        warning:     "border-transparent bg-oati-warning/20 text-oati-warning",
        accent:      "border-transparent bg-accent/20 text-accent",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

// Rendered as a <span> so it counts as phrasing content — placing a
// Badge inside a <p> or other text-flow element is HTML-valid. The
// existing `inline-flex` className keeps the visual layout identical
// to the previous <div>-based version. A <div> here triggers React's
// "div cannot be a descendant of p" hydration warning.
export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { badgeVariants };
