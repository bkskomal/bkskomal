"use client";

import { useCallback, useEffect, useState } from "react";
import { Check, Loader2, Mail, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

type Config = {
  host: string;
  port: number;
  user: string;
  from_addr: string;
  from_name: string;
  use_tls: boolean;
  use_ssl: boolean;
  has_password: boolean;
  password_prefix: string | null;
};
type TestResponse = { ok: boolean; error?: string };

// Settings → App settings · SMTP card. Mirrors the OpenRouter Providers
// card pattern: server-side persistence in system_settings, the browser
// never holds the password after save (only a 4-char prefix).
export function SmtpCard() {
  const [cfg, setCfg]       = useState<Config | null>(null);
  const [err, setErr]       = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Editable draft state. `password` is treated specially — null means
  // "leave the stored one alone"; "" means "clear"; non-empty means
  // "replace". The UI uses an explicit "Update password" toggle so a
  // re-save doesn't silently re-send the existing password.
  const [draft, setDraft] = useState<Omit<Config, "has_password" | "password_prefix">>({
    host: "", port: 587, user: "", from_addr: "",
    from_name: "OATI LLMGateway", use_tls: true, use_ssl: false,
  });
  const [updatePw, setUpdatePw] = useState(false);
  const [newPw,    setNewPw]    = useState("");

  // Test-send state
  const [testTo,   setTestTo]   = useState("");
  const [testing,  setTesting]  = useState(false);
  const [testMsg,  setTestMsg]  = useState<{ ok: boolean; text: string } | null>(null);

  const refresh = useCallback(async () => {
    try {
      const r = await fetch(`${GW}/admin/providers/smtp`, {
        credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data: Config = await r.json();
      setCfg(data);
      setDraft({
        host: data.host, port: data.port, user: data.user,
        from_addr: data.from_addr, from_name: data.from_name,
        use_tls: data.use_tls, use_ssl: data.use_ssl,
      });
    } catch (e) {
      setErr(`Load failed: ${String(e)}`);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const save = async () => {
    setSaving(true);
    setErr(null);
    try {
      const body: Record<string, unknown> = { ...draft };
      // Only send `password` when the operator explicitly opted to update it.
      if (updatePw) body.password = newPw;
      const r = await fetch(`${GW}/admin/providers/smtp`, {
        method: "PUT", credentials: "same-origin", headers: JSON_HEADERS,
        body: JSON.stringify(body),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data: Config = await r.json();
      setCfg(data);
      setUpdatePw(false);
      setNewPw("");
    } catch (e) {
      setErr(String(e));
    } finally {
      setSaving(false);
    }
  };

  const sendTest = async () => {
    if (!testTo.trim()) return;
    setTesting(true);
    setTestMsg(null);
    try {
      const r = await fetch(`${GW}/admin/providers/smtp/test`, {
        method: "POST", credentials: "same-origin", headers: JSON_HEADERS,
        body: JSON.stringify({ to_addr: testTo.trim() }),
      });
      const data: TestResponse = await r.json();
      if (data.ok) {
        setTestMsg({ ok: true, text: `Sent to ${testTo.trim()} — check the inbox.` });
      } else {
        setTestMsg({ ok: false, text: data.error || "SMTP send failed." });
      }
    } catch (e) {
      setTestMsg({ ok: false, text: String(e) });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-[15px]">
          <Mail className="h-4 w-4 text-accent" />
          SMTP — outbound email
        </CardTitle>
        <CardDescription>
          Used when the operator ticks &quot;Email to developer&quot; on the
          Keys page. The raw API key is the only thing this server ever
          emails — every other notification surfaces in the admin UI.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {err && (
          <div className="rounded-md border border-destructive/40 bg-destructive/10 p-2 text-xs text-destructive">
            {err}
          </div>
        )}

        {/* Connection */}
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Host">
            <Input value={draft.host}
                   onChange={(e) => setDraft({ ...draft, host: e.target.value })}
                   placeholder="smtp.office365.com"
                   className="font-mono text-xs" />
          </Field>
          <Field label="Port">
            <Input type="number" min={1} max={65535}
                   value={draft.port}
                   onChange={(e) => setDraft({ ...draft, port: Number(e.target.value) || 0 })}
                   className="font-mono text-xs" />
          </Field>
          <Field label="User (auth)">
            <Input value={draft.user}
                   onChange={(e) => setDraft({ ...draft, user: e.target.value })}
                   placeholder="bot@oati.example"
                   className="font-mono text-xs" />
          </Field>
          <Field label={
            cfg?.has_password
              ? <>Password (stored: <code className="rounded bg-muted px-1 py-0.5 text-[10px]">{cfg.password_prefix}</code>)</>
              : "Password"
          }>
            {!updatePw ? (
              <Button size="sm" variant="outline"
                      onClick={() => setUpdatePw(true)}
                      className="h-9 w-full">
                {cfg?.has_password ? "Update password" : "Set password"}
              </Button>
            ) : (
              <div className="flex items-center gap-1.5">
                <Input type="password" value={newPw}
                       onChange={(e) => setNewPw(e.target.value)}
                       placeholder={cfg?.has_password ? "(leave blank to clear)" : "new password"}
                       className="font-mono text-xs" />
                <Button size="sm" variant="ghost"
                        onClick={() => { setUpdatePw(false); setNewPw(""); }}
                        title="Cancel"
                        className="h-9 px-2">
                  <X className="h-3.5 w-3.5" />
                </Button>
              </div>
            )}
          </Field>
        </div>

        {/* From identity */}
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="From address">
            <Input value={draft.from_addr}
                   onChange={(e) => setDraft({ ...draft, from_addr: e.target.value })}
                   placeholder="no-reply@oati.example"
                   className="font-mono text-xs" />
          </Field>
          <Field label="From name">
            <Input value={draft.from_name}
                   onChange={(e) => setDraft({ ...draft, from_name: e.target.value })}
                   placeholder="OATI LLMGateway"
                   className="text-sm" />
          </Field>
        </div>

        {/* Transport options */}
        <div className="flex flex-wrap items-center gap-4 text-[12px]">
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={draft.use_tls}
                   onChange={(e) => setDraft({ ...draft, use_tls: e.target.checked, use_ssl: e.target.checked ? false : draft.use_ssl })}
                   className="h-3.5 w-3.5 accent-[hsl(var(--accent))]" />
            <span>STARTTLS (port 587 typical)</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={draft.use_ssl}
                   onChange={(e) => setDraft({ ...draft, use_ssl: e.target.checked, use_tls: e.target.checked ? false : draft.use_tls })}
                   className="h-3.5 w-3.5 accent-[hsl(var(--accent))]" />
            <span>Implicit TLS / SSL (port 465 typical)</span>
          </label>
        </div>

        <div className="flex justify-end">
          <Button size="sm" variant="accent" onClick={save} disabled={saving}>
            {saving ? "Saving…" : "Save SMTP config"}
          </Button>
        </div>

        {/* Test send */}
        <div className="border-t border-border pt-3">
          <div className="text-[12px] font-semibold text-foreground">Test send</div>
          <p className="text-[11px] text-muted-foreground">
            Sends a tiny no-secrets message to verify the configuration.
          </p>
          <div className="mt-2 flex items-center gap-2">
            <Input value={testTo}
                   onChange={(e) => setTestTo(e.target.value)}
                   placeholder="recipient@example.com"
                   type="email"
                   className="text-sm" />
            <Button size="sm" variant="outline" onClick={sendTest}
                    disabled={testing || !testTo.trim() || !cfg?.host}
                    title={!cfg?.host ? "Save host first" : "Send test"}>
              {testing
                ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                : "Send"}
            </Button>
          </div>
          {testMsg && (
            <div className={"mt-2 inline-flex items-center gap-1.5 text-[11px] " +
                            (testMsg.ok ? "text-emerald-600" : "text-destructive")}>
              {testMsg.ok ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
              {testMsg.text}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function Field({ label, children }: { label: React.ReactNode; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
