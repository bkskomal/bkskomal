"use client";

import { createContext, useCallback, useContext, useEffect, useState } from "react";

// Sidebar collapse state, persisted across reloads. Lifted to a context so
// the header's hamburger toggle and the nav itself share one source of
// truth without prop-drilling through Shell.
type SidebarCtx = {
  collapsed: boolean;
  toggle:    () => void;
  setCollapsed: (v: boolean) => void;
};

const Ctx = createContext<SidebarCtx | null>(null);

const STORAGE_KEY = "llmgw.sidebar.collapsed";

export function SidebarProvider({ children }: { children: React.ReactNode }) {
  // SSR default is expanded; we hydrate from localStorage on mount so the
  // SSR markup matches the first paint, then upgrade silently.
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    try {
      const v = window.localStorage.getItem(STORAGE_KEY);
      if (v === "1") setCollapsed(true);
    } catch { /* localStorage disabled — fall back to expanded */ }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, collapsed ? "1" : "0");
    } catch { /* ignore */ }
  }, [collapsed]);

  const toggle = useCallback(() => setCollapsed((v) => !v), []);

  return (
    <Ctx.Provider value={{ collapsed, toggle, setCollapsed }}>
      {children}
    </Ctx.Provider>
  );
}

export function useSidebar(): SidebarCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error("useSidebar must be used inside SidebarProvider");
  return v;
}
