"use client";

import { useEffect, useRef, useState } from "react";
import { GripVertical, RotateCcw, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DEFAULT_SECTIONS,
  useDashboardPrefs,
  type DashboardSectionId,
} from "@/components/dashboard-prefs";

// Gear button + popover. Inside the popover the operator can:
//   - Toggle each section visible / hidden (checkbox per row)
//   - Drag rows to reorder (HTML5 DnD — no library; the list is short).
//   - Reset to defaults.
//
// State lives in `useDashboardPrefs`, which is the same hook the page
// reads; both surfaces are reading the same singleton via localStorage.
export function DashboardCustomizer() {
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);
  const { prefs, isHidden, toggle, move, reset } = useDashboardPrefs();

  // Close on outside click / Escape.
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown",   onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown",   onKey);
    };
  }, [open]);

  // DnD state: index of the row being dragged, and the row currently being
  // hovered over. We only commit the move on dragend so partial drags
  // don't churn the saved order.
  const dragIdx = useRef<number | null>(null);
  const [overIdx, setOverIdx] = useState<number | null>(null);

  const onDragStart = (i: number) => () => { dragIdx.current = i; };
  const onDragOver  = (i: number) => (e: React.DragEvent) => {
    e.preventDefault();   // required to allow drop
    if (dragIdx.current !== null && dragIdx.current !== i) setOverIdx(i);
  };
  const onDrop = (i: number) => (e: React.DragEvent) => {
    e.preventDefault();
    if (dragIdx.current !== null && dragIdx.current !== i) {
      move(dragIdx.current, i);
    }
    dragIdx.current = null;
    setOverIdx(null);
  };
  const onDragEnd = () => { dragIdx.current = null; setOverIdx(null); };

  // Rows render in the *current* saved order (not the default order) so
  // the operator's drag-reorder is visible inside the popover too.
  const rows: { id: DashboardSectionId; label: string }[] = prefs.order
    .map((id) => DEFAULT_SECTIONS.find((s) => s.id === id))
    .filter((m): m is { id: DashboardSectionId; label: string } => !!m);

  return (
    <div ref={wrap} className="relative">
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="menu"
      >
        <Settings className="mr-1.5 h-3.5 w-3.5" />
        Customize
      </Button>

      {open && (
        <div
          role="menu"
          className="absolute right-0 top-[calc(100%+8px)] z-40 w-80 overflow-hidden rounded-md border border-border bg-card shadow-lg"
        >
          <div className="border-b border-border px-4 py-2.5">
            <div className="text-[13px] font-semibold">Dashboard layout</div>
            <div className="text-[11px] text-muted-foreground">
              Drag to reorder · toggle to show / hide. Saved to your browser.
            </div>
          </div>

          <ul className="max-h-[60vh] overflow-y-auto py-1.5">
            {rows.map((row, i) => {
              const enabled = !isHidden(row.id);
              const isOver  = overIdx === i;
              return (
                <li
                  key={row.id}
                  draggable
                  onDragStart={onDragStart(i)}
                  onDragOver={onDragOver(i)}
                  onDrop={onDrop(i)}
                  onDragEnd={onDragEnd}
                  className={
                    "flex items-center gap-2 px-3 py-1.5 text-sm cursor-grab active:cursor-grabbing " +
                    (isOver ? "bg-secondary " : "hover:bg-secondary/60 ") +
                    "transition-colors"
                  }
                >
                  <GripVertical className="h-3.5 w-3.5 text-muted-foreground" aria-hidden />
                  <span className="flex-1 select-none">{row.label}</span>
                  <label className="inline-flex items-center gap-2 select-none">
                    <input
                      type="checkbox"
                      checked={enabled}
                      onChange={() => toggle(row.id)}
                      className="h-3.5 w-3.5 accent-[hsl(var(--accent))]"
                    />
                  </label>
                </li>
              );
            })}
          </ul>

          <div className="flex items-center justify-between border-t border-border px-3 py-2">
            <button
              onClick={reset}
              className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground"
            >
              <RotateCcw className="h-3 w-3" />
              Reset to default
            </button>
            <button
              onClick={() => setOpen(false)}
              className="text-[11px] text-muted-foreground hover:text-foreground"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
