"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronRight } from "lucide-react";

// Pretty labels for known top-level routes; pathname segments not listed
// here are still rendered, just title-cased.
const PRETTY: Record<string, string> = {
  "":              "Home",
  "teams":         "Teams",
  "keys":          "API Keys",
  "connect":       "Connect",
  "elevations":    "JIT Elevations",
  "policies":      "Policies",
  "guardrails":    "Guardrails",
  "audit":         "Audit Log",
  "reveal-requests": "Reveal Queue",
  "monitoring":    "UEBA",
  "metrics":       "Metrics",
  "observability": "Observability",
  "plugins":       "Plugins",
  "router":        "Smart Router",
  "settings":      "Models",
};

function pretty(seg: string): string {
  if (PRETTY[seg] !== undefined) return PRETTY[seg];
  // Fall-back: title-case "some-thing" -> "Some Thing"
  return seg
    .split(/[-_]/)
    .filter(Boolean)
    .map((p) => p[0]?.toUpperCase() + p.slice(1))
    .join(" ");
}

// Build a breadcrumb trail from the current pathname. The first entry is
// always "Home" linking to /. Each segment in between is its own link.
export function Breadcrumb() {
  const pathname = usePathname() || "/";

  // /audit/reveal-requests -> ["audit", "reveal-requests"]
  const segs = pathname.split("/").filter(Boolean);

  if (segs.length === 0) {
    // On the home route, the breadcrumb is just "Home" — render it for
    // visual consistency rather than hiding the strip entirely.
    return (
      <nav aria-label="Breadcrumb" className="breadcrumb">
        <span className="current">Home</span>
      </nav>
    );
  }

  // Build progressive hrefs: ["/audit", "/audit/reveal-requests"]
  const trail: { label: string; href: string }[] = [];
  segs.forEach((seg, i) => {
    trail.push({
      label: pretty(seg),
      href:  "/" + segs.slice(0, i + 1).join("/"),
    });
  });

  return (
    <nav aria-label="Breadcrumb" className="breadcrumb">
      <Link href="/">Home</Link>
      {trail.map((t, i) => {
        const last = i === trail.length - 1;
        return (
          <span key={t.href} className="inline-flex items-center gap-1.5">
            <ChevronRight className="h-3 w-3 opacity-50" aria-hidden />
            {last
              ? <span className="current">{t.label}</span>
              : <Link href={t.href}>{t.label}</Link>}
          </span>
        );
      })}
    </nav>
  );
}
