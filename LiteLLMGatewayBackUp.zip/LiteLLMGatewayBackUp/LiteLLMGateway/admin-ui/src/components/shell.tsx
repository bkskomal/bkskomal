"use client";

import { usePathname } from "next/navigation";
import { Header } from "@/components/header";
import { Nav } from "@/components/nav";
import { SidebarProvider } from "@/components/sidebar-context";

/**
 * Top-level chrome.
 *
 * Hides the sidebar + header on /login so the auth screen stands alone.
 * Everywhere else: sticky sidebar on the left, sticky top header on the
 * right column, page content scrolls inside main.
 *
 * SidebarProvider lifts the sidebar's collapsed/expanded state up to a
 * context so the header's hamburger toggle and the Nav share one source
 * of truth; persisted to localStorage.
 */
export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isLogin = pathname?.startsWith("/login");

  if (isLogin) {
    return <main className="min-h-screen">{children}</main>;
  }

  return (
    <SidebarProvider>
      <div className="app-backdrop relative flex min-h-screen">
        <Nav />
        <div className="relative z-10 flex min-h-screen flex-1 flex-col">
          <Header />
          <main className="flex-1 px-5 py-5 lg:px-6">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
