"use client";

import { useEffect, useState } from "react";

// Global "cost / spend metrics visible" flag. Backed by the
// /admin/settings/spend-by-model toggle on the gateway. When this returns
// false, the UI hides every dollar amount, cost-per-token, cost-share
// table column, and the Spend-by-model card. The data is still computed
// server-side (for billing reconciliation) — the toggle is purely a
// visibility gate for the operator-facing UI.

const ENDPOINT = "/api/gateway/admin/settings/spend-by-model";

// Module-level cache so multiple consumers on the same page don't all
// fetch. First hook subscribes and triggers the fetch; subsequent hooks
// hydrate from cache and listen for updates.
let cached: boolean | null = null;
let fetchInflight: Promise<boolean> | null = null;
const subscribers = new Set<(v: boolean) => void>();

async function loadOnce(): Promise<boolean> {
  if (fetchInflight) return fetchInflight;
  fetchInflight = (async () => {
    try {
      const r = await fetch(ENDPOINT, { credentials: "same-origin", cache: "no-store" });
      if (!r.ok) return false;
      const j = await r.json() as { enabled?: boolean };
      const v = !!j.enabled;
      cached = v;
      subscribers.forEach((s) => s(v));
      return v;
    } catch {
      cached = false;
      return false;
    } finally {
      // Leave `cached` set; release the inflight handle so a manual
      // refresh can re-fetch.
      fetchInflight = null;
    }
  })();
  return fetchInflight;
}

/** Notify other consumers when the toggle changes from a setter UI. */
export function setCostVisible(v: boolean): void {
  cached = v;
  subscribers.forEach((s) => s(v));
}

/** Force a re-fetch (e.g. after an unrelated config change). */
export async function refreshCostVisible(): Promise<boolean> {
  cached = null;
  fetchInflight = null;
  return loadOnce();
}

/**
 * `useCostVisible()` — returns `boolean | null` (null while loading).
 *
 * Components that read this should *render the page* even while null so
 * the rest of the layout doesn't flash; just don't render the money cells
 * yet. When `false`, hide all cost/dollar UI.
 */
export function useCostVisible(): boolean | null {
  const [v, setV] = useState<boolean | null>(cached);

  useEffect(() => {
    let alive = true;
    const sub = (val: boolean) => { if (alive) setV(val); };
    subscribers.add(sub);

    if (cached === null) {
      void loadOnce().then((val) => { if (alive) setV(val); });
    } else {
      setV(cached);
    }
    return () => { alive = false; subscribers.delete(sub); };
  }, []);

  return v;
}
