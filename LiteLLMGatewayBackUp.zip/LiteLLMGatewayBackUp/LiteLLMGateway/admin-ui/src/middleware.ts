/**
 * Auth gate.
 *
 *   Unauthenticated request to any page    → 302 /login?next=<original>
 *   Unauthenticated request to /api/gateway → 401 JSON (browser fetch path)
 *   Unauthenticated request to /api/auth/* → pass through (login itself
 *                                            doesn't require a session)
 *
 * Verifies the HMAC-signed session cookie without going to the DB; rejected
 * cookies are treated as absent (no info leak).
 */

import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken, COOKIE_NAME } from "@/lib/session";

const PUBLIC_PATHS = [
  "/login",
  "/api/auth/login",
  "/api/auth/logout",
  "/api/auth/me",
  "/_next",
  "/favicon.ico",
  // Static assets referenced from the unauthenticated /login page must be
  // reachable without a session, or they'll redirect-bounce and show as
  // broken images. Add new public-page assets to this list.
  "/oati-logo.png",
];

export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;

  if (PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p + "/") || pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const token = req.cookies.get(COOKIE_NAME)?.value;
  const session = token ? verifySessionToken(token) : null;

  if (session) return NextResponse.next();

  // /api/gateway/* is the BFF proxy — return a JSON 401 instead of redirect.
  if (pathname.startsWith("/api/gateway")) {
    return new NextResponse(
      JSON.stringify({ error: "Unauthorised" }),
      { status: 401, headers: { "content-type": "application/json" } },
    );
  }

  const loginUrl = req.nextUrl.clone();
  loginUrl.pathname = "/login";
  loginUrl.search = `?next=${encodeURIComponent(pathname + search)}`;
  return NextResponse.redirect(loginUrl);
}

// Middleware verifies the HMAC-signed cookie using Node's crypto module, so
// it must run on the Node runtime — Edge Runtime doesn't expose `node:crypto`.
export const runtime = "nodejs";

export const config = {
  // Run on every request except internal Next.js assets.
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
