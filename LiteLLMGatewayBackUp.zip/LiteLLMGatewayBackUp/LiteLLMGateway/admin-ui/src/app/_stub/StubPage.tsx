import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function StubPage({
  title, description, sprint, planned,
}: {
  title: string;
  description: string;
  sprint: "S1" | "S2" | "S3" | "S4" | "Ops";
  planned: string[];
}) {
  const sprintColor: Record<string, "default" | "destructive" | "warning" | "success" | "secondary" | "accent"> = {
    S1: "default", S2: "destructive", S3: "warning", S4: "success", Ops: "secondary",
  };
  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">{title}</h1>
          <p className="text-muted-foreground">{description}</p>
        </div>
        <Badge variant={sprintColor[sprint]} className="px-3 py-1">
          {sprint} — planned
        </Badge>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Planned scope</CardTitle>
          <CardDescription>
            Features arriving in sprint {sprint}. Backend foundation already supports them
            via the plugin contract — this UI surface is the next vertical slice.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {planned.map((p) => (
              <li key={p} className="flex items-start gap-2 text-sm">
                <span className="mt-1.5 inline-block h-1.5 w-1.5 rounded-full bg-oati-accent" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
