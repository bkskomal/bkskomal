"use client";

import Link from "next/link";
import { Fragment, useCallback, useEffect, useState } from "react";
import { ChevronRight, Download, KeyRound, RefreshCw, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

type RevealStatus = "pending" | "approved" | "denied" | "revealed" | "expired";

type RevealItem = {
  id: number;
  audit_log_id: number;
  requested_by: string;
  requested_email: string | null;
  reason: string;
  status: RevealStatus;
  requested_at: string;
  decided_at: string | null;
  expires_at: string | null;
  revealed_at: string | null;
  approver_user_id: string | null;
  decision_note: string | null;
};

type RevealPayload = {
  request: RevealItem;
  plaintext: { prompt: string | null; response: string | null };
};

type AuditEntry = {
  id: number;
  ts: string;
  request_id: string;
  trace_id: string | null;
  user_id: string;
  user_email: string | null;
  team_id: string;
  tier: string;
  base_tier: string | null;
  elevation_id: number | null;
  model_requested: string | null;
  model_used: string | null;
  routing_reason: string | null;
  tokens_in: number;
  tokens_out: number;
  latency_ms: number;
  cost_usd: number;
  prompt_hash: string | null;
  response_hash: string | null;
  verdict: string;
  findings: Array<{ plugin: string; kind: string; severity: string; message?: string }> | null;
  client_ip: string | null;
  user_agent: string | null;
};

type SearchResponse = {
  rows: AuditEntry[];
  next_cursor: number | null;
};

type Filters = {
  user_id:    string;
  team_id:    string;
  model_used: string;
  verdict:    string;
  trace_id:   string;
  since:      string;     // datetime-local input ("YYYY-MM-DDTHH:mm")
  until:      string;
};

const EMPTY_FILTERS: Filters = {
  user_id: "", team_id: "", model_used: "", verdict: "", trace_id: "",
  since: "", until: "",
};

const VERDICT_VARIANT: Record<string, "default" | "destructive" | "warning" | "success" | "accent" | "secondary"> = {
  allow:   "success",
  refused: "destructive",
  error:   "warning",
};

const GW = "/api/gateway";

// Build the search query string from non-empty filters + cursor/limit.
function buildQuery(f: Filters, limit: number, beforeId: number | null): string {
  const p = new URLSearchParams();
  if (f.user_id.trim())    p.set("user_id",    f.user_id.trim());
  if (f.team_id.trim())    p.set("team_id",    f.team_id.trim());
  if (f.model_used.trim()) p.set("model_used", f.model_used.trim());
  if (f.verdict.trim())    p.set("verdict",    f.verdict.trim());
  if (f.trace_id.trim())   p.set("trace_id",   f.trace_id.trim());
  // datetime-local emits "YYYY-MM-DDTHH:mm" without timezone — append :00Z so
  // FastAPI's datetime parser treats it as UTC. Users see times in their
  // local TZ but search bounds are UTC, which matches how ts is stored.
  if (f.since) p.set("since", `${f.since}:00Z`);
  if (f.until) p.set("until", `${f.until}:00Z`);
  p.set("limit", String(limit));
  if (beforeId !== null) p.set("before_id", String(beforeId));
  return p.toString();
}

export default function AuditPage() {
  const [filters, setFilters]     = useState<Filters>(EMPTY_FILTERS);
  const [rows, setRows]           = useState<AuditEntry[]>([]);
  const [nextCursor, setCursor]   = useState<number | null>(null);
  const [loading, setLoading]     = useState(false);
  const [err, setErr]             = useState<string | null>(null);
  const [expandedId, setExpanded] = useState<number | null>(null);

  // Replace (not append) the current result set — used on first search and
  // filter change. Pagination uses appendNext below.
  const runSearch = useCallback(async (f: Filters) => {
    setLoading(true);
    setErr(null);
    try {
      const qs = buildQuery(f, 50, null);
      const r = await fetch(`${GW}/admin/audit/search?${qs}`, {
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const body = (await r.json()) as SearchResponse;
      setRows(body.rows);
      setCursor(body.next_cursor);
      setExpanded(null);
    } catch (e) {
      setErr(String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  const appendNext = useCallback(async () => {
    if (nextCursor === null) return;
    setLoading(true);
    try {
      const qs = buildQuery(filters, 50, nextCursor);
      const r = await fetch(`${GW}/admin/audit/search?${qs}`, {
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const body = (await r.json()) as SearchResponse;
      setRows((prev) => [...prev, ...body.rows]);
      setCursor(body.next_cursor);
    } catch (e) {
      setErr(String(e));
    } finally {
      setLoading(false);
    }
  }, [filters, nextCursor]);

  // Initial load — show the most recent traffic.
  useEffect(() => { void runSearch(EMPTY_FILTERS); }, [runSearch]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void runSearch(filters);
  };

  const onReset = () => {
    setFilters(EMPTY_FILTERS);
    void runSearch(EMPTY_FILTERS);
  };

  // Click a trace-id badge on any row → pivot the page to that one trace.
  // The badge truncates the value but the search runs against the full id.
  const filterByTrace = (tid: string) => {
    const next = { ...filters, trace_id: tid };
    setFilters(next);
    void runSearch(next);
  };
  const clearTrace = () => {
    const next = { ...filters, trace_id: "" };
    setFilters(next);
    void runSearch(next);
  };

  // CSV export — applies the SAME filters as the on-screen search.
  // The gateway caps at 5000 rows server-side; we trust the server to
  // attach a Content-Disposition filename and just stream it to the user.
  const exportCsv = async () => {
    setLoading(true);
    setErr(null);
    try {
      const qs = buildQuery(filters, 5000, null);
      const r = await fetch(`${GW}/admin/audit/search.csv?${qs}`, {
        credentials: "same-origin",
        cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      // Pull the filename from Content-Disposition so the gateway owns it.
      const cd = r.headers.get("Content-Disposition") || "";
      const m  = /filename="([^"]+)"/.exec(cd);
      const filename = m?.[1] ?? "audit.csv";

      const blob = await r.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      setErr(String(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Audit Log</h1>
          <p className="text-muted-foreground">
            Every gateway call, hash-only. Plaintext access requires a separate 4-eyes flow.
          </p>
        </div>
        <Badge variant="accent" className="px-3 py-1">S3 — live</Badge>
      </div>

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">Error: {err}</CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Search</CardTitle>
          <CardDescription>
            Filters use exact matches on the audit row. Time ranges are interpreted as UTC.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="grid gap-3 md:grid-cols-3 lg:grid-cols-6">
            <FilterField label="User ID" value={filters.user_id}
              onChange={(v) => setFilters({ ...filters, user_id: v })}
              placeholder="alice" />
            <FilterField label="Team ID" value={filters.team_id}
              onChange={(v) => setFilters({ ...filters, team_id: v })}
              placeholder="backend-engineering" />
            <FilterField label="Model" value={filters.model_used}
              onChange={(v) => setFilters({ ...filters, model_used: v })}
              placeholder="kimi-k2.6" />
            <FilterField label="Trace ID" value={filters.trace_id}
              onChange={(v) => setFilters({ ...filters, trace_id: v })}
              placeholder="trace-abc-123" />
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Verdict
              </label>
              <select
                value={filters.verdict}
                onChange={(e) => setFilters({ ...filters, verdict: e.target.value })}
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
              >
                <option value="">any</option>
                <option value="allow">allow</option>
                <option value="refused">refused</option>
                <option value="error">error</option>
              </select>
            </div>
            <FilterField label="Since (UTC)" value={filters.since} type="datetime-local"
              onChange={(v) => setFilters({ ...filters, since: v })} />
            <FilterField label="Until (UTC)" value={filters.until} type="datetime-local"
              onChange={(v) => setFilters({ ...filters, until: v })} />
            <div className="md:col-span-3 lg:col-span-6 flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={onReset} disabled={loading}>
                Reset
              </Button>
              <Button type="button" variant="secondary" onClick={exportCsv}
                      disabled={loading} title="Export current filter to CSV (max 5000 rows)">
                <Download className="mr-1 h-4 w-4" />
                Export CSV
              </Button>
              <Button type="submit" variant="accent" disabled={loading}>
                {loading ? <RefreshCw className="mr-1 h-4 w-4 animate-spin" /> : <Search className="mr-1 h-4 w-4" />}
                Search
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {filters.trace_id.trim() !== "" && (
        <Card className="border-accent bg-accent/10">
          <CardContent className="flex items-center justify-between gap-3 p-3 text-sm">
            <div>
              Showing trace <span className="font-mono">{filters.trace_id.trim()}</span>
            </div>
            <Button type="button" variant="ghost" size="sm" onClick={clearTrace}>
              Show all
            </Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Results</CardTitle>
          <CardDescription>
            {rows.length === 0
              ? "No rows match — try widening the filters."
              : `${rows.length} row${rows.length === 1 ? "" : "s"}${nextCursor !== null ? " (more available)" : ""}`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {rows.length > 0 && (
            <Table>
              <THead>
                <TR>
                  <TH className="w-8"></TH>
                  <TH>Time (UTC)</TH>
                  <TH>User</TH>
                  <TH>Team</TH>
                  <TH>Tier</TH>
                  <TH>Model</TH>
                  <TH>Trace</TH>
                  <TH>Verdict</TH>
                  <TH className="text-right">Tokens (in / out)</TH>
                  <TH className="text-right">Latency (ms)</TH>
                  <TH className="text-right">Cost ($)</TH>
                </TR>
              </THead>
              <TBody>
                {rows.map((row) => {
                  const open = expandedId === row.id;
                  return (
                    <Fragment key={row.id}>
                      <TR
                        className="cursor-pointer hover:bg-muted/40"
                        onClick={() => setExpanded(open ? null : row.id)}
                      >
                        <TD>
                          <ChevronRight
                            className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${open ? "rotate-90" : ""}`}
                          />
                        </TD>
                        <TD className="text-xs whitespace-nowrap">
                          {new Date(row.ts).toISOString().replace("T", " ").slice(0, 19)}
                        </TD>
                        <TD className="font-mono text-xs">{row.user_id}</TD>
                        <TD className="font-mono text-xs">{row.team_id}</TD>
                        <TD className="text-xs">
                          {row.tier}
                          {row.elevation_id !== null && (
                            <Badge variant="accent" className="ml-1 px-1 py-0 text-[10px]">elev</Badge>
                          )}
                        </TD>
                        <TD className="text-xs">{row.model_used ?? "—"}</TD>
                        <TD>
                          {row.trace_id ? (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                filterByTrace(row.trace_id as string);
                              }}
                              title={row.trace_id}
                              className="font-mono text-[11px] rounded bg-muted px-1.5 py-0.5 hover:bg-accent hover:text-accent-foreground"
                            >
                              {row.trace_id.slice(0, 8)}
                            </button>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </TD>
                        <TD>
                          <Badge variant={VERDICT_VARIANT[row.verdict] ?? "secondary"}>
                            {row.verdict}
                          </Badge>
                        </TD>
                        <TD className="text-right text-xs font-mono">
                          {row.tokens_in} / {row.tokens_out}
                        </TD>
                        <TD className="text-right text-xs font-mono">
                          {row.latency_ms.toFixed(1)}
                        </TD>
                        <TD className="text-right text-xs font-mono">
                          {row.cost_usd.toFixed(4)}
                        </TD>
                      </TR>
                      {open && (
                        <TR>
                          <TD colSpan={11} className="bg-muted/30">
                            <DetailPanel row={row} />
                          </TD>
                        </TR>
                      )}
                    </Fragment>
                  );
                })}
              </TBody>
            </Table>
          )}

          {nextCursor !== null && (
            <div className="mt-4 flex justify-center">
              <Button variant="ghost" onClick={appendNext} disabled={loading}>
                {loading ? "Loading…" : "Load more"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function FilterField({
  label, value, onChange, placeholder, type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div className="space-y-1">
      <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </label>
      <Input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}

function DetailPanel({ row }: { row: AuditEntry }) {
  // Raw-access (4-eyes) state. Backed by the real reveal-request API:
  //   POST   /admin/audit/{id}/reveal-requests
  //   GET    /admin/audit/reveal-requests?requested_by=<me>&status=approved
  //   GET    /admin/audit/reveal-requests/{request_id}/reveal
  const [showForm, setShowForm]     = useState(false);
  const [reason, setReason]         = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [opened, setOpened]         = useState<RevealItem | null>(null);
  const [approved, setApproved]     = useState<RevealItem | null>(null);
  const [plaintext, setPlaintext]   = useState<RevealPayload | null>(null);
  const [revealing, setRevealing]   = useState(false);
  const [rawErr, setRawErr]         = useState<string | null>(null);
  const [me, setMe]                 = useState<string | null>(null);

  // Identify the operator so we can find an existing approved request for
  // this audit row by the SAME user (the gateway only lets the requester
  // pull plaintext, so we must look up by requested_by=me).
  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store", credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setMe(d?.user ?? null))
      .catch(() => setMe(null));
  }, []);

  // Look up an existing APPROVED reveal request for this audit row by the
  // current user — gives them a one-click "show plaintext" if a peer has
  // already approved it.
  const refreshApproved = useCallback(async () => {
    if (!me) return;
    try {
      const qs = new URLSearchParams({
        requested_by: me, status: "approved", limit: "100",
      }).toString();
      const r = await fetch(`${GW}/admin/audit/reveal-requests?${qs}`, {
        credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) return;
      const items = (await r.json()) as RevealItem[];
      const match = items.find((it) => it.audit_log_id === row.id) ?? null;
      setApproved(match);
    } catch {
      /* non-fatal */
    }
  }, [me, row.id]);

  useEffect(() => { void refreshApproved(); }, [refreshApproved]);

  const resetRawAccess = () => {
    setShowForm(false);
    setReason("");
    setOpened(null);
    setRawErr(null);
  };

  const submitRequest = async () => {
    if (!reason.trim()) return;
    setSubmitting(true);
    setRawErr(null);
    try {
      const r = await fetch(`${GW}/admin/audit/${row.id}/reveal-requests`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ reason: reason.trim() }),
      });
      if (!r.ok) {
        const body = await r.json().catch(() => ({}));
        const detail = typeof body?.detail === "string" ? body.detail : `${r.status} ${r.statusText}`;
        throw new Error(detail);
      }
      const item = (await r.json()) as RevealItem;
      setOpened(item);
      setShowForm(false);
      setReason("");
    } catch (e) {
      setRawErr(String(e));
    } finally {
      setSubmitting(false);
    }
  };

  const fetchPlaintext = async (req: RevealItem) => {
    setRevealing(true);
    setRawErr(null);
    try {
      const r = await fetch(`${GW}/admin/audit/reveal-requests/${req.id}/reveal`, {
        credentials: "same-origin", cache: "no-store",
      });
      if (r.status === 503) {
        throw new Error(
          "Plaintext encryption is not configured on this gateway. Set " +
          "GATEWAY_AUDIT_KEY (32 random bytes, base64) and restart to enable " +
          "the 4-eyes reveal flow.",
        );
      }
      if (!r.ok) {
        const body = await r.json().catch(() => ({}));
        const detail = typeof body?.detail === "string" ? body.detail : `${r.status} ${r.statusText}`;
        throw new Error(detail);
      }
      const payload = (await r.json()) as RevealPayload;
      setPlaintext(payload);
      // The reveal endpoint flips the request to "revealed" — pick that up
      // so the UI shows "Revealed at <ts>" and hides the button.
      setApproved(payload.request);
    } catch (e) {
      setRawErr(String(e));
    } finally {
      setRevealing(false);
    }
  };

  return (
    <div className="grid gap-3 p-2 text-xs md:grid-cols-2">
      <KV label="Request ID"      value={row.request_id} mono />
      <KV label="User Email"      value={row.user_email ?? "—"} />
      <KV label="Base Tier"       value={row.base_tier ?? "—"} />
      <KV label="Elevation ID"    value={row.elevation_id !== null ? String(row.elevation_id) : "—"} />
      <KV label="Model Requested" value={row.model_requested ?? "—"} />
      <KV label="Routing Reason"  value={row.routing_reason ?? "—"} />
      <KV label="Client IP"       value={row.client_ip ?? "—"} mono />
      <KV label="User Agent"      value={row.user_agent ?? "—"} />
      <KV label="Prompt Hash"     value={row.prompt_hash ?? "—"} mono full />
      <KV label="Response Hash"   value={row.response_hash ?? "—"} mono full />
      {row.findings && row.findings.length > 0 && (
        <div className="md:col-span-2">
          <div className="mb-1 font-medium uppercase tracking-wide text-muted-foreground">
            Findings ({row.findings.length})
          </div>
          <Table>
            <THead>
              <TR>
                <TH>Plugin</TH><TH>Kind</TH><TH>Severity</TH><TH>Message</TH>
              </TR>
            </THead>
            <TBody>
              {row.findings.map((f, i) => (
                <TR key={i}>
                  <TD className="font-mono">{f.plugin}</TD>
                  <TD className="font-mono">{f.kind}</TD>
                  <TD>
                    <Badge variant={f.severity === "critical" || f.severity === "high" ? "destructive" : "warning"}>
                      {f.severity}
                    </Badge>
                  </TD>
                  <TD className="text-muted-foreground">{f.message ?? ""}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </div>
      )}

      {/* Raw access (4-eyes) — wired to /admin/audit/{id}/reveal-requests. */}
      <div className="md:col-span-2 border-t border-border/60 pt-4 mt-4 space-y-3">
        <div className="font-medium uppercase tracking-wide text-muted-foreground">
          Raw access (4-eyes)
        </div>
        <p className="text-muted-foreground">
          Plaintext prompt + response are encrypted at rest with AES-GCM. Two
          distinct admins must approve a reveal — the requester opens a reveal
          request; a peer admin approves; the plaintext is then time-limited
          (15 min default) and downloaded once.
        </p>

        {rawErr && (
          <Card className="border-destructive">
            <CardContent className="p-3 text-xs text-destructive">{rawErr}</CardContent>
          </Card>
        )}

        {/* Existing approved request: one-click reveal. Once revealed the row
            is terminal (status=revealed) so we hide the button and show the
            timestamp instead. */}
        {approved && (
          <Card className="border-oati-success/60 bg-card/40">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div className="text-xs">
                  <div className="font-medium text-foreground">
                    Approved reveal request #{approved.id}
                  </div>
                  <div className="text-muted-foreground">
                    Approved by{" "}
                    <span className="font-mono">{approved.approver_user_id ?? "—"}</span>
                    {approved.expires_at && approved.status === "approved" && (
                      <> · expires {new Date(approved.expires_at).toLocaleString()}</>
                    )}
                    {approved.revealed_at && (
                      <> · revealed at {new Date(approved.revealed_at).toLocaleString()}</>
                    )}
                  </div>
                </div>
                {approved.status === "approved" && !plaintext && (
                  <Button
                    variant="default"
                    size="sm"
                    className="bg-oati-success/20 text-oati-success hover:bg-oati-success/30"
                    onClick={() => fetchPlaintext(approved)}
                    disabled={revealing}
                  >
                    <KeyRound className="mr-1 h-3.5 w-3.5" />
                    {revealing ? "Revealing…" : "Approved — show plaintext"}
                  </Button>
                )}
              </div>

              {plaintext && (
                <div className="space-y-3">
                  <PlaintextBlock label="Prompt"   value={plaintext.plaintext.prompt} />
                  <PlaintextBlock label="Response" value={plaintext.plaintext.response} />
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Open-a-new-request flow. Hidden once we have an approved one. */}
        {!approved && !opened && !showForm && (
          <Button variant="accent" onClick={() => setShowForm(true)}>
            Request raw access
          </Button>
        )}

        {!approved && showForm && (
          <Card className="border-border bg-card/40">
            <CardContent className="p-4 space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Reason for request
                </label>
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value.slice(0, 1024))}
                  placeholder="Incident IR-1234 — need plaintext to confirm prompt-injection payload."
                  maxLength={1024}
                  required
                  rows={3}
                  className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                />
                <div className="text-right text-[10px] text-muted-foreground">
                  {reason.length} / 1024
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="ghost" onClick={resetRawAccess} disabled={submitting}>
                  Cancel
                </Button>
                <Button
                  type="button"
                  variant="accent"
                  disabled={reason.trim().length === 0 || submitting}
                  onClick={submitRequest}
                >
                  {submitting ? "Submitting…" : "Submit request"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {opened && !approved && (
          <Card className="border-accent">
            <CardContent className="p-4 space-y-2">
              <div className="text-foreground font-medium">
                Request opened — waiting for a peer admin to approve. ID #{opened.id}
              </div>
              <p className="text-xs text-muted-foreground">
                A second admin must approve before plaintext can be retrieved.
                You can track decisions on the{" "}
                <Link
                  href="/audit/reveal-requests"
                  className="text-accent-foreground underline underline-offset-2 hover:text-accent"
                >
                  reveal queue
                </Link>
                . After approval, return here and click "Approved — show plaintext".
              </p>
              <div className="flex justify-end">
                <Button type="button" variant="ghost" size="sm" onClick={resetRawAccess}>
                  Dismiss
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function PlaintextBlock({ label, value }: { label: string; value: string | null }) {
  return (
    <div className="space-y-1">
      <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <pre className="max-h-72 overflow-auto rounded-md border border-border/60 bg-background/60 p-3 text-xs font-mono whitespace-pre-wrap break-words">
        {value ?? "(none)"}
      </pre>
    </div>
  );
}

function KV({ label, value, mono = false, full = false }: {
  label: string; value: string; mono?: boolean; full?: boolean;
}) {
  return (
    <div className={full ? "md:col-span-2" : ""}>
      <div className="font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={mono ? "font-mono break-all" : ""}>{value}</div>
    </div>
  );
}
