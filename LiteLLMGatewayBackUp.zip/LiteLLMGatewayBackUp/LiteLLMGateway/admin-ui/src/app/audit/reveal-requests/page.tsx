"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { CheckCircle2, KeyRound, RefreshCw, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

type RevealStatus = "pending" | "approved" | "denied" | "revealed" | "expired";

type RevealItem = {
  id: number;
  audit_log_id: number;
  requested_by: string;
  requested_email: string | null;
  reason: string;
  status: RevealStatus;
  requested_at: string;
  decided_at: string | null;
  expires_at: string | null;
  revealed_at: string | null;
  approver_user_id: string | null;
  decision_note: string | null;
};

type FilterChip = RevealStatus | "all";

const FILTER_CHIPS: FilterChip[] = ["pending", "approved", "denied", "revealed", "expired", "all"];

const STATUS_VARIANT: Record<RevealStatus, "default" | "destructive" | "warning" | "success" | "accent" | "secondary"> = {
  pending:  "warning",
  approved: "accent",
  denied:   "secondary",
  revealed: "success",
  expired:  "secondary",
};

const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };
const GW = "/api/gateway";

// Auto-refresh cadence — short enough that a peer-admin sees fresh decisions
// without manual reload, long enough not to hammer the gateway. Mirrors the
// 15s used elsewhere in the operate section.
const REFRESH_MS = 15_000;

// Render an ISO timestamp as a relative phrase ("3m ago"), with a tooltip
// carrying the absolute local time. Cheap, no deps.
function relTime(iso: string): { rel: string; abs: string } {
  const t = new Date(iso).getTime();
  const dSec = Math.max(0, Math.round((Date.now() - t) / 1000));
  let rel: string;
  if (dSec < 60)         rel = `${dSec}s ago`;
  else if (dSec < 3600)  rel = `${Math.round(dSec / 60)}m ago`;
  else if (dSec < 86400) rel = `${Math.round(dSec / 3600)}h ago`;
  else                   rel = `${Math.round(dSec / 86400)}d ago`;
  return { rel, abs: new Date(iso).toLocaleString() };
}

export default function RevealRequestsPage() {
  const [items, setItems]   = useState<RevealItem[] | null>(null);
  const [filter, setFilter] = useState<FilterChip>("pending");
  const [me, setMe]         = useState<string | null>(null);
  const [err, setErr]       = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Per-row inline decision-note state (key = request id) — same shape as
  // the elevations queue so the muscle memory matches.
  const [noteOpenFor, setNoteOpenFor] = useState<Record<string, "approve" | "deny" | null>>({});
  const [notes, setNotes]             = useState<Record<string, string>>({});
  const [busyId, setBusyId]           = useState<string | null>(null);

  const reload = useCallback(async (f: FilterChip) => {
    setLoading(true);
    try {
      const p = new URLSearchParams({ limit: "100" });
      if (f !== "all") p.set("status", f);
      const r = await fetch(`${GW}/admin/audit/reveal-requests?${p.toString()}`, {
        headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      setItems((await r.json()) as RevealItem[]);
      setErr(null);
    } catch (e) {
      setErr(String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  // Identify the current operator (used to disable self-approval).
  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store", credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setMe(d?.user ?? null))
      .catch(() => setMe(null));
  }, []);

  useEffect(() => { void reload(filter); }, [reload, filter]);

  // Auto-refresh — pause when the tab is hidden so we don't burn cycles in a
  // background tab. Re-runs whenever the filter changes via the deps.
  useEffect(() => {
    const tick = () => { if (!document.hidden) void reload(filter); };
    const id = window.setInterval(tick, REFRESH_MS);
    return () => window.clearInterval(id);
  }, [reload, filter]);

  const decide = async (item: RevealItem, action: "approve" | "deny") => {
    const id = String(item.id);
    setBusyId(id);
    try {
      const note = (notes[id] ?? "").trim();
      const r = await fetch(`${GW}/admin/audit/reveal-requests/${id}/${action}`, {
        method: "POST",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify(note ? { decision_note: note } : {}),
      });
      if (!r.ok) {
        const body = await r.json().catch(() => ({}));
        const detail = typeof body?.detail === "string"
          ? body.detail
          : `${r.status} ${r.statusText}`;
        throw new Error(detail);
      }
      // Optimistic: drop pending row from view if the active filter is
      // "pending" (no longer matches), otherwise fall through to the reload.
      setNotes((n) => { const c = { ...n }; delete c[id]; return c; });
      setNoteOpenFor((o) => ({ ...o, [id]: null }));
      await reload(filter);
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusyId(null);
    }
  };

  const counts = useMemo(() => {
    if (!items) return null;
    return `${items.length} row${items.length === 1 ? "" : "s"}`;
  }, [items]);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Audit reveal queue</h1>
          <p className="text-muted-foreground">
            4-eyes plaintext-reveal requests from other admins. Review, approve,
            or deny. The requester (not you) can fetch the decrypted plaintext
            after your approval, within a 15-minute window.
          </p>
        </div>
        <Badge variant="accent" className="px-3 py-1">
          <KeyRound className="mr-1 h-3 w-3" /> 4-eyes
        </Badge>
      </div>

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">Error: {err}</CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Reveal requests</CardTitle>
          <CardDescription>
            Auto-refreshes every 15s. Self-approval is blocked at the API and
            in the UI — your own requests need a peer to decide.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Status-filter chips */}
          <div className="flex flex-wrap items-center gap-2">
            {FILTER_CHIPS.map((c) => (
              <Button
                key={c}
                size="sm"
                variant={filter === c ? "accent" : "ghost"}
                onClick={() => setFilter(c)}
              >
                {c}
              </Button>
            ))}
            <div className="ml-auto flex items-center gap-2 text-xs text-muted-foreground">
              {loading && <RefreshCw className="h-3.5 w-3.5 animate-spin" />}
              {counts}
            </div>
          </div>

          {!items ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : items.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              {filter === "pending"
                ? "Nothing pending. The queue is clear."
                : `No ${filter} requests.`}
            </p>
          ) : (
            <Table>
              <THead>
                <TR>
                  <TH>Requested at</TH>
                  <TH>Requested by</TH>
                  <TH>Audit log</TH>
                  <TH>Reason</TH>
                  <TH>Status</TH>
                  <TH>Approver</TH>
                  <TH className="w-72 text-right">Actions</TH>
                </TR>
              </THead>
              <TBody>
                {items.map((it) => {
                  const id     = String(it.id);
                  const isSelf = !!me && (me === it.requested_by || me === it.requested_email);
                  const open   = noteOpenFor[id] ?? null;
                  const note   = notes[id] ?? "";
                  const busy   = busyId === id;
                  const t      = relTime(it.requested_at);
                  const isPending = it.status === "pending";

                  return (
                    <TR key={id}>
                      <TD className="text-xs text-muted-foreground" title={t.abs}>
                        {t.rel}
                      </TD>
                      <TD>
                        <div className="leading-tight">
                          <div className="font-mono text-xs">{it.requested_by}</div>
                          {it.requested_email && (
                            <div className="text-xs text-muted-foreground">{it.requested_email}</div>
                          )}
                        </div>
                      </TD>
                      <TD className="font-mono text-xs">
                        <Link
                          href={`/audit?id=${it.audit_log_id}`}
                          className="underline underline-offset-2 hover:text-foreground"
                        >
                          #{it.audit_log_id}
                        </Link>
                      </TD>
                      <TD className="max-w-xs">
                        <div className="line-clamp-2 text-sm" title={it.reason}>
                          {it.reason}
                        </div>
                        {it.decision_note && (
                          <div
                            className="mt-1 text-xs text-muted-foreground"
                            title={it.decision_note}
                          >
                            note: {it.decision_note}
                          </div>
                        )}
                      </TD>
                      <TD>
                        <Badge variant={STATUS_VARIANT[it.status]}>{it.status}</Badge>
                      </TD>
                      <TD className="font-mono text-xs">
                        {it.approver_user_id ?? "—"}
                      </TD>
                      <TD className="text-right">
                        {!isPending ? (
                          <span className="text-xs text-muted-foreground">—</span>
                        ) : open ? (
                          <div className="space-y-2">
                            <textarea
                              value={note}
                              onChange={(e) =>
                                setNotes((n) => ({ ...n, [id]: e.target.value.slice(0, 1024) }))
                              }
                              placeholder={
                                open === "approve"
                                  ? "Approval note (optional)"
                                  : "Reason for denial (optional)"
                              }
                              rows={2}
                              className="flex w-full rounded-md border border-input bg-background px-2 py-1 text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                            />
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => setNoteOpenFor((o) => ({ ...o, [id]: null }))}
                                disabled={busy}
                              >
                                Cancel
                              </Button>
                              <Button
                                size="sm"
                                variant={open === "approve" ? "accent" : "destructive"}
                                onClick={() => decide(it, open)}
                                disabled={busy}
                              >
                                {open === "approve" ? (
                                  <>
                                    <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Confirm approve
                                  </>
                                ) : (
                                  <>
                                    <XCircle className="mr-1 h-3.5 w-3.5" /> Confirm deny
                                  </>
                                )}
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-2">
                            {isSelf && (
                              <span
                                className="text-[10px] text-muted-foreground"
                                title="The 4-eyes rule: the requester cannot decide on their own request."
                              >
                                your request — peer must decide
                              </span>
                            )}
                            <Button
                              size="sm"
                              variant="accent"
                              disabled={isSelf || busy}
                              title={isSelf ? "self-approval blocked" : undefined}
                              onClick={() => setNoteOpenFor((o) => ({ ...o, [id]: "approve" }))}
                            >
                              <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              disabled={isSelf || busy}
                              title={isSelf ? "self-deny blocked" : undefined}
                              onClick={() => setNoteOpenFor((o) => ({ ...o, [id]: "deny" }))}
                            >
                              <XCircle className="mr-1 h-3.5 w-3.5" /> Deny
                            </Button>
                          </div>
                        )}
                      </TD>
                    </TR>
                  );
                })}
              </TBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
