"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, AlertTriangle, DollarSign, RefreshCw, ShieldAlert, TrendingUp, Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { InfoBox } from "@/components/ui/info-box";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { useCostVisible } from "@/components/cost-visibility";

// -------------------------------------------------------------------------
// API contract — mirrors the gateway endpoints verbatim. Keep these types
// the single source of truth for the page; the BFF is a transparent proxy.
// -------------------------------------------------------------------------

type DashboardSummary = {
  window_minutes:    number;
  generated_at:      string;
  request_count:     number;
  requests_per_min:  number;
  avg_latency_ms:    number;
  p99_latency_ms:    number;
  tokens_in_total:   number;
  tokens_out_total:  number;
  cost_usd_total:    number;
  verdict_counts:    Record<string, number>;
  dlp_findings:      number;
  secret_leaks:      number;
  top_models:        { model: string; count: number; tokens: number }[];
  top_teams:         { team:  string; count: number; tokens: number }[];
  timeseries:        { minutes_ago: number; count: number; refused: number }[];
};

type LatencyByModel = {
  model: string;
  count: number;
  avg_ms: number;
  p50_ms: number;
  p95_ms: number;
  p99_ms: number;
};

type SpendByTeam = {
  team_id: string;
  tier: string;
  tokens_in: number;
  tokens_out: number;
  tokens_total: number;
  cost_usd: number;
  daily_limit: number | null;
  pct_used: number;
};

type PluginError = {
  plugin: string;
  refused_count: number;
  last_refusal_at: string | null;
};

type FindingMix = { kind: string; count: number };

type MetricsDetails = {
  window_minutes:    number;
  generated_at:      string;
  latency_by_model:  LatencyByModel[];
  spend_by_team:     SpendByTeam[];
  plugin_errors:     PluginError[];
  finding_mix:       FindingMix[];
};

// Cost forecast — mirrors CostForecastResponse on the gateway.
// `by_team` / `by_model` items carry `share` (0..1) of the window cost; the
// per-row projected dollars are derived in the UI from share × projected_usd.
type CostForecastByTeam  = { team_id:    string; cost_usd: number; share: number };
type CostForecastByModel = { model_used: string; cost_usd: number; share: number };

type CostForecastResponse = {
  window_days:     number;
  cost_window_usd: number;
  cost_per_day:    number;
  projection_days: number;
  projected_usd:   number;
  by_team:         CostForecastByTeam[];
  by_model:        CostForecastByModel[];
  rows_considered: number;
  generated_at:    string;
};

// Spend ($USD/h) by model — mirrors SpendByModelResponse on the gateway.
// Toggled via /admin/settings/spend-by-model; when disabled the endpoint
// returns enabled=false with an empty body and no DB scan.
type SpendByModelRow = { model: string; cost_usd: number; usd_per_hour: number };
type SpendByModelResponse = {
  enabled:         boolean;
  window_minutes:  number;
  cost_total_usd:  number;
  by_model:        SpendByModelRow[];
  rows_considered: number;
  generated_at:    string;
};
type SpendToggle = { enabled: boolean };

// -------------------------------------------------------------------------
// Constants
// -------------------------------------------------------------------------

const GW = "/api/gateway";
const REFRESH_INTERVAL_MS = 15_000;

const WINDOW_OPTIONS: { label: string; minutes: number }[] = [
  { label: "15m", minutes: 15 },
  { label: "60m", minutes: 60 },
  { label: "6h",  minutes: 360 },
  { label: "24h", minutes: 1440 },
  { label: "7d",  minutes: 10080 },
];

// p99 latency above this draws a red tint on the cell; same threshold the
// SRE team uses as a "fast feedback" SLO for the gateway hop.
const P99_RED_MS = 5000;

// Refusal rate above this pulses the stat card red. 5% is the operator's
// "something is misconfigured" tripwire — DLP false positives, an upstream
// outage, or a broken plugin will all push above this.
const REFUSAL_RATE_PULSE_PCT = 5;

type BadgeVariant =
  | "default" | "secondary" | "destructive" | "outline"
  | "success" | "warning" | "accent";

// Tier chip colours — keep these in sync with the Tiers page vocabulary
// so an operator scanning across pages doesn't have to relearn meaning.
const TIER_VARIANT: Record<string, BadgeVariant> = {
  free:       "secondary",
  basic:      "default",
  standard:   "default",
  pro:        "accent",
  enterprise: "warning",
  internal:   "success",
};

// -------------------------------------------------------------------------
// Page
// -------------------------------------------------------------------------

export default function MetricsPage() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [details, setDetails] = useState<MetricsDetails | null>(null);
  const [windowMin, setWindowMin] = useState<number>(60);
  const [error, setError]   = useState<string | null>(null);
  const [refreshedAt, setRefreshedAt] = useState<Date | null>(null);

  const refresh = useCallback(async (winMin: number) => {
    // Promise.allSettled so one endpoint failing doesn't blank the rest;
    // whichever resolves still updates its panel. Errors get concatenated
    // into the destructive Card above the grid.
    const errs: string[] = [];

    const summaryP = fetch(`${GW}/admin/dashboard/summary?window_minutes=${winMin}`, {
      cache: "no-store", credentials: "same-origin",
    }).then(async (r) => {
      if (!r.ok) throw new Error(`summary: ${r.status} ${r.statusText}`);
      return (await r.json()) as DashboardSummary;
    });

    const detailsP = fetch(`${GW}/admin/metrics/details?window_minutes=${winMin}`, {
      cache: "no-store", credentials: "same-origin",
    }).then(async (r) => {
      if (!r.ok) throw new Error(`details: ${r.status} ${r.statusText}`);
      return (await r.json()) as MetricsDetails;
    });

    const [sRes, dRes] = await Promise.allSettled([summaryP, detailsP]);
    if (sRes.status === "fulfilled") setSummary(sRes.value); else errs.push(String(sRes.reason));
    if (dRes.status === "fulfilled") setDetails(dRes.value); else errs.push(String(dRes.reason));

    setRefreshedAt(new Date());
    setError(errs.length ? errs.join(" · ") : null);
  }, []);

  // Initial + polling. Re-key on windowMin so the operator's choice flows
  // through to the next tick without needing a manual refresh.
  useEffect(() => {
    void refresh(windowMin);
    const id = window.setInterval(() => { void refresh(windowMin); }, REFRESH_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, [refresh, windowMin]);

  // Refusal rate = (refused + error) / total. Computed off summary so the
  // value lines up with what the stat row shows even when /details fails.
  const refusalPct = useMemo(() => {
    if (!summary || summary.request_count === 0) return 0;
    const refused = summary.verdict_counts.refused ?? 0;
    const errored = summary.verdict_counts.error   ?? 0;
    return ((refused + errored) / summary.request_count) * 100;
  }, [summary]);

  const refusalPulse = refusalPct > REFUSAL_RATE_PULSE_PCT;
  // Master cost-visibility gate. Treat `null` (still loading) the same as
  // "off" so the page doesn't flash money values during the first paint
  // and then hide them; an operator who turns it on after page load will
  // see costs after the next refresh of `useCostVisible` listeners.
  const showCost = useCostVisible() === true;

  return (
    <div className="mx-auto max-w-7xl space-y-8">
      {/* Header */}
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-2">
          <h1 className="page-title">Metrics</h1>
          <p className="max-w-2xl text-sm text-muted-foreground">
            Latency percentiles, token spend vs budget, refusal rates by plugin, DLP finding mix.
            All derived live from the audit log.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <label htmlFor="metrics-window" className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Window
            </label>
            <select
              id="metrics-window"
              value={windowMin}
              onChange={(e) => setWindowMin(Number(e.target.value))}
              className="h-9 rounded-md border border-border/70 bg-background/60 px-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {WINDOW_OPTIONS.map((opt) => (
                <option key={opt.minutes} value={opt.minutes}>{opt.label}</option>
              ))}
            </select>
          </div>
          {refreshedAt && (
            <span className="hidden text-[11px] text-muted-foreground sm:inline">
              updated {refreshedAt.toLocaleTimeString()}
              <button
                onClick={() => { void refresh(windowMin); }}
                className="ml-2 inline-flex h-5 w-5 items-center justify-center rounded-md hover:bg-secondary"
                aria-label="Refresh"
                title="Refresh"
              >
                <RefreshCw className="h-3 w-3" />
              </button>
            </span>
          )}
        </div>
      </header>

      {error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="flex items-center gap-2 p-4 text-sm text-destructive">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span className="break-all">{error}</span>
          </CardContent>
        </Card>
      )}

      {/* Stat cards — 3-up or 4-up depending on cost-visibility. The Total
          spend tile only appears when the operator has enabled cost UI in
          Settings → App settings → Cost metrics. */}
      <section className={"grid gap-4 sm:grid-cols-2 " + (showCost ? "lg:grid-cols-4" : "lg:grid-cols-3")}>
        <InfoBox
          tone="info"
          icon={<Activity className="h-16 w-16" />}
          label={`Requests · ${windowLabel(windowMin)}`}
          value={summary ? summary.request_count.toLocaleString() : "—"}
          footer={summary ? `${summary.requests_per_min.toFixed(2)} req/min` : "loading…"}
        />
        <InfoBox
          tone="success"
          icon={<Zap className="h-16 w-16" />}
          label="p99 latency (ms)"
          value={summary ? `${Math.round(summary.p99_latency_ms)}` : "—"}
          footer={summary ? `avg ${Math.round(summary.avg_latency_ms)} ms` : "ms"}
        />
        {showCost && (
          <InfoBox
            tone="warning"
            icon={<DollarSign className="h-16 w-16" />}
            label="Total spend (USD)"
            value={summary ? `$${summary.cost_usd_total.toFixed(4)}` : "—"}
            footer={
              summary
                ? `${(summary.tokens_in_total + summary.tokens_out_total).toLocaleString()} tokens`
                : "loading…"
            }
          />
        )}
        <InfoBox
          tone={refusalPulse ? "danger" : "primary"}
          icon={<ShieldAlert className="h-16 w-16" />}
          label="Refusal rate"
          value={summary ? `${refusalPct.toFixed(1)}%` : "—"}
          footer={
            summary
              ? `${(summary.verdict_counts.refused ?? 0) + (summary.verdict_counts.error ?? 0)} of ${summary.request_count.toLocaleString()}`
              : "loading…"
          }
        />
      </section>

      {/* Latency by model + Spend by team. SpendByTeam is cost-gated:
          when off, latency goes full-width so the row doesn't have a hole. */}
      <section className={"grid gap-4 " + (showCost ? "lg:grid-cols-2" : "")}>
        <LatencyByModelCard data={details?.latency_by_model ?? null} windowMin={windowMin} />
        {showCost && (
          <SpendByTeamCard data={details?.spend_by_team ?? null} windowMin={windowMin} />
        )}
      </section>

      {/* Refusals by plugin + Finding mix — two-up */}
      <section className="grid gap-4 lg:grid-cols-2">
        <RefusalsByPluginCard data={details?.plugin_errors ?? null} windowMin={windowMin} />
        <FindingMixCard       data={details?.finding_mix    ?? null} windowMin={windowMin} />
      </section>

      {/* Cost forecast + Spend by model — only render when the operator
          has flipped on Cost metrics in Settings → App settings. */}
      {showCost && (
        <>
          <CostForecastCard />
          <SpendByModelCard />
        </>
      )}
    </div>
  );
}

// -------------------------------------------------------------------------
// Helpers
// -------------------------------------------------------------------------

function windowLabel(min: number): string {
  if (min < 60) return `${min}m`;
  if (min === 10080) return "7d";
  if (min % 1440 === 0) return `${min / 1440}d`;
  if (min % 60 === 0) return `${min / 60}h`;
  return `${min}m`;
}

// Relative time formatter — "5m ago" style. Falls back to absolute clock
// time once the gap crosses a day so the operator isn't reading "1440m ago".
function relativeTime(iso: string | null): string {
  if (!iso) return "—";
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return "—";
  const diffSec = Math.max(0, Math.floor((Date.now() - t) / 1000));
  if (diffSec < 5)         return "just now";
  if (diffSec < 60)        return `${diffSec}s ago`;
  if (diffSec < 3600)      return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86_400)    return `${Math.floor(diffSec / 3600)}h ago`;
  const days = Math.floor(diffSec / 86_400);
  if (days < 7)            return `${days}d ago`;
  return new Date(t).toLocaleDateString();
}

// -------------------------------------------------------------------------
// StatCard — 4-up styling lifted from Overview so the pages match.
// -------------------------------------------------------------------------

function StatCard({
  icon, label, value, hint, pulse,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  hint: string;
  pulse?: boolean;
}) {
  return (
    <Card className="group relative overflow-hidden shadow-soft transition-shadow hover:shadow-ring">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-px -top-px h-24 w-24 bg-gradient-to-br from-accent/40 via-accent/10 to-transparent opacity-70"
      />
      <CardContent className="relative p-5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {label}
          </span>
          <span className="flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground">
            {icon}
          </span>
        </div>
        <div className="mt-4 flex items-center gap-2">
          <div className="stat-number">
            {value}
          </div>
          {pulse && (
            <span className="relative inline-flex h-2.5 w-2.5" aria-label="refusal rate above threshold">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-destructive" />
            </span>
          )}
        </div>
        <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// Latency by model — sortable table, p99 cell tinted red over threshold.
// -------------------------------------------------------------------------

function LatencyByModelCard({
  data, windowMin,
}: {
  data: LatencyByModel[] | null;
  windowMin: number;
}) {
  const sorted = useMemo(() => {
    if (!data) return null;
    return [...data].sort((a, b) => b.count - a.count);
  }, [data]);

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Latency by model · last {windowLabel(windowMin)}
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Percentiles over per-request total latency. p99 cells highlight red above {P99_RED_MS} ms.
        </p>
        {sorted === null ? (
          <div className="text-sm text-muted-foreground">Loading…</div>
        ) : sorted.length === 0 ? (
          <div className="text-sm text-muted-foreground">No traffic in the last {windowLabel(windowMin)}.</div>
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Model</TH>
                <TH className="text-right">Count</TH>
                <TH className="text-right">Avg</TH>
                <TH className="text-right">p50</TH>
                <TH className="text-right">p95</TH>
                <TH className="text-right">p99</TH>
              </TR>
            </THead>
            <TBody>
              {sorted.map((row) => (
                <TR key={row.model}>
                  <TD className="font-mono text-xs">{row.model}</TD>
                  <TD className="text-right font-mono tabular-nums">{row.count.toLocaleString()}</TD>
                  <TD className="text-right font-mono tabular-nums">{Math.round(row.avg_ms)}</TD>
                  <TD className="text-right font-mono tabular-nums">{Math.round(row.p50_ms)}</TD>
                  <TD className="text-right font-mono tabular-nums">{Math.round(row.p95_ms)}</TD>
                  <TD
                    className={
                      "text-right font-mono tabular-nums " +
                      (row.p99_ms > P99_RED_MS ? "bg-destructive/15 text-destructive" : "")
                    }
                  >
                    {Math.round(row.p99_ms)}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// Spend by team — progress bar per team scaled to its daily budget.
// -------------------------------------------------------------------------

function SpendByTeamCard({
  data, windowMin,
}: {
  data: SpendByTeam[] | null;
  windowMin: number;
}) {
  // Sort by cost desc so the highest spenders sit at the top. Tied teams
  // fall back to total-tokens as a deterministic secondary key.
  const sorted = useMemo(() => {
    if (!data) return null;
    return [...data].sort((a, b) => b.cost_usd - a.cost_usd || b.tokens_total - a.tokens_total);
  }, [data]);

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Spend by team · last {windowLabel(windowMin)}
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Token usage vs daily budget. Teams without a configured limit show as unlimited.
        </p>
        {sorted === null ? (
          <div className="text-sm text-muted-foreground">Loading…</div>
        ) : sorted.length === 0 ? (
          <div className="text-sm text-muted-foreground">No team activity in the last {windowLabel(windowMin)}.</div>
        ) : (
          <ul className="space-y-3">
            {sorted.map((t) => (
              <SpendRow key={t.team_id} team={t} />
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function SpendRow({ team }: { team: SpendByTeam }) {
  const tierVariant: BadgeVariant = TIER_VARIANT[team.tier?.toLowerCase()] ?? "secondary";
  const hasLimit = team.daily_limit !== null && team.daily_limit !== undefined && team.daily_limit > 0;
  // Clamp pct to [0, 100] for the visual bar — backends sometimes report
  // >100% when a team blew through its limit and we still want a full bar.
  const pct = Math.max(0, Math.min(100, team.pct_used));
  const barColor =
    team.pct_used > 90 ? "bg-destructive" :
    team.pct_used >= 60 ? "bg-oati-warning" :
    "bg-oati-success";

  return (
    <li className="space-y-1.5">
      <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
        <div className="flex items-center gap-2">
          <span className="truncate font-mono">{team.team_id}</span>
          <Badge variant={tierVariant} className="font-mono uppercase">{team.tier || "—"}</Badge>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="font-mono tabular-nums text-muted-foreground">
            {team.tokens_total.toLocaleString()} tok
          </span>
          <span className="font-mono tabular-nums">
            ${team.cost_usd.toFixed(4)}
          </span>
        </div>
      </div>
      {hasLimit ? (
        <div className="flex items-center gap-2">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
            <div className={"h-full rounded-full " + barColor} style={{ width: `${pct}%` }} />
          </div>
          <span className="w-16 text-right font-mono text-[11px] tabular-nums text-muted-foreground">
            {team.pct_used.toFixed(1)}%
          </span>
        </div>
      ) : (
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
          <span className="font-mono">—</span>
          <span className="italic">unlimited</span>
        </div>
      )}
    </li>
  );
}

// -------------------------------------------------------------------------
// Refusals by plugin — table sorted by count desc.
// -------------------------------------------------------------------------

function RefusalsByPluginCard({
  data, windowMin,
}: {
  data: PluginError[] | null;
  windowMin: number;
}) {
  const sorted = useMemo(() => {
    if (!data) return null;
    return [...data].sort((a, b) => b.refused_count - a.refused_count);
  }, [data]);

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Refusals by plugin · last {windowLabel(windowMin)}
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Each row is a plugin that short-circuited at least one request in the window.
        </p>
        {sorted === null ? (
          <div className="text-sm text-muted-foreground">Loading…</div>
        ) : sorted.length === 0 ? (
          <div className="text-sm text-muted-foreground">
            No refusals in the window — every request landed allow.
          </div>
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Plugin</TH>
                <TH className="text-right">Refused</TH>
                <TH className="text-right">Last refusal</TH>
              </TR>
            </THead>
            <TBody>
              {sorted.map((p) => (
                <TR key={p.plugin}>
                  <TD className="font-mono text-xs">{p.plugin}</TD>
                  <TD className="text-right font-mono tabular-nums">{p.refused_count.toLocaleString()}</TD>
                  <TD className="text-right font-mono text-xs tabular-nums text-muted-foreground">
                    {relativeTime(p.last_refusal_at)}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// Finding mix — horizontal bar list, top 10, severity-coloured.
// -------------------------------------------------------------------------

// Severity inferred from the kind prefix. Anything we don't recognise falls
// through to the "default" accent so the row still renders cleanly.
function findingColor(kind: string): string {
  const k = kind.toLowerCase();
  if (k.startsWith("pii."))                return "bg-accent";
  if (k.startsWith("secret."))             return "bg-oati-warning";
  if (k.startsWith("prompt_injection."))   return "bg-destructive";
  return "bg-muted-foreground/60";
}

function FindingMixCard({
  data, windowMin,
}: {
  data: FindingMix[] | null;
  windowMin: number;
}) {
  const top = useMemo(() => {
    if (!data) return null;
    return [...data].sort((a, b) => b.count - a.count).slice(0, 10);
  }, [data]);

  const max = top && top.length > 0 ? Math.max(1, ...top.map((d) => d.count)) : 1;

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Finding mix · last {windowLabel(windowMin)}
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Top 10 finding kinds scaled to the leader. Colour by severity prefix
          (<span className="font-mono">pii.*</span>,{" "}
          <span className="font-mono">secret.*</span>,{" "}
          <span className="font-mono">prompt_injection.*</span>).
        </p>
        {top === null ? (
          <div className="text-sm text-muted-foreground">Loading…</div>
        ) : top.length === 0 ? (
          <div className="text-sm text-muted-foreground">No findings in the window.</div>
        ) : (
          <ul className="space-y-2.5">
            {top.map((f) => {
              const pct = (f.count / max) * 100;
              return (
                <li key={f.kind} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="truncate font-mono">{f.kind}</span>
                    <span className="font-mono tabular-nums text-muted-foreground">
                      {f.count.toLocaleString()}
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                    <div className={"h-full rounded-full " + findingColor(f.kind)} style={{ width: `${pct}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// Cost forecast — burn-rate projection card.
//
// Independent window controls (look-back days + projection days) since the
// time horizon here is days/weeks rather than the minutes-scale window used
// by the rest of the page. Debounced refetch so the operator can scrub the
// inputs without spamming the audit DB.
// -------------------------------------------------------------------------

// USD formatter — 2 decimals for headline numbers (these are real dollars,
// not the fractional-cent token costs in the rest of the page).
function fmtUsd(n: number): string {
  if (!Number.isFinite(n)) return "—";
  return `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// Tighter formatter for the breakdown tables, where ranks matter more than
// absolute precision and rows with sub-cent spend still need to render.
function fmtUsdCompact(n: number): string {
  if (!Number.isFinite(n)) return "—";
  if (n >= 1) return `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  return `$${n.toFixed(4)}`;
}

function CostForecastCard() {
  // Defaults match the gateway endpoint defaults so the first render shows
  // the same numbers an operator would get from a bare curl.
  const [windowDays, setWindowDays]         = useState<number>(7);
  const [projectionDays, setProjectionDays] = useState<number>(30);
  const [data, setData]   = useState<CostForecastResponse | null>(null);
  const [err, setErr]     = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  // Track the latest in-flight request so a stale response that resolves
  // after a newer one started can't clobber the UI.
  const reqIdRef = useRef(0);

  const fetchForecast = useCallback(async (winD: number, projD: number) => {
    const myId = ++reqIdRef.current;
    setLoading(true);
    try {
      const r = await fetch(
        `${GW}/admin/metrics/cost-forecast?window_days=${winD}&projection_days=${projD}`,
        { cache: "no-store", credentials: "same-origin" },
      );
      if (!r.ok) throw new Error(`cost-forecast: ${r.status} ${r.statusText}`);
      const j = (await r.json()) as CostForecastResponse;
      if (myId !== reqIdRef.current) return;     // stale response, ignore
      setData(j);
      setErr(null);
    } catch (e) {
      if (myId !== reqIdRef.current) return;
      setErr(String(e));
    } finally {
      if (myId === reqIdRef.current) setLoading(false);
    }
  }, []);

  // Debounce the input-driven refetch so a scrub through values doesn't
  // hammer the endpoint. 300ms is the same feel the operator gets in the
  // existing audit filters.
  useEffect(() => {
    const t = window.setTimeout(() => { void fetchForecast(windowDays, projectionDays); }, 300);
    return () => window.clearTimeout(t);
  }, [fetchForecast, windowDays, projectionDays]);

  // Derive top-5 by projected dollars. Per-row projected = share * projected_usd
  // — the gateway only returns share, so we multiply here to keep the table's
  // numbers consistent with the headline.
  const topTeams = useMemo(() => {
    if (!data) return null;
    return [...data.by_team]
      .map((t) => ({ ...t, projected_usd: t.share * data.projected_usd }))
      .sort((a, b) => b.projected_usd - a.projected_usd)
      .slice(0, 5);
  }, [data]);

  const topModels = useMemo(() => {
    if (!data) return null;
    return [...data.by_model]
      .map((m) => ({ ...m, projected_usd: m.share * data.projected_usd }))
      .sort((a, b) => b.projected_usd - a.projected_usd)
      .slice(0, 5);
  }, [data]);

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="mb-1 flex items-center gap-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              <TrendingUp className="h-3.5 w-3.5" />
              Cost forecast
            </div>
            <p className="text-xs text-muted-foreground">
              Burn-rate projection: average daily cost over the look-back window, extrapolated forward.
              No regression — operators get the "if today's rate holds" number.
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <label className="flex items-center gap-1.5 text-muted-foreground">
              <span>Window (days)</span>
              <input
                type="number"
                min={1}
                max={90}
                value={windowDays}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  if (!Number.isFinite(v)) return;
                  setWindowDays(Math.max(1, Math.min(90, Math.trunc(v))));
                }}
                className="h-8 w-20 rounded-md border border-border/70 bg-background/60 px-2 font-mono text-xs tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
            <label className="flex items-center gap-1.5 text-muted-foreground">
              <span>Projection (days)</span>
              <input
                type="number"
                min={1}
                max={365}
                value={projectionDays}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  if (!Number.isFinite(v)) return;
                  setProjectionDays(Math.max(1, Math.min(365, Math.trunc(v))));
                }}
                className="h-8 w-20 rounded-md border border-border/70 bg-background/60 px-2 font-mono text-xs tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
            {loading && (
              <RefreshCw
                className="h-3.5 w-3.5 animate-spin text-muted-foreground"
                aria-label="Loading forecast"
              />
            )}
          </div>
        </div>

        {err && (
          <div className="mb-3 rounded-md border border-destructive/40 bg-destructive/10 p-2 text-xs text-destructive">
            {err}
          </div>
        )}

        {/* Headline numbers — 3-cell grid. Use the same nested-card visual
            language as the StatCard row above but inset, since these belong
            to a single panel rather than being page-level stats. */}
        <div className="grid gap-3 sm:grid-cols-3">
          <ForecastStat
            label={`Actual · last ${data?.window_days ?? windowDays}d`}
            value={data ? fmtUsd(data.cost_window_usd) : "—"}
            hint={data ? `${data.rows_considered.toLocaleString()} rows` : "loading…"}
          />
          <ForecastStat
            label="Daily average"
            value={data ? fmtUsd(data.cost_per_day) : "—"}
            hint={data ? `over ${data.window_days}-day window` : "loading…"}
          />
          <ForecastStat
            label={`Projected · next ${data?.projection_days ?? projectionDays}d`}
            value={data ? fmtUsd(data.projected_usd) : "—"}
            hint={
              data
                ? `${fmtUsd(data.cost_per_day)}/day × ${data.projection_days}d`
                : "loading…"
            }
            emphasis
          />
        </div>

        {/* Breakdown tables — side-by-side, top 5 each by projected dollars. */}
        <div className="mt-5 grid gap-4 lg:grid-cols-2">
          <ForecastBreakdown
            title="By team"
            rows={
              topTeams === null ? null :
              topTeams.map((t) => ({
                label: t.team_id,
                actual_usd:    t.cost_usd,
                projected_usd: t.projected_usd,
                share:         t.share,
              }))
            }
          />
          <ForecastBreakdown
            title="By model"
            rows={
              topModels === null ? null :
              topModels.map((m) => ({
                label: m.model_used,
                actual_usd:    m.cost_usd,
                projected_usd: m.projected_usd,
                share:         m.share,
              }))
            }
          />
        </div>
      </CardContent>
    </Card>
  );
}

function ForecastStat({
  label, value, hint, emphasis,
}: {
  label: string;
  value: React.ReactNode;
  hint: string;
  emphasis?: boolean;
}) {
  return (
    <div
      className={
        "rounded-md border bg-background/40 p-3 " +
        (emphasis ? "border-accent/40" : "border-border/60")
      }
    >
      <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div
        className={
          "stat-number " +
          (emphasis ? "text-accent-foreground" : "text-foreground")
        }
      >
        {value}
      </div>
      <div className="mt-0.5 text-[11px] text-muted-foreground">{hint}</div>
    </div>
  );
}

type ForecastBreakdownRow = {
  label: string;
  actual_usd: number;
  projected_usd: number;
  share: number;
};

function ForecastBreakdown({
  title, rows,
}: {
  title: string;
  rows: ForecastBreakdownRow[] | null;
}) {
  return (
    <div className="rounded-md border border-border/60 bg-background/40 p-3">
      <div className="mb-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {title} · top 5 by projected
      </div>
      {rows === null ? (
        <div className="text-xs text-muted-foreground">Loading…</div>
      ) : rows.length === 0 ? (
        <div className="text-xs text-muted-foreground">No spend in the window.</div>
      ) : (
        <Table>
          <THead>
            <TR>
              <TH>{title === "By team" ? "Team" : "Model"}</TH>
              <TH className="text-right">Actual</TH>
              <TH className="text-right">Projected</TH>
              <TH className="text-right">Share</TH>
            </TR>
          </THead>
          <TBody>
            {rows.map((row) => (
              <TR key={row.label}>
                <TD className="max-w-[18ch] truncate font-mono text-xs" title={row.label}>
                  {row.label}
                </TD>
                <TD className="text-right font-mono text-xs tabular-nums text-muted-foreground">
                  {fmtUsdCompact(row.actual_usd)}
                </TD>
                <TD className="text-right font-mono text-xs tabular-nums">
                  {fmtUsdCompact(row.projected_usd)}
                </TD>
                <TD className="text-right font-mono text-xs tabular-nums text-muted-foreground">
                  {(row.share * 100).toFixed(1)}%
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
      )}
    </div>
  );
}

// -------------------------------------------------------------------------
// Spend ($USD/h) by model. Gated at the page level by `useCostVisible`,
// which mirrors the master "Cost metrics" toggle in /settings/app. We
// don't render any toggle UI here anymore — when the parent decides this
// card should appear, it's already in the enabled state.
// -------------------------------------------------------------------------
function SpendByModelCard() {
  const [windowMin, setWindowMin]   = useState<number>(60);
  const [data, setData]             = useState<SpendByModelResponse | null>(null);
  const [err, setErr]               = useState<string | null>(null);
  const [loading, setLoading]       = useState<boolean>(false);
  const reqIdRef                    = useRef(0);

  // Fetch data — the endpoint will return the rolled-up burn rate when
  // tracking is on (which it must be, since this card only renders in
  // that case via the master gate).
  const fetchSpend = useCallback(async (win: number) => {
    const myId = ++reqIdRef.current;
    setLoading(true);
    try {
      const r = await fetch(
        `${GW}/admin/metrics/spend-by-model?window_minutes=${win}`,
        { cache: "no-store", credentials: "same-origin" },
      );
      if (!r.ok) throw new Error(`spend-by-model: ${r.status} ${r.statusText}`);
      const j = (await r.json()) as SpendByModelResponse;
      if (myId !== reqIdRef.current) return;
      setData(j);
      setErr(null);
    } catch (e) {
      if (myId !== reqIdRef.current) return;
      setErr(String(e));
    } finally {
      if (myId === reqIdRef.current) setLoading(false);
    }
  }, []);

  // Initial fetch + 30s poll. Parent's render gate already enforces the
  // "tracking on" precondition, so we always run.
  useEffect(() => {
    void fetchSpend(windowMin);
    const id = window.setInterval(() => void fetchSpend(windowMin), 30_000);
    return () => window.clearInterval(id);
  }, [windowMin, fetchSpend]);

  const totalPerHour = useMemo(
    () => (data?.by_model ?? []).reduce((acc, r) => acc + (r.usd_per_hour || 0), 0),
    [data],
  );

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="mb-1 flex items-center gap-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              <DollarSign className="h-3.5 w-3.5" />
              Spend ($USD/h) by model
            </div>
            <p className="text-xs text-muted-foreground">
              Per-model burn rate over a rolling window.
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <label className="flex items-center gap-1.5 text-muted-foreground">
              <span>Window (min)</span>
              <input
                type="number"
                min={1}
                max={1440}
                value={windowMin}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  if (!Number.isFinite(v)) return;
                  setWindowMin(Math.max(1, Math.min(1440, Math.trunc(v))));
                }}
                className="h-8 w-20 rounded-md border border-border/70 bg-background/60 px-2 font-mono text-xs tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
            {loading && (
              <RefreshCw
                className="h-3.5 w-3.5 animate-spin text-muted-foreground"
                aria-label="Loading spend rate"
              />
            )}
          </div>
        </div>

        {err && (
          <div className="mb-3 rounded-md border border-destructive/40 bg-destructive/10 p-2 text-xs text-destructive">
            {err}
          </div>
        )}

        <>
            <div className="grid gap-3 sm:grid-cols-2">
              <ForecastStat
                label="Current burn rate"
                value={fmtUsd(totalPerHour) + "/h"}
                hint={data ? `over last ${data.window_minutes}m` : "loading…"}
                emphasis
              />
              <ForecastStat
                label="Window cost"
                value={data ? fmtUsd(data.cost_total_usd) : "—"}
                hint={
                  data
                    ? `${data.rows_considered.toLocaleString()} audit rows`
                    : "loading…"
                }
              />
            </div>

            <div className="mt-5">
              {(!data || data.by_model.length === 0) ? (
                <div className="rounded-md border border-border/60 bg-background/30 p-6 text-center text-xs text-muted-foreground">
                  No cost recorded in this window yet — drive some traffic
                  through a priced model and the table will populate.
                </div>
              ) : (
                <Table>
                  <THead>
                    <TR>
                      <TH>Model</TH>
                      <TH className="text-right">Cost (window)</TH>
                      <TH className="text-right">$USD / hour</TH>
                    </TR>
                  </THead>
                  <TBody>
                    {data.by_model.map((row) => (
                      <TR key={row.model}>
                        <TD className="max-w-[24ch] truncate font-mono text-xs" title={row.model}>
                          {row.model}
                        </TD>
                        <TD className="text-right font-mono text-xs tabular-nums text-muted-foreground">
                          {fmtUsdCompact(row.cost_usd)}
                        </TD>
                        <TD className="text-right font-mono text-xs tabular-nums">
                          {fmtUsdCompact(row.usd_per_hour)}/h
                        </TD>
                      </TR>
                    ))}
                  </TBody>
                </Table>
              )}
            </div>
          </>
      </CardContent>
    </Card>
  );
}

function ToggleSwitch({
  enabled, loading, onClick, labelOn, labelOff,
}: {
  enabled:  boolean;
  loading:  boolean;
  onClick:  () => void;
  labelOn:  string;
  labelOff: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={loading}
      aria-pressed={enabled}
      className={
        "inline-flex items-center gap-2 rounded-full border px-2 py-1 text-[11px] font-medium transition-colors " +
        (enabled
          ? "border-accent/40 bg-accent/15 text-accent-foreground"
          : "border-border/60 bg-background/60 text-muted-foreground hover:bg-secondary/40") +
        (loading ? " cursor-wait opacity-70" : "")
      }
    >
      <span
        aria-hidden
        className={
          "inline-block h-3.5 w-7 rounded-full transition-colors " +
          (enabled ? "bg-accent" : "bg-border")
        }
      >
        <span
          className={
            "block h-3.5 w-3.5 rounded-full bg-background shadow-sm transition-transform " +
            (enabled ? "translate-x-[14px]" : "translate-x-0")
          }
        />
      </span>
      <span className="tabular-nums">{enabled ? labelOn : labelOff}</span>
    </button>
  );
}
