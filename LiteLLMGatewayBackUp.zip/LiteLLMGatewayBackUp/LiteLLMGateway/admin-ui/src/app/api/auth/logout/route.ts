import { NextResponse } from "next/server";
import { COOKIE_NAME, cookieOptions } from "@/lib/session";

export async function POST() {
  const res = NextResponse.json({ ok: true });
  // Set an expired cookie with the same options so the browser drops it.
  res.cookies.set(COOKIE_NAME, "", { ...cookieOptions(), maxAge: 0 });
  return res;
}
