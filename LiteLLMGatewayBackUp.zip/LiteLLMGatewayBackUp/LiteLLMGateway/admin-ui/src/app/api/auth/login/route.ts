import { NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";
import { COOKIE_NAME, cookieOptions, createSessionToken } from "@/lib/session";

/**
 * POST /api/auth/login   { user: string, pass: string }
 *
 * Validates against ADMIN_USER / ADMIN_PASS env vars and sets the session
 * cookie. Replaced by an OIDC PKCE flow in Sprint 4+; the cookie shape stays
 * identical so consuming code doesn't change.
 *
 * Brute-force defence: we always perform both timing-safe compares (even on
 * unknown user) so a 401 leaks no information about which field was wrong.
 */
export async function POST(req: Request) {
  const expectedUser = process.env.ADMIN_USER || "admin";
  const expectedPass = process.env.ADMIN_PASS;
  if (!expectedPass) {
    return NextResponse.json(
      { error: "Server misconfigured: ADMIN_PASS is not set" },
      { status: 500 },
    );
  }

  let body: { user?: unknown; pass?: unknown };
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Bad request" }, { status: 400 }); }

  const user = typeof body.user === "string" ? body.user : "";
  const pass = typeof body.pass === "string" ? body.pass : "";

  // Constant-time equality on equal-length buffers — pad to avoid early-out
  // length leaks.
  const sameUser = safeEqual(user, expectedUser);
  const samePass = safeEqual(pass, expectedPass);

  if (!sameUser || !samePass) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  const { token, session } = createSessionToken(expectedUser);
  const res = NextResponse.json({ user: session.user, exp: session.exp });
  res.cookies.set(COOKIE_NAME, token, cookieOptions());
  return res;
}

function safeEqual(a: string, b: string): boolean {
  const maxLen = Math.max(a.length, b.length, 1);
  const ab = Buffer.alloc(maxLen);
  const bb = Buffer.alloc(maxLen);
  ab.write(a, "utf8");
  bb.write(b, "utf8");
  // Only the equal-length compare is timing-safe; we still pad to maxLen so
  // length differences don't leak via timing of the buffer alloc above.
  return a.length === b.length && timingSafeEqual(ab, bb);
}
