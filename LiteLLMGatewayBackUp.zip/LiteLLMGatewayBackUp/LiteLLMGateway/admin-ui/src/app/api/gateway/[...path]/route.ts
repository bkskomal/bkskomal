import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";

/**
 * BFF proxy:  /api/gateway/<path>  →  ${GATEWAY_URL}/<path>
 *
 * Why this exists
 * ---------------
 * The browser never sees the gateway's master key. The session cookie
 * authenticates the *operator* to the BFF; the BFF then attaches the
 * master key server-side when calling the gateway. Master key stays in
 * a server-only env var (GATEWAY_MASTER_KEY) and out of the JS bundle.
 *
 * What the proxy strips / passes
 * ------------------------------
 *   strips:   Authorization, Cookie, Host
 *   adds:     Authorization: Bearer <GATEWAY_MASTER_KEY>
 *             X-Forwarded-By: admin-ui-bff
 *             X-Operator: <session.user>
 *   preserves: method, body, query string, response status & headers
 */

const HOP_BY_HOP = new Set([
  "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
  "te", "trailer", "transfer-encoding", "upgrade",
  "authorization", "cookie", "host",
  "content-length",   // recomputed by fetch
]);

function gatewayBase(): string {
  const u = process.env.GATEWAY_URL || "http://localhost:4000";
  return u.replace(/\/+$/, "");
}

function masterKey(): string {
  const k = process.env.GATEWAY_MASTER_KEY;
  if (!k) throw new Error("GATEWAY_MASTER_KEY is not set on the BFF");
  return k;
}

async function handler(req: NextRequest,
                       { params }: { params: Promise<{ path: string[] }> }) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }

  const { path } = await params;
  const upstreamPath = "/" + (path || []).join("/");
  const search = req.nextUrl.search || "";
  const upstreamUrl = `${gatewayBase()}${upstreamPath}${search}`;

  // Build headers — drop hop-by-hop + auth, inject the master key.
  const fwd: Record<string, string> = {};
  req.headers.forEach((value, name) => {
    if (!HOP_BY_HOP.has(name.toLowerCase())) fwd[name] = value;
  });
  fwd["Authorization"] = `Bearer ${masterKey()}`;
  fwd["X-Forwarded-By"] = "admin-ui-bff";
  fwd["X-Operator"]    = session.user;

  // Preserve the body verbatim for non-GET/HEAD.
  const method = req.method.toUpperCase();
  const body = (method === "GET" || method === "HEAD") ? undefined : await req.arrayBuffer();

  let upstream: Response;
  try {
    upstream = await fetch(upstreamUrl, { method, headers: fwd, body, redirect: "manual" });
  } catch (e) {
    return NextResponse.json(
      { error: "Upstream unreachable", detail: String(e) },
      { status: 502 },
    );
  }

  // Mirror status + body. Strip hop-by-hop response headers so Next.js
  // controls transfer-encoding itself.
  const respHeaders = new Headers();
  upstream.headers.forEach((v, k) => {
    if (!HOP_BY_HOP.has(k.toLowerCase())) respHeaders.set(k, v);
  });

  const buf = await upstream.arrayBuffer();
  return new NextResponse(buf, {
    status: upstream.status,
    statusText: upstream.statusText,
    headers: respHeaders,
  });
}

export {
  handler as GET,
  handler as POST,
  handler as PUT,
  handler as PATCH,
  handler as DELETE,
  handler as OPTIONS,
};
