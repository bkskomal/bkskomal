"use client";

import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// -------------------------------------------------------------------------
// Types — mirror /admin/plugins and /admin/plugins/{name}/config contracts.
// `effective` arrives as a flattened dict keyed by dotted paths matching the
// schema's field `key` — we keep it that way for reads and only re-nest at
// submit time so the wire shape stays a deep object the gateway expects.
// -------------------------------------------------------------------------

type Plugin = {
  name: string;
  kind: string;
  version: string;
  description: string;
};

type FieldType = "bool" | "int" | "float" | "string" | "select";

type SchemaField = {
  key: string;
  type: FieldType;
  label: string;
  default: unknown;
  help?: string;
  min?: number;
  max?: number;
  step?: number;
  options?: string[];
  max_length?: number;
};

type PluginSchema = {
  title: string;
  description: string;
  fields: SchemaField[];
};

type SchemasResponse = {
  configurable_plugins: string[];
  schemas: Record<string, PluginSchema>;
};

type ConfigResponse = {
  plugin_name: string;
  schema: PluginSchema;
  effective: Record<string, unknown>;
  stored: Record<string, unknown> | null;
  updated_at: string | null;
};

type SaveResponse = {
  plugin_name: string;
  stored: Record<string, unknown>;
  updated_at: string | null;
  reload: { reloaded?: string[]; [k: string]: unknown };
};

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

type BadgeVariant = "default" | "secondary" | "destructive" | "outline" | "success" | "warning" | "accent";

// Same KIND_VARIANT pattern as the Models/Tiers pages — map each plugin kind
// to a semantic badge colour. Anything unmapped falls back to `outline` to
// keep the page legible even when the gateway adds a new kind.
const KIND_VARIANT: Record<string, BadgeVariant> = {
  pre_call:       "accent",
  post_call:      "secondary",
  pre_stream:     "accent",
  post_stream:    "secondary",
  guardrail:      "warning",
  observability:  "success",
  cache:          "default",
  quota:          "warning",
  rate_limit:     "warning",
  policy:         "default",
};

// -------------------------------------------------------------------------
// Helpers — dotted-path get/set against a nested object, used to translate
// between the schema's flat `key` namespace and the wire shape. Kept small
// and dependency-free; we don't need lodash for two functions.
// -------------------------------------------------------------------------

function getNested(obj: unknown, path: string): unknown {
  if (!path) return obj;
  const parts = path.split(".");
  let cur: unknown = obj;
  for (const p of parts) {
    if (cur && typeof cur === "object" && p in (cur as Record<string, unknown>)) {
      cur = (cur as Record<string, unknown>)[p];
    } else {
      return undefined;
    }
  }
  return cur;
}

function setNested(
  obj: Record<string, unknown>,
  path: string,
  value: unknown,
): Record<string, unknown> {
  if (!path) return obj;
  const parts = path.split(".");
  let cur: Record<string, unknown> = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const p = parts[i];
    const next = cur[p];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cur[p] = {};
    }
    cur = cur[p] as Record<string, unknown>;
  }
  cur[parts[parts.length - 1]] = value;
  return obj;
}

// -------------------------------------------------------------------------
// Page
// -------------------------------------------------------------------------

export default function PluginsPage() {
  const [plugins, setPlugins] = useState<Plugin[] | null>(null);
  const [schemas, setSchemas] = useState<SchemasResponse | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // null = closed; otherwise the plugin name whose inline editor is open.
  const [editing, setEditing] = useState<string | null>(null);

  const loadPlugins = useCallback(async () => {
    try {
      const r = await fetch(`${GW}/admin/plugins`, {
        cache: "no-store", credentials: "same-origin",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data = await r.json();
      setPlugins(data.plugins);
    } catch (e) {
      setErr(String(e));
    }
  }, []);

  const loadSchemas = useCallback(async () => {
    // Schemas are advisory for the list view (deciding whether to show the
    // Configure button). If this 404s or errors we degrade to read-only —
    // the per-plugin config fetch will surface the real error.
    try {
      const r = await fetch(`${GW}/admin/plugins/schemas`, {
        cache: "no-store", credentials: "same-origin",
      });
      if (!r.ok) { setSchemas({ configurable_plugins: [], schemas: {} }); return; }
      const data: SchemasResponse = await r.json();
      setSchemas(data);
    } catch {
      setSchemas({ configurable_plugins: [], schemas: {} });
    }
  }, []);

  useEffect(() => { void loadPlugins(); void loadSchemas(); }, [loadPlugins, loadSchemas]);

  const configurableSet = useMemo(
    () => new Set(schemas?.configurable_plugins ?? []),
    [schemas],
  );

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div>
        <h1 className="page-title">Plugins</h1>
        <p className="text-muted-foreground">
          Plugins are discovered via Python entry-points. Configurable ones can be edited inline —
          edits hot-reload the live plugin chain.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Loaded plugins</CardTitle>
          <CardDescription>
            Loaded at startup; restart the gateway to pick up a new one.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {err && <p className="text-sm text-destructive">{err}</p>}
          {!plugins && !err && <p className="text-sm text-muted-foreground">Loading…</p>}
          {plugins && (
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="pb-3 pr-4">Name</th>
                  <th className="pb-3 pr-4">Kind</th>
                  <th className="pb-3 pr-4">Version</th>
                  <th className="pb-3 pr-4">Description</th>
                  <th className="pb-3">Config</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {plugins.map((p) => {
                  const configurable = configurableSet.has(p.name);
                  const isOpen = editing === p.name;
                  const variant = KIND_VARIANT[p.kind] ?? "outline";
                  return (
                    <Fragment key={p.name}>
                      <tr className="hover:bg-secondary/40">
                        <td className="py-3 pr-4 font-mono">{p.name}</td>
                        <td className="py-3 pr-4">
                          <Badge variant={variant} className="uppercase">
                            {p.kind}
                          </Badge>
                        </td>
                        <td className="py-3 pr-4 text-muted-foreground">v{p.version}</td>
                        <td className="py-3 pr-4">{p.description}</td>
                        <td className="py-3">
                          {configurable ? (
                            <Button
                              size="sm"
                              variant={isOpen ? "secondary" : "outline"}
                              onClick={() => setEditing((cur) => (cur === p.name ? null : p.name))}
                            >
                              {isOpen ? "Close" : "Configure"}
                            </Button>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                      </tr>
                      {isOpen && (
                        <tr>
                          <td colSpan={5} className="py-3">
                            <PluginConfigEditor
                              name={p.name}
                              onClose={() => setEditing(null)}
                            />
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// -------------------------------------------------------------------------
// PluginConfigEditor — fetches the schema + effective values for one plugin
// and renders a schema-driven form. Mutates a local `values` map keyed by
// the schema's dotted paths; on submit we re-nest into the wire shape.
// -------------------------------------------------------------------------

function PluginConfigEditor({
  name, onClose,
}: {
  name: string;
  onClose: () => void;
}) {
  const [loading, setLoading]   = useState(true);
  const [loadErr, setLoadErr]   = useState<string | null>(null);
  const [schema, setSchema]     = useState<PluginSchema | null>(null);
  const [values, setValues]     = useState<Record<string, unknown>>({});
  const [submitting, setSubmitting] = useState(false);
  const [formErr, setFormErr]   = useState<string | null>(null);
  const [confirmMsg, setConfirmMsg] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await fetch(`${GW}/admin/plugins/${encodeURIComponent(name)}/config`, {
          cache: "no-store", credentials: "same-origin",
        });
        if (!r.ok) {
          const text = await r.text().catch(() => "");
          throw new Error(`${r.status} ${r.statusText}${text ? ` — ${text}` : ""}`);
        }
        const data: ConfigResponse = await r.json();
        if (cancelled) return;
        // Seed the form from `effective` keyed by dotted path. Missing keys
        // fall through to the field's declared default — keeps the form
        // useful even if the gateway hasn't materialised an effective value
        // for a freshly-added field.
        const initial: Record<string, unknown> = {};
        for (const f of data.schema.fields) {
          const v = data.effective[f.key];
          initial[f.key] = v !== undefined ? v : f.default;
        }
        setSchema(data.schema);
        setValues(initial);
        setLoading(false);
      } catch (e) {
        if (cancelled) return;
        setLoadErr(String(e));
        setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [name]);

  const setValue = (key: string, v: unknown) => {
    setValues((prev) => ({ ...prev, [key]: v }));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!schema) return;
    setFormErr(null);
    setConfirmMsg(null);

    // Re-nest dotted paths into the deep object the gateway expects under
    // the wire key `config`.
    const nested: Record<string, unknown> = {};
    for (const f of schema.fields) {
      setNested(nested, f.key, values[f.key]);
    }

    setSubmitting(true);
    try {
      const r = await fetch(`${GW}/admin/plugins/${encodeURIComponent(name)}/config`, {
        method: "PUT",
        headers: JSON_HEADERS,
        credentials: "same-origin",
        body: JSON.stringify({ config: nested }),
      });
      if (r.status === 400) {
        const text = await r.text().catch(() => "");
        setFormErr(text || "Validation failed (400)");
        return;
      }
      if (!r.ok) {
        const text = await r.text().catch(() => "");
        throw new Error(`${r.status} ${r.statusText}${text ? ` — ${text}` : ""}`);
      }
      const data: SaveResponse = await r.json();
      const n = data.reload?.reloaded?.length ?? 0;
      setConfirmMsg(`Saved — ${n} ${n === 1 ? "plugin" : "plugins"} reloaded`);
      // Auto-dismiss the inline confirmation after 3s, per the spec.
      setTimeout(() => setConfirmMsg(null), 3000);
    } catch (e) {
      setFormErr(String(e));
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <Card className="border-accent/30">
        <CardContent className="p-4 text-sm text-muted-foreground">Loading schema…</CardContent>
      </Card>
    );
  }

  if (loadErr || !schema) {
    return (
      <Card className="border-destructive">
        <CardContent className="p-4 text-sm text-destructive">
          {loadErr ?? "No schema available for this plugin."}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-accent/30">
      <CardHeader>
        <CardTitle className="font-mono">{schema.title}</CardTitle>
        {schema.description && (
          <CardDescription>{schema.description}</CardDescription>
        )}
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          {formErr && (
            <Card className="border-destructive">
              <CardContent className="p-3 text-xs text-destructive">{formErr}</CardContent>
            </Card>
          )}

          <div className="space-y-4">
            {schema.fields.map((f) => (
              <FieldRow
                key={f.key}
                field={f}
                value={values[f.key]}
                onChange={(v) => setValue(f.key, v)}
              />
            ))}
          </div>

          {confirmMsg && (
            <div className="rounded-md border border-accent/40 bg-accent/10 p-2 text-xs text-accent-foreground">
              {confirmMsg}
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={onClose} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" variant="accent" disabled={submitting}>
              {submitting ? "Saving…" : "Save"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// FieldRow — renders one schema field based on its declared type.
// -------------------------------------------------------------------------

function FieldRow({
  field, value, onChange,
}: {
  field: SchemaField;
  value: unknown;
  onChange: (v: unknown) => void;
}) {
  return (
    <div className="space-y-1">
      {field.type === "bool" ? (
        <BoolField field={field} value={value} onChange={onChange} />
      ) : (
        <>
          <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {field.label}
          </label>
          {field.type === "int" && (
            <Input
              type="number"
              step={1}
              min={field.min}
              max={field.max}
              value={value === undefined || value === null ? "" : String(value)}
              onChange={(e) => {
                const raw = e.target.value;
                if (raw === "") { onChange(null); return; }
                const n = parseInt(raw, 10);
                onChange(Number.isFinite(n) ? n : raw);
              }}
              className="font-mono"
            />
          )}
          {field.type === "float" && (
            <Input
              type="number"
              step={field.step ?? 0.1}
              min={field.min}
              max={field.max}
              value={value === undefined || value === null ? "" : String(value)}
              onChange={(e) => {
                const raw = e.target.value;
                if (raw === "") { onChange(null); return; }
                const n = parseFloat(raw);
                onChange(Number.isFinite(n) ? n : raw);
              }}
              className="font-mono"
            />
          )}
          {field.type === "string" && (
            <Input
              type="text"
              maxLength={field.max_length}
              value={value === undefined || value === null ? "" : String(value)}
              onChange={(e) => onChange(e.target.value)}
              className="font-mono"
            />
          )}
          {field.type === "select" && (
            <select
              value={value === undefined || value === null ? "" : String(value)}
              onChange={(e) => onChange(e.target.value)}
              className="flex h-10 w-full rounded-md border border-border/70 bg-background/60 px-3 py-1 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {(field.options ?? []).map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          )}
        </>
      )}
      {field.help && (
        <div className="text-[11px] text-muted-foreground">{field.help}</div>
      )}
      <div className="text-[10px] font-mono text-muted-foreground/60">{field.key}</div>
    </div>
  );
}

function BoolField({
  field, value, onChange,
}: {
  field: SchemaField;
  value: unknown;
  onChange: (v: unknown) => void;
}) {
  const checked = value === true;
  return (
    <label className="flex items-center gap-2 text-sm">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 accent-accent"
      />
      <span className="text-foreground">{field.label}</span>
    </label>
  );
}
