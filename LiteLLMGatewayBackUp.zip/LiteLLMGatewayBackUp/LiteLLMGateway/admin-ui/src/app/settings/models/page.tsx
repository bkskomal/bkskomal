"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Boxes, Check, Code, FormInput, Pencil, Plus, RefreshCw, Search, Trash2, X, Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { OpenRouterBrowser } from "@/components/openrouter-browser";

// -------------------------------------------------------------------------
// Types — kept loose where the gateway is loose (litellm_params is whatever
// LiteLLM accepts for a given provider, so a free-form record is honest).
// -------------------------------------------------------------------------

type Provider =
  | "ollama" | "openrouter" | "openai" | "openai_compatible"
  | "anthropic" | "bedrock" | "azure" | "gemini" | "vertex"
  | "groq" | "together" | "custom";

type ModelInfo = {
  hosting?: string;
  family?: string;
  max_input_tokens?: number;
  cost_per_1k_input?: number;
  cost_per_1k_output?: number;
  [k: string]: unknown;
};

type ModelItem = {
  id: number | string;
  model_name: string;
  provider: Provider;
  enabled: boolean;
  litellm_params: Record<string, unknown>;
  model_info?: ModelInfo | null;
  created_at?: string;
  updated_at?: string;
};

// Ping response — mirrors ModelPingResponse on the gateway.
type ModelPingResponse = {
  model_id:   number;
  model_name: string;
  ok:         boolean;
  latency_ms: number;
  error:      string | null;
};

// -------------------------------------------------------------------------
// Constants — provider colour mapping + presets.
// -------------------------------------------------------------------------

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

type BadgeVariant = "default" | "secondary" | "destructive" | "outline" | "success" | "warning" | "accent";

// Same KIND_VARIANT pattern used elsewhere — map each provider to a semantic
// badge colour. Anything unmapped falls back to `default`.
const PROVIDER_VARIANT: Record<Provider, BadgeVariant> = {
  ollama:            "success",
  openrouter:        "accent",
  openai:            "secondary",
  openai_compatible: "secondary",
  anthropic:         "warning",
  bedrock:           "accent",
  azure:             "secondary",
  gemini:            "accent",
  vertex:            "secondary",
  groq:              "warning",
  together:          "default",
  custom:            "default",
};

const PROVIDERS: { id: Provider; label: string }[] = [
  { id: "ollama",            label: "Ollama (local)" },
  { id: "openrouter",        label: "OpenRouter" },
  { id: "openai_compatible", label: "OpenAI-Compatible (vLLM)" },
  { id: "openai",            label: "OpenAI" },
  { id: "anthropic",         label: "Anthropic" },
  { id: "bedrock",           label: "AWS Bedrock" },
  { id: "azure",             label: "Azure OpenAI" },
  { id: "gemini",            label: "Google Gemini" },
  { id: "vertex",            label: "Vertex AI" },
  { id: "groq",              label: "Groq" },
  { id: "together",          label: "Together AI" },
  { id: "custom",            label: "Custom" },
];

// Per-provider typed field schema. The form renders these as proper
// inputs instead of a raw JSON textarea; each field maps to a key in
// litellm_params. `secret` fields use type=password. Operators who need
// to set something outside this schema flip the Advanced toggle on
// ModelForm to drop back to raw JSON.
type FieldType = "text" | "password" | "select";
type FieldSpec = {
  key:         string;        // litellm_params[key]
  label:       string;
  placeholder?: string;
  type?:        FieldType;
  options?:     string[];     // for type=select
  required?:    boolean;
  help?:        string;
};

const PROVIDER_FIELDS: Record<Provider, FieldSpec[]> = {
  ollama: [
    { key: "model",    label: "Model (LiteLLM path)", placeholder: "ollama_chat/qwen2.5-coder:7b-instruct", required: true,
      help: "Use ollama_chat/<name>:<tag>. Tag must exist in `ollama list`." },
    { key: "api_base", label: "API base", placeholder: "http://localhost:11434/v1",
      help: "Trailing /v1 is required by LLMGateway's OllamaProvider." },
  ],
  openrouter: [
    { key: "model",    label: "Model (LiteLLM path)", placeholder: "openrouter/moonshotai/kimi-k2", required: true,
      help: "Prefix with openrouter/. Use the OpenRouter browser to pick from the catalog." },
    { key: "api_key",  label: "API key reference",  placeholder: "os.environ/OPENROUTER_API_KEY",
      help: "Defaults to the UI-managed key set in Providers → OpenRouter." },
  ],
  openai_compatible: [
    { key: "model",    label: "Model (LiteLLM path)", placeholder: "openai/<repo>/<name>", required: true },
    { key: "api_base", label: "API base", placeholder: "https://your-vllm-host/v1", required: true },
    { key: "api_key",  label: "API key (or env ref)", placeholder: "dummy", type: "password" },
  ],
  openai: [
    { key: "model",    label: "Model", placeholder: "openai/gpt-4o-mini", required: true },
    { key: "api_key",  label: "API key reference", placeholder: "os.environ/OPENAI_API_KEY" },
    { key: "api_base", label: "Custom base URL (optional)", placeholder: "leave empty for OpenAI default" },
  ],
  anthropic: [
    { key: "model",    label: "Model", placeholder: "anthropic/claude-3-5-sonnet-latest", required: true },
    { key: "api_key",  label: "API key reference", placeholder: "os.environ/ANTHROPIC_API_KEY" },
  ],
  bedrock: [
    { key: "model",           label: "Model", placeholder: "bedrock/anthropic.claude-3-5-sonnet-...", required: true },
    { key: "aws_region_name", label: "AWS region", placeholder: "us-east-1" },
    { key: "api_key",         label: "AWS key reference", placeholder: "os.environ/AWS_ACCESS_KEY_ID" },
  ],
  azure: [
    { key: "model",       label: "Deployment", placeholder: "azure/<deployment-name>", required: true },
    { key: "api_base",    label: "Endpoint", placeholder: "https://<resource>.openai.azure.com", required: true },
    { key: "api_version", label: "API version", placeholder: "2024-02-15-preview" },
    { key: "api_key",     label: "API key reference", placeholder: "os.environ/AZURE_API_KEY" },
  ],
  gemini: [
    { key: "model",   label: "Model", placeholder: "gemini/gemini-2.0-flash", required: true },
    { key: "api_key", label: "API key reference", placeholder: "os.environ/GEMINI_API_KEY" },
  ],
  vertex: [
    { key: "model",           label: "Model", placeholder: "vertex_ai/gemini-2.0-flash", required: true },
    { key: "vertex_project",  label: "GCP project", placeholder: "your-gcp-project" },
    { key: "vertex_location", label: "Location", placeholder: "us-central1" },
  ],
  groq: [
    { key: "model",   label: "Model", placeholder: "groq/llama-3.3-70b-versatile", required: true },
    { key: "api_key", label: "API key reference", placeholder: "os.environ/GROQ_API_KEY" },
  ],
  together: [
    { key: "model",   label: "Model", placeholder: "together_ai/meta-llama/Meta-Llama-3.1-70B-Instruct", required: true },
    { key: "api_key", label: "API key reference", placeholder: "os.environ/TOGETHER_API_KEY" },
  ],
  custom: [],   // Custom drops directly into Advanced (raw JSON) mode.
};

// model_info field schema — same shape, applied to all providers.
const MODEL_INFO_FIELDS: FieldSpec[] = [
  { key: "hosting",            label: "Hosting",
    type: "select", options: ["", "cloud", "local", "self-hosted", "local-ollama"],
    help: "Where the inference happens; surfaced in dashboards." },
  { key: "family",             label: "Family", placeholder: "claude, gpt-4o, llama, …" },
  { key: "max_input_tokens",   label: "Max input tokens",  placeholder: "128000" },
  { key: "cost_per_1k_input",  label: "Cost / 1k input ($)",  placeholder: "0.003" },
  { key: "cost_per_1k_output", label: "Cost / 1k output ($)", placeholder: "0.015" },
];

// Sensible defaults per provider — pre-filled in the Add form so a fresh
// operator can just tweak the model name.
function presetFor(provider: Provider): {
  litellm_params: Record<string, unknown>;
  model_info: ModelInfo;
} {
  switch (provider) {
    case "ollama":
      return {
        litellm_params: {
          model: "ollama_chat/<your-model>:<tag>",
          api_base: "http://localhost:11434",
        },
        model_info: { hosting: "local", cost_per_1k_input: 0, cost_per_1k_output: 0 },
      };
    case "openrouter":
      return {
        litellm_params: {
          model: "openrouter/<vendor>/<name>",
          api_key: "os.environ/OPENROUTER_API_KEY",
        },
        model_info: { hosting: "cloud" },
      };
    case "openai_compatible":
      return {
        litellm_params: {
          model: "openai/<repo>/<name>",
          api_base: "https://your-host/v1",
          api_key: "dummy",
        },
        model_info: { hosting: "self-hosted" },
      };
    case "openai":
      return {
        litellm_params: {
          model: "openai/gpt-4o-mini",
          api_key: "os.environ/OPENAI_API_KEY",
        },
        model_info: { hosting: "cloud", family: "gpt-4o" },
      };
    case "anthropic":
      return {
        litellm_params: {
          model: "anthropic/claude-3-5-sonnet-latest",
          api_key: "os.environ/ANTHROPIC_API_KEY",
        },
        model_info: { hosting: "cloud", family: "claude" },
      };
    case "bedrock":
      return {
        litellm_params: {
          model: "bedrock/anthropic.claude-3-5-sonnet-20240620-v1:0",
          aws_region_name: "us-east-1",
          api_key: "os.environ/AWS_ACCESS_KEY_ID",
        },
        model_info: {
          hosting: "cloud",
          family: "claude",
          max_input_tokens: 200_000,
          cost_per_1k_input: 0.003,
          cost_per_1k_output: 0.015,
        },
      };
    case "azure":
      return {
        litellm_params: {
          model: "azure/<your-deployment-name>",
          api_base: "https://<your-resource>.openai.azure.com",
          api_version: "2024-02-15-preview",
          api_key: "os.environ/AZURE_API_KEY",
        },
        model_info: {
          hosting: "cloud",
          family: "gpt-4o",
          max_input_tokens: 128_000,
          cost_per_1k_input: 0.0025,
          cost_per_1k_output: 0.01,
        },
      };
    case "gemini":
      return {
        litellm_params: {
          model: "gemini/gemini-2.0-flash",
          api_key: "os.environ/GEMINI_API_KEY",
        },
        model_info: {
          hosting: "cloud",
          family: "gemini",
          max_input_tokens: 1_000_000,
          cost_per_1k_input: 0.0001,
          cost_per_1k_output: 0.0004,
        },
      };
    case "vertex":
      return {
        litellm_params: {
          model: "vertex_ai/gemini-2.0-flash",
          vertex_project: "<your-gcp-project>",
          vertex_location: "us-central1",
        },
        model_info: {
          hosting: "cloud",
          family: "gemini",
          max_input_tokens: 1_000_000,
          cost_per_1k_input: 0.0001,
          cost_per_1k_output: 0.0004,
        },
      };
    case "groq":
      return {
        litellm_params: {
          model: "groq/llama-3.3-70b-versatile",
          api_key: "os.environ/GROQ_API_KEY",
        },
        model_info: {
          hosting: "cloud",
          family: "llama",
          max_input_tokens: 128_000,
          cost_per_1k_input: 0.0008,
          cost_per_1k_output: 0.0008,
        },
      };
    case "together":
      return {
        litellm_params: {
          model: "together_ai/meta-llama/Meta-Llama-3.1-70B-Instruct",
          api_key: "os.environ/TOGETHER_API_KEY",
        },
        model_info: {
          hosting: "cloud",
          family: "llama",
          max_input_tokens: 128_000,
          cost_per_1k_input: 0.0009,
          cost_per_1k_output: 0.0009,
        },
      };
    default:
      return { litellm_params: {}, model_info: {} };
  }
}

// Mask api_key values so a leaked key in the YAML isn't displayed verbatim.
// Strings starting with `os.environ/` are env-var references, not secrets,
// so show them as-is — that's useful context.
function maskKey(v: unknown): string {
  if (typeof v !== "string") return String(v);
  if (v.startsWith("os.environ/")) return v;
  if (v.length <= 4) return "...";
  return v.slice(0, 4) + "...";
}

function safeJson(value: unknown): string {
  try { return JSON.stringify(value ?? {}, null, 2); }
  catch { return "{}"; }
}

// Shallow-clone an arbitrary JSON-ish object so editing the form state
// doesn't mutate the prop. structuredClone is available in modern
// browsers; we fall back to JSON round-trip when not.
function structuredCloneSafe<T>(v: T): T {
  try {
    if (typeof structuredClone === "function") return structuredClone(v);
  } catch { /* fall through */ }
  try { return JSON.parse(JSON.stringify(v)); }
  catch { return v; }
}

// Single typed input. Renders text / password / select per the FieldSpec.
function TypedField({
  spec, value, onChange,
}: {
  spec: FieldSpec;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="space-y-1">
      <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {spec.label}
        {spec.required && <span className="ml-1 text-destructive">*</span>}
      </label>
      {spec.type === "select" ? (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
        >
          {(spec.options ?? []).map((opt) => (
            <option key={opt || "_empty"} value={opt}>{opt || "—"}</option>
          ))}
        </select>
      ) : (
        <Input
          type={spec.type === "password" ? "password" : "text"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={spec.placeholder}
          className={spec.key === "model" || spec.key === "api_base"
            ? "font-mono text-xs"
            : "text-sm"}
          spellCheck={false}
          autoComplete="off"
        />
      )}
      {spec.help && (
        <div className="text-[11px] leading-snug text-muted-foreground">
          {spec.help}
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------------------
// Page
// -------------------------------------------------------------------------

export default function ModelsPage() {
  const [models, setModels] = useState<ModelItem[] | null>(null);
  const [err, setErr]       = useState<string | null>(null);
  const [info, setInfo]     = useState<string | null>(null);
  const [busy, setBusy]     = useState<string | null>(null);
  const [reloading, setReloading] = useState(false);

  // Form state — null means closed, "new" means add-new, otherwise the id
  // of the model being edited.
  const [formMode, setFormMode] = useState<null | "new" | string>(null);
  // OpenRouter catalog browser modal — opens from the page-level "Browse
  // OpenRouter" button. Closes after a successful import (which auto-
  // reloads the model list).
  const [orBrowserOpen, setOrBrowserOpen] = useState(false);

  const reload = useCallback(async () => {
    try {
      const r = await fetch(`${GW}/admin/models?include_disabled=true`, {
        headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data: ModelItem[] = await r.json();
      setModels(data);
      setErr(null);
    } catch (e) {
      setErr(String(e));
    }
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  const counts = useMemo(() => {
    if (!models) return { enabled: 0, total: 0 };
    return {
      enabled: models.filter((m) => m.enabled).length,
      total: models.length,
    };
  }, [models]);

  const toggleEnabled = async (m: ModelItem) => {
    const id = String(m.id);
    setBusy(id);
    try {
      const r = await fetch(`${GW}/admin/models/${id}`, {
        method: "PATCH",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({ enabled: !m.enabled }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const updated: ModelItem = await r.json();
      setModels((prev) =>
        prev ? prev.map((x) => (String(x.id) === id ? updated : x)) : prev,
      );
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusy(null);
    }
  };

  const removeModel = async (m: ModelItem) => {
    if (!confirm(`Delete model "${m.model_name}"? This is immediate and removes it from the live router.`)) return;
    const id = String(m.id);
    setBusy(id);
    try {
      const r = await fetch(`${GW}/admin/models/${id}`, {
        method: "DELETE", credentials: "same-origin",
      });
      if (!r.ok && r.status !== 204) throw new Error(`${r.status} ${r.statusText}`);
      setModels((prev) => (prev ? prev.filter((x) => String(x.id) !== id) : prev));
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusy(null);
    }
  };

  const reloadRouter = async () => {
    setReloading(true);
    try {
      const r = await fetch(`${GW}/admin/models/reload`, {
        method: "POST", credentials: "same-origin", headers: JSON_HEADERS,
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data = await r.json();
      setInfo(`Router reloaded — ${data?.models_loaded ?? "?"} models loaded`);
      setTimeout(() => setInfo(null), 4000);
      await reload();
    } catch (e) {
      setErr(String(e));
    } finally {
      setReloading(false);
    }
  };

  const editingModel = useMemo(() => {
    if (!formMode || formMode === "new" || !models) return null;
    return models.find((m) => String(m.id) === formMode) ?? null;
  }, [formMode, models]);

  return (
    <div className="space-y-4">
      {/* Heading — layout-owned page title sits above the tab strip; this
          card-level header describes just the Models tab. */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="section-title">Models</h2>
          <p className="section-subtitle">
            Enable, disable, edit, or add backends — changes hot-reload the live router.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="accent" className="px-3 py-1">
            {counts.enabled} enabled / {counts.total} total
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setOrBrowserOpen(true)}
            title="Browse OpenRouter's catalog and add a model in one click"
          >
            <Search className="mr-1 h-3.5 w-3.5" />
            Browse OpenRouter
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={reloadRouter}
            disabled={reloading}
            title="Re-read the YAML from disk. Not normally needed — every CUD already reloads server-side."
          >
            <RefreshCw className={"mr-1 h-3.5 w-3.5 " + (reloading ? "animate-spin" : "")} />
            {reloading ? "Reloading…" : "Reload router"}
          </Button>
          <Button
            variant="accent"
            size="sm"
            onClick={() => setFormMode((m) => (m === "new" ? null : "new"))}
          >
            {formMode === "new" ? (
              <><X className="mr-1 h-3.5 w-3.5" /> Cancel</>
            ) : (
              <><Plus className="mr-1 h-3.5 w-3.5" /> Add model</>
            )}
          </Button>
        </div>
      </div>

      {info && (
        <Card className="border-accent/40">
          <CardContent className="p-3 text-sm text-accent-foreground">{info}</CardContent>
        </Card>
      )}

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">Error: {err}</CardContent>
        </Card>
      )}

      {/* Provider API keys live in /settings/app (App settings tab). */}

      {/* Add form */}
      {formMode === "new" && (
        <ModelForm
          mode="new"
          onCancel={() => setFormMode(null)}
          onSaved={async () => {
            setFormMode(null);
            await reload();
          }}
        />
      )}

      {/* List */}
      {!models ? (
        <Card>
          <CardContent className="p-5 text-sm text-muted-foreground">Loading…</CardContent>
        </Card>
      ) : models.length === 0 ? (
        <Card>
          <CardContent className="p-5 text-sm text-muted-foreground">
            No models registered yet. Click <span className="font-medium text-foreground">Add model</span> to get started.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {models.map((m) => {
            const id = String(m.id);
            const isEditing = formMode === id;
            return (
              <div key={id} className="space-y-3">
                <ModelCard
                  model={m}
                  busy={busy === id}
                  isEditing={isEditing}
                  onToggle={() => toggleEnabled(m)}
                  onEdit={() => setFormMode((cur) => (cur === id ? null : id))}
                  onDelete={() => removeModel(m)}
                />
                {isEditing && editingModel && (
                  <ModelForm
                    mode="edit"
                    initial={editingModel}
                    onCancel={() => setFormMode(null)}
                    onSaved={async () => {
                      setFormMode(null);
                      await reload();
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* OpenRouter catalog browser — modal. */}
      <OpenRouterBrowser
        open={orBrowserOpen}
        onClose={() => setOrBrowserOpen(false)}
        onImported={async (name) => {
          setInfo(`Imported ${name} from OpenRouter`);
          setTimeout(() => setInfo(null), 4000);
          await reload();
        }}
      />
    </div>
  );
}

// -------------------------------------------------------------------------
// ModelCard — read-only display of one model entry.
// -------------------------------------------------------------------------

function ModelCard({
  model, busy, isEditing, onToggle, onEdit, onDelete,
}: {
  model: ModelItem;
  busy: boolean;
  isEditing: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const p = model.litellm_params ?? {};
  const variant = PROVIDER_VARIANT[model.provider] ?? "default";
  const info = model.model_info ?? {};

  // ----- Ping diagnostics -----
  // Per-row state, scoped to this card. Success pills self-dismiss after
  // ~6s; failure pills stay until the operator dismisses them so a flaky
  // backend isn't lost while they scroll down the page.
  const [pingState, setPingState] = useState<
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "ok"; latency_ms: number }
    | { kind: "fail"; error: string; latency_ms: number }
  >({ kind: "idle" });
  const [errorExpanded, setErrorExpanded] = useState(false);
  const fadeTimerRef = useRef<number | null>(null);

  // Clear any pending success-fade timer on unmount so we don't try to set
  // state on a card the user already navigated away from.
  useEffect(() => () => {
    if (fadeTimerRef.current !== null) window.clearTimeout(fadeTimerRef.current);
  }, []);

  const runPing = async () => {
    if (fadeTimerRef.current !== null) {
      window.clearTimeout(fadeTimerRef.current);
      fadeTimerRef.current = null;
    }
    setErrorExpanded(false);
    setPingState({ kind: "loading" });
    try {
      const r = await fetch(`${GW}/admin/models/${model.id}/ping`, {
        method: "POST", credentials: "same-origin", headers: JSON_HEADERS,
      });
      // Soft-failures land as 200 with ok=false; hard HTTP errors (e.g.
      // 404 model-not-found, 503 router-not-ready) we render the same way
      // so the operator gets a uniform red pill.
      if (!r.ok) {
        const text = await r.text().catch(() => "");
        setPingState({
          kind: "fail",
          error: `${r.status} ${r.statusText}${text ? ` — ${text}` : ""}`,
          latency_ms: 0,
        });
        return;
      }
      const j = (await r.json()) as ModelPingResponse;
      if (j.ok) {
        setPingState({ kind: "ok", latency_ms: j.latency_ms });
        fadeTimerRef.current = window.setTimeout(() => {
          setPingState({ kind: "idle" });
          fadeTimerRef.current = null;
        }, 6000);
      } else {
        setPingState({
          kind: "fail",
          error: j.error ?? "ping returned ok=false with no error message",
          latency_ms: j.latency_ms,
        });
      }
    } catch (e) {
      setPingState({ kind: "fail", error: String(e), latency_ms: 0 });
    }
  };

  const pingLoading = pingState.kind === "loading";

  // Pull the well-known summary keys out for display. Anything else stays
  // hidden behind the Edit form so the card doesn't become a YAML dump.
  const summary: { k: string; v: string; mask?: boolean }[] = [];
  if (typeof p.model    === "string") summary.push({ k: "model",    v: p.model });
  if (typeof p.api_base === "string") summary.push({ k: "api_base", v: p.api_base });
  if ("api_key" in p)                 summary.push({ k: "api_key",  v: maskKey(p.api_key), mask: true });

  return (
    <Card className={isEditing ? "ring-1 ring-accent/40" : undefined}>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0">
        <div className="flex flex-1 items-center gap-2">
          <Badge variant={variant}>{model.provider}</Badge>
          <span className="font-mono text-sm font-medium tracking-tight">{model.model_name}</span>
          {!model.enabled && (
            <Badge variant="secondary" className="opacity-80">disabled</Badge>
          )}
        </div>
        <button
          onClick={onToggle}
          disabled={busy}
          aria-label={model.enabled ? "Disable model" : "Enable model"}
          className={
            "relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border border-border/70 transition-colors " +
            (model.enabled ? "bg-accent" : "bg-secondary") +
            (busy ? " opacity-50" : "")
          }
        >
          <span
            className={
              "inline-block h-4 w-4 transform rounded-full bg-background shadow transition-transform " +
              (model.enabled ? "translate-x-4" : "translate-x-0.5")
            }
          />
        </button>
      </CardHeader>
      <CardContent className="space-y-3">
        {summary.length > 0 && (
          <div className="rounded-md border border-border/60 bg-background/40 px-3 py-2 font-mono text-xs leading-relaxed">
            {summary.map((row) => (
              <div key={row.k} className="flex gap-2">
                <span className="w-20 shrink-0 text-muted-foreground">{row.k}:</span>
                <span className={row.mask ? "text-muted-foreground" : ""}>{row.v}</span>
              </div>
            ))}
          </div>
        )}

        {/* Optional model_info chips */}
        {(info.hosting || info.family
          || info.max_input_tokens != null
          || info.cost_per_1k_input != null
          || info.cost_per_1k_output != null) && (
          <div className="flex flex-wrap gap-1.5">
            {info.hosting && <Badge variant="outline">hosting: {info.hosting}</Badge>}
            {info.family  && <Badge variant="outline">family: {info.family}</Badge>}
            {info.max_input_tokens != null && (
              <Badge variant="outline">ctx: {info.max_input_tokens.toLocaleString()}</Badge>
            )}
            {info.cost_per_1k_input != null && (
              <Badge variant="outline">in: ${info.cost_per_1k_input}/1k</Badge>
            )}
            {info.cost_per_1k_output != null && (
              <Badge variant="outline">out: ${info.cost_per_1k_output}/1k</Badge>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
          {/* Ping result pill — left of the action buttons. Success fades
              after ~6s, failure stays until the operator clicks again. */}
          <PingPill
            state={pingState}
            expanded={errorExpanded}
            onToggleExpand={() => setErrorExpanded((v) => !v)}
            onDismiss={() => {
              setErrorExpanded(false);
              setPingState({ kind: "idle" });
            }}
          />
          <Button
            size="sm"
            variant="outline"
            onClick={runPing}
            disabled={busy || pingLoading || !model.enabled}
            title={
              model.enabled
                ? "Send a 1-token completion through this model to verify the backend is reachable."
                : "Enable the model to ping it."
            }
          >
            {pingLoading ? (
              <RefreshCw className="mr-1 h-3.5 w-3.5 animate-spin" />
            ) : (
              <Zap className="mr-1 h-3.5 w-3.5" />
            )}
            {pingLoading ? "Pinging…" : "Ping"}
          </Button>
          <Button size="sm" variant="ghost" onClick={onEdit} disabled={busy}>
            <Pencil className="mr-1 h-3.5 w-3.5" /> {isEditing ? "Close" : "Edit"}
          </Button>
          <Button size="sm" variant="destructive" onClick={onDelete} disabled={busy}>
            <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// ModelForm — used for both "add new" and "edit existing".
// -------------------------------------------------------------------------

function ModelForm({
  mode, initial, onCancel, onSaved,
}: {
  mode: "new" | "edit";
  initial?: ModelItem;
  onCancel: () => void;
  onSaved: () => Promise<void> | void;
}) {
  const [provider, setProvider]   = useState<Provider>(initial?.provider ?? "ollama");
  const [modelName, setModelName] = useState(initial?.model_name ?? "");

  // Typed form state is the source of truth. We hydrate from the initial
  // record's JSON (in edit mode) or the preset (in new mode) and serialize
  // back to JSON at submit. The Advanced toggle dumps the live JSON into
  // the textarea for power-user edits — when the operator flips back, we
  // re-parse to re-hydrate the typed fields.
  const initialParams = initial?.litellm_params
    ?? presetFor(initial?.provider ?? "ollama").litellm_params;
  const initialInfo   = (initial?.model_info as Record<string, unknown> | null | undefined)
    ?? presetFor(initial?.provider ?? "ollama").model_info;

  const [params, setParams] = useState<Record<string, unknown>>(
    structuredCloneSafe(initialParams),
  );
  const [info, setInfo]     = useState<Record<string, unknown>>(
    structuredCloneSafe(initialInfo ?? {}),
  );

  // Raw JSON view: used by `custom` provider, or when the operator flips
  // the Advanced toggle. Mirrors `params` / `info` until they edit it.
  const [advanced, setAdvanced]   = useState<boolean>(
    (initial?.provider ?? "ollama") === "custom",
  );
  const [paramsText, setParamsText] = useState(safeJson(initialParams));
  const [infoText, setInfoText]     = useState(safeJson(initialInfo ?? {}));

  const [enabled, setEnabled] = useState(initial?.enabled ?? true);
  const [submitting, setSubmitting] = useState(false);
  const [formErr, setFormErr] = useState<string | null>(null);
  const [nameErr, setNameErr] = useState<string | null>(null);

  // When the operator picks a different provider in NEW mode, swap in the
  // preset for both views. In EDIT mode we keep their record alone — clicking
  // the provider pill must not silently rewrite saved config.
  const onPickProvider = (p: Provider) => {
    setProvider(p);
    if (mode === "new") {
      const preset = presetFor(p);
      setParams(structuredCloneSafe(preset.litellm_params));
      setInfo(structuredCloneSafe(preset.model_info ?? {}));
      setParamsText(safeJson(preset.litellm_params));
      setInfoText(safeJson(preset.model_info ?? {}));
    }
    // `custom` only has a JSON editor by design.
    if (p === "custom") setAdvanced(true);
  };

  // Flip Advanced on: copy typed state into the textareas.
  // Flip Advanced off: parse the textareas back into typed state.
  const toggleAdvanced = () => {
    if (!advanced) {
      setParamsText(safeJson(params));
      setInfoText(safeJson(info));
      setAdvanced(true);
      return;
    }
    try {
      const p = JSON.parse(paramsText || "{}");
      const i = (infoText || "").trim() ? JSON.parse(infoText) : {};
      if (typeof p !== "object" || p === null || Array.isArray(p)) {
        throw new Error("litellm_params must be a JSON object");
      }
      if (typeof i !== "object" || i === null || Array.isArray(i)) {
        throw new Error("model_info must be a JSON object");
      }
      setParams(p);
      setInfo(i);
      setAdvanced(false);
      setFormErr(null);
    } catch (e) {
      setFormErr(`Cannot leave Advanced mode: ${String(e)}`);
    }
  };

  const setParamField = (key: string, value: string) => {
    setParams((p) => ({ ...p, [key]: value }));
  };
  const setInfoField = (key: string, value: string) => {
    // Numeric coercion for the cost / token fields.
    const numericKeys = new Set(["max_input_tokens", "cost_per_1k_input", "cost_per_1k_output"]);
    if (numericKeys.has(key)) {
      if (value === "") { const c = { ...info }; delete c[key]; setInfo(c); return; }
      const n = Number(value);
      setInfo((p) => ({ ...p, [key]: Number.isFinite(n) ? n : value }));
      return;
    }
    if (value === "") {
      const c = { ...info }; delete c[key]; setInfo(c); return;
    }
    setInfo((p) => ({ ...p, [key]: value }));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    setNameErr(null);

    // Resolve params/info from whichever editor is active.
    let parsedParams: Record<string, unknown>;
    let parsedInfo:   Record<string, unknown> | null;
    if (advanced) {
      try {
        parsedParams = JSON.parse(paramsText || "{}");
        if (typeof parsedParams !== "object" || Array.isArray(parsedParams) || parsedParams === null) {
          throw new Error("litellm_params must be a JSON object");
        }
      } catch (e) {
        setFormErr(`litellm_params: ${String(e)}`);
        return;
      }
      try {
        const t = (infoText || "").trim();
        parsedInfo = t ? JSON.parse(t) : null;
        if (parsedInfo !== null && (typeof parsedInfo !== "object" || Array.isArray(parsedInfo))) {
          throw new Error("model_info must be a JSON object or empty");
        }
      } catch (e) {
        setFormErr(`model_info: ${String(e)}`);
        return;
      }
    } else {
      // Build params from the typed form — drop empty-string values so a
      // blank "API base" input doesn't ship `"api_base": ""` to the gateway.
      parsedParams = Object.fromEntries(
        Object.entries(params).filter(([, v]) =>
          !(typeof v === "string" && v.trim() === ""),
        ),
      );
      const infoEntries = Object.entries(info).filter(([, v]) =>
        !(typeof v === "string" && v.trim() === ""),
      );
      parsedInfo = infoEntries.length ? Object.fromEntries(infoEntries) : null;
    }

    setSubmitting(true);
    try {
      const body: Record<string, unknown> = {
        model_name: modelName.trim(),
        provider,
        litellm_params: parsedParams,
        enabled,
      };
      if (parsedInfo) body.model_info = parsedInfo;

      const url = mode === "new"
        ? `${GW}/admin/models`
        : `${GW}/admin/models/${initial?.id}`;
      const r = await fetch(url, {
        method: mode === "new" ? "POST" : "PATCH",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify(body),
      });
      if (r.status === 409) {
        setNameErr("model_name already exists");
        return;
      }
      if (!r.ok) {
        const text = await r.text().catch(() => "");
        throw new Error(`${r.status} ${r.statusText}${text ? ` — ${text}` : ""}`);
      }
      await onSaved();
    } catch (e) {
      setFormErr(String(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="border-accent/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Boxes className="h-4 w-4 text-accent" />
          {mode === "new" ? "Add a model" : `Edit ${initial?.model_name ?? ""}`}
        </CardTitle>
        <CardDescription>
          Pick a provider to pre-fill sensible defaults. You can edit the raw JSON below before saving.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          {/* Provider pills */}
          <div className="space-y-1">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Provider</label>
            <div className="flex flex-wrap gap-1.5">
              {PROVIDERS.map((p) => {
                const active = provider === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => onPickProvider(p.id)}
                    className={
                      // Active = solid accent fill + white text (full
                      // contrast in every theme). Non-active = solid
                      // card surface with foreground text — was
                      // text-muted-foreground which washed out to
                      // unreadable on the light theme's white bg.
                      "rounded-md border px-3 py-1.5 text-xs font-medium tracking-tight transition-colors " +
                      (active
                        ? "border-accent bg-accent text-accent-foreground shadow-sm"
                        : "border-border bg-card text-foreground hover:bg-secondary")
                    }
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Name + Enabled */}
          <div className="grid gap-3 md:grid-cols-3">
            <div className="md:col-span-2 space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Model name (external)
              </label>
              <Input
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                placeholder="qwen2.5-coder-7b"
                required
                className="font-mono"
              />
              {nameErr && <div className="text-xs text-destructive">{nameErr}</div>}
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Enabled</label>
              <button
                type="button"
                onClick={() => setEnabled((v) => !v)}
                aria-label={enabled ? "Disable" : "Enable"}
                className={
                  "flex h-10 w-full items-center justify-between rounded-md border border-border/70 bg-background/60 px-3 text-sm transition-colors hover:bg-secondary/40"
                }
              >
                <span className={enabled ? "text-foreground" : "text-muted-foreground"}>
                  {enabled ? "On — routable" : "Off — registered but unrouted"}
                </span>
                <span
                  className={
                    "relative inline-flex h-5 w-9 items-center rounded-full border border-border/70 " +
                    (enabled ? "bg-accent" : "bg-secondary")
                  }
                >
                  <span
                    className={
                      "inline-block h-4 w-4 transform rounded-full bg-background shadow transition-transform " +
                      (enabled ? "translate-x-4" : "translate-x-0.5")
                    }
                  />
                </span>
              </button>
            </div>
          </div>

          {/* Form / Advanced (raw JSON) toggle */}
          <div className="flex items-center justify-between border-b border-border pb-2">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {advanced ? "Configuration (raw JSON)" : "Configuration"}
            </div>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={toggleAdvanced}
              title={advanced ? "Switch to form fields" : "Edit as raw JSON"}
              disabled={provider === "custom"}
            >
              {advanced
                ? <><FormInput className="mr-1 h-3.5 w-3.5" /> Form fields</>
                : <><Code className="mr-1 h-3.5 w-3.5" /> Advanced JSON</>}
            </Button>
          </div>

          {advanced ? (
            <>
              <div className="space-y-1">
                <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  litellm_params (JSON)
                </label>
                <textarea
                  value={paramsText}
                  onChange={(e) => setParamsText(e.target.value)}
                  spellCheck={false}
                  rows={Math.min(14, Math.max(6, paramsText.split("\n").length + 1))}
                  className="flex w-full rounded-md border border-input bg-background/60 px-3 py-2 font-mono text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  model_info (JSON · optional)
                </label>
                <textarea
                  value={infoText}
                  onChange={(e) => setInfoText(e.target.value)}
                  spellCheck={false}
                  rows={5}
                  className="flex w-full rounded-md border border-input bg-background/60 px-3 py-2 font-mono text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                />
              </div>
            </>
          ) : (
            <>
              {/* Per-provider typed fields */}
              <div className="space-y-3">
                <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                  {PROVIDER_FIELDS[provider].length} field{PROVIDER_FIELDS[provider].length === 1 ? "" : "s"}
                </div>
                {PROVIDER_FIELDS[provider].length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    No typed fields defined for this provider — use Advanced JSON.
                  </p>
                ) : (
                  <div className="grid gap-3 md:grid-cols-2">
                    {PROVIDER_FIELDS[provider].map((spec) => (
                      <TypedField
                        key={spec.key}
                        spec={spec}
                        value={(params[spec.key] as string | undefined) ?? ""}
                        onChange={(v) => setParamField(spec.key, v)}
                      />
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-3 border-t border-border pt-3">
                <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                  Model metadata (optional)
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  {MODEL_INFO_FIELDS.map((spec) => (
                    <TypedField
                      key={spec.key}
                      spec={spec}
                      value={(info[spec.key] != null ? String(info[spec.key]) : "")}
                      onChange={(v) => setInfoField(spec.key, v)}
                    />
                  ))}
                </div>
              </div>
            </>
          )}

          {formErr && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
              {formErr}
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={onCancel} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" variant="accent" disabled={submitting || !modelName.trim()}>
              {submitting
                ? (mode === "new" ? "Creating…" : "Saving…")
                : (mode === "new" ? "Create model" : "Save changes")}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// PingPill — result chip for the per-row Ping button.
//
// Green pill for ok, red for fail. Failure pills are clickable to expand
// the full error in a small popover (errors are truncated to ~80 chars
// in the pill so a 500-char Python traceback doesn't blow up the row).
// -------------------------------------------------------------------------

type PingPillState =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "ok"; latency_ms: number }
  | { kind: "fail"; error: string; latency_ms: number };

const PING_ERROR_PILL_MAX = 80;

function PingPill({
  state, expanded, onToggleExpand, onDismiss,
}: {
  state: PingPillState;
  expanded: boolean;
  onToggleExpand: () => void;
  onDismiss: () => void;
}) {
  if (state.kind === "idle" || state.kind === "loading") return null;

  if (state.kind === "ok") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-full border border-oati-success/40 bg-oati-success/10 px-2 py-0.5 font-mono text-[11px] text-oati-success transition-opacity"
        role="status"
      >
        <Check className="h-3 w-3" />
        OK · {Math.round(state.latency_ms)}ms
      </span>
    );
  }

  // Failure — truncate for the pill, expose full message via click-to-expand.
  const full = state.error;
  const truncated =
    full.length > PING_ERROR_PILL_MAX ? full.slice(0, PING_ERROR_PILL_MAX) + "…" : full;

  return (
    <span className="relative inline-flex items-center gap-1">
      <button
        type="button"
        onClick={onToggleExpand}
        className="inline-flex max-w-[28ch] items-center gap-1 truncate rounded-full border border-destructive/40 bg-destructive/10 px-2 py-0.5 font-mono text-[11px] text-destructive hover:bg-destructive/15"
        title={full}
        aria-expanded={expanded}
      >
        <X className="h-3 w-3 shrink-0" />
        <span className="truncate">FAIL · {truncated}</span>
      </button>
      <button
        type="button"
        onClick={onDismiss}
        aria-label="Dismiss ping error"
        className="inline-flex h-5 w-5 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary"
        title="Dismiss"
      >
        <X className="h-3 w-3" />
      </button>
      {expanded && (
        <div
          role="dialog"
          className="absolute right-0 top-full z-10 mt-1 w-[min(28rem,90vw)] rounded-md border border-destructive/40 bg-popover p-3 font-mono text-[11px] leading-relaxed text-destructive shadow-md"
        >
          <div className="mb-1 flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Ping error · {Math.round(state.latency_ms)}ms
            </span>
            <button
              type="button"
              onClick={onToggleExpand}
              aria-label="Close error details"
              className="inline-flex h-5 w-5 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
          <div className="max-h-48 overflow-auto whitespace-pre-wrap break-words">
            {full}
          </div>
        </div>
      )}
    </span>
  );
}
