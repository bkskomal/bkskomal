"use client";

import { useCallback, useEffect, useState } from "react";
import { DollarSign, Loader2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ProvidersCard } from "@/components/providers-card";
import { SmtpCard } from "@/components/smtp-card";
import {
  refreshCostVisible, setCostVisible, useCostVisible,
} from "@/components/cost-visibility";

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

export default function AppSettingsPage() {
  return (
    <div className="space-y-4">
      <CostMetricsCard />
      <ProvidersCard />
      <SmtpCard />
    </div>
  );
}

// Master cost-visibility toggle. Off by default. When off:
//   * /metrics hides Total spend, Cost forecast, Spend by model
//   * Dashboard hides the Usage cost row
//   * Spend-by-team table hides the cost column
// Server-side calculation runs only when on, so an idle install pays
// no DB-scan cost for a feature it isn't using.
function CostMetricsCard() {
  const enabled = useCostVisible();
  const [saving, setSaving] = useState(false);
  const [err, setErr]       = useState<string | null>(null);

  const setEnabled = useCallback(async (next: boolean) => {
    setSaving(true);
    setErr(null);
    try {
      const r = await fetch(`${GW}/admin/settings/spend-by-model`, {
        method: "PUT", credentials: "same-origin", headers: JSON_HEADERS,
        body: JSON.stringify({ enabled: next }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const j = await r.json() as { enabled: boolean };
      setCostVisible(!!j.enabled);
    } catch (e) {
      setErr(String(e));
      // Re-sync from server in case the toggle is now out of sync.
      void refreshCostVisible();
    } finally {
      setSaving(false);
    }
  }, []);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-[15px]">
          <DollarSign className="h-4 w-4 text-accent" />
          Cost metrics
        </CardTitle>
        <CardDescription>
          When enabled, the admin UI surfaces every dollar amount, cost-per-token,
          and the Spend-by-model card on the Metrics page. Off by default —
          flip it on once you&apos;ve wired up priced models (OpenRouter, OpenAI, etc).
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between rounded-md border border-border bg-background/40 p-3">
          <div>
            <div className="text-[13px] font-medium">Show cost / spend metrics in UI</div>
            <div className="text-[11px] text-muted-foreground">
              Hides every USD-denominated value across the app. The audit log
              still records cost for billing reconciliation.
            </div>
          </div>
          <ToggleSwitch
            enabled={!!enabled}
            loading={enabled === null || saving}
            onClick={() => setEnabled(!enabled)}
          />
        </div>
        {err && (
          <div className="text-[11px] text-destructive">{err}</div>
        )}
      </CardContent>
    </Card>
  );
}

function ToggleSwitch({
  enabled, loading, onClick,
}: {
  enabled: boolean;
  loading: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={loading}
      aria-pressed={enabled}
      className={
        "inline-flex items-center gap-2 rounded-full border px-2 py-1 text-[11px] font-medium transition-colors " +
        (enabled
          ? "border-accent/40 bg-accent/15 text-accent-foreground"
          : "border-border bg-background/60 text-muted-foreground hover:bg-secondary/40") +
        (loading ? " cursor-wait opacity-70" : "")
      }
    >
      <span
        aria-hidden
        className={
          "inline-block h-3.5 w-7 rounded-full transition-colors " +
          (enabled ? "bg-accent" : "bg-border")
        }
      >
        <span
          className={
            "block h-3.5 w-3.5 rounded-full bg-background shadow-sm transition-transform " +
            (enabled ? "translate-x-[14px]" : "translate-x-0")
          }
        />
      </span>
      <span className="tabular-nums">
        {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : (enabled ? "Enabled" : "Disabled")}
      </span>
    </button>
  );
}
