"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Boxes, Settings as SettingsIcon } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { href: "/settings/models", label: "Models",       icon: Boxes },
  { href: "/settings/app",    label: "App settings", icon: SettingsIcon },
];

// Tabbed shell shared by every /settings/* child route. Tab "active"
// state is derived from the path (no client state) so deep-linking and
// browser-back both work without surprises.
export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname() || "";

  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">
          Manage models, provider keys, and app-wide preferences.
        </p>
      </div>

      <div className="border-b border-border">
        <nav className="-mb-px flex flex-wrap items-end gap-1" aria-label="Settings tabs">
          {TABS.map((t) => {
            const active = pathname.startsWith(t.href);
            const Icon = t.icon;
            return (
              <Link
                key={t.href}
                href={t.href}
                className={cn(
                  "inline-flex items-center gap-1.5 border-b-2 px-3 py-2 text-[13px] font-medium transition-colors",
                  active
                    ? "border-accent text-foreground"
                    : "border-transparent text-muted-foreground hover:border-border hover:text-foreground",
                )}
                aria-current={active ? "page" : undefined}
              >
                <Icon className="h-3.5 w-3.5" />
                {t.label}
              </Link>
            );
          })}
        </nav>
      </div>

      <div>{children}</div>
    </div>
  );
}
