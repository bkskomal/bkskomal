import { redirect } from "next/navigation";

// /settings is a tabbed surface — the default tab is Models. We redirect
// at the route level (server-side) so the URL bar always shows the
// canonical tab path, which is also what every link in the app points at.
export default function SettingsIndexPage(): never {
  redirect("/settings/models");
}
