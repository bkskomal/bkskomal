"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Activity, AlertTriangle, BellRing, CheckCircle2, ExternalLink,
  Gauge, RefreshCw, XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

// Service URLs as seen from the *browser*. These are intentionally the
// host-side ports the docker-compose obs profile publishes — the iframe
// loads in the user's browser, not from the admin-ui server, so the
// container hostnames (`prometheus`, `grafana`) are not reachable here.
// Override via NEXT_PUBLIC_GRAFANA_URL / NEXT_PUBLIC_PROMETHEUS_URL /
// NEXT_PUBLIC_ALERTMANAGER_URL when deploying behind a reverse proxy.
const GRAFANA_URL      = process.env.NEXT_PUBLIC_GRAFANA_URL      ?? "http://localhost:3001";
const PROMETHEUS_URL   = process.env.NEXT_PUBLIC_PROMETHEUS_URL   ?? "http://localhost:9090";
const ALERTMANAGER_URL = process.env.NEXT_PUBLIC_ALERTMANAGER_URL ?? "http://localhost:9093";

// Provisioned dashboard UIDs come from docs/grafana/{operations,security}.json.
// `kiosk=tv` strips the top nav so the embed feels native; theme=dark keeps
// it visually aligned with the admin shell.
const DASHBOARDS = [
  { id: "ops", uid: "litellm-gateway-ops", slug: "litellm-gateway-operations", label: "Operations",
    description: "Request rate, latency, token throughput, cost." },
  { id: "sec", uid: "litellm-gateway-sec", slug: "litellm-gateway-security",   label: "Security",
    description: "DLP hits, secret leaks, refusals, UEBA signals." },
] as const;

type ServiceProbe = {
  name:   string;
  url:    string;
  href:   string;
  status: "checking" | "up" | "down";
  icon:   typeof Gauge;
};

export default function ObservabilityPage() {
  const [active, setActive]   = useState<typeof DASHBOARDS[number]>(DASHBOARDS[0]);
  const [refreshNonce, setRefreshNonce] = useState(0);
  const [probes, setProbes]   = useState<ServiceProbe[]>([
    { name: "Grafana",      url: `${GRAFANA_URL}/api/health`,         href: GRAFANA_URL,      status: "checking", icon: Gauge },
    { name: "Prometheus",   url: `${PROMETHEUS_URL}/-/healthy`,       href: PROMETHEUS_URL,   status: "checking", icon: Activity },
    { name: "Alertmanager", url: `${ALERTMANAGER_URL}/-/healthy`,     href: ALERTMANAGER_URL, status: "checking", icon: BellRing },
  ]);

  // Cross-origin probe — we can't read the response (CORS-opaque), but a
  // successful network response is enough to mark the service "up". A
  // network failure (DNS, refused, timeout) flips it to "down". `no-cors`
  // keeps the browser from logging the opaque-response warning as red.
  const probeAll = useMemo(() => async () => {
    setProbes((ps) => ps.map((p) => ({ ...p, status: "checking" })));
    const next = await Promise.all(probes.map(async (p) => {
      try {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), 2500);
        await fetch(p.url, { mode: "no-cors", signal: ctl.signal, cache: "no-store" });
        clearTimeout(t);
        return { ...p, status: "up" as const };
      } catch {
        return { ...p, status: "down" as const };
      }
    }));
    setProbes(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { probeAll(); }, [probeAll]);

  const iframeSrc = useMemo(() => {
    const u = new URL(`${GRAFANA_URL}/d/${active.uid}/${active.slug}`);
    u.searchParams.set("orgId",   "1");
    u.searchParams.set("kiosk",   "tv");
    u.searchParams.set("theme",   "dark");
    u.searchParams.set("refresh", "10s");
    // Cache-bust on the user's "Refresh embed" click.
    if (refreshNonce > 0) u.searchParams.set("_r", String(refreshNonce));
    return u.toString();
  }, [active, refreshNonce]);

  return (
    <div className="flex flex-col gap-4 p-6">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="page-title">Observability</h1>
          <p className="text-sm text-muted-foreground">
            Prometheus metrics + Grafana dashboards, embedded from the
            local <code className="rounded bg-secondary/60 px-1 py-0.5 text-[11px]">docker compose --profile obs</code> stack.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {probes.map(({ name, status, icon: Icon, href }) => (
            <a
              key={name}
              href={href}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 rounded-md border border-border/60 bg-card/60 px-3 py-1.5 text-xs transition-colors hover:bg-secondary/60"
              title={`Open ${name} (${href})`}
            >
              <Icon className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="font-medium">{name}</span>
              {status === "checking" && (
                <RefreshCw className="h-3 w-3 animate-spin text-muted-foreground" />
              )}
              {status === "up" && (
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
              )}
              {status === "down" && (
                <XCircle className="h-3.5 w-3.5 text-rose-500" />
              )}
              <ExternalLink className="h-3 w-3 text-muted-foreground/60" />
            </a>
          ))}
          <Button variant="outline" size="sm" onClick={probeAll}>
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
            Recheck
          </Button>
        </div>
      </div>

      {/* If any service is down, surface a single banner so the operator
          isn't left wondering why the iframe is blank. */}
      {probes.some((p) => p.status === "down") && (
        <Card className="border-amber-500/40 bg-amber-500/5">
          <CardContent className="flex items-start gap-3 py-4 text-sm">
            <AlertTriangle className="mt-0.5 h-4 w-4 text-amber-500" />
            <div className="space-y-1">
              <div className="font-medium">
                Some observability services aren&apos;t reachable from your browser.
              </div>
              <div className="text-muted-foreground">
                Bring the local stack up with{" "}
                <code className="rounded bg-secondary/60 px-1 py-0.5 text-[11px]">
                  docker compose --profile obs up -d prometheus grafana alertmanager
                </code>
                {" "}from the repo root. Then click <em>Recheck</em>.
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dashboard tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {DASHBOARDS.map((d) => (
          <button
            key={d.id}
            onClick={() => setActive(d)}
            className={
              "rounded-md border px-3 py-1.5 text-sm transition-colors " +
              (active.id === d.id
                ? "border-accent bg-secondary text-foreground"
                : "border-border/60 bg-card/40 text-muted-foreground hover:bg-secondary/60 hover:text-foreground")
            }
            type="button"
          >
            {d.label}
          </button>
        ))}
        <span className="text-xs text-muted-foreground">{active.description}</span>
        <div className="ml-auto flex items-center gap-2">
          <a
            href={`${GRAFANA_URL}/d/${active.uid}/${active.slug}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
          >
            Open in Grafana <ExternalLink className="h-3 w-3" />
          </a>
          <Button variant="outline" size="sm" onClick={() => setRefreshNonce((n) => n + 1)}>
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
            Refresh embed
          </Button>
        </div>
      </div>

      {/* The iframe itself. min-h fills most of the viewport on a 1080p
          laptop without forcing a parent height; tall panels still scroll
          inside the frame because Grafana kiosk mode handles its own
          scrolling. allow-same-origin is required so Grafana's anonymous
          session cookie sticks across panel refreshes. */}
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <iframe
            key={`${active.id}:${refreshNonce}`}
            src={iframeSrc}
            title={`Grafana — ${active.label}`}
            className="block w-full"
            style={{ minHeight: "calc(100vh - 240px)", border: 0 }}
            sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-forms"
          />
        </CardContent>
      </Card>

      {/* Quick-link cards — useful when the iframe sandbox is the wrong
          tool (e.g. the operator wants to edit a panel or check raw rules). */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <QuickLink
          href={GRAFANA_URL}
          title="Grafana"
          subtitle="Dashboards, panels, alert rules. admin / admin."
          badge="3001"
        />
        <QuickLink
          href={`${PROMETHEUS_URL}/targets`}
          title="Prometheus"
          subtitle="Scrape targets, PromQL explorer, recording rules."
          badge="9090"
        />
        <QuickLink
          href={ALERTMANAGER_URL}
          title="Alertmanager"
          subtitle="Active / silenced alerts, routing tree."
          badge="9093"
        />
      </div>
    </div>
  );
}

function QuickLink({ href, title, subtitle, badge }:
  { href: string; title: string; subtitle: string; badge: string }) {
  return (
    <a href={href} target="_blank" rel="noreferrer" className="block">
      <Card className="h-full transition-colors hover:bg-secondary/40">
        <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
          <CardTitle className="text-base">{title}</CardTitle>
          <Badge variant="outline" className="text-[10px]">:{badge}</Badge>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-xs leading-relaxed">
            {subtitle}
          </CardDescription>
          <div className="mt-2 inline-flex items-center gap-1 text-xs text-muted-foreground">
            Open <ExternalLink className="h-3 w-3" />
          </div>
        </CardContent>
      </Card>
    </a>
  );
}
