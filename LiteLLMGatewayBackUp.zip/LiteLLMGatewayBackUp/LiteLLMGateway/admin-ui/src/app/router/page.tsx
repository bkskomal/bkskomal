"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle, ArrowRight, Check, GitBranch, Layers, Pencil, RefreshCw,
  Sparkles, Users, X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";

// -------------------------------------------------------------------------
// API contract — mirrors the gateway /admin/router/* shape verbatim.
// -------------------------------------------------------------------------

type RouterRule = {
  name: string;
  when: Record<string, unknown>;
  route: string;
  reason?: string;
  extra: Record<string, unknown>;
  enabled: boolean;
  route_override: string | null;
};

type ModelItem = {
  model_name: string;
  enabled: boolean;
};

type RulesResponse = {
  rules: RouterRule[];
  count: number;
  source: string;
};

type PerModel = { model: string; count: number; tokens: number };
type TopOverrider = {
  user_id: string;
  total: number;
  overrides: number;
  override_rate: number; // 0..1
};

type UsageResponse = {
  window_minutes: number;
  generated_at: string;
  per_model: PerModel[];
  top_overriders: TopOverrider[];
  overrides_total: number;
  requests_total: number;
};

// -------------------------------------------------------------------------
// Constants
// -------------------------------------------------------------------------

const GW = "/api/gateway";
const REFRESH_INTERVAL_MS = 15_000;

type BadgeVariant =
  | "default" | "secondary" | "destructive" | "outline"
  | "success" | "warning" | "accent";

// Same provider colour vocabulary as the Models / Tiers pages — keep these
// surfaces visually consistent so an operator scanning across pages doesn't
// have to relearn what "green chip" means.
const PROVIDER_VARIANT: Record<string, BadgeVariant> = {
  ollama:            "success",
  openrouter:        "accent",
  openai:            "secondary",
  openai_compatible: "secondary",
  anthropic:         "warning",
  bedrock:           "default",
  azure:             "default",
  gemini:            "default",
  vertex:            "default",
  groq:              "default",
  together:          "default",
  custom:            "default",
};

const WINDOW_OPTIONS: { label: string; minutes: number }[] = [
  { label: "15m", minutes: 15 },
  { label: "60m", minutes: 60 },
  { label: "6h",  minutes: 360 },
  { label: "24h", minutes: 1440 },
];

// Derive provider from a route string. LiteLLM route names typically look
// like "openrouter/vendor/name", "ollama_chat/qwen", "openai/gpt-4o" etc.
// We strip the trailing "_chat" so "ollama_chat" → "ollama" lines up with
// the provider chip mapping. Anything we don't recognise returns null and
// the route just renders without a provider chip.
function providerFromRoute(route: string): string | null {
  if (!route) return null;
  const head = route.split("/")[0]?.toLowerCase() ?? "";
  if (!head) return null;
  const normalized = head.endsWith("_chat") ? head.slice(0, -"_chat".length) : head;
  if (normalized in PROVIDER_VARIANT) return normalized;
  return null;
}

// -------------------------------------------------------------------------
// Page
// -------------------------------------------------------------------------

export default function RouterPage() {
  const [rules, setRules]   = useState<RulesResponse | null>(null);
  const [usage, setUsage]   = useState<UsageResponse | null>(null);
  const [models, setModels] = useState<ModelItem[] | null>(null);
  const [windowMin, setWindowMin] = useState<number>(60);
  const [error, setError]   = useState<string | null>(null);
  const [refreshedAt, setRefreshedAt] = useState<Date | null>(null);

  const refresh = useCallback(async (winMin: number) => {
    // Fetch all three endpoints in parallel; collect their errors so a
    // single failed call doesn't blank the whole page. Whichever resolves
    // still updates its panel.
    const errs: string[] = [];

    const rulesP = fetch(`${GW}/admin/router/rules`, {
      cache: "no-store", credentials: "same-origin",
    }).then(async (r) => {
      if (!r.ok) throw new Error(`rules: ${r.status} ${r.statusText}`);
      return (await r.json()) as RulesResponse;
    });

    const usageP = fetch(`${GW}/admin/router/usage?window_minutes=${winMin}`, {
      cache: "no-store", credentials: "same-origin",
    }).then(async (r) => {
      if (!r.ok) throw new Error(`usage: ${r.status} ${r.statusText}`);
      return (await r.json()) as UsageResponse;
    });

    // Models list — used to populate the route-override dropdown. We only
    // care about model_name + enabled here so the rest of the registry
    // payload is ignored client-side. Disabled models stay in the list
    // (greyed out in the picker) so operators can SEE that a disabled
    // model can't be picked as a route.
    const modelsP = fetch(`${GW}/admin/models?include_disabled=true`, {
      cache: "no-store", credentials: "same-origin",
    }).then(async (r) => {
      if (!r.ok) throw new Error(`models: ${r.status} ${r.statusText}`);
      return (await r.json()) as ModelItem[];
    });

    const [rRes, uRes, mRes] = await Promise.allSettled([rulesP, usageP, modelsP]);
    if (rRes.status === "fulfilled") setRules(rRes.value);  else errs.push(String(rRes.reason));
    if (uRes.status === "fulfilled") setUsage(uRes.value);  else errs.push(String(uRes.reason));
    if (mRes.status === "fulfilled") setModels(mRes.value); else errs.push(String(mRes.reason));

    setRefreshedAt(new Date());
    setError(errs.length ? errs.join(" · ") : null);
  }, []);

  // Initial + polling. Re-key on windowMin so the operator's choice flows
  // through to the next tick without needing a manual refresh.
  useEffect(() => {
    void refresh(windowMin);
    const id = window.setInterval(() => { void refresh(windowMin); }, REFRESH_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, [refresh, windowMin]);

  // PATCH a single rule and slot the returned object back into local state
  // so the toggle / edit feels instant. On failure we surface the error
  // banner but leave the previous local state intact (so the UI doesn't
  // lie about the persisted state).
  const patchRule = useCallback(
    async (ruleName: string, body: { enabled?: boolean; route_override?: string | null }) => {
      try {
        const r = await fetch(
          `${GW}/admin/router/rules/${encodeURIComponent(ruleName)}`,
          {
            method:      "PATCH",
            credentials: "same-origin",
            headers:     { "Content-Type": "application/json" },
            body:        JSON.stringify(body),
          },
        );
        if (!r.ok) {
          const text = await r.text();
          throw new Error(`PATCH ${ruleName}: ${r.status} ${text}`);
        }
        const updated = (await r.json()) as RouterRule;
        setRules((cur) => {
          if (!cur) return cur;
          return {
            ...cur,
            rules: cur.rules.map((x) => (x.name === ruleName ? updated : x)),
          };
        });
        setError(null);
      } catch (e) {
        setError(String(e));
      }
    },
    [],
  );

  const ruleCount = rules?.count ?? rules?.rules.length ?? 0;
  const source = rules?.source ?? "—";

  return (
    <div className="mx-auto max-w-7xl space-y-8">
      {/* Header */}
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-2">
          <h1 className="page-title">Smart Router</h1>
          <p className="max-w-2xl text-sm text-muted-foreground">
            First-match rule chain. Live per-model counters + per-user override-rate from the audit log.
          </p>
          {rules && (
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <Badge variant="outline" className="font-mono">
                <GitBranch className="mr-1 h-3 w-3" />
                {source}
              </Badge>
            </div>
          )}
        </div>
        <div className="flex items-center gap-3">
          {refreshedAt && (
            <span className="hidden text-[11px] text-muted-foreground sm:inline">
              updated {refreshedAt.toLocaleTimeString()}
              <button
                onClick={() => { void refresh(windowMin); }}
                className="ml-2 inline-flex h-5 w-5 items-center justify-center rounded-md hover:bg-secondary"
                aria-label="Refresh"
                title="Refresh"
              >
                <RefreshCw className="h-3 w-3" />
              </button>
            </span>
          )}
          <Badge variant="accent" className="px-3 py-1">
            {ruleCount} {ruleCount === 1 ? "rule" : "rules"} &middot; loaded
          </Badge>
        </div>
      </header>

      {error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="flex items-center gap-2 p-4 text-sm text-destructive">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span className="break-all">{error}</span>
          </CardContent>
        </Card>
      )}

      {/* Stat cards — 4-up grid */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={<Layers className="h-4 w-4" />}
          label="Rules · loaded"
          value={rules ? String(ruleCount) : "—"}
          hint={rules ? `from ${source}` : "loading…"}
        />
        <StatCard
          icon={<ArrowRight className="h-4 w-4" />}
          label={`Requests · ${windowLabel(windowMin)}`}
          value={usage ? usage.requests_total.toLocaleString() : "—"}
          hint={usage ? `over ${usage.window_minutes} min` : "loading…"}
        />
        <StatCard
          icon={<Users className="h-4 w-4" />}
          label={`Overrides · ${windowLabel(windowMin)}`}
          value={usage ? usage.overrides_total.toLocaleString() : "—"}
          hint={
            usage
              ? usage.requests_total > 0
                ? `${Math.round((usage.overrides_total / Math.max(1, usage.requests_total)) * 100)}% of traffic`
                : "no traffic"
              : "loading…"
          }
          pulse={!!usage && usage.overrides_total > 0}
        />
        <StatCard
          icon={<Sparkles className="h-4 w-4" />}
          label="Semantic router"
          value="—"
          hint="embedding similarity (deferred)"
          rightBadge={<Badge variant="secondary" className="opacity-70">Coming in S3</Badge>}
          dimmed
        />
      </section>

      {/* Rule chain */}
      <section className="space-y-3">
        <div className="flex items-baseline justify-between">
          <div>
            <h2 className="section-title">Rule chain</h2>
            <p className="text-sm text-muted-foreground">
              Evaluated top-to-bottom. <span className="font-medium text-foreground">First match wins</span> —
              the matching rule&apos;s <code className="rounded bg-muted px-1 font-mono text-xs">route</code> is what gets called.
            </p>
          </div>
        </div>
        {!rules ? (
          <Card>
            <CardContent className="p-5 text-sm text-muted-foreground">Loading rules…</CardContent>
          </Card>
        ) : rules.rules.length === 0 ? (
          <Card>
            <CardContent className="p-5 text-sm text-muted-foreground">
              No rules configured. The router will fall through to the requested model.
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {rules.rules.map((r, idx) => (
              <RuleCard
                key={`${idx}-${r.name}`}
                rule={r}
                index={idx + 1}
                models={models}
                onToggle={(enabled) => patchRule(r.name, { enabled })}
                onSetRoute={(target) => patchRule(r.name, { route_override: target })}
                onClearRoute={() => patchRule(r.name, { route_override: null })}
              />
            ))}
          </div>
        )}
      </section>

      {/* Usage section — per-model + override-rate, with window picker */}
      <section className="space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="section-title">Live usage</h2>
            <p className="text-sm text-muted-foreground">
              Per-model traffic and per-user override rate, pulled from the audit log.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="window-select" className="text-xs uppercase tracking-wide text-muted-foreground">
              Window
            </label>
            <select
              id="window-select"
              value={windowMin}
              onChange={(e) => setWindowMin(Number(e.target.value))}
              className="h-9 rounded-md border border-border/70 bg-background/60 px-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {WINDOW_OPTIONS.map((opt) => (
                <option key={opt.minutes} value={opt.minutes}>{opt.label}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <PerModelCard data={usage?.per_model ?? null} windowMin={windowMin} />
          <TopOverridersCard data={usage?.top_overriders ?? null} windowMin={windowMin} />
        </div>
      </section>
    </div>
  );
}

// -------------------------------------------------------------------------
// Helpers
// -------------------------------------------------------------------------

function windowLabel(min: number): string {
  if (min < 60) return `${min}m`;
  if (min % 60 === 0) return `${min / 60}h`;
  return `${min}m`;
}

// -------------------------------------------------------------------------
// StatCard — 4-up styling lifted from Overview so the two pages match.
// -------------------------------------------------------------------------

function StatCard({
  icon, label, value, hint, pulse, rightBadge, dimmed,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  hint: string;
  pulse?: boolean;
  rightBadge?: React.ReactNode;
  dimmed?: boolean;
}) {
  return (
    <Card className={
      "group relative overflow-hidden shadow-soft transition-shadow hover:shadow-ring " +
      (dimmed ? "opacity-70" : "")
    }>
      <div
        aria-hidden
        className="pointer-events-none absolute -left-px -top-px h-24 w-24 bg-gradient-to-br from-accent/40 via-accent/10 to-transparent opacity-70"
      />
      <CardContent className="relative p-5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {label}
          </span>
          {rightBadge ?? (
            <span className="flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground">
              {icon}
            </span>
          )}
        </div>
        <div className="mt-4 flex items-center gap-2">
          <div className="stat-number">
            {value}
          </div>
          {pulse && (
            <span className="relative inline-flex h-2.5 w-2.5" aria-label="overrides occurring">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-destructive" />
            </span>
          )}
        </div>
        <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// RuleCard — one rule in the chain.
// -------------------------------------------------------------------------

function RuleCard({
  rule, index, models, onToggle, onSetRoute, onClearRoute,
}: {
  rule: RouterRule;
  index: number;
  models: ModelItem[] | null;
  onToggle: (enabled: boolean) => void;
  onSetRoute: (target: string) => void;
  onClearRoute: () => void;
}) {
  const whenEntries  = Object.entries(rule.when ?? {});
  const extraEntries = Object.entries(rule.extra ?? {});

  // The active route is the override (if set) otherwise the YAML route.
  // The badge colour follows the active value so an operator's eye lands
  // on what the chain ACTUALLY uses today, not on the YAML history.
  const activeRoute = rule.route_override ?? rule.route;
  const provider    = providerFromRoute(activeRoute);
  const providerVariant: BadgeVariant = provider
    ? (PROVIDER_VARIANT[provider] ?? "default")
    : "default";

  const [editing, setEditing] = useState(false);
  // Pre-seed with the active route so the dropdown opens on the current
  // value rather than an empty option.
  const [draft, setDraft] = useState<string>(activeRoute);

  // Keep the draft in sync when the rule prop changes (e.g. after another
  // PATCH refreshed the state) and the editor isn't actively open.
  useEffect(() => {
    if (!editing) setDraft(activeRoute);
  }, [activeRoute, editing]);

  const commit = () => {
    setEditing(false);
    // No-op if the operator picked the same value — saves one round trip.
    if (draft === activeRoute) return;
    onSetRoute(draft);
  };
  const cancel = () => {
    setDraft(activeRoute);
    setEditing(false);
  };

  const dimmed = !rule.enabled;

  return (
    <Card className={"shadow-soft " + (dimmed ? "opacity-60" : "")}>
      <CardContent className="p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
          {/* Index gutter */}
          <div className="flex shrink-0 items-start sm:w-12">
            <span className="inline-flex h-7 w-7 items-center justify-center rounded-full border border-border bg-background font-mono text-[11px] tabular-nums text-muted-foreground">
              {index}
            </span>
          </div>

          {/* Body */}
          <div className="min-w-0 flex-1 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={
                  "font-mono text-sm font-medium tracking-tight " +
                  (dimmed ? "line-through" : "")
                }
              >
                {rule.name}
              </span>
              {!rule.enabled && (
                <Badge variant="secondary" className="font-mono text-[10px]">
                  disabled
                </Badge>
              )}
            </div>

            {/* when: chips per key/value */}
            <div className="flex flex-wrap items-center gap-1.5">
              {whenEntries.length === 0 ? (
                <Badge variant="outline" className="font-mono">when: always</Badge>
              ) : (
                whenEntries.map(([k, v]) => (
                  <Badge key={k} variant="outline" className="font-mono">
                    <span className="opacity-70 mr-1">{k}:</span>
                    <span>{renderValue(v)}</span>
                  </Badge>
                ))
              )}
            </div>

            {/* Arrow + route (editable) */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden />
              {provider && (
                <Badge variant={providerVariant} className="font-mono">{provider}</Badge>
              )}
              {editing ? (
                <span className="flex items-center gap-1">
                  <select
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    className="h-7 rounded-md border border-border/70 bg-background/60 px-2 font-mono text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    aria-label="Route target"
                  >
                    {/* If the rule's YAML route isn't in the registry (very
                        unusual — e.g. someone deleted that model) we still
                        list it so the operator can see what the YAML says
                        and pick something else. */}
                    {models && !models.some((m) => m.model_name === activeRoute) && (
                      <option value={activeRoute} disabled>
                        {activeRoute} (not in registry)
                      </option>
                    )}
                    {(models ?? []).map((m) => (
                      <option
                        key={m.model_name}
                        value={m.model_name}
                        disabled={!m.enabled}
                      >
                        {m.model_name}{m.enabled ? "" : " (disabled)"}
                      </option>
                    ))}
                  </select>
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={commit}
                    aria-label="Save route"
                    title="Save"
                    className="h-7 w-7"
                  >
                    <Check className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={cancel}
                    aria-label="Cancel"
                    title="Cancel"
                    className="h-7 w-7"
                  >
                    <X className="h-3.5 w-3.5" />
                  </Button>
                </span>
              ) : (
                <>
                  <span className="font-mono text-sm">{activeRoute}</span>
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={() => setEditing(true)}
                    aria-label="Edit route"
                    title="Edit route target"
                    className="h-6 w-6"
                  >
                    <Pencil className="h-3 w-3" />
                  </Button>
                  {rule.route_override && (
                    // Clicking the "modified" chip clears the override and
                    // reverts to the YAML default. Using a button (not a
                    // bare span) so keyboard users can reach it too.
                    <button
                      type="button"
                      onClick={onClearRoute}
                      aria-label={`Clear override; revert to ${rule.route}`}
                      title={`Modified · click to revert to YAML default (${rule.route})`}
                      className="inline-flex"
                    >
                      <Badge variant="warning" className="cursor-pointer font-mono text-[10px]">
                        modified · was {rule.route}
                      </Badge>
                    </button>
                  )}
                </>
              )}
            </div>

            {/* extra chips */}
            {extraEntries.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5">
                {extraEntries.map(([k, v]) => (
                  <Badge key={k} variant="secondary" className="font-mono">
                    <span className="opacity-70 mr-1">{k}:</span>
                    <span>{renderValue(v)}</span>
                  </Badge>
                ))}
              </div>
            )}

            {/* reason */}
            {rule.reason && (
              <p className="pt-0.5 text-xs italic text-muted-foreground">{rule.reason}</p>
            )}
          </div>

          {/* Enable/disable rocker toggle — right edge of the card. */}
          <div className="flex shrink-0 items-start">
            <ToggleSwitch
              checked={rule.enabled}
              onChange={(v) => onToggle(v)}
              ariaLabel={rule.enabled ? `Disable rule ${rule.name}` : `Enable rule ${rule.name}`}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Minimal accessible toggle. We don't pull in a separate component because
// this is the only switch on the page and the rest of the UI already
// styles inputs by hand.
function ToggleSwitch({
  checked, onChange, ariaLabel,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  ariaLabel: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      onClick={() => onChange(!checked)}
      className={
        "relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border border-border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring " +
        (checked ? "bg-accent" : "bg-secondary")
      }
    >
      <span
        aria-hidden
        className={
          "inline-block h-5 w-5 transform rounded-full bg-background shadow transition-transform " +
          (checked ? "translate-x-5" : "translate-x-0.5")
        }
      />
    </button>
  );
}

// Compact, predictable rendering of a JSON-ish value for use inside a small
// chip. Strings render as-is (no quotes — chips already have a border to
// frame them). Booleans/numbers stringify normally. Objects/arrays get JSON
// so the user can still read structure without us inventing a tree widget.
function renderValue(v: unknown): string {
  if (v === null) return "null";
  if (typeof v === "string") return v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try { return JSON.stringify(v); } catch { return String(v); }
}

// -------------------------------------------------------------------------
// PerModelCard — horizontal bar list, same vocabulary as Top-N on Overview.
// -------------------------------------------------------------------------

function PerModelCard({ data, windowMin }: { data: PerModel[] | null; windowMin: number }) {
  const items = data ?? [];
  const max = Math.max(1, ...items.map((i) => i.count));
  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-3 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Requests routed · last {windowLabel(windowMin)}
        </div>
        {data === null ? (
          <div className="text-sm text-muted-foreground">Loading…</div>
        ) : items.length === 0 ? (
          <div className="text-sm text-muted-foreground">No traffic in the last {windowLabel(windowMin)}.</div>
        ) : (
          <ul className="space-y-2.5">
            {items.map((m) => {
              const pct = (m.count / max) * 100;
              return (
                <li key={m.model} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="truncate font-mono">{m.model}</span>
                    <span className="font-mono tabular-nums text-muted-foreground">
                      {m.count.toLocaleString()} req &middot; {m.tokens.toLocaleString()} tok
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                    <div className="h-full rounded-full bg-accent" style={{ width: `${pct}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// TopOverridersCard — table with rate column colour-coded.
// -------------------------------------------------------------------------

function TopOverridersCard({ data, windowMin }: { data: TopOverrider[] | null; windowMin: number }) {
  // Sort by rate desc; the gateway already sorts, but defending against
  // server-side reordering keeps the UI deterministic for the operator.
  const sorted = useMemo(() => {
    if (!data) return null;
    return [...data].sort((a, b) => b.override_rate - a.override_rate);
  }, [data]);

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Top overriders · last {windowLabel(windowMin)}
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Users whose requested model differed from what the router served them.
          A high rate flags a rule that&apos;s misfiring.
        </p>
        {sorted === null ? (
          <div className="text-sm text-muted-foreground">Loading…</div>
        ) : sorted.length === 0 ? (
          <div className="text-sm text-muted-foreground">
            No overrides — every user got the model they asked for (or no users specified a model).
          </div>
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>User</TH>
                <TH className="text-right">Total</TH>
                <TH className="text-right">Overrides</TH>
                <TH className="text-right">Rate</TH>
              </TR>
            </THead>
            <TBody>
              {sorted.map((row) => (
                <TR key={row.user_id}>
                  <TD className="font-mono text-xs">{row.user_id}</TD>
                  <TD className="text-right font-mono tabular-nums">{row.total.toLocaleString()}</TD>
                  <TD className="text-right font-mono tabular-nums">{row.overrides.toLocaleString()}</TD>
                  <TD className="text-right">
                    <RateBadge rate={row.override_rate} />
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

// Colour-code the override rate. 0 reads as muted (nothing to investigate);
// 1-25% is a warning (worth a glance); >25% is destructive (a rule is
// probably misfiring or a user is gaming the router).
function RateBadge({ rate }: { rate: number }) {
  const pct = Math.round(rate * 100);
  let variant: BadgeVariant;
  if (pct === 0) variant = "success";
  else if (pct <= 25) variant = "warning";
  else variant = "destructive";
  return (
    <Badge variant={variant} className="font-mono tabular-nums">
      {pct}%
    </Badge>
  );
}
