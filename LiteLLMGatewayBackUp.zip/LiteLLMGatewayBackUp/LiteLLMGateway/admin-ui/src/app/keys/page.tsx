"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Check, CopyIcon, KeyRound, Pencil, Plus, ShieldOff, ShieldX, Undo2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

type Key = {
  id: number;
  key_prefix: string;
  user_id: string;
  user_email: string | null;
  team_id: string;
  role: string;
  is_active: boolean;
  created_at: string;
  expires_at: string | null;
  last_used_at: string | null;
};

type Team = { team_id: string; tier: string };

type UebaAlert = {
  id?: number | string;
  user_id: string;
  signal: string;
  status?: string;
};

type RestoreResponse = {
  user_id: string;
  keys_reactivated: number;
  cleared_by: string;
  decision_note: string | null;
};

const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };
const GW = "/api/gateway";

export default function KeysPage() {
  const [keys, setKeys]   = useState<Key[] | null>(null);
  const [teams, setTeams] = useState<Team[]>([]);
  const [err, setErr]     = useState<string | null>(null);

  // Auto-quarantine signal: user_ids with an OPEN auto_quarantine UEBA alert.
  // HEURISTIC — see TODO in restore handler. A per-key "deactivated_reason"
  // column would be cleaner than this cross-check.
  const [quarantinedUsers, setQuarantinedUsers] = useState<Set<string>>(new Set());

  // Issue-key form state
  const [userId, setUserId]     = useState("");
  const [userEmail, setEmail]   = useState("");
  const [teamId, setTeamId]     = useState("");
  const [creating, setCreating] = useState(false);

  // One-shot raw-key reveal
  const [reveal, setReveal] = useState<{
    key_prefix: string;
    raw_key:    string;
    email_sent?:  boolean;
    email_error?: string | null;
    sent_to?:    string;
  } | null>(null);

  // Issue-key form flag: when ON and the operator filled the email
  // field, the gateway sends the one-time key + IDE setup snippets to
  // that address via the SMTP settings on /settings/app.
  const [emailToDeveloper, setEmailToDeveloper] = useState(false);

  // Per-row restore inline-confirm state (key = key id).
  const [restoreOpenFor, setRestoreOpenFor] = useState<Record<string, boolean>>({});
  const [restoreNotes, setRestoreNotes]     = useState<Record<string, string>>({});
  const [restoreBusy, setRestoreBusy]       = useState<string | null>(null);
  const [restoreOk, setRestoreOk]           = useState<{ user_id: string; n: number } | null>(null);

  // Per-row team-edit state: `teamEditFor` holds the key.id currently in
  // edit mode (only one at a time), `teamDraft` holds the dropdown value.
  // null = nobody editing.
  const [teamEditFor, setTeamEditFor] = useState<number | null>(null);
  const [teamDraft, setTeamDraft]     = useState<string>("");
  const [teamSaveBusy, setTeamSaveBusy] = useState<number | null>(null);

  const reload = useCallback(async () => {
    try {
      const [kr, tr, ar] = await Promise.all([
        fetch(`${GW}/admin/keys`,  { headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store" }),
        fetch(`${GW}/admin/teams`, { headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store" }),
        fetch(`${GW}/admin/ueba/alerts?status=open`, {
          headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store",
        }),
      ]);
      if (!kr.ok) throw new Error(`keys: ${kr.status}`);
      if (!tr.ok) throw new Error(`teams: ${tr.status}`);
      const ks: Key[]  = await kr.json();
      const ts: Team[] = await tr.json();
      setKeys(ks);
      setTeams(ts);
      if (!teamId && ts.length > 0) setTeamId(ts[0].team_id);

      // Alerts endpoint is best-effort: if it fails (older backend, transient
      // 5xx) we still render the keys list — we just won't be able to flag
      // quarantined rows. That's a softer failure than blocking the page.
      // The endpoint returns {status_filter, count, alerts: [...]} — pull
      // out the array (and tolerate a bare array too in case a future
      // version simplifies the shape).
      if (ar.ok) {
        const body = await ar.json();
        const alerts: UebaAlert[] = Array.isArray(body) ? body
                                  : Array.isArray(body?.alerts) ? body.alerts
                                  : [];
        const qs = new Set(
          alerts.filter((a) => a.signal === "auto_quarantine").map((a) => a.user_id),
        );
        setQuarantinedUsers(qs);
      } else {
        setQuarantinedUsers(new Set());
      }
      setErr(null);
    } catch (e) {
      setErr(String(e));
    }
  }, [teamId]);

  useEffect(() => { void reload(); }, [reload]);

  const issue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId || !teamId) return;
    setCreating(true);
    try {
      const r = await fetch(`${GW}/admin/keys`, {
        method: "POST",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({
          user_id: userId, team_id: teamId,
          user_email: userEmail || null,
          // Only ask the gateway to email when both the checkbox is on
          // AND an address is supplied — the backend short-circuits the
          // same way, but keeping the UI strict avoids confusing 400s.
          email_to_developer: emailToDeveloper && Boolean(userEmail),
        }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data = await r.json();
      setReveal({
        key_prefix: data.key_prefix,
        raw_key:    data.raw_key,
        email_sent: data.email_sent,
        email_error: data.email_error ?? null,
        sent_to:    emailToDeveloper && Boolean(userEmail) ? userEmail : undefined,
      });
      setUserId("");
      setEmail("");
      setEmailToDeveloper(false);
      await reload();
    } catch (e) {
      setErr(String(e));
    } finally {
      setCreating(false);
    }
  };

  const revoke = async (id: number) => {
    if (!confirm(`Revoke key ${id}? This is immediate and irreversible.`)) return;
    try {
      const r = await fetch(`${GW}/admin/keys/${id}`, { method: "DELETE", headers: JSON_HEADERS, credentials: "same-origin" });
      // DELETE is idempotent: 204 = just revoked, 404 = already revoked /
      // not present. Either way the desired end state is reached, so we
      // just reload the list. (A stale UI row + a race with another tab
      // both end up here; surfacing the 404 as an error confused operators.)
      if (!r.ok && r.status !== 204 && r.status !== 404) {
        throw new Error(`${r.status} ${r.statusText}`);
      }
      await reload();
      setErr(null);
    } catch (e) {
      setErr(String(e));
    }
  };

  // Reassign a key's team. The key value + hash never change — only the
  // team_id, which means the next request from this key picks up the new
  // team's tier (model ACL, RPM, daily budget). No restart needed.
  const saveTeam = async (k: Key) => {
    const next = teamDraft.trim();
    if (!next || next === k.team_id) {
      // No change — just exit edit mode silently.
      setTeamEditFor(null);
      return;
    }
    setTeamSaveBusy(k.id);
    try {
      const r = await fetch(`${GW}/admin/keys/${k.id}`, {
        method: "PATCH",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({ team_id: next }),
      });
      if (!r.ok) {
        const txt = await r.text().catch(() => "");
        throw new Error(`${r.status} ${r.statusText}${txt ? ` — ${txt.slice(0, 200)}` : ""}`);
      }
      setTeamEditFor(null);
      await reload();
      setErr(null);
    } catch (e) {
      setErr(String(e));
    } finally {
      setTeamSaveBusy(null);
    }
  };

  const restore = async (uid: string, rowKeyId: number) => {
    const id = String(rowKeyId);
    setRestoreBusy(id);
    try {
      const note = (restoreNotes[id] ?? "").trim();
      const r = await fetch(`${GW}/admin/ueba/user/${encodeURIComponent(uid)}/restore-keys`, {
        method: "POST",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify(note ? { decision_note: note } : {}),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data: RestoreResponse = await r.json();
      setRestoreOk({ user_id: data.user_id, n: data.keys_reactivated });
      setRestoreOpenFor((o) => ({ ...o, [id]: false }));
      setRestoreNotes((n) => { const c = { ...n }; delete c[id]; return c; });
      await reload();
    } catch (e) {
      setErr(String(e));
    } finally {
      setRestoreBusy(null);
    }
  };

  // Distinct user_ids whose is_active=false rows we'll badge as QUARANTINED.
  // Used both for the banner count and to decide per-row rendering below.
  const quarantinedUserCount = useMemo(() => {
    if (!keys) return 0;
    const s = new Set<string>();
    for (const k of keys) {
      if (!k.is_active && quarantinedUsers.has(k.user_id)) s.add(k.user_id);
    }
    return s.size;
  }, [keys, quarantinedUsers]);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">API Keys</h1>
          <p className="text-muted-foreground">
            Per-developer virtual keys. Only the SHA-256 hash + first 8 chars are stored.
          </p>
        </div>
        <Badge variant="accent" className="px-3 py-1">S1 — live</Badge>
      </div>

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">Error: {err}</CardContent>
        </Card>
      )}

      {restoreOk && (
        <Card className="border-oati-success">
          <CardContent className="p-4 text-sm text-oati-success">
            {restoreOk.n} key(s) re-activated for {restoreOk.user_id}.
            <Button
              size="sm"
              variant="ghost"
              className="ml-2"
              onClick={() => setRestoreOk(null)}
            >
              Dismiss
            </Button>
          </CardContent>
        </Card>
      )}

      {quarantinedUserCount > 0 && (
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <ShieldOff className="h-4 w-4" />
              {quarantinedUserCount} user(s) auto-quarantined
            </CardTitle>
            <CardDescription>
              Triggered by 3+ critical UEBA signals in 24h. See{" "}
              <a className="underline underline-offset-2" href="/monitoring">/monitoring</a>{" "}
              for details before restoring.
            </CardDescription>
          </CardHeader>
        </Card>
      )}

      {reveal && (
        <Card className="border-oati-accent">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-oati-accent">
              <KeyRound className="h-4 w-4" /> Save this key now
            </CardTitle>
            <CardDescription>
              You will not be able to view it again. Paste it into the developer's IDE config and confirm before closing.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2 rounded-md bg-secondary p-3 font-mono text-sm">
              <span className="select-all break-all">{reveal.raw_key}</span>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => navigator.clipboard?.writeText(reveal.raw_key)}
                title="Copy to clipboard"
              >
                <CopyIcon className="h-4 w-4" />
              </Button>
            </div>

            {/* Email result — only renders when the operator opted in. */}
            {reveal.sent_to !== undefined && (
              reveal.email_sent ? (
                <div className="flex items-center gap-2 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-[12px] text-emerald-700 dark:text-emerald-300">
                  <Check className="h-3.5 w-3.5" />
                  Emailed key + IDE setup snippets to{" "}
                  <span className="font-mono">{reveal.sent_to}</span>.
                </div>
              ) : (
                <div className="flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-[12px] text-destructive">
                  <X className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <div>
                    <div>SMTP send failed — the key above is still valid.</div>
                    <div className="font-mono text-[11px] opacity-80">{reveal.email_error}</div>
                  </div>
                </div>
              )
            )}

            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setReveal(null)}>I&apos;ve saved it</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Issue */}
      <Card>
        <CardHeader>
          <CardTitle>Issue a new key</CardTitle>
          <CardDescription>The team controls the tier (budgets / model ACL / agent mode).</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={issue} className="grid gap-3 md:grid-cols-4">
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">User ID</label>
              <Input value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="bk.komal" required />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Email (optional)</label>
              <Input type="email" value={userEmail} onChange={(e) => setEmail(e.target.value)} placeholder="bk@example.com" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Team</label>
              <select
                value={teamId}
                onChange={(e) => setTeamId(e.target.value)}
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                required
              >
                {teams.map((t) => (
                  <option key={t.team_id} value={t.team_id}>
                    {t.team_id}  ·  {t.tier}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <Button type="submit" variant="accent" disabled={creating || !userId || !teamId} className="w-full">
                <Plus className="mr-1 h-4 w-4" />
                {creating ? "Issuing…" : "Issue key"}
              </Button>
            </div>

            {/* Email-to-developer opt-in. Stretches across all columns
                so the disabled-state explanation reads on a single line. */}
            <div className="md:col-span-4 flex items-center gap-2 rounded-md border border-border bg-background/40 px-3 py-2">
              <input
                id="email-to-dev"
                type="checkbox"
                checked={emailToDeveloper}
                onChange={(e) => setEmailToDeveloper(e.target.checked)}
                disabled={!userEmail.trim()}
                className="h-3.5 w-3.5 accent-[hsl(var(--accent))]"
              />
              <label
                htmlFor="email-to-dev"
                className={
                  "text-[12px] " +
                  (!userEmail.trim() ? "text-muted-foreground" : "text-foreground")
                }
              >
                Email the key + IDE setup snippets to {userEmail.trim() || "(supply an Email above)"}
              </label>
              <span className="ml-auto text-[11px] text-muted-foreground">
                SMTP config: <a className="underline underline-offset-2" href="/settings/app">Settings &rarr; App settings</a>
              </span>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* List */}
      <Card>
        <CardHeader>
          <CardTitle>Active keys</CardTitle>
          <CardDescription>Only prefix + metadata. Raw key was shown once on creation.</CardDescription>
        </CardHeader>
        <CardContent>
          {!keys ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : keys.length === 0 ? (
            <p className="text-sm text-muted-foreground">No keys yet. Issue one above.</p>
          ) : (
            <Table>
              <THead>
                <TR>
                  <TH>ID</TH>
                  <TH>Prefix</TH>
                  <TH>User</TH>
                  <TH>Team</TH>
                  <TH>Role</TH>
                  <TH>Status</TH>
                  <TH>Created</TH>
                  <TH>Last used</TH>
                  <TH className="w-48 text-right">Actions</TH>
                </TR>
              </THead>
              <TBody>
                {keys.map((k) => {
                  const rowId = String(k.id);
                  // HEURISTIC: an inactive key counts as quarantined when the
                  // owning user has an open auto_quarantine UEBA alert. See
                  // TODO above — we'd prefer the backend stamp a per-key
                  // deactivated_reason so we don't conflate operator-revoked
                  // with auto-quarantined when both could be true.
                  const isQuarantined = !k.is_active && quarantinedUsers.has(k.user_id);
                  const showRestoreConfirm = !!restoreOpenFor[rowId];
                  const busy = restoreBusy === rowId;
                  return (
                    <TR key={k.id}>
                      <TD className="font-mono text-xs">{k.id}</TD>
                      <TD className="font-mono">{k.key_prefix}…</TD>
                      <TD>
                        <div className="leading-tight">
                          <div>{k.user_id}</div>
                          {k.user_email && <div className="text-xs text-muted-foreground">{k.user_email}</div>}
                        </div>
                      </TD>
                      <TD>
                        {teamEditFor === k.id ? (
                          // Inline team editor — dropdown + Save / Cancel
                          // buttons. Save patches the row and reloads; Cancel
                          // exits without a request.
                          <div className="flex items-center gap-1.5">
                            <select
                              value={teamDraft}
                              onChange={(e) => setTeamDraft(e.target.value)}
                              autoFocus
                              disabled={teamSaveBusy === k.id}
                              className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                            >
                              {teams.map((t) => (
                                <option key={t.team_id} value={t.team_id}>
                                  {t.team_id} · {t.tier}
                                </option>
                              ))}
                            </select>
                            <Button
                              size="sm" variant="accent"
                              onClick={() => saveTeam(k)}
                              disabled={teamSaveBusy === k.id}
                              title="Save new team"
                              className="h-8 px-2"
                            >
                              {teamSaveBusy === k.id
                                ? "Saving…"
                                : <Check className="h-3.5 w-3.5" />}
                            </Button>
                            <Button
                              size="sm" variant="ghost"
                              onClick={() => setTeamEditFor(null)}
                              disabled={teamSaveBusy === k.id}
                              title="Cancel"
                              className="h-8 px-2"
                            >
                              <X className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setTeamEditFor(k.id);
                              setTeamDraft(k.team_id);
                            }}
                            disabled={!k.is_active}
                            title={k.is_active ? "Change team" : "Inactive keys cannot be edited"}
                            className="group inline-flex items-center gap-1.5 rounded px-1 py-0.5 hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-60"
                          >
                            <span>{k.team_id}</span>
                            <Pencil className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-70" />
                          </button>
                        )}
                      </TD>
                      <TD><Badge variant="outline">{k.role}</Badge></TD>
                      <TD>
                        {k.is_active ? (
                          <Badge variant="success">active</Badge>
                        ) : isQuarantined ? (
                          <Badge variant="destructive" className="gap-1">
                            <ShieldOff className="h-3 w-3" />
                            QUARANTINED
                          </Badge>
                        ) : (
                          <Badge variant="secondary">inactive</Badge>
                        )}
                      </TD>
                      <TD className="text-xs text-muted-foreground">
                        {new Date(k.created_at).toLocaleString()}
                      </TD>
                      <TD className="text-xs text-muted-foreground">
                        {k.last_used_at ? new Date(k.last_used_at).toLocaleString() : "never"}
                      </TD>
                      <TD className="text-right">
                        {isQuarantined ? (
                          showRestoreConfirm ? (
                            <div className="space-y-2">
                              <div className="text-left text-xs text-muted-foreground">
                                Restoring re-activates <span className="font-semibold">all</span> of{" "}
                                <span className="font-mono">{k.user_id}</span>'s keys, not just this row.
                              </div>
                              <textarea
                                value={restoreNotes[rowId] ?? ""}
                                onChange={(e) =>
                                  setRestoreNotes((n) => ({
                                    ...n, [rowId]: e.target.value.slice(0, 1024),
                                  }))
                                }
                                placeholder="e.g. user reviewed; was a false positive due to test traffic"
                                rows={2}
                                className="flex w-full rounded-md border border-input bg-background px-2 py-1 text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                              />
                              <div className="flex justify-end gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  disabled={busy}
                                  onClick={() =>
                                    setRestoreOpenFor((o) => ({ ...o, [rowId]: false }))
                                  }
                                >
                                  Cancel
                                </Button>
                                <Button
                                  size="sm"
                                  variant="accent"
                                  disabled={busy}
                                  onClick={() => restore(k.user_id, k.id)}
                                >
                                  <Undo2 className="mr-1 h-3.5 w-3.5" />
                                  {busy ? "Restoring…" : "Confirm restore"}
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() =>
                                setRestoreOpenFor((o) => ({ ...o, [rowId]: true }))
                              }
                            >
                              <Undo2 className="mr-1 h-3.5 w-3.5" /> Restore
                            </Button>
                          )
                        ) : (
                          <Button size="sm" variant="destructive" onClick={() => revoke(k.id)}>
                            <ShieldX className="mr-1 h-3.5 w-3.5" /> Revoke
                          </Button>
                        )}
                      </TD>
                    </TR>
                  );
                })}
              </TBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
