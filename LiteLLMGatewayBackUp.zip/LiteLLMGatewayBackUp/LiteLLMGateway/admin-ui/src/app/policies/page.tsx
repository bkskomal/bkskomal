"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Pencil, Plus, RefreshCw, ShieldCheck, Trash2, X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";

// -------------------------------------------------------------------------
// Types — mirror the gateway's /admin/tiers contract. tokens_per_day is
// honestly a *string* in the wire format so it can carry the literal
// "unlimited"; we keep that shape end-to-end and only branch in the form.
// -------------------------------------------------------------------------

type AgentMode = "disabled" | "tools_no_shell" | "full" | "full_plus_mcp";

type TierItem = {
  id: number | string;
  tier: string;
  models_allowed: string[];
  tokens_per_day: string;     // "100000" | "unlimited"
  rpm: number;
  agent_mode: AgentMode;
  override_model: boolean;
  description: string | null;
  created_at?: string;
  updated_at?: string;
};

// Just the bits we need from /admin/models — anything else (litellm_params
// etc.) is irrelevant for the multi-select chip list.
type ModelLite = {
  id: number | string;
  model_name: string;
  provider?: string;
  enabled?: boolean;
};

type ReloadResponse = {
  tiers?: number;
  banned_topics?: number;
  extra_patterns?: number;
  [k: string]: unknown;
};

// -------------------------------------------------------------------------
// Constants — known tier → chip variant + provider colour map (lifted from
// the Models page so chips line up visually across the two surfaces).
// -------------------------------------------------------------------------

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

type BadgeVariant = "default" | "secondary" | "destructive" | "outline" | "success" | "warning" | "accent";

const TIER_VARIANT: Record<string, BadgeVariant> = {
  L0_readonly:    "secondary",
  L1_standard:    "default",
  L2_senior:      "accent",
  L3_privileged:  "warning",
  quarantined:    "destructive",
};

// Same provider colour vocabulary as the Models page — anything unmapped
// falls back to `default` so unknown providers still render a chip.
const PROVIDER_VARIANT: Record<string, BadgeVariant> = {
  ollama:            "success",
  openrouter:        "accent",
  openai:            "secondary",
  openai_compatible: "secondary",
  anthropic:         "warning",
  bedrock:           "default",
  azure:             "default",
  gemini:            "default",
  vertex:            "default",
  groq:              "default",
  together:          "default",
  custom:            "default",
};

const AGENT_MODES: { id: AgentMode; label: string }[] = [
  { id: "disabled",       label: "disabled — chat only" },
  { id: "tools_no_shell", label: "tools_no_shell — function calls, no shell" },
  { id: "full",           label: "full — tools + shell" },
  { id: "full_plus_mcp",  label: "full_plus_mcp — tools + shell + MCP" },
];

// -------------------------------------------------------------------------
// Page
// -------------------------------------------------------------------------

export default function PoliciesPage() {
  const [tiers, setTiers]     = useState<TierItem[] | null>(null);
  const [models, setModels]   = useState<ModelLite[] | null>(null);
  const [err, setErr]         = useState<string | null>(null);
  const [info, setInfo]       = useState<string | null>(null);
  const [busy, setBusy]       = useState<string | null>(null);
  const [reloading, setReloading] = useState(false);

  // null = closed; "new" = blank add form; else an id of the tier being edited.
  const [formMode, setFormMode] = useState<null | "new" | string>(null);

  const reloadTiers = useCallback(async () => {
    try {
      const r = await fetch(`${GW}/admin/tiers`, {
        headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      setTiers(await r.json());
      setErr(null);
    } catch (e) {
      setErr(String(e));
    }
  }, []);

  const reloadModels = useCallback(async () => {
    // Models list powers the multi-select chips. If it 404s or errors we
    // degrade to an empty list — the form shows the "no models" hint and
    // the user can still type-in via the `*` checkbox.
    try {
      const r = await fetch(`${GW}/admin/models`, {
        headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) { setModels([]); return; }
      const data: ModelLite[] = await r.json();
      setModels(data);
    } catch {
      setModels([]);
    }
  }, []);

  useEffect(() => { void reloadTiers(); void reloadModels(); }, [reloadTiers, reloadModels]);

  const tierCount = tiers?.length ?? 0;

  const removeTier = async (t: TierItem) => {
    if (!confirm(`Delete tier "${t.tier}"? Any team mapped to it will need to be re-tiered before the next request.`)) return;
    const id = String(t.id);
    setBusy(id);
    try {
      const r = await fetch(`${GW}/admin/tiers/${id}`, {
        method: "DELETE", credentials: "same-origin",
      });
      if (!r.ok && r.status !== 204) throw new Error(`${r.status} ${r.statusText}`);
      setTiers((prev) => (prev ? prev.filter((x) => String(x.id) !== id) : prev));
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusy(null);
    }
  };

  const reloadPolicies = async () => {
    setReloading(true);
    try {
      const r = await fetch(`${GW}/admin/policies/reload`, {
        method: "POST", credentials: "same-origin", headers: JSON_HEADERS,
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data: ReloadResponse = await r.json().catch(() => ({}));
      const tiersN   = data.tiers ?? "?";
      const banned   = data.banned_topics ?? "?";
      const patterns = data.extra_patterns ?? "?";
      setInfo(`Reloaded — ${tiersN} tiers, ${banned} banned topics, ${patterns} extra patterns`);
      setTimeout(() => setInfo(null), 4000);
      await reloadTiers();
    } catch (e) {
      setErr(String(e));
    } finally {
      setReloading(false);
    }
  };

  const editingTier = useMemo(() => {
    if (!formMode || formMode === "new" || !tiers) return null;
    return tiers.find((t) => String(t.id) === formMode) ?? null;
  }, [formMode, tiers]);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Heading */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="page-title">Policies &amp; Tiers</h1>
          <p className="text-muted-foreground">
            Per-tier model ACL, daily budget, requests-per-minute, agent mode. Edits hot-reload
            the live plugin chain.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="accent" className="px-3 py-1">
            {tierCount} {tierCount === 1 ? "tier" : "tiers"}
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={reloadPolicies}
            disabled={reloading}
            title="Manually re-read policies and rebuild the plugin chain. Not normally needed — every CUD already reloads server-side."
          >
            <RefreshCw className={"mr-1 h-3.5 w-3.5 " + (reloading ? "animate-spin" : "")} />
            {reloading ? "Reloading…" : "Reload policies"}
          </Button>
          <Button
            variant="accent"
            size="sm"
            onClick={() => setFormMode((m) => (m === "new" ? null : "new"))}
          >
            {formMode === "new" ? (
              <><X className="mr-1 h-3.5 w-3.5" /> Cancel</>
            ) : (
              <><Plus className="mr-1 h-3.5 w-3.5" /> Add tier</>
            )}
          </Button>
        </div>
      </div>

      {info && (
        <Card className="border-accent/40">
          <CardContent className="p-3 text-sm text-accent-foreground">{info}</CardContent>
        </Card>
      )}

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">Error: {err}</CardContent>
        </Card>
      )}

      {/* Add form */}
      {formMode === "new" && (
        <TierForm
          mode="new"
          models={models ?? []}
          onCancel={() => setFormMode(null)}
          onSaved={async () => {
            setFormMode(null);
            await reloadTiers();
          }}
        />
      )}

      {/* List */}
      {!tiers ? (
        <Card>
          <CardContent className="p-5 text-sm text-muted-foreground">Loading…</CardContent>
        </Card>
      ) : tiers.length === 0 ? (
        <Card>
          <CardContent className="p-5 text-sm text-muted-foreground">
            No tiers configured yet. Click <span className="font-medium text-foreground">Add tier</span> to get started —
            tiers are what teams map onto and what the policy plugins consult on every request.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {tiers.map((t) => {
            const id = String(t.id);
            const isEditing = formMode === id;
            return (
              <div key={id} className="space-y-3">
                <TierCard
                  tier={t}
                  models={models ?? []}
                  busy={busy === id}
                  isEditing={isEditing}
                  onEdit={() => setFormMode((cur) => (cur === id ? null : id))}
                  onDelete={() => removeTier(t)}
                />
                {isEditing && editingTier && (
                  <TierForm
                    mode="edit"
                    initial={editingTier}
                    models={models ?? []}
                    onCancel={() => setFormMode(null)}
                    onSaved={async () => {
                      setFormMode(null);
                      await reloadTiers();
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------------------
// TierCard — read-only summary of one tier with Edit / Delete actions.
// -------------------------------------------------------------------------

function TierCard({
  tier, models, busy, isEditing, onEdit, onDelete,
}: {
  tier: TierItem;
  models: ModelLite[];
  busy: boolean;
  isEditing: boolean;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const variant = TIER_VARIANT[tier.tier] ?? "default";
  const allModels = tier.models_allowed.includes("*");
  const tokensLabel = tier.tokens_per_day === "unlimited"
    ? "unlimited"
    : formatTokens(tier.tokens_per_day);

  return (
    <Card className={isEditing ? "ring-1 ring-accent/40" : undefined}>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0">
        <div className="flex flex-1 items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-muted-foreground" />
          <span className="font-mono text-sm font-medium tracking-tight">{tier.tier}</span>
          <Badge variant={variant}>{tier.tier}</Badge>
          {tier.override_model && (
            <Badge variant="outline" title="This tier may override the model name in chat completions requests.">
              override_model
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Quantitative summary in a mono block, mirroring the Models page */}
        <div className="rounded-md border border-border/60 bg-background/40 px-3 py-2 font-mono text-xs leading-relaxed">
          <SummaryRow k="tokens/day" v={tokensLabel} />
          <SummaryRow k="rpm"        v={tier.rpm.toLocaleString()} />
          <SummaryRow k="agent_mode" v={tier.agent_mode} />
          {tier.description && <SummaryRow k="note" v={tier.description} />}
        </div>

        {/* Allowed models — chip per entry, special-cased for "*" */}
        <div className="space-y-1">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
            Models allowed
          </div>
          <div className="flex flex-wrap gap-1.5">
            {allModels ? (
              <Badge variant="accent">* &middot; all models</Badge>
            ) : tier.models_allowed.length === 0 ? (
              <span className="text-xs text-muted-foreground">none — this tier blocks all models</span>
            ) : (
              tier.models_allowed.map((name) => {
                const provider = models.find((m) => m.model_name === name)?.provider;
                const v: BadgeVariant = (provider ? PROVIDER_VARIANT[provider] : undefined) ?? "outline";
                return (
                  <Badge key={name} variant={v} className="font-mono">
                    {provider ? <span className="opacity-70 mr-1">{provider}:</span> : null}
                    {name}
                  </Badge>
                );
              })
            )}
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-1">
          <Button size="sm" variant="ghost" onClick={onEdit} disabled={busy}>
            <Pencil className="mr-1 h-3.5 w-3.5" /> {isEditing ? "Close" : "Edit"}
          </Button>
          <Button size="sm" variant="destructive" onClick={onDelete} disabled={busy}>
            <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function SummaryRow({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex gap-2">
      <span className="w-24 shrink-0 text-muted-foreground">{k}:</span>
      <span>{v}</span>
    </div>
  );
}

// 100000 → 100,000 — readable, no hard-coded units (we don't know if these
// are input/output/combined tokens; the gateway just enforces the integer).
function formatTokens(s: string): string {
  const n = Number(s);
  if (!Number.isFinite(n)) return s;
  return n.toLocaleString();
}

// -------------------------------------------------------------------------
// TierForm — used for both "add new" and "edit existing".
// -------------------------------------------------------------------------

function TierForm({
  mode, initial, models, onCancel, onSaved,
}: {
  mode: "new" | "edit";
  initial?: TierItem;
  models: ModelLite[];
  onCancel: () => void;
  onSaved: () => Promise<void> | void;
}) {
  const initialAllowAll = initial ? initial.models_allowed.includes("*") : false;

  const [tierName, setTierName]       = useState(initial?.tier ?? "");
  const [allowAll, setAllowAll]       = useState(initialAllowAll);
  const [allowed, setAllowed]         = useState<string[]>(
    initial && !initialAllowAll ? initial.models_allowed : [],
  );
  const [unlimited, setUnlimited]     = useState(initial?.tokens_per_day === "unlimited");
  const [tokensNum, setTokensNum]     = useState<string>(
    initial && initial.tokens_per_day !== "unlimited" ? initial.tokens_per_day : "100000",
  );
  const [rpm, setRpm]                 = useState<string>(String(initial?.rpm ?? 60));
  const [agentMode, setAgentMode]     = useState<AgentMode>(initial?.agent_mode ?? "tools_no_shell");
  const [overrideModel, setOverride]  = useState(initial?.override_model ?? false);
  const [description, setDescription] = useState(initial?.description ?? "");

  const [submitting, setSubmitting] = useState(false);
  const [formErr, setFormErr]   = useState<string | null>(null);
  const [nameErr, setNameErr]   = useState<string | null>(null);

  const toggleModel = (name: string) => {
    setAllowed((prev) =>
      prev.includes(name) ? prev.filter((m) => m !== name) : [...prev, name],
    );
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    setNameErr(null);

    // ----- validation up-front so we don't burn a 400 round-trip -----
    if (!tierName.trim()) {
      setNameErr("tier name is required");
      return;
    }
    const rpmN = Number(rpm);
    if (!Number.isFinite(rpmN) || rpmN < 0 || rpmN > 100000) {
      setFormErr("rpm must be an integer between 0 and 100000");
      return;
    }
    let tokensField: string;
    if (unlimited) {
      tokensField = "unlimited";
    } else {
      const n = Number(tokensNum);
      if (!Number.isFinite(n) || n < 0 || !Number.isInteger(n)) {
        setFormErr("tokens_per_day must be a non-negative integer (or use Unlimited)");
        return;
      }
      tokensField = String(n);
    }

    const modelsField = allowAll ? ["*"] : allowed;

    setSubmitting(true);
    try {
      const body: Record<string, unknown> = {
        tier: tierName.trim(),
        models_allowed: modelsField,
        tokens_per_day: tokensField,
        rpm: Math.trunc(rpmN),
        agent_mode: agentMode,
        override_model: overrideModel,
        description: description.trim() ? description.trim() : null,
      };

      const url = mode === "new"
        ? `${GW}/admin/tiers`
        : `${GW}/admin/tiers/${initial?.id}`;
      const r = await fetch(url, {
        method: mode === "new" ? "POST" : "PATCH",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify(body),
      });
      if (r.status === 409) {
        setNameErr("tier name already exists");
        return;
      }
      if (!r.ok) {
        const text = await r.text().catch(() => "");
        throw new Error(`${r.status} ${r.statusText}${text ? ` — ${text}` : ""}`);
      }
      await onSaved();
    } catch (e) {
      setFormErr(String(e));
    } finally {
      setSubmitting(false);
    }
  };

  // Sort: enabled-first, then alpha by name. Stable enough for a chip list
  // and matches the Models page default ordering on the eye.
  const sortedModels = useMemo(() => {
    return [...models].sort((a, b) => {
      const ae = a.enabled === false ? 1 : 0;
      const be = b.enabled === false ? 1 : 0;
      if (ae !== be) return ae - be;
      return a.model_name.localeCompare(b.model_name);
    });
  }, [models]);

  return (
    <Card className="border-accent/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-accent" />
          {mode === "new" ? "Add a tier" : `Edit ${initial?.tier ?? ""}`}
        </CardTitle>
        <CardDescription>
          Fields map 1:1 to <code className="rounded bg-muted px-1">tier_configs</code> rows.
          Saving rebuilds the live plugin chain.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          {/* Tier name */}
          <div className="space-y-1">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Tier name
            </label>
            <Input
              value={tierName}
              onChange={(e) => setTierName(e.target.value)}
              placeholder="L1_standard"
              required
              className="font-mono"
            />
            {nameErr && <div className="text-xs text-destructive">{nameErr}</div>}
          </div>

          {/* Models allowed */}
          <div className="space-y-2">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Models allowed
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={allowAll}
                onChange={(e) => setAllowAll(e.target.checked)}
                className="h-4 w-4 accent-accent"
              />
              <span>All models <span className="text-muted-foreground">(stores <code className="rounded bg-muted px-1 font-mono text-xs">[&quot;*&quot;]</code>)</span></span>
            </label>

            {!allowAll && (
              sortedModels.length === 0 ? (
                <div className="rounded-md border border-dashed border-border/60 bg-background/40 px-3 py-3 text-xs text-muted-foreground">
                  No models registered. Add models in <a href="/settings" className="text-accent underline-offset-2 hover:underline">Models</a> first,
                  then come back to scope this tier — or tick <span className="font-medium text-foreground">All models</span> above.
                </div>
              ) : (
                <div className="flex flex-wrap gap-1.5 rounded-md border border-border/60 bg-background/40 p-2">
                  {sortedModels.map((m) => {
                    const active = allowed.includes(m.model_name);
                    const provider = m.provider;
                    const v: BadgeVariant = (provider ? PROVIDER_VARIANT[provider] : undefined) ?? "outline";
                    return (
                      <button
                        key={String(m.id)}
                        type="button"
                        onClick={() => toggleModel(m.model_name)}
                        className={
                          "rounded-md border px-2 py-1 text-xs font-mono tracking-tight transition-colors " +
                          (active
                            ? "border-accent/60 bg-accent/15 text-accent-foreground"
                            : "border-border/60 bg-card/40 text-muted-foreground hover:bg-secondary/60 hover:text-foreground")
                        }
                        title={m.enabled === false ? "registered but disabled in router" : undefined}
                      >
                        <Badge variant={v} className="mr-1.5 px-1.5 py-0 text-[10px]">{provider ?? "?"}</Badge>
                        <span>{m.model_name}</span>
                        {m.enabled === false && <span className="ml-1 opacity-60">(off)</span>}
                      </button>
                    );
                  })}
                </div>
              )
            )}
            <div className="text-[11px] text-muted-foreground">
              {allowAll
                ? "This tier may call any registered model."
                : `${allowed.length} model${allowed.length === 1 ? "" : "s"} selected.`}
            </div>
          </div>

          {/* Tokens / day + unlimited */}
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Tokens per day
              </label>
              <Input
                type="number"
                min={0}
                step={1}
                value={tokensNum}
                onChange={(e) => setTokensNum(e.target.value)}
                disabled={unlimited}
                className="font-mono"
              />
              <label className="mt-1 flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={unlimited}
                  onChange={(e) => setUnlimited(e.target.checked)}
                  className="h-4 w-4 accent-accent"
                />
                <span>Unlimited <span className="text-muted-foreground">(stores <code className="rounded bg-muted px-1 font-mono text-xs">&quot;unlimited&quot;</code>)</span></span>
              </label>
            </div>

            {/* RPM */}
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Requests per minute
              </label>
              <Input
                type="number"
                min={0}
                max={100000}
                step={1}
                value={rpm}
                onChange={(e) => setRpm(e.target.value)}
                className="font-mono"
              />
              <div className="text-[11px] text-muted-foreground">
                Range 0–100,000. Enforced by the rate-limit plugin per (team, tier).
              </div>
            </div>
          </div>

          {/* Agent mode + override_model */}
          <div className="grid gap-3 md:grid-cols-3">
            <div className="md:col-span-2 space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Agent mode
              </label>
              <select
                value={agentMode}
                onChange={(e) => setAgentMode(e.target.value as AgentMode)}
                className="flex h-10 w-full rounded-md border border-border/70 bg-background/60 px-3 py-1 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {AGENT_MODES.map((m) => (
                  <option key={m.id} value={m.id}>{m.label}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Override model
              </label>
              <button
                type="button"
                onClick={() => setOverride((v) => !v)}
                aria-label={overrideModel ? "Disallow override" : "Allow override"}
                className="flex h-10 w-full items-center justify-between rounded-md border border-border/70 bg-background/60 px-3 text-sm transition-colors hover:bg-secondary/40"
              >
                <span className={overrideModel ? "text-foreground" : "text-muted-foreground"}>
                  {overrideModel ? "Allowed" : "Locked to client choice"}
                </span>
                <span
                  className={
                    "relative inline-flex h-5 w-9 items-center rounded-full border border-border/70 " +
                    (overrideModel ? "bg-accent" : "bg-secondary")
                  }
                >
                  <span
                    className={
                      "inline-block h-4 w-4 transform rounded-full bg-background shadow transition-transform " +
                      (overrideModel ? "translate-x-4" : "translate-x-0.5")
                    }
                  />
                </span>
              </button>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Description (optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="e.g. day-to-day developer tier — chat + tools, no shell."
              className="flex w-full rounded-md border border-input bg-background/60 px-3 py-2 text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            />
          </div>

          {formErr && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
              {formErr}
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={onCancel} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" variant="accent" disabled={submitting || !tierName.trim()}>
              {submitting
                ? (mode === "new" ? "Creating…" : "Saving…")
                : (mode === "new" ? "Create tier" : "Save changes")}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
