"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, Copy, KeyRound, Plus, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type Team = { team_id: string; tier: string };

type IssuedKey = {
  id: number;
  raw_key: string;
  key_prefix: string;
  user_id: string;
  team_id: string;
};

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

// The gateway's chat-completions URL as seen by the developer's machine.
// This is what gets dropped into VS Code / Cline / Aider — it must be an
// address the dev box can actually reach, NOT the BFF (which requires
// session cookies). Defaulting to localhost:4000 since that's what the
// local-dev Ollama story is built around. Override via the input below
// if you've put the gateway behind a reverse proxy.
const DEFAULT_BASE = "http://localhost:4000";

export default function ConnectPage() {
  const [teams, setTeams]     = useState<Team[]>([]);
  const [userId, setUserId]   = useState("");
  const [email, setEmail]     = useState("");
  const [teamId, setTeamId]   = useState("");
  const [creating, setCreating] = useState(false);
  const [err, setErr]         = useState<string | null>(null);
  const [issued, setIssued]   = useState<IssuedKey | null>(null);
  const [base, setBase]       = useState(DEFAULT_BASE);

  // Load teams once for the team selector.
  useEffect(() => {
    fetch(`${GW}/admin/teams`, { credentials: "same-origin", cache: "no-store" })
      .then((r) => (r.ok ? r.json() : []))
      .then((ts: Team[]) => {
        setTeams(ts);
        if (ts.length > 0 && !teamId) setTeamId(ts[0].team_id);
      })
      .catch(() => {});
  }, [teamId]);

  const issue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId || !teamId) return;
    setCreating(true);
    setErr(null);
    try {
      const r = await fetch(`${GW}/admin/keys`, {
        method: "POST",
        headers: JSON_HEADERS,
        credentials: "same-origin",
        body: JSON.stringify({
          user_id: userId, team_id: teamId,
          user_email: email || null, role: "developer",
        }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      setIssued(await r.json());
    } catch (e) {
      setErr(String(e));
    } finally {
      setCreating(false);
    }
  };

  // The key value injected into every recipe. Once we issue, use the real
  // value so users can copy a working snippet straight away. Otherwise
  // emit a placeholder so the page is still useful before issuing.
  const apiKey = issued?.raw_key ?? "<YOUR_API_KEY>";

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Heading */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Connect</h1>
          <p className="text-muted-foreground">
            Issue an API key and drop it into your editor. Calls flow through the gateway →
            local Ollama, with audit + UEBA + quotas applied transparently.
          </p>
        </div>
        <Badge variant="accent" className="px-3 py-1">Quickstart</Badge>
      </div>

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">{err}</CardContent>
        </Card>
      )}

      {/* Step 1 — issue */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-accent/15 text-[11px] font-semibold text-accent">1</span>
            Issue an API key
          </CardTitle>
          <CardDescription>
            Keys are surfaced exactly once. Save it somewhere safe — the gateway only stores a hash.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={issue} className="grid gap-3 md:grid-cols-4">
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">User ID</label>
              <Input value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="alice" required />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Email (optional)</label>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="alice@dev.local" type="email" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Team</label>
              <select
                value={teamId}
                onChange={(e) => setTeamId(e.target.value)}
                className="flex h-10 w-full rounded-md border border-border/70 bg-background/60 px-3 py-1 text-sm"
                required
              >
                {teams.map((t) => (
                  <option key={t.team_id} value={t.team_id}>{t.team_id} · {t.tier}</option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <Button type="submit" variant="accent" disabled={creating || !userId || !teamId} className="w-full">
                {creating ? "Issuing…" : <><Plus className="mr-1 h-4 w-4" /> Issue key</>}
              </Button>
            </div>
          </form>

          {issued && (
            <div className="mt-5 rounded-xl border border-accent/40 bg-accent/5 p-4">
              <div className="mb-2 flex items-center gap-2 text-sm font-medium">
                <Sparkles className="h-4 w-4 text-accent" />
                Key issued for <span className="font-mono">{issued.user_id}</span> on <span className="font-mono">{issued.team_id}</span>
              </div>
              <CopyBlock label="API key (copy now — won't be shown again)" value={issued.raw_key} mono />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Step 2 — base URL */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-accent/15 text-[11px] font-semibold text-accent">2</span>
            Confirm the gateway URL
          </CardTitle>
          <CardDescription>
            What your dev box uses to reach the gateway. Override if you&apos;ve put it behind a reverse proxy.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Input value={base} onChange={(e) => setBase(e.target.value)} placeholder="http://localhost:4000" className="font-mono" />
        </CardContent>
      </Card>

      {/* Step 3 — recipes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-accent/15 text-[11px] font-semibold text-accent">3</span>
            Drop it into your editor
          </CardTitle>
          <CardDescription>
            Each recipe targets the gateway&apos;s OpenAI-compatible endpoint. Use the model
            name <span className="font-mono">qwen2.5-coder-7b</span> (local), or omit to let the
            smart router pick.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-3 text-sm text-muted-foreground">
            <strong>Tip</strong>: leave the model field as <span className="font-mono">auto</span> and let the smart router pick based on your prompt. Visit{" "}
            <a href="/router" className="text-accent underline-offset-2 hover:underline">Smart Router</a>{" "}
            to see how requests get routed live.
          </p>
          <Recipes apiKey={apiKey} base={base} />
        </CardContent>
      </Card>

      {/* Footer hint */}
      <p className="text-center text-xs text-muted-foreground">
        Every call lands in the audit log. Visit{" "}
        <a href="/audit" className="text-accent underline-offset-2 hover:underline">Audit Log</a>{" "}
        to inspect, or{" "}
        <a href="/metrics" className="text-accent underline-offset-2 hover:underline">Metrics</a>{" "}
        for Prometheus output.
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------------ */
/*  Recipe components — tabbed snippet panels with copy buttons.            */
/* ------------------------------------------------------------------------ */

function Recipes({ apiKey, base }: { apiKey: string; base: string }) {
  const tabs = useMemo(
    () => [
      { id: "curl",     label: "curl",        snippet: curlSnippet(apiKey, base),     filename: undefined },
      { id: "openai",   label: "Python (OpenAI SDK)", snippet: pythonSnippet(apiKey, base), filename: undefined },
      { id: "cline",    label: "VS Code · Cline",     snippet: clineSnippet(apiKey, base),  filename: ".vscode/settings.json" },
      { id: "continue", label: "Continue.dev",        snippet: continueSnippet(apiKey, base), filename: "~/.continue/config.json" },
      { id: "aider",    label: "aider",       snippet: aiderSnippet(apiKey, base),    filename: "~/.aider.conf.yml" },
      { id: "envrc",    label: ".envrc / shell",      snippet: envrcSnippet(apiKey, base),  filename: ".envrc" },
    ],
    [apiKey, base],
  );
  const [active, setActive] = useState(tabs[0].id);
  const tab = tabs.find((t) => t.id === active) ?? tabs[0];

  return (
    <div>
      {/* Tab strip */}
      <div className="mb-3 flex flex-wrap items-center gap-1 rounded-lg border border-border/60 bg-card/40 p-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setActive(t.id)}
            className={
              "rounded-md px-3 py-1.5 text-xs font-medium tracking-tight transition-colors " +
              (active === t.id
                ? "bg-secondary text-foreground shadow-sm"
                : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground")
            }
          >
            {t.label}
          </button>
        ))}
      </div>
      <CopyBlock label={tab.filename} value={tab.snippet} />
    </div>
  );
}

function CopyBlock({ label, value, mono = false }: { label?: string; value: string; mono?: boolean }) {
  const [copied, setCopied] = useState(false);
  const onCopy = async () => {
    try { await navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1500); }
    catch { /* clipboard might be unavailable in non-https / unfocused; ignore */ }
  };
  return (
    <div className="overflow-hidden rounded-lg border border-border/60 bg-background/40">
      <div className="flex items-center justify-between border-b border-border/60 px-3 py-1.5 text-[11px] uppercase tracking-wider text-muted-foreground">
        <span className="font-mono normal-case">{label ?? ""}</span>
        <button
          onClick={onCopy}
          className="flex items-center gap-1 rounded-md px-2 py-1 text-[11px] hover:bg-secondary/60"
          aria-label="Copy"
        >
          {copied ? <><Check className="h-3 w-3 text-emerald-500" /> Copied</> : <><Copy className="h-3 w-3" /> Copy</>}
        </button>
      </div>
      <pre className={"max-h-[420px] overflow-auto p-3 text-[12px] leading-relaxed " + (mono ? "font-mono" : "font-mono")}>
        <code>{value}</code>
      </pre>
    </div>
  );
}

/* ------------------------------------------------------------------------ */
/*  Snippet builders — each kept in its own function so the rendered text   */
/*  is easy to read inline rather than buried in JSX.                       */
/* ------------------------------------------------------------------------ */

function curlSnippet(key: string, base: string): string {
  return `curl -s ${base}/v1/chat/completions \\
  -H "Authorization: Bearer ${key}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "auto",
    "messages": [
      {"role": "user", "content": "Write a Python one-liner that reverses a string."}
    ]
  }'`;
}

function pythonSnippet(key: string, base: string): string {
  return `# pip install openai
from openai import OpenAI

client = OpenAI(
    api_key="${key}",
    base_url="${base}/v1",
)

resp = client.chat.completions.create(
    model="auto",
    messages=[{"role": "user", "content": "Reverse a string in Python, one line."}],
)
print(resp.choices[0].message.content)`;
}

function clineSnippet(key: string, base: string): string {
  return `// Model "auto" lets the gateway's smart router pick — see /router for routing decisions.
// .vscode/settings.json — put it in your workspace, not commit ${key.startsWith("sk-") ? "(this key)" : ""}.
// Cline reads "OpenAI Compatible" provider settings; the gateway IS OpenAI-compatible.
{
  "cline.apiProvider": "openai",
  "cline.openAiApiKey": "${key}",
  "cline.openAiBaseUrl": "${base}/v1",
  "cline.openAiModelId": "auto"
}`;
}

function continueSnippet(key: string, base: string): string {
  return `// ~/.continue/config.json — append to the "models" array.
{
  "models": [
    {
      "title": "OATI LLMGateway (auto-routed)",
      "provider": "openai",
      "model": "auto",
      "apiBase": "${base}/v1",
      "apiKey": "${key}"
    }
  ]
}`;
}

function aiderSnippet(key: string, base: string): string {
  return `# ~/.aider.conf.yml
openai-api-base: ${base}/v1
openai-api-key:  ${key}
model:           auto
# Then run:
#   aider --model auto path/to/file.py`;
}

function envrcSnippet(key: string, base: string): string {
  return `# .envrc — auto-loaded by direnv, or source manually.
export OPENAI_API_KEY="${key}"
export OPENAI_BASE_URL="${base}/v1"
# Pass model=auto in your client to let the gateway router pick.
# Compatible with: openai (python), litellm, langchain, llama-index,
# instructor, marvin, and anything that reads OPENAI_BASE_URL.`;
}
