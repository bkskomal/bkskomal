"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Pencil, Plus, RefreshCw, ShieldX, Trash2, X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

// -------------------------------------------------------------------------
// Types — match the gateway's GuardrailPattern shape. Fields the API
// treats as optional are optional here too so the row renderer can no-op
// cleanly when the SOC didn't supply notes / created_by.
// -------------------------------------------------------------------------

type Kind = "banned_topic" | "dlp_extra" | "output_scan_extra";
type Severity = "info" | "low" | "warn" | "high" | "critical";
type Action = "refuse" | "warn" | "redact";

type PatternItem = {
  id: number | string;
  kind: Kind;
  name: string;
  pattern: string;
  severity: Severity;
  action: Action;
  is_active: boolean;
  created_by?: string | null;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
};

type BadgeVariant = "default" | "secondary" | "destructive" | "outline" | "success" | "warning" | "accent";

const GW = "/api/gateway";
const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

const SEVERITIES: Severity[] = ["info", "low", "warn", "high", "critical"];
const ACTIONS: Action[] = ["refuse", "warn", "redact"];

const SEVERITY_VARIANT: Record<Severity, BadgeVariant> = {
  info:     "default",
  low:      "secondary",
  warn:     "warning",
  high:     "destructive",
  critical: "destructive",
};

const ACTION_VARIANT: Record<Action, BadgeVariant> = {
  refuse: "destructive",
  warn:   "warning",
  redact: "accent",
};

// Section metadata — keeps the per-kind copy in one place so the page body
// stays declarative (one <Section/> per entry).
const SECTIONS: { kind: Kind; title: string; blurb: string; patternHint: string }[] = [
  {
    kind:        "banned_topic",
    title:       "Banned topics",
    blurb:       "Keyword/phrase blocks added by the SOC; the plugin treats them as substring matches (the pattern field is a literal string).",
    patternHint: "literal substring",
  },
  {
    kind:        "dlp_extra",
    title:       "DLP extras",
    blurb:       "Additional regex patterns scanned in the prompt before egress.",
    patternHint: "regex",
  },
  {
    kind:        "output_scan_extra",
    title:       "Output-scan extras",
    blurb:       "Additional regex patterns scanned in the model RESPONSE.",
    patternHint: "regex",
  },
];

// -------------------------------------------------------------------------
// Page
// -------------------------------------------------------------------------

export default function GuardrailsPage() {
  // One bucket per kind. `null` = not loaded yet, `[]` = loaded-but-empty.
  // Keeping them separate (rather than one flat array filtered N times)
  // means each section's add/edit interactions can't accidentally re-render
  // the others.
  const [items, setItems] = useState<Record<Kind, PatternItem[] | null>>({
    banned_topic:      null,
    dlp_extra:         null,
    output_scan_extra: null,
  });
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [reloading, setReloading] = useState(false);

  // Form state per section — null means closed, "new" means add-new,
  // otherwise the id of the row being edited. Independent per kind so
  // editing in one section doesn't collapse another.
  const [formMode, setFormMode] = useState<Record<Kind, null | "new" | string>>({
    banned_topic:      null,
    dlp_extra:         null,
    output_scan_extra: null,
  });

  const reloadKind = useCallback(async (kind: Kind) => {
    const r = await fetch(
      `${GW}/admin/guardrails/patterns?kind=${kind}&include_inactive=true`,
      { headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store" },
    );
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
    const data: PatternItem[] = await r.json();
    setItems((prev) => ({ ...prev, [kind]: data }));
  }, []);

  const reloadAll = useCallback(async () => {
    try {
      await Promise.all(SECTIONS.map((s) => reloadKind(s.kind)));
      setErr(null);
    } catch (e) {
      setErr(String(e));
    }
  }, [reloadKind]);

  useEffect(() => { void reloadAll(); }, [reloadAll]);

  const counts = useMemo(() => {
    const total: Record<Kind, number> = {
      banned_topic:      items.banned_topic?.length      ?? 0,
      dlp_extra:         items.dlp_extra?.length         ?? 0,
      output_scan_extra: items.output_scan_extra?.length ?? 0,
    };
    const active =
      (items.banned_topic?.filter((p) => p.is_active).length      ?? 0) +
      (items.dlp_extra?.filter((p) => p.is_active).length         ?? 0) +
      (items.output_scan_extra?.filter((p) => p.is_active).length ?? 0);
    const all = total.banned_topic + total.dlp_extra + total.output_scan_extra;
    return { active, all };
  }, [items]);

  const reloadPolicies = async () => {
    setReloading(true);
    try {
      const r = await fetch(`${GW}/admin/policies/reload`, {
        method: "POST", credentials: "same-origin", headers: JSON_HEADERS,
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      const data = await r.json();
      // Echo the per-kind counts — that's the most useful "did it work?" signal.
      const parts: string[] = [];
      if (typeof data?.tiers === "number") parts.push(`${data.tiers} tiers`);
      if (typeof data?.banned_topics === "number") parts.push(`${data.banned_topics} banned topics`);
      if (typeof data?.dlp_extra_patterns === "number") parts.push(`${data.dlp_extra_patterns} DLP extras`);
      if (typeof data?.output_scan_extra_patterns === "number") parts.push(`${data.output_scan_extra_patterns} output-scan extras`);
      setInfo(`Plugin chain reloaded${parts.length ? ` — ${parts.join(", ")}` : ""}`);
      setTimeout(() => setInfo(null), 4000);
      await reloadAll();
    } catch (e) {
      setErr(String(e));
    } finally {
      setReloading(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* Heading */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="page-title">Guardrails &amp; DLP</h1>
          <p className="text-muted-foreground">
            Operator-added patterns layered on top of the shipped baseline. Edits hot-reload the plugin chain.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="accent" className="px-3 py-1">
            {counts.active} active / {counts.all} total
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={reloadPolicies}
            disabled={reloading}
            title="Re-read patterns from the DB and rebuild the plugin chain. Normally not needed — every CUD already reloads server-side."
          >
            <RefreshCw className={"mr-1 h-3.5 w-3.5 " + (reloading ? "animate-spin" : "")} />
            {reloading ? "Reloading…" : "Reload"}
          </Button>
        </div>
      </div>

      {info && (
        <Card className="border-accent/40">
          <CardContent className="p-3 text-sm text-accent-foreground">{info}</CardContent>
        </Card>
      )}

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">Error: {err}</CardContent>
        </Card>
      )}

      {/* Three sections */}
      {SECTIONS.map((s) => (
        <Section
          key={s.kind}
          kind={s.kind}
          title={s.title}
          blurb={s.blurb}
          patternHint={s.patternHint}
          rows={items[s.kind]}
          formMode={formMode[s.kind]}
          setFormMode={(m) => setFormMode((prev) => ({ ...prev, [s.kind]: m }))}
          reload={() => reloadKind(s.kind)}
          onError={setErr}
        />
      ))}
    </div>
  );
}

// -------------------------------------------------------------------------
// Section — header + table + (optionally) the in-place form for this kind.
// -------------------------------------------------------------------------

function Section({
  kind, title, blurb, patternHint,
  rows, formMode, setFormMode, reload, onError,
}: {
  kind: Kind;
  title: string;
  blurb: string;
  patternHint: string;
  rows: PatternItem[] | null;
  formMode: null | "new" | string;
  setFormMode: (m: null | "new" | string) => void;
  reload: () => Promise<void>;
  onError: (e: string) => void;
}) {
  const editing = useMemo(() => {
    if (!formMode || formMode === "new" || !rows) return null;
    return rows.find((r) => String(r.id) === formMode) ?? null;
  }, [formMode, rows]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0">
        <div className="space-y-1">
          <CardTitle className="flex items-center gap-2">
            <ShieldX className="h-4 w-4 text-accent" />
            {title}
          </CardTitle>
          <CardDescription>{blurb}</CardDescription>
        </div>
        <Button
          size="sm"
          variant="accent"
          onClick={() => setFormMode(formMode === "new" ? null : "new")}
        >
          {formMode === "new" ? (
            <><X className="mr-1 h-3.5 w-3.5" /> Cancel</>
          ) : (
            <><Plus className="mr-1 h-3.5 w-3.5" /> Add pattern</>
          )}
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {formMode === "new" && (
          <PatternForm
            mode="new"
            kind={kind}
            patternHint={patternHint}
            onCancel={() => setFormMode(null)}
            onSaved={async () => { setFormMode(null); await reload(); }}
            onError={onError}
          />
        )}

        {rows === null ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No patterns added — the shipped baseline is still active. Click{" "}
            <span className="font-medium text-foreground">+ Add</span> to extend it.
          </p>
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Name</TH>
                <TH>Pattern</TH>
                <TH>Severity</TH>
                <TH>Action</TH>
                <TH>Active</TH>
                <TH>Created by</TH>
                <TH className="text-right">Actions</TH>
              </TR>
            </THead>
            <TBody>
              {rows.map((p) => {
                const id = String(p.id);
                const isEditing = formMode === id;
                return (
                  <PatternRowAndForm
                    key={id}
                    p={p}
                    kind={kind}
                    patternHint={patternHint}
                    isEditing={isEditing}
                    onEdit={() => setFormMode(isEditing ? null : id)}
                    onCancel={() => setFormMode(null)}
                    reload={reload}
                    onError={onError}
                    editingItem={editing && String(editing.id) === id ? editing : null}
                  />
                );
              })}
            </TBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

// -------------------------------------------------------------------------
// PatternRowAndForm — the read row plus an edit-form sibling row.
// Splitting them lets the form get its own full-width <tr> rather than
// trying to squeeze inline into the data row.
// -------------------------------------------------------------------------

function PatternRowAndForm({
  p, kind, patternHint, isEditing, editingItem,
  onEdit, onCancel, reload, onError,
}: {
  p: PatternItem;
  kind: Kind;
  patternHint: string;
  isEditing: boolean;
  editingItem: PatternItem | null;
  onEdit: () => void;
  onCancel: () => void;
  reload: () => Promise<void>;
  onError: (e: string) => void;
}) {
  const [busy, setBusy] = useState(false);

  const toggleActive = async () => {
    setBusy(true);
    try {
      const r = await fetch(`${GW}/admin/guardrails/patterns/${p.id}`, {
        method: "PATCH",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({ is_active: !p.is_active }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      await reload();
    } catch (e) {
      onError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!confirm(`Delete pattern "${p.name}"? The plugin chain will hot-reload.`)) return;
    setBusy(true);
    try {
      const r = await fetch(`${GW}/admin/guardrails/patterns/${p.id}`, {
        method: "DELETE", credentials: "same-origin",
      });
      if (!r.ok && r.status !== 204) throw new Error(`${r.status} ${r.statusText}`);
      await reload();
    } catch (e) {
      onError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const dim = p.is_active ? "" : "opacity-60";

  return (
    <>
      <TR className={dim}>
        <TD className="font-mono text-xs">{p.name}</TD>
        <TD className="max-w-[260px]">
          <span
            className="block truncate font-mono text-xs text-muted-foreground"
            title={p.pattern}
          >
            {p.pattern}
          </span>
        </TD>
        <TD>
          <Badge variant={SEVERITY_VARIANT[p.severity]}>{p.severity}</Badge>
        </TD>
        <TD>
          <Badge variant={ACTION_VARIANT[p.action]}>{p.action}</Badge>
        </TD>
        <TD>
          <button
            onClick={toggleActive}
            disabled={busy}
            aria-label={p.is_active ? "Deactivate pattern" : "Activate pattern"}
            className={
              "relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border border-border/70 transition-colors " +
              (p.is_active ? "bg-accent" : "bg-secondary") +
              (busy ? " opacity-50" : "")
            }
          >
            <span
              className={
                "inline-block h-4 w-4 transform rounded-full bg-background shadow transition-transform " +
                (p.is_active ? "translate-x-4" : "translate-x-0.5")
              }
            />
          </button>
        </TD>
        <TD className="text-xs text-muted-foreground">{p.created_by ?? "—"}</TD>
        <TD>
          <div className="flex items-center justify-end gap-1.5">
            <Button size="sm" variant="ghost" onClick={onEdit} disabled={busy}>
              <Pencil className="mr-1 h-3.5 w-3.5" /> {isEditing ? "Close" : "Edit"}
            </Button>
            <Button size="sm" variant="destructive" onClick={remove} disabled={busy}>
              <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
            </Button>
          </div>
        </TD>
      </TR>
      {isEditing && editingItem && (
        <TR>
          <TD colSpan={7} className="bg-secondary/20 p-4">
            <PatternForm
              mode="edit"
              kind={kind}
              patternHint={patternHint}
              initial={editingItem}
              onCancel={onCancel}
              onSaved={async () => { onCancel(); await reload(); }}
              onError={onError}
            />
          </TD>
        </TR>
      )}
    </>
  );
}

// -------------------------------------------------------------------------
// PatternForm — used for both "add new" and "edit existing".
// -------------------------------------------------------------------------

function PatternForm({
  mode, kind, patternHint, initial, onCancel, onSaved, onError,
}: {
  mode: "new" | "edit";
  kind: Kind;
  patternHint: string;
  initial?: PatternItem;
  onCancel: () => void;
  onSaved: () => Promise<void> | void;
  onError: (e: string) => void;
}) {
  const [name, setName]         = useState(initial?.name ?? "");
  const [pattern, setPattern]   = useState(initial?.pattern ?? "");
  const [severity, setSeverity] = useState<Severity>(initial?.severity ?? "warn");
  const [action, setAction]     = useState<Action>(initial?.action ?? (kind === "output_scan_extra" ? "redact" : "refuse"));
  const [isActive, setIsActive] = useState<boolean>(initial?.is_active ?? true);
  const [notes, setNotes]       = useState(initial?.notes ?? "");

  const [submitting, setSubmitting] = useState(false);
  const [formErr, setFormErr]       = useState<string | null>(null);
  const [patternErr, setPatternErr] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErr(null);
    setPatternErr(null);

    if (!name.trim() || !pattern.trim()) {
      setFormErr("Name and pattern are required.");
      return;
    }
    if (name.length > 128) {
      setFormErr("Name must be 128 characters or fewer.");
      return;
    }

    setSubmitting(true);
    try {
      const body: Record<string, unknown> = {
        name: name.trim(),
        pattern,                      // preserve exact whitespace — regex/literal matters
        severity,
        action,
        is_active: isActive,
      };
      if (mode === "new") body.kind = kind;
      if (notes.trim()) body.notes = notes.trim();
      else if (mode === "edit") body.notes = null;   // explicit clear on edit

      const url = mode === "new"
        ? `${GW}/admin/guardrails/patterns`
        : `${GW}/admin/guardrails/patterns/${initial?.id}`;

      const r = await fetch(url, {
        method: mode === "new" ? "POST" : "PATCH",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify(body),
      });

      if (r.status === 400) {
        // The gateway returns a GuardrailError envelope. Surface the regex
        // failure inline next to the pattern field; everything else goes
        // to the form-level banner.
        const text = await r.text().catch(() => "");
        const lower = text.toLowerCase();
        if (lower.includes("regex") || lower.includes("pattern")) {
          setPatternErr(text || "Invalid regex");
        } else {
          setFormErr(text || "Invalid input");
        }
        return;
      }
      if (!r.ok) {
        const text = await r.text().catch(() => "");
        throw new Error(`${r.status} ${r.statusText}${text ? ` — ${text}` : ""}`);
      }
      await onSaved();
    } catch (e) {
      const msg = String(e);
      setFormErr(msg);
      onError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="border-accent/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldX className="h-4 w-4 text-accent" />
          {mode === "new" ? `Add pattern (${kind})` : `Edit ${initial?.name ?? ""}`}
        </CardTitle>
        <CardDescription>
          {kind === "banned_topic"
            ? "Substring match on prompts. Case-insensitive in the plugin."
            : "Python-flavoured regex. Compiled once on save."}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          {/* Name + active */}
          <div className="grid gap-3 md:grid-cols-3">
            <div className="md:col-span-2 space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Name
              </label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="aws-secret-key-extras"
                required
                maxLength={128}
                className="font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Active
              </label>
              <button
                type="button"
                onClick={() => setIsActive((v) => !v)}
                aria-label={isActive ? "Deactivate" : "Activate"}
                className="flex h-10 w-full items-center justify-between rounded-md border border-border/70 bg-background/60 px-3 text-sm transition-colors hover:bg-secondary/40"
              >
                <span className={isActive ? "text-foreground" : "text-muted-foreground"}>
                  {isActive ? "On — enforced" : "Off — stored, ignored"}
                </span>
                <span
                  className={
                    "relative inline-flex h-5 w-9 items-center rounded-full border border-border/70 " +
                    (isActive ? "bg-accent" : "bg-secondary")
                  }
                >
                  <span
                    className={
                      "inline-block h-4 w-4 transform rounded-full bg-background shadow transition-transform " +
                      (isActive ? "translate-x-4" : "translate-x-0.5")
                    }
                  />
                </span>
              </button>
            </div>
          </div>

          {/* Pattern */}
          <div className="space-y-1">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Pattern <span className="ml-1 text-[10px] font-normal normal-case text-muted-foreground/80">({patternHint})</span>
            </label>
            <textarea
              value={pattern}
              onChange={(e) => setPattern(e.target.value)}
              spellCheck={false}
              required
              rows={Math.min(8, Math.max(3, pattern.split("\n").length + 1))}
              placeholder={kind === "banned_topic"
                ? "internal codename foo"
                : "AKIA[0-9A-Z]{16}"}
              className="flex w-full rounded-md border border-input bg-background/60 px-3 py-2 font-mono text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            />
            {patternErr && (
              <div className="text-xs text-destructive">{patternErr}</div>
            )}
          </div>

          {/* Severity + action */}
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Severity
              </label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as Severity)}
                className="flex h-10 w-full rounded-md border border-border/70 bg-background/60 px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {SEVERITIES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Action
              </label>
              <select
                value={action}
                onChange={(e) => setAction(e.target.value as Action)}
                className="flex h-10 w-full rounded-md border border-border/70 bg-background/60 px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {ACTIONS.map((a) => (
                  <option key={a} value={a}>{a}</option>
                ))}
              </select>
              {kind === "output_scan_extra" && (
                <p className="text-[11px] text-muted-foreground">
                  Output-scan plugin always uses <span className="font-mono">redact</span> regardless of this value.
                </p>
              )}
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Notes <span className="ml-1 text-[10px] font-normal normal-case text-muted-foreground/80">(optional)</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Why this pattern exists / linked ticket"
              className="flex w-full rounded-md border border-input bg-background/60 px-3 py-2 text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            />
          </div>

          {formErr && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
              {formErr}
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={onCancel} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" variant="accent" disabled={submitting || !name.trim() || !pattern.trim()}>
              {submitting
                ? (mode === "new" ? "Creating…" : "Saving…")
                : (mode === "new" ? "Create pattern" : "Save changes")}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
