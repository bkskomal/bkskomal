"use client";

import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle, CheckCircle2, ChevronDown, ChevronRight, Loader2,
  RefreshCw, RotateCcw, ShieldAlert, ShieldCheck, ShieldQuestion, XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { InfoBox } from "@/components/ui/info-box";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

// ---------------------------------------------------------------------------
// API contract — mirrors /admin/ueba/* from gateway/src/gateway/api/admin.py
// ---------------------------------------------------------------------------

type AlertStatus = "open" | "acknowledged" | "resolved" | "false_positive";
type AlertSeverity = "info" | "low" | "warn" | "high" | "critical";

type UebaAlert = {
  id: number;
  raised_at: string;
  user_id: string | null;
  team_id: string | null;
  tier: string | null;
  signal: string;
  severity: AlertSeverity | string;
  summary: string;
  details: Record<string, unknown> | null;
  status: AlertStatus | string;
};

type AlertsResponse = {
  status_filter: string;
  count: number;
  alerts: UebaAlert[];
};

type UserState = {
  enabled: boolean;
  user_id: string;
  jailbreak_attempts_today?: number;
  refusal_velocity_5min?: number;
  dlp_hits_week?: number;
  output_secret_leaks_today?: number;
  [k: string]: unknown;
};

// /admin/ueba/user/{id}/baseline — 7-day rolling per-user activity profile.
// `hour_of_day_tokens` always has 24 string keys "0".."23"; missing hours
// are zero. `model_mix` is sparse — only models the user actually hit.
type UserBaseline = {
  enabled: boolean;
  user_id: string;
  window_days: number;
  total_requests: number;
  hour_of_day_tokens: Record<string, number>;
  model_mix: Record<string, number>;
};

// /admin/ueba/user/{id}/radar — 10-axis behavioural risk profile. Each
// score is 0..100; `total_score` is the average across the 10 axes. The
// `axes` list dictates display order (also gives us a label for each key
// without us hard-coding it on the client).
type RadarAxisKey =
  | "jailbreak" | "refusal" | "dlp" | "secret_leak" | "self_approval"
  | "elev_burst" | "off_hours" | "volume_spike" | "model_mix" | "quarantine";

type UserRadar = {
  enabled: boolean;
  user_id: string;
  scores: Record<RadarAxisKey, number>;
  total_score: number;
  axes: { key: RadarAxisKey; label: string }[];
};

// Per `ueba_service.digest_since` the gateway returns a dict keyed by signal
// name (tokens / refusals / jailbreak / dlp_hits / output_leaks) with each
// value a list of rows shaped roughly:
//   { user_id, team_id, ...one_count_field }
// We render whichever count-shaped key exists on each row.
type DigestRow = {
  user_id: string | null;
  team_id: string | null;
  [k: string]: unknown;
};
type DigestResponse = {
  since: string;
  hours: number;
  generated_at: string;
  outliers: Record<string, DigestRow[]>;
};

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const GW = "/api/gateway";
const REFRESH_INTERVAL_MS = 15_000;

// Status filter chip vocabulary.
const STATUS_FILTERS: { key: "open" | "acknowledged" | "resolved" | "all"; label: string }[] = [
  { key: "open",         label: "Open" },
  { key: "acknowledged", label: "Acknowledged" },
  { key: "resolved",     label: "Resolved" },
  { key: "all",          label: "All" },
];

// Severity → Badge variant. Same mapping used elsewhere in the dashboard so
// an operator's mental colour-key stays consistent across pages.
type BadgeVariant =
  | "default" | "secondary" | "destructive" | "outline"
  | "success" | "warning" | "accent";

const SEVERITY_VARIANT: Record<string, BadgeVariant> = {
  info:     "default",
  low:      "secondary",
  warn:     "warning",
  high:     "destructive",
  critical: "destructive",
};

const STATUS_VARIANT: Record<string, BadgeVariant> = {
  open:           "warning",
  acknowledged:   "accent",
  resolved:       "success",
  false_positive: "secondary",
};

// Same provider colour vocabulary as Models / Tiers / Router pages — keep
// the chip language consistent across surfaces so an operator's mental
// "green = ollama, accent = openrouter" mapping never breaks.
const PROVIDER_VARIANT: Record<string, BadgeVariant> = {
  ollama:            "success",
  openrouter:        "accent",
  openai:            "secondary",
  openai_compatible: "secondary",
  anthropic:         "warning",
  bedrock:           "default",
  azure:             "default",
  gemini:            "default",
  vertex:            "default",
  groq:              "default",
  together:          "default",
  custom:            "default",
};

// Pull the provider out of a model identifier. The model_mix keys come
// straight from LiteLLM route names ("openrouter/vendor/x", "ollama_chat/y",
// "openai/gpt-4o"); strip a trailing "_chat" so "ollama_chat" lines up with
// the chip mapping. Returns null if we don't recognise the head — the bar
// just renders in the default accent then.
function providerFromModel(model: string): string | null {
  if (!model) return null;
  const head = model.split("/")[0]?.toLowerCase() ?? "";
  if (!head) return null;
  const normalized = head.endsWith("_chat") ? head.slice(0, -"_chat".length) : head;
  if (normalized in PROVIDER_VARIANT) return normalized;
  return null;
}

// Map a Badge-variant name onto the Tailwind utility for a *bar fill*.
// We can't use Badge for the bar itself (it's a row, not a chip) but we
// want the same colour vocabulary, so this small lookup keeps the two in
// sync without importing the Badge variants directly. All entries use the
// design-system semantic tokens (no raw palette / hex).
const VARIANT_BAR_CLASS: Record<BadgeVariant, string> = {
  default:     "bg-foreground/60",
  secondary:   "bg-secondary-foreground/60",
  destructive: "bg-destructive",
  outline:     "bg-muted-foreground/60",
  success:     "bg-oati-success",
  warning:     "bg-oati-warning",
  accent:      "bg-accent",
};

// Map digest signal-key → human label + the field on each row that carries
// the count. The shape is dictated by ueba_service.digest_since.
const DIGEST_META: Record<string, { label: string; countKey: string; countLabel: string }> = {
  tokens:       { label: "Top token spenders",      countKey: "tokens",   countLabel: "tokens" },
  refusals:     { label: "Refusal velocity",        countKey: "refusals", countLabel: "refusals" },
  jailbreak:    { label: "Jailbreak attempts",      countKey: "hits",     countLabel: "hits" },
  dlp_hits:     { label: "DLP / PII input hits",    countKey: "hits",     countLabel: "hits" },
  output_leaks: { label: "Output secret leaks",     countKey: "hits",     countLabel: "leaks" },
};

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function MonitoringPage() {
  const [statusFilter, setStatusFilter] =
    useState<"open" | "acknowledged" | "resolved" | "all">("open");
  const [alerts, setAlerts]   = useState<UebaAlert[] | null>(null);
  const [digest, setDigest]   = useState<DigestResponse | null>(null);
  // 24h *all-severity* alert list for the stat cards. Independent fetch
  // because the user's selected status-filter shouldn't affect the counts.
  const [last24, setLast24]   = useState<UebaAlert[] | null>(null);

  const [error, setError]     = useState<string | null>(null);
  const [refreshedAt, setRefreshedAt] = useState<Date | null>(null);
  const [busyId, setBusyId]   = useState<number | null>(null);

  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  // Per-expanded-row user state cache: keyed by alert.id (not user_id, since
  // the same user can appear on multiple alerts).
  const [userStates, setUserStates] = useState<Record<number, UserState | { error: string } | null>>({});
  // 7-day baseline cache. Keyed by *user_id* (not alert.id) so collapsing
  // and re-expanding — or expanding a *different* alert from the same user
  // — reuses the in-page snapshot without a round-trip.
  const [baselines, setBaselines] = useState<Record<string, UserBaseline | { error: string } | null>>({});
  // Behaviour-radar cache. Same per-user_id keying as the baseline so two
  // alerts on the same user share the snapshot.
  const [radars, setRadars]       = useState<Record<string, UserRadar | { error: string } | null>>({});

  // Refresh the live alerts list + digest. Stat-cards always re-pull the
  // last-24h "all" list so counts stay accurate independent of the chip
  // filter the operator picked.
  const refresh = useCallback(async (status: typeof statusFilter) => {
    // "all" => fan out to every status bucket and merge, since the backend
    // requires an explicit status filter.
    const alertsP: Promise<AlertsResponse> =
      status === "all"
        ? Promise.all(
            (["open", "acknowledged", "resolved", "false_positive"] as const).map((s) =>
              fetch(`${GW}/admin/ueba/alerts?status=${s}&limit=200`, {
                cache: "no-store", credentials: "same-origin",
              }).then(async (r) => {
                if (!r.ok) throw new Error(`alerts(${s}): ${r.status} ${r.statusText}`);
                return (await r.json()) as AlertsResponse;
              }),
            ),
          ).then((bodies) => {
            const merged = bodies.flatMap((b) => b.alerts);
            // Newest first — the per-status endpoint already does this, but
            // the merge across statuses doesn't.
            merged.sort((a, b) => Date.parse(b.raised_at) - Date.parse(a.raised_at));
            return { status_filter: "all", count: merged.length, alerts: merged };
          })
        : fetch(`${GW}/admin/ueba/alerts?status=${status}&limit=200`, {
            cache: "no-store", credentials: "same-origin",
          }).then(async (r) => {
            if (!r.ok) throw new Error(`alerts: ${r.status} ${r.statusText}`);
            return (await r.json()) as AlertsResponse;
          });

    // Stat cards need *all* statuses regardless of the operator's filter,
    // so we always fan out across the four buckets in parallel. A 404 on a
    // single bucket would be silly but Promise.allSettled keeps the rest
    // working even if one shard is broken.
    const last24P: Promise<UebaAlert[]> = Promise.all(
      (["open", "acknowledged", "resolved", "false_positive"] as const).map((s) =>
        fetch(`${GW}/admin/ueba/alerts?status=${s}&limit=1000`, {
          cache: "no-store", credentials: "same-origin",
        }).then(async (r) => {
          if (!r.ok) throw new Error(`alerts(${s}): ${r.status} ${r.statusText}`);
          return ((await r.json()) as AlertsResponse).alerts;
        }),
      ),
    ).then((batches) => batches.flat());

    const digestP = fetch(`${GW}/admin/ueba/digest?hours=24`, {
      cache: "no-store", credentials: "same-origin",
    }).then(async (r) => {
      if (!r.ok) throw new Error(`digest: ${r.status} ${r.statusText}`);
      return (await r.json()) as DigestResponse;
    });

    const [aRes, lRes, dRes] = await Promise.allSettled([alertsP, last24P, digestP]);
    const errs: string[] = [];
    if (aRes.status === "fulfilled") setAlerts(aRes.value.alerts); else errs.push(String(aRes.reason));
    if (lRes.status === "fulfilled") setLast24(lRes.value);        else errs.push(String(lRes.reason));
    if (dRes.status === "fulfilled") setDigest(dRes.value);        else errs.push(String(dRes.reason));

    setRefreshedAt(new Date());
    setError(errs.length ? errs.join(" · ") : null);
  }, []);

  useEffect(() => {
    void refresh(statusFilter);
    const id = window.setInterval(() => { void refresh(statusFilter); }, REFRESH_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, [refresh, statusFilter]);

  // 24h severity counts from the combined list. We treat the alert's
  // raised_at as the anchor so we don't double-count older alerts that just
  // happen to be in the "open" bucket.
  const counts24h = useMemo(() => {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    const c = { critical: 0, high: 0, warn: 0 };
    if (!last24) return c;
    for (const a of last24) {
      const t = Date.parse(a.raised_at);
      if (Number.isNaN(t) || t < cutoff) continue;
      if (a.severity === "critical") c.critical++;
      else if (a.severity === "high") c.high++;
      else if (a.severity === "warn") c.warn++;
    }
    return c;
  }, [last24]);

  const openCount = useMemo(() => {
    if (!last24) return 0;
    return last24.filter((a) => a.status === "open").length;
  }, [last24]);

  // Inline action: acknowledge / resolve / false-positive / reopen.
  const act = async (a: UebaAlert, action: "acknowledge" | "resolve" | "false-positive" | "reopen") => {
    setBusyId(a.id);
    try {
      const r = await fetch(`${GW}/admin/ueba/alerts/${a.id}/${action}`, {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (!r.ok) throw new Error(`${action}: ${r.status} ${r.statusText}`);
      await refresh(statusFilter);
    } catch (e) {
      setError(String(e));
    } finally {
      setBusyId(null);
    }
  };

  // Toggle a row's details panel and lazy-load the user's current state +
  // 7-day baseline + 10-signal radar on first expand. All three calls fan
  // out in parallel so the panel only ever costs one round-trip-worth of
  // latency, and Promise.allSettled means a 5xx on one endpoint doesn't
  // blank the others. Subsequent expands reuse the cached snapshot —
  // counters tick slowly enough that a stale read is fine until manual
  // refresh, and the baseline + radar are rolling aggregates so they
  // barely move between expands.
  //
  // user-state is keyed per-alert (cheap, distinct request log per row),
  // baseline + radar are keyed per-user_id so two alerts on the same user
  // share the already-fetched snapshot.
  const toggleRow = async (a: UebaAlert) => {
    const willOpen = !expanded[a.id];
    setExpanded((e) => ({ ...e, [a.id]: willOpen }));
    if (!willOpen || !a.user_id) return;

    const uid = a.user_id;
    const needState    = userStates[a.id]   === undefined;
    const needBaseline = baselines[uid]     === undefined;
    const needRadar    = radars[uid]        === undefined;
    if (!needState && !needBaseline && !needRadar) return;

    if (needState)    setUserStates((s) => ({ ...s, [a.id]: null }));
    if (needBaseline) setBaselines((b) => ({ ...b, [uid]:  null }));
    if (needRadar)    setRadars((r)    => ({ ...r, [uid]:  null }));

    const stateP = needState
      ? fetch(`${GW}/admin/ueba/user/${encodeURIComponent(uid)}`, {
          cache: "no-store", credentials: "same-origin",
        }).then(async (r) => {
          if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
          return (await r.json()) as UserState;
        })
      : null;

    const baselineP = needBaseline
      ? fetch(`${GW}/admin/ueba/user/${encodeURIComponent(uid)}/baseline`, {
          cache: "no-store", credentials: "same-origin",
        }).then(async (r) => {
          if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
          return (await r.json()) as UserBaseline;
        })
      : null;

    const radarP = needRadar
      ? fetch(`${GW}/admin/ueba/user/${encodeURIComponent(uid)}/radar`, {
          cache: "no-store", credentials: "same-origin",
        }).then(async (r) => {
          if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
          return (await r.json()) as UserRadar;
        })
      : null;

    const [sRes, bRes, rRes] = await Promise.allSettled([
      stateP    ?? Promise.resolve(null),
      baselineP ?? Promise.resolve(null),
      radarP    ?? Promise.resolve(null),
    ]);

    if (needState) {
      if (sRes.status === "fulfilled") {
        setUserStates((s) => ({ ...s, [a.id]: sRes.value as UserState }));
      } else {
        setUserStates((s) => ({ ...s, [a.id]: { error: String(sRes.reason) } }));
      }
    }
    if (needBaseline) {
      if (bRes.status === "fulfilled") {
        setBaselines((b) => ({ ...b, [uid]: bRes.value as UserBaseline }));
      } else {
        setBaselines((b) => ({ ...b, [uid]: { error: String(bRes.reason) } }));
      }
    }
    if (needRadar) {
      if (rRes.status === "fulfilled") {
        setRadars((r) => ({ ...r, [uid]: rRes.value as UserRadar }));
      } else {
        setRadars((r) => ({ ...r, [uid]: { error: String(rRes.reason) } }));
      }
    }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-8">
      {/* Header */}
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-2">
          <h1 className="page-title">Monitoring</h1>
          <p className="max-w-3xl text-sm text-muted-foreground">
            User-Entity Behaviour Analytics — real-time anomaly signals plus a 24-hour SOC digest.
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            {STATUS_FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setStatusFilter(f.key)}
                className={
                  "inline-flex h-7 items-center rounded-full border px-3 text-[11px] font-medium tracking-wide transition-colors " +
                  (statusFilter === f.key
                    ? "border-accent/60 bg-accent/15 text-accent-foreground"
                    : "border-border/60 bg-secondary/40 text-muted-foreground hover:bg-secondary/70")
                }
              >
                {f.label}
              </button>
            ))}
          </div>
          {refreshedAt && (
            <span className="text-[11px] text-muted-foreground">
              updated {refreshedAt.toLocaleTimeString()}
              <button
                onClick={() => { void refresh(statusFilter); }}
                className="ml-2 inline-flex h-5 w-5 items-center justify-center rounded-md hover:bg-secondary"
                aria-label="Refresh"
                title="Refresh"
              >
                <RefreshCw className="h-3 w-3" />
              </button>
            </span>
          )}
        </div>
      </header>

      {/* Stat cards — UEBA severity rollup */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <InfoBox
          tone={openCount > 0 ? "warning" : "info"}
          icon={<ShieldAlert className="h-16 w-16" />}
          label="Open alerts"
          value={last24 ? String(openCount) : "—"}
          footer={last24 ? "awaiting acknowledgement" : "loading…"}
        />
        <InfoBox
          tone={counts24h.critical > 0 ? "danger" : "info"}
          icon={<ShieldAlert className="h-16 w-16" />}
          label="Critical · 24h"
          value={last24 ? String(counts24h.critical) : "—"}
          footer="severity=critical"
        />
        <InfoBox
          tone="warning"
          icon={<ShieldQuestion className="h-16 w-16" />}
          label="High · 24h"
          value={last24 ? String(counts24h.high) : "—"}
          footer="severity=high"
        />
        <InfoBox
          tone="success"
          icon={<ShieldCheck className="h-16 w-16" />}
          label="Warn · 24h"
          value={last24 ? String(counts24h.warn) : "—"}
          footer="severity=warn"
        />
      </section>

      {error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="flex items-center gap-2 p-4 text-sm text-destructive">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span className="break-all">{error}</span>
          </CardContent>
        </Card>
      )}

      {/* Alerts table */}
      <section className="space-y-3">
        <div>
          <h2 className="section-title">UEBA alerts</h2>
          <p className="text-sm text-muted-foreground">
            Live anomaly signals. Click a row to expand the details payload and the
            user&apos;s current counter snapshot.
          </p>
        </div>

        <Card>
          <CardContent className="p-0">
            {!alerts ? (
              <div className="p-6 text-sm text-muted-foreground">Loading…</div>
            ) : alerts.length === 0 ? (
              <div className="p-6 text-sm text-muted-foreground">
                No alerts in the <span className="font-mono">{statusFilter}</span> bucket. Nice and quiet.
              </div>
            ) : (
              <Table>
                <THead>
                  <TR>
                    <TH className="w-6" />
                    <TH>Raised</TH>
                    <TH>User</TH>
                    <TH>Team</TH>
                    <TH>Tier</TH>
                    <TH>Signal</TH>
                    <TH>Severity</TH>
                    <TH>Summary</TH>
                    <TH>Status</TH>
                    <TH className="w-72 text-right">Actions</TH>
                  </TR>
                </THead>
                <TBody>
                  {alerts.map((a) => {
                    const isOpen = !!expanded[a.id];
                    const busy = busyId === a.id;
                    const sev = String(a.severity);
                    const status = String(a.status);
                    return (
                      <Fragment key={a.id}>
                        <TR
                          className="cursor-pointer"
                          onClick={() => { void toggleRow(a); }}
                        >
                          <TD className="text-muted-foreground">
                            {isOpen
                              ? <ChevronDown className="h-3.5 w-3.5" />
                              : <ChevronRight className="h-3.5 w-3.5" />}
                          </TD>
                          <TD className="whitespace-nowrap text-xs" title={new Date(a.raised_at).toLocaleString()}>
                            <span className="text-muted-foreground">{relTime(a.raised_at)}</span>
                          </TD>
                          <TD className="font-mono text-xs">{a.user_id ?? "—"}</TD>
                          <TD className="font-mono text-xs">{a.team_id ?? "—"}</TD>
                          <TD className="font-mono text-xs">{a.tier ?? "—"}</TD>
                          <TD className="font-mono text-xs">{a.signal}</TD>
                          <TD>
                            <Badge variant={SEVERITY_VARIANT[sev] ?? "secondary"} className="uppercase">
                              {sev}
                            </Badge>
                          </TD>
                          <TD className="max-w-md">
                            <div className="line-clamp-1 text-sm" title={a.summary}>{a.summary}</div>
                          </TD>
                          <TD>
                            <Badge variant={STATUS_VARIANT[status] ?? "secondary"}>
                              {status.replace("_", " ")}
                            </Badge>
                          </TD>
                          <TD className="text-right" onClick={(e) => e.stopPropagation()}>
                            <AlertActions
                              status={status}
                              busy={busy}
                              onAcknowledge={() => act(a, "acknowledge")}
                              onResolve={() => act(a, "resolve")}
                              onFalsePositive={() => act(a, "false-positive")}
                              onReopen={() => act(a, "reopen")}
                            />
                          </TD>
                        </TR>
                        {isOpen && (
                          <TR className="bg-secondary/20 hover:bg-secondary/20">
                            <TD />
                            <TD colSpan={9} className="py-3">
                              <DetailsPanel
                                alert={a}
                                userState={userStates[a.id] ?? undefined}
                                baseline={a.user_id ? (baselines[a.user_id] ?? undefined) : undefined}
                                radar={a.user_id ? (radars[a.user_id] ?? undefined) : undefined}
                              />
                            </TD>
                          </TR>
                        )}
                      </Fragment>
                    );
                  })}
                </TBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </section>

      {/* 24h digest */}
      <section className="space-y-3">
        <Card>
          <CardHeader>
            <CardTitle>24-hour digest</CardTitle>
            <CardDescription>
              Top outliers across all signals over the last 24 hours.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DigestBody digest={digest} />
          </CardContent>
        </Card>
      </section>

    </div>
  );
}

// ---------------------------------------------------------------------------
// Subcomponents
// ---------------------------------------------------------------------------

function AlertActions({
  status, busy,
  onAcknowledge, onResolve, onFalsePositive, onReopen,
}: {
  status: string;
  busy: boolean;
  onAcknowledge: () => void;
  onResolve: () => void;
  onFalsePositive: () => void;
  onReopen: () => void;
}) {
  // Drive button layout off the *server-side* canonical status so an
  // operator who rapid-clicks the wrong action gets the right buttons after
  // the refresh, not stale ones.
  if (status === "open") {
    return (
      <div className="flex items-center justify-end gap-1.5">
        <Button size="sm" variant="accent" onClick={onAcknowledge} disabled={busy}>
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
          Acknowledge
        </Button>
        <Button size="sm" variant="ghost" onClick={onFalsePositive} disabled={busy}>
          <XCircle className="h-3.5 w-3.5" /> False positive
        </Button>
        <Button size="sm" variant="outline" onClick={onResolve} disabled={busy}>
          Resolve
        </Button>
      </div>
    );
  }
  if (status === "acknowledged") {
    return (
      <div className="flex items-center justify-end gap-1.5">
        <Button size="sm" variant="accent" onClick={onResolve} disabled={busy}>
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
          Resolve
        </Button>
        <Button size="sm" variant="ghost" onClick={onReopen} disabled={busy}>
          <RotateCcw className="h-3.5 w-3.5" /> Reopen
        </Button>
      </div>
    );
  }
  // resolved | false_positive
  return (
    <div className="flex items-center justify-end gap-1.5">
      <Button size="sm" variant="ghost" onClick={onReopen} disabled={busy}>
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
        Reopen
      </Button>
    </div>
  );
}

function isErrState(s: UserState | { error: string } | null | undefined): s is { error: string } {
  return !!s && typeof (s as { error?: unknown }).error === "string";
}

function isErrBaseline(b: UserBaseline | { error: string } | null | undefined): b is { error: string } {
  return !!b && typeof (b as { error?: unknown }).error === "string";
}

function isErrRadar(r: UserRadar | { error: string } | null | undefined): r is { error: string } {
  return !!r && typeof (r as { error?: unknown }).error === "string";
}

function DetailsPanel({
  alert, userState, baseline, radar,
}: {
  alert: UebaAlert;
  userState: UserState | { error: string } | null | undefined;
  baseline: UserBaseline | { error: string } | null | undefined;
  radar:    UserRadar    | { error: string } | null | undefined;
}) {
  const detailsText = useMemo(() => {
    if (!alert.details) return "(no details)";
    try { return JSON.stringify(alert.details, null, 2); }
    catch { return String(alert.details); }
  }, [alert.details]);

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-1.5">
          <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            Alert details
          </div>
          <pre className="max-h-64 overflow-auto rounded-md border border-border/60 bg-background/60 p-3 font-mono text-[11px] leading-relaxed">
{detailsText}
          </pre>
        </div>
        <div className="space-y-1.5">
          <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            User state · {alert.user_id ?? "—"}
          </div>
          {!alert.user_id ? (
            <div className="text-xs text-muted-foreground">No user attached to this alert.</div>
          ) : userState === undefined || userState === null ? (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Loader2 className="h-3 w-3 animate-spin" /> Loading…
            </div>
          ) : isErrState(userState) ? (
            <div className="text-xs text-destructive">Failed: {userState.error}</div>
          ) : userState.enabled === false ? (
            <div className="text-xs text-muted-foreground">
              UEBA observer plugin is not loaded — counters unavailable.
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <Counter label="Jailbreak · today"    value={num(userState.jailbreak_attempts_today)} />
              <Counter label="Refusals · 5min"      value={num(userState.refusal_velocity_5min)} />
              <Counter label="DLP hits · 7d"        value={num(userState.dlp_hits_week)} />
              <Counter label="Output leaks · today" value={num(userState.output_secret_leaks_today)} />
            </div>
          )}
        </div>
      </div>

      {alert.user_id && <BaselineCard baseline={baseline} />}
      {alert.user_id && <RadarCard    radar={radar} />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 7-day baseline card — hour-of-day token chart + model mix.
// ---------------------------------------------------------------------------
function BaselineCard({
  baseline,
}: {
  baseline: UserBaseline | { error: string } | null | undefined;
}) {
  return (
    <div className="space-y-2">
      <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        7-day baseline
      </div>

      {baseline === undefined || baseline === null ? (
        <div className="flex items-center gap-2 rounded-md border border-border/60 bg-background/60 p-3 text-xs text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" /> Loading baseline…
        </div>
      ) : isErrBaseline(baseline) ? (
        <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-xs text-destructive">
          Failed: {baseline.error}
        </div>
      ) : baseline.enabled === false ? (
        <div className="rounded-md border border-border/60 bg-background/60 p-3 text-xs text-muted-foreground">
          UEBA plugin not loaded — baseline unavailable.
        </div>
      ) : (
        <>
          <div className="grid gap-3 md:grid-cols-2">
            <HourOfDayChart hourTokens={baseline.hour_of_day_tokens} />
            <ModelMixList   modelMix={baseline.model_mix} />
          </div>
          <div className="pt-1 text-[11px] text-muted-foreground">
            Total requests · 7d:{" "}
            <span className="font-mono tabular-nums text-foreground">
              {baseline.total_requests.toLocaleString()}
            </span>
          </div>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Behaviour radar — 10-axis SVG polygon. Sibling to BaselineCard. Renders
// the per-user risk profile shipped by /admin/ueba/user/{id}/radar so a
// SOC operator can eyeball "is this user lit up across many signals or
// just one" without crunching numbers. Pure inline SVG — no charting dep.
// ---------------------------------------------------------------------------
function RadarCard({
  radar,
}: {
  radar: UserRadar | { error: string } | null | undefined;
}) {
  return (
    <div className="space-y-2">
      <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        Behaviour radar
      </div>

      {radar === undefined || radar === null ? (
        <div className="flex items-center gap-2 rounded-md border border-border/60 bg-background/60 p-3 text-xs text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" /> Loading radar…
        </div>
      ) : isErrRadar(radar) ? (
        <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-xs text-destructive">
          Failed: {radar.error}
        </div>
      ) : radar.enabled === false ? (
        <div className="rounded-md border border-border/60 bg-background/60 p-3 text-xs text-muted-foreground">
          UEBA plugin not loaded.
        </div>
      ) : (
        <RadarChart radar={radar} />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Pure-SVG radar chart. 10 axes spaced 36° apart, four concentric grid
// rings at 25/50/75/100%, and a polygon coloured by max-axis severity so
// a single glance tells the operator "RED — investigate" vs "noise".
// ---------------------------------------------------------------------------
function RadarChart({ radar }: { radar: UserRadar }) {
  const VB = 320, CX = 160, CY = 160, R = 120, LABEL_R = 135;

  // Trust the server's `axes` order so the renderer stays stable even if
  // we add an axis later. Fall back to scores keys if axes is somehow
  // missing — defensive against schema drift.
  const axes = useMemo(() => {
    if (radar.axes && radar.axes.length > 0) return radar.axes;
    return (Object.keys(radar.scores) as RadarAxisKey[]).map((k) => ({
      key: k,
      label: k.replace(/_/g, " "),
    }));
  }, [radar.axes, radar.scores]);

  // Cap to the first 10 — the SVG geometry assumes a 10-gon. If the API
  // ever returns fewer axes the polygon just collapses on the missing
  // sides, which is acceptable; if it returns more we drop the tail
  // rather than lying about angle spacing.
  const items = useMemo(() => {
    return axes.slice(0, 10).map((a, i) => {
      const score = clamp01(num(radar.scores?.[a.key]));
      // Start at the top (-90°) and walk clockwise so axis[0] is "12 o'clock".
      const angleDeg = -90 + i * 36;
      const angle = (angleDeg * Math.PI) / 180;
      const cos = Math.cos(angle), sin = Math.sin(angle);
      return {
        key:   a.key,
        label: a.label,
        score,
        cos, sin, angleDeg,
        ax:  CX + cos * R,                    // axis tip (100% ring)
        ay:  CY + sin * R,
        lx:  CX + cos * LABEL_R,              // label position
        ly:  CY + sin * LABEL_R,
        px:  CX + cos * R * (score / 100),    // polygon vertex
        py:  CY + sin * R * (score / 100),
      };
    });
  }, [axes, radar.scores]);

  const maxScore = items.reduce((m, it) => Math.max(m, it.score), 0);
  const allZero  = items.length > 0 && items.every((it) => it.score === 0);

  // Color-by-max — gives the operator at-a-glance triage. Tailwind text-*
  // utility drives currentColor on both stroke and fill (with opacity).
  const toneClass =
    maxScore >= 75 ? "text-destructive"
    : maxScore >= 50 ? "text-oati-warning"
    : maxScore >= 25 ? "text-warning"
    : "text-accent";

  const polyPoints = items.map((it) => `${it.px.toFixed(2)},${it.py.toFixed(2)}`).join(" ");

  return (
    <div className="rounded-md border border-border/60 bg-background/60 p-3">
      <div className="flex items-baseline justify-between gap-3">
        <div>
          <div className="text-xs font-medium">10-signal risk profile</div>
          <div className="text-[10px] text-muted-foreground">Per-axis score · 0–100</div>
        </div>
        <div className={"font-mono text-[10px] tabular-nums " + toneClass}>
          max {maxScore.toFixed(0)}
        </div>
      </div>

      <div className={"mt-2 flex justify-center " + toneClass}>
        <svg
          viewBox={`0 0 ${VB} ${VB}`}
          className="h-64 w-full max-w-[320px]"
          role="img"
          aria-label="Behaviour radar chart"
        >
          {/* Concentric grid rings — 25 / 50 / 75 / 100 % */}
          {[0.25, 0.5, 0.75, 1].map((f) => (
            <circle
              key={f}
              cx={CX}
              cy={CY}
              r={R * f}
              fill="none"
              stroke="hsl(var(--border) / 0.5)"
              strokeWidth={1}
            />
          ))}

          {/* Axis spokes */}
          {items.map((it) => (
            <line
              key={`axis-${it.key}`}
              x1={CX}
              y1={CY}
              x2={it.ax}
              y2={it.ay}
              stroke="hsl(var(--border) / 0.4)"
              strokeWidth={1}
            />
          ))}

          {/* Filled polygon — currentColor inherited from toneClass */}
          <polygon
            points={polyPoints}
            fill="currentColor"
            fillOpacity={0.2}
            stroke="currentColor"
            strokeWidth={1.5}
            strokeLinejoin="round"
          />

          {/* Vertex dots */}
          {items.map((it) => (
            <circle
              key={`dot-${it.key}`}
              cx={it.px}
              cy={it.py}
              r={2.5}
              fill="currentColor"
            >
              <title>{`${it.label}: ${it.score.toFixed(0)}`}</title>
            </circle>
          ))}

          {/* Axis labels — anchor by horizontal position so right-side
              labels read left-aligned, left-side right-aligned, and the
              top/bottom 12 / 6 o'clock labels centre under their tip. */}
          {items.map((it) => {
            const anchor =
              it.cos > 0.2 ? "start" :
              it.cos < -0.2 ? "end" :
              "middle";
            // Nudge baseline so top labels sit above the tip, bottom below.
            const dy =
              it.sin < -0.5 ? -2 :
              it.sin > 0.5  ? 8 :
              3;
            return (
              <text
                key={`lab-${it.key}`}
                x={it.lx}
                y={it.ly + dy}
                textAnchor={anchor}
                className="text-[10px]"
                fill="hsl(var(--muted-foreground))"
              >
                {it.label}
              </text>
            );
          })}
        </svg>
      </div>

      <div className="mt-2 flex items-baseline justify-between gap-3">
        <div className="text-[11px] text-muted-foreground">
          Total score:{" "}
          <span className={"font-mono tabular-nums " + toneClass}>
            {Math.round(radar.total_score)}/100
          </span>
        </div>
      </div>
      {allZero && (
        <div className="mt-1 text-[10px] italic text-muted-foreground">
          User has no recent activity — radar will populate as signals fire.
        </div>
      )}
    </div>
  );
}

// Clamp an arbitrary "score-like" value into [0,100]. The API guarantees
// the range but defensive parsing keeps the geometry sane if a stray null
// or out-of-band value sneaks through.
function clamp01(v: number | string): number {
  const n = typeof v === "number" ? v : Number(v);
  if (!Number.isFinite(n)) return 0;
  if (n < 0)   return 0;
  if (n > 100) return 100;
  return n;
}

// ---------------------------------------------------------------------------
// Hour-of-day vertical-bar chart. Inline SVG, same approach as the Overview
// activity sparkline. We render 24 bars regardless of which keys the API
// returns so the X-axis layout stays stable across users.
// ---------------------------------------------------------------------------
function HourOfDayChart({ hourTokens }: { hourTokens: Record<string, number> }) {
  const W = 240, H = 80, PAD_X = 4, PAD_Y = 6;
  const buckets: number[] = [];
  for (let h = 0; h < 24; h++) {
    const v = hourTokens[String(h)];
    buckets.push(typeof v === "number" && Number.isFinite(v) && v > 0 ? v : 0);
  }
  const max = Math.max(0, ...buckets);
  const total = buckets.reduce((s, v) => s + v, 0);
  const slot = (W - PAD_X * 2) / 24;
  // Leave a 1px gap between bars regardless of slot width so bars stay
  // visually distinct at narrow breakpoints.
  const barW = Math.max(1, slot - 1);

  return (
    <div className="rounded-md border border-border/60 bg-background/60 p-3">
      <div className="flex items-baseline justify-between gap-3">
        <div>
          <div className="text-xs font-medium">Tokens by hour-of-day</div>
          <div className="text-[10px] text-muted-foreground">Last 7 days · UTC</div>
        </div>
        <div className="font-mono text-[10px] tabular-nums text-muted-foreground">
          {max > 0 ? `max ${max.toLocaleString()}` : ""}
        </div>
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} className="mt-2 h-20 w-full" preserveAspectRatio="none">
        {buckets.map((v, h) => {
          // Empty buckets get a 1px stub so the operator can see the
          // hour-slot grid even on a quiet day.
          const barH = max > 0 && v > 0
            ? Math.max(1, (v / max) * (H - PAD_Y * 2))
            : 1;
          const x = PAD_X + h * slot;
          const y = H - PAD_Y - barH;
          const fill = total === 0 || v === 0
            ? "hsl(var(--muted-foreground))"
            : "hsl(var(--accent))";
          const opacity = total === 0 ? 0.25 : v === 0 ? 0.2 : 0.85;
          return (
            <rect
              key={h}
              x={x}
              y={y}
              width={barW}
              height={barH}
              fill={fill}
              opacity={opacity}
              rx={0.5}
            >
              <title>{`${h}:00 — ${v.toLocaleString()} tokens`}</title>
            </rect>
          );
        })}
      </svg>

      <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
        <span>0</span>
        <span>6</span>
        <span>12</span>
        <span>18</span>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Model mix — horizontal bar list. Sorted by request count descending; bar
// fill follows the provider→variant map so the colour language matches the
// Models / Tiers / Router pages.
// ---------------------------------------------------------------------------
function ModelMixList({ modelMix }: { modelMix: Record<string, number> }) {
  const entries = useMemo(() => {
    return Object.entries(modelMix ?? {})
      .map(([model, count]) => ({
        model,
        count: typeof count === "number" && Number.isFinite(count) ? count : 0,
      }))
      .filter((e) => e.count > 0)
      .sort((a, b) => b.count - a.count);
  }, [modelMix]);

  const max = Math.max(1, ...entries.map((e) => e.count));

  return (
    <div className="rounded-md border border-border/60 bg-background/60 p-3">
      <div className="text-xs font-medium">Model mix</div>
      <div className="text-[10px] text-muted-foreground">Last 7 days</div>

      {entries.length === 0 ? (
        <div className="mt-3 text-xs text-muted-foreground">No model usage in window.</div>
      ) : (
        <ul className="mt-2.5 space-y-2">
          {entries.map((e) => {
            const provider = providerFromModel(e.model);
            const variant: BadgeVariant =
              provider ? (PROVIDER_VARIANT[provider] ?? "accent") : "accent";
            const barClass = VARIANT_BAR_CLASS[variant];
            const pct = (e.count / max) * 100;
            return (
              <li key={e.model} className="space-y-1">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="truncate font-mono" title={e.model}>{e.model}</span>
                  <span className="font-mono tabular-nums text-muted-foreground">
                    {e.count.toLocaleString()}
                  </span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className={"h-full rounded-full " + barClass}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function Counter({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-md border border-border/60 bg-background/60 p-2.5">
      <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div className="mt-1 font-mono text-lg tabular-nums">{value}</div>
    </div>
  );
}

function DigestBody({ digest }: { digest: DigestResponse | null }) {
  if (!digest) {
    return <div className="text-sm text-muted-foreground">Loading…</div>;
  }
  const sections = Object.entries(digest.outliers ?? {});
  const totalRows = sections.reduce((s, [, rows]) => s + (rows?.length ?? 0), 0);
  if (totalRows === 0) {
    return (
      <div className="text-sm text-muted-foreground">
        Nothing to report — no users tripped a signal threshold in the last 24h.
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {sections.map(([sig, rows]) => {
        if (!rows || rows.length === 0) return null;
        const meta = DIGEST_META[sig] ?? { label: sig, countKey: "count", countLabel: "count" };
        // Defensive: if the schema-known key isn't present, fall back to the
        // first numeric field on the row so we always render *something*.
        return (
          <div key={sig} className="rounded-md border border-border/60 bg-background/40">
            <div className="flex items-center justify-between border-b border-border/60 px-3 py-2">
              <span className="text-sm font-medium">{meta.label}</span>
              <span className="font-mono text-[10px] uppercase tracking-wide text-muted-foreground">
                {sig}
              </span>
            </div>
            <Table>
              <THead>
                <TR>
                  <TH>User</TH>
                  <TH>Team</TH>
                  <TH className="text-right">{meta.countLabel}</TH>
                </TR>
              </THead>
              <TBody>
                {rows.map((r, i) => {
                  const count = numFromRow(r, meta.countKey);
                  return (
                    <TR key={`${sig}-${i}`}>
                      <TD className="font-mono text-xs">{r.user_id ?? "—"}</TD>
                      <TD className="font-mono text-xs">{r.team_id ?? "—"}</TD>
                      <TD className="text-right font-mono tabular-nums">{count.toLocaleString()}</TD>
                    </TR>
                  );
                })}
              </TBody>
            </Table>
          </div>
        );
      })}
    </div>
  );
}

// ---------------------------------------------------------------------------
// StatCard — same shape as Overview / Router for visual consistency.
// ---------------------------------------------------------------------------
function StatCard({
  icon, label, value, hint, pulse, tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  hint: string;
  pulse?: boolean;
  tone?: "destructive";
}) {
  const toneClass = tone === "destructive" ? "text-destructive" : "text-foreground";
  return (
    <Card className="group relative overflow-hidden shadow-soft transition-shadow hover:shadow-ring">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-px -top-px h-24 w-24 bg-gradient-to-br from-accent/40 via-accent/10 to-transparent opacity-70"
      />
      <CardContent className="relative p-5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {label}
          </span>
          <span className="flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground">
            {icon}
          </span>
        </div>
        <div className="mt-4 flex items-center gap-2">
          <div className={"stat-number " + toneClass}>
            {value}
          </div>
          {pulse && (
            <span className="relative inline-flex h-2.5 w-2.5" aria-label="open alerts">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-destructive" />
            </span>
          )}
        </div>
        <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// Compact relative-time label. We deliberately keep this inline-trivial
// rather than importing date-fns — the rest of the dashboard already does
// the same and the constraint is "no new npm deps".
function relTime(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  const sec = Math.max(0, Math.round((Date.now() - t) / 1000));
  if (sec < 60)    return `${sec}s ago`;
  const min = Math.round(sec / 60);
  if (min < 60)    return `${min}m ago`;
  const hr  = Math.round(min / 60);
  if (hr  < 24)    return `${hr}h ago`;
  const d   = Math.round(hr / 24);
  return `${d}d ago`;
}

function num(v: unknown): number | string {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.trim() !== "" && !Number.isNaN(Number(v))) return Number(v);
  return "—";
}

// Pull a count off a digest row. If the canonical countKey isn't present
// (older gateway version, schema drift), fall back to the first numeric
// field. Keeps the UI from rendering "NaN" if the API shape shifts.
function numFromRow(r: DigestRow, key: string): number {
  const v = r[key];
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && !Number.isNaN(Number(v))) return Number(v);
  for (const k of Object.keys(r)) {
    if (k === "user_id" || k === "team_id") continue;
    const vv = r[k];
    if (typeof vv === "number" && Number.isFinite(vv)) return vv;
    if (typeof vv === "string" && !Number.isNaN(Number(vv)) && vv.trim() !== "") return Number(vv);
  }
  return 0;
}
