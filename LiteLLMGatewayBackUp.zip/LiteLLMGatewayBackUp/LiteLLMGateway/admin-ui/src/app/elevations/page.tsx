"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowRight, ArrowUpCircle, CheckCircle2, X, XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

type ElevationStatus = "pending" | "approved" | "denied" | "cancelled";

type ElevationItem = {
  id: number | string;
  user_id: string;
  user_email: string | null;
  team_id: string | null;
  base_tier: string;
  requested_tier: string;
  duration_minutes: number;
  reason: string;
  status: ElevationStatus;
  requested_at: string;
  decided_at: string | null;
  expires_at: string | null;
  approver_user_id: string | null;
  decision_note: string | null;
};

const TIERS = ["L1_standard", "L2_senior", "L3_privileged"] as const;

const STATUS_VARIANT: Record<ElevationStatus, "default" | "destructive" | "warning" | "success" | "accent" | "secondary"> = {
  pending:   "warning",
  approved:  "success",
  denied:    "destructive",
  cancelled: "secondary",
};

const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };
// All gateway calls go through the BFF (/api/gateway/*) which authenticates
// the operator via cookie and injects the master key server-side.
const GW = "/api/gateway";

export default function ElevationsPage() {
  const [pending, setPending] = useState<ElevationItem[] | null>(null);
  const [mine, setMine]       = useState<ElevationItem[] | null>(null);
  const [me, setMe]           = useState<string | null>(null);
  const [err, setErr]         = useState<string | null>(null);

  // Request-elevation form state
  const [reqTier, setReqTier]         = useState<string>(TIERS[0]);
  const [duration, setDuration]       = useState<number>(240);
  const [reason, setReason]           = useState<string>("");
  const [submitting, setSubmitting]   = useState(false);

  // Per-row inline decision-note state (key = elevation id)
  const [noteOpenFor, setNoteOpenFor] = useState<Record<string, "approve" | "deny" | null>>({});
  const [notes, setNotes]             = useState<Record<string, string>>({});
  const [busyId, setBusyId]           = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      const [pr, mr] = await Promise.all([
        fetch(`${GW}/admin/elevation/pending`, { headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store" }),
        fetch(`${GW}/admin/elevation/mine`,    { headers: JSON_HEADERS, credentials: "same-origin", cache: "no-store" }),
      ]);
      if (!pr.ok) throw new Error(`pending: ${pr.status} ${pr.statusText}`);
      if (!mr.ok) throw new Error(`mine: ${mr.status} ${mr.statusText}`);
      setPending(await pr.json());
      setMine(await mr.json());
      setErr(null);
    } catch (e) {
      setErr(String(e));
    }
  }, []);

  // Identify the current operator (used to disable self-approval).
  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store", credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setMe(d?.user ?? null))
      .catch(() => setMe(null));
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  const submitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;
    setSubmitting(true);
    try {
      const r = await fetch(`${GW}/admin/elevation/request`, {
        method: "POST",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({
          requested_tier: reqTier,
          duration_minutes: duration,
          reason: reason.trim(),
        }),
      });
      if (r.status === 409) {
        const body = await r.json().catch(() => ({}));
        throw new Error(
          body?.detail
            ? `Duplicate request: ${typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail)}`
            : "Duplicate request — you already have a pending elevation for this tier.",
        );
      }
      if (r.status === 429) {
        // Burst-rate refused. The gateway sets Retry-After (seconds) so we
        // can tell the user when they may try again rather than leaving them
        // guessing — important UX given the duplicate-block can produce a
        // similar-feeling error.
        const body = await r.json().catch(() => ({}));
        const retryAfter = Number(r.headers.get("Retry-After")) || 0;
        const retryHint = retryAfter
          ? ` Try again in about ${Math.max(1, Math.round(retryAfter / 60))} min.`
          : "";
        const detail = typeof body?.detail === "string" ? body.detail : "";
        throw new Error(
          `Rate limited — too many elevation requests recently.${retryHint}` +
            (detail ? ` (${detail})` : ""),
        );
      }
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      setReason("");
      setDuration(240);
      await reload();
    } catch (e) {
      setErr(String(e));
    } finally {
      setSubmitting(false);
    }
  };

  const decide = async (item: ElevationItem, action: "approve" | "deny") => {
    const id = String(item.id);
    setBusyId(id);
    try {
      const note = (notes[id] ?? "").trim();
      const r = await fetch(`${GW}/admin/elevation/${id}/${action}`, {
        method: "POST",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify(note ? { decision_note: note } : {}),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      // Optimistic refresh: drop the row from the pending list immediately,
      // then reload to pick up server-side canonical state.
      setPending((prev) => (prev ? prev.filter((p) => String(p.id) !== id) : prev));
      setNotes((n) => { const c = { ...n }; delete c[id]; return c; });
      setNoteOpenFor((o) => ({ ...o, [id]: null }));
      await reload();
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusyId(null);
    }
  };

  const cancel = async (item: ElevationItem) => {
    const id = String(item.id);
    if (!confirm("Cancel this pending elevation request?")) return;
    setBusyId(id);
    try {
      const r = await fetch(`${GW}/admin/elevation/${id}/cancel`, {
        method: "POST",
        headers: JSON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({}),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      // Optimistic: flip the row to cancelled locally, then reload.
      setMine((prev) =>
        prev ? prev.map((m) => (String(m.id) === id ? { ...m, status: "cancelled" } : m)) : prev,
      );
      await reload();
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusyId(null);
    }
  };

  const tierArrow = useMemo(
    () => (from: string, to: string) => (
      <span className="inline-flex items-center gap-1 font-mono text-xs">
        <Badge variant="secondary">{from}</Badge>
        <ArrowRight className="h-3 w-3 text-muted-foreground" />
        <Badge variant="accent">{to}</Badge>
      </span>
    ),
    [],
  );

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">JIT Elevations</h1>
          <p className="text-muted-foreground">
            Just-in-time tier elevation. Two-person rule: requester cannot self-approve.
          </p>
        </div>
        <Badge variant="accent" className="px-3 py-1">S4 — live</Badge>
      </div>

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">Error: {err}</CardContent>
        </Card>
      )}

      {/* Request elevation */}
      <Card>
        <CardHeader>
          <CardTitle>Request elevation</CardTitle>
          <CardDescription>
            A peer admin must approve. The elevation auto-expires after the requested duration.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submitRequest} className="grid gap-3 md:grid-cols-4">
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Requested tier
              </label>
              <select
                value={reqTier}
                onChange={(e) => setReqTier(e.target.value)}
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                required
              >
                {TIERS.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Duration (minutes)
              </label>
              <Input
                type="number"
                min={15}
                max={1440}
                value={duration}
                onChange={(e) => setDuration(Math.max(15, Math.min(1440, Number(e.target.value) || 0)))}
                required
              />
            </div>
            <div className="space-y-1 md:col-span-2">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Reason
              </label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value.slice(0, 1024))}
                placeholder="Incident IR-1234 — need temporary write access to investigate."
                maxLength={1024}
                required
                rows={2}
                className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
              />
              <div className="text-right text-[10px] text-muted-foreground">
                {reason.length} / 1024
              </div>
            </div>
            <div className="md:col-span-4 flex justify-end">
              <Button
                type="submit"
                variant="accent"
                disabled={submitting || !reason.trim()}
              >
                <ArrowUpCircle className="mr-1 h-4 w-4" />
                {submitting ? "Submitting…" : "Request elevation"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Pending approvals */}
      <Card>
        <CardHeader>
          <CardTitle>Pending approvals</CardTitle>
          <CardDescription>
            Approve or deny outstanding requests. A short decision note is recommended for audit.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!pending ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : pending.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nothing pending. The queue is clear.</p>
          ) : (
            <Table>
              <THead>
                <TR>
                  <TH>User</TH>
                  <TH>Team</TH>
                  <TH>Elevation</TH>
                  <TH>Duration</TH>
                  <TH>Reason</TH>
                  <TH>Requested at</TH>
                  <TH className="w-64 text-right">Actions</TH>
                </TR>
              </THead>
              <TBody>
                {pending.map((it) => {
                  const id = String(it.id);
                  const isSelf = !!me && (me === it.user_id || me === it.user_email);
                  const open = noteOpenFor[id] ?? null;
                  const note = notes[id] ?? "";
                  const busy = busyId === id;
                  return (
                    <TR key={id}>
                      <TD>
                        <div className="leading-tight">
                          <div className="font-mono text-xs">{it.user_id}</div>
                          {it.user_email && (
                            <div className="text-xs text-muted-foreground">{it.user_email}</div>
                          )}
                        </div>
                      </TD>
                      <TD className="font-mono text-xs">{it.team_id ?? "—"}</TD>
                      <TD>{tierArrow(it.base_tier, it.requested_tier)}</TD>
                      <TD className="text-xs">{it.duration_minutes} min</TD>
                      <TD className="max-w-xs">
                        <div className="line-clamp-2 text-sm" title={it.reason}>{it.reason}</div>
                      </TD>
                      <TD className="text-xs text-muted-foreground">
                        {new Date(it.requested_at).toLocaleString()}
                      </TD>
                      <TD className="text-right">
                        {open ? (
                          <div className="space-y-2">
                            <textarea
                              value={note}
                              onChange={(e) =>
                                setNotes((n) => ({ ...n, [id]: e.target.value.slice(0, 1024) }))
                              }
                              placeholder={
                                open === "approve" ? "Approval note (optional)" : "Reason for denial (optional)"
                              }
                              rows={2}
                              className="flex w-full rounded-md border border-input bg-background px-2 py-1 text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                            />
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => setNoteOpenFor((o) => ({ ...o, [id]: null }))}
                                disabled={busy}
                              >
                                Cancel
                              </Button>
                              <Button
                                size="sm"
                                variant={open === "approve" ? "accent" : "destructive"}
                                onClick={() => decide(it, open)}
                                disabled={busy}
                              >
                                {open === "approve" ? (
                                  <><CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Confirm approve</>
                                ) : (
                                  <><XCircle className="mr-1 h-3.5 w-3.5" /> Confirm deny</>
                                )}
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              size="sm"
                              variant="accent"
                              disabled={isSelf || busy}
                              title={isSelf ? "self-approval blocked" : undefined}
                              onClick={() => setNoteOpenFor((o) => ({ ...o, [id]: "approve" }))}
                            >
                              <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                              {isSelf ? "self-approval blocked" : "Approve"}
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              disabled={busy}
                              onClick={() => setNoteOpenFor((o) => ({ ...o, [id]: "deny" }))}
                            >
                              <XCircle className="mr-1 h-3.5 w-3.5" /> Deny
                            </Button>
                          </div>
                        )}
                      </TD>
                    </TR>
                  );
                })}
              </TBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* My recent requests */}
      <Card>
        <CardHeader>
          <CardTitle>My recent requests</CardTitle>
          <CardDescription>
            Pending requests can be cancelled before a peer decides on them.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!mine ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : mine.length === 0 ? (
            <p className="text-sm text-muted-foreground">You haven't requested any elevations yet.</p>
          ) : (
            <Table>
              <THead>
                <TR>
                  <TH>Status</TH>
                  <TH>Elevation</TH>
                  <TH>Duration</TH>
                  <TH>Reason</TH>
                  <TH>Requested at</TH>
                  <TH>Decided at</TH>
                  <TH>Expires</TH>
                  <TH className="w-24 text-right">Actions</TH>
                </TR>
              </THead>
              <TBody>
                {mine.map((it) => {
                  const id = String(it.id);
                  const busy = busyId === id;
                  return (
                    <TR key={id}>
                      <TD>
                        <Badge variant={STATUS_VARIANT[it.status]}>{it.status}</Badge>
                      </TD>
                      <TD>{tierArrow(it.base_tier, it.requested_tier)}</TD>
                      <TD className="text-xs">{it.duration_minutes} min</TD>
                      <TD className="max-w-xs">
                        <div className="line-clamp-2 text-sm" title={it.reason}>{it.reason}</div>
                        {it.decision_note && (
                          <div className="mt-1 text-xs text-muted-foreground" title={it.decision_note}>
                            note: {it.decision_note}
                          </div>
                        )}
                      </TD>
                      <TD className="text-xs text-muted-foreground">
                        {new Date(it.requested_at).toLocaleString()}
                      </TD>
                      <TD className="text-xs text-muted-foreground">
                        {it.decided_at ? new Date(it.decided_at).toLocaleString() : "—"}
                      </TD>
                      <TD className="text-xs text-muted-foreground">
                        {it.expires_at ? new Date(it.expires_at).toLocaleString() : "—"}
                      </TD>
                      <TD className="text-right">
                        {it.status === "pending" ? (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => cancel(it)}
                            disabled={busy}
                          >
                            <X className="mr-1 h-3.5 w-3.5" /> Cancel
                          </Button>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TD>
                    </TR>
                  );
                })}
              </TBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
