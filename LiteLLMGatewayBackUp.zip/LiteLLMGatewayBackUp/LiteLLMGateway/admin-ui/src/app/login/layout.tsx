/**
 * Login uses a chrome-free layout (no sidebar / nav). The root layout
 * already wraps everything in <ThemeProvider>, so we just pass children
 * through here.
 */
export default function LoginLayout({ children }: { children: React.ReactNode }) {
  return children;
}
