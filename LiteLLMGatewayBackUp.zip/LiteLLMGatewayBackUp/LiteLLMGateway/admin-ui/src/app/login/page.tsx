"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

// useSearchParams() requires a Suspense boundary at the page level under the
// Next.js 15 App Router static prerender pipeline.
export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen" />}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next   = params.get("next") || "/";
  const [user, setUser]       = useState("");
  const [pass, setPass]       = useState("");
  const [submitting, setSub]  = useState(false);
  const [err, setErr]         = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSub(true);
    setErr(null);
    try {
      const r = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ user, pass }),
      });
      if (!r.ok) {
        setErr(r.status === 401 ? "Invalid credentials" : `Error ${r.status}`);
        return;
      }
      router.replace(next);
      router.refresh();
    } catch (e2) {
      setErr(String(e2));
    } finally {
      setSub(false);
    }
  };

  return (
    <div className="app-backdrop relative flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-background to-secondary/30 p-6 font-sans">
      <div className="relative z-10 flex w-full max-w-sm flex-col items-center gap-6">
        <Card className="w-full shadow-lg">
          <CardContent className="flex flex-col gap-6 p-8">
            <div className="flex flex-col items-center gap-4 text-center">
              {/* OATI mark on a Solarized-base02 backing tile — keeps the
                  logo's red-gradient halo from clashing with the light
                  card surface, mirrors the sidebar treatment. */}
              <div className="flex h-16 w-20 items-center justify-center rounded-lg bg-[#073642] shadow-sm">
                <img
                  src="/oati-logo.png"
                  alt="OATI"
                  width={88}
                  height={68}
                  className="h-12 w-auto select-none"
                  draggable={false}
                />
              </div>
              <div className="space-y-1.5">
                <h1 className="page-title">Welcome back</h1>
                <p className="text-sm text-muted-foreground">
                  Sign in to the OATI LLMGateway admin console
                </p>
              </div>
            </div>

            <form className="flex flex-col gap-4" onSubmit={submit}>
              <div className="space-y-1.5">
                <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Username
                </label>
                <Input
                  value={user}
                  onChange={(e) => setUser(e.target.value)}
                  placeholder="admin"
                  autoComplete="username"
                  required
                  autoFocus
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Password
                </label>
                <Input
                  type="password"
                  value={pass}
                  onChange={(e) => setPass(e.target.value)}
                  autoComplete="current-password"
                  required
                />
              </div>
              {err && (
                <p className="rounded-lg border border-destructive/40 bg-destructive/10 p-2.5 text-xs text-destructive">
                  {err}
                </p>
              )}
              <Button
                type="submit"
                disabled={submitting || !user || !pass}
                className="mt-1 w-full bg-gradient-to-b from-primary to-primary/90 shadow-sm shadow-primary/20"
                variant="accent"
              >
                {submitting ? "Signing in…" : "Sign in"}
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                No accounts here — OIDC integration lands in Sprint 4.
              </p>
            </form>
          </CardContent>
        </Card>
        <p className="text-xs text-muted-foreground/70">
          OATI LLMGateway · v0.1.0
        </p>
      </div>
    </div>
  );
}
