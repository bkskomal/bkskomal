"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Activity, AlertTriangle, ArrowRight, Cpu, RefreshCw, ShieldCheck, Zap,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { InfoBox } from "@/components/ui/info-box";
import { ObservabilityBus } from "@/components/observability-bus";
import { useCostVisible } from "@/components/cost-visibility";
import { fetchGateway } from "@/lib/utils";
import { DashboardCustomizer } from "@/components/dashboard-customizer";
import {
  useDashboardPrefs,
  type DashboardSectionId,
} from "@/components/dashboard-prefs";

type ReadyResponse = {
  ready: boolean;
  router_plugins: string[];
  audit_plugins: string[];
  loaded_plugins: string[];
};

type Plugin = {
  name: string;
  kind: "auth" | "authz" | "dlp" | "guardrail" | "router" | "output_scan" | "audit" | "observe";
  version: string;
  description: string;
};

type DashboardSummary = {
  window_minutes:    number;
  generated_at:      string;
  request_count:     number;
  requests_per_min:  number;
  avg_latency_ms:    number;
  p99_latency_ms:    number;
  tokens_in_total:   number;
  tokens_out_total:  number;
  cost_usd_total:    number;
  verdict_counts:    Record<string, number>;
  dlp_findings:      number;
  secret_leaks:      number;
  top_models:        { model: string; count: number; tokens: number }[];
  top_teams:         { team:  string; count: number; tokens: number }[];
  timeseries:        { minutes_ago: number; count: number; refused: number }[];
};

const KIND_VARIANT: Record<Plugin["kind"], "default" | "destructive" | "accent" | "success" | "warning" | "secondary"> = {
  auth: "default",
  authz: "default",
  dlp: "destructive",
  guardrail: "destructive",
  router: "accent",
  output_scan: "warning",
  audit: "default",
  observe: "success",
};

const PIPELINE_STAGES = [
  { num: 1, label: "AuthN" },
  { num: 2, label: "AuthZ" },
  { num: 3, label: "DLP" },
  { num: 4, label: "Smart Router" },
  { num: 5, label: "Inference" },
  { num: 6, label: "Audit" },
];

// Auto-refresh cadence. 10s feels live without flooding the audit DB —
// a single SELECT over the last hour costs nothing on a quiet system.
const REFRESH_INTERVAL_MS = 10_000;

export default function Dashboard() {
  const [ready, setReady]     = useState<ReadyResponse | null>(null);
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [error, setError]     = useState<string | null>(null);
  const [refreshedAt, setRefreshedAt] = useState<Date | null>(null);
  const { visibleOrder } = useDashboardPrefs();

  // Initial /ready snapshot — gates the operational pill in the header.
  useEffect(() => {
    fetchGateway<ReadyResponse>("/ready")
      .then(setReady)
      .catch((e) => setError(String(e)));
  }, []);

  // Live rollup — auto-refreshed every REFRESH_INTERVAL_MS.
  const refresh = useCallback(async () => {
    try {
      const r = await fetch("/api/gateway/admin/dashboard/summary?window_minutes=60", {
        cache: "no-store", credentials: "same-origin",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      setSummary(await r.json());
      setRefreshedAt(new Date());
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  }, []);

  useEffect(() => {
    void refresh();
    const id = window.setInterval(refresh, REFRESH_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, [refresh]);

  // Each section is rendered on demand by id so the customizer's saved
  // order is the single source of truth for layout.
  const renderSection = (id: DashboardSectionId): React.ReactNode => {
    switch (id) {
      case "stats":
        return (
          <section key="stats" className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <InfoBox
              tone="info"
              icon={<Activity className="h-16 w-16" />}
              label="Requests / min"
              value={summary ? summary.requests_per_min.toFixed(2) : "—"}
              footer={summary ? `${summary.request_count.toLocaleString()} in last 60 min` : "loading…"}
              href="/metrics"
            />
            <InfoBox
              tone="success"
              icon={<Zap className="h-16 w-16" />}
              label="p99 latency (ms)"
              value={summary ? `${Math.round(summary.p99_latency_ms)}` : "—"}
              footer={summary ? `avg ${Math.round(summary.avg_latency_ms)} ms` : "ms"}
              href="/metrics"
            />
            <InfoBox
              tone="warning"
              icon={<ShieldCheck className="h-16 w-16" />}
              label="DLP findings · 1h"
              value={summary ? summary.dlp_findings.toString() : "—"}
              footer={summary ? `${summary.secret_leaks} response leak${summary.secret_leaks === 1 ? "" : "s"}` : "loading…"}
              href="/monitoring"
            />
            <InfoBox
              tone="danger"
              icon={<Cpu className="h-16 w-16" />}
              label="Loaded plugins"
              value={ready?.loaded_plugins.length ?? "—"}
              footer="Discovered via entry points"
              href="/plugins"
            />
          </section>
        );

      case "activity":
        return summary ? <ActivitySparkline key="activity" data={summary.timeseries} /> : null;

      case "verdict":
        return summary
          ? <VerdictMix key="verdict" counts={summary.verdict_counts} total={summary.request_count} />
          : null;

      case "usage":
        return summary ? <UsageTotals key="usage" summary={summary} /> : null;

      case "top-models":
        return summary && summary.top_models.length > 0
          ? <TopList key="top-models" title="Top models · 1h"
              items={summary.top_models.map((m) => ({ label: m.model, count: m.count, tokens: m.tokens }))} />
          : null;

      case "top-teams":
        return summary && summary.top_teams.length > 0
          ? <TopList key="top-teams" title="Top teams · 1h"
              items={summary.top_teams.map((t) => ({ label: t.team, count: t.count, tokens: t.tokens }))} />
          : null;

      case "pipeline":
        return (
          <section key="pipeline" className="space-y-3">
            <div>
              <h2 className="section-title">Pipeline stages</h2>
              <p className="section-subtitle">
                Every request walks these six gates in order. A failure short-circuits with a structured error.
              </p>
            </div>
            <Card>
              <CardContent>
                <ol className="flex flex-wrap items-center gap-x-1 gap-y-3">
                  {PIPELINE_STAGES.map((s, idx) => (
                    <li key={s.num} className="flex items-center gap-1">
                      <div className="group inline-flex items-center gap-2 rounded-md border border-border bg-secondary py-1.5 pl-1.5 pr-3 text-sm transition-colors hover:bg-accent hover:text-accent-foreground">
                        <span className="inline-flex h-6 w-6 items-center justify-center rounded bg-card font-mono text-[11px] tabular-nums text-muted-foreground ring-1 ring-inset ring-border">
                          {s.num}
                        </span>
                        <span className="font-medium tracking-tight">{s.label}</span>
                      </div>
                      {idx < PIPELINE_STAGES.length - 1 && (
                        <ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/60" aria-hidden />
                      )}
                    </li>
                  ))}
                </ol>
              </CardContent>
            </Card>
          </section>
        );

      case "plugins":
        return (
          <section key="plugins" className="space-y-3">
            <div>
              <h2 className="section-title">Loaded plugins</h2>
              <p className="section-subtitle">
                Discovered via Python entry-points at startup. Install a package and add its name to{" "}
                <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">GATEWAY_PLUGINS</code>.
              </p>
            </div>
            {!ready ? (
              <Card>
                <CardContent className="p-6 text-sm text-muted-foreground">Loading…</CardContent>
              </Card>
            ) : (
              <PluginList />
            )}
          </section>
        );
    }
  };

  // Visual grouping: the three "middle" sections (activity / verdict / usage)
  // and the two "Top" lists used to be in 3-col and 2-col grids respectively.
  // Now that they can be hidden or reordered independently, we group them
  // dynamically — adjacent middle/top items share a row in a responsive grid.
  type Group =
    | { kind: "single";  ids: DashboardSectionId[] }
    | { kind: "triple";  ids: DashboardSectionId[] }
    | { kind: "double";  ids: DashboardSectionId[] };

  const groupSize: Partial<Record<DashboardSectionId, "triple" | "double">> = {
    activity: "triple", verdict: "triple", usage: "triple",
    "top-models": "double", "top-teams": "double",
  };

  const groups: Group[] = [];
  let buf: { kind: "triple" | "double"; ids: DashboardSectionId[] } | null = null;
  for (const id of visibleOrder) {
    const cohort = groupSize[id];
    if (!cohort) {
      if (buf) { groups.push(buf); buf = null; }
      groups.push({ kind: "single", ids: [id] });
    } else if (buf && buf.kind === cohort) {
      buf.ids.push(id);
    } else {
      if (buf) groups.push(buf);
      buf = { kind: cohort, ids: [id] };
    }
  }
  if (buf) groups.push(buf);

  return (
    <div className="space-y-6">
      {/* Top-of-page chrome: 5-pipe observability status. */}
      <ObservabilityBus />

      {/* Header */}
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="page-title">Gateway Overview</h1>
          <p className="page-subtitle max-w-2xl">
            Policy-oriented AI gateway. Every request walks through the same six gates
            before it ever touches a model.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {refreshedAt && (
            <span className="hidden text-[11px] text-muted-foreground sm:inline">
              updated {refreshedAt.toLocaleTimeString()}
              <button
                onClick={refresh}
                className="ml-2 inline-flex h-5 w-5 items-center justify-center rounded-md hover:bg-secondary"
                aria-label="Refresh"
                title="Refresh"
              >
                <RefreshCw className="h-3 w-3" />
              </button>
            </span>
          )}
          {ready && (
            <div
              className={
                "inline-flex h-8 items-center gap-2 rounded-full border px-3 text-xs font-medium " +
                (ready.ready
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400"
                  : "border-destructive/40 bg-destructive/10 text-destructive")
              }
            >
              <span className="relative flex h-2 w-2">
                <span
                  className={
                    "absolute inline-flex h-full w-full animate-ping rounded-full opacity-75 " +
                    (ready.ready ? "bg-emerald-400" : "bg-destructive")
                  }
                />
                <span
                  className={
                    "relative inline-flex h-2 w-2 rounded-full " +
                    (ready.ready ? "bg-emerald-500" : "bg-destructive")
                  }
                />
              </span>
              {ready.ready ? "Operational" : "Degraded"}
            </div>
          )}
          <DashboardCustomizer />
        </div>
      </header>

      {error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="flex items-center gap-2 p-4 text-sm text-destructive">
            <AlertTriangle className="h-4 w-4" />
            {error}
          </CardContent>
        </Card>
      )}

      {/* Render groups in the saved/visible order. */}
      {groups.map((g, gi) => {
        if (g.kind === "single") {
          return <div key={`g-${gi}`}>{renderSection(g.ids[0])}</div>;
        }
        const cols = g.kind === "triple" ? "lg:grid-cols-3" : "lg:grid-cols-2";
        return (
          <section key={`g-${gi}`} className={`grid gap-4 ${cols}`}>
            {g.ids.map((id) => renderSection(id))}
          </section>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  Inline SVG sparkline — no charting dep, looks crisp at any size.  *
 *  Stacked area: total request count (accent) with refused mass on   *
 *  top in destructive color so spikes are obvious at a glance.       *
 * ------------------------------------------------------------------ */
function ActivitySparkline({ data }: { data: DashboardSummary["timeseries"] }) {
  const W = 480, H = 80, PAD = 4;
  const max = Math.max(1, ...data.map((d) => d.count));
  const step = data.length > 1 ? (W - PAD * 2) / (data.length - 1) : 0;
  const yFor = (v: number) => H - PAD - (v / max) * (H - PAD * 2);

  // Build area paths — total fills the band, refused overlays as a thin
  // destructive accent so a small refused bump stays visible.
  const areaPath = data.length === 0 ? "" : (() => {
    const top = data.map((d, i) => `${i === 0 ? "M" : "L"} ${PAD + i * step} ${yFor(d.count)}`).join(" ");
    return `${top} L ${PAD + (data.length - 1) * step} ${H - PAD} L ${PAD} ${H - PAD} Z`;
  })();
  const refusedPath = data.length === 0 ? "" : (() => {
    return data.map((d, i) => `${i === 0 ? "M" : "L"} ${PAD + i * step} ${yFor(d.refused)}`).join(" ");
  })();

  const total = data.reduce((s, d) => s + d.count, 0);
  const refusedTotal = data.reduce((s, d) => s + d.refused, 0);

  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-3 flex items-baseline justify-between">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              Activity · last 60 min
            </div>
            <div className="stat-number">
              {total.toLocaleString()}
            </div>
          </div>
          {refusedTotal > 0 && (
            <Badge variant="destructive">{refusedTotal} refused</Badge>
          )}
        </div>
        <svg viewBox={`0 0 ${W} ${H}`} className="h-20 w-full" preserveAspectRatio="none">
          <defs>
            <linearGradient id="spark" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%"  stopColor="hsl(var(--accent))" stopOpacity="0.45" />
              <stop offset="100%" stopColor="hsl(var(--accent))" stopOpacity="0.02" />
            </linearGradient>
          </defs>
          {areaPath && <path d={areaPath} fill="url(#spark)" stroke="hsl(var(--accent))" strokeWidth="1.25" />}
          {refusedPath && refusedTotal > 0 && (
            <path d={refusedPath} fill="none" stroke="hsl(var(--destructive))" strokeWidth="1.25" />
          )}
        </svg>
        <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
          <span>60m ago</span>
          <span>now</span>
        </div>
      </CardContent>
    </Card>
  );
}

/* ------------------------------------------------------------------ *
 *  Verdict donut — small and informative                              *
 * ------------------------------------------------------------------ */
function VerdictMix({ counts, total }: { counts: Record<string, number>; total: number }) {
  const VERDICT_COLOR: Record<string, string> = {
    allow:   "bg-emerald-500",
    refused: "bg-destructive",
    error:   "bg-amber-500",
  };
  const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Verdict mix · 1h
        </div>
        <div className="mt-3 flex h-2 w-full overflow-hidden rounded-full bg-secondary">
          {entries.map(([v, n]) => (
            <div
              key={v}
              className={"h-full " + (VERDICT_COLOR[v] ?? "bg-muted-foreground")}
              style={{ width: `${total ? (n / total) * 100 : 0}%` }}
              title={`${v}: ${n}`}
            />
          ))}
        </div>
        <ul className="mt-3 space-y-1.5 text-sm">
          {entries.length === 0 && (
            <li className="text-xs text-muted-foreground">No traffic yet.</li>
          )}
          {entries.map(([v, n]) => (
            <li key={v} className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <span className={"inline-block h-2 w-2 rounded-full " + (VERDICT_COLOR[v] ?? "bg-muted-foreground")} />
                <span className="capitalize">{v}</span>
              </span>
              <span className="font-mono tabular-nums text-muted-foreground">
                {n.toLocaleString()} ({total ? Math.round((n / total) * 100) : 0}%)
              </span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

/* ------------------------------------------------------------------ *
 *  Token / cost totals                                                *
 * ------------------------------------------------------------------ */
function UsageTotals({ summary }: { summary: DashboardSummary }) {
  // Cost row only renders when the operator has enabled cost-metrics in
  // Settings → App settings. Tokens always show — they're a usage signal,
  // not a billing one, so they're useful regardless of the cost gate.
  const showCost = useCostVisible() === true;
  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Usage · 1h
        </div>
        <ul className="mt-3 space-y-2.5 text-sm">
          <KV label="Tokens in"  value={summary.tokens_in_total.toLocaleString()} />
          <KV label="Tokens out" value={summary.tokens_out_total.toLocaleString()} />
          {showCost && (
            <KV label="Cost (USD)" value={`$${summary.cost_usd_total.toFixed(4)}`} />
          )}
        </ul>
      </CardContent>
    </Card>
  );
}

function KV({ label, value }: { label: string; value: string }) {
  return (
    <li className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-mono tabular-nums">{value}</span>
    </li>
  );
}

/* ------------------------------------------------------------------ *
 *  Top-N list (models / teams)                                       *
 * ------------------------------------------------------------------ */
function TopList({ title, items }: { title: string; items: { label: string; count: number; tokens: number }[] }) {
  const max = Math.max(1, ...items.map((i) => i.count));
  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="mb-3 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          {title}
        </div>
        {items.length === 0 ? (
          <div className="text-sm text-muted-foreground">No traffic yet.</div>
        ) : (
          <ul className="space-y-2.5">
            {items.map((it) => {
              const pct = (it.count / max) * 100;
              return (
                <li key={it.label} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="truncate font-mono">{it.label}</span>
                    <span className="font-mono tabular-nums text-muted-foreground">
                      {it.count} req · {it.tokens.toLocaleString()} tok
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                    <div className="h-full rounded-full bg-accent" style={{ width: `${pct}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

/* ------------------------------------------------------------------ *
 *  Plugins list — unchanged                                           *
 * ------------------------------------------------------------------ */
function PluginList() {
  const [plugins, setPlugins] = useState<Plugin[] | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/gateway/admin/plugins", { cache: "no-store", credentials: "same-origin" })
      .then(async (r) => {
        if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
        const data = await r.json();
        setPlugins(data.plugins);
      })
      .catch((e) => setErr(String(e)));
  }, []);

  if (err) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="p-4 text-sm text-destructive">
          Failed to load plugins: {err}
        </CardContent>
      </Card>
    );
  }
  if (!plugins) {
    return (
      <Card>
        <CardContent className="p-6 text-sm text-muted-foreground">Loading…</CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-3 sm:grid-cols-1 lg:grid-cols-2">
      {plugins.map((p) => (
        <Card
          key={p.name}
          className="group relative overflow-hidden shadow-soft transition-all hover:shadow-ring"
        >
          <div
            aria-hidden
            className="pointer-events-none absolute inset-y-0 left-0 w-px bg-gradient-to-b from-accent/60 via-border to-transparent"
          />
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1 space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="truncate font-mono text-sm font-medium text-foreground">
                    {p.name}
                  </span>
                  <span className="font-mono text-[11px] tabular-nums text-muted-foreground">
                    v{p.version}
                  </span>
                </div>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {p.description}
                </p>
              </div>
              <Badge
                variant={KIND_VARIANT[p.kind] ?? "secondary"}
                className="shrink-0 text-[10px] uppercase tracking-wide"
              >
                {p.kind}
              </Badge>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
