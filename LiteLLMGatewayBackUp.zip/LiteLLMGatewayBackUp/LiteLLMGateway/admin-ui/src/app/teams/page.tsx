"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, Save, Trash2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

type Team = {
  team_id: string;
  tier: string;
  description: string | null;
  created_at: string;
};

// In-memory "draft" the user is typing into a row. `dirty` is derived by
// comparing against the server row, so we don't need to track it separately.
type Draft = { tier: string; description: string };

const TIERS = ["L0_readonly", "L1_standard", "L2_senior", "L3_privileged", "quarantined"] as const;

const TIER_VARIANT: Record<string, "default" | "destructive" | "warning" | "success" | "accent" | "secondary"> = {
  L0_readonly:   "secondary",
  L1_standard:   "default",
  L2_senior:     "accent",
  L3_privileged: "success",
  quarantined:   "destructive",
};

const COMMON_HEADERS: HeadersInit = { "Content-Type": "application/json" };
const GW = "/api/gateway";

export default function TeamsPage() {
  const [teams,   setTeams]   = useState<Team[] | null>(null);
  const [err,     setErr]     = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);   // team_id mid-save
  const [drafts,  setDrafts]  = useState<Record<string, Draft>>({});

  // "New team" inline form — shown when the operator clicks `+ New team`.
  const [creating,        setCreating]       = useState(false);
  const [newTeamId,       setNewTeamId]      = useState("");
  const [newTier,         setNewTier]        = useState<string>("L1_standard");
  const [newDescription,  setNewDescription] = useState("");
  const [createBusy,      setCreateBusy]     = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await fetch(`${GW}/admin/teams`, {
        headers: COMMON_HEADERS, credentials: "same-origin", cache: "no-store",
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      setTeams(await r.json());
      setErr(null);
    } catch (e) {
      setErr(String(e));
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const draftFor = (t: Team): Draft =>
    drafts[t.team_id] ?? { tier: t.tier, description: t.description ?? "" };

  const isDirty = (t: Team) => {
    const d = draftFor(t);
    return d.tier !== t.tier || d.description !== (t.description ?? "");
  };

  const updateDraft = (team_id: string, patch: Partial<Draft>) =>
    setDrafts((all) => ({
      ...all,
      [team_id]: { ...(all[team_id] ?? { tier: "", description: "" }), ...patch },
    }));

  const cancelEdit = (team_id: string) =>
    setDrafts((all) => { const c = { ...all }; delete c[team_id]; return c; });

  const save = async (t: Team) => {
    const d = draftFor(t);
    if (!isDirty(t)) return;
    setPending(t.team_id);
    try {
      const r = await fetch(`${GW}/admin/teams/${t.team_id}`, {
        method: "PUT",
        headers: COMMON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({
          team_id:     t.team_id,
          tier:        d.tier,
          // Empty string clears the description (backend treats "" as NULL).
          description: d.description,
        }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      await load();
      cancelEdit(t.team_id);
      setErr(null);
    } catch (e) {
      setErr(String(e));
    } finally {
      setPending(null);
    }
  };

  const remove = async (t: Team) => {
    if (!confirm(`Delete team "${t.team_id}"? This is hard-deletion — keys referencing the team must be revoked first.`)) {
      return;
    }
    setPending(t.team_id);
    try {
      const r = await fetch(`${GW}/admin/teams/${t.team_id}`, {
        method: "DELETE", credentials: "same-origin",
      });
      // Idempotent: 204 (deleted) or 404 (already gone) → success.
      if (r.status === 409) {
        const body = await r.json().catch(() => ({}));
        const n = body?.detail?.active_key_count ?? "some";
        throw new Error(
          `Cannot delete "${t.team_id}" — ${n} active key(s) still reference it. Revoke them on the API Keys page first.`,
        );
      }
      if (!r.ok && r.status !== 204 && r.status !== 404) {
        throw new Error(`${r.status} ${r.statusText}`);
      }
      await load();
      setErr(null);
    } catch (e) {
      setErr(String(e));
    } finally {
      setPending(null);
    }
  };

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamId.trim()) return;
    setCreateBusy(true);
    try {
      const r = await fetch(`${GW}/admin/teams/${encodeURIComponent(newTeamId.trim())}`, {
        method: "PUT",
        headers: COMMON_HEADERS, credentials: "same-origin",
        body: JSON.stringify({
          team_id:     newTeamId.trim(),
          tier:        newTier,
          description: newDescription.trim() || null,
        }),
      });
      if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
      // Reset form and refresh list.
      setNewTeamId("");
      setNewTier("L1_standard");
      setNewDescription("");
      setCreating(false);
      await load();
      setErr(null);
    } catch (e) {
      setErr(String(e));
    } finally {
      setCreateBusy(false);
    }
  };

  // Surface count of in-flight edits in the card header so the operator
  // doesn't accidentally navigate away with unsaved changes.
  const dirtyCount = useMemo(
    () => (teams ?? []).filter(isDirty).length,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [teams, drafts],
  );

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Teams</h1>
          <p className="page-subtitle">
            One team per row. Tier controls budget, allowed models and agent permissions.
          </p>
        </div>
        <Badge variant="accent" className="px-3 py-1">S1 — live</Badge>
      </div>

      {err && (
        <Card className="border-destructive">
          <CardContent className="p-4 text-sm text-destructive">
            <div className="flex items-start justify-between gap-3">
              <span>{err}</span>
              <button
                onClick={() => setErr(null)}
                className="text-destructive/70 hover:text-destructive"
                aria-label="Dismiss"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div>
            <CardTitle>Registered teams</CardTitle>
            <CardDescription>
              Tier changes apply on the next request — no gateway restart required.
              {dirtyCount > 0 && (
                <span className="ml-2 text-amber-600 dark:text-amber-400">
                  · {dirtyCount} unsaved
                </span>
              )}
            </CardDescription>
          </div>
          {!creating && (
            <Button size="sm" variant="accent" onClick={() => setCreating(true)}>
              <Plus className="mr-1 h-3.5 w-3.5" />
              New team
            </Button>
          )}
        </CardHeader>
        <CardContent className="p-0">
          {!teams ? (
            <p className="p-4 text-sm text-muted-foreground">Loading…</p>
          ) : (
            <Table>
              <THead>
                <TR>
                  <TH className="pl-4">Team</TH>
                  <TH>Current tier</TH>
                  <TH>Change to</TH>
                  <TH>Notes</TH>
                  <TH className="text-right">Created</TH>
                  <TH className="w-44 pr-4 text-right" />
                </TR>
              </THead>
              <TBody>
                {/* "New team" inline form — first row when creating */}
                {creating && (
                  <TR className="bg-accent/5">
                    <TD className="pl-4">
                      <Input
                        value={newTeamId}
                        onChange={(e) => setNewTeamId(e.target.value)}
                        placeholder="team-id"
                        className="h-8 font-mono text-xs"
                        autoFocus
                      />
                    </TD>
                    <TD className="text-xs text-muted-foreground">—</TD>
                    <TD>
                      <select
                        value={newTier}
                        onChange={(e) => setNewTier(e.target.value)}
                        className="h-8 rounded-md border border-input bg-background px-2 text-sm"
                      >
                        {TIERS.map((tier) => (
                          <option key={tier} value={tier}>{tier}</option>
                        ))}
                      </select>
                    </TD>
                    <TD>
                      <Input
                        value={newDescription}
                        onChange={(e) => setNewDescription(e.target.value)}
                        placeholder="(optional) notes about this team"
                        className="h-8 text-sm"
                      />
                    </TD>
                    <TD className="text-right text-xs text-muted-foreground">—</TD>
                    <TD className="pr-4 text-right">
                      <div className="inline-flex gap-1">
                        <Button
                          size="sm"
                          variant="accent"
                          disabled={!newTeamId.trim() || createBusy}
                          onClick={create}
                        >
                          <Save className="mr-1 h-3.5 w-3.5" />
                          {createBusy ? "Creating…" : "Create"}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setCreating(false);
                            setNewTeamId(""); setNewTier("L1_standard"); setNewDescription("");
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                    </TD>
                  </TR>
                )}

                {teams.length === 0 && !creating ? (
                  <TR>
                    <TD colSpan={6} className="p-6 text-center text-sm text-muted-foreground">
                      No teams yet — click <span className="font-medium">+ New team</span> to add one,
                      or seed them from <code className="rounded bg-muted px-1 py-0.5 text-xs">policies.yaml</code>.
                    </TD>
                  </TR>
                ) : (
                  teams.map((t) => {
                    const d     = draftFor(t);
                    const dirty = isDirty(t);
                    const busy  = pending === t.team_id;
                    return (
                      <TR key={t.team_id}>
                        <TD className="pl-4 font-mono text-sm">{t.team_id}</TD>
                        <TD>
                          <Badge variant={TIER_VARIANT[t.tier] ?? "secondary"}>{t.tier}</Badge>
                        </TD>
                        <TD>
                          <select
                            value={d.tier}
                            onChange={(e) => updateDraft(t.team_id, { tier: e.target.value })}
                            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
                            disabled={busy}
                          >
                            {TIERS.map((tier) => (
                              <option key={tier} value={tier}>{tier}</option>
                            ))}
                          </select>
                        </TD>
                        <TD>
                          <Input
                            value={d.description}
                            onChange={(e) => updateDraft(t.team_id, { description: e.target.value })}
                            placeholder="(no notes)"
                            className="h-8 text-sm"
                            disabled={busy}
                          />
                        </TD>
                        <TD className="text-right text-xs text-muted-foreground">
                          {new Date(t.created_at).toLocaleDateString()}
                        </TD>
                        <TD className="pr-4 text-right">
                          <div className="inline-flex items-center gap-1">
                            {dirty && (
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => cancelEdit(t.team_id)}
                                disabled={busy}
                                title="Discard changes"
                              >
                                <X className="h-3.5 w-3.5" />
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant={dirty ? "accent" : "ghost"}
                              disabled={!dirty || busy}
                              onClick={() => save(t)}
                            >
                              <Save className="mr-1 h-3.5 w-3.5" />
                              {busy ? "Saving…" : "Save"}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => remove(t)}
                              disabled={busy}
                              title="Delete team"
                              className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TD>
                      </TR>
                    );
                  })
                )}
              </TBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
