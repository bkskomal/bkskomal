import type { Metadata } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { Shell } from "@/components/shell";

// Geist is bundled in the `geist` npm package and self-hosted by Next at
// build time — zero runtime network calls, no Google-Fonts dependency
// (which kept failing on networks with strict cert inspection).
// Both fonts expose CSS variables (`--font-geist-sans`, `--font-geist-mono`)
// which we alias below to the `--font-sans` / `--font-mono` names the rest
// of the app + Tailwind config already use.

export const metadata: Metadata = {
  title: "OATI LLMGateway · Admin",
  description: "Policy-oriented AI gateway — admin console",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={`${GeistSans.variable} ${GeistMono.variable}`}
      // Geist exposes its variables as `--font-geist-sans` / `--font-geist-mono`.
      // We pin the same values to the existing `--font-sans` / `--font-mono`
      // names that Tailwind's fontFamily config reads — no Tailwind edits
      // needed, no per-page className churn.
      style={{
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        ["--font-sans" as any]: "var(--font-geist-sans)",
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        ["--font-mono" as any]: "var(--font-geist-mono)",
      }}
    >
      <body className="min-h-screen bg-background font-sans antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          themes={["light", "dark", "solarized-light", "solarized-dark"]}
        >
          <Shell>{children}</Shell>
        </ThemeProvider>
      </body>
    </html>
  );
}
