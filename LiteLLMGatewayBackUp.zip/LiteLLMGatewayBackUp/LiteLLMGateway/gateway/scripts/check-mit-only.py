"""MIT-only gate.

Run from the gateway repo root. Fails the build if EITHER:

  1. ANY litellm-family package is installed in the active venv
     (`litellm`, `litellm-enterprise`, `litellm-proxy-extras`), OR
  2. Any source file imports from `litellm` / `litellm_enterprise`.

We migrated off BerriAI's LiteLLM to in-house LLMGateway (MIT, no
enterprise tier). This guard prevents the dependency from re-creeping
in via a transitive resolver or a hasty PR that re-adds the import.

Exit codes:
    0  clean — only MIT-licensed code is present
    1  drift — proprietary package installed OR proprietary import found

Usage:
    python scripts/check-mit-only.py
"""
from __future__ import annotations

import importlib.metadata as md
import re
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT  = REPO_ROOT / "src"

# Packages we never want installed in any environment that's headed to prod.
# LiteLLM itself is banned — we use LLMGateway (MIT) for provider translation.
BANNED_PACKAGES = {
    "litellm":             "Replaced by LLMGateway (MIT). litellm pulls litellm-enterprise transitively in some versions.",
    "litellm-enterprise":  "BerriAI commercial license — requires paid subscription.",
    "litellm-proxy-extras": "Pulls in proprietary integrations.",
}

# Import patterns that would mean code is calling the banned packages.
# Note: `litellm-gateway` is OUR package name and may appear in paths /
# project metadata — only flag `import litellm` / `from litellm`.
BANNED_IMPORT_PATTERNS = [
    re.compile(r"^\s*from\s+litellm(\.|_enterprise\b|\s+import)", re.MULTILINE),
    re.compile(r"^\s*import\s+litellm($|\s|\.|_enterprise)",      re.MULTILINE),
]


def check_installed_packages() -> list[str]:
    """Return human-readable failure lines, one per banned package found."""
    failures: list[str] = []
    for pkg, why in BANNED_PACKAGES.items():
        try:
            v = md.version(pkg)
            failures.append(
                f"  banned package present: {pkg}=={v}\n"
                f"    reason: {why}\n"
                f"    fix:    pip uninstall -y {pkg}"
            )
        except md.PackageNotFoundError:
            pass
    return failures


def check_source_imports() -> list[str]:
    """Walk src/ and flag any banned import."""
    failures: list[str] = []
    if not SRC_ROOT.exists():
        return failures
    for py in SRC_ROOT.rglob("*.py"):
        try:
            text = py.read_text(encoding="utf-8")
        except OSError:
            continue
        for line_no, line in enumerate(text.splitlines(), 1):
            # Patterns use ^...$ with MULTILINE — but we walk line-by-line
            # so strip ^ and run them per-line for matching.
            for raw_pat in (
                r"^\s*from\s+litellm(\.|_enterprise\b|\s+import)",
                r"^\s*import\s+litellm($|\s|\.|_enterprise)",
            ):
                if re.match(raw_pat, line):
                    rel = py.relative_to(REPO_ROOT)
                    failures.append(f"  banned litellm import: {rel}:{line_no}\n"
                                    f"    line: {line.strip()}")
                    break
    return failures


def check_pyproject_extras() -> list[str]:
    """Catch `litellm[proxy]` or `litellm[enterprise]` style extras in
    pyproject.toml. Hatch / Poetry / pip resolve those into installs of
    the proprietary packages."""
    failures: list[str] = []
    pyproj = REPO_ROOT / "pyproject.toml"
    if not pyproj.exists():
        return failures
    txt = pyproj.read_text(encoding="utf-8")
    # Any dependency line that pulls litellm in (with or without extras).
    # Comment / description lines are fine — only catch lines that look like
    # a real dependency spec ("litellm" followed by extras or version op).
    for pat in (
        re.compile(r'^\s*"?\s*litellm(?:\[[^"\]]+\])?\s*[<>=!~]', re.IGNORECASE | re.MULTILINE),
        re.compile(r'^\s*"?\s*litellm(?:\[[^"\]]+\])?\s*"', re.IGNORECASE | re.MULTILINE),
    ):
        m = pat.search(txt)
        if m:
            failures.append(
                f"  litellm requested as a dependency: {m.group(0).strip()}\n"
                f"    fix:  use 'LLMGateway>=0.3.0' instead — drop-in shim "
                f"lives at llmgateway.litellm_compat"
            )
    return failures


def main() -> int:
    print("MIT-only check")
    print("==============")
    fails: list[str] = []
    fails += check_installed_packages()
    fails += check_source_imports()
    fails += check_pyproject_extras()
    if fails:
        print("\nFAIL — proprietary code or packages detected:\n")
        for f in fails:
            print(f)
        print("\nThis project is committed to MIT-only dependencies. Either")
        print("revert the change or run the documented uninstall step")
        print("(scripts/strip-enterprise.sh) and re-check.")
        return 1
    print("\nOK — only MIT (and equivalent permissive) code present.")
    print("    provider translation: LLMGateway (MIT)")
    print("    no litellm / litellm-enterprise / litellm-proxy-extras installed")
    print("    no `import litellm` / `from litellm` in src/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
