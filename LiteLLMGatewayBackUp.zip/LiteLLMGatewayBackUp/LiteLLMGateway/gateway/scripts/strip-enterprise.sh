#!/usr/bin/env bash
# Post-install hook — uninstall the proprietary BerriAI packages that
# `pip install litellm[proxy]` or a transitive resolver may pull in.
#
# Run this after every `pip install -e .` (or any other install command
# that touches the venv). The Dockerfile + dev install instructions
# both call this script.
#
# Why a separate step instead of fixing pyproject.toml only?
#   pip's resolver can re-pull `litellm-enterprise` if a sub-dependency
#   (or a future litellm release) declares it as an install_requires.
#   Belt-and-suspenders: pin the version AND scrub after install.
set -euo pipefail
echo "Stripping LiteLLM family packages from venv (MIT-only policy)..."
echo "  We use LLMGateway (MIT) for provider translation now — see"
echo "  README 'License posture' for context."
python -m pip uninstall -y litellm               2>/dev/null || true
python -m pip uninstall -y litellm-enterprise    2>/dev/null || true
python -m pip uninstall -y litellm-proxy-extras  2>/dev/null || true
echo "Verifying with check-mit-only.py..."
python "$(dirname "$0")/check-mit-only.py"
