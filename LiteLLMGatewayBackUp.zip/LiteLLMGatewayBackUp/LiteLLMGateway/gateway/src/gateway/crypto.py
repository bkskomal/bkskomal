"""AES-GCM helpers for at-rest encryption of audit-log plaintext.

Threat model
------------
The Postgres audit_log stores hashes by default. When a team's policy
requires plaintext retention (regulated data, customer-support replay,
incident forensics), we encrypt the prompt + response with AES-GCM and
store the ciphertext in the dedicated columns. Plaintext is never written
to disk — it lives in memory only as long as the request is being audited.

Reveal is gated by the 4-eyes flow (one admin requests, a different admin
approves, then a time-limited decrypt is allowed) — see
``services.audit_reveals``.

Key management
--------------
For dev / small deployments: single 32-byte key from the
``GATEWAY_AUDIT_KEY`` env var, base64url-encoded. Generate with::

    python -c "import os, base64; print(base64.urlsafe_b64encode(os.urandom(32)).decode())"

For production: replace ``_load_key`` with an AWS KMS / GCP KMS / HashiCorp
Vault data-key fetch. The interface here is intentionally narrow
(``encrypt`` / ``decrypt`` on raw bytes) so the swap is one function.
The single-key approach has known limitations (no rotation without
re-encrypting everything, key rotation requires downtime); these are
acceptable for the dev / single-deployment stage.

Wire format
-----------
``encrypt(plaintext: bytes) -> bytes`` returns:

    [version:1 byte = 0x01] [nonce:12 bytes] [ciphertext + tag:variable]

The 1-byte version prefix lets us swap algorithms later without breaking
already-encrypted rows.
"""

from __future__ import annotations

import base64
import logging
import os
import secrets
from typing import Optional

log = logging.getLogger(__name__)

VERSION_BYTE_AESGCM = 0x01
NONCE_LEN           = 12   # AES-GCM standard
KEY_LEN             = 32   # AES-256

_cached_key: Optional[bytes] = None


def is_enabled() -> bool:
    """True if encryption is configured. False is a clean no-op everywhere."""
    return _try_load_key() is not None


def encrypt(plaintext: bytes) -> Optional[bytes]:
    """Encrypt with AES-GCM. Returns None if encryption is not configured.

    The caller decides what to do with None — typically: skip writing the
    ciphertext column and rely on the always-stored hash.
    """
    if not plaintext:
        return None
    key = _try_load_key()
    if key is None:
        return None
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        log.warning("cryptography is not installed — audit encryption disabled")
        return None
    nonce = secrets.token_bytes(NONCE_LEN)
    ct = AESGCM(key).encrypt(nonce, plaintext, associated_data=None)
    return bytes([VERSION_BYTE_AESGCM]) + nonce + ct


def decrypt(blob: bytes) -> bytes:
    """Decrypt a versioned ciphertext blob produced by :func:`encrypt`.

    Raises ``ValueError`` on malformed input. Raises ``RuntimeError`` if
    encryption isn't configured (caller has a blob but no key).
    """
    if not blob or len(blob) < 1 + NONCE_LEN + 16:
        raise ValueError("ciphertext too short")
    version = blob[0]
    if version != VERSION_BYTE_AESGCM:
        raise ValueError(f"unsupported ciphertext version {version!r}")
    key = _try_load_key()
    if key is None:
        raise RuntimeError(
            "GATEWAY_AUDIT_KEY is not set — cannot decrypt audit ciphertext "
            "stored when a key was previously configured"
        )
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError as e:
        raise RuntimeError(
            "cryptography is not installed — cannot decrypt audit ciphertext"
        ) from e
    nonce = blob[1:1 + NONCE_LEN]
    ct    = blob[1 + NONCE_LEN:]
    return AESGCM(key).decrypt(nonce, ct, associated_data=None)


# ---------------------------------------------------------------------------
# Key loading
# ---------------------------------------------------------------------------
def _try_load_key() -> Optional[bytes]:
    global _cached_key
    if _cached_key is not None:
        return _cached_key
    raw = (os.environ.get("GATEWAY_AUDIT_KEY") or "").strip()
    if not raw:
        return None
    try:
        # Accept either standard or url-safe base64. Strip padding leniency.
        key = base64.urlsafe_b64decode(_pad(raw))
    except Exception:
        try:
            key = base64.b64decode(_pad(raw))
        except Exception:
            log.error("GATEWAY_AUDIT_KEY is set but not valid base64; "
                      "audit encryption DISABLED")
            return None
    if len(key) != KEY_LEN:
        log.error("GATEWAY_AUDIT_KEY decoded to %d bytes; expected %d (AES-256)",
                  len(key), KEY_LEN)
        return None
    _cached_key = key
    return key


def _pad(s: str) -> str:
    return s + "=" * ((4 - len(s) % 4) % 4)


def _reset_cache_for_tests() -> None:
    """Force the next _try_load_key() to re-read the env var. Test-only."""
    global _cached_key
    _cached_key = None
