"""Async SQLAlchemy engines + session factories.

Two databases:
  * ``gateway`` (operational state — keys, teams, policies cache)
  * ``audit``   (append-only audit log)

Plugins should take the engine they need as a constructor arg, not import a
singleton, so they remain testable.
"""

from __future__ import annotations

from typing import AsyncIterator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from .config import get_settings


class Base(DeclarativeBase):
    """Common base for all ORM models."""


# Engines are created lazily so import-time of this module is cheap.
_gateway_engine = None
_audit_engine = None
_GatewaySession: async_sessionmaker[AsyncSession] | None = None
_AuditSession: async_sessionmaker[AsyncSession] | None = None


def _ensure_engines() -> None:
    global _gateway_engine, _audit_engine, _GatewaySession, _AuditSession
    if _gateway_engine is not None:
        return
    s = get_settings()
    _gateway_engine = create_async_engine(s.db_url, pool_pre_ping=True, future=True)
    _audit_engine = create_async_engine(s.audit_db_url, pool_pre_ping=True, future=True)
    _GatewaySession = async_sessionmaker(_gateway_engine, expire_on_commit=False)
    _AuditSession = async_sessionmaker(_audit_engine, expire_on_commit=False)


def gateway_engine():
    _ensure_engines()
    return _gateway_engine


def audit_engine():
    _ensure_engines()
    return _audit_engine


async def gateway_session() -> AsyncIterator[AsyncSession]:
    _ensure_engines()
    async with _GatewaySession() as s:  # type: ignore[misc]
        yield s


async def audit_session() -> AsyncIterator[AsyncSession]:
    _ensure_engines()
    async with _AuditSession() as s:  # type: ignore[misc]
        yield s
