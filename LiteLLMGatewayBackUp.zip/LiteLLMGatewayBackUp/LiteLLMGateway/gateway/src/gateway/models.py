"""ORM models for the operational + audit databases.

We keep schemas intentionally minimal and let Alembic migrations evolve them.
The audit table is append-only by convention (no updates) and is the source
of truth for every billable / regulated event.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Operational DB
# ---------------------------------------------------------------------------
class Team(Base):
    __tablename__ = "teams"

    team_id:     Mapped[str] = mapped_column(String(64), primary_key=True)
    tier:        Mapped[str] = mapped_column(String(32), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    created_at:  Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    keys: Mapped[list["VirtualKey"]] = relationship(back_populates="team", cascade="all,delete")


class VirtualKey(Base):
    __tablename__ = "virtual_keys"
    __table_args__ = (UniqueConstraint("key_hash"),)

    id:            Mapped[int] = mapped_column(Integer, primary_key=True)
    key_hash:      Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    key_prefix:    Mapped[str] = mapped_column(String(16), nullable=False)
    user_id:       Mapped[str] = mapped_column(String(128), index=True)
    user_email:    Mapped[str | None] = mapped_column(String(255))
    team_id:       Mapped[str] = mapped_column(ForeignKey("teams.team_id"))
    role:          Mapped[str] = mapped_column(String(32), default="developer")
    is_active:     Mapped[bool] = mapped_column(default=True)
    expires_at:    Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_used_at:  Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at:    Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    metadata_json: Mapped[dict[str, Any] | None] = mapped_column("metadata", JSON)

    team: Mapped[Team] = relationship(back_populates="keys")


class UebaAlert(Base):
    """A behavioural-anomaly alert raised by an OBSERVE plugin.

    Durable in the operational DB so the SOC has a working queue separate
    from the immutable audit log. Status transitions:
      open → acknowledged → resolved (or open → false_positive).
    """

    __tablename__ = "ueba_alerts"
    __table_args__ = (
        Index("ix_alerts_user_ts",   "user_id",   "raised_at"),
        Index("ix_alerts_team_ts",   "team_id",   "raised_at"),
        Index("ix_alerts_status_ts", "status",    "raised_at"),
        Index("ix_alerts_signal",    "signal"),
    )

    id:         Mapped[int]      = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    raised_at:  Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, index=True)
    user_id:    Mapped[str]      = mapped_column(String(128))
    team_id:    Mapped[str]      = mapped_column(String(64))
    tier:       Mapped[str]      = mapped_column(String(32))
    signal:     Mapped[str]      = mapped_column(String(64))   # e.g. "jailbreak_attempts"
    severity:   Mapped[str]      = mapped_column(String(16))   # info|warn|high|critical
    summary:    Mapped[str]      = mapped_column(String(512))
    details:    Mapped[dict | None] = mapped_column("details", JSON)
    status:     Mapped[str]      = mapped_column(String(16), default="open")
    audit_log_id: Mapped[int | None] = mapped_column(BigInteger)


class ElevationRequest(Base):
    """A developer's request to temporarily run at a higher tier (JIT).

    Lifecycle: pending → approved (then auto-expires) | denied | cancelled.

    While ``status='approved'`` AND ``expires_at > now()``, the auth resolver
    treats the requester's effective tier as ``requested_tier`` instead of
    their team's default. Auto-expiry happens lazily — the resolver compares
    ``expires_at`` against ``now()`` on every request; a background sweeper is
    optional, not required for correctness.

    Approval is dual-control: the requester (``user_id``) cannot also be the
    approver (``approver_user_id``); enforced in the service layer.
    """

    __tablename__ = "elevation_requests"
    __table_args__ = (
        Index("ix_elev_user_active",  "user_id",  "status"),
        Index("ix_elev_status_exp",   "status",   "expires_at"),
        Index("ix_elev_team_ts",      "team_id",  "requested_at"),
    )

    id:               Mapped[int]       = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    user_id:          Mapped[str]       = mapped_column(String(128))
    user_email:       Mapped[str | None] = mapped_column(String(255))
    team_id:          Mapped[str]       = mapped_column(String(64))
    base_tier:        Mapped[str]       = mapped_column(String(32))     # what they have today
    requested_tier:   Mapped[str]       = mapped_column(String(32))     # what they want
    duration_minutes: Mapped[int]       = mapped_column(Integer, default=240)   # 4h default
    reason:           Mapped[str]       = mapped_column(String(1024))

    status:           Mapped[str]       = mapped_column(String(16), default="pending", index=True)
    # "pending" | "approved" | "denied" | "cancelled"

    requested_at:     Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=_now)
    decided_at:       Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at:       Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    approver_user_id: Mapped[str | None] = mapped_column(String(128))
    decision_note:    Mapped[str | None] = mapped_column(String(512))


class TierConfig(Base):
    """Editable per-tier limits (UI-managed).

    Seeded from ``policies.yaml`` on first boot. Once any row exists this
    table is the source of truth; the YAML is bootstrap-only and edits to
    it are picked up only when the table is empty (e.g. after a fresh DB).

    ``models_allowed`` is stored as a JSON array of model_name strings; the
    special value ``["*"]`` means all models.
    """

    __tablename__ = "tier_configs"
    __table_args__ = (
        UniqueConstraint("tier", name="uq_tier_configs_tier"),
    )

    id:               Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    tier:             Mapped[str]  = mapped_column(String(32), nullable=False)
    models_allowed:   Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    tokens_per_day:   Mapped[str]  = mapped_column(String(16), nullable=False, default="100000")  # "unlimited" or integer
    rpm:              Mapped[int]  = mapped_column(Integer, nullable=False, default=60)
    agent_mode:       Mapped[str]  = mapped_column(String(32), nullable=False, default="tools_no_shell")
    override_model:   Mapped[bool] = mapped_column(default=False, nullable=False)
    description:      Mapped[str | None] = mapped_column(Text)
    created_at:       Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at:       Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)


class GuardrailPattern(Base):
    """UI-managed guardrail / DLP / output-scan pattern additions.

    The shipped guardrail_patterns + output_scan_secrets plugins each carry a
    baseline regex set; this table holds operator-added extras (banned terms,
    custom DLP regex, custom secret detectors) without forcing a YAML edit
    + git PR for every new pattern the SOC needs to flag.
    """

    __tablename__ = "guardrail_patterns"
    __table_args__ = (
        Index("ix_guardrail_kind_active", "kind", "is_active"),
    )

    id:          Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    # "banned_topic" | "dlp_extra" | "output_scan_extra"
    kind:        Mapped[str]  = mapped_column(String(32), nullable=False)
    name:        Mapped[str]  = mapped_column(String(128), nullable=False)
    pattern:     Mapped[str]  = mapped_column(Text, nullable=False)
    severity:    Mapped[str]  = mapped_column(String(16), nullable=False, default="warn")
    action:      Mapped[str]  = mapped_column(String(16), nullable=False, default="refuse")
    is_active:   Mapped[bool] = mapped_column(default=True, nullable=False)
    created_by:  Mapped[str | None] = mapped_column(String(128))
    notes:       Mapped[str | None] = mapped_column(Text)
    created_at:  Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at:  Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)


class AuditRevealRequest(Base):
    """A 4-eyes plaintext-reveal request for one audit_log row.

    Lifecycle: pending → approved → revealed (terminal) | denied | expired.

    Dual-control: the requester (``requested_by``) cannot also be the
    approver (``approver_user_id``) — enforced in the service layer.
    Only the requester (or master) can fetch the decrypted plaintext, and
    only between ``decided_at`` and ``expires_at`` (default 15 minutes).
    """

    __tablename__ = "audit_reveal_requests"
    __table_args__ = (
        Index("ix_reveal_status", "status"),
        Index("ix_reveal_audit_log", "audit_log_id"),
        Index("ix_reveal_requester", "requested_by"),
    )

    id:               Mapped[int]      = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    audit_log_id:     Mapped[int]      = mapped_column(BigInteger, nullable=False)
    requested_by:     Mapped[str]      = mapped_column(String(128), nullable=False)
    requested_email:  Mapped[str | None] = mapped_column(String(255))
    reason:           Mapped[str]      = mapped_column(String(1024), nullable=False)
    status:           Mapped[str]      = mapped_column(String(16), default="pending", nullable=False)
    # "pending" | "approved" | "denied" | "revealed" | "expired"

    requested_at:     Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=_now)
    decided_at:       Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at:       Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    revealed_at:      Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    approver_user_id: Mapped[str | None] = mapped_column(String(128))
    decision_note:    Mapped[str | None] = mapped_column(String(512))


class PluginConfig(Base):
    """UI-managed per-plugin configuration overrides.

    Each plugin reads its config from policies.yaml at setup time. This
    table layers operator edits on top — the lifespan merges the JSON
    payload here into the policies dict before calling setup() so plugins
    don't need to know about the DB. ``config`` is a free-form JSON object
    whose shape is plugin-specific; the admin API exposes a schema per
    plugin so the UI can render a typed form rather than a raw JSON editor.
    """

    __tablename__ = "plugin_configs"
    __table_args__ = (
        UniqueConstraint("plugin_name", name="uq_plugin_configs_name"),
    )

    id:           Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    plugin_name:  Mapped[str]  = mapped_column(String(64), nullable=False)
    config:       Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    updated_at:   Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)


class SystemSetting(Base):
    """Generic kv store for system-wide UI toggles + lightweight settings.

    Plugin settings live in ``plugin_configs`` (schema-driven, per-plugin
    forms). Things that aren't plugin-scoped — UI feature flags, dashboard
    visibility toggles — live here. Singleton-style: one row per key.
    """

    __tablename__ = "system_settings"
    __table_args__ = (UniqueConstraint("key", name="uq_system_settings_key"),)

    id:         Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    key:        Mapped[str]  = mapped_column(String(128), nullable=False)
    value:      Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                 default=_now, onupdate=_now)


class RouterRuleOverride(Base):
    """UI-managed router-rule overrides.

    The shipped router rule chain lives in ``policies.yaml`` because the
    ``when:`` clauses are too heterogeneous (max_tokens, has_tools,
    dlp_findings_present, team_budget_used_pct, …) to edit safely from a
    text box. This table only persists two things an operator can change
    safely from the UI:
        * ``enabled``        — toggle a rule off without deleting it (the
                               rule disappears from the post-override chain)
        * ``route_override`` — substitute the rule's target model with
                               another model in the registry (NULL = no
                               override; the YAML's ``route`` wins).

    Keyed by ``rule_name`` (unique). If a YAML rule is renamed, its row
    here becomes orphaned and is silently ignored by ``apply_overrides``.
    """

    __tablename__ = "router_rule_overrides"
    __table_args__ = (UniqueConstraint("rule_name", name="uq_rrov_rule_name"),)

    id:             Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    rule_name:      Mapped[str]  = mapped_column(String(128), nullable=False)
    enabled:        Mapped[bool] = mapped_column(default=True, nullable=False)
    route_override: Mapped[str | None] = mapped_column(String(64))   # NULL = no override
    updated_at:     Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                     default=_now, onupdate=_now)


class LiteLLMModel(Base):
    """A LiteLLM model_list entry, persisted so the admin UI can CRUD it.

    The YAML at ``litellm_config.yaml`` is bootstrap-only — on first boot,
    if this table is empty, the gateway seeds it from the YAML so deployers
    can start with their existing config. After that the DB is the source
    of truth; the LiteLLM Router is rebuilt from this table on every
    create / update / delete via a small reload endpoint.

    ``provider`` is a UI-facing shorthand derived from the litellm "model"
    string (``ollama_chat/...`` -> ``ollama``, ``openrouter/...`` ->
    ``openrouter``, etc.). Useful for badges and grouping; the actual
    routing key is still ``litellm_params['model']``.
    """

    __tablename__ = "litellm_models"
    __table_args__ = (
        UniqueConstraint("model_name", name="uq_litellm_models_name"),
        Index("ix_litellm_models_provider", "provider"),
    )

    id:             Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    model_name:     Mapped[str]  = mapped_column(String(64), nullable=False)
    provider:       Mapped[str]  = mapped_column(String(32), nullable=False)
    enabled:        Mapped[bool] = mapped_column(default=True, nullable=False)
    litellm_params: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    model_info:     Mapped[dict[str, Any] | None] = mapped_column(JSON)
    created_at:     Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at:     Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)


class BudgetSnapshot(Base):
    """Daily roll-up — used for fast dashboard reads. Real-time counters live in Redis."""

    __tablename__ = "budget_snapshots"
    __table_args__ = (
        UniqueConstraint("team_id", "snapshot_date", name="uq_team_date"),
        Index("ix_team_date", "team_id", "snapshot_date"),
    )

    id:            Mapped[int] = mapped_column(Integer, primary_key=True)
    team_id:       Mapped[str] = mapped_column(String(64), index=True)
    snapshot_date: Mapped[str] = mapped_column(String(10))   # YYYY-MM-DD
    tokens_in:     Mapped[int] = mapped_column(BigInteger, default=0)
    tokens_out:    Mapped[int] = mapped_column(BigInteger, default=0)
    cost_usd:      Mapped[float] = mapped_column(Float, default=0.0)
    request_count: Mapped[int] = mapped_column(Integer, default=0)
    updated_at:    Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)


# ---------------------------------------------------------------------------
# Audit DB
# ---------------------------------------------------------------------------
class AuditLog(Base):
    """One row per gateway call. Append-only.

    For records flagged sensitive, ``prompt_ciphertext`` and ``response_ciphertext``
    hold AES-GCM ciphertext (key wrapped by KMS). Plaintext lives nowhere else.
    """

    __tablename__ = "audit_log"
    __table_args__ = (
        Index("ix_audit_user_ts",   "user_id", "ts"),
        Index("ix_audit_team_ts",   "team_id", "ts"),
        Index("ix_audit_model_ts",  "model_used", "ts"),
        Index("ix_audit_verdict",   "verdict"),
        Index("ix_audit_trace_ts",  "trace_id", "ts"),
    )

    id:            Mapped[int]     = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    request_id:    Mapped[str]     = mapped_column(String(64), index=True)
    # Opaque session-trace id from the client (X-Gateway-Trace header). When
    # absent the audit writer defaults this to request_id so every row has a
    # trace; multi-turn IDE sessions (Cline / Continue / aider) reuse the
    # same trace_id across calls so the audit UI can scrub one trace end-to-end.
    trace_id:      Mapped[str | None] = mapped_column(String(64), index=True)
    ts:            Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, index=True)

    user_id:       Mapped[str]     = mapped_column(String(128))
    user_email:    Mapped[str | None] = mapped_column(String(255))
    team_id:       Mapped[str]     = mapped_column(String(64))
    tier:          Mapped[str]     = mapped_column(String(32))
    # When a JIT elevation was active, ``tier`` is the elevated value and
    # ``base_tier`` is the user's normal tier; ``elevation_id`` references
    # the elevation_requests row that authorised the bump. Both NULL when
    # the call ran at the user's default tier.
    base_tier:     Mapped[str | None] = mapped_column(String(32))
    elevation_id:  Mapped[int | None] = mapped_column(BigInteger)

    model_requested: Mapped[str | None] = mapped_column(String(64))
    model_used:      Mapped[str | None] = mapped_column(String(64))
    routing_reason:  Mapped[str | None] = mapped_column(String(255))

    tokens_in:     Mapped[int]     = mapped_column(BigInteger, default=0)
    tokens_out:    Mapped[int]     = mapped_column(BigInteger, default=0)
    latency_ms:    Mapped[float]   = mapped_column(Float, default=0.0)
    cost_usd:      Mapped[float]   = mapped_column(Float, default=0.0)

    # SHA-256 of the canonical prompt / response — safe to expose to platform ops.
    prompt_hash:   Mapped[str | None] = mapped_column(String(64))
    response_hash: Mapped[str | None] = mapped_column(String(64))

    # AES-GCM blobs — only readable via 4-eyes approval flow.
    prompt_ciphertext:   Mapped[bytes | None] = mapped_column()
    response_ciphertext: Mapped[bytes | None] = mapped_column()

    verdict:       Mapped[str]     = mapped_column(String(16), default="allow")
    findings:      Mapped[list | None] = mapped_column(JSON)   # list[Finding] serialised

    client_ip:     Mapped[str | None] = mapped_column(String(64))
    user_agent:    Mapped[str | None] = mapped_column(String(255))
