"""FastAPI entry point.

Exposes:
  POST /v1/chat/completions   OpenAI-compatible chat endpoint (gated)
  GET  /health                liveness
  GET  /ready                 readiness (DB + Redis + at least one router)
  GET  /admin/plugins         list loaded plugins (master-key only)
  GET  /admin/policies        return effective policies.yaml (master-key only)
  GET  /metrics               Prometheus metrics

LiteLLM does the actual inference; we wrap it so we control auth, DLP,
routing, audit and shape the response headers.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

# (Windows event-loop policy + SSL CA bundle bootstrap are set in
#  gateway/__init__.py before uvicorn boots)

import yaml
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from prometheus_client import Counter, Histogram, make_asgi_app

from . import __version__
from .api.admin import router as admin_router
from .auth import require_principal
from .config import get_settings
from .db import Base, gateway_engine, gateway_session
from .hooks.runtime import RefusalError, run_post_call, run_pre_call
from .models import (   # noqa: F401 — imports register tables with Base
    ElevationRequest, Team, UebaAlert, VirtualKey,
)
from .plugins import registry
from .plugins.base import Principal, RequestContext, ResponseContext
from .services import teams as teams_service

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Background audit tasks — survive request cancellation.
# ---------------------------------------------------------------------------
# When a client disconnects mid-stream the request task is cancelled, and
# any DB writes still in flight inherit that cancellation — half-written
# audit rows + warnings from sqlalchemy. We pin background audit tasks to
# a module-level set so they live on the loop independently of the
# cancelled request task. The `add_done_callback` discards each task once
# it finishes, so the set doesn't grow unbounded.
import asyncio as _asyncio_bg
_BACKGROUND_AUDIT_TASKS: set[_asyncio_bg.Task] = set()


def _schedule_background(coro) -> None:
    """Fire-and-forget a coroutine on the running loop while keeping a
    strong reference so the GC doesn't collect the task before it
    finishes. Used for audit writes that must survive a client disconnect."""
    try:
        loop = _asyncio_bg.get_running_loop()
    except RuntimeError:
        log.warning("No running loop — dropping background coro %r", coro)
        return
    task = loop.create_task(coro)
    _BACKGROUND_AUDIT_TASKS.add(task)
    task.add_done_callback(_BACKGROUND_AUDIT_TASKS.discard)


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
REQUEST_COUNT = Counter(
    "gateway_requests_total", "Total chat requests by verdict",
    ["verdict", "model", "team"],
)
REQUEST_LATENCY = Histogram(
    "gateway_request_latency_seconds", "End-to-end gateway latency",
    ["model"],
)
DLP_HITS = Counter(
    "gateway_dlp_hits_total", "DLP findings by kind + severity",
    ["kind", "severity"],
)
TOKENS_TOTAL = Counter(
    "gateway_tokens_total", "Tokens consumed (prompt + completion)",
    ["direction", "model", "team"],          # direction: prompt | completion
)
COST_USD_TOTAL = Counter(
    "gateway_cost_usd_total", "Inference cost in USD",
    ["model", "team"],
)
PLUGIN_LATENCY = Histogram(
    "gateway_plugin_latency_seconds", "Per-plugin hook latency",
    ["plugin", "stage"],                     # stage: pre_call | post_call | audit
    buckets=(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5),
)
UEBA_ALERT_COUNT = Counter(
    "gateway_ueba_alerts_total", "UEBA alerts raised by signal kind + severity",
    ["signal", "severity"],
)
ELEVATION_LOOKUP_FAILED = Counter(
    "gateway_elevation_lookup_failed_total",
    "JIT elevation lookups that fell back to base tier due to a DB error",
)
# Response-cache counters. Incremented lazily by the cache_redis plugin
# (so a build without the plugin loaded is a clean no-op). Exposed here so
# the metric series exist even if the plugin hasn't fired yet.
CACHE_HITS = Counter(
    "gateway_cache_hits_total", "Cache hits", ["model", "team"],
)
CACHE_MISSES = Counter(
    "gateway_cache_misses_total", "Cache misses", ["model", "team"],
)
# Semantic-cache counters. Same shape as the exact-match counters above;
# emitted by the cache_semantic plugin (lazy import, like cache_redis).
SEMANTIC_CACHE_HITS = Counter(
    "gateway_cache_semantic_hits_total", "Semantic cache hits",
    ["model", "team"],
)
SEMANTIC_CACHE_MISSES = Counter(
    "gateway_cache_semantic_misses_total", "Semantic cache misses",
    ["model", "team"],
)
# Single labeled counter for every elevation lifecycle event. Use a single
# series so the SOC can graph one panel and group by event; the cardinality
# is bounded (<= ~10 known event values) so labels are safe.
ELEVATION_EVENTS = Counter(
    "gateway_elevation_events_total",
    "JIT elevation lifecycle events",
    ["event"],
    # event values:
    #   requested          - new request created
    #   duplicate          - refused: user already has an open elevation
    #   burst_limited      - refused: per-user request burst limit hit
    #   invalid_input      - refused: ladder/tier/duration validation failed
    #   approved           - admin approved a pending request
    #   denied             - admin denied a pending request
    #   cancelled          - requester withdrew their own pending request
    #   self_approval_rejected - approver == requester
    #   invalid_transition - approve/deny/cancel from non-pending status
    #                        (also fires when the TOCTOU lock prevents a
    #                        double-decision and the loser sees stale state)
    #   auto_cancelled     - pending TTL exceeded; lazy sweep flipped it
)


# ---------------------------------------------------------------------------
# Lifespan — plugin registry load + LiteLLM warm-up
# ---------------------------------------------------------------------------
def _validate_production_env(settings) -> None:
    """Loud warnings (not hard failures) when the production environment
    is misconfigured. We don't abort startup — a dev-master-key gateway
    that still boots is better than a silently-down one — but every
    operator sees these in the boot log.

    Hard failures live in the readiness probe (/ready) which a load
    balancer / kubelet uses to decide whether to send real traffic.
    """
    if settings.environment != "production":
        return
    warnings: list[str] = []
    if settings.master_key in {"sk-master-dev", "", "changeme"}:
        warnings.append(
            "GATEWAY_MASTER_KEY is the development default. Rotate to a "
            "long random string before exposing this gateway."
        )
    if (settings.redis_url or "memory://").startswith("memory://"):
        warnings.append(
            "GATEWAY_REDIS_URL=memory:// in production — plugin state "
            "(UEBA counters, response cache, rate limits) lives in this "
            "ONE worker. Set GATEWAY_REDIS_URL to a real Redis URL for "
            "HA + multi-worker."
        )
    if settings.jwt_secret in {"dev-only-not-for-prod", "", "changeme"}:
        warnings.append("GATEWAY_JWT_SECRET is the development default.")
    if not (settings.db_url or "").startswith(("postgresql+asyncpg://",
                                                "postgresql+psycopg://")):
        warnings.append(
            f"GATEWAY_DB_URL doesn't look like a Postgres DSN: {settings.db_url!r}"
        )
    if "host.docker.internal" in (settings.db_url or "") \
       or "localhost" in (settings.db_url or ""):
        warnings.append("GATEWAY_DB_URL points at localhost — fine for a "
                        "single-host deploy, but verify this is intentional.")
    for w in warnings:
        log.warning("PROD-CONFIG: %s", w)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    logging.basicConfig(level=settings.log_level)
    _validate_production_env(settings)

    # ---- DB: create operational tables + seed teams from policies.yaml ---
    policies = _load_yaml(settings.policies_path)
    litellm_config = _load_yaml(settings.litellm_config_path)
    from .models import (
        LiteLLMModel, TierConfig, GuardrailPattern, PluginConfig,
        RouterRuleOverride, AuditRevealRequest, SystemSetting,
    )
    from .services import models as models_service
    from .services import tiers as tiers_service
    async with gateway_engine().begin() as conn:
        await conn.run_sync(Base.metadata.create_all,
                            tables=[Team.__table__, VirtualKey.__table__,
                                    UebaAlert.__table__,
                                    ElevationRequest.__table__,
                                    LiteLLMModel.__table__,
                                    TierConfig.__table__,
                                    GuardrailPattern.__table__,
                                    PluginConfig.__table__,
                                    RouterRuleOverride.__table__,
                                    AuditRevealRequest.__table__,
                                    SystemSetting.__table__])
    db_models: list[dict[str, Any]] = []
    async for session in gateway_session():
        try:
            n = await teams_service.seed_from_policies(session, policies)
            if n:
                log.info("teams: seeded/updated %d row(s) from policies.yaml", n)
        except Exception:  # noqa: BLE001
            log.exception("Team seeding failed")
        # First-boot: seed model registry from litellm_config.yaml so the
        # UI starts with the deployer's existing model_list. Idempotent —
        # only seeds when the table is empty; after that the DB is canonical.
        try:
            seeded = await models_service.seed_from_config(session, litellm_config)
            if seeded:
                log.info("models: seeded %d row(s) from litellm_config.yaml", seeded)
        except Exception:  # noqa: BLE001
            log.exception("Model seeding failed")
        # First-boot: seed tier_configs from policies.yaml. Idempotent; we
        # only fill the table when empty so an existing DB stays canonical.
        try:
            n = await tiers_service.seed_from_policies(session, policies)
            if n:
                log.info("tier_configs: seeded %d row(s) from policies.yaml", n)
        except Exception:  # noqa: BLE001
            log.exception("Tier seeding failed")

        # Read back the registry into local vars so we can build the LiteLLM
        # Router + merged policies dict below WITHOUT re-opening another
        # session (a second `async for ... break` after this one was racing
        # the connection pool and stalling the lifespan past the
        # asgi-lifespan 5s timeout).
        try:
            db_models = await models_service.to_router_model_list(session)
        except Exception:  # noqa: BLE001
            log.exception("Reading model registry failed")

        # Build the merged policies dict that plugins see at setup time.
        # The DB overlays the YAML for tier_configs + guardrail_patterns;
        # everything else (teams, router_rules, ueba thresholds) still
        # comes straight from policies.yaml.
        try:
            policies = await _build_merged_policies(session, policies)
        except Exception:  # noqa: BLE001
            log.exception("Building merged policies failed; using YAML as-is")
        break   # only one iteration of the async-generator

    # ---- Plugins --------------------------------------------------------
    log.info("Loading plugins: %s", settings.plugins_list)
    registry.discover_and_load(enabled=settings.plugins_list)

    app_settings: dict[str, Any] = {
        "redis_url":         settings.redis_url,
        "audit_db_url":      settings.audit_db_url,
        "litellm_config":    litellm_config,
        "policies":          policies,
    }
    await registry.setup_all(app_settings)

    # Build the Router from the DB-backed model registry (read above).
    # We use LLMGateway's MIT-only litellm_compat shim — it speaks the same
    # model_list / acompletion / _hidden_params surface our code expects.
    # LiteLLM is no longer a runtime dependency; see README "License posture".
    try:
        from llmgateway.litellm_compat import Router
        from llmgateway import cost as llm_cost
        if db_models:
            app.state.litellm_router = Router(model_list=db_models)
            log.info("LLMGateway Router built from DB (%d enabled model(s))", len(db_models))
            # Seed the cost map from each model's model_info so the response's
            # _hidden_params['response_cost'] returns a real number rather
            # than the default zero. LLMGateway requires explicit prices —
            # the previous LiteLLM bundle was always-on but approximate.
            for entry in db_models:
                info = entry.get("model_info") or {}
                in_per_1k  = info.get("cost_per_1k_input")
                out_per_1k = info.get("cost_per_1k_output")
                if in_per_1k is None or out_per_1k is None:
                    continue
                try:
                    llm_cost.register_model(
                        name=entry["litellm_params"]["model"],
                        input_per_1m=float(in_per_1k) * 1000.0,
                        output_per_1m=float(out_per_1k) * 1000.0,
                    )
                except Exception:                       # noqa: BLE001
                    log.exception("Failed to register cost for %s",
                                  entry.get("model_name"))
        else:
            log.warning("No models in registry — router not initialised")
            app.state.litellm_router = None
    except Exception as e:  # noqa: BLE001
        log.warning("Router init deferred: %s", e)
        app.state.litellm_router = None

    app.state.policies = app_settings["policies"]
    log.info("Gateway ready — version %s, environment %s", __version__, settings.environment)
    yield
    await registry.teardown_all()


app = FastAPI(
    title="LiteLLM Gateway",
    version=__version__,
    description="Policy-oriented AI gateway with a pluggable hook system",
    lifespan=lifespan,
)

# Prometheus / metrics
app.mount("/metrics", make_asgi_app())

# Admin router (teams, keys, plugins, policies)
app.include_router(admin_router)


# ---------------------------------------------------------------------------
# Public routes
# ---------------------------------------------------------------------------
@app.get("/health")
async def health() -> dict[str, Any]:
    return {"status": "ok", "version": __version__}


@app.get("/ready")
async def ready(request: Request) -> JSONResponse:
    """Per-dependency readiness probe.

    Reports the health of every external dependency the gateway needs to
    serve real traffic. Returns 503 if any required dep is down so a
    load balancer / kubelet readiness probe can pull the pod out of
    rotation. Optional deps (Redis when in memory:// mode, Ollama when
    not configured) report 'skipped' instead of failing.

    Shape:
        {
            "ready":   bool,
            "version": str,
            "checks":  {
                "router_plugins":  {"ok": bool, "names": [...]},
                "audit_plugins":   {"ok": bool, "names": [...]},
                "gateway_db":      {"ok": bool, "detail": "..."},
                "audit_db":        {"ok": bool, "detail": "..."},
                "redis":           {"ok": bool, "detail": "...", "skipped": bool},
                "ollama":          {"ok": bool, "detail": "...", "skipped": bool},
                "llm_router":      {"ok": bool, "model_count": N},
            },
            "loaded_plugins": [...],
        }
    """
    from .plugins import PluginKind
    settings = get_settings()
    checks: dict[str, Any] = {}

    # Plugin chain (cheap, in-process).
    router_names = [p.name for p in registry.of_kind(PluginKind.ROUTER)]
    audit_names  = [p.name for p in registry.of_kind(PluginKind.AUDIT)]
    checks["router_plugins"] = {"ok": len(router_names) >= 1, "names": router_names}
    checks["audit_plugins"]  = {"ok": len(audit_names)  >= 1, "names": audit_names}

    from sqlalchemy import text as _sql_text
    # Gateway operational DB.
    try:
        async with gateway_engine().connect() as conn:
            await conn.execute(_sql_text("SELECT 1"))
        checks["gateway_db"] = {"ok": True, "detail": "SELECT 1 succeeded"}
    except Exception as e:                                          # noqa: BLE001
        checks["gateway_db"] = {"ok": False, "detail": f"{type(e).__name__}: {e}"}

    # Audit DB.
    try:
        from sqlalchemy.ext.asyncio import create_async_engine
        ae = create_async_engine(settings.audit_db_url, future=True)
        try:
            async with ae.connect() as conn:
                await conn.execute(_sql_text("SELECT 1"))
        finally:
            await ae.dispose()
        checks["audit_db"] = {"ok": True, "detail": "SELECT 1 succeeded"}
    except Exception as e:                                          # noqa: BLE001
        checks["audit_db"] = {"ok": False, "detail": f"{type(e).__name__}: {e}"}

    # Redis (or in-memory fallback).
    redis_url = settings.redis_url or "memory://"
    if redis_url.startswith("memory://"):
        checks["redis"] = {"ok": True, "skipped": True,
                           "detail": "in-memory mode (single-replica only — set GATEWAY_REDIS_URL for HA)"}
    else:
        try:
            from redis.asyncio import Redis
            client = Redis.from_url(redis_url, decode_responses=True)
            try:
                await client.ping()
            finally:
                await client.aclose()
            checks["redis"] = {"ok": True, "detail": "PING succeeded"}
        except Exception as e:                                      # noqa: BLE001
            checks["redis"] = {"ok": False, "detail": f"{type(e).__name__}: {e}"}

    # Ollama — best-effort. Probe the configured base if set, else skip.
    import os as _os
    ollama_base = (_os.environ.get("OLLAMA_API_BASE") or "").rstrip("/")
    if not ollama_base:
        checks["ollama"] = {"ok": True, "skipped": True,
                            "detail": "OLLAMA_API_BASE not set"}
    else:
        # Strip trailing /v1 so we hit the root health endpoint.
        host = ollama_base[:-3] if ollama_base.endswith("/v1") else ollama_base
        try:
            import httpx
            async with httpx.AsyncClient(timeout=2.0) as h:
                r = await h.get(f"{host}/")
                ok = r.status_code == 200 and "Ollama" in r.text
            checks["ollama"] = {"ok": ok, "detail": f"GET {host}/ returned {r.status_code}"}
        except Exception as e:                                      # noqa: BLE001
            checks["ollama"] = {"ok": False, "detail": f"{type(e).__name__}: {e}"}

    # LLM router built from DB.
    rt = getattr(app.state, "litellm_router", None)
    if rt is None:
        checks["llm_router"] = {"ok": False, "detail": "Router not initialised — no models in registry?"}
    else:
        model_count = len(getattr(rt, "get_model_names", lambda: [])())
        checks["llm_router"] = {"ok": model_count > 0, "model_count": model_count}

    required = ["router_plugins", "audit_plugins", "gateway_db", "audit_db",
                "redis", "ollama", "llm_router"]
    overall_ok = all(checks[name]["ok"] for name in required)
    body: dict[str, Any] = {
        "ready":          overall_ok,
        "version":        __version__,
        "checks":         checks,
        "loaded_plugins": [p.name for p in registry.all()],
    }
    return JSONResponse(content=body, status_code=200 if overall_ok else 503)


@app.get("/v1/models")
@app.get("/models")
async def list_models_openai(
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """OpenAI-compatible model listing.

    Cline, Continue.dev, aider and most "OpenAI-compatible" editor
    integrations probe this endpoint to populate their model picker. We
    return what the gateway exposes (the DB-backed model registry,
    filtered to enabled rows) in OpenAI's canonical shape::

        {"object": "list", "data": [
            {"id": <model_name>, "object": "model",
             "created": <epoch>, "owned_by": "litellm-gateway"},
            ...
        ]}

    Auth is the same as /v1/chat/completions — any valid key (master,
    DB-issued, or sk-dev+... in non-prod). We don't filter to the
    caller's tier here because editor UIs are often pre-flight queries
    before the user picks a model; refusing to list a model the caller
    can't *use* would just confuse the UI. The actual ACL still fires
    at chat-completion time.
    """
    from .services import models as models_service
    async for session in gateway_session():
        rows = await models_service.list_models(session, include_disabled=False)
        break
    created_epoch = int(time.time())
    return {
        "object": "list",
        "data": [
            {
                "id":       r.model_name,
                "object":   "model",
                "created":  created_epoch,
                "owned_by": "litellm-gateway",
                # Non-standard but useful fields for our admin UI clients.
                "provider":      r.provider,
                "model_info":    r.model_info,
            }
            for r in rows
        ],
    }


# Both /v1/chat/completions and /chat/completions are accepted: the OpenAI
# SDK derives the URL from the user's Base URL as ``<base>/chat/completions``
# verbatim, so clients that point at ``http://gateway:4000`` (without /v1)
# would otherwise 404. Aliasing on the server side avoids forcing every
# operator to memorise whether to include /v1.
@app.post("/v1/chat/completions")
@app.post("/chat/completions")
async def chat_completions(request: Request,
                           principal: Principal = Depends(require_principal)):
    """OpenAI-compatible chat endpoint, gated by the plugin chain.

    Returns either:
      * JSONResponse        — non-streaming (default, stream=False)
      * StreamingResponse   — SSE stream when payload["stream"] is True
    """
    payload = await request.json()
    request_id = str(uuid.uuid4())
    # Session-trace grouping: clients (Cline / Continue / aider) send the
    # same opaque value across every call in a session via X-Gateway-Trace.
    # When the header is absent we default to request_id so every row still
    # has a trace_id (single-call traces == request_id; no separate
    # "untraced" branch). Echoed back on the response so a client that didn't
    # send one can pick up the gateway-generated value.
    trace_id = request.headers.get("X-Gateway-Trace") or request_id
    started = time.monotonic()
    wants_stream = payload.get("stream") is True

    ctx = RequestContext(
        request_id=request_id,
        principal=principal,
        model_requested=payload.get("model"),
        messages=payload.get("messages", []),
        tools=payload.get("tools", []),
        extra={
            "client_ip":   request.client.host if request.client else None,
            "user_agent":  request.headers.get("user-agent"),
            "raw_payload": payload,
        },
        trace_id=trace_id,
    )

    # ---- Pre-call: DLP + GUARDRAIL + ROUTER ------------------------------
    try:
        await run_pre_call(ctx)
    except RefusalError as e:
        verdict_label = (
            "rate_limited"     if e.status_code == 429 else
            "budget_exceeded"  if e.status_code == 402 else
            "refused"
        )
        REQUEST_COUNT.labels(verdict_label,
                             ctx.model_requested or "?",
                             principal.team_id).inc()
        # Audit refusals too — never lose visibility on blocked requests.
        await _audit_refusal(ctx, e, started, request_id)
        headers = {"X-Gateway-Request-Id": request_id,
                   "X-Gateway-Trace":      trace_id,
                   **ctx.extra.get("response_headers", {}),
                   **e.extra_headers}
        # NOTE: Pre-call refusals always come back as a regular JSONResponse
        # even if the client asked for stream=True. OpenAI clients (Cline,
        # Continue.dev, aider) all handle non-stream JSON errors fine — and
        # this avoids the awkwardness of having to encode an HTTP status
        # code inside an SSE event.
        return JSONResponse(
            status_code=e.status_code,
            headers=headers,
            content={
                "error": {
                    "code":    e.error_code,
                    "message": e.reason,
                    "plugin":  e.plugin,
                    "findings": [_finding_to_dict(f) for f in e.findings],
                    "request_id": request_id,
                }
            },
        )

    for f in ctx.findings:
        DLP_HITS.labels(kind=f.kind, severity=f.severity).inc()

    # ---- Inference ------------------------------------------------------
    router = app.state.litellm_router
    if router is None:
        REQUEST_COUNT.labels("error", ctx.model_selected, principal.team_id).inc()
        raise HTTPException(status_code=503, detail="LiteLLM router not initialised")

    payload["model"] = ctx.model_selected
    # Use redacted messages if a DLP plugin mutated them.
    payload["messages"] = ctx.messages

    # ---- Streaming branch ----------------------------------------------
    if wants_stream:
        return await _stream_completion(ctx, payload, principal, started, request_id)

    # ---- Response-cache lookup (non-streaming only) ---------------------
    # Looked up after run_pre_call (so refused requests never get cached)
    # and before inference (so a hit short-circuits the round trip). When
    # the plugin isn't loaded this whole block is a no-op.
    cache_plugin = registry.get("cache_redis")
    cache_max_tokens  = payload.get("max_tokens")
    cache_temperature = payload.get("temperature")
    cached: dict[str, Any] | None = None
    if cache_plugin is not None:
        try:
            cached = await cache_plugin.lookup(
                messages=ctx.messages,
                model_requested=ctx.model_selected,
                principal=principal,
                max_tokens=cache_max_tokens,
                temperature=cache_temperature,
                tools=ctx.tools,
            )
        except Exception:  # noqa: BLE001
            log.exception("cache_redis.lookup failed; bypassing cache")
            cached = None

    if cached is not None:
        # Cache HIT: synthesise a ResponseContext and run the post-call
        # chain so audit / observe / output_scan still fire. The body
        # returned to the client is byte-identical to the original.
        cached_usage = cached.get("usage") or {}
        resp_ctx = ResponseContext(
            request_id=request_id,
            principal=principal,
            model_used=ctx.model_selected or "?",
            response=cached,
            latency_ms=(time.monotonic() - started) * 1000,
            tokens_in=int(cached_usage.get("prompt_tokens", 0) or 0),
            tokens_out=int(cached_usage.get("completion_tokens", 0) or 0),
            cost_usd=0.0,                  # cached responses cost nothing
            extra={"client_ip": ctx.extra.get("client_ip"),
                   "user_agent": ctx.extra.get("user_agent"),
                   "messages":   ctx.messages,
                   "cache":      "HIT"},
            findings=list(ctx.findings),
            trace_id=trace_id,
        )
        await run_post_call(resp_ctx)

        REQUEST_COUNT.labels("allow", ctx.model_selected, principal.team_id).inc()
        REQUEST_LATENCY.labels(ctx.model_selected).observe(resp_ctx.latency_ms / 1000)

        headers = {
            "X-LLM-Model-Used":     _ascii_safe(ctx.model_selected or "?"),
            "X-LLM-Routing-Reason": _ascii_safe(ctx.routing_reason or "default"),
            "X-Gateway-Request-Id": request_id,
            "X-Gateway-Trace":      trace_id,
            "X-Cache":              "HIT",
        }
        headers.update(ctx.extra.get("response_headers", {}))
        return JSONResponse(content=cached, headers=headers)

    # ---- Semantic cache lookup (on cache_redis MISS) --------------------
    # Exact-hash cache MISSed — try matching by embedding similarity. A
    # semantic hit on a paraphrase saves the inference round-trip even when
    # the prompt text differs from any prior request. When the plugin isn't
    # loaded / enabled this whole block is a cheap no-op.
    sem_cache = registry.get("cache_semantic")
    sem_cached: dict[str, Any] | None = None
    if (sem_cache is not None and sem_cache.is_enabled()
            and sem_cache.is_cacheable(ctx.messages, cache_temperature,
                                       ctx.tools)):
        try:
            sem_cached = await sem_cache.lookup(
                messages=ctx.messages,
                model_requested=ctx.model_selected,
                principal=principal,
                max_tokens=cache_max_tokens,
                temperature=cache_temperature,
                tools=ctx.tools,
            )
        except Exception:  # noqa: BLE001
            log.exception("cache_semantic.lookup failed; bypassing semantic cache")
            sem_cached = None

    if sem_cached is not None:
        # Semantic HIT — same post-call treatment as an exact HIT, but
        # advertise the difference in the X-Cache header so clients /
        # operators can tell the two apart in logs and dashboards.
        sem_usage = sem_cached.get("usage") or {}
        resp_ctx = ResponseContext(
            request_id=request_id,
            principal=principal,
            model_used=ctx.model_selected or "?",
            response=sem_cached,
            latency_ms=(time.monotonic() - started) * 1000,
            tokens_in=int(sem_usage.get("prompt_tokens", 0) or 0),
            tokens_out=int(sem_usage.get("completion_tokens", 0) or 0),
            cost_usd=0.0,
            extra={"client_ip": ctx.extra.get("client_ip"),
                   "user_agent": ctx.extra.get("user_agent"),
                   "messages":   ctx.messages,
                   "cache":      "HIT-SEMANTIC"},
            findings=list(ctx.findings),
            trace_id=trace_id,
        )
        await run_post_call(resp_ctx)

        REQUEST_COUNT.labels("allow", ctx.model_selected, principal.team_id).inc()
        REQUEST_LATENCY.labels(ctx.model_selected).observe(resp_ctx.latency_ms / 1000)

        headers = {
            "X-LLM-Model-Used":     _ascii_safe(ctx.model_selected or "?"),
            "X-LLM-Routing-Reason": _ascii_safe(ctx.routing_reason or "default"),
            "X-Gateway-Request-Id": request_id,
            "X-Gateway-Trace":      trace_id,
            "X-Cache":              "HIT-SEMANTIC",
        }
        headers.update(ctx.extra.get("response_headers", {}))
        return JSONResponse(content=sem_cached, headers=headers)

    # ---- Non-streaming branch ------------------------------------------
    try:
        completion = await router.acompletion(**payload)
    except Exception as e:  # noqa: BLE001
        log.exception("Inference failure: %s", e)
        REQUEST_COUNT.labels("error", ctx.model_selected, principal.team_id).inc()
        # Write an audit row before raising so "no audit log entry" never
        # silently equals "developer didn't call" — backend failures are
        # operationally relevant signal that SOC + cost dashboards need
        # to see.
        await _audit_inference_error(ctx, str(e), started, request_id,
                                     streaming=False)
        raise HTTPException(status_code=502, detail=f"Backend inference failed: {e}") from e

    completion_dict = completion.model_dump() if hasattr(completion, "model_dump") else dict(completion)

    # ---- Post-call: OUTPUT_SCAN + OBSERVE + AUDIT -----------------------
    usage = completion_dict.get("usage") or {}
    resp_ctx = ResponseContext(
        request_id=request_id,
        principal=principal,
        model_used=ctx.model_selected or "?",
        response=completion_dict,
        latency_ms=(time.monotonic() - started) * 1000,
        tokens_in=int(usage.get("prompt_tokens", 0) or 0),
        tokens_out=int(usage.get("completion_tokens", 0) or 0),
        cost_usd=float(getattr(completion, "_hidden_params", {}).get("response_cost", 0.0) or 0.0),
        extra={"client_ip": ctx.extra.get("client_ip"),
               "user_agent": ctx.extra.get("user_agent"),
               "messages":   ctx.messages},
        findings=list(ctx.findings),
        trace_id=trace_id,
    )
    await run_post_call(resp_ctx)

    REQUEST_COUNT.labels("allow", ctx.model_selected, principal.team_id).inc()
    REQUEST_LATENCY.labels(ctx.model_selected).observe(resp_ctx.latency_ms / 1000)
    TOKENS_TOTAL.labels("prompt",     ctx.model_selected, principal.team_id).inc(resp_ctx.tokens_in)
    TOKENS_TOTAL.labels("completion", ctx.model_selected, principal.team_id).inc(resp_ctx.tokens_out)
    if resp_ctx.cost_usd:
        COST_USD_TOTAL.labels(ctx.model_selected, principal.team_id).inc(resp_ctx.cost_usd)

    # Cache MISS: store the fresh response for next time (best-effort).
    if cache_plugin is not None:
        try:
            await cache_plugin.store(
                messages=ctx.messages,
                model_requested=ctx.model_selected,
                principal=principal,
                max_tokens=cache_max_tokens,
                temperature=cache_temperature,
                response=completion_dict,
                tools=ctx.tools,
            )
        except Exception:  # noqa: BLE001
            log.exception("cache_redis.store failed; response was returned anyway")

    # Also seed the semantic cache so future paraphrases can hit.
    if (sem_cache is not None and sem_cache.is_enabled()
            and sem_cache.is_cacheable(ctx.messages, cache_temperature,
                                       ctx.tools)):
        try:
            await sem_cache.store(
                messages=ctx.messages,
                model_requested=ctx.model_selected,
                principal=principal,
                max_tokens=cache_max_tokens,
                temperature=cache_temperature,
                response=completion_dict,
                tools=ctx.tools,
            )
        except Exception:  # noqa: BLE001
            log.exception("cache_semantic.store failed; response was returned anyway")

    # Transparency headers — never hide the routing.
    # HTTP header values must be Latin-1 encodable; ASCII-fy the routing
    # reason in case policies.yaml contained e.g. "≤" or "→".
    headers = {
        "X-LLM-Model-Used":     _ascii_safe(ctx.model_selected or "?"),
        "X-LLM-Routing-Reason": _ascii_safe(ctx.routing_reason or "default"),
        "X-Gateway-Request-Id": request_id,
        "X-Gateway-Trace":      trace_id,
    }
    if cache_plugin is not None and cache_plugin.is_cacheable(
        ctx.messages, cache_temperature, ctx.tools,
    ):
        headers["X-Cache"] = "MISS"
    headers.update(ctx.extra.get("response_headers", {}))
    return JSONResponse(content=completion_dict, headers=headers)


# ---------------------------------------------------------------------------
# Streaming helper
# ---------------------------------------------------------------------------
# IMPORTANT TRADEOFF — read before you change this:
#   In non-streaming mode the OUTPUT_SCAN plugins run BEFORE the user sees
#   the response, so a leaked-secret finding can scrub the body. In
#   streaming mode the chunks are flushed to the client as they arrive, and
#   OUTPUT_SCAN only runs AFTER the stream completes (against the
#   accumulated content). If output_scan_secrets would have refused the
#   response, the user has ALREADY seen the leaked content — we can log,
#   audit, and alert on it, but we cannot un-send it. The audit row + UEBA
#   alert + Prometheus counters all still fire so the SOC has the same
#   visibility, but there is no in-band redaction for streamed responses.
#   Operators who need hard pre-egress redaction must disable streaming
#   for the affected route at the policy layer.
async def _stream_completion(ctx: RequestContext,
                             payload: dict[str, Any],
                             principal: Principal,
                             started: float,
                             request_id: str) -> StreamingResponse:
    router = app.state.litellm_router
    # The caller's payload already has stream=True; strip it so we can
    # pass stream=True as an explicit kwarg without a TypeError.
    payload = {k: v for k, v in payload.items() if k != "stream"}

    # ---- Streaming cache lookup ---------------------------------------
    # Use the streaming-specific cache namespace (``cache:stream:``) so a
    # previously-cached non-streaming response cannot be served as SSE.
    # On a hit we skip the backend entirely and replay the recorded chunk
    # array exactly as the original stream produced it.
    cache_plugin = registry.get("cache_redis")
    cache_max_tokens  = payload.get("max_tokens")
    cache_temperature = payload.get("temperature")
    cached_chunks: list[dict[str, Any]] | None = None
    if cache_plugin is not None:
        try:
            cached_chunks = await cache_plugin.lookup_stream(
                messages=ctx.messages,
                model_requested=ctx.model_selected,
                principal=principal,
                max_tokens=cache_max_tokens,
                temperature=cache_temperature,
                tools=ctx.tools,
            )
        except Exception:  # noqa: BLE001
            log.exception("cache_redis.lookup_stream failed; bypassing cache")
            cached_chunks = None

    common_headers = {
        "X-LLM-Model-Used":     _ascii_safe(ctx.model_selected or "?"),
        "X-LLM-Routing-Reason": _ascii_safe(ctx.routing_reason or "default"),
        "X-Gateway-Request-Id": request_id,
        "X-Gateway-Trace":      ctx.trace_id or request_id,
        "Cache-Control":        "no-cache",
        "Connection":           "keep-alive",
        "X-Accel-Buffering":    "no",
        **ctx.extra.get("response_headers", {}),
    }

    if cached_chunks is not None:
        # Cache HIT — replay the recorded chunks as a fresh SSE stream and
        # still run the post-call chain (audit / observe) so the SOC sees
        # the cached delivery. cost_usd is 0 because no inference happened.
        return StreamingResponse(
            _replay_cached_stream(ctx, principal, started, request_id,
                                  cached_chunks),
            media_type="text/event-stream",
            headers={**common_headers, "X-Cache": "HIT"},
        )

    try:
        stream = await router.acompletion(stream=True, **payload)
    except Exception as e:  # noqa: BLE001
        log.exception("Streaming inference failure: %s", e)
        REQUEST_COUNT.labels("error", ctx.model_selected, principal.team_id).inc()
        await _audit_inference_error(ctx, str(e), started, request_id,
                                     streaming=True)
        raise HTTPException(status_code=502,
                            detail=f"Backend inference failed: {e}") from e

    async def event_source():
        accumulated_parts: list[str] = []
        final_usage: dict[str, Any] | None = None
        last_chunk_dict: dict[str, Any] | None = None
        captured_chunks: list[dict[str, Any]] = []
        # If we hit the per-stream cap we stop appending but DO NOT abort
        # the stream — the client still gets full bytes; we just skip the
        # cache store at the end. ``store_stream`` also enforces the cap
        # defensively; this avoids ballooning Python memory either way.
        capture_ok = True
        stream_failed = False
        stream_error_msg: str | None = None
        client_disconnect = False
        finalised = False

        async def _finalize():
            """Audit + counter + cache, exactly once.

            Lifted out of the happy path so it ALSO fires on a client
            disconnect (GeneratorExit) or a mid-flight backend error.
            The original bug: this code lived inline after the try/except,
            so a disconnected IDE never got an audit row — operators saw
            'no activity' even though the gateway had already called the
            backend and updated the key's last_used_at. Marking
            `client_disconnect=True` lets ops distinguish 'IDE cut the
            stream' from 'request completed cleanly' in the audit table.
            """
            nonlocal finalised
            if finalised:
                return
            finalised = True

            full_content = "".join(accumulated_parts)
            prompt_chars = sum(
                len(str(m.get("content", ""))) for m in (ctx.messages or [])
            )
            if final_usage:
                tokens_in  = int(final_usage.get("prompt_tokens", 0) or 0)
                tokens_out = int(final_usage.get("completion_tokens", 0) or 0)
            else:
                tokens_in  = max(1, prompt_chars // 4) if prompt_chars else 0
                tokens_out = max(1, len(full_content) // 4) if full_content else 0

            # The verdict the audit plugin will record. `stream_failed`
            # produces an `{"error": ...}` response shape so audit_postgres
            # picks "error" via its existing `_verdict_for` logic;
            # `client_disconnect` is recorded as a clean `allow` with a
            # `truncated=true` flag in extras (the partial content the
            # backend actually generated was real work, just not delivered).
            if stream_failed:
                synthetic_resp: dict[str, Any] = {
                    "error": stream_error_msg or "stream interrupted",
                }
            else:
                synthetic_resp = {
                    "id":      (last_chunk_dict or {}).get("id", f"chatcmpl-{request_id}"),
                    "object":  "chat.completion",
                    "created": (last_chunk_dict or {}).get("created", int(time.time())),
                    "model":   ctx.model_selected,
                    "choices": [{
                        "index": 0,
                        "message": {"role": "assistant", "content": full_content},
                        "finish_reason": "stop" if not client_disconnect else "length",
                    }],
                    "usage": {
                        "prompt_tokens":     tokens_in,
                        "completion_tokens": tokens_out,
                        "total_tokens":      tokens_in + tokens_out,
                    },
                    "_streamed":          True,
                    "_client_disconnect": client_disconnect,
                }

            resp_ctx = ResponseContext(
                request_id=request_id,
                principal=principal,
                model_used=ctx.model_selected or "?",
                response=synthetic_resp,
                latency_ms=(time.monotonic() - started) * 1000,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                cost_usd=0.0,    # streaming cost is plugin-derived
                extra={
                    "client_ip":         ctx.extra.get("client_ip"),
                    "user_agent":        ctx.extra.get("user_agent"),
                    "messages":          ctx.messages,
                    "streamed":          True,
                    "client_disconnect": client_disconnect,
                    "stream_error":      stream_error_msg,
                },
                findings=list(ctx.findings),
                trace_id=ctx.trace_id,
            )
            verdict = "error" if stream_failed else "allow"

            # Synchronous metrics — Prometheus client lib is in-process,
            # not async, so this runs even in a cancelled request.
            REQUEST_COUNT.labels(verdict, ctx.model_selected,
                                 principal.team_id).inc()
            REQUEST_LATENCY.labels(ctx.model_selected).observe(
                resp_ctx.latency_ms / 1000)
            TOKENS_TOTAL.labels("prompt",     ctx.model_selected,
                                principal.team_id).inc(resp_ctx.tokens_in)
            TOKENS_TOTAL.labels("completion", ctx.model_selected,
                                principal.team_id).inc(resp_ctx.tokens_out)
            if resp_ctx.cost_usd:
                COST_USD_TOTAL.labels(ctx.model_selected,
                                      principal.team_id).inc(resp_ctx.cost_usd)

            # Audit + cache writes hit Postgres / Redis — those are async
            # and inherit the task's cancellation if we just `await` here.
            # Scheduling them as orphaned tasks on the loop lets them
            # complete even when the originating request was cancelled
            # (the actual bug operators saw: client-disconnect produced
            # zero audit rows because the in-flight INSERT was killed).
            async def _bg_post_call():
                try:
                    await run_post_call(resp_ctx)
                except Exception:  # noqa: BLE001
                    log.exception(
                        "Post-call chain failed for streamed request %s",
                        request_id,
                    )

            _schedule_background(_bg_post_call())

            # Cache store only on a clean, fully-received stream.
            if (cache_plugin is not None
                    and not stream_failed and not client_disconnect
                    and capture_ok and captured_chunks):
                async def _bg_cache_store():
                    try:
                        await cache_plugin.store_stream(
                            messages=ctx.messages,
                            model_requested=ctx.model_selected,
                            principal=principal,
                            max_tokens=cache_max_tokens,
                            temperature=cache_temperature,
                            chunks=captured_chunks,
                            tools=ctx.tools,
                        )
                    except Exception:  # noqa: BLE001
                        log.exception(
                            "cache_redis.store_stream failed for %s; stream "
                            "delivered anyway", request_id,
                        )
                _schedule_background(_bg_cache_store())

        try:
            try:
                async for chunk in stream:
                    if hasattr(chunk, "model_dump"):
                        chunk_dict = chunk.model_dump()
                    else:
                        try:
                            chunk_dict = dict(chunk)
                        except Exception:  # noqa: BLE001
                            chunk_dict = {"raw": str(chunk)}

                    last_chunk_dict = chunk_dict

                    # Accumulate delta content for post-call hooks.
                    try:
                        choices = chunk_dict.get("choices") or []
                        if choices:
                            delta = choices[0].get("delta") or {}
                            piece = delta.get("content")
                            if piece:
                                accumulated_parts.append(piece)
                    except Exception:  # noqa: BLE001
                        pass

                    # Capture usage if the backend included it on a chunk.
                    u = chunk_dict.get("usage")
                    if u:
                        final_usage = u

                    # Buffer for the post-stream cache store.
                    if capture_ok:
                        cap = getattr(cache_plugin, "MAX_STREAM_CHUNKS", 5000) \
                            if cache_plugin is not None else 5000
                        if len(captured_chunks) >= cap:
                            capture_ok = False
                        else:
                            captured_chunks.append(chunk_dict)

                    yield f"data: {json.dumps(chunk_dict)}\n\n"

                yield "data: [DONE]\n\n"
            except GeneratorExit:
                # Client closed the connection mid-stream. Mark the
                # outcome and propagate — Starlette uses GeneratorExit to
                # signal disconnect; we must re-raise so the framework's
                # cleanup completes properly.
                client_disconnect = True
                raise
            except Exception as e:  # noqa: BLE001
                log.exception("Stream interrupted mid-flight: %s", e)
                stream_failed = True
                stream_error_msg = str(e)
                err_evt = {
                    "error": {
                        "code":    "stream_failed",
                        "message": stream_error_msg,
                        "request_id": request_id,
                    }
                }
                try:
                    yield f"data: {json.dumps(err_evt)}\n\n"
                    yield "data: [DONE]\n\n"
                except Exception:  # noqa: BLE001
                    pass
        finally:
            # Always finalise. Async generators receive GeneratorExit via
            # `aclose()` which DOES allow awaits in `finally` (PEP 533).
            try:
                await _finalize()
            except Exception:  # noqa: BLE001
                log.exception("Stream finalisation failed for %s", request_id)

    headers = dict(common_headers)
    if (cache_plugin is not None and cache_plugin.is_cacheable(
            ctx.messages, cache_temperature, ctx.tools)):
        headers["X-Cache"] = "MISS"
    return StreamingResponse(
        event_source(),
        media_type="text/event-stream",
        headers=headers,
    )


async def _replay_cached_stream(ctx: RequestContext,
                                principal: Principal,
                                started: float,
                                request_id: str,
                                chunks: list[dict[str, Any]]):
    """Yield cached chunks as SSE, then run the post-call chain.

    The shape is byte-for-byte the same as a live stream — same ``data: ``
    framing, same ``[DONE]`` sentinel — so the client cannot tell a cache
    HIT from a fresh inference (other than the ``X-Cache: HIT`` response
    header). After the final event we still run post_call so audit /
    observe / output_scan_secrets all see the request, with cost_usd
    pinned to 0 because no model was billed.
    """
    accumulated_parts: list[str] = []
    final_usage: dict[str, Any] | None = None
    last_chunk_dict: dict[str, Any] | None = None
    for chunk_dict in chunks:
        last_chunk_dict = chunk_dict
        try:
            choices = chunk_dict.get("choices") or []
            if choices:
                delta = choices[0].get("delta") or {}
                piece = delta.get("content")
                if piece:
                    accumulated_parts.append(piece)
        except Exception:  # noqa: BLE001
            pass
        u = chunk_dict.get("usage")
        if u:
            final_usage = u
        yield f"data: {json.dumps(chunk_dict)}\n\n"
    yield "data: [DONE]\n\n"

    full_content = "".join(accumulated_parts)
    prompt_chars = sum(
        len(str(m.get("content", ""))) for m in (ctx.messages or [])
    )
    if final_usage:
        tokens_in  = int(final_usage.get("prompt_tokens", 0) or 0)
        tokens_out = int(final_usage.get("completion_tokens", 0) or 0)
    else:
        tokens_in  = max(1, prompt_chars // 4) if prompt_chars else 0
        tokens_out = max(1, len(full_content) // 4) if full_content else 0

    synthetic = {
        "id":      (last_chunk_dict or {}).get("id", f"chatcmpl-{request_id}"),
        "object":  "chat.completion",
        "created": (last_chunk_dict or {}).get("created", int(time.time())),
        "model":   ctx.model_selected,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": full_content},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens":     tokens_in,
            "completion_tokens": tokens_out,
            "total_tokens":      tokens_in + tokens_out,
        },
        "_streamed":   True,
        "_cache_hit":  True,
    }

    resp_ctx = ResponseContext(
        request_id=request_id,
        principal=principal,
        model_used=ctx.model_selected or "?",
        response=synthetic,
        latency_ms=(time.monotonic() - started) * 1000,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        cost_usd=0.0,   # cache hit → no model spend
        extra={"client_ip":   ctx.extra.get("client_ip"),
               "user_agent":  ctx.extra.get("user_agent"),
               "messages":    ctx.messages,
               "streamed":    True,
               "cache":       "HIT"},
        findings=list(ctx.findings),
        trace_id=ctx.trace_id,
    )
    try:
        await run_post_call(resp_ctx)
    except Exception:  # noqa: BLE001
        log.exception("Post-call chain failed for cached stream %s",
                      request_id)

    REQUEST_COUNT.labels("allow", ctx.model_selected,
                         principal.team_id).inc()
    REQUEST_LATENCY.labels(ctx.model_selected).observe(
        resp_ctx.latency_ms / 1000)
    TOKENS_TOTAL.labels("prompt",     ctx.model_selected,
                        principal.team_id).inc(resp_ctx.tokens_in)
    TOKENS_TOTAL.labels("completion", ctx.model_selected,
                        principal.team_id).inc(resp_ctx.tokens_out)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _finding_to_dict(f) -> dict[str, Any]:
    return {
        "plugin":   f.plugin,
        "kind":     f.kind,
        "severity": f.severity,
        "message":  f.message,
        "redacted": f.redacted,
    }


async def _build_merged_policies(session, base_policies: dict[str, Any]) -> dict[str, Any]:
    """Overlay DB-side overrides on top of the YAML policies.

    Tier rows replace ``policies.tiers`` entirely when ANY row exists (since
    the DB was seeded from YAML on first boot, "any row" means "operator
    accepted DB as canonical"). Guardrail extras append to the YAML lists
    rather than replace, so the baseline injection patterns shipped in the
    plugin keep working alongside operator-added terms.
    """
    from .services import tiers as tiers_service
    from .services import guardrails as guardrails_service
    from .services import plugin_configs as plugin_configs_service
    from .services import router_rules as router_rules_service
    merged = dict(base_policies or {})

    db_tiers = await tiers_service.as_policy_tiers_dict(session)
    if db_tiers:
        merged["tiers"] = db_tiers

    gx = await guardrails_service.as_guardrails_overlay(session)
    yaml_gr = dict(merged.get("guardrails") or {})
    for section, overlay in gx.items():
        cur = dict(yaml_gr.get(section) or {})
        for key, val in overlay.items():
            if isinstance(val, list):
                cur[key] = list(cur.get(key) or []) + val
            else:
                cur[key] = val
        yaml_gr[section] = cur
    merged["guardrails"] = yaml_gr

    osx = await guardrails_service.as_output_scan_overlay(session)
    yaml_os = dict(merged.get("output_scan") or {})
    for section, overlay in osx.items():
        cur = dict(yaml_os.get(section) or {})
        for key, val in overlay.items():
            if isinstance(val, list):
                cur[key] = list(cur.get(key) or []) + val
            else:
                cur[key] = val
        yaml_os[section] = cur
    merged["output_scan"] = yaml_os

    # Plugin-specific overrides (cache TTL, UEBA thresholds, output-scan
    # action, guardrail actions). apply_overrides returns a fresh dict.
    try:
        merged = await plugin_configs_service.apply_overrides(session, merged)
    except Exception:                                              # noqa: BLE001
        log.exception("plugin-config overlay failed; using YAML-only policies")

    # Router-rule overrides — drop disabled rules + substitute route targets.
    # Applied AFTER plugin-config overlays so the router_rule_based plugin
    # sees the post-override chain at setup time.
    try:
        merged["router_rules"] = await router_rules_service.apply_overrides(
            session, list(merged.get("router_rules") or []),
        )
    except Exception:                                              # noqa: BLE001
        log.exception("router-rule overlay failed; using YAML-only rules")

    return merged


async def reload_policy_consumers() -> dict[str, Any]:
    """Re-run setup() on plugins that read policies, with the latest merged
    dict. Called by admin CUD endpoints after they write to the DB so the
    in-process gateway picks up the change without a process restart.

    Returns a small payload the admin endpoint can echo to the UI so the
    operator gets immediate confirmation.
    """
    settings = get_settings()
    base = _load_yaml(settings.policies_path)
    merged: dict[str, Any] = base
    async for session in gateway_session():
        merged = await _build_merged_policies(session, base)
        break

    app_settings: dict[str, Any] = {
        "redis_url":      settings.redis_url,
        "audit_db_url":   settings.audit_db_url,
        "litellm_config": _load_yaml(settings.litellm_config_path),
        "policies":       merged,
    }
    reloaded: list[str] = []
    # Re-setup plugins that consume policies. Others are stateless re: policy
    # dict and don't need reload (e.g. quota_redis reads tiers via principal
    # tier on every request).
    target_names = {"authz_tiered", "guardrail_patterns", "router_rule_based",
                    "output_scan_secrets", "observe_ueba", "quota_redis",
                    "cache_redis", "cache_semantic", "siem_forward"}
    for p in registry.all():
        if p.name in target_names:
            try:
                await p.setup(app_settings)
                reloaded.append(p.name)
            except Exception:                                  # noqa: BLE001
                log.exception("Reload failed for plugin %s", p.name)

    # Refresh app.state.policies so admin endpoints that read the live merged
    # policies dict (e.g. /admin/policies) see the new state without restart.
    try:
        app.state.policies = merged
    except Exception:                                          # noqa: BLE001
        log.exception("Failed to refresh app.state.policies after reload")
    return {"ok": True, "reloaded": reloaded,
            "tiers": len((merged.get("tiers") or {})),
            "banned_topics": len(((merged.get("guardrails") or {})
                                  .get("banned_topics") or {}).get("keywords") or []),
            "dlp_extra_patterns": len(((merged.get("guardrails") or {})
                                  .get("prompt_injection") or {}).get("extra_patterns") or []),
            "output_scan_extra_patterns": len(((merged.get("output_scan") or {})
                                  .get("secrets") or {}).get("extra_patterns") or [])}


def _load_yaml(path) -> dict[str, Any]:
    try:
        with open(path) as fh:
            return yaml.safe_load(fh) or {}
    except FileNotFoundError:
        log.warning("Config file %s not found — using empty config", path)
        return {}


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


_ASCII_REPLACEMENTS = {
    "≤": "<=",   # ≤
    "≥": ">=",   # ≥
    "→": "->",   # →
    "←": "<-",   # ←
    "•": "*",    # •
    "—": "-",    # —
    "–": "-",    # –
    "·": ".",    # ·
}


def _ascii_safe(value: str) -> str:
    """Make a string Latin-1 safe for HTTP header values."""
    out = value
    for src, dst in _ASCII_REPLACEMENTS.items():
        out = out.replace(src, dst)
    # Final defensive pass — replace anything still outside Latin-1.
    return out.encode("latin-1", errors="replace").decode("latin-1")


async def _audit_inference_error(ctx: RequestContext, error: str,
                                 started: float, request_id: str,
                                 *, streaming: bool) -> None:
    """Write an audit row for a request that failed AT the inference stage
    (backend 4xx / 5xx, network error, mid-stream provider error). Without
    this, failed calls leave no trace in audit_log — and "no audit row"
    looks indistinguishable from "developer never tried", which broke a
    real incident investigation (operator searched the log for a user's
    activity and saw nothing despite a live key with recent last_used_at).

    Verdict label is ``error`` so audit / spend dashboards distinguish
    these from clean allows or policy refusals.
    """
    err_resp = ResponseContext(
        request_id=request_id,
        principal=ctx.principal,
        model_used=ctx.model_selected or "(error-mid-inference)",
        response={"error": error},
        latency_ms=(time.monotonic() - started) * 1000,
        tokens_in=0,
        tokens_out=0,
        cost_usd=0.0,
        extra={
            "client_ip":       ctx.extra.get("client_ip"),
            "user_agent":      ctx.extra.get("user_agent"),
            "messages":        ctx.messages,
            "routing_reason":  ctx.routing_reason or "ERROR",
            "model_requested": ctx.model_requested,
            "verdict_override": "error",
            "streaming":       streaming,
        },
        findings=list(ctx.findings),
        trace_id=ctx.trace_id,
    )
    try:
        await run_post_call(err_resp)
    except Exception as ee:  # noqa: BLE001
        log.exception("Error post-call chain failed: %s", ee)


async def _audit_refusal(ctx: RequestContext, e: RefusalError, started: float,
                         request_id: str) -> None:
    """Run the FULL post-call chain on a refusal so OBSERVE (UEBA) and AUDIT
    plugins all see the blocked request. OUTPUT_SCAN plugins receive a
    response with no ``choices`` and skip cleanly."""
    refusal_resp = ResponseContext(
        request_id=request_id,
        principal=ctx.principal,
        model_used=ctx.model_selected or "(refused-pre-routing)",
        response={"error": e.reason, "plugin": e.plugin,
                  "findings": [_finding_to_dict(f) for f in e.findings]},
        latency_ms=(time.monotonic() - started) * 1000,
        tokens_in=0,
        tokens_out=0,
        cost_usd=0.0,
        extra={
            "client_ip":      ctx.extra.get("client_ip"),
            "user_agent":     ctx.extra.get("user_agent"),
            "messages":       ctx.messages,
            "routing_reason": "REFUSED",
            "model_requested": ctx.model_requested,
        },
        findings=[*ctx.findings, *e.findings],
        trace_id=ctx.trace_id,
    )
    try:
        await run_post_call(refusal_resp)
    except Exception as ee:  # noqa: BLE001
        log.exception("Refusal post-call chain failed: %s", ee)
