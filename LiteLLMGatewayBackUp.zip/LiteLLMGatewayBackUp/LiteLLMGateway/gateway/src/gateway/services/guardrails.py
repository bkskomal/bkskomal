"""UI-managed guardrail / DLP / output-scan extras.

Each plugin ships with a baseline regex set. This service holds operator
additions (banned terms, custom DLP regex, custom secret detectors) so the
SOC can add new patterns without a YAML edit + git PR.

The three plugins consume DB rows of these kinds:
    * banned_topic       -> guardrail_patterns (banned_topics.keywords)
    * dlp_extra          -> guardrail_patterns (prompt_injection.extra_patterns)
    * output_scan_extra  -> output_scan_secrets (extra_patterns)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import GuardrailPattern


VALID_KINDS = {"banned_topic", "dlp_extra", "output_scan_extra"}
VALID_SEVERITIES = {"info", "low", "warn", "high", "critical"}
VALID_ACTIONS = {"refuse", "warn", "redact"}


@dataclass(frozen=True)
class PatternRecord:
    id: int
    kind: str
    name: str
    pattern: str
    severity: str
    action: str
    is_active: bool
    created_by: Optional[str]
    notes: Optional[str]
    created_at: datetime
    updated_at: datetime


class GuardrailError(Exception): ...
class PatternNotFoundError(GuardrailError): ...


async def list_patterns(session: AsyncSession,
                        *, kind: Optional[str] = None,
                        include_inactive: bool = True) -> list[PatternRecord]:
    q = select(GuardrailPattern).order_by(
        GuardrailPattern.kind, GuardrailPattern.name)
    if kind is not None:
        q = q.where(GuardrailPattern.kind == kind)
    if not include_inactive:
        q = q.where(GuardrailPattern.is_active.is_(True))
    rows = (await session.execute(q)).scalars().all()
    return [_to_record(r) for r in rows]


async def create_pattern(
    session: AsyncSession,
    *,
    kind: str,
    name: str,
    pattern: str,
    severity: str = "warn",
    action: str = "refuse",
    is_active: bool = True,
    created_by: Optional[str] = None,
    notes: Optional[str] = None,
) -> PatternRecord:
    _validate(kind=kind, severity=severity, action=action, pattern=pattern, name=name)
    row = GuardrailPattern(
        kind=kind, name=name, pattern=pattern,
        severity=severity, action=action, is_active=is_active,
        created_by=created_by, notes=notes,
    )
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def update_pattern(
    session: AsyncSession,
    pattern_id: int,
    *,
    name: Optional[str] = None,
    pattern: Optional[str] = None,
    severity: Optional[str] = None,
    action: Optional[str] = None,
    is_active: Optional[bool] = None,
    notes: Optional[str] = None,
) -> PatternRecord:
    row = (await session.execute(
        select(GuardrailPattern).where(GuardrailPattern.id == pattern_id)
    )).scalar_one_or_none()
    if row is None:
        raise PatternNotFoundError(f"Pattern id={pattern_id} not found")
    if name is not None:
        _validate(name=name)
        row.name = name
    if pattern is not None:
        _validate(pattern=pattern)
        row.pattern = pattern
    if severity is not None:
        _validate(severity=severity)
        row.severity = severity
    if action is not None:
        _validate(action=action)
        row.action = action
    if is_active is not None:
        row.is_active = bool(is_active)
    if notes is not None:
        row.notes = notes
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def delete_pattern(session: AsyncSession, pattern_id: int) -> bool:
    result = await session.execute(
        delete(GuardrailPattern).where(GuardrailPattern.id == pattern_id))
    await session.commit()
    return (result.rowcount or 0) > 0


# ---------------------------------------------------------------------------
# Plugin-facing merge helpers — used by main.py to overlay DB rows on the
# guardrails / output_scan sections of the loaded policies dict.
# ---------------------------------------------------------------------------
async def as_guardrails_overlay(session: AsyncSession) -> dict[str, Any]:
    """Return a partial ``policies.guardrails`` overlay derived from DB rows.

    Banned topics from the DB are MERGED with whatever's already in YAML;
    extra DLP patterns are appended. The plugin overwrites its in-memory
    state from this merged dict on reload.
    """
    rows = await list_patterns(session, include_inactive=False)
    banned: list[str] = []
    dlp_extra: list[dict[str, Any]] = []
    for r in rows:
        if r.kind == "banned_topic":
            banned.append(r.pattern)
        elif r.kind == "dlp_extra":
            dlp_extra.append({
                "name": r.name, "regex": r.pattern,
                "severity": r.severity, "action": r.action,
            })
    return {
        "banned_topics":     {"keywords":       banned},
        "prompt_injection":  {"extra_patterns": dlp_extra},
    }


async def as_output_scan_overlay(session: AsyncSession) -> dict[str, Any]:
    """Return a partial ``policies.output_scan`` overlay from DB rows."""
    rows = await list_patterns(session, include_inactive=False)
    extras = [
        {"name": r.name, "regex": r.pattern, "severity": r.severity}
        for r in rows if r.kind == "output_scan_extra"
    ]
    return {"secrets": {"extra_patterns": extras}}


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def _validate(*, kind: Optional[str] = None,
              name: Optional[str] = None,
              pattern: Optional[str] = None,
              severity: Optional[str] = None,
              action: Optional[str] = None) -> None:
    if kind is not None and kind not in VALID_KINDS:
        raise GuardrailError(f"kind must be one of {sorted(VALID_KINDS)}")
    if name is not None and (not name.strip() or len(name) > 128):
        raise GuardrailError("name must be 1..128 chars")
    if pattern is not None:
        if not pattern.strip():
            raise GuardrailError("pattern cannot be empty")
        # Compile-check so an operator can't ship a broken regex.
        try:
            re.compile(pattern)
        except re.error as e:
            raise GuardrailError(f"invalid regex: {e}") from e
    if severity is not None and severity not in VALID_SEVERITIES:
        raise GuardrailError(f"severity must be one of {sorted(VALID_SEVERITIES)}")
    if action is not None and action not in VALID_ACTIONS:
        raise GuardrailError(f"action must be one of {sorted(VALID_ACTIONS)}")


def _to_record(row: GuardrailPattern) -> PatternRecord:
    return PatternRecord(
        id=row.id, kind=row.kind, name=row.name, pattern=row.pattern,
        severity=row.severity, action=row.action, is_active=bool(row.is_active),
        created_by=row.created_by, notes=row.notes,
        created_at=row.created_at, updated_at=row.updated_at,
    )
