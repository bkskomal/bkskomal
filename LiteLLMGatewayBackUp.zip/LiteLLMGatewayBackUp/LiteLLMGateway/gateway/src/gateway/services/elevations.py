"""Just-In-Time elevation service.

A developer requests a temporary tier upgrade (e.g. L1_standard → L2_senior
to use Kimi for a specific task). A different platform engineer approves the
request, which sets ``status='approved'`` and stamps ``expires_at``. The auth
resolver then treats the requester as L2_senior until ``expires_at``, after
which it falls back to the team's default tier.

Invariants enforced here (not just at the API boundary):

* The approver cannot be the requester (dual-control).
* A user can have at most ONE pending or active elevation at a time.
* ``requested_tier`` must be a known tier the policy file lists.
* ``duration_minutes`` is clamped to [15, 60*24] (15 min .. 24 h).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import and_, desc, func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import ElevationRequest


# ---------------------------------------------------------------------------
# DTOs
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ElevationRecord:
    id: int
    user_id: str
    user_email: Optional[str]
    team_id: str
    base_tier: str
    requested_tier: str
    duration_minutes: int
    reason: str
    status: str
    requested_at: datetime
    decided_at: Optional[datetime]
    expires_at: Optional[datetime]
    approver_user_id: Optional[str]
    decision_note: Optional[str]


# ---------------------------------------------------------------------------
# Domain errors
# ---------------------------------------------------------------------------
class ElevationError(Exception):
    """Base for service-layer errors. API layer maps to 4xx codes."""


class DuplicateRequestError(ElevationError):
    """The user already has a pending or active elevation."""


class SelfApprovalError(ElevationError):
    """The approver is the requester."""


class InvalidTransitionError(ElevationError):
    """Tried to act on an elevation in the wrong status."""


class RequestBurstError(ElevationError):
    """The user has submitted too many elevation requests in the burst window.

    Distinct from DuplicateRequestError: duplicate is "you already have an open
    one", burst is "you're hammering /elevation/request — back off". The API
    layer maps this to 429 rather than 409 so clients implement retry-after
    correctly instead of treating it as a permanent state conflict.
    """


# ---------------------------------------------------------------------------
# Public service functions
# ---------------------------------------------------------------------------
JIT_LADDER       = ["L0_readonly", "L1_standard", "L2_senior", "L3_privileged"]
JIT_BLOCKED_TIERS = {"L3_privileged", "quarantined"}

# Lazily auto-cancel pending requests older than this. Without a sweep an
# unattended pending row blocks the requester forever via the duplicate check.
PENDING_TTL_HOURS = 24

# Per-user burst limit on /elevation/request. Counts ALL attempts (any status)
# in the window so cancel-and-retry can't bypass it.
REQUEST_BURST_LIMIT         = 5
REQUEST_BURST_WINDOW_HOURS  = 1


async def request_elevation(
    session: AsyncSession,
    *,
    user_id: str,
    user_email: Optional[str],
    team_id: str,
    base_tier: str,
    requested_tier: str,
    duration_minutes: int,
    reason: str,
    allowed_tiers: list[str] | None = None,
) -> ElevationRecord:
    """Create a pending elevation request, refusing duplicates.

    Ordering of checks (the comments here justify the order; do not reshuffle
    without re-reading):

    1. Burst-rate refused FIRST — DoS protection must reject before any
       expensive work or DB writes happen.
    2. Stale-pending sweep — auto-cancel forgotten pending rows so they don't
       falsely block step 3.
    3. Duplicate-block — so a user with an open request is told that BEFORE
       being nudged about input validation problems.
    4. Validation of the new request.
    """
    try:
        await _check_request_burst(session, user_id)
    except RequestBurstError:
        _emit("burst_limited")
        await _record_ueba(
            user_id=user_id, team_id=team_id, tier=base_tier,
            signal="elevation_burst_rejections",
        )
        raise
    await _sweep_stale_pending(session, user_id=user_id)

    # Block early if the user already has a pending or active elevation.
    existing = await _existing_open(session, user_id)
    if existing is not None:
        _emit("duplicate")
        raise DuplicateRequestError(
            f"User {user_id!r} already has an open elevation (id={existing.id}, "
            f"status={existing.status!r})"
        )

    def _invalid(msg: str) -> "ElevationError":
        _emit("invalid_input")
        return ElevationError(msg)

    if requested_tier == base_tier:
        raise _invalid("requested_tier must differ from base_tier")
    if allowed_tiers is not None and requested_tier not in allowed_tiers:
        raise _invalid(f"requested_tier {requested_tier!r} is not in policies.yaml")
    # L3_privileged is a permanent, named-engineer-only tier; JIT must never
    # produce it. quarantined makes no sense as a target.
    if requested_tier in JIT_BLOCKED_TIERS:
        raise _invalid(
            f"requested_tier {requested_tier!r} cannot be granted via JIT; "
            "must be permanently assigned by an administrator"
        )
    # Ladder rule — only one rung up per request. Prevents an L0 intern from
    # social-engineering an approver into one click that grants L2/L3 access.
    try:
        b = JIT_LADDER.index(base_tier)
        r = JIT_LADDER.index(requested_tier)
    except ValueError:
        # Either tier is not on the standard ladder (e.g. test_tight) — let
        # the policies.yaml check above own that decision, no ladder rule.
        b = r = -1
    if b >= 0 and (r <= b or r - b > 1):
        raise _invalid(
            f"JIT elevation only allows one tier up at a time: "
            f"{base_tier} → {requested_tier} not permitted"
        )
    if not (15 <= duration_minutes <= 60 * 24):
        raise _invalid("duration_minutes must be between 15 and 1440")
    if not reason.strip():
        raise _invalid("reason cannot be empty")

    row = ElevationRequest(
        user_id=user_id,
        user_email=user_email,
        team_id=team_id,
        base_tier=base_tier,
        requested_tier=requested_tier,
        duration_minutes=duration_minutes,
        reason=reason.strip(),
        status="pending",
    )
    session.add(row)
    await session.commit()
    await session.refresh(row)
    _emit("requested")
    return _to_record(row)


async def approve(
    session: AsyncSession,
    *,
    elevation_id: int,
    approver_user_id: str,
    decision_note: Optional[str] = None,
) -> ElevationRecord:
    row = await _get(session, elevation_id, for_update=True)
    if row.status != "pending":
        _emit("invalid_transition")
        raise InvalidTransitionError(f"Cannot approve from status {row.status!r}")
    if row.user_id == approver_user_id:
        _emit("self_approval_rejected")
        await _record_ueba(
            user_id=row.user_id, team_id=row.team_id, tier=row.base_tier,
            signal="elevation_self_approval_attempts",
        )
        raise SelfApprovalError("Approver cannot be the requester")

    now = _now()
    row.status            = "approved"
    row.decided_at        = now
    row.approver_user_id  = approver_user_id
    row.decision_note     = (decision_note or "").strip() or None
    row.expires_at        = now + timedelta(minutes=row.duration_minutes)
    await session.commit()
    await session.refresh(row)
    _emit("approved")
    return _to_record(row)


async def deny(
    session: AsyncSession,
    *,
    elevation_id: int,
    approver_user_id: str,
    decision_note: Optional[str] = None,
) -> ElevationRecord:
    row = await _get(session, elevation_id, for_update=True)
    if row.status != "pending":
        _emit("invalid_transition")
        raise InvalidTransitionError(f"Cannot deny from status {row.status!r}")
    if row.user_id == approver_user_id:
        _emit("self_approval_rejected")
        await _record_ueba(
            user_id=row.user_id, team_id=row.team_id, tier=row.base_tier,
            signal="elevation_self_approval_attempts",
        )
        raise SelfApprovalError("Approver cannot be the requester")

    row.status           = "denied"
    row.decided_at       = _now()
    row.approver_user_id = approver_user_id
    row.decision_note    = (decision_note or "").strip() or None
    await session.commit()
    await session.refresh(row)
    _emit("denied")
    return _to_record(row)


async def cancel(
    session: AsyncSession,
    *,
    elevation_id: int,
    user_id: str,
) -> ElevationRecord:
    """Requester withdraws a still-pending request."""
    row = await _get(session, elevation_id, for_update=True)
    if row.user_id != user_id:
        _emit("invalid_transition")
        raise InvalidTransitionError("Only the requester can cancel")
    if row.status != "pending":
        _emit("invalid_transition")
        raise InvalidTransitionError(f"Cannot cancel from status {row.status!r}")
    row.status     = "cancelled"
    row.decided_at = _now()
    await session.commit()
    await session.refresh(row)
    _emit("cancelled")
    return _to_record(row)


async def active_tier_for(session: AsyncSession, user_id: str) -> Optional[str]:
    """Return the elevated tier currently in force for ``user_id``, or None.

    Convenience wrapper around :func:`active_for` for callers that only
    need the tier string.
    """
    rec = await active_for(session, user_id)
    return rec.requested_tier if rec else None


async def active_for(session: AsyncSession, user_id: str) -> Optional[ElevationRecord]:
    """Return the full active elevation record for ``user_id`` (or None).

    Used by ``auth.require_principal`` so the resolved Principal carries
    ``elevation_id``, letting audit / UEBA distinguish elevated calls.
    """
    now = _now()
    stmt = (
        select(ElevationRequest)
        .where(
            ElevationRequest.user_id == user_id,
            ElevationRequest.status == "approved",
            ElevationRequest.expires_at != None,    # noqa: E711
            ElevationRequest.expires_at > now,
        )
        .order_by(desc(ElevationRequest.requested_at))
        .limit(1)
    )
    row = (await session.execute(stmt)).scalar_one_or_none()
    return _to_record(row) if row else None


async def list_pending(session: AsyncSession, limit: int = 100) -> list[ElevationRecord]:
    """Pending elevations younger than PENDING_TTL_HOURS.

    Stale-pending rows are excluded so an admin can't accidentally approve a
    request the user forgot about days ago. They get auto-cancelled lazily
    the next time the requester invokes ``request_elevation``.
    """
    cutoff = _now() - timedelta(hours=PENDING_TTL_HOURS)
    rows = (await session.execute(
        select(ElevationRequest)
        .where(
            ElevationRequest.status == "pending",
            ElevationRequest.requested_at >= cutoff,
        )
        .order_by(desc(ElevationRequest.requested_at))
        .limit(limit)
    )).scalars().all()
    return [_to_record(r) for r in rows]


async def list_for_user(session: AsyncSession, user_id: str,
                        limit: int = 50) -> list[ElevationRecord]:
    rows = (await session.execute(
        select(ElevationRequest)
        .where(ElevationRequest.user_id == user_id)
        .order_by(desc(ElevationRequest.requested_at))
        .limit(limit)
    )).scalars().all()
    return [_to_record(r) for r in rows]


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
async def _get(session: AsyncSession, elevation_id: int,
               *, for_update: bool = False) -> ElevationRequest:
    """Load a single row by id.

    ``for_update=True`` issues ``SELECT ... FOR UPDATE``, which row-locks the
    matched elevation until the surrounding transaction commits / rolls back.
    Mutating paths (approve / deny / cancel) MUST use this — otherwise two
    concurrent admins could both see ``status='pending'`` before either
    commits, both flip it to their decision, and the latter silently
    overwrites the former's approver_user_id without raising.
    """
    stmt = select(ElevationRequest).where(ElevationRequest.id == elevation_id)
    if for_update:
        stmt = stmt.with_for_update()
    row = (await session.execute(stmt)).scalar_one_or_none()
    if row is None:
        raise ElevationError(f"Elevation id={elevation_id} not found")
    return row


async def _sweep_stale_pending(session: AsyncSession,
                               *, user_id: Optional[str] = None) -> int:
    """Auto-cancel pending elevations older than ``PENDING_TTL_HOURS``.

    Pending rows have no other expiry path — without this, a pending request
    a user submitted and forgot about would block them from ever submitting
    another via the duplicate check. Called eagerly inside ``request_elevation``
    so the requester's own stale rows are cleaned before the duplicate-block.

    Scoping to a single user_id is preferred so we don't mutate global state
    on someone else's request; sweep-all is available for an admin job.
    """
    cutoff = _now() - timedelta(hours=PENDING_TTL_HOURS)
    stmt = (
        update(ElevationRequest)
        .where(
            ElevationRequest.status == "pending",
            ElevationRequest.requested_at < cutoff,
        )
        .values(
            status="cancelled",
            decided_at=_now(),
            decision_note="auto-cancelled: pending TTL exceeded",
        )
    )
    if user_id is not None:
        stmt = stmt.where(ElevationRequest.user_id == user_id)
    result = await session.execute(stmt)
    swept = result.rowcount or 0
    if swept:
        _emit("auto_cancelled", count=swept)
    return swept


async def _check_request_burst(session: AsyncSession, user_id: str) -> None:
    """Refuse if the user has hammered /elevation/request recently.

    Counts ALL requests in the window regardless of status, so a user can't
    bypass the limit by cancel-then-retry. Backed by the DB so the count is
    correct across replicas without extra infra; the query is cheap because
    ``ix_elev_user_active`` already indexes ``(user_id, status)``.
    """
    cutoff = _now() - timedelta(hours=REQUEST_BURST_WINDOW_HOURS)
    q = (
        select(func.count())
        .select_from(ElevationRequest)
        .where(
            ElevationRequest.user_id == user_id,
            ElevationRequest.requested_at >= cutoff,
        )
    )
    count = int((await session.execute(q)).scalar_one() or 0)
    if count >= REQUEST_BURST_LIMIT:
        raise RequestBurstError(
            f"Too many elevation requests in the last "
            f"{REQUEST_BURST_WINDOW_HOURS} h ({count}/{REQUEST_BURST_LIMIT}); "
            "please wait before submitting another"
        )


async def _existing_open(session: AsyncSession,
                         user_id: str) -> Optional[ElevationRequest]:
    """Pending OR approved-and-still-active."""
    now = _now()
    stmt = (
        select(ElevationRequest)
        .where(
            ElevationRequest.user_id == user_id,
            or_(
                ElevationRequest.status == "pending",
                and_(
                    ElevationRequest.status == "approved",
                    ElevationRequest.expires_at != None,    # noqa: E711
                    ElevationRequest.expires_at > now,
                ),
            ),
        )
        .limit(1)
    )
    return (await session.execute(stmt)).scalar_one_or_none()


def _to_record(row: ElevationRequest) -> ElevationRecord:
    return ElevationRecord(
        id=row.id, user_id=row.user_id, user_email=row.user_email,
        team_id=row.team_id, base_tier=row.base_tier,
        requested_tier=row.requested_tier,
        duration_minutes=row.duration_minutes, reason=row.reason,
        status=row.status,
        requested_at=row.requested_at, decided_at=row.decided_at,
        expires_at=row.expires_at, approver_user_id=row.approver_user_id,
        decision_note=row.decision_note,
    )


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _emit(event: str, count: int = 1) -> None:
    """Increment the elevation-events counter. Lazy import + swallow errors
    so a missing prometheus_client install or import cycle never breaks the
    business logic on the auth path."""
    if count <= 0:
        return
    try:
        from ..main import ELEVATION_EVENTS
        ELEVATION_EVENTS.labels(event=event).inc(count)
    except Exception:  # noqa: BLE001
        pass


async def _record_ueba(*, user_id: str, team_id: str, tier: str,
                       signal: str) -> None:
    """Fire-and-forget UEBA signal for admin-flow events.

    Looks up the OBSERVE plugin in the registry rather than holding a direct
    reference so a deployment that disables observe_ueba (via GATEWAY_PLUGINS)
    just silently skips this without breaking the business path. Failures are
    swallowed for the same reason — UEBA is best-effort security telemetry,
    never load-bearing for the auth decision.
    """
    try:
        from ..plugins import registry, PluginKind
        for p in registry.of_kind(PluginKind.OBSERVE):
            if p.name == "observe_ueba" and hasattr(p, "record_admin_event"):
                await p.record_admin_event(
                    user_id=user_id, team_id=team_id, tier=tier, signal=signal,
                )
                return
    except Exception:  # noqa: BLE001
        pass
