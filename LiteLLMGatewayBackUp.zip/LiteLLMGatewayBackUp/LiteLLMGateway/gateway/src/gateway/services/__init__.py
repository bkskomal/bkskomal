"""Service layer — narrow async DB operations consumed by the API + plugins.

Service functions are the only code that uses ORM models directly. Routes,
plugins and tests should call services so the persistence boundary is
testable and swappable.
"""
