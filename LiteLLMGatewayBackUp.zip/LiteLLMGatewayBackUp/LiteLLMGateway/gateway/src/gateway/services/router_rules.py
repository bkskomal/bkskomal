"""Router-rule overrides.

The router rule chain lives in ``policies.yaml`` because the ``when:`` block
shapes are too heterogeneous (max_tokens, has_tools, dlp_findings_present,
team_budget_used_pct, contains_any, …) to validate from a UI textbox. What
operators CAN do safely from the UI:

    1. **Enable/disable a rule** — rule keeps existing in YAML but is dropped
       from the chain the plugin evaluates. Useful for incident-time
       killswitch ("turn off the DLP-cloud-block rule for 10 minutes
       while we investigate") without forcing a YAML edit + git PR.
    2. **Substitute the route target** — replace the rule's ``route:`` with
       another model that exists in the registry. Useful when the YAML
       picked a sensible default but ops want to A/B against a different
       model for that rule's traffic.

Both edits are layered on top of the YAML at merge time; the YAML stays
canonical (so a fresh DB cleanly inherits whatever policies.yaml says) and
the DB only carries the operator's deltas.
"""

from __future__ import annotations

import copy
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import RouterRuleOverride


async def list_overrides(session: AsyncSession) -> dict[str, dict[str, Any]]:
    """Return all current overrides keyed by ``rule_name``.

    Shape:
        { "<rule name>": {"enabled": bool, "route_override": str | None}, ... }
    """
    rows = (await session.execute(select(RouterRuleOverride))).scalars().all()
    return {
        r.rule_name: {"enabled": r.enabled, "route_override": r.route_override}
        for r in rows
    }


async def set_override(
    session: AsyncSession,
    *,
    rule_name: str,
    enabled: Optional[bool] = None,
    route_override: Optional[str] = None,
    clear_route_override: bool = False,
) -> RouterRuleOverride:
    """Upsert an override row for ``rule_name``.

    Pass ``enabled`` and / or ``route_override`` to set those fields. Pass
    ``clear_route_override=True`` to NULL out the column (the PATCH endpoint
    uses this to "clear the override" — distinct from "don't touch it",
    which is the default when ``route_override`` is None and
    ``clear_route_override`` is False).
    """
    row = (await session.execute(
        select(RouterRuleOverride).where(RouterRuleOverride.rule_name == rule_name)
    )).scalar_one_or_none()
    if row is None:
        row = RouterRuleOverride(rule_name=rule_name)
        session.add(row)
    if enabled is not None:
        row.enabled = bool(enabled)
    if clear_route_override:
        row.route_override = None
    elif route_override is not None:
        row.route_override = route_override
    await session.commit()
    await session.refresh(row)
    return row


async def apply_overrides(session: AsyncSession,
                          base_rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Layer the DB-stored overrides onto a list of YAML rule dicts.

    - Disabled rules are dropped entirely (so the plugin never evaluates them).
    - ``route_override`` substitutes the rule's ``route`` field in the returned
      copy; the YAML dict is untouched.
    - Rules with no row in the table pass through unchanged.

    Returns a NEW list of NEW rule dicts — the input is never mutated.
    """
    overrides = await list_overrides(session)
    if not overrides:
        # Still return a fresh list so callers can mutate freely.
        return [copy.deepcopy(r) for r in (base_rules or [])]

    out: list[dict[str, Any]] = []
    for rule in (base_rules or []):
        name = rule.get("name") if isinstance(rule, dict) else None
        ov = overrides.get(name) if name else None
        if ov is None:
            out.append(copy.deepcopy(rule))
            continue
        if not ov["enabled"]:
            continue                          # drop disabled rules
        new_rule = copy.deepcopy(rule)
        if ov["route_override"]:
            new_rule["route"] = ov["route_override"]
        out.append(new_rule)
    return out
