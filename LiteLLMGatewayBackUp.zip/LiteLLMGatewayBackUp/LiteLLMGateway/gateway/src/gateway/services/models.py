"""LiteLLM model registry service.

DB-backed model_list management. On first boot the gateway seeds this table
from ``litellm_config.yaml`` so deployers' existing config keeps working;
afterwards the DB is the source of truth.

Provider field
--------------
The UI shows a coloured badge per provider. We derive ``provider`` from the
litellm ``model:`` string at write time, NOT at read time, so the persisted
value can also be hand-edited by an operator who needs to label something
unusual (e.g. an in-house "vllm-experimental" tag).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import LiteLLMModel


# ---------------------------------------------------------------------------
# DTOs
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ModelRecord:
    id: int
    model_name: str
    provider: str
    enabled: bool
    litellm_params: dict[str, Any]
    model_info: Optional[dict[str, Any]]
    created_at: datetime
    updated_at: datetime


class ModelError(Exception):
    """Base error for the service layer; API maps to 4xx."""


class DuplicateModelError(ModelError):
    """A model with this model_name already exists."""


class ModelNotFoundError(ModelError):
    """The model_name / id is not in the registry."""


# ---------------------------------------------------------------------------
# Provider detection
# ---------------------------------------------------------------------------
# Map a litellm "model:" string prefix to a UI-facing provider label.
# Order matters: more-specific prefixes (ollama_chat/) must precede
# generics (openai/) so we don't mis-classify openai_compatible backends.
_PROVIDER_PREFIXES: list[tuple[str, str]] = [
    ("ollama_chat/", "ollama"),
    ("ollama/",      "ollama"),
    ("openrouter/",  "openrouter"),
    ("anthropic/",   "anthropic"),
    ("bedrock/",     "bedrock"),
    ("azure/",       "azure"),
    ("gemini/",      "gemini"),
    ("vertex_ai/",   "vertex"),
    ("groq/",        "groq"),
    ("together_ai/", "together"),
    ("openai/",      "openai"),   # last — least specific
]


def derive_provider(litellm_params: dict[str, Any]) -> str:
    """Best-effort provider label from the litellm `model` string.

    Falls back to "custom" so a hand-written provider tag isn't lost; an
    openai-compatible self-hosted route (`openai/<repo>` with `api_base` set)
    is still tagged "openai" but a future UI version may detect api_base and
    re-tag as "openai_compatible".
    """
    model = (litellm_params or {}).get("model") or ""
    for prefix, label in _PROVIDER_PREFIXES:
        if model.startswith(prefix):
            # `openai/...` with a non-default api_base is really an OpenAI-
            # compatible self-hosted backend (vLLM, TGI, Together, etc.).
            # Keep them as a distinct tag so operators can spot them.
            if label == "openai" and (litellm_params.get("api_base")
                                       or "").strip():
                return "openai_compatible"
            return label
    return "custom"


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------
async def list_models(session: AsyncSession,
                      *, include_disabled: bool = True) -> list[ModelRecord]:
    q = select(LiteLLMModel).order_by(LiteLLMModel.model_name)
    if not include_disabled:
        q = q.where(LiteLLMModel.enabled.is_(True))
    rows = (await session.execute(q)).scalars().all()
    return [_to_record(r) for r in rows]


async def get_model(session: AsyncSession, model_id: int) -> ModelRecord:
    row = (await session.execute(
        select(LiteLLMModel).where(LiteLLMModel.id == model_id)
    )).scalar_one_or_none()
    if row is None:
        raise ModelNotFoundError(f"Model id={model_id} not found")
    return _to_record(row)


async def get_by_name(session: AsyncSession, model_name: str) -> Optional[ModelRecord]:
    row = (await session.execute(
        select(LiteLLMModel).where(LiteLLMModel.model_name == model_name)
    )).scalar_one_or_none()
    return _to_record(row) if row else None


async def create_model(
    session: AsyncSession,
    *,
    model_name: str,
    litellm_params: dict[str, Any],
    model_info: Optional[dict[str, Any]] = None,
    enabled: bool = True,
    provider: Optional[str] = None,
) -> ModelRecord:
    """Add a new model. Refuses duplicates by name."""
    existing = await get_by_name(session, model_name)
    if existing is not None:
        raise DuplicateModelError(
            f"Model {model_name!r} already exists (id={existing.id})"
        )
    _validate(model_name, litellm_params)
    row = LiteLLMModel(
        model_name=model_name,
        provider=provider or derive_provider(litellm_params),
        enabled=enabled,
        litellm_params=litellm_params,
        model_info=model_info,
    )
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def update_model(
    session: AsyncSession,
    model_id: int,
    *,
    model_name: Optional[str] = None,
    litellm_params: Optional[dict[str, Any]] = None,
    model_info: Optional[dict[str, Any]] = None,
    enabled: Optional[bool] = None,
    provider: Optional[str] = None,
) -> ModelRecord:
    row = (await session.execute(
        select(LiteLLMModel).where(LiteLLMModel.id == model_id)
    )).scalar_one_or_none()
    if row is None:
        raise ModelNotFoundError(f"Model id={model_id} not found")

    if model_name is not None and model_name != row.model_name:
        # Renaming — check the new name isn't taken.
        clash = await get_by_name(session, model_name)
        if clash is not None and clash.id != model_id:
            raise DuplicateModelError(
                f"Model {model_name!r} already exists (id={clash.id})"
            )
        row.model_name = model_name
    if litellm_params is not None:
        _validate(row.model_name, litellm_params)
        row.litellm_params = litellm_params
        # Refresh provider unless caller explicitly set it.
        if provider is None:
            row.provider = derive_provider(litellm_params)
    if model_info is not None:
        row.model_info = model_info
    if enabled is not None:
        row.enabled = enabled
    if provider is not None:
        row.provider = provider

    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def delete_model(session: AsyncSession, model_id: int) -> bool:
    result = await session.execute(
        delete(LiteLLMModel).where(LiteLLMModel.id == model_id)
    )
    await session.commit()
    return (result.rowcount or 0) > 0


async def set_enabled(session: AsyncSession, model_id: int, *,
                      enabled: bool) -> ModelRecord:
    """Convenience for the toggle switch in the UI."""
    return await update_model(session, model_id, enabled=enabled)


# ---------------------------------------------------------------------------
# Bootstrap — seed table from litellm_config.yaml on first boot
# ---------------------------------------------------------------------------
async def seed_from_config(session: AsyncSession,
                           litellm_config: dict[str, Any]) -> int:
    """If the registry is empty, seed it from a parsed litellm_config.yaml.

    Idempotent: if any row already exists, this is a no-op. Returns the
    number of rows seeded (0 if seeding was skipped).
    """
    existing = (await session.execute(select(LiteLLMModel.id))).first()
    if existing is not None:
        return 0
    model_list = (litellm_config or {}).get("model_list") or []
    seeded = 0
    for entry in model_list:
        try:
            mn      = entry["model_name"]
            params  = entry.get("litellm_params") or {}
            info    = entry.get("model_info") or None
        except Exception:                                       # noqa: BLE001
            # Malformed entry — skip rather than fail the whole bootstrap.
            continue
        row = LiteLLMModel(
            model_name=mn,
            provider=derive_provider(params),
            enabled=True,
            litellm_params=params,
            model_info=info,
        )
        session.add(row)
        seeded += 1
    if seeded:
        await session.commit()
    return seeded


# ---------------------------------------------------------------------------
# Router payload — used by main.py to (re)build the LiteLLM Router
# ---------------------------------------------------------------------------
async def to_router_model_list(session: AsyncSession) -> list[dict[str, Any]]:
    """Return the enabled rows in the LiteLLM-compatible ``model_list``
    shape, with env-var references expanded.

    The historical YAML uses LiteLLM's `os.environ/VARNAME` syntax for
    api_base / api_key. LLMGateway (which now powers the Router) does NOT
    expand that pattern itself — it expects a concrete URL. We resolve the
    references here so the Router sees ready-to-use strings.

    UI-managed provider keys override the env-var lookup: when the env
    var is missing or equals the literal "dummy", a value stored in
    ``system_settings`` for the matching provider is used instead. This
    lets operators paste an API key into the Settings → Providers card
    and have it survive across restarts without re-exporting env vars.

    Disabled rows are excluded so the router has no way to send traffic to
    them — the kill-switch is enforced one layer below routing.
    """
    # Build the provider-key override map from system_settings ONCE per
    # Router rebuild. Async lookup; cheap (one indexed SELECT per key).
    from . import system_settings as ss
    overrides: dict[str, str] = {}
    try:
        or_rec = await ss.get(session, ss.KEY_OPENROUTER_API_KEY)
        or_key = (or_rec.value or {}).get("api_key")
        if isinstance(or_key, str) and or_key.strip():
            overrides["OPENROUTER_API_KEY"] = or_key.strip()
    except Exception:  # noqa: BLE001
        pass

    rows = await list_models(session, include_disabled=False)
    out: list[dict[str, Any]] = []
    for r in rows:
        entry: dict[str, Any] = {
            "model_name":     r.model_name,
            "litellm_params": _expand_env_refs(r.litellm_params or {}, overrides),
        }
        if r.model_info:
            entry["model_info"] = r.model_info
        out.append(entry)
    return out


# ---------------------------------------------------------------------------
# `os.environ/VARNAME` expansion — LiteLLM-compatible env-var indirection
# ---------------------------------------------------------------------------
def _expand_env_refs(params: dict[str, Any],
                     overrides: Optional[dict[str, str]] = None,
                     ) -> dict[str, Any]:
    """Walk a litellm_params dict and resolve any `os.environ/VARNAME`
    string into the matching env var, with optional UI overrides.

    Resolution order for ``os.environ/VARNAME``:
        1. ``overrides[VARNAME]`` if set and truthy (UI-managed key)
        2. real env var, *unless* it equals the literal "dummy" (the
           placeholder we ship in seed configs)
        3. empty string (signals "not configured")

    LiteLLM's YAML loader did this implicitly; LLMGateway doesn't. Keeping
    the indirection in DB / YAML keeps configs portable across machines
    (Postgres URL, vLLM base URL, OpenRouter key) without baking secrets
    into the config row.
    """
    import os
    overrides = overrides or {}
    out: dict[str, Any] = {}
    for k, v in params.items():
        if isinstance(v, str) and v.startswith("os.environ/"):
            var_name = v[len("os.environ/"):]
            ov  = overrides.get(var_name)
            env = os.environ.get(var_name, "")
            if ov:
                out[k] = ov
            elif env and env != "dummy":
                out[k] = env
            else:
                out[k] = ov or env or ""
        else:
            out[k] = v
    return out


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
def _validate(model_name: str, params: dict[str, Any]) -> None:
    if not model_name or not isinstance(model_name, str):
        raise ModelError("model_name must be a non-empty string")
    if not isinstance(params, dict):
        raise ModelError("litellm_params must be an object")
    if not params.get("model"):
        raise ModelError("litellm_params.model is required (e.g. 'ollama_chat/qwen2.5-coder:7b-instruct')")


def _to_record(row: LiteLLMModel) -> ModelRecord:
    return ModelRecord(
        id=row.id,
        model_name=row.model_name,
        provider=row.provider,
        enabled=row.enabled,
        litellm_params=row.litellm_params or {},
        model_info=row.model_info,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )
