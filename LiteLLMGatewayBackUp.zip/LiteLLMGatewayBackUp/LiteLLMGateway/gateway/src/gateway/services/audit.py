"""Audit-log read API.

The audit_postgres plugin owns WRITES (append-only, one row per gateway
call). This service owns READS — search by user/team/model/verdict over the
immutable audit DB.

Plaintext exposure
------------------
``prompt_ciphertext`` and ``response_ciphertext`` columns are NEVER returned
by this service. Plaintext access is a separate 4-eyes flow (deferred) so
even an admin running ad-hoc searches can't accidentally page through
sensitive content. Hashes are returned so SOC ops can correlate without
seeing payloads.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import AuditLog


@dataclass(frozen=True)
class AuditEntry:
    id: int
    ts: datetime
    request_id: str
    trace_id: Optional[str]
    user_id: str
    user_email: Optional[str]
    team_id: str
    tier: str
    base_tier: Optional[str]
    elevation_id: Optional[int]
    model_requested: Optional[str]
    model_used: Optional[str]
    routing_reason: Optional[str]
    tokens_in: int
    tokens_out: int
    latency_ms: float
    cost_usd: float
    prompt_hash: Optional[str]
    response_hash: Optional[str]
    verdict: str
    findings: Optional[list[dict[str, Any]]]
    client_ip: Optional[str]
    user_agent: Optional[str]


async def search(
    session: AsyncSession,
    *,
    user_id:    Optional[str]      = None,
    team_id:    Optional[str]      = None,
    model_used: Optional[str]      = None,
    verdict:    Optional[str]      = None,
    trace_id:   Optional[str]      = None,
    since:      Optional[datetime] = None,
    until:      Optional[datetime] = None,
    before_id:  Optional[int]      = None,
    limit:      int                = 50,
) -> list[AuditEntry]:
    """Cursor-paginated audit-log search, newest first.

    Pagination is cursor-based on ``id`` (monotonic, append-only): pass the
    last result's id as ``before_id`` to get the next page. Offset-based
    paging would skew over an actively-written table; cursor-based is stable.
    """
    limit = max(1, min(limit, 500))

    q = select(AuditLog)
    if user_id is not None:
        q = q.where(AuditLog.user_id == user_id)
    if team_id is not None:
        q = q.where(AuditLog.team_id == team_id)
    if model_used is not None:
        q = q.where(AuditLog.model_used == model_used)
    if verdict is not None:
        q = q.where(AuditLog.verdict == verdict)
    if trace_id is not None:
        q = q.where(AuditLog.trace_id == trace_id)
    if since is not None:
        q = q.where(AuditLog.ts >= since)
    if until is not None:
        q = q.where(AuditLog.ts < until)
    if before_id is not None:
        q = q.where(AuditLog.id < before_id)

    q = q.order_by(desc(AuditLog.id)).limit(limit)
    rows = (await session.execute(q)).scalars().all()
    return [_to_entry(r) for r in rows]


@dataclass(frozen=True)
class DashboardSummary:
    """Single-shot rollup for the Overview dashboard.

    Computed from audit_log (the source of truth — never desynced from what
    the gateway actually let through). Prometheus has the same numbers but
    needs a real scraping setup; querying the DB directly keeps the dashboard
    self-contained for dev / smoke environments.
    """
    window_minutes:    int
    generated_at:      datetime
    request_count:     int
    requests_per_min:  float
    avg_latency_ms:    float
    p99_latency_ms:    float
    tokens_in_total:   int
    tokens_out_total:  int
    cost_usd_total:    float
    verdict_counts:    dict[str, int]
    dlp_findings:      int
    secret_leaks:      int
    top_models:        list[dict[str, Any]]   # [{model, count, tokens}]
    top_teams:         list[dict[str, Any]]   # [{team, count, tokens}]
    timeseries:        list[dict[str, Any]]   # [{bucket, count, refused}] - 1 bucket per minute


async def summary(
    session: AsyncSession,
    *,
    window_minutes: int = 60,
) -> DashboardSummary:
    """Roll up the last N minutes of audit_log into a dashboard payload.

    Single endpoint behind the /admin/dashboard/summary route so the UI
    only does one fetch per refresh tick. Heavy lifting (verdict mix,
    top models/teams, sparkline) all derives from one base SELECT — we
    pull rows once and aggregate in Python rather than running 5 GROUP BYs;
    typical N is small (last hour = a few hundred rows), and avoiding round
    trips keeps the endpoint snappy under auto-refresh load.
    """
    now = datetime.now(timezone.utc)
    since = now - timedelta(minutes=window_minutes)

    rows = (await session.execute(
        select(AuditLog).where(AuditLog.ts >= since).order_by(AuditLog.ts)
    )).scalars().all()

    request_count = len(rows)
    tokens_in     = sum(r.tokens_in  or 0 for r in rows)
    tokens_out    = sum(r.tokens_out or 0 for r in rows)
    cost_total    = sum(r.cost_usd   or 0.0 for r in rows)

    latencies = sorted(r.latency_ms or 0.0 for r in rows)
    avg_lat = (sum(latencies) / len(latencies)) if latencies else 0.0
    p99_lat = latencies[int(len(latencies) * 0.99)] if latencies else 0.0

    verdicts: dict[str, int] = {}
    for r in rows:
        verdicts[r.verdict] = verdicts.get(r.verdict, 0) + 1

    # dlp_findings — sensitive data caught BEFORE egress (location=prompt).
    # secret_leaks — secrets caught in the model's RESPONSE
    # (plugin=output_scan_secrets). The two are intentionally disjoint so
    # the dashboard can show "what we kept out" vs "what slipped past".
    dlp_findings = 0
    secret_leaks = 0
    for r in rows:
        for f in (r.findings or []):
            location = (f.get("location") or "").lower()
            plugin   = f.get("plugin") or ""
            if plugin == "output_scan_secrets":
                secret_leaks += 1
            elif location == "prompt":
                dlp_findings += 1

    # Top models / teams — bucket counts + token totals.
    by_model: dict[str, dict[str, int]] = {}
    by_team:  dict[str, dict[str, int]] = {}
    for r in rows:
        m = r.model_used or "unknown"
        t = r.team_id    or "unknown"
        by_model.setdefault(m, {"count": 0, "tokens": 0})
        by_model[m]["count"]  += 1
        by_model[m]["tokens"] += (r.tokens_in or 0) + (r.tokens_out or 0)
        by_team.setdefault(t, {"count": 0, "tokens": 0})
        by_team[t]["count"]  += 1
        by_team[t]["tokens"] += (r.tokens_in or 0) + (r.tokens_out or 0)

    top_models = sorted(
        ({"model": k, **v} for k, v in by_model.items()),
        key=lambda d: d["count"], reverse=True,
    )[:5]
    top_teams = sorted(
        ({"team": k, **v} for k, v in by_team.items()),
        key=lambda d: d["count"], reverse=True,
    )[:5]

    # Per-minute timeseries — densely backfilled so the UI sparkline shows
    # zeros where nothing happened (otherwise gaps look like missing data).
    ts_buckets: list[dict[str, Any]] = []
    bucket_counts: dict[int, dict[str, int]] = {}
    for r in rows:
        if r.ts is None:
            continue
        # Minute aligned to UTC; subtract from `now` as integer offset.
        minutes_ago = int((now - r.ts).total_seconds() // 60)
        if minutes_ago < 0 or minutes_ago >= window_minutes:
            continue
        slot = bucket_counts.setdefault(minutes_ago, {"count": 0, "refused": 0})
        slot["count"] += 1
        if r.verdict == "refused":
            slot["refused"] += 1
    for i in range(window_minutes):
        slot = bucket_counts.get(i, {"count": 0, "refused": 0})
        ts_buckets.append({
            "minutes_ago": i,
            "count":       slot["count"],
            "refused":     slot["refused"],
        })
    # Order oldest -> newest so the UI can render left-to-right naturally.
    ts_buckets.reverse()

    return DashboardSummary(
        window_minutes=window_minutes,
        generated_at=now,
        request_count=request_count,
        requests_per_min=round(request_count / max(1, window_minutes), 3),
        avg_latency_ms=round(avg_lat, 2),
        p99_latency_ms=round(p99_lat, 2),
        tokens_in_total=tokens_in,
        tokens_out_total=tokens_out,
        cost_usd_total=round(cost_total, 6),
        verdict_counts=verdicts,
        dlp_findings=dlp_findings,
        secret_leaks=secret_leaks,
        top_models=top_models,
        top_teams=top_teams,
        timeseries=ts_buckets,
    )


@dataclass(frozen=True)
class RetentionResult:
    """What a retention sweep did. Surfaced to the operator via API."""
    cutoff_ts: datetime
    rows_deleted: int
    bytes_freed_estimate: int      # rows * avg_row_size (rough)
    duration_ms: float


@dataclass(frozen=True)
class CostForecast:
    """Projected spend, derived from a rolling window of audit_log rows.

    Operators sized their model budgets in dollars per month; this gives
    them a daily check on how the actual burn rate is tracking. Nothing
    fancy: take a recent window's cost, normalize to per-day, project
    forward. No regression, no seasonality — that's what dashboards
    layered on top of Grafana are for.
    """
    window_days:       int      # input window (e.g. last 7 days)
    cost_window_usd:   float    # cost across the window
    cost_per_day:      float    # normalized
    projection_days:   int      # how many days we project (e.g. 30)
    projected_usd:     float    # cost_per_day * projection_days
    by_team:           list[dict[str, Any]]   # [{team_id, cost_usd, share}, ...]
    by_model:          list[dict[str, Any]]   # [{model_used, cost_usd, share}, ...]
    rows_considered:   int
    generated_at:      datetime


async def cost_forecast(
    session: AsyncSession,
    *,
    window_days: int = 7,
    projection_days: int = 30,
) -> CostForecast:
    """Lightweight spend projection from audit_log.

    Pulls every row in the last ``window_days``, sums cost_usd, normalizes
    to per-day, multiplies by ``projection_days``. Buckets by team and
    model so the UI can show "where the money's going" alongside the
    headline number.

    Returns zero-shaped record on a clean install (no audit rows yet)
    so the UI doesn't have to special-case the empty state.
    """
    window_days     = max(1, min(window_days, 90))
    projection_days = max(1, min(projection_days, 365))
    now    = datetime.now(timezone.utc)
    since  = now - timedelta(days=window_days)

    rows = (await session.execute(
        select(AuditLog).where(AuditLog.ts >= since)
    )).scalars().all()

    cost_total = sum(r.cost_usd or 0.0 for r in rows)
    cost_per_day = round(cost_total / window_days, 6)
    projected = round(cost_per_day * projection_days, 6)

    # Group by team / model with shares relative to the window cost.
    by_team_dict: dict[str, float] = {}
    by_model_dict: dict[str, float] = {}
    for r in rows:
        if r.cost_usd:
            by_team_dict[r.team_id or "unknown"] = (
                by_team_dict.get(r.team_id or "unknown", 0.0) + r.cost_usd
            )
            by_model_dict[r.model_used or "unknown"] = (
                by_model_dict.get(r.model_used or "unknown", 0.0) + r.cost_usd
            )

    def _share(c: float) -> float:
        return round(c / cost_total, 4) if cost_total > 0 else 0.0

    by_team  = sorted(
        ({"team_id": k, "cost_usd": round(v, 6), "share": _share(v)}
         for k, v in by_team_dict.items()),
        key=lambda d: d["cost_usd"], reverse=True,
    )
    by_model = sorted(
        ({"model_used": k, "cost_usd": round(v, 6), "share": _share(v)}
         for k, v in by_model_dict.items()),
        key=lambda d: d["cost_usd"], reverse=True,
    )

    return CostForecast(
        window_days=window_days,
        cost_window_usd=round(cost_total, 6),
        cost_per_day=cost_per_day,
        projection_days=projection_days,
        projected_usd=projected,
        by_team=by_team,
        by_model=by_model,
        rows_considered=len(rows),
        generated_at=now,
    )


@dataclass(frozen=True)
class SpendByModel:
    """Spend rate ($USD/h) per model over a rolling window.

    The window is the input granularity; we divide the window's cost by
    the elapsed hours to get a per-hour burn rate. Cheap: one SELECT over
    the window, in-Python aggregation, no Prometheus dependency.

    Computed ONLY when the operator has enabled the toggle — see the
    ``spend_by_model_enabled`` system setting. When disabled, the
    endpoint short-circuits and returns ``enabled=False`` without
    touching the audit table.
    """
    enabled:        bool
    window_minutes: int
    cost_total_usd: float
    by_model:       list[dict[str, Any]]   # [{model, cost_usd, usd_per_hour}, ...]
    rows_considered: int
    generated_at:   datetime


async def spend_by_model(
    session: AsyncSession,
    *,
    window_minutes: int = 60,
) -> SpendByModel:
    """Per-model burn rate over the last ``window_minutes``.

    The caller is expected to gate this on the system-settings toggle
    before invoking — keeping the gate at the endpoint layer means tests
    can call the service directly when they need the calculation.
    """
    window_minutes = max(1, min(window_minutes, 24 * 60))
    now    = datetime.now(timezone.utc)
    since  = now - timedelta(minutes=window_minutes)

    rows = (await session.execute(
        select(AuditLog).where(AuditLog.ts >= since)
    )).scalars().all()

    by_model_dict: dict[str, float] = {}
    cost_total = 0.0
    for r in rows:
        if r.cost_usd:
            cost_total += r.cost_usd
            key = r.model_used or "unknown"
            by_model_dict[key] = by_model_dict.get(key, 0.0) + r.cost_usd

    hours = window_minutes / 60.0
    by_model = sorted(
        ({"model":        k,
          "cost_usd":     round(v, 6),
          "usd_per_hour": round(v / hours, 6) if hours > 0 else 0.0}
         for k, v in by_model_dict.items()),
        key=lambda d: d["usd_per_hour"], reverse=True,
    )

    return SpendByModel(
        enabled=True,
        window_minutes=window_minutes,
        cost_total_usd=round(cost_total, 6),
        by_model=by_model,
        rows_considered=len(rows),
        generated_at=now,
    )


async def prune_older_than(
    session: AsyncSession,
    *,
    days: int,
    dry_run: bool = False,
) -> RetentionResult:
    """Delete (or count, when ``dry_run``) audit_log rows older than
    ``days`` days. Append-only stays append-only — we never UPDATE rows;
    we just DELETE the ones past the retention horizon.

    Operators run this either via the admin endpoint (one-shot) or on a
    cron schedule. Without a periodic prune, audit_log grows unbounded
    and starts to dominate Postgres disk. Defaults to a no-op when days
    is non-positive so a misconfig can't wipe the table.

    Returns rows_deleted + a rough byte-size estimate (rows × 2 KB,
    which is what a typical row weighs with hashes + findings JSON).
    """
    import time
    if days <= 0:
        return RetentionResult(
            cutoff_ts=datetime.now(timezone.utc),
            rows_deleted=0,
            bytes_freed_estimate=0,
            duration_ms=0.0,
        )
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    started = time.monotonic()
    if dry_run:
        # COUNT — cheap, used by the UI to confirm before destructive op.
        from sqlalchemy import func, select as _select
        count = (await session.execute(
            _select(func.count()).select_from(AuditLog)
            .where(AuditLog.ts < cutoff)
        )).scalar_one()
        rows_deleted = int(count or 0)
    else:
        from sqlalchemy import delete as _delete
        result = await session.execute(
            _delete(AuditLog).where(AuditLog.ts < cutoff)
        )
        await session.commit()
        rows_deleted = int(result.rowcount or 0)
    duration_ms = (time.monotonic() - started) * 1000.0
    return RetentionResult(
        cutoff_ts=cutoff,
        rows_deleted=rows_deleted,
        bytes_freed_estimate=rows_deleted * 2048,
        duration_ms=round(duration_ms, 2),
    )


def _to_entry(row: AuditLog) -> AuditEntry:
    return AuditEntry(
        id=row.id,
        ts=row.ts,
        request_id=row.request_id,
        trace_id=row.trace_id,
        user_id=row.user_id,
        user_email=row.user_email,
        team_id=row.team_id,
        tier=row.tier,
        base_tier=row.base_tier,
        elevation_id=row.elevation_id,
        model_requested=row.model_requested,
        model_used=row.model_used,
        routing_reason=row.routing_reason,
        tokens_in=row.tokens_in or 0,
        tokens_out=row.tokens_out or 0,
        latency_ms=row.latency_ms or 0.0,
        cost_usd=row.cost_usd or 0.0,
        prompt_hash=row.prompt_hash,
        response_hash=row.response_hash,
        verdict=row.verdict,
        findings=row.findings,
        client_ip=row.client_ip,
        user_agent=row.user_agent,
    )
