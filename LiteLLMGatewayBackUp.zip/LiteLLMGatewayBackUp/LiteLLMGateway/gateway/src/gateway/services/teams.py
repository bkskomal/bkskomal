"""Team service — CRUD + seeding from policies.yaml.

A team is a logical grouping of developers that maps to exactly one tier in
``policies.yaml``. Tier names (``L0_readonly``, ``L1_standard``, …) live in
YAML; team rows in Postgres reference them by string.

``seed_from_policies`` is called once at gateway startup and is idempotent —
it inserts missing teams and updates tier-changes, but never deletes (manual
admin action required, to avoid surprise deprovisions).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import Team

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class TeamRecord:
    team_id: str
    tier: str
    description: Optional[str]
    created_at: datetime


async def get_team(session: AsyncSession, team_id: str) -> Optional[TeamRecord]:
    row = (await session.execute(
        select(Team).where(Team.team_id == team_id)
    )).scalar_one_or_none()
    if not row:
        return None
    return TeamRecord(team_id=row.team_id, tier=row.tier,
                      description=row.description, created_at=row.created_at)


async def list_teams(session: AsyncSession) -> list[TeamRecord]:
    rows = (await session.execute(
        select(Team).order_by(Team.team_id)
    )).scalars().all()
    return [
        TeamRecord(team_id=r.team_id, tier=r.tier,
                   description=r.description, created_at=r.created_at)
        for r in rows
    ]


async def upsert_team(session: AsyncSession,
                      *,
                      team_id: str,
                      tier: str,
                      description: Optional[str] = None) -> TeamRecord:
    """Insert or update a team. Empty string in ``description`` clears it
    (stores NULL); ``None`` means "don't touch" on update."""
    # Normalise: an empty-string description is treated as "explicitly
    # clear" so the UI can wipe a note. ``None`` retains the "leave alone"
    # semantics seeding relies on.
    desc_clear  = isinstance(description, str) and description.strip() == ""
    desc_set    = description is not None and not desc_clear

    existing = (await session.execute(
        select(Team).where(Team.team_id == team_id)
    )).scalar_one_or_none()
    if existing is None:
        row = Team(team_id=team_id, tier=tier,
                   description=(None if desc_clear else description))
        session.add(row)
        await session.commit()
        await session.refresh(row)
    else:
        changed = False
        if existing.tier != tier:
            existing.tier = tier
            changed = True
        if desc_clear and existing.description is not None:
            existing.description = None
            changed = True
        elif desc_set and existing.description != description:
            existing.description = description
            changed = True
        if changed:
            await session.commit()
            await session.refresh(existing)
        row = existing
    return TeamRecord(team_id=row.team_id, tier=row.tier,
                      description=row.description, created_at=row.created_at)


class TeamHasActiveKeysError(Exception):
    """Raised when a delete is refused because keys still reference the team."""
    def __init__(self, team_id: str, count: int):
        self.team_id = team_id
        self.count   = count
        super().__init__(
            f"team {team_id!r} still has {count} active key(s); "
            "revoke them before deleting the team"
        )


async def delete_team(session: AsyncSession, team_id: str) -> bool:
    """Hard-delete a team. Refuses if any *active* virtual key references it.

    Returns ``True`` on a successful delete, ``False`` if the team doesn't
    exist (idempotent). Raises ``TeamHasActiveKeysError`` when the team is
    still in use — caller maps to HTTP 409.
    """
    # Reference check — keep this in the service layer so the UI / tests
    # both go through the same gate.
    from ..models import VirtualKey   # local import to avoid cycle
    active_count = (await session.execute(
        select(VirtualKey).where(
            VirtualKey.team_id == team_id,
            VirtualKey.is_active.is_(True),
        )
    )).scalars().all()
    if len(active_count) > 0:
        raise TeamHasActiveKeysError(team_id, len(active_count))

    existing = (await session.execute(
        select(Team).where(Team.team_id == team_id)
    )).scalar_one_or_none()
    if existing is None:
        return False
    await session.delete(existing)
    await session.commit()
    return True


async def seed_from_policies(session: AsyncSession, policies: dict) -> int:
    """Idempotently sync ``teams`` from a parsed ``policies.yaml`` dict.

    Returns the number of inserts/updates performed.
    """
    changed = 0
    for team in policies.get("teams") or []:
        team_id = team.get("team_id")
        tier    = team.get("tier")
        if not team_id or not tier:
            continue
        before = await get_team(session, team_id)
        after  = await upsert_team(session, team_id=team_id, tier=tier,
                                   description=team.get("notes"))
        if before is None or before.tier != after.tier:
            changed += 1
    if changed:
        log.info("teams: seeded/updated %d row(s) from policies.yaml", changed)
    return changed
