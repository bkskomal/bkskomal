"""Outbound email — one-time API-key delivery + IDE setup notes.

SMTP config lives in ``system_settings`` (managed from the admin UI's
Settings → App page) with an env-var fallback for greenfield installs.

This module is deliberately conservative:
  * Best-effort: an SMTP failure must NEVER fail the surrounding HTTP
    request. Callers swallow exceptions and log them.
  * No retries on the request path. A flaky SMTP is the operator's
    problem to resolve in Settings, not something to retry inline.
  * The raw API key is included exactly once per outgoing message; the
    body warns the recipient that the key cannot be retrieved later.
"""

from __future__ import annotations

import logging
import os
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from typing import Optional

import aiosmtplib
from sqlalchemy.ext.asyncio import AsyncSession

from . import system_settings as ss

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config DTO
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class SmtpConfig:
    host: str
    port: int
    user: Optional[str]
    password: Optional[str]
    from_addr: str
    from_name: str
    use_tls: bool        # STARTTLS upgrade on connect (port 587 etc.)
    use_ssl: bool        # implicit TLS from connect (port 465)

    def configured(self) -> bool:
        return bool(self.host and self.from_addr)


def _from_env() -> SmtpConfig:
    """Pull SMTP config from environment variables. Used as a fallback
    when system_settings has nothing stored."""
    return SmtpConfig(
        host      = os.environ.get("SMTP_HOST", ""),
        port      = int(os.environ.get("SMTP_PORT") or 587),
        user      = os.environ.get("SMTP_USER") or None,
        password  = os.environ.get("SMTP_PASSWORD") or None,
        from_addr = os.environ.get("SMTP_FROM") or "",
        from_name = os.environ.get("SMTP_FROM_NAME") or "OATI LLMGateway",
        use_tls   = (os.environ.get("SMTP_USE_TLS", "true").lower() == "true"),
        use_ssl   = (os.environ.get("SMTP_USE_SSL", "false").lower() == "true"),
    )


async def load_config(session: AsyncSession) -> SmtpConfig:
    """Resolve the active SMTP config. system_settings wins; env fills
    any missing field — so an operator can store host + auth in the DB
    and still override one knob with an env var for emergencies."""
    rec = await ss.get(session, ss.KEY_SMTP_CONFIG)
    stored = rec.value or {}
    env = _from_env()

    def pick(key: str, env_val):
        v = stored.get(key)
        return v if v not in (None, "") else env_val

    return SmtpConfig(
        host      = str(pick("host", env.host) or ""),
        port      = int(pick("port", env.port) or 587),
        user      = pick("user", env.user) or None,
        password  = pick("password", env.password) or None,
        from_addr = str(pick("from_addr", env.from_addr) or ""),
        from_name = str(pick("from_name", env.from_name) or "OATI LLMGateway"),
        use_tls   = bool(pick("use_tls", env.use_tls)),
        use_ssl   = bool(pick("use_ssl", env.use_ssl)),
    )


# ---------------------------------------------------------------------------
# Templating
# ---------------------------------------------------------------------------
def _setup_snippets(api_key: str, base_url: str, default_model: str) -> str:
    """Plaintext IDE config snippets for Cline / Continue / Antigravity.
    Kept literal so the recipient can copy-paste verbatim."""
    cont = f"""\
# .continue/config.json  (Continue plugin)
{{
  "models": [{{
    "title":   "OATI Gateway",
    "provider":"openai",
    "model":   "{default_model}",
    "apiBase": "{base_url}/v1",
    "apiKey":  "{api_key}"
  }}]
}}"""
    cline = f"""\
# Cline → Settings → API Provider = "OpenAI Compatible"
#   Base URL  : {base_url}
#   API Key   : {api_key}
#   Model ID  : {default_model}"""
    antigravity = f"""\
# Antigravity IDE → Settings → AI provider = "OpenAI Compatible"
#   Endpoint  : {base_url}/v1
#   API key   : {api_key}
#   Model     : {default_model}"""
    return "\n\n".join([cont, cline, antigravity])


def _build_message(*, cfg: SmtpConfig, to_addr: str, user_id: str,
                   team_id: str, role: str, raw_key: str, key_prefix: str,
                   base_url: str, default_model: str,
                   expires_at: Optional[str]) -> EmailMessage:
    subject = f"Your OATI LLMGateway API key — save this email"
    snippets = _setup_snippets(raw_key, base_url, default_model)
    expires_line = f"\nExpires at: {expires_at}\n" if expires_at else ""

    plain = f"""\
Hi {user_id},

An OATI operator has just issued an API key for you on the LLMGateway.
The raw key value is included once below; we don't store it in plain
text, so save it now.

  API key  : {raw_key}
  Prefix   : {key_prefix}…
  Team     : {team_id}
  Role     : {role}{expires_line}
  Gateway  : {base_url}

──────────────  IDE setup snippets  ──────────────

{snippets}

──────────────────────────────────────────────────

If something looks off, ping #llmgateway-ops or reply to this email.

— OATI LLMGateway"""

    html = f"""\
<!doctype html>
<html><body style="font-family:Segoe UI,Roboto,Helvetica,Arial,sans-serif;
                   color:#1a1a1a;background:#f5f7fa;padding:24px;">
  <div style="max-width:640px;margin:0 auto;background:#fff;
              border-radius:8px;overflow:hidden;
              box-shadow:0 1px 3px rgba(0,0,0,.08);">
    <div style="background:#141f3b;color:#fff;padding:16px 24px;">
      <div style="font-size:13px;letter-spacing:.18em;
                  text-transform:uppercase;opacity:.7;">OATI Technology</div>
      <div style="font-size:20px;font-weight:600;margin-top:4px;">
        OATI LLMGateway · API key issued
      </div>
    </div>
    <div style="padding:20px 24px;">
      <p>Hi <strong>{user_id}</strong>,</p>
      <p>An operator has issued an API key for you on the LLMGateway.
         The raw value is shown once below — save it now; it cannot
         be retrieved later.</p>

      <div style="background:#f1f4f8;border:1px solid #d0d7de;
                  border-radius:6px;padding:14px;font-family:Consolas,
                  monospace;font-size:13px;word-break:break-all;">
        <div><strong>API key:</strong> <span style="color:#c82a32;">{raw_key}</span></div>
        <div style="margin-top:6px;color:#6b7280;">
          <strong>Prefix:</strong> {key_prefix}… &middot;
          <strong>Team:</strong> {team_id} &middot;
          <strong>Role:</strong> {role}
          {("&middot; <strong>Expires:</strong> " + expires_at) if expires_at else ""}
        </div>
        <div style="margin-top:6px;color:#6b7280;">
          <strong>Gateway:</strong> {base_url}
        </div>
      </div>

      <h3 style="margin-top:24px;color:#141f3b;">IDE setup snippets</h3>
      <pre style="background:#0f172a;color:#e2e8f0;padding:14px;
                  border-radius:6px;font-size:12.5px;overflow:auto;
                  white-space:pre-wrap;">{snippets}</pre>

      <p style="color:#6b7280;font-size:12.5px;margin-top:18px;">
        If something looks off, reply to this email or ping
        <code>#llmgateway-ops</code>.
      </p>
    </div>
    <div style="background:#1b2a4e;color:#cfd4dc;padding:8px 24px;
                font-size:10.5px;">
      PROPRIETARY AND CONFIDENTIAL · Open Access Technology International
    </div>
  </div>
</body></html>"""

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"]    = f"{cfg.from_name} <{cfg.from_addr}>"
    msg["To"]      = to_addr
    msg.set_content(plain)
    msg.add_alternative(html, subtype="html")
    return msg


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
class EmailError(Exception):
    """Raised by send paths so callers can map to HTTP 502 in tests; on
    the request path we suppress this and log instead."""


async def _send_message(cfg: SmtpConfig, msg: EmailMessage) -> None:
    """Single SMTP attempt. Caller decides whether to swallow or raise."""
    if not cfg.configured():
        raise EmailError("SMTP not configured — set host + from_addr in Settings → App.")
    # aiosmtplib mode: implicit TLS via use_tls (the underlying socket),
    # or STARTTLS via start_tls. The semantics differ from Python's stdlib
    # smtplib — we expose both with explicit booleans.
    try:
        await aiosmtplib.send(
            msg,
            hostname  = cfg.host,
            port      = cfg.port,
            username  = cfg.user or None,
            password  = cfg.password or None,
            use_tls   = cfg.use_ssl,           # implicit TLS (port 465)
            start_tls = cfg.use_tls,           # STARTTLS upgrade (port 587)
            timeout   = 15,
        )
    except Exception as e:                                              # noqa: BLE001
        raise EmailError(f"SMTP send failed: {e}") from e


async def send_key_email(
    session: AsyncSession,
    *,
    to_addr: str,
    user_id: str,
    team_id: str,
    role: str,
    raw_key: str,
    key_prefix: str,
    base_url: str,
    default_model: str,
    expires_at: Optional[str] = None,
) -> None:
    """Send the one-time-key email. Raises EmailError if SMTP isn't
    configured or the send fails — callers on the HTTP path swallow and
    log so that key issuance still succeeds."""
    cfg = await load_config(session)
    msg = _build_message(
        cfg=cfg, to_addr=to_addr, user_id=user_id, team_id=team_id,
        role=role, raw_key=raw_key, key_prefix=key_prefix,
        base_url=base_url, default_model=default_model,
        expires_at=expires_at,
    )
    await _send_message(cfg, msg)
    log.warning("Emailed new API key to %s (key prefix=%s, team=%s)",
                to_addr, key_prefix, team_id)


async def send_test_email(session: AsyncSession, *, to_addr: str) -> None:
    """Operator-triggered 'Send test' from the SMTP card.

    Body is deliberately tiny — no secrets, just a confirmation that the
    SMTP config is wired up.
    """
    cfg = await load_config(session)
    msg = EmailMessage()
    msg["Subject"] = "OATI LLMGateway · SMTP test"
    msg["From"]    = f"{cfg.from_name} <{cfg.from_addr}>"
    msg["To"]      = to_addr
    msg.set_content(
        "This is a test email from OATI LLMGateway.\n"
        "If you received it, the SMTP config in Settings → App is working.\n"
    )
    await _send_message(cfg, msg)
