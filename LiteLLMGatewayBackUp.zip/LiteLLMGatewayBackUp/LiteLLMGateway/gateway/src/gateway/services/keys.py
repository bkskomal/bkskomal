"""Virtual-API-key service.

A virtual key is a ``sk-<urlsafe>`` token issued to a developer. Only its
SHA-256 hash + first 8 chars are stored, so a DB leak doesn't yield live
credentials. On every request the gateway hashes the inbound bearer and
looks up the matching row.

This module owns:
  * key generation (cryptographically random)
  * insert / lookup / revoke
  * last-used bookkeeping

OIDC integration lands in a later sprint; for now ``create_key`` is invoked
either by an admin (via ``POST /admin/keys``) or by the test seed fixture.
"""

from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import VirtualKey


KEY_PREFIX = "sk-"
RAW_TOKEN_BYTES = 32          # 32 random bytes → 43-char urlsafe → ~256 bits


# ---------------------------------------------------------------------------
# Public DTO returned to the API. Plain dataclass — kept out of the ORM so
# routes / plugins never see SQLAlchemy session-bound objects by accident.
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class IssuedKey:
    id: int
    raw_key: str               # ONLY returned on creation; never read back
    key_prefix: str
    user_id: str
    user_email: Optional[str]
    team_id: str
    role: str
    created_at: datetime
    expires_at: Optional[datetime]


@dataclass(frozen=True)
class KeyRecord:
    id: int
    key_prefix: str
    user_id: str
    user_email: Optional[str]
    team_id: str
    role: str
    is_active: bool
    created_at: datetime
    expires_at: Optional[datetime]
    last_used_at: Optional[datetime]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _generate_raw_key() -> str:
    return KEY_PREFIX + secrets.token_urlsafe(RAW_TOKEN_BYTES)


def _hash(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def _prefix_of(raw_key: str) -> str:
    return raw_key[: len(KEY_PREFIX) + 8]   # "sk-" + 8 chars


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------
async def create_key(
    session: AsyncSession,
    *,
    user_id: str,
    team_id: str,
    user_email: Optional[str] = None,
    role: str = "developer",
    expires_at: Optional[datetime] = None,
    metadata: Optional[dict] = None,
    raw_key: Optional[str] = None,           # tests can supply a fixed key
) -> IssuedKey:
    """Mint a key. Returns the raw value — store it immediately on the caller side."""
    raw = raw_key or _generate_raw_key()
    row = VirtualKey(
        key_hash=_hash(raw),
        key_prefix=_prefix_of(raw),
        user_id=user_id,
        user_email=user_email,
        team_id=team_id,
        role=role,
        expires_at=expires_at,
        metadata_json=metadata,
    )
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return IssuedKey(
        id=row.id,
        raw_key=raw,
        key_prefix=row.key_prefix,
        user_id=row.user_id,
        user_email=row.user_email,
        team_id=row.team_id,
        role=row.role,
        created_at=row.created_at,
        expires_at=row.expires_at,
    )


async def lookup_by_raw(session: AsyncSession, raw_key: str) -> Optional[KeyRecord]:
    """Resolve a presented bearer token to its key record.

    Returns ``None`` for unknown / inactive keys. Expiry is intentionally
    NOT filtered here — auth.py inspects ``expires_at`` and raises a
    specific ``401 "API key has expired"`` so the caller knows to rotate.
    Silently returning ``None`` for expired keys hides the reason.
    """
    if not raw_key.startswith(KEY_PREFIX):
        return None

    digest = _hash(raw_key)
    stmt = select(VirtualKey).where(
        VirtualKey.key_hash == digest,
        VirtualKey.is_active.is_(True),
    )
    result = await session.execute(stmt)
    row: VirtualKey | None = result.scalar_one_or_none()
    if row is None:
        return None

    return KeyRecord(
        id=row.id,
        key_prefix=row.key_prefix,
        user_id=row.user_id,
        user_email=row.user_email,
        team_id=row.team_id,
        role=row.role,
        is_active=row.is_active,
        created_at=row.created_at,
        expires_at=row.expires_at,
        last_used_at=row.last_used_at,
    )


async def mark_used(session: AsyncSession, key_id: int) -> None:
    """Best-effort last-used timestamp. Fire-and-forget from the auth path."""
    await session.execute(
        update(VirtualKey)
        .where(VirtualKey.id == key_id)
        .values(last_used_at=_now())
    )
    await session.commit()


async def revoke(session: AsyncSession, key_id: int) -> bool:
    result = await session.execute(
        update(VirtualKey)
        .where(VirtualKey.id == key_id, VirtualKey.is_active.is_(True))
        .values(is_active=False)
    )
    await session.commit()
    return result.rowcount > 0


class KeyNotFoundError(Exception):
    """Raised when a key id has no row."""


async def update_key(session: AsyncSession,
                     key_id: int,
                     *,
                     team_id: Optional[str] = None,
                     role: Optional[str] = None) -> KeyRecord:
    """Mutate an existing key. Today only ``team_id`` and ``role`` are
    operator-editable; the raw key value and its hash are immutable
    (changing them would invalidate every IDE the developer has
    configured). Caller is responsible for validating that the target
    ``team_id`` actually exists.

    Returns the updated KeyRecord. Raises KeyNotFoundError if the id
    doesn't match a row.
    """
    row: VirtualKey | None = (await session.execute(
        select(VirtualKey).where(VirtualKey.id == key_id)
    )).scalar_one_or_none()
    if row is None:
        raise KeyNotFoundError(f"key id={key_id} not found")

    changed = False
    if team_id is not None and team_id != row.team_id:
        row.team_id = team_id
        changed = True
    if role is not None and role != row.role:
        row.role = role
        changed = True
    if changed:
        await session.commit()
        await session.refresh(row)

    return KeyRecord(
        id=row.id,
        key_prefix=row.key_prefix,
        user_id=row.user_id,
        user_email=row.user_email,
        team_id=row.team_id,
        role=row.role,
        is_active=row.is_active,
        created_at=row.created_at,
        expires_at=row.expires_at,
        last_used_at=row.last_used_at,
    )


async def list_keys(
    session: AsyncSession,
    *,
    team_id: Optional[str] = None,
    include_inactive: bool = False,
) -> list[KeyRecord]:
    stmt = select(VirtualKey).order_by(VirtualKey.created_at.desc())
    if team_id is not None:
        stmt = stmt.where(VirtualKey.team_id == team_id)
    if not include_inactive:
        stmt = stmt.where(VirtualKey.is_active.is_(True))
    result = await session.execute(stmt)
    rows: list[VirtualKey] = list(result.scalars().all())
    return [
        KeyRecord(
            id=r.id,
            key_prefix=r.key_prefix,
            user_id=r.user_id,
            user_email=r.user_email,
            team_id=r.team_id,
            role=r.role,
            is_active=r.is_active,
            created_at=r.created_at,
            expires_at=r.expires_at,
            last_used_at=r.last_used_at,
        )
        for r in rows
    ]


def _now() -> datetime:
    return datetime.now(timezone.utc)
