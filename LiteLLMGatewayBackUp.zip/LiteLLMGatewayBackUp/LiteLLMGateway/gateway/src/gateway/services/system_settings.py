"""System-wide settings (kv store).

A tiny key/value layer over ``system_settings`` for UI feature flags and
single-toggle settings that don't fit the per-plugin schema model. The
value column is JSON so a setting can be a bool, a string, or a small dict.

Keys are stable; we treat the table as a singleton row per key.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import SystemSetting


# Known keys — kept centrally so a typo can't silently land in the DB.
KEY_SPEND_BY_MODEL      = "spend_by_model_enabled"
KEY_OPENROUTER_API_KEY  = "provider.openrouter.api_key"
KEY_SMTP_CONFIG         = "provider.smtp.config"

# Defaults for known keys. Used when the row doesn't exist yet.
_DEFAULTS: dict[str, Any] = {
    KEY_SPEND_BY_MODEL:     {"enabled": False},
    KEY_OPENROUTER_API_KEY: {"api_key": None},
    KEY_SMTP_CONFIG:        {
        # Empty defaults — operator fills via /settings/app or env vars.
        "host": "", "port": 587, "user": "", "password": "",
        "from_addr": "", "from_name": "OATI LLMGateway",
        "use_tls": True, "use_ssl": False,
    },
}


@dataclass(frozen=True)
class SettingRecord:
    key:        str
    value:      dict[str, Any]
    updated_at: Optional[datetime]


async def get(session: AsyncSession, key: str) -> SettingRecord:
    """Return the current value (or the registered default)."""
    stmt = select(SystemSetting).where(SystemSetting.key == key)
    row = (await session.execute(stmt)).scalar_one_or_none()
    if row is None:
        return SettingRecord(key=key,
                             value=dict(_DEFAULTS.get(key, {})),
                             updated_at=None)
    return SettingRecord(key=row.key, value=dict(row.value or {}),
                         updated_at=row.updated_at)


async def set_(session: AsyncSession, key: str,
               value: dict[str, Any]) -> SettingRecord:
    """Insert-or-update the setting. Caller commits."""
    stmt = select(SystemSetting).where(SystemSetting.key == key)
    row = (await session.execute(stmt)).scalar_one_or_none()
    if row is None:
        row = SystemSetting(key=key, value=value)
        session.add(row)
    else:
        row.value = value
    await session.commit()
    await session.refresh(row)
    return SettingRecord(key=row.key, value=dict(row.value or {}),
                         updated_at=row.updated_at)
