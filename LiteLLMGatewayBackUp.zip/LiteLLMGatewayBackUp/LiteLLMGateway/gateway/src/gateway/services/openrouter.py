"""OpenRouter integration — model catalog + key health check.

OpenRouter exposes a public ``/api/v1/models`` endpoint that returns every
model they currently serve, with pricing + context length. The gateway
wraps it so the admin UI can browse and import models without operators
hand-pasting JSON.

A small in-process TTL cache keeps OpenRouter happy under burst (the
admin UI re-fetches on every search keystroke if we let it).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional

import httpx


OPENROUTER_BASE   = "https://openrouter.ai/api/v1"
_CACHE_TTL_SEC    = 300         # 5 min
_HTTP_TIMEOUT_SEC = 15


@dataclass(frozen=True)
class CatalogModel:
    id:                  str
    name:                str
    description:         Optional[str]
    context_length:      Optional[int]
    pricing_prompt_usd_per_1k:     Optional[float]   # USD per 1000 prompt tokens
    pricing_completion_usd_per_1k: Optional[float]   # USD per 1000 completion tokens


# Single-process cache. For a multi-worker deploy this would be Redis-
# backed; on the single-worker dev box it's plenty.
_cache_at: float = 0.0
_cache:    list[CatalogModel] = []


def _parse_price(s: Optional[str]) -> Optional[float]:
    """OR returns prices as strings in USD per token. Convert to USD/1000."""
    if not s:
        return None
    try:
        return round(float(s) * 1000, 6)
    except Exception:  # noqa: BLE001
        return None


def _parse_model(d: dict[str, Any]) -> CatalogModel:
    pricing = d.get("pricing") or {}
    return CatalogModel(
        id=d.get("id", ""),
        name=d.get("name", "") or d.get("id", ""),
        description=d.get("description"),
        context_length=d.get("context_length"),
        pricing_prompt_usd_per_1k=_parse_price(pricing.get("prompt")),
        pricing_completion_usd_per_1k=_parse_price(pricing.get("completion")),
    )


async def list_models(api_key: Optional[str] = None,
                      force_refresh: bool = False) -> list[CatalogModel]:
    """Return the OpenRouter catalog. Cached for 5 minutes per process.

    The ``api_key`` argument is forwarded as a bearer token — OR returns
    the same public list either way, but the auth makes BYOK-flagged
    entries available too. Pass ``force_refresh=True`` to bypass cache.
    """
    global _cache_at, _cache
    now = time.monotonic()
    if not force_refresh and _cache and (now - _cache_at) < _CACHE_TTL_SEC:
        return _cache

    headers: dict[str, str] = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT_SEC) as client:
        resp = await client.get(f"{OPENROUTER_BASE}/models", headers=headers)
        resp.raise_for_status()
        body = resp.json()

    models = [_parse_model(m) for m in body.get("data") or []]
    _cache    = models
    _cache_at = now
    return models


async def verify_key(api_key: str) -> bool:
    """Cheap check that the key authenticates. Hits /auth/key which
    returns 200 only for valid keys."""
    async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT_SEC) as client:
        try:
            resp = await client.get(
                f"{OPENROUTER_BASE}/auth/key",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            return resp.status_code == 200
        except Exception:  # noqa: BLE001
            return False
