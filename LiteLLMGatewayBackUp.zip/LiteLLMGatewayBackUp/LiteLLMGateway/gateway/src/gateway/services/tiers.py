"""Tier-config CRUD + seed + merged-view helpers.

The shipped ``policies.yaml`` defines tiers; this service makes them
UI-editable. The on-disk YAML stays as the bootstrap source so existing
deployments don't lose their config on upgrade — the DB becomes
authoritative as soon as the first row is written.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import TierConfig


@dataclass(frozen=True)
class TierRecord:
    id: int
    tier: str
    models_allowed: list[str]
    tokens_per_day: str          # "unlimited" or integer-as-string
    rpm: int
    agent_mode: str
    override_model: bool
    description: Optional[str]
    created_at: datetime
    updated_at: datetime


class TierError(Exception): ...
class DuplicateTierError(TierError): ...
class TierNotFoundError(TierError): ...


# Known tier names that the gateway is opinionated about.
# Lets the UI render a coloured chip without an "unknown" branch for these.
KNOWN_TIERS = {"L0_readonly", "L1_standard", "L2_senior",
               "L3_privileged", "quarantined"}


async def list_tiers(session: AsyncSession) -> list[TierRecord]:
    rows = (await session.execute(
        select(TierConfig).order_by(TierConfig.tier)
    )).scalars().all()
    return [_to_record(r) for r in rows]


async def get_by_name(session: AsyncSession, tier: str) -> Optional[TierRecord]:
    row = (await session.execute(
        select(TierConfig).where(TierConfig.tier == tier)
    )).scalar_one_or_none()
    return _to_record(row) if row else None


async def create_tier(
    session: AsyncSession,
    *,
    tier: str,
    models_allowed: list[str],
    tokens_per_day: str,
    rpm: int,
    agent_mode: str,
    override_model: bool,
    description: Optional[str] = None,
) -> TierRecord:
    existing = await get_by_name(session, tier)
    if existing is not None:
        raise DuplicateTierError(f"Tier {tier!r} already exists (id={existing.id})")
    _validate(tier=tier, tokens_per_day=tokens_per_day, rpm=rpm,
              models_allowed=models_allowed)
    row = TierConfig(
        tier=tier, models_allowed=list(models_allowed),
        tokens_per_day=str(tokens_per_day), rpm=rpm, agent_mode=agent_mode,
        override_model=bool(override_model), description=description,
    )
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def update_tier(
    session: AsyncSession,
    tier_id: int,
    *,
    tier: Optional[str] = None,
    models_allowed: Optional[list[str]] = None,
    tokens_per_day: Optional[str] = None,
    rpm: Optional[int] = None,
    agent_mode: Optional[str] = None,
    override_model: Optional[bool] = None,
    description: Optional[str] = None,
) -> TierRecord:
    row = (await session.execute(
        select(TierConfig).where(TierConfig.id == tier_id)
    )).scalar_one_or_none()
    if row is None:
        raise TierNotFoundError(f"Tier id={tier_id} not found")
    if tier is not None and tier != row.tier:
        clash = await get_by_name(session, tier)
        if clash is not None and clash.id != tier_id:
            raise DuplicateTierError(f"Tier {tier!r} already exists (id={clash.id})")
        row.tier = tier
    if models_allowed is not None:
        if not isinstance(models_allowed, list):
            raise TierError("models_allowed must be a list of strings")
        row.models_allowed = list(models_allowed)
    if tokens_per_day is not None:
        _validate(tokens_per_day=str(tokens_per_day))
        row.tokens_per_day = str(tokens_per_day)
    if rpm is not None:
        _validate(rpm=rpm)
        row.rpm = rpm
    if agent_mode is not None:
        row.agent_mode = agent_mode
    if override_model is not None:
        row.override_model = bool(override_model)
    if description is not None:
        row.description = description
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def delete_tier(session: AsyncSession, tier_id: int) -> bool:
    result = await session.execute(delete(TierConfig).where(TierConfig.id == tier_id))
    await session.commit()
    return (result.rowcount or 0) > 0


# ---------------------------------------------------------------------------
# Bootstrap + merge
# ---------------------------------------------------------------------------
async def seed_from_policies(session: AsyncSession,
                             policies: dict[str, Any]) -> int:
    """Seed the table from ``policies.yaml`` on first boot. Idempotent."""
    existing = (await session.execute(select(TierConfig.id))).first()
    if existing is not None:
        return 0
    tiers = (policies or {}).get("tiers") or {}
    seeded = 0
    for tier_name, cfg in tiers.items():
        if not isinstance(cfg, dict):
            continue
        row = TierConfig(
            tier=tier_name,
            models_allowed=list(cfg.get("models_allowed") or []),
            tokens_per_day=str(cfg.get("tokens_per_day", "100000")),
            rpm=int(cfg.get("rpm", 60)),
            agent_mode=str(cfg.get("agent_mode", "tools_no_shell")),
            override_model=bool(cfg.get("override_model", False)),
            description=cfg.get("description"),
        )
        session.add(row)
        seeded += 1
    if seeded:
        await session.commit()
    return seeded


async def as_policy_tiers_dict(session: AsyncSession) -> dict[str, dict[str, Any]]:
    """Return tiers in the same shape as ``policies.yaml::tiers`` so existing
    plugins (which speak that dict) can be re-setup with no code change."""
    rows = await list_tiers(session)
    out: dict[str, dict[str, Any]] = {}
    for r in rows:
        # Convert tokens_per_day back to int when it's numeric — the existing
        # YAML allows either an int or the literal string "unlimited".
        tpd: Any = r.tokens_per_day
        if tpd != "unlimited":
            try: tpd = int(tpd)
            except (TypeError, ValueError): pass
        out[r.tier] = {
            "models_allowed": r.models_allowed,
            "tokens_per_day": tpd,
            "rpm":            r.rpm,
            "agent_mode":     r.agent_mode,
            "override_model": r.override_model,
            "description":    r.description,
        }
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _validate(*, tier: Optional[str] = None,
              tokens_per_day: Optional[str] = None,
              rpm: Optional[int] = None,
              models_allowed: Optional[list[str]] = None) -> None:
    if tier is not None and (not tier or len(tier) > 32):
        raise TierError("tier name must be 1..32 chars")
    if tokens_per_day is not None and tokens_per_day != "unlimited":
        try:
            v = int(tokens_per_day)
            if v < 0:
                raise TierError("tokens_per_day must be >= 0 or 'unlimited'")
        except (TypeError, ValueError):
            raise TierError("tokens_per_day must be an integer or 'unlimited'") from None
    if rpm is not None and rpm < 0:
        raise TierError("rpm must be >= 0")
    if models_allowed is not None and not isinstance(models_allowed, list):
        raise TierError("models_allowed must be a list of strings")


def _to_record(row: TierConfig) -> TierRecord:
    return TierRecord(
        id=row.id,
        tier=row.tier,
        models_allowed=list(row.models_allowed or []),
        tokens_per_day=row.tokens_per_day,
        rpm=row.rpm,
        agent_mode=row.agent_mode,
        override_model=bool(row.override_model),
        description=row.description,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )
