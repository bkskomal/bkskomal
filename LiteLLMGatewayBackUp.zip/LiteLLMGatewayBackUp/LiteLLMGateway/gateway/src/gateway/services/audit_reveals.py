"""4-eyes plaintext-reveal flow over encrypted audit_log rows.

Lifecycle of a request
----------------------
  request   (any admin)        status=pending
    │
    ├─► approve (different admin)   status=approved, expires_at=now+window
    │     │
    │     └─► reveal (requester only, before expires_at)
    │           plaintext returned, status=revealed (terminal)
    │
    └─► deny    (different admin)   status=denied  (terminal)

The window between approval and reveal defaults to 15 minutes — long enough
to context-switch back to the audit page and click "Show plaintext", short
enough that an attacker who later compromises the requester's session can't
replay a stale approval.

Dual-control invariants (enforced here, not just at the API layer):
    1. ``requested_by != approver_user_id`` (no self-approve)
    2. State transitions are linear — once revealed/denied/expired, the
       row is terminal and any further action returns InvalidTransition.
    3. ``reveal()`` checks ``expires_at`` against ``now()`` and flips to
       "expired" if past, returning the decrypted plaintext only when in
       a valid approved-and-not-yet-revealed state.

The service does NOT touch the audit DB — the API layer reads the
ciphertext columns from the audit row, hands them to ``reveal()`` for
verification + decryption, and returns the result.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from .. import crypto
from ..models import AuditRevealRequest


REVEAL_WINDOW_MINUTES = 15


@dataclass(frozen=True)
class RevealRecord:
    id: int
    audit_log_id: int
    requested_by: str
    requested_email: Optional[str]
    reason: str
    status: str
    requested_at: datetime
    decided_at: Optional[datetime]
    expires_at: Optional[datetime]
    revealed_at: Optional[datetime]
    approver_user_id: Optional[str]
    decision_note: Optional[str]


class RevealError(Exception): ...
class RevealNotFoundError(RevealError): ...
class SelfApprovalError(RevealError): ...
class InvalidRevealTransitionError(RevealError): ...
class NotAuthorizedToRevealError(RevealError): ...


# ---------------------------------------------------------------------------
# CRUD + state transitions
# ---------------------------------------------------------------------------
async def list_requests(
    session: AsyncSession,
    *,
    status: Optional[str] = None,
    requested_by: Optional[str] = None,
    limit: int = 100,
) -> list[RevealRecord]:
    q = select(AuditRevealRequest).order_by(desc(AuditRevealRequest.requested_at))
    if status is not None:
        q = q.where(AuditRevealRequest.status == status)
    if requested_by is not None:
        q = q.where(AuditRevealRequest.requested_by == requested_by)
    q = q.limit(limit)
    rows = (await session.execute(q)).scalars().all()
    return [_to_record(r) for r in rows]


async def get_request(session: AsyncSession, request_id: int) -> RevealRecord:
    row = await _get(session, request_id)
    return _to_record(row)


async def create_request(
    session: AsyncSession,
    *,
    audit_log_id: int,
    requested_by: str,
    requested_email: Optional[str],
    reason: str,
) -> RevealRecord:
    """Open a new reveal request. Any admin can do this for any audit row."""
    if not reason or not reason.strip():
        raise RevealError("reason cannot be empty")
    row = AuditRevealRequest(
        audit_log_id=audit_log_id,
        requested_by=requested_by,
        requested_email=requested_email,
        reason=reason.strip(),
        status="pending",
    )
    session.add(row)
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def approve(
    session: AsyncSession,
    *,
    request_id: int,
    approver_user_id: str,
    decision_note: Optional[str] = None,
) -> RevealRecord:
    row = await _get(session, request_id)
    if row.status != "pending":
        raise InvalidRevealTransitionError(
            f"Cannot approve from status {row.status!r}"
        )
    if row.requested_by == approver_user_id:
        raise SelfApprovalError("Approver cannot be the requester")
    now = _now()
    row.status            = "approved"
    row.decided_at        = now
    row.approver_user_id  = approver_user_id
    row.decision_note     = (decision_note or "").strip() or None
    row.expires_at        = now + timedelta(minutes=REVEAL_WINDOW_MINUTES)
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def deny(
    session: AsyncSession,
    *,
    request_id: int,
    approver_user_id: str,
    decision_note: Optional[str] = None,
) -> RevealRecord:
    row = await _get(session, request_id)
    if row.status != "pending":
        raise InvalidRevealTransitionError(
            f"Cannot deny from status {row.status!r}"
        )
    if row.requested_by == approver_user_id:
        raise SelfApprovalError("Approver cannot be the requester")
    row.status            = "denied"
    row.decided_at        = _now()
    row.approver_user_id  = approver_user_id
    row.decision_note     = (decision_note or "").strip() or None
    await session.commit()
    await session.refresh(row)
    return _to_record(row)


async def reveal(
    session: AsyncSession,
    *,
    request_id: int,
    requester_user_id: str,
    prompt_ciphertext: Optional[bytes],
    response_ciphertext: Optional[bytes],
) -> tuple[RevealRecord, dict[str, Optional[str]]]:
    """Decrypt the plaintext for the requester. Returns (record, plaintexts).

    Plaintexts dict:
        {"prompt": "..." | None, "response": "..." | None}
    None means the corresponding ciphertext column was empty (the team's
    policy didn't ask audit_postgres to store ciphertext for that row).

    State-machine + dual-control rules:
        * Status MUST be "approved".
        * The caller MUST be ``requested_by`` (only the requester can decrypt
          their own approved request — defence-in-depth against an attacker
          who compromises a different admin session).
        * If past ``expires_at``, status flips to "expired" and reveal fails.
        * Successful reveal flips status to "revealed" (terminal — can't be
          re-decrypted; a fresh request + approval is required).
    """
    row = await _get(session, request_id)
    if row.status == "approved" and row.expires_at and row.expires_at <= _now():
        # Lazy expiry — fold the state machine forward.
        row.status = "expired"
        await session.commit()
        await session.refresh(row)
    if row.status != "approved":
        raise InvalidRevealTransitionError(
            f"Cannot reveal from status {row.status!r}"
        )
    if row.requested_by != requester_user_id:
        raise NotAuthorizedToRevealError(
            "Only the original requester can decrypt; ask them to sign in"
        )

    plaintexts: dict[str, Optional[str]] = {"prompt": None, "response": None}
    if prompt_ciphertext:
        plaintexts["prompt"] = _decrypt_to_str(prompt_ciphertext)
    if response_ciphertext:
        plaintexts["response"] = _decrypt_to_str(response_ciphertext)

    row.status       = "revealed"
    row.revealed_at  = _now()
    await session.commit()
    await session.refresh(row)
    return _to_record(row), plaintexts


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
async def _get(session: AsyncSession, request_id: int) -> AuditRevealRequest:
    row = (await session.execute(
        select(AuditRevealRequest).where(AuditRevealRequest.id == request_id)
    )).scalar_one_or_none()
    if row is None:
        raise RevealNotFoundError(f"Reveal request id={request_id} not found")
    return row


def _decrypt_to_str(blob: bytes) -> str:
    """Decrypt + UTF-8 decode (with replacement on garbage)."""
    plain = crypto.decrypt(bytes(blob))
    return plain.decode("utf-8", errors="replace")


def _to_record(row: AuditRevealRequest) -> RevealRecord:
    return RevealRecord(
        id=row.id, audit_log_id=row.audit_log_id,
        requested_by=row.requested_by, requested_email=row.requested_email,
        reason=row.reason, status=row.status,
        requested_at=row.requested_at, decided_at=row.decided_at,
        expires_at=row.expires_at, revealed_at=row.revealed_at,
        approver_user_id=row.approver_user_id, decision_note=row.decision_note,
    )


def _now() -> datetime:
    return datetime.now(timezone.utc)
