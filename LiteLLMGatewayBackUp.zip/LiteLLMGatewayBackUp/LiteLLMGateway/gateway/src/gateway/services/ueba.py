"""UEBA service — alert CRUD + audit-log-derived digests.

Real-time signals (tally + threshold check) are computed inside the
``observe_ueba`` plugin during request flow. This service is the read /
admin side: list current alerts, ack/resolve them, and produce the daily
digest the SOC team consumes.

Digests query the AUDIT database (not the operational one) so they reflect
the immutable record of everything that happened — never desynced from
what the gateway actually let through.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

from sqlalchemy import desc, func, select, text, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import UebaAlert


@dataclass(frozen=True)
class AlertRecord:
    id: int
    raised_at: datetime
    user_id: str
    team_id: str
    tier: str
    signal: str
    severity: str
    summary: str
    details: Optional[dict[str, Any]]
    status: str
    audit_log_id: Optional[int]


# ---------------------------------------------------------------------------
# Alert CRUD (operational DB)
# ---------------------------------------------------------------------------
async def list_alerts(
    session: AsyncSession,
    *,
    status: Optional[str] = "open",
    limit: int = 100,
    since: Optional[datetime] = None,
) -> list[AlertRecord]:
    stmt = select(UebaAlert).order_by(desc(UebaAlert.raised_at)).limit(limit)
    if status is not None:
        stmt = stmt.where(UebaAlert.status == status)
    if since is not None:
        stmt = stmt.where(UebaAlert.raised_at >= since)
    rows = (await session.execute(stmt)).scalars().all()
    return [_to_record(r) for r in rows]


async def set_alert_status(session: AsyncSession, alert_id: int, *, status: str) -> bool:
    """Status transitions: open → acknowledged | resolved | false_positive."""
    if status not in {"open", "acknowledged", "resolved", "false_positive"}:
        raise ValueError(f"Invalid status {status!r}")
    result = await session.execute(
        update(UebaAlert).where(UebaAlert.id == alert_id).values(status=status)
    )
    await session.commit()
    return result.rowcount > 0


def _to_record(row: UebaAlert) -> AlertRecord:
    return AlertRecord(
        id=row.id, raised_at=row.raised_at, user_id=row.user_id,
        team_id=row.team_id, tier=row.tier, signal=row.signal,
        severity=row.severity, summary=row.summary,
        details=row.details, status=row.status,
        audit_log_id=row.audit_log_id,
    )


# ---------------------------------------------------------------------------
# Digest (audit DB) — top-N outliers in a 24-hour window.
# Uses raw SQL because we're crossing two databases (audit log) and the
# query is intentionally read-only.
# ---------------------------------------------------------------------------
async def digest_since(audit_session: AsyncSession,
                       since: datetime) -> dict[str, list[dict[str, Any]]]:
    """Return the top-5 outliers across five categories since ``since``.

    Categories:
      * tokens         — top users by total tokens (proxy for spend)
      * refusals       — top users by REFUSED requests
      * jailbreak      — top users with prompt_injection findings
      * dlp_hits       — top users with PII / secret findings (input side)
      * output_leaks   — top users with output_scan_secrets findings
    """
    rows_tokens = (await audit_session.execute(text("""
        SELECT user_id, team_id,
               COUNT(*)                       AS calls,
               COALESCE(SUM(tokens_in + tokens_out), 0) AS tokens,
               COALESCE(SUM(cost_usd), 0)              AS cost_usd
        FROM audit_log
        WHERE ts >= :since
        GROUP BY user_id, team_id
        ORDER BY tokens DESC
        LIMIT 5
    """), {"since": since})).mappings().all()

    rows_refusals = (await audit_session.execute(text("""
        SELECT user_id, team_id, COUNT(*) AS refusals
        FROM audit_log
        WHERE ts >= :since AND verdict = 'refused'
        GROUP BY user_id, team_id
        ORDER BY refusals DESC
        LIMIT 5
    """), {"since": since})).mappings().all()

    # Findings live in a JSON column. Postgres' jsonb_array_elements lets us
    # count by plugin / kind across the array.
    rows_jb = (await audit_session.execute(text("""
        SELECT user_id, team_id, COUNT(*) AS hits
        FROM audit_log, jsonb_array_elements(COALESCE(NULLIF(findings::jsonb, 'null'::jsonb), '[]'::jsonb)) f
        WHERE ts >= :since
          AND f->>'plugin' = 'guardrail_patterns'
          AND f->>'kind' LIKE 'prompt_injection.%'
        GROUP BY user_id, team_id
        ORDER BY hits DESC
        LIMIT 5
    """), {"since": since})).mappings().all()

    rows_dlp = (await audit_session.execute(text("""
        SELECT user_id, team_id, COUNT(*) AS hits
        FROM audit_log, jsonb_array_elements(COALESCE(NULLIF(findings::jsonb, 'null'::jsonb), '[]'::jsonb)) f
        WHERE ts >= :since
          AND f->>'plugin' = 'dlp_presidio'
        GROUP BY user_id, team_id
        ORDER BY hits DESC
        LIMIT 5
    """), {"since": since})).mappings().all()

    rows_leaks = (await audit_session.execute(text("""
        SELECT user_id, team_id, COUNT(*) AS hits
        FROM audit_log, jsonb_array_elements(COALESCE(NULLIF(findings::jsonb, 'null'::jsonb), '[]'::jsonb)) f
        WHERE ts >= :since
          AND f->>'plugin' = 'output_scan_secrets'
        GROUP BY user_id, team_id
        ORDER BY hits DESC
        LIMIT 5
    """), {"since": since})).mappings().all()

    return {
        "tokens":       [dict(r) for r in rows_tokens],
        "refusals":     [dict(r) for r in rows_refusals],
        "jailbreak":    [dict(r) for r in rows_jb],
        "dlp_hits":     [dict(r) for r in rows_dlp],
        "output_leaks": [dict(r) for r in rows_leaks],
    }


def yesterday_utc_start() -> datetime:
    today = datetime.now(timezone.utc).date()
    return datetime.combine(today - timedelta(days=1),
                            datetime.min.time(), tzinfo=timezone.utc)
