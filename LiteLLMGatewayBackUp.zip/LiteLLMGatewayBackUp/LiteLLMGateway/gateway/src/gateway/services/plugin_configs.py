"""Per-plugin configuration overrides + schemas.

Each plugin reads its config from ``app_settings`` at setup time. This
service:
    1. Stores operator-supplied overrides in the ``plugin_configs`` table.
    2. Exposes a schema-per-plugin so the UI can render a typed form
       instead of a raw JSON editor. The schemas live in code (this file)
       rather than the DB because they describe the *shape* of valid
       config — they change with the gateway's source, not with operator
       edits.
    3. Provides ``apply_overrides`` which merges DB rows into the policies
       dict at the right paths, so plugins keep reading the same
       ``app_settings["policies"]`` shape they've always read.

Adding a new editable plugin = (1) add a schema entry, (2) add a clause in
``apply_overrides`` for how that plugin's config maps onto the policies
dict, (3) update the plugin's setup() to read the new path (or define a
new path the UI writes to).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import PluginConfig


@dataclass(frozen=True)
class ConfigRecord:
    plugin_name: str
    config: dict[str, Any]
    updated_at: datetime


# ---------------------------------------------------------------------------
# Schemas — UI-renderable form definitions per plugin.
# ---------------------------------------------------------------------------
# Field types the UI knows how to render:
#   "bool"   -> checkbox/toggle
#   "int"    -> number input (min/max optional)
#   "float"  -> number input with step (min/max optional)
#   "string" -> text input (max_length optional)
#   "select" -> single-select dropdown (options required)
# A schema field with `key: "a.b.c"` reads/writes at the nested path
# config["a"]["b"]["c"] on the stored dict.

PLUGIN_SCHEMAS: dict[str, dict[str, Any]] = {
    "cache_redis": {
        "title": "Response Cache",
        "description":
            "Hash incoming prompts and cache the response. Reduces cost + "
            "latency dramatically on repeated prompts (Cline / Continue.dev "
            "often re-issue identical context messages).",
        "fields": [
            {"key": "enabled", "type": "bool", "default": True,
             "label": "Enabled",
             "help": "When off, every call goes straight to the model."},
            {"key": "ttl_seconds", "type": "int", "default": 600,
             "min": 30, "max": 86400, "label": "TTL (seconds)",
             "help": "How long a cached response stays valid. 600 = 10 min."},
            {"key": "skip_above_temperature", "type": "float", "default": 0.0,
             "min": 0.0, "max": 2.0, "step": 0.1,
             "label": "Skip cache when temperature greater than",
             "help": "Non-deterministic calls shouldn't be cached. 0 = "
                     "skip cache for any temperature > 0."},
        ],
    },
    "cache_semantic": {
        "title": "Semantic Response Cache",
        "description":
            "Cache hits on PARAPHRASED prompts, not just byte-identical "
            "ones. Embeds the request and matches against prior cached "
            "entries via cosine similarity. Default OFF until you point "
            "the embedding model at a provider you can reach (OpenAI for "
            "managed, Ollama for local).",
        "fields": [
            {"key": "enabled", "type": "bool", "default": False,
             "label": "Enabled",
             "help": "OFF by default — turning it on triggers an embedding "
                     "API call on every cache lookup. Configure "
                     "`embedding_model` first."},
            {"key": "similarity_threshold", "type": "float", "default": 0.95,
             "min": 0.5, "max": 1.0, "step": 0.01,
             "label": "Similarity threshold",
             "help": "Cosine similarity needed for a HIT. 0.95 = near-"
                     "identical paraphrases only; 0.85 = looser semantic "
                     "match (more hits, higher false-hit risk)."},
            {"key": "embedding_model", "type": "string",
             "default": "openai/text-embedding-3-small", "max_length": 256,
             "label": "Embedding model",
             "help": "Any model llmgateway can route — e.g. "
                     "`openai/text-embedding-3-small` (managed) or "
                     "`ollama/nomic-embed-text` (local)."},
            {"key": "max_entries_per_team", "type": "int", "default": 1000,
             "min": 10, "max": 100000,
             "label": "Max entries per team",
             "help": "LRU cap. The dev path is an in-process dict; for "
                     "production swap for pgvector / Redis HNSW."},
        ],
    },
    "observe_ueba": {
        "title": "UEBA Thresholds",
        "description":
            "Real-time behavioural signals. An alert fires the first time "
            "a user crosses the threshold within the window.",
        "fields": [
            {"key": "enabled", "type": "bool", "default": True,
             "label": "UEBA enabled"},
            # Per-signal threshold count.
            {"key": "thresholds.jailbreak_attempts.count",
             "type": "int", "default": 5, "min": 1, "max": 1000,
             "label": "Jailbreak attempts / day"},
            {"key": "thresholds.jailbreak_attempts.severity",
             "type": "select", "default": "high",
             "options": ["info", "low", "warn", "high", "critical"],
             "label": "Jailbreak alert severity"},

            {"key": "thresholds.refusal_velocity.count",
             "type": "int", "default": 10, "min": 1, "max": 1000,
             "label": "Refusals / 5-min window"},
            {"key": "thresholds.refusal_velocity.severity",
             "type": "select", "default": "high",
             "options": ["info", "low", "warn", "high", "critical"],
             "label": "Refusal-velocity alert severity"},

            {"key": "thresholds.dlp_hit_rate.count",
             "type": "int", "default": 5, "min": 1, "max": 1000,
             "label": "DLP hits / week"},
            {"key": "thresholds.dlp_hit_rate.severity",
             "type": "select", "default": "warn",
             "options": ["info", "low", "warn", "high", "critical"],
             "label": "DLP-rate alert severity"},

            {"key": "thresholds.output_secret_leaks.count",
             "type": "int", "default": 1, "min": 1, "max": 100,
             "label": "Output secret leaks / day"},
            {"key": "thresholds.output_secret_leaks.severity",
             "type": "select", "default": "critical",
             "options": ["info", "low", "warn", "high", "critical"],
             "label": "Output-leak alert severity"},

            {"key": "thresholds.elevation_self_approval_attempts.count",
             "type": "int", "default": 1, "min": 1, "max": 100,
             "label": "Self-approval attempts / day"},
            {"key": "thresholds.elevation_burst_rejections.count",
             "type": "int", "default": 3, "min": 1, "max": 100,
             "label": "Elevation burst rejections / hour"},
        ],
    },
    "output_scan_secrets": {
        "title": "Output Secret Scanner",
        "description":
            "Scans the model's response for credentials. The shipped regex "
            "set always runs; this controls the action + entropy thresholds.",
        "fields": [
            {"key": "action", "type": "select", "default": "redact",
             "options": ["redact", "refuse", "warn"],
             "label": "Action on detection",
             "help": "redact = replace with [REDACTED]; refuse = block the "
                     "response entirely; warn = log only."},
            {"key": "entropy_min_len", "type": "int", "default": 40,
             "min": 8, "max": 200,
             "label": "Min token length for entropy detector"},
            {"key": "entropy_bits_per_char", "type": "float", "default": 4.5,
             "min": 1.0, "max": 8.0, "step": 0.1,
             "label": "Entropy bits / char threshold"},
        ],
    },
    "guardrail_patterns": {
        "title": "Guardrail Actions",
        "description":
            "Top-level actions applied when the shipped or DB-added patterns "
            "fire. Banned topics + DLP patterns themselves are managed at "
            "/guardrails.",
        "fields": [
            {"key": "prompt_injection.action", "type": "select",
             "default": "refuse",
             "options": ["refuse", "warn"],
             "label": "Prompt-injection action",
             "help": "refuse = 422 + don't call the model; warn = audit only."},
            {"key": "banned_topics.action", "type": "select",
             "default": "refuse",
             "options": ["refuse", "warn"],
             "label": "Banned-topic action"},
        ],
    },
    "siem_forward": {
        "title": "SIEM Forwarder",
        "description":
            "Pushes audit events to Splunk HEC / Elastic / generic webhook. "
            "Hash-only payloads — no plaintext content ever crosses the SIEM "
            "pipe (use 4-eyes raw access for that).",
        "fields": [
            {"key": "enabled", "type": "bool", "default": True,
             "label": "Enabled"},
            {"key": "url", "type": "string", "default": "", "max_length": 1024,
             "label": "Webhook URL",
             "help": "Splunk HEC: https://splunk.example.com:8088/services/collector. "
                     "Elastic / generic: any HTTPS endpoint. Leave blank to use the "
                     "SIEM_WEBHOOK_URL env var instead."},
            {"key": "token", "type": "string", "default": "", "max_length": 512,
             "label": "Auth token",
             "help": "Splunk HEC token or Bearer token for generic. Prefer the "
                     "SIEM_AUTH_TOKEN env var to avoid storing secrets in DB."},
            {"key": "format", "type": "select", "default": "splunk_hec",
             "options": ["splunk_hec", "json"],
             "label": "Payload format",
             "help": "splunk_hec wraps event in {time, host, source, sourcetype, event}; "
                     "json sends the event flat with @timestamp."},
            {"key": "timeout_seconds", "type": "float", "default": 5.0,
             "min": 0.5, "max": 30.0, "step": 0.5,
             "label": "HTTP timeout (s)"},
        ],
    },
    "quota_redis": {
        "title": "Quota Defaults",
        "description":
            "Per-tier RPM and daily-token limits live in /policies (Tiers). "
            "This pane only controls the plugin-wide kill-switch.",
        "fields": [
            {"key": "enabled", "type": "bool", "default": True,
             "label": "Quota enforcement enabled",
             "help": "When off, rate-limit and budget checks pass through "
                     "without consuming counters. Useful for incident-time "
                     "kill-switch; do NOT leave off in steady state."},
        ],
    },
}


def schemas() -> dict[str, dict[str, Any]]:
    """The full schema map, returned to the UI."""
    return PLUGIN_SCHEMAS


def configurable_plugins() -> list[str]:
    return sorted(PLUGIN_SCHEMAS.keys())


def schema_for(plugin_name: str) -> Optional[dict[str, Any]]:
    return PLUGIN_SCHEMAS.get(plugin_name)


def default_config_for(plugin_name: str) -> dict[str, Any]:
    """Build a dict of defaults at the right nested paths, derived from
    the schema. Useful for the UI's initial-render and for tests."""
    schema = PLUGIN_SCHEMAS.get(plugin_name)
    if not schema:
        return {}
    out: dict[str, Any] = {}
    for field in schema["fields"]:
        _set_nested(out, field["key"], field["default"])
    return out


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------
async def get_config(session: AsyncSession,
                     plugin_name: str) -> Optional[ConfigRecord]:
    row = (await session.execute(
        select(PluginConfig).where(PluginConfig.plugin_name == plugin_name)
    )).scalar_one_or_none()
    if row is None:
        return None
    return ConfigRecord(
        plugin_name=row.plugin_name,
        config=row.config or {},
        updated_at=row.updated_at,
    )


async def put_config(session: AsyncSession,
                     plugin_name: str,
                     config: dict[str, Any]) -> ConfigRecord:
    """Upsert. Validates against the plugin's schema; unknown keys are
    silently dropped so a stale UI submission can't poison the config."""
    schema = PLUGIN_SCHEMAS.get(plugin_name)
    if schema is None:
        raise ValueError(f"Unknown plugin {plugin_name!r}; no schema registered")
    cleaned = _validate_and_clean(schema, config)

    row = (await session.execute(
        select(PluginConfig).where(PluginConfig.plugin_name == plugin_name)
    )).scalar_one_or_none()
    if row is None:
        row = PluginConfig(plugin_name=plugin_name, config=cleaned)
        session.add(row)
    else:
        row.config = cleaned
    await session.commit()
    await session.refresh(row)
    return ConfigRecord(
        plugin_name=row.plugin_name,
        config=row.config,
        updated_at=row.updated_at,
    )


async def list_configs(session: AsyncSession) -> dict[str, dict[str, Any]]:
    """Returns {plugin_name: config_dict} for every plugin with a row."""
    rows = (await session.execute(select(PluginConfig))).scalars().all()
    return {r.plugin_name: (r.config or {}) for r in rows}


# ---------------------------------------------------------------------------
# Merge — overlay DB config onto policies dict at the right paths.
# ---------------------------------------------------------------------------
async def apply_overrides(session: AsyncSession,
                          policies: dict[str, Any]) -> dict[str, Any]:
    """Merge DB-stored plugin configs onto a policies dict.

    Returns a NEW dict — the input is not mutated. Each plugin's stored
    config is layered onto the canonical YAML path the plugin already
    reads at setup time; this keeps the plugin code paths unchanged.

    Mapping (plugin_name -> policies path):
        cache_redis         -> policies.cache
        cache_semantic      -> policies.cache_semantic
        observe_ueba        -> policies.ueba
        output_scan_secrets -> policies.output_scan.secrets
        guardrail_patterns  -> policies.guardrails  (merged: prompt_injection.action, banned_topics.action)
        quota_redis         -> policies.quota
    """
    db_configs = await list_configs(session)
    if not db_configs:
        return policies

    out = _deep_copy(policies or {})

    if "cache_redis" in db_configs:
        out.setdefault("cache", {})
        _deep_merge(out["cache"], db_configs["cache_redis"])

    if "cache_semantic" in db_configs:
        out.setdefault("cache_semantic", {})
        _deep_merge(out["cache_semantic"], db_configs["cache_semantic"])

    if "observe_ueba" in db_configs:
        out.setdefault("ueba", {})
        _deep_merge(out["ueba"], db_configs["observe_ueba"])

    if "output_scan_secrets" in db_configs:
        out.setdefault("output_scan", {}).setdefault("secrets", {})
        _deep_merge(out["output_scan"]["secrets"], db_configs["output_scan_secrets"])

    if "guardrail_patterns" in db_configs:
        out.setdefault("guardrails", {})
        cfg = db_configs["guardrail_patterns"]
        # Only the action fields are settable from the UI; merge them in
        # without disturbing the extra_patterns / keywords that other paths
        # (DB-backed guardrail patterns service) populate.
        if "prompt_injection" in cfg:
            out["guardrails"].setdefault("prompt_injection", {})
            _deep_merge(out["guardrails"]["prompt_injection"], cfg["prompt_injection"])
        if "banned_topics" in cfg:
            out["guardrails"].setdefault("banned_topics", {})
            _deep_merge(out["guardrails"]["banned_topics"], cfg["banned_topics"])

    if "quota_redis" in db_configs:
        out.setdefault("quota", {})
        _deep_merge(out["quota"], db_configs["quota_redis"])

    if "siem_forward" in db_configs:
        out.setdefault("siem", {})
        _deep_merge(out["siem"], db_configs["siem_forward"])

    return out


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
def _validate_and_clean(schema: dict[str, Any],
                        config: dict[str, Any]) -> dict[str, Any]:
    """Walk the schema, pull each field value out of `config` at the right
    nested path, validate type + range, and assemble a cleaned dict."""
    cleaned: dict[str, Any] = {}
    for field in schema["fields"]:
        key = field["key"]
        val = _get_nested(config, key, default=None)
        if val is None:
            # Missing from submission — keep the schema default so the
            # cleaned dict is always fully populated.
            val = field["default"]
        val = _coerce(field, val)
        _set_nested(cleaned, key, val)
    return cleaned


def _coerce(field: dict[str, Any], val: Any) -> Any:
    t = field["type"]
    try:
        if t == "bool":
            return bool(val)
        if t == "int":
            v = int(val)
            if "min" in field: v = max(field["min"], v)
            if "max" in field: v = min(field["max"], v)
            return v
        if t == "float":
            v = float(val)
            if "min" in field: v = max(field["min"], v)
            if "max" in field: v = min(field["max"], v)
            return v
        if t == "string":
            v = str(val)
            if "max_length" in field:
                v = v[:field["max_length"]]
            return v
        if t == "select":
            v = str(val)
            return v if v in field.get("options", []) else field["default"]
    except (TypeError, ValueError):
        return field["default"]
    return val


def _get_nested(d: dict[str, Any], dotted: str, default: Any = None) -> Any:
    cur: Any = d
    for part in dotted.split("."):
        if not isinstance(cur, dict):
            return default
        if part not in cur:
            return default
        cur = cur[part]
    return cur


def _set_nested(d: dict[str, Any], dotted: str, val: Any) -> None:
    parts = dotted.split(".")
    cur = d
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
        if not isinstance(cur, dict):
            return                                        # caller's fault
    cur[parts[-1]] = val


def _deep_copy(d: dict[str, Any]) -> dict[str, Any]:
    import copy
    return copy.deepcopy(d)


def _deep_merge(dst: dict[str, Any], src: dict[str, Any]) -> None:
    """In-place deep merge of `src` onto `dst`."""
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _deep_merge(dst[k], v)
        else:
            dst[k] = v
