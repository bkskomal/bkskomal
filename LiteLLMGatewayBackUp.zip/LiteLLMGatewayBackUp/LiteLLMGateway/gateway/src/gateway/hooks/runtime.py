"""Hook runtime — invokes plugins at each stage and aggregates verdicts.

The contract is intentionally narrow:

  * Pre-call stage:  DLP, GUARDRAIL, then exactly one ROUTER plugin.
  * Post-call stage: OUTPUT_SCAN, then OBSERVE (UEBA / metrics), then AUDIT.

Any REFUSE verdict short-circuits the current stage and bubbles up. WARN
findings accumulate but don't block.
"""

from __future__ import annotations

import logging
from typing import Iterable

from ..plugins import GatewayPlugin, PluginKind, registry
from ..plugins.base import (
    Finding,
    HookResult,
    PluginVerdict,
    RequestContext,
    ResponseContext,
)

log = logging.getLogger(__name__)


class RefusalError(Exception):
    """Raised when a plugin returned REFUSE. Caught by FastAPI handlers."""

    def __init__(self, plugin: str, reason: str,
                 findings: list[Finding] | None = None,
                 status_code: int = 422,
                 error_code: str = "policy_refused",
                 extra_headers: dict[str, str] | None = None) -> None:
        super().__init__(reason)
        self.plugin = plugin
        self.reason = reason
        self.findings = findings or []
        self.status_code = status_code
        self.error_code = error_code
        self.extra_headers = extra_headers or {}


# ---------------------------------------------------------------------------
# Stage runners
# ---------------------------------------------------------------------------
async def run_pre_call(ctx: RequestContext) -> RequestContext:
    """AUTHZ → DLP → GUARDRAIL → ROUTER. Mutates ``ctx`` in place."""

    # 0. AUTHZ — populate allowed_models / agent_mode / override flags into
    #    ctx.extra and refuse hard-violating requests up front.
    await _run_pre_stage(ctx, registry.of_kind(PluginKind.AUTHZ))

    # 1. DLP — may redact messages; never picks a model.
    await _run_pre_stage(ctx, registry.of_kind(PluginKind.DLP))

    # 2. GUARDRAIL — may block. Same shape.
    await _run_pre_stage(ctx, registry.of_kind(PluginKind.GUARDRAIL))

    # 3. ROUTER — exactly one router decides the model.
    routers = registry.of_kind(PluginKind.ROUTER)
    if not routers:
        raise RefusalError(
            plugin="(none)",
            reason="No router plugin registered; cannot pick a model",
        )
    if len(routers) > 1:
        log.warning(
            "Multiple router plugins registered; using first: %s",
            [r.name for r in routers],
        )
    router = routers[0]
    result = await router.on_route_select(ctx)
    _merge_findings(ctx.findings, result.findings)
    if result.verdict == PluginVerdict.REFUSE:
        raise RefusalError(
            plugin=router.name,
            reason=result.reason or "Routing refused",
            findings=result.findings,
            status_code=result.status_code,
            error_code=result.error_code,
            extra_headers=result.extra_headers,
        )
    if not ctx.model_selected:
        raise RefusalError(plugin=router.name, reason="Router did not set ctx.model_selected")

    return ctx


async def run_post_call(ctx: ResponseContext) -> ResponseContext:
    """OUTPUT_SCAN → OBSERVE → AUTHZ (reconcile) → AUDIT.

    AUTHZ plugins get a second turn at post-call so quota / budget plugins can
    reconcile estimated tokens against the actual response usage.
    """
    await _run_post_stage(ctx, registry.of_kind(PluginKind.OUTPUT_SCAN))
    await _run_post_stage(ctx, registry.of_kind(PluginKind.OBSERVE))
    # AUTHZ reconcile pass — refusals here only scrub the response (the call
    # already happened) but still let plugins update their durable counters.
    await _run_post_stage(ctx, registry.of_kind(PluginKind.AUTHZ))

    # AUDIT plugins don't return verdicts — they just write durable state.
    for p in registry.of_kind(PluginKind.AUDIT):
        try:
            await p.on_audit(ctx)
        except Exception as e:  # noqa: BLE001
            log.exception("Audit plugin %s failed: %s", p.name, e)

    return ctx


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
async def _run_pre_stage(ctx: RequestContext, plugins: Iterable[GatewayPlugin]) -> None:
    for plugin in plugins:
        try:
            result: HookResult = await plugin.on_pre_call(ctx)
        except Exception as e:  # noqa: BLE001
            log.exception("Plugin %s raised in pre-call: %s", plugin.name, e)
            continue
        _merge_findings(ctx.findings, result.findings)
        if result.verdict == PluginVerdict.REFUSE:
            raise RefusalError(
                plugin=plugin.name,
                reason=result.reason or "refused",
                findings=result.findings,
                status_code=result.status_code,
                error_code=result.error_code,
                extra_headers=result.extra_headers,
            )
        # ALLOW_MUTATE / WARN: continue


async def _run_post_stage(ctx: ResponseContext, plugins: Iterable[GatewayPlugin]) -> None:
    for plugin in plugins:
        try:
            result: HookResult = await plugin.on_post_call(ctx)
        except Exception as e:  # noqa: BLE001
            log.exception("Plugin %s raised in post-call: %s", plugin.name, e)
            continue
        _merge_findings(ctx.findings, result.findings)
        if result.verdict == PluginVerdict.REFUSE:
            # Post-call refusals scrub the response but don't undo inference.
            ctx.response = {"error": result.reason or "Output blocked by policy"}


def _merge_findings(dst: list[Finding], src: list[Finding]) -> None:
    if src:
        dst.extend(src)
