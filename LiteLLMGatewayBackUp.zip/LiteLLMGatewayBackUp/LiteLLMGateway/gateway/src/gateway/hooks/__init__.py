"""Hook runtime — runs registered plugins at each request stage."""
