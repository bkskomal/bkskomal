"""HTTP API routers, grouped by domain (admin, public, etc.)."""
