"""Admin API — /admin/* routes.

All endpoints require the master key (or, future, an L3_privileged developer
token). Routes are intentionally narrow and return DTOs — no SQLAlchemy
session objects leak across the boundary.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field

from datetime import datetime, timedelta, timezone

from sqlalchemy import Integer
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from ..auth import require_admin, require_principal
from ..config import get_settings
from ..db import gateway_session
from ..plugins import registry
from ..plugins.base import Principal
from ..services import audit as audit_service
from ..services import audit_reveals as reveals_service
from ..services import elevations as elevations_service
from ..services import guardrails as guardrails_service
from ..services import keys as keys_service
from ..services import models as models_service
from ..services import plugin_configs as plugin_configs_service
from ..services import router_rules as router_rules_service
from ..services import teams as teams_service
from ..services import tiers as tiers_service
from ..services import ueba as ueba_service

log = logging.getLogger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# Pydantic DTOs
# ---------------------------------------------------------------------------
class CreateKeyRequest(BaseModel):
    user_id:    str  = Field(min_length=1, max_length=128)
    team_id:    str  = Field(min_length=1, max_length=64)
    user_email: Optional[str] = Field(default=None, max_length=255)
    role:       str  = Field(default="developer", max_length=32)
    expires_at: Optional[datetime] = None
    # Operator opt-in: when true (and user_email is set), email the
    # one-time key + IDE setup snippets to the developer. SMTP config
    # comes from system_settings (Settings → App).
    email_to_developer: bool = False


class CreatedKeyResponse(BaseModel):
    id:         int
    raw_key:    str
    key_prefix: str
    user_id:    str
    team_id:    str
    role:       str
    expires_at: Optional[datetime] = None
    warning:    str = "Save this key now — it cannot be retrieved later."
    # Populated when the operator ticked "Email to developer". email_sent
    # is True only when the SMTP send succeeded; on failure email_error
    # carries the SMTP error so the UI can surface it.
    email_sent:  bool = False
    email_error: Optional[str] = None


class KeyListItem(BaseModel):
    id:           int
    key_prefix:   str
    user_id:      str
    user_email:   Optional[str]
    team_id:      str
    role:         str
    is_active:    bool
    created_at:   datetime
    expires_at:   Optional[datetime]
    last_used_at: Optional[datetime]


class TeamRequest(BaseModel):
    team_id:     str = Field(min_length=1, max_length=64)
    tier:        str = Field(min_length=1, max_length=32)
    description: Optional[str] = Field(default=None, max_length=1024)


class TeamItem(BaseModel):
    team_id:     str
    tier:        str
    description: Optional[str]
    created_at:  datetime


# ---------------------------------------------------------------------------
# Plugins / policies
# ---------------------------------------------------------------------------
@router.get("/plugins")
async def list_plugins(principal: Principal = Depends(require_principal)) -> dict[str, Any]:
    require_admin(principal)
    return {
        "plugins": [
            {
                "name":        p.name,
                "kind":        p.kind.value,
                "version":     p.version,
                "description": p.description,
            }
            for p in registry.all()
        ]
    }


@router.get("/policies")
async def get_policies(principal: Principal = Depends(require_principal)) -> dict[str, Any]:
    require_admin(principal)
    # Lazy import to avoid circular dep with main.py's app.state.
    from ..main import app
    return app.state.policies or {}


# ---------------------------------------------------------------------------
# Per-plugin configuration — schema-driven UI editing
# ---------------------------------------------------------------------------
class PluginConfigBody(BaseModel):
    config: dict[str, Any] = Field(default_factory=dict)


@router.get("/plugins/schemas")
async def plugin_schemas(
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """Return UI form schemas for every editable plugin in one shot."""
    require_admin(principal)
    return {
        "configurable_plugins": plugin_configs_service.configurable_plugins(),
        "schemas":              plugin_configs_service.schemas(),
    }


@router.get("/plugins/{plugin_name}/config")
async def get_plugin_config(
    plugin_name: str,
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    require_admin(principal)
    schema = plugin_configs_service.schema_for(plugin_name)
    if schema is None:
        raise HTTPException(status_code=404,
                            detail=f"No editable schema for plugin {plugin_name!r}")
    async for session in gateway_session():
        rec = await plugin_configs_service.get_config(session, plugin_name)
    defaults = plugin_configs_service.default_config_for(plugin_name)
    return {
        "plugin_name": plugin_name,
        "schema":      schema,
        # `effective` is what the plugin will actually see (defaults merged
        # with any stored override). `stored` is just the raw override so the
        # UI can show whether a row exists.
        "effective":   {**defaults, **(rec.config if rec else {})},
        "stored":      (rec.config if rec else None),
        "updated_at":  (rec.updated_at.isoformat() if rec else None),
    }


@router.put("/plugins/{plugin_name}/config")
async def put_plugin_config(
    plugin_name: str,
    body: PluginConfigBody,
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    require_admin(principal)
    schema = plugin_configs_service.schema_for(plugin_name)
    if schema is None:
        raise HTTPException(status_code=404,
                            detail=f"No editable schema for plugin {plugin_name!r}")
    async for session in gateway_session():
        try:
            rec = await plugin_configs_service.put_config(
                session, plugin_name, body.config,
            )
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    # Re-setup all policy-consuming plugins so the new config is live.
    reload_info = await _reload_policy_plugins()
    log.warning("Plugin config for %r updated by %s",
                plugin_name, principal.user_id)
    return {
        "plugin_name": plugin_name,
        "stored":      rec.config,
        "updated_at":  rec.updated_at.isoformat(),
        "reload":      reload_info,
    }


# ---------------------------------------------------------------------------
# Teams
# ---------------------------------------------------------------------------
@router.get("/teams", response_model=list[TeamItem])
async def list_teams(principal: Principal = Depends(require_principal)) -> list[TeamItem]:
    require_admin(principal)
    async for session in gateway_session():
        rows = await teams_service.list_teams(session)
        return [TeamItem(**r.__dict__) for r in rows]
    return []   # unreachable; appeases the type checker


@router.put("/teams/{team_id}", response_model=TeamItem)
async def upsert_team(team_id: str, body: TeamRequest,
                      principal: Principal = Depends(require_principal)) -> TeamItem:
    require_admin(principal)
    if body.team_id != team_id:
        raise HTTPException(status_code=400, detail="team_id in body must match URL")
    async for session in gateway_session():
        rec = await teams_service.upsert_team(
            session, team_id=team_id, tier=body.tier, description=body.description,
        )
        log.warning("Team %r upserted by %s (tier=%s)",
                    team_id, principal.user_id, body.tier)
        return TeamItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.delete("/teams/{team_id}", status_code=204)
async def delete_team(team_id: str,
                      principal: Principal = Depends(require_principal)) -> None:
    """Delete a team. Refused with 409 if any *active* key still references
    it — the operator must revoke those keys first so we never orphan a
    valid bearer token's authentication context."""
    require_admin(principal)
    async for session in gateway_session():
        try:
            ok = await teams_service.delete_team(session, team_id)
        except teams_service.TeamHasActiveKeysError as e:
            raise HTTPException(
                status_code=409,
                detail={"error": "team_has_active_keys",
                        "team_id": e.team_id,
                        "active_key_count": e.count,
                        "message": str(e)},
            )
        if not ok:
            raise HTTPException(status_code=404, detail="Team not found")
        log.warning("Team %r deleted by %s", team_id, principal.user_id)
        return


# ---------------------------------------------------------------------------
# Keys
# ---------------------------------------------------------------------------
@router.post("/keys", response_model=CreatedKeyResponse, status_code=201)
async def create_key(body: CreateKeyRequest,
                     principal: Principal = Depends(require_principal)) -> CreatedKeyResponse:
    require_admin(principal)
    async for session in gateway_session():
        # Must reference an existing team; fail loudly otherwise.
        team = await teams_service.get_team(session, body.team_id)
        if team is None:
            raise HTTPException(
                status_code=400,
                detail=f"team_id {body.team_id!r} does not exist; create it first",
            )
        issued = await keys_service.create_key(
            session,
            user_id=body.user_id,
            user_email=body.user_email,
            team_id=body.team_id,
            role=body.role,
            expires_at=body.expires_at,
        )

        # Best-effort developer email — never block key issuance if SMTP
        # is misconfigured. The raw key was already returned to the
        # operator so they can hand it over manually if the email fails.
        email_sent = False
        email_error: Optional[str] = None
        if body.email_to_developer and body.user_email:
            from ..services import email as email_service
            import os as _os
            try:
                await email_service.send_key_email(
                    session,
                    to_addr=body.user_email,
                    user_id=issued.user_id,
                    team_id=issued.team_id,
                    role=issued.role,
                    raw_key=issued.raw_key,
                    key_prefix=issued.key_prefix,
                    # Public URL the developer's IDE will hit. Operators
                    # set GATEWAY_PUBLIC_URL once at deploy time so the
                    # email points at the externally-reachable address
                    # (not the in-cluster service DNS).
                    base_url=_os.environ.get("GATEWAY_PUBLIC_URL", "http://localhost:4000"),
                    default_model="kimi-k2.6",
                    expires_at=(issued.expires_at.isoformat()
                                if issued.expires_at else None),
                )
                email_sent = True
            except Exception as e:                                       # noqa: BLE001
                email_error = str(e)
                log.exception("Failed to email new key id=%d to %s",
                              issued.id, body.user_email)

        return CreatedKeyResponse(
            id=issued.id,
            raw_key=issued.raw_key,
            key_prefix=issued.key_prefix,
            user_id=issued.user_id,
            team_id=issued.team_id,
            role=issued.role,
            expires_at=issued.expires_at,
            email_sent=email_sent,
            email_error=email_error,
        )
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.get("/keys", response_model=list[KeyListItem])
async def list_keys(
    principal: Principal = Depends(require_principal),
    team_id:        Optional[str] = Query(default=None),
    include_inactive: bool         = Query(default=False),
) -> list[KeyListItem]:
    require_admin(principal)
    async for session in gateway_session():
        rows = await keys_service.list_keys(
            session, team_id=team_id, include_inactive=include_inactive,
        )
        return [KeyListItem(**r.__dict__) for r in rows]
    return []


class UpdateKeyRequest(BaseModel):
    """Patch body for /admin/keys/{key_id}. Only operator-editable fields
    are exposed; the raw key + its hash are immutable for the life of the
    record so an in-use bearer token never silently changes meaning."""
    team_id: Optional[str] = Field(default=None, min_length=1, max_length=64)
    role:    Optional[str] = Field(default=None, max_length=32)


@router.patch("/keys/{key_id}", response_model=KeyListItem)
async def update_key(key_id: int,
                     body: UpdateKeyRequest,
                     principal: Principal = Depends(require_principal)) -> KeyListItem:
    """Mutate an existing virtual key. Today the only editable fields are
    ``team_id`` (reassign the developer's key to a different team — picks
    up that team's tier on the next request) and ``role``. The bearer
    token value itself is immutable."""
    require_admin(principal)
    async for session in gateway_session():
        # Validate target team exists when changing it.
        if body.team_id is not None:
            team = await teams_service.get_team(session, body.team_id)
            if team is None:
                raise HTTPException(
                    status_code=400,
                    detail=f"team_id {body.team_id!r} does not exist; create it first",
                )
        try:
            rec = await keys_service.update_key(
                session, key_id,
                team_id=body.team_id,
                role=body.role,
            )
        except keys_service.KeyNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        log.warning("Updated virtual key id=%d by %s (team=%s, role=%s)",
                    key_id, principal.user_id, body.team_id, body.role)
        return KeyListItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.delete("/keys/{key_id}", status_code=204)
async def revoke_key(key_id: int,
                     principal: Principal = Depends(require_principal)) -> None:
    """Revoke (deactivate) a virtual key.

    Idempotent per RFC 9110: the final state ("no active key with this id")
    is the same whether the key was just revoked, was already inactive, or
    never existed. Always returns 204 — distinguishing these three cases
    in HTTP status confused operator tooling (the UI re-rendered a stale
    row and the 404 looked like a real error).
    """
    require_admin(principal)
    async for session in gateway_session():
        ok = await keys_service.revoke(session, key_id)
        if ok:
            log.warning("Revoked virtual key id=%d by %s", key_id, principal.user_id)
        return


# ---------------------------------------------------------------------------
# Quotas
# ---------------------------------------------------------------------------
@router.get("/quotas")
async def view_quotas(principal: Principal = Depends(require_principal)) -> dict[str, Any]:
    """Snapshot current RPM + daily token usage per team."""
    require_admin(principal)
    from ..plugins import PluginKind
    plugins = [p for p in registry.of_kind(PluginKind.AUTHZ) if p.name == "quota_redis"]
    if not plugins:
        return {"enabled": False, "teams": {}}
    quota = plugins[0]
    snap  = await quota.usage_snapshot()

    # Enrich with team list + tier limits so the UI can render % bars.
    async for session in gateway_session():
        teams = await teams_service.list_teams(session)
        break
    from ..main import app
    tiers = (app.state.policies or {}).get("tiers") or {}
    enriched: dict[str, Any] = {}
    for t in teams:
        tier_cfg = tiers.get(t.tier) or {}
        live     = await quota.usage_for_team(t.team_id)
        enriched[t.team_id] = {
            "tier":          t.tier,
            "rpm_limit":     tier_cfg.get("rpm"),
            "rpm_used":      live["rpm"],
            "daily_limit":   tier_cfg.get("tokens_per_day"),
            "tokens_today":  live["tokens_today"],
        }
    return {"enabled": True, "today": snap.get("today"),
            "minute": snap.get("minute"), "teams": enriched}


@router.post("/quotas/{team_id}/reset", status_code=200)
async def reset_quotas(team_id: str,
                       principal: Principal = Depends(require_principal)) -> dict[str, Any]:
    """Wipe RPM + daily counters for a team. Audited via the audit-log table."""
    require_admin(principal)
    from ..plugins import PluginKind
    plugins = [p for p in registry.of_kind(PluginKind.AUTHZ) if p.name == "quota_redis"]
    if not plugins:
        raise HTTPException(status_code=409, detail="quota_redis plugin not loaded")
    n = await plugins[0].reset_team(team_id)
    log.warning("Quota reset by %s for team=%s (%d counter(s) cleared)",
                principal.user_id, team_id, n)
    return {"team_id": team_id, "counters_cleared": n}


# ---------------------------------------------------------------------------
# UEBA — live alerts + per-user state + 24h digest
# ---------------------------------------------------------------------------
@router.get("/ueba/alerts")
async def list_ueba_alerts(
    principal: Principal = Depends(require_principal),
    status:    str         = Query(default="open"),
    limit:     int         = Query(default=100, ge=1, le=1000),
) -> dict[str, Any]:
    """Open / acknowledged / resolved alerts from the operational DB."""
    require_admin(principal)
    async for session in gateway_session():
        rows = await ueba_service.list_alerts(session, status=status, limit=limit)
    return {
        "status_filter": status,
        "count":         len(rows),
        "alerts": [
            {
                "id":         r.id,
                "raised_at":  r.raised_at.isoformat(),
                "user_id":    r.user_id,
                "team_id":    r.team_id,
                "tier":       r.tier,
                "signal":     r.signal,
                "severity":   r.severity,
                "summary":    r.summary,
                "details":    r.details,
                "status":     r.status,
            }
            for r in rows
        ],
    }


@router.post("/ueba/alerts/{alert_id}/{action}", status_code=200)
async def update_ueba_alert(alert_id: int, action: str,
                            principal: Principal = Depends(require_principal)
                            ) -> dict[str, Any]:
    """Transition an alert: acknowledge, resolve, false_positive."""
    require_admin(principal)
    mapping = {
        "acknowledge":    "acknowledged",
        "resolve":        "resolved",
        "false-positive": "false_positive",
        "reopen":         "open",
    }
    new_status = mapping.get(action)
    if new_status is None:
        raise HTTPException(status_code=400, detail=f"Unknown action {action!r}")
    async for session in gateway_session():
        ok = await ueba_service.set_alert_status(session, alert_id, status=new_status)
        if not ok:
            raise HTTPException(status_code=404, detail="Alert not found")
    log.warning("UEBA alert %d → %s by %s", alert_id, new_status, principal.user_id)
    return {"id": alert_id, "status": new_status}


@router.get("/ueba/user/{user_id}")
async def user_state(user_id: str,
                     principal: Principal = Depends(require_principal)) -> dict[str, Any]:
    """Real-time counter snapshot for a single user (from observe_ueba)."""
    require_admin(principal)
    from ..plugins import PluginKind
    plugins = [p for p in registry.of_kind(PluginKind.OBSERVE) if p.name == "observe_ueba"]
    if not plugins:
        return {"enabled": False, "user_id": user_id}
    state = await plugins[0].state_for_user(user_id)
    return {"enabled": True, "user_id": user_id, **state}


@router.get("/ueba/user/{user_id}/radar")
async def user_radar(
    user_id: str,
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """10-signal behavioural radar — for the SOC's "is this user behaving
    unusually right now?" glance. Each axis is normalised 0..100; 100
    means the alert threshold has been crossed."""
    require_admin(principal)
    from ..plugins import PluginKind
    plugins = [p for p in registry.of_kind(PluginKind.OBSERVE) if p.name == "observe_ueba"]
    if not plugins:
        return {"enabled": False, "user_id": user_id}
    return await plugins[0].radar_for_user(user_id)


@router.get("/ueba/user/{user_id}/baseline")
async def user_baseline(
    user_id: str,
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """Per-user 7-day rolling baseline: tokens by hour-of-day + model mix.

    Used by /monitoring to render the "is this user behaving normally?"
    drill-down — operators spot outliers like 4am traffic or sudden
    premium-model preference at a glance.
    """
    require_admin(principal)
    from ..plugins import PluginKind
    plugins = [p for p in registry.of_kind(PluginKind.OBSERVE) if p.name == "observe_ueba"]
    if not plugins:
        return {"enabled": False, "user_id": user_id}
    return await plugins[0].baseline_for_user(user_id)


# ---------------------------------------------------------------------------
# Auto-quarantine — restore (re-arm) a user's keys after manual review
# ---------------------------------------------------------------------------
class RestoreKeysBody(BaseModel):
    decision_note: Optional[str] = Field(default=None, max_length=512)


@router.post("/ueba/user/{user_id}/restore-keys", status_code=200)
async def restore_quarantined_keys(
    user_id: str,
    body: RestoreKeysBody,
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """Re-activate every key for ``user_id`` that auto-quarantine had
    deactivated. The breaker is single-direction: trip is automatic,
    rearm is a SOC engineer's deliberate choice (audited via the
    decision_note + the admin's user_id in the gateway log)."""
    require_admin(principal)
    from sqlalchemy import update as _update
    from ..models import VirtualKey
    n = 0
    async for session in gateway_session():
        res = await session.execute(
            _update(VirtualKey)
            .where(VirtualKey.user_id == user_id,
                   VirtualKey.is_active.is_(False))
            .values(is_active=True)
        )
        n = res.rowcount or 0
        await session.commit()
        break
    # Drop the in-memory quarantine flag so a future trip can fire again.
    from ..plugins import PluginKind as _PK
    for p in registry.of_kind(_PK.OBSERVE):
        if p.name == "observe_ueba" and getattr(p, "_counters", None):
            try:
                # Force-expire by setting a 1s TTL on a 0 increment-equivalent.
                # Different stores expose this differently; the cleanest cross-
                # store hack is to set the value to 0 with a 1-second TTL.
                store = p._counters
                if hasattr(store, "_v") and hasattr(store, "_x"):
                    store._v.pop(f"ueba:quarantined:{user_id}", None)
                    store._x.pop(f"ueba:quarantined:{user_id}", None)
            except Exception:                            # noqa: BLE001
                pass
    log.warning("Quarantine cleared for user=%s by %s — %d key(s) re-activated. "
                "Note: %s", user_id, principal.user_id, n,
                body.decision_note or "(none)")
    return {
        "user_id":          user_id,
        "keys_reactivated": n,
        "cleared_by":       principal.user_id,
        "decision_note":    body.decision_note,
    }


@router.get("/ueba/digest")
async def daily_digest(
    principal: Principal = Depends(require_principal),
    hours:     int        = Query(default=24, ge=1, le=168),
) -> dict[str, Any]:
    """Top-N outliers across categories over the last ``hours`` (default 24).

    Read straight off the immutable ``audit_log`` so the digest can never
    drift from what the gateway actually let through.
    """
    require_admin(principal)
    settings = get_settings()
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    since = datetime.now(timezone.utc) - timedelta(hours=hours)
    try:
        async with SessionLocal() as session:
            result = await ueba_service.digest_since(session, since)
    finally:
        await engine.dispose()
    return {
        "since":       since.isoformat(),
        "hours":       hours,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "outliers":    result,
    }


# ---------------------------------------------------------------------------
# Tier configs — CRUD + plugin hot-reload
# ---------------------------------------------------------------------------
class TierBody(BaseModel):
    tier:           str  = Field(min_length=1, max_length=32)
    models_allowed: list[str]
    tokens_per_day: str  = Field(default="100000", max_length=16)   # int-as-string or "unlimited"
    rpm:            int  = Field(default=60, ge=0, le=100_000)
    agent_mode:     str  = Field(default="tools_no_shell", max_length=32)
    override_model: bool = False
    description:    Optional[str] = Field(default=None, max_length=1024)


class TierPatch(BaseModel):
    tier:           Optional[str]        = Field(default=None, max_length=32)
    models_allowed: Optional[list[str]]  = None
    tokens_per_day: Optional[str]        = Field(default=None, max_length=16)
    rpm:            Optional[int]        = Field(default=None, ge=0, le=100_000)
    agent_mode:     Optional[str]        = Field(default=None, max_length=32)
    override_model: Optional[bool]       = None
    description:    Optional[str]        = Field(default=None, max_length=1024)


class TierItem(BaseModel):
    id: int
    tier: str
    models_allowed: list[str]
    tokens_per_day: str
    rpm: int
    agent_mode: str
    override_model: bool
    description: Optional[str] = None
    created_at: datetime
    updated_at: datetime


async def _reload_policy_plugins() -> dict[str, Any]:
    """Trigger main.reload_policy_consumers() and return its result."""
    from ..main import reload_policy_consumers
    return await reload_policy_consumers()


@router.get("/tiers", response_model=list[TierItem])
async def list_tiers(
    principal: Principal = Depends(require_principal),
) -> list[TierItem]:
    require_admin(principal)
    async for session in gateway_session():
        rows = await tiers_service.list_tiers(session)
        return [TierItem(**r.__dict__) for r in rows]
    return []


@router.post("/tiers", response_model=TierItem, status_code=201)
async def create_tier(
    body: TierBody,
    principal: Principal = Depends(require_principal),
) -> TierItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await tiers_service.create_tier(
                session,
                tier=body.tier,
                models_allowed=body.models_allowed,
                tokens_per_day=body.tokens_per_day,
                rpm=body.rpm,
                agent_mode=body.agent_mode,
                override_model=body.override_model,
                description=body.description,
            )
        except tiers_service.DuplicateTierError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except tiers_service.TierError as e:
            raise HTTPException(status_code=400, detail=str(e))
        await _reload_policy_plugins()
        log.warning("Tier %r created by %s", rec.tier, principal.user_id)
        return TierItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.patch("/tiers/{tier_id}", response_model=TierItem)
async def update_tier(
    tier_id: int,
    body: TierPatch,
    principal: Principal = Depends(require_principal),
) -> TierItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await tiers_service.update_tier(
                session, tier_id,
                tier=body.tier,
                models_allowed=body.models_allowed,
                tokens_per_day=body.tokens_per_day,
                rpm=body.rpm,
                agent_mode=body.agent_mode,
                override_model=body.override_model,
                description=body.description,
            )
        except tiers_service.TierNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except tiers_service.DuplicateTierError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except tiers_service.TierError as e:
            raise HTTPException(status_code=400, detail=str(e))
        await _reload_policy_plugins()
        return TierItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.delete("/tiers/{tier_id}", status_code=204)
async def delete_tier(
    tier_id: int,
    principal: Principal = Depends(require_principal),
) -> None:
    require_admin(principal)
    async for session in gateway_session():
        ok = await tiers_service.delete_tier(session, tier_id)
        if not ok:
            raise HTTPException(status_code=404, detail="Tier not found")
        await _reload_policy_plugins()
        log.warning("Tier id=%d deleted by %s", tier_id, principal.user_id)
        return


# ---------------------------------------------------------------------------
# Guardrail / DLP / output-scan extras — CRUD + plugin hot-reload
# ---------------------------------------------------------------------------
class PatternBody(BaseModel):
    kind:       str  = Field(max_length=32)        # banned_topic | dlp_extra | output_scan_extra
    name:       str  = Field(min_length=1, max_length=128)
    pattern:    str  = Field(min_length=1)
    severity:   str  = Field(default="warn", max_length=16)
    action:     str  = Field(default="refuse", max_length=16)
    is_active:  bool = True
    created_by: Optional[str] = Field(default=None, max_length=128)
    notes:      Optional[str] = None


class PatternPatch(BaseModel):
    name:      Optional[str]  = Field(default=None, max_length=128)
    pattern:   Optional[str]  = None
    severity:  Optional[str]  = Field(default=None, max_length=16)
    action:    Optional[str]  = Field(default=None, max_length=16)
    is_active: Optional[bool] = None
    notes:     Optional[str]  = None


class PatternItem(BaseModel):
    id:         int
    kind:       str
    name:       str
    pattern:    str
    severity:   str
    action:     str
    is_active:  bool
    created_by: Optional[str] = None
    notes:      Optional[str] = None
    created_at: datetime
    updated_at: datetime


@router.get("/guardrails/patterns", response_model=list[PatternItem])
async def list_guardrail_patterns(
    principal: Principal = Depends(require_principal),
    kind: Optional[str]  = Query(default=None, max_length=32),
    include_inactive: bool = Query(default=True),
) -> list[PatternItem]:
    require_admin(principal)
    async for session in gateway_session():
        rows = await guardrails_service.list_patterns(
            session, kind=kind, include_inactive=include_inactive,
        )
        return [PatternItem(**r.__dict__) for r in rows]
    return []


@router.post("/guardrails/patterns", response_model=PatternItem, status_code=201)
async def create_guardrail_pattern(
    body: PatternBody,
    principal: Principal = Depends(require_principal),
) -> PatternItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await guardrails_service.create_pattern(
                session,
                kind=body.kind, name=body.name, pattern=body.pattern,
                severity=body.severity, action=body.action,
                is_active=body.is_active,
                created_by=body.created_by or principal.user_id,
                notes=body.notes,
            )
        except guardrails_service.GuardrailError as e:
            raise HTTPException(status_code=400, detail=str(e))
        await _reload_policy_plugins()
        log.warning("Pattern %r (%s) created by %s",
                    rec.name, rec.kind, principal.user_id)
        return PatternItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.patch("/guardrails/patterns/{pattern_id}", response_model=PatternItem)
async def update_guardrail_pattern(
    pattern_id: int,
    body: PatternPatch,
    principal: Principal = Depends(require_principal),
) -> PatternItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await guardrails_service.update_pattern(
                session, pattern_id,
                name=body.name, pattern=body.pattern, severity=body.severity,
                action=body.action, is_active=body.is_active, notes=body.notes,
            )
        except guardrails_service.PatternNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except guardrails_service.GuardrailError as e:
            raise HTTPException(status_code=400, detail=str(e))
        await _reload_policy_plugins()
        return PatternItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.delete("/guardrails/patterns/{pattern_id}", status_code=204)
async def delete_guardrail_pattern(
    pattern_id: int,
    principal: Principal = Depends(require_principal),
) -> None:
    require_admin(principal)
    async for session in gateway_session():
        ok = await guardrails_service.delete_pattern(session, pattern_id)
        if not ok:
            raise HTTPException(status_code=404, detail="Pattern not found")
        await _reload_policy_plugins()
        return


@router.post("/policies/reload", status_code=200)
async def reload_policies(
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """Manually re-merge YAML + DB and re-setup all policy-consuming plugins."""
    require_admin(principal)
    return await _reload_policy_plugins()


# ---------------------------------------------------------------------------
# Models — CRUD + hot reload of the LiteLLM Router
# ---------------------------------------------------------------------------
class ModelBody(BaseModel):
    model_config = {"protected_namespaces": ()}   # silence pydantic re: model_ fields
    model_name:     str  = Field(min_length=1, max_length=64)
    litellm_params: dict[str, Any]
    model_info:     Optional[dict[str, Any]] = None
    enabled:        bool = True
    provider:       Optional[str] = Field(default=None, max_length=32)


class ModelPatch(BaseModel):
    model_config = {"protected_namespaces": ()}
    model_name:     Optional[str]                = Field(default=None, max_length=64)
    litellm_params: Optional[dict[str, Any]]     = None
    model_info:     Optional[dict[str, Any]]     = None
    enabled:        Optional[bool]               = None
    provider:       Optional[str]                = Field(default=None, max_length=32)


class ModelItem(BaseModel):
    model_config = {"protected_namespaces": ()}
    id:             int
    model_name:     str
    provider:       str
    enabled:        bool
    litellm_params: dict[str, Any]
    model_info:     Optional[dict[str, Any]] = None
    created_at:     datetime
    updated_at:     datetime


async def _reload_router_from_db() -> int:
    """Rebuild the in-memory LiteLLM Router from the DB.

    Called after every write so the live gateway picks up the change without
    a process restart. Returns the number of models loaded.
    """
    from ..main import app
    async for session in gateway_session():
        model_list = await models_service.to_router_model_list(session)
        break
    try:
        from llmgateway.litellm_compat import Router
        app.state.litellm_router = Router(model_list=model_list) if model_list else None
    except Exception as e:                                        # noqa: BLE001
        log.warning("Router rebuild failed: %s", e)
        app.state.litellm_router = None
    return len(model_list)


@router.get("/models", response_model=list[ModelItem])
async def list_models(
    principal: Principal = Depends(require_principal),
    include_disabled: bool = Query(default=True),
) -> list[ModelItem]:
    require_admin(principal)
    async for session in gateway_session():
        rows = await models_service.list_models(session, include_disabled=include_disabled)
        return [ModelItem(**r.__dict__) for r in rows]
    return []


@router.post("/models", response_model=ModelItem, status_code=201)
async def create_model(
    body: ModelBody,
    principal: Principal = Depends(require_principal),
) -> ModelItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await models_service.create_model(
                session,
                model_name=body.model_name,
                litellm_params=body.litellm_params,
                model_info=body.model_info,
                enabled=body.enabled,
                provider=body.provider,
            )
        except models_service.DuplicateModelError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except models_service.ModelError as e:
            raise HTTPException(status_code=400, detail=str(e))
        await _reload_router_from_db()
        log.warning("Model %r created by %s", rec.model_name, principal.user_id)
        return ModelItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.patch("/models/{model_id}", response_model=ModelItem)
async def update_model(
    model_id: int,
    body: ModelPatch,
    principal: Principal = Depends(require_principal),
) -> ModelItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await models_service.update_model(
                session, model_id,
                model_name=body.model_name,
                litellm_params=body.litellm_params,
                model_info=body.model_info,
                enabled=body.enabled,
                provider=body.provider,
            )
        except models_service.ModelNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except models_service.DuplicateModelError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except models_service.ModelError as e:
            raise HTTPException(status_code=400, detail=str(e))
        await _reload_router_from_db()
        return ModelItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.delete("/models/{model_id}", status_code=204)
async def delete_model(
    model_id: int,
    principal: Principal = Depends(require_principal),
) -> None:
    require_admin(principal)
    async for session in gateway_session():
        ok = await models_service.delete_model(session, model_id)
        if not ok:
            raise HTTPException(status_code=404, detail="Model not found")
        await _reload_router_from_db()
        log.warning("Model id=%d deleted by %s", model_id, principal.user_id)
        return


@router.post("/models/reload", status_code=200)
async def reload_models(
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """Manually trigger a Router rebuild from the DB. Useful after a
    direct YAML edit or a manual SQL change on the litellm_models table."""
    require_admin(principal)
    n = await _reload_router_from_db()
    return {"ok": True, "models_loaded": n}


class ModelPingResponse(BaseModel):
    model_id:   int
    model_name: str
    ok:         bool
    latency_ms: float
    error:      Optional[str] = None


@router.post("/models/{model_id}/ping", response_model=ModelPingResponse)
async def ping_model(
    model_id: int,
    principal: Principal = Depends(require_principal),
) -> ModelPingResponse:
    """One-shot availability probe.

    Sends a 1-token completion through the active Router using *just* this
    model so a flaky backend (Ollama down, key revoked) is surfaced clearly
    on the /settings page without a full chat request. Bypasses plugins
    entirely — this is operator diagnostics, not a billable call.
    """
    require_admin(principal)
    import time as _time
    from ..main import app

    async for session in gateway_session():
        try:
            rec = await models_service.get_model(session, model_id)
        except models_service.ModelNotFoundError:
            raise HTTPException(status_code=404, detail="Model not found")
        model_name = rec.model_name
        break

    router_obj = getattr(app.state, "litellm_router", None)
    if router_obj is None:
        raise HTTPException(status_code=503, detail="Router not initialised")

    started = _time.monotonic()
    try:
        # NOTE: don't pin `temperature=0.0`. Some hosted models (Moonshot's
        # Kimi K2.6 in particular) reject any value other than 1 with
        # `invalid_request_error: only 1 is allowed for this model`. Letting
        # the upstream pick its default keeps ping universally compatible —
        # we only care whether the call succeeds, not what it returns.
        await router_obj.acompletion(
            model=model_name,
            messages=[{"role": "user", "content": "ping"}],
            max_tokens=1,
            stream=False,
        )
        elapsed = (_time.monotonic() - started) * 1000
        return ModelPingResponse(
            model_id=model_id, model_name=model_name,
            ok=True, latency_ms=round(elapsed, 1),
        )
    except Exception as e:  # noqa: BLE001
        elapsed = (_time.monotonic() - started) * 1000
        log.warning("Model ping failed id=%d name=%s err=%s", model_id, model_name, e)
        return ModelPingResponse(
            model_id=model_id, model_name=model_name,
            ok=False, latency_ms=round(elapsed, 1),
            error=str(e)[:500],
        )


# ---------------------------------------------------------------------------
# Metrics details — for the /metrics dashboard
# ---------------------------------------------------------------------------
class ModelLatency(BaseModel):
    model: str
    count: int
    avg_ms: float
    p50_ms: float
    p95_ms: float
    p99_ms: float


class TeamSpend(BaseModel):
    team_id:        str
    tier:           Optional[str]   = None
    tokens_in:      int
    tokens_out:     int
    tokens_total:   int
    cost_usd:       float
    daily_limit:    Optional[int]   = None    # None = unlimited
    pct_used:       Optional[float] = None    # 0..100 vs daily_limit, None if unlimited


class PluginErrorCount(BaseModel):
    plugin: str
    refused_count: int
    last_refusal_at: Optional[datetime] = None


class FindingMixEntry(BaseModel):
    kind: str
    count: int


class MetricsDetailsResponse(BaseModel):
    window_minutes:   int
    generated_at:     datetime
    latency_by_model: list[ModelLatency]
    spend_by_team:    list[TeamSpend]
    plugin_errors:    list[PluginErrorCount]
    finding_mix:      list[FindingMixEntry]


@router.get("/metrics/details", response_model=MetricsDetailsResponse)
async def metrics_details(
    principal: Principal = Depends(require_principal),
    window_minutes: int = Query(default=60, ge=1, le=7 * 24 * 60),
) -> MetricsDetailsResponse:
    """Deeper rollup for the /metrics page: per-model latency percentiles,
    per-team spend vs tier budget, per-plugin error counts, finding mix."""
    require_admin(principal)
    settings = get_settings()

    # Load tier budgets from the merged policies dict so the % consumed
    # reflects whatever the operator has set (DB overlay if present).
    from ..main import app
    tiers_cfg = (app.state.policies or {}).get("tiers") or {}

    audit_engine = create_async_engine(settings.audit_db_url, future=True)
    AuditSession = async_sessionmaker(audit_engine, expire_on_commit=False)
    now = datetime.now(timezone.utc)
    since = now - timedelta(minutes=window_minutes)
    try:
        async with AuditSession() as session:
            rows = await audit_service.search(
                session, since=since, before_id=None, limit=10_000,
            )
    finally:
        await audit_engine.dispose()

    # Per-model latency
    by_model: dict[str, list[float]] = {}
    for r in rows:
        if r.model_used:
            by_model.setdefault(r.model_used, []).append(r.latency_ms or 0.0)

    def _pct(s: list[float], p: float) -> float:
        if not s:
            return 0.0
        idx = max(0, min(len(s) - 1, int(round((p / 100.0) * (len(s) - 1)))))
        return round(s[idx], 2)

    latency_by_model: list[ModelLatency] = []
    for m, lats in by_model.items():
        s = sorted(lats)
        latency_by_model.append(ModelLatency(
            model=m,
            count=len(s),
            avg_ms=round(sum(s) / len(s), 2),
            p50_ms=_pct(s, 50),
            p95_ms=_pct(s, 95),
            p99_ms=_pct(s, 99),
        ))
    latency_by_model.sort(key=lambda x: x.count, reverse=True)

    # Per-team spend vs tier daily limit
    # Look up each team's tier from the operational DB so we can compare against tier limits.
    team_tier: dict[str, str] = {}
    async for op_session in gateway_session():
        teams_rows = await teams_service.list_teams(op_session)
        team_tier = {t.team_id: t.tier for t in teams_rows}
        break

    by_team: dict[str, dict[str, Any]] = {}
    for r in rows:
        team = r.team_id or "unknown"
        slot = by_team.setdefault(team, {
            "tokens_in": 0, "tokens_out": 0, "cost_usd": 0.0,
        })
        slot["tokens_in"]  += r.tokens_in  or 0
        slot["tokens_out"] += r.tokens_out or 0
        slot["cost_usd"]   += r.cost_usd   or 0.0

    spend_by_team: list[TeamSpend] = []
    for team, slot in by_team.items():
        tier = team_tier.get(team)
        tier_cfg = tiers_cfg.get(tier or "") if tier else None
        raw_limit = (tier_cfg or {}).get("tokens_per_day")
        daily_limit: Optional[int] = None
        if isinstance(raw_limit, int):
            daily_limit = raw_limit
        elif isinstance(raw_limit, str) and raw_limit != "unlimited":
            try: daily_limit = int(raw_limit)
            except ValueError: daily_limit = None
        total = slot["tokens_in"] + slot["tokens_out"]
        pct_used: Optional[float] = None
        if daily_limit and daily_limit > 0:
            pct_used = round(min(100.0, (total / daily_limit) * 100.0), 1)
        spend_by_team.append(TeamSpend(
            team_id=team, tier=tier,
            tokens_in=slot["tokens_in"], tokens_out=slot["tokens_out"],
            tokens_total=total,
            cost_usd=round(slot["cost_usd"], 6),
            daily_limit=daily_limit, pct_used=pct_used,
        ))
    spend_by_team.sort(key=lambda x: x.tokens_total, reverse=True)

    # Per-plugin error count — derive from findings on refused rows.
    plugin_err: dict[str, dict[str, Any]] = {}
    for r in rows:
        if r.verdict != "refused" or not r.findings:
            continue
        for f in r.findings:
            plugin = f.get("plugin") or "unknown"
            slot = plugin_err.setdefault(plugin, {"count": 0, "last_ts": None})
            slot["count"] += 1
            if slot["last_ts"] is None or (r.ts and r.ts > slot["last_ts"]):
                slot["last_ts"] = r.ts
    plugin_errors = sorted(
        (PluginErrorCount(plugin=p, refused_count=v["count"],
                          last_refusal_at=v["last_ts"])
         for p, v in plugin_err.items()),
        key=lambda x: x.refused_count, reverse=True,
    )

    # Finding mix across all rows in window
    kind_counts: dict[str, int] = {}
    for r in rows:
        for f in (r.findings or []):
            k = f.get("kind") or "unknown"
            kind_counts[k] = kind_counts.get(k, 0) + 1
    finding_mix = sorted(
        (FindingMixEntry(kind=k, count=v) for k, v in kind_counts.items()),
        key=lambda x: x.count, reverse=True,
    )[:20]

    return MetricsDetailsResponse(
        window_minutes=window_minutes,
        generated_at=now,
        latency_by_model=latency_by_model,
        spend_by_team=spend_by_team,
        plugin_errors=plugin_errors,
        finding_mix=finding_mix,
    )


# ---------------------------------------------------------------------------
# 4-eyes audit reveal — request, approve, deny, fetch plaintext
# ---------------------------------------------------------------------------
class RevealRequestBody(BaseModel):
    reason: str = Field(min_length=1, max_length=1024)


class RevealDecisionBody(BaseModel):
    decision_note: Optional[str] = Field(default=None, max_length=512)


class RevealItem(BaseModel):
    id: int
    audit_log_id: int
    requested_by: str
    requested_email: Optional[str] = None
    reason: str
    status: str
    requested_at: datetime
    decided_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    revealed_at: Optional[datetime] = None
    approver_user_id: Optional[str] = None
    decision_note: Optional[str] = None


class RevealPlaintextResponse(BaseModel):
    request: RevealItem
    plaintext: dict[str, Optional[str]]    # {"prompt": "...", "response": "..."}


@router.post("/audit/{audit_log_id}/reveal-requests",
             response_model=RevealItem, status_code=201)
async def request_audit_reveal(
    audit_log_id: int,
    body: RevealRequestBody,
    principal: Principal = Depends(require_principal),
) -> RevealItem:
    """Open a 4-eyes plaintext-reveal request for one audit_log row.

    Any admin can request. A different admin must approve before the
    requester can fetch the decrypted plaintext.
    """
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await reveals_service.create_request(
                session,
                audit_log_id=audit_log_id,
                requested_by=principal.user_id,
                requested_email=principal.email,
                reason=body.reason,
            )
        except reveals_service.RevealError as e:
            raise HTTPException(status_code=400, detail=str(e))
        log.warning("Audit reveal requested by %s for audit_log_id=%d",
                    principal.user_id, audit_log_id)
        return RevealItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.get("/audit/reveal-requests", response_model=list[RevealItem])
async def list_audit_reveal_requests(
    principal: Principal = Depends(require_principal),
    status: Optional[str] = Query(default=None, max_length=16),
    requested_by: Optional[str] = Query(default=None, max_length=128),
    limit: int = Query(default=100, ge=1, le=1000),
) -> list[RevealItem]:
    require_admin(principal)
    async for session in gateway_session():
        rows = await reveals_service.list_requests(
            session, status=status, requested_by=requested_by, limit=limit,
        )
        return [RevealItem(**r.__dict__) for r in rows]
    return []


@router.post("/audit/reveal-requests/{request_id}/approve",
             response_model=RevealItem)
async def approve_audit_reveal(
    request_id: int,
    body: RevealDecisionBody,
    principal: Principal = Depends(require_principal),
) -> RevealItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await reveals_service.approve(
                session, request_id=request_id,
                approver_user_id=principal.user_id,
                decision_note=body.decision_note,
            )
        except reveals_service.RevealNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except reveals_service.SelfApprovalError as e:
            raise HTTPException(status_code=403, detail=str(e))
        except reveals_service.InvalidRevealTransitionError as e:
            raise HTTPException(status_code=409, detail=str(e))
        log.warning("Audit reveal id=%d approved by %s",
                    rec.id, principal.user_id)
        return RevealItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.post("/audit/reveal-requests/{request_id}/deny",
             response_model=RevealItem)
async def deny_audit_reveal(
    request_id: int,
    body: RevealDecisionBody,
    principal: Principal = Depends(require_principal),
) -> RevealItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await reveals_service.deny(
                session, request_id=request_id,
                approver_user_id=principal.user_id,
                decision_note=body.decision_note,
            )
        except reveals_service.RevealNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except reveals_service.SelfApprovalError as e:
            raise HTTPException(status_code=403, detail=str(e))
        except reveals_service.InvalidRevealTransitionError as e:
            raise HTTPException(status_code=409, detail=str(e))
        return RevealItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.get("/audit/reveal-requests/{request_id}/reveal",
            response_model=RevealPlaintextResponse)
async def fetch_audit_reveal(
    request_id: int,
    principal: Principal = Depends(require_principal),
) -> RevealPlaintextResponse:
    """Decrypt + return the plaintext for an APPROVED reveal request.

    Only the original requester can fetch (defence-in-depth — even if a
    different admin's session is compromised, they can't decrypt). Single
    use: a successful fetch flips status to 'revealed' (terminal).
    """
    require_admin(principal)
    # Need the audit row's ciphertext columns. Open both sessions.
    async for op_session in gateway_session():
        try:
            rec = await reveals_service.get_request(op_session, request_id)
        except reveals_service.RevealNotFoundError as e:
            raise HTTPException(status_code=404, detail=str(e))
        break

    settings = get_settings()
    audit_engine = create_async_engine(settings.audit_db_url, future=True)
    AuditSession = async_sessionmaker(audit_engine, expire_on_commit=False)
    try:
        from sqlalchemy import select as _select
        from ..models import AuditLog
        async with AuditSession() as a_session:
            audit_row = (await a_session.execute(
                _select(AuditLog).where(AuditLog.id == rec.audit_log_id)
            )).scalar_one_or_none()
    finally:
        await audit_engine.dispose()
    if audit_row is None:
        raise HTTPException(status_code=404,
                            detail=f"audit_log_id={rec.audit_log_id} not found")

    async for op_session in gateway_session():
        try:
            updated, plaintexts = await reveals_service.reveal(
                op_session,
                request_id=request_id,
                requester_user_id=principal.user_id,
                prompt_ciphertext=audit_row.prompt_ciphertext,
                response_ciphertext=audit_row.response_ciphertext,
            )
        except reveals_service.NotAuthorizedToRevealError as e:
            raise HTTPException(status_code=403, detail=str(e))
        except reveals_service.InvalidRevealTransitionError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except RuntimeError as e:                       # crypto not configured
            raise HTTPException(status_code=503, detail=str(e))
        log.warning("Audit reveal id=%d revealed by %s for audit_log_id=%d",
                    updated.id, principal.user_id, updated.audit_log_id)
        return RevealPlaintextResponse(
            request=RevealItem(**updated.__dict__),
            plaintext=plaintexts,
        )
    raise HTTPException(status_code=500, detail="DB session unavailable")


# ---------------------------------------------------------------------------
# Observability bus — 5-pipe status for the Overview banner
# ---------------------------------------------------------------------------
class PipeStatus(BaseModel):
    name:        str
    label:       str
    state:       str       # "active" | "configured" | "off" | "partial"
    detail:      Optional[str] = None
    metric:      Optional[str] = None    # one short numeric chip the UI can show
    href:        Optional[str] = None    # admin UI page for the pipe


class ObservabilityStatusResponse(BaseModel):
    pipes:        list[PipeStatus]
    generated_at: datetime


@router.get("/observability/status", response_model=ObservabilityStatusResponse)
async def observability_status(
    principal: Principal = Depends(require_principal),
) -> ObservabilityStatusResponse:
    """5-pipe observability bus state.

    Shape used by the ObservabilityBus banner on the Overview page. Each
    pipe self-reports state ("active" / "configured" / "off" / "partial")
    plus an optional one-chip metric the banner can display inline.
    """
    require_admin(principal)
    from ..main import app
    from ..plugins import PluginKind as _PK

    pipes: list[PipeStatus] = []

    # 1. Postgres audit
    audit_loaded = any(p.name == "audit_postgres" for p in registry.all())
    audit_count_24h = 0
    if audit_loaded:
        settings = get_settings()
        engine = create_async_engine(settings.audit_db_url, future=True)
        SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
        try:
            async with SessionLocal() as session:
                rows = await audit_service.search(
                    session,
                    since=datetime.now(timezone.utc) - timedelta(hours=24),
                    limit=1,
                )
                audit_count_24h = -1 if not rows else 1
                # For a real count we'd want a COUNT query; using the rollup
                # endpoint output instead would be cheaper. For now, just
                # report "active" — exact 24h count is not the banner's job.
        finally:
            await engine.dispose()
    pipes.append(PipeStatus(
        name="postgres_audit", label="Postgres audit",
        state="active" if audit_loaded else "off",
        detail="Append-only · 1 row per call" if audit_loaded else "Plugin not loaded",
        href="/audit",
    ))

    # 2. SIEM (Splunk/ELK)
    siem_status = None
    for p in registry.all():
        if p.name == "siem_forward" and hasattr(p, "status"):
            siem_status = p.status()
            break
    if siem_status is None:
        pipes.append(PipeStatus(
            name="siem", label="SIEM (Splunk/ELK)",
            state="off",
            detail="Plugin not loaded — add 'siem_forward' to GATEWAY_PLUGINS",
        ))
    elif not siem_status["enabled"] or not siem_status["configured"]:
        pipes.append(PipeStatus(
            name="siem", label="SIEM (Splunk/ELK)",
            state="off",
            detail="Set SIEM_WEBHOOK_URL or configure in /plugins",
            href="/plugins",
        ))
    else:
        sent = siem_status.get("events_sent", 0)
        failed = siem_status.get("events_failed", 0)
        dl = siem_status.get("dead_lettered", 0)
        state = "partial" if (failed or dl) else "active"
        chip = f"{sent} sent"
        if dl:
            chip += f" · {dl} dead-lettered"
        pipes.append(PipeStatus(
            name="siem", label="SIEM (Splunk/ELK)",
            state=state,
            detail=siem_status.get("url"),
            metric=chip,
            href="/plugins",
        ))

    # 3. Prometheus + Grafana
    # The /metrics endpoint is always exposed; the question is whether
    # anyone is scraping. If GATEWAY_GRAFANA_URL is set, we treat the pipe
    # as "active" and link the bus pill straight to Grafana. Otherwise
    # we say "configured" — the format is shipped, the consumer isn't.
    grafana_url = (os.environ.get("GATEWAY_GRAFANA_URL") or "").strip()
    if grafana_url:
        pipes.append(PipeStatus(
            name="prometheus", label="Prometheus + Grafana",
            state="active",
            detail=f"Scraping /metrics → {grafana_url}",
            href=grafana_url,
        ))
    else:
        # Until Grafana is up, the admin UI's /metrics page is the live
        # dashboard — same audit-log-derived data, no Docker required.
        # We tag this "active" so the bus reads honestly on machines where
        # Docker isn't an option (e.g. no CPU virtualization).
        pipes.append(PipeStatus(
            name="prometheus", label="Prometheus + Grafana",
            state="active",
            detail="In-app metrics dashboard live at /metrics. Set "
                   "GATEWAY_GRAFANA_URL to switch the pill to a Grafana link.",
            href="/metrics",
        ))

    # 4. UEBA baselines
    ueba_loaded = any(p.name == "observe_ueba" for p in registry.all())
    if not ueba_loaded:
        pipes.append(PipeStatus(
            name="ueba", label="UEBA baselines",
            state="off",
            detail="Plugin not loaded",
        ))
    else:
        # The alert path is shipped; per-user baselines are partially deferred.
        pipes.append(PipeStatus(
            name="ueba", label="UEBA baselines",
            state="partial",
            detail="Threshold alerts active; per-user baselines deferred",
            href="/monitoring",
        ))

    # 5. 4-eyes raw access
    # Not yet implemented — needs ciphertext encryption first. Surface as
    # "off" with a clear actionable detail so the SOC knows where things stand.
    pipes.append(PipeStatus(
        name="four_eyes", label="4-eyes raw access",
        state="off",
        detail="Encryption + reveal flow deferred — coming next slice",
        href="/audit",
    ))

    return ObservabilityStatusResponse(
        pipes=pipes,
        generated_at=datetime.now(timezone.utc),
    )


# ---------------------------------------------------------------------------
# Smart Router — rule visualisation + live usage stats
# ---------------------------------------------------------------------------
class RouterRuleItem(BaseModel):
    """One router rule as the UI sees it. We don't try to type the `when:`
    block strictly — the rule conditions are heterogeneous (max_tokens, any_of,
    has_code_blocks, dlp_findings_present, etc.) and the UI just displays
    them as JSON badges.

    ``enabled`` and ``route_override`` reflect the DB-side overlay:
        * ``enabled``        = False means the rule is currently disabled
                               (still listed here so the UI can render the
                               toggle, but the live router doesn't see it).
        * ``route_override`` = a non-null target model that replaces the
                               YAML ``route`` at evaluation time. The
                               ``route`` field still shows the YAML
                               original so the UI can render "was X, now Y".
    """
    name:           str
    when:           dict[str, Any]
    route:          str
    reason:         Optional[str] = None
    extra:          dict[str, Any] = Field(default_factory=dict)
    enabled:        bool = True
    route_override: Optional[str] = None


class RouterRuleOverrideBody(BaseModel):
    """PATCH body. Both fields optional; omit to leave that aspect untouched.

    ``route_override`` semantics:
        - omitted          -> don't change
        - explicit null    -> clear the override (revert to YAML route)
        - non-empty string -> validate against /admin/models, then set
    The distinction matters because Pydantic V2's `model_fields_set` lets us
    tell "field absent" from "field present-and-null".
    """
    enabled:        Optional[bool] = None
    route_override: Optional[str]  = Field(default=None, max_length=64)


class RouterRulesResponse(BaseModel):
    rules:  list[RouterRuleItem]
    count:  int
    source: str        # "policies.yaml" — surfaced so the UI can flag if it
                       # ever switches to DB-backed in a later slice.


class RouterUsageModel(BaseModel):
    model:  str
    count:  int
    tokens: int


class RouterUserOverride(BaseModel):
    user_id:        str
    total:          int     # total requests where model_requested was set
    overrides:      int     # of those, how many ended up on a different model
    override_rate:  float   # overrides / total, 0..1


class RouterUsageResponse(BaseModel):
    window_minutes: int
    generated_at:   datetime
    per_model:      list[RouterUsageModel]
    top_overriders: list[RouterUserOverride]
    overrides_total: int
    requests_total:  int


@router.get("/router/rules", response_model=RouterRulesResponse)
async def list_router_rules(
    principal: Principal = Depends(require_principal),
) -> RouterRulesResponse:
    """Effective router rule chain.

    Returns the BASE YAML rule list (not the post-override list) so the UI
    can render disabled rules and the "edit" affordance for the route
    target. Each rule is augmented with its current ``enabled`` /
    ``route_override`` state pulled from ``router_rule_overrides``.

    Reading from the YAML directly (rather than app.state.policies) means
    disabled rules still appear here — app.state's router_rules list has
    already been pruned by ``apply_overrides`` for the plugin's benefit.
    """
    require_admin(principal)
    from ..main import _load_yaml
    settings = get_settings()
    base = _load_yaml(settings.policies_path)
    rules_raw = (base.get("router_rules") or [])

    # Pull override info in one shot so the UI doesn't need a second fetch.
    overrides: dict[str, dict[str, Any]] = {}
    async for session in gateway_session():
        try:
            overrides = await router_rules_service.list_overrides(session)
        except Exception:                                          # noqa: BLE001
            log.exception("Reading router rule overrides failed; "
                          "rules will render as if no overrides exist")
        break

    rules: list[RouterRuleItem] = []
    for r in rules_raw:
        if not isinstance(r, dict):
            continue
        # Pluck the known fields; anything else goes into `extra` so the UI
        # can render it as JSON without us declaring every Pydantic field.
        known = {"name", "when", "route", "reason"}
        extra = {k: v for k, v in r.items() if k not in known}
        name = str(r.get("name") or "(unnamed)")
        ov = overrides.get(name) or {}
        rules.append(RouterRuleItem(
            name=name,
            when=(r.get("when") or {}),
            route=str(r.get("route") or ""),
            reason=r.get("reason"),
            extra=extra,
            enabled=bool(ov.get("enabled", True)),
            route_override=ov.get("route_override"),
        ))
    return RouterRulesResponse(
        rules=rules, count=len(rules), source="policies.yaml",
    )


@router.patch("/router/rules/{rule_name}", response_model=RouterRuleItem)
async def update_router_rule(
    rule_name: str,
    body: RouterRuleOverrideBody,
    principal: Principal = Depends(require_principal),
) -> RouterRuleItem:
    """Persist a UI-side override for a router rule.

    Only two things are editable here on purpose — the ``when:`` block
    shapes are too rich for a typed form (max_tokens, dlp_findings_present,
    team_budget_used_pct, contains_any, …) and stay YAML-managed.

      * ``enabled`` toggles the rule on/off in the chain.
      * ``route_override`` substitutes the rule's target model. Validated
        against the model registry — passing an unknown model returns 404
        so a stale UI can't poison the chain with a model that doesn't
        exist in /admin/models.

    Returns the merged-view rule object so the UI can immediately replace
    its local card state without re-fetching the whole list.
    """
    require_admin(principal)
    from ..main import _load_yaml
    settings = get_settings()
    base = _load_yaml(settings.policies_path)
    yaml_rule: Optional[dict[str, Any]] = next(
        (r for r in (base.get("router_rules") or [])
         if isinstance(r, dict) and r.get("name") == rule_name),
        None,
    )
    if yaml_rule is None:
        raise HTTPException(status_code=404,
                            detail=f"Router rule {rule_name!r} not found in policies.yaml")

    # Distinguish "field omitted" from "field present and null". A client
    # sending {"route_override": null} explicitly wants the override cleared.
    fields_set = body.model_fields_set
    enabled_arg: Optional[bool] = body.enabled if "enabled" in fields_set else None
    clear_override = False
    route_override_arg: Optional[str] = None
    if "route_override" in fields_set:
        if body.route_override is None or body.route_override == "":
            clear_override = True
        else:
            # Validate the target exists in the registry; refuse early
            # rather than letting the router silently fall through later.
            async for session in gateway_session():
                model = await models_service.get_by_name(session, body.route_override)
                break
            if model is None:
                raise HTTPException(
                    status_code=404,
                    detail=f"Unknown model {body.route_override!r}; "
                           f"not present in /admin/models",
                )
            route_override_arg = body.route_override

    async for session in gateway_session():
        rec = await router_rules_service.set_override(
            session,
            rule_name=rule_name,
            enabled=enabled_arg,
            route_override=route_override_arg,
            clear_route_override=clear_override,
        )
        break
    # Re-merge policies + re-setup the router plugin so the live chain picks
    # up the edit without a restart.
    await _reload_policy_plugins()
    log.warning("Router rule %r override updated by %s (enabled=%s, route_override=%s)",
                rule_name, principal.user_id, rec.enabled, rec.route_override)

    known = {"name", "when", "route", "reason"}
    extra = {k: v for k, v in yaml_rule.items() if k not in known}
    return RouterRuleItem(
        name=rule_name,
        when=(yaml_rule.get("when") or {}),
        route=str(yaml_rule.get("route") or ""),
        reason=yaml_rule.get("reason"),
        extra=extra,
        enabled=rec.enabled,
        route_override=rec.route_override,
    )


@router.get("/router/usage", response_model=RouterUsageResponse)
async def router_usage(
    principal: Principal = Depends(require_principal),
    window_minutes: int = Query(default=60, ge=1, le=24 * 60),
) -> RouterUsageResponse:
    """Per-model request counts + per-user override-rate.

    Override = the user requested a specific model (model_requested is set
    and not "auto") and the router rewrote it to a different one
    (model_used != model_requested). A high override-rate for a single user
    is a leading indicator of a rule that's misfiring for that user's
    workflow.
    """
    require_admin(principal)
    settings = get_settings()
    from sqlalchemy import create_engine                            # noqa: F401  # avoid sync
    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
    from sqlalchemy import select, func
    from ..models import AuditLog
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    now = datetime.now(timezone.utc)
    since = now - timedelta(minutes=window_minutes)
    try:
        async with SessionLocal() as session:
            # Per-model usage in the window.
            rows = (await session.execute(
                select(AuditLog.model_used,
                       func.count(),
                       func.sum(func.coalesce(AuditLog.tokens_in, 0)
                                + func.coalesce(AuditLog.tokens_out, 0)))
                .where(AuditLog.ts >= since)
                .group_by(AuditLog.model_used)
                .order_by(func.count().desc())
            )).all()
            per_model = [
                RouterUsageModel(
                    model=(r[0] or "(unknown)"),
                    count=int(r[1] or 0),
                    tokens=int(r[2] or 0),
                )
                for r in rows
            ]

            # Per-user override-rate. Only count rows where the user explicitly
            # asked for a specific model — "auto" / NULL / empty string mean
            # they were happy to let the router decide, so any rewrite there
            # is not an override.
            override_expr = func.sum(
                func.cast(
                    (AuditLog.model_requested.is_not(None))
                    & (AuditLog.model_requested != "")
                    & (AuditLog.model_requested != "auto")
                    & (AuditLog.model_used != AuditLog.model_requested),
                    Integer,
                )
            )
            total_with_request = func.sum(
                func.cast(
                    (AuditLog.model_requested.is_not(None))
                    & (AuditLog.model_requested != "")
                    & (AuditLog.model_requested != "auto"),
                    Integer,
                )
            )
            rows = (await session.execute(
                select(AuditLog.user_id,
                       total_with_request.label("total"),
                       override_expr.label("overrides"))
                .where(AuditLog.ts >= since)
                .group_by(AuditLog.user_id)
                .having(total_with_request > 0)
            )).all()
            users: list[RouterUserOverride] = []
            for r in rows:
                total = int(r[1] or 0)
                ovs   = int(r[2] or 0)
                if total <= 0:
                    continue
                users.append(RouterUserOverride(
                    user_id=r[0],
                    total=total,
                    overrides=ovs,
                    override_rate=round(ovs / total, 4),
                ))
            users.sort(key=lambda u: (u.override_rate, u.overrides), reverse=True)
            top_overriders = users[:20]

            # Aggregate totals across all users.
            requests_total  = sum(m.count for m in per_model)
            overrides_total = sum(u.overrides for u in users)
    finally:
        await engine.dispose()

    return RouterUsageResponse(
        window_minutes=window_minutes,
        generated_at=now,
        per_model=per_model,
        top_overriders=top_overriders,
        overrides_total=overrides_total,
        requests_total=requests_total,
    )


# ---------------------------------------------------------------------------
# Audit log — search
# ---------------------------------------------------------------------------
class AuditEntryDTO(BaseModel):
    """Single audit row as returned by /admin/audit/search.

    ``prompt_ciphertext`` / ``response_ciphertext`` are deliberately absent —
    plaintext access is a separate 4-eyes flow.
    """
    id:               int
    ts:               datetime
    request_id:       str
    user_id:          str
    user_email:       Optional[str] = None
    team_id:          str
    tier:             str
    base_tier:        Optional[str] = None
    elevation_id:     Optional[int] = None
    model_requested:  Optional[str] = None
    model_used:       Optional[str] = None
    routing_reason:   Optional[str] = None
    tokens_in:        int
    tokens_out:       int
    latency_ms:       float
    cost_usd:         float
    prompt_hash:      Optional[str] = None
    response_hash:    Optional[str] = None
    verdict:          str
    findings:         Optional[list[dict[str, Any]]] = None
    client_ip:        Optional[str] = None
    user_agent:       Optional[str] = None
    trace_id:         Optional[str] = None


class AuditSearchResponse(BaseModel):
    rows:        list[AuditEntryDTO]
    next_cursor: Optional[int] = None


@router.get("/audit/search", response_model=AuditSearchResponse)
async def audit_search(
    principal: Principal = Depends(require_principal),
    user_id:   Optional[str] = Query(default=None, max_length=128),
    team_id:   Optional[str] = Query(default=None, max_length=64),
    model:     Optional[str] = Query(default=None, max_length=64,
                                     alias="model_used"),
    verdict:   Optional[str] = Query(default=None, max_length=16),
    trace_id:  Optional[str] = Query(default=None, max_length=64),
    since:     Optional[datetime] = Query(default=None),
    until:     Optional[datetime] = Query(default=None),
    before_id: Optional[int] = Query(default=None, ge=1),
    limit:     int           = Query(default=50, ge=1, le=500),
) -> AuditSearchResponse:
    """Cursor-paginated audit-log search.

    Pagination: pass the previous page's ``next_cursor`` as ``before_id``.
    Hash columns are returned; ciphertext columns are not exposed here.
    """
    require_admin(principal)
    settings = get_settings()
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with SessionLocal() as session:
            rows = await audit_service.search(
                session,
                user_id=user_id, team_id=team_id, model_used=model,
                verdict=verdict, trace_id=trace_id,
                since=since, until=until,
                before_id=before_id, limit=limit,
            )
    finally:
        await engine.dispose()
    next_cursor = rows[-1].id if len(rows) == limit and rows else None
    return AuditSearchResponse(
        rows=[AuditEntryDTO(**r.__dict__) for r in rows],
        next_cursor=next_cursor,
    )


CSV_EXPORT_MAX_ROWS = 5000
# Stable column order — keep in sync with the UI's expectation that a CSV
# export can be diffed across days. Ciphertext columns are intentionally
# absent; this is the same trust boundary as the JSON /audit/search endpoint.
CSV_COLUMNS = [
    "id", "ts", "request_id", "trace_id",
    "user_id", "user_email", "team_id", "tier", "base_tier", "elevation_id",
    "model_requested", "model_used", "routing_reason",
    "tokens_in", "tokens_out", "latency_ms", "cost_usd",
    "verdict", "prompt_hash", "response_hash",
    "client_ip", "user_agent",
    "findings_count", "findings_max_severity",
]
_SEVERITY_RANK = {"info": 0, "low": 1, "warn": 2, "medium": 2,
                  "high": 3, "critical": 4}


class DashboardSummaryDTO(BaseModel):
    window_minutes:    int
    generated_at:      datetime
    request_count:     int
    requests_per_min:  float
    avg_latency_ms:    float
    p99_latency_ms:    float
    tokens_in_total:   int
    tokens_out_total:  int
    cost_usd_total:    float
    verdict_counts:    dict[str, int]
    dlp_findings:      int
    secret_leaks:      int
    top_models:        list[dict[str, Any]]
    top_teams:         list[dict[str, Any]]
    timeseries:        list[dict[str, Any]]


@router.get("/dashboard/summary", response_model=DashboardSummaryDTO)
async def dashboard_summary(
    principal: Principal = Depends(require_principal),
    window_minutes: int  = Query(default=60, ge=1, le=24 * 60),
) -> DashboardSummaryDTO:
    """One-shot rollup for the Overview page. Designed to be auto-refreshed
    every ~10s; cheap because it's a single SELECT plus in-process aggregation."""
    require_admin(principal)
    settings = get_settings()
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with SessionLocal() as session:
            s = await audit_service.summary(session, window_minutes=window_minutes)
    finally:
        await engine.dispose()
    return DashboardSummaryDTO(**s.__dict__)


class CostForecastResponse(BaseModel):
    window_days:     int
    cost_window_usd: float
    cost_per_day:    float
    projection_days: int
    projected_usd:   float
    by_team:         list[dict[str, Any]]
    by_model:        list[dict[str, Any]]
    rows_considered: int
    generated_at:    datetime


@router.get("/metrics/cost-forecast", response_model=CostForecastResponse)
async def cost_forecast_endpoint(
    principal: Principal = Depends(require_principal),
    window_days:     int = Query(default=7,  ge=1, le=90,
                                  description="Look back this many days to set burn-rate baseline."),
    projection_days: int = Query(default=30, ge=1, le=365,
                                  description="Project the rate forward this many days."),
) -> CostForecastResponse:
    """Lightweight spend projection — burn-rate × horizon.

    Defaults to a 7-day rolling window projected to 30 days (a typical
    "what will we spend this month" check). Cheap: one SELECT over the
    window then an aggregation in Python. Returns zeros when there's no
    audit history yet so the UI doesn't need to special-case empty state.
    """
    require_admin(principal)
    settings = get_settings()
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with SessionLocal() as session:
            f = await audit_service.cost_forecast(
                session,
                window_days=window_days,
                projection_days=projection_days,
            )
    finally:
        await engine.dispose()
    return CostForecastResponse(**f.__dict__)


# ---------------------------------------------------------------------------
# Spend ($USD/h) by model — operator-toggled
# ---------------------------------------------------------------------------
# Off by default. When enabled, the endpoint scans audit_log for the last
# ``window_minutes`` and reports per-model burn rate. When disabled, it
# short-circuits to ``enabled=False`` without touching the DB — so a UI
# poller doesn't drive cost-of-doing-nothing.
class SpendToggle(BaseModel):
    enabled: bool


class SpendByModelRow(BaseModel):
    model:        str
    cost_usd:     float
    usd_per_hour: float


class SpendByModelResponse(BaseModel):
    enabled:        bool
    window_minutes: int
    cost_total_usd: float
    by_model:       list[SpendByModelRow]
    rows_considered: int
    generated_at:   datetime


@router.get("/settings/spend-by-model", response_model=SpendToggle)
async def get_spend_by_model_toggle(
    principal: Principal = Depends(require_principal),
) -> SpendToggle:
    """Read the current state of the spend-by-model toggle."""
    require_admin(principal)
    from ..services import system_settings as ss
    async for session in gateway_session():
        rec = await ss.get(session, ss.KEY_SPEND_BY_MODEL)
        return SpendToggle(enabled=bool(rec.value.get("enabled", False)))
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.put("/settings/spend-by-model", response_model=SpendToggle)
async def set_spend_by_model_toggle(
    body: SpendToggle,
    principal: Principal = Depends(require_principal),
) -> SpendToggle:
    """Flip the spend-by-model toggle on/off."""
    require_admin(principal)
    from ..services import system_settings as ss
    async for session in gateway_session():
        rec = await ss.set_(session, ss.KEY_SPEND_BY_MODEL,
                            {"enabled": bool(body.enabled)})
        log.warning("Spend-by-model toggle set to %s by %s",
                    body.enabled, principal.user_id)
        return SpendToggle(enabled=bool(rec.value.get("enabled", False)))
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.get("/metrics/spend-by-model", response_model=SpendByModelResponse)
async def spend_by_model_endpoint(
    principal: Principal = Depends(require_principal),
    window_minutes: int = Query(default=60, ge=1, le=24 * 60,
                                description="Look back this many minutes."),
) -> SpendByModelResponse:
    """Per-model $USD/hour burn rate.

    Returns immediately with ``enabled=false`` and an empty body when the
    operator hasn't enabled the toggle — so the UI poller costs ~one
    indexed SELECT against ``system_settings`` per refresh.
    """
    require_admin(principal)
    from ..services import system_settings as ss

    # Toggle check — operational DB.
    async for op_session in gateway_session():
        toggle = await ss.get(op_session, ss.KEY_SPEND_BY_MODEL)
        break
    if not toggle.value.get("enabled"):
        return SpendByModelResponse(
            enabled=False,
            window_minutes=window_minutes,
            cost_total_usd=0.0,
            by_model=[],
            rows_considered=0,
            generated_at=datetime.now(timezone.utc),
        )

    # Compute against the audit DB.
    settings = get_settings()
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with SessionLocal() as session:
            s = await audit_service.spend_by_model(
                session, window_minutes=window_minutes,
            )
    finally:
        await engine.dispose()
    return SpendByModelResponse(
        enabled=s.enabled,
        window_minutes=s.window_minutes,
        cost_total_usd=s.cost_total_usd,
        by_model=[SpendByModelRow(**r) for r in s.by_model],
        rows_considered=s.rows_considered,
        generated_at=s.generated_at,
    )


class AuditRetentionResponse(BaseModel):
    cutoff_ts:            datetime
    rows_deleted:         int
    bytes_freed_estimate: int
    duration_ms:          float
    dry_run:              bool


@router.post("/audit/prune", response_model=AuditRetentionResponse)
async def audit_prune(
    principal: Principal = Depends(require_principal),
    days:    int  = Query(default=90, ge=1, le=3650,
                          description="Delete rows older than this many days."),
    dry_run: bool = Query(default=True,
                          description="If true, only count would-be-deleted rows."),
) -> AuditRetentionResponse:
    """Audit-log retention sweep.

    Append-only audit_log grows without bound; this endpoint deletes rows
    older than ``days`` days. Operators typically wire it to a cron:

        # Daily at 03:00, drop everything older than 90 days.
        0 3 * * *   curl -X POST -H "Authorization: Bearer $MASTER" \\
                         "http://gw:4000/admin/audit/prune?days=90&dry_run=false"

    Defaults to dry_run=true so a stray click doesn't wipe history — the
    UI / cron has to pass ``dry_run=false`` explicitly to actually delete.
    """
    require_admin(principal)
    settings = get_settings()
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with SessionLocal() as session:
            result = await audit_service.prune_older_than(
                session, days=days, dry_run=dry_run,
            )
    finally:
        await engine.dispose()
    log.warning(
        "audit_prune by %s: days=%d dry_run=%s rows=%d (~%d bytes)",
        principal.user_id, days, dry_run,
        result.rows_deleted, result.bytes_freed_estimate,
    )
    return AuditRetentionResponse(
        cutoff_ts=result.cutoff_ts,
        rows_deleted=result.rows_deleted,
        bytes_freed_estimate=result.bytes_freed_estimate,
        duration_ms=result.duration_ms,
        dry_run=dry_run,
    )


@router.get("/audit/search.csv")
async def audit_search_csv(
    principal: Principal = Depends(require_principal),
    user_id:   Optional[str]      = Query(default=None, max_length=128),
    team_id:   Optional[str]      = Query(default=None, max_length=64),
    model:     Optional[str]      = Query(default=None, max_length=64,
                                          alias="model_used"),
    verdict:   Optional[str]      = Query(default=None, max_length=16),
    trace_id:  Optional[str]      = Query(default=None, max_length=64),
    since:     Optional[datetime] = Query(default=None),
    until:     Optional[datetime] = Query(default=None),
    limit:     int                = Query(default=CSV_EXPORT_MAX_ROWS,
                                          ge=1, le=CSV_EXPORT_MAX_ROWS),
) -> Response:
    """CSV export of the audit log — same filters as /audit/search, capped
    at ``CSV_EXPORT_MAX_ROWS`` rows.

    Cap is hard (not paginated) because a one-click browser download can't
    cleanly stitch pages and CSV-of-audit-log is a "give me a slice for
    spreadsheet review" workflow, not a SIEM bulk-ship. Use the JSON
    /audit/search endpoint with cursor pagination for the latter.
    """
    require_admin(principal)
    settings = get_settings()
    engine = create_async_engine(settings.audit_db_url, future=True)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with SessionLocal() as session:
            rows = await audit_service.search(
                session,
                user_id=user_id, team_id=team_id, model_used=model,
                verdict=verdict, trace_id=trace_id,
                since=since, until=until,
                before_id=None, limit=limit,
            )
    finally:
        await engine.dispose()

    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(CSV_COLUMNS)
    for r in rows:
        findings = r.findings or []
        max_sev = ""
        if findings:
            max_sev = max(
                (f.get("severity") or "" for f in findings),
                key=lambda s: _SEVERITY_RANK.get(s, -1),
                default="",
            )
        w.writerow([
            r.id, r.ts.isoformat() if r.ts else "", r.request_id,
            r.trace_id or "",
            r.user_id, r.user_email or "", r.team_id, r.tier,
            r.base_tier or "",
            r.elevation_id if r.elevation_id is not None else "",
            r.model_requested or "", r.model_used or "", r.routing_reason or "",
            r.tokens_in, r.tokens_out, f"{r.latency_ms:.3f}", f"{r.cost_usd:.6f}",
            r.verdict, r.prompt_hash or "", r.response_hash or "",
            r.client_ip or "", r.user_agent or "",
            len(findings), max_sev,
        ])

    filename = f"audit-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}.csv"
    return Response(
        content=buf.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Row-Count":         str(len(rows)),
            "X-Row-Cap":           str(CSV_EXPORT_MAX_ROWS),
        },
    )


# ---------------------------------------------------------------------------
# Just-In-Time tier elevation
# ---------------------------------------------------------------------------
class ElevationRequestBody(BaseModel):
    requested_tier:   str = Field(min_length=1, max_length=32)
    duration_minutes: int = Field(default=240, ge=15, le=60 * 24)
    reason:           str = Field(min_length=1, max_length=1024)


class ElevationDecisionBody(BaseModel):
    decision_note: Optional[str] = Field(default=None, max_length=512)


class ElevationItem(BaseModel):
    id: int
    user_id: str
    user_email: Optional[str]
    team_id: str
    base_tier: str
    requested_tier: str
    duration_minutes: int
    reason: str
    status: str
    requested_at: datetime
    decided_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    approver_user_id: Optional[str] = None
    decision_note: Optional[str] = None


def _to_item(rec) -> ElevationItem:
    return ElevationItem(**rec.__dict__)


@router.post("/elevation/request", response_model=ElevationItem, status_code=201)
async def request_elevation(
    body: ElevationRequestBody,
    principal: Principal = Depends(require_principal),
) -> ElevationItem:
    """Any authenticated principal can request an elevation for themselves."""
    from ..main import app
    allowed_tiers = list(((app.state.policies or {}).get("tiers") or {}).keys())

    async for session in gateway_session():
        try:
            # Use the user's *normal* tier as the base for the next request.
            # If they're already elevated, principal.tier is the elevated
            # value — the service would then see base==requested and 400.
            base = principal.base_tier or principal.tier
            rec = await elevations_service.request_elevation(
                session,
                user_id=principal.user_id,
                user_email=principal.email,
                team_id=principal.team_id,
                base_tier=base,
                requested_tier=body.requested_tier,
                duration_minutes=body.duration_minutes,
                reason=body.reason,
                allowed_tiers=allowed_tiers,
            )
        except elevations_service.RequestBurstError as e:
            raise HTTPException(
                status_code=429,
                detail=str(e),
                headers={"Retry-After": str(
                    elevations_service.REQUEST_BURST_WINDOW_HOURS * 3600
                )},
            )
        except elevations_service.DuplicateRequestError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except elevations_service.ElevationError as e:
            raise HTTPException(status_code=400, detail=str(e))
        return _to_item(rec)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.get("/elevation/pending", response_model=list[ElevationItem])
async def list_pending_elevations(
    principal: Principal = Depends(require_principal),
    limit: int = Query(default=100, ge=1, le=1000),
) -> list[ElevationItem]:
    require_admin(principal)
    async for session in gateway_session():
        rows = await elevations_service.list_pending(session, limit=limit)
        return [_to_item(r) for r in rows]
    return []


@router.get("/elevation/mine", response_model=list[ElevationItem])
async def list_my_elevations(
    principal: Principal = Depends(require_principal),
) -> list[ElevationItem]:
    """Requester's own history (no admin role required)."""
    async for session in gateway_session():
        rows = await elevations_service.list_for_user(session, principal.user_id)
        return [_to_item(r) for r in rows]
    return []


@router.post("/elevation/{elevation_id}/approve", response_model=ElevationItem)
async def approve_elevation(
    elevation_id: int,
    body: ElevationDecisionBody,
    principal: Principal = Depends(require_principal),
) -> ElevationItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await elevations_service.approve(
                session,
                elevation_id=elevation_id,
                approver_user_id=principal.user_id,
                decision_note=body.decision_note,
            )
        except elevations_service.SelfApprovalError as e:
            raise HTTPException(status_code=403, detail=str(e))
        except elevations_service.InvalidTransitionError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except elevations_service.ElevationError as e:
            raise HTTPException(status_code=404, detail=str(e))
        log.warning("Elevation %d approved by %s (target %s -> %s, %d min)",
                    rec.id, principal.user_id, rec.base_tier,
                    rec.requested_tier, rec.duration_minutes)
        return _to_item(rec)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.post("/elevation/{elevation_id}/deny", response_model=ElevationItem)
async def deny_elevation(
    elevation_id: int,
    body: ElevationDecisionBody,
    principal: Principal = Depends(require_principal),
) -> ElevationItem:
    require_admin(principal)
    async for session in gateway_session():
        try:
            rec = await elevations_service.deny(
                session,
                elevation_id=elevation_id,
                approver_user_id=principal.user_id,
                decision_note=body.decision_note,
            )
        except elevations_service.SelfApprovalError as e:
            raise HTTPException(status_code=403, detail=str(e))
        except elevations_service.InvalidTransitionError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except elevations_service.ElevationError as e:
            raise HTTPException(status_code=404, detail=str(e))
        log.warning("Elevation %d denied by %s", rec.id, principal.user_id)
        return _to_item(rec)
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.post("/elevation/{elevation_id}/cancel", response_model=ElevationItem)
async def cancel_elevation(
    elevation_id: int,
    principal: Principal = Depends(require_principal),
) -> ElevationItem:
    """The requester withdraws their own pending request."""
    async for session in gateway_session():
        try:
            rec = await elevations_service.cancel(
                session,
                elevation_id=elevation_id,
                user_id=principal.user_id,
            )
        except elevations_service.InvalidTransitionError as e:
            raise HTTPException(status_code=403, detail=str(e))
        except elevations_service.ElevationError as e:
            raise HTTPException(status_code=404, detail=str(e))
        return _to_item(rec)
    raise HTTPException(status_code=500, detail="DB session unavailable")


# ---------------------------------------------------------------------------
# Providers — OpenRouter
# ---------------------------------------------------------------------------
class OpenRouterConfig(BaseModel):
    has_key:    bool
    key_prefix: Optional[str] = None    # first ~12 chars for visual confirmation


class OpenRouterConfigUpdate(BaseModel):
    api_key: Optional[str] = Field(default=None, max_length=512,
                                   description="Pass null/empty to clear.")


class OpenRouterCatalogModel(BaseModel):
    id:                  str
    name:                str
    description:         Optional[str] = None
    context_length:      Optional[int] = None
    pricing_prompt_usd_per_1k:     Optional[float] = None
    pricing_completion_usd_per_1k: Optional[float] = None


class OpenRouterImportRequest(BaseModel):
    or_model_id:   str = Field(min_length=1, max_length=256,
                                description="OpenRouter model id, e.g. moonshotai/kimi-k2")
    gateway_name:  Optional[str] = Field(default=None, max_length=64,
                                          description="External model name; defaults to a sanitised or_model_id")
    tier:          Optional[str] = Field(default="premium", max_length=32)
    enabled:       bool = True


def _key_prefix(s: str) -> str:
    """First chars of an API key for visual confirmation in the UI."""
    if not s:
        return ""
    if len(s) <= 12:
        return s
    return s[:12] + "…"


@router.get("/providers/openrouter", response_model=OpenRouterConfig)
async def get_openrouter_config(
    principal: Principal = Depends(require_principal),
) -> OpenRouterConfig:
    require_admin(principal)
    from ..services import system_settings as ss
    async for session in gateway_session():
        rec = await ss.get(session, ss.KEY_OPENROUTER_API_KEY)
        api_key = (rec.value or {}).get("api_key") or ""
        return OpenRouterConfig(
            has_key=bool(api_key.strip()),
            key_prefix=_key_prefix(api_key) if api_key else None,
        )
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.put("/providers/openrouter", response_model=OpenRouterConfig)
async def set_openrouter_config(
    body: OpenRouterConfigUpdate,
    principal: Principal = Depends(require_principal),
) -> OpenRouterConfig:
    """Store the OpenRouter API key. Pass empty/null to clear. Triggers a
    Router rebuild so the next chat completion picks up the new key."""
    require_admin(principal)
    from ..services import system_settings as ss
    new_val = (body.api_key or "").strip() or None
    async for session in gateway_session():
        await ss.set_(session, ss.KEY_OPENROUTER_API_KEY,
                      {"api_key": new_val})
        log.warning("OpenRouter API key %s by %s",
                    "set" if new_val else "cleared", principal.user_id)
        break
    # Rebuild Router so already-loaded models see the new key.
    try:
        await _reload_router_from_db()
    except Exception:  # noqa: BLE001
        log.exception("Router reload after OpenRouter key change failed")
    return OpenRouterConfig(
        has_key=bool(new_val),
        key_prefix=_key_prefix(new_val) if new_val else None,
    )


@router.get("/providers/openrouter/test")
async def test_openrouter_key(
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """Hit OpenRouter's /auth/key with the stored token. 200 = key works."""
    require_admin(principal)
    from ..services import system_settings as ss
    from ..services import openrouter as or_service
    async for session in gateway_session():
        rec = await ss.get(session, ss.KEY_OPENROUTER_API_KEY)
        api_key = (rec.value or {}).get("api_key") or ""
        break
    if not api_key:
        return {"ok": False, "reason": "no_key_stored"}
    ok = await or_service.verify_key(api_key)
    return {"ok": ok}


@router.get("/providers/openrouter/models", response_model=list[OpenRouterCatalogModel])
async def list_openrouter_models(
    principal: Principal = Depends(require_principal),
    search: Optional[str] = Query(default=None, max_length=128),
    force_refresh: bool = Query(default=False),
) -> list[OpenRouterCatalogModel]:
    """List OpenRouter's catalog. Cached 5min per process. ``search`` is
    a case-insensitive substring match on id + name + description."""
    require_admin(principal)
    from ..services import system_settings as ss
    from ..services import openrouter as or_service
    async for session in gateway_session():
        rec = await ss.get(session, ss.KEY_OPENROUTER_API_KEY)
        api_key = (rec.value or {}).get("api_key") or None
        break
    try:
        models = await or_service.list_models(api_key, force_refresh=force_refresh)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(
            status_code=502,
            detail=f"OpenRouter catalog fetch failed: {e}",
        )
    if search:
        q = search.lower().strip()
        models = [m for m in models if (
            q in m.id.lower()
            or q in (m.name or "").lower()
            or q in (m.description or "").lower()
        )]
    return [OpenRouterCatalogModel(**m.__dict__) for m in models]


@router.post("/providers/openrouter/import", response_model=ModelItem, status_code=201)
async def import_openrouter_model(
    body: OpenRouterImportRequest,
    principal: Principal = Depends(require_principal),
) -> ModelItem:
    """Import an OpenRouter model into the gateway registry. The new row's
    ``litellm_params.model`` becomes ``openrouter/{or_model_id}`` and the
    api_key field points at ``os.environ/OPENROUTER_API_KEY`` so the
    UI-managed key (or env var) flows through at Router build time."""
    require_admin(principal)
    from ..services import openrouter as or_service
    # Resolve the catalog entry so we can pin pricing + context length.
    try:
        catalog = await or_service.list_models()
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502,
                            detail=f"OpenRouter catalog fetch failed: {e}")
    match = next((m for m in catalog if m.id == body.or_model_id), None)
    if match is None:
        raise HTTPException(
            status_code=404,
            detail=f"Model id {body.or_model_id!r} not found in OpenRouter catalog",
        )

    gw_name = body.gateway_name or body.or_model_id.replace("/", "-")
    litellm_params = {
        "model":   f"openrouter/{body.or_model_id}",
        "api_key": "os.environ/OPENROUTER_API_KEY",
    }
    model_info = {
        "gateway_tier":        body.tier or "premium",
        "hosting":             "cloud",
        "family":              body.or_model_id.split("/")[0] if "/" in body.or_model_id else "openrouter",
        "max_input_tokens":    match.context_length,
        "cost_per_1k_input":   match.pricing_prompt_usd_per_1k,
        "cost_per_1k_output":  match.pricing_completion_usd_per_1k,
    }

    async for session in gateway_session():
        try:
            rec = await models_service.create_model(
                session,
                model_name=gw_name,
                litellm_params=litellm_params,
                model_info=model_info,
                enabled=body.enabled,
                provider="openrouter",
            )
        except models_service.DuplicateModelError as e:
            raise HTTPException(status_code=409, detail=str(e))
        except models_service.ModelError as e:
            raise HTTPException(status_code=400, detail=str(e))
        await _reload_router_from_db()
        log.warning("Imported OpenRouter model %r as %r by %s",
                    body.or_model_id, gw_name, principal.user_id)
        return ModelItem(**rec.__dict__)
    raise HTTPException(status_code=500, detail="DB session unavailable")


# ---------------------------------------------------------------------------
# Providers — SMTP (outbound email for key delivery)
# ---------------------------------------------------------------------------
class SmtpConfigResponse(BaseModel):
    """Read shape. Password is never returned to the browser; only a
    'has_password' flag + 4-char prefix for visual confirmation."""
    host:          str
    port:          int
    user:          str
    from_addr:     str
    from_name:     str
    use_tls:       bool
    use_ssl:       bool
    has_password:  bool
    password_prefix: Optional[str] = None


class SmtpConfigUpdate(BaseModel):
    host:      Optional[str]  = Field(default=None, max_length=255)
    port:      Optional[int]  = Field(default=None, ge=1, le=65535)
    user:      Optional[str]  = Field(default=None, max_length=255)
    # password=None means "leave existing alone"; "" means "clear".
    password:  Optional[str]  = Field(default=None, max_length=512)
    from_addr: Optional[str]  = Field(default=None, max_length=255)
    from_name: Optional[str]  = Field(default=None, max_length=128)
    use_tls:   Optional[bool] = None
    use_ssl:   Optional[bool] = None


class SmtpTestRequest(BaseModel):
    to_addr: str = Field(min_length=3, max_length=255)


def _smtp_pw_prefix(s: str) -> Optional[str]:
    if not s:
        return None
    if len(s) <= 4:
        return s[:1] + "…"
    return s[:4] + "…"


@router.get("/providers/smtp", response_model=SmtpConfigResponse)
async def get_smtp_config(
    principal: Principal = Depends(require_principal),
) -> SmtpConfigResponse:
    require_admin(principal)
    from ..services import system_settings as ss
    async for session in gateway_session():
        rec = await ss.get(session, ss.KEY_SMTP_CONFIG)
        v = rec.value or {}
        pw = (v.get("password") or "")
        return SmtpConfigResponse(
            host=(v.get("host") or ""),
            port=int(v.get("port") or 587),
            user=(v.get("user") or ""),
            from_addr=(v.get("from_addr") or ""),
            from_name=(v.get("from_name") or "OATI LLMGateway"),
            use_tls=bool(v.get("use_tls", True)),
            use_ssl=bool(v.get("use_ssl", False)),
            has_password=bool(pw),
            password_prefix=_smtp_pw_prefix(pw),
        )
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.put("/providers/smtp", response_model=SmtpConfigResponse)
async def set_smtp_config(
    body: SmtpConfigUpdate,
    principal: Principal = Depends(require_principal),
) -> SmtpConfigResponse:
    """Save SMTP config. `password=None` leaves the stored password
    alone (so the operator can edit host/port without re-typing the
    secret); empty string clears it explicitly."""
    require_admin(principal)
    from ..services import system_settings as ss
    async for session in gateway_session():
        rec = await ss.get(session, ss.KEY_SMTP_CONFIG)
        cur = dict(rec.value or {})
        # Selective merge — only touch keys the body actually set.
        for k in ("host", "port", "user", "from_addr", "from_name",
                  "use_tls", "use_ssl"):
            v = getattr(body, k)
            if v is not None:
                cur[k] = v
        if body.password is not None:
            cur["password"] = body.password  # "" clears
        await ss.set_(session, ss.KEY_SMTP_CONFIG, cur)
        log.warning("SMTP config updated by %s (host=%s)",
                    principal.user_id, cur.get("host") or "")
        pw = cur.get("password") or ""
        return SmtpConfigResponse(
            host=(cur.get("host") or ""),
            port=int(cur.get("port") or 587),
            user=(cur.get("user") or ""),
            from_addr=(cur.get("from_addr") or ""),
            from_name=(cur.get("from_name") or "OATI LLMGateway"),
            use_tls=bool(cur.get("use_tls", True)),
            use_ssl=bool(cur.get("use_ssl", False)),
            has_password=bool(pw),
            password_prefix=_smtp_pw_prefix(pw),
        )
    raise HTTPException(status_code=500, detail="DB session unavailable")


@router.post("/providers/smtp/test")
async def test_smtp(
    body: SmtpTestRequest,
    principal: Principal = Depends(require_principal),
) -> dict[str, Any]:
    """Send a small test email to the supplied address. Returns
    `{ok: true}` on success or `{ok: false, error: "..."}` on failure
    so the UI can show a precise SMTP error to the operator."""
    require_admin(principal)
    from ..services import email as email_service
    async for session in gateway_session():
        try:
            await email_service.send_test_email(session, to_addr=body.to_addr)
            log.warning("SMTP test sent to %s by %s", body.to_addr, principal.user_id)
            return {"ok": True}
        except email_service.EmailError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:                                           # noqa: BLE001
            return {"ok": False, "error": f"unexpected: {e}"}
    raise HTTPException(status_code=500, detail="DB session unavailable")
