"""LiteLLM Gateway — policy-oriented AI gateway with a pluggable hook system."""

import asyncio as _asyncio
import os as _os
import sys as _sys

# TLS trust bootstrap — Python on Windows can't verify HTTPS to many
# upstreams when SSL/TLS scanning antivirus (Avast / Bitdefender / Norton)
# performs MITM interception with its own self-signed root. That root
# lives in the Windows certificate store but NOT in certifi's bundle, so
# every outbound httpx / requests call fails CERTIFICATE_VERIFY_FAILED.
#
# `truststore` re-wires Python's `ssl` module to verify through the OS
# native cert store (CryptoAPI on Windows, Security framework on macOS),
# which DOES include the antivirus root. Must be injected before any
# HTTP client imports its SSL context — hence package __init__.
#
# certifi vars are also set as a belt-and-suspenders fallback for code
# paths that bypass the global ssl module.
try:
    import truststore as _truststore
    _truststore.inject_into_ssl()
except Exception:  # noqa: BLE001
    pass
try:
    import certifi as _certifi
    _ca = _certifi.where()
    _os.environ.setdefault("SSL_CERT_FILE",     _ca)
    _os.environ.setdefault("REQUESTS_CA_BUNDLE", _ca)
except Exception:  # noqa: BLE001
    pass

# Psycopg async requires SelectorEventLoop. Windows defaults to ProactorEventLoop
# which deadlocks every DB connection. Set this at package import (before uvicorn
# creates its loop) so plugin setup hooks can talk to Postgres.
if _sys.platform == "win32":
    _asyncio.set_event_loop_policy(_asyncio.WindowsSelectorEventLoopPolicy())

__version__ = "0.1.0"
