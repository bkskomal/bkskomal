"""Plugin contract.

A plugin is anything that implements one or more of the four lifecycle methods
on :class:`GatewayPlugin`. The gateway runs them at well-defined points:

    AuthN ─ AuthZ ─►  on_pre_call  ─►  on_route_select  ─► (LiteLLM inference) ─►  on_post_call  ─►  on_audit

Plugins declare themselves via Python entry-points in ``pyproject.toml``::

    [project.entry-points."litellm_gateway.plugins"]
    my_dlp = "my_pkg.plugins:MyDLP"

The runtime discovers entry-points at startup AND any explicitly-named modules
in ``GATEWAY_PLUGINS`` so third-party packages slot in without code changes.
"""

from __future__ import annotations

from abc import ABC
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class PluginKind(str, Enum):
    """Stable taxonomy. Decides slot ordering and UI grouping."""

    AUTH        = "auth"
    AUTHZ       = "authz"
    DLP         = "dlp"            # input-side data-loss prevention
    GUARDRAIL   = "guardrail"      # prompt-injection / jailbreak defence
    ROUTER      = "router"         # picks which model to call
    OUTPUT_SCAN = "output_scan"    # post-call response scrubbing
    AUDIT       = "audit"          # writes the audit log
    OBSERVE     = "observe"        # metrics / UEBA signal emitters


class PluginVerdict(str, Enum):
    """What a hook decided. Returned by every plugin call."""

    ALLOW        = "allow"          # continue the request unchanged
    ALLOW_MUTATE = "allow_mutate"   # continue but mutate the payload (redaction etc.)
    REFUSE       = "refuse"         # short-circuit; return a structured error
    WARN         = "warn"           # continue; surface a non-blocking message


# ---------------------------------------------------------------------------
# Request / response context — what plugins see, and what they can change.
# ---------------------------------------------------------------------------
@dataclass
class Principal:
    """The authenticated caller of this request.

    ``tier`` is the *effective* tier for this request — usually equal to
    ``base_tier``, but can be temporarily promoted by an approved JIT
    elevation, in which case ``elevation_id`` is set.

    Audit / UEBA / quota plugins should use ``base_tier`` for "what is this
    user normally permitted to do" and ``tier`` for "what was actually
    permitted on this call".
    """

    user_id: str
    team_id: str
    tier: str
    email: Optional[str] = None
    roles: list[str] = field(default_factory=list)
    base_tier: Optional[str] = None     # the team's configured tier
    elevation_id: Optional[int] = None  # set when tier != base_tier via JIT


@dataclass
class RequestContext:
    """Mutable bag passed through every pre-call plugin."""

    request_id: str
    principal: Principal
    model_requested: Optional[str]            # what the caller asked for; None = let router pick
    model_selected: Optional[str] = None      # set by the router plugin
    routing_reason: Optional[str] = None      # human-readable explanation
    messages: list[dict[str, Any]] = field(default_factory=list)
    tools: list[dict[str, Any]] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)
    # Pre-call findings — DLP/guardrails write here; router may read.
    findings: list["Finding"] = field(default_factory=list)
    # Opaque session-trace id from the X-Gateway-Trace header. None until
    # main.py defaults it to request_id when the caller didn't send one.
    trace_id: Optional[str] = None


@dataclass
class ResponseContext:
    """Passed through every post-call plugin once LiteLLM has answered."""

    request_id: str
    principal: Principal
    model_used: str
    response: dict[str, Any]
    latency_ms: float
    tokens_in: int
    tokens_out: int
    cost_usd: float
    extra: dict[str, Any] = field(default_factory=dict)
    findings: list["Finding"] = field(default_factory=list)
    # Propagated from RequestContext.trace_id so post-call / audit plugins
    # can group rows into a single session trace.
    trace_id: Optional[str] = None


@dataclass
class Finding:
    """A single result from a DLP / guardrail / scan plugin."""

    plugin: str
    kind: str                  # e.g. "pii.email", "secret.aws", "prompt_injection"
    severity: str              # "info" | "warn" | "high" | "critical"
    message: str
    location: Optional[str] = None   # e.g. "messages[1].content[44:62]"
    redacted: bool = False


@dataclass
class HookResult:
    """What a hook returns. The runtime aggregates these per-stage."""

    verdict: PluginVerdict
    findings: list[Finding] = field(default_factory=list)
    mutations: dict[str, Any] = field(default_factory=dict)  # patches into RequestContext.extra
    reason: Optional[str] = None     # required when REFUSE/WARN
    # Override the default 422 on REFUSE. Common values:
    #   401 - unauthenticated  (auth plugin)
    #   403 - unauthorised     (authz plugin)
    #   429 - rate limited     (quota plugin, RPM/TPM)
    #   402 - budget exceeded  (quota plugin, daily budget)
    status_code: int = 422
    error_code: str = "policy_refused"
    extra_headers: dict[str, str] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Plugin base class — only the methods relevant to your plugin need to be
# implemented; the rest are no-ops by default.
# ---------------------------------------------------------------------------
class GatewayPlugin(ABC):
    """Inherit from this. Override only the hook methods you need."""

    # --- Metadata ----------------------------------------------------------
    name: str                  # unique, snake_case
    kind: PluginKind
    version: str = "0.1.0"
    description: str = ""
    config_schema: type | None = None  # optional pydantic model for validation

    # --- Lifecycle ---------------------------------------------------------
    async def setup(self, app_settings: dict[str, Any]) -> None:
        """Called once at startup. Open connections, load models, etc."""

    async def teardown(self) -> None:
        """Called once at shutdown."""

    # --- Per-request hooks (override only what you need) -------------------
    async def on_pre_call(self, ctx: RequestContext) -> HookResult:
        """Inspect / mutate the request before inference. Default: allow."""
        return HookResult(verdict=PluginVerdict.ALLOW)

    async def on_route_select(self, ctx: RequestContext) -> HookResult:
        """Pick a model. Set ctx.model_selected. ROUTER plugins only.

        Returns ALLOW once a model is set, REFUSE if no model is reachable.
        """
        return HookResult(verdict=PluginVerdict.ALLOW)

    async def on_post_call(self, ctx: ResponseContext) -> HookResult:
        """Inspect / mutate the response after inference. Default: allow."""
        return HookResult(verdict=PluginVerdict.ALLOW)

    async def on_audit(self, ctx: ResponseContext) -> None:
        """Write to durable storage. AUDIT plugins only. No verdict."""
