"""Plugin registry and loader.

Plugins are discovered three ways, in this order of precedence:

1. **Entry points** declared by installed packages under the group
   ``litellm_gateway.plugins``. This is how built-ins and third-party plugins
   register themselves identically.
2. **Explicit modules** named in the ``GATEWAY_PLUGINS`` environment variable
   (comma-separated, matched against the entry-point name).
3. **Auto-registered subclasses** of :class:`GatewayPlugin` imported anywhere
   in the running process (useful for tests).

The registry is queried per-stage by the hook runtime
(``gateway.hooks.*``).
"""

from __future__ import annotations

import importlib.metadata as md
import logging
from collections import defaultdict
from typing import Iterable

from .base import GatewayPlugin, PluginKind

log = logging.getLogger(__name__)

ENTRY_POINT_GROUP = "litellm_gateway.plugins"


class PluginRegistry:
    """In-memory registry of loaded plugin *instances*."""

    def __init__(self) -> None:
        self._by_name: dict[str, GatewayPlugin] = {}
        self._by_kind: dict[PluginKind, list[GatewayPlugin]] = defaultdict(list)

    # ------------------------------------------------------------------ load
    def clear(self) -> None:
        """Drop all registered plugins. Idempotent."""
        self._by_name.clear()
        self._by_kind.clear()

    def discover_and_load(self, enabled: Iterable[str] | None = None) -> None:
        """Walk entry points; instantiate the ones whose name is enabled.

        Idempotent — clears any previously loaded plugins first so calling
        this from a long-lived process (e.g. tests that re-run the lifespan)
        leaves a clean registry.

        If ``enabled`` is ``None``, load *every* registered entry point.
        """
        self.clear()
        enabled_set = set(enabled) if enabled is not None else None
        loaded_count = 0

        try:
            eps = md.entry_points(group=ENTRY_POINT_GROUP)
        except TypeError:
            # Python 3.9 compat
            eps = md.entry_points().get(ENTRY_POINT_GROUP, [])

        for ep in eps:
            if enabled_set is not None and ep.name not in enabled_set:
                continue
            try:
                cls = ep.load()
            except Exception as e:  # noqa: BLE001
                log.error("Failed to load plugin %s: %s", ep.name, e)
                continue
            if not (isinstance(cls, type) and issubclass(cls, GatewayPlugin)):
                log.error("Entry point %s did not resolve to a GatewayPlugin", ep.name)
                continue
            try:
                instance = cls()
            except Exception as e:  # noqa: BLE001
                log.error("Plugin %s failed to instantiate: %s", ep.name, e)
                continue
            self.register(instance)
            loaded_count += 1

        log.info("Plugin registry loaded %d plugin(s)", loaded_count)

    def register(self, plugin: GatewayPlugin) -> None:
        if plugin.name in self._by_name:
            log.warning("Plugin %s already registered; replacing", plugin.name)
        self._by_name[plugin.name] = plugin
        # Avoid duplicates inside the kind-bucket on re-registration.
        bucket = self._by_kind[plugin.kind]
        if plugin not in bucket:
            bucket.append(plugin)

    # ----------------------------------------------------------------- query
    def get(self, name: str) -> GatewayPlugin | None:
        return self._by_name.get(name)

    def of_kind(self, kind: PluginKind) -> list[GatewayPlugin]:
        return list(self._by_kind.get(kind, []))

    def all(self) -> list[GatewayPlugin]:
        return list(self._by_name.values())

    # --------------------------------------------------------------- lifecycle
    async def setup_all(self, app_settings: dict) -> None:
        for p in self.all():
            try:
                await p.setup(app_settings)
            except Exception as e:  # noqa: BLE001
                log.exception("Plugin %s setup failed: %s", p.name, e)

    async def teardown_all(self) -> None:
        for p in self.all():
            try:
                await p.teardown()
            except Exception as e:  # noqa: BLE001
                log.exception("Plugin %s teardown failed: %s", p.name, e)


# Module-level singleton — imported by hooks / main / tests.
registry = PluginRegistry()


__all__ = ["GatewayPlugin", "PluginKind", "PluginRegistry", "registry"]
