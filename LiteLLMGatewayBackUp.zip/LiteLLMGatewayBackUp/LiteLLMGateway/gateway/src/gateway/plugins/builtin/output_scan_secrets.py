"""Post-call secret scanner.

Detects leaked credentials in the model's *response* before it reaches the
developer's IDE. Built-in patterns cover the most common shapes; per-team
``policies.yaml -> output_scan.secrets`` can add custom regexes or change the
action (redact vs refuse).

Actions
-------
* ``redact`` (default) — replace each match with ``[REDACTED:<kind>]`` in the
  response payload, record a finding, return ``ALLOW_MUTATE``. The developer
  sees a scrubbed response with a visible marker — no silent loss of content.
* ``refuse`` — return ``REFUSE``. The gateway emits a 422 with the findings;
  the dev sees only the error.

Both actions audit critically-severe findings — security can investigate even
when redaction happened silently from the dev's perspective.

The plugin is intentionally regex-only (no `trufflehog` binary dependency)
so it works in any container without extra setup; for higher coverage you
can swap in the `output_scan_trufflehog` plugin (future, opt-in).
"""

from __future__ import annotations

import logging
import math
import re
from typing import Any

from ..base import (
    Finding,
    GatewayPlugin,
    HookResult,
    PluginKind,
    PluginVerdict,
    ResponseContext,
)

log = logging.getLogger(__name__)


# (kind, regex, severity)
SECRET_PATTERNS: list[tuple[str, str, str]] = [
    ("aws.access_key_id",     r"\bAKIA[0-9A-Z]{16}\b",                          "critical"),
    ("aws.secret_key",        r"(?i)aws[^a-z0-9]{0,3}secret[^a-z0-9]{0,3}(?:access[^a-z0-9]{0,3})?key[^a-z0-9]{0,5}[A-Za-z0-9/+=]{40}",  "critical"),
    ("github.pat_classic",    r"\bghp_[A-Za-z0-9]{36}\b",                       "critical"),
    ("github.pat_fine",       r"\bgithub_pat_[A-Za-z0-9_]{82}\b",               "critical"),
    ("github.oauth",          r"\bgho_[A-Za-z0-9]{36}\b",                       "critical"),
    ("slack.bot_token",       r"\bxoxb-[A-Za-z0-9-]{10,}\b",                    "critical"),
    ("slack.user_token",      r"\bxoxp-[A-Za-z0-9-]{10,}\b",                    "critical"),
    ("stripe.live_secret",    r"\bsk_live_[0-9a-zA-Z]{24,}\b",                  "critical"),
    ("openai.key",            r"\bsk-(?!dev[+-])[A-Za-z0-9_-]{32,}\b",          "high"),
    ("anthropic.key",         r"\bsk-ant-(?:api|admin)\d?-[A-Za-z0-9_-]{50,}\b","critical"),
    ("google.api_key",        r"\bAIza[0-9A-Za-z_-]{35}\b",                     "high"),
    ("jwt",                   r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b", "high"),
    ("private_key.pem",
        r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----",
        "critical"),
]


class SecretScanOutput(GatewayPlugin):
    name = "output_scan_secrets"
    kind = PluginKind.OUTPUT_SCAN
    description = "Detect + redact (or refuse) leaked credentials in model responses"

    def __init__(self) -> None:
        self._action: str = "redact"
        self._entropy_min_len: int = 40
        self._entropy_bits_per_char: float = 4.5
        self._patterns: list[tuple[str, re.Pattern[str], str]] = []

    async def setup(self, app_settings: dict[str, Any]) -> None:
        policies = app_settings.get("policies") or {}
        cfg = (policies.get("output_scan") or {}).get("secrets") or {}
        self._action = cfg.get("action", "redact")
        self._entropy_min_len     = int(cfg.get("entropy_min_len", 40))
        self._entropy_bits_per_char = float(cfg.get("entropy_bits_per_char", 4.5))

        compiled: list[tuple[str, re.Pattern[str], str]] = []
        for kind, pat, sev in SECRET_PATTERNS:
            compiled.append((kind, re.compile(pat), sev))
        for extra in cfg.get("extra_patterns") or []:
            try:
                compiled.append(("secret.custom", re.compile(extra.get("regex", "")),
                                 extra.get("severity", "high")))
            except re.error as e:
                log.warning("output_scan_secrets: bad custom regex %r: %s", extra, e)
        self._patterns = compiled

        log.info("output_scan_secrets: %d pattern(s); action=%s",
                 len(self._patterns), self._action)

    async def on_post_call(self, ctx: ResponseContext) -> HookResult:
        findings, total_subs = self._scan_and_redact(ctx)

        if not findings:
            return HookResult(verdict=PluginVerdict.ALLOW)

        # Critical findings ALWAYS refuse, regardless of policy — too dangerous
        # to risk a regex-redaction missing a wrapper context.
        any_critical = any(f.severity == "critical" for f in findings)

        if self._action == "refuse" or any_critical:
            # Replace the entire response with a sanitised error so the dev
            # never sees the leaked content.
            ctx.response = {
                "error": "Response blocked: leaked credentials detected",
                "findings": [_finding_to_dict(f) for f in findings],
            }
            return HookResult(
                verdict=PluginVerdict.REFUSE,
                status_code=422,
                error_code="output_blocked_by_policy",
                reason="Response contained leaked credentials",
                findings=findings,
            )

        # action == redact: response was already mutated in _scan_and_redact.
        return HookResult(
            verdict=PluginVerdict.ALLOW_MUTATE,
            findings=findings,
            reason=f"Redacted {total_subs} secret(s) from response",
        )

    # ------------------------------------------------------------------
    def _scan_and_redact(self, ctx: ResponseContext) -> tuple[list[Finding], int]:
        findings: list[Finding] = []
        total_subs = 0
        choices = (ctx.response or {}).get("choices") or []

        for i, choice in enumerate(choices):
            msg = choice.get("message") or {}
            content = msg.get("content")
            if not isinstance(content, str) or not content:
                continue

            new_content = content
            for kind, pat, severity in self._patterns:
                def _replace(m: re.Match[str], _kind: str = kind) -> str:
                    return f"[REDACTED:{_kind}]"

                new_content, n_subs = pat.subn(_replace, new_content)
                if n_subs > 0:
                    total_subs += n_subs
                    for m in pat.finditer(content):
                        findings.append(Finding(
                            plugin=self.name,
                            kind=f"secret.{kind}",
                            severity=severity,
                            message=f"{kind} pattern matched in response choice {i}",
                            location=f"choices[{i}].message.content[{m.start()}:{m.end()}]",
                            redacted=True,
                        ))

            # Optional high-entropy scan for things our patterns missed.
            entropy_findings = self._entropy_scan(content, i)
            if entropy_findings:
                # Redact via a generic replacement around each match.
                for f in entropy_findings:
                    findings.append(f)
                # We *don't* mutate content here — entropy hits are advisory,
                # not always actual secrets, and a bad redaction would corrupt
                # legit base64-encoded responses. Real secrets get caught by
                # the targeted patterns above.

            msg["content"] = new_content

        return findings, total_subs

    # ------------------------------------------------------------------
    def _entropy_scan(self, text: str, choice_idx: int) -> list[Finding]:
        out: list[Finding] = []
        # Tokenise on non-secret characters; only check tokens long enough to
        # plausibly be a secret.
        for m in re.finditer(r"[A-Za-z0-9_\-/+=]{%d,}" % self._entropy_min_len, text):
            token = m.group(0)
            bits = _shannon_bits(token)
            if bits >= self._entropy_bits_per_char:
                out.append(Finding(
                    plugin=self.name,
                    kind="secret.high_entropy",
                    severity="warn",
                    message=f"High-entropy token ({bits:.2f} bits/char, "
                            f"len={len(token)}) — may be a secret",
                    location=f"choices[{choice_idx}].message.content[{m.start()}:{m.end()}]",
                ))
        return out


def _shannon_bits(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    total = len(s)
    return -sum((c / total) * math.log2(c / total) for c in freq.values())


def _finding_to_dict(f: Finding) -> dict[str, Any]:
    return {"plugin": f.plugin, "kind": f.kind, "severity": f.severity,
            "message": f.message, "redacted": f.redacted}
