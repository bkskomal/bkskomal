"""Tier-based authorisation plugin.

Runs in the pre-call stage. It does NOT pick a model — that's the router's
job — but it does two things:

1. **Inject** the tier's allowed-models list into ``ctx.extra["allowed_models"]``
   so downstream router plugins can filter their rule output.
2. **Refuse** an explicit ``force:`` override that the caller's tier doesn't
   permit. (The router can still REFUSE later if its rule output would pick
   a model not in ``allowed_models``.)

Reading the tier configuration is a fast lookup against the in-memory dict
loaded from ``policies.yaml`` at startup — no DB round-trip per request.
"""

from __future__ import annotations

import logging
from typing import Any

from ..base import (
    Finding,
    GatewayPlugin,
    HookResult,
    PluginKind,
    PluginVerdict,
    RequestContext,
)

log = logging.getLogger(__name__)


# A "no-preference" model means the developer is letting the router pick.
# Match these case-insensitively. Kept module-local on purpose — the router
# plugin owns its own equivalent so the two stay independently swappable.
_NO_PREFERENCE_MODELS: frozenset[str] = frozenset({"", "auto"})


def _is_no_preference(model: str | None) -> bool:
    """True when the caller wants the router to pick (None / "" / "auto")."""
    if model is None:
        return True
    return model.strip().lower() in _NO_PREFERENCE_MODELS


class TieredAuthZ(GatewayPlugin):
    """Enforce per-tier model ACL + agent-mode + force-override permission.

    When `model` is the no-preference sentinel (None / "" / "auto", any case)
    the per-tier `models_allowed` membership check and the `override_model`
    check are skipped — there is nothing to compare against, the router will
    decide. All other AuthZ checks (tier known, agent_mode, etc.) still apply.
    """

    name = "authz_tiered"
    kind = PluginKind.AUTHZ
    description = "Enforce per-tier model ACL + agent-mode + force-override permission"

    def __init__(self) -> None:
        self.tiers: dict[str, dict[str, Any]] = {}

    async def setup(self, app_settings: dict[str, Any]) -> None:
        policies = app_settings.get("policies") or {}
        self.tiers = policies.get("tiers") or {}
        if not self.tiers:
            log.warning("authz_tiered: no tiers configured; will allow everything")
        else:
            log.info("authz_tiered: loaded %d tier(s): %s",
                     len(self.tiers), list(self.tiers))

    async def on_pre_call(self, ctx: RequestContext) -> HookResult:
        tier_name = ctx.principal.tier
        tier_cfg = self.tiers.get(tier_name)

        # Quarantined or unknown tier → refuse everything.
        if tier_cfg is None:
            return HookResult(
                verdict=PluginVerdict.REFUSE,
                reason=f"Unknown tier {tier_name!r}; access denied",
                findings=[Finding(plugin=self.name, kind="authz.unknown_tier",
                                  severity="high",
                                  message=f"Tier {tier_name!r} not in policies.yaml")],
            )

        allowed = tier_cfg.get("models_allowed") or []
        # "*" means "any model" — only used by L3_privileged in policies.yaml.
        wildcard = allowed == ["*"]
        ctx.extra["allowed_models"]  = list(allowed)
        ctx.extra["wildcard_models"] = wildcard
        ctx.extra["agent_mode"]      = tier_cfg.get("agent_mode", "disabled")
        ctx.extra["override_allowed"] = bool(tier_cfg.get("override_model"))

        # Quick reject for tiers with no models (e.g. "quarantined").
        if not wildcard and not allowed:
            return HookResult(
                verdict=PluginVerdict.REFUSE,
                reason=f"Tier {tier_name!r} has no models_allowed; access denied",
                findings=[Finding(plugin=self.name, kind="authz.no_models",
                                  severity="high",
                                  message=f"Tier {tier_name!r} blocks all models")],
            )

        # If caller used ?model=force:foo, verify that's allowed for this tier.
        # For the "no-preference" sentinel (None / "" / "auto") we skip both
        # the override-model and models_allowed membership checks entirely —
        # there's nothing to compare against; the router will pick.
        requested = ctx.model_requested or ""
        if not _is_no_preference(ctx.model_requested):
            if requested.startswith("force:"):
                if not tier_cfg.get("override_model"):
                    return HookResult(
                        verdict=PluginVerdict.REFUSE,
                        reason=f"Tier {tier_name!r} cannot override model selection",
                        findings=[Finding(plugin=self.name,
                                          kind="authz.override_forbidden",
                                          severity="high",
                                          message=f"force: override blocked by tier")],
                    )
                forced = requested[len("force:"):]
                if not wildcard and forced not in allowed:
                    return HookResult(
                        verdict=PluginVerdict.REFUSE,
                        reason=f"Tier {tier_name!r} cannot call {forced!r}",
                        findings=[Finding(plugin=self.name,
                                          kind="authz.model_forbidden",
                                          severity="high",
                                          message=f"{forced!r} not in tier's models_allowed")],
                    )
            elif not wildcard and requested not in allowed:
                # Plain (non-force) explicit model name not in the tier's
                # allow-list. This preserves the 422 for callers who name a
                # model they're not entitled to (e.g. L1 asking for kimi).
                return HookResult(
                    verdict=PluginVerdict.REFUSE,
                    reason=f"Tier {tier_name!r} cannot call {requested!r}",
                    findings=[Finding(plugin=self.name,
                                      kind="authz.model_forbidden",
                                      severity="high",
                                      message=f"{requested!r} not in tier's models_allowed")],
                )

        # If caller passed tools but the tier disables agent mode → refuse.
        if ctx.tools and tier_cfg.get("agent_mode") in (None, "disabled"):
            return HookResult(
                verdict=PluginVerdict.REFUSE,
                reason=f"Tier {tier_name!r} cannot use tool-calling (agent mode disabled)",
                findings=[Finding(plugin=self.name,
                                  kind="authz.agent_forbidden",
                                  severity="warn",
                                  message="tools[] supplied but agent_mode is disabled")],
            )

        return HookResult(verdict=PluginVerdict.ALLOW)
