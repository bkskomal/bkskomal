"""User-Entity Behaviour Analytics — real-time anomaly signals.

What it does
------------
Runs in the post-call stage on every request (allowed AND refused). Maintains
short-lived counters in Redis (or in-memory fallback) per user, and raises
durable rows in the operational DB's ``ueba_alerts`` table when configured
thresholds are crossed. Prometheus metric ``gateway_ueba_alerts_total`` is
incremented for every alert so dashboards / Alertmanager can pick them up.

Signals implemented in this slice (the seven that are computable from
request metadata alone — no external classifier):

  1.  jailbreak_attempts     — guardrail_blocked findings per user / day
  2.  refusal_velocity       — any refusal per user, 5-min rolling
  3.  dlp_hit_rate           — DLP findings per user / week
  4.  output_secret_leaks    — output_scan_secrets findings per user / day
  5.  off_hours_activity     — request outside the user's recent hour-of-day band
  6.  volume_spike           — tokens today vs the user's 7-day median
  7.  model_mix_shift        — premium-model usage > 50% when historical avg <10%

Signals 5-7 require a rolling baseline. To keep this slice landable, the
plugin tracks **only today + last 7 days** of hourly buckets per user in
Redis sorted sets; the baseline is recomputed on demand.

Thresholds + retention live in policies.yaml::

    ueba:
      enabled: true
      thresholds:
        jailbreak_attempts:   { per: day,    count: 5,  severity: high }
        refusal_velocity:     { per: 5min,   count: 10, severity: high }
        dlp_hit_rate:         { per: week,   count: 5,  severity: warn }
        output_secret_leaks:  { per: day,    count: 1,  severity: critical }
"""

from __future__ import annotations

import json
import logging
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from ...models import UebaAlert
from ..base import (
    GatewayPlugin,
    HookResult,
    PluginKind,
    PluginVerdict,
    ResponseContext,
)

log = logging.getLogger(__name__)


DEFAULT_THRESHOLDS: dict[str, dict[str, Any]] = {
    "jailbreak_attempts":   {"per": "day",  "count": 5,  "severity": "high"},
    "refusal_velocity":     {"per": "5min", "count": 10, "severity": "high"},
    "dlp_hit_rate":         {"per": "week", "count": 5,  "severity": "warn"},
    "output_secret_leaks":  {"per": "day",  "count": 1,  "severity": "critical"},
    # Admin-flow signals — emitted by the elevations service, not the
    # post_call request path. Counted in the same Redis space so the SOC
    # can see them on the same dashboard alongside request-flow anomalies.
    "elevation_self_approval_attempts": {"per": "day",  "count": 1, "severity": "critical"},
    "elevation_burst_rejections":       {"per": "hour", "count": 3, "severity": "warn"},
}

# Window key + TTL for each admin signal. Kept here (rather than computed
# inline) so the elevation service path stays a one-line emit call.
_ADMIN_SIGNAL_WINDOWS = {
    "elevation_self_approval_attempts": ("day",  129600),   # 36h TTL
    "elevation_burst_rejections":       ("hour",   7200),   # 2h TTL
}


@dataclass
class _CounterUpdate:
    signal: str
    new_value: int
    threshold: int
    severity: str
    details: dict[str, Any]


# ---------------------------------------------------------------------------
# Counter backend (Redis or in-memory)
# ---------------------------------------------------------------------------
class _Counters:
    async def incr(self, key: str, ttl_seconds: int) -> int: ...
    async def incrby(self, key: str, amount: int, ttl_seconds: int) -> int: ...
    async def get(self, key: str) -> int: ...
    async def scan(self, prefix: str) -> dict[str, int]: ...
    async def aclose(self) -> None: ...


class _InMemoryCounters(_Counters):
    def __init__(self) -> None:
        self._v: dict[str, int]   = defaultdict(int)
        self._x: dict[str, float] = {}

    def _purge(self) -> None:
        now = time.time()
        for k in list(self._x.keys()):
            if self._x[k] <= now:
                self._v.pop(k, None)
                self._x.pop(k, None)

    async def incr(self, key: str, ttl_seconds: int) -> int:
        self._purge()
        self._v[key] += 1
        self._x[key] = time.time() + ttl_seconds
        return self._v[key]

    async def incrby(self, key: str, amount: int, ttl_seconds: int) -> int:
        self._purge()
        self._v[key] += int(amount)
        self._x[key] = time.time() + ttl_seconds
        return self._v[key]

    async def get(self, key: str) -> int:
        self._purge()
        return self._v.get(key, 0)

    async def scan(self, prefix: str) -> dict[str, int]:
        self._purge()
        return {k: v for k, v in self._v.items() if k.startswith(prefix)}

    async def aclose(self) -> None:
        pass


class _RedisCounters(_Counters):
    def __init__(self, client) -> None:
        self._r = client

    async def incr(self, key: str, ttl_seconds: int) -> int:
        pipe = self._r.pipeline()
        pipe.incr(key); pipe.expire(key, ttl_seconds)
        val, _ = await pipe.execute()
        return int(val)

    async def incrby(self, key: str, amount: int, ttl_seconds: int) -> int:
        pipe = self._r.pipeline()
        pipe.incrby(key, int(amount)); pipe.expire(key, ttl_seconds)
        val, _ = await pipe.execute()
        return int(val)

    async def get(self, key: str) -> int:
        v = await self._r.get(key)
        return int(v) if v is not None else 0

    async def scan(self, prefix: str) -> dict[str, int]:
        out: dict[str, int] = {}
        cursor = 0
        while True:
            cursor, keys = await self._r.scan(cursor=cursor,
                                              match=prefix + "*", count=200)
            for k in keys:
                k_str = k if isinstance(k, str) else k.decode("utf-8")
                v = await self._r.get(k_str)
                if v is not None:
                    try: out[k_str] = int(v)
                    except (TypeError, ValueError): pass
            if cursor == 0:
                break
        return out

    async def aclose(self) -> None:
        try:
            await self._r.aclose()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# Plugin
# ---------------------------------------------------------------------------
class UebaObserver(GatewayPlugin):
    name = "observe_ueba"
    kind = PluginKind.OBSERVE
    description = "Real-time UEBA — threshold alerts on jailbreak / refusal / DLP / leak"

    def __init__(self) -> None:
        self._counters: Optional[_Counters] = None
        self._thresholds: dict[str, dict[str, Any]] = dict(DEFAULT_THRESHOLDS)
        self._enabled: bool = True
        self._engine = None
        self._SessionLocal: async_sessionmaker[AsyncSession] | None = None

    async def setup(self, app_settings: dict[str, Any]) -> None:
        cfg = (app_settings.get("policies") or {}).get("ueba") or {}
        self._enabled = bool(cfg.get("enabled", True))
        for k, v in (cfg.get("thresholds") or {}).items():
            self._thresholds[k] = {**self._thresholds.get(k, {}), **v}

        url = app_settings.get("redis_url") or "memory://"
        if url.startswith("memory://"):
            self._counters = _InMemoryCounters()
            log.warning("observe_ueba: using in-process counters (dev / test mode)")
        else:
            try:
                from redis.asyncio import Redis
                client = Redis.from_url(url, decode_responses=True)
                await client.ping()
                self._counters = _RedisCounters(client)
            except Exception as e:  # noqa: BLE001
                log.warning("observe_ueba: Redis unreachable (%s); using in-memory", e)
                self._counters = _InMemoryCounters()

        # The alerts table lives in the OPERATIONAL DB, not the audit DB.
        from ..base import RequestContext  # noqa: F401  (avoid circular at module load)
        from ...config import get_settings
        s = get_settings()
        self._engine = create_async_engine(s.db_url, future=True)
        self._SessionLocal = async_sessionmaker(self._engine, expire_on_commit=False)
        log.info("observe_ueba ready (enabled=%s, signals=%s)",
                 self._enabled, list(self._thresholds))

    async def teardown(self) -> None:
        if self._counters is not None:
            await self._counters.aclose()
        if self._engine is not None:
            await self._engine.dispose()

    # ----- Post-call: tally signals and alert if thresholds tripped --------
    async def on_post_call(self, ctx: ResponseContext) -> HookResult:
        if not self._enabled or self._counters is None:
            return HookResult(verdict=PluginVerdict.ALLOW)

        updates: list[_CounterUpdate] = []
        user = ctx.principal.user_id
        team = ctx.principal.team_id
        tier = ctx.principal.tier
        today = _today_utc()
        five_min = _epoch_5min_bucket()
        week = _iso_week()
        hour_bucket = _epoch_hour_bucket()

        # --- Baseline (per-user hour-of-day token + req counts, model mix) ---
        # 8-day TTL so a 7-day rolling window always has the previous bucket
        # values still alive at lookup time.
        BASELINE_TTL = 8 * 24 * 3600
        total_tokens = (ctx.tokens_in or 0) + (ctx.tokens_out or 0)
        if total_tokens:
            await self._counters.incrby(
                f"ueba:bl:tok:{user}:{hour_bucket}",
                total_tokens, BASELINE_TTL,
            )
        await self._counters.incr(
            f"ueba:bl:req:{user}:{hour_bucket}", BASELINE_TTL,
        )
        if ctx.model_used:
            await self._counters.incr(
                f"ueba:bl:model:{user}:{ctx.model_used}", BASELINE_TTL,
            )

        # --- Signal 1: jailbreak_attempts (per day) -----------------------
        jb_count = sum(1 for f in ctx.findings
                       if f.kind.startswith("prompt_injection."))
        if jb_count:
            upd = await self._bump(
                key=f"ueba:jb:{user}:{today}",
                ttl=129600,
                signal="jailbreak_attempts",
                amount=jb_count,
            )
            if upd:
                updates.append(upd)

        # --- Signal 2: refusal_velocity (per 5 min) -----------------------
        was_refused = (
            isinstance(ctx.response, dict) and ctx.response.get("error")
        ) or any(f.severity in ("high", "critical") for f in ctx.findings)
        if was_refused:
            upd = await self._bump(
                key=f"ueba:refv:{user}:{five_min}",
                ttl=600,
                signal="refusal_velocity",
                amount=1,
            )
            if upd:
                updates.append(upd)

        # --- Signal 3: dlp_hit_rate (per week) ----------------------------
        dlp_count = sum(1 for f in ctx.findings if f.kind.startswith(("pii.", "secret.", "regulated.")))
        if dlp_count:
            upd = await self._bump(
                key=f"ueba:dlp:{user}:{week}",
                ttl=691200,                  # 8 days
                signal="dlp_hit_rate",
                amount=dlp_count,
            )
            if upd:
                updates.append(upd)

        # --- Signal 4: output_secret_leaks (per day) ----------------------
        leak_count = sum(1 for f in ctx.findings
                         if f.kind.startswith("secret.")
                         and f.plugin == "output_scan_secrets")
        if leak_count:
            upd = await self._bump(
                key=f"ueba:leak:{user}:{today}",
                ttl=129600,
                signal="output_secret_leaks",
                amount=leak_count,
            )
            if upd:
                updates.append(upd)

        # Persist any alerts that crossed their threshold THIS request.
        for u in updates:
            await self._raise_alert(user=user, team=team, tier=tier, upd=u, ctx=ctx)

        # ---- Auto-quarantine ---------------------------------------------
        # Count how many distinct critical/high signals fired in the last
        # day. ≥3 → flip the user's API keys to inactive ("quarantined").
        # The decision is single-direction: re-activation is a 4-eyes admin
        # action via /keys, never automatic. This is the "trip the breaker"
        # arm — humans rearm.
        critical_today = 0
        for sig_key in ("ueba:jb",  "ueba:leak"):       # day-windowed signals
            critical_today += await self._counters.get(f"{sig_key}:{user}:{today}")
        critical_today += await self._counters.get(
            f"ueba:elevation_self_approval_attempts:{user}:{today}"
        )
        if critical_today >= 3 and not await self._counters.get(
                f"ueba:quarantined:{user}"):
            try:
                await self._auto_quarantine(user_id=user, reason=(
                    f"{critical_today} critical UEBA signals in 24h"))
                # Mark so we don't re-quarantine on every request.
                await self._counters.incr(f"ueba:quarantined:{user}", 86400)
            except Exception:                            # noqa: BLE001
                log.exception("auto_quarantine failed for user=%s", user)

        return HookResult(verdict=PluginVerdict.ALLOW)

    # ----- Admin-flow signals ---------------------------------------------
    async def record_admin_event(
        self, *, user_id: str, team_id: str, tier: str, signal: str,
    ) -> None:
        """Record an admin-API behavioural signal (e.g. self-approve attempt).

        Distinct from on_post_call, which only sees /v1/chat/completions
        traffic — these signals come from the elevations service and other
        admin paths. They share the same counter store and threshold rules
        so the SOC sees one consolidated alert stream.
        """
        if not self._enabled or self._counters is None:
            return
        win = _ADMIN_SIGNAL_WINDOWS.get(signal)
        if win is None:
            log.warning("observe_ueba: unknown admin signal %r — ignored", signal)
            return
        window_key, ttl = win
        if window_key == "day":
            bucket = _today_utc()
        elif window_key == "hour":
            bucket = _epoch_hour_bucket()
        elif window_key == "week":
            bucket = _iso_week()
        else:                                   # noqa: E501 - exhaustive
            bucket = window_key
        key = f"ueba:{signal}:{user_id}:{bucket}"
        upd = await self._bump(key=key, ttl=ttl, signal=signal, amount=1)
        if upd:
            await self._raise_alert(
                user=user_id, team=team_id, tier=tier, upd=upd, ctx=None,
            )

    # ----- Snapshot accessors used by /admin/ueba --------------------------
    async def state_for_user(self, user_id: str) -> dict[str, Any]:
        if self._counters is None:
            return {}
        today    = _today_utc()
        five_min = _epoch_5min_bucket()
        week     = _iso_week()
        return {
            "jailbreak_attempts_today":   await self._counters.get(f"ueba:jb:{user_id}:{today}"),
            "refusal_velocity_5min":      await self._counters.get(f"ueba:refv:{user_id}:{five_min}"),
            "dlp_hits_week":              await self._counters.get(f"ueba:dlp:{user_id}:{week}"),
            "output_secret_leaks_today":  await self._counters.get(f"ueba:leak:{user_id}:{today}"),
        }

    async def radar_for_user(self, user_id: str) -> dict[str, Any]:
        """10-dimensional behavioural fingerprint for ``user_id``.

        Each dimension is normalised to 0..100 where:
            0   = at baseline / no concern
            50  = halfway to the threshold for that signal
            100 = threshold tripped (or worse)

        Six of the signals come from live counters (jailbreak, refusal,
        DLP, leaks, self-approval, elevation-burst). The remaining four
        are derived from the 7-day baseline:

            * off_hours    — current hour's typical traffic vs other hours
            * volume_spike — today's tokens vs 7-day daily median
            * model_mix    — current hour's premium-model fraction vs
                             the 7-day average premium fraction
            * quarantine   — 100 if any of the user's keys are inactive
                             due to auto-quarantine, else 0

        The radar is intended for the SOC's "is this user behaving
        unusually?" glance. It is NOT a hard alert — that's what
        ueba_alerts is for.
        """
        if self._counters is None:
            return {"enabled": False, "user_id": user_id}

        today    = _today_utc()
        five_min = _epoch_5min_bucket()
        week     = _iso_week()
        hour     = _epoch_hour_bucket()
        now_hod  = (hour) % 24

        # ---- Counter-based signals (1-6) ---------------------------------
        def _norm(value: int, threshold: int) -> float:
            if threshold <= 0:
                return 0.0
            return round(min(100.0, (value / threshold) * 100.0), 1)

        def _t(name: str, default: int) -> int:
            cfg = self._thresholds.get(name) or {}
            v = cfg.get("count")
            return int(v) if isinstance(v, int) and v > 0 else default

        scores: dict[str, float] = {}
        scores["jailbreak"]     = _norm(
            await self._counters.get(f"ueba:jb:{user_id}:{today}"),
            _t("jailbreak_attempts", 5))
        scores["refusal"]       = _norm(
            await self._counters.get(f"ueba:refv:{user_id}:{five_min}"),
            _t("refusal_velocity", 10))
        scores["dlp"]           = _norm(
            await self._counters.get(f"ueba:dlp:{user_id}:{week}"),
            _t("dlp_hit_rate", 5))
        scores["secret_leak"]   = _norm(
            await self._counters.get(f"ueba:leak:{user_id}:{today}"),
            _t("output_secret_leaks", 1))
        scores["self_approval"] = _norm(
            await self._counters.get(
                f"ueba:elevation_self_approval_attempts:{user_id}:{today}"),
            _t("elevation_self_approval_attempts", 1))
        scores["elev_burst"]    = _norm(
            await self._counters.get(
                f"ueba:elevation_burst_rejections:{user_id}:{hour}"),
            _t("elevation_burst_rejections", 3))

        # ---- Baseline-derived signals (7-9) ------------------------------
        # We only need a short scan of the per-hour baseline counters to
        # compute these; cheap on the in-memory backend, scan on Redis.
        hour_tok = await self._counters.get(f"ueba:bl:tok:{user_id}:{hour}")
        hod_totals: list[int] = [0] * 24
        seven_day_total = 0
        for offset in range(7 * 24):
            b = hour - offset
            v = await self._counters.get(f"ueba:bl:tok:{user_id}:{b}")
            if v:
                hod_totals[b % 24] += int(v)
                seven_day_total   += int(v)

        # Off-hours: current hour-of-day's typical share. If this hour
        # historically holds <= 3% of the user's traffic but is firing now,
        # that's a 100. Bias toward "no judgement when there's no data."
        if seven_day_total > 0:
            this_hour_share = hod_totals[now_hod] / seven_day_total
            # 1/24 == 4.17%, so anything below half that is "atypical".
            scores["off_hours"] = round(
                min(100.0, max(0.0, (1.0 - this_hour_share * 24)) * 100.0), 1)
            if hour_tok == 0:
                # No traffic this hour at all — there's nothing anomalous to score.
                scores["off_hours"] = 0.0
        else:
            scores["off_hours"] = 0.0

        # Volume spike: today's tokens vs the user's 7-day daily median.
        # Have to materialise into list comprehensions explicitly because
        # `sum(... await ... for ...)` builds an async generator that sum()
        # can't consume.
        today_total = 0
        for h in range(24):
            v = await self._counters.get(f"ueba:bl:tok:{user_id}:{hour - h}")
            today_total += int(v or 0)
        daily_totals: list[int] = []
        for d in range(1, 7):
            day_total = 0
            for h in range(24):
                v = await self._counters.get(
                    f"ueba:bl:tok:{user_id}:{hour - 24 * d - h}"
                )
                day_total += int(v or 0)
            daily_totals.append(day_total)
        non_zero = [d for d in daily_totals if d > 0]
        if non_zero:
            median = sorted(non_zero)[len(non_zero) // 2]
            # 2x median = 50, 4x median = 100.
            ratio = today_total / max(1, median)
            scores["volume_spike"] = round(min(100.0, max(0.0,
                                            (ratio - 1.0) * 33.0)), 1)
        else:
            scores["volume_spike"] = 0.0

        # Model mix: this hour's premium-model fraction vs the 7-day average.
        # We treat any model name containing "kimi" or "gpt-4" or "claude"
        # or "openrouter" as premium for this heuristic.
        models = await self._counters.scan(f"ueba:bl:model:{user_id}:") \
                 if hasattr(self._counters, "scan") else {}
        prem = sum(v for k, v in (models or {}).items()
                   if any(s in k.lower() for s in ("kimi", "gpt-4", "claude",
                                                   "openrouter")))
        total = sum((models or {}).values()) or 1
        prem_ratio_7d = prem / total
        # Without per-hour model breakdown we use the same value as "now"
        # for a simple "is this user currently a heavy premium user?" gauge.
        # 0% premium → 0 score; 100% premium → 100 score, but only when the
        # 7-day baseline shows much lower premium use (otherwise this is
        # just normal for them).
        scores["model_mix"] = round(min(100.0,
                                        max(0.0, (prem_ratio_7d - 0.10) * 200)),
                                    1)

        # ---- Quarantine state (10) ---------------------------------------
        quar_marker = await self._counters.get(f"ueba:quarantined:{user_id}")
        scores["quarantine"] = 100.0 if quar_marker else 0.0

        return {
            "enabled":    True,
            "user_id":    user_id,
            "scores":     scores,
            "total_score": round(sum(scores.values()) / len(scores), 1),
            "axes": [
                {"key": "jailbreak",     "label": "Jailbreak"},
                {"key": "refusal",       "label": "Refusal velocity"},
                {"key": "dlp",           "label": "DLP hits"},
                {"key": "secret_leak",   "label": "Output leaks"},
                {"key": "self_approval", "label": "Self-approve"},
                {"key": "elev_burst",    "label": "Elev. burst"},
                {"key": "off_hours",     "label": "Off-hours"},
                {"key": "volume_spike",  "label": "Volume spike"},
                {"key": "model_mix",     "label": "Premium-model mix"},
                {"key": "quarantine",    "label": "Quarantined"},
            ],
        }

    async def baseline_for_user(self, user_id: str) -> dict[str, Any]:
        """Per-user rolling baseline: tokens by hour-of-day, model mix, total
        request count over the last 7 days. Computed on demand from the
        in-memory hour-bucket counters that on_post_call maintains.

        The baselines are intentionally lightweight (24 hour-of-day buckets +
        N model-name buckets per user). This is enough for the SOC to spot
        "user normally hits the gateway between 9am and 5pm, why is there a
        4am spike?" or "this user has never used kimi before; why is their
        last hour 90% kimi?" — both classic insider-misuse fingerprints.
        """
        if self._counters is None:
            return {"enabled": False}
        # Gather token-by-hour counts for the last 7 days (168 hourly buckets
        # collapsed to 24 hour-of-day slots).
        now_h = _epoch_hour_bucket()
        hour_of_day_tokens: dict[int, int] = {h: 0 for h in range(24)}
        total_requests = 0
        for offset in range(7 * 24):
            bucket = now_h - offset
            tok_key = f"ueba:bl:tok:{user_id}:{bucket}"
            req_key = f"ueba:bl:req:{user_id}:{bucket}"
            tok = await self._counters.get(tok_key)
            req = await self._counters.get(req_key)
            if tok or req:
                hod = (bucket * 3600 // 3600) % 24
                hour_of_day_tokens[hod] += int(tok or 0)
                total_requests += int(req or 0)
        # Model mix — flat dict over the 7-day window.
        models = await self._counters.scan(f"ueba:bl:model:{user_id}:") \
                 if hasattr(self._counters, "scan") else {}
        return {
            "enabled":            True,
            "user_id":            user_id,
            "window_days":        7,
            "total_requests":     total_requests,
            "hour_of_day_tokens": hour_of_day_tokens,
            "model_mix":          {k.rsplit(":", 1)[-1]: v for k, v in (models or {}).items()},
        }

    # ----- Internals --------------------------------------------------------
    async def _bump(self, *, key: str, ttl: int, signal: str,
                    amount: int) -> Optional[_CounterUpdate]:
        # The plugin's counter interface only supports unit-INCR, so loop.
        new_value = 0
        for _ in range(amount):
            new_value = await self._counters.incr(key, ttl)

        cfg = self._thresholds.get(signal) or {}
        threshold = cfg.get("count")
        if not isinstance(threshold, int) or threshold <= 0:
            return None
        # Only fire when we CROSS the threshold (not on every call after).
        if new_value - amount < threshold <= new_value:
            return _CounterUpdate(
                signal=signal,
                new_value=new_value,
                threshold=threshold,
                severity=cfg.get("severity", "warn"),
                details={
                    "window":      cfg.get("per"),
                    "threshold":   threshold,
                    "observed":    new_value,
                    "increment":   amount,
                },
            )
        return None

    async def _auto_quarantine(self, *, user_id: str, reason: str) -> None:
        """Flip every active virtual key for ``user_id`` to is_active=False
        and raise a critical UEBA alert tagged ``auto_quarantine``.

        Re-activation is intentionally manual — a SOC engineer must inspect
        the alert + audit trail and re-enable individual keys via /keys.
        """
        if self._SessionLocal is None:
            return
        from sqlalchemy import update as _update
        from ...models import VirtualKey
        async with self._SessionLocal() as session:
            res = await session.execute(
                _update(VirtualKey)
                .where(VirtualKey.user_id == user_id,
                       VirtualKey.is_active.is_(True))
                .values(is_active=False)
            )
            n = res.rowcount or 0
            await session.commit()
        log.warning(
            "AUTO-QUARANTINE: user=%s — %d key(s) deactivated. Reason: %s",
            user_id, n, reason,
        )
        # Surface as a critical alert so the SOC sees it in /monitoring.
        if n > 0:
            cu = _CounterUpdate(
                signal="auto_quarantine", new_value=n, threshold=1,
                severity="critical",
                details={"reason": reason, "keys_deactivated": n},
            )
            await self._raise_alert(
                user=user_id, team="?", tier="?", upd=cu, ctx=None,
            )

    async def _raise_alert(self, *, user: str, team: str, tier: str,
                           upd: _CounterUpdate,
                           ctx: Optional[ResponseContext]) -> None:
        if self._SessionLocal is None:
            return
        # Prometheus
        try:
            from ...main import UEBA_ALERT_COUNT
            UEBA_ALERT_COUNT.labels(upd.signal, upd.severity).inc()
        except Exception:  # noqa: BLE001
            pass
        # Postgres
        try:
            async with self._SessionLocal() as session:
                row = UebaAlert(
                    user_id=user,
                    team_id=team,
                    tier=tier,
                    signal=upd.signal,
                    severity=upd.severity,
                    summary=(f"{upd.signal}: {upd.new_value} in "
                             f"{upd.details.get('window', 'window')} "
                             f"(threshold {upd.threshold})"),
                    details=upd.details,
                    status="open",
                )
                session.add(row)
                await session.commit()
        except Exception as e:  # noqa: BLE001
            log.exception("Failed to persist UEBA alert (%s): %s", upd.signal, e)


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------
def _today_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _iso_week() -> str:
    iso = datetime.now(timezone.utc).isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


def _epoch_5min_bucket() -> int:
    return int(time.time() // 300)


def _epoch_hour_bucket() -> int:
    return int(time.time() // 3600)
