"""Append-only audit-log plugin.

Writes one row per request to the audit Postgres after the inference call.
Stores hashes always; encrypted ciphertext only when team policy requires
plaintext retention (default: hashes only — minimises blast radius).

Hot-path concerns
-----------------
* Writes use a dedicated async engine (no shared connection with operational DB).
* We use ``run_in_executor`` style: the audit insert is awaited, so a stalled
  DB will surface as gateway latency rather than silent data loss. Logging
  is the source of truth — never best-effort.
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker, create_async_engine

from ...models import AuditLog
from ..base import (
    GatewayPlugin,
    PluginKind,
    ResponseContext,
)

log = logging.getLogger(__name__)


class PostgresAudit(GatewayPlugin):
    name = "audit_postgres"
    kind = PluginKind.AUDIT
    description = "Append-only Postgres audit log; one row per gateway call"

    def __init__(self) -> None:
        self._engine: AsyncEngine | None = None
        self._SessionLocal = None

    async def setup(self, app_settings: dict[str, Any]) -> None:
        dsn = app_settings.get("audit_db_url")
        if not dsn:
            log.error("audit_postgres: GATEWAY_AUDIT_DB_URL not set; audit DISABLED")
            return
        self._engine = create_async_engine(dsn, pool_pre_ping=True, future=True)
        self._SessionLocal = async_sessionmaker(self._engine, expire_on_commit=False)

        # Ensure schema exists. Idempotent. In real deployments Alembic owns this.
        async with self._engine.begin() as conn:
            from ...db import Base
            await conn.run_sync(Base.metadata.create_all, tables=[AuditLog.__table__])
        log.info("audit_postgres ready (dsn=%s)", _redact_dsn(dsn))

    async def teardown(self) -> None:
        if self._engine is not None:
            await self._engine.dispose()

    async def on_audit(self, ctx: ResponseContext) -> None:
        if self._SessionLocal is None:
            return
        try:
            prompt_text = _canonical_messages(ctx.extra.get("messages", []))
            response_text = _canonical_response(ctx.response)
            verdict = _verdict_for(ctx)

            # AES-GCM encrypt prompt + response when GATEWAY_AUDIT_KEY is set.
            # Hash columns are always populated (they're safe to expose to
            # platform ops); ciphertext columns are populated only when
            # encryption is configured + the 4-eyes reveal flow is in scope.
            from ... import crypto
            prompt_ct   = crypto.encrypt(prompt_text.encode("utf-8")) if prompt_text else None
            response_ct = crypto.encrypt(response_text.encode("utf-8")) if response_text else None

            row = AuditLog(
                request_id=ctx.request_id,
                # Default rule lives HERE — the only place audit_log rows
                # are written. When no client-sent trace was propagated,
                # every row's trace_id falls back to its request_id so
                # single-call requests still produce a queryable trace.
                trace_id=getattr(ctx, "trace_id", None) or ctx.request_id,
                user_id=ctx.principal.user_id,
                user_email=ctx.principal.email,
                team_id=ctx.principal.team_id,
                tier=ctx.principal.tier,
                base_tier=getattr(ctx.principal, "base_tier", None),
                elevation_id=getattr(ctx.principal, "elevation_id", None),
                model_requested=ctx.extra.get("model_requested"),
                model_used=ctx.model_used,
                routing_reason=ctx.extra.get("routing_reason"),
                tokens_in=ctx.tokens_in,
                tokens_out=ctx.tokens_out,
                latency_ms=ctx.latency_ms,
                cost_usd=ctx.cost_usd,
                prompt_hash=_sha256(prompt_text),
                response_hash=_sha256(response_text),
                prompt_ciphertext=prompt_ct,
                response_ciphertext=response_ct,
                verdict=verdict,
                findings=[_finding_to_dict(f) for f in ctx.findings] if ctx.findings else None,
                client_ip=ctx.extra.get("client_ip"),
                user_agent=ctx.extra.get("user_agent"),
            )
            async with self._SessionLocal() as session:
                session.add(row)
                await session.commit()
        except Exception as e:  # noqa: BLE001
            log.exception("audit_postgres write failed for request_id=%s: %s",
                          ctx.request_id, e)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _canonical_messages(messages: list[dict]) -> str:
    return json.dumps(messages, sort_keys=True, ensure_ascii=False)


def _canonical_response(response: dict) -> str:
    # Just the assistant-visible content; ignore metadata fields that vary
    # across providers and would change the hash for free.
    try:
        choices = response.get("choices") or []
        bits: list[str] = []
        for c in choices:
            msg = (c.get("message") or {})
            content = msg.get("content")
            if isinstance(content, str):
                bits.append(content)
            elif isinstance(content, list):
                bits.append(json.dumps(content, sort_keys=True))
        return "\n".join(bits)
    except Exception:  # noqa: BLE001
        return json.dumps(response, sort_keys=True, ensure_ascii=False)


def _finding_to_dict(f) -> dict:
    return {
        "plugin":   f.plugin,
        "kind":     f.kind,
        "severity": f.severity,
        "message":  f.message,
        "location": f.location,
        "redacted": f.redacted,
    }


def _verdict_for(ctx: ResponseContext) -> str:
    """Map a ResponseContext to the durable audit verdict."""
    # main.py synthesises a ResponseContext with model_used like
    # "(refused-pre-routing)" when a pre-call plugin REFUSEd; recognise that
    # marker first.
    mu = (ctx.model_used or "").lower()
    if mu.startswith("(refused"):
        return "refused"
    if isinstance(ctx.response, dict) and ctx.response.get("error"):
        return "error"
    if any(f.severity == "critical" for f in ctx.findings):
        return "refused"
    return "allow"


def _redact_dsn(dsn: str) -> str:
    # Hide the password in logs.
    import re
    return re.sub(r":([^:@]+)@", r":***@", dsn)
