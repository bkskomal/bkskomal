"""SIEM forwarder — pushes audit events to Splunk HEC / Elastic / generic webhook.

Why a separate plugin (not bolted into audit_postgres)
------------------------------------------------------
Postgres is the source of truth and stays append-only forever; SIEM is
typically a 90-day operational store the SOC actually looks at, with its
own indexing + alerting. Keeping the two pipes independent means a
misconfigured SIEM destination never blocks the operational write — the
Postgres row lands first, the SIEM forward is best-effort with retries.

What it forwards
----------------
One JSON document per request, in a Splunk-HEC / ELK-friendly shape:

    {
        "time":   <epoch seconds>,
        "host":   "<gateway-host>",
        "source": "litellm-gateway",
        "sourcetype": "_json",
        "event": {
            "request_id":     "...",
            "user_id":        "...",
            "user_email":     "...",
            "team_id":        "...",
            "tier":           "...",
            "model_used":     "...",
            "verdict":        "allow|refused|error",
            "tokens_in":      N,
            "tokens_out":     N,
            "latency_ms":     N,
            "cost_usd":       N,
            "prompt_hash":    "...",
            "response_hash":  "...",
            "findings":       [...]   # plugin/kind/severity only — no content
        }
    }

The "event" object intentionally carries hashes + finding metadata only;
content/PII never traverses the SIEM pipe. Operators who need plaintext
go through the (separate) 4-eyes audit-reveal flow.

Backend
-------
* Splunk HEC: POST to ``<url>/services/collector`` with ``Authorization:
  Splunk <token>`` header.
* Elastic / generic webhook: POST the same JSON to the configured URL
  with ``Authorization: Bearer <token>`` (or no auth if token is unset).
* Format chosen by the ``format`` config field: ``"splunk_hec"``
  (default) or ``"json"``.

Resilience
----------
* If the destination is unreachable, the event is appended to a local
  dead-letter file (``<gateway-data>/siem-deadletter.jsonl``) so it can
  be replayed later.
* In-flight requests don't block on SIEM — the on_audit hook fires and
  schedules the POST without awaiting it (best-effort, fire-and-forget).
* If the URL isn't configured, the plugin is a clean no-op.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional

from ..base import GatewayPlugin, PluginKind, ResponseContext

log = logging.getLogger(__name__)

DEFAULT_TIMEOUT_S        = 5.0
DEFAULT_DEADLETTER_PATH  = "siem-deadletter.jsonl"


class SiemForward(GatewayPlugin):
    name = "siem_forward"
    kind = PluginKind.AUDIT
    description = "Forward audit events to Splunk HEC / Elastic / generic webhook"

    def __init__(self) -> None:
        self._url:      Optional[str] = None
        self._token:    Optional[str] = None
        self._format:   str           = "splunk_hec"  # or "json"
        self._timeout:  float         = DEFAULT_TIMEOUT_S
        self._enabled:  bool          = False
        self._dead_letter_path: Path  = Path(DEFAULT_DEADLETTER_PATH)
        self._client                  = None        # lazy httpx.AsyncClient
        self._sent: int               = 0
        self._failed: int             = 0
        self._dead_lettered: int      = 0

    async def setup(self, app_settings: dict[str, Any]) -> None:
        # Config sourced from policies.cache (overlay path) or env vars.
        # Env wins so an operator-managed deployment can keep the URL out
        # of policies.yaml entirely.
        cfg = ((app_settings.get("policies") or {}).get("siem") or {})
        self._enabled  = bool(cfg.get("enabled", True))
        self._url      = (os.environ.get("SIEM_WEBHOOK_URL")
                          or cfg.get("url") or "").strip() or None
        self._token    = (os.environ.get("SIEM_AUTH_TOKEN")
                          or cfg.get("token") or "").strip() or None
        self._format   = (cfg.get("format") or "splunk_hec").strip() or "splunk_hec"
        try:
            self._timeout = float(cfg.get("timeout_seconds", DEFAULT_TIMEOUT_S))
        except (TypeError, ValueError):
            self._timeout = DEFAULT_TIMEOUT_S

        # Dead-letter beside the gateway by default; operator can override.
        dl = (os.environ.get("SIEM_DEADLETTER_PATH")
              or cfg.get("dead_letter_path") or DEFAULT_DEADLETTER_PATH)
        self._dead_letter_path = Path(dl).expanduser().resolve()

        if self._enabled and self._url:
            import httpx
            self._client = httpx.AsyncClient(timeout=self._timeout)
            log.info("siem_forward ready (url=%s, format=%s, timeout=%.1fs)",
                     _redact_url(self._url), self._format, self._timeout)
        else:
            log.info("siem_forward DISABLED (set SIEM_WEBHOOK_URL or "
                     "policies.siem.url + policies.siem.enabled=true)")

    async def teardown(self) -> None:
        if self._client is not None:
            try:
                await self._client.aclose()
            except Exception:                             # noqa: BLE001
                pass

    # ---- Audit hook ---------------------------------------------------
    async def on_audit(self, ctx: ResponseContext) -> None:
        """Best-effort fire-and-forget. Never raises into the request path."""
        if not self._enabled or self._url is None or self._client is None:
            return
        event = self._build_event(ctx)
        # Schedule but DON'T await — SIEM is best-effort, request returns
        # to the user without waiting on the network round-trip.
        asyncio.create_task(self._post_with_fallback(event))

    # ---- State accessor for the observability-status endpoint ---------
    def status(self) -> dict[str, Any]:
        return {
            "enabled":       self._enabled,
            "configured":    self._url is not None,
            "url":           _redact_url(self._url) if self._url else None,
            "format":        self._format,
            "events_sent":   self._sent,
            "events_failed": self._failed,
            "dead_lettered": self._dead_lettered,
            "dead_letter_path": str(self._dead_letter_path) if self._dead_lettered else None,
        }

    # ---- Internals ----------------------------------------------------
    def _build_event(self, ctx: ResponseContext) -> dict[str, Any]:
        # Findings — metadata only, no content.
        findings = [
            {"plugin": f.plugin, "kind": f.kind, "severity": f.severity,
             "redacted": f.redacted}
            for f in (ctx.findings or [])
        ]
        return {
            "request_id":   ctx.request_id,
            "user_id":      ctx.principal.user_id,
            "user_email":   ctx.principal.email,
            "team_id":      ctx.principal.team_id,
            "tier":         ctx.principal.tier,
            "base_tier":    getattr(ctx.principal, "base_tier", None),
            "elevation_id": getattr(ctx.principal, "elevation_id", None),
            "model_requested": ctx.extra.get("model_requested"),
            "model_used":   ctx.model_used,
            "verdict":      _verdict_for(ctx),
            "tokens_in":    ctx.tokens_in,
            "tokens_out":   ctx.tokens_out,
            "latency_ms":   ctx.latency_ms,
            "cost_usd":     ctx.cost_usd,
            "prompt_hash":  None,           # filled by audit_postgres normally
            "response_hash": None,
            "findings":     findings,
            "client_ip":    ctx.extra.get("client_ip"),
            "user_agent":   ctx.extra.get("user_agent"),
        }

    def _envelope(self, event: dict[str, Any]) -> dict[str, Any]:
        if self._format == "splunk_hec":
            return {
                "time":       int(time.time()),
                "host":       os.environ.get("HOSTNAME") or "litellm-gateway",
                "source":     "litellm-gateway",
                "sourcetype": "_json",
                "event":      event,
            }
        # ELK / generic: one JSON doc per event.
        return {"@timestamp": int(time.time()), **event}

    def _headers(self) -> dict[str, str]:
        if self._format == "splunk_hec":
            # Splunk HEC always uses "Splunk <token>".
            if self._token:
                return {"Authorization": f"Splunk {self._token}",
                        "Content-Type":  "application/json"}
            return {"Content-Type": "application/json"}
        # Generic: Bearer if a token is set.
        if self._token:
            return {"Authorization": f"Bearer {self._token}",
                    "Content-Type":  "application/json"}
        return {"Content-Type": "application/json"}

    async def _post_with_fallback(self, event: dict[str, Any]) -> None:
        envelope = self._envelope(event)
        try:
            r = await self._client.post(
                self._url, headers=self._headers(),
                content=json.dumps(envelope, default=str),
            )
            if 200 <= r.status_code < 300:
                self._sent += 1
                return
            log.warning("siem_forward: %s returned %d %s",
                        _redact_url(self._url), r.status_code, r.reason_phrase)
            self._failed += 1
        except Exception as e:                               # noqa: BLE001
            log.warning("siem_forward: POST failed (%s) — dead-lettering", e)
            self._failed += 1
        # Dead-letter — append one JSON line so operators can replay later.
        try:
            self._dead_letter_path.parent.mkdir(parents=True, exist_ok=True)
            with self._dead_letter_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(envelope, default=str) + "\n")
            self._dead_lettered += 1
        except Exception:                                    # noqa: BLE001
            log.exception("siem_forward: dead-letter write failed")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _verdict_for(ctx: ResponseContext) -> str:
    mu = (ctx.model_used or "").lower()
    if mu.startswith("(refused"):
        return "refused"
    if isinstance(ctx.response, dict) and ctx.response.get("error"):
        return "error"
    if any(f.severity == "critical" for f in (ctx.findings or [])):
        return "refused"
    return "allow"


def _redact_url(url: Optional[str]) -> Optional[str]:
    if not url:
        return None
    # Strip credentials in URL form (https://user:pass@host) for log safety.
    import re
    return re.sub(r"://([^:@]+):([^@]+)@", r"://***:***@", url)
