"""Rate limits + daily token budgets, backed by Redis.

What it enforces
----------------
* **RPM** (requests per minute) per team. Configured via ``policies.yaml ->
  tiers[<tier>].rpm``.
* **Daily token budget** per team. Configured via
  ``policies.yaml -> tiers[<tier>].tokens_per_day``.

How it works
------------
Pre-call:
  1. INCR ``quota:rpm:<team>:<epoch_minute>`` — refuse 429 if > limit.
  2. INCRBY ``quota:daily:<team>:<yyyy-mm-dd>`` by an *estimated* token
     count from the prompt (chars / 4 heuristic). Refuse 402 if > limit,
     and roll the counter back so it stays accurate.
  3. Stash the estimate on ``ctx.extra["quota_estimated_tokens"]``.

Post-call (reconcile):
  4. Apply the delta between estimated and ACTUAL tokens (in+out from the
     response usage block) to the daily counter, so accounting matches
     what the model actually consumed.

Resilience
----------
If the configured Redis URL is unreachable (or set to ``memory://``), the
plugin transparently uses an in-process counter store. This keeps local dev
and tests hermetic but is **not** safe for multi-replica production — a
loud WARN is logged at startup so it's impossible to deploy that way by
accident.
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Optional

from ..base import (
    Finding,
    GatewayPlugin,
    HookResult,
    PluginKind,
    PluginVerdict,
    RequestContext,
    ResponseContext,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Counter back-ends
# ---------------------------------------------------------------------------
class _Counters:
    """Common interface so the plugin doesn't care which backend it uses."""

    async def incr(self, key: str, ttl_seconds: int) -> int: ...
    async def incrby(self, key: str, amount: int, ttl_seconds: int) -> int: ...
    async def decrby(self, key: str, amount: int) -> int: ...
    async def get(self, key: str) -> int: ...
    async def reset(self, key_prefix: str) -> int: ...
    async def aclose(self) -> None: ...


class _InMemoryCounters(_Counters):
    """Process-local counters. Safe for tests / single-replica dev only."""

    def __init__(self) -> None:
        self._values: dict[str, int] = defaultdict(int)
        self._expiry: dict[str, float] = {}
        self._lock = asyncio.Lock()

    def _now(self) -> float:
        return time.time()

    def _expire_due(self) -> None:
        now = self._now()
        for key in list(self._expiry.keys()):
            if self._expiry[key] <= now:
                self._values.pop(key, None)
                self._expiry.pop(key, None)

    async def incr(self, key: str, ttl_seconds: int) -> int:
        async with self._lock:
            self._expire_due()
            self._values[key] += 1
            self._expiry[key] = self._now() + ttl_seconds
            return self._values[key]

    async def incrby(self, key: str, amount: int, ttl_seconds: int) -> int:
        async with self._lock:
            self._expire_due()
            self._values[key] += amount
            self._expiry[key] = self._now() + ttl_seconds
            return self._values[key]

    async def decrby(self, key: str, amount: int) -> int:
        async with self._lock:
            self._values[key] = max(0, self._values[key] - amount)
            return self._values[key]

    async def get(self, key: str) -> int:
        async with self._lock:
            self._expire_due()
            return self._values.get(key, 0)

    async def reset(self, key_prefix: str) -> int:
        async with self._lock:
            to_delete = [k for k in self._values if k.startswith(key_prefix)]
            for k in to_delete:
                self._values.pop(k, None)
                self._expiry.pop(k, None)
            return len(to_delete)

    async def aclose(self) -> None:
        pass


class _RedisCounters(_Counters):
    """Async Redis-backed counters."""

    def __init__(self, client) -> None:
        self._r = client

    async def incr(self, key: str, ttl_seconds: int) -> int:
        pipe = self._r.pipeline()
        pipe.incr(key)
        pipe.expire(key, ttl_seconds)
        new_val, _ = await pipe.execute()
        return int(new_val)

    async def incrby(self, key: str, amount: int, ttl_seconds: int) -> int:
        pipe = self._r.pipeline()
        pipe.incrby(key, amount)
        pipe.expire(key, ttl_seconds)
        new_val, _ = await pipe.execute()
        return int(new_val)

    async def decrby(self, key: str, amount: int) -> int:
        new_val = await self._r.decrby(key, amount)
        return int(new_val)

    async def get(self, key: str) -> int:
        v = await self._r.get(key)
        return int(v) if v is not None else 0

    async def reset(self, key_prefix: str) -> int:
        cursor = 0
        deleted = 0
        while True:
            cursor, keys = await self._r.scan(cursor=cursor, match=key_prefix + "*", count=500)
            if keys:
                deleted += await self._r.delete(*keys)
            if cursor == 0:
                break
        return deleted

    async def aclose(self) -> None:
        try:
            await self._r.aclose()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# Plugin
# ---------------------------------------------------------------------------
def _epoch_minute() -> int:
    return int(time.time() // 60)


def _today_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _estimate_tokens(messages: list[dict]) -> int:
    """Rough 4-chars-per-token heuristic. Reconciled post-call."""
    total = 0
    for m in messages:
        c = m.get("content")
        if isinstance(c, str):
            total += len(c)
        elif isinstance(c, list):
            for part in c:
                if isinstance(part, dict):
                    t = part.get("text") or ""
                    if isinstance(t, str):
                        total += len(t)
    return max(1, math.ceil(total / 4))


class RedisQuota(GatewayPlugin):
    name = "quota_redis"
    kind = PluginKind.AUTHZ
    description = "RPM + daily-token-budget enforcement, Redis-backed (memory fallback)"

    def __init__(self) -> None:
        self._counters: Optional[_Counters] = None
        self._tiers: dict[str, dict[str, Any]] = {}
        self._using_memory = False

    async def setup(self, app_settings: dict[str, Any]) -> None:
        self._tiers = (app_settings.get("policies") or {}).get("tiers") or {}
        url: str = app_settings.get("redis_url") or "memory://"

        if url.startswith("memory://"):
            self._counters = _InMemoryCounters()
            self._using_memory = True
        else:
            try:
                from redis.asyncio import Redis
                client = Redis.from_url(url, decode_responses=True)
                # Sanity check — fail fast if Redis is unreachable.
                await client.ping()
                self._counters = _RedisCounters(client)
            except Exception as e:  # noqa: BLE001
                log.warning(
                    "quota_redis: Redis at %s unreachable (%s); FALLING BACK to "
                    "in-memory counters — NOT SAFE for multi-replica deploys",
                    url, e,
                )
                self._counters = _InMemoryCounters()
                self._using_memory = True

        if self._using_memory:
            log.warning("quota_redis: using in-process counters (dev / test mode)")
        else:
            log.info("quota_redis: connected to Redis at %s", _redact_url(url))

    async def teardown(self) -> None:
        if self._counters is not None:
            await self._counters.aclose()

    # ----- Pre-call: rate limit + budget pre-check -------------------------
    async def on_pre_call(self, ctx: RequestContext) -> HookResult:
        if self._counters is None:
            return HookResult(verdict=PluginVerdict.ALLOW)

        # Counters key off team_id, so the *team's* configured tier must drive
        # the limit lookup — not principal.tier, which may be temporarily
        # elevated via JIT. If we used the elevated tier we'd raise the cap
        # for everyone else on the team for the duration of the elevation.
        quota_tier = ctx.principal.base_tier or ctx.principal.tier
        tier_cfg = self._tiers.get(quota_tier)
        if tier_cfg is None:
            return HookResult(verdict=PluginVerdict.ALLOW)   # authz_tiered already refused

        team   = ctx.principal.team_id
        minute = _epoch_minute()
        today  = _today_utc()

        # --- RPM ---------------------------------------------------------
        rpm_limit = tier_cfg.get("rpm")
        if isinstance(rpm_limit, int) and rpm_limit > 0:
            rpm_key = f"quota:rpm:{team}:{minute}"
            current = await self._counters.incr(rpm_key, ttl_seconds=120)
            if current > rpm_limit:
                # Roll back our own increment so the next call's counter is honest.
                await self._counters.decrby(rpm_key, 1)
                return HookResult(
                    verdict=PluginVerdict.REFUSE,
                    status_code=429,
                    error_code="rate_limited",
                    reason=f"Rate limit exceeded: {rpm_limit} req/min for tier {quota_tier}",
                    findings=[Finding(plugin=self.name, kind="quota.rpm",
                                      severity="warn",
                                      message=f"{current - 1}/{rpm_limit} req/min")],
                    extra_headers={
                        "X-RateLimit-Limit":     str(rpm_limit),
                        "X-RateLimit-Remaining": "0",
                        "X-RateLimit-Reset":     str((minute + 1) * 60),
                    },
                )

        # --- Daily token budget ------------------------------------------
        daily_limit = tier_cfg.get("tokens_per_day")
        if isinstance(daily_limit, int) and daily_limit > 0:
            estimated = _estimate_tokens(ctx.messages)
            daily_key = f"quota:daily:{team}:{today}"
            current   = await self._counters.incrby(daily_key, estimated, ttl_seconds=129600)  # 36 h
            if current > daily_limit:
                # Roll back the pre-add so accounting stays correct.
                await self._counters.decrby(daily_key, estimated)
                return HookResult(
                    verdict=PluginVerdict.REFUSE,
                    status_code=402,
                    error_code="budget_exceeded",
                    reason=(f"Daily token budget exceeded: {daily_limit} tokens/day "
                            f"for team {team!r}"),
                    findings=[Finding(plugin=self.name, kind="quota.daily_tokens",
                                      severity="high",
                                      message=f"{current - estimated}/{daily_limit} tokens today")],
                    extra_headers={
                        "X-Daily-Budget":      str(daily_limit),
                        "X-Daily-Budget-Used": str(current - estimated),
                    },
                )
            ctx.extra["quota_estimated_tokens"] = estimated

        # Allowed — stash the rate-limit headers on ctx so main.py can echo
        # them on the chat-completion response. Clients (Cline / aider) that
        # see `X-RateLimit-Remaining: 1` voluntarily back off; without these
        # they only learn about the limit when they're already over it.
        if isinstance(rpm_limit, int) and rpm_limit > 0:
            rpm_used_now = await self._counters.get(f"quota:rpm:{team}:{minute}")
            ctx.extra.setdefault("response_headers", {}).update({
                "X-RateLimit-Limit":     str(rpm_limit),
                "X-RateLimit-Remaining": str(max(0, rpm_limit - int(rpm_used_now))),
                "X-RateLimit-Reset":     str((minute + 1) * 60),
            })
        if isinstance(daily_limit, int) and daily_limit > 0:
            daily_used_now = await self._counters.get(f"quota:daily:{team}:{today}")
            ctx.extra.setdefault("response_headers", {}).update({
                "X-Daily-Budget":      str(daily_limit),
                "X-Daily-Budget-Used": str(int(daily_used_now)),
            })

        return HookResult(verdict=PluginVerdict.ALLOW)

    # ----- Post-call: reconcile estimated vs actual tokens -----------------
    async def on_post_call(self, ctx: ResponseContext) -> HookResult:
        if self._counters is None:
            return HookResult(verdict=PluginVerdict.ALLOW)

        estimated = int(ctx.extra.get("quota_estimated_tokens") or 0)
        if not estimated:
            return HookResult(verdict=PluginVerdict.ALLOW)

        actual = (ctx.tokens_in or 0) + (ctx.tokens_out or 0)
        delta = actual - estimated
        if delta == 0:
            return HookResult(verdict=PluginVerdict.ALLOW)

        team  = ctx.principal.team_id
        today = _today_utc()
        key = f"quota:daily:{team}:{today}"
        if delta > 0:
            await self._counters.incrby(key, delta, ttl_seconds=129600)
        else:
            await self._counters.decrby(key, abs(delta))
        return HookResult(verdict=PluginVerdict.ALLOW)

    # ----- Admin helpers -----------------------------------------------------
    async def usage_for_team(self, team_id: str) -> dict[str, Any]:
        """Counters for one team. Called by the /admin/quotas endpoint."""
        if self._counters is None:
            return {"rpm": 0, "tokens_today": 0}
        today  = _today_utc()
        minute = _epoch_minute()
        rpm   = await self._counters.get(f"quota:rpm:{team_id}:{minute}")
        daily = await self._counters.get(f"quota:daily:{team_id}:{today}")
        return {"rpm": rpm, "tokens_today": daily}

    async def usage_snapshot(self) -> dict[str, Any]:
        """Snapshot metadata; per-team counters fetched separately."""
        return {"today": _today_utc(), "minute": _epoch_minute(), "teams": {}}

    async def reset_team(self, team_id: str) -> int:
        if self._counters is None:
            return 0
        a = await self._counters.reset(f"quota:rpm:{team_id}:")
        b = await self._counters.reset(f"quota:daily:{team_id}:")
        return a + b


def _redact_url(url: str) -> str:
    import re
    return re.sub(r":([^:@/]+)@", r":***@", url)
