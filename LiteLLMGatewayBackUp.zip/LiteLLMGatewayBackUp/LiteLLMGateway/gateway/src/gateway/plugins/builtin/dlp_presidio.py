"""Presidio-backed DLP pre-call plugin.

Detects PII / secrets / regulated identifiers in incoming prompts using
Microsoft Presidio's analyzer + anonymizer. Configurable via
``policies.yaml`` -> ``dlp`` section, e.g.::

    dlp:
      detectors: [PERSON, EMAIL_ADDRESS, CREDIT_CARD, US_SSN, ...]
      action:    redact          # redact | refuse | warn
      custom_recognizers:
        - name:        CUSTOMER_ID
          pattern:     "OATI-\\d{6}"
          score:       0.8
        - name:        REGULATED_REPO_PATH
          pattern:     "/regulated/[a-z0-9_/-]+"
          score:       0.7

If Presidio isn't installed (the optional ``[dlp]`` extra), the plugin still
loads but is a no-op and warns at startup.
"""

from __future__ import annotations

import logging
from typing import Any

from ..base import (
    Finding,
    GatewayPlugin,
    HookResult,
    PluginKind,
    PluginVerdict,
    RequestContext,
)

log = logging.getLogger(__name__)

try:
    from presidio_analyzer import AnalyzerEngine, PatternRecognizer
    from presidio_analyzer.nlp_engine import NlpEngineProvider
    from presidio_anonymizer import AnonymizerEngine
    from presidio_anonymizer.entities import OperatorConfig

    _PRESIDIO_OK = True
except ImportError as e:
    log.warning("Presidio not available — dlp_presidio will no-op (%s)", e)
    _PRESIDIO_OK = False


DEFAULT_DETECTORS = [
    "PERSON",
    "EMAIL_ADDRESS",
    "PHONE_NUMBER",
    "CREDIT_CARD",
    "IBAN_CODE",
    "US_SSN",
    "IP_ADDRESS",
    "CRYPTO",
]


class PresidioDLP(GatewayPlugin):
    name = "dlp_presidio"
    kind = PluginKind.DLP
    description = "Presidio-based PII / secret / regulated-id detection on prompts"

    def __init__(self) -> None:
        self.enabled = _PRESIDIO_OK
        self.analyzer: Any = None
        self.anonymizer: Any = None
        self.detectors: list[str] = DEFAULT_DETECTORS
        self.action: str = "redact"   # redact | refuse | warn

    async def setup(self, app_settings: dict[str, Any]) -> None:
        if not self.enabled:
            return

        policies = app_settings.get("policies") or {}
        dlp_cfg = policies.get("dlp") or {}
        self.detectors = dlp_cfg.get("detectors", DEFAULT_DETECTORS)
        self.action = dlp_cfg.get("action", "redact")

        # Build the analyzer.
        provider = NlpEngineProvider(
            nlp_configuration={
                "nlp_engine_name": "spacy",
                "models": [{"lang_code": "en", "model_name": "en_core_web_sm"}],
            }
        )
        nlp_engine = provider.create_engine()
        self.analyzer = AnalyzerEngine(nlp_engine=nlp_engine, supported_languages=["en"])
        self.anonymizer = AnonymizerEngine()

        # Custom regex recognisers (e.g. customer-id, regulated paths).
        for rec_cfg in dlp_cfg.get("custom_recognizers", []) or []:
            try:
                rec = PatternRecognizer(
                    supported_entity=rec_cfg["name"],
                    patterns=[{"name": rec_cfg["name"], "regex": rec_cfg["pattern"],
                               "score": rec_cfg.get("score", 0.7)}],
                )
                self.analyzer.registry.add_recognizer(rec)
                self.detectors.append(rec_cfg["name"])
            except Exception as e:  # noqa: BLE001
                log.exception("Failed to add custom recognizer %s: %s",
                              rec_cfg.get("name"), e)

        log.info("dlp_presidio ready (action=%s, detectors=%s)", self.action, self.detectors)

    async def on_pre_call(self, ctx: RequestContext) -> HookResult:
        if not self.enabled:
            return HookResult(verdict=PluginVerdict.ALLOW)

        findings: list[Finding] = []
        any_high = False

        for i, msg in enumerate(ctx.messages):
            content = msg.get("content")
            if not isinstance(content, str) or not content:
                continue

            results = self.analyzer.analyze(text=content, language="en", entities=self.detectors)
            if not results:
                continue

            for r in results:
                kind = f"pii.{r.entity_type.lower()}"
                severity = "high" if r.score >= 0.85 else "warn"
                findings.append(Finding(
                    plugin=self.name,
                    kind=kind,
                    severity=severity,
                    message=f"{r.entity_type} matched (score={r.score:.2f}) in messages[{i}]",
                    location=f"messages[{i}].content[{r.start}:{r.end}]",
                ))
                if severity == "high":
                    any_high = True

            if self.action == "redact" and results:
                # Anonymise in place; downstream router + LiteLLM see the redacted text.
                redacted = self.anonymizer.anonymize(
                    text=content,
                    analyzer_results=results,
                    operators={
                        "DEFAULT": OperatorConfig("replace", {"new_value": "<REDACTED>"}),
                    },
                ).text
                msg["content"] = redacted
                for f in findings[-len(results):]:
                    f.redacted = True

        if not findings:
            return HookResult(verdict=PluginVerdict.ALLOW)

        if self.action == "refuse" and any_high:
            return HookResult(
                verdict=PluginVerdict.REFUSE,
                findings=findings,
                reason="DLP: high-severity sensitive content detected in prompt",
            )

        return HookResult(verdict=PluginVerdict.ALLOW_MUTATE, findings=findings)
