"""Semantic response cache for chat-completion requests.

What it does
------------
Extends :mod:`cache_redis` from exact-hash matching to **embedding
similarity** matching. A request gets embedded, its vector is compared
against every prior cached entry for the same team, and if the maximum
cosine similarity crosses the configured threshold the cached response is
returned. This catches paraphrases ("hi world" vs "hello world") that
the exact-hash cache misses on. It is the single biggest feature gap
between this gateway and Portkey / Helicone / Cloudflare AI Gateway, so
it's a first-class plugin rather than a knob inside cache_redis.

Where it slots in
-----------------
Same pattern as ``cache_redis``: the plugin is loaded as
:class:`PluginKind.AUDIT` so the standard lifecycle wires it up at
startup, but no per-request hook fires. ``main.chat_completions`` calls
``is_cacheable()`` + ``lookup()`` / ``store()`` directly, AFTER the
``cache_redis`` lookup — so an exact hit always beats a semantic hit
(and saves an embedding round-trip).

Storage
-------
**Dev path:** in-process dict keyed by ``team_id`` with an LRU bound
(``max_entries_per_team``). Each entry is ``(embedding, response_dict)``.
This is intentionally simple — there is NO durable, multi-replica
backend in the box. Operators who want production-grade semantic cache
should swap ``_VectorStore`` for a pgvector / Redis HNSW / Qdrant
implementation; the swap-out points are marked with ``# TODO(prod):``.

Embeddings
----------
Calls :func:`llmgateway.aembedding` with the configured ``embedding_model``
(default ``openai/text-embedding-3-small``). Any failure on the embedding
call **degrades gracefully** — we log and return ``None`` from
``lookup()`` / silently skip ``store()`` — so a transient outage in the
embedding provider can never crash a chat request.

Similarity
----------
Plain cosine similarity. Vectors are normalised at store time so
``lookup`` is a single dot-product per cached entry. Linear scan is fine
up to the per-team cap (default 1000) — a vector store would only earn
its keep above ~10⁴–10⁵ entries.

Cold-start safety
-----------------
Default ``enabled=False`` in the plugin_configs schema so a first-boot
gateway with no operator-supplied embedding credentials cannot wedge on
a real-API call. Operators flip it on after pointing ``embedding_model``
at a reachable provider (OpenAI for managed, Ollama for local).
"""

from __future__ import annotations

import asyncio
import logging
import math
from collections import OrderedDict
from typing import Any, Optional

from ..base import GatewayPlugin, PluginKind

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Per-team in-process vector store.
# TODO(prod): swap for a pgvector / Redis HNSW / Qdrant backend behind the
# same get / put / iter interface. Cosine similarity stays the same; only
# the storage + nearest-neighbour-scan implementation changes.
# ---------------------------------------------------------------------------
class _VectorStore:
    """LRU-bounded dict of {team_id: OrderedDict[key -> (vec, response)]}.

    Each per-team OrderedDict is touched on every read so LRU eviction
    pops the coldest entries first. Vectors are stored already L2-normalised
    so similarity is a single dot product.
    """

    def __init__(self, max_entries_per_team: int = 1000) -> None:
        self._max = max(10, int(max_entries_per_team))
        self._teams: dict[str, "OrderedDict[str, tuple[list[float], dict[str, Any]]]"] = {}
        self._lock = asyncio.Lock()

    async def all_for_team(self, team_id: str) -> list[tuple[list[float], dict[str, Any]]]:
        """Snapshot of every (vec, response) pair stored for a team. Empty
        when the team has no entries yet."""
        async with self._lock:
            bucket = self._teams.get(team_id)
            if not bucket:
                return []
            return list(bucket.values())

    async def put(self, team_id: str, key: str,
                  vec: list[float], response: dict[str, Any]) -> None:
        async with self._lock:
            bucket = self._teams.setdefault(team_id, OrderedDict())
            if key in bucket:
                bucket.move_to_end(key)
            bucket[key] = (vec, response)
            # LRU eviction — drop the oldest until under the cap.
            while len(bucket) > self._max:
                bucket.popitem(last=False)

    async def touch(self, team_id: str, key: str) -> None:
        """Mark a hit as most-recently-used. Called on every cache HIT so
        the hot set survives eviction longer than the long tail."""
        async with self._lock:
            bucket = self._teams.get(team_id)
            if bucket is not None and key in bucket:
                bucket.move_to_end(key)

    async def clear(self) -> None:
        async with self._lock:
            self._teams.clear()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _flatten_messages(messages: list[dict[str, Any]]) -> str:
    """Reduce a chat-completion ``messages`` list to a single string that's
    representative for embedding. Roles are included so a question and its
    answer aren't conflated."""
    parts: list[str] = []
    for m in messages or []:
        role = str(m.get("role", "")).strip() or "user"
        content = m.get("content")
        if isinstance(content, list):
            # multi-part content — concatenate text parts only.
            text = " ".join(
                str(p.get("text", "")) for p in content
                if isinstance(p, dict) and p.get("type") in (None, "text")
            )
        else:
            text = str(content or "")
        if text:
            parts.append(f"{role}: {text}")
    return "\n".join(parts)


def _normalise(vec: list[float]) -> list[float]:
    """L2-normalise so cosine similarity reduces to a dot product."""
    n = math.sqrt(sum(x * x for x in vec))
    if n <= 0.0:
        return list(vec)
    return [x / n for x in vec]


def _cosine_dot(a: list[float], b: list[float]) -> float:
    """Cosine similarity of two L2-normalised vectors == their dot product.

    Defensive: if vectors disagree on length (different embedding model
    between store and lookup) we treat that as zero similarity rather than
    crash — operators who switch embedding models should clear the cache,
    but we won't blow up the request if they didn't.
    """
    if not a or not b or len(a) != len(b):
        return 0.0
    return sum(x * y for x, y in zip(a, b))


def _has_tool_calls(messages: list[dict[str, Any]]) -> bool:
    for m in messages or []:
        if m.get("tool_calls"):
            return True
        if m.get("role") == "tool":
            return True
    return False


def _is_cacheable_temperature(temperature: Optional[float],
                              threshold: float = 0.0) -> bool:
    if temperature is None:
        return True
    try:
        return float(temperature) <= threshold
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# Plugin
# ---------------------------------------------------------------------------
class SemanticCache(GatewayPlugin):
    name = "cache_semantic"
    kind = PluginKind.AUDIT
    description = ("Semantic response cache: hit on paraphrased prompts via "
                   "embedding cosine similarity above a threshold.")

    DEFAULT_THRESHOLD = 0.95
    DEFAULT_EMBEDDING_MODEL = "openai/text-embedding-3-small"
    DEFAULT_MAX_ENTRIES = 1000

    def __init__(self) -> None:
        self._enabled: bool = False  # cold-start safe: opt-in
        self._threshold: float = self.DEFAULT_THRESHOLD
        self._embedding_model: str = self.DEFAULT_EMBEDDING_MODEL
        self._max_entries: int = self.DEFAULT_MAX_ENTRIES
        self._skip_above_temperature: float = 0.0
        self._store: Optional[_VectorStore] = None

    # --- Lifecycle ---------------------------------------------------------
    async def setup(self, app_settings: dict[str, Any]) -> None:
        sem_cfg = (((app_settings.get("policies") or {})
                    .get("cache_semantic")) or {})
        # Default to enabled=False here as well — only flip on once an
        # operator has configured an embedding model they can reach.
        self._enabled = bool(sem_cfg.get("enabled", False))
        try:
            self._threshold = float(sem_cfg.get("similarity_threshold",
                                                self.DEFAULT_THRESHOLD))
        except (TypeError, ValueError):
            self._threshold = self.DEFAULT_THRESHOLD
        self._embedding_model = str(sem_cfg.get("embedding_model",
                                                self.DEFAULT_EMBEDDING_MODEL))
        try:
            self._max_entries = int(sem_cfg.get("max_entries_per_team",
                                                self.DEFAULT_MAX_ENTRIES))
        except (TypeError, ValueError):
            self._max_entries = self.DEFAULT_MAX_ENTRIES
        # Reuse the cache_redis "skip_above_temperature" knob so the two
        # caches gate identically on determinism — no surprise mismatches.
        cache_cfg = ((app_settings.get("policies") or {}).get("cache") or {})
        try:
            self._skip_above_temperature = float(cache_cfg.get(
                "skip_above_temperature", 0.0,
            ))
        except (TypeError, ValueError):
            self._skip_above_temperature = 0.0

        self._store = _VectorStore(max_entries_per_team=self._max_entries)
        log.info(
            "cache_semantic: enabled=%s threshold=%.3f model=%s max=%d",
            self._enabled, self._threshold, self._embedding_model,
            self._max_entries,
        )

    async def teardown(self) -> None:
        if self._store is not None:
            await self._store.clear()

    # --- Public API used by main.chat_completions --------------------------
    def is_enabled(self) -> bool:
        return bool(self._enabled and self._store is not None)

    def is_cacheable(self,
                     messages: list[dict[str, Any]],
                     temperature: Optional[float],
                     tools: Optional[list[dict[str, Any]]] = None) -> bool:
        if not self.is_enabled():
            return False
        if not _is_cacheable_temperature(temperature,
                                         self._skip_above_temperature):
            return False
        if tools:
            return False
        if _has_tool_calls(messages):
            return False
        return True

    async def lookup(self,
                     messages: list[dict[str, Any]],
                     model_requested: Optional[str],
                     principal,
                     max_tokens: Optional[int],
                     temperature: Optional[float],
                     tools: Optional[list[dict[str, Any]]] = None,
                     ) -> Optional[dict[str, Any]]:
        """Return the most-similar cached response, or ``None`` on miss.

        Embedding failures are NOT propagated — they degrade to a miss so
        the chat request continues to inference.
        """
        if not self.is_cacheable(messages, temperature, tools):
            return None
        assert self._store is not None

        text = _flatten_messages(messages)
        if not text:
            return None

        try:
            vec = await self._embed(text)
        except Exception as e:  # noqa: BLE001
            log.warning("cache_semantic: embed failed on lookup (%s); MISS", e)
            self._inc_metric("miss", model_requested, principal.team_id)
            return None
        if vec is None:
            self._inc_metric("miss", model_requested, principal.team_id)
            return None

        team_entries = await self._store.all_for_team(principal.team_id)
        if not team_entries:
            self._inc_metric("miss", model_requested, principal.team_id)
            return None

        # Find the single most-similar entry. We don't return ALL matches
        # above threshold — semantic cache picks one answer per call.
        best_sim = -1.0
        best_resp: Optional[dict[str, Any]] = None
        best_key: Optional[str] = None
        # Rebuild per-team key list so we can touch() the LRU position.
        # all_for_team returned values; recover keys via the same lock-free
        # path below by enumerating once more under a fresh lock.
        # (Cheap — same bucket, capped at _max_entries.)
        bucket = self._store._teams.get(principal.team_id)  # noqa: SLF001
        items = list(bucket.items()) if bucket else []
        for key, (cached_vec, resp) in items:
            sim = _cosine_dot(vec, cached_vec)
            if sim > best_sim:
                best_sim = sim
                best_resp = resp
                best_key = key

        if best_resp is None or best_sim < self._threshold:
            self._inc_metric("miss", model_requested, principal.team_id)
            return None

        if best_key is not None:
            await self._store.touch(principal.team_id, best_key)
        self._inc_metric("hit", model_requested, principal.team_id)
        return best_resp

    async def store(self,
                    messages: list[dict[str, Any]],
                    model_requested: Optional[str],
                    principal,
                    max_tokens: Optional[int],
                    temperature: Optional[float],
                    response: dict[str, Any],
                    ttl_seconds: Optional[int] = None,
                    tools: Optional[list[dict[str, Any]]] = None,
                    ) -> None:
        """Embed the request and persist the response under the team's
        bucket. No-op on any error — never break the chat request."""
        if not self.is_cacheable(messages, temperature, tools):
            return
        assert self._store is not None

        text = _flatten_messages(messages)
        if not text:
            return

        try:
            vec = await self._embed(text)
        except Exception as e:  # noqa: BLE001
            log.warning("cache_semantic: embed failed on store (%s); skip", e)
            return
        if vec is None:
            return

        # Key the entry by content + sampling params so two different
        # requests with the same text but e.g. different max_tokens get
        # separate cache lines (the response shape differs).
        key = f"{model_requested or '?'}|{max_tokens or 0}|{temperature or 0.0}|{text}"
        try:
            await self._store.put(principal.team_id, key, vec, response)
        except Exception as e:  # noqa: BLE001
            log.warning("cache_semantic: store put failed (%s)", e)

    # --- Embedding helper --------------------------------------------------
    async def _embed(self, text: str) -> Optional[list[float]]:
        """Call llmgateway.aembedding and return the normalised vector.

        Returns ``None`` (not an exception) when the embedding response
        comes back in an unexpected shape, so callers don't need to
        special-case malformed providers.
        """
        # Late import so tests can monkey-patch ``llmgateway.aembedding``
        # AFTER setup() has run.
        import llmgateway

        try:
            resp = await llmgateway.aembedding(
                model=self._embedding_model,
                input=text,
            )
        except Exception:
            raise

        # Accept both the pydantic-typed EmbeddingResponse and a plain dict
        # (in case a fake / monkey-patched function returns one).
        data = None
        if hasattr(resp, "data"):
            data = resp.data
        elif isinstance(resp, dict):
            data = resp.get("data")
        if not data:
            return None
        first = data[0]
        if hasattr(first, "embedding"):
            vec = first.embedding
        elif isinstance(first, dict):
            vec = first.get("embedding")
        else:
            return None
        if not isinstance(vec, list) or not vec:
            return None
        try:
            vec_f = [float(x) for x in vec]
        except (TypeError, ValueError):
            return None
        return _normalise(vec_f)

    # --- Metrics (lazy import to dodge circular dependency on main) --------
    def _inc_metric(self, kind: str, model: Optional[str], team: str) -> None:
        try:
            from ...main import SEMANTIC_CACHE_HITS, SEMANTIC_CACHE_MISSES
        except Exception:  # noqa: BLE001
            return
        counter = SEMANTIC_CACHE_HITS if kind == "hit" else SEMANTIC_CACHE_MISSES
        try:
            counter.labels(model or "?", team).inc()
        except Exception:  # noqa: BLE001
            pass
