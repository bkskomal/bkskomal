"""Built-in plugins shipped with the gateway."""
