"""Response cache for chat-completion requests.

What it does
------------
Hashes the canonicalised prompt + sampling params and stores the matching
non-streaming chat-completion response keyed by that hash. On the next
identical request it returns the stored payload, skipping inference
entirely. The result: identical prompts cost zero dollars and return in
sub-millisecond time after the first call.

Where it slots in
-----------------
The plugin chain has no native "respond from cache" verdict — ``HookResult``
can ``REFUSE`` a request but cannot complete one. Rather than abuse REFUSE
to short-circuit with a synthetic 200 (which would lie to every counter and
audit row), the cache is invoked **explicitly** from
``main.chat_completions`` between ``run_pre_call`` and ``router.acompletion``.
The plugin still registers as :class:`PluginKind.AUDIT` so the standard
``setup()`` / ``teardown()`` lifecycle wires the Redis client (or its
in-memory fallback) up exactly once at startup. AUDIT is the right slot
because (a) we don't actually want any per-request hook to fire for this
plugin, and (b) AUDIT plugins are loaded last so a stale failure won't
poison the rest of the chain.

Resilience
----------
If the configured Redis URL is unreachable (or set to ``memory://``), the
plugin transparently falls back to a process-local dict. Tests run against
the in-memory store; production should point at Redis so cache state is
shared across replicas.

What is NOT cached
------------------
* Requests with ``temperature`` set to anything > 0 (non-deterministic).
* Requests carrying ``tools`` — replaying a stale tool-call response would
  break stateful flows where the tool has side effects.

Streaming
---------
Streaming requests ARE cached, but in a SEPARATE key namespace
(``cache:stream:<sha>``) from non-streaming responses
(``cache:resp:<sha>``). A non-streaming cache HIT must never be served to
a streaming client (and vice versa) because the on-wire shape differs:
streaming is a list of ``chat.completion.chunk`` dicts replayed as SSE,
non-streaming is a single ``chat.completion`` JSON document. The
``lookup_stream()`` / ``store_stream()`` methods handle this; the
non-streaming ``lookup()`` / ``store()`` paths remain untouched.

Cache key shape
---------------
SHA-256 of canonical JSON of::

    {
        "messages":    <messages>,
        "model":       <model_requested>,
        "max_tokens":  <max_tokens or null>,
        "temperature": <temperature or null>,
        "team_id":     <principal.team_id>,
    }

``team_id`` is included so per-team policy edits (banned topics, redaction
rules, output scrubbing) don't leak across teams via shared cache lines.
The streaming variant prepends ``cache:stream:`` instead of ``cache:resp:``
so the two caches cannot clobber each other.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from typing import Any, Optional

from ..base import GatewayPlugin, PluginKind

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Storage back-ends
# ---------------------------------------------------------------------------
class _Store:
    """Common interface so the plugin doesn't care which backend it uses."""

    async def get(self, key: str) -> Optional[str]: ...
    async def set(self, key: str, value: str, ttl_seconds: int) -> None: ...
    async def aclose(self) -> None: ...


class _InMemoryStore(_Store):
    """Process-local cache. Safe for tests / single-replica dev only."""

    def __init__(self) -> None:
        self._values: dict[str, str] = {}
        self._expiry: dict[str, float] = {}
        self._lock = asyncio.Lock()

    def _now(self) -> float:
        return time.time()

    def _expire_due(self) -> None:
        now = self._now()
        for key in list(self._expiry.keys()):
            if self._expiry[key] <= now:
                self._values.pop(key, None)
                self._expiry.pop(key, None)

    async def get(self, key: str) -> Optional[str]:
        async with self._lock:
            self._expire_due()
            return self._values.get(key)

    async def set(self, key: str, value: str, ttl_seconds: int) -> None:
        async with self._lock:
            self._values[key] = value
            self._expiry[key] = self._now() + ttl_seconds

    async def aclose(self) -> None:
        pass


class _RedisStore(_Store):
    """Async Redis-backed cache."""

    def __init__(self, client) -> None:
        self._r = client

    async def get(self, key: str) -> Optional[str]:
        v = await self._r.get(key)
        if v is None:
            return None
        # decode_responses=True in setup() means redis returns str already.
        return v if isinstance(v, str) else v.decode("utf-8", errors="replace")

    async def set(self, key: str, value: str, ttl_seconds: int) -> None:
        await self._r.set(key, value, ex=ttl_seconds)

    async def aclose(self) -> None:
        try:
            await self._r.aclose()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _canonical_key(messages: list[dict[str, Any]],
                   model: Optional[str],
                   max_tokens: Optional[int],
                   temperature: Optional[float],
                   team_id: str,
                   prefix: str = "cache:resp:") -> str:
    """SHA-256 of canonical JSON of the cacheable subset of the request.

    ``prefix`` is ``cache:resp:`` for non-streaming responses and
    ``cache:stream:`` for streamed chunk arrays — the two namespaces are
    deliberately disjoint so a streaming caller never picks up a
    non-streaming payload (different shape) and vice versa.
    """
    payload = {
        "messages":    messages or [],
        "model":       model,
        "max_tokens":  max_tokens,
        "temperature": temperature,
        "team_id":     team_id,
    }
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=str)
    h = hashlib.sha256(blob.encode("utf-8")).hexdigest()
    return f"{prefix}{h}"


def _has_tool_calls(messages: list[dict[str, Any]]) -> bool:
    """True if any message carries tool calls / tool results.

    Replaying a cached tool-call response would skip the actual tool
    invocation the model expected — break stateful tool flows.
    """
    for m in messages or []:
        if m.get("tool_calls"):
            return True
        if m.get("role") == "tool":
            return True
    return False


def _is_cacheable_temperature(temperature: Optional[float],
                              threshold: float = 0.0) -> bool:
    """Cacheable when temperature is unset OR <= the configured threshold.

    threshold=0 means "only cache for fully deterministic samples". An
    operator who wants to tolerate slight randomness can raise it via the
    cache_redis plugin config (UI)."""
    if temperature is None:
        return True
    try:
        return float(temperature) <= threshold
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# Plugin
# ---------------------------------------------------------------------------
class RedisResponseCache(GatewayPlugin):
    name = "cache_redis"
    kind = PluginKind.AUDIT
    description = "Response cache keyed by prompt hash, Redis-backed (memory fallback)"

    # Default TTL: 10 minutes. Override via policies.cache.ttl_seconds.
    DEFAULT_TTL = 600

    # Hard upper bound on number of chunks we will buffer + persist for a
    # single streamed response. A pathological backend that emits tens of
    # thousands of tiny chunks would otherwise balloon memory and Redis
    # values. When exceeded we skip the store (a single warning logs why).
    MAX_STREAM_CHUNKS = 5000

    def __init__(self) -> None:
        self._store: Optional[_Store] = None
        self._enabled: bool = True
        self._ttl_seconds: int = self.DEFAULT_TTL
        # When the request's temperature is strictly greater than this
        # threshold, skip caching (non-deterministic). UI-editable via
        # the plugin config schema.
        self._skip_above_temperature: float = 0.0
        self._using_memory: bool = False

    # --- Lifecycle ---------------------------------------------------------
    async def setup(self, app_settings: dict[str, Any]) -> None:
        cache_cfg = ((app_settings.get("policies") or {}).get("cache") or {})
        self._enabled = bool(cache_cfg.get("enabled", True))
        self._ttl_seconds = int(cache_cfg.get("ttl_seconds", self.DEFAULT_TTL))
        try:
            self._skip_above_temperature = float(cache_cfg.get(
                "skip_above_temperature", 0.0,
            ))
        except (TypeError, ValueError):
            self._skip_above_temperature = 0.0

        url: str = app_settings.get("redis_url") or "memory://"

        if url.startswith("memory://"):
            self._store = _InMemoryStore()
            self._using_memory = True
        else:
            try:
                from redis.asyncio import Redis
                client = Redis.from_url(url, decode_responses=True)
                # Sanity check — fail fast if Redis is unreachable.
                await client.ping()
                self._store = _RedisStore(client)
            except Exception as e:  # noqa: BLE001
                log.warning(
                    "cache_redis: Redis at %s unreachable (%s); FALLING BACK "
                    "to in-memory store — cache will NOT be shared across "
                    "replicas",
                    url, e,
                )
                self._store = _InMemoryStore()
                self._using_memory = True

        if self._using_memory:
            log.warning("cache_redis: using in-process cache (dev / test mode)")
        else:
            log.info("cache_redis: connected (ttl=%ds, enabled=%s)",
                     self._ttl_seconds, self._enabled)

    async def teardown(self) -> None:
        if self._store is not None:
            await self._store.aclose()

    # --- Public API used by main.chat_completions --------------------------
    def is_enabled(self) -> bool:
        """True only if the plugin is loaded AND policies.cache.enabled."""
        return self._enabled and self._store is not None

    def is_cacheable(self,
                     messages: list[dict[str, Any]],
                     temperature: Optional[float],
                     tools: Optional[list[dict[str, Any]]] = None) -> bool:
        """Quick gate for callers — same checks lookup() / store() use."""
        if not self.is_enabled():
            return False
        if not _is_cacheable_temperature(temperature,
                                         self._skip_above_temperature):
            return False
        if tools:
            return False
        if _has_tool_calls(messages):
            return False
        return True

    async def lookup(self,
                     messages: list[dict[str, Any]],
                     model_requested: Optional[str],
                     principal,
                     max_tokens: Optional[int],
                     temperature: Optional[float],
                     tools: Optional[list[dict[str, Any]]] = None,
                     ) -> Optional[dict[str, Any]]:
        """Return the cached response dict if present, else ``None``."""
        if not self.is_cacheable(messages, temperature, tools):
            return None
        assert self._store is not None  # is_cacheable() guarantees this

        key = _canonical_key(messages, model_requested, max_tokens,
                             temperature, principal.team_id)
        raw = await self._store.get(key)
        if raw is None:
            self._inc_metric("miss", model_requested, principal.team_id)
            return None
        try:
            data = json.loads(raw)
        except (TypeError, ValueError) as e:
            log.warning("cache_redis: corrupt cache entry for %s: %s", key, e)
            self._inc_metric("miss", model_requested, principal.team_id)
            return None
        self._inc_metric("hit", model_requested, principal.team_id)
        return data

    async def store(self,
                    messages: list[dict[str, Any]],
                    model_requested: Optional[str],
                    principal,
                    max_tokens: Optional[int],
                    temperature: Optional[float],
                    response: dict[str, Any],
                    ttl_seconds: Optional[int] = None,
                    tools: Optional[list[dict[str, Any]]] = None,
                    ) -> None:
        """Persist the response under the canonical key. No-op if not cacheable."""
        if not self.is_cacheable(messages, temperature, tools):
            return
        assert self._store is not None

        key = _canonical_key(messages, model_requested, max_tokens,
                             temperature, principal.team_id)
        try:
            blob = json.dumps(response, ensure_ascii=False, default=str)
        except (TypeError, ValueError) as e:
            log.warning("cache_redis: response not JSON-serialisable, skip: %s", e)
            return
        ttl = int(ttl_seconds if ttl_seconds is not None else self._ttl_seconds)
        await self._store.set(key, blob, ttl_seconds=max(1, ttl))

    # --- Streaming cache --------------------------------------------------
    # The streaming and non-streaming caches share the same cacheability
    # predicates and the same canonical-payload hash, but live under
    # DIFFERENT key prefixes (``cache:stream:`` vs ``cache:resp:``) so the
    # two shapes can never collide. A streaming caller will never be served
    # a non-streaming payload as SSE (it would parse as a single oversized
    # event), and a non-streaming caller will never get a chunk array
    # serialised as a JSONResponse (the body shape is wrong for the
    # chat.completion contract).
    async def lookup_stream(self,
                            messages: list[dict[str, Any]],
                            model_requested: Optional[str],
                            principal,
                            max_tokens: Optional[int],
                            temperature: Optional[float],
                            tools: Optional[list[dict[str, Any]]] = None,
                            ) -> Optional[list[dict[str, Any]]]:
        """Return the cached list of chunk dicts if present, else ``None``."""
        if not self.is_cacheable(messages, temperature, tools):
            return None
        assert self._store is not None

        key = _canonical_key(messages, model_requested, max_tokens,
                             temperature, principal.team_id,
                             prefix="cache:stream:")
        raw = await self._store.get(key)
        if raw is None:
            self._inc_metric("miss", model_requested, principal.team_id)
            return None
        try:
            data = json.loads(raw)
        except (TypeError, ValueError) as e:
            log.warning("cache_redis: corrupt stream cache entry for %s: %s",
                        key, e)
            self._inc_metric("miss", model_requested, principal.team_id)
            return None
        # Defensive: the on-disk shape MUST be a list of dicts. If a
        # collision somehow wrote a non-list under this key, treat as miss.
        if not isinstance(data, list):
            log.warning("cache_redis: stream cache entry not a list for %s",
                        key)
            self._inc_metric("miss", model_requested, principal.team_id)
            return None
        self._inc_metric("hit", model_requested, principal.team_id)
        return data

    async def store_stream(self,
                           messages: list[dict[str, Any]],
                           model_requested: Optional[str],
                           principal,
                           max_tokens: Optional[int],
                           temperature: Optional[float],
                           chunks: list[dict[str, Any]],
                           ttl_seconds: Optional[int] = None,
                           tools: Optional[list[dict[str, Any]]] = None,
                           ) -> None:
        """Persist the list of chunk dicts under the streaming key. No-op if
        not cacheable, if the chunk list is empty, or if the count exceeds
        :attr:`MAX_STREAM_CHUNKS`."""
        if not self.is_cacheable(messages, temperature, tools):
            return
        if not chunks:
            return
        if len(chunks) > self.MAX_STREAM_CHUNKS:
            log.warning(
                "cache_redis: refusing to store stream of %d chunks "
                "(cap=%d) — skipping",
                len(chunks), self.MAX_STREAM_CHUNKS,
            )
            return
        assert self._store is not None

        key = _canonical_key(messages, model_requested, max_tokens,
                             temperature, principal.team_id,
                             prefix="cache:stream:")
        try:
            blob = json.dumps(chunks, ensure_ascii=False, default=str)
        except (TypeError, ValueError) as e:
            log.warning("cache_redis: stream chunks not JSON-serialisable, "
                        "skip: %s", e)
            return
        ttl = int(ttl_seconds if ttl_seconds is not None else self._ttl_seconds)
        await self._store.set(key, blob, ttl_seconds=max(1, ttl))

    # --- Metrics (lazy import to dodge circular dependency on main) --------
    def _inc_metric(self, kind: str, model: Optional[str], team: str) -> None:
        try:
            from ...main import CACHE_HITS, CACHE_MISSES
        except Exception:  # noqa: BLE001
            return
        counter = CACHE_HITS if kind == "hit" else CACHE_MISSES
        try:
            counter.labels(model or "?", team).inc()
        except Exception:  # noqa: BLE001
            pass
