"""Regex-based prompt-injection / banned-topic guardrail.

Lightweight (no ML model dependency) defence for the common attack patterns:

* Direct instruction overrides ("ignore previous instructions", "disregard
  system prompt", "you are now in developer mode", etc.)
* Role-hijack ("act as DAN", "pretend to be root")
* Common jailbreak names (DAN, AIM, Developer Mode)
* Custom banned topics / keywords from ``policies.yaml -> guardrails.banned_topics``

Heavier defences (LLM-based classifiers, NeMo Guardrails) can ship later as
opt-in plugins; this plugin is meant to be the always-on baseline that costs
microseconds per request.

Configurable via ``policies.yaml -> guardrails``::

    guardrails:
      prompt_injection:
        action: refuse        # refuse | warn
        extra_patterns:
          - "(?i)spill the secret"
      banned_topics:
        action: refuse
        keywords: [competitor-corp, project-codename-x]
"""

from __future__ import annotations

import logging
import re
from typing import Any

from ..base import (
    Finding,
    GatewayPlugin,
    HookResult,
    PluginKind,
    PluginVerdict,
    RequestContext,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Built-in pattern library — battle-tested across public jailbreak datasets.
# Each pattern is paired with a kind and severity.
# ---------------------------------------------------------------------------
INJECTION_PATTERNS: list[tuple[str, str, str]] = [
    # (regex, kind, severity)
    (r"(?i)\bignore\s+(all\s+)?(?:previous|prior|above|the)\s+(?:instructions?|prompt|system)\b",
        "prompt_injection.ignore_instructions", "high"),
    (r"(?i)\bdisregard\s+(the\s+)?(?:system|previous|above)\b",
        "prompt_injection.disregard", "high"),
    # Allows intervening adjectives, e.g. "forget all your PRIOR instructions"
    (r"(?i)\bforget\s+(?:all\s+|every\s+|every\s+single\s+)?"
     r"(?:your|the)\s+(?:\w+\s+){0,3}"
     r"(?:instructions?|rules?|prompt|system\s*prompt)\b",
        "prompt_injection.forget", "high"),
    (r"(?i)\boverride\s+(your|the)\s+(?:system|safety|instructions?|policies?)\b",
        "prompt_injection.override", "high"),
    (r"(?i)\b(?:you\s+are|act\s+as|pretend\s+to\s+be)\s+(?:now\s+)?(?:a\s+)?(?:developer|admin|root|super\s*user|god\s*mode)\b",
        "prompt_injection.role_hijack", "high"),
    (r"(?i)\b(?:enter|activate|enable)\s+(?:developer|debug|jailbreak|admin|godmode|god\s*mode)\b",
        "prompt_injection.mode_switch", "high"),
    # Named jailbreaks
    (r"(?i)\bDAN\s*(?:mode|11|12|13|14|jailbreak)?\b",
        "prompt_injection.named.dan", "high"),
    (r"(?i)\b(?:AIM|STAN|DUDE|EvilBOT)\s+(?:mode|prompt|jailbreak)\b",
        "prompt_injection.named.misc", "high"),
    # Indirect injections via metadata / system tag spoofing
    (r"<\|im_start\|>\s*system",
        "prompt_injection.spoof.im_start", "critical"),
    (r"\[\[\s*SYSTEM\s*\]\]",
        "prompt_injection.spoof.system_tag", "critical"),
    (r"(?i)\bprint\s+(your|the)\s+(?:system|hidden|secret)\s+(?:prompt|instructions?)\b",
        "prompt_injection.exfiltrate_prompt", "high"),
]


class PatternGuardrail(GatewayPlugin):
    name = "guardrail_patterns"
    kind = PluginKind.GUARDRAIL
    description = "Regex-based prompt-injection / banned-topic guardrail"

    def __init__(self) -> None:
        self._injection_action: str = "refuse"
        self._topic_action: str = "refuse"
        self._compiled: list[tuple[re.Pattern[str], str, str]] = []
        self._banned_terms: list[re.Pattern[str]] = []

    async def setup(self, app_settings: dict[str, Any]) -> None:
        policies = app_settings.get("policies") or {}
        guard_cfg = policies.get("guardrails") or {}

        inj_cfg = guard_cfg.get("prompt_injection") or {}
        self._injection_action = inj_cfg.get("action", "refuse")
        extra = list(inj_cfg.get("extra_patterns") or [])

        compiled: list[tuple[re.Pattern[str], str, str]] = []
        for pat, kind, sev in INJECTION_PATTERNS:
            compiled.append((re.compile(pat), kind, sev))
        # extra_patterns accepts two shapes for backward + forward compat:
        #   - a bare regex string (legacy YAML form)
        #   - a {name, regex, severity, action} dict (UI-added DB rows)
        for pat in extra:
            try:
                if isinstance(pat, dict):
                    regex   = pat.get("regex") or pat.get("pattern")
                    sev     = pat.get("severity") or "high"
                    name    = pat.get("name") or "custom"
                    if not regex:
                        continue
                    compiled.append(
                        (re.compile(regex), f"prompt_injection.{name}", sev)
                    )
                elif isinstance(pat, str):
                    compiled.append(
                        (re.compile(pat), "prompt_injection.custom", "high")
                    )
                else:
                    log.warning("guardrail_patterns: ignoring extra_pattern of "
                                "type %s — expected str or dict", type(pat).__name__)
            except re.error as e:
                log.warning("guardrail_patterns: bad custom pattern %r: %s", pat, e)
        self._compiled = compiled

        topic_cfg = guard_cfg.get("banned_topics") or {}
        self._topic_action = topic_cfg.get("action", "refuse")
        self._banned_terms = []
        for kw in topic_cfg.get("keywords") or []:
            if not isinstance(kw, str) or not kw:
                continue
            # Word-boundary match, case-insensitive.
            self._banned_terms.append(
                re.compile(rf"(?i)\b{re.escape(kw)}\b")
            )

        log.info(
            "guardrail_patterns: %d injection pattern(s), %d banned term(s); "
            "actions=injection:%s topics:%s",
            len(self._compiled), len(self._banned_terms),
            self._injection_action, self._topic_action,
        )

    async def on_pre_call(self, ctx: RequestContext) -> HookResult:
        findings: list[Finding] = []
        worst_severity = "info"
        any_critical = False

        for i, msg in enumerate(ctx.messages):
            content = msg.get("content")
            if not isinstance(content, str) or not content:
                continue

            for pat, kind, severity in self._compiled:
                m = pat.search(content)
                if not m:
                    continue
                findings.append(Finding(
                    plugin=self.name,
                    kind=kind,
                    severity=severity,
                    message=f"{kind} pattern matched in messages[{i}]",
                    location=f"messages[{i}].content[{m.start()}:{m.end()}]",
                ))
                if severity == "critical":
                    any_critical = True
                worst_severity = _max_severity(worst_severity, severity)

            for term in self._banned_terms:
                m = term.search(content)
                if not m:
                    continue
                findings.append(Finding(
                    plugin=self.name,
                    kind="guardrail.banned_topic",
                    severity="high",
                    message=f"Banned topic keyword matched in messages[{i}]",
                    location=f"messages[{i}].content[{m.start()}:{m.end()}]",
                ))
                worst_severity = _max_severity(worst_severity, "high")

        if not findings:
            return HookResult(verdict=PluginVerdict.ALLOW)

        # Decide action.
        is_topic_only = all(f.kind == "guardrail.banned_topic" for f in findings)
        action = self._topic_action if is_topic_only else self._injection_action

        if action == "refuse" or any_critical:
            return HookResult(
                verdict=PluginVerdict.REFUSE,
                status_code=403,
                error_code="guardrail_blocked",
                reason=("Prompt blocked by guardrails: "
                        + ", ".join(sorted({f.kind for f in findings}))),
                findings=findings,
            )

        # action == "warn" → continue, but propagate findings.
        return HookResult(verdict=PluginVerdict.WARN, findings=findings,
                          reason="Guardrail warning")


_SEVERITY_ORDER = {"info": 0, "warn": 1, "high": 2, "critical": 3}


def _max_severity(a: str, b: str) -> str:
    return a if _SEVERITY_ORDER.get(a, 0) >= _SEVERITY_ORDER.get(b, 0) else b
