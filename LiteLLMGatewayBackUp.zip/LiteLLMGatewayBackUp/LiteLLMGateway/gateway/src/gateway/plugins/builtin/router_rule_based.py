"""Rule-based smart router.

Reads ``router_rules`` from ``policies.yaml`` and applies the first rule whose
``when`` clause matches the (prompt, principal, findings) tuple. Falls through
to the catch-all default rule.

Each rule's ``when`` clause supports a small DSL kept deliberately tiny so the
config is a YAML file engineers can edit without learning a new language:

    when:
      max_tokens: 100               # prompt length ≤ 100
      no_tools: true                # no tools list in the payload
      no_code_blocks: true          # no ```fenced blocks
      has_code_blocks: true         # opposite
      has_tools: true               # opposite
      contains_any: ["refactor"]    # any substring matches (case-insensitive)
      starts_with_any: ["plan "]    # prefix match (case-insensitive)
      dlp_findings_present: true    # at least one DLP finding accumulated
      team_budget_used_pct: 80      # current team has used ≥ N% of daily budget
      any_of: [ ... nested ... ]    # OR over a list of clauses

Extending the DSL means adding one method to ``_RuleEvaluator`` and one entry
to ``_PREDICATES``.
"""

from __future__ import annotations

import logging
from typing import Any

from ..base import (
    GatewayPlugin,
    HookResult,
    PluginKind,
    PluginVerdict,
    RequestContext,
)

log = logging.getLogger(__name__)


# A "no-preference" model means the developer is letting the router pick
# (None / "" / "auto", case-insensitive). Kept module-local on purpose —
# authz_tiered owns its own equivalent so the two stay independently
# swappable.
_NO_PREFERENCE_MODELS: frozenset[str] = frozenset({"", "auto"})


def _is_no_preference(model: str | None) -> bool:
    """True when the caller wants the router to pick (None / "" / "auto")."""
    if model is None:
        return True
    return model.strip().lower() in _NO_PREFERENCE_MODELS


def _count_tokens(messages: list[dict]) -> int:
    """Rough heuristic — 4 chars per token. Good enough for routing."""
    total_chars = sum(len(m.get("content", "")) for m in messages if isinstance(m.get("content"), str))
    return total_chars // 4


def _has_code_blocks(messages: list[dict]) -> bool:
    return any("```" in m.get("content", "") for m in messages if isinstance(m.get("content"), str))


def _has_images(messages: list[dict]) -> bool:
    """True if any message carries an image content block.

    Handles both the OpenAI-style (``{"type": "image_url", ...}``) and the
    Anthropic-style (``{"type": "image", "source": {...}}``) multimodal
    payload. A string ``content`` field never carries an image, so we only
    inspect list-typed content.
    """
    for m in messages:
        c = m.get("content")
        if not isinstance(c, list):
            continue
        for part in c:
            if not isinstance(part, dict):
                continue
            t = part.get("type")
            if t == "image_url" or t == "image" or t == "input_image":
                return True
    return False


def _flatten_text(messages: list[dict]) -> str:
    return " ".join(m.get("content", "") for m in messages if isinstance(m.get("content"), str))


class RuleBasedRouter(GatewayPlugin):
    """Pick a model by prompt length / intent / DLP / budget — first match wins.

    When `ctx.model_requested` is the no-preference sentinel (None / "" /
    "auto", case-insensitive) the router evaluates rules normally without
    treating the requested name as a preference. If no rule matches a
    tier-permitted model the request is REFUSE'd just like any other route.
    """

    name = "router_rule_based"
    kind = PluginKind.ROUTER
    description = "Picks model by length / intent / DLP / budget. First match wins."

    def __init__(self) -> None:
        self.rules: list[dict[str, Any]] = []
        self.budget_lookup = None  # injected at setup; reads team daily-spend pct

    async def setup(self, app_settings: dict[str, Any]) -> None:
        policies = app_settings.get("policies") or {}
        self.rules = policies.get("router_rules", [])
        if not self.rules:
            log.warning("router_rule_based: no rules configured; will always REFUSE")
        else:
            log.info("router_rule_based: loaded %d rules", len(self.rules))

    async def on_route_select(self, ctx: RequestContext) -> HookResult:
        # Tier-enforced allow-list. Set by authz_tiered; absent = no AuthZ
        # plugin loaded → permit everything (used in plugin-less unit tests).
        allowed = ctx.extra.get("allowed_models")
        wildcard = ctx.extra.get("wildcard_models", False)

        def is_permitted(model: str) -> bool:
            if allowed is None or wildcard:
                return True
            return model in allowed

        # No-preference sentinel ("" / None / "auto" / "AUTO" / etc.) means
        # "router, you decide" — fall straight through to rule evaluation
        # without treating the requested name as a preference or override.
        if not _is_no_preference(ctx.model_requested):
            if ctx.model_requested.startswith("force:"):
                forced = ctx.model_requested[len("force:"):]
                # authz_tiered will already have refused if forced is disallowed;
                # but defence-in-depth — the router re-checks before honouring it.
                if not is_permitted(forced):
                    return HookResult(
                        verdict=PluginVerdict.REFUSE,
                        reason=f"Tier cannot call forced model {forced!r}",
                    )
                ctx.model_selected = forced
                ctx.routing_reason = "manual override (force:)"
                return HookResult(verdict=PluginVerdict.ALLOW)

        ev = _RuleEvaluator(ctx)
        for rule in self.rules:
            if not ev.matches(rule.get("when") or {}):
                continue
            model = rule.get("route")
            if not model:
                log.warning("router_rule_based: rule %r has no 'route'; skipping",
                            rule.get("name"))
                continue
            if not is_permitted(model):
                # Try fallback_if_tier_blocks before failing the rule.
                alt = rule.get("fallback_if_tier_blocks")
                if alt and is_permitted(alt):
                    ctx.model_selected = alt
                    ctx.routing_reason = (
                        f"{rule.get('reason', rule.get('name', 'rule match'))}"
                        f" (downgraded to {alt} — tier blocked {model})"
                    )
                    return HookResult(verdict=PluginVerdict.ALLOW)
                # No fallback or fallback also blocked — keep scanning for
                # the next rule that the tier IS permitted to use.
                continue

            ctx.model_selected = model
            ctx.routing_reason = rule.get("reason", rule.get("name", "rule match"))
            if rule.get("force_self_host"):
                ctx.extra["force_self_host"] = True
            return HookResult(verdict=PluginVerdict.ALLOW)

        return HookResult(
            verdict=PluginVerdict.REFUSE,
            reason="No router rule matched a model permitted for this tier",
        )


class _RuleEvaluator:
    """Holds prompt-level features so each rule check is O(predicates)."""

    def __init__(self, ctx: RequestContext) -> None:
        self.ctx = ctx
        self.token_count = _count_tokens(ctx.messages)
        self.has_code = _has_code_blocks(ctx.messages)
        self.has_images = _has_images(ctx.messages)
        self.has_tools = bool(ctx.tools)
        self.text_lower = _flatten_text(ctx.messages).lower()
        self.has_dlp = any(f.kind.startswith(("pii.", "secret.", "regulated.")) for f in ctx.findings)

    def matches(self, when: dict[str, Any]) -> bool:
        if not when:
            return True   # empty clause = always match (default rule)
        for key, expected in when.items():
            ok = _PREDICATES.get(key, lambda *_: False)(self, expected)
            if not ok:
                return False
        return True


# ---- predicate registry — easy to extend ---------------------------------
def _p_max_tokens(ev: _RuleEvaluator, v: int) -> bool:        return ev.token_count <= v
def _p_no_tools(ev: _RuleEvaluator, v: bool) -> bool:         return ev.has_tools is not bool(v)
def _p_has_tools(ev: _RuleEvaluator, v: bool) -> bool:        return ev.has_tools == bool(v)
def _p_no_code_blocks(ev: _RuleEvaluator, v: bool) -> bool:   return ev.has_code is not bool(v)
def _p_has_code_blocks(ev: _RuleEvaluator, v: bool) -> bool:  return ev.has_code == bool(v)
def _p_has_images(ev: _RuleEvaluator, v: bool) -> bool:       return ev.has_images == bool(v)
def _p_no_images(ev: _RuleEvaluator, v: bool) -> bool:        return ev.has_images is not bool(v)
def _p_contains_any(ev: _RuleEvaluator, needles: list[str]) -> bool:
    return any(n.lower() in ev.text_lower for n in needles)
def _p_starts_with_any(ev: _RuleEvaluator, prefixes: list[str]) -> bool:
    head = ev.text_lower.lstrip()[:120]
    return any(head.startswith(p.lower()) for p in prefixes)
def _p_dlp_findings_present(ev: _RuleEvaluator, v: bool) -> bool:
    return ev.has_dlp == bool(v)
def _p_team_budget_used_pct(ev: _RuleEvaluator, threshold: int) -> bool:
    # Placeholder until S3 wires real Redis-backed counters.
    return False
def _p_any_of(ev: _RuleEvaluator, clauses: list[dict]) -> bool:
    return any(ev.matches(c) for c in clauses)


_PREDICATES: dict[str, Any] = {
    "max_tokens":           _p_max_tokens,
    "no_tools":             _p_no_tools,
    "has_tools":            _p_has_tools,
    "no_code_blocks":       _p_no_code_blocks,
    "has_code_blocks":      _p_has_code_blocks,
    "has_images":           _p_has_images,
    "no_images":            _p_no_images,
    "contains_any":         _p_contains_any,
    "starts_with_any":      _p_starts_with_any,
    "dlp_findings_present": _p_dlp_findings_present,
    "team_budget_used_pct": _p_team_budget_used_pct,
    "any_of":               _p_any_of,
}
