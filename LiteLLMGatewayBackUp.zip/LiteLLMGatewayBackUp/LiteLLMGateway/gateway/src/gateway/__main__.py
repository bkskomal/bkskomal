"""Launcher so ``python -m gateway`` runs uvicorn with the package already
imported.

On Windows, importing ``gateway`` triggers ``__init__.py``, which installs
the ``WindowsSelectorEventLoopPolicy`` required by psycopg-async. If we
instead boot via ``python -m uvicorn gateway.main:app``, uvicorn calls
``asyncio.run()`` *before* it imports ``gateway`` — the loop is created
under the default ``ProactorEventLoop`` and every DB connection deadlocks
with ``Psycopg cannot use the 'ProactorEventLoop'``.
"""

from __future__ import annotations

import argparse

import uvicorn


def main() -> None:
    p = argparse.ArgumentParser(prog="python -m gateway")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=4000)
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--log-level", default="warning")
    p.add_argument("--no-access-log", action="store_true")
    p.add_argument("--proxy-headers", action="store_true")
    p.add_argument("--reload", action="store_true")
    args = p.parse_args()

    uvicorn.run(
        "gateway.main:app",
        host=args.host,
        port=args.port,
        workers=args.workers,
        log_level=args.log_level,
        access_log=not args.no_access_log,
        proxy_headers=args.proxy_headers,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
