"""Bearer-token → Principal resolution.

Resolution order:

1. **Master key** (``GATEWAY_MASTER_KEY``) → admin role, ``platform-admins`` team
2. **DB-backed virtual key** — issued via ``POST /admin/keys`` (sk-…)
3. **Dev shortcut** — ``sk-dev-<team>-<tier>-<user>`` (enabled only when
   ``GATEWAY_ENVIRONMENT != "production"``)

The dev shortcut keeps the existing test suite green while real key issuance
matures. Production hardening (Sprint 4) flips a flag and the shortcut goes
away entirely.
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import Header, HTTPException, Request

from .config import get_settings
from .db import gateway_session
from .plugins.base import Principal
from .services import elevations as elevations_service
from .services import keys as keys_service
from .services import teams as teams_service

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------
async def require_principal(request: Request,
                            authorization: str | None = Header(default=None)) -> Principal:
    """Resolve the bearer token to a Principal. Raises 401 on failure."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.split(" ", 1)[1].strip()

    settings = get_settings()

    # 1. Master key
    if token == settings.master_key:
        return Principal(user_id="master",
                         team_id="platform-admins",
                         tier="L3_privileged",
                         email="master@gateway",
                         roles=["admin"])

    # 2. DB-backed virtual key
    async for session in gateway_session():
        record = await keys_service.lookup_by_raw(session, token)
        if record is not None:
            # Enforce key expiry. `expires_at` is optional — when set, the
            # key is invalid past that moment. Without this check expired
            # keys silently kept working, which is a real security gap.
            if record.expires_at is not None:
                from datetime import datetime, timezone as _tz
                now = datetime.now(_tz.utc)
                # SQLAlchemy returns datetimes as tz-aware (with timezone=True)
                # but defensively coerce just in case.
                exp = record.expires_at
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=_tz.utc)
                if exp <= now:
                    log.warning("Rejected expired key id=%s (user=%s, expired=%s)",
                                record.id, record.user_id, exp.isoformat())
                    raise HTTPException(
                        status_code=401,
                        detail="API key has expired",
                    )
            team = await teams_service.get_team(session, record.team_id)
            base_tier = team.tier if team else "L0_readonly"
            # JIT elevation: if an approved-and-not-yet-expired elevation
            # exists, swap the tier and record its id for audit attribution.
            elev_rec = await _safe_active_elevation(session, record.user_id)
            tier         = elev_rec.requested_tier if elev_rec else base_tier
            elevation_id = elev_rec.id              if elev_rec else None
            # Best-effort last-used bookkeeping; never block the request on it.
            try:
                await keys_service.mark_used(session, record.id)
            except Exception:  # noqa: BLE001
                log.exception("Failed to update last_used_at for key id=%s", record.id)
            return Principal(
                user_id=record.user_id,
                team_id=record.team_id,
                tier=tier,
                email=record.user_email,
                roles=[record.role],
                base_tier=base_tier,
                elevation_id=elevation_id,
            )

    # 3. Dev-token shortcut — enabled by an EXPLICIT allowlist of environments
    # so a typo'd GATEWAY_ENVIRONMENT (e.g. "Production" vs "production")
    # can never accidentally enable it. Dev tokens carry empty roles, so
    # they cannot pass require_admin (closes the impersonation → self-approve
    # path that the security review flagged).
    #
    # JIT elevation IS honoured for dev tokens because the entire dev
    # shortcut is by design "arbitrary identity in dev only" — disabling
    # elevation here would not buy any real safety while breaking tests.
    if settings.environment in {"dev", "test", "development"} \
            and token.startswith("sk-dev+"):
        parts = token.split("+")
        if len(parts) >= 4:
            user_id   = parts[3]
            base_tier = parts[2]
            tier = base_tier
            elevation_id: Optional[int] = None
            async for session in gateway_session():
                elev = await _safe_active_elevation(session, user_id)
                if elev:
                    tier         = elev.requested_tier
                    elevation_id = elev.id
                break
            return Principal(
                user_id=user_id,
                team_id=parts[1],
                tier=tier,
                email=f"{user_id}@dev.local",
                roles=[],   # the shortcut never grants admin
                base_tier=base_tier,
                elevation_id=elevation_id,
            )

    raise HTTPException(status_code=401, detail="Invalid API key")


async def _safe_active_elevation(session, user_id: str):
    """Look up an active elevation without ever raising on the auth path.

    A DB error here would lock every developer out of every request — too
    blast-y for an optional feature, so we log and fall back to None. The
    failure is also surfaced as a Prometheus counter so SRE notices when
    the elevation lookup silently degrades.
    """
    try:
        return await elevations_service.active_for(session, user_id)
    except Exception:  # noqa: BLE001
        log.exception("Failed to read elevation_requests for user=%s; falling back", user_id)
        try:
            from .main import ELEVATION_LOOKUP_FAILED
            ELEVATION_LOOKUP_FAILED.inc()
        except Exception:  # noqa: BLE001
            pass
        return None


def require_admin(principal: Principal) -> None:
    if "admin" not in principal.roles:
        raise HTTPException(status_code=403, detail="Admin role required")


def is_admin(principal: Optional[Principal]) -> bool:
    return bool(principal and "admin" in principal.roles)
