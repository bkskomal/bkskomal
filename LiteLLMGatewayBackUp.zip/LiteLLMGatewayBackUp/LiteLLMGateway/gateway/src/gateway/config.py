"""Typed settings sourced from environment variables + .env.

Use :func:`get_settings` everywhere instead of reading os.environ directly so
the gateway is testable and the schema stays in one place.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="GATEWAY_",
        env_file=(".env", "../.env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Server ---------------------------------------------------------
    host: str = "0.0.0.0"
    port: int = 4000
    log_level: str = "INFO"
    environment: str = "dev"

    # --- Databases ------------------------------------------------------
    db_url: str = Field(default="postgresql+psycopg://postgres:postgres@localhost/litellm_gateway")
    audit_db_url: str = Field(default="postgresql+psycopg://postgres:postgres@localhost/litellm_gateway_audit")

    # --- Redis ----------------------------------------------------------
    redis_url: str = "redis://localhost:6379/0"

    # --- Crypto ---------------------------------------------------------
    jwt_secret: str = "dev-only-not-for-prod"
    master_key: str = "sk-master-dev"

    # --- Files ----------------------------------------------------------
    litellm_config_path: Path = Path("litellm_config.yaml")
    policies_path: Path = Path("policies.yaml")

    # --- Plugins --------------------------------------------------------
    plugins: str = Field(
        default="router_rule_based,dlp_presidio,audit_postgres",
        description="Comma-separated entry-point names to enable.",
    )

    @property
    def plugins_list(self) -> list[str]:
        return [p.strip() for p in self.plugins.split(",") if p.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached singleton — call this everywhere."""
    return Settings()
