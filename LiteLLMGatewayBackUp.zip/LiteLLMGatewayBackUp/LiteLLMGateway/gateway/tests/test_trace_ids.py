"""Trace-ID grouping: header echo, defaulting, search filter, CSV column.

These tests cover the request_trace_grouping observability feature: clients
send ``X-Gateway-Trace: <opaque-id>`` to group every call of a multi-turn
session (Cline / Continue / aider) into one audit trace. When the header is
absent, the gateway defaults ``trace_id`` to ``request_id`` so single-call
requests still produce a queryable trace (no separate "untraced" branch).
"""

from __future__ import annotations

import asyncio
import os

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev",
          "Content-Type":  "application/json"}


async def _latest_audit_row() -> dict:
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            result = await conn.execute(text(
                "SELECT request_id, trace_id, verdict "
                "FROM audit_log ORDER BY id DESC LIMIT 1"
            ))
            row = result.mappings().first()
    finally:
        await eng.dispose()
    return dict(row) if row else {}


async def _all_audit_rows() -> list[dict]:
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            result = await conn.execute(text(
                "SELECT request_id, trace_id FROM audit_log ORDER BY id"
            ))
            rows = result.mappings().all()
    finally:
        await eng.dispose()
    return [dict(r) for r in rows]


@pytest.mark.asyncio
async def test_audit_writes_trace_id_from_header(gateway_client, clean_audit_db):
    """A client-supplied X-Gateway-Trace header lands on the audit row and
    is echoed back on the response so the client can confirm the grouping."""
    headers = {**dev_headers(), "X-Gateway-Trace": "trace-abc-123"}
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=headers,
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text
    assert r.headers.get("x-gateway-trace") == "trace-abc-123"

    await asyncio.sleep(0.2)
    row = await _latest_audit_row()
    assert row.get("trace_id") == "trace-abc-123"


@pytest.mark.asyncio
async def test_audit_defaults_trace_to_request_id_when_header_absent(
    gateway_client, clean_audit_db,
):
    """Without the header, trace_id defaults to request_id (and the response
    echoes that gateway-generated value back as X-Gateway-Trace)."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text
    rid    = r.headers.get("x-gateway-request-id")
    trace  = r.headers.get("x-gateway-trace")
    assert rid, "missing X-Gateway-Request-Id"
    assert trace == rid, (trace, rid)

    await asyncio.sleep(0.2)
    row = await _latest_audit_row()
    assert row.get("request_id") == rid
    assert row.get("trace_id") == rid


@pytest.mark.asyncio
async def test_audit_search_filter_by_trace(gateway_client, clean_audit_db):
    """Driving three chats with two trace ids → search filters correctly."""
    # Two calls with the same trace.
    for _ in range(2):
        r = await gateway_client.post(
            "/v1/chat/completions",
            headers={**dev_headers(), "X-Gateway-Trace": "t-multi"},
            json={"messages": [{"role": "user", "content": "hi"}]},
        )
        assert r.status_code == 200, r.text
    # One call with a different trace.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={**dev_headers(), "X-Gateway-Trace": "t-other"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text

    await asyncio.sleep(0.3)

    # Sanity — three rows in the audit log.
    rows = await _all_audit_rows()
    assert len(rows) == 3, rows

    # Filter by t-multi → exactly 2 rows, all with that trace.
    r = await gateway_client.get(
        "/admin/audit/search?trace_id=t-multi", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert len(body["rows"]) == 2, body
    assert all(row["trace_id"] == "t-multi" for row in body["rows"])

    # Filter by t-other → exactly 1 row.
    r = await gateway_client.get(
        "/admin/audit/search?trace_id=t-other", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert len(body["rows"]) == 1, body
    assert body["rows"][0]["trace_id"] == "t-other"


@pytest.mark.asyncio
async def test_csv_export_includes_trace_column(gateway_client, clean_audit_db):
    """The CSV export advertises trace_id in the header AND emits a non-empty
    value for every data row (the default rule guarantees this — every row
    has at least its own request_id as trace_id)."""
    # Drive two calls with a custom trace.
    for _ in range(2):
        r = await gateway_client.post(
            "/v1/chat/completions",
            headers={**dev_headers(), "X-Gateway-Trace": "csv-trace"},
            json={"messages": [{"role": "user", "content": "hi"}]},
        )
        assert r.status_code == 200, r.text

    await asyncio.sleep(0.3)

    r = await gateway_client.get(
        "/admin/audit/search.csv", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    text_body = r.text
    lines = text_body.strip().splitlines()
    header = lines[0].split(",")
    assert "trace_id" in header, header
    idx = header.index("trace_id")
    # Every data row should have a non-empty trace_id.
    for line in lines[1:]:
        import csv as _csv
        import io as _io
        cols = next(_csv.reader(_io.StringIO(line)))
        assert cols[idx], f"empty trace_id in CSV row: {line}"
