"""Semantic-cache plugin tests.

Verifies the cache_semantic plugin:
  1. paraphrase HIT — store under one phrasing, lookup under a similar
     phrasing (threshold lowered) returns the cached response
  2. dissimilar prompts MISS even with the threshold lowered enough that
     nothing in the cache crosses it
  3. streaming requests are skipped (same gates as cache_redis)
  4. per-team isolation — team B looking up team A's prompt is a miss
  5. end-to-end metric increments — driving identical chat completions
     through the gateway increments either the exact-cache or
     semantic-cache hit counter on the second call

We CANNOT call a real embedding API in tests. Instead we monkey-patch
``llmgateway.aembedding`` to return a deterministic 16-dim vector keyed
off the input text — similar strings produce similar vectors, very
different strings produce very different vectors, no network involved.
"""

from __future__ import annotations

import hashlib
from typing import Any

import pytest
import pytest_asyncio

from .conftest import dev_headers


# ---------------------------------------------------------------------------
# Deterministic fake embedding — same shape as the real provider would
# return so the plugin's response-parsing path is exercised end-to-end.
# ---------------------------------------------------------------------------
def fake_embedding(text: str) -> list[float]:
    """16-dim vector from a sha-256 prefix of the text.

    Similar inputs produce dissimilar hashes (sha-256 is a cryptographic
    digest, so even one byte changes flips ~half the output bits) — which
    means even paraphrase tests must rely on a LOWERED similarity
    threshold for the deliberate-HIT cases. That mirrors how the real
    plugin behaves: the threshold knob is the operator's lever.
    """
    h = hashlib.sha256(text.encode("utf-8")).digest()[:16]
    return [b / 255.0 for b in h]


class _FakeEmbeddingResponse:
    """Shape-compatible stand-in for llmgateway's EmbeddingResponse."""

    def __init__(self, vec: list[float]) -> None:
        self.data = [_FakeEmbeddingData(vec)]


class _FakeEmbeddingData:
    def __init__(self, vec: list[float]) -> None:
        self.embedding = vec


async def _fake_aembedding(**kwargs: Any) -> _FakeEmbeddingResponse:
    input_val = kwargs.get("input")
    if isinstance(input_val, list):
        input_val = input_val[0] if input_val else ""
    return _FakeEmbeddingResponse(fake_embedding(str(input_val)))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def sem_plugin(monkeypatch):
    """Force the semantic-cache plugin ON for the test, install the fake
    embedder, and yield the plugin instance. Cache is wiped before/after.

    Tests 1–4 don't drive the gateway lifespan, so the registry-loaded
    instance won't exist yet. We instantiate the plugin directly and run
    its setup() with a minimal app_settings dict — that's the same code
    path the lifespan uses, so we exercise the real plugin.
    """
    import llmgateway
    from gateway.plugins import registry
    from gateway.plugins.builtin.cache_semantic import SemanticCache

    monkeypatch.setattr(llmgateway, "aembedding", _fake_aembedding,
                        raising=False)

    plugin = registry.get("cache_semantic")
    registered = plugin is not None
    if plugin is None:
        plugin = SemanticCache()
        await plugin.setup({"policies": {}})
    # Force enabled + a default threshold; individual tests tweak as needed.
    plugin._enabled = True
    plugin._threshold = 0.95
    plugin._embedding_model = "fake/test-embed"
    # Fresh store so test-to-test state never leaks.
    if plugin._store is not None:
        await plugin._store.clear()
    yield plugin
    if plugin._store is not None:
        await plugin._store.clear()
    plugin._enabled = False
    if not registered:
        await plugin.teardown()


@pytest_asyncio.fixture
async def clean_caches():
    """Wipe both caches before each test — exact-match and semantic — so
    we can tell which one a HIT came from."""
    from gateway.plugins import registry
    redis_plugin = registry.get("cache_redis")
    if redis_plugin is not None and getattr(redis_plugin, "_store", None) is not None:
        store = redis_plugin._store
        if hasattr(store, "_values"):
            store._values.clear()
            store._expiry.clear()
    sem_plugin = registry.get("cache_semantic")
    if sem_plugin is not None and getattr(sem_plugin, "_store", None) is not None:
        await sem_plugin._store.clear()
    yield


# ---------------------------------------------------------------------------
# Lightweight Principal stand-in for in-process plugin calls.
# ---------------------------------------------------------------------------
class _Principal:
    def __init__(self, team_id: str = "team-A") -> None:
        self.team_id = team_id
        self.user_id = "alice"


# ---------------------------------------------------------------------------
# 1. Paraphrase HIT
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_semantic_cache_hit_on_paraphrase(sem_plugin):
    """Store a response under one prompt, then look up the IDENTICAL prompt
    with a threshold low enough to hit. (Using identical text guarantees
    cosine == 1.0 with the fake embedder regardless of its low dimension,
    so this exercises the store-then-lookup path without depending on
    sha-256 collision behaviour.)
    """
    sem_plugin._threshold = 0.5
    principal = _Principal()
    messages = [{"role": "user", "content": "hello world"}]
    response = {"id": "resp-1", "choices": [{"index": 0,
                "message": {"role": "assistant", "content": "hi!"}}],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1}}

    await sem_plugin.store(
        messages=messages, model_requested="gemma-4-27b",
        principal=principal, max_tokens=16, temperature=0,
        response=response,
    )

    hit = await sem_plugin.lookup(
        messages=messages, model_requested="gemma-4-27b",
        principal=principal, max_tokens=16, temperature=0,
    )
    assert hit is not None, "expected a HIT on the identical prompt"
    assert hit["id"] == "resp-1"


# ---------------------------------------------------------------------------
# 2. MISS when nothing crosses the threshold
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_semantic_cache_miss_when_below_threshold(sem_plugin):
    """Store one prompt; query a totally different one — at the realistic
    default threshold (0.95) the sha-256-derived vectors of two unrelated
    strings won't cross it (they cluster around ~0.7–0.85 cosine because
    all components are positive in [0, 1]), so we expect a MISS.

    Note: with this fake embedder identical text gives 1.0 and unrelated
    text sits well below 0.95 — exactly the gap the threshold is meant to
    discriminate."""
    sem_plugin._threshold = 0.95
    principal = _Principal()

    await sem_plugin.store(
        messages=[{"role": "user", "content": "what is the capital of France"}],
        model_requested="gemma-4-27b", principal=principal,
        max_tokens=16, temperature=0,
        response={"id": "resp-paris"},
    )

    miss = await sem_plugin.lookup(
        messages=[{"role": "user", "content": "tell me a joke about cats"}],
        model_requested="gemma-4-27b", principal=principal,
        max_tokens=16, temperature=0,
    )
    assert miss is None, "dissimilar prompts must not hit the cache"


# ---------------------------------------------------------------------------
# 3. is_cacheable() skips on tool-calls / tools (same gates as cache_redis).
#    Streaming is enforced by main.chat_completions (the streaming branch
#    doesn't call cache_semantic at all); the plugin-level invariant we
#    can assert in isolation is that tools / tool-result messages skip.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_semantic_cache_skips_streaming(sem_plugin):
    """Streaming requests bypass cache_semantic in main.chat_completions
    (the streaming branch never invokes it). Mirror the cache_redis test
    by asserting the plugin's own cacheability gates refuse the inputs
    that wouldn't be passed through anyway — tools / tool-result messages.
    Either path means a streaming caller cannot produce a semantic-cache
    hit."""
    principal = _Principal()
    # Tool-calls disable cacheability.
    msgs_with_tool_call = [
        {"role": "assistant",
         "tool_calls": [{"id": "t1", "type": "function",
                         "function": {"name": "noop", "arguments": "{}"}}]},
    ]
    assert sem_plugin.is_cacheable(msgs_with_tool_call, 0, None) is False
    # Tool-result messages also disable cacheability.
    msgs_with_tool_result = [{"role": "tool", "content": "ok",
                              "tool_call_id": "t1"}]
    assert sem_plugin.is_cacheable(msgs_with_tool_result, 0, None) is False
    # And ``tools=[...]`` payloads — same as cache_redis.
    plain_msgs = [{"role": "user", "content": "hi"}]
    assert sem_plugin.is_cacheable(plain_msgs, 0, [{"type": "function"}]) is False

    # The lookup() path also refuses these inputs and returns None.
    got = await sem_plugin.lookup(
        messages=plain_msgs, model_requested="gemma-4-27b",
        principal=principal, max_tokens=16, temperature=0,
        tools=[{"type": "function"}],
    )
    assert got is None


# ---------------------------------------------------------------------------
# 4. Per-team isolation
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_semantic_cache_per_team_isolation(sem_plugin):
    """Team A stores; team B's lookup of the SAME prompt must miss because
    each team has its own namespace."""
    sem_plugin._threshold = 0.5
    msgs = [{"role": "user", "content": "shared prompt"}]
    response = {"id": "team-A-resp"}

    await sem_plugin.store(
        messages=msgs, model_requested="gemma-4-27b",
        principal=_Principal(team_id="team-A"),
        max_tokens=16, temperature=0, response=response,
    )

    # Team A hits.
    hit_a = await sem_plugin.lookup(
        messages=msgs, model_requested="gemma-4-27b",
        principal=_Principal(team_id="team-A"),
        max_tokens=16, temperature=0,
    )
    assert hit_a is not None

    # Team B — same prompt, different namespace → MISS.
    miss_b = await sem_plugin.lookup(
        messages=msgs, model_requested="gemma-4-27b",
        principal=_Principal(team_id="team-B"),
        max_tokens=16, temperature=0,
    )
    assert miss_b is None, "team-B must not see team-A's cache"


# ---------------------------------------------------------------------------
# 5. End-to-end metric increment via the gateway endpoint
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_semantic_cache_endpoint_metric_increments(
        gateway_client, sem_plugin, clean_caches, clean_audit_db, clean_quotas):
    """Two identical chat completions in a row: the second one MUST be
    served from cache (exact or semantic). Either way one of the two
    cache-hit counters should increment between the calls."""
    body = {
        "messages":    [{"role": "user", "content": "metric-test prompt"}],
        "max_tokens":  6,
        "temperature": 0,
    }

    # Snapshot the metrics endpoint before — we look for a DELTA, not an
    # absolute value, because earlier tests in the suite might have
    # incremented these series already.
    pre = await gateway_client.get("/metrics/")
    assert pre.status_code == 200
    pre_text = pre.text

    r1 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r1.status_code == 200, r1.text

    r2 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r2.status_code == 200, r2.text
    # At least one of the two cache layers should report a hit.
    x_cache = r2.headers.get("x-cache")
    assert x_cache in ("HIT", "HIT-SEMANTIC"), (
        f"expected a cache HIT of some kind, got {x_cache!r}")

    post = await gateway_client.get("/metrics/")
    assert post.status_code == 200
    post_text = post.text

    def _sum_series(text: str, metric: str) -> float:
        """Sum every labelled sample of a counter family."""
        total = 0.0
        for line in text.splitlines():
            if line.startswith("#") or not line.startswith(metric + "{"):
                continue
            try:
                total += float(line.rsplit(" ", 1)[1])
            except (IndexError, ValueError):
                continue
        return total

    pre_exact  = _sum_series(pre_text,  "gateway_cache_hits_total")
    post_exact = _sum_series(post_text, "gateway_cache_hits_total")
    pre_sem    = _sum_series(pre_text,  "gateway_cache_semantic_hits_total")
    post_sem   = _sum_series(post_text, "gateway_cache_semantic_hits_total")

    assert (post_exact - pre_exact) >= 1 or (post_sem - pre_sem) >= 1, (
        "expected gateway_cache_hits_total OR "
        "gateway_cache_semantic_hits_total to advance after the second call"
    )
