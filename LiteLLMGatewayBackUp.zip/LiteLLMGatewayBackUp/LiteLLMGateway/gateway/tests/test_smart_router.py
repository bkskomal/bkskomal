"""Verify each rule in policies.yaml routes to the expected model.

Hits the gateway end-to-end through the mock vLLM so the X-LLM-Model-Used
header reflects what LiteLLM actually called.
"""

from __future__ import annotations

import pytest

from .conftest import dev_headers


async def _post(client, body, **kw):
    return await client.post(
        "/v1/chat/completions",
        headers=dev_headers(tier=kw.pop("tier", "L2_senior"), **kw),
        json=body,
    )


@pytest.mark.asyncio
async def test_tiny_prompt_goes_to_gemma(gateway_client):
    r = await _post(gateway_client, {"messages": [
        {"role": "user", "content": "hi"},
    ]})
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "gemma-4-27b"
    # ASCII-safe header — "≤" becomes "<="
    assert "<= 100 tokens" in r.headers["X-LLM-Routing-Reason"]


@pytest.mark.asyncio
async def test_code_block_routes_to_qwen3(gateway_client):
    prompt = (
        "Refactor this function for clarity:\n"
        "```python\n"
        "def add(a, b): return a+b\n"
        "for i in range(10):\n"
        "    print(add(i, i+1))\n"
        "```\n"
        "Also explain the change."
    )
    r = await _post(gateway_client, {"messages": [
        {"role": "user", "content": prompt},
    ]})
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "qwen3-coder-30b"


@pytest.mark.asyncio
async def test_tool_use_routes_to_kimi_for_senior(gateway_client):
    body = {
        "messages": [
            {"role": "user", "content": "Plan a migration from MySQL to Postgres."},
        ],
        "tools": [{"type": "function", "function": {"name": "search_docs",
                                                    "description": "RAG search",
                                                    "parameters": {"type": "object"}}}],
    }
    r = await _post(gateway_client, body)
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "kimi-k2.6"


@pytest.mark.asyncio
async def test_default_fallback_is_qwen3(gateway_client):
    # Need a prompt > 100 tokens (heuristic = chars/4 → > 400 chars), with no
    # code blocks, no tools, and no router-triggering keywords like "refactor".
    long_prose = (
        "Walk me through the architectural trade-offs between an event-driven "
        "system using a message broker and a synchronous request-response "
        "pipeline, considering latency budgets, failure modes, observability, "
        "ordering guarantees, and how each interacts with backpressure under "
        "very high load. Imagine the service is a customer-facing payment "
        "platform that handles roughly ten thousand requests per second at "
        "peak with a strict end-to-end p99 latency requirement of 250ms. "
    )
    r = await _post(gateway_client, {"messages": [
        {"role": "user", "content": long_prose},
    ]})
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "qwen3-coder-30b"


@pytest.mark.asyncio
async def test_force_override(gateway_client):
    r = await _post(gateway_client, {
        "messages": [{"role": "user", "content": "ping"}],
        "model":    "force:gemma-4-27b",
    })
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "gemma-4-27b"
    assert "override" in r.headers["X-LLM-Routing-Reason"].lower()


@pytest.mark.asyncio
async def test_router_picks_for_auto_model(gateway_client):
    """`model: "auto"` is the no-preference sentinel — the router still picks
    based on prompt characteristics. A code-block prompt fires the code-heavy
    rule regardless of the requested name, so qwen3-coder-30b is chosen."""
    prompt = (
        "Refactor this function for clarity:\n"
        "```python\n"
        "def add(a, b): return a+b\n"
        "for i in range(10):\n"
        "    print(add(i, i+1))\n"
        "```\n"
        "Also explain the change."
    )
    r = await _post(gateway_client, {
        "messages": [{"role": "user", "content": prompt}],
        "model":    "auto",
    })
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "qwen3-coder-30b"
