"""Rate-limit + daily-budget enforcement tests.

Uses the ``test_tight`` tier from policies.yaml (rpm=3, tokens_per_day=300)
so we can exhaust limits in a handful of calls. Counters reset between
tests via the ``clean_quotas`` fixture.
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timedelta, timezone

import pytest


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


def _hdr(tier: str = "test_tight", team: str = "qa-team", user: str = "alice") -> dict[str, str]:
    return {"Authorization": f"Bearer sk-dev+{team}+{tier}+{user}",
            "Content-Type":  "application/json"}


# ---------------------------------------------------------------------------
# RPM
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_rpm_limit_returns_429(gateway_client, clean_quotas):
    body = {"messages": [{"role": "user", "content": "hi"}]}

    # tier_tight allows 3 req/min. First 3 should succeed.
    for i in range(3):
        r = await gateway_client.post("/v1/chat/completions", headers=_hdr(), json=body)
        assert r.status_code == 200, f"call {i + 1} failed: {r.status_code} {r.text}"

    # 4th trips the rate limit.
    r = await gateway_client.post("/v1/chat/completions", headers=_hdr(), json=body)
    assert r.status_code == 429, r.text
    err = r.json()["error"]
    assert err["code"] == "rate_limited"
    assert "Rate limit" in err["message"]
    # Standard rate-limit headers surfaced to the client.
    assert r.headers.get("X-RateLimit-Limit")     == "3"
    assert r.headers.get("X-RateLimit-Remaining") == "0"
    assert "X-RateLimit-Reset" in r.headers


@pytest.mark.asyncio
async def test_rpm_429_is_audited(gateway_client, clean_quotas, clean_audit_db):
    """A blocked request still lands in the audit log with the correct verdict."""
    body = {"messages": [{"role": "user", "content": "hi"}]}
    for _ in range(3):
        await gateway_client.post("/v1/chat/completions", headers=_hdr(), json=body)
    r = await gateway_client.post("/v1/chat/completions", headers=_hdr(), json=body)
    assert r.status_code == 429

    await asyncio.sleep(0.2)
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    import os
    eng = create_async_engine(os.environ["GATEWAY_AUDIT_DB_URL"], future=True)
    async with eng.begin() as conn:
        rows = (await conn.execute(text(
            "SELECT verdict FROM audit_log ORDER BY id DESC LIMIT 1"
        ))).scalars().all()
    await eng.dispose()
    # The refusal-audit path tags this as "refused" (the verdict column is
    # coarse — the precise reason lives in the findings JSON).
    assert rows == ["refused"]


# ---------------------------------------------------------------------------
# Daily token budget
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_daily_token_budget_returns_402(gateway_client, clean_quotas):
    """test_tight allows 300 tokens/day. A ~1200-char prompt = ~300 estimated
    tokens; the second call goes over and gets refused 402."""
    long_prompt = "x" * 1200          # ~300 estimated tokens
    body        = {"messages": [{"role": "user", "content": long_prompt}]}

    r = await gateway_client.post("/v1/chat/completions",
                                  headers=_hdr(user="bob1"), json=body)
    assert r.status_code == 200, r.text
    # Second call should bust the daily cap.
    r = await gateway_client.post("/v1/chat/completions",
                                  headers=_hdr(user="bob1"), json=body)
    assert r.status_code == 402, r.text
    err = r.json()["error"]
    assert err["code"] == "budget_exceeded"
    assert "X-Daily-Budget"      in r.headers
    assert "X-Daily-Budget-Used" in r.headers


@pytest.mark.asyncio
async def test_l3_privileged_has_no_daily_cap(gateway_client, clean_quotas):
    """L3 has tokens_per_day: unlimited -> the quota plugin must not block."""
    long_prompt = "x" * 4000
    body        = {"messages": [{"role": "user", "content": long_prompt}]}
    # Many bursts in one minute — RPM for L3 is 240 so 5 calls is safe.
    for _ in range(5):
        r = await gateway_client.post("/v1/chat/completions",
                                      headers=_hdr(tier="L3_privileged",
                                                   team="platform-admins"),
                                      json=body)
        assert r.status_code == 200, r.text


# ---------------------------------------------------------------------------
# JIT-elevation must NOT inflate the team's daily budget
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_elevated_user_still_bound_to_base_tier_daily_budget(
    gateway_client, clean_quotas,
):
    """A JIT-elevated user must consume against the team's CONFIGURED tier,
    not the elevated tier. Otherwise one approval silently raises the team's
    daily cap for the whole duration of the elevation — the bug security
    review flagged as Finding #6 (quota-by-tier bypass)."""
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    user = "quota_bypass_probe"
    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(hours=2)
    async with eng.begin() as conn:
        # Idempotent setup — survive prior runs.
        await conn.execute(
            text("DELETE FROM elevation_requests WHERE user_id = :u"),
            {"u": user},
        )
        await conn.execute(text("""
            INSERT INTO elevation_requests
            (user_id, user_email, team_id, base_tier, requested_tier,
             duration_minutes, reason, status, requested_at, decided_at,
             expires_at, approver_user_id)
            VALUES
            (:u, :em, 'qa-team', 'test_tight', 'L2_senior',
             120, 'kimi run', 'approved', :now, :now, :exp, 'approver')
        """), {"u": user, "em": f"{user}@dev.local",
               "now": now, "exp": expires})
    await eng.dispose()

    hdr = {"Authorization": f"Bearer sk-dev+qa-team+test_tight+{user}",
           "Content-Type":  "application/json"}
    long_prompt = "x" * 1200          # ~300 estimated tokens — fills test_tight's daily cap
    body = {"messages": [{"role": "user", "content": long_prompt}]}

    # First call consumes the full test_tight daily budget.
    r = await gateway_client.post("/v1/chat/completions", headers=hdr, json=body)
    assert r.status_code == 200, r.text

    # Second call: under L2_senior's much larger cap, this would be free —
    # but the team's BASE tier is test_tight, so the budget must be busted.
    r = await gateway_client.post("/v1/chat/completions", headers=hdr, json=body)
    assert r.status_code == 402, (
        f"quota-by-tier bypass: elevated principal consumed against the elevated "
        f"tier's cap instead of test_tight ({r.status_code} {r.text})"
    )
    assert r.json()["error"]["code"] == "budget_exceeded"


# ---------------------------------------------------------------------------
# Admin endpoints
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_admin_quotas_endpoint_shows_usage(gateway_client, clean_quotas):
    body = {"messages": [{"role": "user", "content": "hi"}]}
    await gateway_client.post("/v1/chat/completions",
                              headers=_hdr(team="backend-engineering",
                                           tier="L1_standard"),
                              json=body)
    r = await gateway_client.get("/admin/quotas", headers=MASTER)
    assert r.status_code == 200, r.text
    snap = r.json()
    assert snap["enabled"] is True
    assert "backend-engineering" in snap["teams"]
    be = snap["teams"]["backend-engineering"]
    assert be["rpm_used"]    >= 1
    assert be["tokens_today"] >= 1


@pytest.mark.asyncio
async def test_admin_can_reset_team_quota(gateway_client, clean_quotas):
    body = {"messages": [{"role": "user", "content": "hi"}]}
    # Use up two RPM hits.
    for _ in range(2):
        await gateway_client.post("/v1/chat/completions",
                                  headers=_hdr(team="reset-team", tier="test_tight"),
                                  json=body)

    # Reset.
    r = await gateway_client.post("/admin/quotas/reset-team/reset", headers=MASTER)
    assert r.status_code == 200, r.text
    assert r.json()["counters_cleared"] >= 1

    # Now we have a fresh 3-request budget again.
    for _ in range(3):
        rr = await gateway_client.post("/v1/chat/completions",
                                       headers=_hdr(team="reset-team", tier="test_tight"),
                                       json=body)
        assert rr.status_code == 200, rr.text
