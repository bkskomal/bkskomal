"""Team admin endpoint tests — create, update, delete with referential check.

The delete endpoint must refuse (409) when *active* virtual keys still point
at the team. Inactive (revoked) keys don't block delete: their bearer tokens
are already dead, so the team row is safe to drop.
"""

from __future__ import annotations

import pytest

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


# ---------------------------------------------------------------------------
# Create / update via PUT (upsert)
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_upsert_creates_new_team(gateway_client):
    r = await gateway_client.put(
        "/admin/teams/new-team-x", headers=MASTER,
        json={"team_id": "new-team-x", "tier": "L1_standard",
              "description": "QA fixture"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["team_id"]     == "new-team-x"
    assert body["tier"]        == "L1_standard"
    assert body["description"] == "QA fixture"


@pytest.mark.asyncio
async def test_upsert_clears_description_on_empty_string(gateway_client):
    """Empty-string description = clear (NULL). Behaviour the UI relies on."""
    # Create with description
    r = await gateway_client.put(
        "/admin/teams/clearable", headers=MASTER,
        json={"team_id": "clearable", "tier": "L1_standard",
              "description": "to be cleared"},
    )
    assert r.status_code == 200, r.text
    assert r.json()["description"] == "to be cleared"

    # Re-upsert with description=""
    r = await gateway_client.put(
        "/admin/teams/clearable", headers=MASTER,
        json={"team_id": "clearable", "tier": "L1_standard",
              "description": ""},
    )
    assert r.status_code == 200, r.text
    assert r.json()["description"] is None


# ---------------------------------------------------------------------------
# Delete — happy path + referential check
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_delete_unused_team(gateway_client):
    # Seed a team that has no keys.
    r = await gateway_client.put(
        "/admin/teams/expendable", headers=MASTER,
        json={"team_id": "expendable", "tier": "L0_readonly", "description": None},
    )
    assert r.status_code == 200, r.text

    r = await gateway_client.delete("/admin/teams/expendable", headers=MASTER)
    assert r.status_code == 204, r.text

    # Idempotent: deleting again returns 404 (not 5xx).
    r = await gateway_client.delete("/admin/teams/expendable", headers=MASTER)
    assert r.status_code == 404, r.text


@pytest.mark.asyncio
async def test_delete_refused_when_active_keys_present(
    gateway_client, clean_keys,
):
    """If any active key references the team, delete must 409 — not silently
    orphan a working bearer token."""
    # Use the seeded team backend-engineering and mint a fresh active key.
    r = await gateway_client.post(
        "/admin/keys", headers=MASTER,
        json={"user_id": "live-user", "team_id": "backend-engineering",
              "user_email": "live@example.com"},
    )
    assert r.status_code == 201, r.text

    r = await gateway_client.delete(
        "/admin/teams/backend-engineering", headers=MASTER,
    )
    assert r.status_code == 409, r.text
    detail = r.json()["detail"]
    assert detail["error"] == "team_has_active_keys"
    assert detail["team_id"] == "backend-engineering"
    assert detail["active_key_count"] >= 1


@pytest.mark.asyncio
async def test_delete_allowed_after_keys_revoked(
    gateway_client, clean_keys,
):
    """An inactive key doesn't count — once revoked, the team can go."""
    # Create team, mint a key, revoke it, then delete the team.
    r = await gateway_client.put(
        "/admin/teams/ephemeral-team", headers=MASTER,
        json={"team_id": "ephemeral-team", "tier": "L1_standard",
              "description": None},
    )
    assert r.status_code == 200, r.text

    r = await gateway_client.post(
        "/admin/keys", headers=MASTER,
        json={"user_id": "fleeting", "team_id": "ephemeral-team",
              "user_email": "fleeting@example.com"},
    )
    assert r.status_code == 201, r.text
    key_id = r.json()["id"]

    r = await gateway_client.delete(f"/admin/keys/{key_id}", headers=MASTER)
    assert r.status_code == 204, r.text

    # Now the team has only an inactive key — delete must succeed.
    r = await gateway_client.delete(
        "/admin/teams/ephemeral-team", headers=MASTER,
    )
    assert r.status_code == 204, r.text


# ---------------------------------------------------------------------------
# Authorisation
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_delete_team_requires_admin(gateway_client):
    r = await gateway_client.delete(
        "/admin/teams/some-team",
        headers=dev_headers(team="backend-engineering", tier="L1_standard"),
    )
    assert r.status_code == 403, r.text
