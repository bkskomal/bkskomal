"""Audit-log assertions: row written for ALLOW; row written for REFUSE.

These tests TRUNCATE litellm_gateway_audit.audit_log between cases via the
``clean_audit_db`` fixture so we can count rows precisely.
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev",
          "Content-Type":  "application/json"}


async def _audit_rows():
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    async with eng.begin() as conn:
        result = await conn.execute(text(
            "SELECT request_id, model_used, verdict, tokens_in, tokens_out "
            "FROM audit_log ORDER BY id"
        ))
        rows = result.mappings().all()
    await eng.dispose()
    return [dict(r) for r in rows]


@pytest.mark.asyncio
async def test_audit_row_written_on_allow(gateway_client, clean_audit_db):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200

    # Tiny grace — audit insert is committed inside the on_audit hook before
    # the response returns, but Postgres replication can still be marginally
    # async on tests that hit the same connection pool.
    await asyncio.sleep(0.2)

    rows = await _audit_rows()
    assert len(rows) == 1, rows
    row = rows[0]
    assert row["verdict"]    == "allow"
    assert row["model_used"] == "gemma-4-27b"
    assert row["tokens_in"]  >= 1
    assert row["tokens_out"] >= 1


@pytest.mark.asyncio
async def test_audit_row_written_on_refuse(gateway_client, clean_audit_db, monkeypatch):
    """Force a refusal via a quarantined-tier dev token (no allowed models).

    The L0_readonly tier in policies.yaml allows Gemma 4 only, so a request
    forcing Kimi would be ACL-blocked once Sprint 1 AuthZ is wired. For now,
    we trigger a router REFUSE by stubbing the router to always refuse,
    which exercises the same code path on the gateway side.
    """
    # Monkey-patch the loaded router plugin to force a refusal.
    from gateway.plugins import PluginKind, registry
    from gateway.plugins.base import HookResult, PluginVerdict, Finding

    router = registry.of_kind(PluginKind.ROUTER)[0]
    original = router.on_route_select

    async def refusing(ctx):  # noqa: ARG001
        return HookResult(
            verdict=PluginVerdict.REFUSE,
            reason="forced-refusal-for-test",
            findings=[Finding(plugin="router_rule_based",
                              kind="policy.test",
                              severity="high",
                              message="Test refusal")],
        )
    router.on_route_select = refusing
    try:
        r = await gateway_client.post(
            "/v1/chat/completions",
            headers=dev_headers(),
            json={"messages": [{"role": "user", "content": "hi"}]},
        )
        assert r.status_code == 422
        body = r.json()
        assert body["error"]["code"] == "policy_refused"
        assert "forced-refusal-for-test" in body["error"]["message"]

        await asyncio.sleep(0.2)
        rows = await _audit_rows()
        assert len(rows) == 1, rows
        assert rows[0]["verdict"] == "refused"
        assert rows[0]["tokens_in"] == 0
        assert rows[0]["tokens_out"] == 0
    finally:
        router.on_route_select = original


# ---------------------------------------------------------------------------
# /admin/audit/search — read API over the immutable audit log
# ---------------------------------------------------------------------------
async def _seed_audit_rows(rows: list[dict]) -> None:
    """Insert known rows directly into audit_log so search-filter tests are
    independent of what audit_postgres writes per request."""
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            for r in rows:
                await conn.execute(text("""
                    INSERT INTO audit_log
                        (request_id, ts, user_id, team_id, tier,
                         model_used, tokens_in, tokens_out,
                         latency_ms, cost_usd, verdict,
                         prompt_hash, response_hash,
                         prompt_ciphertext, response_ciphertext)
                    VALUES
                        (:rid, :ts, :uid, :team, :tier,
                         :model, :ti, :to_, :lat, :cost, :verdict,
                         :ph, :rh, :pct, :rct)
                """), r)
    finally:
        await eng.dispose()


@pytest.mark.asyncio
async def test_audit_search_filters_and_pagination(gateway_client, clean_audit_db):
    """Search returns only rows that match the filters, ordered newest first,
    with cursor pagination via before_id/next_cursor."""
    now = datetime.now(timezone.utc)
    base = {
        "ts":      now,
        "tier":    "L1_standard",
        "ti":      10,
        "to_":     20,
        "lat":     12.0,
        "cost":    0.001,
        "ph":      "sha256:p",
        "rh":      "sha256:r",
        "pct":     b"secret-ct-prompt",       # must NOT come back
        "rct":     b"secret-ct-response",     # must NOT come back
    }
    rows = [
        {**base, "rid": "r1", "ts": now - timedelta(minutes=4), "uid": "alice", "team": "be",     "model": "kimi-k2.6", "verdict": "allow"},
        {**base, "rid": "r2", "ts": now - timedelta(minutes=3), "uid": "bob",   "team": "be",     "model": "kimi-k2.6", "verdict": "refused"},
        {**base, "rid": "r3", "ts": now - timedelta(minutes=2), "uid": "alice", "team": "be",     "model": "qwen3",     "verdict": "allow"},
        {**base, "rid": "r4", "ts": now - timedelta(minutes=1), "uid": "alice", "team": "be",     "model": "kimi-k2.6", "verdict": "allow"},
        {**base, "rid": "r5", "ts": now,                        "uid": "carol", "team": "data",   "model": "kimi-k2.6", "verdict": "allow"},
    ]
    await _seed_audit_rows(rows)

    # 1. No filter: all 5 rows, newest first.
    r = await gateway_client.get("/admin/audit/search", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()
    ids = [row["request_id"] for row in body["rows"]]
    assert ids == ["r5", "r4", "r3", "r2", "r1"]
    assert body["next_cursor"] is None       # full page < limit

    # 2. Ciphertext NEVER returned.
    for row in body["rows"]:
        assert "prompt_ciphertext"   not in row
        assert "response_ciphertext" not in row
        assert row["prompt_hash"]   == "sha256:p"
        assert row["response_hash"] == "sha256:r"

    # 3. Filter by user_id.
    r = await gateway_client.get(
        "/admin/audit/search?user_id=alice", headers=MASTER,
    )
    assert r.status_code == 200
    ids = [row["request_id"] for row in r.json()["rows"]]
    assert ids == ["r4", "r3", "r1"]

    # 4. Filter by team + verdict.
    r = await gateway_client.get(
        "/admin/audit/search?team_id=be&verdict=refused", headers=MASTER,
    )
    assert r.status_code == 200
    ids = [row["request_id"] for row in r.json()["rows"]]
    assert ids == ["r2"]

    # 5. Cursor pagination — limit=2 produces a next_cursor; using it returns
    # the next page from where the first stopped.
    r = await gateway_client.get(
        "/admin/audit/search?limit=2", headers=MASTER,
    )
    p1 = r.json()
    assert [x["request_id"] for x in p1["rows"]] == ["r5", "r4"]
    assert p1["next_cursor"] is not None

    r = await gateway_client.get(
        f"/admin/audit/search?limit=2&before_id={p1['next_cursor']}",
        headers=MASTER,
    )
    p2 = r.json()
    assert [x["request_id"] for x in p2["rows"]] == ["r3", "r2"]


@pytest.mark.asyncio
async def test_audit_search_requires_admin(gateway_client, clean_audit_db):
    """Dev token (no admin role) gets 403 from /admin/audit/search."""
    r = await gateway_client.get(
        "/admin/audit/search", headers=dev_headers(),
    )
    assert r.status_code == 403, r.text


@pytest.mark.asyncio
async def test_audit_search_csv_export(gateway_client, clean_audit_db):
    """/admin/audit/search.csv produces a CSV with the expected header row,
    one data row per audit entry, a Content-Disposition filename, and NO
    ciphertext columns even though they're populated in the table."""
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    rows = [
        {
            "rid": f"csv-r{i}", "ts": now - timedelta(minutes=i),
            "uid": "alice", "team": "be", "tier": "L1_standard",
            "model": "kimi-k2.6", "ti": 10 + i, "to_": 20,
            "lat": 12.0, "cost": 0.001, "verdict": "allow",
            "ph": "sha256:p", "rh": "sha256:r",
            "pct": b"secret-ct-prompt", "rct": b"secret-ct-response",
        }
        for i in range(3)
    ]
    await _seed_audit_rows(rows)

    r = await gateway_client.get(
        "/admin/audit/search.csv?team_id=be", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    assert r.headers["content-type"].startswith("text/csv"), r.headers
    assert "filename=" in r.headers.get("content-disposition", "")
    assert r.headers["x-row-count"] == "3"

    csv_text = r.text
    lines = csv_text.strip().splitlines()
    assert len(lines) == 4, lines        # 1 header + 3 rows
    header = lines[0].split(",")
    assert "ts"           in header
    assert "verdict"      in header
    assert "prompt_hash"  in header
    # The two ciphertext columns must NEVER appear in the export.
    assert "prompt_ciphertext"   not in header
    assert "response_ciphertext" not in header
    # The ciphertext payload bytes must NOT appear anywhere in the body.
    assert "secret-ct-prompt"   not in csv_text
    assert "secret-ct-response" not in csv_text


@pytest.mark.asyncio
async def test_audit_search_csv_requires_admin(gateway_client, clean_audit_db):
    """Dev tokens get 403 from the CSV export endpoint, same as the JSON one."""
    r = await gateway_client.get(
        "/admin/audit/search.csv", headers=dev_headers(),
    )
    assert r.status_code == 403, r.text


# ---------------------------------------------------------------------------
# /admin/dashboard/summary — live rollup feeding the Overview page
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_dashboard_summary_rollups(gateway_client, clean_audit_db):
    """Summary returns the right counts/aggregates from seeded audit rows.

    Seeds a deterministic mix of allow / refused / DLP-flagged / secret-leak
    rows and asserts each derived field. Sanity-checks the per-minute
    timeseries length matches the requested window."""
    now = datetime.now(timezone.utc)
    base = {
        "ts": now, "tier": "L1_standard",
        "lat": 50.0, "cost": 0.0,
        "ph": "sha256:p", "rh": "sha256:r",
        "pct": None, "rct": None,
    }
    rows = [
        # 3 allow, kimi
        {**base, "rid": "a1", "ts": now - timedelta(minutes=2),  "uid": "u1", "team": "be",   "model": "kimi",  "ti": 100, "to_": 200, "verdict": "allow"},
        {**base, "rid": "a2", "ts": now - timedelta(minutes=10), "uid": "u2", "team": "be",   "model": "kimi",  "ti": 50,  "to_": 80,  "verdict": "allow"},
        {**base, "rid": "a3", "ts": now - timedelta(minutes=15), "uid": "u3", "team": "data", "model": "qwen",  "ti": 60,  "to_": 90,  "verdict": "allow"},
        # 1 refused with DLP finding
        {**base, "rid": "r1", "ts": now - timedelta(minutes=5),  "uid": "u1", "team": "be",   "model": "kimi",  "ti": 0,   "to_": 0,   "verdict": "refused"},
        # 1 secret leak (post-call)
        {**base, "rid": "s1", "ts": now - timedelta(minutes=8),  "uid": "u4", "team": "data", "model": "gemma", "ti": 30,  "to_": 50,  "verdict": "allow"},
    ]
    # Inject findings on the refused + leak rows.
    findings_for = {
        "r1": [{"plugin": "dlp_presidio", "kind": "pii.email_address",
                "severity": "high", "message": "x", "location": "prompt", "redacted": True}],
        "s1": [{"plugin": "output_scan_secrets", "kind": "secret.aws_key",
                "severity": "critical", "message": "x", "location": "response", "redacted": True}],
    }

    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    import json
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            for r in rows:
                await conn.execute(text("""
                    INSERT INTO audit_log
                        (request_id, ts, user_id, team_id, tier, model_used,
                         tokens_in, tokens_out, latency_ms, cost_usd, verdict,
                         prompt_hash, response_hash, findings,
                         prompt_ciphertext, response_ciphertext)
                    VALUES (:rid, :ts, :uid, :uid, :tier, :model,
                            :ti, :to_, :lat, :cost, :verdict,
                            :ph, :rh, :fnd, :pct, :rct)
                """), {**r, "fnd": json.dumps(findings_for.get(r["rid"]))})
    finally:
        await eng.dispose()

    r = await gateway_client.get(
        "/admin/dashboard/summary?window_minutes=60", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    s = r.json()

    assert s["request_count"]     == 5
    assert s["verdict_counts"]    == {"allow": 4, "refused": 1}
    assert s["tokens_in_total"]   == 100 + 50 + 60 + 0 + 30
    assert s["tokens_out_total"]  == 200 + 80 + 90 + 0 + 50
    assert s["dlp_findings"]      == 1   # the email_address finding
    assert s["secret_leaks"]      == 1   # the AWS key finding
    assert s["window_minutes"]    == 60
    assert len(s["timeseries"])   == 60  # densely backfilled per minute
    # Top model is kimi (3 calls)
    assert s["top_models"][0]["model"] == "kimi"
    assert s["top_models"][0]["count"] == 3


@pytest.mark.asyncio
async def test_dashboard_summary_requires_admin(gateway_client, clean_audit_db):
    """Dev token gets 403 from /admin/dashboard/summary."""
    r = await gateway_client.get(
        "/admin/dashboard/summary", headers=dev_headers(),
    )
    assert r.status_code == 403, r.text
