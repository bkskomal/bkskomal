"""Smart Router admin endpoints — integration tests.

Covers:
  * GET /admin/router/rules     — live rules from app.state.policies
  * GET /admin/router/usage     — per-model counts + per-user override-rate

The rules endpoint reads from the merged policies dict that was loaded from
``gateway/tests/_test_policies.yaml`` at app startup, so we cross-check the
API against the YAML on disk (rather than hard-coding a count that would
drift the next time someone edits the test policies).

The usage endpoint reads straight off ``audit_log`` so we seed deterministic
rows the same way ``test_audit.py`` does — bypassing the audit_postgres hook
keeps these tests independent of the request pipeline.
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
import yaml
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev",
          "Content-Type":  "application/json"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_TEST_POLICIES_PATH = Path(__file__).parent / "_test_policies.yaml"


def _load_test_policy_rules() -> list[dict]:
    """Read the test policies file and return its router_rules list."""
    with _TEST_POLICIES_PATH.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    rules = data.get("router_rules") or []
    assert isinstance(rules, list), f"router_rules must be a list, got {type(rules)}"
    return rules


async def _seed_audit_rows(rows: list[dict]) -> None:
    """Insert audit_log rows directly. Same shape as the helper in
    test_audit.py but extended to populate ``model_requested`` (and a
    per-row ``ts``) since the router-usage endpoint pivots on both."""
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            for r in rows:
                await conn.execute(text("""
                    INSERT INTO audit_log
                        (request_id, ts, user_id, team_id, tier,
                         model_requested, model_used,
                         tokens_in, tokens_out,
                         latency_ms, cost_usd, verdict,
                         prompt_hash, response_hash,
                         prompt_ciphertext, response_ciphertext)
                    VALUES
                        (:rid, :ts, :uid, :team, :tier,
                         :mreq, :mused, :ti, :to_, :lat, :cost, :verdict,
                         :ph, :rh, :pct, :rct)
                """), r)
    finally:
        await eng.dispose()


def _base_row(**overrides) -> dict:
    """Default audit-row template; override per call site as needed."""
    base = {
        "rid":     "r",
        "ts":      datetime.now(timezone.utc),
        "uid":     "alice",
        "team":    "backend-engineering",
        "tier":    "L1_standard",
        "mreq":    None,
        "mused":   "gemma-4-27b",
        "ti":      10,
        "to_":     20,
        "lat":     12.0,
        "cost":    0.001,
        "verdict": "allow",
        "ph":      "sha256:p",
        "rh":      "sha256:r",
        "pct":     None,
        "rct":     None,
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# GET /admin/router/rules
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_router_rules_returns_test_yaml_rules(gateway_client):
    """API exposes every router rule from the live policies dict, with the
    source pinned to "policies.yaml". Cross-check against the YAML file
    itself so the assertion can't drift when someone adds a rule."""
    yaml_rules = _load_test_policy_rules()
    assert len(yaml_rules) >= 5, "Test policy file must define >= 5 rules"

    r = await gateway_client.get("/admin/router/rules", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()

    assert body["source"] == "policies.yaml"
    assert body["count"]  == len(yaml_rules)
    assert len(body["rules"]) == len(yaml_rules)

    # Find a known rule by name and assert its `route` matches the YAML.
    target_name = "Tiny prompts -> cheapest"
    yaml_target = next(
        (r for r in yaml_rules if r.get("name") == target_name), None,
    )
    assert yaml_target is not None, (
        f"YAML must contain rule {target_name!r}; got "
        f"{[r.get('name') for r in yaml_rules]}"
    )
    api_target = next(
        (r for r in body["rules"] if r["name"] == target_name), None,
    )
    assert api_target is not None, body["rules"]
    assert api_target["route"] == yaml_target["route"]


@pytest.mark.asyncio
async def test_router_rules_extra_fields_passthrough(gateway_client):
    """Rule keys beyond {name, when, route, reason} get hoisted into ``extra``
    so the UI can render them as JSON badges. The "Tool-use / agent" rule has
    a ``fallback_if_tier_blocks`` and the DLP rule has ``force_self_host`` —
    either is fine, we just need at least one rule with non-empty extras."""
    r = await gateway_client.get("/admin/router/rules", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()

    rules_with_extras = [r for r in body["rules"] if r.get("extra")]
    assert rules_with_extras, (
        "Expected at least one rule to expose passthrough fields under "
        f"`extra`. Got rules: {body['rules']}"
    )

    # The extras must not be nested inside `when` — they're top-level rule keys.
    for rule in rules_with_extras:
        for key in rule["extra"].keys():
            assert key not in rule["when"], (
                f"Rule {rule['name']!r}: extras key {key!r} leaked into `when`"
            )

    # Spot-check: at least one of the well-known extras exists somewhere.
    all_extra_keys: set[str] = set()
    for rule in rules_with_extras:
        all_extra_keys |= set(rule["extra"].keys())
    assert (
        "fallback_if_tier_blocks" in all_extra_keys
        or "force_self_host"      in all_extra_keys
    ), all_extra_keys


# ---------------------------------------------------------------------------
# GET /admin/router/usage
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_router_usage_with_no_traffic(gateway_client, clean_audit_db):
    """Empty audit table → empty rollups, zero totals."""
    r = await gateway_client.get("/admin/router/usage", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["per_model"]       == []
    assert body["top_overriders"]  == []
    assert body["overrides_total"] == 0
    assert body["requests_total"]  == 0
    assert body["window_minutes"]  == 60


@pytest.mark.asyncio
async def test_router_usage_per_model_counts(gateway_client, clean_audit_db):
    """per_model groups by model_used and ranks by count desc."""
    now = datetime.now(timezone.utc)
    rows = [
        _base_row(rid="g1", ts=now - timedelta(minutes=1), mused="gemma-4-27b"),
        _base_row(rid="g2", ts=now - timedelta(minutes=2), mused="gemma-4-27b"),
        _base_row(rid="g3", ts=now - timedelta(minutes=3), mused="gemma-4-27b"),
        _base_row(rid="q1", ts=now - timedelta(minutes=4), mused="qwen3-coder-30b"),
        _base_row(rid="q2", ts=now - timedelta(minutes=5), mused="qwen3-coder-30b"),
    ]
    await _seed_audit_rows(rows)

    r = await gateway_client.get("/admin/router/usage", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()

    assert body["requests_total"] == 5
    assert len(body["per_model"]) == 2

    # Top model by count must be gemma (3 vs 2).
    assert body["per_model"][0]["model"] == "gemma-4-27b"
    assert body["per_model"][0]["count"] == 3

    by_model = {m["model"]: m for m in body["per_model"]}
    assert by_model["qwen3-coder-30b"]["count"] == 2
    # tokens = sum(tokens_in + tokens_out) per model. Each seeded row has 10+20=30.
    assert by_model["gemma-4-27b"]["tokens"]    == 3 * 30
    assert by_model["qwen3-coder-30b"]["tokens"] == 2 * 30


@pytest.mark.asyncio
async def test_router_usage_overrides_detected(gateway_client, clean_audit_db):
    """Override-rate logic: count only rows where model_requested is a real
    model name (not NULL / "" / "auto") and compare to model_used."""
    now = datetime.now(timezone.utc)
    rows = [
        # alice: 3/3 overrides (asked kimi, got gemma each time)
        _base_row(rid="a1", ts=now - timedelta(minutes=1),
                  uid="alice", mreq="kimi-k2.6", mused="gemma-4-27b"),
        _base_row(rid="a2", ts=now - timedelta(minutes=2),
                  uid="alice", mreq="kimi-k2.6", mused="gemma-4-27b"),
        _base_row(rid="a3", ts=now - timedelta(minutes=3),
                  uid="alice", mreq="kimi-k2.6", mused="gemma-4-27b"),
        # alice: model_requested NULL — must not contribute to total/overrides.
        _base_row(rid="a4", ts=now - timedelta(minutes=4),
                  uid="alice", mreq=None, mused="gemma-4-27b"),
        # alice: "auto" — must not contribute either.
        _base_row(rid="a5", ts=now - timedelta(minutes=5),
                  uid="alice", mreq="auto", mused="gemma-4-27b"),
        # bob: 0/2 overrides (got what was asked)
        _base_row(rid="b1", ts=now - timedelta(minutes=6),
                  uid="bob", mreq="qwen3-coder-30b", mused="qwen3-coder-30b"),
        _base_row(rid="b2", ts=now - timedelta(minutes=7),
                  uid="bob", mreq="qwen3-coder-30b", mused="qwen3-coder-30b"),
        # bob: 1/1 override → bob's final ratio is 1/3
        _base_row(rid="b3", ts=now - timedelta(minutes=8),
                  uid="bob", mreq="kimi-k2.6", mused="gemma-4-27b"),
    ]
    await _seed_audit_rows(rows)

    r = await gateway_client.get("/admin/router/usage", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()

    by_user = {u["user_id"]: u for u in body["top_overriders"]}
    assert "alice" in by_user, body["top_overriders"]
    assert "bob"   in by_user, body["top_overriders"]

    assert by_user["alice"]["total"]         == 3
    assert by_user["alice"]["overrides"]     == 3
    assert by_user["alice"]["override_rate"] == 1.0

    assert by_user["bob"]["total"]     == 3
    assert by_user["bob"]["overrides"] == 1
    assert by_user["bob"]["override_rate"] == pytest.approx(1 / 3, abs=1e-3)

    # Alice ranks above Bob — higher override_rate.
    assert body["top_overriders"][0]["user_id"] == "alice"

    # Total overrides across all users (alice 3 + bob 1).
    assert body["overrides_total"] == 4


@pytest.mark.asyncio
async def test_router_usage_window_minutes_filter(gateway_client, clean_audit_db):
    """window_minutes filters rows by `ts >= now - window`."""
    now = datetime.now(timezone.utc)
    rows = [
        _base_row(rid="recent",  ts=now - timedelta(minutes=30), mused="gemma-4-27b"),
        _base_row(rid="oldish",  ts=now - timedelta(minutes=90), mused="gemma-4-27b"),
    ]
    await _seed_audit_rows(rows)

    # 60-minute window only sees the row from 30min ago.
    r = await gateway_client.get(
        "/admin/router/usage?window_minutes=60", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["window_minutes"] == 60
    assert body["requests_total"] == 1
    assert len(body["per_model"]) == 1
    assert body["per_model"][0]["model"] == "gemma-4-27b"
    assert body["per_model"][0]["count"] == 1

    # 120-minute window sees both rows — same model collapses to count=2.
    r = await gateway_client.get(
        "/admin/router/usage?window_minutes=120", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["window_minutes"] == 120
    assert body["requests_total"] == 2
    assert len(body["per_model"]) == 1
    assert body["per_model"][0]["model"] == "gemma-4-27b"
    assert body["per_model"][0]["count"] == 2


# ---------------------------------------------------------------------------
# Admin-only enforcement
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_router_rules_requires_admin(gateway_client):
    r = await gateway_client.get("/admin/router/rules", headers=dev_headers())
    assert r.status_code == 403, r.text


@pytest.mark.asyncio
async def test_router_usage_requires_admin(gateway_client):
    r = await gateway_client.get("/admin/router/usage", headers=dev_headers())
    assert r.status_code == 403, r.text


# ---------------------------------------------------------------------------
# PATCH /admin/router/rules/{rule_name} — enable/disable + route_override
# ---------------------------------------------------------------------------
_TOGGLE_RULE = "Tiny prompts -> cheapest"


def _find_rule(body: dict, name: str) -> dict:
    for r in body["rules"]:
        if r["name"] == name:
            return r
    raise AssertionError(f"Rule {name!r} not in GET response; got "
                         f"{[r['name'] for r in body['rules']]}")


@pytest.mark.asyncio
async def test_router_rule_override_toggle(gateway_client, clean_router_overrides):
    """PATCH a rule disabled, GET confirms enabled=false, then re-enable."""
    # Sanity: the rule defaults to enabled.
    r = await gateway_client.get("/admin/router/rules", headers=MASTER)
    assert r.status_code == 200, r.text
    rule = _find_rule(r.json(), _TOGGLE_RULE)
    assert rule["enabled"] is True
    assert rule["route_override"] is None

    # Disable it.
    r = await gateway_client.patch(
        f"/admin/router/rules/{_TOGGLE_RULE}",
        headers=MASTER, json={"enabled": False},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["name"]    == _TOGGLE_RULE
    assert body["enabled"] is False
    assert body["route_override"] is None

    # GET confirms persistence.
    r = await gateway_client.get("/admin/router/rules", headers=MASTER)
    assert r.status_code == 200, r.text
    rule = _find_rule(r.json(), _TOGGLE_RULE)
    assert rule["enabled"] is False

    # Re-enable; final state must match the YAML default.
    r = await gateway_client.patch(
        f"/admin/router/rules/{_TOGGLE_RULE}",
        headers=MASTER, json={"enabled": True},
    )
    assert r.status_code == 200, r.text
    assert r.json()["enabled"] is True

    r = await gateway_client.get("/admin/router/rules", headers=MASTER)
    rule = _find_rule(r.json(), _TOGGLE_RULE)
    assert rule["enabled"] is True


@pytest.mark.asyncio
async def test_router_rule_route_override(gateway_client, clean_router_overrides):
    """PATCH route_override to a known model, GET confirms; clear works too."""
    # Pick a target that's not the rule's YAML default — the test policies
    # ship "Tiny prompts -> cheapest" with route=gemma-4-27b, so override it
    # to qwen3-coder-30b (also in the registry).
    target = "qwen3-coder-30b"

    r = await gateway_client.patch(
        f"/admin/router/rules/{_TOGGLE_RULE}",
        headers=MASTER, json={"route_override": target},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["route_override"] == target
    # The YAML `route` is preserved so the UI can render "was X, now Y".
    assert body["route"] == "gemma-4-27b"

    r = await gateway_client.get("/admin/router/rules", headers=MASTER)
    rule = _find_rule(r.json(), _TOGGLE_RULE)
    assert rule["route_override"] == target
    assert rule["route"]          == "gemma-4-27b"

    # Clear the override by PATCHing explicit null.
    r = await gateway_client.patch(
        f"/admin/router/rules/{_TOGGLE_RULE}",
        headers=MASTER, json={"route_override": None},
    )
    assert r.status_code == 200, r.text
    assert r.json()["route_override"] is None

    r = await gateway_client.get("/admin/router/rules", headers=MASTER)
    rule = _find_rule(r.json(), _TOGGLE_RULE)
    assert rule["route_override"] is None


@pytest.mark.asyncio
async def test_router_rule_override_unknown_model_returns_404(
    gateway_client, clean_router_overrides,
):
    """A route_override pointing at a model NOT in the registry must 404."""
    r = await gateway_client.patch(
        f"/admin/router/rules/{_TOGGLE_RULE}",
        headers=MASTER, json={"route_override": "not-a-model"},
    )
    assert r.status_code == 404, r.text
    assert "not-a-model" in r.text


@pytest.mark.asyncio
async def test_router_disabled_rule_not_evaluated(
    gateway_client, clean_router_overrides,
):
    """Disable the "Tiny prompts" rule — a tiny prompt that would have
    matched it must fall through to the NEXT matching rule.

    Without any override, "hi" is short enough to match
    ``Tiny prompts -> cheapest`` (route=gemma-4-27b). With that rule
    disabled, the chain proceeds to "Code-heavy refactor", which fails
    (no code blocks / refactor keywords), then "Tool-use / agent" (no
    tools), then "DLP-flagged prompts NEVER leave the network" (no DLP
    findings), then "Budget > 80% used" (under budget), then "Default
    fallback" → qwen3-coder-30b.
    """
    # Baseline: tiny prompt routes to gemma.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(tier="L2_senior"),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "gemma-4-27b"

    # Disable the rule.
    r = await gateway_client.patch(
        f"/admin/router/rules/{_TOGGLE_RULE}",
        headers=MASTER, json={"enabled": False},
    )
    assert r.status_code == 200, r.text

    # Re-issue the same tiny prompt: it must now skip the disabled rule
    # and fall through to the default fallback (qwen3-coder-30b).
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(tier="L2_senior"),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "qwen3-coder-30b"
