"""Response-cache plugin tests.

Verifies the cache_redis plugin:
  1. miss-then-hit on identical prompts via the gateway endpoint
  2. cache keys do NOT leak across teams
  3. streaming requests cache too — miss-then-hit, both delivered as SSE
  4. streaming cache is namespace-isolated from the non-streaming cache
     (a non-streaming HIT must never be served as SSE and vice versa)
  5. streaming cross-team isolation (per team_id, like non-streaming)
  6. high-temperature requests skip the cache (non-deterministic) for
     both streaming and non-streaming variants

The cache uses the in-memory store under tests (GATEWAY_REDIS_URL=memory://).
A fresh fixture wipes its state between tests so each test starts cold.
"""

from __future__ import annotations

import pytest
import pytest_asyncio

from .conftest import dev_headers


# ---------------------------------------------------------------------------
# Per-test cache cleaner — start every test from an empty store.
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def clean_cache():
    from gateway.plugins import registry
    plugin = registry.get("cache_redis")
    if plugin is not None and getattr(plugin, "_store", None) is not None:
        store = plugin._store
        # In-memory backend exposes _values / _expiry directly; tests run
        # against the memory store so this is enough.
        if hasattr(store, "_values"):
            store._values.clear()
            store._expiry.clear()
    yield


# ---------------------------------------------------------------------------
# 1. Cache miss then hit — identical prompts return the same body.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_cache_miss_then_hit_via_gateway(gateway_client, clean_cache,
                                               clean_audit_db, clean_quotas):
    body = {
        "messages":    [{"role": "user", "content": "cache me please"}],
        "max_tokens":  8,
        "temperature": 0,
    }

    r1 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r1.status_code == 200, r1.text
    # First call must be a MISS (header absent OR explicitly "MISS").
    assert r1.headers.get("x-cache", "MISS") == "MISS", r1.headers

    r2 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r2.status_code == 200, r2.text
    assert r2.headers.get("x-cache") == "HIT", r2.headers

    # Bodies must be byte-identical — that's the whole point of the cache.
    assert r2.json() == r1.json()


# ---------------------------------------------------------------------------
# 2. Per-team isolation — same prompt under team B is a fresh MISS.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_cache_does_not_serve_across_teams(gateway_client, clean_cache,
                                                 clean_audit_db, clean_quotas):
    body = {
        "messages":    [{"role": "user", "content": "isolate me"}],
        "max_tokens":  8,
        "temperature": 0,
    }

    # Team A primes the cache.
    r_a1 = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(team="backend-engineering"), json=body,
    )
    assert r_a1.status_code == 200, r_a1.text

    r_a2 = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(team="backend-engineering"), json=body,
    )
    assert r_a2.status_code == 200
    assert r_a2.headers.get("x-cache") == "HIT", r_a2.headers

    # Team B sends the same prompt — different cache key, must be a MISS.
    r_b1 = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(team="platform-admins", tier="L3_privileged"),
        json=body,
    )
    assert r_b1.status_code == 200, r_b1.text
    assert r_b1.headers.get("x-cache", "MISS") == "MISS", r_b1.headers


# ---------------------------------------------------------------------------
# 3. Streaming cache: miss-then-hit via the gateway endpoint.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_streaming_cache_miss_then_hit_via_gateway(
        gateway_client, clean_cache, clean_audit_db, clean_quotas):
    body = {
        "messages":    [{"role": "user", "content": "stream cache me"}],
        "max_tokens":  5,
        "temperature": 0,
        "stream":      True,
    }

    r1 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r1.status_code == 200, r1.text
    assert r1.headers.get("content-type", "").startswith("text/event-stream")
    # First call: NOT a HIT. The header may be absent or explicitly MISS.
    assert r1.headers.get("x-cache", "MISS") == "MISS", r1.headers
    body1 = r1.text
    assert "data: " in body1, body1[:200]
    assert "data: [DONE]" in body1, body1[-200:]

    r2 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r2.status_code == 200, r2.text
    # Second call must still be SSE — never a JSON dump of the cached array.
    assert r2.headers.get("content-type", "").startswith("text/event-stream"), (
        r2.headers
    )
    assert r2.headers.get("x-cache") == "HIT", r2.headers
    body2 = r2.text
    assert "data: " in body2, body2[:200]
    assert "data: [DONE]" in body2, body2[-200:]


# ---------------------------------------------------------------------------
# 4. Streaming cache: cross-team isolation.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_streaming_cache_does_not_serve_across_teams(
        gateway_client, clean_cache, clean_audit_db, clean_quotas):
    body = {
        "messages":    [{"role": "user", "content": "stream isolate me"}],
        "max_tokens":  5,
        "temperature": 0,
        "stream":      True,
    }

    # Team A primes the stream cache.
    r_a1 = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(team="backend-engineering"), json=body,
    )
    assert r_a1.status_code == 200, r_a1.text
    _ = r_a1.text  # drain so the post-call store fires

    r_a2 = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(team="backend-engineering"), json=body,
    )
    assert r_a2.status_code == 200
    assert r_a2.headers.get("x-cache") == "HIT", r_a2.headers
    _ = r_a2.text

    # Team B sends the same prompt — different cache key, must be a MISS.
    r_b1 = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(team="platform-admins", tier="L3_privileged"),
        json=body,
    )
    assert r_b1.status_code == 200, r_b1.text
    assert r_b1.headers.get("x-cache", "MISS") == "MISS", r_b1.headers


# ---------------------------------------------------------------------------
# 5. Streaming cache namespace is separate from the non-streaming cache.
#    A non-streaming HIT must not be replayed as SSE and vice versa.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_streaming_cache_namespace_separated_from_nonstreaming(
        gateway_client, clean_cache, clean_audit_db, clean_quotas):
    base_body = {
        "messages":    [{"role": "user", "content": "namespace check"}],
        "max_tokens":  5,
        "temperature": 0,
    }

    # 1. Prime the non-streaming cache under cache:resp:<sha>.
    r_ns = await gateway_client.post("/v1/chat/completions",
                                     headers=dev_headers(), json=base_body)
    assert r_ns.status_code == 200, r_ns.text
    assert r_ns.headers.get("x-cache", "MISS") == "MISS", r_ns.headers

    # 2. Now stream the EXACT same prompt — must be a MISS (different
    #    namespace), NOT a hit on the non-streaming entry.
    stream_body = {**base_body, "stream": True}
    r_s1 = await gateway_client.post("/v1/chat/completions",
                                     headers=dev_headers(), json=stream_body)
    assert r_s1.status_code == 200, r_s1.text
    assert r_s1.headers.get("content-type", "").startswith("text/event-stream")
    assert r_s1.headers.get("x-cache", "MISS") == "MISS", r_s1.headers
    _ = r_s1.text  # drain so store_stream runs

    # 3. Second streaming call → now a HIT (stream namespace is now warm).
    r_s2 = await gateway_client.post("/v1/chat/completions",
                                     headers=dev_headers(), json=stream_body)
    assert r_s2.status_code == 200
    assert r_s2.headers.get("content-type", "").startswith("text/event-stream")
    assert r_s2.headers.get("x-cache") == "HIT", r_s2.headers


# ---------------------------------------------------------------------------
# 6. Streaming cache skipped for high temperature (non-deterministic).
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_streaming_cache_skipped_for_high_temperature(
        gateway_client, clean_cache, clean_audit_db, clean_quotas):
    body = {
        "messages":    [{"role": "user", "content": "hot stream"}],
        "max_tokens":  5,
        "temperature": 0.7,
        "stream":      True,
    }

    r1 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r1.status_code == 200, r1.text
    # Not cacheable → X-Cache header omitted entirely.
    assert r1.headers.get("x-cache") is None, r1.headers
    _ = r1.text

    r2 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r2.status_code == 200
    assert r2.headers.get("x-cache") is None, r2.headers


# ---------------------------------------------------------------------------
# 7. High-temperature non-streaming requests skip the cache (unchanged).
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_cache_skipped_for_high_temperature(gateway_client, clean_cache,
                                                  clean_audit_db, clean_quotas):
    body = {
        "messages":    [{"role": "user", "content": "hot take please"}],
        "max_tokens":  8,
        "temperature": 0.7,
    }

    r1 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r1.status_code == 200, r1.text
    # When the request isn't cacheable the X-Cache header is omitted entirely.
    assert r1.headers.get("x-cache") is None, r1.headers

    r2 = await gateway_client.post("/v1/chat/completions",
                                   headers=dev_headers(), json=body)
    assert r2.status_code == 200
    assert r2.headers.get("x-cache") is None, r2.headers
