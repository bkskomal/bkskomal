"""Smoke tests for /health, /ready and auth gating."""

from __future__ import annotations

import pytest

from .conftest import dev_headers


@pytest.mark.asyncio
async def test_health_returns_ok(gateway_client):
    r = await gateway_client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "version": "0.1.0"}


@pytest.mark.asyncio
async def test_ready_lists_plugins(gateway_client):
    r = await gateway_client.get("/ready")
    assert r.status_code == 200
    data = r.json()
    assert data["ready"] is True
    assert "router_rule_based" in data["loaded_plugins"]
    assert "audit_postgres"    in data["loaded_plugins"]


@pytest.mark.asyncio
async def test_chat_requires_auth(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 401


@pytest.mark.asyncio
async def test_chat_rejects_bad_token(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={"Authorization": "Bearer not-a-real-key",
                 "Content-Type": "application/json"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 401


@pytest.mark.asyncio
async def test_admin_endpoints_need_master_key(gateway_client):
    # A normal dev token should be rejected from /admin/*
    r = await gateway_client.get("/admin/plugins", headers=dev_headers())
    assert r.status_code == 403

    # Master key works.
    r = await gateway_client.get("/admin/plugins",
                                 headers={"Authorization": "Bearer sk-master-dev"})
    assert r.status_code == 200
    names = {p["name"] for p in r.json()["plugins"]}
    assert "router_rule_based" in names
    assert "audit_postgres" in names
