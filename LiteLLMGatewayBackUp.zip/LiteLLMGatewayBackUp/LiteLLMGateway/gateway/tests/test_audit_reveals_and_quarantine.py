"""Audit at-rest encryption + 4-eyes reveal flow + UEBA baseline + auto-quarantine.

Covers four newly-landed slices of the security backend:

  1. ``gateway.crypto`` AES-GCM helper — round-trip + disabled-mode behaviour.
  2. The ``audit_postgres`` plugin's ciphertext columns — populated only when
     ``GATEWAY_AUDIT_KEY`` is set.
  3. The ``/admin/audit/.../reveal-requests`` 4-eyes flow — request, approve,
     deny, single-use plaintext fetch with dual-control invariants.
  4. ``/admin/ueba/user/{id}/baseline`` per-user behavioural baseline.
  5. Auto-quarantine: ≥3 critical UEBA signals in a day flips ALL of the
     user's virtual_keys to ``is_active=false``; ``/admin/ueba/.../restore-keys``
     re-arms them.

State cleanup
-------------
The conftest ``wipe_gateway_db`` fixture drops ``audit_reveal_requests`` once
at session start, after which the gateway's lifespan re-creates it. This
module ships its own ``clean_reveals`` fixture to TRUNCATE between tests so
ID ordering is deterministic.

Crypto cache hygiene: ``crypto._reset_cache_for_tests()`` MUST be called both
when the env var is set AND when it is unset, otherwise the cached key from
one test bleeds into the next. The ``audit_key_set`` / ``audit_key_unset``
fixtures handle this paired setup-and-teardown.
"""

from __future__ import annotations

import asyncio
import base64
import os
from datetime import datetime, timezone

import pytest
import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev",
          "Content-Type":  "application/json"}

# Deterministic 32-byte key — base64url-encoded — so tests don't fight nondet.
TEST_AUDIT_KEY = base64.urlsafe_b64encode(b"\xab" * 32).decode()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def clean_reveals():
    """Truncate audit_reveal_requests + audit_log between tests.

    audit_reveal_requests holds the 4-eyes lifecycle rows; audit_log is the
    target the reveal flow reads ciphertext from. Both must be deterministic
    so an ID minted in one test doesn't surface in the next.
    """
    op_dsn    = os.environ["GATEWAY_DB_URL"]
    audit_dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    op_eng    = create_async_engine(op_dsn,    future=True)
    audit_eng = create_async_engine(audit_dsn, future=True)
    async with op_eng.begin() as conn:
        await conn.execute(text(
            "TRUNCATE TABLE audit_reveal_requests RESTART IDENTITY"
        ))
    async with audit_eng.begin() as conn:
        await conn.execute(text("TRUNCATE TABLE audit_log RESTART IDENTITY"))
    yield
    await op_eng.dispose()
    await audit_eng.dispose()


@pytest.fixture
def audit_key_set(monkeypatch):
    """Set GATEWAY_AUDIT_KEY for the duration of the test, with paired
    crypto-cache resets at BOTH setup and teardown.

    Without the teardown reset, the next test that runs without this fixture
    would still see encryption enabled because crypto._cached_key sticks.
    """
    from gateway import crypto
    monkeypatch.setenv("GATEWAY_AUDIT_KEY", TEST_AUDIT_KEY)
    crypto._reset_cache_for_tests()
    yield TEST_AUDIT_KEY
    crypto._reset_cache_for_tests()


@pytest.fixture
def audit_key_unset(monkeypatch):
    """Pop GATEWAY_AUDIT_KEY for the duration of the test, paired resets."""
    from gateway import crypto
    monkeypatch.delenv("GATEWAY_AUDIT_KEY", raising=False)
    crypto._reset_cache_for_tests()
    yield
    crypto._reset_cache_for_tests()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
async def _drive_completion(client, *, headers=None, prompt: str = "hi"):
    if headers is None:
        headers = dev_headers()
    return await client.post(
        "/v1/chat/completions",
        headers=headers,
        json={"messages": [{"role": "user", "content": prompt}]},
    )


async def _audit_rows() -> list[dict]:
    """Read the audit_log including the ciphertext columns directly.

    The /admin/audit/search API never returns ciphertext (security tightening),
    so for ciphertext-presence assertions we have to query the table itself.
    """
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            res = await conn.execute(text(
                "SELECT id, request_id, user_id, prompt_ciphertext, "
                "response_ciphertext FROM audit_log ORDER BY id"
            ))
            return [dict(r) for r in res.mappings().all()]
    finally:
        await eng.dispose()


async def _mint_admin_key(client, *, user_id: str, team_id: str = "backend-engineering"):
    r = await client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id":    user_id,
              "team_id":    team_id,
              "role":       "admin",
              "user_email": f"{user_id}@example.com"},
    )
    assert r.status_code == 201, r.text
    raw = r.json()["raw_key"]
    return {"Authorization": f"Bearer {raw}",
            "Content-Type":  "application/json"}


# ===========================================================================
# 1. Crypto helper — round-trip + disabled mode
# ===========================================================================
@pytest.mark.asyncio
async def test_crypto_round_trip_with_key(audit_key_set):
    """encrypt() returns a versioned blob; decrypt() restores the plaintext."""
    from gateway import crypto

    assert crypto.is_enabled() is True
    plaintext = b"hello secret"
    blob = crypto.encrypt(plaintext)
    assert blob is not None
    # Wire format: 1-byte version + 12-byte nonce + ciphertext+tag(>=16).
    assert len(blob) >= 1 + 12 + 16
    assert blob[0] == crypto.VERSION_BYTE_AESGCM
    # Round-trip.
    assert crypto.decrypt(blob) == plaintext


@pytest.mark.asyncio
async def test_crypto_disabled_when_key_unset(audit_key_unset):
    """is_enabled() False, encrypt() returns None — clean no-op."""
    from gateway import crypto

    assert crypto.is_enabled() is False
    assert crypto.encrypt(b"x") is None


# ===========================================================================
# 2. Audit_postgres ciphertext columns — keyed vs unkeyed
# ===========================================================================
@pytest.mark.asyncio
async def test_audit_postgres_encrypts_when_key_set(
    gateway_client, clean_reveals, audit_key_set,
):
    """With a key set, prompt_ciphertext is populated and round-trips back to
    a string containing the original prompt."""
    from gateway import crypto

    prompt = "encrypt-me-please-marker-xyz123"
    r = await _drive_completion(gateway_client, prompt=prompt)
    assert r.status_code == 200, r.text
    await asyncio.sleep(0.2)

    rows = await _audit_rows()
    assert len(rows) == 1, rows
    blob = rows[0]["prompt_ciphertext"]
    assert blob is not None, "ciphertext column should be populated when key is set"
    # decrypt() returns the canonical-messages JSON; the prompt body is in there.
    decoded = crypto.decrypt(bytes(blob)).decode("utf-8")
    assert prompt in decoded, decoded


@pytest.mark.asyncio
async def test_audit_postgres_no_ciphertext_when_key_unset(
    gateway_client, clean_reveals, audit_key_unset,
):
    """Without a key, ciphertext columns must remain NULL."""
    r = await _drive_completion(gateway_client, prompt="not-encrypted")
    assert r.status_code == 200, r.text
    await asyncio.sleep(0.2)

    rows = await _audit_rows()
    assert len(rows) == 1, rows
    assert rows[0]["prompt_ciphertext"]   is None
    assert rows[0]["response_ciphertext"] is None


# ===========================================================================
# 3. Reveal flow — happy path + dual-control invariants
# ===========================================================================
async def _seed_audit_row_and_request(
    client, *, requester_hdr, prompt: str = "secret prompt",
) -> tuple[int, int]:
    """Drive a chat completion (which writes one audit_log row), then open a
    reveal request as ``requester_hdr``. Returns (audit_log_id, reveal_id)."""
    r = await _drive_completion(client, prompt=prompt)
    assert r.status_code == 200, r.text
    await asyncio.sleep(0.2)

    rows = await _audit_rows()
    assert rows, "expected one audit_log row"
    audit_log_id = rows[-1]["id"]

    r = await client.post(
        f"/admin/audit/{audit_log_id}/reveal-requests",
        headers=requester_hdr,
        json={"reason": "incident IR-1234"},
    )
    assert r.status_code == 201, r.text
    reveal_id = r.json()["id"]
    return audit_log_id, reveal_id


@pytest.mark.asyncio
async def test_reveal_full_happy_path(
    gateway_client, clean_reveals, clean_keys, audit_key_set,
):
    """admin_a opens a request, admin_b approves, admin_a fetches plaintext."""
    admin_a = await _mint_admin_key(gateway_client, user_id="reveal_a")
    admin_b = await _mint_admin_key(gateway_client, user_id="reveal_b")

    audit_log_id, reveal_id = await _seed_audit_row_and_request(
        gateway_client, requester_hdr=admin_a, prompt="happy-path-marker",
    )

    # Different admin approves.
    r = await gateway_client.post(
        f"/admin/audit/reveal-requests/{reveal_id}/approve",
        headers=admin_b,
        json={"decision_note": "approved for IR-1234"},
    )
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "approved"

    # Original requester fetches the decrypted plaintext.
    r = await gateway_client.get(
        f"/admin/audit/reveal-requests/{reveal_id}/reveal",
        headers=admin_a,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["request"]["status"] == "revealed"
    assert body["plaintext"]["prompt"], body
    assert body["plaintext"]["response"], body
    # The marker we sent is preserved in the decrypted prompt blob.
    assert "happy-path-marker" in body["plaintext"]["prompt"]


@pytest.mark.asyncio
async def test_reveal_self_approve_is_403(
    gateway_client, clean_reveals, clean_keys, audit_key_set,
):
    """The requester cannot approve their own reveal request."""
    admin_a = await _mint_admin_key(gateway_client, user_id="reveal_self")

    _, reveal_id = await _seed_audit_row_and_request(
        gateway_client, requester_hdr=admin_a,
    )

    r = await gateway_client.post(
        f"/admin/audit/reveal-requests/{reveal_id}/approve",
        headers=admin_a,
        json={"decision_note": "self approve attempt"},
    )
    assert r.status_code == 403, r.text


@pytest.mark.asyncio
async def test_reveal_pre_approval_returns_409(
    gateway_client, clean_reveals, clean_keys, audit_key_set,
):
    """GET /reveal on a still-pending request fails with 409 InvalidTransition."""
    admin_a = await _mint_admin_key(gateway_client, user_id="reveal_pending")

    _, reveal_id = await _seed_audit_row_and_request(
        gateway_client, requester_hdr=admin_a,
    )

    r = await gateway_client.get(
        f"/admin/audit/reveal-requests/{reveal_id}/reveal",
        headers=admin_a,
    )
    assert r.status_code == 409, r.text


@pytest.mark.asyncio
async def test_reveal_wrong_user_returns_403(
    gateway_client, clean_reveals, clean_keys, audit_key_set,
):
    """Only the original requester can decrypt — even master/another admin
    holding an approved request gets 403 NotAuthorizedToReveal."""
    admin_a = await _mint_admin_key(gateway_client, user_id="reveal_wuser_a")
    admin_b = await _mint_admin_key(gateway_client, user_id="reveal_wuser_b")

    _, reveal_id = await _seed_audit_row_and_request(
        gateway_client, requester_hdr=admin_a,
    )

    # admin_b approves (legitimate dual-control).
    r = await gateway_client.post(
        f"/admin/audit/reveal-requests/{reveal_id}/approve",
        headers=admin_b, json={},
    )
    assert r.status_code == 200, r.text

    # admin_b (who is admin, but was NOT the requester) tries to decrypt.
    r = await gateway_client.get(
        f"/admin/audit/reveal-requests/{reveal_id}/reveal",
        headers=admin_b,
    )
    assert r.status_code == 403, r.text

    # MASTER (also admin, also not the requester) is just as locked out.
    r = await gateway_client.get(
        f"/admin/audit/reveal-requests/{reveal_id}/reveal",
        headers=MASTER,
    )
    assert r.status_code == 403, r.text


@pytest.mark.asyncio
async def test_reveal_revealed_state_is_terminal(
    gateway_client, clean_reveals, clean_keys, audit_key_set,
):
    """A successful reveal flips status to 'revealed' (terminal); a second
    GET /reveal must return 409, not re-decrypt."""
    admin_a = await _mint_admin_key(gateway_client, user_id="reveal_term_a")
    admin_b = await _mint_admin_key(gateway_client, user_id="reveal_term_b")

    _, reveal_id = await _seed_audit_row_and_request(
        gateway_client, requester_hdr=admin_a,
    )

    r = await gateway_client.post(
        f"/admin/audit/reveal-requests/{reveal_id}/approve",
        headers=admin_b, json={},
    )
    assert r.status_code == 200, r.text

    # First reveal — succeeds.
    r = await gateway_client.get(
        f"/admin/audit/reveal-requests/{reveal_id}/reveal",
        headers=admin_a,
    )
    assert r.status_code == 200, r.text

    # Second attempt — terminal state.
    r = await gateway_client.get(
        f"/admin/audit/reveal-requests/{reveal_id}/reveal",
        headers=admin_a,
    )
    assert r.status_code == 409, r.text


@pytest.mark.asyncio
async def test_reveal_without_encryption_configured_returns_503(
    gateway_client, clean_reveals, clean_keys, audit_key_unset,
):
    """When the audit row was written without ciphertext (no key), the reveal
    flow either:
      (a) returns 200 with plaintexts={'prompt':None,'response':None} — the
          service skips decrypt() when ciphertext column is empty, OR
      (b) returns 503 if a future tightening makes "no ciphertext" hard-fail.
    Both are valid contracts; we accept either to keep the test load-bearing
    on what matters (no plaintext leaks when no key)."""
    admin_a = await _mint_admin_key(gateway_client, user_id="reveal_nokey_a")
    admin_b = await _mint_admin_key(gateway_client, user_id="reveal_nokey_b")

    _, reveal_id = await _seed_audit_row_and_request(
        gateway_client, requester_hdr=admin_a,
    )

    r = await gateway_client.post(
        f"/admin/audit/reveal-requests/{reveal_id}/approve",
        headers=admin_b, json={},
    )
    assert r.status_code == 200, r.text

    r = await gateway_client.get(
        f"/admin/audit/reveal-requests/{reveal_id}/reveal",
        headers=admin_a,
    )
    assert r.status_code in (200, 503), r.text
    if r.status_code == 200:
        body = r.json()
        assert body["plaintext"]["prompt"]   is None
        assert body["plaintext"]["response"] is None


# ===========================================================================
# 4. UEBA baseline endpoint
# ===========================================================================
@pytest.mark.asyncio
async def test_ueba_baseline_initially_empty_for_user(gateway_client, clean_ueba):
    """Untouched user → enabled, zero-everything baseline shape."""
    r = await gateway_client.get(
        "/admin/ueba/user/never-seen-this-user/baseline",
        headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["enabled"]            is True
    assert body["user_id"]            == "never-seen-this-user"
    assert body["window_days"]        == 7
    assert body["total_requests"]     == 0
    assert body["model_mix"]          == {}
    # JSON keys are strings even when populated as ints.
    hod = body["hour_of_day_tokens"]
    assert len(hod) == 24
    assert all(int(v) == 0 for v in hod.values())


@pytest.mark.asyncio
async def test_ueba_baseline_increments_on_traffic(gateway_client, clean_ueba):
    """Two completions → total_requests >= 2, model_mix has the served model,
    this hour's token bucket > 0."""
    headers = dev_headers(user="baseline_test")
    for _ in range(2):
        r = await _drive_completion(gateway_client, headers=headers)
        assert r.status_code == 200, r.text
    await asyncio.sleep(0.1)

    r = await gateway_client.get(
        "/admin/ueba/user/baseline_test/baseline",
        headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["total_requests"] >= 2

    # The mock vLLM serves gemma-4-27b for tiny prompts on L1_standard.
    mm = body["model_mix"]
    assert mm, body
    # Allow either exact model name match or substring (router naming may vary).
    served = next(iter(mm.keys()))
    assert mm[served] >= 2, mm

    # Current hour-of-day bucket — JSON keys are strings.
    this_hour = datetime.now(timezone.utc).hour
    hod = body["hour_of_day_tokens"]
    assert int(hod[str(this_hour)]) > 0, hod


# ===========================================================================
# 5. Auto-quarantine — flip + restore
# ===========================================================================
async def _force_three_jb_signals(user_id: str) -> None:
    """Inject 3 jailbreak counter increments directly via the plugin store.
    Faster than driving 3 real injection prompts and more deterministic."""
    from gateway.plugins import PluginKind, registry

    ueba = next(p for p in registry.of_kind(PluginKind.OBSERVE)
                if p.name == "observe_ueba")
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    for _ in range(3):
        await ueba._counters.incr(f"ueba:jb:{user_id}:{today}", 86400)


@pytest_asyncio.fixture
async def quarantine_target_key(gateway_client, clean_keys):
    """Mint a normal (non-admin) key for user 'quarantine_target' and return
    (key_id, raw_key) so tests can assert it gets flipped to inactive."""
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id":    "quarantine_target",
              "team_id":    "backend-engineering",
              "user_email": "quarantine_target@example.com"},
    )
    assert r.status_code == 201, r.text
    issued = r.json()
    yield {"id": issued["id"], "raw_key": issued["raw_key"]}


@pytest.mark.asyncio
async def test_auto_quarantine_after_3_critical_signals(
    gateway_client, clean_keys, clean_ueba, quarantine_target_key,
):
    """Three day-windowed critical signals + one more on_post_call → all keys
    for the target user flip to is_active=false and an alert row appears."""
    user = "quarantine_target"
    await _force_three_jb_signals(user)

    # Drive ONE more chat completion AS the target user — on_post_call sees
    # the counter is already at 3 and trips the breaker.
    target_hdr = {
        "Authorization": f"Bearer {quarantine_target_key['raw_key']}",
        "Content-Type":  "application/json",
    }
    r = await _drive_completion(gateway_client, headers=target_hdr,
                                prompt="trigger the breaker")
    assert r.status_code == 200, r.text
    await asyncio.sleep(0.2)

    # The key for the target user is now inactive.
    r = await gateway_client.get(
        "/admin/keys?include_inactive=true", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    target_keys = [k for k in r.json() if k["user_id"] == user]
    assert target_keys, "no key found for target user"
    assert all(k["is_active"] is False for k in target_keys), target_keys

    # Bonus: when present, an open auto_quarantine alert row should be tagged
    # to this user. The persistence path raises a critical alert via
    # _raise_alert(); we treat its presence as best-effort because the key-
    # deactivation effect (the load-bearing safety property) is what the
    # tripped breaker MUST guarantee, and that's already asserted above.
    r = await gateway_client.get(
        "/admin/ueba/alerts?status=open", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    alerts = r.json()["alerts"]
    quarantine_alerts = [a for a in alerts
                         if a["signal"] == "auto_quarantine"
                         and a["user_id"] == user]
    if quarantine_alerts:
        assert quarantine_alerts[0]["severity"] == "critical"


@pytest.mark.asyncio
async def test_restore_keys_endpoint_re_activates(
    gateway_client, clean_keys, clean_ueba, quarantine_target_key,
):
    """After auto-quarantine, /admin/ueba/user/{id}/restore-keys re-arms all
    deactivated keys for that user and returns keys_reactivated >= 1."""
    user = "quarantine_target"

    # Trip the quarantine the same way as #13.
    await _force_three_jb_signals(user)
    target_hdr = {
        "Authorization": f"Bearer {quarantine_target_key['raw_key']}",
        "Content-Type":  "application/json",
    }
    r = await _drive_completion(gateway_client, headers=target_hdr,
                                prompt="trigger the breaker")
    assert r.status_code == 200, r.text
    await asyncio.sleep(0.2)

    # Sanity: the key is currently inactive.
    r = await gateway_client.get(
        "/admin/keys?include_inactive=true", headers=MASTER,
    )
    rows = [k for k in r.json() if k["user_id"] == user]
    assert rows and all(k["is_active"] is False for k in rows), rows

    # Restore.
    r = await gateway_client.post(
        f"/admin/ueba/user/{user}/restore-keys",
        headers=MASTER,
        json={"decision_note": "false positive — confirmed legitimate test traffic"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["user_id"]          == user
    assert body["keys_reactivated"] >= 1
    assert body["cleared_by"]       == "master"

    # All target-user keys are active again.
    r = await gateway_client.get("/admin/keys", headers=MASTER)
    rows = [k for k in r.json() if k["user_id"] == user]
    assert rows and all(k["is_active"] is True for k in rows), rows
