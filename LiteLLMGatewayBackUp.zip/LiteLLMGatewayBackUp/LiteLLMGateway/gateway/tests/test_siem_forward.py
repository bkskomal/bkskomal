"""SIEM forwarder + observability-status integration tests.

The SIEM forwarder is a fire-and-forget audit consumer: it never blocks the
request path and never raises into it, even when the destination is down.
These tests drive a real chat completion through the gateway (with the full
plugin chain) and then probe the side-effects:

  * a captive HTTP test server collects the POST body for happy-path checks
  * an unreachable port forces the dead-letter path
  * we assert the user-facing 200 is unaffected by SIEM failure

The observability-status endpoint is the SOC's banner data source. It self-
reports the live state of all 5 audit pipes (postgres / siem / prometheus /
ueba / four-eyes); we lock in the shape + admin-only guard here.

State hygiene
-------------
The siem_forward plugin is loaded into GATEWAY_PLUGINS for every test in
the suite (see conftest), so its in-memory counters can leak between tests.
The ``reset_siem_state`` fixture below scrubs the counters AND clears the
plugin's HTTP client + URL so a follow-on test that doesn't configure the
plugin starts from a true off state. The dead-letter file is also removed.
"""

from __future__ import annotations

import asyncio
import json
import socket
import threading
import time
from pathlib import Path

import pytest
import pytest_asyncio
import uvicorn
from fastapi import FastAPI, Request

from .conftest import dev_headers, dev_token


MASTER = {"Authorization": "Bearer sk-master-dev",
          "Content-Type":  "application/json"}


# ---------------------------------------------------------------------------
# Helpers — captive HTTP server that records POST bodies
# ---------------------------------------------------------------------------
def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class _CaptureServer:
    """Tiny FastAPI app that appends every POST body to a list.

    Modeled after conftest._BackgroundServer: runs uvicorn in a daemon
    thread on a free port and waits for the socket to come up before
    yielding to the test. Stays in-process so we don't need any extra
    network plumbing.
    """

    def __init__(self) -> None:
        self.bodies: list[bytes] = []
        self.headers: list[dict[str, str]] = []
        self.app = FastAPI()

        @self.app.post("/{path:path}")
        async def _capture(request: Request, path: str):  # noqa: ARG001
            self.bodies.append(await request.body())
            self.headers.append(dict(request.headers))
            return {"ok": True}

        self.host = "127.0.0.1"
        self.port = _free_port()
        cfg = uvicorn.Config(self.app, host=self.host, port=self.port,
                             log_level="warning", loop="asyncio")
        self.server = uvicorn.Server(cfg)
        self._thread = threading.Thread(target=self.server.run, daemon=True)

    def start(self) -> None:
        self._thread.start()
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            try:
                with socket.create_connection((self.host, self.port),
                                              timeout=0.3):
                    return
            except OSError:
                time.sleep(0.1)
        raise RuntimeError(f"Capture server never came up on :{self.port}")

    def stop(self) -> None:
        self.server.should_exit = True
        self._thread.join(timeout=5)

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}/collect"


@pytest_asyncio.fixture
async def capture_server():
    srv = _CaptureServer()
    srv.start()
    try:
        yield srv
    finally:
        srv.stop()


# ---------------------------------------------------------------------------
# Per-test SIEM plugin reset — counters + client + dead-letter file
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def reset_siem_state():
    """Restore siem_forward to a clean off state before AND after each test.

    Without this, a previous test that configured the plugin via setup()
    leaves the in-memory _url / _client / _enabled set, and the next test
    (which assumes "no URL configured") would still see events being sent.
    Also wipes any dead-letter file the previous test created.
    """
    from gateway.plugins import registry

    def _scrub(plugin):
        if plugin is None:
            return
        plugin._sent = 0
        plugin._failed = 0
        plugin._dead_lettered = 0
        # Tear down the live HTTP client so the next test starts from
        # "not configured".
        if getattr(plugin, "_client", None) is not None:
            try:
                # Schedule close; we don't await — the AsyncClient is
                # cheap to leak in tests and aclose() needs an event loop.
                client = plugin._client
                plugin._client = None
                asyncio.create_task(client.aclose())
            except Exception:
                plugin._client = None
        plugin._url = None
        plugin._enabled = False
        # Remove any dead-letter file from a previous test so the next
        # test's "file should now exist" assertion is meaningful.
        try:
            p = Path(plugin._dead_letter_path)
            if p.exists():
                p.unlink()
        except Exception:
            pass

    plugin = registry.get("siem_forward")
    _scrub(plugin)
    yield
    _scrub(registry.get("siem_forward"))


# ---------------------------------------------------------------------------
# Helpers — directly configure the live siem_forward plugin instance
# ---------------------------------------------------------------------------
async def _configure_siem(*, url: str | None, dead_letter_path: Path | None = None,
                          timeout_seconds: float = 5.0) -> None:
    """Re-run setup() on the live siem_forward plugin with the given config.

    We bypass the /admin/plugins/siem_forward/config PUT route because the
    schema doesn't expose dead_letter_path (operators set it via env var or
    YAML), and tests need to point it at tmp_path for isolation.
    """
    from gateway.plugins import registry
    plugin = registry.get("siem_forward")
    assert plugin is not None, "siem_forward plugin not registered"
    siem_cfg: dict = {"enabled": True}
    if url is not None:
        siem_cfg["url"] = url
    if dead_letter_path is not None:
        siem_cfg["dead_letter_path"] = str(dead_letter_path)
    siem_cfg["timeout_seconds"] = timeout_seconds
    await plugin.setup({"policies": {"siem": siem_cfg}})


# ---------------------------------------------------------------------------
# 1. No URL configured → plugin is a clean no-op
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_siem_disabled_when_no_url(gateway_client, reset_siem_state):
    """With no SIEM URL set anywhere, on_audit fires but never tries to
    POST. The plugin's status() reflects that it isn't usable yet."""
    from gateway.plugins import registry

    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text

    await asyncio.sleep(0.2)

    plugin = registry.get("siem_forward")
    assert plugin is not None
    st = plugin.status()
    # Either "enabled" defaulted off or "configured" is false — both are
    # equivalent "no-op" signals.
    assert (st["enabled"] is False) or (st["configured"] is False), st
    # Critically: no event was sent and none was dead-lettered.
    assert st["events_sent"]   == 0, st
    assert st["events_failed"] == 0, st
    assert st["dead_lettered"] == 0, st


# ---------------------------------------------------------------------------
# 2. Happy path — POST captured by local test server
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_siem_forwards_audit_event_to_local_test_server(
    gateway_client, capture_server, reset_siem_state,
):
    """Configure siem_forward at the in-process capture server, drive one
    chat completion, and assert the captured POST body carries the right
    user_id + verdict."""
    await _configure_siem(url=capture_server.url)

    user = "siem-happy-user"
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={"Authorization": f"Bearer {dev_token(user=user)}",
                 "Content-Type":  "application/json"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text

    # Fire-and-forget — give the create_task a tick to land.
    await asyncio.sleep(0.3)

    assert len(capture_server.bodies) == 1, (
        f"expected 1 captured POST, got {len(capture_server.bodies)}: "
        f"{capture_server.bodies!r}"
    )
    payload = json.loads(capture_server.bodies[0])
    # splunk_hec envelope wraps the audit dict under "event".
    assert "event" in payload, payload
    event = payload["event"]
    assert event["user_id"] == user, event
    assert event["verdict"] == "allow", event


# ---------------------------------------------------------------------------
# 3. Unreachable destination → dead-letter file written, request still 200
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_siem_dead_letters_on_unreachable(
    gateway_client, tmp_path, reset_siem_state,
):
    """Point the SIEM URL at a closed port. The chat completion must still
    return 200 (SIEM is best-effort), and the dead-letter JSONL must contain
    the event so an operator can replay it later."""
    dl = tmp_path / "siem-deadletter.jsonl"
    # Allocate a free port THEN don't bind anything to it; connection refused
    # forces the dead-letter branch quickly without a 5s timeout.
    closed_port = _free_port()
    await _configure_siem(
        url=f"http://127.0.0.1:{closed_port}/collect",
        dead_letter_path=dl,
        timeout_seconds=2.0,
    )

    user = "siem-deadletter-user"
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={"Authorization": f"Bearer {dev_token(user=user)}",
                 "Content-Type":  "application/json"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    # SIEM failure must NEVER affect the user-facing response.
    assert r.status_code == 200, r.text

    # Wait long enough for the connect to fail + the file write to flush.
    # Connection-refused is near-instant on loopback, but allow some slack.
    for _ in range(30):
        await asyncio.sleep(0.1)
        if dl.exists() and dl.read_text(encoding="utf-8").strip():
            break

    assert dl.exists(), f"dead-letter file not written at {dl}"
    lines = [ln for ln in dl.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert lines, "dead-letter file is empty"
    parsed = json.loads(lines[0])
    # Same splunk_hec envelope we'd POST.
    event = parsed.get("event", parsed)
    assert event.get("user_id") == user, parsed

    from gateway.plugins import registry
    plugin = registry.get("siem_forward")
    assert plugin is not None
    st = plugin.status()
    assert st["dead_lettered"] >= 1, st


# ---------------------------------------------------------------------------
# 4. SIEM payload must NEVER carry plaintext content
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_siem_payload_excludes_plaintext(
    gateway_client, capture_server, reset_siem_state,
):
    """The SIEM pipe ships hashes + finding metadata only. A literal sentinel
    in the prompt MUST NOT appear anywhere in the captured POST body."""
    await _configure_siem(url=capture_server.url)

    sentinel = "VERY_SECRET_VALUE"
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(),
        json={"messages": [
            {"role": "user", "content": f"Please remember this: {sentinel}"},
        ]},
    )
    assert r.status_code == 200, r.text

    await asyncio.sleep(0.3)

    assert len(capture_server.bodies) == 1, capture_server.bodies
    body_bytes = capture_server.bodies[0]
    assert sentinel.encode() not in body_bytes, (
        f"plaintext sentinel {sentinel!r} leaked into SIEM payload: "
        f"{body_bytes[:500]!r}"
    )
    # Belt-and-braces — also check the decoded JSON string form.
    assert sentinel not in body_bytes.decode("utf-8", errors="replace")


# ---------------------------------------------------------------------------
# 5. /admin/observability/status — 5-pipe shape lock-in
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_observability_status_endpoint_returns_5_pipes(
    gateway_client, reset_siem_state,
):
    """The Overview banner depends on this endpoint shape. Lock down the
    5 pipe names + per-pipe state expectations so a refactor can't quietly
    drop one and surface a green banner that hides a failed pipe."""
    r = await gateway_client.get(
        "/admin/observability/status", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert "generated_at" in body, body
    pipes = body["pipes"]
    assert len(pipes) == 5, pipes

    by_name = {p["name"]: p for p in pipes}
    expected_names = {"postgres_audit", "siem", "prometheus", "ueba", "four_eyes"}
    assert set(by_name) == expected_names, set(by_name)

    # Every pipe carries the full PipeStatus shape (detail/metric/href may
    # be null but must be PRESENT).
    for p in pipes:
        for field in ("name", "label", "state", "detail", "metric", "href"):
            assert field in p, (p["name"], p, field)

    assert by_name["postgres_audit"]["state"] == "active", by_name["postgres_audit"]
    # Prometheus pipe is "active" if GATEWAY_GRAFANA_URL is set (Grafana is
    # actually being scraped), else "configured" (metrics exposed, no scraper).
    # Either is honest; tests don't set the env var so the typical state is
    # "configured" — but accept "active" for environments that do set it.
    assert by_name["prometheus"]["state"] in {"active", "configured"}, by_name["prometheus"]
    assert by_name["four_eyes"]["state"]      == "off",    by_name["four_eyes"]
    assert by_name["ueba"]["state"]           == "partial", by_name["ueba"]
    # SIEM may be off (no URL) or active/partial (if a previous test in this
    # module configured it and reset_siem_state ran in cleanup order); accept
    # any of the three — what matters is the pipe is present and well-formed.
    assert by_name["siem"]["state"] in {"off", "active", "partial"}, by_name["siem"]


# ---------------------------------------------------------------------------
# 6. Admin-only enforcement
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_observability_status_requires_admin(gateway_client):
    r = await gateway_client.get(
        "/admin/observability/status", headers=dev_headers(),
    )
    assert r.status_code == 403, r.text
