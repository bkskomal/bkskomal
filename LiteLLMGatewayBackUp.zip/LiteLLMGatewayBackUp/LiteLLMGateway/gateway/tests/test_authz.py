"""Per-tier AuthZ enforcement.

Tier L0_readonly → only Gemma 4.
Tier L1_standard → Gemma + Qwen3 (no Kimi).
Tier L2_senior   → all three + force-override allowed.
Tier quarantined → nothing.
"""

from __future__ import annotations

import pytest


def _hdr(tier: str, team: str = "test-team") -> dict[str, str]:
    return {"Authorization": f"Bearer sk-dev+{team}+{tier}+alice",
            "Content-Type":  "application/json"}


@pytest.mark.asyncio
async def test_l0_intern_cannot_force_kimi(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L0_readonly"),
        json={"messages": [{"role": "user", "content": "hi"}],
              "model":    "force:kimi-k2.6"},
    )
    assert r.status_code == 422, r.text
    body = r.json()
    assert body["error"]["code"] == "policy_refused"
    assert "override" in body["error"]["message"].lower() \
        or "L0_readonly" in body["error"]["message"]


@pytest.mark.asyncio
async def test_l0_intern_gets_gemma_for_tiny_prompt(gateway_client):
    # The "Tiny prompts → cheapest" rule routes to Gemma, which L0 allows.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L0_readonly"),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "gemma-4-27b"


@pytest.mark.asyncio
async def test_l1_standard_blocked_from_kimi_falls_back_to_qwen3(gateway_client):
    """L1 has Gemma + Qwen3. A tool-use prompt would route to Kimi but the
    rule has fallback_if_tier_blocks → qwen3-coder-30b. Verify downgrade."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L1_standard"),
        json={
            "messages": [{"role": "user", "content": "Plan a migration"}],
            "tools":    [{"type": "function",
                          "function": {"name": "noop",
                                       "description": "",
                                       "parameters": {"type": "object"}}}],
        },
    )
    # Two valid outcomes:
    #  (a) AuthZ refuses tool-use because L1 agent_mode is "tools_no_shell"
    #      (interpreted strictly).
    #  (b) AuthZ allows it; router downgrades to Qwen3 via fallback.
    # We accept either as a pass since both are tier-correct.
    if r.status_code == 200:
        assert r.headers["X-LLM-Model-Used"] == "qwen3-coder-30b"
        assert "downgraded" in r.headers["X-LLM-Routing-Reason"].lower() \
            or "qwen3" in r.headers["X-LLM-Routing-Reason"].lower()
    else:
        assert r.status_code == 422, r.text


@pytest.mark.asyncio
async def test_l2_senior_can_force_kimi(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L2_senior"),
        json={"messages": [{"role": "user", "content": "explain monads"}],
              "model":    "force:kimi-k2.6"},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "kimi-k2.6"


@pytest.mark.asyncio
async def test_quarantined_user_is_blocked(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("quarantined"),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 422, r.text
    body = r.json()
    assert body["error"]["code"] == "policy_refused"


@pytest.mark.asyncio
async def test_unknown_tier_is_refused(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L9_does_not_exist"),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 422, r.text
    body = r.json()
    assert "tier" in body["error"]["message"].lower()


# ---------------------------------------------------------------------------
# "Router decides" sentinel — model: "auto" / "" / omitted lets the router
# pick. AuthZ must NOT reject for the requested name being absent from the
# tier's models_allowed.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_l0_intern_with_auto_lets_router_pick(gateway_client):
    """L0 dev sends model='auto' with a tiny prompt — router picks gemma
    (the only L0-allowed model) and the response comes back 200."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L0_readonly"),
        json={"messages": [{"role": "user", "content": "hi"}],
              "model":    "auto"},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "gemma-4-27b"


@pytest.mark.asyncio
async def test_l1_with_empty_model_lets_router_pick(gateway_client):
    """L1 dev omits the model field entirely — router picks based on rules.
    A code-block prompt should land on qwen3-coder-30b under test policies."""
    prompt = (
        "Refactor this for clarity:\n"
        "```python\n"
        "def add(a, b): return a+b\n"
        "```\n"
    )
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L1_standard"),
        json={"messages": [{"role": "user", "content": prompt}]},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "qwen3-coder-30b"


@pytest.mark.asyncio
async def test_l1_with_auto_uppercase_also_works(gateway_client):
    """Sentinel matching is case-insensitive — 'AUTO' is treated like 'auto'."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L1_standard"),
        json={"messages": [{"role": "user", "content": "hi"}],
              "model":    "AUTO"},
    )
    assert r.status_code == 200, r.text


@pytest.mark.asyncio
async def test_l1_explicit_disallowed_still_returns_422(gateway_client):
    """An explicit (non-force:) model name not in the tier's allow-list must
    still be refused with policy_refused — we only relaxed the empty/auto
    case, not the explicit-but-disallowed case."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=_hdr("L1_standard"),
        json={"messages": [{"role": "user", "content": "hi"}],
              "model":    "kimi-k2.6"},
    )
    assert r.status_code == 422, r.text
    body = r.json()
    assert body["error"]["code"] == "policy_refused"
