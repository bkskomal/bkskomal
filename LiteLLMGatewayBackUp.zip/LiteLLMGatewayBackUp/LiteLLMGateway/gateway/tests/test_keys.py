"""Virtual-API-key issuance + lookup + revocation tests.

Drives the admin endpoints to mint a real key, then uses that key on
``/v1/chat/completions`` and verifies routing works for it. Finally
revokes the key and verifies the next call is rejected.
"""

from __future__ import annotations

import pytest


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


@pytest.mark.asyncio
async def test_create_lookup_and_revoke_key(gateway_client, clean_keys):
    # 1. Create a team (idempotent — seeded already, this is a sanity check)
    r = await gateway_client.put(
        "/admin/teams/backend-engineering",
        headers=MASTER,
        json={"team_id": "backend-engineering",
              "tier": "L1_standard",
              "description": "Default eng team"},
    )
    assert r.status_code == 200, r.text

    # 2. Issue a key
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id": "bk.komal", "team_id": "backend-engineering",
              "user_email": "bk@example.com"},
    )
    assert r.status_code == 201, r.text
    issued = r.json()
    raw_key    = issued["raw_key"]
    key_prefix = issued["key_prefix"]
    key_id     = issued["id"]
    assert raw_key.startswith("sk-")
    assert key_prefix.startswith("sk-")
    assert len(key_prefix) == 3 + 8

    # 3. The same key listed should NOT expose raw_key, only prefix
    r = await gateway_client.get("/admin/keys", headers=MASTER)
    assert r.status_code == 200, r.text
    keys = r.json()
    assert any(k["id"] == key_id and k["key_prefix"] == key_prefix for k in keys)
    assert all("raw_key" not in k for k in keys)

    # 4. Use the key to drive an actual completion through the smart router.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={"Authorization": f"Bearer {raw_key}",
                 "Content-Type":  "application/json"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text
    # The team is L1_standard, which allows Gemma; tiny prompt → Gemma.
    assert r.headers["X-LLM-Model-Used"] == "gemma-4-27b"

    # 5. Revoke
    r = await gateway_client.delete(f"/admin/keys/{key_id}", headers=MASTER)
    assert r.status_code == 204, r.text

    # 6. Revoked key returns 401
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={"Authorization": f"Bearer {raw_key}",
                 "Content-Type":  "application/json"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 401, r.text


@pytest.mark.asyncio
async def test_create_key_without_team_fails(gateway_client, clean_keys):
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id": "ghost", "team_id": "does-not-exist"},
    )
    assert r.status_code == 400, r.text
    assert "does not exist" in r.json()["detail"]


@pytest.mark.asyncio
async def test_listing_keys_requires_admin(gateway_client):
    # No bearer
    r = await gateway_client.get("/admin/keys")
    assert r.status_code == 401, r.text
    # Dev token (non-admin role)
    r = await gateway_client.get(
        "/admin/keys",
        headers={"Authorization": "Bearer sk-dev+backend-engineering+L1_standard+alice"},
    )
    assert r.status_code == 403, r.text
    # Master key works
    r = await gateway_client.get("/admin/keys", headers=MASTER)
    assert r.status_code == 200, r.text
