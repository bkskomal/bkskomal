"""Tests for the operator-toggled Spend ($USD/h) by model feature.

The toggle lives in ``system_settings`` (kv table). The data endpoint must
short-circuit to ``enabled=False`` when the toggle is off — that's the
whole point of the feature, calculation runs only on opt-in.
"""

from __future__ import annotations

import pytest
import pytest_asyncio

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


@pytest_asyncio.fixture
async def clean_system_settings():
    """Truncate system_settings between tests so toggle state is deterministic."""
    import os
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            await conn.execute(text("TRUNCATE TABLE system_settings RESTART IDENTITY"))
        yield
        async with eng.begin() as conn:
            await conn.execute(text("TRUNCATE TABLE system_settings RESTART IDENTITY"))
    finally:
        await eng.dispose()


# ---------------------------------------------------------------------------
# Toggle endpoint
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_spend_toggle_defaults_off(gateway_client, clean_system_settings):
    r = await gateway_client.get("/admin/settings/spend-by-model", headers=MASTER)
    assert r.status_code == 200, r.text
    assert r.json() == {"enabled": False}


@pytest.mark.asyncio
async def test_spend_toggle_round_trips(gateway_client, clean_system_settings):
    # ON
    r = await gateway_client.put(
        "/admin/settings/spend-by-model", headers=MASTER, json={"enabled": True},
    )
    assert r.status_code == 200, r.text
    assert r.json() == {"enabled": True}

    # GET reflects it
    r = await gateway_client.get("/admin/settings/spend-by-model", headers=MASTER)
    assert r.json() == {"enabled": True}

    # OFF again
    r = await gateway_client.put(
        "/admin/settings/spend-by-model", headers=MASTER, json={"enabled": False},
    )
    assert r.json() == {"enabled": False}


@pytest.mark.asyncio
async def test_spend_toggle_requires_admin(gateway_client, clean_system_settings):
    r = await gateway_client.get(
        "/admin/settings/spend-by-model", headers=dev_headers(),
    )
    assert r.status_code == 403, r.text


# ---------------------------------------------------------------------------
# Data endpoint — must short-circuit when disabled
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_spend_data_returns_disabled_shape_when_off(
    gateway_client, clean_system_settings,
):
    """The whole point of the feature: when the toggle is off, the endpoint
    must not touch the audit DB and must return ``enabled=False`` with an
    empty body. A UI poller hitting this should be cheap."""
    r = await gateway_client.get(
        "/admin/metrics/spend-by-model?window_minutes=60", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["enabled"] is False
    assert body["by_model"] == []
    assert body["cost_total_usd"] == 0.0
    assert body["rows_considered"] == 0
    assert body["window_minutes"] == 60


@pytest.mark.asyncio
async def test_spend_data_returns_zero_shape_when_on_no_audit(
    gateway_client, clean_system_settings, clean_audit_db,
):
    """Enabled + clean audit_log → enabled=True, zero numbers. The endpoint
    must not 500 on an empty audit table."""
    r = await gateway_client.put(
        "/admin/settings/spend-by-model", headers=MASTER, json={"enabled": True},
    )
    assert r.status_code == 200, r.text

    r = await gateway_client.get(
        "/admin/metrics/spend-by-model?window_minutes=60", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["enabled"] is True
    assert body["by_model"] == []
    assert body["cost_total_usd"] == 0.0
    assert body["rows_considered"] == 0


@pytest.mark.asyncio
async def test_spend_data_requires_admin(gateway_client, clean_system_settings):
    r = await gateway_client.get(
        "/admin/metrics/spend-by-model", headers=dev_headers(),
    )
    assert r.status_code == 403, r.text


# ---------------------------------------------------------------------------
# Window param bounds (1..1440) — invalid values should 422 from FastAPI
# rather than hitting the service with nonsense.
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_spend_data_window_param_validation(
    gateway_client, clean_system_settings,
):
    r = await gateway_client.get(
        "/admin/metrics/spend-by-model?window_minutes=0", headers=MASTER,
    )
    assert r.status_code == 422, r.text

    r = await gateway_client.get(
        "/admin/metrics/spend-by-model?window_minutes=99999", headers=MASTER,
    )
    assert r.status_code == 422, r.text
