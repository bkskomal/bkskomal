"""Per-plugin configuration endpoint tests.

Covers ``/admin/plugins/schemas`` and ``/admin/plugins/{name}/config``.

Same shape as ``test_policy_admin.py``:
  * ``clean_plugin_configs`` TRUNCATEs ``plugin_configs`` on entry AND on
    exit so a test that writes (e.g.) ``quota_redis.enabled = false``
    can't leak that disabled state into ``test_quotas.py`` and break the
    rest of the suite.
  * Every endpoint is admin-only — dev tokens get 403.
  * The PUT-then-reload cycle re-runs ``setup()`` on policy-consuming
    plugins, so we can probe the live plugin instance (via the registry)
    to confirm the new config was actually re-applied.
"""

from __future__ import annotations

import os

import pytest
import pytest_asyncio

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def clean_plugin_configs():
    """Truncate plugin_configs between tests AND on teardown.

    Teardown is critical: ``test_quota_redis_disabled_via_plugin_config``
    leaves a row marking ``quota_redis`` disabled. If we don't wipe on
    exit, the apply_overrides() merge in the next test module's lifespan
    would still see that row and (in the future, when the kill-switch
    wires through) bypass quota enforcement everywhere. Also re-run the
    policy-consumer reload on exit so the in-memory plugin state matches
    the now-empty DB (otherwise the previous test's PUT call leaves the
    plugin instance with overridden config even after the row is gone).
    """
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            await conn.execute(text("TRUNCATE TABLE plugin_configs RESTART IDENTITY"))
        yield
        async with eng.begin() as conn:
            await conn.execute(text("TRUNCATE TABLE plugin_configs RESTART IDENTITY"))
        # Re-run setup() on policy consumers so in-memory state forgets
        # any override the test installed via PUT.
        from gateway.main import reload_policy_consumers
        await reload_policy_consumers()
    finally:
        await eng.dispose()


# ---------------------------------------------------------------------------
# Schemas endpoint
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_schemas_endpoint_returns_known_plugins(gateway_client):
    r = await gateway_client.get("/admin/plugins/schemas", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()

    names = set(body["configurable_plugins"])
    expected = {"cache_redis", "observe_ueba", "output_scan_secrets",
                "guardrail_patterns", "quota_redis"}
    assert expected <= names, names

    schemas = body["schemas"]
    for name in expected:
        s = schemas[name]
        assert "title" in s and s["title"], (name, s)
        assert "description" in s and s["description"], (name, s)
        assert isinstance(s["fields"], list) and s["fields"], (name, s)
        f0 = s["fields"][0]
        assert "key" in f0 and "type" in f0 and "default" in f0, (name, f0)


# ---------------------------------------------------------------------------
# GET /admin/plugins/{name}/config — defaults
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_get_config_with_no_override_returns_defaults(
    gateway_client, clean_plugin_configs,
):
    r = await gateway_client.get(
        "/admin/plugins/cache_redis/config", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["plugin_name"] == "cache_redis"
    assert body["stored"] is None, body
    eff = body["effective"]
    assert eff["enabled"] is True, eff
    assert eff["ttl_seconds"] == 600, eff


# ---------------------------------------------------------------------------
# PUT round-trip — persisted + reflected on GET
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_put_config_persists_and_returns(
    gateway_client, clean_plugin_configs,
):
    payload = {"config": {
        "enabled":               False,
        "ttl_seconds":           1800,
        "skip_above_temperature": 0.5,
    }}
    r = await gateway_client.put(
        "/admin/plugins/cache_redis/config", headers=MASTER, json=payload,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["plugin_name"] == "cache_redis"
    stored = body["stored"]
    assert stored["enabled"] is False, stored
    assert stored["ttl_seconds"] == 1800, stored
    assert stored["skip_above_temperature"] == 0.5, stored

    r = await gateway_client.get(
        "/admin/plugins/cache_redis/config", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["stored"]["enabled"] is False, body
    assert body["stored"]["ttl_seconds"] == 1800, body
    eff = body["effective"]
    assert eff["enabled"] is False, eff
    assert eff["ttl_seconds"] == 1800, eff
    assert eff["skip_above_temperature"] == 0.5, eff


# ---------------------------------------------------------------------------
# PUT — coercion of out-of-range and wrong-type values
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_put_config_coerces_out_of_range_values(
    gateway_client, clean_plugin_configs,
):
    # ttl above schema max (86400) gets clamped down; string-int gets coerced.
    payload = {"config": {
        "ttl_seconds":            999999,
        "skip_above_temperature": "0.3",   # string for a float field
    }}
    r = await gateway_client.put(
        "/admin/plugins/cache_redis/config", headers=MASTER, json=payload,
    )
    assert r.status_code == 200, r.text
    stored = r.json()["stored"]
    assert stored["ttl_seconds"] == 86400, stored
    assert isinstance(stored["skip_above_temperature"], float), stored
    assert stored["skip_above_temperature"] == 0.3, stored


# ---------------------------------------------------------------------------
# PUT — unknown keys are silently dropped
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_put_config_unknown_keys_are_dropped(
    gateway_client, clean_plugin_configs,
):
    payload = {"config": {
        "enabled":  True,
        "evil_key": "bypass",      # not in the schema
    }}
    r = await gateway_client.put(
        "/admin/plugins/cache_redis/config", headers=MASTER, json=payload,
    )
    assert r.status_code == 200, r.text

    r = await gateway_client.get(
        "/admin/plugins/cache_redis/config", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    stored = r.json()["stored"]
    assert "evil_key" not in stored, stored
    assert stored["enabled"] is True, stored


# ---------------------------------------------------------------------------
# PUT — unknown plugin → 404
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_put_config_returns_404_for_unknown_plugin(
    gateway_client, clean_plugin_configs,
):
    r = await gateway_client.put(
        "/admin/plugins/does_not_exist/config",
        headers=MASTER,
        json={"config": {"enabled": True}},
    )
    assert r.status_code == 404, r.text


# ---------------------------------------------------------------------------
# PUT — response includes reload info
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_put_config_returns_reload_info(
    gateway_client, clean_plugin_configs,
):
    r = await gateway_client.put(
        "/admin/plugins/output_scan_secrets/config",
        headers=MASTER,
        json={"config": {"action": "warn"}},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert "reload" in body, body
    reloaded = body["reload"].get("reloaded") or []
    assert isinstance(reloaded, list) and reloaded, body
    assert "authz_tiered" in reloaded, body


# ---------------------------------------------------------------------------
# observe_ueba — threshold actually re-applied via setup()
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_observe_ueba_threshold_override_lives_through_reload(
    gateway_client, clean_plugin_configs,
):
    payload = {"config": {
        "enabled": True,
        "thresholds": {
            "jailbreak_attempts":               {"count": 999, "severity": "warn"},
            "refusal_velocity":                 {"count": 50,  "severity": "warn"},
            "dlp_hit_rate":                     {"count": 30,  "severity": "warn"},
            "output_secret_leaks":              {"count": 5,   "severity": "warn"},
            "elevation_self_approval_attempts": {"count": 1},
            "elevation_burst_rejections":       {"count": 3},
        },
    }}
    r = await gateway_client.put(
        "/admin/plugins/observe_ueba/config", headers=MASTER, json=payload,
    )
    assert r.status_code == 200, r.text
    reloaded = r.json()["reload"]["reloaded"]
    assert "observe_ueba" in reloaded, reloaded

    # Probe the live plugin instance — proves setup() re-ran with the override.
    from gateway.plugins import registry
    plugin = registry.get("observe_ueba")
    assert plugin is not None, "observe_ueba plugin not registered"
    thr = plugin._thresholds
    assert thr["jailbreak_attempts"]["count"] == 999, thr
    assert thr["jailbreak_attempts"]["severity"] == "warn", thr


# ---------------------------------------------------------------------------
# Admin-only enforcement
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_endpoints_require_admin(gateway_client):
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="snooper")

    r = await gateway_client.get("/admin/plugins/schemas", headers=h)
    assert r.status_code == 403, r.text

    r = await gateway_client.get("/admin/plugins/cache_redis/config", headers=h)
    assert r.status_code == 403, r.text

    r = await gateway_client.put(
        "/admin/plugins/cache_redis/config",
        headers=h,
        json={"config": {"enabled": True}},
    )
    assert r.status_code == 403, r.text


# ---------------------------------------------------------------------------
# quota_redis kill-switch — PUT path must succeed even though the actual
# short-circuit isn't wired through yet
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_quota_redis_disabled_via_plugin_config(
    gateway_client, clean_plugin_configs,
):
    # NOTE: the schema exposes an `enabled` kill-switch for quota_redis but
    # the plugin's check_pre() doesn't yet honour it — quotas keep enforcing
    # even after this PUT. The wiring is a follow-up. For now we only assert
    # that the PUT + reload cycle round-trips cleanly so the UI can render
    # the toggle without 5xx.
    r = await gateway_client.put(
        "/admin/plugins/quota_redis/config",
        headers=MASTER,
        json={"config": {"enabled": False}},
    )
    assert r.status_code == 200, r.text
    stored = r.json()["stored"]
    assert stored["enabled"] is False, stored
