"""SSE streaming tests for /v1/chat/completions.

Verifies:
  1. stream=True returns text/event-stream with at least one data: chunk
     and a terminating data: [DONE] sentinel.
  2. Post-call audit still runs after the stream completes — an audit row
     is written whose request_id matches X-Gateway-Request-Id.
"""

from __future__ import annotations

import asyncio
import os

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from .conftest import dev_headers


async def _latest_audit_row():
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            result = await conn.execute(text(
                "SELECT request_id, model_used, verdict, tokens_in, tokens_out "
                "FROM audit_log ORDER BY id DESC LIMIT 1"
            ))
            row = result.mappings().first()
        return dict(row) if row else None
    finally:
        await eng.dispose()


@pytest.mark.asyncio
async def test_stream_returns_sse_chunks(gateway_client, clean_audit_db):
    """stream=True yields a text/event-stream body with data: chunks + [DONE]."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(),
        json={
            "messages":   [{"role": "user", "content": "hi"}],
            "stream":     True,
            "max_tokens": 5,
        },
    )
    assert r.status_code == 200, r.text
    ctype = r.headers.get("content-type", "")
    assert ctype.startswith("text/event-stream"), ctype

    body = r.text
    assert "data: " in body, body[:500]
    assert "data: [DONE]" in body, body[-500:]

    # Transparency headers should still be present on the streamed response.
    assert r.headers.get("x-gateway-request-id"), r.headers
    assert r.headers.get("x-llm-model-used"), r.headers


@pytest.mark.asyncio
async def test_stream_writes_audit_row(gateway_client, clean_audit_db):
    """After the stream finishes, the post-call chain still runs — and the
    audit_postgres plugin writes a row whose request_id matches the header
    on the streaming response."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(),
        json={
            "messages":   [{"role": "user", "content": "hello stream"}],
            "stream":     True,
            "max_tokens": 5,
        },
    )
    assert r.status_code == 200
    request_id = r.headers["x-gateway-request-id"]
    assert request_id

    # Drain the body so the StreamingResponse generator finishes and runs
    # its post-call hooks (audit insert lives there).
    _ = r.text

    # Tiny grace for the commit to be visible.
    await asyncio.sleep(0.3)

    row = await _latest_audit_row()
    assert row is not None, "no audit row was written for the streamed call"
    assert row["request_id"] == request_id, row
    assert row["verdict"] == "allow", row
    assert row["tokens_out"] >= 1, row
