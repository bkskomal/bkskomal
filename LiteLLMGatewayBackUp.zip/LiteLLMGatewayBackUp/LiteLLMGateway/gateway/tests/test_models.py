"""Model-registry endpoint tests.

Covers the ``/admin/models`` CRUD + ``/reload`` routes end-to-end:
  * Listing surfaces the seeded rows on a fresh boot.
  * Create derives provider from the litellm ``model:`` prefix.
  * Duplicate names → 409; missing required params → 400.
  * Patch toggles enabled, refreshes provider when params change, blocks
    name collisions on rename.
  * Delete returns 204 + removes the row; deleting an unknown id → 404.
  * /reload returns the count of *enabled* rows (disabled ones excluded
    from the in-memory router).
  * Every endpoint is admin-only — dev tokens get 403.
"""

from __future__ import annotations

import os

import pytest
import pytest_asyncio

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def clean_models():
    """Truncate litellm_models between tests so IDs / state are deterministic.

    Mirrors ``clean_keys`` and ``clean_elevations``. After the test, the
    table is truncated AGAIN so the next ``gateway_client`` lifespan finds
    it empty and re-seeds from ``_test_litellm_config.yaml`` — otherwise
    downstream tests that drive ``/v1/chat/completions`` against the
    seeded models (kimi-k2.6, qwen3-coder-30b, gemma-4-27b) would see a
    Router built from the rows this test happened to leave behind.
    """
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    try:
        async with eng.begin() as conn:
            await conn.execute(text("TRUNCATE TABLE litellm_models RESTART IDENTITY"))
        yield
        # Empty the table so the next lifespan re-seeds from YAML.
        async with eng.begin() as conn:
            await conn.execute(text("TRUNCATE TABLE litellm_models RESTART IDENTITY"))
    finally:
        await eng.dispose()


# ---------------------------------------------------------------------------
# Listing — seed survives a fresh boot
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_models_list_after_seed_has_default_three(gateway_client):
    """The lifespan seeds three rows from _test_litellm_config.yaml.

    Intentionally NOT using clean_models — we want to observe the seeded
    state on a fresh boot.
    """
    r = await gateway_client.get("/admin/models", headers=MASTER)
    assert r.status_code == 200, r.text
    rows = r.json()
    names = {row["model_name"] for row in rows}
    assert {"kimi-k2.6", "qwen3-coder-30b", "gemma-4-27b"} <= names, names

    kimi = next(row for row in rows if row["model_name"] == "kimi-k2.6")
    # The test YAML sets api_base on the openai/-prefixed model → openai_compatible.
    assert kimi["provider"] == "openai_compatible", kimi


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_models_create_with_ollama_preset(gateway_client, clean_models):
    r = await gateway_client.post(
        "/admin/models",
        headers=MASTER,
        json={
            "model_name": "ollama-qwen-test",
            "litellm_params": {
                "model":    "ollama_chat/qwen2.5-coder:7b-instruct",
                "api_base": "http://localhost:11434",
            },
        },
    )
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["model_name"] == "ollama-qwen-test"
    assert body["provider"]   == "ollama"
    assert body["id"] > 0
    assert body["enabled"] is True


@pytest.mark.asyncio
async def test_models_create_duplicate_returns_409(gateway_client, clean_models):
    payload = {
        "model_name": "dup-model",
        "litellm_params": {"model": "openai/gpt-4o-mini"},
    }
    r = await gateway_client.post("/admin/models", headers=MASTER, json=payload)
    assert r.status_code == 201, r.text

    r2 = await gateway_client.post("/admin/models", headers=MASTER, json=payload)
    assert r2.status_code == 409, r2.text


@pytest.mark.asyncio
async def test_models_create_missing_model_param_returns_400(
    gateway_client, clean_models,
):
    r = await gateway_client.post(
        "/admin/models",
        headers=MASTER,
        json={"model_name": "broken", "litellm_params": {}},
    )
    assert r.status_code == 400, r.text
    assert "model" in r.json()["detail"].lower()


# ---------------------------------------------------------------------------
# Patch
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_models_patch_toggle_enabled(gateway_client, clean_models):
    r = await gateway_client.post(
        "/admin/models",
        headers=MASTER,
        json={
            "model_name": "toggle-me",
            "litellm_params": {"model": "openai/gpt-4o-mini"},
        },
    )
    assert r.status_code == 201, r.text
    model_id = r.json()["id"]

    # Disable it.
    r = await gateway_client.patch(
        f"/admin/models/{model_id}", headers=MASTER, json={"enabled": False},
    )
    assert r.status_code == 200, r.text
    assert r.json()["enabled"] is False

    # include_disabled=false hides it.
    r = await gateway_client.get(
        "/admin/models?include_disabled=false", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    names = {row["model_name"] for row in r.json()}
    assert "toggle-me" not in names, names


@pytest.mark.asyncio
async def test_models_patch_litellm_params_updates_provider(
    gateway_client, clean_models,
):
    r = await gateway_client.post(
        "/admin/models",
        headers=MASTER,
        json={
            "model_name": "flipper",
            "litellm_params": {"model": "openai/gpt-4o-mini"},
        },
    )
    assert r.status_code == 201, r.text
    assert r.json()["provider"] == "openai"
    model_id = r.json()["id"]

    r = await gateway_client.patch(
        f"/admin/models/{model_id}",
        headers=MASTER,
        json={"litellm_params": {"model": "ollama_chat/qwen2.5-coder:7b-instruct"}},
    )
    assert r.status_code == 200, r.text
    assert r.json()["provider"] == "ollama"


@pytest.mark.asyncio
async def test_models_patch_rename_duplicate_returns_409(
    gateway_client, clean_models,
):
    # Create A.
    r = await gateway_client.post(
        "/admin/models",
        headers=MASTER,
        json={"model_name": "name-a",
              "litellm_params": {"model": "openai/gpt-4o-mini"}},
    )
    assert r.status_code == 201, r.text

    # Create B.
    r = await gateway_client.post(
        "/admin/models",
        headers=MASTER,
        json={"model_name": "name-b",
              "litellm_params": {"model": "openai/gpt-4o-mini"}},
    )
    assert r.status_code == 201, r.text
    b_id = r.json()["id"]

    # Renaming B → A is a 409.
    r = await gateway_client.patch(
        f"/admin/models/{b_id}", headers=MASTER, json={"model_name": "name-a"},
    )
    assert r.status_code == 409, r.text


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_models_delete_removes_row(gateway_client, clean_models):
    r = await gateway_client.post(
        "/admin/models",
        headers=MASTER,
        json={"model_name": "doomed",
              "litellm_params": {"model": "openai/gpt-4o-mini"}},
    )
    assert r.status_code == 201, r.text
    model_id = r.json()["id"]

    r = await gateway_client.delete(f"/admin/models/{model_id}", headers=MASTER)
    assert r.status_code == 204, r.text

    r = await gateway_client.get("/admin/models", headers=MASTER)
    assert r.status_code == 200, r.text
    assert all(row["id"] != model_id for row in r.json())


@pytest.mark.asyncio
async def test_models_delete_missing_returns_404(gateway_client, clean_models):
    r = await gateway_client.delete("/admin/models/99999", headers=MASTER)
    assert r.status_code == 404, r.text


# ---------------------------------------------------------------------------
# Reload — count must equal #enabled
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_models_reload_returns_count(gateway_client, clean_models):
    # Seed two enabled models.
    for name in ("alpha", "beta"):
        r = await gateway_client.post(
            "/admin/models",
            headers=MASTER,
            json={"model_name": name,
                  "litellm_params": {"model": "openai/gpt-4o-mini"}},
        )
        assert r.status_code == 201, r.text

    r = await gateway_client.post("/admin/models/reload", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"] is True
    assert body["models_loaded"] == 2, body

    # Disable one — reload count drops by 1.
    r = await gateway_client.get("/admin/models", headers=MASTER)
    alpha_id = next(row["id"] for row in r.json() if row["model_name"] == "alpha")

    r = await gateway_client.patch(
        f"/admin/models/{alpha_id}", headers=MASTER, json={"enabled": False},
    )
    assert r.status_code == 200, r.text

    r = await gateway_client.post("/admin/models/reload", headers=MASTER)
    assert r.status_code == 200, r.text
    assert r.json()["models_loaded"] == 1, r.text


# ---------------------------------------------------------------------------
# Authorisation — every endpoint is admin-only
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_models_endpoints_require_admin(gateway_client, clean_models):
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="snooper")

    # GET
    r = await gateway_client.get("/admin/models", headers=h)
    assert r.status_code == 403, r.text

    # POST
    r = await gateway_client.post(
        "/admin/models",
        headers=h,
        json={"model_name": "nope",
              "litellm_params": {"model": "openai/gpt-4o-mini"}},
    )
    assert r.status_code == 403, r.text

    # PATCH — id doesn't have to exist; the admin check runs first.
    r = await gateway_client.patch(
        "/admin/models/1", headers=h, json={"enabled": False},
    )
    assert r.status_code == 403, r.text

    # DELETE
    r = await gateway_client.delete("/admin/models/1", headers=h)
    assert r.status_code == 403, r.text

    # /reload
    r = await gateway_client.post("/admin/models/reload", headers=h)
    assert r.status_code == 403, r.text
