"""Just-In-Time tier-elevation tests.

Covers the ``/admin/elevation/*`` routes end-to-end:
  * Requesters can request, list-own, and cancel their own pending request.
  * Admins (master key) can list pending, approve, and deny.
  * The auth resolver honours an approved-and-unexpired elevation (verified
    by forcing Kimi from an L1-base dev that was approved up to L2_senior).
  * Self-approval is rejected.
  * Expired approvals no longer elevate (we mutate ``expires_at`` directly).
  * Validation: unknown tier (400), out-of-range duration (400), duplicate (409).
  * Concurrent approvals on the same row produce exactly one winner (TOCTOU).
  * Stale pending requests auto-cancel and stop blocking fresh ones.
  * /elevation/request enforces a per-user burst limit (429).
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timedelta, timezone

import pytest
import pytest_asyncio

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest_asyncio.fixture
async def clean_elevations():
    """Truncate elevation_requests between tests so IDs / state are deterministic.

    Mirrors the pattern used by ``clean_audit_db`` in conftest.py.
    """
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    async with eng.begin() as conn:
        await conn.execute(text("TRUNCATE TABLE elevation_requests RESTART IDENTITY"))
    yield
    await eng.dispose()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
async def _request_elevation(client, *, headers, requested_tier="L2_senior",
                             duration_minutes=60, reason="need Kimi for refactor"):
    return await client.post(
        "/admin/elevation/request",
        headers=headers,
        json={"requested_tier":   requested_tier,
              "duration_minutes": duration_minutes,
              "reason":           reason},
    )


# ---------------------------------------------------------------------------
# Request + listing
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_dev_can_request_and_appears_in_pending(gateway_client, clean_elevations):
    """A dev requests elevation; admin sees the row in /pending."""
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="alice")
    r = await _request_elevation(gateway_client, headers=h)
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["user_id"]        == "alice"
    assert body["team_id"]        == "backend-engineering"
    assert body["base_tier"]      == "L1_standard"
    assert body["requested_tier"] == "L2_senior"
    assert body["status"]         == "pending"
    assert body["decided_at"]    is None
    assert body["expires_at"]    is None
    elev_id = body["id"]

    # Admin sees it in /pending.
    r = await gateway_client.get("/admin/elevation/pending", headers=MASTER)
    assert r.status_code == 200, r.text
    rows = r.json()
    assert any(row["id"] == elev_id and row["user_id"] == "alice" for row in rows)

    # The requester also sees it under /mine.
    r = await gateway_client.get("/admin/elevation/mine", headers=h)
    assert r.status_code == 200, r.text
    mine = r.json()
    assert any(row["id"] == elev_id for row in mine)


@pytest.mark.asyncio
async def test_duplicate_request_while_pending_is_409(gateway_client, clean_elevations):
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="dup.user")
    r = await _request_elevation(gateway_client, headers=h)
    assert r.status_code == 201, r.text

    # Second request while the first is still pending → 409.
    r2 = await _request_elevation(gateway_client, headers=h, reason="please again")
    assert r2.status_code == 409, r2.text


@pytest.mark.asyncio
async def test_duplicate_request_while_active_is_409(gateway_client, clean_elevations):
    """Once approved-and-unexpired, a fresh request is still a duplicate."""
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="dup.active")
    r = await _request_elevation(gateway_client, headers=h)
    assert r.status_code == 201
    elev_id = r.json()["id"]

    # Admin approves.
    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/approve", headers=MASTER, json={},
    )
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "approved"

    # Another request — still 409, because the previous one is active.
    r2 = await _request_elevation(gateway_client, headers=h, reason="even more access")
    assert r2.status_code == 409, r2.text


# ---------------------------------------------------------------------------
# Approve → tier actually changes on subsequent calls
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_approval_elevates_subsequent_calls(gateway_client, clean_elevations):
    """L1-base dev requests L2; once approved, force:kimi-k2.6 succeeds where
    it would normally 422 (policy_refused) at L1."""
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="climber")

    # Baseline: at L1 base, force:kimi-k2.6 is refused (override_model=false).
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=h,
        json={"messages": [{"role": "user", "content": "explain monads"}],
              "model":    "force:kimi-k2.6"},
    )
    assert r.status_code == 422, r.text

    # Request elevation to L2_senior.
    r = await _request_elevation(gateway_client, headers=h, requested_tier="L2_senior")
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    # Admin approves.
    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/approve",
        headers=MASTER,
        json={"decision_note": "OK for one hour"},
    )
    assert r.status_code == 200, r.text
    approved = r.json()
    assert approved["status"]           == "approved"
    assert approved["approver_user_id"] == "master"
    assert approved["decision_note"]    == "OK for one hour"
    assert approved["expires_at"]       is not None

    # Now the same dev token resolves to L2_senior on the auth path.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=h,
        json={"messages": [{"role": "user", "content": "explain monads"}],
              "model":    "force:kimi-k2.6"},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "kimi-k2.6"


# ---------------------------------------------------------------------------
# Deny
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_deny_keeps_base_tier(gateway_client, clean_elevations):
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="denied.user")
    r = await _request_elevation(gateway_client, headers=h, requested_tier="L2_senior")
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/deny",
        headers=MASTER,
        json={"decision_note": "Not justified"},
    )
    assert r.status_code == 200, r.text
    denied = r.json()
    assert denied["status"]           == "denied"
    assert denied["approver_user_id"] == "master"
    assert denied["decision_note"]    == "Not justified"
    assert denied["expires_at"]      is None

    # Force-Kimi from L1 base still 422 — no elevation took effect.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=h,
        json={"messages": [{"role": "user", "content": "hi"}],
              "model":    "force:kimi-k2.6"},
    )
    assert r.status_code == 422, r.text


# ---------------------------------------------------------------------------
# Self-approval
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_self_approval_is_rejected(gateway_client, clean_elevations):
    """The requester cannot also be the approver — dual-control.

    Uses a real DB key with ``role='admin'`` (dev tokens carry no admin
    role since the security tightening). The key sits on backend-engineering
    (L1_standard), so the L1 → L2 ladder transition is valid; the failure
    must come from the dual-control check, not the ladder rule.
    """
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id":    "selfie",
              "team_id":    "backend-engineering",
              "role":       "admin",
              "user_email": "selfie@example.com"},
    )
    assert r.status_code == 201, r.text
    raw_key = r.json()["raw_key"]
    selfie_hdr = {"Authorization": f"Bearer {raw_key}",
                  "Content-Type":  "application/json"}

    # selfie requests a valid L1 -> L2 elevation for themselves.
    r = await _request_elevation(
        gateway_client, headers=selfie_hdr,
        requested_tier="L2_senior", reason="self-approval attempt",
    )
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    # selfie tries to approve their own request. admin role passes the
    # route-level require_admin, but the service layer rejects with 403.
    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/approve",
        headers=selfie_hdr,
        json={"decision_note": "self approve"},
    )
    assert r.status_code == 403, r.text
    assert "requester" in r.json()["detail"].lower() \
        or "approver" in r.json()["detail"].lower()


# ---------------------------------------------------------------------------
# Cancel
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_requester_can_cancel_their_pending(gateway_client, clean_elevations):
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="canceller")
    r = await _request_elevation(gateway_client, headers=h)
    assert r.status_code == 201
    elev_id = r.json()["id"]

    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/cancel", headers=h,
    )
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "cancelled"

    # /pending no longer lists it.
    r = await gateway_client.get("/admin/elevation/pending", headers=MASTER)
    assert r.status_code == 200
    assert all(row["id"] != elev_id for row in r.json())


@pytest.mark.asyncio
async def test_other_user_cannot_cancel(gateway_client, clean_elevations):
    h_owner   = dev_headers(team="backend-engineering", tier="L1_standard", user="owner")
    h_stranger = dev_headers(team="backend-engineering", tier="L1_standard", user="stranger")

    r = await _request_elevation(gateway_client, headers=h_owner)
    assert r.status_code == 201
    elev_id = r.json()["id"]

    # A different user cannot cancel it.
    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/cancel", headers=h_stranger,
    )
    assert r.status_code == 403, r.text

    # Still pending.
    r = await gateway_client.get("/admin/elevation/mine", headers=h_owner)
    assert r.status_code == 200
    mine = r.json()
    rows = [row for row in mine if row["id"] == elev_id]
    assert rows and rows[0]["status"] == "pending"


# ---------------------------------------------------------------------------
# Expiry — approved + expires_at in the past must NOT elevate
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_expired_approval_no_longer_elevates(gateway_client, clean_elevations):
    """Approve, then back-date expires_at; the next chat call must see the
    base tier again (force:kimi-k2.6 from L1 → 422)."""
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="expiring")

    r = await _request_elevation(gateway_client, headers=h, requested_tier="L2_senior")
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/approve", headers=MASTER, json={},
    )
    assert r.status_code == 200, r.text

    # Sanity: while live, force:kimi works.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=h,
        json={"messages": [{"role": "user", "content": "hi"}],
              "model":    "force:kimi-k2.6"},
    )
    assert r.status_code == 200, r.text
    assert r.headers["X-LLM-Model-Used"] == "kimi-k2.6"

    # Back-date expires_at to one minute ago, directly in Postgres.
    from sqlalchemy import update
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    from gateway.models import ElevationRequest

    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    Session = async_sessionmaker(eng, expire_on_commit=False)
    expired_at = datetime.now(timezone.utc) - timedelta(minutes=1)
    try:
        async with Session() as s:
            await s.execute(
                update(ElevationRequest)
                .where(ElevationRequest.id == elev_id)
                .values(expires_at=expired_at)
            )
            await s.commit()
    finally:
        await eng.dispose()

    # Now the same dev token must fall back to L1 — force:kimi → 422.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=h,
        json={"messages": [{"role": "user", "content": "hi"}],
              "model":    "force:kimi-k2.6"},
    )
    assert r.status_code == 422, r.text
    assert r.json()["error"]["code"] == "policy_refused"


# ---------------------------------------------------------------------------
# Validation — unknown tier / out-of-range duration
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_unknown_requested_tier_returns_400(gateway_client, clean_elevations):
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="badtier")
    r = await _request_elevation(
        gateway_client, headers=h, requested_tier="L9_does_not_exist",
    )
    assert r.status_code == 400, r.text
    assert "policies.yaml" in r.json()["detail"] \
        or "not in" in r.json()["detail"].lower()


@pytest.mark.asyncio
async def test_duration_below_minimum_returns_400(gateway_client, clean_elevations):
    """Pydantic ge=15 on the route guards this; the response is 422 from
    FastAPI's validator. The service layer enforces the same bound and would
    raise 400 if Pydantic were bypassed — we accept either to keep the test
    robust against schema tweaks."""
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="shortdur")
    r = await _request_elevation(
        gateway_client, headers=h, duration_minutes=5,
    )
    assert r.status_code in (400, 422), r.text


@pytest.mark.asyncio
async def test_duration_above_maximum_returns_400(gateway_client, clean_elevations):
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="longdur")
    r = await _request_elevation(
        gateway_client, headers=h, duration_minutes=60 * 24 + 1,
    )
    assert r.status_code in (400, 422), r.text


# ---------------------------------------------------------------------------
# Authorisation — /pending is admin-only
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_pending_listing_requires_admin(gateway_client, clean_elevations):
    # Dev token (no admin role) → 403.
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="peeker")
    r = await gateway_client.get("/admin/elevation/pending", headers=h)
    assert r.status_code == 403, r.text
    # Master key works.
    r = await gateway_client.get("/admin/elevation/pending", headers=MASTER)
    assert r.status_code == 200, r.text


# ---------------------------------------------------------------------------
# TOCTOU — concurrent approvals on the same row
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_concurrent_approvals_only_one_wins(gateway_client, clean_elevations):
    """Two simultaneous approvals on the same pending elevation must result
    in exactly one 200 and one 409.

    Without ``SELECT ... FOR UPDATE`` in ``_get``, both transactions could
    read ``status='pending'`` before either commits, both flip it, and the
    later commit silently overwrites the earlier approver_user_id without
    raising. Closes the security-review TOCTOU finding."""
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="racer")
    r = await _request_elevation(gateway_client, headers=h)
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    # A second admin so dual-control doesn't reject either approve call.
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id":    "admin_b",
              "team_id":    "backend-engineering",
              "role":       "admin",
              "user_email": "admin_b@example.com"},
    )
    assert r.status_code == 201, r.text
    admin_b = {"Authorization": f"Bearer {r.json()['raw_key']}",
               "Content-Type":  "application/json"}

    r_master, r_admin_b = await asyncio.gather(
        gateway_client.post(f"/admin/elevation/{elev_id}/approve",
                            headers=MASTER, json={}),
        gateway_client.post(f"/admin/elevation/{elev_id}/approve",
                            headers=admin_b, json={}),
    )
    statuses = sorted([r_master.status_code, r_admin_b.status_code])
    assert statuses == [200, 409], (
        f"expected one approve to win and one to see invalid-transition; "
        f"got {statuses}; master={r_master.text!r}, admin_b={r_admin_b.text!r}"
    )

    # The winner's approver_user_id is durable — neither overwrote the other.
    r = await gateway_client.get("/admin/elevation/mine", headers=h)
    rows = [row for row in r.json() if row["id"] == elev_id]
    assert rows and rows[0]["status"] == "approved"
    assert rows[0]["approver_user_id"] in ("master", "admin_b")


# ---------------------------------------------------------------------------
# Stale-pending TTL — auto-cancel forgotten pending rows
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_stale_pending_auto_cancelled_on_next_request(
    gateway_client, clean_elevations,
):
    """A pending request older than the TTL must not block the user from
    submitting a fresh one — it auto-cancels lazily on the next request."""
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    user = "forgotten_user"
    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    stale_when = datetime.now(timezone.utc) - timedelta(hours=48)
    try:
        async with eng.begin() as conn:
            await conn.execute(text("""
                INSERT INTO elevation_requests
                (user_id, user_email, team_id, base_tier, requested_tier,
                 duration_minutes, reason, status, requested_at)
                VALUES
                (:u, :em, 'backend-engineering', 'L1_standard', 'L2_senior',
                 60, 'old', 'pending', :rwhen)
            """), {"u": user, "em": f"{user}@dev.local", "rwhen": stale_when})
    finally:
        await eng.dispose()

    # Fresh request must succeed (NOT 409) because the stale one was swept.
    h = dev_headers(team="backend-engineering", tier="L1_standard", user=user)
    r = await _request_elevation(gateway_client, headers=h, reason="fresh attempt")
    assert r.status_code == 201, r.text
    new_id = r.json()["id"]

    # The stale row is now cancelled with a TTL marker.
    r = await gateway_client.get("/admin/elevation/mine", headers=h)
    assert r.status_code == 200, r.text
    mine = r.json()
    stale_rows = [row for row in mine if row["id"] != new_id]
    assert len(stale_rows) == 1, mine
    assert stale_rows[0]["status"] == "cancelled"
    assert "ttl" in (stale_rows[0]["decision_note"] or "").lower()

    # And /pending no longer surfaces stale rows even if they were still
    # status='pending' — the route filters by age too.
    r = await gateway_client.get("/admin/elevation/pending", headers=MASTER)
    assert r.status_code == 200
    assert all(row["id"] != stale_rows[0]["id"] for row in r.json()), (
        "stale pending was leaking into /pending"
    )


# ---------------------------------------------------------------------------
# Burst limit — DoS protection on /elevation/request
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_request_burst_returns_429(gateway_client, clean_elevations):
    """A user who hammers /elevation/request gets 429 after the burst limit.

    Cancelling between attempts must not reset the counter — the limit
    counts attempts in the window regardless of status, so cancel-and-retry
    can't be used to bypass it."""
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="burster")

    # First 5 attempts succeed (cancel each so duplicate doesn't trip).
    for i in range(5):
        r = await _request_elevation(gateway_client, headers=h, reason=f"attempt {i}")
        assert r.status_code == 201, f"attempt {i}: {r.text}"
        rc = await gateway_client.post(
            f"/admin/elevation/{r.json()['id']}/cancel", headers=h,
        )
        assert rc.status_code == 200, rc.text

    # 6th hits the burst limit even though no request is currently open.
    r = await _request_elevation(gateway_client, headers=h, reason="6th")
    assert r.status_code == 429, r.text
    msg = r.json()["detail"].lower()
    assert "too many" in msg and "elevation" in msg
    assert r.headers.get("Retry-After") is not None


# ---------------------------------------------------------------------------
# UEBA — admin-flow signals raised by elevations service
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_self_approval_attempt_raises_ueba_alert(
    gateway_client, clean_elevations, clean_ueba,
):
    """A self-approval attempt must produce a critical UEBA alert.

    Threshold for ``elevation_self_approval_attempts`` is 1/day, so the very
    first attempt fires. Closes the loop on dual-control: the API refuses
    AND the SOC gets a row in ueba_alerts for investigation."""
    # Real DB key with admin role so the route's require_admin passes; the
    # service-layer dual-control check is what we're verifying triggers UEBA.
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id":    "ueba_self",
              "team_id":    "backend-engineering",
              "role":       "admin",
              "user_email": "ueba_self@example.com"},
    )
    assert r.status_code == 201, r.text
    raw_key = r.json()["raw_key"]
    self_hdr = {"Authorization": f"Bearer {raw_key}",
                "Content-Type":  "application/json"}

    r = await _request_elevation(
        gateway_client, headers=self_hdr,
        requested_tier="L2_senior", reason="ueba self-approve probe",
    )
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/approve",
        headers=self_hdr,
        json={"decision_note": "self approve"},
    )
    assert r.status_code == 403, r.text

    # Alert appears in /admin/ueba/alerts with the expected signal + severity.
    r = await gateway_client.get(
        "/admin/ueba/alerts?status=open", headers=MASTER,
    )
    assert r.status_code == 200, r.text
    alerts = r.json()["alerts"]
    matching = [
        a for a in alerts
        if a["signal"]   == "elevation_self_approval_attempts"
        and a["user_id"] == "ueba_self"
    ]
    assert matching, f"no UEBA alert raised; got: {alerts}"
    assert matching[0]["severity"] == "critical"


# ---------------------------------------------------------------------------
# Observability — /metrics surfaces elevation lifecycle events
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_metrics_surface_elevation_events(gateway_client, clean_elevations):
    """Each lifecycle event (requested, approved, cancelled, burst_limited,
    self_approval_rejected, etc.) increments gateway_elevation_events_total
    labeled by event. Verifying the labels appear in /metrics is enough —
    Prometheus scrapes the exposition format, so the contract is the text
    output itself."""
    # Drive at least three distinct event types so the test catches a
    # regression where one of the emit calls gets dropped.
    h = dev_headers(team="backend-engineering", tier="L1_standard", user="metrics_user")
    r = await _request_elevation(gateway_client, headers=h)
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/cancel", headers=h,
    )
    assert r.status_code == 200, r.text

    # A duplicate attempt on a fresh request would need another user; instead
    # we cancel-then-resubmit. The first re-request is allowed (the prior
    # was cancelled, not active). Cancel that too.
    r = await _request_elevation(gateway_client, headers=h, reason="second")
    assert r.status_code == 201, r.text
    await gateway_client.post(f"/admin/elevation/{r.json()['id']}/cancel", headers=h)

    # Scrape /metrics — prometheus_client returns plain-text exposition.
    # The endpoint is mounted at /metrics so the ASGI sub-app responds at
    # /metrics/; httpx doesn't follow redirects by default.
    r = await gateway_client.get("/metrics", follow_redirects=True)
    assert r.status_code == 200, r.text
    body = r.text
    assert "gateway_elevation_events_total" in body, (
        "elevation events counter missing from /metrics"
    )
    # At least the requested + cancelled labels should be present and >0.
    assert 'gateway_elevation_events_total{event="requested"}' in body, body[:2000]
    assert 'gateway_elevation_events_total{event="cancelled"}' in body, body[:2000]


# ---------------------------------------------------------------------------
# Authorisation
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_non_admin_cannot_approve(gateway_client, clean_elevations):
    """A non-admin dev token gets 403 even on a real elevation id."""
    requester = dev_headers(team="backend-engineering", tier="L1_standard", user="req")
    r = await _request_elevation(gateway_client, headers=requester)
    assert r.status_code == 201, r.text
    elev_id = r.json()["id"]

    rando = dev_headers(team="backend-engineering", tier="L1_standard", user="rando")
    r = await gateway_client.post(
        f"/admin/elevation/{elev_id}/approve", headers=rando, json={},
    )
    assert r.status_code == 403, r.text
