"""Tests for the five lightweight additions shipped in Sprint 5:

1. ``GET /v1/models`` — OpenAI-compatible model listing (no auth scope leak).
2. Key expiry — ``virtual_keys.expires_at`` is enforced on the request path.
3. ``GET /admin/metrics/cost-forecast`` — projection endpoint shape.
4. Rate-limit headers (``X-RateLimit-*``, ``X-Daily-Budget-*``) on every
   completion response — refusal AND allow paths.
5. ``POST /admin/models/{id}/ping`` — one-shot availability probe.

Each test is hermetic: it cleans the relevant table, exercises ONE behaviour,
and asserts only on what that behaviour produces. No cross-test ordering
assumptions.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from .conftest import dev_headers


MASTER = {"Authorization": "Bearer sk-master-dev", "Content-Type": "application/json"}


# ---------------------------------------------------------------------------
# 1. GET /v1/models — OpenAI-compatible listing
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_v1_models_lists_seeded_models_for_dev_token(gateway_client):
    """``GET /v1/models`` is the standard OpenAI discovery endpoint — clients
    like Cline / Continue.dev call it to populate their model picker. It must
    accept any authenticated principal (not just admins) so a developer key
    can list the models it's allowed to call."""
    r = await gateway_client.get("/v1/models",
                                 headers=dev_headers(team="backend-engineering"))
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["object"] == "list"
    assert isinstance(body["data"], list)
    assert body["data"], "expected at least one model on a fresh boot"
    sample = body["data"][0]
    # OpenAI's shape: id / object / created / owned_by.
    assert {"id", "object", "owned_by"} <= sample.keys(), sample
    assert sample["object"] == "model"
    ids = {m["id"] for m in body["data"]}
    assert {"kimi-k2.6", "qwen3-coder-30b", "gemma-4-27b"} <= ids, ids


@pytest.mark.asyncio
async def test_v1_models_requires_auth(gateway_client):
    """No bearer → 401 (parity with /v1/chat/completions)."""
    r = await gateway_client.get("/v1/models")
    assert r.status_code == 401, r.text


# ---------------------------------------------------------------------------
# 2. Key expiry — expired virtual_keys are rejected at auth time
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_expired_key_returns_401(gateway_client, clean_keys):
    """An ``expires_at`` in the past must reject the request — silently
    accepting was the gap the security review flagged."""
    expired = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id": "ephemeral", "team_id": "backend-engineering",
              "user_email": "e@example.com", "expires_at": expired},
    )
    assert r.status_code == 201, r.text
    raw = r.json()["raw_key"]

    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={"Authorization": f"Bearer {raw}",
                 "Content-Type": "application/json"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 401, r.text
    assert "expired" in r.text.lower(), r.text


@pytest.mark.asyncio
async def test_unexpired_key_still_works(gateway_client, clean_keys):
    """An ``expires_at`` in the future must NOT trigger the expiry check —
    sanity guard against an off-by-one (e.g. comparing on naive datetimes)."""
    future = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
    r = await gateway_client.post(
        "/admin/keys",
        headers=MASTER,
        json={"user_id": "future-key", "team_id": "backend-engineering",
              "user_email": "f@example.com", "expires_at": future},
    )
    assert r.status_code == 201, r.text
    raw = r.json()["raw_key"]

    r = await gateway_client.post(
        "/v1/chat/completions",
        headers={"Authorization": f"Bearer {raw}",
                 "Content-Type": "application/json"},
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text


# ---------------------------------------------------------------------------
# 3. Cost-forecast endpoint
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_cost_forecast_returns_zero_on_clean_db(gateway_client, clean_audit_db):
    """Fresh install → all zeros, no errors. The endpoint must never 500
    just because the audit table is empty."""
    r = await gateway_client.get(
        "/admin/metrics/cost-forecast?window_days=7&projection_days=30",
        headers=MASTER,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["window_days"]    == 7
    assert body["projection_days"] == 30
    assert body["cost_window_usd"] == 0.0
    assert body["cost_per_day"]    == 0.0
    assert body["projected_usd"]   == 0.0
    assert body["by_team"]  == []
    assert body["by_model"] == []
    assert body["rows_considered"] == 0


@pytest.mark.asyncio
async def test_cost_forecast_requires_admin(gateway_client):
    r = await gateway_client.get(
        "/admin/metrics/cost-forecast",
        headers=dev_headers(),
    )
    assert r.status_code == 403, r.text


# ---------------------------------------------------------------------------
# 4. Rate-limit headers on completion responses
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_rate_limit_headers_on_allow(gateway_client, clean_quotas):
    """A successful (non-cached) completion must surface X-RateLimit-Limit /
    Remaining / Reset so clients can self-throttle without hitting a 429."""
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(team="backend-engineering"),
        json={"messages": [{"role": "user", "content": "hi"}]},
    )
    assert r.status_code == 200, r.text
    # At minimum one rate-limit triple must be present. Daily-budget
    # headers are tier-dependent so we don't hard-require them here.
    assert "X-RateLimit-Limit" in r.headers, dict(r.headers)
    assert "X-RateLimit-Remaining" in r.headers, dict(r.headers)
    assert "X-RateLimit-Reset" in r.headers, dict(r.headers)
    # Sanity: limit is a positive int, remaining ∈ [0, limit].
    limit     = int(r.headers["X-RateLimit-Limit"])
    remaining = int(r.headers["X-RateLimit-Remaining"])
    assert limit > 0
    assert 0 <= remaining <= limit


# ---------------------------------------------------------------------------
# 5. POST /admin/models/{id}/ping — availability probe
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_ping_seeded_model_returns_ok(gateway_client):
    """The seeded models point at mock-vllm, so a ping must come back ok=True
    with a positive latency."""
    r = await gateway_client.get("/admin/models", headers=MASTER)
    assert r.status_code == 200, r.text
    gemma_id = next(row["id"] for row in r.json()
                    if row["model_name"] == "gemma-4-27b")

    r = await gateway_client.post(f"/admin/models/{gemma_id}/ping", headers=MASTER)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["model_id"]   == gemma_id
    assert body["model_name"] == "gemma-4-27b"
    assert body["ok"] is True
    assert body["latency_ms"] >= 0
    assert body["error"] is None


@pytest.mark.asyncio
async def test_ping_missing_model_returns_404(gateway_client):
    r = await gateway_client.post("/admin/models/999999/ping", headers=MASTER)
    assert r.status_code == 404, r.text


@pytest.mark.asyncio
async def test_ping_requires_admin(gateway_client):
    r = await gateway_client.post("/admin/models/1/ping", headers=dev_headers())
    assert r.status_code == 403, r.text
