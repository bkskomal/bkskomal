"""Output-side secret scan.

The mock vLLM echoes the user prompt back in its response. We exploit that
to deliver "the model returned a secret" — the prompt contains a fake
credential which the input DLP is intentionally disabled for in tests, so it
reaches the mock unaltered, and the output_scan_secrets plugin sees it on
the way back.
"""

from __future__ import annotations

import asyncio

import pytest

from .conftest import dev_headers


# Real AWS keys are AKIA + 16 alphanumerics = 20 chars total. This is a
# pattern-conforming fixture that is NEVER a real credential.
FAKE_AWS_KEY = "AKIAEXAMPLEAAAAAAAAA"  # 4 + 16
FAKE_GITHUB_PAT = "ghp_" + "A" * 36     # ghp_ + 36 chars
assert len(FAKE_AWS_KEY) == 20
assert len(FAKE_GITHUB_PAT) == 40


@pytest.mark.asyncio
async def test_secret_in_response_is_redacted(gateway_client):
    # Send a prompt that the mock will echo back unchanged. The post-call
    # scan should detect the AWS key in the response and redact it.
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(tier="L2_senior"),
        json={"messages": [{"role": "user",
                            "content": f"Echo the following: {FAKE_AWS_KEY}"}]},
    )
    assert r.status_code == 422 or r.status_code == 200, r.text
    # Critical secrets always force REFUSE. The plugin replaces the response
    # body with an error payload listing the findings; check both shapes.
    if r.status_code == 422:
        body = r.json()
        assert body["error"]["code"] in ("output_blocked_by_policy", "policy_refused")
        finding_kinds = {f["kind"] for f in body["error"].get("findings", [])}
        assert "secret.aws.access_key_id" in finding_kinds
    else:
        # If the policy ever flips to redact for this kind, the assistant
        # content must NOT contain the literal key.
        content = r.json()["choices"][0]["message"]["content"]
        assert FAKE_AWS_KEY not in content
        assert "[REDACTED:aws.access_key_id]" in content


@pytest.mark.asyncio
async def test_github_pat_in_response_is_blocked(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(tier="L2_senior"),
        json={"messages": [{"role": "user",
                            "content": f"Repeat: {FAKE_GITHUB_PAT}"}]},
    )
    # Either 422 (refuse) or 200 with redacted content — both prove the leak
    # never reaches the developer verbatim.
    if r.status_code == 200:
        content = r.json()["choices"][0]["message"]["content"]
        assert FAKE_GITHUB_PAT not in content
    else:
        assert r.status_code == 422


@pytest.mark.asyncio
async def test_clean_response_passes_through(gateway_client):
    r = await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(tier="L2_senior"),
        json={"messages": [{"role": "user", "content": "what is 2+2"}]},
    )
    assert r.status_code == 200, r.text
    content = r.json()["choices"][0]["message"]["content"]
    assert "[REDACTED" not in content


@pytest.mark.asyncio
async def test_secret_leak_is_audited(gateway_client, clean_audit_db):
    await gateway_client.post(
        "/v1/chat/completions",
        headers=dev_headers(tier="L2_senior"),
        json={"messages": [{"role": "user",
                            "content": f"Echo this back: {FAKE_AWS_KEY}"}]},
    )
    await asyncio.sleep(0.2)
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    import os
    eng = create_async_engine(os.environ["GATEWAY_AUDIT_DB_URL"], future=True)
    async with eng.begin() as conn:
        rows = (await conn.execute(text(
            "SELECT findings FROM audit_log ORDER BY id DESC LIMIT 1"
        ))).mappings().all()
    await eng.dispose()
    assert len(rows) == 1
    findings = rows[0]["findings"] or []
    assert any(
        f.get("plugin") == "output_scan_secrets" and
        f.get("kind",  "").startswith("secret.aws")
        for f in findings
    )
