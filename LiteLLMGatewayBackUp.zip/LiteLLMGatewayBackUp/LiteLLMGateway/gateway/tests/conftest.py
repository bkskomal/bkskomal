"""Shared pytest fixtures.

Spins up the mock vLLM in a background uvicorn server and runs the gateway
in-process via httpx's ASGITransport so request flow gets the real plugin
chain without binding the gateway to a TCP port.

The gateway uses *real* Postgres for the audit DB (tests run only on machines
where Postgres is reachable; the test DB is wiped at session start) and *real*
Redis if available — falls back to in-memory for the smoke tests below.

URL-encode the password in GATEWAY_AUDIT_DB_URL — special chars (#, @) are
URL-significant and asyncpg will reject them otherwise.
"""

from __future__ import annotations

import asyncio
import os
import socket
import sys
import threading
import time
from pathlib import Path

import pytest
import pytest_asyncio
import uvicorn

# --- 1. Test environment ---------------------------------------------------
# Tests use dedicated *_test databases to avoid wiping live data.
# We force-set (not setdefault) so a leaked env var from the user's shell
# can't redirect tests at the live gateway DBs. Tests must be deterministic.
# Choose a Postgres password URL-encoded for asyncpg DSNs.
_PG_USER = os.environ.get("PYTEST_PG_USER", "postgres")
_PG_PASS = os.environ.get("PYTEST_PG_PASS", "Godis1%40321%23")  # already URL-encoded
_PG_HOST = os.environ.get("PYTEST_PG_HOST", "localhost")

_GATEWAY_DB_NAME = "litellm_gateway_test"
_AUDIT_DB_NAME = "litellm_gateway_audit_test"

os.environ["GATEWAY_DB_URL"] = (
    f"postgresql+asyncpg://{_PG_USER}:{_PG_PASS}@{_PG_HOST}:5432/{_GATEWAY_DB_NAME}"
)
os.environ["GATEWAY_AUDIT_DB_URL"] = (
    f"postgresql+asyncpg://{_PG_USER}:{_PG_PASS}@{_PG_HOST}:5432/{_AUDIT_DB_NAME}"
)
# Tests use the in-memory counter fallback so they're hermetic — no Redis
# container needed. The "memory://" scheme is recognised by quota_redis.
os.environ["GATEWAY_REDIS_URL"] = "memory://"
os.environ.setdefault("GATEWAY_PLUGINS",
    "authz_tiered,quota_redis,guardrail_patterns,router_rule_based,"
    "output_scan_secrets,observe_ueba,audit_postgres,cache_redis,"
    "cache_semantic,siem_forward")

# Tests use a self-contained litellm config that points ALL THREE models at
# the mock-vllm backend (avoids any outbound network for Kimi via OpenRouter).
_TEST_LITELLM_CFG = Path(__file__).parent / "_test_litellm_config.yaml"
os.environ["GATEWAY_LITELLM_CONFIG_PATH"] = str(_TEST_LITELLM_CFG)
# Tests use a dedicated policies file (_test_policies.yaml) that pins the
# OLD cloud-first model names (gemma-4-27b, qwen3-coder-30b, kimi-k2.6) and
# matching router rules. The shipped gateway/policies.yaml prefers local
# Ollama models (qwen2.5-coder-7b/1.5b) for the dev box story; integration
# tests need deterministic routes that match what mock-vllm serves.
os.environ.setdefault("GATEWAY_POLICIES_PATH",
    str(Path(__file__).parent / "_test_policies.yaml"))
os.environ.setdefault("OPENROUTER_API_KEY", "dummy")
# These are overridden to the mock-vllm port once the fixture allocates it.
os.environ.setdefault("VLLM_QWEN3_BASE",  "http://localhost:0/v1")
os.environ.setdefault("VLLM_GEMMA4_BASE", "http://localhost:0/v1")

# Clear the settings cache so the new env vars take effect.
from gateway.config import get_settings  # noqa: E402
get_settings.cache_clear()


# --- 2. Mock vLLM in a background uvicorn server --------------------------
def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class _BackgroundServer:
    """Tiny wrapper that runs uvicorn in a thread for the test session."""

    def __init__(self, app, host: str, port: int) -> None:
        self.host = host
        self.port = port
        cfg = uvicorn.Config(app, host=host, port=port, log_level="warning",
                             loop="asyncio")
        self.server = uvicorn.Server(cfg)
        self._thread = threading.Thread(target=self.server.run, daemon=True)

    def start(self) -> None:
        self._thread.start()
        # Wait for the port to start accepting connections.
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            try:
                with socket.create_connection((self.host, self.port), timeout=0.3):
                    return
            except OSError:
                time.sleep(0.1)
        raise RuntimeError(f"Background server never came up on :{self.port}")

    def stop(self) -> None:
        self.server.should_exit = True
        self._thread.join(timeout=5)


@pytest.fixture(scope="session")
def mock_vllm():
    """Bring up a deterministic OpenAI-compatible backend on a free port.

    Both Qwen3 and Gemma 4 base URLs in the gateway's litellm_config.yaml
    point here, so the same mock answers both routes.
    """
    # Make sure mock_vllm is importable. It lives at ../../mock-vllm/src.
    root = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(root / "mock-vllm" / "src"))
    from mock_vllm.main import app as mock_app

    port = _free_port()
    server = _BackgroundServer(mock_app, "127.0.0.1", port)
    server.start()

    # Re-point the gateway's backends at this mock.
    base = f"http://127.0.0.1:{port}/v1"
    os.environ["VLLM_QWEN3_BASE"]  = base
    os.environ["VLLM_GEMMA4_BASE"] = base
    os.environ["OPENROUTER_API_KEY"] = "dummy"

    yield {"host": "127.0.0.1", "port": port, "base_url": base}

    server.stop()


# --- 3. Async gateway client (in-process ASGI) ----------------------------
@pytest_asyncio.fixture
async def gateway_client(mock_vllm):
    """Yields an httpx.AsyncClient bound directly to the gateway's ASGI app.

    LifespanManager runs the FastAPI startup/shutdown hooks so plugins
    register, LiteLLM router initialises, and the audit DB connects exactly
    once per test.
    """
    import httpx
    from asgi_lifespan import LifespanManager
    from gateway.main import app as gateway_app

    async with LifespanManager(gateway_app) as mgr:
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=mgr.app),
            base_url="http://gateway.test",
            timeout=30,
        ) as client:
            yield client


# --- 4. Per-test audit-DB cleaner -----------------------------------------
@pytest_asyncio.fixture
async def clean_audit_db():
    """Truncate audit_log between tests so assertions are deterministic."""
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    async with eng.begin() as conn:
        await conn.execute(text("TRUNCATE TABLE audit_log RESTART IDENTITY"))
    yield
    await eng.dispose()


# --- 4a. Ensure the *_test databases exist before anything else ----------
@pytest_asyncio.fixture(scope="session", autouse=True)
async def ensure_test_databases():
    """Create litellm_gateway_test / litellm_gateway_audit_test if missing.

    Postgres has no `CREATE DATABASE IF NOT EXISTS`, so we connect to the
    `postgres` admin DB, look the names up in `pg_database`, and CREATE
    only when absent. Idempotent: re-runs no-op when DBs already exist.
    Runs before `wipe_gateway_db` so the wipe always finds real targets.
    """
    import asyncpg
    from urllib.parse import unquote

    pg_pass_decoded = unquote(_PG_PASS)
    conn = await asyncpg.connect(
        host=_PG_HOST,
        user=_PG_USER,
        password=pg_pass_decoded,
        database="postgres",
    )
    try:
        for db_name in (_GATEWAY_DB_NAME, _AUDIT_DB_NAME):
            exists = await conn.fetchval(
                "SELECT 1 FROM pg_database WHERE datname = $1", db_name
            )
            if not exists:
                # db_name is a hardcoded module-level constant, safe to inline.
                await conn.execute(f'CREATE DATABASE "{db_name}"')
    finally:
        await conn.close()
    yield


# --- 4b. Wipe operational DB once before the whole session ----------------
@pytest_asyncio.fixture(scope="session", autouse=True)
async def wipe_gateway_db(ensure_test_databases):
    """Drop virtual_keys + teams + ueba_alerts before the session so seeding
    is deterministic. The gateway's own lifespan recreates them via
    Base.metadata.create_all, then seeds teams from policies.yaml.
    """
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    async with eng.begin() as conn:
        await conn.execute(text("DROP TABLE IF EXISTS virtual_keys CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS teams CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS ueba_alerts CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS elevation_requests CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS litellm_models CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS tier_configs CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS guardrail_patterns CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS plugin_configs CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS audit_reveal_requests CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS router_rule_overrides CASCADE"))
        await conn.execute(text("DROP TABLE IF EXISTS system_settings CASCADE"))
    # Audit DB also needs a session-level wipe so the new base_tier /
    # elevation_id columns get created cleanly via the lifespan.
    audit_dsn = os.environ["GATEWAY_AUDIT_DB_URL"]
    audit_eng = create_async_engine(audit_dsn, future=True)
    async with audit_eng.begin() as conn:
        await conn.execute(text("DROP TABLE IF EXISTS audit_log CASCADE"))
    await audit_eng.dispose()
    yield
    await eng.dispose()


# --- 4c. Per-test virtual_keys cleaner ------------------------------------
@pytest_asyncio.fixture
async def clean_keys():
    """Truncate virtual_keys between key-related tests."""
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    async with eng.begin() as conn:
        await conn.execute(text("TRUNCATE TABLE virtual_keys RESTART IDENTITY"))
    yield
    await eng.dispose()


# --- 4d-bis. Per-test UEBA counter + alerts cleaner -----------------------
@pytest_asyncio.fixture
async def clean_ueba():
    """Wipe UEBA counters AND the ueba_alerts table between tests."""
    from gateway.plugins import registry, PluginKind
    # Counter store
    for p in registry.of_kind(PluginKind.OBSERVE):
        if p.name == "observe_ueba" and getattr(p, "_counters", None) is not None:
            store = p._counters
            # The plugin's in-memory store exposes _v / _x directly; the
            # Redis one has a reset() via flush — but for tests we always
            # use in-memory, so this is enough.
            if hasattr(store, "_v"):
                store._v.clear()
                store._x.clear()

    # Alerts table
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    async with eng.begin() as conn:
        await conn.execute(text("TRUNCATE TABLE ueba_alerts RESTART IDENTITY"))
    yield
    await eng.dispose()


# --- 4d-ter. Per-test router-rule-overrides cleaner -----------------------
@pytest_asyncio.fixture
async def clean_router_overrides():
    """Truncate router_rule_overrides between tests so the YAML rule chain
    starts from a known clean state. Used by tests that toggle rules
    on/off — they must NOT inherit leftover rows from a previous test."""
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine
    dsn = os.environ["GATEWAY_DB_URL"]
    eng = create_async_engine(dsn, future=True)
    async with eng.begin() as conn:
        await conn.execute(text(
            "TRUNCATE TABLE router_rule_overrides RESTART IDENTITY"
        ))
    # Trigger a policy reload so the router_rule_based plugin loses any
    # stale chain from a previous test before the next one starts.
    try:
        from gateway.main import reload_policy_consumers
        await reload_policy_consumers()
    except Exception:                                              # noqa: BLE001
        pass
    yield
    # Same hygiene on teardown so the NEXT, non-fixture-using test
    # inherits a chain matching the YAML.
    async with eng.begin() as conn:
        await conn.execute(text(
            "TRUNCATE TABLE router_rule_overrides RESTART IDENTITY"
        ))
    await eng.dispose()
    try:
        from gateway.main import reload_policy_consumers
        await reload_policy_consumers()
    except Exception:                                              # noqa: BLE001
        pass


# --- 4d. Per-test quota-counter cleaner -----------------------------------
@pytest_asyncio.fixture
async def clean_quotas():
    """Wipe quota counters between tests so RPM / daily caps are deterministic."""
    from gateway.plugins import registry, PluginKind
    quotas = [p for p in registry.of_kind(PluginKind.AUTHZ) if p.name == "quota_redis"]
    if quotas and getattr(quotas[0], "_counters", None) is not None:
        # Reset the underlying counter store directly — works for both
        # in-memory and Redis backends.
        store = quotas[0]._counters
        await store.reset("quota:")
    yield


# --- 5. Helpers -----------------------------------------------------------
def dev_token(team: str = "backend-engineering", tier: str = "L1_standard",
              user: str = "alice") -> str:
    # Use + as the separator so team / tier / user values can themselves
    # contain dashes (e.g. "backend-engineering").
    return f"sk-dev+{team}+{tier}+{user}"


def dev_headers(**kw) -> dict[str, str]:
    return {"Authorization": f"Bearer {dev_token(**kw)}",
            "Content-Type": "application/json"}
