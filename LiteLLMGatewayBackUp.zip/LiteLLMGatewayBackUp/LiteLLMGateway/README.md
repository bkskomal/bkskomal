# AI Concepts Hub - Interactive AI Learning Platform

A modern, professional educational website that explains foundational and advanced AI concepts through interactive visualizations, hands-on examples, and real-world applications.

## 🚀 Features

### Core Learning Modules
- **LLM Fundamentals** - Understanding Large Language Models
- **Context Window** - Memory limitations and token management
- **Tokens** - Tokenization, pricing, and efficiency
- **Parameters** - Model sizes, capabilities, and trade-offs
- **RAG** - Retrieval Augmented Generation architecture
- **MCP** - Model Context Protocol implementation
- **LangChain** - Building AI applications with chains
- **LangGraph** - Complex workflows and state management

### Interactive Elements
- **Visual Transformers** - Animated neural network layers
- **Context Simulator** - Real-time context window visualization
- **Token Calculator** - Multi-language token estimation
- **Parameter Explorer** - Model size and performance comparison
- **RAG Flow Visualizer** - End-to-end retrieval process
- **Interactive Playground** - Experiment with AI concepts

### Modern UI/UX
- **Glassmorphism Design** - Beautiful frosted glass effects
- **Dark/Light Mode** - Seamless theme switching
- **Responsive Design** - Perfect on all devices
- **Smooth Animations** - Framer Motion powered interactions
- **SEO Optimized** - Built for search engine visibility

## 🛠️ Tech Stack

### Frontend
- **Next.js 15** - React framework with App Router
- **React 19** - Latest React features
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first styling
- **Framer Motion** - Animation library
- **ShadCN/UI** - Beautiful, accessible components

### Visualization
- **D3.js** - Data visualization
- **React Flow** - Interactive node graphs
- **Chart.js** - Statistical charts
- **Mermaid** - Diagram generation

### Backend
- **Node.js** - Runtime environment
- **PostgreSQL** - Primary database
- **Drizzle ORM** - Type-safe database toolkit

## 📦 Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/ai-concepts-hub.git
   cd ai-concepts-hub
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   ```
   
   Update `.env.local` with your configuration:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/aiconcepts
   NEXTAUTH_SECRET=your-secret-key
   NEXTAUTH_URL=http://localhost:3000
   ```

4. **Set up the database**
   ```bash
   npm run db:push
   ```

5. **Start the development server**
   ```bash
   npm run dev
   ```

## 🎯 Quick Start

Visit `http://localhost:3000` to explore:
- **Home Page** - Hero section with search and quick navigation
- **Learning Modules** - Each concept has dedicated interactive pages
- **Playground** - Experiment with AI parameters in real-time
- **Progress Tracking** - Monitor your learning journey

## 📁 Project Structure

```
ai-concepts-hub/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── globals.css         # Global styles
│   │   ├── layout.tsx          # Root layout
│   │   ├── page.tsx            # Home page
│   │   ├── llm-fundamentals/   # LLM concepts
│   │   ├── context-window/     # Context window
│   │   ├── tokens/             # Token management
│   │   ├── parameters/         # Model parameters
│   │   ├── rag/                # RAG architecture
│   │   ├── mcp/                # MCP protocol
│   │   ├── langchain/          # LangChain
│   │   ├── langgraph/          # LangGraph
│   │   └── playground/         # Interactive playground
│   ├── components/             # React components
│   │   ├── ui/                 # ShadCN/UI components
│   │   ├── llm/                # LLM-specific components
│   │   ├── context-window/     # Context window components
│   │   ├── tokens/             # Token components
│   │   └── playground/         # Playground components
│   ├── lib/                    # Utility functions
│   └── types/                  # TypeScript types
├── database/                   # Database schema
├── public/                     # Static assets
└── docs/                       # Documentation
```

## 🎨 Design System

### Colors
- **AI Blue**: `#0ea5e9` - Primary AI theme
- **Neural Purple**: `#a855f7` - Neural network accent
- **Gradient Backgrounds**: Multi-color gradients for visual appeal

### Components
- **Glassmorphism Cards**: `glassmorphism` class
- **Interactive Elements**: Hover effects and transitions
- **Responsive Grid**: Mobile-first design approach

## 🔧 Development

### Available Scripts
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint
- `npm run type-check` - Type checking
- `npm test` - Run tests

### Adding New Features
1. Create component in `src/components/`
2. Add route in `src/app/`
3. Update navigation in `src/components/navigation.tsx`
4. Add to learning roadmap if applicable

## 🚀 Deployment

### Vercel (Recommended)
1. Push to GitHub
2. Import project on Vercel
3. Add environment variables
4. Deploy

### Docker
```bash
docker build -t ai-concepts-hub .
docker run -p 3000:3000 ai-concepts-hub
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

## 🆘 Support

- **Documentation**: Check `/docs` folder
- **Issues**: Create GitHub issue
- **Discord**: Join our community server
- **Email**: hello@aiconceptshub.com

---

Built with ❤️ for the AI learning community