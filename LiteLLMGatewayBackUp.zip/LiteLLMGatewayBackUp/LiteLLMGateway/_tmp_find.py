import os
for root, _, files in os.walk('gateway/src/gateway'):
    for f in files:
        if not f.endswith('.py'):
            continue
        path = os.path.join(root, f)
        with open(path, encoding='utf-8') as fh:
            for line in fh:
                if 'audit' in line and ('search' in line or 'csv' in line):
                    print(path)
                    break
