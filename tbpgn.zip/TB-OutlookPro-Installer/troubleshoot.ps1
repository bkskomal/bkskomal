#requires -Version 5.1
<#
.SYNOPSIS
  Collects OutlookPro diagnostic artifacts into a single .zip on the
  user's Desktop. Credentials are stripped -- safe to email to support.

.DESCRIPTION
  For every Thunderbird profile found under %APPDATA%\Thunderbird\Profiles\:
    - outlookpro-ews-diagnostic.log  (the sync log)
    - outlookpro-ews-rules.json      (fetched inbox rules snapshot)
    - outlookpro-*.log               (other extension logs)
    - extensions.json  (with .storage/.location paths only, no cookies)
    - prefs.js  (mail.server.* + extensions.outlookpro.* prefs only;
                 every password/token/cookie value REDACTED)
    - list of xpi filenames + version + size in <profile>\extensions\
    - Thunderbird version (from thunderbird.exe VersionInfo)
    - Windows version + user (for reproduction context)
#>

$ErrorActionPreference = "SilentlyContinue"
$stamp   = Get-Date -Format "yyyyMMdd-HHmmss"
$outDir  = Join-Path $env:USERPROFILE "Desktop"
$workDir = Join-Path $env:TEMP "OutlookPro-Diag-$stamp"
$zipPath = Join-Path $outDir  "OutlookPro-Diag-$stamp.zip"

if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }
if (Test-Path $workDir) { Remove-Item $workDir -Recurse -Force }
New-Item -ItemType Directory -Path $workDir | Out-Null

Write-Host "Collecting diagnostics to: $workDir" -ForegroundColor Cyan

# ---------- 1. Thunderbird environment ----------
$tbCandidates = @(
    "C:\Program Files\Mozilla Thunderbird\thunderbird.exe",
    "C:\Program Files (x86)\Mozilla Thunderbird\thunderbird.exe"
)
$tbExe = $tbCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
$env = @{
    "Timestamp"       = (Get-Date).ToString("o")
    "Windows"         = "$([Environment]::OSVersion.VersionString) ($((Get-CimInstance Win32_OperatingSystem).Caption))"
    "User"            = "$env:USERDOMAIN\$env:USERNAME"
    "Machine"         = $env:COMPUTERNAME
    "ThunderbirdPath" = $tbExe
    "ThunderbirdVersion" = if ($tbExe) { (Get-Item $tbExe).VersionInfo.ProductVersion } else { "not found" }
}
$env | ConvertTo-Json | Set-Content (Join-Path $workDir "environment.json") -Encoding UTF8
Write-Host "  [OK] environment.json" -ForegroundColor Green

# ---------- 2. Walk every TB profile ----------
$profilesRoot = Join-Path $env:APPDATA "Thunderbird\Profiles"
if (-not (Test-Path $profilesRoot)) {
    Write-Host "  [WARN] No Thunderbird profiles directory found." -ForegroundColor Yellow
} else {
    Get-ChildItem $profilesRoot -Directory | ForEach-Object {
        $profDir = $_.FullName
        $safeName = $_.Name -replace "[^\w\.\-]", "_"
        $profOut = Join-Path $workDir "profile-$safeName"
        New-Item -ItemType Directory -Path $profOut | Out-Null
        Write-Host "  Profile: $($_.Name)" -ForegroundColor Cyan

        # a) OutlookPro logs
        Get-ChildItem $profDir -Filter "outlookpro-*.log*" -ErrorAction SilentlyContinue |
            ForEach-Object { Copy-Item $_.FullName $profOut }
        Get-ChildItem $profDir -Filter "outlookpro-*.json" -ErrorAction SilentlyContinue |
            ForEach-Object { Copy-Item $_.FullName $profOut }

        # b) extensions.json (list only, no secrets)
        $extJs = Join-Path $profDir "extensions.json"
        if (Test-Path $extJs) {
            try {
                $j = Get-Content $extJs -Raw | ConvertFrom-Json
                $addons = @($j.addons | ForEach-Object {
                    [pscustomobject]@{
                        id         = $_.id
                        version    = $_.version
                        active     = $_.active
                        type       = $_.type
                        location   = $_.location
                    }
                }) | Where-Object { $_.id -like "*outlookpro*" -or $_.id -like "*oati*" -or $_.id -like "*owl*" -or $_.id -like "*ews*" -or $_.id -like "*tbsync*" -or $_.id -like "*cardbook*" }
                $addons | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $profOut "installed-addons.json") -Encoding UTF8
            } catch {
                "extensions.json parse failed: $($_.Exception.Message)" | Set-Content (Join-Path $profOut "installed-addons.json")
            }
        }

        # c) xpi list from extensions/
        $extDir = Join-Path $profDir "extensions"
        if (Test-Path $extDir) {
            Get-ChildItem $extDir -Filter "*.xpi" |
                Select-Object Name, Length, LastWriteTime |
                ConvertTo-Csv -NoTypeInformation |
                Set-Content (Join-Path $profOut "xpi-files.csv") -Encoding UTF8
        }

        # d) prefs.js -- extract only mail.server.* + extensions.outlookpro.*
        #    Redact any password/token/cookie/secret values.
        $prefsJs = Join-Path $profDir "prefs.js"
        if (Test-Path $prefsJs) {
            $prefsRaw = Get-Content $prefsJs -Raw
            $lines = [regex]::Matches($prefsRaw, 'user_pref\("([^"]+)",\s*(.+?)\);') | ForEach-Object {
                $name = $_.Groups[1].Value
                $val  = $_.Groups[2].Value
                if ($name -match '^(mail\.server\.|mail\.account\.|mail\.smtpserver\.|mail\.identity\.|extensions\.outlookpro\.|extensions\.legacy|calendar\.registry|mailnews\.default_|mail\.check_)') {
                    # Redact secrets
                    if ($name -match '(password|token|secret|cookie|access_token|refresh_token|api_key)') {
                        $val = '"<REDACTED>"'
                    }
                    "user_pref(""$name"", $val);"
                }
            }
            $lines -join "`r`n" | Set-Content (Join-Path $profOut "prefs-filtered.js") -Encoding UTF8
        }

        # e) logins.json  -- REALM ONLY, no credentials
        $logJs = Join-Path $profDir "logins.json"
        if (Test-Path $logJs) {
            try {
                $j = Get-Content $logJs -Raw | ConvertFrom-Json
                $realms = $j.logins | ForEach-Object {
                    [pscustomobject]@{
                        hostname    = $_.hostname
                        httpRealm   = $_.httpRealm
                        formSubmitURL = $_.formSubmitURL
                    }
                }
                $realms | ConvertTo-Json -Depth 3 | Set-Content (Join-Path $profOut "login-realms.json") -Encoding UTF8
            } catch {}
        }

        # f) msgFilterRules.dat for each server dir (Mail\ and ImapMail\)
        foreach ($sub in @("Mail", "ImapMail")) {
            $base = Join-Path $profDir $sub
            if (Test-Path $base) {
                Get-ChildItem $base -Directory | ForEach-Object {
                    $ff = Join-Path $_.FullName "msgFilterRules.dat"
                    if (Test-Path $ff) {
                        $dstName = "filter-$sub-$($_.Name).dat"
                        Copy-Item $ff (Join-Path $profOut $dstName)
                    }
                }
            }
        }
    }
}

# ---------- 3. Zip it up ----------
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($workDir, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)

Remove-Item $workDir -Recurse -Force

if (Test-Path $zipPath) {
    $sz = (Get-Item $zipPath).Length
    Write-Host ""
    Write-Host ("[OK] Diagnostic bundle: {0}  ({1:N0} bytes)" -f $zipPath, $sz) -ForegroundColor Green
    Write-Host ""
    Write-Host "Please email this .zip file to your OutlookPro support contact." -ForegroundColor Cyan
    Write-Host "No credentials, tokens, or message content are included." -ForegroundColor DarkGray
} else {
    Write-Host "[FAIL] Zip was not created." -ForegroundColor Red
}
