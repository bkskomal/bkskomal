@echo off
setlocal EnableExtensions
title OutlookPro Diagnostics Collector

echo.
echo ============================================================
echo  OutlookPro for Thunderbird -- Diagnostics Collector
echo ============================================================
echo.
echo  Collects:
echo    - outlookpro-ews-diagnostic.log
echo    - list of installed OutlookPro xpis + their versions
echo    - account shape (server types, hostnames, authMethod)
echo      -- credentials are NEVER included
echo    - Thunderbird version + install path
echo.
echo  Output: OutlookPro-Diag-^<date-time^>.zip on your Desktop.
echo  Please email that .zip file to your OutlookPro support contact.
echo.
pause

powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0troubleshoot.ps1'"

echo.
echo ============================================================
echo Done. The .zip file is on your Desktop.
echo ============================================================
pause
