// ============================================================
// Thunderbird OutlookPro — user.js preferences
//
// Pre-configured defaults that make Thunderbird behave like Outlook
// out of the box. Copy to <profile>/user.js — Thunderbird loads
// this on startup and merges into prefs.js.
// ============================================================

// ---- Enable userChrome.css / userContent.css customizations ----
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

// ---- Auto-enable add-ons dropped into <profile>/extensions/ ----
// 15 = all scopes (system, user, profile, app); default disables profile-scope
// add-ons until the user explicitly approves them. Setting to 0 trusts that
// any .xpi we put in the profile dir was put there intentionally.
user_pref("extensions.autoDisableScopes", 0);
user_pref("extensions.enabledScopes", 15);
user_pref("extensions.unrestricted-domains", "*");
// Skip the "new add-on installed" prompt at startup
user_pref("extensions.startupScanScopes", 15);

// ---- UI density + look-and-feel (Outlook-like) ----
user_pref("mail.uidensity", 0);              // 0=compact (Outlook-tight), 1=normal, 2=touch
user_pref("mail.threadpane.table.horizontal_scroll", false);
// Force TABLE thread-pane view (rows of cells), NOT the new card layout
// (cards render the subject in a much larger font and break visual balance).
user_pref("mail.threadpane.listview", 0);
user_pref("mail.threadpane.table.view", true);
user_pref("mailnews.start_page.enabled", false);
user_pref("mail.biff.show_alert", true);
user_pref("mail.biff.show_tray_icon", true);
user_pref("mail.biff.use_system_alert", true);
user_pref("mail.tabs.tabMinWidth", 100);
user_pref("mail.tabs.tabMaxWidth", 220);

// ---- Conversation view (Gmail-style threading like Outlook 'Show as Conversations') ----
user_pref("mail.operate_on_msgs_in_collapsed_threads", true);
user_pref("mailnews.thread_pane_column_unthreads", false);
user_pref("mailnews.default_view_flags", 1);  // 1 = threaded

// ---- HTML mail + remote content ----
user_pref("mail.html_compose", true);
user_pref("mail.default_html_action", 3);    // 3 = ask if HTML / plain
user_pref("mailnews.message_display.disable_remote_image", true);   // Outlook-like: block remote images by default

// ---- Reply / forward defaults (Outlook semantics) ----
user_pref("mail.compose.default_to_paragraph", true);
user_pref("mail.identity.default.reply_on_top", 1);     // 0=below, 1=above (Outlook style)
user_pref("mail.identity.default.sig_bottom", false);   // signature above quoted text
user_pref("mail.SpellCheckBeforeSend", true);
user_pref("mail.warn_on_send_accel_key", true);

// ---- Address book + auto-collection (Outlook-style) ----
user_pref("mail.collect_email_address_outgoing", true);
user_pref("mail.collect_addressbook", "jsaddrbook://history.sqlite");

// ---- Calendar (Lightning) defaults ----
user_pref("calendar.alarms.playsound", true);
user_pref("calendar.alarms.show", true);
user_pref("calendar.alarms.showmissed", true);
user_pref("calendar.week.start", 1);          // 0=Sun (US), 1=Mon (EU/Outlook default)
user_pref("calendar.view.timeIndicator.interval", 5);
user_pref("calendar.timezone.useSystemTimezone", true);

// ---- Search ----
user_pref("mailnews.database.global.indexer.enabled", true);
user_pref("gloda.indexer.perf.background.cpu_usage", 60);

// ---- Quick filter bar visible by default (gives Outlook 'All / Unread' tabs) ----
user_pref("mail.quickFilterBar.visible", true);
user_pref("mail.quickFilterBar.sticky", true);
user_pref("mail.quickFilterBar.show", true);

// ---- CARD layout in thread pane — Outlook-style 2-line messages ----
// TB semantics (verified from about3Pane.js): 0 = Cards view, 1 = Table view.
// Set to 0 so Cards is the default; user can still flip via View menu.
user_pref("mail.threadpane.listview", 0);

// ---- Group messages by date by default (Today / Yesterday / Last Week / etc.) ----
// Equivalent to View > Sort by > Group by Sort + Sort by Date
user_pref("mailnews.default_view_flags", 1);
user_pref("mailnews.default_sort_order", 2);   // 1=asc, 2=desc
user_pref("mailnews.default_sort_type", 18);   // 18 = date
user_pref("mailnews.default_news_sort_type", 18);
user_pref("mailnews.default_news_sort_order", 2);

// ---- Show Favorite Folders pane mode by default ----
// 'all' / 'unread' / 'favorite' / 'recent' / 'unified'
user_pref("mail.folder_pane.mode", "all");

// ---- Show conversation/preview snippet line under subject (Outlook style) ----
user_pref("mail.threadpane.card_subjectline", true);
user_pref("mail.threadpane.show_message_preview", true);
user_pref("mail.threadpane.preview_lines", 1);

// ---- Performance ----
user_pref("mail.imap.use_status_for_biff", true);
user_pref("mail.server.default.check_new_mail", true);
user_pref("mail.server.default.check_time", 1);         // poll every 1 min (Outlook parity)
user_pref("mail.check_all_imap_folders_for_new", true); // check every folder, not just Inbox
user_pref("mailnews.send_default_charset", "UTF-8");

// ---- Instant-open bodies (Outlook parity) ----
// Bodies download in the background so click-to-open is instant instead
// of waiting for an IMAP fetch. This is the single biggest speed-up for
// message rendering. Combines four settings that work together:
//   autosync_offline_stores  - background download of every message body
//   download_bodies_on_get_new_mail - full body on every mail poll
//   download_on_biff         - full body when biff (new mail signal) fires
//   offline_download         - keep the offline store enabled
user_pref("mail.server.default.autosync_offline_stores", true);
user_pref("mail.server.default.download_bodies_on_get_new_mail", true);
user_pref("mail.server.default.download_on_biff", true);
user_pref("mail.server.default.offline_download", true);
user_pref("mail.server.default.limit_offline_message_size", false);
// Chunked + parallel IMAP fetches so pre-download doesn't stall the UI
user_pref("mail.imap.mime_parts_on_demand", false);     // pre-fetch mime parts too
user_pref("mail.imap.fetch_by_chunks", true);
user_pref("mail.imap.max_cached_connections", 10);      // was 5 -- more parallel fetch
user_pref("mail.server.default.max_cached_connections", 10);
user_pref("mail.imap.hide_other_users_from_list", true);
user_pref("mail.strict_threading", true);               // faster thread pane rendering

// ---- OAuth2 ready (Microsoft 365 / Google) ----
user_pref("mail.server.default.authMethod", 10);        // 10 = OAuth2 preferred
user_pref("mailnews.oauth.loglevel", "Warn");

// ---- Disable telemetry by default ----
user_pref("toolkit.telemetry.enabled", false);
user_pref("toolkit.telemetry.unified", false);
user_pref("datareporting.healthreport.uploadEnabled", false);
user_pref("app.shield.optoutstudies.enabled", false);


// ---- Read receipts (Outlook-style) ----
user_pref("mail.mdn.report.enabled", true);
user_pref("mail.mdn.report.notInToCcOp", 0);

// ---- Notifications: show preview like Outlook ----
user_pref("alerts.totalOpenTime", 8000);
user_pref("mail.biff.show_subject", true);
user_pref("mail.biff.show_sender", true);
user_pref("mail.biff.show_preview", true);

// ---- Don't restore tabs from last session (Outlook opens cleanly) ----
user_pref("mail.tabs.firstTab", "mail");
user_pref("mail.restoreOnLastTabClose", false);

// ---- Force Vertical / Outlook-style 3-pane layout ----
// 0=classic (list above, reading pane below), 1=wide, 2=vertical (Outlook-like)
// Vertical = folder pane | message list | reading pane, left to right
user_pref("mail.pane_config.dynamic", 2);
user_pref("mailnews.thread_pane_column_unthreads", false);
// Show the message preview pane
user_pref("mail.showCondensedAddresses", true);
// Make sure threading and reading pane are on
user_pref("mailnews.default_view_flags", 1);
// Show columns: From, Subject, Date by default
user_pref("mail.threadpane.use_correspondents", true);

// ---- Show toolbar with Outlook-like buttons ----
user_pref("browser.uidensity", 1);

// ---- Use system spell-checker (Outlook behavior) ----
user_pref("spellchecker.dictionary", "");
user_pref("layout.spellcheckDefault", 2);

// ---- Always show expanded message header (from/to/cc/date/subject) ----
// nsMimeHeaderDisplayTypes: 0=Micro, 1=Normal, 2=AllHeaders. Setting 2 makes
// TB render the labeled, stacked header view -- the same one the "i" info
// icon exposes -- for every message by default.
user_pref("mail.show_headers", 1);
