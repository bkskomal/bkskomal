AI Genie Shell - prototype with the new 3D Genie mascot
========================================================

How to run
1. Extract the whole zip to a folder (do not open index.html from inside the zip).
2. Double-click index.html. It opens in your browser (Chrome or Edge recommended).
   Keep index.html and the "assets" folder together.
3. On the sign-in screen just click "Sign in" (no real account is needed).

What to try
- The Genie at the top left shows the application's state.
- "Island states" panel on the left (press I, or click "Island states" in the
  bottom bar, to show or hide it). Under "Genie actions - 3D":
    * Monitoring, Greeting, Listening, Thinking, Working, Speaking, Done,
      Needs attention, Sleeping, Celebrating - each plays Genie's animation
      and its sound. "Play all actions" runs through them.
    * Speaking: Genie says a short greeting and welcome.
    * View: Half (bigger face) or Full (with tail).
    * Scale S / M / L / XL and the Custom slider change his size.
    * Sound On / Off.
- Hover "Ask Genie" at the bottom right: Genie rises out of the lamp.
  Click it to open the chat.
- Settings > Genie also has the "Genie sounds" switch.

Notes
- Turn the computer's sound on. If nothing is heard, click anywhere on the
  page once (browsers hold sound until the first click).
- An internet connection is used only for the fonts and one small animation
  library; without it the page still works, with a plainer font.
