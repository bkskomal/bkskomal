@echo off
setlocal EnableExtensions
title OutlookPro -- Complete Uninstall

set "SCRIPT_DIR=%~dp0"

echo.
echo ============================================================
echo  OutlookPro Complete Uninstall
echo  This removes every OutlookPro bundle from the profile.
echo  Your mail / accounts / address book stay untouched.
echo ============================================================
echo.

REM Unblock .ps1 files (they carry Mark-of-the-Web from the zip extraction)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-ChildItem -Path '%SCRIPT_DIR%' -Filter '*.ps1' -File -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" 2>nul

REM Run uninstall.ps1, passing all args through (e.g. -ProfileName, -KeepPrefs)
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%uninstall.ps1" %*
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" (
  echo Uninstall exited with code %RC%.
) else (
  echo Uninstall complete.
)
echo.
echo Press any key to close.
pause >nul
exit /b %RC%
