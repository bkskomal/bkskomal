============================================================
 OutlookPro for Thunderbird -- Installer Bundle
============================================================

Turns Thunderbird 128+ into a drop-in Outlook replacement:
Outlook-style ribbon, ADFS OAuth, EWS calendar/contacts,
MAPI/HTTP, cards-view-by-default, composer polish, people
picker (Check Names equivalent), auto-archive rules, and more.

============================================================
 TWO WAYS TO INSTALL
============================================================

Option A (fastest, single file) -- from parent folder:
  Double-click:  EnhanceThunderbird.cmd
  Self-extractor that contains this whole bundle Base64-embedded.

Option B (traditional, folder) -- from THIS folder:
  Double-click:  Setup.cmd
  Runs the .ps1 scripts you can inspect first.

Both do the same thing end-to-end.

============================================================
 SETUP.CMD -- what it does
============================================================

  1. Unblocks all .ps1 scripts (strips Mark-of-the-Web so
     PowerShell will run them out of a downloaded zip).
  2. Runs uninstall_old.ps1 -- removes any legacy fine-grained
     OutlookPro bundles that were consolidated (folder-size,
     compose-in-tab, reply-all-fix, recall, ews-calendar,
     ews-contacts, auto-archive, auto-reply, quick-rule,
     server-rules).
  3. Runs install.ps1 -- deploys the current 13 bundles into
     the profile, merges user.js, drops userChrome.css into
     the profile chrome dir, patches xulstore.json to
     whitelist browser_action buttons, then launches TB.

Administrator rights are NOT required.

============================================================
 UNINSTALL.CMD -- complete removal
============================================================

Double-click Uninstall.cmd for full cleanup:

  * Removes every OutlookPro XPI (current 13 + legacy 10)
  * Clears per-extension storage (IndexedDB)
  * Strips the OutlookPro managed block from user.js
    (marker-guarded -- untouched prefs stay)
  * Removes profile\chrome\userChrome.css if it has our marker
    (backup kept as userChrome.css.op-backup)
  * Busts the addonStartup.json.lz4 cache

Non-destructive to your data:
  * No mailbox, message, address book, calendar, filter,
    account setting, or password is touched.
  * -KeepPrefs   flag: leaves user.js alone
  * -KeepUserChromeCss flag: leaves userChrome.css alone

  Uninstall.cmd -ProfileName default-release
  Uninstall.cmd -KeepPrefs -KeepUserChromeCss

============================================================
 OPTIONS (pass through Setup.cmd / Uninstall.cmd)
============================================================

  -ProfileName default-release
      Substring match on profile folder name, or a full path.
      Omit for auto-detect.

  -NoLaunch  (Setup only)
      Skip auto-starting Thunderbird after install.

  -ThunderbirdExe "D:\Portable\TB\thunderbird.exe"  (Setup only)
      Point at a non-standard TB install location.

Combine freely:
  Setup.cmd -ProfileName bt572ve7 -NoLaunch

============================================================
 WHAT GETS INSTALLED
============================================================

13 add-ons (drop into <profile>\extensions\):
  outlookpro-adfs-oauth       ADFS OAuth2 credentials
  outlookpro-archive          Auto-Archive Rules + Archive
                              Options dialog buttons (v0.2.9)
  outlookpro-cards-default    Cards view as default
  outlookpro-composer         New-message composer polish
  outlookpro-composer-plus    Signatures (with image insert)
                              + @Mentions (v2.0.2)
  outlookpro-ews              EWS calendar + contacts
  outlookpro-mapi-http        MAPI/HTTP transport layer
  outlookpro-people           Check Names / people picker
  outlookpro-ribbon           Outlook-style ribbon bar
                              (Home / Send-Receive / Folder /
                               View / Add-ons / Help) v2.18.1
  outlookpro-rules            Outlook-style client-side rules
  outlookpro-search           Advanced search bar
  outlookpro-triage           Rapid inbox triage
  outlookpro-view             View controls + folder size

Files copied into <profile>:
  user.js                    ~150-line Outlook-parity pref
                              template (idempotent, marker-guarded)
  chrome\userChrome.css      Menu bar visible + spaces toolbar
                              styling + tab polish + folder pane

xulstore.json patched:
  Whitelists outlookpro-view, outlookpro-ribbon,
  outlookpro-search, outlookpro-archive in the unified
  toolbar's allowedExtSpaces.

============================================================
 REQUIREMENTS
============================================================

  * Windows 10 / 11
  * PowerShell 5.1+ (built into Windows)
  * Thunderbird 115 or newer

Idempotent -- re-running is safe. Replaces existing XPIs,
merges user.js only once (marker-guarded), appends missing
prefs without touching existing ones.

============================================================
 TROUBLESHOOTING
============================================================

Ribbon buttons don't appear after install:
  1. Fully quit Thunderbird
  2. Delete <profile>\addonStartup.json.lz4
  3. Re-launch Thunderbird

Profile not auto-detected:
  Pass -ProfileName <substring or full path>.
  Profiles live in %APPDATA%\Thunderbird\Profiles\.

Setup.cmd flashes and closes immediately:
  Windows blocked .ps1 before Unblock-File ran.
  Right-click Setup.cmd -> Run as administrator once.

Want to remove everything and start fresh:
  Uninstall.cmd, then Setup.cmd.
