@echo off
rem Opens GenieApplicationShell.html (the framework) on http://localhost:8890.
rem No-cache server (serve_genie.py): F5 always shows the latest file. If the server is
rem already running (e.g. started by Start-GenieAllDashboards.bat, which now serves index.html at /), this only opens the tab.
rem Chrome REMEMBERS the mic Allow on localhost (file:// pages re-ask every time).
cd /d "%~dp0"
set "URL=http://localhost:8890/GenieApplicationShell.html"

netstat -ano | findstr /R /C:":8890 .*LISTENING" >nul 2>&1
if %errorlevel%==0 (
  echo Genie server already running on 8890 - opening %URL%
  start "" "%URL%"
  exit /b 0
)

echo Starting the Genie server on 8890 ...
start "" "%URL%"
"C:\Users\bkkom\.venv\Scripts\python.exe" serve_genie.py 8890
