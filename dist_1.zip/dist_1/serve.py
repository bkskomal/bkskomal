# Serves the packaged Genie webVision hub on http://localhost:8890 with NO-CACHE headers,
# so a plain F5 always shows the latest file state (plain http.server lets the browser
# cache pages, which hides fresh edits behind stale tabs).
#   python serve.py            -> port 8890 (default)
#   python serve.py 8891       -> another port
# One server covers the whole package (index.html - the hub, the default page at /,
# dashboards\*.html, chat\*) - everything is served from this folder.
import http.server
import sys

class NoCacheHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, fmt, *args):  # quieter console: skip the favicon probe noise
        if args and "favicon.ico" in str(args[0]):
            return
        super().log_message(fmt, *args)

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 8890
    http.server.test(HandlerClass=NoCacheHandler, port=port, bind="127.0.0.1")
