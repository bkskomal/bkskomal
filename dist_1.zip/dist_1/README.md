# OATI Genie UI

Self-contained distribution of OATI Genie UI: a multi-product
shell (`index.html`) hosting **10 converted dashboards** on the GenieUI framework
**1.17.1 (2026-09-07)**, plus the Genie chat widget (`chat/`).

The chat widget points at the RAG deployment `https://app.int.oatihub.oati.com/genie/rag`
(edit `chat/genie-config.js` to change it). If that host is unreachable from your machine
the chat still opens — with an empty history, and a clear in-conversation error on send.

## Run it

**Easiest:** double-click `Start-Genie.bat`. It starts the local server on
port 8890 and opens http://localhost:8890/ in your default browser.

**Manual:**

```
python serve.py [port]
```

then open `http://localhost:<port>/` (default port is 8890; any port works).

Sign in with any username — there is no password.

## Why a local server (not double-clicking index.html)

- Microphone permission for Genie listening **persists** on `http://localhost`;
  `file://` pages re-ask every time.
- Browsers cache `file://` pages, which can hide updates behind stale tabs.
  `serve.py` sends no-cache headers so a plain refresh always shows the
  current files.

Chrome is the verified browser.

## Contents

| Path | What |
|---|---|
| `index.html` | Genie UI — the multi-product shell (sign-in, product switcher, status bar) |
| `GenieApplicationShell.html` | The framework on its own — the shell with no products mounted, useful for looking at shell behaviour (sign-in scenes, Genie, settings) in isolation |
| `dashboards/` | The 8 converted dashboards (FTM Optimization, BTM SOC Forecast, EV Charge Load Management, OATI Genie Dynamic Line Ratings, Conversations & Feedback, Genie Powerflow, BA Forecast & Capacity Console, Grid DERMS Dispatch Scheduling) |
| `chat/` | Genie chat widget bundle + config + RAG shim |
| `serve.py` | No-cache local HTTP server |
| `Start-Genie.bat` | One-click launcher |
