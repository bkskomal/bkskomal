import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

async function main() {
  const path = process.argv[2] ?? "C:/Users/bkkom/Downloads/updated_realistic_pdf.pdf";
  const buf = await readFile(path);
  console.log(`PDF: ${path} (${buf.byteLength} bytes)`);

  // Quick raw scan for image stream markers — PDFs embed images as
  // FlateDecode/DCTDecode XObjects. If we find /Image objects, we KNOW
  // there are images even before pdfjs walks the operator list.
  const text = buf.toString("binary");
  const imageMatches = text.match(/\/Subtype\s*\/Image/g);
  const dctMatches = text.match(/\/Filter[^/]*\/DCTDecode/g);
  const flateMatches = text.match(/\/Filter[^/]*\/FlateDecode/g);
  console.log(`  raw /Subtype /Image markers: ${imageMatches?.length ?? 0}`);
  console.log(`  /DCTDecode (JPEG) filters:    ${dctMatches?.length ?? 0}`);
  console.log(`  /FlateDecode filters:         ${flateMatches?.length ?? 0}`);

  // Now via pdfjs operator list
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const req = createRequire(import.meta.url);
  const workerPath = req.resolve("pdfjs-dist/legacy/build/pdf.worker.mjs");
  pdfjs.GlobalWorkerOptions.workerSrc = pathToFileURL(workerPath).href;

  const data = new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
  const doc = await pdfjs.getDocument({ data, verbosity: 0 }).promise;
  console.log(`  pages: ${doc.numPages}`);

  const OPS = pdfjs.OPS;
  console.log(`  OPS.paintImageXObject = ${OPS?.paintImageXObject}`);
  console.log(`  OPS.paintInlineImageXObject = ${OPS?.paintInlineImageXObject}`);
  console.log(`  paintJpegXObject = ${(OPS as Record<string, number>)?.paintJpegXObject}`);

  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const opList = await page.getOperatorList();
    const fnArray: number[] = opList.fnArray;
    const argsArray: unknown[][] = opList.argsArray;
    const paintImgOps = new Map<number, number>();
    const objIds = new Set<string>();
    const paintImageArgs: unknown[][] = [];
    for (let i = 0; i < fnArray.length; i++) {
      const fn = fnArray[i];
      paintImgOps.set(fn, (paintImgOps.get(fn) ?? 0) + 1);
      const args = argsArray[i];
      if (fn === OPS.paintImageXObject || fn === OPS.paintInlineImageXObject) {
        paintImageArgs.push(args);
      }
      if (Array.isArray(args) && typeof args[0] === "string") {
        const first = args[0];
        if (first.length < 100 && /^[a-zA-Z]+_\d+/.test(first)) {
          objIds.add(first);
        }
      }
    }
    console.log(`  page ${p}: actual paint-image args:`);
    paintImageArgs.forEach((a, i) =>
      console.log(`    [${i}] ${JSON.stringify(a).slice(0, 200)}`),
    );
    console.log(`  page ${p}: ops total=${fnArray.length}`);
    const imageOpCodes = [
      OPS.paintImageXObject,
      OPS.paintInlineImageXObject,
      (OPS as Record<string, number>).paintJpegXObject,
      OPS.paintImageMaskXObject,
    ].filter(Boolean);
    for (const code of imageOpCodes) {
      const n = paintImgOps.get(code) ?? 0;
      if (n > 0) console.log(`    op ${code}: ${n}`);
    }
    console.log(`    candidate objIds (any prefix): ${objIds.size}`);
    Array.from(objIds).slice(0, 8).forEach((id) => console.log(`      - ${id}`));
  }
}
main().catch((e) => {
  console.error("FAILED", e);
  process.exit(1);
});
