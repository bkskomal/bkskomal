// Tiny helper: rasterise an SVG to PNG via sharp so it embeds cleanly in
// Office documents (Word/PPT render SVG inconsistently across versions).
// Usage: node scripts/svg-to-png.mjs <input.svg> <output.png> [widthPx]

import { readFile, writeFile } from "node:fs/promises";
import sharp from "sharp";

const [, , input, output, widthStr] = process.argv;
if (!input || !output) {
  console.error("Usage: svg-to-png.mjs <input.svg> <output.png> [widthPx]");
  process.exit(1);
}

const widthPx = widthStr ? parseInt(widthStr, 10) : 1800;
const svg = await readFile(input);
// density boosts the rasterisation DPI so the resulting PNG is sharp.
const buf = await sharp(svg, { density: 192 })
  .resize({ width: widthPx, withoutEnlargement: false })
  .png()
  .toBuffer();
await writeFile(output, buf);
console.log(`wrote ${output} (${buf.byteLength} bytes, ${widthPx}px wide)`);
