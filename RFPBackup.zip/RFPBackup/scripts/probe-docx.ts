import { readFile } from "node:fs/promises";
import JSZip from "jszip";
import { parseAndProcess } from "../src/lib/parsers/pipeline";

async function main() {
  const path = process.argv[2] ?? "C:/Users/bkkom/Downloads/technology_report_5pages.docx";
  const buf = await readFile(path);
  console.log(`DOCX: ${path} (${buf.byteLength} bytes)`);

  // Raw zip scan — list everything under word/media/
  try {
    const zip = await JSZip.loadAsync(buf);
    const media = Object.values(zip.files).filter((f) => !f.dir && /^word\/media\//i.test(f.name));
    console.log(`  raw media entries: ${media.length}`);
    media.slice(0, 10).forEach((m) => console.log(`    - ${m.name}`));
  } catch (e) {
    console.log(`  zip read failed: ${e instanceof Error ? e.message : String(e)}`);
  }

  // Full pipeline
  const result = await parseAndProcess(
    buf,
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "test.docx",
    { enableOcr: false } as Parameters<typeof parseAndProcess>[3],
  );
  console.log(`  pipeline images: ${result.images?.length ?? 0}`);
  console.log(`  pipeline chunks: ${result.chunks.length}`);
  console.log(`  warnings: ${result.ast.report.warnings.length}`);
  result.ast.report.warnings.slice(0, 5).forEach((w) =>
    console.log(`    ! ${w.code}: ${w.message.slice(0, 160)}`),
  );
}
main().catch((e) => {
  console.error("FAILED", e);
  process.exit(1);
});
