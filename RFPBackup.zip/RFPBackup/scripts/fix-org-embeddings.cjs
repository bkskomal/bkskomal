// Set every org's embedding config to the in-process local provider. Safe
// idempotent fix for orgs whose embedding was pointed at OpenRouter (which
// doesn't serve embeddings) during early setup.

const { Client } = require("pg");

(async () => {
  const c = new Client({
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: process.env.PGPASSWORD,
    database: "autorfp",
  });
  await c.connect();

  const bad = await c.query(`
    SELECT "organizationId", "embeddingBaseUrl"
    FROM "OrgAiConfig"
    WHERE "embeddingBaseUrl" IS NOT NULL
      AND "embeddingBaseUrl" NOT LIKE 'local://%'
      AND ("embeddingBaseUrl" LIKE '%openrouter%' OR "embeddingModel" = 'placeholder')
  `);
  console.log(`Found ${bad.rowCount} org config rows pointing embedding at a non-embedding endpoint.`);

  const r = await c.query(`
    UPDATE "OrgAiConfig"
    SET
      "embeddingProvider"   = 'LOCAL',
      "embeddingBaseUrl"    = 'local://transformers',
      "embeddingApiKeyEncrypted" = NULL,
      "embeddingModel"      = 'Xenova/all-MiniLM-L6-v2',
      "embeddingDimensions" = 384
    WHERE "embeddingBaseUrl" IS NOT NULL
      AND "embeddingBaseUrl" NOT LIKE 'local://%'
      AND ("embeddingBaseUrl" LIKE '%openrouter%' OR "embeddingModel" = 'placeholder')
  `);
  console.log(`Updated ${r.rowCount} row(s) to local://transformers / Xenova/all-MiniLM-L6-v2 / 384-dim.`);

  await c.end();
})();
