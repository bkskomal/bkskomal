#!/usr/bin/env node
// Re-encrypt every stored secret under the current AUTH_SECRET.
//
// When AUTH_SECRET is rotated (and the old value moved to KEY_ROTATION_SECRET
// so existing rows remain readable), run this script to walk every encrypted
// column and rewrite the ciphertext using the new master key. After the
// script completes you can drop KEY_ROTATION_SECRET on the next deploy.
//
// Idempotent: re-running it after a successful pass simply re-encrypts the
// same plaintexts under the same key — no schema changes, no data loss. Rows
// that fail to decrypt (e.g. row written under a different secret that's no
// longer reachable) are reported but not modified.
//
// Usage:
//   node scripts/reencrypt-secrets.mjs            # apply
//   node scripts/reencrypt-secrets.mjs --dry-run  # report only, no writes
//
// The crypto envelope format (v2: prefix + base64(iv|tag|ct), plus legacy
// "iv:ct:tag" fallback) is intentionally re-implemented here in plain ESM so
// the script doesn't need a TypeScript loader. Keep it in sync with
// src/lib/crypto.ts — both are tiny and the duplication has paid off in
// portability every time I've reached for one of these scripts.

import process from "node:process";
import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from "node:crypto";
import { PrismaClient } from "@prisma/client";

const DRY_RUN = process.argv.includes("--dry-run");
const CURRENT_KEY_ID = "v2";
const ALGO = "aes-256-gcm";
const IV_LEN = 12;
const TAG_LEN = 16;

const AUTH_SECRET = process.env.AUTH_SECRET;
const ROTATION_SECRET = process.env.KEY_ROTATION_SECRET;

if (!AUTH_SECRET) {
  console.error("AUTH_SECRET must be set.");
  process.exit(2);
}

const primaryKey = createHash("sha256").update(AUTH_SECRET).digest();
const rotationKey = ROTATION_SECRET
  ? createHash("sha256").update(ROTATION_SECRET).digest()
  : null;

function tryDecrypt(key, iv, tag, ct) {
  try {
    const decipher = createDecipheriv(ALGO, key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ct), decipher.final()]).toString("utf8");
  } catch {
    return null;
  }
}

function decrypt(envelope) {
  if (!envelope) return null;
  // v2 path: prefix + base64(iv|tag|ct)
  if (envelope.startsWith(`${CURRENT_KEY_ID}:`)) {
    let buf;
    try {
      buf = Buffer.from(envelope.slice(CURRENT_KEY_ID.length + 1), "base64");
    } catch {
      return null;
    }
    if (buf.length < IV_LEN + TAG_LEN + 1) return null;
    const iv = buf.subarray(0, IV_LEN);
    const tag = buf.subarray(IV_LEN, IV_LEN + TAG_LEN);
    const ct = buf.subarray(IV_LEN + TAG_LEN);
    return tryDecrypt(primaryKey, iv, tag, ct)
      ?? (rotationKey ? tryDecrypt(rotationKey, iv, tag, ct) : null);
  }
  // Legacy path: "iv:ct:tag" base64.
  const parts = envelope.split(":");
  if (parts.length !== 3) return null;
  let iv;
  let ct;
  let tag;
  try {
    iv = Buffer.from(parts[0], "base64");
    ct = Buffer.from(parts[1], "base64");
    tag = Buffer.from(parts[2], "base64");
  } catch {
    return null;
  }
  if (iv.length !== IV_LEN || tag.length !== TAG_LEN) return null;
  return tryDecrypt(primaryKey, iv, tag, ct)
    ?? (rotationKey ? tryDecrypt(rotationKey, iv, tag, ct) : null);
}

function encrypt(plaintext) {
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGO, primaryKey, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  const blob = Buffer.concat([iv, tag, enc]).toString("base64");
  return `${CURRENT_KEY_ID}:${blob}`;
}

const prisma = new PrismaClient();

const ENCRYPTED_COLUMNS = [
  {
    label: "OrgAiConfig",
    table: () => prisma.orgAiConfig,
    fields: ["llmApiKeyEncrypted", "embeddingApiKeyEncrypted", "llamaParseApiKeyEncrypted"],
  },
];

function summarise(label, stats) {
  console.log(
    `  ${label.padEnd(20)} considered=${stats.considered} rewrote=${stats.rewrote} ` +
      `already-v2=${stats.alreadyV2} failed=${stats.failed}`,
  );
}

async function reencryptTable({ label, table, fields }) {
  const rows = await table().findMany();
  const stats = { considered: 0, rewrote: 0, alreadyV2: 0, failed: 0 };
  for (const row of rows) {
    const update = {};
    let touched = false;
    for (const field of fields) {
      const cipher = row[field];
      if (cipher == null) continue;
      stats.considered += 1;
      const plain = decrypt(cipher);
      if (plain === null) {
        stats.failed += 1;
        console.warn(`  ! ${label} id=${row.id} field=${field}: decrypt failed — skipped`);
        continue;
      }
      update[field] = encrypt(plain);
      touched = true;
      if (cipher.startsWith(`${CURRENT_KEY_ID}:`)) {
        stats.alreadyV2 += 1;
      } else {
        stats.rewrote += 1;
      }
    }
    if (touched && !DRY_RUN) {
      await table().update({ where: { id: row.id }, data: update });
    }
  }
  summarise(label, stats);
  return stats;
}

async function main() {
  console.log(
    `[reencrypt-secrets] starting${DRY_RUN ? " (dry run)" : ""} — target key=${CURRENT_KEY_ID}`,
  );
  if (rotationKey) console.log("  KEY_ROTATION_SECRET is set — will try fallback decryption.");
  const totals = { considered: 0, rewrote: 0, alreadyV2: 0, failed: 0 };
  for (const t of ENCRYPTED_COLUMNS) {
    const s = await reencryptTable(t);
    totals.considered += s.considered;
    totals.rewrote += s.rewrote;
    totals.alreadyV2 += s.alreadyV2;
    totals.failed += s.failed;
  }
  console.log("[reencrypt-secrets] done.");
  console.log(`  total considered=${totals.considered}`);
  console.log(`  total rewrote (legacy or rotation-key→current)=${totals.rewrote}`);
  console.log(`  total already-v2 (re-encrypted under same key, harmless)=${totals.alreadyV2}`);
  console.log(`  total failed (decrypt error, left untouched)=${totals.failed}`);
  if (totals.failed > 0) {
    console.error(
      "[reencrypt-secrets] some rows could not be decrypted. Either set " +
        "KEY_ROTATION_SECRET to the matching old AUTH_SECRET and re-run, or ask the " +
        "org admin to re-enter the key via the Rotate dialog in Settings.",
    );
    process.exitCode = 1;
  }
}

main()
  .catch((err) => {
    console.error("[reencrypt-secrets] fatal:", err);
    process.exit(2);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
