const { Client } = require("pg");

(async () => {
  const password = process.env.PGPASSWORD;
  if (!password) {
    console.error("Set PGPASSWORD");
    process.exit(1);
  }
  const c = new Client({
    host: "localhost",
    port: 5432,
    user: "postgres",
    password,
    database: "postgres",
  });
  await c.connect();
  const r = await c.query("SELECT 1 FROM pg_database WHERE datname='autorfp'");
  if (r.rowCount === 0) {
    await c.query("CREATE DATABASE autorfp");
    console.log("created database: autorfp");
  } else {
    console.log("database autorfp already exists");
  }
  await c.end();
})().catch((e) => {
  console.error("ERR:", e.message);
  process.exit(2);
});
