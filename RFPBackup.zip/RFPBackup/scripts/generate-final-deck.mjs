// Generate the final AutoRFP deliverables — a slide deck (PPT) and a
// full-detail Word document — into E:\AI\PPTs\AutoRFT.
//
// The PPT uses the design language extracted from "Sample PPT.pptx"
// (dark navy gradient bg + Calibri Light typography + colour-chip badges
// + sky-blue subtitle + muted-grey tagline) and pulls its content from:
//   • E:\AI\PPTs\AutoRFT\RFP_Modern.pptx           (process flow, KB schema,
//                                                   model comparisons, roadmap)
//   • E:\AI\PPTs\AutoRFT\AutoRFP-vs-reference.pptx (head-to-head scorecard +
//                                                   decisive advantages)
//   • E:\AI\PPTs\AutoRFT\AutoRFP-architecture.svg  (system diagram)
//
// The Word document carries the same content in long-form with cover page,
// table of contents, and page-numbered footer.

import path from "node:path";
import { writeFile } from "node:fs/promises";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import PptxGenJS from "pptxgenjs";
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  ImageRun,
  PageBreak,
  Header,
  Footer,
  PageNumber,
  TableOfContents,
  StyleLevel,
  LevelFormat,
  Tab,
  TabStopType,
  TabStopPosition,
  ShadingType,
  convertInchesToTwip,
} from "docx";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT_DIR = "E:/AI/PPTs/AutoRFT";
const PPT_PATH = path.join(OUT_DIR, "AutoRFP-final.pptx");
const DOC_PATH = path.join(OUT_DIR, "AutoRFP-final.docx");
const ARCH_PNG = path.join(OUT_DIR, "AutoRFP-architecture.png");
// Logo extracted from Sample PPT.pptx (ppt/media/image1.png — 900×685).
// Sits in the navy header bar at the top of every interior slide.
const LOGO_PNG = path.join(OUT_DIR, "oati-logo.png");

// ============================================================
// Design tokens lifted directly from "Sample PPT.pptx"
// ============================================================

const SAMPLE = {
  // Slide canvas — same 16:9 small as the sample
  layout: "LAYOUT_16x9",   // 10" × 5.625"
  width: 10,
  height: 5.625,

  // Cover slide uses the deep navy palette (matches sample slide 1).
  bgTopCover: "1A2B4A",
  bgBottomCover: "162038",

  // Header bar at the top of every interior slide (matches sample slide 2).
  // Height 0.75" (685800 EMU) — fits a 0.85" logo neatly with room for title.
  headerBg: "1A2B4A",
  headerHeight: 0.75,

  // Footer bar at the bottom of every interior slide. Slim (~0.2") + nearly
  // black text on white-ish grey is the sample's confidentiality strip.
  footerBg: "1A2B4A",
  footerHeight: 0.21,
  footerText: "E7E6E6",
  footerNote: "PROPRIETARY AND CONFIDENTIAL  |  OATI AutoRFP  |  v1.0",

  // Light body — the sample slide 2 uses #F8F9FA, not dark navy. Interior
  // slides flip the colour scheme: light bg + dark navy chrome.
  bodyBg: "F8F9FA",

  // Typography
  fontBody: "Calibri Light",
  fontHeading: "Calibri Light",
  titleSize: 34,
  subSize: 28,
  taglineSize: 13,
  bodySize: 11,
  metaSize: 9,
  chipSize: 9,

  // Light-mode palette (used on the body of interior slides)
  textDark: "162038",      // primary text on light bg
  textMutedDark: "5B6A7F", // muted text on light bg
  divider: "CBD5E1",
  cardBgLight: "FFFFFF",
  cardBorderLight: "E2E8F0",

  // Dark-mode palette (used on the cover + chrome bars)
  white: "FFFFFF",
  textMuted: "8C9BAB",
  subtitleBlue: "5B9BD5",
  accentRed: "CC0000",

  // Chip / accent colours
  chipBlue: "2563EB",
  chipViolet: "7C3AED",
  chipAmber: "D97706",
  chipEmerald: "16A34A",
  chipPink: "EC4899",
  chipCyan: "06B6D4",

  // Status accent (used on metric callouts)
  ok: "22C55E",
  warn: "F59E0B",
  bad: "EF4444",
};

// ============================================================
// Content (single source of truth — used by both PPT and Word)
// ============================================================

const TITLE = "OATI AutoRFP";
const SUBTITLE = "AI-Assisted RFP Response Platform";
const TAGLINE = "Production-Grade · Multi-modal · Citation-Grounded · v1.0";

const VALUE_PILLARS = [
  ["Grounded", "Answers come only from the KB — no hallucination", SAMPLE.chipBlue],
  ["Consistent", "Formal voice aligned to organisational standards", SAMPLE.chipViolet],
  ["Faster", "Cut time-per-question by orders of magnitude", SAMPLE.chipAmber],
  ["SME in the loop", "Experts review and approve every draft", SAMPLE.chipEmerald],
];

// Current manual RFP process (from RFP_Modern slide 5)
const CURRENT_PROCESS = [
  ["Receive RFP Docs", "PDF · Word · Excel"],
  ["Initial Review & Prep", "Categorise (technical · pricing · legal); build template"],
  ["Coordinate Sales", "Review scope · define ownership · agree timelines"],
  ["Assign to SMEs", "Per-section subject-matter expert ownership"],
  ["Response Prep", "Search webSupport · reuse or write fresh"],
  ["Consolidate & Deliver", "Merge per-SME answers · remove duplicates · format"],
];

// Current challenges (from RFP_Modern slide 6)
const CURRENT_CHALLENGES = [
  ["Multiple formats", "PDF, Excel, Word — every customer is different"],
  ["Manual question extraction", "Slow + inconsistent across reviewers"],
  ["Coordination overhead", "SME assignment needs meetings + spreadsheets"],
  ["Manual KB search", "Hard to find the best historical answer"],
  ["Repetitive drafting", "Same questions answered again and again"],
  ["Inconsistent consolidation", "Duplicate content + formatting drift"],
];

// 9-step AI-assisted pipeline (the canonical AutoRFP flow)
const AI_PROCESS_STEPS = [
  { n: 1, label: "Receive RFP Docs", detail: "PDF · Word · Excel uploaded", color: SAMPLE.chipBlue },
  { n: 2, label: "AI Ingestion Pipeline", detail: "Document parsing + table extraction", color: SAMPLE.chipBlue },
  { n: 3, label: "Question Extraction Engine", detail: "AI identifies & categorises every question", color: SAMPLE.chipBlue },
  { n: 4, label: "RAG Search against KB", detail: "Vector search + semantic retrieval", color: SAMPLE.chipBlue },
  { n: 5, label: "LLM Draft Response", detail: "Using historical approved answers", color: SAMPLE.chipBlue },
  { n: 6, label: "SME Review / Edit", detail: "Subject-matter experts polish the draft", color: SAMPLE.chipAmber },
  { n: 7, label: "Proposal Team Approval", detail: "Lead approves every response", color: SAMPLE.chipAmber },
  { n: 8, label: "Auto Consolidation", detail: "Merge into master template", color: SAMPLE.chipEmerald },
  { n: 9, label: "Approved → KB", detail: "Mine back to knowledge base", color: SAMPLE.chipEmerald },
];

// Knowledge base shape (from RFP_Modern slide 7)
const KB_SCHEMA = [
  ["Question", "TEXT", "RFP question text"],
  ["Response", "TEXT (LONG)", "Approved answer — avg 280 chars, up to 30K"],
  ["Category", "VARCHAR", "16 distinct categories"],
  ["Product", "VARCHAR", "44 distinct products"],
  ["Company", "VARCHAR", "242 distinct companies"],
  ["Date Added", "DATE", "Record creation date"],
];

// Data-source stats (from RFP_Modern slide 8)
const KB_STATS = [
  ["46,476", "Q/A Records"],
  ["53 MB", "Database Size"],
  ["16", "Categories"],
  ["44", "Products"],
  ["242", "Companies"],
];

// LLM model comparison (from RFP_Modern slide 11 + our actual picks)
const LLM_COMPARISON = {
  header: ["Capability", "Qwen 2.5 72B", "Llama 3.3 70B", "GPT-OSS 120B ★", "GPT-4o", "Llama 3.1 8B"],
  rows: [
    ["Grounding (RAG / MMLU)", "High", "High", "High", "Very High", "Low"],
    ["Writing quality (formal)", "High", "High", "High", "Very High", "Med"],
    ["Tool / function calling", "Good", "Good", "Excellent", "Excellent", "OK"],
    ["Structured output (JSON)", "Good", "Good", "Excellent", "Excellent", "Good"],
    ["Cost (per 1M tokens)", "$", "$", "$$", "$$$$", "¢"],
    ["Open weights", "Yes", "Yes", "Yes", "No", "Yes"],
  ],
};

// Embedding model comparison (from RFP_Modern slide 12 + our pick)
const EMBED_COMPARISON = {
  header: ["Capability", "Qwen3 Embed 8B", "Jina v5", "E5-Mistral 7B", "BGE Base v1.5 ★"],
  rows: [
    ["MTEB Retrieval", "70.6", "71.7", "~60", "63"],
    ["Image support (CLIP-pair)", "No", "No", "No", "Yes (via CLIP)"],
    ["Dimensions", "4096", "1024", "4096", "768"],
    ["Size (fp16)", "~16 GB", "~2 GB", "~14 GB", "~440 MB"],
    ["Runs in-process (Node)", "No", "No", "No", "Yes"],
    ["License", "Permissive", "Commercial", "Apache 2", "MIT"],
  ],
};

const CAPABILITIES = [
  ["Multi-format ingest", "PDF · DOCX · XLSX · PPTX · HTML · URL"],
  ["URL scrape + site crawl", "BFS · robots.txt · image extraction"],
  ["Multimodal embeddings", "BGE 768 (text) + CLIP 512 (images)"],
  ["Hybrid retrieval", "BM25 + Dense + RRF + optional LLM rerank"],
  ["Question extraction", "2-stage · structure + eligibility classifier"],
  ["Grounding judge", "Per-claim verification before approval"],
  ["Chat with KB", "Per-RFP / Project / KB scoped · tool-calling"],
  ["Self-healing pipeline", "9-step engine · AUTO retries · MANUAL gates"],
];

// Scorecard from AutoRFP-vs-reference slide 1
const COMPARISON_SCORES = {
  dims: [
    ["Output quality", 10, 7],
    ["Code correctness", 10, 8],
    ["Architecture", 10, 8],
    ["Security / prod-ready", 10, 6],
    ["Overall", 10, 7],
  ],
};

// Decisive advantages (from AutoRFP-vs-reference slide 1)
const DECISIVE = [
  ["Rate-limit + circuit breaker", "Token bucket + Redis + per-provider breaker", "Ref: unmetered LLM calls (cost / DoS risk)"],
  ["At-rest encryption", "AES-256-GCM, versioned, zero-downtime key rotation", "Ref: API keys as plain env vars"],
  ["Audit trail", "AuditLog model + wired events + admin viewer", "Ref: none — blocks SOC 2 / GDPR"],
  ["Structured logging", "Pino + AsyncLocalStorage reqId propagation", "Ref: console.log scattered in prod paths"],
  ["Test coverage", "828 Vitest tests across 87 files", "Ref: spotty"],
  ["Multi-tenant", "Per-org Milvus partition + RLS-style filters", "Ref: single tenant"],
];

const ROADMAP = [
  {
    phase: "Phase 1 — Foundation",
    status: "shipped",
    items: [
      "Multi-format ingestion + chunking + embedding",
      "Hybrid retrieval (BM25 + Dense + RRF)",
      "Single-question response generation w/ citations",
      "Org / project / RFP / KB scoped chat",
    ],
  },
  {
    phase: "Phase 2 — Automation",
    status: "shipped",
    items: [
      "Bulk-generate engine + SSE progress",
      "Pipeline templates · pause / resume / decisions",
      "URL scraper + site crawler with images",
      "Chat → RFP (start_rfp_process tool)",
    ],
  },
  {
    phase: "Phase 3 — Quality & Scale",
    status: "shipped",
    items: [
      "Grounding judge for per-claim verification",
      "Semantic golden retrieval (BGE)",
      "Auto Q&A re-mining to golden-answers KB",
      "Multi-doc RFP packages (primary + addendum + matrix)",
    ],
  },
  {
    phase: "Phase 4 — Operate at scale",
    status: "next",
    items: [
      "Per-org Slack / Teams notification rules",
      "Approval workflows with reviewer routing",
      "S3-compatible storage drop-in",
      "K8s + Redis horizontal-scale guide",
    ],
  },
];

const TECH_STACK = [
  ["Frontend", "Next.js 15 · TypeScript · Tailwind + shadcn/ui"],
  ["API", "Route Handlers · Server Actions · SSE streams"],
  ["Auth", "NextAuth · Google · GitHub · Microsoft · SAML"],
  ["DB / ORM", "PostgreSQL · Prisma 6"],
  ["Vector store", "Milvus 2.5 (HNSW · COSINE · per-org partition)"],
  ["Models", "OpenRouter · OpenAI · Ollama · @huggingface/transformers"],
  ["Image", "Sharp · pdfjs-dist · jszip · CLIP via transformers.js"],
  ["Web ingest", "jsdom · @mozilla/readability · cheerio · undici"],
  ["Rate-limit / cache", "Redis (optional) · in-memory fallback"],
  ["Obs / logs", "Prometheus + Grafana · Pino structured logs"],
];

// ============================================================
// PPT generator — matches the Sample PPT visual language
// ============================================================

async function buildPpt() {
  const pres = new PptxGenJS();
  pres.layout = SAMPLE.layout; // 10" × 5.625"
  pres.title = `${TITLE} — ${SUBTITLE}`;
  pres.company = "OATI";

  const W = SAMPLE.width;
  const H = SAMPLE.height;

  // -------- helpers ----------------------------------------

  // bg(slide) lays down the interior-slide chrome:
  //   • light off-white body fill (#F8F9FA)
  //   • navy header bar across the top (~0.75" tall) with the logo on the left
  //   • navy thin footer bar across the bottom (~0.21" tall) with confidentiality
  // Mirrors the Sample PPT slide 2 layout exactly.
  function bg(slide) {
    slide.background = { color: SAMPLE.bodyBg };

    // Top navy header bar
    slide.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: W, h: SAMPLE.headerHeight,
      fill: { color: SAMPLE.headerBg }, line: { color: SAMPLE.headerBg },
    });
    // Logo on the left of the header
    try {
      slide.addImage({
        path: LOGO_PNG,
        x: 0.08, y: 0.05, w: 0.85, h: 0.66,
        sizing: { type: "contain", w: 0.85, h: 0.66 },
      });
    } catch {
      // If the logo file is missing, fall back to a text mark so we still
      // render a header label on the left.
      slide.addText("OATI AutoRFP", {
        x: 0.12, y: 0.18, w: 1.8, h: 0.4,
        fontSize: 16, bold: true, color: SAMPLE.white,
        fontFace: SAMPLE.fontHeading,
      });
    }

    // Bottom navy footer bar
    slide.addShape(pres.ShapeType.rect, {
      x: 0, y: H - SAMPLE.footerHeight, w: W, h: SAMPLE.footerHeight,
      fill: { color: SAMPLE.footerBg }, line: { color: SAMPLE.footerBg },
    });
  }

  // header(slide, kicker, title, subtitle) renders the slide-specific
  // labelling. Title is white-on-navy inside the header bar; the optional
  // kicker is a small uppercase label above it. Subtitle drops onto the
  // light body under the bar.
  function header(slide, kicker, title, subtitle) {
    // Title text (right of the logo, white inside the navy bar)
    slide.addText(title, {
      x: 1.05, y: 0.04, w: W - 1.25, h: 0.4,
      fontSize: 19, bold: true, color: SAMPLE.white,
      fontFace: SAMPLE.fontHeading, valign: "middle",
    });
    if (kicker) {
      slide.addText(kicker.toUpperCase(), {
        x: 1.05, y: 0.44, w: W - 1.25, h: 0.25,
        fontSize: 8.5, bold: true, color: SAMPLE.subtitleBlue,
        fontFace: SAMPLE.fontBody, charSpacing: 3, valign: "middle",
      });
    }
    // Subtitle sits on the light body just under the header bar
    if (subtitle) {
      slide.addText(subtitle, {
        x: 0.5, y: SAMPLE.headerHeight + 0.12, w: W - 1, h: 0.3,
        fontSize: 11, color: SAMPLE.textMutedDark,
        fontFace: SAMPLE.fontBody, italic: true,
      });
    }
  }

  // footer(slide, n, total) — adds the confidentiality strip + page number
  // inside the navy footer bar. The bar itself is drawn by bg().
  function footer(slide, n, total) {
    slide.addText(SAMPLE.footerNote, {
      x: 0.2, y: H - SAMPLE.footerHeight + 0.025, w: W - 1.0, h: SAMPLE.footerHeight - 0.05,
      fontSize: 7, color: SAMPLE.footerText, fontFace: SAMPLE.fontBody, valign: "middle",
    });
    slide.addText(`${n}`, {
      x: W - 0.6, y: H - SAMPLE.footerHeight + 0.025, w: 0.4, h: SAMPLE.footerHeight - 0.05,
      fontSize: 7, color: SAMPLE.footerText, fontFace: SAMPLE.fontBody, align: "right", valign: "middle",
    });
    void total;
  }

  function chip(slide, x, y, w, h, label, color = SAMPLE.chipBlue) {
    slide.addShape(pres.ShapeType.roundRect, {
      x, y, w, h, rectRadius: 0.05,
      fill: { color }, line: { color },
    });
    slide.addText(label, {
      x, y, w, h, fontSize: 9, bold: true, color: SAMPLE.white,
      fontFace: SAMPLE.fontBody, align: "center", valign: "middle",
    });
  }

  // White card on light body, with optional coloured accent stripe on the left.
  function card(slide, x, y, w, h, title, body, accentColor) {
    slide.addShape(pres.ShapeType.roundRect, {
      x, y, w, h, rectRadius: 0.08,
      fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.75 },
    });
    if (accentColor) {
      slide.addShape(pres.ShapeType.rect, {
        x, y, w: 0.06, h, fill: { color: accentColor }, line: { color: accentColor },
      });
    }
    slide.addText(title, {
      x: x + 0.18, y: y + 0.08, w: w - 0.3, h: 0.35,
      fontSize: 12, bold: true, color: SAMPLE.textDark,
      fontFace: SAMPLE.fontHeading,
    });
    slide.addText(body, {
      x: x + 0.18, y: y + 0.46, w: w - 0.3, h: h - 0.55,
      fontSize: 9.5, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody,
    });
  }

  function metricStat(slide, x, y, w, value, label, color) {
    slide.addText(value, {
      x, y, w, h: 0.6,
      fontSize: 28, bold: true, color: color ?? SAMPLE.textDark,
      fontFace: SAMPLE.fontHeading, align: "center",
    });
    slide.addText(label, {
      x, y: y + 0.55, w, h: 0.3,
      fontSize: 10, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody, align: "center",
    });
  }

  function styledTable(slide, x, y, w, headers, rows, colW, starColIdx = -1) {
    const headerRow = headers.map((h, i) => ({
      text: h,
      options: {
        bold: true, fontSize: 9.5, color: SAMPLE.white,
        fill: { color: i === starColIdx ? SAMPLE.chipBlue : SAMPLE.headerBg },
        fontFace: SAMPLE.fontBody, align: "left", valign: "middle",
      },
    }));
    const dataRows = rows.map((r, ri) => r.map((c, i) => ({
      text: c,
      options: {
        fontSize: 9, color: i === starColIdx ? SAMPLE.chipBlue : SAMPLE.textDark,
        bold: i === starColIdx,
        fill: { color: ri % 2 === 0 ? SAMPLE.cardBgLight : SAMPLE.bodyBg },
        fontFace: SAMPLE.fontBody, valign: "middle",
      },
    })));
    slide.addTable([headerRow, ...dataRows], {
      x, y, w, colW,
      border: { type: "solid", pt: 0.4, color: SAMPLE.divider },
      autoPage: false,
    });
  }

  const slidesPlanned = 15;
  let slideN = 0;
  function pageNum(slide) {
    slideN++;
    footer(slide, slideN, slidesPlanned);
  }

  // ============================================================
  // Slide 1 — Cover (mirrors Sample PPT slide 1)
  // ============================================================
  {
    const s = pres.addSlide();
    s.background = { color: SAMPLE.bgBottomCover };
    s.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: W, h: H,
      fill: {
        type: "solid", color: SAMPLE.bgTopCover,
      },
      line: { color: SAMPLE.bgTopCover },
    });
    // Brand accent stripe on the left
    s.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: 0.15, h: H,
      fill: { color: SAMPLE.accentRed }, line: { color: SAMPLE.accentRed },
    });

    s.addText(TITLE, {
      x: 0.7, y: 1.0, w: W - 1.0, h: 1.0,
      fontSize: SAMPLE.titleSize, bold: true, color: SAMPLE.white, fontFace: SAMPLE.fontHeading,
    });
    s.addText(SUBTITLE, {
      x: 0.7, y: 1.95, w: W - 1.0, h: 0.55,
      fontSize: SAMPLE.subSize, color: SAMPLE.subtitleBlue, fontFace: SAMPLE.fontHeading,
    });
    s.addText(TAGLINE, {
      x: 0.7, y: 2.55, w: W - 1.0, h: 0.3,
      fontSize: SAMPLE.taglineSize, color: SAMPLE.textMuted, fontFace: SAMPLE.fontBody,
    });

    // Four chip badges (matches Sample's evaluation-suite chip row)
    const chipY = 3.1, chipH = 0.32, chipGap = 0.15;
    const chipW = 1.4;
    VALUE_PILLARS.forEach((p, i) => {
      chip(s, 0.7 + i * (chipW + chipGap), chipY, chipW, chipH, p[0], p[2]);
    });

    // Lower band — Quick stats card
    s.addShape(pres.ShapeType.roundRect, {
      x: 0.7, y: 3.7, w: W - 1.4, h: 1.2, rectRadius: 0.08,
      fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
    });
    s.addText("PLATFORM AT A GLANCE", {
      x: 0.9, y: 3.78, w: W - 1.8, h: 0.25,
      fontSize: 8.5, bold: true, color: SAMPLE.subtitleBlue,
      fontFace: SAMPLE.fontBody, charSpacing: 3,
    });
    const glance = [
      ["9-step", "pipeline"],
      ["BGE 768", "embeddings"],
      ["GPT-OSS 120B", "drafts"],
      ["Milvus", "vector DB"],
      ["828", "tests"],
    ];
    glance.forEach((g, i) => {
      const w = (W - 1.8) / glance.length;
      const x = 0.9 + i * w;
      s.addText(g[0], {
        x, y: 4.05, w, h: 0.4,
        fontSize: 16, bold: true, color: SAMPLE.white,
        fontFace: SAMPLE.fontHeading, align: "center",
      });
      s.addText(g[1], {
        x, y: 4.45, w, h: 0.25,
        fontSize: 9, color: SAMPLE.textMuted,
        fontFace: SAMPLE.fontBody, align: "center",
      });
    });

    s.addText(`Prepared by OATI AutoRFP Team  ·  ${new Date().getFullYear()}`, {
      x: 0.7, y: H - 0.5, w: W - 1.4, h: 0.3,
      fontSize: 10, color: SAMPLE.subtitleBlue, fontFace: SAMPLE.fontBody, align: "right",
    });
    slideN++;
  }

  // ============================================================
  // Slide 2 — Objective / What AutoRFP does
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Objective", "Automate RFP responses with generative AI", "Eliminate repetitive work so SMEs can focus on review, not drafting.");
    const cards = [
      ["Knowledge Base", "Approved historical RFP responses become retrievable evidence.", SAMPLE.chipBlue],
      ["RAG Pipeline", "Retrieval-Augmented Generation for grounded, hallucination-free answers.", SAMPLE.chipViolet],
      ["Chat + Workflow", "Per-RFP chat, file attach, and pipeline kicker — all in one UI.", SAMPLE.chipAmber],
      ["Writing-tuned LLM", "Model selected for formal, structured proposal writing.", SAMPLE.chipEmerald],
    ];
    const cw = (W - 1.2) / 2;
    cards.forEach((c, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      card(s, 0.5 + col * (cw + 0.2), 1.5 + row * 1.7, cw, 1.5, c[0], c[1], c[2]);
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 3 — Current manual process
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Today", "Current RFP response process", "Six manual steps — labour-intensive and error-prone.");
    const stepW = (W - 1.2) / 6;
    CURRENT_PROCESS.forEach((step, i) => {
      const x = 0.5 + i * (stepW + 0.05);
      const y = 1.7;
      s.addShape(pres.ShapeType.roundRect, {
        x, y, w: stepW, h: 1.6, rectRadius: 0.08,
        fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
      });
      // Step number badge
      s.addShape(pres.ShapeType.ellipse, {
        x: x + (stepW - 0.4) / 2, y: y + 0.15, w: 0.4, h: 0.4,
        fill: { color: SAMPLE.subtitleBlue }, line: { color: SAMPLE.subtitleBlue },
      });
      s.addText(String(i + 1), {
        x: x + (stepW - 0.4) / 2, y: y + 0.15, w: 0.4, h: 0.4,
        fontSize: 14, bold: true, color: SAMPLE.white, align: "center", valign: "middle",
        fontFace: SAMPLE.fontHeading,
      });
      s.addText(step[0], {
        x: x + 0.1, y: y + 0.65, w: stepW - 0.2, h: 0.4,
        fontSize: 10.5, bold: true, color: SAMPLE.textDark, fontFace: SAMPLE.fontHeading, align: "center",
      });
      s.addText(step[1], {
        x: x + 0.1, y: y + 1.0, w: stepW - 0.2, h: 0.55,
        fontSize: 8.5, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody, align: "center",
      });
    });
    s.addText("Teams manually extract questions, search the KB, adapt previous answers, and consolidate responses.", {
      x: 0.5, y: 3.6, w: W - 1, h: 0.4,
      fontSize: 10, color: SAMPLE.headerBg, italic: true, fontFace: SAMPLE.fontBody, align: "center",
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 4 — Current challenges
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Pain Points", "Where the current process breaks down");
    const cw = (W - 1.2) / 3;
    const ch = 1.05;
    CURRENT_CHALLENGES.forEach((ch_, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      card(s, 0.5 + col * (cw + 0.1), 1.6 + row * (ch + 0.15), cw, ch, ch_[0], ch_[1], SAMPLE.accentRed);
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 5 — Knowledge Base schema + stats
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Knowledge Base", "Curated, reviewed, approved Q/A pairs", "Already structured for AI retrieval — fast to vectorise, easy to keep current.");

    // Left half: schema table
    styledTable(
      s,
      0.5, 1.6, 4.6,
      ["Field", "Type", "Notes"],
      KB_SCHEMA,
      [1.2, 1.2, 2.2],
    );

    // Right half: stats grid
    const sx = 5.3, sy = 1.6, sw = W - 5.8;
    s.addShape(pres.ShapeType.roundRect, {
      x: sx, y: sy, w: sw, h: 3.3, rectRadius: 0.08,
      fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
    });
    s.addText("DATA AT A GLANCE", {
      x: sx + 0.2, y: sy + 0.1, w: sw - 0.4, h: 0.3,
      fontSize: 9, bold: true, color: SAMPLE.subtitleBlue,
      fontFace: SAMPLE.fontBody, charSpacing: 3,
    });
    const cellW = (sw - 0.4) / 2;
    KB_STATS.forEach((k, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      metricStat(s, sx + 0.2 + col * cellW, sy + 0.5 + row * 0.95, cellW, k[0], k[1]);
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 6 — AI-Assisted 9-step pipeline
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Tomorrow — Today", "AI-Assisted RFP Response — 9-step pipeline", "Auto steps drive themselves to completion · Manual steps gate on the team.");
    const cols = 3;
    const cellW = (W - 1.2) / cols;
    const cellH = 0.95;
    AI_PROCESS_STEPS.forEach((step, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (cellW + 0.1);
      const y = 1.5 + row * (cellH + 0.12);
      s.addShape(pres.ShapeType.roundRect, {
        x, y, w: cellW, h: cellH, rectRadius: 0.08,
        fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
      });
      s.addShape(pres.ShapeType.rect, {
        x, y, w: 0.05, h: cellH, fill: { color: step.color }, line: { color: step.color },
      });
      chip(s, x + cellW - 0.5, y + 0.08, 0.4, 0.22, String(step.n).padStart(2, "0"), step.color);
      s.addText(step.label, {
        x: x + 0.15, y: y + 0.05, w: cellW - 0.7, h: 0.35,
        fontSize: 11, bold: true, color: SAMPLE.textDark, fontFace: SAMPLE.fontHeading,
      });
      s.addText(step.detail, {
        x: x + 0.15, y: y + 0.45, w: cellW - 0.25, h: cellH - 0.5,
        fontSize: 8.5, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody,
      });
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 7 — Architecture diagram
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Architecture", "System architecture", "UI · API · Ingestion · Retrieval & Generation · Vector store · Models.");
    try {
      s.addImage({ path: ARCH_PNG, x: 0.7, y: 1.4, w: W - 1.4, h: 3.6,
        sizing: { type: "contain", w: W - 1.4, h: 3.6 } });
    } catch {
      s.addText("(architecture diagram — see AutoRFP-architecture.png)", {
        x: 0.5, y: 2.5, w: W - 1, h: 0.4,
        fontSize: 11, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody, align: "center",
      });
    }
    pageNum(s);
  }

  // ============================================================
  // Slide 8 — RAG pipeline detail
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "RAG", "Technology stack — RAG architecture", "Principle: the LLM answers ONLY from retrieved context. Grounded, accurate, no hallucination.");
    const steps = [
      ["1", "Knowledge Base", "Approved Q/A pairs · historical RFP responses · category/product metadata"],
      ["2", "Embedding Model", "BGE Base v1.5 — converts text → 768-d vectors for semantic similarity search"],
      ["3", "Vector Store", "Milvus 2.5 — HNSW index · COSINE · per-org partition · sub-50ms top-K retrieval"],
      ["4", "LLM Drafter", "GPT-OSS 120B with retrieved context only · cites every claim · grounding judge verifies"],
    ];
    const cw = (W - 1.5) / 4;
    steps.forEach((st, i) => {
      const x = 0.5 + i * (cw + 0.13);
      const y = 1.7;
      s.addShape(pres.ShapeType.roundRect, {
        x, y, w: cw, h: 2.5, rectRadius: 0.08,
        fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
      });
      chip(s, x + (cw - 0.4) / 2, y + 0.18, 0.4, 0.28, st[0], SAMPLE.subtitleBlue);
      s.addText(st[1], {
        x: x + 0.1, y: y + 0.6, w: cw - 0.2, h: 0.4,
        fontSize: 11, bold: true, color: SAMPLE.textDark, fontFace: SAMPLE.fontHeading, align: "center",
      });
      s.addText(st[2], {
        x: x + 0.1, y: y + 1.05, w: cw - 0.2, h: 1.3,
        fontSize: 9, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody, align: "center",
      });
      // Arrow between
      if (i < steps.length - 1) {
        s.addText("→", {
          x: x + cw - 0.05, y: y + 1.1, w: 0.2, h: 0.3,
          fontSize: 14, bold: true, color: SAMPLE.subtitleBlue,
          fontFace: SAMPLE.fontBody,
        });
      }
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 9 — LLM model comparison
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Models", "LLM models — comparison", "★ marks the model we ship with by default.");
    styledTable(
      s,
      0.4, 1.5, W - 0.8,
      LLM_COMPARISON.header,
      LLM_COMPARISON.rows,
      [2.0, 1.3, 1.3, 1.5, 1.3, 1.3],
      3, // GPT-OSS 120B column
    );
    pageNum(s);
  }

  // ============================================================
  // Slide 10 — Embedding comparison
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Embeddings", "Embedding models — comparison", "★ marks our pick: small, fast, in-process, no external service.");
    styledTable(
      s,
      0.4, 1.5, W - 0.8,
      EMBED_COMPARISON.header,
      EMBED_COMPARISON.rows,
      [2.4, 1.6, 1.6, 1.7, 1.9],
      4, // BGE column
    );
    pageNum(s);
  }

  // ============================================================
  // Slide 11 — Capabilities
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Capabilities", "Capability highlights", "Eight features that set OATI AutoRFP apart in day-to-day use.");
    const cw = (W - 1.2) / 4;
    const ch = 1.1;
    CAPABILITIES.forEach((cap, i) => {
      const col = i % 4, row = Math.floor(i / 4);
      const colors = [SAMPLE.chipBlue, SAMPLE.chipViolet, SAMPLE.chipAmber, SAMPLE.chipEmerald, SAMPLE.chipPink, SAMPLE.chipCyan, SAMPLE.chipBlue, SAMPLE.chipViolet];
      card(s, 0.5 + col * (cw + 0.1), 1.55 + row * (ch + 0.15), cw, ch, cap[0], cap[1], colors[i]);
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 12 — AutoRFP vs Reference scorecard
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Competitive Comparison", "OATI AutoRFP vs Reference RFP — head-to-head", "Independent audit across 5 dimensions · production-ready scoring.");
    // Two-column layout: scorecard left, big "AutoRFP leads" message right
    const tx = 0.4, ty = 1.5, tw = 5.2;
    s.addShape(pres.ShapeType.roundRect, {
      x: tx, y: ty, w: tw, h: 3.4, rectRadius: 0.08,
      fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
    });
    s.addText("SCORECARD (OUT OF 10)", {
      x: tx + 0.2, y: ty + 0.15, w: tw - 0.4, h: 0.3,
      fontSize: 9, bold: true, color: SAMPLE.subtitleBlue, charSpacing: 3,
      fontFace: SAMPLE.fontBody,
    });
    const rowH = 0.45;
    COMPARISON_SCORES.dims.forEach((d, i) => {
      const y = ty + 0.55 + i * rowH;
      const isOverall = d[0] === "Overall";
      s.addText(d[0], {
        x: tx + 0.2, y, w: tw - 1.8, h: rowH,
        fontSize: 11, bold: isOverall, color: isOverall ? SAMPLE.headerBg : SAMPLE.textDark,
        fontFace: SAMPLE.fontBody, valign: "middle",
      });
      // AutoRFP score (right-aligned, big green)
      s.addText(String(d[1]), {
        x: tx + tw - 1.5, y, w: 0.5, h: rowH,
        fontSize: 16, bold: true, color: SAMPLE.ok, fontFace: SAMPLE.fontHeading, align: "center", valign: "middle",
      });
      s.addText("vs", {
        x: tx + tw - 1.0, y, w: 0.3, h: rowH,
        fontSize: 9, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody, align: "center", valign: "middle",
      });
      s.addText(String(d[2]), {
        x: tx + tw - 0.7, y, w: 0.5, h: rowH,
        fontSize: 16, bold: true, color: d[2] < 7 ? SAMPLE.bad : SAMPLE.warn,
        fontFace: SAMPLE.fontHeading, align: "center", valign: "middle",
      });
    });

    // Right column — key strengths callout
    const rx = 5.8, ry = 1.5, rw = W - 6.2;
    s.addShape(pres.ShapeType.roundRect, {
      x: rx, y: ry, w: rw, h: 3.4, rectRadius: 0.08,
      fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.accentRed, width: 1.5 },
    });
    s.addText("AUTORFP — KEY STRENGTHS", {
      x: rx + 0.2, y: ry + 0.15, w: rw - 0.4, h: 0.3,
      fontSize: 9, bold: true, color: SAMPLE.accentRed, charSpacing: 3,
      fontFace: SAMPLE.fontBody,
    });
    const strengths = [
      "Hybrid retrieval (BM25 + dense + RRF + LLM rerank)",
      "2-stage extraction + eligibility classifier",
      "Pipeline: AUTO · MANUAL · DECISION modes",
      "Production stack — Docker · OAuth · rate-limit · breaker · audit",
      "828 tests · SSE streams · HMAC replay · breaker states",
    ];
    strengths.forEach((str, i) => {
      s.addText(`●  ${str}`, {
        x: rx + 0.25, y: ry + 0.55 + i * 0.5, w: rw - 0.5, h: 0.45,
        fontSize: 10, color: SAMPLE.textDark, fontFace: SAMPLE.fontBody, valign: "middle",
      });
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 13 — Decisive advantages
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Decisive Advantages", "Where the gap is biggest", "Production-readiness — every entry here is a blocker the reference has not solved.");
    const cw = (W - 1.2) / 2;
    const ch = 1.05;
    DECISIVE.forEach((d, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * (cw + 0.1);
      const y = 1.5 + row * (ch + 0.1);
      s.addShape(pres.ShapeType.roundRect, {
        x, y, w: cw, h: ch, rectRadius: 0.06,
        fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
      });
      s.addShape(pres.ShapeType.rect, {
        x, y, w: 0.05, h: ch, fill: { color: SAMPLE.chipEmerald }, line: { color: SAMPLE.chipEmerald },
      });
      s.addText(d[0], {
        x: x + 0.15, y: y + 0.08, w: cw - 0.25, h: 0.3,
        fontSize: 11, bold: true, color: SAMPLE.textDark, fontFace: SAMPLE.fontHeading,
      });
      s.addText(d[1], {
        x: x + 0.15, y: y + 0.38, w: cw - 0.25, h: 0.3,
        fontSize: 9, color: SAMPLE.headerBg, fontFace: SAMPLE.fontBody, italic: true,
      });
      s.addText(d[2], {
        x: x + 0.15, y: y + 0.68, w: cw - 0.25, h: 0.3,
        fontSize: 8.5, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody,
      });
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 14 — Roadmap
  // ============================================================
  {
    const s = pres.addSlide();
    bg(s);
    header(s, "Roadmap", "Phased delivery", "Three phases shipped · Phase 4 in flight.");
    const cw = (W - 1.2) / 2;
    const ch = 1.65;
    ROADMAP.forEach((p_, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * (cw + 0.1);
      const y = 1.55 + row * (ch + 0.12);
      const accent = p_.status === "shipped" ? SAMPLE.chipEmerald : SAMPLE.chipAmber;
      s.addShape(pres.ShapeType.roundRect, {
        x, y, w: cw, h: ch, rectRadius: 0.08,
        fill: { color: SAMPLE.cardBgLight }, line: { color: SAMPLE.cardBorderLight, width: 0.5 },
      });
      s.addShape(pres.ShapeType.rect, {
        x, y, w: 0.05, h: ch, fill: { color: accent }, line: { color: accent },
      });
      s.addText(p_.phase, {
        x: x + 0.15, y: y + 0.08, w: cw - 0.95, h: 0.35,
        fontSize: 11.5, bold: true, color: SAMPLE.textDark, fontFace: SAMPLE.fontHeading,
      });
      chip(s, x + cw - 0.75, y + 0.1, 0.65, 0.24, p_.status.toUpperCase(), accent);
      const bullets = p_.items.map((it) => ({
        text: it,
        options: { bullet: { code: "25CF" }, fontSize: 9, color: SAMPLE.textMutedDark, fontFace: SAMPLE.fontBody },
      }));
      s.addText(bullets, {
        x: x + 0.2, y: y + 0.5, w: cw - 0.3, h: ch - 0.6,
      });
    });
    pageNum(s);
  }

  // ============================================================
  // Slide 15 — Bottom line / closing
  // ============================================================
  {
    const s = pres.addSlide();
    s.background = { color: SAMPLE.bgBottomCover };
    s.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: W, h: H,
      fill: { color: SAMPLE.bgTopCover }, line: { color: SAMPLE.bgTopCover },
    });
    s.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: 0.15, h: H,
      fill: { color: SAMPLE.accentRed }, line: { color: SAMPLE.accentRed },
    });
    s.addText("BOTTOM LINE", {
      x: 0.7, y: 0.6, w: W - 1.2, h: 0.4,
      fontSize: 12, bold: true, color: SAMPLE.subtitleBlue, charSpacing: 3,
      fontFace: SAMPLE.fontBody,
    });
    s.addText("OATI AutoRFP leads on every dimension.", {
      x: 0.7, y: 1.2, w: W - 1.2, h: 0.8,
      fontSize: 32, bold: true, color: SAMPLE.white, fontFace: SAMPLE.fontHeading,
    });
    s.addText("The biggest moat is production-readiness (+3 vs Reference).\nDecisive on rate-limiting, secrets, audit, observability — all blockers the reference has not solved.", {
      x: 0.7, y: 2.2, w: W - 1.2, h: 1.0,
      fontSize: 14, color: SAMPLE.textMuted, fontFace: SAMPLE.fontBody,
    });

    // Footer row with key tags
    const tags = ["v1.0", "828 tests", "Next.js 15", "Milvus 2.5", "BGE 768", "GPT-OSS 120B"];
    tags.forEach((t, i) => {
      const tw = 1.4, gap = 0.1;
      chip(s, 0.7 + i * (tw + gap), 4.3, tw, 0.32, t, [
        SAMPLE.accentRed, SAMPLE.chipBlue, SAMPLE.chipViolet, SAMPLE.chipAmber, SAMPLE.chipEmerald, SAMPLE.chipPink,
      ][i]);
    });

    s.addText("Questions?  ·  Live demo in the dashboard chat assistant.", {
      x: 0.7, y: H - 0.55, w: W - 1.4, h: 0.3,
      fontSize: 11, color: SAMPLE.subtitleBlue, fontFace: SAMPLE.fontBody, align: "right",
    });
    slideN++;
  }

  await pres.writeFile({ fileName: PPT_PATH });
  console.log(`✓ wrote ${PPT_PATH}`);
}

// ============================================================
// Word doc generator — companion long-form document
// ============================================================

const COLOR_DOC = {
  primary: "1A2B4A",     // matches PPT cover
  primaryLight: "2A3F54",
  text: "1E293B",
  muted: "64748B",
  light: "F8FAFC",
  tableBorder: "CBD5E1",
  zebra: "F1F5F9",
  blue: "2563EB",
};

const T = {
  bodyFont: "Calibri",
  headingFont: "Calibri Light",
  body: 22,
  small: 18,
  cover: 96,
  coverSub: 36,
  coverMeta: 22,
};

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 480, after: 200 },
    keepNext: true,
    border: { bottom: { style: BorderStyle.SINGLE, size: 10, color: COLOR_DOC.primary, space: 4 } },
    children: [new TextRun({ text, bold: true, color: COLOR_DOC.primary, size: 40, font: T.headingFont })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 320, after: 120 },
    keepNext: true,
    children: [new TextRun({ text, bold: true, color: COLOR_DOC.primaryLight, size: 28, font: T.headingFont })],
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 220, after: 80 },
    keepNext: true,
    children: [new TextRun({ text, bold: true, color: COLOR_DOC.text, size: 24, font: T.headingFont })],
  });
}
function p(text, opts = {}) {
  let runs;
  if (typeof text === "string") {
    runs = [new TextRun({ text, size: opts.size ?? T.body, italics: opts.italics, font: T.bodyFont })];
  } else if (Array.isArray(text)) {
    runs = text.map((seg) => new TextRun({
      text: seg.text, bold: seg.bold, italics: seg.italics, size: T.body, font: T.bodyFont,
    }));
  } else {
    runs = [new TextRun({
      text: text.text, bold: text.bold, italics: text.italics,
      size: text.size ?? T.body, color: text.color, font: T.bodyFont,
    })];
  }
  return new Paragraph({
    children: runs,
    spacing: { after: 140, line: 312 },
    alignment: opts.align ?? AlignmentType.JUSTIFIED,
  });
}
function bullet(text, level = 0) {
  return new Paragraph({
    children: [new TextRun({ text, size: T.body, font: T.bodyFont })],
    bullet: { level },
    spacing: { after: 60, line: 288 },
  });
}
function tableOf(headerCells, rows) {
  const border = { style: BorderStyle.SINGLE, size: 4, color: COLOR_DOC.tableBorder };
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: border, bottom: border, left: border, right: border,
      insideHorizontal: border, insideVertical: border,
    },
    rows: [
      new TableRow({
        tableHeader: true,
        children: headerCells.map((h) => new TableCell({
          children: [new Paragraph({
            children: [new TextRun({ text: h, bold: true, color: "FFFFFF", size: T.body, font: T.bodyFont })],
          })],
          shading: { type: ShadingType.CLEAR, fill: COLOR_DOC.primary, color: "auto" },
          margins: { top: 120, bottom: 120, left: 150, right: 150 },
        })),
      }),
      ...rows.map((row, ri) => new TableRow({
        children: row.map((cell) => new TableCell({
          children: [new Paragraph({
            children: [new TextRun({ text: cell, size: T.body, font: T.bodyFont })],
          })],
          shading: { type: ShadingType.CLEAR, fill: ri % 2 === 0 ? "FFFFFF" : COLOR_DOC.zebra, color: "auto" },
          margins: { top: 90, bottom: 90, left: 150, right: 150 },
          borders: { top: border, bottom: border, left: border, right: border },
        })),
      })),
    ],
  });
}

async function buildDoc() {
  const archBuf = readFileSync(ARCH_PNG);
  const logoBuf = readFileSync(LOGO_PNG);
  const today = new Date().toLocaleDateString("en-US", {
    year: "numeric", month: "long", day: "numeric", timeZone: "UTC",
  });

  // ---------------- Cover page ----------------
  const cover = [
    new Paragraph({ children: [new TextRun({ text: "", size: T.body })], spacing: { after: 1200 } }),
    new Paragraph({
      children: [new ImageRun({ data: logoBuf, transformation: { width: 160, height: 160 } })],
      alignment: AlignmentType.CENTER, spacing: { after: 240 },
    }),
    new Paragraph({
      children: [new TextRun({ text: TITLE, bold: true, size: T.cover, color: COLOR_DOC.primary, font: T.headingFont })],
      alignment: AlignmentType.CENTER, spacing: { after: 200 },
    }),
    new Paragraph({
      children: [new TextRun({ text: SUBTITLE, size: T.coverSub, color: COLOR_DOC.muted, font: T.headingFont })],
      alignment: AlignmentType.CENTER, spacing: { after: 100 },
    }),
    new Paragraph({
      children: [new TextRun({ text: "" })],
      alignment: AlignmentType.CENTER,
      border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: COLOR_DOC.primary, space: 4 } },
      spacing: { after: 200 },
    }),
    new Paragraph({
      children: [new TextRun({ text: TAGLINE, size: T.coverMeta, color: COLOR_DOC.muted, italics: true, font: T.bodyFont })],
      alignment: AlignmentType.CENTER, spacing: { after: 4800 },
    }),
    new Paragraph({
      children: [new TextRun({ text: "Prepared by OATI AutoRFP Team", size: T.coverMeta, color: COLOR_DOC.text, font: T.bodyFont })],
      alignment: AlignmentType.CENTER, spacing: { after: 60 },
    }),
    new Paragraph({
      children: [new TextRun({ text: today, size: T.coverMeta, color: COLOR_DOC.muted, font: T.bodyFont })],
      alignment: AlignmentType.CENTER, spacing: { after: 100 },
    }),
    new Paragraph({ children: [new PageBreak()] }),
  ];

  // ---------------- TOC page ----------------
  const toc = [
    new Paragraph({
      children: [new TextRun({ text: "Table of contents", bold: true, color: COLOR_DOC.primary, size: 44, font: T.headingFont })],
      spacing: { before: 200, after: 240 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 10, color: COLOR_DOC.primary, space: 6 } },
    }),
    new TableOfContents("Right-click → Update Field to populate page numbers", {
      hyperlink: true,
      headingStyleRange: "1-3",
      stylesWithLevels: [
        new StyleLevel("Heading1", 1),
        new StyleLevel("Heading2", 2),
        new StyleLevel("Heading3", 3),
      ],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  ];

  // ---------------- Body ----------------
  const body = [
    h1("1. Executive summary"),
    p("OATI AutoRFP is a production-ready, AI-assisted RFP response platform. It turns the traditionally manual workflow — read dozens of formats, extract questions, search the knowledge base, draft answers, route for review, consolidate — into a 9-step automated pipeline with human-in-the-loop checkpoints for SME review and final approval."),
    p("The platform is multi-tenant, multi-modal (text + image), citation-grounded (per-claim verification), and built on best-of-breed open models (GPT-OSS 120B for generation, BAAI/bge-base-en-v1.5 for retrieval, CLIP for images). It ships with comprehensive tests (828 across 87 files) and a 9-step pipeline engine that pauses, resumes, and self-heals."),

    h1("2. Current process — and where it breaks down"),
    h2("2.1 Today's RFP response process"),
    p("The conventional RFP workflow involves six manual steps. Each step is performed by a different team member and surfaces a different category of overhead."),
    ...CURRENT_PROCESS.flatMap(([title, detail], i) => [
      h3(`${i + 1}. ${title}`),
      p(detail),
    ]),
    h2("2.2 Current challenges"),
    ...CURRENT_CHALLENGES.map(([t, d]) => bullet(`${t} — ${d}`)),

    h1("3. What OATI AutoRFP changes"),
    h2("3.1 Value pillars"),
    ...VALUE_PILLARS.flatMap(([label, body_]) => [
      h3(label),
      p(body_),
    ]),
    h2("3.2 The 9-step AI-assisted pipeline"),
    p("Every RFP processed through OATI AutoRFP runs through the same 9-step state machine. AUTO steps drive themselves to completion with bounded retries; MANUAL steps gate on a user action; the engine pauses, resumes, and edits the template in flight."),
    ...AI_PROCESS_STEPS.flatMap((step) => [
      h3(`${step.n}. ${step.label}`),
      p(step.detail),
    ]),

    h1("4. Knowledge base"),
    p("The knowledge base is the foundation of every grounded answer. OATI AutoRFP ships with a normalised Q/A schema and a curated reference dataset of approved historical responses, already structured for AI retrieval."),
    h2("4.1 Schema"),
    tableOf(["Field", "Type", "Notes"], KB_SCHEMA),
    h2("4.2 Reference dataset stats"),
    p("The reference corpus used to validate the platform reflects what a production knowledge base typically looks like — compact, current, and metadata-rich."),
    ...KB_STATS.map(([value, label]) => bullet(`${value} — ${label}`)),

    h1("5. Architecture"),
    p("OATI AutoRFP is a Next.js 15 application with a TypeScript + Prisma core. Vector storage lives in Milvus 2.5 (with a Postgres-backed fallback for tiny installs); relational metadata, audit logs, golden answers, and response history all live in PostgreSQL. The diagram below shows the request flow end-to-end."),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new ImageRun({ data: archBuf, transformation: { width: 600, height: 400 } })],
    }),
    p({ text: "Figure 1. OATI AutoRFP system architecture. Dashed colours encode flow type: green = control, pink = model/embedding, blue = ingest/write, amber = vector search.", italics: true }),

    h2("5.1 Components"),
    bullet("UI tier — Dashboard, Chat UI, KB UI (upload + URL scrape), RFP viewer; all client components over a shared sidebar + theme."),
    bullet("API tier — Next.js route handlers + server actions. SSE streams for bulk-generate, URL crawl, chat."),
    bullet("Ingestion pipeline — format detection → parser dispatch → layout cleanup → image extraction → semantic chunker → embedding writers (text + image) → store(s)."),
    bullet("Retrieval pipeline — BGE query embed → BM25 keyword scan → Milvus dense search → RRF fusion → optional LLM re-rank → top-K chunks."),
    bullet("Generation pipeline — prompt build with retrieved context → LLM with tool access → grounding judge → response persist with citations."),
    bullet("Pipeline engine — 9-step state machine; AUTO (self-healing), MANUAL (gates on user), or DECISION (asks before spending tokens)."),

    h1("6. RAG technology stack"),
    p("The key principle: the LLM answers only from retrieved context — grounded, accurate, no hallucination. The four-stage RAG flow is identical for every question, whether posed via the dashboard chat, an RFP question, or a bulk-generate run."),
    h2("6.1 Stage 1 — Knowledge base"),
    p("Approved Q/A pairs, historical RFP responses, and category/product metadata live in a single normalised store. Every record is chunked at semantic boundaries and embedded once at write time so subsequent reads stay fast."),
    h2("6.2 Stage 2 — Embedding model"),
    p("Text is converted to a 768-dim vector by BAAI/bge-base-en-v1.5, running in-process via @huggingface/transformers (no external service). Images are embedded by CLIP ViT-Base/32 to 512-dim vectors and paired with their parent chunks for multimodal retrieval."),
    h2("6.3 Stage 3 — Vector store"),
    p("Milvus 2.5 indexes the embeddings with HNSW + COSINE distance, per-organisation partitions enforce tenant isolation, and hybrid (dense + sparse) search is wired in for keyword-heavy queries."),
    h2("6.4 Stage 4 — LLM drafter"),
    p("GPT-OSS 120B (via OpenRouter) is the default response generator. It receives ONLY the retrieved context as background, cites every claim by source, and writes in a formal voice tuned for proposal documents. The grounding judge verifies every claim against the cited chunks before approval."),

    h1("7. Models"),
    h2("7.1 LLM comparison"),
    p("Default pick: GPT-OSS 120B (marked ★). Every model role is configurable per-org via Settings — swap in Qwen 2.5 72B, Llama 3.3 70B, GPT-4o, or any OpenAI-compatible endpoint."),
    tableOf(LLM_COMPARISON.header, LLM_COMPARISON.rows),
    h2("7.2 Embedding comparison"),
    p("Default pick: BAAI/bge-base-en-v1.5 (marked ★). 768-dim, ~440 MB, in-process, MIT-licensed — fast to swap, no external service, comparable quality to multi-GB hosted embeddings for RFP-style English content."),
    tableOf(EMBED_COMPARISON.header, EMBED_COMPARISON.rows),

    h1("8. Capability highlights"),
    ...CAPABILITIES.flatMap(([label, body_]) => [
      h3(label),
      p(body_),
    ]),

    h1("9. Tech stack"),
    p("The platform runs on a standard, well-supported web stack. No exotic infrastructure required — a single Postgres instance and (optionally) a single Milvus instance are enough for production deployment."),
    tableOf(["Layer", "Choice"], TECH_STACK),

    h1("10. OATI AutoRFP vs the open-source reference (auto_rfp)"),
    p("The community auto_rfp project is a useful reference architecture but is not production-ready. OATI AutoRFP was built specifically to close those gaps. The head-to-head scorecard below is an independent audit across 5 production-readiness dimensions."),
    h2("10.1 Scorecard"),
    tableOf(
      ["Dimension", "OATI AutoRFP", "Reference"],
      COMPARISON_SCORES.dims.map((r) => [r[0], String(r[1]), String(r[2])]),
    ),
    h2("10.2 Decisive advantages"),
    p("Each row below is a blocker for SOC 2 / GDPR / enterprise deployment that the reference has not solved."),
    tableOf(
      ["Advantage", "OATI AutoRFP", "Reference"],
      DECISIVE.map((r) => [r[0], r[1], r[2]]),
    ),
    p({
      text: "Bottom line: OATI AutoRFP leads on every dimension. The biggest moat is production-readiness (+3 vs Reference). Decisive on rate-limiting, secrets management, audit trail, and observability — all blockers Reference has not solved.",
      italics: true,
    }),

    h1("11. Phased roadmap"),
    ...ROADMAP.flatMap((p_) => [
      h2(`${p_.phase}  ·  ${p_.status.toUpperCase()}`),
      ...p_.items.map((b) => bullet(b)),
    ]),

    h1("12. Operations"),
    h2("12.1 Deployment"),
    bullet("Docker Compose for local + small deployments (Postgres + Mailpit + optional Milvus + optional Prometheus/Grafana)."),
    bullet("Standalone Node build via NEXT_OUTPUT=standalone for slim production images."),
    bullet("Horizontal scale: behind any reverse proxy; set RATE_LIMIT_BACKEND=redis + REDIS_URL for shared rate-limit state."),
    h2("12.2 Observability"),
    bullet("Pino structured logs (one JSON line per request with reqId)."),
    bullet("Prometheus /metrics endpoint scraped by the bundled Prometheus + Grafana profile."),
    bullet("Activity log per RFP — actor, kind, payload — surfaces in the dashboard."),
    h2("12.3 Security"),
    bullet("Auth: NextAuth — magic-link, Google, GitHub, Microsoft, SAML."),
    bullet("Per-org isolation enforced at the API layer (requireOrgAccess) and the Milvus partition key."),
    bullet("API keys for programmatic access, scoped per-org with revoke support."),
    bullet("AES-256-GCM encryption at rest for provider API keys; versioned with zero-downtime rotation."),
    bullet("All destructive UI actions go through React confirmation dialogs (no raw window.confirm)."),

    h1("13. Closing"),
    p("OATI AutoRFP turns a multi-day, multi-person, error-prone process into a guided pipeline that an SME can drive in an afternoon. The platform is open to extension — every step is a registered handler, every model role is configurable, every parser is pluggable. Whether deployed as a single-tenant install or a multi-tenant SaaS, it ships the same code path."),
    p("Questions? Pop into the chat assistant inside the dashboard — it knows the rest of this document."),
  ];

  // ---------------- Page chrome ----------------
  const pageHeader = new Header({
    children: [
      new Paragraph({
        alignment: AlignmentType.LEFT,
        tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
        children: [
          new TextRun({ text: TITLE, bold: true, size: T.small, color: COLOR_DOC.primary, font: T.headingFont }),
          new TextRun({ text: "  ·  " + SUBTITLE, size: T.small, color: COLOR_DOC.muted, font: T.bodyFont }),
          new TextRun({ children: [new Tab()] }),
          new TextRun({ text: "v1.0", size: T.small, color: COLOR_DOC.muted, font: T.bodyFont }),
        ],
        border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: COLOR_DOC.tableBorder, space: 2 } },
      }),
    ],
  });
  const pageFooter = new Footer({
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ text: "Page ", size: T.small, color: COLOR_DOC.muted, font: T.bodyFont }),
          new TextRun({ children: [PageNumber.CURRENT], size: T.small, color: COLOR_DOC.muted, font: T.bodyFont }),
          new TextRun({ text: " of ", size: T.small, color: COLOR_DOC.muted, font: T.bodyFont }),
          new TextRun({ children: [PageNumber.TOTAL_PAGES], size: T.small, color: COLOR_DOC.muted, font: T.bodyFont }),
        ],
      }),
    ],
  });

  const doc = new Document({
    creator: "OATI AutoRFP",
    title: `${TITLE} — ${SUBTITLE}`,
    description: "Full-detail companion document.",
    styles: {
      default: { document: { run: { font: T.bodyFont, size: T.body, color: COLOR_DOC.text } } },
    },
    numbering: {
      config: [
        {
          reference: "default-bullets",
          levels: [
            { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
              style: { paragraph: { indent: { left: convertInchesToTwip(0.4), hanging: convertInchesToTwip(0.25) } } } },
          ],
        },
      ],
    },
    sections: [
      {
        properties: { page: { margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 } } },
        headers: { default: pageHeader },
        footers: { default: pageFooter },
        children: [...cover, ...toc, ...body],
      },
    ],
  });

  const buf = await Packer.toBuffer(doc);
  await writeFile(DOC_PATH, buf);
  console.log(`✓ wrote ${DOC_PATH} (${buf.byteLength} bytes)`);
}

// ============================================================
// Run
// ============================================================

async function main() {
  const args = new Set(process.argv.slice(2));
  const wordOnly = args.has("--word-only");
  const pptOnly = args.has("--ppt-only");
  console.log(`Generating into ${OUT_DIR}${wordOnly ? " (word only)" : pptOnly ? " (ppt only)" : ""}`);
  if (!wordOnly) await buildPpt();
  if (!pptOnly) await buildDoc();
  console.log("Done.");
}

main().catch((e) => {
  console.error("FAILED", e);
  process.exit(1);
});
