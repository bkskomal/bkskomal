// AutoRFP — slide deck generator.
//
// Run: `node scripts/generate-deck.mjs` → produces docs/AutoRFP-deck.pptx
// Edit the SECTIONS array below to change slides. Each helper applies the
// shared theme (background, accent gradient, footer).

import PptxGenJS from "pptxgenjs";
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";

// ---------- Theme ----------
const COLOR = {
  bg: "0B0716", // deep ink
  bgPanel: "13102A",
  fg: "F4F1FA",
  muted: "9C9BB0",
  primary: "8A2BE2", // brand purple
  primary2: "D946EF", // fuchsia
  accent: "38BDF8", // sky for call-outs
  good: "10B981",
  warn: "F59E0B",
  bad: "EF4444",
  card: "1A1530",
  cardLine: "2B2440",
};

const FONT = "Calibri";

// ---------- Setup ----------
const outDir = resolve("./docs");
mkdirSync(outDir, { recursive: true });

const pres = new PptxGenJS();
pres.layout = "LAYOUT_WIDE"; // 13.33 × 7.5 in
pres.title = "AutoRFP — AI-Powered RFP Response Platform";
pres.author = "AutoRFP";
pres.subject = "Architecture, implementation, AI strategy";

const SLIDE_W = 13.33;
const SLIDE_H = 7.5;

// Shared helpers ------------------------------------------------------------

function addSlide() {
  const s = pres.addSlide();
  // Background
  s.background = { color: COLOR.bg };
  // Gradient bar across the top
  s.addShape(pres.ShapeType.rect, {
    x: 0, y: 0, w: SLIDE_W, h: 0.08,
    fill: { color: COLOR.primary },
    line: { type: "none" },
  });
  s.addShape(pres.ShapeType.rect, {
    x: SLIDE_W * 0.4, y: 0, w: SLIDE_W * 0.6, h: 0.08,
    fill: { color: COLOR.primary2 },
    line: { type: "none" },
  });
  // Faint glow blobs in the bg (purely decorative)
  s.addShape(pres.ShapeType.ellipse, {
    x: -2, y: -1.5, w: 5, h: 5,
    fill: { color: COLOR.primary, transparency: 90 },
    line: { type: "none" },
  });
  s.addShape(pres.ShapeType.ellipse, {
    x: SLIDE_W - 3, y: SLIDE_H - 3, w: 5, h: 5,
    fill: { color: COLOR.primary2, transparency: 92 },
    line: { type: "none" },
  });
  return s;
}

function addFooter(s, page, total) {
  s.addText("AutoRFP · AI-Powered RFP Response Platform", {
    x: 0.4, y: SLIDE_H - 0.45, w: 8, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.muted,
  });
  s.addText(`${page} / ${total}`, {
    x: SLIDE_W - 1.2, y: SLIDE_H - 0.45, w: 0.8, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.muted, align: "right",
  });
}

function addTitle(s, eyebrow, title) {
  s.addText(eyebrow.toUpperCase(), {
    x: 0.5, y: 0.45, w: 12, h: 0.35,
    fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 6,
  });
  s.addText(title, {
    x: 0.5, y: 0.85, w: 12, h: 0.9,
    fontFace: FONT, fontSize: 32, color: COLOR.fg, bold: true,
  });
}

function addCard(s, x, y, w, h, title, body, opts = {}) {
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h,
    fill: { color: opts.bg ?? COLOR.card },
    line: { color: opts.line ?? COLOR.cardLine, width: 0.5 },
    rectRadius: 0.12,
  });
  if (opts.tag) {
    s.addText(opts.tag, {
      x: x + 0.2, y: y + 0.15, w: w - 0.4, h: 0.3,
      fontFace: FONT, fontSize: 9, color: opts.tagColor ?? COLOR.primary2,
      bold: true, charSpacing: 4,
    });
  }
  s.addText(title, {
    x: x + 0.25, y: y + (opts.tag ? 0.45 : 0.18), w: w - 0.5, h: 0.4,
    fontFace: FONT, fontSize: opts.titleSize ?? 14, color: COLOR.fg, bold: true,
  });
  if (body) {
    const textBody = Array.isArray(body)
      ? body.map((b) => ({ text: b, options: { bullet: { code: "25CF" } } }))
      : body;
    s.addText(textBody, {
      x: x + 0.25, y: y + (opts.tag ? 0.85 : 0.65), w: w - 0.5, h: h - 1,
      fontFace: FONT, fontSize: opts.bodySize ?? 11, color: COLOR.muted,
      paraSpaceAfter: 4,
      valign: "top",
    });
  }
}

function addBullets(s, x, y, w, h, items, opts = {}) {
  const body = items.map((t) => ({
    text: typeof t === "string" ? t : t.text,
    options: {
      bullet: { code: "25B8" },
      color: COLOR.fg,
      bold: typeof t === "string" ? false : !!t.bold,
      paraSpaceAfter: 6,
    },
  }));
  s.addText(body, {
    x, y, w, h,
    fontFace: FONT, fontSize: opts.size ?? 14, color: COLOR.fg, valign: "top",
  });
}

// ---------- Slides ----------

const slides = [];

// 01 — Cover
slides.push((page, total) => {
  const s = addSlide();
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 0.5, w: 1.4, h: 1.4, rectRadius: 0.25,
    fill: { color: COLOR.primary },
    line: { type: "none" },
  });
  s.addText("✨", {
    x: 0.5, y: 0.5, w: 1.4, h: 1.4,
    fontFace: FONT, fontSize: 64, color: COLOR.fg, align: "center", valign: "middle",
  });

  s.addText("AutoRFP", {
    x: 0.5, y: 2.2, w: 10, h: 1.4,
    fontFace: FONT, fontSize: 64, color: COLOR.fg, bold: true,
  });
  s.addText("AI-Powered RFP Response Platform", {
    x: 0.5, y: 3.4, w: 12, h: 0.8,
    fontFace: FONT, fontSize: 24, color: COLOR.primary2,
  });
  s.addText(
    "Architecture · Implementation · Open-source AI strategy",
    {
      x: 0.5, y: 4.3, w: 12, h: 0.5,
      fontFace: FONT, fontSize: 16, color: COLOR.muted,
    },
  );
  s.addText(`Generated ${new Date().toISOString().slice(0, 10)}`, {
    x: 0.5, y: SLIDE_H - 0.9, w: 6, h: 0.3,
    fontFace: FONT, fontSize: 10, color: COLOR.muted,
  });
});

// 02 — What is an RFP system?
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Context", "What is an RFP response system?");
  s.addText(
    [
      { text: "Request for Proposal (RFP)", options: { bold: true, color: COLOR.fg } },
      { text: " platforms centralize how teams ", options: { color: COLOR.muted } },
      { text: "create, manage, and respond", options: { bold: true, color: COLOR.fg } },
      { text: " to vendor proposals — replacing email chains, shared drives, and re-typed answers.", options: { color: COLOR.muted } },
    ],
    { x: 0.5, y: 1.95, w: 12.3, h: 0.8, fontFace: FONT, fontSize: 16 },
  );

  const cards = [
    { tag: "01 · CENTRALIZED", title: "Single workspace", body: "Teams manage the full lifecycle — upload, extract, draft, review, approve, export — without leaving the platform." },
    { tag: "02 · CONTENT LIBRARY", title: "Reusable knowledge", body: "Past answers, product docs, security policies, references — all searchable, all reusable, all kept in sync." },
    { tag: "03 · COLLABORATION", title: "Workflow + SMEs", body: "Assign questions to subject-matter experts, track status, comment, mention, set deadlines." },
    { tag: "04 · AUTOMATION", title: "AI-first response", body: "Parse incoming RFPs, generate cited draft answers, score confidence, surface what needs human review." },
  ];
  cards.forEach((c, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    addCard(s, 0.5 + col * 6.4, 3 + row * 2.05, 6.1, 1.85, c.title, c.body, { tag: c.tag });
  });

  addFooter(s, page, total);
});

// 03 — The pain
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "The problem", "Why teams hate responding to RFPs today");
  const rows = [
    { metric: "50–300", label: "questions per RFP", color: COLOR.warn },
    { metric: "70%", label: "of answers already exist somewhere", color: COLOR.primary2 },
    { metric: "5 days", label: "average response time for a 100-question RFP", color: COLOR.warn },
    { metric: "$50K+", label: "average opportunity cost per missed bid", color: COLOR.bad },
  ];
  rows.forEach((r, i) => {
    const x = 0.5 + (i % 2) * 6.4;
    const y = 2 + Math.floor(i / 2) * 2.2;
    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: 6.1, h: 2,
      fill: { color: COLOR.card },
      line: { color: COLOR.cardLine, width: 0.5 },
      rectRadius: 0.12,
    });
    s.addText(r.metric, {
      x: x + 0.3, y: y + 0.25, w: 5.5, h: 1.1,
      fontFace: FONT, fontSize: 54, color: r.color, bold: true,
    });
    s.addText(r.label, {
      x: x + 0.3, y: y + 1.3, w: 5.5, h: 0.55,
      fontFace: FONT, fontSize: 14, color: COLOR.muted,
    });
  });
  s.addText("AI doesn't just speed this up — it changes the workflow.", {
    x: 0.5, y: 6.5, w: 12.3, h: 0.5,
    fontFace: FONT, fontSize: 14, color: COLOR.fg, italic: true, align: "center",
  });
  addFooter(s, page, total);
});

// 04 — How AI enhances RFP systems
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "AI in the loop", "Five ways AI changes the RFP workflow");
  const items = [
    { n: "01", t: "Question extraction", d: "Parse incoming RFPs (PDF, Word, Excel, PPT) → structured list of every question with section, number, requirement." },
    { n: "02", t: "Knowledge retrieval", d: "Hybrid BM25 + dense vector + RRF fusion + LLM reranker. Surfaces the best supporting evidence for each question." },
    { n: "03", t: "Draft generation", d: "Multi-step pipeline: analyze → search → call tools → draft. Streamed with inline source citations." },
    { n: "04", t: "Confidence scoring", d: "Heuristic 0–1 score on every response. Auto-flags answers that need human review." },
    { n: "05", t: "Tool calling", d: "Pluggable tools the model can call mid-answer: knowledge search, calculator, custom org tools." },
  ];
  items.forEach((it, i) => {
    const y = 2 + i * 1.0;
    s.addShape(pres.ShapeType.roundRect, {
      x: 0.5, y, w: 1.0, h: 0.85,
      fill: { color: COLOR.primary },
      line: { type: "none" },
      rectRadius: 0.1,
    });
    s.addText(it.n, {
      x: 0.5, y, w: 1.0, h: 0.85,
      fontFace: FONT, fontSize: 22, color: COLOR.fg, bold: true,
      align: "center", valign: "middle",
    });
    s.addText(it.t, {
      x: 1.8, y, w: 4.2, h: 0.4,
      fontFace: FONT, fontSize: 16, color: COLOR.fg, bold: true,
    });
    s.addText(it.d, {
      x: 1.8, y: y + 0.35, w: 11, h: 0.6,
      fontFace: FONT, fontSize: 11, color: COLOR.muted,
    });
  });
  addFooter(s, page, total);
});

// 05 — Architecture
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Architecture", "Three-tier, self-hostable, fully open");

  // Top tier — Next.js App
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 2, w: 12.3, h: 1.2, rectRadius: 0.12,
    fill: { color: COLOR.card },
    line: { color: COLOR.primary2, width: 1.5 },
  });
  s.addText("Next.js 15 · App Router · React 19 · Tailwind · Radix", {
    x: 0.5, y: 2.1, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 11, color: COLOR.primary2, bold: true, align: "center", charSpacing: 4,
  });
  const uiBlocks = [
    "Dashboard\n(server components)",
    "RFP viewer\n(streaming SSE)",
    "Chat\n(scoped to RFP/index/project)",
    "Settings\n(per-org AI config UI)",
  ];
  uiBlocks.forEach((b, i) => {
    s.addText(b, {
      x: 0.6 + i * 3.05, y: 2.55, w: 2.95, h: 0.6,
      fontFace: FONT, fontSize: 11, color: COLOR.fg, align: "center",
    });
  });

  // Middle tier — Server logic
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 3.4, w: 12.3, h: 1.8, rectRadius: 0.12,
    fill: { color: COLOR.card },
    line: { color: COLOR.primary, width: 1.5 },
  });
  s.addText("Application layer · TypeScript · Prisma · Zod", {
    x: 0.5, y: 3.5, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 11, color: COLOR.primary, bold: true, align: "center", charSpacing: 4,
  });
  const apps = [
    "RFP pipeline",
    "Bulk generation",
    "Notifications\n(pluggable channels)",
    "Tool registry",
    "Hybrid retrieval",
    "Word export",
    "AI config\n(per-org, encrypted)",
    "Workflow\n(status / assign / comments)",
  ];
  apps.forEach((b, i) => {
    const col = i % 4;
    const row = Math.floor(i / 4);
    s.addText(b, {
      x: 0.6 + col * 3.05, y: 3.95 + row * 0.55, w: 2.95, h: 0.5,
      fontFace: FONT, fontSize: 10, color: COLOR.fg, align: "center",
    });
  });

  // Bottom tier — External
  const externals = [
    { x: 0.5, label: "PostgreSQL", sub: "data + Float[] embeddings", color: COLOR.accent },
    { x: 4.6, label: "Self-hosted LLM", sub: "OpenAI-compatible API\n(Ollama / vLLM / OpenRouter)", color: COLOR.primary2 },
    { x: 8.7, label: "Embedding server", sub: "Ollama / OpenAI / LM Studio", color: COLOR.good },
  ];
  externals.forEach((e) => {
    s.addShape(pres.ShapeType.roundRect, {
      x: e.x, y: 5.4, w: 4.0, h: 1.4, rectRadius: 0.12,
      fill: { color: COLOR.card },
      line: { color: e.color, width: 1.5 },
    });
    s.addText(e.label, {
      x: e.x, y: 5.5, w: 4.0, h: 0.4,
      fontFace: FONT, fontSize: 12, color: e.color, bold: true, align: "center",
    });
    s.addText(e.sub, {
      x: e.x, y: 5.95, w: 4.0, h: 0.8,
      fontFace: FONT, fontSize: 10, color: COLOR.muted, align: "center",
    });
  });

  addFooter(s, page, total);
});

// 06 — Tech stack
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Implementation", "Tech stack");

  const groups = [
    {
      heading: "Frontend",
      color: COLOR.primary2,
      items: ["Next.js 15 (App Router)", "React 19 · TypeScript", "Tailwind · shadcn-style Radix UI", "react-markdown · lucide icons", "Streaming SSE for live AI"],
    },
    {
      heading: "Backend",
      color: COLOR.primary,
      items: ["Next API routes (withApiHandler wrapper)", "Prisma 6 · PostgreSQL", "Zod validation · typed error classes", "AES-256-GCM key encryption", "Activity log + audit trail"],
    },
    {
      heading: "AI layer",
      color: COLOR.accent,
      items: ["OpenAI-compatible client (provider-agnostic)", "Hybrid retrieval (BM25 + dense + RRF)", "Optional LLM reranker", "Tool-calling registry", "Multi-step streaming pipeline"],
    },
    {
      heading: "Ops",
      color: COLOR.good,
      items: ["NextAuth v5 (magic link)", "Nodemailer for notifications", "Vitest (45 tests)", "Optional LlamaParse for tables/charts", "instrumentation.ts env validation"],
    },
  ];

  groups.forEach((g, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.5 + col * 6.4;
    const y = 2 + row * 2.4;
    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: 6.1, h: 2.2, rectRadius: 0.12,
      fill: { color: COLOR.card },
      line: { color: g.color, width: 1 },
    });
    s.addText(g.heading.toUpperCase(), {
      x: x + 0.25, y: y + 0.15, w: 5.5, h: 0.35,
      fontFace: FONT, fontSize: 10, color: g.color, bold: true, charSpacing: 4,
    });
    s.addText(
      g.items.map((it) => ({
        text: it,
        options: { bullet: { code: "25B8" }, color: COLOR.fg, paraSpaceAfter: 2 },
      })),
      {
        x: x + 0.25, y: y + 0.55, w: 5.5, h: 1.6,
        fontFace: FONT, fontSize: 11,
      },
    );
  });

  addFooter(s, page, total);
});

// 07 — Multi-tenant data model
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Data model", "Multi-tenant by design");

  const tree = [
    { x: 0.5, y: 2.1, w: 2.3, h: 0.7, label: "Organization", color: COLOR.primary2 },
    { x: 3.3, y: 1.45, w: 2.3, h: 0.7, label: "Membership", color: COLOR.fg },
    { x: 3.3, y: 2.1, w: 2.3, h: 0.7, label: "Project", color: COLOR.primary2 },
    { x: 3.3, y: 2.75, w: 2.3, h: 0.7, label: "KnowledgeIndex", color: COLOR.accent },
    { x: 6.1, y: 1.6, w: 2.3, h: 0.7, label: "RFP", color: COLOR.primary2 },
    { x: 6.1, y: 2.4, w: 2.3, h: 0.7, label: "Document", color: COLOR.accent },
    { x: 8.9, y: 1.0, w: 2.3, h: 0.7, label: "Question", color: COLOR.primary2 },
    { x: 8.9, y: 1.75, w: 2.3, h: 0.7, label: "Comment", color: COLOR.fg },
    { x: 8.9, y: 2.5, w: 2.3, h: 0.7, label: "ActivityEvent", color: COLOR.fg },
    { x: 8.9, y: 3.25, w: 2.3, h: 0.7, label: "BulkGeneration", color: COLOR.fg },
    { x: 6.1, y: 3.2, w: 2.3, h: 0.7, label: "DocumentChunk", color: COLOR.accent },
    { x: 11.5, y: 1.5, w: 1.6, h: 0.7, label: "Response", color: COLOR.good },
    { x: 11.5, y: 2.25, w: 1.6, h: 0.7, label: "Source", color: COLOR.good },
    { x: 0.5, y: 3.4, w: 2.3, h: 0.7, label: "OrgAiConfig", color: COLOR.accent },
    { x: 0.5, y: 4.1, w: 2.3, h: 0.7, label: "ToolConfig", color: COLOR.accent },
    { x: 0.5, y: 4.8, w: 2.3, h: 0.7, label: "GoldenAnswer", color: COLOR.warn },
    { x: 3.3, y: 4.1, w: 2.3, h: 0.7, label: "Notification", color: COLOR.primary2 },
    { x: 3.3, y: 4.8, w: 2.3, h: 0.7, label: "NotificationPreference", color: COLOR.primary2 },
    { x: 6.1, y: 4.1, w: 2.3, h: 0.7, label: "ChatThread", color: COLOR.fg },
    { x: 6.1, y: 4.8, w: 2.3, h: 0.7, label: "ChatMessage", color: COLOR.fg },
    { x: 8.9, y: 4.1, w: 2.3, h: 0.7, label: "Mention", color: COLOR.fg },
    { x: 8.9, y: 4.8, w: 2.3, h: 0.7, label: "Feedback", color: COLOR.warn },
  ];
  tree.forEach((n) => {
    s.addShape(pres.ShapeType.roundRect, {
      x: n.x, y: n.y, w: n.w, h: n.h, rectRadius: 0.08,
      fill: { color: COLOR.card },
      line: { color: n.color, width: 0.8 },
    });
    s.addText(n.label, {
      x: n.x, y: n.y, w: n.w, h: n.h,
      fontFace: FONT, fontSize: 11, color: COLOR.fg, align: "center", valign: "middle",
    });
  });

  s.addText("23 Prisma models · per-org isolation enforced in every API route", {
    x: 0.5, y: 5.9, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 13, color: COLOR.muted, italic: true, align: "center",
  });
  s.addText("All AI calls + storage are scoped by organizationId — no cross-tenant leak path.", {
    x: 0.5, y: 6.3, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.muted, align: "center",
  });

  addFooter(s, page, total);
});

// 08 — AI pipeline detail
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "AI pipeline", "How a question becomes a cited answer");

  const stages = [
    { label: "Analyze", sub: "LLM decomposes the\nquestion into queries", color: COLOR.primary2 },
    { label: "Retrieve", sub: "Hybrid: BM25 + dense\n+ RRF fusion", color: COLOR.accent },
    { label: "Rerank", sub: "LLM-as-judge orders\ntop-k by relevance", color: COLOR.accent },
    { label: "Tool calls", sub: "Model can invoke\ncustom org tools", color: COLOR.primary },
    { label: "Draft", sub: "Streaming generation\nwith [Source N] citations", color: COLOR.primary2 },
    { label: "Score", sub: "Heuristic confidence\n+ needs-review flag", color: COLOR.good },
  ];

  const cellW = 1.95;
  const startX = 0.5;
  const y = 2.5;
  stages.forEach((st, i) => {
    const x = startX + i * (cellW + 0.1);
    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: cellW, h: 2, rectRadius: 0.12,
      fill: { color: COLOR.card },
      line: { color: st.color, width: 1 },
    });
    s.addText(`STAGE ${i + 1}`, {
      x, y: y + 0.15, w: cellW, h: 0.3,
      fontFace: FONT, fontSize: 8, color: st.color, bold: true, align: "center", charSpacing: 4,
    });
    s.addText(st.label, {
      x, y: y + 0.5, w: cellW, h: 0.5,
      fontFace: FONT, fontSize: 16, color: COLOR.fg, bold: true, align: "center",
    });
    s.addText(st.sub, {
      x, y: y + 1.05, w: cellW, h: 0.85,
      fontFace: FONT, fontSize: 10, color: COLOR.muted, align: "center",
    });
    if (i < stages.length - 1) {
      s.addText("▸", {
        x: x + cellW - 0.05, y: y + 0.85, w: 0.2, h: 0.3,
        fontFace: FONT, fontSize: 16, color: COLOR.primary2,
      });
    }
  });

  // Bottom: streaming visualization
  s.addText("All six stages stream to the UI as Server-Sent Events. The user sees the model thinking.", {
    x: 0.5, y: 4.9, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 13, color: COLOR.fg, italic: true, align: "center",
  });

  // Code snippet
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 5.5, w: 12.3, h: 1.4, rectRadius: 0.1,
    fill: { color: COLOR.bgPanel },
    line: { color: COLOR.cardLine, width: 0.5 },
  });
  s.addText(
    [
      { text: "event: step  data: ", options: { color: COLOR.muted } },
      { text: `{"step":"analyzing","detail":"Breaking question into search queries…"}`, options: { color: COLOR.fg } },
      { text: "\nevent: step  data: ", options: { color: COLOR.muted } },
      { text: `{"step":"searching","detail":"Searching: \\"data residency\\""}`, options: { color: COLOR.fg } },
      { text: "\nevent: step  data: ", options: { color: COLOR.muted } },
      { text: `{"step":"tool_call","data":{"name":"search_knowledge_base"}}`, options: { color: COLOR.primary2 } },
      { text: "\nevent: done  data: ", options: { color: COLOR.muted } },
      { text: `{"content":"...","confidence":0.82,"sources":[...]}`, options: { color: COLOR.good } },
    ],
    {
      x: 0.7, y: 5.55, w: 11.9, h: 1.3,
      fontFace: "Consolas", fontSize: 10,
    },
  );

  addFooter(s, page, total);
});

// 09 — Hybrid retrieval
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Retrieval", "Why hybrid retrieval beats vanilla RAG");

  // Left: comparison
  const rows = [
    { method: "Dense only (cosine over embeddings)", strength: "Semantic match", weakness: "Misses exact terms (IDs, acronyms, codes)" },
    { method: "BM25 only (keyword)", strength: "Exact match · fast", weakness: "Misses paraphrases" },
    { method: "Dense + BM25 + RRF (ours)", strength: "Best of both worlds", weakness: "Slightly heavier compute", highlight: true },
    { method: "+ LLM reranker on top-k", strength: "+10–15% precision typical", weakness: "Adds one LLM call", highlight: true },
  ];

  rows.forEach((r, i) => {
    const y = 2.1 + i * 1.05;
    s.addShape(pres.ShapeType.roundRect, {
      x: 0.5, y, w: 12.3, h: 0.9, rectRadius: 0.1,
      fill: { color: r.highlight ? COLOR.primary : COLOR.card, transparency: r.highlight ? 70 : 0 },
      line: { color: r.highlight ? COLOR.primary2 : COLOR.cardLine, width: r.highlight ? 1.2 : 0.5 },
    });
    s.addText(r.method, {
      x: 0.7, y: y + 0.15, w: 5.0, h: 0.6,
      fontFace: FONT, fontSize: 12, color: COLOR.fg, bold: !!r.highlight, valign: "middle",
    });
    s.addText("+ " + r.strength, {
      x: 5.8, y: y + 0.15, w: 3.5, h: 0.6,
      fontFace: FONT, fontSize: 11, color: COLOR.good, valign: "middle",
    });
    s.addText("− " + r.weakness, {
      x: 9.3, y: y + 0.15, w: 3.5, h: 0.6,
      fontFace: FONT, fontSize: 11, color: COLOR.warn, valign: "middle",
    });
  });

  s.addText("Pure JavaScript — runs on plain Postgres, no pgvector required. Swap to pgvector for scale-out later.", {
    x: 0.5, y: 6.6, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.muted, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 10 — Modular AI config
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Configuration", "Provider-agnostic AI, per-org, from the UI");

  addCard(s, 0.5, 2, 6.1, 4.4,
    "Built-in provider catalog",
    [
      "OpenRouter — frontier models, one key",
      "OpenAI — direct (GPT-5, o-series)",
      "Ollama — fully self-hosted, free",
      "vLLM — high-throughput on your GPU",
      "LM Studio · LocalAI — desktop",
      "Custom — any OpenAI-compatible URL",
    ],
    { tag: "ANY OPENAI-COMPATIBLE API" },
  );
  addCard(s, 6.7, 2, 6.1, 4.4,
    "All editable from the Settings page",
    [
      "Provider preset auto-fills URL + models",
      "API keys encrypted at rest (AES-256-GCM)",
      "“Test connection” surfaces real errors",
      "“List models” pulls live /v1/models",
      "Per-field provenance (org vs env fallback)",
      "Role-gated to OWNER / ADMIN",
    ],
    { tag: "BUILT-IN UI" },
  );

  s.addText("Switch providers per-organization in 10 seconds. No code changes. No restart.", {
    x: 0.5, y: 6.55, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 13, color: COLOR.fg, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 11 — Best open-source models for RFP
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Open-source AI", "Best models for RFP work");

  // Headers
  const headers = ["Model", "Size (4-bit VRAM)", "Best for", "Verdict"];
  const widths = [3.5, 2.2, 4.3, 2.0];
  let xPos = 0.5;
  headers.forEach((h, i) => {
    s.addText(h.toUpperCase(), {
      x: xPos, y: 2.0, w: widths[i], h: 0.4,
      fontFace: FONT, fontSize: 9, color: COLOR.primary2, bold: true, charSpacing: 3,
    });
    xPos += widths[i];
  });

  const rows = [
    { m: "Llama 3.3 70B Instruct", v: "~40 GB", b: "Top instruction following, polished writing, tool calling", verdict: "BEST OVERALL", color: COLOR.good, bold: true },
    { m: "Qwen 2.5 72B Instruct", v: "~40 GB", b: "Better on benchmarks, strong multilingual", verdict: "STRONG ALT", color: COLOR.good },
    { m: "Qwen 2.5 32B Instruct", v: "~20 GB", b: "Single-GPU sweet spot · price/performance king", verdict: "BUDGET PICK", color: COLOR.accent, bold: true },
    { m: "DeepSeek-R1 32B", v: "~20 GB", b: "Reasoning model · great for the analyze stage", verdict: "SPECIALIST", color: COLOR.primary2 },
    { m: "Mistral Small 3 (24B)", v: "~14 GB", b: "Fast inference + strong tool use", verdict: "LOW LATENCY", color: COLOR.primary2 },
    { m: "Llama 3.1 8B Instruct", v: "~6 GB", b: "Cheap path: extraction, reranking, titles", verdict: "PAIR WITH 70B", color: COLOR.warn },
  ];

  rows.forEach((r, i) => {
    const y = 2.45 + i * 0.7;
    if (i % 2 === 0) {
      s.addShape(pres.ShapeType.rect, {
        x: 0.4, y: y - 0.05, w: 12.5, h: 0.65,
        fill: { color: COLOR.card, transparency: 50 },
        line: { type: "none" },
      });
    }
    let x = 0.5;
    [r.m, r.v, r.b, r.verdict].forEach((cell, idx) => {
      s.addText(cell, {
        x, y, w: widths[idx], h: 0.55,
        fontFace: FONT, fontSize: 11,
        color: idx === 3 ? r.color : (idx === 0 && r.bold) ? COLOR.fg : (idx === 0) ? COLOR.fg : COLOR.muted,
        bold: idx === 3 || (idx === 0 && r.bold),
        valign: "middle",
      });
      x += widths[idx];
    });
  });

  s.addText("Two-tier deployment pattern: small model for extraction/reranking (8B), large model for response drafting (70B).", {
    x: 0.5, y: 6.7, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.fg, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 12 — Embedding models
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Embeddings", "What to use for the knowledge base");

  const items = [
    { name: "nomic-embed-text", dim: "768-dim", note: "Current default. Lightweight, fast. Multilingual.", color: COLOR.fg, status: "DEFAULT" },
    { name: "bge-m3", dim: "1024-dim", note: "Strongest open embedder. Multi-functional (dense + sparse + multi-vector). Best for long-form passages.", color: COLOR.good, status: "RECOMMENDED" },
    { name: "mxbai-embed-large", dim: "1024-dim", note: "Strong on retrieval benchmarks. Drop-in upgrade from nomic.", color: COLOR.primary2, status: "UPGRADE" },
    { name: "jina-embeddings-v3", dim: "1024-dim", note: "Long context (8192 tokens). Useful for whole-section indexing.", color: COLOR.accent, status: "LONG CTX" },
    { name: "OpenAI text-embedding-3-small", dim: "1536-dim", note: "If you must use a hosted API. Higher dim = bigger storage but better recall.", color: COLOR.muted, status: "HOSTED" },
  ];

  items.forEach((it, i) => {
    const y = 2.15 + i * 0.92;
    s.addShape(pres.ShapeType.roundRect, {
      x: 0.5, y, w: 12.3, h: 0.8, rectRadius: 0.1,
      fill: { color: COLOR.card },
      line: { color: COLOR.cardLine, width: 0.5 },
    });
    s.addText(it.name, {
      x: 0.7, y: y + 0.1, w: 3.7, h: 0.6,
      fontFace: "Consolas", fontSize: 12, color: COLOR.fg, bold: true, valign: "middle",
    });
    s.addText(it.dim, {
      x: 4.4, y: y + 0.1, w: 1.4, h: 0.6,
      fontFace: FONT, fontSize: 11, color: COLOR.muted, valign: "middle",
    });
    s.addText(it.note, {
      x: 5.8, y: y + 0.1, w: 5.4, h: 0.6,
      fontFace: FONT, fontSize: 10, color: COLOR.muted, valign: "middle",
    });
    s.addText(it.status, {
      x: 11.2, y: y + 0.1, w: 1.6, h: 0.6,
      fontFace: FONT, fontSize: 9, color: it.color, bold: true, align: "right", valign: "middle", charSpacing: 3,
    });
  });

  s.addText("Embedding dimensions matter — pick a model and stick with it per index. Mixed dims = empty results.", {
    x: 0.5, y: 7.0, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 11, color: COLOR.warn, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 13 — Self-hosted vs hosted
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Decision matrix", "Self-hosted vs hosted: how to choose");

  const cards = [
    {
      tag: "SELF-HOST (Ollama / vLLM)",
      color: COLOR.good,
      title: "When data never leaves your network",
      body: [
        "Healthcare / financial services / gov",
        "Want predictable cost at scale",
        "Have GPUs already (or rent on-prem)",
        "Need air-gapped deployment",
      ],
    },
    {
      tag: "HOSTED (OpenRouter / OpenAI)",
      color: COLOR.primary2,
      title: "When time-to-market trumps control",
      body: [
        "No GPUs, no devops team",
        "Pay per token, scale to zero",
        "Want access to frontier models",
        "Acceptable to send RFP content to API",
      ],
    },
    {
      tag: "HYBRID (most teams)",
      color: COLOR.accent,
      title: "Self-host embeddings + hosted chat",
      body: [
        "Embeddings: Ollama bge-m3 (free, fast)",
        "Chat: OpenRouter for variety",
        "Keep RAG context out of your provider",
        "Most cost-effective in practice",
      ],
    },
  ];

  cards.forEach((c, i) => {
    addCard(s, 0.5 + i * 4.25, 2.05, 4.0, 4.5, c.title, c.body, {
      tag: c.tag,
      tagColor: c.color,
      bodySize: 11,
      titleSize: 13,
    });
  });

  s.addText("AutoRFP supports all three patterns. Switch in Settings, no code change.", {
    x: 0.5, y: 6.7, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.fg, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 14 — Security
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Security", "Defense in depth");

  const items = [
    { t: "Encryption at rest", d: "API keys (LLM, LlamaParse) encrypted with AES-256-GCM. Key derived from AUTH_SECRET; one-line swap to KMS for production." },
    { t: "Authentication", d: "NextAuth v5 magic link · database sessions · CSRF tokens · HttpOnly cookies. Dev-only bypass route gated on NODE_ENV." },
    { t: "Authorization", d: "Role-based (OWNER/ADMIN/MEMBER). Every API route checks org membership before touching data. Cross-tenant access path: none." },
    { t: "Input validation", d: "Zod schemas at every API boundary. Typed error classes map to consistent JSON responses (no stack traces in prod)." },
    { t: "Audit trail", d: "ActivityEvent log captures every state-changing action (uploads, generation, status changes, exports, mining)." },
    { t: "Secret handling in UI", d: "Keys never sent plaintext to the client; masked as `sk-o••••5678`. Sentinel value preserves saved secrets across edits." },
  ];

  items.forEach((it, i) => {
    const x = 0.5 + (i % 2) * 6.4;
    const y = 2.0 + Math.floor(i / 2) * 1.65;
    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: 6.1, h: 1.45, rectRadius: 0.1,
      fill: { color: COLOR.card },
      line: { color: COLOR.cardLine, width: 0.5 },
    });
    s.addText(it.t, {
      x: x + 0.25, y: y + 0.15, w: 5.6, h: 0.4,
      fontFace: FONT, fontSize: 13, color: COLOR.fg, bold: true,
    });
    s.addText(it.d, {
      x: x + 0.25, y: y + 0.55, w: 5.6, h: 0.85,
      fontFace: FONT, fontSize: 10, color: COLOR.muted,
    });
  });

  addFooter(s, page, total);
});

// 15 — Implementation status
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Status", "What's implemented vs roadmap");

  // Done
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 2.0, w: 6.1, h: 5.0, rectRadius: 0.12,
    fill: { color: COLOR.card },
    line: { color: COLOR.good, width: 1 },
  });
  s.addText("✓ SHIPPED", {
    x: 0.7, y: 2.15, w: 5.5, h: 0.4,
    fontFace: FONT, fontSize: 11, color: COLOR.good, bold: true, charSpacing: 4,
  });
  const shipped = [
    "Multi-tenant orgs · projects · members",
    "Document parsing (PDF/Word/Excel/PPT)",
    "Auto question extraction",
    "Hybrid retrieval + LLM reranker",
    "Multi-step streaming response generation",
    "Tool-calling registry",
    "Bulk generation (3 modes, parallel)",
    "Confidence scoring + needs-review flag",
    "Workflow (4-state · assign · comments)",
    "Activity log · audit trail",
    "Word (.docx) export",
    "Chat (scoped to RFP / index / project / org)",
    "Per-org AI config from UI, encrypted",
    "Notifications (in-app + email, pluggable)",
    "@mentions · due dates · onboarding sample",
    "45 tests passing",
  ];
  s.addText(
    shipped.map((t) => ({
      text: t,
      options: { bullet: { code: "2713" }, color: COLOR.fg, paraSpaceAfter: 4 },
    })),
    {
      x: 0.85, y: 2.6, w: 5.5, h: 4.3,
      fontFace: FONT, fontSize: 10.5,
    },
  );

  // Roadmap
  s.addShape(pres.ShapeType.roundRect, {
    x: 6.7, y: 2.0, w: 6.1, h: 5.0, rectRadius: 0.12,
    fill: { color: COLOR.card },
    line: { color: COLOR.warn, width: 1 },
  });
  s.addText("◷ ROADMAP", {
    x: 6.9, y: 2.15, w: 5.5, h: 0.4,
    fontFace: FONT, fontSize: 11, color: COLOR.warn, bold: true, charSpacing: 4,
  });
  const roadmap = [
    "Buyer-side: vendor submission scoring",
    "Excel matrix import → export (preserves template)",
    "Real-time presence + collaborative editing",
    "Rich-text editor for responses (Tiptap)",
    "Slack / Teams / webhook channels",
    "API tokens + per-token scoping",
    "SSO (SAML/OIDC)",
    "Win/loss analytics + KB freshness metrics",
    "Templates / response snippets library",
    "PDF export (Word→PDF good enough?)",
    "Background queue for long jobs (BullMQ)",
  ];
  s.addText(
    roadmap.map((t) => ({
      text: t,
      options: { bullet: { code: "25B8" }, color: COLOR.muted, paraSpaceAfter: 4 },
    })),
    {
      x: 7.05, y: 2.6, w: 5.5, h: 4.3,
      fontFace: FONT, fontSize: 10.5,
    },
  );

  addFooter(s, page, total);
});

// 16 — Demo flow
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Demo path", "Five clicks from upload to deliverable");

  const steps = [
    { n: "1", t: "Sign in", d: "/auth/dev for instant access in development" },
    { n: "2", t: "Load sample RFP", d: "Pre-built 19-question RFP + 4-doc KB in one click" },
    { n: "3", t: "Bulk generate", d: "Click \"Generate all unanswered\" → 3 parallel workers" },
    { n: "4", t: "Review + edit", d: "Approve high-confidence; edit + regen low-confidence" },
    { n: "5", t: "Export to Word", d: "Branded .docx with cover, citations, confidence badges" },
  ];

  steps.forEach((st, i) => {
    const y = 2.1 + i * 0.95;
    s.addShape(pres.ShapeType.ellipse, {
      x: 0.5, y: y + 0.05, w: 0.7, h: 0.7,
      fill: { color: COLOR.primary },
      line: { type: "none" },
    });
    s.addText(st.n, {
      x: 0.5, y: y + 0.05, w: 0.7, h: 0.7,
      fontFace: FONT, fontSize: 22, color: COLOR.fg, bold: true, align: "center", valign: "middle",
    });
    s.addShape(pres.ShapeType.roundRect, {
      x: 1.4, y, w: 11.4, h: 0.8, rectRadius: 0.1,
      fill: { color: COLOR.card },
      line: { color: COLOR.cardLine, width: 0.5 },
    });
    s.addText(st.t, {
      x: 1.6, y: y + 0.1, w: 3.5, h: 0.6,
      fontFace: FONT, fontSize: 14, color: COLOR.fg, bold: true, valign: "middle",
    });
    s.addText(st.d, {
      x: 5.2, y: y + 0.1, w: 7.4, h: 0.6,
      fontFace: FONT, fontSize: 12, color: COLOR.muted, valign: "middle",
    });
  });

  s.addText("All five steps in well under 5 minutes.", {
    x: 0.5, y: 7.0, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 13, color: COLOR.fg, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 17 — Recommendation
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Recommendation", "If you ship one stack tomorrow");

  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 2.0, w: 12.3, h: 4.5, rectRadius: 0.15,
    fill: { color: COLOR.card },
    line: { color: COLOR.primary, width: 2 },
  });

  const recs = [
    { label: "Chat model", value: "Llama 3.3 70B Instruct via Ollama (self-hosted) — fallback to OpenRouter same model" },
    { label: "Embedding model", value: "bge-m3 (1024-dim) via Ollama" },
    { label: "Document parser", value: "Local (pdf-parse + mammoth + officeparser) · LlamaParse only for tables/charts" },
    { label: "Database", value: "PostgreSQL 16+ · Float[] embeddings · swap to pgvector once chunks > 100k" },
    { label: "Deployment", value: "Single Docker host with Postgres + Ollama + the app · scale horizontally later" },
    { label: "Email", value: "Mailpit locally · Postmark/SES in production" },
  ];

  recs.forEach((r, i) => {
    const y = 2.3 + i * 0.65;
    s.addText(r.label.toUpperCase(), {
      x: 0.8, y, w: 3.2, h: 0.4,
      fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 3, valign: "middle",
    });
    s.addText(r.value, {
      x: 4.1, y, w: 8.5, h: 0.4,
      fontFace: FONT, fontSize: 12, color: COLOR.fg, valign: "middle",
    });
  });

  s.addText("Total operational cost: ~$0 in licensing fees if you have a GPU box. Migrate to OpenRouter for cold-start.", {
    x: 0.5, y: 6.7, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.muted, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 18 — Closing
slides.push((page, total) => {
  const s = addSlide();
  s.addText("Questions?", {
    x: 0.5, y: 3.2, w: 12.3, h: 1.2,
    fontFace: FONT, fontSize: 72, color: COLOR.fg, bold: true, align: "center",
  });
  s.addText("AutoRFP — built in the open, ready to extend.", {
    x: 0.5, y: 4.4, w: 12.3, h: 0.5,
    fontFace: FONT, fontSize: 20, color: COLOR.primary2, align: "center",
  });
  s.addText(
    "Self-hosted · provider-agnostic · multi-tenant · streaming · cited · scored",
    {
      x: 0.5, y: 5.0, w: 12.3, h: 0.4,
      fontFace: FONT, fontSize: 13, color: COLOR.muted, align: "center", italic: true,
    },
  );
});

// ---------- Render ----------
const total = slides.length;
slides.forEach((fn, i) => fn(i + 1, total));

const outPath = resolve(outDir, "AutoRFP-deck.pptx");
await pres.writeFile({ fileName: outPath });
console.log(`✓ wrote ${outPath}`);
console.log(`  ${total} slides`);
