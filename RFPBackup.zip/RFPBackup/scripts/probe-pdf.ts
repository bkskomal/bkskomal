import { readFile } from "node:fs/promises";
import { parseAndProcess } from "../src/lib/parsers/pipeline";

async function main() {
  const path = process.argv[2] ?? "C:/Users/bkkom/Downloads/updated_realistic_pdf.pdf";
  console.log(`> reading ${path}`);
  const buf = await readFile(path);
  console.log(`  ${buf.byteLength} bytes`);

  const t0 = Date.now();
  const result = await parseAndProcess(buf, "application/pdf", "updated_realistic_pdf.pdf", {
    enableOcr: false,
  } as Parameters<typeof parseAndProcess>[3]);

  console.log(`  parse done in ${Date.now() - t0}ms`);
  console.log(`  AST blocks:   ${result.ast.blocks.length}`);
  console.log(`  pages:        ${result.ast.report.pageCount ?? "?"}`);
  console.log(`  parser:       ${result.ast.report.parser}`);
  console.log(`  warnings:     ${result.ast.report.warnings.length}`);
  console.log(`  errors:       ${result.ast.report.errors.length}`);
  console.log(`  chunks:       ${result.chunks.length}`);
  console.log(`  text len:     ${result.text.length}`);
  console.log(`  images:       ${result.images?.length ?? 0}`);
  console.log(`  quality:      ${result.quality.score.toFixed(2)}`);
  for (const w of result.ast.report.warnings.slice(0, 8)) {
    console.log(`    ! ${w.code}: ${w.message.slice(0, 200)}`);
  }
  for (const e of result.ast.report.errors.slice(0, 5)) {
    console.log(`    ✗ ${e.code}: ${e.message.slice(0, 200)}`);
  }
  // Show first chunk + first heading for sanity
  if (result.chunks.length > 0) {
    console.log(`  ----------- first chunk -----------`);
    console.log(result.chunks[0].content.slice(0, 400));
  }
  console.log(`  ----------- markdown head -----------`);
  console.log(result.text.slice(0, 600));
}
main().catch((e) => {
  console.error("FAILED", e instanceof Error ? e.stack ?? e.message : String(e));
  process.exit(1);
});
