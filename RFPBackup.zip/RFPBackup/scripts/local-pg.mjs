// Local Postgres via PGlite WASM. Real Postgres protocol on tcp:5433, with
// pgvector built-in. No install / no Docker / no admin.
//
// Storage is persisted to ./.pglite/ (gitignored).
//
// Usage:
//   node scripts/local-pg.mjs            # foreground, Ctrl+C to stop
//   pnpm db:local                        # via package.json script

import { PGlite } from "@electric-sql/pglite";
import { vector } from "@electric-sql/pglite/vector";
import { PGLiteSocketServer } from "@electric-sql/pglite-socket";
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";

const dataDir = resolve("./.pglite");
mkdirSync(dataDir, { recursive: true });

const port = Number(process.env.PGLITE_PORT ?? 5433);

console.log("[pglite] booting WASM Postgres…");
const db = await PGlite.create({
  dataDir,
  extensions: { vector },
});

const server = new PGLiteSocketServer({ db, port, host: "127.0.0.1" });
await server.start();

console.log(`[pglite] listening on postgres://postgres:postgres@127.0.0.1:${port}/postgres`);
console.log("[pglite] pgvector extension is bundled. Press Ctrl+C to stop.");

const shutdown = async () => {
  console.log("\n[pglite] shutting down…");
  await server.stop();
  await db.close();
  process.exit(0);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
