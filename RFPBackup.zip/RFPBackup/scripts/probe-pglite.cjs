const { Client } = require("pg");

(async () => {
  const c = new Client({
    host: "127.0.0.1",
    port: 5433,
    user: "postgres",
    password: "",
    database: "postgres",
    ssl: false,
    connectionTimeoutMillis: 8000,
  });
  try {
    await c.connect();
    const v = await c.query("SELECT version()");
    await c.query("CREATE EXTENSION IF NOT EXISTS vector");
    const ext = await c.query(
      "SELECT extname, extversion FROM pg_extension WHERE extname IN ('vector','pgcrypto')",
    );
    console.log("OK");
    console.log("version:", v.rows[0].version.split(",")[0]);
    console.log("extensions:", ext.rows);
    await c.end();
  } catch (e) {
    console.error("FAIL:", e.message);
    process.exit(2);
  }
})();
