import { scrapeUrl, scrapedToHtml } from "../src/lib/scraper/url-scraper";

async function main() {
  const url = process.argv[2] ?? "https://www.godhascome.com/";
  const scraped = await scrapeUrl(url, { respectRobots: false, maxImages: 100 });
  const html = scrapedToHtml(scraped, { scrapeImages: true });
  const allImgs = html.match(/<img[^>]*>/gi) ?? [];
  const extrasSection = html.includes('class="autorfp-extra-images"');
  console.log(`scraped images count: ${scraped.images.length}`);
  console.log(`<img> tags in scrapedToHtml output: ${allImgs.length}`);
  console.log(`includes extras section? ${extrasSection}`);
  // Count placeholder vs real URLs
  let placeholders = 0, realUrls = 0;
  for (const tag of allImgs) {
    const srcMatch = /\bsrc=["']([^"']*)["']/.exec(tag);
    if (srcMatch?.[1].startsWith("data:")) placeholders++;
    else realUrls++;
  }
  console.log(`  placeholder data: srcs: ${placeholders}`);
  console.log(`  real http(s) srcs: ${realUrls}`);
  // Show length
  console.log(`scrapedToHtml total bytes: ${html.length}`);
}
main();
