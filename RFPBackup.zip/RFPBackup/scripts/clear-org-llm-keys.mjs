// Clear per-org encrypted LLM API keys so every org falls back to the env
// LLM_API_KEY (which is validated). Use this after rotating keys in the env
// if some orgs had stale per-org overrides.
//
// Dry-run by default. Pass `--apply` to actually mutate.
//
// Run: node --env-file=.env scripts/clear-org-llm-keys.mjs [--apply]

import { PrismaClient } from "@prisma/client";

const apply = process.argv.includes("--apply");
const prisma = new PrismaClient();
try {
  const rows = await prisma.orgAiConfig.findMany({
    where: { llmApiKeyEncrypted: { not: null } },
    include: { organization: { select: { name: true, slug: true } } },
  });

  if (rows.length === 0) {
    console.log("No org has a pinned LLM API key. Nothing to clear.");
    process.exit(0);
  }

  console.log(`Found ${rows.length} org(s) with a pinned LLM API key:`);
  for (const r of rows) {
    const len = r.llmApiKeyEncrypted?.length ?? 0;
    console.log(`  • ${r.organization?.name ?? "?"} (${r.organization?.slug ?? "?"})  key length=${len}`);
  }

  if (!apply) {
    console.log(`\n[dry-run] Pass --apply to clear ${rows.length} encrypted key(s) and fall back to env LLM_API_KEY.`);
    process.exit(0);
  }

  const result = await prisma.orgAiConfig.updateMany({
    where: { llmApiKeyEncrypted: { not: null } },
    data: { llmApiKeyEncrypted: null },
  });
  console.log(`\n✓ Cleared ${result.count} encrypted LLM API key(s). All orgs now use env LLM_API_KEY.`);
} finally {
  await prisma.$disconnect();
}
