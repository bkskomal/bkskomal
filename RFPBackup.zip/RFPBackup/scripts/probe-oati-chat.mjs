// Probe the OATI UserPrompt endpoint directly with a few request variants.
// Mirrors what runExternalChatTurn sends so we can see the upstream response
// without going through the chat UI.
//
// Run: node scripts/probe-oati-chat.mjs

import { randomUUID } from "node:crypto";

const ENDPOINT = "http://aniketsa-d.dev.oati.local/network_api/api/v1/UserPrompt";
const PROMPTS = ["hello", "What is OATI?", "ping"];

function buildBody(prompt, conversationId = "") {
  return {
    metadata: {
      user_id: 0,
      organization_id: 0,
      user_name: "Komal",
      user_timezone: "America/Chicago",
      client: "AutoRFP",
      product: "OATI AutoRFP",
      data_source: [],
      source: "chat",
      prompt_id: randomUUID(),
      enable_query_analyzer: true,
      enable_follow_up: true,
      enable_abbreviation: true,
      json_stream: false,
    },
    prompt,
    conversation_id: conversationId,
    stream: false,
  };
}

async function probe(prompt) {
  console.log(`\n━━━ Prompt: "${prompt}" ━━━`);
  const body = buildBody(prompt);
  console.log(`→ POST ${ENDPOINT}`);
  console.log(`  body: ${JSON.stringify(body).slice(0, 200)}...`);
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch (e) {
    console.error(`✗ fetch threw: ${e.message ?? e}`);
    return;
  }
  const ms = Date.now() - t0;
  console.log(`← HTTP ${res.status} in ${ms}ms`);
  const text = await res.text();
  console.log(`  raw body (${text.length} chars):`);
  console.log(`  ${text.slice(0, 800)}${text.length > 800 ? "...(truncated)" : ""}`);
  try {
    const parsed = JSON.parse(text);
    console.log(`  parsed keys: [${Object.keys(parsed).join(", ")}]`);
    if (parsed.response !== undefined)
      console.log(`  → response (${String(parsed.response).length} chars): "${String(parsed.response).slice(0, 240)}"`);
    if (parsed.conversation_id !== undefined)
      console.log(`  → conversation_id: ${parsed.conversation_id}`);
    if (parsed.references !== undefined)
      console.log(`  → references: ${JSON.stringify(parsed.references).slice(0, 200)}`);
    if (parsed.follow_up_questions !== undefined)
      console.log(`  → follow_up_questions: ${JSON.stringify(parsed.follow_up_questions).slice(0, 200)}`);
    if (parsed.abbreviations !== undefined)
      console.log(`  → abbreviations: ${JSON.stringify(parsed.abbreviations).slice(0, 200)}`);
  } catch {
    console.log(`  (body is not JSON)`);
  }
}

for (const p of PROMPTS) {
  await probe(p);
}
