import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

async function main() {
  const path = process.argv[2] ?? "C:/Users/bkkom/Downloads/updated_realistic_pdf.pdf";
  const buf = await readFile(path);
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const req = createRequire(import.meta.url);
  pdfjs.GlobalWorkerOptions.workerSrc = pathToFileURL(
    req.resolve("pdfjs-dist/legacy/build/pdf.worker.mjs"),
  ).href;

  const data = new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
  const doc = await pdfjs.getDocument({ data, verbosity: 0 }).promise;

  const sharp = await import("sharp").catch((e) => {
    console.log("sharp import FAILED:", e instanceof Error ? e.message : String(e));
    return null;
  });
  console.log(`sharp imported: ${sharp != null}; default fn? ${typeof (sharp as any)?.default}`);

  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const opList = await page.getOperatorList();
    const objIds: string[] = [];
    for (let i = 0; i < opList.fnArray.length; i++) {
      const a = opList.argsArray[i];
      if (Array.isArray(a) && typeof a[0] === "string" && a[0].startsWith("img_")) {
        objIds.push(a[0]);
      }
    }
    console.log(`page ${p}: found img ids: ${objIds.join(", ")}`);
    for (const id of objIds) {
      try {
        const obj = page.objs.get(id);
        if (!obj) {
          console.log(`  ${id}: page.objs.get returned null/undefined`);
          continue;
        }
        const o = obj as any;
        console.log(
          `  ${id}: kind=${o.kind} w=${o.width} h=${o.height} dataLen=${o.data?.byteLength ?? "?"}`,
        );
      } catch (e) {
        console.log(`  ${id}: page.objs.get THREW: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
  }
}
main().catch((e) => {
  console.error("FAILED", e);
  process.exit(1);
});
