// Smoke test: one tiny chat completion through the env-configured OpenRouter
// account. Confirms the key is valid + the model is reachable.
// Cost: ~$0.0001 on llama-3.1-8b. Run once after rotating keys.

// Run with: node --env-file=.env scripts/smoke-llm.mjs
import OpenAI from "openai";

const llm = new OpenAI({
  baseURL: process.env.LLM_BASE_URL,
  apiKey: process.env.LLM_API_KEY,
  defaultHeaders: {
    ...(process.env.LLM_HTTP_REFERER ? { "HTTP-Referer": process.env.LLM_HTTP_REFERER } : {}),
    ...(process.env.LLM_APP_TITLE ? { "X-Title": process.env.LLM_APP_TITLE } : {}),
  },
});

const model = process.env.LLM_MODEL;
console.log(`POST ${process.env.LLM_BASE_URL}/chat/completions (model: ${model})`);

const t0 = Date.now();
try {
  const r = await llm.chat.completions.create({
    model,
    temperature: 0,
    max_tokens: 20,
    messages: [{ role: "user", content: "Say exactly: pong" }],
  });
  const ms = Date.now() - t0;
  const text = r.choices[0]?.message?.content ?? "";
  console.log(`✓ ${ms}ms — response: "${text.trim()}"`);
  console.log(`  usage: prompt=${r.usage?.prompt_tokens ?? "?"} completion=${r.usage?.completion_tokens ?? "?"}`);
  console.log(`\n✓ PASS — OpenRouter key works, model is reachable.`);
} catch (e) {
  console.error(`✗ FAIL after ${Date.now() - t0}ms`);
  console.error(e?.status ? `  HTTP ${e.status}: ${e.message}` : e?.message ?? e);
  process.exit(1);
}
