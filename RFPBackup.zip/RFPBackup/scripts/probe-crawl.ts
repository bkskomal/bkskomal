import { scrapeSite } from "../src/lib/scraper/url-scraper";

async function main() {
  const url = process.argv[2] ?? "https://www.godhascome.com/";
  const max = parseInt(process.argv[3] ?? "5", 10);
  console.log(`> crawling ${url} (max ${max} pages, same-origin only)`);
  const t0 = Date.now();
  const pages = await scrapeSite(url, {
    respectRobots: false,
    maxPages: max,
    maxDepth: 2,
    perHostDelayMs: 500,
    onPage: (p) =>
      console.log(`  [${p.ok ? "OK" : "ERR"}] ${p.url}${p.doc ? ` — ${p.doc.images.length} imgs` : ""}${p.error ? ` (${p.error})` : ""}`),
  });
  console.log(`> done: ${pages.length} pages in ${Date.now() - t0}ms`);
  const totalImages = pages.reduce((n, p) => n + (p.doc?.images.length ?? 0), 0);
  console.log(`  total images across all pages: ${totalImages}`);
}
main().catch((e) => {
  console.error("FAILED:", e instanceof Error ? e.message : String(e));
  process.exit(1);
});
