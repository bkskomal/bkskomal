// Probes whether the image-fetch hydrator now succeeds against a TLS-fussy
// host (godhascome.com) — earlier every image silently failed because the
// bare fetch threw on UNABLE_TO_VERIFY_LEAF_SIGNATURE.
import { hydrateFigureImages } from "../src/lib/parsers/image-fetch";

async function main() {
  const urls = [
    "https://www.godhascome.com/wp-content/uploads/2018/06/god-has-come-1.jpg",
    "https://www.godhascome.com/wp-content/uploads/2018/06/needle1.png",
    "https://www.godhascome.com/wp-content/uploads/2018/07/God-Speaks.png",
  ];
  const blocks = urls.map((url, i) => ({
    kind: "figure" as const,
    anchor: `f${i}`,
    imageRef: url,
  }));
  const t0 = Date.now();
  const result = await hydrateFigureImages(blocks, {
    allowFetch: true,
    maxImages: 50,
  });
  const hydrated = result.blocks.filter(
    (b) => b.kind === "figure" && (b as { imageBuffer?: Buffer }).imageBuffer,
  );
  console.log(`Hydrated ${hydrated.length}/${urls.length} images in ${Date.now() - t0}ms`);
  result.warnings.forEach((w) => console.log(`  ! ${w.code}: ${w.message.slice(0, 140)}`));
  for (const b of result.blocks) {
    if (b.kind !== "figure") continue;
    const buf = (b as { imageBuffer?: Buffer }).imageBuffer;
    console.log(
      `  ${buf ? "✓" : "✗"} ${b.anchor}  bytes=${buf?.byteLength ?? 0}  ref=${(b as { imageRef?: string }).imageRef?.slice(0, 80)}`,
    );
  }
}
main().catch((e) => {
  console.error("FAILED", e instanceof Error ? e.message : String(e));
  process.exit(1);
});
