// Probe the model the org has pinned for extraction.
// Run: node --env-file=.env scripts/smoke-llm-pinned.mjs anthropic/claude-sonnet-4.5

import OpenAI from "openai";

const model = process.argv[2] ?? process.env.LLM_MODEL;
const llm = new OpenAI({
  baseURL: process.env.LLM_BASE_URL,
  apiKey: process.env.LLM_API_KEY,
  defaultHeaders: {
    ...(process.env.LLM_HTTP_REFERER ? { "HTTP-Referer": process.env.LLM_HTTP_REFERER } : {}),
    ...(process.env.LLM_APP_TITLE ? { "X-Title": process.env.LLM_APP_TITLE } : {}),
  },
});

console.log(`Probing model: ${model}`);
try {
  const r = await llm.chat.completions.create({
    model,
    temperature: 0,
    max_tokens: 10,
    messages: [{ role: "user", content: "Reply with: ok" }],
  });
  console.log(`✓ OK — response: "${(r.choices[0]?.message?.content ?? "").trim()}"`);
} catch (e) {
  console.error(`✗ FAIL`);
  console.error(`  status: ${e?.status ?? "?"}`);
  console.error(`  message: ${e?.message ?? e}`);
  if (e?.error) console.error(`  error body: ${JSON.stringify(e.error, null, 2)}`);
}
