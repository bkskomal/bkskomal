// End-to-end probe: scrape a URL, render to HTML, run it through the
// parser pipeline (html-parser → image-fetch → CLIP → image-store).
// Reports exactly where the pipeline drops images.
import { scrapeUrl, scrapedToHtml } from "../src/lib/scraper/url-scraper";
import { parseAndProcess } from "../src/lib/parsers/pipeline";

async function main() {
  const url = process.argv[2] ?? "https://www.godhascome.com/";
  console.log(`> scrape ${url}`);
  const scraped = await scrapeUrl(url, { respectRobots: false, maxImages: 100 });
  console.log(`  ${scraped.images.length} image URLs found`);

  const html = scrapedToHtml(scraped, { scrapeImages: true });
  const buffer = Buffer.from(html, "utf8");
  console.log(`> parse + process (HTML is ${buffer.byteLength} bytes)`);

  const t0 = Date.now();
  // Cast to any to bypass ParsePipelineOptions strictness in this script —
  // the field is genuinely optional at runtime.
  const result = await parseAndProcess(buffer, "text/html", "scraped.html", {
    enableOcr: false,
  } as Parameters<typeof parseAndProcess>[3]);
  console.log(`  parse done in ${Date.now() - t0}ms`);

  // Count figures in the AST
  const figures = result.ast.blocks.filter((b) => b.kind === "figure");
  const hydrated = figures.filter((b) => (b as { imageRef?: string }).imageRef);
  console.log(`  AST blocks: ${result.ast.blocks.length}`);
  console.log(`  figures:    ${figures.length}`);
  console.log(`  with ref:   ${hydrated.length}`);
  console.log(`  images[]:   ${result.images?.length ?? 0}  ← what indexing.ts persists`);
  console.log(`  chunks:     ${result.chunks.length}`);
  console.log(`  warnings:   ${result.ast.report.warnings.length}`);
  for (const w of result.ast.report.warnings.slice(0, 8)) {
    console.log(`    ! ${w.code}: ${w.message.slice(0, 160)}`);
  }
  for (const w of result.ast.report.warnings.slice(8)) {
    console.log(`    ! ${w.code}`);
  }
}
main().catch((e) => {
  console.error("FAILED", e instanceof Error ? e.message : String(e));
  if (e instanceof Error && (e as Error & { cause?: unknown }).cause) {
    console.error("  cause:", String((e as Error & { cause?: unknown }).cause));
  }
  process.exit(1);
});
