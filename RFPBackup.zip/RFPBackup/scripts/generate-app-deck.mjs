// AutoRFP — comprehensive application deck.
// Run: `node scripts/generate-app-deck.mjs` → docs/AutoRFP-application.pptx
//
// Audience: anyone who needs the full picture — engineers, sellers, execs.
// Covers problem, capabilities, architecture, every major subsystem with
// diagrams, security, observability, and roadmap.

import PptxGenJS from "pptxgenjs";
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";

// ---------- Theme (matches scripts/generate-deck.mjs) ----------
const COLOR = {
  bg: "0B0716",
  bgPanel: "13102A",
  fg: "F4F1FA",
  muted: "9C9BB0",
  primary: "8A2BE2",
  primary2: "D946EF",
  accent: "38BDF8",
  good: "10B981",
  warn: "F59E0B",
  bad: "EF4444",
  card: "1A1530",
  cardLine: "2B2440",
  trackBg: "12102A",
};
const FONT = "Calibri";

const outDir = resolve("./docs");
mkdirSync(outDir, { recursive: true });

const pres = new PptxGenJS();
pres.layout = "LAYOUT_WIDE"; // 13.33 × 7.5
pres.title = "AutoRFP — Application Overview";
pres.author = "AutoRFP";

const W = 13.33;
const H = 7.5;

// ---------- Helpers ----------
function addSlide() {
  const s = pres.addSlide();
  s.background = { color: COLOR.bg };
  s.addShape(pres.ShapeType.rect, {
    x: 0, y: 0, w: W * 0.4, h: 0.08,
    fill: { color: COLOR.primary }, line: { type: "none" },
  });
  s.addShape(pres.ShapeType.rect, {
    x: W * 0.4, y: 0, w: W * 0.6, h: 0.08,
    fill: { color: COLOR.primary2 }, line: { type: "none" },
  });
  s.addShape(pres.ShapeType.ellipse, {
    x: -2, y: -1.5, w: 5, h: 5,
    fill: { color: COLOR.primary, transparency: 90 }, line: { type: "none" },
  });
  s.addShape(pres.ShapeType.ellipse, {
    x: W - 3, y: H - 3, w: 5, h: 5,
    fill: { color: COLOR.primary2, transparency: 92 }, line: { type: "none" },
  });
  return s;
}

function addFooter(s, page, total) {
  s.addText("AutoRFP · AI-Powered RFP Response Platform", {
    x: 0.4, y: H - 0.45, w: 8, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.muted,
  });
  s.addText(`${page} / ${total}`, {
    x: W - 1.2, y: H - 0.45, w: 0.8, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.muted, align: "right",
  });
}

function addTitle(s, eyebrow, title) {
  s.addText(eyebrow.toUpperCase(), {
    x: 0.5, y: 0.45, w: 12, h: 0.35,
    fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 6,
  });
  s.addText(title, {
    x: 0.5, y: 0.85, w: 12, h: 0.9,
    fontFace: FONT, fontSize: 30, color: COLOR.fg, bold: true,
  });
}

function addCard(s, x, y, w, h, title, body, opts = {}) {
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h,
    fill: { color: opts.bg ?? COLOR.card },
    line: { color: opts.line ?? COLOR.cardLine, width: opts.lineWidth ?? 0.5 },
    rectRadius: 0.12,
  });
  if (opts.tag) {
    s.addText(opts.tag, {
      x: x + 0.2, y: y + 0.15, w: w - 0.4, h: 0.3,
      fontFace: FONT, fontSize: 9, color: opts.tagColor ?? COLOR.primary2,
      bold: true, charSpacing: 4,
    });
  }
  s.addText(title, {
    x: x + 0.25, y: y + (opts.tag ? 0.45 : 0.18), w: w - 0.5, h: 0.4,
    fontFace: FONT, fontSize: opts.titleSize ?? 14, color: COLOR.fg, bold: true,
  });
  if (body) {
    const textBody = Array.isArray(body)
      ? body.map((b) => ({ text: b, options: { bullet: { code: "25CF" }, color: COLOR.muted } }))
      : body;
    s.addText(textBody, {
      x: x + 0.25, y: y + (opts.tag ? 0.85 : 0.65), w: w - 0.5, h: h - 1,
      fontFace: FONT, fontSize: opts.bodySize ?? 10.5, color: COLOR.muted,
      paraSpaceAfter: 4, valign: "top",
    });
  }
}

function addBox(s, x, y, w, h, label, opts = {}) {
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h, rectRadius: 0.08,
    fill: { color: opts.fill ?? COLOR.card },
    line: { color: opts.line ?? COLOR.cardLine, width: opts.lineWidth ?? 0.75 },
  });
  s.addText(label, {
    x, y, w, h,
    fontFace: FONT, fontSize: opts.fontSize ?? 11,
    color: opts.color ?? COLOR.fg, bold: opts.bold ?? false,
    align: "center", valign: "middle",
  });
}

function addArrow(s, x1, y1, x2, y2, opts = {}) {
  s.addShape(pres.ShapeType.line, {
    x: x1, y: y1, w: x2 - x1, h: y2 - y1,
    line: {
      color: opts.color ?? COLOR.primary2,
      width: opts.width ?? 1.25,
      endArrowType: "triangle",
    },
  });
}

// ============ Slides ============
const slides = [];

// 01 — Cover
slides.push((page, total) => {
  const s = addSlide();
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 0.5, w: 1.4, h: 1.4, rectRadius: 0.25,
    fill: { color: COLOR.primary }, line: { type: "none" },
  });
  s.addText("A", {
    x: 0.5, y: 0.5, w: 1.4, h: 1.4,
    fontFace: FONT, fontSize: 76, color: COLOR.fg, bold: true,
    align: "center", valign: "middle",
  });
  s.addText("AutoRFP", {
    x: 0.5, y: 2.2, w: 12, h: 1.4,
    fontFace: FONT, fontSize: 64, color: COLOR.fg, bold: true,
  });
  s.addText("AI-Powered RFP Response Platform", {
    x: 0.5, y: 3.45, w: 12, h: 0.7,
    fontFace: FONT, fontSize: 22, color: COLOR.primary2,
  });
  s.addText(
    "Architecture · Capabilities · Pipeline · Production hardening",
    { x: 0.5, y: 4.2, w: 12, h: 0.5, fontFace: FONT, fontSize: 14, color: COLOR.muted },
  );

  // 4 chips at bottom
  const chips = [
    { label: "300+ tests", color: COLOR.good },
    { label: "Multi-tenant", color: COLOR.accent },
    { label: "Self-hostable", color: COLOR.primary2 },
    { label: "Bring-your-own-LLM", color: COLOR.warn },
  ];
  chips.forEach((c, i) => {
    s.addShape(pres.ShapeType.roundRect, {
      x: 0.5 + i * 1.7, y: 5.1, w: 1.5, h: 0.4, rectRadius: 0.2,
      fill: { color: COLOR.card }, line: { color: c.color, width: 0.75 },
    });
    s.addText(c.label, {
      x: 0.5 + i * 1.7, y: 5.1, w: 1.5, h: 0.4,
      fontFace: FONT, fontSize: 10, color: c.color, bold: true,
      align: "center", valign: "middle",
    });
  });

  s.addText(`Generated ${new Date().toISOString().slice(0, 10)}`, {
    x: 0.5, y: H - 0.9, w: 6, h: 0.3,
    fontFace: FONT, fontSize: 10, color: COLOR.muted,
  });
});

// 02 — The problem
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Why this exists", "RFP response is broken at every stage");
  const stats = [
    { metric: "50–300", label: "questions per RFP", color: COLOR.warn },
    { metric: "70%", label: "of answers already exist somewhere in the org", color: COLOR.primary2 },
    { metric: "5+ days", label: "average response time for a 100-question RFP", color: COLOR.warn },
    { metric: "$50K+", label: "average opportunity cost per missed bid", color: COLOR.bad },
  ];
  stats.forEach((r, i) => {
    const x = 0.5 + (i % 2) * 6.4;
    const y = 1.95 + Math.floor(i / 2) * 1.95;
    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: 6.1, h: 1.75, rectRadius: 0.12,
      fill: { color: COLOR.card }, line: { color: COLOR.cardLine, width: 0.5 },
    });
    s.addText(r.metric, {
      x: x + 0.3, y: y + 0.15, w: 5.5, h: 1.1,
      fontFace: FONT, fontSize: 48, color: r.color, bold: true,
    });
    s.addText(r.label, {
      x: x + 0.3, y: y + 1.15, w: 5.5, h: 0.5,
      fontFace: FONT, fontSize: 13, color: COLOR.muted,
    });
  });
  s.addText("AutoRFP doesn't just speed this up — it changes the workflow.", {
    x: 0.5, y: 6.05, w: 12.3, h: 0.5,
    fontFace: FONT, fontSize: 14, color: COLOR.fg, italic: true, align: "center",
  });
  addFooter(s, page, total);
});

// 03 — What is AutoRFP (4 value props)
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Product overview", "What AutoRFP does, in one slide");
  s.addText(
    [
      { text: "AutoRFP ", options: { bold: true, color: COLOR.fg } },
      { text: "ingests an RFP, extracts every question, drafts a cited response from your knowledge base, and routes the work through a configurable pipeline — all while preserving auditability, multi-tenancy, and bring-your-own-LLM flexibility.", options: { color: COLOR.muted } },
    ],
    { x: 0.5, y: 1.85, w: 12.3, h: 0.85, fontFace: FONT, fontSize: 14 },
  );
  const props = [
    { tag: "01 · QUALITY", title: "Cited, grounded answers", body: "Hybrid retrieval + LLM rerank + a second judge pass scores every claim against its sources. Hallucinations don't ship." },
    { tag: "02 · SPEED", title: "5 days → 5 hours", body: "Streaming generation, bulk-answer pipelines, semantic caching, and tool-calling cut response time by an order of magnitude." },
    { tag: "03 · CONTROL", title: "Pause, edit, resume any pipeline", body: "Human-in-the-loop on every step. Decision gates for high-stakes choices. Pause mid-flight, re-route, then resume." },
    { tag: "04 · OPS", title: "Production-grade from day one", body: "Multi-tenant, OAuth + magic-link + API keys, AES-256-GCM secrets, Prometheus metrics, audit log, circuit breakers." },
  ];
  props.forEach((c, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    addCard(s, 0.5 + col * 6.4, 3 + row * 1.85, 6.1, 1.65, c.title, c.body, { tag: c.tag });
  });
  addFooter(s, page, total);
});

// 04 — Capability map
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Capability map", "Eight core capabilities");
  const caps = [
    { tag: "INGEST",      t: "Document parsing",     d: "PDF · Word · Excel · PPT · Markdown · LlamaParse fallback" },
    { tag: "EXTRACT",     t: "Question extraction",  d: "2-stage: section-aware batching + LLM eligibility classifier" },
    { tag: "RETRIEVE",    t: "Hybrid retrieval",     d: "BM25 + dense vectors + RRF fusion + optional LLM rerank" },
    { tag: "GENERATE",    t: "Response drafting",    d: "Streaming SSE · multi-step · tool calling · golden answers" },
    { tag: "GROUND",      t: "Hallucination scoring", d: "Second LLM-judge pass scores every claim against sources" },
    { tag: "ORCHESTRATE", t: "Pipeline engine",      d: "AUTO / MANUAL / DECISION steps · pause · resume · edit" },
    { tag: "COLLABORATE", t: "Workflow",             d: "SME assignment · @mentions · comments · review · approve" },
    { tag: "LEARN",       t: "Win/loss feedback",    d: "Outcome tagging boosts retrieval; LOST surfaces coaching" },
  ];
  const cw = 3.0, ch = 1.2;
  caps.forEach((c, i) => {
    const col = i % 4;
    const row = Math.floor(i / 4);
    const x = 0.5 + col * 3.2;
    const y = 2.0 + row * 1.4;
    addCard(s, x, y, cw, ch, c.t, c.d, { tag: c.tag, titleSize: 12, bodySize: 9.5 });
  });

  // Bottom strip — 4 more
  const more = [
    "INSIGHTS · org-scoped dashboard + Prometheus /metrics endpoint",
    "MULTI-DOC · primary RFP + addenda + security questionnaire + pricing matrix",
    "INTEGRATIONS · webhooks (HMAC-signed) + Bearer API for any external tool",
    "FLEXIBILITY · OpenAI · OpenRouter · Ollama · LM Studio · vLLM · LocalAI · Custom",
  ];
  more.forEach((t, i) => {
    s.addText(`▸ ${t}`, {
      x: 0.5, y: 5.05 + i * 0.36, w: 12.3, h: 0.32,
      fontFace: FONT, fontSize: 11, color: COLOR.muted,
    });
  });

  addFooter(s, page, total);
});

// 05 — Technology stack
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Stack", "What it's built on");
  const cols = [
    { tag: "FRONTEND", title: "UI layer", lines: ["Next.js 15 (App Router)", "React 19", "Tailwind CSS", "Radix UI primitives", "Streaming Server Components", "SSE for live generation"] },
    { tag: "BACKEND", title: "Server", lines: ["TypeScript end-to-end", "Next.js Route Handlers", "Prisma 6 ORM", "Zod validation", "PostgreSQL (Float[] vectors)", "AsyncLocalStorage scoping"] },
    { tag: "AI", title: "AI / ML", lines: ["OpenAI-compatible client", "@huggingface/transformers", "Xenova all-MiniLM-L6-v2", "Hybrid BM25 + dense + RRF", "LLM-judge grounding", "Provider-agnostic"] },
    { tag: "INFRA", title: "Operations", lines: ["Docker (multi-stage, non-root)", "docker-compose w/ Postgres + Mailpit + Grafana", "Pino structured logs", "Prometheus /metrics", "ioredis (rate-limit)", "Vitest (300+ tests)"] },
  ];
  cols.forEach((c, i) => {
    addCard(s, 0.5 + i * 3.2, 2.0, 3.0, 4.5, c.title, c.lines, {
      tag: c.tag, titleSize: 14, bodySize: 10,
    });
  });
  addFooter(s, page, total);
});

// 06 — High-level architecture diagram
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Architecture", "Three-tier · self-hostable · bring-your-own-LLM");

  // Top tier — Browser / clients
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 1.85, w: 12.3, h: 0.95, rectRadius: 0.12,
    fill: { color: COLOR.card }, line: { color: COLOR.accent, width: 1.5 },
  });
  s.addText("CLIENTS", {
    x: 0.5, y: 1.92, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.accent, bold: true, align: "center", charSpacing: 4,
  });
  ["Web dashboard", "RFP viewer (SSE)", "Chat UI", "External tools (Bearer API)"].forEach((b, i) => {
    addBox(s, 0.7 + i * 3.05, 2.27, 2.85, 0.45, b, { fontSize: 10, fill: COLOR.bgPanel, line: COLOR.cardLine });
  });

  // Middle tier — Application
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 3.05, w: 12.3, h: 1.95, rectRadius: 0.12,
    fill: { color: COLOR.card }, line: { color: COLOR.primary2, width: 1.5 },
  });
  s.addText("APPLICATION  ·  Next.js Route Handlers + service modules", {
    x: 0.5, y: 3.12, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.primary2, bold: true, align: "center", charSpacing: 4,
  });
  const services = [
    "Auth & API keys", "Pipeline engine", "Question extract", "Hybrid retrieval",
    "Response generate", "Tools registry", "Grounding judge", "Audit log",
    "Rate-limit + breaker", "Metrics", "Webhooks (HMAC)", "Insights",
  ];
  services.forEach((sv, i) => {
    const col = i % 4;
    const row = Math.floor(i / 4);
    addBox(s, 0.7 + col * 3.05, 3.5 + row * 0.45, 2.85, 0.38, sv, {
      fontSize: 9.5, fill: COLOR.bgPanel, line: COLOR.cardLine, color: COLOR.fg,
    });
  });

  // Bottom tier — Storage / external
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 5.25, w: 12.3, h: 1.6, rectRadius: 0.12,
    fill: { color: COLOR.card }, line: { color: COLOR.primary, width: 1.5 },
  });
  s.addText("DATA  ·  STORAGE  ·  EXTERNAL", {
    x: 0.5, y: 5.32, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.primary, bold: true, align: "center", charSpacing: 4,
  });
  const stores = [
    { l: "PostgreSQL\n+ Float[] vectors", c: COLOR.primary },
    { l: "File storage\nuploads/ on disk", c: COLOR.primary },
    { l: "Redis (optional)\nrate-limit backend", c: COLOR.warn },
    { l: "LLM provider\nOllama · OpenRouter · OpenAI", c: COLOR.primary2 },
    { l: "Prometheus\n+ Grafana", c: COLOR.accent },
  ];
  stores.forEach((st, i) => {
    addBox(s, 0.7 + i * 2.45, 5.7, 2.25, 0.95, st.l, {
      fontSize: 9.5, fill: COLOR.bgPanel, line: st.c, color: COLOR.fg, lineWidth: 1,
    });
  });

  addFooter(s, page, total);
});

// 07 — End-to-end RFP flow
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "End-to-end flow", "RFP upload → cited responses, with humans in the loop");

  const stages = [
    { x: 0.5, label: "Upload\n(PDF · DOCX · XLSX)", color: COLOR.accent },
    { x: 2.45, label: "Parse\n(LlamaParse / local)", color: COLOR.accent },
    { x: 4.4, label: "Extract questions\n(2-stage LLM)", color: COLOR.primary2 },
    { x: 6.35, label: "Retrieve evidence\n(BM25 + dense + RRF)", color: COLOR.primary2 },
    { x: 8.3, label: "Generate draft\n(stream + tools)", color: COLOR.primary2 },
    { x: 10.25, label: "Score grounding\n(claim-by-claim)", color: COLOR.warn },
    { x: 12.2, label: "Review · Export\n(human approve)", color: COLOR.good },
  ];
  const boxW = 1.65, boxH = 1.0, y = 2.6;
  stages.forEach((st, i) => {
    addBox(s, st.x - boxW / 2 + 0.825, y, boxW, boxH, st.label, {
      fill: COLOR.card, line: st.color, lineWidth: 1, fontSize: 9.5,
    });
    if (i < stages.length - 1) {
      const nx = stages[i + 1].x - boxW / 2 + 0.825;
      addArrow(s, st.x + boxW / 2 + 0.85, y + boxH / 2, nx, y + boxH / 2, { color: COLOR.muted });
    }
  });

  // Pipeline gate marker
  s.addText("┌─── pipeline engine controls every transition ───┐", {
    x: 0.5, y: y + boxH + 0.2, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 10, color: COLOR.primary, align: "center",
  });

  // Below: cross-cutting concerns
  s.addText("CROSS-CUTTING  ·  audit log  ·  rate-limit  ·  circuit breaker  ·  metrics  ·  AsyncLocalStorage reqId", {
    x: 0.5, y: 5.2, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, align: "center", charSpacing: 3,
  });

  // Side panel facts
  const facts = [
    "Streaming: every step emits SSE events for live UI feedback",
    "Cancelable: pause / resume / stop / edit at any step",
    "Multi-doc: primary RFP can carry addenda + security questionnaires",
    "Per-org config: each org picks its own LLM provider, model, and KB",
  ];
  facts.forEach((f, i) => {
    s.addText(`▸ ${f}`, {
      x: 0.5, y: 5.7 + i * 0.32, w: 12.3, h: 0.3,
      fontFace: FONT, fontSize: 11, color: COLOR.muted,
    });
  });

  addFooter(s, page, total);
});

// 08 — Data model
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Data model", "Multi-tenant by construction");

  // ER-ish diagram with rounded boxes + arrows
  const ents = [
    { x: 0.5,  y: 2.0, w: 2.5, h: 0.7, label: "Organization", c: COLOR.primary2 },
    { x: 0.5,  y: 3.0, w: 2.5, h: 0.7, label: "Membership\n(role: OWNER/ADMIN/MEMBER)", c: COLOR.primary2 },
    { x: 0.5,  y: 4.1, w: 2.5, h: 0.7, label: "OrgAiConfig\n(encrypted keys)", c: COLOR.warn },
    { x: 0.5,  y: 5.1, w: 2.5, h: 0.7, label: "ApiKey\n(SHA-256 hashed)", c: COLOR.good },

    { x: 3.5,  y: 2.0, w: 2.5, h: 0.7, label: "Project", c: COLOR.accent },
    { x: 3.5,  y: 3.0, w: 2.5, h: 0.7, label: "PipelineTemplate", c: COLOR.accent },
    { x: 3.5,  y: 4.1, w: 2.5, h: 0.7, label: "KnowledgeIndex\n→ Doc → Chunk", c: COLOR.accent },
    { x: 3.5,  y: 5.1, w: 2.5, h: 0.7, label: "GoldenAnswer", c: COLOR.accent },

    { x: 6.5,  y: 2.0, w: 2.5, h: 0.7, label: "RFP\n(outcome · docRole · parent)", c: COLOR.primary },
    { x: 6.5,  y: 3.0, w: 2.5, h: 0.7, label: "PipelineRun\n(PAUSED · STOPPED states)", c: COLOR.primary },
    { x: 6.5,  y: 4.1, w: 2.5, h: 0.7, label: "PipelineStepRun", c: COLOR.primary },

    { x: 9.5,  y: 2.0, w: 3.3, h: 0.7, label: "Question\n(complexity · topic · eligibility)", c: COLOR.primary },
    { x: 9.5,  y: 3.0, w: 3.3, h: 0.7, label: "Response\n(confidence · groundingScore)", c: COLOR.primary },
    { x: 9.5,  y: 4.1, w: 3.3, h: 0.7, label: "ResponseSource\n(citations)", c: COLOR.primary },
    { x: 9.5,  y: 5.1, w: 3.3, h: 0.7, label: "Comment / Mention / Notification", c: COLOR.muted },
  ];
  ents.forEach((e) => addBox(s, e.x, e.y, e.w, e.h, e.label, {
    fill: COLOR.card, line: e.c, lineWidth: 1, fontSize: 9.5,
  }));

  // Cross-cutting
  s.addText("Audit log · Activity feed · Tools registry — span all orgs", {
    x: 0.5, y: 6.0, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 10, color: COLOR.muted, italic: true, align: "center",
  });
  s.addText("Hard tenant boundary at Organization. RBAC enforced on every route.", {
    x: 0.5, y: 6.35, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 11, color: COLOR.fg, align: "center", bold: true,
  });

  addFooter(s, page, total);
});

// 09 — Authentication & API keys
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Authentication & access", "Three ways in, one permission model");

  const cols = [
    {
      tag: "01 · INTERACTIVE",
      title: "Sessions (NextAuth v5)",
      body: ["Email magic-link via Nodemailer", "Google · GitHub · Microsoft Entra (env-gated)", "Dev shortcut (`/auth/dev`) for local boxes", "Sessions stored in DB (Prisma adapter)"],
    },
    {
      tag: "02 · PROGRAMMATIC",
      title: "API keys (Bearer)",
      body: ["`autorfp_<32-char>` tokens", "SHA-256 hashed at rest", "Scopes: READ · WRITE · ADMIN", "Per-user, optional org binding", "Revocable · audited · expire-aware"],
    },
    {
      tag: "03 · SYSTEM",
      title: "Webhooks (HMAC)",
      body: ["`X-AutoRFP-Signature: t=…,v1=…`", "SHA-256 over `<ts>.<body>`", "5-minute clock-skew tolerance", "Constant-time verify"],
    },
  ];
  cols.forEach((c, i) => addCard(s, 0.5 + i * 4.27, 1.9, 4.06, 3.2, c.title, c.body, {
    tag: c.tag, titleSize: 14, bodySize: 10.5,
  }));

  // Authorization model below
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.5, y: 5.3, w: 12.3, h: 1.45, rectRadius: 0.12,
    fill: { color: COLOR.card }, line: { color: COLOR.primary2, width: 0.75 },
  });
  s.addText("AUTHORIZATION  ·  RBAC layered on every request", {
    x: 0.5, y: 5.4, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 9, color: COLOR.primary2, bold: true, align: "center", charSpacing: 4,
  });
  const layers = ["requireUser()", "requireMembership(orgId, role)", "requireRfpAccess(rfpId)", "requireUserOrApiKey(req)"];
  layers.forEach((l, i) => {
    addBox(s, 0.7 + i * 3.05, 5.85, 2.85, 0.7, l, {
      fontSize: 11, fill: COLOR.bgPanel, line: COLOR.cardLine, color: COLOR.fg,
    });
  });

  addFooter(s, page, total);
});

// 10 — Knowledge ingestion pipeline
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Knowledge base", "Ingestion pipeline");

  const steps = [
    { label: "Upload\n(PDF/DOCX/XLSX/MD)", c: COLOR.accent },
    { label: "Parse\n(local or LlamaParse)", c: COLOR.accent },
    { label: "Chunk\n(token-aware splitter)", c: COLOR.primary2 },
    { label: "Embed\n(Xenova MiniLM-L6 · 384-d)", c: COLOR.primary2 },
    { label: "Store\n(KnowledgeIndexChunk)", c: COLOR.primary },
  ];
  const y = 2.4, boxW = 2.1, boxH = 1.0;
  steps.forEach((st, i) => {
    const x = 0.5 + i * 2.55;
    addBox(s, x, y, boxW, boxH, st.label, {
      fill: COLOR.card, line: st.c, lineWidth: 1, fontSize: 10,
    });
    if (i < steps.length - 1) {
      addArrow(s, x + boxW, y + boxH / 2, x + boxW + 0.45, y + boxH / 2, { color: COLOR.muted });
    }
  });

  // Below — properties
  const props = [
    { tag: "RE-INDEX", body: "Background re-embedding when an org changes its embedding model. Failed chunks visible in the UI for retry." },
    { tag: "MULTI-INDEX", body: "Each org can have N indexes. Projects pick a default index; questions can override per-generation." },
    { tag: "VIEWER", body: "Inline document + chunk viewer. Sources cited in answers link straight to the chunk on the source page." },
    { tag: "PROVIDERS", body: "In-process transformers.js (default), or any OpenAI-compatible embedding endpoint (Ollama nomic-embed-text, OpenAI text-embedding-3, etc.)" },
  ];
  props.forEach((p, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    addCard(s, 0.5 + col * 6.4, 4.0 + row * 1.35, 6.1, 1.2, p.tag, p.body, { titleSize: 12 });
  });

  addFooter(s, page, total);
});

// 11 — 2-stage question extraction
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Question extraction", "Two LLM passes, never miss a question");

  // Stage flow diagram
  addBox(s, 0.5, 2.1, 2.4, 1.0, "Raw RFP text\n(post-parse)", { fill: COLOR.card, line: COLOR.accent, lineWidth: 1, fontSize: 11 });
  addArrow(s, 2.95, 2.6, 3.4, 2.6);
  addBox(s, 3.4, 2.1, 2.7, 1.0, "Section-aware\nbatching (12 KB)", { fill: COLOR.card, line: COLOR.primary2, lineWidth: 1, fontSize: 11 });
  addArrow(s, 6.15, 2.6, 6.6, 2.6);
  addBox(s, 6.6, 2.1, 3.1, 1.0, "Stage 1: extract\n(parallel, max 3 in-flight)", { fill: COLOR.card, line: COLOR.primary2, lineWidth: 1, fontSize: 11 });
  addArrow(s, 9.75, 2.6, 10.2, 2.6);
  addBox(s, 10.2, 2.1, 2.6, 1.0, "Stage 2: judge\neligibility", { fill: COLOR.card, line: COLOR.warn, lineWidth: 1, fontSize: 11 });

  // Stage 1 metadata produced
  addCard(s, 0.5, 3.55, 6.1, 1.6, "Stage 1 produces per question",
    ["number (e.g. \"3.2.1\" → 321)", "section (heading)", "text (verbatim)", "requirement_type: must · should · may · info", "complexity: simple · moderate · complex", "topic + what_is_asked"],
    { tag: "EXTRACT", titleSize: 12, bodySize: 10 });

  // Stage 2 metadata
  addCard(s, 6.7, 3.55, 6.1, 1.6, "Stage 2 adds eligibility",
    ["answerable — vendor's standard knowledge base", "needs_info — customer-specific (pricing for N seats)", "out_of_scope — submission rules, evaluation criteria", "+ confidence (0..1) per classification"],
    { tag: "TRIAGE", titleSize: 12, bodySize: 10, tagColor: COLOR.warn });

  // Resilience
  addCard(s, 0.5, 5.3, 12.3, 1.4, "Resilience built in",
    ["Stage-2 failure does NOT block the run — falls back to defaults; question still ships", "Per-batch isolation — one bad batch doesn't kill the rest", "Global renumbering after merge — preserved when source has dotted numbering", "Telemetry: byComplexity + byEligibility logged to activity feed"],
    { tag: "FALLBACK", titleSize: 12, bodySize: 10, tagColor: COLOR.good });

  addFooter(s, page, total);
});

// 12 — Hybrid retrieval
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Hybrid retrieval", "BM25 + dense + RRF + optional LLM rerank");

  // Pipeline flow
  addBox(s, 0.5,  2.2, 2.0, 0.8, "Query\n(question)", { fill: COLOR.card, line: COLOR.accent, lineWidth: 1, fontSize: 10 });
  addArrow(s, 2.55, 2.6, 2.95, 2.6);
  addBox(s, 2.95, 1.8, 2.5, 0.7, "BM25\n(sparse)", { fill: COLOR.card, line: COLOR.primary2, lineWidth: 1, fontSize: 10 });
  addBox(s, 2.95, 2.7, 2.5, 0.7, "Dense\n(cosine, 384-d)", { fill: COLOR.card, line: COLOR.primary2, lineWidth: 1, fontSize: 10 });
  addArrow(s, 5.5, 2.15, 5.9, 2.6);
  addArrow(s, 5.5, 3.05, 5.9, 2.6);
  addBox(s, 5.9, 2.2, 2.4, 0.8, "RRF fusion\n(k = 60)", { fill: COLOR.card, line: COLOR.primary, lineWidth: 1, fontSize: 10 });
  addArrow(s, 8.35, 2.6, 8.75, 2.6);
  addBox(s, 8.75, 2.2, 2.4, 0.8, "LLM rerank\n(top-K, optional)", { fill: COLOR.card, line: COLOR.warn, lineWidth: 1, fontSize: 10 });
  addArrow(s, 11.2, 2.6, 11.6, 2.6);
  addBox(s, 11.6, 2.2, 1.7, 0.8, "Top sources\n→ generator", { fill: COLOR.card, line: COLOR.good, lineWidth: 1, fontSize: 10 });

  // Why this beats pure-dense
  addCard(s, 0.5, 3.55, 6.1, 3.1, "Why hybrid",
    ["Pure dense misses exact-match keywords (e.g. SOC 2 Type II, ISO 27001-2022)", "Pure BM25 misses paraphrases and concept matches", "RRF fusion blends both with no tuning of relative weights", "LLM rerank applied selectively (single answers, skipped for bulk to keep latency down)", "Works on plain Postgres — no pgvector required"],
    { tag: "DESIGN", titleSize: 13, bodySize: 10.5 });

  addCard(s, 6.7, 3.55, 6.1, 3.1, "Configurable per call",
    ["topK (final cut)", "candidatePool (RRF input width)", "rerank: on/off", "indexId (which KB to search)", "Per-org default index, per-RFP override", "Outcome boost: golden answers from WON RFPs float up; LOST get coaching note"],
    { tag: "KNOBS", titleSize: 13, bodySize: 10.5, tagColor: COLOR.warn });

  addFooter(s, page, total);
});

// 13 — Response generation pipeline
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Response generation", "Streaming · multi-step · grounded");

  // Vertical step list
  const steps = [
    { n: "01", t: "Analyze",          d: "Extract core ask, sub-questions, search queries (LLM)" },
    { n: "02", t: "Retrieve",         d: "Hybrid retrieval over chosen KB index" },
    { n: "03", t: "Pull goldens",     d: "Top-3 golden answers (boosted by RFP outcome)" },
    { n: "04", t: "Tool calls",       d: "Optional: calculator · web fetch · custom org tools" },
    { n: "05", t: "Synthesize",       d: "Cited answer with [Source N] tags · streamed via SSE" },
    { n: "06", t: "Score grounding",  d: "Second LLM-judge pass on every claim → groundingScore" },
    { n: "07", t: "Confidence + flag", d: "Heuristic + LLM judge → needsReview if < 0.6" },
  ];
  steps.forEach((it, i) => {
    const y = 1.95 + i * 0.66;
    s.addShape(pres.ShapeType.roundRect, {
      x: 0.5, y, w: 0.85, h: 0.55, rectRadius: 0.1,
      fill: { color: COLOR.primary }, line: { type: "none" },
    });
    s.addText(it.n, {
      x: 0.5, y, w: 0.85, h: 0.55,
      fontFace: FONT, fontSize: 14, color: COLOR.fg, bold: true, align: "center", valign: "middle",
    });
    s.addText(it.t, {
      x: 1.55, y, w: 3.0, h: 0.55,
      fontFace: FONT, fontSize: 13, color: COLOR.fg, bold: true, valign: "middle",
    });
    s.addText(it.d, {
      x: 4.7, y, w: 8.0, h: 0.55,
      fontFace: FONT, fontSize: 11, color: COLOR.muted, valign: "middle",
    });
  });

  s.addText("Every step emits an SSE event — UI shows live progress (analyze → retrieve → synthesize → done) with intermediate token streaming.", {
    x: 0.5, y: 6.7, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 11, color: COLOR.primary2, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 14 — Pipeline engine
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Pipeline engine", "Configurable orchestration with human-in-the-loop");

  // States diagram
  const states = [
    { x: 0.5, label: "PENDING", c: COLOR.muted },
    { x: 2.3, label: "RUNNING", c: COLOR.accent },
    { x: 4.1, label: "WAITING\nFOR INPUT", c: COLOR.warn },
    { x: 5.9, label: "PAUSED", c: COLOR.primary2 },
    { x: 7.7, label: "STOPPED", c: COLOR.bad },
    { x: 9.5, label: "SUCCEEDED", c: COLOR.good },
    { x: 11.3, label: "FAILED", c: COLOR.bad },
  ];
  const y = 1.95, boxW = 1.6, boxH = 0.7;
  states.forEach((st) => {
    addBox(s, st.x, y, boxW, boxH, st.label, {
      fill: COLOR.card, line: st.c, lineWidth: 1, fontSize: 10, color: st.c, bold: true,
    });
  });

  // Step kinds
  addCard(s, 0.5, 2.95, 4.0, 3.4, "Step kinds",
    [
      "PARSE_DOCUMENT",
      "EXTRACT_QUESTIONS",
      "ASSIGN_SMES",
      "GENERATE_RESPONSES",
      "REVIEW_QUEUE",
      "EXPORT",
      "WEBHOOK · CUSTOM_TASK",
      "MINE_TO_KB · COORDINATE_AE",
    ],
    { tag: "KINDS", titleSize: 12, bodySize: 10 });

  // Step modes
  addCard(s, 4.65, 2.95, 4.0, 3.4, "Step modes",
    [
      "AUTO — engine advances without prompting",
      "MANUAL — waits for a human to mark complete",
      "DECISION — explicit human confirm before running irreversible work (e.g. full bulk generation)",
      "Editable mid-flight when paused",
    ],
    { tag: "MODES", titleSize: 12, bodySize: 10, tagColor: COLOR.primary2 });

  // Pause/Resume
  addCard(s, 8.8, 2.95, 4.0, 3.4, "Pause · Resume · Edit",
    [
      "Pause from RUNNING / WAITING — records who, when, why",
      "While paused: edit step config / mode / label",
      "Skip a step or reset a completed one",
      "Resume re-enters advance() seamlessly",
      "Stop is terminal (no resume)",
      "Every transition audited",
    ],
    { tag: "CONTROL", titleSize: 12, bodySize: 10, tagColor: COLOR.good });

  addFooter(s, page, total);
});

// 15 — Multi-document RFP package
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Multi-document packages", "Real RFPs come as bundles");

  // Diagram: primary RFP + attachments
  const primaryX = 5.0, primaryY = 2.0;
  addBox(s, primaryX, primaryY, 3.3, 1.1, "PRIMARY RFP\n(carries questions + responses)", {
    fill: COLOR.card, line: COLOR.primary, lineWidth: 1.5, fontSize: 12, bold: true,
  });

  const atts = [
    { x: 0.5,  label: "ADDENDUM", c: COLOR.accent },
    { x: 4.1,  label: "PRICING_MATRIX\n(Excel)", c: COLOR.warn },
    { x: 7.85, label: "SECURITY_QUESTIONNAIRE", c: COLOR.primary2 },
    { x: 11.5, label: "REFERENCE", c: COLOR.muted },
  ];
  atts.forEach((a) => {
    addBox(s, a.x, 4.0, 1.7, 0.85, a.label, { fill: COLOR.card, line: a.c, lineWidth: 1, fontSize: 9 });
    addArrow(s, a.x + 0.85, 4.0, primaryX + 1.65, primaryY + 1.1, { color: a.c });
  });

  // Bottom panel
  addCard(s, 0.5, 5.15, 6.1, 1.6, "Generation prompt is enriched",
    ["Primary's rawText drives questions", "Each attachment's first ~1500 chars added as labeled context block (ADDENDUM:, PRICING_MATRIX: ...)", "Cited as [Source-{role}] in answers"],
    { tag: "CONTEXT", titleSize: 12, bodySize: 10 });

  addCard(s, 6.7, 5.15, 6.1, 1.6, "Cross-reference detection",
    ["Heuristic keyword match between primary questions and attachment text", "UI badge: \"Also in: SECURITY_QUESTIONNAIRE Q14\"", "Helps reviewers spot duplicate / overlapping asks"],
    { tag: "LINKS", titleSize: 12, bodySize: 10, tagColor: COLOR.primary2 });

  addFooter(s, page, total);
});

// 16 — Hallucination grounding
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Hallucination grounding", "Every answer scored claim-by-claim");

  // Flow
  addBox(s, 0.5, 2.1, 2.6, 0.9, "Generated answer\n+ cited sources", { fill: COLOR.card, line: COLOR.accent, lineWidth: 1, fontSize: 10 });
  addArrow(s, 3.15, 2.55, 3.55, 2.55);
  addBox(s, 3.55, 2.1, 2.8, 0.9, "LLM judge prompt\n(answer + sources)", { fill: COLOR.card, line: COLOR.primary2, lineWidth: 1, fontSize: 10 });
  addArrow(s, 6.4, 2.55, 6.8, 2.55);
  addBox(s, 6.8, 2.1, 2.8, 0.9, "Per-claim verdict\nsupported · weak · unsupported", { fill: COLOR.card, line: COLOR.primary2, lineWidth: 1, fontSize: 10 });
  addArrow(s, 9.65, 2.55, 10.05, 2.55);
  addBox(s, 10.05, 2.1, 2.8, 0.9, "Score formula\n(supp + 0.5·weak) / total", { fill: COLOR.card, line: COLOR.warn, lineWidth: 1, fontSize: 10 });

  // Tier badges
  s.addText("BADGE TIERS", {
    x: 0.5, y: 3.4, w: 12.3, h: 0.3,
    fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 4,
  });
  const tiers = [
    { label: "≥ 0.9   GREEN", desc: "Almost every claim has direct evidence — safe to ship", c: COLOR.good },
    { label: "0.6 – 0.9   YELLOW", desc: "Some weak / inferred claims — reviewer should glance", c: COLOR.warn },
    { label: "< 0.6   RED", desc: "Auto-flagged needsReview = true; surfaced in UI + insights", c: COLOR.bad },
  ];
  tiers.forEach((t, i) => {
    const y = 3.85 + i * 0.7;
    addBox(s, 0.5, y, 3.2, 0.55, t.label, { fill: COLOR.card, line: t.c, lineWidth: 1, fontSize: 11, bold: true, color: t.c });
    s.addText(t.desc, {
      x: 3.85, y, w: 9.0, h: 0.55,
      fontFace: FONT, fontSize: 11, color: COLOR.muted, valign: "middle",
    });
  });

  addCard(s, 0.5, 6.0, 12.3, 0.85, "Non-blocking by design",
    ["Grounding failure never fails the response — answer still ships, badge shows \"Not graded\" with a manual Re-score link", "Re-score endpoint lets reviewers re-run the judge after editing the answer"],
    { tag: "RESILIENCE", titleSize: 11, bodySize: 9.5, tagColor: COLOR.good });

  addFooter(s, page, total);
});

// 17 — Win/loss feedback loop
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Win/loss feedback loop", "Outcomes feed back into retrieval");

  // Flow diagram
  addBox(s, 0.5, 2.1, 2.4, 0.85, "RFP submitted", { fill: COLOR.card, line: COLOR.accent, lineWidth: 1, fontSize: 11 });
  addArrow(s, 2.95, 2.55, 3.35, 2.55);
  addBox(s, 3.35, 2.1, 2.4, 0.85, "Outcome tagged\nWON · LOST · WITHDRAWN · NO_BID", { fill: COLOR.card, line: COLOR.primary2, lineWidth: 1, fontSize: 10 });
  addArrow(s, 5.8, 2.55, 6.2, 2.55);
  addBox(s, 6.2, 2.1, 2.4, 0.85, "Audit row written\n+ activity feed event", { fill: COLOR.card, line: COLOR.primary, lineWidth: 1, fontSize: 10 });
  addArrow(s, 8.65, 2.55, 9.05, 2.55);
  addBox(s, 9.05, 2.1, 2.4, 0.85, "Future generations\nsearch w/ outcome boost", { fill: COLOR.card, line: COLOR.good, lineWidth: 1, fontSize: 10 });

  // Boost mechanics
  addCard(s, 0.5, 3.4, 6.1, 1.7, "Boost mechanics",
    ["WON-tied golden answer  → +0.20 score boost (configurable via OUTCOME_BOOST_WON)", "LOST-tied golden answer  → −0.20 demotion + coaching note injected into prompt", "Cached per-generation — single DB lookup per golden, even reused across questions"],
    { tag: "WEIGHTS", titleSize: 12, bodySize: 10 });

  // Coaching prompt example
  addCard(s, 6.7, 3.4, 6.1, 1.7, "Coaching note (auto-prepended)",
    ["\"This question's prior answer (RFP X, lost) was: ...", "Avoid repeating any errors of style or substance from that prior submission.\"", "Surfaces in /dashboard/insights as Win Rate (90d) + outcome distribution"],
    { tag: "COACHING", titleSize: 12, bodySize: 10, tagColor: COLOR.bad });

  // UI chip
  s.addText("UI: outcome chip in RFP header — green WON · red LOST (with coaching label) · grey WITHDRAWN/NO_BID · muted PENDING", {
    x: 0.5, y: 5.4, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 11, color: COLOR.fg, italic: true, align: "center",
  });

  // Insights surfacing
  addCard(s, 0.5, 5.95, 12.3, 0.85, "Insights dashboard cards",
    ["Win rate (90d) · Won count · Lost count · Stacked horizontal bar of outcome distribution"],
    { tag: "ANALYTICS", titleSize: 11, bodySize: 9.5, tagColor: COLOR.accent });

  addFooter(s, page, total);
});

// 18 — Tools registry
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Tools registry", "What the model can call mid-answer");

  const tools = [
    { name: "knowledge_search",     desc: "Hybrid search over the org's knowledge base" },
    { name: "calculator",           desc: "Safe arithmetic for compliance/pricing math" },
    { name: "url_fetch",            desc: "Pull a public URL for citation context" },
    { name: "html_summarize",       desc: "Summarize a fetched page into a few sentences" },
    { name: "web_search",           desc: "Provider-agnostic web search adapter" },
    { name: "current_time",         desc: "Resolves to org timezone (e.g. for SLA calcs)" },
    { name: "currency_convert",     desc: "Live FX conversion for pricing-matrix questions" },
    { name: "compliance_lookup",    desc: "Cite the matching SOC2 / ISO / HIPAA control" },
    { name: "list_team_members",    desc: "For 'who is responsible for X' questions" },
    { name: "company_facts",        desc: "Static org facts (HQ, founding year, employee count)" },
    { name: "contact_lookup",       desc: "Resolves a contact role (e.g. \"security@\") to a name" },
  ];

  tools.forEach((t, i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = 0.5 + col * 4.27;
    const y = 1.95 + row * 1.1;
    addCard(s, x, y, 4.06, 1.0, t.name, t.desc, { titleSize: 12, bodySize: 9.5 });
  });

  s.addText("Tools are per-org togglable from Settings → Tools. Custom tools can be added by extending the registry.", {
    x: 0.5, y: 6.55, w: 12.3, h: 0.4,
    fontFace: FONT, fontSize: 11, color: COLOR.muted, italic: true, align: "center",
  });

  addFooter(s, page, total);
});

// 19 — AI provider flexibility (Ollama-first)
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "AI provider flexibility", "Bring your own LLM — local-first defaults");

  const providers = [
    { tag: "RECOMMENDED FOR DEV", title: "Ollama", body: "http://localhost:11434/v1 · llama3.2 / qwen2.5 / mistral · zero-config local · no API key needed", c: COLOR.good },
    { tag: "MANAGED CLOUD",        title: "OpenRouter", body: "300+ models behind one API · free tier available · most cost-efficient for production", c: COLOR.primary2 },
    { tag: "ENTERPRISE CLOUD",     title: "OpenAI",   body: "GPT-4o · GPT-4o-mini · text-embedding-3 · the safe default for procurement-grade quality", c: COLOR.accent },
    { tag: "SELF-HOSTED",          title: "vLLM · LM Studio · LocalAI · Custom", body: "Any OpenAI-compatible endpoint works · per-org baseURL + apiKey · per-org model picker", c: COLOR.warn },
  ];
  providers.forEach((p, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    addCard(s, 0.5 + col * 6.4, 1.95 + row * 1.85, 6.1, 1.65, p.title, p.body, { tag: p.tag, tagColor: p.c, titleSize: 14 });
  });

  addCard(s, 0.5, 5.7, 12.3, 1.05, "Configuration",
    ["Per-org via /dashboard/settings · provider picker · live model dropdown via /api/tags (Ollama) or /v1/models (OpenAI)", "API keys encrypted at rest (AES-256-GCM, versioned, KEY_ROTATION_SECRET fallback for zero-downtime rotation)"],
    { tag: "CONTROL", titleSize: 12, bodySize: 10 });

  addFooter(s, page, total);
});

// 20 — Production hardening
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Production hardening", "Day-one ready");

  const cards = [
    { tag: "PACKAGING",  title: "Docker", body: ["Multi-stage build · non-root nodejs:1001", "dumb-init · HEALTHCHECK · standalone bundle", "docker-compose: Postgres + Mailpit + Grafana"] },
    { tag: "SECRETS",    title: "Encryption + rotation", body: ["AES-256-GCM at rest, versioned (v2:)", "KEY_ROTATION_SECRET fallback", "Re-encrypt CLI script · UI rotate flow"] },
    { tag: "RATE-LIMIT", title: "Token bucket + breaker", body: ["Memory backend default · Redis adapter (Lua)", "Retry-After + JSON envelope", "Per-provider circuit breaker (LLM only)"] },
    { tag: "AUDIT",      title: "AuditLog", body: ["Sign-in · key set · key rotated · role change", "RFP delete · export · pipeline transitions", "Admin viewer at /audit-log"] },
    { tag: "WEBHOOKS",   title: "HMAC signing", body: ["X-AutoRFP-Signature: t=...,v1=...", "5-min skew tolerance · constant-time verify", "Replay protection"] },
    { tag: "AUTH",       title: "Multi-method", body: ["Magic-link · Google · GitHub · Microsoft Entra", "Bearer API keys (READ/WRITE/ADMIN)", "Dev shortcut for local boxes"] },
  ];
  cards.forEach((c, i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    addCard(s, 0.5 + col * 4.27, 1.95 + row * 2.4, 4.06, 2.2, c.title, c.body, { tag: c.tag, titleSize: 13, bodySize: 9.5 });
  });

  addFooter(s, page, total);
});

// 21 — Observability
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Observability", "Logs · metrics · audit · in-app insights");

  // Three pillars
  const cols = [
    { tag: "LOGS",       title: "Pino + AsyncLocalStorage", body: ["Structured JSON in prod", "Pretty-print in dev", "reqId · userId · orgId on every line", "Auto-tagged via withApiHandler"] },
    { tag: "METRICS",    title: "Prometheus /api/metrics",  body: ["http_requests_total", "http_request_duration_ms", "rate_limit_hits_total", "circuit_breaker_state", "llm_requests_total + tokens", "responses_confidence + grounding_score", "pipeline_steps_total · rfp_outcomes_total"] },
    { tag: "AUDIT",      title: "AuditLog model",          body: ["Sensitive ops only (sign-in, key changes, member changes, deletes, exports)", "Indexed by (org, ts) · (actor, ts) · (event, ts)", "Admin viewer with cursor pagination"] },
    { tag: "INSIGHTS",   title: "/dashboard/insights",     body: ["Org-scoped · 9 cards + 3 charts", "Questions answered · avg confidence · TTR", "Win rate · grounded % · avg docs/RFP", "Throughput-by-day · confidence histogram"] },
  ];
  cols.forEach((c, i) => addCard(s, 0.5 + i * 3.2, 1.95, 3.0, 4.6, c.title, c.body, {
    tag: c.tag, titleSize: 13, bodySize: 9.5,
  }));

  addCard(s, 0.5, 6.7, 12.3, 0.55, "ops/grafana — pre-provisioned dashboards · ops/prometheus — scrape config · `--profile observability` enables stack",
    null, { titleSize: 11, bg: COLOR.bgPanel });

  addFooter(s, page, total);
});

// 22 — UI surface tour
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "UI surface", "Where humans interact");

  const pages = [
    { route: "/dashboard",                  desc: "Org overview · recent activity · in-flight RFPs" },
    { route: "/dashboard/projects",         desc: "Group RFPs by deal · per-project default pipeline + KB index" },
    { route: "/dashboard/rfps/[rfpId]",     desc: "RFP viewer · question table · responses · pipeline panel · documents tab" },
    { route: "/dashboard/pipelines",        desc: "Template editor · run history · DECISION inbox" },
    { route: "/dashboard/indexes",          desc: "Knowledge base management · upload · re-index · viewer" },
    { route: "/dashboard/golden",           desc: "Golden answer library · auto-curated from approved responses" },
    { route: "/dashboard/chat",             desc: "Chat with the KB · scoped to RFP / index / project" },
    { route: "/dashboard/tools",            desc: "Per-org tool toggles" },
    { route: "/dashboard/insights",         desc: "Org analytics · cards + charts · grounding + win-rate" },
    { route: "/dashboard/members",          desc: "Invite · role management · audit log viewer" },
    { route: "/dashboard/settings",         desc: "AI config (provider picker) · API keys · webhooks · rotate keys" },
  ];
  pages.forEach((p, i) => {
    const y = 1.95 + i * 0.42;
    s.addText(p.route, {
      x: 0.5, y, w: 4.5, h: 0.4,
      fontFace: "Consolas", fontSize: 11, color: COLOR.primary2, valign: "middle",
    });
    s.addText(p.desc, {
      x: 5.2, y, w: 7.6, h: 0.4,
      fontFace: FONT, fontSize: 11, color: COLOR.muted, valign: "middle",
    });
  });

  addFooter(s, page, total);
});

// 23 — By the numbers
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "By the numbers", "What's been built so far");

  const stats = [
    { v: "300+",  l: "automated tests", c: COLOR.good },
    { v: "30",    l: "test files", c: COLOR.good },
    { v: "60+",   l: "API routes", c: COLOR.accent },
    { v: "11",    l: "built-in tools", c: COLOR.primary2 },
    { v: "9",     l: "Prometheus metric series", c: COLOR.warn },
    { v: "20+",   l: "Prisma models", c: COLOR.primary },
    { v: "7",     l: "auth methods (3 OAuth + magic + dev + Bearer + webhook HMAC)", c: COLOR.accent },
    { v: "0",     l: "deps with critical CVEs (latest scan)", c: COLOR.good },
  ];
  stats.forEach((r, i) => {
    const col = i % 4;
    const row = Math.floor(i / 4);
    const x = 0.5 + col * 3.2;
    const y = 1.95 + row * 1.95;
    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: 3.0, h: 1.75, rectRadius: 0.12,
      fill: { color: COLOR.card }, line: { color: r.c, width: 1 },
    });
    s.addText(r.v, {
      x: x + 0.2, y: y + 0.15, w: 2.6, h: 1.0,
      fontFace: FONT, fontSize: 36, color: r.c, bold: true,
    });
    s.addText(r.l, {
      x: x + 0.2, y: y + 1.05, w: 2.6, h: 0.65,
      fontFace: FONT, fontSize: 10.5, color: COLOR.muted,
    });
  });

  addFooter(s, page, total);
});

// 24 — Roadmap
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Roadmap", "What's next");

  const tiers = [
    {
      tag: "TIER A · NEXT", title: "Quality differentiators",
      body: ["Pricing-matrix Excel handler — extract · answer per cell · re-emit", "Model routing — cheap LLM for simple, premium for complex (60% cost cut)", "Semantic answer cache — same question across RFPs returns cached answer"],
      c: COLOR.good,
    },
    {
      tag: "TIER B · LATER", title: "Adoption accelerators",
      body: ["Slack / Salesforce / SharePoint integrations", "Real-time collaborative editing (Yjs / Liveblocks)", "SAML SSO for enterprise procurement", "Stale-source detection (cite a 2023 SOC2? warn)"],
      c: COLOR.accent,
    },
    {
      tag: "TIER C · MOONSHOTS", title: "Category-defining bets",
      body: ["Predictive win scoring — recommend NO_BID before responding", "Auto-extracted evaluation rubric — score in-progress response", "Per-org fine-tuned LoRA on golden answers"],
      c: COLOR.primary2,
    },
  ];
  tiers.forEach((t, i) => {
    addCard(s, 0.5 + i * 4.27, 1.95, 4.06, 4.6, t.title, t.body, {
      tag: t.tag, tagColor: t.c, titleSize: 14, bodySize: 10.5,
    });
  });

  addFooter(s, page, total);
});

// 25 — Closing
slides.push((page, total) => {
  const s = addSlide();
  addTitle(s, "Wrap up", "AutoRFP at a glance");

  s.addText(
    [
      { text: "AutoRFP ", options: { bold: true, color: COLOR.primary2 } },
      { text: "is a production-grade, multi-tenant, AI-first RFP response platform designed to be self-hostable, observable, and bring-your-own-LLM from day one.", options: { color: COLOR.fg } },
    ],
    { x: 0.5, y: 1.85, w: 12.3, h: 0.9, fontFace: FONT, fontSize: 16 },
  );

  const pillars = [
    { tag: "QUALITY",  t: "Cited · grounded · scored", c: COLOR.primary2 },
    { tag: "SPEED",    t: "Streaming · parallel · cached", c: COLOR.accent },
    { tag: "CONTROL",  t: "Pause · edit · resume", c: COLOR.good },
    { tag: "OPS",      t: "Encrypted · audited · metered", c: COLOR.warn },
  ];
  pillars.forEach((p, i) => {
    const x = 0.5 + i * 3.2;
    s.addShape(pres.ShapeType.roundRect, {
      x, y: 3.0, w: 3.0, h: 1.5, rectRadius: 0.12,
      fill: { color: COLOR.card }, line: { color: p.c, width: 1 },
    });
    s.addText(p.tag, {
      x, y: 3.15, w: 3.0, h: 0.3,
      fontFace: FONT, fontSize: 10, color: p.c, bold: true, align: "center", charSpacing: 4,
    });
    s.addText(p.t, {
      x, y: 3.5, w: 3.0, h: 0.85,
      fontFace: FONT, fontSize: 14, color: COLOR.fg, bold: true, align: "center", valign: "middle",
    });
  });

  s.addText("Built with engineering rigor. Deployed in minutes. Evolves with your knowledge base.", {
    x: 0.5, y: 5.0, w: 12.3, h: 0.5,
    fontFace: FONT, fontSize: 13, color: COLOR.muted, italic: true, align: "center",
  });

  s.addText("Thank you.", {
    x: 0.5, y: 5.8, w: 12.3, h: 0.8,
    fontFace: FONT, fontSize: 28, color: COLOR.primary2, bold: true, align: "center",
  });

  addFooter(s, page, total);
});

// ---------- Render ----------
const total = slides.length;
slides.forEach((fn, i) => fn(i + 1, total));

const out = resolve(outDir, "AutoRFP-application.pptx");
await pres.writeFile({ fileName: out });
console.log(`Wrote ${out} (${total} slides)`);
