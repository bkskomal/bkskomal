// Read-only diagnostic — inspects every org's AI config (with secrets masked)
// so we can tell which model the route is actually picking + whether a
// per-org API key is overriding the env default.
//
// Run: node --env-file=.env scripts/inspect-org-ai-config.mjs

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
try {
  const rows = await prisma.orgAiConfig.findMany({
    include: { organization: { select: { name: true, slug: true } } },
  });

  console.log(`Found ${rows.length} OrgAiConfig row(s).\n`);

  function masked(s, label) {
    if (!s) return `${label}: <none>`;
    return `${label}: <set, ${s.length} chars>`;
  }

  for (const r of rows) {
    console.log(`── ${r.organization?.name ?? "?"} (${r.organization?.slug ?? "?"}) ──`);
    console.log(`  LLM:`);
    console.log(`    provider:        ${r.llmProvider ?? "<env>"}`);
    console.log(`    baseUrl:         ${r.llmBaseUrl ?? "<env>"}`);
    console.log(`    model:           ${r.llmModel ?? "<env>"}`);
    console.log(`    ${masked(r.llmApiKeyEncrypted, "apiKey (encrypted)")}`);
    console.log(`  Extraction (Phase A.2):`);
    console.log(`    model:           ${r.extractionModel ?? "<falls back to LLM>"}`);
    console.log(`    promptOverride:  ${r.extractionPromptOverride ? "<custom>" : "<built-in>"}`);
    console.log(`    eligibility:     ${r.extractionEligibilityEnabled ?? "<default true>"}`);
    console.log(`  Generation (Phase A.4):`);
    console.log(`    pinnedModel:     ${r.generationModel ?? "<falls back to routing>"}`);
    console.log(`    groundingEnabled:${r.groundingEnabled ?? "<default true>"}`);
    console.log(`  Routing (Phase 3B):`);
    console.log(`    enabled:         ${r.routingEnabled}`);
    console.log(`    simple:          ${r.llmModelSimple ?? "<none>"}`);
    console.log(`    complex:         ${r.llmModelComplex ?? "<none>"}`);
    console.log("");
  }
} finally {
  await prisma.$disconnect();
}
