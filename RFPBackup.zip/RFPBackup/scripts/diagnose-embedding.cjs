// Inspect every org's embedding config to find the misconfigured one(s).
const { Client } = require("pg");

(async () => {
  const c = new Client({
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: process.env.PGPASSWORD,
    database: "autorfp",
  });
  await c.connect();

  const orgs = await c.query(`
    SELECT
      o.id, o.name, o.slug,
      cfg."embeddingBaseUrl",
      cfg."embeddingModel",
      cfg."embeddingDimensions",
      cfg."embeddingProvider",
      (SELECT COUNT(*) FROM "Document" d
       INNER JOIN "KnowledgeIndex" k ON k.id = d."indexId"
       WHERE k."organizationId" = o.id AND d.status = 'FAILED') AS failed_docs
    FROM "Organization" o
    LEFT JOIN "OrgAiConfig" cfg ON cfg."organizationId" = o.id
    ORDER BY o."createdAt"
  `);

  console.log("All orgs and their embedding config:");
  for (const r of orgs.rows) {
    console.log(
      `  ${r.slug.padEnd(25)} url=${r.embeddingBaseUrl ?? "(env default)"} ` +
      `model=${r.embeddingModel ?? "(env)"} failed_docs=${r.failed_docs}`,
    );
  }
  await c.end();
})();
