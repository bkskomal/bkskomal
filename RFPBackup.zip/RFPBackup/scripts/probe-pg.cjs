const { Client } = require("pg");

const password = process.env.PGPASSWORD;
if (!password) {
  console.error("Set PGPASSWORD env var");
  process.exit(1);
}

(async () => {
  const c = new Client({
    host: "localhost",
    port: 5432,
    user: "postgres",
    password,
    database: "postgres",
    connectionTimeoutMillis: 3000,
  });
  try {
    await c.connect();
    const v = await c.query("SELECT version()");
    const ext = await c.query(
      "SELECT name, default_version, installed_version FROM pg_available_extensions WHERE name IN ('vector','pgcrypto') ORDER BY name",
    );
    const dbs = await c.query(
      "SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname",
    );
    console.log("OK");
    console.log("version:", v.rows[0].version.split(",")[0]);
    console.log("extensions:");
    for (const r of ext.rows) {
      console.log(`  ${r.name}: available=${r.default_version} installed=${r.installed_version ?? "no"}`);
    }
    console.log("databases:", dbs.rows.map((r) => r.datname).join(", "));
    await c.end();
  } catch (e) {
    console.error("FAIL:", e.message);
    process.exit(2);
  }
})();
