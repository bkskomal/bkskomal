// One-slide head-to-head: AutoRFP vs Reference RFP.
// Run: `node scripts/generate-comparison-slide.mjs` → docs/AutoRFP-vs-reference.pptx

import PptxGenJS from "pptxgenjs";
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";

const COLOR = {
  bg: "0B0716",
  fg: "F4F1FA",
  muted: "9C9BB0",
  primary: "8A2BE2",
  primary2: "D946EF",
  accent: "38BDF8",
  good: "10B981",
  warn: "F59E0B",
  bad: "EF4444",
  card: "1A1530",
  cardLine: "2B2440",
};
const FONT = "Calibri";

const outDir = resolve("./docs");
mkdirSync(outDir, { recursive: true });

const pres = new PptxGenJS();
pres.layout = "LAYOUT_WIDE";
pres.title = "AutoRFP vs Reference — Head-to-Head";
pres.author = "AutoRFP";

const W = 13.33;
const H = 7.5;
const s = pres.addSlide();
s.background = { color: COLOR.bg };

s.addShape(pres.ShapeType.rect, { x: 0, y: 0, w: W, h: 0.08, fill: { color: COLOR.primary }, line: { type: "none" } });
s.addShape(pres.ShapeType.rect, { x: W * 0.4, y: 0, w: W * 0.6, h: 0.08, fill: { color: COLOR.primary2 }, line: { type: "none" } });
s.addShape(pres.ShapeType.ellipse, { x: -2, y: -1.5, w: 5, h: 5, fill: { color: COLOR.primary, transparency: 90 }, line: { type: "none" } });
s.addShape(pres.ShapeType.ellipse, { x: W - 3, y: H - 3, w: 5, h: 5, fill: { color: COLOR.primary2, transparency: 92 }, line: { type: "none" } });

s.addText("COMPETITIVE COMPARISON", { x: 0.5, y: 0.35, w: 12, h: 0.3, fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 6 });
s.addText("AutoRFP vs Reference RFP — Head-to-Head", { x: 0.5, y: 0.7, w: 12, h: 0.7, fontFace: FONT, fontSize: 28, color: COLOR.fg, bold: true });
s.addText("Independent audit across 5 dimensions · production-ready scoring", { x: 0.5, y: 1.35, w: 12, h: 0.35, fontFace: FONT, fontSize: 12, color: COLOR.muted });

// ---------- LEFT: scoring panel ----------
const leftX = 0.5;
const leftY = 1.9;
const leftW = 6.0;
const leftH = 4.7;
s.addShape(pres.ShapeType.roundRect, {
  x: leftX, y: leftY, w: leftW, h: leftH,
  fill: { color: COLOR.card }, line: { color: COLOR.cardLine, width: 0.5 }, rectRadius: 0.12,
});

s.addText("Scorecard (out of 10)", { x: leftX + 0.25, y: leftY + 0.18, w: leftW - 0.5, h: 0.35, fontFace: FONT, fontSize: 14, color: COLOR.fg, bold: true });

// header row
s.addText("Dimension", { x: leftX + 0.25, y: leftY + 0.6, w: 2.6, h: 0.3, fontFace: FONT, fontSize: 10, color: COLOR.muted, bold: true, charSpacing: 3 });
s.addText("AutoRFP", { x: leftX + 2.9, y: leftY + 0.6, w: 1.5, h: 0.3, fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 3, align: "center" });
s.addText("Reference", { x: leftX + 4.4, y: leftY + 0.6, w: 1.4, h: 0.3, fontFace: FONT, fontSize: 10, color: COLOR.muted, bold: true, charSpacing: 3, align: "center" });

const rows = [
  { name: "Output quality", a: 9, b: 7 },
  { name: "Code correctness", a: 9, b: 8 },
  { name: "Architecture", a: 9, b: 8 },
  { name: "Security / prod-ready", a: 9, b: 6 },
  { name: "Overall", a: 9, b: 7, em: true },
];

rows.forEach((r, i) => {
  const y = leftY + 1.0 + i * 0.68;
  s.addText(r.name, {
    x: leftX + 0.25, y, w: 2.5, h: 0.45,
    fontFace: FONT, fontSize: r.em ? 13 : 12, color: r.em ? COLOR.fg : COLOR.muted, bold: !!r.em,
    valign: "middle",
  });

  // AutoRFP bar
  const barX = leftX + 2.85;
  const barW = 1.6;
  s.addShape(pres.ShapeType.roundRect, {
    x: barX, y: y + 0.12, w: barW, h: 0.22,
    fill: { color: COLOR.cardLine }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addShape(pres.ShapeType.roundRect, {
    x: barX, y: y + 0.12, w: barW * (r.a / 10), h: 0.22,
    fill: { color: r.em ? COLOR.primary2 : COLOR.primary }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addText(String(r.a), {
    x: barX + barW + 0.05, y: y + 0.02, w: 0.4, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.fg, bold: true, valign: "middle",
  });

  // Reference bar
  const barX2 = leftX + 4.95;
  s.addShape(pres.ShapeType.roundRect, {
    x: barX2, y: y + 0.12, w: barW * 0.55, h: 0.22,
    fill: { color: COLOR.cardLine }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addShape(pres.ShapeType.roundRect, {
    x: barX2, y: y + 0.12, w: (barW * 0.55) * (r.b / 10), h: 0.22,
    fill: { color: COLOR.muted }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addText(String(r.b), {
    x: barX2 + (barW * 0.55) + 0.05, y: y + 0.02, w: 0.4, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.muted, valign: "middle",
  });
});

// ---------- RIGHT TOP: AutoRFP strengths ----------
const rightX = 6.85;
const rightW = 6.0;
const topY = 1.9;
const topH = 2.25;
s.addShape(pres.ShapeType.roundRect, {
  x: rightX, y: topY, w: rightW, h: topH,
  fill: { color: COLOR.card }, line: { color: COLOR.primary, width: 0.75 }, rectRadius: 0.12,
});
s.addText("AUTORFP · KEY STRENGTHS", {
  x: rightX + 0.25, y: topY + 0.15, w: rightW - 0.5, h: 0.3,
  fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 4,
});
s.addText(
  [
    { text: "Hybrid retrieval (BM25 + dense + RRF + LLM rerank) — robust without pgvector", options: { bullet: { code: "25B8" }, color: COLOR.fg } },
    { text: "2-stage question extraction with LLM eligibility classifier + confidence", options: { bullet: { code: "25B8" }, color: COLOR.fg } },
    { text: "Pipeline engine — AUTO / MANUAL / DECISION modes with visual progress", options: { bullet: { code: "25B8" }, color: COLOR.fg } },
    { text: "Production stack — Docker · health probe · OAuth · rate-limit · circuit breaker · audit log · key rotation", options: { bullet: { code: "25B8" }, color: COLOR.fg } },
    { text: "154 tests · SSE streams · crypto tamper · HMAC replay · breaker states", options: { bullet: { code: "25B8" }, color: COLOR.fg } },
  ],
  {
    x: rightX + 0.25, y: topY + 0.55, w: rightW - 0.5, h: topH - 0.7,
    fontFace: FONT, fontSize: 11, color: COLOR.fg, paraSpaceAfter: 4, valign: "top",
  },
);

// ---------- RIGHT BOTTOM: Decisive advantages ----------
const botY = 4.25;
const botH = 2.35;
s.addShape(pres.ShapeType.roundRect, {
  x: rightX, y: botY, w: rightW, h: botH,
  fill: { color: COLOR.card }, line: { color: COLOR.primary2, width: 0.75 }, rectRadius: 0.12,
});
s.addText("DECISIVE ADVANTAGES OVER REFERENCE", {
  x: rightX + 0.25, y: botY + 0.15, w: rightW - 0.5, h: 0.3,
  fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 4,
});

const advCols = [
  { title: "Rate-limit + breaker", body: "Token bucket + Redis adapter + per-provider breaker. Ref: unmetered LLM calls (cost / DoS risk)." },
  { title: "At-rest encryption", body: "AES-256-GCM, versioned, zero-downtime rotation. Ref: API keys as plain env vars." },
  { title: "Audit trail", body: "AuditLog model + 7 wired events + admin viewer. Ref: none — blocks SOC 2 / GDPR." },
  { title: "Structured logging", body: "Pino + AsyncLocalStorage reqId propagation. Ref: console.log scattered in prod paths." },
];

advCols.forEach((a, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = rightX + 0.25 + col * 2.85;
  const y = botY + 0.55 + row * 0.85;
  s.addText(a.title, {
    x, y, w: 2.7, h: 0.3,
    fontFace: FONT, fontSize: 11, color: COLOR.accent, bold: true,
  });
  s.addText(a.body, {
    x, y: y + 0.28, w: 2.7, h: 0.55,
    fontFace: FONT, fontSize: 9.5, color: COLOR.muted, valign: "top",
  });
});

// ---------- Bottom strip: bottom-line verdict ----------
s.addShape(pres.ShapeType.roundRect, {
  x: 0.5, y: 6.75, w: W - 1.0, h: 0.45,
  fill: { color: "1F1A36" }, line: { color: COLOR.primary2, width: 0.5 }, rectRadius: 0.08,
});
s.addText(
  [
    { text: "BOTTOM LINE  ", options: { color: COLOR.primary2, bold: true, charSpacing: 4 } },
    { text: "AutoRFP leads on every dimension. Biggest moat: production-readiness (+3 vs Reference). Decisive on rate-limiting, secrets management, audit trail, and observability — all blockers Reference has not solved.", options: { color: COLOR.fg } },
  ],
  {
    x: 0.7, y: 6.78, w: W - 1.4, h: 0.4,
    fontFace: FONT, fontSize: 11, valign: "middle",
  },
);

const out = resolve(outDir, "AutoRFP-vs-reference.pptx");
await pres.writeFile({ fileName: out });
console.log("Wrote", out);
