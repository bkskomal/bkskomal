// One-shot probe: runs the live scraper against a URL and dumps image stats.
// Usage: pnpm exec tsx scripts/probe-scrape.mjs <url>
import { scrapeUrl } from "../src/lib/scraper/url-scraper.ts";

const url = process.argv[2] ?? "https://www.godhascome.com/";
console.log(`> scraping ${url}`);
const t0 = Date.now();
const r = await scrapeUrl(url, { respectRobots: false, maxImages: 100 });
console.log(`  title:    ${r.title}`);
console.log(`  bytes:    ${r.fetchedBytes}`);
console.log(`  images:   ${r.images.length}`);
console.log(`  warnings: ${r.warnings.length}`);
r.warnings.forEach((w) => console.log(`    ! ${w.code}: ${w.message.slice(0, 120)}`));
const byRole = {};
for (const img of r.images) byRole[img.role] = (byRole[img.role] ?? 0) + 1;
console.log(`  by role:  ${JSON.stringify(byRole)}`);
r.images.slice(0, 15).forEach((i, n) => console.log(`    [${n}] ${i.role.padEnd(8)} ${i.url}`));
console.log(`  elapsed:  ${Date.now() - t0}ms`);
