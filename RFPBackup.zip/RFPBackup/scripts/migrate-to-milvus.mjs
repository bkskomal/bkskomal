#!/usr/bin/env node
// Backfill an org's Postgres-stored DocumentChunk embeddings into Milvus.
//
// Usage:
//   node scripts/migrate-to-milvus.mjs --org <orgId> [--index <indexId>] \
//        [--batch 200] [--dry-run]
//
// Mirrors the logic in `src/lib/ai/vector/backfill.ts` — the route at
// /api/orgs/:orgId/vector/migrate calls that helper directly; this script is
// the same shape rewritten in plain ESM so it can run under `node` without a
// TypeScript loader. Keep the two in sync when changing batching/skip rules.
//
// Flow:
//   1. Read OrgAiConfig → resolve milvusUri/token/collection/isolation.
//   2. Lazy-import @zilliz/milvus2-sdk-node and instantiate a client.
//   3. Ensure the per-org collection / partition + indexes exist (skipped on
//      --dry-run).
//   4. Cursor-paginate DocumentChunk in batches of `--batch`, scoped to the
//      org (and optionally one index).
//   5. Skip empty embeddings; insert the rest.
//   6. Print { scanned, written, errors }.
//   7. On a clean non-dry run with at least one write, stamp
//      `vectorMigratedAt = now()` so the UI badge flips.

import process from "node:process";
import {
  createDecipheriv,
  createHash,
} from "node:crypto";
import { PrismaClient } from "@prisma/client";

// --- Args -------------------------------------------------------------------

const args = parseArgs(process.argv.slice(2));
if (!args.org) {
  console.error("usage: node scripts/migrate-to-milvus.mjs --org <orgId> [--index <id>] [--batch 200] [--dry-run]");
  process.exit(2);
}

const ORG_ID = args.org;
const INDEX_ID = args.index ?? null;
const BATCH = Number(args.batch ?? 200);
const DRY_RUN = Boolean(args["dry-run"]);

if (!Number.isFinite(BATCH) || BATCH <= 0 || BATCH > 1000) {
  console.error(`--batch must be 1..1000 (got ${args.batch})`);
  process.exit(2);
}

// --- Crypto (mirrors src/lib/crypto.ts decrypt) -----------------------------

const AUTH_SECRET = process.env.AUTH_SECRET;
const ROTATION_SECRET = process.env.KEY_ROTATION_SECRET;
if (!AUTH_SECRET) {
  console.error("AUTH_SECRET is required to decrypt the stored Milvus token.");
  process.exit(2);
}
const PRIMARY_KEY = createHash("sha256").update(AUTH_SECRET).digest();
const ROTATION_KEY = ROTATION_SECRET
  ? createHash("sha256").update(ROTATION_SECRET).digest()
  : null;
const IV_LEN = 12;
const TAG_LEN = 16;

function decrypt(envelope) {
  if (!envelope) return null;
  if (envelope.startsWith("v2:")) {
    const buf = Buffer.from(envelope.slice(3), "base64");
    if (buf.length < IV_LEN + TAG_LEN + 1) return null;
    const iv = buf.subarray(0, IV_LEN);
    const tag = buf.subarray(IV_LEN, IV_LEN + TAG_LEN);
    const ct = buf.subarray(IV_LEN + TAG_LEN);
    return tryDecrypt(PRIMARY_KEY, iv, tag, ct) ?? (ROTATION_KEY ? tryDecrypt(ROTATION_KEY, iv, tag, ct) : null);
  }
  // Legacy "iv:ct:tag" base64.
  const parts = envelope.split(":");
  if (parts.length !== 3) return null;
  try {
    const iv = Buffer.from(parts[0], "base64");
    const ct = Buffer.from(parts[1], "base64");
    const tag = Buffer.from(parts[2], "base64");
    return tryDecrypt(PRIMARY_KEY, iv, tag, ct) ?? (ROTATION_KEY ? tryDecrypt(ROTATION_KEY, iv, tag, ct) : null);
  } catch {
    return null;
  }
}

function tryDecrypt(key, iv, tag, ct) {
  try {
    const dec = createDecipheriv("aes-256-gcm", key, iv);
    dec.setAuthTag(tag);
    return Buffer.concat([dec.update(ct), dec.final()]).toString("utf8");
  } catch {
    return null;
  }
}

// --- Main -------------------------------------------------------------------

const prisma = new PrismaClient();

async function main() {
  const cfg = await prisma.orgAiConfig.findUnique({
    where: { organizationId: ORG_ID },
    select: {
      milvusUri: true,
      milvusTokenEncrypted: true,
      milvusCollection: true,
      milvusIsolation: true,
      embeddingDimensions: true,
    },
  });
  if (!cfg?.milvusUri) {
    throw new Error(`Org ${ORG_ID} has no milvusUri configured`);
  }
  const token = cfg.milvusTokenEncrypted ? decrypt(cfg.milvusTokenEncrypted) : null;
  const collectionBase = cfg.milvusCollection?.trim() || "autorfp_chunks";
  const isolation = cfg.milvusIsolation === "collection" ? "collection" : "partition";
  const dim = cfg.embeddingDimensions ?? Number(process.env.EMBEDDING_DIMENSIONS ?? 384);
  const collectionName =
    isolation === "collection"
      ? `${collectionBase}_${ORG_ID.replace(/[^A-Za-z0-9_]/g, "_").slice(0, 200)}`
      : collectionBase;

  console.log(
    `[migrate] org=${ORG_ID} indexFilter=${INDEX_ID ?? "*"} batch=${BATCH} dryRun=${DRY_RUN}`,
  );
  console.log(
    `[migrate] backend uri=${cfg.milvusUri} collection=${collectionName} isolation=${isolation} dim=${dim}`,
  );

  // Lazy import so a missing SDK install only bites at runtime, not at parse.
  let MilvusClient, DataType, MetricType, IndexType;
  let client = null;
  if (!DRY_RUN) {
    ({ MilvusClient, DataType, MetricType, IndexType } = await import("@zilliz/milvus2-sdk-node"));
    client = new MilvusClient({ address: cfg.milvusUri, token: token ?? undefined });
    await ensureCollection(client, collectionName, isolation, dim, DataType, MetricType, IndexType);
  }

  const indexes = await prisma.knowledgeIndex.findMany({
    where: {
      organizationId: ORG_ID,
      ...(INDEX_ID ? { id: INDEX_ID } : {}),
    },
    select: { id: true },
  });
  if (indexes.length === 0) {
    console.warn(`[migrate] no indexes match — nothing to do`);
    await prisma.$disconnect();
    return;
  }

  let scanned = 0;
  let written = 0;
  let errors = 0;
  const t0 = Date.now();

  for (const idx of indexes) {
    let cursor;
    while (true) {
      const rows = await prisma.documentChunk.findMany({
        where: { document: { indexId: idx.id } },
        select: {
          id: true,
          embedding: true,
          documentId: true,
          section: true,
          kind: true,
          page: true,
          anchor: true,
          document: { select: { indexId: true } },
        },
        take: BATCH,
        ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
        orderBy: { id: "asc" },
      });
      if (rows.length === 0) break;
      cursor = rows[rows.length - 1].id;
      scanned += rows.length;

      const ready = rows.filter((r) => Array.isArray(r.embedding) && r.embedding.length > 0);
      if (ready.length === 0) continue;

      if (DRY_RUN) {
        written += ready.length;
        continue;
      }

      try {
        const data = ready.map((r) => ({
          id: r.id,
          organizationId: ORG_ID,
          indexId: r.document.indexId,
          documentId: r.documentId,
          section: (r.section ?? "").slice(0, 512),
          kind: (r.kind ?? "").slice(0, 32),
          page: r.page ?? 0,
          anchor: (r.anchor ?? "").slice(0, 64),
          embedding: r.embedding,
        }));
        await client.insert({ collection_name: collectionName, data });
        written += ready.length;
      } catch (err) {
        errors += ready.length;
        console.warn(`[migrate] batch failed (${ready.length} rows):`, err?.message ?? err);
      }
    }
  }

  if (!DRY_RUN && errors === 0 && written > 0) {
    await prisma.orgAiConfig.upsert({
      where: { organizationId: ORG_ID },
      update: { vectorMigratedAt: new Date() },
      create: { organizationId: ORG_ID, vectorMigratedAt: new Date() },
    });
    console.log(`[migrate] vectorMigratedAt stamped`);
  }

  const ms = Date.now() - t0;
  console.log(`[migrate] done scanned=${scanned} written=${written} errors=${errors} ms=${ms}`);
  await prisma.$disconnect();
}

async function ensureCollection(
  client,
  name,
  isolation,
  dim,
  DataType,
  MetricType,
  IndexType,
) {
  const has = await client.hasCollection({ collection_name: name });
  if (!has?.value) {
    const fields = [
      { name: "id", data_type: DataType.VarChar, is_primary_key: true, autoID: false, max_length: 64 },
      {
        name: "organizationId",
        data_type: DataType.VarChar,
        max_length: 64,
        is_partition_key: isolation === "partition",
      },
      { name: "indexId", data_type: DataType.VarChar, max_length: 64 },
      { name: "documentId", data_type: DataType.VarChar, max_length: 64 },
      { name: "section", data_type: DataType.VarChar, max_length: 512 },
      { name: "kind", data_type: DataType.VarChar, max_length: 32 },
      { name: "page", data_type: DataType.Int32 },
      { name: "anchor", data_type: DataType.VarChar, max_length: 64 },
      { name: "embedding", data_type: DataType.FloatVector, dim },
      { name: "sparse", data_type: DataType.SparseFloatVector },
    ];
    await client.createCollection({
      collection_name: name,
      fields,
      num_partitions: isolation === "partition" ? 64 : undefined,
    });
    console.log(`[migrate] created collection ${name}`);
  }
  await client.createIndex({
    collection_name: name,
    field_name: "embedding",
    index_name: "embedding_hnsw",
    index_type: IndexType.HNSW,
    metric_type: MetricType.COSINE,
    params: { M: 16, efConstruction: 200 },
  });
  try {
    await client.createIndex({
      collection_name: name,
      field_name: "sparse",
      index_name: "sparse_inv",
      index_type: IndexType.SPARSE_INVERTED_INDEX,
      metric_type: MetricType.IP,
      params: { drop_ratio_build: 0.2 },
    });
  } catch (err) {
    console.warn("[migrate] sparse index create skipped:", err?.message ?? err);
  }
  await client.loadCollection({ collection_name: name });
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--")) continue;
    const key = a.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith("--")) {
      out[key] = true;
    } else {
      out[key] = next;
      i++;
    }
  }
  return out;
}

main().catch(async (err) => {
  console.error("[migrate] fatal:", err?.stack ?? err);
  await prisma.$disconnect().catch(() => {});
  process.exit(1);
});
