// One-slide head-to-head comparison — LIGHT theme with header + footer.
// Run: `node scripts/generate-comparison-slide-light.mjs`
//      → docs/AutoRFP-vs-reference-light.pptx

import PptxGenJS from "pptxgenjs";
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";

const COLOR = {
  bg: "FFFFFF",
  bgSoft: "F8FAFC",       // slate-50
  card: "FFFFFF",
  cardLine: "E2E8F0",     // slate-200
  fg: "0F172A",           // slate-900
  fgSoft: "334155",       // slate-700
  muted: "64748B",         // slate-500
  primary: "7C3AED",      // violet-600
  primary2: "C026D3",      // fuchsia-600
  accent: "0284C7",       // sky-600
  good: "059669",
  warn: "D97706",
  bad: "DC2626",
  trackBg: "F1F5F9",       // slate-100 (for bar tracks)
};
const FONT = "Calibri";

const outDir = resolve("./docs");
mkdirSync(outDir, { recursive: true });

const pres = new PptxGenJS();
pres.layout = "LAYOUT_WIDE";
pres.title = "AutoRFP vs Reference — Head-to-Head";
pres.author = "AutoRFP";

const W = 13.33;
const H = 7.5;
const s = pres.addSlide();
s.background = { color: COLOR.bg };

// =================== HEADER ===================
// Top gradient strip (thin)
s.addShape(pres.ShapeType.rect, {
  x: 0, y: 0, w: W * 0.45, h: 0.08,
  fill: { color: COLOR.primary }, line: { type: "none" },
});
s.addShape(pres.ShapeType.rect, {
  x: W * 0.45, y: 0, w: W * 0.55, h: 0.08,
  fill: { color: COLOR.primary2 }, line: { type: "none" },
});

// Header band
s.addShape(pres.ShapeType.rect, {
  x: 0, y: 0.08, w: W, h: 0.55,
  fill: { color: COLOR.bgSoft }, line: { type: "none" },
});
// Header divider
s.addShape(pres.ShapeType.line, {
  x: 0, y: 0.63, w: W, h: 0,
  line: { color: COLOR.cardLine, width: 0.75 },
});

// Logo badge (small square)
s.addShape(pres.ShapeType.roundRect, {
  x: 0.5, y: 0.18, w: 0.36, h: 0.36, rectRadius: 0.07,
  fill: { color: COLOR.primary }, line: { type: "none" },
});
s.addText("A", {
  x: 0.5, y: 0.18, w: 0.36, h: 0.36,
  fontFace: FONT, fontSize: 18, color: "FFFFFF", bold: true, align: "center", valign: "middle",
});

s.addText("AutoRFP", {
  x: 0.95, y: 0.16, w: 4, h: 0.32,
  fontFace: FONT, fontSize: 16, color: COLOR.fg, bold: true,
});
s.addText("AI-Powered RFP Response Platform", {
  x: 0.95, y: 0.42, w: 5, h: 0.22,
  fontFace: FONT, fontSize: 9, color: COLOR.muted,
});

s.addText("COMPETITIVE COMPARISON", {
  x: W - 4.0, y: 0.22, w: 3.5, h: 0.22,
  fontFace: FONT, fontSize: 9, color: COLOR.primary2, bold: true, charSpacing: 6, align: "right",
});
s.addText(new Date().toISOString().slice(0, 10), {
  x: W - 4.0, y: 0.42, w: 3.5, h: 0.22,
  fontFace: FONT, fontSize: 9, color: COLOR.muted, align: "right",
});

// =================== TITLE ===================
s.addText("AutoRFP vs Reference RFP — Head-to-Head", {
  x: 0.5, y: 0.85, w: 12.3, h: 0.55,
  fontFace: FONT, fontSize: 26, color: COLOR.fg, bold: true,
});
s.addText("Independent audit across 5 dimensions  ·  production-ready scoring", {
  x: 0.5, y: 1.4, w: 12.3, h: 0.3,
  fontFace: FONT, fontSize: 12, color: COLOR.muted,
});

// =================== LEFT: SCORECARD ===================
const leftX = 0.5;
const leftY = 1.85;
const leftW = 6.0;
const leftH = 4.6;

s.addShape(pres.ShapeType.roundRect, {
  x: leftX, y: leftY, w: leftW, h: leftH, rectRadius: 0.12,
  fill: { color: COLOR.card }, line: { color: COLOR.cardLine, width: 0.75 },
});
// Card header accent
s.addShape(pres.ShapeType.rect, {
  x: leftX, y: leftY, w: 0.12, h: leftH,
  fill: { color: COLOR.primary }, line: { type: "none" },
});

s.addText("Scorecard (out of 10)", {
  x: leftX + 0.3, y: leftY + 0.2, w: leftW - 0.5, h: 0.35,
  fontFace: FONT, fontSize: 14, color: COLOR.fg, bold: true,
});

s.addText("Dimension", {
  x: leftX + 0.3, y: leftY + 0.62, w: 2.5, h: 0.3,
  fontFace: FONT, fontSize: 9, color: COLOR.muted, bold: true, charSpacing: 3,
});
s.addText("AutoRFP", {
  x: leftX + 2.85, y: leftY + 0.62, w: 1.6, h: 0.3,
  fontFace: FONT, fontSize: 9, color: COLOR.primary, bold: true, charSpacing: 3, align: "center",
});
s.addText("Reference", {
  x: leftX + 4.45, y: leftY + 0.62, w: 1.4, h: 0.3,
  fontFace: FONT, fontSize: 9, color: COLOR.muted, bold: true, charSpacing: 3, align: "center",
});

const rows = [
  { name: "Output quality", a: 9, b: 7 },
  { name: "Code correctness", a: 9, b: 8 },
  { name: "Architecture", a: 9, b: 8 },
  { name: "Security / prod-ready", a: 9, b: 6 },
  { name: "Overall", a: 9, b: 7, em: true },
];

const barW = 1.55;

rows.forEach((r, i) => {
  const y = leftY + 1.0 + i * 0.68;

  // Row separator (subtle)
  if (i > 0) {
    s.addShape(pres.ShapeType.line, {
      x: leftX + 0.3, y, w: leftW - 0.6, h: 0,
      line: { color: COLOR.trackBg, width: 0.4 },
    });
  }

  s.addText(r.name, {
    x: leftX + 0.3, y: y + 0.08, w: 2.5, h: 0.45,
    fontFace: FONT, fontSize: r.em ? 13 : 12,
    color: r.em ? COLOR.fg : COLOR.fgSoft, bold: !!r.em,
    valign: "middle",
  });

  // AutoRFP bar
  const barX = leftX + 2.85;
  s.addShape(pres.ShapeType.roundRect, {
    x: barX, y: y + 0.18, w: barW, h: 0.22,
    fill: { color: COLOR.trackBg }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addShape(pres.ShapeType.roundRect, {
    x: barX, y: y + 0.18, w: barW * (r.a / 10), h: 0.22,
    fill: { color: r.em ? COLOR.primary2 : COLOR.primary }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addText(String(r.a), {
    x: barX + barW + 0.05, y: y + 0.08, w: 0.4, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.fg, bold: true, valign: "middle",
  });

  // Reference bar
  const barX2 = leftX + 4.5;
  s.addShape(pres.ShapeType.roundRect, {
    x: barX2, y: y + 0.18, w: barW * 0.6, h: 0.22,
    fill: { color: COLOR.trackBg }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addShape(pres.ShapeType.roundRect, {
    x: barX2, y: y + 0.18, w: (barW * 0.6) * (r.b / 10), h: 0.22,
    fill: { color: COLOR.muted }, line: { type: "none" }, rectRadius: 0.05,
  });
  s.addText(String(r.b), {
    x: barX2 + (barW * 0.6) + 0.05, y: y + 0.08, w: 0.4, h: 0.4,
    fontFace: FONT, fontSize: 12, color: COLOR.muted, valign: "middle",
  });
});

// =================== RIGHT TOP: AUTORFP STRENGTHS ===================
const rightX = 6.85;
const rightW = 6.0;
const topY = 1.85;
const topH = 2.25;

s.addShape(pres.ShapeType.roundRect, {
  x: rightX, y: topY, w: rightW, h: topH, rectRadius: 0.12,
  fill: { color: COLOR.card }, line: { color: COLOR.cardLine, width: 0.75 },
});
s.addShape(pres.ShapeType.rect, {
  x: rightX, y: topY, w: 0.12, h: topH,
  fill: { color: COLOR.primary }, line: { type: "none" },
});

s.addText("AUTORFP · KEY STRENGTHS", {
  x: rightX + 0.3, y: topY + 0.18, w: rightW - 0.5, h: 0.3,
  fontFace: FONT, fontSize: 10, color: COLOR.primary, bold: true, charSpacing: 4,
});
s.addText(
  [
    { text: "Hybrid retrieval (BM25 + dense + RRF + LLM rerank) — robust without pgvector", options: { bullet: { code: "25B8" }, color: COLOR.fgSoft } },
    { text: "2-stage question extraction with LLM eligibility classifier + confidence", options: { bullet: { code: "25B8" }, color: COLOR.fgSoft } },
    { text: "Pipeline engine — AUTO / MANUAL / DECISION modes with visual progress", options: { bullet: { code: "25B8" }, color: COLOR.fgSoft } },
    { text: "Prod stack — Docker · health · OAuth · rate-limit · breaker · audit · key rotation", options: { bullet: { code: "25B8" }, color: COLOR.fgSoft } },
    { text: "154 tests — SSE streams · crypto tamper · HMAC replay · breaker states", options: { bullet: { code: "25B8" }, color: COLOR.fgSoft } },
  ],
  {
    x: rightX + 0.3, y: topY + 0.55, w: rightW - 0.5, h: topH - 0.7,
    fontFace: FONT, fontSize: 11, paraSpaceAfter: 4, valign: "top",
  },
);

// =================== RIGHT BOTTOM: ADVANTAGES ===================
const botY = 4.2;
const botH = 2.25;

s.addShape(pres.ShapeType.roundRect, {
  x: rightX, y: botY, w: rightW, h: botH, rectRadius: 0.12,
  fill: { color: COLOR.card }, line: { color: COLOR.cardLine, width: 0.75 },
});
s.addShape(pres.ShapeType.rect, {
  x: rightX, y: botY, w: 0.12, h: botH,
  fill: { color: COLOR.primary2 }, line: { type: "none" },
});

s.addText("DECISIVE ADVANTAGES OVER REFERENCE", {
  x: rightX + 0.3, y: botY + 0.18, w: rightW - 0.5, h: 0.3,
  fontFace: FONT, fontSize: 10, color: COLOR.primary2, bold: true, charSpacing: 4,
});

const advCols = [
  { title: "Rate-limit + breaker", body: "Token bucket + Redis adapter + per-provider breaker.  Ref: unmetered LLM calls (cost / DoS risk)." },
  { title: "At-rest encryption", body: "AES-256-GCM, versioned, zero-downtime rotation.  Ref: API keys as plain env vars." },
  { title: "Audit trail", body: "AuditLog model + 7 wired events + admin viewer.  Ref: none — blocks SOC 2 / GDPR." },
  { title: "Structured logging", body: "Pino + AsyncLocalStorage reqId propagation.  Ref: console.log in prod paths." },
];

advCols.forEach((a, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = rightX + 0.3 + col * 2.85;
  const y = botY + 0.55 + row * 0.85;
  s.addText(a.title, {
    x, y, w: 2.7, h: 0.3,
    fontFace: FONT, fontSize: 11, color: COLOR.accent, bold: true,
  });
  s.addText(a.body, {
    x, y: y + 0.28, w: 2.7, h: 0.55,
    fontFace: FONT, fontSize: 9.5, color: COLOR.muted, valign: "top",
  });
});

// =================== BOTTOM LINE STRIP ===================
s.addShape(pres.ShapeType.roundRect, {
  x: 0.5, y: 6.55, w: W - 1.0, h: 0.45, rectRadius: 0.08,
  fill: { color: COLOR.bgSoft }, line: { color: COLOR.primary2, width: 0.5 },
});
s.addText(
  [
    { text: "BOTTOM LINE   ", options: { color: COLOR.primary2, bold: true, charSpacing: 4 } },
    { text: "AutoRFP leads on every dimension. Biggest moat: production-readiness (+3 vs Reference). Decisive on rate-limiting, secrets management, audit trail, and observability.", options: { color: COLOR.fg } },
  ],
  {
    x: 0.7, y: 6.58, w: W - 1.4, h: 0.4,
    fontFace: FONT, fontSize: 11, valign: "middle",
  },
);

// =================== FOOTER ===================
s.addShape(pres.ShapeType.line, {
  x: 0, y: 7.12, w: W, h: 0,
  line: { color: COLOR.cardLine, width: 0.75 },
});
s.addText("AutoRFP · Confidential · For internal review", {
  x: 0.5, y: 7.18, w: 7, h: 0.28,
  fontFace: FONT, fontSize: 9, color: COLOR.muted,
});
s.addText("Page 1 of 1", {
  x: W - 2.5, y: 7.18, w: 2, h: 0.28,
  fontFace: FONT, fontSize: 9, color: COLOR.muted, align: "right",
});

const out = resolve(outDir, "AutoRFP-vs-reference-light.pptx");
await pres.writeFile({ fileName: out });
console.log("Wrote", out);
