// Read-only — list columns on OrgAiConfig so we can tell whether the Phase D
// schema additions actually applied to Postgres.

import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
try {
  const rows = await prisma.$queryRawUnsafe(
    `SELECT column_name FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = 'OrgAiConfig'
     ORDER BY column_name`,
  );
  console.log(`OrgAiConfig columns (${rows.length}):`);
  for (const r of rows) console.log(`  • ${r.column_name}`);
  const has = (n) => rows.some((r) => r.column_name === n);
  const phaseD = ["ragProvider", "ragEndpoint", "ragApiKeyEncrypted", "ragExtraHeaders"];
  console.log(`\nPhase D fields:`);
  for (const f of phaseD) console.log(`  ${has(f) ? "✓" : "✗"} ${f}`);
} finally {
  await prisma.$disconnect();
}
