// Smoke test: download the BGE cross-encoder for real and score passages
// via the SAME code path the chat pipeline uses (src/lib/ai/reranker.ts).
//
// Run: node scripts/smoke-cross-encoder.mjs

import { performance } from "node:perf_hooks";
import { register } from "node:module";
import { pathToFileURL } from "node:url";

// Boot TypeScript-import support so this script can pull our .ts module
// directly (no separate build step). Uses Node's experimental loader hook.
try {
  register("tsx/esm", pathToFileURL("./"));
} catch {
  // tsx is not a hard dep — fall back to a clear error.
}

const QUERY = "What is your SLA for incident response?";
const PASSAGES = [
  "Our SLA guarantees 30-minute response to critical incidents 24/7/365.",
  "Last year we launched a redesigned employee handbook with updated PTO policies.",
  "The chef's special is a wood-fired Margherita pizza with fresh basil.",
  "Incident response: P1 acknowledged in 15 min, P2 in 1 hour, per signed SLA.",
  "Onboarding includes a Day 1 laptop setup with VPN, MFA, and Slack access.",
];

console.log(`Loading reranker module + downloading Xenova/bge-reranker-base…`);
console.log(`(first run downloads ~120 MB to node_modules/.cache/transformers)\n`);

let getCrossEncoder;
try {
  ({ getCrossEncoder } = await import("../src/lib/ai/reranker.ts"));
} catch (e) {
  console.error("Failed to import reranker module. Did you run `pnpm add -D tsx`?");
  console.error(e);
  process.exit(1);
}

const t0 = performance.now();
const encoder = getCrossEncoder(); // defaults to Xenova/bge-reranker-base
const result = await encoder.rerank(QUERY, PASSAGES);
const t1 = performance.now();

console.log(`✓ scored ${PASSAGES.length} passages in ${((t1 - t0) / 1000).toFixed(1)}s (incl. model load)`);
console.log(`\nRanked best → worst:`);
for (let k = 0; k < result.order.length; k++) {
  const i = result.order[k];
  const p = PASSAGES[i];
  const s = result.scores[k];
  const flag = p.includes("SLA") || p.includes("incident") ? " ✓" : "";
  console.log(`  ${s.toFixed(4)}  ${p.slice(0, 70)}${p.length > 70 ? "…" : ""}${flag}`);
}

// Sanity: the top 2 should both be SLA/incident-related.
const top2 = result.order.slice(0, 2).map((i) => PASSAGES[i]);
const top2Relevant = top2.every((p) => p.includes("SLA") || p.includes("incident"));
if (!top2Relevant) {
  console.error(`\n✗ FAIL — top 2 don't both look SLA-related. Reranker may be miscalibrated.`);
  process.exit(1);
}
// Sanity: scores should span a meaningful range (not all identical).
const range = result.scores[0] - result.scores[result.scores.length - 1];
if (range < 0.05) {
  console.error(`\n✗ FAIL — score range is only ${range.toFixed(4)}; reranker outputs are too flat.`);
  process.exit(1);
}
console.log(`\n✓ PASS — top-2 are both SLA-relevant; score range ${range.toFixed(4)} is healthy.`);
