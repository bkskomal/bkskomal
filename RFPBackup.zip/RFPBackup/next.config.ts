import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Emit a self-contained server bundle under `.next/standalone` so the
  // production Docker image can run `node server.js` without the full
  // node_modules tree. See Dockerfile (runner stage). On Windows the trace
  // step needs SeCreateSymbolicLinkPrivilege, so we only enable standalone
  // when explicitly requested (set NEXT_OUTPUT=standalone for Docker builds).
  ...(process.env.NEXT_OUTPUT === "standalone" ? { output: "standalone" as const } : {}),
  experimental: {
    serverActions: {
      bodySizeLimit: "50mb",
    },
  },
  serverExternalPackages: [
    "pdf-parse",
    // pdfjs-dist needs to resolve its worker file from node_modules at runtime;
    // webpack-bundling it breaks that lookup. The worker URL is set via
    // `pathToFileURL(require.resolve(...))` in pdf-parser.ts.
    "pdfjs-dist",
    "mammoth",
    "xlsx",
    "officeparser",
    "@huggingface/transformers",
    "onnxruntime-node",
    "sharp",
    // gRPC + protobuf packages must NOT be bundled by webpack — bundling
    // breaks the native gRPC channel resolver. Keep them as CommonJS requires.
    "@zilliz/milvus2-sdk-node",
    "@grpc/grpc-js",
    "@grpc/proto-loader",
    "protobufjs",
    // ioredis needs Node "stream" + "net" + "tls" builtins which webpack
    // refuses to polyfill — bundling it produces "Module not found: Can't
    // resolve 'stream'". Treating it as an external require keeps the
    // rate-limit backend working in dev + Docker.
    "ioredis",
    // nodemailer (pulled in by next-auth's Nodemailer provider) needs
    // Node "stream" + "net" + "dns" — same situation as ioredis.
    "nodemailer",
    // jsdom + Readability (used by the URL scraper) and turndown pull in
    // node-builtins (vm, url, fs) that we don't want webpack rewriting.
    "jsdom",
    "@mozilla/readability",
    "turndown",
  ],
};

export default nextConfig;
