# AutoRFP

AI-powered RFP response platform. Upload an RFP, get every question extracted automatically, and generate cited answers from your own knowledge base — all running on your own self-hosted models. **No data leaves your infrastructure.**

Built for organizations that want to respond to RFPs faster without sending their proprietary content to a third-party API.

---

## Highlights

- **Self-hosted AI by design.** Works with any OpenAI-compatible LLM server: Ollama, vLLM, LocalAI, LM Studio, OpenRouter, OpenAI. Swap models with one env var.
- **Persistent right-side chat panel (Assistant).** A dedicated chat sidebar (`src/components/dashboard/chat-sidebar.tsx`) sits on every page — drag-resizable (280–800 px), maximizable to full content area, with a conversation-history view that's always visible when maximized and toggleable in normal mode. Sticky below the full-width top header, auto-collapses on narrow viewports, and per-org thread state persists in localStorage.
- **Scoped AI chat.** Chat with an RFP, a knowledge index, a project, or org-wide. Streaming SSE, tool-calling, persistent threads.
- **Pluggable chat backend.** Drive chat with the built-in RAG + LangGraph research agent, OR delegate to an external service (e.g. OATI `/UserPrompt`) — toggle per-org from Admin Settings → Chat Provider. Tools + Agent toggles ignored automatically when external.
- **Pluggable RAG backend.** Same pattern for retrieval: Internal hybrid (dense + BM25 + RRF + cross-encoder rerank) OR external HTTP service (Vectara, Azure AI Search, Pinecone Assistants, your own endpoint).
- **LangGraph research agent.** Optional "Agent ON" mode for chat — `plan → search → draft → critique → revise` loop with bounded iterations. Emits step events live to the chat UI.
- **Multi-step response generation, streamed live.** Watch the model analyze → search → call tools → draft → cite, in real time.
- **Pluggable tool registry.** Function-calling tools (knowledge search, calculator, custom org tools) the model can invoke while answering. Add your own by dropping a file in `src/lib/ai/tools/`.
- **Per-org configurable AI stack.** RAG strategy + reranker + extraction model + prompt + scraping engine + generation model + grounding judge — every layer driven by `OrgAiConfig` and surfaced as Admin Settings cards.
- **Cross-encoder reranker + contextual retrieval + headless scraping.** BGE-style reranker via `@huggingface/transformers` (local, free), Anthropic-style chunk-context-prepended embeddings, Playwright + Browserless headless engines for JS-rendered pages.
- **Quality compounds.** Golden-answer references and 👍/👎 feedback per response build a continuously growing eval set.
- **Optional premium document parsing.** Drop in a LlamaParse API key for table-aware/chart-aware extraction; falls back to local parsers (pdf-parse, mammoth, officeparser) when not configured.
- **Markdown-rendered AI output.** Bullets, tables, code blocks, citations all render properly.
- **Multi-tenant.** Organizations · projects · members (owner/admin/member) · per-org knowledge bases.
- **Production-grade plumbing.** Typed error classes, `withApiHandler` wrapper, env validation at boot via `instrumentation.ts`, Vitest test harness (~880 tests).
- **Modern UI.** Next.js 15 App Router · React 19 · Tailwind · shadcn-style Radix components · light/dark/system theme · ⌘K command palette · full-width sticky header with brand on the left, theme picker / notifications / chat toggle / avatar on the right.

---

## Architecture

```
┌─────────────────────┐    ┌──────────────────────┐    ┌────────────────────┐
│   Next.js 15 App    │    │   PostgreSQL +       │    │  Self-hosted LLM   │
│   (App Router)      │◄──►│   pgvector           │    │  (OpenAI-compat)   │
│                     │    │                      │    │                    │
│  - Server actions   │    │  - Org / projects    │    │  - Ollama          │
│  - SSE streaming    │    │  - RFPs / questions  │◄──►│  - vLLM            │
│  - NextAuth         │    │  - Documents         │    │  - LocalAI         │
│  - Prisma           │    │  - Vector embeddings │    │  - LM Studio       │
└─────────────────────┘    │  - Golden answers    │    └────────────────────┘
                            │  - Feedback          │
                            └──────────────────────┘
```

Document parsing is server-side (PDF, Word, Excel, PowerPoint, txt, markdown). Chunks are embedded once and stored as `vector(768)` columns. Retrieval is cosine-similarity search via pgvector.

---

## Prerequisites

- **Node.js** 20+
- **pnpm** 9+ (`npm install -g pnpm`)
- **PostgreSQL 14+** with the [`pgvector`](https://github.com/pgvector/pgvector) extension installed.
  - Easiest: `docker run --name pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d pgvector/pgvector:pg16`
- A running OpenAI-compatible LLM server. The simplest is **Ollama**:
  ```bash
  # Install: https://ollama.com
  ollama pull llama3.2               # default chat model (matches LLM_MODEL)
  ollama pull nomic-embed-text        # embedding model (must produce 768-dim vectors)
  ollama serve                        # exposes http://localhost:11434/v1
  ```
- An SMTP server for magic-link emails. For local dev, [Mailpit](https://github.com/axllent/mailpit) is perfect:
  ```bash
  docker run -d -p 1025:1025 -p 8025:8025 axllent/mailpit
  # SMTP on :1025, web inbox on http://localhost:8025
  ```

---

## Quick start

```bash
git clone <this repo>
cd AutoRFP

# 1. Install
pnpm install

# 2. Configure
cp .env.example .env
# Edit .env — set DATABASE_URL, AUTH_SECRET (run `openssl rand -base64 32`),
# LLM_BASE_URL/MODEL, EMAIL_SERVER_HOST/PORT.

# 3. Database
pnpm db:push          # provisions schema + pgvector + pgcrypto extensions
pnpm db:seed          # optional: creates a demo user + org + project

# 4. Run
pnpm dev              # http://localhost:3000
```

Sign in with your email — Mailpit's inbox at `http://localhost:8025` will show the magic link.

---

## Run with Ollama (recommended for local dev)

AutoRFP defaults to a local-first setup. If Ollama is running on the same machine, **no env config is needed** — `LLM_BASE_URL` defaults to `http://localhost:11434/v1`, `LLM_MODEL` defaults to `llama3.2`, and there's no API key to manage.

```bash
# 1. Install Ollama (one-time)
#    macOS / Linux: see https://ollama.com
#    Windows:        https://ollama.com/download/windows

# 2. Pull a chat model (~2 GB) and an embedder (~270 MB)
ollama pull llama3.2
ollama pull nomic-embed-text

# 3. Start the daemon (most installers register a launchd/systemd unit
#    so this runs automatically; if not:)
ollama serve

# 4. Start AutoRFP — startup log should print:
#       [autorfp] ✓ Ollama reachable: v0.x.y
pnpm dev
```

Open `http://localhost:3000/dashboard/settings` and the AI configuration card will show **Ollama** preselected with **Local** and **No API key** badges. Recommended models that aren't installed yet have a **Pull** button — click it to stream the download right from the UI.

To swap to a hosted provider later, just override `LLM_BASE_URL`, `LLM_API_KEY`, and `LLM_MODEL` in `.env` (or change the per-org config in the Settings page).

---

## Production Docker deploy

The repo ships with a multi-stage `Dockerfile` and a `docker-compose.yml` that brings up Postgres (with pgvector), Mailpit, and the app in one shot:

```bash
docker compose up --build
```

Then visit **http://localhost:3000**. Captured magic-link emails appear at **http://localhost:8025** (Mailpit).

### What you must override for real production

The defaults in `docker-compose.yml` are dev-grade. Before deploying anywhere real, set:

- `AUTH_SECRET` — generate via `openssl rand -base64 32`. The default is a clearly-marked placeholder.
- `LLM_API_KEY` — your OpenRouter / OpenAI / vLLM key. Passed through from the host environment.
- `AUTH_URL` — the public origin of your deployment (e.g. `https://rfp.example.com`).

### Migrations

The container runs `prisma migrate deploy` on every startup (falling back to `prisma db push --accept-data-loss` if no migrations are present). This is idempotent — already-applied migrations are skipped.

### Healthcheck

```bash
curl http://localhost:3000/api/health
```

Returns JSON with sub-checks for `database`, `embedding`, and `llm`. HTTP 200 when healthy, 503 when the database check fails. The Docker `HEALTHCHECK` directive uses the same endpoint.

### Corporate TLS proxies

If your build host sits behind a TLS-intercepting proxy, add your CA bundle to the compose env so Node trusts it at runtime:

```yaml
# docker-compose.yml — app.environment
NODE_EXTRA_CA_CERTS: /etc/ssl/corp-ca.pem
# …and mount the cert:
# volumes:
#   - ./corp-ca.pem:/etc/ssl/corp-ca.pem:ro
```

The build itself sets `NODE_TLS_REJECT_UNAUTHORIZED=0` only during `next build` to get past proxy-broken npm registry traffic — runtime requests still verify TLS normally.

---

## Configuration

All config is via environment variables. See `.env.example` for the full list.

### Switching the LLM

The whole AI layer talks the **OpenAI Chat Completions API**. Any server that speaks it works:

```env
# Ollama
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
LLM_MODEL=llama3.1:8b

# vLLM
LLM_BASE_URL=http://your-vllm-host:8000/v1
LLM_API_KEY=anything
LLM_MODEL=meta-llama/Meta-Llama-3.1-8B-Instruct

# LocalAI / LM Studio
LLM_BASE_URL=http://your-host:1234/v1
LLM_MODEL=your-loaded-model-id
```

#### Testing with OpenRouter

[OpenRouter](https://openrouter.ai) is the fastest way to try the app against frontier models without running anything locally. It exposes an OpenAI-compatible chat endpoint with hundreds of models behind one key.

```env
LLM_BASE_URL=https://openrouter.ai/api/v1
LLM_API_KEY=sk-or-v1-...                  # from https://openrouter.ai/keys
LLM_MODEL=anthropic/claude-sonnet-4.5      # or any model from https://openrouter.ai/models

# Recommended (used by OpenRouter for analytics + rate-limit attribution):
LLM_HTTP_REFERER=http://localhost:3000
LLM_APP_TITLE=AutoRFP
```

**One caveat:** OpenRouter does **not** serve embeddings. Keep `EMBEDDING_BASE_URL` pointed at Ollama (or another embedding-capable server) for document indexing. The two clients are independent — `pnpm dev` will happily call OpenRouter for chat and `localhost:11434` for embeddings in the same request.

If you don't want to run Ollama at all, use OpenAI for embeddings:
```env
EMBEDDING_BASE_URL=https://api.openai.com/v1
EMBEDDING_API_KEY=sk-...
EMBEDDING_MODEL=text-embedding-3-small
EMBEDDING_DIMENSIONS=1536
```
…and bump the `vector(768)` types in `prisma/schema.prisma` to `vector(1536)` before `pnpm db:push`.

**Embedding dimensions matter.** The schema is currently fixed at `vector(768)`, matching `nomic-embed-text`. If you switch to a model with a different embedding size, update both `EMBEDDING_DIMENSIONS` and the `vector(768)` types in `prisma/schema.prisma`, then `pnpm db:push`.

### Tool calling

Built-in tools (registered in `src/lib/ai/tools/builtin.ts`):
- `search_knowledge_base` — semantic search over the org's index
- `list_indexes` — list available knowledge bases
- `calculator` — evaluate arithmetic

Add your own:

```ts
// src/lib/ai/tools/builtin.ts (or any file imported from there)
toolRegistry.register({
  name: "lookup_customer",
  description: "Look up a customer record by ID.",
  schema: z.object({ id: z.string() }),
  async execute({ id }, ctx) {
    // ctx has organizationId, projectId, rfpId, userId, defaultIndexId
    return await myCrm.fetch(id);
  },
});
```

The tool is automatically exposed to the LLM via the OpenAI tools spec. Toggle the `Tools ON/OFF` button in the RFP viewer to control whether the model can call tools per-question.

---

## How it works

### RFP processing pipeline

1. **Upload** (Word/PDF/Excel/PPT/txt) → `src/lib/parsers/`
2. **Question extraction** — LLM reads the document text and returns structured JSON of every question/requirement → `src/lib/ai/extract.ts`
3. **User clicks Generate** on a question → SSE stream begins
4. **Analyze** — LLM plans search queries
5. **Retrieve** — pgvector cosine search across the project's default knowledge index
6. **Tool loop** (if enabled) — LLM can call tools and incorporate results
7. **Draft** — LLM produces final answer with `[Source N]` inline citations
8. **Persist** — response, sources, reasoning steps, feedback

### Quality loop

- **Golden Answers** (`/dashboard/golden`): pin the best Q→A pairs. The 3 most recent are injected as in-context style/format references for new responses.
- **Feedback** (👍/👎 on every response): stored in the `Feedback` table. Use as a continuously growing eval set, or wire into retrieval ranking later.

---

## Project layout

```
src/
  app/
    api/              # All REST routes (orgs, projects, rfps, indexes, responses, …)
    auth/             # Sign-in / verify-request
    dashboard/        # Authenticated app shell + pages
    page.tsx          # Marketing landing
  components/
    ui/               # shadcn-style primitives (button, card, dialog, …)
    dashboard/        # Sidebar, header, command palette
  lib/
    ai/
      client.ts       # OpenAI-compatible client (LLM + embedder)
      embeddings.ts
      retrieval.ts    # pgvector search
      chunking.ts
      extract.ts      # Question extraction
      generate.ts     # Multi-step response generation w/ tools
      prompts.ts
      tools/
        registry.ts   # Pluggable tool registry
        builtin.ts    # Built-in tools
    parsers/          # PDF / Word / Excel / PPT / text
    auth.ts           # NextAuth config
    authz.ts          # requireUser / requireMembership / requireProjectAccess
    prisma.ts
    indexing.ts       # Document → chunks → embeddings
    rfp-pipeline.ts   # RFP upload → parse → extract questions
    storage.ts        # File uploads
    env.ts            # Lazy zod-validated env
prisma/
  schema.prisma
  seed.ts
  migrations/0_init/migration.sql   # Enables pgvector + pgcrypto
```

---

## Useful scripts

```bash
pnpm dev          # Next dev server
pnpm build        # Production build (runs prisma generate first)
pnpm start        # Production server
pnpm typecheck    # tsc --noEmit
pnpm lint         # next lint
pnpm test         # vitest run
pnpm test:watch   # vitest in watch mode

pnpm db:push      # Sync schema to DB (dev)
pnpm db:migrate   # Create + apply a migration
pnpm db:studio    # Prisma Studio UI
pnpm db:seed      # Seed demo org + user
pnpm db:local     # Run an in-process Postgres (PGlite) on :5433 — no install needed
```

## Dev shortcuts

- **`/auth/dev`** — sign in as any email without SMTP. Only works when `NODE_ENV=development`.
- **Startup checks** — `src/instrumentation.ts` runs on first boot and logs each env var with `✓ / ! / ✗`. Misconfigurations are surfaced before the first request.
- **Typed errors** — throw `ValidationError`, `AuthError`, `ForbiddenError`, `NotFoundError`, `LlmError`, `EmbeddingError` from any route wrapped in `withApiHandler`. The wrapper translates them to consistent JSON.

## Troubleshooting

### `UNABLE_TO_VERIFY_LEAF_SIGNATURE` / "Connection error" when testing the LLM

Your machine has a corporate proxy or a TLS interceptor whose CA Node.js doesn't trust by default. Two fixes:

1. **Proper fix** — point Node at your corporate CA bundle:
   ```bash
   # PowerShell:  $env:NODE_EXTRA_CA_CERTS="C:\path\to\corp-ca.pem"; pnpm dev
   # bash:        NODE_EXTRA_CA_CERTS=/path/to/corp-ca.pem pnpm dev
   ```
2. **Quick fix (local dev only)** — disable TLS verification:
   ```bash
   # PowerShell:  $env:NODE_TLS_REJECT_UNAUTHORIZED="0"; pnpm dev
   # bash:        NODE_TLS_REJECT_UNAUTHORIZED=0 pnpm dev
   ```
   The startup log will show `! NODE_TLS_REJECT_UNAUTHORIZED=0` as a reminder. Never use this in production.

The Settings → Test Connection button surfaces the actual TLS error instead of OpenAI SDK's generic "Connection error." so you can tell which case you're in.

---

## Deployment notes

- **Long-running document processing** (parsing + embedding) currently runs in-process via fire-and-forget background promises. For production at scale, move `processRfp` and `ingestDocument` to a queue worker (BullMQ, pg-boss, etc.) — both are pure functions taking an ID, so the swap is mechanical.
- **Vercel** works for the web app, but you'll need separate workers since serverless functions can't run unbounded background tasks. A single VPS/container running `pnpm start` works out of the box.
- **HTTPS / SMTP** for production magic-link auth: set `AUTH_URL=https://your-domain` and use real SMTP credentials.

---

## License

MIT.
