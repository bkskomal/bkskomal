# Acme Cloud — Integrations Catalog

**Version:** 6.1 — February 2026

This document lists all integrations Acme supports out of the box, organized by category. For custom integration requests, contact integrations@acmecloud.com.

## 1. Identity and SSO

### SAML 2.0 (Generic)
Any IdP that speaks SAML 2.0. Tested with Okta, Azure AD, Google Workspace, OneLogin, Auth0, Ping, JumpCloud, Centrify, ADFS, Shibboleth.

Setup: ~15 minutes. Customer provides IdP metadata XML; Acme generates SP metadata. Test login validates round-trip before activation.

### SCIM 2.0
Automated user provisioning/deprovisioning from your identity provider. Supports user-create, user-update, user-deactivate, group-create, group-update, role-assign.

### Specific IdP Recipes
We have step-by-step guides for:
- Okta (most common; 5-minute setup)
- Azure AD / Entra ID
- Google Workspace
- OneLogin
- Auth0
- Ping Identity

### MFA Factors
- TOTP (Google Authenticator, Authy, etc.)
- WebAuthn (hardware keys, passkeys)
- Push notifications via Acme mobile app
- SMS (deprecated; only available for legacy migrations)

## 2. Content Sources

For ingesting documents into your Knowledge Base.

### File Storage Connectors
- **SharePoint Online** — connect to specific sites/libraries; sync incrementally
- **OneDrive for Business** — per-user or shared
- **Google Drive** — Workspace or Personal
- **Box**
- **Dropbox** (Standard, Advanced, Business)
- **Egnyte**

### Wiki and Documentation
- **Confluence** (Cloud and Server)
- **Notion** (per-database or per-workspace)
- **GitHub Wikis** (and any Markdown in a GitHub repo)
- **GitLab Wikis**
- **Bitbucket Wikis**
- **Slab**

### CRM and Sales
- **Salesforce** (Sales Cloud — for past correspondence) — also bidirectional for opportunity link + outcome
- **HubSpot** (Sales / Marketing)
- **Outreach**
- **Salesloft**
- **Pipedrive**

### Project Management and Tickets
- **Jira** (Cloud and Server)
- **Asana**
- **Linear**
- **Monday.com**
- **ClickUp**

### Email
- **Microsoft Exchange / Outlook** — historical email archive ingestion
- **Gmail** — via Workspace integration
- **Email-in** — forward an RFP to your tenant address (e.g. rfp@your-tenant.acmecloud.com); auto-creates project

### Custom HTTP / API
- **Generic webhook ingest** — POST documents/chunks to your tenant's `/api/indexes/[id]/external/documents` endpoint
- **NiFi processor** — reference NiFi flow at https://docs.acmecloud.com/integrations/nifi
- **Airflow operator** — official Airflow operator for the Acme API
- **n8n nodes** — community-contributed nodes for n8n
- **Zapier app** — full Zapier app with triggers and actions
- **Make.com (formerly Integromat)** — integration available

## 3. Communication and Notifications

### Slack
- Notifications channel (configurable per event type)
- Slash commands: `/acme draft`, `/acme search`, `/acme status`
- Acme bot for in-thread Q&A
- Thread-based RFP discussion

### Microsoft Teams
- Notifications channel
- Adaptive cards for review/approve workflows
- Acme bot in personal scope and team scope

### Email
- Daily digest emails (configurable per user)
- @mention email notifications
- RFP status change emails

### Webhooks
- Outgoing webhooks for any system event
- HMAC-SHA256 signed payloads
- Retry with exponential backoff
- Configurable event filters

## 4. Procurement Platforms

### Coupa
- Read-only access to RFP feed
- Auto-create Acme projects from Coupa RFPs

### Ariba
- Read-only access to RFP feed
- Bid response export back to Ariba

### Loopio (migration)
- One-way migration of legacy answer library
- Maintains tagging and structure where possible

### Responsive (formerly RFPIO) (migration)
- One-way migration of legacy answer library
- Maintains golden answers + tags

### Vendor questionnaires (read direction)
- Auto-detect when an RFP is a known questionnaire format (CAIQ, SIG, VSA-Q, custom variants)
- Auto-populate where the questionnaire is published-format

## 5. CRM Outcome Linkage

### Salesforce
- Link Acme RFP project to Salesforce Opportunity
- Push outcome (won/lost/withdrawn) back to Salesforce on RFP close
- Pull opportunity context (deal size, customer, industry) into RFP project

### HubSpot
- Same as Salesforce for HubSpot Sales Hub

## 6. Document Management at Output

### Word Export
- Pre-built templates for common RFP response formats
- Custom templates can be uploaded
- Maintains formatting, tables, citations

### PDF Export
- Same as Word but as PDF
- Citation links open the source document if user has access

### Excel Export
- For pricing-matrix RFPs
- Maintains cell structure, formulas where applicable

### eSignature
- DocuSign — send completed RFP for internal sign-off
- Adobe Acrobat Sign — same

## 7. Storage and Backup

### Customer-managed S3 / GCS / Azure Blob
- Dual-write all customer documents to a customer-managed bucket
- Real-time replication
- Customer maintains independent copy of all uploaded content

### Snowflake
- Outbound feed of audit logs and metrics into customer's Snowflake instance
- For customers with centralized data warehouses

### BigQuery
- Same as Snowflake for GCP customers

### Splunk / Datadog Logs
- Forward Acme audit logs into customer's SIEM
- HTTPS webhook destination supported by both

## 8. Observability Integrations

### Datadog
- Metrics published in Datadog format (when customer's tenant is on Datadog Cloud)
- Logs forwarded
- Custom Acme dashboards

### Splunk
- HEC (HTTP Event Collector) push of audit logs
- Pre-built Splunk dashboard JSON for Acme metrics

### Generic Prometheus
- /api/metrics endpoint exposes all metrics in Prometheus format
- Authenticated via METRICS_TOKEN env var

### Generic OpenTelemetry
- OTLP-formatted metrics and traces (in beta; GA Q2 2026)

## 9. AI Provider Connections

We integrate with any OpenAI-compatible LLM endpoint. Tested explicitly with:

### Acme-managed (default)
- Claude Sonnet 4.5 via Anthropic
- GPT-4o via OpenAI
- (Per region routing)

### Customer BYO
- **OpenAI** (direct or via Microsoft Azure OpenAI Service)
- **Anthropic** (direct or via AWS Bedrock)
- **Google Vertex AI** (Gemini family)
- **OpenRouter** (300+ models behind one API)
- **Together.ai** (open-source models)
- **Replicate** (open-source models)
- **Fireworks AI** (open-source models)
- **Perplexity** (Sonar models)
- **Groq** (fast Llama serving)
- **vLLM** (self-hosted)
- **Ollama** (self-hosted, including local desktop)
- **LM Studio** (self-hosted)
- **LocalAI** (self-hosted)
- **HuggingFace TGI** (self-hosted)

### Embedding Provider Connections
- OpenAI text-embedding-3 family
- Cohere embed family
- VoyageAI embeddings
- HuggingFace TEI (self-hosted)
- @huggingface/transformers (in-process; default)
- Any OpenAI-compatible /v1/embeddings endpoint

### LoRA / Fine-tune Connections
- OpenAI fine-tunes (`ft:` model names)
- Together.ai LoRA hosting
- vLLM with adapter loading
- Custom adapter URL on any OpenAI-compatible endpoint

## 10. Vector Store Connections

### Postgres (default)
- pgvector extension or Float[] columns
- Built-in; zero configuration

### Milvus / Zilliz Cloud
- gRPC connection to standalone or cloud Milvus
- Supports HNSW dense + sparse hybrid

### Future (roadmap)
- Pinecone (Q2 2026)
- Weaviate (Q3 2026)
- Qdrant (Q3 2026)

## 11. Knowledge Graph and BI

### Neo4j (export)
- Export entity relationships from extracted RFP content
- For customers building knowledge graphs from procurement data

### Power BI / Tableau / Looker
- Standard SQL access to non-customer-content metadata (project counts, response times, win rates)
- Read-only DB credentials for analytics workloads

## 12. Custom Integration

When you need an integration not on this list:

- **Generic Webhook + REST API:** ~80% of needs covered without code
- **Custom NiFi/Airflow flow:** Acme provides reference flows; customer adapts to their stack
- **Acme Pro Services:** time-and-materials engagement, $250/hour, typical project 2–6 weeks
- **Open-source community contributions:** community node libraries for n8n, Zapier, etc. encouraged

## 13. Integration Pricing

- All integrations on this list are included in your tier (no per-integration cost)
- Custom integration build via Pro Services is T&M billed
- Some third-party services (e.g. premium Zapier features) may have their own costs
- Outbound webhook delivery is metered at high volumes (>10,000/day) at $0.01 per 1,000 deliveries

## 14. Integration Reliability

- Connector failures don't impact core platform operation
- Sync schedules: typically 15-min poll for low-volume sources, 1-min for high-volume; webhook-driven where the source supports it
- Failed syncs visible in tenant admin UI with retry/resolve actions
- 99.9% uptime SLA for all bundled integrations on Platinum/Enterprise tier

## 15. Contact

For integration questions during evaluation: integrations@acmecloud.com or your assigned Solutions Architect.
For active customer integration help: your CSM or TAM.
For Pro Services: proservices@acmecloud.com.
