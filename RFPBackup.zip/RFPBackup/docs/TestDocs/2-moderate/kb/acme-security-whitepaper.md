# Acme Cloud Security Whitepaper

**Version:** 4.1 — March 2026
**Audience:** Security architects, CISOs, IT procurement, compliance teams

## 1. Security Philosophy

Acme Cloud is built on the principle that security is a property of the system architecture, not a feature bolted on later. Every customer's data is encrypted with keys we don't have access to in plaintext, every employee action against production is logged and reviewed, and every release goes through automated security gates before it sees customer traffic.

This whitepaper documents the controls, tools, and processes that back that claim.

## 2. Encryption

### 2.1 Data at Rest

All customer data is encrypted at rest using **AES-256-GCM**. Encryption is performed transparently at the storage layer — we never store unencrypted customer bytes on persistent media.

Each tenant has its own **Customer Master Key (CMK)** managed by AWS KMS (or, for BYOK customers, in their own KMS). The CMK is used to envelope-encrypt per-object data encryption keys (DEKs); only the DEK ever decrypts the data, and the DEK exists only in memory during read operations.

CMK characteristics:
- AES-256 keys generated within the FIPS 140-2 Level 2 validated AWS KMS HSM
- One CMK per tenant — cross-tenant key access is structurally impossible
- Automatic 90-day rotation; old keys retained for decryption of older snapshots
- Key access policies restricted to a single AWS IAM role used by our storage layer
- Every CMK use is logged in CloudTrail; logs immutably retained for 13 months

For Enterprise tier customers, **Bring Your Own Key (BYOK)** is supported using AWS KMS, Azure Key Vault, or GCP Cloud KMS. The customer creates and rotates their own key; Acme requests envelope encryption operations against the customer's KMS endpoint. Revoking the key in the customer's KMS causes immediate (within 5 minutes) loss of access to that customer's data — this is a customer-controlled "kill switch."

Backups, vector store entries, and search indexes are all encrypted with the same per-tenant CMK. There is no tier of data, no internal cache, and no analytics database that holds plaintext customer content.

### 2.2 Data in Transit

All network traffic to and from Acme Cloud uses **TLS 1.3** with HTTP Strict Transport Security (HSTS) and HSTS preloading. Cipher suites are restricted to perfect-forward-secrecy AEAD ciphers (AES-256-GCM, ChaCha20-Poly1305).

Internal service-to-service traffic uses **mutual TLS (mTLS)** with workload identities issued by SPIRE. Certificates rotate every 24 hours.

For customers behind corporate proxies, we support certificate pinning and a documented set of static IP ranges so customer firewalls can allowlist us by IP+SNI without TLS interception.

## 3. Identity and Access

### 3.1 Customer-Side Identity

- **SAML 2.0 SSO** supported with all major IdPs (Okta, Azure AD, Google, Auth0, OneLogin, generic SAML)
- **SCIM 2.0** for automated user provisioning/deprovisioning
- **Passkeys (WebAuthn)** supported as a primary authentication method
- **MFA** can be enforced per-tenant; supported factors: TOTP, WebAuthn (hardware key, passkey), push notification via SDK
- **Just-in-Time** user provisioning on first SSO login
- Optional **IP allowlisting** for tenant access
- Optional **geographic access restrictions** (block logins from specified countries)
- **Session lifetime** configurable per-tenant (default 8 hours, max 30 days, minimum 30 minutes)

### 3.2 RBAC and Permissions

Roles are tenant-scoped:
- **Owner** — full administrative access; can manage billing, members, deletion
- **Admin** — full access to data and configuration; cannot delete the org or change billing
- **Member** — full access to data based on project assignments; cannot manage members
- **Custom roles** (Enterprise tier) — define your own permission sets

Permissions are evaluated server-side on every API call. There is no client-side trust model.

### 3.3 Acme-Side Access

Acme employees do **not** have standing access to customer data. Production access for support, debugging, and operations follows a strict process:

1. Customer must explicitly grant temporary access via their tenant settings (or via a support ticket where the customer authorizes a specific scope)
2. Acme support engineer requests JIT elevation in our internal access broker
3. Approval required from a second engineer (the "two-person rule")
4. Time-boxed grant (default 4 hours, max 24 hours)
5. All actions logged with the engineer's identity, the customer's grant token, and the specific data accessed
6. Customer receives a notification when the grant is exercised
7. Customer can revoke the grant at any time

This is enforced technically, not just procedurally — there is no "back door" admin role; even our own engineers must go through the broker.

## 4. Network Security

### 4.1 Architecture

Acme Cloud runs on a **defense-in-depth** network architecture:

- **Edge:** Cloudflare WAF + DDoS protection. Bot detection. Rate limiting per source IP.
- **Application Load Balancer:** AWS ALB in private subnets, health-checked, multi-AZ
- **Application tier:** EKS containers in private subnets, no public IPs, egress through NAT
- **Data tier:** RDS + S3 + custom data services in further-restricted subnets, accessible only from the application tier via security groups
- **Admin plane:** A separate VPC with its own routing, used only for our access broker, observability, and emergency administration. Not reachable from customer-facing components.

### 4.2 DDoS Protection

Cloudflare absorbs DDoS attacks at the edge. We have customer-tested patterns up to 1.2 Tbps. For application-layer attacks, our WAF rules and rate limits provide the second layer.

### 4.3 Web Application Firewall

Cloudflare WAF runs in active mode with the OWASP Core Rule Set and our own custom rules tuned for the Acme Cloud API surface. Rules updated weekly.

## 5. Application Security

### 5.1 Secure SDLC

Every code change goes through:
1. **Pre-commit hooks** (local dev): linter, formatter, unit tests, secret scanner (GitGuardian)
2. **Pull request CI**: full test suite, type checker, SAST (Snyk Code, Semgrep), dependency scan (Snyk + Dependabot), license check, IaC scan (Checkov)
3. **Code review**: minimum 2 reviewers for security-sensitive paths (auth, crypto, IAM, billing); 1 reviewer for others; security team review required for new dependencies
4. **Pre-merge gate**: all CI green, all reviewers approved, no policy violations
5. **Post-merge canary**: deploy to 1% of traffic, observe metrics for 30 minutes, then progressive rollout

### 5.2 Vulnerability Management

- **External pen test:** Annually by a third-party firm (currently NCC Group). Findings tracked to closure with severity-based SLAs (Critical: 7 days, High: 30 days, Medium: 90 days).
- **Internal pen test:** Quarterly by our internal red team. Same SLAs.
- **Bug bounty:** Program on HackerOne (private, by invitation). 2025 paid bounties totaling $187,000 across 43 valid reports.
- **Continuous scanning:** Snyk for dependencies (real-time on every commit), Dependabot, Trivy for container images, Falco for runtime anomalies.

### 5.3 Secret Management

- All secrets in HashiCorp Vault, accessed via short-lived (1 hour) tokens issued to specific workloads
- No secrets in source code (enforced by GitGuardian on every commit)
- No secrets in container images (enforced by image scanning)
- Database credentials rotate every 24 hours
- API keys (customer-issued) hashed at rest with SHA-256

## 6. Logging and Monitoring

### 6.1 What We Log

- **Authentication events:** every login, logout, MFA challenge, SSO assertion, password reset
- **API access:** every API call with user, action, resource, timestamp, source IP, user agent
- **Privileged operations:** every administrative action including data export, member changes, key rotations
- **Subprocess invocations:** every LLM call, every embedding generation, every search query
- **Configuration changes:** every change to tenant settings, RBAC grants, IP allowlists

### 6.2 Where Logs Live

- **Hot tier (Datadog):** 30 days, fast search
- **Warm tier (S3 + Athena):** 13 months, slower but still queryable
- **Cold tier (Glacier):** 7 years for audit-relevant logs

All logs are encrypted at rest and immutable (write-once via S3 Object Lock).

### 6.3 Customer Access to Logs

Tenants can access their own audit logs via the API or the in-app Audit Log viewer (Admin role required). Logs are filterable by event type, actor, time range, and resource. CSV/JSON export available.

For real-time streaming, customers can configure a webhook destination to receive a signed (HMAC-SHA256) JSON payload on every audit event.

### 6.4 Security Monitoring

24/7 SOC monitoring with:
- **Datadog** for infrastructure metrics, traces, and logs
- **Splunk** for SIEM (correlation rules, threat hunting)
- **CrowdStrike** for endpoint detection
- **Falco** for runtime anomaly detection on production hosts
- **Wiz** for cloud posture monitoring (CSPM/CWPP)

Mean time to detect: 4 minutes for high-severity. Mean time to acknowledge: 7 minutes.

## 7. Data Handling

### 7.1 Data Classification

Customer data is treated as **Confidential** by default. Our internal classification scheme has four levels:

- **Public:** marketing content, public docs
- **Internal:** Acme operational metrics, anonymized usage stats
- **Confidential:** all customer data, customer-derived embeddings, customer-uploaded files
- **Restricted:** encryption keys, customer credentials, BYOK key references

Different controls apply to each level (encryption, access logging, retention, sharing).

### 7.2 Data Minimization

Customer data is processed only for the documented purposes in our DPA: serving the Acme Cloud functionality, security monitoring, and operational support. We do not use customer data for training our own models, marketing, or sale.

### 7.3 Data Deletion

Customers can delete data via the API or UI. Soft-deleted records are unrecoverable to other tenants immediately and physically purged from primary storage within 30 days. Backup copies expire under their normal retention policy (30 days). Vector store entries and search indexes are purged within 24 hours of soft-delete.

Upon contract termination, all customer data is purged within 30 days. Customers may request a deletion certificate.

## 8. Compliance Posture

We hold the following active certifications and attestations:

- **SOC 2 Type II** (annually since 2018; current report covers Jan–Dec 2025)
- **ISO/IEC 27001:2022** (since 2023; certificate ISMS-2026-04711)
- **ISO/IEC 27017:2015** (cloud-specific extension)
- **ISO/IEC 27018:2019** (PII in public cloud)
- **PCI DSS Service Provider Level 1** (for payment-handling features)
- **HIPAA Business Associate Agreement** available with appropriate safeguards
- **StateRAMP Authorized** (Moderate, since 2024)
- **TX-RAMP Level 2** certification
- **FedRAMP Moderate** authorization in progress (target Q3 2026)

## 9. Incident Response

A documented Incident Response Plan (IRP v5.0) governs how we detect, contain, eradicate, and recover from security incidents. See the Incident Response Runbook document for the full procedure, including escalation paths, customer-notification SLAs, and post-incident review process.

In summary:
- 24/7 on-call rotation with primary, secondary, and incident commander roles
- Customer notification within 72 hours for confirmed material impact
- Public post-mortem published within 14 days for significant incidents

## 10. Trust Portal

For real-time control evidence, certificate downloads, subprocessor list, and security questionnaire prefills, visit https://trust.acmecloud.com.

For security questions or to report a vulnerability: security@acmecloud.com (PGP key on the trust portal).
