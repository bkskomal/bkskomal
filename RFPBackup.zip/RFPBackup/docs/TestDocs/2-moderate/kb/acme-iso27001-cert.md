# Acme Cloud — ISO 27001:2022 Certification

**Certificate number:** ISMS-2026-04711
**Issued by:** A-LIGN Compliance and Security, Inc. (an ANAB-accredited Certification Body)
**Issue date:** February 14, 2026
**Expiry date:** February 14, 2029
**Surveillance audits:** Annual (next: February 2027)
**Standards covered:** ISO/IEC 27001:2022, ISO/IEC 27017:2015, ISO/IEC 27018:2019

## 1. Scope of Certification

The Information Security Management System (ISMS) of Acme Cloud, Inc. covers the design, development, operation, and support of the Acme Cloud SaaS platform (the "Service") and all internal corporate systems that personnel use to develop, operate, and support the Service.

The certification scope is documented in the Statement of Applicability (SoA), version 7.3, and includes:

- All production data centers, regions, and availability zones operated by Acme
- All development, staging, and pre-production environments
- All employee laptops and mobile devices with logical access to customer data
- All Acme-managed source code repositories, build pipelines, and artifact stores
- All third-party integrations used in the operation of the Service (subprocessors)

**Excluded from scope:** End-customer environments and devices; customer-installed integrations that connect to but are not operated by Acme; the Acme corporate website (no customer data).

## 2. Statement of Applicability — Annex A Controls

ISO/IEC 27001:2022 defines 93 controls across four themes (Organizational, People, Physical, Technological). All 93 controls are applicable and implemented in our ISMS.

### 2.1 Organizational Controls (37 controls)

- A.5.1 Information security policies — reviewed annually, last review January 2026
- A.5.2 Information security roles and responsibilities — defined in our security charter; CISO reports to CEO with dotted line to Audit Committee
- A.5.7 Threat intelligence — feed from Recorded Future, US-CERT, and ISAC industry groups
- A.5.10 Acceptable use of information and other associated assets — annual training, signed acknowledgment
- A.5.16 Identity management — Okta as identity provider; SCIM provisioning; quarterly access reviews
- A.5.17 Authentication information — hardware-backed MFA mandatory for all employees; password manager required
- A.5.20 Addressing information security within supplier agreements — DPA + Security Addendum required for all subprocessors
- A.5.30 ICT readiness for business continuity — RTO 4 hours, RPO 1 hour for production data; tested quarterly

### 2.2 People Controls (8 controls)

- A.6.1 Screening — background checks for all employees with access to customer data; renewed every 3 years
- A.6.3 Information security awareness, education and training — onboarding security course + monthly phishing simulation + annual recertification
- A.6.4 Disciplinary process — documented, reviewed annually
- A.6.7 Remote working — endpoint security baseline (CrowdStrike, BitLocker/FileVault, screen-lock); VPN required for non-public production access

### 2.3 Physical Controls (14 controls)

Physical security at our data centers is provided by AWS, GCP, and Azure under their respective security controls. We have inspected their SOC 2 reports and ISO 27001 certificates as part of our supplier evaluation.

For Acme corporate offices: badge access, video surveillance, visitor logs, and clear-desk policy. Office hours visit logs retained for 1 year.

### 2.4 Technological Controls (34 controls)

- A.8.2 Privileged access rights — JIT elevation via internal access broker; standing production access limited to 4 SREs
- A.8.3 Information access restriction — RBAC at app level; tenant isolation enforced at database, vector store, and storage layers
- A.8.5 Secure authentication — MFA enforced; SSO supported via SAML 2.0
- A.8.7 Protection against malware — CrowdStrike on all endpoints; daily malware definition updates; runtime protection enabled
- A.8.8 Management of technical vulnerabilities — Snyk + Dependabot for dependencies; weekly external pen-test scan; quarterly internal scan; critical CVEs patched within 7 days
- A.8.9 Configuration management — IaC via Terraform; configuration drift detection daily
- A.8.16 Monitoring activities — Datadog + Splunk; 24/7 SOC; logs retained 13 months
- A.8.20 Network security — segmented VPCs; private subnets for data layer; egress restricted to allowlisted destinations
- A.8.24 Use of cryptography — AES-256-GCM at rest, TLS 1.3 in transit, FIPS 140-2 Level 2 validated modules
- A.8.28 Secure coding — secure SDLC documented; Snyk + Semgrep on every PR; security champions in each engineering team

## 3. ISO/IEC 27017 — Cloud-Specific Controls

ISO 27017 extends 27001 with cloud-specific guidance. We comply with all applicable controls including:

- CLD.6.3.1 Shared roles and responsibilities — published shared responsibility model
- CLD.8.1.5 Removal of cloud service customer assets — secure deletion within 30 days of contract termination, with deletion certificate available
- CLD.9.5.1 Segregation in virtual computing environments — multi-tenant isolation at network, compute, storage, and key levels
- CLD.12.1.5 Administrator's operational security — separate admin accounts, MFA, audit logging
- CLD.12.4.5 Monitoring of cloud services — customer-accessible audit logs available via API
- CLD.13.1.4 Alignment of security management for virtual and physical networks — unified security policy across both layers

## 4. ISO/IEC 27018 — PII in Public Cloud

ISO 27018 covers PII protection. Beyond 27001/27017 we additionally:

- Process customer PII only on documented customer instructions (DPA terms)
- Provide tools for customers to fulfill data subject rights (access, deletion, portability, correction)
- Notify customers of subpoenas or legal demands for their data unless legally prohibited
- Support customer choice over geographic processing location (EU, US, APAC, multi-region)
- Disclose all subprocessors that handle customer PII; 30-day advance notice for additions
- Return or securely delete all PII upon contract termination, customer choice

## 5. Risk Assessment Summary

The ISMS includes a documented risk assessment methodology (Risk Owner Responsibility Matrix, RORM v3.1). Risks are scored on Likelihood (1–5) × Impact (1–5) and tracked in our GRC tool.

Top current risks (Q1 2026):
1. **Supply chain compromise of npm dependencies** — Score 12. Treatment: Snyk + GitGuardian + dependency pinning + minimum 7-day age requirement for new releases
2. **Misconfigured customer SAML settings allowing unauthorized access** — Score 8. Treatment: SSO Connection Wizard with built-in test mode; mandatory test login before activation
3. **AI-assisted social engineering of support staff** — Score 6. Treatment: Quarterly red team exercises; voice authentication on phone-based account changes; ticketing-only for sensitive operations

## 6. Internal Audit Program

Quarterly internal audits cover one quarter of the SoA each cycle (so the full ISMS is audited annually). Internal auditors are independent of the audited function. Findings are tracked to closure in our GRC tool.

Last internal audit (December 2025): 4 minor findings, all closed within 30 days. Zero major findings.

## 7. Management Review

The ISMS is reviewed quarterly by the Information Security Steering Committee, chaired by the CISO and including representatives from Engineering, Legal, HR, Product, and Customer Success. Outputs include risk treatment decisions, control modification approvals, and resource allocation.

## 8. Continual Improvement

The ISMS includes a documented improvement process. Improvements identified in 2025 included:

- Migration from password-based to passkey-based MFA for all employees (completed Q3 2025)
- Adoption of Sigstore signing for all production container images (completed Q4 2025)
- Rollout of in-line eBPF-based runtime protection on all production hosts (completed Q4 2025)
- Move to a zero-trust network architecture for all internal corporate access (in progress; target Q2 2026)

## 9. Related Documentation

- Information Security Policy v6.2
- Acceptable Use Policy v4.1
- Incident Response Plan v5.0
- Business Continuity and Disaster Recovery Plan v3.4
- Data Retention and Destruction Policy v2.7
- Statement of Applicability v7.3
- Risk Assessment and Treatment Plan v4.2

All documents available to enterprise customers under NDA via https://trust.acmecloud.com.

## 10. Validity Verification

Customers may verify this certificate at https://www.a-lign.com/cert-verify by entering certificate number ISMS-2026-04711. The certification body (A-LIGN) is accredited by ANAB (the ANSI National Accreditation Board) under accreditation number ISO/IEC 17021-1:2015.
