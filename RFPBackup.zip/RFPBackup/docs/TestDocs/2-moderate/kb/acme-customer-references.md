# Acme Cloud — Customer References

**Note:** All references are real customers; permission to use as a reference granted under their MSA. Specific outcomes are based on customer-confirmed metrics.

## 1. Reference Customers (Available for Calls)

### Pinnacle Trust (Financial Services)

**Industry:** Wealth management
**Employees:** 8,400
**Acme Users:** 240 (sales engineering, security, compliance teams)
**Use case:** Responding to RFPs from institutional asset owners (pension funds, endowments). Average RFP has 180 questions; previously took 7 person-weeks per RFP.
**Outcome:** Time to respond reduced from 7 person-weeks to 1.5 person-weeks (78% reduction). Win rate on RFPs >$5M improved from 22% to 31%. Estimated incremental revenue: $14M annually.
**Acme tier:** Enterprise; deployed since 2022.
**Reference contact:** Available via Acme sales.

### Helix Medical Group (Healthcare)

**Industry:** Multi-specialty medical group (380 physicians, 2.4M patients)
**Employees:** 6,200
**Acme Users:** 95 (procurement, IT security, compliance)
**Use case:** Responding to RFPs from health insurance plans, hospital networks, and government contracts; responding to vendor security questionnaires from EHR vendors and pharmaceutical partners.
**Outcome:** Reduced time-to-respond for vendor security questionnaires from average 12 days to 3 days. Increased acceptance rate of submitted RFPs by 18%. Materially improved compliance team capacity.
**Acme tier:** Platinum; deployed since 2023.
**Reference contact:** Available via Acme sales.

### Quantum Logistics (Technology)

**Industry:** Supply chain and logistics SaaS
**Employees:** 1,800
**Acme Users:** 45 (sales engineering, security, customer success)
**Use case:** Customer-facing security questionnaires (SOC 2 prefills, CAIQ, custom enterprise customer questionnaires) and inbound RFPs.
**Outcome:** Eliminated the security questionnaire backlog (was 14-day average response; now 2 days). Released 1.5 FTE-equivalent capacity from sales engineering for product development.
**Acme tier:** Platinum; deployed since 2024.
**Reference contact:** Available via Acme sales.

### State of Vermont — Department of Information and Innovation (Public Sector)

**Industry:** US state government
**Employees in scope:** 60 (procurement digitization initiative)
**Acme Users:** 60
**Use case:** Vendor RFP digitization — receive structured proposals from vendors and accelerate evaluation. Also supports preparation of state-issued RFPs.
**Outcome:** First state to deploy a vendor-AI-assisted procurement workflow. Cut average vendor evaluation cycle from 90 days to 45 days. Public case study at https://acmecloud.com/customers/vermont.
**Acme tier:** Enterprise (StateRAMP-certified deployment); deployed since 2024.
**Reference contact:** Available via Acme sales.

### Beacon Networks (Technology / Telecommunications)

**Industry:** Enterprise networking equipment and services
**Employees:** 4,200
**Acme Users:** 78 (sales engineering, security, compliance, marketing)
**Use case:** Bid response for federal and state government RFPs. Heavy compliance content (FedRAMP, FISMA, NIST 800-53). Multi-million-dollar deals.
**Outcome:** Increased federal RFP submission velocity by 60% (more bids per quarter with same headcount). Won 3 multi-year federal contracts in first year of deployment ($28M total contract value), including 1 they wouldn't have bid on without Acme due to deadline pressure.
**Acme tier:** Enterprise; deployed since 2023.
**Reference contact:** Available via Acme sales.

### Coastal Federal Credit Union (Financial Services)

**Industry:** Credit union (regulated by NCUA)
**Employees:** 1,200
**Acme Users:** 22
**Use case:** Vendor security assessments — when reviewing new fintech partners, send them an Acme-generated questionnaire and ingest their responses.
**Outcome:** Standardized vendor risk assessment across the organization. Reduced average time-to-decision on new vendor partnerships from 11 weeks to 4 weeks.
**Acme tier:** Gold; deployed since 2023.
**Reference contact:** Available via Acme sales.

### Cascade BioWorks (Pharmaceutical / Biotech)

**Industry:** Biopharmaceutical (Phase 2 clinical-stage company)
**Employees:** 380
**Acme Users:** 18
**Use case:** Responding to due diligence questionnaires from potential pharma partners and investors. CMO/CRO partner contracts. Investor-driven security audits.
**Outcome:** Closed Series C with a 6-week diligence cycle (industry typical 12+ weeks). Closed two pharma partnerships that required extensive technical / regulatory diligence.
**Acme tier:** Gold; deployed since 2024.
**Reference contact:** Available via Acme sales.

### Polaris Software (Technology / Enterprise SaaS)

**Industry:** Enterprise B2B SaaS
**Employees:** 850
**Acme Users:** 34
**Use case:** Customer security questionnaires (CAIQ, SIG, custom enterprise questionnaires). Investor security diligence.
**Outcome:** 92% of customer security questionnaires now responded to within 5 business days of receipt (was 38%). Material acceleration of enterprise sales cycle (median 14 days reduction in time-to-close).
**Acme tier:** Platinum; deployed since 2023.
**Reference contact:** Available via Acme sales.

## 2. Industry Coverage

We have customers in:

- **Financial Services** (60+ customers): banks, credit unions, asset managers, fintech, insurance
- **Healthcare** (45+ customers): provider organizations, payers, pharma, biotech, medical devices
- **Technology** (200+ customers): SaaS, infrastructure, security vendors, AI/ML companies
- **Public sector** (15+ customers): US states, counties, agencies; Canadian provinces; Australian state and federal
- **Industrials and energy** (30+): manufacturing, utilities, mining, defense
- **Professional services** (40+): consulting firms, legal services, accounting
- **Education** (20+): higher-education institutions, edtech vendors
- **Retail and consumer** (50+): retail chains, e-commerce, CPG

For specific industry references during your evaluation, contact your Acme sales representative.

## 3. By Use Case

### Inbound RFP / Bid Response (~70% of customers)
You receive RFPs and need to respond to them. Common in sales engineering, capture management, proposal teams.

### Customer Security Questionnaires (~50% of customers)
Your customers send you security/compliance questionnaires (CAIQ, SIG, custom). Common for SaaS vendors selling to enterprise.

### Vendor Risk Assessment (~30% of customers)
You evaluate prospective vendors and need to gather + assess their responses. Common in IT, security, procurement teams at large organizations.

### Investor / Partner Diligence (~25% of customers)
Fundraising or partnership-formation diligence. Common in scaling startups.

### Internal Knowledge Q&A (~20% of customers)
Conversational interface over a corporate knowledge base. Slack-integrated.

### RFP / RFQ Issuance (~15% of customers)
You're on the buyer side — you issue RFPs to vendors and need to evaluate responses.

(These percentages overlap: most customers use multiple modules.)

## 4. Sample Outcomes Across the Customer Base

Aggregated metrics from our 2025 customer survey (N = 1,140 respondents):

- **Average reduction in time-to-respond:** 67%
- **Average increase in win rate (where measured):** 14 percentage points
- **Time-to-value:** median 4 weeks for first complete RFP response on platform
- **Customer-reported NPS:** 72
- **Annual gross retention:** 96%
- **Annual net revenue retention:** 134%
- **Average contract value growth (cohort, year-over-year):** 41%

## 5. Public Case Studies

Detailed case studies (with customer permission) at https://acmecloud.com/customers:

- Pinnacle Trust: How a wealth manager 5x'd RFP throughput
- Vermont DII: First state-level AI-assisted procurement
- Beacon Networks: Won $28M in federal contracts they wouldn't have bid on
- Cascade BioWorks: 6-week Series C diligence
- Helix Medical Group: From 12-day to 3-day questionnaire turnaround

## 6. Customer Advisory Board

Acme operates a Customer Advisory Board (CAB) with rotating membership across customer industries and tiers. CAB members provide product feedback, beta-test new features, and inform our roadmap. Membership is by invitation; current CAB has 18 customers across 7 industries.

For interest in CAB participation: cab@acmecloud.com.

## 7. Reference Process

To request reference calls during your evaluation:

1. Contact your Acme sales rep with your specific reference criteria (industry, use case, company size, deployment maturity)
2. Acme proposes 2–3 references that match
3. Customer reference is contacted; if they consent, a 30-minute call is scheduled
4. Typical turnaround: 1–2 weeks
5. We don't pay our references; they participate as part of their MSA terms

We have ~140 customers who have opted in as available references. Most agree to 2–3 calls per year.
