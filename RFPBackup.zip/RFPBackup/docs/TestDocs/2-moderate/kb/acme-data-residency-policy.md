# Acme Cloud — Data Residency and Privacy Policy

**Version:** 3.4 — January 2026
**Effective:** Immediately for new customers; existing customers on previous version until renewal

## 1. Where Customer Data Lives

Each Acme Cloud tenant is provisioned in a single primary region selected by the customer at onboarding. **All customer data — primary storage, embeddings, vector store entries, search indexes, audit logs, and backups — stays in the chosen region.** No customer data crosses region boundaries except where explicitly opted in (e.g., cross-region disaster recovery on Enterprise tier).

Available regions (as of February 2026):

| Region | Code | Cloud | Data residency |
|---|---|---|---|
| US East | us-east-1 | AWS Northern Virginia | Continental US |
| US West | us-west-2 | AWS Oregon | Continental US |
| Canada | ca-central-1 | AWS Montréal | Canadian sovereign |
| EU West | eu-west-1 | AWS Ireland | EU/EEA |
| EU Central | eu-central-1 | AWS Frankfurt | EU/EEA, Germany-only option available |
| UK | eu-west-2 | AWS London | UK (post-Brexit data sovereignty) |
| Asia-Pacific Sydney | ap-southeast-2 | AWS Sydney | Australia (per APRA CPS 234) |
| Asia-Pacific Tokyo | ap-northeast-1 | AWS Tokyo | Japan |
| Asia-Pacific Singapore | ap-southeast-1 | AWS Singapore | Singapore |
| GovCloud (in progress) | us-gov-west-1 | AWS GovCloud | US Federal, FedRAMP Moderate |

Region selection is made at organization creation. Existing tenants can request a region migration; the migration takes 24–72 hours of coordinated downtime depending on data volume.

## 2. Subprocessor Data Locations

Subprocessors handling customer data observe the same regional boundaries:

- **Anthropic (LLM):** When using Acme-managed Claude, requests are routed to the Anthropic endpoint in the customer's region (US: us-east-1, EU: eu-west-1). Anthropic is contractually bound (DPA) to not retain or train on customer prompts/completions for the API path.
- **OpenAI (LLM, alternative):** When using Acme-managed GPT-4o, requests are routed to OpenAI's regional endpoint. OpenAI's API path is not used for training (per their data usage policy for paid API).
- **AWS (infrastructure):** Customer's chosen region only.
- **Datadog (observability):** EU customer logs go to Datadog's EU region (datadoghq.eu); US customers go to US (datadoghq.com). Customers can opt out of Datadog logs entirely if their compliance posture requires (logs go to a customer-managed S3 bucket instead).
- **Cloudflare (edge):** Cloudflare's network is global, but TLS termination happens at the nearest edge to the request — the customer's choice of "Hold" mode on the EU-only routing rule keeps EU customer requests within Cloudflare's EU edge nodes.
- **Twilio (voice/SMS for MFA):** Regional MFA endpoints; EU customers' MFA delivery goes via Twilio's EU infrastructure.

The full subprocessor list, with data flow descriptions and regional boundaries, is published at https://acmecloud.com/subprocessors. We notify all customers 30 days before any change to the subprocessor list.

## 3. Cross-Border Data Transfers

For EU/UK/Switzerland customers, Acme commits to Standard Contractual Clauses (EU SCCs 2021/914) as the lawful transfer mechanism for any limited cross-border processing (e.g., support tickets that may briefly include excerpts of customer data when handled by US-based engineers under temporary access).

Specifically:
- Customer data at rest: stays in chosen region (no cross-border transfer)
- Customer data in transit: customer-region only
- Support exception: when a customer authorizes access via the JIT broker, the engineer may view excerpts. If the engineer is in a different jurisdiction, the SCCs cover the brief processing.

For US-based customers, no SCCs needed (no EU data subjects involved).

For UK-based customers, the UK International Data Transfer Addendum to the EU SCCs is included.

For Swiss customers, the Swiss Federal Data Protection Act applies; we comply with FDPIC requirements.

## 4. GDPR Compliance

For EU/EEA/UK data subjects, Acme acts as a **Data Processor** processing personal data on instructions from the customer (Data Controller).

Our DPA includes:
- Documented purpose limitations
- Sub-processor change notifications (30 days)
- Data subject rights tooling (access, deletion, rectification, portability, objection)
- Data Protection Impact Assessment (DPIA) support
- 72-hour breach notification commitment
- Audit rights for the controller
- Data return/deletion at termination

### 4.1 Data Subject Access Requests (DSARs)

Customers can fulfill DSARs from their tenants using:
- **Access:** Export tool (UI + API) returns all personal data tied to a specific identifier (email, employee ID)
- **Deletion:** Soft-delete in the UI; permanent purge within 30 days (also from backups under the normal retention cycle)
- **Rectification:** Edit tool for any record holding personal data
- **Portability:** Export in JSON or CSV
- **Objection / restriction:** Per-user processing flags

Acme assists customers with DSARs within 5 business days of request. We don't process DSARs directly from data subjects (we forward them to the customer organization, who is the controller).

### 4.2 Data Categories Processed

We process the following customer-provided data:
- Customer organization metadata (name, billing address)
- User identities (name, email, role, last login)
- Customer-uploaded documents (knowledge base content + RFP docs)
- Generated answers (model output tied to a question)
- Audit logs (what user did what action when)

We don't intentionally process:
- Special category data (health, biometrics, etc.) — but customers may upload such content into their KB; in that case, customer is responsible for compliance
- Children's data (Acme is not a children's product; account holders must be 18+)

## 5. Data Retention

| Data category | Retention |
|---|---|
| Knowledge base content | Indefinite while subscription is active |
| Generated responses | Indefinite while subscription is active |
| Audit logs | 90 days (Silver), 1 year (Gold), 7 years (Platinum), custom (Enterprise) |
| Daily backups | 30 days |
| Cross-region backup snapshots | 30 days |
| Cold archive (Glacier) | 7 years for audit-relevant logs |
| Deleted user data | 30 days hard-purge |
| Cancelled subscription data | 90-day grace period for export, then permanent deletion |

Customers can configure their own retention windows (within Acme-supported ranges) per data category via tenant settings.

## 6. Encryption Posture

All customer data is encrypted at rest with AES-256-GCM using per-tenant Customer Master Keys (CMKs). For Enterprise tier, customers can BYOK their own keys via AWS KMS, Azure Key Vault, or GCP Cloud KMS. Detailed encryption controls are in the Security Whitepaper.

## 7. Government Access Requests

We respond to lawful government requests for customer data using a documented process:

1. We push back on overly broad requests
2. We notify the affected customer unless legally prohibited from doing so
3. We minimize disclosure to what's specifically required
4. We post an annual transparency report at https://acmecloud.com/transparency

Calendar year 2025 numbers (published February 2026):
- Subpoenas received: 11
- Subpoenas responded to in full: 4 (after narrowing scope)
- Subpoenas where customer was notified: 9
- National security letters / gag orders: legally cannot disclose specifics; canary statement at https://acmecloud.com/canary

For BYOK Enterprise customers, even a lawful subpoena to Acme cannot give the requester plaintext access — the customer's keys remain in the customer's KMS.

## 8. Data Localization Specifics

### 8.1 EU GDPR

EU customer data stays in EU regions. Subprocessors with EU presence used. EU SCCs in place. EU representative appointed (Acme Cloud Ireland Limited). Data Protection Officer reachable at dpo@acmecloud.com.

### 8.2 UK Data Protection Act

UK customer data stays in UK region. UK SCCs addendum to EU SCCs. UK representative: Acme Cloud (UK) Limited.

### 8.3 Australia (APRA CPS 234)

Australian financial-services customers can elect Sydney region. We meet APRA CPS 234 requirements for outsourced cloud service providers.

### 8.4 Singapore (PDPA)

Singapore region available. We meet PDPA requirements for cross-border transfer (where applicable).

### 8.5 Canada (PIPEDA)

Canadian region (Montréal) available. PIPEDA-compliant DPA.

### 8.6 US Federal

GovCloud region in progress (Q3 2026). FedRAMP Moderate authorization in progress. Currently StateRAMP Authorized for state and local government use. TX-RAMP Level 2 certified.

## 9. Customer's Use of Personal Data in the KB

When customers upload documents containing personal data of EU/UK data subjects, the customer remains the Data Controller. Acme's role as Processor is governed by the DPA. Customers are responsible for:

- Lawful basis for processing
- Data subject notice (transparency)
- DSAR fulfillment (with Acme's assistance per the DPA)
- Restricting upload of inappropriate special-category data unless they have a lawful basis

We provide tooling but don't substitute customer's compliance program.

## 10. Contact

For privacy/GDPR questions: dpo@acmecloud.com
For data residency questions: trust@acmecloud.com
For DSAR assistance: support@acmecloud.com (route to your tenant admin first)
For breach notification: security@acmecloud.com (PGP key on trust portal)
