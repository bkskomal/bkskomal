# Acme Cloud — Architecture Overview

**Version:** 5.2 — February 2026
**Audience:** Solutions architects, customer technical evaluators, procurement technical reviewers

## 1. Logical Architecture

Acme Cloud follows a classic three-tier architecture with strict tenant isolation throughout.

### 1.1 Edge

- **Cloudflare** for CDN, WAF, DDoS protection, and bot mitigation
- **Anycast DNS** with global routing
- TLS 1.3 termination at the edge with cert pinning available for paranoid customers
- Edge logic in Cloudflare Workers for region-aware request routing (a request from EU is routed to the nearest EU region)

### 1.2 Application Tier

- **Next.js 15 (App Router)** for the web UI and Server Components
- **REST API** built on Node.js, deployed as containerized services in Amazon EKS / GKE / AKS depending on region
- **Authentication** via NextAuth v5 (sessions in DB) supporting magic-link, OAuth (Google, GitHub, Microsoft), SAML 2.0, and Bearer API keys
- **Background workers** for ingestion, embedding, generation, and pipeline orchestration (separate worker pools so no synchronous request blocks on heavy work)
- **Per-tenant rate limits** enforced at the application layer (token bucket, configurable via OrgAiConfig)

### 1.3 AI Tier

- **LLM provider** is per-org configurable. Default is Acme-managed (Claude Sonnet 4.5 via Anthropic), with BYO support for OpenAI, Anthropic direct, OpenRouter, Together.ai, vLLM, Ollama, and any OpenAI-compatible endpoint
- **Embedding model** defaults to Xenova/all-MiniLM-L6-v2 in-process (384-d). Per-org override to OpenAI text-embedding-3-large (3072-d) or any OpenAI-compatible embedder
- **Vector store** per-tenant choice: Postgres (Float[]) or Milvus (HNSW + sparse)
- **Multimodal** via CLIP (Xenova/clip-vit-base-patch32, 512-d) for image-as-vector storage and search
- **Reranker** for high-stakes single answers via the per-org LLM (deterministic ranking pass)
- **Vision-LLM OCR** for scanned PDFs and embedded images (uses the per-org LLM if it supports vision)

### 1.4 Data Tier

- **Postgres 16** (with pgvector extension) for primary OLTP plus default vector store
- **Milvus** standalone or Zilliz Cloud for production-scale vector store on Platinum/Enterprise
- **S3** (or GCS / Azure Blob) for file storage, encrypted at rest with per-tenant CMKs
- **Redis** (optional) for distributed rate limiting and ephemeral caches
- **etcd + minio** when Milvus is deployed standalone

### 1.5 Observability

- **Pino** structured logging with AsyncLocalStorage-propagated request IDs
- **Prometheus** metrics exposed at `/api/metrics`
- **Grafana** dashboards (pre-provisioned in the Docker stack)
- **Datadog** for production SaaS deployments (APM, logs, infrastructure)
- **Splunk** for SIEM correlation
- **Audit log** in Postgres with composite indexes for fast retrieval

## 2. High Availability

### 2.1 Within a Region

Each region runs across at least three availability zones (AZs) in active-active mode.

- **App tier:** EKS deployment with min 3 replicas per service, distributed across AZs by topology spread constraints
- **Postgres:** Multi-AZ RDS with automated failover; standby in synchronous replication mode
- **Milvus:** standalone deployment with shard replication across AZs (for Enterprise; Platinum uses single-AZ Milvus with hot snapshots)
- **S3:** native AWS multi-AZ durability (99.999999999%)
- **Load balancers:** AWS ALB with health checks; unhealthy instances automatically removed from rotation

Failover scenarios:
- AZ failure: traffic shifts to remaining AZs within ~30 seconds (DNS TTL + health check interval). Customer-facing impact: zero downtime.
- Single-instance failure: Kubernetes restarts the pod; ALB removes from rotation during the restart. Customer impact: a few in-flight requests may fail and need retry.
- Database primary failure: RDS triggers failover to standby. Customer impact: ~30 seconds of degraded service while the standby is promoted.

### 2.2 Across Regions

Cross-region disaster recovery is available on Enterprise tier:
- Backup region maintained in warm standby
- Continuous replication of customer data with documented RPO ≤ 1 hour
- Documented runbook for region cutover with target RTO ≤ 4 hours
- Quarterly cutover drills (the most recent drill — January 2026 — completed in 2h 47m)

For Platinum tier, customer data is backed up to a separate region but not actively maintained for failover. Customer can request a manual region restore (24-hour SLA).

## 3. Multi-Tenant Isolation

Tenant isolation is enforced at every layer:

### 3.1 Database
- All customer-data tables have a non-null `organizationId` column
- All Prisma queries filter by `organizationId` (enforced by code review + automated linter)
- Row-level security policies in Postgres provide a defensive second layer

### 3.2 Vector Store
- **Postgres backend:** filter by `organizationId` via JOIN to Document → KnowledgeIndex → Organization
- **Milvus partition mode (default):** `partition_key = organizationId`; one collection serves all orgs but searches scope to a single partition
- **Milvus collection mode (optional, Enterprise):** one collection per org; structurally impossible to mix data

### 3.3 File Storage
- S3 prefix-per-org: `s3://acme-uploads-{region}/{orgId}/...`
- IAM policies restrict the application's role to its own org's prefix at the request layer

### 3.4 Encryption
- One CMK per tenant in AWS KMS (or customer-managed for BYOK)
- Cross-tenant decryption impossible — even Acme staff don't have access

### 3.5 Compute
- For Enterprise tier with dedicated infrastructure, customer gets their own EKS namespace with hard CPU/memory limits and network policy isolation
- For shared multi-tenant, fairness enforced via per-tenant rate limits (token bucket) and queue priority

## 4. Scaling Limits

Tested production limits:

- **Documents per index:** 1,000,000+ (largest customer)
- **Chunks per index:** 50,000,000+
- **Concurrent users per tenant:** 5,000 sustained, 20,000 burst
- **Concurrent generations per tenant:** 50 sustained, 200 burst (configurable)
- **API throughput per tenant:** 10,000 req/sec sustained
- **File upload size:** 250 MB per file (default), can extend to 2 GB for Enterprise
- **Single doc page count:** no hard limit; tested with 8,000-page PDFs
- **RFP question count:** 5,000 per project (highest seen in production)

Hot-side metrics to monitor capacity:
- Vector search p99 latency (target < 200ms)
- LLM call queue depth (target < 5)
- Background worker queue depth (target < 50)

If the queue depth exceeds threshold, the tenant is automatically scaled (additional worker pods spawned) and the tenant admin gets a notification.

## 5. Network Architecture

```
                     ┌─────────────┐
   Public Internet   │  Cloudflare  │
   ───────────────►  │   (Edge +    │
                     │   WAF/DDoS)  │
                     └──────┬───────┘
                            │ TLS 1.3
                            ▼
                     ┌─────────────┐
                     │   AWS ALB    │   (per region)
                     └──────┬───────┘
                            │
                            ▼
              ┌──────────────────────────┐
              │   App Tier (EKS)         │
              │   - Next.js              │
              │   - API workers          │
              │   - Background workers   │
              └──────┬─────────┬─────────┘
                     │         │
              mTLS   │         │   Vault tokens
                     ▼         ▼
              ┌──────────┐  ┌─────────┐
              │ Data Tier│  │  Vault  │  (secret management)
              │ - RDS    │  └─────────┘
              │ - Milvus │
              │ - S3     │       │
              │ - Redis  │       │ HSM-backed
              └──────────┘       ▼
                          ┌──────────┐
                          │ AWS KMS  │
                          │  (CMK)   │
                          └──────────┘
```

All tier boundaries enforced with security groups (default-deny). No data-tier component is reachable from the public internet.

## 6. Deployment Patterns

### 6.1 Standard SaaS (most customers)

Acme operates the platform; customer accesses via web/API.

### 6.2 Single-Tenant SaaS (Enterprise)

Customer's tenant runs on dedicated infrastructure (own VPC, own database, own Milvus cluster) inside Acme's account. Acme operates it. Allows customers to demand specific compliance posture or guaranteed capacity.

### 6.3 Customer-VPC Deployment (Enterprise)

Acme deploys the platform into the customer's AWS / GCP / Azure account. Customer owns the data and infrastructure; Acme operates and updates the application. Common for customers with strict data residency requirements (defense, government, regulated finance).

### 6.4 Air-Gapped / Self-Hosted (special)

Customer takes the container images and runs them in their own data center. We provide a self-hosted license with a quarterly update cadence. Limited integration support (customer responsible for connectivity to LLM, DB, Milvus). Used by ~12 customers with extreme isolation requirements.

## 7. Update and Maintenance

- **Standard SaaS:** updates deployed continuously; customers see no maintenance windows. Backwards-incompatible API changes require 6-month deprecation period.
- **Customer-VPC:** monthly update cycle. We provide upgrade automation and pre-test releases in customer's staging.
- **Self-hosted:** quarterly update releases. We provide release notes 30 days in advance.

## 8. Performance SLAs

- API response time p95: < 500ms for read endpoints; < 2s for retrieval
- Generation latency p50: 8 seconds for a typical RFP question (BYO model dependent)
- Search latency p99: < 200ms over 10M-chunk corpus
- Webhook delivery: 99.9% within 5 seconds of event
- Uptime: per tier (99.5% Silver, 99.9% Gold, 99.99% Platinum)

SLA breach credits per the MSA: failure to meet uptime SLA in any month entitles the customer to a service credit equal to 10% of monthly fees (single breach) up to 100% (sustained breach).
