# Acme Cloud — Implementation Guide

**Version:** 4.0 — January 2026
**Audience:** Customer technical leads, project managers, evaluation teams

## 1. Implementation Tier Comparison

| Tier | Duration | Approach | Personnel |
|---|---|---|---|
| **Silver** | 0–3 days | Self-serve | Customer team only |
| **Gold** | 1–2 weeks | Onboarding call + check-in | Onboarding Specialist (Acme), 1 customer admin |
| **Platinum** | 4 weeks | Guided implementation | Onboarding Manager (Acme), Solutions Architect, 1–3 customer admins, 1 customer technical lead |
| **Enterprise** | 8–12 weeks | White-glove implementation | TAM, dedicated SA, Implementation Engineering team, customer technical lead, customer steering committee |

## 2. Standard Implementation Phases (applies to Gold/Platinum/Enterprise)

### Phase 0 — Pre-kickoff (Week 0)

**Acme actions:**
- Contract execution and order processing
- Tenant provisioning in customer-selected region
- Onboarding/Implementation Manager assigned
- Pre-kickoff document shared (questionnaire about goals, integrations, data sources)

**Customer actions:**
- Identify customer technical lead and stakeholders
- Complete pre-kickoff questionnaire
- Identify initial data sources for ingestion

### Phase 1 — Kickoff and Discovery (Week 1)

**Activities:**
- 90-minute kickoff call with Acme + customer team
- Walkthrough of platform capabilities
- Review goals, success metrics, milestones
- Decision on integration scope (which data sources, which systems)
- Decision on initial use case (start narrow; expand later)

**Deliverables:**
- Mutually-agreed implementation plan with milestone dates
- Identified pilot users (typically 5–10 for initial validation)

### Phase 2 — Configuration (Weeks 2–3)

**Activities:**
- Tenant settings (regions, retention, audit log, RBAC)
- SSO setup (SAML configuration with customer's IdP)
- Initial knowledge base ingestion (start with 1 representative source)
- Configure pipeline templates for the chosen use case
- Custom branding (logo, color palette) if applicable
- API key creation for any planned integrations

**Deliverables:**
- Tenant configured to spec
- First 100+ documents indexed
- Pilot users can log in via SSO and use core features

### Phase 3 — Integration (Weeks 3–6)

**Activities:**
- Connect remaining data sources (SharePoint, Confluence, Drive, etc.)
- Set up integrations (Slack notifications, Salesforce link, webhook destinations)
- Configure custom workflows (pipeline templates with org-specific steps)
- Bulk import golden answers from any pre-existing answer libraries
- Stale-source detection rules tuned to org's content lifecycle
- Win/loss outcome tagging back-populated for past RFPs (where data is available)

**Deliverables:**
- Full data source coverage
- All integrations operational
- Knowledge base ready for production use

### Phase 4 — Pilot Run (Weeks 6–8)

**Activities:**
- Pilot users run 2–3 real RFPs through the platform end-to-end
- Acme team observes and provides coaching
- Identify needed customizations or workflow tweaks
- Quality calibration (review generated answers for accuracy, tone, completeness)

**Deliverables:**
- 2–3 completed RFPs as production proof
- User feedback consolidated
- Refinement plan for any quality issues

### Phase 5 — Training and Rollout (Weeks 8–10)

**Activities:**
- Full team training (live or recorded; up to 4 sessions)
- Admin training (separate; 2 sessions)
- Internal launch communications
- Documentation customization (Acme-provided playbooks tailored to customer)

**Deliverables:**
- All users trained
- Internal launch complete

### Phase 6 — Go-Live and Hypercare (Weeks 10–12)

**Activities:**
- Production cutover (if applicable — most orgs use Acme alongside existing process initially)
- Daily check-ins for the first 2 weeks (Acme + customer)
- Issue resolution and tuning
- Hand-off from Implementation team to Customer Success Manager
- 90-day success review scheduled

**Deliverables:**
- Acme is the production tool for the chosen use case
- CSM is the steady-state contact

## 3. Faster Implementations

For smaller scope or simpler integrations, the implementation can compress:

- **Gold + simple use case:** 1 week (e.g., RFP response only, no integrations beyond SSO)
- **Platinum + 1 integration:** 2.5 weeks
- **Enterprise + extensive integration:** 12+ weeks (especially when on-premise or VPC deployment)

We work backward from your target go-live date.

## 4. Implementation Best Practices

Drawn from 2,300+ customer implementations:

### Start narrow, expand once you've succeeded
Don't try to onboard every team and every use case in week 1. Pick one use case (e.g., "sales engineering responding to security questionnaires") and one team (5–15 people). Get them productive. Expand from there.

### Curate the initial knowledge base, don't dump everything
Quality of retrieval depends on quality of source content. 100 well-organized documents beat 10,000 disorganized documents. Prefer the source-of-truth version of each topic; archive duplicates.

### Tag golden answers from past wins
The win/loss feedback loop is materially better when you backfill outcomes for past RFPs. Spend a half-day with sales leadership to tag the last 12 months of RFP outcomes.

### Run a quality calibration in pilot
Don't trust the AI answers blindly — and don't reject them blindly either. Review the first 50 answers with a SME to identify systematic issues (e.g., outdated source content, missing topical coverage). Fix root causes; don't just edit individual answers.

### Designate a single champion
Implementations succeed when one person (typically the customer technical lead) owns the rollout. Distributed ownership leads to drift. Acme's Implementation team partners with that single champion.

### Plan for change management
RFP responding is often emotionally tied to specific people who "know everything." Their workflow is changing. Acknowledge this; involve them in the rollout; show how Acme makes their expertise more leveraged, not less.

## 5. What's NOT Required Before Go-Live

A common over-engineering trap. You do NOT need:

- Every data source integrated before going live (start with the most-cited 1–3)
- Custom pipeline templates for every workflow (use defaults; customize as needs emerge)
- All users trained before any user is productive (do a champion cohort first)
- Win/loss data tagged for every past RFP (do the most recent 12 months; backfill more later)
- Custom branding (skip during pilot; add at general rollout)
- All integrations live (start with SSO + Slack; add the rest incrementally)

## 6. Rollback Plan

In the unlikely event your implementation isn't going well:

- **Pilot rollback** (Weeks 1–4): Pause; redo discovery; adjust scope. No data loss; tenant remains.
- **Full rollback** (Weeks 5+): Cancel the implementation; export all data via Acme's standard export tools; pro-rated refund for unused term.

We've had ~15 implementations rollback in 8 years. Common cause: organizational change at the customer (new CIO, M&A, deprioritization). Less common: technical fit issues — usually we identify these in pre-sales SE engagement.

## 7. Implementation Pricing

Implementation services are listed in the Pricing Tiers document. Summary:

- Silver: $0 (self-serve)
- Gold: $1,500 one-time
- Platinum: $5,000 one-time
- Enterprise: custom (typically $20K–$80K depending on scope)

Implementation fees are invoiced at contract signing. Payment terms match the subscription.

## 8. Post-Implementation Engagement

After go-live, you transition to steady-state support:

- **Customer Success Manager:** quarterly business reviews; ongoing relationship
- **Support team:** day-to-day issue resolution
- **TAM (Enterprise):** weekly check-ins; ongoing technical partnership

We measure post-implementation success via:
- Adoption (active users / week)
- Volume (RFPs / month answered)
- Quality (response accuracy, citation precision)
- Outcome (win rate, time-to-response)

These metrics are surfaced in your Insights dashboard. Your CSM/TAM reviews them with you regularly.

## 9. Reference Implementations

For sample implementation timelines from real customers:

- Helix Medical Group (Platinum, healthcare): 4 weeks, on schedule
- Cascade BioWorks (Gold, biotech): 1.5 weeks, on schedule
- Beacon Networks (Enterprise, telecom): 11 weeks (extended from 10 by 1 week for additional integration scope)
- State of Vermont (Enterprise, public sector): 14 weeks (extended from 12 due to StateRAMP authorization timing)
- Pinnacle Trust (Enterprise, financial services): 9 weeks (compressed from 12 by parallelizing work streams)

## 10. Contact

For implementation questions during your evaluation:
- Solutions Architect (assigned during pre-sales): your direct contact
- Implementation team lead: implementation@acmecloud.com
- General questions: rfp@acmecloud.com

For active customer implementations: your assigned Onboarding Manager or TAM.
