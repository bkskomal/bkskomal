# Acme Cloud — Pricing Tiers

**Effective:** January 2026
**Currency:** USD (multi-currency available on Enterprise tier)
**Billing:** Monthly or annual; annual prepay 17% discount
**Standard contract term:** 12 months (Silver/Gold/Platinum); 12 or 36 months (Enterprise)

## 1. Tier Overview

| Tier | Annual list price (per user) | Minimum users |
|---|---|---|
| Silver | $948/year ($79/month equivalent) | 5 |
| Gold | $2,388/year ($199/month equivalent) | 25 |
| Platinum | $4,788/year ($399/month equivalent) | 100 |
| Enterprise | Custom — contact sales | Custom |

Prices listed are list prices for annual prepay. Monthly billing is 20% higher.

## 2. Volume Discounts

Standard published volume discounts off list:

| User band | Silver | Gold | Platinum |
|---|---|---|---|
| 5–24 | List | n/a | n/a |
| 25–49 | n/a | List | n/a |
| 50–99 | n/a | 5% off | n/a |
| 100–249 | n/a | 10% off | List |
| 250–499 | n/a | 15% off | 8% off |
| 500–999 | n/a | 20% off | 12% off |
| 1000+ | n/a | 25% off | 18% off |

Enterprise pricing is custom per deal — contact sales@acmecloud.com.

## 3. Multi-Year Discounts

- 2-year contract: additional 8% off list
- 3-year contract: additional 15% off list

Multi-year discounts stack with volume discounts.

## 4. What's Included by Tier

### Silver
Up to 5 users. 10 RFPs/month. 10 GB knowledge base. Postgres vector store. Acme-managed LLM. Email support, business hours. 99.5% SLA. 90-day audit log retention. Self-serve onboarding.

### Gold
Up to 25 users (additional users $24/user/month). 50 RFPs/month. 50 GB knowledge base. Postgres vector store. Acme-managed LLM. Email + 24/5 chat support. 99.9% SLA. 1-year audit log retention. Onboarding call included.

### Platinum
Up to 100 users (additional users $40/user/month). 250 RFPs/month. 250 GB knowledge base. Milvus vector store option. BYO LLM supported. SAML SSO. Phone + 24/7 support. 99.99% SLA. 7-year audit log retention. Guided onboarding (4 weeks).

### Enterprise
Custom users, RFPs, knowledge base. Milvus vector store. BYO LLM required. BYOK encryption. SAML SSO + SCIM. All regions. Custom SLA up to 99.999%. Custom audit log retention. Technical Account Manager. White-glove onboarding (8–12 weeks). Dedicated infrastructure available. On-premise / VPC deployment available. Custom DPA. Custom MSA terms.

## 5. Add-Ons (available on any tier)

| Add-on | Price |
|---|---|
| Additional knowledge base storage | $0.18/GB/month |
| Premium parser (LlamaParse) | $0.012/page parsed |
| LLM passthrough metering (BYO key) | $0/month — pass-through cost only |
| Acme-managed Claude Sonnet 4.5 | $0.038/1k tokens (in/out blended) |
| Acme-managed GPT-4o | $0.034/1k tokens (in/out blended) |
| Premium support (24/7 phone) | 15% of contract value |
| Sandbox environment | $400/month per environment |
| Additional regions | $200/month per region |
| Custom integration build | T&M, $250/hour |
| Onsite training | $4,000/day plus expenses |

## 6. Implementation Services

| Tier | Cost | Duration | Includes |
|---|---|---|---|
| Silver | $0 | Self-serve | Documentation, video tutorials, community Slack |
| Gold | $1,500 (one-time) | 1–2 weeks | Onboarding call, sample knowledge base load, kickoff training |
| Platinum | $5,000 (one-time) | 4 weeks | Dedicated onboarding manager, integration setup, custom workflow design, admin training |
| Enterprise | Custom | 8–12 weeks | TAM, full integration build, custom data migration, change management, training program |

## 7. Trial

14-day free trial. Full feature access. No credit card required. Limited to 2 users, 5 RFPs, 1 GB knowledge base. Trials can be extended or expanded by contacting sales.

## 8. Discounts and Special Pricing

- **Non-profit / education:** 30% off list with annual contract
- **Government:** GSA pricing available; StateRAMP and FedRAMP authorized for federal use
- **Startup program:** for venture-backed companies under $20M ARR — 50% off year 1, 25% off year 2 (separate application)

## 9. Payment Terms

- Net 30 invoicing for annual contracts
- Credit card for monthly subscriptions
- ACH, wire, and check accepted for annual
- Multi-currency: USD, EUR, GBP, CAD, AUD, JPY, SGD on Enterprise tier
- Tax: invoiced separately based on customer's billing address; we collect and remit US sales tax in applicable states and EU VAT for EU billing addresses

## 10. Cancellation and Refunds

- Annual contracts auto-renew unless cancelled 30 days before renewal date
- No refunds for partial periods on annual; cancellation effective at end of paid term
- Monthly subscriptions cancellable any time, effective at end of current monthly cycle
- Pro-rated refunds available in case of Acme-side material breach (per MSA Section 14.3)
- Data export available for 90 days post-cancellation; permanent deletion after that

## 11. Custom Pricing for Specific Volumes

For specific seat counts or RFP volumes not shown above, contact sales@acmecloud.com. We can quote any combination of:

- 250+ users
- 5+ regions
- Multi-tenant within a single organization (subsidiary structures)
- Hybrid SaaS + on-premise deployments
- Industry-specific compliance bundles (FedRAMP, HITRUST, PCI Service Provider Level 1, etc.)

Sample custom quote: a financial services org with 1,200 users, 3 regions, BYOK encryption, Premium support, and custom DPA terms typically lands at approximately $2.4M annually with a 3-year commitment. Actual pricing depends on usage profile and negotiated terms.

## 12. Why We Don't Publish Enterprise Pricing

Enterprise pricing varies materially based on:
- Total user count (linear)
- Region count (each region adds infrastructure cost)
- LLM tier (Acme-managed vs BYO; which model)
- BYOK adds key-management overhead
- Custom DPA / MSA negotiation
- Required SLA tier (99.999% requires hot-standby capacity)
- Premium support level

Publishing a single per-user number wouldn't reflect any actual deal. Our sales team can give an indicative quote within 48 hours of an exploratory call.

## 13. References for Pricing Questions

For pricing questions specific to your use case:
- Contact: sales@acmecloud.com
- Custom quote turnaround: 2 business days
- For RFP responses needing pricing, please share the RFP context — we can provide a tailored response section

For procurement / contract questions:
- Master Service Agreement template available at https://acmecloud.com/legal/msa
- Data Processing Addendum at https://acmecloud.com/legal/dpa
- Standard contractual clauses (EU SCCs) included in all DPAs by default
