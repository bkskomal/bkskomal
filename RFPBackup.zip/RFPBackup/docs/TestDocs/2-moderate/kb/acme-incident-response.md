# Acme Cloud — Incident Response Runbook (Public Summary)

**Version:** 5.0 — December 2025
**Audience:** Customer security teams; included in security questionnaire responses

This document is a public summary of our Incident Response Plan (IRP). The full plan is restricted to Acme security personnel; key elements relevant to customers are summarized here.

## 1. Recovery Objectives

These are committed to in our SOC 2 Type II report and in our Master Service Agreement.

| Metric | Commitment |
|---|---|
| **Recovery Time Objective (RTO)** | ≤ 4 hours for full-region failure |
| **Recovery Point Objective (RPO)** | ≤ 1 hour for transactional data; ≤ 24 hours for blob storage |
| **Mean time to detect (MTTD)** | 4 minutes for high-severity events |
| **Mean time to acknowledge (MTTA)** | 7 minutes |
| **Mean time to triage (MTTT)** | 23 minutes |
| **Customer notification SLA** | 72 hours after confirmed material impact |

Quarterly disaster recovery drills validate RTO/RPO; the most recent drill (January 2026) recovered a simulated full-region failure in 2 hours 47 minutes.

## 2. Incident Severity Levels

| Level | Definition | Example |
|---|---|---|
| **SEV-1 (Critical)** | Multi-tenant impact; potential data exposure; service down | All-region outage; confirmed unauthorized data access |
| **SEV-2 (High)** | Single-tenant impact OR significant capability degradation | Single tenant unable to log in; LLM provider outage |
| **SEV-3 (Medium)** | Limited impact; degraded but functional | Slow searches in one region; non-critical feature broken |
| **SEV-4 (Low)** | Minimal impact; no customer perception | Internal tooling broken; documentation outdated |

## 3. On-Call Structure

24/7/365 on-call rotation:

- **Primary:** answers within 5 minutes (PagerDuty)
- **Secondary:** escalation if primary doesn't acknowledge within 10 minutes
- **Incident Commander:** activated for SEV-1 and SEV-2 incidents; coordinates response across teams
- **Engineering leadership:** notified for SEV-1 incidents within 30 minutes
- **CISO:** notified for any security-related SEV-1 within 30 minutes
- **CEO:** notified for any incident affecting > 100 customers or with regulatory disclosure implications

For each engineering team there is a dedicated rotation; the platform-wide on-call covers customer-impacting incidents while team-specific on-calls cover deep-dive expertise.

## 4. Incident Workflow

### 4.1 Detection

Incidents detected via:
- Automated alerts (Datadog, Splunk, CrowdStrike, Falco, Wiz)
- Customer support tickets escalated by support engineers
- Bug bounty submissions (HackerOne)
- Internal security testing (red team, pen test)
- Public disclosures (CVE, Twitter/social, security researcher email)

### 4.2 Triage

The on-call performs initial triage within 23 minutes (mean):
- Confirm the incident is real (not a false positive)
- Assess severity (SEV-1 to SEV-4)
- Identify scope (which tenants, which subsystems, which data)
- Activate Incident Commander if SEV-1 or SEV-2

### 4.3 Containment

Containment actions depend on the incident type:
- For unauthorized access: immediately disable the affected credential, rotate session tokens, restrict the affected user's access
- For service impairment: shift traffic to healthy regions/AZs; spin up additional capacity
- For potential data exposure: isolate affected systems, preserve forensic state, halt affected feature

### 4.4 Eradication

After containment, the response team eradicates the root cause:
- Patch the vulnerability
- Revoke compromised credentials platform-wide
- Update detection rules to catch similar incidents
- Roll back compromised deployments if necessary

### 4.5 Recovery

- Restore normal service operation
- Validate data integrity (especially after containment actions like restoring from backup)
- Communicate with customers about service restoration

### 4.6 Post-Incident Review

Within 14 days for SEV-1, 30 days for SEV-2:
- Documented post-mortem (blameless)
- Root cause analysis
- Action items with owners and due dates
- Public post-mortem published for SEV-1 incidents that affected customers

## 5. Customer Notification

For confirmed material impact to customer data or service:

**SEV-1 (data exposure or significant service impact):**
- Initial notification within 24 hours of confirmed impact
- Detailed update within 72 hours (per our committed SLA in the MSA)
- Full post-mortem within 14 days
- Notification channels: email to designated security contact, in-app banner, status page, optional webhook

**SEV-2 (limited impact):**
- Notification within 72 hours
- Single update upon resolution

**SEV-3 / SEV-4:**
- No active notification; visible on the status page if it affects multiple customers

Customers can configure notification preferences:
- Designated security contact (mandatory; default: org owner)
- Webhook for real-time alerts
- Slack channel webhook
- Email distribution list

## 6. Escalation Paths

For customer-side escalation during an active incident:

| Tier | Contact | When to use |
|---|---|---|
| **Standard support** | support@acmecloud.com | First contact for any service issue |
| **Customer Success Manager** | (assigned at onboarding) | If standard support is slow or escalation needed |
| **24/7 oncall (Platinum/Enterprise)** | +1-415-555-0123 (Platinum), TAM mobile (Enterprise) | Active outage requiring urgent attention |
| **Security incident contact** | security@acmecloud.com (PGP key on trust portal) | Suspected security incident |
| **CISO direct** | Provided to Enterprise TAMs only | Material security or compliance incident |

Customer can request a dedicated incident commander from their TAM during an active SEV-1 to coordinate communication.

## 7. Regulatory Notifications

For incidents involving personal data of EU/UK/CA/AU/etc. data subjects, we assist customers (the Data Controllers) with regulatory notifications:

- We notify customers within 24 hours of confirmed personal data exposure
- We provide all required information for the customer's regulatory notification (data categories, number of records, root cause, mitigation, timeline)
- We coordinate with customer's DPO if requested
- We do NOT notify regulators directly on the customer's behalf — that's the customer's role as Controller

For incidents subject to direct Acme regulatory notification (e.g., as a payment-handling entity under PCI), we follow the applicable regulatory timeline (typically 24–72 hours).

## 8. Communication Channels

During an active incident:
- **Status page:** https://status.acmecloud.com (real-time, public)
- **Security disclosures page:** https://acmecloud.com/security/incidents (public, post-resolution)
- **Trust portal:** https://trust.acmecloud.com (private to customers under NDA)
- **Email:** designated security contact + org owners
- **In-app:** banner with severity color
- **Webhook:** real-time JSON payload (HMAC-signed) to customer-configured URL

## 9. Past Incident Transparency

Our public security incident log is at https://acmecloud.com/security/incidents. Calendar 2025 saw:

- 2 SEV-1 incidents (both publicly post-mortemed)
- 7 SEV-2 incidents (public summary; full post-mortem to affected customers)
- 4 SEV-3 incidents

The 2 SEV-1 incidents in 2025:
- **2025-04-12:** EU region intermittent latency due to a Cloudflare configuration change. Resolved in 1h 23m. No data impact.
- **2025-09-08:** Search degradation due to a Postgres index bloat. Resolved in 2h 14m. No data impact.

Zero confirmed unauthorized data access events to date. (One reported in 2023 turned out to be a legitimate cross-tenant integration the customer had configured.)

## 10. Drill Cadence

- **Tabletop exercises:** monthly with the security team
- **Synthetic incident drills:** quarterly across engineering + support
- **Disaster recovery drills:** quarterly (region failover)
- **Red team exercises:** quarterly (purple team in collaboration with detection engineering)
- **Annual tabletop with executive team:** simulating a major breach scenario including legal, comms, and regulatory response

## 11. Forensics and Evidence Preservation

For incidents with potential litigation or regulatory follow-up:
- Snapshot affected systems before containment changes
- Preserve logs in immutable storage
- Maintain chain-of-custody documentation
- Engage outside counsel and forensic firm if material

We retain forensic evidence for 7 years post-incident.

## 12. Insurance

Acme maintains:
- Cyber liability insurance: $20M per occurrence, $40M aggregate
- General liability: $5M
- Errors & omissions: $10M
- Directors & officers: $25M

Certificate of insurance available on request via trust@acmecloud.com.
