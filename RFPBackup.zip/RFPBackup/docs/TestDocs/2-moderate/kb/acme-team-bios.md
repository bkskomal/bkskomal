# Acme Cloud — Leadership and Key Personnel

**Last updated:** February 2026

This document covers the leadership team, key technical personnel, and the customer-facing roles your organization will interact with during evaluation, implementation, and ongoing partnership.

## 1. Executive Leadership

### Sarah Chen — Chief Executive Officer

Founded Acme Cloud in 2015 after 8 years at Google leading the Workspace search ranking team. Holds an M.S. in Computer Science from Carnegie Mellon and a B.S. in Mathematics from MIT. Previously co-founded a procurement-tech startup acquired by SAP in 2014. Board member at the Open Source Initiative. Lives in San Francisco with her family.

### Marcus Rodríguez — Chief Technology Officer

Joined as CTO in 2017. Previously Distinguished Engineer at Microsoft Azure (Storage), where he built the team that designed Azure Blob Storage's tiering system. M.S. in Distributed Systems from University of Illinois Urbana-Champaign. Holds 14 patents in distributed systems and storage. Speaks at QCon and KubeCon regularly.

### Priya Patel — Chief Information Security Officer

Joined in 2020 from Cloudflare where she led the Trust & Safety engineering team. Previously at PayPal in fraud and risk engineering. Holds a Ph.D. in Computer Security from Carnegie Mellon (focus: side-channel attacks on TEEs) and a B.Tech from IIT Delhi. CISSP. Member of the FIDO Alliance Board. Reports directly to the CEO with dotted-line reporting to the Audit Committee.

### David Okonkwo — Chief Revenue Officer

Joined in 2021 from Stripe where he scaled the SMB sales motion from $100M to $1.2B ARR. Previously at Salesforce in mid-market sales. M.B.A. from Wharton. Based in New York.

### Emma Larsson — Chief Financial Officer

Joined in 2022 from Snowflake where she was VP of Finance. Previously at Goldman Sachs in Technology investment banking. CPA, M.S. in Accounting from NYU Stern. Based in New York.

### Hiroshi Tanaka — Chief Customer Officer

Joined in 2019 from Atlassian where he led Customer Success globally. Built Acme's Customer Success organization from 3 people to 87. M.A. in Organizational Behavior from Stanford GSB. Based in San Francisco; spends 30% of time in customer markets globally.

## 2. Technical Leadership

### Linda Wallace — VP of Engineering

Joined in 2018. Reports to CTO. Oversees ~180 engineers across 12 teams (Platform, AI/ML, Web, Mobile, Data, Infrastructure, SRE, Security Engineering, Developer Experience, Quality, Foundations, Internationalization). M.S. Computer Science Stanford. Previously Engineering Director at Google for 6 years.

### Raj Subramaniam — VP of AI/ML

Joined in 2022. Reports to CTO. Owns the AI/ML organization (~25 engineers + research scientists) responsible for the retrieval, generation, grounding, and routing systems. Ph.D. in NLP from CMU. Previously Research Scientist at Anthropic and FAIR (Meta AI Research).

### Yuki Miyamoto — VP of Site Reliability Engineering

Joined in 2019. Reports to CTO. Owns SRE, on-call, observability, and platform reliability. Manages the global incident response capability. M.S. in Computer Engineering from University of Tokyo. 12 years prior at Twitter as Staff SRE.

### Carlos Vega — Director of Security Engineering

Joined in 2021. Reports to CISO. Owns the security engineering team (~14 engineers) responsible for application security, vulnerability management, secure SDLC tooling, and security-focused infrastructure. CISSP, OSCP. Previously at Square in their internal security team.

### Anika Sharma — Director of Compliance

Joined in 2022. Reports to CISO. Owns the compliance program including SOC 2, ISO 27001, FedRAMP, GDPR, and customer security questionnaires. CIPP/E, CISA, J.D. from Northwestern Pritzker. Prior 6 years at Deloitte's cyber risk practice.

## 3. Customer-Facing Roles by Tier

### Silver Tier (self-serve)
- **Support email:** support@acmecloud.com (business hours, 1-business-day SLA for first response)
- **Community Slack:** for self-service collaboration
- No dedicated personnel

### Gold Tier
- **Onboarding Specialist:** assigned for the first 30 days; runs the kickoff call and 2-week check-in
- **Customer Success Manager:** assigned at activation; pooled (2:1 ratio); quarterly business reviews
- **Support:** email + 24/5 chat (1-hour SLA on chat)

### Platinum Tier
- **Onboarding Manager:** assigned for first 90 days; runs the 4-week guided implementation
- **Customer Success Manager:** dedicated; monthly check-ins; 24/7 escalation path
- **Support:** phone, chat, email; 24/7; 30-min SLA for SEV-2 and above
- **Solutions Architect (shared):** quarterly architecture review

### Enterprise Tier
- **Technical Account Manager (TAM):** dedicated, named individual; on-site and remote; weekly check-ins
- **Solutions Architect (dedicated):** assigned for design partnership
- **Customer Success Manager:** dedicated, executive-level
- **Implementation Engineering Team:** 8–12 week guided rollout with named engineers
- **Direct CISO escalation** for material security/compliance matters
- **Quarterly executive business review** with VP-level Acme attendance

## 4. Account Team Roles (definitions)

### Customer Success Manager (CSM)

Owns the long-term success of your account. Conducts business reviews, surfaces best practices, identifies expansion opportunities, manages renewals. Your single point of contact for non-technical questions.

### Technical Account Manager (TAM) — Enterprise only

A senior engineer (typically 8+ years experience) embedded with your account. Owns technical success, complex troubleshooting, integration design review, capacity planning, and new-feature rollout coordination. Available via Slack and direct phone.

### Solutions Architect (SA)

Pre-sales and ongoing architectural guidance. Designs integrations, helps tune RAG quality for your specific knowledge base, advises on multi-region or BYOK setups. SAs are subject-matter experts in either security/compliance, AI/ML, or integrations.

### Implementation Engineer

Hands-on engineer who runs your implementation: data migration, integration setup, custom workflow configuration, training. Typically engaged for 4–12 weeks during initial rollout.

### Onboarding Manager

Runs the rollout playbook for your tier. Ensures milestone completion. Hand-off to CSM at end of onboarding.

### Designated Security Contact

Customer's single point of contact for any security-related communication from Acme (incident notifications, vulnerability disclosures, audit requests). Customer designates one or more Security Contacts; defaults to the org owner.

## 5. Key Numbers

| Function | Headcount |
|---|---|
| Total employees | 412 |
| Engineering (incl. AI/ML, SRE, Security, DevEx) | 180 |
| Customer-facing (CS, Support, SE, TAM) | 87 |
| Sales | 56 |
| Product Management | 14 |
| Marketing | 22 |
| Finance / Operations / Legal | 28 |
| Information Security (separate from Security Engineering) | 12 |
| HR / People | 13 |

## 6. Geographic Distribution

| Office | Headcount |
|---|---|
| San Francisco (HQ) | 187 |
| New York | 78 |
| London | 64 |
| Singapore | 32 |
| Sydney | 19 |
| Remote (33 countries) | 32 |

We follow a "remote-friendly with hub anchoring" model — most employees are within commuting distance of one of the five offices, but remote work is supported for the right roles.

## 7. Customer-Facing Personnel Specific to Healthcare and Regulated-Industries Customers

For customers in regulated industries (healthcare, financial services, government, critical infrastructure), we assign personnel with specific domain background:

- **Healthcare/HIPAA SAs:** 4 dedicated. Background: prior work at Epic, Cerner, or large hospital systems. HIPAA-trained; signed BAA-aware.
- **Financial Services SAs:** 6 dedicated. Background: prior work at large banks or fintech. Familiar with NYDFS, OCC, FINRA.
- **Government SAs:** 3 dedicated. US public-trust cleared. Familiar with FedRAMP, StateRAMP, GovCloud.

## 8. Reference Calls

Customers can request reference calls with existing customers in similar industries / use cases. Sales team coordinates. Typical turnaround: 1–2 weeks for a 30-minute call with 1–2 references.

For reference contact: rfp@acmecloud.com or your sales rep.

## 9. Conferences and Events

Acme has presence at:
- RSA Conference (annual)
- KubeCon (annual)
- Gartner CIO Symposium (annual)
- CIPP / IAPP Privacy Summit (annual)
- AI Engineer Summit (annual)
- Customer Advisory Board events (3x/year, by invitation)

Visit our booth or schedule a 1:1. Contact events@acmecloud.com.

## 10. Contact Summary

| Need | Contact |
|---|---|
| General inquiry | hello@acmecloud.com |
| Sales | sales@acmecloud.com |
| RFP / procurement | rfp@acmecloud.com |
| Support | support@acmecloud.com |
| Security incident reporting | security@acmecloud.com (PGP) |
| Privacy / GDPR | dpo@acmecloud.com |
| Trust portal access | trust@acmecloud.com |
| Press / media | press@acmecloud.com |
| Investor relations | ir@acmecloud.com |
