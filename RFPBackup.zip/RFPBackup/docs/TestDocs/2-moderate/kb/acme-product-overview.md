# Acme Cloud — Product Overview

**Founded:** 2015
**Headquarters:** San Francisco, California, USA
**Additional offices:** New York · London · Singapore · Sydney
**Employees:** 412 (as of January 2026)
**Customers:** 2,300+ globally across 38 countries

## 1. What Acme Cloud Does

Acme Cloud is an enterprise-grade content intelligence platform that helps organizations turn their unstructured documents, knowledge bases, and historical correspondence into a queryable, automation-ready system of record. We're used most heavily by procurement teams, security teams, sales engineering teams, and compliance teams — in short, anyone whose job involves answering questions whose answers exist somewhere in their organization's accumulated knowledge.

The core capability is hybrid retrieval-augmented generation (RAG) over heterogeneous content sources, packaged with workflow tooling for the teams that need to act on the answers.

## 2. Core Modules

### 2.1 Knowledge Base

The Knowledge Base is where customers ingest their content. We support direct upload of:

- PDF (with layout-aware parsing, OCR for scans)
- Microsoft Word (.docx) with structure preservation
- Microsoft Excel (.xlsx) with sheet-aware extraction and merged-cell handling
- Microsoft PowerPoint (.pptx) — slide-by-slide
- HTML pages (with content-extraction filters)
- Markdown (.md) and plain text
- Email (.eml, .msg) including threaded conversations
- Images (.png, .jpg) with vision-LLM OCR

Content can also be pulled in via integrations from SharePoint, Google Drive, Confluence, Notion, GitHub wikis, and 30+ other connectors.

Documents are parsed into a structured AST (heading hierarchy, tables, lists, figures, footnotes), semantically chunked along block boundaries, and embedded into a vector store. Tables are preserved as both Markdown and structured JSON. Citation precision down to the exact heading path and page number.

### 2.2 RFP & Questionnaire Response

The flagship workflow module. Designed for teams that respond to:

- RFPs (Requests for Proposal)
- RFIs (Requests for Information)
- DDQs (Due Diligence Questionnaires)
- Security questionnaires (CAIQ, SIG, VSA-Q, custom)
- Vendor onboarding forms
- Compliance attestations

Workflow:
1. Upload the source RFP/questionnaire (PDF/DOCX/XLSX/web form)
2. AI extracts every distinct question with metadata (complexity, required, topic, eligibility)
3. AI generates a draft answer for each question, citing relevant knowledge-base sources
4. Subject-matter experts review and approve, with comments and @mentions
5. Approved responses become "golden answers" that strengthen future generations
6. Export as a completed Word/PDF/Excel response file

Supports multi-document RFP packages (primary spec + addenda + security questionnaire + pricing matrix in one project).

### 2.3 Pricing Matrix Handler

Specialized handling for Excel pricing matrices common in enterprise RFPs. Extracts rows × columns, AI-generates per-cell answers, lets users edit, exports a completed Excel file ready to ship. Handles thousands of cells per workbook.

### 2.4 Content Library / Golden Answers

A curated library of approved past answers. Used as both:
- Direct retrievable knowledge during answer generation
- Style and tone reference for the LLM

Includes outcome tagging — answers from won RFPs are weighted higher in retrieval; answers from lost RFPs surface coaching notes to avoid repeating mistakes.

### 2.5 Chat

A conversational interface over the customer's knowledge base. Used for:
- Quick answer lookup before responding to a teammate
- Drafting Slack/email responses
- Exploring the knowledge base interactively
- Per-RFP "discuss this" threads tied to specific projects

Tool calling supported for live data (calculator, web fetch, internal connectors).

### 2.6 Insights

Real-time analytics on team performance:
- Questions answered per period
- Average confidence and grounding score
- Time-to-answer distribution
- Win rate by RFP characteristics
- Coverage gaps (questions with no good source)
- Stale source flags
- Per-user productivity

## 3. Architecture (Customer-Visible)

### 3.1 Multi-Tenancy

Every customer ("organization") has a hard-isolated tenant. Data, embeddings, configurations, audit logs, and computational resources are partitioned at the database, vector store, storage, and key-management layers. Cross-tenant access is structurally impossible — there's no admin role that can read across tenants, including by Acme staff.

### 3.2 Region Selection

Tenants choose their primary region during onboarding:
- US-East (Northern Virginia)
- US-West (Oregon)
- EU-West (Ireland)
- EU-Central (Frankfurt)
- UK (London)
- Asia-Pacific (Sydney)
- Asia-Pacific (Tokyo)
- Asia-Pacific (Singapore)
- Canada (Central)

All customer data — primary storage, backups, vector store, search indexes — stays in the chosen region.

### 3.3 High Availability

Each region has at least 3 availability zones with active-active deployment. Automated failover between zones (RPO measured in seconds, no customer action required). Cross-region disaster recovery available on Enterprise tier with documented RTO 4 hours, RPO 1 hour.

### 3.4 Scaling

The platform horizontally scales for:
- Document ingestion (parallel parsing, chunking, embedding)
- Concurrent question generation (per-org rate limits configurable)
- Vector search (HNSW indexes, sub-100ms p50 query latency at 10M-chunk scale)
- Chat throughput (per-tenant LLM concurrency limits)

## 4. Integrations

Out-of-the-box:

**Identity & SSO:**
- Okta, Azure AD, Google Workspace, OneLogin, Auth0, generic SAML 2.0
- SCIM 2.0 user provisioning

**Content Sources:**
- SharePoint, OneDrive, Google Drive, Box, Dropbox
- Confluence, Notion, Google Sites
- GitHub, GitLab wikis
- Jira, Asana, Linear (for past tickets)
- Salesforce (for past sales correspondence)
- HubSpot, Outreach (for past customer interactions)

**Communication:**
- Slack (notifications, slash commands, Acme bot)
- Microsoft Teams
- Email-in (forward an RFP to your tenant address; auto-creates project)

**CRM & Sales:**
- Salesforce (link RFP to opportunity, push outcome)
- HubSpot
- Pipedrive

**Procurement Platforms:**
- Loopio (import legacy library)
- Responsive (RFPIO)
- Ariba, Coupa (read RFP feed)

**Webhooks:** Outgoing webhooks (HMAC-SHA256 signed) for any event in the system. Incoming webhooks for external triggers.

**API:** Comprehensive REST API with Bearer-token authentication. Programmatic access to every entity. OpenAPI 3.0 spec published.

## 5. Tier Comparison

| Feature | Silver | Gold | Platinum | Enterprise |
|---|---|---|---|---|
| Users | 5 | 25 | 100 | Unlimited |
| RFPs / month | 10 | 50 | 250 | Unlimited |
| Knowledge base size | 10 GB | 50 GB | 250 GB | Custom |
| Vector store | Postgres | Postgres | Milvus | Milvus + BYO |
| LLM provider | Acme-managed | Acme-managed | BYO supported | BYO required |
| SAML SSO | — | — | ✓ | ✓ |
| BYOK encryption | — | — | — | ✓ |
| Region selection | US only | US, EU | All | All + custom |
| SLA uptime | 99.5% | 99.9% | 99.99% | 99.99% + custom |
| Support | Email, BH | Email, 24/5 | Phone, 24/7 | TAM, 24/7 |
| Audit log retention | 90 days | 1 year | 7 years | Custom |
| Implementation | Self-serve | Onboarding call | Guided | White-glove |

## 6. Customers (selected, public references)

By industry vertical:

**Financial services:** Pinnacle Trust, Atlas Capital Partners, Meridian Wealth, Northbridge Insurance, Coastal Federal Credit Union

**Healthcare:** Helix Medical Group, Northstar Health Systems, Vanguard Pharma, Cascade BioWorks, Greenline Therapeutics

**Technology:** Polaris Software, Beacon Networks, Quantum Logistics, Ironclad Devices, Strataline Cloud (Strataline runs Acme on top of their own platform — yes, that's recursive)

**Public sector:** State of Vermont (procurement digitization initiative), County of Santa Clara, Province of Ontario (vendor management), Australian Department of Health Services

**Other regulated industries:** Helio Energy (utilities), Continental Mining, Ridgeline Aerospace, Sapphire Defense Systems

Total: 2,300+ customers across 38 countries. The largest customer (a multinational financial services group) has 18,000 active users on the platform.

## 7. Pricing

Pricing details are in the Pricing Tiers document. Custom Enterprise pricing available — contact sales@acmecloud.com.

Volume discounts available at 50, 100, 250, 500, and 1000+ user thresholds.

Annual contracts standard; 3-year commitments available with 15% discount.

## 8. What We Don't Do

To be clear about boundaries:

- We are not a CRM. We integrate with Salesforce/HubSpot but don't replace them.
- We are not a content management system. We index your content but don't replace SharePoint/Confluence.
- We are not a contract lifecycle management tool. We help respond to RFPs but don't manage executed contracts (we integrate with Ironclad and ContractWorks for that).
- We are not a fine-tuning service. We help you export training data and consume the resulting fine-tuned model, but we don't train models on your behalf.

## 9. Getting Started

- **Self-serve trial:** sign up at https://acmecloud.com/trial. 14-day full-feature trial. No credit card required.
- **Demo:** schedule at https://acmecloud.com/demo. Tailored to your use case.
- **Procurement materials:** see https://trust.acmecloud.com for SOC 2, ISO 27001, security questionnaire prefills, master service agreement templates.
- **Documentation:** https://docs.acmecloud.com (public).
- **API reference:** https://api-docs.acmecloud.com (public).

For procurement / RFP-related questions: rfp@acmecloud.com.
