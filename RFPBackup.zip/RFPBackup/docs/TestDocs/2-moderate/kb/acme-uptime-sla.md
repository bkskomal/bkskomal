# Acme Cloud — Uptime, SLA, and Availability

**Version:** 3.1 — January 2026
**Effective:** for all subscriptions including renewals from this date

## 1. Tier-Based Uptime Commitments

| Tier | Monthly uptime | Allowed downtime per month |
|---|---|---|
| Silver | 99.5% | 3h 39m |
| Gold | 99.9% | 43m 49s |
| Platinum | 99.99% | 4m 22s |
| Enterprise | 99.99% (default); custom up to 99.999% (26s/month) | per contract |

Uptime measured against **HTTP 5xx responses to the API** and **inability to authenticate via the web UI**, in 1-minute granularity, calculated at the end of each calendar month.

## 2. What Counts Toward Downtime

Counts:
- API returns HTTP 5xx for > 50% of requests in a given minute
- Web UI fails to load (TLS error, ALB 5xx, total timeout)
- Authentication completely fails (cannot log in)
- Search returns no results across all queries (catastrophic failure)

Doesn't count (excluded):
- Customer-side issues (customer's IdP down, customer's API key revoked, customer's network issue)
- Force majeure (per MSA Section 19)
- Scheduled maintenance windows (rare — most maintenance is online; when offline maintenance is required, 14-day advance notice; max 2 hours/quarter)
- Third-party LLM provider outages affecting customers using BYO LLM (the customer's choice of provider; their reliability concern)
- Customer-induced overload (request volume > tier limit)
- Beta/preview features explicitly marked as such

## 3. Status Page

Real-time status at **https://status.acmecloud.com**.

- Shows status per region per service component
- Subscribes via email, RSS, webhook, Slack
- Public incident history (90 days visible; older available on request)
- Maintenance window calendar

The status page is hosted on independent infrastructure (Statuspage by Atlassian) — when Acme is down, the status page is up.

## 4. SLA Credits

For monthly uptime falling below committed:

| Uptime in month | Service credit |
|---|---|
| 99.5% — 99.9% (for 99.9% tier) | 10% of that month's fees |
| 99.0% — 99.5% (for 99.9% tier) | 25% of that month's fees |
| 95.0% — 99.0% (for 99.9% tier) | 50% of that month's fees |
| < 95.0% (any tier) | 100% of that month's fees |

For 99.99% Platinum tier:
| Uptime in month | Credit |
|---|---|
| 99.9% — 99.99% | 10% of monthly fees |
| 99.5% — 99.9% | 25% |
| 99.0% — 99.5% | 50% |
| < 99.0% | 100% |

Credits are claimed by the customer within 60 days of the affected month. Credits are applied to the next invoice, not refunded as cash. Total credits in any month capped at 100% of monthly fees.

## 5. Historic Uptime

Public uptime data for the last 12 months (calendar 2025):

| Month | US-East | US-West | EU-West | EU-Central | UK | AP-Sydney |
|---|---|---|---|---|---|---|
| Jan 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Feb 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Mar 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Apr 2025 | 100% | 100% | 99.84% | 100% | 100% | 100% |
| May 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Jun 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Jul 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Aug 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Sep 2025 | 99.78% | 100% | 100% | 100% | 100% | 100% |
| Oct 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Nov 2025 | 100% | 100% | 100% | 100% | 100% | 100% |
| Dec 2025 | 100% | 100% | 100% | 100% | 100% | 100% |

**Trailing 12-month uptime across all regions: 99.987%**

Two SEV-1 incidents in 2025:
- April 12: EU-West Cloudflare config issue (1h 23m). Impact: 99.84% uptime that month for EU-West.
- September 8: US-East Postgres index bloat (2h 14m). Impact: 99.78% uptime that month for US-East.

Both within tolerance for Platinum 99.99% across the trailing 12 months. SLA credits issued automatically to affected customers in those months.

## 6. Maintenance Windows

Acme aims for zero downtime maintenance. The platform supports rolling deploys that don't require taking the service offline.

In rare cases (major database upgrade, fundamental schema migration), an offline window may be needed:

- **14-day advance notice** to all affected tenants
- **Window: a 2-hour off-peak slot** (per region; we choose the local off-peak time for that region)
- **Maximum 2 hours per quarter** per tenant
- **Maintenance windows don't count toward downtime** (they're explicitly excluded from the SLA)
- **Postponement available** for a customer with a specific business-critical need (e.g., active RFP deadline) — request via your CSM

## 7. Scaling Promises

When you exceed your tier's capacity limits:

- **Soft limits** (e.g., concurrent users) — automatically scale up; you receive a notification of the auto-scale event
- **Hard limits** (e.g., RFPs/month) — quota enforced at the tier limit; you receive a notification ahead of exhaustion; can purchase add-on capacity or upgrade tier

We don't take you offline because of a usage spike. We may rate-limit individual operations during a spike to maintain platform stability, but core service remains available.

## 8. Region-Specific Availability

Each region is a separate failure domain. An outage in EU-West does not affect US-East customers. Cross-region incidents are extremely rare (would require a global Cloudflare outage or a global AWS control-plane issue, both of which are themselves rare).

For customers needing cross-region failover (their primary region goes fully down):
- **Enterprise tier:** documented cross-region DR with RPO ≤ 1h, RTO ≤ 4h
- **Platinum tier:** backup snapshots in a secondary region; manual restore via support ticket (24h SLA)
- **Gold/Silver tier:** in-region resilience only (within-AZ redundancy, no cross-region failover)

## 9. Network Topology and Failover

Within a region:
- Multi-AZ active-active deployment (≥3 AZs)
- AZ failure → automatic failover within ~30 seconds
- Single instance failure → automatic restart within ~10 seconds
- Database primary failure → automatic failover within ~30 seconds (Multi-AZ RDS)

These are the failover scenarios we exercise most often:
- Quarterly "AZ-out" drills
- Monthly chaos engineering experiments (random pod kills, simulated network partitions, simulated database failures)

## 10. Performance SLAs

Beyond uptime, we commit to:

| Metric | Commitment |
|---|---|
| API read latency (p95) | < 500ms |
| API read latency (p99) | < 1.5s |
| Vector search latency (p99) | < 200ms |
| Generation start latency (p50) | < 2s |
| Generation completion latency (p50) | < 8s for typical question (BYO model dependent) |
| Webhook delivery (p95) | < 5s after triggering event |
| Audit log freshness | < 60s lag from event to queryable |

Performance SLAs measured globally, not per-customer. For customers wanting per-tenant performance SLAs (Enterprise tier), we negotiate based on workload profile.

## 11. Capacity Planning Transparency

We publish quarterly capacity-planning notes for Enterprise customers detailing:

- Current utilization (CPU, memory, vector store size, database connections)
- Forecast trajectory and runway
- Planned capacity additions
- Any tenant approaching tier limits

Available via the Trust Portal (Enterprise tier).

## 12. Reliability Engineering Investment

We dedicate ~12% of total engineering capacity to reliability work:
- 24-person SRE team
- Dedicated chaos engineering function
- Dedicated incident response engineering
- 24/7 SOC

This is a deliberate over-investment relative to industry norm (~8%), driven by our customers' regulated-industry expectations.

## 13. Contact

For SLA questions: csm@acmecloud.com (your assigned CSM)
For status page subscriptions: https://status.acmecloud.com
For credit claims: support@acmecloud.com (cite affected month + downtime in the ticket)
For Enterprise-specific availability terms: tam@acmecloud.com (your assigned TAM) or your contracts officer
