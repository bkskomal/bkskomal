# Acme Cloud — SOC 2 Type II Audit Report Summary

**Document version:** v3.2 — January 2026
**Audit firm:** Schellman Compliance LLC
**Audit period:** January 1, 2025 through December 31, 2025
**Report type:** SOC 2 Type II
**Trust Service Criteria covered:** Security, Availability, Confidentiality, Processing Integrity

## 1. Scope of Audit

This report covers the Acme Cloud platform offered by Acme Cloud, Inc. (the "Service Organization"), including all production systems hosting customer data in our AWS, GCP, and Azure regions. The audit boundary includes:

- The Acme Cloud SaaS application (web, API, mobile)
- All supporting infrastructure including authentication, authorization, encryption, and storage subsystems
- Internal corporate systems used by personnel with logical access to customer data (laptop endpoints, identity provider, ticketing systems, code repositories)
- Subprocessors used in the delivery of the service, including AWS, Cloudflare, Datadog, Twilio, and Stripe (full subprocessor list in Appendix C)

Out of scope: physical security controls at AWS data centers (carved out under SSAE 18 — relied on AWS SOC 2), the Acme Cloud Marketing site (no customer data), and beta/preview features explicitly marked as such (under separate evaluation).

## 2. Auditor's Opinion

In the opinion of Schellman Compliance LLC, the controls described in Section 4 of this report were suitably designed throughout the period to provide reasonable assurance that the service commitments and system requirements would be achieved based on the applicable Trust Service Criteria, and operated effectively to provide reasonable assurance that the controls were achieved.

**Result: Unqualified opinion. No exceptions noted.**

## 3. Service Commitments and System Requirements

Acme Cloud commits to the following availability and security objectives:

- **Availability:** 99.99% monthly uptime for Platinum tier, 99.9% for Gold tier, 99.5% for Silver tier
- **Encryption:** All customer data encrypted at rest using AES-256-GCM and in transit using TLS 1.3
- **Authentication:** All access to customer data requires authenticated sessions; production access requires hardware-backed MFA
- **Backup:** Daily encrypted backups retained for 30 days, with tested restore procedures
- **Incident response:** Security incidents communicated to affected customers within 72 hours of confirmed material impact

## 4. Tested Controls (selected)

### 4.1 Logical Access (CC6.1, CC6.2, CC6.3)
- All employee access to production systems uses Acme's identity provider (Okta) with hardware-backed MFA (YubiKey or TouchID)
- Just-in-time elevation via internal access broker; standing production access is restricted to four members of the SRE leadership team
- Quarterly access reviews; annual entitlement audit
- Terminations revoke access within 60 minutes of HR notification
- Tested by inspecting 50 sample access grants and 25 termination events across the audit period; no exceptions

### 4.2 Encryption (CC6.7)
- Data at rest: AES-256-GCM via AWS KMS-managed CMKs; one CMK per tenant
- Data in transit: TLS 1.3 with HSTS, perfect-forward-secrecy ciphers only
- Key rotation: automatic 90-day rotation for CMKs; automatic 365-day rotation for certificate authorities
- Customer-managed keys (BYOK) supported for Enterprise tier customers via AWS KMS, Azure Key Vault, or GCP Cloud KMS
- Tested by inspecting CMK configurations, KMS audit logs, and TLS certificate chains across all customer-facing endpoints

### 4.3 Change Management (CC8.1)
- All production changes via pull request with peer review (minimum two approvers for security-sensitive paths)
- Automated security scanning (Snyk, GitGuardian, Semgrep) runs on every PR
- Production deployment requires green CI, passing SAST/DAST, and approval from the deployment manager
- Emergency changes (under 4 hours) follow an abbreviated path with required post-change review within 24 hours
- Tested by inspecting 100 production changes; all had documented approvals and CI evidence

### 4.4 Monitoring (CC7.1, CC7.2)
- Centralized logging via Datadog; logs retained for 13 months in encrypted, immutable storage
- 24/7 SOC monitoring with automated alerting for known indicators of compromise
- Mean time to alert: 4 minutes for high-severity events
- Mean time to acknowledge: 7 minutes
- Mean time to triage: 23 minutes
- Tested by reviewing alert response logs and conducting two synthetic incident drills during the period

### 4.5 Backup and Recovery (A1.2)
- Daily snapshots of all customer data; encrypted with the customer's CMK
- Snapshots replicated to a separate AWS region within 60 minutes of creation
- Quarterly restore drills (tested twice during the audit period; both successful within stated RPO/RTO)
- Recovery Time Objective (RTO): 4 hours for full-region failure
- Recovery Point Objective (RPO): 1 hour for transactional data; 24 hours for blob storage

### 4.6 Vendor Management (CC9.2)
- All subprocessors evaluated annually against Acme's vendor security questionnaire
- New subprocessors require security team review before adoption
- 30-day customer notification before any new subprocessor is added that handles customer data
- Public subprocessor list maintained at https://acmecloud.com/subprocessors

## 5. Subservice Organization Reliance

Acme relies on AWS for compute, storage, and network infrastructure. AWS provides physical security and certain availability controls under their own SOC 2 Type II report. The boundary between Acme controls and AWS controls is documented in Appendix B; in summary: Acme is responsible for tenant isolation, encryption configuration, identity, and application logic; AWS is responsible for hypervisor isolation, physical access, environmental controls, and the underlying availability of EC2, S3, RDS, and KMS.

## 6. Complementary User Entity Controls (CUECs)

Customer organizations are responsible for the following controls to achieve the complete control objectives:

- Maintaining the confidentiality of their Acme Cloud authentication credentials
- Promptly notifying Acme of personnel changes that affect access permissions
- Properly configuring SSO and MFA settings for their tenant
- Reviewing customer-side audit logs (available via API) for unauthorized activity
- Ensuring that data uploaded to Acme is appropriate per the customer's own data classification policy

## 7. Summary of Controls Tested

A complete list of 147 controls is in Appendix A. The audit tested all 147 with no exceptions noted. This is the seventh consecutive year Acme has obtained an unqualified SOC 2 Type II opinion.

## 8. How to Request the Full Report

Customers and prospects under NDA may request the full SOC 2 Type II report by emailing trust@acmecloud.com. The full report includes the description of the system, complete list of controls tested, sample sizes, and management's assertion. Reports are made available within 5 business days of NDA execution.

## 9. Continuous Compliance

Beyond the annual SOC 2 audit, Acme operates a continuous compliance program with daily automated control testing via Vanta. Customers may view our real-time compliance status, control evidence, and any active findings at https://trust.acmecloud.com.

## 10. Related Certifications and Reports

- ISO 27001:2022 certification (since 2023, current renewal 2026)
- ISO 27017 (cloud-specific extension) certification (since 2023)
- ISO 27018 (PII in cloud) certification (since 2024)
- HIPAA Business Associate Agreement available
- PCI DSS Service Provider Level 1 (for payment-handling features)
- StateRAMP Authorized (Moderate, since 2024)
- FedRAMP Moderate authorization in progress (target: Q3 2026)
- TX-RAMP Level 2 certification

For our complete trust portfolio, visit https://trust.acmecloud.com.
