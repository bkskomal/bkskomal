# Acme Cloud — SOC 2 Type II Report (OLD)

**Document version:** v1.0 — January 2023
**Audit firm:** Prior Audit Partners LLC
**Audit period:** January 1, 2022 through December 31, 2022
**Report type:** SOC 2 Type II (SUPERSEDED — see current 2025 report)
**Status:** ARCHIVED — refer to current SOC 2 Type II report for active audit data

## 1. Notice

This document reflects the **2022 audit window** and is retained for historical reference only. For current control attestations, refer to the active SOC 2 Type II report (January 1, 2025 through December 31, 2025).

## 2. Summary of 2022 Audit

- Audit firm: Prior Audit Partners LLC
- Auditor's opinion: Unqualified
- Trust Service Criteria: Security, Availability, Confidentiality
- Exceptions noted: 2 (both remediated by Q1 2023)
- Total controls tested: 121

## 3. Why You Should NOT Cite This

This report describes controls and a vendor environment as of 2022. The platform has since:

- Migrated to AWS KMS HSM-backed CMKs (was: software-only key management in 2022)
- Adopted hardware-backed MFA platform-wide (was: TOTP-only in 2022)
- Increased SOC scope to include Processing Integrity (was: SAC only in 2022)
- Changed audit firm from Prior Audit Partners LLC to Schellman Compliance LLC

Citing this document as evidence of current posture would be **materially misleading**.

## 4. Where to Find the Current Report

Customers under NDA can request the current (2025 period) SOC 2 Type II report by emailing trust@acmecloud.com. Report turnaround: 5 business days after NDA execution.

## 5. Document Retention

This archived report is retained until **December 31, 2027** per our data retention policy. After that date, it will be moved to cold archive (Glacier) for SOX-equivalent records-retention purposes.
