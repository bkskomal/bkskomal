# Northbridge Bank — Vendor Risk Questionnaire (Addendum)

**Reference:** NB-VR-2026-0419-A1
**Date:** Issued June 30, 2026

The following questions are additional to the primary questionnaire (NB-VR-2026-0419). Vendor must respond to both documents.

---

## Section A — Stale-source Spot-check

### A.1
Provide your CURRENT SOC 2 Type II audit firm. (Note: we have seen archived material citing "Prior Audit Partners LLC" — please clarify if that is still your active auditor.)

---

## Section B — Architecture Diagrams

### B.1
Describe your high-availability architecture across availability zones.

### B.2
Confirm whether your platform supports active-active deployment across regions.

---

## Section C — AI/ML Usage

### C.1
Do you use AI/ML in your platform? If yes, describe what models are used, what data they process, and your training-data governance.

### C.2
Confirm that you do not use customer data to train models that benefit other customers.
