# Northbridge Bank — Vendor Risk Assessment Questionnaire

**Vendor:** Acme Cloud
**Sponsor:** Vendor Risk Management Office
**Reference:** NB-VR-2026-0419
**Response deadline:** 5:00 PM EST on July 15, 2026
**Submit to:** vendorrisk@northbridge.example

This questionnaire is part of Northbridge Bank's mandatory third-party risk assessment.
Vendor responses will be evaluated by the Vendor Risk Committee and the CISO.

---

## Section 1 — Vendor Profile

### 1.1
Provide your company name, year founded, and headquarters location.

### 1.2
List your three most relevant customer references in financial services.

### 1.3
What was your average customer-reported NPS in calendar year 2025?

---

## Section 2 — Security Architecture

### 2.1
How do you protect stored customer data? Specify the cryptographic algorithm and the key-management approach.

### 2.2
What is your committed RTO and RPO for a regional failure event?

### 2.3
Describe your tenant isolation model across compute, storage, vector search, and encryption.

### 2.4
Describe your defense-in-depth network architecture including WAF, DDoS mitigation, and segmentation.

### 2.5
What pen-testing cadence do you follow, and which firm conducts your annual external test?

---

## Section 3 — Compliance & Audit

### 3.1
Provide your current SOC 2 Type II audit firm, audit period, and confirm that the most recent report had no exceptions.

### 3.2
Are you ISO 27001 certified? Provide certificate number and validity dates.

### 3.3
Confirm support for HIPAA Business Associate Agreements with appropriate safeguards.

### 3.4
Describe your support for customer-driven data subject access requests under GDPR.

---

## Section 4 — Operations & Reliability

### 4.1
What is your trailing 12-month uptime across all regions? Provide a per-region breakdown if available.

### 4.2
Describe your incident response process from detection through public post-mortem.

### 4.3
What is your mean time to acknowledge (MTTA) for SEV-1 incidents?

---

## Section 5 — Implementation & Account Management

### 5.1
What is the typical implementation timeline for an Enterprise-tier customer of approximately 1,500 users?

### 5.2
Describe the dedicated personnel that would be assigned to our account.

### 5.3
Provide your standard SLA tiers and the credits associated with breach.

---

## Section 6 — Pricing & Commercials

### 6.1
What is the annual cost for 1,500 users with FedRAMP High authorization, BYOK encryption, and 24/7 phone support across 4 regions?

### 6.2
Describe your standard contract term and any multi-year discount structure.

### 6.3
How is your pricing differentiated from your primary competitor's? Be specific about feature-by-feature deltas.

---

## Section 7 — Northbridge-specific

### 7.1
Describe your support for our internal compliance framework (Northbridge Operational Risk Framework v3.7).

### 7.2
Have you previously partnered with Northbridge Bank, or with any institution in our peer group (G-SIB tier)?

---

## Section 8 — Submission

### 8.1
Submit your response by 5:00 PM EST on July 15, 2026.

### 8.2
Responses must be in 11pt Times New Roman, single-spaced, with section numbers preserved. No marketing material.
