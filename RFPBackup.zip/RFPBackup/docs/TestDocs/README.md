# AutoRFP — Test Documents

These are the fixtures used in the 3-tier capability test campaign that produced
the validation results deck at `docs/AutoRFP-validation-results.pptx`.

Each tier folder contains the knowledge-base documents (`kb/`) and the RFP
document(s) (`rfp/`) used in that tier's run. Tier 3 also contains the seeded
golden answers (`goldens/`).

## Tier 1 — Easy

`1-easy/` — Single-source factual lookup.

- **KB:** 4 NovaCore docs (~6 KB) — fictional data-observability vendor
- **RFP:** 1 questionnaire, 10 questions, all simple factual lookups
- **Result:** 10/10 answered · 9/9 citation precision · grounding 1.000 · 2m 4s

## Tier 2 — Moderate

`2-moderate/` — Multi-source synthesis + eligibility classification.

- **KB:** 13 Acme Cloud docs (~22K words) — security/compliance, product, pricing,
  references, team bios, integrations, etc.
- **RFP:** 1 Continental Healthcare RFP, 30 questions across 7 sections
- **Result:** 22/28 completed · 9/9 citation precision · grounding 0.912 ·
  grounding judge caught a real soft-hallucination · 7m 53s

## Tier 3 — Complex

`3-complex/` — Multi-document RFP + pricing matrix + stale + contradictory +
paraphrased golden + edge cases.

- **KB:** 15 docs (13 Acme + `acme-soc2-2022-DEPRECATED.md` deliberately stale +
  `acme-marketing-fluff.md` deliberately contradictory)
- **RFP package:** primary spec + addendum + pricing matrix XLSX (16 cells)
- **Goldens:** 3 seed Q&A pairs with deliberately different wording from the RFP
  to exercise BGE semantic golden retrieval
- **Result:** 21/21 completed · 9/9 citation precision · grounding 0.827 ·
  stale-source flagged · matrix returned 16/16 NEEDS INFO · semantic golden
  matched 3/4 key terms · 21m 7s

## Full test report

See [`AutoRFP-validation-results.pptx`](../AutoRFP-validation-results.pptx) in
the parent docs folder for the complete capability matrix and per-tier metrics.
