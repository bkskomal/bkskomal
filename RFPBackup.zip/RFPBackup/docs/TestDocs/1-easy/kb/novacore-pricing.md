# NovaCore — Pricing

## Tier Comparison

| Tier | List price (per user/year) | Minimum users | Uptime SLA |
|---|---|---|---|
| Silver | $480 | 5 | 99.5% |
| Gold | $1,200 | 25 | 99.9% |
| Platinum | $3,600 | 100 | 99.99% |
| Enterprise | Custom | Custom | Custom |

All prices listed are list prices for annual prepay. Monthly billing carries a 20% premium.

## What's Included

### Silver
- 5 users
- 10 GB log retention
- 30-day data retention
- Email support (business hours)
- Self-serve onboarding

### Gold
- 25 users (additional users $10/user/month)
- 100 GB log retention
- 90-day data retention
- Email + 24/5 chat support
- Onboarding call included
- Up to 50 integrations active

### Platinum
- 100 users (additional users $20/user/month)
- 500 GB log retention
- 1-year data retention
- 24/7 phone + chat support
- SAML SSO + SCIM
- BYOK encryption
- Dedicated CSM
- 4-week guided implementation

### Enterprise
- Custom user count
- Custom data retention (up to 7 years)
- Custom SLA up to 99.999%
- Dedicated Technical Account Manager
- Custom DPA / MSA negotiation
- White-glove implementation (8-12 weeks)
- Optional single-tenant infrastructure
- Optional customer-VPC deployment

## Volume Discounts

| User band | Gold off list | Platinum off list |
|---|---|---|
| 50-99 | 5% | n/a |
| 100-249 | 10% | List |
| 250-499 | 15% | 8% |
| 500-999 | 20% | 12% |
| 1000+ | 25% | 18% |

## Free Trial
14-day free trial with full feature access. No credit card required. Limited to 2 users, 1 GB of ingest, and 5 dashboards.

## Payment Terms
- Annual contracts: Net 30 invoicing
- Monthly subscriptions: credit card only
- Accepted methods for annual: ACH, wire, check, credit card
- Multi-currency: USD, EUR, GBP, CAD, AUD on Enterprise tier

## Discounts
- **Non-profit / education:** 30% off list with annual contract
- **Government:** GSA pricing available; StateRAMP authorized
- **Startup program:** for venture-backed companies under $20M ARR — 50% off year 1, 25% off year 2
