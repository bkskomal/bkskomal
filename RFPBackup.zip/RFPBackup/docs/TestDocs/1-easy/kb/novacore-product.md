# NovaCore — Product Overview

## What NovaCore Does
NovaCore is a unified data observability platform that ingests metrics, logs, and traces from any cloud or on-premise source and lets engineering teams query, alert, and visualize them in one place.

## Core Features
- **Real-time ingestion** at up to 10 million events per second per tenant
- **Unified query language** (NovaQL) across metrics, logs, and traces
- **Anomaly detection** powered by built-in machine learning models
- **Custom dashboards** with 60+ visualization types
- **Alerting** with routing to Slack, PagerDuty, OpsGenie, email, and webhooks
- **Distributed tracing** with OpenTelemetry support
- **Cost analytics** — see exactly which queries and dashboards drive your spend

## Architecture
The NovaCore platform is built on a multi-tenant SaaS architecture running on AWS, GCP, and Azure. Each tenant gets a logically isolated namespace with its own encryption keys (BYOK supported on Enterprise tier). Customer data never crosses tenant boundaries; row-level security is enforced at the database, query, and storage layers.

## Uptime SLA
- **Silver tier:** 99.5% monthly uptime
- **Gold tier:** 99.9%
- **Platinum tier:** 99.99%
- **Enterprise:** Custom (up to 99.999%)

Historic 12-month trailing uptime across all regions: **99.987%**.

## Standard Contract Terms
NovaCore's standard contract term is **12 months**, auto-renewing unless cancelled 30 days before renewal. 2-year and 3-year commitments are available with discounts of 8% and 15% respectively. Multi-year discounts stack with volume discounts.

## Implementation Timeline
Typical implementation for a Gold-tier customer of 25-100 users takes **1-2 weeks** including onboarding call, integration setup, custom dashboard creation, and team training. Enterprise customers typically run an **8-12 week guided implementation** with a dedicated Technical Account Manager.

## Integrations
Out-of-the-box integrations with 200+ data sources including AWS CloudWatch, Datadog, Splunk, PagerDuty, Slack, Salesforce, ServiceNow, Jira, GitHub, GitLab, Kubernetes, Docker, Prometheus, Grafana, OpenTelemetry. Custom integration via REST API or OpenTelemetry SDK.
