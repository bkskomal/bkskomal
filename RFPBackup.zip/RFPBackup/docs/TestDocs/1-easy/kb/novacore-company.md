# NovaCore — Company Profile

## Founding & History
NovaCore was **founded in 2018** by Sarah Chen (CEO) and Marcus Rodríguez (CTO), both alumni of Stripe's data infrastructure team. The company was originally based in San Francisco; today it operates from offices in **San Francisco (HQ), New York, and London**.

## Mission
NovaCore builds enterprise-grade data observability tools that help engineering and ops teams understand what their production systems are doing in real time.

## Funding
- **Seed (2018):** $4.2M led by Accel
- **Series A (2020):** $18M led by Sequoia Capital
- **Series B (2022):** $50M led by Bond Capital
- **Series C (2024):** $120M led by Tiger Global
- **Total raised:** $192.2M

## Team Size
NovaCore has **278 employees** as of January 2026. Roughly 60% engineering, 20% go-to-market, 12% customer success, 8% G&A.

## Leadership
- **Sarah Chen** — CEO and co-founder
- **Marcus Rodríguez** — CTO and co-founder
- **Priya Patel** — CISO (joined 2022 from Cloudflare)
- **Emma Larsson** — CFO (joined 2023 from Snowflake)
- **Hiroshi Tanaka** — Chief Customer Officer

## Customers
NovaCore serves over **1,400 customers** across financial services, healthcare, technology, and the public sector. Reference customers (with permission to use as a reference): Pinnacle Trust (wealth management), Helix Medical Group (healthcare), Quantum Logistics (supply chain), State of Vermont (public sector).

## Languages and Regions
NovaCore is currently available in English only, with German and French translations on the roadmap for 2026. The platform is available in 9 regions globally (see the security overview for the regional list).

## Contact
- General inquiries: hello@novacore.example
- Sales: sales@novacore.example
- Procurement / RFPs: rfp@novacore.example
- Support: support@novacore.example
