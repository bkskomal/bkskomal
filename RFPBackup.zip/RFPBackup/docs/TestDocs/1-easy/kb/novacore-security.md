# NovaCore — Security Overview

## Encryption
All customer data is encrypted at rest using **AES-256-GCM**. Encryption keys are managed in AWS KMS with automatic rotation every 90 days. Data in transit uses **TLS 1.3** with HSTS preloading.

## Compliance Certifications
- **SOC 2 Type II** — certified annually since 2020. Audit firm: Schellman.
- **ISO 27001:2022** — certified since 2022. Certificate number ISMS-2024-1102.
- **HIPAA Business Associate Agreement** available with appropriate safeguards.
- **GDPR** compliant — EU Data Processing Addendum included in all contracts.

## Access Control
NovaCore uses role-based access control (RBAC) with three default roles: Owner, Admin, Member. Custom roles are available on the Enterprise tier. All admin actions are logged in an immutable audit log retained for 7 years.

## Multi-Factor Authentication
MFA is mandatory for all NovaCore staff with production access. Customer admins can enforce MFA for their tenant's users. Supported factors: TOTP, WebAuthn hardware keys, and push notifications.

## Incident Response
NovaCore commits to:
- **Recovery Time Objective (RTO):** 4 hours for full-region failure
- **Recovery Point Objective (RPO):** 1 hour for transactional data
- **Customer notification SLA:** 72 hours after confirmed material impact
- **24/7 on-call** with mean time to acknowledge under 10 minutes

## Penetration Testing
Annual external pen tests are conducted by NCC Group. Quarterly internal red-team exercises. Critical vulnerabilities are patched within 7 days of discovery.

## Data Residency
Customer data stays in the tenant's chosen region. Available regions: US-East (Virginia), US-West (Oregon), EU-West (Ireland), EU-Central (Frankfurt), UK (London), Asia-Pacific (Sydney). Cross-region disaster recovery available on Enterprise tier.

## Reporting Vulnerabilities
Security researchers can report vulnerabilities to security@novacore.example. Bug bounty program available on HackerOne (invitation only). PGP key published on the trust portal.

## Subprocessor List
NovaCore relies on AWS (compute and storage), Cloudflare (edge/DDoS), and Datadog (observability). The complete subprocessor list with data-flow descriptions is published at https://novacore.example/subprocessors. Customers receive 30 days advance notice of any subprocessor change.
