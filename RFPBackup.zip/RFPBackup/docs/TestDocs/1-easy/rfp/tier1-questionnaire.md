# Vendor Security & Company Questionnaire

**Sent by:** Beacon Capital — Vendor Due Diligence
**Vendor under review:** NovaCore

Please answer each question concisely. Cite the source document where the answer appears.

## Section A — Company Background

### A.1
In what year was NovaCore founded?

### A.2
Where is NovaCore headquartered?

### A.3
How many total employees does NovaCore have?

## Section B — Security & Compliance

### B.1
Is NovaCore SOC 2 Type II certified? If yes, name the audit firm.

### B.2
What encryption algorithm is used for data at rest?

### B.3
What is your committed customer-notification SLA for a confirmed material security incident?

## Section C — Product & Operations

### C.1
What is the uptime SLA for the Platinum tier?

### C.2
How long does a typical Gold-tier implementation take?

## Section D — Pricing & Contracts

### D.1
What is your standard contract term?

### D.2
What is the annual per-user list price for the Gold tier?
