# NiFi -> AutoRFP External Ingest Recipe

A reference flow for pushing crawled documents into an AutoRFP knowledge
index using Apache NiFi's `InvokeHTTP` processor. The same pattern applies to
Airflow (`SimpleHttpOperator`), n8n (`HTTP Request` node), and any generic
ETL tool that can issue an HTTP POST with a Bearer header.

## Prerequisites

1. Issue an API key in AutoRFP with `WRITE` scope:
   - **Settings → API keys → Create key** (give it a memorable name like
     `nifi-prod-ingest`).
   - Copy the plaintext token (`autorfp_<32-char-base62>`) — it's shown
     exactly once. Store it in NiFi's parameter context as a sensitive value
     named `autorfp.apiKey`.
2. Find the target index id: `Settings → Knowledge Indexes`. The id is in
   the URL when you open an index detail page (a `cuid` string).

## Recipe A — NiFi pushes already-extracted text (recommended)

Use this when an upstream NiFi processor (e.g. `ExtractText`,
`EvaluateXPath`, `Tika ParseDocumentText`) has already produced plain text.
Skips AutoRFP's parser pipeline and goes straight to chunking + embedding.

```text
GetFile / ListSFTP / GetMongo / ConsumeKafka
        |
        v
ExtractText  (turn binary into a text attribute)
        |
        v
AttributesToJSON  (build the request body)
        |
        v
InvokeHTTP        (POST to AutoRFP)
        |
        v
RouteOnStatus     (split 2xx vs 4xx/5xx for retry)
```

### `AttributesToJSON` config

- **Destination:** `flowfile-content`
- **Attributes List:** `name, fileName, mimeType, sourceUrl, content`
- **Include Core Attributes:** `false`
- **Null Value Behavior:** `empty-string`

You'll typically want a wrapping `documents: [...]` array. Either:
- Use `ReplaceText` after `AttributesToJSON` with replacement value
  `{"documents":[$1]}` and Search Value `(.+)`, OR
- Use a `JoltTransformJSON` with a `default` spec wrapping the object.

### `InvokeHTTP` config

| Property                         | Value                                                                       |
|----------------------------------|-----------------------------------------------------------------------------|
| HTTP Method                      | `POST`                                                                      |
| Remote URL                       | `https://your.autorfp.example/api/indexes/${autorfp.indexId}/external/documents` |
| Send Message Body                | `true`                                                                      |
| Request Content-Type             | `application/json`                                                          |
| Add Response Headers as Attrs    | `true`                                                                      |
| Penalize on No Retry             | `true`                                                                      |

Add two **dynamic properties** (the gear icon → "Add Property") so NiFi
sends them as request headers:

| Header Name      | Header Value                          |
|------------------|---------------------------------------|
| `Authorization`  | `Bearer ${autorfp.apiKey}`            |
| `Content-Type`   | `application/json`                    |
| `X-Request-ID`   | `${uuid}`  *(optional — for tracing)* |

### Backpressure / retries

Wire the `Failure` and `Retry` relationships of `InvokeHTTP` to a
`PenalizeFlowFile` then back into `InvokeHTTP`. The endpoint enforces a
**100 requests/minute per org** rate limit; on 429 it returns
`Retry-After` (in seconds) which NiFi exposes as the
`invokehttp.response.header.Retry-After` attribute. A small `Wait`
processor consuming that attribute keeps things polite.

## Recipe B — NiFi forwards raw bytes (PDFs, DOCX, …)

Use this when NiFi pulls a binary you want AutoRFP's parser pipeline to
handle (PDF layout cleanup, DOCX heading extraction, table enhancement).

```text
FetchFile / FetchSFTP / GetS3Object
        |
        v
Base64EncodeContent
        |
        v
AttributesToJSON  (name, fileName, mimeType, sourceUrl)
        |
        v
ReplaceText / JoltTransformJSON
   (assemble {"documents":[{...,"contentBase64":"<base64>"}]})
        |
        v
InvokeHTTP  (same config as Recipe A)
```

The base64-encoded body can be large. Set `InvokeHTTP`'s **Max Length to
Put in Attribute** to `0` (we never need it as an attribute) and ensure
`Send Message Body` is `true`.

## Validation tips

After the first batch lands, hit:

```bash
curl -H "Authorization: Bearer $AUTORFP_API_KEY" \
     "https://your.autorfp.example/api/indexes/$INDEX_ID/external/status"
```

You should see `documentCount` and `chunkCount` increment, and
`lastIngestAt` move to a timestamp within a few seconds of when NiFi
issued the POST.

## Smoke-test with curl

Before plumbing through NiFi, verify the endpoint works end-to-end with a
plain `curl`. The following round-trip creates a Document, waits a beat for
async ingest, and confirms chunks materialised:

```bash
export AUTORFP_API_KEY="autorfp_yourPlainTextTokenHere"
export INDEX_ID="cl_yourIndexId"
export BASE="https://your.autorfp.example"

# 1) Push a text-only doc.
curl -sS -X POST \
  -H "Authorization: Bearer $AUTORFP_API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE/api/indexes/$INDEX_ID/external/documents" \
  -d '{
    "documents": [{
      "name": "Smoke Test Doc",
      "fileName": "smoke.txt",
      "mimeType": "text/plain",
      "content": "We use AES-256 encryption at rest and in transit. Keys are rotated quarterly."
    }]
  }'

# Response:
# { "accepted": 1, "documents": [{ "id": "cl...", "fileName": "smoke.txt", "status": "PENDING" }] }

# 2) Confirm it landed.
curl -sS -H "Authorization: Bearer $AUTORFP_API_KEY" \
  "$BASE/api/indexes/$INDEX_ID/external/status"

# Response:
# { "documentCount": 1, "chunkCount": 1, "lastIngestAt": "2026-05-15T10:23:00.000Z" }

# 3) Pre-embedded chunk push (NiFi batch path).
curl -sS -X POST \
  -H "Authorization: Bearer $AUTORFP_API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE/api/indexes/$INDEX_ID/external/chunks" \
  -d '{
    "chunks": [{
      "documentId": "cl_existingDocId",
      "content": "We use AES-256 encryption.",
      "ordinal": 0,
      "embedding": [0.01, 0.02, 0.03, ...384 floats total],
      "sparseEmbedding": { "indices": [123, 456], "values": [2.1, 0.7] }
    }]
  }'

# 4) Tear down.
curl -sS -X DELETE \
  -H "Authorization: Bearer $AUTORFP_API_KEY" \
  "$BASE/api/indexes/$INDEX_ID/external/documents/cl_existingDocId"
```

## Common errors

| HTTP | `code`                  | Meaning                                            |
|------|-------------------------|----------------------------------------------------|
| 400  | `validation_error`      | Body shape wrong — see `details` for field path    |
| 401  | `unauthenticated`       | Missing/invalid `Authorization` header              |
| 403  | `forbidden`             | API key has only `READ` scope — reissue with `WRITE`|
| 404  | `not_found`             | Index id doesn't exist or your key isn't in its org|
| 429  | `rate_limited`          | 100/min bucket exhausted — honour `Retry-After`     |
