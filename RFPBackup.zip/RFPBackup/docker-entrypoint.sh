#!/bin/sh
# AutoRFP container entrypoint.
#
# Applies database migrations on every container start, then hands off to the
# main process (usually `node server.js`). Idempotent: `prisma migrate deploy`
# is a no-op when the DB is already at head.
set -e

if [ -n "${DATABASE_URL:-}" ]; then
  echo "[entrypoint] running prisma migrate deploy..."
  if ! node node_modules/prisma/build/index.js migrate deploy; then
    echo "[entrypoint] migrate deploy failed; falling back to db push --accept-data-loss"
    node node_modules/prisma/build/index.js db push --accept-data-loss
  fi
else
  echo "[entrypoint] DATABASE_URL not set — skipping migrations."
fi

exec "$@"
