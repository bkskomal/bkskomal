import { PrismaClient, Role } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SEED_EMAIL ?? "demo@autorfp.local";
  const orgName = process.env.SEED_ORG ?? "Demo Org";
  const orgSlug = orgName.toLowerCase().replace(/[^a-z0-9]+/g, "-");

  const user = await prisma.user.upsert({
    where: { email },
    update: {},
    create: { email, name: "Demo User", emailVerified: new Date() },
  });

  const org = await prisma.organization.upsert({
    where: { slug: orgSlug },
    update: {},
    create: { name: orgName, slug: orgSlug },
  });

  await prisma.membership.upsert({
    where: { userId_organizationId: { userId: user.id, organizationId: org.id } },
    update: { role: Role.OWNER },
    create: { userId: user.id, organizationId: org.id, role: Role.OWNER },
  });

  const index = await prisma.knowledgeIndex.create({
    data: {
      organizationId: org.id,
      name: "Default Knowledge Base",
      description: "Drop product docs, past RFP responses, and reference material here.",
    },
  });

  await prisma.project.create({
    data: {
      organizationId: org.id,
      name: "Sample Project",
      description: "A starter project — upload your first RFP to get going.",
      defaultIndexId: index.id,
    },
  });

  console.log(`Seeded: user=${user.email}, org=${org.slug}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
