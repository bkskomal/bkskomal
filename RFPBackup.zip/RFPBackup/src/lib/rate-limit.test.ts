import { describe, expect, it, beforeEach } from "vitest";
import {
  RATE_LIMITS,
  RateLimitError,
  rateLimit,
  MemoryBackend,
  _resetForTests,
  _setBackendForTests,
  _setNowForTests,
  getBackendName,
  type RateLimitBackend,
  type RateLimitDecision,
  type RateLimitRule,
} from "./rate-limit";

beforeEach(() => {
  _resetForTests();
});

describe("rateLimit — token bucket", () => {
  it("first call succeeds and reports no error", async () => {
    await expect(
      rateLimit(RATE_LIMITS.generate, {
        userId: "u1",
        orgId: "o1",
        route: "questions/generate",
      }),
    ).resolves.toBeUndefined();
  });

  it("allows up to `capacity` consecutive calls then throws RateLimitError", async () => {
    // Freeze time so no refill happens between calls.
    let t = 1_000_000;
    _setNowForTests(() => t);

    const rule: RateLimitRule = { capacity: 3, refillPerMinute: 1, scope: "user" };
    for (let i = 0; i < 3; i++) {
      await rateLimit(rule, { userId: "u1", route: "r" });
    }

    let caught: unknown;
    try {
      await rateLimit(rule, { userId: "u1", route: "r" });
    } catch (e) {
      caught = e;
    }
    expect(caught).toBeInstanceOf(RateLimitError);
    const err = caught as RateLimitError;
    expect(err.status).toBe(429);
    expect(err.code).toBe("rate_limited");
    expect(err.exposeMessage).toBe(true);
    expect(err.retryAfterSeconds).toBeGreaterThan(0);
    // refillPerMinute = 1, so retry after 60s.
    expect(err.retryAfterSeconds).toBe(60);
  });

  it("refills tokens over simulated time", async () => {
    let t = 1_000_000;
    _setNowForTests(() => t);

    const rule: RateLimitRule = { capacity: 2, refillPerMinute: 2, scope: "user" };
    await rateLimit(rule, { userId: "u1", route: "r" });
    await rateLimit(rule, { userId: "u1", route: "r" });
    // Bucket empty — next call rejects.
    await expect(rateLimit(rule, { userId: "u1", route: "r" })).rejects.toBeInstanceOf(
      RateLimitError,
    );

    // Advance 30 seconds — refillPerMinute=2 means +1 token in 30s.
    t += 30_000;
    await expect(rateLimit(rule, { userId: "u1", route: "r" })).resolves.toBeUndefined();

    // Still empty immediately after.
    await expect(rateLimit(rule, { userId: "u1", route: "r" })).rejects.toBeInstanceOf(
      RateLimitError,
    );

    // Advance enough to refill fully (well beyond capacity worth of refill).
    t += 5 * 60_000;
    // After full refill, capacity tokens are available.
    await rateLimit(rule, { userId: "u1", route: "r" });
    await rateLimit(rule, { userId: "u1", route: "r" });
    await expect(rateLimit(rule, { userId: "u1", route: "r" })).rejects.toBeInstanceOf(
      RateLimitError,
    );
  });

  it("retryAfterSeconds = ceil(60 / refillPerMinute)", async () => {
    let t = 1_000_000;
    _setNowForTests(() => t);

    const rule: RateLimitRule = { capacity: 1, refillPerMinute: 4, scope: "user" };
    await rateLimit(rule, { userId: "u1", route: "r" });
    try {
      await rateLimit(rule, { userId: "u1", route: "r" });
      throw new Error("expected throw");
    } catch (e) {
      expect(e).toBeInstanceOf(RateLimitError);
      expect((e as RateLimitError).retryAfterSeconds).toBe(15); // ceil(60/4)
    }
  });

  it("separate keys (different users) have independent buckets", async () => {
    let t = 1_000_000;
    _setNowForTests(() => t);

    const rule: RateLimitRule = { capacity: 2, refillPerMinute: 1, scope: "user" };
    // User A drains.
    await rateLimit(rule, { userId: "A", route: "r" });
    await rateLimit(rule, { userId: "A", route: "r" });
    await expect(rateLimit(rule, { userId: "A", route: "r" })).rejects.toBeInstanceOf(
      RateLimitError,
    );
    // User B unaffected.
    await rateLimit(rule, { userId: "B", route: "r" });
    await rateLimit(rule, { userId: "B", route: "r" });
    await expect(rateLimit(rule, { userId: "B", route: "r" })).rejects.toBeInstanceOf(
      RateLimitError,
    );
  });

  it("different routes on the same user have independent buckets", async () => {
    let t = 1_000_000;
    _setNowForTests(() => t);

    const rule: RateLimitRule = { capacity: 1, refillPerMinute: 1, scope: "user" };
    await rateLimit(rule, { userId: "u1", route: "route-a" });
    await expect(rateLimit(rule, { userId: "u1", route: "route-a" })).rejects.toBeInstanceOf(
      RateLimitError,
    );
    // Different route — fresh bucket.
    await expect(
      rateLimit(rule, { userId: "u1", route: "route-b" }),
    ).resolves.toBeUndefined();
  });

  it("org-scoped rules share a bucket across users in the same org", async () => {
    let t = 1_000_000;
    _setNowForTests(() => t);

    const rule: RateLimitRule = { capacity: 2, refillPerMinute: 1, scope: "org" };
    await rateLimit(rule, { userId: "userA", orgId: "org1", route: "r" });
    await rateLimit(rule, { userId: "userB", orgId: "org1", route: "r" });
    // Org bucket drained — even a third user in the same org is blocked.
    await expect(
      rateLimit(rule, { userId: "userC", orgId: "org1", route: "r" }),
    ).rejects.toBeInstanceOf(RateLimitError);

    // A different org has its own bucket.
    await expect(
      rateLimit(rule, { userId: "userA", orgId: "org2", route: "r" }),
    ).resolves.toBeUndefined();
  });

  it("RATE_LIMITS presets have the documented shape", () => {
    expect(RATE_LIMITS.generate).toEqual({ capacity: 30, refillPerMinute: 30, scope: "org" });
    expect(RATE_LIMITS.bulkStart).toEqual({ capacity: 5, refillPerMinute: 2, scope: "org" });
    expect(RATE_LIMITS.chat).toEqual({ capacity: 60, refillPerMinute: 60, scope: "user" });
    expect(RATE_LIMITS.providerTest).toEqual({
      capacity: 10,
      refillPerMinute: 10,
      scope: "user",
    });
  });
});

describe("MemoryBackend — direct adapter contract", () => {
  it("first call returns allowed=true and remaining=capacity-1", async () => {
    const b = new MemoryBackend();
    const rule: RateLimitRule = { capacity: 4, refillPerMinute: 1, scope: "user" };
    const d = await b.consume("k", rule);
    expect(d.allowed).toBe(true);
    expect(d.remaining).toBe(3);
    expect(d.retryAfterSeconds).toBe(0);
  });

  it("rejected calls report retryAfterSeconds = ceil(60/refillPerMinute) and remaining=0", async () => {
    const b = new MemoryBackend();
    let t = 0;
    _setNowForTests(() => t);
    const rule: RateLimitRule = { capacity: 1, refillPerMinute: 3, scope: "user" };
    await b.consume("k", rule); // allowed
    const d = await b.consume("k", rule); // rejected
    expect(d.allowed).toBe(false);
    expect(d.remaining).toBe(0);
    expect(d.retryAfterSeconds).toBe(20); // ceil(60/3)
  });

  it("reset() empties the bucket store", async () => {
    const b = new MemoryBackend();
    const rule: RateLimitRule = { capacity: 1, refillPerMinute: 1, scope: "user" };
    await b.consume("k", rule);
    expect((await b.consume("k", rule)).allowed).toBe(false);
    b.reset();
    expect((await b.consume("k", rule)).allowed).toBe(true);
  });
});

describe("_setBackendForTests — backend isolation", () => {
  it("swapping the backend isolates state from the default Memory backend", async () => {
    // Drain the default in-process backend.
    let t = 1_000_000;
    _setNowForTests(() => t);
    const rule: RateLimitRule = { capacity: 1, refillPerMinute: 1, scope: "user" };
    await rateLimit(rule, { userId: "u", route: "r" });
    await expect(rateLimit(rule, { userId: "u", route: "r" })).rejects.toBeInstanceOf(
      RateLimitError,
    );

    // Swap in a fresh backend — the new one shouldn't see the old bucket.
    _setBackendForTests(new MemoryBackend());
    await expect(rateLimit(rule, { userId: "u", route: "r" })).resolves.toBeUndefined();
  });

  it("a stub backend can short-circuit rateLimit() — exercises the adapter seam", async () => {
    const calls: Array<{ key: string; rule: RateLimitRule }> = [];
    const stub: RateLimitBackend = {
      name: "stub",
      async consume(key, rule): Promise<RateLimitDecision> {
        calls.push({ key, rule });
        // Always reject — confirms the wrapper trusts the backend's decision.
        return { allowed: false, retryAfterSeconds: 7, remaining: 0 };
      },
    };
    _setBackendForTests(stub);

    const rule: RateLimitRule = { capacity: 99, refillPerMinute: 99, scope: "user" };
    try {
      await rateLimit(rule, { userId: "u", route: "r" });
      throw new Error("expected reject");
    } catch (e) {
      expect(e).toBeInstanceOf(RateLimitError);
      expect((e as RateLimitError).retryAfterSeconds).toBe(7);
    }
    expect(calls).toHaveLength(1);
    expect(calls[0].key).toBe("user:u:r");
    expect(calls[0].rule).toEqual(rule);
  });

  it("getBackendName() reports the active backend", () => {
    expect(getBackendName()).toBe("memory");
    _setBackendForTests({
      name: "fake-redis",
      async consume(): Promise<RateLimitDecision> {
        return { allowed: true, retryAfterSeconds: 0, remaining: 1 };
      },
    });
    expect(getBackendName()).toBe("fake-redis");
  });
});
