// Personal API key issuance, lookup, and revocation.
//
// Tokens look like `autorfp_<32-char-base62>`. We hand the plaintext to the
// caller exactly once at creation time and persist only the SHA-256 hash plus
// a short prefix for display ("autorfp_aBc12Xy9..."). All lookups query by
// hash, never by plaintext.
//
// `lookupApiKey()` is on the hot path for Bearer-token authenticated requests,
// so it debounces `lastUsedAt` writes — we only update the column once per
// 60 seconds per key to keep the row from churning under load.

import { createHash, randomBytes } from "node:crypto";
import type { ApiKey, User } from "@prisma/client";
import { ApiKeyScope } from "@prisma/client";
import { prisma } from "./prisma";

export { ApiKeyScope };

export interface IssuedKey {
  id: string;
  name: string;
  /** Plaintext token. Only available at issuance time. */
  token: string;
  prefix: string;
  scope: ApiKeyScope;
  createdAt: Date;
}

export interface IssueOptions {
  name: string;
  userId: string;
  organizationId?: string | null;
  scope: ApiKeyScope;
  expiresAt?: Date | null;
}

const TOKEN_PREFIX = "autorfp_";
const TOKEN_RANDOM_LEN = 32;
const PREFIX_LEN = 8;
const BASE62 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

// --- clock seam (for tests) --------------------------------------------------
let nowFn: () => number = () => Date.now();
export function _setNowForTests(fn: () => number): void {
  nowFn = fn;
}
export function _resetNowForTests(): void {
  nowFn = () => Date.now();
}

/** Generate a random base62 string of the given length using rejection sampling. */
function randomBase62(len: number): string {
  // Read more bytes than we need so the rejection rate is negligible.
  const out: string[] = [];
  while (out.length < len) {
    const buf = randomBytes(len * 2);
    for (let i = 0; i < buf.length && out.length < len; i++) {
      // 62 * 4 = 248; reject bytes >= 248 to keep the distribution uniform.
      const b = buf[i];
      if (b < 248) out.push(BASE62[b % 62]);
    }
  }
  return out.join("");
}

export function hashToken(plaintext: string): string {
  return createHash("sha256").update(plaintext).digest("hex");
}

/** Format invariant: `autorfp_` + 32 base62 chars. */
export function isValidTokenFormat(plaintext: string): boolean {
  if (!plaintext.startsWith(TOKEN_PREFIX)) return false;
  const tail = plaintext.slice(TOKEN_PREFIX.length);
  if (tail.length !== TOKEN_RANDOM_LEN) return false;
  for (let i = 0; i < tail.length; i++) {
    if (!BASE62.includes(tail[i])) return false;
  }
  return true;
}

export async function issueApiKey(opts: IssueOptions): Promise<IssuedKey> {
  const random = randomBase62(TOKEN_RANDOM_LEN);
  const token = `${TOKEN_PREFIX}${random}`;
  const hash = hashToken(token);
  // Prefix is the first PREFIX_LEN chars of the random part — used as a
  // human-recognisable disambiguator in the UI alongside the name.
  const prefix = random.slice(0, PREFIX_LEN);

  const created = await prisma.apiKey.create({
    data: {
      name: opts.name,
      hash,
      prefix,
      userId: opts.userId,
      organizationId: opts.organizationId ?? null,
      scope: opts.scope,
      expiresAt: opts.expiresAt ?? null,
    },
  });

  return {
    id: created.id,
    name: created.name,
    token,
    prefix: created.prefix,
    scope: created.scope,
    createdAt: created.createdAt,
  };
}

export async function revokeApiKey(opts: { id: string; userId: string }): Promise<void> {
  // updateMany rather than update so we can scope by userId in a single call —
  // this also no-ops cleanly if the key doesn't exist or isn't this user's.
  await prisma.apiKey.updateMany({
    where: { id: opts.id, userId: opts.userId, revokedAt: null },
    data: { revokedAt: new Date(nowFn()) },
  });
}

export async function listApiKeys(userId: string): Promise<Array<Omit<ApiKey, "hash">>> {
  const keys = await prisma.apiKey.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
  // Drop the hash field — it never leaves the server.
  return keys.map(({ hash: _hash, ...rest }) => rest);
}

const LAST_USED_DEBOUNCE_MS = 60_000;

export async function lookupApiKey(
  plaintext: string,
): Promise<{ key: ApiKey; user: User } | null> {
  if (!isValidTokenFormat(plaintext)) return null;
  const hash = hashToken(plaintext);
  const key = await prisma.apiKey.findUnique({
    where: { hash },
    include: { user: true },
  });
  if (!key) return null;

  const now = new Date(nowFn());
  if (key.revokedAt && key.revokedAt.getTime() <= now.getTime()) return null;
  if (key.expiresAt && key.expiresAt.getTime() <= now.getTime()) return null;

  // Debounce lastUsedAt writes. Skip the update if we touched it recently.
  const last = key.lastUsedAt?.getTime() ?? 0;
  if (now.getTime() - last >= LAST_USED_DEBOUNCE_MS) {
    // Fire-and-forget — failure to refresh lastUsedAt must not break auth.
    try {
      await prisma.apiKey.update({
        where: { id: key.id },
        data: { lastUsedAt: now },
      });
      key.lastUsedAt = now;
    } catch {
      // Swallow — bookkeeping only.
    }
  }

  const { user, ...rest } = key;
  return { key: rest as ApiKey, user };
}
