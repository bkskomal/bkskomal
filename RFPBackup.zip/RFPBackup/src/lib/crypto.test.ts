import { afterEach, describe, expect, it } from "vitest";
import { createCipheriv, createHash, randomBytes } from "node:crypto";
import { _resetCryptoCachesForTests, currentKeyId, decrypt, encrypt, maskSecret } from "./crypto";
import { _resetEnvCacheForTests } from "./env";

// Helper: produce a legacy (pre-v2) envelope using a chosen master secret.
// Mirrors what `encrypt()` looked like before we added the version prefix —
// "<b64(iv)>:<b64(ct)>:<b64(tag)>" — so we can prove decrypt() still handles
// rows written by older deployments.
function makeLegacyEnvelope(plaintext: string, secret: string): string {
  const key = createHash("sha256").update(secret).digest();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("base64")}:${enc.toString("base64")}:${tag.toString("base64")}`;
}

const ORIGINAL_AUTH_SECRET = process.env.AUTH_SECRET;
const ORIGINAL_ROTATION = process.env.KEY_ROTATION_SECRET;

function restoreEnv() {
  if (ORIGINAL_AUTH_SECRET === undefined) delete process.env.AUTH_SECRET;
  else process.env.AUTH_SECRET = ORIGINAL_AUTH_SECRET;
  if (ORIGINAL_ROTATION === undefined) delete process.env.KEY_ROTATION_SECRET;
  else process.env.KEY_ROTATION_SECRET = ORIGINAL_ROTATION;
  _resetEnvCacheForTests();
  _resetCryptoCachesForTests();
}

afterEach(() => {
  restoreEnv();
});

describe("encrypt / decrypt", () => {
  it("round-trips a plain string", () => {
    const plain = "sk-or-v1-secret-value-abc123";
    const enc = encrypt(plain);
    expect(enc).not.toBe(plain);
    expect(decrypt(enc)).toBe(plain);
  });

  it("emits the v2: prefix on new ciphertexts", () => {
    const enc = encrypt("hello");
    expect(enc.startsWith("v2:")).toBe(true);
    // The blob after the prefix is a single base64 chunk — no extra colons.
    expect(enc.slice(3).includes(":")).toBe(false);
  });

  it("exposes the current key id", () => {
    expect(currentKeyId()).toBe("v2");
  });

  it("produces different ciphertexts for the same plaintext (random IV)", () => {
    const a = encrypt("hello");
    const b = encrypt("hello");
    expect(a).not.toBe(b);
    expect(decrypt(a)).toBe("hello");
    expect(decrypt(b)).toBe("hello");
  });

  it("decrypts legacy (pre-v2) ciphertexts written by older deployments", () => {
    const legacy = makeLegacyEnvelope(
      "legacy-key-from-before-versioning",
      process.env.AUTH_SECRET!,
    );
    expect(legacy.startsWith("v2:")).toBe(false);
    expect(decrypt(legacy)).toBe("legacy-key-from-before-versioning");
  });

  it("returns null on tampered ciphertext", () => {
    const enc = encrypt("safe");
    // Flip a byte inside the blob (after the v2: prefix). The auth tag
    // verification must catch it.
    const prefix = "v2:";
    const blob = Buffer.from(enc.slice(prefix.length), "base64");
    blob[blob.length - 1] ^= 0xff;
    const tampered = `${prefix}${blob.toString("base64")}`;
    expect(decrypt(tampered)).toBeNull();
  });

  it("returns null on garbage input", () => {
    expect(decrypt("not-an-envelope")).toBeNull();
    expect(decrypt(null)).toBeNull();
    expect(decrypt("")).toBeNull();
    expect(decrypt("v2:not-base64!@#")).toBeNull();
    expect(decrypt("v2:")).toBeNull();
  });
});

describe("KEY_ROTATION_SECRET fallback", () => {
  it("decrypts a v2 blob encrypted under the previous AUTH_SECRET when the rotation key is set", () => {
    // 1) Encrypt under the *old* AUTH_SECRET.
    const oldSecret = "old-auth-secret-1234567890abcdef-old";
    process.env.AUTH_SECRET = oldSecret;
    _resetEnvCacheForTests();
    _resetCryptoCachesForTests();
    const enc = encrypt("ROTATABLE");

    // 2) Simulate rotation: new AUTH_SECRET, old one moves to KEY_ROTATION_SECRET.
    process.env.AUTH_SECRET = "new-auth-secret-1234567890abcdef-new";
    process.env.KEY_ROTATION_SECRET = oldSecret;
    _resetEnvCacheForTests();
    _resetCryptoCachesForTests();

    expect(decrypt(enc)).toBe("ROTATABLE");
  });

  it("decrypts legacy ciphertexts under the rotation key too", () => {
    const oldSecret = "old-auth-secret-1234567890abcdef-old";
    const legacy = makeLegacyEnvelope("LEGACY-ROTATABLE", oldSecret);

    process.env.AUTH_SECRET = "new-auth-secret-1234567890abcdef-new";
    process.env.KEY_ROTATION_SECRET = oldSecret;
    _resetEnvCacheForTests();
    _resetCryptoCachesForTests();

    expect(decrypt(legacy)).toBe("LEGACY-ROTATABLE");
  });

  it("returns null when neither the primary nor the rotation key works", () => {
    const enc = encrypt("PROTECTED");

    process.env.AUTH_SECRET = "completely-different-secret-aaaaaaaaaaaaaa";
    process.env.KEY_ROTATION_SECRET = "also-wrong-secret-bbbbbbbbbbbbbbbbbbbb";
    _resetEnvCacheForTests();
    _resetCryptoCachesForTests();

    expect(decrypt(enc)).toBeNull();
  });

  it("encrypt() always uses the current AUTH_SECRET, never the rotation key", () => {
    process.env.AUTH_SECRET = "active-secret-xxxxxxxxxxxxxxxxxxxxxxxxxxx";
    process.env.KEY_ROTATION_SECRET = "stale-secret-yyyyyyyyyyyyyyyyyyyyyyyyy";
    _resetEnvCacheForTests();
    _resetCryptoCachesForTests();
    const enc = encrypt("PIN-TO-CURRENT");

    // Drop the rotation key — the blob must still decrypt because it was
    // pinned to the current AUTH_SECRET on write.
    delete process.env.KEY_ROTATION_SECRET;
    _resetEnvCacheForTests();
    _resetCryptoCachesForTests();
    expect(decrypt(enc)).toBe("PIN-TO-CURRENT");
  });
});

describe("maskSecret", () => {
  it("masks the middle, keeps prefix and suffix", () => {
    expect(maskSecret("sk-or-v1-abcd1234efgh5678")).toMatch(/^sk-o.*5678$/);
  });
  it("returns empty for nullish", () => {
    expect(maskSecret(null)).toBe("");
    expect(maskSecret(undefined)).toBe("");
  });
  it("fully masks short secrets", () => {
    expect(maskSecret("short")).toBe("•••••");
  });
});
