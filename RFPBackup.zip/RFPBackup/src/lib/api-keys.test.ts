import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Mock prisma before importing the module under test.
vi.mock("./prisma", () => ({
  prisma: {
    apiKey: {
      create: vi.fn(),
      findUnique: vi.fn(),
      findMany: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
    },
  },
}));

import { prisma } from "./prisma";
import {
  hashToken,
  isValidTokenFormat,
  issueApiKey,
  listApiKeys,
  lookupApiKey,
  revokeApiKey,
  _setNowForTests,
  _resetNowForTests,
} from "./api-keys";
import { ApiKeyScope } from "@prisma/client";

type MockedFn = ReturnType<typeof vi.fn>;
const create = prisma.apiKey.create as unknown as MockedFn;
const findUnique = prisma.apiKey.findUnique as unknown as MockedFn;
const findMany = prisma.apiKey.findMany as unknown as MockedFn;
const update = prisma.apiKey.update as unknown as MockedFn;
const updateMany = prisma.apiKey.updateMany as unknown as MockedFn;

beforeEach(() => {
  create.mockReset();
  findUnique.mockReset();
  findMany.mockReset();
  update.mockReset();
  updateMany.mockReset();
});

afterEach(() => {
  _resetNowForTests();
});

describe("issueApiKey", () => {
  it("returns plaintext token and persists only the hash + prefix", async () => {
    create.mockImplementation(async ({ data }: any) => ({
      id: "key_1",
      name: data.name,
      hash: data.hash,
      prefix: data.prefix,
      userId: data.userId,
      organizationId: data.organizationId,
      scope: data.scope,
      lastUsedAt: null,
      expiresAt: data.expiresAt,
      revokedAt: null,
      createdAt: new Date("2026-01-01T00:00:00Z"),
    }));

    const issued = await issueApiKey({
      name: "CI",
      userId: "user_1",
      organizationId: "org_1",
      scope: ApiKeyScope.READ,
    });

    expect(issued.token.startsWith("autorfp_")).toBe(true);
    expect(issued.token).toHaveLength("autorfp_".length + 32);
    expect(issued.prefix).toHaveLength(8);
    expect(issued.id).toBe("key_1");

    // What got persisted: a sha256 of the plaintext, never the plaintext itself.
    const persisted = create.mock.calls[0][0].data;
    expect(persisted.hash).toBe(hashToken(issued.token));
    expect(persisted.hash).not.toContain(issued.token);
    expect(persisted.prefix).toBe(issued.token.slice("autorfp_".length, "autorfp_".length + 8));
    // No raw token stored anywhere on the row.
    expect(JSON.stringify(persisted)).not.toContain(issued.token);
  });

  it("token format invariant: autorfp_ + 32 base62 chars", async () => {
    create.mockImplementation(async ({ data }: any) => ({
      id: "k",
      name: data.name,
      hash: data.hash,
      prefix: data.prefix,
      userId: data.userId,
      organizationId: null,
      scope: data.scope,
      lastUsedAt: null,
      expiresAt: null,
      revokedAt: null,
      createdAt: new Date(),
    }));
    const { token } = await issueApiKey({
      name: "x",
      userId: "u",
      scope: ApiKeyScope.READ,
    });
    expect(isValidTokenFormat(token)).toBe(true);
    // Reject obvious tampering.
    expect(isValidTokenFormat("nope_" + token.slice(8))).toBe(false);
    expect(isValidTokenFormat("autorfp_short")).toBe(false);
    expect(isValidTokenFormat("autorfp_!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" /* len 40 */)).toBe(
      false,
    );
  });
});

describe("lookupApiKey", () => {
  function rowFor(token: string, overrides: Partial<any> = {}) {
    return {
      id: "key_1",
      name: "k",
      hash: hashToken(token),
      prefix: token.slice("autorfp_".length, "autorfp_".length + 8),
      userId: "user_1",
      organizationId: null,
      scope: ApiKeyScope.READ,
      lastUsedAt: null,
      expiresAt: null,
      revokedAt: null,
      createdAt: new Date("2026-01-01T00:00:00Z"),
      user: { id: "user_1", email: "u@example.com", name: null },
      ...overrides,
    };
  }

  it("accepts the issued plaintext and returns key + user", async () => {
    const token = "autorfp_" + "a".repeat(32);
    findUnique.mockResolvedValueOnce(rowFor(token));
    update.mockResolvedValueOnce({});

    const result = await lookupApiKey(token);
    expect(result).not.toBeNull();
    expect(result!.user.id).toBe("user_1");
    expect(result!.key.id).toBe("key_1");
  });

  it("rejects malformed tokens before hitting the DB", async () => {
    const result = await lookupApiKey("not-a-token");
    expect(result).toBeNull();
    expect(findUnique).not.toHaveBeenCalled();
  });

  it("rejects after revocation", async () => {
    const token = "autorfp_" + "b".repeat(32);
    _setNowForTests(() => Date.parse("2026-02-01T00:00:00Z"));
    findUnique.mockResolvedValueOnce(
      rowFor(token, { revokedAt: new Date("2026-01-15T00:00:00Z") }),
    );
    expect(await lookupApiKey(token)).toBeNull();
  });

  it("rejects after expiry", async () => {
    const token = "autorfp_" + "c".repeat(32);
    _setNowForTests(() => Date.parse("2026-02-01T00:00:00Z"));
    findUnique.mockResolvedValueOnce(
      rowFor(token, { expiresAt: new Date("2026-01-15T00:00:00Z") }),
    );
    expect(await lookupApiKey(token)).toBeNull();
  });

  it("debounces lastUsedAt updates (>60s gap → write, <60s → skip)", async () => {
    const token = "autorfp_" + "d".repeat(32);
    let now = Date.parse("2026-03-01T00:00:00Z");
    _setNowForTests(() => now);

    // First lookup: no prior lastUsedAt → must write.
    findUnique.mockResolvedValueOnce(rowFor(token, { lastUsedAt: null }));
    update.mockResolvedValueOnce({});
    await lookupApiKey(token);
    expect(update).toHaveBeenCalledTimes(1);

    // Second lookup 30s later — within debounce window, must NOT write.
    now += 30_000;
    findUnique.mockResolvedValueOnce(
      rowFor(token, { lastUsedAt: new Date(now - 30_000) }),
    );
    await lookupApiKey(token);
    expect(update).toHaveBeenCalledTimes(1); // unchanged

    // Third lookup 90s later — past debounce, must write.
    now += 60_000;
    findUnique.mockResolvedValueOnce(
      rowFor(token, { lastUsedAt: new Date(now - 90_000) }),
    );
    update.mockResolvedValueOnce({});
    await lookupApiKey(token);
    expect(update).toHaveBeenCalledTimes(2);
  });

  it("returns null when the hash isn't found", async () => {
    findUnique.mockResolvedValueOnce(null);
    expect(await lookupApiKey("autorfp_" + "e".repeat(32))).toBeNull();
  });
});

describe("listApiKeys", () => {
  it("strips the hash field from every row", async () => {
    findMany.mockResolvedValueOnce([
      {
        id: "k1",
        name: "n",
        hash: "secret-hash",
        prefix: "abcdefgh",
        userId: "u",
        organizationId: null,
        scope: ApiKeyScope.READ,
        lastUsedAt: null,
        expiresAt: null,
        revokedAt: null,
        createdAt: new Date(),
      },
    ]);
    const out = await listApiKeys("u");
    expect(out).toHaveLength(1);
    expect((out[0] as any).hash).toBeUndefined();
    expect(out[0].id).toBe("k1");
  });
});

describe("revokeApiKey", () => {
  it("scopes the update to the owning user and only un-revoked rows", async () => {
    updateMany.mockResolvedValueOnce({ count: 1 });
    await revokeApiKey({ id: "k1", userId: "u1" });
    expect(updateMany).toHaveBeenCalledWith({
      where: { id: "k1", userId: "u1", revokedAt: null },
      data: expect.objectContaining({ revokedAt: expect.any(Date) }),
    });
  });
});
