// Symmetric encryption for at-rest secrets (LLM API keys, etc.).
//
// AES-256-GCM with a 12-byte random IV per ciphertext. The encryption key is
// derived from AUTH_SECRET via SHA-256 — single-tenant infra, single secret.
// In a multi-region SaaS we'd swap to a real KMS (AWS KMS, GCP KMS, Vault) —
// the call sites only know `encrypt(s)` / `decrypt(s)`, so swapping is a one
// file change.
//
// --- Ciphertext format & key rotation ---
//
// Current format (v2): `v2:<base64( iv | authTag | ciphertext )>` — a single
// base64 blob keeps us free of any colon-parsing fragility and makes the
// version prefix the only structural delimiter.
//
// Legacy format (no prefix): `<b64(iv)>:<b64(ciphertext)>:<b64(authTag)>` —
// still accepted by decrypt() so existing rows continue to work. Once all
// stored blobs have been re-encrypted (see scripts/reencrypt-secrets.mjs) the
// legacy branch can be removed.
//
// To rotate the master secret without downtime, set KEY_ROTATION_SECRET to the
// previous AUTH_SECRET value before changing AUTH_SECRET. decrypt() will try
// the current AUTH_SECRET-derived key first, then fall back to the rotation
// key. encrypt() always uses the current key, so newly-written rows are bound
// to the new secret. After running the re-encrypt script, KEY_ROTATION_SECRET
// can be cleared.

import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { env } from "@/lib/env";

const ALGO = "aes-256-gcm";
const IV_LEN = 12;
const TAG_LEN = 16;

/** Stable identifier for the current encryption scheme. Stored as a prefix on
 *  every new ciphertext so we can migrate format / KDF later without ambiguity. */
const CURRENT_KEY_ID = "v2";

let cachedPrimaryKey: Buffer | null = null;
let cachedRotationKey: Buffer | null = null;

function deriveKey(secret: string): Buffer {
  return createHash("sha256").update(secret).digest();
}

function primaryKey(): Buffer {
  if (cachedPrimaryKey) return cachedPrimaryKey;
  cachedPrimaryKey = deriveKey(env.AUTH_SECRET);
  return cachedPrimaryKey;
}

function rotationKey(): Buffer | null {
  if (cachedRotationKey) return cachedRotationKey;
  const rot = env.KEY_ROTATION_SECRET;
  if (!rot) return null;
  cachedRotationKey = deriveKey(rot);
  return cachedRotationKey;
}

/** @internal test helper — clears module-level key caches so a test can
 *  swap env vars between calls without restarting the process. */
export function _resetCryptoCachesForTests(): void {
  cachedPrimaryKey = null;
  cachedRotationKey = null;
}

/** Identifier for the key/format that encrypt() is currently emitting. Callers
 *  that record per-row provenance (audit log, re-encrypt script) should
 *  persist this alongside the ciphertext. */
export function currentKeyId(): string {
  return CURRENT_KEY_ID;
}

/** Encrypt a string. Returns a versioned envelope: `v2:<base64(iv|tag|ct)>`. */
export function encrypt(plaintext: string): string {
  if (!plaintext) return plaintext;
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGO, primaryKey(), iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  const blob = Buffer.concat([iv, tag, enc]).toString("base64");
  return `${CURRENT_KEY_ID}:${blob}`;
}

/** Decrypt an envelope produced by `encrypt`. Returns null on tamper / bad input. */
export function decrypt(envelope: string | null | undefined): string | null {
  if (!envelope) return null;
  // Versioned format wins — single colon between prefix and blob.
  if (envelope.startsWith(`${CURRENT_KEY_ID}:`)) {
    return decryptV2(envelope.slice(CURRENT_KEY_ID.length + 1));
  }
  // Legacy: "iv:ct:tag", base64-encoded each. Pre-rotation rows.
  return decryptLegacy(envelope);
}

function tryDecryptWithKey(key: Buffer, iv: Buffer, tag: Buffer, ct: Buffer): string | null {
  try {
    const decipher = createDecipheriv(ALGO, key, iv);
    decipher.setAuthTag(tag);
    const dec = Buffer.concat([decipher.update(ct), decipher.final()]);
    return dec.toString("utf8");
  } catch {
    return null;
  }
}

function decryptV2(blob: string): string | null {
  let buf: Buffer;
  try {
    buf = Buffer.from(blob, "base64");
  } catch {
    return null;
  }
  if (buf.length < IV_LEN + TAG_LEN + 1) return null;
  const iv = buf.subarray(0, IV_LEN);
  const tag = buf.subarray(IV_LEN, IV_LEN + TAG_LEN);
  const ct = buf.subarray(IV_LEN + TAG_LEN);
  return decryptWithFallback(iv, tag, ct);
}

function decryptLegacy(envelope: string): string | null {
  const parts = envelope.split(":");
  if (parts.length !== 3) return null;
  let iv: Buffer;
  let ct: Buffer;
  let tag: Buffer;
  try {
    iv = Buffer.from(parts[0], "base64");
    ct = Buffer.from(parts[1], "base64");
    tag = Buffer.from(parts[2], "base64");
  } catch {
    return null;
  }
  if (iv.length !== IV_LEN || tag.length !== TAG_LEN) return null;
  return decryptWithFallback(iv, tag, ct);
}

function decryptWithFallback(iv: Buffer, tag: Buffer, ct: Buffer): string | null {
  const primary = tryDecryptWithKey(primaryKey(), iv, tag, ct);
  if (primary !== null) return primary;
  const rot = rotationKey();
  if (!rot) return null;
  return tryDecryptWithKey(rot, iv, tag, ct);
}

/**
 * Mask a secret for display: show first 4 and last 4 chars, * the rest.
 * "sk-or-v1-abcd1234efgh5678" → "sk-o…5678" (or "sk-or-v1-…5678" if longer).
 */
export function maskSecret(s: string | null | undefined): string {
  if (!s) return "";
  if (s.length <= 8) return "•".repeat(s.length);
  return `${s.slice(0, 4)}${"•".repeat(Math.max(4, s.length - 8))}${s.slice(-4)}`;
}
