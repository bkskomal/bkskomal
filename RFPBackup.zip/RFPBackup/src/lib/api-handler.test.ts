import { describe, expect, it } from "vitest";
import { z, ZodError } from "zod";
import { withApiHandler, errorResponse } from "./api-handler";
import { AuthError, NotFoundError, ValidationError } from "./errors";

describe("withApiHandler", () => {
  it("passes through successful responses", async () => {
    const handler = withApiHandler(async () => Response.json({ ok: true }));
    const res = await handler(new Request("http://x"), { params: Promise.resolve({}) });
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ok: true });
  });

  it("translates AuthError to 401", async () => {
    const handler = withApiHandler(async () => {
      throw new AuthError("not signed in");
    });
    const res = await handler(new Request("http://x"), { params: Promise.resolve({}) });
    expect(res.status).toBe(401);
    expect(await res.json()).toMatchObject({
      error: "not signed in",
      code: "unauthenticated",
    });
  });

  it("translates NotFoundError to 404", async () => {
    const handler = withApiHandler(async () => {
      throw new NotFoundError("missing");
    });
    const res = await handler(new Request("http://x"), { params: Promise.resolve({}) });
    expect(res.status).toBe(404);
  });

  it("translates ZodError → ValidationError 400 with details", async () => {
    const schema = z.object({ name: z.string() });
    const handler = withApiHandler(async () => {
      schema.parse({});
      return Response.json({});
    });
    const res = await handler(new Request("http://x"), { params: Promise.resolve({}) });
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.code).toBe("validation_error");
    expect(body.details).toBeDefined();
  });

  it("returns 500 for unknown errors", () => {
    const res = errorResponse(new Error("internal"));
    expect(res.status).toBe(500);
  });
});
