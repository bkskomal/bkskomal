// Collaborative edit awareness + soft lock for Response.content.
//
// IMPORTANT: This is NOT a CRDT. There is no operational transform, no Yjs,
// no WebSocket layer. The contract is much weaker and intentionally so:
//
//   1. Only one user holds the "edit lock" on a response at a time.
//   2. The lock is soft: it auto-expires if the holder stops heartbeating
//      for HEARTBEAT_TTL_MS (~60s). Closing the browser tab without
//      explicitly releasing is therefore safe — the next user can take
//      ownership after a minute.
//   3. While editing, the client debounce-saves the textarea contents to
//      `draftContent` every AUTOSAVE_DEBOUNCE_MS (~5s). This is a single-
//      writer column; the last writer wins. Two editors can never reach
//      this code path simultaneously because of (1).
//   4. A monotonic `version` is bumped on every formal commit (finalize)
//      so a stale tab that survived the lock window can detect the
//      conflict and refuse to clobber.
//
// Trade-off: 5-second autosave + soft lock covers ~95% of real
// collaboration scenarios (the same human editing two tabs, two humans
// editing the same response at the same time) without a websocket layer
// or CRDT runtime. The remaining 5% — edits made while the network is
// partitioned, or two clients racing inside the same lock window — fall
// back to "last writer wins" with audit-trail visibility via the version
// field.
//
// All public functions are single-prisma-call where feasible to avoid
// TOCTOU races between "did I own this lock?" and "did I update it?".

import { prisma } from "@/lib/prisma";
import { editLocksAcquiredTotal, editDraftsSavedTotal } from "@/lib/metrics";

/** Lock expires if no heartbeat is received within this window. */
export const HEARTBEAT_TTL_MS = 60_000;

/** Client-side debounce target for draft autosave. Exported for the UI hook. */
export const AUTOSAVE_DEBOUNCE_MS = 5_000;

/** Internal clock indirection so tests can mock time. */
let nowFn: () => number = () => Date.now();

/** @internal — for tests only. */
export function _setNowForTests(fn: () => number): void {
  nowFn = fn;
}

/** @internal — for tests only. */
export function _resetNowForTests(): void {
  nowFn = () => Date.now();
}

function now(): Date {
  return new Date(nowFn());
}

export type AcquireResult =
  | {
      ok: true;
      session: {
        editorId: string;
        version: number;
        draftContent: string | null;
        draftUpdatedAt: Date | null;
      };
    }
  | {
      ok: false;
      reason: "locked_by_other";
      lockedBy: { id: string; name: string | null; email: string };
      lastHeartbeat: Date;
    };

/**
 * Attempt to take exclusive edit ownership of `responseId` for `userId`.
 *
 * Semantics:
 *   - No row, or row with editorId=null  → take it.
 *   - Existing live session by the same user → idempotent refresh.
 *   - Existing live session by *another* user → reject with `locked_by_other`.
 *   - Existing session whose lastHeartbeat has aged past TTL → take it.
 *
 * We use `upsert` so the "no row yet" and "stale row" cases collapse into a
 * single round-trip on the happy path. The "live other holder" case still
 * requires a follow-up read because Prisma's upsert can't conditionally
 * branch on the existing row's values.
 */
export async function acquireEditLock(opts: {
  responseId: string;
  userId: string;
}): Promise<AcquireResult> {
  const { responseId, userId } = opts;
  const t = now();
  const staleBefore = new Date(t.getTime() - HEARTBEAT_TTL_MS);

  const existing = await prisma.responseEditSession.findUnique({
    where: { responseId },
  });

  // Live lock held by *another* user — refuse.
  if (
    existing &&
    existing.editorId &&
    existing.editorId !== userId &&
    existing.lastHeartbeat &&
    existing.lastHeartbeat > staleBefore
  ) {
    const holder = await prisma.user.findUnique({
      where: { id: existing.editorId },
      select: { id: true, name: true, email: true },
    });
    try {
      editLocksAcquiredTotal.inc({ result: "locked_by_other" });
    } catch {
      // ignore — telemetry must never break the request
    }
    return {
      ok: false,
      reason: "locked_by_other",
      // Holder *should* exist; if the user row was deleted out from under us
      // (FK is intentionally not cascading on editorId), surface a synthetic
      // placeholder rather than 500ing the request.
      lockedBy: holder ?? {
        id: existing.editorId,
        name: null,
        email: "(deleted user)",
      },
      lastHeartbeat: existing.lastHeartbeat,
    };
  }

  // Either no row, the row is stale, or we already own it. Upsert claims
  // ownership in one statement so a concurrent caller can't race us into the
  // same row.
  const session = await prisma.responseEditSession.upsert({
    where: { responseId },
    create: {
      responseId,
      editorId: userId,
      lastHeartbeat: t,
    },
    update: {
      editorId: userId,
      lastHeartbeat: t,
    },
  });

  try {
    editLocksAcquiredTotal.inc({ result: "ok" });
  } catch {
    // ignore
  }

  return {
    ok: true,
    session: {
      editorId: userId,
      version: session.version,
      draftContent: session.draftContent,
      draftUpdatedAt: session.draftUpdatedAt,
    },
  };
}

/**
 * Refresh the heartbeat for the caller's lock. Returns the new expiry.
 *
 * If the caller isn't the current editor (either someone else took over or
 * the lock was released), reject with `not_editor` — the client should
 * stop heartbeating and re-acquire if they still want to edit.
 */
export async function heartbeat(opts: {
  responseId: string;
  userId: string;
}): Promise<{ ok: true; expiresAt: Date } | { ok: false; reason: string }> {
  const { responseId, userId } = opts;
  const t = now();
  // Single conditional update: only refreshes if the row's editorId matches.
  // Using updateMany so a non-match returns count=0 instead of throwing.
  const result = await prisma.responseEditSession.updateMany({
    where: { responseId, editorId: userId },
    data: { lastHeartbeat: t },
  });
  if (result.count === 0) {
    return { ok: false, reason: "not_editor" };
  }
  return { ok: true, expiresAt: new Date(t.getTime() + HEARTBEAT_TTL_MS) };
}

/**
 * Persist a debounced draft of the in-flight edit.
 *
 * Rejected with:
 *   - `version_conflict` when the client's `expectedVersion` doesn't match
 *     the server-side version. This means a different editor formally
 *     committed between when the caller acquired the lock and now —
 *     refusing protects them from silently clobbering that commit.
 *   - `lock_lost` when the caller is no longer the recorded editor. This
 *     can happen if the lock TTL expired (e.g. tab was backgrounded) and
 *     another user grabbed ownership in the interim.
 *
 * On success: writes draftContent, bumps draftUpdatedAt, refreshes the
 * heartbeat (a successful save IS an editor liveness signal — counts as
 * a heartbeat too), and returns the unchanged version. The version is
 * bumped only on formal commits via the finalize route, not on draft
 * saves, so a long editing session that produces dozens of debounced
 * drafts stays at the same version until the user clicks Publish.
 */
export async function saveDraft(opts: {
  responseId: string;
  userId: string;
  content: string;
  expectedVersion: number;
}): Promise<
  | { ok: true; version: number }
  | { ok: false; reason: "version_conflict" | "lock_lost"; serverVersion: number }
> {
  const { responseId, userId, content, expectedVersion } = opts;
  const existing = await prisma.responseEditSession.findUnique({
    where: { responseId },
  });
  if (!existing || existing.editorId !== userId) {
    try {
      editDraftsSavedTotal.inc({ result: "lock_lost" });
    } catch {
      // ignore
    }
    return {
      ok: false,
      reason: "lock_lost",
      serverVersion: existing?.version ?? 0,
    };
  }
  if (existing.version !== expectedVersion) {
    try {
      editDraftsSavedTotal.inc({ result: "version_conflict" });
    } catch {
      // ignore
    }
    return {
      ok: false,
      reason: "version_conflict",
      serverVersion: existing.version,
    };
  }
  const t = now();
  const updated = await prisma.responseEditSession.update({
    where: { responseId },
    data: {
      draftContent: content,
      draftUpdatedAt: t,
      lastHeartbeat: t,
    },
  });
  try {
    editDraftsSavedTotal.inc({ result: "ok" });
  } catch {
    // ignore
  }
  return { ok: true, version: updated.version };
}

/**
 * Release the edit lock. No-op if the caller isn't the current editor —
 * we want this to be safe to call from `useEffect` cleanup paths without
 * the UI needing to track whether it actually still owns the lock.
 *
 * We null out `editorId` rather than deleting the row so the
 * `version` counter survives — protecting future editors from a
 * stale-version race when they reacquire the lock right after release.
 */
export async function releaseEditLock(opts: {
  responseId: string;
  userId: string;
}): Promise<void> {
  await prisma.responseEditSession.updateMany({
    where: { responseId: opts.responseId, editorId: opts.userId },
    data: { editorId: null, lastHeartbeat: null },
  });
}

/**
 * Read-only view of the edit state. Open to any caller with read access on
 * the underlying response — used by collaborators to render "🔒 Editing
 * locked by <name>" banners without trying to take the lock.
 *
 * `isStale=true` means the recorded session's last heartbeat is older than
 * TTL, so the next acquire call will succeed even though `editorId` is
 * non-null in the DB. The UI uses this to render "Start editing" rather
 * than "Locked by <stale user>" when the lock is essentially abandoned.
 */
export async function getEditState(responseId: string): Promise<{
  editorId: string | null;
  editor: { id: string; name: string | null; email: string } | null;
  lastHeartbeat: Date | null;
  version: number;
  draftContent: string | null;
  draftUpdatedAt: Date | null;
  isStale: boolean;
}> {
  const session = await prisma.responseEditSession.findUnique({
    where: { responseId },
    include: {
      // No relation on schema for editor; fetch via secondary query to keep
      // this readable. Most calls return null anyway (no active editor).
    },
  });
  if (!session) {
    return {
      editorId: null,
      editor: null,
      lastHeartbeat: null,
      version: 0,
      draftContent: null,
      draftUpdatedAt: null,
      isStale: false,
    };
  }
  const t = now();
  const isStale =
    !!session.lastHeartbeat &&
    session.lastHeartbeat.getTime() < t.getTime() - HEARTBEAT_TTL_MS;

  let editor: { id: string; name: string | null; email: string } | null = null;
  if (session.editorId) {
    editor = await prisma.user.findUnique({
      where: { id: session.editorId },
      select: { id: true, name: true, email: true },
    });
  }

  return {
    editorId: session.editorId,
    editor,
    lastHeartbeat: session.lastHeartbeat,
    version: session.version,
    draftContent: session.draftContent,
    draftUpdatedAt: session.draftUpdatedAt,
    isStale,
  };
}

/**
 * Sweep stale locks: null out editorId on any session whose lastHeartbeat
 * is older than 2× TTL.
 *
 * Why 2× and not 1×? The 1× window is what triggers a fresh `acquire` to
 * succeed; sweeping at exactly 1× would race with in-flight callers that
 * are about to acquire. Doubling the window gives the foreground path
 * priority — by the time the sweeper considers a row, it's been
 * completely abandoned for at least two minutes.
 *
 * Returns the number of rows cleared, primarily so the periodic tick can
 * log it.
 */
export async function expireStaleLocks(): Promise<number> {
  const cutoff = new Date(nowFn() - HEARTBEAT_TTL_MS * 2);
  const result = await prisma.responseEditSession.updateMany({
    where: {
      editorId: { not: null },
      OR: [{ lastHeartbeat: null }, { lastHeartbeat: { lt: cutoff } }],
    },
    data: { editorId: null, lastHeartbeat: null },
  });
  return result.count;
}

/**
 * Commit the draft (or an explicit content override) to Response.content.
 * Releases the lock and bumps the version atomically so a stale tab that
 * survived the lock window can detect the conflict on its next save.
 *
 * Reject with `version_conflict` if the caller's `expectedVersion`
 * doesn't match the current server version.
 *
 * Reject with `not_editor` if the caller doesn't currently hold the lock.
 * (Without this guard, a viewer could call finalize and publish whatever
 * `content` they pass — the lock is the auth check for "you're the one
 * who's been writing this draft".)
 */
export async function commitDraft(opts: {
  responseId: string;
  userId: string;
  expectedVersion: number;
  contentOverride?: string;
}): Promise<
  | { ok: true; version: number; content: string }
  | {
      ok: false;
      reason: "version_conflict" | "not_editor";
      serverVersion: number;
    }
> {
  const { responseId, userId, expectedVersion, contentOverride } = opts;
  const session = await prisma.responseEditSession.findUnique({
    where: { responseId },
  });
  if (!session || session.editorId !== userId) {
    return {
      ok: false,
      reason: "not_editor",
      serverVersion: session?.version ?? 0,
    };
  }
  if (session.version !== expectedVersion) {
    return {
      ok: false,
      reason: "version_conflict",
      serverVersion: session.version,
    };
  }
  const finalContent = contentOverride ?? session.draftContent ?? "";

  // Two-table write — wrap in an interactive transaction so the
  // Response.content update and the lock release are atomic. If either
  // half fails the other rolls back.
  const [updatedResponse, updatedSession] = await prisma.$transaction([
    prisma.response.update({
      where: { id: responseId },
      data: { content: finalContent },
      select: { id: true, content: true },
    }),
    prisma.responseEditSession.update({
      where: { responseId },
      data: {
        version: { increment: 1 },
        draftContent: null,
        draftUpdatedAt: null,
        editorId: null,
        lastHeartbeat: null,
      },
    }),
  ]);

  return {
    ok: true,
    version: updatedSession.version,
    content: updatedResponse.content,
  };
}
