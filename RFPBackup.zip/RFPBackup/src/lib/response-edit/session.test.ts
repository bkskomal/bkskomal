import { describe, expect, it, beforeEach, afterEach, vi } from "vitest";

// Mock prisma before importing the module under test so the import gets our
// stub instance.
vi.mock("@/lib/prisma", () => ({
  prisma: {
    responseEditSession: {
      findUnique: vi.fn(),
      upsert: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
    },
    user: {
      findUnique: vi.fn(),
    },
    response: {
      update: vi.fn(),
    },
    // Used by commitDraft's interactive transaction. The mock just resolves
    // the list of supplied prisma promises in order (each "promise" returned
    // from response.update / responseEditSession.update is the value we
    // set up via .mockResolvedValueOnce, so $transaction returns those
    // values as a tuple — matching prisma.$transaction's array form).
    $transaction: vi.fn(async (operations: Promise<unknown>[]) =>
      Promise.all(operations),
    ),
  },
}));

import { prisma } from "@/lib/prisma";
import {
  acquireEditLock,
  commitDraft,
  expireStaleLocks,
  getEditState,
  HEARTBEAT_TTL_MS,
  heartbeat,
  releaseEditLock,
  saveDraft,
  _resetNowForTests,
  _setNowForTests,
} from "./session";

type MockedFn = ReturnType<typeof vi.fn>;
const sessionFindUnique = prisma.responseEditSession.findUnique as unknown as MockedFn;
const sessionUpsert = prisma.responseEditSession.upsert as unknown as MockedFn;
const sessionUpdate = prisma.responseEditSession.update as unknown as MockedFn;
const sessionUpdateMany = prisma.responseEditSession.updateMany as unknown as MockedFn;
const userFindUnique = prisma.user.findUnique as unknown as MockedFn;
const responseUpdate = prisma.response.update as unknown as MockedFn;
const transactionMock = (
  prisma as unknown as { $transaction: MockedFn }
).$transaction;

const RESPONSE_ID = "resp-1";
const USER_A = "user-a";
const USER_B = "user-b";

// Anchor "now" at a stable epoch so TTL arithmetic in the assertions is
// readable.
const T0 = new Date("2026-05-14T12:00:00Z").getTime();

beforeEach(() => {
  vi.clearAllMocks();
  _setNowForTests(() => T0);
});

afterEach(() => {
  _resetNowForTests();
});

describe("acquireEditLock", () => {
  it("takes ownership when no session exists yet", async () => {
    sessionFindUnique.mockResolvedValueOnce(null);
    sessionUpsert.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      lastHeartbeat: new Date(T0),
      version: 0,
      draftContent: null,
      draftUpdatedAt: null,
    });

    const r = await acquireEditLock({ responseId: RESPONSE_ID, userId: USER_A });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.session.editorId).toBe(USER_A);
    expect(r.session.version).toBe(0);
    expect(sessionUpsert).toHaveBeenCalledOnce();
    const arg = sessionUpsert.mock.calls[0][0];
    expect(arg.where).toEqual({ responseId: RESPONSE_ID });
    expect(arg.create.editorId).toBe(USER_A);
    expect(arg.update.editorId).toBe(USER_A);
  });

  it("rejects with locked_by_other when a live session is held by a different user", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_B,
      // 30s ago — well within TTL.
      lastHeartbeat: new Date(T0 - 30_000),
      version: 4,
      draftContent: "in flight",
      draftUpdatedAt: new Date(T0 - 30_000),
    });
    userFindUnique.mockResolvedValueOnce({
      id: USER_B,
      name: "Bob",
      email: "bob@example.com",
    });

    const r = await acquireEditLock({ responseId: RESPONSE_ID, userId: USER_A });
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.reason).toBe("locked_by_other");
    expect(r.lockedBy.id).toBe(USER_B);
    expect(r.lockedBy.name).toBe("Bob");
    expect(r.lockedBy.email).toBe("bob@example.com");
    expect(sessionUpsert).not.toHaveBeenCalled();
  });

  it("takes ownership when the existing session is past its TTL", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_B,
      // 5 minutes ago — well past TTL of 60s.
      lastHeartbeat: new Date(T0 - 5 * 60_000),
      version: 2,
      draftContent: null,
      draftUpdatedAt: null,
    });
    sessionUpsert.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      lastHeartbeat: new Date(T0),
      version: 2,
      draftContent: null,
      draftUpdatedAt: null,
    });

    const r = await acquireEditLock({ responseId: RESPONSE_ID, userId: USER_A });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.session.editorId).toBe(USER_A);
    expect(r.session.version).toBe(2);
    expect(userFindUnique).not.toHaveBeenCalled();
  });
});

describe("heartbeat", () => {
  it("refreshes lastHeartbeat when caller is the current editor", async () => {
    sessionUpdateMany.mockResolvedValueOnce({ count: 1 });
    const r = await heartbeat({ responseId: RESPONSE_ID, userId: USER_A });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.expiresAt.getTime()).toBe(T0 + HEARTBEAT_TTL_MS);
    const arg = sessionUpdateMany.mock.calls[0][0];
    expect(arg.where).toEqual({ responseId: RESPONSE_ID, editorId: USER_A });
    expect(arg.data.lastHeartbeat).toBeInstanceOf(Date);
  });

  it("rejects when caller is not the current editor", async () => {
    sessionUpdateMany.mockResolvedValueOnce({ count: 0 });
    const r = await heartbeat({ responseId: RESPONSE_ID, userId: USER_A });
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.reason).toBe("not_editor");
  });
});

describe("saveDraft", () => {
  it("rejects with version_conflict when expectedVersion mismatches", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      lastHeartbeat: new Date(T0),
      version: 5,
      draftContent: null,
      draftUpdatedAt: null,
    });
    const r = await saveDraft({
      responseId: RESPONSE_ID,
      userId: USER_A,
      content: "x",
      expectedVersion: 3,
    });
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.reason).toBe("version_conflict");
    expect(r.serverVersion).toBe(5);
    expect(sessionUpdate).not.toHaveBeenCalled();
  });

  it("rejects with lock_lost when the editor changed", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_B,
      lastHeartbeat: new Date(T0),
      version: 0,
      draftContent: null,
      draftUpdatedAt: null,
    });
    const r = await saveDraft({
      responseId: RESPONSE_ID,
      userId: USER_A,
      content: "x",
      expectedVersion: 0,
    });
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.reason).toBe("lock_lost");
    expect(r.serverVersion).toBe(0);
    expect(sessionUpdate).not.toHaveBeenCalled();
  });

  it("happy path persists draft, refreshes heartbeat, leaves version unchanged", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      lastHeartbeat: new Date(T0 - 1000),
      version: 7,
      draftContent: "old",
      draftUpdatedAt: new Date(T0 - 1000),
    });
    sessionUpdate.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      lastHeartbeat: new Date(T0),
      version: 7,
      draftContent: "new draft",
      draftUpdatedAt: new Date(T0),
    });

    const r = await saveDraft({
      responseId: RESPONSE_ID,
      userId: USER_A,
      content: "new draft",
      expectedVersion: 7,
    });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.version).toBe(7);
    const updateArg = sessionUpdate.mock.calls[0][0];
    expect(updateArg.data.draftContent).toBe("new draft");
    expect(updateArg.data.lastHeartbeat).toBeInstanceOf(Date);
  });
});

describe("releaseEditLock", () => {
  it("clears editorId only when caller is the current editor", async () => {
    sessionUpdateMany.mockResolvedValueOnce({ count: 1 });
    await releaseEditLock({ responseId: RESPONSE_ID, userId: USER_A });
    const arg = sessionUpdateMany.mock.calls[0][0];
    expect(arg.where).toEqual({ responseId: RESPONSE_ID, editorId: USER_A });
    expect(arg.data).toEqual({ editorId: null, lastHeartbeat: null });
  });

  it("is a no-op (no throw) when caller does not hold the lock", async () => {
    sessionUpdateMany.mockResolvedValueOnce({ count: 0 });
    await expect(
      releaseEditLock({ responseId: RESPONSE_ID, userId: USER_A }),
    ).resolves.toBeUndefined();
  });
});

describe("expireStaleLocks", () => {
  it("nulls editorId on sessions whose lastHeartbeat is older than 2x TTL", async () => {
    sessionUpdateMany.mockResolvedValueOnce({ count: 3 });
    const count = await expireStaleLocks();
    expect(count).toBe(3);
    const arg = sessionUpdateMany.mock.calls[0][0];
    // 2× TTL window.
    const expectedCutoff = new Date(T0 - HEARTBEAT_TTL_MS * 2);
    expect(arg.where.editorId).toEqual({ not: null });
    // The OR clause includes the cutoff timestamp; pull it out and check
    // the value matches.
    const orClause = arg.where.OR as Array<{ lastHeartbeat?: unknown }>;
    expect(orClause.some((c) => c.lastHeartbeat === null)).toBe(true);
    expect(
      orClause.some(
        (c) =>
          typeof c.lastHeartbeat === "object" &&
          c.lastHeartbeat !== null &&
          (c.lastHeartbeat as { lt: Date }).lt.getTime() === expectedCutoff.getTime(),
      ),
    ).toBe(true);
    expect(arg.data).toEqual({ editorId: null, lastHeartbeat: null });
  });
});

describe("getEditState", () => {
  it("returns the read-only shape and resolves the editor user", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      lastHeartbeat: new Date(T0 - 10_000),
      version: 1,
      draftContent: "wip",
      draftUpdatedAt: new Date(T0 - 10_000),
    });
    userFindUnique.mockResolvedValueOnce({
      id: USER_A,
      name: "Alice",
      email: "alice@example.com",
    });
    const r = await getEditState(RESPONSE_ID);
    expect(r.editorId).toBe(USER_A);
    expect(r.editor?.name).toBe("Alice");
    expect(r.isStale).toBe(false);
    expect(r.version).toBe(1);
  });

  it("flags isStale when lastHeartbeat is older than TTL", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      lastHeartbeat: new Date(T0 - 5 * 60_000),
      version: 1,
      draftContent: null,
      draftUpdatedAt: null,
    });
    userFindUnique.mockResolvedValueOnce({
      id: USER_A,
      name: "Alice",
      email: "alice@example.com",
    });
    const r = await getEditState(RESPONSE_ID);
    expect(r.isStale).toBe(true);
  });
});

describe("commitDraft", () => {
  it("rejects when caller is not the current editor", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_B,
      version: 2,
      lastHeartbeat: new Date(T0),
      draftContent: null,
      draftUpdatedAt: null,
    });
    const r = await commitDraft({
      responseId: RESPONSE_ID,
      userId: USER_A,
      expectedVersion: 2,
    });
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.reason).toBe("not_editor");
    expect(transactionMock).not.toHaveBeenCalled();
  });

  it("commits the draft, bumps version, and releases the lock atomically", async () => {
    sessionFindUnique.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: USER_A,
      version: 2,
      lastHeartbeat: new Date(T0),
      draftContent: "final draft",
      draftUpdatedAt: new Date(T0),
    });
    responseUpdate.mockResolvedValueOnce({
      id: RESPONSE_ID,
      content: "final draft",
    });
    sessionUpdate.mockResolvedValueOnce({
      id: "ses-1",
      responseId: RESPONSE_ID,
      editorId: null,
      version: 3,
      draftContent: null,
      draftUpdatedAt: null,
      lastHeartbeat: null,
    });

    const r = await commitDraft({
      responseId: RESPONSE_ID,
      userId: USER_A,
      expectedVersion: 2,
    });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.version).toBe(3);
    expect(r.content).toBe("final draft");
    expect(transactionMock).toHaveBeenCalledOnce();
  });
});
