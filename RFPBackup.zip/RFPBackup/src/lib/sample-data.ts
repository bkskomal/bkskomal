// Bundled sample RFP + KB content. Lets a fresh org explore the full
// flow (extract → generate → review → export) in seconds without uploading
// anything real. Triggered by the onboarding wizard.

import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { env } from "@/lib/env";
import { prisma } from "@/lib/prisma";
import { embed } from "@/lib/ai/embeddings";
import { vectorStoreResolver } from "@/lib/ai/vector";
import { logActivity } from "@/lib/activity";

const SAMPLE_RFP_TEXT = `# RFP-2026-008 — Cloud Data Platform Modernization

Acme Healthcare invites proposals for the modernization of our enterprise data platform.
Submissions due: 60 days from issuance.

## Section 1 — Company Information

1.1 Provide a brief description of your company and its core offering.
1.2 How many years has your firm been in business?
1.3 List your three largest customer references in healthcare or regulated industries.

## Section 2 — Security & Compliance

2.1 Describe your information security program, including frameworks you adhere to (SOC 2, ISO 27001, HIPAA, HITRUST).
2.2 Detail how customer data is encrypted, both at rest and in transit.
2.3 Explain your access control model (MFA, SSO, RBAC, least-privilege).
2.4 Describe your data residency options. Are EU- and US-only deployment regions available?
2.5 Provide your most recent SOC 2 Type II report or summary.

## Section 3 — Architecture & Reliability

3.1 Describe your platform's high-availability architecture and SLA.
3.2 What is your published uptime over the last 12 months?
3.3 Describe disaster-recovery RTO and RPO objectives.
3.4 How is the system horizontally scalable to support 10x growth in workload?

## Section 4 — Implementation & Support

4.1 What is your typical implementation timeline for an enterprise customer of our size (~5,000 internal users)?
4.2 Describe your professional services and onboarding methodology.
4.3 What support tiers are available, and what are the response-time SLAs for each?
4.4 Describe your customer success engagement model post-implementation.

## Section 5 — Commercials

5.1 Provide pricing for the proposed solution including all licenses, infrastructure, and support.
5.2 Describe any volume discounts or multi-year commitments.
5.3 What is your contract renewal and termination policy?
`;

export const SAMPLE_KB_DOCS: Array<{ name: string; fileName: string; content: string }> = [
  {
    name: "Security & Compliance Overview",
    fileName: "security-overview.md",
    content: `# Acme Cloud Security & Compliance Overview

## Frameworks & certifications
Acme Cloud is SOC 2 Type II certified (annual reports available under NDA), ISO 27001:2013 certified,
HIPAA-compliant for healthcare workloads, and HITRUST CSF certified. Penetration tests are conducted
quarterly by a third-party firm and on a continuous basis through our internal red team.

## Encryption
All customer data is encrypted in transit using TLS 1.3 with modern ciphers (forward secrecy required).
At rest, data is encrypted using AES-256 with envelope encryption — per-tenant data keys protected by
a customer-specific KMS-managed key. Bring-Your-Own-Key (BYOK) is supported on Enterprise tier.

## Access control
Single Sign-On is supported via SAML 2.0 and OIDC (Okta, Azure AD, Google, Ping). MFA is required
for all production access. Role-Based Access Control (RBAC) is enforced with the principle of least
privilege; production access requires JIT elevation and is audited end-to-end.

## Data residency
Acme Cloud operates regions in the United States (us-east, us-west) and the European Union
(eu-west). EU customers can pin all data and processing to EU regions, satisfying GDPR data
residency requirements. Cross-region replication is opt-in and configurable per environment.
`,
  },
  {
    name: "Reliability & Architecture",
    fileName: "reliability.md",
    content: `# Acme Cloud Reliability & Architecture

## SLA & uptime
Acme Cloud's standard SLA is 99.95% uptime measured monthly. Enterprise contracts can opt into
a 99.99% SLA with corresponding service credits. Trailing 12-month measured uptime: 99.987%.

## Architecture
Multi-tenant control plane with single-tenant data planes per region. Each data plane spans 3
availability zones with active-active failover; load balancers and stateless services autoscale
based on observed load. Stateful services (Postgres, Kafka, OpenSearch) are operated in HA mode
with synchronous replication within a region and asynchronous replication across regions for DR.

## Disaster recovery
RTO target: 1 hour. RPO target: 5 minutes for transactional data, 1 hour for analytical data.
DR drills are run quarterly with full region failover.

## Scalability
Horizontal scale is achieved by sharding by tenant_id. The largest production tenant currently
serves 22,000 internal users on a single shard with headroom; new shards can be provisioned in
under 6 hours. We have load-tested the platform to 10x current peak load.
`,
  },
  {
    name: "Company Overview & References",
    fileName: "company.md",
    content: `# About Acme Cloud

Acme Cloud was founded in 2014 and has been in continuous operation for 12 years. We are
headquartered in San Francisco with engineering hubs in Toronto, Berlin, and Bengaluru. As of
2026 we serve 1,200+ enterprise customers globally including 18 of the Fortune 100.

## Healthcare & regulated industry references
- Mercy Health Systems (HIPAA, 30k seats, 4-year customer)
- BlueShield Insurance (SOC 2, HITRUST, 18k seats, 6-year customer)
- Pacific Coast Bank (SOC 2, PCI, 12k seats, 3-year customer)

References available on request once an NDA is executed.
`,
  },
  {
    name: "Implementation & Support",
    fileName: "implementation.md",
    content: `# Implementation, Support, and Customer Success

## Implementation timeline
Typical enterprise implementations follow a 90-day plan: weeks 1-2 design, weeks 3-6 build &
configure, weeks 7-10 user acceptance testing, weeks 11-12 cutover and hypercare. For
deployments at the 5,000-user scale we have completed several go-lives in under 75 days.

## Professional services
Our implementation team includes a dedicated Solutions Architect, a Project Manager, and 2-3
Implementation Engineers. We follow a phased methodology aligned to your project plan.

## Support tiers
- **Standard** (24x5): P1 4-hour response, P2 next business day
- **Enterprise** (24x7): P1 30-minute response, P2 4-hour response
- **Mission-Critical** (24x7 with named TAM): P1 15-minute response, hands-on incident
  commander assigned to every Sev 1.

## Customer success
Every Enterprise customer gets a named Customer Success Manager who runs quarterly business
reviews, monitors adoption, and coordinates renewals. Mission-Critical customers also get a
named Technical Account Manager (TAM) who acts as their advocate inside engineering.
`,
  },
  {
    name: "Privacy & Data Handling",
    fileName: "privacy.md",
    content: `# Privacy & Data Handling

## Data classification
Acme Cloud classifies all customer-provided data as Confidential by default. Production access
is restricted to a defined on-call rotation; access events are logged to an immutable audit
trail and reviewed weekly.

## GDPR & data subject rights
We act as a data processor under GDPR. We support every standard Data Subject Request — access,
rectification, erasure, portability, and restriction — via a self-serve admin console. Average
response time for an erasure request is under 72 hours.

## Data retention
Customer content is retained per customer-configured policy (default: indefinite). On contract
termination, all customer data is purged from production within 30 days and from backups within
90 days. A signed certificate of destruction is provided on request.

## Sub-processors
A complete list of sub-processors (AWS for hosting, Datadog for observability, Twilio for SMS,
Stripe for billing) is published at acmecloud.example.com/legal/subprocessors. Customers are
notified 30 days before any sub-processor addition takes effect.

## Privacy program contacts
Data Protection Officer: dpo@acmecloud.example.com. EU representative under Article 27: see
above page. CCPA: privacy-ca@acmecloud.example.com.
`,
  },
  {
    name: "Pricing & Commercial Terms",
    fileName: "pricing.md",
    content: `# Pricing & Commercial Terms

## Tier structure
Acme Cloud is priced per active seat per month. Three tiers:

- **Standard** — $39 / seat / month. Includes 24x5 support, standard SLA (99.95%), 50 GB of
  document storage per seat.
- **Enterprise** — $79 / seat / month. Adds SSO, SCIM provisioning, custom retention policies,
  99.99% SLA option, named CSM, and audit log export.
- **Mission-Critical** — $129 / seat / month. Adds named TAM, 15-minute P1 response, custom DR
  arrangements, BYOK encryption, dedicated success engineering.

## Volume discounts
- 500–999 seats: 10% discount on listed price
- 1,000–4,999 seats: 18% discount
- 5,000+ seats: contact sales for custom pricing

## Commitment terms
1-year commitment is standard. Multi-year commitments unlock additional discounts: 2 years (5%),
3 years (10%). Mid-term seat additions are pro-rated; reductions take effect at renewal only.

## Renewal & termination
Default renewal is auto-renew at the same terms with 90 days written notice required to opt out.
Termination for convenience requires 60 days notice. Termination for breach: standard 30-day
cure period before either party can terminate.

## What's included vs. add-ons
Storage beyond 50 GB/seat: $0.10 / GB / month. API call overage above 100k/month: $0.001 / call.
Sandbox environments: 1 included, additional sandboxes $5,000 / year. Professional services
billed at $250 / hour, T&M, or fixed-fee SOW.
`,
  },
  {
    name: "Integrations & API",
    fileName: "integrations.md",
    content: `# Integrations & API

## REST API
Acme Cloud exposes a comprehensive REST API at api.acmecloud.example.com/v2. The API uses OAuth
2.0 (PKCE flow for SPAs, client-credentials for server-to-server) and supports per-token
scoping. Rate limits: 1,000 requests/minute per token on Standard, 10,000/min on Enterprise.

## Webhooks
Outbound webhooks are configurable per organization. Event types include: document.created,
document.updated, response.approved, user.added, billing.invoice. Webhook deliveries are signed
with HMAC-SHA256 and retried with exponential backoff (5 retries over 24 hours).

## Identity & SSO
SAML 2.0 (Okta, Azure AD, Google Workspace, Ping, OneLogin) and OIDC are supported. SCIM 2.0
for automated user provisioning + de-provisioning. JIT user provisioning is available where
SAML is configured but SCIM is not.

## Pre-built integrations
- Slack (notifications, slash commands)
- Microsoft Teams (notifications, embedded app)
- Salesforce (deal-to-RFP linkage)
- HubSpot (contact sync)
- Jira (export questions as issues)
- Confluence (publish responses)
- Google Drive / SharePoint (document sync)
- DocuSign (signature workflows)

## Custom integration
SDKs are published for TypeScript, Python, Go, and Ruby. Customers can also build custom
integrations against the public API; we provide a sandbox environment with synthetic data for
integration development.
`,
  },
  {
    name: "Performance & SLA",
    fileName: "performance.md",
    content: `# Performance & SLA

## Measured uptime (trailing 12 months)
- Standard SLA target: 99.95% — achieved 99.987%
- Enterprise SLA target: 99.99% — achieved 99.993%
- Mission-Critical SLA target: 99.99% with sub-15-min P1 response — achieved 99.995%, average
  P1 ack time 4 minutes 30 seconds.

## API latency (P50 / P95 / P99)
- Read operations: 28ms / 95ms / 220ms
- Write operations: 65ms / 180ms / 410ms
- Search (semantic + keyword hybrid): 110ms / 290ms / 540ms

## Throughput
Sustained throughput per region: 50,000 requests / second on the read path, 12,000 requests /
second on the write path. Hot-shard isolation prevents one tenant's burst from impacting others.

## Service credits
Below 99.95% in a month: 10% credit. Below 99.5%: 25% credit. Below 99.0%: 50% credit. Credits
applied automatically to the next invoice; no claim required for SLA-related credits.

## Maintenance windows
Standard maintenance window: Saturday 02:00–06:00 UTC, with 7-day prior notice. Emergency
maintenance is announced as soon as scheduled, with target advance notice of 4 hours. No
maintenance occurs during customer-declared blackout windows (configurable up to 3 per quarter
per organization).
`,
  },
  {
    name: "Disaster Recovery & Business Continuity",
    fileName: "disaster-recovery.md",
    content: `# Disaster Recovery & Business Continuity

## RPO / RTO objectives
- Recovery Point Objective (RPO): 5 minutes for transactional data, 1 hour for analytical
  data. WAL streaming replication keeps the secondary region within seconds in steady state.
- Recovery Time Objective (RTO): 1 hour for full-region failover. Service restoration to a
  read-only state typically completes within 15 minutes.

## DR architecture
Each production region (us-east, us-west, eu-west) is paired with a hot standby in a different
geography. Replication is asynchronous between regions and synchronous across AZs within a
region. The standby is continuously receiving writes; failover is an automated promotion plus
DNS cutover.

## Backups
Database snapshots every 1 hour, retained 35 days. Object storage uses cross-region replication
and versioning; deletions are soft for 30 days, with hard-delete protection on production
buckets.

## DR drills
We run full region-failover drills quarterly. Each drill is documented in an internal runbook
and the post-mortem is shared with customers under NDA. The most recent drill (Q1 2026)
completed full failover in 41 minutes with zero data loss.

## Business continuity
Geographically distributed workforce. No single office is critical for operations. Crisis
management plan is exercised twice annually and reviewed by the executive team.
`,
  },
  {
    name: "AI & Machine Learning",
    fileName: "ai-ml.md",
    content: `# AI & Machine Learning Capabilities

## Model architecture
Acme Cloud's AI features use a hybrid architecture: open-source large language models hosted
on our own GPU infrastructure for sensitive workloads, and selected hosted models (via private
endpoints with no training opt-out) for use cases where customers explicitly opt in.

## Self-hosted models
Production inference runs on Llama-family models served via vLLM and TensorRT-LLM. Models in
active service include Llama 3.3 70B, Qwen 2.5 72B, and Mistral Large. Customers may pin a
specific model per environment for reproducibility.

## Data isolation
Customer data is never used for training. Inference is stateless per request. Caches are
encrypted with per-tenant keys and cleared on tenant deletion. No customer data leaves the
customer's chosen region for any AI workload.

## Customization
Customers can upload reference content (style guides, approved responses, product specs) to
ground model outputs. Retrieval-Augmented Generation (RAG) is the primary customization path;
fine-tuning is available on Enterprise+ for high-volume use cases.

## Responsible AI
We publish a responsible-AI policy covering acceptable use, model evaluation, and bias testing.
Outputs include confidence scores and source citations. Customers can disable AI features
entirely per environment.
`,
  },
  {
    name: "Accessibility & Internationalization",
    fileName: "accessibility.md",
    content: `# Accessibility & Internationalization

## Accessibility standards
Acme Cloud conforms to WCAG 2.1 Level AA across all customer-facing interfaces. Annual
third-party accessibility audits are conducted; the most recent report (Q4 2025) is available
on request under NDA. Issues identified are tracked in a public-facing dashboard with
target-resolution SLAs.

## Assistive technology compatibility
Tested with JAWS, NVDA, VoiceOver (macOS, iOS), TalkBack, and Dragon NaturallySpeaking. All
interactive elements support keyboard-only navigation; focus order matches visual order; all
controls have programmatic names.

## Color & contrast
Both light and dark themes meet WCAG AA contrast ratios (4.5:1 for text, 3:1 for large text
and UI components). Color is never the sole conveyer of information.

## Internationalization
The interface is currently translated into 14 languages: English, Spanish, French, German,
Portuguese (BR), Italian, Dutch, Japanese, Korean, Simplified Chinese, Traditional Chinese,
Polish, Swedish, and Hebrew. Right-to-left layouts supported for Hebrew and Arabic. Time zones,
date formats, and number formats are localized per user preference.

## Translation workflow
We use a continuous-localization model: every UI string change triggers re-translation within
72 hours. Customers can request additional languages for enterprise-tier accounts.
`,
  },
  {
    name: "Audit & Logging",
    fileName: "audit-logging.md",
    content: `# Audit & Logging

## What's logged
Every state-changing action by a user, admin, or API client is recorded in an immutable audit
log: who, what, when, where (IP + user agent), and the before/after state for material changes.
This includes authentication events, permission grants, document uploads, exports, and admin
configuration changes.

## Retention
Audit logs are retained for 7 years by default for Enterprise customers and 1 year on Standard
tier. Mission-Critical customers can configure unlimited retention.

## Export & integration
Logs are streamable in real time via webhook or SIEM-compatible push (Splunk HEC, Sumo Logic,
Datadog, Elastic Common Schema). Customers can also export historical logs in CSV or JSONL
format from the admin console or via the audit API.

## Tamper-evident storage
Audit log entries are hash-chained; any modification breaks the chain and is detected on next
read. The append-only store is replicated to write-once read-many (WORM) storage in a separate
account with no production-network access.

## Common audit scenarios
- Investigate a suspected unauthorized access: filter by user ID, IP range, or session
- Quarterly access reviews: export permission grants by role
- Compliance evidence: pre-built reports for SOC 2 CC6, ISO 27001 A.9, HIPAA §164.312
`,
  },
];

export interface SampleResult {
  rfpId: string;
  indexId: string;
  documentCount: number;
}

export async function loadSampleRfp(input: {
  organizationId: string;
  userId: string;
}): Promise<SampleResult> {
  // Reuse a project named "Sample" if it exists, otherwise create one.
  let project = await prisma.project.findFirst({
    where: { organizationId: input.organizationId, name: "Sample" },
  });

  // Pick a default index for the project — first index in the org, or create one.
  let index = await prisma.knowledgeIndex.findFirst({
    where: { organizationId: input.organizationId },
    orderBy: { createdAt: "asc" },
  });
  if (!index) {
    index = await prisma.knowledgeIndex.create({
      data: {
        organizationId: input.organizationId,
        name: "Sample Knowledge Base",
        description: "Seeded by AutoRFP onboarding.",
      },
    });
  }

  if (!project) {
    project = await prisma.project.create({
      data: {
        organizationId: input.organizationId,
        name: "Sample",
        description: "Seeded sample project — explore the full RFP flow with example data.",
        defaultIndexId: index.id,
      },
    });
  }

  // Save the sample RFP file to disk + create the row.
  const dir = join(env.UPLOAD_DIR, `rfp/${project.id}`);
  await mkdir(dir, { recursive: true });
  const fileName = "sample-rfp-cloud-modernization.md";
  const fullPath = join(dir, `${Date.now()}-${fileName}`);
  await writeFile(fullPath, SAMPLE_RFP_TEXT);

  const rfp = await prisma.rFP.create({
    data: {
      projectId: project.id,
      title: "RFP-2026-008 — Cloud Data Platform Modernization",
      fileName,
      fileSize: Buffer.byteLength(SAMPLE_RFP_TEXT),
      mimeType: "text/markdown",
      storagePath: fullPath,
      status: "READY",
      rawText: SAMPLE_RFP_TEXT,
    },
  });

  // Create question rows directly — skip extraction LLM call so onboarding
  // works even without an API key.
  const sections: Array<{ section: string; pattern: RegExp }> = [
    { section: "Company Information", pattern: /^## Section 1/m },
    { section: "Security & Compliance", pattern: /^## Section 2/m },
    { section: "Architecture & Reliability", pattern: /^## Section 3/m },
    { section: "Implementation & Support", pattern: /^## Section 4/m },
    { section: "Commercials", pattern: /^## Section 5/m },
  ];
  const lines = SAMPLE_RFP_TEXT.split("\n");
  let currentSection = "General";
  let n = 1;
  const seedQuestions: Array<{ number: number; section: string; text: string }> = [];
  for (const line of lines) {
    const sectionMatch = /^## Section \d+ — (.*)$/.exec(line);
    if (sectionMatch) {
      currentSection = sectionMatch[1].trim();
      continue;
    }
    const qMatch = /^(\d+\.\d+)\s+(.*)$/.exec(line);
    if (qMatch) {
      seedQuestions.push({ number: n++, section: currentSection, text: qMatch[2].trim() });
    }
  }
  if (seedQuestions.length > 0) {
    await prisma.question.createMany({
      data: seedQuestions.map((q) => ({
        rfpId: rfp.id,
        number: q.number,
        section: q.section,
        text: q.text,
      })),
    });
  }

  // Seed the KB documents (with embeddings) — only if it's currently empty,
  // to avoid noisy duplicates on repeat onboarding.
  const existingDocs = await prisma.document.count({ where: { indexId: index.id } });
  if (existingDocs === 0) {
    for (const d of SAMPLE_KB_DOCS) {
      const doc = await prisma.document.create({
        data: {
          indexId: index.id,
          name: d.name,
          fileName: d.fileName,
          fileSize: Buffer.byteLength(d.content),
          mimeType: "text/markdown",
          storagePath: `(synthetic)/sample/${d.fileName}`,
          status: "PROCESSING",
        },
      });
      try {
        // One chunk per sample doc — they're short.
        const vec = await embed(d.content, input.organizationId);
        const row = await prisma.documentChunk.create({
          data: { documentId: doc.id, ordinal: 0, content: d.content, embedding: [] },
          select: { id: true },
        });
        const writers = await vectorStoreResolver.writersForOrg(input.organizationId);
        await Promise.all(
          writers.map((w) =>
            w.upsert([
              {
                id: row.id,
                embedding: vec,
                metadata: {
                  documentId: doc.id,
                  indexId: index.id,
                  organizationId: input.organizationId,
                },
              },
            ]),
          ),
        );
        await prisma.document.update({ where: { id: doc.id }, data: { status: "INDEXED" } });
      } catch (e) {
        // Embeddings may fail (no embedding server configured). Mark FAILED
        // so the user sees the status, but keep going.
        await prisma.document.update({
          where: { id: doc.id },
          data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
        });
      }
    }
  }

  void logActivity({
    rfpId: rfp.id,
    actorId: input.userId,
    kind: "RFP_UPLOADED",
    payload: { sample: true, fileName, questionCount: seedQuestions.length },
  });

  const documentCount = await prisma.document.count({ where: { indexId: index.id } });
  return { rfpId: rfp.id, indexId: index.id, documentCount };
}
