import { z } from "zod";

const schema = z.object({
  DATABASE_URL: z.string().url(),
  AUTH_SECRET: z.string().min(16, "AUTH_SECRET must be at least 16 chars"),
  // Optional previous AUTH_SECRET value, used by lib/crypto.ts as a fallback
  // decryption key during zero-downtime key rotation. When set, decrypt() will
  // try the current AUTH_SECRET-derived key first, then fall back to a key
  // derived from KEY_ROTATION_SECRET. encrypt() always uses the current
  // AUTH_SECRET. Procedure: set KEY_ROTATION_SECRET=<old AUTH_SECRET>, deploy,
  // rotate AUTH_SECRET, run scripts/reencrypt-secrets.mjs, unset
  // KEY_ROTATION_SECRET on the next deploy.
  KEY_ROTATION_SECRET: z.string().min(16).optional(),
  AUTH_URL: z.string().url().optional(),
  NEXTAUTH_URL: z.string().url().optional(),
  EMAIL_SERVER_HOST: z.string().default("localhost"),
  EMAIL_SERVER_PORT: z.coerce.number().default(1025),
  EMAIL_SERVER_USER: z.string().optional().default(""),
  EMAIL_SERVER_PASSWORD: z.string().optional().default(""),
  EMAIL_FROM: z.string().default("AutoRFP <no-reply@autorfp.local>"),
  LLM_BASE_URL: z.string().url().default("http://localhost:11434/v1"),
  LLM_API_KEY: z.string().default("ollama"),
  LLM_MODEL: z.string().default("llama3.2"),
  /**
   * Optional fast model for question extraction. When set, the extractor uses
   * this instead of LLM_MODEL. Extraction is structured-JSON and benefits
   * from speed; a 7-8B model or gpt-4o-mini handles it well at 5-10× the
   * throughput of a 70B. Examples that work well:
   *   - meta-llama/llama-3.3-8b-instruct (OpenRouter)
   *   - qwen/qwen-2.5-7b-instruct
   *   - openai/gpt-4o-mini
   *   - anthropic/claude-haiku-4-5
   * Avoid models smaller than ~7B — they often return malformed JSON.
   */
  LLM_EXTRACTION_MODEL: z.string().optional(),
  // Optional headers — OpenRouter recommends sending an HTTP-Referer and X-Title
  // for analytics and rate-limit attribution. Both are no-ops elsewhere.
  LLM_HTTP_REFERER: z.string().optional(),
  LLM_APP_TITLE: z.string().optional(),
  EMBEDDING_BASE_URL: z.string().url().default("http://localhost:11434/v1"),
  EMBEDDING_API_KEY: z.string().default("ollama"),
  EMBEDDING_MODEL: z.string().default("nomic-embed-text"),
  EMBEDDING_DIMENSIONS: z.coerce.number().default(768),
  UPLOAD_DIR: z.string().default("./uploads"),
  // Optional: LlamaParse for premium PDF/Word/PPT extraction (tables, charts).
  // If unset, the local parsers (pdf-parse, mammoth, xlsx, officeparser) are used.
  LLAMA_CLOUD_API_KEY: z.string().optional(),
  LLAMAPARSE_BASE_URL: z.string().url().default("https://api.cloud.llamaindex.ai/api/v1/parsing"),
  LLAMAPARSE_RESULT_TYPE: z.enum(["text", "markdown"]).default("markdown"),
  // --- OAuth (all optional; each provider is enabled only when both ID and SECRET are set) ---
  OAUTH_GOOGLE_ID: z.string().optional(),
  OAUTH_GOOGLE_SECRET: z.string().optional(),
  OAUTH_GITHUB_ID: z.string().optional(),
  OAUTH_GITHUB_SECRET: z.string().optional(),
  OAUTH_MICROSOFT_ID: z.string().optional(),
  OAUTH_MICROSOFT_SECRET: z.string().optional(),
  // Defaults to "common" (multi-tenant) when unset; set to a directory (tenant) ID
  // to restrict sign-in to a single Entra tenant.
  OAUTH_MICROSOFT_TENANT_ID: z.string().optional(),
  // --- Rate-limit backend ---
  // "memory" (default) is the in-process Map — fine for single-instance
  // deployments. "redis" coordinates buckets across replicas via a Lua-scripted
  // token bucket; selected only when REDIS_URL is also set.
  RATE_LIMIT_BACKEND: z.enum(["memory", "redis"]).default("memory"),
  REDIS_URL: z.string().optional(),
  // --- Observability ---
  // If set, /api/metrics requires `Authorization: Bearer ${METRICS_TOKEN}`.
  // If unset, the endpoint is open — typical for in-cluster scrapes gated by
  // network policy. Don't expose /api/metrics on the public internet without
  // setting this.
  METRICS_TOKEN: z.string().optional(),
  // --- Win/loss feedback loop boost weights ---
  // Applied additively to a golden answer's effective rank when the matched
  // historical question is associated with a WON or LOST RFP. Defaults are
  // small (+/- 0.2) so the feedback loop nudges, not overrides, freshness.
  // Set to 0 to disable the boost without removing the lookup.
  OUTCOME_BOOST_WON: z.coerce.number().default(0.2),
  OUTCOME_BOOST_LOST: z.coerce.number().default(-0.2),
  // --- Semantic answer cache ---
  // Master switch for the cache lookup path inside generateResponse. When
  // false, lookupCachedAnswer() short-circuits to null and storeCachedAnswer()
  // becomes a no-op, but the database table itself is unaffected (existing
  // rows persist and can be cleared via the admin route). Defaults to true.
  SEMANTIC_CACHE_ENABLED: z
    .union([z.boolean(), z.enum(["true", "false", "1", "0"])])
    .default(true)
    .transform((v) => (typeof v === "boolean" ? v : v === "true" || v === "1")),
  // --- Stale-source detection (Tier B2) ---
  // Default age (in days) beyond which a knowledge-base document is
  // considered stale and its citations get a warning. Category overrides
  // in lib/sources/staleness.ts can shorten this on a per-document basis
  // (e.g. SOC2 audits decay yearly). ~730 days ≈ 2 years.
  STALE_SOURCE_THRESHOLD_DAYS: z.coerce.number().int().positive().default(730),
});

export type Env = z.infer<typeof schema>;

let cached: Env | null = null;

function loadEnv(): Env {
  if (cached) return cached;
  const result = schema.safeParse(process.env);
  if (!result.success) {
    // Don't crash the build when collecting page data — only crash at request time.
    // We return a permissive proxy so accessing a missing key explicitly throws there.
    if (process.env.NEXT_PHASE === "phase-production-build") {
      cached = schema.parse({
        DATABASE_URL: "postgresql://buildtime:buildtime@localhost:5432/buildtime",
        AUTH_SECRET: "buildtime-placeholder-secret-do-not-use",
        ...Object.fromEntries(
          Object.entries(process.env).filter(([, v]) => v !== undefined),
        ),
      });
      return cached;
    }
    throw new Error(
      `Invalid env: ${result.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ")}`,
    );
  }
  cached = result.data;
  return cached;
}

// Proxy so module-level imports don't trigger validation until a key is read.
export const env: Env = new Proxy({} as Env, {
  get(_t, prop) {
    return loadEnv()[prop as keyof Env];
  },
  has(_t, prop) {
    return prop in loadEnv();
  },
});

/** @internal test helper — drop the memoised parse so a test that mutates
 *  process.env (e.g. to exercise key rotation) sees the new values. */
export function _resetEnvCacheForTests(): void {
  cached = null;
}
