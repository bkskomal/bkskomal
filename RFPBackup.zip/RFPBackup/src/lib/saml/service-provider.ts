// SAML SP / IdP wiring on top of samlify.
//
// samlify gives us:
//   * IdentityProvider() builder — takes IdP entity id, SSO URL, certificate
//   * ServiceProvider() builder — takes our SP entity id and ACS (callback) URL
//   * sp.createLoginRequest(idp, "redirect") — returns { context: url }
//   * sp.parseLoginResponse(idp, "post", { body: { SAMLResponse } }) — validates
//     signature against the IdP cert and yields extracted attributes.
//
// We require a schema validator. We use a permissive validator (always
// resolves true) because (a) we trust the IdP's signing cert end-to-end —
// that's the real security boundary, not XSD validity, and (b) wiring up
// libxmljs2 is heavyweight and platform-dependent. samlify will refuse to
// run without one set, hence the empty-validator stub.

import type { SamlOrgConfig, SamlAttributeMappings } from "./config";

// We dynamically require samlify so a missing install degrades gracefully:
// tests can mock it cleanly, and a Windows-native-build failure still lets
// the rest of the app boot.
//
// In production code paths, callers should treat a thrown `SAML_UNAVAILABLE`
// the same way they treat any other auth failure.

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let _samlify: any | null = null;
let _samlifyInitErr: string | null = null;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function loadSamlify(): any {
  if (_samlify) return _samlify;
  if (_samlifyInitErr) throw new Error(_samlifyInitErr);
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const mod = require("samlify");
    // samlify requires an XSD validator be registered. We register a no-op:
    // signature validation against the IdP cert is the real security check.
    if (typeof mod.setSchemaValidator === "function") {
      mod.setSchemaValidator({
        validate: async () => "skipped",
      });
    }
    _samlify = mod;
    return mod;
  } catch (e) {
    _samlifyInitErr =
      "samlify is not installed: " + (e instanceof Error ? e.message : String(e));
    throw new Error(_samlifyInitErr);
  }
}

/** Internal — for tests, allows injecting a mock samlify module. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function _setSamlifyForTests(mod: any | null): void {
  _samlify = mod;
  _samlifyInitErr = null;
}

function ensurePemCert(raw: string): string {
  const trimmed = raw.trim();
  if (trimmed.includes("-----BEGIN CERTIFICATE-----")) return trimmed;
  // Bare base64 — wrap it. samlify accepts both wrapped and bare, but some
  // downstream xml-crypto paths are happier with wrapped form.
  return `-----BEGIN CERTIFICATE-----\n${trimmed.replace(/\s+/g, "\n")}\n-----END CERTIFICATE-----`;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function buildIdp(config: SamlOrgConfig): any {
  const samlify = loadSamlify();
  return samlify.IdentityProvider({
    entityID: config.idpEntityId,
    singleSignOnService: [
      {
        Binding: "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
        Location: config.idpSsoUrl,
      },
      {
        Binding: "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
        Location: config.idpSsoUrl,
      },
    ],
    signingCert: ensurePemCert(config.idpCertificate),
    isAssertionEncrypted: false,
    wantLogoutRequestSigned: false,
  });
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function buildSp(config: SamlOrgConfig, callbackUrl: string): any {
  const samlify = loadSamlify();
  return samlify.ServiceProvider({
    entityID: config.spEntityId,
    assertionConsumerService: [
      {
        Binding: "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
        Location: callbackUrl,
      },
    ],
    authnRequestsSigned: false,
    wantAssertionsSigned: true,
    wantMessageSigned: false,
  });
}

/**
 * Builds the redirect URL the user-agent should bounce to. Uses the HTTP
 * Redirect binding (signed via URL query params if the SP is configured to
 * sign — currently off in `buildSp` for simplicity).
 */
export function buildLoginRedirect(
  config: SamlOrgConfig,
  callbackUrl: string,
): { url: string } {
  const idp = buildIdp(config);
  const sp = buildSp(config, callbackUrl);
  const { context } = sp.createLoginRequest(idp, "redirect");
  return { url: context as string };
}

/** Returns the SP metadata XML for the IdP admin to upload. */
export function buildSpMetadata(
  config: SamlOrgConfig,
  callbackUrl: string,
): string {
  const sp = buildSp(config, callbackUrl);
  return sp.getMetadata() as string;
}

export interface SamlPrincipal {
  email: string;
  name?: string;
  externalId?: string;
  groups?: string[];
}

/**
 * Parse and validate the SAML POST response, returning the extracted user
 * attributes. Throws on signature mismatch or attribute extraction failure.
 */
export async function consumeSamlResponse(
  config: SamlOrgConfig,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  sp: any,
  samlBody: string,
): Promise<SamlPrincipal> {
  const idp = buildIdp(config);
  const flow = await sp.parseLoginResponse(idp, "post", {
    body: { SAMLResponse: samlBody },
  });
  return extractPrincipal(flow, config.attributeMappings);
}

/** Internal — exported so tests can verify mapping logic in isolation. */
export function extractPrincipal(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  flow: any,
  mappings: SamlAttributeMappings,
): SamlPrincipal {
  // samlify shape: { extract: { attributes: {...}, nameID: "...", ... } }
  const extract = flow?.extract ?? flow ?? {};
  const attrs: Record<string, unknown> = extract.attributes ?? {};
  const nameId: string | undefined =
    typeof extract.nameID === "string"
      ? extract.nameID
      : typeof extract.nameIdentifier === "string"
        ? extract.nameIdentifier
        : undefined;

  function pick(key?: string): string | undefined {
    if (!key) return undefined;
    const v = attrs[key];
    if (typeof v === "string") return v;
    if (Array.isArray(v) && v.length && typeof v[0] === "string") return v[0] as string;
    return undefined;
  }

  function pickArray(key?: string): string[] | undefined {
    if (!key) return undefined;
    const v = attrs[key];
    if (Array.isArray(v)) return v.filter((x) => typeof x === "string") as string[];
    if (typeof v === "string") return [v];
    return undefined;
  }

  const email = (pick(mappings.email) ?? nameId ?? "").trim().toLowerCase();
  if (!email || !email.includes("@")) {
    throw new Error("SAML assertion missing email attribute");
  }
  const name = pick(mappings.name);
  const externalId = pick(mappings.externalId) ?? nameId;
  const groups = pickArray(mappings.groups);
  return { email, name, externalId, groups };
}
