import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("@/lib/prisma", () => ({
  prisma: {
    samlConfig: {
      findUnique: vi.fn(),
    },
    user: {
      findFirst: vi.fn(),
    },
    organization: {
      findUnique: vi.fn(),
    },
  },
}));

import { prisma } from "@/lib/prisma";
import {
  loadSamlConfigForOrg,
  loadSamlConfigByDomain,
  findSamlRouteForEmail,
} from "./config";

type MockedFn = ReturnType<typeof vi.fn>;
const samlFindUnique = prisma.samlConfig.findUnique as unknown as MockedFn;
const userFindFirst = prisma.user.findFirst as unknown as MockedFn;
const orgFindUnique = prisma.organization.findUnique as unknown as MockedFn;

beforeEach(() => {
  samlFindUnique.mockReset();
  userFindFirst.mockReset();
  orgFindUnique.mockReset();
});

describe("loadSamlConfigForOrg", () => {
  it("returns null when no config exists", async () => {
    samlFindUnique.mockResolvedValueOnce(null);
    const result = await loadSamlConfigForOrg("org-1");
    expect(result).toBeNull();
  });

  it("returns null when config is disabled", async () => {
    samlFindUnique.mockResolvedValueOnce({
      organizationId: "org-1",
      idpEntityId: "https://idp",
      idpSsoUrl: "https://idp/sso",
      idpCertificate: "cert-data",
      spEntityId: "sp",
      attributeMappings: null,
      enforced: false,
      enabled: false,
    });
    const result = await loadSamlConfigForOrg("org-1");
    expect(result).toBeNull();
  });

  it("returns shaped config with default attribute mappings when null", async () => {
    samlFindUnique.mockResolvedValueOnce({
      organizationId: "org-1",
      idpEntityId: "https://idp/entity",
      idpSsoUrl: "https://idp/sso",
      idpCertificate: "MIIcert",
      spEntityId: "sp-id",
      attributeMappings: null,
      enforced: true,
      enabled: true,
    });
    const result = await loadSamlConfigForOrg("org-1");
    expect(result).toEqual({
      idpEntityId: "https://idp/entity",
      idpSsoUrl: "https://idp/sso",
      idpCertificate: "MIIcert",
      spEntityId: "sp-id",
      attributeMappings: {
        email: "email",
        name: "name",
        groups: "groups",
        externalId: "externalId",
      },
      enforced: true,
    });
  });

  it("uses provided attribute mappings and merges defaults for missing fields", async () => {
    samlFindUnique.mockResolvedValueOnce({
      organizationId: "org-1",
      idpEntityId: "i",
      idpSsoUrl: "https://idp/sso",
      idpCertificate: "c",
      spEntityId: null,
      attributeMappings: { email: "EmailAddress" },
      enforced: false,
      enabled: true,
    });
    const result = await loadSamlConfigForOrg("org-1");
    expect(result?.attributeMappings.email).toBe("EmailAddress");
    expect(result?.attributeMappings.name).toBe("name");
    // spEntityId defaulted from AUTH_URL / fallback
    expect(result?.spEntityId).toMatch(/\/saml\/sp\/org-1$/);
  });
});

describe("loadSamlConfigByDomain", () => {
  it("returns null for empty domain", async () => {
    const result = await loadSamlConfigByDomain("");
    expect(result).toBeNull();
  });

  it("finds a config via a member email", async () => {
    userFindFirst.mockResolvedValueOnce({
      memberships: [
        {
          organizationId: "org-1",
          organization: {
            id: "org-1",
            samlConfig: {
              idpEntityId: "https://idp",
              idpSsoUrl: "https://idp/sso",
              idpCertificate: "cert",
              spEntityId: "sp",
              attributeMappings: null,
              enforced: false,
              enabled: true,
            },
          },
        },
      ],
    });
    const result = await loadSamlConfigByDomain("example.com");
    expect(result).not.toBeNull();
    expect(result?.orgId).toBe("org-1");
    expect(result?.config.idpEntityId).toBe("https://idp");
  });

  it("skips orgs whose SamlConfig is disabled", async () => {
    userFindFirst.mockResolvedValueOnce({
      memberships: [
        {
          organizationId: "org-1",
          organization: {
            id: "org-1",
            samlConfig: {
              idpEntityId: "x",
              idpSsoUrl: "https://idp/sso",
              idpCertificate: "cert",
              spEntityId: "sp",
              attributeMappings: null,
              enforced: false,
              enabled: false,
            },
          },
        },
      ],
    });
    const result = await loadSamlConfigByDomain("example.com");
    expect(result).toBeNull();
  });
});

describe("findSamlRouteForEmail", () => {
  it("returns the org slug for a SAML-bound email", async () => {
    userFindFirst.mockResolvedValueOnce({
      memberships: [
        {
          organizationId: "org-1",
          organization: {
            id: "org-1",
            samlConfig: {
              idpEntityId: "i",
              idpSsoUrl: "https://idp/sso",
              idpCertificate: "cert",
              spEntityId: null,
              attributeMappings: null,
              enforced: true,
              enabled: true,
            },
          },
        },
      ],
    });
    orgFindUnique.mockResolvedValueOnce({ slug: "acme" });
    const result = await findSamlRouteForEmail("alice@example.com");
    expect(result).toEqual({ orgSlug: "acme", enforced: true });
  });

  it("returns null for a domain with no SAML config", async () => {
    userFindFirst.mockResolvedValueOnce(null);
    const result = await findSamlRouteForEmail("alice@nowhere.com");
    expect(result).toBeNull();
  });
});
