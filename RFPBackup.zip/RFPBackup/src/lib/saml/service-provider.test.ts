import { describe, expect, it, beforeEach, vi } from "vitest";
import type { SamlOrgConfig } from "./config";
import {
  buildIdp,
  buildSp,
  buildLoginRedirect,
  consumeSamlResponse,
  extractPrincipal,
  _setSamlifyForTests,
} from "./service-provider";

const baseConfig: SamlOrgConfig = {
  idpEntityId: "https://idp.example.com",
  idpSsoUrl: "https://idp.example.com/sso",
  idpCertificate:
    "MIIDazCCAlOgAwIBAgIUExampleCertificateDataForTestPurposesOnlyXYZ",
  spEntityId: "https://app.example.com/saml/sp/org-1",
  attributeMappings: {
    email: "email",
    name: "name",
    groups: "groups",
    externalId: "externalId",
  },
  enforced: false,
};

interface FakeIdp {
  __kind: "idp";
  entityID: string;
  signingCert: string;
}

interface FakeSp {
  __kind: "sp";
  entityID: string;
  callbackBinding: string;
  createLoginRequest: ReturnType<typeof vi.fn>;
  parseLoginResponse: ReturnType<typeof vi.fn>;
  getMetadata: ReturnType<typeof vi.fn>;
}

function makeMockSamlify() {
  const idpCalls: Array<Record<string, unknown>> = [];
  const spCalls: Array<Record<string, unknown>> = [];
  const sp: FakeSp = {
    __kind: "sp",
    entityID: "",
    callbackBinding: "",
    createLoginRequest: vi.fn().mockReturnValue({
      context: "https://idp.example.com/sso?SAMLRequest=ENCODED",
    }),
    parseLoginResponse: vi.fn().mockResolvedValue({
      extract: {
        attributes: {
          email: "bob@example.com",
          name: "Bob Example",
          externalId: "bob-123",
          groups: ["eng", "ops"],
        },
        nameID: "bob@example.com",
      },
    }),
    getMetadata: vi
      .fn()
      .mockReturnValue("<EntityDescriptor entityID='sp'/>"),
  };
  const mod = {
    IdentityProvider(props: Record<string, unknown>) {
      idpCalls.push(props);
      const idp: FakeIdp = {
        __kind: "idp",
        entityID: props.entityID as string,
        signingCert: props.signingCert as string,
      };
      return idp;
    },
    ServiceProvider(props: Record<string, unknown>) {
      spCalls.push(props);
      sp.entityID = props.entityID as string;
      return sp;
    },
    setSchemaValidator: vi.fn(),
  };
  return { mod, sp, idpCalls, spCalls };
}

beforeEach(() => {
  _setSamlifyForTests(null);
});

describe("buildIdp", () => {
  it("constructs an IdP with the configured entity ID and certificate", () => {
    const { mod, idpCalls } = makeMockSamlify();
    _setSamlifyForTests(mod);
    const idp = buildIdp(baseConfig) as FakeIdp;
    expect(idp.entityID).toBe("https://idp.example.com");
    // Cert should have been wrapped into PEM form (bare base64 → wrapped).
    expect(idp.signingCert).toContain("BEGIN CERTIFICATE");
    expect(idpCalls).toHaveLength(1);
    // SSO bindings include both Redirect and POST so either flow works.
    const bindings = (idpCalls[0].singleSignOnService as Array<{ Binding: string }>).map(
      (b) => b.Binding,
    );
    expect(bindings).toContain("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect");
    expect(bindings).toContain("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST");
  });

  it("does not double-wrap an already-PEM certificate", () => {
    const { mod } = makeMockSamlify();
    _setSamlifyForTests(mod);
    const pem =
      "-----BEGIN CERTIFICATE-----\nMIIDazCC\n-----END CERTIFICATE-----";
    const idp = buildIdp({ ...baseConfig, idpCertificate: pem }) as FakeIdp;
    expect(idp.signingCert).toBe(pem);
  });
});

describe("buildSp", () => {
  it("constructs an SP pointing at the supplied callback URL", () => {
    const { mod, spCalls } = makeMockSamlify();
    _setSamlifyForTests(mod);
    const sp = buildSp(baseConfig, "https://app.example.com/api/auth/saml/acme/callback");
    expect(sp).toBeDefined();
    expect(spCalls).toHaveLength(1);
    const acs = spCalls[0].assertionConsumerService as Array<{ Location: string }>;
    expect(acs[0].Location).toBe(
      "https://app.example.com/api/auth/saml/acme/callback",
    );
  });
});

describe("buildLoginRedirect", () => {
  it("produces a URL with a SAMLRequest", () => {
    const { mod, sp } = makeMockSamlify();
    _setSamlifyForTests(mod);
    const result = buildLoginRedirect(
      baseConfig,
      "https://app.example.com/api/auth/saml/acme/callback",
    );
    expect(result.url).toContain("SAMLRequest");
    expect(sp.createLoginRequest).toHaveBeenCalledTimes(1);
    expect(sp.createLoginRequest.mock.calls[0][1]).toBe("redirect");
  });
});

describe("consumeSamlResponse", () => {
  it("extracts principal from a valid assertion", async () => {
    const { mod, sp } = makeMockSamlify();
    _setSamlifyForTests(mod);
    const result = await consumeSamlResponse(baseConfig, sp, "FAKE_BASE64_SAML");
    expect(result.email).toBe("bob@example.com");
    expect(result.name).toBe("Bob Example");
    expect(result.externalId).toBe("bob-123");
    expect(result.groups).toEqual(["eng", "ops"]);
    expect(sp.parseLoginResponse).toHaveBeenCalledTimes(1);
  });

  it("propagates samlify validation failures", async () => {
    const { mod, sp } = makeMockSamlify();
    sp.parseLoginResponse.mockRejectedValueOnce(new Error("signature invalid"));
    _setSamlifyForTests(mod);
    await expect(
      consumeSamlResponse(baseConfig, sp, "TAMPERED"),
    ).rejects.toThrow(/signature/i);
  });
});

describe("extractPrincipal", () => {
  it("falls back to nameID when email attribute is missing", () => {
    const flow = {
      extract: {
        attributes: {
          name: "Carol",
        },
        nameID: "carol@example.com",
      },
    };
    const result = extractPrincipal(flow, {
      email: "email",
      name: "name",
      groups: "groups",
      externalId: "externalId",
    });
    expect(result.email).toBe("carol@example.com");
    expect(result.externalId).toBe("carol@example.com");
  });

  it("throws when neither email attribute nor a usable nameID is present", () => {
    const flow = { extract: { attributes: { other: "x" }, nameID: "not-an-email" } };
    expect(() =>
      extractPrincipal(flow, {
        email: "email",
        name: "name",
        groups: "groups",
        externalId: "externalId",
      }),
    ).toThrow(/email/i);
  });

  it("normalises a single-string groups attribute into an array", () => {
    const flow = {
      extract: {
        attributes: { email: "d@e.com", groups: "engineering" },
        nameID: "d@e.com",
      },
    };
    const result = extractPrincipal(flow, {
      email: "email",
      name: "name",
      groups: "groups",
      externalId: "externalId",
    });
    expect(result.groups).toEqual(["engineering"]);
  });
});
