// SAML per-org configuration loaders.
//
// Two reads:
//   * loadSamlConfigForOrg(orgId) — exact lookup, used by routes that already
//     know the org (`/api/auth/saml/[orgSlug]/...`, admin settings).
//   * loadSamlConfigByDomain(emailDomain) — sign-in page routing: the user
//     typed an email, we want to know if their company forces SAML so we can
//     redirect them at the right IdP.
//
// The DB schema (SamlConfig) already exists; this module just shapes the row
// into a typed `SamlOrgConfig` object with default-filled attribute mappings.

import { prisma } from "@/lib/prisma";

export interface SamlAttributeMappings {
  email: string;
  name?: string;
  groups?: string;
  externalId?: string;
}

export interface SamlOrgConfig {
  idpEntityId: string;
  idpSsoUrl: string;
  idpCertificate: string;
  spEntityId: string;
  attributeMappings: SamlAttributeMappings;
  enforced: boolean;
}

const DEFAULT_ATTRIBUTE_MAPPINGS: SamlAttributeMappings = {
  email: "email",
  name: "name",
  groups: "groups",
  externalId: "externalId",
};

function normaliseMappings(
  raw: unknown,
): SamlAttributeMappings {
  if (!raw || typeof raw !== "object") return { ...DEFAULT_ATTRIBUTE_MAPPINGS };
  const m = raw as Record<string, unknown>;
  return {
    email: typeof m.email === "string" && m.email ? m.email : DEFAULT_ATTRIBUTE_MAPPINGS.email,
    name: typeof m.name === "string" ? m.name : DEFAULT_ATTRIBUTE_MAPPINGS.name,
    groups: typeof m.groups === "string" ? m.groups : DEFAULT_ATTRIBUTE_MAPPINGS.groups,
    externalId:
      typeof m.externalId === "string" ? m.externalId : DEFAULT_ATTRIBUTE_MAPPINGS.externalId,
  };
}

function defaultSpEntityId(orgId: string): string {
  const base = process.env.AUTH_URL || process.env.NEXTAUTH_URL || "https://app.example.com";
  return `${base.replace(/\/$/, "")}/saml/sp/${orgId}`;
}

export async function loadSamlConfigForOrg(orgId: string): Promise<SamlOrgConfig | null> {
  const row = await prisma.samlConfig.findUnique({ where: { organizationId: orgId } });
  if (!row) return null;
  if (!row.enabled) return null;
  return {
    idpEntityId: row.idpEntityId,
    idpSsoUrl: row.idpSsoUrl,
    idpCertificate: row.idpCertificate,
    spEntityId: row.spEntityId ?? defaultSpEntityId(orgId),
    attributeMappings: normaliseMappings(row.attributeMappings),
    enforced: row.enforced,
  };
}

/**
 * Find a SAML config by the email's domain. Strategy: pick any user whose
 * email ends with that domain, follow to their org. If multiple orgs match,
 * we return the first; for enterprise SSO scenarios this is the common case
 * (one corporate domain == one org) and ambiguity is callers' problem.
 */
export async function loadSamlConfigByDomain(
  emailDomain: string,
): Promise<{ orgId: string; config: SamlOrgConfig } | null> {
  const domain = emailDomain.trim().toLowerCase().replace(/^@/, "");
  if (!domain) return null;

  // Find a user whose email matches the domain and join via memberships to
  // any org that has a SamlConfig. We don't want to leak across orgs, so
  // require an actual SAML row.
  const candidate = await prisma.user.findFirst({
    where: { email: { endsWith: `@${domain}` } },
    select: {
      memberships: {
        select: {
          organizationId: true,
          organization: {
            select: {
              id: true,
              samlConfig: true,
            },
          },
        },
      },
    },
  });

  if (!candidate) return null;
  for (const m of candidate.memberships) {
    const cfg = m.organization?.samlConfig;
    if (cfg && cfg.enabled) {
      return {
        orgId: m.organizationId,
        config: {
          idpEntityId: cfg.idpEntityId,
          idpSsoUrl: cfg.idpSsoUrl,
          idpCertificate: cfg.idpCertificate,
          spEntityId: cfg.spEntityId ?? defaultSpEntityId(m.organizationId),
          attributeMappings: normaliseMappings(cfg.attributeMappings),
          enforced: cfg.enforced,
        },
      };
    }
  }
  return null;
}

/**
 * Convenience helper: given an email, return the org slug to bounce the
 * sign-in page at. Returns null when no SAML config matches.
 */
export async function findSamlRouteForEmail(
  email: string,
): Promise<{ orgSlug: string; enforced: boolean } | null> {
  const at = email.indexOf("@");
  if (at < 0) return null;
  const domain = email.slice(at + 1);
  const hit = await loadSamlConfigByDomain(domain);
  if (!hit) return null;
  const org = await prisma.organization.findUnique({
    where: { id: hit.orgId },
    select: { slug: true },
  });
  if (!org) return null;
  return { orgSlug: org.slug, enforced: hit.config.enforced };
}
