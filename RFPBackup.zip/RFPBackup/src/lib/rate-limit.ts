// Pluggable token-bucket rate limiter.
//
// The legacy implementation was a single in-process Map. That's fine for a
// single-instance deployment, but it doesn't coordinate across replicas — N
// pods get N times the budget. This module now picks one of two backends at
// runtime:
//
//   - MemoryBackend: original behavior, used for tests and single-instance.
//   - RedisBackend:  one Lua script per consume, atomically reads (tokens,
//                    lastRefill), refills, and decrements in a single round-
//                    trip. Selected when RATE_LIMIT_BACKEND=redis + REDIS_URL.
//
// The public surface — RATE_LIMITS and rateLimit() — is unchanged, so callers
// don't need to know which backend is active.
//
// Each rule defines a capacity (the burst) and a refill rate per minute (the
// steady-state allowance). Buckets refill naturally as time passes — we
// compute the elapsed minutes since the last update on each call and add that
// many tokens (clamped to capacity).
//
// Scope is either "user" (per-user) or "org" (per-organization). The bucket
// key is `${scope}:${id}:${route}` so two routes with the same rule and the
// same scope don't share a bucket.
//
// On exhaustion we throw RateLimitError; the api-handler maps that to a 429
// with a Retry-After header.

import { AppError } from "@/lib/errors";
import { log } from "@/lib/logger";
import { rateLimitHitsTotal } from "@/lib/metrics";

export class RateLimitError extends AppError {
  status = 429;
  code = "rate_limited";
  exposeMessage = true;
  retryAfterSeconds: number;
  constructor(message: string, retryAfterSeconds: number) {
    super(message);
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

export type RateLimitScope = "user" | "org";

export interface RateLimitRule {
  capacity: number;
  refillPerMinute: number;
  scope: RateLimitScope;
}

export const RATE_LIMITS = {
  // Tighter on expensive operations, looser on cheap meta queries.
  generate: { capacity: 30, refillPerMinute: 30, scope: "org" } as RateLimitRule,
  bulkStart: { capacity: 5, refillPerMinute: 2, scope: "org" } as RateLimitRule,
  chat: { capacity: 60, refillPerMinute: 60, scope: "user" } as RateLimitRule,
  providerTest: { capacity: 10, refillPerMinute: 10, scope: "user" } as RateLimitRule,
  // External ingest endpoint (Phase V): bursty NiFi / Airflow / n8n flows
  // can push 100 docs/chunks per minute per org before getting back-pressure.
  externalIngest: { capacity: 100, refillPerMinute: 100, scope: "org" } as RateLimitRule,
};

// --- Backend interface ------------------------------------------------------

export interface RateLimitDecision {
  /** True if a token was successfully consumed. */
  allowed: boolean;
  /** Seconds the caller should wait before retrying when allowed=false. */
  retryAfterSeconds: number;
  /** Approximate remaining tokens after this call (informational only). */
  remaining: number;
}

export interface RateLimitBackend {
  consume(key: string, rule: RateLimitRule): Promise<RateLimitDecision>;
  /** Called by tests / on backend swap to drop in-process state. */
  reset?(): void | Promise<void>;
  /** Human-readable name for logs. */
  readonly name: string;
}

// --- Memory backend ---------------------------------------------------------

interface Bucket {
  tokens: number;
  updated: number;
}

/** Internal clock indirection so tests can mock time. */
let nowFn: () => number = () => Date.now();

/** @internal — for tests only. */
export function _setNowForTests(fn: () => number): void {
  nowFn = fn;
}

export class MemoryBackend implements RateLimitBackend {
  readonly name = "memory";
  private buckets: Map<string, Bucket> = new Map();

  async consume(key: string, rule: RateLimitRule): Promise<RateLimitDecision> {
    const now = nowFn();
    const existing = this.buckets.get(key);

    let tokens: number;
    if (!existing) {
      tokens = rule.capacity;
    } else {
      const elapsedMinutes = (now - existing.updated) / 60_000;
      const refill = elapsedMinutes * rule.refillPerMinute;
      tokens = Math.min(rule.capacity, existing.tokens + refill);
    }

    tokens -= 1;
    if (tokens < 0) {
      // Restore — don't actually consume on a rejection. We persist the bucket
      // with its pre-decrement token count so the refill clock continues from
      // here.
      const restoredTokens = tokens + 1;
      this.buckets.set(key, { tokens: restoredTokens, updated: now });
      const retryAfterSeconds = Math.ceil(60 / rule.refillPerMinute);
      return { allowed: false, retryAfterSeconds, remaining: 0 };
    }

    this.buckets.set(key, { tokens, updated: now });
    return { allowed: true, retryAfterSeconds: 0, remaining: Math.floor(tokens) };
  }

  reset(): void {
    this.buckets.clear();
  }

  /** @internal — for the periodic idle-bucket sweeper. */
  _sweep(idleMs: number): void {
    const now = nowFn();
    for (const [k, b] of this.buckets) {
      if (now - b.updated > idleMs) this.buckets.delete(k);
    }
  }
}

// --- Redis backend ----------------------------------------------------------

// Atomic token-bucket. Args: key, capacity, refillPerSec, nowMs, ttlMs.
// Reads (tokens, lastUpdateMs) from a hash, refills by elapsed*rate, clamps to
// capacity, decrements by one. If tokens fell below zero, restores +1 (so the
// rejection doesn't drain a fractional token we never gave out) and signals
// the caller via the first return value. Total: one round-trip.
const REDIS_LUA = `
local key      = KEYS[1]
local capacity = tonumber(ARGV[1])
local refill   = tonumber(ARGV[2])   -- tokens per ms
local now      = tonumber(ARGV[3])
local ttl      = tonumber(ARGV[4])

local data    = redis.call('HMGET', key, 'tokens', 'updated')
local tokens  = tonumber(data[1])
local updated = tonumber(data[2])

if tokens == nil then
  tokens  = capacity
  updated = now
else
  local elapsed = math.max(0, now - updated)
  tokens = math.min(capacity, tokens + elapsed * refill)
  updated = now
end

tokens = tokens - 1
local allowed
if tokens < 0 then
  tokens  = tokens + 1
  allowed = 0
else
  allowed = 1
end

redis.call('HMSET', key, 'tokens', tokens, 'updated', updated)
redis.call('PEXPIRE', key, ttl)

local remaining = math.floor(tokens)
if remaining < 0 then remaining = 0 end
return { allowed, remaining }
`;

interface MinimalRedis {
  eval(
    script: string,
    numKeys: number,
    ...args: (string | number)[]
  ): Promise<unknown>;
  ping(): Promise<string>;
  quit?(): Promise<unknown>;
  disconnect?(): void;
}

export class RedisBackend implements RateLimitBackend {
  readonly name = "redis";
  constructor(private readonly client: MinimalRedis) {}

  async consume(key: string, rule: RateLimitRule): Promise<RateLimitDecision> {
    const tokensPerMs = rule.refillPerMinute / 60_000;
    const refillWindowMs = rule.capacity / tokensPerMs;
    // TTL: evict idle buckets after at least an hour, or 2× the time it takes
    // a fully-drained bucket to refill — whichever is longer. Ensures buckets
    // never appear "full" to a stale caller due to TTL expiry mid-window.
    const ttlMs = Math.max(60 * 60 * 1000, Math.ceil(refillWindowMs * 2));
    const now = nowFn();

    const result = (await this.client.eval(
      REDIS_LUA,
      1,
      `rl:${key}`,
      rule.capacity,
      tokensPerMs,
      now,
      ttlMs,
    )) as [number, number];

    const allowed = result[0] === 1;
    const remaining = Number(result[1] ?? 0);
    if (!allowed) {
      return {
        allowed: false,
        retryAfterSeconds: Math.ceil(60 / rule.refillPerMinute),
        remaining: 0,
      };
    }
    return { allowed: true, retryAfterSeconds: 0, remaining };
  }
}

// --- Backend selection ------------------------------------------------------

let backend: RateLimitBackend | null = null;
let backendInitPromise: Promise<RateLimitBackend> | null = null;

function getBackend(): RateLimitBackend {
  if (backend) return backend;
  // Sync path. Memory is the only synchronously-buildable backend; if the
  // caller wanted Redis, they should have called initBackend() during startup
  // (instrumentation does this). Until that resolves, fall through to memory.
  if (!backendInitPromise) {
    backendInitPromise = buildDefaultBackend().then((b) => {
      backend = b;
      return b;
    });
  }
  // Synchronous fallback so the very first request doesn't block on Redis
  // discovery — instrumentation has already kicked off the real init by the
  // time any request lands.
  if (!backend) backend = new MemoryBackend();
  return backend;
}

async function buildDefaultBackend(): Promise<RateLimitBackend> {
  // Avoid pulling ioredis when callers haven't asked for it.
  const backendName = process.env.RATE_LIMIT_BACKEND ?? "memory";
  const redisUrl = process.env.REDIS_URL;
  if (backendName === "redis" && redisUrl) {
    try {
      // webpackIgnore so this dynamic import is left as a runtime require —
      // ioredis pulls Node "stream"/"net"/"tls" which webpack can't polyfill.
      const ioredisMod = await import(/* webpackIgnore: true */ "ioredis");
      const Client =
        (ioredisMod as unknown as { default?: typeof ioredisMod.Redis }).default ??
        ioredisMod.Redis;
      const client = new Client(redisUrl, {
        maxRetriesPerRequest: 2,
        lazyConnect: false,
      });
      client.on("error", (err: Error) => {
        log().warn({ err: err.message }, "redis rate-limit backend error");
      });
      return new RedisBackend(client as unknown as MinimalRedis);
    } catch (err) {
      log().error(
        { err: err instanceof Error ? err.message : String(err) },
        "failed to initialize redis rate-limit backend — falling back to memory",
      );
      return new MemoryBackend();
    }
  }
  return new MemoryBackend();
}

/**
 * Eagerly construct the configured backend. Call from instrumentation /
 * server startup so the first request doesn't fall back to memory while Redis
 * is still warming up. Idempotent.
 */
export async function initBackend(): Promise<RateLimitBackend> {
  if (backend && backend.name !== "memory") return backend;
  const b = await buildDefaultBackend();
  backend = b;
  backendInitPromise = Promise.resolve(b);
  return b;
}

/** @internal — for tests only. Replaces the backend (memory by default). */
export function _setBackendForTests(b: RateLimitBackend | null): void {
  backend = b;
}

/** @internal — for tests only. */
export function _resetForTests(): void {
  if (backend && typeof backend.reset === "function") {
    void backend.reset();
  }
  backend = new MemoryBackend();
  nowFn = () => Date.now();
}

/** Returns the active backend's name. For startup logging / debugging. */
export function getBackendName(): string {
  return getBackend().name;
}

function bucketKey(rule: RateLimitRule, key: { userId: string; orgId?: string; route: string }): string {
  const id = rule.scope === "org" ? key.orgId ?? key.userId : key.userId;
  return `${rule.scope}:${id}:${key.route}`;
}

/**
 * Consume one token from the bucket identified by (rule, key). Throws
 * RateLimitError if the bucket is empty.
 */
export async function rateLimit(
  rule: RateLimitRule,
  key: { userId: string; orgId?: string; route: string },
): Promise<void> {
  const k = bucketKey(rule, key);
  const decision = await getBackend().consume(k, rule);

  if (!decision.allowed) {
    log().warn(
      {
        scope: rule.scope,
        route: key.route,
        userId: key.userId,
        orgId: key.orgId,
        retryAfterSeconds: decision.retryAfterSeconds,
      },
      "rate limited",
    );
    rateLimitHitsTotal.inc({ route: key.route, scope: rule.scope });
    throw new RateLimitError(
      `Rate limit exceeded. Retry after ${decision.retryAfterSeconds}s.`,
      decision.retryAfterSeconds,
    );
  }

  log().debug(
    {
      scope: rule.scope,
      route: key.route,
      userId: key.userId,
      orgId: key.orgId,
      remaining: decision.remaining,
    },
    "rate limit consumed",
  );
}

// --- Memory-backend idle sweep ----------------------------------------------
//
// Periodically purge in-memory buckets that haven't been touched in over an
// hour so we don't leak memory in a long-running server. Guarded so it doesn't
// fire during the Next.js build (where setInterval keeps the process alive)
// nor under tests. Redis buckets self-evict via PEXPIRE.
const IDLE_TTL_MS = 60 * 60 * 1000;
const CLEANUP_INTERVAL_MS = 10 * 60 * 1000;

if (typeof setInterval !== "undefined" && process.env.NODE_ENV !== "test") {
  const handle = setInterval(() => {
    const b = getBackend();
    if (b instanceof MemoryBackend) b._sweep(IDLE_TTL_MS);

    // Piggy-back the response-edit stale-lock sweeper on the same tick. Done
    // here rather than in instrumentation.ts because:
    //   1. We already guard against build / test environments with the same
    //      conditions above — duplicating that logic in a second module would
    //      double the risk of dangling intervals.
    //   2. The work is bounded and fast (one updateMany against a small table)
    //      so co-locating it with the in-memory bucket sweep avoids spawning
    //      a second long-lived timer for what's essentially the same kind of
    //      housekeeping.
    // Loaded dynamically to break a require cycle (response-edit imports
    // metrics, which is loaded before rate-limit in the dependency graph).
    void (async () => {
      try {
        const { expireStaleLocks } = await import("@/lib/response-edit/session");
        const count = await expireStaleLocks();
        if (count > 0) {
          log().info({ count }, "expired stale response-edit locks");
        }
      } catch (err) {
        log().warn(
          { err: err instanceof Error ? err.message : String(err) },
          "stale-lock sweep failed",
        );
      }
    })();
  }, CLEANUP_INTERVAL_MS);
  if (typeof handle.unref === "function") handle.unref();
}
