import { describe, expect, it } from "vitest";
import {
  AppError,
  ValidationError,
  AuthError,
  ForbiddenError,
  NotFoundError,
  LlmError,
  EmbeddingError,
} from "./errors";

describe("typed errors", () => {
  it("ValidationError → 400 + exposes message", () => {
    const e = new ValidationError("bad payload", { field: "email" });
    expect(e.status).toBe(400);
    expect(e.exposeMessage).toBe(true);
    expect(e.details).toEqual({ field: "email" });
  });

  it("AuthError → 401", () => {
    expect(new AuthError("nope").status).toBe(401);
  });

  it("ForbiddenError → 403", () => {
    expect(new ForbiddenError("nope").status).toBe(403);
  });

  it("NotFoundError → 404", () => {
    expect(new NotFoundError("nope").status).toBe(404);
  });

  it("LlmError wraps service name", () => {
    const e = new LlmError("rate limited");
    expect(e.status).toBe(502);
    expect(e.service).toBe("llm");
    expect(e.message).toContain("llm:");
  });

  it("EmbeddingError uses its own code", () => {
    expect(new EmbeddingError("fail").code).toBe("embedding_error");
  });

  it("AppError default status is 500", () => {
    expect(new AppError("x").status).toBe(500);
  });
});
