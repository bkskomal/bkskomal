// LoRA adapter resolver (Tier C3 — LoRA adapter support).
//
// Reads `OrgAiConfig.loraAdapterUrl` + `loraAdapterMeta` and surfaces them
// as a typed `AdapterSpec`. There is no validation of the URL beyond "is it
// non-empty" — we explicitly trust whatever the user's inference server can
// resolve. `loraAdapterUrl` may carry any of:
//
//   • OpenAI fine-tune id    e.g. "ft:gpt-4o-mini:my-org::abc123"
//   • vLLM adapter id        e.g. "my-org/sales-rfp-lora"
//   • Together / OpenRouter  any provider-recognised model string
//   • Local file path        e.g. "file:///opt/loras/sales.safetensors"
//   • HTTP URL               for backends that download adapters
//
// Whatever the value, it is treated as the *model identifier* in the
// chat-completions request — AutoRFP does no fetching, attaching, or
// inspection. Misconfiguration surfaces as an inference-time 4xx/5xx,
// which the user sees in the "Test this adapter" UI.

import { prisma } from "@/lib/prisma";

export type AdapterProvider =
  | "openai_ft"
  | "vllm"
  | "openrouter"
  | "ollama"
  | "together"
  | "other";

export interface AdapterMeta {
  baseModel: string;
  rank?: number;
  trainedAt?: string;
  trainSize?: number;
  provider?: AdapterProvider;
  notes?: string;
}

export interface AdapterSpec extends AdapterMeta {
  /**
   * Canonical model id / adapter URL — passed verbatim to the LLM client
   * as the `model` parameter. Required (non-empty) for the adapter to be
   * considered "configured".
   */
  url: string;
}

/**
 * Resolve the adapter spec for an org. Returns `null` when no adapter is
 * configured (the common case), letting callers short-circuit. We don't
 * throw on a missing `baseModel` field — older configs may pre-date the
 * meta UI; we fall back to "unknown" so the spec is still usable.
 */
export async function resolveAdapter(orgId: string): Promise<AdapterSpec | null> {
  const row = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: { loraAdapterUrl: true, loraAdapterMeta: true },
  });

  if (!row?.loraAdapterUrl?.trim()) return null;

  const meta = parseMeta(row.loraAdapterMeta);
  return {
    url: row.loraAdapterUrl,
    baseModel: meta.baseModel ?? "unknown",
    rank: meta.rank,
    trainedAt: meta.trainedAt,
    trainSize: meta.trainSize,
    provider: meta.provider,
    notes: meta.notes,
  };
}

/**
 * Return the model identifier to pass to chat.completions.create — for now
 * this is simply the URL field, but the indirection lets us evolve the
 * mapping later (e.g. prepend "lora:" for some provider) without touching
 * every caller.
 */
export function adapterToModelName(spec: AdapterSpec): string {
  return spec.url;
}

/**
 * Coerce the JSON blob into a partial AdapterMeta. We accept missing /
 * malformed fields silently: the meta JSON is informational ("how was this
 * adapter trained?"), and we don't want a stray bad write to bork
 * generation. Unknown keys are dropped.
 */
function parseMeta(value: unknown): Partial<AdapterMeta> {
  if (!value || typeof value !== "object") return {};
  const obj = value as Record<string, unknown>;
  const out: Partial<AdapterMeta> = {};
  if (typeof obj.baseModel === "string") out.baseModel = obj.baseModel;
  if (typeof obj.rank === "number" && Number.isFinite(obj.rank)) out.rank = obj.rank;
  if (typeof obj.trainedAt === "string") out.trainedAt = obj.trainedAt;
  if (typeof obj.trainSize === "number" && Number.isFinite(obj.trainSize)) {
    out.trainSize = obj.trainSize;
  }
  if (typeof obj.provider === "string" && isProvider(obj.provider)) {
    out.provider = obj.provider;
  }
  if (typeof obj.notes === "string") out.notes = obj.notes;
  return out;
}

function isProvider(v: string): v is AdapterProvider {
  return (
    v === "openai_ft" ||
    v === "vllm" ||
    v === "openrouter" ||
    v === "ollama" ||
    v === "together" ||
    v === "other"
  );
}
