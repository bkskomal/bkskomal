// Golden-answer training-data exporter (Tier C3 — LoRA adapter support).
//
// AutoRFP does NOT host a training pipeline. This module exists to package
// up the corpus an org has accumulated (golden answers + approved
// responses) into an OpenAI-fine-tune-compatible JSONL the user can then
// upload to whichever external training provider they like (OpenAI Fine-
// tuning, Together.ai, Hugging Face AutoTrain, a custom vLLM stack…).
//
// Output shape — one JSON object per line, following the OpenAI chat-format
// fine-tune spec:
//   { "messages": [
//       { "role": "system",    "content": "..." },
//       { "role": "user",      "content": "<question>" },
//       { "role": "assistant", "content": "<answer>" }
//     ] }
//
// System prompt is a *condensed* version of RESPONSE_GENERATION_SYSTEM
// (under 200 chars). The full primer is fine for inference-time prompting,
// but for fine-tuning we want a short, stable preamble so the model learns
// the role rather than memorizing the prompt.

import { prisma } from "@/lib/prisma";
import { QuestionStatus } from "@prisma/client";

/**
 * Shape of one OpenAI-format training example. Tuple type intentional: each
 * example is exactly three messages (system → user → assistant) — fewer
 * confuses the fine-tune validator, more wastes tokens.
 */
export interface TrainingExample {
  messages: [
    { role: "system"; content: string },
    { role: "user"; content: string },
    { role: "assistant"; content: string },
  ];
}

/**
 * Condensed system prompt used for fine-tune training examples. The full
 * `RESPONSE_GENERATION_SYSTEM` is ~1.5KB; we keep this under 200 chars so it
 * doesn't dominate the per-example token cost. The model is being fine-
 * tuned to *be* this role, not to be reminded of it on every call.
 */
export const TRAINING_SYSTEM_PROMPT =
  "You are an expert proposal writer. Answer the RFP question directly, specifically, and with confidence. Cite sources inline when given. Do not hedge.";

/** Result of an export. `warning` is non-null when the corpus is too small. */
export interface ExportResult {
  jsonl: string;
  exampleCount: number;
  warning: string | null;
}

/**
 * The minimum number of training examples OpenAI's fine-tune API recommends
 * for usable results. Below this we still emit the file (the user may want
 * to combine corpora externally) but warn so they know what they're doing.
 */
export const RECOMMENDED_MIN_EXAMPLES = 50;

/**
 * Export every GoldenAnswer for the org as JSONL training data. Returns
 * the raw text body (caller streams it as the HTTP response).
 *
 * Order is stable (oldest-first by `createdAt`) so re-running the export
 * produces a diffable file — useful when users iterate on their golden set.
 */
export async function exportGoldenAnswersJsonl(orgId: string): Promise<ExportResult> {
  const rows = await prisma.goldenAnswer.findMany({
    where: { organizationId: orgId },
    orderBy: { createdAt: "asc" },
    select: { question: true, answer: true },
  });

  const lines: string[] = [];
  for (const row of rows) {
    const example: TrainingExample = {
      messages: [
        { role: "system", content: TRAINING_SYSTEM_PROMPT },
        { role: "user", content: row.question },
        { role: "assistant", content: row.answer },
      ],
    };
    // JSON.stringify is deterministic for plain objects + string values, so
    // the output is stable for tests. No trailing whitespace.
    lines.push(JSON.stringify(example));
  }

  const jsonl = lines.length ? lines.join("\n") + "\n" : "";
  const warning =
    lines.length === 0
      ? "No golden answers found for this organization. Nothing to export."
      : lines.length < RECOMMENDED_MIN_EXAMPLES
        ? `Only ${lines.length} golden answer(s) — most providers recommend at least ${RECOMMENDED_MIN_EXAMPLES} examples for a usable fine-tune.`
        : null;

  return { jsonl, exampleCount: lines.length, warning };
}

/**
 * Export every Response whose parent Question.status = APPROVED as JSONL.
 * The assistant content is the response body (citations included — the
 * fine-tuned model will learn to reproduce the citation style). Sorted by
 * response creation date for stability.
 */
export async function exportApprovedResponsesJsonl(orgId: string): Promise<ExportResult> {
  const rows = await prisma.response.findMany({
    where: {
      question: {
        status: QuestionStatus.APPROVED,
        rfp: { project: { organizationId: orgId } },
      },
    },
    orderBy: { createdAt: "asc" },
    select: {
      content: true,
      question: { select: { text: true } },
    },
  });

  const lines: string[] = [];
  for (const row of rows) {
    // Skip rows with empty content — fine-tune validators reject blank
    // assistant turns. Cheap defence; in practice the schema should never
    // hold an empty Response.content for an APPROVED question.
    if (!row.content?.trim()) continue;
    const example: TrainingExample = {
      messages: [
        { role: "system", content: TRAINING_SYSTEM_PROMPT },
        { role: "user", content: row.question.text },
        { role: "assistant", content: row.content },
      ],
    };
    lines.push(JSON.stringify(example));
  }

  const jsonl = lines.length ? lines.join("\n") + "\n" : "";
  const warning =
    lines.length === 0
      ? "No approved responses found for this organization. Nothing to export."
      : lines.length < RECOMMENDED_MIN_EXAMPLES
        ? `Only ${lines.length} approved response(s) — most providers recommend at least ${RECOMMENDED_MIN_EXAMPLES} examples for a usable fine-tune.`
        : null;

  return { jsonl, exampleCount: lines.length, warning };
}
