import { describe, it, expect, beforeEach, vi } from "vitest";

const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    goldenAnswer: {
      findMany: vi.fn(),
    },
    response: {
      findMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

import {
  exportGoldenAnswersJsonl,
  exportApprovedResponsesJsonl,
  RECOMMENDED_MIN_EXAMPLES,
  TRAINING_SYSTEM_PROMPT,
} from "./export";

beforeEach(() => {
  vi.clearAllMocks();
});

describe("exportGoldenAnswersJsonl", () => {
  it("returns empty body + warning when the org has no goldens", async () => {
    prismaMock.goldenAnswer.findMany.mockResolvedValue([]);
    const result = await exportGoldenAnswersJsonl("org-1");
    expect(result.jsonl).toBe("");
    expect(result.exampleCount).toBe(0);
    expect(result.warning).toMatch(/No golden answers/);
  });

  it("emits one valid JSONL line per golden with system/user/assistant messages", async () => {
    prismaMock.goldenAnswer.findMany.mockResolvedValue([
      { question: "Do you support SSO?", answer: "Yes — SAML 2.0 and OIDC." },
      { question: "What is your RTO?", answer: "Recovery time objective is 4 hours." },
      { question: "Where is data stored?", answer: "AWS us-east-1, encrypted at rest." },
    ]);

    const result = await exportGoldenAnswersJsonl("org-1");
    const lines = result.jsonl.trimEnd().split("\n");

    expect(lines).toHaveLength(3);
    expect(result.exampleCount).toBe(3);

    for (const line of lines) {
      const parsed = JSON.parse(line);
      expect(parsed.messages).toHaveLength(3);
      expect(parsed.messages[0].role).toBe("system");
      expect(parsed.messages[0].content).toBe(TRAINING_SYSTEM_PROMPT);
      expect(parsed.messages[1].role).toBe("user");
      expect(parsed.messages[2].role).toBe("assistant");
    }
    // Warning fires because we're below the recommended minimum.
    expect(result.warning).toMatch(/3 golden answer/);
    expect(result.warning).toContain(String(RECOMMENDED_MIN_EXAMPLES));
  });

  it("no warning when the corpus meets the recommended size", async () => {
    const big = Array.from({ length: RECOMMENDED_MIN_EXAMPLES }, (_, i) => ({
      question: `Q${i}`,
      answer: `A${i}`,
    }));
    prismaMock.goldenAnswer.findMany.mockResolvedValue(big);
    const result = await exportGoldenAnswersJsonl("org-1");
    expect(result.warning).toBeNull();
    expect(result.exampleCount).toBe(RECOMMENDED_MIN_EXAMPLES);
  });

  it("uses a short system prompt under 200 characters", () => {
    // Guard so the condensed prompt doesn't drift back toward the full one.
    expect(TRAINING_SYSTEM_PROMPT.length).toBeLessThan(200);
  });
});

describe("exportApprovedResponsesJsonl", () => {
  it("includes only responses whose question is APPROVED (Prisma where-clause)", async () => {
    prismaMock.response.findMany.mockResolvedValue([
      { content: "Yes, certified SOC2.", question: { text: "Are you SOC2 certified?" } },
    ]);

    const result = await exportApprovedResponsesJsonl("org-1");
    expect(result.exampleCount).toBe(1);

    // The where clause MUST filter on APPROVED status — the test relies on
    // this to ensure DRAFT/IN_REVIEW responses aren't accidentally exported.
    const where = prismaMock.response.findMany.mock.calls[0][0].where;
    expect(where.question.status).toBe("APPROVED");
    expect(where.question.rfp.project.organizationId).toBe("org-1");
  });

  it("skips responses with empty content", async () => {
    prismaMock.response.findMany.mockResolvedValue([
      { content: "Real answer.", question: { text: "Q1" } },
      { content: "", question: { text: "Q2" } },
      { content: "   ", question: { text: "Q3" } },
    ]);
    const result = await exportApprovedResponsesJsonl("org-1");
    expect(result.exampleCount).toBe(1);
  });

  it("returns empty body + warning when there are no approved responses", async () => {
    prismaMock.response.findMany.mockResolvedValue([]);
    const result = await exportApprovedResponsesJsonl("org-1");
    expect(result.jsonl).toBe("");
    expect(result.warning).toMatch(/No approved responses/);
  });
});
