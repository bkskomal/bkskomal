import { describe, it, expect, beforeEach, vi } from "vitest";

const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    orgAiConfig: {
      findUnique: vi.fn(),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

import { resolveAdapter, adapterToModelName } from "./resolver";

beforeEach(() => {
  vi.clearAllMocks();
});

describe("resolveAdapter", () => {
  it("returns null when the org has no AI-config row", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue(null);
    const result = await resolveAdapter("org-1");
    expect(result).toBeNull();
  });

  it("returns null when loraAdapterUrl is blank/whitespace", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      loraAdapterUrl: "   ",
      loraAdapterMeta: null,
    });
    expect(await resolveAdapter("org-1")).toBeNull();
  });

  it("returns a full spec when adapter is configured", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      loraAdapterUrl: "ft:gpt-4o-mini:acme::abc123",
      loraAdapterMeta: {
        baseModel: "gpt-4o-mini",
        rank: 8,
        trainedAt: "2026-05-01T00:00:00Z",
        trainSize: 142,
        provider: "openai_ft",
        notes: "First production fine-tune",
      },
    });

    const result = await resolveAdapter("org-1");
    expect(result).toEqual({
      url: "ft:gpt-4o-mini:acme::abc123",
      baseModel: "gpt-4o-mini",
      rank: 8,
      trainedAt: "2026-05-01T00:00:00Z",
      trainSize: 142,
      provider: "openai_ft",
      notes: "First production fine-tune",
    });
  });

  it("tolerates missing/partial meta and falls back to baseModel='unknown'", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      loraAdapterUrl: "my-org/sales-lora",
      loraAdapterMeta: null,
    });
    const result = await resolveAdapter("org-1");
    expect(result?.url).toBe("my-org/sales-lora");
    expect(result?.baseModel).toBe("unknown");
    expect(result?.provider).toBeUndefined();
  });

  it("drops unknown provider strings instead of trusting them", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      loraAdapterUrl: "x",
      loraAdapterMeta: { baseModel: "gpt-4o-mini", provider: "made-up-provider" },
    });
    const result = await resolveAdapter("org-1");
    expect(result?.provider).toBeUndefined();
  });
});

describe("adapterToModelName", () => {
  it("returns the URL field as the model identifier", () => {
    expect(
      adapterToModelName({ url: "ft:gpt-4o-mini:acme::abc", baseModel: "gpt-4o-mini" }),
    ).toBe("ft:gpt-4o-mini:acme::abc");
  });
});
