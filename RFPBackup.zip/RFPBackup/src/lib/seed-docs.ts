// Seed an existing knowledge index with the bundled sample documents.
//
// Self-healing: if a document with the same name exists but is in FAILED or
// PENDING state, we retry the embedding step in place. Only INDEXED docs
// are skipped. Idempotent: safe to re-run after a misconfigured embedding
// endpoint is corrected.

import { prisma } from "@/lib/prisma";
import { embed } from "@/lib/ai/embeddings";
import { vectorStoreResolver } from "@/lib/ai/vector";
import { SAMPLE_KB_DOCS } from "./sample-data";

export interface SeedResult {
  added: number;
  retried: number;
  skipped: number;
  failed: number;
  documentNames: string[];
}

async function reembed(documentId: string, content: string, orgId: string): Promise<void> {
  await prisma.documentChunk.deleteMany({ where: { documentId } });
  const vec = await embed(content, orgId);
  // Look up indexId so the resolver can scope by org and the upsert can
  // tag chunks with full metadata for backends like Milvus.
  const docRow = await prisma.document.findUnique({
    where: { id: documentId },
    select: { indexId: true },
  });
  const row = await prisma.documentChunk.create({
    data: { documentId, ordinal: 0, content, embedding: [] },
    select: { id: true },
  });
  const writers = await vectorStoreResolver.writersForOrg(orgId);
  await Promise.all(
    writers.map((w) =>
      w.upsert([
        {
          id: row.id,
          embedding: vec,
          metadata: {
            documentId,
            indexId: docRow?.indexId ?? "",
            organizationId: orgId,
          },
        },
      ]),
    ),
  );
  await prisma.document.update({
    where: { id: documentId },
    data: { status: "INDEXED", errorMessage: null },
  });
}

export async function seedSampleDocs(
  indexId: string,
  organizationId: string,
): Promise<SeedResult> {
  const existing = await prisma.document.findMany({
    where: { indexId },
    select: { id: true, name: true, status: true },
  });
  const byName = new Map(existing.map((d) => [d.name, d]));

  let added = 0;
  let retried = 0;
  let skipped = 0;
  let failed = 0;
  const touchedNames: string[] = [];

  for (const sample of SAMPLE_KB_DOCS) {
    const present = byName.get(sample.name);

    // Already indexed — leave it alone.
    if (present && present.status === "INDEXED") {
      skipped++;
      continue;
    }

    // Existing but in FAILED/PENDING/PROCESSING — re-embed in place.
    if (present) {
      await prisma.document.update({
        where: { id: present.id },
        data: { status: "PROCESSING", errorMessage: null },
      });
      try {
        await reembed(present.id, sample.content, organizationId);
        retried++;
        touchedNames.push(sample.name);
      } catch (e) {
        await prisma.document.update({
          where: { id: present.id },
          data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
        });
        failed++;
      }
      continue;
    }

    // Brand new — create + embed.
    const doc = await prisma.document.create({
      data: {
        indexId,
        name: sample.name,
        fileName: sample.fileName,
        fileSize: Buffer.byteLength(sample.content),
        mimeType: "text/markdown",
        storagePath: `(synthetic)/sample/${sample.fileName}`,
        status: "PROCESSING",
      },
    });
    try {
      await reembed(doc.id, sample.content, organizationId);
      added++;
      touchedNames.push(sample.name);
    } catch (e) {
      await prisma.document.update({
        where: { id: doc.id },
        data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
      });
      failed++;
    }
  }

  return { added, retried, skipped, failed, documentNames: touchedNames };
}
