import { describe, expect, it } from "vitest";
import { extractRawMentions, resolveMentions } from "./mentions";

describe("extractRawMentions", () => {
  it("returns nothing for plain text", () => {
    expect(extractRawMentions("Hello, world.")).toEqual([]);
  });

  it("extracts email mentions", () => {
    const r = extractRawMentions("cc @alice@acme.com and @bob.smith@acme.com please");
    expect(r).toEqual([
      { text: "alice@acme.com", kind: "email" },
      { text: "bob.smith@acme.com", kind: "email" },
    ]);
  });

  it("extracts short handles", () => {
    const r = extractRawMentions("@alice can you weigh in? cc @bob");
    expect(r).toEqual([
      { text: "alice", kind: "handle" },
      { text: "bob", kind: "handle" },
    ]);
  });

  it("does not double-count an email's local part as a handle", () => {
    const r = extractRawMentions("@alice@acme.com let's chat");
    expect(r).toEqual([{ text: "alice@acme.com", kind: "email" }]);
  });

  it("doesn't match @ in the middle of an email-like word", () => {
    const r = extractRawMentions("see alice@acme.com for help");
    expect(r).toEqual([]);
  });

  it("de-duplicates repeats", () => {
    const r = extractRawMentions("@alice @alice @alice");
    expect(r).toHaveLength(1);
  });
});

describe("resolveMentions", () => {
  const members = [
    { id: "u_alice", email: "alice@acme.com" },
    { id: "u_bob", email: "bob@acme.com" },
    { id: "u_carol", email: "carol@other.com" },
  ];

  it("resolves email matches", () => {
    expect(resolveMentions([{ text: "alice@acme.com", kind: "email" }], members)).toEqual(["u_alice"]);
  });

  it("resolves handle matches when unambiguous", () => {
    expect(resolveMentions([{ text: "bob", kind: "handle" }], members)).toEqual(["u_bob"]);
  });

  it("skips ambiguous handles (same local-part on different domains)", () => {
    const ambig = [
      { id: "u1", email: "alex@a.com" },
      { id: "u2", email: "alex@b.com" },
    ];
    expect(resolveMentions([{ text: "alex", kind: "handle" }], ambig)).toEqual([]);
  });

  it("returns [] for unknown mentions", () => {
    expect(resolveMentions([{ text: "nobody@nowhere.com", kind: "email" }], members)).toEqual([]);
  });

  it("returns no duplicates when mentioned multiple ways", () => {
    const raw = [
      { text: "alice@acme.com", kind: "email" as const },
      { text: "alice", kind: "handle" as const },
    ];
    expect(resolveMentions(raw, members)).toEqual(["u_alice"]);
  });
});
