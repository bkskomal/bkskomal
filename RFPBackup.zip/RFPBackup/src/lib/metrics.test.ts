import { afterEach, describe, expect, it } from "vitest";
import {
  _resetForTests,
  counter,
  exposition,
  gauge,
  histogram,
} from "./metrics";

describe("metrics primitives", () => {
  afterEach(() => {
    _resetForTests();
  });

  it("counter accumulates with labels", () => {
    const c = counter("test_total", "test counter", ["route"]);
    c.inc({ route: "/a" });
    c.inc({ route: "/a" });
    c.inc({ route: "/b" }, 3);
    const out = exposition();
    expect(out).toContain('test_total{route="/a"} 2');
    expect(out).toContain('test_total{route="/b"} 3');
  });

  it("counter with no labels emits a single sample", () => {
    const c = counter("noop_total", "no-label counter");
    c.inc();
    c.inc(undefined, 4);
    const out = exposition();
    expect(out).toContain("noop_total 5");
  });

  it("histogram observe emits cumulative buckets, sum, and count", () => {
    const h = histogram(
      "test_duration_ms",
      "test histogram",
      ["route"],
      [10, 100, 1000],
    );
    h.observe({ route: "/x" }, 5);
    h.observe({ route: "/x" }, 50);
    h.observe({ route: "/x" }, 500);
    h.observe({ route: "/x" }, 5000); // beyond all buckets

    const out = exposition();
    // <=10 should hold 1 (the value 5)
    expect(out).toContain('test_duration_ms_bucket{le="10",route="/x"} 1');
    // <=100 cumulative: 5 and 50 -> 2
    expect(out).toContain('test_duration_ms_bucket{le="100",route="/x"} 2');
    // <=1000 cumulative: 5, 50, 500 -> 3
    expect(out).toContain('test_duration_ms_bucket{le="1000",route="/x"} 3');
    // +Inf: all 4 observations
    expect(out).toContain('test_duration_ms_bucket{le="+Inf",route="/x"} 4');
    expect(out).toContain('test_duration_ms_sum{route="/x"} 5555');
    expect(out).toContain('test_duration_ms_count{route="/x"} 4');
  });

  it("gauge supports set, inc, and dec", () => {
    const g = gauge("test_gauge", "test gauge", ["name"]);
    g.set({ name: "a" }, 10);
    g.inc({ name: "a" }, 5);
    g.dec({ name: "a" }, 2);
    g.set({ name: "b" }, 0);

    const out = exposition();
    expect(out).toContain('test_gauge{name="a"} 13');
    expect(out).toContain('test_gauge{name="b"} 0');
  });

  it("exposition emits HELP and TYPE lines for each metric", () => {
    counter("a_total", "an A counter").inc();
    gauge("b_gauge", "a B gauge").set(undefined, 42);
    const out = exposition();
    expect(out).toContain("# HELP a_total an A counter");
    expect(out).toContain("# TYPE a_total counter");
    expect(out).toContain("# HELP b_gauge a B gauge");
    expect(out).toContain("# TYPE b_gauge gauge");
    expect(out).toContain("a_total 1");
    expect(out).toContain("b_gauge 42");
  });

  it("_resetForTests clears all registered metrics and samples", () => {
    counter("ephemeral_total", "scratch counter").inc();
    expect(exposition()).toContain("ephemeral_total");
    _resetForTests();
    expect(exposition()).not.toContain("ephemeral_total");
  });

  it("counter is import-safe and silent on bad input", () => {
    const c = counter("safe_total", "safe", ["k"]);
    // intentionally pass weird values; should not throw
    expect(() => {
      c.inc({ k: "v\\with\"quotes\nand newline" });
      c.inc({ k: "v" }, Number.NaN);
    }).not.toThrow();
    const out = exposition();
    // escaping in label values
    expect(out).toContain('safe_total{k="v\\\\with\\"quotes\\nand newline"} 1');
  });

  it("re-registering the same metric returns the same instance", () => {
    const c1 = counter("dup_total", "dup", ["k"]);
    const c2 = counter("dup_total", "dup", ["k"]);
    c1.inc({ k: "x" });
    c2.inc({ k: "x" });
    const out = exposition();
    // shared underlying state -> one sample with value 2
    expect(out).toContain('dup_total{k="x"} 2');
  });

  it("output ends with a trailing newline (Prom convention)", () => {
    counter("trailing_total", "x").inc();
    const out = exposition();
    expect(out.endsWith("\n")).toBe(true);
  });
});
