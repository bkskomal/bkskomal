import { describe, expect, it, beforeEach, afterAll } from "vitest";
import {
  CircuitOpenError,
  createBreaker,
  _setNowForTests,
  _resetClockForTests,
} from "./circuit-breaker";

let t = 1_000_000;
beforeEach(() => {
  t = 1_000_000;
  _setNowForTests(() => t);
});

afterAll(() => {
  // Restore real clock after the file so other suites aren't affected.
  _resetClockForTests();
});

function ok<T>(value: T): () => Promise<T> {
  return () => Promise.resolve(value);
}

function fail(msg = "boom"): () => Promise<never> {
  return () => Promise.reject(new Error(msg));
}

describe("circuit-breaker", () => {
  it("starts CLOSED and passes successful calls through", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 3, resetTimeoutMs: 1000 });
    await expect(b(ok(42))).resolves.toBe(42);
    expect(b.inspect().state).toBe("CLOSED");
    expect(b.inspect().failures).toBe(0);
  });

  it("trips to OPEN after N consecutive failures", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 3, resetTimeoutMs: 1000 });
    for (let i = 0; i < 3; i++) {
      await expect(b(fail())).rejects.toThrow("boom");
    }
    expect(b.inspect().state).toBe("OPEN");
  });

  it("counts only consecutive failures — a success between failures resets the counter", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 3, resetTimeoutMs: 1000 });
    await expect(b(fail())).rejects.toThrow();
    await expect(b(fail())).rejects.toThrow();
    expect(b.inspect().failures).toBe(2);
    // Success in CLOSED resets.
    await expect(b(ok("ok"))).resolves.toBe("ok");
    expect(b.inspect().failures).toBe(0);
    // We need a fresh streak of 3 to open.
    await expect(b(fail())).rejects.toThrow();
    await expect(b(fail())).rejects.toThrow();
    expect(b.inspect().state).toBe("CLOSED");
  });

  it("OPEN rejects calls immediately with CircuitOpenError without invoking fn", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 1, resetTimeoutMs: 1000 });
    await expect(b(fail())).rejects.toThrow("boom");
    expect(b.inspect().state).toBe("OPEN");

    let invoked = 0;
    const probe = () => {
      invoked++;
      return Promise.resolve("should-not-run");
    };

    let caught: unknown;
    try {
      await b(probe);
    } catch (e) {
      caught = e;
    }
    expect(caught).toBeInstanceOf(CircuitOpenError);
    const err = caught as CircuitOpenError;
    expect(err.status).toBe(503);
    expect(err.code).toBe("circuit_open");
    expect(err.exposeMessage).toBe(true);
    expect(err.breaker).toBe("t");
    expect(invoked).toBe(0);
  });

  it("transitions OPEN -> HALF_OPEN after resetTimeoutMs and admits a probe", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 1, resetTimeoutMs: 5_000 });
    await expect(b(fail())).rejects.toThrow();
    expect(b.inspect().state).toBe("OPEN");

    // Just before the window elapses — still rejects.
    t += 4_999;
    await expect(b(ok(1))).rejects.toBeInstanceOf(CircuitOpenError);

    // After the window — HALF_OPEN admits the probe.
    t += 2;
    await expect(b(ok("probe"))).resolves.toBe("probe");
    // One probe success with default halfOpenSuccesses=1 closes the breaker.
    expect(b.inspect().state).toBe("CLOSED");
  });

  it("HALF_OPEN failure re-opens with a fresh window", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 1, resetTimeoutMs: 5_000 });
    await expect(b(fail())).rejects.toThrow();
    const firstOpenedAt = b.inspect().openedAt;

    t += 6_000;
    // HALF_OPEN — the probe fails.
    await expect(b(fail())).rejects.toThrow("boom");
    expect(b.inspect().state).toBe("OPEN");
    // The window restarted — openedAt advanced.
    expect(b.inspect().openedAt).toBeGreaterThan(firstOpenedAt);

    // And immediately, OPEN rejects again.
    await expect(b(ok(1))).rejects.toBeInstanceOf(CircuitOpenError);
  });

  it("HALF_OPEN with halfOpenSuccesses=2 requires two successes to close", async () => {
    const b = createBreaker({
      name: "t",
      failureThreshold: 1,
      resetTimeoutMs: 1_000,
      halfOpenSuccesses: 2,
    });
    await expect(b(fail())).rejects.toThrow();
    t += 1_001;

    await expect(b(ok("s1"))).resolves.toBe("s1");
    // After one success, still HALF_OPEN waiting for the second.
    expect(b.inspect().state).toBe("HALF_OPEN");

    await expect(b(ok("s2"))).resolves.toBe("s2");
    expect(b.inspect().state).toBe("CLOSED");
  });

  it("HALF_OPEN rejects piled-on concurrent calls so only one probe touches upstream", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 1, resetTimeoutMs: 1_000 });
    await expect(b(fail())).rejects.toThrow();
    t += 1_001;

    // First call grabs the probe slot and is in-flight (we never resolve it
    // here — it represents the probe waiting on a slow upstream).
    let resolveProbe: ((v: string) => void) | null = null;
    const probePromise = b(
      () =>
        new Promise<string>((res) => {
          resolveProbe = res;
        }),
    );

    // A concurrent call during the probe must reject with CircuitOpenError —
    // we don't want to pile load on a possibly-still-broken upstream.
    await expect(b(ok("queued"))).rejects.toBeInstanceOf(CircuitOpenError);

    // Resolve the probe — should close the breaker.
    resolveProbe!("probe-ok");
    await expect(probePromise).resolves.toBe("probe-ok");
    expect(b.inspect().state).toBe("CLOSED");

    // Now follow-up calls go through normally.
    await expect(b(ok("post-close"))).resolves.toBe("post-close");
  });

  it("reset() forces CLOSED regardless of prior state", async () => {
    const b = createBreaker({ name: "t", failureThreshold: 1, resetTimeoutMs: 60_000 });
    await expect(b(fail())).rejects.toThrow();
    expect(b.inspect().state).toBe("OPEN");
    b.reset();
    expect(b.inspect().state).toBe("CLOSED");
    expect(b.inspect().failures).toBe(0);
  });

  it("CircuitOpenError message is safe to expose to users", async () => {
    const b = createBreaker({ name: "llm:openrouter", failureThreshold: 1, resetTimeoutMs: 1_000 });
    await expect(b(fail())).rejects.toThrow();
    try {
      await b(ok(1));
    } catch (e) {
      expect(e).toBeInstanceOf(CircuitOpenError);
      const ce = e as CircuitOpenError;
      expect(ce.message).toContain("llm:openrouter");
      expect(ce.exposeMessage).toBe(true);
    }
  });
});
