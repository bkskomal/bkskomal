import NextAuth, { type DefaultSession, type NextAuthConfig } from "next-auth";
import { PrismaAdapter } from "@auth/prisma-adapter";
import Nodemailer from "next-auth/providers/nodemailer";
import Google from "next-auth/providers/google";
import GitHub from "next-auth/providers/github";
import MicrosoftEntraID from "next-auth/providers/microsoft-entra-id";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
    } & DefaultSession["user"];
  }
}

function buildProviders(): NextAuthConfig["providers"] {
  const providers: NextAuthConfig["providers"] = [
    Nodemailer({
      server: {
        host: env.EMAIL_SERVER_HOST,
        port: env.EMAIL_SERVER_PORT,
        auth: env.EMAIL_SERVER_USER
          ? { user: env.EMAIL_SERVER_USER, pass: env.EMAIL_SERVER_PASSWORD }
          : undefined,
      },
      from: env.EMAIL_FROM,
    }),
  ];

  if (env.OAUTH_GOOGLE_ID && env.OAUTH_GOOGLE_SECRET) {
    providers.push(
      Google({
        clientId: env.OAUTH_GOOGLE_ID,
        clientSecret: env.OAUTH_GOOGLE_SECRET,
      }),
    );
  }

  if (env.OAUTH_GITHUB_ID && env.OAUTH_GITHUB_SECRET) {
    providers.push(
      GitHub({
        clientId: env.OAUTH_GITHUB_ID,
        clientSecret: env.OAUTH_GITHUB_SECRET,
      }),
    );
  }

  if (env.OAUTH_MICROSOFT_ID && env.OAUTH_MICROSOFT_SECRET) {
    providers.push(
      MicrosoftEntraID({
        clientId: env.OAUTH_MICROSOFT_ID,
        clientSecret: env.OAUTH_MICROSOFT_SECRET,
        issuer: `https://login.microsoftonline.com/${env.OAUTH_MICROSOFT_TENANT_ID ?? "common"}/v2.0`,
      }),
    );
  }

  return providers;
}

/**
 * Returns the list of OAuth providers that are currently configured via env.
 * The email magic-link provider is intentionally NOT included here — this is
 * for the OAuth-buttons section of the sign-in UI only.
 */
export function enabledOAuthProviders(): { id: string; label: string }[] {
  const out: { id: string; label: string }[] = [];
  if (env.OAUTH_GOOGLE_ID && env.OAUTH_GOOGLE_SECRET) {
    out.push({ id: "google", label: "Google" });
  }
  if (env.OAUTH_GITHUB_ID && env.OAUTH_GITHUB_SECRET) {
    out.push({ id: "github", label: "GitHub" });
  }
  if (env.OAUTH_MICROSOFT_ID && env.OAUTH_MICROSOFT_SECRET) {
    out.push({ id: "microsoft-entra-id", label: "Microsoft" });
  }
  return out;
}

/**
 * Returns true if the email's domain belongs to an org whose SamlConfig has
 * `enforced=true`. Used by the signIn callback to block non-SAML methods for
 * SAML-bound orgs. Failures (DB down, etc.) fall open — denying sign-in on a
 * SAML config lookup error would be worse than letting the user proceed via
 * email+OAuth.
 */
async function isSamlEnforcedForEmail(email: string | null | undefined): Promise<boolean> {
  if (!email) return false;
  const at = email.indexOf("@");
  if (at < 0) return false;
  const domain = email.slice(at + 1).toLowerCase();
  try {
    const candidate = await prisma.user.findFirst({
      where: { email: { endsWith: `@${domain}` } },
      select: {
        memberships: {
          select: {
            organization: { select: { samlConfig: { select: { enforced: true, enabled: true } } } },
          },
        },
      },
    });
    if (!candidate) return false;
    for (const m of candidate.memberships) {
      const s = m.organization?.samlConfig;
      if (s?.enabled && s?.enforced) return true;
    }
    return false;
  } catch {
    return false;
  }
}

export const { handlers, auth, signIn, signOut } = NextAuth({
  adapter: PrismaAdapter(prisma),
  secret: env.AUTH_SECRET,
  session: { strategy: "database" },
  pages: { signIn: "/auth/signin", verifyRequest: "/auth/verify" },
  providers: buildProviders(),
  callbacks: {
    async session({ session, user }) {
      if (session.user) session.user.id = user.id;
      return session;
    },
    /**
     * SAML enforcement guard: if the user's email domain is bound to an org
     * with `enforced=true`, block all other sign-in paths. Our own SAML route
     * (`/api/auth/saml/...`) issues sessions directly via PrismaAdapter — it
     * does not go through this callback, so it's not affected.
     */

    async signIn({ user }) {
      const enforced = await isSamlEnforcedForEmail(user?.email);
      if (enforced) return false;
      return true;
    },
  },
});
