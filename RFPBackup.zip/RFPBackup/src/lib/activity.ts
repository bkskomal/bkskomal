import { prisma } from "@/lib/prisma";
import type { ActivityKind } from "@prisma/client";

/**
 * Log a single activity event for an RFP. Fire-and-forget — failures shouldn't
 * break the user-facing operation.
 */
export async function logActivity(input: {
  rfpId: string;
  actorId: string | null;
  kind: ActivityKind;
  payload?: Record<string, unknown> | null;
}): Promise<void> {
  try {
    await prisma.activityEvent.create({
      data: {
        rfpId: input.rfpId,
        actorId: input.actorId,
        kind: input.kind,
        payload: (input.payload as never) ?? undefined,
      },
    });
  } catch (e) {
    console.warn("[activity] failed to log:", e);
  }
}
