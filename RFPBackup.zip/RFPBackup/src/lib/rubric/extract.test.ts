import { describe, expect, it, vi, beforeEach } from "vitest";
import {
  findRubricSection,
  normalizeWeights,
  parseRubricJson,
  slugify,
  extractRubric,
  type RubricCriterion,
} from "./extract";

// ---------------------------------------------------------------------------
// Mocks for extractRubric — we hoist them so the factory closures see the
// vi.fn instances at module evaluation time. The AI client is replaced with
// a stub whose chat.completions.create returns a canned JSON payload per
// test.
// ---------------------------------------------------------------------------

const { aiClientMock } = vi.hoisted(() => ({
  aiClientMock: vi.fn(),
}));

vi.mock("@/lib/ai/client", () => ({
  getAiClients: () => aiClientMock(),
}));

beforeEach(() => {
  vi.clearAllMocks();
});

// ---- slugify --------------------------------------------------------------

describe("slugify", () => {
  it("lowercases and hyphenates", () => {
    expect(slugify("Technical Approach")).toBe("technical-approach");
    expect(slugify("  Price / Value  ")).toBe("price-value");
    expect(slugify("___odd---chars!!")).toBe("odd-chars");
  });
});

// ---- normalizeWeights -----------------------------------------------------

describe("normalizeWeights", () => {
  const base = (n: number): RubricCriterion[] =>
    Array.from({ length: n }, (_, i) => ({
      id: `c-${i + 1}`,
      label: `C${i + 1}`,
      description: "",
      weight: 0,
    }));

  it("rescales weights summing > 1 to exactly 1", () => {
    const input: RubricCriterion[] = [
      { id: "a", label: "A", description: "", weight: 40 },
      { id: "b", label: "B", description: "", weight: 60 },
    ];
    const out = normalizeWeights(input);
    expect(out.map((c) => c.weight)).toEqual([0.4, 0.6]);
    expect(out.reduce((a, c) => a + c.weight, 0)).toBeCloseTo(1, 4);
  });

  it("evenly distributes when all weights are zero", () => {
    const out = normalizeWeights(base(4));
    expect(out.map((c) => c.weight).reduce((a, b) => a + b, 0)).toBeCloseTo(1, 4);
    // first three are 0.25 (rounded), last absorbs remainder.
    expect(out[0]!.weight).toBeCloseTo(0.25);
    expect(out[3]!.weight).toBeCloseTo(0.25);
  });

  it("fills mixed missing+present weights", () => {
    const input: RubricCriterion[] = [
      { id: "a", label: "A", description: "", weight: 0.4 },
      { id: "b", label: "B", description: "", weight: 0 }, // missing
      { id: "c", label: "C", description: "", weight: 0.4 },
    ];
    const out = normalizeWeights(input);
    const sum = out.reduce((a, c) => a + c.weight, 0);
    expect(sum).toBeCloseTo(1, 4);
    // The previously-zero slot must end up with some positive weight.
    expect(out[1]!.weight).toBeGreaterThan(0);
  });

  it("is a no-op for an empty array", () => {
    expect(normalizeWeights([])).toEqual([]);
  });
});

// ---- findRubricSection ----------------------------------------------------

describe("findRubricSection", () => {
  it("finds an 'Evaluation Criteria' section and trims it", () => {
    const text = [
      "# 1. Introduction",
      "Some intro text here.",
      "",
      "# 4. Evaluation Criteria",
      "Technical Approach: 40%",
      "Price: 30%",
      "Experience: 30%",
      "",
      "# 5. Submission Instructions",
      "Send proposals to ...",
    ].join("\n");
    const section = findRubricSection(text);
    expect(section).not.toBeNull();
    expect(section).toContain("Evaluation Criteria");
    expect(section).toContain("Technical Approach: 40%");
    // The next major heading must be cut off.
    expect(section).not.toContain("Submission Instructions");
  });

  it("returns null when no rubric header is present", () => {
    expect(findRubricSection("Just some general RFP text. No criteria here.")).toBeNull();
  });

  it("respects the 2KB cap", () => {
    const padding = "x".repeat(5000);
    const text = `# Evaluation Criteria\n${padding}`;
    const section = findRubricSection(text);
    expect(section).not.toBeNull();
    expect(section!.length).toBeLessThanOrEqual(2048);
  });
});

// ---- parseRubricJson ------------------------------------------------------

describe("parseRubricJson", () => {
  it("normalizes a well-formed payload with explicit weights", () => {
    const raw = JSON.stringify({
      criteria: [
        { id: "tech", label: "Technical Approach", weight: 0.4, description: "" },
        { id: "price", label: "Price", weight: 0.3, description: "" },
        { id: "exp", label: "Experience", weight: 0.3, description: "" },
      ],
      extraction_confidence: 1.0,
      rationale: "buyer stated explicit weights",
    });
    const out = parseRubricJson(raw);
    expect(out.criteria).toHaveLength(3);
    expect(out.extractionConfidence).toBe(1.0);
    const sum = out.criteria.reduce((a, c) => a + c.weight, 0);
    expect(sum).toBeCloseTo(1, 4);
  });

  it("assigns ordinal weights when buyer only gave an ordering", () => {
    // Simulate: model returns three criteria with descending weights summing to 1.0.
    const raw = JSON.stringify({
      criteria: [
        { id: "tech", label: "Technical", weight: 0.5, description: "" },
        { id: "price", label: "Price", weight: 0.3, description: "" },
        { id: "exp", label: "Experience", weight: 0.2, description: "" },
      ],
      extraction_confidence: 0.7,
      rationale: "ordinal weights inferred from ordering",
    });
    const out = parseRubricJson(raw);
    expect(out.criteria.map((c) => c.weight)).toEqual([0.5, 0.3, 0.2]);
    expect(out.extractionConfidence).toBe(0.7);
    // Strictly decreasing.
    for (let i = 1; i < out.criteria.length; i++) {
      expect(out.criteria[i]!.weight).toBeLessThan(out.criteria[i - 1]!.weight);
    }
  });

  it("returns empty criteria with 0.1 confidence on bogus JSON", () => {
    expect(parseRubricJson("not json").criteria).toEqual([]);
    expect(parseRubricJson("not json").extractionConfidence).toBe(0.1);
  });

  it("detects must-have via label/description even without the flag", () => {
    const raw = JSON.stringify({
      criteria: [
        {
          id: "compliance",
          label: "Compliance",
          description: "Vendor shall meet all required minimum security controls.",
          weight: 0.5,
        },
        {
          id: "extras",
          label: "Extras",
          description: "Optional bonus features.",
          weight: 0.5,
        },
      ],
      extraction_confidence: 1.0,
      rationale: "",
    });
    const out = parseRubricJson(raw);
    expect(out.criteria[0]!.mustHave).toBe(true);
    expect(out.criteria[1]!.mustHave).toBe(false);
  });

  it("deduplicates colliding ids with numeric suffixes", () => {
    const raw = JSON.stringify({
      criteria: [
        { id: "x", label: "Technical", weight: 0.5, description: "" },
        { id: "x", label: "Technical", weight: 0.5, description: "" },
      ],
      extraction_confidence: 1.0,
    });
    const out = parseRubricJson(raw);
    expect(out.criteria.map((c) => c.id)).toEqual(["x", "x-2"]);
  });
});

// ---- extractRubric (uses the AI client mock) -----------------------------

describe("extractRubric", () => {
  function setupLlmReturning(payload: unknown) {
    aiClientMock.mockResolvedValue({
      config: { llm: { model: "test-model" } },
      llm: {
        chat: {
          completions: {
            create: vi
              .fn()
              .mockResolvedValue({
                choices: [{ message: { content: JSON.stringify(payload) } }],
              }),
          },
        },
      },
      embedder: {},
    });
  }

  it("returns the LLM's criteria with high confidence when explicit weights are present", async () => {
    setupLlmReturning({
      criteria: [
        { id: "tech", label: "Technical Approach", weight: 0.4, description: "" },
        { id: "price", label: "Price", weight: 0.3, description: "" },
        { id: "ref", label: "References", weight: 0.3, description: "" },
      ],
      extraction_confidence: 0.95,
      rationale: "explicit percentages",
    });

    const rawText = [
      "# 4. Evaluation Criteria",
      "Technical Approach: 40%",
      "Price: 30%",
      "References: 30%",
    ].join("\n");

    const out = await extractRubric({ rawText, organizationId: "org-1" });
    expect(out.criteria).toHaveLength(3);
    expect(out.extractionConfidence).toBeGreaterThanOrEqual(0.9);
  });

  it("returns empty criteria + 0.1 confidence when no rubric section is found", async () => {
    setupLlmReturning({ criteria: [], extraction_confidence: 0.1 });
    const out = await extractRubric({
      rawText: "Just some prose with no criteria header at all.",
      organizationId: "org-1",
    });
    expect(out.criteria).toEqual([]);
    expect(out.extractionConfidence).toBe(0.1);
  });
});
