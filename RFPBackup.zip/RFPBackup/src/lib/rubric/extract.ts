// Auto-extract evaluation rubric from RFP raw text.
//
// Pipeline:
//   1. Scan rawText for any rubric section header (Evaluation Criteria,
//      Selection Criteria, Award Criteria, How proposals will be evaluated,
//      Scoring Methodology, Weighting, …). Cut the section at the next
//      major heading or 2KB cap.
//   2. Run a single LLM call with RUBRIC_EXTRACTION_SYSTEM. The model
//      returns a JSON object with criteria, extraction_confidence, and a
//      rationale.
//   3. Normalize: clamp weights, dedupe ids, ensure weights sum to ~1.0,
//      slugify labels when ids are missing. Detect "must-have" phrases on
//      label+description when the model didn't set the flag.
//   4. If no section was found, fall back to extraction_confidence 0.1 with
//      empty criteria. The caller persists this anyway so the UI can show
//      "no rubric detected".

import { getAiClients, type AiClients } from "@/lib/ai/client";
import { stripCodeFences } from "@/lib/ai/json-utils";
import { RUBRIC_EXTRACTION_SYSTEM } from "@/lib/ai/prompts";

// --- Public types -----------------------------------------------------------

export interface RubricCriterion {
  /** Slug-style identifier, stable across re-extractions where possible. */
  id: string;
  /** Buyer's wording for the criterion, lightly cleaned. */
  label: string;
  /** 0..1, with all criteria's weights summing to ~1.0 across the rubric. */
  weight: number;
  /** One short sentence describing what the buyer is evaluating. */
  description: string;
  /** True when the criterion is a gating "must-have". Defaults to false. */
  mustHave?: boolean;
}

export interface ExtractedRubric {
  criteria: RubricCriterion[];
  /** 0..1 — how confident we are that we recovered the buyer's intent. */
  extractionConfidence: number;
  /** Brief LLM note describing the extraction. */
  rationale: string;
}

// --- Section detection ------------------------------------------------------

/**
 * Headers (case-insensitive) that strongly indicate the start of an
 * evaluation-rubric section. Ordered roughly by how often we see each
 * variant in real RFPs.
 */
const RUBRIC_HEADER_PATTERNS: RegExp[] = [
  /evaluation\s+criteria/i,
  /selection\s+criteria/i,
  /award\s+criteria/i,
  /scoring\s+methodology/i,
  /scoring\s+criteria/i,
  /evaluation\s+methodology/i,
  /how\s+proposals\s+will\s+be\s+evaluated/i,
  /proposal\s+evaluation/i,
  /weighting/i,
  /evaluation\s+factors?/i,
];

/** Approx. 2KB cap on the extracted section body — keeps the LLM call cheap. */
export const MAX_RUBRIC_SECTION_CHARS = 2048;

/**
 * Phrases on a criterion's label/description that mark it as "must-have" /
 * gating. The LLM is asked to set this directly, but we also re-check
 * locally so a model that forgot the flag still gets credit.
 */
const MUST_HAVE_PHRASES: RegExp[] = [
  /\bmust(?:[- ]have)?\b/i,
  /\bminimum\b/i,
  /\bshall\b/i,
  /\brequired\b/i,
  /\bqualifying\b/i,
  /\bmandatory\b/i,
  /\bgating\b/i,
];

/**
 * Locate the rubric section in raw text. Returns the slice (capped at
 * MAX_RUBRIC_SECTION_CHARS) or null if no header matched.
 *
 * Strategy:
 *   - Walk the text once with each header regex; pick the earliest match.
 *   - Section ends at the next markdown heading (`^#`, `^##`) or a line that
 *     looks like a numbered top-level heading (e.g. "5. Submission").
 *   - Cap at MAX_RUBRIC_SECTION_CHARS regardless to keep the LLM call bounded.
 */
export function findRubricSection(rawText: string): string | null {
  const text = (rawText ?? "").trim();
  if (!text) return null;

  let earliest = -1;
  for (const re of RUBRIC_HEADER_PATTERNS) {
    const m = re.exec(text);
    if (m && m.index !== undefined) {
      if (earliest < 0 || m.index < earliest) earliest = m.index;
    }
  }
  if (earliest < 0) return null;

  // Find the start of the line containing the match — we want the header
  // text itself to be the start of the section.
  let start = earliest;
  while (start > 0 && text[start - 1] !== "\n") start--;

  // Search forward for the next "major" heading after a reasonable offset
  // so the immediate header line itself doesn't terminate the section.
  const tail = text.slice(start);
  const SEARCH_FROM = 40; // skip past the header line itself
  const nextHeadingRe = /\n(?:#{1,2}\s+\w|\d+\.\s+[A-Z][A-Za-z])/g;
  nextHeadingRe.lastIndex = SEARCH_FROM;
  const next = nextHeadingRe.exec(tail);
  let end = next ? next.index : tail.length;
  if (end > MAX_RUBRIC_SECTION_CHARS) end = MAX_RUBRIC_SECTION_CHARS;
  return tail.slice(0, end).trim();
}

// --- Public entry point -----------------------------------------------------

/**
 * Extract the buyer's evaluation rubric from raw RFP text. Always resolves —
 * never throws — so the pipeline can call this fire-and-forget. On total
 * failure returns an empty-criteria result with extractionConfidence 0.1.
 */
export async function extractRubric(opts: {
  rawText: string;
  organizationId: string;
}): Promise<ExtractedRubric> {
  const section = findRubricSection(opts.rawText);
  if (!section) {
    return {
      criteria: [],
      extractionConfidence: 0.1,
      rationale: "no rubric section detected in raw text",
    };
  }

  let clients: AiClients;
  try {
    clients = await getAiClients(opts.organizationId);
  } catch {
    return {
      criteria: [],
      extractionConfidence: 0.1,
      rationale: "ai client unavailable",
    };
  }

  let raw = "{}";
  try {
    const completion = await clients.llm.chat.completions.create({
      model: clients.config.llm.model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: RUBRIC_EXTRACTION_SYSTEM },
        { role: "user", content: section },
      ],
    });
    raw = completion.choices[0]?.message?.content ?? "{}";
  } catch {
    return {
      criteria: [],
      extractionConfidence: 0.1,
      rationale: "rubric extraction call failed",
    };
  }

  return parseRubricJson(raw);
}

// --- Parsing / normalization -----------------------------------------------

/**
 * Parse the LLM's JSON output and normalize criteria. Exposed for tests so
 * we can drive the parsing path without an LLM.
 */
export function parseRubricJson(raw: string): ExtractedRubric {
  let parsed: unknown;
  try {
    parsed = JSON.parse(stripCodeFences(raw));
  } catch {
    return { criteria: [], extractionConfidence: 0.1, rationale: "unparseable" };
  }
  if (!parsed || typeof parsed !== "object") {
    return { criteria: [], extractionConfidence: 0.1, rationale: "unparseable" };
  }

  const obj = parsed as Record<string, unknown>;
  const rawCriteria = Array.isArray(obj.criteria) ? obj.criteria : [];
  const confidence = clampUnit(
    typeof obj.extraction_confidence === "number"
      ? obj.extraction_confidence
      : typeof obj.extractionConfidence === "number"
        ? obj.extractionConfidence
        : 0.4,
  );
  const rationale =
    typeof obj.rationale === "string" && obj.rationale.trim()
      ? obj.rationale.trim()
      : "";

  const seenIds = new Set<string>();
  const criteria: RubricCriterion[] = [];
  for (let i = 0; i < rawCriteria.length; i++) {
    const c = rawCriteria[i];
    if (!c || typeof c !== "object") continue;
    const rec = c as Record<string, unknown>;
    const label = typeof rec.label === "string" ? rec.label.trim() : "";
    if (!label) continue;
    let id = typeof rec.id === "string" && rec.id.trim() ? slugify(rec.id) : slugify(label);
    if (!id) id = `criterion-${i + 1}`;
    // Ensure uniqueness — if the model emitted two with the same slug,
    // suffix the duplicates so persistence and lookup stay stable.
    let dedupId = id;
    let counter = 2;
    while (seenIds.has(dedupId)) {
      dedupId = `${id}-${counter++}`;
    }
    seenIds.add(dedupId);

    const weight = clampUnit(typeof rec.weight === "number" ? rec.weight : 0);
    const description = typeof rec.description === "string" ? rec.description.trim() : "";

    let mustHave =
      rec.mustHave === true ||
      rec.must_have === true ||
      rec.mustHave === "true";
    if (!mustHave) {
      // Local heuristic: phrases anywhere in label/description.
      const hay = `${label} ${description}`;
      if (MUST_HAVE_PHRASES.some((re) => re.test(hay))) {
        mustHave = true;
      }
    }

    criteria.push({
      id: dedupId,
      label,
      weight,
      description,
      mustHave,
    });
  }

  return {
    criteria: normalizeWeights(criteria),
    extractionConfidence: confidence,
    rationale,
  };
}

/**
 * Normalize weights so the criteria array sums to 1.0. Handles three cases:
 *   - All weights present and >0 → scale to sum 1.
 *   - All weights zero/missing → assign equal weights.
 *   - Some present, some zero → fill zeros with equal share of the leftover,
 *     then renormalize.
 *
 * Exported for unit-testing.
 */
export function normalizeWeights(criteria: RubricCriterion[]): RubricCriterion[] {
  if (criteria.length === 0) return criteria;
  const present = criteria.filter((c) => c.weight > 0);
  const totalPresent = present.reduce((acc, c) => acc + c.weight, 0);

  if (present.length === criteria.length && totalPresent > 0) {
    // All have weights — rescale to 1.0.
    return criteria.map((c) => ({ ...c, weight: round4(c.weight / totalPresent) }));
  }

  if (present.length === 0) {
    // None have weights — equal split.
    const share = round4(1 / criteria.length);
    return criteria.map((c, i) => ({
      ...c,
      // Last one absorbs the rounding remainder so the sum is exactly 1.
      weight: i === criteria.length - 1 ? round4(1 - share * (criteria.length - 1)) : share,
    }));
  }

  // Mixed — give zeros an equal share of the leftover, then renormalize.
  const leftover = Math.max(0, 1 - totalPresent);
  const zeroCount = criteria.length - present.length;
  const zeroShare = zeroCount > 0 ? leftover / zeroCount : 0;
  const filled = criteria.map((c) => ({
    ...c,
    weight: c.weight > 0 ? c.weight : zeroShare,
  }));
  const sum = filled.reduce((a, c) => a + c.weight, 0);
  if (sum <= 0) {
    const share = round4(1 / filled.length);
    return filled.map((c) => ({ ...c, weight: share }));
  }
  return filled.map((c) => ({ ...c, weight: round4(c.weight / sum) }));
}

// --- Helpers ---------------------------------------------------------------

function clampUnit(n: number): number {
  if (!Number.isFinite(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}

function round4(n: number): number {
  return Math.round(n * 10000) / 10000;
}

/** Lowercase, hyphenated slug derived from arbitrary text. */
export function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
}
