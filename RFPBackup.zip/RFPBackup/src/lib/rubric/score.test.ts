import { describe, expect, it, vi, beforeEach } from "vitest";
import {
  computeWeightedTotal,
  parseCriterionScoreJson,
  pickWeakestCriteria,
  scoreRubric,
  type CriterionScore,
} from "./score";
import type { RubricCriterion } from "./extract";

const { aiClientMock, prismaMock } = vi.hoisted(() => ({
  aiClientMock: vi.fn(),
  prismaMock: {
    response: {
      findMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/ai/client", () => ({
  getAiClients: () => aiClientMock(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

beforeEach(() => {
  vi.clearAllMocks();
});

// ---- parseCriterionScoreJson ----------------------------------------------

describe("parseCriterionScoreJson", () => {
  it("parses a well-formed JSON payload", () => {
    const raw = JSON.stringify({
      score: 0.72,
      rationale: "covers most of the criterion",
      evidence: ["Snippet A", "Snippet B"],
    });
    const s = parseCriterionScoreJson("c1", raw);
    expect(s.score).toBe(0.72);
    expect(s.rationale).toBe("covers most of the criterion");
    expect(s.evidence).toEqual(["Snippet A", "Snippet B"]);
  });

  it("clamps out-of-range scores and trims evidence", () => {
    const raw = JSON.stringify({
      score: 1.4,
      rationale: " ",
      evidence: ["a", "b", "c", "d", "e"],
    });
    const s = parseCriterionScoreJson("c1", raw);
    expect(s.score).toBe(1);
    expect(s.evidence).toHaveLength(3);
  });

  it("returns a safe default for unparseable input", () => {
    const s = parseCriterionScoreJson("c1", "not json");
    expect(s.score).toBe(0);
    expect(s.evidence).toEqual([]);
  });
});

// ---- computeWeightedTotal -------------------------------------------------

describe("computeWeightedTotal", () => {
  const rubric: RubricCriterion[] = [
    { id: "tech", label: "Technical", weight: 0.4, description: "" },
    { id: "price", label: "Price", weight: 0.3, description: "" },
    { id: "exp", label: "Experience", weight: 0.3, description: "" },
  ];

  it("computes the weighted average", () => {
    const scores: Record<string, CriterionScore> = {
      tech: { criterionId: "tech", score: 1.0, rationale: "", evidence: [] },
      price: { criterionId: "price", score: 0.5, rationale: "", evidence: [] },
      exp: { criterionId: "exp", score: 0.0, rationale: "", evidence: [] },
    };
    const total = computeWeightedTotal(rubric, scores);
    // 0.4*1.0 + 0.3*0.5 + 0.3*0.0 = 0.55
    expect(total).toBeCloseTo(0.55, 4);
  });

  it("returns 0 when no scores are provided", () => {
    expect(computeWeightedTotal(rubric, {})).toBe(0);
  });

  it("ignores criteria with no matching score", () => {
    const scores: Record<string, CriterionScore> = {
      tech: { criterionId: "tech", score: 1.0, rationale: "", evidence: [] },
    };
    // Only the 'tech' criterion (weight 0.4) is scored — weighted avg is
    // 0.4*1.0 / 0.4 = 1.0.
    expect(computeWeightedTotal(rubric, scores)).toBe(1);
  });
});

// ---- pickWeakestCriteria --------------------------------------------------

describe("pickWeakestCriteria", () => {
  it("returns the bottom N by score, weakest first", () => {
    const scores: Record<string, CriterionScore> = {
      a: { criterionId: "a", score: 0.8, rationale: "", evidence: [] },
      b: { criterionId: "b", score: 0.1, rationale: "", evidence: [] },
      c: { criterionId: "c", score: 0.4, rationale: "", evidence: [] },
      d: { criterionId: "d", score: 0.6, rationale: "", evidence: [] },
    };
    expect(pickWeakestCriteria(scores, 3)).toEqual(["b", "c", "d"]);
  });

  it("breaks ties alphabetically for stable output", () => {
    const scores: Record<string, CriterionScore> = {
      x: { criterionId: "x", score: 0.5, rationale: "", evidence: [] },
      a: { criterionId: "a", score: 0.5, rationale: "", evidence: [] },
      m: { criterionId: "m", score: 0.5, rationale: "", evidence: [] },
    };
    expect(pickWeakestCriteria(scores, 3)).toEqual(["a", "m", "x"]);
  });

  it("returns at most `limit` ids", () => {
    const scores: Record<string, CriterionScore> = {
      a: { criterionId: "a", score: 0.1, rationale: "", evidence: [] },
      b: { criterionId: "b", score: 0.2, rationale: "", evidence: [] },
      c: { criterionId: "c", score: 0.3, rationale: "", evidence: [] },
    };
    expect(pickWeakestCriteria(scores, 2)).toEqual(["a", "b"]);
  });
});

// ---- scoreRubric (uses mocks for prisma + llm) ----------------------------

describe("scoreRubric", () => {
  beforeEach(() => {
    prismaMock.response.findMany.mockResolvedValue([
      {
        content: "We deploy multi-AZ with hot standby.",
        questionId: "q1",
        confidence: 0.9,
        createdAt: new Date(),
        question: { id: "q1", text: "Describe DR posture", complexity: "complex" },
      },
      {
        content: "AES-256 at rest, TLS 1.3 in transit.",
        questionId: "q2",
        confidence: 0.85,
        createdAt: new Date(),
        question: { id: "q2", text: "Describe encryption", complexity: "moderate" },
      },
    ]);
  });

  function setupLlmReturningPerCriterion(scoresByCriterion: Record<string, number>) {
    const callMock = vi.fn();
    callMock.mockImplementation(async (req: { messages: Array<{ content: string }> }) => {
      const userMsg = req.messages.find((m: { content: string }) =>
        typeof m.content === "string" && m.content.startsWith("CRITERION:"),
      );
      const content = userMsg?.content ?? "";
      // Match `CRITERION: <label>` so we can look up the right score.
      const labelLine = content.split("\n")[0] ?? "";
      const label = labelLine.replace(/^CRITERION:\s*/, "").trim();
      const score = scoresByCriterion[label] ?? 0;
      return {
        choices: [
          {
            message: {
              content: JSON.stringify({
                score,
                rationale: `score ${score}`,
                evidence: ["E1"],
              }),
            },
          },
        ],
      };
    });
    aiClientMock.mockResolvedValue({
      config: { llm: { model: "test-model" } },
      llm: { chat: { completions: { create: callMock } } },
      embedder: {},
    });
  }

  it("computes weighted average + weakestCriteria from per-criterion scores", async () => {
    setupLlmReturningPerCriterion({
      Technical: 1.0,
      Price: 0.5,
      Experience: 0.0,
    });

    const rubric: RubricCriterion[] = [
      { id: "tech", label: "Technical", weight: 0.4, description: "" },
      { id: "price", label: "Price", weight: 0.3, description: "" },
      { id: "exp", label: "Experience", weight: 0.3, description: "" },
    ];

    const result = await scoreRubric({
      rfpId: "rfp-1",
      rubric,
      organizationId: "org-1",
    });

    expect(result.totalScore).toBeCloseTo(0.55, 4);
    expect(result.weakestCriteria[0]).toBe("exp");
    expect(result.weakestCriteria).toHaveLength(3);
    expect(Object.keys(result.perCriterionScores).sort()).toEqual(["exp", "price", "tech"]);
  });

  it("returns an empty score when rubric is empty (no LLM calls)", async () => {
    const result = await scoreRubric({
      rfpId: "rfp-1",
      rubric: [],
      organizationId: "org-1",
    });
    expect(result.totalScore).toBe(0);
    expect(result.perCriterionScores).toEqual({});
    expect(result.weakestCriteria).toEqual([]);
    expect(aiClientMock).not.toHaveBeenCalled();
  });

  it("invokes onProgress once per criterion", async () => {
    setupLlmReturningPerCriterion({ Technical: 0.8, Price: 0.4 });
    const seen: string[] = [];
    const rubric: RubricCriterion[] = [
      { id: "tech", label: "Technical", weight: 0.5, description: "" },
      { id: "price", label: "Price", weight: 0.5, description: "" },
    ];
    await scoreRubric({
      rfpId: "rfp-1",
      rubric,
      organizationId: "org-1",
      onProgress: (s) => {
        seen.push(s.criterionId);
      },
    });
    expect(seen).toEqual(["tech", "price"]);
  });
});
