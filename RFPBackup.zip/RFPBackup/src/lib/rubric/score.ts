// Score an in-progress RFP response against an extracted evaluation rubric.
//
// Cost model: one LLM call per criterion (not per question). For each
// criterion we send the criterion's label + description and the top-N
// (default 8) most complex responses, then ask for a single 0..1 score with
// rationale and a few evidence snippets. The total cost grows with the size
// of the rubric, not the number of questions.

import { prisma } from "@/lib/prisma";
import { getAiClients, type AiClients } from "@/lib/ai/client";
import { stripCodeFences } from "@/lib/ai/json-utils";
import { RUBRIC_SCORE_CRITERION_SYSTEM } from "@/lib/ai/prompts";
import type { Complexity } from "@/lib/ai/extract";
import type { RubricCriterion } from "./extract";

// --- Public types -----------------------------------------------------------

export interface CriterionScore {
  criterionId: string;
  /** 0..1; 0 = not addressed, 1 = fully addressed. */
  score: number;
  rationale: string;
  /** Short verbatim snippets that drove the score. */
  evidence: string[];
}

export interface RubricScore {
  /** Weighted average across criterion scores. 0..1. */
  totalScore: number;
  perCriterionScores: Record<string, CriterionScore>;
  /** Up to 3 criterion ids with the lowest scores, weakest first. */
  weakestCriteria: string[];
  scoredAt: Date;
}

const TOP_N_RESPONSES = 8;
/** Per-snippet cap so the prompt body stays bounded. */
const MAX_RESPONSE_CHARS = 800;

// --- Public entry point -----------------------------------------------------

/**
 * Score the RFP's in-progress responses against each criterion. Loads the
 * top-N responses from the DB (ranked by question complexity, then by
 * confidence) and dispatches one LLM call per criterion sequentially —
 * sequential rather than parallel so SSE consumers can observe per-criterion
 * progress through the optional `onProgress` callback.
 */
export async function scoreRubric(opts: {
  rfpId: string;
  rubric: RubricCriterion[];
  organizationId: string;
  /** Called once per criterion with the freshly-computed score. */
  onProgress?: (s: CriterionScore) => void | Promise<void>;
}): Promise<RubricScore> {
  const { rfpId, rubric, organizationId, onProgress } = opts;

  if (rubric.length === 0) {
    return {
      totalScore: 0,
      perCriterionScores: {},
      weakestCriteria: [],
      scoredAt: new Date(),
    };
  }

  const responses = await loadTopResponses(rfpId, TOP_N_RESPONSES);
  const responsesBlock = formatResponsesBlock(responses);

  const clients = await getAiClients(organizationId);

  const perCriterionScores: Record<string, CriterionScore> = {};
  for (const criterion of rubric) {
    const score = await scoreOneCriterion(criterion, responsesBlock, clients);
    perCriterionScores[criterion.id] = score;
    if (onProgress) {
      try {
        await onProgress(score);
      } catch {
        // Telemetry callback errors must never poison the score loop.
      }
    }
  }

  const totalScore = computeWeightedTotal(rubric, perCriterionScores);
  const weakestCriteria = pickWeakestCriteria(perCriterionScores, 3);

  return {
    totalScore,
    perCriterionScores,
    weakestCriteria,
    scoredAt: new Date(),
  };
}

// --- Aggregate weighted score ----------------------------------------------

/**
 * Compute the weighted average of per-criterion scores. Exported for tests.
 */
export function computeWeightedTotal(
  rubric: RubricCriterion[],
  scores: Record<string, CriterionScore>,
): number {
  let totalWeight = 0;
  let weighted = 0;
  for (const c of rubric) {
    const s = scores[c.id];
    if (!s) continue;
    weighted += c.weight * s.score;
    totalWeight += c.weight;
  }
  if (totalWeight <= 0) return 0;
  return round4(weighted / totalWeight);
}

/**
 * Return the criterion ids with the lowest scores, weakest first, capped
 * at `limit`. Ties broken alphabetically for deterministic output.
 */
export function pickWeakestCriteria(
  scores: Record<string, CriterionScore>,
  limit: number,
): string[] {
  return Object.values(scores)
    .slice()
    .sort((a, b) => {
      if (a.score !== b.score) return a.score - b.score;
      return a.criterionId.localeCompare(b.criterionId);
    })
    .slice(0, limit)
    .map((s) => s.criterionId);
}

// --- Response loading ------------------------------------------------------

interface LoadedResponse {
  questionId: string;
  questionText: string;
  questionComplexity: Complexity | null;
  content: string;
}

/**
 * Load the top-N COMPLETED responses for an RFP. Ordering favours complex
 * questions (they tend to carry the most evidence) and then high-confidence
 * answers. Falls back to ANY response state if there are not enough
 * COMPLETED ones — empty responses are filtered out either way.
 */
async function loadTopResponses(rfpId: string, n: number): Promise<LoadedResponse[]> {
  const rows = await prisma.response.findMany({
    where: {
      question: { rfpId },
      content: { not: "" },
    },
    orderBy: { createdAt: "desc" },
    select: {
      content: true,
      questionId: true,
      confidence: true,
      createdAt: true,
      question: {
        select: { id: true, text: true, complexity: true },
      },
    },
  });

  // Collapse to the latest response per question.
  const byQuestion = new Map<string, (typeof rows)[number]>();
  for (const r of rows) {
    if (!byQuestion.has(r.questionId)) byQuestion.set(r.questionId, r);
  }

  const complexityRank: Record<string, number> = { complex: 3, moderate: 2, simple: 1 };

  const all = [...byQuestion.values()]
    .map((r): LoadedResponse & { _conf: number; _rank: number } => ({
      questionId: r.question.id,
      questionText: r.question.text,
      questionComplexity: (r.question.complexity as Complexity | null) ?? null,
      content: r.content,
      _conf: r.confidence ?? 0,
      _rank: complexityRank[r.question.complexity ?? "moderate"] ?? 2,
    }))
    .sort((a, b) => {
      if (a._rank !== b._rank) return b._rank - a._rank;
      return b._conf - a._conf;
    })
    .slice(0, n);

  return all.map(({ _conf: _c, _rank: _r, ...rest }) => {
    void _c;
    void _r;
    return rest;
  });
}

function formatResponsesBlock(responses: LoadedResponse[]): string {
  if (responses.length === 0) {
    return "(no responses available)";
  }
  return responses
    .map((r, i) => {
      const body = r.content.length > MAX_RESPONSE_CHARS
        ? r.content.slice(0, MAX_RESPONSE_CHARS) + " …"
        : r.content;
      return `### Response ${i + 1}\nQuestion: ${r.questionText}\nAnswer: ${body}`;
    })
    .join("\n\n");
}

// --- Per-criterion LLM call ------------------------------------------------

async function scoreOneCriterion(
  criterion: RubricCriterion,
  responsesBlock: string,
  clients: AiClients,
): Promise<CriterionScore> {
  const userPrompt = [
    `CRITERION: ${criterion.label}`,
    `DESCRIPTION: ${criterion.description}`,
    criterion.mustHave ? "GATING: must-have" : "GATING: optional",
    "",
    "RESPONSES:",
    responsesBlock,
  ].join("\n");

  let raw = "{}";
  try {
    const completion = await clients.llm.chat.completions.create({
      model: clients.config.llm.model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: RUBRIC_SCORE_CRITERION_SYSTEM },
        { role: "user", content: userPrompt },
      ],
    });
    raw = completion.choices[0]?.message?.content ?? "{}";
  } catch {
    return {
      criterionId: criterion.id,
      score: 0,
      rationale: "scoring call failed",
      evidence: [],
    };
  }

  return parseCriterionScoreJson(criterion.id, raw);
}

/** Parse the LLM's per-criterion JSON. Exposed for tests. */
export function parseCriterionScoreJson(criterionId: string, raw: string): CriterionScore {
  let parsed: unknown;
  try {
    parsed = JSON.parse(stripCodeFences(raw));
  } catch {
    return { criterionId, score: 0, rationale: "unparseable", evidence: [] };
  }
  if (!parsed || typeof parsed !== "object") {
    return { criterionId, score: 0, rationale: "unparseable", evidence: [] };
  }
  const obj = parsed as Record<string, unknown>;
  const score = clampUnit(typeof obj.score === "number" ? obj.score : 0);
  const rationale = typeof obj.rationale === "string" ? obj.rationale.trim() : "";
  let evidence: string[] = [];
  if (Array.isArray(obj.evidence)) {
    evidence = obj.evidence
      .filter((e): e is string => typeof e === "string")
      .map((e) => e.trim())
      .filter((e) => e.length > 0)
      .slice(0, 3);
  }
  return { criterionId, score, rationale, evidence };
}

function clampUnit(n: number): number {
  if (!Number.isFinite(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}

function round4(n: number): number {
  return Math.round(n * 10000) / 10000;
}
