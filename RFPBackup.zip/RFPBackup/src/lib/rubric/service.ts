// Service layer for the auto-extracted evaluation rubric.
//
// Wraps the pure `extractRubric` and `scoreRubric` functions with database
// persistence on the EvaluationRubric model + metrics + light error handling.
// Routes and pipeline hooks call into here; the pure modules stay
// LLM-input/output-shaped so they're easy to unit test.

import type { EvaluationRubric } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import {
  extractRubric,
  type ExtractedRubric,
  type RubricCriterion,
} from "./extract";
import { scoreRubric, type CriterionScore, type RubricScore } from "./score";
import {
  rubricExtractionsTotal,
  rubricScoresTotal,
  rubricTotalScore,
} from "@/lib/metrics";
import { log } from "@/lib/logger";

/**
 * Extract a rubric from the RFP's rawText and upsert it onto the
 * EvaluationRubric row. Idempotent — re-extracting overwrites criteria and
 * resets scoredAt/totalScore/perCriterionScores because the old scores no
 * longer match the new criterion ids.
 *
 * Throws only on programmer-error conditions (RFP missing). LLM/parser
 * failures surface as an empty-criteria rubric with extractionConfidence
 * 0.1 — callers can still persist that as "we tried, here's nothing".
 */
export async function extractAndPersistRubric(rfpId: string): Promise<EvaluationRubric> {
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    select: {
      id: true,
      rawText: true,
      project: { select: { organizationId: true } },
    },
  });
  if (!rfp) throw new Error("RFP not found");

  const rawText = rfp.rawText ?? "";
  const extracted: ExtractedRubric = await extractRubric({
    rawText,
    organizationId: rfp.project.organizationId,
  });

  // Persist. Re-extraction clears prior scores because criterion ids may
  // have changed and stale per-criterion scores would mislead the UI.
  const row = await prisma.evaluationRubric.upsert({
    where: { rfpId: rfp.id },
    create: {
      rfpId: rfp.id,
      criteria: extracted.criteria as unknown as never,
      extractionConfidence: extracted.extractionConfidence,
      totalScore: null,
      perCriterionScores: undefined,
      scoredAt: null,
    },
    update: {
      criteria: extracted.criteria as unknown as never,
      extractionConfidence: extracted.extractionConfidence,
      totalScore: null,
      perCriterionScores: undefined as unknown as never,
      scoredAt: null,
    },
  });

  try {
    rubricExtractionsTotal.inc({
      org: rfp.project.organizationId,
      has_criteria: extracted.criteria.length > 0 ? "true" : "false",
    });
  } catch {
    // metrics must never break the request path
  }

  log().info(
    {
      rfpId: rfp.id,
      criteriaCount: extracted.criteria.length,
      extractionConfidence: extracted.extractionConfidence,
    },
    "rubric extracted",
  );

  return row;
}

/**
 * Score the in-progress responses against the stored rubric criteria.
 * Persists totalScore, perCriterionScores, scoredAt back onto the row.
 * Throws when the RFP has no rubric — callers should run extraction first.
 */
export async function scoreAndPersistRubric(
  rfpId: string,
  opts: { onProgress?: (s: CriterionScore) => void | Promise<void> } = {},
): Promise<RubricScore> {
  const existing = await prisma.evaluationRubric.findUnique({
    where: { rfpId },
    include: {
      rfp: { select: { project: { select: { organizationId: true } } } },
    },
  });
  if (!existing) {
    throw new Error("Rubric not extracted yet — call extractAndPersistRubric first");
  }

  const criteria = (existing.criteria as unknown as RubricCriterion[]) ?? [];
  const organizationId = existing.rfp.project.organizationId;

  const result = await scoreRubric({
    rfpId,
    rubric: criteria,
    organizationId,
    onProgress: opts.onProgress,
  });

  await prisma.evaluationRubric.update({
    where: { rfpId },
    data: {
      totalScore: result.totalScore,
      perCriterionScores: result.perCriterionScores as unknown as never,
      scoredAt: result.scoredAt,
    },
  });

  try {
    rubricScoresTotal.inc({ org: organizationId });
    rubricTotalScore.observe({ org: organizationId }, result.totalScore);
  } catch {
    // never break on metrics
  }

  log().info(
    {
      rfpId,
      totalScore: result.totalScore,
      criteriaCount: criteria.length,
      weakest: result.weakestCriteria,
    },
    "rubric scored",
  );

  return result;
}

/**
 * Manual override: replace `criteria` on the stored rubric. Used by the
 * Edit-criteria admin modal. Resets scores because old criterion ids may
 * have changed; the caller re-runs scoring afterwards.
 */
export async function overrideRubricCriteria(
  rfpId: string,
  criteria: RubricCriterion[],
): Promise<EvaluationRubric> {
  const existing = await prisma.evaluationRubric.findUnique({ where: { rfpId } });
  if (!existing) {
    // Create one rather than 404 — admins editing a rubric on an RFP that
    // never had one is a legitimate workflow.
    return prisma.evaluationRubric.create({
      data: {
        rfpId,
        criteria: criteria as unknown as never,
        extractionConfidence: 1.0, // human-entered = full confidence
        totalScore: null,
        scoredAt: null,
      },
    });
  }
  return prisma.evaluationRubric.update({
    where: { rfpId },
    data: {
      criteria: criteria as unknown as never,
      extractionConfidence: 1.0,
      totalScore: null,
      perCriterionScores: undefined as unknown as never,
      scoredAt: null,
    },
  });
}
