import { describe, expect, it, vi, beforeEach } from "vitest";

// Mock the Prisma client before importing the module under test so the
// import gets our mocked instance.
vi.mock("./prisma", () => ({
  prisma: {
    auditLog: {
      create: vi.fn(),
    },
  },
}));

import { prisma } from "./prisma";
import { audit, auditContextFromRequest } from "./audit";

type MockedCreate = ReturnType<typeof vi.fn>;
const auditCreate = prisma.auditLog.create as unknown as MockedCreate;

beforeEach(() => {
  auditCreate.mockReset();
});

describe("audit()", () => {
  it("writes a row with the full payload", async () => {
    auditCreate.mockResolvedValueOnce({ id: "row_1" });

    await audit({
      event: "RFP_DELETED",
      actorId: "user_1",
      organizationId: "org_1",
      targetType: "rfp",
      targetId: "rfp_1",
      metadata: { reason: "user requested" },
      ip: "1.2.3.4",
      userAgent: "agent/1.0",
    });

    expect(auditCreate).toHaveBeenCalledTimes(1);
    const arg = auditCreate.mock.calls[0][0];
    expect(arg.data).toMatchObject({
      event: "RFP_DELETED",
      actorId: "user_1",
      organizationId: "org_1",
      targetType: "rfp",
      targetId: "rfp_1",
      ip: "1.2.3.4",
      userAgent: "agent/1.0",
    });
    expect(arg.data.metadata).toEqual({ reason: "user requested" });
  });

  it("defaults optional fields to null when omitted", async () => {
    auditCreate.mockResolvedValueOnce({ id: "row_2" });

    await audit({
      event: "USER_SIGNED_IN",
      actorId: "user_1",
      organizationId: null,
    });

    const arg = auditCreate.mock.calls[0][0];
    expect(arg.data).toMatchObject({
      event: "USER_SIGNED_IN",
      actorId: "user_1",
      organizationId: null,
      targetType: null,
      targetId: null,
      metadata: null,
      ip: null,
      userAgent: null,
    });
  });

  it("swallows DB errors and never throws", async () => {
    auditCreate.mockRejectedValueOnce(new Error("connection refused"));

    // The handler should complete normally even when the DB write fails.
    await expect(
      audit({ event: "ORG_CREATED", actorId: "u", organizationId: "o" }),
    ).resolves.toBeUndefined();
  });

  it("serialises metadata as a plain JSON-safe object", async () => {
    auditCreate.mockResolvedValueOnce({ id: "row_3" });

    const meta = {
      nested: { value: 1 },
      arr: [1, 2, 3],
      bool: true,
      nullField: null,
    };

    await audit({
      event: "API_KEY_SET",
      actorId: "user_1",
      organizationId: "org_1",
      metadata: meta,
    });

    const arg = auditCreate.mock.calls[0][0];
    // Round-trip through JSON to confirm everything is serialisable as-is.
    expect(JSON.parse(JSON.stringify(arg.data.metadata))).toEqual(meta);
  });
});

describe("auditContextFromRequest", () => {
  function mkReq(headers: Record<string, string>): Request {
    return new Request("https://example.com/", { headers });
  }

  it("extracts the first hop of x-forwarded-for", () => {
    const req = mkReq({
      "x-forwarded-for": "203.0.113.7, 10.0.0.1, 10.0.0.2",
      "user-agent": "test-agent/9.9",
    });
    expect(auditContextFromRequest(req)).toEqual({
      ip: "203.0.113.7",
      userAgent: "test-agent/9.9",
    });
  });

  it("falls back to x-real-ip when no x-forwarded-for", () => {
    const req = mkReq({ "x-real-ip": "198.51.100.4" });
    expect(auditContextFromRequest(req)).toEqual({
      ip: "198.51.100.4",
      userAgent: undefined,
    });
  });

  it("returns undefined for missing headers", () => {
    const req = mkReq({});
    expect(auditContextFromRequest(req)).toEqual({
      ip: undefined,
      userAgent: undefined,
    });
  });
});
