import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ApiKeyScope, Role } from "@prisma/client";
import { AuthError, ForbiddenError, NotFoundError } from "./errors";
import { errorResponse } from "./api-handler";
import { authenticateBearer, type BearerSession } from "./auth-bearer";

export async function requireUser() {
  const session = await auth();
  if (!session?.user?.id) throw new AuthError("Not authenticated");
  return session.user;
}

/**
 * Resolved caller — either a session user or an API-key-bound principal.
 * `via === "api-key"` means scope/keyId/organizationId reflect the key, not
 * a Membership row.
 */
export type ResolvedPrincipal =
  | {
      via: "session";
      userId: string;
      organizationId: null;
      scope: ApiKeyScope;
      keyId: null;
    }
  | {
      via: "api-key";
      userId: string;
      organizationId: string | null;
      scope: ApiKeyScope;
      keyId: string;
    };

/**
 * Try Bearer-token auth first; on failure fall back to the session cookie.
 * Throws AuthError if neither produces a principal.
 *
 * Routes that opt in to this helper accept both interactive users and
 * programmatic API key clients. Sessions get an effective scope of ADMIN
 * (they're full users); API keys carry whatever scope they were issued with.
 */
export async function requireUserOrApiKey(
  req: Request,
): Promise<ResolvedPrincipal> {
  const bearer: BearerSession | null = await authenticateBearer(req);
  if (bearer) {
    return {
      via: "api-key",
      userId: bearer.userId,
      organizationId: bearer.organizationId,
      scope: bearer.scope,
      keyId: bearer.keyId,
    };
  }
  const session = await auth();
  if (session?.user?.id) {
    return {
      via: "session",
      userId: session.user.id,
      organizationId: null,
      scope: ApiKeyScope.ADMIN,
      keyId: null,
    };
  }
  throw new AuthError("Not authenticated");
}

/** True if the caller's scope satisfies the required minimum. */
export function hasApiKeyScope(actual: ApiKeyScope, required: ApiKeyScope): boolean {
  const rank: Record<ApiKeyScope, number> = {
    [ApiKeyScope.READ]: 1,
    [ApiKeyScope.WRITE]: 2,
    [ApiKeyScope.ADMIN]: 3,
  };
  return rank[actual] >= rank[required];
}

export async function requireMembership(organizationId: string, minRole: Role = Role.MEMBER) {
  const user = await requireUser();
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId } },
  });
  if (!membership) throw new ForbiddenError("Not a member of this organization");
  if (!hasRole(membership.role, minRole)) throw new ForbiddenError("Insufficient role");
  return { user, membership };
}

export function hasRole(actual: Role, required: Role): boolean {
  const rank: Record<Role, number> = { OWNER: 3, ADMIN: 2, MEMBER: 1 };
  return rank[actual] >= rank[required];
}

export async function requireProjectAccess(projectId: string, minRole: Role = Role.MEMBER) {
  const user = await requireUser();
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: { organization: true },
  });
  if (!project) throw new NotFoundError("Project not found");
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: project.organizationId } },
  });
  if (!membership || !hasRole(membership.role, minRole)) throw new ForbiddenError("Forbidden");
  return { user, project, membership };
}

export async function requireRfpAccess(rfpId: string, minRole: Role = Role.MEMBER) {
  const user = await requireUser();
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: { project: true },
  });
  if (!rfp) throw new NotFoundError("RFP not found");
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: rfp.project.organizationId } },
  });
  if (!membership || !hasRole(membership.role, minRole)) throw new ForbiddenError("Forbidden");
  return { user, rfp, membership };
}

export async function requireIndexAccess(indexId: string, minRole: Role = Role.MEMBER) {
  const user = await requireUser();
  const index = await prisma.knowledgeIndex.findUnique({ where: { id: indexId } });
  if (!index) throw new NotFoundError("Index not found");
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: index.organizationId } },
  });
  if (!membership || !hasRole(membership.role, minRole)) throw new ForbiddenError("Forbidden");
  return { user, index, membership };
}

/**
 * Resolve RFP access for a caller that may be a session user OR a Bearer
 * token. Enforces the supplied minimum scope for API keys; sessions are
 * always considered ADMIN-equivalent (they're full users). Membership is
 * still checked: a key bound to a different org cannot read another org's
 * RFP. Returns the same shape as `requireRfpAccess` plus `principal`.
 */
export async function requireRfpAccessForRequest(
  req: Request,
  rfpId: string,
  opts: { minScope?: ApiKeyScope; minRole?: Role } = {},
) {
  const minScope = opts.minScope ?? ApiKeyScope.READ;
  const minRole = opts.minRole ?? Role.MEMBER;
  const principal = await requireUserOrApiKey(req);
  if (!hasApiKeyScope(principal.scope, minScope)) {
    throw new ForbiddenError("API key scope insufficient");
  }
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: { project: true },
  });
  if (!rfp) throw new NotFoundError("RFP not found");

  // If the key was bound to a specific org, refuse cross-org access early.
  if (
    principal.via === "api-key" &&
    principal.organizationId &&
    principal.organizationId !== rfp.project.organizationId
  ) {
    throw new ForbiddenError("API key not bound to this organization");
  }

  const membership = await prisma.membership.findUnique({
    where: {
      userId_organizationId: {
        userId: principal.userId,
        organizationId: rfp.project.organizationId,
      },
    },
  });
  if (!membership || !hasRole(membership.role, minRole)) {
    throw new ForbiddenError("Forbidden");
  }
  return { rfp, membership, principal };
}

/**
 * Resolve KnowledgeIndex access for a caller that may be a session user OR a
 * Bearer token. Mirrors `requireRfpAccessForRequest` for indexes — used by the
 * external ingest API so NiFi/Airflow/n8n can push to a specific index without
 * touching the cookie session. Enforces minimum scope for API keys; sessions
 * are always considered ADMIN. Org-bound keys can't reach another org's index.
 */
export async function requireIndexAccessForRequest(
  req: Request,
  indexId: string,
  opts: { minScope?: ApiKeyScope; minRole?: Role } = {},
) {
  const minScope = opts.minScope ?? ApiKeyScope.READ;
  const minRole = opts.minRole ?? Role.MEMBER;
  const principal = await requireUserOrApiKey(req);
  if (!hasApiKeyScope(principal.scope, minScope)) {
    throw new ForbiddenError("API key scope insufficient");
  }
  const index = await prisma.knowledgeIndex.findUnique({ where: { id: indexId } });
  if (!index) throw new NotFoundError("Index not found");

  if (
    principal.via === "api-key" &&
    principal.organizationId &&
    principal.organizationId !== index.organizationId
  ) {
    throw new ForbiddenError("API key not bound to this organization");
  }

  const membership = await prisma.membership.findUnique({
    where: {
      userId_organizationId: {
        userId: principal.userId,
        organizationId: index.organizationId,
      },
    },
  });
  if (!membership || !hasRole(membership.role, minRole)) {
    throw new ForbiddenError("Forbidden");
  }
  return { index, membership, principal };
}

/** Back-compat: the old jsonError helper. New code should use withApiHandler. */
export const jsonError = errorResponse;

// Re-export for back-compat with files that imported AuthError from here.
export { AuthError } from "./errors";
