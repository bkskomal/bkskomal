"use server";

import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { ACTIVE_ORG_COOKIE } from "@/lib/dashboard";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/authz";

export async function setActiveOrg(orgId: string) {
  const user = await requireUser();
  // Verify the user is a member of that org before persisting.
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
  });
  if (!membership) throw new Error("Not a member of that organization");

  const c = await cookies();
  c.set(ACTIVE_ORG_COOKIE, orgId, {
    httpOnly: false, // readable client-side for UI consistency
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
  revalidatePath("/dashboard", "layout");
}
