// Pipeline engine. Two responsibilities:
//   1. Create a PipelineRun for an RFP (using the org's default template).
//   2. Advance an existing run — re-evaluate the current step, kick off any
//      auto work, transition state.
//
// `advance()` is idempotent and fast — call it from event hooks freely.

import { prisma } from "@/lib/prisma";
import {
  PipelineRunStatus,
  PipelineStepStatus,
  PipelineStepMode,
  type PipelineStepRun,
  type PipelineRun,
} from "@prisma/client";
import { DEFAULT_PIPELINE, type StepDefinition } from "./catalog";
import { getHandler, type StepHandlerResult } from "./handlers";
import { ConflictError, NotFoundError, ValidationError } from "@/lib/errors";
import { pipelineStepsTotal } from "@/lib/metrics";

const ENGINE_TAG = "[pipeline]";

// ---- template management ----

export async function ensureDefaultTemplate(organizationId: string) {
  const existing = await prisma.pipelineTemplate.findFirst({
    where: { organizationId, isDefault: true },
  });
  if (existing) return existing;
  return prisma.pipelineTemplate.create({
    data: {
      organizationId,
      name: "Default RFP Workflow",
      description: "Standard 9-step RFP response workflow.",
      isDefault: true,
      steps: DEFAULT_PIPELINE as never,
    },
  });
}

// ---- run lifecycle ----

/**
 * Create the PipelineRun + child PipelineStepRuns for an RFP. Safe to call
 * twice — returns the existing run if one is already attached to the RFP.
 *
 * Resolution order for which template to use:
 *   1. The project's defaultPipelineTemplateId (if set and still valid)
 *   2. The org's default template
 *   3. ensureDefaultTemplate() — creates one from the catalog
 */
export async function createRunForRfp(rfpId: string): Promise<PipelineRun> {
  const existing = await prisma.pipelineRun.findUnique({ where: { rfpId } });
  if (existing) return existing;

  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: { project: { select: { organizationId: true, defaultPipelineTemplateId: true } } },
  });
  if (!rfp) throw new Error(`RFP ${rfpId} not found`);

  let template = null;
  if (rfp.project.defaultPipelineTemplateId) {
    template = await prisma.pipelineTemplate.findFirst({
      where: {
        id: rfp.project.defaultPipelineTemplateId,
        organizationId: rfp.project.organizationId,
      },
    });
  }
  if (!template) template = await ensureDefaultTemplate(rfp.project.organizationId);

  const stepDefs = (template.steps as unknown as StepDefinition[]) ?? DEFAULT_PIPELINE;

  const run = await prisma.pipelineRun.create({
    data: {
      templateId: template.id,
      rfpId,
      status: "PENDING",
      currentStepIndex: 0,
      steps: {
        create: stepDefs.map((s, i) => ({
          index: i,
          kind: s.kind,
          label: s.label,
          description: s.description ?? null,
          mode: s.mode,
          status: "PENDING",
          config: (s.config as never) ?? undefined,
        })),
      },
    },
  });

  // Kick off the first step right away.
  void advance(rfpId);
  return run;
}

// ---- advance ----

/**
 * Re-evaluate the current step's state and transition the run forward where
 * possible. Safe to call repeatedly. No-ops if the run is already done.
 */
export async function advance(rfpId: string): Promise<void> {
  try {
    await advanceInner(rfpId);
  } catch (e) {
    console.error(ENGINE_TAG, "advance failed", e);
  }
}

async function advanceInner(rfpId: string): Promise<void> {
  const run = await prisma.pipelineRun.findUnique({
    where: { rfpId },
    include: {
      steps: { orderBy: { index: "asc" } },
      rfp: true,
    },
  });
  if (!run) return;
  if (run.status === "SUCCEEDED" || run.status === "CANCELLED") return;
  // Pause / stop are explicit user holds — never advance through them.
  if (run.status === "PAUSED" || run.status === "STOPPED") return;

  // Find the first step that's not yet finished.
  let cursor = run.steps.findIndex(
    (s) => s.status === "PENDING" || s.status === "RUNNING" || s.status === "WAITING_FOR_INPUT",
  );
  if (cursor === -1) {
    // Everything is done — mark run succeeded.
    await prisma.pipelineRun.update({
      where: { id: run.id },
      data: {
        status: "SUCCEEDED",
        finishedAt: new Date(),
        currentStepIndex: run.steps.length - 1,
      },
    });
    return;
  }

  // Walk forward as far as possible — successive auto/marker steps may all
  // resolve in one pass.
  while (cursor < run.steps.length) {
    const step = run.steps[cursor];
    if (step.status === "SUCCEEDED" || step.status === "SKIPPED") {
      cursor++;
      continue;
    }

    // Trigger auto work for steps that need an external action to start.
    await triggerAutoAction(step, run.rfp);

    // Re-fetch the step in case the trigger updated state.
    const fresh = await prisma.pipelineStepRun.findUnique({ where: { id: step.id } });
    if (!fresh) return;

    const handler = getHandler(fresh.kind);
    if (!handler) {
      await markStep(fresh.id, "FAILED", { errorMessage: `No handler for step kind ${fresh.kind}` });
      await markRun(run.id, "FAILED", cursor);
      return;
    }

    let outcome: StepHandlerResult;
    try {
      outcome = await handler({ step: fresh, rfp: run.rfp });
    } catch (e) {
      outcome = { status: "FAILED", error: e instanceof Error ? e.message : String(e) };
    }

    await applyOutcome(fresh, outcome);

    if (outcome.status === "SUCCEEDED") {
      cursor++;
      continue;
    }
    if (outcome.status === "FAILED") {
      await markRun(run.id, "FAILED", cursor);
      return;
    }
    if (outcome.status === "RUNNING") {
      await markRun(run.id, "RUNNING", cursor);
      return;
    }
    if (outcome.status === "WAITING_FOR_INPUT") {
      await markRun(run.id, "WAITING_FOR_INPUT", cursor);
      return;
    }
  }

  // Walked to the end successfully.
  await markRun(run.id, "SUCCEEDED", run.steps.length - 1);
}

// ---- side-effect triggers ----

/**
 * For steps that need to *start* something (bulk gen, export, etc.), kick it
 * off here. Idempotent — handlers below check for in-flight state.
 */
async function triggerAutoAction(step: PipelineStepRun, rfp: { id: string; projectId: string }) {
  if (step.status !== "PENDING") return;

  if (step.kind === "GENERATE_RESPONSES" && step.mode === "AUTO") {
    const existing = await prisma.bulkGeneration.findFirst({
      where: { rfpId: rfp.id, status: { in: ["PENDING", "RUNNING"] } },
    });
    if (existing) return;
    const cfg = (step.config as Record<string, unknown> | null) ?? {};
    const mode = (cfg.mode as string) ?? "unanswered";
    await startBulkForStep(rfp.id, mode);
  }

  if (step.kind === "CONSOLIDATE_EXPORT" && step.mode === "AUTO") {
    const cfg = (step.config as Record<string, unknown> | null) ?? {};
    await runExportForStep(rfp.id, cfg);
  }

  if (step.kind === "MINE_TO_KB" && step.mode === "AUTO") {
    await runMineForStep(rfp.id);
  }
}

async function startBulkForStep(rfpId: string, mode: string) {
  // Inline start so we don't have to round-trip through HTTP.
  const { runBulkGeneration } = await import("@/lib/ai/bulk-generate");
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: { project: { select: { defaultIndexId: true, organizationId: true } } },
  });
  if (!rfp) return;

  const all = await prisma.question.findMany({
    where: { rfpId },
    select: { id: true, responses: { select: { status: true }, orderBy: { createdAt: "desc" }, take: 1 } },
  });
  const ids =
    mode === "all"
      ? all.map((q) => q.id)
      : all
          .filter((q) => q.responses.length === 0 || q.responses[0]?.status !== "COMPLETED")
          .map((q) => q.id);
  if (ids.length === 0) return;

  // Need a started-by; use the most recent activity actor on the RFP, or
  // an org owner as fallback.
  const ev = await prisma.activityEvent.findFirst({
    where: { rfpId, actorId: { not: null } },
    orderBy: { createdAt: "desc" },
    select: { actorId: true },
  });
  let userId = ev?.actorId ?? null;
  if (!userId) {
    const owner = await prisma.membership.findFirst({
      where: { organizationId: rfp.project.organizationId, role: "OWNER" },
      select: { userId: true },
    });
    userId = owner?.userId ?? null;
  }
  if (!userId) return;

  const bulk = await prisma.bulkGeneration.create({
    data: {
      rfpId,
      startedById: userId,
      questionIds: ids,
      indexId: rfp.project.defaultIndexId,
      enableTools: true,
      total: ids.length,
    },
  });
  void runBulkGeneration({ bulkId: bulk.id }).then(() => advance(rfpId));
}

async function runExportForStep(rfpId: string, cfg: Record<string, unknown>) {
  const { exportRfpToWord } = await import("@/lib/export/word");
  const { logActivity } = await import("@/lib/activity");
  try {
    const approvedOnly = cfg.approvedOnly === true;
    const includeSources = cfg.includeSources !== false;
    const { buffer, filename } = await exportRfpToWord(rfpId, { approvedOnly, includeSources });
    await logActivity({
      rfpId,
      actorId: null,
      kind: "EXPORT_GENERATED",
      payload: { format: "docx", approvedOnly, includeSources, byteSize: buffer.length, filename, automated: true },
    });
  } catch (e) {
    console.error(ENGINE_TAG, "auto export failed", e);
  }
}

async function runMineForStep(rfpId: string) {
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: { project: { select: { defaultIndexId: true } } },
  });
  if (!rfp || !rfp.project.defaultIndexId) return;
  try {
    const { mineRfpToIndex } = await import("@/lib/rfp-mining");
    await mineRfpToIndex(rfpId, rfp.project.defaultIndexId, { approvedOnly: true });
  } catch (e) {
    console.error(ENGINE_TAG, "auto mine failed", e);
  }
}

// ---- writes ----

async function applyOutcome(step: PipelineStepRun, outcome: StepHandlerResult) {
  const status = outcomeStatus(outcome);
  const data: Record<string, unknown> = { status };
  if (outcome.status === "SUCCEEDED") {
    data.result = (outcome.result as never) ?? null;
    data.errorMessage = null;
    data.blockedReason = null;
    data.progressDetail = null;
    data.finishedAt = new Date();
    if (!step.startedAt) data.startedAt = new Date();
  } else if (outcome.status === "FAILED") {
    data.errorMessage = outcome.error;
    // Bug fix: clear the live-progress + waiting text on terminal states so
    // the UI doesn't show stale "retrying…" copy alongside the FAILED badge.
    data.blockedReason = null;
    data.progressDetail = null;
    data.finishedAt = new Date();
    if (!step.startedAt) data.startedAt = new Date();
  } else if (outcome.status === "WAITING_FOR_INPUT") {
    // blockedReason is now SPECIFICALLY "why we're waiting on a human action".
    data.blockedReason = outcome.reason;
    data.progressDetail = null;
    if (!step.startedAt) data.startedAt = new Date();
  } else if (outcome.status === "RUNNING") {
    // progressDetail is the live "what is the engine doing right now" text.
    // Shown inside the step card with a marching border so users can watch
    // it tick. Per-handler setStepProgress() writes finer-grained updates
    // (e.g. "Extracted 12/24 questions") while the engine is between polls.
    data.progressDetail = outcome.reason ?? null;
    data.blockedReason = null;
    if (!step.startedAt) data.startedAt = new Date();
  }
  await prisma.pipelineStepRun.update({ where: { id: step.id }, data: data as never });
  if (status !== step.status) pipelineStepsTotal.inc({ kind: step.kind, status });
}

/**
 * Public helper for handlers (and code they call into, like processRfp) to
 * write live progress text into a step's `progressDetail` while the step is
 * RUNNING. Best-effort — failures are swallowed so a transient DB hiccup
 * never blows up the actual work.
 */
export async function setStepProgress(stepId: string, text: string | null): Promise<void> {
  try {
    await prisma.pipelineStepRun.update({
      where: { id: stepId },
      data: { progressDetail: text } as never,
    });
  } catch {
    // never let progress UI fail real work
  }
}

function outcomeStatus(o: StepHandlerResult): PipelineStepStatus {
  if (o.status === "SUCCEEDED") return "SUCCEEDED";
  if (o.status === "FAILED") return "FAILED";
  if (o.status === "WAITING_FOR_INPUT") return "WAITING_FOR_INPUT";
  return "RUNNING";
}

async function markStep(stepId: string, status: PipelineStepStatus, extra: Record<string, unknown> = {}) {
  const before = await prisma.pipelineStepRun.findUnique({ where: { id: stepId }, select: { kind: true, status: true } });
  await prisma.pipelineStepRun.update({
    where: { id: stepId },
    data: { status, ...extra } as never,
  });
  if (before && before.status !== status) pipelineStepsTotal.inc({ kind: before.kind, status });
}

async function markRun(runId: string, status: PipelineRunStatus, currentStepIndex: number) {
  await prisma.pipelineRun.update({
    where: { id: runId },
    data: {
      status,
      currentStepIndex,
      ...(status === "SUCCEEDED" || status === "FAILED" || status === "CANCELLED"
        ? { finishedAt: new Date() }
        : {}),
    },
  });
  // Set startedAt the first time the run leaves PENDING.
  if (status !== "PENDING") {
    await prisma.pipelineRun.updateMany({
      where: { id: runId, startedAt: null },
      data: { startedAt: new Date() },
    });
  }
}

// ---- user actions ----

export async function markStepComplete(stepId: string, note?: string) {
  const step = await prisma.pipelineStepRun.findUnique({
    where: { id: stepId },
    include: { run: { include: { rfp: true } } },
  });
  if (!step) throw new Error("Step not found");
  await prisma.pipelineStepRun.update({
    where: { id: stepId },
    data: {
      status: "SUCCEEDED",
      result: { manuallyCompleted: true, note: note ?? null } as never,
      finishedAt: new Date(),
      blockedReason: null,
    },
  });
  if (step.status !== "SUCCEEDED") pipelineStepsTotal.inc({ kind: step.kind, status: "SUCCEEDED" });
  await advance(step.run.rfpId);
}

export async function skipStep(stepId: string) {
  const step = await prisma.pipelineStepRun.findUnique({
    where: { id: stepId },
    include: { run: true },
  });
  if (!step) throw new Error("Step not found");
  await prisma.pipelineStepRun.update({
    where: { id: stepId },
    data: { status: "SKIPPED", finishedAt: new Date(), blockedReason: null },
  });
  if (step.status !== "SKIPPED") pipelineStepsTotal.inc({ kind: step.kind, status: "SKIPPED" });
  await advance(step.run.rfpId);
}

export async function retryStep(stepId: string) {
  const step = await prisma.pipelineStepRun.findUnique({
    where: { id: stepId },
    include: { run: true },
  });
  if (!step) throw new Error("Step not found");
  await prisma.pipelineStepRun.update({
    where: { id: stepId },
    data: {
      status: "PENDING",
      errorMessage: null,
      blockedReason: null,
      result: undefined,
      finishedAt: null,
    },
  });
  if (step.status !== "PENDING") pipelineStepsTotal.inc({ kind: step.kind, status: "PENDING" });
  await advance(step.run.rfpId);
}

export async function decideStep(stepId: string, config: Record<string, unknown>) {
  const step = await prisma.pipelineStepRun.findUnique({
    where: { id: stepId },
    include: { run: true },
  });
  if (!step) throw new Error("Step not found");

  // Merge the user's decision into the step config, then drop back to AUTO so
  // the engine picks it up in the next advance() pass.
  const merged = { ...((step.config as Record<string, unknown> | null) ?? {}), ...config };
  await prisma.pipelineStepRun.update({
    where: { id: stepId },
    data: { config: merged as never, mode: "AUTO", status: "PENDING", blockedReason: null },
  });
  await advance(step.run.rfpId);
}

// ---- pause / stop / resume / edit-while-paused ----

/**
 * Pause an in-flight run. Only valid from RUNNING or WAITING_FOR_INPUT —
 * pausing a finished/failed/cancelled run is a no-op error so the caller
 * notices the wrong button was wired up.
 */
export async function pauseRun(rfpId: string, userId: string, reason?: string): Promise<void> {
  const run = await prisma.pipelineRun.findUnique({ where: { rfpId } });
  if (!run) throw new NotFoundError("Pipeline run not found");
  if (run.status !== "RUNNING" && run.status !== "WAITING_FOR_INPUT") {
    throw new ConflictError(`Cannot pause a ${run.status.toLowerCase()} run`);
  }
  await prisma.pipelineRun.update({
    where: { id: run.id },
    data: {
      status: "PAUSED",
      pausedAt: new Date(),
      pausedById: userId,
      pausedReason: reason ?? null,
    },
  });
}

/**
 * Stop a run permanently. Terminal — no resume after this. The current step
 * (if any was in flight) is marked CANCELLED so observers can tell the
 * difference between "user stopped at step 3" vs "step 3 still pending".
 */
export async function stopRun(rfpId: string, userId: string, reason?: string): Promise<void> {
  const run = await prisma.pipelineRun.findUnique({
    where: { rfpId },
    include: { steps: { orderBy: { index: "asc" } } },
  });
  if (!run) throw new NotFoundError("Pipeline run not found");
  if (run.status === "SUCCEEDED" || run.status === "FAILED" || run.status === "CANCELLED" || run.status === "STOPPED") {
    throw new ConflictError(`Cannot stop a ${run.status.toLowerCase()} run`);
  }

  const current = run.steps[run.currentStepIndex];
  await prisma.$transaction(async (tx) => {
    await tx.pipelineRun.update({
      where: { id: run.id },
      data: {
        status: "STOPPED",
        finishedAt: new Date(),
        // Preserve who stopped + why in the same fields used for pause —
        // they read naturally as "stopped by ..." in the UI too.
        pausedAt: new Date(),
        pausedById: userId,
        pausedReason: reason ?? null,
      },
    });
    if (current && (current.status === "RUNNING" || current.status === "WAITING_FOR_INPUT" || current.status === "PENDING")) {
      await tx.pipelineStepRun.update({
        where: { id: current.id },
        data: { status: "CANCELLED", finishedAt: new Date(), blockedReason: null },
      });
    }
  });
}

/**
 * Resume a paused run. Clears the pause-tracking fields, flips back to
 * RUNNING, and re-enters advance() to pick up wherever we left off.
 */
export async function resumeRun(rfpId: string): Promise<void> {
  const run = await prisma.pipelineRun.findUnique({ where: { rfpId } });
  if (!run) throw new NotFoundError("Pipeline run not found");
  if (run.status !== "PAUSED") {
    throw new ConflictError(`Cannot resume a ${run.status.toLowerCase()} run`);
  }
  await prisma.pipelineRun.update({
    where: { id: run.id },
    data: {
      status: "RUNNING",
      pausedAt: null,
      pausedById: null,
      pausedReason: null,
    },
  });
  await advance(rfpId);
}

export interface PipelineStepEdit {
  index: number;
  label?: string;
  mode?: PipelineStepMode;
  config?: unknown;
  action?: "skip" | "reset";
}

/**
 * Edit the remaining steps of a paused run. Allows users to tweak labels,
 * modes and configs, skip steps, or reset already-completed/failed steps so
 * they re-execute on resume.
 *
 * Steps before the current cursor are immutable unless the action is
 * explicitly "reset" — otherwise we'd silently rewrite history.
 */
export async function editRunSteps(rfpId: string, edits: PipelineStepEdit[]): Promise<void> {
  if (!Array.isArray(edits) || edits.length === 0) return;

  const run = await prisma.pipelineRun.findUnique({
    where: { rfpId },
    include: { steps: { orderBy: { index: "asc" } } },
  });
  if (!run) throw new NotFoundError("Pipeline run not found");
  if (run.status !== "PAUSED") {
    throw new ConflictError("Run must be paused to edit its steps");
  }

  const stepsByIndex = new Map(run.steps.map((s) => [s.index, s]));

  // Pre-validate the whole batch before mutating anything.
  for (const edit of edits) {
    const step = stepsByIndex.get(edit.index);
    if (!step) {
      throw new ValidationError(`No step at index ${edit.index} on this run`);
    }
    const isReset = edit.action === "reset";
    if (edit.index < run.currentStepIndex && !isReset) {
      throw new ValidationError(
        `Step ${edit.index} is before the current cursor; only "reset" is allowed`,
      );
    }
    if (isReset && step.status !== "SUCCEEDED" && step.status !== "FAILED" && step.status !== "SKIPPED" && step.status !== "CANCELLED") {
      throw new ValidationError(
        `Step ${edit.index} cannot be reset (status ${step.status})`,
      );
    }
  }

  await prisma.$transaction(async (tx) => {
    for (const edit of edits) {
      const data: Record<string, unknown> = {};
      if (edit.label !== undefined) data.label = edit.label;
      if (edit.mode !== undefined) data.mode = edit.mode;
      if (edit.config !== undefined) data.config = edit.config as never;

      if (edit.action === "skip") {
        data.status = "SKIPPED";
        data.finishedAt = new Date();
        data.blockedReason = null;
      } else if (edit.action === "reset") {
        data.status = "PENDING";
        data.errorMessage = null;
        data.blockedReason = null;
        data.result = null;
        data.startedAt = null;
        data.finishedAt = null;
      }

      const step = stepsByIndex.get(edit.index)!;
      await tx.pipelineStepRun.update({
        where: { id: step.id },
        data: data as never,
      });
    }
  });
}
