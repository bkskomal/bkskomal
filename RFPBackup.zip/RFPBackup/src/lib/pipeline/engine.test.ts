import { describe, expect, it, vi, beforeEach } from "vitest";

// Mock prisma BEFORE importing the engine, the same way audit.test.ts does.
// Each model only declares the methods the engine actually touches.
vi.mock("@/lib/prisma", () => ({
  prisma: {
    pipelineRun: {
      findUnique: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
      create: vi.fn(),
    },
    pipelineStepRun: {
      findUnique: vi.fn(),
      update: vi.fn(),
    },
    pipelineTemplate: {
      findFirst: vi.fn(),
      create: vi.fn(),
    },
    rFP: { findUnique: vi.fn() },
    bulkGeneration: { findFirst: vi.fn(), create: vi.fn() },
    activityEvent: { findFirst: vi.fn() },
    membership: { findFirst: vi.fn() },
    // $transaction(fn) — call the callback with `prisma` itself so per-model
    // updates inside transactions hit the same mocks the rest of the test
    // inspects.
    $transaction: vi.fn(async (fn: (tx: unknown) => Promise<unknown>) => fn(mockTx())),
  },
}));

// Metrics is imported at the top of engine.ts but never required for the
// behaviour under test — stub it to a no-op so we don't load the real module.
vi.mock("@/lib/metrics", () => ({
  pipelineStepsTotal: { inc: vi.fn() },
}));

import { prisma } from "@/lib/prisma";
import {
  pauseRun,
  resumeRun,
  stopRun,
  editRunSteps,
  advance,
} from "./engine";

type Mock = ReturnType<typeof vi.fn>;
const runFind = prisma.pipelineRun.findUnique as unknown as Mock;
const runUpdate = prisma.pipelineRun.update as unknown as Mock;
const runUpdateMany = prisma.pipelineRun.updateMany as unknown as Mock;
const stepUpdate = prisma.pipelineStepRun.update as unknown as Mock;
const stepFind = prisma.pipelineStepRun.findUnique as unknown as Mock;
const txFn = prisma.$transaction as unknown as Mock;

function mockTx() {
  // Return an object that proxies pipelineRun/pipelineStepRun back to the
  // outer prisma mocks so callers inside a transaction record onto the same
  // spies the test asserts against.
  return {
    pipelineRun: { update: runUpdate },
    pipelineStepRun: { update: stepUpdate },
  };
}

const RFP_ID = "rfp_1";
const RUN_ID = "run_1";
const USER_ID = "user_1";

function makeStep(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: `step_${overrides.index ?? 0}`,
    runId: RUN_ID,
    index: 0,
    kind: "EXTRACT_QUESTIONS",
    label: "Extract",
    description: null,
    mode: "AUTO",
    status: "PENDING",
    config: null,
    result: null,
    errorMessage: null,
    blockedReason: null,
    startedAt: null,
    finishedAt: null,
    ...overrides,
  };
}

function makeRun(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: RUN_ID,
    rfpId: RFP_ID,
    templateId: "tpl_1",
    status: "RUNNING",
    currentStepIndex: 0,
    startedAt: new Date(),
    finishedAt: null,
    pausedAt: null,
    pausedById: null,
    pausedReason: null,
    ...overrides,
  };
}

beforeEach(() => {
  runFind.mockReset();
  runUpdate.mockReset();
  runUpdateMany.mockReset();
  stepFind.mockReset();
  stepUpdate.mockReset();
  txFn.mockReset();
  // Restore default $transaction passthrough.
  txFn.mockImplementation(async (fn: (tx: unknown) => Promise<unknown>) => fn(mockTx()));
});

describe("pauseRun", () => {
  it("transitions a RUNNING run to PAUSED with who/when/why", async () => {
    runFind.mockResolvedValueOnce(makeRun({ status: "RUNNING" }));
    runUpdate.mockResolvedValueOnce({});

    await pauseRun(RFP_ID, USER_ID, "Need to review");

    expect(runUpdate).toHaveBeenCalledTimes(1);
    const data = runUpdate.mock.calls[0][0].data;
    expect(data.status).toBe("PAUSED");
    expect(data.pausedById).toBe(USER_ID);
    expect(data.pausedReason).toBe("Need to review");
    expect(data.pausedAt).toBeInstanceOf(Date);
  });

  it("works from WAITING_FOR_INPUT too", async () => {
    runFind.mockResolvedValueOnce(makeRun({ status: "WAITING_FOR_INPUT" }));
    runUpdate.mockResolvedValueOnce({});
    await pauseRun(RFP_ID, USER_ID);
    expect(runUpdate).toHaveBeenCalled();
  });

  it.each(["SUCCEEDED", "FAILED", "STOPPED", "PAUSED", "PENDING", "CANCELLED"])(
    "rejects when status=%s",
    async (status) => {
      runFind.mockResolvedValueOnce(makeRun({ status }));
      await expect(pauseRun(RFP_ID, USER_ID)).rejects.toThrow(/cannot pause/i);
      expect(runUpdate).not.toHaveBeenCalled();
    },
  );

  it("rejects when the run does not exist", async () => {
    runFind.mockResolvedValueOnce(null);
    await expect(pauseRun(RFP_ID, USER_ID)).rejects.toThrow(/not found/i);
  });
});

describe("advance() guard", () => {
  it("early-returns without writing anything when run is PAUSED", async () => {
    runFind.mockResolvedValueOnce({ ...makeRun({ status: "PAUSED" }), steps: [], rfp: { id: RFP_ID, projectId: "proj_1" } });
    await advance(RFP_ID);
    expect(runUpdate).not.toHaveBeenCalled();
    expect(stepUpdate).not.toHaveBeenCalled();
  });

  it("early-returns without writing anything when run is STOPPED", async () => {
    runFind.mockResolvedValueOnce({ ...makeRun({ status: "STOPPED" }), steps: [], rfp: { id: RFP_ID, projectId: "proj_1" } });
    await advance(RFP_ID);
    expect(runUpdate).not.toHaveBeenCalled();
    expect(stepUpdate).not.toHaveBeenCalled();
  });
});

describe("resumeRun", () => {
  it("clears pause fields, flips to RUNNING, and re-enters advance()", async () => {
    // First findUnique: resumeRun's own status check (no `steps` include).
    runFind.mockResolvedValueOnce(makeRun({ status: "PAUSED", pausedById: USER_ID, pausedAt: new Date(), pausedReason: "x" }));
    runUpdate.mockResolvedValueOnce({});
    // Second findUnique: advance() reads the run again with steps.
    runFind.mockResolvedValueOnce({
      ...makeRun({ status: "RUNNING" }),
      steps: [makeStep({ status: "SUCCEEDED" })],
      rfp: { id: RFP_ID, projectId: "proj_1" },
    });
    runUpdate.mockResolvedValueOnce({}); // the run-completion update inside advance
    runUpdateMany.mockResolvedValueOnce({});

    await resumeRun(RFP_ID);

    expect(runUpdate).toHaveBeenCalled();
    const firstUpdate = runUpdate.mock.calls[0][0].data;
    expect(firstUpdate.status).toBe("RUNNING");
    expect(firstUpdate.pausedAt).toBeNull();
    expect(firstUpdate.pausedById).toBeNull();
    expect(firstUpdate.pausedReason).toBeNull();
    // advance was entered (runFind called twice).
    expect(runFind).toHaveBeenCalledTimes(2);
  });

  it("rejects when not paused", async () => {
    runFind.mockResolvedValueOnce(makeRun({ status: "RUNNING" }));
    await expect(resumeRun(RFP_ID)).rejects.toThrow(/cannot resume/i);
    expect(runUpdate).not.toHaveBeenCalled();
  });
});

describe("stopRun", () => {
  it("sets STOPPED + cancels the current step", async () => {
    const current = makeStep({ index: 0, status: "RUNNING" });
    runFind.mockResolvedValueOnce({
      ...makeRun({ status: "RUNNING", currentStepIndex: 0 }),
      steps: [current, makeStep({ index: 1 })],
    });

    await stopRun(RFP_ID, USER_ID, "user requested");

    expect(txFn).toHaveBeenCalled();
    expect(runUpdate).toHaveBeenCalled();
    const runData = runUpdate.mock.calls[0][0].data;
    expect(runData.status).toBe("STOPPED");
    expect(runData.pausedById).toBe(USER_ID);
    expect(runData.pausedReason).toBe("user requested");
    expect(runData.finishedAt).toBeInstanceOf(Date);

    expect(stepUpdate).toHaveBeenCalled();
    expect(stepUpdate.mock.calls[0][0].data.status).toBe("CANCELLED");
  });

  it("is terminal — subsequent resume rejects", async () => {
    // First we stop a paused run...
    const paused = makeRun({ status: "PAUSED", currentStepIndex: 0 });
    runFind.mockResolvedValueOnce({ ...paused, steps: [makeStep({ status: "PENDING" })] });
    await stopRun(RFP_ID, USER_ID);

    // ...then attempting to resume reads back STOPPED and bounces.
    runFind.mockResolvedValueOnce(makeRun({ status: "STOPPED" }));
    await expect(resumeRun(RFP_ID)).rejects.toThrow(/cannot resume/i);
  });

  it("rejects on already-terminal runs", async () => {
    runFind.mockResolvedValueOnce({ ...makeRun({ status: "SUCCEEDED" }), steps: [] });
    await expect(stopRun(RFP_ID, USER_ID)).rejects.toThrow(/cannot stop/i);
  });
});

describe("editRunSteps", () => {
  it("rejects when run is not paused", async () => {
    runFind.mockResolvedValueOnce({ ...makeRun({ status: "RUNNING" }), steps: [makeStep()] });
    await expect(editRunSteps(RFP_ID, [{ index: 0, label: "x" }])).rejects.toThrow(/must be paused/i);
    expect(stepUpdate).not.toHaveBeenCalled();
  });

  it("skip + reset round-trip on a paused run", async () => {
    const steps = [
      makeStep({ index: 0, status: "SUCCEEDED" }),
      makeStep({ index: 1, status: "PENDING" }),
      makeStep({ index: 2, status: "PENDING" }),
    ];
    runFind.mockResolvedValueOnce({
      ...makeRun({ status: "PAUSED", currentStepIndex: 1 }),
      steps,
    });

    await editRunSteps(RFP_ID, [
      { index: 0, action: "reset" },
      { index: 1, action: "skip" },
      { index: 2, label: "Renamed", config: { foo: "bar" } },
    ]);

    expect(stepUpdate).toHaveBeenCalledTimes(3);
    const calls = stepUpdate.mock.calls.map((c) => c[0]);

    // reset on step 0
    expect(calls[0].where).toEqual({ id: "step_0" });
    expect(calls[0].data.status).toBe("PENDING");
    expect(calls[0].data.errorMessage).toBeNull();
    expect(calls[0].data.startedAt).toBeNull();

    // skip on step 1
    expect(calls[1].data.status).toBe("SKIPPED");
    expect(calls[1].data.finishedAt).toBeInstanceOf(Date);

    // label/config edit on step 2 (no action)
    expect(calls[2].data.label).toBe("Renamed");
    expect(calls[2].data.config).toEqual({ foo: "bar" });
    expect(calls[2].data.status).toBeUndefined();
  });

  it("forbids modifying steps before currentStepIndex unless reset", async () => {
    const steps = [
      makeStep({ index: 0, status: "SUCCEEDED" }),
      makeStep({ index: 1, status: "PENDING" }),
    ];
    runFind.mockResolvedValueOnce({
      ...makeRun({ status: "PAUSED", currentStepIndex: 1 }),
      steps,
    });

    await expect(
      editRunSteps(RFP_ID, [{ index: 0, label: "no" }]),
    ).rejects.toThrow(/before the current cursor/i);
    expect(stepUpdate).not.toHaveBeenCalled();
  });

  it("rejects reset on a step that hasn't actually run", async () => {
    const steps = [makeStep({ index: 0, status: "PENDING" })];
    runFind.mockResolvedValueOnce({
      ...makeRun({ status: "PAUSED", currentStepIndex: 0 }),
      steps,
    });
    await expect(
      editRunSteps(RFP_ID, [{ index: 0, action: "reset" }]),
    ).rejects.toThrow(/cannot be reset/i);
  });

  it("rejects an edit pointing at a non-existent step", async () => {
    runFind.mockResolvedValueOnce({
      ...makeRun({ status: "PAUSED", currentStepIndex: 0 }),
      steps: [makeStep({ index: 0 })],
    });
    await expect(
      editRunSteps(RFP_ID, [{ index: 99, action: "skip" }]),
    ).rejects.toThrow(/no step at index 99/i);
  });
});
