// Per-step handlers. Each handler returns the next state for the step:
//   - { status: "SUCCEEDED", result?: any }   — done; engine advances
//   - { status: "WAITING_FOR_INPUT", reason } — pause; user must act
//   - { status: "RUNNING" }                   — in flight; engine re-checks later
//   - { status: "FAILED", error }             — error; engine stops
//
// Handlers are pure observers of existing state — they never duplicate work
// the rest of the system already does. The engine is responsible for *kicking
// off* operations (e.g. starting bulk gen) by calling existing endpoints.

import { prisma } from "@/lib/prisma";
import type { PipelineStepRun, RFP } from "@prisma/client";

export type StepHandlerResult =
  | { status: "SUCCEEDED"; result?: Record<string, unknown> }
  | { status: "RUNNING"; reason?: string }
  | { status: "WAITING_FOR_INPUT"; reason: string }
  | { status: "FAILED"; error: string };

export interface StepContext {
  step: PipelineStepRun;
  rfp: RFP;
}

// ---- handlers ----

async function handleReceiveDocs({ rfp }: StepContext): Promise<StepHandlerResult> {
  // The RFP exists, so this step is done by definition.
  return { status: "SUCCEEDED", result: { fileName: rfp.fileName, fileSize: rfp.fileSize } };
}

// ---------------------------------------------------------------------------
// Active-retry helpers — AUTO steps drive their own work to completion
// instead of passively observing other code paths. Each step caps retries
// via `step.result.attempts` (writes through prisma directly) so a broken
// upstream can't push us into an infinite RUNNING loop.
// ---------------------------------------------------------------------------

const MAX_AUTO_ATTEMPTS = 3;

function getAttempts(step: PipelineStepRun): number {
  const r = step.result as { attempts?: number } | null;
  return typeof r?.attempts === "number" ? r.attempts : 0;
}

async function bumpAttemptsAndKick(
  stepId: string,
  current: number,
  kicker: () => Promise<void> | void,
  what: string,
): Promise<number> {
  const next = current + 1;
  // Bump the counter BEFORE kicking the work so a crash mid-kick still
  // reflects the attempt (prevents infinite "kick crashed → counter unchanged
  // → next tick retries again" loops).
  await prisma.pipelineStepRun.update({
    where: { id: stepId },
    data: {
      result: { attempts: next, lastAttemptAt: new Date().toISOString(), kicked: what } as never,
    },
  });
  await kicker();
  return next;
}

async function handleAiIngestion({ step, rfp }: StepContext): Promise<StepHandlerResult> {
  // AI ingestion = parse + table extract + chunk + embed. The actual worker
  // lives in `processRfp` (rfp-pipeline.ts). This handler is the
  // self-healing AUTO driver: if the RFP hasn't been parsed yet, it
  // re-triggers processRfp (bounded by MAX_AUTO_ATTEMPTS) instead of
  // passively waiting for someone else to push the work forward.

  // Already done: parse completed, RFP is READY (or further along).
  if (rfp.status === "READY" || rfp.status === "GENERATING" || rfp.status === "COMPLETED") {
    return { status: "SUCCEEDED", result: { mimeType: rfp.mimeType, fileSize: rfp.fileSize } };
  }

  // Worker reported a hard failure on a prior run — surface it with context.
  if (rfp.status === "FAILED") {
    const attempts = getAttempts(step);
    if (attempts >= MAX_AUTO_ATTEMPTS) {
      return {
        status: "FAILED",
        error: `Document parsing failed after ${attempts} attempt(s): ${rfp.errorMessage ?? "unknown error"}`,
      };
    }
    // Self-heal: clear the error + re-kick processRfp.
    await prisma.rFP.update({
      where: { id: rfp.id },
      data: { status: "UPLOADED", errorMessage: null },
    });
    const { processRfp } = await import("@/lib/rfp-pipeline");
    const next = await bumpAttemptsAndKick(
      step.id,
      attempts,
      () => {
        processRfp(rfp.id).catch((err) => console.error("[pipeline:ai_ingest retry]", err));
      },
      "processRfp",
    );
    return { status: "RUNNING", reason: `Retrying ingestion (attempt ${next}/${MAX_AUTO_ATTEMPTS})` };
  }

  // EXTRACTING — work is in flight, just wait for it to finish.
  if (rfp.status === "EXTRACTING") {
    return { status: "RUNNING", reason: "Parsing + extracting (in flight)" };
  }

  // UPLOADED — worker hasn't started (or its background task crashed before
  // changing rfp.status). Kick it now so we don't sit in UPLOADED forever.
  const attempts = getAttempts(step);
  if (attempts >= MAX_AUTO_ATTEMPTS) {
    return {
      status: "FAILED",
      error: `Ingestion did not start after ${attempts} kick(s). Check the server log for TLS / network / parser crashes.`,
    };
  }
  const { processRfp } = await import("@/lib/rfp-pipeline");
  const next = await bumpAttemptsAndKick(
    step.id,
    attempts,
    () => {
      processRfp(rfp.id).catch((err) => console.error("[pipeline:ai_ingest kick]", err));
    },
    "processRfp",
  );
  return { status: "RUNNING", reason: `Kicking ingestion (attempt ${next}/${MAX_AUTO_ATTEMPTS})` };
}

async function handleExtractQuestions({ step, rfp }: StepContext): Promise<StepHandlerResult> {
  // Extraction is part of processRfp, so by the time RFP.status is READY
  // we expect questions to exist. If READY but 0 questions, the LLM call
  // silently failed — self-heal by re-running processRfp (bounded). If
  // READY with questions, we're done.
  if (rfp.status === "READY") {
    const count = await prisma.question.count({ where: { rfpId: rfp.id } });
    if (count > 0) {
      return { status: "SUCCEEDED", result: { questionCount: count } };
    }
    // 0 questions — retry extraction.
    const attempts = getAttempts(step);
    if (attempts >= MAX_AUTO_ATTEMPTS) {
      return {
        status: "FAILED",
        error:
          `Question extraction returned 0 questions across ${attempts} attempt(s). ` +
          "Check the server log for LLM errors (TLS, rate-limit, key, model refusal) " +
          "and click 'Re-process' once fixed.",
      };
    }
    // Reset RFP to UPLOADED so processRfp re-runs the parse + extract.
    await prisma.rFP.update({
      where: { id: rfp.id },
      data: { status: "UPLOADED", errorMessage: null },
    });
    const { processRfp } = await import("@/lib/rfp-pipeline");
    const { setStepProgress } = await import("./engine");
    const next = await bumpAttemptsAndKick(
      step.id,
      attempts,
      () => {
        // Pass a progress sink so processRfp/extractQuestions can write
        // sub-step text ("Extracting batch 3/6 — 12 questions so far") into
        // the step card while the work runs.
        processRfp(rfp.id, {
          onProgress: (text) => setStepProgress(step.id, text),
        }).catch((err) => console.error("[pipeline:extract retry]", err));
      },
      "processRfp",
    );
    return { status: "RUNNING", reason: `0 questions — retrying extraction (attempt ${next}/${MAX_AUTO_ATTEMPTS})` };
  }
  if (rfp.status === "FAILED") {
    return { status: "FAILED", error: rfp.errorMessage ?? "Question extraction failed" };
  }
  // EXTRACTING / UPLOADED — still in flight or about to start. Surface a
  // generic but informative tick so the step card isn't blank.
  return { status: "RUNNING", reason: `Parsing document & extracting questions…` };
}

async function handleRagSearch({ rfp }: StepContext): Promise<StepHandlerResult> {
  // RAG search is wired into GENERATE_RESPONSES (retrieval-augmented draft
  // step). As a standalone pipeline checkpoint it succeeds the moment every
  // question is on file (i.e. extraction has run) — retrieval itself happens
  // per question inside the next step and doesn't need pre-warming.
  const total = await prisma.question.count({ where: { rfpId: rfp.id } });
  if (total === 0) {
    return { status: "RUNNING", reason: "Waiting for question extraction" };
  }
  return {
    status: "SUCCEEDED",
    result: { questionCount: total, note: "Retrieval runs per-question in the next step." },
  };
}

async function handleCoordinateAE(_ctx: StepContext): Promise<StepHandlerResult> {
  // Pure manual — engine sets this to WAITING_FOR_INPUT until the user
  // clicks "Mark complete" via the API.
  return { status: "WAITING_FOR_INPUT", reason: "Confirm with your account executive that scope, ownership, and timelines are agreed." };
}

async function handleAssignSMEs({ step, rfp }: StepContext): Promise<StepHandlerResult> {
  const total = await prisma.question.count({ where: { rfpId: rfp.id } });
  if (total === 0) return { status: "SUCCEEDED", result: { assigned: 0, total: 0 } };
  const assigned = await prisma.question.count({
    where: { rfpId: rfp.id, NOT: { assigneeId: null } },
  });

  if (step.mode === "AUTO") {
    // Round-robin across org members. Only assign currently-unassigned.
    const project = await prisma.project.findUnique({
      where: { id: rfp.projectId },
      select: { organizationId: true },
    });
    if (!project) return { status: "FAILED", error: "Project not found" };

    const members = await prisma.membership.findMany({
      where: { organizationId: project.organizationId },
      select: { userId: true },
    });
    if (members.length === 0) {
      return { status: "WAITING_FOR_INPUT", reason: "No members to assign to. Invite teammates first." };
    }
    const unassigned = await prisma.question.findMany({
      where: { rfpId: rfp.id, assigneeId: null },
      select: { id: true },
      orderBy: { number: "asc" },
    });
    for (let i = 0; i < unassigned.length; i++) {
      await prisma.question.update({
        where: { id: unassigned[i].id },
        data: { assigneeId: members[i % members.length].userId },
      });
    }
    return { status: "SUCCEEDED", result: { autoAssigned: unassigned.length, total } };
  }

  // MANUAL
  if (assigned >= total) {
    return { status: "SUCCEEDED", result: { assigned, total } };
  }
  return {
    status: "WAITING_FOR_INPUT",
    reason: `${assigned} of ${total} questions assigned. Assign the remaining ${total - assigned}.`,
  };
}

async function handleGenerateResponses({ step, rfp }: StepContext): Promise<StepHandlerResult> {
  const total = await prisma.question.count({ where: { rfpId: rfp.id } });
  if (total === 0) {
    return { status: "WAITING_FOR_INPUT", reason: "No questions to generate against yet." };
  }

  // If a run is currently in flight for this RFP, mark RUNNING.
  const inflight = await prisma.bulkGeneration.findFirst({
    where: { rfpId: rfp.id, status: { in: ["PENDING", "RUNNING"] } },
  });
  if (inflight) {
    return {
      status: "RUNNING",
      reason: `Bulk generation in progress (${inflight.completed}/${inflight.total}).`,
    };
  }

  // Step is succeeded if every question has a COMPLETED response.
  const answered = await prisma.question.count({
    where: { rfpId: rfp.id, responses: { some: { status: "COMPLETED" } } },
  });
  if (answered >= total) {
    return { status: "SUCCEEDED", result: { generated: answered, total } };
  }

  // No bulk in flight, not all answered → wait for user decision/trigger.
  if (step.mode === "DECISION") {
    return {
      status: "WAITING_FOR_INPUT",
      reason: `${answered}/${total} answered. Confirm to start bulk generation for the rest.`,
    };
  }
  // AUTO mode but no run yet — engine will trigger one.
  return { status: "RUNNING", reason: "Triggering bulk generation…" };
}

async function handleInternalReview({ rfp }: StepContext): Promise<StepHandlerResult> {
  const total = await prisma.question.count({ where: { rfpId: rfp.id } });
  if (total === 0) return { status: "SUCCEEDED" };
  const stillTodoOrInProgress = await prisma.question.count({
    where: { rfpId: rfp.id, status: { in: ["TODO", "IN_PROGRESS"] } },
  });
  if (stillTodoOrInProgress === 0) {
    return { status: "SUCCEEDED", result: { reviewed: total } };
  }
  return {
    status: "WAITING_FOR_INPUT",
    reason: `${stillTodoOrInProgress} question(s) still need to move to In Review or Approved.`,
  };
}

async function handleApproval({ rfp }: StepContext): Promise<StepHandlerResult> {
  const total = await prisma.question.count({ where: { rfpId: rfp.id } });
  if (total === 0) return { status: "SUCCEEDED" };
  const approved = await prisma.question.count({
    where: { rfpId: rfp.id, status: "APPROVED" },
  });
  if (approved >= total) {
    return { status: "SUCCEEDED", result: { approved, total } };
  }
  return {
    status: "WAITING_FOR_INPUT",
    reason: `${approved}/${total} questions approved. Approve the remaining ${total - approved}.`,
  };
}

async function handleConsolidateExport({ step, rfp }: StepContext): Promise<StepHandlerResult> {
  // Step succeeds when an EXPORT_GENERATED activity exists for this RFP.
  const exportEvent = await prisma.activityEvent.findFirst({
    where: { rfpId: rfp.id, kind: "EXPORT_GENERATED" },
    orderBy: { createdAt: "desc" },
  });
  if (exportEvent) {
    const payload = (exportEvent.payload as Record<string, unknown> | null) ?? {};
    return {
      status: "SUCCEEDED",
      result: { format: payload.format ?? "docx", at: exportEvent.createdAt.toISOString() },
    };
  }
  if (step.mode === "DECISION") {
    return {
      status: "WAITING_FOR_INPUT",
      reason: "Confirm export format and options to generate the deliverable.",
    };
  }
  return { status: "RUNNING", reason: "Triggering export…" };
}

async function handleMineToKB({ rfp }: StepContext): Promise<StepHandlerResult> {
  // Succeeds if a "mined: true" EXPORT_GENERATED-type event exists. (We
  // overload the existing EXPORT_GENERATED kind for mining; see rfp-mining.ts.)
  const ev = await prisma.activityEvent.findFirst({
    where: {
      rfpId: rfp.id,
      kind: "EXPORT_GENERATED",
      payload: { path: ["mined"], equals: true } as never,
    },
    orderBy: { createdAt: "desc" },
  });
  if (ev) return { status: "SUCCEEDED", result: ev.payload as Record<string, unknown> };
  return { status: "RUNNING", reason: "Mining approved Q&A into knowledge base…" };
}

async function handleCustomTask(_ctx: StepContext): Promise<StepHandlerResult> {
  return { status: "WAITING_FOR_INPUT", reason: "Manual checkpoint. Mark complete when done." };
}

async function handleWebhook({ step, rfp }: StepContext): Promise<StepHandlerResult> {
  const cfg = (step.config as Record<string, unknown> | null) ?? {};
  const url = typeof cfg.url === "string" ? cfg.url : null;
  if (!url) return { status: "FAILED", error: "Webhook step is missing 'url' in config." };

  // Idempotent: only call once per step.
  const prior = (step.result as Record<string, unknown> | null) ?? null;
  if (prior?.calledAt) return { status: "SUCCEEDED", result: prior };

  // Build payload with everything a receiver needs to verify + react.
  const payload = {
    event: "pipeline.step.executed",
    stepId: step.id,
    runId: step.runId,
    kind: step.kind,
    rfpId: rfp.id,
    rfpTitle: rfp.title,
    timestamp: new Date().toISOString(),
    nonce: randomNonce(),
  };
  const bodyText = JSON.stringify(payload);

  // Optional HMAC signature (X-AutoRFP-Signature: t=<ts>,v1=<hex>).
  // The signing secret is per-step config. If unset, no header is sent.
  const secret = typeof cfg.secret === "string" ? cfg.secret : null;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "X-AutoRFP-Event": payload.event,
    "User-Agent": "AutoRFP-Webhook/1.0",
  };
  if (secret) {
    const ts = Math.floor(Date.now() / 1000).toString();
    const sig = await hmacSha256(secret, `${ts}.${bodyText}`);
    headers["X-AutoRFP-Signature"] = `t=${ts},v1=${sig}`;
  }
  if (cfg.headers && typeof cfg.headers === "object") {
    Object.assign(headers, cfg.headers as Record<string, string>);
  }

  // Retry with exponential backoff: 0s, 1s, 3s, 8s. Total ceiling ~12s.
  const attempts: Array<{ status?: number; error?: string; at: string }> = [];
  const backoffs = [0, 1000, 3000, 8000];
  let lastError: string | null = null;

  for (let i = 0; i < backoffs.length; i++) {
    if (backoffs[i] > 0) await new Promise((r) => setTimeout(r, backoffs[i]));
    try {
      const res = await fetch(url, { method: "POST", headers, body: bodyText });
      attempts.push({ status: res.status, at: new Date().toISOString() });
      if (res.status >= 200 && res.status < 300) {
        return {
          status: "SUCCEEDED",
          result: {
            calledAt: new Date().toISOString(),
            status: res.status,
            attempts: attempts.length,
            signed: Boolean(secret),
          },
        };
      }
      lastError = `HTTP ${res.status}`;
      // 4xx (except 408/429) won't get better with retries — short-circuit.
      if (res.status >= 400 && res.status < 500 && res.status !== 408 && res.status !== 429) {
        break;
      }
    } catch (e) {
      lastError = e instanceof Error ? e.message : String(e);
      attempts.push({ error: lastError, at: new Date().toISOString() });
    }
  }

  return {
    status: "FAILED",
    error: `Webhook failed after ${attempts.length} attempt(s): ${lastError ?? "unknown"}`,
  };
}

async function hmacSha256(secret: string, message: string): Promise<string> {
  const { createHmac } = await import("node:crypto");
  return createHmac("sha256", secret).update(message).digest("hex");
}

function randomNonce(): string {
  const { randomBytes } = require("node:crypto") as typeof import("node:crypto");
  return randomBytes(8).toString("hex");
}

// ---- dispatch ----

const HANDLERS: Record<string, (ctx: StepContext) => Promise<StepHandlerResult>> = {
  RECEIVE_DOCS: handleReceiveDocs,
  AI_INGESTION: handleAiIngestion,
  EXTRACT_QUESTIONS: handleExtractQuestions,
  RAG_SEARCH: handleRagSearch,
  COORDINATE_AE: handleCoordinateAE,
  ASSIGN_SMES: handleAssignSMEs,
  GENERATE_RESPONSES: handleGenerateResponses,
  INTERNAL_REVIEW: handleInternalReview,
  APPROVAL: handleApproval,
  CONSOLIDATE_EXPORT: handleConsolidateExport,
  MINE_TO_KB: handleMineToKB,
  CUSTOM_TASK: handleCustomTask,
  WEBHOOK: handleWebhook,
};

export function getHandler(kind: string) {
  return HANDLERS[kind];
}
