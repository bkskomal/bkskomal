// Catalog of every pipeline step kind we support, plus the canonical default
// pipeline used when an org hasn't customized one. Adding a new step kind is
// one entry here + one handler in handlers.ts.

import { PipelineStepKind, PipelineStepMode } from "@prisma/client";

export interface StepCatalogEntry {
  kind: PipelineStepKind;
  label: string;
  description: string;
  /** Default execution mode if a template doesn't override. */
  defaultMode: PipelineStepMode;
  /** Modes the user is allowed to pick for this step. Some steps must be
   *  one mode (e.g. RECEIVE_DOCS is always AUTO). */
  allowedModes: PipelineStepMode[];
  /** Per-step config schema description shown in the editor. */
  configHint?: string;
  /** True if this step's role is purely a marker (no work to do). */
  marker?: boolean;
}

export const STEP_CATALOG: Record<PipelineStepKind, StepCatalogEntry> = {
  RECEIVE_DOCS: {
    kind: "RECEIVE_DOCS",
    label: "Receive RFP Docs",
    description: "RFP file uploaded to the system (PDF, Word, Excel). Marks the start of the pipeline.",
    defaultMode: "AUTO",
    allowedModes: ["AUTO"],
    marker: true,
  },
  AI_INGESTION: {
    kind: "AI_INGESTION",
    label: "AI Ingestion",
    description:
      "Document parsing + table extraction. Runs every parser (PDF/DOCX/XLSX/PPTX), reconstructs layout, extracts tables, embeds images via CLIP.",
    defaultMode: "AUTO",
    allowedModes: ["AUTO"],
    marker: true,
  },
  EXTRACT_QUESTIONS: {
    kind: "EXTRACT_QUESTIONS",
    label: "Question Extraction Engine",
    description:
      "AI identifies and categorizes every distinct question or requirement using the configured LLM.",
    defaultMode: "AUTO",
    allowedModes: ["AUTO", "MANUAL"],
  },
  RAG_SEARCH: {
    kind: "RAG_SEARCH",
    label: "RAG Search against KB",
    description:
      "For each extracted question, run vector search + semantic retrieval against the knowledge base so the LLM has grounded context before drafting.",
    defaultMode: "AUTO",
    allowedModes: ["AUTO"],
    marker: true,
  },
  COORDINATE_AE: {
    kind: "COORDINATE_AE",
    label: "Coordinate with Account Executive",
    description:
      "Confirm scope, customer need, ownership, and timelines with your account executive. Manual checkpoint.",
    defaultMode: "MANUAL",
    allowedModes: ["MANUAL"],
  },
  ASSIGN_SMES: {
    kind: "ASSIGN_SMES",
    label: "Assign SMEs to Questions",
    description:
      "Assign each question to a subject-matter expert. Auto mode round-robins across org members; manual waits until every question has an assignee.",
    defaultMode: "MANUAL",
    allowedModes: ["AUTO", "MANUAL"],
    configHint: "AUTO uses round-robin across all org members; MANUAL waits for each question to be assigned.",
  },
  GENERATE_RESPONSES: {
    kind: "GENERATE_RESPONSES",
    label: "Generate Draft Responses",
    description:
      "Run the AI on every unanswered question with the configured knowledge base. Auto mode runs immediately; DECISION asks before spending tokens.",
    defaultMode: "DECISION",
    allowedModes: ["AUTO", "DECISION"],
    configHint: "Mode 'all' generates every question; 'unanswered' skips already-completed ones.",
  },
  INTERNAL_REVIEW: {
    kind: "INTERNAL_REVIEW",
    label: "SME Review / Edit",
    description:
      "Subject-matter experts review their assigned questions, edit drafts, and move them to IN_REVIEW. Step completes when no question is still TODO/IN_PROGRESS.",
    defaultMode: "MANUAL",
    allowedModes: ["MANUAL"],
  },
  APPROVAL: {
    kind: "APPROVAL",
    label: "Proposal Team Approval",
    description:
      "Proposal lead reviews every response and marks it APPROVED. Step completes when every question has APPROVED status.",
    defaultMode: "MANUAL",
    allowedModes: ["MANUAL"],
  },
  CONSOLIDATE_EXPORT: {
    kind: "CONSOLIDATE_EXPORT",
    label: "Auto Consolidation into Master Template",
    description:
      "Generate the final deliverable document into the master template. Auto exports immediately; DECISION asks for format and content options.",
    defaultMode: "DECISION",
    allowedModes: ["AUTO", "DECISION"],
    configHint: "Defaults: Word format, approved-only, sources included.",
  },
  MINE_TO_KB: {
    kind: "MINE_TO_KB",
    label: "Upload Approved Responses to KB",
    description:
      "Approved Q&A pairs from this RFP are uploaded back to the knowledge base so future RFPs benefit from them.",
    defaultMode: "AUTO",
    allowedModes: ["AUTO", "MANUAL"],
  },
  CUSTOM_TASK: {
    kind: "CUSTOM_TASK",
    label: "Custom Task",
    description: "Free-form manual checkpoint. The step completes when a team member marks it done.",
    defaultMode: "MANUAL",
    allowedModes: ["MANUAL"],
    configHint: "Set the label and description per-template.",
  },
  WEBHOOK: {
    kind: "WEBHOOK",
    label: "Outbound Webhook",
    description:
      "POST a signed payload to an external URL. Useful for integrating with downstream systems (Slack, ticketing, etc.).",
    defaultMode: "AUTO",
    allowedModes: ["AUTO"],
    configHint: "Set 'url' (required) and optional 'headers' object in the step config.",
  },
};

export interface StepDefinition {
  kind: PipelineStepKind;
  label: string;
  description?: string;
  mode: PipelineStepMode;
  config?: Record<string, unknown>;
}

/**
 * The canonical 9-step RFP response pipeline.
 *
 *   1. Receive RFP Docs
 *   2. AI Ingestion Pipeline (parse + table extract)
 *   3. Question Extraction Engine
 *   4. RAG Search against KB (vector + semantic)
 *   5. LLM generates draft response (uses historical approved answers)
 *   6. SME Review / Edit
 *   7. Proposal Team Approval
 *   8. Auto consolidation into master template
 *   9. Approved responses uploaded back to KB
 *
 * Mirrors the Genie reference flow exactly. The two older "coordinate AE"
 * and "assign SMEs" steps are still in the catalog (so orgs that customised
 * their template keep working) but the default no longer includes them.
 */
export const DEFAULT_PIPELINE: StepDefinition[] = [
  { kind: "RECEIVE_DOCS", label: STEP_CATALOG.RECEIVE_DOCS.label, mode: "AUTO" },
  { kind: "AI_INGESTION", label: STEP_CATALOG.AI_INGESTION.label, mode: "AUTO" },
  { kind: "EXTRACT_QUESTIONS", label: STEP_CATALOG.EXTRACT_QUESTIONS.label, mode: "AUTO" },
  { kind: "RAG_SEARCH", label: STEP_CATALOG.RAG_SEARCH.label, mode: "AUTO" },
  {
    kind: "GENERATE_RESPONSES",
    label: STEP_CATALOG.GENERATE_RESPONSES.label,
    mode: "AUTO",
    config: { mode: "unanswered", enableTools: true, useGoldenAnswers: true },
  },
  { kind: "INTERNAL_REVIEW", label: STEP_CATALOG.INTERNAL_REVIEW.label, mode: "MANUAL" },
  { kind: "APPROVAL", label: STEP_CATALOG.APPROVAL.label, mode: "MANUAL" },
  {
    kind: "CONSOLIDATE_EXPORT",
    label: STEP_CATALOG.CONSOLIDATE_EXPORT.label,
    mode: "AUTO",
    config: { format: "docx", approvedOnly: true, includeSources: true },
  },
  { kind: "MINE_TO_KB", label: STEP_CATALOG.MINE_TO_KB.label, mode: "AUTO" },
];
