// Bearer-token authentication middleware.
//
// Reads `Authorization: Bearer <token>`, looks up the matching ApiKey, and
// returns a session-shaped object on success. Returns null in every failure
// mode (missing header, malformed header, unknown / revoked / expired token)
// so callers can fall back to session auth without try/catch.
//
// On success, fires a fire-and-forget `API_KEY_USED` audit event with request
// context (IP, user-agent) so we have a trail of which key did what.

import type { NextRequest } from "next/server";
import { ApiKeyScope } from "@prisma/client";
import { lookupApiKey } from "./api-keys";
import { audit, auditContextFromRequest } from "./audit";

export interface BearerSession {
  userId: string;
  organizationId: string | null;
  scope: ApiKeyScope;
  keyId: string;
  via: "api-key";
}

const BEARER_PREFIX = "Bearer ";

export async function authenticateBearer(
  req: Request | NextRequest,
): Promise<BearerSession | null> {
  const header = req.headers.get("authorization") ?? req.headers.get("Authorization");
  if (!header) return null;
  if (!header.startsWith(BEARER_PREFIX)) return null;

  const token = header.slice(BEARER_PREFIX.length).trim();
  if (!token) return null;

  const found = await lookupApiKey(token);
  if (!found) return null;

  const { key, user } = found;

  // Fire-and-forget audit. Don't block the request on the write.
  void audit({
    event: "API_KEY_USED",
    actorId: user.id,
    organizationId: key.organizationId,
    targetType: "api_key",
    targetId: key.id,
    metadata: { prefix: key.prefix, scope: key.scope },
    ...auditContextFromRequest(req),
  });

  return {
    userId: user.id,
    organizationId: key.organizationId,
    scope: key.scope,
    keyId: key.id,
    via: "api-key",
  };
}
