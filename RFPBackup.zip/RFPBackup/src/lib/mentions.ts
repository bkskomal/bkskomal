// Parse @mentions from a comment body.
//
// Two formats are recognized:
//   - `@user@domain.com`   — full email
//   - `@username`          — local-part (matches an org member whose email's
//                            local part equals this; useful for short handles)
//
// We resolve mentions against the org membership for the comment, so a typo
// won't match someone in a different org.

const EMAIL_MENTION = /(^|[^a-zA-Z0-9._-])@([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g;
const HANDLE_MENTION = /(^|[^a-zA-Z0-9._-])@([a-zA-Z0-9._-]{2,})\b/g;

export interface RawMention {
  text: string; // raw token after the @
  kind: "email" | "handle";
}

export function extractRawMentions(body: string): RawMention[] {
  const out: RawMention[] = [];
  const seen = new Set<string>();
  let m: RegExpExecArray | null;
  EMAIL_MENTION.lastIndex = 0;
  while ((m = EMAIL_MENTION.exec(body)) !== null) {
    const t = m[2].toLowerCase();
    if (!seen.has(`email:${t}`)) {
      seen.add(`email:${t}`);
      out.push({ text: t, kind: "email" });
    }
  }
  HANDLE_MENTION.lastIndex = 0;
  while ((m = HANDLE_MENTION.exec(body)) !== null) {
    const t = m[2].toLowerCase();
    // Skip if we already captured this as an email's local part.
    if (out.some((r) => r.kind === "email" && r.text.startsWith(`${t}@`))) continue;
    if (!seen.has(`handle:${t}`)) {
      seen.add(`handle:${t}`);
      out.push({ text: t, kind: "handle" });
    }
  }
  return out;
}

/**
 * Resolve raw mentions against a set of candidate org members.
 * Returns the user IDs of unambiguous matches.
 */
export function resolveMentions(
  raw: RawMention[],
  members: Array<{ id: string; email: string }>,
): string[] {
  const byEmail = new Map(members.map((m) => [m.email.toLowerCase(), m.id]));
  // For handles, build a map of local-part → id. If multiple members share
  // the same local-part across providers (rare), skip to avoid ambiguity.
  const localCounts = new Map<string, number>();
  for (const m of members) {
    const local = m.email.split("@")[0].toLowerCase();
    localCounts.set(local, (localCounts.get(local) ?? 0) + 1);
  }
  const byHandle = new Map<string, string>();
  for (const m of members) {
    const local = m.email.split("@")[0].toLowerCase();
    if (localCounts.get(local) === 1) byHandle.set(local, m.id);
  }

  const ids = new Set<string>();
  for (const r of raw) {
    if (r.kind === "email") {
      const id = byEmail.get(r.text);
      if (id) ids.add(id);
    } else {
      const id = byHandle.get(r.text);
      if (id) ids.add(id);
    }
  }
  return Array.from(ids);
}
