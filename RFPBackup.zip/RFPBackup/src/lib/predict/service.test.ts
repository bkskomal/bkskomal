import { describe, expect, it, vi, beforeEach } from "vitest";

// Hoisted mocks so the factory functions in `vi.mock(...)` can reference them.
const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    rFP: { findUnique: vi.fn(), groupBy: vi.fn(), findMany: vi.fn() },
    goldenAnswer: { findMany: vi.fn() },
    document: { findFirst: vi.fn() },
    winPrediction: {
      upsert: vi.fn(),
      findUnique: vi.fn(),
      update: vi.fn(),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

import {
  scoreRfp,
  scoreAndPersist,
  persistPrediction,
  applyOverride,
} from "./service";

const RFP_ID = "rfp_svc_1";
const ORG_ID = "org_svc_1";
const USER_ID = "user_svc_1";

beforeEach(() => {
  vi.clearAllMocks();
  // Default RFP returns a minimal valid shape so extractFeatures resolves.
  prismaMock.rFP.findUnique.mockResolvedValue({
    id: RFP_ID,
    dueDate: null,
    project: { organizationId: ORG_ID },
    questions: [],
  });
  prismaMock.rFP.groupBy.mockResolvedValue([]);
  prismaMock.rFP.findMany.mockResolvedValue([]);
  prismaMock.goldenAnswer.findMany.mockResolvedValue([]);
  prismaMock.document.findFirst.mockResolvedValue(null);
  prismaMock.winPrediction.upsert.mockResolvedValue({});
  prismaMock.winPrediction.update.mockResolvedValue({});
  prismaMock.winPrediction.findUnique.mockResolvedValue(null);
});

// ---------------------------------------------------------------------------
// scoreRfp / persistPrediction / scoreAndPersist.
// ---------------------------------------------------------------------------

describe("scoreRfp()", () => {
  it("returns features + probability + recommendation", async () => {
    const result = await scoreRfp(RFP_ID);
    expect(result.features).toBeDefined();
    expect(typeof result.probability).toBe("number");
    expect(["go", "review", "no_bid"]).toContain(result.recommendation);
    expect(result.modelVersion).toMatch(/^win-predictor-/);
  });
});

describe("persistPrediction()", () => {
  it("upserts the WinPrediction row with the score snapshot", async () => {
    const features = {
      questionCount: 0,
      avgQuestionConfidence: 0,
      avgGroundingScore: 0,
      complexityDist: { simple: 0, moderate: 0, complex: 0 },
      eligibilityDist: { answerable: 0, needs_info: 0, out_of_scope: 0 },
      daysToDeadline: null,
      historicalWinRate: 0.5,
      similarRfpCount: 0,
      similarRfpWinRate: null,
      hasGoldenAnswerCoverage: 0,
      daysSinceOldestSource: null,
    };
    await persistPrediction(RFP_ID, {
      features,
      probability: 0.55,
      recommendation: "go",
      contributions: { historicalWinRate: 0.1 },
      modelVersion: "win-predictor-v1",
    });
    expect(prismaMock.winPrediction.upsert).toHaveBeenCalledTimes(1);
    const call = prismaMock.winPrediction.upsert.mock.calls[0][0];
    expect(call.where).toEqual({ rfpId: RFP_ID });
    expect(call.create.probability).toBe(0.55);
    expect(call.create.recommendation).toBe("go");
    expect(call.create.modelVersion).toBe("win-predictor-v1");
    expect(call.update.probability).toBe(0.55);
    // Critical: upsert must not touch the override fields so re-scores
    // never clobber a human override.
    expect(call.update.overrideAction).toBeUndefined();
    expect(call.update.overrideById).toBeUndefined();
    expect(call.update.overrideAt).toBeUndefined();
  });
});

describe("scoreAndPersist()", () => {
  it("writes a WinPrediction row in a single call", async () => {
    const result = await scoreAndPersist(RFP_ID);
    expect(prismaMock.winPrediction.upsert).toHaveBeenCalledTimes(1);
    expect(result.probability).toBeGreaterThanOrEqual(0);
    expect(result.probability).toBeLessThanOrEqual(1);
  });
});

// ---------------------------------------------------------------------------
// applyOverride() — set + clear semantics.
// ---------------------------------------------------------------------------

describe("applyOverride()", () => {
  it("sets overrideAction + overrideById + overrideAt when action is provided", async () => {
    prismaMock.winPrediction.findUnique.mockResolvedValueOnce({ id: "wp_1" });
    await applyOverride({ rfpId: RFP_ID, action: "go", userId: USER_ID });
    expect(prismaMock.winPrediction.update).toHaveBeenCalledTimes(1);
    const call = prismaMock.winPrediction.update.mock.calls[0][0];
    expect(call.where).toEqual({ rfpId: RFP_ID });
    expect(call.data.overrideAction).toBe("go");
    expect(call.data.overrideById).toBe(USER_ID);
    expect(call.data.overrideAt).toBeInstanceOf(Date);
  });

  it("clears all three override fields when action is null", async () => {
    prismaMock.winPrediction.findUnique.mockResolvedValueOnce({ id: "wp_1" });
    await applyOverride({ rfpId: RFP_ID, action: null, userId: USER_ID });
    expect(prismaMock.winPrediction.update).toHaveBeenCalledTimes(1);
    const call = prismaMock.winPrediction.update.mock.calls[0][0];
    expect(call.data.overrideAction).toBeNull();
    expect(call.data.overrideById).toBeNull();
    expect(call.data.overrideAt).toBeNull();
  });

  it("bootstraps a row when none exists, then applies the override", async () => {
    // No existing row → service first calls scoreAndPersist internally.
    prismaMock.winPrediction.findUnique.mockResolvedValueOnce(null);
    await applyOverride({ rfpId: RFP_ID, action: "no_bid", userId: USER_ID });
    expect(prismaMock.winPrediction.upsert).toHaveBeenCalledTimes(1);
    expect(prismaMock.winPrediction.update).toHaveBeenCalledTimes(1);
    expect(prismaMock.winPrediction.update.mock.calls[0][0].data.overrideAction).toBe(
      "no_bid",
    );
  });
});
