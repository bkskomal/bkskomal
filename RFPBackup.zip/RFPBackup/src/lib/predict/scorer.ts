// Win-probability scorer (Tier C — moonshot).
//
// Takes the feature struct produced by `extractFeatures` and emits a
// 0..1 probability + GO/REVIEW/NO_BID recommendation. Optimised for
// **explainability over accuracy**: a small set of hand-tuned weights,
// each contributing a signed "lift" to the base probability, summed and
// squashed through a sigmoid.
//
// This is a *decision aid, not an oracle*. The probability is meant to
// answer "should this bid get a human's full attention?" — not "what is
// the true posterior probability that we close this deal?". When a sales
// VP wants to overrule the model, they pin GO or NO_BID via the override
// mechanism (see `service.applyOverride`) and the model stops mattering
// for that RFP.
//
// Model design
// ------------
// Start at base lift = 0 (corresponds to P(win) = 0.5 after the sigmoid).
// Each feature adds a signed lift. Every weight below is documented inline
// with the rationale for its direction and magnitude.
//
// The historical-win-rate term is the *anchor*: it shifts the base by up to
// ±1.0 (which maps to roughly P = 0.27..0.73). All other features are
// modifiers on that anchor — none individually exceeds ±0.20.
//
// Why no training pipeline?
//   * We have outcomes for ~tens to hundreds of RFPs per org. That's not
//     enough to fit a model that generalises across orgs without massive
//     overfitting. A hand-tuned rule set is more honest about how little
//     signal we actually have.
//   * Sales leaders need to know *why* the model recommended NO_BID. A
//     per-feature contribution map (the `contributions` field below) is
//     trivially derived from a weighted sum and impossible to derive
//     cleanly from a non-trivial ML model.
//
// When weights change (which they will as we collect more data), bump
// `MODEL_VERSION`. The route's PATCH re-score and the override actions
// stamp this version into the `WinPrediction` row so historical analysis
// can tell which model produced which call.

import type { PredictionFeatures } from "./features";

export type Recommendation = "go" | "review" | "no_bid";

export interface ScoreResult {
  /** Squashed final probability, 0..1. */
  probability: number;
  /** Tier label derived from `probability`. */
  recommendation: Recommendation;
  /**
   * Per-feature signed contribution to the *lift* (pre-sigmoid). Reading
   * the map: positive values pushed probability up, negative pulled it
   * down. The keys are stable strings so the UI can pretty-print them
   * (see the panel component).
   */
  contributions: Record<string, number>;
  /** Bumped whenever the formula or thresholds change. */
  modelVersion: string;
}

export const MODEL_VERSION = "win-predictor-v1";

// Threshold boundaries. Tuned so a "no signal" RFP (probability ≈ 0.5)
// always falls in REVIEW — the conservative default that asks for a
// human look. Only RFPs with material positive lift become GO; only
// those with material negative lift become NO_BID.
export const GO_THRESHOLD = 0.55;
export const NO_BID_THRESHOLD = 0.30;

/**
 * Score a feature struct. Pure function — no I/O. Safe to call on stale
 * features (e.g. when computing a what-if preview in the UI later).
 */
export function scoreFeatures(features: PredictionFeatures): ScoreResult {
  const contributions: Record<string, number> = {};

  // --- 1. Historical anchor --------------------------------------------
  // (historicalWinRate − 0.5) × 2 puts a 30%-winning org at lift = -0.4
  // (≈ P 0.40) and a 70%-winning org at lift = +0.4 (≈ P 0.60). This is
  // intentionally the *largest* dial: an org that wins 20% of its bids
  // shouldn't get GO recommendations on every new RFP just because the
  // text looks clean.
  contributions.historicalWinRate = (features.historicalWinRate - 0.5) * 2;

  // --- 2. Question quality signals -------------------------------------
  // High avg confidence is a leading indicator that we already have good
  // answers stored; low avg confidence flags content the team will
  // struggle on. Asymmetric weights — the penalty for *bad* coverage is
  // larger than the bonus for *good* coverage because a known weakness
  // costs more than a known strength gains.
  if (features.avgQuestionConfidence >= 0.8) {
    contributions.avgQuestionConfidence = 0.15;
  } else if (features.avgQuestionConfidence > 0 && features.avgQuestionConfidence <= 0.5) {
    contributions.avgQuestionConfidence = -0.2;
  } else {
    contributions.avgQuestionConfidence = 0;
  }

  // Grounding score reflects whether our knowledge base supports the
  // claims we'd make — a stronger signal than self-rated confidence
  // because it's third-party-checked by the LLM judge.
  if (features.avgGroundingScore >= 0.85) {
    contributions.avgGroundingScore = 0.1;
  } else if (features.avgGroundingScore > 0 && features.avgGroundingScore <= 0.6) {
    contributions.avgGroundingScore = -0.15;
  } else {
    contributions.avgGroundingScore = 0;
  }

  // --- 3. RFP shape ----------------------------------------------------
  // Lots of "complex" questions = lots of expert SME time. Negative
  // signal regardless of historical win rate.
  if (features.complexityDist.complex > 0.4) {
    contributions.complexity = -0.1;
  } else {
    contributions.complexity = 0;
  }

  // Eligibility signals: out-of-scope questions are the strongest tell
  // that this RFP is a poor fit at all (penalty larger than complexity).
  // `needs_info` is softer — it means we'd have to chase the customer
  // for specifics. Both are *capability* signals separate from quality.
  if (features.eligibilityDist.out_of_scope > 0.2) {
    contributions.outOfScope = -0.2;
  } else {
    contributions.outOfScope = 0;
  }
  if (features.eligibilityDist.needs_info > 0.3) {
    contributions.needsInfo = -0.1;
  } else {
    contributions.needsInfo = 0;
  }

  // --- 4. Deadline -----------------------------------------------------
  // Rush bids underperform because the team has no time to polish.
  // Threshold at 3 days because that's roughly the minimum for a serious
  // RFP cycle (questions, draft, review, final). Negative numbers count
  // as overdue and trigger the penalty too.
  if (features.daysToDeadline != null && features.daysToDeadline < 3) {
    contributions.daysToDeadline = -0.15;
  } else {
    contributions.daysToDeadline = 0;
  }

  // --- 5. Reuse from past wins -----------------------------------------
  // Golden answer coverage means an SME has previously vetted answers
  // that match the new questions — the closest analogue we have to
  // "we've sold this exact thing before."
  if (features.hasGoldenAnswerCoverage >= 0.5) {
    contributions.goldenAnswerCoverage = 0.15;
  } else {
    contributions.goldenAnswerCoverage = 0;
  }

  // --- 6. Similar-RFP outcome — the strongest external signal ---------
  // Lift scaled by 0.6 (smaller than the historical anchor) because the
  // similarity metric is a coarse topic-overlap. Skipped entirely when
  // we have no similar decided RFPs (null) — better to abstain than to
  // hallucinate signal.
  if (features.similarRfpWinRate != null) {
    contributions.similarRfpWinRate = (features.similarRfpWinRate - 0.5) * 0.6;
  } else {
    contributions.similarRfpWinRate = 0;
  }

  // --- 7. Source freshness --------------------------------------------
  // Soft penalty — a stale knowledge base doesn't *prevent* a win but
  // makes it harder. Two years is the rough sell-by date for security
  // questionnaire content (SOC2 / pen-test windows, regulatory changes).
  if (features.daysSinceOldestSource != null && features.daysSinceOldestSource > 730) {
    contributions.sourceStaleness = -0.05;
  } else {
    contributions.sourceStaleness = 0;
  }

  // --- Combine ---------------------------------------------------------
  const lift = Object.values(contributions).reduce((a, b) => a + b, 0);
  // logit(0.5) = 0, so base 0.5 + sigmoid(lift) gives us a clean midpoint
  // when nothing fires.
  const probability = sigmoid(logit(0.5) + lift);
  return {
    probability,
    recommendation: classify(probability),
    contributions,
    modelVersion: MODEL_VERSION,
  };
}

/** Tier classifier — exposed so tests can verify the threshold boundaries. */
export function classify(probability: number): Recommendation {
  if (probability >= GO_THRESHOLD) return "go";
  if (probability < NO_BID_THRESHOLD) return "no_bid";
  return "review";
}

function sigmoid(z: number): number {
  // Numerically stable: avoid overflow on large |z|. The fallback paths
  // also handle Infinity / NaN cleanly so a bad feature can't crash a
  // route handler.
  if (!Number.isFinite(z)) return z > 0 ? 1 : 0;
  if (z >= 0) {
    const ez = Math.exp(-z);
    return 1 / (1 + ez);
  }
  const ez = Math.exp(z);
  return ez / (1 + ez);
}

function logit(p: number): number {
  if (p <= 0) return -Infinity;
  if (p >= 1) return Infinity;
  return Math.log(p / (1 - p));
}
