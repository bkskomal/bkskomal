// Feature extractor for the win-prediction scorer (Tier C — moonshot).
//
// Pulls a small bag of cheap signals out of the DB for a single RFP:
//   * shape of the RFP itself (question count, complexity / eligibility mix,
//     deadline)
//   * health of any answers already drafted (avg model confidence, avg
//     grounding score from the LLM judge)
//   * organisational priors (historical win rate, similar-RFP outcomes,
//     coverage by golden answers, source freshness)
//
// All signals are pure Prisma reads — no LLM calls, no embeddings. The whole
// point of this module is to be fast enough to run synchronously on every
// upload and re-run cheaply on outcome changes.
//
// Design notes:
//   * Every field returns a defined value (never undefined). Unknown numeric
//     signals collapse to neutral defaults (0 distributions, win rate 0.5,
//     `null` only where the consumer needs to distinguish "no data" from "0"
//     — i.e. `daysToDeadline`, `similarRfpWinRate`, `daysSinceOldestSource`).
//   * `similarRfpCount` uses a deliberately stupid heuristic: take the most
//     common `Question.topic` of the new RFP and count past RFPs in the org
//     whose questions share that topic (case-insensitive substring). Good
//     enough as a directional signal — proper semantic similarity is left
//     to a future revision with embeddings.

import { prisma } from "@/lib/prisma";

export interface PredictionFeatures {
  /** Number of extracted questions on the RFP (post-renumbering). */
  questionCount: number;
  /** Mean Question.confidence across all questions on the RFP, 0..1. */
  avgQuestionConfidence: number;
  /** Mean Response.groundingScore across COMPLETED responses, 0..1. */
  avgGroundingScore: number;
  /** Fractional split (sums to 1) of Question.complexity. */
  complexityDist: { simple: number; moderate: number; complex: number };
  /** Fractional split (sums to 1) of Question.eligibility. */
  eligibilityDist: { answerable: number; needs_info: number; out_of_scope: number };
  /** Days until RFP.dueDate (negative = overdue). Null when no deadline set. */
  daysToDeadline: number | null;
  /**
   * Org-wide win rate across all decided RFPs: WON / (WON + LOST). Defaults
   * to 0.5 (no prior) when the org has no decided RFPs yet — this prevents
   * the scorer from anchoring a fresh org at "0% baseline".
   */
  historicalWinRate: number;
  /** Number of past RFPs in the same org sharing the new RFP's top topic. */
  similarRfpCount: number;
  /**
   * Win rate among similar RFPs (same denominator rule as
   * `historicalWinRate`). Null when there are no decided similar RFPs —
   * the scorer treats `null` as "no signal" and skips its weight entirely.
   */
  similarRfpWinRate: number | null;
  /** Fraction of questions matched by an org golden answer (substring). */
  hasGoldenAnswerCoverage: number;
  /**
   * Age (in days) of the oldest source Document attached to the org's
   * knowledge bases. Null when the org has no Documents (e.g. brand-new
   * tenant). Used as a staleness penalty.
   */
  daysSinceOldestSource: number | null;
}

/** Neutral baseline used when the RFP has no questions yet. */
const EMPTY_DIST = { simple: 0, moderate: 0, complex: 0 } as const;
const EMPTY_ELIGIBILITY_DIST = {
  answerable: 0,
  needs_info: 0,
  out_of_scope: 0,
} as const;

const DAY_MS = 24 * 60 * 60 * 1000;

/**
 * Pull every feature for `rfpId`. Returns the full struct even when the RFP
 * is empty — callers can pass the result straight to `scoreFeatures` and the
 * scorer will fall back to the historical-win-rate anchor.
 *
 * Throws when the RFP doesn't exist (caller error). All other "no data"
 * paths produce a usable feature struct.
 */
export async function extractFeatures(rfpId: string): Promise<PredictionFeatures> {
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    select: {
      id: true,
      dueDate: true,
      project: { select: { organizationId: true } },
      questions: {
        select: {
          id: true,
          text: true,
          confidence: true,
          complexity: true,
          eligibility: true,
          topic: true,
          responses: {
            where: { status: "COMPLETED" },
            select: { groundingScore: true },
            orderBy: { createdAt: "desc" },
            take: 1,
          },
        },
      },
    },
  });
  if (!rfp) throw new Error(`RFP not found: ${rfpId}`);

  const orgId = rfp.project.organizationId;
  const questions = rfp.questions;
  const questionCount = questions.length;

  // --- Per-question signals ---------------------------------------------
  const confidences = questions
    .map((q) => q.confidence)
    .filter((c): c is number => typeof c === "number");
  const avgQuestionConfidence = confidences.length
    ? confidences.reduce((a, b) => a + b, 0) / confidences.length
    : 0;

  const groundingScores: number[] = [];
  for (const q of questions) {
    const score = q.responses[0]?.groundingScore;
    if (typeof score === "number") groundingScores.push(score);
  }
  const avgGroundingScore = groundingScores.length
    ? groundingScores.reduce((a, b) => a + b, 0) / groundingScores.length
    : 0;

  const complexityDist = computeDist(questions.map((q) => q.complexity), [
    "simple",
    "moderate",
    "complex",
  ]) as PredictionFeatures["complexityDist"];

  const eligibilityDist = computeDist(questions.map((q) => q.eligibility), [
    "answerable",
    "needs_info",
    "out_of_scope",
  ]) as PredictionFeatures["eligibilityDist"];

  // --- Deadline ---------------------------------------------------------
  const now = Date.now();
  const daysToDeadline = rfp.dueDate
    ? Math.round((rfp.dueDate.getTime() - now) / DAY_MS)
    : null;

  // --- Org priors --------------------------------------------------------
  const outcomeRows = await prisma.rFP.groupBy({
    by: ["outcome"],
    where: { project: { organizationId: orgId }, id: { not: rfpId } },
    _count: { _all: true },
  });
  let won = 0;
  let lost = 0;
  for (const row of outcomeRows) {
    if (row.outcome === "WON") won = row._count._all;
    else if (row.outcome === "LOST") lost = row._count._all;
  }
  const decided = won + lost;
  // 0.5 = "no prior" so the scorer doesn't penalise brand-new orgs.
  const historicalWinRate = decided > 0 ? won / decided : 0.5;

  // --- Similar-RFP signal -----------------------------------------------
  // Pick the most-common topic on the new RFP and count past RFPs whose
  // questions overlap with that topic. Stupid heuristic, intentional — see
  // module docstring.
  const topTopic = mostCommonTopic(questions.map((q) => q.topic));
  let similarRfpCount = 0;
  let similarWon = 0;
  let similarLost = 0;
  if (topTopic) {
    const matching = await prisma.rFP.findMany({
      where: {
        project: { organizationId: orgId },
        id: { not: rfpId },
        questions: {
          // Case-insensitive substring match on Question.topic.
          some: { topic: { contains: topTopic, mode: "insensitive" } },
        },
      },
      select: { id: true, outcome: true },
    });
    similarRfpCount = matching.length;
    for (const r of matching) {
      if (r.outcome === "WON") similarWon++;
      else if (r.outcome === "LOST") similarLost++;
    }
  }
  const similarDecided = similarWon + similarLost;
  const similarRfpWinRate = similarDecided > 0 ? similarWon / similarDecided : null;

  // --- Golden-answer coverage -------------------------------------------
  // Cheap heuristic: count questions whose text shares >= 3 long-ish words
  // with any golden answer's question text. We pull all goldens once and
  // run the check in JS — golden tables are small (hundreds, not millions).
  let hasGoldenAnswerCoverage = 0;
  if (questions.length > 0) {
    const goldens = await prisma.goldenAnswer.findMany({
      where: { organizationId: orgId },
      select: { question: true },
    });
    if (goldens.length > 0) {
      const goldenTokenSets = goldens.map((g) => tokenSet(g.question));
      let matched = 0;
      for (const q of questions) {
        const qTokens = tokenSet(q.text);
        for (const gTokens of goldenTokenSets) {
          if (overlapAtLeast(qTokens, gTokens, 3)) {
            matched++;
            break;
          }
        }
      }
      hasGoldenAnswerCoverage = matched / questions.length;
    }
  }

  // --- Source freshness -------------------------------------------------
  // Age (days) of the oldest Document in the org's knowledge indexes. We
  // intentionally use the oldest source rather than the average: a single
  // stale-but-load-bearing policy doc says more about answer quality risk
  // than the mean ingest age.
  const oldestDoc = await prisma.document.findFirst({
    where: { index: { organizationId: orgId } },
    orderBy: { createdAt: "asc" },
    select: { createdAt: true },
  });
  const daysSinceOldestSource = oldestDoc
    ? Math.round((now - oldestDoc.createdAt.getTime()) / DAY_MS)
    : null;

  return {
    questionCount,
    avgQuestionConfidence,
    avgGroundingScore,
    complexityDist: questionCount ? complexityDist : { ...EMPTY_DIST },
    eligibilityDist: questionCount ? eligibilityDist : { ...EMPTY_ELIGIBILITY_DIST },
    daysToDeadline,
    historicalWinRate,
    similarRfpCount,
    similarRfpWinRate,
    hasGoldenAnswerCoverage,
    daysSinceOldestSource,
  };
}

// ---------------------------------------------------------------------------
// Helpers (unit-tested via the public extractor).
// ---------------------------------------------------------------------------

/**
 * Bin a list of category strings into the supplied bucket names and emit
 * fractions that sum to 1. Empty input emits all-zero — the caller is
 * responsible for spreading the empty constant when the RFP has no
 * questions (we can't distinguish "all zero" from "no questions" from this
 * helper alone, but the public extractor handles it).
 */
function computeDist<K extends string>(
  values: Array<string | null | undefined>,
  buckets: readonly K[],
): Record<K, number> {
  const counts = {} as Record<K, number>;
  for (const b of buckets) counts[b] = 0;
  let total = 0;
  for (const v of values) {
    if (!v) continue;
    if ((counts as Record<string, number>)[v] !== undefined) {
      counts[v as K] += 1;
      total += 1;
    }
  }
  if (total === 0) return counts;
  for (const b of buckets) counts[b] = counts[b] / total;
  return counts;
}

/** Return the most common non-null topic, or null when none exist. */
function mostCommonTopic(topics: Array<string | null | undefined>): string | null {
  const freq = new Map<string, number>();
  for (const t of topics) {
    if (!t) continue;
    const key = t.trim().toLowerCase();
    if (!key) continue;
    freq.set(key, (freq.get(key) ?? 0) + 1);
  }
  if (freq.size === 0) return null;
  let best: string | null = null;
  let bestCount = 0;
  for (const [k, v] of freq) {
    if (v > bestCount) {
      best = k;
      bestCount = v;
    }
  }
  return best;
}

/** Lower-cased token set of words >= 4 chars from `text`. */
function tokenSet(text: string): Set<string> {
  const out = new Set<string>();
  for (const raw of text.toLowerCase().split(/[^a-z0-9]+/)) {
    if (raw.length >= 4) out.add(raw);
  }
  return out;
}

/** True when |a ∩ b| >= n. */
function overlapAtLeast(a: Set<string>, b: Set<string>, n: number): boolean {
  let hits = 0;
  for (const tok of a) {
    if (b.has(tok)) {
      hits++;
      if (hits >= n) return true;
    }
  }
  return false;
}
