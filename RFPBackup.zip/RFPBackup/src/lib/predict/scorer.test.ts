import { describe, expect, it } from "vitest";
import {
  scoreFeatures,
  classify,
  MODEL_VERSION,
  GO_THRESHOLD,
  NO_BID_THRESHOLD,
} from "./scorer";
import type { PredictionFeatures } from "./features";

// A neutral feature snapshot: every signal at its zero-lift baseline.
// `historicalWinRate = 0.5` means the anchor contributes 0; every threshold
// gate falls below the trigger so no feature fires. Resulting probability
// should be exactly 0.5 ⇒ classification = "review".
function neutral(): PredictionFeatures {
  return {
    questionCount: 10,
    avgQuestionConfidence: 0.7,
    avgGroundingScore: 0.75,
    complexityDist: { simple: 0.5, moderate: 0.3, complex: 0.2 },
    eligibilityDist: { answerable: 0.7, needs_info: 0.2, out_of_scope: 0.1 },
    daysToDeadline: 30,
    historicalWinRate: 0.5,
    similarRfpCount: 0,
    similarRfpWinRate: null,
    hasGoldenAnswerCoverage: 0,
    daysSinceOldestSource: 30,
  };
}

describe("scoreFeatures() — neutral baseline", () => {
  it("emits probability ≈ 0.5 and review recommendation when nothing fires", () => {
    const r = scoreFeatures(neutral());
    expect(r.probability).toBeCloseTo(0.5, 5);
    expect(r.recommendation).toBe("review");
    expect(r.modelVersion).toBe(MODEL_VERSION);
    // No feature should contribute non-zero lift on the neutral baseline.
    for (const [, v] of Object.entries(r.contributions)) {
      expect(v).toBe(0);
    }
  });
});

describe("scoreFeatures() — positive contributions raise probability", () => {
  it("high historical win rate raises probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.historicalWinRate = 0.8;
    const r = scoreFeatures(f);
    expect(r.probability).toBeGreaterThan(base);
    expect(r.contributions.historicalWinRate).toBeGreaterThan(0);
  });

  it("high avg confidence raises probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.avgQuestionConfidence = 0.85;
    const r = scoreFeatures(f);
    expect(r.probability).toBeGreaterThan(base);
    expect(r.contributions.avgQuestionConfidence).toBeGreaterThan(0);
  });

  it("high grounding score raises probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.avgGroundingScore = 0.9;
    const r = scoreFeatures(f);
    expect(r.probability).toBeGreaterThan(base);
    expect(r.contributions.avgGroundingScore).toBeGreaterThan(0);
  });

  it("strong golden answer coverage raises probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.hasGoldenAnswerCoverage = 0.7;
    const r = scoreFeatures(f);
    expect(r.probability).toBeGreaterThan(base);
    expect(r.contributions.goldenAnswerCoverage).toBeGreaterThan(0);
  });

  it("similar-RFP win rate above 0.5 contributes positively", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.similarRfpWinRate = 0.8;
    const r = scoreFeatures(f);
    expect(r.probability).toBeGreaterThan(base);
    expect(r.contributions.similarRfpWinRate).toBeGreaterThan(0);
  });
});

describe("scoreFeatures() — negative contributions lower probability", () => {
  it("low historical win rate lowers probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.historicalWinRate = 0.2;
    const r = scoreFeatures(f);
    expect(r.probability).toBeLessThan(base);
    expect(r.contributions.historicalWinRate).toBeLessThan(0);
  });

  it("low avg confidence lowers probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.avgQuestionConfidence = 0.4;
    const r = scoreFeatures(f);
    expect(r.probability).toBeLessThan(base);
    expect(r.contributions.avgQuestionConfidence).toBeLessThan(0);
  });

  it("low grounding score lowers probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.avgGroundingScore = 0.5;
    const r = scoreFeatures(f);
    expect(r.probability).toBeLessThan(base);
    expect(r.contributions.avgGroundingScore).toBeLessThan(0);
  });

  it("lots of complex questions lower probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.complexityDist = { simple: 0.3, moderate: 0.2, complex: 0.5 };
    const r = scoreFeatures(f);
    expect(r.probability).toBeLessThan(base);
    expect(r.contributions.complexity).toBeLessThan(0);
  });

  it("high out-of-scope share lowers probability sharply", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.eligibilityDist = { answerable: 0.4, needs_info: 0.3, out_of_scope: 0.3 };
    const r = scoreFeatures(f);
    expect(r.probability).toBeLessThan(base);
    expect(r.contributions.outOfScope).toBeLessThan(0);
  });

  it("rush deadline lowers probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.daysToDeadline = 1;
    const r = scoreFeatures(f);
    expect(r.probability).toBeLessThan(base);
    expect(r.contributions.daysToDeadline).toBeLessThan(0);
  });

  it("stale source base lowers probability", () => {
    const base = scoreFeatures(neutral()).probability;
    const f = neutral();
    f.daysSinceOldestSource = 1000;
    const r = scoreFeatures(f);
    expect(r.probability).toBeLessThan(base);
    expect(r.contributions.sourceStaleness).toBeLessThan(0);
  });
});

// ---------------------------------------------------------------------------
// Threshold + classifier sanity.
// ---------------------------------------------------------------------------

describe("classify() — threshold boundaries are honoured", () => {
  it("returns go above the GO threshold", () => {
    expect(classify(GO_THRESHOLD + 0.01)).toBe("go");
    expect(classify(0.9)).toBe("go");
  });

  it("returns review at and above NO_BID, below GO", () => {
    expect(classify(NO_BID_THRESHOLD)).toBe("review");
    expect(classify(0.4)).toBe("review");
    expect(classify(GO_THRESHOLD - 0.01)).toBe("review");
  });

  it("returns no_bid below the NO_BID threshold", () => {
    expect(classify(NO_BID_THRESHOLD - 0.01)).toBe("no_bid");
    expect(classify(0.1)).toBe("no_bid");
  });
});

describe("scoreFeatures() — full-stack thresholds", () => {
  it("produces GO when many positive signals fire", () => {
    const r = scoreFeatures({
      ...neutral(),
      historicalWinRate: 0.8,
      avgQuestionConfidence: 0.9,
      avgGroundingScore: 0.9,
      hasGoldenAnswerCoverage: 0.8,
      similarRfpWinRate: 0.75,
    });
    expect(r.recommendation).toBe("go");
    expect(r.probability).toBeGreaterThanOrEqual(GO_THRESHOLD);
  });

  it("produces NO_BID when many negative signals fire", () => {
    const r = scoreFeatures({
      ...neutral(),
      historicalWinRate: 0.15,
      avgQuestionConfidence: 0.3,
      avgGroundingScore: 0.4,
      complexityDist: { simple: 0.2, moderate: 0.2, complex: 0.6 },
      eligibilityDist: { answerable: 0.3, needs_info: 0.4, out_of_scope: 0.3 },
      daysToDeadline: 1,
      similarRfpWinRate: 0.15,
      daysSinceOldestSource: 900,
    });
    expect(r.recommendation).toBe("no_bid");
    expect(r.probability).toBeLessThan(NO_BID_THRESHOLD);
  });
});

describe("MODEL_VERSION stability", () => {
  it("is the documented v1 string until the formula is bumped", () => {
    expect(MODEL_VERSION).toBe("win-predictor-v1");
  });
});
