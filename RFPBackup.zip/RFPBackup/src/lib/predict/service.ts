// Win-prediction service — orchestrates feature extraction, scoring, and
// persistence into the WinPrediction table.
//
// Three entry points:
//   * `scoreRfp(rfpId)` — compute features and a score in-memory. Pure
//     read-only; useful for previews and tests.
//   * `persistPrediction(rfpId, result)` — upsert a single WinPrediction
//     row. Idempotent; safe to call repeatedly.
//   * `scoreAndPersist(rfpId)` — the workhorse. Called from the RFP
//     pipeline post-processing and from the prediction routes.
//   * `applyOverride(opts)` — admin lever. Pins overrideAction to
//     "go" / "no_bid", or clears it back to null.
//
// Persistence contract:
//   * One WinPrediction row per RFP (`rfpId` is unique on the model).
//   * `features` and `contributions` are stored as JSON snapshots so the
//     UI can render the same numbers the scorer saw, even after the
//     formula is bumped.
//   * `overrideAction` / `overrideById` / `overrideAt` are not touched by
//     `scoreAndPersist` — they live in their own column trio and are only
//     mutated by `applyOverride`. This means a re-score doesn't blow away
//     a human override.

import { prisma } from "@/lib/prisma";
import { extractFeatures, type PredictionFeatures } from "./features";
import {
  scoreFeatures,
  type ScoreResult,
  type Recommendation,
  MODEL_VERSION,
} from "./scorer";
import {
  winPredictionsTotal,
  winPredictionProbability,
} from "@/lib/metrics";

export type { Recommendation } from "./scorer";

export interface ScoreWithFeatures extends ScoreResult {
  features: PredictionFeatures;
}

/**
 * Compute features + score for `rfpId` without writing to the DB. Throws
 * when the RFP doesn't exist (delegates to `extractFeatures`).
 */
export async function scoreRfp(rfpId: string): Promise<ScoreWithFeatures> {
  const features = await extractFeatures(rfpId);
  const result = scoreFeatures(features);
  return { ...result, features };
}

/**
 * Upsert the WinPrediction row for `rfpId`. Idempotent — the unique
 * constraint on `rfpId` means repeated calls overwrite the previous
 * snapshot. Override fields are preserved across upserts (we never
 * include them in either branch of the upsert).
 */
export async function persistPrediction(
  rfpId: string,
  result: ScoreWithFeatures,
): Promise<void> {
  const data = {
    probability: result.probability,
    recommendation: result.recommendation,
    // Prisma's JSON column requires `unknown` casts to feed through plain
    // serialisable objects without forcing callers to import the
    // Prisma-internal `InputJsonValue` type.
    features: result.features as unknown as never,
    contributions: result.contributions as unknown as never,
    modelVersion: result.modelVersion,
  };
  await prisma.winPrediction.upsert({
    where: { rfpId },
    create: { rfpId, ...data },
    update: data,
  });

  // Telemetry — best-effort.
  try {
    winPredictionsTotal.inc({ recommendation: result.recommendation });
    winPredictionProbability.observe({}, result.probability);
  } catch {
    // Swallow — telemetry never breaks the persistence path.
  }
}

/**
 * Score + persist in one call. Used by the RFP pipeline and the route.
 * Returns the in-memory result so callers can also include it in a
 * synchronous response. Errors are propagated — callers that want
 * fire-and-forget semantics should `void scoreAndPersist(...)`.
 */
export async function scoreAndPersist(rfpId: string): Promise<ScoreWithFeatures> {
  const result = await scoreRfp(rfpId);
  await persistPrediction(rfpId, result);
  return result;
}

/**
 * Apply or clear a human override on the prediction. Passing `action: null`
 * clears the override (back to model-driven recommendations). Requires the
 * WinPrediction row to already exist — call `scoreAndPersist` first.
 */
export async function applyOverride(opts: {
  rfpId: string;
  action: "go" | "no_bid" | null;
  userId: string;
}): Promise<void> {
  // Ensure a row exists so the update has something to mutate. Cheap noop
  // when one already does.
  const existing = await prisma.winPrediction.findUnique({
    where: { rfpId: opts.rfpId },
    select: { id: true },
  });
  if (!existing) {
    // Bootstrap the row from a fresh score so downstream queries don't 404
    // when an admin pins an override on a never-scored RFP.
    const result = await scoreRfp(opts.rfpId);
    await persistPrediction(opts.rfpId, result);
  }

  if (opts.action === null) {
    await prisma.winPrediction.update({
      where: { rfpId: opts.rfpId },
      data: { overrideAction: null, overrideById: null, overrideAt: null },
    });
    return;
  }

  await prisma.winPrediction.update({
    where: { rfpId: opts.rfpId },
    data: {
      overrideAction: opts.action,
      overrideById: opts.userId,
      overrideAt: new Date(),
    },
  });
}

/** Re-export for callers that read the version stamp. */
export { MODEL_VERSION };
