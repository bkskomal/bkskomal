import { describe, expect, it, vi, beforeEach } from "vitest";

// Mock Prisma before importing the module under test.
const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
      groupBy: vi.fn(),
      findMany: vi.fn(),
    },
    goldenAnswer: {
      findMany: vi.fn(),
    },
    document: {
      findFirst: vi.fn(),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

import { extractFeatures } from "./features";

// ---------------------------------------------------------------------------
// Fixtures.
// ---------------------------------------------------------------------------

const RFP_ID = "rfp_1";
const ORG_ID = "org_1";

function buildRfp(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: RFP_ID,
    dueDate: null,
    project: { organizationId: ORG_ID },
    questions: [],
    ...overrides,
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  // Sensible defaults: empty everything except the RFP shell.
  prismaMock.rFP.findUnique.mockResolvedValue(buildRfp());
  prismaMock.rFP.groupBy.mockResolvedValue([]);
  prismaMock.rFP.findMany.mockResolvedValue([]);
  prismaMock.goldenAnswer.findMany.mockResolvedValue([]);
  prismaMock.document.findFirst.mockResolvedValue(null);
});

// ---------------------------------------------------------------------------
// Empty / baseline RFP.
// ---------------------------------------------------------------------------

describe("extractFeatures() — empty RFP baseline", () => {
  it("returns neutral defaults for an RFP with no questions, no priors", async () => {
    const f = await extractFeatures(RFP_ID);
    expect(f.questionCount).toBe(0);
    expect(f.avgQuestionConfidence).toBe(0);
    expect(f.avgGroundingScore).toBe(0);
    expect(f.complexityDist).toEqual({ simple: 0, moderate: 0, complex: 0 });
    expect(f.eligibilityDist).toEqual({
      answerable: 0,
      needs_info: 0,
      out_of_scope: 0,
    });
    expect(f.daysToDeadline).toBeNull();
    // No decided RFPs in the org → fallback to 0.5.
    expect(f.historicalWinRate).toBe(0.5);
    expect(f.similarRfpCount).toBe(0);
    expect(f.similarRfpWinRate).toBeNull();
    expect(f.hasGoldenAnswerCoverage).toBe(0);
    expect(f.daysSinceOldestSource).toBeNull();
  });

  it("throws when the RFP is missing", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(null);
    await expect(extractFeatures(RFP_ID)).rejects.toThrow(/not found/i);
  });
});

// ---------------------------------------------------------------------------
// Mixed-complexity RFP with confidence / grounding data.
// ---------------------------------------------------------------------------

describe("extractFeatures() — mixed complexity / eligibility distributions", () => {
  it("emits correct fractions and averages", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(
      buildRfp({
        questions: [
          {
            id: "q1",
            text: "Describe your security posture and SOC 2 controls",
            confidence: 0.9,
            complexity: "simple",
            eligibility: "answerable",
            topic: "security",
            responses: [{ groundingScore: 0.95 }],
          },
          {
            id: "q2",
            text: "What is your data retention policy?",
            confidence: 0.7,
            complexity: "simple",
            eligibility: "answerable",
            topic: "security",
            responses: [{ groundingScore: 0.85 }],
          },
          {
            id: "q3",
            text: "Highly bespoke government compliance frameworks",
            confidence: 0.3,
            complexity: "complex",
            eligibility: "out_of_scope",
            topic: "compliance",
            responses: [{ groundingScore: 0.5 }],
          },
          {
            id: "q4",
            text: "Specific deployment topology for our tenant",
            confidence: null,
            complexity: "moderate",
            eligibility: "needs_info",
            topic: "deployment",
            responses: [],
          },
        ],
      }),
    );
    const f = await extractFeatures(RFP_ID);
    expect(f.questionCount).toBe(4);
    // Avg of 0.9, 0.7, 0.3 (null filtered)
    expect(f.avgQuestionConfidence).toBeCloseTo((0.9 + 0.7 + 0.3) / 3, 5);
    // Avg of 0.95, 0.85, 0.5
    expect(f.avgGroundingScore).toBeCloseTo((0.95 + 0.85 + 0.5) / 3, 5);
    expect(f.complexityDist.simple).toBeCloseTo(0.5, 5);
    expect(f.complexityDist.moderate).toBeCloseTo(0.25, 5);
    expect(f.complexityDist.complex).toBeCloseTo(0.25, 5);
    expect(f.eligibilityDist.answerable).toBeCloseTo(0.5, 5);
    expect(f.eligibilityDist.needs_info).toBeCloseTo(0.25, 5);
    expect(f.eligibilityDist.out_of_scope).toBeCloseTo(0.25, 5);
  });
});

// ---------------------------------------------------------------------------
// Org priors: historical win rate + similar-RFP lookup.
// ---------------------------------------------------------------------------

describe("extractFeatures() — historical and similar-RFP signals", () => {
  it("computes historical win rate from decided outcomes", async () => {
    prismaMock.rFP.groupBy.mockResolvedValueOnce([
      { outcome: "WON", _count: { _all: 6 } },
      { outcome: "LOST", _count: { _all: 4 } },
      { outcome: "PENDING", _count: { _all: 10 } },
      { outcome: "WITHDRAWN", _count: { _all: 2 } },
    ]);
    const f = await extractFeatures(RFP_ID);
    expect(f.historicalWinRate).toBeCloseTo(0.6, 5);
  });

  it("finds similar RFPs via the dominant-topic substring match", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(
      buildRfp({
        questions: [
          { id: "a", text: "x", confidence: null, complexity: null, eligibility: null, topic: "security", responses: [] },
          { id: "b", text: "y", confidence: null, complexity: null, eligibility: null, topic: "security", responses: [] },
          { id: "c", text: "z", confidence: null, complexity: null, eligibility: null, topic: "pricing", responses: [] },
        ],
      }),
    );
    prismaMock.rFP.findMany.mockResolvedValueOnce([
      { id: "past_1", outcome: "WON" },
      { id: "past_2", outcome: "WON" },
      { id: "past_3", outcome: "LOST" },
      { id: "past_4", outcome: "PENDING" },
    ]);
    const f = await extractFeatures(RFP_ID);
    expect(f.similarRfpCount).toBe(4);
    expect(f.similarRfpWinRate).toBeCloseTo(2 / 3, 5);
    // Verify the where clause uses the dominant topic.
    const findManyCall = prismaMock.rFP.findMany.mock.calls[0][0];
    expect(findManyCall.where.questions.some.topic.contains).toBe("security");
    expect(findManyCall.where.questions.some.topic.mode).toBe("insensitive");
  });

  it("returns null similarRfpWinRate when no decided similar RFPs", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(
      buildRfp({
        questions: [
          { id: "a", text: "x", confidence: null, complexity: null, eligibility: null, topic: "novel-topic", responses: [] },
        ],
      }),
    );
    prismaMock.rFP.findMany.mockResolvedValueOnce([
      { id: "past_1", outcome: "PENDING" },
    ]);
    const f = await extractFeatures(RFP_ID);
    expect(f.similarRfpCount).toBe(1);
    expect(f.similarRfpWinRate).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Deadline / source freshness signals.
// ---------------------------------------------------------------------------

describe("extractFeatures() — deadline and source freshness", () => {
  it("computes daysToDeadline from RFP.dueDate", async () => {
    const due = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);
    prismaMock.rFP.findUnique.mockResolvedValueOnce(buildRfp({ dueDate: due }));
    const f = await extractFeatures(RFP_ID);
    // Allow off-by-one (rounding around midnight)
    expect(f.daysToDeadline).toBeGreaterThanOrEqual(4);
    expect(f.daysToDeadline).toBeLessThanOrEqual(5);
  });

  it("computes daysSinceOldestSource", async () => {
    const old = new Date(Date.now() - 800 * 24 * 60 * 60 * 1000);
    prismaMock.document.findFirst.mockResolvedValueOnce({ createdAt: old });
    const f = await extractFeatures(RFP_ID);
    expect(f.daysSinceOldestSource).toBeGreaterThanOrEqual(799);
  });
});

// ---------------------------------------------------------------------------
// Golden answer coverage.
// ---------------------------------------------------------------------------

describe("extractFeatures() — golden answer coverage", () => {
  it("matches questions to goldens via shared long tokens", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(
      buildRfp({
        questions: [
          {
            id: "q1",
            text: "Describe your SOC2 audit reports and information security program",
            confidence: null,
            complexity: null,
            eligibility: null,
            topic: null,
            responses: [],
          },
          {
            id: "q2",
            text: "What flavor of ice cream do your engineers prefer?",
            confidence: null,
            complexity: null,
            eligibility: null,
            topic: null,
            responses: [],
          },
        ],
      }),
    );
    prismaMock.goldenAnswer.findMany.mockResolvedValueOnce([
      {
        question:
          "Please describe your information security program and SOC2 audit attestations",
      },
    ]);
    const f = await extractFeatures(RFP_ID);
    expect(f.hasGoldenAnswerCoverage).toBeCloseTo(0.5, 5);
  });
});
