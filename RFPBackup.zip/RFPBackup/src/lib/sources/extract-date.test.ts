import { describe, expect, it, vi, beforeEach } from "vitest";

// ---------------------------------------------------------------------------
// Mocks. The LLM pass calls into getAiClients, so we stub the AI client
// factory before importing the module under test. Everything else (filename
// + body-regex passes) is pure, no DB / no AI.
// ---------------------------------------------------------------------------

const { getAiClientsMock } = vi.hoisted(() => ({
  getAiClientsMock: vi.fn(),
}));

vi.mock("@/lib/ai/client", () => ({
  getAiClients: (...args: unknown[]) => getAiClientsMock(...args),
}));

import {
  extractDateFromBody,
  extractDateFromBodyLLM,
  extractDateFromFilename,
  detectSourceDate,
} from "./extract-date";

beforeEach(() => {
  getAiClientsMock.mockReset();
});

// ---------------------------------------------------------------------------
// Filename pass — checks each regex branch the heuristic claims to cover.
// ---------------------------------------------------------------------------

describe("extractDateFromFilename", () => {
  it("hits on a bare YYYY", () => {
    const r = extractDateFromFilename("SOC2-2022.pdf");
    expect(r).not.toBeNull();
    expect(r!.date.getUTCFullYear()).toBe(2022);
    expect(r!.date.getUTCMonth()).toBe(0); // Jan
    expect(r!.source).toBe("filename");
    expect(r!.confidence).toBeCloseTo(0.7, 5);
  });

  it("hits on a YYYY-MM-DD", () => {
    const r = extractDateFromFilename("policy-2024-03-15.docx");
    expect(r).not.toBeNull();
    expect(r!.date.toISOString().slice(0, 10)).toBe("2024-03-15");
  });

  it("hits on a Q3-YYYY", () => {
    const r = extractDateFromFilename("Q3-2024 roadmap.pptx");
    expect(r).not.toBeNull();
    // Q3 = July
    expect(r!.date.getUTCMonth()).toBe(6);
    expect(r!.date.getUTCFullYear()).toBe(2024);
  });

  it("hits on FY2024", () => {
    const r = extractDateFromFilename("FY2024 pricing.xlsx");
    expect(r).not.toBeNull();
    expect(r!.date.getUTCFullYear()).toBe(2024);
    // FY end ~ June 30
    expect(r!.date.getUTCMonth()).toBe(5);
    expect(r!.date.getUTCDate()).toBe(30);
  });

  it("hits on FY24 (two-digit)", () => {
    const r = extractDateFromFilename("FY24-budget.xlsx");
    expect(r).not.toBeNull();
    expect(r!.date.getUTCFullYear()).toBe(2024);
  });

  it("returns null when no date is present", () => {
    expect(extractDateFromFilename("security-policy.pdf")).toBeNull();
    expect(extractDateFromFilename("")).toBeNull();
  });

  it("rejects out-of-range years (1989, 2031)", () => {
    expect(extractDateFromFilename("legacy-1989.pdf")).toBeNull();
    expect(extractDateFromFilename("future-2031.pdf")).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Body-regex pass — the labelled patterns that catch "as of", effective,
// audit period, copyright, etc.
// ---------------------------------------------------------------------------

describe("extractDateFromBody", () => {
  it("catches 'As of January 15, 2024'", () => {
    const r = extractDateFromBody("Cover page.\nAs of January 15, 2024\nMore content.");
    expect(r).not.toBeNull();
    expect(r!.date.toISOString().slice(0, 10)).toBe("2024-01-15");
    expect(r!.source).toBe("regex_body");
    expect(r!.confidence).toBeCloseTo(0.8, 5);
  });

  it("catches 'Effective 2023-12-01'", () => {
    const r = extractDateFromBody("Effective 2023-12-01 — this policy supersedes…");
    expect(r).not.toBeNull();
    expect(r!.date.toISOString().slice(0, 10)).toBe("2023-12-01");
  });

  it("returns the END date of an audit period", () => {
    const r = extractDateFromBody(
      "Audit period: April 1, 2023 — March 31, 2024\nIssued by Acme Auditors",
    );
    expect(r).not.toBeNull();
    expect(r!.date.toISOString().slice(0, 10)).toBe("2024-03-31");
  });

  it("falls back to copyright year", () => {
    const r = extractDateFromBody("Long preamble with no real dates.\n© 2022 Example Corp.");
    expect(r).not.toBeNull();
    expect(r!.date.getUTCFullYear()).toBe(2022);
  });

  it("returns null on unrelated prose", () => {
    expect(
      extractDateFromBody("This document explains our security posture. Nothing dated here."),
    ).toBeNull();
  });

  it("picks the FIRST match by buffer position when multiple patterns fire", () => {
    const text = [
      "Some intro text.",
      "As of January 15, 2024",
      "© 2020 Example Corp.",
      "Last updated March 1, 2025",
    ].join("\n");
    const r = extractDateFromBody(text);
    expect(r).not.toBeNull();
    // The "as of" hit comes first in the buffer.
    expect(r!.date.toISOString().slice(0, 10)).toBe("2024-01-15");
  });
});

// ---------------------------------------------------------------------------
// LLM pass — verifies the JSON parse path and the failure-returns-null
// contract. We don't exercise a live model; the canned completion stands in
// for whatever the org's configured LLM would say.
// ---------------------------------------------------------------------------

describe("extractDateFromBodyLLM", () => {
  it("returns an ExtractedDate when the LLM returns valid JSON", async () => {
    getAiClientsMock.mockResolvedValueOnce({
      config: { llm: { model: "test-model" } },
      llm: {
        chat: {
          completions: {
            create: vi.fn().mockResolvedValueOnce({
              choices: [
                {
                  message: {
                    content: JSON.stringify({
                      date: "2023-09-30",
                      rationale: "audit window ended Sep 30 2023",
                    }),
                  },
                },
              ],
            }),
          },
        },
      },
    });

    const r = await extractDateFromBodyLLM("dummy text", "org_1");
    expect(r).not.toBeNull();
    expect(r!.date.toISOString().slice(0, 10)).toBe("2023-09-30");
    expect(r!.source).toBe("llm");
    expect(r!.confidence).toBeCloseTo(0.6, 5);
    expect(r!.rationale).toContain("audit");
  });

  it("returns null when the LLM says it can't find a date", async () => {
    getAiClientsMock.mockResolvedValueOnce({
      config: { llm: { model: "test-model" } },
      llm: {
        chat: {
          completions: {
            create: vi.fn().mockResolvedValueOnce({
              choices: [{ message: { content: JSON.stringify({ date: null }) } }],
            }),
          },
        },
      },
    });
    expect(await extractDateFromBodyLLM("text", "org_1")).toBeNull();
  });

  it("returns null and swallows errors when the LLM call throws", async () => {
    getAiClientsMock.mockRejectedValueOnce(new Error("breaker open"));
    expect(await extractDateFromBodyLLM("text", "org_1")).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Dispatcher — filename beats body beats LLM, useLLM gate works.
// ---------------------------------------------------------------------------

describe("detectSourceDate", () => {
  it("prefers filename when it hits", async () => {
    const r = await detectSourceDate({
      fileName: "SOC2-2022.pdf",
      text: "As of January 15, 2024",
      orgId: "org_1",
    });
    expect(r!.source).toBe("filename");
    expect(r!.date.getUTCFullYear()).toBe(2022);
  });

  it("falls through to body regex when filename has no date", async () => {
    const r = await detectSourceDate({
      fileName: "security-policy.pdf",
      text: "Effective 2024-01-15",
      orgId: "org_1",
    });
    expect(r!.source).toBe("regex_body");
  });

  it("only calls the LLM when useLLM=true", async () => {
    // Should not call LLM when useLLM is false (the default).
    const r1 = await detectSourceDate({
      fileName: "x.pdf",
      text: "no date here",
      orgId: "org_1",
    });
    expect(r1).toBeNull();
    expect(getAiClientsMock).not.toHaveBeenCalled();

    getAiClientsMock.mockResolvedValueOnce({
      config: { llm: { model: "m" } },
      llm: {
        chat: {
          completions: {
            create: vi.fn().mockResolvedValueOnce({
              choices: [{ message: { content: JSON.stringify({ date: "2021" }) } }],
            }),
          },
        },
      },
    });
    const r2 = await detectSourceDate({
      fileName: "x.pdf",
      text: "no date here",
      orgId: "org_1",
      useLLM: true,
    });
    expect(r2!.source).toBe("llm");
    expect(r2!.date.getUTCFullYear()).toBe(2021);
    expect(getAiClientsMock).toHaveBeenCalledTimes(1);
  });

  it("returns null when nothing matches", async () => {
    expect(
      await detectSourceDate({
        fileName: "doc.pdf",
        text: "nothing of interest",
        orgId: "org_1",
      }),
    ).toBeNull();
  });
});
