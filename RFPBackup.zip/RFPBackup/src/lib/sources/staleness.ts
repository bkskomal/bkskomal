// Stale-source detection — verdict + rescan (Tier B2).
//
// Companion to `extract-date.ts`. Given a document's detected sourceDate plus
// filename, decide whether the document is "stale" — older than the org's
// threshold. Category overrides allow specific topic families to decay faster
// than the default (audit reports, pricing, roadmaps).
//
// Persistence model: the schema has NO `isStale` column. Instead we use
// `staleReason String?` as a tri-state:
//   - null               → not stale (within threshold OR no sourceDate)
//   - non-null string    → stale; the string explains why
// This keeps queries cheap (`WHERE staleReason IS NOT NULL`) without a
// dedicated boolean column, and the message becomes the tooltip text in the
// UI.
//
// `refreshStalenessForOrg` is idempotent: re-running it after a threshold
// change rewrites every Document's `staleReason` from the same inputs. We
// only PATCH rows whose state actually flips so the route is cheap to call
// in admin workflows.

import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";

export interface StalenessRule {
  /** Default age (in days) beyond which a doc is stale. */
  thresholdDays: number;
  /**
   * Per-category overrides, keyed by a lowercase substring matched against
   * the filename. First match (insertion order of `Object.entries`) wins.
   * Values are days.
   */
  categoryOverrides?: Record<string, number>;
}

export interface StalenessVerdict {
  isStale: boolean;
  /** Age of the document in days, or null when sourceDate is unknown. */
  daysOld: number | null;
  /** Threshold (in days) that applied to this document. */
  threshold: number;
  /** Brief human-readable reason. Only populated when `isStale` is true. */
  reason?: string;
}

/**
 * Default category overrides. Lowercase substring → threshold (days).
 *
 *   soc2 / soc 2     → 365   (audit reports lapse yearly)
 *   iso 27001        → 1095  (3-year recertification cycle)
 *   pricing          → 180   (prices change frequently)
 *   policy/handbook  → 730   (annual review is typical; matches default)
 *   roadmap          → 90    (anything older than a quarter is misleading)
 *
 * Ordered most-specific first so "soc 2 audit report" hits SOC2 rather than
 * the more generic "policy".
 */
export const DEFAULT_CATEGORY_OVERRIDES: Record<string, number> = {
  soc2: 365,
  "soc 2": 365,
  "iso 27001": 1095,
  iso27001: 1095,
  pricing: 180,
  "price list": 180,
  policy: 730,
  handbook: 730,
  roadmap: 90,
};

const DAY_MS = 24 * 60 * 60 * 1000;

/**
 * Resolve the effective threshold for `fileName` against the configured
 * overrides. Returns the default when nothing matches. Exposed for tests
 * and the refresh route — most callers should just use `evaluateStaleness`.
 */
export function resolveThreshold(
  fileName: string,
  rule: StalenessRule,
): { threshold: number; category: string | null } {
  const lower = (fileName ?? "").toLowerCase();
  const overrides = rule.categoryOverrides ?? {};
  for (const [keyword, days] of Object.entries(overrides)) {
    if (lower.includes(keyword)) {
      return { threshold: days, category: keyword };
    }
  }
  return { threshold: rule.thresholdDays, category: null };
}

/**
 * Build the active rule from env defaults merged with a per-call override.
 * The merge is one-level: a caller-supplied `categoryOverrides` REPLACES the
 * default map entirely (rather than spreading). That keeps the contract
 * predictable for tests that need to isolate a single keyword.
 */
function resolveRule(partial?: Partial<StalenessRule>): StalenessRule {
  return {
    thresholdDays: partial?.thresholdDays ?? env.STALE_SOURCE_THRESHOLD_DAYS,
    categoryOverrides: partial?.categoryOverrides ?? DEFAULT_CATEGORY_OVERRIDES,
  };
}

/**
 * Decide whether a single document is stale. Pure function — same inputs
 * always produce the same verdict.
 *
 * Algorithm:
 *   1. No sourceDate → not stale (unknown ≠ proven old).
 *   2. Resolve threshold via category overrides on filename.
 *   3. Compute age in days. If age > threshold, flag stale with a reason
 *      that names the category (when matched) and the days delta.
 */
export function evaluateStaleness(opts: {
  sourceDate: Date | null;
  fileName: string;
  rule?: Partial<StalenessRule>;
  /** Override "now" for tests; defaults to system clock. */
  now?: Date;
}): StalenessVerdict {
  const rule = resolveRule(opts.rule);
  const { threshold, category } = resolveThreshold(opts.fileName ?? "", rule);

  if (!opts.sourceDate || !(opts.sourceDate instanceof Date) || Number.isNaN(opts.sourceDate.getTime())) {
    return { isStale: false, daysOld: null, threshold };
  }

  const now = opts.now ?? new Date();
  const daysOld = Math.floor((now.getTime() - opts.sourceDate.getTime()) / DAY_MS);
  if (daysOld <= threshold) {
    return { isStale: false, daysOld, threshold };
  }

  const label = category ? friendlyLabel(category) : "Document";
  const reason = `${label} > ${threshold} days old (age: ${daysOld} days)`;
  return { isStale: true, daysOld, threshold, reason };
}

/**
 * Pretty-print a category keyword for use in a reason string. We don't want
 * "SOC2 audit report > 365 days old" but we DO want the category to read
 * naturally — "soc2" → "SOC2", "iso 27001" → "ISO 27001 cert", "pricing"
 * → "Pricing sheet", etc.
 */
function friendlyLabel(category: string): string {
  switch (category) {
    case "soc2":
    case "soc 2":
      return "SOC2 audit report";
    case "iso 27001":
    case "iso27001":
      return "ISO 27001 certification";
    case "pricing":
    case "price list":
      return "Pricing sheet";
    case "policy":
      return "Policy";
    case "handbook":
      return "Handbook";
    case "roadmap":
      return "Roadmap";
    default:
      return category.replace(/\b\w/g, (c) => c.toUpperCase());
  }
}

/**
 * Re-scan every Document in `orgId` and update its `staleReason` based on
 * the current rule. Returns counts. Idempotent — re-running with the same
 * inputs is a no-op DB-wise (we only PATCH rows whose state actually flips
 * so the call is cheap to retry after a threshold change).
 *
 * Cross-references:
 *   - The route POST .../sources/refresh-staleness/ wraps this with auth +
 *     audit logging.
 *   - The ingest hook calls evaluateStaleness directly on a single doc; this
 *     batched form is the catch-up path for docs uploaded before B2 shipped
 *     or after the org operator tweaks the threshold.
 */
export async function refreshStalenessForOrg(
  orgId: string,
): Promise<{ scanned: number; flagged: number }> {
  const docs = await prisma.document.findMany({
    where: { index: { organizationId: orgId } },
    select: {
      id: true,
      fileName: true,
      sourceDate: true,
      staleReason: true,
    },
  });

  let flagged = 0;
  const now = new Date();
  for (const d of docs) {
    const verdict = evaluateStaleness({
      sourceDate: d.sourceDate,
      fileName: d.fileName,
      now,
    });
    const wasStale = d.staleReason !== null;
    // Only PATCH on a state flip. The reason string includes the age in days,
    // which drifts day-by-day — comparing on the full string would rewrite
    // every still-stale row on every run. The original reason is good enough
    // for the UI tooltip; we'd rather skip the write.
    if (verdict.isStale !== wasStale) {
      const nextReason = verdict.isStale ? verdict.reason ?? "stale" : null;
      await prisma.document.update({
        where: { id: d.id },
        data: { staleReason: nextReason },
      });
    }
    if (verdict.isStale) flagged++;
  }

  return { scanned: docs.length, flagged };
}
