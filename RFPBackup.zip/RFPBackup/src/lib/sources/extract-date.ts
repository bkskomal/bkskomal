// Stale-source detection — "as of" date extraction (Tier B2).
//
// Three-pass heuristic for figuring out when a knowledge-base document was
// authored / last updated. Used downstream by `evaluateStaleness` to decide
// whether an answer that cites this document should carry a "stale source"
// warning.
//
// Pass order (first hit wins):
//   1. Filename — cheapest, often surprisingly reliable. "SOC2-2022.pdf",
//      "Q3-2024 roadmap.pptx", "FY2024 pricing.xlsx", etc.
//   2. Body regex — first-page-style patterns: "As of <date>", "Effective
//      <date>", "© 2023", "Last updated <date>", "Revision: <date>", and
//      audit-period end dates.
//   3. LLM — only when explicitly opted into (`useLLM=true`). Sends the
//      first 4k chars of body text to the org's configured LLM and asks for
//      an ISO date. Skipped by default because most docs hit a regex.
//
// Each pass returns `{ date, source, confidence, rationale }`. Confidence
// values are tuned so a filename hit (0.7) beats nothing, a body-regex hit
// (0.8) beats a filename hit when they disagree, and the LLM (0.6) is the
// last resort. The dispatcher `detectSourceDate` runs the passes in order
// and returns the first non-null result.

import { getAiClients } from "@/lib/ai/client";
import { stripCodeFences } from "@/lib/ai/json-utils";
import { SOURCE_DATE_EXTRACTION_SYSTEM } from "@/lib/ai/prompts";
import { log } from "@/lib/logger";

export interface ExtractedDate {
  date: Date;
  source: "filename" | "regex_body" | "llm";
  confidence: number; // 0..1
  rationale: string;
}

// --- Constants used across passes -------------------------------------------

const MIN_YEAR = 1990;
const MAX_YEAR = 2030;

const MONTH_NAMES = [
  "january",
  "february",
  "march",
  "april",
  "may",
  "june",
  "july",
  "august",
  "september",
  "october",
  "november",
  "december",
];
const SHORT_MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

function monthIndex(name: string): number {
  const lower = name.toLowerCase();
  const full = MONTH_NAMES.indexOf(lower);
  if (full !== -1) return full;
  return SHORT_MONTHS.indexOf(lower.slice(0, 3));
}

function clampYear(year: number): boolean {
  return year >= MIN_YEAR && year <= MAX_YEAR;
}

/**
 * Build a UTC Date from y/m/d while validating ranges. Invalid combinations
 * (Feb 30, month 13, etc.) return null rather than the JS auto-rollover.
 */
function safeDate(year: number, month: number, day: number): Date | null {
  if (!clampYear(year)) return null;
  if (month < 0 || month > 11) return null;
  if (day < 1 || day > 31) return null;
  const d = new Date(Date.UTC(year, month, day));
  if (d.getUTCFullYear() !== year || d.getUTCMonth() !== month || d.getUTCDate() !== day) {
    return null;
  }
  return d;
}

// ---------------------------------------------------------------------------
// 1. Filename pass
// ---------------------------------------------------------------------------

/**
 * Try to pull a date out of a filename. Matches (in order):
 *   - YYYY-MM-DD                  → exact date
 *   - YYYY-MM                     → 1st of the month
 *   - Q[1-4]-YYYY or QnYYYY       → first day of the quarter
 *   - FY24 / FY2024               → June 30 of the fiscal year end
 *   - Bare YYYY (1990..2030)      → January 1 of that year
 *
 * Confidence 0.7 for any match.
 */
export function extractDateFromFilename(fileName: string): ExtractedDate | null {
  if (!fileName) return null;

  // Strip path + extension noise.
  const base = fileName.replace(/^.*[\\/]/, "").replace(/\.[a-z0-9]+$/i, "");

  // YYYY-MM-DD (or YYYY_MM_DD / YYYY.MM.DD).
  {
    const m = base.match(/(19[9]\d|20[0-2]\d|2030)[\-_.](0[1-9]|1[0-2])[\-_.](0[1-9]|[12]\d|3[01])/);
    if (m) {
      const d = safeDate(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
      if (d) {
        return {
          date: d,
          source: "filename",
          confidence: 0.7,
          rationale: `filename contains ISO date ${m[0]}`,
        };
      }
    }
  }

  // YYYY-MM.
  {
    const m = base.match(/(?<![\d])(19[9]\d|20[0-2]\d|2030)[\-_.](0[1-9]|1[0-2])(?![\d])/);
    if (m) {
      const d = safeDate(Number(m[1]), Number(m[2]) - 1, 1);
      if (d) {
        return {
          date: d,
          source: "filename",
          confidence: 0.7,
          rationale: `filename contains year-month ${m[0]}`,
        };
      }
    }
  }

  // Q1-2024 / Q1_2024 / Q1 2024 / Q12024.
  {
    const m = base.match(/\bQ([1-4])[\-_ ]?(19[9]\d|20[0-2]\d|2030)\b/i);
    if (m) {
      const q = Number(m[1]);
      const year = Number(m[2]);
      const month = (q - 1) * 3;
      const d = safeDate(year, month, 1);
      if (d) {
        return {
          date: d,
          source: "filename",
          confidence: 0.7,
          rationale: `filename contains quarter Q${q}-${year}`,
        };
      }
    }
  }

  // FY24 / FY2024. Treat as the end of the fiscal year ≈ June 30 of that year.
  // We don't know the org's fiscal calendar so this is a best-guess; the
  // staleness threshold check is robust to ±6 months.
  {
    const m = base.match(/\bFY[\-_ ]?(\d{2}|\d{4})\b/i);
    if (m) {
      let year = Number(m[1]);
      if (year < 100) year = year >= 50 ? 1900 + year : 2000 + year;
      const d = safeDate(year, 5, 30); // June 30
      if (d) {
        return {
          date: d,
          source: "filename",
          confidence: 0.7,
          rationale: `filename contains fiscal-year FY${m[1]}`,
        };
      }
    }
  }

  // Bare YYYY.
  {
    const m = base.match(/(?<![\d])(19[9]\d|20[0-2]\d|2030)(?![\d])/);
    if (m) {
      const d = safeDate(Number(m[1]), 0, 1);
      if (d) {
        return {
          date: d,
          source: "filename",
          confidence: 0.7,
          rationale: `filename contains year ${m[1]}`,
        };
      }
    }
  }

  return null;
}

// ---------------------------------------------------------------------------
// 2. Body-regex pass
// ---------------------------------------------------------------------------

/**
 * Parse a date string from a regex capture. Accepts:
 *   - YYYY-MM-DD
 *   - Month DD, YYYY     (e.g. "January 15, 2024")
 *   - DD Month YYYY      (e.g. "15 January 2024")
 *   - Month YYYY         (e.g. "January 2024" → 1st of month)
 *   - bare YYYY
 */
function parseFlexDate(raw: string): Date | null {
  const s = raw.trim().replace(/[,;.]+$/, "");

  // ISO YYYY-MM-DD.
  const iso = s.match(/^(19[9]\d|20[0-2]\d|2030)-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/);
  if (iso) return safeDate(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));

  // YYYY-MM
  const ym = s.match(/^(19[9]\d|20[0-2]\d|2030)-(0[1-9]|1[0-2])$/);
  if (ym) return safeDate(Number(ym[1]), Number(ym[2]) - 1, 1);

  // Month DD, YYYY.
  const mdy = s.match(
    /^(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(\d{1,2}),?\s+(19[9]\d|20[0-2]\d|2030)$/i,
  );
  if (mdy) {
    const m = monthIndex(mdy[1]);
    if (m >= 0) return safeDate(Number(mdy[3]), m, Number(mdy[2]));
  }

  // DD Month YYYY.
  const dmy = s.match(
    /^(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(19[9]\d|20[0-2]\d|2030)$/i,
  );
  if (dmy) {
    const m = monthIndex(dmy[2]);
    if (m >= 0) return safeDate(Number(dmy[3]), m, Number(dmy[1]));
  }

  // Month YYYY.
  const my = s.match(
    /^(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(19[9]\d|20[0-2]\d|2030)$/i,
  );
  if (my) {
    const m = monthIndex(my[1]);
    if (m >= 0) return safeDate(Number(my[2]), m, 1);
  }

  // Bare YYYY.
  const y = s.match(/^(19[9]\d|20[0-2]\d|2030)$/);
  if (y) return safeDate(Number(y[1]), 0, 1);

  return null;
}

// Date sub-pattern reused inside the labelled body patterns.
const DATE_SUBPATTERN = String.raw`(?:(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+\d{1,2},?\s+(?:19[9]\d|20[0-2]\d|2030)|\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(?:19[9]\d|20[0-2]\d|2030)|(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(?:19[9]\d|20[0-2]\d|2030)|(?:19[9]\d|20[0-2]\d|2030)-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])|(?:19[9]\d|20[0-2]\d|2030)-(?:0[1-9]|1[0-2])|(?:19[9]\d|20[0-2]\d|2030))`;

interface BodyPattern {
  /** Label used in the rationale string. */
  label: string;
  /** Compiled regex. Capture group 1 must be the date string. */
  re: RegExp;
}

const BODY_PATTERNS: BodyPattern[] = [
  // "As of January 15, 2024", "as of 2023-12-01"
  { label: "as of", re: new RegExp(`\\bas\\s+of\\s+(${DATE_SUBPATTERN})`, "i") },
  // "Effective January 15, 2024", "Effective Date: 2024-01-15"
  {
    label: "effective",
    re: new RegExp(`\\beffective(?:\\s+(?:as\\s+of|date|on))?[:\\s]+(${DATE_SUBPATTERN})`, "i"),
  },
  // "Audit period: April 1, 2023 — March 31, 2024" — take the END date.
  {
    label: "audit period",
    re: new RegExp(
      `\\baudit\\s+period[:\\s][^\\n]*?(?:-|—|–|to|through)\\s*(${DATE_SUBPATTERN})`,
      "i",
    ),
  },
  // "Reporting period: ... — <end>"
  {
    label: "reporting period",
    re: new RegExp(
      `\\breporting\\s+period[:\\s][^\\n]*?(?:-|—|–|to|through)\\s*(${DATE_SUBPATTERN})`,
      "i",
    ),
  },
  // "Last updated January 15, 2024"
  { label: "last updated", re: new RegExp(`\\blast\\s+updated[:\\s]+(${DATE_SUBPATTERN})`, "i") },
  // "Revision: 2024-01-15", "Revised: January 15, 2024"
  {
    label: "revision",
    re: new RegExp(`\\b(?:revision|revised)[:\\s]+(${DATE_SUBPATTERN})`, "i"),
  },
  // "Published: 2024-01-15"
  { label: "published", re: new RegExp(`\\bpublished[:\\s]+(${DATE_SUBPATTERN})`, "i") },
  // "© 2023", "(c) 2023", "Copyright 2023"
  {
    label: "copyright",
    re: /(?:©|\(c\)|copyright)\s*(19[9]\d|20[0-2]\d|2030)/i,
  },
];

/**
 * Scan the first ~16k chars of body text for any of the labelled patterns
 * above. Returns the FIRST match (by buffer position) so callers get a
 * deterministic result even when a doc carries several candidate dates.
 *
 * Confidence is 0.8 for all body-regex hits.
 */
export function extractDateFromBody(text: string): ExtractedDate | null {
  if (!text) return null;
  // We only look at the head of the document — title pages, cover sheets, and
  // audit boilerplate all live there. Scanning further is wasted work and
  // increases false positives (random "as of" phrases mid-document).
  const head = text.slice(0, 16000);

  let best: { idx: number; date: Date; label: string; raw: string } | null = null;

  for (const p of BODY_PATTERNS) {
    const m = head.match(p.re);
    if (!m || m.index == null) continue;
    const captured = m[1];
    const date = parseFlexDate(captured);
    if (!date) continue;
    if (!best || m.index < best.idx) {
      best = { idx: m.index, date, label: p.label, raw: captured };
    }
  }

  if (!best) return null;
  return {
    date: best.date,
    source: "regex_body",
    confidence: 0.8,
    rationale: `body matched "${best.label}" → ${best.raw}`,
  };
}

// ---------------------------------------------------------------------------
// 3. LLM pass
// ---------------------------------------------------------------------------

/**
 * Last-resort pass that asks the configured LLM to identify the "as of" date.
 * We send the first 4000 chars of the document body so the call stays cheap
 * (one inexpensive completion, no embeddings). Caller opts in via
 * `useLLM: true`; default `detectSourceDate` does NOT invoke this path.
 *
 * On any failure (timeout, parse error, model returns "unknown") we return
 * null and the caller falls back to no source date — never throws.
 */
export async function extractDateFromBodyLLM(
  text: string,
  orgId: string,
): Promise<ExtractedDate | null> {
  if (!text || !orgId) return null;
  const snippet = text.slice(0, 4000);
  try {
    const { llm, config } = await getAiClients(orgId);
    const completion = await llm.chat.completions.create({
      model: config.llm.model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SOURCE_DATE_EXTRACTION_SYSTEM },
        { role: "user", content: snippet },
      ],
    });
    const raw = completion.choices[0]?.message?.content ?? "";
    const parsed = JSON.parse(stripCodeFences(raw)) as { date?: string; rationale?: string };
    if (!parsed.date || typeof parsed.date !== "string") return null;
    // Accept either YYYY, YYYY-MM, or YYYY-MM-DD ISO output.
    const iso = parsed.date.trim();
    const date = parseFlexDate(iso);
    if (!date) return null;
    return {
      date,
      source: "llm",
      confidence: 0.6,
      rationale: parsed.rationale?.slice(0, 200) ?? `LLM extracted ${iso}`,
    };
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        orgId,
      },
      "source-date LLM extraction failed",
    );
    return null;
  }
}

// ---------------------------------------------------------------------------
// Dispatcher
// ---------------------------------------------------------------------------

/**
 * Try filename → body regex → (optionally) LLM, return the first hit.
 * Best-effort: never throws. Logs LLM errors and keeps going.
 */
export async function detectSourceDate(opts: {
  fileName: string;
  text: string;
  orgId: string;
  useLLM?: boolean;
}): Promise<ExtractedDate | null> {
  const fromName = extractDateFromFilename(opts.fileName);
  if (fromName) return fromName;
  const fromBody = extractDateFromBody(opts.text);
  if (fromBody) return fromBody;
  if (opts.useLLM) {
    const fromLlm = await extractDateFromBodyLLM(opts.text, opts.orgId);
    if (fromLlm) return fromLlm;
  }
  return null;
}
