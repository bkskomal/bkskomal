import { describe, expect, it, vi, beforeEach } from "vitest";

// ---------------------------------------------------------------------------
// Pure-logic tests for `evaluateStaleness` + an integration-style test for
// `refreshStalenessForOrg` against a mocked Prisma client.
// ---------------------------------------------------------------------------

const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    document: {
      findMany: vi.fn(),
      update: vi.fn(),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

import {
  DEFAULT_CATEGORY_OVERRIDES,
  evaluateStaleness,
  refreshStalenessForOrg,
  resolveThreshold,
} from "./staleness";

beforeEach(() => {
  prismaMock.document.findMany.mockReset();
  prismaMock.document.update.mockReset();
});

const NOW = new Date("2026-05-14T00:00:00Z");

function daysAgo(n: number): Date {
  return new Date(NOW.getTime() - n * 24 * 60 * 60 * 1000);
}

// ---------------------------------------------------------------------------
// evaluateStaleness
// ---------------------------------------------------------------------------

describe("evaluateStaleness", () => {
  it("flags a doc older than the default threshold (~2 years)", () => {
    const v = evaluateStaleness({
      sourceDate: daysAgo(900), // ~2.5 years
      fileName: "vendor-overview.pdf",
      now: NOW,
    });
    expect(v.isStale).toBe(true);
    expect(v.daysOld).toBe(900);
    expect(v.threshold).toBe(730);
    expect(v.reason).toMatch(/> 730 days old/);
  });

  it("does not flag a doc within the default threshold", () => {
    const v = evaluateStaleness({
      sourceDate: daysAgo(400),
      fileName: "vendor-overview.pdf",
      now: NOW,
    });
    expect(v.isStale).toBe(false);
    expect(v.daysOld).toBe(400);
    expect(v.reason).toBeUndefined();
  });

  it("applies the SOC2 category override (365 days) to a 540-day-old report", () => {
    const v = evaluateStaleness({
      sourceDate: daysAgo(540), // 18 months — under default but over SOC2 threshold
      fileName: "Acme-SOC2-Type-II-2024.pdf",
      now: NOW,
    });
    expect(v.isStale).toBe(true);
    expect(v.threshold).toBe(365);
    expect(v.reason).toMatch(/SOC2 audit report/);
  });

  it("treats a missing sourceDate as not-stale (unknown ≠ proven old)", () => {
    const v = evaluateStaleness({
      sourceDate: null,
      fileName: "SOC2-something.pdf",
      now: NOW,
    });
    expect(v.isStale).toBe(false);
    expect(v.daysOld).toBeNull();
    expect(v.threshold).toBe(365); // override still picked, but unused for verdict
  });

  it("applies the roadmap override (90 days) aggressively", () => {
    const v = evaluateStaleness({
      sourceDate: daysAgo(120),
      fileName: "2025 product roadmap.pptx",
      now: NOW,
    });
    expect(v.isStale).toBe(true);
    expect(v.threshold).toBe(90);
  });

  it("respects an explicit rule override over env default", () => {
    const v = evaluateStaleness({
      sourceDate: daysAgo(100),
      fileName: "unrelated.pdf",
      rule: { thresholdDays: 30 },
      now: NOW,
    });
    expect(v.isStale).toBe(true);
    expect(v.threshold).toBe(30);
  });
});

// ---------------------------------------------------------------------------
// resolveThreshold — surface-level sanity, mostly there to anchor the
// default-override table to a test.
// ---------------------------------------------------------------------------

describe("resolveThreshold", () => {
  it("returns the SOC2 override for SOC2 filenames", () => {
    const { threshold, category } = resolveThreshold("acme-soc2-report.pdf", {
      thresholdDays: 730,
      categoryOverrides: DEFAULT_CATEGORY_OVERRIDES,
    });
    expect(threshold).toBe(365);
    expect(category).toBe("soc2");
  });

  it("returns the default when no keyword matches", () => {
    const { threshold, category } = resolveThreshold("misc.pdf", {
      thresholdDays: 730,
      categoryOverrides: DEFAULT_CATEGORY_OVERRIDES,
    });
    expect(threshold).toBe(730);
    expect(category).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// refreshStalenessForOrg — idempotent batch update against mocked Prisma.
// ---------------------------------------------------------------------------

describe("refreshStalenessForOrg", () => {
  it("returns counts and only PATCHes rows whose verdict flips", async () => {
    prismaMock.document.findMany.mockResolvedValueOnce([
      // Already-stale, still stale → no update.
      {
        id: "d1",
        fileName: "soc2-2022.pdf",
        sourceDate: daysAgo(900),
        staleReason: "SOC2 audit report > 365 days old (age: 900 days)",
      },
      // Fresh → no update.
      { id: "d2", fileName: "x.pdf", sourceDate: daysAgo(10), staleReason: null },
      // Was clean, now stale → update.
      { id: "d3", fileName: "soc2-2024.pdf", sourceDate: daysAgo(400), staleReason: null },
      // Was stale, now clean (sourceDate cleared somehow) → update.
      { id: "d4", fileName: "y.pdf", sourceDate: null, staleReason: "old reason" },
    ]);

    const r = await refreshStalenessForOrg("org_1");
    expect(r.scanned).toBe(4);
    // d1 still stale, d3 now stale → flagged = 2
    expect(r.flagged).toBe(2);

    // Two PATCHes: d3 (flip null→reason) and d4 (flip reason→null). d1 and d2
    // unchanged.
    expect(prismaMock.document.update).toHaveBeenCalledTimes(2);
    const ids = prismaMock.document.update.mock.calls.map((c) => c[0].where.id).sort();
    expect(ids).toEqual(["d3", "d4"]);
  });

  it("returns zero when there are no documents", async () => {
    prismaMock.document.findMany.mockResolvedValueOnce([]);
    const r = await refreshStalenessForOrg("empty_org");
    expect(r).toEqual({ scanned: 0, flagged: 0 });
    expect(prismaMock.document.update).not.toHaveBeenCalled();
  });
});
