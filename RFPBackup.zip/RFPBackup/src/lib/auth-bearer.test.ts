import { beforeEach, describe, expect, it, vi } from "vitest";

// Mock the api-keys module so we control lookupApiKey behavior directly.
vi.mock("./api-keys", () => ({
  lookupApiKey: vi.fn(),
}));

// Suppress audit writes — we only care about the auth result here.
vi.mock("./audit", () => ({
  audit: vi.fn().mockResolvedValue(undefined),
  auditContextFromRequest: vi.fn().mockReturnValue({}),
}));

import { lookupApiKey } from "./api-keys";
import { authenticateBearer } from "./auth-bearer";
import { audit } from "./audit";
import { ApiKeyScope } from "@prisma/client";

type MockedFn = ReturnType<typeof vi.fn>;
const mockLookup = lookupApiKey as unknown as MockedFn;
const mockAudit = audit as unknown as MockedFn;

beforeEach(() => {
  mockLookup.mockReset();
  mockAudit.mockReset();
});

function reqWith(headers: Record<string, string>): Request {
  return new Request("https://example.com/api/whatever", { headers });
}

describe("authenticateBearer", () => {
  it("returns null when the Authorization header is missing", async () => {
    const result = await authenticateBearer(reqWith({}));
    expect(result).toBeNull();
    expect(mockLookup).not.toHaveBeenCalled();
  });

  it("returns null on malformed header (no Bearer prefix)", async () => {
    const result = await authenticateBearer(
      reqWith({ authorization: "Basic dXNlcjpwYXNz" }),
    );
    expect(result).toBeNull();
    expect(mockLookup).not.toHaveBeenCalled();
  });

  it("returns null when the Bearer token is empty", async () => {
    const result = await authenticateBearer(reqWith({ authorization: "Bearer " }));
    expect(result).toBeNull();
    expect(mockLookup).not.toHaveBeenCalled();
  });

  it("returns a session shape on success", async () => {
    mockLookup.mockResolvedValueOnce({
      key: {
        id: "key_1",
        userId: "user_1",
        organizationId: "org_1",
        scope: ApiKeyScope.WRITE,
        prefix: "abcdefgh",
        revokedAt: null,
        expiresAt: null,
      },
      user: { id: "user_1", email: "u@example.com" },
    });
    const result = await authenticateBearer(reqWith({ authorization: "Bearer autorfp_xyz" }));
    expect(result).toEqual({
      userId: "user_1",
      organizationId: "org_1",
      scope: ApiKeyScope.WRITE,
      keyId: "key_1",
      via: "api-key",
    });
    // Audit fired with API_KEY_USED event.
    expect(mockAudit).toHaveBeenCalledTimes(1);
    expect(mockAudit.mock.calls[0][0]).toMatchObject({
      event: "API_KEY_USED",
      actorId: "user_1",
      organizationId: "org_1",
      targetType: "api_key",
      targetId: "key_1",
    });
  });

  it("returns null when lookup says revoked / expired / unknown (any null result)", async () => {
    mockLookup.mockResolvedValueOnce(null);
    const result = await authenticateBearer(
      reqWith({ authorization: "Bearer autorfp_revoked" }),
    );
    expect(result).toBeNull();
    expect(mockAudit).not.toHaveBeenCalled();
  });

  it("treats lookup-revoked the same as null (no session, no audit)", async () => {
    // lookupApiKey already filters revoked/expired keys to null — confirm we
    // honor that contract rather than try to second-guess it.
    mockLookup.mockResolvedValueOnce(null);
    expect(
      await authenticateBearer(reqWith({ authorization: "Bearer autorfp_expired" })),
    ).toBeNull();
  });

  it("accepts case-insensitive Authorization header name", async () => {
    mockLookup.mockResolvedValueOnce({
      key: {
        id: "k",
        userId: "u",
        organizationId: null,
        scope: ApiKeyScope.READ,
        prefix: "ffffffff",
        revokedAt: null,
        expiresAt: null,
      },
      user: { id: "u" },
    });
    const result = await authenticateBearer(reqWith({ Authorization: "Bearer autorfp_x" }));
    expect(result?.userId).toBe("u");
  });
});
