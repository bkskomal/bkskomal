import { describe, expect, it } from "vitest";
import { parseSignatureHeader, signPayload } from "./sign";
import { verifyPayload } from "./verify";

const SECRET = "wh_sec_test_abcdef0123456789";
const BODY = JSON.stringify({ event: "rfp.exported", id: "rfp_123" });

describe("signPayload", () => {
  it("produces a t=<ts>,v1=<hex> header", () => {
    const header = signPayload(SECRET, BODY, { timestamp: 1_700_000_000 });
    expect(header).toMatch(/^t=1700000000,v1=[0-9a-f]{64}$/);
  });

  it("is deterministic for a given (secret, body, ts)", () => {
    const a = signPayload(SECRET, BODY, { timestamp: 42 });
    const b = signPayload(SECRET, BODY, { timestamp: 42 });
    expect(a).toBe(b);
  });

  it("changes when the secret changes", () => {
    const a = signPayload(SECRET, BODY, { timestamp: 42 });
    const b = signPayload(SECRET + "x", BODY, { timestamp: 42 });
    expect(a).not.toBe(b);
  });

  it("rejects empty secrets", () => {
    expect(() => signPayload("", BODY)).toThrow();
  });
});

describe("parseSignatureHeader", () => {
  it("parses well-formed input", () => {
    expect(parseSignatureHeader("t=1700000000,v1=abcdef")).toEqual({ ts: 1700000000, v1: "abcdef" });
  });

  it("tolerates whitespace and additional vN fields", () => {
    expect(parseSignatureHeader(" t=1, v1=AB , v2=ignored")).toEqual({ ts: 1, v1: "ab" });
  });

  it("rejects missing fields, non-hex sigs, non-numeric ts", () => {
    expect(parseSignatureHeader("t=1")).toBeNull();
    expect(parseSignatureHeader("v1=ab")).toBeNull();
    expect(parseSignatureHeader("t=abc,v1=ab")).toBeNull();
    expect(parseSignatureHeader("t=1,v1=zz")).toBeNull();
    expect(parseSignatureHeader("garbage")).toBeNull();
  });
});

describe("verifyPayload — happy path", () => {
  it("accepts a freshly-signed payload", () => {
    const header = signPayload(SECRET, BODY);
    expect(verifyPayload(SECRET, BODY, header)).toEqual({ ok: true });
  });

  it("accepts within the tolerance window (default 5 min)", () => {
    const now = 2_000_000_000;
    const header = signPayload(SECRET, BODY, { timestamp: now - 299 });
    expect(verifyPayload(SECRET, BODY, header, { now: () => now * 1000 })).toEqual({ ok: true });
  });
});

describe("verifyPayload — tampering detection", () => {
  it("rejects body tampering", () => {
    const header = signPayload(SECRET, BODY, { timestamp: 1_700_000_000 });
    const result = verifyPayload(SECRET, BODY + " ", header, {
      now: () => 1_700_000_000 * 1000,
    });
    expect(result).toEqual({ ok: false, reason: "mismatch" });
  });

  it("rejects signature tampering (flipped hex byte)", () => {
    const ts = 1_700_000_000;
    const header = signPayload(SECRET, BODY, { timestamp: ts });
    // Flip the last hex char so the parsed sig is still hex but wrong.
    const tampered = header.replace(/.$/, (c) => (c === "0" ? "1" : "0"));
    const result = verifyPayload(SECRET, BODY, tampered, { now: () => ts * 1000 });
    expect(result).toEqual({ ok: false, reason: "mismatch" });
  });

  it("rejects a different secret", () => {
    const ts = 1_700_000_000;
    const header = signPayload(SECRET, BODY, { timestamp: ts });
    expect(verifyPayload(SECRET + "x", BODY, header, { now: () => ts * 1000 })).toEqual({
      ok: false,
      reason: "mismatch",
    });
  });
});

describe("verifyPayload — replay protection", () => {
  it("rejects timestamps older than the tolerance window", () => {
    const signed = signPayload(SECRET, BODY, { timestamp: 1000 });
    // 6 minutes later — outside the default 300s window.
    const result = verifyPayload(SECRET, BODY, signed, { now: () => (1000 + 360) * 1000 });
    expect(result).toEqual({ ok: false, reason: "expired" });
  });

  it("rejects timestamps too far in the future", () => {
    const signed = signPayload(SECRET, BODY, { timestamp: 1000 + 600 });
    const result = verifyPayload(SECRET, BODY, signed, { now: () => 1000 * 1000 });
    expect(result).toEqual({ ok: false, reason: "future" });
  });

  it("respects a custom tolerance", () => {
    const signed = signPayload(SECRET, BODY, { timestamp: 1000 });
    // 10s drift, tolerance of 5s — should reject.
    expect(
      verifyPayload(SECRET, BODY, signed, {
        now: () => 1010 * 1000,
        toleranceSeconds: 5,
      }),
    ).toEqual({ ok: false, reason: "expired" });
    // Same drift, tolerance of 60s — should accept.
    expect(
      verifyPayload(SECRET, BODY, signed, {
        now: () => 1010 * 1000,
        toleranceSeconds: 60,
      }),
    ).toEqual({ ok: true });
  });
});

describe("verifyPayload — malformed input", () => {
  it("rejects null / empty / missing headers", () => {
    expect(verifyPayload(SECRET, BODY, null)).toEqual({ ok: false, reason: "malformed" });
    expect(verifyPayload(SECRET, BODY, undefined)).toEqual({ ok: false, reason: "malformed" });
    expect(verifyPayload(SECRET, BODY, "")).toEqual({ ok: false, reason: "malformed" });
  });

  it("rejects garbage headers", () => {
    expect(verifyPayload(SECRET, BODY, "not-a-real-sig")).toEqual({
      ok: false,
      reason: "malformed",
    });
    expect(verifyPayload(SECRET, BODY, "t=abc,v1=ab")).toEqual({
      ok: false,
      reason: "malformed",
    });
    expect(verifyPayload(SECRET, BODY, "t=1,v1=not-hex")).toEqual({
      ok: false,
      reason: "malformed",
    });
  });

  it("rejects empty secret", () => {
    const header = signPayload(SECRET, BODY);
    expect(verifyPayload("", BODY, header)).toEqual({ ok: false, reason: "malformed" });
  });
});
