// HMAC-SHA256 webhook signing primitive.
//
// Wire format mirrors the Stripe / GitHub style:
//
//   X-AutoRFP-Signature: t=<unix-seconds>,v1=<hex>
//
// where the signed input is the literal string `<t>.<body>`. Including the
// timestamp in the signed payload prevents replay attacks (see verify.ts).
//
// The primitive is intentionally framework-free so it can be re-used by any
// future outgoing-webhook code path (the existing pipeline WEBHOOK step in
// src/lib/pipeline/handlers.ts implements an inlined version of the same
// scheme — new code should prefer importing from this module).

import { createHmac } from "node:crypto";

export interface SignOptions {
  /** Override the timestamp (seconds) — defaults to `Date.now() / 1000`. */
  timestamp?: number;
}

/**
 * Sign a body with the given secret. Returns the header value in the form
 * `t=<unix-seconds>,v1=<hex>`. Both `body` and `secret` are treated as opaque
 * byte strings; the caller is responsible for serialising structured data
 * deterministically before passing it in.
 */
export function signPayload(secret: string, body: string, opts: SignOptions = {}): string {
  if (!secret) throw new Error("signPayload: secret must be a non-empty string");
  const ts = Math.floor(opts.timestamp ?? Date.now() / 1000);
  const sig = createHmac("sha256", secret).update(`${ts}.${body}`).digest("hex");
  return `t=${ts},v1=${sig}`;
}

/**
 * Parse a `t=<ts>,v1=<hex>` header into its components. Returns null if the
 * shape is wrong. Designed to be tolerant of trailing whitespace and
 * additional `vN=` fields (for forward-compat with future schemes).
 */
export function parseSignatureHeader(header: string): { ts: number; v1: string } | null {
  if (typeof header !== "string") return null;
  const parts = header.split(",").map((p) => p.trim());
  let ts: number | null = null;
  let v1: string | null = null;
  for (const p of parts) {
    const eq = p.indexOf("=");
    if (eq <= 0) return null;
    const k = p.slice(0, eq);
    const v = p.slice(eq + 1);
    if (k === "t") {
      const n = Number(v);
      if (!Number.isFinite(n) || n <= 0) return null;
      ts = n;
    } else if (k === "v1") {
      if (!/^[0-9a-f]+$/i.test(v)) return null;
      v1 = v.toLowerCase();
    }
  }
  if (ts === null || v1 === null) return null;
  return { ts, v1 };
}
