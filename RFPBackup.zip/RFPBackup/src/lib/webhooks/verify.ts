// HMAC-SHA256 webhook verification.
//
// Mirrors signPayload() in ./sign.ts. Uses `crypto.timingSafeEqual` for a
// constant-time compare so an attacker cannot leak the signature byte-by-byte
// via timing.
//
// Replay protection: by default the timestamp must be within ±5 minutes of
// the verifier's clock. Tune via `toleranceSeconds`.

import { createHmac, timingSafeEqual } from "node:crypto";
import { parseSignatureHeader } from "./sign";

export interface VerifyOptions {
  /** Allowed clock skew in seconds. Default: 300 (5 minutes). */
  toleranceSeconds?: number;
  /** Override "now" — primarily for tests. */
  now?: () => number;
}

export type VerifyResult =
  | { ok: true }
  | { ok: false; reason: "malformed" | "expired" | "future" | "mismatch" };

/**
 * Verify that `header` is a valid signature over `body` using `secret`.
 *
 * Returns a discriminated union so callers can distinguish a malformed header
 * (likely a bug, log loudly) from an expired timestamp (likely a replay or
 * clock-skew issue, log quietly) from an outright mismatch (potential attack).
 */
export function verifyPayload(
  secret: string,
  body: string,
  header: string | null | undefined,
  opts: VerifyOptions = {},
): VerifyResult {
  if (!secret || typeof header !== "string" || header.length === 0) {
    return { ok: false, reason: "malformed" };
  }
  const parsed = parseSignatureHeader(header);
  if (!parsed) return { ok: false, reason: "malformed" };

  const tolerance = opts.toleranceSeconds ?? 300;
  const nowSec = Math.floor((opts.now?.() ?? Date.now()) / 1000);
  const drift = nowSec - parsed.ts;
  if (drift > tolerance) return { ok: false, reason: "expired" };
  // Allow a tiny negative drift (clock skew on the sender side) up to the
  // same tolerance window; anything beyond is suspicious.
  if (drift < -tolerance) return { ok: false, reason: "future" };

  const expected = createHmac("sha256", secret)
    .update(`${parsed.ts}.${body}`)
    .digest("hex");

  // Hex strings are the same length; if not, definite mismatch — but still
  // do a constant-time compare on equal-length buffers to avoid leaking the
  // length check.
  if (expected.length !== parsed.v1.length) return { ok: false, reason: "mismatch" };
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(parsed.v1, "hex");
  if (a.length !== b.length) return { ok: false, reason: "mismatch" };
  return timingSafeEqual(a, b) ? { ok: true } : { ok: false, reason: "mismatch" };
}
