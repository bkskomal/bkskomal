// Mine completed RFP responses → KB documents. Each Q+A pair becomes a
// dedicated chunk so retrieval surfaces full pairs, not fragmented prose.

import { prisma } from "@/lib/prisma";
import { embed } from "@/lib/ai/embeddings";
import { vectorStoreResolver } from "@/lib/ai/vector";
import type { ChunkVec } from "@/lib/ai/vector/types";
import { logActivity } from "@/lib/activity";

export interface MineOptions {
  /** Only mine APPROVED questions (default) or all with COMPLETED responses. */
  approvedOnly?: boolean;
}

export async function mineRfpToIndex(
  rfpId: string,
  indexId: string,
  options: MineOptions = {},
): Promise<{ documentId: string; pairCount: number }> {
  const approvedOnly = options.approvedOnly !== false;

  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: {
      project: { select: { name: true, organizationId: true } },
      questions: {
        where: approvedOnly ? { status: "APPROVED" } : {},
        orderBy: { number: "asc" },
        include: {
          responses: {
            where: { status: "COMPLETED" },
            orderBy: { createdAt: "desc" },
            take: 1,
          },
        },
      },
    },
  });
  if (!rfp) throw new Error("RFP not found");

  // Sanity check the index belongs to the same org.
  const index = await prisma.knowledgeIndex.findUnique({ where: { id: indexId } });
  if (!index || index.organizationId !== rfp.project.organizationId) {
    throw new Error("Knowledge index does not belong to this organization");
  }

  const pairs = rfp.questions
    .filter((q) => q.responses[0]?.content?.trim())
    .map((q) => ({
      number: q.number,
      section: q.section ?? "General",
      question: q.text,
      answer: q.responses[0].content,
    }));

  if (pairs.length === 0) {
    throw new Error("No completed responses to mine");
  }

  // One synthetic Document per RFP-mining run, chunked one Q&A per chunk.
  const doc = await prisma.document.create({
    data: {
      indexId,
      name: `Mined: ${rfp.title}`,
      fileName: `mined-${rfp.id}.md`,
      fileSize: 0,
      mimeType: "text/markdown",
      storagePath: `(synthetic)/mined/${rfp.id}`,
      status: "PROCESSING",
    },
  });

  try {
    const chunkVecs: ChunkVec[] = [];
    for (let i = 0; i < pairs.length; i++) {
      const p = pairs[i];
      const content = `# ${p.section} — Q${p.number}\n\nQ: ${p.question}\n\nA: ${p.answer}`;
      const vec = await embed(content, rfp.project.organizationId);
      const row = await prisma.documentChunk.create({
        data: {
          documentId: doc.id,
          ordinal: i,
          content,
          embedding: [],
        },
        select: { id: true },
      });
      chunkVecs.push({
        id: row.id,
        embedding: vec,
        metadata: {
          documentId: doc.id,
          indexId,
          organizationId: rfp.project.organizationId,
        },
      });
    }
    if (chunkVecs.length > 0) {
      const writers = await vectorStoreResolver.writersForOrg(
        rfp.project.organizationId,
      );
      await Promise.all(writers.map((w) => w.upsert(chunkVecs)));
    }
    await prisma.document.update({
      where: { id: doc.id },
      data: { status: "INDEXED", fileSize: pairs.reduce((n, p) => n + p.question.length + p.answer.length, 0) },
    });
  } catch (e) {
    await prisma.document.update({
      where: { id: doc.id },
      data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
    });
    throw e;
  }

  void logActivity({
    rfpId,
    actorId: null,
    kind: "EXPORT_GENERATED", // closest existing kind; a dedicated MINED kind could be added later
    payload: { mined: true, documentId: doc.id, pairCount: pairs.length, indexId },
  });

  return { documentId: doc.id, pairCount: pairs.length };
}
