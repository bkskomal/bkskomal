import { describe, expect, it } from "vitest";
import { slugify, formatBytes, truncate } from "./utils";

describe("slugify", () => {
  it("lowercases and replaces non-alphanumerics", () => {
    expect(slugify("Hello World")).toBe("hello-world");
    expect(slugify("Acme, Inc!")).toBe("acme-inc");
  });
  it("trims leading/trailing dashes", () => {
    expect(slugify("  -- foo bar -- ")).toBe("foo-bar");
  });
  it("caps length at 64", () => {
    expect(slugify("a".repeat(200)).length).toBeLessThanOrEqual(64);
  });
});

describe("formatBytes", () => {
  it("formats by magnitude", () => {
    expect(formatBytes(0)).toBe("0 B");
    expect(formatBytes(512)).toBe("512 B");
    expect(formatBytes(2048)).toBe("2.0 KB");
    expect(formatBytes(2 * 1024 * 1024)).toBe("2.0 MB");
    expect(formatBytes(3 * 1024 * 1024 * 1024)).toBe("3.00 GB");
  });
});

describe("truncate", () => {
  it("returns input unchanged when within limit", () => {
    expect(truncate("hi", 10)).toBe("hi");
  });
  it("appends an ellipsis when truncating", () => {
    const t = truncate("a".repeat(50), 10);
    expect(t.length).toBeLessThanOrEqual(11);
    expect(t.endsWith("…")).toBe(true);
  });
});
