// Tiny in-process Prometheus-style metrics registry.
//
// Hand-rolled (no prom-client dependency) because:
//   - We only need three metric kinds (counter, histogram, gauge).
//   - The exposition format is simple text — easier to audit than a transitive
//     dep tree.
//   - We can keep the surface narrow enough for tests to reset cleanly.
//
// Design notes:
//   - All metric instances live in a module-level `registry` map keyed by name.
//     Re-defining the same name (e.g. on a hot module reload) returns the
//     existing instance instead of throwing. This makes the file safe to
//     import-eagerly from many places.
//   - Label combinations are stored as a stable string key
//     `name="value",name2="value2"` (sorted by name). Cheap and matches the
//     Prometheus exposition format directly.
//   - No background timers, no I/O — purely a passive collector. Hooks call
//     .inc() / .observe() / .set() and we accumulate state.
//   - Errors thrown by metric methods would corrupt the request path. Every
//     entry point catches and swallows; the worst case is a missing data
//     point, not a 500.

export interface Counter {
  inc(labels?: Record<string, string>, n?: number): void;
}

export interface Histogram {
  observe(labels: Record<string, string> | undefined, value: number): void;
}

export interface Gauge {
  set(labels: Record<string, string> | undefined, value: number): void;
  inc(labels?: Record<string, string>, n?: number): void;
  dec(labels?: Record<string, string>, n?: number): void;
}

type MetricKind = "counter" | "histogram" | "gauge";

interface BaseMetric {
  name: string;
  help: string;
  kind: MetricKind;
  labelNames: string[];
}

interface CounterMetric extends BaseMetric {
  kind: "counter";
  values: Map<string, number>;
}

interface GaugeMetric extends BaseMetric {
  kind: "gauge";
  values: Map<string, number>;
}

interface HistogramMetric extends BaseMetric {
  kind: "histogram";
  buckets: number[]; // upper bounds, ascending; +Inf is implicit
  // For each label-key: cumulative bucket counts (length === buckets.length + 1
  // for the implicit +Inf bucket), running sum and count.
  values: Map<
    string,
    { bucketCounts: number[]; sum: number; count: number; labels: Record<string, string> }
  >;
}

type AnyMetric = CounterMetric | GaugeMetric | HistogramMetric;

const registry = new Map<string, AnyMetric>();

const DEFAULT_BUCKETS = [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000];

function labelKey(labelNames: string[], labels: Record<string, string> | undefined): string {
  if (!labelNames.length) return "";
  const sorted = [...labelNames].sort();
  const parts: string[] = [];
  for (const n of sorted) {
    const v = labels?.[n] ?? "";
    parts.push(`${n}="${escapeLabelValue(v)}"`);
  }
  return parts.join(",");
}

function escapeLabelValue(v: string): string {
  // Prometheus exposition: backslash, double quote, and newline must be escaped.
  return v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n");
}

function ensureRegistered(metric: AnyMetric): AnyMetric {
  const existing = registry.get(metric.name);
  if (existing) {
    if (existing.kind !== metric.kind) {
      // Don't throw — log via console.warn so tests / startup keep going.
      // Returning the existing instance prevents subtle double-registration
      // bugs.
      // eslint-disable-next-line no-console
      console.warn(
        `[metrics] re-registration of "${metric.name}" with different kind ignored`,
      );
    }
    return existing;
  }
  registry.set(metric.name, metric);
  return metric;
}

export function counter(name: string, help: string, labelNames: string[] = []): Counter {
  const m = ensureRegistered({
    name,
    help,
    kind: "counter",
    labelNames,
    values: new Map(),
  } as CounterMetric) as CounterMetric;
  return {
    inc(labels?: Record<string, string>, n = 1) {
      try {
        const k = labelKey(m.labelNames, labels);
        m.values.set(k, (m.values.get(k) ?? 0) + n);
      } catch {
        // Swallow — never break the caller for telemetry.
      }
    },
  };
}

export function gauge(name: string, help: string, labelNames: string[] = []): Gauge {
  const m = ensureRegistered({
    name,
    help,
    kind: "gauge",
    labelNames,
    values: new Map(),
  } as GaugeMetric) as GaugeMetric;
  return {
    set(labels, value) {
      try {
        const k = labelKey(m.labelNames, labels);
        m.values.set(k, value);
      } catch {
        // ignore
      }
    },
    inc(labels, n = 1) {
      try {
        const k = labelKey(m.labelNames, labels);
        m.values.set(k, (m.values.get(k) ?? 0) + n);
      } catch {
        // ignore
      }
    },
    dec(labels, n = 1) {
      try {
        const k = labelKey(m.labelNames, labels);
        m.values.set(k, (m.values.get(k) ?? 0) - n);
      } catch {
        // ignore
      }
    },
  };
}

export function histogram(
  name: string,
  help: string,
  labelNames: string[] = [],
  buckets: number[] = DEFAULT_BUCKETS,
): Histogram {
  const sortedBuckets = [...buckets].sort((a, b) => a - b);
  const m = ensureRegistered({
    name,
    help,
    kind: "histogram",
    labelNames,
    buckets: sortedBuckets,
    values: new Map(),
  } as HistogramMetric) as HistogramMetric;
  return {
    observe(labels, value) {
      try {
        const k = labelKey(m.labelNames, labels);
        let entry = m.values.get(k);
        if (!entry) {
          entry = {
            bucketCounts: new Array(m.buckets.length + 1).fill(0),
            sum: 0,
            count: 0,
            labels: { ...(labels ?? {}) },
          };
          m.values.set(k, entry);
        }
        // Find first bucket whose upper bound >= value; that and all higher
        // buckets get incremented (cumulative). The trailing +Inf bucket
        // always increments.
        let bumped = false;
        for (let i = 0; i < m.buckets.length; i++) {
          if (value <= m.buckets[i]) {
            for (let j = i; j < m.buckets.length; j++) entry.bucketCounts[j]++;
            bumped = true;
            break;
          }
        }
        // +Inf always.
        entry.bucketCounts[m.buckets.length]++;
        if (!bumped) {
          // value exceeded all explicit buckets — only +Inf incremented above.
        }
        entry.sum += value;
        entry.count += 1;
      } catch {
        // ignore
      }
    },
  };
}

/**
 * Render the current registry as Prometheus 0.0.4 text exposition.
 * Format reference:
 *   # HELP metric_name help text
 *   # TYPE metric_name counter|gauge|histogram
 *   metric_name{label="v",...} 12.5
 *
 * Histograms additionally emit `_bucket{le="..."}`, `_sum`, and `_count`.
 */
export function exposition(): string {
  const lines: string[] = [];
  // Stable ordering across calls helps with diffing in tests.
  const names = [...registry.keys()].sort();
  for (const name of names) {
    const m = registry.get(name);
    if (!m) continue;
    lines.push(`# HELP ${m.name} ${escapeHelp(m.help)}`);
    lines.push(`# TYPE ${m.name} ${m.kind}`);
    if (m.kind === "counter" || m.kind === "gauge") {
      if (m.values.size === 0 && m.labelNames.length === 0) {
        // Emit a zero sample so scrapers see the metric exists.
        lines.push(`${m.name} 0`);
      } else if (m.values.size === 0) {
        // Labelled but no data yet — skip; nothing to emit.
      } else {
        for (const [k, v] of m.values) {
          lines.push(formatSample(m.name, k, v));
        }
      }
    } else {
      // histogram
      if (m.values.size === 0) {
        // Emit nothing for empty histograms — Prom is fine with that.
        continue;
      }
      for (const [, entry] of m.values) {
        const baseLabels = entry.labels;
        for (let i = 0; i < m.buckets.length; i++) {
          const bucketLabels = { ...baseLabels, le: String(m.buckets[i]) };
          const bk = labelKey([...m.labelNames, "le"], bucketLabels);
          lines.push(formatSample(`${m.name}_bucket`, bk, entry.bucketCounts[i]));
        }
        const infLabels = { ...baseLabels, le: "+Inf" };
        const ibk = labelKey([...m.labelNames, "le"], infLabels);
        lines.push(formatSample(`${m.name}_bucket`, ibk, entry.bucketCounts[m.buckets.length]));
        const baseKey = labelKey(m.labelNames, baseLabels);
        lines.push(formatSample(`${m.name}_sum`, baseKey, entry.sum));
        lines.push(formatSample(`${m.name}_count`, baseKey, entry.count));
      }
    }
  }
  // Trailing newline per Prom convention.
  return lines.join("\n") + "\n";
}

function escapeHelp(h: string): string {
  return h.replace(/\\/g, "\\\\").replace(/\n/g, "\\n");
}

function formatSample(name: string, labelKeyStr: string, value: number): string {
  const labelPart = labelKeyStr ? `{${labelKeyStr}}` : "";
  return `${name}${labelPart} ${formatNumber(value)}`;
}

function formatNumber(n: number): string {
  if (!Number.isFinite(n)) return n > 0 ? "+Inf" : n < 0 ? "-Inf" : "NaN";
  // Integers: render plain. Floats: keep up to 6 significant digits to avoid
  // long IEEE tails.
  if (Number.isInteger(n)) return String(n);
  return String(Number(n.toPrecision(6)));
}

/** @internal — for tests. Drop all registered metrics + samples. */
export function _resetForTests(): void {
  registry.clear();
}

// ---------------------------------------------------------------------------
// Pre-registered metric instances. Importing this module is enough for them to
// appear in `exposition()`, even before the first sample.
// ---------------------------------------------------------------------------

export const httpRequestsTotal = counter(
  "http_requests_total",
  "Total HTTP requests handled by withApiHandler",
  ["route", "method", "status"],
);

export const httpRequestDurationMs = histogram(
  "http_request_duration_ms",
  "Duration of HTTP requests in milliseconds",
  ["route", "method", "status"],
  [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000],
);

export const rateLimitHitsTotal = counter(
  "rate_limit_hits_total",
  "Total rate-limit rejections (HTTP 429)",
  ["route", "scope"],
);

export const circuitBreakerState = gauge(
  "circuit_breaker_state",
  "Circuit breaker state: 0=closed, 1=half_open, 2=open",
  ["name"],
);

export const llmRequestsTotal = counter(
  "llm_requests_total",
  "Total LLM chat-completion requests",
  ["provider", "model", "status"],
);

export const llmTokensTotal = counter(
  "llm_tokens_total",
  "Total LLM tokens consumed (prompt + completion)",
  ["provider", "model", "kind"],
);

// Model-routing decisions (Phase 3B). Incremented once per call to
// `pickModelForGeneration`. The `reason` label takes one of:
//   routing_disabled | no_complexity | fallback | simple_routed | complex_routed
// and the `model` label is the model actually selected. Dashboards can
// chart the simple_routed:complex_routed ratio to verify the cheap-model
// lever is being pulled in production.
export const llmRoutingDecisionsTotal = counter(
  "llm_routing_decisions_total",
  "Model routing decisions made for LLM generation",
  ["model", "reason"],
);

export const pipelineStepsTotal = counter(
  "pipeline_steps_total",
  "Total pipeline step status transitions",
  ["kind", "status"],
);

export const responsesGeneratedTotal = counter(
  "responses_generated_total",
  "Total RFP responses generated",
  ["org"],
);

export const responsesConfidence = histogram(
  "responses_confidence",
  "Distribution of self-rated confidence (0..1) on generated responses",
  ["org"],
  [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
);

// Grounding score from the second-pass LLM judge (see lib/ai/grounding.ts).
// Same 0..1 bucket layout as responsesConfidence so the two histograms are
// directly comparable in dashboards.
export const responseGroundingScore = histogram(
  "response_grounding_score",
  "Distribution of LLM-judge grounding scores (0..1) on generated responses",
  ["org"],
  [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
);

// --- Pricing matrix (Phase 3A) ---
// Counter incremented every time a single matrix cell is filled in by
// generateMatrixCell. One increment per AI-generated cell, regardless of
// whether the cell ended up as a real answer or "NEEDS INFO" — operators
// reading the metric want to see total LLM volume per org, not just
// "successful" generations.
export const matrixCellsGeneratedTotal = counter(
  "matrix_cells_generated_total",
  "Total pricing-matrix cells generated via AI",
  ["org"],
);

// --- Win/loss feedback loop ---
// Counter incremented every time an RFP outcome is set via the outcome route.
// `outcome` label takes one of: PENDING | WON | LOST | WITHDRAWN | NO_BID.
export const rfpOutcomesTotal = counter(
  "rfp_outcomes_total",
  "Total RFP outcome transitions (each PATCH on the outcome route)",
  ["outcome"],
);

// --- Predictive win scoring (Tier C — moonshot) ---
// Counter incremented each time the scorer persists a WinPrediction row.
// `recommendation` takes one of: go | review | no_bid. Pair with the
// histogram below for the "are we over-recommending GO?" dashboard.
export const winPredictionsTotal = counter(
  "win_predictions_total",
  "Total win-prediction rows persisted by the scorer",
  ["recommendation"],
);

// Histogram of the raw probability (0..1). Same 0.1-bucket layout as
// `responsesConfidence` so dashboards can plot the two next to each other
// and reason about "model thinks we'll win" vs "model is confident in
// individual answers" as independent series.
export const winPredictionProbability = histogram(
  "win_prediction_probability",
  "Distribution of predicted win probabilities (0..1) on RFPs",
  [],
  [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
);

// --- Semantic answer cache (Phase 3C) ---
// Counter incremented inside lookupCachedAnswer(). `result` takes one of:
//   hit_exact    — questionHash matched verbatim
//   hit_semantic — cosine similarity >= threshold
//   miss         — neither path produced a hit (or cache disabled)
// Dashboards compute hit rate as hit_*/total.
export const cacheLookupsTotal = counter(
  "cache_lookups_total",
  "Total semantic-cache lookups (hit/miss outcomes)",
  ["result"],
);

// Counter incremented when the admin route purges cached answers (bulk or
// per-entry). One sample per route call, not per row purged, so dashboards
// can show "purges per day" rather than total rows churned.
export const cachePurgesTotal = counter(
  "cache_purges_total",
  "Total semantic-cache purge operations (any path)",
);

// --- Stale-source detection (Tier B2) ---
// Counter incremented once per generation that produced at least one
// stale-source warning (not per warning — orgs care about "how often does
// freshness hurt us", not per-doc fan-out). Pair with `staleSourcesCount`
// in insights for the durable signal.
export const staleSourceWarningsTotal = counter(
  "stale_source_warnings_total",
  "Generations that surfaced one or more stale-source warnings",
  ["org"],
);

// --- Slack integration (Tier B1) ---
// Counter incremented inside sendSlackMessage(). One sample per call.
// `result` takes one of:
//   ok      — Slack accepted the message (chat.postMessage ok=true, or webhook 200)
//   error   — transport / API / circuit-open error
//   skipped — integration not configured, disabled, or filtered by event preference
// `event` is the SlackEventKind (or "manual" for direct sends like the test route).
export const slackMessagesSentTotal = counter(
  "slack_messages_sent_total",
  "Total Slack messages dispatched per event kind and result",
  ["event", "result"],
);

// --- Collaborative edit awareness (Tier B4) ---
// Counter incremented on every attempt to take the edit lock on a response.
// `result` takes one of:
//   ok               — lock granted (no holder, or previous holder expired)
//   locked_by_other  — refused; another user is actively editing
// Dashboards compute "edit contention rate" as locked_by_other / total —
// useful when sizing whether a team needs true CRDT collab vs. the soft lock.
export const editLocksAcquiredTotal = counter(
  "edit_locks_acquired_total",
  "Total response edit-lock acquisition attempts (ok or locked_by_other)",
  ["result"],
);

// Counter incremented on each debounced draft-save (PUT /draft). `result`:
//   ok                — draft persisted
//   version_conflict  — refused; someone else committed in between
//   lock_lost         — refused; caller no longer holds the lock (TTL expired)
// `lock_lost` ticking up means clients are letting their tabs background past
// HEARTBEAT_TTL_MS and trying to save anyway — a UX-tuning signal.
export const editDraftsSavedTotal = counter(
  "edit_drafts_saved_total",
  "Total debounced draft-save attempts on response edit sessions",
  ["result"],
);

// --- LoRA adapter (Tier C3) ---
// Counter incremented once per `pickModelForGeneration` call that resolves
// to a configured adapter (reason `adapter_override`). The `base_model`
// label carries `loraAdapterMeta.baseModel` so dashboards can split usage
// by which underlying model the org chose to fine-tune. AutoRFP itself
// does NOT train adapters — this metric just tracks *consumption* of a
// fine-tune the user produced externally.
export const loraAdapterUsesTotal = counter(
  "lora_adapter_uses_total",
  "Generations served by an org's configured LoRA / fine-tune adapter",
  ["org", "base_model"],
);

// --- SAML SSO (Tier B3) ---
// Counter incremented once per `/api/auth/saml/[orgSlug]/callback` completion.
// `result` is one of:
//   ok            — callback validated and a session was issued
//   cert_invalid  — signature did not match the stored IdP certificate
//   not_member    — assertion was valid but the user isn't in the org and we
//                   declined to auto-create the membership
//   other_error   — anything else (config missing, attribute mapping failed)
export const samlLoginsTotal = counter(
  "saml_logins_total",
  "Total SAML SSO callback completions",
  ["org", "result"],
);

// --- Evaluation rubric (auto-extracted) ---
// Counter incremented inside `extractAndPersistRubric` after the criteria
// have been parsed + persisted. `has_criteria` distinguishes successful
// extractions ("true" — buyer's rubric was recovered) from no-rubric runs
// ("false" — section not found or LLM returned empty). Dashboards compute
// the recovery rate as has_criteria="true" / total.
export const rubricExtractionsTotal = counter(
  "rubric_extractions_total",
  "Total evaluation-rubric extraction passes (with/without criteria)",
  ["org", "has_criteria"],
);

// Counter incremented inside `scoreAndPersistRubric` after a full scoring
// run completes. One sample per scored RFP, regardless of criterion count.
export const rubricScoresTotal = counter(
  "rubric_scores_total",
  "Total evaluation-rubric scoring runs completed",
  ["org"],
);

// Distribution of the weighted total score (0..1) across scored RFPs. Same
// 0.1 bucket layout as `responsesConfidence` so the two histograms diff
// cleanly in dashboards.
export const rubricTotalScore = histogram(
  "rubric_total_score",
  "Distribution of weighted total rubric scores (0..1)",
  ["org"],
  [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
);

// --- Document parser pipeline (Phase D) ---
// Counter incremented once per format-specific parser invocation, regardless
// of post-processing outcome. `parser` is the ParserId ("pdf", "docx", ...);
// `result` is one of:
//   ok      — parser produced an AST without throwing.
//   error   — parser threw (corrupt file, unsupported variant, etc.).
//   timeout — parser exceeded its wall-clock budget.
export const documentParsesTotal = counter(
  "document_parses_total",
  "Total document parser invocations",
  ["parser", "result"],
);

// Histogram of the 0..1 parse-quality score emitted by `scoreParseQuality`.
// One observation per fully-processed document (after layout clean + OCR +
// table enhance). Bucket layout matches `responsesConfidence` so dashboards
// can plot the two side by side.
export const documentParseQuality = histogram(
  "document_parse_quality",
  "Distribution of parse-quality scores (0..1) on ingested documents",
  [],
  [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
);

// Counter incremented every time the vision-LLM OCR fallback is invoked.
// `result` is one of:
//   ok                     — model returned a transcription (possibly empty).
//   vision_not_supported   — model refused / does not support image inputs.
//   error                  — transport / LLM error before a response landed.
export const visionOcrCallsTotal = counter(
  "vision_ocr_calls_total",
  "Total vision-LLM OCR fallback invocations",
  ["org", "result"],
);

// Counter incremented once per chunk produced by `semanticChunk`. `kind`
// carries the chunk's dominant block kind. Dashboards can compute the
// chunk-kind mix to verify rich-structure docs (heading/table/list) aren't
// being flattened into pure paragraph runs by the chunker.
export const chunksCreatedTotal = counter(
  "chunks_created_total",
  "Total chunks produced by the semantic chunker",
  ["kind"],
);

// --- Vector backend (Phase V) ---
// Backend-agnostic instrumentation for the VectorStore abstraction. Both
// PostgresVectorStore and MilvusVectorStore call into these same metric
// instances, labelling themselves via the `backend` label. Dashboards then
// chart upserts/searches/health side-by-side as orgs migrate from
// Postgres → Milvus.
//
// vector_upserts_total counts CHUNKS upserted, not batches — one
// .inc({...}, n) per upsert call where n is the chunk count. Pairs with
// `vector_searches_total` for the "writes vs reads" balance.
export const vectorUpsertsTotal = counter(
  "vector_upserts_total",
  "Total chunks upserted into the vector store",
  ["backend", "result"],
);

// One sample per search() call. `hybrid` distinguishes native dense+sparse
// fusion from dense-only requests so dashboards can verify the hybrid path
// is actually exercised after V3 lands.
export const vectorSearchesTotal = counter(
  "vector_searches_total",
  "Total vector-store search invocations",
  ["backend", "hybrid", "result"],
);

// Histogram of search wall-clock duration in milliseconds. Includes filter
// translation + network round-trip but not downstream re-ranking. Bucket
// layout matches httpRequestDurationMs so the two are diffable.
export const vectorSearchDurationMs = histogram(
  "vector_search_duration_ms",
  "Duration of vector-store search calls in milliseconds",
  ["backend"],
  [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000],
);

// --- Multimodal image search (Phase IM) ---
// One sample per `searchImages()` call on either backend. `result` takes
// one of:
//   ok          — search returned (possibly empty) hits successfully
//   error       — backend threw before producing a result
//   empty_query — caller passed a zero-norm query vector; we returned [] without
//                 issuing a backend query (defensive — should be rare in practice)
//   clip_skip   — retrieval skipped image search because CLIP failed to load
// Pair with `vector_searches_total` to chart text vs image search volume per
// backend as multimodal RAG ramps up.
export const imageSearchesTotal = counter(
  "image_searches_total",
  "Total image-vector search invocations (multimodal retrieval)",
  ["backend", "result"],
);

// --- Multimodal: extraction + UI search + storage (Phase IM — UI surfaces) ---
//
// imagesExtractedTotal: incremented by IM1's parser pipeline once per image
// pulled out of a source document. `format` carries the parser id ("html",
// "pdf", "docx") so dashboards can chart "which formats are giving us the
// most figure surface area to index". The UI-side image-search routes do not
// touch this counter — extraction is purely an indexing-time signal.
export const imagesExtractedTotal = counter(
  "images_extracted_total",
  "Total images extracted from source documents during indexing",
  ["format"],
);

// imagesSearchedTotal: incremented by the /api/indexes/:id/images/search and
// /similar routes (and any other surface that triggers a CLIP-space lookup).
// `mode` is one of:
//   text_query        — caller submitted a natural-language description
//   image_similarity  — caller submitted an existing imageId to "find similar"
// `backend` mirrors the underlying VectorStore id ("postgres" | "milvus") so
// the chart can be split per-tenant on the migration page. Pair with
// `image_searches_total` — that one fires inside the backend, this one fires
// at the request boundary so we can measure UI-driven volume independently.
export const imagesSearchedTotal = counter(
  "images_searched_total",
  "Total image-vector searches initiated from UI / API surfaces",
  ["backend", "mode"],
);

// imageStorageBytesTotal: cumulative bytes written under uploads/images/ per
// org. Incremented by the indexing image-persistence loop (IM1) with
// `n = bytesWritten` on each new file. Renamed counters cannot decrement, so
// deletions do NOT subtract here — operators reading the metric see total
// on-disk image volume committed (not current footprint). The insights
// `imageStorageMb` card uses a live DB-backed estimate instead so it tracks
// deletions correctly.
export const imageStorageBytesTotal = counter(
  "image_storage_bytes_total",
  "Cumulative bytes saved to disk for extracted images, per org",
  ["org"],
);

// Gauge updated by the health() probe: 1 = ok, 0 = fail. The /api/health
// route also writes this; treat it as "last observed status" rather than a
// continuous timeseries.
export const vectorHealthStatus = gauge(
  "vector_health_status",
  "Last observed vector-store health (1=ok, 0=fail)",
  ["backend"],
);

/** Numeric encoding shared by the gauge and the breaker hook. */
export const CIRCUIT_STATE_VALUE: Record<"CLOSED" | "HALF_OPEN" | "OPEN", number> = {
  CLOSED: 0,
  HALF_OPEN: 1,
  OPEN: 2,
};
