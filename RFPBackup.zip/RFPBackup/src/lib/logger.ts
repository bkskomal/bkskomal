// Structured logging built on Pino.
//
// Every API request gets a request-scoped logger with a unique `req_id` that
// propagates through all `await` chains via AsyncLocalStorage. Anywhere in
// the codebase you can call `log.info({...}, "message")` and the request ID
// + user ID will be auto-attached.
//
// Output: JSON in production (pipe to your log aggregator), pretty-printed
// in development (color, single-line). Level via LOG_LEVEL env var; defaults
// to "info" in prod, "debug" in dev.

import { AsyncLocalStorage } from "node:async_hooks";
import { randomBytes } from "node:crypto";
import pino, { type Logger } from "pino";

export interface LogContext {
  reqId: string;
  userId?: string | null;
  orgId?: string | null;
  route?: string | null;
  method?: string | null;
}

const storage = new AsyncLocalStorage<LogContext>();

const isDev = process.env.NODE_ENV !== "production";
const level = process.env.LOG_LEVEL ?? (isDev ? "debug" : "info");

const baseLogger: Logger = pino({
  level,
  base: { app: "autorfp" },
  timestamp: pino.stdTimeFunctions.isoTime,
  ...(isDev && process.stdout.isTTY
    ? {
        transport: {
          target: "pino-pretty",
          options: {
            colorize: true,
            translateTime: "HH:MM:ss.l",
            singleLine: true,
            ignore: "pid,hostname,app",
          },
        },
      }
    : {}),
});

/**
 * Get a logger pre-bound with the current request's context. Outside of a
 * request (e.g. on server startup), returns the base logger.
 */
export function log(): Logger {
  const ctx = storage.getStore();
  return ctx ? baseLogger.child(ctx) : baseLogger;
}

export function newRequestId(): string {
  return randomBytes(8).toString("hex");
}

/**
 * Run a function within a request-scoped logging context. The given context
 * is visible to every `log()` call inside the callback (including nested
 * async work).
 */
export function withLogContext<T>(ctx: LogContext, fn: () => Promise<T> | T): Promise<T> | T {
  return storage.run(ctx, fn);
}

/** Mutate the current context — e.g. once auth resolves the user. */
export function setLogContext(patch: Partial<LogContext>): void {
  const ctx = storage.getStore();
  if (!ctx) return;
  Object.assign(ctx, patch);
}
