import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const ACTIVE_ORG_COOKIE = "autorfp.activeOrg";

export async function getActiveOrg(searchOrgId?: string) {
  const session = await auth();
  if (!session?.user?.id) redirect("/auth/signin");
  const memberships = await prisma.membership.findMany({
    where: { userId: session.user.id },
    include: { organization: true },
    orderBy: { createdAt: "asc" },
  });
  if (memberships.length === 0) redirect("/orgs/new");

  const cookieStore = await cookies();
  const cookieOrgId = cookieStore.get(ACTIVE_ORG_COOKIE)?.value;

  // Resolution order: explicit search param wins (deep links), then cookie, then first.
  const target =
    memberships.find((m) => m.organizationId === searchOrgId) ??
    memberships.find((m) => m.organizationId === cookieOrgId) ??
    memberships[0];

  return {
    user: session.user,
    organization: target.organization,
    membership: target,
  };
}
