// notify() — the only function you call to dispatch a notification.
//
// Resolves the recipient's per-kind, per-channel preferences and fans out to
// the enabled channels. Each channel runs in isolation; one channel's failure
// is logged but never breaks another or the caller's flow.

import { ALL_CHANNELS, CHANNELS } from "./channels";
import { isEnabled } from "./preferences";
import type { NotificationContext, NotificationPayload } from "./types";

export interface NotifyInput {
  ctx: NotificationContext;
  payload: NotificationPayload;
}

export async function notify(input: NotifyInput): Promise<void> {
  // Skip self-notifications (don't email yourself for your own comment).
  if (input.ctx.actorId && input.ctx.actorId === input.ctx.userId) return;

  const tasks = ALL_CHANNELS.map(async (channelId) => {
    try {
      const enabled = await isEnabled(input.ctx.userId, input.payload.kind, channelId);
      if (!enabled) return;
      const impl = CHANNELS[channelId];
      if (!impl) return;
      await impl.deliver({ ctx: input.ctx, payload: input.payload });
    } catch (e) {
      console.warn(`[notifications] channel ${channelId} failed:`, e);
    }
  });
  await Promise.allSettled(tasks);
}

/** Convenience for fanning out to multiple recipients in parallel. */
export async function notifyMany(inputs: NotifyInput[]): Promise<void> {
  await Promise.allSettled(inputs.map((i) => notify(i)));
}
