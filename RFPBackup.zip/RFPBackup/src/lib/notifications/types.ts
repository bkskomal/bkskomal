// Typed payloads for each notification kind. Channels render them; the
// inbox UI renders them. Keeping the payloads strict means renaming a field
// once breaks all the spots that read it — desirable.

import type { NotificationKind } from "@prisma/client";

export interface NotificationContext {
  /** The recipient. */
  userId: string;
  /** The user who triggered it (assignor, commenter, etc.). Null for system. */
  actorId?: string | null;
  organizationId?: string;
  rfpId?: string;
  questionId?: string;
  commentId?: string;
}

export interface QuestionAssignedPayload {
  rfpTitle: string;
  questionNumber: number;
  questionText: string;
  actorName: string;
}

export interface CommentPayload {
  rfpTitle: string;
  questionNumber: number;
  questionText: string;
  actorName: string;
  excerpt: string;
}

export interface RfpCompletedPayload {
  rfpTitle: string;
  totalQuestions: number;
  approvedQuestions: number;
}

export interface RfpDeadlinePayload {
  rfpTitle: string;
  dueDate: string;
  hoursUntilDue: number;
  unansweredCount: number;
}

export interface BulkCompletedPayload {
  rfpTitle: string;
  completed: number;
  failed: number;
  total: number;
}

export type NotificationPayload =
  | { kind: "QUESTION_ASSIGNED"; data: QuestionAssignedPayload }
  | { kind: "COMMENT_ON_YOUR_QUESTION"; data: CommentPayload }
  | { kind: "COMMENT_MENTION"; data: CommentPayload }
  | { kind: "RFP_COMPLETED"; data: RfpCompletedPayload }
  | { kind: "RFP_DEADLINE_APPROACHING"; data: RfpDeadlinePayload }
  | { kind: "BULK_GENERATION_COMPLETED"; data: BulkCompletedPayload };

/**
 * Human-friendly metadata per notification kind. Used to drive the
 * preferences UI, email subjects, and inbox display.
 */
export const NOTIFICATION_KIND_META: Record<
  NotificationKind,
  {
    label: string;
    description: string;
    /** When true the email channel ships by default. */
    defaultEmail: boolean;
    /** When true the in-app channel ships by default (in-app is almost always on). */
    defaultInApp: boolean;
  }
> = {
  QUESTION_ASSIGNED: {
    label: "Question assigned to you",
    description: "A teammate assigns you to answer an RFP question.",
    defaultEmail: true,
    defaultInApp: true,
  },
  COMMENT_ON_YOUR_QUESTION: {
    label: "Comment on your question",
    description: "Someone comments on a question that's assigned to you.",
    defaultEmail: false,
    defaultInApp: true,
  },
  COMMENT_MENTION: {
    label: "You're @mentioned",
    description: "A teammate @mentions you in a comment.",
    defaultEmail: true,
    defaultInApp: true,
  },
  RFP_COMPLETED: {
    label: "RFP completed",
    description: "All questions on an RFP have been approved.",
    defaultEmail: false,
    defaultInApp: true,
  },
  RFP_DEADLINE_APPROACHING: {
    label: "RFP deadline approaching",
    description: "An RFP you're working on is due in the next 24 hours.",
    defaultEmail: true,
    defaultInApp: true,
  },
  BULK_GENERATION_COMPLETED: {
    label: "Bulk generation done",
    description: "A bulk generation run you started has finished.",
    defaultEmail: false,
    defaultInApp: true,
  },
};

/**
 * Helper to extract a short human summary for the inbox list / email subject.
 * Keeping it here so channels stay dumb.
 */
export function summarize(payload: NotificationPayload): string {
  switch (payload.kind) {
    case "QUESTION_ASSIGNED":
      return `${payload.data.actorName} assigned you Q${payload.data.questionNumber} on "${payload.data.rfpTitle}"`;
    case "COMMENT_ON_YOUR_QUESTION":
      return `${payload.data.actorName} commented on Q${payload.data.questionNumber}`;
    case "COMMENT_MENTION":
      return `${payload.data.actorName} mentioned you in a comment`;
    case "RFP_COMPLETED":
      return `"${payload.data.rfpTitle}" is complete (${payload.data.approvedQuestions}/${payload.data.totalQuestions} approved)`;
    case "RFP_DEADLINE_APPROACHING":
      return `"${payload.data.rfpTitle}" is due in ${payload.data.hoursUntilDue}h · ${payload.data.unansweredCount} unanswered`;
    case "BULK_GENERATION_COMPLETED":
      return `Bulk generation done · ${payload.data.completed}/${payload.data.total} for "${payload.data.rfpTitle}"`;
  }
}
