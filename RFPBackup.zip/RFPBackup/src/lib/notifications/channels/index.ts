// Channel registry. Add a new channel by importing it here and adding it to
// the map — the dispatcher will fan out to it automatically (subject to
// preferences). To support a new channel kind, also add a value to the
// NotificationChannel enum in prisma/schema.prisma.

import type { NotificationChannel } from "@prisma/client";
import type { NotificationChannelImpl } from "./types";
import { inAppChannel } from "./in-app";
import { emailChannel } from "./email";

export const CHANNELS: Partial<Record<NotificationChannel, NotificationChannelImpl>> = {
  IN_APP: inAppChannel,
  EMAIL: emailChannel,
};

export const ALL_CHANNELS: NotificationChannel[] = ["IN_APP", "EMAIL"];
