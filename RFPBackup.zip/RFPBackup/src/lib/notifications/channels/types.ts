import type { NotificationPayload, NotificationContext } from "../types";
import type { NotificationChannel } from "@prisma/client";

export interface DeliverOptions {
  ctx: NotificationContext;
  payload: NotificationPayload;
}

/**
 * Channel implementation surface. Channels know how to deliver a notification
 * over their own medium (in-app inbox, email, future: Slack, webhook).
 * Failure is logged but never thrown — one channel's outage should not block
 * the others.
 */
export interface NotificationChannelImpl {
  readonly id: NotificationChannel;
  deliver(opts: DeliverOptions): Promise<void>;
}
