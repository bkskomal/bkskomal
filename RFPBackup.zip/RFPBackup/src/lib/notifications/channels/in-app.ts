import { prisma } from "@/lib/prisma";
import type { NotificationChannelImpl } from "./types";

/**
 * Persist the notification to the DB. The UI polls /api/notifications and
 * shows the unread count in the header bell.
 */
export const inAppChannel: NotificationChannelImpl = {
  id: "IN_APP",
  async deliver({ ctx, payload }) {
    await prisma.notification.create({
      data: {
        userId: ctx.userId,
        actorId: ctx.actorId ?? null,
        kind: payload.kind,
        payload: payload.data as never,
        organizationId: ctx.organizationId,
        rfpId: ctx.rfpId,
        questionId: ctx.questionId,
        commentId: ctx.commentId,
      },
    });
  },
};
