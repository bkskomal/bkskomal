// Email channel — uses the same Nodemailer config NextAuth uses for magic
// links. Templates are inline because we send a small number of kinds; if
// this grows, factor them out into `lib/notifications/templates/`.

import nodemailer from "nodemailer";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { summarize, type NotificationPayload } from "../types";
import type { NotificationChannelImpl } from "./types";

let cachedTransporter: nodemailer.Transporter | null = null;
function transporter() {
  if (cachedTransporter) return cachedTransporter;
  cachedTransporter = nodemailer.createTransport({
    host: env.EMAIL_SERVER_HOST,
    port: env.EMAIL_SERVER_PORT,
    auth: env.EMAIL_SERVER_USER
      ? { user: env.EMAIL_SERVER_USER, pass: env.EMAIL_SERVER_PASSWORD }
      : undefined,
  });
  return cachedTransporter;
}

function appUrl(): string {
  return env.AUTH_URL ?? env.NEXTAUTH_URL ?? "http://localhost:3000";
}

function deepLink(payload: NotificationPayload, ctx: { rfpId?: string; organizationId?: string }): string {
  const base = appUrl();
  if (ctx.rfpId) return `${base}/dashboard/rfps/${ctx.rfpId}`;
  if (ctx.organizationId) return `${base}/dashboard?org=${ctx.organizationId}`;
  return `${base}/dashboard`;
}

function renderBody(payload: NotificationPayload, ctx: { rfpId?: string; organizationId?: string }) {
  const url = deepLink(payload, ctx);
  const summary = summarize(payload);

  switch (payload.kind) {
    case "QUESTION_ASSIGNED":
      return {
        subject: `[AutoRFP] ${summary}`,
        text: `${summary}\n\n"${payload.data.questionText}"\n\nOpen the RFP: ${url}`,
        html: `<p><strong>${escape(payload.data.actorName)}</strong> assigned you a question on <strong>${escape(payload.data.rfpTitle)}</strong>.</p>
<blockquote style="border-left:3px solid #8a2be2;padding:8px 12px;color:#444;margin:12px 0">${escape(payload.data.questionText)}</blockquote>
<p><a href="${url}">Open the RFP →</a></p>`,
      };
    case "COMMENT_ON_YOUR_QUESTION":
      return {
        subject: `[AutoRFP] New comment on Q${payload.data.questionNumber}`,
        text: `${payload.data.actorName} commented on Q${payload.data.questionNumber}:\n\n"${payload.data.excerpt}"\n\n${url}`,
        html: `<p><strong>${escape(payload.data.actorName)}</strong> commented on Q${payload.data.questionNumber} of <em>${escape(payload.data.rfpTitle)}</em>:</p>
<blockquote style="border-left:3px solid #888;padding:8px 12px;color:#444;margin:12px 0">${escape(payload.data.excerpt)}</blockquote>
<p><a href="${url}">Open the RFP →</a></p>`,
      };
    case "COMMENT_MENTION":
      return {
        subject: `[AutoRFP] ${payload.data.actorName} mentioned you`,
        text: `${payload.data.actorName} @mentioned you on Q${payload.data.questionNumber}:\n\n"${payload.data.excerpt}"\n\n${url}`,
        html: `<p><strong>${escape(payload.data.actorName)}</strong> mentioned you in a comment on Q${payload.data.questionNumber} of <em>${escape(payload.data.rfpTitle)}</em>:</p>
<blockquote style="border-left:3px solid #8a2be2;padding:8px 12px;color:#444;margin:12px 0">${escape(payload.data.excerpt)}</blockquote>
<p><a href="${url}">Reply →</a></p>`,
      };
    case "RFP_COMPLETED":
      return {
        subject: `[AutoRFP] "${payload.data.rfpTitle}" is complete`,
        text: `${summary}\n\n${url}`,
        html: `<p>🎉 <strong>${escape(payload.data.rfpTitle)}</strong> is fully approved.</p>
<p>${payload.data.approvedQuestions} / ${payload.data.totalQuestions} questions approved.</p>
<p><a href="${url}">Open the RFP →</a></p>`,
      };
    case "RFP_DEADLINE_APPROACHING":
      return {
        subject: `[AutoRFP] Deadline in ${payload.data.hoursUntilDue}h: ${payload.data.rfpTitle}`,
        text: `${summary}\nDue: ${payload.data.dueDate}\n\n${url}`,
        html: `<p>⏰ <strong>${escape(payload.data.rfpTitle)}</strong> is due in <strong>${payload.data.hoursUntilDue} hours</strong>.</p>
<p>${payload.data.unansweredCount} questions still unanswered.</p>
<p><a href="${url}">Open the RFP →</a></p>`,
      };
    case "BULK_GENERATION_COMPLETED":
      return {
        subject: `[AutoRFP] Bulk generation done · ${payload.data.completed}/${payload.data.total}`,
        text: `${summary}\n\n${url}`,
        html: `<p>Bulk generation finished for <strong>${escape(payload.data.rfpTitle)}</strong>.</p>
<p>${payload.data.completed} succeeded, ${payload.data.failed} failed (of ${payload.data.total}).</p>
<p><a href="${url}">Open the RFP →</a></p>`,
      };
  }
}

function escape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export const emailChannel: NotificationChannelImpl = {
  id: "EMAIL",
  async deliver({ ctx, payload }) {
    const user = await prisma.user.findUnique({
      where: { id: ctx.userId },
      select: { email: true },
    });
    if (!user?.email) return;

    const { subject, text, html } = renderBody(payload, ctx);

    await transporter().sendMail({
      from: env.EMAIL_FROM,
      to: user.email,
      subject,
      text,
      html,
    });
  },
};
