// Resolve effective preferences for a user. Per-row settings override the
// hardcoded defaults from NOTIFICATION_KIND_META.

import { prisma } from "@/lib/prisma";
import type { NotificationChannel, NotificationKind } from "@prisma/client";
import { NOTIFICATION_KIND_META } from "./types";

export interface EffectivePreference {
  kind: NotificationKind;
  inApp: boolean;
  email: boolean;
}

function defaultFor(kind: NotificationKind, channel: NotificationChannel): boolean {
  const meta = NOTIFICATION_KIND_META[kind];
  return channel === "EMAIL" ? meta.defaultEmail : meta.defaultInApp;
}

export async function getEffectivePreferences(userId: string): Promise<EffectivePreference[]> {
  const rows = await prisma.notificationPreference.findMany({ where: { userId } });
  const byKey = new Map<string, boolean>();
  for (const r of rows) byKey.set(`${r.kind}:${r.channel}`, r.enabled);

  const kinds: NotificationKind[] = Object.keys(NOTIFICATION_KIND_META) as NotificationKind[];
  return kinds.map((kind) => ({
    kind,
    inApp: byKey.get(`${kind}:IN_APP`) ?? defaultFor(kind, "IN_APP"),
    email: byKey.get(`${kind}:EMAIL`) ?? defaultFor(kind, "EMAIL"),
  }));
}

export async function isEnabled(
  userId: string,
  kind: NotificationKind,
  channel: NotificationChannel,
): Promise<boolean> {
  const row = await prisma.notificationPreference.findUnique({
    where: { userId_kind_channel: { userId, kind, channel } },
  });
  if (row) return row.enabled;
  return defaultFor(kind, channel);
}
