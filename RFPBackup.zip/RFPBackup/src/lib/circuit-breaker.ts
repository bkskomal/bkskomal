// Generic circuit breaker.
//
// Three states:
//   CLOSED    — calls pass through. Consecutive failures bump a counter; on
//               reaching failureThreshold, transition to OPEN.
//   OPEN      — calls reject immediately with CircuitOpenError until
//               resetTimeoutMs has elapsed since opening. Then HALF_OPEN.
//   HALF_OPEN — one probe call is allowed through at a time. On success,
//               accumulate; after halfOpenSuccesses successes, return to
//               CLOSED. On failure, return to OPEN with a fresh timeout.
//
// Intended for wrapping external HTTP calls (LLM provider, etc.) where a
// stalled upstream should fail fast rather than tying up every in-flight
// request. Use one breaker per "thing that can fail independently" — for the
// LLM client that means one per provider baseUrl.

import { AppError } from "@/lib/errors";
import { circuitBreakerState, CIRCUIT_STATE_VALUE } from "@/lib/metrics";

export class CircuitOpenError extends AppError {
  status = 503;
  code = "circuit_open";
  exposeMessage = true;
  breaker: string;
  constructor(breakerName: string) {
    super(`Service temporarily unavailable (${breakerName}). Try again shortly.`);
    this.breaker = breakerName;
  }
}

export type CircuitState = "CLOSED" | "OPEN" | "HALF_OPEN";

export interface BreakerOptions {
  name: string;
  failureThreshold: number;
  resetTimeoutMs: number;
  /** Number of consecutive HALF_OPEN successes needed to close. Default 1. */
  halfOpenSuccesses?: number;
}

interface BreakerInternals {
  state: CircuitState;
  consecutiveFailures: number;
  consecutiveHalfOpenSuccesses: number;
  /** Wall-clock ms (per nowFn) when the current OPEN window started. */
  openedAt: number;
  /** Pending probe: only one HALF_OPEN call may be in-flight at a time. */
  probeInFlight: boolean;
}

/** Internal clock indirection so tests can mock time. */
let nowFn: () => number = () => Date.now();

/** @internal — for tests only. */
export function _setNowForTests(fn: () => number): void {
  nowFn = fn;
}

/** @internal — for tests only. Resets the clock. */
export function _resetClockForTests(): void {
  nowFn = () => Date.now();
}

export interface Breaker {
  <T>(fn: () => Promise<T>): Promise<T>;
  /** Snapshot of current state — primarily for tests / observability. */
  inspect(): { state: CircuitState; failures: number; openedAt: number };
  /** Force-reset to CLOSED. Primarily for tests. */
  reset(): void;
}

/**
 * Build a circuit breaker. Returns a function that wraps an async fn —
 * call `breaker(() => doThing())`.
 *
 * Note: identifies failures purely by promise rejection. If an upstream
 * returns HTTP 200 with a body that semantically means "broken", the breaker
 * won't notice — that's deliberate; the caller's job is to throw.
 */
export function createBreaker(opts: BreakerOptions): Breaker {
  const halfOpenK = opts.halfOpenSuccesses ?? 1;
  const state: BreakerInternals = {
    state: "CLOSED",
    consecutiveFailures: 0,
    consecutiveHalfOpenSuccesses: 0,
    openedAt: 0,
    probeInFlight: false,
  };

  // Seed the gauge so scrapers see the breaker exists even before its first
  // failure. Cheap; runs once per breaker instantiation.
  circuitBreakerState.set({ name: opts.name }, CIRCUIT_STATE_VALUE.CLOSED);

  function setState(next: CircuitState): void {
    state.state = next;
    circuitBreakerState.set({ name: opts.name }, CIRCUIT_STATE_VALUE[next]);
  }

  function trip(): void {
    setState("OPEN");
    state.openedAt = nowFn();
    state.consecutiveHalfOpenSuccesses = 0;
  }

  function close(): void {
    setState("CLOSED");
    state.consecutiveFailures = 0;
    state.consecutiveHalfOpenSuccesses = 0;
    state.probeInFlight = false;
  }

  async function run<T>(fn: () => Promise<T>): Promise<T> {
    // Possibly transition OPEN -> HALF_OPEN before deciding to admit the call.
    if (state.state === "OPEN" && nowFn() - state.openedAt >= opts.resetTimeoutMs) {
      setState("HALF_OPEN");
      state.consecutiveHalfOpenSuccesses = 0;
      state.probeInFlight = false;
    }

    if (state.state === "OPEN") {
      throw new CircuitOpenError(opts.name);
    }

    if (state.state === "HALF_OPEN") {
      // Only one probe in flight. Additional calls during the probe reject
      // immediately so we don't pile load onto a possibly-still-broken
      // upstream.
      if (state.probeInFlight) {
        throw new CircuitOpenError(opts.name);
      }
      state.probeInFlight = true;
    }

    try {
      const result = await fn();
      // Success.
      if (state.state === "HALF_OPEN") {
        state.consecutiveHalfOpenSuccesses += 1;
        state.probeInFlight = false;
        if (state.consecutiveHalfOpenSuccesses >= halfOpenK) {
          close();
        }
      } else {
        // CLOSED — reset failure counter on any success.
        state.consecutiveFailures = 0;
      }
      return result;
    } catch (err) {
      if (state.state === "HALF_OPEN") {
        state.probeInFlight = false;
        trip();
      } else {
        state.consecutiveFailures += 1;
        if (state.consecutiveFailures >= opts.failureThreshold) {
          trip();
        }
      }
      throw err;
    }
  }

  const fn = (<T>(work: () => Promise<T>) => run(work)) as Breaker;
  fn.inspect = () => ({
    state: state.state,
    failures: state.consecutiveFailures,
    openedAt: state.openedAt,
  });
  fn.reset = () => close();
  return fn;
}
