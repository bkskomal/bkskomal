// Word (.docx) export — produces a polished response document with cover
// header, RFP metadata, and Q/A pairs grouped by section.
//
// Uses the `docx` library (pure-JS, no native deps). Returns a Node Buffer.

import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  PageBreak,
  ShadingType,
  BorderStyle,
} from "docx";
import { prisma } from "@/lib/prisma";
import { NotFoundError } from "@/lib/errors";

export interface ExportOptions {
  /** Only include questions whose status is APPROVED. */
  approvedOnly?: boolean;
  /** Include sources block under each answer. */
  includeSources?: boolean;
}

export async function exportRfpToWord(
  rfpId: string,
  options: ExportOptions = {},
): Promise<{ filename: string; buffer: Buffer }> {
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: {
      project: { include: { organization: true } },
      questions: {
        orderBy: { number: "asc" },
        include: {
          responses: {
            where: { status: "COMPLETED" },
            orderBy: { createdAt: "desc" },
            take: 1,
            include: { sources: true },
          },
        },
      },
    },
  });
  if (!rfp) throw new NotFoundError("RFP not found");

  const filteredQuestions = options.approvedOnly
    ? rfp.questions.filter((q) => q.status === "APPROVED")
    : rfp.questions;

  // Group by section.
  const grouped = new Map<string, typeof filteredQuestions>();
  for (const q of filteredQuestions) {
    const key = q.section ?? "General";
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key)!.push(q);
  }

  const children: Paragraph[] = [];

  // Header / cover.
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 400, after: 200 },
      children: [
        new TextRun({
          text: rfp.project.organization.name.toUpperCase(),
          bold: true,
          size: 22,
          color: "888888",
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
      children: [
        new TextRun({ text: "Response to RFP", italics: true, color: "666666" }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 600 },
      children: [
        new TextRun({ text: rfp.title, bold: true, size: 36 }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [
        new TextRun({
          text: `Project: ${rfp.project.name}  ·  ${filteredQuestions.length} question${filteredQuestions.length === 1 ? "" : "s"}  ·  ${new Date().toLocaleDateString()}`,
          color: "666666",
          size: 18,
        }),
      ],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  );

  // Body — sections + Q/A.
  for (const [section, questions] of grouped) {
    children.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 400, after: 200 },
        children: [new TextRun({ text: section, bold: true, size: 28 })],
      }),
    );

    for (const q of questions) {
      const r = q.responses[0];

      // Question block — bordered, shaded.
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 300, after: 100 },
          shading: { type: ShadingType.SOLID, color: "F4F1FA", fill: "F4F1FA" },
          border: {
            top: { style: BorderStyle.SINGLE, size: 6, color: "8A2BE2" },
            left: { style: BorderStyle.SINGLE, size: 6, color: "8A2BE2" },
            right: { style: BorderStyle.SINGLE, size: 6, color: "8A2BE2" },
            bottom: { style: BorderStyle.SINGLE, size: 6, color: "8A2BE2" },
          },
          children: [
            new TextRun({ text: `Q${q.number}. `, bold: true, color: "5B21B6" }),
            new TextRun({ text: q.text, bold: true }),
          ],
        }),
      );

      // Answer.
      if (!r) {
        children.push(
          new Paragraph({
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: "[No response generated yet]",
                italics: true,
                color: "AA4444",
              }),
            ],
          }),
        );
      } else {
        // Render markdown-ish content as paragraphs/runs (lightweight; keep it
        // simple — bold, italic, bullets, paragraph breaks).
        for (const para of mdToParagraphs(r.content)) {
          children.push(para);
        }

        if (options.includeSources && r.sources.length > 0) {
          children.push(
            new Paragraph({
              spacing: { before: 100, after: 50 },
              children: [
                new TextRun({
                  text: "Sources",
                  bold: true,
                  size: 18,
                  color: "888888",
                }),
              ],
            }),
          );
          r.sources.forEach((s, i) => {
            children.push(
              new Paragraph({
                spacing: { after: 40 },
                indent: { left: 360 },
                children: [
                  new TextRun({
                    text: `[${i + 1}] ${s.fileName ?? "—"}${s.page ? `, p. ${s.page}` : ""}`,
                    size: 16,
                    color: "888888",
                  }),
                ],
              }),
            );
          });
        }

        // Confidence / review-flag footnote.
        if (typeof r.confidence === "number" || r.needsReview) {
          const parts: string[] = [];
          if (typeof r.confidence === "number") {
            parts.push(`Confidence ${Math.round(r.confidence * 100)}%`);
          }
          if (r.needsReview) parts.push("Needs human review");
          children.push(
            new Paragraph({
              spacing: { before: 60, after: 200 },
              children: [
                new TextRun({
                  text: parts.join("  ·  "),
                  italics: true,
                  color: "AA8800",
                  size: 16,
                }),
              ],
            }),
          );
        }
      }
    }
  }

  const doc = new Document({
    creator: rfp.project.organization.name,
    title: `Response to ${rfp.title}`,
    description: `AutoRFP-generated response document`,
    sections: [{ properties: {}, children }],
  });

  const buffer = await Packer.toBuffer(doc);
  const safeTitle = rfp.title.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
  const date = new Date().toISOString().slice(0, 10);
  return {
    filename: `${safeTitle}_response_${date}.docx`,
    buffer,
  };
}

/**
 * Translate a small subset of markdown (paragraphs, **bold**, *italic*,
 * bullet lines, headings) into docx Paragraphs. Anything fancier rounds-trips
 * as plain text — good enough for response output.
 */
function mdToParagraphs(md: string): Paragraph[] {
  const out: Paragraph[] = [];
  const lines = md.split(/\r?\n/);
  let i = 0;
  let buffer: string[] = [];

  const flushBuffer = () => {
    if (buffer.length === 0) return;
    out.push(
      new Paragraph({
        spacing: { after: 100 },
        children: parseInline(buffer.join(" ")),
      }),
    );
    buffer = [];
  };

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();
    if (!trimmed) {
      flushBuffer();
      i++;
      continue;
    }
    // headings
    const heading = /^(#{1,3})\s+(.*)/.exec(trimmed);
    if (heading) {
      flushBuffer();
      const level = heading[1].length;
      out.push(
        new Paragraph({
          heading: level === 1 ? HeadingLevel.HEADING_2 : level === 2 ? HeadingLevel.HEADING_3 : HeadingLevel.HEADING_4,
          spacing: { before: 200, after: 100 },
          children: [new TextRun({ text: heading[2], bold: true })],
        }),
      );
      i++;
      continue;
    }
    // bullets / numbered list
    const bullet = /^[-*]\s+(.*)/.exec(trimmed);
    const numbered = /^(\d+)\.\s+(.*)/.exec(trimmed);
    if (bullet || numbered) {
      flushBuffer();
      const text = bullet ? bullet[1] : numbered![2];
      out.push(
        new Paragraph({
          bullet: bullet ? { level: 0 } : undefined,
          numbering: numbered ? { reference: "default-numbering", level: 0 } : undefined,
          spacing: { after: 60 },
          indent: { left: 360 },
          children: [
            new TextRun({ text: numbered ? `${numbered[1]}. ` : "" }),
            ...parseInline(text),
          ],
        }),
      );
      i++;
      continue;
    }
    buffer.push(trimmed);
    i++;
  }
  flushBuffer();
  return out;
}

function parseInline(text: string): TextRun[] {
  // Very small inline formatter: **bold**, *italic*, `code`, [Source N] left as plain.
  const runs: TextRun[] = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = re.exec(text)) !== null) {
    if (match.index > lastIndex) {
      runs.push(new TextRun({ text: text.slice(lastIndex, match.index) }));
    }
    const tok = match[0];
    if (tok.startsWith("**")) {
      runs.push(new TextRun({ text: tok.slice(2, -2), bold: true }));
    } else if (tok.startsWith("`")) {
      runs.push(new TextRun({ text: tok.slice(1, -1), font: "Courier New" }));
    } else {
      runs.push(new TextRun({ text: tok.slice(1, -1), italics: true }));
    }
    lastIndex = match.index + tok.length;
  }
  if (lastIndex < text.length) {
    runs.push(new TextRun({ text: text.slice(lastIndex) }));
  }
  return runs.length ? runs : [new TextRun({ text })];
}
