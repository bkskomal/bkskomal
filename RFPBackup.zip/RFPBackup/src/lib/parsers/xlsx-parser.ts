// XLSX parser — per-sheet structured extraction.
//
// For each non-empty sheet we emit:
//   • HeadingBlock (level 1) with the sheet name (and a PageBreak between sheets).
//   • TableBlock with headers + rows + Markdown rendering.
//
// We also extract any embedded images (header logos, drawing-anchored images)
// from the xl/media/ folder of the OpenXML zip. They become FigureBlocks with
// imageBuffer so the pipeline's image-processing step (CLIP embed + persist)
// picks them up.
//
// We handle:
//   • Merged cells via !merges — fill all cells in the merge range with the
//     top-left value (so downstream consumers see a normal rectangular table).
//   • Formula detection — when any cell has an `.f`, we list the formula
//     functions used as a side note in the table caption.
//   • Multi-sheet workbooks become a sequence of (heading, table) pairs
//     separated by PageBreaks.
//   • Embedded images — appended as FigureBlocks at the end of the AST so
//     they don't disrupt the heading/table flow.

import {
  anchorFor,
  type DocumentAST,
  type DocumentParser,
  type ParseOptions,
  type ParseReport,
  type ParseWarning,
  type Block,
} from "./ast";
import { tableToMarkdown } from "./table-md";
import { extractImagesFromOpenXml } from "./openxml-images";

export const XLSX_PARSER_VERSION = "xlsx-2026-05-02";

const XLSX_MIMES = new Set([
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-excel",
]);

export const xlsxParser: DocumentParser = {
  id: "xlsx",
  version: XLSX_PARSER_VERSION,
  canParse(buffer, opts) {
    if (opts.mimeType && XLSX_MIMES.has(opts.mimeType)) return true;
    if (opts.fileName?.match(/\.xlsx?$/i)) return true;
    return false;
  },
  async parse(buffer, opts): Promise<DocumentAST> {
    return parseXlsxBuffer(buffer, opts);
  },
};

export async function parseXlsxBuffer(
  buffer: Buffer,
  _opts: ParseOptions,
): Promise<DocumentAST> {
  const t0 = Date.now();
  const warnings: ParseWarning[] = [];
  const errors: ParseWarning[] = [];

  if (buffer.byteLength === 0) {
    warnings.push({ code: "empty_input", message: "XLSX input is empty." });
    return emptyXlsxAst(t0, warnings, errors);
  }

  const XLSX = await import("xlsx");
  let wb;
  try {
    wb = XLSX.read(buffer, { type: "buffer", cellFormula: true, cellDates: true });
  } catch (e) {
    errors.push({
      code: "xlsx_read_failed",
      message: `XLSX read failed: ${e instanceof Error ? e.message : String(e)}`,
    });
    return emptyXlsxAst(t0, warnings, errors);
  }

  const blocks: Block[] = [];
  let ordinal = 0;
  let tableCount = 0;
  let title: string | undefined;

  const sheetNames = wb.SheetNames ?? [];
  for (let si = 0; si < sheetNames.length; si++) {
    const sheetName = sheetNames[si];
    const sheet = wb.Sheets[sheetName];
    if (!sheet) continue;

    const ref = sheet["!ref"];
    if (!ref) {
      warnings.push({
        code: "empty_sheet",
        message: `Sheet "${sheetName}" is empty.`,
        context: { sheet: sheetName },
      });
      continue;
    }

    const range = XLSX.utils.decode_range(ref);
    // Build a 2D grid covering rows [r0..r1] x cols [c0..c1].
    const r0 = range.s.r;
    const r1 = range.e.r;
    const c0 = range.s.c;
    const c1 = range.e.c;
    const nRows = r1 - r0 + 1;
    const nCols = c1 - c0 + 1;
    const grid: string[][] = Array.from({ length: nRows }, () =>
      Array.from({ length: nCols }, () => ""),
    );

    // Collect formula functions used (e.g. SUM, VLOOKUP) for the caption.
    const formulaFns = new Set<string>();

    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const addr = XLSX.utils.encode_cell({ r, c });
        const cell = sheet[addr];
        if (!cell) continue;
        const v = cell.w ?? formatCellValue(cell.v);
        grid[r - r0][c - c0] = v;
        if (typeof cell.f === "string") {
          for (const m of cell.f.matchAll(/([A-Z][A-Z0-9.]+)\s*\(/g)) {
            formulaFns.add(m[1]);
          }
        }
      }
    }

    // Apply merges: fill non-top-left cells of each merge with the top-left's value.
    const merges = (sheet["!merges"] ?? []) as Array<{
      s: { r: number; c: number };
      e: { r: number; c: number };
    }>;
    let mergeNotes = 0;
    for (const m of merges) {
      const r = m.s.r;
      const c = m.s.c;
      // Only operate within our captured grid range.
      if (r < r0 || c < c0) continue;
      const value = grid[r - r0]?.[c - c0] ?? "";
      for (let rr = m.s.r; rr <= m.e.r; rr++) {
        for (let cc = m.s.c; cc <= m.e.c; cc++) {
          if (rr === m.s.r && cc === m.s.c) continue;
          if (rr - r0 < 0 || cc - c0 < 0) continue;
          if (rr - r0 >= nRows || cc - c0 >= nCols) continue;
          if (!grid[rr - r0][cc - c0]) grid[rr - r0][cc - c0] = value;
        }
      }
      mergeNotes += 1;
    }

    // Strip leading/trailing fully-empty rows.
    let firstRow = 0;
    while (firstRow < grid.length && grid[firstRow].every((c) => c === "")) firstRow += 1;
    let lastRow = grid.length - 1;
    while (lastRow >= firstRow && grid[lastRow].every((c) => c === "")) lastRow -= 1;
    const trimmed = grid.slice(firstRow, lastRow + 1);

    if (trimmed.length === 0) {
      warnings.push({
        code: "empty_sheet",
        message: `Sheet "${sheetName}" has no data.`,
        context: { sheet: sheetName },
      });
      continue;
    }

    // Strip trailing fully-empty columns.
    let lastCol = trimmed[0].length - 1;
    while (
      lastCol >= 0 &&
      trimmed.every((r) => (r[lastCol] ?? "") === "")
    ) {
      lastCol -= 1;
    }
    const rectangular = trimmed.map((r) => r.slice(0, lastCol + 1));

    // Heuristic: first row is headers when it has ≥2 cells, all non-empty,
    // and the cells below are predominantly numbers or short strings.
    const first = rectangular[0];
    const looksLikeHeader =
      first.length >= 2 &&
      first.every((c) => c.length > 0) &&
      rectangular.length > 1;
    const headers = looksLikeHeader ? first : undefined;
    const rows = looksLikeHeader ? rectangular.slice(1) : rectangular;

    // Sheet heading.
    const headingSection = sheetName;
    blocks.push({
      kind: "heading",
      level: 1,
      text: sheetName,
      section: headingSection,
      anchor: anchorFor(headingSection, ordinal++),
    });
    if (!title) title = sheetName;

    // Caption with formula + merge notes.
    const captionParts: string[] = [];
    if (formulaFns.size > 0) {
      const fns = Array.from(formulaFns)
        .slice(0, 6)
        .map((f) => `=${f}`)
        .join(", ");
      captionParts.push(`Cells use ${fns}`);
    }
    if (mergeNotes > 0) {
      captionParts.push(`${mergeNotes} merged ranges normalized`);
    }
    const caption = captionParts.length ? captionParts.join("; ") : undefined;

    blocks.push({
      kind: "table",
      headers,
      rows,
      markdown: tableToMarkdown(headers, rows),
      caption,
      section: headingSection,
      anchor: anchorFor(headingSection, ordinal++),
      confidence: 0.95,
    });
    tableCount += 1;

    // Page break between sheets (not after the last).
    if (si < sheetNames.length - 1) {
      blocks.push({
        kind: "page_break",
        toPage: si + 2,
        section: headingSection,
        anchor: anchorFor(headingSection, ordinal++),
      });
    }
  }

  // Extract embedded images from xl/media/. Appended as FigureBlocks at the
  // end of the AST. The pipeline's image-processing step will store + CLIP
  // embed each one. Failures are non-fatal.
  let figureCount = 0;
  try {
    const images = await extractImagesFromOpenXml(buffer, { format: "xlsx" });
    for (const img of images) {
      const section = "Images";
      blocks.push({
        kind: "figure",
        caption: img.zipPath.replace(/^xl\/media\//, ""),
        imageBuffer: img.buffer,
        section,
        anchor: anchorFor(section, ordinal++),
      });
      figureCount += 1;
    }
    if (images.length > 0) {
      // Insert a "Images" heading before the figures so chunk section paths look right.
      const firstFigureIndex = blocks.length - figureCount;
      blocks.splice(firstFigureIndex, 0, {
        kind: "heading",
        level: 1,
        text: "Images",
        section: "Images",
        anchor: anchorFor("Images", ordinal++),
      });
    }
  } catch (e) {
    warnings.push({
      code: "xlsx_image_extract_failed",
      message: `Failed to extract embedded images: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  const report: ParseReport = {
    parser: "xlsx",
    parserVersion: XLSX_PARSER_VERSION,
    pageCount: sheetNames.length,
    blockCount: blocks.length,
    tableCount,
    listCount: 0,
    figureCount,
    ocrUsed: false,
    parseMs: Date.now() - t0,
    warnings,
    errors,
  };

  return {
    metadata: {
      title,
      parser: "xlsx",
      parserVersion: XLSX_PARSER_VERSION,
      pageCount: sheetNames.length,
    },
    blocks,
    report,
  };
}

function formatCellValue(v: unknown): string {
  if (v === null || v === undefined) return "";
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === "number") {
    return Number.isInteger(v) ? String(v) : String(v);
  }
  if (typeof v === "boolean") return v ? "TRUE" : "FALSE";
  return String(v);
}

function emptyXlsxAst(
  t0: number,
  warnings: ParseWarning[],
  errors: ParseWarning[],
): DocumentAST {
  return {
    metadata: { parser: "xlsx", parserVersion: XLSX_PARSER_VERSION },
    blocks: [],
    report: {
      parser: "xlsx",
      parserVersion: XLSX_PARSER_VERSION,
      blockCount: 0,
      tableCount: 0,
      listCount: 0,
      figureCount: 0,
      ocrUsed: false,
      parseMs: Date.now() - t0,
      warnings,
      errors,
    },
  };
}
