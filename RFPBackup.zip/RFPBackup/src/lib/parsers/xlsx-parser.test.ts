import { describe, it, expect } from "vitest";
import * as XLSX from "xlsx";
import { parseXlsxBuffer } from "./xlsx-parser";
import { astToMarkdown } from "./ast";

function makeXlsx(sheets: Record<string, unknown[][]>, opts: {
  merges?: Record<string, XLSX.Range[]>;
  formulas?: Record<string, { addr: string; formula: string }[]>;
} = {}): Buffer {
  const wb = XLSX.utils.book_new();
  for (const [name, rows] of Object.entries(sheets)) {
    const ws = XLSX.utils.aoa_to_sheet(rows);
    if (opts.merges?.[name]) ws["!merges"] = opts.merges[name];
    if (opts.formulas?.[name]) {
      for (const f of opts.formulas[name]) {
        ws[f.addr] = { t: "n", v: 0, f: f.formula };
      }
    }
    XLSX.utils.book_append_sheet(wb, ws, name);
  }
  const out = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
  return Buffer.isBuffer(out) ? out : Buffer.from(out as ArrayBuffer);
}

describe("xlsxParser", () => {
  it("returns empty AST + warning for empty input", async () => {
    const ast = await parseXlsxBuffer(Buffer.alloc(0), { fileName: "x.xlsx" });
    expect(ast.blocks).toEqual([]);
    expect(ast.report.warnings.some((w) => w.code === "empty_input")).toBe(true);
  });

  it("emits a heading + table per sheet", async () => {
    const buf = makeXlsx({
      Pricing: [
        ["Plan", "Cost"],
        ["Basic", 10],
        ["Pro", 30],
      ],
    });
    const ast = await parseXlsxBuffer(buf, { fileName: "x.xlsx" });
    expect(ast.metadata.parser).toBe("xlsx");
    expect(ast.blocks[0].kind).toBe("heading");
    const heading = ast.blocks[0];
    if (heading.kind === "heading") expect(heading.text).toBe("Pricing");
    const table = ast.blocks.find((b) => b.kind === "table");
    if (table?.kind !== "table") throw new Error("nope");
    expect(table.headers).toEqual(["Plan", "Cost"]);
    expect(table.rows).toEqual([
      ["Basic", "10"],
      ["Pro", "30"],
    ]);
  });

  it("handles merged cells by repeating top-left value", async () => {
    // A1 spans across A1:B1.
    const buf = makeXlsx(
      {
        Sheet1: [
          ["Header spans both", ""],
          ["x", "y"],
          ["1", "2"],
        ],
      },
      { merges: { Sheet1: [{ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }] } },
    );
    const ast = await parseXlsxBuffer(buf, { fileName: "m.xlsx" });
    const table = ast.blocks.find((b) => b.kind === "table");
    if (table?.kind !== "table") throw new Error("nope");
    // The first row was repeated across the merged span; subsequent code
    // treats it as headers when looksLikeHeader is true.
    const allCells = [
      ...(table.headers ?? []),
      ...table.rows.flat(),
    ].join("|");
    expect(allCells).toContain("Header spans both");
  });

  it("annotates formulas in the table caption", async () => {
    const buf = makeXlsx(
      {
        S: [
          ["A", "B", "Total"],
          [1, 2, 0],
        ],
      },
      { formulas: { S: [{ addr: "C2", formula: "SUM(A2:B2)" }] } },
    );
    const ast = await parseXlsxBuffer(buf, { fileName: "f.xlsx" });
    const table = ast.blocks.find((b) => b.kind === "table");
    if (table?.kind !== "table") throw new Error("nope");
    expect(table.caption ?? "").toContain("SUM");
  });

  it("multi-sheet workbook: heading + table + page_break + heading + table", async () => {
    const buf = makeXlsx({
      One: [
        ["a", "b"],
        ["1", "2"],
      ],
      Two: [
        ["x", "y"],
        ["9", "8"],
      ],
    });
    const ast = await parseXlsxBuffer(buf, { fileName: "ms.xlsx" });
    const kinds = ast.blocks.map((b) => b.kind);
    expect(kinds.filter((k) => k === "heading")).toHaveLength(2);
    expect(kinds.filter((k) => k === "table")).toHaveLength(2);
    expect(kinds.filter((k) => k === "page_break")).toHaveLength(1);
  });

  it("round-trips through astToMarkdown", async () => {
    const buf = makeXlsx({
      S: [
        ["A", "B"],
        ["1", "2"],
      ],
    });
    const ast = await parseXlsxBuffer(buf, { fileName: "r.xlsx" });
    const md = astToMarkdown(ast);
    expect(md).toContain("# S");
    expect(md).toContain("| A | B |");
    expect(md).toContain("| 1 | 2 |");
  });
});
