// image-store tests.
//
// Verifies content-addressing (same bytes → same path), read-after-write
// roundtrip, and idempotent delete. We don't mock the filesystem — the
// store writes under uploads/images/ which is part of the repo, so we
// clean up our test fixtures afterward.

import { describe, expect, it, afterAll } from "vitest";
import { storeImageBytes, readStoredImage, deleteStoredImage } from "./image-store";

// Construct a small distinguishable byte buffer per test so concurrent runs
// don't collide. We append a uniqueness prefix to a 1×1 PNG so each test
// case hashes to a unique path.
const ONE_PIXEL_PNG = Buffer.from(
  "89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000A49444154789C6300010000000500010D0A2DB40000000049454E44AE426082",
  "hex",
);

function unique(prefix: string): Buffer {
  return Buffer.concat([Buffer.from(prefix, "utf8"), ONE_PIXEL_PNG]);
}

const writtenPaths: string[] = [];

afterAll(async () => {
  for (const p of writtenPaths) {
    try {
      await deleteStoredImage(p);
    } catch {
      // best-effort cleanup
    }
  }
});

describe("image-store", () => {
  it("storing the same buffer twice returns the same path (content-addressed)", async () => {
    const buf = unique("dedupe-test-1");
    const a = await storeImageBytes({ buffer: buf, mimeType: "image/png" });
    const b = await storeImageBytes({ buffer: buf, mimeType: "image/png" });
    writtenPaths.push(a.imagePath);
    expect(a.imagePath).toBe(b.imagePath);
    expect(a.imagePath.startsWith("images/")).toBe(true);
    expect(a.imagePath.endsWith(".png")).toBe(true);
  });

  it("derives extension from the declared mime type", async () => {
    const png = unique("ext-png");
    const jpg = unique("ext-jpg");
    const a = await storeImageBytes({ buffer: png, mimeType: "image/png" });
    const b = await storeImageBytes({ buffer: jpg, mimeType: "image/jpeg" });
    writtenPaths.push(a.imagePath, b.imagePath);
    expect(a.imagePath.endsWith(".png")).toBe(true);
    expect(b.imagePath.endsWith(".jpg")).toBe(true);
  });

  it("read-after-write returns identical bytes", async () => {
    const buf = unique("roundtrip-test");
    const stored = await storeImageBytes({ buffer: buf, mimeType: "image/png" });
    writtenPaths.push(stored.imagePath);
    const readBack = await readStoredImage(stored.imagePath);
    expect(readBack.byteLength).toBe(buf.byteLength);
    // Compare via Buffer.compare (returns 0 when equal).
    expect(Buffer.compare(readBack, buf)).toBe(0);
  });

  it("deleteStoredImage is idempotent (no throw on second call)", async () => {
    const buf = unique("delete-test");
    const stored = await storeImageBytes({ buffer: buf, mimeType: "image/png" });
    await deleteStoredImage(stored.imagePath);
    // Second delete must not throw.
    await expect(deleteStoredImage(stored.imagePath)).resolves.toBeUndefined();
  });

  it("rejects empty buffers with a clear error", async () => {
    await expect(
      storeImageBytes({ buffer: Buffer.alloc(0), mimeType: "image/png" }),
    ).rejects.toThrow(/empty/);
  });

  it("uses .bin extension for unknown mime types", async () => {
    const buf = unique("unknown-mime");
    const stored = await storeImageBytes({ buffer: buf, mimeType: "application/x-weird" });
    writtenPaths.push(stored.imagePath);
    expect(stored.imagePath.endsWith(".bin")).toBe(true);
  });
});
