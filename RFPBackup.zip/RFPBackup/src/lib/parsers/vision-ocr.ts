// Vision-LLM OCR fallback.
//
// The format-specific parsers emit FigureBlocks for scanned PDF pages and
// embedded images, but they do NOT themselves transcribe them. This module
// fills `ocrText` by sending each figure to the org's configured LLM via
// OpenAI's image-content protocol.
//
// Design notes:
//   - No Tesseract / native dependency. The vision model is whatever the
//     org configured for its LLM client. If the org's model doesn't support
//     vision, we surface a `vision_not_supported` warning and bail without
//     crashing.
//   - Concurrency is capped at a small constant. Vision calls are slow
//     and expensive; the goal is graceful degradation, not throughput.
//   - `maxImages` caps the total figures attempted per document. Large
//     scanned PDFs can have hundreds of pages-as-images; without a cap a
//     single ingest could blow through an org's API budget.

import OpenAI from "openai";
import { getAiClients } from "@/lib/ai/client";
import { VISION_OCR_SYSTEM } from "@/lib/ai/prompts";
import { visionOcrCallsTotal } from "@/lib/metrics";
import type { Buffer as NodeBuffer } from "node:buffer";
import type { DocumentAST, FigureBlock, ParseWarning } from "./ast";
import { readStoredImage } from "./image-store";

export interface OcrInput {
  /** Image bytes — PNG or JPEG. */
  imageBuffer: Buffer;
  /** Optional context: surrounding paragraphs from the same doc. */
  contextHint?: string;
  organizationId: string;
}

export interface OcrResult {
  text: string;
  /** 0..1 — model-reported when available; heuristic from word count otherwise. */
  confidence: number;
  ms: number;
}

const DEFAULT_MAX_IMAGES = 12;
const CONCURRENCY = 3;

// Sentinel responses we recognize as "model can't see the image". We keep the
// list small and conservative — we match case-insensitively on a short prefix
// to catch the common variants without misclassifying real transcriptions
// that happen to mention vision.
const VISION_NOT_SUPPORTED_PATTERNS = [
  /^i (am|'m) (?:unable|not able) to (?:see|view|process) (?:images|the image)/i,
  /^i (cannot|can't) (?:see|view|process) images/i,
  /^this model does not support image/i,
  /^image input is not supported/i,
  /^sorry,? i (?:cannot|can't) process images/i,
];

function looksLikeVisionRefusal(text: string): boolean {
  const t = text.trim().slice(0, 200);
  return VISION_NOT_SUPPORTED_PATTERNS.some((re) => re.test(t));
}

function detectMimeFromBuffer(buf: Buffer): "image/png" | "image/jpeg" {
  // PNG magic: 89 50 4E 47. JPEG magic: FF D8 FF. Anything else we default
  // to PNG — OpenAI accepts both and the data-URL only matters for routing.
  if (buf.length >= 4 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) {
    return "image/png";
  }
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    return "image/jpeg";
  }
  return "image/png";
}

/** Heuristic confidence when the model itself doesn't report one. */
function heuristicConfidence(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  const words = trimmed.split(/\s+/).filter(Boolean);
  if (words.length === 0) return 0;
  // Scale: a few characters -> low confidence; 50+ words -> 0.85. Tuned to
  // give a meaningful penalty in the quality scorer when the model spits
  // out only a fragment.
  if (words.length < 3) return 0.3;
  if (words.length < 10) return 0.55;
  if (words.length < 30) return 0.75;
  return 0.85;
}

/**
 * Run the vision-LLM OCR on a single image. Returns empty text + low
 * confidence (and a `vision_not_supported` flag in the caller) when the
 * model refuses. Never throws on a refusal — only on transport errors.
 */
export async function ocrImageWithVisionLLM(input: OcrInput): Promise<OcrResult> {
  const started = Date.now();
  const { llm, config } = await getAiClients(input.organizationId);
  const mime = detectMimeFromBuffer(input.imageBuffer);
  const dataUrl = `data:${mime};base64,${input.imageBuffer.toString("base64")}`;

  const userBlocks: OpenAI.Chat.Completions.ChatCompletionContentPart[] = [
    {
      type: "text",
      text: input.contextHint
        ? `Transcribe this image. Surrounding context for disambiguation only: ${input.contextHint.slice(0, 500)}`
        : "Transcribe this image.",
    },
    { type: "image_url", image_url: { url: dataUrl } },
  ];

  try {
    const completion = await llm.chat.completions.create({
      model: config.llm.model,
      messages: [
        { role: "system", content: VISION_OCR_SYSTEM },
        { role: "user", content: userBlocks },
      ],
      temperature: 0,
    });
    const text = completion.choices?.[0]?.message?.content?.toString() ?? "";
    if (looksLikeVisionRefusal(text)) {
      visionOcrCallsTotal.inc({ org: input.organizationId, result: "vision_not_supported" });
      return { text: "", confidence: 0, ms: Date.now() - started };
    }
    visionOcrCallsTotal.inc({ org: input.organizationId, result: "ok" });
    return {
      text: text.trim(),
      confidence: heuristicConfidence(text),
      ms: Date.now() - started,
    };
  } catch (err) {
    visionOcrCallsTotal.inc({ org: input.organizationId, result: "error" });
    throw err;
  }
}

export interface FillOcrOptions {
  /** Cap on figures attempted per document. Default 12. */
  maxImages?: number;
  /** Optional override of the OCR function — used by tests. */
  ocrFn?: (input: OcrInput) => Promise<OcrResult>;
}

/**
 * Walk the AST, find FigureBlocks without `ocrText`, and populate them via
 * the vision-LLM OCR. Mutates the AST shallowly (returns a new object with
 * the same identity-shape so callers can pipe through). Caps at
 * `maxImages` to bound cost; subsequent figures get a warning instead of
 * a transcription.
 */
export async function fillOcrForFigures(
  ast: DocumentAST,
  organizationId: string,
  opts?: FillOcrOptions,
): Promise<DocumentAST> {
  const maxImages = opts?.maxImages ?? DEFAULT_MAX_IMAGES;
  const ocrFn = opts?.ocrFn ?? ocrImageWithVisionLLM;

  // Identify candidates in document order so the cap drops the trailing
  // figures (more likely to be appendix scans / signature pages) and keeps
  // the earlier, content-bearing ones.
  const candidates: { idx: number; block: FigureBlock; buffer: Buffer }[] = [];
  for (let i = 0; i < ast.blocks.length; i++) {
    const b = ast.blocks[i];
    if (b.kind !== "figure") continue;
    if (b.ocrText && b.ocrText.trim().length > 0) continue;
    const buffer = await imageBufferFor(b);
    if (!buffer) continue;
    candidates.push({ idx: i, block: b, buffer });
  }

  if (candidates.length === 0) {
    return ast;
  }

  const blocks = [...ast.blocks];
  const warnings: ParseWarning[] = [];
  let attempted = 0;
  let succeeded = 0;
  let visionRefused = false;
  const confidences: number[] = [];
  const startedAll = Date.now();

  // Run with bounded concurrency. Splice candidates into a queue and have
  // CONCURRENCY workers pull from it.
  const queue = candidates.slice(0, maxImages);
  const skipped = candidates.length - queue.length;

  if (skipped > 0) {
    warnings.push({
      code: "vision_ocr_capped",
      message: `Skipped ${skipped} figure(s); per-doc OCR cap (${maxImages}) reached.`,
      context: { skipped, cap: maxImages },
    });
  }

  // Build a small async pool. Simple approach: workers pop from a shared
  // index. Avoids a heavy dep.
  let cursor = 0;
  async function worker(): Promise<void> {
    while (true) {
      const myIdx = cursor++;
      if (myIdx >= queue.length) return;
      const entry = queue[myIdx];
      attempted++;
      try {
        const result = await ocrFn({
          imageBuffer: entry.buffer,
          contextHint: surroundingContextFor(ast, entry.idx),
          organizationId,
        });
        if (result.text.length > 0) {
          succeeded++;
          confidences.push(result.confidence);
          // Block is referenced by index — write back into our local copy.
          blocks[entry.idx] = { ...entry.block, ocrText: result.text };
        } else {
          // Empty result -> either "no text in image" or refusal. We
          // can't disambiguate without the metric, but we set a low
          // confidence so the scorer can see the doc is OCR-degraded.
          confidences.push(0);
          if (!visionRefused) visionRefused = true;
        }
      } catch (err) {
        warnings.push({
          code: "vision_ocr_error",
          message: `Vision OCR failed for figure ${entry.block.anchor}: ${
            err instanceof Error ? err.message : String(err)
          }`,
          context: { anchor: entry.block.anchor },
        });
      }
    }
  }

  await Promise.all(
    Array.from({ length: Math.min(CONCURRENCY, queue.length) }, () => worker()),
  );

  if (visionRefused && succeeded === 0) {
    warnings.push({
      code: "vision_not_supported",
      message:
        "Vision-LLM OCR produced no transcribable output; the configured model may not support image inputs.",
      context: { attempted },
    });
  }

  const ocrConfidence =
    confidences.length > 0 ? confidences.reduce((a, b) => a + b, 0) / confidences.length : undefined;

  return {
    ...ast,
    blocks,
    report: {
      ...ast.report,
      ocrUsed: ast.report.ocrUsed || attempted > 0,
      ocrConfidence: ocrConfidence ?? ast.report.ocrConfidence,
      ocrMs: (ast.report.ocrMs ?? 0) + (Date.now() - startedAll),
      warnings: [...ast.report.warnings, ...warnings],
    },
  };
}

function surroundingContextFor(ast: DocumentAST, idx: number): string {
  // Pull text from up to 2 paragraphs above and 1 below the figure.
  const parts: string[] = [];
  for (let i = Math.max(0, idx - 2); i < idx; i++) {
    const b = ast.blocks[i];
    if (b.kind === "paragraph") parts.push(b.text);
    else if (b.kind === "heading") parts.push(b.text);
  }
  for (let i = idx + 1; i < Math.min(ast.blocks.length, idx + 2); i++) {
    const b = ast.blocks[i];
    if (b.kind === "paragraph") parts.push(b.text);
  }
  return parts.join(" ").slice(0, 800);
}

async function imageBufferFor(block: FigureBlock): Promise<Buffer | null> {
  // Prefer the in-memory buffer when the parser carried one through. The
  // pipeline's image-processing step normally clears this in favour of
  // imageRef, but tests and tightly-coupled callers may invoke OCR before
  // that runs — supporting both keeps the contract flexible.
  if (block.imageBuffer && block.imageBuffer.byteLength > 0) {
    return block.imageBuffer;
  }
  // The AST stores an `imageRef` which may be a data: URL, a stored-image
  // path under uploads/, or a remote URL. We resolve data: URLs and
  // images/<sha256>.<ext> paths (placed there by the image-store helper)
  // here. Remote URLs need an HTTP fetch and a fetch-allowlist policy that
  // is outside the scope of post-processing.
  const ref = block.imageRef;
  if (!ref) return null;
  if (ref.startsWith("data:")) {
    const commaIdx = ref.indexOf(",");
    if (commaIdx < 0) return null;
    const b64 = ref.slice(commaIdx + 1);
    try {
      return Buffer.from(b64, "base64") as unknown as NodeBuffer as Buffer;
    } catch {
      return null;
    }
  }
  if (ref.startsWith("images/")) {
    try {
      return await readStoredImage(ref);
    } catch {
      return null;
    }
  }
  // P1 parsers may set imageRef to a temp filesystem path or remote URL.
  // We don't read those here.
  return null;
}
