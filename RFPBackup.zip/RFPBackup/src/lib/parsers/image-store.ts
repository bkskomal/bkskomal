// Content-addressed image storage on the local filesystem.
//
// Images extracted by parsers (HTML <img>, DOCX inline images, PDF embedded
// images) are written to `uploads/images/<sha256>.<ext>`. The hash-as-filename
// scheme deduplicates identical images automatically: the same byte sequence
// always produces the same path, so re-uploading a doc with the same logo
// won't multiply storage.
//
// Width/height detection is best-effort and uses `sharp` only when present.
// We deliberately avoid adding a new image-decoding dep here — most callers
// don't need dimensions, and the ImageEmbedding row tolerates nulls.

import { createHash } from "node:crypto";
import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";

export interface StoredImage {
  /** Path relative to uploads/, e.g. "images/<sha256>.png". */
  imagePath: string;
  /** Resolved absolute path on disk. */
  absolutePath: string;
  mimeType: string;
  bytes: number;
  width?: number;
  height?: number;
}

const UPLOADS_ROOT = resolve(process.cwd(), "uploads");
const IMAGES_DIR = join(UPLOADS_ROOT, "images");

// MIME → extension. Limited to the formats we expect from parsers; unknown
// MIMEs fall through to ".bin" so the file is still saved (callers can still
// retrieve and re-encode).
const EXT_FOR_MIME: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/bmp": "bmp",
  "image/svg+xml": "svg",
  "image/tiff": "tiff",
  "image/avif": "avif",
};

function extForMime(mimeType: string): string {
  const norm = (mimeType || "").toLowerCase().split(";")[0].trim();
  return EXT_FOR_MIME[norm] ?? "bin";
}

async function ensureImagesDir(): Promise<void> {
  await mkdir(IMAGES_DIR, { recursive: true });
}

function hashBytes(buffer: Buffer): string {
  return createHash("sha256").update(buffer).digest("hex").slice(0, 32);
}

/** Resolve an `images/<hash>.<ext>` relative path to an absolute disk path. */
function absoluteFor(imagePath: string): string {
  // Reject parent-dir traversal — paths must live under uploads/.
  const safe = imagePath.replace(/\\/g, "/").replace(/^\/+/, "");
  if (safe.includes("..")) {
    throw new Error(`Refusing image path containing '..': ${imagePath}`);
  }
  return resolve(UPLOADS_ROOT, safe);
}

/**
 * Read width/height via sharp when the package is installed. The dep is
 * optional — we never throw if sharp isn't available, we just leave the
 * dimensions undefined.
 */
async function tryReadDimensions(
  buffer: Buffer,
): Promise<{ width?: number; height?: number }> {
  try {
    // Dynamic import keeps sharp out of the eager require graph; .catch keeps
    // the build resilient if sharp isn't installed in some environment.
    const mod = (await import("sharp").catch(() => null)) as
      | { default: (input: Buffer) => { metadata: () => Promise<{ width?: number; height?: number }> } }
      | null;
    if (!mod || typeof mod.default !== "function") return {};
    const meta = await mod.default(buffer).metadata();
    return { width: meta.width, height: meta.height };
  } catch {
    return {};
  }
}

/**
 * Write image bytes to the content-addressed store. Idempotent: writing the
 * same bytes twice produces the same path and the same on-disk file.
 */
export async function storeImageBytes(opts: {
  buffer: Buffer;
  mimeType: string;
}): Promise<StoredImage> {
  const { buffer, mimeType } = opts;
  if (!buffer || buffer.byteLength === 0) {
    throw new Error("storeImageBytes: buffer is empty");
  }
  await ensureImagesDir();
  const hash = hashBytes(buffer);
  const ext = extForMime(mimeType);
  const filename = `${hash}.${ext}`;
  const imagePath = `images/${filename}`;
  const absolutePath = absoluteFor(imagePath);
  // Write idempotently. We could check existence first but writeFile is
  // overwrite-safe and the bytes will be identical anyway.
  await writeFile(absolutePath, buffer);
  const dims = await tryReadDimensions(buffer);
  return {
    imagePath,
    absolutePath,
    mimeType,
    bytes: buffer.byteLength,
    width: dims.width,
    height: dims.height,
  };
}

/** Read an image previously stored by storeImageBytes. */
export async function readStoredImage(imagePath: string): Promise<Buffer> {
  return readFile(absoluteFor(imagePath));
}

/** Delete an image. No-op if the file is already gone. */
export async function deleteStoredImage(imagePath: string): Promise<void> {
  try {
    await unlink(absoluteFor(imagePath));
  } catch (e) {
    // ENOENT = already deleted; idempotent contract.
    if ((e as NodeJS.ErrnoException).code === "ENOENT") return;
    throw e;
  }
}
