import { describe, it, expect, vi } from "vitest";
import * as XLSX from "xlsx";
import { detectFormat, parseDocument, PARSER_PIPELINE_VERSION } from "./parse";

// Stub out pdfjs to avoid loading the heavy module — we never trigger a real
// PDF parse in this file; we only exercise format detection on the buffer.
vi.mock("pdfjs-dist/legacy/build/pdf.mjs", () => ({
  GlobalWorkerOptions: { workerSrc: "" },
  getDocument: () => ({
    promise: Promise.resolve({
      numPages: 0,
      getMetadata: () => Promise.resolve({ info: {} }),
      getPage: () => Promise.reject(new Error("unused in test")),
      destroy: () => Promise.resolve(),
    }),
  }),
}));

const buf = (s: string) => Buffer.from(s, "utf8");

describe("PARSER_PIPELINE_VERSION", () => {
  it("is the p1 constant", () => {
    expect(PARSER_PIPELINE_VERSION).toMatch(/^p1-/);
  });
});

describe("detectFormat — magic bytes", () => {
  it("detects PDF by %PDF magic", () => {
    expect(detectFormat(Buffer.from("%PDF-1.4\n"), "", "x.bin")).toBe("pdf");
  });

  it("detects DOCX by ZIP magic + word/ peek", () => {
    // Build a real XLSX file's first chunk to verify we route to xlsx.
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.aoa_to_sheet([["a", "b"], [1, 2]]),
      "S",
    );
    const xlsxBuf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
    expect(detectFormat(xlsxBuf, "", "x.bin")).toBe("xlsx");
  });

  it("detects HTML by <!DOCTYPE / <html sniff", () => {
    expect(detectFormat(buf("<!DOCTYPE html>\n<html></html>"), "", "x.bin")).toBe("html");
    expect(detectFormat(buf("<html><body>x</body></html>"), "", "x.bin")).toBe("html");
  });

  it("falls back to MIME when magic bytes don't match", () => {
    expect(detectFormat(buf("just text"), "text/markdown", "")).toBe("md");
    expect(detectFormat(buf("just text"), "text/plain", "")).toBe("txt");
    expect(detectFormat(buf("just text"), "application/pdf", "")).toBe("pdf");
  });

  it("falls back to filename extension as last resort", () => {
    expect(detectFormat(buf("anything"), "", "doc.html")).toBe("html");
    expect(detectFormat(buf("anything"), "", "doc.md")).toBe("md");
    expect(detectFormat(buf("anything"), "", "doc.pdf")).toBe("pdf");
    expect(detectFormat(buf("anything"), "", "doc.docx")).toBe("docx");
    expect(detectFormat(buf("anything"), "", "doc.xlsx")).toBe("xlsx");
  });

  it("defaults to txt when nothing matches", () => {
    expect(detectFormat(buf("random"), "", "noext")).toBe("txt");
  });
});

describe("parseDocument facade", () => {
  it("dispatches HTML by magic bytes", async () => {
    const { ast } = await parseDocument(
      buf("<html><body><h1>Hi</h1><p>x</p></body></html>"),
      "",
      "org-1",
      "page.html",
    );
    expect(ast.metadata.parser).toBe("html");
    expect(ast.blocks.some((b) => b.kind === "heading")).toBe(true);
  });

  it("dispatches Markdown by MIME", async () => {
    const { text, ast } = await parseDocument(
      buf("# H\n\npara\n"),
      "text/markdown",
      "org-1",
      "x.md",
    );
    expect(ast.metadata.parser).toBe("md");
    expect(text).toContain("# H");
  });

  it("dispatches plain text", async () => {
    const { ast } = await parseDocument(
      buf("Plain text paragraph one.\n\nParagraph two."),
      "text/plain",
      "org-1",
      "x.txt",
    );
    expect(ast.metadata.parser).toBe("txt");
    expect(ast.blocks.filter((b) => b.kind === "paragraph")).toHaveLength(2);
  });

  it("dispatches XLSX", async () => {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.aoa_to_sheet([
        ["A", "B"],
        ["1", "2"],
      ]),
      "Sheet1",
    );
    const xlsxBuf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
    const { ast } = await parseDocument(xlsxBuf, "", "org-1", "x.xlsx");
    expect(ast.metadata.parser).toBe("xlsx");
  });

  it("returns rendered Markdown as `text`", async () => {
    const { text } = await parseDocument(
      buf("# Title\n\nBody."),
      "text/markdown",
      "org-1",
      "x.md",
    );
    expect(text).toContain("# Title");
    expect(text).toContain("Body.");
  });

  it("error in one parser does not crash other parses", async () => {
    // First call: HTML that's malformed enough Readability may struggle,
    // but the facade should still return an AST (not throw).
    const r1 = await parseDocument(buf("<<<not html>>>"), "text/html", "o", "x.html");
    expect(r1.ast).toBeDefined();
    // Subsequent calls work fine.
    const r2 = await parseDocument(buf("# OK"), "text/markdown", "o", "x.md");
    expect(r2.ast.metadata.parser).toBe("md");
  });
});
