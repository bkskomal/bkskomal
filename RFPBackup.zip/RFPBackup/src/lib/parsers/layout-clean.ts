// Post-parse layout cleanup. Operates on the AST produced by format-specific
// parsers (PDF, DOCX, HTML, ...) and strips artefacts the parsers themselves
// could not confidently remove:
//
//   - Repeating running headers / footers that appear on > 50% of pages in
//     the top/bottom 8% region. PDF parser already does some of this with
//     bbox heuristics; this catches the leftovers and applies the same logic
//     to DOCX page-emulated content.
//   - Standalone page-number paragraphs ("Page 3 of 12", "12").
//   - Adjacent duplicate paragraphs (a common DOCX export artefact).
//
// Cleaning is purely additive: we never invent blocks. Every drop is logged
// to `report.warnings` so the quality scorer (and any human reviewer) can
// see what was suppressed.

import type {
  Block,
  DocumentAST,
  ParagraphBlock,
  ParseWarning,
} from "./ast";

export interface LayoutCleanOptions {
  /** Trim trailing whitespace-only paragraphs at page boundaries. */
  stripEmpty?: boolean;
  /** Drop blocks that look like running headers/footers. */
  stripHeaderFooter?: boolean;
  /** Drop blocks that are clearly page numbers ("Page 3 of 12"). */
  stripPageNumbers?: boolean;
}

const DEFAULT_OPTS: Required<LayoutCleanOptions> = {
  stripEmpty: true,
  stripHeaderFooter: true,
  stripPageNumbers: true,
};

// Two regex flavours. The "page number with words" form requires the whole
// paragraph to be a page-ish marker. The bare-number form is stricter: only
// fires on a *short* paragraph that is just digits so we don't strip a
// real numbered heading.
const PAGE_NUMBER_TEXT = /^Page\s+\d+(\s+of\s+\d+)?$/i;
const BARE_PAGE_NUMBER = /^\d{1,4}$/;

/**
 * Run the post-parse cleaner. Returns a new AST with surviving blocks
 * (the input is not mutated) and a report with cleanup warnings appended.
 */
export function cleanLayout(ast: DocumentAST, opts?: LayoutCleanOptions): DocumentAST {
  const o = { ...DEFAULT_OPTS, ...(opts ?? {}) };
  const blocks = ast.blocks;
  const warnings: ParseWarning[] = [];

  // --- pass 1: identify repeating header/footer text ---
  // Heuristic: group ParagraphBlocks by their page (when known). For each
  // page, mark the first paragraph as a header-candidate and the last as a
  // footer-candidate. If the same exact text shows up as a top or bottom
  // candidate on > 50% of pages, every instance is dropped.
  const repeatingHeaders = new Set<string>();
  const repeatingFooters = new Set<string>();

  if (o.stripHeaderFooter) {
    const byPage = groupParagraphsByPage(blocks);
    const totalPages = byPage.size;
    if (totalPages >= 4) {
      const headerCounts = new Map<string, number>();
      const footerCounts = new Map<string, number>();
      for (const list of byPage.values()) {
        if (list.length === 0) continue;
        const head = normalizeHeaderFooter(list[0].text);
        const foot = normalizeHeaderFooter(list[list.length - 1].text);
        if (head) headerCounts.set(head, (headerCounts.get(head) ?? 0) + 1);
        if (foot) footerCounts.set(foot, (footerCounts.get(foot) ?? 0) + 1);
      }
      const threshold = Math.ceil(totalPages * 0.5);
      for (const [k, c] of headerCounts) {
        if (c >= threshold) repeatingHeaders.add(k);
      }
      for (const [k, c] of footerCounts) {
        if (c >= threshold) repeatingFooters.add(k);
      }
    }
  }

  // --- pass 2: filter ---
  const kept: Block[] = [];
  let lastParagraphText: string | null = null;
  let droppedHeaderFooter = 0;
  let droppedPageNumbers = 0;
  let droppedEmpty = 0;
  let droppedDuplicates = 0;

  for (const block of blocks) {
    if (block.kind === "paragraph") {
      const t = block.text.trim();

      if (o.stripEmpty && t.length === 0) {
        droppedEmpty++;
        continue;
      }

      if (o.stripPageNumbers && isPageNumber(t)) {
        droppedPageNumbers++;
        continue;
      }

      if (
        o.stripHeaderFooter &&
        (repeatingHeaders.has(normalizeHeaderFooter(block.text)) ||
          repeatingFooters.has(normalizeHeaderFooter(block.text)))
      ) {
        droppedHeaderFooter++;
        continue;
      }

      if (lastParagraphText !== null && t === lastParagraphText) {
        droppedDuplicates++;
        continue;
      }
      lastParagraphText = t;
      kept.push(block);
      continue;
    }
    // Non-paragraph blocks reset the duplicate-paragraph tracker — a heading
    // or a table separating two identical paragraphs is meaningful and we
    // should keep both copies.
    lastParagraphText = null;
    kept.push(block);
  }

  if (droppedHeaderFooter > 0) {
    warnings.push({
      code: "layout_clean_header_footer_stripped",
      message: `Removed ${droppedHeaderFooter} repeating header/footer paragraph(s).`,
      context: { count: droppedHeaderFooter },
    });
  }
  if (droppedPageNumbers > 0) {
    warnings.push({
      code: "layout_clean_page_numbers_stripped",
      message: `Removed ${droppedPageNumbers} standalone page-number paragraph(s).`,
      context: { count: droppedPageNumbers },
    });
  }
  if (droppedEmpty > 0) {
    warnings.push({
      code: "layout_clean_empty_stripped",
      message: `Removed ${droppedEmpty} empty paragraph(s).`,
      context: { count: droppedEmpty },
    });
  }
  if (droppedDuplicates > 0) {
    warnings.push({
      code: "layout_clean_duplicates_stripped",
      message: `Removed ${droppedDuplicates} adjacent duplicate paragraph(s).`,
      context: { count: droppedDuplicates },
    });
  }

  return {
    ...ast,
    blocks: kept,
    report: {
      ...ast.report,
      blockCount: kept.length,
      warnings: [...ast.report.warnings, ...warnings],
    },
  };
}

function groupParagraphsByPage(blocks: Block[]): Map<number, ParagraphBlock[]> {
  const out = new Map<number, ParagraphBlock[]>();
  for (const b of blocks) {
    if (b.kind !== "paragraph") continue;
    const page = b.page ?? -1;
    let list = out.get(page);
    if (!list) {
      list = [];
      out.set(page, list);
    }
    list.push(b);
  }
  return out;
}

function normalizeHeaderFooter(text: string): string {
  // Collapse whitespace and lower-case so "Confidential | Page 3 of 12" and
  // "Confidential | Page 4 of 12" match when the page-number portion is
  // stripped. We also remove any "Page N of M" suffix and standalone page
  // numbers so the same template fires across pages.
  const noPage = text
    .replace(/Page\s+\d+(\s+of\s+\d+)?/gi, "")
    .replace(/\b\d{1,4}\b/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
  return noPage;
}

function isPageNumber(text: string): boolean {
  if (PAGE_NUMBER_TEXT.test(text)) return true;
  if (BARE_PAGE_NUMBER.test(text)) return true;
  return false;
}
