import { describe, expect, it } from "vitest";
import * as XLSX from "xlsx";
import {
  emitMatrixXlsx,
  parseMatrixXlsx,
  type PricingMatrix,
} from "./pricing-matrix";

function buildWorkbook(
  sheets: Record<string, unknown[][]>,
  sheetOrder: string[],
): Buffer {
  const wb = XLSX.utils.book_new();
  for (const name of sheetOrder) {
    const aoa = sheets[name] ?? [];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    XLSX.utils.book_append_sheet(wb, ws, name);
  }
  return Buffer.from(
    XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as ArrayBuffer,
  );
}

describe("parseMatrixXlsx", () => {
  it("parses a basic grid into headers + rows", async () => {
    const buf = buildWorkbook(
      {
        Sheet1: [
          ["Item", "Tier 1", "Tier 2"],
          ["License", "$100", "$200"],
          ["Support", "$50", "$75"],
        ],
      },
      ["Sheet1"],
    );
    const m = await parseMatrixXlsx(buf);
    expect(m.headers).toEqual(["Item", "Tier 1", "Tier 2"]);
    expect(m.rows).toHaveLength(2);
    expect(m.rows[0]).toEqual({
      label: "License",
      cells: [{ value: "$100" }, { value: "$200" }],
    });
    expect(m.rows[1]).toEqual({
      label: "Support",
      cells: [{ value: "$50" }, { value: "$75" }],
    });
  });

  it("treats the first NON-EMPTY sheet as the matrix (skips blank sheets)", async () => {
    const buf = buildWorkbook(
      {
        // Empty leading sheet (no data) — must be skipped.
        Cover: [],
        Pricing: [
          ["SKU", "Annual"],
          ["alpha", "$1,200"],
        ],
      },
      ["Cover", "Pricing"],
    );
    const m = await parseMatrixXlsx(buf);
    expect(m.headers).toEqual(["SKU", "Annual"]);
    expect(m.rows).toEqual([
      { label: "alpha", cells: [{ value: "$1,200" }] },
    ]);
  });

  it("treats the first non-empty row of the sheet as the headers", async () => {
    // Two leading blank rows (often left by RFP authors who reserved title
    // space). The parser should walk past them and pick row 3 as headers.
    const buf = buildWorkbook(
      {
        Sheet1: [
          ["", "", ""],
          ["", "", ""],
          ["Item", "Tier A", "Tier B"],
          ["X", "1", "2"],
        ],
      },
      ["Sheet1"],
    );
    const m = await parseMatrixXlsx(buf);
    expect(m.headers).toEqual(["Item", "Tier A", "Tier B"]);
    expect(m.rows).toEqual([
      { label: "X", cells: [{ value: "1" }, { value: "2" }] },
    ]);
  });

  it("drops trailing blank rows", async () => {
    const buf = buildWorkbook(
      {
        Sheet1: [
          ["Item", "Price"],
          ["A", "$1"],
          ["B", "$2"],
          ["", ""],
          ["", ""],
        ],
      },
      ["Sheet1"],
    );
    const m = await parseMatrixXlsx(buf);
    expect(m.rows.map((r) => r.label)).toEqual(["A", "B"]);
  });

  it("drops trailing blank columns", async () => {
    const buf = buildWorkbook(
      {
        Sheet1: [
          ["Item", "Price", "", ""],
          ["A", "$1", "", ""],
        ],
      },
      ["Sheet1"],
    );
    const m = await parseMatrixXlsx(buf);
    expect(m.headers).toEqual(["Item", "Price"]);
    expect(m.rows[0]?.cells).toEqual([{ value: "$1" }]);
  });

  it("round-trips parse → emit → re-parse to an identical matrix", async () => {
    const buf = buildWorkbook(
      {
        Sheet1: [
          ["Item", "Tier 1", "Tier 2"],
          ["License", "$100", "$200"],
          ["Support", "$50", "$75"],
        ],
      },
      ["Sheet1"],
    );
    const first = await parseMatrixXlsx(buf);
    const out = emitMatrixXlsx(first);
    const reparsed = await parseMatrixXlsx(out);
    expect(reparsed).toEqual(first);
  });

  it("returns an empty matrix when the workbook has no data at all", async () => {
    const buf = buildWorkbook({ Sheet1: [] }, ["Sheet1"]);
    const m = await parseMatrixXlsx(buf);
    expect(m).toEqual({ headers: [], rows: [] });
  });
});

describe("emitMatrixXlsx", () => {
  it("writes `value` when set, otherwise falls back to `generated`", async () => {
    const m: PricingMatrix = {
      headers: ["Item", "Tier 1", "Tier 2"],
      rows: [
        {
          label: "Row 1",
          cells: [
            { value: "$100" },
            { generated: "$200", confidence: 0.9 },
          ],
        },
        {
          label: "Row 2",
          cells: [{}, { generated: "NEEDS INFO", confidence: 0 }],
        },
      ],
    };
    const buf = emitMatrixXlsx(m);
    const reparsed = await parseMatrixXlsx(buf);
    expect(reparsed.headers).toEqual(["Item", "Tier 1", "Tier 2"]);
    expect(reparsed.rows[0]).toEqual({
      label: "Row 1",
      cells: [{ value: "$100" }, { value: "$200" }],
    });
    // The empty cell stays empty on round-trip.
    expect(reparsed.rows[1]).toEqual({
      label: "Row 2",
      cells: [{}, { value: "NEEDS INFO" }],
    });
  });
});
