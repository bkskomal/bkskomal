import { describe, expect, it } from "vitest";
import { semanticChunk } from "./chunker";
import { anchorFor } from "./ast";
import type {
  CodeBlock,
  DocumentAST,
  HeadingBlock,
  ListBlock,
  ParagraphBlock,
  TableBlock,
} from "./ast";

let anchorCtr = 0;
function nextAnchor(): string {
  return `anc${++anchorCtr}`;
}

function heading(level: number, text: string, page?: number): HeadingBlock {
  return { kind: "heading", level, text, anchor: nextAnchor(), page };
}

function paragraph(text: string, page?: number): ParagraphBlock {
  return { kind: "paragraph", text, anchor: nextAnchor(), page };
}

function list(items: string[], ordered = false): ListBlock {
  return {
    kind: "list",
    ordered,
    items: items.map((t) => ({ text: t })),
    anchor: nextAnchor(),
  };
}

function tableBlock(headers: string[], rows: string[][]): TableBlock {
  const md = [
    `| ${headers.join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((r) => `| ${r.join(" | ")} |`),
  ].join("\n");
  return { kind: "table", headers, rows, markdown: md, anchor: nextAnchor() };
}

function code(c: string, lang = "ts"): CodeBlock {
  return { kind: "code", code: c, language: lang, anchor: nextAnchor() };
}

function emptyReport() {
  return {
    parser: "html" as const,
    parserVersion: "1.0",
    blockCount: 0,
    tableCount: 0,
    listCount: 0,
    figureCount: 0,
    ocrUsed: false,
    parseMs: 1,
    warnings: [],
    errors: [],
  };
}

function ast(blocks: DocumentAST["blocks"]): DocumentAST {
  return {
    metadata: { parser: "html", parserVersion: "1.0" },
    blocks,
    report: { ...emptyReport(), blockCount: blocks.length },
  };
}

describe("semanticChunk", () => {
  it("starts a new chunk on every heading", () => {
    const chunks = semanticChunk(
      ast([
        heading(1, "Intro"),
        paragraph("Intro body."),
        heading(1, "Architecture"),
        paragraph("Arch body."),
      ]),
    );
    expect(chunks.length).toBeGreaterThanOrEqual(4);
    expect(chunks[0].kind).toBe("heading");
    expect(chunks[0].content).toContain("Intro");
  });

  it("puts a table in its own chunk and never splits a small one", () => {
    const chunks = semanticChunk(
      ast([
        paragraph("Before table."),
        tableBlock(["A", "B"], [["1", "2"]]),
        paragraph("After table."),
      ]),
    );
    const tableChunks = chunks.filter((c) => c.kind === "table");
    expect(tableChunks).toHaveLength(1);
    expect(tableChunks[0].content).toContain("| A | B |");
  });

  it("splits an oversized table by rows preserving the header", () => {
    const rows = Array.from({ length: 100 }, (_, i) => [
      `row${i}`,
      "x".repeat(60),
    ]);
    const chunks = semanticChunk(ast([tableBlock(["A", "B"], rows)]), {
      maxSize: 500,
    });
    const tableChunks = chunks.filter((c) => c.kind === "table");
    expect(tableChunks.length).toBeGreaterThan(1);
    for (const c of tableChunks) {
      expect(c.content).toContain("| A | B |");
    }
  });

  it("groups list items and never splits mid-item", () => {
    const items = ["First item", "Second item", "Third item"];
    const chunks = semanticChunk(ast([list(items)]));
    const listChunk = chunks.find((c) => c.kind === "list")!;
    expect(listChunk.content).toContain("First item");
    expect(listChunk.content).toContain("Second item");
    expect(listChunk.content).toContain("Third item");
  });

  it("puts code blocks in their own chunk", () => {
    const chunks = semanticChunk(
      ast([paragraph("Before"), code("const x = 1;"), paragraph("After")]),
    );
    const codeChunks = chunks.filter((c) => c.kind === "code");
    expect(codeChunks).toHaveLength(1);
    expect(codeChunks[0].content).toContain("const x = 1;");
  });

  it("splits oversized paragraphs at sentence boundaries with overlap", () => {
    // 10 sentences of ~50 chars => 500 chars total. Force splits at 200.
    const longPara = Array.from({ length: 10 }, (_, i) =>
      `Sentence number ${i} fills up a fixed-length window.`,
    ).join(" ");
    const chunks = semanticChunk(ast([paragraph(longPara)]), {
      maxSize: 200,
      targetSize: 200,
      overlap: 30,
      minSize: 50,
    });
    const paraChunks = chunks.filter((c) => c.kind === "paragraph");
    expect(paraChunks.length).toBeGreaterThan(1);
    // Every fragment should end with sentence-terminator (or at least not
    // chop a word in half at the start).
    for (const c of paraChunks) {
      expect(c.content.trim().length).toBeGreaterThan(0);
    }
  });

  it("tracks the section path through nested headings", () => {
    const chunks = semanticChunk(
      ast([
        heading(1, "Security"),
        heading(2, "Encryption"),
        paragraph("AES-256 at rest."),
        heading(2, "Auditing"),
        paragraph("All access logged."),
        heading(1, "Operations"),
        paragraph("On-call rotation."),
      ]),
    );
    const aes = chunks.find((c) => c.content.includes("AES-256"))!;
    expect(aes.section).toBe("Security / Encryption");
    const audit = chunks.find((c) => c.content.includes("All access logged"))!;
    expect(audit.section).toBe("Security / Auditing");
    const ops = chunks.find((c) => c.content.includes("On-call rotation"))!;
    expect(ops.section).toBe("Operations");
  });

  it("emits stable anchors across runs (anchor stability)", () => {
    // Anchors derive from the source block's anchor — so identical input
    // ASTs (same block.anchor values) must produce identical chunk anchors
    // across runs. We pin the anchors on the input to avoid the random ID
    // helper used elsewhere in this test file.
    const buildAst = () =>
      ast([
        { kind: "heading" as const, level: 1, text: "Intro", anchor: "h-stable", page: 1 },
        { kind: "paragraph" as const, text: "Body of intro.", anchor: "p-stable", page: 1 },
      ]);
    const a = semanticChunk(buildAst());
    const b = semanticChunk(buildAst());
    expect(a.map((c) => c.anchor)).toEqual(b.map((c) => c.anchor));
  });

  it("derives anchor of paragraph chunk from its first block anchor", () => {
    anchorCtr = 0;
    const para = paragraph("Hello world.");
    para.anchor = "para-anchor-1";
    const chunks = semanticChunk(ast([para]));
    expect(chunks).toHaveLength(1);
    expect(chunks[0].anchor).toBe("para-anchor-1");
  });

  it("falls back to computed anchor when block has no anchor set", () => {
    // Construct a block with empty anchor; chunker should compute one from
    // section + ordinal via anchorFor.
    const blocks = [
      { kind: "paragraph", text: "Body", anchor: "" } as ParagraphBlock,
    ];
    const chunks = semanticChunk({
      metadata: { parser: "html", parserVersion: "1.0" },
      blocks,
      report: { ...emptyReport(), blockCount: 1 },
    });
    expect(chunks).toHaveLength(1);
    // The pending chunk has anchor = "" so flush() falls back to anchorFor.
    expect(chunks[0].anchor).toBe(anchorFor(undefined, 0));
  });
});
