import { describe, expect, it } from "vitest";
import { fillOcrForFigures } from "./vision-ocr";
import type { DocumentAST, FigureBlock } from "./ast";

function tinyPngBase64(): string {
  // 1x1 transparent PNG, base64 — minimal valid PNG.
  return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
}

function figureBlock(i: number): FigureBlock {
  return {
    kind: "figure",
    anchor: `fig${i}`,
    imageRef: `data:image/png;base64,${tinyPngBase64()}`,
  };
}

function emptyReport() {
  return {
    parser: "pdf" as const,
    parserVersion: "1.0",
    blockCount: 0,
    tableCount: 0,
    listCount: 0,
    figureCount: 0,
    ocrUsed: false,
    parseMs: 1,
    warnings: [],
    errors: [],
  };
}

function ast(blocks: DocumentAST["blocks"]): DocumentAST {
  return {
    metadata: { parser: "pdf", parserVersion: "1.0" },
    blocks,
    report: { ...emptyReport(), blockCount: blocks.length, figureCount: blocks.filter((b) => b.kind === "figure").length },
  };
}

describe("fillOcrForFigures", () => {
  it("populates ocrText and confidence on figures via mocked OCR", async () => {
    const before = ast([figureBlock(1), figureBlock(2)]);
    const result = await fillOcrForFigures(before, "org-1", {
      ocrFn: async () => ({ text: "transcribed text from image with several words", confidence: 0.8, ms: 10 }),
    });
    const figures = result.blocks.filter((b) => b.kind === "figure") as FigureBlock[];
    expect(figures).toHaveLength(2);
    for (const f of figures) {
      expect(f.ocrText).toBe("transcribed text from image with several words");
    }
    expect(result.report.ocrUsed).toBe(true);
    expect(result.report.ocrConfidence).toBeCloseTo(0.8, 5);
  });

  it("emits a vision_not_supported warning when the model returns empty for all figures", async () => {
    const before = ast([figureBlock(1)]);
    const result = await fillOcrForFigures(before, "org-1", {
      ocrFn: async () => ({ text: "", confidence: 0, ms: 5 }),
    });
    expect(
      result.report.warnings.some((w) => w.code === "vision_not_supported"),
    ).toBe(true);
  });

  it("honours the maxImages cap", async () => {
    const figures = Array.from({ length: 8 }, (_, i) => figureBlock(i));
    const before = ast(figures);
    let calls = 0;
    const result = await fillOcrForFigures(before, "org-1", {
      maxImages: 3,
      ocrFn: async () => {
        calls++;
        return { text: "transcribed many words to count over here", confidence: 0.75, ms: 5 };
      },
    });
    expect(calls).toBe(3);
    const populated = (result.blocks.filter((b) => b.kind === "figure") as FigureBlock[]).filter(
      (f) => f.ocrText,
    );
    expect(populated).toHaveLength(3);
    expect(
      result.report.warnings.some((w) => w.code === "vision_ocr_capped"),
    ).toBe(true);
  });

  it("skips figures that already have ocrText", async () => {
    const figs: FigureBlock[] = [
      { ...figureBlock(1), ocrText: "already transcribed" },
      figureBlock(2),
    ];
    let calls = 0;
    const result = await fillOcrForFigures(ast(figs), "org-1", {
      ocrFn: async () => {
        calls++;
        return { text: "new text from ocr", confidence: 0.6, ms: 5 };
      },
    });
    expect(calls).toBe(1);
    const figures = result.blocks.filter((b) => b.kind === "figure") as FigureBlock[];
    expect(figures[0].ocrText).toBe("already transcribed");
    expect(figures[1].ocrText).toBe("new text from ocr");
  });

  it("returns the AST unchanged when there are no figures needing OCR", async () => {
    const before = ast([]);
    const result = await fillOcrForFigures(before, "org-1", {
      ocrFn: async () => ({ text: "x", confidence: 1, ms: 0 }),
    });
    expect(result).toEqual(before);
  });
});
