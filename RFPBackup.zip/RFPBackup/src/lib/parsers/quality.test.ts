import { describe, expect, it } from "vitest";
import { scoreParseQuality } from "./quality";
import type { DocumentAST } from "./ast";

function emptyReport(overrides: Partial<DocumentAST["report"]> = {}): DocumentAST["report"] {
  return {
    parser: "html",
    parserVersion: "1.0",
    blockCount: 0,
    tableCount: 0,
    listCount: 0,
    figureCount: 0,
    ocrUsed: false,
    parseMs: 1,
    warnings: [],
    errors: [],
    ...overrides,
  };
}

function ast(blocks: DocumentAST["blocks"], reportOverrides: Partial<DocumentAST["report"]> = {}): DocumentAST {
  return {
    metadata: { parser: "html", parserVersion: "1.0" },
    blocks,
    report: emptyReport({ ...reportOverrides, blockCount: blocks.length }),
  };
}

describe("scoreParseQuality", () => {
  it("returns a low score for an all-paragraph degenerate doc", () => {
    const result = scoreParseQuality(
      ast([{ kind: "paragraph", text: "everything in one block", anchor: "a1" }]),
    );
    // has_blocks (+0.2) + no_warnings (+0.1) - single_paragraph_doc (-0.1) = 0.2
    expect(result.score).toBeCloseTo(0.2, 5);
    expect(result.reasons.some((r) => r.code === "single_paragraph_doc")).toBe(true);
  });

  it("returns a high score for a rich doc with headings, tables, lists", () => {
    const result = scoreParseQuality(
      ast([
        { kind: "heading", level: 1, text: "Intro", anchor: "h1" },
        { kind: "paragraph", text: "Body.", anchor: "p1" },
        {
          kind: "table",
          headers: ["A", "B"],
          rows: [["1", "2"]],
          markdown: "| A | B |\n| --- | --- |\n| 1 | 2 |",
          anchor: "t1",
        },
        {
          kind: "list",
          ordered: false,
          items: [{ text: "one" }, { text: "two" }],
          anchor: "l1",
        },
        { kind: "code", code: "x", language: "ts", anchor: "c1" },
      ]),
    );
    // has_blocks +0.2, headings +0.15, table_headers +0.15, no_warnings +0.1,
    // diverse_kinds (heading, table, list, code = 4) +0.2 => 0.8.
    expect(result.score).toBeCloseTo(0.8, 5);
    expect(result.reasons.find((r) => r.code === "diverse_kinds")?.weight).toBeCloseTo(0.2, 5);
  });

  it("penalizes low OCR confidence", () => {
    const result = scoreParseQuality(
      ast(
        [{ kind: "paragraph", text: "OCR text.", anchor: "a1" }],
        { ocrUsed: true, ocrConfidence: 0.3, warnings: [] },
      ),
    );
    // 0.2 (has_blocks) + 0.1 (no_warnings) - 0.1 (single_paragraph_doc) - 0.15 (ocr) = 0.05
    expect(result.score).toBeCloseTo(0.05, 5);
    expect(result.reasons.some((r) => r.code === "low_ocr_confidence")).toBe(true);
  });

  it("penalizes errors capped at -0.3", () => {
    const result = scoreParseQuality(
      ast(
        [
          { kind: "heading", level: 1, text: "Intro", anchor: "h1" },
          { kind: "paragraph", text: "Body.", anchor: "p1" },
        ],
        {
          errors: [
            { code: "e1", message: "x" },
            { code: "e2", message: "y" },
            { code: "e3", message: "z" },
            { code: "e4", message: "w" },
            { code: "e5", message: "u" },
          ],
        },
      ),
    );
    const parseErrReason = result.reasons.find((r) => r.code === "parse_errors")!;
    expect(parseErrReason.weight).toBe(-0.3);
  });

  it("clamps score to [0, 1]", () => {
    const result = scoreParseQuality(
      ast(
        [{ kind: "paragraph", text: "x", anchor: "a1" }],
        {
          warnings: [{ code: "w", message: "x" }],
          errors: [
            { code: "e1", message: "x" },
            { code: "e2", message: "y" },
            { code: "e3", message: "z" },
          ],
          ocrUsed: true,
          ocrConfidence: 0.1,
        },
      ),
    );
    expect(result.score).toBeGreaterThanOrEqual(0);
    expect(result.score).toBeLessThanOrEqual(1);
  });
});
