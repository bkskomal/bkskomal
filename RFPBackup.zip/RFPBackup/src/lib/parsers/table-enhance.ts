// LLM-assisted table repair.
//
// Format-specific parsers do their best to recover table structure but PDF
// text-layer extraction in particular often produces tables with shifted
// columns or ragged row widths. This module walks the AST, finds the
// low-confidence / ragged tables, and asks the org's LLM to clean them up.
// The cleaned Markdown replaces the block's `markdown`, `headers`, and
// `rows` and the confidence is bumped to reflect the repair.
//
// Cost guardrails:
//   - Only tables flagged below `confidenceThreshold` (default 0.7) OR with
//     uneven row widths get sent. A confident, regular table is left alone.
//   - Hard per-document cap (MAX_TABLES_PER_DOC) so a 200-table appendix
//     can't blow through an org's budget.
//   - Sequential calls (no concurrency) — tables in the same doc are likely
//     similar, and serial calls keep token-budget predictable.

import { getAiClients } from "@/lib/ai/client";
import { TABLE_ENHANCE_SYSTEM } from "@/lib/ai/prompts";
import type { DocumentAST, TableBlock, ParseWarning } from "./ast";

export interface EnhanceTablesOptions {
  /** Tables with `confidence < threshold` are enhanced. Default 0.7. */
  confidenceThreshold?: number;
  /** Cap on tables enhanced per document. Default 6. */
  maxTables?: number;
  /**
   * Internal override of the LLM call — used by tests so they can run
   * without a live OpenAI client.
   */
  enhanceFn?: (input: {
    markdown: string;
    contextHint: string;
    organizationId: string;
  }) => Promise<string>;
}

const DEFAULT_MAX_TABLES = 6;
const DEFAULT_CONFIDENCE_THRESHOLD = 0.7;

/**
 * Find low-confidence / mis-shaped tables and run them through the LLM
 * repair prompt. Replaces the block's `markdown`/`headers`/`rows` in place
 * (returning a new AST object — the input is not mutated) and bumps
 * `confidence` to 0.9.
 */
export async function enhanceTablesWithLLM(
  ast: DocumentAST,
  organizationId: string,
  opts?: EnhanceTablesOptions,
): Promise<DocumentAST> {
  const threshold = opts?.confidenceThreshold ?? DEFAULT_CONFIDENCE_THRESHOLD;
  const cap = opts?.maxTables ?? DEFAULT_MAX_TABLES;

  // Identify candidates in document order.
  const candidates: { idx: number; block: TableBlock }[] = [];
  for (let i = 0; i < ast.blocks.length; i++) {
    const b = ast.blocks[i];
    if (b.kind !== "table") continue;
    if (needsRepair(b, threshold)) candidates.push({ idx: i, block: b });
  }
  if (candidates.length === 0) return ast;

  const blocks = [...ast.blocks];
  const warnings: ParseWarning[] = [];

  const toEnhance = candidates.slice(0, cap);
  const skipped = candidates.length - toEnhance.length;
  if (skipped > 0) {
    warnings.push({
      code: "table_enhance_capped",
      message: `Skipped ${skipped} low-confidence table(s); per-doc enhance cap (${cap}) reached.`,
      context: { skipped, cap },
    });
  }

  const enhance =
    opts?.enhanceFn ??
    (async ({ markdown, contextHint, organizationId: orgId }) => {
      const { llm, config } = await getAiClients(orgId);
      const userPrompt =
        `Current table:\n\n${markdown}\n\n` +
        (contextHint
          ? `Surrounding context (for disambiguation only):\n${contextHint}\n\n`
          : "") +
        `Return only the corrected Markdown table.`;
      const completion = await llm.chat.completions.create({
        model: config.llm.model,
        messages: [
          { role: "system", content: TABLE_ENHANCE_SYSTEM },
          { role: "user", content: userPrompt },
        ],
        temperature: 0,
      });
      return completion.choices?.[0]?.message?.content?.toString() ?? "";
    });

  for (const entry of toEnhance) {
    try {
      const contextHint = surroundingContextFor(ast, entry.idx);
      const raw = await enhance({
        markdown: entry.block.markdown,
        contextHint,
        organizationId,
      });
      const cleanedMarkdown = stripFencesAndPrelude(raw);
      const parsed = parseMarkdownTable(cleanedMarkdown);
      if (!parsed) {
        warnings.push({
          code: "table_enhance_unparseable",
          message: `Table enhancer returned non-tabular output; original kept.`,
          context: { anchor: entry.block.anchor },
        });
        continue;
      }
      blocks[entry.idx] = {
        ...entry.block,
        markdown: cleanedMarkdown,
        headers: parsed.headers,
        rows: parsed.rows,
        confidence: 0.9,
      };
    } catch (err) {
      warnings.push({
        code: "table_enhance_error",
        message: `Table enhance failed for anchor ${entry.block.anchor}: ${
          err instanceof Error ? err.message : String(err)
        }`,
        context: { anchor: entry.block.anchor },
      });
    }
  }

  return {
    ...ast,
    blocks,
    report: {
      ...ast.report,
      warnings: [...ast.report.warnings, ...warnings],
    },
  };
}

function needsRepair(t: TableBlock, threshold: number): boolean {
  const conf = t.confidence ?? 1;
  if (conf < threshold) return true;
  // Ragged column counts -> almost certainly mis-parsed.
  if (t.rows.length >= 2) {
    const widths = new Set<number>();
    for (const r of t.rows) widths.add(r.length);
    if (widths.size > 1) return true;
    // Header width mismatches body width.
    if (t.headers && t.headers.length > 0 && !widths.has(t.headers.length)) return true;
  }
  return false;
}

function surroundingContextFor(ast: DocumentAST, idx: number): string {
  const parts: string[] = [];
  for (let i = Math.max(0, idx - 2); i < idx; i++) {
    const b = ast.blocks[i];
    if (b.kind === "paragraph" || b.kind === "heading") parts.push(b.kind === "heading" ? `# ${b.text}` : b.text);
  }
  for (let i = idx + 1; i < Math.min(ast.blocks.length, idx + 3); i++) {
    const b = ast.blocks[i];
    if (b.kind === "paragraph") parts.push(b.text);
  }
  return parts.join("\n").slice(0, 800);
}

function stripFencesAndPrelude(text: string): string {
  // Some models still return ```markdown ... ``` despite the prompt. Strip
  // a leading fence and any prose before the first pipe row.
  let t = text.trim();
  if (t.startsWith("```")) {
    const firstNl = t.indexOf("\n");
    if (firstNl > 0) t = t.slice(firstNl + 1);
    if (t.endsWith("```")) t = t.slice(0, -3);
  }
  // Trim everything before the first row that looks like a markdown table.
  const lines = t.split("\n");
  const firstPipe = lines.findIndex((l) => l.trim().startsWith("|"));
  if (firstPipe > 0) {
    return lines.slice(firstPipe).join("\n").trim();
  }
  return t.trim();
}

function parseMarkdownTable(md: string): { headers: string[]; rows: string[][] } | null {
  const lines = md
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.startsWith("|"));
  if (lines.length < 2) return null;
  const splitRow = (line: string): string[] => {
    // Strip leading/trailing pipes then split.
    const trimmed = line.replace(/^\|/, "").replace(/\|$/, "");
    return trimmed.split("|").map((c) => c.trim());
  };
  const headers = splitRow(lines[0]);
  // Second line should be the separator (---|---). Skip it.
  const sepIdx = isSeparatorRow(lines[1]) ? 2 : 1;
  const rows: string[][] = [];
  for (let i = sepIdx; i < lines.length; i++) {
    const cells = splitRow(lines[i]);
    rows.push(cells);
  }
  if (rows.length === 0) return null;
  return { headers, rows };
}

function isSeparatorRow(line: string): boolean {
  return /^\|?\s*:?-{3,}:?(\s*\|\s*:?-{3,}:?)*\s*\|?$/.test(line);
}
