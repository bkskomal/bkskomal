// Parsers facade — backwards-compatible file-path API on top of the new
// buffer-based pipeline in `./parse.ts`.
//
// LlamaParse (when configured for the org) still wins for PDFs / DOCX / PPTX
// because it handles complex layouts better than our local pipeline. When
// LlamaParse is unavailable or fails, we fall back to the local DocumentAST
// pipeline.

import { extname } from "node:path";
import { readFile } from "node:fs/promises";
import { parseWithLlamaParse, resolveLlamaParse } from "./llamaparse";
import { parseDocument as parseBuffer } from "./parse";
import type { DocumentAST } from "./ast";

export interface ParseResult {
  text: string;
  pageCount?: number;
  /** Which provider produced the text. */
  provider?: "llamaparse" | "local";
  /** Full DocumentAST when produced by the local pipeline. */
  ast?: DocumentAST;
}

// File types LlamaParse handles best (rich documents). For txt/md we keep the
// local path because LlamaParse charges per page even for tiny files.
const LLAMAPARSE_MIMES = new Set([
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/vnd.ms-powerpoint",
]);

export type ParserMime =
  | "application/pdf"
  | "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  | "application/msword"
  | "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  | "application/vnd.ms-excel"
  | "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  | "application/vnd.ms-powerpoint"
  | "text/plain"
  | "text/markdown"
  | "text/html";

const SUPPORTED_EXT: Record<string, ParserMime> = {
  ".pdf": "application/pdf",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".doc": "application/msword",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".xls": "application/vnd.ms-excel",
  ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ".ppt": "application/vnd.ms-powerpoint",
  ".txt": "text/plain",
  ".md": "text/markdown",
  ".markdown": "text/markdown",
  ".html": "text/html",
  ".htm": "text/html",
};

export function detectMime(fileName: string): ParserMime | null {
  const ext = extname(fileName).toLowerCase();
  return SUPPORTED_EXT[ext] ?? null;
}

/**
 * Legacy file-path entry point. Preserved for backward compatibility with
 * `src/lib/rfp-pipeline.ts`, `src/lib/indexing.ts`, and the attachments
 * route. Delegates to the new buffer-based pipeline in `./parse.ts` and also
 * keeps the LlamaParse premium path.
 *
 * Callers that want the structured AST should use the new `parseDocument`
 * exported from `./parse.ts` instead.
 */
export async function parseDocument(
  filePath: string,
  mime: string,
  orgId?: string | null,
): Promise<ParseResult> {
  // Premium path: LlamaParse handles tables, charts, multi-column PDFs.
  if (LLAMAPARSE_MIMES.has(mime)) {
    const llama = await resolveLlamaParse(orgId ?? null);
    if (llama) {
      try {
        const result = await parseWithLlamaParse(filePath, orgId ?? null);
        return { text: result.text, provider: "llamaparse" };
      } catch (e) {
        // Soft-fail: log and fall back to local parsers so a transient
        // LlamaParse outage doesn't block uploads.
        console.warn("[parsers] LlamaParse failed, falling back to local:", e);
      }
    }
  }

  // PPTX has no DocumentAST parser yet — keep the legacy officeparser path.
  if (
    mime === "application/vnd.openxmlformats-officedocument.presentationml.presentation" ||
    mime === "application/vnd.ms-powerpoint"
  ) {
    return { ...(await parsePowerPoint(filePath)), provider: "local" };
  }

  // Plain-text shortcut: no need to spin up the AST pipeline for a .txt.
  if (mime === "text/plain") {
    return { text: await readFile(filePath, "utf8"), provider: "local" };
  }

  // Everything else: route through the new DocumentAST pipeline.
  const buf = await readFile(filePath);
  const { text, ast } = await parseBuffer(buf, mime, orgId, filePath);
  return {
    text,
    ast,
    pageCount: ast.metadata.pageCount,
    provider: "local",
  };
}

async function parsePowerPoint(filePath: string): Promise<ParseResult> {
  const office = (await import("officeparser")) as unknown as {
    parseOfficeAsync: (p: string) => Promise<string>;
  };
  const text: string = await office.parseOfficeAsync(filePath);
  return { text };
}

// Re-export the buffer-based facade so callers can opt into ASTs.
export {
  parseDocument as parseDocumentBuffer,
  detectFormat,
  PARSER_PIPELINE_VERSION,
  PARSER_VERSIONS,
} from "./parse";
export type { ParseDocumentResult } from "./parse";
