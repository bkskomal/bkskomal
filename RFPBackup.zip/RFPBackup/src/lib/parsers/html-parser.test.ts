import { describe, it, expect } from "vitest";
import { htmlParser, parseHtmlBuffer } from "./html-parser";
import { astToMarkdown } from "./ast";

const buf = (s: string) => Buffer.from(s, "utf8");

describe("htmlParser", () => {
  it("returns empty AST + warning for empty input", async () => {
    const ast = await parseHtmlBuffer(buf(""), { fileName: "empty.html" });
    expect(ast.blocks).toEqual([]);
    expect(ast.report.warnings.some((w) => w.code === "empty_input")).toBe(true);
    expect(astToMarkdown(ast)).toBe("\n");
  });

  it("parses a clean article with headings + paragraphs", async () => {
    const html = `<!doctype html><html lang="en"><head><title>About us</title></head>
      <body>
        <article>
          <h1>About us</h1>
          <p>We build great <strong>software</strong>.</p>
          <h2>Team</h2>
          <p>Founded in 2024.</p>
        </article>
      </body></html>`;
    const ast = await parseHtmlBuffer(buf(html), { fileName: "about.html" });
    expect(ast.metadata.parser).toBe("html");
    expect(ast.metadata.title).toBe("About us");
    expect(ast.metadata.language).toBe("en");
    const kinds = ast.blocks.map((b) => b.kind);
    expect(kinds).toContain("heading");
    expect(kinds).toContain("paragraph");
    const md = astToMarkdown(ast);
    expect(md).toContain("# About us");
    expect(md).toContain("**software**");
  });

  it("preserves tables", async () => {
    const html = `<html><body><h1>Pricing</h1>
      <table>
        <thead><tr><th>Plan</th><th>Cost</th></tr></thead>
        <tbody>
          <tr><td>Basic</td><td>$10</td></tr>
          <tr><td>Pro</td><td>$30</td></tr>
        </tbody>
      </table></body></html>`;
    const ast = await parseHtmlBuffer(buf(html), { fileName: "p.html" });
    const tbl = ast.blocks.find((b) => b.kind === "table");
    expect(tbl).toBeDefined();
    if (tbl?.kind !== "table") throw new Error("nope");
    expect(tbl.headers).toEqual(["Plan", "Cost"]);
    expect(tbl.rows).toEqual([
      ["Basic", "$10"],
      ["Pro", "$30"],
    ]);
    expect(tbl.markdown).toContain("| Plan | Cost |");
    expect(tbl.markdown).toContain("| Basic | $10 |");
  });

  it("handles nested lists", async () => {
    const html = `<html><body><ul>
      <li>Top 1<ul><li>nested 1.1</li><li>nested 1.2</li></ul></li>
      <li>Top 2</li>
    </ul></body></html>`;
    const ast = await parseHtmlBuffer(buf(html), { fileName: "l.html" });
    const list = ast.blocks.find((b) => b.kind === "list");
    expect(list?.kind).toBe("list");
    if (list?.kind !== "list") throw new Error("nope");
    expect(list.items).toHaveLength(2);
    expect(list.items[0].children).toHaveLength(2);
    expect(list.items[0].children?.[0].text).toBe("nested 1.1");
  });

  it("preserves code blocks with language", async () => {
    const html = `<html><body><pre><code class="language-ts">const x = 1;</code></pre></body></html>`;
    const ast = await parseHtmlBuffer(buf(html), { fileName: "c.html" });
    const code = ast.blocks.find((b) => b.kind === "code");
    if (code?.kind !== "code") throw new Error("nope");
    expect(code.language).toBe("ts");
    expect(code.code).toBe("const x = 1;");
  });

  it("strips chrome (nav/header/footer/aside) when not in Readability mode", async () => {
    // Tiny page so Readability returns nothing useful — we fall back to body
    // walk where chrome stripping happens.
    const html = `<html><body>
      <nav><a href="#">Home</a></nav>
      <header><h1>SiteNav</h1></header>
      <main><h1>Real title</h1><p>Real content here that we want.</p></main>
      <footer>Copyright X</footer>
    </body></html>`;
    const ast = await parseHtmlBuffer(buf(html), { fileName: "page.html" });
    const flat = astToMarkdown(ast);
    expect(flat).toContain("Real content");
    expect(flat).not.toContain("Copyright X");
  });

  it("astToMarkdown round-trips a small page", async () => {
    const html = `<html><body><h1>T</h1><p>p1</p><ul><li>a</li></ul></body></html>`;
    const ast = await parseHtmlBuffer(buf(html), { fileName: "r.html" });
    const md = astToMarkdown(ast);
    expect(md).toContain("# T");
    expect(md).toContain("p1");
    expect(md).toMatch(/-\s+a/);
  });

  it("hydrates FigureBlock.imageBuffer from inline data: URLs", async () => {
    // Smallest valid PNG (1x1 transparent) encoded as base64.
    const dataUrl =
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
    const html = `<html><body><h1>x</h1><p>before</p><img src="${dataUrl}" alt="diagram" /><p>after</p></body></html>`;
    const ast = await parseHtmlBuffer(buf(html), { fileName: "img.html" });
    const figure = ast.blocks.find((b) => b.kind === "figure");
    if (figure?.kind !== "figure") throw new Error("expected figure block");
    expect(figure.caption).toBe("diagram");
    expect(figure.imageBuffer).toBeDefined();
    expect(figure.imageBuffer!.byteLength).toBeGreaterThan(0);
    // PNG magic bytes confirm we decoded the base64 correctly.
    expect(figure.imageBuffer![0]).toBe(0x89);
    expect(figure.imageBuffer![1]).toBe(0x50);
  });

  it("fetches FigureBlock.imageBuffer from http(s) URLs via injected fetch", async () => {
    // Drop in a small PNG via a mocked fetch. We can't override the fetch
    // call without monkey-patching globalThis here, but the dom-walker emits
    // imageRef set to the http URL; image-fetch.ts uses globalThis.fetch.
    const png = Buffer.from(
      "89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000A49444154789C6300010000000500010D0A2DB40000000049454E44AE426082",
      "hex",
    );
    const original = globalThis.fetch;
    globalThis.fetch = (async (_url: unknown) =>
      ({
        ok: true,
        headers: new Map([["content-type", "image/png"]]) as unknown as Headers,
        arrayBuffer: async () => png.buffer.slice(png.byteOffset, png.byteOffset + png.byteLength),
      }) as unknown as Response) as typeof fetch;
    try {
      const html = `<html><body><h1>x</h1><img src="https://example.com/d.png" alt="d" /></body></html>`;
      const ast = await parseHtmlBuffer(buf(html), { fileName: "img.html" });
      const figure = ast.blocks.find((b) => b.kind === "figure");
      if (figure?.kind !== "figure") throw new Error("expected figure");
      expect(figure.imageBuffer).toBeDefined();
      expect(figure.imageBuffer!.byteLength).toBe(png.byteLength);
    } finally {
      globalThis.fetch = original;
    }
  });

  it("emits a warning and no buffer when image URL fetch fails", async () => {
    const original = globalThis.fetch;
    globalThis.fetch = (async (_url: unknown) => {
      throw new Error("network down");
    }) as unknown as typeof fetch;
    try {
      const html = `<html><body><h1>x</h1><img src="https://example.com/missing.png" alt="m" /></body></html>`;
      const ast = await parseHtmlBuffer(buf(html), { fileName: "img.html" });
      const figure = ast.blocks.find((b) => b.kind === "figure");
      if (figure?.kind !== "figure") throw new Error("expected figure");
      expect(figure.imageBuffer).toBeUndefined();
      expect(ast.report.warnings.some((w) => w.code === "image_fetch_failed")).toBe(true);
    } finally {
      globalThis.fetch = original;
    }
  });

  it("canParse detects HTML via MIME, extension, and magic bytes", () => {
    expect(
      htmlParser.canParse(buf("<html></html>"), {
        fileName: "x.txt",
        mimeType: "text/html",
      }),
    ).toBe(true);
    expect(
      htmlParser.canParse(buf("plain"), { fileName: "x.html", mimeType: "" }),
    ).toBe(true);
    expect(
      htmlParser.canParse(buf("<!DOCTYPE html><html></html>"), { fileName: "x.txt", mimeType: "" }),
    ).toBe(true);
    expect(
      htmlParser.canParse(buf("plain"), { fileName: "x.txt", mimeType: "" }),
    ).toBe(false);
  });
});
