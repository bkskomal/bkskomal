// LlamaParse provider — premium PDF/Word/PPT extraction with table + chart
// awareness. Activated only when an API key is configured (env or per-org).

import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { env } from "@/lib/env";
import { DocumentParseError, ExternalServiceError } from "@/lib/errors";
import { resolveAiConfig } from "@/lib/ai/config";

const POLL_INTERVAL_MS = 1500;
const MAX_POLLS = 80; // ~2 min ceiling

interface JobStatus {
  status: "PENDING" | "SUCCESS" | "ERROR" | string;
  error?: string;
}

/**
 * Resolve the active LlamaParse settings for an org, falling back to env.
 * Returns `null` when no key is configured anywhere.
 */
export async function resolveLlamaParse(orgId: string | null | undefined): Promise<{
  apiKey: string;
  resultType: "text" | "markdown";
  baseUrl: string;
} | null> {
  if (orgId) {
    const cfg = await resolveAiConfig(orgId);
    if (cfg.llamaparse.enabled && cfg.llamaparse.apiKey) {
      return {
        apiKey: cfg.llamaparse.apiKey,
        resultType: cfg.llamaparse.resultType,
        baseUrl: env.LLAMAPARSE_BASE_URL,
      };
    }
  }
  if (env.LLAMA_CLOUD_API_KEY) {
    return {
      apiKey: env.LLAMA_CLOUD_API_KEY,
      resultType: env.LLAMAPARSE_RESULT_TYPE,
      baseUrl: env.LLAMAPARSE_BASE_URL,
    };
  }
  return null;
}

export async function parseWithLlamaParse(
  filePath: string,
  orgId: string | null | undefined,
): Promise<{ text: string }> {
  const settings = await resolveLlamaParse(orgId);
  if (!settings) {
    throw new ExternalServiceError("llamaparse", "LLAMA_CLOUD_API_KEY is not configured");
  }
  const { apiKey, resultType, baseUrl } = settings;
  const base = baseUrl.replace(/\/$/, "");
  const fileName = basename(filePath);
  const buf = await readFile(filePath);

  const form = new FormData();
  form.append("file", new Blob([new Uint8Array(buf)]), fileName);
  form.append("result_type", resultType);

  const upload = await fetch(`${base}/upload`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
  });
  if (!upload.ok) {
    const body = await upload.text().catch(() => "");
    throw new ExternalServiceError(
      "llamaparse",
      `upload failed (${upload.status}): ${body.slice(0, 200)}`,
    );
  }
  const { id } = (await upload.json()) as { id: string };
  if (!id) throw new ExternalServiceError("llamaparse", "no job id returned");

  for (let i = 0; i < MAX_POLLS; i++) {
    await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
    const status = await fetch(`${base}/job/${id}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!status.ok) continue;
    const j = (await status.json()) as JobStatus;
    if (j.status === "SUCCESS") {
      const result = await fetch(`${base}/job/${id}/result/${resultType}`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (!result.ok) {
        throw new ExternalServiceError("llamaparse", `result fetch failed (${result.status})`);
      }
      const data = (await result.json()) as { text?: string; markdown?: string };
      const text = resultType === "markdown" ? data.markdown : data.text;
      if (!text) throw new DocumentParseError("LlamaParse returned an empty result");
      return { text };
    }
    if (j.status === "ERROR") {
      throw new DocumentParseError(`LlamaParse failed: ${j.error ?? "unknown error"}`);
    }
  }
  throw new ExternalServiceError("llamaparse", "timed out waiting for parse job");
}
