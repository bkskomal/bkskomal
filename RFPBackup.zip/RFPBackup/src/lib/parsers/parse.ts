// Parser facade — format detection + dispatch + AST → Markdown rendering.
//
// This is the public entry point for the "new" buffer-based parser pipeline.
// The legacy file-path-based `parseDocument` in `./index.ts` is preserved for
// backward compatibility and delegates to this module.

import {
  astToMarkdown,
  type DocumentAST,
  type ParseOptions,
  type ParserId,
} from "./ast";
import { parseHtmlBuffer, HTML_PARSER_VERSION } from "./html-parser";
import { parsePdfBuffer, PDF_PARSER_VERSION } from "./pdf-parser";
import { parseDocxBuffer, DOCX_PARSER_VERSION } from "./docx-parser";
import { parseXlsxBuffer, XLSX_PARSER_VERSION } from "./xlsx-parser";
import { parsePptxBuffer, PPTX_PARSER_VERSION } from "./pptx-parser";
import { parseTextBuffer, TEXT_PARSER_VERSION } from "./text-parser";

export const PARSER_PIPELINE_VERSION = "p1-2026-05";

export const PARSER_VERSIONS = {
  html: HTML_PARSER_VERSION,
  pdf: PDF_PARSER_VERSION,
  docx: DOCX_PARSER_VERSION,
  xlsx: XLSX_PARSER_VERSION,
  pptx: PPTX_PARSER_VERSION,
  md: TEXT_PARSER_VERSION,
  txt: TEXT_PARSER_VERSION,
} as const;

export interface ParseDocumentResult {
  /** Rendered Markdown of the AST (for legacy text consumers). */
  text: string;
  /** The full DocumentAST. */
  ast: DocumentAST;
}

/**
 * Detect the parser to use for this buffer + mime + filename combo.
 *
 * Order:
 *   1. Magic-byte sniff (PDF `%PDF`, ZIP `PK\x03\x04` peeked for word/ or xl/,
 *      HTML `<!DOCTYPE` or `<html`).
 *   2. MIME-type match.
 *   3. Filename extension fallback.
 *   4. Default to "txt" — never throws.
 */
export function detectFormat(
  buffer: Buffer,
  mimeType: string,
  fileName?: string,
): ParserId {
  // 1) Magic bytes.
  if (buffer.byteLength >= 4) {
    const head4 = buffer.slice(0, 4);
    if (head4[0] === 0x25 && head4[1] === 0x50 && head4[2] === 0x44 && head4[3] === 0x46) {
      // "%PDF"
      return "pdf";
    }
    if (head4[0] === 0x50 && head4[1] === 0x4b && head4[2] === 0x03 && head4[3] === 0x04) {
      // ZIP — could be docx, xlsx, or other Office format. Peek inside.
      const zipPeek = peekZipFormat(buffer);
      if (zipPeek) return zipPeek;
    }
  }
  // HTML sniff.
  if (buffer.byteLength > 0) {
    const head = buffer
      .slice(0, Math.min(buffer.byteLength, 2048))
      .toString("utf8")
      .toLowerCase()
      .trim();
    if (
      head.startsWith("<!doctype html") ||
      head.startsWith("<html") ||
      head.startsWith("<?xml") && head.includes("<html")
    ) {
      return "html";
    }
  }

  // 2) MIME match.
  const mime = mimeType?.toLowerCase() ?? "";
  if (mime === "application/pdf") return "pdf";
  if (
    mime === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    mime === "application/msword"
  ) return "docx";
  if (
    mime === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
    mime === "application/vnd.ms-excel"
  ) return "xlsx";
  if (
    mime === "application/vnd.openxmlformats-officedocument.presentationml.presentation" ||
    mime === "application/vnd.ms-powerpoint"
  ) return "pptx";
  if (mime === "text/html" || mime === "application/xhtml+xml") return "html";
  if (mime === "text/markdown" || mime === "text/x-markdown") return "md";
  if (mime === "text/plain") return "txt";

  // 3) Extension fallback.
  if (fileName) {
    const m = fileName.toLowerCase().match(/\.([a-z0-9]+)$/);
    if (m) {
      switch (m[1]) {
        case "pdf":
          return "pdf";
        case "docx":
        case "doc":
          return "docx";
        case "xlsx":
        case "xls":
          return "xlsx";
        case "pptx":
        case "ppt":
          return "pptx";
        case "html":
        case "htm":
        case "xhtml":
          return "html";
        case "md":
        case "markdown":
          return "md";
        case "txt":
          return "txt";
      }
    }
  }
  return "txt";
}

/**
 * Cheap peek inside a ZIP to distinguish docx (`word/`) from xlsx (`xl/`).
 * We don't decompress — just scan the first ~4KB for filename signatures
 * inside the local-file-header records.
 */
function peekZipFormat(buffer: Buffer): ParserId | null {
  const limit = Math.min(buffer.byteLength, 4096);
  const window = buffer.slice(0, limit).toString("binary");
  if (window.includes("ppt/")) return "pptx";
  if (window.includes("word/")) return "docx";
  if (window.includes("xl/")) return "xlsx";
  return null;
}

/**
 * Parse a document buffer into a DocumentAST + a Markdown rendering.
 *
 * @param buffer         The raw file contents.
 * @param mimeType       Declared MIME (used as a hint; magic bytes win).
 * @param organizationId Org context for per-org LLM clients (forwarded into
 *                       ParseOptions for parsers that may invoke vision OCR).
 * @param fileName       Original filename (used for extension fallback).
 */
export async function parseDocument(
  buffer: Buffer,
  mimeType: string,
  organizationId?: string | null,
  fileName?: string,
): Promise<ParseDocumentResult> {
  const id = detectFormat(buffer, mimeType, fileName);
  const opts: ParseOptions = {
    fileName: fileName ?? "",
    mimeType,
    organizationId: organizationId ?? undefined,
  };

  let ast: DocumentAST;
  try {
    switch (id) {
      case "pdf":
        ast = await parsePdfBuffer(buffer, opts);
        break;
      case "docx":
        ast = await parseDocxBuffer(buffer, opts);
        break;
      case "xlsx":
        ast = await parseXlsxBuffer(buffer, opts);
        break;
      case "pptx":
        ast = await parsePptxBuffer(buffer, opts);
        break;
      case "html":
        ast = await parseHtmlBuffer(buffer, opts);
        break;
      case "md":
      case "txt":
        ast = await parseTextBuffer(buffer, opts);
        break;
      default:
        // Exhaustiveness guard — id is one of the ParserId values.
        ast = await parseTextBuffer(buffer, opts);
    }
  } catch (e) {
    // Never throw out of the facade — produce a sentinel AST with the error
    // recorded. Callers downstream (rfp-pipeline, indexing) will see an
    // empty `text` and can decide whether to surface the error.
    ast = {
      metadata: { parser: id, parserVersion: PARSER_VERSIONS[id] },
      blocks: [],
      report: {
        parser: id,
        parserVersion: PARSER_VERSIONS[id],
        blockCount: 0,
        tableCount: 0,
        listCount: 0,
        figureCount: 0,
        ocrUsed: false,
        parseMs: 0,
        warnings: [],
        errors: [
          {
            code: "parser_threw",
            message: `Parser ${id} threw: ${e instanceof Error ? e.message : String(e)}`,
          },
        ],
      },
    };
  }

  return { text: astToMarkdown(ast), ast };
}
