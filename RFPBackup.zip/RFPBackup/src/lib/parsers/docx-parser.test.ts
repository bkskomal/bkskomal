import { describe, it, expect } from "vitest";
import {
  Document,
  Packer,
  Paragraph,
  HeadingLevel,
  Table,
  TableRow,
  TableCell,
  TextRun,
} from "docx";
import { parseDocxBuffer } from "./docx-parser";
import { astToMarkdown } from "./ast";

async function makeDocx(children: Paragraph[] | (Paragraph | Table)[]): Promise<Buffer> {
  const doc = new Document({
    sections: [{ children }],
  });
  return Packer.toBuffer(doc);
}

describe("docxParser", () => {
  it("returns empty AST + warning for empty input", async () => {
    const ast = await parseDocxBuffer(Buffer.alloc(0), { fileName: "x.docx" });
    expect(ast.blocks).toEqual([]);
    expect(ast.report.warnings.some((w) => w.code === "empty_input")).toBe(true);
  });

  it("extracts heading hierarchy", async () => {
    const buf = await makeDocx([
      new Paragraph({ text: "Top", heading: HeadingLevel.HEADING_1 }),
      new Paragraph({ text: "Intro paragraph here." }),
      new Paragraph({ text: "Sub", heading: HeadingLevel.HEADING_2 }),
      new Paragraph({ text: "Sub paragraph." }),
    ]);
    const ast = await parseDocxBuffer(buf, { fileName: "x.docx" });
    const headings = ast.blocks.filter((b) => b.kind === "heading");
    expect(headings.length).toBeGreaterThanOrEqual(2);
    if (headings[0].kind === "heading") {
      expect(headings[0].level).toBe(1);
      expect(headings[0].text).toBe("Top");
    }
    expect(ast.metadata.title).toBe("Top");
  });

  it("preserves tables", async () => {
    const buf = await makeDocx([
      new Paragraph({ text: "Title", heading: HeadingLevel.HEADING_1 }),
      new Table({
        rows: [
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("Plan")] }),
              new TableCell({ children: [new Paragraph("Cost")] }),
            ],
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("Basic")] }),
              new TableCell({ children: [new Paragraph("$10")] }),
            ],
          }),
        ],
      }),
    ]);
    const ast = await parseDocxBuffer(buf, { fileName: "x.docx" });
    const table = ast.blocks.find((b) => b.kind === "table");
    expect(table).toBeDefined();
    if (table?.kind !== "table") throw new Error("nope");
    expect(table.rows.length).toBeGreaterThanOrEqual(1);
    // Mammoth may or may not detect headers depending on bold/style — just
    // confirm Plan and Cost are present somewhere.
    const flat = JSON.stringify(table);
    expect(flat).toContain("Plan");
    expect(flat).toContain("Basic");
  });

  it("round-trips through astToMarkdown", async () => {
    const buf = await makeDocx([
      new Paragraph({ text: "Hello", heading: HeadingLevel.HEADING_1 }),
      new Paragraph({
        children: [new TextRun("Some text with "), new TextRun({ text: "bold", bold: true })],
      }),
    ]);
    const ast = await parseDocxBuffer(buf, { fileName: "x.docx" });
    const md = astToMarkdown(ast);
    expect(md).toContain("# Hello");
    expect(md.toLowerCase()).toContain("some text");
  });
});
