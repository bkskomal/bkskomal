// HTML parser — Readability for article extraction, cheerio for structured
// DOM walk, turndown as a fallback table renderer (kept available to P2).
//
// Strategy:
//   1. Run jsdom + @mozilla/readability against the raw HTML. If it returns
//      an article body we treat as substantial, walk THAT.
//   2. Otherwise walk the whole <body>, skipping chrome (nav/header/footer/aside).
//   3. The shared walker (dom-walker.ts) does the actual block extraction —
//      this file only does Readability invocation and root selection.

import * as cheerio from "cheerio";
import { Readability } from "@mozilla/readability";
import { JSDOM } from "jsdom";
import TurndownService from "turndown";

import {
  detectLanguage,
  type DocumentAST,
  type DocumentParser,
  type ParseOptions,
  type ParseReport,
  type ParseWarning,
} from "./ast";
import { cheerioToDom, walkDom } from "./dom-walker";
import { hydrateFigureImages } from "./image-fetch";

export const HTML_PARSER_VERSION = "html-2026-05-01";

// Threshold below which we treat Readability's output as "not useful" and fall
// back to walking the whole body.
const READABILITY_MIN_CHARS = 200;

export const htmlParser: DocumentParser = {
  id: "html",
  version: HTML_PARSER_VERSION,
  canParse(buffer, opts) {
    const mime = opts.mimeType?.toLowerCase() ?? "";
    if (mime.startsWith("text/html") || mime === "application/xhtml+xml") return true;
    if (opts.fileName?.match(/\.(html?|xhtml)$/i)) return true;
    const head = buffer.slice(0, 2048).toString("utf8").toLowerCase();
    return /<!doctype html|<html[\s>]|<body[\s>]/.test(head);
  },
  async parse(buffer, opts): Promise<DocumentAST> {
    return parseHtmlBuffer(buffer, opts);
  },
};

export async function parseHtmlBuffer(
  buffer: Buffer,
  opts: ParseOptions,
): Promise<DocumentAST> {
  const t0 = Date.now();
  const warnings: ParseWarning[] = [];
  const errors: ParseWarning[] = [];

  const html = buffer.toString("utf8");
  if (!html.trim()) {
    warnings.push({ code: "empty_input", message: "HTML input is empty." });
    return emptyHtmlAst(t0, warnings, errors);
  }

  // jsdom + Readability for article extraction.
  // SKIPPED when the document was produced by our URL scraper (the scraper
  // already ran Readability once when fetching the page — running it again
  // here strips the hero + trailing-image `<figure>` tags we injected into
  // the body, dropping the per-doc image count to zero).
  const isPreScraped = /<meta[^>]+name=["']autorfp-scraped["']/i.test(html);
  let articleContent: string | undefined;
  let articleTitle: string | undefined;
  let langAttr: string | undefined;
  try {
    const dom = new JSDOM(html, { url: "http://localhost/" });
    langAttr =
      dom.window.document.documentElement.getAttribute("lang") ??
      dom.window.document.documentElement.lang ??
      undefined;
    if (!isPreScraped) {
      const reader = new Readability(dom.window.document.cloneNode(true) as Document);
      const parsed = reader.parse();
      if (parsed?.content && parsed.content.replace(/<[^>]+>/g, "").length >= READABILITY_MIN_CHARS) {
        articleContent = parsed.content;
        articleTitle = parsed.title?.trim() || undefined;
      }
    }
  } catch (e) {
    warnings.push({
      code: "readability_failed",
      message: `Readability extraction failed: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  // Parse with cheerio — either the Readability article subtree or the
  // original document body.
  const $ = cheerio.load(articleContent ?? html);
  const $title = $("title").first().text().trim() || undefined;
  const $h1 = $("h1").first().text().trim() || undefined;
  const titleFromHtml = articleTitle || $title || $h1 || undefined;

  // When Readability ran, its output is article-only — no chrome to skip.
  // When falling back, walk the <body> and let the walker skip nav/etc.
  const rootEl: cheerio.Cheerio<unknown> = articleContent
    ? ($.root() as unknown as cheerio.Cheerio<unknown>)
    : $("body").length
      ? ($("body") as unknown as cheerio.Cheerio<unknown>)
      : ($.root() as unknown as cheerio.Cheerio<unknown>);
  const rootNode = (rootEl as unknown as { get(i: number): unknown }).get(0);
  if (!rootNode) {
    warnings.push({
      code: "no_body",
      message: "Could not locate <body> or root node.",
    });
    return emptyHtmlAst(t0, warnings, errors, { title: titleFromHtml });
  }

  const walk = walkDom(cheerioToDom(rootNode), { skipChrome: !articleContent });
  warnings.push(...walk.warnings);

  // Hydrate FigureBlock.imageBuffer from inline data: URLs and (when allowed)
  // remote http(s) URLs. Allowing fetch is opt-in and bounded — see
  // image-fetch.ts for limits. Failures are appended as warnings; the parse
  // itself never fails because of an unreachable image.
  let figureBlocks = walk.blocks;
  try {
    const hydrate = await hydrateFigureImages(walk.blocks, {
      allowFetch: opts.allowImageFetch !== false,
      maxImages: opts.maxImagesPerDoc,
    });
    figureBlocks = hydrate.blocks;
    warnings.push(...hydrate.warnings);
  } catch (e) {
    warnings.push({
      code: "image_hydrate_failed",
      message: `Image hydration failed: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  // Language: <html lang>, then heuristic.
  let language: string | undefined = langAttr?.toLowerCase().split("-")[0] || undefined;
  if (!language) {
    const combined = figureBlocks
      .map((b) => ("text" in b ? (b as { text: string }).text : ""))
      .join(" ");
    language = detectLanguage(combined) ?? undefined;
  }

  const title = titleFromHtml ?? walk.detectedTitle;

  const tableCount = figureBlocks.filter((b) => b.kind === "table").length;
  const listCount = figureBlocks.filter((b) => b.kind === "list").length;
  const figureCount = figureBlocks.filter((b) => b.kind === "figure").length;

  const report: ParseReport = {
    parser: "html",
    parserVersion: HTML_PARSER_VERSION,
    blockCount: figureBlocks.length,
    tableCount,
    listCount,
    figureCount,
    ocrUsed: false,
    parseMs: Date.now() - t0,
    warnings,
    errors,
  };

  return {
    metadata: {
      title,
      language,
      parser: "html",
      parserVersion: HTML_PARSER_VERSION,
    },
    blocks: figureBlocks,
    report,
  };
}

function emptyHtmlAst(
  t0: number,
  warnings: ParseWarning[],
  errors: ParseWarning[],
  meta: { title?: string } = {},
): DocumentAST {
  return {
    metadata: {
      title: meta.title,
      parser: "html",
      parserVersion: HTML_PARSER_VERSION,
    },
    blocks: [],
    report: {
      parser: "html",
      parserVersion: HTML_PARSER_VERSION,
      blockCount: 0,
      tableCount: 0,
      listCount: 0,
      figureCount: 0,
      ocrUsed: false,
      parseMs: Date.now() - t0,
      warnings,
      errors,
    },
  };
}

// Turndown is exposed for P2 / table-enhance use; we keep it imported here so
// the dep is exercised and downstream code can reuse the configured instance.
let _turndown: TurndownService | undefined;
export function getTurndown(): TurndownService {
  if (!_turndown) {
    _turndown = new TurndownService({
      headingStyle: "atx",
      codeBlockStyle: "fenced",
      bulletListMarker: "-",
    });
    // GFM-ish: keep tables (turndown default drops them).
    _turndown.addRule("table", {
      filter: "table",
      replacement: (_content, node) => {
        const el = node as HTMLTableElement;
        const rows: string[][] = [];
        for (const tr of Array.from(el.rows)) {
          rows.push(
            Array.from(tr.cells).map((c) => (c.textContent ?? "").trim().replace(/\|/g, "\\|")),
          );
        }
        if (rows.length === 0) return "";
        const cols = Math.max(...rows.map((r) => r.length));
        rows.forEach((r) => {
          while (r.length < cols) r.push("");
        });
        const head = rows[0];
        const body = rows.slice(1);
        const out: string[] = [];
        out.push("| " + head.join(" | ") + " |");
        out.push("| " + head.map(() => "---").join(" | ") + " |");
        for (const r of body) out.push("| " + r.join(" | ") + " |");
        return "\n\n" + out.join("\n") + "\n\n";
      },
    });
  }
  return _turndown;
}
