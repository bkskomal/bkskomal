import { describe, it, expect, vi, beforeEach } from "vitest";
import { astToMarkdown } from "./ast";

// Mock pdfjs-dist before importing the parser.
type MockItem = { str: string; transform: number[]; width: number; height: number };
interface MockPage {
  items: MockItem[];
  viewport: { width: number; height: number };
}
let mockPages: MockPage[] = [];
let mockInfo: Record<string, unknown> = {};

vi.mock("pdfjs-dist/legacy/build/pdf.mjs", () => {
  return {
    GlobalWorkerOptions: { workerSrc: "" },
    getDocument: () => ({
      promise: Promise.resolve({
        numPages: mockPages.length,
        getMetadata: () => Promise.resolve({ info: mockInfo }),
        getPage: (n: number) =>
          Promise.resolve({
            getViewport: () => mockPages[n - 1].viewport,
            getTextContent: () =>
              Promise.resolve({ items: mockPages[n - 1].items }),
            cleanup: () => {},
          }),
        destroy: () => Promise.resolve(),
      }),
    }),
  };
});

import { parsePdfBuffer } from "./pdf-parser";

const someBytes = Buffer.from("%PDF-1.4\n");

beforeEach(() => {
  mockPages = [];
  mockInfo = {};
});

describe("pdfParser", () => {
  it("returns empty AST + warning for empty input", async () => {
    const ast = await parsePdfBuffer(Buffer.alloc(0), { fileName: "x.pdf" });
    expect(ast.blocks).toEqual([]);
    expect(ast.report.warnings.some((w) => w.code === "empty_input")).toBe(true);
  });

  it("extracts heading + paragraph by font size, with page breaks", async () => {
    // Page 1: a big heading + a body paragraph.
    // Page 2: another body paragraph.
    mockPages = [
      {
        viewport: { width: 600, height: 800 },
        items: [
          { str: "Big Title", transform: [22, 0, 0, 22, 50, 750], width: 100, height: 22 },
          { str: "This is body text.", transform: [12, 0, 0, 12, 50, 700], width: 150, height: 12 },
        ],
      },
      {
        viewport: { width: 600, height: 800 },
        items: [
          { str: "More body content.", transform: [12, 0, 0, 12, 50, 700], width: 150, height: 12 },
        ],
      },
    ];
    const ast = await parsePdfBuffer(someBytes, { fileName: "x.pdf" });
    expect(ast.metadata.parser).toBe("pdf");
    expect(ast.metadata.pageCount).toBe(2);
    const kinds = ast.blocks.map((b) => b.kind);
    expect(kinds).toContain("heading");
    expect(kinds).toContain("paragraph");
    expect(kinds).toContain("page_break");
    const heading = ast.blocks.find((b) => b.kind === "heading");
    if (heading?.kind === "heading") {
      expect(heading.text).toBe("Big Title");
      expect(heading.level).toBe(1);
    }
  });

  it("emits FigureBlock with warning for image-only (no text) page", async () => {
    mockPages = [
      { viewport: { width: 600, height: 800 }, items: [] },
    ];
    const ast = await parsePdfBuffer(someBytes, { fileName: "scanned.pdf" });
    const fig = ast.blocks.find((b) => b.kind === "figure");
    expect(fig).toBeDefined();
    expect(ast.report.warnings.some((w) => w.code === "scanned_page")).toBe(true);
  });

  it("uses PDF metadata title when present", async () => {
    mockInfo = { Title: "From Metadata" };
    mockPages = [
      {
        viewport: { width: 600, height: 800 },
        items: [
          { str: "Body line.", transform: [12, 0, 0, 12, 50, 700], width: 100, height: 12 },
        ],
      },
    ];
    const ast = await parsePdfBuffer(someBytes, { fileName: "x.pdf" });
    expect(ast.metadata.title).toBe("From Metadata");
  });

  it("round-trips through astToMarkdown", async () => {
    mockPages = [
      {
        viewport: { width: 600, height: 800 },
        items: [
          { str: "Heading", transform: [20, 0, 0, 20, 50, 750], width: 80, height: 20 },
          { str: "Para line.", transform: [12, 0, 0, 12, 50, 700], width: 100, height: 12 },
        ],
      },
    ];
    const ast = await parsePdfBuffer(someBytes, { fileName: "x.pdf" });
    const md = astToMarkdown(ast);
    expect(md).toContain("Heading");
    expect(md).toContain("Para line.");
  });

  it("strips repeating page headers/footers", async () => {
    // Same "Header text" appears at top of all 3 pages → should be suppressed.
    mockPages = [1, 2, 3].map((p) => ({
      viewport: { width: 600, height: 800 },
      items: [
        { str: "Header text", transform: [10, 0, 0, 10, 50, 770], width: 80, height: 10 },
        { str: `Body of page ${p}.`, transform: [12, 0, 0, 12, 50, 500], width: 120, height: 12 },
      ],
    }));
    const ast = await parsePdfBuffer(someBytes, { fileName: "x.pdf" });
    const allText = ast.blocks
      .map((b) => ("text" in b ? (b as { text: string }).text : ""))
      .join(" ");
    expect(allText).not.toContain("Header text");
    expect(allText).toContain("Body of page 1");
  });
});
