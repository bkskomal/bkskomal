import { describe, expect, it } from "vitest";
import { cleanLayout } from "./layout-clean";
import type { DocumentAST, ParagraphBlock, HeadingBlock } from "./ast";

function paragraph(text: string, page?: number): ParagraphBlock {
  return {
    kind: "paragraph",
    text,
    anchor: `a${Math.random().toString(36).slice(2, 8)}`,
    page,
  };
}

function heading(text: string, level = 1, page?: number): HeadingBlock {
  return {
    kind: "heading",
    text,
    level,
    anchor: `h${Math.random().toString(36).slice(2, 8)}`,
    page,
  };
}

function emptyReport() {
  return {
    parser: "html" as const,
    parserVersion: "1.0",
    blockCount: 0,
    tableCount: 0,
    listCount: 0,
    figureCount: 0,
    ocrUsed: false,
    parseMs: 1,
    warnings: [],
    errors: [],
  };
}

function ast(blocks: DocumentAST["blocks"]): DocumentAST {
  return {
    metadata: { parser: "html", parserVersion: "1.0" },
    blocks,
    report: { ...emptyReport(), blockCount: blocks.length },
  };
}

describe("cleanLayout", () => {
  it("strips repeating header on 6/10 pages", () => {
    const blocks: DocumentAST["blocks"] = [];
    // 10 pages: each page opens with the same header paragraph "ACME Corp - Confidential"
    // 6 pages of which also include real content; 4 pages are header-only.
    for (let p = 1; p <= 10; p++) {
      blocks.push(paragraph("ACME Corp - Confidential", p));
      if (p <= 6) {
        blocks.push(paragraph(`Page ${p} body text describing something unique to page ${p}.`, p));
      }
      blocks.push(paragraph(`${p}`, p)); // bare page number at bottom
    }
    const cleaned = cleanLayout(ast(blocks));
    const remaining = cleaned.blocks.filter((b) => b.kind === "paragraph") as ParagraphBlock[];
    // The repeating "ACME Corp" header should be gone everywhere; bare page
    // numbers gone too; only the 6 unique body paragraphs survive.
    expect(remaining).toHaveLength(6);
    for (const r of remaining) {
      expect(r.text).toMatch(/Page \d+ body text/);
    }
    expect(
      cleaned.report.warnings.some((w) => w.code === "layout_clean_header_footer_stripped"),
    ).toBe(true);
  });

  it("strips standalone page numbers in various forms", () => {
    const blocks: DocumentAST["blocks"] = [
      paragraph("Page 1 of 12"),
      paragraph("Real content goes here."),
      paragraph("12"),
      paragraph("Section 5: Things"), // real section header — must survive (it has words)
      paragraph("Page 7"),
    ];
    const cleaned = cleanLayout(ast(blocks));
    const remaining = cleaned.blocks.map((b) => (b as ParagraphBlock).text);
    expect(remaining).toEqual(["Real content goes here.", "Section 5: Things"]);
    expect(
      cleaned.report.warnings.some((w) => w.code === "layout_clean_page_numbers_stripped"),
    ).toBe(true);
  });

  it("preserves real content and headings even when adjacent to noise", () => {
    const blocks: DocumentAST["blocks"] = [
      heading("Introduction", 1),
      paragraph("Real intro paragraph.", 1),
      paragraph("3"),
      heading("Architecture", 1),
      paragraph("Real arch paragraph.", 2),
    ];
    const cleaned = cleanLayout(ast(blocks));
    expect(cleaned.blocks).toHaveLength(4);
    expect((cleaned.blocks[0] as HeadingBlock).text).toBe("Introduction");
    expect((cleaned.blocks[2] as HeadingBlock).text).toBe("Architecture");
  });

  it("drops adjacent duplicate paragraphs", () => {
    const blocks: DocumentAST["blocks"] = [
      paragraph("Hello world"),
      paragraph("Hello world"),
      paragraph("Hello world"),
      paragraph("Different paragraph"),
    ];
    const cleaned = cleanLayout(ast(blocks));
    expect(cleaned.blocks).toHaveLength(2);
    expect(
      cleaned.report.warnings.some((w) => w.code === "layout_clean_duplicates_stripped"),
    ).toBe(true);
  });

  it("does not collapse duplicates separated by a heading", () => {
    const blocks: DocumentAST["blocks"] = [
      paragraph("Hello world"),
      heading("Section", 2),
      paragraph("Hello world"),
    ];
    const cleaned = cleanLayout(ast(blocks));
    expect(cleaned.blocks).toHaveLength(3);
  });
});
