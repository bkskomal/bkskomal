// AutoRFP DocumentAST contract.
//
// Every parser (PDF, DOCX, XLSX, HTML, MD, TXT) emits this shape. Every
// downstream consumer (semantic chunker, citation builder, KB viewer,
// quality scorer) reads this shape. This is the integration seam.
//
// Design goals:
//   1. Lossless enough to preserve heading hierarchy, tables (as both
//      Markdown and structured JSON), lists, code, quotes, footnotes,
//      figures, page boundaries.
//   2. Cheap to serialize (plain JSON, no class instances).
//   3. Stable IDs/anchors so chunks survive re-ingest after parser upgrades.
//   4. Per-block provenance (page, sourceParser, confidence) so the citation
//      builder can produce exact-anchor citations and the quality scorer can
//      flag low-confidence regions.

export type ParserId = "html" | "pdf" | "docx" | "xlsx" | "pptx" | "md" | "txt";

export interface DocumentMetadata {
  /** Detected or declared title — first H1, <title> tag, docx core props, etc. */
  title?: string;
  /** Detected author. */
  author?: string;
  /** Detected publication/modification date (ISO string). */
  date?: string;
  /** BCP-47 language code (heuristic from text or declared in source). */
  language?: string;
  /** Source format that produced this AST. */
  parser: ParserId;
  /** Bumped when the parser implementation changes — used for re-ingest decisions. */
  parserVersion: string;
  /** Original page count when meaningful (PDF, multi-sheet XLSX). */
  pageCount?: number;
}

export type Block =
  | HeadingBlock
  | ParagraphBlock
  | ListBlock
  | TableBlock
  | CodeBlock
  | QuoteBlock
  | FigureBlock
  | FootnoteBlock
  | PageBreak
  | HorizontalRule;

export interface BlockBase {
  /** Stable anchor — hash of (section path + ordinal). */
  anchor: string;
  /** 1-based page number when applicable (PDF, paginated formats). */
  page?: number;
  /** Slash-joined heading path leading up to this block. e.g. "1 / Intro". */
  section?: string;
  /** Parser-reported confidence 0..1; null when the parser doesn't track it. */
  confidence?: number;
}

export interface HeadingBlock extends BlockBase {
  kind: "heading";
  /** 1..6, like HTML h1..h6. */
  level: number;
  text: string;
}

export interface ParagraphBlock extends BlockBase {
  kind: "paragraph";
  /** Plain text — Markdown-light formatting allowed (bold, italic, code spans). */
  text: string;
}

export interface ListBlock extends BlockBase {
  kind: "list";
  ordered: boolean;
  items: ListItem[];
}

export interface ListItem {
  text: string;
  /** Nested list, if any. */
  children?: ListItem[];
}

export interface TableBlock extends BlockBase {
  kind: "table";
  /** First non-empty row as headers when detected. */
  headers?: string[];
  /** Body rows; each row is an array of cell strings. */
  rows: string[][];
  /** Markdown rendering of the table for prompt context. */
  markdown: string;
  /** Caption / table-number when extractable (e.g. "Table 3: SLA tiers"). */
  caption?: string;
}

export interface CodeBlock extends BlockBase {
  kind: "code";
  language?: string;
  code: string;
}

export interface QuoteBlock extends BlockBase {
  kind: "quote";
  text: string;
  cite?: string;
}

export interface FigureBlock extends BlockBase {
  kind: "figure";
  /** Caption / alt text. */
  caption?: string;
  /** OCR / vision-LLM derived text from the image, when extracted. */
  ocrText?: string;
  /** Where the image lives if persisted. May be a data: URL, http(s) URL, or
   * `images/<sha256>.<ext>` path under uploads/ once the pipeline has stored
   * the bytes. */
  imageRef?: string;
  /**
   * Raw image bytes carried alongside the block during parsing. Populated by
   * format parsers (HTML <img>, DOCX inline images, PDF embedded images) and
   * consumed by the parser pipeline's image-processing step, which stores the
   * bytes via image-store and CLIP-embeds them. Cleared (set to undefined) by
   * the pipeline before the AST is serialized to JSON, so persisted ASTs stay
   * lean. Marked optional so the field is invisible to consumers that don't
   * care about images.
   */
  imageBuffer?: Buffer;
}

export interface FootnoteBlock extends BlockBase {
  kind: "footnote";
  /** Reference token in the body (e.g. "[1]"). */
  ref: string;
  text: string;
}

export interface PageBreak extends BlockBase {
  kind: "page_break";
  /** The new page number that begins after this break. */
  toPage: number;
}

export interface HorizontalRule extends BlockBase {
  kind: "hr";
}

export interface ParseWarning {
  /** Short machine-readable code. */
  code: string;
  /** Human-readable explanation. */
  message: string;
  /** Optional context — page, block anchor, etc. */
  context?: Record<string, unknown>;
}

export interface ParseReport {
  parser: ParserId;
  parserVersion: string;
  pageCount?: number;
  blockCount: number;
  tableCount: number;
  listCount: number;
  figureCount: number;
  /** True when OCR / vision fallback was invoked at least once. */
  ocrUsed: boolean;
  /** Mean OCR confidence across pages that needed it; null when not used. */
  ocrConfidence?: number;
  /** Wall-clock ms for the parse pass (excluding OCR). */
  parseMs: number;
  /** Wall-clock ms for OCR / vision fallback when invoked. */
  ocrMs?: number;
  /** Non-fatal warnings — surfaced in the KB viewer. */
  warnings: ParseWarning[];
  /** Soft errors that didn't prevent producing an AST. */
  errors: ParseWarning[];
}

export interface DocumentAST {
  metadata: DocumentMetadata;
  blocks: Block[];
  report: ParseReport;
}

// --------------------------------------------------------------------------
// Parser interface — every format-specific parser implements this.
// --------------------------------------------------------------------------

export interface ParseOptions {
  fileName: string;
  mimeType?: string;
  /**
   * When true, parser may invoke vision-LLM OCR for scanned PDFs or
   * extracted images. Wired by post-processing; parsers themselves only
   * surface that an image was found.
   */
  enableOcr?: boolean;
  /** Org context so parsers can resolve per-org LLM clients for vision fallback. */
  organizationId?: string;
  /** Hard cap on parse wall-clock ms. */
  timeoutMs?: number;
  /**
   * Per-document image cap forwarded to the image-fetch hydrator. Defaults
   * to 20; the URL ingest path raises this when the operator opts into
   * "scrape images" so a content-rich page (godhascome.com has 22 in the
   * hero alone) isn't silently truncated.
   */
  maxImagesPerDoc?: number;
  /**
   * When false, the HTML parser will not fetch remote images even when their
   * URLs are known. Default true. Set false to skip the image-embedding step
   * for fast text-only ingest.
   */
  allowImageFetch?: boolean;
}

export interface DocumentParser {
  id: ParserId;
  version: string;
  /** Quick test: can this parser handle this file? Checks MIME + magic bytes. */
  canParse(buffer: Buffer, opts: ParseOptions): boolean;
  parse(buffer: Buffer, opts: ParseOptions): Promise<DocumentAST>;
}

// --------------------------------------------------------------------------
// Helpers shared by every parser.
// --------------------------------------------------------------------------

import { createHash } from "node:crypto";

export function anchorFor(section: string | undefined, ordinal: number): string {
  return createHash("sha256")
    .update(`${section ?? ""}::${ordinal}`)
    .digest("hex")
    .slice(0, 16);
}

/**
 * Reduce an AST to a Markdown string for downstream prompt context + the
 * legacy rawText display. Order-preserving, tables emitted as Markdown,
 * pages joined with `\n\n---\n\n`.
 */
export function astToMarkdown(ast: DocumentAST): string {
  const out: string[] = [];
  if (ast.metadata.title) {
    out.push(`# ${ast.metadata.title}\n`);
  }
  for (const block of ast.blocks) {
    switch (block.kind) {
      case "heading":
        out.push(`${"#".repeat(Math.min(block.level, 6))} ${block.text}\n`);
        break;
      case "paragraph":
        out.push(`${block.text}\n`);
        break;
      case "list":
        out.push(renderList(block, 0));
        break;
      case "table":
        out.push(block.markdown);
        if (block.caption) out.push(`*${block.caption}*\n`);
        break;
      case "code":
        out.push("```" + (block.language ?? "") + "\n" + block.code + "\n```\n");
        break;
      case "quote":
        out.push(`> ${block.text}\n`);
        break;
      case "figure":
        if (block.caption) out.push(`*Figure: ${block.caption}*\n`);
        if (block.ocrText) out.push(block.ocrText + "\n");
        break;
      case "footnote":
        out.push(`[^${block.ref}]: ${block.text}\n`);
        break;
      case "page_break":
        out.push("\n---\n");
        break;
      case "hr":
        out.push("\n---\n");
        break;
    }
  }
  return out.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
}

function renderList(block: ListBlock, indent: number): string {
  const lines: string[] = [];
  block.items.forEach((it, i) => {
    const bullet = block.ordered ? `${i + 1}.` : "-";
    const prefix = " ".repeat(indent * 2) + bullet + " ";
    lines.push(prefix + it.text);
    if (it.children?.length) {
      for (const child of it.children) {
        lines.push(renderList({ ...block, items: [child] }, indent + 1).trimEnd());
      }
    }
  });
  return lines.join("\n") + "\n";
}

/**
 * Detect language from a text sample via a simple heuristic (digit/letter
 * frequency + common stop-words). Returns BCP-47 code or null.
 * Parsers can override with declared language when available.
 */
export function detectLanguage(text: string): string | null {
  const sample = text.slice(0, 4000).toLowerCase();
  if (!sample.match(/[a-z]/)) return null;
  const english = (sample.match(/\b(the|and|of|to|in|that|for|is|on|with)\b/g) ?? []).length;
  const spanish = (sample.match(/\b(el|la|de|que|y|en|los|las|por|con)\b/g) ?? []).length;
  const french  = (sample.match(/\b(le|la|de|et|que|à|les|un|une|des)\b/g) ?? []).length;
  const german  = (sample.match(/\b(der|die|das|und|in|mit|zu|den|von|für)\b/g) ?? []).length;
  const top = Math.max(english, spanish, french, german);
  if (top < 5) return null;
  if (top === english) return "en";
  if (top === spanish) return "es";
  if (top === french) return "fr";
  if (top === german) return "de";
  return null;
}
