import { describe, expect, it } from "vitest";
import { parseAndProcess } from "./pipeline";
import type { ClipEmbedder } from "@/lib/ai/clip";

// Reusable fake CLIP embedder — returns a deterministic 512-d vector of all
// 0.044194... (= 1/sqrt(512)) so it's already L2-normalized. Pipeline tests
// inject this so the heavyweight transformers.js pipeline never loads.
function fakeClipEmbedder(): ClipEmbedder {
  const v = new Array<number>(512).fill(1 / Math.sqrt(512));
  return {
    model: "test/clip-fake",
    dimensions: 512,
    ready: true,
    embedImage: async () => v.slice(),
    embedTextForImageSearch: async () => v.slice(),
  };
}

function failingClipEmbedder(): ClipEmbedder {
  return {
    model: "test/clip-broken",
    dimensions: 512,
    ready: true,
    embedImage: async () => {
      throw new Error("clip down");
    },
    embedTextForImageSearch: async () => {
      throw new Error("clip down");
    },
  };
}

const ONE_PIXEL_PNG_B64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";

describe("parseAndProcess (HTML end-to-end)", () => {
  it("parses HTML and produces text, chunks, and a quality score", async () => {
    const html = `<!DOCTYPE html>
<html>
<head><title>Sample Doc</title></head>
<body>
  <h1>Introduction</h1>
  <p>This is the introduction paragraph for the sample document.</p>
  <h2>Architecture</h2>
  <p>The architecture is composed of several distinct services.</p>
  <ul>
    <li>Service A handles ingress.</li>
    <li>Service B handles storage.</li>
    <li>Service C handles retrieval.</li>
  </ul>
</body>
</html>`;
    const buffer = Buffer.from(html, "utf8");
    const result = await parseAndProcess(buffer, "text/html", "sample.html", {
      organizationId: "org-test",
      enableOcr: false, // no figures in input anyway
      enableTableEnhance: false, // no tables to enhance
      enableImages: false, // no images in input
    });
    expect(result.text.length).toBeGreaterThan(0);
    expect(result.text).toContain("Introduction");
    expect(result.chunks.length).toBeGreaterThan(0);
    expect(result.quality.score).toBeGreaterThan(0);
    expect(result.quality.score).toBeLessThanOrEqual(1);
    // The first chunk should be the H1 heading.
    expect(result.chunks[0].kind).toBe("heading");
    // The architecture section should carry the heading path.
    const archChunk = result.chunks.find((c) => c.content.includes("composed of several"));
    expect(archChunk?.section).toContain("Architecture");
  });

  it("processes inline images: result.images is populated with CLIP vectors", async () => {
    const html = `<!DOCTYPE html><html><body>
      <h1>Spec</h1>
      <p>The architecture diagram below illustrates the components.</p>
      <img src="data:image/png;base64,${ONE_PIXEL_PNG_B64}" alt="diagram one" />
      <p>The data-flow diagram complements it.</p>
      <img src="data:image/png;base64,${ONE_PIXEL_PNG_B64}AA" alt="diagram two" />
    </body></html>`;
    const buffer = Buffer.from(html, "utf8");
    const result = await parseAndProcess(buffer, "text/html", "imgs.html", {
      organizationId: "org-test",
      enableOcr: false,
      enableTableEnhance: false,
      clipEmbedder: fakeClipEmbedder(),
    });
    expect(result.images).toBeDefined();
    expect(result.images!.length).toBe(2);
    for (const img of result.images!) {
      expect(img.vector).toHaveLength(512);
      expect(img.imagePath.startsWith("images/")).toBe(true);
      expect(img.figureAnchor.length).toBeGreaterThan(0);
    }
    // After processing, every figure block should have its imageBuffer
    // cleared and an imageRef pointing at the stored path.
    const figures = result.ast.blocks.filter((b) => b.kind === "figure");
    expect(figures.length).toBe(2);
    for (const f of figures) {
      if (f.kind !== "figure") continue;
      expect(f.imageBuffer).toBeUndefined();
      expect(f.imageRef?.startsWith("images/")).toBe(true);
    }
  });

  it("CLIP failure produces a warning but does not fail the parse", async () => {
    const html = `<!DOCTYPE html><html><body>
      <h1>Spec</h1>
      <p>Body text.</p>
      <img src="data:image/png;base64,${ONE_PIXEL_PNG_B64}" alt="d" />
    </body></html>`;
    const buffer = Buffer.from(html, "utf8");
    const result = await parseAndProcess(buffer, "text/html", "fail.html", {
      organizationId: "org-test",
      enableOcr: false,
      enableTableEnhance: false,
      clipEmbedder: failingClipEmbedder(),
    });
    // Result is still produced; images list is empty (the failed image is skipped).
    expect(result.images).toBeDefined();
    expect(result.images!.length).toBe(0);
    expect(result.chunks.length).toBeGreaterThan(0);
    // The pipeline should have recorded the per-image failure as a warning.
    const allWarnings = result.ast.report.warnings;
    expect(allWarnings.some((w) => w.code === "image_process_failed")).toBe(true);
  });

  it("never throws on completely invalid input", async () => {
    const buffer = Buffer.from([0xff, 0xfe, 0xfd, 0xfc]);
    const result = await parseAndProcess(buffer, "application/octet-stream", "garbage.bin", {
      organizationId: "org-test",
      enableOcr: false,
      enableTableEnhance: false,
      enableImages: false,
    });
    // We still get a result with an empty-ish AST; no exception escapes.
    expect(result.quality.score).toBeGreaterThanOrEqual(0);
    expect(result.chunks).toBeInstanceOf(Array);
  });
});
