// High-level parser pipeline.
//
// Single entry point used by ingest paths (KB upload, RFP processing) to:
//   1. Parse a buffer into an AST via the format facade (P1).
//   2. Clean layout artefacts (running headers, page numbers, dupes).
//   3. Fill OCR text on figures via the vision-LLM fallback.
//   4. Repair low-confidence tables via the LLM enhancer.
//   5. Score parse quality.
//   6. Chunk the AST for retrieval.
//   7. Render Markdown for legacy text consumers.
//
// Each step is opt-out via the options object — RFPs don't need chunks, KB
// uploads can disable OCR for paranoid orgs, etc. The orchestrator never
// throws on a step failure: every step records its error in the AST's
// report.warnings/errors and the next step continues with the partial
// result. That guarantee lets callers persist whatever quality we did
// manage to produce, rather than losing the entire ingest on a single
// flaky table-enhance call.

import { astToMarkdown, type DocumentAST, type FigureBlock } from "./ast";
import { parseDocument } from "./parse";
import { cleanLayout } from "./layout-clean";
import { fillOcrForFigures } from "./vision-ocr";
import { enhanceTablesWithLLM } from "./table-enhance";
import { scoreParseQuality, type QualityResult } from "./quality";
import { semanticChunk, type ChunkOut, type ChunkOptions } from "./chunker";
import { storeImageBytes } from "./image-store";
import { getClipEmbedder, type ClipEmbedder } from "@/lib/ai/clip";
import {
  chunksCreatedTotal,
  documentParseQuality,
  documentParsesTotal,
} from "@/lib/metrics";

export interface ParsePipelineOptions {
  organizationId: string;
  enableOcr?: boolean;
  enableTableEnhance?: boolean;
  enableLayoutClean?: boolean;
  /**
   * When true (default), CLIP-embed extracted FigureBlock images and persist
   * the bytes to uploads/images/. Set to false to skip the image-processing
   * step entirely (used by tests that don't want to load the CLIP model).
   */
  enableImages?: boolean;
  /**
   * Optional override for the CLIP embedder. Tests inject a mock here so
   * they don't need to load the real model. Defaults to `getClipEmbedder()`.
   */
  clipEmbedder?: ClipEmbedder;
  /** Chunk options forwarded into semanticChunk(). */
  chunkOptions?: ChunkOptions;
}

export interface PreparedImage {
  imagePath: string;
  mimeType: string;
  /** CLIP image vector — 512-d, L2-normalized. */
  vector: number[];
  page?: number;
  caption?: string;
  ocrText?: string;
  width?: number;
  height?: number;
  /** Anchor of the FigureBlock the image came from — used by the indexer
   * to link the ImageEmbedding row to its parent text chunk. */
  figureAnchor: string;
}

export interface ParsePipelineResult {
  text: string;
  ast: DocumentAST;
  chunks: ChunkOut[];
  quality: QualityResult;
  /**
   * CLIP-embedded images extracted during this parse. Empty when no figures
   * had imageBuffers attached or when image processing was disabled. Each
   * entry maps 1:1 to an ImageEmbedding row the indexer will create.
   */
  images?: PreparedImage[];
}

export async function parseAndProcess(
  buffer: Buffer,
  mimeType: string,
  fileName: string,
  opts: ParsePipelineOptions,
): Promise<ParsePipelineResult> {
  const {
    organizationId,
    enableOcr = true,
    enableTableEnhance = true,
    enableLayoutClean = true,
    enableImages = true,
    clipEmbedder,
    chunkOptions,
  } = opts;

  // 1) Parse to AST. The facade never throws — it returns a sentinel AST
  //    with errors on the report when a parser blows up.
  let ast: DocumentAST;
  try {
    const parsed = await parseDocument(buffer, mimeType, organizationId, fileName);
    ast = parsed.ast;
    documentParsesTotal.inc({ parser: ast.metadata.parser, result: ast.report.errors.length > 0 ? "error" : "ok" });
  } catch (err) {
    // Belt-and-braces: even if parseDocument throws (shouldn't), produce a
    // zero-block AST so the rest of the pipeline keeps its shape.
    documentParsesTotal.inc({ parser: "unknown", result: "error" });
    ast = {
      metadata: { parser: "txt", parserVersion: "unknown" },
      blocks: [],
      report: {
        parser: "txt",
        parserVersion: "unknown",
        blockCount: 0,
        tableCount: 0,
        listCount: 0,
        figureCount: 0,
        ocrUsed: false,
        parseMs: 0,
        warnings: [],
        errors: [
          { code: "facade_threw", message: err instanceof Error ? err.message : String(err) },
        ],
      },
    };
  }

  // 2) Layout cleanup.
  if (enableLayoutClean) {
    try {
      ast = cleanLayout(ast);
    } catch (err) {
      ast = appendError(ast, "layout_clean_failed", err);
    }
  }

  // 3) Image processing — for every FigureBlock with an attached imageBuffer:
  //   a) store the bytes under uploads/images/<sha256>.<ext>
  //   b) CLIP-embed the bytes → 512-d L2-normalized vector
  //   c) build a PreparedImage entry
  //   d) replace the block's imageBuffer with imageRef = stored path so the
  //      AST is JSON-serializable downstream
  // Wrapped in try/catch — image processing must never fail the parse. We
  // also populate ocrText on each PreparedImage AFTER step 4 (OCR) below by
  // joining on figureAnchor.
  let images: PreparedImage[] = [];
  if (enableImages) {
    try {
      const result = await processImages(ast, clipEmbedder);
      ast = result.ast;
      images = result.images;
      if (result.warnings.length) {
        ast = {
          ...ast,
          report: {
            ...ast.report,
            warnings: [...ast.report.warnings, ...result.warnings],
          },
        };
      }
    } catch (err) {
      ast = appendError(ast, "image_processing_failed", err);
    }
  }

  // 4) Vision OCR (only when there are figures missing ocrText).
  if (enableOcr) {
    const needsOcr = ast.blocks.some(
      (b) =>
        b.kind === "figure" &&
        (!b.ocrText || b.ocrText.trim().length === 0) &&
        (b.imageRef || b.imageBuffer),
    );
    if (needsOcr) {
      try {
        ast = await fillOcrForFigures(ast, organizationId);
      } catch (err) {
        ast = appendError(ast, "ocr_failed", err);
      }
    }
  }

  // 4.5) Backfill PreparedImage.ocrText from FigureBlocks now that OCR has
  // run. Match on figureAnchor → block.anchor. This way the ImageEmbedding
  // row gets the OCR text alongside the CLIP vector.
  if (images.length > 0) {
    const anchorToOcr = new Map<string, string>();
    for (const b of ast.blocks) {
      if (b.kind === "figure" && b.ocrText && b.ocrText.trim()) {
        anchorToOcr.set(b.anchor, b.ocrText);
      }
    }
    images = images.map((img) => {
      const ocr = anchorToOcr.get(img.figureAnchor);
      return ocr ? { ...img, ocrText: ocr } : img;
    });
  }

  // 4) Table enhancement (only when there are candidate tables).
  if (enableTableEnhance) {
    const hasCandidate = ast.blocks.some(
      (b) =>
        b.kind === "table" &&
        ((b.confidence ?? 1) < 0.7 ||
          (b.rows.length > 1 && new Set(b.rows.map((r) => r.length)).size > 1)),
    );
    if (hasCandidate) {
      try {
        ast = await enhanceTablesWithLLM(ast, organizationId);
      } catch (err) {
        ast = appendError(ast, "table_enhance_failed", err);
      }
    }
  }

  // 5) Quality score.
  const quality = scoreParseQuality(ast);
  documentParseQuality.observe(undefined, quality.score);

  // 6) Chunks.
  const chunks = semanticChunk(ast, chunkOptions);
  for (const c of chunks) {
    chunksCreatedTotal.inc({ kind: c.kind });
  }

  // 7) Markdown text.
  const text = astToMarkdown(ast);

  return { text, ast, chunks, quality, images };
}

/**
 * For each FigureBlock with imageBuffer attached: store the bytes via
 * image-store, CLIP-embed them, and build a PreparedImage. Returns a new AST
 * with the imageBuffer cleared and imageRef pointing at the stored image
 * path. Per-image failures are collected as warnings rather than thrown so
 * one bad image doesn't take down the whole document.
 */
async function processImages(
  ast: DocumentAST,
  embedderOverride?: ClipEmbedder,
): Promise<{ ast: DocumentAST; images: PreparedImage[]; warnings: { code: string; message: string; context?: Record<string, unknown> }[] }> {
  const figures: { idx: number; block: FigureBlock }[] = [];
  for (let i = 0; i < ast.blocks.length; i++) {
    const b = ast.blocks[i];
    if (b.kind === "figure" && b.imageBuffer && b.imageBuffer.byteLength > 0) {
      figures.push({ idx: i, block: b });
    }
  }
  if (figures.length === 0) {
    return { ast, images: [], warnings: [] };
  }

  const embedder = embedderOverride ?? getClipEmbedder();
  const blocks = [...ast.blocks];
  const images: PreparedImage[] = [];
  const warnings: { code: string; message: string; context?: Record<string, unknown> }[] = [];

  for (const { idx, block } of figures) {
    try {
      const buffer = block.imageBuffer!;
      // Detect mime when not declared. The store helper falls back to .bin
      // for unknown types; for the common HTML/DOCX cases we sniff the magic
      // bytes so the file gets a meaningful extension.
      const mimeType = sniffMime(buffer);
      const stored = await storeImageBytes({ buffer, mimeType });
      const vector = await embedder.embedImage(buffer);
      images.push({
        imagePath: stored.imagePath,
        mimeType: stored.mimeType,
        vector,
        page: block.page,
        caption: block.caption,
        width: stored.width,
        height: stored.height,
        figureAnchor: block.anchor,
      });
      // Replace imageBuffer with imageRef so the AST is JSON-serializable.
      const updated: FigureBlock = {
        ...block,
        imageRef: stored.imagePath,
        imageBuffer: undefined,
      };
      blocks[idx] = updated;
    } catch (err) {
      warnings.push({
        code: "image_process_failed",
        message: `Image processing failed for figure ${block.anchor}: ${
          err instanceof Error ? err.message : String(err)
        }`,
        context: { anchor: block.anchor },
      });
      // Leave the block as-is; OCR may still try to read the buffer.
    }
  }

  return {
    ast: { ...ast, blocks },
    images,
    warnings,
  };
}

/**
 * Detect MIME from the first few bytes. Covers the formats parsers typically
 * surface (PNG, JPEG, GIF, WebP). Defaults to image/png — image-store falls
 * back to .bin for anything unrecognised so an unknown type still saves.
 */
function sniffMime(buf: Buffer): string {
  if (buf.length >= 4 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47)
    return "image/png";
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff)
    return "image/jpeg";
  if (buf.length >= 6 && buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x38)
    return "image/gif";
  if (
    buf.length >= 12 &&
    buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
    buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50
  )
    return "image/webp";
  return "image/png";
}

function appendError(ast: DocumentAST, code: string, err: unknown): DocumentAST {
  return {
    ...ast,
    report: {
      ...ast.report,
      errors: [
        ...ast.report.errors,
        {
          code,
          message: err instanceof Error ? err.message : String(err),
        },
      ],
    },
  };
}
