// Parse-quality scorer.
//
// Produces a 0..1 score plus a list of contributing reasons (positive and
// negative). The score is persisted on Document.parseQuality and rendered
// in the KB viewer as a "how well did we parse this" indicator. Operators
// also see the histogram via the `document_parse_quality` metric.
//
// Heuristics are intentionally simple and deterministic — no ML, no calls
// out. The score is a *floor*, not a ceiling; downstream code can still
// trust documents below 0.5 but should flag them for review.

import type { DocumentAST } from "./ast";

export interface QualityReason {
  /** Machine-readable code (kebab-style). */
  code: string;
  impact: "positive" | "negative";
  /** Signed weight applied to the score for this reason. */
  weight: number;
  /** Optional human-readable note. */
  detail?: string;
}

export interface QualityResult {
  score: number;
  reasons: QualityReason[];
}

export function scoreParseQuality(ast: DocumentAST): QualityResult {
  const reasons: QualityReason[] = [];
  let score = 0;

  const blocks = ast.blocks;
  const blockCount = blocks.length;
  const report = ast.report;

  if (blockCount > 0) {
    reasons.push({ code: "has_blocks", impact: "positive", weight: 0.2 });
    score += 0.2;
  }

  const hasHeading = blocks.some((b) => b.kind === "heading");
  if (hasHeading) {
    reasons.push({
      code: "headings_present",
      impact: "positive",
      weight: 0.15,
      detail: "Structural headings recovered.",
    });
    score += 0.15;
  }

  const hasTableWithHeaders = blocks.some(
    (b) => b.kind === "table" && (b.headers?.length ?? 0) > 0,
  );
  if (hasTableWithHeaders) {
    reasons.push({
      code: "table_headers",
      impact: "positive",
      weight: 0.15,
      detail: "At least one table had recoverable headers.",
    });
    score += 0.15;
  }

  if ((report.warnings?.length ?? 0) === 0) {
    reasons.push({
      code: "no_warnings",
      impact: "positive",
      weight: 0.1,
    });
    score += 0.1;
  }

  const kinds = new Set(blocks.map((b) => b.kind));
  kinds.delete("paragraph");
  kinds.delete("page_break");
  kinds.delete("hr");
  const extraKinds = Math.min(4, kinds.size);
  if (extraKinds > 0) {
    const weight = 0.05 * extraKinds;
    reasons.push({
      code: "diverse_kinds",
      impact: "positive",
      weight,
      detail: `Discovered ${extraKinds} block kinds beyond paragraph.`,
    });
    score += weight;
  }

  if (report.ocrUsed && (report.ocrConfidence ?? 1) < 0.6) {
    reasons.push({
      code: "low_ocr_confidence",
      impact: "negative",
      weight: -0.15,
      detail: `Mean OCR confidence ${report.ocrConfidence?.toFixed(2) ?? "n/a"} is below 0.6.`,
    });
    score -= 0.15;
  }

  const errorCount = report.errors?.length ?? 0;
  if (errorCount > 0) {
    const penalty = Math.max(-0.3, -0.1 * errorCount);
    reasons.push({
      code: "parse_errors",
      impact: "negative",
      weight: penalty,
      detail: `${errorCount} soft error(s) reported by parser.`,
    });
    score += penalty;
  }

  // Entire-doc-is-one-paragraph penalty: structure recovery failed.
  if (
    blockCount === 1 &&
    blocks[0].kind === "paragraph"
  ) {
    reasons.push({
      code: "single_paragraph_doc",
      impact: "negative",
      weight: -0.1,
      detail: "Entire document collapsed to a single paragraph (no structure recovered).",
    });
    score -= 0.1;
  }

  // Clamp.
  if (score < 0) score = 0;
  if (score > 1) score = 1;

  return { score, reasons };
}
