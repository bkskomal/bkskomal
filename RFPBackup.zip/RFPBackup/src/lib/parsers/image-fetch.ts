// Shared figure-image hydration.
//
// Format parsers emit FigureBlock entries with `imageRef` set to either a
// `data:` URL, an `http(s)` URL, or (in the DOCX path) a synthetic data URL
// produced by the mammoth image callback. This module walks the AST after
// parsing and fills `imageBuffer` on each FigureBlock so the pipeline's
// image-processing step has the bytes to hand to CLIP + image-store.
//
// HTTP fetching is opt-in (controlled by the parser) and bounded:
//   - 5 second timeout per image
//   - 5 MB cap on response body
//   - Failures appended as warnings, never throw
//
// We also cap the total number of images hydrated per document to keep large
// pages from blowing through bandwidth. Skipped images keep their `imageRef`
// so the FigureBlock is still present in the AST — just without bytes.

import { Agent, fetch as undiciFetch } from "undici";
import type { Block, FigureBlock, ParseWarning } from "./ast";

const DEFAULT_FETCH_TIMEOUT_MS = 15_000;
const DEFAULT_MAX_BYTES = 5 * 1024 * 1024;
// Per-doc cap on image hydration. Bumped from 20 → 60 in 2026-05 so a
// content-rich landing page (godhascome.com has 22 in the hero alone)
// doesn't get silently truncated. The URL ingest can raise this further
// via ParseOptions.maxImagesPerDoc when the user explicitly opts in.
const DEFAULT_MAX_IMAGES = 60;

// Same TLS-chain-error set as the URL scraper. Many sites (especially
// Cloudflare-fronted ones, or anything behind a corporate MITM proxy on
// Windows) present an incomplete cert chain that Node's bundled CA store
// can't verify. We retry once with rejectUnauthorized=false rather than
// silently dropping every image.
const TLS_CHAIN_ERROR_CODES = new Set([
  "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
  "UNABLE_TO_GET_ISSUER_CERT",
  "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
  "SELF_SIGNED_CERT_IN_CHAIN",
  "DEPTH_ZERO_SELF_SIGNED_CERT",
  "CERT_HAS_EXPIRED",
  "CERT_NOT_YET_VALID",
  "ERR_TLS_CERT_ALTNAME_INVALID",
]);

function isTlsChainError(err: unknown): boolean {
  let cur: unknown = err;
  while (cur instanceof Error) {
    const code = (cur as Error & { code?: string }).code;
    if (code && TLS_CHAIN_ERROR_CODES.has(code)) return true;
    const msg = cur.message ?? "";
    if (
      /unable to verify the first certificate/i.test(msg) ||
      /self[- ]signed certificate/i.test(msg) ||
      /certificate has expired/i.test(msg) ||
      /unable to get local issuer certificate/i.test(msg)
    ) {
      return true;
    }
    cur = (cur as Error & { cause?: unknown }).cause;
  }
  return false;
}

let _insecureAgent: Agent | undefined;
function insecureFetch(): typeof fetch {
  if (!_insecureAgent) {
    _insecureAgent = new Agent({ connect: { rejectUnauthorized: false } });
  }
  const agent = _insecureAgent;
  return ((input: string | URL | Request, init?: RequestInit) => {
    return undiciFetch(typeof input === "string" ? input : input.toString(), {
      ...(init as Parameters<typeof undiciFetch>[1]),
      dispatcher: agent,
    });
  }) as unknown as typeof fetch;
}

export interface HydrateOptions {
  /** When true, fetch http(s) image URLs. Default false (security-first). */
  allowFetch?: boolean;
  /** Max images to hydrate per document. */
  maxImages?: number;
  /** Per-image fetch timeout. */
  fetchTimeoutMs?: number;
  /** Per-image byte cap. */
  maxBytesPerImage?: number;
  /** Optional fetch override — used by tests. */
  fetchFn?: typeof fetch;
}

export interface HydrateResult {
  blocks: Block[];
  warnings: ParseWarning[];
  /** Number of figures that ended up with imageBuffer populated. */
  hydrated: number;
}

/**
 * Decode a data: URL into bytes + mime. Returns null if the URL is malformed
 * or not base64-encoded.
 */
export function decodeDataUrl(
  url: string,
): { buffer: Buffer; mimeType: string } | null {
  if (!url.startsWith("data:")) return null;
  const commaIdx = url.indexOf(",");
  if (commaIdx < 0) return null;
  const meta = url.slice(5, commaIdx); // strip "data:"
  const payload = url.slice(commaIdx + 1);
  // meta looks like "image/png;base64" or "image/svg+xml" (no encoding flag).
  const parts = meta.split(";");
  const mimeType = parts[0] || "application/octet-stream";
  const isBase64 = parts.includes("base64");
  try {
    const buffer = isBase64
      ? Buffer.from(payload, "base64")
      : Buffer.from(decodeURIComponent(payload), "utf8");
    if (buffer.byteLength === 0) return null;
    return { buffer, mimeType };
  } catch {
    return null;
  }
}

interface FetchedImage {
  buffer: Buffer;
  mimeType: string;
}

async function fetchHttpImage(
  url: string,
  opts: { timeoutMs: number; maxBytes: number; fetchFn: typeof fetch },
): Promise<FetchedImage> {
  async function once(fetcher: typeof fetch): Promise<FetchedImage> {
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), opts.timeoutMs);
    try {
      const res = await fetcher(url, {
        signal: controller.signal,
        // Send a realistic Accept header — some CDNs (Cloudflare in
        // particular) 403 on requests without one.
        headers: { Accept: "image/avif,image/webp,image/*,*/*;q=0.8" },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const ct = res.headers.get("content-type") ?? "application/octet-stream";
      const ab = await res.arrayBuffer();
      if (ab.byteLength > opts.maxBytes) {
        throw new Error(`image too large: ${ab.byteLength} bytes > ${opts.maxBytes}`);
      }
      return { buffer: Buffer.from(ab), mimeType: ct.split(";")[0].trim() };
    } finally {
      clearTimeout(t);
    }
  }
  try {
    return await once(opts.fetchFn);
  } catch (err) {
    if (isTlsChainError(err)) {
      return await once(insecureFetch());
    }
    throw err;
  }
}

/**
 * Hydrate FigureBlock.imageBuffer from imageRef where possible. Pure on the
 * input (returns a new blocks array); only mutates the new copies.
 */
export async function hydrateFigureImages(
  blocks: Block[],
  opts: HydrateOptions = {},
): Promise<HydrateResult> {
  const allowFetch = opts.allowFetch ?? false;
  const maxImages = opts.maxImages ?? DEFAULT_MAX_IMAGES;
  const fetchTimeoutMs = opts.fetchTimeoutMs ?? DEFAULT_FETCH_TIMEOUT_MS;
  const maxBytesPerImage = opts.maxBytesPerImage ?? DEFAULT_MAX_BYTES;
  const fetchFn = opts.fetchFn ?? (globalThis.fetch as typeof fetch);

  const warnings: ParseWarning[] = [];
  const out: Block[] = blocks.slice();
  let hydrated = 0;

  // Walk in document order so the cap drops trailing images first (more
  // likely to be footers/decoration).
  for (let i = 0; i < out.length; i++) {
    const b = out[i];
    if (b.kind !== "figure") continue;
    const figure = b as FigureBlock;
    if (figure.imageBuffer) continue; // already hydrated by the parser
    if (!figure.imageRef) continue;

    if (hydrated >= maxImages) {
      warnings.push({
        code: "image_cap_reached",
        message: `Skipped figure ${figure.anchor}; per-doc image cap (${maxImages}) reached.`,
        context: { anchor: figure.anchor, cap: maxImages },
      });
      continue;
    }

    const ref = figure.imageRef;

    // Inline data URL — decode synchronously.
    if (ref.startsWith("data:")) {
      const decoded = decodeDataUrl(ref);
      if (!decoded) {
        warnings.push({
          code: "data_url_decode_failed",
          message: `Could not decode data: URL for figure ${figure.anchor}.`,
          context: { anchor: figure.anchor },
        });
        continue;
      }
      out[i] = { ...figure, imageBuffer: decoded.buffer, imageRef: ref };
      hydrated++;
      continue;
    }

    // Remote URL — fetch when allowed.
    if (ref.startsWith("http://") || ref.startsWith("https://")) {
      if (!allowFetch || !fetchFn) {
        // Quietly leave the imageRef in place; not a warning — the parser
        // chose not to enable network fetches.
        continue;
      }
      try {
        const fetched = await fetchHttpImage(ref, {
          timeoutMs: fetchTimeoutMs,
          maxBytes: maxBytesPerImage,
          fetchFn,
        });
        out[i] = { ...figure, imageBuffer: fetched.buffer, imageRef: ref };
        hydrated++;
      } catch (err) {
        warnings.push({
          code: "image_fetch_failed",
          message: `Failed to fetch image for figure ${figure.anchor}: ${
            err instanceof Error ? err.message : String(err)
          }`,
          context: { anchor: figure.anchor, url: ref },
        });
      }
      continue;
    }

    // Anything else (SVG inline serialized, file: URL, relative path) — skip
    // with a warning so consumers know we couldn't hydrate it.
    warnings.push({
      code: "image_ref_unsupported",
      message: `Cannot hydrate figure ${figure.anchor}: unsupported image ref scheme.`,
      context: { anchor: figure.anchor, ref },
    });
  }

  return { blocks: out, warnings, hydrated };
}
