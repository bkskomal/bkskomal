// Shared DOM → Block[] walker.
//
// Used by html-parser.ts (cheerio output) and docx-parser.ts (mammoth HTML
// output). Operates against a minimal DOM-shaped API so we can run it against
// either cheerio nodes or jsdom nodes by adapting a thin wrapper.
//
// We deliberately reimplement just enough DOM here to stay light and isomorphic
// between cheerio and jsdom — both libraries expose `tagName`, `attribs`,
// `children`, and `data`/`text` in slightly different shapes.

import {
  anchorFor,
  type Block,
  type ListItem,
  type ParseWarning,
} from "./ast";
import { tableToMarkdown } from "./table-md";

// Minimal node abstraction. Adapters fill these in from cheerio / jsdom.
export interface DomNode {
  type: "element" | "text" | "other";
  /** Lowercase tag name when type === "element". */
  tag?: string;
  /** Raw text content when type === "text". */
  text?: string;
  /** Attribute bag, lowercase keys. */
  attribs?: Record<string, string>;
  children?: DomNode[];
}

const SKIP_TAGS = new Set([
  "script",
  "style",
  "noscript",
  "nav",
  "header",
  "footer",
  "aside",
  "form",
  "iframe",
  "svg",
  "canvas",
]);

const HEADING_TAGS: Record<string, number> = {
  h1: 1,
  h2: 2,
  h3: 3,
  h4: 4,
  h5: 5,
  h6: 6,
};

const INLINE_TAGS = new Set([
  "a",
  "abbr",
  "b",
  "br",
  "cite",
  "code",
  "em",
  "i",
  "kbd",
  "mark",
  "q",
  "s",
  "samp",
  "small",
  "span",
  "strong",
  "sub",
  "sup",
  "time",
  "u",
  "var",
]);

export interface WalkResult {
  blocks: Block[];
  warnings: ParseWarning[];
  /** Best-effort detected title — first H1 text. */
  detectedTitle?: string;
}

export interface WalkOptions {
  /**
   * When true (default), skip non-content chrome tags (nav, header, footer,
   * aside, script, style). HTML parser sets this; docx parser passes false
   * since mammoth never emits those.
   */
  skipChrome?: boolean;
}

class Walker {
  blocks: Block[] = [];
  warnings: ParseWarning[] = [];
  detectedTitle: string | undefined;
  private sectionStack: { level: number; text: string }[] = [];
  private ordinal = 0;
  private skipChrome: boolean;

  constructor(opts: WalkOptions) {
    this.skipChrome = opts.skipChrome ?? true;
  }

  walk(node: DomNode): void {
    if (!node) return;
    if (node.type === "text") return; // top-level text is ignored
    if (node.type === "other") {
      if (node.children) for (const c of node.children) this.walk(c);
      return;
    }
    const tag = node.tag ?? "";

    if (this.skipChrome && SKIP_TAGS.has(tag)) return;

    if (HEADING_TAGS[tag]) {
      const level = HEADING_TAGS[tag];
      const text = inlineText(node).trim();
      if (!text) return;
      // Update section path: pop deeper-or-equal levels, then push this one.
      while (
        this.sectionStack.length > 0 &&
        this.sectionStack[this.sectionStack.length - 1].level >= level
      ) {
        this.sectionStack.pop();
      }
      this.sectionStack.push({ level, text });
      const section = this.section();
      this.blocks.push({
        kind: "heading",
        level,
        text,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      if (level === 1 && !this.detectedTitle) {
        this.detectedTitle = text;
      }
      return;
    }

    if (tag === "p") {
      const text = inlineText(node).trim();
      if (!text) return;
      const section = this.section();
      this.blocks.push({
        kind: "paragraph",
        text,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    if (tag === "ul" || tag === "ol") {
      const items = collectListItems(node);
      if (items.length === 0) return;
      const section = this.section();
      this.blocks.push({
        kind: "list",
        ordered: tag === "ol",
        items,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    if (tag === "table") {
      const table = extractTable(node);
      if (!table) return;
      const section = this.section();
      this.blocks.push({
        kind: "table",
        headers: table.headers,
        rows: table.rows,
        markdown: tableToMarkdown(table.headers, table.rows),
        caption: table.caption,
        section,
        anchor: anchorFor(section, this.ordinal++),
        confidence: 0.9,
      });
      return;
    }

    if (tag === "pre") {
      // <pre><code class="language-x">...</code></pre>
      const codeNode = (node.children ?? []).find(
        (c) => c.type === "element" && c.tag === "code",
      );
      const target = codeNode ?? node;
      let language: string | undefined;
      const cls = codeNode?.attribs?.class ?? node.attribs?.class ?? "";
      const m = cls.match(/language-([\w-]+)/);
      if (m) language = m[1];
      const code = collectText(target).replace(/\n$/, "");
      if (!code.trim()) return;
      const section = this.section();
      this.blocks.push({
        kind: "code",
        code,
        language,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    if (tag === "code" && !isInsidePre()) {
      // Standalone <code> block (not wrapped in <pre>) — treat as code block.
      const code = collectText(node);
      if (!code.trim()) return;
      const section = this.section();
      this.blocks.push({
        kind: "code",
        code,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    if (tag === "blockquote") {
      const text = inlineText(node).trim();
      if (!text) return;
      const section = this.section();
      this.blocks.push({
        kind: "quote",
        text,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    if (tag === "img") {
      const caption = node.attribs?.alt;
      const imageRef = node.attribs?.src;
      const section = this.section();
      this.blocks.push({
        kind: "figure",
        caption: caption || undefined,
        imageRef: imageRef || undefined,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    if (tag === "figure") {
      // Figure with optional <img> and <figcaption>.
      const img = findFirstByTag(node, "img");
      const caption =
        inlineText(findFirstByTag(node, "figcaption")).trim() ||
        img?.attribs?.alt ||
        undefined;
      const imageRef = img?.attribs?.src;
      const section = this.section();
      this.blocks.push({
        kind: "figure",
        caption,
        imageRef: imageRef || undefined,
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    if (tag === "hr") {
      const section = this.section();
      this.blocks.push({
        kind: "hr",
        section,
        anchor: anchorFor(section, this.ordinal++),
      });
      return;
    }

    // Generic container — recurse into children.
    if (node.children) {
      for (const c of node.children) this.walk(c);
    }
  }

  private section(): string | undefined {
    if (this.sectionStack.length === 0) return undefined;
    return this.sectionStack.map((s) => s.text).join(" / ");
  }
}

// We don't actually track ancestors above, but a free <code> inside a <pre>
// is already short-circuited by the <pre> branch. Keep this as a guard noop.
function isInsidePre(): boolean {
  return false;
}

export function walkDom(root: DomNode, opts: WalkOptions = {}): WalkResult {
  const w = new Walker(opts);
  // The root itself may be an element (e.g. <body>) — walk children when so.
  if (root.type === "element" && root.children) {
    for (const c of root.children) w.walk(c);
  } else {
    w.walk(root);
  }
  return { blocks: w.blocks, warnings: w.warnings, detectedTitle: w.detectedTitle };
}

// ------- helpers ---------------------------------------------------------

function inlineText(node: DomNode | undefined): string {
  if (!node) return "";
  if (node.type === "text") return node.text ?? "";
  const tag = node.tag ?? "";
  // Stop at block-level descendants — they get their own blocks.
  if (
    HEADING_TAGS[tag] ||
    tag === "p" ||
    tag === "ul" ||
    tag === "ol" ||
    tag === "table" ||
    tag === "pre" ||
    tag === "blockquote" ||
    tag === "figure"
  ) {
    if (node.children) return node.children.map(inlineText).join("");
    return "";
  }

  // Inline formatting -> emit lightweight Markdown.
  const inner = (node.children ?? []).map(inlineText).join("");
  switch (tag) {
    case "strong":
    case "b":
      return `**${inner}**`;
    case "em":
    case "i":
      return `*${inner}*`;
    case "code":
      return `\`${inner}\``;
    case "br":
      return "\n";
    case "a": {
      const href = node.attribs?.href;
      if (!href) return inner;
      return `[${inner}](${href})`;
    }
    default:
      return inner;
  }
}

function collectText(node: DomNode | undefined): string {
  if (!node) return "";
  if (node.type === "text") return node.text ?? "";
  return (node.children ?? []).map(collectText).join("");
}

function collectListItems(listNode: DomNode): ListItem[] {
  const items: ListItem[] = [];
  for (const c of listNode.children ?? []) {
    if (c.type !== "element" || c.tag !== "li") continue;
    // li may contain text + optional nested <ul>/<ol>.
    const childParts: string[] = [];
    const children: ListItem[] = [];
    for (const ic of c.children ?? []) {
      if (ic.type === "element" && (ic.tag === "ul" || ic.tag === "ol")) {
        for (const nested of collectListItems(ic)) children.push(nested);
      } else {
        childParts.push(inlineText(ic));
      }
    }
    const text = childParts.join("").trim();
    if (!text && children.length === 0) continue;
    items.push({ text, children: children.length ? children : undefined });
  }
  return items;
}

interface ExtractedTable {
  headers?: string[];
  rows: string[][];
  caption?: string;
}

function extractTable(tableNode: DomNode): ExtractedTable | null {
  let caption: string | undefined;
  let headers: string[] | undefined;
  const rows: string[][] = [];

  const allRows: { isHeader: boolean; cells: string[] }[] = [];

  const visit = (n: DomNode, parentTag?: string) => {
    if (n.type !== "element") return;
    const tag = n.tag ?? "";
    if (tag === "caption") {
      caption = inlineText(n).trim() || undefined;
      return;
    }
    if (tag === "tr") {
      const cells: string[] = [];
      let isHeader = parentTag === "thead";
      for (const cell of n.children ?? []) {
        if (cell.type !== "element") continue;
        if (cell.tag === "th") {
          isHeader = true;
          cells.push(inlineText(cell).trim());
        } else if (cell.tag === "td") {
          cells.push(inlineText(cell).trim());
        }
      }
      if (cells.length > 0) allRows.push({ isHeader, cells });
      return;
    }
    for (const c of n.children ?? []) visit(c, tag);
  };

  visit(tableNode);

  if (allRows.length === 0) return null;

  if (allRows[0].isHeader) {
    headers = allRows[0].cells;
    for (let i = 1; i < allRows.length; i++) rows.push(allRows[i].cells);
  } else {
    // Heuristic: when first row looks like header (all cells short, no numbers
    // dominant), treat it as such. Otherwise leave headers undefined.
    const first = allRows[0].cells;
    const looksLikeHeader =
      first.length > 1 &&
      first.every((c) => c.length > 0 && c.length < 60) &&
      first.filter((c) => /^-?\d/.test(c)).length < first.length / 2;
    if (looksLikeHeader) {
      headers = first;
      for (let i = 1; i < allRows.length; i++) rows.push(allRows[i].cells);
    } else {
      for (const r of allRows) rows.push(r.cells);
    }
  }

  return { headers, rows, caption };
}

function findFirstByTag(node: DomNode | undefined, tag: string): DomNode | undefined {
  if (!node) return undefined;
  if (node.type === "element" && node.tag === tag) return node;
  for (const c of node.children ?? []) {
    const r = findFirstByTag(c, tag);
    if (r) return r;
  }
  return undefined;
}

// ---- adapters -----------------------------------------------------------

/** Convert a cheerio AnyNode tree to a DomNode tree. */
export function cheerioToDom(node: unknown): DomNode {
  // Cheerio's node shapes follow domhandler: type ∈ {tag, text, root, comment, script, style, ...},
  // tagName/name, attribs, children, data.
  const n = node as Record<string, unknown> & {
    type?: string;
    name?: string;
    data?: string;
    attribs?: Record<string, string>;
    children?: unknown[];
  };
  const type = n.type;
  if (type === "text") {
    return { type: "text", text: typeof n.data === "string" ? n.data : "" };
  }
  if (type === "tag" || type === "script" || type === "style" || type === "root") {
    const tag = typeof n.name === "string" ? n.name.toLowerCase() : undefined;
    return {
      type: "element",
      tag: tag ?? (type === "root" ? "root" : undefined),
      attribs: n.attribs ?? {},
      children: (n.children ?? []).map((c) => cheerioToDom(c)),
    };
  }
  // comment, directive, doctype...
  return { type: "other" };
}

/** Convert a jsdom DOM Node to a DomNode tree. */
export function jsdomToDom(node: Node): DomNode {
  // 1 = ELEMENT_NODE, 3 = TEXT_NODE, 9 = DOCUMENT_NODE, 11 = DOCUMENT_FRAGMENT.
  const nt = node.nodeType;
  if (nt === 3) {
    return { type: "text", text: node.textContent ?? "" };
  }
  if (nt === 1 || nt === 9 || nt === 11) {
    const el = node as Element;
    const tag = (el.tagName ?? "").toLowerCase() || undefined;
    const attribs: Record<string, string> = {};
    if ((el as Element).attributes) {
      for (const a of Array.from((el as Element).attributes ?? [])) {
        attribs[a.name.toLowerCase()] = a.value;
      }
    }
    const children: DomNode[] = [];
    for (const c of Array.from(node.childNodes)) {
      children.push(jsdomToDom(c));
    }
    return { type: "element", tag, attribs, children };
  }
  return { type: "other" };
}
