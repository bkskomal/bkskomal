// Boundary-aware semantic chunker.
//
// Replaces the legacy character-window chunker in src/lib/ai/chunking.ts
// for documents that have gone through the AST parser pipeline. Operates
// on the block list so chunks honour the document's natural structure:
//
//   * Headings always start a new chunk and never split.
//   * Tables are atomic; only if they overflow `maxSize` do we split by
//     rows while replicating the header row in every fragment.
//   * Lists never split mid-item; consecutive items pack into a chunk
//     until the size target is hit.
//   * Code blocks and figures-with-OCR are emitted as their own chunks.
//   * Paragraphs concatenate until size target; oversized paragraphs are
//     split at sentence boundaries with character overlap.
//
// The chunker also tracks the running heading path so every chunk carries
// a `section` string like "1 / Security / Encryption" — useful for
// citations and for the KB viewer's structure tree.

import type {
  Block,
  CodeBlock,
  DocumentAST,
  FigureBlock,
  HeadingBlock,
  ListBlock,
  ListItem,
  ParagraphBlock,
  QuoteBlock,
  TableBlock,
  FootnoteBlock,
} from "./ast";
import { anchorFor } from "./ast";

export interface ChunkOut {
  content: string;
  ordinal: number;
  page?: number;
  section?: string;
  /** Matches one of Block.kind. */
  kind: string;
  /** Stable anchor — derived from first block in the chunk. */
  anchor: string;
}

export interface ChunkOptions {
  /** Target chunk size in characters (~tokens × 4). */
  targetSize?: number;
  /** Maximum allowed before forced split. */
  maxSize?: number;
  /** Minimum chunk size; smaller chunks get merged with neighbor. */
  minSize?: number;
  /** Character overlap at chunk boundaries (helps retrieval recall). */
  overlap?: number;
}

const DEFAULTS: Required<ChunkOptions> = {
  targetSize: 1200,
  maxSize: 1800,
  minSize: 200,
  overlap: 100,
};

interface PendingChunk {
  /** Block kinds contributing content; used to compute dominant kind. */
  kindsCounter: Map<string, number>;
  parts: string[];
  page?: number;
  section?: string;
  anchor?: string;
  // Track current size cheaply.
  size: number;
}

function newPending(): PendingChunk {
  return { kindsCounter: new Map(), parts: [], size: 0 };
}

export function semanticChunk(ast: DocumentAST, opts?: ChunkOptions): ChunkOut[] {
  const o = { ...DEFAULTS, ...(opts ?? {}) };
  const out: ChunkOut[] = [];

  // Running heading stack so we can derive the slash-joined section path.
  // For an H2 we replace position 1 and discard 2+ etc.
  const headingStack: string[] = [];
  let pending = newPending();

  const flush = (): void => {
    const content = pending.parts.join("\n\n").trim();
    if (content.length === 0) {
      pending = newPending();
      return;
    }
    const kind = dominantKind(pending.kindsCounter);
    out.push({
      content,
      ordinal: out.length,
      page: pending.page,
      section: pending.section,
      kind,
      anchor: pending.anchor && pending.anchor.length > 0
        ? pending.anchor
        : anchorFor(pending.section, out.length),
    });
    pending = newPending();
  };

  const append = (block: Block, text: string, section: string | undefined): void => {
    if (text.length === 0) return;
    if (pending.parts.length === 0) {
      pending.page = block.page;
      pending.section = section ?? block.section;
      pending.anchor = block.anchor;
    }
    pending.parts.push(text);
    pending.size += text.length + 2;
    pending.kindsCounter.set(block.kind, (pending.kindsCounter.get(block.kind) ?? 0) + 1);
  };

  for (const block of ast.blocks) {
    if (block.kind === "page_break" || block.kind === "hr") continue;

    if (block.kind === "heading") {
      // Headings start a new chunk. Flush whatever is buffered, then update
      // the heading stack, then emit the heading on its own (so retrieval
      // can return the section title as a standalone unit).
      flush();
      updateHeadingStack(headingStack, block as HeadingBlock);
      const section = headingPath(headingStack);
      append(block, formatHeading(block as HeadingBlock), section);
      flush();
      continue;
    }

    const section = block.section ?? headingPath(headingStack);

    if (block.kind === "table") {
      // Tables are their own chunk. If oversized, split by rows preserving
      // the header in every fragment.
      flush();
      const table = block as TableBlock;
      if (table.markdown.length <= o.maxSize || table.rows.length <= 1) {
        emitStandalone(out, table, table.markdown, "table", section);
      } else {
        const fragments = splitTable(table, o.maxSize);
        for (const frag of fragments) {
          emitStandalone(out, table, frag, "table", section);
        }
      }
      continue;
    }

    if (block.kind === "code") {
      flush();
      const code = block as CodeBlock;
      emitStandalone(out, code, renderCode(code), "code", section);
      continue;
    }

    if (block.kind === "figure") {
      const fig = block as FigureBlock;
      if (fig.ocrText && fig.ocrText.trim().length > 0) {
        flush();
        emitStandalone(out, fig, renderFigure(fig), "figure", section);
      }
      // Figures without OCR text don't contribute to chunks.
      continue;
    }

    if (block.kind === "list") {
      const list = block as ListBlock;
      // Items group together; pack until target size; never split mid-item.
      const itemTexts = list.items.map((it, i) => renderListItem(list, it, i, 0));
      for (const txt of itemTexts) {
        if (pending.size + txt.length > o.targetSize && pending.parts.length > 0) {
          flush();
        }
        append(list, txt, section);
      }
      continue;
    }

    if (block.kind === "quote") {
      const q = block as QuoteBlock;
      const text = `> ${q.text}`;
      if (pending.size + text.length > o.targetSize && pending.parts.length > 0) flush();
      append(q, text, section);
      continue;
    }

    if (block.kind === "footnote") {
      const f = block as FootnoteBlock;
      const text = `[^${f.ref}]: ${f.text}`;
      if (pending.size + text.length > o.targetSize && pending.parts.length > 0) flush();
      append(f, text, section);
      continue;
    }

    if (block.kind === "paragraph") {
      const para = block as ParagraphBlock;
      const text = para.text;
      if (text.length === 0) continue;

      if (text.length > o.maxSize) {
        // Oversize paragraph: flush, then split at sentence boundaries with
        // overlap. Each fragment becomes its own chunk.
        flush();
        const pieces = splitBySentence(text, o.maxSize, o.overlap);
        for (const piece of pieces) {
          emitStandalone(out, para, piece, "paragraph", section);
        }
        continue;
      }

      if (pending.size + text.length > o.targetSize && pending.parts.length > 0) {
        flush();
      }
      append(para, text, section);
      continue;
    }
  }

  flush();

  // Final pass: merge tiny adjacent chunks. We never merge across a heading
  // chunk (kind === "heading") because that would lose the structural cue,
  // and we cap merges at maxSize.
  return mergeSmallChunks(out, o.minSize, o.maxSize);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function emitStandalone(
  out: ChunkOut[],
  block: Block,
  content: string,
  kind: string,
  section: string | undefined,
): void {
  const trimmed = content.trim();
  if (trimmed.length === 0) return;
  out.push({
    content: trimmed,
    ordinal: out.length,
    page: block.page,
    section: section ?? block.section,
    kind,
    anchor: block.anchor,
  });
}

function updateHeadingStack(stack: string[], block: HeadingBlock): void {
  const level = Math.max(1, Math.min(6, block.level));
  // Trim to level-1 entries, then push.
  stack.length = level - 1;
  stack.push(block.text.trim());
}

function headingPath(stack: string[]): string | undefined {
  const filtered = stack.filter((s) => s.length > 0);
  return filtered.length === 0 ? undefined : filtered.join(" / ");
}

function formatHeading(b: HeadingBlock): string {
  const hashes = "#".repeat(Math.min(6, Math.max(1, b.level)));
  return `${hashes} ${b.text}`;
}

function renderCode(b: CodeBlock): string {
  return "```" + (b.language ?? "") + "\n" + b.code + "\n```";
}

function renderFigure(b: FigureBlock): string {
  const cap = b.caption ? `*Figure: ${b.caption}*\n\n` : "";
  return `${cap}${b.ocrText ?? ""}`.trim();
}

function renderListItem(list: ListBlock, item: ListItem, index: number, indent: number): string {
  const bullet = list.ordered ? `${index + 1}.` : "-";
  const prefix = " ".repeat(indent * 2) + bullet + " ";
  let out = prefix + item.text;
  if (item.children?.length) {
    item.children.forEach((c, j) => {
      out += "\n" + renderListItem({ ...list, ordered: false }, c, j, indent + 1);
    });
  }
  return out;
}

function dominantKind(counts: Map<string, number>): string {
  if (counts.size === 0) return "paragraph";
  let best = "paragraph";
  let bestN = -1;
  for (const [k, n] of counts) {
    if (n > bestN) {
      best = k;
      bestN = n;
    }
  }
  return best;
}

function splitTable(table: TableBlock, maxSize: number): string[] {
  const lines = table.markdown.split("\n");
  // Find header lines: first two pipe rows.
  let headerEnd = 0;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith("|")) {
      headerEnd = i;
      if (i + 1 < lines.length && lines[i + 1].includes("---")) {
        headerEnd = i + 1;
        break;
      }
    }
  }
  const header = lines.slice(0, headerEnd + 1).join("\n");
  const bodyLines = lines.slice(headerEnd + 1);

  const fragments: string[] = [];
  let current: string[] = [];
  let currentSize = header.length;
  for (const row of bodyLines) {
    if (currentSize + row.length + 1 > maxSize && current.length > 0) {
      fragments.push(header + "\n" + current.join("\n"));
      current = [row];
      currentSize = header.length + row.length + 1;
    } else {
      current.push(row);
      currentSize += row.length + 1;
    }
  }
  if (current.length > 0) {
    fragments.push(header + "\n" + current.join("\n"));
  }
  return fragments.length > 0 ? fragments : [table.markdown];
}

function splitBySentence(text: string, maxSize: number, overlap: number): string[] {
  // Split into sentences with a permissive regex; punctuation-only splits
  // won't catch every case but are deterministic and dependency-free. The
  // chunker pads each fragment with `overlap` chars of context from the
  // previous fragment to help retrieval recall on boundary cases.
  const sentences = text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (sentences.length === 0) return [text];

  const out: string[] = [];
  let buf: string[] = [];
  let size = 0;

  const flush = () => {
    if (buf.length === 0) return;
    const piece = buf.join(" ");
    if (out.length > 0 && overlap > 0) {
      const prev = out[out.length - 1];
      const tail = prev.slice(Math.max(0, prev.length - overlap));
      out.push(tail + " " + piece);
    } else {
      out.push(piece);
    }
    buf = [];
    size = 0;
  };

  for (const s of sentences) {
    if (size + s.length + 1 > maxSize && buf.length > 0) flush();
    buf.push(s);
    size += s.length + 1;
  }
  flush();
  return out.length > 0 ? out : [text];
}

function mergeSmallChunks(chunks: ChunkOut[], minSize: number, maxSize: number): ChunkOut[] {
  if (chunks.length <= 1) return chunks;
  const out: ChunkOut[] = [];
  for (const c of chunks) {
    const last = out[out.length - 1];
    // Headings & tables stay atomic — never merge them with a neighbor and
    // never absorb the next chunk into a heading.
    const cIsStructural = c.kind === "heading" || c.kind === "table" || c.kind === "code" || c.kind === "figure";
    const lastIsStructural =
      last && (last.kind === "heading" || last.kind === "table" || last.kind === "code" || last.kind === "figure");
    if (
      last &&
      !cIsStructural &&
      !lastIsStructural &&
      last.content.length < minSize &&
      last.content.length + c.content.length + 2 <= maxSize &&
      last.section === c.section
    ) {
      last.content = `${last.content}\n\n${c.content}`;
      // Kind: paragraph wins when mixing; otherwise keep the last.
      if (c.kind !== last.kind) last.kind = "paragraph";
      continue;
    }
    out.push({ ...c });
  }
  // Re-number ordinals so they stay contiguous after merging.
  for (let i = 0; i < out.length; i++) out[i].ordinal = i;
  return out;
}
