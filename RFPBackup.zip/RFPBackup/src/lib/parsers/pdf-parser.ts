// PDF parser — pdfjs-dist (Mozilla PDF.js), layout-aware.
//
// What we extract per page:
//   • Text items with positions + font sizes via getTextContent().
//   • Cluster items into lines by Y coordinate.
//   • Cluster lines into paragraphs/headings by font-size + line spacing.
//   • Detect tables heuristically: ≥2 consecutive lines whose tokens align on
//     the same x-coordinates (within a tolerance).
//   • Strip headers/footers by detecting repeating top/bottom text across
//     pages.
//   • Emit PageBreak between pages.
//   • If a page has NO text items (image-only / scanned), emit a FigureBlock
//     so P2 can run vision-LLM OCR.

import {
  anchorFor,
  detectLanguage,
  type DocumentAST,
  type DocumentParser,
  type FigureBlock,
  type ParseOptions,
  type ParseReport,
  type ParseWarning,
  type Block,
  type HeadingBlock,
} from "./ast";
import { tableToMarkdown } from "./table-md";

export const PDF_PARSER_VERSION = "pdf-2026-05-01";

const PDF_MAX_EMBEDDED_IMAGES = 20;

interface RawItem {
  text: string;
  /** Page-space x (left of bbox). */
  x: number;
  /** Page-space y (baseline). */
  y: number;
  /** Item width. */
  width: number;
  /** Item height / font size proxy. */
  height: number;
  /** Font size — derived from transform[0] (uniform scaling assumption). */
  fontSize: number;
}

interface RawLine {
  items: RawItem[];
  /** Mean Y across items. */
  y: number;
  /** Text joined with single spaces. */
  text: string;
  /** Dominant font size (max across items, since headings often have mixed). */
  fontSize: number;
  /** Smallest x of any item — used for table column alignment. */
  minX: number;
  /** Sorted (by x) array of (x, text) tokens — used for column detection. */
  tokens: { x: number; text: string }[];
}

export const pdfParser: DocumentParser = {
  id: "pdf",
  version: PDF_PARSER_VERSION,
  canParse(buffer, opts) {
    if (opts.mimeType === "application/pdf") return true;
    if (opts.fileName?.match(/\.pdf$/i)) return true;
    return buffer.slice(0, 5).toString() === "%PDF-";
  },
  async parse(buffer, opts): Promise<DocumentAST> {
    return parsePdfBuffer(buffer, opts);
  },
};

export async function parsePdfBuffer(
  buffer: Buffer,
  _opts: ParseOptions,
): Promise<DocumentAST> {
  const t0 = Date.now();
  const warnings: ParseWarning[] = [];
  const errors: ParseWarning[] = [];

  if (buffer.byteLength === 0) {
    warnings.push({ code: "empty_input", message: "PDF input is empty." });
    return emptyPdfAst(t0, warnings, errors);
  }

  // Dynamic import — pdfjs is heavy (~3MB) and we don't want it on the
  // critical path for non-PDF documents.
  const pdfjs = await loadPdfjs();

  let doc: PdfDocument;
  try {
    const data = new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
    const loadingTask = pdfjs.getDocument({
      data,
      // Disable font fetching from CDN; works fully offline.
      useSystemFonts: true,
      disableFontFace: true,
      isEvalSupported: false,
      // Quieter logging.
      verbosity: 0,
    });
    doc = await loadingTask.promise;
  } catch (e) {
    errors.push({
      code: "pdf_load_failed",
      message: `Failed to load PDF: ${e instanceof Error ? e.message : String(e)}`,
    });
    return emptyPdfAst(t0, warnings, errors);
  }

  // Metadata.
  let title: string | undefined;
  try {
    const meta = await doc.getMetadata();
    const info = (meta?.info ?? {}) as Record<string, unknown>;
    if (typeof info.Title === "string" && info.Title.trim()) title = info.Title.trim();
  } catch {
    // ignore — metadata is best-effort.
  }

  const pageCount = doc.numPages;

  // Per-page raw lines, retained so we can do cross-page header/footer
  // detection BEFORE block emission.
  const pageLines: RawLine[][] = [];
  const pageHeights: number[] = [];
  // Per-page embedded image bytes (PNG-encoded). Parallel-indexed with
  // pageLines; we materialize FigureBlocks for them after layout reconstruction.
  const pageImages: { buffer: Buffer; mimeType: string; width?: number; height?: number }[][] = [];
  let totalEmbeddedImages = 0;

  for (let pageNum = 1; pageNum <= pageCount; pageNum++) {
    try {
      const page = await doc.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1 });
      pageHeights.push(viewport.height);
      const content = await page.getTextContent({
        includeMarkedContent: false,
        disableNormalization: false,
      });
      const items: RawItem[] = [];
      for (const it of content.items) {
        // TextMarkedContent items lack `str` — skip.
        const item = it as { str?: string; transform?: number[]; width?: number; height?: number };
        if (typeof item.str !== "string" || !item.transform) continue;
        if (item.str.length === 0) continue;
        const t = item.transform;
        // PDF transform = [a, b, c, d, e, f]; e,f are translation in page space.
        // Font size ≈ |a| (assuming no skew).
        const x = t[4];
        const y = t[5];
        const fontSize = Math.abs(t[0]) || Math.abs(t[3]) || 0;
        items.push({
          text: item.str,
          x,
          y,
          width: item.width ?? 0,
          height: item.height ?? fontSize,
          fontSize,
        });
      }
      pageLines.push(clusterIntoLines(items));

      // Embedded image extraction. Best-effort: we walk the operator list
      // looking for paintImageXObject ops, then resolve each image via
      // page.objs. Encoding the raw RGBA pixels into a PNG requires an
      // image library (sharp); when sharp isn't installed we skip silently
      // — the doc still parses, just without embedded-image figures.
      if (totalEmbeddedImages < PDF_MAX_EMBEDDED_IMAGES) {
        try {
          const imgs = await extractEmbeddedImages(
            page,
            PDF_MAX_EMBEDDED_IMAGES - totalEmbeddedImages,
          );
          pageImages.push(imgs);
          totalEmbeddedImages += imgs.length;
        } catch (e) {
          warnings.push({
            code: "image_extract_failed",
            message: `Image extraction on page ${pageNum} failed: ${
              e instanceof Error ? e.message : String(e)
            }`,
            context: { page: pageNum },
          });
          pageImages.push([]);
        }
      } else {
        pageImages.push([]);
      }

      try {
        page.cleanup();
      } catch {
        // cleanup is best-effort
      }
    } catch (e) {
      warnings.push({
        code: "page_failed",
        message: `Page ${pageNum} failed: ${e instanceof Error ? e.message : String(e)}`,
        context: { page: pageNum },
      });
      pageLines.push([]);
      pageHeights.push(0);
      pageImages.push([]);
    }
  }

  // Header/footer suppression — detect lines that repeat on > 50% of pages at
  // the top or bottom 8% of the page.
  const supress = detectHeaderFooter(pageLines, pageHeights);

  // Body font-size detection: median of all line fontSizes.
  const allSizes: number[] = [];
  for (const lines of pageLines) for (const l of lines) allSizes.push(l.fontSize);
  const bodySize = allSizes.length ? median(allSizes) : 12;
  // Headings: a line with fontSize > bodySize * 1.15 is at least h3, > 1.35
  // is h2, > 1.6 is h1.
  const headingLevel = (size: number): number | null => {
    if (size > bodySize * 1.6) return 1;
    if (size > bodySize * 1.35) return 2;
    if (size > bodySize * 1.15) return 3;
    return null;
  };

  const blocks: Block[] = [];
  let ordinal = 0;
  const sectionStack: { level: number; text: string }[] = [];
  const sectionPath = () =>
    sectionStack.length ? sectionStack.map((s) => s.text).join(" / ") : undefined;

  let tableCount = 0;
  let figureCount = 0;

  for (let p = 0; p < pageLines.length; p++) {
    const pageNum = p + 1;
    const lines = pageLines[p].filter((l) => !supress.has(l.text.trim()));

    if (lines.length === 0) {
      // Image-only / scanned page → emit a FigureBlock placeholder for P2 OCR.
      const section = sectionPath();
      blocks.push({
        kind: "figure",
        page: pageNum,
        section,
        anchor: anchorFor(section, ordinal++),
        caption: `Scanned page ${pageNum}`,
      });
      figureCount += 1;
      warnings.push({
        code: "scanned_page",
        message: `Page ${pageNum} has no extractable text — vision OCR fallback recommended.`,
        context: { page: pageNum },
      });
    } else {
      // Detect tables: run a sliding-window check over lines.
      let i = 0;
      while (i < lines.length) {
        const tableEnd = detectTableEnd(lines, i);
        if (tableEnd > i + 1) {
          // We have a table spanning [i .. tableEnd-1].
          const tableLines = lines.slice(i, tableEnd);
          const table = buildTable(tableLines);
          const section = sectionPath();
          blocks.push({
            kind: "table",
            page: pageNum,
            section,
            anchor: anchorFor(section, ordinal++),
            headers: table.headers,
            rows: table.rows,
            markdown: tableToMarkdown(table.headers, table.rows),
            confidence: table.confidence,
          });
          tableCount += 1;
          if (table.confidence < 0.7) {
            warnings.push({
              code: "low_confidence_table",
              message: `Low-confidence table on page ${pageNum} — P2 may reconstruct.`,
              context: { page: pageNum },
            });
          }
          i = tableEnd;
          continue;
        }

        // Not a table — paragraph / heading run.
        const line = lines[i];
        const lvl = headingLevel(line.fontSize);
        if (lvl !== null && line.text.length < 200) {
          const text = line.text.trim();
          while (sectionStack.length && sectionStack[sectionStack.length - 1].level >= lvl) {
            sectionStack.pop();
          }
          sectionStack.push({ level: lvl, text });
          const section = sectionPath();
          const block: HeadingBlock = {
            kind: "heading",
            level: lvl,
            text,
            page: pageNum,
            section,
            anchor: anchorFor(section, ordinal++),
          };
          blocks.push(block);
          if (!title && lvl === 1) title = text;
          i += 1;
        } else {
          // Group consecutive body-size lines into a paragraph until we see
          // a line gap > 1.5× line height OR a heading.
          const para: RawLine[] = [line];
          let j = i + 1;
          while (j < lines.length) {
            const prev = lines[j - 1];
            const cur = lines[j];
            const gap = Math.abs(prev.y - cur.y);
            const lvl2 = headingLevel(cur.fontSize);
            if (lvl2 !== null) break;
            if (gap > prev.fontSize * 1.8) break;
            para.push(cur);
            j += 1;
          }
          const text = para
            .map((l) => l.text)
            .join(" ")
            .replace(/\s{2,}/g, " ")
            .trim();
          if (text) {
            const section = sectionPath();
            blocks.push({
              kind: "paragraph",
              text,
              page: pageNum,
              section,
              anchor: anchorFor(section, ordinal++),
            });
          }
          i = j;
        }
      }
    }

    // Embedded images for this page → emit FigureBlock per image with
    // imageBuffer attached. These are in addition to the layout-text figures
    // we may have emitted above for scanned pages.
    const embedded = pageImages[p] ?? [];
    for (const img of embedded) {
      const section = sectionPath();
      const figure: FigureBlock = {
        kind: "figure",
        page: pageNum,
        section,
        anchor: anchorFor(section, ordinal++),
        imageBuffer: img.buffer,
      };
      blocks.push(figure);
      figureCount += 1;
    }

    // Page break after every page except the last.
    if (p < pageLines.length - 1) {
      const section = sectionPath();
      blocks.push({
        kind: "page_break",
        toPage: pageNum + 1,
        page: pageNum,
        section,
        anchor: anchorFor(section, ordinal++),
      });
    }
  }

  // Language detection from extracted text.
  const allText = blocks
    .map((b) => ("text" in b ? (b as { text: string }).text : ""))
    .join(" ");
  const language = detectLanguage(allText) ?? undefined;

  const report: ParseReport = {
    parser: "pdf",
    parserVersion: PDF_PARSER_VERSION,
    pageCount,
    blockCount: blocks.length,
    tableCount,
    listCount: 0,
    figureCount,
    ocrUsed: false,
    parseMs: Date.now() - t0,
    warnings,
    errors,
  };

  try {
    await doc.destroy();
  } catch {
    // cleanup
  }

  return {
    metadata: {
      title,
      language,
      parser: "pdf",
      parserVersion: PDF_PARSER_VERSION,
      pageCount,
    },
    blocks,
    report,
  };
}

// ---- line clustering --------------------------------------------------

function clusterIntoLines(items: RawItem[]): RawLine[] {
  if (items.length === 0) return [];
  // Sort by Y desc (PDF coords: higher Y = nearer top? No — pdfjs reports
  // text in user space where higher Y is further up. We just need a stable
  // ordering for clustering, then re-sort top-down at the end.)
  const sorted = [...items].sort((a, b) => b.y - a.y);

  const lines: RawItem[][] = [];
  const tolerance = (it: RawItem) => Math.max(it.height, it.fontSize, 6) * 0.5;
  for (const it of sorted) {
    const last = lines[lines.length - 1];
    if (last && Math.abs(last[0].y - it.y) <= tolerance(last[0])) {
      last.push(it);
    } else {
      lines.push([it]);
    }
  }
  return lines.map((items) => {
    items.sort((a, b) => a.x - b.x);
    const text = items.map((i) => i.text).join("").replace(/\s+/g, " ").trim();
    const y = items.reduce((s, i) => s + i.y, 0) / items.length;
    const fontSize = Math.max(...items.map((i) => i.fontSize));
    const minX = Math.min(...items.map((i) => i.x));
    // For table detection we want the "token-level" x positions. Tokenize on
    // gaps > average char width.
    const tokens = tokenize(items);
    return { items, y, text, fontSize, minX, tokens };
  });
}

function tokenize(items: RawItem[]): { x: number; text: string }[] {
  // Group consecutive items into tokens when the gap between them is small.
  const tokens: { x: number; text: string }[] = [];
  let cur: { x: number; text: string } | null = null;
  let prevEnd = -Infinity;
  for (const it of items) {
    const avgCharW = it.width && it.text.length ? it.width / it.text.length : it.fontSize * 0.4;
    const gap = it.x - prevEnd;
    if (cur && gap < avgCharW * 1.5) {
      cur.text += it.text;
    } else {
      if (cur) tokens.push(cur);
      cur = { x: it.x, text: it.text };
    }
    prevEnd = it.x + it.width;
  }
  if (cur) tokens.push(cur);
  return tokens
    .map((t) => ({ x: t.x, text: t.text.trim() }))
    .filter((t) => t.text.length > 0);
}

// ---- header/footer detection ------------------------------------------

function detectHeaderFooter(pageLines: RawLine[][], pageHeights: number[]): Set<string> {
  const topCounts = new Map<string, number>();
  const bottomCounts = new Map<string, number>();
  const pagesWithText = pageLines.filter((l) => l.length > 0).length;
  if (pagesWithText < 3) return new Set();

  for (let i = 0; i < pageLines.length; i++) {
    const lines = pageLines[i];
    const h = pageHeights[i] || 0;
    if (lines.length === 0 || h === 0) continue;
    const topThresh = h * 0.92; // top 8% (Y axis: higher = closer to top)
    const bottomThresh = h * 0.08;
    for (const line of lines) {
      const text = line.text.trim();
      if (!text || text.length > 120) continue;
      if (line.y >= topThresh) {
        topCounts.set(text, (topCounts.get(text) ?? 0) + 1);
      } else if (line.y <= bottomThresh) {
        bottomCounts.set(text, (bottomCounts.get(text) ?? 0) + 1);
      }
    }
  }

  const suppress = new Set<string>();
  const half = pagesWithText / 2;
  for (const [text, n] of topCounts) if (n > half) suppress.add(text);
  for (const [text, n] of bottomCounts) if (n > half) suppress.add(text);
  return suppress;
}

// ---- table detection --------------------------------------------------

/**
 * Returns the exclusive index past the last line of a table starting at
 * `start`. Returns `start + 1` (no table) when no table is detected.
 *
 * Heuristic: a "row" line has ≥2 tokens. A table is a run of ≥2 row lines
 * whose token x-positions cluster into the same N columns.
 */
function detectTableEnd(lines: RawLine[], start: number): number {
  const firstRow = lines[start];
  if (!firstRow || firstRow.tokens.length < 2) return start + 1;

  // Candidate column anchors: x positions of the first row's tokens.
  const colAnchors = firstRow.tokens.map((t) => t.x);
  const tol = 8; // px tolerance

  const rowMatches = (line: RawLine): boolean => {
    if (line.tokens.length < 2) return false;
    let matched = 0;
    for (const a of colAnchors) {
      if (line.tokens.some((t) => Math.abs(t.x - a) <= tol)) matched += 1;
    }
    return matched >= Math.max(2, Math.ceil(colAnchors.length * 0.6));
  };

  let end = start + 1;
  while (end < lines.length && rowMatches(lines[end])) end += 1;
  if (end - start < 2) return start + 1; // not enough rows
  return end;
}

function buildTable(lines: RawLine[]): {
  headers?: string[];
  rows: string[][];
  confidence: number;
} {
  // Snap each token to the nearest column anchor derived from line 0.
  const anchors = lines[0].tokens.map((t) => t.x);
  const tol = 8;
  const rows: string[][] = [];
  for (const line of lines) {
    const row: string[] = new Array(anchors.length).fill("");
    for (const tok of line.tokens) {
      let best = 0;
      let bestD = Infinity;
      for (let i = 0; i < anchors.length; i++) {
        const d = Math.abs(tok.x - anchors[i]);
        if (d < bestD) {
          bestD = d;
          best = i;
        }
      }
      if (bestD <= tol * 2) {
        row[best] = row[best] ? `${row[best]} ${tok.text}` : tok.text;
      }
    }
    rows.push(row);
  }
  const headers = rows.shift();
  // Confidence: ratio of non-empty cells.
  const cells = rows.flat();
  const nonEmpty = cells.filter((c) => c.length > 0).length;
  const confidence = cells.length ? Math.min(1, nonEmpty / cells.length + 0.2) : 0.5;
  return { headers, rows, confidence };
}

// ---- misc -------------------------------------------------------------

function median(xs: number[]): number {
  const s = [...xs].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

function emptyPdfAst(
  t0: number,
  warnings: ParseWarning[],
  errors: ParseWarning[],
): DocumentAST {
  return {
    metadata: { parser: "pdf", parserVersion: PDF_PARSER_VERSION },
    blocks: [],
    report: {
      parser: "pdf",
      parserVersion: PDF_PARSER_VERSION,
      blockCount: 0,
      tableCount: 0,
      listCount: 0,
      figureCount: 0,
      ocrUsed: false,
      parseMs: Date.now() - t0,
      warnings,
      errors,
    },
  };
}

// ---- embedded-image extraction ----------------------------------------

interface PdfImageObj {
  data?: Uint8ClampedArray | Uint8Array;
  width?: number;
  height?: number;
  /** "RGBA_32BPP" | "RGB_24BPP" | "GRAYSCALE_1BPP" — pdfjs ImageKind enum. */
  kind?: number;
  bitmap?: ImageBitmap;
}

/**
 * Walk the operator list looking for paintImageXObject ops, resolve each one
 * via page.objs, and PNG-encode the raw RGBA pixels via sharp (when
 * available). Returns at most `limit` images. Silently skips any image we
 * can't resolve or encode — callers don't need to know which ones we couldn't
 * extract.
 */
async function extractEmbeddedImages(
  page: PdfPage,
  limit: number,
): Promise<{ buffer: Buffer; mimeType: string; width?: number; height?: number }[]> {
  if (limit <= 0) return [];
  // sharp is a runtime dependency. The dynamic-import .catch keeps the build
  // resilient even if it's missing in some environment.
  const sharpMod = (await import("sharp").catch(() => null)) as
    | { default: (input: Buffer | Uint8Array, opts?: Record<string, unknown>) => {
        png: () => { toBuffer: () => Promise<Buffer> };
      } }
    | null;
  if (!sharpMod || typeof sharpMod.default !== "function") {
    // No image encoder available — skip silently.
    return [];
  }

  let opList;
  try {
    opList = await page.getOperatorList();
  } catch {
    return [];
  }
  // pdfjs ops: OPS.paintImageXObject (and Repeat / Inline). The numeric
  // value is in shared/util.js; we read it from the loaded pdfjs module.
  // Rather than introspecting the OPS enum, we collect candidate object IDs
  // and try to resolve each one via page.objs.get.
  const objIds = new Set<string>();
  const fnArray = (opList as unknown as { fnArray?: number[]; argsArray?: unknown[][] }).fnArray ?? [];
  const argsArray = (opList as unknown as { fnArray?: number[]; argsArray?: unknown[][] }).argsArray ?? [];
  for (let i = 0; i < fnArray.length; i++) {
    const args = argsArray[i];
    if (!Array.isArray(args)) continue;
    // First arg of paint*ImageXObject ops is the object id (string).
    const first = args[0];
    if (typeof first === "string" && (first.startsWith("img_") || first.startsWith("g_"))) {
      objIds.add(first);
    }
  }

  const out: { buffer: Buffer; mimeType: string; width?: number; height?: number }[] = [];
  for (const objId of objIds) {
    if (out.length >= limit) break;

    // pdfjs loads image XObjects asynchronously while we walk the op list.
    // Calling `page.objs.get(objId)` synchronously throws
    //   "Requesting object that isn't resolved yet ..."
    // when the image hasn't materialized yet. The callback overload of
    // `.get` fires once the data is ready; promisify it. We cap the wait at
    // 5s per image so a malformed XObject can't hang the parser.
    let obj: PdfImageObj | undefined;
    try {
      obj = await new Promise<PdfImageObj | undefined>((resolve) => {
        const timer = setTimeout(() => resolve(undefined), 5_000);
        try {
          (page.objs as {
            get(id: string, cb: (value: unknown) => void): void;
          }).get(objId, (value) => {
            clearTimeout(timer);
            resolve(value as PdfImageObj | undefined);
          });
        } catch {
          clearTimeout(timer);
          resolve(undefined);
        }
      });
    } catch {
      continue;
    }
    if (!obj || !obj.width || !obj.height) continue;

    const width = obj.width;
    const height = obj.height;
    const data = obj.data;
    if (!data || data.byteLength === 0) continue;

    // Determine channels from the kind enum when present, falling back to
    // pixel-count math.
    // pdfjs ImageKind: GRAYSCALE_1BPP=1, RGB_24BPP=2, RGBA_32BPP=3.
    let channels: 1 | 3 | 4;
    if (obj.kind === 1) channels = 1;
    else if (obj.kind === 2) channels = 3;
    else if (obj.kind === 3) channels = 4;
    else {
      const bytesPerPixel = data.byteLength / (width * height);
      if (bytesPerPixel === 4) channels = 4;
      else if (bytesPerPixel === 3) channels = 3;
      else if (bytesPerPixel === 1) channels = 1;
      else continue;
    }

    try {
      const png = await sharpMod
        .default(Buffer.from(data.buffer, data.byteOffset, data.byteLength), {
          raw: { width, height, channels },
        })
        .png()
        .toBuffer();
      out.push({ buffer: png, mimeType: "image/png", width, height });
    } catch {
      // skip un-encodable images silently.
      continue;
    }
  }
  return out;
}

// ---- pdfjs loader (handles Node-vs-browser) ---------------------------

interface PdfTextItem {
  str?: string;
  transform?: number[];
  width?: number;
  height?: number;
}
interface PdfTextContent {
  items: PdfTextItem[];
}
interface PdfPage {
  getViewport(opts: { scale: number }): { width: number; height: number };
  getTextContent(opts: {
    includeMarkedContent: boolean;
    disableNormalization: boolean;
  }): Promise<PdfTextContent>;
  /** Operator list — fnArray + argsArray of low-level draw commands. */
  getOperatorList(): Promise<unknown>;
  /** Per-page object cache; image XObjects are stored here by the worker. */
  objs: { get(id: string): unknown };
  cleanup(): void;
}
interface PdfDocument {
  numPages: number;
  getMetadata(): Promise<{ info?: Record<string, unknown> }>;
  getPage(n: number): Promise<PdfPage>;
  destroy(): Promise<void>;
}
interface PdfjsLike {
  getDocument(opts: {
    data: Uint8Array;
    useSystemFonts?: boolean;
    disableFontFace?: boolean;
    isEvalSupported?: boolean;
    verbosity?: number;
  }): { promise: Promise<PdfDocument> };
  GlobalWorkerOptions?: { workerSrc?: string };
}

let _pdfjs: PdfjsLike | undefined;
async function loadPdfjs(): Promise<PdfjsLike> {
  if (_pdfjs) return _pdfjs;
  // Use the legacy build — it runs in Node without DOM polyfills.
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore — no type re-export from /legacy/build/pdf.mjs path.
  const mod = (await import("pdfjs-dist/legacy/build/pdf.mjs")) as unknown as PdfjsLike;
  // pdfjs v5 REQUIRES a workerSrc — the older "fake worker via empty src"
  // trick fails with: `Setting up fake worker failed: No workerSrc specified`.
  // Resolve the bundled legacy worker file via require.resolve so the path is
  // correct in every install layout (pnpm, npm, yarn, monorepos).
  if (mod.GlobalWorkerOptions) {
    try {
      const { createRequire } = await import("node:module");
      const req = createRequire(import.meta.url);
      const workerPath = req.resolve("pdfjs-dist/legacy/build/pdf.worker.mjs");
      // pdfjs accepts a file:// URL or a plain path for Node.
      const { pathToFileURL } = await import("node:url");
      mod.GlobalWorkerOptions.workerSrc = pathToFileURL(workerPath).href;
    } catch {
      // Last-ditch: relative spec. pdfjs will try to import() it.
      mod.GlobalWorkerOptions.workerSrc = "pdfjs-dist/legacy/build/pdf.worker.mjs";
    }
  }
  _pdfjs = mod;
  return mod;
}
