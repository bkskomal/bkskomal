// Shared "rows -> GitHub-flavored Markdown table" renderer used by every
// parser that emits a TableBlock.

export function tableToMarkdown(
  headers: string[] | undefined,
  rows: string[][],
): string {
  if ((!headers || headers.length === 0) && rows.length === 0) {
    return "";
  }
  const colCount = Math.max(
    headers?.length ?? 0,
    ...rows.map((r) => r.length),
    1,
  );
  const headerRow = headers ?? Array.from({ length: colCount }, (_, i) => `Col ${i + 1}`);
  // Pad header row to column count.
  while (headerRow.length < colCount) headerRow.push("");

  const sanitize = (s: string) =>
    String(s ?? "")
      .replace(/\r?\n/g, " ")
      .replace(/\|/g, "\\|")
      .trim();

  const lines: string[] = [];
  lines.push("| " + headerRow.map(sanitize).join(" | ") + " |");
  lines.push("| " + headerRow.map(() => "---").join(" | ") + " |");
  for (const r of rows) {
    const padded = [...r];
    while (padded.length < colCount) padded.push("");
    lines.push("| " + padded.map(sanitize).join(" | ") + " |");
  }
  return lines.join("\n") + "\n";
}
