// DOCX parser — mammoth.convertToHtml → cheerio → shared DOM walker.
//
// Mammoth converts Word's "Heading 1/2/3" styles to <h1>/<h2>/<h3>, real
// tables to <table>, lists to <ul>/<ol>, etc. We then run our DOM walker
// across that HTML to emit DocumentAST blocks identical in shape to what
// the html-parser produces.

import * as cheerio from "cheerio";
import {
  anchorFor,
  detectLanguage,
  type DocumentAST,
  type DocumentParser,
  type ParseOptions,
  type ParseReport,
  type ParseWarning,
} from "./ast";
import { cheerioToDom, walkDom } from "./dom-walker";
import { hydrateFigureImages } from "./image-fetch";
import { extractImagesFromOpenXml } from "./openxml-images";

export const DOCX_PARSER_VERSION = "docx-2026-05-01";

const DOCX_MIMES = new Set([
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/msword",
]);

export const docxParser: DocumentParser = {
  id: "docx",
  version: DOCX_PARSER_VERSION,
  canParse(buffer, opts) {
    if (opts.mimeType && DOCX_MIMES.has(opts.mimeType)) return true;
    if (opts.fileName?.match(/\.docx?$/i)) return true;
    // DOCX is a ZIP — PK\x03\x04 magic. We don't peek further here; the
    // facade's detectFormat does the deeper distinguishing.
    if (buffer.slice(0, 4).toString("hex") === "504b0304") return true;
    return false;
  },
  async parse(buffer, opts): Promise<DocumentAST> {
    return parseDocxBuffer(buffer, opts);
  },
};

export async function parseDocxBuffer(
  buffer: Buffer,
  _opts: ParseOptions,
): Promise<DocumentAST> {
  const t0 = Date.now();
  const warnings: ParseWarning[] = [];
  const errors: ParseWarning[] = [];

  if (buffer.byteLength === 0) {
    warnings.push({ code: "empty_input", message: "DOCX input is empty." });
    return emptyDocxAst(t0, warnings, errors);
  }

  const mammoth = await import("mammoth");

  // Convert to HTML with a style map that pins heading hierarchy. Mammoth's
  // defaults already map Heading 1..6 — we just make sure to honor them.
  let html = "";
  let titleFromProps: string | undefined;
  let mammothMessages: { message: string }[] = [];
  try {
    const result = await mammoth.convertToHtml(
      { buffer },
      {
        styleMap: [
          "p[style-name='Title'] => h1.title:fresh",
          "p[style-name='Heading 1'] => h1:fresh",
          "p[style-name='Heading 2'] => h2:fresh",
          "p[style-name='Heading 3'] => h3:fresh",
          "p[style-name='Heading 4'] => h4:fresh",
          "p[style-name='Heading 5'] => h5:fresh",
          "p[style-name='Heading 6'] => h6:fresh",
          "p[style-name='Quote'] => blockquote:fresh",
          "p[style-name='Intense Quote'] => blockquote:fresh",
        ],
      },
    );
    html = result.value;
    mammothMessages = result.messages ?? [];
  } catch (e) {
    errors.push({
      code: "docx_convert_failed",
      message: `mammoth.convertToHtml failed: ${e instanceof Error ? e.message : String(e)}`,
    });
    return emptyDocxAst(t0, warnings, errors);
  }

  for (const m of mammothMessages) {
    warnings.push({ code: "mammoth_warning", message: m.message });
  }

  // Pull "Title" from the .title class produced by our style map; failing
  // that, the first h1.
  const $ = cheerio.load(`<root>${html}</root>`);
  titleFromProps =
    $("h1.title").first().text().trim() ||
    $("h1").first().text().trim() ||
    undefined;

  const rootNode = $("root").get(0);
  if (!rootNode) {
    return emptyDocxAst(t0, warnings, errors);
  }
  const walk = walkDom(cheerioToDom(rootNode), { skipChrome: false });
  warnings.push(...walk.warnings);

  // Hydrate FigureBlock.imageBuffer from inline data: URLs. Mammoth's default
  // image converter (`images.dataUri`) emits base64 data URLs for every
  // embedded image, so this typically catches every figure that mammoth
  // produced. We don't enable HTTP fetch here — DOCX images are always
  // embedded.
  let figureBlocks = walk.blocks;
  try {
    const hydrate = await hydrateFigureImages(walk.blocks, { allowFetch: false });
    figureBlocks = hydrate.blocks;
    warnings.push(...hydrate.warnings);
  } catch (e) {
    warnings.push({
      code: "image_hydrate_failed",
      message: `Image hydration failed: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  // Fallback path: ALSO walk the DOCX zip directly and pull every
  // `word/media/imageN.*` entry. Mammoth's HTML conversion drops images
  // whose `style-name` doesn't match any mapped paragraph style (figures
  // floating in text, inline shapes inside tables, ...), so a "5 images
  // in the file, 0 in the parsed AST" result is depressingly common. The
  // OpenXML zip walk is deterministic — same helper xlsx/pptx already use.
  // We dedupe against URLs/buffers that mammoth already gave us via the
  // base64 imageRef so we don't double-embed.
  try {
    const seenHashes = new Set<string>();
    for (const b of figureBlocks) {
      if (b.kind === "figure" && b.imageBuffer && b.imageBuffer.byteLength > 0) {
        // Cheap "have we seen this exact image?" check via length — full
        // hashing would cost more than the dedupe is worth.
        seenHashes.add(`${b.imageBuffer.byteLength}`);
      }
    }
    const zipImages = await extractImagesFromOpenXml(buffer, { format: "docx" });
    let ordinal = figureBlocks.length;
    const figuresFromZip: typeof walk.blocks = [];
    for (const img of zipImages) {
      const sizeKey = `${img.buffer.byteLength}`;
      if (seenHashes.has(sizeKey)) continue;
      seenHashes.add(sizeKey);
      const section = "Embedded images";
      figuresFromZip.push({
        kind: "figure",
        caption: img.zipPath.replace(/^word\/media\//, ""),
        imageBuffer: img.buffer,
        section,
        anchor: anchorFor(section, ordinal++),
      });
    }
    if (figuresFromZip.length > 0) {
      // Insert an "Embedded images" heading so chunk section paths read nicely.
      figureBlocks = [
        ...figureBlocks,
        {
          kind: "heading",
          level: 2,
          text: "Embedded images",
          section: "Embedded images",
          anchor: anchorFor("Embedded images", ordinal++),
        },
        ...figuresFromZip,
      ];
    }
  } catch (e) {
    warnings.push({
      code: "openxml_image_extract_failed",
      message: `OpenXML image extraction failed: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  const title = titleFromProps ?? walk.detectedTitle;

  const allText = figureBlocks
    .map((b) => ("text" in b ? (b as { text: string }).text : ""))
    .join(" ");
  const language = detectLanguage(allText) ?? undefined;

  const tableCount = figureBlocks.filter((b) => b.kind === "table").length;
  const listCount = figureBlocks.filter((b) => b.kind === "list").length;
  const figureCount = figureBlocks.filter((b) => b.kind === "figure").length;

  const report: ParseReport = {
    parser: "docx",
    parserVersion: DOCX_PARSER_VERSION,
    blockCount: figureBlocks.length,
    tableCount,
    listCount,
    figureCount,
    ocrUsed: false,
    parseMs: Date.now() - t0,
    warnings,
    errors,
  };

  return {
    metadata: {
      title,
      language,
      parser: "docx",
      parserVersion: DOCX_PARSER_VERSION,
    },
    blocks: figureBlocks,
    report,
  };
}

function emptyDocxAst(
  t0: number,
  warnings: ParseWarning[],
  errors: ParseWarning[],
): DocumentAST {
  return {
    metadata: { parser: "docx", parserVersion: DOCX_PARSER_VERSION },
    blocks: [],
    report: {
      parser: "docx",
      parserVersion: DOCX_PARSER_VERSION,
      blockCount: 0,
      tableCount: 0,
      listCount: 0,
      figureCount: 0,
      ocrUsed: false,
      parseMs: Date.now() - t0,
      warnings,
      errors,
    },
  };
}
