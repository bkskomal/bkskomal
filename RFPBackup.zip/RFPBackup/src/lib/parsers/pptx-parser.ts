// PPTX parser — slide-by-slide extraction.
//
// PPTX files are ZIP archives. Each slide lives at ppt/slides/slideN.xml as
// DrawingML XML. We unzip, walk each slide's text-frame elements (`<a:t>`)
// to reconstruct slide text, and emit:
//   • PageBreak between slides (toPage = slide number)
//   • HeadingBlock (level 1) with the slide title (when present)
//   • ParagraphBlock per text frame (the bullets, body, etc.)
//   • FigureBlock for each embedded image (extracted from ppt/media/)
//
// We do NOT use a heavy-weight DrawingML library — the text-extraction we
// need is reachable via simple XML walking. This keeps the parser dep-free
// and fast. Slide notes are skipped (most RFP-relevant content is on the
// slides themselves).

import JSZip from "jszip";
import {
  anchorFor,
  type DocumentAST,
  type DocumentParser,
  type ParseOptions,
  type ParseReport,
  type ParseWarning,
  type Block,
} from "./ast";
import { extractImagesFromOpenXml } from "./openxml-images";

export const PPTX_PARSER_VERSION = "pptx-2026-05-01";

const PPTX_MIMES = new Set([
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/vnd.ms-powerpoint",
]);

export const pptxParser: DocumentParser = {
  id: "pptx" as const,
  version: PPTX_PARSER_VERSION,
  canParse(buffer, opts) {
    if (opts.mimeType && PPTX_MIMES.has(opts.mimeType)) return true;
    if (opts.fileName?.match(/\.pptx?$/i)) return true;
    // Magic-byte sniff: PK header + the central directory mentioning ppt/
    if (buffer.length > 4 && buffer[0] === 0x50 && buffer[1] === 0x4b) {
      // Only confidently true when MIME or filename signals PowerPoint;
      // raw zip detection is left to the format-detection facade so we
      // don't accidentally claim DOCX/XLSX files.
      return false;
    }
    return false;
  },
  async parse(buffer, opts): Promise<DocumentAST> {
    return parsePptxBuffer(buffer, opts);
  },
};

export async function parsePptxBuffer(
  buffer: Buffer,
  _opts: ParseOptions,
): Promise<DocumentAST> {
  const t0 = Date.now();
  const warnings: ParseWarning[] = [];
  const errors: ParseWarning[] = [];

  if (buffer.byteLength === 0) {
    warnings.push({ code: "empty_input", message: "PPTX input is empty." });
    return emptyAst(t0, warnings, errors);
  }

  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(buffer);
  } catch (e) {
    errors.push({
      code: "pptx_unzip_failed",
      message: `PPTX unzip failed: ${e instanceof Error ? e.message : String(e)}`,
    });
    return emptyAst(t0, warnings, errors);
  }

  const blocks: Block[] = [];
  let ordinal = 0;
  let title: string | undefined;
  let listCount = 0;
  let figureCount = 0;

  // Enumerate slides in numeric order. Filenames are slide1.xml, slide2.xml, ...
  const slideFiles = Object.values(zip.files)
    .filter((f) => !f.dir && /^ppt\/slides\/slide\d+\.xml$/i.test(f.name))
    .sort((a, b) => slideNumberFromName(a.name) - slideNumberFromName(b.name));

  for (let i = 0; i < slideFiles.length; i++) {
    const file = slideFiles[i];
    const slideNum = slideNumberFromName(file.name);
    let xml: string;
    try {
      xml = await file.async("text");
    } catch (e) {
      warnings.push({
        code: "slide_read_failed",
        message: `Slide ${slideNum} read failed: ${e instanceof Error ? e.message : String(e)}`,
        context: { slide: slideNum },
      });
      continue;
    }

    const slide = extractSlideContent(xml);
    const section = `Slide ${slideNum}${slide.title ? `: ${slide.title}` : ""}`;

    // PageBreak between slides (not before the first).
    if (i > 0) {
      blocks.push({
        kind: "page_break",
        toPage: slideNum,
        section,
        anchor: anchorFor(section, ordinal++),
      });
    }

    // Heading.
    blocks.push({
      kind: "heading",
      level: 1,
      text: slide.title ?? `Slide ${slideNum}`,
      page: slideNum,
      section,
      anchor: anchorFor(section, ordinal++),
    });
    if (!title && slide.title) title = slide.title;

    // Body paragraphs (one per text frame other than the title).
    for (const para of slide.bodyParagraphs) {
      if (!para.trim()) continue;
      blocks.push({
        kind: "paragraph",
        text: para,
        page: slideNum,
        section,
        anchor: anchorFor(section, ordinal++),
      });
    }

    // Bulleted lists collapsed into a ListBlock when ≥ 2 short lines look bullet-like.
    if (slide.bullets.length >= 2) {
      blocks.push({
        kind: "list",
        ordered: false,
        items: slide.bullets.map((b) => ({ text: b })),
        page: slideNum,
        section,
        anchor: anchorFor(section, ordinal++),
      });
      listCount += 1;
    }
  }

  // Embedded images from ppt/media/. Each becomes a FigureBlock with imageBuffer.
  // The pipeline's image-processing step picks them up.
  try {
    const images = await extractImagesFromOpenXml(buffer, { format: "pptx" });
    if (images.length > 0) {
      const figSection = "Images";
      blocks.push({
        kind: "heading",
        level: 1,
        text: "Images",
        section: figSection,
        anchor: anchorFor(figSection, ordinal++),
      });
      for (const img of images) {
        blocks.push({
          kind: "figure",
          caption: img.zipPath.replace(/^ppt\/media\//, ""),
          imageBuffer: img.buffer,
          section: figSection,
          anchor: anchorFor(figSection, ordinal++),
        });
        figureCount += 1;
      }
    }
  } catch (e) {
    warnings.push({
      code: "pptx_image_extract_failed",
      message: `Failed to extract embedded images: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  const report: ParseReport = {
    parser: "pptx",
    parserVersion: PPTX_PARSER_VERSION,
    pageCount: slideFiles.length,
    blockCount: blocks.length,
    tableCount: 0,
    listCount,
    figureCount,
    ocrUsed: false,
    parseMs: Date.now() - t0,
    warnings,
    errors,
  };

  return {
    metadata: {
      title,
      parser: "pptx",
      parserVersion: PPTX_PARSER_VERSION,
      pageCount: slideFiles.length,
    },
    blocks,
    report,
  };
}

interface SlideContent {
  title?: string;
  bodyParagraphs: string[];
  bullets: string[];
}

/**
 * Walk a slide's XML, extract text from `<a:t>` elements, and group them by
 * their parent text frame. The first text frame on a slide that contains a
 * single short line is treated as the slide title; subsequent frames become
 * body paragraphs. Lines that look like bullets (the typical 1–8 word
 * fragments common to PowerPoint slides) are collapsed into a list.
 */
export function extractSlideContent(xml: string): SlideContent {
  // Each text frame is `<p:txBody>...</p:txBody>` containing one or more
  // `<a:p>...</a:p>` paragraphs, each containing `<a:r>...<a:t>text</a:t>...</a:r>`
  // runs. Reconstruct paragraph-level text by joining `<a:t>` siblings inside
  // each `<a:p>`, then group by `<p:txBody>` for frames.
  const frames: string[][] = [];
  const txBodyRegex = /<p:txBody\b[^>]*>([\s\S]*?)<\/p:txBody>/g;
  let mFrame: RegExpExecArray | null;
  while ((mFrame = txBodyRegex.exec(xml))) {
    const frameXml = mFrame[1];
    const paragraphs: string[] = [];
    const paraRegex = /<a:p\b[^>]*>([\s\S]*?)<\/a:p>/g;
    let mPara: RegExpExecArray | null;
    while ((mPara = paraRegex.exec(frameXml))) {
      const runs: string[] = [];
      const tRegex = /<a:t\b[^>]*>([\s\S]*?)<\/a:t>/g;
      let mT: RegExpExecArray | null;
      while ((mT = tRegex.exec(mPara[1]))) {
        runs.push(decodeXml(mT[1]));
      }
      const text = runs.join("").trim();
      if (text) paragraphs.push(text);
    }
    if (paragraphs.length > 0) frames.push(paragraphs);
  }

  // Heuristic: title is the first frame that has a single line ≤ 80 chars.
  let title: string | undefined;
  let titleFrameIdx = -1;
  for (let i = 0; i < frames.length; i++) {
    const f = frames[i];
    if (f.length === 1 && f[0].length <= 80) {
      title = f[0];
      titleFrameIdx = i;
      break;
    }
  }

  // Body = remaining frames flattened.
  const bodyParagraphs: string[] = [];
  const bullets: string[] = [];
  for (let i = 0; i < frames.length; i++) {
    if (i === titleFrameIdx) continue;
    const f = frames[i];
    // If the frame has ≥3 lines AND each line is short (≤120 chars), treat
    // as bullets. Otherwise as paragraphs.
    if (f.length >= 3 && f.every((l) => l.length <= 120)) {
      bullets.push(...f);
    } else {
      bodyParagraphs.push(...f);
    }
  }

  return { title, bodyParagraphs, bullets };
}

function slideNumberFromName(name: string): number {
  const m = name.match(/slide(\d+)\.xml$/i);
  return m ? parseInt(m[1], 10) : 0;
}

function decodeXml(s: string): string {
  return s
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");
}

function emptyAst(
  t0: number,
  warnings: ParseWarning[],
  errors: ParseWarning[],
): DocumentAST {
  return {
    metadata: { parser: "pptx", parserVersion: PPTX_PARSER_VERSION },
    blocks: [],
    report: {
      parser: "pptx",
      parserVersion: PPTX_PARSER_VERSION,
      blockCount: 0,
      tableCount: 0,
      listCount: 0,
      figureCount: 0,
      ocrUsed: false,
      parseMs: Date.now() - t0,
      warnings,
      errors,
    },
  };
}
