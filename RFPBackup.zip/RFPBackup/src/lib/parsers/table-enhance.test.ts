import { describe, expect, it } from "vitest";
import { enhanceTablesWithLLM } from "./table-enhance";
import type { DocumentAST, TableBlock } from "./ast";

function tableBlock(opts: {
  anchor: string;
  confidence?: number;
  headers: string[];
  rows: string[][];
}): TableBlock {
  const markdown = renderMarkdown(opts.headers, opts.rows);
  return {
    kind: "table",
    anchor: opts.anchor,
    confidence: opts.confidence,
    headers: opts.headers,
    rows: opts.rows,
    markdown,
  };
}

function renderMarkdown(headers: string[], rows: string[][]): string {
  const sep = headers.map(() => "---");
  const fmt = (cells: string[]) => `| ${cells.join(" | ")} |`;
  return [fmt(headers), fmt(sep), ...rows.map((r) => fmt(r))].join("\n");
}

function emptyReport() {
  return {
    parser: "pdf" as const,
    parserVersion: "1.0",
    blockCount: 0,
    tableCount: 0,
    listCount: 0,
    figureCount: 0,
    ocrUsed: false,
    parseMs: 1,
    warnings: [],
    errors: [],
  };
}

function ast(blocks: DocumentAST["blocks"]): DocumentAST {
  return {
    metadata: { parser: "pdf", parserVersion: "1.0" },
    blocks,
    report: { ...emptyReport(), blockCount: blocks.length, tableCount: blocks.filter((b) => b.kind === "table").length },
  };
}

describe("enhanceTablesWithLLM", () => {
  it("enhances a low-confidence table and bumps confidence to 0.9", async () => {
    const t = tableBlock({
      anchor: "t1",
      confidence: 0.4,
      headers: ["A", "B"],
      rows: [["1", "2"]],
    });
    const cleaned =
      "| A | B | C |\n| --- | --- | --- |\n| 1 | 2 | 3 |";
    const result = await enhanceTablesWithLLM(ast([t]), "org-1", {
      enhanceFn: async () => cleaned,
    });
    const after = result.blocks[0] as TableBlock;
    expect(after.headers).toEqual(["A", "B", "C"]);
    expect(after.rows).toEqual([["1", "2", "3"]]);
    expect(after.confidence).toBe(0.9);
    expect(after.markdown).toContain("| A | B | C |");
  });

  it("does not touch high-confidence regular tables", async () => {
    const t = tableBlock({
      anchor: "t1",
      confidence: 0.95,
      headers: ["A", "B"],
      rows: [["1", "2"], ["3", "4"]],
    });
    let calls = 0;
    const result = await enhanceTablesWithLLM(ast([t]), "org-1", {
      enhanceFn: async () => {
        calls++;
        return "should not be called";
      },
    });
    expect(calls).toBe(0);
    const after = result.blocks[0] as TableBlock;
    expect(after.confidence).toBe(0.95);
  });

  it("enhances tables with ragged column counts regardless of confidence", async () => {
    const t = tableBlock({
      anchor: "t1",
      confidence: 0.95, // looks confident but rows are ragged
      headers: ["A", "B"],
      rows: [["1", "2"], ["3"]],
    });
    let calls = 0;
    const result = await enhanceTablesWithLLM(ast([t]), "org-1", {
      enhanceFn: async () => {
        calls++;
        return "| A | B |\n| --- | --- |\n| 1 | 2 |\n| 3 |   |";
      },
    });
    expect(calls).toBe(1);
    const after = result.blocks[0] as TableBlock;
    expect(after.confidence).toBe(0.9);
    expect(after.rows).toHaveLength(2);
  });

  it("respects the maxTables cap", async () => {
    const tables = Array.from({ length: 10 }, (_, i) =>
      tableBlock({
        anchor: `t${i}`,
        confidence: 0.3,
        headers: ["A"],
        rows: [["x"]],
      }),
    );
    let calls = 0;
    const result = await enhanceTablesWithLLM(ast(tables), "org-1", {
      maxTables: 2,
      enhanceFn: async () => {
        calls++;
        return "| A |\n| --- |\n| x |";
      },
    });
    expect(calls).toBe(2);
    expect(
      result.report.warnings.some((w) => w.code === "table_enhance_capped"),
    ).toBe(true);
  });

  it("logs a warning and keeps the original when the LLM returns unparseable text", async () => {
    const t = tableBlock({
      anchor: "t1",
      confidence: 0.3,
      headers: ["A"],
      rows: [["x"]],
    });
    const result = await enhanceTablesWithLLM(ast([t]), "org-1", {
      enhanceFn: async () => "this is not a table at all",
    });
    const after = result.blocks[0] as TableBlock;
    expect(after.confidence).toBe(0.3);
    expect(
      result.report.warnings.some((w) => w.code === "table_enhance_unparseable"),
    ).toBe(true);
  });
});
