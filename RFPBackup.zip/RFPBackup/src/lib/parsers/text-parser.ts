// text-parser.ts — handles Markdown (`.md`) and plain text (`.txt`).
//
// Markdown: minimal block-level walker. Recognized:
//   • ATX headings (#..######) and Setext (=== / --- underline)
//   • `- ` / `* ` / `+ ` unordered list items, `1. ` ordered list items
//     (indented to allow nesting up to 4 levels)
//   • Fenced code blocks (```lang ... ```)
//   • Blockquotes (`> `)
//   • Horizontal rules (--- / ***)
//   • GFM tables (`| h1 | h2 |` followed by `|---|---|`)
//   • Paragraphs (everything else, separated by blank lines)
//
// Plain text: split on blank lines into paragraphs. No structure.

import {
  anchorFor,
  detectLanguage,
  type Block,
  type DocumentAST,
  type DocumentParser,
  type ListItem,
  type ParseOptions,
  type ParseReport,
  type ParseWarning,
} from "./ast";
import { tableToMarkdown } from "./table-md";

export const TEXT_PARSER_VERSION = "text-2026-05-01";

const MD_MIMES = new Set(["text/markdown", "text/x-markdown"]);
const TXT_MIMES = new Set(["text/plain"]);

export const textParser: DocumentParser = {
  id: "md",
  version: TEXT_PARSER_VERSION,
  canParse(buffer, opts) {
    const mime = opts.mimeType?.toLowerCase() ?? "";
    if (MD_MIMES.has(mime) || TXT_MIMES.has(mime)) return true;
    if (opts.fileName?.match(/\.(md|markdown|txt)$/i)) return true;
    return false;
  },
  async parse(buffer, opts): Promise<DocumentAST> {
    return parseTextBuffer(buffer, opts);
  },
};

export async function parseTextBuffer(
  buffer: Buffer,
  opts: ParseOptions,
): Promise<DocumentAST> {
  const t0 = Date.now();
  const warnings: ParseWarning[] = [];
  const errors: ParseWarning[] = [];

  const text = buffer.toString("utf8");
  if (!text.trim()) {
    warnings.push({ code: "empty_input", message: "Text input is empty." });
    return emptyTextAst(t0, warnings, errors, "md");
  }

  const isMarkdown =
    opts.mimeType === "text/markdown" ||
    opts.mimeType === "text/x-markdown" ||
    !!opts.fileName?.match(/\.(md|markdown)$/i);
  const id: "md" | "txt" = isMarkdown ? "md" : "txt";

  const blocks: Block[] = [];
  let ordinal = 0;
  let title: string | undefined;
  const sectionStack: { level: number; text: string }[] = [];
  const sectionPath = () =>
    sectionStack.length ? sectionStack.map((s) => s.text).join(" / ") : undefined;
  const pushHeading = (level: number, headingText: string) => {
    while (sectionStack.length && sectionStack[sectionStack.length - 1].level >= level) {
      sectionStack.pop();
    }
    sectionStack.push({ level, text: headingText });
    const section = sectionPath();
    blocks.push({
      kind: "heading",
      level,
      text: headingText,
      section,
      anchor: anchorFor(section, ordinal++),
    });
    if (!title && level === 1) title = headingText;
  };
  type BlockNoAnchor =
    | { kind: "paragraph"; text: string }
    | { kind: "code"; code: string; language?: string }
    | { kind: "quote"; text: string }
    | { kind: "hr" }
    | { kind: "table"; headers?: string[]; rows: string[][]; markdown: string; confidence?: number }
    | { kind: "list"; ordered: boolean; items: ListItem[] };
  const pushBlock = (b: BlockNoAnchor) => {
    const section = sectionPath();
    blocks.push({ ...b, section, anchor: anchorFor(section, ordinal++) } as Block);
  };

  if (!isMarkdown) {
    // Plain text: blank-line-separated paragraphs.
    for (const para of text.split(/\n{2,}/)) {
      const trimmed = para.trim();
      if (!trimmed) continue;
      pushBlock({ kind: "paragraph", text: trimmed.replace(/\s+/g, " ") });
    }
  } else {
    parseMarkdown(text, {
      pushHeading,
      pushBlock,
    });
  }

  const allText = blocks
    .map((b) => ("text" in b ? (b as { text: string }).text : ""))
    .join(" ");
  const language = detectLanguage(allText) ?? undefined;

  const tableCount = blocks.filter((b) => b.kind === "table").length;
  const listCount = blocks.filter((b) => b.kind === "list").length;

  const report: ParseReport = {
    parser: id,
    parserVersion: TEXT_PARSER_VERSION,
    blockCount: blocks.length,
    tableCount,
    listCount,
    figureCount: 0,
    ocrUsed: false,
    parseMs: Date.now() - t0,
    warnings,
    errors,
  };

  return {
    metadata: {
      title,
      language,
      parser: id,
      parserVersion: TEXT_PARSER_VERSION,
    },
    blocks,
    report,
  };
}

// ---- Markdown walker --------------------------------------------------

interface MdSink {
  pushHeading(level: number, text: string): void;
  pushBlock(b: MdSinkBlock): void;
}

type MdSinkBlock =
  | { kind: "paragraph"; text: string }
  | { kind: "code"; code: string; language?: string }
  | { kind: "quote"; text: string }
  | { kind: "hr" }
  | { kind: "table"; headers?: string[]; rows: string[][]; markdown: string; confidence?: number }
  | { kind: "list"; ordered: boolean; items: ListItem[] };

function parseMarkdown(src: string, sink: MdSink): void {
  // Normalize line endings + strip BOM.
  const lines = src.replace(/^﻿/, "").replace(/\r\n?/g, "\n").split("\n");
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // Skip blank lines.
    if (line.trim() === "") {
      i += 1;
      continue;
    }

    // Fenced code block.
    const fence = line.match(/^(\s*)(```|~~~)\s*([\w.-]*)\s*$/);
    if (fence) {
      const closeFence = fence[2];
      const language = fence[3] || undefined;
      const codeLines: string[] = [];
      i += 1;
      while (i < lines.length) {
        if (new RegExp(`^\\s*${closeFence}\\s*$`).test(lines[i])) {
          i += 1;
          break;
        }
        codeLines.push(lines[i]);
        i += 1;
      }
      sink.pushBlock({ kind: "code", code: codeLines.join("\n"), language });
      continue;
    }

    // ATX heading.
    const atx = line.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/);
    if (atx) {
      sink.pushHeading(atx[1].length, atx[2].trim());
      i += 1;
      continue;
    }

    // Setext heading: line + underline.
    if (i + 1 < lines.length) {
      const next = lines[i + 1];
      if (line.trim() && /^\s{0,3}=+\s*$/.test(next)) {
        sink.pushHeading(1, line.trim());
        i += 2;
        continue;
      }
      if (line.trim() && /^\s{0,3}-{2,}\s*$/.test(next) && !/^\s*[-*+]\s/.test(line)) {
        sink.pushHeading(2, line.trim());
        i += 2;
        continue;
      }
    }

    // Horizontal rule.
    if (/^\s{0,3}(\*\s*){3,}\s*$|^\s{0,3}(-\s*){3,}\s*$|^\s{0,3}(_\s*){3,}\s*$/.test(line)) {
      sink.pushBlock({ kind: "hr" });
      i += 1;
      continue;
    }

    // Blockquote.
    if (/^\s{0,3}>/.test(line)) {
      const quoteLines: string[] = [];
      while (i < lines.length && /^\s{0,3}>/.test(lines[i])) {
        quoteLines.push(lines[i].replace(/^\s{0,3}>\s?/, ""));
        i += 1;
      }
      sink.pushBlock({ kind: "quote", text: quoteLines.join(" ").trim() });
      continue;
    }

    // GFM table: header row | separator row | body rows.
    if (line.includes("|") && i + 1 < lines.length && /^\s*\|?(\s*:?-+:?\s*\|)+\s*:?-+:?\s*\|?\s*$/.test(lines[i + 1])) {
      const headers = splitTableRow(line);
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && lines[i].includes("|") && lines[i].trim() !== "") {
        rows.push(splitTableRow(lines[i]));
        i += 1;
      }
      sink.pushBlock({
        kind: "table",
        headers,
        rows,
        markdown: tableToMarkdown(headers, rows),
        confidence: 0.95,
      });
      continue;
    }

    // List.
    if (/^\s*([-*+]|\d+\.)\s+/.test(line)) {
      const { items, ordered, consumed } = collectList(lines, i);
      sink.pushBlock({ kind: "list", ordered, items });
      i += consumed;
      continue;
    }

    // Paragraph: gather consecutive non-blank, non-special lines.
    const paraLines: string[] = [line];
    i += 1;
    while (i < lines.length) {
      const cur = lines[i];
      if (cur.trim() === "") break;
      if (/^\s{0,3}#{1,6}\s+/.test(cur)) break;
      if (/^\s{0,3}(```|~~~)/.test(cur)) break;
      if (/^\s{0,3}>/.test(cur)) break;
      if (/^\s*([-*+]|\d+\.)\s+/.test(cur)) break;
      paraLines.push(cur);
      i += 1;
    }
    sink.pushBlock({
      kind: "paragraph",
      text: paraLines.join(" ").replace(/\s+/g, " ").trim(),
    });
  }
}

function splitTableRow(line: string): string[] {
  let t = line.trim();
  if (t.startsWith("|")) t = t.slice(1);
  if (t.endsWith("|")) t = t.slice(0, -1);
  return t.split("|").map((c) => c.trim());
}

function collectList(
  lines: string[],
  start: number,
): { items: ListItem[]; ordered: boolean; consumed: number } {
  // Determine base indentation + ordered/unordered from first item.
  const first = lines[start];
  const firstMatch = first.match(/^(\s*)([-*+]|\d+\.)\s+(.*)$/);
  if (!firstMatch) {
    return { items: [], ordered: false, consumed: 1 };
  }
  const baseIndent = firstMatch[1].length;
  const ordered = /\d/.test(firstMatch[2]);

  const items: ListItem[] = [];
  let i = start;

  // Build a flat list of (indent, ordered, text) and rebuild hierarchy.
  interface FlatItem {
    indent: number;
    ordered: boolean;
    text: string;
  }
  const flat: FlatItem[] = [];

  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === "") {
      // Could be a list-end OR a blank between items. Peek ahead.
      if (i + 1 < lines.length && /^\s*([-*+]|\d+\.)\s+/.test(lines[i + 1])) {
        i += 1;
        continue;
      }
      break;
    }
    const m = line.match(/^(\s*)([-*+]|\d+\.)\s+(.*)$/);
    if (!m) {
      // Continuation of previous item if indented deeper.
      if (line.length > baseIndent && line.match(/^\s+/) && flat.length) {
        flat[flat.length - 1].text += " " + line.trim();
        i += 1;
        continue;
      }
      break;
    }
    if (m[1].length < baseIndent) break;
    flat.push({
      indent: m[1].length,
      ordered: /\d/.test(m[2]),
      text: m[3].trim(),
    });
    i += 1;
  }

  // Build a tree rooted at baseIndent. Items at the base indent become
  // top-level; deeper indented items become children of the most recent
  // item one level shallower.
  const stack: { indent: number; items: ListItem[] }[] = [
    { indent: baseIndent, items },
  ];
  for (const f of flat) {
    const node: ListItem = { text: f.text };
    while (stack.length > 1 && stack[stack.length - 1].indent > f.indent) {
      stack.pop();
    }
    if (f.indent > stack[stack.length - 1].indent) {
      // Nest under the last item of the current frame.
      const parentList = stack[stack.length - 1].items;
      const parent = parentList[parentList.length - 1];
      if (parent) {
        parent.children = parent.children ?? [];
        parent.children.push(node);
        stack.push({ indent: f.indent, items: parent.children });
        continue;
      }
    }
    stack[stack.length - 1].items.push(node);
  }

  return { items, ordered, consumed: i - start };
}

function emptyTextAst(
  t0: number,
  warnings: ParseWarning[],
  errors: ParseWarning[],
  id: "md" | "txt",
): DocumentAST {
  return {
    metadata: { parser: id, parserVersion: TEXT_PARSER_VERSION },
    blocks: [],
    report: {
      parser: id,
      parserVersion: TEXT_PARSER_VERSION,
      blockCount: 0,
      tableCount: 0,
      listCount: 0,
      figureCount: 0,
      ocrUsed: false,
      parseMs: Date.now() - t0,
      warnings,
      errors,
    },
  };
}
