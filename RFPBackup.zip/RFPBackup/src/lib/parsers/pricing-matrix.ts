// Pricing-matrix Excel parser/emitter.
//
// RFPs commonly ship pricing as an Excel grid: the leftmost column lists line
// items (rows) and each remaining column is a tier/quantity/region/SKU. The
// vendor's job is to fill in a price-per-cell answer. The standard text
// extractor (lib/parsers/index.ts -> parseExcel) loses this structure — it
// flattens every cell into a CSV blob suitable for retrieval but unsuitable
// for per-cell answer generation.
//
// This module preserves the grid as { headers, rows[].cells[] } so callers
// can:
//   - render the matrix in a per-cell editor,
//   - generate vendor answers cell-by-cell with AI,
//   - round-trip the completed grid back out to .xlsx for download.
//
// Conventions:
//   - First non-empty sheet wins. RFP authors sometimes leave a blank "Sheet1"
//     before the actual matrix; we scan past it.
//   - First non-empty row of that sheet is the header row.
//   - First column of every subsequent row is the row label; remaining columns
//     are cells. The number of cells per row is fixed at headers.length - 1
//     (we pad short rows with empty cells so the table is rectangular — the
//     UI assumes this).
//   - Trailing blank rows and trailing blank columns are dropped. We keep
//     interior blank rows because they may be intentional spacing.
//   - On emit, prefer `value` (the original vendor input from the source
//     file) over `generated` — `value` is the source of truth; `generated`
//     is the AI's draft.
//
// xlsx is already a project dependency (used by parseExcel in index.ts).

import * as XLSX from "xlsx";

export interface PricingCell {
  /** Pre-filled vendor input from the source file. Source of truth. */
  value?: string;
  /** AI-generated draft answer (from generateMatrixCell). */
  generated?: string;
  /** ISO-8601 timestamp of the most recent generation. */
  generatedAt?: string;
  /** 0..1 confidence score from the generator. */
  confidence?: number;
}

export interface PricingRow {
  /** First column of the row — typically the line item / SKU name. */
  label: string;
  /** Remaining columns. Length = headers.length - 1. */
  cells: PricingCell[];
}

export interface PricingMatrix {
  /** Column labels including the leftmost label-column header. */
  headers: string[];
  rows: PricingRow[];
}

/**
 * Parse an .xlsx file into the typed pricing-matrix shape. Best-effort:
 * an empty workbook returns `{ headers: [], rows: [] }` rather than
 * throwing — callers can present an empty editor.
 */
export async function parseMatrixXlsx(buffer: Buffer): Promise<PricingMatrix> {
  const wb = XLSX.read(buffer, { type: "buffer" });
  const sheet = pickFirstNonEmptySheet(wb);
  if (!sheet) return { headers: [], rows: [] };

  // header:1 returns each row as an array of cell values (rather than an
  // object keyed by the header row). We do header detection ourselves so
  // blank-leading-row workbooks still parse cleanly. defval: "" coerces
  // empty cells to "" so column indices align.
  const grid = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
    header: 1,
    defval: "",
    blankrows: true,
  });

  // Normalize every cell to a string; XLSX may return numbers / dates /
  // booleans depending on the cell type.
  const normalized: string[][] = grid.map((row) =>
    Array.isArray(row) ? row.map((c) => stringifyCell(c)) : [],
  );

  const trimmed = trimTrailingBlankRowsAndCols(normalized);
  if (trimmed.length === 0) return { headers: [], rows: [] };

  // First non-empty row = headers. We skip leading blank rows so a workbook
  // that opens with an empty title row still parses.
  let headerIdx = 0;
  while (headerIdx < trimmed.length && rowIsBlank(trimmed[headerIdx]!)) {
    headerIdx++;
  }
  if (headerIdx >= trimmed.length) return { headers: [], rows: [] };

  const headers = trimmed[headerIdx]!.map((h) => h.trim());
  // Drop trailing blank header columns (we already trimmed grid-wide, but the
  // header row may have its own trailing blanks if a body row was wider).
  while (headers.length > 0 && headers[headers.length - 1] === "") {
    headers.pop();
  }
  if (headers.length === 0) return { headers: [], rows: [] };

  const cellCount = Math.max(0, headers.length - 1);
  const rows: PricingRow[] = [];
  for (let i = headerIdx + 1; i < trimmed.length; i++) {
    const row = trimmed[i]!;
    if (rowIsBlank(row)) continue;
    const label = (row[0] ?? "").trim();
    // A row with no label and no body content is dropped; a row with a label
    // but blank cells is kept — the user may want to fill it in.
    const bodyCells: PricingCell[] = [];
    for (let c = 0; c < cellCount; c++) {
      const raw = (row[c + 1] ?? "").trim();
      bodyCells.push(raw ? { value: raw } : {});
    }
    if (!label && bodyCells.every((cell) => !cell.value)) continue;
    rows.push({ label, cells: bodyCells });
  }

  return { headers, rows };
}

/**
 * Serialise the matrix back to .xlsx. Round-trip stable for the
 * { headers, rows[].label, rows[].cells[].value } subset — generated
 * answers fall through into `value` slots only when no source value
 * exists for that cell.
 */
export function emitMatrixXlsx(matrix: PricingMatrix): Buffer {
  const aoa: string[][] = [];
  aoa.push([...matrix.headers]);
  const cellCount = Math.max(0, matrix.headers.length - 1);
  for (const row of matrix.rows) {
    const out: string[] = [row.label ?? ""];
    for (let c = 0; c < cellCount; c++) {
      const cell = row.cells[c];
      if (!cell) {
        out.push("");
        continue;
      }
      if (cell.value !== undefined && cell.value !== "") {
        out.push(cell.value);
      } else if (cell.generated !== undefined && cell.generated !== "") {
        out.push(cell.generated);
      } else {
        out.push("");
      }
    }
    aoa.push(out);
  }
  const sheet = XLSX.utils.aoa_to_sheet(aoa);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, sheet, "Pricing");
  // type "buffer" with bookType "xlsx" is the round-trip-friendly combo.
  const out = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
  return Buffer.isBuffer(out) ? out : Buffer.from(out);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function pickFirstNonEmptySheet(wb: XLSX.WorkBook): XLSX.WorkSheet | null {
  for (const name of wb.SheetNames) {
    const sheet = wb.Sheets[name];
    if (!sheet) continue;
    // !ref is undefined for truly empty sheets.
    if (!sheet["!ref"]) continue;
    const sample = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
      header: 1,
      defval: "",
      blankrows: false,
    });
    if (sample.length > 0 && sample.some((r) => Array.isArray(r) && r.some((c) => stringifyCell(c) !== ""))) {
      return sheet;
    }
  }
  return null;
}

function stringifyCell(c: unknown): string {
  if (c == null) return "";
  if (typeof c === "string") return c;
  if (typeof c === "number") return Number.isFinite(c) ? String(c) : "";
  if (typeof c === "boolean") return c ? "TRUE" : "FALSE";
  if (c instanceof Date) return c.toISOString();
  return String(c);
}

function rowIsBlank(row: string[]): boolean {
  return row.every((c) => c.trim() === "");
}

/**
 * Drop trailing all-blank rows AND trailing all-blank columns. We use the
 * widest row (after trimming trailing blank rows) to size the column count
 * so short rows pad rather than truncating the grid.
 */
function trimTrailingBlankRowsAndCols(grid: string[][]): string[][] {
  // Trailing blank rows.
  let lastRow = grid.length - 1;
  while (lastRow >= 0 && rowIsBlank(grid[lastRow]!)) lastRow--;
  if (lastRow < 0) return [];
  const rows = grid.slice(0, lastRow + 1);

  // Determine the rightmost column with any content across all rows.
  let lastCol = -1;
  for (const r of rows) {
    for (let c = r.length - 1; c > lastCol; c--) {
      if ((r[c] ?? "").trim() !== "") {
        lastCol = c;
        break;
      }
    }
  }
  if (lastCol < 0) return [];

  return rows.map((r) => {
    const padded = r.slice(0, lastCol + 1);
    while (padded.length < lastCol + 1) padded.push("");
    return padded;
  });
}
