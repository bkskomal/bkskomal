import { describe, it, expect } from "vitest";
import { parseTextBuffer } from "./text-parser";
import { astToMarkdown } from "./ast";

const buf = (s: string) => Buffer.from(s, "utf8");

describe("textParser (md + txt)", () => {
  it("returns empty AST + warning for empty input", async () => {
    const ast = await parseTextBuffer(buf(""), { fileName: "x.md" });
    expect(ast.blocks).toEqual([]);
    expect(ast.report.warnings.some((w) => w.code === "empty_input")).toBe(true);
  });

  it("parses a simple Markdown doc", async () => {
    const md = `# Title

Para one.

## Sub

- a
- b
- c
`;
    const ast = await parseTextBuffer(buf(md), { fileName: "x.md" });
    expect(ast.metadata.title).toBe("Title");
    const kinds = ast.blocks.map((b) => b.kind);
    expect(kinds).toContain("heading");
    expect(kinds).toContain("paragraph");
    expect(kinds).toContain("list");
    const md2 = astToMarkdown(ast);
    expect(md2).toContain("# Title");
    expect(md2).toMatch(/-\s+a/);
  });

  it("parses fenced code blocks with language", async () => {
    const md = "```python\nprint('hi')\n```\n";
    const ast = await parseTextBuffer(buf(md), { fileName: "x.md" });
    const code = ast.blocks.find((b) => b.kind === "code");
    if (code?.kind !== "code") throw new Error("nope");
    expect(code.language).toBe("python");
    expect(code.code).toBe("print('hi')");
  });

  it("parses GFM tables", async () => {
    const md = `| A | B |
|---|---|
| 1 | 2 |
| 3 | 4 |
`;
    const ast = await parseTextBuffer(buf(md), { fileName: "x.md" });
    const t = ast.blocks.find((b) => b.kind === "table");
    if (t?.kind !== "table") throw new Error("nope");
    expect(t.headers).toEqual(["A", "B"]);
    expect(t.rows).toEqual([
      ["1", "2"],
      ["3", "4"],
    ]);
  });

  it("parses nested lists", async () => {
    const md = `- a
  - a.1
  - a.2
- b
`;
    const ast = await parseTextBuffer(buf(md), { fileName: "x.md" });
    const list = ast.blocks.find((b) => b.kind === "list");
    if (list?.kind !== "list") throw new Error("nope");
    expect(list.items).toHaveLength(2);
    expect(list.items[0].children).toHaveLength(2);
  });

  it("parses blockquotes", async () => {
    const md = `> First line\n> Second line\n`;
    const ast = await parseTextBuffer(buf(md), { fileName: "x.md" });
    const q = ast.blocks.find((b) => b.kind === "quote");
    if (q?.kind !== "quote") throw new Error("nope");
    expect(q.text).toContain("First line");
  });

  it("treats .txt as paragraphs split on blank lines", async () => {
    const txt = `Hello world.\n\nSecond paragraph here.\n\nThird.`;
    const ast = await parseTextBuffer(buf(txt), { fileName: "x.txt" });
    expect(ast.metadata.parser).toBe("txt");
    const paras = ast.blocks.filter((b) => b.kind === "paragraph");
    expect(paras).toHaveLength(3);
  });

  it("round-trips through astToMarkdown", async () => {
    const md = `# H1\n\npara\n\n- one\n- two\n`;
    const ast = await parseTextBuffer(buf(md), { fileName: "x.md" });
    const rendered = astToMarkdown(ast);
    expect(rendered).toContain("# H1");
    expect(rendered).toContain("para");
    expect(rendered).toMatch(/-\s+one/);
  });
});
