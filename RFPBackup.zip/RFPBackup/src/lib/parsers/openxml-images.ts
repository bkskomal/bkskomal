// Extract embedded images from any OpenXML container (xlsx, pptx, docx).
//
// OpenXML files are ZIP archives. Embedded images live under conventional
// paths:
//   word/media/image*.png|jpg|...   (DOCX — already handled by mammoth)
//   xl/media/image*.png|jpg|...     (XLSX)
//   ppt/media/image*.png|jpg|...    (PPTX)
//
// We just walk the ZIP, pull anything under those media folders, sniff the
// mime type from the extension, and return raw bytes. The format-specific
// parsers wrap each entry as a FigureBlock with `imageBuffer` so the
// pipeline's CLIP step picks them up like any other inline image.

import JSZip from "jszip";

export interface ExtractedImage {
  /** Path inside the OpenXML container (e.g. `xl/media/image1.png`). Used
   *  as a stable hint for the figure's caption when no other label exists. */
  zipPath: string;
  /** Image bytes ready for image-store + CLIP encode. */
  buffer: Buffer;
  /** Inferred from the file extension. */
  mimeType: string;
  /** Detected slide / sheet index when extractable from the path. Best-effort. */
  index?: number;
}

const MIME_BY_EXT: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  bmp: "image/bmp",
  webp: "image/webp",
  tiff: "image/tiff",
  tif: "image/tiff",
  svg: "image/svg+xml",
  emf: "image/x-emf",
  wmf: "image/x-wmf",
};

const MEDIA_PREFIXES: Record<"xlsx" | "pptx" | "docx", RegExp> = {
  xlsx: /^xl\/media\//i,
  pptx: /^ppt\/media\//i,
  docx: /^word\/media\//i,
};

export interface ExtractImagesOptions {
  format: "xlsx" | "pptx" | "docx";
  /** Cap on how many images to extract per document. Default 30. */
  maxImages?: number;
}

export async function extractImagesFromOpenXml(
  buffer: Buffer,
  opts: ExtractImagesOptions,
): Promise<ExtractedImage[]> {
  const max = opts.maxImages ?? 30;
  const prefix = MEDIA_PREFIXES[opts.format];
  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(buffer);
  } catch {
    // Not a valid zip — caller should treat as "no images".
    return [];
  }

  const out: ExtractedImage[] = [];
  const entries = Object.values(zip.files)
    .filter((f) => !f.dir && prefix.test(f.name))
    .sort((a, b) => a.name.localeCompare(b.name));

  for (const entry of entries) {
    if (out.length >= max) break;
    const ext = entry.name.split(".").pop()?.toLowerCase() ?? "";
    const mimeType = MIME_BY_EXT[ext];
    // Skip vector formats (svg/emf/wmf) and unknowns — CLIP encoder needs
    // raster bytes; we'd need rasterization (sharp can do svg, not emf/wmf).
    // For now, only surface the formats CLIP can consume directly.
    if (!mimeType || !["image/png", "image/jpeg", "image/gif", "image/bmp", "image/webp", "image/tiff"].includes(mimeType)) {
      continue;
    }
    try {
      const data = await entry.async("nodebuffer");
      out.push({
        zipPath: entry.name,
        buffer: data,
        mimeType,
      });
    } catch {
      // Single-entry failure shouldn't kill the rest.
      continue;
    }
  }
  return out;
}
