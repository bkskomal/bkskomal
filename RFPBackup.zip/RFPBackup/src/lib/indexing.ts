import { readFile } from "node:fs/promises";
import { prisma } from "@/lib/prisma";
import { parseAndProcess } from "@/lib/parsers/pipeline";
import { PARSER_PIPELINE_VERSION } from "@/lib/parsers/parse";
import { semanticChunk, type ChunkOut } from "@/lib/parsers/chunker";
import { anchorFor, detectLanguage } from "@/lib/parsers/ast";
import { embed } from "@/lib/ai/embeddings";
import { encodeSparse } from "@/lib/ai/sparse";
import { resolveAiConfig } from "@/lib/ai/config";
import { contextualizeChunks } from "@/lib/ai/contextual-chunks";
import { vectorStoreResolver } from "@/lib/ai/vector";
import type { ChunkVec, ImageVec, VectorStoreImages } from "@/lib/ai/vector/types";
import { Prisma } from "@prisma/client";
import { detectSourceDate } from "@/lib/sources/extract-date";
import { evaluateStaleness } from "@/lib/sources/staleness";
import { log } from "@/lib/logger";

export async function ingestDocument(documentId: string): Promise<void> {
  const doc = await prisma.document.findUnique({
    where: { id: documentId },
    include: { index: { select: { organizationId: true } } },
  });
  if (!doc) throw new Error("Document not found");
  const orgId = doc.index.organizationId;

  await prisma.document.update({
    where: { id: documentId },
    data: { status: "PROCESSING", errorMessage: null },
  });

  try {
    const buffer = await readFile(doc.storagePath);
    // Scraped HTML pages don't benefit from per-image vision OCR — the page
    // text is already extracted, and running GPT-4o-mini against each of 20+
    // marketing images burns ~30s + dozens of LLM calls per URL with little
    // payoff. Disable OCR for URL-ingested docs; CLIP embeddings still get
    // produced so visual similarity search remains intact.
    const isScrapedHtml =
      doc.mimeType === "text/html" && doc.sourceUrl !== null && doc.sourceUrl !== undefined;
    const { text, ast, chunks, quality, images } = await parseAndProcess(
      buffer,
      doc.mimeType,
      doc.fileName,
      {
        organizationId: orgId,
        enableOcr: !isScrapedHtml,
      },
    );

    // Wipe any prior chunks (in case of re-index) so the section/anchor
    // updates land cleanly. Image embeddings cascade-delete via the
    // chunk relation when chunkId is set, but for safety we also drop any
    // orphan ImageEmbedding rows for this document below before re-inserting.
    await prisma.documentChunk.deleteMany({ where: { documentId } });
    await prisma.imageEmbedding.deleteMany({ where: { documentId } });

    // Two-phase write: create the chunk row WITHOUT the embedding, then hand
    // the embeddings to the per-org VectorStore (or both backends in
    // dual-write mode). For Postgres the store just patches the embedding
    // column → identical end state to the legacy single-write path. For
    // Milvus / dual-write the embedding fans out to the right backends.
    const chunkVecs: ChunkVec[] = [];
    const chunkContents = new Map<string, string>();
    // Anchor → chunk row id, so we can link figure ImageEmbedding rows back
    // to their parent text chunk for citation/UI joins.
    const figureChunkIdByAnchor = new Map<string, string>();

    // Phase B.3: contextual retrieval. When the org enabled it, generate a
    // 1-sentence context blurb per chunk and PREPEND it to the text before
    // embedding. The DB row keeps the original `piece.content` so the viewer
    // shows the actual chunk text — only the embedding sees the contextualized
    // version. Per-chunk failures degrade silently to the pre-B.3 path
    // (embed the raw chunk).
    const ragCfg = (await resolveAiConfig(orgId)).retrieval;
    const contextBlurbs: string[] = ragCfg.contextualEnabled
      ? await contextualizeChunks(text, chunks, orgId)
      : [];
    if (ragCfg.contextualEnabled) {
      const nonEmpty = contextBlurbs.filter((b) => b.length > 0).length;
      log().info(
        { orgId, documentId, totalChunks: chunks.length, contextBlurbs: nonEmpty },
        "indexing: contextual retrieval applied",
      );
    }

    for (let i = 0; i < chunks.length; i++) {
      const piece = chunks[i]!;
      const blurb = contextBlurbs[i] ?? "";
      const embedText = blurb ? `${blurb}\n\n${piece.content}` : piece.content;
      const vec = await embed(embedText, orgId);
      const row = await prisma.documentChunk.create({
        data: {
          documentId,
          ordinal: piece.ordinal,
          content: piece.content,
          page: piece.page ?? null,
          section: piece.section ?? null,
          kind: piece.kind,
          anchor: piece.anchor,
          // Embedding is written by the VectorStore upsert below.
          embedding: [],
        },
        select: { id: true },
      });
      chunkVecs.push({
        id: row.id,
        embedding: vec,
        metadata: {
          documentId,
          indexId: doc.indexId,
          organizationId: orgId,
          section: piece.section ?? undefined,
          kind: piece.kind ?? undefined,
          page: piece.page ?? undefined,
          anchor: piece.anchor ?? undefined,
        },
      });
      chunkContents.set(row.id, piece.content);
      if (piece.kind === "figure" && piece.anchor) {
        figureChunkIdByAnchor.set(piece.anchor, row.id);
      }
    }

    if (chunkVecs.length > 0) {
      const writers = await vectorStoreResolver.writersForOrg(orgId);
      // Native hybrid (Phase V): if any writer supports sparse-vector hybrid
      // search, attach a BM25-style sparse vector per chunk so Milvus can
      // fuse dense+sparse server-side. Postgres ignores `sparseEmbedding`,
      // so attaching it is harmless when both backends co-exist (dual-write).
      const enriched = await maybeAttachSparse(chunkVecs, chunkContents, orgId, writers);
      await Promise.all(writers.map((w) => w.upsert(enriched)));
    }

    // --- Image embeddings (Phase IM) ---
    // For each PreparedImage produced by the parser pipeline: write the
    // ImageEmbedding row. Failures are logged and swallowed — multimodal
    // ingest is a soft contract, not blocking for the text path.
    if (images && images.length > 0) {
      const persistedImageVecs: ImageVec[] = [];
      for (const img of images) {
        try {
          const chunkId = figureChunkIdByAnchor.get(img.figureAnchor) ?? null;
          const row = await prisma.imageEmbedding.create({
            data: {
              organizationId: orgId,
              indexId: doc.indexId,
              documentId,
              chunkId,
              vector: img.vector,
              imagePath: img.imagePath,
              mimeType: img.mimeType,
              page: img.page ?? null,
              ocrText: img.ocrText ?? null,
              caption: img.caption ?? null,
              width: img.width ?? null,
              height: img.height ?? null,
            },
          });
          persistedImageVecs.push({
            id: row.id,
            vector: img.vector,
            metadata: {
              organizationId: orgId,
              indexId: doc.indexId,
              documentId,
              chunkId: chunkId ?? undefined,
              imagePath: img.imagePath,
              mimeType: img.mimeType,
              page: img.page ?? undefined,
              caption: img.caption ?? undefined,
              ocrText: img.ocrText ?? undefined,
              width: img.width ?? undefined,
              height: img.height ?? undefined,
            },
          });
        } catch (err) {
          log().warn(
            {
              err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
              documentId,
              orgId,
              imagePath: img.imagePath,
            },
            "image embedding persistence failed; continuing",
          );
        }
      }

      // Mirror image vectors into the per-org vector backend(s). For Postgres
      // backend this is a no-op-equivalent (the rows we just wrote ARE the
      // store). For Milvus, this populates the images collection. Dual-write
      // mode (vectorDualWrite=true) fans out to both. Failures swallowed —
      // the Postgres rows above are the source of truth.
      try {
        const writers = await vectorStoreResolver.writersForOrg(orgId);
        const imageWriters = writers.filter(
          (w): w is typeof w & VectorStoreImages =>
            "supportsImages" in w && (w as Partial<VectorStoreImages>).supportsImages === true &&
            typeof (w as Partial<VectorStoreImages>).upsertImages === "function",
        );
        if (imageWriters.length > 0 && persistedImageVecs.length > 0) {
          await Promise.all(imageWriters.map((w) => w.upsertImages(persistedImageVecs)));
        }
      } catch (err) {
        log().warn(
          {
            err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
            documentId,
            orgId,
            imageCount: persistedImageVecs.length,
          },
          "image vector-store mirror failed; Postgres rows still persisted",
        );
      }
    }

    // --- Stale-source detection (Tier B2) ---
    // Best-effort: extract the document's "as of" date and evaluate it against
    // the org's staleness rule. We use the cheap filename → body-regex path
    // here (useLLM: false) so a chatty extractor doesn't slow every upload.
    // Any failure inside this block is logged and swallowed — date extraction
    // is a UX nicety, not a correctness requirement for indexing.
    let sourceDate: Date | null = null;
    let staleReason: string | null = null;
    try {
      const extracted = await detectSourceDate({
        fileName: doc.fileName,
        text,
        orgId,
        useLLM: false,
      });
      if (extracted) {
        sourceDate = extracted.date;
      }
      const verdict = evaluateStaleness({
        sourceDate,
        fileName: doc.fileName,
      });
      if (verdict.isStale && verdict.reason) {
        staleReason = verdict.reason;
      }
    } catch (err) {
      log().warn(
        {
          err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
          documentId,
          orgId,
        },
        "source-date extraction failed; continuing without staleness metadata",
      );
    }

    // Persist parser-pipeline metadata alongside the canonical document row.
    // `parserVersion` carries the pipeline version (not the format-specific
    // parser version) so a future pipeline upgrade triggers re-ingest of
    // everything below that line. `parseReport` is serialized to JSON via
    // Prisma's automatic structured-data handling — the shape mirrors
    // `DocumentAST.report` plus the chunk count for convenience.
    const language = ast.metadata.language ?? detectLanguage(text) ?? null;
    await prisma.document.update({
      where: { id: documentId },
      data: {
        status: "INDEXED",
        sourceDate,
        staleReason,
        parserVersion: PARSER_PIPELINE_VERSION,
        parseQuality: quality.score,
        parseReport: {
          parser: ast.report.parser,
          parserVersion: ast.report.parserVersion,
          pageCount: ast.report.pageCount ?? null,
          blockCount: ast.report.blockCount,
          tableCount: ast.report.tableCount,
          listCount: ast.report.listCount,
          figureCount: ast.report.figureCount,
          ocrUsed: ast.report.ocrUsed,
          ocrConfidence: ast.report.ocrConfidence ?? null,
          parseMs: ast.report.parseMs,
          ocrMs: ast.report.ocrMs ?? null,
          warnings: ast.report.warnings.map((w) => ({
            code: w.code,
            message: w.message,
            context: (w.context ?? null) as Prisma.InputJsonValue | null,
          })),
          errors: ast.report.errors.map((w) => ({
            code: w.code,
            message: w.message,
            context: (w.context ?? null) as Prisma.InputJsonValue | null,
          })),
          qualityReasons: quality.reasons.map((r) => ({
            code: r.code,
            impact: r.impact,
            weight: r.weight,
            detail: r.detail ?? null,
          })),
          chunkCount: chunks.length,
        } as Prisma.InputJsonValue,
        language,
      },
    });
  } catch (e) {
    await prisma.document.update({
      where: { id: documentId },
      data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
    });
    throw e;
  }
}

/**
 * Ingest a Document whose content is a single pre-parsed text block (no
 * parser pipeline). Used by the external ingest API when an upstream ETL
 * step (NiFi/Airflow/n8n) has already converted the source to plain text.
 *
 * The flow is the same as ingestDocument from the chunking step onward:
 * semantic chunker → embed → write through vectorStoreResolver. Skipping
 * parsing means we don't have an AST, so parser-pipeline metadata fields
 * are left null (and the language is detected directly from the text).
 */
export async function ingestDocumentFromContent(
  documentId: string,
  content: string,
): Promise<void> {
  const doc = await prisma.document.findUnique({
    where: { id: documentId },
    include: { index: { select: { organizationId: true } } },
  });
  if (!doc) throw new Error("Document not found");
  const orgId = doc.index.organizationId;

  await prisma.document.update({
    where: { id: documentId },
    data: { status: "PROCESSING", errorMessage: null },
  });

  try {
    // Build a minimal one-paragraph AST so the chunker has something to
    // operate on. The chunker will produce one chunk per logical block; for
    // small content this is exactly one chunk.
    const ast = {
      metadata: { parser: "txt" as const, parserVersion: PARSER_PIPELINE_VERSION },
      blocks: [
        {
          kind: "paragraph" as const,
          text: content,
          anchor: anchorFor(undefined, 0),
        },
      ],
      report: {
        parser: "txt" as const,
        parserVersion: PARSER_PIPELINE_VERSION,
        blockCount: 1,
        tableCount: 0,
        listCount: 0,
        figureCount: 0,
        ocrUsed: false,
        parseMs: 0,
        warnings: [],
        errors: [],
      },
    };
    const chunks: ChunkOut[] = semanticChunk(ast);

    await prisma.documentChunk.deleteMany({ where: { documentId } });

    const chunkVecs: ChunkVec[] = [];
    const chunkContents = new Map<string, string>();
    for (const piece of chunks) {
      const vec = await embed(piece.content, orgId);
      const row = await prisma.documentChunk.create({
        data: {
          documentId,
          ordinal: piece.ordinal,
          content: piece.content,
          page: piece.page ?? null,
          section: piece.section ?? null,
          kind: piece.kind,
          anchor: piece.anchor,
          embedding: [],
        },
        select: { id: true },
      });
      chunkVecs.push({
        id: row.id,
        embedding: vec,
        metadata: {
          documentId,
          indexId: doc.indexId,
          organizationId: orgId,
          section: piece.section ?? undefined,
          kind: piece.kind ?? undefined,
          page: piece.page ?? undefined,
          anchor: piece.anchor ?? undefined,
        },
      });
      chunkContents.set(row.id, piece.content);
    }

    if (chunkVecs.length > 0) {
      const writers = await vectorStoreResolver.writersForOrg(orgId);
      const enriched = await maybeAttachSparse(chunkVecs, chunkContents, orgId, writers);
      await Promise.all(writers.map((w) => w.upsert(enriched)));
    }

    await prisma.document.update({
      where: { id: documentId },
      data: {
        status: "INDEXED",
        parserVersion: PARSER_PIPELINE_VERSION,
        // No parser pipeline ran — leave parseQuality / parseReport null.
        language: detectLanguage(content) ?? null,
      },
    });
  } catch (e) {
    await prisma.document.update({
      where: { id: documentId },
      data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
    });
    throw e;
  }
}

/**
 * If any writer in the pool supports native hybrid search, attach a sparse
 * BM25-style vector to each chunk. The encoder is fast (in-process, hashed),
 * so we Promise.all over chunks rather than serialising. When no writer
 * supports hybrid we return the original array unchanged — saving the work.
 *
 * Postgres ignores `sparseEmbedding`, so attaching it once and handing the
 * same enriched array to every writer is safe in dual-write mode.
 */
export async function maybeAttachSparse(
  chunks: ChunkVec[],
  contents: Map<string, string>,
  orgId: string,
  writers: { supportsHybrid: boolean }[],
): Promise<ChunkVec[]> {
  if (!writers.some((w) => w.supportsHybrid)) return chunks;
  try {
    return await Promise.all(
      chunks.map(async (c) => {
        const text = contents.get(c.id);
        if (!text) return c;
        const sparse = await encodeSparse(text, orgId);
        return { ...c, sparseEmbedding: sparse };
      }),
    );
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        orgId,
      },
      "sparse encode failed during ingest; proceeding with dense only",
    );
    return chunks;
  }
}
