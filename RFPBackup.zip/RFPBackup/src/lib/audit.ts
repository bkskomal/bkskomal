// Audit logging for sensitive operations.
//
// Append-only trail of security-relevant actions: auth events, API-key
// changes, member changes, deletions, exports. Read it back via the
// /api/orgs/[orgId]/audit-log endpoint (admin-only).
//
// Design contract:
//   * Fire-and-forget — callers do `void audit({...})` and continue. The
//     request must NEVER block on the audit write.
//   * Errors are caught and logged at warn level, then swallowed. A failure
//     to record an audit event must not break the user-facing operation.
//   * No foreign keys on the table — entries outlive the actors and orgs
//     they reference (compliance: deleting a user must not retro-erase the
//     audit trail of what they did).

import type { NextRequest } from "next/server";
import { prisma } from "./prisma";
import { log } from "./logger";

export type AuditEvent =
  | "USER_SIGNED_IN"
  | "USER_SIGNED_OUT"
  | "ORG_CREATED"
  | "ORG_DELETED"
  | "MEMBER_INVITED"
  | "MEMBER_REMOVED"
  | "MEMBER_ROLE_CHANGED"
  | "API_KEY_SET"
  | "API_KEY_ROTATED"
  | "API_KEY_VIEWED"
  | "API_KEY_CREATED"
  | "API_KEY_REVOKED"
  | "API_KEY_USED"
  | "RFP_DELETED"
  | "RFP_EXPORTED"
  | "RFP_OUTCOME_SET"
  | "RFP_ATTACHMENT_ADDED"
  | "RFP_ATTACHMENT_REMOVED"
  | "RFP_ATTACHMENT_RECLASSIFIED"
  | "INDEX_DELETED"
  | "PIPELINE_PAUSED"
  | "PIPELINE_RESUMED"
  | "PIPELINE_STOPPED"
  | "PIPELINE_EDITED"
  | "MODEL_PULLED"
  | "RESPONSE_REGROUNDED"
  // --- Pricing matrix (Phase 3A) ---
  | "MATRIX_CELL_UPDATED"
  | "MATRIX_GENERATED"
  | "MATRIX_EXPORTED"
  // --- Semantic answer cache (Phase 3C) ---
  | "CACHE_INVALIDATED"
  | "CACHE_PURGED"
  // --- Slack integration (Tier B1) ---
  | "SLACK_INTEGRATION_CONFIGURED"
  | "SLACK_INTEGRATION_REMOVED"
  // --- Collaborative edit awareness (Tier B4) ---
  // Recorded when an editor commits their soft-lock-protected draft to
  // Response.content via the finalize route. Captures the previous and
  // new version so the audit log shows who clobbered what during a
  // disputed merge.
  | "RESPONSE_COMMITTED"
  // --- SAML SSO (Tier B3) ---
  // SAML_SIGN_IN: an end-user completed the SAML callback flow successfully.
  // SAML_CONFIGURED: an admin saved the org's SAML IdP settings.
  // SAML_REMOVED: an admin disconnected SAML for the org.
  | "SAML_SIGN_IN"
  | "SAML_CONFIGURED"
  | "SAML_REMOVED"
  // --- Stale-source detection (Tier B2) ---
  // Recorded when an admin re-runs `refreshStalenessForOrg` (e.g. after
  // bumping the threshold env var). Metadata carries `{ scanned, flagged }`.
  | "SOURCE_STALENESS_REFRESHED"
  // --- Auto-extracted evaluation rubric ---
  // RUBRIC_EXTRACTED:  the buyer's evaluation criteria were (re-)extracted
  //                    from the RFP rawText. Metadata carries
  //                    { criteriaCount, extractionConfidence }.
  // RUBRIC_SCORED:     responses were scored against the stored rubric.
  //                    Metadata carries { totalScore, weakestCriteria }.
  // RUBRIC_OVERRIDDEN: an admin manually replaced the criteria via the
  //                    Edit-criteria modal. Metadata carries
  //                    { criteriaCount }.
  // RUBRIC_REMOVED:    an admin deleted the rubric (admin-only DELETE route).
  | "RUBRIC_EXTRACTED"
  | "RUBRIC_SCORED"
  | "RUBRIC_OVERRIDDEN"
  | "RUBRIC_REMOVED"
  // --- Predictive win scoring (Tier C — moonshot) ---
  // WIN_PREDICTION_RESCORED: an admin re-ran the scorer on an RFP via the
  //                          POST route. Metadata carries
  //                          { probability, recommendation, previousRecommendation }.
  // WIN_PREDICTION_OVERRIDDEN: an admin pinned overrideAction to go/no_bid
  //                            (or cleared it). Metadata carries
  //                            { action: "go" | "no_bid" | null }.
  | "WIN_PREDICTION_RESCORED"
  | "WIN_PREDICTION_OVERRIDDEN"
  // --- LoRA adapter (Tier C3) ---
  // LORA_DATASET_EXPORTED: an admin downloaded a goldens / approved-responses
  //   JSONL training file. Metadata carries `{ kind, exampleCount, filename }`.
  // LORA_ADAPTER_CONFIGURED: an admin saved (or cleared) the org's adapter
  //   URL + meta. Metadata carries `{ adapterUrl, baseModel? }`. The URL is
  //   a model identifier, not a secret, so we record it verbatim.
  // LORA_ADAPTER_TESTED: an admin invoked the "Test this adapter" route.
  //   Metadata carries `{ model, ms, ok }` — useful for debugging "did the
  //   fine-tune actually serve a response?" reports.
  | "LORA_DATASET_EXPORTED"
  | "LORA_ADAPTER_CONFIGURED"
  | "LORA_ADAPTER_TESTED"
  // --- External ingest API (Phase V — NiFi/Airflow/n8n entry point) ---
  // EXTERNAL_INGEST_DOCUMENTS: an external ETL pipeline pushed one or more
  //   docs via POST /api/indexes/:id/external/documents. Metadata carries
  //   `{ count, mode: "content" | "base64" | "mixed" }`.
  // EXTERNAL_INGEST_CHUNKS: an external pipeline pushed pre-embedded chunks
  //   directly to the vector store via POST /external/chunks. Metadata
  //   carries `{ count, errors }`.
  // EXTERNAL_DELETE_DOCUMENT: a single doc + its chunks were removed via
  //   DELETE /external/documents/:documentId.
  | "EXTERNAL_INGEST_DOCUMENTS"
  | "EXTERNAL_INGEST_CHUNKS"
  | "EXTERNAL_DELETE_DOCUMENT"
  // --- Vector backend (Phase V) ---
  // VECTOR_BACKEND_CONFIGURED: an admin saved the org's vector backend
  //   selection (PUT /api/orgs/:orgId/vector). Metadata carries the new
  //   backend, isolation strategy, dual-write flag, and a token-prefix
  //   summary — never the plaintext token.
  // VECTOR_BACKEND_RESET: an admin reverted the org to the Postgres default
  //   (DELETE on the same route). Metadata is empty.
  // VECTOR_BACKEND_TESTED: an admin pressed "Test connection" against a
  //   prospective Milvus URI/token. Metadata carries `{ uri, ms, ok }`; the
  //   token is never recorded.
  // VECTOR_BACKEND_MIGRATED: a backfill from Postgres → Milvus completed
  //   (or was simulated via dryRun). Metadata carries
  //   `{ scanned, written, errors, dryRun, indexId? }`.
  | "VECTOR_BACKEND_CONFIGURED"
  | "VECTOR_BACKEND_RESET"
  | "VECTOR_BACKEND_TESTED"
  | "VECTOR_BACKEND_MIGRATED";

export interface AuditPayload {
  event: AuditEvent;
  actorId: string | null;
  organizationId: string | null;
  targetType?: string;
  targetId?: string;
  metadata?: Record<string, unknown>;
  ip?: string;
  userAgent?: string;
}

/**
 * Record a sensitive-operation audit event. Returns a promise that
 * resolves whether or not the write succeeded — callers should use
 * `void audit({...})` and not await this.
 */
export async function audit(p: AuditPayload): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        event: p.event,
        actorId: p.actorId,
        organizationId: p.organizationId,
        targetType: p.targetType ?? null,
        targetId: p.targetId ?? null,
        // Prisma's Json column accepts plain serialisable values. Casting
        // through `unknown` keeps this typesafe for callers without forcing
        // them to import Prisma's InputJsonValue type.
        metadata: (p.metadata ?? null) as unknown as never,
        ip: p.ip ?? null,
        userAgent: p.userAgent ?? null,
      },
    });
  } catch (err) {
    // Swallow — audit failures must never break the user-facing request.
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        event: p.event,
        actorId: p.actorId,
        organizationId: p.organizationId,
      },
      "audit log write failed",
    );
  }
}

/**
 * Extract caller identity hints from request headers. Handles the common
 * proxy chains (`x-forwarded-for` may be a comma-separated list; the leftmost
 * entry is the original client). Returns plain strings (or undefined) so the
 * result can be spread directly into an AuditPayload.
 */
export function auditContextFromRequest(
  req: NextRequest | Request,
): { ip?: string; userAgent?: string } {
  const headers = req.headers;
  const xff = headers.get("x-forwarded-for");
  const xri = headers.get("x-real-ip");
  const ip = (xff?.split(",")[0]?.trim() || xri?.trim() || undefined) ?? undefined;
  const userAgent = headers.get("user-agent") ?? undefined;
  return { ip, userAgent };
}
