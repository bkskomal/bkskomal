import { describe, it, expect, beforeEach, vi } from "vitest";

const prismaMock = vi.hoisted(() => ({
  goldenAnswer: {
    findUnique: vi.fn(),
    update: vi.fn(),
    findMany: vi.fn(),
    count: vi.fn(),
  },
}));
const embedMock = vi.hoisted(() => vi.fn());
const logWarnMock = vi.hoisted(() => vi.fn());

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("./embeddings", () => ({ embed: embedMock }));
vi.mock("@/lib/logger", () => ({ log: () => ({ warn: logWarnMock, info: () => {}, debug: () => {} }) }));

const { embedGoldenAnswer, findRelevantGoldens } = await import("./golden-search");

beforeEach(() => {
  vi.resetAllMocks();
});

describe("embedGoldenAnswer", () => {
  it("embeds when row exists and has no embeddedAt", async () => {
    prismaMock.goldenAnswer.findUnique.mockResolvedValue({
      id: "g1",
      organizationId: "org1",
      question: "Are you SOC 2 certified?",
      embeddedAt: null,
      updatedAt: new Date(),
    });
    embedMock.mockResolvedValue([0.1, 0.2, 0.3]);
    prismaMock.goldenAnswer.update.mockResolvedValue({});
    await embedGoldenAnswer("g1");
    expect(prismaMock.goldenAnswer.update).toHaveBeenCalledWith({
      where: { id: "g1" },
      data: expect.objectContaining({ questionEmbedding: [0.1, 0.2, 0.3] }),
    });
  });

  it("no-ops when embeddedAt is current (>= updatedAt)", async () => {
    const t = new Date();
    prismaMock.goldenAnswer.findUnique.mockResolvedValue({
      id: "g2", organizationId: "org1", question: "q",
      embeddedAt: new Date(t.getTime() + 1000), updatedAt: t,
    });
    await embedGoldenAnswer("g2");
    expect(embedMock).not.toHaveBeenCalled();
    expect(prismaMock.goldenAnswer.update).not.toHaveBeenCalled();
  });

  it("swallows embedder failures and warns", async () => {
    prismaMock.goldenAnswer.findUnique.mockResolvedValue({
      id: "g3", organizationId: "org1", question: "q",
      embeddedAt: null, updatedAt: new Date(),
    });
    embedMock.mockRejectedValue(new Error("embedder down"));
    await expect(embedGoldenAnswer("g3")).resolves.toBeUndefined();
    expect(logWarnMock).toHaveBeenCalled();
  });
});

describe("findRelevantGoldens", () => {
  it("returns [] when org has no goldens", async () => {
    prismaMock.goldenAnswer.count.mockResolvedValue(0);
    const r = await findRelevantGoldens({ organizationId: "org1", questionText: "anything" });
    expect(r).toEqual([]);
  });

  it("returns top-N by cosine over embedded candidates", async () => {
    prismaMock.goldenAnswer.count
      .mockResolvedValueOnce(3)  // totalForOrg
      .mockResolvedValueOnce(3); // embeddedCount
    embedMock.mockResolvedValue([1, 0, 0]); // query
    prismaMock.goldenAnswer.findMany.mockResolvedValueOnce([
      { id: "a", question: "qa", answer: "aa", questionEmbedding: [1, 0, 0] },    // sim 1.0
      { id: "b", question: "qb", answer: "ab", questionEmbedding: [0.5, 0.5, 0] }, // sim 0.5
      { id: "c", question: "qc", answer: "ac", questionEmbedding: [0, 1, 0] },    // sim 0.0
    ]);
    const r = await findRelevantGoldens({ organizationId: "org1", questionText: "q", take: 2 });
    expect(r).toHaveLength(2);
    expect(r[0].id).toBe("a");
    expect(r[0].similarity).toBeCloseTo(1.0, 3);
    expect(r[1].id).toBe("b");
    expect(r[1].similarity).toBeCloseTo(0.5, 3);
  });

  it("pads with recency when embedded coverage is low", async () => {
    prismaMock.goldenAnswer.count
      .mockResolvedValueOnce(10) // totalForOrg
      .mockResolvedValueOnce(1); // embeddedCount  (10% coverage)
    embedMock.mockResolvedValue([1, 0]);
    prismaMock.goldenAnswer.findMany.mockResolvedValueOnce([
      { id: "embedded1", question: "q1", answer: "a1", questionEmbedding: [0.9, 0.1] },
    ]);
    prismaMock.goldenAnswer.findMany.mockResolvedValueOnce([
      { id: "recent1", question: "rq1", answer: "ra1" },
      { id: "recent2", question: "rq2", answer: "ra2" },
    ]);
    const r = await findRelevantGoldens({ organizationId: "org1", questionText: "q", take: 3 });
    expect(r.map((x) => x.id)).toEqual(["embedded1", "recent1", "recent2"]);
    expect(r[0].similarity).toBeDefined();
    expect(r[1].similarity).toBeUndefined();
  });
});
