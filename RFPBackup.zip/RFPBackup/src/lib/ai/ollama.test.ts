import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  listOllamaModels,
  nativeBaseUrl,
  pingOllama,
  pullOllamaModel,
  streamPullProgress,
} from "./ollama";

const realFetch = globalThis.fetch;

describe("nativeBaseUrl", () => {
  it("strips a trailing /v1 and any trailing slashes", () => {
    expect(nativeBaseUrl("http://localhost:11434/v1")).toBe("http://localhost:11434");
    expect(nativeBaseUrl("http://localhost:11434/v1/")).toBe("http://localhost:11434");
    expect(nativeBaseUrl("http://localhost:11434/")).toBe("http://localhost:11434");
    expect(nativeBaseUrl("http://localhost:11434")).toBe("http://localhost:11434");
  });
});

describe("listOllamaModels", () => {
  beforeEach(() => {
    globalThis.fetch = vi.fn();
  });
  afterEach(() => {
    globalThis.fetch = realFetch;
  });

  it("hits /api/tags (not /v1/models) and parses model[] entries", async () => {
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        models: [
          { name: "llama3.2:latest", size: 2_500_000_000, modified_at: "2026-01-01T00:00:00Z" },
          { name: "qwen2.5:7b", size: 4_700_000_000, modified_at: "2026-02-01T00:00:00Z" },
        ],
      }),
    });

    const out = await listOllamaModels("http://localhost:11434/v1");

    expect(globalThis.fetch).toHaveBeenCalledWith("http://localhost:11434/api/tags");
    expect(out).toHaveLength(2);
    // Sorted alphabetically.
    expect(out[0]?.name).toBe("llama3.2:latest");
    expect(out[0]?.sizeBytes).toBe(2_500_000_000);
    expect(out[0]?.modifiedAt).toBe("2026-01-01T00:00:00Z");
    expect(out[1]?.name).toBe("qwen2.5:7b");
  });

  it("returns [] when models field is missing", async () => {
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: true,
      json: async () => ({}),
    });
    expect(await listOllamaModels("http://localhost:11434")).toEqual([]);
  });

  it("throws on non-2xx", async () => {
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: false,
      status: 503,
      statusText: "unavailable",
    });
    await expect(listOllamaModels("http://localhost:11434/v1")).rejects.toThrow(/503/);
  });
});

describe("pingOllama", () => {
  beforeEach(() => {
    globalThis.fetch = vi.fn();
  });
  afterEach(() => {
    globalThis.fetch = realFetch;
  });

  it("returns ok:true with the daemon version", async () => {
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: true,
      json: async () => ({ version: "0.1.42" }),
    });
    const r = await pingOllama("http://localhost:11434/v1");
    expect(r).toEqual({ ok: true, version: "0.1.42" });
  });

  it("returns ok:false with the HTTP error when the daemon answers an error", async () => {
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: false,
      status: 500,
      statusText: "boom",
    });
    const r = await pingOllama("http://localhost:11434/v1");
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.error).toContain("500");
  });

  it("returns ok:false (does not throw) when fetch rejects (e.g. timeout)", async () => {
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockRejectedValueOnce(
      Object.assign(new Error("aborted"), { name: "AbortError" }),
    );
    const r = await pingOllama("http://localhost:11434/v1", 5);
    expect(r.ok).toBe(false);
  });
});

describe("pullOllamaModel / streamPullProgress", () => {
  beforeEach(() => {
    globalThis.fetch = vi.fn();
  });
  afterEach(() => {
    globalThis.fetch = realFetch;
  });

  function streamFromStrings(parts: string[]): ReadableStream<Uint8Array> {
    const enc = new TextEncoder();
    let i = 0;
    return new ReadableStream({
      pull(controller) {
        if (i >= parts.length) {
          controller.close();
          return;
        }
        controller.enqueue(enc.encode(parts[i]!));
        i++;
      },
    });
  }

  it("accumulates streaming chunks across packet boundaries and reports progress", async () => {
    // Split JSON lines across two packets to exercise the line-buffering logic.
    const stream = streamFromStrings([
      `{"status":"pulling manifest"}\n{"status":"download","total":100,"completed":25}\n{"sta`,
      `tus":"download","total":100,"completed":75}\n{"status":"success"}\n`,
    ]);
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: true,
      body: stream,
    });

    const progress: number[] = [];
    await pullOllamaModel("http://localhost:11434/v1", "llama3.2", (p) => progress.push(p));

    expect(globalThis.fetch).toHaveBeenCalledWith(
      "http://localhost:11434/api/pull",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ name: "llama3.2", stream: true }),
      }),
    );
    // Two of the four chunks have total+completed; we should see two pct values.
    expect(progress).toEqual([0.25, 0.75]);
  });

  it("yields progress chunks via streamPullProgress", async () => {
    const stream = streamFromStrings([
      `{"status":"pulling","total":10,"completed":3}\n{"status":"success"}\n`,
    ]);
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: true,
      body: stream,
    });
    const out = [];
    for await (const c of streamPullProgress("http://localhost:11434/v1", "x")) out.push(c);
    expect(out).toHaveLength(2);
    expect(out[0]?.pct).toBeCloseTo(0.3);
    expect(out[1]?.status).toBe("success");
  });

  it("rejects when the daemon emits an error chunk", async () => {
    const stream = streamFromStrings([`{"error":"model not found"}\n`]);
    (globalThis.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      ok: true,
      body: stream,
    });
    await expect(pullOllamaModel("http://localhost:11434/v1", "nope")).rejects.toThrow(
      /model not found/,
    );
  });
});
