// Hallucination / grounding judge.
//
// A second, narrower LLM pass that audits whether each factual claim in a
// generated answer is actually backed by the cited Source excerpts. Distinct
// from the heuristic `confidence` score: confidence is a cheap predictor of
// "looks reasonable" (source count, length, hedging language); grounding is a
// per-claim factual audit that asks the model to point at the supporting
// evidence.
//
// Design notes:
//   - Single LLM call per response. We bound the prompt size by truncating
//     each source to ~1500 chars and capping at 8 sources (rich enough for
//     RFP answers, small enough to keep latency and token cost predictable).
//   - Strict JSON response_format. The judge is asked to return claims with
//     verbatim text + a 3-tier support label + source_ids + a one-line note.
//   - Score formula is deterministic (not asked of the LLM) so it's stable
//     across model versions: supported = 1.0, weak = 0.5, unsupported = 0.
//     Empty content / no claims => 1.0 (nothing to be wrong about).
//   - JSON parse errors degrade gracefully: score 0 + a single "parse error"
//     pseudo-claim so reviewers can see WHY the response wasn't graded
//     instead of silently getting a "0%" badge.
//   - The LLM client is the same per-org client used by generate.ts; the
//     circuit breaker wrap in client.ts applies automatically.

import { getAiClients } from "./client";
import { stripCodeFences } from "./json-utils";
import { GROUNDING_JUDGE_SYSTEM } from "./prompts";
import { responseGroundingScore } from "@/lib/metrics";

export type GroundingSupport = "supported" | "weak" | "unsupported";

export interface GroundingClaim {
  /** Verbatim or lightly trimmed quote from `content`. */
  claim: string;
  support: GroundingSupport;
  /** Ids of sources that support it (subset of provided source ids). */
  sourceIds?: string[];
  /** Brief LLM justification. */
  note?: string;
}

export interface GroundingResult {
  /** 0..1, fraction of claims backed by sources. */
  score: number;
  claims: GroundingClaim[];
  /** Model used by the judge — useful when comparing vintages. */
  judgeModel: string;
  /** Wall-clock duration of the judge call, including JSON parsing. */
  ms: number;
}

export interface GroundingSourceInput {
  id: string;
  content: string;
  fileName?: string;
  page?: number | null;
}

export interface ScoreGroundingInput {
  content: string;
  sources: GroundingSourceInput[];
  organizationId: string;
}

// Tunables. Numbers are deliberate and the rationale is in the design notes
// above — change them together with the prompt if you adjust them.
export const MAX_SOURCES = 8;
export const MAX_CHARS_PER_SOURCE = 1500;

// Score weights for each support tier. Exposed as a const so tests can assert
// the formula without re-declaring the magic numbers.
export const SUPPORT_WEIGHTS: Record<GroundingSupport, number> = {
  supported: 1,
  weak: 0.5,
  unsupported: 0,
};

/**
 * Score the grounding of a generated answer against the cited sources.
 *
 * Always returns a result — never throws. Upstream failures (LLM down, parse
 * errors) become a low score plus an explanatory pseudo-claim so the UI can
 * show *why* a response is ungraded rather than silently rendering 0%.
 */
export async function scoreGrounding(
  input: ScoreGroundingInput,
): Promise<GroundingResult> {
  const start = Date.now();
  const trimmedContent = input.content.trim();

  // Empty content: nothing to be wrong about. Pre-flight short-circuit avoids
  // wasting an LLM call on a no-op.
  if (!trimmedContent) {
    return finish({
      score: 1,
      claims: [],
      judgeModel: "n/a",
      startedAt: start,
      orgId: input.organizationId,
    });
  }

  // Pick the highest-quality (longest, most informative) sources up to the
  // cap. We assume the caller already passed in sources ordered by retrieval
  // score; we just enforce a hard ceiling on count + per-source length.
  const cappedSources = input.sources.slice(0, MAX_SOURCES);
  const sourcePromptBlock = buildSourceBlock(cappedSources);

  const userPrompt = [
    `# ANSWER`,
    trimmedContent,
    sourcePromptBlock
      ? `\n# SOURCES\n${sourcePromptBlock}`
      : `\n# SOURCES\n(none provided — every factual claim is automatically unsupported)`,
  ].join("\n");

  let judgeModel = "unknown";
  try {
    const { llm, config } = await getAiClients(input.organizationId);
    // Phase A.4: per-org grounding model (defaults to extractionModel for
    // structured-output efficiency). Falls back to the main chat model only
    // if the resolver returned something unusable.
    judgeModel = config.generation.groundingModel || config.llm.model;

    const completion = await llm.chat.completions.create({
      model: judgeModel,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: GROUNDING_JUDGE_SYSTEM },
        { role: "user", content: userPrompt },
      ],
    });

    const raw = completion.choices[0]?.message?.content ?? "";
    const claims = parseJudgeOutput(raw, cappedSources);

    // No claims extracted: the answer was non-factual (e.g. clarifying
    // question or pure boilerplate). Treat as fully grounded — there's
    // nothing to fact-check.
    if (claims.length === 0) {
      return finish({
        score: 1,
        claims: [],
        judgeModel,
        startedAt: start,
        orgId: input.organizationId,
      });
    }

    const score = computeScore(claims);
    return finish({
      score,
      claims,
      judgeModel,
      startedAt: start,
      orgId: input.organizationId,
    });
  } catch (err) {
    // Two distinct failure modes share this branch: the LLM call itself
    // failed (network / breaker / 5xx) OR the JSON was malformed. Both
    // surface as a 0 score with a single pseudo-claim explaining why so the
    // UI can render an actionable error rather than a silent empty grade.
    const message = err instanceof Error ? err.message : String(err);
    return finish({
      score: 0,
      claims: [
        {
          claim: "(grounding judge failed)",
          support: "unsupported",
          note: `Judge error: ${message}`,
        },
      ],
      judgeModel,
      startedAt: start,
      orgId: input.organizationId,
    });
  }
}

/**
 * Build the [Source N] block. Truncates each source to MAX_CHARS_PER_SOURCE
 * and prefixes a 1-based tag matching what the answer text uses.
 */
function buildSourceBlock(sources: GroundingSourceInput[]): string {
  return sources
    .map((s, i) => {
      const header = `[Source ${i + 1}]${s.fileName ? ` ${s.fileName}` : ""}${
        s.page ? ` (p.${s.page})` : ""
      }`;
      const body = truncate(s.content ?? "", MAX_CHARS_PER_SOURCE);
      return `${header}\n${body}`;
    })
    .join("\n\n---\n\n");
}

function truncate(s: string, max: number): string {
  if (s.length <= max) return s;
  // Soft cut: stop at the nearest whitespace just before the cap. Keeps the
  // tail readable when the LLM might quote it back.
  const slice = s.slice(0, max);
  const lastSpace = slice.lastIndexOf(" ");
  return (lastSpace > max - 100 ? slice.slice(0, lastSpace) : slice) + "…";
}

/**
 * Parse the judge's JSON. Returns [] if the JSON is missing/invalid or the
 * shape is wrong — the caller treats that as a parse failure and falls back.
 *
 * Guards:
 *   - support label is normalized to lowercase + restricted to the 3 tiers
 *   - source_ids are mapped 1-based -> the actual source.id strings the
 *     caller passed in (so consumers don't need to re-resolve indices)
 *   - claim text is coerced to string and trimmed; empty claims are dropped
 */
function parseJudgeOutput(
  raw: string,
  sources: GroundingSourceInput[],
): GroundingClaim[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(stripCodeFences(raw));
  } catch {
    throw new Error("judge returned invalid JSON");
  }
  if (!parsed || typeof parsed !== "object") {
    throw new Error("judge returned non-object JSON");
  }
  const claimsRaw = (parsed as { claims?: unknown }).claims;
  if (!Array.isArray(claimsRaw)) {
    // Not strictly a parse error — the model returned valid JSON of the wrong
    // shape. Treat as "no claims" (score 1) rather than a failure; a missing
    // claims array on a valid object usually means the model classified the
    // answer as non-factual.
    return [];
  }

  const out: GroundingClaim[] = [];
  for (const c of claimsRaw) {
    if (!c || typeof c !== "object") continue;
    const obj = c as Record<string, unknown>;
    const claim = String(obj.claim ?? "").trim();
    if (!claim) continue;

    const supportRaw = String(obj.support ?? "").toLowerCase();
    const support: GroundingSupport =
      supportRaw === "supported" || supportRaw === "weak" || supportRaw === "unsupported"
        ? (supportRaw as GroundingSupport)
        : "unsupported";

    // Map 1-based source numbers (as the judge sees them) back to the caller's
    // source.id strings. Anything out of range is silently dropped.
    const sourceIdsRaw = obj.source_ids ?? obj.sourceIds;
    const sourceIds: string[] = [];
    if (Array.isArray(sourceIdsRaw)) {
      for (const sid of sourceIdsRaw) {
        const n = typeof sid === "number" ? sid : Number(sid);
        if (!Number.isFinite(n)) continue;
        const idx = Math.floor(n) - 1;
        if (idx >= 0 && idx < sources.length) {
          sourceIds.push(sources[idx]!.id);
        }
      }
    }

    const note = typeof obj.note === "string" ? obj.note.trim() : undefined;

    out.push({
      claim,
      support,
      sourceIds: sourceIds.length ? sourceIds : undefined,
      note: note || undefined,
    });
  }
  return out;
}

/**
 * Deterministic score from per-claim labels. Supported = 1, weak = 0.5,
 * unsupported = 0. Average across all claims, in [0, 1].
 *
 * Caller is responsible for short-circuiting on empty inputs (we'd return NaN
 * here on a zero-length list).
 */
export function computeScore(claims: GroundingClaim[]): number {
  if (claims.length === 0) return 1;
  let sum = 0;
  for (const c of claims) sum += SUPPORT_WEIGHTS[c.support] ?? 0;
  const avg = sum / claims.length;
  // Numeric noise guard — keep the value strictly in [0, 1].
  return Math.max(0, Math.min(1, avg));
}

interface FinishArgs {
  score: number;
  claims: GroundingClaim[];
  judgeModel: string;
  startedAt: number;
  orgId: string;
}

function finish(a: FinishArgs): GroundingResult {
  const ms = Date.now() - a.startedAt;
  // Observe even on failure (score 0) so operators can see the failure rate
  // in the histogram. The metric never throws.
  try {
    responseGroundingScore.observe({ org: a.orgId }, a.score);
  } catch {
    // ignore — never fail a grounding call due to metrics
  }
  return { score: a.score, claims: a.claims, judgeModel: a.judgeModel, ms };
}

/** @internal — for tests. */
export const _internals = {
  buildSourceBlock,
  parseJudgeOutput,
  truncate,
};
