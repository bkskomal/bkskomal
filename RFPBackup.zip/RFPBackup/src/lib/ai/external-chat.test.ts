// External chat adapter — unit tests (Phase E).
//
// Mocks Prisma + global fetch. Coverage:
//   - buildUserPromptBody merges org metadata with defaults
//   - runExternalChatTurn:
//       • persists user message before calling upstream
//       • POSTs JSON body with prompt + conversation_id + Authorization
//       • saves assistant message with returned response + metadata
//       • persists upstream conversation_id back onto ChatThread
//       • on failure, saves an error-shaped assistant message + emits "error"
//   - pingExternalChat wraps {ok, message}

import { describe, expect, it, beforeEach, afterEach, vi } from "vitest";

const { prismaMock, resolveConfigMock } = vi.hoisted(() => ({
  prismaMock: {
    chatMessage: {
      create: vi.fn(async (args: { data: { role: string; content: string } }) => ({
        id: `msg-${args.data.role.toLowerCase()}-${Date.now()}`,
        ...args.data,
      })),
    },
    chatThread: {
      findUnique: vi.fn(),
      update: vi.fn(async () => ({})),
    },
  },
  resolveConfigMock: vi.fn(),
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("./config", () => ({ resolveAiConfig: (...args: unknown[]) => resolveConfigMock(...args) }));

import { buildUserPromptBody, runExternalChatTurn, pingExternalChat } from "./external-chat";
import type { ChatStep } from "./chat";

const ORIG_FETCH = globalThis.fetch;

beforeEach(() => {
  prismaMock.chatMessage.create.mockClear();
  prismaMock.chatThread.findUnique.mockReset();
  prismaMock.chatThread.update.mockClear();
  resolveConfigMock.mockReset();
});

afterEach(() => {
  globalThis.fetch = ORIG_FETCH;
});

describe("buildUserPromptBody", () => {
  it("merges org metadata defaults with per-turn overrides and generates a fresh prompt_id", () => {
    const body = buildUserPromptBody(
      {
        kind: "OATI_USER_PROMPT",
        endpoint: "x",
        apiKey: null,
        metadata: {
          client: "AutoRFP",
          product: "OATI AutoRFP",
          data_source: ["kb1", "kb2"],
          source: "chat",
          user_timezone: "America/Chicago",
          enable_query_analyzer: true,
          enable_follow_up: false,
          enable_abbreviation: true,
          json_stream: false,
        },
      },
      {
        prompt: "what is your sla?",
        conversationId: "prev-conv",
        user: { id: "u-1", name: "Alice", email: "a@b.com" },
      },
    );

    expect(body.prompt).toBe("what is your sla?");
    expect(body.conversation_id).toBe("prev-conv");
    expect(body.stream).toBe(false);
    expect(body.metadata.client).toBe("AutoRFP");
    expect(body.metadata.product).toBe("OATI AutoRFP");
    expect(body.metadata.data_source).toEqual(["kb1", "kb2"]);
    expect(body.metadata.user_name).toBe("Alice");
    expect(body.metadata.user_timezone).toBe("America/Chicago");
    expect(body.metadata.enable_query_analyzer).toBe(true);
    expect(body.metadata.enable_follow_up).toBe(false);
    expect(body.metadata.prompt_id).toMatch(/^[0-9a-f-]{36}$/i);
  });

  it("falls back to email then 'anonymous' when no name + no metadata user_name", () => {
    const a = buildUserPromptBody(
      { kind: "OATI_USER_PROMPT", endpoint: "x", apiKey: null, metadata: {} },
      { prompt: "p", conversationId: "", user: { id: "u-1", name: null, email: "fb@x.com" } },
    );
    expect(a.metadata.user_name).toBe("fb@x.com");

    const b = buildUserPromptBody(
      { kind: "OATI_USER_PROMPT", endpoint: "x", apiKey: null, metadata: {} },
      { prompt: "p", conversationId: "", user: { id: "u-1", name: null, email: null } },
    );
    expect(b.metadata.user_name).toBe("anonymous");
  });

  it("defaults user_id and organization_id to 0 when not configured", () => {
    const body = buildUserPromptBody(
      { kind: "OATI_USER_PROMPT", endpoint: "x", apiKey: null, metadata: {} },
      { prompt: "p", conversationId: "", user: { id: "u-1", name: "x", email: null } },
    );
    expect(body.metadata.user_id).toBe(0);
    expect(body.metadata.organization_id).toBe(0);
  });
});

describe("runExternalChatTurn — happy path", () => {
  it("persists user msg, POSTs prompt + conv id + Bearer, saves assistant msg, threads conv id", async () => {
    resolveConfigMock.mockResolvedValue({
      chatProvider: {
        kind: "OATI_USER_PROMPT",
        endpoint: "https://oati.local/UserPrompt",
        apiKey: "tok",
        metadata: { client: "AutoRFP", product: "OATI AutoRFP" },
      },
    });
    prismaMock.chatThread.findUnique.mockResolvedValue({ externalConversationId: "prev-conv" });

    let captured: { url: string; init: RequestInit | undefined } | null = null;
    globalThis.fetch = (async (url: string, init?: RequestInit) => {
      captured = { url, init };
      return new Response(
        JSON.stringify({
          response: "Our SLA is 99.95%.",
          references: [{ doc: "soc2.pdf" }],
          follow_up_questions: ["What about RTO?"],
          abbreviations: ["SLA = Service Level Agreement"],
          conversation_id: "next-conv-789",
        }),
        { status: 200 },
      );
    }) as typeof fetch;

    const events: ChatStep[] = [];
    const result = await runExternalChatTurn({
      threadId: "thread-1",
      userMessage: "what is your sla?",
      organizationId: "org-1",
      scope: "INDEX",
      user: { id: "u-1", name: "Alice", email: "a@b.com" },
      onStep: (s) => events.push(s),
    });

    // 2 messages saved: USER then ASSISTANT
    expect(prismaMock.chatMessage.create).toHaveBeenCalledTimes(2);
    const [userCall, assistantCall] = prismaMock.chatMessage.create.mock.calls.map(
      (c: unknown[]) => (c[0] as { data: { role: string; content: string; metadata?: unknown } }).data,
    );
    expect(userCall.role).toBe("USER");
    expect(userCall.content).toBe("what is your sla?");
    expect(assistantCall.role).toBe("ASSISTANT");
    expect(assistantCall.content).toContain("99.95%");
    const meta = assistantCall.metadata as { external?: { follow_up_questions?: string[]; conversation_id?: string } };
    expect(meta.external?.follow_up_questions).toEqual(["What about RTO?"]);
    expect(meta.external?.conversation_id).toBe("next-conv-789");

    // Thread updated with new conversation_id + updatedAt
    expect(prismaMock.chatThread.update).toHaveBeenCalledTimes(1);
    const updateCall = (prismaMock.chatThread.update.mock.calls[0] as unknown as [{ data: { externalConversationId?: string } }])[0];
    expect(updateCall.data.externalConversationId).toBe("next-conv-789");

    // HTTP shape
    expect(captured).not.toBeNull();
    expect(captured!.url).toBe("https://oati.local/UserPrompt");
    expect(captured!.init?.method).toBe("POST");
    const headers = captured!.init?.headers as Record<string, string>;
    expect(headers["Authorization"]).toBe("Bearer tok");
    expect(headers["Content-Type"]).toBe("application/json");
    const sent = JSON.parse(captured!.init?.body as string);
    expect(sent.prompt).toBe("what is your sla?");
    expect(sent.conversation_id).toBe("prev-conv"); // threaded from prior turn
    expect(sent.metadata.client).toBe("AutoRFP");
    expect(sent.metadata.user_name).toBe("Alice");

    // Steps emitted: thinking + done
    expect(events.map((e) => e.step)).toEqual(["thinking", "done"]);

    // Return shape
    expect(result.content).toContain("99.95%");
    expect(result.metadata.external?.follow_up_questions).toEqual(["What about RTO?"]);
  });

  it("uses empty conversation_id on first turn (thread has no externalConversationId yet)", async () => {
    resolveConfigMock.mockResolvedValue({
      chatProvider: {
        kind: "OATI_USER_PROMPT",
        endpoint: "https://oati.local/UserPrompt",
        apiKey: null,
        metadata: {},
      },
    });
    prismaMock.chatThread.findUnique.mockResolvedValue({ externalConversationId: null });

    let captured = "";
    globalThis.fetch = (async (_url: string, init?: RequestInit) => {
      captured = init?.body as string;
      return new Response(JSON.stringify({ response: "hi", conversation_id: "new-1" }), { status: 200 });
    }) as typeof fetch;

    await runExternalChatTurn({
      threadId: "thread-1",
      userMessage: "hello",
      organizationId: "org-1",
      scope: "ORG",
      user: { id: "u-1", name: "Alice", email: null },
    });
    expect(JSON.parse(captured).conversation_id).toBe("");
  });

  it("omits Authorization header when apiKey is null", async () => {
    resolveConfigMock.mockResolvedValue({
      chatProvider: { kind: "OATI_USER_PROMPT", endpoint: "https://oati.local/UserPrompt", apiKey: null, metadata: {} },
    });
    prismaMock.chatThread.findUnique.mockResolvedValue({ externalConversationId: "" });
    let capturedHeaders: Record<string, string> = {};
    globalThis.fetch = (async (_url: string, init?: RequestInit) => {
      capturedHeaders = init?.headers as Record<string, string>;
      return new Response(JSON.stringify({ response: "ok" }), { status: 200 });
    }) as typeof fetch;

    await runExternalChatTurn({
      threadId: "thread-1",
      userMessage: "x",
      organizationId: "org-1",
      scope: "ORG",
      user: { id: "u-1", name: "x", email: null },
    });
    expect(capturedHeaders["Authorization"]).toBeUndefined();
  });
});

describe("runExternalChatTurn — failure path", () => {
  it("saves an error-shaped assistant message + emits 'error' on non-2xx upstream", async () => {
    resolveConfigMock.mockResolvedValue({
      chatProvider: {
        kind: "OATI_USER_PROMPT",
        endpoint: "https://oati.local/UserPrompt",
        apiKey: "tok",
        metadata: {},
      },
    });
    prismaMock.chatThread.findUnique.mockResolvedValue({ externalConversationId: "" });
    globalThis.fetch = (async () =>
      new Response("rate limited", { status: 429 })) as typeof fetch;

    const events: ChatStep[] = [];
    const result = await runExternalChatTurn({
      threadId: "thread-1",
      userMessage: "hi",
      organizationId: "org-1",
      scope: "ORG",
      user: { id: "u-1", name: "x", email: null },
      onStep: (s) => events.push(s),
    });

    expect(prismaMock.chatMessage.create).toHaveBeenCalledTimes(2);
    const assistantCall = prismaMock.chatMessage.create.mock.calls[1][0] as { data: { content: string; metadata?: unknown } };
    expect(assistantCall.data.content).toMatch(/External chat provider failed/);
    expect(assistantCall.data.content).toMatch(/HTTP 429/);
    // Thread not bumped on the error path.
    expect(prismaMock.chatThread.update).not.toHaveBeenCalled();
    expect(events[events.length - 1].step).toBe("error");
    expect(result.content).toMatch(/External chat provider failed/);
  });
});

describe("pingExternalChat", () => {
  it("returns ok=true with response length on success", async () => {
    globalThis.fetch = (async () =>
      new Response(JSON.stringify({ response: "hello there" }), { status: 200 })) as typeof fetch;
    const r = await pingExternalChat({ endpoint: "https://oati.local/UserPrompt", apiKey: null });
    expect(r.ok).toBe(true);
    expect(r.message).toMatch(/11-char/);
  });

  it("returns ok=false on non-2xx", async () => {
    globalThis.fetch = (async () => new Response("nope", { status: 500 })) as typeof fetch;
    const r = await pingExternalChat({ endpoint: "https://oati.local/UserPrompt", apiKey: null });
    expect(r.ok).toBe(false);
    expect(r.message).toMatch(/HTTP 500/);
  });
});
