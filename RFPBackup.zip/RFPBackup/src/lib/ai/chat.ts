// Chat service — multi-turn conversation with optional scope-aware tools.
//
// Scope determines what context the model sees and which tools it can call:
//   ORG     — can search any of the org's knowledge indexes
//   PROJECT — same as ORG, plus knows the project name
//   INDEX   — pinned to one knowledge index (search_knowledge_base preconfigured)
//   RFP     — knows the RFP title + has access to RFP question list

import { prisma } from "@/lib/prisma";
import { getAiClients } from "./client";
import { toolRegistry, type ToolContext } from "./tools/registry";
import "./tools/builtin";
import { LlmError } from "@/lib/errors";
import type { ChatScope, MessageRole } from "@prisma/client";

const CHAT_SYSTEM = `You are AutoRFP's assistant — a precise, professional helper that grounds answers in the user's organizational knowledge whenever possible.

Rules:
- When the user asks a factual question that could be answered by their knowledge base, call the search_knowledge_base tool first.
- Cite sources inline as [Source 1], [Source 2], etc., when you've used tool results.
- If you don't have enough context, say so — don't fabricate.
- Be concise. Use markdown (bullets, tables, code blocks) when it improves clarity.
- For RFP questions, when asked to "draft a response", produce a polished, vendor-style answer.

Attached files & workflows:
- Users can attach files via the paperclip button. Attached files are auto-indexed
  into the KB. The user message will include the documentId in parentheses next to
  each filename (e.g. "report.pdf (\`cm1abc…\`)").
- When the user says something like "start an RFP process from this", "process this RFP",
  "turn this into an RFP", or any equivalent, call the start_rfp_process tool with the
  most recently mentioned documentId. After the tool returns, tell the user the RFP id
  and the project name, and remind them they can review extracted questions in the RFP
  viewer in about a minute.
- When the user asks to "create a new knowledge base" / "set up a KB", call
  create_knowledge_index.`;

export interface ChatStep {
  step: "thinking" | "tool_call" | "tool_result" | "delta" | "done" | "error";
  detail?: string;
  data?: unknown;
}

interface BuildContextOpts {
  scope: ChatScope;
  organizationId: string;
  projectId?: string | null;
  rfpId?: string | null;
  indexId?: string | null;
}

async function buildScopeContext(opts: BuildContextOpts): Promise<string> {
  const lines: string[] = [];

  const org = await prisma.organization.findUnique({
    where: { id: opts.organizationId },
    select: { name: true },
  });
  if (org) lines.push(`Organization: ${org.name}`);

  if (opts.scope === "PROJECT" && opts.projectId) {
    const p = await prisma.project.findUnique({
      where: { id: opts.projectId },
      select: { name: true, description: true, _count: { select: { rfps: true } } },
    });
    if (p) {
      lines.push(`Scope: PROJECT "${p.name}"${p.description ? ` — ${p.description}` : ""}`);
      lines.push(`The project has ${p._count.rfps} RFP(s).`);
    }
  } else if (opts.scope === "RFP" && opts.rfpId) {
    const rfp = await prisma.rFP.findUnique({
      where: { id: opts.rfpId },
      include: {
        project: { select: { name: true, defaultIndexId: true } },
        questions: { select: { number: true, section: true, text: true }, orderBy: { number: "asc" }, take: 80 },
      },
    });
    if (rfp) {
      lines.push(`Scope: RFP "${rfp.title}" (project: ${rfp.project.name})`);
      lines.push(`The RFP has ${rfp.questions.length} extracted question(s):`);
      for (const q of rfp.questions) {
        lines.push(`  ${q.number}. ${q.section ? `[${q.section}] ` : ""}${truncate(q.text, 140)}`);
      }
    }
  } else if (opts.scope === "INDEX" && opts.indexId) {
    const idx = await prisma.knowledgeIndex.findUnique({
      where: { id: opts.indexId },
      select: { name: true, description: true, _count: { select: { documents: true } } },
    });
    if (idx) {
      lines.push(`Scope: KNOWLEDGE INDEX "${idx.name}"${idx.description ? ` — ${idx.description}` : ""}`);
      lines.push(`Contains ${idx._count.documents} document(s). Use search_knowledge_base to query it.`);
    }
  } else {
    lines.push(`Scope: ORGANIZATION-WIDE`);
  }

  return lines.join("\n");
}

function truncate(s: string, n: number): string {
  return s.length > n ? s.slice(0, n).trimEnd() + "…" : s;
}

interface ChatRunOpts {
  threadId: string;
  userMessage: string;
  ctx: ToolContext;
  scope: ChatScope;
  scopedIndexId?: string | null;
  rfpId?: string | null;
  projectId?: string | null;
  enableTools?: boolean;
  onStep?: (step: ChatStep) => void;
}

interface ChatResult {
  assistantMessageId: string;
  content: string;
  metadata: { sources?: unknown[]; toolCalls?: unknown[] };
}

/**
 * Run one chat turn against an existing thread. Persists the user message,
 * streams reasoning via onStep, persists the assistant reply at the end.
 */
export async function runChatTurn(opts: ChatRunOpts): Promise<ChatResult> {
  const emit = (s: ChatStep) => opts.onStep?.(s);

  // Persist user message immediately so reloads see it.
  await prisma.chatMessage.create({
    data: { threadId: opts.threadId, role: "USER", content: opts.userMessage },
  });

  // Build context block for this scope.
  const scopeContext = await buildScopeContext({
    scope: opts.scope,
    organizationId: opts.ctx.organizationId,
    projectId: opts.projectId,
    rfpId: opts.rfpId,
    indexId: opts.scopedIndexId,
  });

  // Load prior messages (most recent 30).
  const history = await prisma.chatMessage.findMany({
    where: { threadId: opts.threadId },
    orderBy: { createdAt: "asc" },
    take: 60,
  });

  const messages: any[] = [
    { role: "system", content: `${CHAT_SYSTEM}\n\n# Current Context\n${scopeContext}` },
    ...history.map((m) => ({
      role: m.role.toLowerCase() as "user" | "assistant" | "system" | "tool",
      content: m.content,
    })),
  ];

  const useTools = opts.enableTools !== false;
  const toolCtx: ToolContext = {
    ...opts.ctx,
    defaultIndexId: opts.scopedIndexId ?? opts.ctx.defaultIndexId,
  };

  const tools = useTools ? await toolRegistry.toOpenAIToolsForOrg(opts.ctx.organizationId) : undefined;

  emit({ step: "thinking", detail: "Considering your message…" });

  const allSources: unknown[] = [];
  const allToolCalls: unknown[] = [];
  let finalText = "";

  const { llm, config } = await getAiClients(opts.ctx.organizationId);

  // Tool-call loop bounded to keep latency sane.
  for (let turn = 0; turn < 4; turn++) {
    let resp;
    try {
      resp = await llm.chat.completions.create({
        model: config.llm.model,
        temperature: 0.3,
        messages,
        tools,
        tool_choice: tools ? "auto" : undefined,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      throw new LlmError(msg);
    }

    const msg = resp.choices[0]?.message;
    if (!msg) break;

    if (msg.tool_calls?.length) {
      messages.push(msg);
      for (const call of msg.tool_calls) {
        emit({
          step: "tool_call",
          detail: `Tool: ${call.function.name}`,
          data: { name: call.function.name, args: call.function.arguments },
        });
        allToolCalls.push({ name: call.function.name, args: call.function.arguments });

        let result: unknown;
        try {
          result = await toolRegistry.invoke(call.function.name, call.function.arguments, toolCtx);
        } catch (e) {
          result = { error: e instanceof Error ? e.message : String(e) };
        }

        // If the tool was knowledge search, capture the sources.
        if (call.function.name === "search_knowledge_base" && result && typeof result === "object") {
          const r = result as { results?: unknown[] };
          if (Array.isArray(r.results)) allSources.push(...r.results);
        }

        emit({ step: "tool_result", detail: `Got result for ${call.function.name}`, data: result });

        messages.push({
          role: "tool",
          tool_call_id: call.id,
          content: JSON.stringify(result),
        });
      }
      continue;
    }

    finalText = msg.content ?? "";
    break;
  }

  if (!finalText) finalText = "_The model did not produce a response. Try again._";

  emit({ step: "delta", detail: "Drafting…" });

  const assistantMsg = await prisma.chatMessage.create({
    data: {
      threadId: opts.threadId,
      role: "ASSISTANT",
      content: finalText,
      metadata: { sources: allSources, toolCalls: allToolCalls } as never,
    },
  });

  await prisma.chatThread.update({
    where: { id: opts.threadId },
    data: { updatedAt: new Date() },
  });

  emit({ step: "done", detail: "Response ready" });

  return {
    assistantMessageId: assistantMsg.id,
    content: finalText,
    metadata: { sources: allSources, toolCalls: allToolCalls },
  };
}

/**
 * One-shot helper: ask the LLM to summarize the user's first message into a
 * short thread title (4-6 words). Best-effort; falls back to a truncation.
 */
export async function generateThreadTitle(
  firstMessage: string,
  orgId: string | null | undefined,
): Promise<string> {
  try {
    const { llm, config } = await getAiClients(orgId);
    const resp = await llm.chat.completions.create({
      model: config.llm.model,
      temperature: 0.3,
      max_tokens: 24,
      messages: [
        {
          role: "system",
          content:
            "Summarize the user's first message as a 4-6 word chat title. Plain text, no quotes, no period.",
        },
        { role: "user", content: firstMessage.slice(0, 500) },
      ],
    });
    const t = resp.choices[0]?.message?.content?.trim().replace(/^["']|["']$/g, "");
    if (t && t.length <= 80) return t;
  } catch {
    // ignore
  }
  return truncate(firstMessage, 60);
}

export type { MessageRole };
