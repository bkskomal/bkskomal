// Resolves the active AI configuration for an organization. Per-org overrides
// (stored in OrgAiConfig, encrypted at rest) win over the env defaults; any
// field that's null on the org row falls back to the env value.

import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { decrypt } from "@/lib/crypto";
import { AiProvider } from "@prisma/client";
import { inferProviderFromUrl } from "./providers";

export interface ResolvedAiConfig {
  llm: {
    provider: AiProvider;
    baseUrl: string;
    apiKey: string;
    model: string;
    /**
     * Model used for the question-extraction LLM passes. Extraction is a
     * structured-output task where smaller/faster models perform well, so we
     * prefer the org's `llmModelSimple` when set (configured under model
     * routing). Falls back to `model` when no Simple model is configured.
     * Setting this independently from `model` lets users keep a powerful
     * model for response generation while shaving 5-10× off extraction
     * latency.
     */
    extractionModel: string;
    httpReferer?: string;
    appTitle?: string;
  };
  embedding: {
    provider: AiProvider;
    baseUrl: string;
    apiKey: string;
    model: string;
    dimensions: number;
  };
  llamaparse: {
    enabled: boolean;
    apiKey: string | null;
    resultType: "text" | "markdown";
  };
  /**
   * Question-extraction layer config (Phase A.2). Defaults preserve current
   * behavior: built-in V2 prompt, eligibility pass on, batch cap 12KB,
   * concurrency 3.
   */
  extraction: {
    /**
     * Effective model id for extraction. Resolution order:
     *   1. Org's pinned `extractionModel` (NEW — Phase A.2 admin UI)
     *   2. env.LLM_EXTRACTION_MODEL (operator-pinned)
     *   3. llmModel (the main generation model)
     * Use a model that handles structured output cleanly — too small and
     * you'll get malformed JSON even at temperature 0.
     */
    model: string;
    /**
     * Optional custom system prompt. When null, the built-in V2 prompt is
     * used. Operators occasionally override this for domain-specific RFPs
     * (e.g. tax filings, healthcare credentialing) where the generic prompt
     * extracts noise.
     */
    promptOverride: string | null;
    /** Run the stage-2 eligibility classifier (default true). */
    eligibilityEnabled: boolean;
    /** Max BYTES per extraction batch (UI exposes this in KB). */
    batchSizeBytes: number;
    /** Concurrent batches in flight. */
    concurrency: number;
  };
  /**
   * Answer-generation config (Phase A.4). Defaults preserve current behavior:
   * routed/llm model, grounding judge on (uses chat model), semantic cache
   * on (0.92 threshold from semantic-cache.ts).
   */
  generation: {
    /**
     * Org-pinned generation model. When set, overrides Phase 3B routing
     * (simple/complex tiers) but LoRA adapter still wins. null = inherit from
     * routing → baseModel.
     */
    pinnedModel: string | null;
    /** Run the post-hoc grounding judge after drafting. */
    groundingEnabled: boolean;
    /**
     * Pinned model for the grounding judge. Falls back to extractionModel
     * (structured-output friendly) when null.
     */
    groundingModel: string;
    /** Consult the semantic answer cache before drafting. */
    cacheEnabled: boolean;
    /** Cosine similarity threshold for semantic cache hits. */
    cacheSimilarityThreshold: number;
  };
  /**
   * Web-scraping config (Phase A.3). Defaults preserve current behavior:
   * STATIC engine, robots.txt honored, 20s timeout, 48 images per page.
   * PLAYWRIGHT / BROWSERLESS land in Phase B; until then, non-STATIC engines
   * fall back to STATIC with a warn.
   */
  scraping: {
    /** "STATIC" | "PLAYWRIGHT" | "BROWSERLESS" */
    engine: "STATIC" | "PLAYWRIGHT" | "BROWSERLESS";
    /** Browserless / remote Playwright endpoint (used when engine != STATIC). */
    headlessUrl: string | null;
    /** Decrypted auth token for the headless service (Browserless API token, etc.). */
    headlessToken: string | null;
    /** Honor robots.txt during scrape. Default true. */
    respectRobots: boolean;
    /** Per-page fetch timeout in ms. */
    timeoutMs: number;
    /** Max images extracted per page. */
    maxImages: number;
  };
  /**
   * Chat provider (Phase E). INTERNAL = current runChatTurn / agentic chat
   * stack. OATI_USER_PROMPT = POST {prompt, conversation_id, metadata} to a
   * remote `/UserPrompt` endpoint that returns {response, references,
   * follow_up_questions, abbreviations, conversation_id}.
   *
   * When EXTERNAL, the chat route ignores enableTools / enableAgentic — the
   * remote service owns retrieval and tool use.
   */
  chatProvider: {
    kind: "INTERNAL" | "OATI_USER_PROMPT";
    endpoint: string | null;
    apiKey: string | null;
    /** Default metadata merged into every request body. All keys optional. */
    metadata: {
      user_id?: number;
      organization_id?: number;
      user_name?: string;
      user_timezone?: string;
      client?: string;
      product?: string;
      data_source?: string[];
      source?: string;
      enable_query_analyzer?: boolean;
      enable_follow_up?: boolean;
      enable_abbreviation?: boolean;
      json_stream?: boolean;
    };
  };
  /**
   * RAG provider (Phase D). INTERNAL = run our own dense+sparse+rerank stack
   * (the historical behavior). EXTERNAL_HTTP = POST the query to a remote
   * service and use its chunks as-is. Cross-encoder rerank + contextual
   * retrieval ingest become no-ops when external — the remote service owns
   * those concerns.
   */
  ragProvider: {
    kind: "INTERNAL" | "EXTERNAL_HTTP";
    endpoint: string | null;
    apiKey: string | null;
    /** Extra headers merged into the external POST. */
    extraHeaders: Record<string, string>;
  };
  /**
   * Retrieval / RAG layer config (Phase A). Defaults preserve current behavior:
   * HYBRID + LLM rerank with topK=8 + RRF k=60.
   */
  retrieval: {
    /** "HYBRID" | "DENSE_ONLY" | "SPARSE_ONLY" */
    strategy: "HYBRID" | "DENSE_ONLY" | "SPARSE_ONLY";
    /** "NONE" | "LLM" | "CROSS_ENCODER" */
    rerankerKind: "NONE" | "LLM" | "CROSS_ENCODER";
    /** Cross-encoder model id (only consulted when rerankerKind = CROSS_ENCODER). */
    rerankerModel: string;
    /** How many candidates to feed the reranker before truncating to topK. */
    rerankerTopK: number;
    /** Final top-K returned to the answer generator. */
    topK: number;
    /** RRF k constant for hybrid fusion. */
    rrfK: number;
    /** Dense weight in hybrid scoring (0..1). 1 = dense only, 0 = sparse only. */
    denseWeight: number;
    /**
     * Phase B.3: contextual retrieval (Anthropic technique). When true,
     * each chunk gets a 1-sentence LLM-generated context blurb prepended
     * BEFORE the embedding call. Display in the viewer keeps original text.
     * Opt-in — costs one LLM call per chunk at ingest time.
     */
    contextualEnabled: boolean;
  };
  /** Per-field provenance — useful for the Settings UI badge. */
  source: {
    llmBaseUrl: "org" | "env";
    llmApiKey: "org" | "env";
    llmModel: "org" | "env";
    embeddingBaseUrl: "org" | "env";
    embeddingApiKey: "org" | "env";
    embeddingModel: "org" | "env";
    embeddingDimensions: "org" | "env";
    llamaparse: "org" | "env";
    /** "org" if any of the retrieval fields are set on the org row, else "default". */
    retrieval: "org" | "default";
    /** "org" if a non-INTERNAL ragProvider is set, else "default". */
    ragProvider: "org" | "default";
    /** "org" if a non-INTERNAL chatProvider is set, else "default". */
    chatProvider: "org" | "default";
    /** "org" if any of the extraction fields are set on the org row, else "default". */
    extraction: "org" | "default";
    /** "org" if any of the scraping fields are set on the org row, else "default". */
    scraping: "org" | "default";
    /** "org" if any of the generation fields are set on the org row, else "default". */
    generation: "org" | "default";
  };
}

const DEFAULT_RESULT_TYPE = "markdown" as const;

export async function resolveAiConfig(orgId: string | null | undefined): Promise<ResolvedAiConfig> {
  const orgConfig = orgId
    ? await prisma.orgAiConfig.findUnique({ where: { organizationId: orgId } })
    : null;

  const llmBaseUrl = orgConfig?.llmBaseUrl ?? env.LLM_BASE_URL;
  const llmApiKey = decrypt(orgConfig?.llmApiKeyEncrypted) ?? env.LLM_API_KEY;
  const llmModel = orgConfig?.llmModel ?? env.LLM_MODEL;

  const embeddingBaseUrl = orgConfig?.embeddingBaseUrl ?? env.EMBEDDING_BASE_URL;
  const embeddingApiKey = decrypt(orgConfig?.embeddingApiKeyEncrypted) ?? env.EMBEDDING_API_KEY;
  const embeddingModel = orgConfig?.embeddingModel ?? env.EMBEDDING_MODEL;
  const embeddingDimensions = orgConfig?.embeddingDimensions ?? env.EMBEDDING_DIMENSIONS;

  const llamaParseKey =
    decrypt(orgConfig?.llamaParseApiKeyEncrypted) ?? env.LLAMA_CLOUD_API_KEY ?? null;
  const llamaParseEnabled = (orgConfig?.llamaParseEnabled ?? false) || Boolean(env.LLAMA_CLOUD_API_KEY);

  // Extraction-specific model. Resolution order:
  //   1. Org's pinned `extractionModel` (Phase A.2 admin UI)
  //   2. env.LLM_EXTRACTION_MODEL (operator-pinned fast model)
  //   3. Fall back to llmModel (the main generation model)
  //
  // We deliberately do NOT auto-route to llmModelSimple here — extraction is
  // structured-output and a too-small model (e.g. 3B) returns malformed JSON
  // even at temperature 0. Operators who want the speedup should explicitly
  // pin a model that's been verified to handle structured output cleanly
  // (e.g. llama-3.3-8b, gpt-4o-mini, claude-haiku, qwen-2.5-7b).
  const extractionModel = orgConfig?.extractionModel ?? env.LLM_EXTRACTION_MODEL ?? llmModel;

  // Extraction defaults preserve current behavior: built-in V2 prompt,
  // eligibility on, 12 KB batches, concurrency 3.
  const extractionPromptOverride = orgConfig?.extractionPromptOverride ?? null;
  const extractionEligibilityEnabled = orgConfig?.extractionEligibilityEnabled ?? true;
  // Stored as KB on the row; surfaced as bytes here so callers don't have to
  // remember the unit conversion (extract.ts splits on bytes/chars).
  const extractionBatchKb = orgConfig?.extractionBatchKb ?? 12;
  const extractionBatchSizeBytes = extractionBatchKb * 1024;
  const extractionConcurrency = orgConfig?.extractionConcurrency ?? 3;
  const extractionConfigured = Boolean(
    orgConfig?.extractionModel ||
      orgConfig?.extractionPromptOverride ||
      orgConfig?.extractionEligibilityEnabled != null ||
      orgConfig?.extractionBatchKb != null ||
      orgConfig?.extractionConcurrency != null,
  );

  // Generation defaults preserve current behavior:
  //   - pinnedModel null (routing decides)
  //   - groundingEnabled true (current behavior — judge runs)
  //   - groundingModel = extractionModel (structured-output, fast)
  //   - cacheEnabled true (semantic-cache.ts runs)
  //   - cacheSimilarityThreshold 0.92 (matches DEFAULT_THRESHOLD in semantic-cache.ts)
  const generationPinnedModel = orgConfig?.generationModel ?? null;
  const generationGroundingEnabled = orgConfig?.groundingEnabled ?? true;
  const generationGroundingModel = orgConfig?.groundingModel ?? extractionModel;
  const generationCacheEnabled = orgConfig?.cacheEnabled ?? true;
  const generationCacheThreshold = orgConfig?.cacheSimilarityThreshold ?? 0.92;
  const generationConfigured = Boolean(
    orgConfig?.generationModel ||
      orgConfig?.groundingEnabled != null ||
      orgConfig?.groundingModel ||
      orgConfig?.cacheEnabled != null ||
      orgConfig?.cacheSimilarityThreshold != null,
  );

  // Scraping defaults preserve current behavior: STATIC, robots on,
  // 20s timeout, 48 images. Token is decrypted here so callers don't have to.
  const scraperEngine = ((orgConfig?.scraperEngine ?? "STATIC") as
    | "STATIC"
    | "PLAYWRIGHT"
    | "BROWSERLESS");
  const scraperHeadlessUrl = orgConfig?.scraperHeadlessUrl ?? null;
  const scraperHeadlessToken =
    decrypt(orgConfig?.scraperHeadlessTokenEncrypted) ?? null;
  const scraperRespectRobots = orgConfig?.scraperRespectRobots ?? true;
  const scraperTimeoutMs = orgConfig?.scraperTimeoutMs ?? 20_000;
  const scraperMaxImages = orgConfig?.scraperMaxImages ?? 48;
  const scrapingConfigured = Boolean(
    orgConfig?.scraperEngine ||
      orgConfig?.scraperHeadlessUrl ||
      orgConfig?.scraperHeadlessTokenEncrypted ||
      orgConfig?.scraperRespectRobots != null ||
      orgConfig?.scraperTimeoutMs != null ||
      orgConfig?.scraperMaxImages != null,
  );

  // Chat provider (Phase E). Defaults to INTERNAL; only OATI_USER_PROMPT
  // shipped in the MVP so we narrow unknown future values back to INTERNAL.
  const chatProviderRaw = (orgConfig?.chatProvider ?? "INTERNAL").toUpperCase();
  const chatProviderKind: "INTERNAL" | "OATI_USER_PROMPT" =
    chatProviderRaw === "OATI_USER_PROMPT" ? "OATI_USER_PROMPT" : "INTERNAL";
  const chatEndpoint = orgConfig?.chatEndpoint ?? null;
  const chatApiKey = decrypt(orgConfig?.chatApiKeyEncrypted) ?? null;
  // Validate/coerce the metadata JSON. Anything that doesn't match the
  // expected primitive type is dropped silently — better empty than crash.
  const rawChatMeta = (orgConfig?.chatProviderMetadata as Record<string, unknown> | null) ?? {};
  const chatMetadata: ResolvedAiConfig["chatProvider"]["metadata"] = {};
  if (typeof rawChatMeta.user_id === "number") chatMetadata.user_id = rawChatMeta.user_id;
  if (typeof rawChatMeta.organization_id === "number") chatMetadata.organization_id = rawChatMeta.organization_id;
  if (typeof rawChatMeta.user_name === "string") chatMetadata.user_name = rawChatMeta.user_name;
  if (typeof rawChatMeta.user_timezone === "string") chatMetadata.user_timezone = rawChatMeta.user_timezone;
  if (typeof rawChatMeta.client === "string") chatMetadata.client = rawChatMeta.client;
  if (typeof rawChatMeta.product === "string") chatMetadata.product = rawChatMeta.product;
  if (Array.isArray(rawChatMeta.data_source)) {
    chatMetadata.data_source = rawChatMeta.data_source.filter((s): s is string => typeof s === "string");
  }
  if (typeof rawChatMeta.source === "string") chatMetadata.source = rawChatMeta.source;
  if (typeof rawChatMeta.enable_query_analyzer === "boolean") chatMetadata.enable_query_analyzer = rawChatMeta.enable_query_analyzer;
  if (typeof rawChatMeta.enable_follow_up === "boolean") chatMetadata.enable_follow_up = rawChatMeta.enable_follow_up;
  if (typeof rawChatMeta.enable_abbreviation === "boolean") chatMetadata.enable_abbreviation = rawChatMeta.enable_abbreviation;
  if (typeof rawChatMeta.json_stream === "boolean") chatMetadata.json_stream = rawChatMeta.json_stream;
  const chatProviderConfigured = chatProviderKind !== "INTERNAL";

  // RAG provider (Phase D). Defaults to INTERNAL; only EXTERNAL_HTTP shipped
  // in the MVP so we narrow unknown future values back to INTERNAL.
  const ragProviderRaw = (orgConfig?.ragProvider ?? "INTERNAL").toUpperCase();
  const ragProviderKind: "INTERNAL" | "EXTERNAL_HTTP" =
    ragProviderRaw === "EXTERNAL_HTTP" ? "EXTERNAL_HTTP" : "INTERNAL";
  const ragEndpoint = orgConfig?.ragEndpoint ?? null;
  const ragApiKey = decrypt(orgConfig?.ragApiKeyEncrypted) ?? null;
  // Coerce JSON column to a plain Record<string,string>. Drops non-string
  // values silently rather than crashing on a misconfigured row.
  const ragExtraHeaders: Record<string, string> = {};
  if (orgConfig?.ragExtraHeaders && typeof orgConfig.ragExtraHeaders === "object") {
    for (const [k, v] of Object.entries(orgConfig.ragExtraHeaders as Record<string, unknown>)) {
      if (typeof v === "string") ragExtraHeaders[k] = v;
    }
  }
  const ragProviderConfigured = ragProviderKind !== "INTERNAL";

  // Retrieval defaults preserve current behavior: HYBRID + LLM rerank + topK 8.
  const retrievalStrategy = ((orgConfig?.retrievalStrategy ?? "HYBRID") as
    | "HYBRID"
    | "DENSE_ONLY"
    | "SPARSE_ONLY");
  const rerankerKind = ((orgConfig?.rerankerKind ?? "LLM") as
    | "NONE"
    | "LLM"
    | "CROSS_ENCODER");
  const rerankerModel = orgConfig?.rerankerModel ?? "BAAI/bge-reranker-v2-m3";
  const rerankerTopK = orgConfig?.rerankerTopK ?? 20;
  const retrievalTopK = orgConfig?.retrievalTopK ?? 8;
  const rrfK = orgConfig?.rrfK ?? 60;
  const denseWeight = orgConfig?.hybridDenseWeight ?? 0.5;
  // Phase B.3: contextual retrieval defaults OFF (opt-in — costs LLM tokens
  // at ingest time).
  const contextualEnabled = orgConfig?.contextualRetrievalEnabled ?? false;

  const retrievalConfigured = Boolean(
    orgConfig?.retrievalStrategy ||
      orgConfig?.rerankerKind ||
      orgConfig?.rerankerModel ||
      orgConfig?.rerankerTopK != null ||
      orgConfig?.retrievalTopK != null ||
      orgConfig?.rrfK != null ||
      orgConfig?.hybridDenseWeight != null ||
      orgConfig?.contextualRetrievalEnabled != null,
  );

  return {
    llm: {
      provider: orgConfig?.llmProvider ?? inferProviderFromUrl(llmBaseUrl),
      baseUrl: llmBaseUrl,
      apiKey: llmApiKey,
      model: llmModel,
      extractionModel,
      httpReferer: orgConfig?.llmHttpReferer ?? env.LLM_HTTP_REFERER ?? undefined,
      appTitle: orgConfig?.llmAppTitle ?? env.LLM_APP_TITLE ?? undefined,
    },
    embedding: {
      provider: orgConfig?.embeddingProvider ?? inferProviderFromUrl(embeddingBaseUrl),
      baseUrl: embeddingBaseUrl,
      apiKey: embeddingApiKey,
      model: embeddingModel,
      dimensions: embeddingDimensions,
    },
    llamaparse: {
      enabled: llamaParseEnabled,
      apiKey: llamaParseKey,
      resultType:
        (orgConfig?.llamaParseResultType as "text" | "markdown" | undefined) ??
        env.LLAMAPARSE_RESULT_TYPE ??
        DEFAULT_RESULT_TYPE,
    },
    extraction: {
      model: extractionModel,
      promptOverride: extractionPromptOverride,
      eligibilityEnabled: extractionEligibilityEnabled,
      batchSizeBytes: extractionBatchSizeBytes,
      concurrency: extractionConcurrency,
    },
    scraping: {
      engine: scraperEngine,
      headlessUrl: scraperHeadlessUrl,
      headlessToken: scraperHeadlessToken,
      respectRobots: scraperRespectRobots,
      timeoutMs: scraperTimeoutMs,
      maxImages: scraperMaxImages,
    },
    generation: {
      pinnedModel: generationPinnedModel,
      groundingEnabled: generationGroundingEnabled,
      groundingModel: generationGroundingModel,
      cacheEnabled: generationCacheEnabled,
      cacheSimilarityThreshold: generationCacheThreshold,
    },
    ragProvider: {
      kind: ragProviderKind,
      endpoint: ragEndpoint,
      apiKey: ragApiKey,
      extraHeaders: ragExtraHeaders,
    },
    chatProvider: {
      kind: chatProviderKind,
      endpoint: chatEndpoint,
      apiKey: chatApiKey,
      metadata: chatMetadata,
    },
    retrieval: {
      strategy: retrievalStrategy,
      rerankerKind,
      rerankerModel,
      rerankerTopK,
      topK: retrievalTopK,
      rrfK,
      denseWeight,
      contextualEnabled,
    },
    source: {
      llmBaseUrl: orgConfig?.llmBaseUrl ? "org" : "env",
      llmApiKey: orgConfig?.llmApiKeyEncrypted ? "org" : "env",
      llmModel: orgConfig?.llmModel ? "org" : "env",
      embeddingBaseUrl: orgConfig?.embeddingBaseUrl ? "org" : "env",
      embeddingApiKey: orgConfig?.embeddingApiKeyEncrypted ? "org" : "env",
      embeddingModel: orgConfig?.embeddingModel ? "org" : "env",
      embeddingDimensions: orgConfig?.embeddingDimensions != null ? "org" : "env",
      llamaparse: orgConfig?.llamaParseApiKeyEncrypted ? "org" : "env",
      retrieval: retrievalConfigured ? "org" : "default",
      ragProvider: ragProviderConfigured ? "org" : "default",
      chatProvider: chatProviderConfigured ? "org" : "default",
      extraction: extractionConfigured ? "org" : "default",
      scraping: scrapingConfigured ? "org" : "default",
      generation: generationConfigured ? "org" : "default",
    },
  };
}
