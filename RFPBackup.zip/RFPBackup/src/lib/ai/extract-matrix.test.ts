import { describe, expect, it, beforeEach, vi } from "vitest";

// Hoisted client mock — generateMatrixCell talks to the OpenAI client built
// by getAiClients. We swap that out for a stub we can drive per-test.
const { llmCreateMock } = vi.hoisted(() => ({
  llmCreateMock: vi.fn(),
}));

vi.mock("./client", () => ({
  getAiClients: async () => ({
    config: { llm: { model: "test-model" } },
    llm: {
      chat: {
        completions: { create: (...args: unknown[]) => llmCreateMock(...args) },
      },
    },
  }),
}));

import { generateMatrixCell, scoreCell, NEEDS_INFO_SENTINEL } from "./extract-matrix";

beforeEach(() => {
  vi.clearAllMocks();
});

describe("generateMatrixCell", () => {
  it("returns the model's cell value with a positive confidence", async () => {
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "$1,200/yr" } }],
    });
    const result = await generateMatrixCell({
      rowLabel: "Annual platform license",
      columnHeader: "Up to 100 users",
      contextBlocks: ["Past answer: $1,200/yr for 100-user license"],
      organizationId: "org-1",
    });
    expect(result.generated).toBe("$1,200/yr");
    expect(result.confidence).toBeGreaterThan(0);
  });

  it("returns NEEDS INFO with confidence 0 when the LLM throws", async () => {
    llmCreateMock.mockRejectedValueOnce(new Error("upstream down"));
    const result = await generateMatrixCell({
      rowLabel: "Implementation",
      columnHeader: "EU region",
      contextBlocks: [],
      organizationId: "org-1",
    });
    expect(result.generated).toBe(NEEDS_INFO_SENTINEL);
    expect(result.confidence).toBe(0);
  });

  it("normalises the 'NEEDS INFO' sentinel regardless of case/decoration", async () => {
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "**needs info**" } }],
    });
    const result = await generateMatrixCell({
      rowLabel: "Premium support tier",
      columnHeader: "APAC",
      contextBlocks: [],
      organizationId: "org-1",
    });
    expect(result.generated).toBe(NEEDS_INFO_SENTINEL);
    expect(result.confidence).toBe(0);
  });

  it("strips a wrapping code fence the model occasionally produces", async () => {
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "```\n$500/mo\n```" } }],
    });
    const result = await generateMatrixCell({
      rowLabel: "Support",
      columnHeader: "Standard",
      contextBlocks: [],
      organizationId: "org-1",
    });
    expect(result.generated).toBe("$500/mo");
    expect(result.confidence).toBeGreaterThan(0);
  });
});

describe("scoreCell", () => {
  it("scores empty values as 0 confidence with the sentinel", () => {
    expect(scoreCell("")).toEqual({
      generated: NEEDS_INFO_SENTINEL,
      confidence: 0,
    });
  });

  it("nudges confidence down on hedging language", () => {
    const a = scoreCell("$100");
    const b = scoreCell("may be around $100");
    expect(b.confidence).toBeLessThan(a.confidence);
  });
});
