// Semantic retrieval over GoldenAnswer.
//
// GoldenAnswers are the highest-quality reference signal — past Q&A pairs
// curated and approved by humans. Historically this lookup was recency-based
// (`updatedAt desc`), which meant a new RFP question worded differently from
// a known golden never matched it. This module fixes that:
//
//   1) embedGoldenAnswer(id)   — embed a golden's question with the org's
//                                BGE embedder (called on create/update).
//   2) findRelevantGoldens(...) — cosine-similarity search returning the top-N
//                                 goldens most semantically similar to a new
//                                 question, even when wording differs.
//
// Per-org isolated: cross-tenant goldens are structurally unreachable.
// Falls back gracefully — if embedder is unavailable or no goldens have
// embeddings yet, returns the recency-based list (legacy behaviour).

import { prisma } from "@/lib/prisma";
import { embed } from "./embeddings";
import { log } from "@/lib/logger";

/** What downstream callers use: a thin shape `generateResponse` expects. */
export interface GoldenCandidate {
  id: string;
  question: string;
  answer: string;
  /** Cosine similarity 0..1. Present when retrieved semantically. */
  similarity?: number;
}

/**
 * Embed a single golden's question. Idempotent — safe to call on every
 * create/update. Failures are logged and swallowed; the golden row just
 * doesn't get embedded and falls out of semantic search until next call.
 */
export async function embedGoldenAnswer(goldenId: string): Promise<void> {
  const golden = await prisma.goldenAnswer.findUnique({
    where: { id: goldenId },
    select: { id: true, organizationId: true, question: true, embeddedAt: true, updatedAt: true },
  });
  if (!golden) return;
  // Skip when already embedded and the question hasn't changed since.
  if (golden.embeddedAt && golden.embeddedAt >= golden.updatedAt) return;

  try {
    const vec = await embed(golden.question, golden.organizationId);
    if (!vec || vec.length === 0) return;
    await prisma.goldenAnswer.update({
      where: { id: goldenId },
      data: { questionEmbedding: vec, embeddedAt: new Date() },
    });
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        goldenId,
        orgId: golden.organizationId,
      },
      "golden-answer embedding failed; will retry on next write",
    );
  }
}

/** Cheap cosine for the BGE 768-d vectors (already L2-normalized). */
function cosine(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length);
  if (n === 0) return 0;
  let dot = 0;
  for (let i = 0; i < n; i++) dot += a[i] * b[i];
  // BGE outputs L2-normalized vectors, so dot product == cosine.
  return dot;
}

/**
 * Find the most semantically-similar golden answers for a new question.
 *
 * Strategy:
 *   1. Embed the query.
 *   2. Fetch all goldens for the org that already have an embedding
 *      (capped at 500 — for orgs with more, swap to a vector index).
 *   3. Compute cosine similarity, sort desc, return top-N.
 *   4. If fewer than half the org's goldens have embeddings (e.g. fresh
 *      org, embedder was down at write time), supplement with recency-based
 *      results so the lookup is never empty.
 *
 * Returns at most `take` candidates. Each has `similarity` populated when
 * matched semantically; legacy recency hits have undefined `similarity`.
 */
export async function findRelevantGoldens(opts: {
  organizationId: string;
  questionText: string;
  take?: number;
}): Promise<GoldenCandidate[]> {
  const take = Math.max(1, Math.min(20, opts.take ?? 6));
  const totalForOrg = await prisma.goldenAnswer.count({
    where: { organizationId: opts.organizationId },
  });
  if (totalForOrg === 0) return [];

  // Try semantic match first.
  let semantic: GoldenCandidate[] = [];
  try {
    const queryVec = await embed(opts.questionText, opts.organizationId);
    if (queryVec && queryVec.length > 0) {
      const candidates = await prisma.goldenAnswer.findMany({
        where: { organizationId: opts.organizationId, embeddedAt: { not: null } },
        select: { id: true, question: true, answer: true, questionEmbedding: true },
        orderBy: { updatedAt: "desc" },
        take: 500,
      });
      semantic = candidates
        .filter((c) => c.questionEmbedding && c.questionEmbedding.length > 0)
        .map((c) => ({
          id: c.id,
          question: c.question,
          answer: c.answer,
          similarity: cosine(queryVec, c.questionEmbedding),
        }))
        .sort((a, b) => (b.similarity ?? 0) - (a.similarity ?? 0))
        .slice(0, take);
    }
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        orgId: opts.organizationId,
      },
      "golden-answer semantic search failed; falling back to recency",
    );
  }

  // If semantic returned at least `take` results AND covered most of the
  // org's goldens, we're done. Otherwise pad from recency so older / un-
  // embedded goldens don't get permanently excluded.
  if (semantic.length >= take) return semantic;

  const embeddedCount = await prisma.goldenAnswer.count({
    where: { organizationId: opts.organizationId, embeddedAt: { not: null } },
  });
  const ratio = totalForOrg > 0 ? embeddedCount / totalForOrg : 1;
  if (ratio >= 0.5 && semantic.length > 0) {
    return semantic; // semantic coverage is fine — just take what we found
  }

  // Pad with recency-based hits, de-duped against semantic ids.
  const seen = new Set(semantic.map((s) => s.id));
  const recency = await prisma.goldenAnswer.findMany({
    where: { organizationId: opts.organizationId, id: { notIn: [...seen] } },
    select: { id: true, question: true, answer: true },
    orderBy: { updatedAt: "desc" },
    take: take - semantic.length,
  });
  return [...semantic, ...recency.map((r) => ({ id: r.id, question: r.question, answer: r.answer }))];
}
