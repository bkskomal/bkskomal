import { describe, expect, it } from "vitest";
import {
  MAX_CHARS_PER_BATCH,
  mergeStages,
  parseStage1Json,
  parseStage2Json,
  renumberQuestions,
  splitForExtraction,
  type ExtractedQuestion,
  type Stage1Row,
} from "./extract";

// ---- splitForExtraction ----------------------------------------------------

describe("splitForExtraction", () => {
  it("returns one batch for short input", () => {
    const text = "Hello\n\nWorld";
    expect(splitForExtraction(text)).toEqual([text]);
  });

  it("returns an empty array for empty input", () => {
    expect(splitForExtraction("")).toEqual([]);
    expect(splitForExtraction("   \n\n   ")).toEqual([]);
  });

  it("splits a long document on '## Section' headings", () => {
    // Build three sections, each ~6k chars, total 18k > MAX_CHARS_PER_BATCH.
    const body = "paragraph text. ".repeat(380); // ~6080 chars per section body
    const text = [
      "## Section 1: Security",
      body,
      "## Section 2: Pricing",
      body,
      "## Section 3: Operations",
      body,
    ].join("\n\n");

    const batches = splitForExtraction(text);

    // Each batch must be under the cap.
    for (const b of batches) {
      expect(b.length).toBeLessThanOrEqual(MAX_CHARS_PER_BATCH);
    }
    // Should produce at least 2 batches (we packed 3 ~6k sections into <=12k batches).
    expect(batches.length).toBeGreaterThanOrEqual(2);
    // Every "Section N" heading must survive somewhere in the batches.
    const joined = batches.join("\n---\n");
    expect(joined).toContain("## Section 1: Security");
    expect(joined).toContain("## Section 2: Pricing");
    expect(joined).toContain("## Section 3: Operations");
  });

  it("falls back to paragraph batching when no sections are present", () => {
    const para = "This is a paragraph of plain text. ".repeat(20); // ~700 chars
    const text = Array(40).fill(para).join("\n\n"); // ~28k chars, no headings

    const batches = splitForExtraction(text);

    expect(batches.length).toBeGreaterThan(1);
    for (const b of batches) {
      expect(b.length).toBeLessThanOrEqual(MAX_CHARS_PER_BATCH);
    }
  });
});

// ---- renumberQuestions -----------------------------------------------------

describe("renumberQuestions", () => {
  const baseQ = (n: number, text: string): ExtractedQuestion => ({
    number: n,
    text,
    required: true,
    requirementType: "must",
    complexity: "moderate",
    eligibility: "answerable",
    eligibilityConfidence: 0.5,
  });

  it("rewrites numbers to 1..N while preserving order and stashing original", () => {
    const input: ExtractedQuestion[] = [
      baseQ(21, "first question (was 2.1)"),
      baseQ(34, "second question (was 3.4)"),
      baseQ(5, "third question (was 5)"),
    ];
    const out = renumberQuestions(input);
    expect(out.map((q) => q.number)).toEqual([1, 2, 3]);
    expect(out.map((q) => q.text)).toEqual(input.map((q) => q.text));
    expect(out.map((q) => q.originalNumber)).toEqual([21, 34, 5]);
  });

  it("is a no-op for an empty list", () => {
    expect(renumberQuestions([])).toEqual([]);
  });
});

// ---- mergeStages (eligibility fallback) -----------------------------------

describe("mergeStages eligibility fallback", () => {
  const rows: Stage1Row[] = [
    {
      number: 1,
      text: "Describe encryption at rest.",
      requirementType: "must",
      complexity: "moderate",
      topic: "security",
    },
    {
      number: 2,
      text: "Provide pricing for 500 seats.",
      requirementType: "should",
      complexity: "complex",
      topic: "pricing",
    },
    {
      number: 3,
      text: "Where do we send the proposal?",
      requirementType: "info",
      complexity: "simple",
    },
  ];

  it("applies defaults when stage-2 returns nothing", () => {
    const merged = mergeStages(rows, new Map());
    expect(merged).toHaveLength(3);
    for (const m of merged) {
      expect(m.eligibility).toBe("answerable");
      expect(m.eligibilityConfidence).toBe(0.5);
    }
    // required derived from requirement_type
    expect(merged[0]!.required).toBe(true); // must
    expect(merged[1]!.required).toBe(true); // should
    expect(merged[2]!.required).toBe(false); // info
  });

  it("uses stage-2 values when present, defaults otherwise", () => {
    const stage2 = new Map([
      [1, { eligibility: "answerable" as const, confidence: 0.95 }],
      [3, { eligibility: "out_of_scope" as const, confidence: 0.8 }],
    ]);
    const merged = mergeStages(rows, stage2);
    expect(merged[0]!.eligibility).toBe("answerable");
    expect(merged[0]!.eligibilityConfidence).toBe(0.95);
    // Row 2 had no stage-2 entry — falls back to defaults.
    expect(merged[1]!.eligibility).toBe("answerable");
    expect(merged[1]!.eligibilityConfidence).toBe(0.5);
    expect(merged[2]!.eligibility).toBe("out_of_scope");
    expect(merged[2]!.eligibilityConfidence).toBe(0.8);
  });
});

// ---- parseStage1Json / parseStage2Json ------------------------------------

describe("parseStage1Json", () => {
  it("normalizes a well-formed payload", () => {
    const raw = JSON.stringify({
      questions: [
        {
          number: "2.1",
          section: "Security",
          text: "Describe SSO.",
          requirement_type: "MUST",
          complexity: "Moderate",
          topic: "auth",
          what_is_asked: "Which SSO providers are supported?",
        },
      ],
    });
    const out = parseStage1Json(raw);
    expect(out).toHaveLength(1);
    expect(out[0]).toMatchObject({
      number: 21,
      section: "Security",
      requirementType: "must",
      complexity: "moderate",
      topic: "auth",
      whatIsAsked: "Which SSO providers are supported?",
    });
  });

  it("returns [] on bogus JSON", () => {
    expect(parseStage1Json("not json")).toEqual([]);
    expect(parseStage1Json("{}")).toEqual([]);
    expect(parseStage1Json('{"questions": "nope"}')).toEqual([]);
  });

  it("falls back to legacy `required` boolean when requirement_type is missing", () => {
    const raw = JSON.stringify({
      questions: [
        { number: 1, text: "Q1", required: true },
        { number: 2, text: "Q2", required: false },
      ],
    });
    const out = parseStage1Json(raw);
    expect(out[0]!.requirementType).toBe("must");
    expect(out[1]!.requirementType).toBe("may");
  });
});

describe("parseStage2Json", () => {
  it("clamps confidence and normalizes eligibility", () => {
    const raw = JSON.stringify({
      items: [
        { number: 1, eligibility: "ANSWERABLE", confidence: 1.4 },
        { number: 2, eligibility: "needs_info", confidence: -3 },
        { number: 3, eligibility: "wat", confidence: "bad" },
      ],
    });
    const map = parseStage2Json(raw);
    expect(map.get(1)).toEqual({ eligibility: "answerable", confidence: 1 });
    expect(map.get(2)).toEqual({ eligibility: "needs_info", confidence: 0 });
    // Bad eligibility falls back to default; bad confidence falls back to 0.5.
    expect(map.get(3)).toEqual({ eligibility: "answerable", confidence: 0.5 });
  });

  it("returns an empty map for unparseable input", () => {
    expect(parseStage2Json("garbage").size).toBe(0);
    expect(parseStage2Json("{}").size).toBe(0);
  });
});
