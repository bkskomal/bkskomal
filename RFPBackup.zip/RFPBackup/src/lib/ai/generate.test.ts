import { describe, expect, it, beforeEach, vi } from "vitest";

// Hoisted mock state. We inject every external dependency of generate.ts so
// the test stays focused on the multi-document prompt-shaping behaviour:
//
//   * LLM client → captured chat-completions mock returning a deterministic
//     stub response.
//   * Retrieval → empty (we only care about the user prompt body, not
//     knowledge-base injection).
//   * Grounding + outcome-boost → no-ops; this test is not about those paths.
//   * Prisma → exposes the rfp.findUnique / rfp.findMany lookups that
//     loadAttachmentContext makes.
const {
  llmCreateMock,
  searchIndexMock,
  scoreGroundingMock,
  reorderGoldensMock,
  coachingNoteMock,
  prismaMock,
  toolRegistryMock,
} = vi.hoisted(() => ({
  llmCreateMock: vi.fn(),
  searchIndexMock: vi.fn(),
  scoreGroundingMock: vi.fn(),
  reorderGoldensMock: vi.fn(),
  coachingNoteMock: vi.fn(),
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
      findMany: vi.fn(),
    },
  },
  toolRegistryMock: {
    toOpenAIToolsForOrg: vi.fn().mockResolvedValue(undefined),
    invoke: vi.fn(),
  },
}));

vi.mock("./client", () => ({
  getAiClients: async () => ({
    config: { llm: { model: "test-model" } },
    llm: { chat: { completions: { create: (...args: unknown[]) => llmCreateMock(...args) } } },
  }),
  // Routing decision is mocked to return the standard model so existing
  // assertions on the answer-call payload stay valid.
  pickModelForGeneration: async () => ({
    model: "test-model",
    reason: "routing_disabled",
    baseModel: "test-model",
  }),
}));

vi.mock("./retrieval", () => ({
  searchIndex: (...args: unknown[]) => searchIndexMock(...args),
}));

vi.mock("./grounding", () => ({
  scoreGrounding: (...args: unknown[]) => scoreGroundingMock(...args),
}));

vi.mock("./outcome-boost", () => ({
  reorderGoldensByOutcome: (_: unknown, goldens: unknown) => reorderGoldensMock(goldens),
  coachingNoteForGoldenAnswer: (...args: unknown[]) => coachingNoteMock(...args),
  createOutcomeBoostCache: () => ({}),
}));

vi.mock("./tools/registry", () => ({
  toolRegistry: toolRegistryMock,
}));

vi.mock("./tools/builtin", () => ({}));

// Phase A.4: generate.ts now reads per-org generation config (cache toggle,
// grounding toggle, similarity threshold). Mock the resolver to return the
// platform defaults so existing assertions (which expect cache + grounding
// to run) keep passing.
vi.mock("./config", () => ({
  resolveAiConfig: async () => ({
    generation: {
      pinnedModel: null,
      groundingEnabled: true,
      groundingModel: "",
      cacheEnabled: true,
      cacheSimilarityThreshold: 0.92,
    },
  }),
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

import { generateResponse } from "./generate";

const ORG_ID = "org-1";
const RFP_ID = "rfp-primary";
const QUESTION_ID = "q-1";
const USER_ID = "user-1";

function buildCtx() {
  return {
    organizationId: ORG_ID,
    rfpId: RFP_ID,
    questionId: QUESTION_ID,
    projectId: "proj-1",
    defaultIndexId: null,
    userId: USER_ID,
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  // First completion is the analysis call, second is the answer.
  llmCreateMock
    .mockResolvedValueOnce({
      choices: [
        {
          message: {
            content: JSON.stringify({
              coreAsk: "describe encryption",
              subQuestions: [],
              searchQueries: ["encryption"],
            }),
          },
        },
      ],
    })
    .mockResolvedValueOnce({
      choices: [{ message: { content: "We use AES-256-GCM. [Source-SECURITY_QUESTIONNAIRE]" } }],
    });
  searchIndexMock.mockResolvedValue([]);
  scoreGroundingMock.mockResolvedValue(null);
  reorderGoldensMock.mockImplementation((g) => g);
});

describe("generateResponse — multi-document attachment context", () => {
  it("includes attachment context blocks in the user prompt when attachments exist", async () => {
    prismaMock.rFP.findUnique.mockResolvedValue({ id: RFP_ID, parentRfpId: null });
    prismaMock.rFP.findMany.mockResolvedValue([
      {
        id: "att-sec",
        docRole: "SECURITY_QUESTIONNAIRE",
        fileName: "vendor-sec.xlsx",
        rawText: "Q14: Describe key rotation. Q15: Backup retention.",
      },
      {
        id: "att-add",
        docRole: "ADDENDUM",
        fileName: "addendum-v2.pdf",
        rawText: "Addendum 2: clarifies pricing schedule for Year 2.",
      },
    ]);

    const result = await generateResponse({
      question: "Describe your encryption posture.",
      indexId: null,
      ctx: buildCtx(),
    });

    expect(result.content).toContain("AES-256");
    // The second LLM call is the answer-drafting one — pull its messages.
    const answerCall = llmCreateMock.mock.calls[1][0];
    const userMsg = answerCall.messages.find((m: { role: string }) => m.role === "user");
    expect(userMsg.content).toContain("# Companion Documents");
    expect(userMsg.content).toContain("SECURITY_QUESTIONNAIRE (vendor-sec.xlsx):");
    expect(userMsg.content).toContain("ADDENDUM (addendum-v2.pdf):");
    // System prompt should mention the [Source-{role}] convention.
    const systemMsg = answerCall.messages.find((m: { role: string }) => m.role === "system");
    expect(systemMsg.content).toMatch(/Source-\{role\}/);
  });

  it("is a no-op when the RFP has no attachments", async () => {
    prismaMock.rFP.findUnique.mockResolvedValue({ id: RFP_ID, parentRfpId: null });
    prismaMock.rFP.findMany.mockResolvedValue([]);

    const result = await generateResponse({
      question: "Describe your encryption posture.",
      indexId: null,
      ctx: buildCtx(),
    });
    expect(result.content).toContain("AES-256");
    const answerCall = llmCreateMock.mock.calls[1][0];
    const userMsg = answerCall.messages.find((m: { role: string }) => m.role === "user");
    expect(userMsg.content).not.toContain("# Companion Documents");
  });

  it("walks up to the primary when ctx.rfpId is itself an attachment", async () => {
    prismaMock.rFP.findUnique.mockResolvedValue({
      id: "att-id",
      parentRfpId: "primary-id",
    });
    prismaMock.rFP.findMany.mockResolvedValue([
      {
        id: "att-x",
        docRole: "PRICING_MATRIX",
        fileName: "pricing.xlsx",
        rawText: "Year 1: $50k Year 2: $60k",
      },
    ]);

    await generateResponse({
      question: "Describe pricing.",
      indexId: null,
      ctx: { ...buildCtx(), rfpId: "att-id" },
    });
    // findMany was called scoped to the resolved primary, not the attachment.
    expect(prismaMock.rFP.findMany.mock.calls[0][0].where).toEqual({ parentRfpId: "primary-id" });
  });

  it("survives a prisma failure during attachment lookup (continues without companion docs)", async () => {
    prismaMock.rFP.findUnique.mockRejectedValue(new Error("db down"));

    const result = await generateResponse({
      question: "Describe your encryption posture.",
      indexId: null,
      ctx: buildCtx(),
    });
    expect(result.content).toContain("AES-256");
    const answerCall = llmCreateMock.mock.calls[1][0];
    const userMsg = answerCall.messages.find((m: { role: string }) => m.role === "user");
    expect(userMsg.content).not.toContain("# Companion Documents");
  });
});
