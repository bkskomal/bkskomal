// Model routing (Phase 3B).
//
// Pure decision function: given the org's AI-config row and an optional
// question complexity ("simple" | "moderate" | "complex" | undefined),
// return which model to send the request to and why. No I/O — all the
// inputs are passed in, so this is exhaustively testable and trivially
// cacheable.
//
// Intent: route obvious yes/no questions ("Do you support SSO?") to a
// cheap model and reserve premium spend for genuinely complex prompts
// ("Describe your incident-response playbook including RACI..."). When
// routing is disabled, every call falls back to the existing single
// `llmModel` so behaviour stays identical to the pre-routing world.

export type Complexity = "simple" | "moderate" | "complex" | undefined;

export interface RoutingDecision {
  /** Model identifier to pass to the chat-completions API. */
  model: string;
  /**
   * Why this model was chosen — useful for SSE step events, logs, and
   * Prometheus labels. Exactly one of:
   *   - "routing_disabled": org has `routingEnabled = false`. Standard model.
   *   - "no_complexity":    routing is on but we don't know the question's
   *                          complexity (e.g. ad-hoc chat). Standard model.
   *   - "fallback":          routing is on, complexity known, but the org
   *                          didn't configure a model for that tier.
   *                          Standard model.
   *   - "simple_routed":     simple question → cheap model.
   *   - "complex_routed":    complex question → premium model.
   *
   * Note that `complexity = "moderate"` never produces a "_routed" reason —
   * moderate is the default tier and uses `llmModel` directly. We surface
   * that as "no_complexity" only when complexity is truly absent; moderate
   * with routing enabled returns "routing_disabled"-style: standard model
   * with reason `"fallback"` is wrong (no override exists for moderate).
   * Instead we report it as `"no_complexity"` since the effective behaviour
   * is identical to the unknown case.
   */
  reason:
    | "routing_disabled"
    | "no_complexity"
    | "fallback"
    | "simple_routed"
    | "complex_routed"
    // --- LoRA adapter (Tier C3) ---
    // Org has `loraAdapterUrl` configured. The adapter URL replaces routing
    // entirely: simple/moderate/complex all funnel through the same fine-
    // tuned model. Set in `pickModelForGeneration` (not in the pure router
    // — adapter resolution is an I/O step we don't want to push into this
    // pure decision function).
    | "adapter_override"
    // --- Pinned generation model (Phase A.4) ---
    // Org has `generationModel` set in OrgAiConfig — overrides tier routing
    // for orgs that want a fixed drafting model without paying for routing
    // analysis. Set in `pickModelForGeneration`; adapter still wins above.
    | "pinned";
  /** The model that would have been used had routing been disabled. */
  baseModel: string;
}

export interface RoutingConfig {
  routingEnabled: boolean;
  llmModel: string;
  llmModelSimple?: string | null;
  llmModelComplex?: string | null;
}

export function routeForComplexity(opts: {
  config: RoutingConfig;
  complexity: Complexity;
}): RoutingDecision {
  const { config, complexity } = opts;
  const baseModel = config.llmModel;

  if (!config.routingEnabled) {
    return { model: baseModel, reason: "routing_disabled", baseModel };
  }

  if (!complexity) {
    return { model: baseModel, reason: "no_complexity", baseModel };
  }

  if (complexity === "simple") {
    const target = config.llmModelSimple?.trim();
    if (target) {
      return { model: target, reason: "simple_routed", baseModel };
    }
    return { model: baseModel, reason: "fallback", baseModel };
  }

  if (complexity === "complex") {
    const target = config.llmModelComplex?.trim();
    if (target) {
      return { model: target, reason: "complex_routed", baseModel };
    }
    return { model: baseModel, reason: "fallback", baseModel };
  }

  // moderate (or anything we don't recognise) → standard model. We label
  // this "no_complexity" rather than inventing a new reason: the operational
  // intent is "we didn't pick a routed tier", which is the same outcome.
  return { model: baseModel, reason: "no_complexity", baseModel };
}
