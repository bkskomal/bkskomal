import { getAiClients } from "./client";
import { resolveAiConfig } from "./config";
import { EmbeddingError } from "@/lib/errors";
import { embedLocal, isLocalEmbeddingUrl } from "./embeddings-local";

export async function embed(text: string, orgId: string | null | undefined): Promise<number[]> {
  try {
    // Check first: does this org want in-process local embeddings? If so,
    // route through transformers.js instead of constructing an HTTP client.
    const config = await resolveAiConfig(orgId);
    if (isLocalEmbeddingUrl(config.embedding.baseUrl)) {
      return await embedLocal(text, config.embedding.model);
    }

    const { embedder } = await getAiClients(orgId);
    const response = await embedder.embeddings.create({
      model: config.embedding.model,
      input: text,
    });
    const vec = response.data[0]?.embedding;
    if (!vec) throw new EmbeddingError("Embedding response was empty");
    return vec;
  } catch (e) {
    if (e instanceof EmbeddingError) throw e;
    const msg = e instanceof Error ? e.message : String(e);
    throw new EmbeddingError(msg);
  }
}

export async function embedBatch(
  texts: string[],
  orgId: string | null | undefined,
): Promise<number[][]> {
  if (texts.length === 0) return [];
  // Many self-hosted servers (Ollama in particular) don't accept arrays for
  // /embeddings — call sequentially to remain compatible. The local
  // transformers.js path also processes one input at a time.
  const out: number[][] = [];
  for (const text of texts) {
    out.push(await embed(text, orgId));
  }
  return out;
}
