// Provider catalog — used by the Settings UI to drive the preset dropdown
// and to auto-fill base URLs / suggested models. Adding a new provider is one
// entry here; the rest of the system is provider-agnostic (anything speaking
// the OpenAI Chat Completions API works).
//
// The catalog is exposed in two shapes:
//
//   * `PROVIDERS` (Record<AiProvider, ProviderPreset>)
//     The original shape, keyed by the AiProvider Prisma enum. Used by the
//     existing Settings form and `/api/ai-providers`.
//
//   * `ProviderDef` shape (lowercase ids)
//     The local-first shape requested by the Ollama-as-first-class-provider
//     work. Adds `recommendedModels`, `requiresApiKey`, `isLocal`, etc. for
//     the new provider-cards picker. `defaultProvider()` and
//     `detectProviderFromUrl()` work in this shape.

import { AiProvider } from "@prisma/client";

export interface ProviderPreset {
  id: AiProvider;
  label: string;
  /** Default base URL when the user picks this provider. */
  llmBaseUrl: string;
  /** Default base URL for embeddings, if the provider serves them too. */
  embeddingBaseUrl?: string;
  /** Suggested model names the user can pick from. */
  llmModels: string[];
  embeddingModels?: Array<{ name: string; dimensions: number }>;
  /** Hint for the API key field (label / placeholder). */
  keyHint?: string;
  /** Where to get a key. */
  keyUrl?: string;
  /** Does this provider serve embeddings? */
  hasEmbeddings: boolean;
  /** Whether the model list is fetchable via /v1/models. */
  hasModelsApi: boolean;
  /** Free-text help shown under the form. */
  notes?: string;
  /** True when the endpoint runs on the same machine — surface a "Local" badge. */
  isLocal: boolean;
  /** False when an API key is optional/cosmetic (e.g. local servers accept any string). */
  requiresApiKey: boolean;
  /** Lowercase id for the new provider-cards picker. */
  shortId: ProviderShortId;
}

export type ProviderShortId =
  | "ollama"
  | "openrouter"
  | "openai"
  | "lmstudio"
  | "vllm"
  | "localai"
  | "local"
  | "custom";

/**
 * Lightweight, framework-agnostic provider description used by the new
 * provider-cards picker. A pure projection of `ProviderPreset` with the
 * fields the UI needs and lowercase string ids.
 */
export interface ProviderDef {
  id: ProviderShortId;
  /** Matching AiProvider enum value, for round-tripping with the DB. */
  enumId: AiProvider;
  label: string;
  baseUrl: string;
  requiresApiKey: boolean;
  isLocal: boolean;
  recommendedModels: string[];
  docsUrl?: string;
  description: string;
}

export const PROVIDERS: Record<AiProvider, ProviderPreset> = {
  OPENROUTER: {
    id: "OPENROUTER",
    shortId: "openrouter",
    label: "OpenRouter",
    llmBaseUrl: "https://openrouter.ai/api/v1",
    llmModels: [
      // Open-weights frontier (recommended for response generation here)
      "openai/gpt-oss-120b",
      "openai/gpt-oss-20b",
      // Hosted frontier
      "anthropic/claude-sonnet-4.5",
      "anthropic/claude-opus-4.5",
      "openai/gpt-5",
      "openai/gpt-4o",
      "openai/gpt-4o-mini",
      "google/gemini-2.5-pro",
      "meta-llama/llama-3.3-70b-instruct",
      "meta-llama/llama-3.1-70b-instruct",
      "meta-llama/llama-3.1-8b-instruct",
      "mistralai/mistral-large-2411",
      "deepseek/deepseek-chat",
      "qwen/qwen-2.5-72b-instruct",
    ],
    keyHint: "sk-or-v1-...",
    keyUrl: "https://openrouter.ai/keys",
    hasEmbeddings: false,
    hasModelsApi: true,
    isLocal: false,
    requiresApiKey: true,
    notes:
      "Hundreds of frontier models behind one API key. Recommended for AutoRFP: " +
      "openai/gpt-oss-120b (open-weights, strong tool-use + grounding, competitive cost). " +
      "Does NOT serve embeddings — pair with the Local in-process BGE provider for embeddings.",
  },
  OPENAI: {
    id: "OPENAI",
    shortId: "openai",
    label: "OpenAI",
    llmBaseUrl: "https://api.openai.com/v1",
    embeddingBaseUrl: "https://api.openai.com/v1",
    llmModels: [
      "gpt-5",
      "gpt-5-mini",
      "gpt-4.1",
      "gpt-4o",
      "gpt-4o-mini",
      "o3",
      "o4-mini",
    ],
    embeddingModels: [
      { name: "text-embedding-3-small", dimensions: 1536 },
      { name: "text-embedding-3-large", dimensions: 3072 },
    ],
    keyHint: "sk-...",
    keyUrl: "https://platform.openai.com/api-keys",
    hasEmbeddings: true,
    hasModelsApi: true,
    isLocal: false,
    requiresApiKey: true,
    notes:
      "Direct to OpenAI. text-embedding-3-small is 1536-dim — make sure EMBEDDING_DIMENSIONS matches.",
  },
  OLLAMA: {
    id: "OLLAMA",
    shortId: "ollama",
    label: "Ollama (self-hosted)",
    llmBaseUrl: "http://localhost:11434/v1",
    embeddingBaseUrl: "http://localhost:11434/v1",
    llmModels: [
      "llama3.2",
      "llama3.2:3b",
      "qwen2.5:7b",
      "mistral:latest",
      "llama3.3:70b",
      "llama3.1:70b",
      "llama3.1:8b",
      "qwen2.5:72b",
      "qwen2.5:32b",
      "mistral-small:24b",
      "deepseek-r1:32b",
      "gemma3:27b",
    ],
    embeddingModels: [
      { name: "nomic-embed-text", dimensions: 768 },
      { name: "mxbai-embed-large", dimensions: 1024 },
      { name: "bge-m3", dimensions: 1024 },
    ],
    keyHint: "(no key needed)",
    keyUrl: "https://ollama.com",
    hasEmbeddings: true,
    hasModelsApi: true,
    isLocal: true,
    requiresApiKey: false,
    notes:
      "Run a model locally with `ollama pull <model>`. Both chat and embeddings are served from the same endpoint. No API key needed.",
  },
  VLLM: {
    id: "VLLM",
    shortId: "vllm",
    label: "vLLM (self-hosted)",
    llmBaseUrl: "http://localhost:8000/v1",
    llmModels: [
      "meta-llama/Meta-Llama-3.1-70B-Instruct",
      "meta-llama/Meta-Llama-3.1-8B-Instruct",
      "Qwen/Qwen2.5-72B-Instruct",
    ],
    keyHint: "any string",
    keyUrl: "https://docs.vllm.ai",
    hasEmbeddings: false,
    hasModelsApi: true,
    isLocal: true,
    requiresApiKey: false,
    notes:
      "High-throughput inference server. Run as `vllm serve <model> --port 8000`. Bring an embedding server separately.",
  },
  LMSTUDIO: {
    id: "LMSTUDIO",
    shortId: "lmstudio",
    label: "LM Studio (self-hosted)",
    llmBaseUrl: "http://localhost:1234/v1",
    embeddingBaseUrl: "http://localhost:1234/v1",
    llmModels: [],
    embeddingModels: [{ name: "nomic-embed-text-v1.5", dimensions: 768 }],
    keyHint: "(no key needed)",
    keyUrl: "https://lmstudio.ai",
    hasEmbeddings: true,
    hasModelsApi: true,
    isLocal: true,
    requiresApiKey: false,
    notes:
      "Pick a model in the LM Studio app and start the local server. Both chat and embeddings supported.",
  },
  LOCALAI: {
    id: "LOCALAI",
    shortId: "localai",
    label: "LocalAI (self-hosted)",
    llmBaseUrl: "http://localhost:8080/v1",
    embeddingBaseUrl: "http://localhost:8080/v1",
    llmModels: [],
    embeddingModels: [],
    keyHint: "any string",
    keyUrl: "https://localai.io",
    hasEmbeddings: true,
    hasModelsApi: true,
    isLocal: true,
    requiresApiKey: false,
    notes: "Open-source drop-in replacement for the OpenAI API. Supports many model formats.",
  },
  LOCAL: {
    id: "LOCAL",
    shortId: "local",
    label: "Local (in-process, no install)",
    llmBaseUrl: "local://transformers",
    embeddingBaseUrl: "local://transformers",
    llmModels: [],
    embeddingModels: [
      // Recommended: BGE Base v1.5 — 768-dim, strong semantic recall for the
      // golden-answer + chunk retrieval pipeline. First call downloads
      // ~440MB to node_modules/.cache/, then runs entirely in-process.
      { name: "BAAI/bge-base-en-v1.5", dimensions: 768 },
      { name: "BAAI/bge-small-en-v1.5", dimensions: 384 },
      { name: "BAAI/bge-large-en-v1.5", dimensions: 1024 },
      { name: "Xenova/all-MiniLM-L6-v2", dimensions: 384 },
      { name: "Xenova/all-mpnet-base-v2", dimensions: 768 },
      { name: "Xenova/multilingual-e5-small", dimensions: 384 },
    ],
    keyHint: "(no key needed)",
    hasEmbeddings: true,
    hasModelsApi: true,
    isLocal: true,
    requiresApiKey: false,
    notes:
      "Runs sentence-encoder models inside the Node server via @huggingface/transformers. " +
      "Recommended: BAAI/bge-base-en-v1.5 (768-dim) — first call downloads ~440MB " +
      "to node_modules/.cache. No external service or API key required.",
  },
  CUSTOM: {
    id: "CUSTOM",
    shortId: "custom",
    label: "Custom (OpenAI-compatible)",
    llmBaseUrl: "",
    llmModels: [],
    keyHint: "API key",
    hasEmbeddings: true,
    hasModelsApi: false,
    isLocal: false,
    requiresApiKey: true,
    notes:
      "Any server that implements the OpenAI Chat Completions API. Set the base URL and model name manually.",
  },
};

/**
 * Lowercase-id projections, matching the `ProviderDef` shape consumed by the
 * new provider-cards UI. Order matters — Ollama first because it's the
 * recommended local default.
 */
export const PROVIDER_DEFS: ProviderDef[] = [
  toProviderDef(PROVIDERS.OLLAMA, "Local Ollama server. No API key. Run `ollama serve` and `ollama pull llama3.2`."),
  toProviderDef(PROVIDERS.OPENROUTER, "Hundreds of frontier models behind one API key."),
  toProviderDef(PROVIDERS.OPENAI, "Direct connection to OpenAI's hosted API."),
  toProviderDef(PROVIDERS.LMSTUDIO, "LM Studio app exposes an OpenAI-compatible server on port 1234."),
  toProviderDef(PROVIDERS.VLLM, "High-throughput inference server, typically on port 8000."),
  toProviderDef(PROVIDERS.LOCALAI, "Open-source OpenAI-compatible API, typically on port 8080."),
  toProviderDef(PROVIDERS.CUSTOM, "Any other OpenAI-compatible endpoint."),
];

function toProviderDef(p: ProviderPreset, description: string): ProviderDef {
  return {
    id: p.shortId,
    enumId: p.id,
    label: p.label,
    baseUrl: p.llmBaseUrl,
    requiresApiKey: p.requiresApiKey,
    isLocal: p.isLocal,
    recommendedModels: p.llmModels,
    docsUrl: p.keyUrl,
    description,
  };
}

/**
 * Detect the provider from a base URL using simple substring matching.
 * Returns the lowercase shortId for the new picker UI; mirrors the
 * AiProvider-shaped `inferProviderFromUrl` below.
 */
export function detectProviderFromUrl(url: string | null | undefined): ProviderShortId {
  if (!url) return "custom";
  const u = url.toLowerCase();
  if (u.startsWith("local://")) return "local";
  if (u.includes("openrouter.ai")) return "openrouter";
  if (u.includes("api.openai.com")) return "openai";
  if (u.includes("11434")) return "ollama";
  if (u.includes("1234")) return "lmstudio";
  if (u.includes("localai") || u.includes(":8080")) return "localai";
  if (u.includes(":8000")) return "vllm";
  return "custom";
}

/**
 * Pick the right default provider for the current environment. If the user
 * has set `LLM_BASE_URL` to a recognisable endpoint, we honour that.
 * Otherwise we recommend Ollama — the local-first sensible default.
 *
 * Reads `process.env.LLM_BASE_URL` directly rather than going through the
 * validated `env` proxy so this stays usable from places that haven't (or
 * shouldn't) initialise the full env (tests, build-time imports).
 */
export function defaultProvider(): ProviderDef {
  const envUrl = process.env.LLM_BASE_URL;
  if (envUrl && envUrl.trim().length > 0) {
    const id = detectProviderFromUrl(envUrl);
    const found = PROVIDER_DEFS.find((p) => p.id === id);
    if (found) return found;
  }
  // Fall back to Ollama — the local-first default for fresh installs.
  const ollama = PROVIDER_DEFS.find((p) => p.id === "ollama");
  if (!ollama) throw new Error("Ollama provider missing from catalog (this should not happen)");
  return ollama;
}

export function inferProviderFromUrl(url: string | null | undefined): AiProvider {
  if (!url) return "CUSTOM";
  const u = url.toLowerCase();
  if (u.startsWith("local://")) return "LOCAL";
  if (u.includes("openrouter.ai")) return "OPENROUTER";
  if (u.includes("api.openai.com")) return "OPENAI";
  if (u.includes("11434")) return "OLLAMA";
  if (u.includes("1234")) return "LMSTUDIO";
  if (u.includes("localai") || u.includes(":8080")) return "LOCALAI";
  if (u.includes(":8000")) return "VLLM";
  return "CUSTOM";
}
