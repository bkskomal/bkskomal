// Helpers for parsing JSON returned by LLMs.
//
// Why this file exists: a number of models (notably Claude Sonnet via
// OpenRouter as of 2026-05) IGNORE `response_format: { type: "json_object" }`
// and wrap their response in Markdown code fences anyway:
//
//   ```json
//   { "questions": [...] }
//   ```
//
// `JSON.parse` throws on the leading backticks, callers swallow the throw,
// and the downstream pipeline silently sees an empty result. Question
// extraction returned 0 questions for every Claude-Sonnet-via-OpenRouter
// RFP because of this exact bug. Strip the fences first, parse second.
//
// Also handles trivial wrapper preambles ("Here's the JSON:") that some
// models add when they decide to be helpful.

/**
 * Strip Markdown code fences (` ```json … ``` `) and other common preambles
 * from an LLM response that should be JSON. No-op on already-clean JSON.
 */
export function stripCodeFences(raw: string): string {
  let s = (raw ?? "").trim();

  // Strip "Here's the JSON:" / "Result:" prefaces some models add before
  // the actual JSON. Conservative: only the most common patterns.
  s = s.replace(/^(?:here(?:'s| is)? the (?:json|result)[:\s]*\n+)/i, "");
  s = s.replace(/^(?:result|response|output)\s*[:=]\s*\n+/i, "");

  // Leading ``` or ```json (with optional language tag).
  s = s.replace(/^```(?:json|JSON|jsonc|JS|js|ts|TS|markdown)?\s*\n?/, "");
  // Trailing ``` on its own (possibly indented).
  s = s.replace(/\n?```\s*$/, "");

  return s.trim();
}

/**
 * Like JSON.parse but tolerates LLM fence-wrapping. Returns `fallback`
 * on parse failure instead of throwing.
 */
export function parseLlmJson<T>(raw: string, fallback: T): T {
  try {
    return JSON.parse(stripCodeFences(raw)) as T;
  } catch {
    return fallback;
  }
}
