import { describe, expect, it, beforeEach, vi } from "vitest";

// Hoisted mocks — must be created via vi.hoisted so the vi.mock factory can
// close over them. We mock @/lib/ai/client (the LLM client factory) so the
// grounding judge runs against a canned chat completion instead of hitting a
// real LLM.

const { llmCreateMock, getAiClientsMock } = vi.hoisted(() => {
  const llmCreateMock = vi.fn();
  return {
    llmCreateMock,
    getAiClientsMock: vi.fn(async () => ({
      llm: { chat: { completions: { create: llmCreateMock } } },
      // Phase A.4: grounding.ts now reads config.generation.groundingModel
      // and falls back to config.llm.model when empty. Mock supplies an empty
      // override so tests keep asserting on "test-judge-model" (same chain
      // the resolver provides when no per-org grounding model is set).
      config: {
        llm: { model: "test-judge-model", baseUrl: "http://test", apiKey: "x" },
        generation: { groundingModel: "" },
      },
      embedder: {},
    })),
  };
});

vi.mock("@/lib/ai/client", () => ({
  getAiClients: (...args: unknown[]) => (getAiClientsMock as (...a: unknown[]) => unknown)(...args),
}));

import {
  scoreGrounding,
  computeScore,
  SUPPORT_WEIGHTS,
  MAX_CHARS_PER_SOURCE,
  MAX_SOURCES,
  _internals,
  type GroundingClaim,
} from "./grounding";

const ORG = "org-test";

function judgeReturns(payload: unknown) {
  llmCreateMock.mockResolvedValueOnce({
    choices: [{ message: { content: typeof payload === "string" ? payload : JSON.stringify(payload) } }],
  });
}

beforeEach(() => {
  vi.clearAllMocks();
});

// ---------------------------------------------------------------------------
// computeScore — pure formula
// ---------------------------------------------------------------------------

describe("computeScore", () => {
  it("returns 1 for an empty claim list (nothing to fact-check)", () => {
    expect(computeScore([])).toBe(1);
  });

  it("scores per the supported=1 / weak=0.5 / unsupported=0 weights", () => {
    expect(SUPPORT_WEIGHTS.supported).toBe(1);
    expect(SUPPORT_WEIGHTS.weak).toBe(0.5);
    expect(SUPPORT_WEIGHTS.unsupported).toBe(0);
  });

  it("averages mixed supported/weak/unsupported labels", () => {
    const claims: GroundingClaim[] = [
      { claim: "a", support: "supported" },
      { claim: "b", support: "supported" },
      { claim: "c", support: "weak" },
      { claim: "d", support: "unsupported" },
    ];
    // (1 + 1 + 0.5 + 0) / 4 = 0.625
    expect(computeScore(claims)).toBeCloseTo(0.625, 6);
  });

  it("handles all-supported and all-unsupported edge cases", () => {
    expect(
      computeScore([
        { claim: "a", support: "supported" },
        { claim: "b", support: "supported" },
      ]),
    ).toBe(1);
    expect(
      computeScore([
        { claim: "a", support: "unsupported" },
        { claim: "b", support: "unsupported" },
      ]),
    ).toBe(0);
  });

  it("clamps numerical noise into [0, 1]", () => {
    // Forge a label outside the known set — formula treats it as 0, average
    // stays in range. (Defense-in-depth — the parser already filters these.)
    const claims = [{ claim: "x", support: "weak" as const }];
    expect(computeScore(claims)).toBeGreaterThanOrEqual(0);
    expect(computeScore(claims)).toBeLessThanOrEqual(1);
  });
});

// ---------------------------------------------------------------------------
// scoreGrounding — happy path + LLM mock
// ---------------------------------------------------------------------------

describe("scoreGrounding (LLM mocked)", () => {
  it("computes the score from the judge JSON and maps source indices to ids", async () => {
    judgeReturns({
      claims: [
        { claim: "AES-256 at rest.", support: "supported", source_ids: [1] },
        { claim: "Daily backups.", support: "weak", source_ids: [2], note: "implied" },
        { claim: "ISO 27001 certified.", support: "unsupported", note: "no source mentions ISO" },
      ],
    });

    const result = await scoreGrounding({
      content: "We use AES-256 at rest. Daily backups. ISO 27001 certified.",
      sources: [
        { id: "src-A", content: "Encryption at rest uses AES-256.", fileName: "sec.md" },
        { id: "src-B", content: "Backups run nightly.", fileName: "ops.md" },
      ],
      organizationId: ORG,
    });

    // (1 + 0.5 + 0) / 3 = 0.5
    expect(result.score).toBeCloseTo(0.5, 6);
    expect(result.claims).toHaveLength(3);
    expect(result.claims[0]).toMatchObject({
      claim: "AES-256 at rest.",
      support: "supported",
      sourceIds: ["src-A"],
    });
    expect(result.claims[1]).toMatchObject({
      claim: "Daily backups.",
      support: "weak",
      sourceIds: ["src-B"],
    });
    expect(result.claims[2]).toMatchObject({ support: "unsupported" });
    expect(result.judgeModel).toBe("test-judge-model");
    expect(result.ms).toBeGreaterThanOrEqual(0);
  });

  it("returns score 1.0 with no LLM call for empty content", async () => {
    const result = await scoreGrounding({
      content: "   \n\n  ",
      sources: [{ id: "s1", content: "anything" }],
      organizationId: ORG,
    });
    expect(result.score).toBe(1);
    expect(result.claims).toEqual([]);
    expect(llmCreateMock).not.toHaveBeenCalled();
  });

  it("returns score 1.0 when the judge says there are no factual claims", async () => {
    judgeReturns({ claims: [] });
    const result = await scoreGrounding({
      content: "Sorry, I cannot answer that without more information.",
      sources: [],
      organizationId: ORG,
    });
    expect(result.score).toBe(1);
    expect(result.claims).toEqual([]);
  });

  it("falls back to score 0 with a parse-error pseudo-claim on invalid JSON", async () => {
    judgeReturns("definitely not json { ::");
    const result = await scoreGrounding({
      content: "Some answer with claims.",
      sources: [{ id: "s1", content: "anything" }],
      organizationId: ORG,
    });
    expect(result.score).toBe(0);
    expect(result.claims).toHaveLength(1);
    expect(result.claims[0].support).toBe("unsupported");
    expect(result.claims[0].note).toMatch(/Judge error/);
  });

  it("falls back to score 0 on LLM client failure (network / breaker)", async () => {
    llmCreateMock.mockRejectedValueOnce(new Error("LLM down"));
    const result = await scoreGrounding({
      content: "Some answer with claims.",
      sources: [{ id: "s1", content: "anything" }],
      organizationId: ORG,
    });
    expect(result.score).toBe(0);
    expect(result.claims[0].note).toContain("LLM down");
  });

  it("ignores out-of-range source_ids without throwing", async () => {
    judgeReturns({
      claims: [
        { claim: "X.", support: "supported", source_ids: [1, 99, "bogus"] },
      ],
    });
    const result = await scoreGrounding({
      content: "X.",
      sources: [{ id: "src-A", content: "x is real" }],
      organizationId: ORG,
    });
    expect(result.claims[0].sourceIds).toEqual(["src-A"]);
  });

  it("normalizes unknown support labels to 'unsupported'", async () => {
    judgeReturns({
      claims: [{ claim: "Y.", support: "MAYBE_OK" }],
    });
    const result = await scoreGrounding({
      content: "Y.",
      sources: [],
      organizationId: ORG,
    });
    expect(result.claims[0].support).toBe("unsupported");
    expect(result.score).toBe(0);
  });

  it("treats valid JSON without a `claims` array as 'no claims' (score 1)", async () => {
    judgeReturns({ unrelated: "shape" });
    const result = await scoreGrounding({
      content: "Some answer.",
      sources: [],
      organizationId: ORG,
    });
    expect(result.score).toBe(1);
    expect(result.claims).toEqual([]);
  });
});

// ---------------------------------------------------------------------------
// Source truncation — internals
// ---------------------------------------------------------------------------

describe("source truncation", () => {
  it("respects MAX_CHARS_PER_SOURCE per excerpt", () => {
    const big = "word ".repeat(2000); // ~10000 chars, well over the cap
    const block = _internals.buildSourceBlock([
      { id: "s1", content: big, fileName: "big.md" },
    ]);
    // Header line + truncated body. Block is much smaller than the raw input.
    expect(block.length).toBeLessThan(big.length);
    // Body length itself stays at or just under the cap (allow +1 for the
    // trailing ellipsis added by truncate()).
    const body = block.split("\n").slice(1).join("\n");
    expect(body.length).toBeLessThanOrEqual(MAX_CHARS_PER_SOURCE + 1);
  });

  it("includes [Source N] tags numbered 1-based", () => {
    const block = _internals.buildSourceBlock([
      { id: "a", content: "alpha" },
      { id: "b", content: "beta" },
      { id: "c", content: "gamma" },
    ]);
    expect(block).toContain("[Source 1]");
    expect(block).toContain("[Source 2]");
    expect(block).toContain("[Source 3]");
  });

  it("caps at MAX_SOURCES sources via slice in scoreGrounding", async () => {
    const sources = Array.from({ length: MAX_SOURCES + 5 }, (_, i) => ({
      id: `s${i}`,
      content: `body${i}`,
    }));
    judgeReturns({ claims: [] });
    await scoreGrounding({
      content: "answer",
      sources,
      organizationId: ORG,
    });
    // Pull the prompt user message and assert it contains [Source 8] but not
    // [Source 9].
    const callArgs = llmCreateMock.mock.calls[0]?.[0] as {
      messages: Array<{ role: string; content: string }>;
    };
    const user = callArgs.messages.find((m) => m.role === "user");
    expect(user?.content).toContain(`[Source ${MAX_SOURCES}]`);
    expect(user?.content).not.toContain(`[Source ${MAX_SOURCES + 1}]`);
  });

  it("truncate() leaves shorter strings untouched", () => {
    expect(_internals.truncate("hello", 100)).toBe("hello");
  });
});
