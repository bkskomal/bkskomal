// Research agent — unit tests (Phase C).
//
// Both the LLM client and the searchIndex retrieval are mocked so the tests
// exercise the LangGraph state machine without any I/O. Coverage:
//   - Happy path: plan → search → draft → critique(sufficient) → END,
//     emits agent_plan / agent_search / agent_draft / agent_critique / agent_done
//   - Iterative loop: critique returns gaps → re-search → re-draft, bounded by
//     maxIterations
//   - Sources merge across iterations (dedup by id)
//   - Missing indexId (ORG scope) skips search without blowing up
//   - Search failure on one query doesn't break the rest

import { describe, expect, it, beforeEach, vi } from "vitest";

const { llmCreateMock, searchIndexMock } = vi.hoisted(() => ({
  llmCreateMock: vi.fn(),
  searchIndexMock: vi.fn(),
}));

vi.mock("../client", () => ({
  getAiClients: async () => ({
    llm: { chat: { completions: { create: llmCreateMock } } },
    config: {
      llm: { model: "draft-model" },
      extraction: { model: "extract-model" },
    },
  }),
}));

vi.mock("../retrieval", () => ({
  searchIndex: (...args: unknown[]) => searchIndexMock(...args),
}));

import { runResearchAgent, type AgentStep } from "./research-agent";

const ORG = "org-1";
const INDEX = "idx-1";

function chunk(id: string, content: string) {
  return {
    id,
    documentId: `doc-${id}`,
    documentName: `Doc ${id}`,
    fileName: `${id}.md`,
    ordinal: 0,
    page: null,
    content,
    score: 0.9,
  };
}

beforeEach(() => {
  llmCreateMock.mockReset();
  searchReset();
});

function searchReset() {
  searchIndexMock.mockReset();
}

describe("runResearchAgent — happy path", () => {
  it("plan → search → draft → critique(sufficient) emits all events in order and returns content", async () => {
    // PLAN call returns 2 queries.
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"queries":["sla terms","incident response"]}' } }],
    });
    // SEARCH returns 2 chunks per query.
    searchIndexMock.mockResolvedValue([chunk("a", "Our SLA is 99.95%"), chunk("b", "Incident response is 30 min")]);
    // DRAFT call returns the answer.
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "Our SLA is 99.95% [Source 1]. Incident response within 30 min [Source 2]." } }],
    });
    // CRITIQUE call says sufficient.
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":true,"gaps":[]}' } }],
    });

    const events: AgentStep[] = [];
    const result = await runResearchAgent({
      question: "What is your SLA + incident response?",
      organizationId: ORG,
      indexId: INDEX,
      scope: "INDEX",
      onStep: (e) => events.push(e),
    });

    expect(result.content).toMatch(/99\.95%/);
    expect(result.iterations).toBe(1);
    expect(result.sufficient).toBe(true);
    // Sources are deduped across the two search calls (both returned same ids).
    expect(result.sources.map((s) => s.id).sort()).toEqual(["a", "b"]);
    // Event ordering — plan, search (x2 queries), draft, critique, done.
    const order = events.map((e) => e.step);
    expect(order[0]).toBe("agent_plan");
    expect(order.filter((s) => s === "agent_search").length).toBe(2);
    expect(order).toContain("agent_draft");
    expect(order).toContain("agent_critique");
    expect(order[order.length - 1]).toBe("agent_done");
  });
});

describe("runResearchAgent — iterative refinement", () => {
  it("loops when critique returns gaps and stops at maxIterations", async () => {
    // PLAN (initial): one query
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"queries":["sla"]}' } }],
    });
    // SEARCH always returns chunks (different ids per call to verify merge).
    let callIdx = 0;
    searchIndexMock.mockImplementation(async () => {
      callIdx++;
      return [chunk(`c${callIdx}`, `chunk-${callIdx}`)];
    });
    // DRAFT (round 1)
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "first draft" } }],
    });
    // CRITIQUE (round 1): gaps exist
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":false,"gaps":["security details"]}' } }],
    });
    // DRAFT (round 2) — after re-search
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "better draft" } }],
    });
    // CRITIQUE (round 2): still gaps — should now hit cap and exit
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":false,"gaps":["more details"]}' } }],
    });

    const result = await runResearchAgent({
      question: "Tell me about security",
      organizationId: ORG,
      indexId: INDEX,
      scope: "INDEX",
      maxIterations: 2,
    });

    expect(result.iterations).toBe(2);
    expect(result.sufficient).toBe(false); // hit cap, not satisfied
    expect(result.content).toBe("better draft");
    // 2 search rounds, 2 different chunk ids accumulated.
    expect(result.sources.length).toBe(2);
  });

  it("stops early when critique returns empty gaps even if sufficient is false", async () => {
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"queries":["q1"]}' } }],
    });
    searchIndexMock.mockResolvedValue([chunk("x", "content")]);
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "draft" } }],
    });
    // Critique: sufficient=false but no gaps to chase → END
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":false,"gaps":[]}' } }],
    });

    const result = await runResearchAgent({
      question: "anything",
      organizationId: ORG,
      indexId: INDEX,
      scope: "INDEX",
      maxIterations: 5,
    });
    expect(result.iterations).toBe(1);
    expect(searchIndexMock).toHaveBeenCalledTimes(1);
  });
});

describe("runResearchAgent — degrades gracefully", () => {
  it("skips retrieval when indexId is null (ORG scope)", async () => {
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"queries":["q1"]}' } }],
    });
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "answer from general knowledge" } }],
    });
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":true,"gaps":[]}' } }],
    });

    const result = await runResearchAgent({
      question: "broad question",
      organizationId: ORG,
      indexId: null,
      scope: "ORG",
    });
    expect(searchIndexMock).not.toHaveBeenCalled();
    expect(result.sources).toEqual([]);
    expect(result.content).toContain("general knowledge");
  });

  it("continues when some search queries fail", async () => {
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"queries":["q1","q2"]}' } }],
    });
    // First query throws, second succeeds.
    searchIndexMock
      .mockRejectedValueOnce(new Error("vector store down"))
      .mockResolvedValueOnce([chunk("ok", "kept content")]);
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "draft using one source" } }],
    });
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":true,"gaps":[]}' } }],
    });

    const result = await runResearchAgent({
      question: "anything",
      organizationId: ORG,
      indexId: INDEX,
      scope: "INDEX",
    });
    expect(result.sources.map((s) => s.id)).toEqual(["ok"]);
    expect(result.content).toBe("draft using one source");
  });

  it("uses the question itself when the planner returns malformed JSON", async () => {
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "not json at all" } }],
    });
    searchIndexMock.mockResolvedValue([chunk("a", "content")]);
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "draft" } }],
    });
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":true,"gaps":[]}' } }],
    });

    await runResearchAgent({
      question: "fallback question",
      organizationId: ORG,
      indexId: INDEX,
      scope: "INDEX",
    });
    // Search called once with the literal question as the fallback query.
    expect(searchIndexMock).toHaveBeenCalledWith(
      INDEX,
      "fallback question",
      expect.any(Object),
    );
  });
});
