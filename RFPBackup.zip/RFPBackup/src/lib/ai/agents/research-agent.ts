// Research agent (Phase C) — LangGraph multi-step RAG loop.
//
// Wraps the existing retrieval + LLM stack as a stateful agent that:
//   1. PLAN — decompose the question into 1-3 search queries
//   2. SEARCH — run searchIndex for each, accumulate sources
//   3. DRAFT — write a cited answer using all accumulated sources
//   4. CRITIQUE — review the draft against sources; if gaps exist and we
//      haven't hit the iteration cap, generate gap queries and loop back
//      to SEARCH; otherwise END.
//
// The default single-shot generate.ts path stays. This agent is opt-in via
// the chat UI "Agentic" toggle and a per-request `enableAgentic` flag.
//
// Emits the existing `ChatStep` event shape so the chat UI's StepsTrace
// renders agent reasoning the same way it renders tool calls — no UI
// changes required to see plan/search/critique events stream in.

import { StateGraph, START, END, Annotation } from "@langchain/langgraph";
import { getAiClients, type AiClients } from "../client";
import { searchIndex, type RetrievedChunk } from "../retrieval";
import { stripCodeFences } from "../json-utils";
import { log } from "@/lib/logger";
import type { ChatScope } from "@prisma/client";

// ---- Public types ---------------------------------------------------------

export type AgentStep =
  | { step: "agent_plan"; detail: string; data: { queries: string[] } }
  | { step: "agent_search"; detail: string; data: { query: string; hits: number } }
  | { step: "agent_draft"; detail: string; data: { sources: number; chars: number } }
  | { step: "agent_critique"; detail: string; data: { sufficient: boolean; gaps: string[] } }
  | { step: "agent_done"; detail: string; data: { iterations: number; totalSources: number } }
  | { step: "agent_error"; detail: string; data: { error: string } };

export interface ResearchAgentInput {
  question: string;
  organizationId: string;
  /** When set, retrieval is scoped to a single index. ORG scope leaves this null. */
  indexId: string | null;
  scope: ChatScope;
  /** Cap on the search→draft→critique→search loop. Default 3. */
  maxIterations?: number;
  /** SSE event sink (chat route forwards these to the client). */
  onStep?: (event: AgentStep) => void;
}

export interface ResearchAgentResult {
  /** Final assistant content (markdown). */
  content: string;
  /** Every chunk used to ground the final answer. */
  sources: RetrievedChunk[];
  /** How many search rounds ran. */
  iterations: number;
  /** Was the loop exited because critique said "sufficient" vs hit the cap? */
  sufficient: boolean;
}

// ---- Internal state shape -------------------------------------------------

// LangGraph v1 uses Annotation.Root for declarative state schemas with
// per-channel reducers. Sources accumulate across iterations (deduped by id);
// every other field is overwritten by the latest node output.
const ResearchState = Annotation.Root({
  question: Annotation<string>(),
  organizationId: Annotation<string>(),
  indexId: Annotation<string | null>(),
  scope: Annotation<ChatScope>(),
  plan: Annotation<string[]>({
    reducer: (_prev, next) => next,
    default: () => [],
  }),
  sources: Annotation<RetrievedChunk[]>({
    // Merge + dedupe by id so multiple search rounds don't double-count.
    reducer: (prev, next) => {
      if (!next || next.length === 0) return prev ?? [];
      const seen = new Set((prev ?? []).map((s) => s.id));
      const merged = [...(prev ?? [])];
      for (const s of next) {
        if (!seen.has(s.id)) {
          seen.add(s.id);
          merged.push(s);
        }
      }
      return merged;
    },
    default: () => [],
  }),
  draft: Annotation<string>({
    reducer: (_prev, next) => next,
    default: () => "",
  }),
  critique: Annotation<{ sufficient: boolean; gaps: string[] } | null>({
    reducer: (_prev, next) => next,
    default: () => null,
  }),
  iteration: Annotation<number>({
    reducer: (_prev, next) => next,
    default: () => 0,
  }),
  maxIterations: Annotation<number>(),
});

type ResearchStateType = typeof ResearchState.State;

// ---- Per-node helpers -----------------------------------------------------

interface NodeCtx {
  clients: AiClients;
  emit: (event: AgentStep) => void;
}

const PLAN_SYSTEM = `You are a research planner for an RFP knowledge base. Given a user question, output a JSON object {"queries": [string, ...]} with 1-3 short search queries that, taken together, would retrieve the documents needed to answer the question. Prefer specific terms over paraphrases. Output ONLY JSON, no preamble.`;

const DRAFT_SYSTEM = `You answer questions using ONLY the provided sources. Every factual claim must cite a source as [Source N] where N is the 1-based index in the SOURCES block. If the sources don't contain the answer, say so plainly — never invent facts. Markdown allowed.`;

const CRITIQUE_SYSTEM = `You are a critic checking whether a drafted answer is sufficient given the sources. Output JSON: {"sufficient": boolean, "gaps": [string, ...]}. "sufficient" = true means the draft fully answers the question with the available sources; "gaps" is an array of 0-3 SHORT search queries that would retrieve any missing facts. If sufficient=true, gaps must be []. Output ONLY JSON.`;

function parseQueriesJson(raw: string, fallback: string): string[] {
  try {
    const parsed = JSON.parse(stripCodeFences(raw));
    if (parsed && Array.isArray(parsed.queries)) {
      const cleaned = parsed.queries
        .filter((q: unknown): q is string => typeof q === "string" && q.trim().length > 0)
        .map((q: string) => q.trim())
        .slice(0, 3);
      if (cleaned.length > 0) return cleaned;
    }
  } catch {
    // ignore — fall through to fallback
  }
  return [fallback];
}

function parseCritiqueJson(raw: string): { sufficient: boolean; gaps: string[] } {
  try {
    const parsed = JSON.parse(stripCodeFences(raw));
    if (parsed && typeof parsed === "object") {
      const sufficient = parsed.sufficient === true;
      const gaps = Array.isArray(parsed.gaps)
        ? parsed.gaps
            .filter((g: unknown): g is string => typeof g === "string" && g.trim().length > 0)
            .map((g: string) => g.trim())
            .slice(0, 3)
        : [];
      return { sufficient, gaps };
    }
  } catch {
    // ignore
  }
  // Conservative default — assume sufficient on parse failure so we stop
  // looping rather than spin forever.
  return { sufficient: true, gaps: [] };
}

function buildSourceBlock(sources: RetrievedChunk[]): string {
  return sources
    .map((s, i) => {
      const head = `[Source ${i + 1}] ${s.documentName}${s.page ? ` p.${s.page}` : ""}`;
      // Cap each source at ~1KB so the prompt stays in budget on 20+ source draws.
      const body = s.content.length > 1000 ? s.content.slice(0, 1000) + "…" : s.content;
      return `${head}\n${body}`;
    })
    .join("\n\n---\n\n");
}

// ---- Nodes ----------------------------------------------------------------

function planNode(ctx: NodeCtx) {
  return async (state: ResearchStateType): Promise<Partial<ResearchStateType>> => {
    const completion = await ctx.clients.llm.chat.completions.create({
      model: ctx.clients.config.extraction.model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: PLAN_SYSTEM },
        { role: "user", content: state.question },
      ],
    });
    const raw = completion.choices[0]?.message?.content ?? "{}";
    const queries = parseQueriesJson(raw, state.question);
    ctx.emit({
      step: "agent_plan",
      detail: `Decomposed into ${queries.length} search ${queries.length === 1 ? "query" : "queries"}`,
      data: { queries },
    });
    return { plan: queries };
  };
}

function searchNode(ctx: NodeCtx) {
  return async (state: ResearchStateType): Promise<Partial<ResearchStateType>> => {
    if (!state.indexId) {
      // ORG-scope and similar — retrieval requires an index. Skip silently
      // and let drafting work from whatever conversation context exists.
      ctx.emit({
        step: "agent_search",
        detail: "No indexId in scope — skipping retrieval",
        data: { query: "", hits: 0 },
      });
      return { sources: [] };
    }
    const fresh: RetrievedChunk[] = [];
    for (const query of state.plan) {
      try {
        const hits = await searchIndex(state.indexId, query, { topK: 5, rerank: true });
        ctx.emit({
          step: "agent_search",
          detail: `"${query}" → ${hits.length} hits`,
          data: { query, hits: hits.length },
        });
        fresh.push(...hits);
      } catch (err) {
        log().warn(
          { orgId: state.organizationId, query, err: err instanceof Error ? err.message : String(err) },
          "research-agent search failed for query",
        );
      }
    }
    return { sources: fresh };
  };
}

function draftNode(ctx: NodeCtx) {
  return async (state: ResearchStateType): Promise<Partial<ResearchStateType>> => {
    const sourceBlock = buildSourceBlock(state.sources);
    const userPrompt = sourceBlock
      ? `# QUESTION\n${state.question}\n\n# SOURCES\n${sourceBlock}`
      : `# QUESTION\n${state.question}\n\n(no sources retrieved — answer from general knowledge or say you don't know)`;
    const completion = await ctx.clients.llm.chat.completions.create({
      model: ctx.clients.config.llm.model,
      temperature: 0.2,
      messages: [
        { role: "system", content: DRAFT_SYSTEM },
        { role: "user", content: userPrompt },
      ],
    });
    const draft = completion.choices[0]?.message?.content ?? "";
    ctx.emit({
      step: "agent_draft",
      detail: `Drafted answer (${draft.length} chars, ${state.sources.length} sources)`,
      data: { sources: state.sources.length, chars: draft.length },
    });
    return { draft };
  };
}

function critiqueNode(ctx: NodeCtx) {
  return async (state: ResearchStateType): Promise<Partial<ResearchStateType>> => {
    const userPrompt = [
      `# QUESTION\n${state.question}`,
      `# DRAFT\n${state.draft}`,
      `# SOURCES\n${buildSourceBlock(state.sources)}`,
    ].join("\n\n");
    const completion = await ctx.clients.llm.chat.completions.create({
      model: ctx.clients.config.extraction.model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: CRITIQUE_SYSTEM },
        { role: "user", content: userPrompt },
      ],
    });
    const raw = completion.choices[0]?.message?.content ?? "{}";
    const critique = parseCritiqueJson(raw);
    ctx.emit({
      step: "agent_critique",
      detail: critique.sufficient
        ? "Draft is sufficient"
        : `Draft has ${critique.gaps.length} gap${critique.gaps.length === 1 ? "" : "s"}`,
      data: critique,
    });
    // The next iteration's PLAN is the critique's gaps. Bump iteration.
    return {
      critique,
      plan: critique.gaps,
      iteration: state.iteration + 1,
    };
  };
}

function shouldContinue(state: ResearchStateType): "searchNode" | typeof END {
  // Stop when the critic said sufficient, OR we've hit the iteration cap,
  // OR there are no gap queries to chase (empty gaps).
  if (!state.critique) return END;
  if (state.critique.sufficient) return END;
  if (state.critique.gaps.length === 0) return END;
  if (state.iteration >= state.maxIterations) return END;
  return "searchNode";
}

// ---- Public entry point ---------------------------------------------------

/**
 * Run the research agent against a question. Returns the final draft + the
 * union of sources used across all search rounds. Emits AgentStep events
 * via the optional `onStep` callback — pass them through to the chat SSE
 * stream so the UI shows plan/search/critique events as they happen.
 */
export async function runResearchAgent(
  input: ResearchAgentInput,
): Promise<ResearchAgentResult> {
  const maxIterations = input.maxIterations ?? 3;
  const clients = await getAiClients(input.organizationId);
  const emit = (event: AgentStep) => {
    try {
      input.onStep?.(event);
    } catch {
      // event sink failures must never break the agent
    }
  };
  const ctx: NodeCtx = { clients, emit };

  // LangGraph v1 forbids node names that collide with state channel names
  // ("plan", "draft", etc. are channels) — so suffix every node with "Node".
  const graph = new StateGraph(ResearchState)
    .addNode("planNode", planNode(ctx))
    .addNode("searchNode", searchNode(ctx))
    .addNode("draftNode", draftNode(ctx))
    .addNode("critiqueNode", critiqueNode(ctx))
    .addEdge(START, "planNode")
    .addEdge("planNode", "searchNode")
    .addEdge("searchNode", "draftNode")
    .addEdge("draftNode", "critiqueNode")
    .addConditionalEdges("critiqueNode", shouldContinue, {
      searchNode: "searchNode",
      [END]: END,
    });

  const compiled = graph.compile();

  try {
    const final = await compiled.invoke({
      question: input.question,
      organizationId: input.organizationId,
      indexId: input.indexId,
      scope: input.scope,
      maxIterations,
    });
    emit({
      step: "agent_done",
      detail: `Done after ${final.iteration} iteration${final.iteration === 1 ? "" : "s"}`,
      data: { iterations: final.iteration, totalSources: final.sources.length },
    });
    return {
      content: final.draft,
      sources: final.sources,
      iterations: final.iteration,
      sufficient: final.critique?.sufficient ?? true,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    emit({
      step: "agent_error",
      detail: "Agent failed — falling back to whatever draft we had",
      data: { error: message },
    });
    log().error(
      { orgId: input.organizationId, err: message },
      "research-agent crashed",
    );
    throw err;
  }
}
