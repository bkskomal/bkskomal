// agentic-chat — integration test (Phase C verification).
//
// Drives the wrapper the chat route actually calls. Mocks Prisma + LLM +
// retrieval so the full plan→search→draft→critique→done pipeline runs
// in-process. Verifies:
//   - user message persisted BEFORE the agent runs (so reloads see it)
//   - assistant message persisted at the end with sources + agent metadata
//   - thread updatedAt bumped
//   - AgentStep events get translated to ChatStep events the UI understands
//   - agent failures still save an error-shaped assistant message

import { describe, expect, it, beforeEach, vi } from "vitest";

const { llmCreateMock, searchIndexMock, prismaMock } = vi.hoisted(() => ({
  llmCreateMock: vi.fn(),
  searchIndexMock: vi.fn(),
  prismaMock: {
    chatMessage: {
      create: vi.fn(async (args: { data: { role: string; content: string } }) => ({
        id: `msg-${args.data.role.toLowerCase()}-${Date.now()}`,
        ...args.data,
      })),
    },
    chatThread: {
      update: vi.fn(async () => ({})),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

vi.mock("../client", () => ({
  getAiClients: async () => ({
    llm: { chat: { completions: { create: llmCreateMock } } },
    config: {
      llm: { model: "draft-model" },
      extraction: { model: "extract-model" },
    },
  }),
}));

vi.mock("../retrieval", () => ({
  searchIndex: (...args: unknown[]) => searchIndexMock(...args),
}));

import { runAgenticChatTurn } from "./agentic-chat";
import type { ChatStep } from "../chat";

beforeEach(() => {
  llmCreateMock.mockReset();
  searchIndexMock.mockReset();
  prismaMock.chatMessage.create.mockClear();
  prismaMock.chatThread.update.mockClear();
});

function chunk(id: string, content: string) {
  return {
    id,
    documentId: `doc-${id}`,
    documentName: `Doc ${id}`,
    fileName: `${id}.md`,
    ordinal: 0,
    page: null,
    content,
    score: 0.9,
  };
}

describe("runAgenticChatTurn — full happy path", () => {
  it("persists user message, runs agent, persists assistant message with metadata, emits translated steps", async () => {
    // 1) plan → 2 queries
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"queries":["sla","incident"]}' } }],
    });
    searchIndexMock.mockResolvedValue([chunk("a", "Our SLA is 99.95%")]);
    // 2) draft
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: "Our SLA is 99.95% [Source 1]." } }],
    });
    // 3) critique: sufficient → END
    llmCreateMock.mockResolvedValueOnce({
      choices: [{ message: { content: '{"sufficient":true,"gaps":[]}' } }],
    });

    const events: ChatStep[] = [];
    const result = await runAgenticChatTurn({
      threadId: "thread-1",
      userMessage: "What is your SLA?",
      organizationId: "org-1",
      scope: "INDEX",
      scopedIndexId: "idx-1",
      onStep: (s) => events.push(s),
    });

    // Persistence: 2 chatMessage.create calls — first USER, then ASSISTANT.
    expect(prismaMock.chatMessage.create).toHaveBeenCalledTimes(2);
    const [userCall, assistantCall] = prismaMock.chatMessage.create.mock.calls.map(
      (c: unknown[]) => (c[0] as { data: { role: string; content: string; metadata?: unknown } }).data,
    );
    expect(userCall.role).toBe("USER");
    expect(userCall.content).toBe("What is your SLA?");
    expect(assistantCall.role).toBe("ASSISTANT");
    expect(assistantCall.content).toContain("99.95%");
    expect(assistantCall.metadata).toMatchObject({
      agent: { iterations: 1, sufficient: true },
    });
    // sources snapshot includes the chunk that fed the draft
    const meta = assistantCall.metadata as { sources?: Array<{ id: string }> };
    expect(meta.sources?.map((s) => s.id)).toEqual(["a"]);

    // Thread updatedAt bumped.
    expect(prismaMock.chatThread.update).toHaveBeenCalledTimes(1);

    // Return shape matches the chat route's contract.
    expect(result.content).toContain("99.95%");
    expect(result.metadata.agent).toEqual({ iterations: 1, sufficient: true });
    expect(result.assistantMessageId).toMatch(/^msg-assistant-/);

    // Event translation: every emitted step uses one of the existing
    // ChatStep variants so the UI's StepsTrace renders them with known
    // icons. Agent-specific steps map to thinking/tool_call/delta/tool_result.
    const stepKinds = new Set(events.map((e) => e.step));
    expect(stepKinds.has("thinking")).toBe(true);    // agent_plan
    expect(stepKinds.has("tool_call")).toBe(true);   // agent_search
    expect(stepKinds.has("delta")).toBe(true);       // agent_draft
    expect(stepKinds.has("tool_result")).toBe(true); // agent_critique
    expect(stepKinds.has("done")).toBe(true);        // agent_done + final done
    // No raw "agent_*" leaks through to the UI.
    expect(events.every((e) => !e.step.startsWith("agent_"))).toBe(true);
  });
});

describe("runAgenticChatTurn — graceful failure", () => {
  it("saves an error-shaped assistant message when the agent throws", async () => {
    // Plan throws — the agent never recovers.
    llmCreateMock.mockRejectedValue(new Error("upstream LLM 503"));

    const result = await runAgenticChatTurn({
      threadId: "thread-1",
      userMessage: "hello",
      organizationId: "org-1",
      scope: "INDEX",
      scopedIndexId: "idx-1",
    });

    expect(prismaMock.chatMessage.create).toHaveBeenCalledTimes(2);
    const [userCall, assistantCall] = prismaMock.chatMessage.create.mock.calls.map(
      (c: unknown[]) => (c[0] as { data: { content: string; metadata?: unknown } }).data,
    );
    expect(userCall.content).toBe("hello");
    expect(assistantCall.content).toMatch(/research agent failed/i);
    expect(assistantCall.content).toMatch(/upstream LLM 503/);
    // metadata.agent.error captures the message
    const meta = assistantCall.metadata as { agent?: { error?: string } };
    expect(meta.agent?.error).toMatch(/upstream LLM 503/);
    expect(result.assistantMessageId).toMatch(/^msg-assistant-/);
    // Thread updatedAt is NOT bumped on the failure path (assistant text
    // exists but the agent didn't complete normally) — we save the user
    // message + error reply only.
    expect(prismaMock.chatThread.update).not.toHaveBeenCalled();
  });
});
