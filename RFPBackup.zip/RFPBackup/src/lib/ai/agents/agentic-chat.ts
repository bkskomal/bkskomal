// Agentic chat wrapper (Phase C).
//
// Mirrors runChatTurn's persistence contract — saves the user message,
// runs the research agent, saves the assistant message — so the chat
// route's branch is a one-liner. AgentStep events are mapped to the
// existing ChatStep envelope so the UI's StepsTrace renders them
// without any UI-side changes.

import { prisma } from "@/lib/prisma";
import { log } from "@/lib/logger";
import { runResearchAgent, type AgentStep } from "./research-agent";
import type { ChatStep } from "../chat";
import type { ChatScope } from "@prisma/client";
import type { RetrievedChunk } from "../retrieval";

export interface AgenticChatTurnOpts {
  threadId: string;
  userMessage: string;
  organizationId: string;
  scope: ChatScope;
  /**
   * Index to scope retrieval against. Null for ORG/PROJECT/RFP scopes
   * without an attached index — the agent will fall back to general
   * knowledge or say it doesn't know.
   */
  scopedIndexId: string | null;
  /** Cap on the search→draft→critique→search loop. Default 3. */
  maxIterations?: number;
  onStep?: (step: ChatStep) => void;
}

export interface AgenticChatResult {
  assistantMessageId: string;
  content: string;
  metadata: {
    sources?: unknown[];
    /** Agent-mode-specific telemetry — visible to the chat-message viewer. */
    agent?: { iterations: number; sufficient: boolean };
  };
}

/**
 * Persistence-aware wrapper around `runResearchAgent`. Saves the user +
 * assistant messages exactly like `runChatTurn` does so the chat route can
 * branch on `enableAgentic` and call this without thinking about DB writes.
 */
export async function runAgenticChatTurn(
  opts: AgenticChatTurnOpts,
): Promise<AgenticChatResult> {
  const emit = (s: ChatStep) => opts.onStep?.(s);

  // 1) Persist user message immediately so reloads see it (matches chat.ts).
  await prisma.chatMessage.create({
    data: { threadId: opts.threadId, role: "USER", content: opts.userMessage },
  });

  // 2) Run the agent. Translate AgentStep → ChatStep so the UI sees them in
  // its existing stream (no UI plumbing changes required).
  let result: Awaited<ReturnType<typeof runResearchAgent>>;
  try {
    result = await runResearchAgent({
      question: opts.userMessage,
      organizationId: opts.organizationId,
      indexId: opts.scopedIndexId,
      scope: opts.scope,
      maxIterations: opts.maxIterations,
      onStep: (event) => emit(translateAgentStep(event)),
    });
  } catch (err) {
    // Save an error-shaped assistant message so the UI shows something instead
    // of leaving the user with a blank turn.
    const message = err instanceof Error ? err.message : String(err);
    log().error({ orgId: opts.organizationId, threadId: opts.threadId, err: message }, "agentic chat failed");
    const failText = `_The research agent failed: ${message.slice(0, 200)}._\n\nTry asking again, or turn off Agentic mode to use the standard chat path.`;
    const failMsg = await prisma.chatMessage.create({
      data: {
        threadId: opts.threadId,
        role: "ASSISTANT",
        content: failText,
        metadata: { agent: { iterations: 0, sufficient: false, error: message } } as never,
      },
    });
    emit({ step: "error", detail: "Agent failed" });
    return {
      assistantMessageId: failMsg.id,
      content: failText,
      metadata: { agent: { iterations: 0, sufficient: false } },
    };
  }

  const content = result.content || "_The agent did not produce a response._";

  // 3) Persist the assistant message + bump thread timestamp.
  const assistantMsg = await prisma.chatMessage.create({
    data: {
      threadId: opts.threadId,
      role: "ASSISTANT",
      content,
      metadata: {
        sources: result.sources.map((s: RetrievedChunk) => ({
          id: s.id,
          documentId: s.documentId,
          documentName: s.documentName,
          fileName: s.fileName,
          page: s.page,
          score: s.score,
        })),
        agent: { iterations: result.iterations, sufficient: result.sufficient },
      } as never,
    },
  });

  await prisma.chatThread.update({
    where: { id: opts.threadId },
    data: { updatedAt: new Date() },
  });

  emit({ step: "done", detail: "Response ready" });

  return {
    assistantMessageId: assistantMsg.id,
    content,
    metadata: {
      sources: result.sources,
      agent: { iterations: result.iterations, sufficient: result.sufficient },
    },
  };
}

/** Map our agent-specific step enum onto the chat UI's ChatStep envelope. */
function translateAgentStep(event: AgentStep): ChatStep {
  // The UI's StepsTrace renders any unknown `step` value as a generic line,
  // so we can pass the AgentStep through almost verbatim. We just narrow the
  // `step` field to one of the existing ChatStep variants where possible so
  // existing icons (thinking/tool_call/tool_result) light up.
  switch (event.step) {
    case "agent_plan":
      return { step: "thinking", detail: event.detail, data: event.data };
    case "agent_search":
      return { step: "tool_call", detail: event.detail, data: event.data };
    case "agent_draft":
      return { step: "delta", detail: event.detail, data: event.data };
    case "agent_critique":
      return { step: "tool_result", detail: event.detail, data: event.data };
    case "agent_done":
      return { step: "done", detail: event.detail, data: event.data };
    case "agent_error":
      return { step: "error", detail: event.detail, data: event.data };
  }
}
