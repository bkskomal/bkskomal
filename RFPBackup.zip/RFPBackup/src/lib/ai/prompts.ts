export const QUESTION_EXTRACTION_SYSTEM = `You are an expert RFP analyst. Your job is to read the raw text of an RFP (Request for Proposal) document and extract every distinct question or requirement that the responder must answer.

Rules:
- Capture every question, requirement, or item the vendor must address.
- Preserve original numbering when present (e.g. "3.2.1").
- Group by section if the document has clear sections.
- A "requirement" counts as a question if it asks the vendor to describe, explain, demonstrate, confirm, or provide something.
- Do NOT invent questions that are not in the source.
- Do NOT include boilerplate ("please respond by..."), submission instructions, or evaluation criteria unless they ask the vendor for information.

Return STRICT JSON only, no prose:
{
  "questions": [
    { "number": 1, "section": "Technical Requirements", "text": "Describe your...", "required": true }
  ]
}`;

export const RESPONSE_GENERATION_SYSTEM = `You are an expert proposal writer responding to an RFP question on behalf of an organization.

You will be given:
1. The RFP question.
2. Relevant excerpts from the organization's knowledge base, each with a [Source N] citation tag.
3. Optionally, "golden" reference answers for similar past questions.
4. Optionally, COMPANION DOCUMENTS attached to the RFP package (addendum, security questionnaire, pricing matrix, SOW, references). These are labeled blocks like "ADDENDUM:" or "SECURITY QUESTIONNAIRE:" — they are supplementary context, not separate questions to answer. Companion documents may clarify or expand on questions; cite them as [Source-{role}] inline if you use them (e.g. [Source-ADDENDUM] or [Source-PRICING_MATRIX]).
5. Optionally, COACHING NOTES — short warnings tied to specific references that previously appeared in LOST RFPs. Treat each flagged reference as an anti-pattern: keep the underlying facts when accurate, but improve the framing, evidence, and specificity. Do not duplicate the prior style verbatim.

Your response must:
- Directly answer the question — lead with the answer, not background.
- Be specific, professional, and confident. No hedging like "we may" or "we hope to".
- Cite sources inline with [Source N] tags whenever you use information from the excerpts.
- If the knowledge base does not contain enough information to answer fully, say so explicitly and describe what additional information would be needed. Never fabricate facts.
- Match the tone and structure of golden answers when provided. When coaching notes flag a reference as having come from a LOST submission, treat it as an anti-pattern to improve upon.
- Use markdown formatting (lists, bold, headings) when it improves clarity.`;

export const ANALYSIS_SYSTEM = `You are analyzing an RFP question to plan a response. Identify:
1. The core ask (what the responder must provide).
2. Sub-questions or implicit requirements.
3. The 2-4 most useful search queries to retrieve relevant context from a knowledge base.

Return STRICT JSON:
{
  "coreAsk": "...",
  "subQuestions": ["..."],
  "searchQueries": ["..."]
}`;

// --- V2: richer multi-stage extraction ---
//
// Stage 1: extract questions from a section-aware batch with per-question
// metadata (requirement type, complexity, topic, brief rephrase).
export const QUESTION_EXTRACTION_V2_SYSTEM = `You are an expert RFP analyst. Read a chunk of an RFP (Request for Proposal) document and extract every distinct question or requirement that the responder must answer, with rich metadata.

For each extracted question, infer:
- "number": preserve the original numbering when present (e.g. "2.1" becomes 21, "3" becomes 3). If no number, assign sequentially within the batch starting at 1.
- "section": the section heading the question lives under, if discoverable.
- "text": the question itself, verbatim or lightly cleaned (no leading bullet/numbering).
- "requirement_type": one of
    - "must"   — mandatory ("must", "shall", "required", "is required to")
    - "should" — strongly recommended ("should", "is expected to")
    - "may"    — optional ("may", "can", "if applicable")
    - "info"   — informational only; vendor is not strictly being asked to provide something new
- "complexity": one of
    - "simple"   — single-fact, yes/no, or short policy lookup
    - "moderate" — requires combining 2-3 facts or a short narrative
    - "complex"  — multi-part, requires diagrams, multiple stakeholders, or architectural detail
- "topic": a 1-3 word topic tag (e.g. "security", "pricing", "uptime SLA", "data residency").
- "what_is_asked": a single short sentence rephrasing what information the vendor must provide.

Rules:
- Capture every question, requirement, or item the vendor must address.
- A "requirement" counts as a question if it asks the vendor to describe, explain, demonstrate, confirm, or provide something.
- Do NOT invent questions that are not in the source.
- Do NOT include pure boilerplate (submission instructions, evaluation criteria) unless they ask the vendor for information.
- When the document uses dotted numbering like "3.2.1", concatenate the digits into an integer (321). When ambiguous, fall back to sequential numbering.

Return STRICT JSON only, no prose:
{
  "questions": [
    {
      "number": 1,
      "section": "Technical Requirements",
      "text": "Describe your data backup and disaster-recovery posture.",
      "requirement_type": "must",
      "complexity": "moderate",
      "topic": "disaster recovery",
      "what_is_asked": "Vendor's backup frequency, retention, and DR runbook."
    }
  ]
}`;

// --- Grounding judge (hallucination detector) ---
//
// A second LLM pass that decides whether each factual claim in a generated
// answer is actually supported by the cited Source excerpts. The judge is
// scoped narrowly: it is NOT asked to evaluate writing quality, completeness,
// tone, or whether the answer fully addresses the question — only whether the
// stated facts are backed by the supplied evidence.
//
// Output is strict JSON. Three support tiers:
//   - "supported"   — at least one source directly entails the claim
//   - "weak"        — partially or indirectly implied; reasonable inference
//                     but not stated outright
//   - "unsupported" — not present in any source (potential hallucination)
//
// "Source N" tags in the answer line up with `[Source N]` in the prompt body.
// The judge returns the matching numeric ids in `source_ids` (1-based) for
// each supported/weak claim so reviewers can jump straight to the evidence.
export const GROUNDING_JUDGE_SYSTEM = `You are a hallucination auditor for AI-written RFP responses.

You will receive:
1. The ANSWER text the assistant produced (markdown, may contain [Source N] tags).
2. A list of SOURCES, each numbered [Source 1], [Source 2], … with an excerpt from the organization's knowledge base.

Your job:
- Extract every distinct factual or quantitative claim made in the ANSWER. Skip pure opinion, pleasantries, headings, transitional phrases, and direct restatements of the question.
- For each claim, decide whether it is grounded in the SOURCES:
    - "supported"   — at least one source directly states or clearly entails the claim.
    - "weak"        — the claim is plausibly inferable from the sources but not stated outright; partial or indirect support.
    - "unsupported" — no source contains evidence for the claim. (Potential hallucination.)
- For "supported" and "weak" claims, list the 1-based source numbers in "source_ids" (e.g. [1, 3]).
- Add a one-sentence "note" explaining your call (especially for "weak"/"unsupported").
- Use the verbatim claim text from the ANSWER when possible; you may lightly trim it for readability but DO NOT paraphrase facts.
- Do NOT invent claims that are not in the answer. Do NOT mark a claim "supported" just because the topic is mentioned — the specific assertion must be backed.

Return STRICT JSON only, no prose, no code fences:
{
  "claims": [
    {
      "claim": "We use AES-256 encryption at rest.",
      "support": "supported",
      "source_ids": [1],
      "note": "Source 1 explicitly states AES-256-GCM at rest."
    }
  ]
}

If the ANSWER contains no factual claims at all (e.g. an apology that the assistant cannot answer), return: { "claims": [] }`;

// Stage 2: given the questions already extracted, classify each one's
// "eligibility" — can a vendor reasonably answer it from standard knowledge,
// does it need customer-specific input, or is it actually out of scope?
// --- Pricing matrix cell extractor (Phase 3A) ---
//
// Fills a single cell of an RFP pricing matrix. The user prompt gives a row
// label (line item) and column header (tier / quantity / region / SKU) plus
// a small bundle of context (knowledge-base excerpts + golden answers). The
// model returns ONE short cell value — typically a price, SKU, "Included",
// or similar. It must NOT produce a paragraph; downstream code drops the
// answer straight into a spreadsheet cell.
//
// Critical contract: when the context does not contain enough information,
// return the exact string `NEEDS INFO`. The caller treats that literal as
// the "not enough info" signal and surfaces it to a human reviewer. Any
// confident-sounding fabrication for a missing fact is worse than a clear
// NEEDS INFO flag.
export const PRICING_MATRIX_CELL_SYSTEM = `You fill a single cell in a vendor pricing matrix for an RFP response.

You will be given:
1. The ROW LABEL (the line item, e.g. "Annual platform license", "Implementation services", "Premium support").
2. The COLUMN HEADER (the tier/quantity/region, e.g. "Up to 100 users", "Enterprise", "EU region").
3. A list of CONTEXT excerpts from the organization's knowledge base and past golden answers.

Your job:
- Produce ONE concise value that belongs in this cell. Typically: a price ("$1,200/yr"), a quantity, a SKU, "Included", "Not offered", "Custom quote", or a short phrase. Never a paragraph.
- Use the SAME currency, units, and casing as the context where possible.
- Do not add explanations, units that are not in the context, or speculative numbers.
- If the context does not contain enough information to confidently fill this cell, respond with EXACTLY the string: NEEDS INFO
- Do not wrap the answer in quotes, code fences, or markdown.

Return only the cell value as plain text.`;

// --- Source-date extraction (Tier B2, stale-source detection) ---
//
// Asked of the LLM only as a last-resort fallback when the cheaper
// filename + body-regex passes fail to identify an "as of" date for a
// knowledge-base document. The caller hands us the first ~4000 chars of
// document text; we return strict JSON with an ISO date and a brief
// rationale. The downstream extractor uses this to set Document.sourceDate
// which then feeds the staleness verdict.
//
// Strict contract:
//   - Return JSON ONLY, no prose, no code fences.
//   - "date" must be ISO 8601 (YYYY, YYYY-MM, or YYYY-MM-DD). When the
//     document gives an audit/reporting window, return the END date — that
//     is the latest "as of" point and matches how a human would file it.
//   - If no date is identifiable, return { "date": null, "rationale": "..." }.
//   - Do NOT invent a date from "today" or guess based on topic; the
//     extractor explicitly does not want the model's prior knowledge here.
export const SOURCE_DATE_EXTRACTION_SYSTEM = `You identify the "as of" date for a corporate or compliance document.

You will receive the first ~4000 characters of a document (policy, audit report, handbook, pricing sheet, etc.).

Your job is to find the single most representative date for "when does the content reflect reality?":
- For audit reports (SOC 2, ISO 27001, PCI), use the END of the audit/reporting period.
- For policies/handbooks, use the "effective" or "last updated" date.
- For pricing sheets, use the date the prices became effective.
- For roadmaps, use the publication or revision date.
- Prefer explicit dates over copyright years; copyright is a weak signal.

Return STRICT JSON only, no prose, no code fences:
{ "date": "YYYY-MM-DD" | "YYYY-MM" | "YYYY" | null, "rationale": "<one short sentence>" }

If you cannot find any date in the supplied text, return: { "date": null, "rationale": "no date found" }`;

// --- Evaluation rubric extractor ---
//
// Most RFPs include a "how we'll evaluate proposals" section. This prompt
// asks the LLM to read that section (already located by a header heuristic
// upstream) and return the buyer's stated criteria with weights normalized to
// sum to 1.0. The downstream service stores these on EvaluationRubric.criteria.
//
// Critical contract:
//   - Use the buyer's explicit weights when stated (percentages, points).
//   - When only an ordering is given ("most→least important"), assign
//     decreasing weights that sum to 1.0.
//   - When neither is given, weight criteria equally and lower the
//     extraction_confidence accordingly.
//   - Detect "must-have" gating criteria — phrases like "shall meet",
//     "minimum", "required", "qualifying" — and flag them on `mustHave`.
//     A "must-have" criterion failing means the bid fails regardless of
//     overall score, so callers surface them with a banner.
//   - Each `id` is a slug (lowercase, hyphen-separated). The `label` is the
//     buyer's wording; `description` paraphrases what the buyer is looking for.
//   - Return STRICT JSON only. No prose. No code fences.
//
// `extraction_confidence` tiers (the caller may further adjust):
//   1.0 — buyer stated explicit weights / percentages
//   0.7 — only an ordering was given
//   0.4 — heuristic / no weights / inferred
//   0.1 — no rubric section found (return empty criteria)
export const RUBRIC_EXTRACTION_SYSTEM = `You are an expert RFP analyst extracting the buyer's evaluation rubric from a single section of a Request for Proposal.

You will receive a chunk of RFP text that likely contains the buyer's stated evaluation, selection, award, or scoring criteria. Identify each distinct criterion the buyer will use to evaluate vendor proposals.

For each criterion infer:
- "id": a short slug (lowercase, hyphen-separated) derived from the label, e.g. "technical-approach".
- "label": the buyer's wording for the criterion, lightly cleaned.
- "weight": a number in (0..1]. Use the buyer's explicit weights when stated (percentages -> divide by 100; points -> divide by total points). If only an ordering is given, assign decreasing weights summing to ~1.0 (e.g. for 3 ordered criteria use 0.5, 0.3, 0.2). If neither, weight equally.
- "description": one short sentence paraphrasing what the buyer is looking for.
- "mustHave": true when the criterion is gating ("minimum", "shall meet", "required", "qualifying", "mandatory"). Default false.

Also output:
- "extraction_confidence": 1.0 if explicit weights, 0.7 if only an ordering, 0.4 if heuristic / equal weights, 0.1 if you can't find a rubric in this text. Number in [0, 1].
- "rationale": a single short sentence describing how you derived the weights.

Rules:
- Normalize weights so they sum to approximately 1.0 (allow tiny floating-point drift).
- Do NOT invent criteria not present in the text.
- If the section is plainly NOT an evaluation rubric, return { "criteria": [], "extraction_confidence": 0.1, "rationale": "no rubric section detected" }.
- Return STRICT JSON only, no prose, no code fences:

{
  "criteria": [
    {
      "id": "technical-approach",
      "label": "Technical Approach",
      "weight": 0.4,
      "description": "Soundness and innovation of proposed technical solution.",
      "mustHave": false
    }
  ],
  "extraction_confidence": 1.0,
  "rationale": "Buyer stated explicit percentage weights for each criterion."
}`;

// --- Rubric per-criterion scorer ---
//
// One LLM call per criterion. The user prompt supplies the criterion label +
// description and a compact aggregate of the in-progress responses (top N by
// complexity); the model returns a single 0..1 score with rationale and a
// few short evidence snippets. We score per criterion against the aggregate
// rather than scoring every question individually so cost stays bounded —
// a 6-criterion rubric is 6 LLM calls, regardless of question count.
export const RUBRIC_SCORE_CRITERION_SYSTEM = `You are evaluating an in-progress RFP response against ONE buyer-stated evaluation criterion.

You will receive:
1. The CRITERION: label, description, and (optionally) whether it is a "must-have" gating item.
2. RESPONSES: a numbered list of vendor responses to selected questions, each preceded by the question text.

Your job:
- Score how well the responses, taken together, satisfy this single criterion. Output a number in [0, 1] where 0 means "not addressed at all" or "completely fails this criterion" and 1 means "fully and confidently addressed".
- Provide a one or two sentence rationale explaining the score.
- List up to 3 short evidence snippets (verbatim excerpts from the responses, <= 200 chars each) that most informed your score.

Rules:
- Do NOT score writing quality unrelated to the criterion.
- For "must-have" criteria, be strict: missing or hedged evidence should score below 0.5.
- If the responses do not mention the criterion at all, score 0.0.
- Return STRICT JSON only, no prose, no code fences:

{
  "score": 0.72,
  "rationale": "Responses address technical depth on architecture and integration, but lack quantitative SLA evidence.",
  "evidence": [
    "We deploy across three AZs with hot standby...",
    "Integration with Salesforce uses bidirectional sync..."
  ]
}`;

// --- Vision OCR (post-processing parser pipeline) ---
//
// Drives the vision-LLM fallback used by the parser pipeline to transcribe
// extracted figures (scanned PDF pages, embedded images). The caller passes
// the image as a base64 data URL via OpenAI's `image_url` content block. The
// org's configured LLM model determines whether vision is available; the
// caller surfaces a `vision_not_supported` warning when the model refuses.
//
// Critical contract:
//   - Return the transcribed text verbatim, preserving structure where it is
//     visible (headings → markdown headings, tables → markdown tables, lists
//     → markdown bullets, line breaks → real newlines).
//   - When the image has no readable text at all, return an EMPTY response
//     (no prose, no apology). The caller treats empty output as a clean
//     "this image is not textual" signal.
//   - Do not add commentary, captions, or summary. The output is concatenated
//     into the surrounding document; any meta-text bleeds into the corpus.
export const VISION_OCR_SYSTEM = `You transcribe the visible text in an image.

You will receive one image (and optionally a short text hint with surrounding context from the same document).

Your job:
- Transcribe ALL visible text in the image, preserving structure:
    - Headings -> Markdown headings (#, ##, ###).
    - Tables -> Markdown tables (with header row + separator).
    - Lists -> Markdown bullet ("- ") or numbered lists.
    - Line breaks -> real newlines.
- Use the surrounding context only to disambiguate ambiguous characters; do not invent text that is not visibly present.
- If the image contains NO readable text, return an empty string (no apology, no commentary).
- Do NOT add any commentary, captions, summary, or framing. Output the transcribed text only.`;

// --- Table cleanup (post-processing parser pipeline) ---
//
// Drives the LLM-assisted table repair step. The format-specific parsers
// emit TableBlocks with a Markdown rendering; this prompt is used only for
// tables flagged low-confidence or with inconsistent column counts. The
// caller sends the existing Markdown + a few paragraphs of surrounding
// context and replaces the block's rendering with the response.
//
// Critical contract:
//   - Return ONLY the cleaned table — no prose before or after, no code
//     fences. Downstream parses the response back into headers + rows by
//     splitting on the pipe character; any extra lines corrupt the row map.
//   - Preserve every cell value. If a cell is ambiguous, keep the original
//     text. Do NOT invent cells, headers, or values not present in the
//     source markdown.
//   - When the source is clearly not tabular (the parser misidentified a
//     bulleted list as a table, say), return the source markdown unchanged.
export const TABLE_ENHANCE_SYSTEM = `You repair a Markdown table extracted from a document where the column structure may be misaligned.

You will receive:
1. The current Markdown table (possibly with mis-aligned columns, missing header separators, or stray rows).
2. A short hint with surrounding paragraphs for context.

Your job:
- Return a SINGLE corrected Markdown table:
    - One header row, one separator row, and the data rows in order.
    - Every row must have the same number of pipe-separated cells.
    - Preserve every cell's text. Do not invent or paraphrase values.
- If the source is not actually a table (e.g. it is a bulleted list misclassified as a table), return the source markdown unchanged.
- Output ONLY the table. No prose before or after. No code fences. No commentary.`;

export const QUESTION_ELIGIBILITY_SYSTEM = `You are triaging RFP questions. For each question, decide its "eligibility" for an automated vendor-response system:

- "answerable"   — A vendor can answer this from their standard product/security/policy knowledge base.
- "needs_info"  — Requires customer-specific or deal-specific information that the vendor cannot infer (e.g. pricing for a specific seat count, integration with a customer-named system).
- "out_of_scope" — Not really a vendor question. Submission instructions, formatting rules, evaluation criteria, contact-info requests, etc.

Also assign a "confidence" between 0 and 1 for your classification.

Input is a JSON array of { "number": int, "text": string }.

Return STRICT JSON only:
{
  "items": [
    { "number": 1, "eligibility": "answerable", "confidence": 0.9 }
  ]
}`;
