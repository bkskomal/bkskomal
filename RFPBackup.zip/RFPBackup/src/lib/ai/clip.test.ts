// CLIP embedder tests.
//
// We mock @huggingface/transformers so the test never has to download the
// real ~85 MB model. The mock returns canned 512-d Float32Arrays so we can
// assert the embedder's wiring (L2 normalization, lazy load, dimension
// guard) without touching the network or onnxruntime.

import { describe, expect, it, vi, beforeEach } from "vitest";

// Mock state — we keep counters here so the lazy-load test can prove the
// pipeline factory is only invoked once across multiple embed calls.
let pipelineCallCount = 0;
let tokenizerCallCount = 0;
let textModelCallCount = 0;

// Top-level imports of the module under test. The mock below replaces
// @huggingface/transformers via vi.mock hoisting.
import {
  getClipEmbedder,
  CLIP_MODEL,
  CLIP_DIMENSIONS,
  __resetClipForTests,
} from "./clip";

vi.mock("@huggingface/transformers", () => {
  return {
    env: { cacheDir: "", allowLocalModels: true },
    pipeline: vi.fn(async (_task: string, _model: string) => {
      pipelineCallCount++;
      // The image-feature-extraction pipeline returns a Tensor-like:
      //   { data: Float32Array(512), dims: [1, 512] }
      // We return a constant non-normalized vector so the test can verify
      // the embedder L2-normalizes its output.
      return async (_image: unknown) => {
        const data = new Float32Array(512);
        for (let i = 0; i < 512; i++) data[i] = i + 1; // 1..512
        return { data, dims: [1, 512] };
      };
    }),
    AutoTokenizer: {
      from_pretrained: vi.fn(async (_model: string) => {
        tokenizerCallCount++;
        return (texts: string[]) => ({ input_ids: texts });
      }),
    },
    CLIPTextModelWithProjection: {
      from_pretrained: vi.fn(async (_model: string) => {
        textModelCallCount++;
        return async (_inputs: Record<string, unknown>) => {
          // text_embeds shape [1, 512]; varied values so the L2 norm isn't
          // trivially 1 before normalization.
          const data = new Float32Array(512);
          for (let i = 0; i < 512; i++) data[i] = (i % 7) + 0.5;
          return { text_embeds: { data, dims: [1, 512] } };
        };
      }),
    },
    RawImage: {
      fromBlob: vi.fn(async (_blob: Blob) => ({
        data: new Uint8ClampedArray([0, 0, 0, 255]),
        width: 1,
        height: 1,
        channels: 4,
      })),
    },
  };
});

// Reset call counters between tests; the singleton inside clip.ts is reset
// per-test via __resetClipForTests() in each `it` block.
beforeEach(() => {
  pipelineCallCount = 0;
  tokenizerCallCount = 0;
  textModelCallCount = 0;
});

const ONE_PIXEL_PNG = Buffer.from(
  // 1x1 transparent PNG (smallest valid encoding).
  "89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000A49444154789C6300010000000500010D0A2DB40000000049454E44AE426082",
  "hex",
);

function isUnitNorm(v: number[]): boolean {
  let s = 0;
  for (const x of v) s += x * x;
  return Math.abs(Math.sqrt(s) - 1) < 1e-5;
}

describe("clip embedder", () => {
  it("embedImage returns a 512-d L2-normalized vector for a 1-pixel PNG", async () => {
    __resetClipForTests();
    const embedder = getClipEmbedder();
    const v = await embedder.embedImage(ONE_PIXEL_PNG);
    expect(v).toHaveLength(CLIP_DIMENSIONS);
    expect(isUnitNorm(v)).toBe(true);
    // Vector should NOT be the raw 1..512 — normalization must have run.
    expect(v[0]).not.toBe(1);
  });

  it("embedTextForImageSearch returns a 512-d L2-normalized vector", async () => {
    __resetClipForTests();
    const embedder = getClipEmbedder();
    const v = await embedder.embedTextForImageSearch("an architecture diagram");
    expect(v).toHaveLength(CLIP_DIMENSIONS);
    expect(isUnitNorm(v)).toBe(true);
  });

  it("returns a zero vector for empty text input (no crash)", async () => {
    __resetClipForTests();
    const embedder = getClipEmbedder();
    const v = await embedder.embedTextForImageSearch("");
    expect(v).toHaveLength(CLIP_DIMENSIONS);
    expect(v.every((x) => x === 0)).toBe(true);
  });

  it("lazy-loads the image pipeline only once across multiple calls", async () => {
    __resetClipForTests();
    const embedder = getClipEmbedder();
    expect(embedder.ready).toBe(false);
    await embedder.embedImage(ONE_PIXEL_PNG);
    expect(embedder.ready).toBe(true);
    await embedder.embedImage(ONE_PIXEL_PNG);
    await embedder.embedImage(ONE_PIXEL_PNG);
    // Pipeline factory should only have been called once despite 3 embeds.
    expect(pipelineCallCount).toBe(1);
  });

  it("lazy-loads the text encoder only once across multiple calls", async () => {
    __resetClipForTests();
    const embedder = getClipEmbedder();
    await embedder.embedTextForImageSearch("first");
    await embedder.embedTextForImageSearch("second");
    expect(tokenizerCallCount).toBe(1);
    expect(textModelCallCount).toBe(1);
  });

  it("rejects empty image buffer", async () => {
    __resetClipForTests();
    const embedder = getClipEmbedder();
    await expect(embedder.embedImage(Buffer.alloc(0))).rejects.toThrow(/empty/);
  });

  it("exposes the configured model name and dimensions", async () => {
    __resetClipForTests();
    const embedder = getClipEmbedder();
    expect(embedder.model).toBe(CLIP_MODEL);
    expect(embedder.dimensions).toBe(CLIP_DIMENSIONS);
  });
});
