// External RAG adapter — unit tests (Phase D).
//
// Mocks `fetch` so the test never hits a real endpoint. Coverage:
//   - Request shape: POST, JSON body with {query, topK, indexId, orgId}
//   - Authorization header sent only when apiKey is set
//   - Extra headers merged
//   - Response normalized: missing id → falls back to ext-<i>, missing
//     score → defaults to 0.5, chunks without content dropped
//   - Non-2xx throws with the upstream body excerpt
//   - Abort signal cancels the request
//   - pingExternalRag wraps fetchExternalRag with ok/message shape

import { describe, expect, it, beforeEach, afterEach, vi } from "vitest";

import { fetchExternalRag, pingExternalRag } from "./external-rag";

const ORIG_FETCH = globalThis.fetch;

beforeEach(() => {
  vi.useRealTimers();
});

afterEach(() => {
  globalThis.fetch = ORIG_FETCH;
});

describe("fetchExternalRag — request shape", () => {
  it("POSTs JSON body and adds Bearer auth when apiKey is set", async () => {
    let captured: { url: string; init: RequestInit | undefined } | null = null;
    globalThis.fetch = (async (url: string, init?: RequestInit) => {
      captured = { url, init };
      return new Response(
        JSON.stringify({ chunks: [{ id: "x", content: "hello world" }] }),
        { status: 200, headers: { "content-type": "application/json" } },
      );
    }) as typeof fetch;

    const chunks = await fetchExternalRag({
      query: "what is your SLA?",
      topK: 5,
      indexId: "idx-1",
      orgId: "org-1",
      endpoint: "https://rag.example.com/v1/query",
      apiKey: "tok-123",
      extraHeaders: { "x-customer-id": "abc" },
    });

    expect(chunks).toHaveLength(1);
    expect(chunks[0].content).toBe("hello world");

    expect(captured).not.toBeNull();
    expect(captured!.url).toBe("https://rag.example.com/v1/query");
    expect(captured!.init?.method).toBe("POST");
    const headers = captured!.init?.headers as Record<string, string>;
    expect(headers["Content-Type"]).toBe("application/json");
    expect(headers["Authorization"]).toBe("Bearer tok-123");
    expect(headers["x-customer-id"]).toBe("abc");
    const body = JSON.parse(captured!.init?.body as string);
    expect(body).toEqual({ query: "what is your SLA?", topK: 5, indexId: "idx-1", orgId: "org-1" });
  });

  it("omits Authorization header when apiKey is null", async () => {
    let capturedHeaders: Record<string, string> = {};
    globalThis.fetch = (async (_url: string, init?: RequestInit) => {
      capturedHeaders = init?.headers as Record<string, string>;
      return new Response(JSON.stringify({ chunks: [] }), { status: 200 });
    }) as typeof fetch;

    await fetchExternalRag({
      query: "q",
      topK: 1,
      indexId: null,
      orgId: "org-1",
      endpoint: "https://rag.local",
      apiKey: null,
      extraHeaders: {},
    });
    expect(capturedHeaders["Authorization"]).toBeUndefined();
  });
});

describe("fetchExternalRag — response normalization", () => {
  function mockChunks(chunks: unknown[]) {
    globalThis.fetch = (async () =>
      new Response(JSON.stringify({ chunks }), { status: 200 })) as typeof fetch;
  }

  const baseInput = {
    query: "q",
    topK: 5,
    indexId: null,
    orgId: "org-1",
    endpoint: "https://rag.local",
    apiKey: null,
    extraHeaders: {},
  };

  it("defaults missing id, score, and documentName", async () => {
    mockChunks([{ content: "first chunk" }, { content: "second chunk" }]);
    const out = await fetchExternalRag(baseInput);
    expect(out).toHaveLength(2);
    expect(out[0].id).toBe("ext-0");
    expect(out[1].id).toBe("ext-1");
    expect(out[0].score).toBe(0.5);
    expect(out[0].documentName).toBe("External source");
  });

  it("drops chunks with no content (useless to the generator)", async () => {
    mockChunks([
      { id: "a", content: "keep" },
      { id: "b" }, // no content
      { id: "c", content: 42 }, // wrong type
      { id: "d", content: "" }, // empty string
      { id: "e", content: "also keep" },
    ]);
    const out = await fetchExternalRag(baseInput);
    expect(out.map((c) => c.id)).toEqual(["a", "e"]);
  });

  it("returns empty when chunks field is missing or wrong type", async () => {
    globalThis.fetch = (async () =>
      new Response(JSON.stringify({ other: "stuff" }), { status: 200 })) as typeof fetch;
    const out = await fetchExternalRag(baseInput);
    expect(out).toEqual([]);
  });

  it("preserves passed-through fields (documentName, fileName, page, score)", async () => {
    mockChunks([
      {
        id: "src-7",
        content: "soc 2 report excerpt",
        documentId: "doc-soc2",
        documentName: "SOC 2 Report 2025",
        fileName: "soc2-2025.pdf",
        page: 42,
        score: 0.91,
      },
    ]);
    const [c] = await fetchExternalRag(baseInput);
    expect(c).toMatchObject({
      id: "src-7",
      documentId: "doc-soc2",
      documentName: "SOC 2 Report 2025",
      fileName: "soc2-2025.pdf",
      page: 42,
      score: 0.91,
    });
  });
});

describe("fetchExternalRag — error path", () => {
  it("throws with upstream status + body excerpt on non-2xx", async () => {
    globalThis.fetch = (async () =>
      new Response("rate limited; retry in 60s", { status: 429 })) as typeof fetch;

    await expect(
      fetchExternalRag({
        query: "q",
        topK: 1,
        indexId: null,
        orgId: "org-1",
        endpoint: "https://rag.local",
        apiKey: null,
        extraHeaders: {},
      }),
    ).rejects.toThrow(/external RAG HTTP 429.*rate limited/);
  });

  it("respects caller AbortSignal", async () => {
    const ctrl = new AbortController();
    globalThis.fetch = (async (_url: string, init?: RequestInit) => {
      return new Promise<Response>((_, reject) => {
        init?.signal?.addEventListener("abort", () =>
          reject(Object.assign(new Error("AbortError"), { name: "AbortError" })),
        );
      });
    }) as typeof fetch;
    setTimeout(() => ctrl.abort(), 5);
    await expect(
      fetchExternalRag({
        query: "q",
        topK: 1,
        indexId: null,
        orgId: "org-1",
        endpoint: "https://rag.local",
        apiKey: null,
        extraHeaders: {},
        signal: ctrl.signal,
      }),
    ).rejects.toThrow(/abort/i);
  });
});

describe("pingExternalRag", () => {
  it("returns ok=true with chunk count on success", async () => {
    globalThis.fetch = (async () =>
      new Response(JSON.stringify({ chunks: [{ id: "x", content: "y" }] }), {
        status: 200,
      })) as typeof fetch;
    const r = await pingExternalRag({
      query: "ping",
      topK: 1,
      indexId: null,
      orgId: "org-1",
      endpoint: "https://rag.local",
      apiKey: null,
      extraHeaders: {},
    });
    expect(r.ok).toBe(true);
    expect(r.sampleCount).toBe(1);
  });

  it("returns ok=false with the upstream error message on failure", async () => {
    globalThis.fetch = (async () =>
      new Response("unauthorized", { status: 401 })) as typeof fetch;
    const r = await pingExternalRag({
      query: "ping",
      topK: 1,
      indexId: null,
      orgId: "org-1",
      endpoint: "https://rag.local",
      apiKey: null,
      extraHeaders: {},
    });
    expect(r.ok).toBe(false);
    expect(r.message).toMatch(/HTTP 401/);
  });
});
