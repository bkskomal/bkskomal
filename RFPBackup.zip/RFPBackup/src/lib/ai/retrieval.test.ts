// Retrieval — multimodal mode (Phase IM).
//
// We focus on the new image branches added in IM2:
//   - imageMode "off"  → no image hits, text behaviour unchanged
//   - imageMode "fuse" → image + text hits, image rows tagged kind="image"
//   - imageMode "only" → text hits dropped from final result
//   - CLIP failure     → text hits still returned, warning logged
//
// The existing text retrieval is exercised end-to-end through the Postgres
// store mock so we don't have to re-test its internals here.

import { describe, expect, it, beforeEach, vi } from "vitest";

const { prismaMock, embedMock, clipMock, storeMock } = vi.hoisted(() => ({
  prismaMock: {
    knowledgeIndex: { findUnique: vi.fn() },
    documentChunk: { findMany: vi.fn() },
    // Phase A: retrieval.ts now reads per-org retrieval config via
    // resolveAiConfig(). Null → defaults baked in by the resolver, which
    // preserves the original test behavior (HYBRID + LLM rerank + topK 8).
    orgAiConfig: { findUnique: vi.fn().mockResolvedValue(null) },
  },
  embedMock: vi.fn(),
  clipMock: { embedTextForImageSearch: vi.fn() },
  storeMock: {
    id: "postgres" as const,
    version: "pg-1",
    supportsHybrid: false,
    supportsImages: true,
    initOrg: vi.fn(),
    upsert: vi.fn(),
    search: vi.fn(),
    delete: vi.fn(),
    deleteIndex: vi.fn(),
    health: vi.fn(),
    upsertImages: vi.fn(),
    searchImages: vi.fn(),
    deleteImages: vi.fn(),
    deleteImagesForIndex: vi.fn(),
  },
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("./embeddings", () => ({ embed: embedMock }));
vi.mock("./sparse", () => ({ encodeSparse: vi.fn() }));
vi.mock("./client", () => ({ getAiClients: vi.fn() }));
vi.mock("./clip", () => ({
  getClipEmbedder: () => clipMock,
}));
vi.mock("./vector", async () => {
  // Pull the real `supportsImages` helper through; only stub the resolver.
  const actual = await vi.importActual<typeof import("./vector")>("./vector");
  return {
    ...actual,
    vectorStoreResolver: {
      forOrg: vi.fn(async () => storeMock),
      writersForOrg: vi.fn(async () => [storeMock]),
    },
  };
});

import { searchIndex } from "./retrieval";

const ORG_A = "org-a";
const INDEX_A = "idx-a";

beforeEach(() => {
  vi.clearAllMocks();
  prismaMock.knowledgeIndex.findUnique.mockResolvedValue({ organizationId: ORG_A });
  embedMock.mockResolvedValue([1, 0, 0]);
  clipMock.embedTextForImageSearch.mockResolvedValue([1, 0, 0]);
  storeMock.search.mockResolvedValue([
    { id: "c1", score: 0.9, source: "dense" },
    { id: "c2", score: 0.7, source: "dense" },
  ]);
  storeMock.searchImages.mockResolvedValue([]);
  prismaMock.documentChunk.findMany.mockResolvedValue([
    {
      id: "c1",
      documentId: "d1",
      ordinal: 0,
      page: 1,
      content: "encryption at rest is AES-256",
      document: { name: "Security.pdf", fileName: "Security.pdf" },
    },
    {
      id: "c2",
      documentId: "d1",
      ordinal: 1,
      page: 2,
      content: "encryption in transit uses TLS 1.3",
      document: { name: "Security.pdf", fileName: "Security.pdf" },
    },
  ]);
});

describe("searchIndex — multimodal retrieval (Phase IM)", () => {
  it("imageMode='off' is the default: no image search and no image hits in result", async () => {
    const hits = await searchIndex(INDEX_A, "encryption", { topK: 5 });
    expect(storeMock.searchImages).not.toHaveBeenCalled();
    expect(clipMock.embedTextForImageSearch).not.toHaveBeenCalled();
    expect(hits.every((h) => h.kind !== "image")).toBe(true);
    expect(hits.length).toBeGreaterThan(0);
  });

  it("imageMode='fuse' adds image hits with kind='image' to the result", async () => {
    storeMock.searchImages.mockResolvedValueOnce([
      {
        id: "img-1",
        score: 0.85,
        imagePath: "uploads/images/diag.png",
        caption: "Encryption flow",
        ocrText: "client → server → DB (TLS)",
        page: 4,
        documentId: "d1",
        chunkId: null,
      },
    ]);
    const hits = await searchIndex(INDEX_A, "encryption", { topK: 5, imageMode: "fuse" });
    expect(clipMock.embedTextForImageSearch).toHaveBeenCalledWith("encryption");
    expect(storeMock.searchImages).toHaveBeenCalledTimes(1);
    const imageHit = hits.find((h) => h.kind === "image");
    expect(imageHit).toBeDefined();
    expect(imageHit?.id).toBe("img-1");
    expect(imageHit?.imagePath).toBe("uploads/images/diag.png");
    expect(imageHit?.caption).toBe("Encryption flow");
    // Text hits still present.
    expect(hits.some((h) => h.id === "c1")).toBe(true);
  });

  it("imageMode='only' drops text hits and returns only image hits", async () => {
    storeMock.searchImages.mockResolvedValueOnce([
      {
        id: "img-1",
        score: 0.91,
        imagePath: "uploads/images/diag.png",
        caption: "Diagram",
        page: 1,
        documentId: "d1",
        chunkId: null,
      },
      {
        id: "img-2",
        score: 0.7,
        imagePath: "uploads/images/screenshot.png",
        page: 2,
        documentId: "d1",
        chunkId: null,
      },
    ]);
    const hits = await searchIndex(INDEX_A, "diagram", { topK: 5, imageMode: "only" });
    expect(hits).toHaveLength(2);
    expect(hits.every((h) => h.kind === "image")).toBe(true);
    expect(hits.find((h) => h.id === "c1")).toBeUndefined();
  });

  it("when CLIP fails to load, image retrieval is skipped but text hits still returned", async () => {
    clipMock.embedTextForImageSearch.mockRejectedValueOnce(new Error("model not downloaded"));
    const hits = await searchIndex(INDEX_A, "encryption", { topK: 5, imageMode: "fuse" });
    expect(hits.length).toBeGreaterThan(0);
    expect(hits.every((h) => h.kind !== "image")).toBe(true);
    expect(storeMock.searchImages).not.toHaveBeenCalled();
  });

  it("imageTopK is forwarded to searchImages (default 5)", async () => {
    storeMock.searchImages.mockResolvedValueOnce([]);
    await searchIndex(INDEX_A, "encryption", { imageMode: "fuse", imageTopK: 3 });
    expect(storeMock.searchImages).toHaveBeenCalledTimes(1);
    const opts = storeMock.searchImages.mock.calls[0][3] as { topK: number };
    expect(opts.topK).toBe(3);
  });

  it("threads filter.documentIds through to searchImages", async () => {
    storeMock.searchImages.mockResolvedValueOnce([]);
    await searchIndex(INDEX_A, "encryption", {
      imageMode: "fuse",
      filter: { documentIds: ["d1"] },
    });
    const opts = storeMock.searchImages.mock.calls[0][3] as {
      filter?: { documentIds?: string[] };
    };
    expect(opts.filter?.documentIds).toEqual(["d1"]);
  });
});
