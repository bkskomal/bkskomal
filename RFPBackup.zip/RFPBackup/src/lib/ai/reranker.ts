// Cross-encoder reranker (Phase B.1).
//
// Loads a BGE-style cross-encoder via @huggingface/transformers and scores
// (query, passage) pairs. The output is a single relevance logit per pair;
// we sort the candidate list in descending score and return the requested
// top-K. Defaults to BAAI/bge-reranker-v2-m3 — runs on CPU in ~50-150 ms
// per pair on a typical laptop, no API cost, no per-org token spend.
//
// Design notes:
//   - Singleton, lazy-load. Model is ~568 MB (multilingual reranker) but
//     transformers.js caches under node_modules/.cache/transformers, so the
//     download only happens once per machine.
//   - Public surface is small: `getCrossEncoder().rerank(query, passages,
//     topK?)` returns indices sorted best-to-worst, plus the scores.
//   - Per-call wall-clock cap of 60s so a runaway batch doesn't hang the
//     generate path. Each pair is bounded internally; the cap is for the
//     whole batch.
//   - Errors surface as warnings — retrieval.ts (the caller) is responsible
//     for the fallback path (today: LLM reranker, in the spirit of
//     "the reranker the operator configured wasn't available, so we used
//     the next-best one we had").

import { log } from "@/lib/logger";

export const DEFAULT_RERANKER_MODEL = "Xenova/bge-reranker-base";

// 60s — covers cold-start model download and CPU inference. Subsequent calls
// are ~50-150 ms per pair, so a 20-candidate batch typically finishes well
// inside this window.
const DEFAULT_TIMEOUT_MS = 60_000;

export interface RerankResult {
  /** Indices into the input `passages` array, sorted best→worst. */
  order: number[];
  /** Aligned with `order` — sigmoid'd relevance scores in [0,1]. */
  scores: number[];
  /** The model id that produced these scores (for log correlation). */
  model: string;
}

export interface CrossEncoder {
  readonly model: string;
  /** True once the model is loaded. Lazy on first call. */
  readonly ready: boolean;
  /**
   * Score every passage against the query and return a sorted index list +
   * scores. `topK` truncates the result; omit to get all passages back in
   * relevance order.
   */
  rerank(query: string, passages: string[], topK?: number): Promise<RerankResult>;
}

// --- transformers.js loader (mirrors clip.ts) -------------------------------

interface Tokenizer {
  (
    text: string | string[],
    opts?: { text_pair?: string | string[]; padding?: boolean; truncation?: boolean; return_tensors?: string },
  ): Record<string, unknown>;
}
interface SequenceClassificationModel {
  (inputs: Record<string, unknown>): Promise<{ logits: { data: Float32Array; dims: number[] } }>;
}
interface TransformersModule {
  AutoTokenizer: { from_pretrained: (model: string) => Promise<Tokenizer> };
  AutoModelForSequenceClassification: {
    from_pretrained: (model: string) => Promise<SequenceClassificationModel>;
  };
  env: { cacheDir?: string; allowLocalModels?: boolean };
}

let _mod: TransformersModule | null = null;
async function getTransformers(): Promise<TransformersModule> {
  if (_mod) return _mod;
  const mod = (await import("@huggingface/transformers")) as unknown as TransformersModule;
  if (mod.env) {
    mod.env.cacheDir = "./node_modules/.cache/transformers";
    mod.env.allowLocalModels = true;
  }
  _mod = mod;
  return mod;
}

// Cache (tokenizer, model) pairs per model id so concurrent rerank calls
// share one loaded copy. The text-classification pipeline pattern was wrong
// for BGE rerankers — single-class softmax produces 1.0 for every pair — so
// we tokenize + run the model + read the raw logit ourselves.
interface ScorerPair {
  tokenizer: Tokenizer;
  model: SequenceClassificationModel;
}
const scorerPromiseByModel = new Map<string, Promise<ScorerPair>>();

async function getScorer(modelId: string): Promise<ScorerPair> {
  let p = scorerPromiseByModel.get(modelId);
  if (!p) {
    p = (async () => {
      const mod = await getTransformers();
      const [tokenizer, model] = await Promise.all([
        mod.AutoTokenizer.from_pretrained(modelId),
        mod.AutoModelForSequenceClassification.from_pretrained(modelId),
      ]);
      return { tokenizer, model };
    })();
    scorerPromiseByModel.set(modelId, p);
  }
  try {
    return await p;
  } catch (e) {
    // Don't leave a poisoned promise that re-throws forever.
    scorerPromiseByModel.delete(modelId);
    throw e;
  }
}

function sigmoid(x: number): number {
  // Numerically stable for large |x|.
  if (x >= 0) {
    const z = Math.exp(-x);
    return 1 / (1 + z);
  }
  const z = Math.exp(x);
  return z / (1 + z);
}

// --- public factory ---------------------------------------------------------

let _readyByModel = new Map<string, boolean>();

class CrossEncoderImpl implements CrossEncoder {
  constructor(public readonly model: string) {}

  get ready(): boolean {
    return _readyByModel.get(this.model) === true;
  }

  async rerank(query: string, passages: string[], topK?: number): Promise<RerankResult> {
    if (passages.length === 0) {
      return { order: [], scores: [], model: this.model };
    }
    const { tokenizer, model } = await withTimeout(
      getScorer(this.model),
      DEFAULT_TIMEOUT_MS,
      `cross-encoder model load (${this.model})`,
    );
    _readyByModel.set(this.model, true);

    // Tokenize the (query, passage) pairs as a batch. text_pair is the BGE
    // cross-encoder convention — the tokenizer joins them with the model's
    // [SEP] token before feeding through the encoder.
    const queries = passages.map(() => query);
    const inputs = tokenizer(queries, {
      text_pair: passages,
      padding: true,
      truncation: true,
    });
    const output = await withTimeout(
      model(inputs),
      DEFAULT_TIMEOUT_MS,
      `cross-encoder batch (${this.model}, n=${passages.length})`,
    );

    // Single-class regression model — one logit per pair. Sigmoid → 0..1
    // relevance score. (Wrong path: pipeline("text-classification") applies
    // softmax which always returns 1.0 for a single class.)
    const logits = output.logits.data;
    const scores = passages.map((_, i) => sigmoid(logits[i]));

    // Sort indices by score desc.
    const indices = scores
      .map((s, i) => ({ s, i }))
      .sort((a, b) => b.s - a.s)
      .map((x) => x.i);
    const sortedScores = indices.map((i) => scores[i]);
    const limit = topK ?? indices.length;
    return {
      order: indices.slice(0, limit),
      scores: sortedScores.slice(0, limit),
      model: this.model,
    };
  }
}

const _encoderByModel = new Map<string, CrossEncoder>();

/**
 * Return the singleton cross-encoder for the given model id. Multiple calls
 * with the same id share the same loaded pipeline (and the same cached
 * download). Defaults to BGE-reranker-base when no model is passed.
 */
export function getCrossEncoder(model: string = DEFAULT_RERANKER_MODEL): CrossEncoder {
  let e = _encoderByModel.get(model);
  if (!e) {
    e = new CrossEncoderImpl(model);
    _encoderByModel.set(model, e);
  }
  return e;
}

/**
 * Test seam — clears every cached pipeline + factory so unit tests can swap
 * the underlying transformers module via vi.mock without state leaking
 * across files. Production code should never call this.
 */
export function _resetCrossEncoderForTests(): void {
  _mod = null;
  scorerPromiseByModel.clear();
  _readyByModel = new Map();
  _encoderByModel.clear();
}

// --- internals --------------------------------------------------------------

async function withTimeout<T>(
  p: Promise<T>,
  ms: number,
  label: string,
): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      const err = new Error(`${label}: timed out after ${ms} ms`);
      log().warn({ label, ms }, "cross-encoder timeout");
      reject(err);
    }, ms);
  });
  try {
    return await Promise.race([p, timeoutPromise]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
