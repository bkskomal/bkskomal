// Cross-encoder reranker — unit tests.
//
// We mock @huggingface/transformers so the test never has to download a
// real model. The mock returns deterministic scores keyed off the passage
// text so we can verify the sort order, scoring path, and graceful handling
// of edge cases (empty input, single candidate, model error).

import { describe, expect, it, beforeEach, vi } from "vitest";

const { tokenizerMock, modelMock, tokenizerFromMock, modelFromMock } = vi.hoisted(() => {
  const tokenizerMock = vi.fn();
  const modelMock = vi.fn();
  return {
    tokenizerMock,
    modelMock,
    // Typed to accept a model id arg so the vi.mock factory's
    // `from_pretrained: (model: string) => xMock(model)` typechecks.
    tokenizerFromMock: vi.fn(async (_model: string) => tokenizerMock),
    modelFromMock: vi.fn(async (_model: string) => modelMock),
  };
});

vi.mock("@huggingface/transformers", () => ({
  // BGE rerankers use AutoTokenizer + AutoModelForSequenceClassification;
  // the test seam exposes both so we can drive scores per-call.
  AutoTokenizer: { from_pretrained: (model: string) => tokenizerFromMock(model) },
  AutoModelForSequenceClassification: {
    from_pretrained: (model: string) => modelFromMock(model),
  },
  env: {},
}));

// Helper: stub the tokenizer (returns an empty inputs object) + drive the
// model to return a known logits array for the next call.
function setLogits(values: number[]) {
  tokenizerMock.mockImplementation(() => ({ /* opaque inputs */ }));
  modelMock.mockImplementationOnce(async () => ({
    logits: { data: new Float32Array(values), dims: [values.length, 1] },
  }));
}

import {
  getCrossEncoder,
  _resetCrossEncoderForTests,
  DEFAULT_RERANKER_MODEL,
} from "./reranker";

beforeEach(() => {
  _resetCrossEncoderForTests();
  tokenizerMock.mockReset();
  modelMock.mockReset();
  tokenizerFromMock.mockClear();
  modelFromMock.mockClear();
  tokenizerFromMock.mockResolvedValue(tokenizerMock);
  modelFromMock.mockResolvedValue(modelMock);
});

describe("CrossEncoder.rerank", () => {
  it("sorts passages by descending sigmoid'd logits", async () => {
    // Logits chosen so sigmoid orders them: idx 1 > idx 2 > idx 0.
    // sigmoid(2)=0.88, sigmoid(0)=0.5, sigmoid(-2)=0.12
    setLogits([-2, 2, 0]);

    const encoder = getCrossEncoder();
    const result = await encoder.rerank("what is the SLA?", [
      "irrelevant",
      "highly relevant SLA content",
      "somewhat related",
    ]);

    expect(result.order).toEqual([1, 2, 0]);
    expect(result.scores[0]).toBeGreaterThan(result.scores[1]);
    expect(result.scores[1]).toBeGreaterThan(result.scores[2]);
    expect(result.model).toBe(DEFAULT_RERANKER_MODEL);
    // Scores must lie in (0, 1).
    for (const s of result.scores) {
      expect(s).toBeGreaterThan(0);
      expect(s).toBeLessThan(1);
    }
  });

  it("supports topK truncation", async () => {
    // First-pair has the highest logit, descending from there.
    setLogits([5, 4, 3, 2, 1]);

    const encoder = getCrossEncoder();
    const result = await encoder.rerank("q", ["a", "b", "c", "d", "e"], 2);
    expect(result.order).toEqual([0, 1]);
    expect(result.scores).toHaveLength(2);
  });

  it("returns empty result on empty input without loading the model", async () => {
    const encoder = getCrossEncoder();
    const result = await encoder.rerank("q", []);
    expect(result.order).toEqual([]);
    expect(result.scores).toEqual([]);
    // Model should not have been requested at all.
    expect(tokenizerFromMock).not.toHaveBeenCalled();
    expect(modelFromMock).not.toHaveBeenCalled();
  });

  it("uses the configured model id when one is passed", async () => {
    setLogits([0.5, 0.5]);
    const encoder = getCrossEncoder("BAAI/bge-reranker-v2-m3");
    const result = await encoder.rerank("q", ["a", "b"]);
    expect(result.model).toBe("BAAI/bge-reranker-v2-m3");
    expect(tokenizerFromMock).toHaveBeenCalledWith("BAAI/bge-reranker-v2-m3");
    expect(modelFromMock).toHaveBeenCalledWith("BAAI/bge-reranker-v2-m3");
  });

  it("propagates model load errors so the caller can fall back", async () => {
    modelFromMock.mockRejectedValueOnce(new Error("model not downloaded"));
    const encoder = getCrossEncoder();
    await expect(encoder.rerank("q", ["a", "b"])).rejects.toThrow(/model not downloaded/);
  });

  it("re-attempts model load after a previous failure (no poisoned promise)", async () => {
    modelFromMock.mockRejectedValueOnce(new Error("transient network blip"));
    setLogits([0.5]);

    const encoder = getCrossEncoder();
    await expect(encoder.rerank("q", ["a"])).rejects.toThrow(/transient network blip/);
    // Second call should succeed (cache was cleared on failure).
    const ok = await encoder.rerank("q", ["a"]);
    expect(ok.order).toEqual([0]);
  });
});
