// Contextual retrieval — unit tests (Phase B.3).
//
// We mock the LLM client so the tests run offline. Coverage:
//   - Returns an aligned array of blurbs, one per chunk
//   - Empty input short-circuits without calling the model
//   - Per-chunk LLM failure degrades to empty string (ingest doesn't break)
//   - Doc text is truncated to MAX_DOC_CHARS
//   - sanitizeBlurb strips quotes, collapses whitespace, caps length

import { describe, expect, it, beforeEach, vi } from "vitest";

const { llmCreateMock, getAiClientsMock } = vi.hoisted(() => {
  const llmCreateMock = vi.fn();
  return {
    llmCreateMock,
    getAiClientsMock: vi.fn(async () => ({
      llm: { chat: { completions: { create: llmCreateMock } } },
      config: { extraction: { model: "test-extract-model" } },
    })),
  };
});

vi.mock("./client", () => ({
  getAiClients: (...args: unknown[]) => (getAiClientsMock as (...a: unknown[]) => unknown)(...args),
}));

import { contextualizeChunks, sanitizeBlurb } from "./contextual-chunks";

beforeEach(() => {
  llmCreateMock.mockReset();
  getAiClientsMock.mockClear();
});

describe("contextualizeChunks", () => {
  it("returns one blurb per chunk, sourced from the LLM response", async () => {
    llmCreateMock.mockImplementation(async (params: { messages: Array<{ role: string; content: string }> }) => {
      // Echo the chunk ordinal back as the blurb so we can assert alignment.
      const user = params.messages.find((m) => m.role === "user")?.content ?? "";
      const m = user.match(/# CHUNK\n(?:.*\n)?(.+)/);
      return {
        choices: [{ message: { content: `blurb for: ${m?.[1] ?? "?"}` } }],
      };
    });

    const blurbs = await contextualizeChunks(
      "Full document text here.",
      [
        { ordinal: 0, content: "alpha" },
        { ordinal: 1, content: "beta" },
        { ordinal: 2, content: "gamma" },
      ],
      "org-1",
    );
    expect(blurbs).toEqual([
      "blurb for: alpha",
      "blurb for: beta",
      "blurb for: gamma",
    ]);
    expect(llmCreateMock).toHaveBeenCalledTimes(3);
  });

  it("returns empty array for empty input without calling the model", async () => {
    const blurbs = await contextualizeChunks("doc", [], "org-1");
    expect(blurbs).toEqual([]);
    expect(llmCreateMock).not.toHaveBeenCalled();
    expect(getAiClientsMock).not.toHaveBeenCalled();
  });

  it("returns all-empty when document text is blank (no context to add)", async () => {
    const blurbs = await contextualizeChunks(
      "   ",
      [{ ordinal: 0, content: "anything" }],
      "org-1",
    );
    expect(blurbs).toEqual([""]);
    expect(llmCreateMock).not.toHaveBeenCalled();
  });

  it("degrades per-chunk failure to empty string (does not throw)", async () => {
    let call = 0;
    llmCreateMock.mockImplementation(async () => {
      call++;
      if (call === 2) throw new Error("rate limited");
      return { choices: [{ message: { content: "context-ok" } }] };
    });

    const blurbs = await contextualizeChunks(
      "doc",
      [
        { ordinal: 0, content: "a" },
        { ordinal: 1, content: "b" },
        { ordinal: 2, content: "c" },
      ],
      "org-1",
    );
    // 3 chunks, 1 failed somewhere — exactly 1 empty, 2 successful.
    expect(blurbs).toHaveLength(3);
    expect(blurbs.filter((b) => b === "").length).toBe(1);
    expect(blurbs.filter((b) => b === "context-ok").length).toBe(2);
  });

  it("uses the extraction model from clients config", async () => {
    llmCreateMock.mockResolvedValue({ choices: [{ message: { content: "ok" } }] });
    await contextualizeChunks("doc", [{ ordinal: 0, content: "x" }], "org-1");
    const callArgs = llmCreateMock.mock.calls[0][0];
    expect(callArgs.model).toBe("test-extract-model");
    expect(callArgs.temperature).toBe(0);
    expect(callArgs.max_tokens).toBe(80);
  });

  it("truncates very long documents before sending to the LLM", async () => {
    llmCreateMock.mockResolvedValue({ choices: [{ message: { content: "ok" } }] });
    // 50_000 chars >> MAX_DOC_CHARS (16_000). Sanity-check that the user
    // prompt the model receives doesn't blow up to the full size.
    const giantDoc = "X".repeat(50_000);
    await contextualizeChunks(giantDoc, [{ ordinal: 0, content: "y" }], "org-1");
    const userPrompt = llmCreateMock.mock.calls[0][0].messages[1].content as string;
    expect(userPrompt.length).toBeLessThan(20_000);
  });
});

describe("sanitizeBlurb", () => {
  it("strips surrounding double quotes", () => {
    expect(sanitizeBlurb('"the answer"')).toBe("the answer");
  });

  it("strips surrounding single quotes", () => {
    expect(sanitizeBlurb("'the answer'")).toBe("the answer");
  });

  it("collapses newlines and runs of whitespace", () => {
    expect(sanitizeBlurb("line one\n\n   line   two")).toBe("line one line two");
  });

  it("trims and returns empty on whitespace-only", () => {
    expect(sanitizeBlurb("   \n  ")).toBe("");
  });

  it("caps at the max-blurb length", () => {
    const long = "x".repeat(500);
    const out = sanitizeBlurb(long);
    expect(out.length).toBeLessThanOrEqual(240);
  });
});
