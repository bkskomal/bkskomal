import { describe, expect, it, beforeEach, vi } from "vitest";

// Mock prisma + resolveAiConfig so we can control the routing inputs to
// `pickModelForGeneration` without standing up a DB. The unit tests on the
// pure router are exhaustive — here we only need to confirm that the integ
// path correctly threads org config + complexity through to the decision and
// increments the metric.

const { prismaMock, resolveAiConfigMock, resolveAdapterMock } = vi.hoisted(() => ({
  prismaMock: {
    orgAiConfig: {
      findUnique: vi.fn(),
    },
  },
  resolveAiConfigMock: vi.fn(),
  resolveAdapterMock: vi.fn(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("./config", () => ({
  resolveAiConfig: (...args: unknown[]) => resolveAiConfigMock(...args),
}));

// Adapter resolution is its own module — mock it so the pickModelForGeneration
// integration tests can flip the adapter on/off without standing up a DB.
vi.mock("@/lib/lora/resolver", () => ({
  resolveAdapter: (...args: unknown[]) => resolveAdapterMock(...args),
}));

import { pickModelForGeneration } from "./client";
import { exposition } from "@/lib/metrics";

beforeEach(() => {
  vi.clearAllMocks();
  // Default: resolveAiConfig returns a usable env default if we end up
  // calling it (no org row). Most tests provide an org row directly.
  resolveAiConfigMock.mockResolvedValue({
    llm: { model: "env-default-model" },
  });
  // Adapter default: none configured. Tests that exercise the override
  // path set their own return value.
  resolveAdapterMock.mockResolvedValue(null);
});

describe("pickModelForGeneration — integration with router + metrics", () => {
  it("consults the router and returns standard model when routing disabled", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      routingEnabled: false,
      llmModel: "std",
      llmModelSimple: "cheap",
      llmModelComplex: "premium",
    });

    const decision = await pickModelForGeneration("org-1", "simple");

    expect(decision).toEqual({
      model: "std",
      reason: "routing_disabled",
      baseModel: "std",
    });
  });

  it("routes a simple question to the cheap model when routing enabled", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      routingEnabled: true,
      llmModel: "std",
      llmModelSimple: "cheap",
      llmModelComplex: "premium",
    });

    const decision = await pickModelForGeneration("org-1", "simple");

    expect(decision.model).toBe("cheap");
    expect(decision.reason).toBe("simple_routed");
    expect(decision.baseModel).toBe("std");
  });

  it("routes a complex question to the premium model when routing enabled", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      routingEnabled: true,
      llmModel: "std",
      llmModelSimple: "cheap",
      llmModelComplex: "premium",
    });

    const decision = await pickModelForGeneration("org-1", "complex");

    expect(decision.model).toBe("premium");
    expect(decision.reason).toBe("complex_routed");
  });

  it("falls back to env default when the org has no AI-config row", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue(null);
    resolveAiConfigMock.mockResolvedValue({
      llm: { model: "env-default-model" },
    });

    const decision = await pickModelForGeneration("org-1", "simple");

    expect(decision.model).toBe("env-default-model");
    expect(decision.reason).toBe("routing_disabled");
    expect(decision.baseModel).toBe("env-default-model");
  });

  it("adapter set → returns adapter URL as model with reason 'adapter_override'", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      routingEnabled: true,
      llmModel: "std",
      llmModelSimple: "cheap",
      llmModelComplex: "premium",
    });
    resolveAdapterMock.mockResolvedValue({
      url: "ft:gpt-4o-mini:acme::abc123",
      baseModel: "gpt-4o-mini",
      rank: 8,
      provider: "openai_ft",
    });

    const decision = await pickModelForGeneration("org-1", "complex");
    expect(decision.model).toBe("ft:gpt-4o-mini:acme::abc123");
    expect(decision.reason).toBe("adapter_override");
    // baseModel still reports the org's *standard* model so the UI can show
    // "currently using fine-tune <X> instead of <std>".
    expect(decision.baseModel).toBe("std");
    expect(decision.adapterMeta?.url).toBe("ft:gpt-4o-mini:acme::abc123");
    expect(decision.adapterMeta?.baseModel).toBe("gpt-4o-mini");
  });

  it("adapter null → falls through to existing routing logic", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      routingEnabled: true,
      llmModel: "std",
      llmModelSimple: "cheap",
      llmModelComplex: "premium",
    });
    resolveAdapterMock.mockResolvedValue(null);

    const decision = await pickModelForGeneration("org-1", "simple");
    expect(decision.model).toBe("cheap");
    expect(decision.reason).toBe("simple_routed");
    expect(decision.adapterMeta).toBeUndefined();
  });

  it("increments llm_routing_decisions_total with the chosen model + reason", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValue({
      routingEnabled: true,
      llmModel: "std",
      llmModelSimple: "cheap",
      llmModelComplex: "premium",
    });

    await pickModelForGeneration("org-1", "simple");
    const text = exposition();
    expect(text).toContain("llm_routing_decisions_total{");
    // Counter accumulates across tests; just assert the labelled sample exists
    // (the count itself is checked implicitly — line is present iff inc fired).
    expect(text).toMatch(
      /llm_routing_decisions_total\{[^}]*model="cheap"[^}]*reason="simple_routed"[^}]*\} \d+/,
    );
  });
});
