import { describe, it, expect } from "vitest";
import { routeForComplexity, type RoutingConfig } from "./router";

// Helpers — keep each test focused on the one variable that matters.
const cfgWith = (overrides: Partial<RoutingConfig> = {}): RoutingConfig => ({
  routingEnabled: true,
  llmModel: "standard-model",
  llmModelSimple: "cheap-model",
  llmModelComplex: "premium-model",
  ...overrides,
});

describe("routeForComplexity", () => {
  it("routing disabled → standard model, reason=routing_disabled", () => {
    const d = routeForComplexity({
      config: cfgWith({ routingEnabled: false }),
      complexity: "simple",
    });
    expect(d).toEqual({
      model: "standard-model",
      reason: "routing_disabled",
      baseModel: "standard-model",
    });
  });

  it("no complexity → standard model, reason=no_complexity", () => {
    const d = routeForComplexity({
      config: cfgWith(),
      complexity: undefined,
    });
    expect(d).toEqual({
      model: "standard-model",
      reason: "no_complexity",
      baseModel: "standard-model",
    });
  });

  it("simple + llmModelSimple set → cheap model, reason=simple_routed", () => {
    const d = routeForComplexity({
      config: cfgWith(),
      complexity: "simple",
    });
    expect(d).toEqual({
      model: "cheap-model",
      reason: "simple_routed",
      baseModel: "standard-model",
    });
  });

  it("simple + llmModelSimple null → standard model, reason=fallback", () => {
    const d = routeForComplexity({
      config: cfgWith({ llmModelSimple: null }),
      complexity: "simple",
    });
    expect(d).toEqual({
      model: "standard-model",
      reason: "fallback",
      baseModel: "standard-model",
    });
  });

  it("complex + llmModelComplex set → premium model, reason=complex_routed", () => {
    const d = routeForComplexity({
      config: cfgWith(),
      complexity: "complex",
    });
    expect(d).toEqual({
      model: "premium-model",
      reason: "complex_routed",
      baseModel: "standard-model",
    });
  });

  it("complex + llmModelComplex null → standard model, reason=fallback", () => {
    const d = routeForComplexity({
      config: cfgWith({ llmModelComplex: null }),
      complexity: "complex",
    });
    expect(d).toEqual({
      model: "standard-model",
      reason: "fallback",
      baseModel: "standard-model",
    });
  });

  it("moderate complexity always uses llmModel (no routed reason)", () => {
    const d = routeForComplexity({
      config: cfgWith(),
      complexity: "moderate",
    });
    expect(d.model).toBe("standard-model");
    expect(d.baseModel).toBe("standard-model");
    expect(d.reason).toBe("no_complexity");
  });

  it("empty-string simple model is treated as not configured (fallback)", () => {
    const d = routeForComplexity({
      config: cfgWith({ llmModelSimple: "   " }),
      complexity: "simple",
    });
    expect(d.model).toBe("standard-model");
    expect(d.reason).toBe("fallback");
  });
});
