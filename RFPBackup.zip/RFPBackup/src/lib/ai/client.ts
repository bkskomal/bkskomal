// AI client factory. Construct OpenAI clients per-org so config changes (LLM
// endpoint, key, model) take effect without restarting the server.
//
// `OpenAI` instances are cheap to construct (no I/O) so we don't bother
// caching — each call to `getAiClients` builds fresh from the resolved config.
//
// The LLM client's chat-completion path is wrapped with a per-provider circuit
// breaker so a stalled upstream fails fast rather than tying up every in-
// flight request. We key the breaker by baseUrl: each distinct provider gets
// its own breaker, lazily created. Embeddings are NOT wrapped — they have a
// different failure mode (typically fast and cheap, often local), and we
// don't want one provider's slow chat endpoint to block indexing.

import OpenAI from "openai";
import { Agent, fetch as undiciFetch } from "undici";
import { resolveAiConfig, type ResolvedAiConfig } from "./config";
import { createBreaker, type Breaker } from "@/lib/circuit-breaker";
import {
  llmRequestsTotal,
  llmTokensTotal,
  llmRoutingDecisionsTotal,
} from "@/lib/metrics";
import { routeForComplexity, type Complexity, type RoutingDecision } from "./router";
import { prisma } from "@/lib/prisma";
import { resolveAdapter, type AdapterSpec } from "@/lib/lora/resolver";
import { loraAdapterUsesTotal } from "@/lib/metrics";

export interface AiClients {
  config: ResolvedAiConfig;
  llm: OpenAI;
  embedder: OpenAI;
}

// One breaker per LLM baseUrl, lazily created. Keyed by baseUrl rather than
// orgId so multiple orgs sharing the same provider share the failure signal —
// a single provider outage trips the breaker once.
const llmBreakers = new Map<string, Breaker>();

const DEFAULT_FAILURE_THRESHOLD = 5;
const DEFAULT_RESET_TIMEOUT_MS = 30_000;

// ---------------------------------------------------------------------------
// TLS-tolerant fetch for upstream LLM/embedding hosts.
//
// Node's bundled CA store is often missing intermediate certs (especially on
// Windows or behind corporate MITM proxies), so `fetch("https://openrouter.ai/…")`
// can throw `unable to verify the first certificate` on perfectly legitimate
// hosts. Without a fallback the whole RFP pipeline fails with the cryptic
// "Connection error." that the OpenAI SDK surfaces.
//
// Strategy mirrors what we did for the URL scraper + image-fetch: try strict
// TLS first; on a chain error, retry once via an undici Agent with
// rejectUnauthorized=false. Long-term fix is to set NODE_EXTRA_CA_CERTS
// to the local/corporate CA bundle.
// ---------------------------------------------------------------------------

const TLS_CHAIN_ERROR_CODES = new Set([
  "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
  "UNABLE_TO_GET_ISSUER_CERT",
  "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
  "SELF_SIGNED_CERT_IN_CHAIN",
  "DEPTH_ZERO_SELF_SIGNED_CERT",
  "CERT_HAS_EXPIRED",
  "CERT_NOT_YET_VALID",
  "ERR_TLS_CERT_ALTNAME_INVALID",
]);

function isTlsChainError(err: unknown): boolean {
  let cur: unknown = err;
  while (cur instanceof Error) {
    const code = (cur as Error & { code?: string }).code;
    if (code && TLS_CHAIN_ERROR_CODES.has(code)) return true;
    const msg = cur.message ?? "";
    if (
      /unable to verify the first certificate/i.test(msg) ||
      /self[- ]signed certificate/i.test(msg) ||
      /certificate has expired/i.test(msg) ||
      /unable to get local issuer certificate/i.test(msg)
    ) {
      return true;
    }
    cur = (cur as Error & { cause?: unknown }).cause;
  }
  return false;
}

let _insecureAgent: Agent | undefined;
function getInsecureAgent(): Agent {
  if (!_insecureAgent) {
    _insecureAgent = new Agent({ connect: { rejectUnauthorized: false } });
  }
  return _insecureAgent;
}

// Have we already discovered this baseURL needs the relaxed agent? Once we
// see one chain error against a host, subsequent calls go straight through
// the insecure agent — avoids hitting the bad chain twice per request and
// silences the warning spam.
const tlsRelaxedHosts = new Set<string>();

function hostOf(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return "";
  }
}

/**
 * Builds an OpenAI-SDK-compatible `fetch` that:
 *   1. Uses Node's built-in fetch first (full TLS validation).
 *   2. On a chain error, retries via an undici Agent with
 *      rejectUnauthorized=false, and remembers the host as "needs relaxed"
 *      so subsequent calls skip straight to the relaxed path.
 *
 * The OpenAI SDK accepts a custom `fetch` option since v4.x. We pass our
 * wrapper there so every chat / embedding call goes through it.
 */
function buildTolerantFetch(baseUrl: string): typeof fetch {
  const baseHost = hostOf(baseUrl);
  const relaxedCall = (input: string | URL | Request, init?: RequestInit) =>
    undiciFetch(typeof input === "string" ? input : input.toString(), {
      ...(init as Parameters<typeof undiciFetch>[1]),
      dispatcher: getInsecureAgent(),
    }) as unknown as ReturnType<typeof fetch>;

  return (async (input: string | URL | Request, init?: RequestInit) => {
    const url = typeof input === "string" ? input : input.toString();
    const host = hostOf(url) || baseHost;
    if (host && tlsRelaxedHosts.has(host)) {
      return relaxedCall(input, init);
    }
    try {
      return await (globalThis.fetch as typeof fetch)(input as RequestInfo, init);
    } catch (err) {
      if (isTlsChainError(err)) {
        if (host) tlsRelaxedHosts.add(host);
        return relaxedCall(input, init);
      }
      throw err;
    }
  }) as unknown as typeof fetch;
}

function getLlmBreaker(baseUrl: string): Breaker {
  let b = llmBreakers.get(baseUrl);
  if (!b) {
    b = createBreaker({
      name: `llm:${baseUrl}`,
      failureThreshold: DEFAULT_FAILURE_THRESHOLD,
      resetTimeoutMs: DEFAULT_RESET_TIMEOUT_MS,
    });
    llmBreakers.set(baseUrl, b);
  }
  return b;
}

/** @internal — for tests only. */
export function _resetBreakersForTests(): void {
  llmBreakers.clear();
}

/**
 * Wrap an OpenAI client so every chat.completions.create call runs inside the
 * per-baseUrl circuit breaker. We intercept via Proxy to keep the surface
 * identical to a real `OpenAI` instance — callers see the same types.
 *
 * Only chat completions are wrapped; embeddings remain direct. Streaming
 * variants currently aren't used in this codebase, but if added they'd want
 * the same protection.
 */
function wrapLlmWithBreaker(client: OpenAI, baseUrl: string): OpenAI {
  const breaker = getLlmBreaker(baseUrl);
  const originalCreate = client.chat.completions.create.bind(client.chat.completions);
  // Replace just the one method on this instance. `create` is overloaded
  // (params can include stream:true), so we forward args opaquely.
  (client.chat.completions as { create: unknown }).create = ((...args: unknown[]) => {
    // We pull provider+model from the call args for label fidelity. baseUrl
    // doubles as the provider identifier (callers may share a provider across
    // models, so model is its own label). Streaming responses don't expose
    // usage on the result object — we count the request but not tokens.
    const reqArgs = (args[0] as { model?: string } | undefined) ?? {};
    const model = reqArgs.model ?? "unknown";
    return breaker(() =>
      (originalCreate as (...a: unknown[]) => Promise<unknown>)(...args),
    ).then(
      (result) => {
        recordLlmCall(baseUrl, model, "success", result);
        return result;
      },
      (err) => {
        recordLlmCall(baseUrl, model, "error", null);
        throw err;
      },
    );
  }) as typeof client.chat.completions.create;
  return client;
}

function recordLlmCall(provider: string, model: string, status: string, result: unknown): void {
  try {
    llmRequestsTotal.inc({ provider, model, status });
    if (status !== "success" || !result || typeof result !== "object") return;
    const usage = (result as { usage?: { prompt_tokens?: number; completion_tokens?: number } })
      .usage;
    if (!usage) return;
    if (typeof usage.prompt_tokens === "number") {
      llmTokensTotal.inc({ provider, model, kind: "prompt" }, usage.prompt_tokens);
    }
    if (typeof usage.completion_tokens === "number") {
      llmTokensTotal.inc({ provider, model, kind: "completion" }, usage.completion_tokens);
    }
  } catch {
    // never fail an LLM call due to metrics
  }
}

export async function getAiClients(orgId: string | null | undefined): Promise<AiClients> {
  const config = await resolveAiConfig(orgId);

  const llmHeaders: Record<string, string> = {};
  if (config.llm.httpReferer) llmHeaders["HTTP-Referer"] = config.llm.httpReferer;
  if (config.llm.appTitle) llmHeaders["X-Title"] = config.llm.appTitle;

  const llm = new OpenAI({
    baseURL: config.llm.baseUrl,
    apiKey: config.llm.apiKey,
    defaultHeaders: Object.keys(llmHeaders).length ? llmHeaders : undefined,
    fetch: buildTolerantFetch(config.llm.baseUrl),
  });

  return {
    config,
    llm: wrapLlmWithBreaker(llm, config.llm.baseUrl),
    embedder: new OpenAI({
      baseURL: config.embedding.baseUrl,
      apiKey: config.embedding.apiKey,
      fetch: buildTolerantFetch(config.embedding.baseUrl),
    }),
  };
}

// ---------------------------------------------------------------------------
// Model routing (Phase 3B). Resolves the org's routing config and asks the
// pure `routeForComplexity` for a decision. Callers in the generation pipeline
// invoke this *before* sending the chat-completions request so the LLM is
// matched to the question's complexity (cheap model for "simple", premium for
// "complex"). Falls back to the standard `llmModel` when routing is off or
// the org didn't configure a tiered model.
// ---------------------------------------------------------------------------

/**
 * Decision returned by `pickModelForGeneration`. Extends the pure router's
 * `RoutingDecision` with an optional `adapterMeta` payload — populated only
 * when the org has a configured LoRA adapter (reason `adapter_override`).
 *
 * SSE consumers surface `adapterMeta` directly so end-users can see *which*
 * fine-tune answered them (base model, train date, train size, notes).
 */
export interface GenerationModelDecision extends RoutingDecision {
  adapterMeta?: AdapterSpec;
}

/**
 * Resolve the routing decision for an org + question complexity. Reads the
 * `OrgAiConfig` row (cheap — already cached upstream by Prisma) and consults
 * the pure router. Returns a decision whose `model` should be passed to
 * `chat.completions.create`. Increments the `llm_routing_decisions_total`
 * counter exactly once per call.
 *
 * Priority order:
 *   1. LoRA adapter (`loraAdapterUrl` set) — replaces routing entirely.
 *      The adapter URL is the model id; tier-routing is bypassed because
 *      the user paid to fine-tune the adapter and presumably wants every
 *      generation to go through it.
 *   2. Pinned generation model (Phase A.4 `generationModel`) — overrides
 *      tier routing for orgs that don't want simple/complex routing but
 *      do want a specific model for drafting.
 *   3. Tier routing (Phase 3B) — see `routeForComplexity`.
 */
export async function pickModelForGeneration(
  orgId: string | null | undefined,
  complexity: Complexity,
): Promise<GenerationModelDecision> {
  // Fetch the routing fields directly. We could piggy-back on resolveAiConfig
  // but those fields aren't on ResolvedAiConfig and we want to keep this path
  // cheap — a single org row read.
  const orgConfig = orgId
    ? await prisma.orgAiConfig.findUnique({
        where: { organizationId: orgId },
        select: {
          routingEnabled: true,
          llmModel: true,
          llmModelSimple: true,
          llmModelComplex: true,
          // Phase A.4: pinned generation model. Overrides tier routing below
          // (but adapter still wins above).
          generationModel: true,
        },
      })
    : null;

  // If we have no org row at all, routing is implicitly disabled and we still
  // need *some* model name to report. Reuse resolveAiConfig to get the env
  // default model.
  let baseModel = orgConfig?.llmModel ?? null;
  if (!baseModel) {
    const resolved = await resolveAiConfig(orgId);
    baseModel = resolved.llm.model;
  }

  // --- LoRA adapter override (Tier C3) ---
  // Adapter, when set, fully replaces the routing decision: every generation
  // goes through the configured fine-tune regardless of complexity. We still
  // report `baseModel` as the org's *standard* model (what would have run if
  // the adapter weren't configured) — useful for observability and for the
  // UI to render "currently using fine-tune <X> instead of <baseModel>".
  if (orgId) {
    const adapter = await resolveAdapter(orgId);
    if (adapter) {
      const decision: GenerationModelDecision = {
        model: adapter.url,
        reason: "adapter_override",
        baseModel,
        adapterMeta: adapter,
      };
      try {
        llmRoutingDecisionsTotal.inc({
          model: decision.model,
          reason: decision.reason,
        });
        loraAdapterUsesTotal.inc({
          org: orgId,
          base_model: adapter.baseModel,
        });
      } catch {
        // metrics must never fail generation
      }
      return decision;
    }
  }

  // Phase A.4: pinned generation model. If the org pinned a specific drafting
  // model, that wins over tier routing. (Adapter already won above.)
  if (orgConfig?.generationModel) {
    const decision: GenerationModelDecision = {
      model: orgConfig.generationModel,
      reason: "pinned",
      baseModel,
    };
    try {
      llmRoutingDecisionsTotal.inc({ model: decision.model, reason: decision.reason });
    } catch {
      // metrics never fail generation
    }
    return decision;
  }

  const decision = routeForComplexity({
    config: {
      routingEnabled: orgConfig?.routingEnabled ?? false,
      llmModel: baseModel,
      llmModelSimple: orgConfig?.llmModelSimple ?? null,
      llmModelComplex: orgConfig?.llmModelComplex ?? null,
    },
    complexity,
  });

  try {
    llmRoutingDecisionsTotal.inc({
      model: decision.model,
      reason: decision.reason,
    });
  } catch {
    // never fail generation on a metric write
  }

  return decision;
}
