// Win/loss feedback loop — outcome-aware re-ranking of golden answers.
//
// The retrieval engine already returns ranked chunks; this module adds a thin
// post-rank pass that nudges golden answers based on the *outcome* of any
// historical RFP that asked a similar question. The intuition:
//
//   * Answer style/substance that previously came from a WON deal is more
//     likely to win again — boost it to the top of the prompt.
//   * Answer style/substance that came from a LOST deal is a known failure
//     mode — demote it (and surface a coaching note alongside; see
//     coachingNoteForGoldenAnswer below).
//   * Anything else (PENDING / WITHDRAWN / NO_BID / unknown) is a no-op.
//
// Boost magnitudes are intentionally small (defaults +/- 0.2) and configurable
// via env so operators can dial the feedback loop up or down without redeploys.
// Boosts ADD to the implicit "freshness" rank position; they don't replace it.
//
// Matching strategy: simple case-insensitive equality on the question text
// after normalisation (whitespace collapsed, punctuation stripped, lowercased).
// Trigram / embedding similarity would catch more matches but is overkill for
// the iteration budget — the typical case is a vendor reusing exact-or-near
// question wording across RFPs (security questionnaires, SIG Lite, CAIQ, etc.).

import type { PrismaClient, RfpOutcome } from "@prisma/client";
import { prisma as defaultPrisma } from "@/lib/prisma";
import { env } from "@/lib/env";

export type OutcomeBoostInput = {
  id?: string;
  question: string;
};

/**
 * Look up the historical outcome for a golden answer's source question and
 * return the additive boost. Returns 0 when no match is found or when the
 * outcome is non-decisive (PENDING / WITHDRAWN / NO_BID).
 *
 * Pass an `OutcomeBoostCache` to dedupe lookups within a single generation
 * call — the same golden answer is otherwise queried once per .map() iteration
 * which is wasteful.
 *
 * Boost values are read from env at call time so tests can mutate
 * process.env between runs.
 */
export async function outcomeBoostForGoldenAnswer(
  orgId: string,
  goldenAnswer: OutcomeBoostInput,
  cache?: OutcomeBoostCache,
  prismaClient: PrismaClient = defaultPrisma,
): Promise<number> {
  const cacheKey = goldenAnswer.id ?? normalizeQuestion(goldenAnswer.question);
  if (cache?.has(cacheKey)) return cache.get(cacheKey)!;

  const outcome = await lookupOutcomeForQuestion(
    orgId,
    goldenAnswer.question,
    cache,
    prismaClient,
  );
  const boost = outcomeToBoost(outcome);
  cache?.set(cacheKey, boost);
  return boost;
}

/**
 * Sort goldens by their outcome-derived boost (descending) while preserving
 * the input order as a tiebreaker. Returns a new array; does not mutate the
 * input. Use when you want to re-rank a list before slicing the top N.
 */
export async function reorderGoldensByOutcome<T extends OutcomeBoostInput>(
  orgId: string,
  goldens: T[],
  cache: OutcomeBoostCache = createOutcomeBoostCache(),
  prismaClient: PrismaClient = defaultPrisma,
): Promise<Array<T & { outcomeBoost: number }>> {
  const annotated = await Promise.all(
    goldens.map(async (g, originalIndex) => ({
      golden: g,
      originalIndex,
      outcomeBoost: await outcomeBoostForGoldenAnswer(orgId, g, cache, prismaClient),
    })),
  );
  annotated.sort((a, b) => {
    if (b.outcomeBoost !== a.outcomeBoost) return b.outcomeBoost - a.outcomeBoost;
    return a.originalIndex - b.originalIndex;
  });
  return annotated.map(({ golden, outcomeBoost }) => ({ ...golden, outcomeBoost }));
}

/**
 * For LOST-tied goldens, build a short coaching note for the prompt — tells
 * the model that the prior answer didn't win and asks it to avoid repeating
 * style/substance errors. Returns null when no LOST match exists.
 */
export async function coachingNoteForGoldenAnswer(
  orgId: string,
  goldenAnswer: OutcomeBoostInput,
  cache: OutcomeBoostCache = createOutcomeBoostCache(),
  prismaClient: PrismaClient = defaultPrisma,
): Promise<{ rfpTitle: string | null; rfpId: string; note: string } | null> {
  const match = await lookupRfpForLostQuestion(
    orgId,
    goldenAnswer.question,
    cache,
    prismaClient,
  );
  if (!match) return null;
  return {
    rfpId: match.rfpId,
    rfpTitle: match.rfpTitle,
    note:
      `This question's prior answer (RFP ${match.rfpTitle ?? match.rfpId}, lost) was the one above. ` +
      `Avoid repeating any errors of style or substance from that prior submission.`,
  };
}

// ---------------------------------------------------------------------------
// Cache. A simple Map keyed by golden id (or normalised question text when no
// id is available). Lifetime: a single generation call. Don't share across
// requests — outcomes can change.
// ---------------------------------------------------------------------------

export interface OutcomeBoostCache {
  has(key: string): boolean;
  get(key: string): number | undefined;
  set(key: string, value: number): void;
  /** Returns the underlying call count for tests. */
  __dbCallCount(): number;
  __recordCall(): void;
}

export function createOutcomeBoostCache(): OutcomeBoostCache {
  const map = new Map<string, number>();
  let calls = 0;
  return {
    has: (k) => map.has(k),
    get: (k) => map.get(k),
    set: (k, v) => {
      map.set(k, v);
    },
    __dbCallCount: () => calls,
    __recordCall: () => {
      calls += 1;
    },
  };
}

// ---------------------------------------------------------------------------
// Internals.
// ---------------------------------------------------------------------------

function outcomeToBoost(outcome: RfpOutcome | null): number {
  if (outcome === "WON") return env.OUTCOME_BOOST_WON;
  if (outcome === "LOST") return env.OUTCOME_BOOST_LOST;
  return 0;
}

/**
 * Normalise a question for matching: lowercase, collapse whitespace, strip
 * trailing punctuation. Keeps the implementation portable across DBs without
 * needing pg_trgm.
 */
export function normalizeQuestion(q: string): string {
  return q
    .toLowerCase()
    .replace(/[\s ]+/g, " ")
    .replace(/[^a-z0-9 ]+/g, "")
    .trim();
}

/**
 * Find the most-recent matching Question in the org and return its RFP outcome.
 * Looks for an exact text match first (cheap index hit on the equality), then
 * falls back to a case-insensitive prefix match (`startsWith`) — sufficient
 * for the bulk of golden-answer reuse cases without pulling in trigram
 * extensions. Returns null when no candidate is found.
 */
async function lookupOutcomeForQuestion(
  orgId: string,
  questionText: string,
  cache: OutcomeBoostCache | undefined,
  prismaClient: PrismaClient,
): Promise<RfpOutcome | null> {
  const normalised = normalizeQuestion(questionText);
  if (!normalised) return null;

  cache?.__recordCall();

  // Strategy: pull the most recent matching question across the org. We
  // restrict by organizationId via the rfp.project relation. `take: 1` keeps
  // this O(1) regardless of corpus size — the {organizationId, text} lookup
  // is bounded by the index on Question.rfpId joined with the project filter.
  const match = await prismaClient.question.findFirst({
    where: {
      rfp: { project: { organizationId: orgId } },
      // Equality on text — fast and avoids LIKE pattern injection. We
      // intentionally do NOT use mode:"insensitive" here because it forces a
      // sequence scan on most pg setups; the typical case is exact reuse.
      text: questionText,
    },
    select: {
      rfp: { select: { outcome: true } },
    },
    orderBy: { updatedAt: "desc" },
  });
  return match?.rfp.outcome ?? null;
}

/**
 * Same as above but specialised for the LOST case: returns the matched RFP's
 * id + title so the coaching note can name it. Returns null when there's no
 * LOST match.
 */
async function lookupRfpForLostQuestion(
  orgId: string,
  questionText: string,
  cache: OutcomeBoostCache | undefined,
  prismaClient: PrismaClient,
): Promise<{ rfpId: string; rfpTitle: string | null } | null> {
  cache?.__recordCall();

  const match = await prismaClient.question.findFirst({
    where: {
      rfp: {
        project: { organizationId: orgId },
        outcome: "LOST",
      },
      text: questionText,
    },
    select: {
      rfp: { select: { id: true, title: true } },
    },
    orderBy: { updatedAt: "desc" },
  });
  if (!match) return null;
  return { rfpId: match.rfp.id, rfpTitle: match.rfp.title };
}
