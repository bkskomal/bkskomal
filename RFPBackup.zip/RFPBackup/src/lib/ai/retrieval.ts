// Hybrid retrieval: dense (delegated to the per-org VectorStore) + sparse
// (BM25-lite, in JS over Postgres rows) + reciprocal-rank-fusion. Optional
// LLM-based reranker rescoring the top-K for cases where extra quality
// matters (single response generation), skipped for bulk to keep latency low.
//
// The dense path is now backend-agnostic: we ask the org's resolved
// VectorStore for a candidate pool, then fuse with BM25 in process. For the
// default Postgres backend this is numerically identical to the old direct
// cosine-over-Float[] code; for Milvus it pushes the cosine to the cluster.
//
// Native hybrid (Phase V): when the resolved backend `supportsHybrid` (Milvus
// 2.4+ via SPARSE_INVERTED_INDEX), we encode the query as a BM25-style sparse
// vector and let the backend fuse dense+sparse server-side. In that case we
// skip the in-JS BM25 + RRF entirely and use the backend's hits directly.

import { prisma } from "@/lib/prisma";
import { embed } from "./embeddings";
import { encodeSparse } from "./sparse";
import { getAiClients } from "./client";
import { stripCodeFences } from "./json-utils";
import { resolveAiConfig } from "./config";
import { vectorStoreResolver, supportsImages } from "./vector";
import type {
  ImageHit,
  SparseVector,
  VectorSearchFilter,
} from "./vector/types";
import { getClipEmbedder } from "./clip";
import { getCrossEncoder } from "./reranker";
import { fetchExternalRag } from "./external-rag";
import { log } from "@/lib/logger";
import { imageSearchesTotal } from "@/lib/metrics";

export interface RetrievedChunk {
  id: string;
  documentId: string;
  documentName: string;
  fileName: string;
  ordinal: number;
  page: number | null;
  content: string;
  /** 0..1 fused score after RRF (and optional reranking). */
  score: number;
  scoreDense?: number;
  scoreSparse?: number;
  scoreRerank?: number;
  /**
   * Distinguisher for downstream consumers (generate.ts, the response viewer).
   * Defaults to `"text"` for backwards compatibility — image-sourced hits
   * fanned in via the multimodal retrieval mode (Phase IM) carry `"image"`
   * and trigger the [Source N — Image: ...] formatting in the prompt.
   */
  kind?: "text" | "image";
  /**
   * Image-only metadata, populated when `kind === "image"`. Lives at the
   * RetrievedChunk surface so callers don't have to thread a separate result
   * shape through the generation pipeline.
   */
  imagePath?: string;
  caption?: string;
  ocrText?: string;
}

interface SearchOptions {
  topK?: number;
  candidatePool?: number;
  rerank?: boolean;
  /**
   * When true and the resolved backend supports it, pass through to the
   * VectorStore so it can fuse dense+sparse natively. Postgres ignores it;
   * Milvus (V3) honours it. Default false — caller does RRF in JS.
   */
  hybrid?: boolean;
  /** Optional sparse query for backends that do hybrid server-side. */
  sparseQuery?: SparseVector;
  /** Metadata filters threaded through to the VectorStore. */
  filter?: VectorSearchFilter;
  /**
   * Multimodal image retrieval (Phase IM):
   *   "off"   — text retrieval only (default; preserves pre-IM behaviour).
   *   "fuse"  — search images + RRF-fuse with text hits.
   *   "only"  — return ONLY image hits (text retrieval still runs to fill
   *             the candidate pool but its hits are dropped from the
   *             final result).
   * The mode is silently downgraded to "off" when:
   *   - the resolved backend doesn't support images (`supportsImages = false`)
   *   - CLIP fails to load (text retrieval still works)
   */
  imageMode?: "off" | "fuse" | "only";
  /** Max image hits to consider in fusion. Default 5. */
  imageTopK?: number;
}

/** Public alias — keeps the call sites readable in callers that prefer the noun. */
export type RetrievalOpts = SearchOptions;

const DEFAULT_TOPK = 6;
const DEFAULT_POOL = 30;
const DEFAULT_IMAGE_TOPK = 5;

export async function searchIndex(
  indexId: string,
  query: string,
  topKOrOptions: number | SearchOptions = DEFAULT_TOPK,
): Promise<RetrievedChunk[]> {
  const opts: SearchOptions =
    typeof topKOrOptions === "number" ? { topK: topKOrOptions } : topKOrOptions;

  // Look up the org so embeddings + reranker + vector backend all use the
  // right per-org config.
  const index = await prisma.knowledgeIndex.findUnique({
    where: { id: indexId },
    select: { organizationId: true },
  });
  if (!index) return [];
  const orgId = index.organizationId;

  // Phase D: external RAG provider short-circuit. When the org pointed us at
  // an external service (Vectara, Azure, in-house RAG endpoint, etc.) we
  // delegate the entire retrieval step to it — no dense/sparse/RRF/rerank,
  // no contextual augmentation. Falls back to internal on misconfig or fetch
  // failure so a flaky external service can't fully break answer drafting.
  const fullCfg = await resolveAiConfig(orgId);
  if (fullCfg.ragProvider.kind === "EXTERNAL_HTTP" && fullCfg.ragProvider.endpoint) {
    try {
      const externalTopK = (typeof topKOrOptions === "number" ? topKOrOptions : topKOrOptions.topK) ?? fullCfg.retrieval.topK;
      const chunks = await fetchExternalRag({
        query,
        topK: externalTopK,
        indexId,
        orgId,
        endpoint: fullCfg.ragProvider.endpoint,
        apiKey: fullCfg.ragProvider.apiKey,
        extraHeaders: fullCfg.ragProvider.extraHeaders,
      });
      log().info(
        { orgId, indexId, externalTopK, returned: chunks.length, endpoint: fullCfg.ragProvider.endpoint },
        "searchIndex: external RAG used",
      );
      return chunks;
    } catch (err) {
      log().warn(
        { orgId, indexId, err: errSummary(err), endpoint: fullCfg.ragProvider.endpoint },
        "external RAG failed — falling back to internal hybrid retrieval",
      );
      // Fall through to the internal path below.
    }
  }

  // Phase A: per-org retrieval config. Defaults preserve current behavior
  // (HYBRID + LLM rerank + topK=8 + RRF k=60), so this is a pure plumbing
  // change for orgs that haven't customized anything.
  const retrievalCfg = fullCfg.retrieval;
  const topK = opts.topK ?? retrievalCfg.topK;
  // Pool needs to be at least the reranker candidate pool so the reranker
  // actually has things to reorder.
  const pool = opts.candidatePool ?? Math.max(retrievalCfg.rerankerTopK, DEFAULT_POOL);
  // Caller-explicit `rerank: true` enables it; the configured kind (LLM /
  // CROSS_ENCODER) decides which path runs. `kind === "NONE"` always disables.
  const rerank = opts.rerank === true && retrievalCfg.rerankerKind !== "NONE";
  const strategy = retrievalCfg.strategy;
  const rrfK = retrievalCfg.rrfK;

  // Embed the query first so dense + (optional) sparse searches share the cost.
  // (Skipped when SPARSE_ONLY — embed() can be expensive for OpenAI-backed orgs.)
  const queryVec = strategy === "SPARSE_ONLY" ? [] : await embed(query, orgId);

  // Dense path: delegate to the per-org VectorStore. For Postgres this runs
  // the in-process cosine; for Milvus it round-trips to the cluster.
  const store = await vectorStoreResolver.forOrg(orgId);

  // --- Multimodal (Phase IM) ---
  // Kick off image retrieval in parallel with text. We resolve the promise at
  // the end of each return path (hybrid + bm25) and fuse via RRF — that way
  // the image query encode + ANN round-trip overlaps the text dense search
  // round-trip. `imageMode === "off"` (or backend-doesn't-support / CLIP-fail)
  // resolves to an empty list, so the fusion is a no-op in the common case.
  const imageMode = opts.imageMode ?? "off";
  const imageHitsPromise = retrieveImageHits({
    imageMode,
    imageTopK: opts.imageTopK ?? DEFAULT_IMAGE_TOPK,
    orgId,
    indexId,
    query,
    store,
    filter: opts.filter,
  });

  // Native hybrid (Phase V): when the backend supports it, encode the query
  // as a sparse vector once and let the backend fuse server-side. We default
  // hybrid to ON for Milvus-class backends since the cluster pays the BM25
  // cost more efficiently than this process can. Caller can opt out by
  // explicitly passing `hybrid: false`.
  // Server-side hybrid only makes sense for HYBRID strategy. For dense/sparse-only
  // we let the in-JS path handle the single ranking so the strategy gating below
  // applies uniformly.
  const wantsHybrid = strategy === "HYBRID" && opts.hybrid !== false && store.supportsHybrid;
  let sparseQuery: SparseVector | undefined = opts.sparseQuery;
  if (wantsHybrid && !sparseQuery) {
    try {
      sparseQuery = await encodeSparse(query, orgId);
    } catch {
      // Sparse encode is best-effort; on failure fall through to dense-only.
      sparseQuery = undefined;
    }
  }

  // SPARSE_ONLY: skip dense entirely. Otherwise run the configured backend
  // search (which may itself fuse dense+sparse server-side via wantsHybrid).
  const denseHits = strategy === "SPARSE_ONLY"
    ? []
    : await store.search(orgId, indexId, queryVec, {
        topK: pool,
        filter: opts.filter,
        hybrid: wantsHybrid,
        sparseQuery,
      });
  const denseScoreById = new Map(denseHits.map((h) => [h.id, h.score]));
  const denseRanked = denseHits.map((h) => ({ id: h.id, score: h.score }));

  // When the backend already fused dense+sparse, skip the in-JS BM25 step —
  // the backend's scores are already a fusion. We still need to fetch chunk
  // text for the response payload, but only for the hit ids the backend
  // returned (much smaller than scanning the whole index).
  if (wantsHybrid && sparseQuery && denseHits.length > 0) {
    const ids = denseHits.map((h) => h.id);
    const rows = await prisma.documentChunk.findMany({
      where: { id: { in: ids } },
      select: {
        id: true,
        documentId: true,
        ordinal: true,
        page: true,
        content: true,
        document: { select: { name: true, fileName: true } },
      },
    });
    const byId = new Map(rows.map((r) => [r.id, r]));
    const built: RetrievedChunk[] = [];
    for (const h of denseHits) {
      const c = byId.get(h.id);
      if (!c) continue;
      built.push({
        id: c.id,
        documentId: c.documentId,
        documentName: c.document.name,
        fileName: c.document.fileName,
        ordinal: c.ordinal,
        page: c.page,
        content: c.content,
        score: h.score,
        // Backend-fused — we don't have separated dense/sparse subscores.
        scoreDense: h.source === "sparse" ? undefined : h.score,
        scoreSparse: h.source === "dense" ? undefined : h.score,
      });
    }
    let top = built;
    if (rerank && top.length > 1) {
      top = await rerankDispatch(query, top, orgId, retrievalCfg.rerankerKind);
    }
    const imageHits = await imageHitsPromise;
    return fuseTextAndImages(top, imageHits, imageMode, topK);
  }

  // BM25 path: stays in JS over Postgres rows. We need the chunk text anyway
  // for the response payload, and Postgres BM25 isn't worth the extra index.
  // Filtering mirrors the dense path so RRF compares the same candidate set.
  const chunks = await prisma.documentChunk.findMany({
    where: {
      document: {
        indexId,
        status: "INDEXED",
        ...(opts.filter?.documentIds
          ? { id: { in: opts.filter.documentIds } }
          : {}),
      },
      ...(opts.filter?.sections
        ? { section: { in: opts.filter.sections } }
        : {}),
      ...(opts.filter?.kinds ? { kind: { in: opts.filter.kinds } } : {}),
    },
    select: {
      id: true,
      documentId: true,
      ordinal: true,
      page: true,
      content: true,
      document: { select: { name: true, fileName: true } },
    },
  });
  if (chunks.length === 0 && denseHits.length === 0) {
    // No text hits — but image retrieval may still have produced something.
    const imageHits = await imageHitsPromise;
    return fuseTextAndImages([], imageHits, imageMode, topK);
  }

  // Strategy gates the fusion inputs:
  //   HYBRID      → dense + sparse (current behavior)
  //   DENSE_ONLY  → drop the BM25 ranking, fuse just the dense list (no-op fuse)
  //   SPARSE_ONLY → drop the dense ranking, BM25 alone
  const sparseScores = strategy === "DENSE_ONLY" ? new Map<string, number>() : bm25Scores(query, chunks);
  const sparseRanked = strategy === "DENSE_ONLY" ? [] : sortMap(sparseScores).slice(0, pool);
  const fused = rrfFuse(
    strategy === "DENSE_ONLY"
      ? [denseRanked]
      : strategy === "SPARSE_ONLY"
      ? [sparseRanked]
      : [denseRanked, sparseRanked],
    rrfK,
  );

  const byId = new Map(chunks.map((c) => [c.id, c]));
  const built: RetrievedChunk[] = [];
  for (const { id, score } of fused.slice(0, topK * 2)) {
    const c = byId.get(id);
    // A dense-only hit might miss the BM25 chunk fetch (e.g. if the chunk
    // was just removed between the two queries). Skip; we still slice down
    // to topK at the end.
    if (!c) continue;
    built.push({
      id: c.id,
      documentId: c.documentId,
      documentName: c.document.name,
      fileName: c.document.fileName,
      ordinal: c.ordinal,
      page: c.page,
      content: c.content,
      score,
      scoreDense: denseScoreById.get(c.id),
      scoreSparse: sparseScores.get(c.id),
    });
  }
  let top = built;

  if (rerank && top.length > 1) {
    top = await rerankWithLLM(query, top, orgId);
  }

  const imageHits = await imageHitsPromise;
  return fuseTextAndImages(top, imageHits, imageMode, topK);
}

/**
 * Image retrieval (Phase IM). Encodes the query in CLIP text space and
 * issues an ANN search on the per-org VectorStore's image collection.
 *
 * Failure modes return [] (with a warning log + metric bump) so callers
 * never see retrieval blow up because of a missing model:
 *   - imageMode === "off" (caller opted out)
 *   - backend.supportsImages === false
 *   - CLIP failed to load (first run, model download blocked, etc.)
 *   - searchImages threw (already metric'd inside the backend impl)
 */
async function retrieveImageHits(args: {
  imageMode: "off" | "fuse" | "only";
  imageTopK: number;
  orgId: string;
  indexId: string;
  query: string;
  store: Awaited<ReturnType<typeof vectorStoreResolver.forOrg>>;
  filter?: VectorSearchFilter;
}): Promise<RetrievedChunk[]> {
  const { imageMode, imageTopK, orgId, indexId, query, store, filter } = args;
  if (imageMode === "off") return [];
  if (!supportsImages(store)) return [];

  let clipVec: number[];
  try {
    clipVec = await getClipEmbedder().embedTextForImageSearch(query);
  } catch (err) {
    log().warn(
      { err: errSummary(err), orgId, indexId },
      "CLIP text encode failed; skipping image retrieval (text retrieval still active)",
    );
    imageSearchesTotal.inc({ backend: store.id, result: "clip_skip" });
    return [];
  }

  let hits: ImageHit[];
  try {
    hits = await store.searchImages(orgId, indexId, clipVec, {
      topK: imageTopK,
      filter: filter?.documentIds ? { documentIds: filter.documentIds } : undefined,
    });
  } catch (err) {
    log().warn(
      { err: errSummary(err), orgId, indexId },
      "image vector search failed; continuing with text-only retrieval",
    );
    return [];
  }

  return hits.map((h) => ({
    id: h.id,
    documentId: h.documentId ?? "",
    documentName: h.caption ?? h.imagePath ?? "image",
    fileName: h.imagePath ?? "",
    ordinal: 0,
    page: h.page ?? null,
    // Prompt context falls back through OCR → caption → "[image]" so the LLM
    // always has SOMETHING to read; the [Source N — Image: ...] annotation in
    // generate.ts tells it the source is non-textual.
    content: h.ocrText ?? h.caption ?? "[image]",
    score: h.score,
    kind: "image" as const,
    imagePath: h.imagePath,
    caption: h.caption,
    ocrText: h.ocrText,
  }));
}

/**
 * Fuse text + image hits by RRF (k=60). Honours imageMode:
 *   "off"  — image hits ignored (defensive; retrieveImageHits also returns []).
 *   "fuse" — RRF over [text, image] rankings, return topK.
 *   "only" — drop text hits entirely; topK from images alone.
 */
function fuseTextAndImages(
  textHits: RetrievedChunk[],
  imageHits: RetrievedChunk[],
  imageMode: "off" | "fuse" | "only",
  topK: number,
): RetrievedChunk[] {
  if (imageMode === "off" || imageHits.length === 0) {
    // Tag any un-tagged text hit as kind="text" for the response viewer.
    return textHits.map((h) => ({ ...h, kind: h.kind ?? ("text" as const) })).slice(0, topK);
  }
  if (imageMode === "only") {
    return imageHits.slice(0, topK);
  }

  // Fuse: build per-source rankings (already sorted desc by score), RRF in JS.
  const textRanked = textHits.map((h) => ({ id: prefixedId("text", h.id), score: h.score }));
  const imageRanked = imageHits.map((h) => ({ id: prefixedId("image", h.id), score: h.score }));
  const fused = rrfFuse([textRanked, imageRanked]);

  const byId = new Map<string, RetrievedChunk>();
  for (const h of textHits) {
    byId.set(prefixedId("text", h.id), { ...h, kind: h.kind ?? ("text" as const) });
  }
  for (const h of imageHits) {
    byId.set(prefixedId("image", h.id), h);
  }

  const out: RetrievedChunk[] = [];
  for (const { id, score } of fused) {
    const c = byId.get(id);
    if (!c) continue;
    out.push({ ...c, score });
    if (out.length >= topK) break;
  }
  return out;
}

/** RRF id namespacing — text and image ids can collide otherwise (cuids overlap). */
function prefixedId(kind: "text" | "image", id: string): string {
  return `${kind}:${id}`;
}

function errSummary(err: unknown): Record<string, unknown> {
  if (err instanceof Error) return { name: err.name, message: err.message };
  return { value: String(err) };
}

function sortMap(m: Map<string, number>): { id: string; score: number }[] {
  return Array.from(m.entries())
    .map(([id, score]) => ({ id, score }))
    .sort((a, b) => b.score - a.score);
}

function rrfFuse(
  rankings: Array<Array<{ id: string; score: number }>>,
  k = 60,
): Array<{ id: string; score: number }> {
  const fused = new Map<string, number>();
  for (const list of rankings) {
    list.forEach((item, idx) => {
      const prev = fused.get(item.id) ?? 0;
      fused.set(item.id, prev + 1 / (k + idx + 1));
    });
  }
  return sortMap(fused);
}

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "but", "is", "are", "was", "were", "be", "been", "being",
  "of", "to", "in", "on", "at", "by", "for", "with", "as", "from", "that", "this", "it",
  "its", "we", "you", "they", "he", "she", "i", "what", "which", "who", "how", "why",
  "when", "where", "do", "does", "did", "have", "has", "had", "will", "would", "should",
  "can", "could", "may", "might", "shall", "must", "if", "then", "else", "not", "no",
]);

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]+/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 1 && !STOPWORDS.has(t));
}

function bm25Scores(
  query: string,
  chunks: Array<{ id: string; content: string }>,
  k1 = 1.5,
  b = 0.75,
): Map<string, number> {
  const queryTerms = Array.from(new Set(tokenize(query)));
  if (queryTerms.length === 0) return new Map();

  const docTokens = chunks.map((c) => tokenize(c.content));
  const docLengths = docTokens.map((t) => t.length);
  const avgLen = docLengths.reduce((a, b) => a + b, 0) / docLengths.length || 1;
  const N = chunks.length;

  const df = new Map<string, number>();
  for (const t of docTokens) {
    const seen = new Set(t);
    for (const term of seen) df.set(term, (df.get(term) ?? 0) + 1);
  }

  const scores = new Map<string, number>();
  for (let i = 0; i < chunks.length; i++) {
    const tokens = docTokens[i];
    const len = docLengths[i];
    const tf = new Map<string, number>();
    for (const t of tokens) tf.set(t, (tf.get(t) ?? 0) + 1);

    let score = 0;
    for (const term of queryTerms) {
      const f = tf.get(term) ?? 0;
      if (f === 0) continue;
      const n = df.get(term) ?? 0;
      const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
      const numer = f * (k1 + 1);
      const denom = f + k1 * (1 - b + (b * len) / avgLen);
      score += idf * (numer / denom);
    }
    if (score > 0) scores.set(chunks[i].id, score);
  }
  return scores;
}

/**
 * Reranker dispatch. NONE returns the input unchanged; LLM and CROSS_ENCODER
 * route to their respective scorers. A cross-encoder failure (model download
 * blocked, OOM, malformed output) degrades gracefully to LLM rerank so the
 * answer pipeline never breaks because of a reranker hiccup — we just log
 * the fall and move on.
 */
async function rerankDispatch(
  query: string,
  candidates: RetrievedChunk[],
  orgId: string,
  kind: "NONE" | "LLM" | "CROSS_ENCODER",
): Promise<RetrievedChunk[]> {
  if (kind === "NONE") return candidates;
  if (kind === "CROSS_ENCODER") {
    try {
      return await rerankWithCrossEncoder(query, candidates, orgId);
    } catch (err) {
      log().warn(
        { orgId, err: errSummary(err) },
        "cross-encoder rerank failed — falling back to LLM rerank",
      );
      return rerankWithLLM(query, candidates, orgId);
    }
  }
  return rerankWithLLM(query, candidates, orgId);
}

async function rerankWithCrossEncoder(
  query: string,
  candidates: RetrievedChunk[],
  orgId: string,
): Promise<RetrievedChunk[]> {
  if (candidates.length <= 1) return candidates;
  // Resolve config once to get the per-org reranker model id.
  const retrievalCfg = (await resolveAiConfig(orgId)).retrieval;
  const encoder = getCrossEncoder(retrievalCfg.rerankerModel);
  // Score every candidate; the encoder returns indices sorted best→worst.
  const result = await encoder.rerank(
    query,
    candidates.map((c) => c.content),
  );
  // Reassemble candidates in scored order, attaching the rerank score so
  // downstream consumers (generate.ts, viewer) can show it.
  return result.order.map((idx, sortedRank) => ({
    ...candidates[idx]!,
    scoreRerank: result.scores[sortedRank],
  }));
}

async function rerankWithLLM(
  query: string,
  candidates: RetrievedChunk[],
  orgId: string,
): Promise<RetrievedChunk[]> {
  const list = candidates
    .map((c, i) => `[${i}] ${c.content.slice(0, 600)}`)
    .join("\n\n---\n\n");

  try {
    const { llm, config } = await getAiClients(orgId);
    const resp = await llm.chat.completions.create({
      model: config.llm.model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            'You rerank retrieval results by relevance to the user query. Return STRICT JSON: {"order": [int, …]} where the integers are the indices from the candidate list, best-to-worst.',
        },
        {
          role: "user",
          content: `# Query\n${query}\n\n# Candidates (numbered)\n${list}`,
        },
      ],
    });
    const raw = resp.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(stripCodeFences(raw)) as { order?: number[] };
    if (!Array.isArray(parsed.order)) return candidates;
    const seen = new Set<number>();
    const reordered: RetrievedChunk[] = [];
    parsed.order.forEach((idx, rank) => {
      if (typeof idx !== "number" || idx < 0 || idx >= candidates.length || seen.has(idx)) return;
      seen.add(idx);
      const c = { ...candidates[idx] };
      c.scoreRerank = 1 - rank / candidates.length;
      reordered.push(c);
    });
    for (let i = 0; i < candidates.length; i++) {
      if (!seen.has(i)) reordered.push(candidates[i]);
    }
    return reordered;
  } catch {
    return candidates;
  }
}
