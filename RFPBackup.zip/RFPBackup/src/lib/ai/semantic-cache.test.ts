import { describe, expect, it, beforeEach, vi } from "vitest";

// ---------------------------------------------------------------------------
// Mocks. We mock the prisma client (to control cache rows) and the embedder
// (to make the semantic-similarity tier deterministic). Both follow the
// repo-wide hoisted pattern used by outcome-boost / generate tests.
// ---------------------------------------------------------------------------

const { prismaMock, embedMock } = vi.hoisted(() => ({
  prismaMock: {
    cachedAnswer: {
      findFirst: vi.fn(),
      findMany: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
      deleteMany: vi.fn(),
    },
  },
  embedMock: vi.fn(),
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("./embeddings", () => ({
  embed: (...args: unknown[]) => embedMock(...args),
}));

import { _resetEnvCacheForTests } from "@/lib/env";
import {
  cosineSimilarity,
  invalidateCachedAnswer,
  lookupCachedAnswer,
  normalizeQuestion,
  purgeStaleCache,
  questionHash,
  storeCachedAnswer,
} from "./semantic-cache";

const ORG_A = "org-a";
const ORG_B = "org-b";

beforeEach(() => {
  vi.clearAllMocks();
  _resetEnvCacheForTests();
  process.env.SEMANTIC_CACHE_ENABLED = "true";
  // Sensible defaults — individual tests override per case.
  prismaMock.cachedAnswer.findFirst.mockResolvedValue(null);
  prismaMock.cachedAnswer.findMany.mockResolvedValue([]);
  prismaMock.cachedAnswer.create.mockResolvedValue({ id: "new" });
  prismaMock.cachedAnswer.update.mockResolvedValue({ id: "touched" });
  prismaMock.cachedAnswer.delete.mockResolvedValue({ id: "gone" });
  prismaMock.cachedAnswer.deleteMany.mockResolvedValue({ count: 0 });
  embedMock.mockResolvedValue([0, 0, 0]);
});

// ---------------------------------------------------------------------------
// normalizeQuestion + questionHash.
// ---------------------------------------------------------------------------

describe("normalizeQuestion", () => {
  it("lowercases input", () => {
    expect(normalizeQuestion("HELLO World")).toBe("hello world");
  });

  it("collapses runs of whitespace", () => {
    expect(normalizeQuestion("a    b\t\tc\n d")).toBe("a b c d");
  });

  it("strips surrounding punctuation but keeps internal punctuation", () => {
    expect(normalizeQuestion("  ¿What is SOC 2?? ")).toBe("what is soc 2");
    // Internal punctuation is preserved by design — "soc-2" must not collide
    // with "soc2".
    expect(normalizeQuestion("SOC-2 ?")).toBe("soc-2");
  });
});

describe("questionHash", () => {
  it("is stable for the same normalized input", () => {
    const a = questionHash("  What is your SOC 2 certification? ");
    const b = questionHash("what is your soc 2 certification");
    expect(a).toBe(b);
  });

  it("differs across distinct questions", () => {
    expect(questionHash("foo")).not.toBe(questionHash("bar"));
  });

  it("returns a 64-char sha256 hex string", () => {
    expect(questionHash("anything")).toMatch(/^[0-9a-f]{64}$/);
  });
});

// ---------------------------------------------------------------------------
// cosineSimilarity (sanity).
// ---------------------------------------------------------------------------

describe("cosineSimilarity", () => {
  it("returns 1.0 for identical vectors", () => {
    expect(cosineSimilarity([1, 0, 0], [1, 0, 0])).toBeCloseTo(1);
  });

  it("returns 0 for orthogonal vectors", () => {
    expect(cosineSimilarity([1, 0], [0, 1])).toBeCloseTo(0);
  });

  it("returns 0 on mismatched lengths", () => {
    expect(cosineSimilarity([1, 0], [1, 0, 0])).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// lookupCachedAnswer — exact hash tier.
// ---------------------------------------------------------------------------

describe("lookupCachedAnswer — exact hash", () => {
  it("returns the row with similarity 1.0 when the questionHash matches", async () => {
    prismaMock.cachedAnswer.findFirst.mockResolvedValueOnce({
      id: "row-1",
      question: "What is your SOC 2 status?",
      answer: "We are SOC 2 Type II certified.",
      sourcesSnapshot: [{ id: "s1", fileName: "soc2.pdf" }],
      confidence: 0.9,
      groundingScore: 0.85,
    });

    const hit = await lookupCachedAnswer({
      organizationId: ORG_A,
      question: "what is your soc 2 status?",
    });

    expect(hit).not.toBeNull();
    expect(hit!.id).toBe("row-1");
    expect(hit!.similarity).toBe(1.0);
    expect(hit!.answer).toBe("We are SOC 2 Type II certified.");
    expect(hit!.sourcesSnapshot).toHaveLength(1);
    // Did NOT need the embedder — exact tier skips it.
    expect(embedMock).not.toHaveBeenCalled();
    // Did touch the row to bump hits + lastUsedAt.
    expect(prismaMock.cachedAnswer.update).toHaveBeenCalledTimes(1);
    const touchCall = prismaMock.cachedAnswer.update.mock.calls[0][0];
    expect(touchCall.where).toEqual({ id: "row-1" });
    expect(touchCall.data.hits).toEqual({ increment: 1 });
  });
});

// ---------------------------------------------------------------------------
// lookupCachedAnswer — semantic tier.
// ---------------------------------------------------------------------------

describe("lookupCachedAnswer — semantic tier", () => {
  it("returns the closest row when cosine >= threshold", async () => {
    // Two candidates: one orthogonal, one ~identical to the query.
    prismaMock.cachedAnswer.findMany.mockResolvedValueOnce([
      {
        id: "row-far",
        question: "Unrelated",
        answer: "no",
        sourcesSnapshot: [],
        confidence: null,
        groundingScore: null,
        questionEmbedding: [0, 1, 0],
      },
      {
        id: "row-near",
        question: "Describe your encryption posture.",
        answer: "AES-256 at rest, TLS 1.3 in transit.",
        sourcesSnapshot: [{ id: "s1", fileName: "sec.pdf" }],
        confidence: 0.8,
        groundingScore: 0.95,
        questionEmbedding: [1, 0, 0],
      },
    ]);
    // Query embedding aligned with row-near.
    embedMock.mockResolvedValueOnce([1, 0, 0]);

    const hit = await lookupCachedAnswer({
      organizationId: ORG_A,
      question: "What encryption do you use?",
    });

    expect(hit).not.toBeNull();
    expect(hit!.id).toBe("row-near");
    expect(hit!.similarity).toBeCloseTo(1);
    expect(hit!.answer).toContain("AES-256");
  });

  it("returns null when no candidate clears the threshold", async () => {
    prismaMock.cachedAnswer.findMany.mockResolvedValueOnce([
      {
        id: "row-1",
        question: "Other",
        answer: "x",
        sourcesSnapshot: [],
        confidence: null,
        groundingScore: null,
        questionEmbedding: [1, 0, 0],
      },
    ]);
    // Query embedding at ~0.5 cosine to the candidate — below the default
    // 0.92 threshold.
    embedMock.mockResolvedValueOnce([1, 1, 0]);

    const hit = await lookupCachedAnswer({
      organizationId: ORG_A,
      question: "Something different",
    });
    expect(hit).toBeNull();
  });

  it("respects a custom threshold parameter", async () => {
    prismaMock.cachedAnswer.findMany.mockResolvedValueOnce([
      {
        id: "row-1",
        question: "Other",
        answer: "x",
        sourcesSnapshot: [],
        confidence: null,
        groundingScore: null,
        questionEmbedding: [1, 0, 0],
      },
    ]);
    // cosine = 1/sqrt(2) ~= 0.707
    embedMock.mockResolvedValueOnce([1, 1, 0]);

    const hit = await lookupCachedAnswer({
      organizationId: ORG_A,
      question: "Something different",
      threshold: 0.5,
    });
    expect(hit).not.toBeNull();
    expect(hit!.id).toBe("row-1");
  });
});

// ---------------------------------------------------------------------------
// Tenant isolation. Org A's row must never be returned for Org B's lookup.
// ---------------------------------------------------------------------------

describe("lookupCachedAnswer — tenant isolation", () => {
  it("scopes the exact-hash query by organizationId", async () => {
    await lookupCachedAnswer({
      organizationId: ORG_B,
      question: "anything",
    });
    expect(prismaMock.cachedAnswer.findFirst).toHaveBeenCalledTimes(1);
    const whereArg = prismaMock.cachedAnswer.findFirst.mock.calls[0][0].where;
    expect(whereArg.organizationId).toBe(ORG_B);
  });

  it("scopes the semantic candidate fetch by organizationId", async () => {
    await lookupCachedAnswer({
      organizationId: ORG_B,
      question: "anything",
    });
    expect(prismaMock.cachedAnswer.findMany).toHaveBeenCalledTimes(1);
    const whereArg = prismaMock.cachedAnswer.findMany.mock.calls[0][0].where;
    expect(whereArg.organizationId).toBe(ORG_B);
  });
});

// ---------------------------------------------------------------------------
// storeCachedAnswer.
// ---------------------------------------------------------------------------

describe("storeCachedAnswer", () => {
  it("embeds the question and persists the row", async () => {
    embedMock.mockResolvedValueOnce([0.1, 0.2, 0.3]);

    await storeCachedAnswer({
      organizationId: ORG_A,
      question: "What is your RPO?",
      answer: "4 hours.",
      indexId: "idx-1",
      sourcesSnapshot: [{ id: "s1", fileName: "dr.pdf" }],
      confidence: 0.9,
      groundingScore: 0.8,
    });

    expect(embedMock).toHaveBeenCalledTimes(1);
    expect(prismaMock.cachedAnswer.create).toHaveBeenCalledTimes(1);
    const data = prismaMock.cachedAnswer.create.mock.calls[0][0].data;
    expect(data.organizationId).toBe(ORG_A);
    expect(data.question).toBe("What is your RPO?");
    expect(data.answer).toBe("4 hours.");
    expect(data.indexId).toBe("idx-1");
    expect(data.questionEmbedding).toEqual([0.1, 0.2, 0.3]);
    expect(data.questionHash).toBe(questionHash("What is your RPO?"));
    expect(data.confidence).toBe(0.9);
    expect(data.groundingScore).toBe(0.8);
  });

  it("swallows embedder failures (best-effort store)", async () => {
    embedMock.mockRejectedValueOnce(new Error("embed down"));
    await expect(
      storeCachedAnswer({
        organizationId: ORG_A,
        question: "any",
        answer: "any",
        sourcesSnapshot: [],
      }),
    ).resolves.toBeUndefined();
    expect(prismaMock.cachedAnswer.create).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// invalidateCachedAnswer / purgeStaleCache.
// ---------------------------------------------------------------------------

describe("invalidateCachedAnswer", () => {
  it("deletes the row by id", async () => {
    await invalidateCachedAnswer("row-1");
    expect(prismaMock.cachedAnswer.delete).toHaveBeenCalledWith({ where: { id: "row-1" } });
  });

  it("does not throw when the row is already gone", async () => {
    prismaMock.cachedAnswer.delete.mockRejectedValueOnce(new Error("P2025"));
    await expect(invalidateCachedAnswer("missing")).resolves.toBeUndefined();
  });
});

describe("purgeStaleCache", () => {
  it("deletes rows whose lastUsedAt is older than the cutoff", async () => {
    prismaMock.cachedAnswer.deleteMany.mockResolvedValueOnce({ count: 17 });
    const n = await purgeStaleCache(30);
    expect(n).toBe(17);
    const whereArg = prismaMock.cachedAnswer.deleteMany.mock.calls[0][0].where;
    expect(whereArg.lastUsedAt.lt).toBeInstanceOf(Date);
    const cutoff = whereArg.lastUsedAt.lt as Date;
    const expected = Date.now() - 30 * 24 * 60 * 60 * 1000;
    // Allow 1s skew for clock fuzz in CI.
    expect(Math.abs(cutoff.getTime() - expected)).toBeLessThan(1000);
  });

  it("returns 0 for negative windows without touching the DB", async () => {
    const n = await purgeStaleCache(-1);
    expect(n).toBe(0);
    expect(prismaMock.cachedAnswer.deleteMany).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// Env disable flag.
// ---------------------------------------------------------------------------

describe("SEMANTIC_CACHE_ENABLED=false", () => {
  beforeEach(() => {
    process.env.SEMANTIC_CACHE_ENABLED = "false";
    _resetEnvCacheForTests();
  });

  it("makes lookupCachedAnswer a no-op (always null, no DB call)", async () => {
    const hit = await lookupCachedAnswer({
      organizationId: ORG_A,
      question: "anything",
    });
    expect(hit).toBeNull();
    expect(prismaMock.cachedAnswer.findFirst).not.toHaveBeenCalled();
    expect(prismaMock.cachedAnswer.findMany).not.toHaveBeenCalled();
  });

  it("makes storeCachedAnswer a no-op", async () => {
    await storeCachedAnswer({
      organizationId: ORG_A,
      question: "any",
      answer: "any",
      sourcesSnapshot: [],
    });
    expect(prismaMock.cachedAnswer.create).not.toHaveBeenCalled();
  });
});
