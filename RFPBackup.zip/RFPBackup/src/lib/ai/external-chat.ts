// External chat provider (Phase E).
//
// When the org sets chatProvider != INTERNAL, the chat route stops calling
// runChatTurn / runAgenticChatTurn and instead POSTs the user's prompt to a
// remote service. The MVP target is OATI's UserPrompt endpoint:
//
//   POST {endpoint}
//   Headers:
//     Authorization: Bearer {apiKey}   (when set)
//     Content-Type: application/json
//   Body:
//     {
//       "metadata": {
//         "user_id": 0,
//         "organization_id": 0,
//         "user_name": "Alice",
//         "user_timezone": "America/Chicago",
//         "client": "string",
//         "product": "string",
//         "data_source": ["string"],
//         "source": "string",
//         "prompt_id": "<uuid>",
//         "enable_query_analyzer": true,
//         "enable_follow_up": true,
//         "enable_abbreviation": true,
//         "json_stream": false
//       },
//       "prompt": "<user message>",
//       "conversation_id": "<sticky id; empty on first turn>",
//       "stream": false
//     }
//   200 OK:
//     {
//       "response": "string",
//       "references": [{...}],
//       "follow_up_questions": ["string"],
//       "abbreviations": ["string"],
//       "conversation_id": "string"   // we persist this on ChatThread for threading
//     }
//
// Tools + Agent toggles from the chat UI are ignored when external — the
// remote service owns retrieval, tool calls, and the multi-step loop.

import { randomUUID } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { log } from "@/lib/logger";
import { resolveAiConfig, type ResolvedAiConfig } from "./config";
import type { ChatStep } from "./chat";
import type { ChatScope } from "@prisma/client";

const DEFAULT_TIMEOUT_MS = 60_000;

export interface ExternalChatTurnOpts {
  threadId: string;
  userMessage: string;
  organizationId: string;
  scope: ChatScope;
  /** The user driving this turn — name + (optional) numeric mapping for OATI. */
  user: { id: string; name: string | null; email: string | null };
  onStep?: (step: ChatStep) => void;
}

export interface ExternalChatTurnResult {
  assistantMessageId: string;
  content: string;
  metadata: {
    /** Raw upstream payload — UI can render follow-ups, references, etc. */
    external?: {
      references?: unknown[];
      follow_up_questions?: string[];
      abbreviations?: string[];
      conversation_id?: string;
    };
  };
}

interface UserPromptRequest {
  metadata: {
    user_id: number;
    organization_id: number;
    user_name: string;
    user_timezone: string;
    client: string;
    product: string;
    data_source: string[];
    source: string;
    prompt_id: string;
    enable_query_analyzer: boolean;
    enable_follow_up: boolean;
    enable_abbreviation: boolean;
    json_stream: boolean;
  };
  prompt: string;
  conversation_id: string;
  stream: boolean;
}

interface UserPromptResponse {
  response?: string;
  references?: unknown[];
  follow_up_questions?: string[];
  abbreviations?: string[];
  conversation_id?: string;
}

/**
 * Build the request body — merges org-configured defaults with per-turn
 * overrides (user_name from the caller, prompt_id freshly generated).
 */
export function buildUserPromptBody(
  cfg: ResolvedAiConfig["chatProvider"],
  input: {
    prompt: string;
    conversationId: string;
    user: { id: string; name: string | null; email: string | null };
  },
): UserPromptRequest {
  const md = cfg.metadata;
  return {
    metadata: {
      // user_id / organization_id are int in OATI's contract but ours are
      // cuids. Org admin can set a numeric mapping in metadata defaults;
      // otherwise 0 (most installs ignore them anyway).
      user_id: md.user_id ?? 0,
      organization_id: md.organization_id ?? 0,
      user_name:
        md.user_name ?? input.user.name ?? input.user.email ?? "anonymous",
      user_timezone: md.user_timezone ?? "UTC",
      client: md.client ?? "AutoRFP",
      product: md.product ?? "OATI AutoRFP",
      data_source: md.data_source ?? [],
      source: md.source ?? "chat",
      prompt_id: randomUUID(),
      enable_query_analyzer: md.enable_query_analyzer ?? true,
      enable_follow_up: md.enable_follow_up ?? true,
      enable_abbreviation: md.enable_abbreviation ?? true,
      json_stream: md.json_stream ?? false,
    },
    prompt: input.prompt,
    conversation_id: input.conversationId,
    stream: false,
  };
}

/**
 * Drive one chat turn against the external provider.
 *  1. Save the user message immediately (matches runChatTurn — reloads see it).
 *  2. Load the thread's `externalConversationId` (empty string on first turn).
 *  3. POST to the configured endpoint.
 *  4. Save the assistant reply + persist the returned conversation_id back
 *     onto the thread so the next turn threads correctly.
 *  5. Bubble references / follow_ups / abbreviations into metadata.
 */
export async function runExternalChatTurn(
  opts: ExternalChatTurnOpts,
): Promise<ExternalChatTurnResult> {
  const emit = (s: ChatStep) => opts.onStep?.(s);

  // 1) Persist user message.
  await prisma.chatMessage.create({
    data: { threadId: opts.threadId, role: "USER", content: opts.userMessage },
  });

  // 2) Resolve config + load thread's existing conversation_id (if any).
  const cfg = (await resolveAiConfig(opts.organizationId)).chatProvider;
  if (!cfg.endpoint) {
    throw new Error("chatProvider endpoint not configured");
  }
  const thread = await prisma.chatThread.findUnique({
    where: { id: opts.threadId },
    select: { externalConversationId: true },
  });
  const conversationId = thread?.externalConversationId ?? "";

  emit({ step: "thinking", detail: "Calling external chat provider…" });

  // 3) POST.
  const body = buildUserPromptBody(cfg, {
    prompt: opts.userMessage,
    conversationId,
    user: opts.user,
  });

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), DEFAULT_TIMEOUT_MS);
  let parsed: UserPromptResponse;
  try {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (cfg.apiKey) headers["Authorization"] = `Bearer ${cfg.apiKey}`;
    const res = await fetch(cfg.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(
        `External chat HTTP ${res.status}: ${text.slice(0, 240)}`,
      );
    }
    parsed = (await res.json()) as UserPromptResponse;
  } catch (err) {
    clearTimeout(timer);
    const message = err instanceof Error ? err.message : String(err);
    log().error(
      { orgId: opts.organizationId, threadId: opts.threadId, endpoint: cfg.endpoint, err: message },
      "external chat call failed",
    );
    // Save an error-shaped assistant message so the UI shows something.
    const failText = `_External chat provider failed: ${message.slice(0, 200)}._\n\nCheck the endpoint + API key in Settings → Chat Provider.`;
    const failMsg = await prisma.chatMessage.create({
      data: {
        threadId: opts.threadId,
        role: "ASSISTANT",
        content: failText,
        metadata: { external: { error: message } } as never,
      },
    });
    emit({ step: "error", detail: "External chat failed" });
    return {
      assistantMessageId: failMsg.id,
      content: failText,
      metadata: {},
    };
  }
  clearTimeout(timer);

  // 4) Persist assistant message + thread the conversation_id.
  const rawResponse = (parsed.response ?? "").trim();
  // Detect the well-known OATI placeholder error so we can annotate the
  // chat bubble. The pattern is case-insensitive substring — OATI returns
  // exactly "Something went wrong while trying to answer" today, but
  // similar phrasings count too. When matched, we append a short note so
  // the user knows it's the upstream service, not our integration.
  const looksLikeUpstreamError =
    rawResponse.length === 0 ||
    /\b(something went wrong|failed to (generate|answer|respond)|internal (error|server error))\b/i.test(
      rawResponse,
    );

  const content = looksLikeUpstreamError
    ? buildUpstreamErrorMessage(rawResponse, parsed, cfg.endpoint)
    : rawResponse;

  const newConversationId =
    typeof parsed.conversation_id === "string" && parsed.conversation_id.trim()
      ? parsed.conversation_id
      : conversationId;

  const assistantMsg = await prisma.chatMessage.create({
    data: {
      threadId: opts.threadId,
      role: "ASSISTANT",
      content,
      metadata: {
        external: {
          // Raw upstream payload — UI can render follow_up_questions / refs
          // and the debug "View raw response" disclosure.
          rawResponse: parsed,
          references: Array.isArray(parsed.references) ? parsed.references : [],
          follow_up_questions: Array.isArray(parsed.follow_up_questions)
            ? parsed.follow_up_questions
            : [],
          abbreviations: Array.isArray(parsed.abbreviations) ? parsed.abbreviations : [],
          conversation_id: newConversationId,
          upstreamError: looksLikeUpstreamError,
        },
      } as never,
    },
  });

  if (newConversationId !== conversationId) {
    await prisma.chatThread.update({
      where: { id: opts.threadId },
      data: { externalConversationId: newConversationId, updatedAt: new Date() },
    });
  } else {
    await prisma.chatThread.update({
      where: { id: opts.threadId },
      data: { updatedAt: new Date() },
    });
  }

  emit({ step: "done", detail: "Response ready" });

  return {
    assistantMessageId: assistantMsg.id,
    content,
    metadata: {
      external: {
        references: Array.isArray(parsed.references) ? parsed.references : [],
        follow_up_questions: Array.isArray(parsed.follow_up_questions)
          ? parsed.follow_up_questions
          : [],
        abbreviations: Array.isArray(parsed.abbreviations) ? parsed.abbreviations : [],
        conversation_id: newConversationId,
      },
    },
  };
}

/**
 * Build a friendly assistant message body when the upstream service returned
 * a generic error / empty response. Surfaces the raw payload + endpoint so
 * the user knows it's the external service that failed, not our integration.
 * Markdown supported by ChatPanel renderer.
 */
function buildUpstreamErrorMessage(
  rawResponse: string,
  parsed: UserPromptResponse,
  endpoint: string,
): string {
  const lines: string[] = [];
  if (rawResponse) {
    lines.push(`> ${rawResponse}`);
  } else {
    lines.push(`> _(empty response)_`);
  }
  lines.push("");
  lines.push(
    `**The external chat provider returned a generic error.** Your integration is working correctly — the request reached the service and a response came back. The service itself failed to produce an answer.`,
  );
  lines.push("");
  lines.push(`**Endpoint:** \`${endpoint}\``);
  lines.push("");
  lines.push("**What to try:**");
  lines.push("- Check the OATI service logs at the timestamp above");
  lines.push("- In **Settings → Chat Provider → Advanced**, set real numeric `user_id` and `organization_id` (we send 0 by default)");
  lines.push("- Add at least one `data_source` value in the CSV field");
  lines.push("- Click **Test connection** in Settings to retest");
  lines.push("- To bypass while debugging: **Settings → Chat Provider → Reset to internal**");
  lines.push("");
  lines.push("<details><summary>Raw response payload</summary>\n\n```json\n" + JSON.stringify(parsed, null, 2) + "\n```\n</details>");
  return lines.join("\n");
}

/** Best-effort health check for the Settings "Test connection" button. */
export async function pingExternalChat(params: {
  endpoint: string;
  apiKey: string | null;
  /** Optional metadata to send for the test ping. */
  metadata?: Partial<ResolvedAiConfig["chatProvider"]["metadata"]>;
}): Promise<{ ok: boolean; message: string }> {
  const body = buildUserPromptBody(
    {
      kind: "OATI_USER_PROMPT",
      endpoint: params.endpoint,
      apiKey: params.apiKey,
      metadata: params.metadata ?? {},
    },
    {
      prompt: "ping",
      conversationId: "",
      user: { id: "test", name: "ping", email: null },
    },
  );

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15_000);
  try {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (params.apiKey) headers["Authorization"] = `Bearer ${params.apiKey}`;
    const res = await fetch(params.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return { ok: false, message: `HTTP ${res.status}: ${text.slice(0, 240)}` };
    }
    const parsed = (await res.json()) as UserPromptResponse;
    const len = (parsed.response ?? "").length;
    return { ok: true, message: `OK — got ${len}-char response` };
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : String(err) };
  } finally {
    clearTimeout(timer);
  }
}
