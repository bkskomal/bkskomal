import { getAiClients, pickModelForGeneration } from "./client";
import { stripCodeFences } from "./json-utils";
import type { Complexity } from "./router";
import { searchIndex, type RetrievedChunk } from "./retrieval";
import { ANALYSIS_SYSTEM, RESPONSE_GENERATION_SYSTEM } from "./prompts";
import { toolRegistry, type ToolContext } from "./tools/registry";
import "./tools/builtin";
import {
  responsesGeneratedTotal,
  responsesConfidence,
  staleSourceWarningsTotal,
} from "@/lib/metrics";
import { scoreGrounding, type GroundingResult } from "./grounding";
import { log } from "@/lib/logger";
import {
  coachingNoteForGoldenAnswer,
  createOutcomeBoostCache,
  reorderGoldensByOutcome,
} from "./outcome-boost";
import { prisma } from "@/lib/prisma";
import type { RfpDocRole } from "@prisma/client";
import { lookupCachedAnswer, storeCachedAnswer, type CacheHit } from "./semantic-cache";
import { resolveAiConfig } from "./config";

// --- Multi-document RFP package ---
//
// Cap how much attachment text we splice into the prompt. Per attachment we
// truncate to ~1500 chars; we include up to MAX_ATTACHMENTS attachments
// sorted oldest-first. The aim is supplementary context, not exhaustive
// inclusion — past ~6k characters of companion content the prompt becomes
// noise and pushes useful KB excerpts out of the model's attention window.
const MAX_ATTACHMENTS_IN_PROMPT = 4;
const ATTACHMENT_TEXT_BUDGET = 1500;

interface AttachmentSnippet {
  id: string;
  docRole: RfpDocRole;
  fileName: string;
  text: string;
}

/**
 * Resolve the primary RFP for `rfpId` (walks up if `rfpId` is itself an
 * attachment) and return the trimmed attachment context blocks. Best-effort:
 * any DB error returns an empty list — generation must work fine for RFPs
 * with no attachments at all.
 */
async function loadAttachmentContext(rfpId: string | undefined): Promise<AttachmentSnippet[]> {
  if (!rfpId) return [];
  try {
    const rfp = await prisma.rFP.findUnique({
      where: { id: rfpId },
      select: { id: true, parentRfpId: true },
    });
    if (!rfp) return [];
    const primaryId = rfp.parentRfpId ?? rfp.id;
    const attachments = await prisma.rFP.findMany({
      where: { parentRfpId: primaryId },
      orderBy: { createdAt: "asc" },
      take: MAX_ATTACHMENTS_IN_PROMPT,
      select: { id: true, docRole: true, fileName: true, rawText: true },
    });
    const out: AttachmentSnippet[] = [];
    for (const a of attachments) {
      if (!a.rawText) continue;
      const text = a.rawText.slice(0, ATTACHMENT_TEXT_BUDGET).trim();
      if (!text) continue;
      out.push({ id: a.id, docRole: a.docRole, fileName: a.fileName, text });
    }
    return out;
  } catch (err) {
    log().warn(
      { err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) }, rfpId },
      "attachment-context lookup failed; continuing without companion docs",
    );
    return [];
  }
}

function formatAttachmentBlock(attachments: AttachmentSnippet[]): string {
  if (attachments.length === 0) return "";
  const blocks = attachments
    .map((a) => `${a.docRole} (${a.fileName}):\n${a.text}`)
    .join("\n\n---\n\n");
  return `\n# Companion Documents\nThese files were attached to the RFP as supplementary context. Cite them as [Source-{role}] (e.g. [Source-${attachments[0].docRole}]) if you use them.\n\n${blocks}`;
}

export interface ResponseStep {
  step:
    | "analyzing"
    | "searching"
    | "tool_call"
    | "drafting"
    | "complete"
    | "grounding"
    | "error"
    | "routing"
    | "cache_hit"
    | "stale_source";
  detail: string;
  data?: unknown;
}

/**
 * Per-source staleness warning surfaced to the UI alongside the response.
 * Mirrored into `Response.reasoning.staleSourceWarnings` so the response
 * viewer can render a banner without re-fetching documents.
 */
export interface StaleSourceWarning {
  documentId: string;
  fileName: string;
  reason: string;
  sourceDate: string | null;
}

export interface ResponseResult {
  content: string;
  reasoning: ResponseStep[];
  sources: RetrievedChunk[];
  /** 0..1 self-rated confidence in this response. */
  confidence: number;
  /** True if this answer should be flagged for human review. */
  needsReview: boolean;
  /**
   * True when this response was served from the semantic cache instead of
   * being freshly generated. The grounding pass is skipped on cache hits
   * (the cached entry already carries its original grounding score), and
   * `sources` is reconstructed from the snapshot so downstream UI still has
   * something to render. Defaults to false.
   */
  cached?: boolean;
  /** Cosine similarity for the cache hit (1.0 = exact hash). Undefined on misses. */
  cacheSimilarity?: number;
  /**
   * Result of the second-pass LLM-judge grounding check. `null` if the
   * grounding call failed or was skipped (we never let grounding break the
   * primary generation flow).
   */
  grounding: GroundingResult | null;
  /**
   * Stale-source warnings (Tier B2). Non-empty when at least one cited
   * source's underlying Document has `staleReason` set. Surfaced to the UI
   * as a banner above the response; never used to filter sources out.
   */
  staleSourceWarnings: StaleSourceWarning[];
}

/**
 * Threshold below which we override `needsReview` to true regardless of the
 * heuristic confidence score. Picked to match the badge "red" tier in the UI
 * — anything that the LLM judge flags as below 60% grounded should land in
 * the reviewer's queue.
 */
export const GROUNDING_REVIEW_THRESHOLD = 0.6;

/**
 * Heuristic confidence score:
 *   - Source richness: more high-relevance hits → higher confidence
 *   - Hedging language: "we may", "we plan to", "potentially" → lower
 *   - "I don't have information" type disclaimers → much lower
 *   - Length: very short responses (< 60 chars) often fail → lower
 *
 * Cheap and deterministic. The model can be asked to self-rate later, but
 * heuristics catch the obvious failure modes.
 */
function scoreResponse(content: string, sources: RetrievedChunk[]): { confidence: number; needsReview: boolean } {
  let score = 0.5;
  const lower = content.toLowerCase();
  const trimmed = content.trim();

  // Source signal — strongest predictor of grounding.
  const goodSources = sources.filter((s) => s.score > 0.5);
  if (goodSources.length >= 3) score += 0.25;
  else if (goodSources.length === 2) score += 0.15;
  else if (goodSources.length === 1) score += 0.05;
  else score -= 0.1; // no decent sources = uncertain

  // Citations actually used in the output → trust signal.
  if (/\[Source \d+\]/i.test(content)) score += 0.1;

  // Hedging / disclaimer signals.
  if (/i (don'?t|do not) have (enough )?information/i.test(content)) score -= 0.4;
  if (/cannot (find|locate|determine)|insufficient (context|information)/i.test(content)) score -= 0.3;
  if (/\b(may|might|could potentially|we plan to|we intend to|possibly)\b/gi.test(content)) {
    const matches = lower.match(/\b(may|might|could potentially|we plan to|we intend to|possibly)\b/g) ?? [];
    score -= Math.min(0.15, matches.length * 0.03);
  }
  if (/\bdoes not produce a response\b/i.test(content)) score -= 0.5;

  // Length signal.
  if (trimmed.length < 60) score -= 0.2;
  if (trimmed.length > 400) score += 0.05;

  const confidence = Math.max(0, Math.min(1, score));
  const needsReview = confidence < 0.55 || goodSources.length === 0;
  return { confidence, needsReview };
}

interface GenerateOptions {
  question: string;
  indexId: string | null;
  ctx: ToolContext;
  /**
   * Up to ~6 candidate golden answers. We re-rank these in-place by the
   * historical outcome of any RFP that previously asked a similar question
   * (WON floats up, LOST sinks; see lib/ai/outcome-boost.ts) and then take
   * the top 3 for the prompt.
   */
  goldenAnswers?: Array<{ id?: string; question: string; answer: string }>;
  enableTools?: boolean;
  /**
   * Question complexity from the extraction pipeline. Passed to model
   * routing — simple questions can be answered by a cheaper model when the
   * org has enabled per-tier routing. When undefined, routing falls back
   * to the standard `llmModel` regardless of org config.
   */
  complexity?: Complexity;
  /**
   * When true, skip the semantic cache (both lookup and store). Used by
   * the "regenerate from scratch" path so reviewers can force a fresh
   * generation without having to manually invalidate the cached entry.
   */
  disableCache?: boolean;
  onStep?: (step: ResponseStep) => void;
}

export async function generateResponse(opts: GenerateOptions): Promise<ResponseResult> {
  const reasoning: ResponseStep[] = [];
  const emit = (s: ResponseStep) => {
    reasoning.push(s);
    opts.onStep?.(s);
  };

  // Phase A.4: pull per-org generation config (cache toggle + similarity
  // threshold, grounding toggle, pinned model). Single resolver call shared
  // across cache lookup, drafting, and the grounding judge below.
  const genCfg = (await resolveAiConfig(opts.ctx.organizationId)).generation;

  // --- Semantic cache (Phase 3C) — ORDER MATTERS ---
  // Cache lookup runs FIRST, before routing (Agent 3B) and any LLM call. On
  // a hit we short-circuit the entire pipeline: no analysis, no retrieval,
  // no drafting, no grounding. The cached entry already carries the
  // grounding score from the original generation. On a miss we fall through
  // to the full pipeline and store the result at the end.
  if (!opts.disableCache && genCfg.cacheEnabled) {
    try {
      const hit = await lookupCachedAnswer({
        organizationId: opts.ctx.organizationId,
        question: opts.question,
        indexId: opts.indexId,
        threshold: genCfg.cacheSimilarityThreshold,
      });
      if (hit) {
        return buildCachedResult(hit, emit, reasoning);
      }
    } catch (err) {
      // A cache failure must never break generation. Log and proceed.
      log().warn(
        {
          err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
          orgId: opts.ctx.organizationId,
        },
        "cache lookup failed; falling through to fresh generation",
      );
    }
  }

  emit({ step: "analyzing", detail: "Breaking question into search queries…" });

  const { llm } = await getAiClients(opts.ctx.organizationId);

  // --- Model routing (Phase 3B) ---
  // Decide which model to use *before* any chat-completions call. The decision
  // is shared across the analysis pass and the answer-drafting pass so both
  // run on the same tier (avoids paying premium prices for the cheap analysis
  // step on a simple question). For ordering with the semantic cache (Agent
  // 3C): cache lookup happens first, then on miss we route + generate + store.
  // We surface the decision as a SSE `routing` step event so the UI can show
  // which model answered, and log it for ops correlation.
  const routing = await pickModelForGeneration(opts.ctx.organizationId, opts.complexity);
  emit({
    step: "routing",
    detail: `Using ${routing.model} (${routing.reason})`,
    data: {
      model: routing.model,
      reason: routing.reason,
      baseModel: routing.baseModel,
      complexity: opts.complexity ?? null,
      // LoRA / fine-tune adapter (Tier C3). Present only when the org has
      // an adapter configured and reason === "adapter_override". The UI
      // surfaces this so users can confirm *which* fine-tune answered them
      // (base model, train date, train size, free-form notes).
      adapterMeta: routing.adapterMeta ?? null,
    },
  });
  log().info(
    {
      orgId: opts.ctx.organizationId,
      questionId: opts.ctx.questionId,
      complexity: opts.complexity ?? null,
      routedModel: routing.model,
      baseModel: routing.baseModel,
      reason: routing.reason,
    },
    "llm routing decision",
  );

  let analysis: { coreAsk: string; subQuestions: string[]; searchQueries: string[] };
  try {
    const a = await llm.chat.completions.create({
      model: routing.model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: ANALYSIS_SYSTEM },
        { role: "user", content: opts.question },
      ],
    });
    analysis = JSON.parse(stripCodeFences(a.choices[0]?.message?.content ?? "{}"));
  } catch {
    analysis = { coreAsk: opts.question, subQuestions: [], searchQueries: [opts.question] };
  }
  if (!analysis.searchQueries?.length) analysis.searchQueries = [opts.question];

  emit({ step: "analyzing", detail: "Plan ready", data: analysis });

  const allHits = new Map<string, RetrievedChunk>();
  if (opts.indexId) {
    const queries = analysis.searchQueries.slice(0, 4);
    for (let qi = 0; qi < queries.length; qi++) {
      const q = queries[qi];
      emit({ step: "searching", detail: `Searching: "${q}"` });
      // Rerank only on the most-promising query (the first / coreAsk-derived).
      // Skipping rerank on follow-ups keeps latency reasonable without losing
      // much quality.
      const hits = await searchIndex(opts.indexId, q, { topK: 4, rerank: qi === 0 });
      for (const h of hits) {
        const existing = allHits.get(h.id);
        if (!existing || existing.score < h.score) allHits.set(h.id, h);
      }
    }
  } else {
    emit({ step: "searching", detail: "No knowledge index configured — answering from question alone." });
  }

  const sources = Array.from(allHits.values())
    .sort((a, b) => b.score - a.score)
    .slice(0, 8);

  // --- Stale-source detection (Tier B2) ---
  // After retrieval picks the top sources, look up their `staleReason` from
  // the Document table. Non-null reason → the doc is stale; emit a SSE step
  // for the UI and remember the warnings so we can persist them on the
  // response's `reasoning` payload. We do NOT filter stale sources out —
  // they may still be the best evidence available; this surfaces the risk
  // to the human reviewer instead.
  const staleWarnings = await collectStaleSourceWarnings(sources, emit, opts.ctx.organizationId);

  emit({
    step: "drafting",
    detail: `Drafting response from ${sources.length} source${sources.length === 1 ? "" : "s"}…`,
  });

  // Image-vs-text formatting (Phase IM). Image-sourced retrievals get an
  // [Image: <caption|filename>] annotation so the LLM knows the underlying
  // source is non-textual; the OCR/caption text still appears as the body so
  // the model has something to ground on.
  const sourceBlock = sources
    .map((s, i) => {
      const head =
        s.kind === "image"
          ? `[Source ${i + 1} — Image: ${s.caption ?? s.imagePath ?? s.documentName}] (${s.documentName}${
              s.page ? `, p.${s.page}` : ""
            }, score=${s.score.toFixed(2)})`
          : `[Source ${i + 1}] (${s.documentName}${s.page ? `, p.${s.page}` : ""}, score=${s.score.toFixed(2)})`;
      return `${head}\n${s.content}`;
    })
    .join("\n\n---\n\n");

  // Append a short note to the system prompt when the retrieved sources
  // include images — the model needs to know that a `[Source N — Image: ...]`
  // tag is a screenshot/diagram/figure rather than prose. We DON'T modify the
  // standing RESPONSE_GENERATION_SYSTEM string itself; we just add a paragraph
  // for this single call.
  const hasImageSources = sources.some((s) => s.kind === "image");
  const systemPrompt = hasImageSources
    ? `${RESPONSE_GENERATION_SYSTEM}\n\nSome retrieved sources are images (figures, diagrams, screenshots). They appear as [Source N — Image: <caption or path>] with their OCR/caption text. Cite them like any other source if you use them.`
    : RESPONSE_GENERATION_SYSTEM;

  // --- Win/loss feedback loop ---
  // Reorder candidate goldens by the outcome of any past RFP that asked a
  // matching question. WON-derived references float to the top; LOST sink
  // (and surface a coaching note further down). Cache lookups within this
  // single call so we never query the same golden twice. Best-effort: if
  // the lookup fails (e.g. DB hiccup), fall through to the original order.
  const outcomeCache = createOutcomeBoostCache();
  let rankedGoldens: Array<{
    id?: string;
    question: string;
    answer: string;
    outcomeBoost?: number;
  }> = opts.goldenAnswers ?? [];
  if (rankedGoldens.length > 0) {
    try {
      rankedGoldens = await reorderGoldensByOutcome(
        opts.ctx.organizationId,
        rankedGoldens,
        outcomeCache,
      );
    } catch (err) {
      log().warn(
        {
          err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
          orgId: opts.ctx.organizationId,
        },
        "outcome-boost reordering failed; falling back to insertion order",
      );
    }
  }
  const topGoldens = rankedGoldens.slice(0, 3);

  const goldenBlock = topGoldens
    .map(
      (g, i) =>
        `[Reference ${i + 1}]\nQ: ${g.question}\nA: ${g.answer}`,
    )
    .join("\n\n");

  // For any of the top goldens that historically came from a LOST RFP, build
  // a short coaching note. We deliberately scope this to the goldens we are
  // *actually* including in the prompt — surfacing coaching for a golden the
  // model never sees would be confusing. Best-effort; failures are swallowed.
  const coachingNotes: string[] = [];
  for (let i = 0; i < topGoldens.length; i++) {
    const g = topGoldens[i];
    if ((g.outcomeBoost ?? 0) >= 0) continue; // not a LOST-tied reference
    try {
      const note = await coachingNoteForGoldenAnswer(
        opts.ctx.organizationId,
        g,
        outcomeCache,
      );
      if (note) {
        coachingNotes.push(`Reference ${i + 1}: ${note.note}`);
      }
    } catch {
      // ignore — coaching notes are an enhancement, not a requirement
    }
  }
  const coachingBlock = coachingNotes.length
    ? `\n# Coaching Notes (prior LOST submissions)\n${coachingNotes.join("\n")}`
    : "";

  // Splice in any companion docs attached to this RFP (security questionnaire,
  // addendum, pricing matrix, …). Cheap DB lookup; safe no-op when there are
  // none. Lives on the user prompt so it's part of the context, not the
  // standing system instructions.
  const attachmentSnippets = await loadAttachmentContext(opts.ctx.rfpId);
  const attachmentBlock = formatAttachmentBlock(attachmentSnippets);

  const userPrompt = [
    `# RFP Question`,
    opts.question,
    sourceBlock ? `\n# Knowledge Base Excerpts\n${sourceBlock}` : "",
    goldenBlock ? `\n# Reference Past Responses (style/format guidance)\n${goldenBlock}` : "",
    coachingBlock,
    attachmentBlock,
    `\n# Your Response`,
    `Answer the question above using the excerpts. Cite sources inline as [Source N]. Cite companion documents as [Source-{role}] (e.g. [Source-ADDENDUM]).`,
  ]
    .filter(Boolean)
    .join("\n");

  // For one-shot answer drafting, expose the full RFP toolset filtered by the
  // org's ToolConfig — admins can disable individual tools they don't want
  // the model to call. The model picks which to invoke.
  const tools = opts.enableTools
    ? await toolRegistry.toOpenAIToolsForOrg(opts.ctx.organizationId)
    : undefined;

  const messages: any[] = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt },
  ];

  // Tool-call loop (max 3 turns to keep latency bounded).
  let finalContent = "";
  for (let turn = 0; turn < 3; turn++) {
    const completion = await llm.chat.completions.create({
      // Routed model — see the routing block above. Same tier used for the
      // analysis pass so we don't mix premium and cheap calls within one
      // request.
      model: routing.model,
      temperature: 0.2,
      messages,
      tools,
      tool_choice: tools ? "auto" : undefined,
    });
    const msg = completion.choices[0]?.message;
    if (!msg) break;

    if (msg.tool_calls?.length) {
      messages.push(msg);
      for (const call of msg.tool_calls) {
        emit({
          step: "tool_call",
          detail: `Tool: ${call.function.name}`,
          data: { args: call.function.arguments },
        });
        let result: unknown;
        try {
          result = await toolRegistry.invoke(call.function.name, call.function.arguments, opts.ctx);
        } catch (e) {
          result = { error: e instanceof Error ? e.message : String(e) };
        }
        messages.push({
          role: "tool",
          tool_call_id: call.id,
          content: JSON.stringify(result),
        });
      }
      continue;
    }

    finalContent = msg.content ?? "";
    break;
  }

  emit({ step: "complete", detail: "Response ready" });

  const finalText = finalContent.trim() || "_The model did not produce a response. Try regenerating._";
  const { confidence, needsReview: heuristicNeedsReview } = scoreResponse(finalText, sources);

  responsesGeneratedTotal.inc({ org: opts.ctx.organizationId });
  responsesConfidence.observe({ org: opts.ctx.organizationId }, confidence);

  // Second-pass grounding judge. Wrapped in try/catch — a grounding failure
  // must NEVER fail the primary generation flow. The metric inside
  // scoreGrounding is observed there too, so a thrown exception here only
  // means we couldn't get a result back at all. Phase A.4: per-org toggle —
  // when disabled, skip the judge entirely (saves one LLM call per answer)
  // and fall back to the heuristic confidence score for needsReview.
  let grounding: GroundingResult | null = null;
  if (genCfg.groundingEnabled) try {
    grounding = await scoreGrounding({
      content: finalText,
      sources: sources.map((s) => ({
        id: s.id,
        content: s.content,
        fileName: s.documentName,
        page: s.page ?? null,
      })),
      organizationId: opts.ctx.organizationId,
    });
    emit({
      step: "grounding",
      detail: `Grounding ${(grounding.score * 100).toFixed(0)}% (${grounding.claims.length} claim${
        grounding.claims.length === 1 ? "" : "s"
      })`,
      data: {
        score: grounding.score,
        claims: grounding.claims,
        judgeModel: grounding.judgeModel,
        ms: grounding.ms,
      },
    });
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        orgId: opts.ctx.organizationId,
      },
      "grounding scoring failed",
    );
  }

  // needsReview decision matrix, in order of authority:
  //   1. Stale sources → always flag (an answer built on a stale SOC2 belongs
  //      in front of a human regardless of how confident the prose looks).
  //   2. Grounding judge available → it's the authoritative signal. The
  //      judge directly checks each claim against the cited sources, so a
  //      good grounding score (≥ 0.6) overrides the heuristic. The heuristic
  //      over-flags short factual answers ("Yes, SOC 2 Type II certified") —
  //      we don't want a perfectly grounded one-liner to land in the review
  //      queue just because it's short.
  //   3. No grounding signal → fall back to the heuristic.
  if (staleWarnings.length > 0) {
    staleSourceWarningsTotal.inc({ org: opts.ctx.organizationId });
  }
  const needsReview =
    staleWarnings.length > 0 ||
    (grounding != null
      ? grounding.score < GROUNDING_REVIEW_THRESHOLD
      : heuristicNeedsReview);

  // Persist the (question, answer) pair for future cache lookups. Best-effort
  // — failures are logged inside storeCachedAnswer. We only cache when the
  // caller didn't ask us to skip it AND the answer isn't the model-failure
  // placeholder (no value in caching "the model did not produce a response").
  if (!opts.disableCache && genCfg.cacheEnabled && finalContent.trim()) {
    void storeCachedAnswer({
      organizationId: opts.ctx.organizationId,
      question: opts.question,
      indexId: opts.indexId,
      answer: finalText,
      sourcesSnapshot: sources.map((s) => ({
        id: s.id,
        fileName: s.documentName,
        page: s.page ?? null,
        score: s.score,
      })),
      confidence,
      groundingScore: grounding?.score,
    });
  }

  return {
    content: finalText,
    reasoning,
    sources,
    confidence,
    needsReview,
    grounding,
    staleSourceWarnings: staleWarnings,
  };
}

/**
 * Resolve the per-source `staleReason` from the Document table and emit a
 * SSE step for each stale doc. Returns the assembled warnings — never
 * throws (any DB error returns []), and an empty list means "no stale
 * sources" so callers can branch on `.length > 0`.
 *
 * Why this exists as its own helper: the RetrievedChunk doesn't carry the
 * Document's staleReason (retrieval only loads `name`+`fileName` to keep
 * the query narrow). One indexed query covers any number of sources, so
 * this is cheap even with rerank-expanded candidate pools.
 */
async function collectStaleSourceWarnings(
  sources: RetrievedChunk[],
  emit: (s: ResponseStep) => void,
  orgId: string,
): Promise<StaleSourceWarning[]> {
  if (sources.length === 0) return [];
  const docIds = Array.from(new Set(sources.map((s) => s.documentId).filter(Boolean)));
  if (docIds.length === 0) return [];
  try {
    const docs = await prisma.document.findMany({
      where: { id: { in: docIds } },
      select: { id: true, fileName: true, sourceDate: true, staleReason: true },
    });
    const warnings: StaleSourceWarning[] = [];
    for (const d of docs) {
      if (!d.staleReason) continue;
      const w: StaleSourceWarning = {
        documentId: d.id,
        fileName: d.fileName,
        reason: d.staleReason,
        sourceDate: d.sourceDate ? d.sourceDate.toISOString() : null,
      };
      warnings.push(w);
      emit({
        step: "stale_source",
        detail: `${d.fileName}: ${d.staleReason}`,
        data: w,
      });
    }
    return warnings;
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        orgId,
        docIds,
      },
      "stale-source lookup failed; continuing without warnings",
    );
    return [];
  }
}

/**
 * Build a `ResponseResult` from a cache hit. We reconstruct `sources` from
 * the snapshot so downstream code (UI, response.sources DB rows) still has
 * something to render — but the chunks themselves are no longer in memory,
 * so `content` is the stored excerpt rather than the live KB row. The
 * grounding object is null on cache hits; the cached `groundingScore` is
 * surfaced via the response row's `groundingScore` column on persist (see
 * the generate route) so the UI's grounding badge still works.
 */
function buildCachedResult(
  hit: CacheHit,
  emit: (s: ResponseStep) => void,
  reasoning: ResponseStep[],
): ResponseResult {
  emit({
    step: "cache_hit",
    detail: `Cache hit (similarity ${(hit.similarity * 100).toFixed(1)}%)`,
    data: {
      cachedAnswerId: hit.id,
      similarity: hit.similarity,
      matchedQuestion: hit.question,
    },
  });
  emit({ step: "complete", detail: "Response served from cache" });

  // Snapshot is `[{ id, fileName, page, score }]` from storeCachedAnswer. We
  // re-hydrate it into the RetrievedChunk shape so downstream code is
  // agnostic to whether the answer came from cache or fresh generation.
  // `content` is left empty — we no longer have the original chunk text,
  // but the snapshot carries enough metadata (fileName, page) for the UI
  // to render citation chips.
  const sources: RetrievedChunk[] = (hit.sourcesSnapshot as Array<{
    id?: string;
    fileName?: string;
    page?: number | null;
    score?: number;
  }>)
    .filter((s) => s && typeof s === "object")
    .map((s) => ({
      id: String(s.id ?? ""),
      documentId: "",
      documentName: String(s.fileName ?? ""),
      fileName: String(s.fileName ?? ""),
      ordinal: 0,
      content: "",
      score: typeof s.score === "number" ? s.score : 0,
      page: typeof s.page === "number" ? s.page : null,
    }));

  const heuristicNeedsReview = (hit.confidence ?? 1) < 0.55;

  return {
    content: hit.answer,
    reasoning,
    sources,
    confidence: hit.confidence ?? 0.8,
    needsReview: heuristicNeedsReview,
    grounding: null,
    cached: true,
    cacheSimilarity: hit.similarity,
    // Cache hits skip the staleness check — the cached entry was scored when
    // it was originally generated, and the snapshot doesn't carry the doc
    // IDs needed to re-resolve staleReason. Treat as "no warnings" for the
    // shape's sake; the next non-cached generation will re-flag.
    staleSourceWarnings: [],
  };
}
