// In-process embedding via transformers.js — runs a small sentence-encoder
// model entirely inside the Node server. First call downloads & caches the
// model (~25MB for all-MiniLM-L6-v2). No external server required.
//
// Activated when the org's EMBEDDING_BASE_URL starts with `local://`. The
// model name comes from the configured `EMBEDDING_MODEL` (the part after
// `local://transformers/` is treated as a Hugging Face repo id).
//
// Falls back to WASM if onnxruntime-node native binaries aren't installed —
// slower but works on any machine.

import { EmbeddingError } from "@/lib/errors";

const LOCAL_PREFIX = "local://";

let pipelinePromise: Promise<any> | null = null;
let cachedModel: string | null = null;

export function isLocalEmbeddingUrl(baseUrl: string | undefined | null): boolean {
  return Boolean(baseUrl && baseUrl.startsWith(LOCAL_PREFIX));
}

/**
 * Default model when a user picks "Local" without specifying one.
 * 384-dim, ~25MB, multilingual-light. Best balance of size/quality for in-proc.
 */
export const DEFAULT_LOCAL_MODEL = "Xenova/all-MiniLM-L6-v2";
export const DEFAULT_LOCAL_DIMENSIONS = 384;

async function getPipeline(modelName: string): Promise<any> {
  if (pipelinePromise && cachedModel === modelName) return pipelinePromise;
  cachedModel = modelName;
  pipelinePromise = (async () => {
    // Dynamic import so the dep isn't loaded unless local embeddings are used.
    const { pipeline, env } = await import("@huggingface/transformers");
    // Cache model files under node_modules/.cache to survive dev restarts.
    env.cacheDir = "./node_modules/.cache/transformers";
    env.allowLocalModels = true;
    return pipeline("feature-extraction", modelName);
  })();
  try {
    return await pipelinePromise;
  } catch (e) {
    // Reset so the next call retries the load.
    pipelinePromise = null;
    cachedModel = null;
    throw e;
  }
}

export async function embedLocal(text: string, model: string): Promise<number[]> {
  // Strip the protocol prefix if it leaked through ("local://transformers" etc.)
  const cleanModel = model.includes("://") ? model.split("://").slice(-1)[0] : model;
  const repoId =
    cleanModel === "" || cleanModel === "transformers" ? DEFAULT_LOCAL_MODEL : cleanModel;

  try {
    const extractor = await getPipeline(repoId);
    // Mean-pool + normalize → standard sentence-embedding shape.
    const output = await extractor(text, { pooling: "mean", normalize: true });
    // output.data is a Float32Array for single inputs.
    return Array.from(output.data as Float32Array);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    throw new EmbeddingError(`local embedding (${repoId}): ${msg}`);
  }
}
