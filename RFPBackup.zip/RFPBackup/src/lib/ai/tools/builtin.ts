// Built-in tools the LLM can call mid-answer. Each is registered with the
// global tool registry; the registry serializes them to the OpenAI tools spec
// so any compatible model can invoke them. Tools are org-scoped — they read
// ctx.organizationId and never cross tenants.

import { readFile } from "node:fs/promises";
import { prisma } from "@/lib/prisma";
import { searchIndex } from "@/lib/ai/retrieval";
import { processRfp } from "@/lib/rfp-pipeline";
import { createRunForRfp } from "@/lib/pipeline/engine";
import { saveUpload } from "@/lib/storage";
import { logActivity } from "@/lib/activity";
import { toolRegistry, z } from "./registry";

// ---------- Existing tools ----------

toolRegistry.register({
  name: "search_knowledge_base",
  description:
    "Semantic search over the organization's knowledge base. Returns the most relevant document excerpts for a natural-language query.",
  schema: z.object({
    query: z.string().min(1).describe("Natural-language search query"),
    indexId: z.string().optional().describe("Knowledge index to search; defaults to the project's default index"),
    topK: z.number().int().min(1).max(15).optional().describe("Number of results"),
  }),
  async execute({ query, indexId, topK }, ctx) {
    const target = indexId ?? ctx.defaultIndexId;
    if (!target) return { results: [], note: "No index configured for this project." };
    const hits = await searchIndex(target, query, topK ?? 6);
    return {
      results: hits.map((h) => ({
        documentName: h.documentName,
        page: h.page,
        score: Number(h.score.toFixed(3)),
        excerpt: h.content,
      })),
    };
  },
});

toolRegistry.register({
  name: "list_indexes",
  description: "List all knowledge indexes available in the current organization.",
  schema: z.object({}),
  async execute(_input, ctx) {
    const indexes = await prisma.knowledgeIndex.findMany({
      where: { organizationId: ctx.organizationId },
      select: {
        id: true,
        name: true,
        description: true,
        _count: { select: { documents: true } },
      },
    });
    return {
      indexes: indexes.map((i) => ({
        id: i.id,
        name: i.name,
        description: i.description,
        documentCount: i._count.documents,
      })),
    };
  },
});

toolRegistry.register({
  name: "calculator",
  description: "Evaluate an arithmetic expression. Supports + - * / parentheses and ^ exponent.",
  schema: z.object({
    expression: z.string().describe("e.g. '(12 * 3) + 4 / 2'"),
  }),
  async execute({ expression }) {
    const sanitized = expression.replace(/\^/g, "**");
    if (!/^[\d+\-*/().\s*]+$/.test(sanitized)) {
      throw new Error("Expression contains disallowed characters");
    }
    // eslint-disable-next-line no-new-func
    const result = Function(`"use strict"; return (${sanitized});`)();
    return { result };
  },
});

// ---------- RFP-specific tools ----------

toolRegistry.register({
  name: "search_golden_answers",
  description:
    "Search the organization's curated Golden Answers — vetted Q&A pairs the team has explicitly marked as canonical. Use this before falling back to raw knowledge-base search; golden answers are higher-trust.",
  schema: z.object({
    query: z.string().min(1).describe("Question or topic to find a vetted answer for"),
    topK: z.number().int().min(1).max(10).optional(),
  }),
  async execute({ query, topK }, ctx) {
    const all = await prisma.goldenAnswer.findMany({
      where: { organizationId: ctx.organizationId },
      orderBy: { updatedAt: "desc" },
    });
    if (all.length === 0) return { results: [], note: "No golden answers configured for this organization." };

    // Score by simple keyword overlap — sufficient for small libraries (<200
    // golden answers). For larger libraries, embed at write-time and do
    // vector search; the surface is the same.
    const qTokens = tokenize(query);
    if (qTokens.length === 0) return { results: all.slice(0, topK ?? 5).map(toGoldenView) };
    const scored = all
      .map((g) => {
        const docTokens = new Set([...tokenize(g.question), ...tokenize(g.answer)]);
        const overlap = qTokens.filter((t) => docTokens.has(t)).length;
        return { g, score: overlap / Math.max(qTokens.length, 1) };
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK ?? 5);

    return {
      results: scored.map(({ g, score }) => ({
        ...toGoldenView(g),
        score: Number(score.toFixed(3)),
      })),
    };
  },
});

toolRegistry.register({
  name: "find_similar_past_responses",
  description:
    "Search APPROVED responses on past RFPs in this organization for questions semantically similar to the given query. Use this to reuse what we've already polished — it's the strongest signal for response quality.",
  schema: z.object({
    query: z.string().min(1).describe("Question text or topic"),
    topK: z.number().int().min(1).max(8).optional(),
  }),
  async execute({ query, topK }, ctx) {
    // Hybrid: prefer APPROVED, otherwise fall back to any COMPLETED response.
    const candidates = await prisma.response.findMany({
      where: {
        question: {
          rfp: { project: { organizationId: ctx.organizationId } },
          status: "APPROVED",
          ...(ctx.questionId ? { NOT: { id: ctx.questionId } } : {}),
        },
        status: "COMPLETED",
      },
      orderBy: { updatedAt: "desc" },
      take: 80,
      include: {
        question: {
          select: {
            id: true,
            text: true,
            section: true,
            number: true,
            rfp: { select: { title: true } },
          },
        },
      },
    });
    if (candidates.length === 0) return { results: [], note: "No approved past responses yet." };

    const qTokens = tokenize(query);
    const scored = candidates
      .map((r) => {
        const text = `${r.question.text} ${r.content}`;
        const docTokens = new Set(tokenize(text));
        const overlap = qTokens.filter((t) => docTokens.has(t)).length;
        return { r, score: overlap / Math.max(qTokens.length, 1) };
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK ?? 4);

    return {
      results: scored.map(({ r, score }) => ({
        rfpTitle: r.question.rfp.title,
        section: r.question.section,
        questionNumber: r.question.number,
        question: r.question.text,
        answer: r.content,
        confidence: r.confidence,
        score: Number(score.toFixed(3)),
      })),
    };
  },
});

toolRegistry.register({
  name: "get_rfp_context",
  description:
    "Return high-level context about the current RFP: title, project, total questions, status breakdown, due date, and section list. Call this first when you need to orient yourself.",
  schema: z.object({}),
  async execute(_input, ctx) {
    if (!ctx.rfpId) return { note: "No RFP in context for this request." };
    const rfp = await prisma.rFP.findUnique({
      where: { id: ctx.rfpId },
      include: {
        project: { select: { name: true } },
        questions: {
          select: { status: true, section: true, assigneeId: true, confidence: true, dueDate: true },
        },
      },
    });
    if (!rfp || rfp.project == null) return { note: "RFP not found." };

    const statusCounts: Record<string, number> = {};
    const sections = new Set<string>();
    let assigned = 0;
    let withResponse = 0;
    for (const q of rfp.questions) {
      statusCounts[q.status] = (statusCounts[q.status] ?? 0) + 1;
      if (q.section) sections.add(q.section);
      if (q.assigneeId) assigned++;
      if (q.confidence != null) withResponse++;
    }

    return {
      title: rfp.title,
      project: rfp.project.name,
      dueDate: rfp.dueDate?.toISOString() ?? null,
      totalQuestions: rfp.questions.length,
      statusCounts,
      assignedCount: assigned,
      generatedCount: withResponse,
      sections: Array.from(sections).sort(),
    };
  },
});

toolRegistry.register({
  name: "list_rfp_questions",
  description:
    "List questions on the current RFP. Filter by section, status, or assignee. Returns up to 50 results.",
  schema: z.object({
    section: z.string().optional().describe("Exact section name to filter by"),
    status: z
      .enum(["TODO", "IN_PROGRESS", "IN_REVIEW", "APPROVED"])
      .optional(),
    onlyUnanswered: z.boolean().optional().describe("If true, return only questions without a COMPLETED response"),
    limit: z.number().int().min(1).max(50).optional(),
  }),
  async execute({ section, status, onlyUnanswered, limit }, ctx) {
    if (!ctx.rfpId) return { questions: [], note: "No RFP in context." };
    const questions = await prisma.question.findMany({
      where: {
        rfpId: ctx.rfpId,
        ...(section ? { section } : {}),
        ...(status ? { status } : {}),
        ...(onlyUnanswered
          ? { NOT: { responses: { some: { status: "COMPLETED" } } } }
          : {}),
      },
      orderBy: { number: "asc" },
      take: limit ?? 25,
      select: {
        id: true,
        number: true,
        section: true,
        text: true,
        status: true,
        confidence: true,
        assignee: { select: { name: true, email: true } },
      },
    });
    return {
      questions: questions.map((q) => ({
        number: q.number,
        section: q.section,
        text: q.text,
        status: q.status,
        confidence: q.confidence,
        assignee: q.assignee ? (q.assignee.name ?? q.assignee.email) : null,
      })),
    };
  },
});

toolRegistry.register({
  name: "get_question_detail",
  description:
    "Fetch a single RFP question by its number, including any latest response, sources, and comment summary.",
  schema: z.object({
    questionNumber: z.number().int().describe("The question's display number on this RFP"),
  }),
  async execute({ questionNumber }, ctx) {
    if (!ctx.rfpId) return { note: "No RFP in context." };
    const q = await prisma.question.findFirst({
      where: { rfpId: ctx.rfpId, number: questionNumber },
      include: {
        responses: {
          where: { status: "COMPLETED" },
          orderBy: { createdAt: "desc" },
          take: 1,
          include: { sources: true },
        },
        comments: {
          orderBy: { createdAt: "asc" },
          take: 10,
          include: { author: { select: { name: true, email: true } } },
        },
        assignee: { select: { name: true, email: true } },
      },
    });
    if (!q) return { note: `No question with number ${questionNumber} on this RFP.` };
    const latest = q.responses[0];
    return {
      number: q.number,
      section: q.section,
      text: q.text,
      status: q.status,
      assignee: q.assignee ? (q.assignee.name ?? q.assignee.email) : null,
      response: latest
        ? {
            content: latest.content,
            confidence: latest.confidence,
            needsReview: latest.needsReview,
            sourceCount: latest.sources.length,
          }
        : null,
      comments: q.comments.map((c) => ({
        author: c.author.name ?? c.author.email,
        body: c.body,
        at: c.createdAt.toISOString(),
      })),
    };
  },
});

toolRegistry.register({
  name: "days_until",
  description:
    "Compute the time remaining from now until a date. Useful for deadline math (e.g. 'how many days until this RFP is due?').",
  schema: z.object({
    targetDate: z.string().describe("ISO date or datetime, e.g. '2026-08-15' or '2026-08-15T17:00:00Z'"),
  }),
  async execute({ targetDate }) {
    const t = new Date(targetDate);
    if (Number.isNaN(t.getTime())) throw new Error("Invalid date");
    const now = new Date();
    const ms = t.getTime() - now.getTime();
    const days = Math.floor(ms / 86_400_000);
    const hours = Math.floor((ms % 86_400_000) / 3_600_000);
    const minutes = Math.floor((ms % 3_600_000) / 60_000);
    return {
      targetDate: t.toISOString(),
      now: now.toISOString(),
      isPast: ms < 0,
      totalHours: Math.round(ms / 3_600_000),
      totalDays: Math.round(ms / 86_400_000),
      breakdown: { days, hours, minutes },
      friendly: friendlyDelta(ms),
    };
  },
});

toolRegistry.register({
  name: "word_count",
  description:
    "Count words and characters in a text. Use to verify a draft answer fits an RFP's length constraint (e.g. 'answer in 250 words or less').",
  schema: z.object({
    text: z.string(),
  }),
  async execute({ text }) {
    const words = (text.trim().match(/\S+/g) ?? []).length;
    const chars = text.length;
    const charsNoSpace = text.replace(/\s/g, "").length;
    return { words, characters: chars, charactersNoSpaces: charsNoSpace };
  },
});

toolRegistry.register({
  name: "list_documents",
  description:
    "List documents in a knowledge index (or all org indexes if none specified). Use this to learn what evidence exists before drafting an answer.",
  schema: z.object({
    indexId: z.string().optional(),
    limit: z.number().int().min(1).max(50).optional(),
  }),
  async execute({ indexId, limit }, ctx) {
    const where = indexId
      ? { indexId, index: { organizationId: ctx.organizationId } }
      : { index: { organizationId: ctx.organizationId } };
    const docs = await prisma.document.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      take: limit ?? 25,
      select: {
        id: true,
        name: true,
        fileName: true,
        status: true,
        index: { select: { name: true } },
        _count: { select: { chunks: true } },
      },
    });
    return {
      documents: docs.map((d) => ({
        name: d.name,
        fileName: d.fileName,
        index: d.index.name,
        status: d.status,
        chunkCount: d._count.chunks,
      })),
    };
  },
});

// ---------- Workflow tools (chat can drive the system) ----------

toolRegistry.register({
  name: "create_knowledge_index",
  description:
    "Create a new knowledge base (vector index) in the current organization. Use when the user asks to set up a new KB.",
  schema: z.object({
    name: z.string().min(2).max(80).describe("Display name for the new KB"),
    description: z.string().max(500).optional(),
  }),
  async execute({ name, description }, ctx) {
    const index = await prisma.knowledgeIndex.create({
      data: { name, description: description ?? null, organizationId: ctx.organizationId },
      select: { id: true, name: true },
    });
    return { ok: true, indexId: index.id, name: index.name };
  },
});

toolRegistry.register({
  name: "start_rfp_process",
  description:
    "Convert an already-uploaded document into a new RFP and kick off the full processing pipeline " +
    "(question extraction → response generation → grounding). The document must already exist as a " +
    "Document row (typically uploaded via the chat attach button or the KB UI). " +
    "If no project is specified, the document is attached to a default 'Chat RFPs' project " +
    "(auto-created on first use).",
  schema: z.object({
    documentId: z
      .string()
      .describe("ID of the Document to treat as the RFP source. The most recent chat upload is usually correct."),
    title: z.string().max(200).optional().describe("Optional title; defaults to the file name."),
    projectName: z
      .string()
      .max(80)
      .optional()
      .describe("Project to attach the RFP to. Auto-created if it doesn't exist; defaults to 'Chat RFPs'."),
  }),
  async execute({ documentId, title, projectName }, ctx) {
    // Look up the document and confirm it belongs to this org.
    const doc = await prisma.document.findUnique({
      where: { id: documentId },
      include: { index: { select: { organizationId: true } } },
    });
    if (!doc) return { ok: false, error: `Document ${documentId} not found.` };
    if (doc.index.organizationId !== ctx.organizationId) {
      return { ok: false, error: "Document belongs to a different organization." };
    }

    // Resolve / auto-create project. We pick the user's preferred name when
    // supplied; otherwise the conventional "Chat RFPs" bucket.
    const targetName = projectName?.trim() || "Chat RFPs";
    let project = await prisma.project.findFirst({
      where: { organizationId: ctx.organizationId, name: targetName },
      select: { id: true, name: true },
    });
    if (!project) {
      project = await prisma.project.create({
        data: {
          organizationId: ctx.organizationId,
          name: targetName,
          description:
            targetName === "Chat RFPs"
              ? "Auto-created project for RFPs started from the chat assistant."
              : null,
        },
        select: { id: true, name: true },
      });
    }

    // Read the file bytes back so the RFP gets its own copy (the document
    // stays in the KB). This keeps the existing RFP pipeline contract
    // unchanged (it reads from storagePath).
    let buf: Buffer;
    try {
      buf = await readFile(doc.storagePath);
    } catch (e) {
      return {
        ok: false,
        error: `Could not read document bytes: ${e instanceof Error ? e.message : String(e)}`,
      };
    }
    const { storagePath: rfpStoragePath } = await saveUpload(
      `rfp/${project.id}`,
      doc.fileName,
      buf,
    );

    const rfp = await prisma.rFP.create({
      data: {
        projectId: project.id,
        title: title?.trim() || doc.name,
        fileName: doc.fileName,
        fileSize: doc.fileSize,
        mimeType: doc.mimeType,
        storagePath: rfpStoragePath,
      },
      select: { id: true, title: true },
    });

    void logActivity({
      rfpId: rfp.id,
      actorId: ctx.userId,
      kind: "RFP_UPLOADED",
      payload: {
        fileName: doc.fileName,
        fileSize: doc.fileSize,
        source: "chat_assistant",
        sourceDocumentId: doc.id,
      },
    });

    // Kick off the pipeline in the background; question extraction begins.
    void createRunForRfp(rfp.id);
    processRfp(rfp.id).catch((err) => console.error("[chat:start_rfp_process]", err));

    return {
      ok: true,
      rfpId: rfp.id,
      rfpTitle: rfp.title,
      projectId: project.id,
      projectName: project.name,
      note:
        "RFP created and processing started in the background — question extraction is running. " +
        "Direct the user to the RFP viewer once it's INDEXED (usually under a minute).",
    };
  },
});

// ---------- helpers ----------

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "but", "is", "are", "was", "were", "be", "of",
  "to", "in", "on", "at", "by", "for", "with", "as", "from", "that", "this",
  "we", "you", "they", "i", "what", "which", "who", "how", "why", "when",
  "where", "do", "does", "did", "have", "has", "had", "will", "would", "should",
  "can", "could", "may", "might", "must", "if", "then", "not", "no",
]);

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]+/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2 && !STOPWORDS.has(t));
}

function toGoldenView(g: { question: string; answer: string; tags: string[]; updatedAt: Date }) {
  return {
    question: g.question,
    answer: g.answer,
    tags: g.tags,
    updatedAt: g.updatedAt.toISOString(),
  };
}

function friendlyDelta(ms: number): string {
  const abs = Math.abs(ms);
  const days = Math.floor(abs / 86_400_000);
  const hours = Math.floor((abs % 86_400_000) / 3_600_000);
  const sign = ms < 0 ? "ago" : "from now";
  if (days >= 1) return `${days}d ${hours}h ${sign}`;
  const minutes = Math.floor((abs % 3_600_000) / 60_000);
  if (hours >= 1) return `${hours}h ${minutes}m ${sign}`;
  return `${minutes}m ${sign}`;
}

