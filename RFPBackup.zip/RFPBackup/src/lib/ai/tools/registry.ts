import type { ChatCompletionTool } from "openai/resources/chat/completions";
import { z, type ZodType } from "zod";

export interface ToolContext {
  organizationId: string;
  projectId?: string;
  rfpId?: string;
  /** When generating a response, this is the question we're answering. */
  questionId?: string;
  defaultIndexId?: string | null;
  userId: string;
}

export interface ToolDefinition<I = unknown, O = unknown> {
  name: string;
  description: string;
  schema: ZodType<I>;
  execute: (input: I, ctx: ToolContext) => Promise<O>;
}

class ToolRegistry {
  private tools = new Map<string, ToolDefinition<any, any>>();

  register<I, O>(tool: ToolDefinition<I, O>) {
    this.tools.set(tool.name, tool);
    return this;
  }

  get(name: string): ToolDefinition | undefined {
    return this.tools.get(name);
  }

  list(): ToolDefinition[] {
    return Array.from(this.tools.values());
  }

  toOpenAITools(names?: string[]): ChatCompletionTool[] {
    const selected = names
      ? names.map((n) => this.tools.get(n)).filter((t): t is ToolDefinition => Boolean(t))
      : this.list();
    return selected.map((t) => ({
      type: "function",
      function: {
        name: t.name,
        description: t.description,
        parameters: zodToJsonSchema(t.schema),
      },
    }));
  }

  /**
   * Same as toOpenAITools but consults the per-org ToolConfig table to filter
   * out tools the admin has disabled. Tools without a ToolConfig row are
   * treated as enabled by default — adding a new tool doesn't silently break
   * existing orgs.
   */
  async toOpenAIToolsForOrg(organizationId: string, names?: string[]): Promise<ChatCompletionTool[]> {
    const { prisma } = await import("@/lib/prisma");
    const configs = await prisma.toolConfig.findMany({
      where: { organizationId },
      select: { name: true, enabled: true },
    });
    const overrides = new Map(configs.map((c) => [c.name, c.enabled]));
    const enabled = this.list().filter((t) => overrides.get(t.name) !== false);
    const selected = names ? enabled.filter((t) => names.includes(t.name)) : enabled;
    return selected.map((t) => ({
      type: "function",
      function: {
        name: t.name,
        description: t.description,
        parameters: zodToJsonSchema(t.schema),
      },
    }));
  }

  async invoke(name: string, rawArgs: string, ctx: ToolContext): Promise<unknown> {
    const tool = this.get(name);
    if (!tool) throw new Error(`Unknown tool: ${name}`);
    let parsed: unknown;
    try {
      parsed = JSON.parse(rawArgs || "{}");
    } catch {
      throw new Error(`Tool ${name} got invalid JSON arguments`);
    }
    const valid = tool.schema.safeParse(parsed);
    if (!valid.success) {
      throw new Error(`Tool ${name} arguments invalid: ${valid.error.message}`);
    }
    return tool.execute(valid.data, ctx);
  }
}

export const toolRegistry = new ToolRegistry();

// Lightweight Zod -> JSON Schema for the small subset we use in tool args.
// Avoids pulling in `zod-to-json-schema` for what is a few primitive types.
function zodToJsonSchema(schema: ZodType): Record<string, unknown> {
  const def = (schema as unknown as { _def: any })._def;
  switch (def.typeName) {
    case "ZodObject": {
      const shape = def.shape();
      const properties: Record<string, unknown> = {};
      const required: string[] = [];
      for (const key of Object.keys(shape)) {
        const child = shape[key] as ZodType;
        const childDef = (child as unknown as { _def: any })._def;
        properties[key] = zodToJsonSchema(child);
        if (childDef.typeName !== "ZodOptional" && childDef.typeName !== "ZodDefault") {
          required.push(key);
        }
      }
      return { type: "object", properties, required, additionalProperties: false };
    }
    case "ZodString":
      return { type: "string", description: def.description };
    case "ZodNumber":
      return { type: "number", description: def.description };
    case "ZodBoolean":
      return { type: "boolean", description: def.description };
    case "ZodArray":
      return { type: "array", items: zodToJsonSchema(def.type) };
    case "ZodOptional":
    case "ZodDefault":
      return zodToJsonSchema(def.innerType);
    case "ZodEnum":
      return { type: "string", enum: def.values };
    default:
      return { type: "string" };
  }
}

export { z };
