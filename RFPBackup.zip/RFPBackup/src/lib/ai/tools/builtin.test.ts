import { describe, expect, it, beforeAll } from "vitest";
import { toolRegistry } from "./registry";
import "./builtin";

const CTX = {
  organizationId: "org_test",
  userId: "user_test",
};

describe("builtin tools — deterministic", () => {
  it("registers all RFP tools", () => {
    const names = toolRegistry.list().map((t) => t.name);
    expect(names).toEqual(expect.arrayContaining([
      "search_knowledge_base",
      "list_indexes",
      "calculator",
      "search_golden_answers",
      "find_similar_past_responses",
      "get_rfp_context",
      "list_rfp_questions",
      "get_question_detail",
      "days_until",
      "word_count",
      "list_documents",
    ]));
  });

  it("calculator evaluates basic arithmetic", async () => {
    const r = await toolRegistry.invoke("calculator", JSON.stringify({ expression: "(12 * 3) + 4 / 2" }), CTX);
    expect(r).toEqual({ result: 38 });
  });

  it("calculator handles exponent via ^", async () => {
    const r = await toolRegistry.invoke("calculator", JSON.stringify({ expression: "2^10" }), CTX);
    expect(r).toEqual({ result: 1024 });
  });

  it("calculator rejects letters and other unsafe input", async () => {
    await expect(
      toolRegistry.invoke("calculator", JSON.stringify({ expression: "process.exit(1)" }), CTX),
    ).rejects.toThrow();
  });

  it("word_count counts words, characters, and non-space characters", async () => {
    const r = (await toolRegistry.invoke(
      "word_count",
      JSON.stringify({ text: "Hello world, this is AutoRFP." }),
      CTX,
    )) as { words: number; characters: number; charactersNoSpaces: number };
    expect(r.words).toBe(5);
    expect(r.characters).toBe(29);
    expect(r.charactersNoSpaces).toBe(25);
  });

  it("word_count treats multiple whitespace as one separator", async () => {
    const r = (await toolRegistry.invoke(
      "word_count",
      JSON.stringify({ text: "one   two\nthree\t\tfour" }),
      CTX,
    )) as { words: number };
    expect(r.words).toBe(4);
  });

  it("days_until returns positive deltas for future dates", async () => {
    const future = new Date(Date.now() + 3 * 86_400_000 + 5 * 3_600_000).toISOString();
    const r = (await toolRegistry.invoke(
      "days_until",
      JSON.stringify({ targetDate: future }),
      CTX,
    )) as { isPast: boolean; breakdown: { days: number; hours: number } };
    expect(r.isPast).toBe(false);
    expect(r.breakdown.days).toBe(3);
    expect(r.breakdown.hours).toBeGreaterThanOrEqual(4);
    expect(r.breakdown.hours).toBeLessThanOrEqual(5);
  });

  it("days_until flags past dates", async () => {
    const past = new Date(Date.now() - 2 * 86_400_000).toISOString();
    const r = (await toolRegistry.invoke(
      "days_until",
      JSON.stringify({ targetDate: past }),
      CTX,
    )) as { isPast: boolean; friendly: string };
    expect(r.isPast).toBe(true);
    expect(r.friendly).toMatch(/ago$/);
  });

  it("days_until rejects garbage input", async () => {
    await expect(
      toolRegistry.invoke("days_until", JSON.stringify({ targetDate: "not-a-date" }), CTX),
    ).rejects.toThrow();
  });
});
