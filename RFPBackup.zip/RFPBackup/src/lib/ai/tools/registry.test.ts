import { describe, expect, it, beforeEach } from "vitest";
import { toolRegistry, z } from "./registry";

const TEST_TOOL_NAME = "__test_echo__";

beforeEach(() => {
  // Re-register a clean test tool each run.
  toolRegistry.register({
    name: TEST_TOOL_NAME,
    description: "Echoes a message",
    schema: z.object({ message: z.string() }),
    async execute({ message }) {
      return { echoed: message };
    },
  });
});

describe("toolRegistry", () => {
  it("lists registered tools", () => {
    const names = toolRegistry.list().map((t) => t.name);
    expect(names).toContain(TEST_TOOL_NAME);
  });

  it("converts to OpenAI tool spec", () => {
    const tools = toolRegistry.toOpenAITools([TEST_TOOL_NAME]);
    expect(tools).toHaveLength(1);
    expect(tools[0].function.name).toBe(TEST_TOOL_NAME);
    expect(tools[0].function.parameters).toMatchObject({
      type: "object",
      properties: { message: { type: "string" } },
      required: ["message"],
    });
  });

  it("invokes a tool with valid args", async () => {
    const result = await toolRegistry.invoke(
      TEST_TOOL_NAME,
      JSON.stringify({ message: "hi" }),
      { organizationId: "org_x", userId: "user_x" },
    );
    expect(result).toEqual({ echoed: "hi" });
  });

  it("rejects invalid args", async () => {
    await expect(
      toolRegistry.invoke(TEST_TOOL_NAME, JSON.stringify({}), {
        organizationId: "org_x",
        userId: "user_x",
      }),
    ).rejects.toThrow(/invalid/i);
  });

  it("rejects unknown tool name", async () => {
    await expect(
      toolRegistry.invoke("nope", "{}", { organizationId: "org_x", userId: "user_x" }),
    ).rejects.toThrow(/unknown tool/i);
  });
});
