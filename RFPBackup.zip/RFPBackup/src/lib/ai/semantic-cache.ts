// Semantic answer cache. Returns a previously generated answer when the same
// (or sufficiently similar) question has been asked before in the same org.
//
// Two-tier lookup keeps the hot path cheap:
//   1. Exact match on `questionHash` (sha256 of the normalized question).
//      Index-covered ({organizationId, questionHash}), one row fetch, no
//      embedding work at all. Covers the very common "vendor copy-pasted the
//      same question wording across two RFPs" case.
//   2. Semantic match: embed the question once, score cosine similarity vs
//      the latest ~200 rows for the org+index. The cap exists because we
//      don't yet have a pgvector index — see the TODO below. With 200 rows
//      the loop runs in <2 ms in practice.
//
// On a hit, we increment `hits` and bump `lastUsedAt` in a single UPDATE so
// stale-rotation queries ("purge cached answers older than N days") can
// distinguish actively-used entries from forgotten ones.
//
// Tenant isolation: every query is bound by `organizationId`. The
// `indexId ?? null` shape mirrors how rows are written — entries created
// without an index also match lookups that pass `null`/undefined, so a project
// without a configured knowledge base still benefits from the cache.

import crypto from "crypto";
import { prisma } from "@/lib/prisma";
import { embed } from "./embeddings";
import { env } from "@/lib/env";
import { log } from "@/lib/logger";
import { cacheLookupsTotal } from "@/lib/metrics";

/** Default cosine-similarity threshold for the semantic tier. Lifted high so
 *  we don't return a confidently-wrong answer to a subtly-different question
 *  (e.g. "soc 2 type 1" vs "soc 2 type 2" — these embed very close but the
 *  answer differs materially). Operators can tune via `threshold` on the call. */
export const DEFAULT_THRESHOLD = 0.92;

/** Max rows scanned per semantic lookup. Replace with pgvector ORDER BY once
 *  the index ships. */
const SEMANTIC_SCAN_LIMIT = 200;

export interface CacheLookupOpts {
  organizationId: string;
  question: string;
  indexId?: string | null;
  /** Cosine similarity threshold for the semantic tier. Default 0.92. */
  threshold?: number;
}

export interface CacheHit {
  id: string;
  /** The cached question text — useful for telemetry / "matched X" UI hints. */
  question: string;
  answer: string;
  /** 0..1 — 1.0 for exact-hash matches, cosine similarity otherwise. */
  similarity: number;
  sourcesSnapshot: unknown[];
  confidence: number | null;
  groundingScore: number | null;
}

export interface CacheStoreOpts {
  organizationId: string;
  question: string;
  indexId?: string | null;
  answer: string;
  sourcesSnapshot: unknown;
  confidence?: number;
  groundingScore?: number;
}

/**
 * Normalize a question for hashing and matching. Lowercases, collapses
 * runs of whitespace to a single space, and strips leading / trailing
 * non-word characters. Punctuation *inside* the question is preserved so
 * "what is soc 2?" doesn't collide with an unrelated "what is soc 2".
 *
 * Examples:
 *   "What is your SOC 2 certification?" -> "what is your soc 2 certification"
 *   "  hello    world!   " -> "hello world"
 */
export function normalizeQuestion(q: string): string {
  return q
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/^[^\w]+|[^\w]+$/g, "");
}

/** SHA-256 hex of the normalized question. Stable across processes. */
export function questionHash(q: string): string {
  return crypto.createHash("sha256").update(normalizeQuestion(q)).digest("hex");
}

/** Cosine similarity of two equal-length numeric vectors. Returns 0 when
 *  either vector is empty or zero-norm (defensive — embeddings should never
 *  be zero but guarding here means the cache never blows up on a corrupt row). */
export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length === 0 || a.length !== b.length) return 0;
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

/**
 * Look up a cached answer for the given question in the given org+index.
 * Returns the best match (exact hash > semantic) or null on miss.
 *
 * Always succeeds — DB / embedding errors are caught and logged at warn
 * level, then surfaced as a miss. A cache failure must never break
 * generation.
 */
export async function lookupCachedAnswer(opts: CacheLookupOpts): Promise<CacheHit | null> {
  if (!env.SEMANTIC_CACHE_ENABLED) {
    cacheLookupsTotal.inc({ result: "miss" });
    return null;
  }

  const indexFilter = opts.indexId ?? null;
  const threshold = opts.threshold ?? DEFAULT_THRESHOLD;

  // --- Tier 1: exact-hash match.
  const hash = questionHash(opts.question);
  try {
    const exact = await prisma.cachedAnswer.findFirst({
      where: {
        organizationId: opts.organizationId,
        questionHash: hash,
        indexId: indexFilter,
      },
      orderBy: { lastUsedAt: "desc" },
    });
    if (exact) {
      await touchHit(exact.id);
      cacheLookupsTotal.inc({ result: "hit_exact" });
      return toCacheHit(exact, 1.0);
    }
  } catch (err) {
    log().warn(
      { err: errSummary(err), orgId: opts.organizationId },
      "cache exact-hash lookup failed; treating as miss",
    );
    cacheLookupsTotal.inc({ result: "miss" });
    return null;
  }

  // --- Tier 2: semantic match.
  // TODO(pgvector): once we have a pgvector column + ivfflat index, replace
  // this with `ORDER BY questionEmbedding <-> $1 LIMIT 1` and skip the
  // in-process scoring loop entirely. Until then the scan is bounded by
  // SEMANTIC_SCAN_LIMIT to keep p99 latency predictable.
  let candidates: Awaited<ReturnType<typeof prisma.cachedAnswer.findMany>>;
  try {
    candidates = await prisma.cachedAnswer.findMany({
      where: { organizationId: opts.organizationId, indexId: indexFilter },
      orderBy: { lastUsedAt: "desc" },
      take: SEMANTIC_SCAN_LIMIT,
    });
  } catch (err) {
    log().warn(
      { err: errSummary(err), orgId: opts.organizationId },
      "cache semantic candidate fetch failed; treating as miss",
    );
    cacheLookupsTotal.inc({ result: "miss" });
    return null;
  }

  if (candidates.length === 0) {
    cacheLookupsTotal.inc({ result: "miss" });
    return null;
  }

  let queryEmbedding: number[];
  try {
    queryEmbedding = await embed(opts.question, opts.organizationId);
  } catch (err) {
    log().warn(
      { err: errSummary(err), orgId: opts.organizationId },
      "cache embedder failed; treating as miss",
    );
    cacheLookupsTotal.inc({ result: "miss" });
    return null;
  }

  let bestRow: (typeof candidates)[number] | null = null;
  let bestScore = 0;
  for (const row of candidates) {
    const embedding = row.questionEmbedding;
    // questionEmbedding is `Float[]` on the schema — Prisma returns it as
    // `number[]`. Skip rows with missing/empty vectors (older rows from
    // before this feature shipped won't have one).
    if (!Array.isArray(embedding) || embedding.length === 0) continue;
    if (embedding.length !== queryEmbedding.length) continue;
    const score = cosineSimilarity(queryEmbedding, embedding);
    if (score > bestScore) {
      bestScore = score;
      bestRow = row;
    }
  }

  if (bestRow && bestScore >= threshold) {
    await touchHit(bestRow.id);
    cacheLookupsTotal.inc({ result: "hit_semantic" });
    return toCacheHit(bestRow, bestScore);
  }

  cacheLookupsTotal.inc({ result: "miss" });
  return null;
}

/**
 * Persist a freshly-generated answer in the cache. Best-effort — failures
 * are logged and swallowed. The cache is a latency/cost optimization, not
 * a source of truth, so a write failure must never affect the response
 * the user is currently seeing.
 */
export async function storeCachedAnswer(opts: CacheStoreOpts): Promise<void> {
  if (!env.SEMANTIC_CACHE_ENABLED) return;

  try {
    const embedding = await embed(opts.question, opts.organizationId);
    await prisma.cachedAnswer.create({
      data: {
        organizationId: opts.organizationId,
        questionHash: questionHash(opts.question),
        indexId: opts.indexId ?? null,
        question: opts.question,
        questionEmbedding: embedding,
        answer: opts.answer,
        sourcesSnapshot: (opts.sourcesSnapshot ?? null) as never,
        confidence: opts.confidence ?? null,
        groundingScore: opts.groundingScore ?? null,
      },
    });
  } catch (err) {
    log().warn(
      { err: errSummary(err), orgId: opts.organizationId },
      "cache store failed; continuing",
    );
  }
}

/** Delete a single cache entry by id. Used by the admin "Invalidate" button
 *  and by maintenance scripts. No-op (and no throw) when the row is already
 *  gone. */
export async function invalidateCachedAnswer(id: string): Promise<void> {
  try {
    await prisma.cachedAnswer.delete({ where: { id } });
  } catch (err) {
    // P2025 = "Record to delete does not exist" — fine, idempotent.
    log().warn(
      { err: errSummary(err), id },
      "cache invalidate: row already gone or delete failed",
    );
  }
}

/** Bulk-purge entries whose `lastUsedAt` is older than the given window.
 *  Returns the number of rows deleted. Used by both the admin route's
 *  "purge older than N days" action and (eventually) a maintenance cron. */
export async function purgeStaleCache(olderThanDays: number): Promise<number> {
  if (!Number.isFinite(olderThanDays) || olderThanDays < 0) return 0;
  const cutoff = new Date(Date.now() - olderThanDays * 24 * 60 * 60 * 1000);
  try {
    const result = await prisma.cachedAnswer.deleteMany({
      where: { lastUsedAt: { lt: cutoff } },
    });
    return result.count;
  } catch (err) {
    log().warn({ err: errSummary(err), olderThanDays }, "cache purge failed");
    return 0;
  }
}

// --- helpers ---------------------------------------------------------------

async function touchHit(id: string): Promise<void> {
  try {
    await prisma.cachedAnswer.update({
      where: { id },
      data: { hits: { increment: 1 }, lastUsedAt: new Date() },
    });
  } catch (err) {
    // Don't fail the lookup over a touch failure — the row is still a valid
    // cache hit even if we couldn't bump its counters.
    log().warn({ err: errSummary(err), id }, "cache touch failed");
  }
}

function toCacheHit(
  row: {
    id: string;
    question: string;
    answer: string;
    sourcesSnapshot: unknown;
    confidence: number | null;
    groundingScore: number | null;
  },
  similarity: number,
): CacheHit {
  const snapshot = row.sourcesSnapshot;
  return {
    id: row.id,
    question: row.question,
    answer: row.answer,
    similarity,
    sourcesSnapshot: Array.isArray(snapshot) ? (snapshot as unknown[]) : [],
    confidence: row.confidence,
    groundingScore: row.groundingScore,
  };
}

function errSummary(err: unknown): Record<string, unknown> {
  if (err instanceof Error) return { name: err.name, message: err.message };
  return { value: String(err) };
}
