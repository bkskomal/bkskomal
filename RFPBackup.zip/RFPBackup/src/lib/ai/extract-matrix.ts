// AI pricing-matrix cell extractor.
//
// One LLM call per cell. The caller hands us the row label (line item),
// column header (tier/quantity/region/SKU), and a small bundle of context
// (knowledge-base excerpts + past golden answers). We return a short cell
// value plus a confidence score in [0, 1].
//
// Failure mode: ANY thrown error from the LLM client (network, timeout, bad
// JSON, breaker-open) is swallowed and surfaces as `{ generated: "NEEDS
// INFO", confidence: 0 }`. A failing cell must NOT fail the whole row.
// Upstream the caller streams cells one-by-one via SSE; a transient error
// for one cell should not poison the rest.
//
// Confidence scoring is heuristic and intentionally simple. The model
// outputs a plain string — no structured self-rating to lean on — so we
// derive confidence from:
//   - Did we get back the literal "NEEDS INFO" sentinel? → 0
//   - Was the response empty after trimming? → 0
//   - Was the response one of the "obvious unknown" hedges? → low
//   - Otherwise → 0.7 baseline, nudged by length and citation hints.
// Cheap, deterministic, and good enough for a per-cell "should a human
// review this?" badge. The grounding judge in lib/ai/grounding.ts is too
// expensive to run per-cell on a 50-row × 10-column matrix.

import { getAiClients } from "./client";
import { PRICING_MATRIX_CELL_SYSTEM } from "./prompts";
import { log } from "@/lib/logger";

export interface GenerateMatrixCellInput {
  rowLabel: string;
  columnHeader: string;
  /** Free-form context strings. KB excerpts, golden Q/A pairs, prior cell answers. */
  contextBlocks: string[];
  organizationId: string;
}

export interface GenerateMatrixCellResult {
  generated: string;
  confidence: number;
}

/** Sentinel the prompt instructs the model to return when context is insufficient. */
export const NEEDS_INFO_SENTINEL = "NEEDS INFO";

/**
 * Cap raw context-block length so the prompt fits even when callers pass
 * a generous set of excerpts. The matrix generator is invoked per-cell and
 * tail latency matters; bloated prompts also push useful signal out of
 * attention.
 */
const PER_BLOCK_CHAR_BUDGET = 800;
const MAX_CONTEXT_BLOCKS = 6;

export async function generateMatrixCell(
  input: GenerateMatrixCellInput,
): Promise<GenerateMatrixCellResult> {
  const rowLabel = input.rowLabel?.trim() || "(unnamed line item)";
  const columnHeader = input.columnHeader?.trim() || "(unnamed column)";

  const contextBody = buildContextBody(input.contextBlocks);
  const userPrompt = [
    `Row label: ${rowLabel}`,
    `Column header: ${columnHeader}`,
    contextBody ? `\nContext:\n${contextBody}` : `\nContext: (none provided)`,
    `\nReturn the single cell value (or exactly "NEEDS INFO").`,
  ].join("\n");

  try {
    const { llm, config } = await getAiClients(input.organizationId);
    const completion = await llm.chat.completions.create({
      model: config.llm.model,
      temperature: 0.1,
      messages: [
        { role: "system", content: PRICING_MATRIX_CELL_SYSTEM },
        { role: "user", content: userPrompt },
      ],
    });
    const raw = completion.choices?.[0]?.message?.content ?? "";
    return scoreCell(cleanCellValue(raw));
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        rowLabel,
        columnHeader,
        orgId: input.organizationId,
      },
      "matrix-cell generation failed; returning NEEDS INFO",
    );
    return { generated: NEEDS_INFO_SENTINEL, confidence: 0 };
  }
}

/**
 * Concatenate context blocks with a fixed per-block budget and an overall
 * block cap. Returns "" when no usable blocks were supplied.
 */
function buildContextBody(blocks: string[] | undefined): string {
  if (!blocks || blocks.length === 0) return "";
  const trimmed: string[] = [];
  for (const block of blocks) {
    if (trimmed.length >= MAX_CONTEXT_BLOCKS) break;
    if (typeof block !== "string") continue;
    const t = block.trim();
    if (!t) continue;
    trimmed.push(t.slice(0, PER_BLOCK_CHAR_BUDGET));
  }
  return trimmed.map((b, i) => `[Context ${i + 1}]\n${b}`).join("\n\n---\n\n");
}

/**
 * Strip code fences, surrounding quotes, and leading list markers the model
 * sometimes adds despite the prompt asking for plain text. Conservative —
 * we don't second-guess legitimate content; we only peel obvious wrappers.
 */
function cleanCellValue(raw: string): string {
  let s = (raw ?? "").trim();
  if (!s) return "";
  // Strip a single layer of code fences (```...```), preserving inner whitespace.
  const fence = s.match(/^```(?:\w+)?\n?([\s\S]*?)```$/);
  if (fence) s = fence[1]!.trim();
  // Strip surrounding matched quotes.
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    s = s.slice(1, -1).trim();
  }
  // Strip a leading bullet/dash/numbering token.
  s = s.replace(/^[-*•]\s+/, "").replace(/^\d+[.)]\s+/, "");
  return s.trim();
}

/**
 * Heuristic confidence for a single cell answer. See module header for
 * rationale.
 */
export function scoreCell(value: string): GenerateMatrixCellResult {
  const generated = value.trim();
  if (!generated) return { generated: NEEDS_INFO_SENTINEL, confidence: 0 };
  // Case-insensitive match on the sentinel so "needs info" / "Needs Info"
  // both collapse to the canonical form.
  if (generated.toUpperCase().includes("NEEDS INFO")) {
    return { generated: NEEDS_INFO_SENTINEL, confidence: 0 };
  }

  let score = 0.7;
  const lower = generated.toLowerCase();

  // Obvious-unknown hedges are not failures, but a reviewer should look.
  if (/\b(unknown|tbd|to be determined|n\/?a|contact sales|not applicable)\b/i.test(generated)) {
    score -= 0.3;
  }
  // Hedging language inside a cell answer is a yellow flag.
  if (/\b(may|might|could|potentially|possibly)\b/i.test(lower)) {
    score -= 0.1;
  }
  // Short, structured-looking values (e.g. "$1,200/yr") are typical wins.
  if (/^\$?[\d.,]+/.test(generated)) score += 0.1;
  if (generated.length > 200) score -= 0.1; // overly long isn't really a cell

  if (score < 0) score = 0;
  if (score > 1) score = 1;
  return { generated, confidence: score };
}
