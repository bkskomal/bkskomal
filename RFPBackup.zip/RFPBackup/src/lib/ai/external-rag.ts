// External RAG provider (Phase D).
//
// When the org sets ragProvider != INTERNAL, retrieval.ts skips our own
// dense+sparse+rerank stack and POSTs the query to a remote service that
// returns ranked chunks ready to feed the answer generator. The remote
// service owns hybrid search, reranking, and any contextual augmentation.
//
// This MVP supports a single provider kind: EXTERNAL_HTTP — a generic
// JSON contract any team can stand up in front of their existing RAG
// (Vectara, Azure AI Search, Pinecone Assistants, AWS Kendra, an
// in-house service). Specific provider presets (which auto-shape the
// request/response for those vendors) land as Phase D.2.
//
// Generic contract:
//   POST {endpoint}
//   Headers:
//     Authorization: Bearer {ragApiKey}    (when apiKey set)
//     Content-Type: application/json
//     ... + any extraHeaders the admin configured
//   Body:
//     {
//       "query":   "user question text",
//       "topK":    8,
//       "indexId": "knowledge-index id (or null for org-scope)",
//       "orgId":   "organization id"
//     }
//   200 OK body:
//     {
//       "chunks": [
//         {
//           "id":           "string (required, unique)",
//           "content":      "string (required)",
//           "documentId":   "string (optional)",
//           "documentName": "string (optional, falls back to 'External source')",
//           "fileName":     "string (optional)",
//           "page":         "number | null (optional)",
//           "score":        "number (optional, defaults to 0.5)"
//         },
//         ...
//       ]
//     }
//
// Non-2xx responses raise — retrieval.ts catches and surfaces the error
// up the chain instead of silently returning [].

import { log } from "@/lib/logger";
import type { RetrievedChunk } from "./retrieval";

const DEFAULT_TIMEOUT_MS = 20_000;

export interface ExternalRagInput {
  query: string;
  topK: number;
  indexId: string | null;
  orgId: string;
  endpoint: string;
  apiKey: string | null;
  extraHeaders: Record<string, string>;
  /** Caller AbortSignal so the UI Stop button cancels the upstream call. */
  signal?: AbortSignal;
}

interface ExternalChunkPayload {
  id?: unknown;
  content?: unknown;
  documentId?: unknown;
  documentName?: unknown;
  fileName?: unknown;
  page?: unknown;
  score?: unknown;
}
interface ExternalResponsePayload {
  chunks?: unknown;
}

/**
 * POST a query to an external RAG service and normalize the response into
 * our `RetrievedChunk[]` shape so the rest of the pipeline (generate.ts,
 * citations, viewer) keeps working without conditionals.
 */
export async function fetchExternalRag(input: ExternalRagInput): Promise<RetrievedChunk[]> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), DEFAULT_TIMEOUT_MS);
  const onExternal = () => ctrl.abort();
  if (input.signal) {
    if (input.signal.aborted) ctrl.abort();
    else input.signal.addEventListener("abort", onExternal, { once: true });
  }

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...input.extraHeaders,
  };
  if (input.apiKey) headers["Authorization"] = `Bearer ${input.apiKey}`;

  try {
    const res = await fetch(input.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        query: input.query,
        topK: input.topK,
        indexId: input.indexId,
        orgId: input.orgId,
      }),
      signal: ctrl.signal,
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(
        `external RAG HTTP ${res.status}: ${body.slice(0, 240)}`,
      );
    }
    const payload = (await res.json()) as ExternalResponsePayload;
    const raw = Array.isArray(payload?.chunks) ? payload.chunks : [];
    return raw
      .map((c, i) => normalize(c as ExternalChunkPayload, i))
      .filter((c): c is RetrievedChunk => c !== null);
  } finally {
    clearTimeout(timer);
    input.signal?.removeEventListener("abort", onExternal);
  }
}

function normalize(c: ExternalChunkPayload, fallbackIdx: number): RetrievedChunk | null {
  const content = typeof c.content === "string" ? c.content : null;
  if (!content) return null; // a chunk with no content is useless
  const id = typeof c.id === "string" && c.id.trim() ? c.id : `ext-${fallbackIdx}`;
  const documentId = typeof c.documentId === "string" ? c.documentId : id;
  const documentName =
    typeof c.documentName === "string" && c.documentName.trim()
      ? c.documentName
      : "External source";
  const fileName = typeof c.fileName === "string" ? c.fileName : documentName;
  const page = typeof c.page === "number" ? c.page : null;
  const score = typeof c.score === "number" ? c.score : 0.5;
  return {
    id,
    documentId,
    documentName,
    fileName,
    ordinal: fallbackIdx,
    page,
    content,
    score,
  };
}

/** Best-effort health-check helper for the Settings UI "Test connection"
 *  button. Sends a trivial query and reports {ok, message, sampleCount}. */
export async function pingExternalRag(input: ExternalRagInput): Promise<{
  ok: boolean;
  message: string;
  sampleCount: number;
}> {
  try {
    const chunks = await fetchExternalRag({ ...input, query: "ping", topK: 1 });
    return {
      ok: true,
      message: `Returned ${chunks.length} chunk${chunks.length === 1 ? "" : "s"}`,
      sampleCount: chunks.length,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    log().warn({ orgId: input.orgId, endpoint: input.endpoint, err: message }, "external RAG ping failed");
    return { ok: false, message, sampleCount: 0 };
  }
}
