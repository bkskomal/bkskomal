// CLIP image + text embedder.
//
// Loads `Xenova/clip-vit-base-patch32` via @huggingface/transformers and
// produces 512-d L2-normalized vectors in CLIP space. Image and text encoders
// share the same vector space, which means a text query like "an architecture
// diagram" can directly retrieve images via cosine similarity — no separate
// caption-and-embed step required.
//
// Design notes:
//   - Singleton, lazy-load. Model files are ~85 MB on first use; subsequent
//     calls reuse the cached pipeline. Cache lives under
//     `node_modules/.cache/transformers` so it survives dev restarts (matches
//     the embeddings-local convention).
//   - Image input: Buffer → Blob → RawImage. The transformers.js pipeline
//     accepts a RawImage directly. We handle the Buffer-to-Blob conversion
//     here so callers can keep passing Node Buffers.
//   - Text input: tokenizer auto-truncates at 77 tokens (CLIP's positional
//     limit). We rely on `padding: true, truncation: true`.
//   - All output vectors are L2-normalized so cosine similarity becomes a
//     simple dot product — every vector store contract assumes normalized
//     inputs.
//   - Each call is wrapped in a 10 s timeout. The model is fast on CPU
//     (~100 ms per image) so a 10 s budget catches pathological inputs
//     without spuriously aborting healthy calls.

export const CLIP_MODEL = "Xenova/clip-vit-base-patch32";
export const CLIP_DIMENSIONS = 512;

// 60s — covers cold-start model download (Xenova/clip-vit-base-patch32 ≈ 85 MB)
// and slow CPU inference on large images. Subsequent calls are typically < 200ms.
const DEFAULT_TIMEOUT_MS = 60_000;

export interface ClipEmbedder {
  readonly model: string;
  readonly dimensions: number;
  /** Image bytes → CLIP image vector (L2-normalized, 512-d). */
  embedImage(buffer: Buffer): Promise<number[]>;
  /** Text → CLIP text vector (L2-normalized, 512-d) — same space as embedImage. */
  embedTextForImageSearch(text: string): Promise<number[]>;
  /** True once the model has been loaded. Lazy on first call. */
  readonly ready: boolean;
}

// ---- internal lazy loaders ----------------------------------------------

// We hold three lazy promises: the image-feature-extraction pipeline (uses the
// CLIP vision tower), and the (tokenizer, text-model-with-projection) pair for
// text. transformers.js doesn't ship a single "clip-text" pipeline task, so we
// compose AutoTokenizer + CLIPTextModelWithProjection by hand.
let imagePipelinePromise: Promise<unknown> | null = null;
let textTokenizerPromise: Promise<unknown> | null = null;
let textModelPromise: Promise<unknown> | null = null;
let loadedFlag = false;

interface TransformersModule {
  pipeline: (task: string, model: string, options?: Record<string, unknown>) => Promise<unknown>;
  AutoTokenizer: { from_pretrained: (model: string) => Promise<unknown> };
  CLIPTextModelWithProjection: { from_pretrained: (model: string) => Promise<unknown> };
  RawImage: {
    fromBlob: (blob: Blob) => Promise<unknown>;
  };
  env: { cacheDir?: string; allowLocalModels?: boolean };
}

let _mod: TransformersModule | null = null;
async function getTransformers(): Promise<TransformersModule> {
  if (_mod) return _mod;
  const mod = (await import("@huggingface/transformers")) as unknown as TransformersModule;
  // Cache model files under node_modules/.cache to mirror embeddings-local.
  if (mod.env) {
    mod.env.cacheDir = "./node_modules/.cache/transformers";
    mod.env.allowLocalModels = true;
  }
  _mod = mod;
  return mod;
}

async function getImagePipeline(): Promise<unknown> {
  if (imagePipelinePromise) return imagePipelinePromise;
  imagePipelinePromise = (async () => {
    const mod = await getTransformers();
    const pipe = await mod.pipeline("image-feature-extraction", CLIP_MODEL);
    loadedFlag = true;
    return pipe;
  })();
  try {
    return await imagePipelinePromise;
  } catch (e) {
    imagePipelinePromise = null;
    throw e;
  }
}

async function getTextEncoder(): Promise<{
  tokenizer: (texts: string[], opts: Record<string, unknown>) => Record<string, unknown>;
  model: (inputs: Record<string, unknown>) => Promise<{ text_embeds: { data: Float32Array; dims: number[] } }>;
}> {
  if (!textTokenizerPromise || !textModelPromise) {
    const mod = await getTransformers();
    if (!textTokenizerPromise) {
      textTokenizerPromise = mod.AutoTokenizer.from_pretrained(CLIP_MODEL);
    }
    if (!textModelPromise) {
      textModelPromise = mod.CLIPTextModelWithProjection.from_pretrained(CLIP_MODEL);
    }
  }
  try {
    const [tok, model] = await Promise.all([textTokenizerPromise, textModelPromise]);
    loadedFlag = true;
    return {
      tokenizer: tok as never,
      model: model as never,
    };
  } catch (e) {
    textTokenizerPromise = null;
    textModelPromise = null;
    throw e;
  }
}

// ---- math helpers --------------------------------------------------------

/** L2-normalize in place; returns the same array for chaining. */
function l2Normalize(v: number[]): number[] {
  let s = 0;
  for (const x of v) s += x * x;
  const n = Math.sqrt(s);
  if (n === 0) return v;
  for (let i = 0; i < v.length; i++) v[i] = v[i] / n;
  return v;
}

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      },
    );
  });
}

// ---- public API ----------------------------------------------------------

class ClipEmbedderImpl implements ClipEmbedder {
  readonly model = CLIP_MODEL;
  readonly dimensions = CLIP_DIMENSIONS;

  get ready(): boolean {
    return loadedFlag;
  }

  async embedImage(buffer: Buffer): Promise<number[]> {
    if (!buffer || buffer.byteLength === 0) {
      throw new Error("embedImage: buffer is empty");
    }
    return withTimeout(
      (async () => {
        const mod = await getTransformers();
        const pipe = (await getImagePipeline()) as (
          input: unknown,
        ) => Promise<{ data: Float32Array; dims: number[] }>;
        // Convert Buffer → Blob → RawImage. RawImage.fromBlob handles PNG/JPEG/etc.
        const blob = new Blob([new Uint8Array(buffer)]);
        const image = await mod.RawImage.fromBlob(blob);
        const tensor = await pipe(image);
        const arr = Array.from(tensor.data as Float32Array);
        if (arr.length !== CLIP_DIMENSIONS) {
          // Some image models return [1, N, D] hidden states when not pooled.
          // The CLIP image-feature-extraction pipeline pools by default, so
          // length should always be 512. If we get something else, take the
          // first 512 entries as a defensive fallback.
          if (arr.length > CLIP_DIMENSIONS) {
            return l2Normalize(arr.slice(0, CLIP_DIMENSIONS));
          }
          throw new Error(
            `CLIP image vector has unexpected length ${arr.length} (expected ${CLIP_DIMENSIONS})`,
          );
        }
        return l2Normalize(arr);
      })(),
      DEFAULT_TIMEOUT_MS,
      "clip.embedImage",
    );
  }

  async embedTextForImageSearch(text: string): Promise<number[]> {
    const trimmed = text?.trim?.() ?? "";
    if (!trimmed) {
      // Empty text → zero vector. Cosine sim against any image is 0; this is
      // the correct behaviour for "no query" rather than throwing.
      return new Array<number>(CLIP_DIMENSIONS).fill(0);
    }
    return withTimeout(
      (async () => {
        const enc = await getTextEncoder();
        // CLIP's tokenizer caps at 77 tokens. truncation: true ensures we
        // don't blow past that limit on long captions / queries.
        const inputs = enc.tokenizer([trimmed], { padding: true, truncation: true });
        const out = await enc.model(inputs);
        const arr = Array.from(out.text_embeds.data);
        // text_embeds shape is [batch, 512]; we passed batch=1 so length=512.
        if (arr.length !== CLIP_DIMENSIONS) {
          if (arr.length > CLIP_DIMENSIONS) {
            return l2Normalize(arr.slice(0, CLIP_DIMENSIONS));
          }
          throw new Error(
            `CLIP text vector has unexpected length ${arr.length} (expected ${CLIP_DIMENSIONS})`,
          );
        }
        return l2Normalize(arr);
      })(),
      DEFAULT_TIMEOUT_MS,
      "clip.embedTextForImageSearch",
    );
  }
}

let _embedder: ClipEmbedder | null = null;

/** Process-wide singleton. Lazy-loads the model on first encode call. */
export function getClipEmbedder(): ClipEmbedder {
  if (!_embedder) _embedder = new ClipEmbedderImpl();
  return _embedder;
}

/**
 * Reset the singleton + cached promises. Test-only escape hatch — production
 * callers should never need this.
 */
export function __resetClipForTests(): void {
  _embedder = null;
  imagePipelinePromise = null;
  textTokenizerPromise = null;
  textModelPromise = null;
  _mod = null;
  loadedFlag = false;
}
