import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { findManyMock } = vi.hoisted(() => ({
  findManyMock: vi.fn(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: { documentChunk: { findMany: (...args: unknown[]) => findManyMock(...args) } },
}));

import {
  _resetSparseCacheForTests,
  encodeSparse,
  encodeSparseWithIdf,
  hashTerm,
  refreshIdfCache,
  tokenizeSparse,
} from "./sparse";

beforeEach(() => {
  _resetSparseCacheForTests();
  findManyMock.mockReset();
});

afterEach(() => {
  _resetSparseCacheForTests();
});

describe("tokenizeSparse", () => {
  it("lowercases and strips punctuation", () => {
    expect(tokenizeSparse("Hello, World!")).toEqual(["hello", "world"]);
  });

  it("removes stopwords and single-character tokens", () => {
    // "a" / "the" are stopwords; "x" is a single char and dropped too.
    expect(tokenizeSparse("the quick a brown fox x")).toEqual([
      "quick",
      "brown",
      "fox",
    ]);
  });

  it("keeps internal dots so v1.2 stays one token, but separates 'soc 2'", () => {
    expect(tokenizeSparse("v1.2 release")).toEqual(["v1.2", "release"]);
    expect(tokenizeSparse("SOC 2 compliance")).toEqual(["soc", "compliance"]);
    // "2" is a single char so it gets dropped; that's expected — IDF would
    // have killed it anyway.
  });

  it("handles empty / whitespace input", () => {
    expect(tokenizeSparse("")).toEqual([]);
    expect(tokenizeSparse("   \t\n")).toEqual([]);
  });

  it("strips Unicode punctuation like em-dashes and curly quotes", () => {
    expect(tokenizeSparse("hello—world “test”")).toEqual([
      "hello",
      "world",
      "test",
    ]);
  });
});

describe("hashTerm (FNV-1a)", () => {
  it("is deterministic across calls", () => {
    expect(hashTerm("encryption")).toBe(hashTerm("encryption"));
    expect(hashTerm("aes-256")).toBe(hashTerm("aes-256"));
  });

  it("produces 32-bit unsigned ints", () => {
    const h = hashTerm("anything goes");
    expect(h).toBeGreaterThanOrEqual(0);
    expect(h).toBeLessThanOrEqual(0xffffffff);
    expect(Number.isInteger(h)).toBe(true);
  });

  it("differs for different inputs (no trivial collisions)", () => {
    expect(hashTerm("encryption")).not.toBe(hashTerm("Encryption"));
    expect(hashTerm("aes")).not.toBe(hashTerm("aes-256"));
  });
});

describe("encodeSparseWithIdf", () => {
  it("returns parallel indices/values arrays of equal length", () => {
    const v = encodeSparseWithIdf("encryption keys", new Map());
    expect(v.indices.length).toBe(v.values.length);
    expect(v.indices.length).toBeGreaterThan(0);
  });

  it("emits no duplicate indices", () => {
    const v = encodeSparseWithIdf(
      "encryption keys encryption rotation encryption",
      new Map(),
    );
    expect(new Set(v.indices).size).toBe(v.indices.length);
  });

  it("indices are sorted ascending (deterministic on-the-wire order)", () => {
    const v = encodeSparseWithIdf("zebra apple mango banana", new Map());
    for (let i = 1; i < v.indices.length; i++) {
      expect(v.indices[i]).toBeGreaterThan(v.indices[i - 1]);
    }
  });

  it("falls back to TF (idf=1) when the cache is empty", () => {
    const v = encodeSparseWithIdf("encryption encryption keys", new Map());
    // Two unique terms after dedup: encryption (tf=2) and keys (tf=1).
    expect(v.indices.length).toBe(2);
    const sum = v.values.reduce((a, b) => a + b, 0);
    expect(sum).toBe(3); // 2 + 1
  });

  it("weights by TF * IDF when an IDF map is provided", () => {
    const enc = hashTerm("encryption");
    const keys = hashTerm("keys");
    const idf = new Map<number, number>([
      [enc, 2.0],
      [keys, 0.5],
    ]);
    const v = encodeSparseWithIdf("encryption encryption keys", idf);
    const lookup = new Map<number, number>();
    v.indices.forEach((id, i) => lookup.set(id, v.values[i]));
    expect(lookup.get(enc)).toBeCloseTo(4.0); // tf 2 * idf 2.0
    expect(lookup.get(keys)).toBeCloseTo(0.5); // tf 1 * idf 0.5
  });

  it("returns empty for stopword-only input", () => {
    expect(encodeSparseWithIdf("the and of to", new Map())).toEqual({
      indices: [],
      values: [],
    });
  });
});

describe("encodeSparse (orgId, with IDF cache)", () => {
  it("computes IDF from the org's chunk corpus on first call", async () => {
    // 5 chunks: "encryption" appears in all 5 → low IDF; "tornado" appears
    // in 1 → high IDF.
    findManyMock.mockResolvedValueOnce([
      { content: "encryption keys" },
      { content: "encryption rotation" },
      { content: "encryption at rest" },
      { content: "encryption in transit" },
      { content: "encryption tornado disaster" },
    ]);

    const v = await encodeSparse("encryption tornado", "org-1");
    expect(findManyMock).toHaveBeenCalledTimes(1);
    expect(v.indices.length).toBe(2);

    const enc = hashTerm("encryption");
    const tor = hashTerm("tornado");
    const lookup = new Map<number, number>();
    v.indices.forEach((id, i) => lookup.set(id, v.values[i]));
    // tornado must outweigh encryption (rarer → higher IDF).
    expect(lookup.get(tor)!).toBeGreaterThan(lookup.get(enc)!);
  });

  it("caches the IDF table across encode calls for the same org", async () => {
    findManyMock.mockResolvedValueOnce([
      { content: "alpha beta gamma" },
      { content: "alpha gamma" },
    ]);

    await encodeSparse("alpha", "org-cache");
    await encodeSparse("beta", "org-cache");
    await encodeSparse("gamma", "org-cache");

    expect(findManyMock).toHaveBeenCalledTimes(1);
  });

  it("refreshIdfCache invalidates and rebuilds", async () => {
    findManyMock
      .mockResolvedValueOnce([{ content: "alpha beta" }])
      .mockResolvedValueOnce([{ content: "delta epsilon" }]);

    await encodeSparse("alpha", "org-refresh");
    await refreshIdfCache("org-refresh");
    await encodeSparse("delta", "org-refresh");

    expect(findManyMock).toHaveBeenCalledTimes(2);
  });

  it("returns an empty vector for an org with no corpus (falls back gracefully)", async () => {
    findManyMock.mockResolvedValueOnce([]);
    const v = await encodeSparse("anything at all", "org-empty");
    // No corpus → IDF map is empty → fallback IDF=1, so we still get TF terms.
    expect(v.indices.length).toBeGreaterThan(0);
  });
});
