import { describe, expect, it, beforeEach, vi } from "vitest";

// ---------------------------------------------------------------------------
// Mocks. We deliberately mock the prisma client so we can control the matched
// Question rows and assert on the exact number of DB calls (the cache test).
// ---------------------------------------------------------------------------

const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    question: {
      findFirst: vi.fn(),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

// Reset the env-cache between tests so OUTCOME_BOOST_WON / OUTCOME_BOOST_LOST
// changes are picked up. (Boosts are read on each call by design — see
// outcome-boost.ts comment.)
import { _resetEnvCacheForTests } from "@/lib/env";

import {
  coachingNoteForGoldenAnswer,
  createOutcomeBoostCache,
  normalizeQuestion,
  outcomeBoostForGoldenAnswer,
  reorderGoldensByOutcome,
} from "./outcome-boost";

const ORG_ID = "org-1";

beforeEach(() => {
  vi.clearAllMocks();
  _resetEnvCacheForTests();
  // Defaults — explicit so tests don't depend on prior process.env state.
  process.env.OUTCOME_BOOST_WON = "0.2";
  process.env.OUTCOME_BOOST_LOST = "-0.2";
});

// ---------------------------------------------------------------------------
// Boost values.
// ---------------------------------------------------------------------------

describe("outcomeBoostForGoldenAnswer — boost values", () => {
  it("returns +0.2 when the matched question came from a WON RFP", async () => {
    prismaMock.question.findFirst.mockResolvedValueOnce({ rfp: { outcome: "WON" } });
    const boost = await outcomeBoostForGoldenAnswer(ORG_ID, {
      id: "g-1",
      question: "Do you encrypt data at rest?",
    });
    expect(boost).toBe(0.2);
    expect(prismaMock.question.findFirst).toHaveBeenCalledTimes(1);
  });

  it("returns -0.2 when the matched question came from a LOST RFP", async () => {
    prismaMock.question.findFirst.mockResolvedValueOnce({ rfp: { outcome: "LOST" } });
    const boost = await outcomeBoostForGoldenAnswer(ORG_ID, {
      id: "g-2",
      question: "What is your SLA?",
    });
    expect(boost).toBe(-0.2);
  });

  it("returns 0 when no matching question is found in the org", async () => {
    prismaMock.question.findFirst.mockResolvedValueOnce(null);
    const boost = await outcomeBoostForGoldenAnswer(ORG_ID, {
      id: "g-3",
      question: "Brand-new question never asked before",
    });
    expect(boost).toBe(0);
  });

  it.each(["PENDING", "WITHDRAWN", "NO_BID"] as const)(
    "returns 0 for non-decisive outcome %s",
    async (outcome) => {
      prismaMock.question.findFirst.mockResolvedValueOnce({ rfp: { outcome } });
      const boost = await outcomeBoostForGoldenAnswer(ORG_ID, {
        id: `g-${outcome}`,
        question: "anything",
      });
      expect(boost).toBe(0);
    },
  );

  it("respects OUTCOME_BOOST_WON / OUTCOME_BOOST_LOST env overrides", async () => {
    process.env.OUTCOME_BOOST_WON = "0.5";
    process.env.OUTCOME_BOOST_LOST = "-0.4";
    _resetEnvCacheForTests();
    prismaMock.question.findFirst
      .mockResolvedValueOnce({ rfp: { outcome: "WON" } })
      .mockResolvedValueOnce({ rfp: { outcome: "LOST" } });
    const won = await outcomeBoostForGoldenAnswer(ORG_ID, {
      id: "g-w",
      question: "X",
    });
    const lost = await outcomeBoostForGoldenAnswer(ORG_ID, {
      id: "g-l",
      question: "Y",
    });
    expect(won).toBe(0.5);
    expect(lost).toBe(-0.4);
  });
});

// ---------------------------------------------------------------------------
// Cache.
// ---------------------------------------------------------------------------

describe("outcomeBoostForGoldenAnswer — caching", () => {
  it("queries the DB once when the same golden is looked up twice in a generation call", async () => {
    prismaMock.question.findFirst.mockResolvedValueOnce({ rfp: { outcome: "WON" } });
    const cache = createOutcomeBoostCache();
    const golden = { id: "g-cache", question: "Repeated question" };

    const a = await outcomeBoostForGoldenAnswer(ORG_ID, golden, cache);
    const b = await outcomeBoostForGoldenAnswer(ORG_ID, golden, cache);

    expect(a).toBe(0.2);
    expect(b).toBe(0.2);
    // The DB was hit once across both calls — the second resolved from cache.
    expect(prismaMock.question.findFirst).toHaveBeenCalledTimes(1);
  });

  it("falls back to the normalized question text as a cache key when id is absent", async () => {
    prismaMock.question.findFirst.mockResolvedValueOnce({ rfp: { outcome: "LOST" } });
    const cache = createOutcomeBoostCache();
    const a = await outcomeBoostForGoldenAnswer(
      ORG_ID,
      { question: "Same question with different casing" },
      cache,
    );
    const b = await outcomeBoostForGoldenAnswer(
      ORG_ID,
      { question: "  same question with different CASING " },
      cache,
    );
    expect(a).toBe(-0.2);
    expect(b).toBe(-0.2);
    expect(prismaMock.question.findFirst).toHaveBeenCalledTimes(1);
  });
});

// ---------------------------------------------------------------------------
// reorderGoldensByOutcome.
// ---------------------------------------------------------------------------

describe("reorderGoldensByOutcome", () => {
  it("floats WON-derived goldens to the top and sinks LOST", async () => {
    // Three goldens. lookups are issued in input order: pending, won, lost.
    prismaMock.question.findFirst
      .mockResolvedValueOnce({ rfp: { outcome: "PENDING" } })
      .mockResolvedValueOnce({ rfp: { outcome: "WON" } })
      .mockResolvedValueOnce({ rfp: { outcome: "LOST" } });

    const goldens = [
      { id: "g-pending", question: "p", answer: "..." },
      { id: "g-won", question: "w", answer: "..." },
      { id: "g-lost", question: "l", answer: "..." },
    ];
    const reordered = await reorderGoldensByOutcome(ORG_ID, goldens);

    expect(reordered.map((g) => g.id)).toEqual(["g-won", "g-pending", "g-lost"]);
    expect(reordered.map((g) => g.outcomeBoost)).toEqual([0.2, 0, -0.2]);
  });

  it("preserves input order as a tiebreaker when boosts are equal", async () => {
    prismaMock.question.findFirst
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null);
    const goldens = [
      { id: "a", question: "a", answer: "..." },
      { id: "b", question: "b", answer: "..." },
      { id: "c", question: "c", answer: "..." },
    ];
    const reordered = await reorderGoldensByOutcome(ORG_ID, goldens);
    expect(reordered.map((g) => g.id)).toEqual(["a", "b", "c"]);
  });
});

// ---------------------------------------------------------------------------
// coachingNoteForGoldenAnswer.
// ---------------------------------------------------------------------------

describe("coachingNoteForGoldenAnswer", () => {
  it("returns a note pointing at the LOST RFP when a match exists", async () => {
    prismaMock.question.findFirst.mockResolvedValueOnce({
      rfp: { id: "rfp-lost-1", title: "Mega Corp 2024" },
    });
    const note = await coachingNoteForGoldenAnswer(ORG_ID, {
      id: "g-lost-1",
      question: "Describe your DR plan.",
    });
    expect(note).not.toBeNull();
    expect(note!.rfpId).toBe("rfp-lost-1");
    expect(note!.rfpTitle).toBe("Mega Corp 2024");
    expect(note!.note).toContain("lost");
    expect(note!.note).toContain("Mega Corp 2024");
  });

  it("returns null when no LOST match exists", async () => {
    prismaMock.question.findFirst.mockResolvedValueOnce(null);
    const note = await coachingNoteForGoldenAnswer(ORG_ID, {
      question: "Brand-new question",
    });
    expect(note).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// normalizeQuestion (small unit, included so the equality contract is pinned).
// ---------------------------------------------------------------------------

describe("normalizeQuestion", () => {
  it("lowercases, collapses whitespace, and strips punctuation", () => {
    expect(normalizeQuestion("  How do you encrypt data at REST? ")).toBe(
      "how do you encrypt data at rest",
    );
    expect(normalizeQuestion("a   b\tc")).toBe("a b c");
  });
});
