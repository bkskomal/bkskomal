// Cross-reference detection across a multi-document RFP package.
//
// A primary RFP carries questions; its attachments (security questionnaire,
// addendum, pricing matrix, …) carry context that may or may not also speak
// to those questions. This module provides the cheap heuristic that surfaces
// "this question is also asked / mentioned in the security questionnaire"
// hints in the UI, without going through the LLM.
//
// Approach:
//   * For each Question on the primary RFP, build a small set of keyword
//     tokens drawn from the question text (≥4 chars, deduped, stop-words
//     filtered). For each attachment, scan its rawText for the longest
//     matching span and return a snippet around it if at least 2 tokens hit.
//   * The result is a list of HINTS, not authoritative links — the UI
//     renders them as soft badges; nothing in generation depends on them.
//
// We cache results per primary RFP keyed by (rfpId, attachmentSignature) to
// avoid re-scanning rawText on every render. The signature is the count +
// max(updatedAt) of attachments — cheap to recompute, invalidated when any
// attachment changes. No DB schema change.

import { prisma } from "@/lib/prisma";

export interface CrossRef {
  /** Question on the primary RFP this match was found for. */
  primaryQuestionId: string;
  /** The attachment RFP that contained the match. */
  attachmentRfpId: string;
  /** Heuristic question number on the attachment when discoverable, else undefined. */
  attachmentQuestionNumber?: number;
  /** Up-to ~240 char excerpt around the matching span. */
  attachmentSnippet: string;
  /** Brief human-readable note ("4 keywords matched: encryption, key, rotation, hsm"). */
  reason: string;
}

interface CacheEntry {
  signature: string;
  refs: CrossRef[];
  hits: number;
}

const cache = new Map<string, CacheEntry>();

/** Visible to tests for resetting between runs. */
export function _resetCrossRefCacheForTests(): void {
  cache.clear();
}

/** Expose hit counter for test verification of cache behavior. */
export function _getCrossRefCacheStats(rfpId: string): { hits: number } | null {
  const entry = cache.get(rfpId);
  return entry ? { hits: entry.hits } : null;
}

const STOP_WORDS = new Set([
  "the", "and", "for", "with", "that", "this", "from", "your", "have", "what",
  "when", "where", "which", "will", "shall", "must", "should", "would", "could",
  "into", "about", "their", "they", "them", "describe", "provide", "explain",
  "demonstrate", "confirm", "vendor", "vendors", "rfp", "please", "include",
  "support", "supports", "supported", "company", "companies", "section",
  "question", "questions", "respond", "response", "responses",
]);

/**
 * Tokenize question text into the minimal interesting keywords for substring
 * matching. We lowercase, strip punctuation, drop short words and stop-words,
 * and dedupe. Cap at ~12 tokens to keep the per-question scan cheap.
 */
function tokenize(text: string): string[] {
  const tokens = text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length >= 4 && !STOP_WORDS.has(t));
  const seen = new Set<string>();
  const out: string[] = [];
  for (const t of tokens) {
    if (seen.has(t)) continue;
    seen.add(t);
    out.push(t);
    if (out.length >= 12) break;
  }
  return out;
}

/**
 * Find the index of the densest cluster of token hits inside `text`. Returns
 * { center, hits } where center is a character offset in the text near which
 * to anchor the snippet. If fewer than `min` distinct tokens are found,
 * returns null.
 */
function findCluster(
  text: string,
  tokens: string[],
  min: number,
): { center: number; hitTokens: string[] } | null {
  if (tokens.length < min) return null;
  const lower = text.toLowerCase();
  const positions: { token: string; pos: number }[] = [];
  for (const t of tokens) {
    const p = lower.indexOf(t);
    if (p >= 0) positions.push({ token: t, pos: p });
  }
  if (positions.length < min) return null;
  // Pick the position with the most other tokens inside a 600-char window.
  let best = { center: positions[0].pos, hitTokens: [positions[0].token] };
  for (const anchor of positions) {
    const within = positions.filter((p) => Math.abs(p.pos - anchor.pos) <= 600);
    const distinctTokens = Array.from(new Set(within.map((w) => w.token)));
    if (distinctTokens.length > best.hitTokens.length) {
      best = { center: anchor.pos, hitTokens: distinctTokens };
    }
  }
  return best.hitTokens.length >= min ? best : null;
}

const SNIPPET_RADIUS = 120;

function snippetAround(text: string, center: number): string {
  const start = Math.max(0, center - SNIPPET_RADIUS);
  const end = Math.min(text.length, center + SNIPPET_RADIUS);
  let s = text.slice(start, end).replace(/\s+/g, " ").trim();
  if (start > 0) s = "…" + s;
  if (end < text.length) s = s + "…";
  return s;
}

// Capture leading numbering that looks like an attachment-question id ("3.2",
// "12)", "Q14"). Best-effort — undefined when the surrounding text doesn't
// contain something parseable.
const NUMBER_NEAR = /(?:^|[\n\r])\s*(?:Q[._-]?)?(\d{1,3})(?:[.)\]]|\s)/i;
function nearestQuestionNumber(text: string, center: number): number | undefined {
  // Look back up to 200 chars for a leading numbering token.
  const start = Math.max(0, center - 200);
  const window = text.slice(start, center + 40);
  const m = NUMBER_NEAR.exec(window);
  if (!m) return undefined;
  const n = parseInt(m[1], 10);
  return Number.isFinite(n) ? n : undefined;
}

interface Input {
  rfpId: string;
  organizationId: string;
}

export async function findCrossReferences(input: Input): Promise<CrossRef[]> {
  // Resolve the primary RFP (callers may pass an attachment id; we walk up).
  const rfp = await prisma.rFP.findUnique({
    where: { id: input.rfpId },
    select: {
      id: true,
      parentRfpId: true,
      project: { select: { organizationId: true } },
    },
  });
  if (!rfp) return [];
  // Org gate — caller asserted org but we double-check.
  if (rfp.project.organizationId !== input.organizationId) return [];

  const primaryId = rfp.parentRfpId ?? rfp.id;

  const attachments = await prisma.rFP.findMany({
    where: { parentRfpId: primaryId },
    select: { id: true, rawText: true, docRole: true, updatedAt: true },
    orderBy: { createdAt: "asc" },
  });
  if (attachments.length === 0) return [];

  // Cache signature: rebuild when any attachment text changes.
  const signature = `${attachments.length}:${Math.max(
    ...attachments.map((a) => a.updatedAt.getTime()),
  )}`;
  const cached = cache.get(primaryId);
  if (cached && cached.signature === signature) {
    cached.hits += 1;
    return cached.refs;
  }

  const questions = await prisma.question.findMany({
    where: { rfpId: primaryId },
    select: { id: true, text: true },
  });
  if (questions.length === 0) {
    cache.set(primaryId, { signature, refs: [], hits: 0 });
    return [];
  }

  const refs: CrossRef[] = [];
  for (const q of questions) {
    const tokens = tokenize(q.text);
    if (tokens.length < 2) continue;
    for (const a of attachments) {
      if (!a.rawText) continue;
      const cluster = findCluster(a.rawText, tokens, 2);
      if (!cluster) continue;
      const snippet = snippetAround(a.rawText, cluster.center);
      const number = nearestQuestionNumber(a.rawText, cluster.center);
      refs.push({
        primaryQuestionId: q.id,
        attachmentRfpId: a.id,
        attachmentQuestionNumber: number,
        attachmentSnippet: snippet,
        reason: `${cluster.hitTokens.length} keyword${cluster.hitTokens.length === 1 ? "" : "s"} matched: ${cluster.hitTokens.slice(0, 4).join(", ")}`,
      });
    }
  }

  cache.set(primaryId, { signature, refs, hits: 0 });
  return refs;
}
