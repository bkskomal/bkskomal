import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  PROVIDERS,
  PROVIDER_DEFS,
  defaultProvider,
  detectProviderFromUrl,
  inferProviderFromUrl,
} from "./providers";

describe("detectProviderFromUrl", () => {
  it("identifies each known provider by URL", () => {
    expect(detectProviderFromUrl("http://localhost:11434/v1")).toBe("ollama");
    expect(detectProviderFromUrl("https://openrouter.ai/api/v1")).toBe("openrouter");
    expect(detectProviderFromUrl("https://api.openai.com/v1")).toBe("openai");
    expect(detectProviderFromUrl("http://localhost:1234/v1")).toBe("lmstudio");
    expect(detectProviderFromUrl("http://localhost:8080/v1")).toBe("localai");
    expect(detectProviderFromUrl("http://localhost:8000/v1")).toBe("vllm");
    expect(detectProviderFromUrl("local://transformers")).toBe("local");
  });

  it("falls back to 'custom' for unknown / empty input", () => {
    expect(detectProviderFromUrl("")).toBe("custom");
    expect(detectProviderFromUrl(null)).toBe("custom");
    expect(detectProviderFromUrl(undefined)).toBe("custom");
    expect(detectProviderFromUrl("https://example.com/api")).toBe("custom");
  });

  it("is case-insensitive", () => {
    expect(detectProviderFromUrl("HTTP://LOCALHOST:11434/V1")).toBe("ollama");
    expect(detectProviderFromUrl("HTTPS://OPENROUTER.AI/api/v1")).toBe("openrouter");
  });
});

describe("inferProviderFromUrl (legacy AiProvider shape)", () => {
  it("maps URLs to AiProvider enum values", () => {
    expect(inferProviderFromUrl("http://localhost:11434/v1")).toBe("OLLAMA");
    expect(inferProviderFromUrl("https://openrouter.ai/api/v1")).toBe("OPENROUTER");
    expect(inferProviderFromUrl("https://api.openai.com/v1")).toBe("OPENAI");
    expect(inferProviderFromUrl("local://transformers")).toBe("LOCAL");
    expect(inferProviderFromUrl(null)).toBe("CUSTOM");
  });
});

describe("defaultProvider", () => {
  const originalEnv = process.env.LLM_BASE_URL;

  beforeEach(() => {
    delete process.env.LLM_BASE_URL;
  });

  afterEach(() => {
    if (originalEnv === undefined) delete process.env.LLM_BASE_URL;
    else process.env.LLM_BASE_URL = originalEnv;
  });

  it("returns Ollama when no env override is set", () => {
    expect(defaultProvider().id).toBe("ollama");
  });

  it("honours LLM_BASE_URL when it points at OpenRouter", () => {
    process.env.LLM_BASE_URL = "https://openrouter.ai/api/v1";
    expect(defaultProvider().id).toBe("openrouter");
  });

  it("honours LLM_BASE_URL when it points at OpenAI", () => {
    process.env.LLM_BASE_URL = "https://api.openai.com/v1";
    expect(defaultProvider().id).toBe("openai");
  });

  it("falls back to Ollama when env URL is empty/whitespace", () => {
    process.env.LLM_BASE_URL = "   ";
    expect(defaultProvider().id).toBe("ollama");
  });
});

describe("PROVIDERS catalog invariants", () => {
  it("has every AiProvider key present and well-formed", () => {
    const ids = ["OPENROUTER", "OPENAI", "OLLAMA", "VLLM", "LMSTUDIO", "LOCALAI", "LOCAL", "CUSTOM"];
    for (const id of ids) {
      const p = PROVIDERS[id as keyof typeof PROVIDERS];
      expect(p, `missing provider ${id}`).toBeTruthy();
      expect(p.id).toBe(id);
      expect(typeof p.label).toBe("string");
      expect(typeof p.shortId).toBe("string");
      expect(typeof p.requiresApiKey).toBe("boolean");
      expect(typeof p.isLocal).toBe("boolean");
      expect(Array.isArray(p.llmModels)).toBe(true);
    }
  });

  it("flags Ollama as local + key-less", () => {
    expect(PROVIDERS.OLLAMA.isLocal).toBe(true);
    expect(PROVIDERS.OLLAMA.requiresApiKey).toBe(false);
    expect(PROVIDERS.OLLAMA.shortId).toBe("ollama");
    expect(PROVIDERS.OLLAMA.llmBaseUrl).toBe("http://localhost:11434/v1");
    // Recommended models include the lightweight defaults the docs reference.
    expect(PROVIDERS.OLLAMA.llmModels).toContain("llama3.2");
  });

  it("flags hosted providers as non-local + key-required", () => {
    expect(PROVIDERS.OPENAI.isLocal).toBe(false);
    expect(PROVIDERS.OPENAI.requiresApiKey).toBe(true);
    expect(PROVIDERS.OPENROUTER.isLocal).toBe(false);
    expect(PROVIDERS.OPENROUTER.requiresApiKey).toBe(true);
  });
});

describe("PROVIDER_DEFS shape", () => {
  it("ranks Ollama first", () => {
    expect(PROVIDER_DEFS[0]?.id).toBe("ollama");
  });

  it("includes the seven non-LOCAL providers expected by the picker", () => {
    const ids = PROVIDER_DEFS.map((p) => p.id);
    for (const id of ["ollama", "openrouter", "openai", "lmstudio", "vllm", "localai", "custom"]) {
      expect(ids, `missing def ${id}`).toContain(id);
    }
  });

  it("each def carries the required ProviderDef fields", () => {
    for (const def of PROVIDER_DEFS) {
      expect(def.label.length).toBeGreaterThan(0);
      expect(typeof def.baseUrl).toBe("string");
      expect(typeof def.requiresApiKey).toBe("boolean");
      expect(typeof def.isLocal).toBe("boolean");
      expect(Array.isArray(def.recommendedModels)).toBe(true);
      expect(typeof def.description).toBe("string");
    }
  });
});
