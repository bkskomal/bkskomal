// Native Ollama API helpers.
//
// Ollama exposes two API surfaces: an OpenAI-compatible one at /v1 and a
// native one at /api. We use the OpenAI surface for chat/embeddings (via the
// OpenAI SDK) and the native surface here for the bits the OpenAI surface
// doesn't cover: listing locally-installed models, pulling new ones, and
// probing whether the daemon is up.
//
// All functions accept a `baseUrl` that may include or omit the trailing
// `/v1`. We normalise by stripping a trailing `/v1` so callers can pass the
// same URL they store in OrgAiConfig.

/** Strip a trailing `/v1` (and any trailing slash) from an Ollama base URL. */
export function nativeBaseUrl(baseUrl: string): string {
  return baseUrl.replace(/\/+$/, "").replace(/\/v1$/, "");
}

export interface OllamaModelInfo {
  name: string;
  sizeBytes: number;
  modifiedAt: string;
}

interface RawTagsResponse {
  models?: Array<{
    name?: string;
    model?: string;
    size?: number;
    modified_at?: string;
  }>;
}

/**
 * List models that are already pulled into the local Ollama daemon. Hits the
 * native `/api/tags` endpoint (the OpenAI `/v1/models` endpoint also works,
 * but doesn't expose `size` or `modified_at`).
 */
export async function listOllamaModels(baseUrl: string): Promise<OllamaModelInfo[]> {
  const root = nativeBaseUrl(baseUrl);
  const res = await fetch(`${root}/api/tags`);
  if (!res.ok) {
    throw new Error(`Ollama /api/tags responded ${res.status} ${res.statusText}`);
  }
  const data = (await res.json()) as RawTagsResponse;
  const models = Array.isArray(data?.models) ? data.models : [];
  return models
    .map((m) => ({
      name: String(m.name ?? m.model ?? ""),
      sizeBytes: typeof m.size === "number" ? m.size : 0,
      modifiedAt: String(m.modified_at ?? ""),
    }))
    .filter((m) => m.name.length > 0)
    .sort((a, b) => a.name.localeCompare(b.name));
}

export interface OllamaPullProgress {
  status: string;
  /** 0..1 fractional progress when known. */
  pct?: number;
  digest?: string;
  total?: number;
  completed?: number;
}

interface RawPullChunk {
  status?: string;
  digest?: string;
  total?: number;
  completed?: number;
  error?: string;
}

/**
 * Pull a model into the local Ollama daemon. Streams progress chunks from
 * `/api/pull`. The optional `onProgress` callback is invoked with a
 * fractional 0..1 percentage whenever a chunk reports a `total` and
 * `completed`. Resolves when the stream ends; rejects if the server emits an
 * `error` field.
 */
export async function pullOllamaModel(
  baseUrl: string,
  name: string,
  onProgress?: (pct: number) => void,
): Promise<void> {
  for await (const chunk of streamPullProgress(baseUrl, name)) {
    if (
      onProgress &&
      typeof chunk.total === "number" &&
      typeof chunk.completed === "number" &&
      chunk.total > 0
    ) {
      onProgress(Math.min(1, Math.max(0, chunk.completed / chunk.total)));
    }
  }
}

/**
 * Streaming variant of `pullOllamaModel` — yields each progress chunk so
 * callers (e.g. the SSE pull route) can forward them. Throws if the daemon
 * returns an error chunk.
 */
export async function* streamPullProgress(
  baseUrl: string,
  name: string,
): AsyncGenerator<OllamaPullProgress, void, void> {
  const root = nativeBaseUrl(baseUrl);
  const res = await fetch(`${root}/api/pull`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name, stream: true }),
  });
  if (!res.ok || !res.body) {
    throw new Error(`Ollama /api/pull responded ${res.status} ${res.statusText}`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    // Ollama emits one JSON object per line. Buffer until we see a newline,
    // then emit each complete line. Keep the trailing partial chunk in the
    // buffer for the next read.
    let idx: number;
    while ((idx = buffer.indexOf("\n")) >= 0) {
      const line = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 1);
      if (!line) continue;
      const parsed = parsePullLine(line);
      if (parsed) yield parsed;
    }
  }

  // Drain anything left in the buffer (Ollama sometimes omits a trailing newline).
  const tail = buffer.trim();
  if (tail) {
    const parsed = parsePullLine(tail);
    if (parsed) yield parsed;
  }
}

function parsePullLine(line: string): OllamaPullProgress | null {
  let raw: RawPullChunk;
  try {
    raw = JSON.parse(line) as RawPullChunk;
  } catch {
    return null;
  }
  if (raw.error) {
    throw new Error(`Ollama pull error: ${raw.error}`);
  }
  const out: OllamaPullProgress = { status: String(raw.status ?? "") };
  if (typeof raw.digest === "string") out.digest = raw.digest;
  if (typeof raw.total === "number") out.total = raw.total;
  if (typeof raw.completed === "number") out.completed = raw.completed;
  if (out.total && out.completed !== undefined && out.total > 0) {
    out.pct = Math.min(1, Math.max(0, (out.completed ?? 0) / out.total));
  }
  return out;
}

export type PingResult =
  | { ok: true; version: string }
  | { ok: false; error: string };

/**
 * Probe an Ollama daemon's `/api/version` endpoint. Returns a tagged result
 * — never throws — so callers (including instrumentation) can treat
 * "Ollama not running" as a soft signal rather than an exception.
 */
export async function pingOllama(baseUrl: string, timeoutMs = 1500): Promise<PingResult> {
  const root = nativeBaseUrl(baseUrl);
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const res = await fetch(`${root}/api/version`, { signal: ac.signal });
    if (!res.ok) {
      return { ok: false, error: `HTTP ${res.status} ${res.statusText}` };
    }
    const data = (await res.json()) as { version?: string };
    return { ok: true, version: String(data?.version ?? "unknown") };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { ok: false, error: msg };
  } finally {
    clearTimeout(timer);
  }
}
