// Bulk response generation. Runs in-process with bounded concurrency. For
// production scale you'd move this to a queue (BullMQ, pg-boss, etc.) — the
// surface here is purely an ID-taking function so swapping is mechanical.

import { prisma } from "@/lib/prisma";
import { generateResponse } from "./generate";
import { logActivity } from "@/lib/activity";
import { notify } from "@/lib/notifications/service";
import { advance as advancePipeline } from "@/lib/pipeline/engine";

// Concurrency for in-process bulk generation. Lower this when the upstream LLM
// provider is sensitive to bursts (e.g. OpenRouter free tier, smaller paid
// plans). 2 is a safe default that won't trip rate limits on most providers.
// Override via env: BULK_GENERATE_CONCURRENCY=4 (or 1 to fully serialize).
const PARALLELISM = Math.max(
  1,
  Math.min(8, Number(process.env.BULK_GENERATE_CONCURRENCY ?? "2")),
);

// Exponential-backoff retry config for transient LLM failures (429, 5xx,
// network drops). Retries are PER QUESTION inside the worker, so they don't
// block other questions in the queue — they just take longer for the one
// being retried.
const MAX_RETRIES = 3;        // 1 try + 3 retries = 4 total attempts
const BACKOFF_BASE_MS = 2000; // 1st retry 2s, 2nd 4s, 3rd 8s
const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);
const RETRYABLE_ERROR_CODES = new Set([
  "ECONNRESET", "ETIMEDOUT", "EAI_AGAIN", "ENOTFOUND",
]);

function isRetryable(err: unknown): boolean {
  if (!err || typeof err !== "object") return false;
  const e = err as { status?: number; code?: string | number; message?: string };
  if (typeof e.status === "number" && RETRYABLE_STATUS.has(e.status)) return true;
  if (typeof e.code === "string" && RETRYABLE_ERROR_CODES.has(e.code)) return true;
  // OpenRouter / OpenAI SDK sometimes surfaces 429 as a string in the message
  if (typeof e.message === "string" && /\b429\b|rate.?limit|too many requests/i.test(e.message)) {
    return true;
  }
  return false;
}

async function generateWithRetry(
  questionId: string,
  indexId: string | null,
  enableTools: boolean,
  actorId: string,
): Promise<void> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      await generateOne(questionId, indexId, enableTools, actorId);
      return;
    } catch (e) {
      lastErr = e;
      if (attempt === MAX_RETRIES || !isRetryable(e)) throw e;
      const wait = BACKOFF_BASE_MS * Math.pow(2, attempt) + Math.floor(Math.random() * 500);
      console.warn(
        `[bulk] question ${questionId} attempt ${attempt + 1} failed (${(e as { status?: number }).status ?? "?"}), retrying in ${wait}ms`,
      );
      await new Promise((r) => setTimeout(r, wait));
    }
  }
  throw lastErr;
}

interface RunOpts {
  bulkId: string;
}

const inFlight = new Map<string, AbortController>();

export function isRunning(bulkId: string): boolean {
  return inFlight.has(bulkId);
}

export function cancelBulk(bulkId: string): boolean {
  const ac = inFlight.get(bulkId);
  if (!ac) return false;
  ac.abort();
  return true;
}

export async function runBulkGeneration({ bulkId }: RunOpts): Promise<void> {
  const ac = new AbortController();
  inFlight.set(bulkId, ac);

  const bulkRow = await prisma.bulkGeneration.findUnique({
    where: { id: bulkId },
    include: { rfp: { include: { project: true } } },
  });
  if (!bulkRow) {
    inFlight.delete(bulkId);
    return;
  }
  const bulk = bulkRow;

  await prisma.bulkGeneration.update({
    where: { id: bulkId },
    data: { status: "RUNNING", total: bulk.questionIds.length },
  });

  void logActivity({
    rfpId: bulk.rfpId,
    actorId: bulk.startedById,
    kind: "BULK_GENERATION_STARTED",
    payload: { bulkId, total: bulk.questionIds.length },
  });

  let completed = 0;
  let failed = 0;
  const queue = [...bulk.questionIds];

  async function worker() {
    while (queue.length > 0) {
      if (ac.signal.aborted) return;
      const questionId = queue.shift();
      if (!questionId) return;
      try {
        await generateWithRetry(questionId, bulk.indexId, bulk.enableTools, bulk.startedById);
        completed++;
      } catch (e) {
        console.error("[bulk] question failed after retries:", questionId, e);
        failed++;
      }
      await prisma.bulkGeneration.update({
        where: { id: bulkId },
        data: { completed, failed },
      });
    }
  }

  const workers = Array.from({ length: PARALLELISM }, () => worker());
  await Promise.all(workers);

  const finalStatus = ac.signal.aborted ? "CANCELED" : failed === bulk.questionIds.length ? "FAILED" : "COMPLETED";
  await prisma.bulkGeneration.update({
    where: { id: bulkId },
    data: {
      status: finalStatus,
      completed,
      failed,
      finishedAt: new Date(),
    },
  });

  void logActivity({
    rfpId: bulk.rfpId,
    actorId: bulk.startedById,
    kind: "BULK_GENERATION_COMPLETED",
    payload: { bulkId, total: bulk.questionIds.length, completed, failed, status: finalStatus },
  });

  if (finalStatus === "COMPLETED" || finalStatus === "FAILED") {
    void notify({
      ctx: {
        userId: bulk.startedById,
        organizationId: bulk.rfp.project.organizationId,
        rfpId: bulk.rfpId,
      },
      payload: {
        kind: "BULK_GENERATION_COMPLETED",
        data: {
          rfpTitle: bulk.rfp.title,
          completed,
          failed,
          total: bulk.questionIds.length,
        },
      },
    });
  }

  void advancePipeline(bulk.rfpId);

  inFlight.delete(bulkId);
}

async function generateOne(
  questionId: string,
  indexId: string | null,
  enableTools: boolean,
  userId: string,
): Promise<void> {
  const question = await prisma.question.findUnique({
    where: { id: questionId },
    include: { rfp: { include: { project: true } } },
  });
  if (!question) return;

  const orgId = question.rfp.project.organizationId;
  const useIndex = indexId ?? question.rfp.project.defaultIndexId ?? null;

  const draft = await prisma.response.create({
    data: { questionId, indexId: useIndex, status: "GENERATING", content: "" },
  });

  try {
    // Semantic golden lookup — finds the most relevant past Q&A even when
    // the new question is worded completely differently. Falls back to
    // recency for orgs whose goldens aren't embedded yet (legacy rows).
    const { findRelevantGoldens } = await import("./golden-search");
    const goldenAnswers = await findRelevantGoldens({
      organizationId: orgId,
      questionText: question.text,
      take: 6,
    });

    const result = await generateResponse({
      question: question.text,
      indexId: useIndex,
      goldenAnswers,
      enableTools,
      // Pass through extractor complexity for model routing (Phase 3B).
      complexity:
        question.complexity === "simple" ||
        question.complexity === "moderate" ||
        question.complexity === "complex"
          ? question.complexity
          : undefined,
      ctx: {
        organizationId: orgId,
        projectId: question.rfp.projectId,
        rfpId: question.rfpId,
        defaultIndexId: useIndex,
        userId,
      },
    });

    await prisma.response.update({
      where: { id: draft.id },
      data: {
        status: "COMPLETED",
        content: result.content,
        reasoning: result.reasoning as never,
        confidence: result.confidence,
        needsReview: result.needsReview,
        // Persist grounding (when the judge succeeded) — same shape as the
        // streaming generate route.
        ...(result.grounding
          ? {
              groundingScore: result.grounding.score,
              groundingNotes: result.grounding.claims as never,
              groundingAt: new Date(),
            }
          : {}),
        sources: {
          create: result.sources.map((s) => ({
            chunkId: s.id,
            score: s.score,
            excerpt: s.content.slice(0, 1000),
            fileName: s.fileName,
            page: s.page,
          })),
        },
      },
    });

    await prisma.question.update({
      where: { id: questionId },
      data: {
        confidence: result.confidence,
        // If the question was untouched, mark IN_PROGRESS to nudge reviewers.
        status: question.status === "TODO" ? "IN_PROGRESS" : question.status,
      },
    });
  } catch (e) {
    await prisma.response.update({
      where: { id: draft.id },
      data: {
        status: "FAILED",
        content: `_Bulk generation failed: ${e instanceof Error ? e.message : String(e)}_`,
      },
    });
    throw e;
  }
}
