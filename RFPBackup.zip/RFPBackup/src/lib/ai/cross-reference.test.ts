import { describe, expect, it, beforeEach, vi } from "vitest";

const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
      findMany: vi.fn(),
    },
    question: {
      findMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

import {
  findCrossReferences,
  _resetCrossRefCacheForTests,
  _getCrossRefCacheStats,
} from "./cross-reference";

const ORG_ID = "org-1";
const PRIMARY_ID = "rfp-primary";
const ATTACHMENT_ID = "rfp-att";

beforeEach(() => {
  _resetCrossRefCacheForTests();
  vi.clearAllMocks();
  prismaMock.rFP.findUnique.mockResolvedValue({
    id: PRIMARY_ID,
    parentRfpId: null,
    project: { organizationId: ORG_ID },
  });
});

describe("findCrossReferences — substring/keyword matching", () => {
  it("returns hits when attachment text contains the question's keywords", async () => {
    prismaMock.rFP.findMany.mockResolvedValueOnce([
      {
        id: ATTACHMENT_ID,
        rawText:
          "Q14: Describe key rotation policies and HSM usage for encryption keys at rest. Vendors must support automated rotation.",
        docRole: "SECURITY_QUESTIONNAIRE",
        updatedAt: new Date("2026-01-01T00:00:00Z"),
      },
    ]);
    prismaMock.question.findMany.mockResolvedValueOnce([
      {
        id: "q1",
        text: "Describe your encryption key rotation policy and HSM usage.",
      },
    ]);

    const refs = await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: ORG_ID });
    expect(refs).toHaveLength(1);
    expect(refs[0].primaryQuestionId).toBe("q1");
    expect(refs[0].attachmentRfpId).toBe(ATTACHMENT_ID);
    expect(refs[0].reason).toMatch(/keyword/);
    expect(refs[0].attachmentSnippet.toLowerCase()).toContain("encryption");
  });

  it("returns an empty list when nothing matches", async () => {
    prismaMock.rFP.findMany.mockResolvedValueOnce([
      {
        id: ATTACHMENT_ID,
        rawText: "Pricing breakdown for Year 1 and Year 2 including discounts and SKUs.",
        docRole: "PRICING_MATRIX",
        updatedAt: new Date("2026-01-01T00:00:00Z"),
      },
    ]);
    prismaMock.question.findMany.mockResolvedValueOnce([
      { id: "q1", text: "Describe your data residency posture and SOC2 audit cadence." },
    ]);
    const refs = await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: ORG_ID });
    expect(refs).toEqual([]);
  });

  it("returns an empty list when the RFP has no attachments at all", async () => {
    prismaMock.rFP.findMany.mockResolvedValueOnce([]);
    const refs = await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: ORG_ID });
    expect(refs).toEqual([]);
    // Skipped the question lookup because no attachments meant no work to do.
    expect(prismaMock.question.findMany).not.toHaveBeenCalled();
  });

  it("walks up to the primary when given an attachment id", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce({
      id: ATTACHMENT_ID,
      parentRfpId: PRIMARY_ID,
      project: { organizationId: ORG_ID },
    });
    prismaMock.rFP.findMany.mockResolvedValueOnce([
      {
        id: ATTACHMENT_ID,
        rawText: "encryption key rotation HSM",
        docRole: "SECURITY_QUESTIONNAIRE",
        updatedAt: new Date("2026-01-01T00:00:00Z"),
      },
    ]);
    prismaMock.question.findMany.mockResolvedValueOnce([
      { id: "q1", text: "Describe encryption key rotation." },
    ]);
    const refs = await findCrossReferences({ rfpId: ATTACHMENT_ID, organizationId: ORG_ID });
    // The findMany for attachments should have been keyed off the PRIMARY id.
    expect(prismaMock.rFP.findMany.mock.calls[0][0].where).toEqual({ parentRfpId: PRIMARY_ID });
    expect(refs.length).toBeGreaterThan(0);
  });

  it("rejects mismatched org ids (defense in depth)", async () => {
    const refs = await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: "other-org" });
    expect(refs).toEqual([]);
    expect(prismaMock.rFP.findMany).not.toHaveBeenCalled();
  });
});

describe("findCrossReferences — caching", () => {
  it("hits the cache on the second call within a single signature window", async () => {
    prismaMock.rFP.findMany.mockResolvedValue([
      {
        id: ATTACHMENT_ID,
        rawText: "encryption key rotation HSM at rest backups",
        docRole: "SECURITY_QUESTIONNAIRE",
        updatedAt: new Date("2026-01-01T00:00:00Z"),
      },
    ]);
    prismaMock.question.findMany.mockResolvedValue([
      { id: "q1", text: "Describe encryption key rotation and HSM usage." },
    ]);

    const first = await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: ORG_ID });
    expect(first.length).toBeGreaterThan(0);
    expect(_getCrossRefCacheStats(PRIMARY_ID)?.hits).toBe(0);

    const second = await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: ORG_ID });
    expect(second).toEqual(first);
    expect(_getCrossRefCacheStats(PRIMARY_ID)?.hits).toBe(1);
    // Question table only fetched once because the second call was served from cache.
    expect(prismaMock.question.findMany).toHaveBeenCalledTimes(1);
  });

  it("invalidates the cache when an attachment's updatedAt changes", async () => {
    prismaMock.rFP.findMany
      .mockResolvedValueOnce([
        {
          id: ATTACHMENT_ID,
          rawText: "encryption key rotation",
          docRole: "SECURITY_QUESTIONNAIRE",
          updatedAt: new Date("2026-01-01T00:00:00Z"),
        },
      ])
      .mockResolvedValueOnce([
        {
          id: ATTACHMENT_ID,
          rawText: "encryption key rotation now with extra detail",
          docRole: "SECURITY_QUESTIONNAIRE",
          updatedAt: new Date("2026-02-01T00:00:00Z"),
        },
      ]);
    prismaMock.question.findMany.mockResolvedValue([
      { id: "q1", text: "Describe encryption key rotation." },
    ]);

    await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: ORG_ID });
    await findCrossReferences({ rfpId: PRIMARY_ID, organizationId: ORG_ID });
    // Both calls re-queried questions because the signature changed.
    expect(prismaMock.question.findMany).toHaveBeenCalledTimes(2);
  });
});
