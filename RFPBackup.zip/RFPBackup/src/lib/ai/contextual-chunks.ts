// Contextual retrieval (Phase B.3, Anthropic Sept 2024 technique).
//
// For each chunk, generate a 1-2 sentence context blurb that situates it
// within the parent document. The blurb is prepended to the chunk text
// before embedding (NOT stored in the DB content field — the viewer keeps
// showing the original chunk verbatim). The result: embeddings carry the
// document-level disambiguation a chunk often lacks on its own.
//
// Example impact:
//   Raw chunk: "Implementation typically takes 4-6 weeks."
//   Contextualized: "From OATI's smart-grid deployment FAQ, section
//     'Implementation Timeline': Implementation typically takes 4-6 weeks."
//
// Tradeoff: one LLM call per chunk at ingest time. We use the extraction
// model (structured-output friendly + fast). Failures degrade silently — a
// chunk that couldn't get a blurb just gets embedded as-is, which is the
// pre-Phase-B.3 behavior. We never let contextualization break ingest.
//
// Operational notes:
//   - Document text is truncated to MAX_DOC_CHARS — full docs can be huge,
//     and the LLM only needs enough context to place the chunk.
//   - We use bounded parallelism (CONCURRENCY) — too high and rate limits
//     bite, too low and a 50-chunk doc takes forever.

import type OpenAI from "openai";
import { getAiClients } from "./client";
import { log } from "@/lib/logger";

const MAX_DOC_CHARS = 16_000;
const MAX_BLURB_CHARS = 240;
const CONCURRENCY = 4;
const TIMEOUT_MS = 20_000;

const SYSTEM_PROMPT =
  `You are a retrieval-context assistant. Given a document and a chunk taken from it, write a SHORT context sentence (max 1-2 sentences, no markdown) that situates the chunk within the document so future search queries can find it.

Rules:
- Output ONLY the context sentence. No preamble, no quotes, no markdown.
- Reference the document's subject + the chunk's section/topic.
- Do NOT repeat the chunk's text — add what the chunk is missing.
- Keep it short. Under ${MAX_BLURB_CHARS} characters.

Example output:
"From the OATI Smart Grid Solutions overview, section 'Implementation Timeline' — describes deployment milestones for medium-sized utility customers."`;

/**
 * Generate context blurbs for an array of chunks against the same document.
 * Returns an aligned array of strings — empty string for chunks that failed
 * (callers prepend the blurb only when non-empty, so failures pass through
 * unchanged).
 *
 * The whole document text is sent on every LLM call. Prompt-caching providers
 * (Anthropic, OpenAI ≥ Sept 2024) automatically cache the doc across calls —
 * for others we just pay the per-call input cost, still cheap.
 */
export async function contextualizeChunks(
  docText: string,
  chunks: Array<{ ordinal: number; content: string; section?: string }>,
  orgId: string | null | undefined,
  opts: { signal?: AbortSignal } = {},
): Promise<string[]> {
  if (chunks.length === 0) return [];
  const trimmedDoc = (docText ?? "").trim().slice(0, MAX_DOC_CHARS);
  if (!trimmedDoc) {
    // No document context to add — skip, return all empty.
    return chunks.map(() => "");
  }
  const clients = await getAiClients(orgId);
  const model = clients.config.extraction.model;

  const results: string[] = new Array(chunks.length).fill("");
  let next = 0;

  async function worker(): Promise<void> {
    while (true) {
      if (opts.signal?.aborted) return;
      const i = next++;
      if (i >= chunks.length) return;
      const chunk = chunks[i]!;
      try {
        const blurb = await contextualizeOne(
          clients.llm,
          model,
          trimmedDoc,
          chunk,
          opts.signal,
        );
        results[i] = blurb;
      } catch (err) {
        // Per-chunk failure must NEVER break ingest. The chunk falls back
        // to its original text embedding — the pre-B.3 path.
        log().warn(
          {
            orgId,
            chunkOrdinal: chunk.ordinal,
            err: err instanceof Error ? { name: err.name, message: err.message } : String(err),
          },
          "contextualizeChunks: per-chunk blurb failed; embedding chunk as-is",
        );
        results[i] = "";
      }
    }
  }

  const workerCount = Math.min(CONCURRENCY, chunks.length);
  await Promise.all(Array.from({ length: workerCount }, () => worker()));
  return results;
}

async function contextualizeOne(
  llm: OpenAI,
  model: string,
  docText: string,
  chunk: { ordinal: number; content: string; section?: string },
  signal: AbortSignal | undefined,
): Promise<string> {
  const userPrompt = [
    "# DOCUMENT",
    docText,
    "",
    "# CHUNK",
    chunk.section ? `(section: ${chunk.section})\n` : "",
    chunk.content,
  ].join("\n");

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  const onExternal = () => ctrl.abort();
  if (signal) {
    if (signal.aborted) ctrl.abort();
    else signal.addEventListener("abort", onExternal, { once: true });
  }
  try {
    const completion = await llm.chat.completions.create(
      {
        model,
        temperature: 0,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        // 80 tokens is plenty for a 1-2 sentence blurb; trims runaway output.
        max_tokens: 80,
      },
      // OpenAI SDK takes the signal on the second (request-options) arg.
      { signal: ctrl.signal },
    );
    const raw = completion.choices?.[0]?.message?.content ?? "";
    return sanitizeBlurb(raw);
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onExternal);
  }
}

/** Trim whitespace, strip surrounding quotes, cap length, drop newlines. */
export function sanitizeBlurb(raw: string): string {
  let s = (raw ?? "").trim();
  // Strip surrounding quotes (models often quote their output).
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    s = s.slice(1, -1).trim();
  }
  // Collapse newlines so the prepended blurb is one logical line.
  s = s.replace(/\s+/g, " ");
  if (s.length > MAX_BLURB_CHARS) s = s.slice(0, MAX_BLURB_CHARS).trim();
  return s;
}
