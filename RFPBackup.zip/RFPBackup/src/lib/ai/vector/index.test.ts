import { describe, expect, it, beforeEach, vi } from "vitest";

// ---------------------------------------------------------------------------
// Hoisted mocks. We mock prisma (to drive OrgAiConfig.vectorBackend +
// vectorDualWrite per test) and the lazy `./milvus` module (V2 owns the real
// thing). Mocking a dynamically-imported specifier is supported by Vitest
// directly via `vi.mock("./milvus", ...)` because the resolver's specifier is
// a plain relative path.
// ---------------------------------------------------------------------------
const { prismaMock, milvusCtor } = vi.hoisted(() => ({
  prismaMock: {
    orgAiConfig: {
      findUnique: vi.fn(),
    },
    // PostgresVectorStore reaches into prisma at construction-time via its
    // method bodies, but the resolver only needs the OrgAiConfig accessor.
  },
  milvusCtor: vi.fn(),
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

// Stub the V2 module. The resolver does `await import("./milvus")` lazily;
// returning a constructor here mimics V2's eventual export. Both
// `MilvusVectorStore` and `createMilvusForOrg` must be present — the resolver
// only accepts the module if both exports are functions.
vi.mock("./milvus", () => {
  class MilvusVectorStore {
    readonly id = "milvus" as const;
    readonly version = "milvus-mock";
    readonly supportsHybrid = true;
    constructor() {
      milvusCtor();
    }
    async initOrg() {}
    async upsert() {}
    async search() {
      return [];
    }
    async delete() {}
    async deleteIndex() {}
    async health() {
      return { ok: true, ms: 0 };
    }
  }
  async function createMilvusForOrg(_orgId: string) {
    return new MilvusVectorStore();
  }
  return { MilvusVectorStore, createMilvusForOrg };
});

import {
  DefaultVectorStoreResolver,
  PostgresVectorStore,
  createVectorStore,
} from "./index";

const ORG_PG = "org-pg";
const ORG_MILVUS = "org-milvus";
const ORG_DUAL_PG = "org-dual-pg";
const ORG_DUAL_MILVUS = "org-dual-milvus";
const ORG_NO_CONFIG = "org-no-config";

beforeEach(() => {
  vi.clearAllMocks();
  prismaMock.orgAiConfig.findUnique.mockImplementation(async ({ where }: { where: { organizationId: string } }) => {
    switch (where.organizationId) {
      case ORG_PG:
        return { vectorBackend: "POSTGRES", vectorDualWrite: false };
      case ORG_MILVUS:
        return { vectorBackend: "MILVUS", vectorDualWrite: false };
      case ORG_DUAL_PG:
        return { vectorBackend: "POSTGRES", vectorDualWrite: true };
      case ORG_DUAL_MILVUS:
        return { vectorBackend: "MILVUS", vectorDualWrite: true };
      case ORG_NO_CONFIG:
        return null;
      default:
        return null;
    }
  });
});

// ---------------------------------------------------------------------------
// createVectorStore — backend factory.
// ---------------------------------------------------------------------------

describe("createVectorStore", () => {
  it("returns a PostgresVectorStore for backend=postgres", async () => {
    const store = await createVectorStore("postgres");
    expect(store).toBeInstanceOf(PostgresVectorStore);
    expect(store.id).toBe("postgres");
  });

  it("returns a MilvusVectorStore for backend=milvus (via lazy import of @/lib/ai/vector/milvus)", async () => {
    // Milvus backend requires an orgId because the real implementation reads
    // uri/token/collection from per-org config. The mocked createMilvusForOrg
    // ignores it and just returns a fresh stub.
    const store = await createVectorStore("milvus", ORG_MILVUS);
    expect(store.id).toBe("milvus");
    expect(store.supportsHybrid).toBe(true);
    expect(milvusCtor).toHaveBeenCalledTimes(1);
  });
});

// ---------------------------------------------------------------------------
// DefaultVectorStoreResolver.forOrg — single read backend per org.
// ---------------------------------------------------------------------------

describe("DefaultVectorStoreResolver.forOrg", () => {
  it("returns PostgresVectorStore when OrgAiConfig.vectorBackend = POSTGRES", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const store = await resolver.forOrg(ORG_PG);
    expect(store.id).toBe("postgres");
  });

  it("returns MilvusVectorStore when OrgAiConfig.vectorBackend = MILVUS", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const store = await resolver.forOrg(ORG_MILVUS);
    expect(store.id).toBe("milvus");
  });

  it("defaults to PostgresVectorStore when no OrgAiConfig row exists", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const store = await resolver.forOrg(ORG_NO_CONFIG);
    expect(store.id).toBe("postgres");
  });

  it("caches per-(org, backend) so repeated calls return the same instance", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const a = await resolver.forOrg(ORG_PG);
    const b = await resolver.forOrg(ORG_PG);
    expect(a).toBe(b);
  });

  it("reset() drops the cache so the next call rebuilds", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const a = await resolver.forOrg(ORG_PG);
    resolver.reset();
    const b = await resolver.forOrg(ORG_PG);
    expect(a).not.toBe(b);
  });
});

// ---------------------------------------------------------------------------
// DefaultVectorStoreResolver.writersForOrg — the dual-write matrix.
//
// backend     dualWrite  → writers           reads
// ----------  ---------  ------------------  --------
// POSTGRES    false      [postgres]          postgres
// POSTGRES    true       [postgres, milvus]  postgres
// MILVUS      true       [postgres, milvus]  milvus
// MILVUS      false      [milvus]            milvus
// ---------------------------------------------------------------------------

describe("DefaultVectorStoreResolver.writersForOrg", () => {
  it("POSTGRES + dualWrite=false → [postgres]", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const writers = await resolver.writersForOrg(ORG_PG);
    expect(writers.map((w) => w.id)).toEqual(["postgres"]);
  });

  it("MILVUS + dualWrite=false → [milvus]", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const writers = await resolver.writersForOrg(ORG_MILVUS);
    expect(writers.map((w) => w.id)).toEqual(["milvus"]);
  });

  it("POSTGRES + dualWrite=true → [postgres, milvus] (backfill phase)", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const writers = await resolver.writersForOrg(ORG_DUAL_PG);
    expect(writers.map((w) => w.id)).toEqual(["postgres", "milvus"]);
  });

  it("MILVUS + dualWrite=true → [postgres, milvus] (verify phase, reads from Milvus)", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const writers = await resolver.writersForOrg(ORG_DUAL_MILVUS);
    expect(writers.map((w) => w.id)).toEqual(["postgres", "milvus"]);
  });

  it("reuses cached instances across forOrg + writersForOrg calls (Milvus client is heavy)", async () => {
    const resolver = new DefaultVectorStoreResolver();
    const reader = await resolver.forOrg(ORG_DUAL_MILVUS);
    const writers = await resolver.writersForOrg(ORG_DUAL_MILVUS);
    // The milvus reader and the milvus writer should be the SAME instance.
    const milvusWriter = writers.find((w) => w.id === "milvus");
    expect(milvusWriter).toBe(reader);
  });
});
