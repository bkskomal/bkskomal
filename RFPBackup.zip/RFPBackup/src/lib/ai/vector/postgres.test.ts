import { describe, expect, it, beforeEach, vi } from "vitest";

// ---------------------------------------------------------------------------
// Hoisted mocks. We mock prisma directly — the PostgresVectorStore is the
// thin adapter from VectorStore → DocumentChunk, so we exercise the SQL
// shape (where clauses, transaction batching) rather than touching a real DB.
// ---------------------------------------------------------------------------
const { prismaMock } = vi.hoisted(() => ({
  prismaMock: {
    documentChunk: {
      findMany: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
      count: vi.fn(),
    },
    imageEmbedding: {
      findMany: vi.fn(),
      update: vi.fn(),
      deleteMany: vi.fn(),
    },
    $transaction: vi.fn(),
  },
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

import { PostgresVectorStore } from "./postgres";

const ORG_A = "org-a";
const ORG_B = "org-b";
const INDEX_A = "idx-a";

beforeEach(() => {
  vi.clearAllMocks();
  // Default: $transaction just runs each promise the caller built. Tests can
  // override per-case if they need to inspect the transaction batch.
  prismaMock.$transaction.mockImplementation(async (ops: unknown) => {
    if (Array.isArray(ops)) return Promise.all(ops);
    return ops;
  });
  prismaMock.documentChunk.findMany.mockResolvedValue([]);
  prismaMock.documentChunk.update.mockResolvedValue({ id: "ok" });
  prismaMock.documentChunk.updateMany.mockResolvedValue({ count: 0 });
  prismaMock.documentChunk.count.mockResolvedValue(0);
  prismaMock.imageEmbedding.findMany.mockResolvedValue([]);
  prismaMock.imageEmbedding.update.mockResolvedValue({ id: "ok" });
  prismaMock.imageEmbedding.deleteMany.mockResolvedValue({ count: 0 });
});

describe("PostgresVectorStore — identity", () => {
  it("advertises the postgres backend with no native hybrid", () => {
    const store = new PostgresVectorStore();
    expect(store.id).toBe("postgres");
    expect(store.version).toBe("pg-1");
    expect(store.supportsHybrid).toBe(false);
  });

  it("advertises image support (multimodal RAG, Phase IM)", () => {
    const store = new PostgresVectorStore();
    expect(store.supportsImages).toBe(true);
  });

  it("initOrg is a no-op (Postgres tables already exist)", async () => {
    const store = new PostgresVectorStore();
    await expect(store.initOrg(ORG_A)).resolves.toBeUndefined();
    expect(prismaMock.documentChunk.update).not.toHaveBeenCalled();
  });
});

describe("PostgresVectorStore.upsert", () => {
  it("patches embedding column on existing chunk rows in a single transaction", async () => {
    const store = new PostgresVectorStore();
    await store.upsert([
      {
        id: "c1",
        embedding: [1, 0, 0],
        metadata: { documentId: "d1", indexId: INDEX_A, organizationId: ORG_A },
      },
      {
        id: "c2",
        embedding: [0, 1, 0],
        metadata: { documentId: "d1", indexId: INDEX_A, organizationId: ORG_A },
      },
    ]);
    expect(prismaMock.$transaction).toHaveBeenCalledTimes(1);
    // The two updates were issued by id with the new embedding payload.
    const calls = prismaMock.documentChunk.update.mock.calls;
    expect(calls).toHaveLength(2);
    expect(calls[0][0]).toEqual({
      where: { id: "c1" },
      data: { embedding: [1, 0, 0] },
    });
    expect(calls[1][0]).toEqual({
      where: { id: "c2" },
      data: { embedding: [0, 1, 0] },
    });
  });

  it("is a no-op when given an empty list", async () => {
    const store = new PostgresVectorStore();
    await store.upsert([]);
    expect(prismaMock.$transaction).not.toHaveBeenCalled();
    expect(prismaMock.documentChunk.update).not.toHaveBeenCalled();
  });
});

describe("PostgresVectorStore.search", () => {
  it("returns top-K with cosine sorted descending and tags hits as 'dense'", async () => {
    prismaMock.documentChunk.findMany.mockResolvedValueOnce([
      { id: "c-perp", embedding: [0, 1, 0] }, // cosine 0
      { id: "c-near", embedding: [1, 0, 0] }, // cosine 1
      { id: "c-mid", embedding: [1, 1, 0] }, // cosine ~0.707
    ]);
    const store = new PostgresVectorStore();
    const hits = await store.search(ORG_A, INDEX_A, [1, 0, 0], { topK: 2 });
    expect(hits).toHaveLength(2);
    expect(hits[0].id).toBe("c-near");
    expect(hits[0].score).toBeCloseTo(1);
    expect(hits[0].source).toBe("dense");
    expect(hits[1].id).toBe("c-mid");
    expect(hits[1].score).toBeCloseTo(1 / Math.sqrt(2));
  });

  it("filters by documentIds when supplied", async () => {
    prismaMock.documentChunk.findMany.mockResolvedValueOnce([]);
    const store = new PostgresVectorStore();
    await store.search(ORG_A, INDEX_A, [1, 0, 0], {
      topK: 5,
      filter: { documentIds: ["d1", "d2"] },
    });
    const where = prismaMock.documentChunk.findMany.mock.calls[0][0].where;
    expect(where.document.id).toEqual({ in: ["d1", "d2"] });
  });

  it("filters by sections and kinds when supplied", async () => {
    prismaMock.documentChunk.findMany.mockResolvedValueOnce([]);
    const store = new PostgresVectorStore();
    await store.search(ORG_A, INDEX_A, [1, 0, 0], {
      topK: 5,
      filter: { sections: ["Security"], kinds: ["paragraph"] },
    });
    const where = prismaMock.documentChunk.findMany.mock.calls[0][0].where;
    expect(where.section).toEqual({ in: ["Security"] });
    expect(where.kind).toEqual({ in: ["paragraph"] });
  });

  it("drops hits below minScore", async () => {
    prismaMock.documentChunk.findMany.mockResolvedValueOnce([
      { id: "c-near", embedding: [1, 0, 0] },
      { id: "c-mid", embedding: [1, 1, 0] }, // cosine ~0.707
    ]);
    const store = new PostgresVectorStore();
    const hits = await store.search(ORG_A, INDEX_A, [1, 0, 0], {
      topK: 5,
      minScore: 0.9,
    });
    expect(hits.map((h) => h.id)).toEqual(["c-near"]);
  });

  it("skips chunks with mismatched embedding length and zero-norm chunks", async () => {
    prismaMock.documentChunk.findMany.mockResolvedValueOnce([
      { id: "c-zero", embedding: [0, 0, 0] }, // norm 0
      { id: "c-wrong-dim", embedding: [1, 0] }, // wrong dim
      { id: "c-ok", embedding: [1, 0, 0] },
    ]);
    const store = new PostgresVectorStore();
    const hits = await store.search(ORG_A, INDEX_A, [1, 0, 0], { topK: 5 });
    expect(hits.map((h) => h.id)).toEqual(["c-ok"]);
  });

  it("returns empty array when query embedding is the zero vector", async () => {
    const store = new PostgresVectorStore();
    const hits = await store.search(ORG_A, INDEX_A, [0, 0, 0], { topK: 5 });
    expect(hits).toEqual([]);
    expect(prismaMock.documentChunk.findMany).not.toHaveBeenCalled();
  });
});

describe("PostgresVectorStore — tenant isolation", () => {
  it("scopes findMany by organizationId via the index join (org A's query never sees org B)", async () => {
    prismaMock.documentChunk.findMany.mockResolvedValueOnce([]);
    const store = new PostgresVectorStore();
    await store.search(ORG_B, INDEX_A, [1, 0, 0], { topK: 5 });
    const where = prismaMock.documentChunk.findMany.mock.calls[0][0].where;
    // The crucial assertion: the SQL filter requires the index belong to the
    // requesting org. A leaked indexId from another org cannot match.
    expect(where.document.indexId).toBe(INDEX_A);
    expect(where.document.index.organizationId).toBe(ORG_B);
    expect(where.document.status).toBe("INDEXED");
  });
});

describe("PostgresVectorStore.delete (soft delete)", () => {
  it("clears embedding on the named chunks but leaves rows intact", async () => {
    const store = new PostgresVectorStore();
    await store.delete(ORG_A, ["c1", "c2"]);
    expect(prismaMock.documentChunk.updateMany).toHaveBeenCalledWith({
      where: { id: { in: ["c1", "c2"] } },
      data: { embedding: [] },
    });
  });

  it("is a no-op when the chunk-id list is empty", async () => {
    const store = new PostgresVectorStore();
    await store.delete(ORG_A, []);
    expect(prismaMock.documentChunk.updateMany).not.toHaveBeenCalled();
  });
});

describe("PostgresVectorStore.deleteIndex", () => {
  it("clears embeddings for every chunk under the index, scoped to org", async () => {
    const store = new PostgresVectorStore();
    await store.deleteIndex(ORG_A, INDEX_A);
    expect(prismaMock.documentChunk.updateMany).toHaveBeenCalledWith({
      where: { document: { indexId: INDEX_A, index: { organizationId: ORG_A } } },
      data: { embedding: [] },
    });
  });
});

describe("PostgresVectorStore.health", () => {
  it("returns ok with vectorCount", async () => {
    prismaMock.documentChunk.count.mockResolvedValueOnce(42);
    const store = new PostgresVectorStore();
    const h = await store.health(ORG_A);
    expect(h.ok).toBe(true);
    expect(h.vectorCount).toBe(42);
    expect(typeof h.ms).toBe("number");
  });

  it("returns not-ok with detail when the count query throws", async () => {
    prismaMock.documentChunk.count.mockRejectedValueOnce(new Error("db down"));
    const store = new PostgresVectorStore();
    const h = await store.health(ORG_A);
    expect(h.ok).toBe(false);
    expect(h.detail).toBe("db down");
  });
});

// ---------------------------------------------------------------------------
// Image (multimodal) — Phase IM
// ---------------------------------------------------------------------------

describe("PostgresVectorStore.upsertImages", () => {
  it("patches the vector column on existing ImageEmbedding rows in a single transaction", async () => {
    const store = new PostgresVectorStore();
    await store.upsertImages([
      {
        id: "img-1",
        vector: [1, 0, 0],
        metadata: {
          organizationId: ORG_A,
          indexId: INDEX_A,
          documentId: "d1",
          imagePath: "uploads/images/abc.png",
          mimeType: "image/png",
        },
      },
      {
        id: "img-2",
        vector: [0, 1, 0],
        metadata: {
          organizationId: ORG_A,
          indexId: INDEX_A,
          documentId: "d1",
          imagePath: "uploads/images/def.png",
          mimeType: "image/png",
        },
      },
    ]);
    expect(prismaMock.$transaction).toHaveBeenCalledTimes(1);
    const calls = prismaMock.imageEmbedding.update.mock.calls;
    expect(calls).toHaveLength(2);
    expect(calls[0][0]).toEqual({ where: { id: "img-1" }, data: { vector: [1, 0, 0] } });
    expect(calls[1][0]).toEqual({ where: { id: "img-2" }, data: { vector: [0, 1, 0] } });
  });

  it("is a no-op when given an empty list", async () => {
    const store = new PostgresVectorStore();
    await store.upsertImages([]);
    expect(prismaMock.$transaction).not.toHaveBeenCalled();
    expect(prismaMock.imageEmbedding.update).not.toHaveBeenCalled();
  });
});

describe("PostgresVectorStore.searchImages", () => {
  it("returns top-K image hits sorted by cosine descending", async () => {
    prismaMock.imageEmbedding.findMany.mockResolvedValueOnce([
      {
        id: "i-perp",
        vector: [0, 1, 0],
        imagePath: "p1.png",
        caption: null,
        ocrText: null,
        page: 1,
        documentId: "d1",
        chunkId: null,
      },
      {
        id: "i-near",
        vector: [1, 0, 0],
        imagePath: "p2.png",
        caption: "near match",
        ocrText: "ocr near",
        page: 2,
        documentId: "d1",
        chunkId: "c1",
      },
      {
        id: "i-mid",
        vector: [1, 1, 0],
        imagePath: "p3.png",
        caption: null,
        ocrText: null,
        page: null,
        documentId: "d1",
        chunkId: null,
      },
    ]);
    const store = new PostgresVectorStore();
    const hits = await store.searchImages(ORG_A, INDEX_A, [1, 0, 0], { topK: 2 });
    expect(hits).toHaveLength(2);
    expect(hits[0].id).toBe("i-near");
    expect(hits[0].score).toBeCloseTo(1);
    expect(hits[0].caption).toBe("near match");
    expect(hits[0].ocrText).toBe("ocr near");
    expect(hits[0].chunkId).toBe("c1");
    expect(hits[1].id).toBe("i-mid");
    expect(hits[1].score).toBeCloseTo(1 / Math.sqrt(2));
  });

  it("scopes the query to organizationId AND indexId", async () => {
    prismaMock.imageEmbedding.findMany.mockResolvedValueOnce([]);
    const store = new PostgresVectorStore();
    await store.searchImages(ORG_B, INDEX_A, [1, 0, 0], { topK: 5 });
    const where = prismaMock.imageEmbedding.findMany.mock.calls[0][0].where;
    expect(where.organizationId).toBe(ORG_B);
    expect(where.indexId).toBe(INDEX_A);
  });

  it("filters by documentIds when supplied", async () => {
    prismaMock.imageEmbedding.findMany.mockResolvedValueOnce([]);
    const store = new PostgresVectorStore();
    await store.searchImages(ORG_A, INDEX_A, [1, 0, 0], {
      topK: 5,
      filter: { documentIds: ["d1", "d2"] },
    });
    const where = prismaMock.imageEmbedding.findMany.mock.calls[0][0].where;
    expect(where.documentId).toEqual({ in: ["d1", "d2"] });
  });

  it("drops hits below minScore", async () => {
    prismaMock.imageEmbedding.findMany.mockResolvedValueOnce([
      { id: "i-near", vector: [1, 0, 0], imagePath: "n.png", caption: null, ocrText: null, page: null, documentId: "d", chunkId: null },
      { id: "i-mid", vector: [1, 1, 0], imagePath: "m.png", caption: null, ocrText: null, page: null, documentId: "d", chunkId: null },
    ]);
    const store = new PostgresVectorStore();
    const hits = await store.searchImages(ORG_A, INDEX_A, [1, 0, 0], {
      topK: 5,
      minScore: 0.9,
    });
    expect(hits.map((h) => h.id)).toEqual(["i-near"]);
  });

  it("returns [] for a zero-norm query without hitting the DB", async () => {
    const store = new PostgresVectorStore();
    const hits = await store.searchImages(ORG_A, INDEX_A, [0, 0, 0], { topK: 5 });
    expect(hits).toEqual([]);
    expect(prismaMock.imageEmbedding.findMany).not.toHaveBeenCalled();
  });
});

describe("PostgresVectorStore.deleteImages (hard delete)", () => {
  it("hard-deletes the named image rows scoped to org", async () => {
    const store = new PostgresVectorStore();
    await store.deleteImages(ORG_A, ["img-1", "img-2"]);
    expect(prismaMock.imageEmbedding.deleteMany).toHaveBeenCalledWith({
      where: { id: { in: ["img-1", "img-2"] }, organizationId: ORG_A },
    });
  });

  it("is a no-op when the id list is empty", async () => {
    const store = new PostgresVectorStore();
    await store.deleteImages(ORG_A, []);
    expect(prismaMock.imageEmbedding.deleteMany).not.toHaveBeenCalled();
  });
});

describe("PostgresVectorStore.deleteImagesForIndex", () => {
  it("hard-deletes every image row under the index, scoped to org", async () => {
    const store = new PostgresVectorStore();
    await store.deleteImagesForIndex(ORG_A, INDEX_A);
    expect(prismaMock.imageEmbedding.deleteMany).toHaveBeenCalledWith({
      where: { organizationId: ORG_A, indexId: INDEX_A },
    });
  });
});
