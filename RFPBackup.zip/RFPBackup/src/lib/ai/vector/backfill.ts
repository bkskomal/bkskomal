// Shared Postgres → Milvus backfill helper.
//
// Used by both the CLI (`scripts/migrate-to-milvus.mjs`) and the
// /api/orgs/[orgId]/vector/migrate route. The CLI shells out to Node and
// imports this file via the standard tsx loader; the route calls it inline.
//
// Streaming-friendly: walks `DocumentChunk` in cursor-paginated batches so a
// large org (>1M chunks) doesn't materialise the whole result set in memory.
//
// On `dryRun = true` we skip every Milvus call but still scan the rows and
// report the would-be-written count — useful as a "is the backfill safe to
// run" preflight.

import { prisma } from "@/lib/prisma";
import { createMilvusForOrg, MilvusVectorStore } from "./milvus";
import type { ChunkVec } from "./types";
import { log } from "@/lib/logger";

export interface BackfillOpts {
  orgId: string;
  /** When set, only chunks belonging to this index get backfilled. */
  indexId?: string;
  /** Page size for the cursor scan. Default 200. */
  batch?: number;
  /** When true, no Milvus writes happen — only counts. */
  dryRun?: boolean;
  /** Optional pre-built store (for tests). Otherwise factory-built. */
  store?: MilvusVectorStore;
}

export interface BackfillResult {
  scanned: number;
  written: number;
  errors: number;
  /** First few error messages for diagnostics. Capped to avoid blowing up payloads. */
  sampleErrors: string[];
  durationMs: number;
}

const SAMPLE_ERROR_CAP = 5;

export async function backfillToMilvus(opts: BackfillOpts): Promise<BackfillResult> {
  const started = Date.now();
  const batch = opts.batch ?? 200;
  const dryRun = Boolean(opts.dryRun);

  const store = opts.store ?? (await createMilvusForOrg(opts.orgId));

  if (!dryRun) {
    await store.initOrg(opts.orgId);
  }

  // Find the indexes we need to walk. Caller may scope to a single index;
  // otherwise scan every index in the org.
  const indexes = await prisma.knowledgeIndex.findMany({
    where: {
      organizationId: opts.orgId,
      ...(opts.indexId ? { id: opts.indexId } : {}),
    },
    select: { id: true },
  });

  let scanned = 0;
  let written = 0;
  let errors = 0;
  const sampleErrors: string[] = [];

  for (const idx of indexes) {
    let cursor: string | undefined;
    while (true) {
      const rows = await prisma.documentChunk.findMany({
        where: {
          document: { indexId: idx.id },
        },
        select: {
          id: true,
          embedding: true,
          documentId: true,
          section: true,
          kind: true,
          page: true,
          anchor: true,
          document: { select: { indexId: true } },
        },
        take: batch,
        ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
        orderBy: { id: "asc" },
      });
      if (rows.length === 0) break;
      cursor = rows[rows.length - 1].id;
      scanned += rows.length;

      // Skip chunks with empty embeddings — no point inserting a zero-vector
      // payload that will never match anything.
      const ready: ChunkVec[] = rows
        .filter((r) => Array.isArray(r.embedding) && r.embedding.length > 0)
        .map((r) => ({
          id: r.id,
          embedding: r.embedding,
          metadata: {
            documentId: r.documentId,
            indexId: r.document.indexId,
            organizationId: opts.orgId,
            section: r.section ?? undefined,
            kind: r.kind ?? undefined,
            page: r.page ?? undefined,
            anchor: r.anchor ?? undefined,
          },
        }));

      if (ready.length === 0 || dryRun) {
        if (dryRun) written += ready.length;
        continue;
      }

      try {
        await store.upsert(ready);
        written += ready.length;
      } catch (err) {
        errors += ready.length;
        if (sampleErrors.length < SAMPLE_ERROR_CAP) {
          sampleErrors.push(err instanceof Error ? err.message : String(err));
        }
        log().warn(
          { err: err instanceof Error ? err.message : String(err), batch: ready.length },
          "milvus backfill batch failed",
        );
      }
    }
  }

  // Stamp the migration timestamp on success (non-dry, no errors). Failed
  // backfills leave the field alone so the UI keeps showing "not migrated".
  if (!dryRun && errors === 0 && written > 0) {
    await prisma.orgAiConfig.upsert({
      where: { organizationId: opts.orgId },
      update: { vectorMigratedAt: new Date() },
      create: { organizationId: opts.orgId, vectorMigratedAt: new Date() },
    });
  }

  return {
    scanned,
    written,
    errors,
    sampleErrors,
    durationMs: Date.now() - started,
  };
}
