// Vector backend resolver + factory.
//
// One implementation per `VectorBackendId`. The resolver reads
// `OrgAiConfig.vectorBackend` to decide which backend to hand back per-org,
// and consults `vectorDualWrite` to decide whether upserts should fan out to
// both backends during a Postgres↔Milvus cutover.
//
// Caching: backend instances (especially Milvus, which holds a gRPC client)
// are heavyweight. We cache PER-ORG so concurrent requests reuse the same
// connection. Postgres instances are cheap but cached for symmetry.
//
// Lazy import for Milvus: V2 owns `./milvus`. We `await import()` lazily and
// catch failures so the build doesn't break if V2 hasn't shipped yet — orgs
// configured for Milvus will get a clear error, Postgres orgs are unaffected.

import { prisma } from "@/lib/prisma";
import { PostgresVectorStore } from "./postgres";
import type {
  VectorBackendId,
  VectorStore,
  VectorStoreResolver,
} from "./types";

/**
 * Construct a fresh store for the given backend id. Used by the resolver and
 * (occasionally) by ops scripts that need to talk to a specific backend
 * directly. Prefer the resolver for normal request paths.
 */
export async function createVectorStore(
  backend: VectorBackendId,
  organizationId?: string,
): Promise<VectorStore> {
  if (backend === "postgres") {
    return new PostgresVectorStore();
  }
  if (backend === "milvus") {
    const mod = await loadMilvusModule();
    if (!mod) {
      throw new Error(
        "Milvus backend requested but @/lib/ai/vector/milvus is unavailable. " +
          "Either the V2 module isn't installed or its dependencies failed to load.",
      );
    }
    if (!organizationId) {
      throw new Error(
        "createVectorStore('milvus') requires an organizationId — Milvus reads " +
          "uri/token/collection from per-org config.",
      );
    }
    return await mod.createMilvusForOrg(organizationId);
  }
  // Exhaustiveness — TS will complain if a new backend is added.
  const _exhaustive: never = backend;
  throw new Error(`Unknown vector backend: ${String(_exhaustive)}`);
}

interface MilvusModule {
  MilvusVectorStore: new (opts: unknown) => VectorStore;
  createMilvusForOrg: (orgId: string) => Promise<VectorStore>;
}

async function loadMilvusModule(): Promise<MilvusModule | null> {
  try {
    // Static specifier so test mocks (vi.mock("./milvus", ...)) intercept it
    // and so Vite/TS can build the dynamic import graph. The try/catch below
    // means the build still succeeds if V2's module resolution fails at
    // runtime — only orgs configured for Milvus will see the resolver throw.
    const mod = (await import("./milvus")) as Partial<MilvusModule>;
    if (
      typeof mod.MilvusVectorStore !== "function" ||
      typeof mod.createMilvusForOrg !== "function"
    ) {
      return null;
    }
    return {
      MilvusVectorStore: mod.MilvusVectorStore,
      createMilvusForOrg: mod.createMilvusForOrg,
    };
  } catch {
    return null;
  }
}

/**
 * Default resolver: reads OrgAiConfig.vectorBackend per-org, caches one store
 * per (orgId, backend), and supports dual-write for cutover.
 *
 * Dual-write matrix:
 *
 *   backend     dualWrite  → writers           reads
 *   ----------  ---------  ------------------  --------
 *   POSTGRES    false      [postgres]          postgres
 *   POSTGRES    true       [postgres, milvus]  postgres   ← backfill phase
 *   MILVUS      true       [postgres, milvus]  milvus     ← verify phase
 *   MILVUS      false      [milvus]            milvus     ← cutover complete
 */
export class DefaultVectorStoreResolver implements VectorStoreResolver {
  private cache = new Map<string, VectorStore>();

  async forOrg(organizationId: string): Promise<VectorStore> {
    const config = await prisma.orgAiConfig.findUnique({
      where: { organizationId },
      select: { vectorBackend: true },
    });
    // Default to POSTGRES when the org has no AI config row at all (most
    // self-hosted single-org installs never write to OrgAiConfig).
    const backend: VectorBackendId =
      config?.vectorBackend === "MILVUS" ? "milvus" : "postgres";
    return this.getOrCreate(organizationId, backend);
  }

  async writersForOrg(organizationId: string): Promise<VectorStore[]> {
    const config = await prisma.orgAiConfig.findUnique({
      where: { organizationId },
      select: { vectorBackend: true, vectorDualWrite: true },
    });
    const backend: VectorBackendId =
      config?.vectorBackend === "MILVUS" ? "milvus" : "postgres";
    const dualWrite = config?.vectorDualWrite === true;

    if (!dualWrite) {
      return [await this.getOrCreate(organizationId, backend)];
    }
    // Dual-write: always [postgres, milvus] in a stable order regardless of
    // which one is the read backend. Order matters for predictable error
    // reporting, not for correctness.
    return [
      await this.getOrCreate(organizationId, "postgres"),
      await this.getOrCreate(organizationId, "milvus"),
    ];
  }

  /** For tests: drop the per-org cache. */
  reset(): void {
    this.cache.clear();
  }

  private async getOrCreate(
    organizationId: string,
    backend: VectorBackendId,
  ): Promise<VectorStore> {
    const key = `${organizationId}:${backend}`;
    const cached = this.cache.get(key);
    if (cached) return cached;
    const store = await createVectorStore(backend, organizationId);
    // Ensure per-org collection/partition exists. Idempotent — Postgres is a
    // no-op; Milvus creates the collections if missing. Without this the first
    // upsert against a fresh org fails with "collection not found".
    try {
      await store.initOrg(organizationId);
    } catch (err) {
      // Don't poison the cache on init failure — caller will hit the same
      // error on the next attempt and can surface it; we just don't want a
      // bad init to permanently break this org's resolver.
      const msg = err instanceof Error ? err.message : String(err);
      throw new Error(`vectorStore.initOrg(${organizationId}) failed for backend ${backend}: ${msg}`);
    }
    this.cache.set(key, store);
    return store;
  }
}

/** Process-wide singleton — safe because per-org instances are cached inside. */
export const vectorStoreResolver = new DefaultVectorStoreResolver();

// Re-export the contract types so callers only need one import path.
export type {
  ChunkVec,
  ChunkMetadata,
  ImageHit,
  ImageMetadata,
  ImageSearchOpts,
  ImageVec,
  VectorBackendId,
  VectorHealth,
  VectorHit,
  VectorSearchFilter,
  VectorSearchOpts,
  VectorStore,
  VectorStoreImages,
  VectorStoreResolver,
} from "./types";
export { PostgresVectorStore } from "./postgres";

// ---------------------------------------------------------------------------
// Image (multimodal) — Phase IM
//
// Capability narrowing helper. The store instance itself implements the
// `VectorStoreImages` interface, but TS callers using the bare `VectorStore`
// type can't see those methods. Use this in retrieval and ingestion paths to
// branch on the capability cleanly.
// ---------------------------------------------------------------------------

import type { VectorStore as VS, VectorStoreImages as VSI } from "./types";

export function supportsImages(store: VS): store is VS & VSI {
  // Both Postgres and Milvus impls set `supportsImages = true` literally on
  // the instance — TS narrows on the field check below.
  return (store as unknown as { supportsImages?: boolean }).supportsImages === true;
}
