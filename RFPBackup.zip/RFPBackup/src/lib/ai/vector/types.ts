// VectorStore contract — the integration seam for any vector backend.
//
// Implementations: PostgresVectorStore (current behaviour, default),
// MilvusVectorStore (M2). Adding Pinecone / Weaviate / Qdrant later is a
// matter of writing one more impl behind this interface.
//
// Design notes:
//   - Backends are per-org: each Organization picks one via OrgAiConfig.
//   - Tenant isolation is mandatory: every method takes orgId; backends
//     enforce it (Milvus via partition_key, Postgres via WHERE clause).
//   - Embeddings are produced upstream by the embedding service; this
//     interface just stores and searches them.
//   - The schema-backed `DocumentChunk.embedding` Float[] column remains
//     the source of truth for the Postgres backend; Milvus mirrors it.

export type VectorBackendId = "postgres" | "milvus";

export interface ChunkVec {
  /** Stable chunk identifier — matches `DocumentChunk.id`. */
  id: string;
  /** Dense vector (length matches the org's embeddingDimensions, default 384). */
  embedding: number[];
  /** Optional sparse vector (BM25-style term weights) for native hybrid search. */
  sparseEmbedding?: SparseVector;
  /** Indexed metadata used for filtering at search time. */
  metadata: ChunkMetadata;
}

/** Sparse vector representation: parallel arrays of term ids and weights. */
export interface SparseVector {
  indices: number[];
  values: number[];
}

export interface ChunkMetadata {
  documentId: string;
  indexId: string;
  organizationId: string;
  /** Heading path, e.g. "1.2 / Security / Encryption". */
  section?: string;
  /** Block kind: paragraph | heading | table | list | code | quote | figure | footnote. */
  kind?: string;
  page?: number;
  anchor?: string;
}

export interface VectorSearchOpts {
  topK: number;
  /** Optional metadata filters — backends translate to native filter syntax. */
  filter?: VectorSearchFilter;
  /** Drop hits below this cosine score; 0 = no floor. */
  minScore?: number;
  /** Optional sparse query (term ids + weights) for hybrid search. */
  sparseQuery?: SparseVector;
  /** When true and backend supports it, run native hybrid (dense+sparse) and fuse server-side. */
  hybrid?: boolean;
}

export interface VectorSearchFilter {
  documentIds?: string[];
  sections?: string[];
  kinds?: string[];
}

export interface VectorHit {
  /** Matches `DocumentChunk.id`. */
  id: string;
  /** Cosine similarity 0..1 (or backend-native distance normalised). */
  score: number;
  /** Optional embedding return for downstream re-rank without a second fetch. */
  embedding?: number[];
  /** Backend-reported source — useful for hybrid responses indicating dense vs sparse hit. */
  source?: "dense" | "sparse" | "hybrid";
}

export interface VectorHealth {
  ok: boolean;
  detail?: string;
  ms: number;
  /** Approximate vector count for the org/index when cheaply available. */
  vectorCount?: number;
}

/**
 * The contract every vector backend implements. Methods are async; backends
 * may keep persistent connections (Milvus client) or be stateless (Postgres).
 */
export interface VectorStore {
  readonly id: VectorBackendId;
  readonly version: string;
  /** Whether this backend can do native hybrid (dense+sparse) search. */
  readonly supportsHybrid: boolean;

  /**
   * Ensure the org's collection/partition exists. Idempotent. Called from
   * `initOrgVectorStore` on first write or via the migration CLI.
   */
  initOrg(orgId: string): Promise<void>;

  /** Bulk upsert chunks. Called by the indexing pipeline post-embedding. */
  upsert(chunks: ChunkVec[]): Promise<void>;

  /**
   * Dense-only search by default. When opts.hybrid=true and supportsHybrid,
   * the backend fuses dense + sparse server-side. Otherwise sparseQuery is ignored
   * (caller is expected to do BM25 separately and RRF in JS).
   */
  search(
    organizationId: string,
    indexId: string,
    queryEmbedding: number[],
    opts: VectorSearchOpts,
  ): Promise<VectorHit[]>;

  /** Bulk delete by chunk id. Called when a Document is removed. */
  delete(organizationId: string, chunkIds: string[]): Promise<void>;

  /** Drop everything for one index (e.g. when index is deleted entirely). */
  deleteIndex(organizationId: string, indexId: string): Promise<void>;

  /** Health probe; cheap. Used by `/api/health`. */
  health(organizationId: string): Promise<VectorHealth>;
}

/**
 * Per-org factory. Reads OrgAiConfig.vectorBackend and returns the matching
 * implementation. When `vectorDualWrite` is true, returns a wrapper that
 * writes to both backends but reads from `vectorBackend` only — used during
 * cutover.
 */
export interface VectorStoreResolver {
  forOrg(organizationId: string): Promise<VectorStore>;
  /** Returns BOTH stores when dual-write is enabled. Used by upserts only. */
  writersForOrg(organizationId: string): Promise<VectorStore[]>;
}

// --------------------------------------------------------------------------
// Image (multimodal) — Phase IM
//
// CLIP image vectors live alongside text chunks. Same backends, additional
// methods. Default model: Xenova/clip-vit-base-patch32 (512-d vectors). The
// CLIP text encoder produces vectors in the same space, so a text query can
// retrieve images directly without an intermediate caption step.
// --------------------------------------------------------------------------

export interface ImageVec {
  /** Stable id — matches `ImageEmbedding.id`. */
  id: string;
  /** CLIP image vector (default 512-d). */
  vector: number[];
  metadata: ImageMetadata;
}

export interface ImageMetadata {
  organizationId: string;
  indexId: string;
  documentId: string;
  /** Optional link to the parent text chunk (the FigureBlock chunk). */
  chunkId?: string;
  /** Path under uploads/images/. */
  imagePath: string;
  mimeType: string;
  page?: number;
  caption?: string;
  /** OCR/vision-LLM derived text — denormalized here for hit display. */
  ocrText?: string;
  width?: number;
  height?: number;
}

export interface ImageSearchOpts {
  topK: number;
  minScore?: number;
  filter?: { documentIds?: string[] };
}

export interface ImageHit {
  id: string;
  score: number;
  imagePath?: string;
  caption?: string;
  ocrText?: string;
  page?: number;
  documentId?: string;
  chunkId?: string;
}

/** Capabilities a backend may extend with for multimodal storage. */
export interface VectorStoreImages {
  /** True when the backend can store + search image vectors. */
  readonly supportsImages: boolean;
  /** Bulk upsert images. Called by the parser pipeline post-CLIP-encoding. */
  upsertImages(images: ImageVec[]): Promise<void>;
  /**
   * Search images by a CLIP-space query vector. The query vector should come
   * from `embedTextForImageSearch(query)` (text in CLIP space) or
   * `embedImage(buffer)` (find similar images).
   */
  searchImages(
    organizationId: string,
    indexId: string,
    queryVector: number[],
    opts: ImageSearchOpts,
  ): Promise<ImageHit[]>;
  /** Bulk delete by image id. */
  deleteImages(organizationId: string, imageIds: string[]): Promise<void>;
  /** Drop all images for one index. */
  deleteImagesForIndex(organizationId: string, indexId: string): Promise<void>;
}
