// MilvusVectorStore — gRPC-backed vector store implementation.
//
// Implements the contract in `./types.ts`. Loaded by V1's resolver via
// dynamic import (`await import("@/lib/ai/vector/milvus")`) so installing the
// `@zilliz/milvus2-sdk-node` dep is only paid by orgs that opted in.
//
// --- Tenant isolation ---
//
// Two strategies, picked per org via `OrgAiConfig.milvusIsolation`:
//
//   "partition"  — single base collection (default name "autorfp_chunks")
//                  with `organizationId` declared as the partition_key field.
//                  Milvus routes inserts to a partition keyed by the value;
//                  search queries that include `organizationId == "<org>"` in
//                  the filter expression are pushed down to the matching
//                  partition only. Cheap, scales to thousands of orgs.
//
//   "collection" — one collection per org named `<base>_<safeOrgId>`. Heavier
//                  (each collection has its own gRPC handle, index files,
//                  load state) but provides hard isolation when an enterprise
//                  customer demands "no shared physical storage".
//
// In BOTH strategies, every search() call constructs a filter expression that
// includes `organizationId == "<orgId>"` — the partition_key is a routing
// hint, not an enforcement boundary; the WHERE clause is mandatory.
//
// --- Hybrid search ---
//
// We declare `supportsHybrid = true`. When the caller passes
// `opts.hybrid && opts.sparseQuery`, we issue a Milvus hybrid_search request
// with two ANN sub-requests (dense COSINE + sparse IP) and an RRFRanker for
// server-side fusion. Otherwise we issue a plain dense search.
//
// --- Connection pooling & reliability ---
//
//   * One MilvusClient per (uri, token) pair, cached at module scope. The
//     gRPC channel is multiplexed safely across concurrent requests.
//   * Every method runs through a per-uri circuit breaker so a wedged Milvus
//     fails fast instead of stacking up timeouts.
//   * Tokens are decrypted from `OrgAiConfig.milvusTokenEncrypted` on
//     factory construction; the plaintext never leaves this module.

import type {
  ChunkVec,
  ImageHit,
  ImageSearchOpts,
  ImageVec,
  VectorHealth,
  VectorHit,
  VectorSearchOpts,
  VectorStore,
  VectorStoreImages,
} from "./types";
import { prisma } from "@/lib/prisma";
import { decrypt } from "@/lib/crypto";
import { env } from "@/lib/env";
import { createBreaker, type Breaker } from "@/lib/circuit-breaker";
import { log } from "@/lib/logger";
import {
  vectorUpsertsTotal,
  vectorSearchesTotal,
  vectorSearchDurationMs,
  vectorHealthStatus,
  imageSearchesTotal,
} from "@/lib/metrics";

// SDK type imports kept narrow; we import the runtime client lazily so
// importing this file doesn't drag the gRPC stack into route bundles.
type MilvusClient = import("@zilliz/milvus2-sdk-node").MilvusClient;

const DEFAULT_COLLECTION = "autorfp_chunks";
const DEFAULT_DIM = 384;
/**
 * CLIP image vector dimension. Default is 512 — Xenova/clip-vit-base-patch32.
 * Using a fixed dim per process is fine because images live in their own
 * collection and we never mix CLIP with text-embedding vectors.
 */
const DEFAULT_IMAGE_DIM = 512;

/**
 * Milvus connection cache keyed by `<uri>::<tokenSha>` — we hash the token
 * (rather than concatenating it raw) so the cache key is safe to log if the
 * map ever leaks via an introspection endpoint.
 */
const clientCache = new Map<string, MilvusClient>();

/** One breaker per Milvus URI. Failure mode is shared across collections. */
const breakerCache = new Map<string, Breaker>();

interface MilvusOpts {
  uri: string;
  token?: string;
  collection: string;
  isolation: "partition" | "collection";
  embeddingDim: number;
  /** CLIP vector dim for the images collection. Defaults to 512 if omitted. */
  imageDim?: number;
}

export class MilvusVectorStore implements VectorStore, VectorStoreImages {
  readonly id = "milvus" as const;
  readonly version = "milvus-1";
  readonly supportsHybrid = true;
  /**
   * IM (multimodal) — Milvus stores image vectors in a SECOND collection
   * (`<base>_images`, or `<base>_<safeOrgId>_images` in collection isolation).
   * A separate collection is cleaner than a multi-vector field: different
   * dimensions, independent index params, and broader compatibility with
   * older Milvus versions. `initOrg` provisions both collections atomically.
   */
  readonly supportsImages = true;

  private client: MilvusClient | null = null;
  private breaker: Breaker;
  private readonly cacheKey: string;

  constructor(private opts: MilvusOpts) {
    this.cacheKey = `${opts.uri}::${tokenFingerprint(opts.token)}`;
    let breaker = breakerCache.get(opts.uri);
    if (!breaker) {
      breaker = createBreaker({
        name: `milvus:${opts.uri}`,
        failureThreshold: 5,
        resetTimeoutMs: 30_000,
      });
      breakerCache.set(opts.uri, breaker);
    }
    this.breaker = breaker;
  }

  // -------------------------------------------------------------------------
  // Lazy client setup
  // -------------------------------------------------------------------------

  private async getClient(): Promise<MilvusClient> {
    if (this.client) return this.client;
    const cached = clientCache.get(this.cacheKey);
    if (cached) {
      this.client = cached;
      return cached;
    }
    const { MilvusClient } = await import("@zilliz/milvus2-sdk-node");
    // The SDK accepts either `host:port` or a full URI. Local Milvus over
    // gRPC needs `host:port` (no protocol); managed Zilliz Cloud needs the
    // full https URI. Detect: if URI has http(s) scheme + non-default port,
    // pass through as-is (Zilliz). Otherwise strip scheme so plain gRPC works.
    const rawUri = this.opts.uri;
    const address = rawUri.startsWith("https://")
      ? rawUri // Zilliz Cloud / TLS — keep scheme
      : rawUri.replace(/^https?:\/\//, ""); // local Milvus — strip scheme
    const client = new MilvusClient({
      address,
      token: this.opts.token ? this.opts.token : undefined,
      // Disable TLS auto-detection for plain http addresses.
      ssl: rawUri.startsWith("https://"),
    });
    clientCache.set(this.cacheKey, client);
    this.client = client;
    return client;
  }

  // -------------------------------------------------------------------------
  // Schema helpers
  // -------------------------------------------------------------------------

  /** Returns the per-org collection name when isolation === "collection". */
  private collectionName(orgId: string): string {
    if (this.opts.isolation === "collection") {
      return `${this.opts.collection}_${safeName(orgId)}`;
    }
    return this.opts.collection;
  }

  /**
   * Image collection name. Always suffixed with `_images` so it never
   * collides with the chunks collection. In collection-isolation mode the
   * orgId comes between the base and the suffix:
   *   partition  → autorfp_chunks_images
   *   collection → autorfp_chunks_<safeOrgId>_images
   */
  private imageCollectionName(orgId: string): string {
    if (this.opts.isolation === "collection") {
      return `${this.opts.collection}_${safeName(orgId)}_images`;
    }
    return `${this.opts.collection}_images`;
  }

  /**
   * Field schema for the image collection. Compact metadata: just the
   * filterable fields plus the CLIP vector. Fuller payload (caption / OCR /
   * imagePath) is stored too so search results can be rendered without a
   * second DB lookup, mirroring how Postgres returns them inline.
   */
  private async imageFieldSchema(): Promise<unknown[]> {
    const { DataType } = await import("@zilliz/milvus2-sdk-node");
    const dim = this.opts.imageDim ?? DEFAULT_IMAGE_DIM;
    return [
      {
        name: "id",
        data_type: DataType.VarChar,
        is_primary_key: true,
        autoID: false,
        max_length: 64,
      },
      {
        name: "organizationId",
        data_type: DataType.VarChar,
        max_length: 64,
        // Same partition_key trick as the chunks collection — only meaningful
        // when isolation === "partition".
        is_partition_key: this.opts.isolation === "partition",
      },
      { name: "indexId", data_type: DataType.VarChar, max_length: 64 },
      { name: "documentId", data_type: DataType.VarChar, max_length: 64 },
      { name: "chunkId", data_type: DataType.VarChar, max_length: 64 },
      { name: "page", data_type: DataType.Int32 },
      { name: "imagePath", data_type: DataType.VarChar, max_length: 512 },
      { name: "caption", data_type: DataType.VarChar, max_length: 512 },
      { name: "ocrText", data_type: DataType.VarChar, max_length: 2048 },
      { name: "vector", data_type: DataType.FloatVector, dim },
    ];
  }

  /**
   * Field schema used for `createCollection`. Reads cleanly against the
   * runtime DataType enum so a typo in the field type explodes at create
   * time rather than silently inserting wrong-shaped vectors.
   */
  private async fieldSchema(includeSparse: boolean): Promise<unknown[]> {
    const { DataType } = await import("@zilliz/milvus2-sdk-node");
    return [
      {
        name: "id",
        data_type: DataType.VarChar,
        is_primary_key: true,
        autoID: false,
        max_length: 64,
      },
      {
        name: "organizationId",
        data_type: DataType.VarChar,
        max_length: 64,
        // Only mark as partition_key in the partition strategy. In collection
        // strategy each org has its own collection so the field is just data.
        is_partition_key: this.opts.isolation === "partition",
      },
      { name: "indexId", data_type: DataType.VarChar, max_length: 64 },
      { name: "documentId", data_type: DataType.VarChar, max_length: 64 },
      { name: "section", data_type: DataType.VarChar, max_length: 512 },
      { name: "kind", data_type: DataType.VarChar, max_length: 32 },
      { name: "page", data_type: DataType.Int32 },
      { name: "anchor", data_type: DataType.VarChar, max_length: 64 },
      {
        name: "embedding",
        data_type: DataType.FloatVector,
        dim: this.opts.embeddingDim,
      },
      ...(includeSparse
        ? [{ name: "sparse", data_type: DataType.SparseFloatVector }]
        : []),
    ];
  }

  // -------------------------------------------------------------------------
  // initOrg
  // -------------------------------------------------------------------------

  async initOrg(orgId: string): Promise<void> {
    return this.breaker(async () => {
      const client = await this.getClient();
      const name = this.collectionName(orgId);

      const exists = await client.hasCollection({ collection_name: name });
      if (!exists.value) {
        const fields = await this.fieldSchema(true);
        const createReq: Record<string, unknown> = {
          collection_name: name,
          fields,
          // num_partitions is meaningful only when a partition_key is
          // declared; harmless otherwise. 64 is Milvus' default-ish for
          // partition_key collections.
          num_partitions: this.opts.isolation === "partition" ? 64 : undefined,
        };
        await client.createCollection(createReq as never);
      }

      // Create indexes (idempotent — Milvus returns ok if already present).
      const { MetricType, IndexType } = await import("@zilliz/milvus2-sdk-node");
      await client.createIndex({
        collection_name: name,
        field_name: "embedding",
        index_name: "embedding_hnsw",
        index_type: IndexType.HNSW,
        metric_type: MetricType.COSINE,
        params: { M: 16, efConstruction: 200 },
      } as never);

      try {
        await client.createIndex({
          collection_name: name,
          field_name: "sparse",
          index_name: "sparse_inv",
          index_type: IndexType.SPARSE_INVERTED_INDEX,
          metric_type: MetricType.IP,
          params: { drop_ratio_build: 0.2 },
        } as never);
      } catch (err) {
        // Sparse index can fail on older Milvus servers; log but don't tank
        // the whole init — dense path still works.
        log().warn(
          { err: errSummary(err), orgId, collection: name },
          "milvus sparse index creation failed (continuing)",
        );
      }

      // Load the collection so subsequent searches succeed without an
      // explicit Load step.
      await client.loadCollection({ collection_name: name });

      // ------------------------------------------------------------------
      // IM (multimodal) — provision the images collection alongside chunks.
      // Idempotent: same hasCollection / createCollection / createIndex /
      // loadCollection dance, but on the `<base>_images` name with a CLIP
      // 512-d FloatVector field. Failures here log+continue so an
      // older Milvus that can't accept the image schema doesn't tank the
      // whole org init — text retrieval still works.
      // ------------------------------------------------------------------
      try {
        const imageName = this.imageCollectionName(orgId);
        const imageExists = await client.hasCollection({ collection_name: imageName });
        if (!imageExists.value) {
          const fields = await this.imageFieldSchema();
          const createReq: Record<string, unknown> = {
            collection_name: imageName,
            fields,
            num_partitions:
              this.opts.isolation === "partition" ? 64 : undefined,
          };
          await client.createCollection(createReq as never);
        }
        await client.createIndex({
          collection_name: imageName,
          field_name: "vector",
          index_name: "image_vector_hnsw",
          index_type: IndexType.HNSW,
          metric_type: MetricType.COSINE,
          params: { M: 16, efConstruction: 200 },
        } as never);
        await client.loadCollection({ collection_name: imageName });

        log().info(
          { orgId, collection: imageName, isolation: this.opts.isolation },
          "milvus initOrg images ok",
        );
      } catch (err) {
        log().warn(
          { err: errSummary(err), orgId },
          "milvus images collection init failed (continuing — text search still works)",
        );
      }

      log().info(
        { orgId, collection: name, isolation: this.opts.isolation },
        "milvus initOrg ok",
      );
    });
  }

  // -------------------------------------------------------------------------
  // upsert
  // -------------------------------------------------------------------------

  async upsert(chunks: ChunkVec[]): Promise<void> {
    if (chunks.length === 0) return;
    const orgId = chunks[0].metadata.organizationId;
    const name = this.collectionName(orgId);

    return this.breaker(async () => {
      const client = await this.getClient();

      const BATCH = 200;
      try {
        for (let i = 0; i < chunks.length; i += BATCH) {
          const slice = chunks.slice(i, i + BATCH);
          const data = slice.map((c) => ({
            id: c.id,
            organizationId: c.metadata.organizationId,
            indexId: c.metadata.indexId,
            documentId: c.metadata.documentId,
            section: truncate(c.metadata.section ?? "", 512),
            kind: truncate(c.metadata.kind ?? "", 32),
            page: c.metadata.page ?? 0,
            anchor: truncate(c.metadata.anchor ?? "", 64),
            embedding: c.embedding,
            ...(c.sparseEmbedding
              ? { sparse: sparseToMilvus(c.sparseEmbedding) }
              : {}),
          }));
          await client.insert({ collection_name: name, data } as never);
        }
        vectorUpsertsTotal.inc({ backend: "milvus", result: "ok" }, chunks.length);
      } catch (err) {
        vectorUpsertsTotal.inc({ backend: "milvus", result: "error" }, chunks.length);
        throw err;
      }
    });
  }

  // -------------------------------------------------------------------------
  // search
  // -------------------------------------------------------------------------

  async search(
    organizationId: string,
    indexId: string,
    queryEmbedding: number[],
    opts: VectorSearchOpts,
  ): Promise<VectorHit[]> {
    return this.breaker(async () => {
      const client = await this.getClient();
      const name = this.collectionName(organizationId);
      const filter = buildFilterExpression(organizationId, indexId, opts);
      const hybrid = Boolean(opts.hybrid && opts.sparseQuery);
      const started = Date.now();

      try {
        let raw: { results?: Array<Record<string, unknown>> };
        if (hybrid && opts.sparseQuery) {
          raw = (await client.hybridSearch({
            collection_name: name,
            data: [
              {
                anns_field: "embedding",
                data: [queryEmbedding],
                params: { metric_type: "COSINE", ef: 64 },
              },
              {
                anns_field: "sparse",
                data: [sparseToMilvus(opts.sparseQuery)],
                params: { metric_type: "IP", drop_ratio_search: 0.2 },
              },
            ],
            rerank: { strategy: "rrf", params: { k: 60 } },
            limit: opts.topK,
            output_fields: ["id"],
            filter,
          } as never)) as never;
        } else {
          raw = (await client.search({
            collection_name: name,
            data: [queryEmbedding],
            anns_field: "embedding",
            limit: opts.topK,
            output_fields: ["id"],
            filter,
            params: { metric_type: "COSINE", ef: 64 },
          } as never)) as never;
        }

        const hits = mapMilvusHits(raw, hybrid, opts.minScore ?? 0);
        vectorSearchesTotal.inc({
          backend: "milvus",
          hybrid: hybrid ? "true" : "false",
          result: "ok",
        });
        vectorSearchDurationMs.observe({ backend: "milvus" }, Date.now() - started);
        return hits;
      } catch (err) {
        vectorSearchesTotal.inc({
          backend: "milvus",
          hybrid: hybrid ? "true" : "false",
          result: "error",
        });
        vectorSearchDurationMs.observe({ backend: "milvus" }, Date.now() - started);
        throw err;
      }
    });
  }

  // -------------------------------------------------------------------------
  // delete / deleteIndex
  // -------------------------------------------------------------------------

  async delete(organizationId: string, chunkIds: string[]): Promise<void> {
    if (chunkIds.length === 0) return;
    return this.breaker(async () => {
      const client = await this.getClient();
      const name = this.collectionName(organizationId);
      const idList = chunkIds.map((id) => `"${escapeExpr(id)}"`).join(",");
      const expr = `organizationId == "${escapeExpr(organizationId)}" && id in [${idList}]`;
      await client.deleteEntities({ collection_name: name, expr } as never);
    });
  }

  async deleteIndex(organizationId: string, indexId: string): Promise<void> {
    return this.breaker(async () => {
      const client = await this.getClient();
      const name = this.collectionName(organizationId);
      const expr = `organizationId == "${escapeExpr(organizationId)}" && indexId == "${escapeExpr(indexId)}"`;
      await client.deleteEntities({ collection_name: name, expr } as never);
    });
  }

  // -------------------------------------------------------------------------
  // Image (multimodal) — Phase IM
  //
  // All four methods route to the SEPARATE images collection. Tenant
  // isolation invariant matches the chunks collection: every search /
  // delete expression includes `organizationId == "<orgId>"`. Distance
  // metric is COSINE (CLIP vectors are L2-normalised → score is already in
  // 0..1 from Milvus).
  // -------------------------------------------------------------------------

  async upsertImages(images: ImageVec[]): Promise<void> {
    if (images.length === 0) return;
    const orgId = images[0].metadata.organizationId;
    const name = this.imageCollectionName(orgId);

    return this.breaker(async () => {
      const client = await this.getClient();
      const BATCH = 200;
      for (let i = 0; i < images.length; i += BATCH) {
        const slice = images.slice(i, i + BATCH);
        const data = slice.map((img) => ({
          id: img.id,
          organizationId: img.metadata.organizationId,
          indexId: img.metadata.indexId,
          documentId: img.metadata.documentId,
          chunkId: img.metadata.chunkId ?? "",
          page: img.metadata.page ?? 0,
          imagePath: truncate(img.metadata.imagePath ?? "", 512),
          caption: truncate(img.metadata.caption ?? "", 512),
          ocrText: truncate(img.metadata.ocrText ?? "", 2048),
          vector: img.vector,
        }));
        await client.insert({ collection_name: name, data } as never);
      }
    });
  }

  async searchImages(
    organizationId: string,
    indexId: string,
    queryVector: number[],
    opts: ImageSearchOpts,
  ): Promise<ImageHit[]> {
    return this.breaker(async () => {
      const client = await this.getClient();
      const name = this.imageCollectionName(organizationId);
      const filter = buildImageFilterExpression(organizationId, indexId, opts);

      try {
        const raw = (await client.search({
          collection_name: name,
          data: [queryVector],
          anns_field: "vector",
          limit: opts.topK,
          output_fields: [
            "id",
            "imagePath",
            "caption",
            "ocrText",
            "page",
            "documentId",
            "chunkId",
          ],
          filter,
          params: { metric_type: "COSINE", ef: 64 },
        } as never)) as { results?: Array<Record<string, unknown>> };

        const hits = mapMilvusImageHits(raw, opts.minScore ?? 0);
        imageSearchesTotal.inc({ backend: "milvus", result: "ok" });
        return hits;
      } catch (err) {
        imageSearchesTotal.inc({ backend: "milvus", result: "error" });
        throw err;
      }
    });
  }

  async deleteImages(organizationId: string, imageIds: string[]): Promise<void> {
    if (imageIds.length === 0) return;
    return this.breaker(async () => {
      const client = await this.getClient();
      const name = this.imageCollectionName(organizationId);
      const idList = imageIds.map((id) => `"${escapeExpr(id)}"`).join(",");
      const expr = `organizationId == "${escapeExpr(organizationId)}" && id in [${idList}]`;
      await client.deleteEntities({ collection_name: name, expr } as never);
    });
  }

  async deleteImagesForIndex(organizationId: string, indexId: string): Promise<void> {
    return this.breaker(async () => {
      const client = await this.getClient();
      const name = this.imageCollectionName(organizationId);
      const expr = `organizationId == "${escapeExpr(organizationId)}" && indexId == "${escapeExpr(indexId)}"`;
      await client.deleteEntities({ collection_name: name, expr } as never);
    });
  }

  // -------------------------------------------------------------------------
  // health
  // -------------------------------------------------------------------------

  async health(organizationId: string): Promise<VectorHealth> {
    const started = Date.now();
    try {
      return await this.breaker(async () => {
        const client = await this.getClient();
        const name = this.collectionName(organizationId);

        const has = await client.hasCollection({ collection_name: name });
        if (!has.value) {
          // Collection doesn't exist yet — that's still a healthy connection;
          // initOrg will create it on first write.
          vectorHealthStatus.set({ backend: "milvus" }, 1);
          return {
            ok: true,
            ms: Date.now() - started,
            detail: `collection ${name} not yet created`,
            vectorCount: 0,
          };
        }
        const stats = await client.getCollectionStatistics({ collection_name: name });
        const count = readRowCount(stats);
        vectorHealthStatus.set({ backend: "milvus" }, 1);
        return {
          ok: true,
          ms: Date.now() - started,
          detail: `collection ${name} ok`,
          vectorCount: count,
        };
      });
    } catch (err) {
      vectorHealthStatus.set({ backend: "milvus" }, 0);
      return {
        ok: false,
        ms: Date.now() - started,
        detail: err instanceof Error ? err.message : String(err),
      };
    }
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function tokenFingerprint(token?: string): string {
  if (!token) return "no-token";
  // Cheap non-cryptographic fingerprint — only used as a cache key, not for
  // any auth purpose. Avoids leaking the token via map iteration.
  let h = 5381;
  for (let i = 0; i < token.length; i++) {
    h = ((h << 5) + h) ^ token.charCodeAt(i);
  }
  return `t${(h >>> 0).toString(36)}`;
}

function safeName(s: string): string {
  // Milvus collection names: letters/digits/underscore only. Map anything
  // else to underscore so cuids etc. are accepted.
  return s.replace(/[^A-Za-z0-9_]/g, "_").slice(0, 200);
}

function truncate(s: string, max: number): string {
  if (s.length <= max) return s;
  return s.slice(0, max);
}

function sparseToMilvus(v: { indices: number[]; values: number[] }): Record<string, number> {
  // Milvus' SparseFloatVector accepts a `{ "<dim>": <weight>, ... }` map.
  const out: Record<string, number> = {};
  for (let i = 0; i < v.indices.length; i++) {
    out[String(v.indices[i])] = v.values[i] ?? 0;
  }
  return out;
}

function escapeExpr(s: string): string {
  // Milvus filter expression strings — escape backslash + double-quote.
  return s.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

export function buildFilterExpression(
  organizationId: string,
  indexId: string,
  opts: VectorSearchOpts,
): string {
  const parts: string[] = [
    `organizationId == "${escapeExpr(organizationId)}"`,
    `indexId == "${escapeExpr(indexId)}"`,
  ];
  if (opts.filter?.documentIds?.length) {
    const list = opts.filter.documentIds.map((id) => `"${escapeExpr(id)}"`).join(",");
    parts.push(`documentId in [${list}]`);
  }
  if (opts.filter?.sections?.length) {
    const list = opts.filter.sections.map((s) => `"${escapeExpr(s)}"`).join(",");
    parts.push(`section in [${list}]`);
  }
  if (opts.filter?.kinds?.length) {
    const list = opts.filter.kinds.map((k) => `"${escapeExpr(k)}"`).join(",");
    parts.push(`kind in [${list}]`);
  }
  return parts.join(" && ");
}

/**
 * Filter expression builder for the images collection. Mirrors
 * `buildFilterExpression` but only the documentIds filter is supported on
 * images (no sections/kinds — those are text-chunk concepts). Tenant
 * isolation invariant: orgId is ALWAYS pinned via equality.
 */
export function buildImageFilterExpression(
  organizationId: string,
  indexId: string,
  opts: ImageSearchOpts,
): string {
  const parts: string[] = [
    `organizationId == "${escapeExpr(organizationId)}"`,
    `indexId == "${escapeExpr(indexId)}"`,
  ];
  if (opts.filter?.documentIds?.length) {
    const list = opts.filter.documentIds.map((id) => `"${escapeExpr(id)}"`).join(",");
    parts.push(`documentId in [${list}]`);
  }
  return parts.join(" && ");
}

function mapMilvusImageHits(
  raw: { results?: Array<Record<string, unknown>> },
  minScore: number,
): ImageHit[] {
  const out: ImageHit[] = [];
  const rows = Array.isArray(raw.results) ? raw.results : [];
  for (const r of rows) {
    const id = String(r.id ?? "");
    if (!id) continue;
    const scoreRaw = (r.score ?? r.distance) as number | undefined;
    const score = typeof scoreRaw === "number" ? scoreRaw : 0;
    if (score < minScore) continue;
    const chunkId = typeof r.chunkId === "string" && r.chunkId.length > 0 ? r.chunkId : undefined;
    out.push({
      id,
      score,
      imagePath: typeof r.imagePath === "string" ? r.imagePath : undefined,
      caption: typeof r.caption === "string" && r.caption.length > 0 ? r.caption : undefined,
      ocrText: typeof r.ocrText === "string" && r.ocrText.length > 0 ? r.ocrText : undefined,
      page: typeof r.page === "number" && r.page > 0 ? r.page : undefined,
      documentId: typeof r.documentId === "string" ? r.documentId : undefined,
      chunkId,
    });
  }
  return out;
}

function mapMilvusHits(
  raw: { results?: Array<Record<string, unknown>> },
  hybrid: boolean,
  minScore: number,
): VectorHit[] {
  const out: VectorHit[] = [];
  const rows = Array.isArray(raw.results) ? raw.results : [];
  for (const r of rows) {
    const id = String(r.id ?? "");
    if (!id) continue;
    // COSINE in Milvus is "similarity" and reported in [0,1] (1 = identical).
    // The SDK exposes this as `score` (newer) or `distance` (legacy).
    const scoreRaw = (r.score ?? r.distance) as number | undefined;
    const score = typeof scoreRaw === "number" ? scoreRaw : 0;
    if (score < minScore) continue;
    out.push({
      id,
      score,
      source: hybrid ? "hybrid" : "dense",
    });
  }
  return out;
}

function readRowCount(stats: unknown): number | undefined {
  // getCollectionStatistics returns { stats: [{key:"row_count", value:"123"}], ... }
  if (!stats || typeof stats !== "object") return undefined;
  const arr = (stats as { stats?: Array<{ key?: string; value?: string }> }).stats;
  if (!Array.isArray(arr)) return undefined;
  for (const kv of arr) {
    if (kv?.key === "row_count" && typeof kv.value === "string") {
      const n = Number(kv.value);
      if (Number.isFinite(n)) return n;
    }
  }
  return undefined;
}

function errSummary(err: unknown): Record<string, unknown> {
  if (err instanceof Error) return { name: err.name, message: err.message };
  return { value: String(err) };
}

// ---------------------------------------------------------------------------
// Factory — used by V1's resolver and by the per-org test/migrate routes.
// ---------------------------------------------------------------------------

/**
 * Build a MilvusVectorStore for an org by reading the encrypted config. Throws
 * when the org has no Milvus config. Caller is responsible for confirming
 * `vectorBackend === MILVUS` if that matters to them.
 */
export async function createMilvusForOrg(orgId: string): Promise<MilvusVectorStore> {
  const cfg = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: {
      milvusUri: true,
      milvusTokenEncrypted: true,
      milvusCollection: true,
      milvusIsolation: true,
      embeddingDimensions: true,
    },
  });
  if (!cfg?.milvusUri) {
    throw new Error(`Org ${orgId} has no milvusUri configured`);
  }
  const token = cfg.milvusTokenEncrypted ? decrypt(cfg.milvusTokenEncrypted) ?? undefined : undefined;
  return new MilvusVectorStore({
    uri: cfg.milvusUri,
    token,
    collection: cfg.milvusCollection?.trim() || DEFAULT_COLLECTION,
    isolation: (cfg.milvusIsolation === "collection" ? "collection" : "partition") as
      | "partition"
      | "collection",
    embeddingDim: cfg.embeddingDimensions ?? env.EMBEDDING_DIMENSIONS ?? DEFAULT_DIM,
    // Image dim isn't tunable per-org today — CLIP is one model. Plumbed via
    // the constructor so a future per-org override (different CLIP variant)
    // is a one-line change.
    imageDim: DEFAULT_IMAGE_DIM,
  });
}

/** @internal — for tests. Drop the cached client + breaker maps. */
export function _resetMilvusCachesForTests(): void {
  clientCache.clear();
  breakerCache.clear();
}

export const _MILVUS_DEFAULTS = { DEFAULT_COLLECTION, DEFAULT_DIM, DEFAULT_IMAGE_DIM };
