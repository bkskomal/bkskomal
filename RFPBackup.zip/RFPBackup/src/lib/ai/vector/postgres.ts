// PostgresVectorStore — the default vector backend.
//
// Wraps the existing `DocumentChunk.embedding` Float[] column behaviour into
// the `VectorStore` contract. Zero behavioural change for users on the default
// backend: search() runs the same in-process cosine that retrieval.ts has
// always done; upsert() patches the embedding column on chunk rows that the
// ingest pipeline already created.
//
// Tenant isolation is enforced at the SQL layer via the `Document.indexId →
// KnowledgeIndex.organizationId` join — a lookup for org A can never return
// chunks belonging to org B because we always filter by indexId AND join the
// index back to the requesting org.
//
// Soft-delete contract:
//   - delete(chunkIds): clears the embedding (sets to []) but leaves the row.
//     The chunk's text is still queryable for source citations on existing
//     ResponseSource rows. The row itself is removed by upstream Prisma calls
//     (e.g. cascading from Document delete).
//   - deleteIndex(indexId): same — clears all embeddings under the index.

import { prisma } from "@/lib/prisma";
import type {
  ChunkVec,
  ImageHit,
  ImageSearchOpts,
  ImageVec,
  VectorHealth,
  VectorHit,
  VectorSearchOpts,
  VectorStore,
  VectorStoreImages,
} from "./types";
import { imageSearchesTotal } from "@/lib/metrics";

export class PostgresVectorStore implements VectorStore, VectorStoreImages {
  readonly id = "postgres" as const;
  readonly version = "pg-1";
  readonly supportsHybrid = false;
  /**
   * IM (multimodal) — Postgres can transparently store CLIP image vectors in
   * the `ImageEmbedding.vector` Float[] column, parallel to text chunk
   * embeddings on `DocumentChunk.embedding`. Search runs the same in-process
   * cosine the dense text path uses, no extra deps required.
   */
  readonly supportsImages = true;

  /**
   * Postgres tables already exist via the Prisma migration. Nothing to do.
   * Kept as a no-op so callers can treat all backends uniformly.
   */
  async initOrg(_orgId: string): Promise<void> {
    // intentional no-op
  }

  /**
   * Patch the `embedding` column on chunk rows that the ingest pipeline has
   * already created. Run inside a single transaction so a partial failure
   * leaves the index in a consistent state.
   */
  async upsert(chunks: ChunkVec[]): Promise<void> {
    if (chunks.length === 0) return;
    await prisma.$transaction(
      chunks.map((c) =>
        prisma.documentChunk.update({
          where: { id: c.id },
          data: { embedding: c.embedding },
        }),
      ),
    );
  }

  /**
   * Dense cosine search. Loads candidate chunks scoped by indexId + (optional)
   * documentIds + sections + kinds, then computes cosine in-process — this
   * preserves the exact numerical behaviour of the legacy retrieval path.
   *
   * The `topK` here controls the candidate pool returned to the caller; the
   * caller (retrieval.ts) does its own RRF fusion against BM25 and then trims
   * to the user-facing topK.
   */
  async search(
    organizationId: string,
    indexId: string,
    queryEmbedding: number[],
    opts: VectorSearchOpts,
  ): Promise<VectorHit[]> {
    const queryNorm = norm(queryEmbedding);
    if (queryNorm === 0) return [];

    const chunks = await prisma.documentChunk.findMany({
      where: {
        document: {
          // Tenant isolation: the indexId belongs to a single org. We assert
          // the index is in `organizationId` so a leaked indexId can't be
          // used to read another org's chunks.
          indexId,
          status: "INDEXED",
          index: { organizationId },
          ...(opts.filter?.documentIds
            ? { id: { in: opts.filter.documentIds } }
            : {}),
        },
        ...(opts.filter?.sections
          ? { section: { in: opts.filter.sections } }
          : {}),
        ...(opts.filter?.kinds ? { kind: { in: opts.filter.kinds } } : {}),
      },
      select: { id: true, embedding: true },
    });
    if (chunks.length === 0) return [];

    const minScore = opts.minScore ?? 0;
    const hits: VectorHit[] = [];
    for (const c of chunks) {
      if (c.embedding.length !== queryEmbedding.length) continue;
      const cn = norm(c.embedding);
      if (cn === 0) continue;
      const score = dot(c.embedding, queryEmbedding) / (queryNorm * cn);
      if (score < minScore) continue;
      hits.push({ id: c.id, score, source: "dense" });
    }
    hits.sort((a, b) => b.score - a.score);
    return hits.slice(0, Math.max(0, opts.topK));
  }

  /**
   * Soft-delete: clear the embedding so the chunk is invisible to vector
   * search but text-queryable for ResponseSource citations. Hard delete of the
   * chunk row is the responsibility of upstream Prisma calls (e.g. Document
   * deletion cascading).
   */
  async delete(_organizationId: string, chunkIds: string[]): Promise<void> {
    if (chunkIds.length === 0) return;
    await prisma.documentChunk.updateMany({
      where: { id: { in: chunkIds } },
      data: { embedding: [] },
    });
  }

  /**
   * Clear embeddings for every chunk under an index. Same soft-delete
   * rationale as `delete`.
   */
  async deleteIndex(organizationId: string, indexId: string): Promise<void> {
    await prisma.documentChunk.updateMany({
      where: { document: { indexId, index: { organizationId } } },
      data: { embedding: [] },
    });
  }

  // -------------------------------------------------------------------------
  // Image (multimodal) — Phase IM
  //
  // The `ImageEmbedding` row is created by the parser pipeline (IM1) when an
  // image block is extracted; the row is created WITHOUT a vector and we
  // patch the `vector` column here once CLIP encoding finishes. Hard-delete
  // is safe for image rows because they are only a vector index entry — the
  // underlying file lives on disk under uploads/images/ and citations point
  // at the chunkId, not the embedding row.
  // -------------------------------------------------------------------------

  /**
   * Bulk patch the `vector` column on existing `ImageEmbedding` rows. We use
   * the same transaction-of-updates pattern as `upsert(chunks)` so a partial
   * failure leaves the index consistent.
   */
  async upsertImages(images: ImageVec[]): Promise<void> {
    if (images.length === 0) return;
    await prisma.$transaction(
      images.map((img) =>
        prisma.imageEmbedding.update({
          where: { id: img.id },
          data: { vector: img.vector },
        }),
      ),
    );
  }

  /**
   * Dense cosine search over `ImageEmbedding`. Same pattern as text search:
   * load candidates scoped by orgId + indexId (and optional documentIds),
   * compute cosine in-process, sort desc, return topK with score >= minScore.
   *
   * The query vector is expected to come from CLIP — either
   * `embedTextForImageSearch(query)` for text→image search or
   * `embedImage(buffer)` for image→image. CLIP vectors are L2-normalised so
   * cosine == dot product, but we compute it the safe way (divided by norms)
   * in case a caller passes an un-normalised vector.
   */
  async searchImages(
    organizationId: string,
    indexId: string,
    queryVector: number[],
    opts: ImageSearchOpts,
  ): Promise<ImageHit[]> {
    const queryNorm = norm(queryVector);
    if (queryNorm === 0) {
      imageSearchesTotal.inc({ backend: "postgres", result: "empty_query" });
      return [];
    }

    let rows;
    try {
      rows = await prisma.imageEmbedding.findMany({
        where: {
          organizationId,
          indexId,
          ...(opts.filter?.documentIds
            ? { documentId: { in: opts.filter.documentIds } }
            : {}),
        },
        select: {
          id: true,
          vector: true,
          imagePath: true,
          caption: true,
          ocrText: true,
          page: true,
          documentId: true,
          chunkId: true,
        },
      });
    } catch (err) {
      imageSearchesTotal.inc({ backend: "postgres", result: "error" });
      throw err;
    }
    if (rows.length === 0) {
      imageSearchesTotal.inc({ backend: "postgres", result: "ok" });
      return [];
    }

    const minScore = opts.minScore ?? 0;
    const hits: ImageHit[] = [];
    for (const r of rows) {
      if (!Array.isArray(r.vector) || r.vector.length !== queryVector.length) continue;
      const rn = norm(r.vector);
      if (rn === 0) continue;
      const score = dot(r.vector, queryVector) / (queryNorm * rn);
      if (score < minScore) continue;
      hits.push({
        id: r.id,
        score,
        imagePath: r.imagePath,
        caption: r.caption ?? undefined,
        ocrText: r.ocrText ?? undefined,
        page: r.page ?? undefined,
        documentId: r.documentId,
        chunkId: r.chunkId ?? undefined,
      });
    }
    hits.sort((a, b) => b.score - a.score);
    imageSearchesTotal.inc({ backend: "postgres", result: "ok" });
    return hits.slice(0, Math.max(0, opts.topK));
  }

  /**
   * Hard-delete image rows by id. Unlike text chunks (where the row is the
   * source of truth for citation excerpts), image rows are purely a vector
   * index entry — the actual image file on disk and the parent chunk both
   * survive. Scoped by orgId for tenant isolation.
   */
  async deleteImages(organizationId: string, imageIds: string[]): Promise<void> {
    if (imageIds.length === 0) return;
    await prisma.imageEmbedding.deleteMany({
      where: { id: { in: imageIds }, organizationId },
    });
  }

  /** Hard-delete every image embedding row under one index. */
  async deleteImagesForIndex(organizationId: string, indexId: string): Promise<void> {
    await prisma.imageEmbedding.deleteMany({
      where: { organizationId, indexId },
    });
  }

  /**
   * Cheap probe: count chunks under any index belonging to this org. The
   * count includes soft-deleted chunks (those with empty embeddings) — that's
   * intentional, since a stale chunk row still exists in Postgres.
   */
  async health(organizationId: string): Promise<VectorHealth> {
    const start = Date.now();
    try {
      const vectorCount = await prisma.documentChunk.count({
        where: { document: { index: { organizationId } } },
      });
      return { ok: true, ms: Date.now() - start, vectorCount };
    } catch (e) {
      return {
        ok: false,
        ms: Date.now() - start,
        detail: e instanceof Error ? e.message : String(e),
      };
    }
  }
}

// ---- Cosine helpers (centralised here, re-exported for retrieval.ts). ----

export function dot(a: number[], b: number[]): number {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * b[i];
  return s;
}

export function norm(a: number[]): number {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * a[i];
  return Math.sqrt(s);
}
