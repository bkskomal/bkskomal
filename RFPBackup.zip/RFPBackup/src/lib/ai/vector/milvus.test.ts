// Unit tests for MilvusVectorStore.
//
// We mock @zilliz/milvus2-sdk-node entirely — no real gRPC. The mock client
// records every call so each test can assert that the right schema, filter
// expression, or insert batch landed at the SDK boundary.
//
// Tenant-isolation invariant: every search() filter expression MUST include
// `organizationId == "<orgId>"`. We assert this in a dedicated test so a
// regression where the partition_key is treated as enforcement (it isn't —
// it's a routing hint) gets caught immediately.

import { describe, expect, it, beforeEach, vi } from "vitest";
import { _resetForTests as resetMetrics } from "@/lib/metrics";

// --- Mock the SDK ----------------------------------------------------------

const { mockClient, MilvusClientCtor } = vi.hoisted(() => {
  const mock = {
    hasCollection: vi.fn(),
    createCollection: vi.fn(),
    createIndex: vi.fn(),
    loadCollection: vi.fn(),
    insert: vi.fn(),
    search: vi.fn(),
    hybridSearch: vi.fn(),
    deleteEntities: vi.fn(),
    getCollectionStatistics: vi.fn(),
  };
  // Use a regular `function` (not arrow) so `new MilvusClient(...)` works —
  // arrow functions can't be called with `new`.
  const ctor = vi.fn(function MilvusClientMock() {
    return mock;
  });
  return { mockClient: mock, MilvusClientCtor: ctor };
});

vi.mock("@zilliz/milvus2-sdk-node", () => ({
  MilvusClient: MilvusClientCtor,
  DataType: {
    None: 0,
    VarChar: 21,
    Int32: 4,
    FloatVector: 101,
    SparseFloatVector: 104,
  },
  MetricType: { COSINE: "COSINE", IP: "IP" },
  IndexType: { HNSW: "HNSW", SPARSE_INVERTED_INDEX: "SPARSE_INVERTED_INDEX" },
  FunctionType: { BM25: 1 },
}));

import {
  MilvusVectorStore,
  buildFilterExpression,
  buildImageFilterExpression,
  _resetMilvusCachesForTests,
} from "./milvus";
import type { ChunkVec, ImageVec } from "./types";

const ORG_ID = "org-1";
const INDEX_ID = "idx-1";

function newStore(overrides: Partial<{
  uri: string;
  collection: string;
  isolation: "partition" | "collection";
  embeddingDim: number;
}> = {}) {
  return new MilvusVectorStore({
    uri: overrides.uri ?? "http://milvus.test:19530",
    token: "test-token",
    collection: overrides.collection ?? "autorfp_chunks",
    isolation: overrides.isolation ?? "partition",
    embeddingDim: overrides.embeddingDim ?? 384,
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  _resetMilvusCachesForTests();
  resetMetrics();
  // Defaults — tests can override.
  mockClient.hasCollection.mockResolvedValue({ value: false });
  mockClient.createCollection.mockResolvedValue({ error_code: "Success" });
  mockClient.createIndex.mockResolvedValue({ error_code: "Success" });
  mockClient.loadCollection.mockResolvedValue({ error_code: "Success" });
  mockClient.insert.mockResolvedValue({ status: { error_code: "Success" } });
  mockClient.search.mockResolvedValue({ results: [] });
  mockClient.hybridSearch.mockResolvedValue({ results: [] });
  mockClient.deleteEntities.mockResolvedValue({ status: { error_code: "Success" } });
  mockClient.getCollectionStatistics.mockResolvedValue({
    stats: [{ key: "row_count", value: "0" }],
  });
});

describe("MilvusVectorStore.initOrg (partition strategy)", () => {
  it("creates collection + indexes + loads when collection is missing", async () => {
    const store = newStore({ isolation: "partition" });
    await store.initOrg(ORG_ID);

    expect(mockClient.hasCollection).toHaveBeenCalledWith({
      collection_name: "autorfp_chunks",
    });
    // hasCollection is called for both chunks AND the images collection.
    expect(mockClient.createCollection).toHaveBeenCalledTimes(2);
    const createArg = mockClient.createCollection.mock.calls[0][0] as {
      collection_name: string;
      fields: Array<{ name: string; is_partition_key?: boolean; dim?: number }>;
    };
    expect(createArg.collection_name).toBe("autorfp_chunks");

    // organizationId must be the partition_key in partition strategy.
    const orgField = createArg.fields.find((f) => f.name === "organizationId");
    expect(orgField?.is_partition_key).toBe(true);

    // Embedding dim must be set on the FloatVector field.
    const embField = createArg.fields.find((f) => f.name === "embedding");
    expect(embField?.dim).toBe(384);

    expect(mockClient.createIndex).toHaveBeenCalledWith(
      expect.objectContaining({
        collection_name: "autorfp_chunks",
        field_name: "embedding",
        index_type: "HNSW",
        metric_type: "COSINE",
        params: expect.objectContaining({ M: 16, efConstruction: 200 }),
      }),
    );
    expect(mockClient.createIndex).toHaveBeenCalledWith(
      expect.objectContaining({
        field_name: "sparse",
        index_type: "SPARSE_INVERTED_INDEX",
      }),
    );
    expect(mockClient.loadCollection).toHaveBeenCalledWith({
      collection_name: "autorfp_chunks",
    });
  });

  it("skips createCollection when both the chunks AND images collections already exist", async () => {
    // Chunks collection AND images collection both report exists=true, so
    // initOrg only re-runs createIndex / loadCollection on each.
    mockClient.hasCollection
      .mockResolvedValueOnce({ value: true })
      .mockResolvedValueOnce({ value: true });
    const store = newStore({ isolation: "partition" });
    await store.initOrg(ORG_ID);
    expect(mockClient.createCollection).not.toHaveBeenCalled();
    // Still re-runs createIndex + load so newly added indexes get backfilled.
    expect(mockClient.createIndex).toHaveBeenCalled();
    expect(mockClient.loadCollection).toHaveBeenCalled();
  });

  it("continues init even if sparse index creation throws", async () => {
    mockClient.createIndex
      .mockResolvedValueOnce({ error_code: "Success" }) // dense
      .mockRejectedValueOnce(new Error("sparse not supported on this server"));
    const store = newStore();
    await expect(store.initOrg(ORG_ID)).resolves.toBeUndefined();
    expect(mockClient.loadCollection).toHaveBeenCalled();
  });
});

describe("MilvusVectorStore.initOrg (collection strategy)", () => {
  it("creates a per-org collection named <base>_<safeOrgId> (plus images)", async () => {
    const store = newStore({ isolation: "collection" });
    await store.initOrg("org-with-dashes");
    // Both chunks AND images collections get created.
    expect(mockClient.createCollection).toHaveBeenCalledTimes(2);
    const chunkCreate = mockClient.createCollection.mock.calls.find(
      (c) => (c[0] as { collection_name: string }).collection_name === "autorfp_chunks_org_with_dashes",
    )?.[0] as {
      collection_name: string;
      fields: Array<{ name: string; is_partition_key?: boolean }>;
    };
    expect(chunkCreate).toBeDefined();
    expect(chunkCreate.collection_name).toBe("autorfp_chunks_org_with_dashes");
    // partition_key NOT set in collection strategy.
    const orgField = chunkCreate.fields.find((f) => f.name === "organizationId");
    expect(orgField?.is_partition_key).toBe(false);
  });
});

describe("MilvusVectorStore.upsert", () => {
  it("batches inserts of 200", async () => {
    const store = newStore();
    const chunks: ChunkVec[] = Array.from({ length: 450 }, (_, i) => ({
      id: `chunk-${i}`,
      embedding: new Array(384).fill(0).map(() => Math.random()),
      metadata: {
        documentId: `doc-${i % 5}`,
        indexId: INDEX_ID,
        organizationId: ORG_ID,
        section: "Security / Encryption",
        kind: "paragraph",
        page: 1,
        anchor: `a${i}`,
      },
    }));
    await store.upsert(chunks);
    // 450 / 200 → ceil(450/200) = 3 batches.
    expect(mockClient.insert).toHaveBeenCalledTimes(3);
    const firstCall = mockClient.insert.mock.calls[0][0] as {
      collection_name: string;
      data: Array<Record<string, unknown>>;
    };
    expect(firstCall.collection_name).toBe("autorfp_chunks");
    expect(firstCall.data).toHaveLength(200);
    expect(firstCall.data[0]).toMatchObject({
      id: "chunk-0",
      organizationId: ORG_ID,
      indexId: INDEX_ID,
      documentId: "doc-0",
    });
  });

  it("returns early on empty input without hitting the SDK", async () => {
    const store = newStore();
    await store.upsert([]);
    expect(mockClient.insert).not.toHaveBeenCalled();
  });
});

describe("MilvusVectorStore.search filter expression", () => {
  it("builds an org+index filter and runs dense search by default", async () => {
    mockClient.search.mockResolvedValueOnce({
      results: [
        { id: "c1", score: 0.95 },
        { id: "c2", score: 0.8 },
      ],
    });
    const store = newStore();
    const hits = await store.search(ORG_ID, INDEX_ID, [0.1, 0.2, 0.3], { topK: 5 });
    expect(mockClient.hybridSearch).not.toHaveBeenCalled();
    expect(mockClient.search).toHaveBeenCalledTimes(1);
    const arg = mockClient.search.mock.calls[0][0] as { filter: string; limit: number };
    expect(arg.limit).toBe(5);
    expect(arg.filter).toContain(`organizationId == "${ORG_ID}"`);
    expect(arg.filter).toContain(`indexId == "${INDEX_ID}"`);
    expect(hits).toHaveLength(2);
    expect(hits[0]).toMatchObject({ id: "c1", score: 0.95, source: "dense" });
  });

  it("includes documentIds + sections + kinds when supplied", async () => {
    const expr = buildFilterExpression(ORG_ID, INDEX_ID, {
      topK: 5,
      filter: {
        documentIds: ["d1", "d2"],
        sections: ["Security"],
        kinds: ["paragraph", "table"],
      },
    });
    expect(expr).toContain('documentId in ["d1","d2"]');
    expect(expr).toContain('section in ["Security"]');
    expect(expr).toContain('kind in ["paragraph","table"]');
  });

  it("escapes embedded quotes/backslashes in filter values", async () => {
    const expr = buildFilterExpression(`evil"org\\name`, INDEX_ID, { topK: 1 });
    // The raw quote must be escaped as \" — otherwise a malicious orgId could
    // inject a clause.
    expect(expr).toContain('organizationId == "evil\\"org\\\\name"');
  });

  it("uses hybrid_search when opts.hybrid + sparseQuery are set", async () => {
    mockClient.hybridSearch.mockResolvedValueOnce({
      results: [{ id: "c1", score: 0.7 }],
    });
    const store = newStore();
    const hits = await store.search(ORG_ID, INDEX_ID, [0.1, 0.2], {
      topK: 3,
      hybrid: true,
      sparseQuery: { indices: [42, 99], values: [0.5, 1.0] },
    });
    expect(mockClient.search).not.toHaveBeenCalled();
    expect(mockClient.hybridSearch).toHaveBeenCalledTimes(1);
    const arg = mockClient.hybridSearch.mock.calls[0][0] as {
      data: Array<{ anns_field: string }>;
      filter: string;
    };
    expect(arg.data.map((d) => d.anns_field)).toEqual(["embedding", "sparse"]);
    expect(arg.filter).toContain(`organizationId == "${ORG_ID}"`);
    expect(hits[0].source).toBe("hybrid");
  });

  it("drops hits below opts.minScore", async () => {
    mockClient.search.mockResolvedValueOnce({
      results: [
        { id: "good", score: 0.9 },
        { id: "bad", score: 0.1 },
      ],
    });
    const store = newStore();
    const hits = await store.search(ORG_ID, INDEX_ID, [0], { topK: 5, minScore: 0.5 });
    expect(hits.map((h) => h.id)).toEqual(["good"]);
  });
});

describe("MilvusVectorStore.delete", () => {
  it("deletes by primary-key list scoped to org", async () => {
    const store = newStore();
    await store.delete(ORG_ID, ["c1", "c2"]);
    expect(mockClient.deleteEntities).toHaveBeenCalledTimes(1);
    const arg = mockClient.deleteEntities.mock.calls[0][0] as { expr: string };
    expect(arg.expr).toContain(`organizationId == "${ORG_ID}"`);
    expect(arg.expr).toContain('id in ["c1","c2"]');
  });

  it("no-ops on empty input", async () => {
    const store = newStore();
    await store.delete(ORG_ID, []);
    expect(mockClient.deleteEntities).not.toHaveBeenCalled();
  });

  it("deleteIndex deletes by org+index expression", async () => {
    const store = newStore();
    await store.deleteIndex(ORG_ID, INDEX_ID);
    const arg = mockClient.deleteEntities.mock.calls[0][0] as { expr: string };
    expect(arg.expr).toBe(`organizationId == "${ORG_ID}" && indexId == "${INDEX_ID}"`);
  });
});

describe("MilvusVectorStore.health", () => {
  it("returns ok with vectorCount when collection exists", async () => {
    mockClient.hasCollection.mockResolvedValueOnce({ value: true });
    mockClient.getCollectionStatistics.mockResolvedValueOnce({
      stats: [{ key: "row_count", value: "1234" }],
    });
    const store = newStore();
    const res = await store.health(ORG_ID);
    expect(res.ok).toBe(true);
    expect(res.vectorCount).toBe(1234);
  });

  it("returns ok=true with vectorCount=0 when collection doesn't exist yet", async () => {
    mockClient.hasCollection.mockResolvedValueOnce({ value: false });
    const store = newStore();
    const res = await store.health(ORG_ID);
    expect(res.ok).toBe(true);
    expect(res.vectorCount).toBe(0);
  });

  it("returns ok=false on connection error", async () => {
    mockClient.hasCollection.mockRejectedValueOnce(new Error("ECONNREFUSED"));
    const store = newStore();
    const res = await store.health(ORG_ID);
    expect(res.ok).toBe(false);
    expect(res.detail).toContain("ECONNREFUSED");
  });
});

// ---------------------------------------------------------------------------
// Image (multimodal) — Phase IM
// ---------------------------------------------------------------------------

describe("MilvusVectorStore — image collection provisioning (initOrg)", () => {
  it("creates BOTH the chunks collection AND the images collection", async () => {
    const store = newStore({ isolation: "partition" });
    await store.initOrg(ORG_ID);

    // hasCollection probed twice (chunks, images).
    expect(mockClient.hasCollection).toHaveBeenCalledWith({ collection_name: "autorfp_chunks" });
    expect(mockClient.hasCollection).toHaveBeenCalledWith({ collection_name: "autorfp_chunks_images" });

    // Both create + load.
    const createCalls = mockClient.createCollection.mock.calls.map(
      (c) => (c[0] as { collection_name: string }).collection_name,
    );
    expect(createCalls).toContain("autorfp_chunks");
    expect(createCalls).toContain("autorfp_chunks_images");

    const loadCalls = mockClient.loadCollection.mock.calls.map(
      (c) => (c[0] as { collection_name: string }).collection_name,
    );
    expect(loadCalls).toContain("autorfp_chunks_images");

    // The image collection's vector field must be 512-d (CLIP) and have
    // a HNSW + COSINE index registered.
    const imageCreate = mockClient.createCollection.mock.calls.find(
      (c) => (c[0] as { collection_name: string }).collection_name === "autorfp_chunks_images",
    )?.[0] as {
      fields: Array<{ name: string; dim?: number; is_partition_key?: boolean; data_type?: number }>;
    };
    expect(imageCreate).toBeDefined();
    const vecField = imageCreate.fields.find((f) => f.name === "vector");
    expect(vecField?.dim).toBe(512);
    const orgField = imageCreate.fields.find((f) => f.name === "organizationId");
    expect(orgField?.is_partition_key).toBe(true);

    expect(mockClient.createIndex).toHaveBeenCalledWith(
      expect.objectContaining({
        collection_name: "autorfp_chunks_images",
        field_name: "vector",
        index_type: "HNSW",
        metric_type: "COSINE",
      }),
    );
  });

  it("uses <base>_<safeOrgId>_images in collection-isolation mode", async () => {
    const store = newStore({ isolation: "collection" });
    await store.initOrg("org-with-dashes");
    const createCalls = mockClient.createCollection.mock.calls.map(
      (c) => (c[0] as { collection_name: string }).collection_name,
    );
    expect(createCalls).toContain("autorfp_chunks_org_with_dashes_images");
  });

  it("logs+continues if image collection init throws (text search still works)", async () => {
    // First hasCollection (chunks) → false; then createCollection chunks → ok;
    // second hasCollection (images) → throws.
    mockClient.hasCollection
      .mockResolvedValueOnce({ value: false })
      .mockRejectedValueOnce(new Error("image schema not supported"));
    const store = newStore();
    await expect(store.initOrg(ORG_ID)).resolves.toBeUndefined();
    // The chunks collection still loaded.
    expect(mockClient.loadCollection).toHaveBeenCalledWith({ collection_name: "autorfp_chunks" });
  });
});

describe("MilvusVectorStore.upsertImages", () => {
  it("inserts into the images collection with image-shaped rows", async () => {
    const store = newStore();
    const images: ImageVec[] = [
      {
        id: "img-1",
        vector: new Array(512).fill(0).map(() => Math.random()),
        metadata: {
          organizationId: ORG_ID,
          indexId: INDEX_ID,
          documentId: "doc-1",
          chunkId: "chunk-1",
          imagePath: "uploads/images/abc.png",
          mimeType: "image/png",
          page: 3,
          caption: "Architecture diagram",
          ocrText: "client → gateway → service",
        },
      },
    ];
    await store.upsertImages(images);
    expect(mockClient.insert).toHaveBeenCalledTimes(1);
    const arg = mockClient.insert.mock.calls[0][0] as {
      collection_name: string;
      data: Array<Record<string, unknown>>;
    };
    expect(arg.collection_name).toBe("autorfp_chunks_images");
    expect(arg.data[0]).toMatchObject({
      id: "img-1",
      organizationId: ORG_ID,
      indexId: INDEX_ID,
      documentId: "doc-1",
      chunkId: "chunk-1",
      page: 3,
      imagePath: "uploads/images/abc.png",
      caption: "Architecture diagram",
      ocrText: "client → gateway → service",
    });
    // Vector survived intact.
    expect((arg.data[0] as { vector: number[] }).vector).toHaveLength(512);
  });

  it("is a no-op on empty input", async () => {
    const store = newStore();
    await store.upsertImages([]);
    expect(mockClient.insert).not.toHaveBeenCalled();
  });
});

describe("MilvusVectorStore.searchImages", () => {
  it("ANN-searches the images collection with org+index filter", async () => {
    mockClient.search.mockResolvedValueOnce({
      results: [
        {
          id: "img-1",
          score: 0.92,
          imagePath: "uploads/images/abc.png",
          caption: "diagram",
          ocrText: "",
          page: 3,
          documentId: "doc-1",
          chunkId: "chunk-1",
        },
      ],
    });
    const store = newStore();
    const hits = await store.searchImages(ORG_ID, INDEX_ID, [0.1, 0.2, 0.3], { topK: 4 });

    expect(mockClient.search).toHaveBeenCalledTimes(1);
    const arg = mockClient.search.mock.calls[0][0] as {
      collection_name: string;
      anns_field: string;
      filter: string;
      limit: number;
    };
    expect(arg.collection_name).toBe("autorfp_chunks_images");
    expect(arg.anns_field).toBe("vector");
    expect(arg.limit).toBe(4);
    expect(arg.filter).toContain(`organizationId == "${ORG_ID}"`);
    expect(arg.filter).toContain(`indexId == "${INDEX_ID}"`);
    expect(hits).toHaveLength(1);
    expect(hits[0]).toMatchObject({
      id: "img-1",
      score: 0.92,
      imagePath: "uploads/images/abc.png",
      caption: "diagram",
      page: 3,
      documentId: "doc-1",
      chunkId: "chunk-1",
    });
  });

  it("includes documentIds in the filter expression", () => {
    const expr = buildImageFilterExpression(ORG_ID, INDEX_ID, {
      topK: 5,
      filter: { documentIds: ["d1", "d2"] },
    });
    expect(expr).toContain(`organizationId == "${ORG_ID}"`);
    expect(expr).toContain(`indexId == "${INDEX_ID}"`);
    expect(expr).toContain('documentId in ["d1","d2"]');
  });

  it("drops hits below opts.minScore", async () => {
    mockClient.search.mockResolvedValueOnce({
      results: [
        { id: "good", score: 0.9, imagePath: "g.png", caption: "", ocrText: "", page: 1, documentId: "d", chunkId: "" },
        { id: "bad", score: 0.1, imagePath: "b.png", caption: "", ocrText: "", page: 1, documentId: "d", chunkId: "" },
      ],
    });
    const store = newStore();
    const hits = await store.searchImages(ORG_ID, INDEX_ID, [0], { topK: 5, minScore: 0.5 });
    expect(hits.map((h) => h.id)).toEqual(["good"]);
  });
});

describe("MilvusVectorStore image delete methods", () => {
  it("deleteImages targets the images collection by id list, scoped to org", async () => {
    const store = newStore();
    await store.deleteImages(ORG_ID, ["img-1", "img-2"]);
    expect(mockClient.deleteEntities).toHaveBeenCalledTimes(1);
    const arg = mockClient.deleteEntities.mock.calls[0][0] as {
      collection_name: string;
      expr: string;
    };
    expect(arg.collection_name).toBe("autorfp_chunks_images");
    expect(arg.expr).toContain(`organizationId == "${ORG_ID}"`);
    expect(arg.expr).toContain('id in ["img-1","img-2"]');
  });

  it("deleteImages no-ops on empty input", async () => {
    const store = newStore();
    await store.deleteImages(ORG_ID, []);
    expect(mockClient.deleteEntities).not.toHaveBeenCalled();
  });

  it("deleteImagesForIndex targets the images collection by org+index expression", async () => {
    const store = newStore();
    await store.deleteImagesForIndex(ORG_ID, INDEX_ID);
    const arg = mockClient.deleteEntities.mock.calls[0][0] as {
      collection_name: string;
      expr: string;
    };
    expect(arg.collection_name).toBe("autorfp_chunks_images");
    expect(arg.expr).toBe(`organizationId == "${ORG_ID}" && indexId == "${INDEX_ID}"`);
  });
});

describe("Image tenant isolation invariant", () => {
  it("every image-search / image-delete expression includes organizationId equality", async () => {
    const store = newStore();

    await store.searchImages(ORG_ID, INDEX_ID, [0], { topK: 1 });
    expect(
      (mockClient.search.mock.calls[0][0] as { filter: string }).filter,
    ).toContain(`organizationId == "${ORG_ID}"`);

    await store.deleteImages(ORG_ID, ["img-1"]);
    expect(
      (mockClient.deleteEntities.mock.calls[0][0] as { expr: string }).expr,
    ).toContain(`organizationId == "${ORG_ID}"`);

    await store.deleteImagesForIndex(ORG_ID, INDEX_ID);
    expect(
      (mockClient.deleteEntities.mock.calls[1][0] as { expr: string }).expr,
    ).toContain(`organizationId == "${ORG_ID}"`);
  });
});

describe("Tenant isolation invariant", () => {
  it("every search filter expression includes organizationId equality", async () => {
    const store = newStore();
    // dense
    await store.search(ORG_ID, INDEX_ID, [0], { topK: 1 });
    expect(
      (mockClient.search.mock.calls[0][0] as { filter: string }).filter,
    ).toContain(`organizationId == "${ORG_ID}"`);

    // hybrid
    await store.search(ORG_ID, INDEX_ID, [0], {
      topK: 1,
      hybrid: true,
      sparseQuery: { indices: [1], values: [1] },
    });
    expect(
      (mockClient.hybridSearch.mock.calls[0][0] as { filter: string }).filter,
    ).toContain(`organizationId == "${ORG_ID}"`);

    // delete
    await store.delete(ORG_ID, ["c1"]);
    expect(
      (mockClient.deleteEntities.mock.calls[0][0] as { expr: string }).expr,
    ).toContain(`organizationId == "${ORG_ID}"`);

    // deleteIndex
    await store.deleteIndex(ORG_ID, INDEX_ID);
    expect(
      (mockClient.deleteEntities.mock.calls[1][0] as { expr: string }).expr,
    ).toContain(`organizationId == "${ORG_ID}"`);
  });
});
