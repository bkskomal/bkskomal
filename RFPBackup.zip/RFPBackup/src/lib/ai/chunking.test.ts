import { describe, expect, it } from "vitest";
import { chunkText } from "./chunking";

describe("chunkText", () => {
  it("returns empty array for empty input", () => {
    expect(chunkText("")).toEqual([]);
  });

  it("returns a single chunk when text fits in one window", () => {
    const text = "Hello world. This is short.";
    expect(chunkText(text)).toEqual([text]);
  });

  it("respects size limit and applies overlap", () => {
    const text = "A".repeat(3000);
    const chunks = chunkText(text, 1000, 100);
    expect(chunks.length).toBeGreaterThan(2);
    for (const c of chunks) {
      expect(c.length).toBeLessThanOrEqual(1000);
    }
  });

  it("prefers paragraph boundaries when splitting", () => {
    const para = "Sentence one. Sentence two.";
    const text = (para + "\n\n").repeat(50);
    const chunks = chunkText(text, 200, 30);
    // Each chunk should end at a paragraph boundary, not mid-sentence.
    for (const c of chunks.slice(0, -1)) {
      expect(c.endsWith(".") || c.endsWith("\n\n") || c.endsWith(para)).toBe(true);
    }
  });
});
