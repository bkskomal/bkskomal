// Multi-stage RFP question extractor.
//
// Pipeline per RFP:
//   1. Section-aware batching: split the raw text on top-level section
//      headings, then fall back to paragraph batching, capping each batch at
//      ~12k chars. This keeps related questions together in one LLM call so
//      section context is preserved.
//   2. Run STAGE_1 (extraction) and STAGE_2 (eligibility) per batch, with
//      bounded parallelism (3 batches in flight). Stage 2 is best-effort —
//      if it fails for any reason, every question in the batch falls back to
//      default eligibility ("answerable", 0.5). Stage-2 failure must NOT fail
//      the whole extraction.
//   3. Merge batch results and renumber globally 1..N. Original LLM numbering
//      is preserved on `originalNumber`.

import { getAiClients, type AiClients } from "./client";
import {
  QUESTION_ELIGIBILITY_SYSTEM,
  QUESTION_EXTRACTION_V2_SYSTEM,
} from "./prompts";
import { log } from "@/lib/logger";
import { stripCodeFences } from "./json-utils";

// --- Public types -----------------------------------------------------------

export type RequirementType = "must" | "should" | "may" | "info";
export type Complexity = "simple" | "moderate" | "complex";
export type Eligibility = "answerable" | "needs_info" | "out_of_scope";

export interface ExtractedQuestion {
  number: number;
  section?: string;
  text: string;
  required: boolean;
  requirementType: RequirementType;
  complexity: Complexity;
  topic?: string;
  whatIsAsked?: string;
  eligibility: Eligibility;
  eligibilityConfidence: number;
  /** The LLM's number for this question before global renumbering. */
  originalNumber?: number;
}

// --- Constants --------------------------------------------------------------

/**
 * Default batch char cap when the resolver returns no per-org override (kept
 * exported for tests + legacy callers). Phase A.2: the real value comes from
 * `clients.config.extraction.batchSizeBytes` at request time.
 */
export const MAX_CHARS_PER_BATCH = 12_000;
/**
 * Default concurrent batches when no per-org override exists. Phase A.2: the
 * real value comes from `clients.config.extraction.concurrency`.
 */
export const MAX_CONCURRENT_BATCHES = 3;

const DEFAULT_REQUIREMENT: RequirementType = "must";
const DEFAULT_COMPLEXITY: Complexity = "moderate";
const DEFAULT_ELIGIBILITY: Eligibility = "answerable";
const DEFAULT_ELIGIBILITY_CONFIDENCE = 0.5;

const REQUIREMENT_VALUES: ReadonlySet<RequirementType> = new Set([
  "must",
  "should",
  "may",
  "info",
]);
const COMPLEXITY_VALUES: ReadonlySet<Complexity> = new Set([
  "simple",
  "moderate",
  "complex",
]);
const ELIGIBILITY_VALUES: ReadonlySet<Eligibility> = new Set([
  "answerable",
  "needs_info",
  "out_of_scope",
]);

// --- Public entry point -----------------------------------------------------

export interface ExtractQuestionsOptions {
  /** Sink for live progress text — surfaced inside the EXTRACT_QUESTIONS
   *  pipeline step card while the batches stream through the LLM. */
  onProgress?: (text: string) => void | Promise<void>;
}

export async function extractQuestions(
  rawText: string,
  orgId: string | null | undefined,
  opts: ExtractQuestionsOptions = {},
): Promise<ExtractedQuestion[]> {
  const onProgress = opts.onProgress ?? (() => {});
  const text = (rawText ?? "").trim();
  if (!text) {
    log().warn(
      { orgId, rawTextLen: rawText?.length ?? 0 },
      "extractQuestions: rawText is empty — parser likely produced no text",
    );
    return [];
  }

  // Resolve config FIRST so batching honors the org's batch-size override.
  const clients = await getAiClients(orgId);
  const extCfg = clients.config.extraction;
  const batches = splitForExtraction(text, extCfg.batchSizeBytes);

  log().info(
    {
      orgId,
      textLen: text.length,
      batchCount: batches.length,
      model: clients.config.llm.extractionModel,
      provider: clients.config.llm.provider,
      batchSizeBytes: extCfg.batchSizeBytes,
      concurrency: extCfg.concurrency,
      eligibilityEnabled: extCfg.eligibilityEnabled,
      promptOverridden: extCfg.promptOverride !== null,
    },
    "extractQuestions: starting",
  );

  // Bounded parallel pool — at most MAX_CONCURRENT_BATCHES in flight.
  const results: ExtractedQuestion[][] = new Array(batches.length);
  let nextIndex = 0;
  const perBatchCounts: number[] = new Array(batches.length).fill(0);

  let completedBatches = 0;
  let runningTotal = 0;
  // Initial tick so the UI shows something the instant we start.
  void onProgress(`Extracting questions — 0/${batches.length} batches`);

  async function worker(): Promise<void> {
    while (true) {
      const i = nextIndex++;
      if (i >= batches.length) return;
      try {
        results[i] = await processBatch(batches[i]!, clients);
        perBatchCounts[i] = results[i].length;
        completedBatches += 1;
        runningTotal += results[i].length;
        // Best-effort tick. Failures inside onProgress (e.g. DB hiccup)
        // must NEVER break extraction — the callback already swallows.
        void onProgress(
          `Extracting questions — ${completedBatches}/${batches.length} batches, ${runningTotal} found`,
        );
      } catch (err) {
        results[i] = [];
        const errMsg = err instanceof Error ? err.message : String(err);
        // Bubble the LLM error up to the step card so the user doesn't see
        // a silent "0 questions" when the real problem is a 401 / bad model /
        // rate limit. The handler writes progressDetail into the step row.
        void onProgress(
          `Batch ${i + 1}/${batches.length} failed — ${errMsg.slice(0, 120)}`,
        );
        log().error(
          {
            orgId,
            batchIndex: i,
            batchLen: batches[i]?.length ?? 0,
            err: err instanceof Error ? { name: err.name, message: err.message, cause: (err as Error & { cause?: unknown }).cause } : String(err),
          },
          "extractQuestions: batch failed (returning empty)",
        );
      }
    }
  }

  const workerCount = Math.min(extCfg.concurrency, batches.length);
  await Promise.all(
    Array.from({ length: workerCount }, () => worker()),
  );

  const merged: ExtractedQuestion[] = [];
  for (const r of results) merged.push(...r);
  log().info(
    {
      orgId,
      totalQuestions: merged.length,
      perBatchCounts,
      emptyBatches: perBatchCounts.filter((n) => n === 0).length,
    },
    `extractQuestions: done (${merged.length} questions from ${batches.length} batches)`,
  );
  return renumberQuestions(merged);
}

// --- Section-aware batching -------------------------------------------------

/**
 * Split RFP text into batches suitable for one LLM call each.
 *
 * Strategy (in priority order):
 *   1. Split on `^##? Section ` headings (most RFPs label sections this way).
 *   2. Otherwise split on `\n\n## ` markdown-style headings.
 *   3. Otherwise fall back to paragraph batching.
 *
 * `maxChars` (Phase A.2) defaults to MAX_CHARS_PER_BATCH so older callers and
 * unit tests keep working unchanged. The real extraction path threads in the
 * per-org override from `clients.config.extraction.batchSizeBytes`.
 */
export function splitForExtraction(text: string, maxChars: number = MAX_CHARS_PER_BATCH): string[] {
  const cleaned = (text ?? "").trim();
  if (!cleaned) return [];
  if (cleaned.length <= maxChars) return [cleaned];

  const sectionChunks = splitOnSections(cleaned);
  // Pack section chunks into batches up to the size cap. Each section is kept
  // whole if it fits; oversized sections are paragraph-batched.
  return packIntoBatches(sectionChunks, maxChars);
}

function splitOnSections(text: string): string[] {
  // Pattern 1: lines like "## Section 3.1" or "# Section A".
  const headingRe = /^##?\s+Section\b.*$/gm;
  let parts = splitKeepingDelimiters(text, headingRe);
  if (parts.length > 1) return parts;

  // Pattern 2: any markdown H2 boundary.
  const h2Re = /\n\n## .+$/gm;
  parts = splitKeepingDelimiters(text, h2Re);
  if (parts.length > 1) return parts;

  // No section structure — return the whole text as one section chunk.
  return [text];
}

/**
 * Split `text` on the regex but keep each match as the start of the
 * following chunk (so the heading travels with its section body).
 */
function splitKeepingDelimiters(text: string, re: RegExp): string[] {
  const indices: number[] = [];
  for (const m of text.matchAll(re)) {
    if (typeof m.index === "number") indices.push(m.index);
  }
  if (indices.length === 0) return [text];

  const chunks: string[] = [];
  // Preserve any preamble before the first heading.
  if (indices[0]! > 0) {
    const head = text.slice(0, indices[0]!).trim();
    if (head) chunks.push(head);
  }
  for (let i = 0; i < indices.length; i++) {
    const start = indices[i]!;
    const end = i + 1 < indices.length ? indices[i + 1]! : text.length;
    const piece = text.slice(start, end).trim();
    if (piece) chunks.push(piece);
  }
  return chunks;
}

function packIntoBatches(sections: string[], maxChars: number = MAX_CHARS_PER_BATCH): string[] {
  const batches: string[] = [];
  let current = "";

  const flush = () => {
    if (current.trim()) batches.push(current.trim());
    current = "";
  };

  for (const section of sections) {
    if (section.length > maxChars) {
      // Oversized atomic section — flush current, then paragraph-batch it.
      flush();
      for (const sub of paragraphBatch(section, maxChars)) batches.push(sub);
      continue;
    }
    if (current && current.length + section.length + 2 > maxChars) {
      flush();
    }
    current = current ? current + "\n\n" + section : section;
  }
  flush();
  return batches;
}

function paragraphBatch(text: string, maxChars: number = MAX_CHARS_PER_BATCH): string[] {
  const out: string[] = [];
  const paras = text.split(/\n\n+/);
  let cur = "";
  for (const p of paras) {
    if (cur && (cur.length + p.length + 2) > maxChars) {
      out.push(cur);
      cur = p;
    } else {
      cur = cur ? cur + "\n\n" + p : p;
    }
  }
  if (cur) out.push(cur);
  return out;
}

// --- Per-batch pipeline -----------------------------------------------------

async function processBatch(
  batch: string,
  clients: AiClients,
): Promise<ExtractedQuestion[]> {
  const stage1 = await runStage1(batch, clients);
  if (stage1.length === 0) return [];

  // Phase A.2: stage-2 eligibility is opt-in via per-org config. When disabled,
  // every question falls back to ("answerable", 0.5) — same shape, half the cost.
  const eligibilityByNumber = clients.config.extraction.eligibilityEnabled
    ? await runStage2(stage1, clients)
    : new Map<number, { eligibility: Eligibility; confidence: number }>();

  return stage1.map((q) => {
    const elig = eligibilityByNumber.get(q.number);
    return {
      number: q.number,
      section: q.section,
      text: q.text,
      required: q.requirementType === "must" || q.requirementType === "should",
      requirementType: q.requirementType,
      complexity: q.complexity,
      topic: q.topic,
      whatIsAsked: q.whatIsAsked,
      eligibility: elig?.eligibility ?? DEFAULT_ELIGIBILITY,
      eligibilityConfidence:
        elig?.confidence ?? DEFAULT_ELIGIBILITY_CONFIDENCE,
      originalNumber: q.number,
    };
  });
}

// Internal shape for stage-1 parsed rows (post-normalization). Exported for
// unit testing the merge/eligibility-fallback path.
export interface Stage1Row {
  number: number;
  section?: string;
  text: string;
  requirementType: RequirementType;
  complexity: Complexity;
  topic?: string;
  whatIsAsked?: string;
}

async function runStage1(
  batch: string,
  clients: AiClients,
): Promise<Stage1Row[]> {
  // Phase A.2: honor the per-org system prompt override when set.
  const systemPrompt = clients.config.extraction.promptOverride ?? QUESTION_EXTRACTION_V2_SYSTEM;
  const completion = await clients.llm.chat.completions.create({
    // Extraction model resolves to: org's pinned extractionModel → env →
    // llmModel. See resolveAiConfig.
    model: clients.config.llm.extractionModel,
    temperature: 0,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: batch },
    ],
  });
  const raw = completion.choices[0]?.message?.content ?? "{}";
  const parsed = parseStage1Json(raw);
  // When the LLM returns 0 questions, dump enough context to diagnose:
  //   - what the model actually said (raw response)
  //   - what we sent it (first 300 chars of the batch)
  //   - finish reason (length / stop / content_filter / refusal)
  // This is the difference between "model said no questions" vs. "model
  // returned malformed JSON our parser dropped".
  if (parsed.length === 0) {
    const finish = completion.choices[0]?.finish_reason ?? "unknown";
    log().warn(
      {
        batchLen: batch.length,
        batchPreview: batch.slice(0, 300),
        rawResponse: raw.slice(0, 600),
        finishReason: finish,
        model: clients.config.llm.extractionModel,
      },
      "extractQuestions/stage1: 0 questions returned — inspect rawResponse",
    );
  }
  return parsed;
}

export function parseStage1Json(raw: string): Stage1Row[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(stripCodeFences(raw));
  } catch {
    return [];
  }
  if (!parsed || typeof parsed !== "object") return [];
  const arr = (parsed as { questions?: unknown }).questions;
  if (!Array.isArray(arr)) return [];

  const out: Stage1Row[] = [];
  for (let i = 0; i < arr.length; i++) {
    const item = arr[i];
    if (!item || typeof item !== "object") continue;
    const rec = item as Record<string, unknown>;
    const text = typeof rec.text === "string" ? rec.text.trim() : "";
    if (!text) continue;

    const number = coerceInt(rec.number, i + 1);
    const section = typeof rec.section === "string" && rec.section.trim()
      ? rec.section.trim()
      : undefined;
    const requirementType = normalizeRequirement(rec.requirement_type, rec.required);
    const complexity = normalizeComplexity(rec.complexity);
    const topic = typeof rec.topic === "string" && rec.topic.trim()
      ? rec.topic.trim()
      : undefined;
    const whatIsAsked =
      typeof rec.what_is_asked === "string" && rec.what_is_asked.trim()
        ? rec.what_is_asked.trim()
        : undefined;

    out.push({
      number,
      section,
      text,
      requirementType,
      complexity,
      topic,
      whatIsAsked,
    });
  }
  return out;
}

// Stage 2: best-effort eligibility classification. Returns a map keyed by
// the stage-1 question number. Any failure (network, bad JSON, missing
// fields) is swallowed and callers fall back to defaults.
async function runStage2(
  stage1: Stage1Row[],
  clients: AiClients,
): Promise<Map<number, { eligibility: Eligibility; confidence: number }>> {
  try {
    const payload = JSON.stringify(
      stage1.map((q) => ({ number: q.number, text: q.text })),
    );
    const completion = await clients.llm.chat.completions.create({
      // Eligibility classification is also structured-output — same fast model.
      model: clients.config.llm.extractionModel,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: QUESTION_ELIGIBILITY_SYSTEM },
        { role: "user", content: payload },
      ],
    });
    const raw = completion.choices[0]?.message?.content ?? "{}";
    return parseStage2Json(raw);
  } catch {
    return new Map();
  }
}

export function parseStage2Json(
  raw: string,
): Map<number, { eligibility: Eligibility; confidence: number }> {
  const out = new Map<number, { eligibility: Eligibility; confidence: number }>();
  let parsed: unknown;
  try {
    parsed = JSON.parse(stripCodeFences(raw));
  } catch {
    return out;
  }
  if (!parsed || typeof parsed !== "object") return out;
  const items = (parsed as { items?: unknown }).items;
  if (!Array.isArray(items)) return out;

  for (const item of items) {
    if (!item || typeof item !== "object") continue;
    const rec = item as Record<string, unknown>;
    const num = coerceInt(rec.number, NaN);
    if (!Number.isFinite(num)) continue;
    const elig = normalizeEligibility(rec.eligibility);
    const confidence = clampConfidence(rec.confidence);
    out.set(num, { eligibility: elig, confidence });
  }
  return out;
}

// --- Renumbering & normalization helpers ------------------------------------

/**
 * Rewrite `number` to a global 1..N sequence while preserving order. The
 * LLM's original number is stashed on `originalNumber` for traceability.
 */
export function renumberQuestions(qs: ExtractedQuestion[]): ExtractedQuestion[] {
  return qs.map((q, i) => ({
    ...q,
    number: i + 1,
    originalNumber: q.originalNumber ?? q.number,
  }));
}

/**
 * Merge stage-1 rows with stage-2 results into the public shape. Exposed for
 * unit testing the eligibility-fallback path without an LLM.
 */
export function mergeStages(
  stage1: Stage1Row[],
  stage2: Map<number, { eligibility: Eligibility; confidence: number }>,
): ExtractedQuestion[] {
  return stage1.map((q) => {
    const elig = stage2.get(q.number);
    return {
      number: q.number,
      section: q.section,
      text: q.text,
      required: q.requirementType === "must" || q.requirementType === "should",
      requirementType: q.requirementType,
      complexity: q.complexity,
      topic: q.topic,
      whatIsAsked: q.whatIsAsked,
      eligibility: elig?.eligibility ?? DEFAULT_ELIGIBILITY,
      eligibilityConfidence:
        elig?.confidence ?? DEFAULT_ELIGIBILITY_CONFIDENCE,
      originalNumber: q.number,
    };
  });
}

function normalizeRequirement(
  rt: unknown,
  required: unknown,
): RequirementType {
  if (typeof rt === "string") {
    const v = rt.trim().toLowerCase() as RequirementType;
    if (REQUIREMENT_VALUES.has(v)) return v;
  }
  // Legacy fallback — old prompt only returned a boolean `required`.
  if (typeof required === "boolean") return required ? "must" : "may";
  return DEFAULT_REQUIREMENT;
}

function normalizeComplexity(c: unknown): Complexity {
  if (typeof c === "string") {
    const v = c.trim().toLowerCase() as Complexity;
    if (COMPLEXITY_VALUES.has(v)) return v;
  }
  return DEFAULT_COMPLEXITY;
}

function normalizeEligibility(e: unknown): Eligibility {
  if (typeof e === "string") {
    const v = e.trim().toLowerCase() as Eligibility;
    if (ELIGIBILITY_VALUES.has(v)) return v;
  }
  return DEFAULT_ELIGIBILITY;
}

function clampConfidence(c: unknown): number {
  if (typeof c !== "number" || !Number.isFinite(c)) {
    return DEFAULT_ELIGIBILITY_CONFIDENCE;
  }
  if (c < 0) return 0;
  if (c > 1) return 1;
  return c;
}

function coerceInt(v: unknown, fallback: number): number {
  if (typeof v === "number" && Number.isFinite(v)) return Math.trunc(v);
  if (typeof v === "string") {
    // Accept dotted numbering like "2.1" by stripping dots.
    const cleaned = v.replace(/[^\d]/g, "");
    if (cleaned) {
      const n = parseInt(cleaned, 10);
      if (Number.isFinite(n)) return n;
    }
  }
  return fallback;
}
