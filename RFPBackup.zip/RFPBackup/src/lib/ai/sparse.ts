// Cheap BM25-style sparse encoder for native hybrid search (Milvus 2.4+).
//
// Tokenizes a text, hashes each surviving term to a deterministic 32-bit ID
// via FNV-1a, and emits a (term-id → weight) sparse vector where weight =
// term-frequency × IDF. The IDF table is computed lazily per-org from the
// chunk corpus and cached for SPARSE_IDF_TTL_MS (default 1h).
//
// Design notes:
//   - Zero external dependencies. FNV-1a is a tiny inline routine; the
//     stopword list is a small inline Set (matches the one in retrieval.ts).
//   - The hash is 32-bit unsigned so it fits in a Postgres `int` and Milvus's
//     sparse-index integer width. Collisions are statistically possible but
//     ignored — same-collision terms just get summed, which is fine for BM25.
//   - encodeSparseWithIdf is the pure function under test; encodeSparse is the
//     orgId-aware wrapper that loads/refreshes the IDF cache.
//   - First call per org may be slow (one prisma query + tokenization sweep);
//     subsequent calls are O(tokens). The cache key is just orgId.

import { prisma } from "@/lib/prisma";
import { log } from "@/lib/logger";

export interface SparseVector {
  indices: number[];
  values: number[];
}

const SPARSE_IDF_TTL_MS = Number(process.env.SPARSE_IDF_TTL_MS ?? 60 * 60 * 1000);
const SPARSE_IDF_SAMPLE = Number(process.env.SPARSE_IDF_SAMPLE ?? 5000);

// --- Tokenizer --------------------------------------------------------------

// Standard English stopwords — tiny inline set to avoid pulling a dep. Kept
// in sync with the retrieval.ts list so the dense+sparse stop-words match.
const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "but", "is", "are", "was", "were", "be", "been", "being",
  "of", "to", "in", "on", "at", "by", "for", "with", "as", "from", "that", "this", "it",
  "its", "we", "you", "they", "he", "she", "i", "what", "which", "who", "how", "why",
  "when", "where", "do", "does", "did", "have", "has", "had", "will", "would", "should",
  "can", "could", "may", "might", "shall", "must", "if", "then", "else", "not", "no",
]);

/**
 * Lowercase, strip non-word/non-dot characters, split on whitespace, drop
 * empties + stopwords + single chars. Keeps `.` so tokens like "soc 2" don't
 * fuse, and tokens like "v1.2" survive as one.
 */
export function tokenizeSparse(text: string): string[] {
  if (!text) return [];
  return text
    .toLowerCase()
    // Replace non-word chars (keeping `.`) with whitespace; collapse runs.
    .replace(/[^\p{L}\p{N}.\s]+/gu, " ")
    .split(/\s+/)
    .map((t) => t.replace(/^\.+|\.+$/g, "")) // strip leading/trailing dots
    .filter((t) => t.length > 1 && !STOPWORDS.has(t));
}

// --- Hashing (FNV-1a 32-bit) ------------------------------------------------

const FNV_OFFSET = 0x811c9dc5;
const FNV_PRIME = 0x01000193;

/**
 * Deterministic 32-bit unsigned hash. Same input → same output across
 * processes and platforms. Fast enough for hot-path use.
 */
export function hashTerm(term: string): number {
  let h = FNV_OFFSET;
  for (let i = 0; i < term.length; i++) {
    h ^= term.charCodeAt(i);
    // FNV multiplication, force back to 32-bit unsigned via Math.imul + >>> 0.
    h = Math.imul(h, FNV_PRIME) >>> 0;
  }
  return h;
}

// --- IDF cache --------------------------------------------------------------

interface IdfEntry {
  /** Map of term-id → IDF score. */
  idf: Map<number, number>;
  expiresAt: number;
}

const idfCache = new Map<string, IdfEntry>();
const inflight = new Map<string, Promise<Map<number, number>>>();

/** @internal — for tests. */
export function _resetSparseCacheForTests(): void {
  idfCache.clear();
  inflight.clear();
}

/**
 * Build (or refresh) the per-org IDF table by sampling chunk content.
 * Each surviving term contributes log(1 + (N - n + 0.5) / (n + 0.5)).
 */
async function buildIdfForOrg(orgId: string): Promise<Map<number, number>> {
  const chunks = await prisma.documentChunk.findMany({
    where: { document: { index: { organizationId: orgId } } },
    select: { content: true },
    take: SPARSE_IDF_SAMPLE,
  });

  const N = chunks.length;
  if (N === 0) return new Map();

  // Document-frequency: how many chunks contain term t at least once.
  const df = new Map<number, number>();
  for (const c of chunks) {
    const seen = new Set<number>();
    for (const tok of tokenizeSparse(c.content)) {
      const id = hashTerm(tok);
      if (seen.has(id)) continue;
      seen.add(id);
      df.set(id, (df.get(id) ?? 0) + 1);
    }
  }

  const idf = new Map<number, number>();
  for (const [id, n] of df) {
    idf.set(id, Math.log(1 + (N - n + 0.5) / (n + 0.5)));
  }
  return idf;
}

async function loadIdf(orgId: string): Promise<Map<number, number>> {
  const now = Date.now();
  const cached = idfCache.get(orgId);
  if (cached && cached.expiresAt > now) return cached.idf;

  // Coalesce concurrent first-call requests so we don't issue N parallel
  // prisma queries for the same org under load.
  const pending = inflight.get(orgId);
  if (pending) return pending;

  const promise = (async () => {
    try {
      const idf = await buildIdfForOrg(orgId);
      idfCache.set(orgId, { idf, expiresAt: Date.now() + SPARSE_IDF_TTL_MS });
      return idf;
    } catch (err) {
      log().warn(
        {
          err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
          orgId,
        },
        "sparse IDF build failed; falling back to empty table",
      );
      return new Map<number, number>();
    } finally {
      inflight.delete(orgId);
    }
  })();
  inflight.set(orgId, promise);
  return promise;
}

/** Force-refresh the org's IDF table. Useful after a large bulk ingest. */
export async function refreshIdfCache(orgId: string): Promise<void> {
  idfCache.delete(orgId);
  inflight.delete(orgId);
  await loadIdf(orgId);
}

// --- Public encode ---------------------------------------------------------

/**
 * Pure encoder used by tests + offline tooling. Same tokenizer + hasher as
 * encodeSparse, but the IDF table is supplied by the caller. When the IDF
 * table is empty (cold cache), we fall back to a constant IDF of 1.0 so the
 * encoder still produces a usable TF vector.
 */
export function encodeSparseWithIdf(
  text: string,
  idf: Map<number, number>,
): SparseVector {
  const tokens = tokenizeSparse(text);
  if (tokens.length === 0) return { indices: [], values: [] };

  // Term frequency (raw count) per term-id.
  const tf = new Map<number, number>();
  for (const tok of tokens) {
    const id = hashTerm(tok);
    tf.set(id, (tf.get(id) ?? 0) + 1);
  }

  const fallbackIdf = idf.size === 0;
  // Stable order — sort by id for deterministic output. Milvus doesn't care
  // about ordering, but tests + on-the-wire diffing benefit from it.
  const ids = Array.from(tf.keys()).sort((a, b) => a - b);
  const indices: number[] = new Array(ids.length);
  const values: number[] = new Array(ids.length);
  for (let i = 0; i < ids.length; i++) {
    const id = ids[i];
    const w = fallbackIdf ? 1 : idf.get(id) ?? 0;
    indices[i] = id;
    values[i] = (tf.get(id) ?? 0) * w;
  }
  return { indices, values };
}

/**
 * Encode a text into a (term-id → weight) sparse vector for the org's
 * cached IDF table. Loads the table on first use; returns instantly on
 * subsequent calls until SPARSE_IDF_TTL_MS expires.
 */
export async function encodeSparse(
  text: string,
  orgId: string,
): Promise<SparseVector> {
  const idf = await loadIdf(orgId);
  return encodeSparseWithIdf(text, idf);
}
