// Slack integration client.
//
// One row per org in SlackIntegration. Two send modes:
//   * Bot token (preferred) — Slack Web API chat.postMessage with bearer auth.
//     Supports rich BlockKit, channel resolution, and a real ts/permalink.
//   * Incoming webhook (fallback) — plain POST to the org's webhook URL. No
//     ts/permalink, no channel override, but works for orgs that haven't
//     installed a bot.
//
// All sends pass through a single circuit breaker so a Slack outage doesn't
// snowball into queues of stuck retries. We never throw at the call site —
// dispatchers fire-and-forget and a failed send is a logged warn + a metric
// increment, nothing more.
//
// Per-event filtering:
//   The 4 supported event kinds (rfp_uploaded, response_generated, mention,
//   outcome_set) each have an entry in `eventPreferences`. Default is "send
//   it"; an explicit `false` no-ops. This lets admins mute one kind without
//   removing the integration entirely.

import { prisma } from "@/lib/prisma";
import { decrypt } from "@/lib/crypto";
import { log } from "@/lib/logger";
import { createBreaker, CircuitOpenError } from "@/lib/circuit-breaker";
import { slackMessagesSentTotal } from "@/lib/metrics";

export type SlackEventKind =
  | "rfp_uploaded"
  | "response_generated"
  | "mention"
  | "outcome_set";

export interface SlackMessage {
  text: string;
  blocks?: unknown[];
  /** Channel override. Falls back to the integration's defaultChannelId. */
  channel?: string;
  /** Which event preference gates this send. Omit to bypass the filter. */
  eventKind?: SlackEventKind;
}

export interface SlackSendResult {
  ok: boolean;
  ts?: string;
  error?: string;
  /** True when the send was suppressed (no integration / disabled / filtered). */
  skipped?: boolean;
}

export interface SlackChannel {
  id: string;
  name: string;
  isPrivate: boolean;
}

// Single breaker for Slack as a whole — chat.postMessage and the helper
// endpoints share the same backend, so one tripped breaker should suppress
// all of them. Threshold tuned for fire-and-forget: we want a stalled Slack
// to fail fast within a few seconds rather than burying request handlers.
const slackBreaker = createBreaker({
  name: "slack",
  failureThreshold: 5,
  resetTimeoutMs: 30_000,
});

const SLACK_API_BASE = "https://slack.com/api";

interface ResolvedIntegration {
  organizationId: string;
  botToken: string | null;
  webhookUrl: string | null;
  defaultChannelId: string | null;
  enabled: boolean;
  eventPreferences: Record<string, boolean>;
  teamId: string | null;
  teamName: string | null;
}

/**
 * Load and decrypt the SlackIntegration row for an org. Returns null when no
 * integration exists, the integration is disabled, or the bot token can't be
 * decrypted (legacy/rotated key). Callers should treat null as "no-op".
 */
async function loadIntegration(orgId: string): Promise<ResolvedIntegration | null> {
  const row = await prisma.slackIntegration.findUnique({
    where: { organizationId: orgId },
  });
  if (!row) return null;
  if (!row.enabled) return null;

  const botToken = row.botTokenEncrypted ? decrypt(row.botTokenEncrypted) : null;

  // eventPreferences is Json? on the schema. Normalize to a plain object so
  // downstream code can do `prefs[kind] !== false`.
  const prefs =
    row.eventPreferences && typeof row.eventPreferences === "object"
      ? (row.eventPreferences as Record<string, boolean>)
      : {};

  return {
    organizationId: row.organizationId,
    botToken,
    webhookUrl: row.webhookUrl,
    defaultChannelId: row.defaultChannelId,
    enabled: row.enabled,
    eventPreferences: prefs,
    teamId: row.teamId,
    teamName: row.teamName,
  };
}

/**
 * Send a message to the org's Slack workspace. Behaviour matrix:
 *   - no integration / disabled / event filtered → {ok:true, skipped:true}
 *   - bot token present → Slack Web API (best path; supports BlockKit + ts)
 *   - else webhook URL → plain webhook POST
 *   - else → {ok:true, skipped:true} (configured but no transport set)
 *
 * Errors return `{ok:false, error}` rather than throwing — the dispatchers
 * (slack-events.ts) fire-and-forget and a thrown error would leak through.
 */
export async function sendSlackMessage(
  orgId: string,
  msg: SlackMessage,
): Promise<SlackSendResult> {
  const eventLabel = msg.eventKind ?? "manual";
  try {
    const integ = await loadIntegration(orgId);
    if (!integ) {
      slackMessagesSentTotal.inc({ event: eventLabel, result: "skipped" });
      return { ok: true, skipped: true };
    }

    if (msg.eventKind && integ.eventPreferences[msg.eventKind] === false) {
      slackMessagesSentTotal.inc({ event: eventLabel, result: "skipped" });
      return { ok: true, skipped: true };
    }

    if (integ.botToken) {
      const channel = msg.channel ?? integ.defaultChannelId ?? undefined;
      if (!channel) {
        // Bot tokens require a channel ID. Without one we can't post.
        slackMessagesSentTotal.inc({ event: eventLabel, result: "skipped" });
        return { ok: true, skipped: true };
      }
      const result = await slackBreaker(() =>
        postViaApi(integ.botToken!, channel, msg.text, msg.blocks),
      );
      slackMessagesSentTotal.inc({
        event: eventLabel,
        result: result.ok ? "ok" : "error",
      });
      return result;
    }

    if (integ.webhookUrl) {
      const result = await slackBreaker(() =>
        postViaWebhook(integ.webhookUrl!, msg.text, msg.blocks),
      );
      slackMessagesSentTotal.inc({
        event: eventLabel,
        result: result.ok ? "ok" : "error",
      });
      return result;
    }

    // Integration row exists but neither transport configured.
    slackMessagesSentTotal.inc({ event: eventLabel, result: "skipped" });
    return { ok: true, skipped: true };
  } catch (err) {
    // CircuitOpenError or any other surprise — log + count as error.
    slackMessagesSentTotal.inc({ event: eventLabel, result: "error" });
    const error =
      err instanceof CircuitOpenError
        ? "Slack circuit open"
        : err instanceof Error
          ? err.message
          : String(err);
    log().warn({ err: errSummary(err), orgId, event: eventLabel }, "slack send failed");
    return { ok: false, error };
  }
}

/** POST to https://slack.com/api/chat.postMessage. */
async function postViaApi(
  token: string,
  channel: string,
  text: string,
  blocks: unknown[] | undefined,
): Promise<SlackSendResult> {
  const body = JSON.stringify({ channel, text, blocks });
  const res = await fetch(`${SLACK_API_BASE}/chat.postMessage`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json; charset=utf-8",
    },
    body,
  });
  // Slack always returns 200 even on auth/permission errors; the JSON body's
  // `ok` field is the real status.
  let json: { ok?: boolean; error?: string; ts?: string } = {};
  try {
    json = (await res.json()) as typeof json;
  } catch {
    // Empty body — treat as transport error.
  }
  if (json.ok) {
    return { ok: true, ts: json.ts };
  }
  return {
    ok: false,
    error: json.error ?? `HTTP ${res.status}`,
  };
}

/** POST to an incoming webhook URL. Webhooks return "ok" / "invalid_token" etc. */
async function postViaWebhook(
  url: string,
  text: string,
  blocks: unknown[] | undefined,
): Promise<SlackSendResult> {
  const payload: Record<string, unknown> = { text };
  if (blocks && blocks.length) payload.blocks = blocks;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (res.ok) return { ok: true };
  const errBody = await res.text().catch(() => "");
  return { ok: false, error: errBody || `HTTP ${res.status}` };
}

/**
 * Verify the integration can talk to Slack. Uses `auth.test` for bot tokens
 * (cheap, identifies the workspace) and a no-op text send for webhooks (the
 * webhook URL alone can't be introspected — sending is the only signal).
 */
export async function testSlackConnection(
  orgId: string,
): Promise<{ ok: boolean; team?: string; error?: string }> {
  try {
    const integ = await loadIntegration(orgId);
    if (!integ) return { ok: false, error: "No integration configured" };

    if (integ.botToken) {
      const res = await slackBreaker(() =>
        fetch(`${SLACK_API_BASE}/auth.test`, {
          method: "POST",
          headers: { Authorization: `Bearer ${integ.botToken}` },
        }).then(async (r) => {
          let body: { ok?: boolean; team?: string; error?: string } = {};
          try {
            body = (await r.json()) as typeof body;
          } catch {
            // ignore
          }
          return body;
        }),
      );
      if (res.ok) return { ok: true, team: res.team };
      return { ok: false, error: res.error ?? "Slack rejected the token" };
    }

    if (integ.webhookUrl) {
      // Webhooks have no introspection endpoint. The closest we can do is
      // confirm the URL is well-formed; an actual send is gated by the
      // /test route so admins know they're paying the message cost.
      try {
        const u = new URL(integ.webhookUrl);
        if (u.protocol !== "https:") return { ok: false, error: "Webhook must be https" };
        return { ok: true };
      } catch {
        return { ok: false, error: "Invalid webhook URL" };
      }
    }

    return { ok: false, error: "Neither bot token nor webhook configured" };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

/**
 * List channels available to the bot. Uses conversations.list. Returns an
 * empty array when no bot token is configured (webhooks can't enumerate).
 */
export async function listSlackChannels(orgId: string): Promise<SlackChannel[]> {
  const integ = await loadIntegration(orgId);
  if (!integ?.botToken) return [];
  try {
    const channels = await slackBreaker(async () => {
      const out: SlackChannel[] = [];
      // Paginate up to a reasonable cap. Most orgs have far fewer than 1000.
      let cursor: string | undefined;
      for (let i = 0; i < 5; i++) {
        const url = new URL(`${SLACK_API_BASE}/conversations.list`);
        url.searchParams.set("limit", "200");
        url.searchParams.set("types", "public_channel,private_channel");
        url.searchParams.set("exclude_archived", "true");
        if (cursor) url.searchParams.set("cursor", cursor);
        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${integ.botToken}` },
        });
        const body = (await res.json().catch(() => ({}))) as {
          ok?: boolean;
          channels?: Array<{ id: string; name: string; is_private?: boolean }>;
          response_metadata?: { next_cursor?: string };
          error?: string;
        };
        if (!body.ok) {
          throw new Error(body.error ?? `HTTP ${res.status}`);
        }
        for (const c of body.channels ?? []) {
          out.push({ id: c.id, name: c.name, isPrivate: Boolean(c.is_private) });
        }
        cursor = body.response_metadata?.next_cursor;
        if (!cursor) break;
      }
      return out;
    });
    return channels;
  } catch (err) {
    log().warn({ err: errSummary(err), orgId }, "slack listChannels failed");
    return [];
  }
}

function errSummary(err: unknown): Record<string, unknown> {
  if (err instanceof Error) {
    return { name: err.name, message: err.message };
  }
  return { value: String(err) };
}

/** @internal — for tests. Reset the breaker between cases. */
export function _resetSlackBreakerForTests(): void {
  slackBreaker.reset();
}
