// Slack event dispatchers.
//
// Thin wrappers around sendSlackMessage that build BlockKit payloads for
// each of the 4 supported event kinds. Every dispatcher:
//   - Builds BlockKit blocks (header + section + context) and a plain-text
//     fallback for clients that don't render blocks (older mobile, screen
//     readers).
//   - Calls sendSlackMessage with the matching eventKind so per-event
//     preferences are honoured.
//   - Never throws. Failures are logged at warn; the user-facing path keeps
//     going.
//
// Call sites use `void slackNotifyX(...)` — fire-and-forget.

import { sendSlackMessage, type SlackEventKind } from "./slack";
import { log } from "@/lib/logger";
import { env } from "@/lib/env";

/** Best-effort base URL for building permalinks. NEXTAUTH_URL is the canonical
 *  app URL we already require for OAuth; falls back to "" so links degrade to
 *  the bare path (Slack still renders them; users just have to copy/paste). */
function appBaseUrl(): string {
  return env.AUTH_URL ?? env.NEXTAUTH_URL ?? "";
}

function absUrl(path: string): string {
  const base = appBaseUrl();
  if (!base) return path;
  if (path.startsWith("http")) return path;
  return `${base.replace(/\/$/, "")}${path.startsWith("/") ? path : `/${path}`}`;
}

async function fireAndLog(
  event: SlackEventKind,
  orgId: string,
  fn: () => Promise<unknown>,
): Promise<void> {
  try {
    await fn();
  } catch (err) {
    log().warn(
      {
        err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
        event,
        orgId,
      },
      "slack dispatcher failed",
    );
  }
}

export interface SlackRfpUploadedInput {
  id: string;
  title: string;
  questionCount?: number;
}

export async function slackNotifyRfpUploaded(
  orgId: string,
  rfp: SlackRfpUploadedInput,
): Promise<void> {
  return fireAndLog("rfp_uploaded", orgId, async () => {
    const rfpUrl = absUrl(`/dashboard/rfps/${rfp.id}`);
    const text =
      typeof rfp.questionCount === "number"
        ? `RFP processed: "${rfp.title}" — ${rfp.questionCount} questions extracted`
        : `RFP processed: "${rfp.title}"`;
    const blocks: unknown[] = [
      {
        type: "header",
        text: { type: "plain_text", text: "RFP processed" },
      },
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text:
            `*<${rfpUrl}|${escapeMrkdwn(rfp.title)}>*` +
            (typeof rfp.questionCount === "number"
              ? `\n${rfp.questionCount} question${rfp.questionCount === 1 ? "" : "s"} extracted and ready to answer.`
              : `\nReady to answer.`),
        },
      },
      {
        type: "actions",
        elements: [
          {
            type: "button",
            text: { type: "plain_text", text: "Open RFP" },
            url: rfpUrl,
            style: "primary",
          },
        ],
      },
    ];
    await sendSlackMessage(orgId, { text, blocks, eventKind: "rfp_uploaded" });
  });
}

export interface SlackResponseGeneratedInput {
  rfpTitle: string;
  questionText: string;
  confidence: number | null | undefined;
  groundingScore?: number | null;
  responseUrl: string;
}

export async function slackNotifyResponseGenerated(
  orgId: string,
  opts: SlackResponseGeneratedInput,
): Promise<void> {
  return fireAndLog("response_generated", orgId, async () => {
    const url = absUrl(opts.responseUrl);
    const conf = typeof opts.confidence === "number" ? `${Math.round(opts.confidence * 100)}%` : "—";
    const grounding =
      typeof opts.groundingScore === "number"
        ? `${Math.round(opts.groundingScore * 100)}%`
        : null;
    const summaryLine = grounding
      ? `Confidence: *${conf}*  ·  Grounding: *${grounding}*`
      : `Confidence: *${conf}*`;
    const text = `Response generated for "${opts.rfpTitle}" — ${truncate(opts.questionText, 120)}`;
    const blocks: unknown[] = [
      {
        type: "header",
        text: { type: "plain_text", text: "Response generated" },
      },
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: `*${escapeMrkdwn(opts.rfpTitle)}*\n>${escapeMrkdwn(truncate(opts.questionText, 240))}`,
        },
      },
      {
        type: "context",
        elements: [{ type: "mrkdwn", text: summaryLine }],
      },
      {
        type: "actions",
        elements: [
          {
            type: "button",
            text: { type: "plain_text", text: "View response" },
            url,
            style: "primary",
          },
        ],
      },
    ];
    await sendSlackMessage(orgId, { text, blocks, eventKind: "response_generated" });
  });
}

export interface SlackMentionInput {
  mentionedUserName: string;
  mentionerName: string;
  commentText: string;
  rfpTitle: string;
  commentUrl: string;
}

export async function slackNotifyMention(
  orgId: string,
  opts: SlackMentionInput,
): Promise<void> {
  return fireAndLog("mention", orgId, async () => {
    const url = absUrl(opts.commentUrl);
    const text = `${opts.mentionerName} mentioned ${opts.mentionedUserName} in "${opts.rfpTitle}"`;
    const blocks: unknown[] = [
      {
        type: "header",
        text: { type: "plain_text", text: "You were mentioned" },
      },
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text:
            `*${escapeMrkdwn(opts.mentionerName)}* mentioned *${escapeMrkdwn(opts.mentionedUserName)}* on *${escapeMrkdwn(opts.rfpTitle)}*\n` +
            `>${escapeMrkdwn(truncate(opts.commentText, 240))}`,
        },
      },
      {
        type: "actions",
        elements: [
          {
            type: "button",
            text: { type: "plain_text", text: "Open comment" },
            url,
          },
        ],
      },
    ];
    await sendSlackMessage(orgId, { text, blocks, eventKind: "mention" });
  });
}

export interface SlackOutcomeSetInput {
  rfpTitle: string;
  outcome: "PENDING" | "WON" | "LOST" | "WITHDRAWN" | "NO_BID";
  setByName: string;
  note?: string | null;
}

export async function slackNotifyOutcomeSet(
  orgId: string,
  opts: SlackOutcomeSetInput,
): Promise<void> {
  return fireAndLog("outcome_set", orgId, async () => {
    const emoji = outcomeEmoji(opts.outcome);
    const text = `${opts.setByName} set outcome ${opts.outcome} on "${opts.rfpTitle}"`;
    const blocks: unknown[] = [
      {
        type: "header",
        text: { type: "plain_text", text: `RFP outcome: ${opts.outcome}` },
      },
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text:
            `${emoji} *${escapeMrkdwn(opts.rfpTitle)}* — set by *${escapeMrkdwn(opts.setByName)}*` +
            (opts.note ? `\n>${escapeMrkdwn(truncate(opts.note, 240))}` : ""),
        },
      },
    ];
    await sendSlackMessage(orgId, { text, blocks, eventKind: "outcome_set" });
  });
}

function outcomeEmoji(outcome: SlackOutcomeSetInput["outcome"]): string {
  switch (outcome) {
    case "WON":
      return ":tada:";
    case "LOST":
      return ":disappointed:";
    case "WITHDRAWN":
      return ":wave:";
    case "NO_BID":
      return ":no_entry_sign:";
    case "PENDING":
      return ":hourglass_flowing_sand:";
  }
}

function truncate(s: string, n: number): string {
  if (!s) return "";
  if (s.length <= n) return s;
  return `${s.slice(0, n - 1)}…`;
}

/** Light mrkdwn escaping for user-supplied strings injected into blocks. */
function escapeMrkdwn(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
