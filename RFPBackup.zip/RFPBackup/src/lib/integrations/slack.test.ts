import { describe, expect, it, beforeEach, vi, afterAll } from "vitest";

const { prismaMock, decryptMock } = vi.hoisted(() => ({
  prismaMock: {
    slackIntegration: {
      findUnique: vi.fn(),
    },
  },
  decryptMock: vi.fn((s: string | null | undefined) => {
    if (!s) return null;
    if (s.startsWith("enc:")) return s.slice(4);
    return null;
  }),
}));

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/crypto", async () => {
  const actual = await vi.importActual<typeof import("@/lib/crypto")>("@/lib/crypto");
  return {
    ...actual,
    decrypt: (s: string | null | undefined) => decryptMock(s),
  };
});

import {
  sendSlackMessage,
  testSlackConnection,
  listSlackChannels,
  _resetSlackBreakerForTests,
} from "./slack";

const originalFetch = globalThis.fetch;

function setFetch(impl: typeof fetch) {
  globalThis.fetch = impl as typeof fetch;
}

afterAll(() => {
  globalThis.fetch = originalFetch;
});

beforeEach(() => {
  vi.clearAllMocks();
  _resetSlackBreakerForTests();
  decryptMock.mockImplementation((s: string | null | undefined) => {
    if (!s) return null;
    if (s.startsWith("enc:")) return s.slice(4);
    return null;
  });
});

// ---------------------------------------------------------------------------
// sendSlackMessage
// ---------------------------------------------------------------------------

describe("sendSlackMessage", () => {
  it("no-ops with ok:true when no integration exists", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue(null);
    const fetchSpy = vi.fn();
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", { text: "hi" });
    expect(res).toEqual({ ok: true, skipped: true });
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("no-ops when integration is disabled", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: false,
      botTokenEncrypted: "enc:xoxb-abc",
      webhookUrl: null,
      defaultChannelId: "C123",
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    const fetchSpy = vi.fn();
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", { text: "hi", eventKind: "rfp_uploaded" });
    expect(res).toEqual({ ok: true, skipped: true });
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("no-ops when the event kind is filtered out by preferences", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: "enc:xoxb-abc",
      webhookUrl: null,
      defaultChannelId: "C123",
      eventPreferences: { mention: false },
      teamId: null,
      teamName: null,
    });
    const fetchSpy = vi.fn();
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", { text: "hey", eventKind: "mention" });
    expect(res).toEqual({ ok: true, skipped: true });
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("uses the Slack Web API with Bearer auth when a bot token is configured", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: "enc:xoxb-secret",
      webhookUrl: null,
      defaultChannelId: "C-default",
      eventPreferences: null,
      teamId: "T1",
      teamName: "Acme",
    });
    const fetchSpy = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ ok: true, ts: "1234567890.000100" }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", {
      text: "hello",
      blocks: [{ type: "section", text: { type: "mrkdwn", text: "hi" } }],
      eventKind: "rfp_uploaded",
    });
    expect(res.ok).toBe(true);
    expect(res.ts).toBe("1234567890.000100");
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const [url, init] = fetchSpy.mock.calls[0];
    expect(url).toBe("https://slack.com/api/chat.postMessage");
    expect(init.method).toBe("POST");
    expect(init.headers.Authorization).toBe("Bearer xoxb-secret");
    const body = JSON.parse(init.body);
    expect(body.channel).toBe("C-default");
    expect(body.text).toBe("hello");
    expect(Array.isArray(body.blocks)).toBe(true);
  });

  it("falls back to the webhook URL when no bot token is set", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: null,
      webhookUrl: "https://hooks.slack.com/services/T0/B0/abc",
      defaultChannelId: null,
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    const fetchSpy = vi
      .fn()
      .mockResolvedValue(new Response("ok", { status: 200 }));
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", { text: "via webhook" });
    expect(res.ok).toBe(true);
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const [url, init] = fetchSpy.mock.calls[0];
    expect(url).toBe("https://hooks.slack.com/services/T0/B0/abc");
    expect(init.method).toBe("POST");
    const body = JSON.parse(init.body);
    expect(body.text).toBe("via webhook");
  });

  it("returns {ok:false, error} when the Slack API responds with ok:false", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: "enc:xoxb-secret",
      webhookUrl: null,
      defaultChannelId: "C-default",
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    const fetchSpy = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ ok: false, error: "channel_not_found" }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", { text: "hi" });
    expect(res.ok).toBe(false);
    expect(res.error).toBe("channel_not_found");
  });

  it("returns {ok:false, error} when fetch rejects (network failure)", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: "enc:xoxb-secret",
      webhookUrl: null,
      defaultChannelId: "C-default",
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    const fetchSpy = vi.fn().mockRejectedValue(new Error("ECONNRESET"));
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", { text: "hi" });
    expect(res.ok).toBe(false);
    expect(res.error).toMatch(/ECONNRESET|circuit/i);
  });

  it("no-ops when bot token is set but no default channel is configured and no override", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: "enc:xoxb-secret",
      webhookUrl: null,
      defaultChannelId: null,
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    const fetchSpy = vi.fn();
    setFetch(fetchSpy as unknown as typeof fetch);

    const res = await sendSlackMessage("org-1", { text: "hi" });
    expect(res.skipped).toBe(true);
    expect(fetchSpy).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// testSlackConnection
// ---------------------------------------------------------------------------

describe("testSlackConnection", () => {
  it("returns ok:true with team name on a bot-token integration", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: "enc:xoxb-secret",
      webhookUrl: null,
      defaultChannelId: "C1",
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    setFetch(
      vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ ok: true, team: "Acme Corp" }), {
          status: 200,
          headers: { "content-type": "application/json" },
        }),
      ) as unknown as typeof fetch,
    );
    const res = await testSlackConnection("org-1");
    expect(res).toEqual({ ok: true, team: "Acme Corp" });
  });

  it("returns ok:false when no integration", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue(null);
    const res = await testSlackConnection("org-1");
    expect(res.ok).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// listSlackChannels
// ---------------------------------------------------------------------------

describe("listSlackChannels", () => {
  it("returns [] when no bot token", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: null,
      webhookUrl: "https://hooks.slack.com/x",
      defaultChannelId: null,
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    const channels = await listSlackChannels("org-1");
    expect(channels).toEqual([]);
  });

  it("maps Slack API channels to the public shape", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValue({
      organizationId: "org-1",
      enabled: true,
      botTokenEncrypted: "enc:xoxb-secret",
      webhookUrl: null,
      defaultChannelId: null,
      eventPreferences: null,
      teamId: null,
      teamName: null,
    });
    setFetch(
      vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({
            ok: true,
            channels: [
              { id: "C1", name: "general", is_private: false },
              { id: "C2", name: "rfps-private", is_private: true },
            ],
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
      ) as unknown as typeof fetch,
    );

    const channels = await listSlackChannels("org-1");
    expect(channels).toEqual([
      { id: "C1", name: "general", isPrivate: false },
      { id: "C2", name: "rfps-private", isPrivate: true },
    ]);
  });
});
