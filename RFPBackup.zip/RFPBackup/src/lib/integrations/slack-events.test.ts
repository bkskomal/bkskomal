import { describe, expect, it, beforeEach, vi } from "vitest";

const { sendMock } = vi.hoisted(() => ({ sendMock: vi.fn() }));

vi.mock("./slack", () => ({
  sendSlackMessage: (...args: unknown[]) => sendMock(...args),
}));

import {
  slackNotifyRfpUploaded,
  slackNotifyResponseGenerated,
  slackNotifyMention,
  slackNotifyOutcomeSet,
} from "./slack-events";

beforeEach(() => {
  sendMock.mockReset();
  sendMock.mockResolvedValue({ ok: true });
});

function lastPayload(): {
  text: string;
  blocks: unknown[];
  eventKind: string;
} {
  const call = sendMock.mock.calls[sendMock.mock.calls.length - 1];
  // call[0] is orgId; call[1] is the SlackMessage.
  return call[1] as { text: string; blocks: unknown[]; eventKind: string };
}

describe("slackNotifyRfpUploaded", () => {
  it("builds a header + section + actions block", async () => {
    await slackNotifyRfpUploaded("org-1", {
      id: "rfp-1",
      title: "Acme Cloud RFP",
      questionCount: 42,
    });
    expect(sendMock).toHaveBeenCalledTimes(1);
    const payload = lastPayload();
    expect(payload.eventKind).toBe("rfp_uploaded");
    expect(payload.text).toContain("Acme Cloud RFP");
    expect(payload.text).toContain("42 questions");
    expect(Array.isArray(payload.blocks)).toBe(true);
    const types = payload.blocks.map((b) => (b as { type?: string }).type);
    expect(types).toEqual(["header", "section", "actions"]);
  });

  it("omits question count when undefined", async () => {
    await slackNotifyRfpUploaded("org-1", { id: "rfp-1", title: "Untitled" });
    const payload = lastPayload();
    expect(payload.text).not.toMatch(/\d+ question/);
  });

  it("never throws even when the underlying send rejects", async () => {
    sendMock.mockRejectedValue(new Error("transport down"));
    await expect(
      slackNotifyRfpUploaded("org-1", { id: "rfp-1", title: "x" }),
    ).resolves.toBeUndefined();
  });
});

describe("slackNotifyResponseGenerated", () => {
  it("includes confidence and grounding in the context block", async () => {
    await slackNotifyResponseGenerated("org-1", {
      rfpTitle: "Acme RFP",
      questionText: "Describe your SOC2 controls",
      confidence: 0.82,
      groundingScore: 0.91,
      responseUrl: "/dashboard/rfps/rfp-1?question=q1",
    });
    const payload = lastPayload();
    expect(payload.eventKind).toBe("response_generated");
    const context = payload.blocks.find((b) => (b as { type?: string }).type === "context") as {
      elements?: Array<{ text?: string }>;
    };
    expect(context?.elements?.[0]?.text).toContain("82%");
    expect(context?.elements?.[0]?.text).toContain("91%");
  });

  it("omits the grounding segment when groundingScore is missing", async () => {
    await slackNotifyResponseGenerated("org-1", {
      rfpTitle: "Acme RFP",
      questionText: "Anything?",
      confidence: 0.5,
      responseUrl: "/dashboard/x",
    });
    const payload = lastPayload();
    const context = payload.blocks.find((b) => (b as { type?: string }).type === "context") as {
      elements?: Array<{ text?: string }>;
    };
    expect(context?.elements?.[0]?.text).toContain("50%");
    expect(context?.elements?.[0]?.text).not.toMatch(/Grounding/);
  });
});

describe("slackNotifyMention", () => {
  it("escapes < > in user-supplied strings to prevent injection", async () => {
    await slackNotifyMention("org-1", {
      mentionedUserName: "Alice",
      mentionerName: "Bob <admin>",
      commentText: "see <here>",
      rfpTitle: "Acme",
      commentUrl: "/x",
    });
    const payload = lastPayload();
    expect(payload.eventKind).toBe("mention");
    const section = payload.blocks.find((b) => (b as { type?: string }).type === "section") as {
      text?: { text?: string };
    };
    expect(section?.text?.text).toContain("&lt;admin&gt;");
    expect(section?.text?.text).toContain("&lt;here&gt;");
  });
});

describe("slackNotifyOutcomeSet", () => {
  it("includes outcome emoji and uses outcome_set event kind", async () => {
    await slackNotifyOutcomeSet("org-1", {
      rfpTitle: "Acme",
      outcome: "WON",
      setByName: "Alice",
      note: "Direct contract.",
    });
    const payload = lastPayload();
    expect(payload.eventKind).toBe("outcome_set");
    const section = payload.blocks.find((b) => (b as { type?: string }).type === "section") as {
      text?: { text?: string };
    };
    expect(section?.text?.text).toContain(":tada:");
    expect(section?.text?.text).toContain("Acme");
    expect(section?.text?.text).toContain("Direct contract.");
  });

  it("omits the note line when no note provided", async () => {
    await slackNotifyOutcomeSet("org-1", {
      rfpTitle: "Acme",
      outcome: "LOST",
      setByName: "Bob",
    });
    const payload = lastPayload();
    const section = payload.blocks.find((b) => (b as { type?: string }).type === "section") as {
      text?: { text?: string };
    };
    expect(section?.text?.text).toContain(":disappointed:");
    expect(section?.text?.text).not.toContain(">");
  });
});
