// Typed error classes used throughout the app. Each one knows the HTTP status
// it maps to. Use `withApiHandler` (in api-handler.ts) to translate them to
// JSON responses automatically.

export class AppError extends Error {
  status = 500;
  code = "internal_error";
  /** Set true if the message is safe to show to users verbatim. */
  exposeMessage = false;

  constructor(message: string) {
    super(message);
    this.name = this.constructor.name;
  }
}

export class ValidationError extends AppError {
  status = 400;
  code = "validation_error";
  exposeMessage = true;
  details?: unknown;
  constructor(message: string, details?: unknown) {
    super(message);
    this.details = details;
  }
}

export class AuthError extends AppError {
  status = 401;
  code = "unauthenticated";
  exposeMessage = true;
}

export class ForbiddenError extends AppError {
  status = 403;
  code = "forbidden";
  exposeMessage = true;
}

export class NotFoundError extends AppError {
  status = 404;
  code = "not_found";
  exposeMessage = true;
}

export class ConflictError extends AppError {
  status = 409;
  code = "conflict";
  exposeMessage = true;
}

export class ExternalServiceError extends AppError {
  status = 502;
  code = "external_service_error";
  exposeMessage = true;
  service: string;
  constructor(service: string, message: string) {
    super(`${service}: ${message}`);
    this.service = service;
  }
}

export class LlmError extends ExternalServiceError {
  code = "llm_error";
  constructor(message: string) {
    super("llm", message);
  }
}

export class EmbeddingError extends ExternalServiceError {
  code = "embedding_error";
  constructor(message: string) {
    super("embedding", message);
  }
}

export class DocumentParseError extends AppError {
  status = 422;
  code = "document_parse_error";
  exposeMessage = true;
}
