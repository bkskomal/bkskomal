import { readFile } from "node:fs/promises";
import { prisma } from "@/lib/prisma";
import { parseAndProcess } from "@/lib/parsers/pipeline";
import { extractQuestions } from "@/lib/ai/extract";
import { logActivity } from "@/lib/activity";
import { advance as advancePipeline } from "@/lib/pipeline/engine";
import { slackNotifyRfpUploaded } from "@/lib/integrations/slack-events";
import { scoreAndPersist as scoreAndPersistWinPrediction } from "@/lib/predict/service";
import { extractAndPersistRubric } from "@/lib/rubric/service";
import { log } from "@/lib/logger";

/** Sink for live progress text — wired to the pipeline step's progressDetail
 *  by the EXTRACT_QUESTIONS handler so the workflow UI ticks while we work. */
export interface ProcessRfpOptions {
  onProgress?: (text: string) => void | Promise<void>;
}

export async function processRfp(rfpId: string, opts: ProcessRfpOptions = {}): Promise<void> {
  const onProgress = opts.onProgress ?? (() => {});

  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: { project: { select: { organizationId: true } } },
  });
  if (!rfp) throw new Error("RFP not found");

  await prisma.rFP.update({
    where: { id: rfpId },
    data: { status: "EXTRACTING", errorMessage: null },
  });

  try {
    await onProgress("Parsing document…");
    // RFPs go through the same AST pipeline as KB docs — we just don't
    // persist the AST/chunks (there's no schema for it on the RFP model
    // and the downstream extractor only needs the rendered text). Running
    // through `parseAndProcess` still gives us layout cleaning + OCR +
    // table repair which materially improves question extraction quality.
    const buffer = await readFile(rfp.storagePath);
    const { text } = await parseAndProcess(buffer, rfp.mimeType, rfp.fileName, {
      organizationId: rfp.project.organizationId,
    });

    log().info(
      {
        rfpId,
        fileName: rfp.fileName,
        mimeType: rfp.mimeType,
        fileSize: rfp.fileSize,
        parsedTextLen: text.length,
        parsedTextPreview: text.slice(0, 300),
      },
      `rfp-pipeline: parsed ${rfp.fileName} → ${text.length} chars`,
    );

    await prisma.rFP.update({
      where: { id: rfpId },
      data: { rawText: text },
    });

    await onProgress(`Parsed ${text.length.toLocaleString()} chars — extracting questions…`);
    const questions = await extractQuestions(text, rfp.project.organizationId, {
      onProgress: (msg) => onProgress(msg),
    });
    await onProgress(`Extracted ${questions.length} question${questions.length === 1 ? "" : "s"} — saving…`);

    await prisma.question.deleteMany({ where: { rfpId } });
    if (questions.length > 0) {
      await prisma.question.createMany({
        data: questions.map((q) => ({
          rfpId,
          number: q.number,
          section: q.section,
          text: q.text,
          required: q.required ?? true,
          complexity: q.complexity,
          topic: q.topic,
          whatIsAsked: q.whatIsAsked,
          eligibility: q.eligibility,
          eligibilityConfidence: q.eligibilityConfidence,
          requirementType: q.requirementType,
          originalNumber: q.originalNumber,
        })),
      });
    }

    const byComplexity = { simple: 0, moderate: 0, complex: 0 };
    for (const q of questions) {
      byComplexity[q.complexity] += 1;
    }

    await prisma.rFP.update({
      where: { id: rfpId },
      data: { status: "READY" },
    });
    void logActivity({
      rfpId,
      actorId: null,
      kind: "RFP_PROCESSED",
      payload: { questionCount: questions.length, byComplexity },
    });
    // Slack notification (Tier B1) — fire-and-forget. No-op when the org has
    // no Slack integration configured, the integration is disabled, or the
    // rfp_uploaded event is muted.
    void slackNotifyRfpUploaded(rfp.project.organizationId, {
      id: rfpId,
      title: rfp.title,
      questionCount: questions.length,
    });
    // Predictive win scoring (Tier C — moonshot). Fire-and-forget: the
    // scorer is pure-Prisma and cheap, but it isn't on the critical path
    // for "RFP is ready to answer". Failures get logged at warn level and
    // swallowed so they can't break the pipeline.
    void scoreAndPersistWinPrediction(rfpId).catch((err) => {
      log().warn(
        { err: err instanceof Error ? err.message : String(err), rfpId },
        "win prediction scoring failed",
      );
    });
    // Auto-extract the buyer's evaluation rubric. Fire-and-forget: the
    // rubric is an enrichment on top of the questions, not a precondition
    // for "ready to answer". An LLM hiccup or a missing rubric section
    // surfaces as an empty-criteria row downstream — never as a pipeline
    // failure.
    void extractAndPersistRubric(rfpId).catch((err) => {
      log().warn(
        { err: err instanceof Error ? err.message : String(err), rfpId },
        "rubric extraction failed",
      );
    });
    void advancePipeline(rfpId);
  } catch (e) {
    await prisma.rFP.update({
      where: { id: rfpId },
      data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
    });
    void advancePipeline(rfpId);
    throw e;
  }
}
