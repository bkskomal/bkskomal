// withApiHandler: wraps an async route function and translates thrown errors
// into consistent JSON responses. Also opens a request-scoped logging context
// so anything logged inside the handler is auto-tagged with a request ID,
// method, and route.

import { ZodError } from "zod";
import { AppError, ValidationError } from "./errors";
import { log, newRequestId, withLogContext } from "./logger";
import { RateLimitError } from "./rate-limit";
import { httpRequestsTotal, httpRequestDurationMs } from "./metrics";

type RouteContext<P = Record<string, string>> = { params: Promise<P> };

export function withApiHandler<P = Record<string, string>>(
  handler: (req: Request, ctx: RouteContext<P>) => Promise<Response>,
) {
  return async (req: Request, ctx: RouteContext<P>): Promise<Response> => {
    const reqId = req.headers.get("x-request-id") ?? newRequestId();
    const url = new URL(req.url);
    const start = Date.now();

    return withLogContext({ reqId, route: url.pathname, method: req.method }, async () => {
      try {
        const res = await handler(req, ctx);
        const ms = Date.now() - start;
        // Skip noisy debug logs for 2xx/3xx; emit one info per request.
        log().info({ status: res.status, ms }, `${req.method} ${url.pathname} ${res.status} ${ms}ms`);
        recordHttpMetric(url.pathname, req.method, res.status, ms);
        // Bubble the request id back to the caller for tracing.
        try {
          res.headers.set("x-request-id", reqId);
        } catch {
          // Some streaming responses freeze headers; ignore.
        }
        return res;
      } catch (err) {
        const res = errorResponse(err);
        const ms = Date.now() - start;
        log().warn(
          { status: res.status, ms, err: errSummary(err) },
          `${req.method} ${url.pathname} ${res.status} ${ms}ms`,
        );
        recordHttpMetric(url.pathname, req.method, res.status, ms);
        try {
          res.headers.set("x-request-id", reqId);
        } catch {
          // ignore
        }
        return res;
      }
    });
  };
}

export function errorResponse(err: unknown): Response {
  if (err instanceof ZodError) {
    err = new ValidationError("Invalid request body", err.flatten());
  }

  if (err instanceof AppError) {
    const res = Response.json(
      {
        error: err.exposeMessage ? err.message : "Internal error",
        code: err.code,
        ...(err instanceof ValidationError && err.details ? { details: err.details } : {}),
        ...(err instanceof RateLimitError ? { retryAfterSeconds: err.retryAfterSeconds } : {}),
      },
      { status: err.status },
    );
    if (err instanceof RateLimitError) {
      try {
        res.headers.set("Retry-After", String(err.retryAfterSeconds));
      } catch {
        // ignore — frozen headers
      }
    }
    return res;
  }

  log().error({ err: errSummary(err) }, "unhandled api error");
  const message = err instanceof Error ? err.message : "Internal error";
  return Response.json(
    {
      error: process.env.NODE_ENV === "development" ? message : "Internal error",
      code: "internal_error",
    },
    { status: 500 },
  );
}

// Collapse high-cardinality dynamic path segments into placeholders so the
// `route` label doesn't explode (one timeseries per UUID would be
// catastrophic for Prometheus). Anything that looks like a CUID/UUID/long
// numeric ID becomes `:id`.
function normalizeRouteForMetric(pathname: string): string {
  return pathname
    .split("/")
    .map((seg) => {
      if (!seg) return seg;
      if (/^c[a-z0-9]{20,}$/i.test(seg)) return ":id"; // cuid
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(seg)) return ":id";
      if (/^\d{6,}$/.test(seg)) return ":id";
      return seg;
    })
    .join("/");
}

function recordHttpMetric(pathname: string, method: string, status: number, ms: number): void {
  try {
    const route = normalizeRouteForMetric(pathname);
    const labels = { route, method, status: String(status) };
    httpRequestsTotal.inc(labels);
    httpRequestDurationMs.observe(labels, ms);
  } catch {
    // never let telemetry break a response
  }
}

function errSummary(err: unknown): Record<string, unknown> {
  if (err instanceof Error) {
    return { name: err.name, message: err.message, stack: err.stack?.split("\n").slice(0, 3).join("\n") };
  }
  return { value: String(err) };
}
