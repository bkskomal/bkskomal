import { mkdir, writeFile, unlink } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { env } from "@/lib/env";

export async function saveUpload(
  scope: string,
  fileName: string,
  data: Buffer,
): Promise<{ storagePath: string }> {
  const dir = join(env.UPLOAD_DIR, scope);
  await mkdir(dir, { recursive: true });
  const safe = fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const finalName = `${randomUUID()}-${safe}`;
  const fullPath = join(dir, finalName);
  await writeFile(fullPath, data);
  return { storagePath: fullPath };
}

export async function deleteUpload(storagePath: string): Promise<void> {
  try {
    await unlink(storagePath);
  } catch {
    // already gone
  }
}
